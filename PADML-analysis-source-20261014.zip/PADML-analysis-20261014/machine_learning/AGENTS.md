# Integrated raw-data nested LOCO computation

Read NESTED_LOCO_PROTOCOL.md before changing scientific code. Current user
instructions take precedence. This worktree implements the current a.xlsx batch;
it does not restart, delete or rewrite the completed historical batch.

## Authority and scope

- Main process is the only writer of production source, configuration, protocols,
  commits and release bundles. Three subagents may audit read-only or test in
  disposable directories. The main process integrates their findings.
- Necessary causal fixes, direct-consumer changes, compilation and focused checks
  are authorized. Do not add approval stages, services, queues, databases,
  acceptance frameworks or speculative tests. Use guard and karpathy guidance.
- Resource-call regressions must exercise the real admission contract, not a
  stub that accepts inconsistent batch/task estimates. A retained-only recovery
  submits no pending ReadyPool stage when there is no scientific task to run.
- The single audit chain is real input -> necessary scientific computation ->
  real numerical output -> direct downstream consumer. State exactly what a
  check proves. Engineering fixtures never establish clinical completion.
- Every confirmed engineering issue needs original failure reproduction,
  causal patch, a real retained product, actual downstream consumption and
  interrupted/cross-version recovery evidence in the existing final review.
  Missing evidence means OPEN, even if compilation, deployment or a worker
  reports COMPLETED. Require exact unique MI coordinates, explicit numerical
  statuses and actual research/clinical scope dispositions in the direct consumer.
  Do not introduce another acceptance framework or service.
  Record engineering defects, required calculations, new research, statistical
  limitations and user-paused delivery in separate fields. A failed research
  method and authorized delivery pause are not runtime defects; neither is PASS.
- H01 has an isolated Linux candidate checkout. Real-input checks are authorized;
  installed production source stays frozen until acceptance and deployment.
  Three preimplementation audits are closed. Perform two read-only cross-audit
  rounds after implementation, then only causal repairs and affected checks.
  A source review or engineering fixture is never a completed clinical run.

## Production path

- The 2026-10-09 `result_closure` is an evaluation-only appendage on the eight
  retained FULL0/EVALUATION owners. Never enter model fitting, training MICE,
  SHAP or B/P generation to repair this tail. A04 has 784 AUC, 784 calibration
  groups and 343 distinct Uno coordinates: 196 retained 24-month reference
  coordinates plus 147 at the other lines' own windows. Each Uno uses the risk
  score and truncation time of that same window. Negative-control gates remain
  at 24 months; the new Uno diagnostics cannot select models. Original predictions and permuted
  outcomes are authoritative. Old calibration definitions remain historical.
- A04 numerical failure is not a scientific NA. Preserve the six fixed centers,
  macro weights, negative thresholds and original96 eligibility. Review new
  negative alerts causally; no threshold/seed/model replacement. Six completed
  Exp1 simulations resolve reliability to failed tested scopes/unvalidated
  other scopes, never to a claimed clinical-center coverage rate.
- Publish the compact current report and six-center cross-time diagnosis before
  archival confirmation. No PAVA or plotting. Archive remains paused until
  actual numerical consumption, A04 review, original96 and the final audit pass,
  AND a subsequent explicit human instruction authorizes resumption.
  Reuse unchanged history; do not serialize another complete historical report.
- Final acceptance and its exact evidence must enter the existing archive object
  store once. Offline report readers validate the same acceptance against the
  eight actual tail identities and current report. Preserve original negative
  alerts; causal review completion is a separate delivery record, not a rewritten
  numerical PASS or a claim of clinical validity.

- One fresh run.json accepts workbook, run ID, seven hosts and pinned Python/R
  environment. No old F1 runtime, F2 run, 46-unit barrier or historical producer
  chain is required. F1/F2 kernels are internal functions only.
- Keep 56 units: 24 PRIMARY, 24 three-branch AAR, 4 FULL0, 4 EVALUATION; append
  O_fit and selection B1000 for 24 PRIMARY plus 4 FULL0 contexts. AAR has no
  separate family competition, OOF development, O_fit or selection bootstrap.
- Each instance owns one active job. Use existing worker, manifest, ordered pool
  and next assignment logic. Keep context-local execution and dynamic refill.
  UNKNOWN running state never permits duplicate dispatch or starting another
  owner. Independent lines can evaluate on separate instances.
- Recovery reads original stage/coordinate data, skips completed work, and
  resumes only genuine gaps. Input drift, incomplete publication and corrupted
  evidence are errors, not permission to train another copy.
- Same-batch causal source repairs use the existing pinned unit_predecessor.
  Admission requires the identical raw batch, scientific contract, budgets and
  reviewed exact source pairs. A reviewed native performance upgrade additionally
  binds the exact previous/current dependency locks, loaders and installation
  manifests; the new actual installation must qualify independently. Keep the
  frozen science authority unchanged. Preserve previous contexts, receipts
  and producer identities. An old Q header without a complete model is failed
  evidence; a new executor fits under its own key. Keep live owners on their
  immutable release and original manifest; stage the repaired manifest separately.
  Training compatibility admits only the registered base-to-six-tier
  frequency amendment, with unchanged successful 12/20 prefixes. Evaluation
  amendments have their own exact contract and appended results; they never
  change a training/MICE/selector/model identity or relabel historical metrics. No historical
  outer4 exception or arbitrary science SHA substitution is admitted.

## Scientific invariants

- The independent AAR threshold appendage uses the pinned association A01
  observed cohort and its complete20 MI, never the ML imputation/input identity.
  Its explicit contract is `config/threshold-analysis.json`: fixed1.46,
  training-only LOCO threshold selection at24 months, shared center-stratified
  B1000, and at most141 logical association Cox fits. No training MICE,
  seven-family retraining or plotting. New threshold intervals may use at least
  950 valid paired draws, explicitly exploratory and not coverage-validated;
  this exception does not change any historical B1000 consumer. Preserve all
  failed coordinates and statistical non-estimability. Direct report consumption
  and interrupted recovery, not task completion alone, establish this appendage.

- The independent 2026-10-09 evaluation_extension adds three FULL0 six-center
  36-month odd/even M20 panels (30 coordinates, at most18 evaluation fits),
  references the existing H36 ten without recomputation, and reports original
  application coverage179 unique people (50/2/50/12/50/15); four lines are716
  assessments, not716 independent patients. Old reports and qualifications stay
  unchanged. Research owner tasks use the original appendage and ReadyPool.
- The two fixed AUC research candidates are studentized center Exp1 with
  weighted-KM IF variance, and hierarchical logit-AUC with joint patient IF
  covariance. Preserve the exact registered hypotheses, priors, seeds, eight
  scenes,100 pilot and2000 independent confirmation datasets/scene,1999 joint
  perturbations/dataset. Original-point unsupported coordinates remain NA.
  Failed numerical integration/interval publication stays in the original
  estimable denominator. Do not add methods, seeds or loosen gates until PASS.
  Hierarchical inference excludes MICRO; derived means/differences do not enter
  its likelihood. Shared random streams/covariance preserve all paired branches,
  times and OOF repeats. No ridge, invented covariance blocks or prior selection.
- Current report consumption must include the full40 MI panel, application
  coverage, historical warnings and the complete independent research reduction.
  Keep research completion separate from reliability by validated scope and
  from clinical applicability. Prior Exp1 failures, H12 negative-control alert,
  LOCO crossing and incomplete B1000 intervals remain explicit limitations.
- All archive modes obey the new explicit user pause. Paused dispatch creates
  no inventory, sender, ACK, Quark upload or source retirement. Enabled/staging
  drains reconcile exact original request IDs, including pre-import adapters
  and ACKs; IDLE is never an inventory. A successful transmission first persists
  its existing location index; index failure cannot cause a retransmission.
- Historical report reuse checks current then the complete qualified ancestor
  chain (up to128 unique ancestors), nearest first. An existing corrupt candidate
  stops recovery instead of falling back to older evidence. Preserve every edge
  pin, cycle rejection and unchanged historical report bytes. Stable restart
  reads only required completion heads, not139 members or another47.5MB report.

- Use the current a.xlsx identity and recompute clinical MICE. Derive the 44
  candidate and 33 active-target counts from their distinct role lists. Keep
  RBC/HGB/MCV/RDW_CV/INR; exclude HCT/MCH/MCHC/RDW_SD/PT/PT Activity from selection.
  PT-family imputation/transforms stay unchanged. Center is grouping only;
  Barthel is raw-only and predicts neither height nor weight.
- Formula prefill consumes one projected original-observation snapshot, before
  outcome auxiliaries; no recursive fill, invalid divisor or conflicting result.
  Recompute HCT/MCH/MCHC from bases. Unconfirmed WBC/protein relations are
  diagnostic-only: no arbitrary tolerance, scaling, clipping or PMM retries.
  ANALYSIS uses only its own training outcomes; APPLICATION never sees outcomes.
  All direct consumers use the same effective inputs and role requirements.
- Check all M20 chains jointly at 30/40/50. Complete, unique, finite PSRF/AC
  coordinates are mandatory; PSRF <1.1, or only at 50 <1.2. Resume lagging chains
  from their own RNG and append donor traces. Never filter bad diagnostics.
- Independent development horizons 6/12/24/36 months, all report four times.
  Keep six validation centers and center55 training only; keep M20, original
  seeds, PMM, 30->40->50 MICE iterations, recipe and native model algorithms.
- MICE, transformation, selection and tuning are partition-local. Heldout
  outcomes never enter training or application views. FULL0 is a development
  model, not external validation. New data has new data/run identities.
- H36 excludes center55 from validation loss/STOP/scoring, while retaining it
  in training, MICE and EPV. Do not reuse changed SetA, STOP, seed or population.
- Formal parent reselection in PRIMARY, FULL0 and the third no-AAR redevelopment
  uses (EPV15,12/20) -> (10,12/20) -> (10,14/20) -> (10,16/20) ->
  (10,18/20) -> (10,20/20), inclusive. Validate every coarse alpha and all M20
  paths before choosing the first tier with any feasible candidate. Keep the
  original alpha/lambda selection and one fine grid at that locked tier; its
  coarse winner must remain present and feasible. Never escalate after fine.
  Reaggregate qualified EPV10 frequencies without new native paths or altered
  MI lambdas. Empty common SetA is valid NOT_ESTIMABLE, never a replacement
  model; terminal exhaustion cannot produce Q, a development lock or final fits.
  Missing, nonfinite, unconverged or invalid no-entry native paths are errors,
  never fallback. Fixed-SetA branches and independent diagnostics keep their
  original rules. This is an explicit post-result amendment, not prespecified.
  Preserve exact old successful 12/20 prefixes and producer bytes; admit only
  the registered base/amendment identities. A producer's request, lock and
  prediction must still match exactly; only aggregation may combine them.
- Exhausted valid selectors publish typed NOT_ESTIMABLE evidence and original
  path references. Dependent contexts terminate explicitly without phantom fits.
  A failed third AAR branch retains its first two complete branches. Six-fold
  coverage is always reported; incomplete branch metrics/comparisons are not
  estimated, reweighted or filled with zeros. Independent contexts continue.
  Imported selector references never establish a receiving host's context owner.
  For integrated ownership, OUTER uses its private primary-context.json and
  FULL0 uses common/full-development.json; imported selection draws establish
  neither. An active original worker owns its context before preparation publishes.
- Preserve complete loss and outer coefficient paths, df, health and actual
  EPV. Fixed-SetA Elastic and FPM use their required real INNER score fits.
- Shared computations must match actual patients, MICE, recipe, SetA,
  parameters, stage, seed, STOP and kernel. Preserve producer identity. One
  fit yields one 0-36 month curve; each line separately scores/promotes/locks.
- Weighted center macro uses this batch's original validation patient counts.
  Equal center macro remains. No reweighting for missing centers, no discarding
  unestimable draws, no new draws. All 1000 IDs, type7 intervals, AAR minus
  PRIMARY; numerical estimability and process completion are separate.
- The evaluation-only 2026-10-07 amendment is explicitly post-result. At report
  month36, every development line uses its original evaluation population's
  intersection with the six registered validation centers, including the whole
  monthly IBS integral. Earlier reports retain their main population and add
  six-center sensitivity. Training, Center55, EPV and formal IBS winners stay
  unchanged. Sensitivity filters original draw/OOB indices, preserving all B1000
  IDs and multiplicities; it never redraws or rewrites the formal family.
- New evaluation readers use per-metric support, G>=.05 and ESS>=max(30,.2n),
  without the old20 case/control gates. Zero events/controls, pair support,
  calibration rank/separation and numerical failure are distinct. One failed
  calibration metric cannot erase successful discrimination/error metrics.
  AUC inference includes estimated center-KM and shared-patient covariance;
  boundary/degenerate or insufficiently validated intervals stay unreliable.
  The fixed three-quantile natural-logit-spline diagnostic uses IPCW for fitting
  and all evaluation rows unweighted for ICI/E50/E90. No knot/degree/penalty
  fallback. Raw risk is preserved, including the O/E denominator. Old LOESS
  and bootstrap bytes remain historical. These are conditional fixed-prediction
  intervals, not full-development uncertainty or predictive recalibration.
- Keep four independently fitted predictions unchanged; no PAVA and no AUC
  family reselection. Crossing is a coverage-aware diagnostic. A training-KM
  IBS comparator uses each original fit population's event outcomes, never
  validation outcomes or the censoring KM. New metrics cite their original
  prediction/response/draw, population, report time and exact amendment.
- SHAP keeps full patients/background, four outputs, tol=.005 and original
  random stream. Preserve converged patient checkpoints and M20 models;
  bounded recovery max2000 follows the original patient-start contract.

## Post-lock diagnostics and application

- PRIMARY/FULL0 postprocess must finish mRMRe/Boruta, the independent AST_ALT
  penalty1 audit, and winner-only extra seeds. Keep core receipt/SetA/lock
  immutable. AAR adds none of these diagnostics. SetB is explicitly excluded.
- mRMRe/Boruta use M20 and original seeds (FULL0 outer0); reuse identical native
  rankings, then reduce using the main selector's locked EPV15 or10. Report
  12/14/16 sets, frequency, df/EPV, stability and overlap. No independent tier switch.
- Natural AST_ALT uses a separate identity/penalty1, original coarse/fine and
  per-MI lambda selection. Count actual nonzero design columns and follow the
  complete coarse EPV15->10 rule independently. Report coefficient/nonzero/20;
  no success threshold or writeback to the main penalty0 selector.
- Extra seeds use the winning RSF/GBM/XGBoost candidate's original owner hash,
  two registered offsets, INNER15*M5; boosted families retain STOP/refit.
  No candidate search rerun. Other winners explicitly report NOT_APPLICABLE.
- The historical FULL0 application self-check uses at most2 missing-data patients per validation
  center, fixed order, center55 donor-only, batch and single M20 four-output
  predictions. It is not the original50-per-center A04 deployment assessment.
- The approved 2026-10-08 repair retains the original 96 coordinates and all
  original patients. Each of the 10 failures needs original reproduction,
  a demonstrated cause and independent real prediction after repair; all 86
  previous successes must also regress. A04 completion cannot satisfy this gate.
- Application batching must reuse the identical singleton patient MICE
  transaction: donors, input, recipe, M20 and RNG protocol are bound separately
  from the model. Independent cold A/B stores may consume at most40 chains per
  unique original patient, at most1,920 in total. Both endpoints run prediction;
  reading the same cached risk array is not a parity test. Keep old failed bytes.
- Complete A04 uses the current six PRIMARY locks in each of four lines, with
  per-MI formal parameters for variants, negative controls and sample-size fits.
  The original two S3B1 center-stress candidates keep their own stopping locks;
  local diagnostics alter only the registered adjacent parameter. Preserve the
  original42-grid seed ordinal, current EPV/frequency tier and training center55.
  Center stress consumes OUTER APPLICATION, sample-size diagnostics consume the
  registered merged OUTER views, and local perturbations consume the five INNER
  repeat1 ANALYSIS/APPLICATION pairs. Do not exchange their fitted populations.
  New integrated provenance is explicit; never fabricate old F1/F2 acceptance.
- Calibration repairs retain the exact unpenalized likelihood, weights, fixed
  knots and original gradient tolerance. Check output accuracy on zero-weight
  patients too, but do not add them to the likelihood. Repair only failed fits
  and affected reductions; retain distinct structural NA and numerical failures.
- New exponential-weight AUC inference is independent of original B1000/IF.
  Bind one frozen patient universe, shared PCG64 weights, each re-estimated
  center KM, all1999 IDs and exact RNG state. No metric-specific streams,
  failed-draw removal, clinical ESS gating inside perturbations or reliability
  claim before the six registered2000-dataset coverage checks pass by scope.
- During this repair, f45-next defaults to archive-mode paused and in that mode must not
  instantiate archive scanning/transfer/confirmation. Keep partial files and
  historical pins. Explicit re-enable requires original10/96 closure, calibration
  disposition, complete A04 review, CI validation, direct report consumption and
  final audit. Deployment, numerical estimability and scientific completion are
  separate statuses. No duplicate dispatcher or Quark authorization reset.
  While paused, the same dispatcher collects only declared repair summary heads
  with their completion-reference pins, then publishes the local numerical report.
  This direct consumer creates no archive inventory, archive ACK or new service.
- Explicit materials-only archiving uses archive-mode staging in the same
  dispatcher and seven-slot IO pool, including immutable completed results on
  a host whose scientific worker is still running. Inventory scopes require
  completed unit/postprocess/selection and applicable appendix heads; pending
  A04/evaluation work is deferred, never traversed. Scope-specific inventories
  preserve full-inventory bytes. Shared entities have one queued/in-flight
  writer; at most two archive streams and three inventory calls leave control
  capacity. These are local call slots: a timed-out remote reader retains its
  own host lease until exit. Rotate first requests and lease probes by the last
  request time, so repeated probes cannot starve a later host. Same-host heavy
  inventories and senders are mutually exclusive, including unknown remote
  leases/requests; ready transfers precede new inventories. Status-only exit
  probes remain allowed. Persist successful locations in the existing index, including on
  drain. SSH loss/local signals retain the exact sender request and UNKNOWN
  slot until two native process/lease exit observations; never equate local SSH
  termination with remote completion. MATERIALS_SAVED is not a window receipt, scientific acceptance or
  retirement authority. Only enabled mode after the original final gates may
  publish complete windows and send archive_confirm; staging inventories cannot
  authorize those actions. Do not stop a healthy calculation for archiving.
- Calibration leaves with the same input path may retain different admitted
  producer bytes. Archive only those proven identical after removing producer
  and seal under separate pin-addressed index entries; keep the original ZIP
  member names, inventories, receipts and scientific files unchanged. Pinned
  consumers must resolve their exact original SHA/size, including offline and
  cold recovery. Ambiguous unpinned reads, numerical drift and conflicts in
  other roles remain errors. A scope with one producer keeps its original
  closure digest; a full closure with variants must include every original pin.
- Zero-missing views have20 logical data slots,0 imputation chains/iterations,
  no RNG consumption and no applicable convergence statistic. Their typed
  complete-data objects must not be described as fitted mids chains.

## Same-run bounded recovery

- Preflight the complete O_fit or final M20 batch before fitting. An existing
  incomplete native directory is never a fresh task. Complete retained pairs
  use native object checks, original training replay and the direct numerical
  consumer with zero new fits. Commit model, baseline, health and training
  predictions durably before successful scratch cleanup; failed commits retain
  the original scratch.
- The October 6 H06 repair is restricted by the run's pinned score_repair
  report to PRIMARY-H06-O5 and the original fourteen pending coordinates.
  Only individually confirmed unrecoverable entries may fit once with their
  exact source record, parameters and seed. Preserve the five original inputs
  by atomic rename. A second partial attempt stops; a new complete pair only
  replays. No implicit deletion or widening of this repair authority.
- SHAP patient recovery follows one admitted upstream ancestry. Bind each
  patient's original spec, file pin and original-budget RNG; never replay
  already completed sampling. Contradictory overlap, forks and drift fail.
  Retire partial ancestors only after the complete carrier's numeric consumer.
- A known UNKNOWN owner quarantines that host and its dependencies while
  independent healthy hosts proceed. An unknown identity or shared-input
  failure stops new dispatch. Keep the same attempt_id across SSH timeout and
  owner reconciliation; one IDLE observation or an older same-coordinate
  RETURNED owner cannot release an uncertain launch slot.
- Worker takeover under the original lock permits only an empty record or a
  validated RETURNED owner whose complete process groups have exited. FAILED
  and UNKNOWN require explicit, pinned same-inode recovery. Stage immutable
  releases alongside healthy owners; only their next task uses the new code.
- Native observers use shared locks. A live exclusive writer is identified by
  its complete owner header and real PID/PGID; reading an unfinished group
  append must not erase that identity. IDLE requires a stable complete log and
  exited groups. Workers wait briefly only for shared readers, never for another
  exclusive owner. Registration gaps retain the existing pending attempt;
  only an explicit pre-Popen rejection proves that attempt created no child.

## Storage and resources

- The 2026-10-08 curve/RMSE appendage consumes only the four retained PRIMARY
  LOCO and four FULL0 apparent mean-M20 survival matrices. Keep one fixed six-
  center population throughout0-36. No AAR, refit, model prediction, MICE,
  resampling or SHAP work is introduced. Validation outcomes construct observed
  KM only; never re-estimate model baselines on validation patients.
- Each ready curve coordinate uses the original appendage owner and dynamic
  single pool with C-8 ceiling and max(1GiB, actual need). Admit before reading
  predictions; reserve only compact output and real temporary/publication peaks.
  Reuse qualified source pins and read necessary members directly. Eight small
  independent coordinates do not justify splitting patients/months into many
  jobs, a new pool, or duplicating matrices to fill24 slots. Preserve original
  repair completion and archive pause gates. Publish one small numerical result
  per coordinate; the existing I/O pool collects compact numerical JSON/CSV only.
  Current workers and dispatcher perform calculation, not plotting: no plotting
  imports, figure generation or figure pins in completion/archival dependencies.
  Retain the monthly survival/risk, KM knots/intervals, at-risk counts and RMSE
  needed by a later independent visualization consumer.
  Observe prior repair completion once and distinguish curve-only pending work;
  it must not repeat training-KM/A04 transfers. Publish the eight-curve report
  when its own sources are ready, without waiting for unrelated A04 tasks.
  Stable report recovery reuses its small numerical results, not new RPCs.

- Retain one formal carrier for models and required numerical evidence.
  unit.json references artifacts; no enclosing unit.zip, full-source/result
  nested archives, duplicate raw CSV trees or nonessential model replay.
- First publish/transfer or changed source requires its SHA/scientific check.
  Consumers may reuse qualified unchanged evidence; never cache UNKNOWN or
  failure, change old identities, or retain mutable shared cached objects.
- Prepare every required shared Q input hard-link alias before worker reads,
  including the nested GBM H36 donor inside the search carrier. Worker imports
  must not change a shared input inode's ctime. Keep complete stat and SHA drift
  checks; do not ignore ctime or retry away real input mutation.
- A reviewed same-batch source successor reuses the original completed V1
  historical-storage migration receipt, without rescanning converted atoms or
  relabeling released bytes. New atoms retain their normal direct-consumer
  cleanup. A changed migration contract requires a new receipt version.
- Native candidate risks/models may retire only after their original numeric
  consumer, paths/curves and bindings are durable. STOP function data needed
  for another actual population stays in the shared producer until consumed.
  Retire exact owned members and hard-link aliases, not directories by name.
- Audited GBM STOP may replace retained risk matrices with one immutable
  GBM_LOSSES_V1 member containing both complete ALL and H36 loss paths. Keep
  original receipt/values/seal bytes, task identity and lock rules. An empty or
  event-free H36 population preserves its original native rejection and matrix;
  it cannot block a legal earlier window. Qualify old H36 consumers before
  unlinking every known alias; an unknown link protects that inode.
- Completed MICE/native and numerical carriers remain unique. Retire only
  member-pinned FIT/REPLAY/gather copies after the original direct consumer.
  AAR prepares one active branch; preparation returns owned member pins in
  memory. Never discover cleanup candidates by recursively hashing a tree.
- Restored artifacts already occupy observed free space. Reserve only their
  future qualification/output increment, plus genuine transient/publication
  peaks. Every ReadyPool refill uses a fresh observation; only stable owned
  in-flight writes can reduce their remaining reservation. Do not credit shared
  hard links or count existing data a second time.
- Logical carrier references have no physical ZIP header offset. Evaluation
  reads referenced inputs through the original qualified carrier resolver,
  including offline packed sources. A failed evaluation appendage resumes the
  completed unit with zero MICE/model fits; COMPLETED alone is not evaluation-ready.
- Final M20, original models, OOF, application materials and SHAP are protected.
  Bootstrap coordinates retain consumed statistics/support/provenance; shared
  predictions and draws stay once. Delete duplicate native inputs only after
  compact publication and its direct reader have succeeded.
- Keep one process pool, measured C-8 as a ceiling, threads1. The 1GiB per-worker
  value is an admission estimate floor, not a physical allocation or a target
  of 24 reserved slots. Larger task-specific estimates still apply. Qualified historical records keep
  their original 2GiB observation/budget; new admission uses the 1GiB minimum.
  Scratch reserve0 does not remove live disk/IO checks. Admit retained data,
  active worker transient outputs and one publication/transfer peak; reduce
  concurrency when storage is limiting.
- At real dispatch/lifecycle events, drain newly completed I/O, return completed
  warm idle workers that have no immediately admissible task, then remeasure.
  Retain bounded preparations for immediate reuse inside a live batch. Confirm
  the whole registered process group has exited before reusing its slot; an
  exit in progress must not block other safe slots. Preserve active tasks,
  release ACKs and READY deadlines. Cold workers cannot be recycled without
  scientific progress. Never credit all active_file or requested cache advice
  as free memory; retain conservative peak estimates for in-flight tasks.
- Cache release uses the consumer's existing paths/handles/member indexes after
  mappings and native children close; no extra SHA, receipt replay, directory or
  process-tree scan to discover files. Successful advice leaves the pending set;
  unchanged later consumption is a new cache generation. Failed hints have bounded
  entries, bytes, age and attempts. Drain only pending hints after pools close.
  ZIP ownership ends at the last child handle; SHAP mapping ownership ends at the
  last derived view, without forcibly closing shared mappings. Failure/cancel
  paths preserve scientific errors and resumable bytes. Required publication
  fsync remains a real I/O operation; read-only consumption does not resync it.
  Remeasure on dispatch/lifecycle events; only actual pending
  work blocked by resources with spare CPU retries every five seconds for
  external relief. No busy polling, global drop_caches, cgroup permission
  changes or deletion disguised as page reclaim. Diagnostics are bounded summaries plus finite error samples.
  UNKNOWN cache disposition does not invalidate science or prevent otherwise
  safe retirement; cache advice is not proof of physical eviction or file deletion.

- All roots come from manifest.run_root, even when run.json lives elsewhere.
  An archive with explicit references requires its declared closure; it is not
  a self-contained export. Source pin changes invalidate qualification.
- A successful scientific qualification may be reused only with the same
  frozen contract and unchanged file pins. First selection reduction validates
  all1000 coordinates; later complete resumes do not reread OOF matrices.
  Shared bootstrap archives retain their admitted original producer identity
  across a same-batch source repair; absence or drift cannot trigger new draws.
  New SHAP patient records bind the actual original-budget RNG state at write
  time. Legacy unqualified partial segments need a sampling-state check only
  at their unanchored boundary, without repeating prediction or SHAP solving.
- Deployment qualifies installed R/Python files, runtime-manifest SHA and actual
  loader paths, plus source/dependency identity. Persist that qualification;
  cleaned installation archives are not a subsequent runtime requirement.
  Changed files or loader paths invalidate it. Never substitute version strings
  for first byte and scientific checks. New native patches have new version/SHA.
- Reuse the existing file qualification across consumers. Recent writes inside
  the filesystem timestamp ambiguity window are rehashed. Keep one required
  MICE/SHAP representation and exact source references, including .producer.
- A window archives its full reference closure to the verified external volume
  through the existing IO pool (at most three large transfers, at most two for
  background archives, leaving one for required calculation inputs). Transfers
  retain partial bytes on a 60-second stall; follow-mode dispatch must not wait
  for all independent transfers before observing owners and refilling. ExFAT publishes
  same-directory .part files by rename; no hard links on that volume. Failure
  retains remote source; only all actual consumers plus confirmed archive allow
  formal-source retirement. Quark is the previously bound backup channel.
- Archive the canonical GBM projection and its original five bindings with
  completed Q coordinates, including historical carriers whose SHA stays fixed.
  Confirm file and parent-directory durability before retirement or ACK. Keep
  strict inventory identity; do not reuse an old ACK for a changed closure.
- Archive readers on one host share the existing archive-directory lease.
  An SSH timeout leaves that reader UNKNOWN; a new heavy scan waits for the
  original lease to exit. Harvest other hosts independently. Qualified unchanged
  inventories do not rescan carriers. First closure follows declared reference
  metadata and the complete selection replicate member table; nested stored
  ZIPs use bounded random access. Offline readers consume packed B members
  directly. New evaluation/closure versions append their own immutable pins;
  they never overwrite an old window's completion evidence.
  Legacy Q input copies within a qualified carrier share one reference scan
  only when its sealed numerical member index declares the same SHA/size and
  the ZIP metadata agrees. Verify the first input bytes; unknown formats and
  changed ZIP metadata retain the actual read. Do not use CRC as an identity,
  skip unindexed references, or rewrite the original carrier to remove copies.
  A live inventory lease supersedes that reader's stale SSH timeout display;
  other unresolved readers and transfer failures remain visible.
  Archive member lists travel through bounded, SHA-bound stdin, never an
  unbounded SSH argv. Keep original pack membership, pins and resume offsets.
  A failed sender retains its exact host/storage/inventory/offset, exit code
  and bounded stderr in the existing error receipt. Retain legal partials;
  clear only the error belonging to a transfer that has actually succeeded.
- On dispatcher drain retain the existing lock, stop assignments, settle
  in-flight I/O and reconcile the same attempts. An older dispatcher without
  this handler still requires explicit adapter/owner/PID/PGID reconciliation.
- A follow dispatcher observes before pumping pending RPCs. Anonymous SSH
  observation failures retain its original lock, futures and attempts until a
  complete locatable observation returns; no partial-snapshot dispatch/archive.
  Post-Popen transfer receipt loss is TRANSFER_OUTCOME_UNKNOWN and retains its
  assignment even after local SSH exit. Old RETURNED/IDLE is not proof of remote
  receiver exit. Known independent hosts may continue. Only an acknowledged
  receive timeout after its unpublished temporary is removed permits retry.
  Receive uses bounded idle/total input deadlines, never an unbounded EOF read.

## Delivery

Completion includes the original units,28 O_fit/selection/diagnostic tails,
4 application checks/SHAP summaries, and automatic small-report collection by
next. Report numerical estimability separately. Do not copy final models again
to aggregate reports. Collect only missing pinned report members after interruption.

Freeze one commit and source package with dependency pins, configuration,
commands, reuse/retention rules and actual check evidence. Do not claim Linux
or full scientific completion without the corresponding real results. Old
source/history is in Git and is not a new-run dependency or deployment target.

Deploy H01 first, then at most three hosts concurrently. Software/install cache
is on the system disk; calculation/data/tmp/cache are on the data disk, with at
least 4 GiB system free space even at peak. H05/H6 is westb:31044; never connect
the released westb:48482. H04/H5 is unchanged. No credentials in source bundles.
After all seven pass and no human pause remains, use the existing authorized Machine Learning execution
chat with gpt-6.1-sol / max and its 90-minute inline status heartbeat; do not
create another dispatcher or duplicate chat. This chat owns
causal bug fixes; the execution chat is the single formal dispatch owner.
Both local dispatcher and remote workers run from the same pinned immutable
release, never the editable checkout. A source-only causal repair may add a new
release without changing live owners, runtime/configuration or the code symlink;
observe recognized predecessor owners until they exit, then refill from the new release.
An explicit immediate pause overrides refilling. Static deployment never clears
an owner lock or authorizes recovery; absent owners with unresolved records remain
UNKNOWN until the existing owner-resolution procedure is explicitly authorized.

安装资格登记源码与原生实体；仅有已锁定同名源码的Python生成字节码缓存可从安装清单排除，并以实际新SHA登记清单。Python/Numba计算缓存指向数据盘，wrapper、reexec及子进程保持同一缓存环境，首次源码/原生字节和真实加载检查不得跳过。

本次评价追加结果的 point、逐 B 和最终头必须分别保存已审核的 run/source 生产者。部分恢复也核对原生产者，不能只在最终头重新署名；合法前驱无需重算。已完成 EVALUATION 只从原回执 pin 对应的唯一 result.zip 读取输入和预测；残留独立副本不参加新评价。selection 的报告主键保留方法、袋内/袋外及同 B 配对差坐标；不得以两端区间相减代替配对区间。

### Conditional OSS rebuild (2026-10-09)

The user's current authorization replaces the earlier indefinite archive pause only
when required repair, calculations, fixed research, real report consumption and
final cross-audit are accepted. Until then archive-mode remains paused. Statistical
method rejection is an explicit conclusion, not numerical success.

Only the contents of `/Volumes/My Passport/Machine Learning 2` may be cleared,
once, after exact volume UUID/path, complete recoverable sources, real OSS
upload/download/resume/delete probe, cost/funding and quiescent readers pass.
Persist PREPARED→CLEARING→CLEARED outside that directory. Recovery of CLEARED
must never delete new-generation content. A wrong CLI root must fail before any
mutation. Do not erase the rest of the external volume or the OSS bucket.
The user's later explicit instruction authorizes transfer before topping up OSS.
Record that authority against this archive generation; preserve the known cash
balance separately and never report a promised top-up as credited money.
Old controller final-review members without remote sources are preserved by their
original pins outside the cleared root, then published under their original archive
names. Missing scientific members still block deletion; an old review is not dropped.

Use the existing IO pool and exact requests: seven independent remote uploaders,
two local large writes, one persistent producer per physical object, and bounded
stdin. Signed object capabilities travel only by private stdin; credentials stay
in Keychain. Use OSS V4 with exact object/query scope for upload, resume and
environment retrieval. The explicitly authorized bucket-level ListMultipartUploads
grant exposes multipart metadata only; this API has no prefix condition. Keep
ListObjects and all object reads/writes/deletes under their separate exact prefixes.
New relay generation enters inventories/indexes/ACKs. Window ACKs
alone do not retire original remote sources. Preserve partials, reconcile UNKNOWN,
and publish byte-qualified locations before making a transfer reusable.

Clear only this relay prefix after four new durable window receipts and a real
network-disabled offline numerical report. Keep environment objects in a distinct
private encrypted prefix without ordinary DeleteObject authorization. Environment
completion requires actual OSS roundtrip and H01 isolated chroot native consumption,
not successful tar creation or library import alone. Runtime/install layers remain
on the system disk, retain at least 4 GiB free, exclude credentials and clinical
results, and use their actual new SHA. Computation/data/caches remain on the data disk.
The independent system-Python restore requires no old run or runtime. Exact
isolated OS closure and compatible live-host installation are distinct: live
installation must preserve existing non-PADML OS files/permissions and record
actual loader checks, never overwrite host caches/configuration. Accepted and
retired test roots are not recreated to recover a lost final receipt.
