from __future__ import annotations

from .runtime import MIN_WORKER_MEMORY_BYTES

from .carriers import open_carrier

import argparse
import json
import os
import shutil
import tempfile
from pathlib import Path
from typing import Any, Mapping

from .bundle import (
    ContractError,
    canonical_json_bytes,
    execution_result_contract,
    read_safe_zip,
    sha256_bytes,
    sha256_file,
    strict_json_bytes,
    validate_envelope,
    validate_sha256,
    write_deterministic_zip,
)
from .capsule import expected_f2_model_input, load_capsule
from .f2_kernel import execute_model, execute_p2c2t
from .f2_validation import admitted_source_record, validate_f2_unit_result
from .runtime import R_LIBRARY, THREAD_ENV, resolve_pool_workers


def _require(condition: bool, reason: str) -> None:
    if not condition:
        raise ContractError(reason)


def _write_result(
    request: Mapping[str, Any], target: Path, value: Mapping[str, Any]
) -> dict[str, Any]:
    payload = canonical_json_bytes(dict(value))
    expected = request["artifacts"][0]
    artifact = {
        **expected,
        "size_bytes": len(payload),
        "sha256": sha256_bytes(payload),
        "status": "OK",
    }
    envelope = validate_envelope(
        {
            **dict(request),
            "kind": "result",
            "artifacts": [artifact],
            "terminal": {
                "status": "COMPLETED",
                "reason_code": "OK",
                "message_sha256": None,
            },
            "decision": None,
        }
    )
    write_deterministic_zip(
        target,
        {
            "manifest.json": canonical_json_bytes(envelope),
            artifact["relative_path"]: payload,
        },
    )
    os.chmod(target, 0o600)
    return {
        "status": "COMPLETED",
        "unit_id": request["unit_id"],
        "sha256": sha256_file(target),
        "size_bytes": target.stat().st_size,
    }


class _Dependencies:
    def __init__(self, capsule: Mapping[str, Any], result_root: Path) -> None:
        self.capsule = capsule
        self.result_root = result_root
        self.cache: dict[str, dict[str, Any]] = {}

    def load(self, unit_id: str) -> dict[str, Any]:
        if unit_id in self.cache:
            return self.cache[unit_id]
        request = self.capsule["requests"][unit_id]
        sources = {
            dependency: admitted_source_record(self.load(dependency))
            for dependency in request["plan"]["depends_on"]
        }
        values = {
            dependency: self.load(dependency)["value"]
            for dependency in request["plan"]["depends_on"]
        }
        result = validate_f2_unit_result(
            request,
            self.result_root / f"{unit_id}.zip",
            self.capsule["authority_slice"],
            route_profiles=self.capsule["manifest"]["identity_records"][
                "execution_plan"
            ]["route_profiles"],
            admitted_sources=sources,
            admitted_values=values,
            expected_model_input=expected_f2_model_input(self.capsule, unit_id),
            expected_selector_search=self.capsule["manifest"].get("selector_search_reuse", {}).get(unit_id),
            expected_selector_primary=self.capsule["manifest"].get("selector_primary_reuse", {}).get(unit_id),
            expected_selector_result=self.capsule["manifest"].get("selector_result_reuse", {}).get(unit_id),
            authority_mode="REMOTE_CANDIDATE",
        )
        _require(
            result["status"] == "CANDIDATE_VALID",
            f"F2_DEPENDENCY_INVALID:{unit_id}",
        )
        _require(result["value"].get("fpm_fixed_reuse")
                 == self.capsule["manifest"].get("fpm_fixed_reuse", {}).get(unit_id),
                 "F2_FPM_REUSE_SOURCE_INVALID")
        self.cache[unit_id] = result
        return result


def execute(
    capsule_path: Path,
    common_input_path: Path,
    unit_id: str,
    result_path: Path,
    *, reuse_non_fpm: Path | None = None,
    reuse_fpm: Path | None = None,
) -> dict[str, Any]:
    _require(
        capsule_path.is_absolute()
        and common_input_path.is_absolute()
        and result_path.is_absolute()
        and result_path.parent.is_dir()
        and not result_path.exists(),
        "F2_WORKER_PATH_INVALID",
    )
    capsule = load_capsule(capsule_path, common_input_path)
    _require(unit_id in capsule["requests"], "F2_WORKER_UNIT_UNKNOWN")
    _require(unit_id not in capsule["manifest"].get("selector_result_reuse", {}),
             "F2_SELECTOR_RESULT_REUSE_MUST_NOT_REFIT")
    request = capsule["requests"][unit_id]
    fpm_source = capsule["manifest"].get("fpm_fixed_reuse", {}).get(unit_id)
    _require((fpm_source is None) == (reuse_fpm is None), "F2_FPM_REUSE_SOURCE_REQUIRED")
    retained_fpm = None
    if reuse_fpm is not None:
        _require(reuse_fpm.is_absolute() and reuse_fpm.is_file() and not reuse_fpm.is_symlink()
                 and reuse_fpm.stat().st_size == fpm_source["size_bytes"]
                 and sha256_file(reuse_fpm) == fpm_source["sha256"], "F2_FPM_REUSE_SOURCE_INVALID")
        retained_fpm = read_safe_zip(reuse_fpm)
        if request["plan"]["action"] == "MODEL_DEVELOPMENT":
            original = strict_json_bytes(retained_fpm["original-request.json"])
            _require(strict_json_bytes(retained_fpm["original-task.json"])["task_id"]
                     == fpm_source["task_id"], "F2_FPM_REUSE_TASK_INVALID")
            _require(all(original[key] == request[key] for key in
                         ("run_id", "stage_id", "unit_id", "seed", "plan")),
                     "F2_FPM_REUSE_REQUEST_MISMATCH")
            _require(any(row == {"axis": "family", "value": "FPM_TVC_SET_A"}
                         for row in request["plan"]["coordinates"]), "F2_FPM_REUSE_SCOPE_INVALID")
        else:
            _require(unit_id in {"p2c2t-center-blocked-stress",
                                "p2c2t-locked-model-sample-size-diagnostic"},
                     "F2_FPM_REUSE_SCOPE_INVALID")
            _require(strict_json_bytes(retained_fpm["fixed-task.json"])["task_id"]
                     == fpm_source["task_id"], "F2_FPM_REUSE_TASK_INVALID")
    if request["plan"]["action"] in {"MODEL_DEVELOPMENT", "P2C2T"}:
        resolve_pool_workers(request["plan"]["internal_threads"])
    _require(
        os.environ.get("PADML_WORKER_SHA256")
        == request["identities"]["worker"],
        "F2_WORKER_ARCHIVE_IDENTITY_INVALID",
    )
    dependencies = _Dependencies(capsule, result_path.parent)
    dependency_ids = request["plan"]["depends_on"]
    with tempfile.TemporaryDirectory(
        prefix=f".{unit_id}-", dir=result_path.parent, delete=False
    ) as temporary:
        scratch = Path(temporary).resolve()
        action = request["plan"]["action"]
        _require(reuse_non_fpm is None or action == "P2C2T", "F2_P2C2T_REUSE_ACTION_INVALID")
        if action == "MODEL_DEVELOPMENT":
            selector = (
                dependencies.load(dependency_ids[0])["value"]
                if dependency_ids
                else None
            )
            value = execute_model(
                capsule_path, capsule, request, scratch, selector,
                cache_root=result_path.parent.parent / "split-cache",
                checkpoint_root=result_path.parent,
                retained_fpm=retained_fpm,
            )
        else:
            _require(action == "P2C2T", "F2_WORKER_ACTION_INVALID")
            retained = None
            if reuse_non_fpm is not None:
                entries = read_safe_zip(reuse_non_fpm)
                old_envelope = validate_envelope(strict_json_bytes(entries["manifest.json"]))
                artifact = old_envelope["artifacts"][0]
                payload = entries[artifact["relative_path"]]
                _require(old_envelope["kind"] == "result" and old_envelope["unit_id"] == unit_id
                         and old_envelope["run_id"] == request["run_id"]
                         and old_envelope["terminal"]["status"] == "COMPLETED"
                         and len(payload) == artifact["size_bytes"]
                         and sha256_bytes(payload) == artifact["sha256"], "F2_P2C2T_REUSE_SOURCE_INVALID")
                retained = strict_json_bytes(payload)
            component = next(
                row["value"]
                for row in request["plan"]["coordinates"]
                if row["axis"] == "component"
            )
            value = execute_p2c2t(
                capsule_path,
                capsule,
                component,
                [dependencies.load(item)["value"] for item in dependency_ids],
                request,
                scratch,
                cache_root=result_path.parent.parent / "split-cache",
                reuse_non_fpm=retained,
                retained_fpm=retained_fpm,
                checkpoint_root=result_path.parent,
            )
        value = {
            **value,
            **execution_result_contract(request["plan"]),
            "consumed_sources": [
                admitted_source_record(dependencies.load(item))
                for item in dependency_ids
            ],
        }
        if fpm_source is not None:
            value["fpm_fixed_reuse"] = dict(fpm_source)
        if action == "P2C2T":
            value["result_identity_sha256"] = sha256_bytes(canonical_json_bytes({
                key: item for key, item in value.items() if key != "result_identity_sha256"
            }))
        result = _write_result(request, result_path, value)
        shutil.rmtree(scratch)
        return result



def _f45_write(path: Path, value: Mapping[str, Any]) -> None:
    from .nested_loco import _write_exact_once
    _write_exact_once(path, canonical_json_bytes(value), "F45_COMPLETED_VALUE_DRIFT")


def _f45_read(path: Path) -> dict[str, Any]:
    return strict_json_bytes(path.read_bytes())


def _f45_compile_archive(target: Path, compiler) -> dict[str, Any]:
    """Retain the original compiler return; recover only a missing publication tail."""
    record = target.with_suffix(".compile.json")
    if record.is_file():
        value = _f45_read(record)
        _require(target.is_file(), "F45_COMPILED_INPUT_MISSING")
        return value
    if target.exists():
        with tempfile.TemporaryDirectory(prefix="compile-recover-", dir=target.parent) as name:
            retry = Path(name) / target.name
            value = compiler(retry)
            _require(sha256_file(retry) == sha256_file(target), "F45_COMPILED_INPUT_DRIFT")
    else:
        value = compiler(target)
    _f45_write(record, value)
    return value


def _f45_raw_inputs(run: Mapping[str, Any], root: Path) -> tuple[Path, Path]:
    from .integrated import is_integrated, ensure_raw_binding
    if is_integrated(run):
        binding = ensure_raw_binding(run)
        return binding["root"] / "covariates.csv", binding["root"] / "response-seal.csv"
    from .f1_contract import load_f1_input_manifest
    from .f4 import _load_o_fit_frozen_source
    from .nested_loco import _write_exact_once
    from .run import _load_replay
    f1 = Path(run["f1_runtime_root"])
    root.mkdir(mode=0o700, parents=True, exist_ok=True)
    manifest = load_f1_input_manifest(f1 / "input/f1/input-manifest.json")
    replay = _load_replay(f1 / "build/f1-replay-seal.zip", f1 / "build/common-input.zip", manifest)
    frozen = _load_o_fit_frozen_source(f1, manifest, replay, [])
    covariates, response = root / "covariates.csv", root / "response.csv"
    _write_exact_once(covariates, frozen["covariates_csv"], "F45_F1_RAW_INPUT_DRIFT")
    _write_exact_once(response, frozen["response_csv"], "F45_F1_RAW_INPUT_DRIFT")
    return covariates, response


def _f45_release(root, stage, *completed):
    from .runtime import release_f45_cumulative_files
    report = release_f45_cumulative_files(completed, owner=stage, report_root=root,
        released_references=["returned_stage_call"])
    return report


def _f45_primary(run, unit, root, context):
    from .integrated import is_integrated, execute_primary
    if is_integrated(run):
        return execute_primary(run, unit, root, context)
    from . import f4, f5, nested_loco as nested
    from .runtime import observe_execution_resources, resource_admission
    policy, budgets = run["resource_policy"], run["budgets"]
    outer, h = unit["outer_fold"], unit["horizon"]
    f1, f2 = Path(run["f1_runtime_root"]), Path(run["f2_run_root"])
    compiler_args = {"outer_fold": outer, "science_decision": nested.science_decision_template(24),
        "resource_policy": policy, "f1_runtime_root": f1,
        **{name: budgets[name] for name in ("retained_bytes_per_component", "expanded_bytes_per_component", "shared_storage_bytes")}}
    presearch = context / "primary-pre-search.zip"
    _f45_compile_archive(presearch, lambda target: f4.compile_o_fit_bundle(f2, target, pre_search=True, **compiler_args))
    searches = {}
    primary_selector = None
    selector_root = root / "selector-h36" if h == 36 else None
    def admit_io(*, memory_bytes=0, pending_bytes=0):
        observation = observe_execution_resources(context)
        _require(observation["scratch_available_bytes"] >= pending_bytes, "F45_IO_SPACE_INSUFFICIENT")
        return resource_admission({**policy, "scratch_reserve_bytes": 0,
            "memory_reserve_bytes": policy["memory_reserve_bytes"] + memory_bytes}, observation, legal_tasks=1)
    if h != 24:
        with tempfile.TemporaryDirectory(prefix="primary-training-inputs-", dir=context) as name:
            opened = f4._materialize_o_fit_input_bundle(presearch, Path(name) / "inputs", pre_search=True, admit_io=admit_io)
            state = opened["materialized_pre_search"]
            if h == 36:
                admission = resource_admission({**policy, "memory_bytes_per_worker": MIN_WORKER_MEMORY_BYTES},
                    observe_execution_resources(root), legal_tasks=320)
                primary_selector = f5._primary_selector_program(state, selector_root,
                    replay=(selector_root / "development-input.json").is_file(),
                    workers=admission["admitted_worker_ceiling"], resource_policy=policy)
                _f45_release(root, "PRIMARY_H36_SELECTOR", selector_root)
            search_root = root / ("search-h36-exclude55" if h == 36 else "search")
            search_root.mkdir(mode=0o700, exist_ok=True)
            for family in ("RSF", "GBM_COX", "XGBOOST_COX", "COXTIME_SET_A"):
                searches[family] = f5._prepare_primary_outer_rsf_search(
                    f4._primary_pre_search_family_projection(state, family, primary_selector=primary_selector), search_root / family, policy,
                    retained_bytes_per_task=budgets["retained_bytes_per_q_task"], admit_io=admit_io,
                    family=family, selection_horizon_months=h,
                    source_registered_identity=state["source_registered_identity"])
                _f45_release(root, "PRIMARY_SEARCH:" + family, search_root / family)
    source, result = root / "input.zip", root / "result.zip"
    compiled = _f45_compile_archive(source, lambda target: f4.compile_o_fit_bundle(None, target,
        pre_search_input=presearch, selection_horizon_months=h, primary_searches=searches or None,
        primary_selector_root=selector_root,
        **{**compiler_args, "f1_runtime_root": None, "science_decision": nested.science_decision_template(h)}))
    if not result.is_file():
        f4.execute_o_fit_bundle(input_bundle=source, target=result, outer_fold=outer,
            completed_score_units=_f45_score_reuse_candidates(run, unit))
    consumed = f4.load_o_fit_execution_archive(result, input_bundle=source, compiled_input_record=compiled,
        f2_run_root=f2, f1_runtime_root=f1)
    _require(consumed.get("outer_fold", outer) == outer, "F45_PRIMARY_CONSUMER_OUTER_MISMATCH")
    del consumed
    _f45_release(root, "PRIMARY_M20_CONSUMED", source, result)
    return [source, source.with_suffix(".compile.json"), result]


def _f45_score_reuse_candidates(run, unit):
    """Discover complete units; the native score reader verifies artifact bytes."""
    from .run import f45_unit_predecessors
    _require(unit["kind"] in {"PRIMARY", "FULL0"}, "F45_SCORE_REUSE_WHOLE_REQUIRED")
    generations = [run, *f45_unit_predecessors(run)]
    identities = {row["identity"] for row in generations}
    h36_runs = {row["identity"] for row in generations if "amendment_20260928" in row["science_decision"]}
    candidates = []
    for previous in sorted(run["units"], key=lambda row: row["horizon"]):
        if (previous["kind"] != unit["kind"] or previous["context"] != unit["context"]
                or previous["unit_id"] == unit["unit_id"]):
            continue
        root = Path(run["run_root"]) / "units" / previous["unit_id"]
        if not (root / "unit.json").is_file():
            continue
        receipt = _f45_read(root / "unit.json")
        _require(receipt.get("status") == "COMPLETED" and receipt.get("direct_consumer_completed") is True
            and receipt.get("unit_id") == previous["unit_id"] and receipt.get("run_identity") in identities
            and receipt.get("selection_horizon_months") == previous["horizon"]
            and receipt.get("report_horizons_months") == [6, 12, 24, 36],
            "F45_SCORE_REUSE_WHOLE_REQUIRED")
        if previous["horizon"] == 36 and receipt["run_identity"] not in h36_runs:
            continue
        candidates.append({"root": str(root), "receipt": receipt})
    return candidates


def _f45_file_group_read_job(job):
    results = []
    for name, path, expected in job["members"]:
        _require(path.is_file(), job["failure"])
        pin = {"sha256": sha256_file(path), "size_bytes": path.stat().st_size}
        _require(expected is None or pin == expected, job["failure"])
        results.append((name, pin))
    return results


def _f45_archive_group_read_job(job):
    import hashlib
    import zipfile
    with open_carrier(job["archive"]) as archive:
        for name, pin in job["members"]:
            if name in archive.references:
                _require({k:archive.references[name][k] for k in ("sha256","size_bytes")} == pin, "F45_FULL0_SCORE_ARCHIVE_DRIFT")
                archive.external_path(name)
                continue
            digest = hashlib.sha256()
            _require(archive.getinfo(name).file_size == pin["size_bytes"], "F45_FULL0_SCORE_ARCHIVE_DRIFT")
            with archive.open(name) as stream:
                for chunk in iter(lambda: stream.read(1024 * 1024), b""):
                    digest.update(chunk)
            _require(digest.hexdigest() == pin["sha256"], "F45_FULL0_SCORE_ARCHIVE_DRIFT")
    return True


def _f45_file_pins(members, *, policy, root, expected=None, failure="F45_COMPLETED_ARTIFACT_DRIFT"):
    from .runtime import _readback_ordered, resolve_pool_workers
    if not members:
        return {}
    from .carriers import run_context
    current = run_context()
    if current is not None:
        from .integrated import qualified_file_pins
        result = qualified_file_pins(members, identity=current["source_identity"], expected=expected,
            record=root / ("file-qualification-" + sha256_bytes(canonical_json_bytes(sorted(members))) + ".json"))
        from .runtime import advise_completed_io
        advise_completed_io(members.values())
        return result
    count = min(len(members), resolve_pool_workers(None))
    groups, sizes = [[] for _ in range(count)], [0] * count
    for name, path in sorted(members.items(), key=lambda row: (-row[1].stat().st_size, row[0])):
        index = min(range(count), key=lambda i: (sizes[i], i))
        groups[index].append((name, path, None if expected is None else expected[name]))
        sizes[index] += path.stat().st_size
    results = _readback_ordered(_f45_file_group_read_job,
        [{"members": group, "failure": failure} for group in groups], policy=policy, root=root,
        retained_bytes=4096 * len(members), cache_files=members.values())
    pins = dict(row for group in results for row in group)
    return {name: pins[name] for name in members}


def _f45_full0_score_archive(root, run):
    """Carry original pre-lock numbers as part of the completed FULL0 unit."""
    import zipfile
    from . import f5, nested_loco as nested
    from .runtime import observe_execution_resources, resource_admission

    score_root = root / "score"
    request = _f45_read(score_root / "request/full-score-input.json")
    scores = _f45_read(score_root / "full-score-result.json")
    final_input = _f45_read(root / "final-input/full-final-input.json")
    _require(request["identity_sha256"] == scores["request_identity_sha256"]
        and request["training_context"]["scope"] == "FULL_DATA"
        and scores["identity_sha256"] == nested._sha({k: v for k, v in scores.items() if k != "identity_sha256"})
        and final_input.get("kind") == "PADML_NESTED_FULL_FINAL_INPUT_V1"
        and final_input.get("identity_sha256") == nested._sha({k: v for k, v in final_input.items() if k != "identity_sha256"})
        and final_input.get("selection_horizon_months") == request["selection_horizon_months"]
        and final_input.get("score_request_identity_sha256") == request["identity_sha256"]
        and final_input.get("score_result_identity_sha256") == scores["identity_sha256"],
        "F45_FULL0_SCORE_ARCHIVE_INVALID")
    members = {"request.json": score_root / "request/full-score-input.json",
               "scores.json": score_root / "full-score-result.json"}
    members.update({row["path"]: score_root / "request" / row["path"] for row in request["component_records"]})
    for execution in scores["fresh_score_execution"]:
        nested.validate_fresh_score_execution(execution)
        members.update({row["path"]: score_root / row["path"] for row in execution["component_evidence_records"]})
    members.update({name: score_root / name for name in f5._f45_score_reuse_members(scores["fresh_score_execution"])})
    _require(all(path.is_file() and path.resolve(strict=True) == path for path in members.values()),
             "F45_FULL0_SCORE_ARCHIVE_INVALID")
    metadata = nested._sealed({"kind": "PADML_F45_FULL0_SCORE_ARCHIVE_V1",
        "request_identity_sha256": request["identity_sha256"],
        "score_result_identity_sha256": scores["identity_sha256"],
        "final_input": final_input,
        "selection_horizon_months": request["selection_horizon_months"],
        "members": _f45_file_pins(dict(sorted(members.items())), policy=run["resource_policy"], root=root)})
    encoded = canonical_json_bytes(metadata)
    archive_path = root / "score.zip"
    if not archive_path.exists():
        from .integrated import is_integrated
        compact = is_integrated(run)
        pending = len(encoded) + (0 if compact else sum(path.stat().st_size for path in members.values())) + 4096 * (len(members) + 1)
        policy = run["resource_policy"]
        observation = observe_execution_resources(root)
        _require(observation["scratch_available_bytes"] >= pending, "F45_FULL0_SCORE_ARCHIVE_SPACE_INSUFFICIENT")
        resource_admission({**policy, "scratch_reserve_bytes": 0,
            "memory_reserve_bytes": policy["memory_reserve_bytes"] + 32 * len(encoded)}, observation, legal_tasks=1)
        if compact:
            from .carriers import write_carrier
            write_carrier(archive_path, {"score-archive.json": encoded}, references=members, run=run)
        else:
            write_deterministic_zip(archive_path, {"score-archive.json": encoded, **members}, stored_members=set(members))
    _require(archive_path.is_file() and not archive_path.is_symlink(), "F45_FULL0_SCORE_ARCHIVE_INVALID")
    with open_carrier(archive_path) as archive:
        names = archive.namelist()
        _require(len(names) == len(set(names)) and set(names) == {"score-archive.json", *members}
            and archive.read("score-archive.json") == encoded, "F45_FULL0_SCORE_ARCHIVE_DRIFT")
    from .runtime import _readback_ordered, resolve_pool_workers
    count = min(len(members), resolve_pool_workers(None))
    groups, sizes = [[] for _ in range(count)], [0] * count
    for name, pin in sorted(metadata["members"].items(), key=lambda row: (-row[1]["size_bytes"], row[0])):
        index = min(range(count), key=lambda i: (sizes[i], i))
        groups[index].append((name, pin))
        sizes[index] += pin["size_bytes"]
    _readback_ordered(_f45_archive_group_read_job,
        [{"archive": archive_path, "members": group} for group in groups],
        policy=run["resource_policy"], root=root, per_worker_bytes=4096 * len(members) + 2 * 1024**2,
        retained_bytes=32 * len(encoded), cache_files=[archive_path])
    return archive_path


def _f45_aar_reuse_candidates(run, unit):
    """Only byte-verified, consumed whole AAR units from this run/outer."""
    from .run import f45_unit_predecessors
    from .f5_sensitivity import _validate_a12_whole_artifacts
    generations = [run, *f45_unit_predecessors(run)]
    identities = {row["identity"] for row in generations}
    h36_runs = {row["identity"] for row in generations if "amendment_20260928" in row["science_decision"]}
    candidates = []
    for previous in sorted(run["units"], key=lambda row: row["horizon"]):
        if (previous["kind"] != "AAR" or previous["outer_fold"] != unit["outer_fold"]
                or previous["unit_id"] == unit["unit_id"]):
            continue
        root = Path(run["run_root"]) / "units" / previous["unit_id"]
        if not (root / "unit.json").is_file():
            continue
        receipt = _f45_read(root / "unit.json")
        _validate_a12_whole_artifacts(receipt.get("artifacts", {}))
        _require(receipt.get("status") == "COMPLETED" and receipt.get("direct_consumer_completed") is True
            and receipt.get("run_identity") in identities and receipt.get("unit_id") == previous["unit_id"]
            and receipt.get("selection_horizon_months") == previous["horizon"]
            and receipt.get("report_horizons_months") == [6, 12, 24, 36],
            "F45_AAR_REUSE_WHOLE_REQUIRED")
        if previous["horizon"] == 36 and receipt["run_identity"] not in h36_runs:
            continue
        for name, pin in receipt["artifacts"].items():
            path = root / name
            _require(not root.is_symlink() and path.is_file() and not path.is_symlink()
                and path.resolve(strict=True) == path
                and path.stat().st_size == pin["size_bytes"] and sha256_file(path) == pin["sha256"],
                "F45_AAR_REUSE_ARTIFACT_DRIFT")
        candidates.append({"root": str(root), "receipt": receipt})
    return candidates


def _f45_aar(run, unit, root, context):
    from . import f5_sensitivity as a
    primary = Path(run["run_root"]) / "units" / unit["depends_on"][0]
    source, mice, result = root / "input.zip", root / "mice.zip", root / "result.zip"
    if run.get("kind") == "PADML_INTEGRATED_RAW_RUN_V1":
        from .integrated import prepare_primary_context
        _require((context / "primary-context.json").is_file(), "RAW_AAR_CONTEXT_TRANSFER_REQUIRED")
        _f45_compile_archive(source, lambda target: a.compile_a12_outer_inputs(primary / "input.zip",
            primary / "result.zip", target, outer_fold=unit["outer_fold"], resource_policy=run["resource_policy"],
            compiled_input_record=_f45_read(primary / "input.compile.json"),
            current_raw={"run": run, "state": prepare_primary_context(run, unit["outer_fold"], context)}))
    else:
        _f45_compile_archive(source, lambda target: a.compile_a12_outer_inputs(primary / "input.zip",
            primary / "result.zip", target, f2_run_root=Path(run["f2_run_root"]), outer_fold=unit["outer_fold"],
            resource_policy=run["resource_policy"], f1_runtime_root=Path(run["f1_runtime_root"]),
            compiled_input_record=_f45_read(primary / "input.compile.json")))
    reusable = _f45_aar_reuse_candidates(run, unit) if not result.is_file() else []
    completed_raw = os.environ.get("PADML_F45_COMPLETED_AAR_REPLAY")
    completed_replay = strict_json_bytes(completed_raw.encode()) if completed_raw is not None else None
    _require(completed_raw is None or isinstance(completed_replay, Mapping), "F45_AAR_COMPLETED_PIN_REQUIRED")
    _require(completed_replay is None or result.is_file(), "F45_AAR_COMPLETED_RESULT_REQUIRED")
    if result.is_file():
        _require(mice.is_file(), "F45_AAR_COMPLETED_MICE_REQUIRED")
    elif not mice.is_file():
        a.execute_a12_outer_inputs(source, mice, retained_bytes_per_view=run["budgets"]["retained_bytes_per_view"],
            completed_aar_units=reusable)
    if not result.is_file():
        _f45_release(root, "AAR_MICE", mice)
        a.execute_a12_outer_bundle(mice, result, input_bundle=source,
            retained_bytes_per_component=run["budgets"]["retained_bytes_per_component"],
            completed_aar_units=reusable)
    a._load_a12_outer_archive(result, input_bundle=source, completed_replay=completed_replay)
    _f45_release(root, "AAR_THREE_BRANCHES_CONSUMED", source, mice, result)
    from .integrated import is_integrated
    retained = ([mice, *sorted((root / "result.zip.work/fits").glob("*.zip"))] if is_integrated(run) else [])
    return [source, source.with_suffix(".compile.json"), result, *retained] + (
        [Path(completed_replay["path"])] if completed_replay is not None else [])


def _f45_full0(run, unit, root, context):
    from . import f5, f5_application, nested_loco as nested
    from .run import _f45_worker_memory_revision
    h, policy, budgets = unit["horizon"], run["resource_policy"], run["budgets"]
    common = context / "common"
    shared = common / "full-development.json"
    if not shared.is_file():
        covariates, response = _f45_raw_inputs(run, context / "raw")
        f5.compile_full_data_development_inputs(covariates, response, common,
            science_decision=nested.science_decision_template(24), resource_policy=policy,
            **({"raw_binding_root": covariates.parent} if run.get("kind") == "PADML_INTEGRATED_RAW_RUN_V1"
               else {"f1_runtime_root": Path(run["f1_runtime_root"])}), selection_horizon_months=24,
            **{name: budgets[name] for name in ("retained_bytes_per_view", "retained_bytes_per_component",
                                              "expanded_bytes_per_component", "shared_storage_bytes")})
    sources = _f45_read(shared)
    _require(nested.compatible_science_decisions(sources["science_decision"], nested.science_decision_template(24))
        and (sources["resource_policy"] == policy
             or run.get("kind") == "PADML_INTEGRATED_RAW_RUN_V1"
             and _f45_worker_memory_revision(sources["resource_policy"], policy)),
        "F45_FULL0_PREPARATION_DRIFT")
    tasks = [*f5.compile_full_data_search_mice_tasks(sources["plan"]),
             f5.compile_final_full_data_mice_task(sources["plan"])]
    mice_results = f5.execute_full_data_mice_batch(shared, common / "mice-execution",
        view_ids=[task["view_id"] for task in tasks], selection_horizon_months=24)
    mice_files = [Path(sources['final_mice_path']) if task['phase'] == 'FINAL_MICE' else
        Path(sources['mice_root']) / task['split_id'] / (task['role'].lower()+'.zip') for task in tasks]
    mice_files.extend(Path(row['native_archive_path']) for row in mice_results['results']
        if 'native_archive_path' in row)
    _f45_release(root, "FULL0_MICE", *mice_files)
    del mice_results
    if h == 36:
        sources["selector_root"] = str(root / "selector-h36")
    (root / "search").mkdir(mode=0o700, exist_ok=True)
    source = root / "full-development.json"
    science = (_f45_read(source)["science_decision"] if source.is_file() else nested.science_decision_template(h))
    nested.validate_science_decision(science, selection_horizon_months=h)
    sources.update(selection_horizon_months=h, science_decision=science,
        shared_storage_bytes=budgets["shared_storage_bytes"], score_root=str(root / "score"),
        search_roots={family: str(root / "search" / family) for family in sources["search_roots"]})
    _f45_write(source, sources)
    inputs, outputs = root / "final-input", root / "final-result"
    compiled_path = root / "final.compile.json"
    # One physical MICE materialization spans selector, Q, scoring and final input compilation.
    with f5._materialized_full_data_development_sources(source, root,
            selection_horizon_months=h) as prepared:
        sources, partitions, full = prepared
        development = f5._nested_full_selector_program(sources["plan"], partitions, full, Path(sources["selector_root"]),
            rscript=sources["rscript"], replay=(Path(sources["selector_root"]) / "development-input.json").is_file(),
            resource_policy=policy, selection_horizon_months=h)
        if development["selector"].get("status") == "NOT_ESTIMABLE":
            from .integrated import publish_unit_not_estimable
            return publish_unit_not_estimable(run, unit, root, development=development,
                selector_root=Path(sources["selector_root"]))
        if (development["selector"]["epv_resolution"].get("frequency_policy_sha256") is not None
                and sources["science_decision"] != nested.science_decision_template(h)):
            # The old preparation predates the observed-failure amendment.
            # Preserve it; only this small scientific input gains the new rule.
            sources = {**sources, "science_decision": nested.science_decision_template(h)}
            source = root / "full-development.frequency.json"
            _f45_write(source, sources)
            prepared = (sources, partitions, full)
        from .runtime import run_ready_families
        families = ("RSF", "GBM_COX", "XGBOOST_COX", "COXTIME_SET_A")
        # Selector replay touches one shared directory; finish it before threads start.
        search_tasks = {family: f5.compile_nested_full_complex_search_task(sources["plan"], partitions, full,
            Path(sources["selector_root"]), family=family, rscript=sources["rscript"],
            resource_policy=policy, selection_horizon_months=h, science_decision=sources["science_decision"])
            for family in families}
        run_ready_families([lambda family=family: f5._final_complex_search_program(
            search_tasks[family], partitions, Path(sources["search_roots"][family]), resource_policy=policy)
            for family in families], policy=policy, root=root)
        scored = f5._full_data_locked_score_program(sources["plan"], partitions, full,
            Path(sources["selector_root"]), {k: Path(v) for k, v in sources["search_roots"].items()},
            Path(sources["score_root"]), rscript=sources["rscript"], replay=False,
            resume=(root / "score").exists(), resource_policy=policy, selection_horizon_months=h,
            science_decision=sources["science_decision"], completed_score_units=_f45_score_reuse_candidates(run, unit),
            **{k: budgets[k] for k in ("retained_bytes_per_component", "expanded_bytes_per_component", "shared_storage_bytes")})
        if compiled_path.is_file():
            compiled = _f45_read(compiled_path)
        else:
            compiled = f5.compile_final_refit_bundles(full_development_path=source, target_root=inputs,
                selection_horizon_months=h, prepared_sources=prepared, consumed_scores=scored)
            _f45_write(compiled_path, compiled)
    # Native producers drain their already-read member indexes at publication.
    _f45_release(root, "FULL0_DEVELOPMENT", source, compiled_path)
    f5.execute_final_refit_batch(inputs, outputs, resource_policy=policy,
        compiled_input_record=compiled, selection_horizon_months=h,
        completed_final_units=_f45_score_reuse_candidates(run, unit))
    final_files = [outputs / f"F5_FINAL_FULL_DATA_M{i:02d}.zip" for i in range(1, 21)]
    _f45_release(root, "FULL0_FINAL_M20", *final_files)
    lineage = inputs / "lineage.json"
    non_ph, result = root / "non-ph.zip", root / "result.zip"
    response = Path(sources["response_path"])
    if not non_ph.is_file():
        f5.execute_non_ph_action(lineage, response, outputs, non_ph, input_root=inputs,
            resource_policy=policy, compiled_input_record=compiled)
    f5.execute_final_aggregate(lineage, response, outputs, non_ph, result, input_root=inputs,
        resource_policy=policy, compiled_input_record=compiled, selection_horizon_months=h, replay=result.is_file())
    _f45_release(root, "FULL0_DIAGNOSTICS_SHAP_AGGREGATE", *final_files, non_ph, result)
    application = root / "application.json"
    from .integrated import is_integrated
    if is_integrated(run):
        f5_application.run_application_self_check(run, unit, root, _f45_read(lineage), compiled, sources)
    else:
        models = f5_application.load_application_models(_f45_read(lineage), inputs, outputs, workers=None,
            resource_policy=policy, compiled_input_record=compiled, retain_objects=False)
        _require(len(models) == 20, "F45_FULL0_APPLICATION_M20_REQUIRED")
        del models
        _f45_release(root, "FULL0_APPLICATION_MODELS_CONSUMED", *final_files)
        application = root / "application.json"
        _f45_write(application, {"scope": "FULL_DATA_APPARENT_ONLY", "selection_horizon_months": h,
            "report_horizons_months": [6, 12, 24, 36], "model_count": 20,
            "reader": "padml.f5_application.load_application_models",
            "predictor": "padml.f5_application.predict_completed_application",
            "lineage": "final-input/lineage.json", "inputs": "final-input", "models": "final-result"})
    # Keep native M20 objects needed for actual downstream application; the aggregate is numerical.
    score_archive = _f45_full0_score_archive(root, run)
    return [result, non_ph, compiled_path, application, score_archive, *([root / "report-summary.json"] if (root / "report-summary.json").is_file() else []), *sorted((root / "application").glob("*.json")), *sorted(inputs.rglob("*.json")),
            *sorted(inputs.rglob("*.zip")), *sorted(outputs.glob("*.zip")), *sorted(outputs.glob("*.numbers.json")),
            *sorted((outputs / "shap-components").glob("F5_FINAL_AGGREGATE_SHAP_M*.zip")),
            *(outputs / name for name in sorted(f5._f45_full_final_reuse_members(outputs)))]


def _f45_resume_evaluation(run, unit, root, primary_roots, aar_roots, shared):
    """Consume retained first metric rows and source-bound CIs; never rerun metrics."""
    import hashlib
    import io
    import zipfile
    from . import f4, f5_sensitivity as a, nested_loco as n

    def read(archive, member):
        return strict_json_bytes(archive.read(member))

    def check_member(archive, member, pin):
        _require(archive.getinfo(member).file_size == pin["size_bytes"], "F45_EVALUATION_SOURCE_DRIFT")
        digest = hashlib.sha256()
        with archive.open(member) as stream:
            for chunk in iter(lambda: stream.read(1024**2), b""):
                digest.update(chunk)
        _require(digest.hexdigest() == pin["sha256"], "F45_EVALUATION_SOURCE_DRIFT")

    with open_carrier(root / "primary.zip") as primary_archive:
        primary_meta = read(primary_archive, "o-fit-aggregate.json")
    _require(primary_meta["kind"] == "PADML_F4_O_FIT_AGGREGATE_ARCHIVE_V4"
        and n._sealed({k: v for k, v in primary_meta.items() if k != "identity_sha256"}) == primary_meta,
        "F45_EVALUATION_PRIMARY_SOURCE_DRIFT")
    receipts = {o: _f45_read(p / "unit.json") for o, p in primary_roots.items()}
    for row in primary_meta["source_archives"]:
        _require({k: row[k] for k in ("sha256", "size_bytes")}
            == receipts[row["outer_fold"]]["artifacts"]["result.zip"], "F45_EVALUATION_PRIMARY_SOURCE_DRIFT")
    primary = primary_meta["selected_ooc"]
    sciences = [n._base_science_decision_template(unit["horizon"]), n.science_decision_template(unit["horizon"])]
    science = next((value for value in sciences if value["identity_sha256"] == primary["science_decision_sha256"]), None)
    _require(science is not None, "F45_EVALUATION_PRIMARY_SOURCE_DRIFT")
    source = {"kind": "PADML_F5_NESTED_AAR_PRIMARY_SOURCE_V1", "program_id": n.PROGRAM_ID,
        "primary_aggregate_sha256": sha256_file(root / "primary.zip"),
        "primary_aggregate_identity_sha256": primary_meta["identity_sha256"],
        "science_decision_sha256": science["identity_sha256"], "primary_ooc_sha256": primary["identity_sha256"],
        "primary_source_archives": primary_meta["source_archives"],
        "primary_input_sha256": {str(o): r["artifacts"]["input.zip"]["sha256"] for o, r in receipts.items()}}
    headers, records = [], []
    for p in aar_roots.values():
        with open_carrier(p / "result.zip") as archive:
            header = read(archive, "a12-outer.json")
        headers.append(header)
        records.append(a._a12_outer_archive_record(header, p / "result.zip"))
    with open_carrier(root / "result.zip") as archive:
        names = {"a12.json", "predictions.json", "aggregate-execution.json", "primary.zip",
            *(f"outer-o{o}.zip" for o in range(1, 7)),
            *(f"evaluation/{name}" for name in a._a12_evaluation_member_names(nested=True))}
        _require(len(archive.namelist()) == len(names) and set(archive.namelist()) == names,
                 "F45_EVALUATION_MEMBER_COVERAGE_INVALID")
        check_member(archive, "primary.zip", {"sha256": source["primary_aggregate_sha256"],
                                             "size_bytes": (root / "primary.zip").stat().st_size})
        for record in records:
            check_member(archive, record["member"], record)
        predictions, value = read(archive, "predictions.json"), read(archive, "a12.json")
        context = {"primary": primary, "population_registry": predictions["population_registry"],
            "science_decision": science, "source": source,
            "family_by_outer": {str(row["outer_fold"]): row["selected_family"] for row in primary["selection_by_outer"]}}
        _require(a._a12_handoff_from_outers(context, headers) == predictions,
                 "F45_EVALUATION_PREDICTION_SOURCE_DRIFT")
        handoff = a._validate_a12_handoff(predictions)
        _require(handoff["selection_horizon_months"] == unit["horizon"], "F45_EVALUATION_HORIZON_DRIFT")
        execution = read(archive, "evaluation/execution.json")
        aggregate = read(archive, "aggregate-execution.json")
        pool = execution["bootstrap_pool"]
        from .integrated import same_batch_generations
        _require(execution["executor_source_identity"] == aggregate["executor_source_identity"]
            and execution["executor_source_identity"] in same_batch_generations(run).values()
            and execution == value["evaluation_execution"] and pool["status"] == "COMPLETED"
            and pool["completed_task_count"] == pool["runnable_task_count"] == 1000,
            "F45_EVALUATION_EXECUTION_SOURCE_DRIFT")
        preparation = _f45_read(shared / "bootstrap-preparation.json")
        validate_sha256(preparation.get("f45_source_sha256"), "f45.bootstrap.original_producer")
        rng = archive.read("evaluation/rng.zip")
        _require(preparation["status"] == "PREPARED_SHARED_F45_DRAWS"
            and preparation["stage_acceptance"] is False and preparation["shared_rng_invocations"] == 1
            and preparation["new_model_fits"] == preparation["bootstrap_replicates_executed"] == 0
            and preparation["rng_archive"] == {"sha256": sha256_bytes(rng), "size_bytes": len(rng)}
            and sha256_file(shared / "bootstrap.zip") == preparation["rng_archive"]["sha256"],
            "F45_EVALUATION_SHARED_DRAWS_DRIFT")
        plan = f4.bootstrap_draws(handoff["patient_ids"], handoff["centers"], "FIXED_MODEL_PAIRED",
            replicate_count=1000, patient_keys=handoff["patient_keys"], replay_archive=rng)
        evaluation_handoff = {k: handoff[k] for k in ("patient_ids", "centers", "horizons", "survival")}
        evaluation_handoff.update(a._a12_evaluation_scope(handoff))
        evaluation_handoff.update(a._a12_evaluation_estimability(handoff))
        # Reuse the original binding constructor; only its response digest comes from
        # the already-consumed PRIMARY outcome join rather than a new response load.
        binding = a._a12_bootstrap_binding(evaluation_handoff, b"", plan)
        binding["response_sha256"] = primary_meta["evaluation"]["heldout_response_sha256"]
        _require(read(archive, "evaluation/plan.json") == {"source": binding, "plan": plan},
                 "F45_EVALUATION_PLAN_SOURCE_DRIFT")
        point = read(archive, "evaluation/point-evaluation.json")
        origin = read(archive, "evaluation/primary-point-evaluation.json")
        _require(origin == primary_meta["evaluation"]
            and point == a._merge_a12_point_evaluations(origin["evaluation"],
                read(archive, "evaluation/aar-point-evaluation.json"), estimability=handoff.get("estimability")), "F45_EVALUATION_POINT_SOURCE_DRIFT")
        replicates = []
        branches = tuple(handoff["survival"])
        for rid, draw in enumerate(plan["draws"], 1):
            member = f"evaluation/replicate-{rid:04d}.zip"
            _require(archive.getinfo(member).file_size <= run["budgets"]["retained_bytes_per_replicate"],
                     "F45_EVALUATION_REPLICATE_TOO_LARGE")
            with open_carrier(io.BytesIO(archive.read(member))) as replica:
                _require(len(replica.namelist()) == 4
                    and set(replica.namelist()) == {"input.json", "evaluation.json", "result.json", "metrics.zip"},
                    "F45_EVALUATION_REPLICATE_MEMBERS_INVALID")
                _require(read(replica, "input.json") == {**binding, "replicate": rid, "draw_indices": draw},
                         "F45_EVALUATION_REPLICATE_SOURCE_DRIFT")
                row, evaluation = read(replica, "result.json"), read(replica, "evaluation.json")
                _require(evaluation["selection_horizon_months"] == unit["horizon"]
                    and evaluation["science_decision_sha256"] == science["identity_sha256"]
                    and a._a12_bootstrap_row(rid, row["receipt"], evaluation, branches=branches) == row,
                    "F45_EVALUATION_REPLICATE_REDUCTION_DRIFT")
                replicates.append(row)
        numeric = a._reduce_a12_incremental_value(handoff, plan, point, replicates, formal=True)
        numeric["evaluation_execution"] = execution
        _require(a._a12_native_summary(context, numeric, records) == value,
                 "F45_EVALUATION_SUMMARY_REDUCTION_DRIFT")


def _f45_evaluation(run, unit, root, context):
    from . import f5_sensitivity as a
    import zipfile
    units = Path(run["run_root"]) / "units"
    h = unit["horizon"]
    primary_roots = {o: units / f"PRIMARY-H{h:02d}-O{o}" for o in range(1, 7)}
    aar_roots = {o: units / f"AAR-H{h:02d}-O{o}" for o in range(1, 7)}
    result = root / "result.zip"
    shared = Path(run["run_root"]) / "shared"
    if run.get("kind") == "PADML_INTEGRATED_RAW_RUN_V1":
        from .run import prepare_f45_bootstrap
        prepare_f45_bootstrap(run, shared)
    _require((shared / "bootstrap.zip").is_file() and (shared / "bootstrap-preparation.json").is_file(),
             "F45_SHARED_B1000_INPUT_REQUIRED")
    if not result.is_file():
        prepared = a.prepare_f45_evaluation(run, unit, root)
        a.execute_f45_compact_evaluation(run, unit, root, prepared)
    else:
        with open_carrier(result) as archive:
            compact = "evaluation-input.zip" in archive.namelist()
        if compact:
            a.replay_f45_compact_evaluation(run, unit, root)
        else:
            _f45_resume_evaluation(run, unit, root, primary_roots, aar_roots, shared)
    tables = _f45_report_tables(result, root, h)
    _f45_release(root, "EVALUATION_B1000_PAIRED_TABLES", result, *tables)
    return [result, *tables]


def _f45_report_tables(archive: Path, root: Path, horizon: int) -> list[Path]:
    import csv
    import io
    import re
    import zipfile
    from .nested_loco import _write_exact_once
    with open_carrier(archive) as handle:
        value = strict_json_bytes(handle.read("a12.json"))
    _require(value["selection_horizon_months"] == horizon and value["bootstrap"]["replicate_count"] == 1000,
             "F45_REPORT_HORIZON_OR_BOOTSTRAP_DRIFT")
    from .f5_sensitivity import _a12_aggregate_estimability
    unavailable = _a12_aggregate_estimability(value.get("estimability"))
    branch_count = 2 if unavailable else 3
    tables = []
    rows_per_branch = 344 + (42 if "weighted_center_macro" in value else 0)
    for name, count in (("absolute_rows", (branch_count + 1) * rows_per_branch),
                        ("paired_rows", branch_count * rows_per_branch)):
        original = value["bootstrap"][name]
        _require(len(original) == count, "F45_REPORT_ROW_COVERAGE_INVALID")
        rows = []
        for original_row in original:
            row = {"development_horizon_months": horizon,
                **({"delta_definition": value["delta_definition"]} if name == "paired_rows" else {})}
            def flatten(prefix, node):
                if isinstance(node, dict):
                    for key, item in node.items():
                        flatten(f"{prefix}_{key}" if prefix else key, item)
                else:
                    row[prefix] = json.dumps(node, ensure_ascii=False) if isinstance(node, list) else node
            flatten("", original_row)
            ci = original_row["bootstrap"]["percentile_95_ci"]
            row.pop("bootstrap_percentile_95_ci", None)
            row["ci_lower_95"], row["ci_upper_95"] = ci if ci is not None else (None, None)
            time = re.search(r"_(6|12|24|36)$", row["metric"])
            row["report_horizon_months"] = int(time.group(1)) if time else horizon if row["metric"] == "uno_c" else "ALL_FOLLOWUP"
            # Retain numerical support statuses; an absent estimate stays empty, never zero.
            rows.append(row)
        fields = list(dict.fromkeys(k for row in rows for k in row))
        stream = io.StringIO(newline="")
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader(); writer.writerows(rows)
        path = root / f"report-H{horizon:02d}-{name}.csv"
        _write_exact_once(path, stream.getvalue().encode(), "F45_REPORT_DRIFT")
        tables.append(path)
    if unavailable:
        from .nested_loco import AAR_ESTIMANDS
        coverage = [{"branch": branch, "outer_fold": outer,
            "status": "NOT_ESTIMABLE" if outer in {row["outer_fold"] for row in
                unavailable.get(branch, {}).get("unavailable_outers", [])} else "COMPLETED"}
            for branch in ("PRIMARY", *AAR_ESTIMANDS) for outer in range(1, 7)]
        path = root / "report-estimability.json"
        _write_exact_once(path, canonical_json_bytes({"status": "PARTIALLY_NOT_ESTIMABLE",
            "selection_horizon_months": horizon, "estimability": unavailable, "outer_branch_coverage": coverage}),
            "F45_REPORT_DRIFT")
        tables.append(path)
    return tables


def execute_f45(run_path: Path, unit_id: str, *, mode: str = "execute", source_unit: str | None = None,
                attempt_id: str | None = None) -> dict[str, Any]:
    """One host, one complete unit, original scientific coordinates as recovery state."""
    import fcntl
    import platform
    from . import runtime
    from .run import load_f45_run, f45_unit_predecessors
    from .runtime import observe_execution_resources, resource_admission
    import re
    _require(attempt_id is None or isinstance(attempt_id, str)
        and re.fullmatch(r'[0-9a-f]{32}', attempt_id) is not None, 'F45_START_ATTEMPT_INVALID')
    _require(platform.system() == "Linux", "F45_PRODUCTION_REQUIRES_LINUX")
    os.environ["PADML_F45_RUN_PATH"] = str(run_path)
    run = load_f45_run(run_path)
    from .integrated import is_integrated
    if is_integrated(run):
        os.environ["PADML_INTEGRATED_RUN"] = run["identity"]
    else:
        os.environ.pop("PADML_INTEGRATED_RUN", None)
    generations = [run, *f45_unit_predecessors(run)]
    admitted_runs = {row["identity"] for row in generations}
    h36_runs = {row["identity"] for row in generations if "amendment_20260928" in row["science_decision"]}
    by_id = {u["unit_id"]: u for u in run["units"]}
    _require(unit_id in by_id, "F45_UNIT_UNKNOWN")
    unit = by_id[unit_id]
    _require(mode in {"execute", "postprocess", "selection", "appendage"}
        and (mode != "postprocess" or unit["kind"] in {"PRIMARY", "FULL0"})
        and (mode != "selection" or unit["kind"] == "EVALUATION" and source_unit in by_id
            and by_id[source_unit]["kind"] in {"PRIMARY", "FULL0"}
            and by_id[source_unit]["horizon"] == unit["horizon"])
        and (mode != 'appendage' or unit['kind'] in {'PRIMARY','FULL0','EVALUATION'}
            and (source_unit is None or unit['kind'] == 'EVALUATION' and source_unit in by_id
                and by_id[source_unit]['kind'] in {'PRIMARY','FULL0'}
                and by_id[source_unit]['horizon'] == unit['horizon']))
        and (mode in {"selection", "appendage"} or source_unit is None), "F45_UNIT_MODE_INVALID")
    base = Path(run["run_root"])
    base.mkdir(mode=0o700, parents=True, exist_ok=True)
    # The existing pool READY handshake records groups before any scientific task is sent.
    with (base / "active.lock").open("a+") as owner:
        import time
        read_deadline = time.monotonic() + 1.0
        while True:
            try:
                fcntl.flock(owner, fcntl.LOCK_EX | fcntl.LOCK_NB)
                break
            except BlockingIOError:
                try:
                    # Shared observers are short readers, not computation owners.
                    fcntl.flock(owner, fcntl.LOCK_SH | fcntl.LOCK_NB)
                except BlockingIOError:
                    raise ContractError("F45_INSTANCE_ALREADY_RUNNING") from None
                fcntl.flock(owner, fcntl.LOCK_UN)
                _require(time.monotonic() < read_deadline, "F45_OWNER_READ_CONTENTION_TIMEOUT")
                time.sleep(.025)
        owner.seek(0)
        previous_raw = owner.read().strip()
        if previous_raw:
            try:
                previous = [json.loads(line) for line in previous_raw.splitlines()]
            except (ValueError, TypeError):
                raise ContractError("F45_PREVIOUS_PROCESS_STATE_UNKNOWN") from None
            _require(all(isinstance(row, dict) for row in previous), "F45_PREVIOUS_PROCESS_STATE_UNKNOWN")
            head, terminal = previous[0], previous[-1]
            _require(head.get('run_identity') in admitted_runs and head.get('unit_id') in by_id
                and head.get('mode', 'execute') in {'execute', 'postprocess', 'selection', 'appendage'}
                and (head.get('source_unit') in by_id if head.get('mode') == 'selection'
                     or head.get('mode') == 'appendage' and head.get('source_unit') is not None
                     else head.get('source_unit') is None)
                and type(head.get('pid')) is int and head['pid'] > 0
                and terminal.get('exit_status') == 'RETURNED'
                and terminal.get('pgid') == head.get('pgid'), "F45_PREVIOUS_OWNER_REQUIRES_EXPLICIT_RECOVERY")
            groups = {row.get("pgid") for row in previous}
            _require(all(type(group) is int and group > 0 for group in groups), "F45_PREVIOUS_PROCESS_STATE_UNKNOWN")
            import subprocess
            processes = subprocess.run(["ps", "-eo", "pgid="], capture_output=True, text=True, check=True)
            live = set(processes.stdout.split())
            _require(all(str(group) not in live for group in groups),
                     "F45_PREVIOUS_PROCESS_GROUP_STILL_LIVE")
        root = base / "units" / unit_id
        context = base / "contexts" / unit["context"]
        root.mkdir(mode=0o700, parents=True, exist_ok=True)
        context.mkdir(mode=0o700, parents=True, exist_ok=True)
        owner.seek(0); owner.truncate()
        owner.write(json.dumps({"pid": os.getpid(), "pgid": os.getpgrp(), "unit_id": unit_id,
            "mode": mode, "source_unit": source_unit, "run_identity": run["identity"],
            **({'attempt_id': attempt_id} if attempt_id is not None else {})}) + "\n"); owner.flush(); os.fsync(owner.fileno())
        def observe_group(group):
            owner.write(json.dumps({"pgid": group}) + "\n"); owner.flush(); os.fsync(owner.fileno())
        runtime._POOL_GROUP_OBSERVER = observe_group
        runtime._COMPLETED_CACHE_ROOT = base
        returned = False
        try:
            if is_integrated(run):
                from .runtime_bundle import qualify_current_environment
                qualify_current_environment(run)
                if mode != 'appendage':
                    from .integrated import compact_retained_storage
                    compact_retained_storage(run)
            if mode == 'appendage':
                from .evaluation_extension import eligible as extension_eligible,run_extension,qualify_retained_prerequisites
                origin = by_id[source_unit] if source_unit is not None else None
                from .evaluation_extension import GATE,clinical_eligible,run_clinical
                if source_unit is None and clinical_eligible(run,unit) and (base/GATE).is_file():
                    result=run_clinical(run,unit)
                    returned=True
                    return result
                if extension_eligible(run,unit,origin):
                    qualify_retained_prerequisites(run,unit)
                    result = run_extension(run,unit)
                    returned = True
                    return result
                from .f4 import run_evaluation_appendix,run_post_result_repair,evaluation_appendix_observation
                consume = run_post_result_repair if run.get('post_result_repair') is not None else run_evaluation_appendix
                from .curve_rmse import eligible,run_curve
                origin = by_id[source_unit] if source_unit is not None else None
                if eligible(run,unit,origin):
                    if not evaluation_appendix_observation(run,unit,include_curve=False):
                        consume(run,unit,root)
                    result = run_curve(run,unit)
                else:
                    result = consume(run,unit,root,source_unit=origin)
                from .result_closure import eligible as closure_eligible,run_closure
                if closure_eligible(run,unit,origin):
                    result = run_closure(run,unit)
                returned = True
                return result
            from .f4 import run_f45_postprocess, run_f45_selection
            if mode == "postprocess":
                if unit["kind"] == "FULL0" and is_integrated(run):
                    from .f5_application import validate_application_self_check
                    validate_application_self_check(_f45_read(root / "application.json"), run, root)
                result = run_f45_postprocess(run, unit, root)
                if unit["kind"] == "PRIMARY":
                    from .f5_sensitivity import prepare_f45_evaluation_source
                    prepare_f45_evaluation_source(run, unit, root)
                returned = True
                return result
            if mode == "selection":
                result = run_f45_selection(run, unit, by_id[source_unit], root / "selection" / source_unit)
                returned = True
                return result
            result_path = root / "unit.json"
            if result_path.is_file():
                result = _f45_read(result_path)
                _require(result["run_identity"] in admitted_runs and result["unit_id"] == unit_id
                    and (unit["horizon"] != 36 or result["run_identity"] in h36_runs),
                         "F45_UNIT_RESULT_SOURCE_DRIFT")
                if result.get("status") == "NOT_ESTIMABLE":
                    from .integrated import consume_unit_estimability
                    consume_unit_estimability(run, unit, root, result)
                    returned = True
                    return result
                _require(result.get("status") == "COMPLETED" and result.get("direct_consumer_completed") is True,
                    "F45_UNIT_TERMINAL_INVALID")
                if unit["kind"] == "FULL0" and is_integrated(run):
                    from .f5_application import validate_application_self_check
                    validate_application_self_check(_f45_read(root / "application.json"), run, root)
                if unit["kind"] in {"PRIMARY", "FULL0"}:
                    run_f45_postprocess(run, unit, root)
                    if unit["kind"] == "PRIMARY":
                        from .f5_sensitivity import prepare_f45_evaluation_source
                        prepare_f45_evaluation_source(run, unit, root)
                    returned = True
                    return result
                if unit["kind"] == "AAR":
                    from .f5_sensitivity import prepare_f45_evaluation_source
                    prepare_f45_evaluation_source(run, unit, root)
                    returned = True
                    return result
                _f45_file_pins({name: root / name for name in result["artifacts"]},
                    expected=result["artifacts"], policy=run["resource_policy"], root=root,
                    failure="F45_COMPLETED_ARTIFACT_DRIFT")
                if run.get("kind") != "PADML_INTEGRATED_RAW_RUN_V1" and not (root / "unit.zip").is_file():
                    write_deterministic_zip(root / "unit.zip", {"unit.json": result_path,
                        **{name: root / name for name in result["artifacts"]}},
                        stored_members={name for name in result["artifacts"] if name.endswith(".zip")})
                returned = True
                return result
            dependency_receipts = {name: _f45_read(base / "units" / name / "unit.json") for name in unit["depends_on"]}
            direct_negative = {name for name, row in dependency_receipts.items()
                if row.get("status") == "NOT_ESTIMABLE" and by_id[name]["kind"] == "PRIMARY"}
            not_estimable_dependencies = []
            for dependency in unit["depends_on"]:
                previous = base / "units" / dependency
                receipt = dependency_receipts[dependency]
                _require(receipt["run_identity"] in admitted_runs and receipt["unit_id"] == dependency
                    and receipt.get("selection_horizon_months") == unit["horizon"]
                    and receipt.get("direct_consumer_completed") is True
                    and (unit["horizon"] != 36 or receipt["run_identity"] in h36_runs),
                         "F45_DEPENDENCY_IDENTITY_DRIFT")
                if receipt.get("status") == "NOT_ESTIMABLE":
                    from .integrated import consume_unit_estimability
                    if unit["kind"] == "EVALUATION" and direct_negative and by_id[dependency]["kind"] == "AAR":
                        proof = receipt.get("estimability", {})
                        _require(proof.get("status") == "NOT_ESTIMABLE"
                            and proof.get("reason_code") == "UPSTREAM_PRIMARY_NOT_ESTIMABLE"
                            and proof.get("upstream_units") == sorted(by_id[dependency]["depends_on"])
                            and set(proof["upstream_units"]) <= direct_negative,
                            "F45_DEPENDENCY_ESTIMABILITY_DRIFT")
                        validate_sha256(proof.get("evidence_identity"), "dependency.estimability")
                    else:
                        consume_unit_estimability(run, by_id[dependency], previous, receipt)
                    if by_id[dependency]["kind"] == "PRIMARY":
                        not_estimable_dependencies.append(dependency)
                    continue
                _require(receipt.get("status") == "COMPLETED" and receipt.get("direct_consumer_completed") is True,
                    "F45_DEPENDENCY_NOT_TERMINAL")
                if is_integrated(run) and unit["kind"] == "AAR":
                    # AAR's original compact consumer verifies the receipt, lock and numerical
                    # members below. It does not use or rehash PRIMARY's twenty final models.
                    _require((previous / "evaluation-input.zip").is_file(), "F45_COMPACT_DEPENDENCIES_NOT_READY")
                elif unit["kind"] != "EVALUATION":
                    _f45_file_pins({name: previous / name for name in receipt["artifacts"]},
                        expected=receipt["artifacts"], policy=run["resource_policy"], root=root,
                        failure="F45_DEPENDENCY_ARTIFACT_DRIFT")
            admission = resource_admission(run["resource_policy"], observe_execution_resources(root), legal_tasks=300)
            os.environ.update(THREAD_ENV)
            os.environ["PADML_F45_Q_REUSE_ROOT"] = str(context / "q-atoms")
            action = {"PRIMARY": _f45_primary, "AAR": _f45_aar, "FULL0": _f45_full0,
                      "EVALUATION": _f45_evaluation}[unit["kind"]]
            if not_estimable_dependencies:
                from .integrated import publish_unit_not_estimable
                artifacts = publish_unit_not_estimable(run, unit, root, dependencies=not_estimable_dependencies)
            else:
                artifacts = action(run, unit, root, context)
            estimability = None
            with open_carrier(root / "result.zip") as archive:
                negative = "estimability.json" in archive.namelist()
                if not negative and unit["kind"] == "AAR":
                    from .f5_sensitivity import _a12_estimable_branches
                    header = strict_json_bytes(archive.read("a12-outer.json"))
                    _a12_estimable_branches(header)
                    if "estimability" in header:
                        estimability = {branch: {key: proof[key] for key in
                            ("status", "reason_code", "outer_fold", "identity_sha256")}
                            for branch, proof in header["estimability"].items()}
                elif not negative and unit["kind"] == "EVALUATION":
                    from .f5_sensitivity import _a12_aggregate_estimability
                    header = strict_json_bytes(archive.read("a12.json"))
                    unavailable = _a12_aggregate_estimability(header.get("estimability"))
                    if unavailable:
                        estimability = {branch: {"status": proof["status"], "reason_code": proof["reason_code"],
                            "unavailable_outers": [item["outer_fold"] for item in proof["unavailable_outers"]]}
                            for branch, proof in unavailable.items()}
            if negative:
                from .integrated import consume_not_estimable_result, _unit_estimability_summary
                estimability = _unit_estimability_summary(consume_not_estimable_result(run, unit, root / "result.zip"))
            result = {"status": "NOT_ESTIMABLE" if negative else "COMPLETED", "unit_id": unit_id, "run_identity": run["identity"],
                "selection_horizon_months": unit["horizon"], "report_horizons_months": [6, 12, 24, 36],
                "resource_admission": admission, "direct_consumer_completed": True,
                **({"estimability": estimability} if estimability else {}),
                "artifacts": _f45_file_pins({path.relative_to(root).as_posix(): path for path in artifacts},
                    policy=run["resource_policy"], root=root)}
            _f45_write(result_path, result)
            if run.get("kind") != "PADML_INTEGRATED_RAW_RUN_V1":
                write_deterministic_zip(root / "unit.zip", {"unit.json": result_path,
                    **{name: root / name for name in result["artifacts"]}},
                    stored_members={name for name in result["artifacts"] if name.endswith(".zip")})
            if not negative and unit["kind"] in {"PRIMARY", "FULL0"}:
                run_f45_postprocess(run, unit, root)
            if not negative and unit["kind"] in {"PRIMARY", "AAR"}:
                from .f5_sensitivity import prepare_f45_evaluation_source
                prepare_f45_evaluation_source(run, unit, root)
            returned = True
            return result

        finally:
            try:
                if returned and mode not in {"selection", "appendage"}:
                    from .integrated import retire_completed_outputs
                    retire_completed_outputs(run, unit, root)
            except BaseException:
                returned = False
                raise
            finally:
                try:
                    runtime.release_f45_cumulative_files(
                        [root / name for name in result.get('artifacts', {})] if returned else [],
                        owner="WHOLE_UNIT_EXIT:" + unit_id,
                        report_root=root, released_references=["returned_whole_unit_call"], scope="run")
                except BaseException:
                    returned = False
                    raise
                finally:
                    runtime._COMPLETED_CACHE_ROOT = None
                    runtime._COMPLETED_CACHE_FILES.clear()
                    runtime._POOL_GROUP_OBSERVER = None
                    owner.write(json.dumps({"pgid": os.getpgrp(), "exit_status": "RETURNED" if returned else "FAILED"}) + "\n")
                    owner.flush(); os.fsync(owner.fileno())

def main() -> None:
    import sys
    if len(sys.argv) > 1 and sys.argv[1] == "f45":
        parser = argparse.ArgumentParser(prog="padml.worker f45")
        parser.add_argument("run", type=Path)
        parser.add_argument("unit_id")
        parser.add_argument("--mode", choices=("execute", "postprocess", "selection", "appendage"), default="execute")
        parser.add_argument("--source-unit")
        parser.add_argument("--attempt-id")
        args = parser.parse_args(sys.argv[2:])
        from .integrated import configure_environment
        configure_environment(args.run.resolve(strict=True))
        os.environ.update(THREAD_ENV)
        os.environ["R_LIBS_USER"] = R_LIBRARY
        if os.getpgrp() != os.getpid():
            os.setsid()
        print(json.dumps(execute_f45(args.run.resolve(strict=True), args.unit_id,
            mode=args.mode, source_unit=args.source_unit, attempt_id=args.attempt_id), sort_keys=True))
        return
    parser = argparse.ArgumentParser(prog="padml-worker")
    parser.add_argument("capsule", type=Path)
    parser.add_argument("common_input", type=Path)
    parser.add_argument("unit_id")
    parser.add_argument("result", type=Path)
    parser.add_argument("--reuse-non-fpm", type=Path,
                        help="Retain unchanged non-FPM tasks from this prior P2C2T result; refit FPM only.")
    parser.add_argument("--reuse-fpm", type=Path,
                        help="Reuse the capsule-bound, native fixed FPM component without refitting it.")
    args = parser.parse_args()
    os.environ.update(THREAD_ENV)
    os.environ["R_LIBS_USER"] = R_LIBRARY
    result = execute(
        args.capsule.resolve(),
        args.common_input.resolve(),
        args.unit_id,
        args.result.resolve(),
        reuse_non_fpm=args.reuse_non_fpm.resolve(strict=True) if args.reuse_non_fpm else None,
        reuse_fpm=args.reuse_fpm.resolve(strict=True) if args.reuse_fpm else None,
    )
    print(json.dumps(result, sort_keys=True, separators=(",", ":")))


if __name__ == "__main__":
    main()
