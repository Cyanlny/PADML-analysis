"""Learning-specific M5 numbers retained after the current native audit.

These readers recompute selection and prediction arithmetic. They do not claim
to replay retired MICE/model objects or reconstruct full coefficient paths.
"""
from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from .bundle import canonical_json_bytes, strict_json_bytes
from .f4 import (
    _choose_learning_selector_summary, _learning_selector_numbers, _require,
    _summarize_learning_selector_alpha,
)
from .f2_kernel import (
    _elastic_ratios, _finite_number, _validate_sealed_elastic_lambda_path_health,
)
from ._science_authority import load_science_authority


_HEALTH = (
    "imputation", "lambda_max", "lambda_path_sha256", "lambda_upper_bound",
    "penalized_active_count_path", "penalized_design_column_count", "penalized_entry_covered",
)


def compact_learning_alpha(record: Mapping[str, Any], heldout_inner: int) -> dict[str, Any]:
    """Complete full-path admission precedes any disposal of a coefficient."""
    summary = _summarize_learning_selector_alpha(record, heldout_inner)
    vectors = []
    for path, decision in zip(record["full_paths"], summary["imputation_decisions"], strict=True):
        if decision["status"] == "EPV_INFEASIBLE":
            vectors.append(None)
        else:
            index = summary["ratios"].index(decision["r_1se"])
            vectors.append({parent: values[index] for parent, values in path["parent_coefficients"].items()})
    value = {
        "alpha": record["alpha"], "partition_losses": record["partition_losses"],
        "parent_design_columns": record["full_paths"][0]["parent_design_columns"],
        "full_path_health": [{**{key: path[key] for key in _HEALTH}, "event_count": path["event_count"]}
                             for path in record["full_paths"]],
        "selected_coefficients": vectors,
    }
    return strict_json_bytes(canonical_json_bytes(value))


def read_learning_alpha(
    value: Mapping[str, Any], *, heldout_inner: int, training_event_count: int,
    parent_design_columns: Mapping[str, int], fold_validation_n: Mapping[int, int],
) -> dict[str, Any]:
    """Caller supplies actual training events, recipe dimensions and fold sizes."""
    contract = load_science_authority()["science"]["f2_model_development"]["selector_contract"]
    ratios = _elastic_ratios(contract)
    _require(type(heldout_inner) is int and heldout_inner in range(1, 6)
             and type(training_event_count) is int and training_event_count > 0
             and isinstance(parent_design_columns, Mapping) and "AST_ALT" in parent_design_columns
             and all(isinstance(k, str) and k and type(n) is int and n > 0
                     for k, n in parent_design_columns.items())
             and isinstance(fold_validation_n, Mapping)
             and set(fold_validation_n) == set(range(1, 6)) - {heldout_inner}
             and all(type(n) is int and n > 0 for n in fold_validation_n.values()),
             "F4_LEARNING_COMPACT_CALLER_INVALID")
    _require(isinstance(value, Mapping) and set(value) == {
        "alpha", "partition_losses", "parent_design_columns", "full_path_health", "selected_coefficients"},
        "F4_LEARNING_COMPACT_ALPHA_INVALID")
    alpha, rows, paths, vectors = (value[key] for key in
        ("alpha", "partition_losses", "full_path_health", "selected_coefficients"))
    _require(_finite_number(alpha) and 0.01 <= alpha <= 1
             and value["parent_design_columns"] == parent_design_columns
             and isinstance(rows, list) and len(rows) == 4
             and isinstance(paths, list) and len(paths) == 5
             and isinstance(vectors, list) and len(vectors) == 5,
             "F4_LEARNING_COMPACT_ALPHA_INVALID")
    seen = set()
    for row in rows:
        _require(isinstance(row, Mapping) and type(row.get("inner_fold")) is int,
                 "F4_LEARNING_COMPACT_LOSS_INVALID")
        fold, losses, health = row["inner_fold"], row.get("mi_losses"), row.get("mi_lambda_path_health")
        _require(fold in fold_validation_n and fold not in seen and type(row.get("repeat")) is int
                 and row["repeat"] == 2 and type(row.get("validation_n")) is int
                 and row["validation_n"] == fold_validation_n[fold]
                 and isinstance(losses, list) and len(losses) == 5
                 and all(isinstance(loss, list) and len(loss) == 150
                         and all(_finite_number(x) for x in loss) for loss in losses)
                 and isinstance(health, list) and len(health) == 5,
                 "F4_LEARNING_COMPACT_LOSS_INVALID")
        seen.add(fold)
        for imp, item in enumerate(health, 1):
            _validate_sealed_elastic_lambda_path_health(item, alpha=float(alpha), ratios=ratios, imputation=imp)
    _require(seen == set(fold_validation_n), "F4_LEARNING_SELECTOR_FOLD_COVERAGE_INVALID")
    rows = sorted(rows, key=lambda row: row["inner_fold"])
    for imp, (path, vector) in enumerate(zip(paths, vectors, strict=True), 1):
        _require(isinstance(path, Mapping) and set(path) == {*_HEALTH, "event_count"}
                 and type(path["event_count"]) is int and path["event_count"] == training_event_count,
                 "F4_LEARNING_COMPACT_HEALTH_INVALID")
        _validate_sealed_elastic_lambda_path_health(
            {key: path[key] for key in _HEALTH}, alpha=float(alpha), ratios=ratios, imputation=imp)
        _require(path["penalized_design_column_count"] ==
                 sum(n for parent, n in parent_design_columns.items() if parent != "AST_ALT"),
                 "F4_LEARNING_COMPACT_DESIGN_MISMATCH")
        feasible = any(training_event_count / (parent_design_columns["AST_ALT"] + n) >=
                       contract["epv_contract"]["minimum"] for n in path["penalized_active_count_path"])
        if not feasible:
            _require(vector is None, "F4_LEARNING_COMPACT_INFEASIBLE_SLICE_INVALID")
        else:
            _require(isinstance(vector, Mapping) and set(vector) == set(parent_design_columns)
                     and all(isinstance(coef, list) and len(coef) == parent_design_columns[parent]
                             and all(_finite_number(x) for x in coef) for parent, coef in vector.items()),
                     "F4_LEARNING_COMPACT_COEFFICIENT_INVALID")
    summary = _learning_selector_numbers(float(alpha), rows, paths, parent_design_columns, vectors)
    for path, vector, decision in zip(paths, vectors, summary["imputation_decisions"], strict=True):
        if decision["status"] == "FEASIBLE":
            index = ratios.index(decision["r_1se"])
            _require(sum(x != 0 for parent, coef in vector.items() if parent != "AST_ALT" for x in coef)
                     == path["penalized_active_count_path"][index],
                     "F4_LEARNING_COMPACT_SELECTED_DF_MISMATCH")
    return summary


def read_learning_selector(
    value: Mapping[str, Any], *, cell: Mapping[str, Any], training_event_count: int,
    parent_design_columns: Mapping[str, int], fold_validation_n: Mapping[int, int],
) -> dict[str, Any]:
    """All actual alpha candidates, original coarse/fine reuse and M5 ties."""
    _require(isinstance(value, Mapping) and set(value) == {"alpha_records", "selector_result"}
             and isinstance(value["alpha_records"], list) and bool(value["alpha_records"]),
             "F4_LEARNING_COMPACT_SELECTOR_INVALID")
    cache = {}
    for record in value["alpha_records"]:
        summary = read_learning_alpha(record, heldout_inner=cell["inner_fold"],
            training_event_count=training_event_count, parent_design_columns=parent_design_columns,
            fold_validation_n=fold_validation_n)
        _require(summary["alpha"] not in cache, "F4_LEARNING_COMPACT_ALPHA_DUPLICATE")
        cache[summary["alpha"]] = summary
    grid = load_science_authority()["science"]["f2_model_development"]["selector_contract"]["alpha_grid"]
    coarse = [float(x) for x in grid["coarse"]]
    _require(all(alpha in cache for alpha in coarse), "F4_LEARNING_COMPACT_ALPHA_COVERAGE_INVALID")
    winner, _ = _choose_learning_selector_summary([cache[alpha] for alpha in coarse])
    lower, upper = grid["fine"]["clip"]
    fine = sorted({min(upper, max(lower, round(winner["alpha"] + offset, 3))) for offset in grid["fine"]["offsets"]})
    _require(set(cache) == set(coarse) | set(fine)
             and [row["alpha"] for row in value["alpha_records"]] == coarse + [a for a in fine if a not in coarse],
             "F4_LEARNING_COMPACT_ALPHA_COVERAGE_INVALID")
    chosen, _ = _choose_learning_selector_summary([cache[alpha] for alpha in fine])
    result = {"cell": dict(cell), "selector": chosen, "coarse_alpha_order": coarse,
              "fine_alpha_order": fine, "distinct_alpha_count": len(cache),
              "selector_path_count": len(cache) * 25, "final_model_fits": 0,
              "new_mice_chains": 0, "sensitivity_selection_effect": "NONE", "formal_stage_acceptance": False}
    _require(canonical_json_bytes(result) == canonical_json_bytes(value["selector_result"]),
             "F4_LEARNING_COMPACT_SELECTION_MISMATCH")
    return result


def _portable_mice_spec(spec: Mapping[str, Any]) -> dict[str, Any]:
    paths = {"authority_path", "variable_path", "covariates_path", "response_path", "output_dir"}
    return {key: value for key, value in spec.items() if key not in paths}


def _read_learning_mice_numbers(value: Mapping[str, Any], specs: Mapping[str, Any], covariates_csv: bytes) -> None:
    """Consume retained iterations/configuration, not a retired mids object."""
    from .f1 import load_f1_authority
    import csv
    import io
    science = load_f1_authority()["science"]["mice"]
    reader = csv.DictReader(io.StringIO(covariates_csv.decode("utf-8-sig")))
    columns = [name for name in reader.fieldnames if name != "Patient_ID"]
    from .f1_kernel import effective_mice_rows, mice_terminal_valid, validate_mice_continuation
    raw = effective_mice_rows({row["Patient_ID"]: row for row in reader}, science)
    configurations = {"ACTUAL_MICE_METHOD", "ACTUAL_PREDICTOR_MATRIX", "ACTUAL_BLOT", "ACTUAL_CONTINUATION_CONFIG"}
    _require(isinstance(value, Mapping) and set(value) == set(specs), "F4_LEARNING_COMPACT_MICE_COVERAGE_INVALID")
    for role, spec in specs.items():
        item, view = value[role], spec["view"]
        _require(isinstance(item, Mapping) and set(item) == {"spec", "summary", "configuration"}
                 and item["spec"] == _portable_mice_spec(spec)
                 and isinstance(item["summary"], Mapping) and isinstance(item["configuration"], Mapping)
                 and set(item["configuration"]) == configurations, "F4_LEARNING_COMPACT_MICE_INVALID")
        summary = item["summary"]
        from .f1_kernel import complete_data_passthrough
        passthrough = complete_data_passthrough(summary)
        extra = {"completion_mode", "actual_mice_chains", "rng_consumed"} if passthrough else set()
        _require(set(summary) == {"schema_version", "kind", "status", "view_id", "role", "outer_fold",
                    "row_count", "analysis_row_count", "row_ids_sha256", "formal_m", "active_target_count",
                    "final_iteration", "application_response_columns", "application_predictor_matrix_response_edges",
                    "analysis_auxiliary_predictor_edges", "convergence_max_psrf", "relationship_diagnostics"} | extra
                 and summary["schema_version"] == "1.0.0" and summary["status"] == "PASS"
                 and summary.get("kind") == "PADML_F1_MICE_VIEW_SUMMARY"
                 and summary.get("view_id") == view["view_id"] and summary.get("role") == view["role"]
                 and summary.get("outer_fold") == view["outer_fold"]
                 and type(summary.get("row_count")) is int and summary["row_count"] == len(view["row_ids"])
                 and summary.get("analysis_row_count") == len(view["analysis_ids"])
                 and summary.get("row_ids_sha256") == view["row_ids_sha256"]
                 and type(summary.get("formal_m")) is int and summary["formal_m"] == 5
                 and mice_terminal_valid(summary)
                 and summary.get("application_response_columns") == 0
                 and summary.get("application_predictor_matrix_response_edges") == 0,
                 "F4_LEARNING_COMPACT_MICE_QC_INVALID")
        config = {}
        for name, record in item["configuration"].items():
            _require(isinstance(record, Mapping) and set(record) == {"schema_version", "component", "view_id", "payload"}
                     and record["schema_version"] == "1.0.0" and record["component"] == name
                     and record["view_id"] == view["view_id"] and isinstance(record["payload"], Mapping),
                     "F4_LEARNING_COMPACT_MICE_CONFIGURATION_INVALID")
            config[name] = record["payload"]
        method = config["ACTUAL_MICE_METHOD"]
        names = columns + (["event_aux", "nelson_aalen_aux"] if view["role"] == "ANALYSIS" else [])
        expected_active = {row["target"] for row in science["target_rules"]
                           if any(not raw[p][row["target"]].strip() for p in view["row_ids"])}
        _require(set(method) == {"names", "values"} and isinstance(method["names"], list)
                 and isinstance(method["values"], list) and len(method["names"]) == len(set(method["names"]))
                 == len(method["values"]) and method["names"] == names and passthrough == (not expected_active)
                 and method["values"] == ["pmm" if name in expected_active else "" for name in names],
                 "F4_LEARNING_COMPACT_MICE_CONFIGURATION_INVALID")
        active = [name for name, mode in zip(method["names"], method["values"], strict=True) if mode]
        targets = [row["target"] for row in science["target_rules"] if row["target"] in active]
        _require(len(active) == len(targets) == summary.get("active_target_count")
                 and config["ACTUAL_BLOT"] == {"rows": [{"target": target, **science["pmm"]} for target in targets]},
                 "F4_LEARNING_COMPACT_MICE_CONFIGURATION_INVALID")
        validate_mice_continuation(config['ACTUAL_CONTINUATION_CONFIG'], summary, spec['chain_seeds'], active)
        matrix = config["ACTUAL_PREDICTOR_MATRIX"]
        _require(set(matrix) == {"row_names", "column_names", "values"}
                 and matrix["row_names"] == matrix["column_names"] == names
                 and isinstance(matrix["values"], list) and len(matrix["values"]) == len(names)
                 and all(isinstance(row, list) and len(row) == len(names)
                         and all(type(x) is int and x in {0, 1} for x in row) for row in matrix["values"])
                 and all(matrix["values"][index][index] == 0 for index in range(len(names))),
                 "F4_LEARNING_COMPACT_MICE_MATRIX_INVALID")
        targets_by_name = {row["target"]: row for row in science["target_rules"]}
        for name, edges in zip(names, matrix["values"], strict=True):
            forbidden = set(science["always_forbidden_predictors"]) | {name}
            if name in targets_by_name:
                forbidden.update(targets_by_name[name]["forbidden_predictors"])
            _require(all(not edge for predictor, edge in zip(names, edges, strict=True)
                         if name not in targets_by_name or predictor in forbidden),
                     "F4_LEARNING_COMPACT_MICE_MATRIX_INVALID")
        auxiliary_count = sum(matrix["values"][names.index(target)][names.index(auxiliary)]
                              for target in active for auxiliary in ("event_aux", "nelson_aalen_aux")
                              if auxiliary in names)
        _require(summary["analysis_auxiliary_predictor_edges"] == auxiliary_count
                 and auxiliary_count == (2 * len(active) if view["role"] == "ANALYSIS" else 0),
                 "F4_LEARNING_COMPACT_MICE_MATRIX_INVALID")


def _learning_compact_source(value: Mapping[str, Any], source: Mapping[str, Any]) -> tuple:
    """Rebuild actual registered populations and M5 selection from common input."""
    from pathlib import Path
    from .bundle import sha256_bytes, validate_sha256
    from .f4 import _learning_curve_mice_specs, _learning_selector_subsets, _response_rows, _write_response_subset
    from .f2_kernel import _elastic_candidate_parents, _expected_family_parent_column_map, _validate_transform_recipe, predictor_contract
    cell = value["cell"]
    _require(isinstance(cell, Mapping) and cell.get("family") == "XGBOOST_COX",
             "F4_LEARNING_COMPACT_LOCKED_FAMILY_UNSUPPORTED")
    # This path is used only to build portable source specs; nothing is written.
    specs = _learning_curve_mice_specs(source["binding_contract"], source["covariates_csv"],
        source["response_csv"], None, cell, Path("/PADML_COMPACT_SOURCE_ONLY/mice"))
    model = source["models"][cell["outer_fold"], cell["family"]]
    _require(value["f1_identity"] == source["f1_manifest"]["identity"]
             and value["model_sha256"] == sha256_bytes(canonical_json_bytes(model)),
             "F4_LEARNING_COMPACT_SOURCE_MISMATCH")
    validate_sha256(value["source_native_identity"], "learning.compact.original_cell")
    _read_learning_mice_numbers(value["mice"], specs, source["covariates_csv"])
    predictors = predictor_contract(Path(__file__).parent)
    recipe = _validate_transform_recipe(value["selector_recipe"], predictors)
    _require(recipe["partition_id"] == specs["ANALYSIS"]["view"]["view_id"] + "_SELECTOR_K0"
             and recipe["fit_ids_sha256"] == sha256_bytes(canonical_json_bytes(cell["analysis_ids"])),
             "F4_LEARNING_COMPACT_RECIPE_SOURCE_MISMATCH")
    columns = {row["parent"]: len(row["columns"]) for row in _expected_family_parent_column_map(
        _elastic_candidate_parents({"predictors": predictors}), "ELASTIC_NET_COX", predictors, recipe)}
    subsets = _learning_selector_subsets(source["binding_contract"], cell)
    _require(value["selector_subsets"] == subsets, "F4_LEARNING_COMPACT_SELECTOR_SOURCE_MISMATCH")
    fields, responses = _response_rows(source["response_csv"])
    training = _write_response_subset(fields, responses, cell["analysis_ids"], None)
    selector = read_learning_selector(value["selector"], cell=cell, training_event_count=training["event_count"],
        parent_design_columns=columns, fold_validation_n={row["inner_fold"]: len(row["evaluation_ids"]) for row in subsets})
    return cell, model, specs, predictors, selector, fields, responses


def _learning_xgb_task(model: Mapping[str, Any], cell: Mapping[str, Any], selector: Mapping[str, Any],
                       predictors: Mapping[str, Any], specs: Mapping[str, Any], imp: int,
                       *, stop: bool, lock: Mapping[str, Any] | None) -> tuple:
    """Exact existing learning task arithmetic for the actually locked family."""
    from .bundle import sha256_bytes
    from .f4 import _f4_model_seed
    from .f5 import _locked_family_parameters, _validate_final_design_recipe
    from .f2_kernel import _engine_parameters, _expected_family_parent_column_map
    family, selected = "XGBOOST_COX", selector["selector"]["selected_parents"]
    recipe = _validate_final_design_recipe({"schema_version": "1.0.0", "kind": "PADML_F5_FINAL_DESIGN_RECIPE_V1",
        "family": family, "selected_parents": selected, "preprocessing_mode": "F2_RAW_CANONICAL_AUTHORITY_LEVELS",
        "predictor_contract_sha256": sha256_bytes(canonical_json_bytes(predictors)),
        "predictor_rows": [row for row in predictors["variables"] if row["name"] in selected],
        "transform_recipe": None, "coxtime_standardization": None}, family=family, selected_parents=selected)
    coordinates = {"purpose": "LEARNING_CURVE", "outer_fold": cell["outer_fold"], "repeat": 2,
        "inner_fold": cell["inner_fold"], "imputation": imp, "seed_ordinal": cell["seed_ordinal"],
        "fraction_rank": (0.4, 0.6, 0.8, 1.0).index(cell["sample_fraction"]) + 1}
    seed = _f4_model_seed(family, coordinates)
    fit_ids = specs["STOP_ANALYSIS" if stop else "ANALYSIS"]["view"]["analysis_ids"]
    evaluation_ids = [p for p in cell["analysis_ids"] if p not in set(fit_ids)] if stop else cell["validation_ids"]
    parameters = {**model["selected_spec"], **({"selected_parents": selected} if "selected_parents" in model["selected_spec"] else {})}
    _locked_family_parameters(family, model["selected_spec"])
    if not stop:
        _require(isinstance(lock, Mapping) and type(lock.get("selected_rounds")) is int and lock["selected_rounds"] > 0,
                 "F4_LEARNING_COMPACT_STOP_LOCK_INVALID")
        parameters["selected_rounds"] = lock["selected_rounds"]
    task = {"family": family, "selected_parents": selected, "parameters": parameters, "imputation": imp,
        "f4_coordinates": coordinates, "registered_model_seed": seed,
        "model_seed": cell["seeds"]["early_stopping"] if stop else seed, "row_count": len(fit_ids),
        "family_design_column_count": sum(len(row["columns"]) for row in
            _expected_family_parent_column_map(selected, family, predictors, None))}
    if stop:
        task.update(registered_stop_seed=cell["seeds"]["early_stopping"],
                    stop_parameters=_engine_parameters(family, model["selected_spec"]["parameters"]))
    return task, recipe, fit_ids, evaluation_ids


def read_learning_cell_numbers(value: Mapping[str, Any], mean_survival: bytes, *,
                               frozen_source: Mapping[str, Any]) -> dict[str, Any]:
    """Read the actual retained M5 mean, source-bound tasks, health and IBS.

    The former component objects/STOP loss vector are not reconstructed from
    their summaries. Native auditing happens before this retention boundary.
    """
    import struct
    from .bundle import sha256_bytes, validate_sha256
    from .f4 import HORIZONS, _learning_curve_metric, _learning_native_cell_row, _write_response_subset
    from .f2_kernel import _seal_prediction_matrix, _validate_python_fit_health, _validate_xgb_cox_objective_health
    _require(type(mean_survival) is bytes and isinstance(value, Mapping) and set(value) == {"kind", "cell", "f1_identity", "model_sha256",
        "source_native_identity", "selector", "selector_recipe", "selector_subsets", "mice", "models", "stops",
        "mean_prediction", "score", "identity_sha256"}
        and value["kind"] == "PADML_F4_LEARNING_CELL_COMPACT_V1"
        and value["identity_sha256"] == sha256_bytes(canonical_json_bytes({k: v for k, v in value.items()
                                                                          if k != "identity_sha256"})),
        "F4_LEARNING_COMPACT_CELL_INVALID")
    cell, model, specs, predictors, selector, fields, responses = _learning_compact_source(value, frozen_source)
    _require(isinstance(value["models"], list) and len(value["models"]) == 5
             and isinstance(value["stops"], list) and len(value["stops"]) == 5,
             "F4_LEARNING_COMPACT_M5_REQUIRED")
    for imp, (fitted, stopping) in enumerate(zip(value["models"], value["stops"], strict=True), 1):
        _require(isinstance(stopping, Mapping) and set(stopping) == {"task", "recipe", "native_function", "lock"}
                 and isinstance(stopping["native_function"], Mapping) and set(stopping["native_function"]) == {"sealed"},
                 "F4_LEARNING_COMPACT_STOP_INVALID")
        task, recipe, fit_ids, evaluation_ids = _learning_xgb_task(
            model, cell, selector, predictors, specs, imp, stop=True, lock=None)
        _require(stopping["task"] == task and stopping["recipe"] == recipe, "F4_LEARNING_COMPACT_STOP_SOURCE_MISMATCH")
        sealed, lock = stopping["native_function"]["sealed"], stopping["lock"]
        _require(isinstance(sealed, Mapping) and set(sealed) == {"status", "payload", "sha256"}
                 and sealed["status"] == "SEALED" and isinstance(sealed.get("payload"), Mapping)
                 and isinstance(lock, Mapping), "F4_LEARNING_COMPACT_STOP_INVALID")
        payload = sealed["payload"]
        parameters = task["stop_parameters"]
        _require(set(payload) == {"schema_version", "kind", "fit_ids", "evaluation_ids", "maximum",
                    "booster_sha256", "cox_objective", "design_identity", "parameter_sha256", "fit_input_identity", "seed"}
                 and payload["schema_version"] == "1.0.0"
                 and payload.get("kind") == "PADML_F2_XGBOOST_PREDICTION_FUNCTION"
                 and payload.get("fit_ids") == fit_ids and payload.get("evaluation_ids") == evaluation_ids
                 and payload.get("maximum") == parameters["max_nrounds"]
                 and payload.get("parameter_sha256") == sha256_bytes(canonical_json_bytes(parameters))
                 and payload.get("seed") == task["model_seed"]
                 and sealed.get("sha256") == sha256_bytes(canonical_json_bytes(payload)),
                 "F4_LEARNING_COMPACT_STOP_SOURCE_MISMATCH")
        for key in ("booster_sha256", "design_identity", "fit_input_identity"):
            validate_sha256(payload[key], "learning.compact.stop." + key)
        _validate_xgb_cox_objective_health(payload.get("cox_objective"), payload["maximum"], len(fit_ids))
        _require(set(lock) == {"schema_version", "kind", "risk_curve_sha256", "fit_response_sha256",
                              "evaluation_response_sha256", "selected_rounds", "evaluated_tree_count",
                              "minimum_grouped_cox_deviance", "identity"}
                 and lock["kind"] == "PADML_F2_XGBOOST_ROUND_LOCK" and lock["schema_version"] == "1.0.0"
                 and lock["risk_curve_sha256"] == sealed["sha256"]
                 and lock["fit_response_sha256"] == _write_response_subset(fields, responses, fit_ids, None)["sha256"]
                 and lock["evaluation_response_sha256"] == _write_response_subset(fields, responses, evaluation_ids, None)["sha256"]
                 and type(lock["selected_rounds"]) is int and type(lock["evaluated_tree_count"]) is int
                 and 1 <= lock["selected_rounds"] <= lock["evaluated_tree_count"] <= parameters["max_nrounds"]
                 and _finite_number(lock["minimum_grouped_cox_deviance"])
                 and lock["identity"] == sha256_bytes(canonical_json_bytes({k: v for k, v in lock.items() if k != "identity"})),
                 "F4_LEARNING_COMPACT_STOP_LOCK_INVALID")
        task, recipe, fit_ids, _ = _learning_xgb_task(model, cell, selector, predictors, specs, imp, stop=False, lock=lock)
        _require(isinstance(fitted, Mapping) and set(fitted) == {"task", "recipe", "fit_health"}
                 and fitted["task"] == task and fitted["recipe"] == recipe,
                 "F4_LEARNING_COMPACT_MODEL_SOURCE_MISMATCH")
        _validate_python_fit_health("XGBOOST_COX", fitted["fit_health"], locked_value=lock["selected_rounds"],
                                    training_count=len(fit_ids), evaluation_count=len(fit_ids))
    ids = cell["validation_ids"]
    expected_mean = {"encoding": "IEEE754_FLOAT64_LE_ROW_MAJOR", "patient_ids": ids,
        "centers": [frozen_source["centers"][p] for p in ids], "horizons": HORIZONS,
        "imputation_count": 5, "size_bytes": len(ids) * len(HORIZONS) * 8,
        "sha256": sha256_bytes(mean_survival)}
    _require(type(mean_survival) is bytes and len(mean_survival) == expected_mean["size_bytes"]
             and value["mean_prediction"] == expected_mean, "F4_LEARNING_COMPACT_MEAN_INVALID")
    matrix = [list(row) for row in struct.iter_unpack("<" + "d" * len(HORIZONS), mean_survival)]
    _seal_prediction_matrix(ids, matrix, HORIZONS)
    _require(all(row[0] == 1.0 for row in matrix), "F4_LEARNING_COMPACT_MONTH_ZERO_INVALID")
    prediction = {"patient_ids": ids, "centers": expected_mean["centers"], "horizons": HORIZONS,
                  "survival": {cell["family"]: matrix}}
    score = _learning_curve_metric(cell, prediction, frozen_source)
    _require(canonical_json_bytes(score) == canonical_json_bytes(value["score"]), "F4_LEARNING_COMPACT_METRIC_MISMATCH")
    return {"cell": cell, "row": _learning_native_cell_row(
        {"cell": cell, "identity_sha256": value["source_native_identity"]}, score)}


def load_learning_cell_compact(path: Any, *, frozen_source: Mapping[str, Any]) -> dict[str, Any]:
    from .bundle import read_safe_zip
    _require(path.is_absolute() and path.is_file() and not path.is_symlink(), "F4_LEARNING_COMPACT_PATH_INVALID")
    entries = read_safe_zip(path, expected_members={"learning-cell.json", "mean-survival.f64"},
                            max_member_bytes=64 * 1024 * 1024, max_total_bytes=65 * 1024 * 1024)
    value = strict_json_bytes(entries["learning-cell.json"])
    _require(canonical_json_bytes(value) == entries["learning-cell.json"], "F4_LEARNING_COMPACT_CELL_INVALID")
    return read_learning_cell_numbers(value, entries["mean-survival.f64"], frozen_source=frozen_source)


def write_learning_cell_compact(archive_path: Any, target: Any, *,
                                frozen_source: Mapping[str, Any]) -> dict[str, Any]:
    """Numerical export after the existing producer's successful native audit.

    No engine is invoked and no original is deleted here. The caller must
    preserve originals until OSS return, root consumption and last use finish.
    An unfinished worker's ZIP alone is not a successful producer return.
    """
    import io
    import struct
    import zipfile
    from .bundle import sha256_bytes, write_deterministic_zip
    from .f4 import (
        HORIZONS, _f4_native_component_inputs, _f4_native_prediction, _f4_stop_component_inputs,
        _learning_native_member_names,
    )
    from .f2_kernel import _pool_prediction_batch, _seal_prediction_matrix
    _require(archive_path.is_absolute() and archive_path.is_file() and not archive_path.is_symlink()
             and target.is_absolute() and target.parent.is_dir() and not target.exists() and not target.is_symlink(),
             "F4_LEARNING_COMPACT_EXPORT_PATH_INVALID")
    source_stat = archive_path.stat(follow_symlinks=False)
    with zipfile.ZipFile(archive_path) as archive:
        _require(archive.getinfo("learning-cell.json").file_size <= 4 * 1024 * 1024,
                 "F4_LEARNING_COMPACT_EXPORT_SOURCE_INVALID")
        raw = archive.read("learning-cell.json")
        original = strict_json_bytes(raw)
        _require(isinstance(original, Mapping) and set(original) == {"kind", "cell", "f1_identity", "model_sha256",
            "selector_grids", "members", "identity_sha256"} and original["kind"] == "PADML_F4_LEARNING_CELL_NATIVE_V1"
            and canonical_json_bytes(original) == raw
            and original["identity_sha256"] == sha256_bytes(canonical_json_bytes({k: v for k, v in original.items()
                                                                                if k != "identity_sha256"})),
            "F4_LEARNING_COMPACT_EXPORT_SOURCE_INVALID")
        cell = original["cell"]
        _require(cell["family"] == "XGBOOST_COX" and set(original["members"]) ==
                 _learning_native_member_names(cell, original["selector_grids"]),
                 "F4_LEARNING_COMPACT_EXPORT_SOURCE_INVALID")
        infos = archive.infolist()
        _require(len(infos) == len(original["members"]) + 1 and {i.filename for i in infos} ==
                 {"learning-cell.json", *original["members"]}, "F4_LEARNING_COMPACT_EXPORT_COVERAGE_INVALID")

        def member(name: str) -> bytes:
            info, record = archive.getinfo(name), original["members"][name]
            _require(not info.is_dir() and info.file_size == record["size_bytes"]
                     and info.file_size <= 256 * 1024 * 1024, "F4_LEARNING_COMPACT_EXPORT_MEMBER_INVALID")
            content = archive.read(info)
            _require(sha256_bytes(content) == record["sha256"], "F4_LEARNING_COMPACT_EXPORT_MEMBER_INVALID")
            return content

        def value(name: str) -> Any:
            return strict_json_bytes(member(name))

        records = []
        for phase, alphas in original["selector_grids"].items():
            if not alphas:
                continue
            phase_records = value(f"selector/{phase}/paths.json")
            _require(isinstance(phase_records, list) and [row["alpha"] for row in phase_records] == alphas,
                     "F4_LEARNING_COMPACT_ALPHA_COVERAGE_INVALID")
            records.extend(compact_learning_alpha(row, cell["inner_fold"]) for row in phase_records)
        selector_result = value("selector/selector.json")
        # JSON object key order is canonical alphabetical, not phase order.
        alpha_order = selector_result["coarse_alpha_order"] + [a for a in selector_result["fine_alpha_order"]
                                                               if a not in selector_result["coarse_alpha_order"]]
        _require(len(records) == len(alpha_order) and len({row["alpha"] for row in records}) == len(records),
                 "F4_LEARNING_COMPACT_ALPHA_COVERAGE_INVALID")
        by_alpha = {row["alpha"]: row for row in records}
        selector = {"alpha_records": [by_alpha[a] for a in alpha_order], "selector_result": selector_result}
        mice = {role: {"spec": _portable_mice_spec(value(f"mice/{role}/spec.json")),
            "summary": value(f"mice/{role}/output/summary.json"),
            "configuration": {name: value(f"mice/{role}/output/configuration/{name}.json") for name in
                ("ACTUAL_MICE_METHOD", "ACTUAL_PREDICTOR_MATRIX", "ACTUAL_BLOT", "ACTUAL_CONTINUATION_CONFIG")}}
            for role in ("ANALYSIS", "APPLICATION", "STOP_ANALYSIS", "STOP_APPLICATION")}
        fitted, stopping, predictions = [], [], []
        input_names = {"task.json", "recipe.json", "fit-covariates.csv", "fit-response.csv", "prediction-covariates.csv"}
        for imp in range(1, 6):
            for stop in (True, False):
                name = f"stops/M{imp:02d}_STOP.zip" if stop else f"fits/M{imp:02d}.zip"
                with zipfile.ZipFile(io.BytesIO(member(name))) as component:
                    expected = (input_names | {"stop-response.csv", "model.bin", "native-function.json", "lock.json"}
                                if stop else input_names | {"model.bin", "baseline.bin", "fit-health.json",
                                                          "training-prediction.json", "prediction.json"})
                    nested = component.infolist()
                    _require(len(nested) == len(expected) and {i.filename for i in nested} == expected
                             and all(not i.is_dir() and i.file_size <= 256 * 1024 * 1024 for i in nested),
                             "F4_LEARNING_COMPACT_COMPONENT_COVERAGE_INVALID")
                    inputs = {n: component.read(n) for n in input_names | ({"stop-response.csv"} if stop else set())}
                    task, recipe, training, _, application, *_ = (
                        _f4_stop_component_inputs(inputs) if stop else _f4_native_component_inputs(inputs))
                    if stop:
                        stopping.append({"task": task, "recipe": recipe,
                            "native_function": strict_json_bytes(component.read("native-function.json")),
                            "lock": strict_json_bytes(component.read("lock.json"))})
                    else:
                        training_prediction = strict_json_bytes(component.read("training-prediction.json"))
                        _f4_native_prediction(task, training, training_prediction)
                        prediction = strict_json_bytes(component.read("prediction.json"))
                        rebuilt = _f4_native_prediction(task, application, prediction["survival"][cell["family"]])
                        _require(rebuilt == prediction and prediction["patient_ids"] == cell["validation_ids"],
                                 "F4_LEARNING_COMPACT_COMPONENT_PREDICTION_INVALID")
                        predictions.append(prediction)
                        fitted.append({"task": task, "recipe": recipe,
                                       "fit_health": strict_json_bytes(component.read("fit-health.json"))})
        mean = _pool_prediction_batch([{"sealed_prediction": _seal_prediction_matrix(
            row["patient_ids"], row["survival"][cell["family"]], HORIZONS)} for row in predictions], HORIZONS)["payload"]["survival"]
        prediction = {"patient_ids": cell["validation_ids"], "centers": predictions[0]["centers"],
                      "horizons": HORIZONS, "survival": {cell["family"]: mean}}
        _require(canonical_json_bytes(prediction) == member("prediction.json"), "F4_LEARNING_COMPACT_M5_MEAN_MISMATCH")
        encoded = b"".join(struct.pack("<" + "d" * len(HORIZONS), *row) for row in mean)
        partitions = value("selector/partitions.json")
        body = {"kind": "PADML_F4_LEARNING_CELL_COMPACT_V1", "cell": cell,
            "f1_identity": original["f1_identity"], "model_sha256": original["model_sha256"],
            "source_native_identity": original["identity_sha256"], "selector": selector,
            "selector_recipe": value("selector/k0/recipe/recipe.json"),
            "selector_subsets": [{key: row[key] for key in ("inner_fold", "fit_ids", "evaluation_ids")}
                                 for row in partitions if row["inner_fold"]],
            "mice": mice, "models": fitted, "stops": stopping,
            "mean_prediction": {"encoding": "IEEE754_FLOAT64_LE_ROW_MAJOR", "patient_ids": cell["validation_ids"],
                "centers": prediction["centers"], "horizons": HORIZONS, "imputation_count": 5,
                "sha256": sha256_bytes(encoded), "size_bytes": len(encoded)}, "score": value("score.json")}
    compact = {**body, "identity_sha256": sha256_bytes(canonical_json_bytes(body))}
    result = read_learning_cell_numbers(compact, encoded, frozen_source=frozen_source)
    current = archive_path.stat(follow_symlinks=False)
    _require(all(getattr(current, key) == getattr(source_stat, key) for key in
                 ("st_dev", "st_ino", "st_size", "st_mtime_ns", "st_ctime_ns")),
             "F4_LEARNING_COMPACT_EXPORT_SOURCE_CHANGED")
    write_deterministic_zip(target, {"learning-cell.json": canonical_json_bytes(compact), "mean-survival.f64": encoded})
    return result
