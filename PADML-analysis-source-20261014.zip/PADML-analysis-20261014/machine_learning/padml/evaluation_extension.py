"""Approved MI panel and bounded inference research in existing appendage owners."""
from __future__ import annotations

from pathlib import Path

from . import nested_loco as n
from .bundle import ContractError, canonical_json_bytes, strict_json_bytes

PREFIX = 'evaluation-extension-20261009'
GATE = f'shared/{PREFIX}/research-gate.json'
LIMIT = 16*1024**2
RESEARCH_UNITS = ('FULL0-H06', *(f'PRIMARY-H06-O{i}' for i in range(1,7)))
ENGINEERING_ISSUES = ('ARCHIVE_REQUEST_DRAIN','ARCHIVE_PREIMPORT_REGISTRATION',
    'TRANSFER_INDEX_RECOVERY','REPORT_ANCESTRY_REUSE','SOURCE_ANCESTRY_CAPACITY')
CLOSURE_STEPS = ('original_failure','causal_fix','real_product','direct_consumption','interrupted_recovery')
MI_LABELS = ('IBS_0_36','BRIER_36','UNO_C_36','AUC_36','CALIBRATION_SLOPE_36',
    'CALIBRATION_CITL_36','CALIBRATION_OE_36','CALIBRATION_ICI_BY_HORIZON_36',
    'CALIBRATION_E50_BY_HORIZON_36','CALIBRATION_E90_BY_HORIZON_36')


def need(ok, reason):
    if not ok:
        raise ContractError('EVALUATION_EXTENSION_' + reason)


def validate_mi(value):
    import math
    coordinates=value['coordinates']
    need(len(coordinates)==10 and {v['original_check'] for v in coordinates} ==
        {'ODD_EVEN_'+label+'_NOT_ESTIMABLE' for label in MI_LABELS},'MI_COORDINATE_COVERAGE')
    failures=unavailable=0
    for row in coordinates:
        for name in ('odd','even','absolute_difference'):
            metric=row[name];x=metric['value']
            need(isinstance(metric['reasons'],list) and all(isinstance(r,str) and r for r in metric['reasons']),
                'MI_REASON_INVALID')
            need((x is not None and type(x) in (int,float) and math.isfinite(x)
                    and metric['status']=='ESTIMABLE' and not metric['reasons']) or
                (x is None and metric['status'] in {'NOT_ESTIMABLE','NUMERICAL_FAILURE'} and metric['reasons']),
                'MI_VALUE_STATE_DRIFT')
        a,b,d=(row[k] for k in ('odd','even','absolute_difference'))
        status=('NUMERICAL_FAILURE' if 'NUMERICAL_FAILURE' in {a['status'],b['status']} else
            'NOT_ESTIMABLE' if 'NOT_ESTIMABLE' in {a['status'],b['status']} else 'ESTIMABLE')
        need(d['status']==status and d['reasons']==sorted(set(a['reasons']+b['reasons']))
            and d['value']==(abs(a['value']-b['value']) if status=='ESTIMABLE' else None),'MI_DELTA_DRIFT')
        failures+=status=='NUMERICAL_FAILURE';unavailable+=status=='NOT_ESTIMABLE'
    need(failures==value['unresolved_numerical_failures']==0
        and unavailable==value['statistical_not_estimable'],'MI_COUNTS_DRIFT')
    return value


def decision():
    return n._sealed({'kind':'PADML_RESULT_EXTENSION_RESEARCH_20261009_V1',
        'amendment':'POST_RESULT_DIAGNOSTICS_AND_SUPPLEMENTARY_INFERENCE',
        'mi_units':['FULL0-H06','FULL0-H12','FULL0-H24'],
        'mi_report_month':36, 'mi_centers':['36','38','39','48','52','54'],
        'mi_coordinates':['ibs','brier','uno_c','auc','calibration_slope','citl','oe','ici','e50','e90'],
        'mi_new_calibration_fit_ceiling':18, 'h36_mi':'REFERENCE_UNCHANGED_ORIGINAL_TEN',
        'support':'ORIGINAL_CASES_CONTROLS_G_ESS_REQUIRED_NO_EXTRAPOLATION',
        'candidates':['CENTER_EXP1_STUDENTIZED_WEIGHTED_KM_IF','HIERARCHICAL_LOGIT_AUC'],
        'studentized':{'replicates':1999,'auc_macro_scale':'LOGIT','paired_scale':'IDENTITY',
            'standard_error':'WEIGHTED_EMPIRICAL_CENTER_KM_IF_LINEAR_MASS',
            'failed_draws':'PRESERVE_IDS_NO_DROP_NO_REPLACEMENT',
            'clinical_stream':'REPLAY_ORIGINAL_P1999_PCG64_730000001_UNIVERSE_ORDER'},
        'hierarchical':{'mu_sd':2.5,'tau_prior':'HALFNORMAL', 'main_scale':.5,
            'sensitivity_scales':[.25,1.], 'residual':'CENTER_INTERCEPT_PLUS_COORDINATE_EFFECT',
            'covariance':'FULL_ALIGNED_BRANCH_TIME_OOF_IF_WITH_KM',
            'scope':'SUPPORTED_CENTER_AUC_FIXED_MACROS_AND_PAIRED_DIFFERENCES_NOT_MICRO',
            'integration':'CONDITIONAL_GAUSSIAN_TWO_SCALE_GENERALIZED_LAGUERRE_AND_JOINT_SOBOL',
            'laguerre_orders':[12,24,48], 'sobol_powers':[12,13,14],
            'numerical_mean_absolute_tolerance':.0005,'numerical_endpoint_absolute_tolerance':.001,
            'numerical_normalizer_relative_tolerance':.0001,
            'singular_likelihood':'NUMERICAL_ZERO_SPACE_IS_UNRESOLVED_NOT_A_PROOF_OF_IMPROPRIETY;POSITIVE_DEFINITE_BLOCKS_USE_NORMALIZER_GATE',
            'numerical_exhaustion':'INTEGRATION_NOT_CONVERGED_NO_RIDGE_OR_TOLERANCE_CHANGE'},
        'research':{'pilot_seed':2026100901,'confirmation_seed':2026100902,
            'pilot_datasets_per_scenario':100,'confirmation_datasets_per_scenario':2000,
            'scenarios':8,'report_months':[6,12,24,36], 'observed_event_target_month':12,
            'administrative_followup_month':36,'substreams':'SeedSequence(root,scenario,dataset,domain)',
            'domains':{'data':0,'score_noise':1,'weights':2,'numerical_integration':3},
            'risk_signal_heterogeneity':[.25,.5,.75,1.,1.5,2.],
            'rank_reversal':'OOF-R1_LATENT_Z_COEFFICIENT_ONLY_IN_SIXTH_CENTER',
            'joint_perturbation_ceiling':33583200,'hierarchical_inference_ceiling':25200,
            'gates':{'coverage_min':.94,'wilson95_coverage_lower_min':.925,
                'publication_rate_min':.95,'wilson95_zero_difference_rejection_upper_max':.075},
            'failure_denominator':'EVERY_ORIGINAL_POINT_ESTIMABLE_DATASET',
            'owners':list(RESEARCH_UNITS), 'partition':'LEXICOGRAPHIC_PHASE_SCENARIO_DATASET_ORDINAL_MOD_7',
            'confirmation_used_for_tuning':False, 'stop':'FIXED_BUDGET_NO_NEW_METHOD_OR_SEED'},
        'preserve':['ORIGINAL96','MATCHED_UNO343','M20','MODELS','SHAP','B1000','OLD_IF','OLD_EXP1','RMSE16'],
        'application_coverage':'179_UNIQUE_PER_LINE_CENTER_COUNTS_FROM_ORIGINAL_IDS',
        'clinical_supplement':{'units':'24_PRIMARY_4_FULL0_4_EVALUATION',
            'scope':'ORIGINAL_SUPPORTED_FIXED_PREDICTION_COORDINATES_ONLY',
            'validation':'ALL_REGISTERED_CONFIRMATION_SCENARIOS_FOR_ESTIMAND_AND_REPORT_TIME',
            'population_transport':'CENTER_N91_OR117;JOINT_REQUIRES_REGISTERED_SIX_CENTER_SIZE_PROFILE',
            'branch_transport':'APPARENT_AND_THREE_OOF_ONLY;AAR_COMPARISONS_UNVALIDATED',
            'unvalidated':'EXPLICIT_DISPOSITION_NO_RELIABLE_INTERVAL_NO_EXTRA_COMPUTATION'},
        'closure':{'engineering_issues':list(ENGINEERING_ISSUES),'required_evidence_steps':list(CLOSURE_STEPS),
            'separate_domains':['engineering_defects','required_calculations','new_research',
                'statistical_limitations','controlled_delivery'],
            'task_completion_is_not_chain_acceptance':True},
        'selection_effect':'NONE','risk_projection':'NONE','plotting':False,
        'new_training_mice':0,'new_prediction_model_fits':0,'new_shap_solves':0,
        'archive_resume':'REQUIRES_SUBSEQUENT_EXPLICIT_USER_AUTHORIZATION'})


def eligible(run, unit, source_unit=None):
    return run.get('evaluation_extension') is not None and source_unit is None and (
        unit['unit_id'] in RESEARCH_UNITS or unit['unit_id'] in ('FULL0-H12','FULL0-H24'))


def relative_result(unit):
    return f"units/{unit['unit_id']}/{PREFIX}/result.json"


def validate_result(run, unit, value):
    from .bundle import validate_relative_path, validate_sha256
    from .f4 import _evaluation_check_producer
    from .integrated import same_batch_generations
    need(eligible(run,unit) and run['evaluation_extension'] == decision()
        and value['kind'] == 'PADML_EVALUATION_EXTENSION_UNIT_V1'
        and value['decision_sha256'] == decision()['identity_sha256']
        and value['target_unit'] == unit['unit_id'] and value['status'] == 'COMPLETED'
        and value['direct_consumer_completed'] is True
        and n._sealed({k:v for k,v in value.items() if k != 'identity_sha256'}) == value,
        'RESULT_DRIFT')
    _evaluation_check_producer(value,same_batch_generations(run))
    expected = ({'research'} if unit['unit_id'] in RESEARCH_UNITS else set())
    if unit['kind'] == 'FULL0' and unit['horizon'] in (6,12,24): expected.add('mi')
    if unit['unit_id'] == 'FULL0-H06': expected.update(('application_coverage','h36_mi_reference'))
    need(set(value['components']) == expected,'COMPONENT_COVERAGE')
    prefix = f"units/{unit['unit_id']}/{PREFIX}/"
    paths = set()
    if 'mi' in expected:
        item = value['components']['mi']
        need(item['coordinate_count'] == 10 and item['new_prediction_model_fits'] == 0
            and item['new_evaluation_calibration_fit_ceiling'] == 6,'MI_COMPONENT_DRIFT')
        paths.add(prefix+'mi-diagnostic.json')
    if 'research' in expected:
        from .auc_research import tasks
        coordinates = tasks(unit['unit_id']); item = value['components']['research']
        need(item['dataset_count'] == len(coordinates) and item['P_count'] == len(coordinates)*1999
            and item['hierarchical_inferences'] == 3*sum(t['scenario'] > 4 for t in coordinates),
            'RESEARCH_BUDGET_DRIFT')
        paths.add(prefix+'research/result.json')
    if 'application_coverage' in expected:
        from .f5_application import application_repair_decision
        cohort_prefix = application_repair_decision()['identity_sha256']
        paths.update(f'units/FULL0-H{h:02d}/application-repair/{cohort_prefix}/full-a04/cohort/cohort.json'
            for h in (6,12,24,36))
        paths.update(f'units/FULL0-H{h:02d}/application-repair/{cohort_prefix}/full-a04/result.json'
            for h in (6,12,24,36))
        from .f4 import post_result_repair_root
        base = Path(run['run_root'])
        paths.update((post_result_repair_root(run, next(u for u in run['units']
            if u['unit_id'] == f'FULL0-H{h:02d}'))/'result.json').relative_to(base).as_posix()
            for h in (6,12,24,36))
        paths.add('units/FULL0-H36/post-result-repair-20261008/mi-diagnostic.json')
    need(set(value['sources']) == paths,'SOURCE_COVERAGE')
    for name,pin in value['sources'].items():
        validate_relative_path(name,'evaluation_extension.source')
        validate_sha256(pin['sha256'],'evaluation_extension.source.sha256')
        need(set(pin) == {'sha256','size_bytes'} and type(pin['size_bytes']) is int
            and 0 < pin['size_bytes'] <= LIMIT,'SOURCE_PIN_INVALID')
    return value


def validate_closure_evidence(run, acceptance, evidence):
    """Extend the existing final review; never create a second checker/owner."""
    binding = acceptance.get('evaluation_extension_evidence',{})
    need(set(binding) == {'current_report','review'} and set(binding.values()) <= set(evidence),
        'FINAL_EVIDENCE_REQUIRED')
    current = strict_json_bytes(evidence[binding['current_report']])
    review = strict_json_bytes(evidence[binding['review']])
    need(current['run_identity'] == run['identity']
        and current['decision_sha256'] == decision()['identity_sha256']
        and current['mi_coordinate_count'] == 40 and current['new_mi_coordinates'] == 30
        and current['clinical_supplement']['status']=='ALL_32_SCOPES_DISPOSITION_COMPLETE'
        and len(current['clinical_source_identities'])==32
        and set(current['clinical_supplement']['units'])==set(current['clinical_source_identities'])
        and all(v['coordinate_count']==len(v['rows'])>0 for v in current['clinical_supplement']['units'].values())
        and n._sealed({k:v for k,v in current.items() if k != 'identity_sha256'}) == current,
        'FINAL_REPORT_BINDING_DRIFT')
    closure = review.get('chain_closure',{})
    need(closure.get('report_identity') == current['identity_sha256']
        and closure.get('source_identities') == current['source_identities']
        and set(closure.get('domains',{})) == set(decision()['closure']['separate_domains'])
        and closure.get('unresolved_engineering_defects') == 0
        and closure.get('remaining_required_calculations') == 0, 'FINAL_CHAIN_INCOMPLETE')
    domains=closure['domains']
    expected_domains={'engineering_defects':'CLOSED_WITH_CHAIN_EVIDENCE',
        'required_calculations':current['completion_domains']['required_diagnostics']['status'],
        'new_research':current['research']['status'],
        'statistical_limitations':current['completion_domains']['statistical_limitations']['status'],
        'controlled_delivery':current['completion_domains']['delivery']['status']}
    need(all(isinstance(domains[k],dict) and domains[k].get('status')==v
        and domains[k].get('report_identity')==current['identity_sha256'] for k,v in expected_domains.items()),
        'FINAL_DOMAIN_STATUS_DRIFT')
    issues = closure.get('engineering_issues',{})
    need(set(issues) == set(ENGINEERING_ISSUES),'FINAL_ISSUE_COVERAGE')
    for issue,row in issues.items():
        need(row.get('status') == 'CLOSED' and set(row.get('evidence',{})) == set(CLOSURE_STEPS),
            'FINAL_ISSUE_EVIDENCE_INCOMPLETE:'+issue)
        for step,names in row['evidence'].items():
            need(isinstance(names,list) and names and set(names) <= set(evidence),
                'FINAL_ISSUE_EVIDENCE_MISSING:'+issue+':'+step)
    confirmed=[r for r in current['research']['coordinates'] if r['coordinate'][0]=='confirmation']
    disposition=('ALL_REGISTERED_SCOPES_VALIDATED' if confirmed and all(
        r['status']=='VALIDATED_REGISTERED_SCOPE' for r in confirmed)
        else 'COMPLETED_WITH_FAILED_OR_UNVALIDATED_SCOPES')
    need(closure.get('research_disposition') == disposition
        and closure.get('statistical_limits_preserved') is True
        and closure.get('archive_user_authorization_required') is True,'FINAL_DOMAINS_CONFLATED')
    need(all(r['status']!='NUMERICAL_FAILURE' and r['original']['status']!='NUMERICAL_FAILURE'
        for unit in current['clinical_supplement']['units'].values() for r in unit['rows']),
        'FINAL_CLINICAL_NUMERICAL_FAILURE_OPEN')
    return current


def read_result(run, unit, *, observation=False):
    from .carriers import source_bytes
    from .integrated import qualified_file_pins, same_batch_generations
    from .f4 import _evaluation_check_producer
    path = Path(run['run_root'])/relative_result(unit)
    if not path.is_file():
        return None
    value = validate_result(run,unit,strict_json_bytes(source_bytes(path, limit=LIMIT)))
    paths = {name:Path(run['run_root'])/name for name in value['sources']}
    hit = qualified_file_pins(paths, identity=value['identity_sha256'], expected=value['sources'],
        record=path.with_name('result.qualified.json'), validate=lambda:None, cached_only=observation)
    return value if hit is not None else None


def run_extension(run, unit):
    from .carriers import source_pin
    from .f4 import _post_result_full0_bindings, _run_full0_six_center_mi, _evaluation_provenance
    need(eligible(run,unit) and run['evaluation_extension'] == decision(), 'OWNER_SCOPE')
    saved = read_result(run,unit)
    if saved is not None:
        return saved
    base = Path(run['run_root']); root = base/'units'/unit['unit_id']/PREFIX
    root.mkdir(parents=True,exist_ok=True)
    components, sources = {}, {}
    if unit['kind'] == 'FULL0' and unit['horizon'] in (6,12,24):
        original, lineage, compiled, inputs = _post_result_full0_bindings(run,unit)
        from .runtime import admit_stage, MIN_WORKER_MEMORY_BYTES
        admit_stage(run['resource_policy'],root,legal_tasks=1,retained_bytes=512*1024,
            transient_bytes_per_worker=64*1024**2,publication_bytes=512*1024,
            memory_bytes_per_worker=max(MIN_WORKER_MEMORY_BYTES,512*1024**2))
        mi = _run_full0_six_center_mi(run,unit,original,lineage=lineage,sources=inputs)
        validate_mi(mi)
        need(len(mi['coordinates']) == 10 and mi['unresolved_numerical_failures'] == 0,
            'MI_NUMERICAL_FAILURE')
        components['mi'] = {'source_identity':mi['identity_sha256'],'coordinate_count':10,
            'new_evaluation_calibration_fit_ceiling':6,'new_prediction_model_fits':0}
        sources[(root/'mi-diagnostic.json').relative_to(base).as_posix()] = source_pin(root/'mi-diagnostic.json')
    if unit['unit_id'] == 'FULL0-H06':
        from .f5_application import application_repair_decision
        from collections import Counter
        lines, union = {}, set()
        for h in (6,12,24,36):
            path = base/f'units/FULL0-H{h:02d}/application-repair'/application_repair_decision()['identity_sha256']/\
                'full-a04/cohort/cohort.json'
            from .carriers import validate_reference
            from .f4 import post_result_repair_root
            original_unit=next(u for u in run['units'] if u['unit_id']==f'FULL0-H{h:02d}')
            parent = strict_json_bytes((post_result_repair_root(run,original_unit)/'result.json').read_bytes())
            from .f4 import _evaluation_check_producer,_evaluation_provenance
            _evaluation_check_producer(parent,_evaluation_provenance(run)['generations'])
            need(n._sealed({k:v for k,v in parent.items() if k != 'identity_sha256'}) == parent,
                'APPLICATION_PARENT_DRIFT')
            completed_refs = [r for r in parent['formal_references']
                if r['role'] == 'COMPLETE_A04_APPLICATION_COHORT']
            need(len(completed_refs) == 1 and completed_refs[0]['path'] ==
                (path.parent.parent/'result.json').relative_to(base).as_posix(),
                'APPLICATION_COMPLETION_REFERENCE_MISSING')
            validate_reference(completed_refs[0],run)
            completion = strict_json_bytes((path.parent.parent/'result.json').read_bytes())
            need(completion['binding']['unit_id'] == f'FULL0-H{h:02d}'
                and completion['binding']['decision_sha256'] == application_repair_decision()['identity_sha256']
                and n._sealed({k:v for k,v in completion.items() if k != 'identity_sha256'}) == completion,
                'APPLICATION_COMPLETION_DRIFT')
            refs = [r for r in completion['formal_references'] if r['role'] == 'A04_APPLICATION_COHORT']
            need(len(refs) == 1 and refs[0]['path'] == path.relative_to(base).as_posix(),
                'APPLICATION_FROZEN_COHORT_MISSING')
            validate_reference(refs[0],run)
            cohort = strict_json_bytes(path.read_bytes())
            ids = [pid for c in cohort['centers'] for pid in c['selected_ids']]
            counts = {c['center']:len(c['selected_ids']) for c in cohort['centers']}
            need(len(ids) == len(set(ids)) == cohort['patient_count'] == 179
                and counts == {'36':50,'38':2,'39':50,'48':12,'52':50,'54':15},'APPLICATION_COVERAGE_DRIFT')
            union.update(ids)
            lines[str(h)] = {'patient_count':len(ids),'center_counts':counts,
                'patient_order_sha256':n._sha(ids),'source':path.relative_to(base).as_posix()}
            sources[path.relative_to(base).as_posix()] = source_pin(path)
            for head_path in (post_result_repair_root(run,original_unit)/'result.json',path.parent.parent/'result.json'):
                sources[head_path.relative_to(base).as_posix()]=source_pin(head_path)
        need(len(union) == 179,'APPLICATION_CROSS_LINE_PATIENT_DRIFT')
        components['application_coverage'] = {'lines':lines,'unique_patients_across_four_lines':len(union),
            'line_patient_assessments':716,'original_regression_coordinates':96,
            'limitation':'CENTER38_HAS_ONLY_TWO_APPLICATION_PATIENTS'}
        # Reference the original ten, including their actual patient identity;
        # a report's population label alone cannot establish matched rows.
        path = base/'units/FULL0-H36/post-result-repair-20261008/mi-diagnostic.json'
        original = strict_json_bytes(path.read_bytes())
        need(original['binding']['source_unit'] == 'FULL0-H36'
            and original['status'] == 'COMPLETED' and len(original['coordinates']) == 10
            and original['unresolved_numerical_failures'] == 0
            and n._sealed({k:v for k,v in original.items() if k != 'identity_sha256'}) == original,
            'H36_REFERENCE_DRIFT')
        from .carriers import validate_reference
        for ref in original['formal_references']: validate_reference(ref,run)
        components['h36_mi_reference'] = {'source_identity':original['identity_sha256'],
            'source':path.relative_to(base).as_posix(),'new_calibration_fits':0}
        sources[path.relative_to(base).as_posix()] = source_pin(path)
    if unit['unit_id'] in RESEARCH_UNITS:
        from .auc_research import run_research
        result = run_research(run,unit)
        components['research'] = {k:result[k] for k in ('identity_sha256','dataset_count','P_count',
            'hierarchical_inferences','reliability')}
        sources[(root/'research/result.json').relative_to(base).as_posix()] = source_pin(root/'research/result.json')
    value = n._sealed({'kind':'PADML_EVALUATION_EXTENSION_UNIT_V1','target_unit':unit['unit_id'],
        'decision_sha256':decision()['identity_sha256'], 'producer':_evaluation_provenance(run)['producer'],
        'status':'COMPLETED','direct_consumer_completed':True,'sources':sources,'components':components,
        'archive_status':'PAUSED_REQUIRES_NEW_USER_AUTHORIZATION'})
    n._write_exact_once(root/'result.json',canonical_json_bytes(value),'EVALUATION_EXTENSION_PUBLICATION_DRIFT')
    return read_result(run,unit)


def qualify_retained_prerequisites(run,unit):
    """Repair qualification only; missing historical science is not recomputed."""
    from . import f4,curve_rmse,result_closure
    if not f4.evaluation_appendix_observation(run,unit):
        original = f4._evaluation_appendix_read(f4.evaluation_appendix_root(run,unit),run,unit)
        need(original is not None,'RETAINED_APPENDIX_MISSING')
        need(f4._post_result_repair_read(run,unit,None,original) is not None,
            'RETAINED_REPAIR_MISSING')
        if curve_rmse.eligible(run,unit):
            need(curve_rmse.read_result(run,unit) is not None,'RETAINED_CURVE_MISSING')
    if result_closure.eligible(run,unit):
        need(result_closure.read_result(run,unit) is not None,'RETAINED_CLOSURE_MISSING')


def clinical_eligible(run,unit):
    return run.get('evaluation_extension') is not None and unit['kind'] in {'PRIMARY','FULL0','EVALUATION'}


def clinical_name(unit):
    return f"units/{unit['unit_id']}/{PREFIX}/clinical.json"


def research_gate(run,study,sources):
    groups={}
    seen=set()
    for row in study['coordinates']:
        phase,_,method,scope,h,branch=row['coordinate']
        if phase!='confirmation':continue
        key=tuple(row['coordinate'])
        need(key not in seen,'CONFIRMATION_COORDINATE_DUPLICATE');seen.add(key)
        scope=('CENTER' if scope not in {'MICRO','EQUAL_CENTER','PATIENT_WEIGHTED_CENTER'} else scope)
        name='|'.join((method,scope,str(h),branch))
        item=groups.setdefault(name,{'confirmed':0,'failed':0})
        item['confirmed']+=1;item['failed']+=row['status']!='VALIDATED_REGISTERED_SCOPE'
    need(len(seen)==4144,'CONFIRMATION_COORDINATE_COVERAGE')
    return n._sealed({'kind':'PADML_AUC_RESEARCH_CLINICAL_GATE_V1','run_id':run['run_id'],
        'raw_input_sha256':n._sha(run['raw_input']),
        'summary_sha256':n._sha(study),
        'decision_sha256':decision()['identity_sha256'],'source_identities':sources,
        'registered_datasets':study['dataset_count'],'scope_results':groups,
        'reliability':'SIMULATION_SCOPE_IS_NOT_A_CLINICAL_CENTER_COVERAGE_RATE'})


def validate_gate(run,value):
    from .auc_research import BRANCHES,MONTHS
    names=(*BRANCHES,'OOF-MEAN','APPARENT_MINUS_OOF_MEAN','OOF-R1_MINUS_OOF-R2')
    expected={}
    for method in ('STUDENTIZED','HIERARCHICAL_0.5','HIERARCHICAL_0.25','HIERARCHICAL_1.0'):
        counts=({'CENTER':28,'MICRO':8,'EQUAL_CENTER':8,'PATIENT_WEIGHTED_CENTER':8} if method=='STUDENTIZED'
            else {'CENTER':24,'EQUAL_CENTER':4,'PATIENT_WEIGHTED_CENTER':4})
        for scope,count in counts.items():
            for h in MONTHS:
                for name in names:expected['|'.join((method,scope,str(h),name))]=count
    need(value['kind']=='PADML_AUC_RESEARCH_CLINICAL_GATE_V1'
        and value['run_id']==run['run_id'] and value['raw_input_sha256']==n._sha(run['raw_input'])
        and value['decision_sha256']==decision()['identity_sha256']
        and value['registered_datasets']==16800 and set(value['scope_results'])==set(expected)
        and all(set(value['scope_results'][k])=={'confirmed','failed'}
            and value['scope_results'][k]['confirmed']==count
            and type(value['scope_results'][k]['failed']) is int
            and 0<=value['scope_results'][k]['failed']<=count for k,count in expected.items())
        and set(value['source_identities'])==set(RESEARCH_UNITS)|{'FULL0-H12','FULL0-H24'}
        and n._sealed({k:v for k,v in value.items() if k!='identity_sha256'})==value,
        'CLINICAL_GATE_DRIFT')
    return value


def publish_gate(run,value):
    validate_gate(run,value)
    target=Path(run['run_root'])/GATE;target.parent.mkdir(parents=True,exist_ok=True)
    n._write_exact_once(target,canonical_json_bytes(value),'EVALUATION_EXTENSION_GATE_PUBLICATION_DRIFT')
    return {'status':'PUBLISHED','identity_sha256':value['identity_sha256']}


def clinical_numbers(table):
    from .f4 import _evaluation_contrasts
    # Derived estimates are algebraic consumers of these same original points.
    # The original point archive remains byte-for-byte unchanged.
    return _evaluation_contrasts({name:{'auc':numbers['auc']} for name,numbers in table['numbers'].items()
        if not name.startswith('KM-') and '_MINUS_' not in name and name!='OOF-MEAN' and 'auc' in numbers})


def clinical_qualification(unit,table,name,method,gate):
    from .auc_research import BRANCHES
    scope=table['scope'];h=table['report_month'];source=table['original']
    need(method in {'STUDENTIZED','HIERARCHICAL_0.5','HIERARCHICAL_0.25','HIERARCHICAL_1.0'},'CLINICAL_METHOD_INVALID')
    key='|'.join((method,scope if scope in {'MICRO','EQUAL_CENTER','PATIENT_WEIGHTED_CENTER'} else 'CENTER',str(h),name))
    qualification=gate['scope_results'].get(key)
    if source['value'] is None:reasons=['ORIGINAL_POINT_NOT_ESTIMABLE',*source['reasons']]
    elif method.startswith('HIERARCHICAL') and scope=='MICRO':reasons=['METHOD_NOT_APPLICABLE_TO_MICRO']
    elif unit['kind']=='EVALUATION' or name not in (*BRANCHES,'OOF-MEAN','APPARENT_MINUS_OOF_MEAN'):
        reasons=['BRANCH_DESIGN_NOT_VALIDATED_BY_REGISTERED_RESEARCH']
    elif not qualification or qualification['failed']:reasons=['REGISTERED_CONFIRMATION_SCOPE_FAILED_OR_NOT_VALIDATED']
    elif scope in {'MICRO','EQUAL_CENTER','PATIENT_WEIGHTED_CENTER'} or method.startswith('HIERARCHICAL'):
        reasons=['JOINT_CLINICAL_POPULATION_NOT_VALIDATED_BY_REGISTERED_SIZE_PROFILE']
    elif table['patient_count'] not in (91,117):reasons=['CENTER_SIZE_OUTSIDE_REGISTERED_CONFIRMATION_PROFILE']
    else:reasons=[]
    return key,qualification,reasons


def read_clinical(run,unit,*,observation=False):
    path=Path(run['run_root'])/clinical_name(unit)
    if not path.is_file():return None
    value=strict_json_bytes(path.read_bytes())
    gate=validate_gate(run,strict_json_bytes((Path(run['run_root'])/GATE).read_bytes()))
    validate_clinical(run,unit,value,gate)
    from .integrated import qualified_file_pins
    refs=value['formal_references']
    pins={r['path']:{k:r[k] for k in ('sha256','size_bytes')} for r in refs}
    def validate_point():
        from .carriers import open_carrier
        from .f4 import evaluation_appendix_root
        with open_carrier(evaluation_appendix_root(run,unit)/'point.zip') as archive:
            point=strict_json_bytes(archive.read('point.json'))
        expected={(k,name,method) for k,t in point['tables'].items()
            for name,numbers in clinical_numbers(t).items()
            for method in ('STUDENTIZED','HIERARCHICAL_0.5','HIERARCHICAL_0.25','HIERARCHICAL_1.0')}
        need({(r['table'],r['branch'],r['method']) for r in value['rows']}==expected,'CLINICAL_COORDINATE_COVERAGE')
        need(all(r['original']==clinical_numbers(point['tables'][r['table']])[r['branch']]['auc']
            for r in value['rows']), 'CLINICAL_ORIGINAL_POINT_DRIFT')
        need(all(r['patient_count']==point['tables'][r['table']]['patient_count']
            and r['centers']==point['tables'][r['table']]['centers']
            and r['patient_order_sha256']==point['tables'][r['table']].get('patient_order_sha256')
            and r['fixed_center_counts']==point['tables'][r['table']].get('fixed_center_counts')
            for r in value['rows']), 'CLINICAL_POPULATION_REFERENCE_DRIFT')
    hit=qualified_file_pins({name:Path(run['run_root'])/name for name in pins},
        identity=value['identity_sha256'],expected=pins,record=path.with_name('clinical.qualified.json'),
        validate=validate_point,cached_only=observation)
    return value if hit is not None else None


def validate_clinical(run,unit,value,gate):
    from .f4 import _evaluation_check_producer,_evaluation_provenance,evaluation_appendix_root
    _evaluation_check_producer(value,_evaluation_provenance(run)['generations'])
    need(clinical_eligible(run,unit) and value['kind']=='PADML_AUC_CLINICAL_SUPPLEMENT_DISPOSITION_V1'
        and value['target_unit']==unit['unit_id'] and value['gate_identity']==gate['identity_sha256']
        and value['status']=='DISPOSITION_COMPLETE'
        and value['coordinate_count']==len(value['rows'])>0
        and len({(r['table'],r['branch'],r['method']) for r in value['rows']})==len(value['rows'])
        and value['new_prediction_model_fits']==value['new_training_mice']==value['new_shap_solves']==value['new_resampling']==0
        and n._sealed({k:v for k,v in value.items() if k!='identity_sha256'})==value,
        'CLINICAL_RESULT_DRIFT')
    for row in value['rows']:
        role,month,scope=row['table'].split('/')
        need(role in {'PRIMARY','SIX_CENTER_SENSITIVITY'} and month in {'H06','H12','H24','H36'},'CLINICAL_TABLE_DRIFT')
        key,qualification,reasons=clinical_qualification(unit,
            {**row,'report_month':int(month[1:]),'scope':scope},row['branch'],row['method'],gate)
        need(row['confirmation_key']==key and row['confirmation']==qualification, 'CLINICAL_QUALIFICATION_DRIFT')
        if reasons:
            need(row['interval'] is None and row['new_point'] is None and row['reasons']==reasons,
                'CLINICAL_INELIGIBLE_INTERVAL')
        else:
            need(row['original']['status']=='ESTIMABLE' and row['original']['value'] is not None
                and type(row['new_point']) in (float,int)
                and abs(row['new_point']-row['original']['value'])<=1e-12 and row.get('P_count')==1999,
                'CLINICAL_ESTIMATE_OR_P_DRIFT')
            invalid=row.get('invalid_P_ids')
            need(isinstance(invalid,list) and invalid==sorted(set(invalid)) and all(type(i) is int and 1<=i<=1999 for i in invalid),
                'CLINICAL_P_IDS_DRIFT')
        if row['interval'] is not None:
            import math
            need(row['confirmation'] is not None and row['confirmation']['failed']==0
                and row['status']=='CONDITIONAL_SUPPLEMENT_WITH_REGISTERED_SCOPE_VALIDATION'
                and not reasons and not row['invalid_P_ids'] and not row.get('failure_P_ids',{})
                and value.get('clinical_rng_universe') is not None
                and not row['reasons'] and len(row['interval'])==2
                and all(math.isfinite(v) for v in row['interval']) and row['interval'][0]<=row['interval'][1],
                'CLINICAL_INTERVAL_NOT_QUALIFIED')
        else:need(row['reasons'] and row['status'] in {'NOT_ESTIMABLE','NOT_VALIDATED_FOR_THIS_CLINICAL_SCOPE',
            'NUMERICAL_FAILURE','UNRELIABLE'}, 'CLINICAL_DISPOSITION_MISSING')
    expected={GATE,(evaluation_appendix_root(run,unit)/'point.zip').relative_to(Path(run['run_root'])).as_posix()}
    if value.get('clinical_rng_universe') is not None:
        from .bundle import validate_sha256
        universe=value['clinical_rng_universe']
        validate_sha256(universe['patient_order_sha256'],'clinical.universe')
        need(universe['seed']==730000001 and type(universe['patient_count']) is int and universe['patient_count']>0,
            'CLINICAL_UNIVERSE_INVALID')
        expected.add('binding/binding.json')
    need(len(value['formal_references'])==len(expected) and {r['path'] for r in value['formal_references']}==expected,
        'CLINICAL_SOURCE_COVERAGE')
    return value


def run_clinical(run,unit):
    """A second existing appendage pass, gated by completed independent research."""
    from . import auc_research as a,f4
    from .carriers import open_carrier,file_reference
    from .runtime import admit_stage
    from .integrated import load_raw_binding
    import numpy as np
    base=Path(run['run_root']);root=base/'units'/unit['unit_id'];target=base/clinical_name(unit)
    need(clinical_eligible(run,unit),'CLINICAL_SCOPE_INVALID')
    gate=validate_gate(run,strict_json_bytes((base/GATE).read_bytes()))
    qualify_retained_prerequisites(run,unit)
    if eligible(run,unit):
        original_extension=read_result(run,unit)
        need(original_extension is not None and original_extension['identity_sha256']==
            gate['source_identities'][unit['unit_id']],'CLINICAL_RESEARCH_SOURCE_REQUIRED')
    saved=read_clinical(run,unit)
    def retire_partial():
        partial=target.parent/'clinical-partial'
        if not partial.exists() and not partial.is_symlink():return
        need(partial.is_dir() and not partial.is_symlink() and partial.resolve()==partial.absolute(),
            'CLINICAL_PARTIAL_DRIFT')
        for folder in partial.iterdir():
            need(folder.is_dir() and not folder.is_symlink(),'CLINICAL_PARTIAL_DRIFT')
            a.retire_private_publication_members(folder,{f'P{i:04d}.zip' for i in range(1,2000,32)})
        partial.rmdir()
    if saved is not None:
        a.retire_accepted_publication_temps(target);retire_partial();return saved
    admit_stage(run['resource_policy'],root,legal_tasks=1,retained_bytes=2*1024**2,
        publication_bytes=2*1024**2,transient_bytes_per_worker=64*1024**2,
        memory_bytes_per_worker=1024**3)
    original_root=f4.evaluation_appendix_root(run,unit)
    original=f4._evaluation_appendix_read(original_root,run,unit)
    need(original is not None,'CLINICAL_ORIGINAL_POINT_REQUIRED')
    with open_carrier(original_root/'point.zip') as carrier:point=strict_json_bytes(carrier.read('point.json'))
    rows=[];needed={};rng_universe=None
    for table_key,table in point['tables'].items():
        scope=table['scope'];h=table['report_month']
        numbers=clinical_numbers(table);names=list(numbers)
        for name in names:
            source=numbers[name]['auc']
            for method in ('STUDENTIZED','HIERARCHICAL_0.5','HIERARCHICAL_0.25','HIERARCHICAL_1.0'):
                key,qualification,reasons=clinical_qualification(unit,{**table,'original':source},name,method,gate)
                row={'table':table_key,'branch':name,'method':method,'original':source,
                    'patient_count':table['patient_count'],'centers':table['centers'],
                    'fixed_center_counts':table.get('fixed_center_counts'),
                    'patient_order_sha256':table.get('patient_order_sha256'),'interval':None,'new_point':None,
                    'status':'NOT_ESTIMABLE' if source['value'] is None else 'NOT_VALIDATED_FOR_THIS_CLINICAL_SCOPE',
                    'reasons':reasons,'confirmation_key':key,'confirmation':qualification}
                row.update(method_confirmation='PASSED_REGISTERED_SCENARIOS' if qualification and not qualification['failed']
                    else 'FAILED_OR_UNVALIDATED_REGISTERED_SCENARIOS',clinical_transport='NOT_ESTABLISHED_BY_SIMULATION')
                rows.append(row)
                if not reasons:needed.setdefault((scope,table['patient_order_sha256']),[]).append(row)
    if needed:
        view,_,_=f4._post_result_original_view(run,unit,root,original,need_draws=False)
        frozen=load_raw_binding(base/'binding',expected_input=run['raw_input'])
        universe=list(frozen['centers']);positions={pid:i for i,pid in enumerate(universe)}
        need(frozen['receipt']['run_id']==run['run_id'] and frozen['receipt']['source_identity'] in
            set(f4._evaluation_provenance(run)['generations'].values()),'CLINICAL_UNIVERSE_SOURCE_DRIFT')
        rng_universe={'patient_order_sha256':n._sha(universe),'patient_count':len(universe),
            'source_identity':frozen['receipt']['source_identity'],'seed':730000001}
        for (scope,patient_order),consumers in needed.items():
            idx=[i for i,c in enumerate(view['centers']) if c==scope]
            selected=f4._evaluation_projection(view['patient_ids'],view['centers'],view['response_csv'],view['matrices'],idx)
            need(selected['projection_sha256']==patient_order,'CLINICAL_PATIENT_ORDER_DRIFT')
            need(all(len(selected['patient_ids'])==r['patient_count'] and sorted(set(selected['centers']))==r['centers']
                for r in consumers),'CLINICAL_POPULATION_DRIFT')
            fields,response=f4._response_rows(selected['response_csv'])
            ts,ev=f4._response_arrays(f4._write_response_subset(fields,response,selected['patient_ids'],None),selected['patient_ids'])
            months={point['tables'][r['table']]['report_month'] for r in consumers}
            risk={(h,name):np.array([1-r[h] for r in matrix]) for name,matrix in selected['matrices'].items()
                if name in a.BRANCHES for h in sorted(months)}
            prepared=a.prepare(selected['patient_ids'],ts,ev,selected['centers'],risk,scopes={scope})
            class ProjectedGenerator:
                def __init__(self):self.raw=np.random.Generator(np.random.PCG64(730000001))
                @property
                def bit_generator(self):return self.raw.bit_generator
                def exponential(self,size):
                    return self.raw.exponential(size=(size[0],len(universe)))[:,[positions[p] for p in selected['patient_ids']]]
            values=a.studentized(prepared,ProjectedGenerator(),progress=target.parent/'clinical-partial'/f'{scope}-{patient_order[:16]}',
                binding={'gate':gate['identity_sha256'],'unit':unit['unit_id'],'patient_order':patient_order,'scope':scope,
                    'original_point_identity':point['identity_sha256'],'rng_universe':rng_universe})
            for row in consumers:
                h=point['tables'][row['table']]['report_month'];key=(scope,h,row['branch'])
                need(abs(prepared['original'][key]['value']-row['original']['value'])<=1e-12,'CLINICAL_POINT_DRIFT')
                value=values[key];row.update(new_point=value['point'],interval=value['interval'],reasons=value['reasons'],
                    status='CONDITIONAL_SUPPLEMENT_WITH_REGISTERED_SCOPE_VALIDATION' if value['interval'] is not None else value['status'],
                    P_count=1999,invalid_P_ids=value['invalid_P_ids'],failure_P_ids=value.get('failure_P_ids',{}))
    result=n._sealed({'kind':'PADML_AUC_CLINICAL_SUPPLEMENT_DISPOSITION_V1','target_unit':unit['unit_id'],
        'gate_identity':gate['identity_sha256'],'producer':f4._evaluation_provenance(run)['producer'],
        'status':'DISPOSITION_COMPLETE','rows':rows,'coordinate_count':len(rows),
        'clinical_rng_universe':rng_universe,
        'new_prediction_model_fits':0,'new_training_mice':0,'new_shap_solves':0,'new_resampling':0,
        'inference':'FIXED_PREDICTIONS;REGISTERED_SIMULATION_COVERAGE_IS_NOT_ACTUAL_CLINICAL_COVERAGE',
        'formal_references':[file_reference(base/GATE,'INDEPENDENT_CONFIRMATION_GATE',run),
            file_reference(original_root/'point.zip','ORIGINAL_EVALUATION_POINT',run)]+
            ([file_reference(base/'binding/binding.json','ORIGINAL_P_PATIENT_UNIVERSE',run)] if rng_universe else [])})
    target.parent.mkdir(parents=True,exist_ok=True)
    validate_clinical(run,unit,result,gate)
    n._write_exact_once(target,canonical_json_bytes(result),'CLINICAL_PUBLICATION_DRIFT')
    result=read_clinical(run,unit);a.retire_accepted_publication_temps(target);retire_partial()
    return result
