"""Post-lock diagnostics for current raw-data PRIMARY/FULL0 contexts.

These functions call the original numerical kernels. They never alter the
selector, family lock, or original unit receipt and have no separate scheduler.
"""
from __future__ import annotations

from .runtime import MIN_WORKER_MEMORY_BYTES

import copy
import tempfile
from pathlib import Path

from .bundle import ContractError, canonical_json_bytes, strict_json_bytes, sha256_file
from . import nested_loco as n


def _need(condition, reason):
    if not condition:
        raise ContractError(reason)


def _read(path):
    return strict_json_bytes(path.read_bytes())


def _save(path, body):
    result = n._sealed(body)
    n._write_exact_once(path, canonical_json_bytes(result), "DIAGNOSTIC_RESULT_DRIFT")
    return result


# Native task inputs already bind each MI, population, outcome, candidates,
# transforms, seed and threads. Exclude only surrounding-view lineage.
def _sensitivity_task_input(task):
    lineage = {"outer_partition_id", "analysis_view_sha256", "fit_covariate_member_set_sha256"}
    return {k: v for k, v in task.items() if k not in lineage}


_SENSITIVITY_ADAPTER_FUNCTIONS = {
    "_require", "_finite_number", "_sha", "predictor_contract", "_validate_transform_conflicts",
    "_recipe_training_member_bytes", "_recipe_training_rows_bytes", "_contains_recipe_forbidden_role",
    "_materialize_recipe_training_member", "_recipe_partition_projection",
    "_selector_sensitivity_seed", "_selector_sensitivity_task_spec_record",
    "_validate_selector_sensitivity_numerics", "_r_failure_reason",
    "_run_r_selector_sensitivity_pool_task", "_run_r_selector_sensitivity_shared_pool_task",
    "_run_selector_sensitivity_method",
}
_SENSITIVITY_NATIVE_MEMBERS = (
    "padml/kernels/f2_model_development.R", "padml/kernels/f5_design.R",
    "padml/_science_authority.py", "padml/science/authority.json",
    "padml/science/variable.csv", "dependency-lock.json",
    "padml/kernels/native/mrmre-performance.patch", "padml/kernels/native/ranger-performance.patch",
)


_SENSITIVITY_BUNDLE_FUNCTIONS = {
    "ContractError", "_reject_nonfinite", "canonical_json_bytes", "strict_json_bytes", "sha256_bytes",
    "sha256_file", "_remember_qualified_digest",
}


def _sensitivity_python_dependency(raw, required):
    # Exact source slices; ast.dump identities vary between Python versions.
    import ast
    source = raw.decode("utf-8")
    tree = ast.parse(source)
    definitions = {node.name: node for node in tree.body
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)) and node.name in required}
    if set(definitions) != required:
        return None  # An older adapter with a different closure is not reusable.
    names = {node.id for fn in definitions.values() for node in ast.walk(fn) if isinstance(node, ast.Name)}
    assignments = [node for node in tree.body if isinstance(node, ast.Assign)
        and any(isinstance(t, ast.Name) and t.id in names for t in node.targets)]
    names |= {item.id for node in assignments for item in ast.walk(node) if isinstance(item, ast.Name)}
    imports, constants = [], {}
    for node in tree.body:
        if isinstance(node, (ast.Import, ast.ImportFrom)):
            for alias in node.names:
                if (alias.asname or alias.name.split(".")[0]) in names:
                    imports.append([getattr(node, "level", 0), getattr(node, "module", None), alias.name, alias.asname])
        elif node in assignments:
            constants[ast.get_source_segment(source, node).split("=", 1)[0].strip()] = ast.get_source_segment(source, node)
    return n._sha({"definitions": {name: {"body": ast.get_source_segment(source, node),
        "decorators": [ast.get_source_segment(source, item) for item in node.decorator_list]}
        for name, node in definitions.items()}, "imports": imports, "constants": constants})


def _sensitivity_dependencies(members, adapter, bundle):
    # R keeps all hardcoded options and its sourced design helper. Installed
    # native/transitive libraries remain bound to the actual qualified lock.
    from .bundle import sha256_bytes
    _need(all(name in members for name in (*_SENSITIVITY_NATIVE_MEMBERS, "padml/f2_kernel.py", "padml/bundle.py"))
        and sha256_bytes(adapter) == members["padml/f2_kernel.py"]
        and sha256_bytes(bundle) == members["padml/bundle.py"], "DIAGNOSTIC_ADAPTER_DRIFT")
    adapter_identity = _sensitivity_python_dependency(adapter, _SENSITIVITY_ADAPTER_FUNCTIONS)
    serialization_identity = _sensitivity_python_dependency(bundle, _SENSITIVITY_BUNDLE_FUNCTIONS)
    if adapter_identity is None or serialization_identity is None:
        return None
    return {"native_members": {name: members[name] for name in _SENSITIVITY_NATIVE_MEMBERS},
        "adapter": adapter_identity, "serialization": serialization_identity}


def _sensitivity_sources(run):
    # Qualify each same-batch producer once for the forty tasks. No globbing,
    # arbitrary source folders, lock-version equivalence, or rewritten provenance.
    from .f4 import _f45_source_member_sha256, load_f45_source_bundle
    from .run import f45_unit_predecessors, _f45_predecessor_paths
    from .integrated import is_integrated
    import zipfile
    _need(is_integrated(run), "DIAGNOSTIC_RAW_RUN_REQUIRED")
    current = _f45_source_member_sha256()
    _need(n._sha(current) == run["source_identity"], "DIAGNOSTIC_SOURCE_DRIFT")
    python_sources = {name: (Path(__file__).parent.parent / name).read_bytes()
        for name in ("padml/f2_kernel.py", "padml/bundle.py")}
    dependencies = _sensitivity_dependencies(current, *python_sources.values())
    _need(dependencies is not None, "DIAGNOSTIC_ADAPTER_DRIFT")
    producers = [run["source_identity"]]
    previous = f45_unit_predecessors(run)
    for owner in previous:
        # Every pin below has already passed f45_unit_predecessors. The same
        # source ZIP SHA binds the same source bytes even for a pretty run JSON.
        pins = [pin for parent in (run, *previous) for pin in
            (([parent["unit_predecessor"]] if parent.get("unit_predecessor") else [])
             + parent.get("unit_source_predecessors", []))
            if pin["source_sha256"] == owner["source_bundle_sha256"]]
        _need(pins, "DIAGNOSTIC_PRODUCER_DRIFT")
        source_path = _f45_predecessor_paths(pins[0])[1]
        manifest = load_f45_source_bundle(source_path)
        members = {row["path"]: row["sha256"] for row in manifest["members"]}
        _need(n._sha(members) == owner["source_identity"], "DIAGNOSTIC_PRODUCER_DRIFT")
        if any(members.get(name) != current[name] for name in _SENSITIVITY_NATIVE_MEMBERS):
            continue
        if all(members.get(name) == current[name] for name in python_sources):
            producers.append(owner["source_identity"])
            continue
        # The existing predecessor reader qualified both physical SHA pins,
        # source members and scientific contract; no canonical-run SHA guess.
        with zipfile.ZipFile(source_path) as archive:
            old_python = [raw if members.get(name) == current[name] else archive.read(name)
                for name, raw in python_sources.items()]
        if _sensitivity_dependencies(members, *old_python) == dependencies:
            producers.append(owner["source_identity"])
    return dependencies, producers


def _sensitivity_compute_identity(task, dependencies):
    return n._sha({"task": _sensitivity_task_input(task), "native_dependencies": dependencies})


def _sensitivity_job(call, cache, dependencies, producers):
    task = call[0]["sensitivity_task"]["task_spec_record"]
    identity = _sensitivity_compute_identity(task, dependencies)
    current = (call, str(cache / (identity + ".json")), identity, producers, None)
    if Path(current[1]).exists() or Path(current[1]).is_symlink():
        return current
    for producer in producers:
        old_identity = n._sha({"task": _sensitivity_task_input(task), "producer": producer})
        old_path = cache / (old_identity + ".json")
        if old_path.exists() or old_path.is_symlink():
            return (call, str(old_path), old_identity, producers, producer)
    return current


def _sensitivity_validate_native(value, task):
    from .f2_kernel import _validate_selector_sensitivity_numerics
    record = value.get("task_spec_record", {})
    echo_keys = ("task_spec_sha256", "method", "imputation", "seed", "candidate_parent_count",
        "package_versions", "thread_count", "numerical_health")
    _need(set(value) == {"schema_version", "kind", "status", "task_id", "result", "task_spec_record",
        "task_echo", "task_echo_sha256", *echo_keys} and value.get("schema_version") == "1.1.0"
        and value.get("kind") == "PADML_F2_SELECTOR_SENSITIVITY_TASK" and value.get("status") == "PASS"
        and _sensitivity_task_input(record) == _sensitivity_task_input(task["task_spec_record"])
        and value["task_spec_sha256"] == n._sha(record)
        and all(value[name] == record[name] for name in
            ("task_id", "method", "imputation", "seed", "candidate_parent_count", "package_versions"))
        and value["thread_count"] == 1
        and value["task_echo"] == {name: value[name] for name in echo_keys}
        and value["task_echo_sha256"] == n._sha(value["task_echo"]), "DIAGNOSTIC_NATIVE_DRIFT")
    _validate_selector_sensitivity_numerics(value["method"], value["numerical_health"],
        package_version=value["package_versions"]["mRMRe"])
    result, candidates = value["result"], task["candidate_parents"]
    if value["method"] == "MRMRE":
        ranking = result.get("ranking")
        _need(set(result) == {"ranking"} and isinstance(ranking, list)
            and len(ranking) == len(candidates) and len(set(ranking)) == len(ranking)
            and set(ranking) == set(candidates), "F2_MRMRE_RANK_DENOMINATOR_INVALID")
    else:
        decisions = result.get("decisions")
        _need(set(result) == {"decisions"} and isinstance(decisions, dict)
            and set(decisions) == set(candidates)
            and set(decisions.values()) <= {"Confirmed", "Tentative", "Rejected"},
            "F2_BORUTA_DECISION_DENOMINATOR_INVALID")
    return value


def _sensitivity_atom(job):
    from .f2_kernel import _run_r_selector_sensitivity_shared_pool_task
    call, path, identity, producers, legacy_producer = job
    path = Path(path)
    task = call[0]["sensitivity_task"]
    if path.exists() or path.is_symlink():
        _need(path.is_file() and not path.is_symlink(), "DIAGNOSTIC_NATIVE_DRIFT")
        saved = _read(path)
        expected_keys = {"input_identity", "value", "identity_sha256"} | ({"producer"} if legacy_producer is None else set())
        _need(set(saved) == expected_keys and saved["input_identity"] == identity
            and n._sealed({k: v for k, v in saved.items() if k != "identity_sha256"}) == saved
            and (legacy_producer or saved["producer"]) in producers, "DIAGNOSTIC_NATIVE_DRIFT")
        return _sensitivity_validate_native(saved["value"], task)
    _need(legacy_producer is None, "DIAGNOSTIC_NATIVE_MISSING")
    value = _run_r_selector_sensitivity_shared_pool_task(call)
    if value.get("kind") == "PADML_F2_SELECTOR_SENSITIVITY_SHARED_POOL_FAILURE":
        return value  # Existing typed reduction remains; failures are not reusable atoms.
    _sensitivity_validate_native(value, task)
    _save(path, {"input_identity": identity, "producer": producers[0], "value": value})
    return value


def _sensitivity(run, unit, training, development, root):
    from . import f2_kernel as k
    from ._science_authority import load_science_authority
    from .runtime import admit_stage, _bounded_ordered_spawn
    package = Path(__file__).parent
    authority = load_science_authority()
    contract = copy.deepcopy(k.selector_sensitivity_contract(authority))
    # Preserve the frozen input/science authority; bind only the executing native
    # versions to the dependency lock already qualified by execute_f45.
    native = _read(package.parent / "dependency-lock.json")["engine_contract_versions"]
    contract["mrmre"]["version"] = native["mRMRe"]
    contract["boruta"]["ranger_version"] = native["ranger"]
    tier = development["selector"]["epv_resolution"]["minimum"]
    _need(tier in {10, 15}, "DIAGNOSTIC_EPV_TIER_INVALID")
    contract["shared_contract"]["epv_minimum"] = tier
    parent = root / "sensitivity"
    parent.mkdir(parents=True, exist_ok=True)
    from .runtime import resolve_pool_workers
    slots = resolve_pool_workers(None)
    profiles = k.selected_route_profiles(pool_workers=slots)
    chosen = {}
    for method, route in (("MRMRE", "F2_SELECTOR_MRMRE"), ("BORUTA", "F2_SELECTOR_BORUTA")):
        record = profiles[route]
        profile = record["profile"]
        _need(profile is not None, "DIAGNOSTIC_METHOD_CAPABILITY_UNAVAILABLE:" + method)
        chosen[method] = {"admission_identity": record["admission_identity"], "selection": record["selection"],
            "execution": {"execution_mode": k.execution_mode(profile), "threads": slots,
                "pool_workers": slots, "engine_threads": 1}}
    spec = {"fold": unit.get("outer_fold") or 0, "heldout_center": unit.get("heldout_center") or
            (n.OUTER_CENTERS[unit["outer_fold"]-1] if unit.get("outer_fold") else 0),
        "integrated_diagnostic": True, "predictors": k.predictor_contract(package),
        "outcome": authority["science"]["population"]["outcome"],
        "time": authority["science"]["population"]["time"],
        "selector_sensitivity_contract": contract, "selector_sensitivity_profiles": chosen}
    with tempfile.TemporaryDirectory(prefix="projection-", dir=parent) as temp:
        work = Path(temp)
        projection = k._recipe_partition_projection({"partitions": [training]}, training["partition_id"],
            spec["predictors"], work, imputations=[])
        scope = {key: training[key] for key in ("partition_id", "fit_ids", "fit_response")}
        scope["fit_response"] = {key: v for key, v in scope["fit_response"].items() if key != "private_bytes"}
        calls, plans = [], {}
        for method in ("MRMRE", "BORUTA"):
            plans[method] = k._run_selector_sensitivity_method(spec, scope, method, projection,
                work, package, shared_call_args=calls)
        cache = Path(run["run_root"]) / "shared/selector-sensitivity"
        cache.mkdir(parents=True, exist_ok=True)
        dependencies, producers = _sensitivity_sources(run)
        jobs = [_sensitivity_job(call, cache, dependencies, producers) for call in calls]
        rows = [None] * len(jobs)
        missing = []
        for index, job in enumerate(jobs):
            if Path(job[1]).is_file():
                rows[index] = _sensitivity_atom(job)
            else:
                missing.append(index)
        if missing:
            # Only absent native tasks require projection bytes or compute admission.
            required_mi = sorted({jobs[i][0][0]["sensitivity_task"]["imputation"] for i in missing})
            publication = len(missing) * 1024**2
            admission = admit_stage(run["resource_policy"], parent, legal_tasks=len(missing),
                retained_bytes=len(missing) * 1024**2, publication_bytes=publication,
                # Each atom publishes its own bounded JSON. Keep the complete
                # original publication allowance until all missing atoms finish.
                task_disk_bytes=[(1024**2, publication) for _ in missing],
                transient_bytes_per_worker=max(run["resource_policy"]["scratch_bytes_per_worker"],
                    max(m["size_bytes"] for m in training["covariates"]["members"])))
            slots = admission["admitted_worker_ceiling"]
            k._recipe_partition_projection({"partitions": [training]}, training["partition_id"],
                spec["predictors"], work, imputations=required_mi)
            pending = [jobs[i] for i in missing]
            order = sorted(range(len(pending)), key=lambda i:
                (pending[i][0][0]["sensitivity_task"]["method"] != "BORUTA", i))
            computed = _bounded_ordered_spawn(_sensitivity_atom, pending, selected_slots=slots,
                schedule_order=order)
            for index, value in zip(missing, computed, strict=True):
                rows[index] = value

        methods = {method: k._run_selector_sensitivity_method(spec, scope, method, projection,
            work, package, prepared_rows=rows[plans[method]["start"]:plans[method]["start"]+20])
            for method in ("MRMRE", "BORUTA")}
        from .runtime import advise_completed_io
        advise_completed_io([Path(job[1]) for job in jobs])
    overlaps = {}
    for threshold in (12, 14, 16):
        if any(m["status"] != "PASS" for m in methods.values()):
            overlaps[str(threshold)] = {"status": "NOT_ESTIMABLE", "reason": "METHOD_NOT_ESTIMABLE"}
            continue
        a, b = (set(methods[m]["threshold_sets"][f"{threshold}/20"]) for m in ("MRMRE", "BORUTA"))
        overlaps[str(threshold)] = {"intersection": sorted(a & b), "union_count": len(a | b),
            "jaccard": len(a & b)/len(a | b) if a | b else 1.0}
    return {"status": "PASS", "methods": methods, "locked_epv_minimum": tier,
        "method_overlap": overlaps, "source_lineage": {
            "analysis_view_sha256": training["covariates"]["analysis_view_sha256"],
            "fit_covariate_members": training["fit_covariate_members"]},
        "primary_writeback": "FORBIDDEN", "heldout_outcome_read_count": 0}


def _natural(run, context, partitions, development, root):
    from . import f4
    from .runtime import resolve_pool_workers
    from .integrated import same_batch_generations
    keys = [n._sha({"source": context["source"], "recipes": development["transform_recipes"],
        "penalty_factor": 1, "producer": producer})
        for producer in dict.fromkeys(same_batch_generations(run).values())]
    candidates = [(key, Path(run["run_root"]) / "shared/natural-selector" / key) for key in keys]
    # A completed predecessor can precede the per-unit publication. Only
    # qualified same-batch producers are considered; its identity stays intact.
    for key, shared in candidates:
        _need(not shared.is_symlink() and shared.resolve() == shared
            and (not shared.exists() or shared.is_dir()), "DIAGNOSTIC_NATIVE_DRIFT")
        result_path = shared / "diagnostic.json"
        if result_path.exists() or result_path.is_symlink():
            _need(result_path.is_file() and not result_path.is_symlink(), "DIAGNOSTIC_NATIVE_DRIFT")
            value = _read(result_path)
            _need(isinstance(value, dict) and value.get("input_identity") == key
                and n._sealed({k:v for k,v in value.items() if k != "identity_sha256"}) == value,
                "DIAGNOSTIC_NATIVE_DRIFT")
            return value
    # Resume the original phase/atom readers at their original producer root.
    # An empty directory from an interrupted newer attempt is not progress.
    key, shared = next(((key, path) for key, path in candidates
        if path.is_dir() and any(path.iterdir())), candidates[0])
    shared.mkdir(parents=True, exist_ok=True)
    result_path = shared / "diagnostic.json"
    recipes = {r["partition_id"]: r for r in development["transform_recipes"]["recipes"]}
    with tempfile.TemporaryDirectory(prefix="responses-", dir=root) as tmp:
        parts = []
        for index, p in enumerate(partitions):
            if p["kind"] == "OUTER":
                from . import f2_kernel as k
                projection = Path(tmp) / "outer-training"
                projection.mkdir()
                members = []
                for member in p["fit_covariate_members"]:
                    actual = k._materialize_recipe_training_member(
                        Path(p["covariates"]["input_dir"]) / member["name"], p["fit_ids"],
                        projection / member["name"])
                    _need(actual == member, "NESTED_PRIMARY_SELECTOR_TRAINING_DRIFT")
                    members.append(actual)
                p = {k: p[k] for k in ("partition_id", "repeat", "inner_fold", "fit_ids", "fit_response")} | {
                    "kind": "OUTER_TRAINING", "evaluation_ids": p["fit_ids"],
                    "application_ids": p["fit_ids"], "evaluation_ids_sha256": n._sha(p["fit_ids"]),
                    "fit_covariate_members": members,
                    "covariates": {**p["covariates"], "input_dir": str(projection), "members": members,
                        "application_ids_sha256": n._sha(p["fit_ids"]), "data_identity": n._sha(members)}}
            p = {**p, "transform_recipe": recipes[p["partition_id"]]}
            response = dict(p.get("evaluation_response", p["fit_response"]))
            if "private_bytes" in response:
                target = Path(tmp) / f"{index}.csv"
                target.write_bytes(response.pop("private_bytes"))
                response["path"] = str(target)
            p["evaluation_response"] = response
            parts.append(p)
        try:
            result, _ = f4._full_pipeline_selector_search({**context, "ast_alt_natural_audit": True},
                parts, shared, rscript=run["environment"]["rscript"], replay=False,
                workers=resolve_pool_workers(None), resource_policy=run["resource_policy"])
        except ContractError as exc:
            if not hasattr(exc, "natural_diagnostic"):
                raise
            result = exc.natural_diagnostic
    return _save(result_path, {"kind": "PADML_AST_ALT_NATURAL_DIAGNOSTIC_V1", "input_identity": key,
        "status": result.get("status", "PASS"), "result": result, "penalty_factor": 1,
        "success_threshold": None, "primary_writeback": "FORBIDDEN"})


def _seed(run, unit, root, registered, lock):
    family = lock["selected_family"]
    from . import f5, f2_kernel as f2
    if family not in {"RSF", "GBM_COX", "XGBOOST_COX"}:
        return {"status": "NOT_APPLICABLE", "family": family, "new_model_fits": 0}
    original = root / "search" / family
    source, selected = _read(original / "input.json"), _read(original / "result.json")
    _need(n._sealed({k:v for k,v in selected.items() if k != "identity_sha256"}) == selected
        and selected["selected_spec"] == lock["selected_spec"]
        and source["spec"]["family"] == family
        and source["spec"].get("selection_horizon_months", 24) == unit["horizon"]
        and source["spec"]["selector_from_dependency"]["selected_parents"] == lock["selected_parents"],
        "DIAGNOSTIC_WINNER_LOCK_DRIFT")
    candidate, = selected["search_trace"]["S3B2"]
    _need(candidate["parameter_sha256"] == f2._v20_owner_sha(candidate["parameters"]), "DIAGNOSTIC_WINNER_DRIFT")
    # The original validated Q input supplies identical recipe, SetA, STOP and seeds.
    spec = {**source["spec"], "seed_audit_candidate": candidate}
    q_input = {**source, "spec": spec, "locked_search_identity": selected["identity_sha256"]}
    return f5._current_q_program(q_input, registered, root / "postprocess/diagnostics/seed",
        resource_policy=run["resource_policy"])


def run_diagnostics(run, unit, root, manifest):
    from . import f5
    from .integrated import is_integrated, prepare_primary_context, primary_projection, same_batch_generations
    if not is_integrated(run):
        return None
    _need(unit["kind"] in {"PRIMARY", "FULL0"}, "DIAGNOSTIC_CONTEXT_INVALID")
    folder = root / "postprocess/diagnostics"
    folder.mkdir(parents=True, exist_ok=True)
    source = {"source_unit": unit["unit_id"], "source_receipt_sha256": manifest["source_receipt_sha256"],
              "development_lock": manifest["development_lock"], "producer": run["source_identity"]}
    identity = n._sha(source)
    admitted = {n._sha({**source, "producer": producer}) for producer in same_batch_generations(run).values()}
    path = folder / "result.json"
    if path.is_file():
        result = _read(path)
        _need(result["input_identity"] in admitted and n._sealed({k:v for k,v in result.items()
              if k != "identity_sha256"}) == result, "DIAGNOSTIC_RESULT_DRIFT")
        return result
    family = manifest["development_lock"]["selected_family"]
    completed = {}
    for name in ("sensitivity", "natural", "seed"):
        target = folder / (name + ".json")
        if target.is_file():
            value = _read(target)
            _need(value["input_identity"] in admitted and n._sealed({k:v for k,v in value.items()
                if k != "identity_sha256"}) == value, "DIAGNOSTIC_RESULT_DRIFT")
            completed[name] = value["value"]
    def finish(results):
        return _save(path, {"kind": "PADML_POST_LOCK_DIAGNOSTICS_V1", "status": "COMPLETED",
            "input_identity": identity, **source, "results": results, "primary_writeback": "FORBIDDEN"})
    if "seed" not in completed and family not in {"RSF", "GBM_COX", "XGBOOST_COX"}:
        value = _seed(run, unit, root, None, manifest["development_lock"])
        _save(folder / "seed.json", {"input_identity": identity, "value": value})
        completed["seed"] = value
    if len(completed) == 3:
        return finish(completed)
    def compute(context, parts, development, registered):
        calls = (("sensitivity", lambda: _sensitivity(run, unit, parts[-1], development, folder)),
                 ("natural", lambda: _natural(run, context, parts, development, folder)),
                 ("seed", lambda: _seed(run, unit, root, registered, manifest["development_lock"])))
        pending = [(name, call) for name, call in calls if name not in completed]
        def consume(name, call):
            return _save(folder / (name + ".json"),
                {"input_identity": identity, "value": call()})["value"]
        from .runtime import run_ready_families
        values = run_ready_families([lambda name=name, call=call: consume(name, call)
            for name, call in pending], policy=run["resource_policy"], root=folder)
        from .runtime import advise_completed_io
        advise_completed_io([Path(part['covariates']['input_dir']) / member['name']
            for part in parts for member in part['covariates']['members']])
        return {**completed, **{name: value for (name, _), value in zip(pending, values, strict=True)}}
    if unit["kind"] == "FULL0" and set(completed) == {"natural", "seed"}:
        # Sensitivity consumes only full ANALYSIS. INNER/STOP views have no
        # role in either its native fits or the already completed diagnostics.
        sources = f5._read_final_lineage(root / "full-development.json", bounded=True,
            selection_horizon_months=unit["horizon"])
        f5._full_development_science_decision(sources["science_decision"], selection_horizon_months=unit["horizon"])
        _need(sources["selection_horizon_months"] == unit["horizon"], "DIAGNOSTIC_CONTEXT_INVALID")
        from .runtime import observe_execution_resources, resource_admission, validate_resource_policy
        from .bundle import _admit_zip_directory
        policy = validate_resource_policy(sources["resource_policy"])
        raw_paths = f5._full_development_raw_paths(sources)
        raw_memory = 32 * (sum(path.stat().st_size for path in raw_paths.values())
            + (root / "full-development.json").stat().st_size)
        def admit_io(*, memory_bytes=0):
            resource_admission({**policy, "memory_bytes_per_worker": MIN_WORKER_MEMORY_BYTES,
                "memory_reserve_bytes": policy["memory_reserve_bytes"] + raw_memory + memory_bytes,
                "scratch_reserve_bytes": 0}, observe_execution_resources(folder), legal_tasks=1)
        admit_io()
        _admit_zip_directory(Path(sources["final_mice_path"]), admit_io)
        _, response, canonical = f5._full_development_raw_inputs(sources)
        with tempfile.TemporaryDirectory(prefix="full-analysis-", dir=folder) as temp:
            full = f5.materialize_final_full_data_mice(sources["plan"], Path(sources["final_mice_path"]),
                response, Path(temp) / "full")
            _need(full["development_input"] == {"mice_plan_sha256": n._sha(sources["plan"]),
                "raw_covariates_sha256": canonical, "response_sha256": n.sha256_bytes(response)},
                "F5_FULL_DEVELOPMENT_RAW_INPUT_DRIFT")
            development = _read(Path(sources["selector_root"]) / "development-input.json")
            return finish(compute(None, [full], development, None))
    if unit["kind"] == "PRIMARY":
        context_root = Path(run["run_root"]) / "contexts" / unit["context"]
        state = prepare_primary_context(run, unit["outer_fold"], context_root)
        state["projection"]["selector_horizon_months"] = 36 if unit["horizon"] == 36 else 24
        selector_root = context_root / ("selector-h36" if unit["horizon"] == 36 else "selector")
        development = _read(selector_root / "development-input.json")
        projection = primary_projection(state, development, unit["horizon"])
        registered = {**{k:v for k,v in projection["registered"].items() if k != "identity"},
                      "source_registered_identity": state["source_registered_identity"]}
        results = f5._primary_selector_program(state, selector_root, replay=True, workers=None,
            resource_policy=run["resource_policy"], input_consumer=lambda c,p: compute(c,p,development,registered))
    else:
        with f5._materialized_full_data_development_sources(root / "full-development.json", folder,
                selector_only="seed" in completed, selection_horizon_months=unit["horizon"]) as (sources, parts, full):
            context, selector_parts = f5._nested_full_selector_inputs(sources["plan"], parts, full)
            if unit["horizon"] == 36:
                context["source"]["selection_horizon_months"] = 36
            development = _read(Path(sources["selector_root"]) / "development-input.json")
            registered = None
            if "seed" not in completed:
                task = _read(root / "search" / family / "input.json")["task"]
                registered = f5._complex_runtime_registered_inputs(task, parts)
            results = compute(context, selector_parts, development, registered)
    return finish(results)
