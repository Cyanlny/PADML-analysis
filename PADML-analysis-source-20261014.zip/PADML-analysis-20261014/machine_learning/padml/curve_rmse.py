"""Population KM versus retained mean survival; no model or imputation work."""
from __future__ import annotations

import bisect
import math
import struct
from collections import Counter
from pathlib import Path

from .bundle import ContractError, canonical_json_bytes, sha256_bytes
from . import nested_loco as n

CENTERS = ['36', '38', '39', '48', '52', '54']
MONTHS = list(range(37))
HORIZONS = (6, 12, 24, 36)
RESULT_LIMIT = 2 * 1024**2


def _need(ok, reason):
    if not ok:
        raise ContractError('CURVE_RMSE_' + reason)


def decision():
    return n._sealed({'kind': 'PADML_CURVE_RMSE_20261008_V1',
        'roles': ['LOCO', 'FULL0_APPARENT'], 'development_months': list(HORIZONS),
        'centers': CENTERS, 'months': MONTHS, 'population': 'FIXED_SIX_CENTER_INTERSECTION',
        'prediction': 'RETAINED_M20_MEAN_SURVIVAL', 'km': 'POOLED_OUTCOME_KM',
        'km_interval': 'GREENWOOD_LOG_LOG_POINTWISE_95',
        'rmse': 'EQUAL_MONTH_WEIGHT_EXCLUDING_ZERO', 'intervals': 'TARGET_AND_36_MONTHS',
        'unsupported_tail': 'NOT_ESTIMABLE_NO_TRUNCATED_DENOMINATOR',
        'model_selection_effect': 'NONE', 'new_fits': 0, 'new_mice_chains': 0,
        'new_predictions': 0, 'new_shap_solves': 0, 'new_resampling': 0})


def eligible(run, unit, source_unit=None):
    return run.get('curve_rmse') is not None and source_unit is None and unit['kind'] in {'FULL0', 'EVALUATION'}


def relative_result(unit):
    return 'units/' + unit['unit_id'] + '/curve-rmse-20261008/result.json'


def outcome_km(times, events):
    """One sorted sweep; deaths at a tied time consume the pre-censor risk set."""
    _need(len(times) == len(events) > 0 and all(math.isfinite(t) and t > 0 for t in times)
        and all(e in (0, 1) for e in events), 'OUTCOME_INVALID')
    at_time = {}
    for t, e in zip(times, events, strict=True):
        row = at_time.setdefault(t, [0, 0]); row[0] += 1; row[1] += int(e)
    remaining, survival, greenwood = len(times), 1.0, 0.0
    knots = [{'month': 0., 'survival': 1., 'lower': 1., 'upper': 1.}]
    for t in sorted(at_time):
        count, deaths = at_time[t]
        if deaths:
            if deaths == remaining:
                survival, low, high = 0., None, None
            else:
                survival *= 1. - deaths / remaining
                greenwood += deaths / (remaining * (remaining - deaths))
                log_s = math.log(survival)
                delta = 1.959963984540054 * math.sqrt(greenwood) / abs(log_s)
                z = math.log(-log_s)
                # Avoid overflow at a legitimate near-boundary KM confidence limit.
                low = 0. if z + delta > 709 else math.exp(-math.exp(z + delta))
                high = math.exp(-math.exp(z - delta))
            if t <= 36:
                knots.append({'month': float(t), 'survival': survival, 'lower': low, 'upper': high})
        remaining -= count
    ordered = sorted(times)
    knot_times = [k['month'] for k in knots]
    monthly = []
    for month in MONTHS:
        point = knots[bisect.bisect_right(knot_times, month)-1]
        supported = month <= ordered[-1] or point['survival'] == 0.
        monthly.append({'month': month, 'at_risk': len(times)-bisect.bisect_left(ordered, month),
            'supported': supported, **{k: point[k] if supported else None for k in ('survival', 'lower', 'upper')}})
    return {'knots': knots, 'monthly': monthly, 'maximum_followup_months': ordered[-1],
        'event_count': sum(events), 'zero_event_warning': not any(events)}


def summarize(ids, centers, times, events, matrix, horizon):
    from .f4 import _seal_prediction_matrix
    _need(horizon in HORIZONS and len(ids) == len(centers) == len(times) == len(events)
        and len(ids) == len(set(ids)) and set(centers) == set(CENTERS), 'POPULATION_DRIFT')
    _seal_prediction_matrix(ids, matrix, MONTHS)
    _need(all(row[0] == 1. for row in matrix), 'MONTH_ZERO_INVALID')
    km = outcome_km(times, events)
    mean = [math.fsum(row[m] for row in matrix)/len(ids) for m in MONTHS]
    rows = [{**row, 'predicted_survival': mean[row['month']],
        'predicted_risk': 1.-mean[row['month']],
        'km_risk': None if row['survival'] is None else 1.-row['survival']} for row in km['monthly']]
    metrics = {}
    for label, end in (('target', horizon), ('common36', 36)):
        supported = all(row['supported'] for row in rows[1:end+1])
        value = math.sqrt(math.fsum((row['predicted_survival']-row['survival'])**2
            for row in rows[1:end+1])/end) if supported else None
        metrics[label] = {'end_month': end, 'n_months': end, 'value': value,
            'percentage_points': None if value is None else 100*value,
            'status': 'ESTIMABLE' if supported else 'NOT_ESTIMABLE',
            'reason': None if supported else 'KM_FOLLOWUP_SUPPORT_INSUFFICIENT'}
    return {'patient_count': len(ids), 'center_counts': dict(sorted(Counter(centers).items())),
        'population_sha256': n._sha(sorted(zip(ids, centers))),
        'patient_order_sha256': n._sha(ids), 'outcomes_sha256': n._sha(sorted(zip(ids, times, events))),
        'monthly': rows, 'km_knots': km['knots'], 'rmse': metrics,
        'event_count': km['event_count'], 'maximum_followup_months': km['maximum_followup_months'],
        'zero_event_warning': km['zero_event_warning']}


def _bindings(run, unit):
    from .carriers import source_pin, source_bytes
    from .f4 import _f45_optimism_json, evaluation_appendix_root, _post_result_repair_read, _evaluation_check_producer
    from .integrated import same_batch_generations
    _need(eligible(run, unit) and run['curve_rmse'] == decision(), 'CONTRACT_DRIFT')
    base = Path(run['run_root']); root = base/'units'/unit['unit_id']
    receipt_path = root/'unit.json'
    receipt = _f45_optimism_json(source_bytes(receipt_path, limit=RESULT_LIMIT))
    generations = same_batch_generations(run)
    _need(receipt['unit_id'] == unit['unit_id'] and receipt['run_identity'] in generations
        and receipt['status'] == 'COMPLETED' and receipt['direct_consumer_completed'], 'UNIT_NOT_COMPLETE')
    original_path = evaluation_appendix_root(run, unit)/'result.json'
    original = _f45_optimism_json(source_bytes(original_path, limit=8*1024**2))
    _evaluation_check_producer(original, generations)
    _need(_post_result_repair_read(run, unit, None, original, observation=True) is not None,
        'PRIOR_REPAIR_NOT_COMPLETE')
    path = root/('postprocess/input.zip' if unit['kind'] == 'FULL0' else 'result.zip')
    expected = original['sources'].get(path.relative_to(base).as_posix())
    _need(expected is not None, 'PREDICTION_SOURCE_NOT_REGISTERED')
    # Project the already-qualified byte fact, not the thousands of B1000 members.
    qualification = original_path.parent/'result.qualified.json'
    if qualification.is_file():
        from .bundle import strict_json_bytes, _remember_qualified_digest
        q = strict_json_bytes(qualification.read_bytes())
        key = 'source/' + path.relative_to(base).as_posix()
        s = path.stat(); stamp = [s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns]
        if (q.get('binding') == n._sha({'evaluation': original['identity_sha256']})
            and q.get('scientifically_validated') is True and q.get('stable_stamps') is True
            and q.get('pins',{}).get(key) == expected
            and q.get('stamps',{}).get(key) == [str(path.resolve()), *stamp]):
            _remember_qualified_digest(path.resolve(), expected['sha256'], stamp)
    sources = {str(p.relative_to(base)): source_pin(p) for p in (receipt_path, original_path, path)}
    _need(sources[path.relative_to(base).as_posix()] == expected, 'PREDICTION_SOURCE_DRIFT')
    if unit['kind'] == 'EVALUATION':
        _need(receipt['artifacts']['result.zip'] == expected, 'LOCO_RECEIPT_DRIFT')
    return path, sources


def _load_view(path, run, unit, *, sources=None, source_stamps=None):
    from .carriers import open_carrier, resolve_reference
    from .f4 import _f45_optimism_json, _f45_optimism_member, _response_rows, _write_response_subset, _response_arrays
    from .integrated import same_batch_generations
    def track(archive, names):
        for name in names:
            ref = archive.references.get(name)
            if ref is None:
                continue
            physical = resolve_reference(ref,run)
            if sources is not None:
                pin = {k:ref[k] for k in ('sha256','size_bytes')}
                _need(ref['path'] not in sources or sources[ref['path']] == pin,'MEMBER_ALIAS_DRIFT')
                sources[ref['path']] = pin
                s = physical.stat()
                source_stamps[ref['path']] = [s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns]
    if unit['kind'] == 'FULL0':
        with open_carrier(path) as archive:
            track(archive, ('input.json','apparent.f64','response.csv'))
            manifest = _f45_optimism_json(_f45_optimism_member(archive, 'input.json', limit=8*1024**2))
            _need(manifest['kind'] == 'PADML_F45_OPTIMISM_INPUT_V1'
                and manifest['source_unit'] == unit['unit_id']
                and manifest['selection_horizon_months'] == unit['horizon']
                and manifest['source_receipt']['run_identity'] in same_batch_generations(run), 'FULL0_SOURCE_DRIFT')
            context = n.validate_training_context(manifest['training_context'])
            lock = n.validate_development_lock(manifest['development_lock'], context=context)
            ids, centers = manifest['patient_ids'], manifest['centers']
            _need(context['outer_fold'] == 0 and context['channel'] == 'PRIMARY'
                and ids == [p for p in context['training_ids'] if unit['horizon'] != 36
                    or context['centers_by_patient'][p] != '55']
                and centers == [context['centers_by_patient'][p] for p in ids]
                and lock['selection_horizon_months'] == unit['horizon'], 'FULL0_POPULATION_DRIFT')
            raw = _f45_optimism_member(archive, 'apparent.f64', manifest['members']['apparent.f64'])
            _need(len(raw) == len(ids)*37*8, 'MATRIX_SHAPE_INVALID')
            matrix = list(struct.iter_unpack('<37d', raw))
            response = _f45_optimism_member(archive, 'response.csv', manifest['members']['response.csv'])
            provenance = {'development_lock_sha256': lock['identity_sha256'], 'family': lock['selected_family']}
    else:
        from .f5_sensitivity import _f45_evaluation_input
        with open_carrier(path) as outer:
            track(outer, ('evaluation-input.zip',))
        # Bounded member access, never load the twelve source archives or B1000.
        with _f45_evaluation_input(path, 'evaluation-input.zip') as archive:
            track(archive, ('evaluation-input.json','predictions.json','response.csv'))
            manifest = _f45_optimism_json(_f45_optimism_member(archive, 'evaluation-input.json'))
            _need(manifest['kind'] == 'PADML_F45_COMPACT_EVALUATION_V1'
                and manifest['unit_id'] == unit['unit_id'] and manifest['horizon'] == unit['horizon'], 'LOCO_SOURCE_DRIFT')
            handoff = _f45_optimism_json(_f45_optimism_member(archive, 'predictions.json', manifest['members']['predictions.json']))
            _need(handoff['kind'] == 'PADML_F5_A12_ALIGNED_PREDICTIONS_V2', 'LOCO_HANDOFF_INVALID')
            registry = n.validate_population_registry(handoff['population_registry'])
            primary = n.validate_selected_ooc(handoff['primary_ooc'], population_registry=registry)
            _need(primary['selection_horizon_months'] == unit['horizon']
                and handoff['survival']['PRIMARY'] == primary['survival']['NESTED_SELECTED_POLICY'], 'LOCO_PREDICTION_DRIFT')
            ids, centers, matrix = primary['patient_ids'], primary['centers'], primary['survival']['NESTED_SELECTED_POLICY']
            response = _f45_optimism_member(archive, 'response.csv', manifest['members']['response.csv'])
            provenance = {'primary_ooc_sha256': primary['identity_sha256'], 'selection_by_outer': primary['selection_by_outer']}
    fields, records = _response_rows(response)
    _need(list(records) == ids and len(ids) == len(set(ids)) == len(centers), 'RESPONSE_ORDER_DRIFT')
    selected = [i for i, c in enumerate(centers) if c in CENTERS]
    chosen = [ids[i] for i in selected]
    times, events = _response_arrays(_write_response_subset(fields, records, chosen, None), chosen)
    return chosen, [centers[i] for i in selected], times, events, [matrix[i] for i in selected], provenance


def validate_result(run, unit, value):
    from .f4 import _evaluation_check_producer
    from .integrated import same_batch_generations
    _need(run.get('curve_rmse') == decision() and value.get('kind') == 'PADML_CURVE_RMSE_RESULT_V1'
        and value['decision_sha256'] == decision()['identity_sha256']
        and value['target_unit'] == unit['unit_id'] and value['development_month'] == unit['horizon']
        and value['role'] == ('LOCO' if unit['kind'] == 'EVALUATION' else 'FULL0_APPARENT')
        and value['status'] == 'COMPLETED' and value['direct_consumer_completed'] is True
        and n._sealed({k:v for k,v in value.items() if k != 'identity_sha256'}) == value, 'RESULT_DRIFT')
    _evaluation_check_producer(value, same_batch_generations(run))
    numbers = value['numbers']
    _need(set(numbers['center_counts']) == set(CENTERS)
        and sum(numbers['center_counts'].values()) == numbers['patient_count'] > 0
        and [row['month'] for row in numbers['monthly']] == MONTHS, 'NUMBERS_INVALID')
    for label, end in (('target', unit['horizon']), ('common36', 36)):
        metric = numbers['rmse'][label]; rows = numbers['monthly'][1:end+1]
        supported = all(row['supported'] for row in rows)
        expected = math.sqrt(math.fsum((row['predicted_survival']-row['survival'])**2 for row in rows)/end) if supported else None
        _need(metric['end_month'] == metric['n_months'] == end and metric['value'] == expected
            and metric['status'] == ('ESTIMABLE' if supported else 'NOT_ESTIMABLE'), 'RMSE_DRIFT')
    return value


def read_result(run, unit, *, observation=False):
    from .carriers import source_bytes
    from .f4 import _f45_optimism_json
    path = Path(run['run_root'])/relative_result(unit)
    if not path.is_file():
        return None
    value = validate_result(run, unit, _f45_optimism_json(source_bytes(path, limit=RESULT_LIMIT)))
    # Observation reads a small header and stamps only. Worker qualification binds bytes.
    changed={}
    for name, stamp in value['source_stamps'].items():
        p = Path(run['run_root'])/name
        _need(not p.is_symlink() and p.is_file(), 'SOURCE_MISSING')
        stat = p.stat()
        if [stat.st_dev, stat.st_ino, stat.st_size, stat.st_mtime_ns, stat.st_ctime_ns] != stamp:
            changed[name]=p
    if changed:
        # A new hard link changes ctime without changing a single input byte.
        # Observation schedules qualification; only the worker reads changed
        # members against their original pins. Never rewrite the old result.
        from .integrated import qualified_file_pins
        qualified=qualified_file_pins(changed,identity=value['identity_sha256'],
            expected={name:value['sources'][name] for name in changed},
            record=path.with_name('source-requalified.json'),validate=lambda:None,cached_only=observation)
        if qualified is None:return None
    return value


def _compute(unit, *, run):
    from .f4 import _evaluation_provenance
    from .runtime import advise_completed_io
    path, sources = _bindings(run, unit)
    base = Path(run['run_root'])
    def stamps():
        return {name: [s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns]
            for name in sources for s in [(base/name).stat()]}
    before = stamps()
    ids, centers, times, events, matrix, provenance = _load_view(path, run, unit,
        sources=sources,source_stamps=before)
    numbers = summarize(ids, centers, times, events, matrix, unit['horizon'])
    _need(before == stamps(), 'SOURCE_CHANGED_DURING_READ')
    value = n._sealed({'kind': 'PADML_CURVE_RMSE_RESULT_V1', 'decision_sha256': decision()['identity_sha256'],
        'target_unit': unit['unit_id'], 'development_month': unit['horizon'],
        'role': 'LOCO' if unit['kind'] == 'EVALUATION' else 'FULL0_APPARENT',
        'producer': _evaluation_provenance(run)['producer'], 'sources': sources, 'source_stamps': before,
        'provenance': provenance, 'numbers': numbers, 'status': 'COMPLETED', 'direct_consumer_completed': True,
        'new_model_fits': 0, 'new_mice_chains': 0, 'new_predictions': 0, 'new_shap_solves': 0})
    validate_result(run, unit, value)
    target = base/relative_result(unit)
    target.parent.mkdir(parents=True, exist_ok=True)
    raw = canonical_json_bytes(value)
    _need(len(raw) <= RESULT_LIMIT, 'RESULT_TOO_LARGE')
    n._write_exact_once(target, raw, 'CURVE_RMSE_PUBLICATION_DRIFT')
    advise_completed_io([path], sync=False)
    return {'target_unit': unit['unit_id'], 'identity_sha256': value['identity_sha256'], 'size_bytes': len(raw)}


def run_curve(run, unit):
    """Admit before any prediction read; use the existing dynamic single pool."""
    from functools import partial
    from .runtime import admit_stage, run_ready_families, _bounded_ordered_spawn, MIN_WORKER_MEMORY_BYTES
    saved = read_result(run, unit)
    if saved is not None:
        return {'target_unit': unit['unit_id'], 'identity_sha256': saved['identity_sha256'], 'reused': True}
    root = Path(run['run_root'])/'units'/unit['unit_id']
    def batch():
        import zipfile
        from .carriers import open_carrier
        temporary = 0
        if unit['kind'] == 'EVALUATION':
            with open_carrier(root/'result.zip') as archive:
                info = archive.getinfo('evaluation-input.zip')
                if info.compress_type != zipfile.ZIP_STORED and 'evaluation-input.zip' not in archive.references:
                    _need(info.file_size <= 512*1024**2, 'LEGACY_NESTED_INPUT_TOO_LARGE')
                    temporary = info.file_size
        admission = admit_stage(run['resource_policy'], root, legal_tasks=1,
            retained_bytes=RESULT_LIMIT, publication_bytes=RESULT_LIMIT,
            transient_bytes_per_worker=temporary+16*1024**2, memory_bytes_per_worker=MIN_WORKER_MEMORY_BYTES,
            task_disk_bytes=[(RESULT_LIMIT, RESULT_LIMIT)],
            task_write_paths=[(Path(run['run_root'])/relative_result(unit),)])
        return _bounded_ordered_spawn(partial(_compute, run=run), [unit],
            selected_slots=admission['admitted_worker_ceiling'])[0]
    return run_ready_families([batch], policy=run['resource_policy'], root=root)[0]


def write_report(run, records, root):
    """Consume eight compact numerical heads, never patient matrices or models."""
    from .reports import _publish
    from .f4 import _f45_optimism_csv
    units = {u['unit_id']: u for u in run['units'] if eligible(run,u)}
    _need(len(units) == 8 and set(records) == set(units), 'EIGHT_COORDINATES_REQUIRED')
    checked = [validate_result(run, units[uid], records[uid]) for uid in sorted(units)]
    _need(len({r['numbers']['population_sha256'] for r in checked}) == 1
        and len({r['numbers']['outcomes_sha256'] for r in checked}) == 1, 'CROSS_LINE_POPULATION_DRIFT')
    root = Path(root); root.mkdir(parents=True, exist_ok=True)
    rows, metrics = [], []
    for result in checked:
        key = {'role': result['role'], 'development_month': result['development_month']}
        rows.extend({**key, **row} for row in result['numbers']['monthly'])
        metrics.extend({**key, 'interval': name, **result['numbers']['rmse'][name]}
            for name in ('common36','target'))
    summary = n._sealed({'kind': 'PADML_CURVE_RMSE_NUMERICAL_REPORT_V1', 'decision': decision(),
        'status': 'COMPLETED', 'coordinates': {r['target_unit']: r for r in checked},
        'new_fits': 0, 'new_mice_chains': 0, 'new_predictions': 0, 'new_shap_solves': 0,
        'interpretation': 'Population-mean curve agreement, not individual accuracy or clinical admission.',
        'censoring_assumption': 'Pooled KM requires independent censoring in this six-center evaluation population.',
        'prediction_uncertainty': 'Not estimated; KM bands are pointwise observation intervals only.',
        'loco_role': 'Heldout-center predictions of the nested selected policy, not external validation of FULL0.'})
    target = root/'curve-rmse-results.json'
    _publish(root/'curve-rmse-monthly.csv', _f45_optimism_csv(rows), 'CURVE_RMSE_REPORT_DRIFT')
    _publish(root/'curve-rmse-summary.csv', _f45_optimism_csv(metrics), 'CURVE_RMSE_REPORT_DRIFT')
    _publish(target, canonical_json_bytes(summary), 'CURVE_RMSE_REPORT_DRIFT')
    return {'status': 'COMPLETED', 'coordinates': 8, 'report': str(target), 'archive_mode': 'PAUSED'}
