"""Retained outer/final and B100/B200 numbers, after complete native audit.

These data do not recreate deleted risks, coefficient paths or native models.
They retain the actual inputs to the original selection arithmetic. Publication,
source admission and last-consumer deletion belong to the calling main process.
"""

from __future__ import annotations

from .runtime import MIN_WORKER_MEMORY_BYTES

from ._science_authority import selector_parent_names

import math
from collections import Counter
from typing import Any, Mapping

from .bundle import canonical_json_bytes, sha256_bytes
from .f2_kernel import (
    _choose_elastic_summary, _elastic_alpha_numeric_summary,
    _elastic_imputation_decisions, _elastic_ratios, _finite_number, _require,
    _summarize_elastic_alpha, _validate_sealed_elastic_lambda_path_health,
)
from .f5 import _primary_seta_coefficient_counts, _reduce_primary_seta_evidence


def _o_fit_final_component_numbers(numbers, entries, *, context, lock):
    """Read one original post-lock MI through the existing numerical checks."""
    from pathlib import Path
    from . import nested_loco as nested
    from .f4 import _f4_native_component_inputs, _f4_native_prediction
    from .f2_kernel import (_expected_family_parent_column_map, _locked_family_parameters,
                            _validate_python_fit_health, predictor_contract)
    from .f5 import _validate_final_r_fit_health, _validate_retained_r_audit_numbers

    context = nested.validate_training_context(context, entries["fit-response.csv"])
    lock = nested.validate_development_lock(lock, context=context)
    family = lock["selected_family"]
    from .bundle import strict_json_bytes
    task = strict_json_bytes(entries["task.json"])
    template = {key: value for key, value in task.items() if key != "development_lock_sha256"}
    _require(task == nested.bind_post_lock_task(template, lock), "F4_O_FIT_FINAL_NUMBERS_BINDING_DRIFT")
    task, recipe, training, _, application, _ = _f4_native_component_inputs(entries)
    receipt = nested.validate_component_receipt(numbers["receipt"], lock)
    prediction, health, audit = numbers["prediction"], numbers["fit_health"], numbers["object_audit"]
    _require(isinstance(prediction, Mapping) and isinstance(health, Mapping) and isinstance(audit, Mapping)
             and isinstance(prediction.get("survival"), Mapping) and set(prediction["survival"]) == {family},
             "F4_O_FIT_FINAL_NUMBERS_COMPONENT_INVALID")
    expected_prediction = _f4_native_prediction(task, application, prediction["survival"][family])
    expected_receipt = nested._sealed({
        "imputation": task["imputation"], "development_lock_sha256": lock["identity_sha256"],
        "training_context_sha256": context["identity_sha256"], "task_sha256": nested._sha(task),
        "input_sha256": nested._sha({name: sha256_bytes(raw) for name, raw in sorted(entries.items())}),
        "mice_member_sha256": sha256_bytes(entries["fit-covariates.csv"]), "recipe_sha256": nested._sha(recipe),
        "parameter_sha256": nested._sha(task["parameters"]),
        "training_ids_sha256": nested._sha([row["Patient_ID"] for row in training]),
        "application_ids_sha256": nested._sha([row["Patient_ID"] for row in application]),
        "training_response_sha256": sha256_bytes(entries["fit-response.csv"]),
        "model_sha256": receipt["model_sha256"], "baseline_sha256": receipt["baseline_sha256"],
        "prediction_sha256": nested._sha(expected_prediction), "fit_health_sha256": nested._sha(health),
        "model_fit_count": 1, "engine_threads": 1, "seed": task["registered_model_seed"],
    })
    _require(prediction == expected_prediction and receipt == expected_receipt
             and prediction["patient_ids"] == context["heldout_ids"]
             and prediction["centers"] == [str(context["heldout_center"])] * len(context["heldout_ids"]),
             "F4_O_FIT_FINAL_NUMBERS_BINDING_DRIFT")
    columns_by_parent = _expected_family_parent_column_map(
        task["selected_parents"], family, predictor_contract(Path(__file__).parent), recipe["transform_recipe"])
    columns = [column for row in columns_by_parent for column in row["columns"]]
    if family in {"XGBOOST_COX", "COXTIME_SET_A"}:
        columns.sort(key=lambda text: text.encode())
    _require(audit.get("design_columns") == columns and task["family_design_column_count"] == len(columns),
             "F4_O_FIT_FINAL_NUMBERS_DESIGN_DRIFT")
    if family in {"XGBOOST_COX", "COXTIME_SET_A"}:
        locked = task["parameters"]["selected_rounds" if family == "XGBOOST_COX" else "locked_epoch"]
        _validate_python_fit_health(family, health, locked_value=locked,
            training_count=len(training), evaluation_count=len(training))
        expected_audit = {"design_columns": columns,
            **({"booster_round_count": locked} if family == "XGBOOST_COX" else {"input_width": len(columns)})}
        _require(audit == expected_audit, "F4_O_FIT_FINAL_NUMBERS_AUDIT_DRIFT")
        _require(family != "XGBOOST_COX" or health.get("model_binary_sha256") == receipt["model_sha256"],
                 "F4_O_FIT_FINAL_NUMBERS_MODEL_BINDING_DRIFT")
    else:
        options = {}
        if family == "ELASTIC_NET_COX":
            from .f4 import _f4_elastic_parameters
            _, options["lambda_source_column_map"] = _f4_elastic_parameters(task["f4_outer_elastic_source"], task["f4_coordinates"])
        _validate_final_r_fit_health(family, health,
                                     (_locked_family_parameters(family, task["parameters"])
                                      if family in {"RSF", "GBM_COX"} else task["parameters"]),
                                     ordered_parent_column_map=columns_by_parent,
                                     training_count=len(training), **options)
        _validate_retained_r_audit_numbers(family, audit, health, task)
    return receipt, prediction


def _o_fit_final_numbers(
    value: Mapping[str, Any], mean: bytes, *, request: Mapping[str, Any], request_root: Any,
    lock: Mapping[str, Any], native_members: Mapping[str, Any],
    retained_primary_source_bundle: Any = None,
) -> dict[str, Any]:
    """Recheck the first final M20 values against the original bound inputs."""
    import struct
    from pathlib import Path
    from . import nested_loco as nested
    from .bundle import sha256_file
    from .bundle import validate_sha256
    from .f4 import _f4_native_component_inputs, _f4_native_prediction
    from .f2_kernel import (_expected_family_parent_column_map, _locked_family_parameters, _pool_prediction_batch,
                            _seal_prediction_matrix, _validate_python_fit_health, predictor_contract)
    from .f5 import _validate_final_r_fit_health, _validate_retained_r_audit_numbers

    lock = nested.validate_development_lock(lock)
    context = nested.validate_training_context(request["training_context"])
    family = lock["selected_family"]
    _require(context["scope"] == "OUTER" and context["channel"] == "PRIMARY"
             and lock["training_context_sha256"] == context["identity_sha256"]
             and isinstance(value, Mapping) and set(value) == {
                 "kind", "input_identity_sha256", "development_lock_sha256", "components", "mean", "identity_sha256"}
                 | ({"batch_executions"} if "batch_executions" in value else set())
             and value["kind"] == "PADML_F4_O_FIT_FINAL_NUMBERS_V1"
             and value["input_identity_sha256"] == request["identity_sha256"]
             and value["development_lock_sha256"] == lock["identity_sha256"]
             and value["identity_sha256"] == nested._sha({key: item for key, item in value.items() if key != "identity_sha256"})
             and isinstance(value["components"], list) and len(value["components"]) == nested.M,
             "F4_O_FIT_FINAL_NUMBERS_SOURCE_INVALID")
    records = [row for row in request["post_lock_templates"] if row["family"] == family]
    _require([row["imputation"] for row in records] == list(range(1, nested.M + 1))
             and isinstance(native_members, Mapping)
             and set(native_members) == {f"fits/M{imp:02d}.zip" for imp in range(1, nested.M + 1)},
             "F4_O_FIT_FINAL_NUMBERS_M20_REQUIRED")
    if "batch_executions" in value:
        from .f4 import _o_fit_final_batch_execution
        _o_fit_final_batch_execution(value["batch_executions"], value["components"], request=request, lock=lock,
            **({"retained_primary_source_bundle": retained_primary_source_bundle}
               if retained_primary_source_bundle is not None else {}))
    _require(retained_primary_source_bundle is None or "batch_executions" in value,
             "F4_RETAINED_PRIMARY_SOURCE_SCOPE_INVALID")
    for member in native_members.values():
        _require(isinstance(member, Mapping) and set(member) == {"sha256", "size_bytes"}
                 and type(member["size_bytes"]) is int and member["size_bytes"] > 0,
                 "F4_O_FIT_FINAL_NUMBERS_COMPONENT_INVALID")
        validate_sha256(member["sha256"], "f4.final.native_archive")
    receipts, predictions = [], []
    for record, numbers in zip(records, value["components"], strict=True):
        _require(isinstance(numbers, Mapping) and set(numbers) == {"receipt", "prediction", "fit_health", "object_audit", "native_archive"}
                 | ({"reused_final"} if "reused_final" in numbers else set())
                 and numbers["native_archive"] == {"member": f"fits/M{record['imputation']:02d}.zip",
                     **native_members[f"fits/M{record['imputation']:02d}.zip"]},
                 "F4_O_FIT_FINAL_NUMBERS_COMPONENT_INVALID")
        path = request_root / record["path"]
        _require(path.is_file() and not path.is_symlink() and path.stat().st_size == record["size_bytes"]
                 and sha256_file(path) == record["sha256"], "F4_O_FIT_FINAL_NUMBERS_INPUT_DRIFT")
        template, _, entries = nested._read_component(path)
        task = nested.bind_post_lock_task(template, lock)
        entries = {**entries, "task.json": canonical_json_bytes(task)}
        if "reused_final" in numbers:
            from .f5 import _f45_primary_final_reuse_read
            rebuilt = _f45_primary_final_reuse_read(request, lock, request_root.parent, entries,
                numbers["reused_final"], request_root.parent / numbers["native_archive"]["member"])
            _require(rebuilt == numbers, "F45_FINAL_REUSE_CONSUMER_BINDING_DRIFT")
        receipt, prediction = _o_fit_final_component_numbers(numbers, entries, context=context, lock=lock)
        receipts.append(receipt)
        predictions.append({"sealed_prediction": _seal_prediction_matrix(prediction["patient_ids"],
            prediction["survival"][family], list(nested.HORIZONS))})
    pooled = _pool_prediction_batch(predictions, list(nested.HORIZONS))
    expected_mean = b"".join(struct.pack("<" + "d" * len(nested.HORIZONS), *row) for row in pooled["payload"]["survival"])
    metadata = {"encoding": "IEEE754_FLOAT64_LE_ROW_MAJOR", "patient_ids": context["heldout_ids"],
        "centers": [str(context["heldout_center"])] * len(context["heldout_ids"]), "horizons": list(nested.HORIZONS),
        "imputation_count": nested.M, "sha256": sha256_bytes(mean), "size_bytes": len(mean)}
    _require(mean == expected_mean and value["mean"] == metadata, "F4_O_FIT_FINAL_NUMBERS_MEAN_DRIFT")
    selected = nested.seal_selected_prediction(lock=lock, patient_ids=metadata["patient_ids"], centers=metadata["centers"],
        survival=pooled["payload"]["survival"], component_receipts=receipts)
    reused = sum("reused_final" in row for row in value["components"])
    return {"development_lock": lock, "selected_prediction": selected, "component_receipts": receipts,
            **({"reused_final_model_count": reused} if reused else {})}


def read_o_fit_final_numbers(source: Any, *, request: Mapping[str, Any], request_root: Any,
                            lock: Mapping[str, Any], native_members: Mapping[str, Any],
                            retained_primary_source_bundle: Any = None) -> dict[str, Any]:
    from pathlib import Path
    from .bundle import read_safe_zip, strict_json_bytes
    from .f4 import O_FIT_COMPONENT_BYTES
    _require(isinstance(source, bytes) or isinstance(source, Path) and source.is_file() and not source.is_symlink(),
             "F4_O_FIT_FINAL_NUMBERS_REQUIRED")
    _require((len(source) if isinstance(source, bytes) else source.stat().st_size) <= O_FIT_COMPONENT_BYTES,
             "F4_O_FIT_FINAL_NUMBERS_ARCHIVE_TOO_LARGE")
    entries = read_safe_zip(source, expected_members={"final.json", "heldout-mean.f64"},
        max_member_bytes=min(request["shared_storage_bytes"], O_FIT_COMPONENT_BYTES),
        max_total_bytes=min(request["shared_storage_bytes"], O_FIT_COMPONENT_BYTES))
    value = strict_json_bytes(entries["final.json"])
    _require(canonical_json_bytes(value) == entries["final.json"], "F4_O_FIT_FINAL_NUMBERS_JSON_INVALID")
    return _o_fit_final_numbers(value, entries["heldout-mean.f64"], request=request, request_root=request_root,
        lock=lock, native_members=native_members,
        **({"retained_primary_source_bundle": retained_primary_source_bundle}
           if retained_primary_source_bundle is not None else {}))


def write_o_fit_final_numbers(root: Any, *, request: Mapping[str, Any], lock: Mapping[str, Any],
                             components: list[Mapping[str, Any]], selected: Mapping[str, Any],
                             native_members: Mapping[str, Any], batch_executions: list[Mapping[str, Any]] | None = None) -> dict[str, Any]:
    """Publish first audited M20 numbers; retain all native originals for later consumers."""
    import struct
    import shutil
    from . import nested_loco as nested
    from .bundle import read_safe_zip, write_deterministic_zip
    from .f4 import O_FIT_COMPONENT_BYTES
    from .f5 import _full_score_storage_usage
    mean = b"".join(struct.pack("<" + "d" * len(nested.HORIZONS), *row) for row in selected["survival"])
    value = nested._sealed({"kind": "PADML_F4_O_FIT_FINAL_NUMBERS_V1", "input_identity_sha256": request["identity_sha256"],
        "development_lock_sha256": lock["identity_sha256"], "components": components,
        **({"batch_executions": batch_executions} if batch_executions is not None else {}),
        "mean": {"encoding": "IEEE754_FLOAT64_LE_ROW_MAJOR", "patient_ids": selected["patient_ids"],
            "centers": selected["centers"], "horizons": selected["horizons"], "imputation_count": nested.M,
            "sha256": sha256_bytes(mean), "size_bytes": len(mean)}})
    entries = {"final.json": canonical_json_bytes(value), "heldout-mean.f64": mean}
    _require(sum(map(len, entries.values())) <= request["shared_storage_bytes"], "NESTED_FULL_SCORE_SHARED_STORAGE_ESTIMATE_EXCEEDED")
    rebuilt = _o_fit_final_numbers(value, mean, request=request, request_root=root / "request", lock=lock, native_members=native_members)
    _require(rebuilt["selected_prediction"] == selected, "F4_O_FIT_FINAL_NUMBERS_MEAN_DRIFT")
    target = root / "final-numbers.zip"
    if target.exists():
        _require(read_safe_zip(target) == entries, "F4_O_FIT_FINAL_NUMBERS_REPLAY_DRIFT")
    else:
        # Stored entries have a bounded ZIP/ZIP64 header overhead. Count this
        # additional shared object before writing, not after the disk is full.
        pending = sum(map(len, entries.values())) + 4096 * (len(entries) + 1)
        _require(pending <= O_FIT_COMPONENT_BYTES, "F4_O_FIT_FINAL_NUMBERS_ARCHIVE_TOO_LARGE")
        jobs = [{"source": str(root / "request" / row["path"]),
                 "root": str(root / "components/score-native" / row["family"] /
                             f"R{row['repeat']}_K{row['inner_fold']}_M{row['imputation']:02d}")}
                for row in request["component_records"]]
        _full_score_storage_usage(root, jobs, retained_bytes_per_component=request["retained_bytes_per_component"],
            shared_storage_bytes=request["shared_storage_bytes"], pending_result_bytes=pending)
        _require(shutil.disk_usage(root).free >= pending + request["resource_policy"]["scratch_reserve_bytes"],
                 "F4_O_FIT_FINAL_NUMBERS_DISK_SPACE_INSUFFICIENT")
        write_deterministic_zip(target, entries, stored_members=set(entries))
    _require(target.stat().st_size <= O_FIT_COMPONENT_BYTES, "F4_O_FIT_FINAL_NUMBERS_ARCHIVE_TOO_LARGE")
    _require(read_o_fit_final_numbers(target, request=request, request_root=root / "request", lock=lock, native_members=native_members) == rebuilt,
             "F4_O_FIT_FINAL_NUMBERS_REPLAY_DRIFT")
    return rebuilt


def read_full_pipeline_resampling(
    value: Mapping[str, Any], patient_ids: list[str], centers: list[int], events: list[int],
) -> dict[str, Any]:
    """Read the actual audited virtual-0 allocation, never draw another split.

    Source, complete partitions, strata counts and seed addresses are checked.
    The retired native MICE does not prove the original RNG permutation here;
    its exact allocation was admitted before this retention boundary.
    """
    from .bundle import validate_sha256
    _require(len(patient_ids) == len(set(patient_ids)) == len(centers) == len(events) > 0
             and all(type(x) is int and x in {36, 38, 39, 48, 52, 54, 55} for x in centers)
             and all(type(x) is int and x in {0, 1} for x in events),
             "F4_COMPACT_RESAMPLING_SOURCE_INVALID")
    for patient in patient_ids:
        validate_sha256(patient, "F4_COMPACT_PATIENT_KEY")
    ordered = sorted(zip(patient_ids, centers, events, strict=True))
    ids = [row[0] for row in ordered]
    source = {"patient_ids": ids, "centers": [row[1] for row in ordered], "events": [row[2] for row in ordered]}
    _require(isinstance(value, Mapping) and set(value) == {"algorithm", "virtual_outer", "patient_ids",
        "split_count", "input_sha256", "rng", "r_version", "splits", "outer_split_reused", "model_fit_count"}
        and value["algorithm"] == "CENTER_EVENT_STRATIFIED_LECUYER_ROUND_ROBIN_V1"
        and type(value["virtual_outer"]) is int and value["virtual_outer"] == 0
        and value["patient_ids"] == ids and type(value["split_count"]) is int and value["split_count"] == 15
        and value["input_sha256"] == sha256_bytes(canonical_json_bytes(source))
        and value["rng"] == ["L'Ecuyer-CMRG", "Inversion", "Rejection"]
        and isinstance(value["r_version"], str) and bool(value["r_version"])
        and value["outer_split_reused"] is False and type(value["model_fit_count"]) is int
        and value["model_fit_count"] == 0 and isinstance(value["splits"], list) and len(value["splits"]) == 15,
        "F4_COMPACT_RESAMPLING_RECORD_INVALID")
    by_id = {row[0]: row[1:] for row in ordered}
    strata = Counter(by_id.values())
    for repeat in range(1, 4):
        current = value["splits"][(repeat - 1) * 5:repeat * 5]
        heldout = []
        for inner, row in enumerate(current, 1):
            _require(isinstance(row, Mapping) and set(row) == {"repeat", "inner_fold", "seed", "training_ids", "validation_ids"}
                     and all(type(row[key]) is int and row[key] == expected for key, expected in
                             (("repeat", repeat), ("inner_fold", inner), ("seed", 100000 + repeat * 100)))
                     and isinstance(row["training_ids"], list) and isinstance(row["validation_ids"], list)
                     and all(isinstance(pid, str) for pid in row["training_ids"] + row["validation_ids"]),
                     "F4_COMPACT_RESAMPLING_PARTITION_INVALID")
            train, valid = row["training_ids"], row["validation_ids"]
            _require(valid == sorted(set(valid)) and train == sorted(set(train)) and bool(train) and bool(valid)
                     and set(train).isdisjoint(valid) and set(train) | set(valid) == set(ids),
                     "F4_COMPACT_RESAMPLING_PARTITION_INVALID")
            observed = Counter(by_id[pid] for pid in valid)
            _require({by_id[pid][1] for pid in train} == {by_id[pid][1] for pid in valid} == {0, 1}
                     and all(observed[stratum] == (size // 5 + (inner <= size % 5))
                             for stratum, size in strata.items()), "F4_COMPACT_RESAMPLING_STRATUM_INVALID")
            heldout.extend(valid)
        _require(sorted(heldout) == ids, "F4_COMPACT_RESAMPLING_REPEAT_COVERAGE_INVALID")
    return dict(value)


def _full_pipeline_mice_completed_values(
    covariates_csv: bytes, view: Mapping[str, Any], input_dir: Any, *, label: str = "F5_A12_MICE_NUMBERS_",
) -> None:
    """Original observed/donor/passive checks shared by AAR and full0 readers."""
    import csv
    import io
    from pathlib import Path
    from ._science_authority import load_science_authority
    from .bundle import ContractError
    source_reader = csv.DictReader(io.StringIO(covariates_csv.decode("utf-8-sig")))
    raw_rows = {row["Patient_ID"]: row for row in source_reader}
    from .f2_kernel import _locked_categorical_levels, predictor_contract
    levels = {row["name"]: _locked_categorical_levels(row)
              for row in predictor_contract(Path(__file__).parent)["variables"]
              if row["type"] in {"binary", "ordered", "unordered"}}
    science = load_science_authority()['science']['mice']
    from .f1_kernel import effective_mice_rows, formula_value
    raw_rows = effective_mice_rows(raw_rows, science)
    targets = {row["target"] for row in science['target_rules']}
    derived_rules = science['formula_completion']['derived']
    nullable = set(science['formula_completion']['raw_only_nullable'])
    donors = {name: [float(raw_rows[pid][name]) for pid in view["analysis_ids"]
                     if raw_rows[pid][name].strip()] for name in targets}
    for imputation in range(1, 21):
        with (input_dir / f"imp{imputation:02d}.csv").open(encoding="utf-8-sig", newline="") as handle:
            reader = csv.DictReader(handle)
            rows = list(reader)
        _require(reader.fieldnames == source_reader.fieldnames
                 and [row.get("Patient_ID") for row in rows] == view["row_ids"]
                 and all(set(row) == set(reader.fieldnames) and all(isinstance(item, str) for item in row.values())
                         and row["Center"] == raw_rows[row["Patient_ID"]]["Center"] for row in rows),
                 label + "COMPLETED_ROWS_INVALID")
        for row in rows:
            original = raw_rows[row["Patient_ID"]]
            numeric = {}
            for name, item in row.items():
                if name in nullable and not item.strip():
                    _require(not original[name].strip(), label + "OBSERVED_VALUE_DRIFT")
                    continue
                _require(bool(item.strip()), label + "COMPLETED_VALUE_INVALID")
                if name in levels:
                    _require(item.strip() in levels[name], label + "COMPLETED_VALUE_INVALID")
                elif name != "Patient_ID":
                    try:
                        numeric[name] = float(item)
                    except ValueError as exc:
                        raise ContractError(label + "COMPLETED_VALUE_INVALID") from exc
                    _require(math.isfinite(numeric[name]), label + "COMPLETED_VALUE_INVALID")
                if name not in targets | {"BMI", "eGFR_calc", "AST_ALT"} | set(derived_rules):
                    _require(item == original[name], label + "OBSERVED_VALUE_DRIFT")
                elif name in targets:
                    # F1 complete() preserves observed targets. PMM
                    # fills only from observed, non-ignored training
                    # donors; Creatinine is inverse-transformed first.
                    support = [float(original[name])] if original[name].strip() else donors[name]
                    _require(any(math.isclose(numeric[name], observed, rel_tol=1e-14, abs_tol=0.0)
                                 for observed in support), label + "TARGET_VALUE_DRIFT")
            try:
                # Verbatim F1 passive formula, not an imputation or
                # refit. 1e-14 allows its 15-significant-digit CSV
                # serialization (including log1p/expm1 round trips).
                female = int(float(row["Sex"]) == 1)
                ratio = numeric["Creatinine"] / 88.4 / (0.7 if female else 0.9)
                derived = {"BMI": numeric["Weight_kg"] / (numeric["Height_cm"] / 100)**2,
                    "eGFR_calc": 142 * min(ratio, 1)**(-0.241 if female else -0.302)
                        * max(ratio, 1)**(-1.200) * 0.9938**numeric["Age"] * 1.012**female}
                if "AST_ALT" in numeric:
                    derived["AST_ALT"] = numeric["AST"] / numeric["ALT"]
                for name in ('HCT', 'MCH', 'MCHC'):
                    if name in numeric:
                        derived[name] = formula_value({**numeric, **derived}, derived_rules[name])
                valid = all(math.isfinite(expected) and math.isclose(numeric[name], expected,
                            rel_tol=1e-14, abs_tol=0.0) for name, expected in derived.items())
            except (ValueError, ZeroDivisionError, OverflowError, TypeError):
                valid = False
            _require(valid, label + "DERIVED_VALUE_DRIFT")


def _full_pipeline_mice_numbers(value: Mapping[str, Any], context: Mapping[str, Any]) -> None:
    """M20 iteration/configuration numbers after each original mids audit."""
    import csv
    import io
    from pathlib import Path
    from .f1 import load_f1_authority
    from .f2_kernel import _locked_categorical_levels, predictor_contract
    science = load_f1_authority()["science"]["mice"]
    levels = {row["name"]: _locked_categorical_levels(row)
              for row in predictor_contract(Path(__file__).parent)["variables"]
              if row["type"] in {"binary", "ordered", "unordered"}}
    reader = csv.DictReader(io.StringIO(context["covariates_csv"].decode("utf-8-sig")))
    columns = [name for name in reader.fieldnames if name != "Patient_ID"]
    from .f1_kernel import effective_mice_rows, mice_terminal_valid, validate_mice_continuation
    raw = effective_mice_rows({row["Patient_ID"]: row for row in reader}, science)
    specs = context["mice_specs"]
    names = {"ACTUAL_MICE_METHOD", "ACTUAL_PREDICTOR_MATRIX", "ACTUAL_BLOT", "ACTUAL_CONTINUATION_CONFIG"}
    _require(isinstance(value, Mapping) and set(value) == set(specs), "F4_COMPACT_MICE_VIEW_COVERAGE_INVALID")
    paths = {"authority_path", "variable_path", "covariates_path", "response_path", "output_dir"}
    for role, spec in specs.items():
        item, view = value[role], spec["view"]
        _require(isinstance(item, Mapping) and set(item) == {"spec", "summary", "configuration"}
                 and item["spec"] == {k: v for k, v in spec.items() if k not in paths}
                 and (type(item["spec"]["chain_rng_substream"]) is int if "chain_rng_substream" in spec else
                      spec.get("mode") == "IMPUTE_VIEW" and (isinstance(spec.get("nested_aar_source"), Mapping)
                          or context.get("full0") is True and view["outer_fold"] == 0))
                 and all(type(seed) is int for seed in item["spec"]["chain_seeds"])
                 and isinstance(item["summary"], Mapping) and isinstance(item["configuration"], Mapping)
                 and set(item["configuration"]) == names, "F4_COMPACT_MICE_VIEW_INVALID")
        summary = item["summary"]
        from .f1_kernel import complete_data_passthrough
        passthrough = complete_data_passthrough(summary)
        additional = {"completion_mode", "actual_mice_chains", "rng_consumed"} if passthrough else set()
        _require(set(summary) == {"schema_version", "kind", "status", "view_id", "role", "outer_fold",
                    "row_count", "analysis_row_count", "row_ids_sha256", "formal_m", "active_target_count",
                    "final_iteration", "application_response_columns", "application_predictor_matrix_response_edges",
                    "analysis_auxiliary_predictor_edges", "convergence_max_psrf", "relationship_diagnostics"} | additional
                 and summary["schema_version"] == "1.0.0" and summary["kind"] == "PADML_F1_MICE_VIEW_SUMMARY"
                 and summary["status"] == "PASS" and summary["view_id"] == view["view_id"]
                 and summary["role"] == view["role"] and type(summary["outer_fold"]) is int
                 and summary["outer_fold"] == view["outer_fold"]
                 and type(summary["row_count"]) is int and summary["row_count"] == len(view["row_ids"])
                 and type(summary["analysis_row_count"]) is int and summary["analysis_row_count"] == len(view["analysis_ids"])
                 and summary["row_ids_sha256"] == view["row_ids_sha256"]
                 and type(summary["formal_m"]) is int and summary["formal_m"] == 20
                 and mice_terminal_valid(summary)
                 and all(type(summary[k]) is int and summary[k] == 0 for k in
                         ("application_response_columns", "application_predictor_matrix_response_edges")),
                 "F4_COMPACT_MICE_QC_INVALID")
        configurations = {}
        for name, record in item["configuration"].items():
            _require(isinstance(record, Mapping) and set(record) == {"schema_version", "component", "view_id", "payload"}
                     and record["schema_version"] == "1.0.0" and record["component"] == name
                     and record["view_id"] == view["view_id"] and isinstance(record["payload"], Mapping),
                     "F4_COMPACT_MICE_CONFIGURATION_INVALID")
            configurations[name] = record["payload"]
        expected_names = columns + (["event_aux", "nelson_aalen_aux"] if view["role"] == "ANALYSIS" else [])
        active = [row["target"] for row in science["target_rules"]
                  if any(not raw[p][row["target"]].strip() for p in view["row_ids"])]
        _require(passthrough == (not active) and type(summary["active_target_count"]) is int
                 and summary["active_target_count"] == len(active)
                 and configurations["ACTUAL_MICE_METHOD"] == {"names": expected_names,
                     "values": ["pmm" if name in active else "" for name in expected_names]}
                 and configurations["ACTUAL_BLOT"] == {"rows": [{"target": name, **science["pmm"]} for name in active]},
                 "F4_COMPACT_MICE_CONFIGURATION_INVALID")
        validate_mice_continuation(configurations['ACTUAL_CONTINUATION_CONFIG'], summary, spec['chain_seeds'], active)
        for row in configurations["ACTUAL_BLOT"]["rows"]:
            _require(all(type(row[k]) is int for k in ("donors", "matchtype", "trim"))
                     and _finite_number(row["ridge"]), "F4_COMPACT_MICE_CONFIGURATION_INVALID")
        continuation = configurations["ACTUAL_CONTINUATION_CONFIG"]
        _require(all(type(continuation[k]) is int for k in ("initial_iteration", "continuation_increment"))
                 and all(type(number) is int for key in ("continuation_iterations", "chain_seeds", "final_iterations")
                         for number in continuation[key]), "F4_COMPACT_MICE_CONFIGURATION_INVALID")
        matrix = configurations["ACTUAL_PREDICTOR_MATRIX"]
        _require(set(matrix) == {"row_names", "column_names", "values"}
                 and matrix["row_names"] == matrix["column_names"] == expected_names
                 and isinstance(matrix["values"], list) and len(matrix["values"]) == len(expected_names)
                 and all(isinstance(row, list) and len(row) == len(expected_names)
                         and all(type(x) is int and x in {0, 1} for x in row) for row in matrix["values"])
                 and all(matrix["values"][i][i] == 0 for i in range(len(expected_names))),
                 "F4_COMPACT_MICE_MATRIX_INVALID")
        targets = {row["target"]: row for row in science["target_rules"]}
        for name, edges in zip(expected_names, matrix["values"], strict=True):
            candidates = set()
            if name in targets:
                rule = targets[name]
                candidates.update(rule["required_predictors"])
                for group in rule["optional_group_ids"]:
                    candidates.update(science["predictor_groups"][group])
                candidates.intersection_update(expected_names)
                candidates.difference_update([*rule["forbidden_predictors"], *science["always_forbidden_predictors"], name])
                # F1 forces the ratio; the original A12 bridge removes that
                # exact expression together with the three raw channels.
                if "AST_ALT" in columns:
                    candidates.add("AST_ALT")
                if view["role"] == "ANALYSIS":
                    candidates.update(("event_aux", "nelson_aalen_aux"))
                # Original factor_support_ok: all declared levels need five
                # training rows whose target is observed. Numeric predictors
                # bypass this categorical support check, even for inactive targets.
                for predictor in candidates & levels.keys():
                    counts = Counter(raw[pid][predictor].strip() for pid in view["analysis_ids"]
                                     if raw[pid][name].strip())
                    if len(levels[predictor]) < 2 or any(counts[level] < 5 for level in levels[predictor]):
                        candidates.remove(predictor)
                candidates.discard(name)
            _require(edges == [int(predictor in candidates) for predictor in expected_names],
                     "F4_COMPACT_MICE_MATRIX_INVALID")
        auxiliary = sum(matrix["values"][expected_names.index(target)][expected_names.index(column)]
                        for target in active for column in ("event_aux", "nelson_aalen_aux") if column in expected_names)
        _require(type(summary["analysis_auxiliary_predictor_edges"]) is int
                 and summary["analysis_auxiliary_predictor_edges"] == auxiliary
                 and auxiliary == (2 * len(active) if view["role"] == "ANALYSIS" else 0),
                 "F4_COMPACT_MICE_MATRIX_INVALID")


def read_full_pipeline_mice_compact(
    value: Mapping[str, Any], *, plan: Mapping[str, Any], replicate: int, context: int,
    frozen_source: Mapping[str, Any],
) -> dict[str, Any]:
    """Rebuild actual clone/source/split context without mids or completed tables."""
    from pathlib import Path
    from .bundle import validate_sha256
    from .f4 import _prepare_full_pipeline_mice_context, _full_pipeline_mice_context_record
    _require(isinstance(value, Mapping) and set(value) == {"kind", "native_context", "views", "identity_sha256"}
             and value["kind"] == "PADML_F4_MICE_CONTEXT_NUMBERS_V1"
             and value["identity_sha256"] == sha256_bytes(canonical_json_bytes({k: v for k, v in value.items()
                                                                               if k != "identity_sha256"}))
             and isinstance(value["native_context"], Mapping), "F4_COMPACT_MICE_CONTEXT_INVALID")
    native = value["native_context"]
    _require(set(native) == {"kind", "source", "clone_mapping", "inner_partitions", "original_evaluation_ids",
                            "resampling", "view_names", "members", "identity_sha256"}
             and isinstance(native["members"], Mapping), "F4_COMPACT_MICE_CONTEXT_INVALID")
    _require((isinstance(native["resampling"], Mapping) if context == 0
              and plan["family"] not in {"COX_PH", "FPM_TVC_SET_A"} else native["resampling"] is None),
             "F4_COMPACT_MICE_RESAMPLING_REQUIRED")
    expected = _prepare_full_pipeline_mice_context(plan, replicate, context, frozen_source,
        Path("/PADML_COMPACT_SOURCE_ONLY/mice"), rscript="/NO_NATIVE_CALL_IN_COMPACT_READER",
        registered_resampling=native["resampling"])
    _require(set(native["members"]) == {f"views/{name}.zip" for name in expected["mice_specs"]},
             "F4_COMPACT_MICE_VIEW_COVERAGE_INVALID")
    for member in native["members"].values():
        _require(isinstance(member, Mapping) and set(member) == {"sha256", "size_bytes"}
                 and type(member["size_bytes"]) is int and member["size_bytes"] > 0,
                 "F4_COMPACT_MICE_NATIVE_SOURCE_INVALID")
        validate_sha256(member["sha256"], "F4_COMPACT_MICE_ORIGINAL_VIEW")
    body = {"kind": "PADML_F4_FULL_PIPELINE_MICE_CONTEXT_NATIVE_V1",
            **_full_pipeline_mice_context_record(expected), "members": native["members"]}
    _require(canonical_json_bytes(native) == canonical_json_bytes(
        {**body, "identity_sha256": sha256_bytes(canonical_json_bytes(body))}),
             "F4_COMPACT_MICE_SOURCE_MISMATCH")
    _full_pipeline_mice_numbers(value["views"], expected)
    return {**expected, "archive_identity_sha256": native["identity_sha256"]}


def write_full_pipeline_mice_compact(
    context: Mapping[str, Any], target: Any, *, plan: Mapping[str, Any], frozen_source: Mapping[str, Any],
) -> dict[str, Any]:
    """Read numbers after the current native loader; never delete source objects."""
    from .bundle import strict_json_bytes
    _require(target.is_absolute() and target.parent.is_dir() and not target.exists() and not target.is_symlink(),
             "F4_COMPACT_MICE_TARGET_INVALID")
    root = context["native_root"]
    native = strict_json_bytes((root.parent / "context.json").read_bytes())
    _require(native["identity_sha256"] == context["archive_identity_sha256"], "F4_COMPACT_MICE_NATIVE_SOURCE_INVALID")
    paths = {"authority_path", "variable_path", "covariates_path", "response_path", "output_dir"}
    views = {}
    for role in context["mice_specs"]:
        directory = root / role
        spec = strict_json_bytes((directory / "spec.json").read_bytes())
        views[role] = {"spec": {k: v for k, v in spec.items() if k not in paths},
            "summary": strict_json_bytes((directory / "output/summary.json").read_bytes()),
            "configuration": {name: strict_json_bytes((directory / f"output/configuration/{name}.json").read_bytes())
                for name in ("ACTUAL_MICE_METHOD", "ACTUAL_PREDICTOR_MATRIX", "ACTUAL_BLOT", "ACTUAL_CONTINUATION_CONFIG")}}
    body = {"kind": "PADML_F4_MICE_CONTEXT_NUMBERS_V1", "native_context": native, "views": views}
    value = {**body, "identity_sha256": sha256_bytes(canonical_json_bytes(body))}
    read_full_pipeline_mice_compact(value, plan=plan, replicate=context["source"]["bootstrap_replicate"],
                                    context=context["source"]["context"], frozen_source=frozen_source)
    with target.open("xb") as handle:
        handle.write(canonical_json_bytes(value))
    return value


def _full_pipeline_q_registered_numbers(
    value: Mapping[str, Any], context: Mapping[str, Any], views: Mapping[str, Any],
) -> dict[str, Any]:
    """Source-bind the originally audited merged tables, without recreating them.

    Member hashes below are actual historical merge records, not hashes derived
    from two MICE input hashes. Retired completed values cannot be reopened here.
    """
    from .bundle import validate_sha256
    from .f5 import _mice_native_sources_match
    from .f4 import (_response_rows, _write_response_subset, _full_pipeline_mice_native_sources,
                     _full_pipeline_mice_view_members)
    _require(context["source"]["context"] == 0 and context["source"]["family"] == "XGBOOST_COX"
             and isinstance(value, Mapping) and isinstance(value.get("partitions"), list)
             and len(value["partitions"]) == 30 and isinstance(views, Mapping),
             "F4_COMPACT_Q_REGISTERED_INVALID")
    specifications = context["mice_specs"]
    rows = context["inner_partitions"]
    _require([(row["repeat"], row["inner_fold"]) for row in rows]
             == [(r, k) for r in range(1, 4) for k in range(1, 6)], "F4_COMPACT_Q_REGISTERED_INVALID")
    full_ids = [row["clone_id"] for row in context["clone_mapping"]]
    fields, responses = _response_rows(context["response_csv"])
    native_sources = _full_pipeline_mice_native_sources(next(iter(specifications.values())))
    expected, identities, used_views = [], [], set()
    for kind in ("INNER", "STOP"):
        for row in rows:
            name = f"{kind}_R{row['repeat']}_K{row['inner_fold']}"
            definition = row if kind == "INNER" else row["stopping"]
            fit, evaluation = definition["analysis_ids"], definition["validation_ids"]
            application = full_ids if kind == "INNER" else row["analysis_ids"]
            analysis_name, application_name = name + "_ANALYSIS", name + "_APPLICATION"
            for role_name in (analysis_name, application_name):
                _require(role_name in views, "F4_COMPACT_Q_MICE_VIEW_MISSING")
                native, spec = views[role_name], specifications[role_name]
                members = native.get("members") if isinstance(native, Mapping) else None
                _require(isinstance(members, Mapping)
                         and set(members) == _full_pipeline_mice_view_members(spec["view"]["role"]),
                         "F4_COMPACT_Q_MICE_VIEW_INVALID")
                for member in members.values():
                    _require(isinstance(member, Mapping) and set(member) == {"sha256", "size_bytes"}
                             and type(member["size_bytes"]) is int and member["size_bytes"] >= 0,
                             "F4_COMPACT_Q_MICE_MEMBER_INVALID")
                    validate_sha256(member["sha256"], "F4_COMPACT_Q_MICE_MEMBER")
                _require(_mice_native_sources_match(native.get("native_sources"), native_sources),
                         "F4_COMPACT_Q_MICE_SOURCE_MISMATCH")
                body = {"kind": "PADML_F4_FULL_PIPELINE_MICE_VIEW_NATIVE_V1", "source": context["source"],
                        "view_name": role_name, "native_sources": native["native_sources"],
                        "members": members}
                _require(canonical_json_bytes(native) == canonical_json_bytes(
                    {**body, "identity_sha256": sha256_bytes(canonical_json_bytes(body))}),
                         "F4_COMPACT_Q_MICE_SOURCE_MISMATCH")
                used_views.add(role_name)
            _require(specifications[analysis_name]["view"]["row_ids"] == fit
                     and specifications[application_name]["view"]["row_ids"] == application
                     and set(fit).isdisjoint(evaluation) and set(fit + evaluation) == set(application),
                     "F4_COMPACT_Q_PARTITION_SOURCE_MISMATCH")
            saved = value["partitions"][len(expected)]
            covariates = saved.get("covariates") if isinstance(saved, Mapping) else None
            members = covariates.get("members") if isinstance(covariates, Mapping) else None
            _require(isinstance(members, list) and len(members) == 20, "F4_COMPACT_Q_M20_REQUIRED")
            for imp, member in enumerate(members, 1):
                _require(isinstance(member, Mapping) and set(member) == {"name", "sha256", "size_bytes"}
                         and member["name"] == f"imp{imp:02d}.csv" and type(member["size_bytes"]) is int
                         and member["size_bytes"] > 0, "F4_COMPACT_Q_MERGED_MEMBER_INVALID")
                validate_sha256(member["sha256"], "F4_COMPACT_Q_MERGED_MEMBER")
            covariates = {"members": members, "analysis_ids_sha256": sha256_bytes(canonical_json_bytes(fit)),
                "analysis_view_sha256": sha256_bytes(canonical_json_bytes(views[analysis_name])),
                "application_view_sha256": sha256_bytes(canonical_json_bytes(views[application_name]))}
            covariates["data_identity"] = sha256_bytes(canonical_json_bytes(covariates))
            part = {"partition_id": specifications[analysis_name]["view"]["view_id"], "kind": kind,
                "repeat": row["repeat"], "inner_fold": row["inner_fold"], "fit_ids": fit,
                "evaluation_ids": evaluation, "application_ids": application,
                "evaluation_ids_sha256": sha256_bytes(canonical_json_bytes(evaluation)), "covariates": covariates,
                **{label: {k: v for k, v in _write_response_subset(fields, responses, ids, None).items()
                          if k != "private_bytes"}
                   for label, ids in (("fit_response", fit), ("evaluation_response", evaluation))},
                **({"consumer_set": ["GBM_COX", "XGBOOST_COX", "COXTIME_SET_A"]} if kind == "STOP" else {})}
            expected.append(part)
            identities.append({"kind": kind, "partition_id": part["partition_id"], "repeat": part["repeat"],
                "inner_fold": part["inner_fold"], "fit_ids_sha256": sha256_bytes(canonical_json_bytes(fit)),
                "evaluation_ids_sha256": part["evaluation_ids_sha256"],
                "covariate_data_identity": covariates["data_identity"],
                "fit_response_sha256": part["fit_response"]["sha256"],
                "evaluation_response_sha256": part["evaluation_response"]["sha256"]})
    result = {"schema_version": "1.0.0", "kind": "PADML_F4_FULL_PIPELINE_REGISTERED_INPUTS",
        "status": "PASS", "fold": 0, "outer_count": 0, "inner_count": 15, "stop_count": 15,
        "diagnostic_count": 0, "full_count": 0, "view_count": 30, "partitions": expected,
        "diagnostic_partitions": [], "identity": sha256_bytes(canonical_json_bytes(identities))}
    _require(set(views) == used_views and canonical_json_bytes(value) == canonical_json_bytes(result),
             "F4_COMPACT_Q_REGISTERED_SOURCE_MISMATCH")
    return result


def _full_pipeline_q_read_admission(root: Any, policy: Mapping[str, Any], *, native_audit: bool) -> dict:
    """Reserve actual retained Q readback in the existing host resource rule."""
    from .runtime import observe_execution_resources, resource_admission, validate_resource_policy
    from .f5 import _q_batch_metadata_limits
    _require(type(native_audit) is bool, "F4_COMPACT_Q_RESOURCE_SCOPE_INVALID")
    policy = validate_resource_policy(policy)
    files = []
    for path in (root / "native").rglob("*"):
        _require(not path.is_symlink() and (path.is_file() or path.is_dir()), "F4_COMPACT_Q_MEMBER_INVALID")
        if path.is_file():
            files.append(path)
            _require(len(files) <= 40000, "F4_COMPACT_Q_MEMBER_SET_INVALID")
    input_bytes = sum((root / name).stat().st_size for name in ("input.json", "result.json"))
    sizes = [path.stat().st_size for path in files]
    # Native audit preserves a complete replay plus every original STOP
    # quarantine copy. Two whole-native-tree allowances bound both, including
    # the complete function batch rather than only active workers.
    pending = (2 * sum(sizes) + 2 * input_bytes if native_audit else 0)
    metadata = 2 * 16 * 1024**2 + 8192 * 20000
    index = root / "numbers.json"
    _require(native_audit or index.is_file() and not index.is_symlink(), "F4_COMPACT_Q_NUMBERS_REQUIRED")
    index_bytes = 16 * 1024**2 if native_audit else index.stat().st_size
    _require(index_bytes <= 16 * 1024**2, "F4_COMPACT_Q_NUMBERS_REQUIRED")
    execution = root / "execution.json"
    execution_bytes = execution.stat().st_size if execution.exists() else 0
    # The completed ledger contains up to 2600 bounded producer records and
    # one envelope. Charge its actual bytes before the numerical reader below.
    record_limit, count_limit = _q_batch_metadata_limits()
    _require(execution_bytes <= (count_limit + 1) * record_limit and not execution.is_symlink(),
             "F4_COMPACT_Q_NUMBERS_REQUIRED")
    effective = {**policy,
        "memory_reserve_bytes": policy["memory_reserve_bytes"] + 64 * input_bytes + 32 * (index_bytes + execution_bytes),
        # This function admits a new read, never verifies an old observation.
        # Keep shared reserves, but use the authorized final worker allowance.
        "memory_bytes_per_worker": MIN_WORKER_MEMORY_BYTES,
        "scratch_reserve_bytes": policy["scratch_reserve_bytes"] + pending + (metadata if native_audit else 0)}
    return {**resource_admission(effective, observe_execution_resources(root), legal_tasks=300),
            "effective_policy": effective}

def _full_pipeline_q_numbers_mode(spec: Mapping[str, Any]) -> bool:
    """An explicit numerical read of an already first-audited nested Q."""
    if "native_search_numbers" not in spec:
        return False
    from .f4 import _primary_complex_search_source
    primary = _primary_complex_search_source(spec)
    _require(spec["native_search_numbers"] is True and spec.get("native_search_replay") is True
             and (primary is not None or spec.get("execution_scope") == "F5_FULL_DEVELOPMENT_SEARCH"
                  and spec.get("final_search_source", {}).get("program_id") == "PADML_F45_REBUILD_20260925"
                  or spec.get("execution_scope") == "F5_A12_SEARCH"
                  and spec.get("a12_source", {}).get("source", {}).get("kind")
                  == "PADML_F5_A12_PROJECTED_OUTER_INPUTS_V1"),
             "F4_COMPACT_Q_NUMERICAL_SCOPE_INVALID")
    return True


def _full_pipeline_q_numbers_index(raw: bytes) -> dict:
    """Original numeric-index identity, shared by directory and ZIP readers."""
    from .bundle import strict_json_bytes
    _require(isinstance(raw, bytes) and 0 < len(raw) <= 16 * 1024**2,
             "F4_COMPACT_Q_NUMBERS_INVALID")
    value = strict_json_bytes(raw)
    _require(isinstance(value, dict) and set(value) == {
        "kind", "input_sha256", "result_sha256", "members", "identity_sha256"}
        and value["kind"] in {"PADML_F5_Q_NUMBERS_V1", "PADML_F5_Q_CONSUMED_NUMBERS_V1"}
        and value["identity_sha256"] == sha256_bytes(canonical_json_bytes(
            {key: item for key, item in value.items() if key != "identity_sha256"}))
        and raw == canonical_json_bytes(value), "F4_COMPACT_Q_NUMBERS_INVALID")
    return value


def _consumed_q_members(root, *, references=None):
    """Current-batch Q consumes each atom's original first audit and curves.

    Native risk arrays belong only to the shared producer while still needed.
    A completed Q carrier contains no second native search tree.
    """
    from .bundle import sha256_file, strict_json_bytes, validate_sha256
    from .nested_loco import _write_exact_once
    from pathlib import Path, PurePosixPath
    target = root / "numbers.json"
    if references is None:
        value = _full_pipeline_q_numbers_index(target.read_bytes())
        _require(value["kind"] == "PADML_F5_Q_CONSUMED_NUMBERS_V1", "F45_Q_COMPACT_INDEX_INVALID")
        refs = value["members"]
    else:
        refs = dict(references)
        refs["result.json"] = {"sha256": sha256_file(root / "result.json"), "size_bytes": (root / "result.json").stat().st_size}
        body = {"kind": "PADML_F5_Q_CONSUMED_NUMBERS_V1", "input_sha256": refs["input.json"]["sha256"],
            "result_sha256": refs["result.json"]["sha256"], "members": refs}
        value = {**body, "identity_sha256": sha256_bytes(canonical_json_bytes(body))}
    _require(value["input_sha256"] == refs["input.json"]["sha256"]
        and value["result_sha256"] == refs["result.json"]["sha256"], "F45_Q_COMPACT_INDEX_INVALID")
    members, verified_inodes = {}, {}
    for name, pin in refs.items():
        path = PurePosixPath(name)
        _require(not path.is_absolute() and ".." not in path.parts and str(path) == name
            and set(pin) == {"sha256", "size_bytes"} and type(pin["size_bytes"]) is int and pin["size_bytes"] > 0,
            "F45_Q_COMPACT_MEMBER_INVALID")
        validate_sha256(pin["sha256"], "Q.compact_member")
        member = root / name
        _require(member.is_file() and not member.is_symlink() and member.resolve(strict=True).is_relative_to(root),
            "F45_Q_COMPACT_MEMBER_DRIFT")
        stat = member.stat()
        stamp = (stat.st_dev, stat.st_ino, stat.st_size, stat.st_mtime_ns, stat.st_ctime_ns)
        if stamp not in verified_inodes:
            verified_inodes[stamp] = sha256_file(member)
        _require(stat.st_size == pin["size_bytes"] and verified_inodes[stamp] == pin["sha256"],
            "F45_Q_COMPACT_MEMBER_DRIFT")
        members[name] = member
    coordinates = strict_json_bytes(members["native/coordinates.json"].read_bytes())
    from .f5 import _a12_q_stop_phase, _current_q_branch
    from .f4 import _f45_source_member_sha256
    from .run import load_f45_run, f45_unit_predecessors, validate_f45_resource_revision
    import os
    source = strict_json_bytes(members["input.json"].read_bytes())
    result = strict_json_bytes(members["result.json"].read_bytes())
    family = source["spec"]["family"]
    stages = ("S1", "S2", "S3A", "S3B1", "S3B2")
    trials = {"RSF": (24, 8, 3, 2, 1), "GBM_COX": (28, 10, 3, 2, 1),
        "XGBOOST_COX": (40, 14, 3, 2, 1), "COXTIME_SET_A": (12, 4, 2, 2, 1)}
    _require(family in trials and result["family"] == family, "F45_Q_COMPACT_FAMILY_DRIFT")
    if "seed_audit_candidate" in source["spec"]:
        from .f2_kernel import _validate_winner_seed_result
        _validate_winner_seed_result(source["spec"], result)
        stages = ("SEED_AUDIT_1", "SEED_AUDIT_2")
        logical = set()
        for stage in stages:
            roles = [("_run_r_prediction_pool_task", "")] if family == "RSF" else (
                [("_run_r_prediction_pool_task", "_STOP"), ("_run_r_prediction_pool_task", "_REFIT")]
                if family == "GBM_COX" else [("_run_python_stop_pair_pool_task", "_FUNCTION"),
                                             ("_run_xgb_refit_pool_task", "_LOCKED_REFIT")])
            for function, suffix in roles:
                logical.update(f"{function}:{stage}_T001_P{part:02d}_M{imp:02d}{suffix}"
                               for part in range(1, 16) for imp in range(1, 6))
        count = 150
    else:
        logical = set()
        for index, stage in enumerate(stages):
            for refit in ((True,) if family == "RSF" else (False, True)):
                if family in {"XGBOOST_COX", "COXTIME_SET_A"}:
                    function, names = _a12_q_stop_phase(stage, refit=refit, family=family)
                    function = function.rsplit("-", 1)[0]
                else:
                    function = "_run_r_prediction_pool_task"
                    suffix = ("_REFIT" if refit else "_STOP") if family == "GBM_COX" else ""
                    names = [f"{stage}_T{trial:03d}_P{part:02d}_M{imp:02d}{suffix}"
                        for trial in range(1, trials[family][index] + 1)
                        for part in range(1, (5 if index < 3 else 15) + 1)
                        for imp in range(1, (1, 5, 20, 5, 20)[index] + 1)]
                logical.update(function + ":" + name for name in names)
        count = {"RSF": 1070, "GBM_COX": 1140, "XGBOOST_COX": 1300, "COXTIME_SET_A": 810}[family]
    stop = 0 if family == "RSF" else count
    _require(set(coordinates) == logical and result["search_evaluation_unit_count"] == count
        and result["locked_training_refit_count"] == count
        and result["response_free_stopping_fit_count"] == stop
        and result["total_search_fit_count"] == count + stop, "F45_Q_COMPACT_COORDINATE_COVERAGE_INVALID")
    authorities = {sha256_bytes(canonical_json_bytes(_f45_source_member_sha256()))}
    if os.environ.get("PADML_F45_RUN_PATH"):
        run = load_f45_run(Path(os.environ["PADML_F45_RUN_PATH"]))
        authorities = {row["source_identity"] for row in [run, *f45_unit_predecessors(run)]}
        baseline = validate_f45_resource_revision(run)
        if baseline is not None:
            authorities.add(sha256_bytes(canonical_json_bytes(baseline)))
    expected = {"input.json", "result.json", "native/coordinates.json"}
    seen_atoms, input_specs = set(), {}
    source_branch = _current_q_branch(source["spec"])
    for entry in coordinates.values():
        key, prefix = entry["key"], entry["root"]
        validate_sha256(key, "Q.atom")
        _require(prefix == "native/atoms/" + key, "F45_Q_COMPACT_COORDINATE_DRIFT")
        expected.update(prefix + "/" + name for name in ("input.json", "producer.json", "receipt.json", "audit.json", "values.json"))
        if key in seen_atoms:
            continue
        seen_atoms.add(key)
        receipt = strict_json_bytes(members[prefix + "/receipt.json"].read_bytes())
        producer = strict_json_bytes(members[prefix + "/producer.json"].read_bytes())
        audit = strict_json_bytes(members[prefix + "/audit.json"].read_bytes())
        input_sha = refs[prefix + "/input.json"]["sha256"]
        if input_sha not in input_specs:
            input_specs[input_sha] = strict_json_bytes(members[prefix + "/input.json"].read_bytes())["spec"]
        atom_spec = input_specs[input_sha]
        _require(producer["executor_source_identity"] in authorities
            and atom_spec["family"] == family
            and _current_q_branch(atom_spec) == source_branch,
            "F45_Q_COMPACT_PRODUCER_DRIFT")
        _require(producer["key"] == receipt["key"] == key
            and producer["q_input_sha256"] == refs[prefix + "/input.json"]["sha256"]
            and receipt["values"] == refs[prefix + "/values.json"]
            and receipt["audit"] == audit == {"values_sha256": receipt["values"]["sha256"],
                "native_units": receipt["native_units"]}
            and receipt["native_units"] == producer["native_units"], "F45_Q_COMPACT_CONSUMPTION_DRIFT")
        if prefix + '/gbm-losses.json' in refs:
            from .f5 import _current_q_gbm_projection
            _current_q_gbm_projection(root / prefix)
            expected.add(prefix + '/gbm-losses.json')
        donor_key = producer.get('stop_function_source', {}).get('key')
        if donor_key and prefix + '/native/atoms/' + donor_key + '/gbm-losses.json' in refs:
            from .f5 import _current_q_gbm_h36_members
            compact = _current_q_gbm_h36_members(root / prefix)
            _require(compact is not None, 'F45_Q_COMPACT_CONSUMPTION_DRIFT')
            expected.update(prefix + '/' + name for name in compact)
            for name, pin in compact.items():
                _require(refs.get(prefix + '/' + name) == pin, 'F45_Q_COMPACT_CONSUMPTION_DRIFT')
        elif receipt.get('retention') == 'CONSUMED_GBM_STOP_VALUES':
            _require(False, 'F45_Q_COMPACT_CONSUMPTION_DRIFT')
    _require(set(refs) == expected and bool(coordinates), "F45_Q_COMPACT_MEMBER_SET_INVALID")
    if references is not None:
        _write_exact_once(target, canonical_json_bytes(value), "F45_Q_COMPACT_PUBLICATION_DRIFT")
    return {**members, "numbers.json": target}, refs


def _q_object_audit_read(root, parent, local, *, publish, transported_refs, recover_existing_object_audits):
    # The small per-coordinate record avoids decoding the complete Q index
    # in every reused pool worker. It binds the original numeric files too.
    path = root / parent / "object-audit.json"
    payload = canonical_json_bytes(local)
    _require(len(payload) <= 1024**2,
             "F4_COMPACT_Q_NATIVE_REFERENCE_INVALID")
    if publish and transported_refs is None:
        if recover_existing_object_audits and path.exists():
            _require(path.is_file() and not path.is_symlink() and path.resolve(strict=True) == path
                     and path.stat().st_size == len(payload) and path.read_bytes() == payload,
                     "F4_COMPACT_Q_NATIVE_REFERENCE_MISMATCH")
        else:
            __import__("padml.nested_loco", fromlist=["_write_exact_once"])._write_exact_once(path, payload, "F4_COMPACT_Q_NATIVE_REFERENCE_MISMATCH")
    else:
        _require(path.is_file() and not path.is_symlink() and path.resolve(strict=True) == path
                 and path.stat().st_size == len(payload) and path.read_bytes() == payload,
                 "F4_COMPACT_Q_NATIVE_REFERENCE_MISMATCH")
    return path


def _q_coordinate_read_job(job):
    from pathlib import PurePosixPath
    from .bundle import sha256_file, validate_sha256
    root, input_source, refs, operational = (job[key] for key in ("root", "input_source", "refs", "operational"))
    publish, transported_refs, recover_existing_object_audits = (job[key] for key in ("publish", "transported_refs", "recover"))
    def native_object(name):
        path = PurePosixPath(name)
        return path.suffix == ".rds" or path.name in {"model.bin", "baseline.bin", "function.ubj", "checkpoints.pt"}

    projection, objects, by_parent = {}, {}, {}
    for name, record in refs.items():
        _require(isinstance(name, str), "F4_COMPACT_Q_MEMBER_INVALID")
        path = PurePosixPath(name)
        _require(str(path) == name and not path.is_absolute()
                 and all(part not in {"", ".", ".."} for part in path.parts)
                 and (name in {"input.json", "result.json", "execution.json"}
                      or path.parts[0] == "native" or name in operational)
                 and (path.name != "object-audit.json" or name in operational)
                 and isinstance(record, dict) and set(record) == {"sha256", "size_bytes"}
                 and type(record["size_bytes"]) is int and record["size_bytes"] >= 0,
                 "F4_COMPACT_Q_MEMBER_INVALID")
        validate_sha256(record["sha256"], "F4_COMPACT_Q_MEMBER")
        by_parent.setdefault(path.parent.as_posix(), {})[path.name] = record
        if native_object(name):
            _require(record["size_bytes"] > 0, "F4_COMPACT_Q_NATIVE_REFERENCE_INVALID")
            objects.setdefault(path.parent.as_posix(), {})[path.name] = record
        else:
            member = input_source if name == "input.json" else root / name
            _require(member.is_file() and not member.is_symlink() and member.resolve(strict=True) == member
                     and member.stat().st_size == record["size_bytes"] and sha256_file(member) == record["sha256"],
                     "F4_COMPACT_Q_VALUE_BYTES_MISMATCH")
            projection[name] = member
    if job["check_audits"]:
        for parent in objects:
            path = _q_object_audit_read(root, parent, by_parent[parent], publish=publish,
                transported_refs=transported_refs, recover_existing_object_audits=recover_existing_object_audits)
            projection[path.relative_to(root).as_posix()] = path
    return projection, objects


def _full_pipeline_q_numerical_members(
    root: Any, *, publish: bool = False, native_units: tuple[str, ...] | None = None,
    transported_refs: Mapping[str, Any] | None = None,
    recover_existing_object_audits: bool = False,
    resource_policy: Mapping[str, Any] | None = None,
) -> tuple[dict, dict]:
    """Project original Q values after native audit; preserve every native reference."""
    from pathlib import PurePosixPath
    from .bundle import sha256_file, strict_json_bytes, validate_sha256
    # Largest current Q: 1300 XGB pairs, with 11 retained H36 STOP refs
    # and 8 REFIT refs each, plus root input, coordinates and result.
    member_limit = 1300 * (11 + 8) + 3
    _require(type(publish) is bool and type(recover_existing_object_audits) is bool
             and (not recover_existing_object_audits
                  or publish and native_units is not None and transported_refs is None)
             and root.is_absolute() and root.is_dir() and not root.is_symlink()
             and (root / "native").is_dir() and not (root / "native").is_symlink(),
             "F4_COMPACT_Q_PATH_INVALID")
    target = root / "numbers.json"
    if not publish and native_units is None and transported_refs is None and target.is_file():
        index = _full_pipeline_q_numbers_index(target.read_bytes())
        if index["kind"] == "PADML_F5_Q_CONSUMED_NUMBERS_V1":
            return _consumed_q_members(root)
    _require((native_units is None and transported_refs is None)
             or publish and (native_units is None or transported_refs is None)
             or not publish and native_units is not None and transported_refs is not None,
             "F4_COMPACT_Q_PUBLICATION_SCOPE_INVALID")
    roots = [root / "native"]
    if native_units is not None:
        _require(isinstance(native_units, tuple) and 0 < len(native_units) <= 20000
                 and all(isinstance(name, str) and name not in {"", ".", ".."}
                         and all(char.isalnum() or char in "_-" for char in name) for name in native_units)
                 and len(set(native_units)) == len(native_units), "F4_COMPACT_Q_UNIT_SET_INVALID")
        roots = [root / "native" / name for name in native_units]
        _require(all(path.is_dir() and not path.is_symlink() for path in roots),
                 "F4_COMPACT_Q_UNIT_SET_INVALID")
    # A complete Q retains the original recovery call, not a new call inferred
    # from the receiving path. These five byte-pinned leaves are operational
    # evidence, never additions to the old native object-audit records.
    operational = {}
    primary_indexes = []
    input_source = root / "input.json"
    if native_units is not None and transported_refs is not None and transported_refs.get("input.json") != {
            "sha256": sha256_file(input_source), "size_bytes": input_source.stat().st_size}:
        # The existing evidence slot keeps one exact old input for a complete
        # STOP-family Q. Only that family's common stages may read this input.
        from .f5 import _full0_rsf_s1s2_input_pair
        old = root / "execution-evidence/gbm-common/input.json"
        _require(old.is_file() and not old.is_symlink() and old.resolve(strict=True) == old
                 and 0 < old.stat().st_size <= 16 * 1024**2
                 and transported_refs.get("input.json") == {"sha256": sha256_file(old), "size_bytes": old.stat().st_size},
                 "F4_COMPACT_Q_INPUT_MISMATCH")
        prior, current = strict_json_bytes(old.read_bytes()), strict_json_bytes(input_source.read_bytes())
        family = prior.get("task", {}).get("family")
        common_stages = ("S1_",) if family == "COXTIME_SET_A" else ("S1_", "S2_")
        _require(family == current.get("task", {}).get("family")
                 and family in {"GBM_COX", "XGBOOST_COX", "COXTIME_SET_A"}
                 and all(name.startswith(common_stages + (("batch-",) if family == "GBM_COX" else ())) for name in native_units)
                 and any(name.startswith(common_stages) for name in native_units),
                 "F4_COMPACT_Q_INPUT_MISMATCH")
        _full0_rsf_s1s2_input_pair(prior, current)
        input_source = old
    execution = root / "execution.json"
    if native_units is None and execution.exists():
        from .f5 import _q_batch_metadata_limits, _q_completed_execution_records
        record_limit, count_limit = _q_batch_metadata_limits()
        _require(execution.is_file() and not execution.is_symlink()
                 and execution.resolve(strict=True) == execution
                 and 0 < execution.stat().st_size <= (count_limit + 1) * record_limit,
                 "F4_COMPACT_Q_MEMBER_INVALID")
        execution_raw = execution.read_bytes()
        execution_value = strict_json_bytes(execution_raw)
        _require(isinstance(execution_value, dict) and canonical_json_bytes(execution_value) == execution_raw,
                 "F4_COMPACT_Q_MEMBER_INVALID")
        # Match _q_search_batch_completion, not a single producer's 16 MiB
        # limit. The contained count tightens the pre-read absolute bound.
        batches = _q_completed_execution_records(execution_value, len(execution_raw),
                                                 failure="F4_COMPACT_Q_MEMBER_INVALID")
        if "historical_q_publications" in execution_value:
            from .f5 import _primary_q_publication_evidence
            from .f4 import _primary_rsf_search_source
            q_raw = input_source.read_bytes()
            q_value = strict_json_bytes(q_raw)
            _require(_primary_rsf_search_source(q_value["spec"]) is not None,
                     "F4_COMPACT_Q_MEMBER_SET_INVALID")
            _primary_q_publication_evidence(execution_value["historical_q_publications"],
                {"sha256": sha256_bytes(q_raw), "size_bytes": len(q_raw)}, batches=batches)
        if "primary_rsf_evidence" in execution_value:
            from .f5 import _primary_rsf_prepared_input, _a12_q_stop_phase
            from .f4 import _retained_full0_source_members
            primary = execution_value["primary_rsf_evidence"]
            prefix = "execution-evidence/primary-rsf/"
            _require(set(execution_value) == {"batches", "primary_rsf_evidence"}
                         | ({"historical_q_publications"} if "historical_q_publications" in execution_value else set())
                     and isinstance(primary, dict) and 3 < len(primary) < 200,
                     "F4_COMPACT_Q_MEMBER_SET_INVALID")
            files = {}
            for name, pin in primary.items():
                _require(isinstance(name, str) and name.startswith(prefix)
                         and str(PurePosixPath(name)) == name
                         and ".." not in PurePosixPath(name).parts,
                         "F4_COMPACT_Q_MEMBER_INVALID")
                member = root / name
                _require(member.is_file() and not member.is_symlink()
                         and member.resolve(strict=True) == member
                         and 0 < member.stat().st_size <= 16 * 1024**2
                         and pin == {"sha256": sha256_file(member), "size_bytes": member.stat().st_size},
                         "F4_COMPACT_Q_VALUE_BYTES_MISMATCH")
                files[name.removeprefix(prefix)] = member
            legacy = any(name.startswith("s3b2/") for name in files)
            stages = ("s2", "s3a", "s3b1", "s3b2") if legacy else ("s2", "s3a", "s3b1")
            retained_groups = ("s3b1/source/primary-preparation", "s2/source/primary-s1-summary")
            retained_names = {group + "/" + name for group in retained_groups
                              for name in ("input.json", "numbers.json", "result.json")}
            _require(not legacy or not retained_names.intersection(files), "F4_COMPACT_Q_MEMBER_SET_INVALID")
            if not legacy:
                _require(retained_names <= set(files), "F4_COMPACT_Q_MEMBER_SET_INVALID")
                final_result = strict_json_bytes((root / "result.json").read_bytes())
                for group, trace_stages in zip(retained_groups, (("S2", "S3A"), ("S1",)), strict=True):
                    original_index = _full_pipeline_q_numbers_index(files[group + "/numbers.json"].read_bytes())
                    original_input = files[group + "/input.json"].read_bytes()
                    original_raw = files[group + "/result.json"].read_bytes()
                    original_result = strict_json_bytes(original_raw)
                    _require(original_input == input_source.read_bytes()
                             and canonical_json_bytes(original_result) == original_raw
                             and isinstance(original_index.get("members"), dict)
                             and original_index["input_sha256"] == sha256_bytes(original_input)
                             and original_index["result_sha256"] == sha256_bytes(original_raw)
                             and original_index["members"].get("input.json") == {
                                 "sha256": sha256_bytes(original_input), "size_bytes": len(original_input)}
                             and original_index["members"].get("result.json") == {
                                 "sha256": sha256_bytes(original_raw), "size_bytes": len(original_raw)}
                             and original_result.get("primary_search_source") == final_result.get("primary_search_source")
                             and list(original_result.get("search_trace", {})) == list(trace_stages)
                             and all(canonical_json_bytes(original_result["search_trace"][stage])
                                 == canonical_json_bytes(final_result.get("search_trace", {}).get(stage))
                                 for stage in trace_stages), "F4_COMPACT_Q_VALUE_BYTES_MISMATCH")
                    primary_indexes.append(original_index)
            _require({"preparation.zip", "producer.zip", "q-producer.zip"} <= set(files)
                     and all(name in {"preparation.zip", "producer.zip", "q-producer.zip"}
                         or any(name.startswith(stage + "/") for stage in stages) for name in files),
                     "F4_COMPACT_Q_MEMBER_SET_INVALID")
            q_raw = input_source.read_bytes()
            _primary_rsf_prepared_input(q_raw, files["preparation.zip"], files["producer.zip"],
                **{stage + "_evidence": {name.removeprefix(stage + "/"): path
                    for name, path in files.items() if name.startswith(stage + "/")
                    and name not in retained_names} for stage in stages})
            source_members = _retained_full0_source_members(files["q-producer.zip"], primary_rsf_inputs=True)
            spec = strict_json_bytes(q_raw).get("spec", {}) if not legacy else {}
            if not legacy:
                from .f4 import _primary_rsf_search_source, _f45_source_member_sha256
                source = _primary_rsf_search_source(spec)
                _require(source is not None and type(spec.get("fold")) is int and spec["fold"] in range(1, 7)
                         and spec.get("selection_horizon_months") == 12,
                         "F4_COMPACT_Q_MEMBER_SET_INVALID")
            phase_table = {stage: _a12_q_stop_phase(stage, refit=True, family="RSF",
                **({"rsf_pool_workers": spec["pool_workers"]} if not legacy else {}))
                for stage in (("S1", "S3B2") if legacy else ("S1", "S2", "S3A", "S3B1", "S3B2"))}
            present = {row.get("phase") for row in batches}
            _require((len(batches) == 14 if legacy else
                      {phase_table[stage][0] for stage in ("S1", "S2", "S3A", "S3B1", "S3B2")} == present)
                     and present <= {phase for phase, _ in phase_table.values()},
                     "F4_COMPACT_Q_MEMBER_SET_INVALID")
            for stage, (phase, ids) in phase_table.items():
                selected = [row for row in batches if row.get("phase") == phase]
                received = [name for row in selected for name in row.get("task_ids", [])]
                _require((len(selected) == 7 if legacy or stage != "S3B2" else len(selected) == 1)
                         and len(received) == len(set(received))
                         and set(received) == set(ids)
                         and all(row.get("input") == {"sha256": sha256_bytes(q_raw), "size_bytes": len(q_raw)}
                             for row in selected), "F4_COMPACT_Q_MEMBER_SET_INVALID")
                if not legacy:
                    if stage in {"S1", "S2", "S3A"}:
                        group = {"S1": "s2", "S2": "s3a", "S3A": "s3b1"}[stage]
                        original = {path.read_bytes() for name, path in files.items()
                                    if name.startswith(group + "/primary-" + group + "/")
                                    and name.endswith("-execution.json")}
                        _require({canonical_json_bytes(row) for row in selected} == original,
                                 "F4_COMPACT_Q_MEMBER_SET_INVALID")
                    else:
                        identity = sha256_bytes(canonical_json_bytes(source_members if stage == "S3B1"
                                                                    else _f45_source_member_sha256()))
                        _require(all(row.get("source_identity") == identity for row in selected),
                                 "F4_COMPACT_Q_MEMBER_SET_INVALID")
            operational.update(primary)
        derived = {sha256_bytes(canonical_json_bytes(row)) for row in batches if "numerical_consumption" in row}
        table = execution_value.get("gbm_loss_call_evidence", {})
        _require(isinstance(table, dict) and set(table) == derived
                 and bool(derived) == ("gbm_loss_call_evidence" in execution_value),
                 "F4_COMPACT_Q_MEMBER_SET_INVALID")
        for digest, records in table.items():
            _require(isinstance(records, dict) and len(records) == 5
                     and all(isinstance(name, str) for name in records), "F4_COMPACT_Q_MEMBER_SET_INVALID")
            wrappers = [name for name in records if name.startswith("cli/") and name.endswith("-execution.json")]
            _require(len(wrappers) == 1 and wrappers[0].count("/") == 1,
                     "F4_COMPACT_Q_MEMBER_SET_INVALID")
            stem = wrappers[0].removesuffix("-execution.json")
            _require(set(records) == {"collection.json", "execution-evidence/input-execution.json",
                     wrappers[0], stem + ".stdout", stem + ".stderr"}, "F4_COMPACT_Q_MEMBER_SET_INVALID")
            for name, record in records.items():
                _require(isinstance(record, dict) and set(record) == {"sha256", "size_bytes"}
                         and type(record["size_bytes"]) is int and 0 <= record["size_bytes"] <= 32 * 1024**2,
                         "F4_COMPACT_Q_MEMBER_INVALID")
                validate_sha256(record["sha256"], "F4_COMPACT_Q_MEMBER")
                operational[f"execution-evidence/{digest}/{name}"] = record
        sources = execution_value.get("gbm_retained_sources", {})
        outer4_selector_sources = isinstance(sources, dict) and set(sources) - {
            "execution-evidence/retained-sources/selector-executor.zip"} == {
            "execution-evidence/retained-sources/primary1513.zip", "execution-evidence/retained-sources/selector1ae.zip"}
        if outer4_selector_sources:
            # The optional fine-executor leaf is not a second coarse producer.
            # No source set is admitted by filename alone. The original
            # Q source reader binds the exact outer4 decision, actual projected
            # input, old primary/selector bytes and current RSF Q provenance.
            from .f5 import _q_gbm_source_evidence
            input_path = root / "input.json"
            _require(input_path.is_file() and not input_path.is_symlink()
                     and 0 < input_path.stat().st_size <= 16 * 1024**2, "F4_COMPACT_Q_MEMBER_INVALID")
            original_input = strict_json_bytes(input_path.read_bytes())
            spec = original_input.get("spec", {})
            _require(isinstance(spec, dict) and spec.get("family") == "RSF" and spec.get("fold") == 4
                     and spec.get("execution_scope") == "F5_A12_SEARCH"
                     and isinstance(spec.get("a12_source"), Mapping), "F4_COMPACT_Q_MEMBER_INVALID")
            _, source_refs = _q_gbm_source_evidence(root, spec["a12_source"]["source"]["resource_policy"])
            _require(source_refs == sources and not table, "F4_COMPACT_Q_MEMBER_SET_INVALID")
            del original_input, spec, source_refs
        outer5_s3b2_sources = isinstance(sources, dict) and set(sources) - {
            "execution-evidence/retained-sources/a12-q-executor.zip"} == {
            "execution-evidence/retained-sources/" + name for name in (
                "primary1513.zip", "selector1ae.zip", "q73.zip", "q0f.zip",
                "q2cc.zip", "q3ab.zip", "qdf85.zip", "q5c303.zip")}
        if outer5_s3b2_sources:
            from .f5 import _q_gbm_source_evidence
            input_path = root / "input.json"
            _require(input_path.is_file() and not input_path.is_symlink()
                     and 0 < input_path.stat().st_size <= 16 * 1024**2, "F4_COMPACT_Q_MEMBER_INVALID")
            original_input = strict_json_bytes(input_path.read_bytes())
            spec = original_input.get("spec", {})
            _require(isinstance(spec, dict) and isinstance(spec.get("a12_source"), Mapping),
                     "F4_COMPACT_Q_MEMBER_INVALID")
            _, source_refs = _q_gbm_source_evidence(root, spec["a12_source"]["source"]["resource_policy"])
            _require(source_refs == sources, "F4_COMPACT_Q_MEMBER_SET_INVALID")
            del original_input, spec, source_refs
        _require(isinstance(sources, dict) and (not sources and "gbm_retained_sources" not in execution_value
                 or outer4_selector_sources
                 or outer5_s3b2_sources
                 or set(sources) in ({"execution-evidence/retained-sources/" + name for name in names}
                     for names in (("primary1513.zip", "selector1ae.zip", "q73.zip"),
                                   ("primary1513.zip", "selector1ae.zip", "q73.zip", "q0f.zip"),
                                   ("primary1513.zip", "selector1ae.zip", "q73.zip", "q2cc.zip"),
                                   ("primary1513.zip", "selector1ae.zip", "q73.zip", "q0f.zip", "q2cc.zip"),
                                   ("primary1513.zip", "selector1ae.zip", "q73.zip", "q0f.zip", "q2cc.zip", "q3ab.zip"),
                                   ("primary1513.zip", "selector1ae.zip", "q73.zip", "q0f.zip", "q2cc.zip", "q3ab.zip", "qdf85.zip")))),
                 "F4_COMPACT_Q_MEMBER_SET_INVALID")
        for name, record in sources.items():
            _require(isinstance(record, dict) and set(record) == {"sha256", "size_bytes"}
                     and type(record["size_bytes"]) is int and 0 < record["size_bytes"] <= 16 * 1024**2,
                     "F4_COMPACT_Q_MEMBER_INVALID")
            validate_sha256(record["sha256"], "F4_COMPACT_Q_MEMBER")
            operational[name] = record
        rsf = execution_value.get("rsf_s3b2_evidence", {})
        _require(isinstance(rsf, dict) and (not rsf and "rsf_s3b2_evidence" not in execution_value
                 and "retained_rsf_prefix_result_sha256" not in execution_value
                 or rsf and not table and not sources
                 and execution_value.get("retained_rsf_prefix_result_sha256")
                     == "556821c6675669b45a21a8b16d590453158c55705ef43f1696a278ba111f05bd"
                 and rsf.get("execution-evidence/rsf-s3b2/prefix/collection.json") == {
                     "sha256": "c6d3000954e05e52360b9cae97bae834f2ae578cd858bc8ceb0f1fcdacd7b89e", "size_bytes": 1065077}
                 and rsf.get("execution-evidence/rsf-s3b2/tail/preservation.json") == {
                     "sha256": "537f275b023fb7a78c9f8d31cc1e5bb6d928640eae1b071b988960eed2eb6a10", "size_bytes": 299257}),
                 "F4_COMPACT_Q_MEMBER_SET_INVALID")
        for name, record in rsf.items():
            _require(isinstance(name, str) and name.startswith("execution-evidence/rsf-s3b2/")
                     and isinstance(record, dict) and set(record) == {"sha256", "size_bytes"}
                     and type(record["size_bytes"]) is int and 0 <= record["size_bytes"] <= 32 * 1024**2,
                     "F4_COMPACT_Q_MEMBER_INVALID")
            validate_sha256(record["sha256"], "F4_COMPACT_Q_MEMBER")
            operational[name] = record
        rsf24 = execution_value.get("rsf24_numbers_evidence", {})
        _require(isinstance(rsf24, dict) and (not rsf24 and "rsf24_numbers_evidence" not in execution_value
                 or rsf24 and not rsf and not table and not sources
                 and "gbm_common_evidence" not in execution_value
                 and "q_resource_evidence" not in execution_value
                 and "retained_rsf_prefix_result_sha256" not in execution_value
                 and rsf24.get("execution-evidence/rsf24-numbers/prepared/collection.json") == {
                     "sha256": "5a8e27e1883b5a4a0cb3d07ef4e8abaf74dc6e7e05daa06a65887161ef6531c3", "size_bytes": 8354}
                 and rsf24.get("execution-evidence/rsf24-numbers/tail/preservation.json") == {
                     "sha256": "537f275b023fb7a78c9f8d31cc1e5bb6d928640eae1b071b988960eed2eb6a10", "size_bytes": 299257}),
                 "F4_COMPACT_Q_MEMBER_SET_INVALID")
        for name, record in rsf24.items():
            _require(isinstance(name, str) and name.startswith("execution-evidence/rsf24-numbers/")
                     and not PurePosixPath(name).is_absolute() and ".." not in PurePosixPath(name).parts
                     and isinstance(record, dict) and set(record) == {"sha256", "size_bytes"}
                     and type(record["size_bytes"]) is int and 0 <= record["size_bytes"] <= 32 * 1024**2,
                     "F4_COMPACT_Q_MEMBER_INVALID")
            validate_sha256(record["sha256"], "F4_COMPACT_Q_MEMBER")
            operational[name] = record
        if "gbm_common_evidence" in execution_value:
            from .f5 import _full0_rsf_s1s2_input_pair
            from .f4 import load_f45_source_bundle, _f45_source_member_sha256
            common = execution_value["gbm_common_evidence"]
            historical = set(common) == {"execution-evidence/gbm-common/" + role + ".zip"
                for role in ("stop", "publisher", "refit")} if isinstance(common, dict) else False
            _require(isinstance(common, dict) and (historical or set(common) == {
                "execution-evidence/gbm-common/input.json", "execution-evidence/gbm-common/source.zip"})
                and not table and not sources and not rsf and "q_resource_evidence" not in execution_value,
                "F4_COMPACT_Q_MEMBER_SET_INVALID")
            for name, record in common.items():
                member = root / name
                _require(member.is_file() and not member.is_symlink() and member.resolve(strict=True) == member
                         and 0 < member.stat().st_size <= 16 * 1024**2
                         and record == {"sha256": sha256_file(member), "size_bytes": member.stat().st_size},
                         "F4_COMPACT_Q_VALUE_BYTES_MISMATCH")
            if historical:
                # Reuse the original metadata reader's source roles and exact
                # phase coverage; it does not open/replay any native object.
                from .f5 import _q_search_batch_control
                _q_search_batch_control(root, batches[0]["resource_policy"], None,
                    retained_q_producer_source_bundle={role:
                        root / ("execution-evidence/gbm-common/" + role + ".zip")
                        for role in ("stop", "publisher", "refit")})
            else:
                prior = strict_json_bytes((root / "execution-evidence/gbm-common/input.json").read_bytes())
                current = strict_json_bytes((root / "input.json").read_bytes())
                _require(prior.get("task", {}).get("family") == current.get("task", {}).get("family")
                         and current.get("task", {}).get("family") in {"GBM_COX", "XGBOOST_COX", "COXTIME_SET_A"},
                         "F4_COMPACT_Q_INPUT_MISMATCH")
                _full0_rsf_s1s2_input_pair(prior, current)
                manifest = load_f45_source_bundle(root / "execution-evidence/gbm-common/source.zip")
                _require({row["path"]: row["sha256"] for row in manifest["members"]} == _f45_source_member_sha256(),
                         "F4_COMPACT_Q_SOURCE_MISMATCH")
            operational.update(common)
        if "q_resource_evidence" in execution_value:
            from .f5 import _q_python_resource_evidence
            _require(not sources and not table and not rsf
                     and all(sum(sha256_bytes(canonical_json_bytes(row)) == pin["sha256"] for row in batches) == 1
                         for name, pin in execution_value["q_resource_evidence"].items() if name.endswith("-execution.json")),
                     "F4_COMPACT_Q_MEMBER_SET_INVALID")
            _, resource_refs = _q_python_resource_evidence(root, batches[0]["resource_policy"],
                expected=execution_value["q_resource_evidence"])
            operational.update(resource_refs)
        _require(len(operational) <= 20000, "F4_COMPACT_Q_MEMBER_SET_INVALID")
        del execution_raw, execution_value, batches, table, sources, rsf

    if publish or transported_refs is not None:
        _require(not publish or not target.exists() and not target.is_symlink(), "F4_COMPACT_Q_ALREADY_PUBLISHED")
        if transported_refs is None:
            files = {"input.json": root / "input.json"}
            if native_units is None:
                files["result.json"] = root / "result.json"
                if (root / "execution.json").exists():
                    files["execution.json"] = root / "execution.json"
            for directory in roots:
                for path in sorted(directory.rglob("*")):
                    _require(not path.is_symlink() and (path.is_file() or path.is_dir()),
                             "F4_COMPACT_Q_MEMBER_INVALID")
                    if path.is_file():
                        if path.name == "object-audit.json" and recover_existing_object_audits:
                            continue
                        _require(path.name != "object-audit.json", "F4_COMPACT_Q_ALREADY_PUBLISHED")
                        files[path.relative_to(root).as_posix()] = path
                        _require(len(files) <= member_limit, "F4_COMPACT_Q_MEMBER_SET_INVALID")
            refs = {name: {"sha256": sha256_file(path), "size_bytes": path.stat().st_size}
                    for name, path in sorted(files.items())}
            refs.update(operational)
        else:
            _require(isinstance(transported_refs, Mapping) and "result.json" not in transported_refs
                     and 1 < len(transported_refs) < member_limit
                     and isinstance(transported_refs.get("input.json"), dict)
                     and set(transported_refs["input.json"]) == {"sha256", "size_bytes"},
                     "F4_COMPACT_Q_MEMBER_SET_INVALID")
            refs = dict(transported_refs)
            if native_units is None:
                result = root / "result.json"
                _require(result.is_file() and not result.is_symlink(), "F4_COMPACT_Q_MEMBER_INVALID")
                refs["result.json"] = {"sha256": sha256_file(result), "size_bytes": result.stat().st_size}
                execution = root / "execution.json"
                if execution.exists():
                    _require(execution.is_file() and not execution.is_symlink(), "F4_COMPACT_Q_MEMBER_INVALID")
                    refs["execution.json"] = {"sha256": sha256_file(execution), "size_bytes": execution.stat().st_size}
        if native_units is None:
            body = {"kind": "PADML_F5_Q_NUMBERS_V1", "input_sha256": refs["input.json"].get("sha256"),
                    "result_sha256": refs["result.json"]["sha256"], "members": refs}
            value = {**body, "identity_sha256": sha256_bytes(canonical_json_bytes(body))}
            raw = canonical_json_bytes(value)
        else:
            # A first-audited unit is not a completed search. Only the original
            # funnel may later supply result.json and publish the whole index.
            value, raw = None, canonical_json_bytes(refs)
    else:
        _require(target.is_file() and not target.is_symlink() and target.stat().st_size <= 16 * 1024**2,
                 "F4_COMPACT_Q_NUMBERS_REQUIRED")
        raw = target.read_bytes()
        value = _full_pipeline_q_numbers_index(raw)
        refs = value["members"]
    _require(len(raw) <= 16 * 1024**2 and isinstance(refs, dict) and 1 < len(refs) <= member_limit
             and "input.json" in refs and (native_units is not None or 2 < len(refs)
                 and "result.json" in refs
                 and value["input_sha256"] == refs["input.json"]["sha256"]
                 and value["result_sha256"] == refs["result.json"]["sha256"]),
             "F4_COMPACT_Q_MEMBER_SET_INVALID")
    _require(all(isinstance(name, str) for name in refs), "F4_COMPACT_Q_MEMBER_INVALID")
    _require({name: record for name, record in refs.items() if name.startswith("execution-evidence/")}
             == operational, "F4_COMPACT_Q_MEMBER_SET_INVALID")
    for original_index in primary_indexes:
        original_refs = original_index["members"]
        _require(isinstance(original_refs, dict) and all(isinstance(name, str)
                     and (name in {"input.json", "result.json", "execution.json"}
                          or name.startswith(("native/", "execution-evidence/"))) for name in original_refs)
                 and any(name.startswith("native/") for name in original_refs)
                 and all(refs.get(name) == pin for name, pin in original_refs.items()
                     if name.startswith(("native/", "execution-evidence/"))),
                 "F4_COMPACT_Q_VALUE_BYTES_MISMATCH")
    completed_readback = resource_policy is not None and not publish and native_units is None
    grouped = {}
    for name, record in refs.items():
        grouped.setdefault(PurePosixPath(name).parent.as_posix(), {})[name] = record
    jobs = [{"root": root, "input_source": input_source, "refs": group,
        "operational": {name for name in group if name in operational}, "publish": publish,
        "transported_refs": None if transported_refs is None else True,
        "recover": recover_existing_object_audits, "check_audits": completed_readback}
        for group in grouped.values()]
    if completed_readback:
        from .runtime import _readback_ordered
        results = _readback_ordered(_q_coordinate_read_job, jobs, policy=resource_policy, root=root,
            retained_bytes=32 * len(raw),
            per_worker_bytes=32 * max(len(canonical_json_bytes(group)) for group in grouped.values()),
            cache_files=(path for group in ((target,),
                (path for name in refs for path in (
                    (root / PurePosixPath(name).parent / "object-audit.json",)
                    if PurePosixPath(name).suffix == ".rds" or PurePosixPath(name).name in {
                        "model.bin", "baseline.bin", "function.ubj", "checkpoints.pt"}
                    else (input_source if name == "input.json" else root / name,))))
                for path in group if path.is_file()))
    else:
        results = [_q_coordinate_read_job(job) for job in jobs]
    projected, objects = {}, {}
    for members, native in results:
        projected.update(members)
        objects.update(native)
    ordered_parents = dict.fromkeys(PurePosixPath(name).parent.as_posix() for name in refs
        if PurePosixPath(name).name in objects.get(PurePosixPath(name).parent.as_posix(), {}))
    objects = {parent: objects[parent] for parent in ordered_parents}
    projection = {name: projected[name] for name in refs if name in projected}
    for parent in objects:
        name = parent + "/object-audit.json"
        if completed_readback:
            projection[name] = projected[name]
    _require(bool(objects), "F4_COMPACT_Q_NATIVE_REFERENCE_REQUIRED")
    if native_units is None:
        _require(("execution.json" in refs) == (root / "execution.json").exists()
                 and not (root / "execution.json").is_symlink(), "F4_COMPACT_Q_MEMBER_SET_INVALID")
        evidence_root = root / "execution-evidence"
        actual_evidence = set()
        if evidence_root.exists() or evidence_root.is_symlink():
            _require(evidence_root.is_dir() and not evidence_root.is_symlink(), "F4_COMPACT_Q_MEMBER_INVALID")
            for member in evidence_root.rglob("*"):
                _require(not member.is_symlink() and (member.is_dir() or member.is_file()),
                         "F4_COMPACT_Q_MEMBER_INVALID")
                if member.is_file():
                    actual_evidence.add(member.relative_to(root).as_posix())
                    _require(len(actual_evidence) <= 20000, "F4_COMPACT_Q_MEMBER_SET_INVALID")
        _require(actual_evidence == set(operational), "F4_COMPACT_Q_MEMBER_SET_INVALID")
    if not completed_readback:
        for parent in objects:
            local = {PurePosixPath(name).name: record for name, record in grouped[parent].items()}
            path = _q_object_audit_read(root, parent, local, publish=publish,
                transported_refs=transported_refs, recover_existing_object_audits=recover_existing_object_audits)
            projection[path.relative_to(root).as_posix()] = path
    actual = set()
    for directory in roots:
        for path in directory.rglob("*"):
            _require(not path.is_symlink() and (path.is_dir() or path.is_file()), "F4_COMPACT_Q_MEMBER_INVALID")
            if path.is_file():
                actual.add(path.relative_to(root).as_posix())
                _require(len(actual) <= 40000, "F4_COMPACT_Q_MEMBER_SET_INVALID")
    numeric_names = {name for name in projection if name.startswith("native/")}
    original_names = {name for name in refs if name.startswith("native/")}
    _require(numeric_names <= actual <= original_names | numeric_names, "F4_COMPACT_Q_MEMBER_SET_INVALID")
    for parent, records in objects.items():
        expected = {f"{parent}/{name}" for name in records}
        _require(not actual & expected or actual & expected == expected, "F4_COMPACT_Q_MEMBER_SET_INVALID")
    if publish and native_units is None:
        from .nested_loco import _write_exact_once
        _write_exact_once(target, raw, "F4_COMPACT_Q_PUBLICATION_DRIFT")
    if native_units is None:
        projection["numbers.json"] = target
    return projection, refs


def _full_pipeline_q_object_numbers(root: Any, spec: Mapping[str, Any], members: set[str]) -> dict:
    """Read one first-audited coordinate, without opening its model objects."""
    from .bundle import sha256_file, strict_json_bytes, validate_sha256
    _require(_full_pipeline_q_numbers_mode(spec), "F4_COMPACT_Q_NUMERICAL_SCOPE_INVALID")
    path = root / "object-audit.json"
    _require(path.is_file() and not path.is_symlink() and path.resolve(strict=True) == path
             and path.stat().st_size <= 1024**2, "F4_COMPACT_Q_NATIVE_REFERENCE_REQUIRED")
    raw = path.read_bytes()
    refs = strict_json_bytes(raw)
    _require(isinstance(refs, dict) and set(refs) == members and raw == canonical_json_bytes(refs),
             "F4_COMPACT_Q_NATIVE_REFERENCE_MISMATCH")
    objects = {"model.bin", "baseline.bin", "function.ubj", "checkpoints.pt", "model.rds", "baseline.rds"}
    projected = members - objects
    _require({p.name for p in root.iterdir()} in (members | {"object-audit.json"},
                                                  projected | {"object-audit.json"}),
             "F4_COMPACT_Q_MEMBER_SET_INVALID")
    for name, record in refs.items():
        _require(isinstance(record, dict) and set(record) == {"sha256", "size_bytes"}
                 and type(record["size_bytes"]) is int and record["size_bytes"] > 0,
                 "F4_COMPACT_Q_NATIVE_REFERENCE_INVALID")
        validate_sha256(record["sha256"], "F4_COMPACT_Q_NATIVE_REFERENCE")
        if name not in objects:
            member = root / name
            _require(member.is_file() and not member.is_symlink()
                     and member.stat().st_size == record["size_bytes"]
                     and sha256_file(member) == record["sha256"], "F4_COMPACT_Q_VALUE_BYTES_MISMATCH")
    return refs

def _full_pipeline_q_stop_function_values(task: Mapping[str, Any], loaded: Mapping[str, Any], np: Any) -> dict:
    """Bind a retained response-free function to the original exact STOP arrays."""
    from .bundle import strict_json_bytes, validate_sha256
    from .f4 import _full_pipeline_python_stop_input, _full_pipeline_python_stop_root
    from .f2_kernel import _coxtime_labtrans, _validate_xgb_cox_objective_health
    root, _ = _full_pipeline_python_stop_root(task)
    family = task["spec"]["family"]
    name = "function.ubj" if family == "XGBOOST_COX" else "checkpoints.pt"
    refs = _full_pipeline_q_object_numbers(root, task["spec"],
        {"input.json", name, "function.json", "evaluation.json"})
    _require((root / "input.json").read_bytes() == canonical_json_bytes(_full_pipeline_python_stop_input(task, loaded)),
             "F4_FULL_PIPELINE_Q_STOP_INPUT_MISMATCH")
    saved = strict_json_bytes((root / "function.json").read_bytes())
    _require(isinstance(saved, dict) and set(saved) == {"sealed", "handoff"}
             and isinstance(saved["sealed"], dict) and isinstance(saved["handoff"], dict),
             "F4_COMPACT_Q_STOP_INVALID")
    sealed, handoff = saved["sealed"], saved["handoff"]
    payload = sealed.get("payload")
    keys = {"schema_version", "kind", "fit_ids", "evaluation_ids", "maximum", "fit_input_identity", "seed"}
    keys |= ({"booster_sha256", "cox_objective", "design_identity", "parameter_sha256"}
             if family == "XGBOOST_COX" else {"checkpoint_sha256s", "candidate_sha256", "scaler_sha256",
                 "labtrans_sha256", "evaluation_design_sha256"})
    _require(set(sealed) == {"status", "payload", "sha256"} and sealed["status"] == "SEALED"
             and isinstance(payload, dict) and set(payload) == keys
             and sealed["sha256"] == sha256_bytes(canonical_json_bytes(payload))
             and payload["schema_version"] == "1.0.0"
             and payload["kind"] == ("PADML_F2_XGBOOST_PREDICTION_FUNCTION" if family == "XGBOOST_COX"
                                     else "PADML_F2_COXTIME_PREDICTION_FUNCTION")
             and payload["fit_ids"] == loaded["fit_ids"] and payload["evaluation_ids"] == loaded["evaluation_ids"]
             and type(payload["seed"]) is int and payload["seed"] == task["seed"]
             and type(payload["maximum"]) is int
             and set(handoff) == {"kind", "sha256", "size_bytes"}
             and handoff["kind"] == ("PADML_F2_XGBOOST_QUARANTINE_HANDOFF" if family == "XGBOOST_COX"
                                     else "PADML_F2_COXTIME_QUARANTINE_HANDOFF")
             and type(handoff["size_bytes"]) is int
             and {key: handoff[key] for key in ("sha256", "size_bytes")} == refs[name],
             "F4_COMPACT_Q_STOP_SOURCE_MISMATCH")
    fit, evaluation = loaded["fit_designs"][0], loaded["evaluation_designs"][0]
    if family == "XGBOOST_COX":
        fit_bytes = np.ascontiguousarray(fit, dtype="float64").tobytes()
        evaluation_bytes = np.ascontiguousarray(evaluation, dtype="float64").tobytes()
        design = {"fit_shape": list(fit.shape), "fit_sha256": sha256_bytes(fit_bytes),
            "evaluation_shape": list(evaluation.shape), "evaluation_sha256": sha256_bytes(evaluation_bytes)}
        fit_input = {"fit_ids_sha256": sha256_bytes(canonical_json_bytes(loaded["fit_ids"])),
            "fit_design_shape": list(fit.shape), "fit_design_sha256": sha256_bytes(fit_bytes),
            "fit_time_sha256": sha256_bytes(canonical_json_bytes([float(value) for value in loaded["fit_time"]])),
            "fit_event_sha256": sha256_bytes(canonical_json_bytes([int(value) for value in loaded["fit_event"]]))}
        _require(payload["maximum"] == task["parameters"]["max_nrounds"]
                 and payload["parameter_sha256"] == sha256_bytes(canonical_json_bytes(task["parameters"]))
                 and payload["booster_sha256"] == handoff["sha256"]
                 and payload["design_identity"] == sha256_bytes(canonical_json_bytes(design))
                 and payload["fit_input_identity"] == sha256_bytes(canonical_json_bytes(fit_input)),
                 "F4_COMPACT_Q_STOP_ARRAY_BINDING_MISMATCH")
        _validate_xgb_cox_objective_health(payload["cox_objective"], payload["maximum"], len(fit))
    else:
        from pycox import models
        fit, evaluation = np.asarray(fit, dtype="float32"), np.asarray(evaluation, dtype="float32")
        fit_input = {"fit_ids_sha256": sha256_bytes(canonical_json_bytes(loaded["fit_ids"])),
            "fit_design_shape": list(fit.shape),
            "fit_design_sha256": sha256_bytes(np.ascontiguousarray(fit).tobytes()),
            "fit_time_sha256": sha256_bytes(canonical_json_bytes([float(value) for value in loaded["fit_time"]])),
            "fit_event_sha256": sha256_bytes(canonical_json_bytes([int(value) for value in loaded["fit_event"]])),
            "evaluation_design_shape": list(evaluation.shape),
            "evaluation_design_sha256": sha256_bytes(np.ascontiguousarray(evaluation).tobytes())}
        mean = fit.mean(axis=0, dtype="float64").astype("float32")
        scale = fit.std(axis=0, dtype="float64").astype("float32")
        scale[~np.isfinite(scale) | (scale <= 0)] = 1.0
        evaluation = (evaluation - mean) / scale
        labtrans = _coxtime_labtrans(models, task["candidate"], loaded["fit_time"], loaded["fit_event"], np)
        scaler = {"mean": [float(value) for value in mean], "scale": [float(value) for value in scale]}
        labtrans_record = {"log_duration": bool(labtrans.log_duration),
            "mean": [float(value) for value in labtrans.duration_scaler.mean_],
            "scale": [float(value) for value in labtrans.duration_scaler.scale_]}
        _require(payload["maximum"] == 300 and isinstance(payload["checkpoint_sha256s"], list)
                 and len(payload["checkpoint_sha256s"]) == 300
                 and payload["candidate_sha256"] == sha256_bytes(canonical_json_bytes(task["candidate"]))
                 and payload["scaler_sha256"] == sha256_bytes(canonical_json_bytes(scaler))
                 and payload["labtrans_sha256"] == sha256_bytes(canonical_json_bytes(labtrans_record))
                 and payload["fit_input_identity"] == sha256_bytes(canonical_json_bytes(fit_input))
                 and bool(np.isfinite(evaluation).all())
                 and payload["evaluation_design_sha256"] == sha256_bytes(np.ascontiguousarray(evaluation).tobytes()),
                 "F4_COMPACT_Q_STOP_ARRAY_BINDING_MISMATCH")
        for digest in payload["checkpoint_sha256s"]:
            validate_sha256(digest, "F4_COMPACT_Q_CHECKPOINT")
    return saved


def _full_pipeline_python_stop_evaluate_numbers(task: Mapping[str, Any], loaded: Mapping[str, Any], np: Any) -> dict:
    """Supply original STOP losses to the existing locks, without loading objects."""
    from .bundle import strict_json_bytes
    from .f4 import _full_pipeline_python_stop_root
    from .f2_kernel import _response_arrays
    saved = _full_pipeline_q_stop_function_values(task, loaded, np)
    produced = task["function_result"]
    _require(produced["sealed"] == saved["sealed"]
             and produced["handoff"] == {**saved["handoff"], "path": task["handoff_path"]},
             "F4_COMPACT_Q_STOP_SOURCE_MISMATCH")
    root, _ = _full_pipeline_python_stop_root(task)
    evaluation = strict_json_bytes((root / "evaluation.json").read_bytes())
    partition = task["evaluation_partition"]
    _response_arrays(partition["fit_response"], loaded["fit_ids"])
    _response_arrays(partition["evaluation_response"], loaded["evaluation_ids"])
    if task["spec"]["family"] == "XGBOOST_COX":
        return _full_pipeline_q_stop_numbers({"function": saved, "evaluation": evaluation},
            parameters=task["parameters"], seed=task["seed"], partition=partition,
            selection_horizon_months=task["spec"].get("selection_horizon_months", 24))
    contract = task["spec"]["coxtime"]["shared_candidate_parameters"]
    expected_contract = {"validation_repeat": 5, "n_control": 5, "validation_control_seed_offset": 70000,
                         "validation_control_seed_rule": "TASK_SEED_PLUS_OFFSET_PLUS_ONE_BASED_REPEAT"}
    _require(all(contract.get(key) == item for key, item in expected_contract.items())
             and isinstance(evaluation, dict) and set(evaluation) == {"function_sha256", "result", "evaluated_path"}
             and evaluation["function_sha256"] == saved["sealed"]["sha256"] and evaluation["evaluated_path"] == {},
             "F4_COMPACT_Q_STOP_EVALUATION_INVALID")
    curve = evaluation["result"]
    losses = curve.get("losses") if isinstance(curve, dict) else None
    _require(isinstance(losses, list) and len(losses) == 300
             and all(_finite_number(value) and value >= 0 for value in losses),
             "F4_COMPACT_Q_STOP_LOSS_PATH_INVALID")
    expected = {"schema_version": "1.0.0", "kind": "PADML_F2_COXTIME_VALIDATION_CURVE",
        "function_sha256": saved["sealed"]["sha256"],
        "evaluation_response_sha256": partition["evaluation_response"]["sha256"],
        **expected_contract, "losses": losses}
    _require(canonical_json_bytes(curve) == canonical_json_bytes(expected),
             "F4_COMPACT_Q_STOP_EVALUATION_INVALID")
    return curve

def _full_pipeline_q_gbm_stop_numbers(
    root: Any, references: Mapping[str, Any], *, task: Mapping[str, Any],
    sealed: Mapping[str, Any], partition: Mapping[str, Any], evaluation_context: Mapping[str, Any],
) -> dict[str, Any]:
    """Read independently pinned complete losses after the original risk checks."""
    import stat
    from .bundle import sha256_file, strict_json_bytes, validate_sha256
    from .f2_kernel import _tree_stopping_lock_from_losses
    _require(isinstance(references, Mapping) and set(references) == {"evaluation.json", "output.json"},
             "F4_COMPACT_Q_GBM_LOSS_REFERENCE_INVALID")
    raw = None
    for name, ref in references.items():
        _require(isinstance(ref, Mapping) and set(ref) == {"sha256", "size_bytes"}
                 and type(ref["size_bytes"]) is int and 0 < ref["size_bytes"] <= 16 * 1024**2,
                 "F4_COMPACT_Q_GBM_LOSS_REFERENCE_INVALID")
        validate_sha256(ref["sha256"], "F4_COMPACT_Q_GBM_LOSS_REFERENCE")
        path = root / name
        _require(path.is_file() and not path.is_symlink() and path.resolve(strict=True) == path
                 and stat.S_ISREG(path.stat().st_mode) and path.stat().st_nlink == 1
                 and path.stat().st_size == ref["size_bytes"],
                 "F4_COMPACT_Q_GBM_LOSS_BYTES_MISMATCH")
        if name == "evaluation.json":
            with path.open("rb") as handle:
                raw = handle.read(ref["size_bytes"] + 1)
            _require(len(raw) == ref["size_bytes"] and sha256_bytes(raw) == ref["sha256"],
                     "F4_COMPACT_Q_GBM_LOSS_BYTES_MISMATCH")
        else:
            _require(sha256_file(path) == ref["sha256"], "F4_COMPACT_Q_GBM_LOSS_BYTES_MISMATCH")
    value = strict_json_bytes(raw)
    _require(isinstance(value, Mapping) and set(value) == {
        "task_sha256", "native_output", "result", "evaluated_path"}
        and raw == canonical_json_bytes(value)
        and value["task_sha256"] == sha256_bytes(canonical_json_bytes(task))
        and canonical_json_bytes(value["native_output"]) == canonical_json_bytes(references["output.json"]),
        "F4_COMPACT_Q_GBM_LOSS_SOURCE_MISMATCH")
    from .f2_kernel import _validate_cox_risk_seal
    payload = _validate_cox_risk_seal(sealed)
    parameters = task["parameters"]
    _require(payload["fit_ids"] == partition["fit_ids"] and payload["evaluation_ids"] == partition["evaluation_ids"]
        and type(payload["maximum"]) is int and payload["maximum"] == parameters["max_trees"],
        "F4_COMPACT_Q_GBM_LOSS_CURVE_MISMATCH")
    context = evaluation_context
    _require(isinstance(context, Mapping)
             and context.get("fit_response_sha256") == partition["fit_response"]["sha256"]
             and context.get("evaluation_response_sha256") == partition["evaluation_response"]["sha256"]
             and context.get("fit_ids_sha256") == sha256_bytes(canonical_json_bytes(payload["fit_ids"]))
             and context.get("evaluation_ids_sha256") == sha256_bytes(canonical_json_bytes(payload["evaluation_ids"])),
             "F2_COX_EVALUATION_CONTEXT_IDENTITY_INVALID")
    _require(sum(context["fit_events"]) > 0 and sum(context["evaluation_events"]) > 0,
             "F2_COX_RISK_CURVE_EVALUATION_INVALID")
    evaluated = value["evaluated_path"]
    losses = evaluated.get("losses") if isinstance(evaluated, Mapping) else None
    _require(isinstance(losses, list) and len(losses) == payload["maximum"],
             "F4_COMPACT_Q_GBM_LOSS_PATH_INVALID")
    expected = {"schema_version": "1.0.0", "kind": "PADML_F2_GROUPED_COX_LOSS_PATH",
        "risk_curve_sha256": sealed["sha256"], "fit_response_sha256": partition["fit_response"]["sha256"],
        "evaluation_response_sha256": partition["evaluation_response"]["sha256"],
        "validation_n": len(context["evaluation_times"]), "losses": losses}
    _require(canonical_json_bytes(evaluated) == canonical_json_bytes(expected),
             "F4_COMPACT_Q_GBM_LOSS_PATH_INVALID")
    lock = _tree_stopping_lock_from_losses(losses, risk_curve_sha256=sealed["sha256"],
        fit_response_sha256=partition["fit_response"]["sha256"],
        evaluation_response_sha256=partition["evaluation_response"]["sha256"],
        minimum_improvement=float(parameters["minimum_improvement"]),
        patience=int(parameters["early_stopping_patience"]), family="GBM_COX")
    _require(canonical_json_bytes(value["result"]) == canonical_json_bytes(lock),
             "F4_COMPACT_Q_GBM_STOP_LOCK_MISMATCH")
    return lock


def _full_pipeline_q_stop_numbers(
    value: Mapping[str, Any], *, parameters: Mapping[str, Any], seed: int,
    partition: Mapping[str, Any], selection_horizon_months: int = 24,
) -> dict[str, Any]:
    """Recompute the original lock from the actual patience-truncated prefix."""
    from .bundle import validate_sha256
    from .f2_kernel import _tree_stopping_lock_from_losses, _validate_xgb_cox_objective_health, _development_evaluation_indices
    function, evaluation = value["function"], value["evaluation"]
    _require(isinstance(function, Mapping) and set(function) == {"sealed", "handoff"}
             and isinstance(function["sealed"], Mapping) and isinstance(function["handoff"], Mapping),
             "F4_COMPACT_Q_STOP_INVALID")
    sealed, handoff = function["sealed"], function["handoff"]
    payload = sealed.get("payload")
    _require(set(sealed) == {"status", "payload", "sha256"} and sealed["status"] == "SEALED"
             and isinstance(payload, Mapping) and set(payload) == {"schema_version", "kind", "fit_ids",
                "evaluation_ids", "maximum", "booster_sha256", "cox_objective", "design_identity",
                "parameter_sha256", "fit_input_identity", "seed"}
             and payload["schema_version"] == "1.0.0" and payload["kind"] == "PADML_F2_XGBOOST_PREDICTION_FUNCTION"
             and payload["fit_ids"] == partition["fit_ids"] and payload["evaluation_ids"] == partition["evaluation_ids"]
             and type(payload["maximum"]) is int and payload["maximum"] == parameters["max_nrounds"]
             and type(payload["seed"]) is int and payload["seed"] == seed
             and payload["parameter_sha256"] == sha256_bytes(canonical_json_bytes(parameters))
             and sealed["sha256"] == sha256_bytes(canonical_json_bytes(payload))
             and set(handoff) == {"kind", "sha256", "size_bytes"}
             and handoff["kind"] == "PADML_F2_XGBOOST_QUARANTINE_HANDOFF"
             and handoff["sha256"] == payload["booster_sha256"]
             and type(handoff["size_bytes"]) is int and handoff["size_bytes"] > 0,
             "F4_COMPACT_Q_STOP_SOURCE_MISMATCH")
    for key in ("booster_sha256", "design_identity", "fit_input_identity"):
        validate_sha256(payload[key], "F4_COMPACT_Q_STOP_" + key)
    _validate_xgb_cox_objective_health(payload["cox_objective"], payload["maximum"], len(partition["fit_ids"]))
    _require(isinstance(evaluation, Mapping) and set(evaluation) == {"function_sha256", "result", "evaluated_path"}
             and evaluation["function_sha256"] == sealed["sha256"] and isinstance(evaluation["evaluated_path"], Mapping),
             "F4_COMPACT_Q_STOP_EVALUATION_INVALID")
    path = evaluation["evaluated_path"]
    losses = path.get("losses")
    _require(isinstance(losses, list) and 1 <= len(losses) <= payload["maximum"],
             "F4_COMPACT_Q_STOP_LOSS_PATH_INVALID")
    expected = {"schema_version": "1.0.0", "kind": "PADML_F2_GROUPED_COX_LOSS_PATH",
        "risk_curve_sha256": sealed["sha256"], "fit_response_sha256": partition["fit_response"]["sha256"],
        "evaluation_response_sha256": partition["evaluation_response"]["sha256"],
        "validation_n": len(_development_evaluation_indices(partition, selection_horizon_months) or partition["evaluation_ids"]), "losses": losses}
    _require(canonical_json_bytes(path) == canonical_json_bytes(expected), "F4_COMPACT_Q_STOP_LOSS_PATH_INVALID")
    lock = _tree_stopping_lock_from_losses(losses, risk_curve_sha256=sealed["sha256"],
        fit_response_sha256=partition["fit_response"]["sha256"],
        evaluation_response_sha256=partition["evaluation_response"]["sha256"],
        minimum_improvement=0.0, patience=parameters["early_stopping_rounds"], family="XGBOOST_COX")
    _require(canonical_json_bytes(evaluation["result"]) == canonical_json_bytes(lock)
             and lock["evaluated_tree_count"] == len(losses)
             and (len(losses) == payload["maximum"]
                  or len(losses) - lock["selected_rounds"] == parameters["early_stopping_rounds"]),
             "F4_COMPACT_Q_STOP_LOCK_MISMATCH")
    return lock


def read_full_pipeline_q_compact(
    value: Mapping[str, Any], *, inputs: Mapping[str, Any], result: Mapping[str, Any],
    contexts: Mapping[int, Mapping[str, Any]], seta: Mapping[str, Any],
) -> dict[str, Any]:
    """Read actual Q promotion/STOP numbers; never refit or invent MI predictions."""
    import csv
    import io
    from decimal import Decimal
    from .bundle import validate_sha256
    from .f4 import _full_pipeline_complex_search_spec, _response_rows, _write_response_subset, HORIZONS
    from .f2_kernel import (_engine_parameters, _full_pipeline_search_seed_registry, _integer_median,
        _tree_s3a_candidates, _rank_trials, _shared_full_development_search_result,
        _validate_python_fit_health, _center_stratified_evaluation_context)
    _require(isinstance(value, Mapping) and set(value) == {"kind", "input_sha256", "result_sha256", "mice_views",
        "tasks", "identity_sha256"} and value["kind"] == "PADML_F4_Q_NUMBERS_V1"
        and value["input_sha256"] == sha256_bytes(canonical_json_bytes(inputs))
        and value["result_sha256"] == sha256_bytes(canonical_json_bytes(result))
        and value["identity_sha256"] == sha256_bytes(canonical_json_bytes({k: v for k, v in value.items()
                                                                          if k != "identity_sha256"}))
        and set(contexts) == set(range(7)) and all(type(k) is int for k in contexts)
        and isinstance(value["tasks"], list) and len(value["tasks"]) == 1300,
        "F4_COMPACT_Q_INVALID")
    full = contexts[0]
    registered = _full_pipeline_q_registered_numbers(inputs["registered_inputs"], full, value["mice_views"])
    spec = _full_pipeline_complex_search_spec(full, seta, registered)
    source = {k: v for k, v in full["source"].items() if k != "context"}
    expected_input = {"source": source, "mice_contexts": [
        {"context": fold, "identity_sha256": contexts[fold]["archive_identity_sha256"]} for fold in range(7)],
        "seta": seta, "registered_inputs": registered, "spec": spec}
    _require(canonical_json_bytes(inputs) == canonical_json_bytes(expected_input), "F4_COMPACT_Q_INPUT_SOURCE_MISMATCH")
    registry = _full_pipeline_search_seed_registry(spec, True, source["bootstrap_replicate"])
    seeds = {(r["stage"], r["candidate_id"]): r for r in registry["trials"]}
    inner = [r for r in registered["partitions"] if r["kind"] == "INNER"]
    stops = {(r["repeat"], r["inner_fold"]): r for r in registered["partitions"] if r["kind"] == "STOP"}
    raw_centers = {}
    for row in csv.DictReader(io.StringIO(full["covariates_csv"].decode("utf-8-sig"))):
        center = Decimal(row["Center"])
        _require(center.is_finite() and center == center.to_integral_value()
                 and int(center) in {36, 38, 39, 48, 52, 54, 55}
                 and row["Patient_ID"] not in raw_centers, "F4_COMPACT_Q_CENTER_INVALID")
        raw_centers[row["Patient_ID"]] = str(int(center))
    fields, responses = _response_rows(full["response_csv"])
    qcs = {}
    for repeat in range(1, 4):
        ids = [pid for part in inner if part["repeat"] == repeat for pid in part["evaluation_ids"]]
        response = _write_response_subset(fields, responses, ids, None)
        qcs[repeat] = _center_stratified_evaluation_context(response, ids, [raw_centers[p] for p in ids])["ipcw_qc"]
    _require(isinstance(result, Mapping) and isinstance(result.get("search_trace"), Mapping)
             and list(result["search_trace"]) == ["S1", "S2", "S3A", "S3B1", "S3B2"], "F4_COMPACT_Q_TRACE_INVALID")
    trace, consumed = {}, 0
    for stage, mi, repeat in (("S1", 1, 1), ("S2", 5, 2), ("S3A", 20, 3), ("S3B1", 5, None), ("S3B2", 20, None)):
        candidates = (spec["candidate_trials"][stage] if stage in {"S1", "S2"} else
            _tree_s3a_candidates(trace) if stage == "S3A" else
            _rank_trials(trace["S3A"], retain=2)[:2] if stage == "S3B1" else
            _rank_trials(trace["S3B1"], retain=1)[:1])
        parts = [r for r in inner if repeat is None or r["repeat"] == repeat]
        observed = result["search_trace"][stage]
        _require(isinstance(observed, list) and len(observed) == len(candidates), "F4_COMPACT_Q_PROMOTION_INVALID")
        trace[stage] = []
        for trial_index, (candidate, row) in enumerate(zip(candidates, observed, strict=True), 1):
            candidate_id = candidate.get("trial_id", candidate.get("candidate_id"))
            seed = seeds[stage, candidate_id]
            parameters = _engine_parameters("XGBOOST_COX", candidate["parameters"])
            rounds = []
            for part_index, partition in enumerate(parts, 1):
                stop = stops[partition["repeat"], partition["inner_fold"]]
                for imp in range(1, mi + 1):
                    task = value["tasks"][consumed]
                    consumed += 1
                    _require(isinstance(task, Mapping) and set(task) == {"stop_input", "function", "evaluation",
                        "refit_input", "fit_health"}, "F4_COMPACT_Q_TASK_INVALID")
                    name = f"{stage}_T{trial_index:03d}_P{part_index:02d}_M{imp:02d}"
                    for stopped, label, current in ((True, "stop_input", stop), (False, "refit_input", partition)):
                        item = task[label]
                        _require(isinstance(item, Mapping) and set(item) == {"task_id", "training_binding",
                            "prediction_input_sha256", *([] if stopped else ["horizons"])}
                            and item["task_id"] == name + ("_FUNCTION" if stopped else "_LOCKED_REFIT")
                            and (stopped or item["horizons"] == HORIZONS[1:])
                            and isinstance(item["training_binding"], Mapping), "F4_COMPACT_Q_TASK_INPUT_INVALID")
                        binding = item["training_binding"]
                        expected_binding = {"model_seed": registry["stop_seeds"][imp - 1] if stopped else seed["seed"],
                            "imputation": imp, "coordinates": {"source": full["source"],
                                "partition_id": current["partition_id"], "stage": stage,
                                "candidate_id": candidate_id, "candidate_order": seed["order"]},
                            "consumed_input_sha256": binding.get("consumed_input_sha256")}
                        _require(canonical_json_bytes(binding) == canonical_json_bytes(expected_binding),
                                 "F4_COMPACT_Q_TASK_COORDINATE_MISMATCH")
                        validate_sha256(binding["consumed_input_sha256"], "F4_COMPACT_Q_TRAINING_INPUT")
                        validate_sha256(item["prediction_input_sha256"], "F4_COMPACT_Q_PREDICTION_INPUT")
                    lock = _full_pipeline_q_stop_numbers(task, parameters=parameters,
                        seed=registry["stop_seeds"][imp - 1], partition=stop)
                    rounds.append(lock["selected_rounds"])
                    _validate_python_fit_health("XGBOOST_COX", task["fit_health"], locked_value=lock["selected_rounds"],
                        training_count=len(partition["fit_ids"]), evaluation_count=len(partition["evaluation_ids"]))
            _require(isinstance(row, Mapping) and set(row) == {"stage_id", "trial_index", "candidate_id", "parameters",
                "parameter_sha256", "metric_values", "fold_metric_values", "ranking_metric_values", "ranking_metric_qc",
                "ranking_evaluation_count", "mean_ibs", "maximum_ibs", "evaluation_units", "selected_rounds_median"},
                "F4_COMPACT_Q_TRIAL_INVALID")
            for key, count in (("metric_values", len(parts) * mi), ("fold_metric_values", len(parts)),
                               ("ranking_metric_values", 3 if repeat is None else 1)):
                _require(isinstance(row[key], list) and len(row[key]) == count
                         and all(_finite_number(number) and number >= 0 for number in row[key]),
                         "F4_COMPACT_Q_METRIC_DENOMINATOR_INVALID")
            scores = row["ranking_metric_values"]
            expected = {"stage_id": stage, "trial_index": trial_index, "candidate_id": candidate_id,
                "parameters": candidate["parameters"], "parameter_sha256": candidate["parameter_sha256"],
                "metric_values": row["metric_values"], "fold_metric_values": row["fold_metric_values"],
                "ranking_metric_values": scores, "ranking_metric_qc": [qcs[r] for r in (range(1, 4) if repeat is None else [repeat])],
                "ranking_evaluation_count": len(scores), "mean_ibs": math.fsum(scores) / len(scores),
                "maximum_ibs": max(scores), "evaluation_units": len(parts) * mi,
                "selected_rounds_median": _integer_median(rounds)}
            _require(canonical_json_bytes(row) == canonical_json_bytes(expected), "F4_COMPACT_Q_TRIAL_NUMBERS_MISMATCH")
            trace[stage].append(expected)
    _require(consumed == len(value["tasks"]) == 1300, "F4_COMPACT_Q_TASK_COVERAGE_INVALID")
    winner = trace["S3B2"][0]
    rebuilt = _shared_full_development_search_result(spec, registered, trace, {"family": "XGBOOST_COX",
        "candidate_id": winner["candidate_id"], "parameters": winner["parameters"],
        "selected_rounds": winner["selected_rounds_median"], "selection_metric": "IBS_0_24",
        "selection_stage": "S3B2"}, registry)
    _require(canonical_json_bytes(result) == canonical_json_bytes(rebuilt), "F4_COMPACT_Q_RESULT_MISMATCH")
    return rebuilt


def write_full_pipeline_q_compact(
    root: Any, contexts: Mapping[int, Mapping[str, Any]], seta: Mapping[str, Any],
) -> dict[str, Any]:
    """Export original small records only after the existing complete native Q audit."""
    from .bundle import strict_json_bytes
    target = root / "compact.json"
    _require(root.is_absolute() and root.is_dir() and not root.is_symlink()
             and not target.exists() and not target.is_symlink(), "F4_COMPACT_Q_TARGET_INVALID")
    tasks = []
    paths = sorted((root / "native").glob("*_FUNCTION"))
    _require(len(paths) == 1300 and {p.name for p in (root / "native").iterdir()}
             == {name for path in paths for name in (path.name, path.name.removesuffix("_FUNCTION") + "_LOCKED_REFIT")},
             "F4_COMPACT_Q_NATIVE_COVERAGE_INVALID")
    for path in paths:
        refit = path.with_name(path.name.removesuffix("_FUNCTION") + "_LOCKED_REFIT")
        tasks.append({"stop_input": strict_json_bytes((path / "input.json").read_bytes()),
            "function": strict_json_bytes((path / "function.json").read_bytes()),
            "evaluation": strict_json_bytes((path / "evaluation.json").read_bytes()),
            "refit_input": strict_json_bytes((refit / "input.json").read_bytes()),
            "fit_health": strict_json_bytes((refit / "fit-health.json").read_bytes())})
    inputs, result = (strict_json_bytes((root / name).read_bytes()) for name in ("input.json", "result.json"))
    full = contexts[0]
    views = {name: strict_json_bytes((full["native_root"] / name / "view.json").read_bytes())
             for name in full["mice_specs"] if name.startswith(("INNER_", "STOP_"))}
    body = {"kind": "PADML_F4_Q_NUMBERS_V1", "input_sha256": sha256_bytes(canonical_json_bytes(inputs)),
            "result_sha256": sha256_bytes(canonical_json_bytes(result)), "mice_views": views, "tasks": tasks}
    value = {**body, "identity_sha256": sha256_bytes(canonical_json_bytes(body))}
    read_full_pipeline_q_compact(value, inputs=inputs, result=result, contexts=contexts, seta=seta)
    with target.open("xb") as handle:
        handle.write(canonical_json_bytes(value))
    return value


def _full_pipeline_final_numbers(
    value: Mapping[str, Any], means: Mapping[str, bytes], *, context: Mapping[str, Any],
    seta: Mapping[str, Any], selection: Mapping[str, Any],
) -> dict[str, Any]:
    """Actual final tasks/health and audited M20 means, not individual predictions."""
    import csv
    import io
    import struct
    from decimal import Decimal
    from pathlib import Path
    from .bundle import validate_sha256
    from .f4 import _full_pipeline_seta_numeric_inputs, _f4_model_seed, _response_rows, _write_response_subset, HORIZONS
    from .f2_kernel import predictor_contract, _expected_family_parent_column_map, _validate_python_fit_health, _seal_prediction_matrix
    from .f5 import _validate_final_design_recipe, _validate_final_refit_locked_spec
    numeric = _full_pipeline_seta_numeric_inputs(context, seta)
    selected, source = numeric["selected_parents"], context["source"]
    _require(source["family"] == "XGBOOST_COX" and source["context"] == 0
             and isinstance(value, Mapping) and set(value) == {"kind", "input", "models", "means", "identity_sha256"}
             and value["kind"] == "PADML_F4_FINAL_M20_NUMBERS_V1"
             and value["identity_sha256"] == sha256_bytes(canonical_json_bytes({k: v for k, v in value.items()
                                                                               if k != "identity_sha256"}))
             and isinstance(value["input"], Mapping) and isinstance(value["models"], list) and len(value["models"]) == 20
             and isinstance(selection, Mapping) and selection["execution_scope"] == "F4_FULL_PIPELINE_SEARCH"
             and selection["family"] == "XGBOOST_COX" and selection["selected_parents"] == selected
             and selection["seed_registry"]["replicate"] == source["bootstrap_replicate"]
             and selection["selected_spec_sha256"] == sha256_bytes(canonical_json_bytes(selection["selected_spec"])),
             "F4_COMPACT_FINAL_SOURCE_INVALID")
    _validate_final_refit_locked_spec("XGBOOST_COX", selection["selected_spec"])
    specs = context["mice_specs"]
    fit_ids = [row["clone_id"] for row in context["clone_mapping"]]
    original_ids = context["original_evaluation_ids"]
    _require(specs["FULL_ANALYSIS"]["view"]["analysis_ids"] == fit_ids
             and len(fit_ids) == len(set(fit_ids)) > 0
             and original_ids == sorted(set(original_ids), key=lambda x: x.encode())
             and not set(fit_ids).intersection(original_ids)
             and specs["ORIGINAL_APPLICATION"]["view"]["analysis_ids"] == fit_ids
             and specs["ORIGINAL_APPLICATION"]["view"]["row_ids"] == fit_ids + original_ids,
             "F4_COMPACT_FINAL_POPULATION_INVALID")
    predictors = predictor_contract(Path(__file__).parent)
    recipe = _validate_final_design_recipe({"schema_version": "1.0.0", "kind": "PADML_F5_FINAL_DESIGN_RECIPE_V1",
        "family": "XGBOOST_COX", "selected_parents": selected,
        "predictor_rows": [r for r in predictors["variables"] if r["name"] in selected],
        "predictor_contract_sha256": sha256_bytes(canonical_json_bytes(predictors)),
        "preprocessing_mode": "F2_RAW_CANONICAL_AUTHORITY_LEVELS", "transform_recipe": None,
        "coxtime_standardization": None}, family="XGBOOST_COX", selected_parents=selected)
    design = _expected_family_parent_column_map(selected, "XGBOOST_COX", predictors, None)
    columns = sorted([column for row in design for column in row["columns"]], key=lambda x: x.encode("utf-8"))
    fields, responses = _response_rows(context["response_csv"])
    response = _write_response_subset(fields, responses, fit_ids, None)
    task_inputs = value["input"].get("task_inputs")
    _require(isinstance(task_inputs, list) and len(task_inputs) == 20, "F4_COMPACT_FINAL_M20_REQUIRED")
    for imp, (model, item) in enumerate(zip(value["models"], task_inputs, strict=True), 1):
        _require(isinstance(model, Mapping) and set(model) == {"task", "fit_health", "object_audit"}
                 and isinstance(item, Mapping) and set(item) == {"name", "members"}, "F4_COMPACT_FINAL_MODEL_INVALID")
        coordinates = {"purpose": "FULL_PIPELINE", "bootstrap_replicate": source["bootstrap_replicate"],
                       "outer_fold": 0, "repeat": 0, "inner_fold": 0, "imputation": imp}
        seed = _f4_model_seed("XGBOOST_COX", coordinates)
        task = {"family": "XGBOOST_COX", "selected_parents": selected, "imputation": imp,
                "f4_coordinates": coordinates, "registered_model_seed": seed, "model_seed": seed,
                "full_pipeline_source": source, "seta_lock_sha256": seta["lock_sha256"],
                "row_count": len(fit_ids), "family_design_column_count": len(columns),
                "parameters": selection["selected_spec"]}
        _require(canonical_json_bytes(model["task"]) == canonical_json_bytes(task)
                 and item["name"] == f"B{source['bootstrap_replicate']:03d}_M{imp:02d}"
                 and isinstance(item["members"], Mapping) and set(item["members"]) == {
                     "task.json", "recipe.json", "fit-covariates.csv", "fit-response.csv", "prediction-covariates.csv"},
                 "F4_COMPACT_FINAL_TASK_SOURCE_MISMATCH")
        for name, member in item["members"].items():
            _require(isinstance(member, Mapping) and set(member) == {"sha256", "size_bytes"}
                     and type(member["size_bytes"]) is int and member["size_bytes"] > 0,
                     "F4_COMPACT_FINAL_MEMBER_INVALID")
            validate_sha256(member["sha256"], "F4_COMPACT_FINAL_MEMBER")
        for name, raw in (("task.json", canonical_json_bytes(task)), ("recipe.json", canonical_json_bytes(recipe)),
                          ("fit-response.csv", response["private_bytes"])):
            _require(item["members"][name] == {"sha256": sha256_bytes(raw), "size_bytes": len(raw)},
                     "F4_COMPACT_FINAL_INPUT_MISMATCH")
        rounds = selection["selected_spec"]["selected_rounds"]
        _validate_python_fit_health("XGBOOST_COX", model["fit_health"], locked_value=rounds,
                                    training_count=len(fit_ids), evaluation_count=len(fit_ids))
        _require(canonical_json_bytes(model["object_audit"]) == canonical_json_bytes(
            {"booster_round_count": rounds, "design_columns": columns}), "F4_COMPACT_FINAL_AUDIT_NUMBERS_MISMATCH")
    expected_input = {"source": source, "mice_context_identity_sha256": context["archive_identity_sha256"],
        "seta": seta, "selection": selection, "recipe": recipe, "bootstrap_ids": fit_ids,
        "original_ids": original_ids, "task_inputs": task_inputs}
    _require(canonical_json_bytes(value["input"]) == canonical_json_bytes(expected_input)
             and isinstance(value["means"], Mapping) and set(value["means"]) == set(means) == {"bootstrap", "original"},
             "F4_COMPACT_FINAL_INPUT_MISMATCH")
    centers = {}
    for row in csv.DictReader(io.StringIO(context["covariates_csv"].decode("utf-8-sig"))):
        center = Decimal(row["Center"])
        _require(center.is_finite() and center == center.to_integral_value()
                 and int(center) in {36, 38, 39, 48, 52, 54, 55} and row["Patient_ID"] not in centers,
                 "F4_COMPACT_FINAL_CENTER_INVALID")
        centers[row["Patient_ID"]] = int(center)
    predictions = {}
    for population, ids in (("bootstrap", fit_ids), ("original", original_ids)):
        raw = means[population]
        _require(type(raw) is bytes and len(raw) == len(ids) * len(HORIZONS) * 8, "F4_COMPACT_FINAL_MEAN_SHAPE_INVALID")
        metadata = {"encoding": "IEEE754_FLOAT64_LE_ROW_MAJOR", "patient_ids": ids,
                    "centers": [centers[p] for p in ids], "horizons": HORIZONS,
                    "imputation_count": 20, "sha256": sha256_bytes(raw), "size_bytes": len(raw)}
        _require(canonical_json_bytes(value["means"][population]) == canonical_json_bytes(metadata),
                 "F4_COMPACT_FINAL_MEAN_SOURCE_MISMATCH")
        matrix = [list(row) for row in struct.iter_unpack("<" + "d" * len(HORIZONS), raw)]
        _seal_prediction_matrix(ids, matrix, HORIZONS)
        _require(all(row[0] == 1.0 for row in matrix), "F4_COMPACT_FINAL_MEAN_T0_INVALID")
        predictions[population] = {"patient_ids": ids, "centers": metadata["centers"], "horizons": HORIZONS,
                                   "survival": {"XGBOOST_COX": matrix}}
    return predictions


def read_full_pipeline_final_compact(
    source: Any, *, context: Mapping[str, Any], seta: Mapping[str, Any], selection: Mapping[str, Any],
) -> dict[str, Any]:
    from .bundle import read_safe_zip, strict_json_bytes
    entries = read_safe_zip(source, expected_members={"final.json", "bootstrap-mean.f64", "original-mean.f64"},
                            max_member_bytes=64 * 1024**2, max_total_bytes=96 * 1024**2)
    value = strict_json_bytes(entries["final.json"])
    _require(canonical_json_bytes(value) == entries["final.json"], "F4_COMPACT_FINAL_JSON_INVALID")
    return _full_pipeline_final_numbers(value, {p: entries[p + "-mean.f64"] for p in ("bootstrap", "original")},
                                        context=context, seta=seta, selection=selection)


def write_full_pipeline_final_compact(
    root: Any, *, context: Mapping[str, Any], seta: Mapping[str, Any], selection: Mapping[str, Any],
    components: list[Mapping[str, Any]], predictions: Mapping[str, Any],
) -> dict[str, Any]:
    """Seal means only after all twenty original native models have been reopened."""
    import struct
    from .bundle import strict_json_bytes, write_deterministic_zip
    _require(len(components) == 20 and (root / "predictions.json").read_bytes() == canonical_json_bytes(predictions),
             "F4_COMPACT_FINAL_M20_REQUIRED")
    inputs = strict_json_bytes((root / "input.json").read_bytes())
    _require(all(component["native_numbers"]["recipe"] == inputs["recipe"] for component in components),
             "F4_COMPACT_FINAL_RECIPE_MISMATCH")
    models = [{key: component["native_numbers"][key] for key in ("task", "fit_health", "object_audit")}
              for component in components]
    means, metadata = {}, {}
    for population in ("bootstrap", "original"):
        rows = predictions[population]
        means[population] = b"".join(struct.pack("<" + "d" * len(rows["horizons"]), *row)
                                     for row in rows["survival"]["XGBOOST_COX"])
        metadata[population] = {"encoding": "IEEE754_FLOAT64_LE_ROW_MAJOR", "patient_ids": rows["patient_ids"],
            "centers": rows["centers"], "horizons": rows["horizons"], "imputation_count": 20,
            "sha256": sha256_bytes(means[population]), "size_bytes": len(means[population])}
    body = {"kind": "PADML_F4_FINAL_M20_NUMBERS_V1", "input": inputs, "models": models, "means": metadata}
    value = {**body, "identity_sha256": sha256_bytes(canonical_json_bytes(body))}
    rebuilt = _full_pipeline_final_numbers(value, means, context=context, seta=seta, selection=selection)
    _require(canonical_json_bytes(rebuilt) == canonical_json_bytes(predictions), "F4_COMPACT_FINAL_MEAN_REPLAY_MISMATCH")
    write_deterministic_zip(root / "compact.zip", {"final.json": canonical_json_bytes(value),
        **{p + "-mean.f64": raw for p, raw in means.items()}})
    return value


_LAMBDA_HEALTH = (
    "imputation", "lambda_max", "lambda_path_sha256", "lambda_upper_bound",
    "penalized_active_count_path", "penalized_design_column_count", "penalized_entry_covered",
)


def compact_elastic_alpha(record: Mapping[str, Any], contract: Mapping[str, Any]) -> dict[str, Any]:
    """Validate full paths first, then copy actual repeat losses and chosen vectors."""
    summary = _summarize_elastic_alpha(record, contract)
    ratios = summary["ratios"]
    imputations = []
    for path, decision in zip(record["outer_paths"], summary["imputation_decisions"], strict=True):
        index = ratios.index(decision["r_1se"]) if decision["status"] == "FEASIBLE" else None
        imputations.append({
            "imputation": path["imputation"],
            "repeat_loss_paths": decision["repeat_loss_paths"],
            "active_design_df_path": decision["active_design_df_path"],
            "lambda_health": {key: path[key] for key in _LAMBDA_HEALTH},
            "selected_coefficients": None if index is None else {
                parent: vectors[index] for parent, vectors in path["parent_coefficients"].items()},
        })
    return {
        "alpha": summary["alpha"], "outer_training_event_count": summary["outer_training_event_count"],
        "parent_design_columns": record["outer_paths"][0]["parent_design_columns"],
        "partitions": [{key: row[key] for key in (
            "repeat", "inner_fold", "validation_n", "mi_lambda_path_health")}
            for row in sorted(record["partition_losses"], key=lambda row: (row["repeat"], row["inner_fold"]))],
        "imputations": imputations,
    }


def read_compact_elastic_alpha(
    value: Mapping[str, Any], contract: Mapping[str, Any], *,
    expected_design: Mapping[str, int], event_count: int,
    partition_denominators: list[dict[str, int]],
) -> dict[str, Any]:
    """Recompute the original per-MI feasible 1SE and common SetA from retained numbers.

    Repeat losses are the actual weighted reductions of the audited split risks;
    the intentionally retired risk matrices cannot be independently reopened here.
    Caller-derived design, event and validation denominators are mandatory inputs.
    """
    _require(isinstance(value, Mapping) and set(value) == {
        "alpha", "outer_training_event_count", "parent_design_columns", "partitions", "imputations"}
        and type(value["alpha"]) in {int, float} and math.isfinite(value["alpha"])
        and 0.01 <= value["alpha"] <= 1
        and isinstance(expected_design, Mapping) and set(expected_design) == set(selector_parent_names())
        and "AST_ALT" in expected_design
        and all(isinstance(parent, str) and parent and type(width) is int and width > 0
                for parent, width in expected_design.items())
        and value["parent_design_columns"] == expected_design
        and type(event_count) is int and event_count > 0
        and type(value["outer_training_event_count"]) is int
        and value["outer_training_event_count"] == event_count,
        "F4_COMPACT_SELECTOR_ALPHA_SOURCE_INVALID")
    _require(isinstance(partition_denominators, list) and len(partition_denominators) == 15
             and all(isinstance(row, dict) and set(row) == {"repeat", "inner_fold", "validation_n"}
                     and type(row["repeat"]) is int and type(row["inner_fold"]) is int
                     and type(row["validation_n"]) is int and row["validation_n"] > 0
                     for row in partition_denominators)
             and [(row["repeat"], row["inner_fold"]) for row in partition_denominators]
             == [(repeat, inner) for repeat in range(1, 4) for inner in range(1, 6)]
             and isinstance(value["partitions"], list) and len(value["partitions"]) == 15,
             "F4_COMPACT_SELECTOR_PARTITIONS_INVALID")
    ratios = _elastic_ratios(contract)
    for row, expected in zip(value["partitions"], partition_denominators, strict=True):
        _require(isinstance(row, Mapping) and set(row) == {*expected, "mi_lambda_path_health"}
                 and all(type(row[key]) is int and row[key] == number for key, number in expected.items())
                 and isinstance(row["mi_lambda_path_health"], list) and len(row["mi_lambda_path_health"]) == 20,
                 "F4_COMPACT_SELECTOR_PARTITIONS_INVALID")
        for imp, health in enumerate(row["mi_lambda_path_health"], 1):
            _validate_sealed_elastic_lambda_path_health(health, alpha=float(value["alpha"]),
                                                       ratios=ratios, imputation=imp)
    rows = value["imputations"]
    _require(isinstance(rows, list) and len(rows) == 20, "F4_COMPACT_SELECTOR_M20_REQUIRED")
    maxima, bounds = [], []
    forced_df, maximum_df = expected_design["AST_ALT"], sum(expected_design.values())
    for imp, row in enumerate(rows, 1):
        _require(isinstance(row, Mapping) and set(row) == {
            "imputation", "repeat_loss_paths", "active_design_df_path", "lambda_health", "selected_coefficients"}
            and type(row["imputation"]) is int and row["imputation"] == imp
            and isinstance(row["repeat_loss_paths"], list) and len(row["repeat_loss_paths"]) == 3
            and all(isinstance(path, list) and len(path) == 150
                    and all(type(number) in {int, float} and math.isfinite(number) for number in path)
                    for path in row["repeat_loss_paths"])
            and isinstance(row["active_design_df_path"], list) and len(row["active_design_df_path"]) == 150
            and all(type(df) is int and forced_df <= df <= maximum_df for df in row["active_design_df_path"])
            and isinstance(row["lambda_health"], Mapping) and set(row["lambda_health"]) == set(_LAMBDA_HEALTH),
            "F4_COMPACT_SELECTOR_IMPUTATION_INVALID")
        health = row["lambda_health"]
        bounds.append(_validate_sealed_elastic_lambda_path_health(
            health, alpha=float(value["alpha"]), ratios=ratios, imputation=imp))
        _require(row["active_design_df_path"] == [forced_df + active for active in health["penalized_active_count_path"]]
                 and health["penalized_design_column_count"] == maximum_df - forced_df,
                 "F4_COMPACT_SELECTOR_ACTIVE_DF_MISMATCH")
        maxima.append(float(health["lambda_max"]))
    decisions, indices = _elastic_imputation_decisions(
        ratios, [row["repeat_loss_paths"] for row in rows],
        [row["active_design_df_path"] for row in rows], [event_count] * 20, contract)
    coefficients = []
    for row, decision in zip(rows, decisions, strict=True):
        sliced = row["selected_coefficients"]
        if decision["status"] == "EPV_INFEASIBLE":
            _require(sliced is None, "F4_COMPACT_SELECTOR_UNDEFINED_COEFFICIENT_SLICE")
            continue
        _require(isinstance(sliced, dict) and set(sliced) == set(expected_design)
                 and all(isinstance(sliced[parent], list) and len(sliced[parent]) == width
                         and all(type(number) in {int, float} and math.isfinite(number) for number in sliced[parent])
                         for parent, width in expected_design.items()),
                 "F4_COMPACT_SELECTOR_COEFFICIENT_SLICE_INVALID")
        active = forced_df + sum(number != 0 for parent, vector in sliced.items()
                                 if parent != "AST_ALT" for number in vector)
        _require(active == decision["selected_active_design_df"], "F4_COMPACT_SELECTOR_SLICE_DF_MISMATCH")
        coefficients.append(sliced)
    return _elastic_alpha_numeric_summary(
        float(value["alpha"]), ratios, decisions, indices, [event_count] * 20,
        expected_design, maxima, bounds, coefficients if len(indices) == 20 else [], contract)


def read_compact_selector(
    value: Mapping[str, Any], contract: Mapping[str, Any], *, source: Mapping[str, Any],
    expected_design: Mapping[str, int], event_count: int,
    partition_denominators: list[dict[str, int]],
) -> tuple[dict[str, Any], dict[str, Any]]:
    """Recompute both original grids and return actual winning coefficient slices."""
    _require(isinstance(value, Mapping) and set(value) == {"source", "alphas", "selector_result"}
             and value["source"] == source and isinstance(value["alphas"], list),
             "F4_COMPACT_SELECTOR_SOURCE_INVALID")
    coarse = [float(alpha) for alpha in contract["alpha_grid"]["coarse"]]
    records, summaries = {}, {}
    for row in value["alphas"]:
        summary = read_compact_elastic_alpha(row, contract, expected_design=expected_design,
                    event_count=event_count, partition_denominators=partition_denominators)
        alpha = summary["alpha"]
        _require(alpha not in records, "F4_COMPACT_SELECTOR_ALPHA_COVERAGE_INVALID")
        records[alpha], summaries[alpha] = row, summary
    _require(list(records)[:len(coarse)] == coarse, "F4_COMPACT_SELECTOR_COARSE_GRID_INVALID")
    choice = _choose_elastic_summary([summaries[alpha] for alpha in coarse])
    grid = contract["alpha_grid"]["fine"]
    lower, upper = grid["clip"]
    fine = sorted({min(upper, max(lower, round(choice["alpha"] + offset, 3))) for offset in grid["offsets"]})
    _require(list(records) == coarse + [alpha for alpha in fine if alpha not in coarse],
             "F4_COMPACT_SELECTOR_FINE_GRID_INVALID")
    chosen = _choose_elastic_summary([summaries[alpha] for alpha in fine])
    result = {"source": dict(source), "selector": chosen, "coarse_alpha_order": coarse,
              "fine_alpha_order": fine, "distinct_alpha_count": len(records), "selector_path_count": len(records) * 320,
              "final_model_fits": 0, "new_mice_chains": 0, "sensitivity_selection_effect": "NONE"}
    _require(canonical_json_bytes(value["selector_result"]) == canonical_json_bytes(result),
             "F4_COMPACT_SELECTOR_RESULT_MISMATCH")
    return result, records[chosen["alpha"]]


def reduce_compact_primary_seta(
    primaries: list[tuple[dict[str, Any], dict[str, Any]]], *,
    expected_design: Mapping[str, int], full_data_event_count: int, contract: Mapping[str, Any],
) -> dict[str, Any]:
    """After six direct selector consumers, apply the original 4/6 and direction rule."""
    _require(isinstance(primaries, list) and len(primaries) == 6
             and type(full_data_event_count) is int and full_data_event_count > 0
             and contract["ratio_decision"]["natural_parent_frequency"] == "12/20"
             and contract["diagnostics"]["outer_fold_frequency"]["minimum"] == "4/6"
             and contract["diagnostics"]["direction_consistency"]["flag_threshold"] == 0.75,
             "F4_COMPACT_SETA_INPUT_INVALID")
    outer_frequency, signs_by_parent, fold_rows = Counter(), {}, []
    for fold, (result, record) in enumerate(primaries, 1):
        selected = result["selector"]
        _require(result["source"]["context"] == fold and selected["status"] == "FEASIBLE"
                 and record["alpha"] == selected["alpha"] and record["parent_design_columns"] == expected_design,
                 "F4_COMPACT_SETA_COORDINATE_INVALID")
        frequencies, signs = _primary_seta_coefficient_counts(
            [row["selected_coefficients"] for row in record["imputations"]], expected_design)
        flags = {parent: max(values.count(1), values.count(-1)) / len(values) >= 0.75
                 if values and expected_design[parent] == 1 else None for parent, values in signs.items()}
        parents = sorted({"AST_ALT", *(parent for parent, count in frequencies.items() if count >= 12)},
                         key=lambda parent: parent.encode("utf-8"))
        _require(selected["natural_frequency"] == frequencies and selected["direction_diagnostic_flags"] == flags
                 and selected["selected_parents"] == parents, "F4_COMPACT_SETA_COEFFICIENT_MISMATCH")
        outer_frequency.update(parent for parent in parents if parent != "AST_ALT")
        for parent in parents:
            if parent != "AST_ALT" and expected_design[parent] == 1:
                signs_by_parent.setdefault(parent, []).extend(signs[parent])
        fold_rows.append({"fold": fold, "selected_parents": parents,
                          "selected_parent_sha256": sha256_bytes(canonical_json_bytes(parents)),
                          "common_alpha": selected["alpha"]})
    return _reduce_primary_seta_evidence(
        fold_rows, expected_design, outer_frequency, signs_by_parent, full_data_event_count, 0.75)
