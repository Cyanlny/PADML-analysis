"""A04: three paired-outcome permutations per outer, M2 QC and M1 prediction.

Reuses original F1 application M1 and original outer parameters. No selector,
search, STOP, fresh application chain or additional scheduling layer.
"""

from __future__ import annotations

import csv
import io
import math
import os
import shutil
import subprocess
from pathlib import Path
from typing import Any, Mapping

from ._science_authority import load_science_authority
from .bundle import (canonical_json_bytes, extract_safe_zip, sha256_bytes, sha256_file,
                     strict_json_bytes, validate_sha256, write_deterministic_zip)
from .f2_kernel import (_contains_recipe_forbidden_role, _expected_family_parent_column_map,
    _materialize_recipe_training_member, _recipe_training_member_bytes, _response_rows,
    _seal_prediction_matrix, _write_response_subset, predictor_contract)
from .f4 import HORIZONS, _f4_outer_elastic_source, _outer_elastic_parameters
from .f5_application import _audit_json, _new_target, _require, application_context
from .f5_mice_variants import _layout, _original_outer, _source, _STOCHASTIC, _TRANSFORMED
from .f5_sensitivity import (_a04_variant_model_seed, _a12_total_mice_input_members,
    _ablation_component_inputs, _execute_ablation_component, _replay_ablation_component,
    _spearman_average_ranks, _validate_a04_variant_model_task,
    execute_a12_total_mice_bundle, materialize_a12_total_mice_view)
from .runtime import (RSCRIPT_EXECUTABLE, R_LIBRARY, THREAD_ENV,
                      _bounded_ordered_spawn, resolve_pool_workers)


BRANCH = "NEGATIVE_CONTROL"
_PERMUTATION_MEMBERS = {"permutation.json", "analysis-response.csv", "evaluation-response.csv",
                      "source-response.csv", "spec.json", "stdout.txt", "stderr.txt", "native-session.txt"}


from .f5_mice_variants import _frozen, _parameters


def _coordinates(outer: int, index: int) -> dict:
    value = {"outer_fold": outer, "imputation": 1, "variant": BRANCH, "permutation_index": index}
    _a04_variant_model_seed(value)
    return value


def _check_permutation(frozen: Mapping[str, Any], outer: int, index: int, value: Mapping[str, Any]) -> None:
    _coordinates(outer, index)
    row, = [row for row in frozen["registry"]["outer"] if row["outer_fold"] == outer]
    evidence = value["evidence"]
    _require(set(value) == {"evidence", "analysis_response", "evaluation_response"}
             and set(evidence) == {"kind", "outer_fold", "permutation_index", "seed", "rng_kind",
                                  "rng_initial", "rng_final", "blocks"}
             and evidence["kind"] == "PADML_F5_A04_NEGATIVE_PERMUTATION_V1"
             and evidence["outer_fold"] == outer and evidence["permutation_index"] == index
             and evidence["seed"] == 500000 + outer*10 + index
             and evidence["rng_kind"] == ["L'Ecuyer-CMRG", "Inversion", "Rejection"],
             "F5_A04_NEGATIVE_PERMUTATION_INVALID")
    roles = {"ANALYSIS": row["analysis_ids"], "EVALUATION": row["validation_ids"]}
    expected = [(role, center, [patient for patient in ids if frozen["centers"][patient] == center])
                for role, ids in roles.items() for center in sorted({frozen["centers"][p] for p in ids}, key=int)]
    _require(len(evidence["blocks"]) == len(expected), "F5_A04_NEGATIVE_BLOCK_COVERAGE_INVALID")
    original = _response_rows(frozen["response_csv"])[1]
    responses = {role: _response_rows(value[role.lower() + "_response"])[1] for role in roles}
    _require(all(list(responses[role]) == ids for role, ids in roles.items()), "F5_A04_NEGATIVE_RESPONSE_ORDER_INVALID")
    state = evidence["rng_initial"]
    for block, (role, center, ids) in zip(evidence["blocks"], expected, strict=True):
        _require(set(block) == {"role", "center", "patient_ids", "source_patient_ids", "permutation", "rng_before", "rng_after"}
                 and block["role"] == role and block["center"] == center and block["patient_ids"] == ids
                 and isinstance(block["permutation"], list)
                 and all(type(i) is int for i in block["permutation"])
                 and sorted(block["permutation"]) == list(range(1, len(ids) + 1))
                 and block["source_patient_ids"] == [ids[i-1] for i in block["permutation"]]
                 and block["rng_before"] == state, "F5_A04_NEGATIVE_BLOCK_MAPPING_INVALID")
        for rng in (block["rng_before"], block["rng_after"]):
            _require(isinstance(rng, list) and len(rng) == 7 and all(type(i) is int for i in rng),
                     "F5_A04_NEGATIVE_RNG_STATE_INVALID")
        for patient, source in zip(ids, block["source_patient_ids"], strict=True):
            _require(responses[role][patient] == {**original[source], "Patient_ID": patient},
                     "F5_A04_NEGATIVE_PAIRED_RESPONSE_MISMATCH")
        state = block["rng_after"]
    _require(state == evidence["rng_final"], "F5_A04_NEGATIVE_RNG_STATE_INVALID")


def _permutation(frozen: Mapping[str, Any], outer: int, index: int, root: Path) -> dict:
    """One native R permutation stream; replay does not run MICE or a model."""
    _coordinates(outer, index)
    row, = [row for row in frozen["registry"]["outer"] if row["outer_fold"] == outer]
    root.mkdir(mode=0o700)
    (root / "source-response.csv").write_bytes(frozen["response_csv"])
    spec = {"response_path": str(root / "source-response.csv"), "centers": frozen["centers"],
            "analysis_ids": row["analysis_ids"], "evaluation_ids": row["validation_ids"],
            "outer_fold": outer, "permutation_index": index, "output_dir": str(root / "output")}
    (root / "spec.json").write_bytes(canonical_json_bytes(spec))
    environment = {**os.environ, **THREAD_ENV}
    if any(Path(path).is_dir() for path in R_LIBRARY.split(":")):
        environment["R_LIBS_USER"] = R_LIBRARY
    try:
        with (root / "stdout.txt").open("wb") as stdout, (root / "stderr.txt").open("wb") as stderr:
            completed = subprocess.run([RSCRIPT_EXECUTABLE, "--vanilla",
                str(Path(__file__).with_name("kernels") / "f5_a04_negative.R"), "PERMUTE", str(root / "spec.json")],
                env=environment, stdout=stdout, stderr=stderr, check=False, timeout=60)
        _require(completed.returncode == 0, "F5_A04_NEGATIVE_PERMUTATION_NATIVE_FAILED")
        value = {"evidence": strict_json_bytes((root / "output/permutation.json").read_bytes()),
                 "analysis_response": (root / "output/analysis-response.csv").read_bytes(),
                 "evaluation_response": (root / "output/evaluation-response.csv").read_bytes()}
        _check_permutation(frozen, outer, index, value)
        return value
    except BaseException as exc:
        exc.add_note(f"F5_A04_NEGATIVE_PERMUTATION_EVIDENCE:{root}")
        raise


def _analysis_inputs(frozen: Mapping[str, Any], outer: int, index: int, permutation: Mapping[str, Any]) -> dict[str, bytes]:
    _check_permutation(frozen, outer, index, permutation)
    entries = _a12_total_mice_input_members(frozen["binding_contract"], frozen["covariates_csv"],
                                           frozen["response_csv"], outer, "OUTER_ANALYSIS")
    value = strict_json_bytes(entries["input.json"])
    entries["input.json"] = canonical_json_bytes({**value, "kind": "PADML_F5_A04_NEGATIVE_MICE_INPUT",
        "chain_seeds": value["chain_seeds"][:2], "a04_coordinates": _coordinates(outer, index)})
    entries["response.csv"] = permutation["analysis_response"]
    return entries


def _m1_recipe_projection(partition: Mapping[str, Any], predictors: Mapping[str, Any], root: Path) -> dict:
    """The original recipe schema, containing exactly one real training member."""
    ids, binding = partition["fit_ids"], partition["covariates"]
    directory = Path(binding["input_dir"])
    member, = binding["members"]
    path = directory / "imp01.csv"
    _require(member == {"name": "imp01.csv", "sha256": sha256_file(path), "size_bytes": path.stat().st_size}
             and binding["analysis_ids_sha256"] == sha256_bytes(canonical_json_bytes(ids)),
             "F5_A04_NEGATIVE_M1_TRAINING_BINDING_INVALID")
    validate_sha256(binding["analysis_view_sha256"], "a04.negative.analysis_view")
    training = root / "m1"
    training.mkdir(mode=0o700)
    actual = _materialize_recipe_training_member(path, ids, training / "imp01.csv")
    registry = {**predictors["transform_registry"],
                "rows": [row for row in predictors["transform_registry"]["rows"] if row["parent"] != "eGFR_calc"]}
    projection = {"partition_id": partition["partition_id"], "fit_ids_sha256": binding["analysis_ids_sha256"],
        "analysis_ids_sha256": binding["analysis_ids_sha256"], "analysis_view_sha256": binding["analysis_view_sha256"],
        "recipe_registry_record": {"schema_version": "1.0.0", "kind": "PADML_F2_RECIPE_REGISTRY_RECORD",
            "input_dir": str(training), "fit_ids": ids, "members": [actual], "registry": registry,
            "conflict_map": predictors["conflict_map"]}}
    _require(len(registry["rows"]) == 32 and not _contains_recipe_forbidden_role(projection),
             "F5_A04_NEGATIVE_RECIPE_SCOPE_INVALID")
    return projection


def _prepare(context: Mapping[str, Any], outer: int, archives: Mapping[int, Path], root: Path, *,
             original_root: Path | None = None, permutations: Mapping[int, dict] | None = None,
             retain_evidence: bool = False) -> tuple[dict, list[dict]]:
    from .f5 import _compile_partition_design_recipe, _validate_final_design_recipe
    layout, frozen = _layout(context, outer), _frozen(context)
    _require(set(archives) == {1, 2, 3} and (permutations is None or set(permutations) == {1, 2, 3}),
             "F5_A04_NEGATIVE_THREE_INDICES_REQUIRED")
    root.mkdir(mode=0o700)
    if original_root is None:
        original_root = root / "original"
        original = _original_outer(frozen, layout, original_root)
    else:
        original = strict_json_bytes((original_root / "admission.json").read_bytes())
    family, selected, row = layout["family"], layout["selected_parents"], layout["row"]
    application_path = original_root / "views/OUTER_APPLICATION/imputations/imp01.csv"
    application = _recipe_training_member_bytes(application_path, row["validation_ids"])
    predictors = predictor_contract(Path(__file__).parent)
    prepared, jobs = [], []
    for index in range(1, 4):
        work = root / f"P{index}"
        work.mkdir(mode=0o700)
        permutation = (_permutation(frozen, outer, index, work / "permutation")
                       if permutations is None else permutations[index])
        source = work / "analysis-input.zip"
        write_deterministic_zip(source, _analysis_inputs(frozen, outer, index, permutation))
        view = materialize_a12_total_mice_view(source, archives[index], work / "analysis", a04_negative=True,
                                              retain_evidence=retain_evidence)
        path = Path(view["input_dir"]) / "imp01.csv"
        training = _recipe_training_member_bytes(path, row["analysis_ids"])
        for raw, ids in ((training, row["analysis_ids"]), (application, row["validation_ids"])):
            reader = csv.DictReader(io.StringIO(raw.decode("utf-8-sig")))
            rows = list(reader)
            _require(reader.fieldnames == load_science_authority()["science"]["mice"]["private_handoff"]["columns"]
                     and [r["Patient_ID"] for r in rows] == ids
                     and all(r["Center"] == frozen["centers"][r["Patient_ID"]] for r in rows),
                     "F5_A04_NEGATIVE_COMPLETED_ROWS_INVALID")
        fields, response = _response_rows(permutation["analysis_response"])
        fit_response = _write_response_subset(fields, response, row["analysis_ids"], None)
        _require(fit_response["event_count"] == layout["training_event_count"], "F5_A04_NEGATIVE_EVENT_COUNT_DRIFT")
        binding = {"input_dir": view["input_dir"], "members": [view["members"][0]],
                   "analysis_view_sha256": sha256_file(archives[index]),
                   "analysis_ids_sha256": sha256_bytes(canonical_json_bytes(row["analysis_ids"]))}
        partition = {"partition_id": row["partition_id"], "fit_ids": row["analysis_ids"], "covariates": binding}
        recipe = _compile_partition_design_recipe(family, selected, partition, work, a04_negative=True,
                    **({"native_evidence": work / "recipe-native"} if family in _TRANSFORMED else {}))
        _validate_final_design_recipe(recipe, family=family, selected_parents=selected)
        design_count = sum(len(r["columns"]) for r in _expected_family_parent_column_map(
            selected, family, predictors, recipe["transform_recipe"]))
        _require(design_count > 0, "F5_A04_NEGATIVE_EMPTY_DESIGN")
        if family in _TRANSFORMED:
            common = sum(len(r["columns"]) for r in _expected_family_parent_column_map(
                selected, "ELASTIC_NET_COX", predictors, recipe["transform_recipe"]))
            _require(common == layout["common_set_design_df"], "F5_A04_NEGATIVE_SETA_COMPLEXITY_DRIFT")
        coordinates = _coordinates(outer, index)
        seed = _a04_variant_model_seed(coordinates)
        parameters, parameter_source = _parameters(context, layout, 1)
        task = {"family": family, "selected_parents": selected, "parameters": parameters, "imputation": 1,
            "a04_coordinates": coordinates, "registered_model_seed": seed,
            "model_seed": seed if family in _STOCHASTIC else None, "row_count": len(row["analysis_ids"]),
            "family_design_column_count": design_count, "common_set_design_df": layout["common_set_design_df"],
            "training_event_count": layout["training_event_count"], "a04_parameter_source": parameter_source}
        _validate_a04_variant_model_task(family, task)
        entries = {"task.json": canonical_json_bytes(task), "recipe.json": canonical_json_bytes(recipe),
            "fit-covariates.csv": training, "fit-response.csv": fit_response["private_bytes"],
            "prediction-covariates.csv": application}
        _ablation_component_inputs(entries)
        jobs.append({"name": f"O{outer}_NEGATIVE_P{index}_M01", "entries": entries})
        prepared.append({"permutation_index": index, "permutation": permutation["evidence"],
            "analysis_response_sha256": sha256_bytes(permutation["analysis_response"]),
            "evaluation_response": list(_response_rows(permutation["evaluation_response"])[1].values()),
            "analysis_m2_sha256": sha256_file(archives[index]), "analysis_chain_seeds": view["chain_seeds"],
            "training_m1_sha256": sha256_bytes(training), "application_m1_sha256": sha256_bytes(application),
            "recipe": recipe})
    return {"source": _source(context), "family": family, "outer_fold": outer,
            "original_log_donor5": original, "permutations": prepared}, jobs


def _predictions(prepared: Mapping[str, Any], jobs: list[dict], rows: list[dict]) -> list[dict]:
    _require(len(jobs) == len(rows) == 3, "F5_A04_NEGATIVE_MODEL_COVERAGE_INVALID")
    for index, (job, row) in enumerate(zip(jobs, rows, strict=True), 1):
        task, _, _, _, application = _ablation_component_inputs(job["entries"])
        ids = [r["Patient_ID"] for r in application]
        _require(task["a04_coordinates"] == row["a04_coordinates"] == _coordinates(prepared["outer_fold"], index)
                 and row["family"] == prepared["family"] and row["patient_ids"] == ids
                 and row["centers"] == [r["Center"] for r in application] and row["horizons"] == HORIZONS,
                 "F5_A04_NEGATIVE_PREDICTION_COORDINATES_INVALID")
        _seal_prediction_matrix(ids, row["survival"], HORIZONS)
        _require(all(values[0] == 1.0 for values in row["survival"]), "F5_A04_NEGATIVE_MONTH_ZERO_INVALID")
    return rows


def _member_names(family: str, outer: int, *, compact: bool = False) -> set[str]:
    return ({f"views/P{i}.zip" for i in range(1, 4)}
        | {f"fits/O{outer}_NEGATIVE_P{i}_M01.{'numbers.json' if compact else 'zip'}" for i in range(1, 4)}
        | {f"permutations/P{i}/{name}" for i in range(1, 4) for name in _PERMUTATION_MEMBERS}
        | ({f"recipes/P{i}/{name}" for i in range(1, 4)
            for name in ("spec.json", "recipe.json", "stdout.log", "stderr.log")} if family in _TRANSFORMED else set()))


def _execute_view(job: Mapping[str, Any]) -> dict:
    return execute_a12_total_mice_bundle(Path(job["input"]), Path(job["target"]), a04_negative=True)


def execute_negative_outer(lineage: Mapping[str, Any], target: Path, *, f2_run_root: Path,
                           outer: int, workers: int | None = None, f1_runtime_root: Path | None = None) -> dict:
    _new_target(target)
    context = application_context(f2_run_root, lineage, f1_runtime_root=f1_runtime_root)
    layout = _layout(context, outer)
    capacity = resolve_pool_workers(workers)
    root = target.with_name(target.name + ".work")
    root.mkdir(mode=0o700)
    try:
        frozen = context["_f4_inputs"]["o_fit_source"]
        original = _original_outer(frozen, layout, root / "original")
        (root / "original/admission.json").write_bytes(canonical_json_bytes(original))
        (root / "permutations").mkdir(mode=0o700)
        (root / "views").mkdir(mode=0o700)
        permutations, archives, jobs = {}, {}, []
        for index in range(1, 4):
            permutations[index] = _permutation(frozen, outer, index, root / f"permutations/P{index}")
            source, result = root / f"views/P{index}-input.zip", root / f"views/P{index}.zip"
            write_deterministic_zip(source, _analysis_inputs(frozen, outer, index, permutations[index]))
            jobs.append({"input": str(source), "target": str(result)})
            archives[index] = result
        _bounded_ordered_spawn(_execute_view, jobs, selected_slots=capacity)
        prepared, jobs = _prepare(context, outer, archives, root / "prepared",
                                 original_root=root / "original", permutations=permutations)
        (root / "fits").mkdir(mode=0o700)
        jobs = [{**job, "root": str(root / "fits" / job["name"])} for job in jobs]
        rows = _bounded_ordered_spawn(_execute_ablation_component, jobs, selected_slots=capacity)
        members = {name: root / name for name in _member_names(layout["family"], outer)}
        for name in members:
            if name.startswith("recipes/"):
                _, index, leaf = name.split("/")
                members[name] = root / "prepared" / index / "recipe-native" / leaf
            elif name.startswith("permutations/") and name.rsplit("/", 1)[1] in {
                "permutation.json", "analysis-response.csv", "evaluation-response.csv", "native-session.txt"}:
                members[name] = members[name].parent / "output" / members[name].name
        body = {"kind": "PADML_F5_A04_NEGATIVE_OUTER_NATIVE", **prepared,
            "predictions": _predictions(prepared, jobs, rows),
            "members": {name: {"sha256": sha256_file(path), "size_bytes": path.stat().st_size}
                        for name, path in sorted(members.items())}}
        write_deterministic_zip(target, {"negative-outer.json": canonical_json_bytes(body), **members},
                                stored_members={name for name in members if name.endswith(".zip")})
    except BaseException as exc:
        exc.add_note(f"F5_A04_NEGATIVE_OUTER_EVIDENCE:{root}")
        raise
    shutil.rmtree(root)
    return {"status": "COMPUTED_NATIVE_NEGATIVE_CONTROLS", "stage_acceptance": False, "outer_fold": outer,
        "model_fit_count": 3, "mice_chain_execution_count": 6, "application_new_chain_count": 0,
        "stop_fit_count": 0, "pool_workers": min(capacity, 3),
        "sha256": sha256_file(target), "size_bytes": target.stat().st_size}


def replay_negative_outer(source: Path, context: Mapping[str, Any], root: Path, *, retain_evidence: bool = False) -> dict:
    stored, raw = _audit_json(source, "negative-outer.json")
    layout = _layout(context, stored.get("outer_fold"))
    compact='current_primary' in context
    names = _member_names(layout["family"], layout["outer_fold"],compact=compact)
    _require(set(stored) == {"kind", "source", "family", "outer_fold", "original_log_donor5", "permutations", "predictions", "members"}
             and stored["kind"] == ("PADML_CURRENT_A04_NEGATIVE_OUTER_NUMERICAL_V1" if compact else "PADML_F5_A04_NEGATIVE_OUTER_NATIVE")
             and stored["source"] == _source(context) and stored["family"] == layout["family"]
             and set(stored["members"]) == names, "F5_A04_NEGATIVE_OUTER_SOURCE_INVALID")
    _new_target(root)
    root.mkdir(mode=0o700)
    try:
        extracted = root / "archive"
        extract_safe_zip(source, extracted, expected_members={"negative-outer.json": {
            "sha256": sha256_bytes(raw), "size_bytes": len(raw)}, **stored["members"]},
            max_member_bytes=4*1024**3, max_total_bytes=15*1024**3)
        prepared, jobs = _prepare(context, layout["outer_fold"],
            {i: extracted / f"views/P{i}.zip" for i in range(1, 4)}, root / "prepared", retain_evidence=retain_evidence)
        _require(all(stored[key] == value for key, value in prepared.items()), "F5_A04_NEGATIVE_INPUT_REPLAY_MISMATCH")
        for index in range(1, 4):
            archive = extracted / f"permutations/P{index}"
            replay = root / f"prepared/P{index}/permutation"
            for name in ("permutation.json", "analysis-response.csv", "evaluation-response.csv"):
                _require((archive / name).read_bytes() == (replay / "output" / name).read_bytes(),
                         "F5_A04_NEGATIVE_PERMUTATION_REPLAY_MISMATCH")
            _require((archive / "source-response.csv").read_bytes() == _frozen(context)["response_csv"],
                     "F5_A04_NEGATIVE_PERMUTATION_SOURCE_MISMATCH")
            saved_spec, actual_spec = [strict_json_bytes((directory / "spec.json").read_bytes()) for directory in (archive, replay)]
            for key in ("response_path", "output_dir"):
                del saved_spec[key], actual_spec[key]
            _require(saved_spec == actual_spec, "F5_A04_NEGATIVE_PERMUTATION_SPEC_MISMATCH")
            if layout["family"] in _TRANSFORMED:
                _require((extracted / f"recipes/P{index}/recipe.json").read_bytes()
                         == (root / f"prepared/P{index}/recipe-native/recipe.json").read_bytes(),
                         "F5_A04_NEGATIVE_RECIPE_REPLAY_MISMATCH")
        if compact:
            from .f5_a04_current import _a04_replay_numbers
            rows=[_a04_replay_numbers(job,extracted/f"fits/{job['name']}.numbers.json") for job in jobs]
        else:
            rows = [_replay_ablation_component({**job, "archive": extracted / f"fits/{job['name']}.zip",
                **({"replay_evidence": root / (job["name"] + "-replay")} if retain_evidence else {})}) for job in jobs]
        predictions = _predictions(prepared, jobs, rows)
        if retain_evidence:
            (root / "replayed-predictions.json").write_bytes(canonical_json_bytes(predictions))
        _require(predictions == stored["predictions"], "F5_A04_NEGATIVE_PREDICTION_REPLAY_MISMATCH")
    except BaseException as exc:
        exc.add_note(f"F5_A04_NEGATIVE_REPLAY_EVIDENCE:{root}")
        raise
    if not retain_evidence:
        shutil.rmtree(root)
    return stored


def negative_handoff(context: Mapping[str, Any], outers: list[dict], index: int) -> tuple[dict, bytes]:
    _coordinates(1, index)
    _require([row["outer_fold"] for row in outers] == list(range(1, 7)), "F5_A04_NEGATIVE_SIX_OUTERS_REQUIRED")
    primary, family = context["_f4_inputs"]["handoff"], context["lineage"]["final_family"]
    ids, centers = primary["patient_ids"], primary["centers"]
    by_id, responses = {}, {}
    for outer in outers:
        _require(outer["family"] == family and outer["source"] == _source(context)
                 and len(outer["predictions"]) == len(outer["permutations"]) == 3,
                 "F5_A04_NEGATIVE_COORDINATE_COVERAGE_INVALID")
        prediction, permutation = outer["predictions"][index-1], outer["permutations"][index-1]
        _require(prediction["a04_coordinates"] == _coordinates(outer["outer_fold"], index)
                 and permutation["permutation_index"] == index
                 and prediction["horizons"] == HORIZONS and not set(prediction["patient_ids"]).intersection(by_id)
                 and [row["Patient_ID"] for row in permutation["evaluation_response"]] == prediction["patient_ids"],
                 "F5_A04_NEGATIVE_PATIENT_COVERAGE_INVALID")
        by_id.update({patient: (center, values) for patient, center, values in zip(
            prediction["patient_ids"], prediction["centers"], prediction["survival"], strict=True)})
        responses.update({row["Patient_ID"]: row for row in permutation["evaluation_response"]})
    _require(set(by_id) == set(responses) == set(ids) and [by_id[p][0] for p in ids] == centers
             and set(centers) == {"36", "38", "39", "48", "52", "54"}, "F5_A04_NEGATIVE_PATIENT_COVERAGE_INVALID")
    matrix = [by_id[p][1] for p in ids]
    _seal_prediction_matrix(ids, matrix, HORIZONS)
    response = _write_response_subset(["Patient_ID", "All_Cause_Death", "Death_Followup_months"], responses, ids, None)
    return {"patient_ids": ids, "centers": centers, "horizons": HORIZONS, "survival": {BRANCH: matrix}}, response["private_bytes"]


def _threshold_summary(items: list[dict]) -> dict:
    _require(len(items) == 3, "F5_A04_NEGATIVE_COMPLETE_DENOMINATOR_REQUIRED")
    values = []
    for item in items:
        value = item.get("value")
        reasons = item.get("reasons")
        _require(isinstance(reasons, list) and all(isinstance(reason, str) and reason for reason in reasons)
                 and (type(value) in {int, float} and math.isfinite(value) and 0 <= value <= 1
                      and item.get("status") == "ESTIMABLE" and not reasons
                      or value is None and item.get("status") == "NOT_ESTIMABLE" and bool(reasons)),
                 "F5_A04_NEGATIVE_METRIC_NUMERICAL_ERROR")
        values.append(value)
    mean = math.fsum(values) / 3 if all(value is not None for value in values) else None
    triggered = any(value is not None and value > 0.65 for value in values) or mean is not None and mean > 0.60
    return {"status": "HARD_REVIEW_REQUIRED" if triggered else "NOT_ESTIMABLE" if mean is None else "PASS",
            "values": items, "denominator": 3, "estimable_count": sum(v is not None for v in values),
            "arithmetic_mean": mean, "hard_review_required": bool(triggered)}


def _negative_evaluation_summary(outers: list[dict], evaluations: list[dict], handoffs: list[dict]) -> dict:
    """Original numerical reduction, independent of legacy/global family context."""
    _require(len(evaluations) == len(handoffs) == 3
        and [row["outer_fold"] for row in outers] == list(range(1,7)),
        "F5_A04_NEGATIVE_THREE_EVALUATIONS_REQUIRED")
    scopes = ["MICRO", "36", "38", "39", "48", "52", "54"]
    reduced = {}
    for scope in scopes:
        metrics = {"uno_c_24": [], "auc_24": []}
        for index, evaluation in enumerate(evaluations, 1):
            handoff = handoffs[index-1]
            _require(evaluation["status"] == "COMPUTED" and [row["scope"] for row in evaluation["scopes"]] == scopes
                     and evaluation["model_refit_count"] == 0, "F5_A04_NEGATIVE_EVALUATION_SCOPE_INVALID")
            row, = [row for row in evaluation["scopes"] if row["scope"] == scope]
            _require(set(row["families"]) == {BRANCH} and row["patient_count"] == (
                len(handoff["patient_ids"]) if scope == "MICRO" else handoff["centers"].count(scope)),
                "F5_A04_NEGATIVE_METRIC_DENOMINATOR_INVALID")
            discrimination = row["families"][BRANCH]["discrimination"]
            metrics["uno_c_24"].append(discrimination["uno_c_24"])
            metrics["auc_24"].append(discrimination["auc"]["24"])
        reduced[scope] = {name: _threshold_summary(items) for name, items in metrics.items()}
    correlations = []
    for outer in outers:
        predictions = outer["predictions"]
        _require(all(row["patient_ids"] == predictions[0]["patient_ids"] for row in predictions),
                 "F5_A04_NEGATIVE_CORRELATION_ALIGNMENT_INVALID")
        for left, right in ((1, 2), (1, 3), (2, 3)):
            risks = [[1.0-row[24] for row in predictions[index-1]["survival"]] for index in (left, right)]
            rho, status = _spearman_average_ranks(*risks)
            correlations.append({"outer_fold": outer["outer_fold"], "indices": [left, right], "rho": rho,
                "status": status, "reason": ("FEWER_THAN_TWO_PATIENTS" if len(risks[0]) < 2 else "CONSTANT_RISK_VECTOR")
                if rho is None else None, "trigger": None})
    hard = any(item["hard_review_required"] for metrics in reduced.values() for item in metrics.values())
    pooled_na = any(item["estimable_count"] != 3 for item in reduced["MICRO"].values())
    gate = "HARD_REVIEW_REQUIRED" if hard else "BLOCKED_POOLED_NOT_ESTIMABLE" if pooled_na else "PASS"
    return {"gate_status": gate, "blocking_for_production": gate != "PASS", "scopes": reduced,
        "evaluations": evaluations, "risk_correlations_descriptive_only": correlations}


def negative_result(context: Mapping[str, Any], outers: list[dict], evaluations: list[dict]) -> dict:
    _require(len(evaluations) == 3, "F5_A04_NEGATIVE_THREE_EVALUATIONS_REQUIRED")
    handoffs = [negative_handoff(context, outers, index)[0] for index in range(1, 4)]
    summary = _negative_evaluation_summary(outers, evaluations, handoffs)
    return {"status": "NATIVE_NEGATIVE_MICE_MODELS_AND_PERMUTATIONS_REPLAYED", "source": _source(context),
        "final_family": context["lineage"]["final_family"], "permutation_indices": [1, 2, 3],
        "model_fit_count": 18, "mice_chain_execution_count": 36, "application_new_chain_count": 0,
        "selector_path_count": 0, "search_fit_count": 0, "stop_fit_count": 0,
        "prediction_m": 1, "analysis_qc_m": 2, "selection_effect": "NONE", "stage_acceptance": False,
        **summary,
        "variable_stability_trigger": "REMOVED_BY_APPROVED_20260907_AMENDMENT",
        "scope": "CENTRE_WISE_OUTCOME_PAIR_PERMUTATION_RETAINS_BETWEEN_CENTRE_SIGNAL_NO_ABSENCE_OF_LEAKAGE_CLAIM",
        "outer_sources": [{"outer_fold": row["outer_fold"], "original_log_donor5": row["original_log_donor5"]} for row in outers]}


def evaluate_negative(context: Mapping[str, Any], outers: list[dict], root: Path, *,
                      native_archives: Mapping[int, Path] | None = None) -> tuple[dict, dict[str, Path]]:
    from .f4 import evaluate_predictions
    from .f5_sensitivity import _validate_a12_native_evaluation
    _require(native_archives is None or set(native_archives) == {1, 2, 3},
             "F5_A04_NEGATIVE_THREE_METRIC_ORIGINALS_REQUIRED")
    evaluations, members = [], {}
    for index in range(1, 4):
        handoff, response = negative_handoff(context, outers, index)
        native = root / f"negative-metrics-P{index}.zip" if native_archives is None else native_archives[index]
        evaluation = evaluate_predictions(handoff, response, **(
            {"evidence_root": root / f"negative-metrics-P{index}", "native_archive": native}
            if native_archives is None else {"replay_native_archive": native}))
        _validate_a12_native_evaluation(evaluation, handoff, response, native_archive=native, a04_negative=True)
        evaluations.append(evaluation)
        members[f"negative-controls/metrics-P{index}.zip"] = native
    return negative_result(context, outers, evaluations), members
