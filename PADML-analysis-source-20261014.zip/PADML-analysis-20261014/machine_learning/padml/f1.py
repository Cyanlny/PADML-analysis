from __future__ import annotations

from typing import Any

from ._science_authority import load_science_authority
from .bundle import canonical_json_bytes, sha256_bytes


F1_COMMON_INPUT_NAME = "common-input.zip"
F1_WORKBOOK_MEMBER = "input/workbook.xlsx"


def load_f1_authority() -> dict[str, Any]:
    return load_science_authority()


F1_AUTHORITY_SHA256 = sha256_bytes(canonical_json_bytes(load_f1_authority()))
