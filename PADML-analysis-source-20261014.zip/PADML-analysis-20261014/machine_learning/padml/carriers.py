"""One physical carrier with explicit, pinned references in the current run.

A reference archive keeps the existing numerical-reader interface. It is not a
transport archive: consumers transfer only their declared numerical closure.
"""
from __future__ import annotations
import io
import os
import stat
import struct
import zipfile
from pathlib import Path

_INDEX = "__padml_references__.json"


def _need(ok, reason):
    from .bundle import ContractError
    if not ok:
        raise ContractError(reason)


def run_context():
    from .bundle import strict_json_bytes
    name = os.environ.get("PADML_F45_RUN_PATH")
    if not name:
        return None
    value = strict_json_bytes(Path(name).read_bytes())
    return value if value.get("kind") == "PADML_INTEGRATED_RAW_RUN_V1" else None


def _admitted_producer(ref, run):
    from .integrated import same_batch_generations
    _need(run is not None and ref["producer"] in same_batch_generations(run).values(),
          "CARRIER_PRODUCER_DRIFT")


def file_reference(path, role, run=None):
    from .integrated import qualified_file_pins
    from .nested_loco import _sha
    run = run or run_context()
    _need(run is not None, "CARRIER_CURRENT_RUN_REQUIRED")
    base, path = Path(run["run_root"]), Path(path)
    _need(path.is_absolute() and path.is_file() and not path.is_symlink()
          and path.resolve(strict=True).is_relative_to(base.resolve(strict=True)), "CARRIER_REFERENCE_PATH_INVALID")
    relative = path.relative_to(base).as_posix()
    record = base / "shared/file-qualifications" / (_sha(relative) + ".json")
    pin = qualified_file_pins({relative: path}, identity=run["source_identity"], record=record)[relative]
    return {"role": role, "path": relative, **pin, "producer": run["source_identity"]}


def resolve_reference(ref, run=None):
    from .bundle import validate_relative_path
    from .integrated import qualified_file_pins
    from .nested_loco import _sha
    run = run or run_context()
    _admitted_producer(ref, run)
    name = validate_relative_path(ref["path"], "reference.path")
    base = Path(run["run_root"])
    path = base / name
    if os.environ.get("PADML_ARCHIVE_INDEX"):
        from .reports import archived_location
        location = archived_location(name, run, expected={k:ref[k] for k in ('sha256','size_bytes')})
        if location is not None:
            path, item = location
            _need(item["pin"] == {k: ref[k] for k in ("sha256", "size_bytes")}, "CARRIER_ARCHIVE_REFERENCE_DRIFT")
            _need(item["member"] is None, "CARRIER_PACKED_MEMBER_HAS_NO_NATIVE_PATH")
            return path
    _need(not path.is_symlink() and path.resolve(strict=True).is_relative_to(base.resolve(strict=True)),
          "CARRIER_REFERENCE_PATH_INVALID")
    pin = {k: ref[k] for k in ("sha256", "size_bytes")}
    qualified_file_pins({name: path}, identity=ref["producer"], expected={name: pin},
        record=base / "shared/file-qualifications" / (_sha(name) + ".json"))
    return path


def read_reference(ref, run=None):
    run = run or run_context()
    _admitted_producer(ref, run)
    if os.environ.get("PADML_ARCHIVE_INDEX"):
        from .reports import archived_bytes, archived_location
        pin = {k:ref[k] for k in ('sha256','size_bytes')}
        location = archived_location(ref["path"], run, expected=pin)
        if location is not None:
            _need(location[1]["pin"] == {k: ref[k] for k in ("sha256", "size_bytes")}, "CARRIER_ARCHIVE_REFERENCE_DRIFT")
            return archived_bytes(ref["path"], run, expected=pin)
    path = resolve_reference(ref, run)
    raw = path.read_bytes()
    from .runtime import advise_completed_io
    advise_completed_io([path], sync=False, minimum_bytes=8*1024**2)
    return raw


def validate_reference(ref, run=None):
    run = run or run_context()
    _admitted_producer(ref, run)
    if os.environ.get("PADML_ARCHIVE_INDEX"):
        from .reports import archived_location
        location = archived_location(ref["path"], run, expected={k:ref[k] for k in ('sha256','size_bytes')})
        if location is not None:
            _need(location[1]["pin"] == {k: ref[k] for k in ("sha256", "size_bytes")}, "CARRIER_ARCHIVE_REFERENCE_DRIFT")
            if location[1]["member"] is not None:
                read_reference(ref, run)
            return
    resolve_reference(ref, run)


def write_carrier(target, members, *, references, run=None):
    from .bundle import canonical_json_bytes, write_deterministic_zip
    from .nested_loco import _sealed
    run = run or run_context()
    _need(run is not None and not set(members).intersection(references), "CARRIER_MEMBER_COLLISION")
    refs = {name: file_reference(path, name, run) for name, path in references.items()}
    index = _sealed({"kind": "PADML_RUN_REFERENCES_V1", "run_identity": run["identity"],
        "source_identity": run["source_identity"], "members": refs})
    write_deterministic_zip(target, {**members, _INDEX: canonical_json_bytes(index)},
                            stored_members={n for n in members if n.endswith((".zip", ".rds"))})
    return index


def archive_source(file, *, expected=None):
    """Resolve one logical source through the existing immutable archive index."""
    if os.environ.get("PADML_ARCHIVE_INDEX") and isinstance(file, (str, Path)):
        run = run_context()
        path = Path(file)
        if run is not None and path.is_relative_to(Path(run["run_root"])):
            from .reports import archived_location, archived_bytes
            name = path.relative_to(Path(run["run_root"])).as_posix()
            location = archived_location(name, run, expected=expected)
            if location is not None:
                return location[0] if location[1]["member"] is None else io.BytesIO(archived_bytes(name, run, expected=expected))
    return file


def source_pin(path):
    """Pins of a local or archived source, retaining its scientific name."""
    from .bundle import sha256_file, sha256_bytes
    if os.environ.get('PADML_ARCHIVE_INDEX'):
        run = run_context()
        logical = Path(path)
        if run is not None and logical.is_relative_to(Path(run['run_root'])):
            from .reports import archived_location
            location = archived_location(logical.relative_to(Path(run['run_root'])).as_posix(), run)
            if location is not None:
                # archived_location qualifies the whole immutable physical
                # object/pack; reading a pin need not unzip its member again.
                return dict(location[1]['pin'])
    source = archive_source(path)
    if isinstance(source, io.BytesIO):
        raw = source.getvalue()
        return {"sha256": sha256_bytes(raw), "size_bytes": len(raw)}
    source = Path(source)
    _need(source.is_absolute() and source.is_file() and not source.is_symlink()
        and source.resolve(strict=True) == source, "CARRIER_SOURCE_INVALID")
    return {"sha256": sha256_file(source), "size_bytes": source.stat().st_size}


def source_bytes(path, *, limit=None, expected=None):
    source = archive_source(path, expected=expected)
    if isinstance(source, io.BytesIO):
        raw = source.getvalue()
        _need(limit is None or len(raw) <= limit, "CARRIER_SOURCE_TOO_LARGE")
        return raw
    source = Path(source)
    _need(source.is_absolute() and source.is_file() and not source.is_symlink()
        and source.resolve(strict=True) == source, "CARRIER_SOURCE_INVALID")
    _need(limit is None or source.stat().st_size <= limit, "CARRIER_SOURCE_TOO_LARGE")
    with source.open("rb") as stream:
        raw = stream.read(-1 if limit is None else limit + 1)
    _need(limit is None or len(raw) <= limit, "CARRIER_SOURCE_TOO_LARGE")
    from .runtime import advise_completed_io
    advise_completed_io([source], sync=False, minimum_bytes=8*1024**2)
    return raw


def source_root(path):
    """Physical resource-observation directory for a logical read-only tree."""
    _need(isinstance(path, Path) and path.is_absolute() and not path.is_symlink(), "CARRIER_SOURCE_ROOT_INVALID")
    index_path = os.environ.get("PADML_ARCHIVE_INDEX")
    run = run_context() if index_path else None
    if run is not None and path.is_relative_to(Path(run["run_root"])):
        from .reports import _archive_index
        index_path = Path(index_path)
        index = _archive_index(index_path, run)
        prefix = "" if path == Path(run["run_root"]) else path.relative_to(Path(run["run_root"])).as_posix().rstrip('/') + '/'
        _need(any(name.startswith(prefix) for name in index["members"]), "CARRIER_SOURCE_ROOT_MISSING")
        return index_path.parent
    _need(path.is_dir() and path.resolve(strict=True) == path, "CARRIER_SOURCE_ROOT_INVALID")
    return path


class CarrierZip(zipfile.ZipFile):
    """Explicit logical ZIP reader; external files are immutable qualified pins."""
    def __init__(self, file, mode="r", *args, **kwargs):
        self.references = {}
        if mode == "r":
            file = archive_source(file)
        super().__init__(file, mode, *args, **kwargs)
        if mode == 'r' and not self._filePassed:
            from .runtime import ConsumedStream
            # ZipFile._fpclose owns this handle until its LAST child closes,
            # including when the outer context has already returned.
            self.fp = ConsumedStream(self.fp)
        if mode != "r" or _INDEX not in self.NameToInfo:
            return
        from .bundle import strict_json_bytes, validate_relative_path
        from .nested_loco import _sealed
        from .integrated import same_batch_generations
        _need(sum(i.filename == _INDEX for i in self.filelist) == 1, "CARRIER_DUPLICATE_INDEX")
        _need(self.NameToInfo[_INDEX].file_size <= 32*1024**2, "CARRIER_INDEX_TOO_LARGE")
        index = strict_json_bytes(super().read(_INDEX))
        run = run_context()
        _need(run is not None and index["kind"] == "PADML_RUN_REFERENCES_V1"
            and same_batch_generations(run).get(index["run_identity"]) == index["source_identity"]
            and _sealed({k:v for k,v in index.items() if k != "identity_sha256"}) == index,
            "CARRIER_IDENTITY_DRIFT")
        for name, ref in index["members"].items():
            validate_relative_path(name, "carrier.member")
            _need(name not in self.NameToInfo and ref["role"] == name, "CARRIER_MEMBER_COLLISION")
            self.references[name] = ref
        self.reference_index = index
        self.NameToInfo.pop(_INDEX)
        self._virtual = {}
        for name, ref in self.references.items():
            info = zipfile.ZipInfo(name)
            info.file_size = info.compress_size = ref["size_bytes"]
            info.external_attr = (stat.S_IFREG | 0o600) << 16
            info.CRC = 0
            self._virtual[name] = info
            self.NameToInfo[name] = info

    def infolist(self):
        return [i for i in super().infolist() if i.filename != _INDEX] + list(getattr(self, "_virtual", {}).values())

    def namelist(self):
        return [i.filename for i in self.infolist()]

    def getinfo(self, name):
        return self._virtual[name] if name in self.references else super().getinfo(name)

    def external_path(self, name):
        if name in self.references and os.environ.get("PADML_ARCHIVE_INDEX"):
            from .reports import archived_location
            ref = self.references[name]
            location = archived_location(ref["path"], run_context(),
                expected={k:ref[k] for k in ('sha256','size_bytes')})
            if location is not None and location[1]["member"] is not None:
                return None
        return resolve_reference(self.references[name]) if name in self.references else None

    def open(self, name, mode="r", pwd=None, *, force_zip64=False):
        key = name.filename if isinstance(name, zipfile.ZipInfo) else name
        if key in self.references:
            _need(mode == "r" and pwd is None, "CARRIER_IMMUTABLE")
            path = self.external_path(key)
            if path is None:
                return io.BytesIO(read_reference(self.references[key]))
            from .runtime import ConsumedStream
            return ConsumedStream(path.open('rb'))
        return super().open(name, mode, pwd, force_zip64=force_zip64)

    def read(self, name, pwd=None):
        key = name.filename if isinstance(name, zipfile.ZipInfo) else name
        if key not in self.references:
            return super().read(name, pwd)
        _need(pwd is None, 'CARRIER_IMMUTABLE')
        with self.open(key) as stream:
            raw = stream.read()
        return raw


def open_carrier(file, mode="r", *args, **kwargs):
    return CarrierZip(file, mode, *args, **kwargs)


def publish_pooled(matrix, *, patient_ids, receipts, family, partition):
    from .nested_loco import _sha, _write_exact_once
    run = run_context()
    if run is None:
        return {"pooled_survival": matrix}
    key = _sha({"ids": patient_ids, "mi_sources": receipts, "family": family, "partition": partition})
    path = Path(run["run_root"]) / "shared/oof" / (key + ".f64")
    path.parent.mkdir(parents=True, exist_ok=True)
    _write_exact_once(path, b"".join(struct.pack("<37d", *row) for row in matrix), "OOF_VALUES_DRIFT")
    return {"pooled_survival_ref": file_reference(path, "M20_POOLED_OOF", run)}


def pooled_matrix(item):
    if "pooled_survival" in item:
        return item["pooled_survival"]
    raw = read_reference(item["pooled_survival_ref"])
    _need(len(raw) == len(item["patient_ids"]) * 37 * 8, "OOF_MATRIX_SHAPE_INVALID")
    return [list(row) for row in struct.iter_unpack("<37d", raw)]
