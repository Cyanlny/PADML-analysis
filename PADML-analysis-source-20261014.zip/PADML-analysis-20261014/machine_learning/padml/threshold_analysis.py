"""Independent association-data threshold appendage; no legacy run dispatch.

R owns every scientific number. This module only pins inputs, dispatches the
existing ReadyPool, publishes task receipts and admits direct table consumption.
"""
from __future__ import annotations

import argparse
import fcntl
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time
import uuid

from .runtime import (CPU_MINUS_8, RSCRIPT_EXECUTABLE, THREAD_ENV, _ready_ordered, admit_stage,
                      observe_execution_resources)

ROOT = Path(__file__).resolve().parents[1]
KERNEL = ROOT / "padml/kernels/threshold_analysis.R"
CONFIG = ROOT / "config/threshold-analysis.json"
GIB = 1024**3
TABLES = ('classification', 'threshold_points', 'threshold_distribution', 'support',
          'bootstrap_failure_counts', 'cox', 'ph', 'complete_case', 'km', 'riskset', 'groups')


def require(ok, reason):
    if not ok:
        raise RuntimeError(reason)


def stat_id(path):
    st = path.stat()
    require(path.is_file() and not path.is_symlink(), "SOURCE_NOT_REGULAR")
    return [st.st_dev, st.st_ino, st.st_size, st.st_mtime_ns, st.st_ctime_ns]


def pin(path):
    before = stat_id(path)
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    require(before == stat_id(path), "SOURCE_CHANGED_DURING_READ")
    return {"sha256": digest.hexdigest(), "size_bytes": before[2]}


def read_json(path):
    return json.loads(path.read_text())


def write_json(path, value):
    part = path.with_name(path.name + ".part")
    with part.open("w") as stream:
        json.dump(value, stream, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())
    part.replace(path)
    sync_directory(path.parent)


def sync_directory(path):
    fd = os.open(path, os.O_RDONLY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def identity_of(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def qualify(paths, config, output):
    """One byte qualification per unchanged source, including cold restart."""
    cache_path = output / "source-qualification.json"
    old = read_json(cache_path) if cache_path.exists() else {}
    records = {}
    for name, path in paths.items():
        state = stat_id(path)
        previous = old.get("sources", {}).get(name, {})
        record_pin = previous.get("pin") if previous.get("path") == str(path) and previous.get("stat") == state else pin(path)
        if name in config["source_sha256"]:
            require(record_pin["sha256"] == config["source_sha256"][name], "FROZEN_ASSOCIATION_INPUT_DRIFT:" + name)
        records[name] = {"path": str(path), "stat": state, "pin": record_pin}
    scientific = {"sources": {k: v["pin"] for k, v in records.items()}, "revision": config["revision"]}
    identity = identity_of(scientific)
    require(not old or old["identity"] == identity, "EXISTING_THRESHOLD_OUTPUT_DIFFERENT_SCIENCE")
    write_json(cache_path, {"identity": identity, "sources": records})
    return identity, records


def outputs_for(task, output):
    if task["mode"] == "cox":
        return [output / "numerical" / (task["spec"]["task"] + ".rds")]
    if task["mode"] == "bootstrap":
        return [output / "numerical" / f"B{b:04d}.rds" for b in task["indices"]]
    return {"prepare": [output / "prepared.rds", output / "prepared.json", output/'observation.rds'],
            "point": [output / "point.rds"],
            "reduce": [output / "acceptance.json"] + [output/'tables'/(name+'.csv') for name in TABLES]}[task["mode"]]


def retained_receipt(receipt_path, identity, expected):
    if not receipt_path.exists():
        return None
    receipt = read_json(receipt_path)
    require(receipt["identity"] == identity and receipt["status"] == "COMPLETED", "TASK_RECEIPT_IDENTITY_DRIFT")
    require(set(receipt["outputs"]) == {str(p) for p in expected}, "TASK_RECEIPT_MEMBER_DRIFT")
    refreshed = False
    for path in expected:
        previous = receipt["outputs"][str(path)]
        require(path.is_file(), "PUBLISHED_TASK_MEMBER_MISSING")
        if previous["stat"] != stat_id(path):
            require(pin(path) == previous["pin"], "PUBLISHED_TASK_MEMBER_CHANGED")
            # Refresh only the small receipt after byte-identical relocation/touch.
            previous["stat"] = stat_id(path)
            refreshed = True
    if refreshed:
        write_json(receipt_path, receipt)
    return receipt


def run_task(task):
    output = Path(task["output"])
    expected = outputs_for(task, output)
    receipt_path = output / "receipts" / (task["id"] + ".json")
    request = output / "requests" / (task["id"] + ".json")
    log = output / "logs" / (task["id"] + ".log")
    started = time.monotonic()
    with (output / ".compute.lock").open("r+") as lease, log.open("ab") as stream:
        fcntl.flock(lease, fcntl.LOCK_SH | fcntl.LOCK_NB)
        owner = read_json(output / "owner.json")
        require(owner["attempt_id"] == task["attempt_id"] and owner["status"] == "RUNNING",
                "TASK_OWNER_REPLACED")
        os.kill(owner["pid"], 0)
        invalid = receipt_path.with_suffix('.invalid.json')
        require(not invalid.exists(), 'TASK_SOURCE_DRIFT_REQUIRES_CAUSAL_REVIEW')
        def check_sources():
            require(all(stat_id(Path(v['path'])) == v['stat'] for v in task['source_records'].values()),
                    'TASK_SOURCE_CHANGED')
        check_sources()
        marker = expected[0].with_suffix('.rds.started') if task['mode'] == 'cox' else None
        retained = retained_receipt(receipt_path, task["identity"], expected)
        if retained:
            if marker and marker.exists():
                require(read_json(marker)['identity'] == task['identity'], 'COX_STARTED_IDENTITY_DRIFT')
                marker.unlink(); sync_directory(marker.parent)
            return {"id": task["id"], "reused": True, "seconds": 0.0}
        if request.exists() and any(p.exists() for p in expected):
            previous = read_json(request)
            require(previous.get('source_records') == task['source_records'], 'UNCOMMITTED_SOURCE_STATE_CHANGED')
        native_task = dict(task)
        if marker and not expected[0].exists():
            require(not marker.exists(), 'COX_INTERRUPTED_REQUIRES_CAUSAL_REVIEW')
            # Durable before native execution; only a published result can clear it.
            write_json(marker, {'identity':task['identity'], 'id':task['id'], 'attempt_id':task['attempt_id']})
            native_task['fit_authorized'] = True
        write_json(request, native_task)
        child = subprocess.Popen([task["rscript"], "--vanilla", str(KERNEL), str(request)],
            stdout=stream, stderr=subprocess.STDOUT, env={**os.environ, **THREAD_ENV},
            pass_fds=(lease.fileno(),), start_new_session=False)
        # The shared fd survives a lost parent. A new owner needs EX and cannot
        # start until all original native children have released this inode.
        try:
            native_task.update(native_pid=child.pid, native_pgid=os.getpgid(child.pid))
            write_json(request,native_task)
            code = child.wait(timeout=3600)
        except BaseException:
            if child.poll() is None: child.terminate()
            try: child.wait(timeout=15)
            except subprocess.TimeoutExpired: child.kill(); child.wait()
            raise
        require(code == 0, f"NATIVE_THRESHOLD_TASK_FAILED:{task['id']}:{code}:see {log}")
        try:
            check_sources()
        except (RuntimeError,OSError):
            write_json(invalid, {'identity':task['identity'],'reason':'SOURCE_CHANGED_DURING_NATIVE','id':task['id']})
            raise
        members = {}
        for path in expected:
            with path.open("rb") as member:
                os.fsync(member.fileno())
            members[str(path)] = {"stat": stat_id(path), "pin": pin(path)}
        for parent in {p.parent for p in expected}:
            sync_directory(parent)
        receipt = {"id": task["id"], "identity": task["identity"], "status": "COMPLETED",
                   "outputs": members, "seconds": time.monotonic() - started}
        write_json(receipt_path, receipt)
        if marker and marker.exists():
            require(read_json(marker)['identity'] == task['identity'], 'COX_STARTED_IDENTITY_DRIFT')
            marker.unlink(); sync_directory(marker.parent)
    return {"id": task["id"], "reused": False, "seconds": receipt["seconds"]}


def validate_report(output, identity, prepared):
    import csv
    import math
    acceptance = read_json(output / "acceptance.json")
    require(acceptance["identity"] == identity and acceptance["direct_consumer_completed"] is True
            and acceptance["bootstrap_completed"] == 1000 and acceptance["logical_cox_fits"] == 141
            and acceptance["unique_cox_fits"] == prepared["physical_fit_n"]
            and acceptance["numerical_failures"] == 0, "DIRECT_REPORT_ACCEPTANCE_INVALID")
    require(set(acceptance['table_rows']) == set(TABLES), 'DIRECT_REPORT_MEMBERS_INVALID')
    files = {}
    for name, count in acceptance["table_rows"].items():
        path = output / "tables" / (name + ".csv")
        with path.open(newline="") as stream:
            reader = csv.DictReader(stream)
            require(not {"Patient_ID", "patient_id"}.intersection(reader.fieldnames or []), "PUBLIC_PATIENT_ID")
            rows = list(reader)
        require(len(rows) == count, "DIRECT_REPORT_ROW_COUNT:" + name)
        fields = {'classification':{'branch','variant','scope','center','metric','value','status','valid_b','interval_method'},
                  'threshold_points':{'branch','center','raw','rounded','reason'},
                  'threshold_distribution':{'branch','center','variant','valid_b','interpretation'},
                  'support':{'center','n','case_n','control_n','min_g','ess','reason'},
                  'bootstrap_failure_counts':{'branch','variant','scope','center','metric','reason','count'},
                  'cox':{'kind','model','time','contrast','beta','se','hr','lower','upper','m'},
                  'ph':{'kind','model','imputation','term','chisq','df','p'},
                  'complete_case':{'n','events','beta','hr','lower','upper'},
                  'km':{'group','time','survival','lower','upper','n_risk'},
                  'riskset':{'group','time','n_risk'},
                  'groups':{'branch','group','n','events','risk24','lower','upper','crude_death_proportion'}}
        require(fields[name].issubset(reader.fieldnames or []),'DIRECT_REPORT_SCHEMA:'+name)
        if name == 'classification':
            keys = set()
            for row in rows:
                key = tuple(row[x] for x in ('branch','variant','scope','center','metric'))
                require(key not in keys,'DUPLICATE_METRIC_COORDINATE'); keys.add(key)
                require(0 <= int(row['valid_b']) <= 1000,'BOOTSTRAP_VALID_COUNT')
                if row['status']=='ESTIMABLE':
                    value=float(row['value']); signed=row['variant']=='PAIRED_DIFFERENCE' or row['metric'] in ('Youden','RiskDifference24')
                    require(math.isfinite(value) and (-1-1e-12 if signed else -1e-12)<=value<=1+1e-12,'INVALID_CLASSIFICATION_VALUE')
                else:
                    require(row['status']=='NOT_ESTIMABLE' and row['value']=='','INVALID_STATISTICAL_STATE')
        elif name == 'cox':
            require(len(rows)==19 and all(int(r['m'])==20 and math.isfinite(float(r['hr'])) and float(r['se'])>=0 for r in rows),
                    'COX_M20_REPORT_INCOMPLETE')
        elif name == 'groups':
            require(len(rows)==4 and all(sum(int(r['n']) for r in rows if r['branch']==b)==2124 for b in ('FIXED146','ROC_ORIGINAL')),
                    'GROUP_REPORT_POPULATION')
        files[path.relative_to(output).as_posix()] = {"pin": pin(path), "stat": stat_id(path)}
    return acceptance, files


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("input-state", "roc-layer", "roc-summary", "output"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--rscript", default=RSCRIPT_EXECUTABLE)
    parser.add_argument("--environment-receipt",type=Path)
    parser.add_argument("--workers", type=int, default=None)
    parser.add_argument("--prepare-only", action="store_true")
    parser.add_argument("--admit-only", action="store_true")
    args = parser.parse_args()
    os.umask(0o077)
    output = args.output.absolute()
    output.mkdir(parents=True, exist_ok=True)
    require(not output.is_symlink() and output.resolve() == output, "OUTPUT_PATH_ALIAS")
    for name in ("numerical", "receipts", "requests", "logs"):
        (output / name).mkdir(exist_ok=True)
    # Existing independent appendage convention: one kernel owner, same inode.
    with (output / ".compute.lock").open("a+") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        attempt = uuid.uuid4().hex
        write_json(output / "owner.json", {"pid": os.getpid(), "pgid": os.getpgrp(),
            "attempt_id": attempt, "source": str(ROOT), "status": "QUALIFYING"})
        config = read_json(CONFIG)
        paths = {"input_state": args.input_state.resolve(), "roc_layer": args.roc_layer.resolve(),
                 "roc_summary": args.roc_summary.resolve(), "config": CONFIG, "kernel": KERNEL,
                 "orchestrator":Path(__file__).resolve(), "runtime":ROOT/'padml/runtime.py'}
        if args.environment_receipt:
            environment = args.environment_receipt.resolve()
            require(read_json(environment).get('status')=='PASS','INSTALLED_ENVIRONMENT_NOT_QUALIFIED')
            paths.update(environment_receipt=environment,rscript=Path(args.rscript).resolve())
        identity, records = qualify(paths, config, output)
        base = {k: str(v) for k, v in paths.items() if k != "kernel"}
        base.update(identity=identity, output=str(output), rscript=args.rscript, attempt_id=attempt,source_records=records)
        # First record the owner before native imports/qualification work.
        write_json(output / "owner.json", {"pid": os.getpid(), "pgid": os.getpgrp(), "identity": identity,
            "source": str(ROOT), "attempt_id": attempt, "status": "RUNNING"})
        fcntl.flock(lock, fcntl.LOCK_SH)
        resources = observe_execution_resources(output)
        policy = {"configured_worker_ceiling": CPU_MINUS_8, "memory_bytes_per_worker": GIB,
                  "scratch_bytes_per_worker": 32 * 1024**2, "memory_reserve_bytes": 8 * GIB,
                  "scratch_reserve_bytes": 0, "transfer_archive_worker_ceiling": resources["effective_cpus"]}
        def serial(mode):
            task = {**base,'mode':mode,'id':mode}
            if not retained_receipt(output/'receipts'/(mode+'.json'),identity,outputs_for(task,output)):
                admit_stage(policy,output,legal_tasks=1,retained_bytes=32*1024**2,
                            publication_bytes=64*1024**2,transient_bytes_per_worker=32*1024**2,
                            memory_bytes_per_worker=GIB)
            return run_task(task)
        serial('prepare')
        prepared_receipt = retained_receipt(output/'receipts/prepare.json',identity,outputs_for({'mode':'prepare'},output))
        base['source_records'] = {**records, **{path:{'path':path,**v} for path,v in prepared_receipt['outputs'].items()}}
        prepared = read_json(output / "prepared.json")
        require(prepared["identity"] == identity and prepared["logical_fit_n"] == 141, "PREPARED_SCOPE_DRIFT")
        if args.prepare_only:
            write_json(output / "owner.json", {"pid": os.getpid(), "identity": identity, "status": "RETURNED_PREPARED"})
            print(json.dumps({"identity": identity, "unique_cox_fits": prepared["physical_fit_n"], "prepared": True}))
            return
        require(args.workers is None or 1 <= args.workers <= resources["effective_cpus"] - 8,
                "WORKERS_EXCEED_C_MINUS_8")
        if args.admit_only:
            admission = admit_stage(policy, output, legal_tasks=prepared["physical_fit_n"]+100,
                retained_bytes=128*1024**2, publication_bytes=64*1024**2,
                transient_bytes_per_worker=32*1024**2, memory_bytes_per_worker=2*GIB)
            write_json(output/"admission.json", admission)
            write_json(output/"owner.json", {"pid":os.getpid(),"identity":identity,"status":"RETURNED_ADMITTED"})
            print(json.dumps(admission)); return
        completion_path = output / "completion.json"
        if completion_path.exists():
            old = read_json(completion_path)
            require(old["identity"] == identity and old['status']=='COMPLETED' and old['direct_consumer_completed'], "COMPLETION_IDENTITY_DRIFT")
            receipt = retained_receipt(output/'receipts/reduce.json',identity,outputs_for({'mode':'reduce'},output))
            require(receipt is not None and receipt['outputs'][str(output/'acceptance.json')]['pin']==old['acceptance'],
                    'COMPLETED_ACCEPTANCE_DRIFT')
            require(len(old.get('numerical_members',{}))==1001+prepared['physical_fit_n'],'COMPLETED_NUMERICAL_CLOSURE_MISSING')
            for rel,saved in old['numerical_members'].items():
                p=output/rel
                if saved['stat'] != stat_id(p):
                    require(pin(p)==saved['pin'],'COMPLETED_NUMERICAL_DRIFT')
            for rel, saved in old["tables"].items():
                p = output / rel
                if saved["stat"] != stat_id(p):
                    require(pin(p) == saved["pin"], "COMPLETED_REPORT_DRIFT")
            write_json(output/"owner.json", {"pid":os.getpid(),"identity":identity,"status":"RETURNED","attempt_id":attempt})
            print(json.dumps({"status": "COMPLETED", "reused": True, "identity": identity})); return
        serial('point')
        tasks = [{**base, "mode": "cox", "id": spec["task"], "spec": spec} for spec in prepared["tasks"]]
        tasks += [{**base, "mode": "bootstrap", "id": f"batch-{b:04d}",
                   "indices": list(range(b, min(b+config["batch_size"], 1001)))}
                  for b in range(1, 1001, config["batch_size"])]
        pending = [t for t in tasks if retained_receipt(output/"receipts"/(t["id"]+".json"), identity, outputs_for(t,output)) is None]
        report = {}; started = time.monotonic()
        if pending:
            _ready_ordered(run_task, pending, policy=policy, root=output,
                retained_bytes_per_task=1024**2, transient_bytes_per_worker=32*1024**2,
                publication_bytes=64*1024**2, memory_bytes_per_worker=2*GIB,
                selected_slots=args.workers, execution_report=report, task_timeout_seconds=3600)
        reduction_sources = dict(base['source_records'])
        for task in [*tasks,{**base,'mode':'point','id':'point'}]:
            receipt = retained_receipt(output/'receipts'/(task['id']+'.json'),identity,outputs_for(task,output))
            require(receipt is not None,'REDUCTION_SOURCE_NOT_PUBLISHED')
            reduction_sources.update({path:{'path':path,**v} for path,v in receipt['outputs'].items()})
        base['source_records'] = reduction_sources
        serial('reduce')
        acceptance, tables = validate_report(output, identity, prepared)
        require(all(stat_id(Path(v["path"])) == v["stat"] for v in records.values()), "SOURCE_DRIFT_DURING_COMPUTE")
        completion = {"identity": identity, "status": "COMPLETED", "direct_consumer_completed": True,
            "source": str(ROOT), "tables": tables, "acceptance": pin(output/"acceptance.json"),
            "source_qualification": records, "executed_pending_tasks":len(pending),
            "numerical_members":{Path(p).relative_to(output).as_posix():{'stat':v['stat'],'pin':v['pin']}
                for p,v in reduction_sources.items() if Path(p).parent==output/'numerical' or Path(p)==output/'point.rds'},
            "seconds": time.monotonic()-started, "resources":resources, "pool":report,
            "summary":acceptance}
        write_json(completion_path, completion)
        write_json(output/"owner.json", {"pid":os.getpid(),"identity":identity,"status":"RETURNED"})
        print(json.dumps({"status":"COMPLETED","identity":identity,"unique_cox_fits":prepared["physical_fit_n"],"bootstrap":1000}))


if __name__ == "__main__":
    main()
