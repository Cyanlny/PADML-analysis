"""PADML fully nested leave-one-center-out development program."""

__all__ = ["__version__"]
__version__ = "2.0.0"
