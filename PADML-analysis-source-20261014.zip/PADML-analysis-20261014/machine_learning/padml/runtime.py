from __future__ import annotations

import gc
import math
import os
import shutil
import signal
import stat
import sys
import weakref
from collections import OrderedDict
from multiprocessing import get_context
from multiprocessing.connection import wait as wait_connections
from pathlib import Path
from time import monotonic, monotonic_ns
from threading import Lock
from typing import Any, Callable, Mapping, Sequence, TypeVar

from .bundle import ContractError, canonical_json_bytes, sha256_bytes, strict_json_bytes


REMOTE_ROOT = Path("/root/autodl-tmp/PADML_V22")
DEPENDENCY_ROOT_ID = "4dd533d039544c2ee887945b8ff66f82d8aa18a9086257f4c1aa09b1507a6376"
DEPENDENCY_ROOT = REMOTE_ROOT / "runtime/dependencies" / DEPENDENCY_ROOT_ID
SEALED_PYTHON_EXECUTABLE = str(DEPENDENCY_ROOT / "py-env/bin/python")
PYTHON_EXECUTABLE = os.environ.get("PADML_PYTHON", SEALED_PYTHON_EXECUTABLE)
SEALED_RSCRIPT_EXECUTABLE = str(DEPENDENCY_ROOT / "r-env/bin/Rscript")
_SEALED_RSCRIPT_EXECUTABLE = Path(SEALED_RSCRIPT_EXECUTABLE)
RSCRIPT_EXECUTABLE = os.environ.get("PADML_RSCRIPT") or (
    str(_SEALED_RSCRIPT_EXECUTABLE)
    if _SEALED_RSCRIPT_EXECUTABLE.is_file()
    else shutil.which("Rscript") or str(_SEALED_RSCRIPT_EXECUTABLE)
)
R_LIBRARY_BASE = str(DEPENDENCY_ROOT / "r-library")
R_LIBRARY_OVERLAY = str(DEPENDENCY_ROOT / "r-selector-overlay")
MRMRE_SOURCE_ID = "34ad7860a048eb016e2e8b9d25c3628987f6a02a55a6e6d4bad7cdfb956e92e5"
R_MRMRE_CORRECTION = str(REMOTE_ROOT / "runtime/dependencies" / MRMRE_SOURCE_ID / "r-mrmre-correction")
GBM_SOURCE_ID = "618c8b73ffb2ebf8ef9df1408620ea1af177c73466067d5254dff4216448bfe8"
R_GBM_CORRECTION = str(REMOTE_ROOT / "runtime/dependencies" / GBM_SOURCE_ID / "r-gbm-correction")
FPM_SOURCE_ID = "8c6abc9249e45b897bd553094cd7e5ff4f387254611409332cc1715a194cba3e"
R_FPM_CORRECTION = str(REMOTE_ROOT / "runtime/dependencies" / FPM_SOURCE_ID / "r-fpm-correction")
R_LIBRARY = os.environ.get("PADML_R_LIBRARY") or f"{R_FPM_CORRECTION}:{R_MRMRE_CORRECTION}:{R_GBM_CORRECTION}:{R_LIBRARY_OVERLAY}:{R_LIBRARY_BASE}"
THREAD_ENV = {
    "OMP_NUM_THREADS": "1",
    "OPENBLAS_NUM_THREADS": "1",
    "MKL_NUM_THREADS": "1",
    "VECLIB_MAXIMUM_THREADS": "1",
    "NUMEXPR_NUM_THREADS": "1",
}
THREAD_POLICY_IDENTITY = sha256_bytes(canonical_json_bytes(THREAD_ENV))
OPERATIONAL_IDENTITY = sha256_bytes(
    canonical_json_bytes(
        {
            "dependency_root_id": DEPENDENCY_ROOT_ID,
            "remote_root": str(REMOTE_ROOT),
            "r_library": R_LIBRARY,
            "threads": THREAD_ENV,
        }
    )
)
REMOTE_ENV = {**THREAD_ENV,
    "PYTHONDONTWRITEBYTECODE": "" if os.environ.get("PYTHONPYCACHEPREFIX") else "1",
    "R_LIBS_USER": R_LIBRARY}


RESOURCE_POLICY_FIELDS = {
    "configured_worker_ceiling",
    "memory_bytes_per_worker",
    "scratch_bytes_per_worker",
    "memory_reserve_bytes",
    "scratch_reserve_bytes",
    "transfer_archive_worker_ceiling",
}
CPU_MINUS_8 = "EXECUTION_HOST_C_MINUS_8"
MIN_WORKER_MEMORY_BYTES = 1024**3
# Readers preserve the recorded budget of qualified pre-revision results.
RECORDED_WORKER_MEMORY_BYTES = (MIN_WORKER_MEMORY_BYTES, 2 * 1024**3)
RESOURCE_OBSERVATION_FIELDS = {
    "effective_cpus",
    "available_memory_bytes",
    "scratch_available_bytes",
    "scratch_root",
}


def _require(condition: bool, reason: str) -> None:
    if not condition:
        raise ContractError(reason)


def validate_resource_policy(value: Any) -> dict[str, Any]:
    """New F4/F5 estimates: defer CPU geometry to the execution host.

    Historical F1/F2 execution profiles do not use this resource policy and
    remain read-only. Transfer capacity is a physical admission estimate, not
    a second software CPU ceiling.
    """
    _require(
        isinstance(value, Mapping) and set(value) == RESOURCE_POLICY_FIELDS,
        "RESOURCE_POLICY_INVALID",
    )
    row = dict(value)
    _require(
        row["configured_worker_ceiling"] == CPU_MINUS_8
        and all(type(row[name]) is int and row[name] >= 0
                for name in row if name != "configured_worker_ceiling")
        and row["memory_bytes_per_worker"] >= 1
        and row["scratch_bytes_per_worker"] >= 1
        and row["transfer_archive_worker_ceiling"] >= 1,
        "RESOURCE_POLICY_INVALID",
    )
    return row


def _available_memory_bytes() -> int:
    """Return live host/cgroup headroom, never total RAM or an inferred default."""
    try:
        if sys.platform == "linux":
            values: dict[str, int] = {}
            for line in Path("/proc/meminfo").read_text().splitlines():
                name, raw = line.split(":", 1)
                fields = raw.split()
                if name in {"MemAvailable", "MemFree"}:
                    _require(
                        len(fields) == 2 and fields[1] == "kB",
                        "MEMORY_RESOURCE_UNDETERMINED",
                    )
                    values[name] = int(fields[0]) * 1024
            value = values.get("MemAvailable")
            _require(
                type(value) is int and value > 0,
                "MEMORY_RESOURCE_UNDETERMINED",
            )
            headroom = min([value, *_cgroup_memory_headrooms()])
            _require(headroom > 0, "MEMORY_RESOURCE_EXHAUSTED")
            return headroom
        # macOS has no stable stdlib API for *available* memory.  Total pages
        # would over-admit, so production admission remains Linux-only.
        raise ContractError("MEMORY_RESOURCE_UNDETERMINED")
    except (OSError, ValueError, IndexError) as error:
        raise ContractError("MEMORY_RESOURCE_UNDETERMINED") from error


def _cgroup_memory_headrooms(observations: list[dict[str, Any]] | None = None) -> list[int]:
    """Apply every visible ancestor's RAM cap and measured reclaimable cache.

    MemAvailable is host-wide even inside many containers.  The parent's
    usage includes siblings; subtracting only this process/leaf usage would
    over-admit workers.  Swap is not RAM and never augments the budget.
    """
    mounts = []
    for line in Path("/proc/self/mountinfo").read_text().splitlines():
        left, right = line.split(" - ", 1)
        fields, filesystem = left.split(), right.split()
        if filesystem[0] in {"cgroup", "cgroup2"}:
            mounts.append((filesystem[0], Path(fields[3]), Path(fields[4]),
                           set(filesystem[2].split(","))))
    headrooms = []
    controller_seen = False
    v1_seen = False
    unmounted_unified = False
    for line in Path("/proc/self/cgroup").read_text().splitlines():
        hierarchy, raw_controllers, raw_path = line.split(":", 2)
        controllers = set(raw_controllers.split(","))
        unified = controllers == {""}
        if not unified and "memory" not in controllers:
            continue
        group = Path(raw_path)
        _require(group.is_absolute() and ".." not in group.parts,
                 "MEMORY_RESOURCE_CGROUP_PATH_INVALID")
        if unified and hierarchy == "0" and not any(row[0] == "cgroup2" for row in mounts):
            unmounted_unified = True
            continue
        matches = [row for row in mounts
                   if row[0] == ("cgroup2" if unified else "cgroup")
                   and (unified or controllers <= row[3])
                   and group.is_relative_to(row[1])]
        _require(bool(matches), "MEMORY_RESOURCE_CGROUP_MOUNT_MISSING")
        _, root, mount, _ = max(matches, key=lambda row: len(row[1].parts))
        current = mount / group.relative_to(root)
        while True:
            limit_path = current / ("memory.max" if unified else "memory.limit_in_bytes")
            usage_path = current / ("memory.current" if unified else "memory.usage_in_bytes")
            record = {"path": str(current), "version": 2 if unified else 1,
                      "total_bytes": None, "limit_bytes": None, "anon_bytes": None,
                      "file_bytes": None, "stat_keys": ["anon", "file"] if unified else
                      ["total_rss", "total_cache"], "stat_status": "UNKNOWN"}
            if observations is not None:
                observations.append(record)
            if limit_path.exists() or usage_path.exists():
                # The cgroup2 root has no memory.max.  All non-root groups
                # must expose both fields if memory accounting is enabled.
                has_limit = limit_path.is_file()
                _require(usage_path.is_file() and (
                    has_limit or unified and current == mount and root == Path("/")
                ), "MEMORY_RESOURCE_CGROUP_LIMIT_MISSING")
                usage = int(usage_path.read_text().strip())
                _require(usage >= 0, "MEMORY_RESOURCE_CGROUP_USAGE_INVALID")
                record["total_bytes"] = usage
                if has_limit:
                    raw_limit = limit_path.read_text().strip()
                    if not (unified and raw_limit == "max"):
                        limit = int(raw_limit)
                        _require(limit >= 0, "MEMORY_RESOURCE_CGROUP_LIMIT_INVALID")
                        record["limit_bytes"] = limit
                        # Only observed clean inactive file pages can be reclaimed.
                        # Missing counters grant no credit; never count anon, active
                        # file, shmem, slab or swap as additional worker capacity.
                        cache_keys = ("inactive_file", "file", "shmem", "file_dirty", "file_writeback") if unified else (
                            "total_inactive_file", "total_cache", "total_shmem", "total_dirty", "total_writeback")
                        credit = 0
                        try:
                            cache = {}
                            with (current / "memory.stat").open() as stream:
                                for row in stream:
                                    fields = row.split()
                                    if fields and fields[0] in cache_keys:
                                        _require(len(fields) == 2 and fields[0] not in cache,
                                                 "MEMORY_STAT_INVALID")
                                        value = int(fields[1])
                                        _require(value >= 0, "MEMORY_STAT_INVALID")
                                        cache[fields[0]] = value
                            _require(set(cache) == set(cache_keys), "MEMORY_STAT_INVALID")
                            inactive, file, shmem, dirty, writeback = (cache[key] for key in cache_keys)
                            credit = max(0, min(inactive, max(0, file - shmem)) - dirty - writeback)
                        except (OSError, ValueError, ContractError):
                            pass
                        headrooms.append(max(0, limit - max(0, usage - min(usage, credit))))
                controller_seen = True
                v1_seen = v1_seen or not unified
            else:
                _require(unified, "MEMORY_RESOURCE_CGROUP_LIMIT_MISSING")
            if observations is not None:
                try:
                    values = {}
                    with (current / "memory.stat").open() as stream:
                        for row in stream:
                            fields = row.split()
                            if fields and fields[0] in record["stat_keys"]:
                                _require(len(fields) == 2 and fields[0] not in values,
                                         "MEMORY_STAT_INVALID")
                                value = int(fields[1])
                                _require(value >= 0, "MEMORY_STAT_INVALID")
                                values[fields[0]] = value
                    _require(set(values) == set(record["stat_keys"]), "MEMORY_STAT_INVALID")
                    record.update(anon_bytes=values[record["stat_keys"][0]],
                                  file_bytes=values[record["stat_keys"][1]], stat_status="OBSERVED")
                except (OSError, ValueError, ContractError):
                    # Diagnostic absence never changes valid RAM admission.
                    pass
            if current == mount:
                break
            current = current.parent
    _require(not unmounted_unified or v1_seen, "MEMORY_RESOURCE_CGROUP_MOUNT_MISSING")
    _require(controller_seen, "MEMORY_RESOURCE_UNDETERMINED")
    # With an explicitly unlimited hierarchy, MemAvailable is the only cap.
    return headrooms


def observe_step_memory(*, detailed=True) -> dict[str, Any]:
    """Current PID RSS and visible ancestor counters, not an atomic snapshot.

    Ancestors include sibling usage. v1 total_rss/total_cache retain their
    native meanings; they are not process RSS or exactly v2 anon/file.
    Linux maxrss is a lifetime high-water mark, not a sampled peak, a task
    delta or a live process-tree/cgroup total. CHILDREN covers only children
    already reaped by their original owner. No extra waiter is introduced.
    These diagnostics never increase the original RAM headroom.
    """
    result = {"pid": os.getpid(), "started_ns": monotonic_ns(), "finished_ns": None,
              "clock": "MONOTONIC_NS",
              "rss_bytes": None, "rss_source": "/proc/self/smaps_rollup:Rss",
              "cgroup_status": "UNKNOWN", "cgroups": [],
              "lifetime_maxrss": {"status": "UNKNOWN", "source": "LINUX_GETRUSAGE",
                  "unit": "BYTES", "scope": "LIFETIME_SELF_AND_MAX_REAPED_CHILD",
                  "process_start_ticks": None, "self_bytes": None, "children_bytes": None}}
    if sys.platform == "linux" and detailed:
        try:
            import resource
            # comm may contain both spaces and parentheses; starttime is
            # field 22, hence index 19 after the closing comm delimiter.
            prefix, delimiter, tail = Path("/proc/self/stat").read_text().rpartition(") ")
            pid, opening, _comm = prefix.partition(" (")
            fields = tail.split()
            _require(delimiter and opening and int(pid) == result["pid"]
                     and len(fields) >= 20 and fields[19].isascii() and fields[19].isdecimal(),
                     "MEMORY_PROCESS_START_INVALID")
            start_ticks = int(fields[19])
            own = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
            children = resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss
            _require(start_ticks > 0 and type(own) is int and own > 0
                     and type(children) is int and children >= 0, "MEMORY_MAXRSS_INVALID")
            result["lifetime_maxrss"].update(status="OBSERVED", process_start_ticks=start_ticks,
                self_bytes=own * 1024, children_bytes=children * 1024)
        except (ImportError, OSError, ValueError, IndexError, ContractError):
            pass
        try:
            rows = [line.split() for line in Path("/proc/self/smaps_rollup").read_text().splitlines()
                    if line.startswith("Rss:")]
            _require(len(rows) == 1 and len(rows[0]) == 3 and rows[0][2] == "kB",
                     "MEMORY_RSS_INVALID")
            value = int(rows[0][1]) * 1024
            _require(value >= 0, "MEMORY_RSS_INVALID")
            result["rss_bytes"] = value
        except (OSError, ValueError, ContractError):
            pass
        try:
            _cgroup_memory_headrooms(result["cgroups"])
            result["cgroup_status"] = "OBSERVED"
        except (OSError, ValueError, IndexError, ContractError):
            pass
    result["finished_ns"] = monotonic_ns()
    return result


def _visible_open_file_keys(candidates: set[tuple[int, int]]) -> tuple[set[tuple[int, int]], int]:
    for attempt in range(2):
        try:
            return _scan_visible_open_file_keys(candidates)
        except PermissionError as error:
            if attempt or not getattr(error, "process_incarnation_ended", False):
                raise
    raise AssertionError("unreachable")


def _scan_visible_open_file_keys(candidates: set[tuple[int, int]]) -> tuple[set[tuple[int, int]], int]:
    """Include mmap after fd close; unknown process visibility forbids advice.

    Callers must also prove exclusive completed-step ownership: this scan
    alone cannot establish last use, prevent later opens, or see host PIDs
    hidden by a namespace. No descriptor owned by another scope is closed.
    """
    keys, count = set(), 0
    if not candidates:
        return keys, count
    for process in Path("/proc").iterdir():
        if not process.name.isdecimal():
            continue
        incarnation = None
        try:
            incarnation = (process / "stat").read_text().split(") ", 1)[1].split()[19]
            with os.scandir(process / "fd") as descriptors:
                for fd in descriptors:
                    try:
                        value = fd.stat()
                    except FileNotFoundError:
                        continue  # fd closed, not a guessed inaccessible owner
                    key = (value.st_dev, value.st_ino)
                    if stat.S_ISREG(value.st_mode) and key in candidates:
                        keys.add(key)
            with (process / "maps").open() as mappings:
                for line in mappings:
                    fields = line.split(maxsplit=5)
                    device, inode = fields[3], int(fields[4])
                    if inode:
                        major, minor = (int(part, 16) for part in device.split(":"))
                        key = (os.makedev(major, minor), inode)
                        if key in candidates:
                            keys.add(key)
            count += 1
        except FileNotFoundError as error:
            if process.exists():
                error.add_note(f"RESOURCE_READER_SCAN_PROCESS:{process};completed_processes:{count}")
                raise
        except (OSError, ValueError, IndexError) as error:
            if isinstance(error, PermissionError) and incarnation is not None:
                try:
                    now = (process / "stat").read_text().split(") ", 1)[1].split()[19]
                    error.process_incarnation_ended = now != incarnation
                except FileNotFoundError:
                    error.process_incarnation_ended = not process.exists()
                except (OSError, ValueError, IndexError):
                    pass
            error.add_note(f"RESOURCE_READER_SCAN_PROCESS:{process};completed_processes:{count}")
            raise
    return keys, count


_COMPLETED_CACHE_FILES = set()
_COMPLETED_CACHE_LOCK = Lock()
_COMPLETED_CACHE_ROOT = None  # Set only by the registered whole-unit owner.
_CACHE_DONE = OrderedDict()
_CACHE_PENDING = OrderedDict()
_CACHE_MAPPINGS = {}
_CACHE_PENDING_LIMIT = 512
_CACHE_PENDING_BYTES = 8 * 1024**3
_CACHE_PENDING_SECONDS = 300


def _cache_stamp(value):
    return (value.st_dev, value.st_ino, value.st_size, value.st_mtime_ns, value.st_ctime_ns)


def mark_cache_use(files):
    """A real reopen/native invocation invalidates advice even if bytes are unchanged."""
    with _COMPLETED_CACHE_LOCK:
        for supplied in files:
            try:
                value = Path(supplied).lstat()
            except OSError:
                continue
            key = (value.st_dev, value.st_ino)
            _CACHE_DONE.pop(key, None)
            prior = _CACHE_PENDING.pop(key, None)
            if prior is not None: _COMPLETED_CACHE_FILES.discard(prior['path'])


def track_cache_mapping(array, path):
    """Observe the backing mmap, which outlives all NumPy slices; never close it."""
    backing = getattr(array, '_mmap', None)
    if backing is None:
        return
    path = Path(path)
    value = path.stat()
    key = (value.st_dev, value.st_ino)
    with _COMPLETED_CACHE_LOCK:
        live = [ref for ref in _CACHE_MAPPINGS.get(key, ()) if ref() is not None]
        if not any(ref() is backing for ref in live):
            # The weak callback only queues a bounded hint. It cannot close a
            # mapping, and actual advice occurs after the destructor returns.
            live.append(weakref.ref(backing, lambda _: _cache_mapping_closed(key, path)))
        _CACHE_MAPPINGS[key] = live
        _CACHE_DONE.pop(key, None)


def _cache_mapping_closed(key, path):
    with _COMPLETED_CACHE_LOCK:
        live = _cache_has_mapping(key)
    if not live:
        _record_completed_cache_file(path)


def _cache_has_mapping(key):
    live = [ref for ref in _CACHE_MAPPINGS.get(key, ()) if ref() is not None]
    if live:
        _CACHE_MAPPINGS[key] = live
    else:
        _CACHE_MAPPINGS.pop(key, None)
    return bool(live)


def _cache_result(path, value, status, *, sync, ranges=None, initial_ranges=False):
    key, stamp, now = (value.st_dev, value.st_ino), _cache_stamp(value), monotonic()
    with _COMPLETED_CACHE_LOCK:
        prior = _CACHE_PENDING.pop(key, None)
        if prior is not None:
            _COMPLETED_CACHE_FILES.discard(prior['path'])
        attempts = (prior['attempts'] if prior and prior['stamp'] == stamp else 0)
        if initial_ranges:
            # A stream can consume several disjoint/rolling ranges before its
            # first retry. Those initial hints are one attempt per range.
            attempts = max(1, attempts)
            if prior and prior['stamp'] == stamp and prior['ranges']:
                combined = []
                for start, end in sorted([*prior['ranges'], *ranges]):
                    if combined and start <= combined[-1][1]:
                        combined[-1] = (combined[-1][0], max(end, combined[-1][1]))
                    else:
                        combined.append((start, end))
                ranges = combined[-128:]
        elif status != 'DEFERRED':
            attempts += 1
        if status in {'ADVISED', 'UNSUPPORTED', 'EXPIRED'} or attempts >= 2:
            _CACHE_DONE[key] = (stamp, status)
            _CACHE_DONE.move_to_end(key)
            while len(_CACHE_DONE) > 4096:
                _CACHE_DONE.popitem(last=False)
            return
        _CACHE_PENDING[key] = dict(path=path, stamp=stamp, sync=sync,
            ranges=ranges, attempts=attempts, started=prior['started'] if prior else now)
        if _COMPLETED_CACHE_ROOT is not None and path.is_relative_to(_COMPLETED_CACHE_ROOT):
            _COMPLETED_CACHE_FILES.add(path)
        total = sum(row['stamp'][2] for row in _CACHE_PENDING.values())
        for old_key, row in list(_CACHE_PENDING.items()):
            if now-row['started'] > _CACHE_PENDING_SECONDS:
                _CACHE_PENDING.pop(old_key)
                _COMPLETED_CACHE_FILES.discard(row['path'])
                total -= row['stamp'][2]
        while _CACHE_PENDING and (len(_CACHE_PENDING) > _CACHE_PENDING_LIMIT
                or total > _CACHE_PENDING_BYTES
                ):
            _, row = _CACHE_PENDING.popitem(last=False)
            total -= row['stamp'][2]
            _COMPLETED_CACHE_FILES.discard(row['path'])


def drain_completed_io():
    """Retry only the bounded unfinished hints; successes are no longer pending."""
    with _COMPLETED_CACHE_LOCK:
        now = monotonic()
        for key, row in list(_CACHE_PENDING.items()):
            if now-row['started'] > _CACHE_PENDING_SECONDS:
                _CACHE_PENDING.pop(key)
                _COMPLETED_CACHE_FILES.discard(row['path'])
        files = [row['path'] for row in _CACHE_PENDING.values()]
    return advise_completed_io(files, new_consumption=False)


def _cache_path_unavailable(path):
    with _COMPLETED_CACHE_LOCK:
        for key, row in list(_CACHE_PENDING.items()):
            if row['path'] == path:
                _CACHE_PENDING.pop(key)
                _COMPLETED_CACHE_FILES.discard(path)


def _record_completed_cache_file(path):
    # Kept for original stage callers: an unconsumed/pending hint is bounded.
    try:
        _cache_result(path, path.stat(), 'DEFERRED', sync=False)
    except OSError:
        pass


def advise_consumed_stream(stream, *, offset=0, length=0, sync=False):
    """Cache advice for an already consumed range; never deletion or a gate."""
    if not hasattr(os, 'posix_fadvise') or not hasattr(os, 'POSIX_FADV_DONTNEED'):
        return 'UNSUPPORTED'
    try:
        fd = stream.fileno()
        if sync:
            stream.flush()
            os.fsync(fd)
        os.posix_fadvise(fd, offset, length, os.POSIX_FADV_DONTNEED)
        return 'ADVISED'
    except (OSError, ValueError):
        return 'UNKNOWN'


def advise_completed_io(files, *, sync=True, minimum_bytes=0, new_consumption=True):
    """Drain paths already held by the consumer, without readers/SHA/tree scans.

    Call after native children and mappings close. Retained disk entities and
    scientific pins are untouched. Keep only failed/deferred hints for the tail;
    callers keep compact counts, never another per-file diagnostic archive.
    """
    summary = dict(attempted_files=0, attempted_bytes=0, advised_files=0,
        advised_bytes=0, skipped_files=0, failed_files=0, unsupported_files=0)
    seen = set()
    for supplied in files:
        path = Path(supplied)
        try:
            value = path.lstat()
            if not path.is_absolute() or not stat.S_ISREG(value.st_mode):
                summary['skipped_files'] += 1
                continue
            if value.st_size < minimum_bytes:
                continue
            key = (value.st_dev, value.st_ino)
            if key in seen:
                continue
            seen.add(key)
            with _COMPLETED_CACHE_LOCK:
                if new_consumption:
                    _CACHE_DONE.pop(key, None)
                    prior = _CACHE_PENDING.pop(key, None)
                    if prior is not None: _COMPLETED_CACHE_FILES.discard(prior['path'])
                prior = _CACHE_PENDING.get(key)
                if not new_consumption and key in _CACHE_DONE and _CACHE_DONE[key][0] == _cache_stamp(value):
                    summary['skipped_files'] += 1
                    continue
                mapped = _cache_has_mapping(key)
            if prior and monotonic()-prior['started'] > _CACHE_PENDING_SECONDS:
                _cache_result(path, value, 'EXPIRED', sync=False)
                summary['skipped_files'] += 1
                continue
            if mapped:
                _cache_result(path, value, 'DEFERRED', sync=sync)
                summary['skipped_files'] += 1
                continue
            summary['attempted_files'] += 1
            summary['attempted_bytes'] += value.st_size
            fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
            with os.fdopen(fd, 'rb') as stream:
                current = os.fstat(stream.fileno())
                if (current.st_dev, current.st_ino) != key:
                    summary['failed_files'] += 1
                    continue
                ranges = prior['ranges'] if prior and prior['stamp'] == _cache_stamp(value) else None
                required_sync = prior['sync'] if prior else sync
                if ranges:
                    statuses = [advise_consumed_stream(stream, offset=start, length=end-start)
                        for start, end in ranges]
                    status = 'ADVISED' if all(s == 'ADVISED' for s in statuses) else statuses[0]
                    if any(s == 'UNKNOWN' for s in statuses): status = 'UNKNOWN'
                else:
                    status = advise_consumed_stream(stream, sync=required_sync)
            _cache_result(path, value, status, sync=required_sync, ranges=ranges)
            if status == 'ADVISED':
                summary['advised_files'] += 1
                summary['advised_bytes'] += value.st_size
            else:
                summary['unsupported_files' if status == 'UNSUPPORTED' else 'failed_files'] += 1
        except FileNotFoundError:
            _cache_path_unavailable(path)
            summary['skipped_files'] += 1
        except OSError:
            _cache_path_unavailable(path)
            summary['failed_files'] += 1
    return summary


class ConsumedStream:
    """Own one read handle and advise only ranges actually read, including errors.

    Rolling mode bounds long transfers. ZIP handles defer advice until the last
    ZipExtFile releases their shared physical handle. Neither mode writes/syncs.
    """
    def __init__(self, stream, *, rolling=False):
        self.stream, self.rolling, self.ranges = stream, rolling, []
        self.path = Path(stream.name) if isinstance(getattr(stream, 'name', None), (str, Path)) else None
        self.closed = False
        self.extent, self.advice_status = 0, 'ADVISED'
        self.page = os.sysconf('SC_PAGE_SIZE')
        self.limited = False
        if self.path is not None: mark_cache_use([self.path])

    def __getattr__(self, name):
        return getattr(self.stream, name)

    def _read(self, method, *args):
        start = self.stream.tell()
        answer = getattr(self.stream, method)(*args)
        end = self.stream.tell()
        if end > start:
            if start <= self.extent: self.extent = max(self.extent, end)
            ranges = sorted([*self.ranges, (start, end)])
            self.ranges = []
            for left, right in ranges:
                if self.ranges and left <= self.ranges[-1][1]:
                    self.ranges[-1] = (self.ranges[-1][0], max(right, self.ranges[-1][1]))
                else:
                    self.ranges.append((left, right))
            if self.rolling:
                self._drain(tail=False)
            # Bounded advice state, not a history of every tiny seek/read.
            if len(self.ranges) > 128:
                if self.rolling:
                    self._drain(tail=True)
                else:
                    self.ranges = self.ranges[-128:]
                    self.limited = True
        return answer

    def read(self, *args): return self._read('read', *args)
    def read1(self, *args): return self._read('read1', *args)
    def readline(self, *args): return self._read('readline', *args)
    def readinto(self, *args): return self._read('readinto', *args)
    def __iter__(self): return self
    def __next__(self):
        row = self.readline()
        if not row: raise StopIteration
        return row

    def _drain(self, *, tail):
        remaining, failed = [], []
        page = self.page
        for start, end in self.ranges:
            stop = end if tail else end // page * page
            if stop <= start or not tail and stop-start < 8*1024**2:
                remaining.append((start, end)); continue
            status = advise_consumed_stream(self.stream, offset=start, length=stop-start)
            if status != 'ADVISED': self.advice_status = status
            if status == 'UNKNOWN' and self.path is not None:
                failed.append((start, stop))
            if stop < end: remaining.append((stop, end))
        self.ranges = remaining
        if failed:
            try:
                _cache_result(self.path, os.fstat(self.stream.fileno()), 'UNKNOWN',
                    sync=False, ranges=failed, initial_ranges=True)
            except (OSError, ValueError):
                pass

    def close(self):
        if self.closed: return
        try:
            self._drain(tail=True)
            if self.path is not None:
                try:
                    value = os.fstat(self.stream.fileno())
                    if self.extent >= value.st_size and not self.limited and self.advice_status != 'UNKNOWN':
                        _cache_result(self.path, value, self.advice_status, sync=False)
                except (OSError, ValueError):
                    pass
        finally:
            self.closed = True
            self.stream.close()

    def __enter__(self): return self
    def __exit__(self, kind, error, traceback):
        try: self.close()
        except OSError:
            if error is None: raise


def release_step_resources(files: Sequence[Path], *, owner: str,
                           before: Mapping[str, Any], released_references: Sequence[str],
                           file_aliases: Mapping[Path, Sequence[Path]] | None = None,
                           file_identities: Mapping[Path, tuple] | None = None,
                           force_cache: bool | None = None,
                           sample_memory: bool = True) -> dict[str, Any]:
    """Release file cache; F45 force mode waives reader and ownership checks.

    The caller drops dead references before entry, preserves returned values,
    and has already closed its context-managed handles and waited for owned
    children. Nothing is deleted. fsync precedes DONTNEED; successful advice
    is not proof of cache eviction. Original admission must be observed anew.
    """
    if force_cache is None:
        force_cache = bool(os.environ.get('PADML_F45_RUN_PATH'))
    _require(isinstance(owner, str) and bool(owner) and before.get("pid") == os.getpid()
             and all(isinstance(name, str) and name for name in released_references),
             "RESOURCE_RELEASE_OWNER_INVALID")
    _require(len(set(files)) == len(files), "RESOURCE_RELEASE_FILE_ALIAS")
    report = {"owner": owner, "before": dict(before), "after": None,
              "released_references": list(released_references), "gc_collected": gc.collect(),
              "reader_scan_status": "UNKNOWN", "visible_processes_checked": 0,
              "files": [], "claim": "ADVISORY_ONLY_NONATOMIC_OBSERVATIONS_NOT_ATTRIBUTION"}
    for path in files:
        _require(isinstance(path, Path) and path.is_absolute() and not path.is_symlink()
                 and path.resolve(strict=True) == path, "RESOURCE_RELEASE_PATH_INVALID")
        original = path.stat()
        _require(stat.S_ISREG(original.st_mode),
                 "RESOURCE_RELEASE_FILE_INVALID")
        if not force_cache:
            _check_release_aliases(path, original, file_aliases)
        identity = (original.st_dev, original.st_ino, original.st_size,
                    original.st_mtime_ns, original.st_ctime_ns)
        _require(force_cache or file_identities is None or file_identities.get(path) == identity,
                 "RESOURCE_RELEASE_FILE_CHANGED")
        row = {"path": str(path), "device": identity[0], "inode": identity[1],
               "size_bytes": identity[2], "mtime_ns": identity[3], "ctime_ns": identity[4],
               "status": "UNKNOWN", "error": None}
        report["files"].append(row)
    opened = set()
    if force_cache:
        report["reader_scan_status"] = "WAIVED_BY_USER"
    elif sys.platform == "linux":
        try:
            opened, count = _visible_open_file_keys({(row["device"], row["inode"]) for row in report["files"]})
            report.update(reader_scan_status="OBSERVED", visible_processes_checked=count)
        except (OSError, ValueError, IndexError) as error:
            detail = f"RESOURCE_READER_SCAN_FAILED:{type(error).__name__}:{error}"
            notes = getattr(error, "__notes__", ())
            if notes:
                detail += "\n" + "\n".join(notes)
            for row in report["files"]:
                row["error"] = detail
    for path, row in zip(files, report["files"], strict=True):
        identity = tuple(row[key] for key in ("device", "inode", "size_bytes", "mtime_ns", "ctime_ns"))
        if report["reader_scan_status"] not in {"OBSERVED", "WAIVED_BY_USER"}:
            continue
        if identity[:2] in opened:
            row["status"] = "ACTIVE_READER_OR_WRITER"
            continue
        if force_cache:
            result = advise_completed_io([path], sync=False, new_consumption=False)
            if result['advised_files']:
                row['status'] = 'ADVISED'
            elif result['unsupported_files']:
                row['status'] = 'UNSUPPORTED'
            elif result['skipped_files']:
                row['error'] = 'CACHE_ALREADY_FINISHED_OR_MAPPING_STILL_LIVE'
            else:
                row['error'] = 'RESOURCE_RELEASE_ADVICE_FAILED'
            continue
        if not hasattr(os, "posix_fadvise") or not hasattr(os, "POSIX_FADV_DONTNEED"):
            row["status"] = "UNSUPPORTED"
            continue
        fd = None
        try:
            fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
            current = os.fstat(fd)
            _require(force_cache or (current.st_dev, current.st_ino, current.st_size,
                      current.st_mtime_ns, current.st_ctime_ns) == identity,
                     "RESOURCE_RELEASE_FILE_CHANGED")
            if not force_cache:
                _check_release_aliases(path, current, file_aliases)
            os.fsync(fd)
            try:
                os.posix_fadvise(fd, 0, 0, os.POSIX_FADV_DONTNEED)
            except OSError as error:
                # Advice is not a persistence operation. Keep this distinct
                # from open/fsync/stat failures for direct stage consumers.
                row["error"] = "RESOURCE_RELEASE_ADVICE_FAILED:" + type(error).__name__ + ":" + str(error)
            if not force_cache:
                current = path.stat()
                _require((current.st_dev, current.st_ino, current.st_size,
                          current.st_mtime_ns, current.st_ctime_ns) == identity,
                         "RESOURCE_RELEASE_FILE_CHANGED")
            if row["error"] is None:
                row["status"] = "ADVISED"
        except (OSError, ContractError) as error:
            row["error"] = str(error)
        finally:
            if fd is not None:
                os.close(fd)
    del opened
    report["after"] = observe_step_memory() if sample_memory else observe_step_memory(detailed=False)
    validate_resource_release(report)
    return report


def _check_release_aliases(path, original, aliases):
    """Default remains exclusive; an opt-in caller must account for every link."""
    if original.st_nlink == 1:
        return
    names = () if aliases is None else aliases.get(path, ())
    _require(len(set(names)) == len(names) == original.st_nlink and path in names,
             "RESOURCE_RELEASE_FILE_INVALID")
    for name in names:
        value = name.stat()
        _require(name.is_absolute() and not name.is_symlink() and name.resolve(strict=True) == name
                 and value.st_uid == original.st_uid == os.getuid()
                 and (value.st_dev, value.st_ino, value.st_nlink, value.st_size,
                      value.st_mtime_ns, value.st_ctime_ns)
                     == (original.st_dev, original.st_ino, original.st_nlink, original.st_size,
                         original.st_mtime_ns, original.st_ctime_ns),
                 "RESOURCE_RELEASE_FILE_CHANGED")


def release_completed_files(files: Sequence[Path], *, owner: str, report_root: Path,
                            alias_roots: Sequence[Path] = (),
                            released_references: Sequence[str] = (),
                            file_identities: Mapping[Path, tuple] | None = None,
                            persist_report: bool = True) -> dict[str, Any]:
    """Non-scientific stage tail: retain bytes and record actual cache advice.

    Call only after the original numerical consumer returns and owned workers
    have joined. Alias roots belong to that same computation; unrelated links
    or open descriptor/mapping prevent ordinary advice. F45 force mode waives
    these checks by explicit user authorization. Retained results may be read
    by a later stage: DONTNEED is only a cache hint, never retirement or deletion.
    """
    report = {"owner": owner, "skipped": [], "aliases": {}, "release": None,
              "resource_observation_after": None, "error": None, "files_deleted": 0}
    # Explicit user authorization covers all F45 cache-only release calls.
    # No process readers, UID/GID or historical ownership gate is required.
    force_cache = bool(os.environ.get("PADML_F45_RUN_PATH"))
    try:
        selected, linked, seen = [], {}, set()
        for path in sorted(set(files)):
            try:
                value = path.stat()
                if (not path.is_absolute() or path.is_symlink() or path.resolve(strict=True) != path
                        or not stat.S_ISREG(value.st_mode)
                        or (not force_cache and value.st_uid != os.getuid())):
                    raise ValueError("UNCONFIRMED_PATH_OR_OWNER")
                key = (value.st_dev, value.st_ino)
                if key in seen:
                    continue
                seen.add(key)
                if force_cache or value.st_nlink == 1:
                    selected.append(path)
                else:
                    linked[key] = (path, value, set())
            except (OSError, ValueError) as error:
                report["skipped"].append({"path": str(path), "reason": str(error)})
        if linked:
            for base in alias_roots:
                _require(base.is_absolute() and not base.is_symlink()
                         and base.resolve(strict=True) == base, "RESOURCE_RELEASE_ALIAS_ROOT_INVALID")
                def failed(error):
                    raise error
                for directory, _, names in os.walk(base, followlinks=False, onerror=failed):
                    for name in names:
                        path = Path(directory) / name
                        if path.is_symlink():
                            continue
                        try:
                            value = path.stat()
                        except FileNotFoundError:
                            continue
                        key = (value.st_dev, value.st_ino)
                        if key in linked:
                            linked[key][2].add(path)
        aliases = {}
        for path, value, names in linked.values():
            try:
                _check_release_aliases(path, value, {path: sorted(names)})
                aliases[path] = sorted(names)
                report["aliases"][str(path)] = [str(p) for p in sorted(names)]
                selected.append(path)
            except (OSError, ContractError) as error:
                report["skipped"].append({"path": str(path), "reason": str(error),
                    "identity": [value.st_dev, value.st_ino, value.st_size,
                                 value.st_mtime_ns, value.st_ctime_ns]})
        report["release"] = release_step_resources(sorted(selected), owner=owner,
            before=observe_step_memory(), released_references=released_references, file_aliases=aliases,
            file_identities=file_identities, force_cache=force_cache)
    except (OSError, ContractError, ValueError) as error:
        report["error"] = type(error).__name__ + ":" + str(error)
    try:
        report["resource_observation_after"] = observe_execution_resources(report_root)
    except (OSError, ContractError, ValueError) as error:
        report["observation_error"] = type(error).__name__ + ":" + str(error)
    if not persist_report:
        return report
    try:
        directory = report_root / "resource-release"
        directory.mkdir(mode=0o700, parents=True, exist_ok=True)
        path = directory / f"{os.getpid()}-{monotonic_ns()}.json"
        with path.open("xb") as handle:
            handle.write(canonical_json_bytes(report))
            handle.flush()
            os.fsync(handle.fileno())
        report["report_path"] = str(path)
    except OSError as error:
        report["report_error"] = type(error).__name__ + ":" + str(error)
    return report




def active_run_root():
    """The manifest's location is independent of its declared data directory."""
    location = os.environ.get("PADML_F45_RUN_PATH")
    if location is None:
        return None
    from .bundle import strict_json_bytes
    value = strict_json_bytes(Path(location).read_bytes())
    root = Path(value["run_root"])
    _require(root.is_absolute(), "RESOURCE_RUN_ROOT_INVALID")
    return root


def release_f45_cumulative_files(files, *, owner, report_root, released_references=(), scope="stage"):
    """A failed cache diagnostic never replaces a valid scientific result."""
    try:
        return _release_f45_cumulative_files(files, owner=owner, report_root=report_root,
                                             released_references=released_references, scope=scope)
    except (OSError, ValueError, KeyError, TypeError, ContractError) as error:
        report = {"owner": "CUMULATIVE:" + owner, "release": None, "files_deleted": 0,
                  "error": type(error).__name__ + ":" + str(error),
                  "cumulative": {"status": "UNKNOWN"}}
        try:
            base = active_run_root() / "units"
            unit = base / report_root.relative_to(base).parts[0]
            directory = unit / "resource-release"
            directory.mkdir(mode=0o700, exist_ok=True)
            path = directory / f"{os.getpid()}-{monotonic_ns()}.json"
            with path.open("xb") as stream:
                stream.write(canonical_json_bytes(report))
                stream.flush()
                os.fsync(stream.fileno())
            report["report_path"] = str(path)
        except (OSError, ValueError, KeyError, IndexError) as diagnostic_error:
            report["report_error"] = str(diagnostic_error)
        print(canonical_json_bytes(report).decode(), file=sys.stderr)
        return report




def _release_f45_cumulative_files(files, *, owner, report_root, released_references=(), scope="stage"):
    """Release this stage's actual files, or the run at the whole-owner boundary.

    No reader gates or deletion. Advice and non-atomic observations are not
    proof of eviction; successful global advice does not invent file counts.
    """
    location = os.environ.get("PADML_F45_RUN_PATH")
    if location is None:
        return {}
    base = active_run_root()
    _require(scope in {"stage", "run"}, "RESOURCE_CUMULATIVE_SCOPE_INVALID")
    if scope in {'stage', 'run'}:
        with _COMPLETED_CACHE_LOCK:
            files = tuple(dict.fromkeys([*files, *(p for p in _COMPLETED_CACHE_FILES
                if p.is_relative_to(base))]))
    units = base / "units"
    if report_root.is_relative_to(base / "contexts"):
        # Shared FULL0 inputs have no unit in their path. Use the existing
        # coordinator record solely to place diagnostics outside science data.
        from .bundle import strict_json_bytes
        with (base / "active.lock").open("rb") as stream:
            unit_id = strict_json_bytes(stream.readline(65536))["unit_id"]
        _require(isinstance(unit_id, str) and unit_id not in {"", ".", ".."}
                 and Path(unit_id).name == unit_id, "RESOURCE_CUMULATIVE_SCOPE_INVALID")
        report_root = units / unit_id
    _require(base.is_absolute() and report_root.is_relative_to(units),
             "RESOURCE_CUMULATIVE_SCOPE_INVALID")
    unit = units / report_root.relative_to(units).parts[0]
    before = observe_step_memory()
    summary = {"scope": scope, "run_root": str(base), "enumerated": False,
        "attempted_files": 0, "attempted_bytes": 0, "advised_files": 0, "advised_bytes": 0,
        "failed_files": 0, "skipped_files": 0, "unsupported_files": 0,
        "duplicate_files": 0, "error_counts": {}, "error_samples": [], "errors_omitted": 0,
        "global_cache": {"operation": "NONE", "status": "NOT_REQUESTED"},
        "claim": "ADVICE_NOT_PROOF_OF_EVICTION; NO_PRECHECK_OR_POSTCHECK_GATE"}
    report = {"owner": "CUMULATIVE:" + owner, "files_deleted": 0, "error": None,
        "before": before, "gc_collected": gc.collect(), "released_references": list(released_references),
        "cumulative": summary}
    def failed(operation, error, path=None):
        key = operation + ":" + str(getattr(error, "errno", None))
        summary["error_counts"][key] = summary["error_counts"].get(key, 0) + 1
        if len(summary["error_samples"]) < 16:
            summary["error_samples"].append({"operation": operation,
                "path": None if path is None else str(path)[:1024], "error": str(error)[:1024]})
        else:
            summary["errors_omitted"] += 1
    # The current consumer already supplied exact names. No rediscovery,
    # publication resync or second advice for an unchanged consumption.
    summary["enumerated"] = True
    result = advise_completed_io(files, sync=False, new_consumption=False)
    summary.update(result)
    report["after"] = observe_step_memory()
    try:
        report["resource_observation_after"] = observe_execution_resources(report_root)
    except Exception as error:
        report["observation_error"] = str(error)[:2048]
    directory = unit / "resource-release"
    directory.mkdir(mode=0o700, parents=True, exist_ok=True)
    path = directory / f"{os.getpid()}-{monotonic_ns()}.json"
    with path.open("xb") as stream:
        stream.write(canonical_json_bytes(report))
        stream.flush()
        os.fsync(stream.fileno())
    report["report_path"] = str(path)
    return report


def validate_resource_release(value: Any) -> None:
    """Direct stage-reader validation; UNKNOWN never becomes zero or success."""
    if isinstance(value, Mapping) and value.get("status") == "UNKNOWN":
        _require(set(value) == {"status", "owner", "pid", "reason"}
                 and isinstance(value["owner"], str) and value["owner"]
                 and type(value["pid"]) is int and value["pid"] > 0
                 and isinstance(value["reason"], str) and value["reason"], "RESOURCE_RELEASE_REPORT_INVALID")
        return
    _require(isinstance(value, Mapping) and set(value) == {
        "owner", "before", "after", "released_references", "gc_collected", "reader_scan_status",
        "visible_processes_checked", "files", "claim"}
        and isinstance(value["owner"], str) and bool(value["owner"])
        and value["claim"] == "ADVISORY_ONLY_NONATOMIC_OBSERVATIONS_NOT_ATTRIBUTION"
        and value["reader_scan_status"] in {"UNKNOWN", "OBSERVED", "WAIVED_BY_USER"}
        and all(type(value[key]) is int and value[key] >= 0 for key in
                ("gc_collected", "visible_processes_checked"))
        and isinstance(value["released_references"], list)
        and all(isinstance(name, str) and name for name in value["released_references"])
        and isinstance(value["files"], list), "RESOURCE_RELEASE_REPORT_INVALID")
    for snapshot in (value["before"], value["after"]):
        _require(isinstance(snapshot, Mapping) and set(snapshot) == {
            "pid", "started_ns", "finished_ns", "clock", "rss_bytes", "rss_source", "cgroup_status", "cgroups"}
            | ({"lifetime_maxrss"} if "lifetime_maxrss" in snapshot else set())
            and snapshot["clock"] == "MONOTONIC_NS"
            and type(snapshot["pid"]) is int and snapshot["pid"] > 0
            and type(snapshot["started_ns"]) is int and type(snapshot["finished_ns"]) is int
            and 0 < snapshot["started_ns"] <= snapshot["finished_ns"]
            and (snapshot["rss_bytes"] is None or type(snapshot["rss_bytes"]) is int and snapshot["rss_bytes"] >= 0)
            and snapshot["rss_source"] == "/proc/self/smaps_rollup:Rss"
            and snapshot["cgroup_status"] in {"UNKNOWN", "OBSERVED"}
            and isinstance(snapshot["cgroups"], list), "RESOURCE_RELEASE_MEMORY_INVALID")
        if "lifetime_maxrss" in snapshot:
            peak = snapshot["lifetime_maxrss"]
            _require(isinstance(peak, Mapping) and set(peak) == {
                "status", "source", "unit", "scope", "process_start_ticks", "self_bytes", "children_bytes"}
                and peak["source"] == "LINUX_GETRUSAGE" and peak["unit"] == "BYTES"
                and peak["scope"] == "LIFETIME_SELF_AND_MAX_REAPED_CHILD"
                and (peak["status"] == "UNKNOWN"
                     and all(peak[key] is None for key in ("process_start_ticks", "self_bytes", "children_bytes"))
                     or peak["status"] == "OBSERVED"
                     and type(peak["process_start_ticks"]) is int and peak["process_start_ticks"] > 0
                     and type(peak["self_bytes"]) is int and peak["self_bytes"] > 0
                     and type(peak["children_bytes"]) is int and peak["children_bytes"] >= 0),
                "RESOURCE_RELEASE_MAXRSS_INVALID")
        for row in snapshot["cgroups"]:
            _require(isinstance(row, Mapping) and set(row) == {"path", "version", "total_bytes", "limit_bytes",
                "anon_bytes", "file_bytes", "stat_keys", "stat_status"}
                and isinstance(row["path"], str) and Path(row["path"]).is_absolute()
                and type(row["version"]) is int and row["version"] in {1, 2}
                and row["stat_keys"] == (["anon", "file"] if row["version"] == 2 else ["total_rss", "total_cache"])
                and all(row[key] is None or type(row[key]) is int and row[key] >= 0
                        for key in ("total_bytes", "limit_bytes", "anon_bytes", "file_bytes"))
                and row["stat_status"] in {"UNKNOWN", "OBSERVED"}
                and (row["stat_status"] == "OBSERVED") == (row["anon_bytes"] is not None and row["file_bytes"] is not None),
                "RESOURCE_RELEASE_CGROUP_INVALID")
    _require(value["before"]["pid"] == value["after"]["pid"]
             and value["before"]["finished_ns"] <= value["after"]["started_ns"],
             "RESOURCE_RELEASE_MEMORY_INVALID")
    # Old releases remain readable but have no peak evidence. A new pair
    # cannot mix a legacy half or claim another incarnation of the same PID.
    _require(("lifetime_maxrss" in value["before"]) == ("lifetime_maxrss" in value["after"]),
             "RESOURCE_RELEASE_MAXRSS_INVALID")
    if "lifetime_maxrss" in value["before"]:
        before, after = value["before"]["lifetime_maxrss"], value["after"]["lifetime_maxrss"]
        if before["status"] == after["status"] == "OBSERVED":
            _require(before["process_start_ticks"] == after["process_start_ticks"]
                     and all(after[key] >= before[key] for key in ("self_bytes", "children_bytes")),
                     "RESOURCE_RELEASE_MAXRSS_INVALID")
    paths = []
    for row in value["files"]:
        _require(isinstance(row, Mapping) and set(row) == {"path", "device", "inode", "size_bytes",
            "mtime_ns", "ctime_ns", "status", "error"}
            and isinstance(row["path"], str) and Path(row["path"]).is_absolute()
            and all(type(row[key]) is int and row[key] >= 0
                    for key in ("device", "inode", "size_bytes", "mtime_ns", "ctime_ns"))
            and row["status"] in {"UNKNOWN", "ACTIVE_READER_OR_WRITER", "UNSUPPORTED", "ADVISED"}
            and (row["error"] is None or isinstance(row["error"], str))
            and (row["status"] != "ADVISED" or value["reader_scan_status"] in {"OBSERVED", "WAIVED_BY_USER"}
                 and row["error"] is None),
            "RESOURCE_RELEASE_FILE_REPORT_INVALID")
        paths.append(row["path"])
    _require(len(set(paths)) == len(paths), "RESOURCE_RELEASE_FILE_ALIAS")


def observe_execution_resources(scratch_root: Path) -> dict[str, Any]:
    """Capture live CPU, available-memory and scratch evidence on one host."""
    _require(
        isinstance(scratch_root, Path)
        and scratch_root.is_absolute()
        and scratch_root.is_dir()
        and not scratch_root.is_symlink()
        and scratch_root.resolve(strict=True) == scratch_root,
        "SCRATCH_RESOURCE_PATH_INVALID",
    )
    try:
        stat = os.statvfs(scratch_root)
        scratch = stat.f_bavail * stat.f_frsize
    except OSError as error:
        raise ContractError("SCRATCH_RESOURCE_UNDETERMINED") from error
    _require(type(scratch) is int and scratch > 0, "SCRATCH_RESOURCE_UNDETERMINED")
    return {
        "effective_cpus": effective_cpu_count(),
        "available_memory_bytes": _available_memory_bytes(),
        "scratch_available_bytes": scratch,
        "scratch_root": str(scratch_root),
    }


def validate_resource_observation(value: Any) -> dict[str, Any]:
    _require(
        isinstance(value, Mapping) and set(value) == RESOURCE_OBSERVATION_FIELDS,
        "RESOURCE_OBSERVATION_INVALID",
    )
    row = dict(value)
    _require(
        type(row["effective_cpus"]) is int and row["effective_cpus"] > 8
        and type(row["available_memory_bytes"]) is int
        and row["available_memory_bytes"] > 0
        and type(row["scratch_available_bytes"]) is int
        and row["scratch_available_bytes"] > 0
        and isinstance(row["scratch_root"], str)
        and Path(row["scratch_root"]).is_absolute(),
        "RESOURCE_OBSERVATION_INVALID",
    )
    return row


def resource_admission(
    policy: Mapping[str, Any], observation: Mapping[str, Any], *, legal_tasks: int,
) -> dict[str, Any]:
    """Apply the exact one-host minimum rule and retain each limiting term."""
    policy = validate_resource_policy(policy)
    observation = validate_resource_observation(observation)
    _require(type(legal_tasks) is int and legal_tasks >= 1, "RESOURCE_LEGAL_TASKS_INVALID")
    memory_usable = max(
        0, observation["available_memory_bytes"] - policy["memory_reserve_bytes"]
    )
    scratch_usable = max(
        0, observation["scratch_available_bytes"] - policy["scratch_reserve_bytes"]
    )
    limits = {
        "cpu_c_minus_8": observation["effective_cpus"] - 8,
        "memory": memory_usable // policy["memory_bytes_per_worker"],
        "scratch": scratch_usable // policy["scratch_bytes_per_worker"],
        "transfer_archive": policy["transfer_archive_worker_ceiling"],
        "legal_independent_tasks": legal_tasks,
        "configured": pool_capacity(observation["effective_cpus"]),
    }
    admitted = min(limits.values())
    if admitted < 1:
        detail = {
            "limits": limits,
            "memory_usable_bytes": memory_usable,
            "scratch_usable_bytes": scratch_usable,
            "legal_tasks": legal_tasks,
            "policy": policy,
            "observation": observation,
        }
        raise ContractError("RESOURCE_ADMISSION_ZERO:"
                            + canonical_json_bytes(detail).decode("utf-8").rstrip("\n"))
    return {
        "limits": limits,
        "admitted_worker_ceiling": admitted,
        "memory_usable_bytes": memory_usable,
        "scratch_usable_bytes": scratch_usable,
    }


def admit_stage(policy, root, *, legal_tasks, retained_bytes, publication_bytes,
                transient_bytes_per_worker, memory_bytes_per_worker=MIN_WORKER_MEMORY_BYTES,
                task_disk_bytes=None, task_write_paths=None, _observation=None):
    """Charge future retained/publication bytes before admitting temporary workers."""
    if task_disk_bytes is not None:
        _require(isinstance(task_disk_bytes, (list, tuple)) and len(task_disk_bytes) == legal_tasks
            and all(isinstance(row, (list, tuple)) and len(row) == 2
                and all(type(v) is int and v >= 0 for v in row) for row in task_disk_bytes),
            "RESOURCE_STAGE_TASK_ESTIMATE_INVALID")
        task_disk_bytes = tuple(tuple(row) for row in task_disk_bytes)
        _require(sum(row[0] for row in task_disk_bytes) == retained_bytes
            and max((row[1] for row in task_disk_bytes), default=0) == publication_bytes,
            "RESOURCE_STAGE_TASK_ESTIMATE_INVALID")
    shared = current_ready_pool()
    _require(task_write_paths is None or isinstance(task_write_paths, (tuple, list))
        and len(task_write_paths) == legal_tasks and all(isinstance(paths, (list, tuple))
            and all(isinstance(p, (str, Path)) and Path(p).is_absolute() for p in paths)
            for paths in task_write_paths), 'RESOURCE_STAGE_WRITE_PATHS_INVALID')
    if shared is not None:
        return shared.admit(policy, root, legal_tasks=legal_tasks, retained_bytes=retained_bytes,
            publication_bytes=publication_bytes, transient_bytes_per_worker=transient_bytes_per_worker,
            memory_bytes_per_worker=memory_bytes_per_worker, task_disk_bytes=task_disk_bytes,
            task_write_paths=task_write_paths)
    values = (retained_bytes, publication_bytes, transient_bytes_per_worker, memory_bytes_per_worker)
    _require(all(type(v) is int and v >= 0 for v in values)
             and transient_bytes_per_worker > 0 and memory_bytes_per_worker > 0,
             "RESOURCE_STAGE_ESTIMATE_INVALID")
    observation = observe_execution_resources(root) if _observation is None else _observation
    future = retained_bytes + publication_bytes
    observed = dict(observation)
    _require(observation["scratch_available_bytes"] > future, "RESOURCE_ADMISSION_ZERO:FUTURE_RETAINED_AND_PUBLICATION_SPACE")
    observed["scratch_available_bytes"] = observation["scratch_available_bytes"] - future
    result = resource_admission({**policy, "scratch_reserve_bytes": 0,
        "scratch_bytes_per_worker": max(policy["scratch_bytes_per_worker"], transient_bytes_per_worker),
        "memory_bytes_per_worker": max(policy["memory_bytes_per_worker"], memory_bytes_per_worker)},
        observed, legal_tasks=legal_tasks)
    result["disk_peak"] = {"free_bytes": observation["scratch_available_bytes"],
        "future_retained_bytes": retained_bytes, "publication_bytes": publication_bytes,
        "transient_bytes_per_worker": transient_bytes_per_worker}
    return result


def _readback_ordered(worker, tasks, *, policy, root, per_worker_bytes=0,
                      retained_bytes=0, execution_report=None, cache_files=()):
    """Read independent completed coordinates in the original ordered pool."""
    _require(type(per_worker_bytes) is int and per_worker_bytes >= 0
             and type(retained_bytes) is int and retained_bytes >= 0,
             "RESOURCE_READBACK_ESTIMATE_INVALID")
    if not tasks:
        return []
    # An outer scientific worker already owns its memory and process slot.
    if _IN_SCIENTIFIC_POOL:
        return [worker(task) for task in tasks]
    effective = {**validate_resource_policy(policy), "scratch_reserve_bytes": 0,
        "memory_bytes_per_worker": max(MIN_WORKER_MEMORY_BYTES, per_worker_bytes),
        "memory_reserve_bytes": policy["memory_reserve_bytes"] + retained_bytes}
    admission = resource_admission(effective, observe_execution_resources(root), legal_tasks=len(tasks))
    report = {} if execution_report is None else execution_report
    report.update(resource_admission=admission, effective_policy=effective, pool={})
    results = _bounded_ordered_spawn(worker, tasks,
        selected_slots=admission["admitted_worker_ceiling"], execution_report=report["pool"])
    # Workers have exited; returned numerical objects remain live and reserved.
    # The original helper also covers files advised before being read again.
    cache_files = tuple(cache_files)
    mark_cache_use(cache_files)  # The child's reread is new consumption in this parent.
    release_f45_cumulative_files(cache_files, owner="READBACK:" + worker.__name__, report_root=root)
    return results


def _ready_ordered(worker, tasks, *, policy, root, retained_bytes_per_task,
                   transient_bytes_per_worker, publication_bytes=0,
                   memory_bytes_per_worker=MIN_WORKER_MEMORY_BYTES, task_write_paths=None,
                   retained_bytes_by_task=None, **kwargs):
    """Run an existing ordered batch through the sole dynamically admitted pool."""
    if not tasks:
        return []
    workers = kwargs.pop('selected_slots', None)
    retained = ([retained_bytes_per_task] * len(tasks) if retained_bytes_by_task is None
        else list(retained_bytes_by_task))
    _require(len(retained) == len(tasks) and all(type(v) is int and v >= 0 for v in retained),
        'READY_TASK_DISK_ESTIMATE_INVALID')
    def coordinate():
        admit_stage(policy, root, legal_tasks=len(tasks),
            retained_bytes=sum(retained),
            publication_bytes=publication_bytes,
            transient_bytes_per_worker=transient_bytes_per_worker,
            memory_bytes_per_worker=memory_bytes_per_worker,
            task_disk_bytes=[(value, publication_bytes) for value in retained],
            task_write_paths=task_write_paths)
        return _bounded_ordered_spawn(worker, tasks, selected_slots=workers, **kwargs)
    if current_ready_pool() is not None:
        return coordinate()
    return run_ready_families([coordinate], policy=policy, root=root, workers=workers)[0]


def effective_cpu_count() -> int:
    """Read the executing host's affinity, cpuset and hierarchical CPU quotas."""
    try:
        if sys.platform != "linux":
            count = os.cpu_count()
            _require(type(count) is int and count > 0, "CPU_RESOURCE_UNDETERMINED")
            return count
        allowed = set(os.sched_getaffinity(0))
        _require(bool(allowed), "CPU_RESOURCE_UNDETERMINED")
        mounts = []
        for line in Path("/proc/self/mountinfo").read_text().splitlines():
            left, right = line.split(" - ", 1)
            fields, filesystem = left.split(), right.split()
            if filesystem[0] in {"cgroup", "cgroup2"}:
                mounts.append((filesystem[0], Path(fields[3]), Path(fields[4]),
                               set(filesystem[2].split(","))))
        limits = []
        cpu_controller_seen = False
        v1_controllers_seen = set()
        unmounted_unified = False
        for line in Path("/proc/self/cgroup").read_text().splitlines():
            hierarchy, controllers, raw_path = line.split(":", 2)
            controllers = set(controllers.split(","))
            unified = controllers == {""}
            if not unified and not controllers & {"cpu", "cpuset"}:
                continue
            group = Path(raw_path)
            _require(group.is_absolute() and ".." not in group.parts,
                     "CPU_RESOURCE_CGROUP_PATH_INVALID")
            if unified and hierarchy == "0" and not any(row[0] == "cgroup2" for row in mounts):
                # A hybrid host may list v2 while both CPU controllers belong to v1.
                # Defer until their real limits are read, independent of row order.
                unmounted_unified = True
                continue
            matches = [row for row in mounts
                       if row[0] == ("cgroup2" if unified else "cgroup")
                       and (unified or controllers <= row[3])
                       and group.is_relative_to(row[1])]
            _require(bool(matches), "CPU_RESOURCE_CGROUP_MOUNT_MISSING")
            _, root, mount, _ = max(matches, key=lambda row: len(row[1].parts))
            current = mount / group.relative_to(root)
            while True:
                if unified:
                    quota_file = current / "cpu.max"
                    if quota_file.exists():
                        quota, period = quota_file.read_text().split()
                        _require(int(period) > 0, "CPU_RESOURCE_QUOTA_INVALID")
                        if quota != "max":
                            _require(int(quota) > 0, "CPU_RESOURCE_QUOTA_INVALID")
                            limits.append(int(quota) // int(period))
                        cpu_controller_seen = True
                elif "cpu" in controllers:
                    quota = int((current / "cpu.cfs_quota_us").read_text())
                    period = int((current / "cpu.cfs_period_us").read_text())
                    _require(period > 0 and (quota == -1 or quota > 0),
                             "CPU_RESOURCE_QUOTA_INVALID")
                    if quota != -1:
                        limits.append(quota // period)
                    cpu_controller_seen = True
                    v1_controllers_seen.add("cpu")
                if unified or "cpuset" in controllers:
                    names = ("cpuset.cpus.effective", "cpuset.effective_cpus", "cpuset.cpus")
                    for name in names:
                        path = current / name
                        if not path.exists():
                            continue
                        raw = path.read_text().strip()
                        if raw:
                            cpus = set()
                            for part in raw.split(","):
                                bounds = part.split("-")
                                _require(len(bounds) in {1, 2}, "CPU_RESOURCE_CPUSET_INVALID")
                                low, high = int(bounds[0]), int(bounds[-1])
                                _require(0 <= low <= high, "CPU_RESOURCE_CPUSET_INVALID")
                                cpus.update(range(low, high + 1))
                            allowed.intersection_update(cpus)
                            if not unified:
                                v1_controllers_seen.add("cpuset")
                            break
                if current == mount:
                    break
                current = current.parent
        _require(not unmounted_unified or {"cpu", "cpuset"} <= v1_controllers_seen,
                 "CPU_RESOURCE_CGROUP_MOUNT_MISSING")
        _require(cpu_controller_seen and bool(allowed), "CPU_RESOURCE_UNDETERMINED")
        return min(len(allowed), *limits) if limits else len(allowed)
    except (OSError, ValueError, IndexError, AttributeError) as error:
        raise ContractError("CPU_RESOURCE_UNDETERMINED") from error


def pool_capacity(effective_cpus: int | None = None) -> int:
    """C−8; an explicit C must be observed on the execution host, not the compiler."""
    count = effective_cpu_count() if effective_cpus is None else effective_cpus
    _require(type(count) is int and count > 8, "CPU_RESOURCE_REQUIRES_MORE_THAN_8_CPUS")
    return count - 8


def resolve_pool_workers(workers: int | None = None) -> int:
    capacity = pool_capacity()
    _require(workers is None or type(workers) is int and 1 <= workers <= capacity,
             "POOL_WORKERS_EXCEED_EXECUTION_HOST_CAPACITY")
    return capacity if workers is None else workers


_Task = TypeVar("_Task")
_Result = TypeVar("_Result")
_MISSING = object()
_TASK_DEADLINE_SECONDS = 12 * 60 * 60
_RELEASE_WAIT_SECONDS = 60.0
_RELEASE_TERMINATE_GRACE_SECONDS = 5.0
_IN_SCIENTIFIC_POOL = False
_ACTIVE_TASK_DEADLINE = None
_POOL_MAIN_LOCK = Lock()
_POOL_GROUP_OBSERVER = None


from collections import deque
from queue import SimpleQueue, Empty
from threading import Event, Thread, local
from time import monotonic
from types import SimpleNamespace
import math
import os
import signal


_READY_FAMILY_LOCAL = local()
_READY_MISSING = object()
_READY_PREPARATION_SCOPE = None


def _ready_leaf(call):
    global _READY_PREPARATION_SCOPE
    function, task, scope, live_scopes = call
    kernel = sys.modules.get("padml.f2_kernel")
    if kernel is not None:
        kernel._release_python_prepared(live_scopes)
    _READY_PREPARATION_SCOPE = scope
    try:
        return function(task)
    finally:
        _READY_PREPARATION_SCOPE = None


def _task_cache_files(function, task):
    if function is _ready_leaf:
        function, task, _, _ = task
    planned = getattr(function, 'cache_files', None)
    return tuple(planned(task)) if planned is not None else ()


def _compensate_task_cache(function, task):
    """Called only after owned-group exit is confirmed, never while UNKNOWN."""
    try:
        return advise_completed_io(_task_cache_files(function, task))
    except (OSError, ValueError, KeyError, TypeError, ContractError):
        return None  # Cache advice cannot replace the original task failure.


def current_ready_pool():
    return getattr(_READY_FAMILY_LOCAL, 'pool', None)


def _signal_pool_process(process, signum, *, owns_group):
    """Always signal owned descendants; ignore EPERM only for an absent group."""
    try:
        if owns_group:
            os.killpg(process.pid, signum)
        else:
            os.kill(process.pid, signum)
    except ProcessLookupError:
        pass
    except PermissionError:
        # Darwin may report EPERM for an already reaped empty process group.
        # Leader exit alone proves nothing about its native descendants.
        if owns_group:
            import subprocess
            try:
                process.join(timeout=0)
                observed = subprocess.run(["ps", "-eo", "pgid="], capture_output=True,
                    text=True, timeout=5)
                groups = observed.stdout.split()
                if observed.returncode == 0 and groups and all(g.isdigit() for g in groups) \
                        and str(process.pid) not in groups:
                    return
            except (OSError, subprocess.TimeoutExpired):
                pass
        raise


def _advance_release_timeout(process, state, *, owns_group):
    """Nonblocking retirement of one acknowledged worker after scientific OK.

    state is [cleanup deadline, signal phase]; peers keep progressing while
    TERM/KILL completes. No slot is reusable until its whole group is gone.
    """
    now = monotonic()
    try:
        _require(owns_group, 'BOUNDED_SPAWN_RELEASE_OWNER_UNKNOWN')
        process.join(timeout=0)
        if not process.is_alive():
            try:
                os.killpg(process.pid, 0)
                gone = False
            except ProcessLookupError:
                gone = True
            except PermissionError:
                import subprocess
                result = subprocess.run(['ps','-eo','pgid='], capture_output=True, text=True, timeout=5)
                groups = result.stdout.split()
                _require(result.returncode == 0 and bool(groups)
                    and all(g.isdecimal() for g in groups), 'BOUNDED_SPAWN_RELEASE_OWNER_UNKNOWN')
                gone = str(process.pid) not in groups
            if gone:
                return True
        if now >= state[0]:
            _require(state[1] < 2, 'BOUNDED_SPAWN_RELEASE_OWNER_UNKNOWN')
            _signal_pool_process(process, signal.SIGTERM if state[1] == 0 else signal.SIGKILL,
                owns_group=True)
            state[:] = [monotonic()+_RELEASE_TERMINATE_GRACE_SECONDS, state[1]+1]
        return False
    except Exception as error:
        raise ContractError('BOUNDED_SPAWN_RELEASE_OWNER_UNKNOWN:' + str(process.pid)
            + ':' + type(error).__name__ + ':' + str(error)) from error


def _wait_pool_exits(processes, owned_groups, *, terminated=False):
    """Bounded parallel final reap; a dead leader never proves group exit."""
    pending = {p: [monotonic()+_RELEASE_TERMINATE_GRACE_SECONDS, int(terminated)]
        for p in processes}
    gone, failures, unconfirmed = set(), [], {}
    while pending:
        for process, state in list(pending.items()):
            if process in unconfirmed:
                # Observation failure must not abandon our owned leader. Reap
                # it after KILL while retaining UNKNOWN for the whole group.
                try:
                    process.join(timeout=0)
                    if not process.is_alive() or monotonic() >= unconfirmed[process]:
                        del pending[process]
                except Exception as error:
                    failures.append(error)
                    del pending[process]
                continue
            try:
                if process.pid in owned_groups:
                    complete = _advance_release_timeout(process, state, owns_group=True)
                else:
                    # No READY means no scientific/native task was dispatched.
                    process.join(timeout=0)
                    complete = not process.is_alive()
                    if not complete and monotonic() >= state[0]:
                        _require(state[1] < 2, 'BOUNDED_SPAWN_CHILD_SURVIVOR')
                        _signal_pool_process(process,
                            signal.SIGTERM if state[1] == 0 else signal.SIGKILL, owns_group=False)
                        state[:] = [monotonic()+_RELEASE_TERMINATE_GRACE_SECONDS, state[1]+1]
                if complete:
                    gone.add(process)
                    del pending[process]
            except Exception as error:
                failures.append(error)
                try:
                    _signal_pool_process(process, signal.SIGKILL,
                        owns_group=process.pid in owned_groups)
                except Exception as cleanup_error:
                    failures.append(cleanup_error)
                unconfirmed[process] = monotonic()+_RELEASE_TERMINATE_GRACE_SECONDS
        if pending:
            Event().wait(.01)
    return gone, failures


class _ReadyPool:
    def __init__(self, policy, root, workers, report):
        self.policy = validate_resource_policy(policy)
        self.root, self.ceiling = root, resolve_pool_workers(workers)
        self.report = report
        self.inbox = SimpleQueue()
        self.waiting, self.batches, self.idle = deque(), deque(), deque()
        self.processes, self.starting, self.active, self.owned = {}, {}, {}, set()
        self.release_waits = {}
        self.retiring = {}
        self.warm = set()
        self.bound_function_scopes = {}
        self.failure = None
        self.capacity = self.ceiling
        self.cancelled = Event()
        self.completed_families = 0
        self.cache_generation = 0
        self.admission_dirty = True
        self.admission_retry_at = math.inf
        self.dispatch_observation = None
        self.dispatch_written_credits = {}
        self.dispatching = False

    def check(self):
        if self.cancelled.is_set():
            raise self.failure or ContractError('READY_FAMILY_CANCELLED')

    def admit(self, policy, root, **estimates):
        self.check()
        _require(validate_resource_policy(policy) == self.policy
            and root.stat().st_dev == self.root.stat().st_dev,
            'READY_FAMILY_RESOURCE_SCOPE_DRIFT')
        _require(getattr(_READY_FAMILY_LOCAL, 'stage', None) is None, 'READY_STAGE_ALREADY_PENDING')
        limits = [estimates[k] for k in ('legal_tasks','transient_bytes_per_worker')]
        limits += [estimates.get('memory_bytes_per_worker', MIN_WORKER_MEMORY_BYTES)]
        _require(all(type(v) is int and v > 0 for v in limits)
            and all(type(estimates[k]) is int and estimates[k] >= 0
                    for k in ('retained_bytes','publication_bytes')),
            'RESOURCE_STAGE_ESTIMATE_INVALID')
        estimates = {**estimates, 'memory_bytes_per_worker': limits[-1]}
        # Filled by the sole parent before any task in this batch is sent.
        record = {'admitted_worker_ceiling': min(self.ceiling, estimates['legal_tasks'])}
        _READY_FAMILY_LOCAL.stage = estimates, record
        return record

    def map(self, function, tasks, *, selected_slots=None, on_result=None,
            schedule_order=None, execution_report=None, task_deadlines=None,
            task_timeout_seconds=None, resource_release_report=None):
        self.check()
        _require(not _IN_SCIENTIFIC_POOL and bool(tasks), 'NESTED_SCIENTIFIC_POOL_FORBIDDEN')
        stage = getattr(_READY_FAMILY_LOCAL, 'stage', None)
        _require(stage is not None, 'READY_STAGE_ADMISSION_REQUIRED')
        _READY_FAMILY_LOCAL.stage = None
        n = len(tasks)
        disk = stage[0].get('task_disk_bytes')
        _require(disk is None or len(disk) == n, 'RESOURCE_STAGE_TASK_ESTIMATE_INVALID')
        order = list(range(n)) if schedule_order is None else list(schedule_order)
        _require(len(order) == n and set(order) == set(range(n)), 'BOUNDED_SPAWN_SCHEDULE_INVALID')
        timeout = _TASK_DEADLINE_SECONDS if task_timeout_seconds is None else task_timeout_seconds
        _require(type(timeout) in (int, float) and math.isfinite(timeout)
            and 0 < timeout <= 24*3600, 'BOUNDED_SPAWN_TIMEOUT_INVALID')
        _require(task_deadlines is None or len(task_deadlines) == n
            and all(d is None or type(d) in (int,float) and math.isfinite(d)
                    and 0 < d <= monotonic()+timeout for d in task_deadlines),
            'BOUNDED_SPAWN_DEADLINES_INVALID')
        _require(execution_report is None or not execution_report, 'BOUNDED_SPAWN_REPORT_INVALID')
        _require(resource_release_report is None or not resource_release_report,
            'BOUNDED_SPAWN_RELEASE_REPORT_INVALID')
        batch = SimpleNamespace(function=function, tasks=tasks, pending=deque(order),
            results=[_READY_MISSING]*n, remaining=n, active=0, released=set(), event=Event(), error=None,
            maximum=min(self.ceiling, resolve_pool_workers(selected_slots)),
            estimates=stage[0], admission=stage[1], report=execution_report,
            timeout=timeout, deadlines=task_deadlines, on_result=on_result,
            release_report=resource_release_report)
        # Only paths absent at submission can earn credit for this batch's
        # own newly written retained bytes. Existing data never earns it twice.
        paths = stage[0].get('task_write_paths') or [()] * n
        batch.new_paths = [tuple(Path(p) for p in row if not os.path.lexists(p)) for row in paths]
        self.inbox.put(('batch', batch))
        while not batch.event.wait(.05):
            self.check()
        if batch.error is not None:
            raise batch.error
        return batch.results

    def _admission(self, batches):
        def written():
            stamps = {}
            seen = set()
            for batch, index, _, releasing in self.active.values():
                if releasing or not any(batch is b for b in batches):
                    continue
                for path in getattr(batch, 'new_paths', [()] * len(batch.results))[index]:
                    try:
                        value = path.lstat()
                    except OSError:
                        continue
                    key = (value.st_dev, value.st_ino)
                    if not stat.S_ISREG(value.st_mode) or value.st_nlink != 1 or key in seen:
                        continue
                    seen.add(key)
                    stamps[id(batch), index, str(path)] = (_cache_stamp(value), min(value.st_size, value.st_blocks * 512))
            return stamps
        if not self.dispatching or self.dispatch_observation is None:
            before = written()
            self.dispatch_observation = observe_execution_resources(self.root)
            after = written()
            self.dispatch_written_credits = {}
            for (batch_id, index, path), value in before.items():
                if after.get((batch_id, index, path)) == value:
                    key = (batch_id, index)
                    self.dispatch_written_credits[key] = self.dispatch_written_credits.get(key, 0) + value[1]
        credits = self.dispatch_written_credits
        sizes = []
        for batch in batches:
            estimate = batch.estimates
            disk = estimate.get('task_disk_bytes')
            if disk is not None:
                # Scientific OK has published its bytes and its parent callback
                # has returned before this sole driver can admit more work.
                # Live free space already charges them; cleanup ACK still owns
                # the worker slot and transient/memory budget until it returns.
                future = [(max(0, row[0] - credits.get((id(batch), index), 0)), row[1])
                          for index, (row, result) in enumerate(zip(disk, batch.results, strict=True))
                          if result is _READY_MISSING]
                estimate = {**estimate, 'retained_bytes': sum(row[0] for row in future),
                    'publication_bytes': max((row[1] for row in future), default=0)}
            sizes.append(estimate)
        return admit_stage(self.policy, self.root,
            legal_tasks=max(1, sum(len(b.pending)+b.active for b in batches)),
            retained_bytes=sum(s['retained_bytes'] for s in sizes),
            publication_bytes=sum(s['publication_bytes'] for s in sizes),
            transient_bytes_per_worker=max(s['transient_bytes_per_worker'] for s in sizes),
            memory_bytes_per_worker=max(s['memory_bytes_per_worker'] for s in sizes),
            _observation=self.dispatch_observation)

    def _accept(self):
        if not self.admission_dirty:
            return
        waiting = len(self.waiting)
        for _ in range(waiting):
            batch = self.waiting.popleft()
            try:
                admitted = self._admission([*self.batches, batch])
            except ContractError as error:
                if not str(error).startswith('RESOURCE_ADMISSION_ZERO'):
                    raise
                batch.error = error
                self.waiting.append(batch)
                continue
            batch.error = None
            self.cache_generation += 1
            batch.cache_scope = self.cache_generation
            batch.admission.clear(); batch.admission.update(admitted)
            self.capacity = min(self.ceiling, admitted['admitted_worker_ceiling'])
            if batch.report is not None:
                batch.report.update(configured_worker_ceiling=resolve_pool_workers(None),
                    admitted_worker_ceiling=min(batch.maximum,self.capacity),
                    runnable_task_count=len(batch.tasks), actual_worker_process_peak=0,
                    completed_task_count=0, engine_threads=1, status='RUNNING')
            self.batches.append(batch)
        if not self.batches and self.waiting and not self.active:
            if not self._defer_admission(self.waiting[0].error):
                raise self.waiting[0].error

    def _defer_admission(self, error):
        if not str(error).startswith('RESOURCE_ADMISSION_ZERO:'):
            return False
        try:
            limits = strict_json_bytes(str(error).partition(':')[2].encode())['limits']
            memory_only = limits['memory'] == 0 and all(
                value > 0 for name,value in limits.items() if name != 'memory')
        except (ContractError, KeyError, TypeError):
            memory_only = False
        if memory_only and not self.retiring:
            for receiver in tuple(self.idle):
                if receiver in self.warm:
                    self._retire_idle(receiver)
                    break  # Remeasure the actual exit before discarding useful peers.
        # In-flight science/ACK/READY and registered exits can still progress.
        # None of their occupied memory or process slots is credited in advance.
        return bool(self.active or self.starting or self.retiring)

    def _retire_idle(self, receiver):
        """End a completed idle process, preserving every live scientific task."""
        _require(receiver in self.idle and receiver in self.warm
            and receiver not in self.active, 'BOUNDED_SPAWN_RELEASE_OWNER_UNKNOWN')
        process = self.processes[receiver]
        _require(process.pid in self.owned, 'BOUNDED_SPAWN_RELEASE_OWNER_UNKNOWN')
        self.idle.remove(receiver)
        self.warm.remove(receiver)
        self.retiring[receiver] = [monotonic()+_RELEASE_TERMINATE_GRACE_SECONDS, 0]
        try:
            receiver.send(None)
        except (OSError, EOFError):
            pass  # Its recorded process group must still be confirmed gone.

    def _next(self):
        for _ in range(len(self.batches)):
            batch = self.batches[0]
            self.batches.rotate(-1)
            if batch.pending and batch.active < batch.maximum:
                return batch, batch.pending.popleft()
        return None

    def _launch(self):
        context = get_context('spawn')
        receiver, sender = context.Pipe(duplex=True)
        process = context.Process(target=_spawn_task_entry, args=(_ready_leaf,sender,True))
        process.start(); sender.close()
        self.processes[receiver] = process
        self.starting[receiver] = monotonic()+30
        self.report['worker_process_peak'] = max(self.report['worker_process_peak'], len(self.processes))
        self.report['worker_pids'].append(process.pid)

    def _fill(self):
        if not self.admission_dirty:
            return
        self.admission_dirty = False
        self.admission_retry_at = math.inf
        ready = sum(min(len(b.pending), max(0, b.maximum-b.active)) for b in self.batches)
        if not ready:
            if self.waiting and self.retiring:
                return  # One measured exit may make the waiting stage affordable.
            # A stage need not wait for another family to finish before its
            # unused imports, native allocators and prepared inputs disappear.
            for receiver in tuple(self.idle):
                if receiver in self.warm:
                    self._retire_idle(receiver)
            if self.waiting and not self.retiring and len(self.active)+len(self.starting) < self.ceiling:
                self.admission_retry_at = monotonic()+5
            return
        if self.batches:
            try:
                live_admission = self._admission(list(self.batches))
                self.capacity = min(self.ceiling,live_admission['admitted_worker_ceiling'])
                for batch in self.batches:
                    if self.capacity > batch.admission['admitted_worker_ceiling']:
                        batch.admission.clear(); batch.admission.update(live_admission)
                    if batch.report is not None:
                        batch.report['admitted_worker_ceiling'] = max(
                            batch.report['admitted_worker_ceiling'],min(batch.maximum,self.capacity))
            except ContractError as error:
                if not self._defer_admission(error):
                    raise
                self.admission_retry_at = monotonic()+5
                return  # Existing fits finish; do not admit another allocation yet.
        # Retiring groups still occupy process slots. Other genuinely available
        # slots may dispatch; one exit must not stop all independent families.
        need = min(self.capacity, ready+len(self.active))
        while len(self.processes) < need:
            self._launch()
        while self.idle and len(self.active) < self.capacity:
            picked = self._next()
            if picked is None:
                break
            batch,index = picked
            receiver = self.idle.popleft()
            deadline = monotonic()+batch.timeout
            if batch.deadlines is not None:
                if batch.deadlines[index] is None:
                    batch.deadlines[index] = deadline
                deadline = batch.deadlines[index]
            _require(deadline > monotonic(), 'BOUNDED_SPAWN_TASK_DEADLINE_EXCEEDED')
            batch.active += 1
            if batch.report is not None:
                batch.report['actual_worker_process_peak'] = max(batch.report['actual_worker_process_peak'],batch.active)
            self.active[receiver] = [batch,index,deadline,False]
            # Scope tags are ephemeral cache bookkeeping, never science IDs.
            # Immediate reuse retains live prepared data; ended stages are
            # dropped before the next real task. Unused warm slots exit below.
            reuse = getattr(batch.function, 'reuse_worker_function', False) is True
            function = (None if reuse and self.bound_function_scopes.get(receiver) == batch.cache_scope
                        else batch.function)
            call = (function,batch.tasks[index],batch.cache_scope,tuple(b.cache_scope for b in self.batches))
            if reuse and function is not None:
                # ForkingPickler drops functools.partial.__dict__. Send these
                # operational hints explicitly once, outside its reducer.
                call += ({'reuse':True,'cache_files':getattr(function,'cache_files',None)},)
            receiver.send((index,call,deadline))
            if reuse:
                self.bound_function_scopes[receiver] = batch.cache_scope
            else:
                self.bound_function_scopes.pop(receiver, None)
        for receiver in tuple(self.idle):
            if receiver in self.warm:
                self._retire_idle(receiver)
        if len(self.active)+len(self.starting) < self.ceiling and (self.waiting or any(
                b.pending and b.active < b.maximum for b in self.batches)):
            # External archive/owner allocations can disappear without a pool
            # message. Only a genuinely resource-limited ready queue retries.
            self.admission_retry_at = monotonic()+5

    def _message(self, receiver):
        self.admission_dirty = True
        process = self.processes[receiver]
        read_error = None
        try:
            value = receiver.recv()
        except Exception as error:
            if receiver in self.starting or not self.active[receiver][3]:
                raise ContractError('BOUNDED_SPAWN_CHILD_FAILED:' + type(error).__name__) from error
            read_error, value = error, None
        if receiver in self.starting:
            _require(value == {'status':'READY','process_group':process.pid},
                'BOUNDED_SPAWN_PROCESS_GROUP_INVALID')
            del self.starting[receiver]
            self.owned.add(process.pid)
            if _POOL_GROUP_OBSERVER is not None:
                _POOL_GROUP_OBSERVER(process.pid)
            self.idle.append(receiver)
            return
        batch,index,deadline,releasing = self.active[receiver]
        if not releasing:
            _require(isinstance(value,dict) and value.get('index') == index,
                'BOUNDED_SPAWN_RESULT_PROTOCOL_INVALID')
            _require(monotonic() < deadline, 'BOUNDED_SPAWN_TASK_DEADLINE_EXCEEDED')
            if value.get('status') != 'OK':
                raise ContractError(f"BOUNDED_SPAWN_CHILD_FAILED:{index}:{value.get('error_type')}:{value.get('error_message')}")
            result = value.get('result')
            _require(result is not None, 'BOUNDED_SPAWN_RESULT_MISSING')
            batch.results[index] = result
            if batch.on_result is not None:
                batch.on_result(index,result)
            if batch.report is not None:
                batch.report['completed_task_count'] += 1
            # Phase barrier includes release ACK: its thread may safely link
            # next-stage aliases only after every previous reader returned.
            # The scientific result met its deadline; cleanup is not a second
            # scientific task and must not invalidate an already consumed OK.
            self.active[receiver][2] = math.inf
            self.active[receiver][3] = True
            self.release_waits[receiver] = [monotonic()+_RELEASE_WAIT_SECONDS, 0]
            return
        try:
            if read_error is not None:
                raise ContractError('BOUNDED_SPAWN_RELEASE_RECEIVE_FAILED:' + type(read_error).__name__)
            _require(isinstance(value,dict) and set(value)=={'status','index','resource_release'}
                and value['status']=='RELEASED' and value['index']==index,
                'BOUNDED_SPAWN_RELEASE_REPORT_INVALID')
            release = value['resource_release']
            validate_resource_release(release)
            _require(release['owner'] == f'POOL_TASK_RESULT:{index}'
                and (release.get('pid') if release.get('status')=='UNKNOWN' else release.get('before',{}).get('pid'))==process.pid,
                'BOUNDED_SPAWN_RELEASE_REPORT_INVALID')
        except (ContractError,KeyError,TypeError) as error:
            # Existing retained scientific OK is not invalidated by diagnostics.
            release = {'status':'UNKNOWN','owner':f'POOL_TASK_RESULT:{index}',
                'pid':process.pid,'reason':str(error)}
        if read_error is not None:
            # EOF proves neither leader nor native-descendant exit. Retain
            # the completed result while the existing group retirement proves it.
            if batch.release_report is not None:
                batch.release_report[str(index)] = release
            self.release_waits[receiver] = [monotonic(), 0]
            return
        self._finish_release(receiver, release, retire=read_error is not None)

    def _finish_release(self, receiver, release, *, retire):
        self.admission_dirty = True
        process = self.processes[receiver]
        batch,index,_,_ = self.active[receiver]
        if batch.release_report is not None:
            batch.release_report[str(index)] = release
        if retire:
            _compensate_task_cache(batch.function, batch.tasks[index])
            self.owned.discard(process.pid)
            self.warm.discard(receiver)
            self.bound_function_scopes.pop(receiver, None)
            receiver.close(); process.close()
            del self.processes[receiver]
        else:
            self.idle.append(receiver)
            self.warm.add(receiver)
        self.release_waits.pop(receiver, None)
        batch.active -= 1; batch.remaining -= 1
        del self.active[receiver]
        if batch.remaining == 0:
            self.batches.remove(batch)
            if batch.report is not None:
                batch.report['status'] = 'COMPLETED'
            batch.event.set()

    def advance(self):
        # One fresh light observation per actual dispatch event, shared by the
        # accept/fill calculations in this event only. Never credit hints.
        self.dispatch_observation = None
        if monotonic() >= self.admission_retry_at:
            self.admission_dirty = True
            self.admission_retry_at = math.inf
        for receiver,state in list(self.retiring.items()):
            process = self.processes[receiver]
            if _advance_release_timeout(process, state, owns_group=process.pid in self.owned):
                self.owned.discard(process.pid)
                self.bound_function_scopes.pop(receiver, None)
                receiver.close(); process.close()
                del self.processes[receiver]
                del self.retiring[receiver]
                self.admission_dirty = True
        for receiver,state in list(self.release_waits.items()):
            if state[1] or monotonic() >= state[0]:
                process = self.processes[receiver]
                batch,index,_,_ = self.active[receiver]
                release = {'status':'UNKNOWN','owner':f'POOL_TASK_RESULT:{index}',
                    'pid':process.pid,'reason':'BOUNDED_SPAWN_RELEASE_ACK_TIMEOUT'}
                if batch.release_report is not None:
                    batch.release_report[str(index)] = release
                if _advance_release_timeout(process, state, owns_group=process.pid in self.owned):
                    self._finish_release(receiver, release, retire=True)
        while True:
            try: kind,value = self.inbox.get_nowait()
            except Empty: break
            if kind == 'error': raise value
            if kind == 'finished': self.completed_families += 1
            if kind == 'batch':
                self.waiting.append(value)
                self.admission_dirty = True
        self.dispatching = True
        try:
            self._accept(); self._fill()
        finally:
            self.dispatching = False
            self.dispatch_observation = None
        now=monotonic()
        _require(all(d>now for d in self.starting.values()), 'BOUNDED_SPAWN_STARTUP_TIMEOUT')
        for b in [*self.batches,*self.waiting]:
            if b.deadlines is not None:
                _require(all(d is None or b.results[i] is not _READY_MISSING or d>now
                    for i,d in enumerate(b.deadlines)), 'BOUNDED_SPAWN_TASK_DEADLINE_EXCEEDED')
        _require(all(deadline>now for _,_,deadline,_ in self.active.values()),
            'BOUNDED_SPAWN_TASK_DEADLINE_EXCEEDED')
        readers=[*self.starting, *(r for r in self.active
            if r not in self.release_waits or self.release_waits[r][1] == 0)]
        if readers:
            for receiver in wait_connections(readers,timeout=.05):
                self._message(receiver)
        else:
            self.cancelled.wait(.01)

    def abort(self, error):
        self.failure=error; self.cancelled.set()
        while True:
            try:
                kind,value=self.inbox.get_nowait()
                if kind=='batch': self.waiting.append(value)
            except Empty: break
        for b in [*self.batches,*self.waiting]:
            b.error=error
            if b.report is not None: b.report['status']='FAILED'
            b.event.set()

    def close(self, failed=False):
        def kill(p,sig):
            _signal_pool_process(p, sig, owns_group=p.pid in self.owned)
        failures=[]
        rows=list(self.processes.items())
        for receiver,p in rows:
            if failed:
                try: kill(p,signal.SIGTERM)
                except Exception as error: failures.append(error)
            else:
                try: receiver.send(None)
                except (OSError,EOFError): pass
        gone, errors = _wait_pool_exits([p for _,p in rows], self.owned, terminated=failed)
        failures.extend(errors)
        for receiver,p in rows:
            if p not in gone:
                continue
            try:
                if receiver in self.active:
                    batch,index,_,_ = self.active[receiver]
                    _compensate_task_cache(batch.function, batch.tasks[index])
                self.owned.discard(p.pid)
                self.bound_function_scopes.pop(receiver, None)
                receiver.close(); p.close()
                del self.processes[receiver]
            except Exception as error:
                failures.append(error)
        if failures:
            raise failures[0]


def run_ready_families(calls, *, policy, root, workers=None, report=None):
    """Calls are parent-only closures in canonical family order; no science fork."""
    _require(not _IN_SCIENTIFIC_POOL and current_ready_pool() is None and bool(calls),
        'NESTED_SCIENTIFIC_POOL_FORBIDDEN')
    report={} if report is None else report
    report.update(worker_process_peak=0,worker_pids=[],status='RUNNING')
    pool=_ReadyPool(policy,root,workers,report)
    _require(_POOL_MAIN_LOCK.acquire(blocking=False),'CONCURRENT_SCIENTIFIC_POOL_FORBIDDEN')
    answers=[_READY_MISSING]*len(calls)
    def coordinate(i,call):
        _READY_FAMILY_LOCAL.pool=pool; _READY_FAMILY_LOCAL.stage=None
        try:
            answers[i]=call()
            pool.check()
            _require(_READY_FAMILY_LOCAL.stage is None,'READY_STAGE_NOT_SUBMITTED')
        except BaseException as error:
            pool.inbox.put(('error',error))
        finally:
            _READY_FAMILY_LOCAL.pool=None; _READY_FAMILY_LOCAL.stage=None
            pool.inbox.put(('finished',i))
    threads=[Thread(target=coordinate,args=(i,call),name=f'Q-family-{i}') for i,call in enumerate(calls)]
    try:
        for thread in threads: thread.start()
        while pool.completed_families < len(threads) or pool.retiring: pool.advance()
        _require(not pool.batches and not pool.waiting and not pool.active,'READY_POOL_UNFINISHED')
        pool.close()
        report['status']='COMPLETED'
        return answers
    except BaseException as error:
        pool.abort(error)
        pool.close(failed=True)
        report['status']='FAILED'
        raise
    finally:
        # Never return to the host owner while a coordinator can still publish.
        for thread in threads:
            if thread.ident is not None: thread.join()
        _POOL_MAIN_LOCK.release()


def _cancel_owned_task(signum: int, frame: Any) -> None:
    # subprocess.run catches BaseException, kills and waits for its native
    # child. A default SIGTERM exit would abandon that R process instead.
    raise SystemExit("BOUNDED_SPAWN_CANCELLED")


def _spawn_task_entry(
    worker: Callable[[_Task], _Result], connection: Any, capture_release: bool = False
) -> None:
    global _IN_SCIENTIFIC_POOL, _ACTIVE_TASK_DEADLINE
    _IN_SCIENTIFIC_POOL = True
    os.setsid()
    signal.signal(signal.SIGTERM, _cancel_owned_task)
    os.environ.update(THREAD_ENV)
    completed_tasks = 0
    bound_function = None
    try:
        connection.send({"status": "READY", "process_group": os.getpgrp()})
        while True:
            message = connection.recv()
            if message is None:
                return
            index, task, _ACTIVE_TASK_DEADLINE = message
            if worker is _ready_leaf:
                metadata = None
                if len(task) == 5:
                    *parts, metadata = task
                    task = tuple(parts)
                    del parts
                    _require(isinstance(metadata,dict) and set(metadata)=={'reuse','cache_files'}
                        and metadata['reuse'] is True and task[0] is not None
                        and (metadata['cache_files'] is None or callable(metadata['cache_files'])),
                        'READY_FUNCTION_METADATA_INVALID')
                function, argument, scope, live_scopes = task
                if function is None:
                    _require(bound_function is not None and bound_function[0] == scope
                        and scope in live_scopes, 'READY_FUNCTION_SCOPE_DRIFT')
                    function = bound_function[1]
                    task = (function, argument, scope, live_scopes)
                else:
                    if metadata is not None:
                        function.cache_files = metadata['cache_files']
                    bound_function = (scope, function) if metadata is not None else None
                del function, argument, scope, live_scopes, metadata
            cache_files = _task_cache_files(worker, task)
            mark_cache_use(cache_files)
            try:
                payload = {"status": "OK", "index": index, "result": worker(task)}
            except BaseException as error:
                payload = {
                    "status": "ERROR",
                    "index": index,
                    "error_type": type(error).__name__,
                    "error_message": "\n".join([str(error),
                        *(str(note) for note in getattr(error, "__notes__", []))]),
                }
            finally:
                _ACTIVE_TASK_DEADLINE = None
            succeeded = payload["status"] == "OK"
            connection.send(payload)
            before = None
            release_error = None
            sample_memory = completed_tasks % 16 == 0
            if capture_release and succeeded:
                try:
                    before = observe_step_memory() if sample_memory else observe_step_memory(detailed=False)
                except (OSError, ContractError, ValueError) as error:
                    release_error = type(error).__name__ + ":" + str(error)
            # The parent owns the serialized result now. Do not retain the
            # previous step's objects while this worker starts its next task.
            del payload, task, message
            gc.collect()
            advise_completed_io(cache_files, new_consumption=False)
            del cache_files
            drain_completed_io()
            if not succeeded:
                return
            if capture_release:
                try:
                    if release_error is not None:
                        raise ContractError(release_error)
                    release = release_step_resources([], owner=f"POOL_TASK_RESULT:{index}", before=before,
                        released_references=["serialized_result", "task", "received_message"],
                        sample_memory=sample_memory)
                except (OSError, ContractError, ValueError) as error:
                    release = {"status": "UNKNOWN", "owner": f"POOL_TASK_RESULT:{index}",
                        "pid": os.getpid(), "reason": type(error).__name__ + ":" + str(error)}
                connection.send({"status": "RELEASED", "index": index, "resource_release": release})
                del release, before
            else:
                gc.collect()
            completed_tasks += 1
    finally:
        gc.collect()
        drain_completed_io()
        connection.close()


def _bounded_ordered_spawn(
    worker: Callable[[_Task], _Result],
    tasks: Sequence[_Task],
    *,
    selected_slots: int | None = None,
    on_result: Callable[[int, _Result], None] | None = None,
    schedule_order: Sequence[int] | None = None,
    execution_report: dict[str, Any] | None = None,
    task_deadlines: list[float | None] | None = None,
    task_timeout_seconds: float | None = None,
    resource_release_report: dict[str, Any] | None = None,
) -> list[_Result]:
    """Dynamically refill one pool and return results in canonical task order.

    ``schedule_order`` may prioritize known long-tail coordinates without
    changing task identities, RNG, or reduction order.  It must be an exact
    permutation of the canonical task indices; results remain indexed by the
    original ``tasks`` sequence.

    ``task_deadlines`` optionally carries this coordinator's absolute monotonic
    deadlines across phases of the same coordinates. None entries are set on
    first dispatch; existing entries are never extended, including while queued.
    This is call-local bookkeeping, not a persisted resume or scheduling record.
    FULL0 final/SHAP may explicitly request 24 hours; workers receive the same
    absolute deadline so native calls use only the remaining coordinate budget.
    """

    _require(
        (selected_slots is None or type(selected_slots) is int and selected_slots >= 1)
        and isinstance(tasks, Sequence)
        and not isinstance(tasks, (str, bytes))
        and bool(tasks),
        "BOUNDED_SPAWN_INPUT_INVALID",
    )
    _require(not _IN_SCIENTIFIC_POOL, "NESTED_SCIENTIFIC_POOL_FORBIDDEN")
    shared = current_ready_pool()
    if shared is not None:
        return shared.map(worker, tasks, selected_slots=selected_slots, on_result=on_result,
            schedule_order=schedule_order, execution_report=execution_report,
            task_deadlines=task_deadlines, task_timeout_seconds=task_timeout_seconds,
            resource_release_report=resource_release_report)
    timeout = _TASK_DEADLINE_SECONDS if task_timeout_seconds is None else task_timeout_seconds
    _require(type(timeout) in {int, float} and math.isfinite(timeout) and 0 < timeout <= 24 * 60 * 60,
             "BOUNDED_SPAWN_TIMEOUT_INVALID")
    now = monotonic()
    _require(task_deadlines is None or isinstance(task_deadlines, list)
             and len(task_deadlines) == len(tasks)
             and all(deadline is None or type(deadline) in {int, float}
                     and math.isfinite(deadline) and 0 < deadline <= now + timeout
                     for deadline in task_deadlines), "BOUNDED_SPAWN_DEADLINES_INVALID")
    selected_slots = resolve_pool_workers(selected_slots)
    _require(resource_release_report is None or isinstance(resource_release_report, dict) and not resource_release_report,
             "BOUNDED_SPAWN_RELEASE_REPORT_INVALID")
    effective_workers = min(selected_slots, len(tasks))
    if execution_report is not None:
        _require(isinstance(execution_report, dict) and not execution_report,
                 "BOUNDED_SPAWN_REPORT_INVALID")
        execution_report.update(configured_worker_ceiling=resolve_pool_workers(None),
            admitted_worker_ceiling=selected_slots, runnable_task_count=len(tasks),
            actual_worker_process_peak=0, completed_task_count=0, engine_threads=1,
            status="RUNNING")
    pending = (
        list(range(len(tasks)))
        if schedule_order is None
        else list(schedule_order)
    )
    _require(
        len(pending) == len(tasks)
        and all(type(index) is int for index in pending)
        and set(pending) == set(range(len(tasks))),
        "BOUNDED_SPAWN_SCHEDULE_INVALID",
    )
    results: list[Any] = [_MISSING] * len(tasks)
    context = get_context("spawn")
    active: dict[Any, tuple[int, Any, float]] = {}
    starting: set[Any] = set()
    releasing: set[Any] = set()
    release_waits: dict[Any, list] = {}
    retiring: list[Any] = []
    retiring_tasks = {}
    previous_cleanup = {}
    owned_groups: set[int] = set()
    next_position = 0

    def check_carried_deadlines() -> float:
        deadline = min((value for index, value in enumerate(task_deadlines or [])
                        if value is not None and results[index] is _MISSING), default=math.inf)
        _require(deadline > monotonic(), "BOUNDED_SPAWN_TASK_DEADLINE_EXCEEDED")
        return deadline

    def dispatch(receiver: Any, index: int, process: Any) -> None:
        check_carried_deadlines()
        deadline = monotonic() + timeout
        if task_deadlines is not None:
            if task_deadlines[index] is None:
                task_deadlines[index] = deadline
            deadline = task_deadlines[index]
        check_carried_deadlines()
        receiver.send((index, tasks[index], deadline))
        active[receiver] = (index, process, deadline)

    def launch(index: int) -> None:
        receiver, sender = context.Pipe(duplex=True)
        process = context.Process(target=_spawn_task_entry,
                                  args=(worker, sender, resource_release_report is not None))
        process.start()
        sender.close()
        # Start the whole admitted set before waiting for individual READY
        # messages. No task is sent until that child's process group is known.
        active[receiver] = (index, process, monotonic() + 30)
        starting.add(receiver)
        if execution_report is not None:
            execution_report["actual_worker_process_peak"] = max(
                execution_report["actual_worker_process_peak"],
                sum(row[1].is_alive() for row in active.values()))

    def signal_owned(process: Any, signum: int) -> None:
        # No READY acknowledgement means no task/native child was started.
        _signal_pool_process(process, signum, owns_group=process.pid in owned_groups)

    def terminate_active() -> None:
        rows = list(active.items())
        failures = []
        for receiver, (_, process, _) in rows:
            receiver.close()
            try:
                signal_owned(process, signal.SIGTERM)
            except Exception as error:
                failures.append(error)
        gone, errors = _wait_pool_exits([p for _,(_,p,_) in rows], owned_groups, terminated=True)
        failures.extend(errors)
        for receiver, (index, process, _) in rows:
            if process not in gone:
                continue
            try:
                if receiver not in starting:
                    previous = previous_cleanup.pop(receiver, None)
                    if previous is not None and previous != index:
                        _compensate_task_cache(worker, tasks[previous])
                    _compensate_task_cache(worker, tasks[index])
                owned_groups.discard(process.pid)
                process.close()
                active.pop(receiver, None)
                starting.discard(receiver)
            except Exception as error:
                failures.append(error)
        if failures:
            raise failures[0]

    # The existing coordinator may flatten several tasks into this one pool;
    # callbacks/threads cannot obtain an additional budget in the same process.
    # Separate host commands are serialized by the existing dispatch owner.
    _require(_POOL_MAIN_LOCK.acquire(blocking=False), "CONCURRENT_SCIENTIFIC_POOL_FORBIDDEN")
    try:
        check_carried_deadlines()
        while next_position < len(pending) and len(active) < effective_workers:
            launch(pending[next_position])
            next_position += 1
        # Reconcile startup before invoking any result callback, as the
        # original launch loop did. Workers already acknowledged may compute
        # while their peers start; their results remain on the original pipes.
        while starting:
            carried_deadline = check_carried_deadlines()
            remaining = min(carried_deadline, *(active[receiver][2] for receiver in starting)) - monotonic()
            ready = wait_connections(list(starting), timeout=max(0.0, min(1.0, remaining)))
            check_carried_deadlines()
            _require(ready or remaining > 0, "BOUNDED_SPAWN_STARTUP_TIMEOUT")
            for receiver in sorted(ready, key=lambda item: active[item][0]):
                index, process, _ = active[receiver]
                try:
                    payload = receiver.recv()
                except EOFError:
                    payload = None
                _require(payload == {"status": "READY", "process_group": process.pid},
                         "BOUNDED_SPAWN_PROCESS_GROUP_INVALID")
                starting.remove(receiver)
                owned_groups.add(process.pid)
                if _POOL_GROUP_OBSERVER is not None:
                    _POOL_GROUP_OBSERVER(process.pid)
                dispatch(receiver, index, process)
        while active:
            for receiver,state in list(release_waits.items()):
                if state[1] or monotonic() >= state[0]:
                    index,process,_ = active[receiver]
                    resource_release_report[str(index)] = {'status':'UNKNOWN','owner':f'POOL_TASK_RESULT:{index}',
                        'pid':process.pid,'reason':'BOUNDED_SPAWN_RELEASE_ACK_TIMEOUT'}
                    if _advance_release_timeout(process, state, owns_group=process.pid in owned_groups):
                        _compensate_task_cache(worker, tasks[index])
                        owned_groups.discard(process.pid)
                        receiver.close(); process.close()
                        del active[receiver]; del release_waits[receiver]; releasing.remove(receiver)
                        if next_position < len(pending):
                            launch(pending[next_position]); next_position += 1
            if not active:
                break
            remaining = min(check_carried_deadlines(), *(row[2] for row in active.values())) - monotonic()
            _require(remaining > 0, "BOUNDED_SPAWN_TASK_DEADLINE_EXCEEDED")
            readers = [r for r in active if r not in release_waits or release_waits[r][1] == 0]
            wait_limit = min((max(0.0,s[0]-monotonic()) for s in release_waits.values()), default=1.0)
            if any(s[1] for s in release_waits.values()):
                wait_limit = min(wait_limit,.05)
            ready = wait_connections(readers, timeout=min(1.0,wait_limit,remaining))
            for receiver in sorted(ready, key=lambda item: active[item][0]):
                check_carried_deadlines()
                index, process, deadline = active[receiver]
                _require(deadline > monotonic(), "BOUNDED_SPAWN_TASK_DEADLINE_EXCEEDED")
                read_error = None
                try:
                    payload = receiver.recv()
                except EOFError as error:
                    read_error = error
                    payload = {"status": "ERROR", "index": index, "error_type": "ChildExit", "error_message": "pipe closed"}
                except Exception as error:
                    if receiver not in releasing:
                        raise
                    read_error, payload = error, None
                if receiver in starting:
                    _require(payload == {"status": "READY", "process_group": process.pid},
                             "BOUNDED_SPAWN_PROCESS_GROUP_INVALID")
                    starting.remove(receiver)
                    owned_groups.add(process.pid)
                    if _POOL_GROUP_OBSERVER is not None:
                        _POOL_GROUP_OBSERVER(process.pid)
                    dispatch(receiver, index, process)
                    continue
                if receiver in releasing:
                    releasing.remove(receiver)
                    release_waits.pop(receiver, None)
                    try:
                        if read_error is not None:
                            raise ContractError("BOUNDED_SPAWN_RELEASE_RECEIVE_FAILED:"
                                                + type(read_error).__name__ + ":" + str(read_error))
                        _require(isinstance(payload, dict) and set(payload) == {"status", "index", "resource_release"}
                                 and payload["status"] == "RELEASED" and payload["index"] == index,
                                 "BOUNDED_SPAWN_RELEASE_REPORT_INVALID")
                        release = payload["resource_release"]
                        validate_resource_release(release)
                        _require(release["owner"] == f"POOL_TASK_RESULT:{index}"
                                 and (release.get("pid") if release.get("status") == "UNKNOWN"
                                      else release.get("before", {}).get("pid")) == process.pid,
                                 "BOUNDED_SPAWN_RELEASE_REPORT_INVALID")
                        resource_release_report[str(index)] = release
                    except (ContractError, KeyError, TypeError) as error:
                        # The scientific OK and callback were already retained.
                        # Missing diagnostics never invalidate a retained OK.
                        resource_release_report[str(index)] = {"status": "UNKNOWN", "owner": f"POOL_TASK_RESULT:{index}",
                            "pid": process.pid, "reason": str(error)}
                    if read_error is not None:
                        # Preserve OK; the original event loop proves the entire
                        # registered group gone before allocating its replacement.
                        releasing.add(receiver)
                        release_waits[receiver] = [monotonic(), 0]
                    elif next_position < len(pending):
                        dispatch(receiver, pending[next_position], process)
                        next_position += 1
                    else:
                        try:
                            receiver.send(None)
                        except (OSError, EOFError):
                            pass
                        receiver.close()
                        retiring.append(process)
                        retiring_tasks[process] = index
                        active.pop(receiver)
                    continue
                if not isinstance(payload, dict) or payload.get("index") != index or payload.get("status") != "OK":
                    terminate_active()
                    failure = payload if isinstance(payload, dict) else {}
                    raise ContractError(
                        f"BOUNDED_SPAWN_CHILD_FAILED:{index}:{failure.get('error_type', 'PROTOCOL')}:{failure.get('error_message', '')}"
                    )
                result = payload.get("result")
                _require(result is not None, "BOUNDED_SPAWN_RESULT_MISSING")
                check_carried_deadlines()
                _require(deadline > monotonic(), "BOUNDED_SPAWN_TASK_DEADLINE_EXCEEDED")
                results[index] = result
                # This result proves the child's preceding cleanup finished.
                previous_cleanup.pop(receiver, None)
                if execution_report is not None:
                    execution_report["completed_task_count"] += 1
                if resource_release_report is not None:
                    if on_result is not None:
                        on_result(index, result)
                    releasing.add(receiver)
                    # Its science deadline was satisfied by OK. The same event
                    # loop can receive other scientific results while this PID
                    # releases references; no second timeout cancels peers.
                    active[receiver] = (index, process, math.inf)
                    release_waits[receiver] = [monotonic()+_RELEASE_WAIT_SECONDS, 0]
                    continue
                if next_position < len(pending):
                    next_index = pending[next_position]
                    previous_cleanup[receiver] = index
                    dispatch(receiver, next_index, process)
                    next_position += 1
                else:
                    receiver.send(None)
                    receiver.close()
                    retiring.append(process)
                    retiring_tasks[process] = index
                    active.pop(receiver)
                # This slot can compute its next independent coordinate while
                # the original serial callback retains the completed one.
                # Do not defer that callback past another child's failure.
                if on_result is not None:
                    on_result(index, result)
    except BaseException:
        if execution_report is not None:
            execution_report["status"] = "FAILED"
        terminate_active()
        raise
    finally:
        try:
            gone, errors = _wait_pool_exits(retiring, owned_groups)
            for process in gone:
                if process.exitcode != 0:
                    _compensate_task_cache(worker, tasks[retiring_tasks[process]])
                owned_groups.discard(process.pid)
                process.close()
            if errors:
                raise errors[0]
        finally:
            _POOL_MAIN_LOCK.release()
    _require(all(result is not _MISSING for result in results), "BOUNDED_SPAWN_RESULT_MISSING")
    if execution_report is not None:
        execution_report["status"] = "COMPLETED"
    return list(results)


def activated_environment() -> dict[str, str]:
    value = dict(os.environ)
    value.update(REMOTE_ENV)
    if value.get("PYTHONPYCACHEPREFIX"):
        value["PYTHONDONTWRITEBYTECODE"] = ""
    return value
