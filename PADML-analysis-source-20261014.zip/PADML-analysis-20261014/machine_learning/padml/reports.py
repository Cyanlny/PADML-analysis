"""Small final reports collected through the existing SSH dispatcher."""
from __future__ import annotations
import csv
import fcntl
import hashlib
import html
import io
import json
import os
import subprocess
import selectors
import shutil
import struct
import sys
import tempfile
import time
import zipfile
from pathlib import Path

from .bundle import ContractError, canonical_json_bytes, strict_json_bytes
from . import nested_loco as n
from .integrated import qualified_file_pins, same_batch_generations


def _need(ok, code):
    if not ok:
        raise ContractError(code)


def _persist_published(path):
    """A readable rename is not yet a durable archive completion."""
    with path.open('rb') as stream:
        os.fsync(stream.fileno())
    directory = os.open(path.parent, os.O_RDONLY)
    try:
        os.fsync(directory)
    finally:
        os.close(directory)


def _publish(path, raw, reason, *, replace=False):
    """Single dispatcher publication, including volumes without hard links."""
    _need(path.is_absolute() and path.parent.is_dir() and not path.is_symlink(), reason)
    if path.is_file():
        if path.read_bytes() == raw:
            _persist_published(path)
            return
        _need(replace, reason)
    part = path.with_name(path.name + ".part")
    _need(not part.is_symlink(), reason)
    with part.open("wb") as stream:
        stream.write(raw); stream.flush(); os.fsync(stream.fileno())
    os.replace(part, path)
    _persist_published(path)


def _archive_version(run):
    version = {'closure_version': 2}
    if 'evaluation_decision' in run:
        from .bundle import validate_sha256
        decision = run['evaluation_decision']
        validate_sha256(decision['identity_sha256'], 'archive.evaluation_decision')
        _need(n._sealed({k:v for k,v in decision.items() if k != 'identity_sha256'}) == decision,
            'ARCHIVE_EVALUATION_DECISION_DRIFT')
        version['evaluation_decision_sha256'] = decision['identity_sha256']
    if run.get('post_result_repair') is not None:
        from .f4 import post_result_repair_decision
        _need(run['post_result_repair'] == post_result_repair_decision(), 'ARCHIVE_REPAIR_DECISION_DRIFT')
        version['post_result_repair_sha256'] = run['post_result_repair']['identity_sha256']
    if run.get('curve_rmse') is not None:
        from .curve_rmse import decision
        _need(run['curve_rmse'] == decision(), 'ARCHIVE_CURVE_DECISION_DRIFT')
        version['curve_rmse_sha256'] = decision()['identity_sha256']
    if run.get('result_closure') is not None:
        from .result_closure import decision
        _need(run['result_closure'] == decision(), 'ARCHIVE_RESULT_CLOSURE_DRIFT')
        version['result_closure_sha256'] = decision()['identity_sha256']
    if run.get('evaluation_extension') is not None:
        from .evaluation_extension import decision
        _need(run['evaluation_extension'] == decision(), 'ARCHIVE_EVALUATION_EXTENSION_DRIFT')
        version['evaluation_extension_sha256'] = decision()['identity_sha256']
    if run.get('archive_transfer') is not None:
        version['archive_generation'] = validate_archive_transfer(run)['generation']
    return version


def validate_archive_transfer(run):
    from .bundle import validate_sha256
    value = run['archive_transfer']
    _need(set(value) == {'kind','generation','relay_prefix','volume','project_root','rebuild_record','controller_sources'}
        and value['kind'] == 'OSS_RELAY_V1', 'ARCHIVE_TRANSPORT_INVALID')
    validate_sha256(value['generation'],'archive.generation')
    _need(value['relay_prefix'] == 'padml-relay/'+run['run_id']+'/'+value['generation']+'/'
        and set(value['volume']) == {'uuid','mount','filesystem'}
        and bool(value['volume']['uuid']) and value['volume']['filesystem'].lower() == 'exfat'
        and Path(value['project_root']).is_absolute() and Path(value['rebuild_record']).is_absolute()
        and not Path(value['rebuild_record']).is_relative_to(Path(value['project_root'])),
        'ARCHIVE_TRANSPORT_SCOPE_INVALID')
    _need(set(value['controller_sources']) == {'raw-input.xlsx','source.zip'}, 'ARCHIVE_LOCAL_SOURCES_INCOMPLETE')
    for name, pin in value['controller_sources'].items():
        _need(set(pin) == {'path','sha256','size_bytes'} and Path(pin['path']).is_absolute()
            and not Path(pin['path']).is_relative_to(Path(value['project_root']))
            and type(pin['size_bytes']) is int and pin['size_bytes'] > 0,
            'ARCHIVE_LOCAL_SOURCE_INVALID')
        validate_sha256(pin['sha256'],'archive.local_source')
    _need(value['controller_sources']['source.zip']['sha256'] == run['source_bundle_sha256']
        and all(value['controller_sources']['raw-input.xlsx'][k] == run['raw_input'][k]
            for k in ('sha256','size_bytes')), 'ARCHIVE_LOCAL_SOURCE_DRIFT')
    return value


def _archive_receipt_path(folder, horizon, receipt, *, confirmation=False):
    name = f'H{horizon:02d}' + ('-confirmed' if confirmation else '')
    if receipt.get('evaluation_decision_sha256'):
        from .bundle import validate_sha256
        decision = validate_sha256(receipt['evaluation_decision_sha256'], 'archive.evaluation_decision')
        name += '-' + decision[:12]
    elif receipt.get('previous_window_identity'):
        name += '-closure2'
    if receipt.get('post_result_repair_sha256'):
        from .bundle import validate_sha256
        name += '-' + validate_sha256(receipt['post_result_repair_sha256'], 'archive.repair_decision')[:12]
    if receipt.get('curve_rmse_sha256'):
        from .bundle import validate_sha256
        name += '-' + validate_sha256(receipt['curve_rmse_sha256'], 'archive.curve_decision')[:12]
    if receipt.get('result_closure_sha256'):
        from .bundle import validate_sha256
        name += '-' + validate_sha256(receipt['result_closure_sha256'], 'archive.result_closure')[:12]
    if receipt.get('evaluation_extension_sha256'):
        from .bundle import validate_sha256
        name += '-' + validate_sha256(receipt['evaluation_extension_sha256'], 'archive.evaluation_extension')[:12]
    if receipt.get('archive_generation'):
        from .bundle import validate_sha256
        name += '-' + validate_sha256(receipt['archive_generation'],'archive.generation')[:12]
    return folder / (name + '.json')


def _archive_parent_receipt(folder, horizon, identity, *, confirmation=False):
    prefix = f'H{horizon:02d}' + ('-confirmed' if confirmation else '')
    paths = [folder / (prefix + '.json'), *sorted(folder.glob(prefix + '-*.json'))]
    for path in dict.fromkeys(paths):
        if path.is_file():
            value = strict_json_bytes(path.read_bytes())
            if value.get('identity_sha256') == identity:
                _need(n._sealed({k:v for k,v in value.items() if k != 'identity_sha256'}) == value,
                    'ARCHIVE_WINDOW_DRIFT')
                return value
    raise ContractError('ARCHIVE_WINDOW_PREDECESSOR_MISSING')


def _archive_appendix_pins(run, horizon, units, selections):
    """Read only the small, last-published declarations of this evaluation rule."""
    if 'evaluation_decision' not in run:
        return {}
    from .bundle import validate_relative_path, validate_sha256
    base = Path(run['run_root'])
    decision = _archive_version(run)['evaluation_decision_sha256']
    from .integrated import same_batch_generations
    from .f4 import _evaluation_check_producer
    generations = same_batch_generations(run)
    known = {u['unit_id']:u for u in run['units']}
    roots = []
    for uid in units:
        receipt = strict_json_bytes((base / 'units' / uid / 'unit.json').read_bytes())
        if receipt['status'] == 'NOT_ESTIMABLE':
            continue
        kind = known[uid]['kind']
        if kind in {'PRIMARY', 'FULL0'}:
            roots.append((f'units/{uid}/postprocess/evaluation-amendment', 'source_unit', uid))
        elif kind == 'EVALUATION':
            roots.append((f'units/{uid}/evaluation-amendment', 'target_unit', uid))
    roots.extend((f'units/EVALUATION-H{horizon:02d}/selection/{uid}/evaluation-amendment',
                  'source_unit', uid) for uid in selections)
    pins = {}
    def pin(name, value):
        name = validate_relative_path(name, 'archive.appendix.path')
        _need(isinstance(value, dict) and set(value) == {'sha256','size_bytes'}
            and type(value['size_bytes']) is int and value['size_bytes'] >= 0,
            'ARCHIVE_APPENDIX_PIN_INVALID')
        validate_sha256(value['sha256'], 'archive.appendix.sha256')
        _need(name not in pins or pins[name] == value, 'ARCHIVE_REFERENCE_ALIAS')
        pins[name] = value
    for prefix, field, uid in roots:
        path = base / prefix / 'result.json'
        if not path.is_file():
            return None
        _need(not path.is_symlink() and path.stat().st_size <= 32*1024**2,
            'ARCHIVE_APPENDIX_HEADER_INVALID')
        raw = path.read_bytes()
        value = strict_json_bytes(raw)
        _evaluation_check_producer(value,generations)
        _need(value.get('kind') == 'PADML_EVALUATION_APPENDIX_V1'
            and value.get('decision_sha256') == decision and value.get('status') == 'COMPLETED'
            and value.get(field) == uid and isinstance(value.get('sources'), dict)
            and isinstance(value.get('members'), dict)
            and n._sealed({k:v for k,v in value.items() if k != 'identity_sha256'}) == value,
            'ARCHIVE_APPENDIX_HEADER_INVALID')
        pin(prefix + '/result.json', {'sha256':hashlib.sha256(raw).hexdigest(), 'size_bytes':len(raw)})
        for name, member in value['sources'].items():
            pin(validate_relative_path(name, 'archive.appendix.source'), member)
        for name, member in value['members'].items():
            name = validate_relative_path(name, 'archive.appendix.member')
            _need(name != 'result.json', 'ARCHIVE_APPENDIX_SELF_REFERENCE')
            pin(prefix + '/' + name, member)
        if run.get('post_result_repair') is not None:
            from .f4 import _post_result_repair_read,post_result_repair_root
            target = known[value['target_unit']]
            source = known[uid] if '/selection/' in prefix else None
            repair = _post_result_repair_read(run,target,source,value)
            if repair is None: return None
            repair_path = post_result_repair_root(run,target,source)/'result.json'
            raw = repair_path.read_bytes()
            pin(str(repair_path.relative_to(base)), {'sha256':hashlib.sha256(raw).hexdigest(),'size_bytes':len(raw)})
            for ref in repair['formal_references']:
                pin(ref['path'],{k:ref[k] for k in ('sha256','size_bytes')})
            from .curve_rmse import eligible,relative_result,read_result
            if eligible(run,target,source):
                curve = read_result(run,target)
                if curve is None: return None
                curve_path = relative_result(target)
                raw = (base/curve_path).read_bytes()
                pin(curve_path,{'sha256':hashlib.sha256(raw).hexdigest(),'size_bytes':len(raw)})
                for name, member in curve['sources'].items():
                    pin(validate_relative_path(name,'archive.curve.source'),member)
            from .result_closure import eligible as closure_eligible,relative_result as closure_name,read_result as read_closure
            if closure_eligible(run,target,source):
                result = read_closure(run,target)
                if result is None: return None
                name = closure_name(target)
                raw = (base/name).read_bytes()
                pin(name,{'sha256':hashlib.sha256(raw).hexdigest(),'size_bytes':len(raw)})
                for name, member in result['sources'].items(): pin(name,member)
            from .evaluation_extension import eligible as extension_eligible,relative_result as extension_name,read_result as read_extension
            if extension_eligible(run,target,source):
                result = read_extension(run,target)
                if result is None: return None
                name = extension_name(target)
                raw = (base/name).read_bytes()
                pin(name,{'sha256':hashlib.sha256(raw).hexdigest(),'size_bytes':len(raw)})
                for name,member in result['sources'].items(): pin(name,member)
            from .evaluation_extension import clinical_eligible,clinical_name,read_clinical,GATE
            if source is None and clinical_eligible(run,target):
                result=read_clinical(run,target)
                if result is None:return None
                name=clinical_name(target);raw=(base/name).read_bytes()
                pin(name,{'sha256':hashlib.sha256(raw).hexdigest(),'size_bytes':len(raw)})
                for ref in result['formal_references']:pin(ref['path'],{k:ref[k] for k in ('sha256','size_bytes')})
    return pins


def _archive_confirmed_head(run, horizon):
    """A valid ACK must name the current inventory, independent of leaf filenames."""
    if run.get('archive_transfer') is not None:
        # This relay generation protects remote originals throughout offline and
        # environment recovery acceptance. Window ACKs alone cannot retire them.
        return None
    folder = Path(run['run_root']) / 'shared/archives'
    version = _archive_version(run)
    decision = version.get('evaluation_decision_sha256')
    suffix = decision[:12] if decision else None
    if version.get('post_result_repair_sha256'):
        suffix += '-' + version['post_result_repair_sha256'][:12]
    if version.get('curve_rmse_sha256'):
        suffix += '-' + version['curve_rmse_sha256'][:12]
    if version.get('result_closure_sha256'):
        suffix += '-' + version['result_closure_sha256'][:12]
    if version.get('evaluation_extension_sha256'):
        suffix += '-' + version['evaluation_extension_sha256'][:12]
    if version.get('archive_generation'):
        suffix += '-' + version['archive_generation'][:12]
    if decision:
        inventory = folder / f'H{horizon:02d}-inventory-{suffix}.json'
        acknowledgement = folder / f'H{horizon:02d}-confirmed-{suffix}.json'
    else:
        inventory = folder / f'H{horizon:02d}-inventory-closure2.json'
        if not inventory.is_file():
            inventory = folder / f'H{horizon:02d}-inventory.json'
        acknowledgement = folder / f'H{horizon:02d}-confirmed-closure2.json'
        if not acknowledgement.is_file():
            acknowledgement = folder / f'H{horizon:02d}-confirmed.json'
    if not inventory.is_file() or not acknowledgement.is_file():
        return None
    proof = strict_json_bytes(acknowledgement.read_bytes())
    declared = strict_json_bytes(inventory.read_bytes())
    _need(n._sealed({k:v for k,v in proof.items() if k != 'identity_sha256'}) == proof
        and n._sealed({k:v for k,v in declared.items() if k != 'identity_sha256'}) == declared
        and not declared.get('materials_only', False)
        and proof['run_identity'] in same_batch_generations(run)
        and declared['run_identity'] in same_batch_generations(run)
        and proof['horizon'] == declared['horizon'] == horizon and proof['status'] == 'ARCHIVED',
        'RAW_RETIREMENT_ARCHIVE_DRIFT')
    if (any(proof.get(k) != version.get(k) for k in ('closure_version','evaluation_decision_sha256','post_result_repair_sha256','curve_rmse_sha256','result_closure_sha256','evaluation_extension_sha256','archive_generation'))
            or declared['identity_sha256'] not in proof['inventories'].values()
            or any(declared.get(k) != version.get(k) for k in
                ('closure_version','evaluation_decision_sha256','post_result_repair_sha256','curve_rmse_sha256','result_closure_sha256','evaluation_extension_sha256','archive_generation'))):
        return None
    if proof.get('previous_window_identity'):
        parent = _archive_parent_receipt(folder, horizon, proof['previous_window_identity'], confirmation=True)
        _need(parent['run_identity'] in same_batch_generations(run), 'RAW_RETIREMENT_ARCHIVE_DRIFT')
    return proof, declared


def _archive_request(operation, horizon, **scope):
    import uuid
    return {'request_id': n._sha([operation, horizon, scope, uuid.uuid4().hex]),
        'operation': operation, 'horizon': horizon, **scope}


def archive_inventory(run, horizon, units, selections, *, staging=False, status_only=False,
                      sender_request=None, request=None):
    """Close declared formal references once, without scanning working trees."""
    folder = Path(run['run_root']) / 'shared/archives'
    if not status_only:
        folder.mkdir(parents=True, exist_ok=True)
    _need(not folder.is_symlink(), 'ARCHIVE_DIRECTORY_INVALID')
    queried = request if request is not None else sender_request
    if queried is not None:
        from .bundle import validate_sha256
        _need(status_only, 'ARCHIVE_REQUEST_INVALID')
        request_id = validate_sha256(queried['request_id'], 'archive.request')
        if request is not None:
            _need(request.get('operation') in {'archive_inventory','archive_confirm'}
                and request.get('horizon') == horizon, 'ARCHIVE_REQUEST_INVALID')
        # On a lost SSH reply, include the adapter's pre-import/startup period.
        # The exact request marker occurs in the original shell/Python argv,
        # never in this status probe's differently named envelope.
        observed = subprocess.run(['ps', '-eo', 'pid=,pgid=,lstart=,args='],
            capture_output=True, text=True, timeout=10, check=True)
        processes = []
        for line in observed.stdout.splitlines():
            fields = line.split(None, 7)
            if len(fields) == 8 and request_id in fields[7] and 'archive_request_id' in fields[7]:
                processes.append({'pid':int(fields[0]), 'pgid':int(fields[1]), 'started_at':' '.join(fields[2:7])})
        if processes:
            return {'status':'IN_PROGRESS', 'horizon':horizon, 'reason':'ARCHIVE_SENDER_ACTIVE',
                'request_id':request_id, 'processes':processes}
    # The directory lease survives a lost SSH response and is released by the
    # kernel when this reader exits. A retry cannot start a second heavy scan.
    if not folder.exists():
        _need(status_only, 'ARCHIVE_DIRECTORY_INVALID')
        return {'status':'IDLE', 'horizon':horizon,
            **({'request_id':queried['request_id']} if queried is not None else {})}
    descriptor = os.open(folder, os.O_RDONLY)
    try:
        try:
            fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            return {'status': 'IN_PROGRESS', 'horizon': horizon,
                    'reason': 'ARCHIVE_READER_ACTIVE',
                    **({'request_id':queried['request_id']} if queried is not None else {})}
        if status_only:
            value = {'status': 'IDLE', 'horizon': horizon,
                **({'request_id': queried['request_id']} if queried is not None else {})}
            if request is not None and request['operation'] == 'archive_confirm':
                receipt = request['receipt']
                _need(receipt['horizon'] == horizon and n._sealed({k:v for k,v in receipt.items()
                    if k != 'identity_sha256'}) == receipt, 'ARCHIVE_REQUEST_INVALID')
                path = _archive_receipt_path(folder, horizon, receipt, confirmation=True)
                if path.exists():
                    _need(not path.is_symlink() and strict_json_bytes(path.read_bytes()) == receipt,
                        'ARCHIVE_ACKNOWLEDGEMENT_DRIFT')
                    value['confirmation'] = receipt['identity_sha256']
            return value
        return _archive_inventory_locked(run, horizon, units, selections, staging=staging)
    finally:
        os.close(descriptor)


def _archive_inventory_locked(run, horizon, units, selections, *, staging=False):
    from .bundle import validate_relative_path
    base = Path(run["run_root"])
    generations = same_batch_generations(run)
    known = {u["unit_id"]: u for u in run["units"] if u["horizon"] == horizon}
    all_known = {u['unit_id']: u for u in run['units']}
    _need(set(units) <= set(known) and set(selections) <= {
        u for u, row in known.items() if row["kind"] in {"PRIMARY", "FULL0"}}, "ARCHIVE_SCOPE_INVALID")
    target = base / 'shared/archives' / f'H{horizon:02d}-inventory.json'
    closure_target = target.with_name(f'H{horizon:02d}-inventory-closure2.json')
    version = _archive_version(run)
    appendix_pins = _archive_appendix_pins(run, horizon, units, selections)
    if appendix_pins is None:
        return {'status':'IN_PROGRESS', 'horizon':horizon, 'reason':'EVALUATION_APPENDIX_PENDING'}
    decision = version.get('evaluation_decision_sha256')
    suffix = decision[:12] if decision else None
    if version.get('post_result_repair_sha256'):
        suffix += '-' + version['post_result_repair_sha256'][:12]
    if version.get('curve_rmse_sha256'):
        suffix += '-' + version['curve_rmse_sha256'][:12]
    if version.get('result_closure_sha256'):
        suffix += '-' + version['result_closure_sha256'][:12]
    prior_extension_suffix = suffix
    if version.get('evaluation_extension_sha256'):
        suffix += '-' + version['evaluation_extension_sha256'][:12]
    previous_generation = target.with_name(f'H{horizon:02d}-inventory-{suffix}.json') if suffix else None
    if version.get('archive_generation'):
        suffix += '-' + version['archive_generation'][:12]
    version_target = target.with_name(f'H{horizon:02d}-inventory-{suffix}.json') if suffix else None
    previous_evaluation = target.with_name(f'H{horizon:02d}-inventory-{decision[:12]}.json') if decision else None
    repair = version.get('post_result_repair_sha256')
    previous_repair = target.with_name(f'H{horizon:02d}-inventory-{decision[:12]}-{repair[:12]}.json') if decision and repair else None
    curve = version.get('curve_rmse_sha256')
    previous_curve = target.with_name(f'H{horizon:02d}-inventory-{decision[:12]}-{repair[:12]}-{curve[:12]}.json') if decision and repair and curve else None
    previous_closure = target.with_name(f'H{horizon:02d}-inventory-{prior_extension_suffix}.json') if prior_extension_suffix else None
    previous_path = (version_target if version_target is not None and version_target.is_file() else
        previous_generation if previous_generation is not None and previous_generation.is_file() else
        previous_closure if previous_closure is not None and previous_closure.is_file() else
        previous_curve if previous_curve is not None and previous_curve.is_file() else
        previous_repair if previous_repair is not None and previous_repair.is_file() else
        previous_evaluation if previous_evaluation is not None and previous_evaluation.is_file() else
        closure_target if closure_target.is_file() else target)
    previous = strict_json_bytes(previous_path.read_bytes()) if previous_path.is_file() else None
    qualification = target.with_name(f'H{horizon:02d}-inventory.qualified.json')
    prior_qualification = qualification
    if staging:
        scope = n._sha({**version, 'units': sorted(units), 'selections': sorted(selections),
            'materials_only': True})
        version_target = target.with_name(f'H{horizon:02d}-inventory-{scope}.json')
        qualification = target.with_name(f'H{horizon:02d}-inventory-staging-{scope}.qualified.json')
        if version_target.is_file():
            previous_path = version_target
            previous = strict_json_bytes(previous_path.read_bytes())
            prior_qualification = qualification
        elif version.get('evaluation_extension_sha256') or version.get('result_closure_sha256'):
            addition = 'evaluation_extension_sha256' if version.get('evaluation_extension_sha256') else 'result_closure_sha256'
            prior_scope = n._sha({**{k:v for k,v in version.items() if k != addition},
                'units':sorted(units),'selections':sorted(selections),'materials_only':True})
            prior_target = target.with_name(f'H{horizon:02d}-inventory-{prior_scope}.json')
            if prior_target.is_file():
                previous_path = prior_target
                previous = strict_json_bytes(prior_target.read_bytes())
                prior_qualification = target.with_name(f'H{horizon:02d}-inventory-staging-{prior_scope}.qualified.json')
            elif previous is not None and (previous['units'] != sorted(units)
                    or previous['selections'] != sorted(selections)):
                previous = None
        elif previous is not None and (previous['units'] != sorted(units)
                or previous['selections'] != sorted(selections)):
            previous = None
        target = version_target
    qualified_closure = None
    if previous is not None:
        _need(n._sealed({k: v for k, v in previous.items() if k != 'identity_sha256'}) == previous
            and previous['run_identity'] in generations and previous['horizon'] == horizon
            and previous['units'] == sorted(units) and previous['selections'] == sorted(selections),
            'ARCHIVE_INVENTORY_DRIFT')
        paths = {name: base / name for name in previous['members']}
        _need(all(p.is_file() and not any(a.is_symlink() for a in (p, *p.parents)
            if a == base or base in a.parents) for p in paths.values()), 'ARCHIVE_REFERENCE_MISSING')
        expected = {name: {k: pin[k] for k in ('sha256', 'size_bytes')}
                    for name, pin in previous['members'].items()}
        # Only this closure algorithm's previous scientific pass qualifies a
        # hit. Legacy inventories must first prove the selection member closure.
        current = all(previous.get(k) == version.get(k) for k in ('closure_version','evaluation_decision_sha256','post_result_repair_sha256','curve_rmse_sha256','result_closure_sha256','evaluation_extension_sha256','archive_generation')) and all(
            expected.get(name) == pin for name,pin in appendix_pins.items())
        hit = (qualified_file_pins(paths, identity={**version, 'inventory': previous['identity_sha256']},
            expected=expected, record=prior_qualification, validate=lambda: None, cached_only=True) if current else None)
        if hit is not None:
            return previous
        # This amendment only appends eight compact results. The prior closed
        # graph remains valid when every original member has the same qualified
        # bytes and filesystem stamp. Do not reopen its nested model/MICE ZIPs.
        curve_extension = (version.get('curve_rmse_sha256') is not None
            and previous.get('curve_rmse_sha256') is None
            and all(previous.get(k) == version.get(k) for k in
                ('closure_version','evaluation_decision_sha256','post_result_repair_sha256')))
        result_extension = (version.get('result_closure_sha256') is not None
            and previous.get('result_closure_sha256') is None
            and all(previous.get(k) == version.get(k) for k in
                ('closure_version','evaluation_decision_sha256','post_result_repair_sha256','curve_rmse_sha256')))
        evaluation_extension = (version.get('evaluation_extension_sha256') is not None
            and previous.get('evaluation_extension_sha256') is None
            and all(previous.get(k) == version.get(k) for k in version if k != 'evaluation_extension_sha256'))
        transport_extension = (version.get('archive_generation') is not None
            and previous.get('archive_generation') is None
            and all(previous.get(k) == v for k,v in version.items() if k != 'archive_generation'))
        if curve_extension or result_extension or evaluation_extension or transport_extension:
            prior_version = {k:previous[k] for k in version if k in previous}
            qualified_closure = qualified_file_pins(paths,
                identity={**prior_version,'inventory':previous['identity_sha256']},
                expected=expected,record=prior_qualification,validate=lambda:None,cached_only=True)
    pins, pending, projected_atoms, not_estimable = dict(qualified_closure or {}), [], set(), set()
    if qualified_closure is not None:
        not_estimable.update(previous.get('not_estimable_units', []))

    def add(name, pin=None):
        name = validate_relative_path(name, "archive.path")
        path = base / name
        _need(not any(p.is_symlink() for p in (path, *path.parents) if p == base or base in p.parents)
            and path.is_file() and path.resolve().is_relative_to(base.resolve()), "ARCHIVE_REFERENCE_MISSING:" + name)
        if name in pins:
            _need(pin is None or pins[name] == pin, "ARCHIVE_REFERENCE_ALIAS")
        else:
            actual = qualified_file_pins({name: path}, identity=run["source_identity"],
                expected={name: pin} if pin is not None else None,
                record=base / "shared/file-qualifications" / (n._sha(name) + ".json"))[name]
            pins[name] = actual
            pending.append(name)

    def inspect_json(value):
        if isinstance(value, dict):
            if {"path", "producer", "sha256", "size_bytes"} <= set(value):
                _need(value["producer"] in generations.values(), "ARCHIVE_PRODUCER_DRIFT")
                add(value["path"], {k: value[k] for k in ("sha256", "size_bytes")})
            elif {"path", "archive_sha256", "archive_size_bytes"} <= set(value):
                path = Path(value["path"])
                _need(path.is_absolute() and path.is_relative_to(base), "ARCHIVE_REFERENCE_PATH_INVALID")
                add(path.relative_to(base).as_posix(), {"sha256": value["archive_sha256"],
                    "size_bytes": value["archive_size_bytes"]})
            for item in value.values():
                inspect_json(item)
        elif isinstance(value, list):
            for item in value:
                inspect_json(item)

    def add_gbm_coordinates(coordinates, context):
        from .f5 import _current_q_json, _current_q_gbm_projection
        _need(context is not None, 'ARCHIVE_Q_CONTEXT_MISSING')
        cache = base / 'contexts' / context / 'q-atoms/atoms'
        for key in dict.fromkeys(row['key'] for row in coordinates.values()):
            from .bundle import validate_sha256
            validate_sha256(key, 'archive.atom')
            atom = cache / key
            producer = _current_q_json(atom / 'producer.json')
            if producer['task'].get('producer_kind') != 'GBM_STOP_CURVE':
                continue
            _need(producer['executor_source_identity'] in generations.values()
                and producer['key'] == key, 'ARCHIVE_Q_PRODUCER_DRIFT')
            if 'stop_function_source' in producer:
                source = producer['stop_function_source']
                atom = cache / source['key']
                from .carriers import source_pin
                _need(source_pin(atom / 'receipt.json')['sha256'] == source['receipt_sha256']
                    and source_pin(atom / 'input.json')['sha256'] == source['input_sha256'], 'ARCHIVE_Q_SOURCE_DRIFT')
            if atom in projected_atoms:
                continue
            projection = _current_q_gbm_projection(atom)
            if projection is not None:
                for member, pin in projection['original_members'].items():
                    add((atom / member).relative_to(base).as_posix(), pin)
                add((atom / 'gbm-losses.json').relative_to(base).as_posix())
                projected_atoms.add(atom)

    def inspect_zip(source, depth=0, context=None):
        _need(depth <= 12, "ARCHIVE_NESTING_TOO_DEEP")
        # Physical ZIP inspection: virtual references are collected rather than
        # expanded or copied, and recursively inspected at their sole source.
        with zipfile.ZipFile(source) as archive:
            # Legacy Q carriers embed the same full input in every atom. The
            # already qualified container and its sealed numerical member index
            # establish those byte identities; discover their references once.
            # CRC is only an additional ZIP consistency check, never the identity.
            infos = {info.filename: info for info in archive.infolist()}
            indexes, inspected_inputs = {}, set()
            def input_pin(name):
                from .f4_compact import _full_pipeline_q_numbers_index
                from .bundle import validate_sha256
                for parent in Path(name).parents:
                    index_name = (parent / 'numbers.json').as_posix()
                    if index_name not in infos:
                        continue
                    if index_name not in indexes:
                        _need(infos[index_name].file_size <= 16*1024**2, 'ARCHIVE_METADATA_TOO_LARGE')
                        raw = archive.read(index_name)
                        value = strict_json_bytes(raw)
                        indexes[index_name] = (_full_pipeline_q_numbers_index(raw)
                            if isinstance(value, dict) and value.get('kind') in {'PADML_F5_Q_NUMBERS_V1',
                                'PADML_F5_Q_CONSUMED_NUMBERS_V1'} else None)
                    index = indexes[index_name]
                    if index is None:
                        continue
                    pin = index['members'].get(Path(name).relative_to(parent).as_posix())
                    if pin is not None:
                        validate_sha256(pin.get('sha256'), 'archive.input')
                        _need(set(pin) == {'sha256', 'size_bytes'}
                            and type(pin['size_bytes']) is int
                            and pin['size_bytes'] == infos[name].file_size, 'ARCHIVE_METADATA_PIN_DRIFT')
                        return pin
                return None
            for info in archive.infolist():
                if (Path(info.filename).name in {'__padml_references__.json', 'input.json', 'scores.json',
                        'o-fit-scores.json', 'full-score-result.json', 'source-scores.json', 'execution.json',
                        'source-execution.json', 'number.json', 'predictions.json'}
                        or info.filename.endswith('native/coordinates.json')):
                    _need(info.file_size <= 64*1024**2, "ARCHIVE_METADATA_TOO_LARGE")
                    pin = input_pin(info.filename) if Path(info.filename).name == 'input.json' else None
                    key = (pin['sha256'], pin['size_bytes'], info.CRC) if pin is not None else None
                    if key is not None and key in inspected_inputs:
                        continue
                    raw = archive.read(info)
                    _need(pin is None or hashlib.sha256(raw).hexdigest() == pin['sha256'],
                        'ARCHIVE_METADATA_PIN_DRIFT')
                    value = strict_json_bytes(raw)
                    inspect_json(value)
                    if key is not None:
                        inspected_inputs.add(key)
                    if info.filename.endswith('native/coordinates.json'):
                        add_gbm_coordinates(value, context)
                elif info.filename.endswith(".zip"):
                    if info.compress_type == zipfile.ZIP_STORED:
                        # A nested stored archive is a byte window, not a
                        # ZipExtFile whose backward seeks replay its prefix.
                        with _StoredArchiveMember(archive, info) as stream:
                            inspect_zip(stream, depth+1, context)
                    else:
                        # Old compressed carriers are expanded once to bounded
                        # scratch; no repeated decompression or retained copy.
                        _need(info.file_size <= 512*1024**2, 'ARCHIVE_COMPRESSED_NESTED_TOO_LARGE')
                        with tempfile.SpooledTemporaryFile(max_size=8*1024**2,
                                dir=base / 'shared/archives') as stream, archive.open(info) as member:
                            shutil.copyfileobj(member, stream, length=1024**2)
                            stream.seek(0)
                            inspect_zip(stream, depth+1, context)

    for uid in (() if qualified_closure is not None else units):
        name = f"units/{uid}/unit.json"
        add(name)
        receipt = strict_json_bytes((base / name).read_bytes())
        _need(receipt["status"] in {"COMPLETED", "NOT_ESTIMABLE"}
            and receipt["run_identity"] in generations
            and receipt["unit_id"] == uid and receipt["direct_consumer_completed"] is True,
            "ARCHIVE_UNIT_INCOMPLETE")
        if receipt["status"] == "NOT_ESTIMABLE":
            from .integrated import consume_unit_estimability
            consume_unit_estimability(run, known[uid], base / "units" / uid, receipt)
            not_estimable.add(uid)
        for member, pin in receipt["artifacts"].items():
            add(f"units/{uid}/{member}", pin)
        if receipt["status"] == "COMPLETED" and known[uid]["kind"] in {"PRIMARY", "FULL0"}:
            for member in ("input.zip", "result.json", "o-fit.csv", "diagnostics/result.json"):
                add(f"units/{uid}/postprocess/{member}")
            folder = base / 'units' / uid / 'search/GBM_COX'
            coordinates = folder / 'native/coordinates.json'
            if coordinates.is_file():
                numbers = strict_json_bytes((folder / 'numbers.json').read_bytes())
                raw = coordinates.read_bytes()
                _need(numbers['members']['native/coordinates.json'] == {
                    'sha256': hashlib.sha256(raw).hexdigest(), 'size_bytes': len(raw)}, 'ARCHIVE_Q_COORDINATE_DRIFT')
                add_gbm_coordinates(strict_json_bytes(raw), known[uid]['context'])
    _need(not not_estimable.intersection(selections), "ARCHIVE_SELECTION_NOT_ESTIMABLE")
    for uid in (() if qualified_closure is not None else selections):
        for member in ("result.json", "selection.csv"):
            add(f"units/EVALUATION-H{horizon:02d}/selection/{uid}/{member}")
        prefix = f'units/EVALUATION-H{horizon:02d}/selection/{uid}'
        result = strict_json_bytes((base / prefix / 'result.json').read_bytes())
        _need(result.get('status') == 'COMPLETED' and result.get('source_unit') == uid
            and result.get('replicate_count') == 1000
            and set(result.get('replicate_members', {})) == {
                f'replicates/B{r:04d}.json' for r in range(1, 1001)}, 'ARCHIVE_SELECTION_CLOSURE_INVALID')
        for member, pin in result['replicate_members'].items():
            add(prefix + '/' + member, pin)
    for name, pin in appendix_pins.items():
        add(name, pin)
    if units:
        for member in ("binding.json", "contract.json", "covariates.csv", "response-seal.csv"):
            add("binding/" + member)
    while pending:
        name = pending.pop()
        if name.endswith(".zip"):
            parts = Path(name).parts
            context = (all_known.get(parts[1], {}).get('context') if parts[0] == 'units' else
                parts[1] if parts[0] == 'contexts' else None) if len(parts) > 1 else None
            inspect_zip(base / name, context=context)
        elif name.endswith(".json"):
            value = strict_json_bytes((base / name).read_bytes())
            if isinstance(value, dict) and value.get('kind') == 'PADML_CALIBRATION_REPAIR_APPENDIX_20261008_V1':
                import re
                from .f4 import _evaluation_check_producer
                _evaluation_check_producer(value, generations)
                legal = {'point.patch.json', 'metrics.csv', 'intervals.zip'} | {
                    f'patches/B{b:04d}.json' for b in range(1, 1001)}
                _need(value.get('status') == 'COMPLETED'
                    and value.get('direct_consumer_completed') is True and value.get('replicate_count') == 1000
                    and {'metrics.csv', 'intervals.zip'} <= set(value['members']) <= legal,
                    'ARCHIVE_CALIBRATION_REPAIR_CLOSURE_INVALID')
                for member, pin in value['members'].items():
                    add((Path(name).parent / member).as_posix(), pin)
                for member, pin in value['shared_members'].items():
                    _need(re.fullmatch(r'shared/evaluation-calibration-20261008/[0-9a-f]{64}\.json', member)
                        is not None, 'ARCHIVE_CALIBRATION_SHARED_SCOPE_INVALID')
                    add(member, pin)
            inspect_json(value)
    result = n._sealed({"kind": "PADML_WINDOW_ARCHIVE_INVENTORY_V1", "run_identity": run["identity"], **version,
        **({'materials_only': True} if staging else {}),
        "horizon": horizon, "units": sorted(units), "selections": sorted(selections),
        **({"not_estimable_units": sorted(not_estimable)} if not_estimable else {}),
        "members": {name: {**pin, "native_file": Path(name).suffix in {
            ".f64", ".rds", ".bin", ".pt", ".ubj", ".csv"} or pin["size_bytes"] >= 1024**2}
            for name, pin in sorted(pins.items())}})
    if previous is not None:
        ignored = {'run_identity','identity_sha256','previous_inventory_identity'}
        body = lambda v: {k:x for k,x in v.items() if k not in ignored}
        if body(previous) == body(result):
            result, target = previous, previous_path
        else:
            _need(all(previous.get(k) == result.get(k) for k in
                ('kind','horizon','units','selections','not_estimable_units'))
                and all(result['members'].get(name) == pin for name,pin in previous['members'].items()),
                'ARCHIVE_INVENTORY_DRIFT')
            target = version_target or closure_target
            _need(target != previous_path, 'ARCHIVE_INVENTORY_DRIFT')
            result = n._sealed({k:v for k,v in result.items() if k != 'identity_sha256'} |
                {'previous_inventory_identity':previous['identity_sha256']})
    elif version_target is not None:
        target = version_target
    _publish(target, canonical_json_bytes(result), "ARCHIVE_INVENTORY_DRIFT")
    qualified_file_pins({name: base / name for name in pins},
        identity={**version, 'inventory': result['identity_sha256']}, expected=pins,
        record=qualification, validate=lambda: None)
    return result


class _StoredArchiveMember(io.RawIOBase):
    """Sequentially used, bounded random access into an already qualified ZIP."""
    def __init__(self, archive, info):
        self.source, self.size, self.position = archive.fp, info.file_size, 0
        self.source.seek(info.header_offset)
        raw = self.source.read(30)
        _need(len(raw) == 30 and raw[:4] == b'PK\x03\x04', 'ARCHIVE_MEMBER_HEADER_INVALID')
        fields = struct.unpack('<4s5H3I2H', raw)
        _need(info.compress_size == info.file_size and fields[3] == zipfile.ZIP_STORED
            and fields[2] == info.flag_bits and not (fields[2] & 1),
            'ARCHIVE_MEMBER_COMPRESSION_INVALID')
        name = self.source.read(fields[-2])
        _need(name.decode('utf-8' if info.flag_bits & 0x800 else 'cp437') == info.orig_filename,
            'ARCHIVE_MEMBER_HEADER_INVALID')
        self.start = info.header_offset + 30 + fields[-2] + fields[-1]
        _need(0 <= self.start <= self.start+self.size <= archive.start_dir,
            'ARCHIVE_MEMBER_RANGE_INVALID')

    def readable(self): return True
    def seekable(self): return True
    def tell(self): return self.position
    def seek(self, offset, whence=0):
        _need(whence in (0, 1, 2), 'ARCHIVE_MEMBER_SEEK_INVALID')
        position = offset + (self.position if whence == 1 else self.size if whence == 2 else 0)
        _need(0 <= position <= self.size, 'ARCHIVE_MEMBER_SEEK_INVALID')
        self.position = position
        return position
    def read(self, size=-1):
        remaining = self.size - self.position
        size = remaining if size is None or size < 0 else min(size, remaining)
        self.source.seek(self.start + self.position)
        raw = self.source.read(size)
        self.position += len(raw)
        return raw


def _read_archive_inventory(base, horizon, identities):
    folder = base / 'shared/archives'
    paths = [folder/f'H{horizon:02d}-inventory-closure2.json', folder/f'H{horizon:02d}-inventory.json',
        *sorted(folder.glob(f'H{horizon:02d}-inventory-[0-9a-f]' + '*.json'))]
    for path in dict.fromkeys(paths):
        if path.is_file():
            value = strict_json_bytes(path.read_bytes())
            _need(n._sealed({k:v for k,v in value.items() if k != 'identity_sha256'}) == value,
                'ARCHIVE_INVENTORY_DRIFT')
            if value['identity_sha256'] in identities:
                return value
    raise ContractError('ARCHIVE_INVENTORY_IDENTITY_MISSING')


def archive_send(run, horizon, inventory_identity, members, offset, output):
    """Stream admitted sources; only compact metadata packs are assembled."""
    from .bundle import _zip_info
    from .runtime import ConsumedStream
    base = Path(run["run_root"])
    inventory = _read_archive_inventory(base, horizon, {inventory_identity})
    _need(inventory["identity_sha256"] == inventory_identity and members
        and len(members) == len(set(members)) and set(members) <= set(inventory["members"])
        and type(offset) is int and offset >= 0, "ARCHIVE_STREAM_NOT_ADMITTED")
    expected = {name: {k: inventory["members"][name][k] for k in ("sha256", "size_bytes")} for name in members}
    qualified_file_pins({name: base / name for name in members}, identity=inventory_identity,
        expected=expected, record=base / "shared/file-qualifications" / (n._sha(members) + ".archive.json"))
    if len(members) == 1:
        stream = ConsumedStream((base / members[0]).open("rb"), rolling=True)
        size = expected[members[0]]["size_bytes"]
    else:
        _need(sum(pin["size_bytes"] for pin in expected.values()) <= 64*1024**2
            and all(not inventory["members"][name]["native_file"] for name in members), "ARCHIVE_PACK_TOO_LARGE")
        stream = io.BytesIO()
        with zipfile.ZipFile(stream, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
            for name in sorted(members):
                with ConsumedStream((base / name).open('rb')) as source:
                    archive.writestr(_zip_info(name), source.read())
        size = stream.tell()
    try:
        _need(offset <= size, "ARCHIVE_RESUME_OFFSET_INVALID")
        stream.seek(offset)
        while block := stream.read(1024**2):
            output.write(block)
    finally:
        stream.close()


def archive_oss_operation(run, payload, envelope):
    """The original archive adapter owns one bounded pack/upload, not a new service."""
    from .bundle import sha256_file
    transfer = validate_archive_transfer(run)
    members, pins = envelope['members'], envelope['pins']
    _need(0 < len(members) <= 2048 and len(members) == len(set(members)) and set(members) == set(pins),
        'ARCHIVE_REQUEST_INVALID')
    scope = {'generation':transfer['generation'], 'horizon':payload['horizon'],
        'inventory_identity':payload['inventory_identity'], 'pins':pins}
    identity = n._sha(scope)
    _need(payload['archive_request_id'] == identity, 'ARCHIVE_REQUEST_ID_DRIFT')
    base = Path(run['run_root']); folder = base/'shared/archives/oss-relay'/transfer['generation']
    action=payload['action']
    if action!='status': folder.mkdir(parents=True,exist_ok=True)
    _need(folder.is_dir(),'ARCHIVE_UPLOAD_RECORD_ABSENT')
    _need(not folder.is_symlink() and folder.resolve().is_relative_to(base.resolve()),'ARCHIVE_DIRECTORY_INVALID')
    lock = folder/(identity+'.lock'); record_path = folder/(identity+'.json')
    _need(not lock.is_symlink() and not record_path.is_symlink(),'ARCHIVE_REQUEST_PATH_INVALID')
    if action=='status': _need(lock.is_file(),'ARCHIVE_UPLOAD_RECORD_ABSENT')
    fd = os.open(lock,os.O_RDONLY if action=='status' else os.O_CREAT|os.O_RDWR,0o600)
    try:
        try: fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError: return {'phase':'UPLOADING','request_id':identity}
        record = strict_json_bytes(record_path.read_bytes()) if record_path.exists() else None
        if record is not None:
            _need(record['scope'] == scope,'ARCHIVE_UPLOAD_RECORD_DRIFT')
        if action == 'status':
            _need(record is not None,'ARCHIVE_UPLOAD_RECORD_ABSENT')
            return {k:record[k] for k in ('phase','request_id','physical','storage') if k in record}
        if action=='release':
            _need(record is not None and record['phase']=='UPLOADED','ARCHIVE_UPLOAD_RELEASE_NOT_READY')
            if len(members)>1:
                source=folder/(identity+'.zip')
                _need(str(source)==record['source'] and not source.is_symlink(),'ARCHIVE_PACK_PATH_INVALID')
                if source.exists():
                    _need(source.stat().st_size==record['physical']['size_bytes']
                        and sha256_file(source)==record['physical']['sha256'],'ARCHIVE_PACK_BYTES_DRIFT')
                    source.unlink();_persist_published(record_path)
            return {k:record[k] for k in ('phase','request_id','physical','storage')}
        if action == 'prepare':
            inventory = _read_archive_inventory(base,payload['horizon'],{payload['inventory_identity']})
            _need(set(members) <= set(inventory['members']) and all(pins[k] ==
                {x:inventory['members'][k][x] for x in ('sha256','size_bytes')} for k in members),
                'ARCHIVE_UPLOAD_SOURCE_DRIFT')
            if record is not None and record['phase'] == 'UPLOADED':
                return {k:record[k] for k in ('phase','request_id','physical','storage')}
            qualified_file_pins({k:base/k for k in members},identity=payload['inventory_identity'],expected=pins,
                record=base/'shared/file-qualifications'/(n._sha(members)+'.archive.json'))
            packed = len(members)>1
            storage = 'packs/'+n._sha(pins)+'.zip' if packed else 'objects/'+pins[members[0]]['sha256']
            source = folder/(identity+'.zip') if packed else base/members[0]
            if packed:
                _need(not source.is_symlink(), 'ARCHIVE_PACK_PATH_INVALID')
                if not source.exists():
                    _need(shutil.disk_usage(folder).free >= sum(p['size_bytes'] for p in pins.values())+4*1024**3,
                        'ARCHIVE_SPACE_INSUFFICIENT')
                    part = source.with_name(source.name+'.part')
                    _need(not part.is_symlink(),'ARCHIVE_PACK_PATH_INVALID')
                    with part.open('wb') as stream:
                        archive_send(run,payload['horizon'],payload['inventory_identity'],members,0,stream)
                        stream.flush(); os.fsync(stream.fileno())
                    os.replace(part,source); _persist_published(source)
                physical = {'sha256':sha256_file(source),'size_bytes':source.stat().st_size}
                with zipfile.ZipFile(source) as z:
                    _need(sorted(z.namelist()) == sorted(members),'ARCHIVE_PACK_BYTES_DRIFT')
                    for k in members:
                        raw=z.read(k)
                        _need(len(raw)==pins[k]['size_bytes'] and hashlib.sha256(raw).hexdigest()==pins[k]['sha256'],
                            'ARCHIVE_PACK_BYTES_DRIFT')
            else: physical = pins[members[0]]
            if record is not None:
                _need(record['physical'] == physical and record['storage'] == storage,'ARCHIVE_UPLOAD_RECORD_DRIFT')
            stamp = source.stat()
            record = {'scope':scope,'request_id':identity,'phase':'PREPARED','physical':physical,'storage':storage,
                'source':str(source),'stamp':[stamp.st_dev,stamp.st_ino,stamp.st_size,stamp.st_mtime_ns,stamp.st_ctime_ns]}
            _publish(record_path,canonical_json_bytes(record),'ARCHIVE_UPLOAD_RECORD_DRIFT',replace=True)
            return {k:record[k] for k in ('phase','request_id','physical','storage')}
        _need(action == 'upload' and record is not None,'ARCHIVE_UPLOAD_PHASE_INVALID')
        if record['phase'] == 'UPLOADED':
            return {k:record[k] for k in ('phase','request_id','physical','storage')}
        tokens = envelope['tokens']; source = Path(record['source'])
        stamp = source.stat()
        _need([stamp.st_dev,stamp.st_ino,stamp.st_size,stamp.st_mtime_ns,stamp.st_ctime_ns] == record['stamp']
            and tokens['key'] == transfer['relay_prefix']+record['storage'], 'ARCHIVE_UPLOAD_SOURCE_DRIFT')
        # The inherited native directory lease and exact argv marker remain alive
        # through all HTTP work, including after loss of this short SSH reply.
        pid = os.fork()
        if pid:
            return {'phase':'UPLOADING','request_id':identity}
        try:
            os.setsid()
            null = os.open(os.devnull,os.O_RDWR)
            for stream in (0,1,2): os.dup2(null,stream)
            os.close(null)
            from .oss import upload_parts
            try:
                upload_parts(source,record['physical'],tokens)
                record['phase']='UPLOADED';record.pop('error',None)
                _publish(record_path,canonical_json_bytes(record),'ARCHIVE_UPLOAD_RECORD_DRIFT',replace=True)
            except BaseException as error:
                # No tokens or raw urllib errors are persisted.
                record['phase']='PAUSED'; record['error']=type(error).__name__
                _publish(record_path,canonical_json_bytes(record),'ARCHIVE_UPLOAD_RECORD_DRIFT',replace=True)
            if record['phase']=='UPLOADED' and len(members)>1:
                source.unlink(missing_ok=True); _persist_published(record_path)
        finally: os._exit(0)
    finally: os.close(fd)


def _oss_remote(command, run, record, action, tokens=None):
    request = {'members':record['members'],'pins':record['pins']}
    if tokens is not None: request['tokens']=tokens
    raw = canonical_json_bytes(request)
    _need(len(raw) <= 16*1024**2,'ARCHIVE_REQUEST_TOO_LARGE')
    scope = {'generation':run['archive_transfer']['generation'],'horizon':record['horizon'],
        'inventory_identity':record['inventory_identity'],'pins':record['pins']}
    request_id = n._sha(scope)
    # Capabilities use stdin only; process listings and errors contain no URLs.
    try:
        result = subprocess.run(command(record['host'],'archive_oss',action=action,horizon=record['horizon'],
            inventory_identity=record['inventory_identity'],archive_request_id=request_id,
            envelope_pin={'sha256':hashlib.sha256(raw).hexdigest(),'size_bytes':len(raw)}),
            input=raw,capture_output=True,timeout=60)
    except subprocess.TimeoutExpired:
        raise _ArchiveSenderUnknown({'request_id':request_id,'horizon':record['horizon']},'OSS_ADAPTER_UNKNOWN') from None
    if result.returncode == 255:
        raise _ArchiveSenderUnknown({'request_id':request_id,'horizon':record['horizon']},'OSS_ADAPTER_UNKNOWN')
    _need(result.returncode == 0,'ARCHIVE_OSS_ADAPTER_FAILED:'+str(result.returncode))
    value = strict_json_bytes(result.stdout)
    _need(value['request_id'] == request_id and value['phase'] in {'PREPARED','UPLOADING','UPLOADED','PAUSED'},
        'ARCHIVE_OSS_RESPONSE_INVALID')
    return value


def _oss_transport_owner(run,target,record):
    """The one original producer survives unordered inventories and controller loss."""
    storage=('packs/'+n._sha(record['pins'])+'.zip' if len(record['members'])>1 else
        'objects/'+record['pins'][record['members'][0]]['sha256'])
    key=run['archive_transfer']['relay_prefix']+storage
    folder=target/'transfers';folder.mkdir(exist_ok=True)
    path=folder/(n._sha(key)+'.json')
    if path.exists():
        value=strict_json_bytes(path.read_bytes());owner=value['owner']
        _need(value['storage']==storage and owner['host'] in run['hosts'], 'ARCHIVE_UPLOAD_OWNER_DRIFT')
    else:
        owner={k:record[k] for k in ('host','horizon','inventory_identity','members','pins')}
        _publish(path,canonical_json_bytes({'storage':storage,'owner':owner,'status':'PREPARING'}),
            'ARCHIVE_UPLOAD_OWNER_DRIFT')
    expected=('packs/'+n._sha(owner['pins'])+'.zip' if len(owner['members'])>1 else
        'objects/'+owner['pins'][owner['members'][0]]['sha256'])
    _need(expected==storage,'ARCHIVE_UPLOAD_OWNER_DRIFT')
    record['oss_owner']=owner
    return owner,path


def archive_oss_step(run, target, record, *, command):
    from . import oss
    owner,session=_oss_transport_owner(run,target,record)
    phase = record.get('oss_phase','prepare')
    if phase in {'prepare','poll'}:
        result = _oss_remote(command,run,owner,'prepare' if phase == 'prepare' else 'status')
        if result['phase'] == 'UPLOADING': return {'oss_phase':'poll'}
        if result['phase'] == 'UPLOADED':
            return {'oss_phase':'download','oss_material':result}
        return {'oss_phase':'upload','oss_material':result}
    if phase == 'upload':
        result = record['oss_material']
        key = run['archive_transfer']['relay_prefix']+result['storage']
        upload_id = oss.begin_multipart(key,result['physical'],session)
        tokens = oss.multipart_tokens(key,upload_id,result['physical']['size_bytes'])
        value = _oss_remote(command,run,owner,'upload',tokens)
        return {'oss_phase':'download' if value['phase']=='UPLOADED' else 'poll','oss_material':result}
    _need(phase in {'download','qualify'},'ARCHIVE_OSS_PHASE_INVALID')
    result = record['oss_material']; storage = result['storage']
    _need(target.stat().st_dev == record['volume_device'],'ARCHIVE_VOLUME_CHANGED')
    path = target/storage
    def before_write(remaining):
        _need(shutil.disk_usage(target).free >= remaining+record.get('other_write_reserve',0)+4*1024**3,
            'ARCHIVE_SPACE_INSUFFICIENT')
    if phase=='download':
        if path.exists():
            _qualify_archive_entity(path,result['physical'])
        else:
            oss.download_resume(path,run['archive_transfer']['relay_prefix']+storage,
                result['physical'],before_write=before_write)
        return {'oss_phase':'qualify'}
    physical=_qualify_archive_entity(path,result['physical'])
    members,pins=record['members'],record['pins'];packed=len(members)>1
    if packed:
        with zipfile.ZipFile(path) as z:
            _need(sorted(z.namelist()) == sorted(members),'ARCHIVE_PACK_MEMBERS_DRIFT')
            for name in members:
                raw=z.read(name)
                _need(len(raw)==pins[name]['size_bytes'] and hashlib.sha256(raw).hexdigest()==pins[name]['sha256'],
                    'ARCHIVE_PACK_BYTES_DRIFT')
    else: _need(physical==pins[members[0]],'ARCHIVE_BYTES_DRIFT')
    if packed: _oss_remote(command,run,owner,'release')
    return {record.get('archive_names',{}).get(name,name):{'pin':pins[name],'storage':storage,
        'physical':physical,'member':name if packed else None} for name in members}


def _archive_volume(root):
    """Bind the actual mounted volume, so an unmounted path cannot fill Mac SSD."""
    import plistlib
    _need(root.is_absolute() and root.is_dir() and not root.is_symlink(), "ARCHIVE_VOLUME_UNAVAILABLE")
    observed_mount = next((p for p in (root, *root.parents) if p.is_mount()), None)
    _need(observed_mount is not None and observed_mount != Path("/"), "ARCHIVE_VOLUME_UNAVAILABLE")
    result = subprocess.run(["/usr/sbin/diskutil", "info", "-plist", str(observed_mount)], capture_output=True, timeout=10)
    _need(result.returncode == 0, "ARCHIVE_VOLUME_UNAVAILABLE")
    info = plistlib.loads(result.stdout)
    mount = Path(info.get("MountPoint", "/"))
    # diskutil omits Mounted on some macOS releases. An actual mount boundary,
    # returned MountPoint and volume UUID establish the same required fact.
    _need(info.get("Mounted", True) is True and mount == observed_mount and mount.is_mount()
        and root.stat().st_dev == mount.stat().st_dev and root.resolve().is_relative_to(mount)
        and isinstance(info.get("VolumeUUID"), str), "ARCHIVE_VOLUME_IDENTITY_INVALID")
    return {"uuid": info["VolumeUUID"], "mount": str(mount), "filesystem": info.get("FilesystemType")}


def prepare_archive(run, archive_root):
    from .run import f45_unit_predecessors, _f45_predecessor_paths
    root = Path(archive_root)
    volume = _archive_volume(root)
    target = root / run["run_id"]
    target.mkdir(exist_ok=True)
    _need(not target.is_symlink(), "ARCHIVE_DESTINATION_INVALID")
    parent = os.open(root, os.O_RDONLY)
    try:
        os.fsync(parent)
    finally:
        os.close(parent)
    volume_file = target / "volume.json"
    _publish(volume_file, canonical_json_bytes(volume), "ARCHIVE_VOLUME_CHANGED")
    previous = f45_unit_predecessors(run)
    generations = {value["identity"]: value["source_identity"] for value in (run, *previous)}
    manifest = target / "run.json"
    if manifest.is_file():
        original = strict_json_bytes(manifest.read_bytes())
        _need(original["identity"] == n._sha({k:v for k,v in original.items() if k != "identity"})
            and generations.get(original["identity"]) == original["source_identity"]
            and original["run_id"] == run["run_id"] and original["run_root"] == run["run_root"],
            "ARCHIVE_RUN_CHANGED")
    for name in ("objects", "packs", "windows"):
        (target / name).mkdir(exist_ok=True)
    # Preserve the admitted source chain once, before publishing its new head.
    # Scientific manifests keep their original absolute paths and identities;
    # offline predecessor readers resolve these exact bytes by the declared SHA.
    for value in (run, *previous):
        if value.get("score_repair") is not None:
            from .run import _f45_score_repair_path, f45_score_repair
            f45_score_repair(value)
            ref = value["score_repair"]
            raw = _f45_score_repair_path(value).read_bytes()
            _need(len(raw) == ref["size_bytes"] and hashlib.sha256(raw).hexdigest() == ref["sha256"],
                "ARCHIVE_SCORE_REPAIR_BYTES_DRIFT")
            _publish(target / "objects" / ref["sha256"], raw, "ARCHIVE_SCORE_REPAIR_BYTES_DRIFT")
        pins = ([value["unit_predecessor"]] if value.get("unit_predecessor") else [])
        pins += value.get("unit_source_predecessors", [])
        for pin in pins:
            for kind, source in zip(("run", "source"), _f45_predecessor_paths(pin), strict=True):
                raw = source.read_bytes()
                digest = pin[kind + "_sha256"]
                _need(hashlib.sha256(raw).hexdigest() == digest, "ARCHIVE_PREDECESSOR_BYTES_DRIFT")
                _publish(target / "objects" / digest, raw, "ARCHIVE_PREDECESSOR_BYTES_DRIFT")
    _publish(manifest, canonical_json_bytes(run), "ARCHIVE_RUN_CHANGED", replace=True)
    return target


def _archive_rebuild_funds(available_cny, estimated_cny, generation, authority=None):
    """Keep observed cash distinct from an explicit authority to top up later."""
    from math import isfinite
    _need(all(type(v) in (int,float) and isfinite(v) for v in (available_cny,estimated_cny))
        and available_cny >= 0 and estimated_cny > 0, 'ARCHIVE_REBUILD_FUNDS_INVALID')
    if authority is not None:
        _need(isinstance(authority,dict) and set(authority)=={'kind','generation','authorized_at','instruction'}
            and authority['kind']=='USER_AUTHORIZED_ARCHIVE_BEFORE_RECHARGE'
            and authority['generation']==generation
            and isinstance(authority['authorized_at'],str) and bool(authority['authorized_at'])
            and isinstance(authority['instruction'],str) and bool(authority['instruction']),
            'ARCHIVE_REBUILD_FUNDING_AUTHORITY_INVALID')
    _need(available_cny >= estimated_cny or authority is not None, 'ARCHIVE_REBUILD_FUNDS_INSUFFICIENT')
    return {'available_cny':available_cny,'estimated_cny':estimated_cny,
        **({'proceed_before_recharge':authority} if authority is not None else {})}


def _preserve_archive_controller_reviews(old_index, old, missing, record_path):
    """Retain only old controller reviews lacking a remote source, before deletion."""
    from .bundle import validate_relative_path
    _need(all(name.startswith('shared/final-review/') for name in missing),
        'ARCHIVE_NECESSARY_OLD_MEMBER_SOURCE_MISSING:'+str(len(missing)))
    retained={}
    if not missing:return retained
    folder=record_path.with_suffix('.retained')
    _need(not folder.is_symlink() and not folder.resolve().is_relative_to(old_index.parent.parent.resolve()),
        'ARCHIVE_RETAINED_SOURCE_INVALID')
    folder.mkdir(exist_ok=True)
    for name in missing:
        validate_relative_path(name,'archive.controller_review')
        item=old['members'][name];pin=item['pin']
        _need(0 < pin['size_bytes'] <= 64*1024**2, 'ARCHIVE_CONTROLLER_REVIEW_TOO_LARGE')
        raw=_archive_item_bytes(*_archive_physical_location(item,old_index))
        _need(len(raw)==pin['size_bytes'] and hashlib.sha256(raw).hexdigest()==pin['sha256'],
            'ARCHIVE_CONTROLLER_REVIEW_DRIFT')
        target=folder/pin['sha256']
        _publish(target,raw,'ARCHIVE_CONTROLLER_REVIEW_DRIFT')
        retained[name]={'path':str(target),**pin}
    return retained


def _qualify_retained_controller_reviews(record, root):
    members=record.get('retained_controller_reviews',{})
    _need(all(name.startswith('shared/final-review/') and Path(row['path']).is_absolute()
        and not Path(row['path']).resolve().is_relative_to(root.resolve()) for name,row in members.items()),
        'ARCHIVE_RETAINED_SOURCE_INVALID')
    if members:
        folder=Path(next(iter(members.values()))['path']).parent
        _need(all(Path(row['path']).parent==folder for row in members.values()),
            'ARCHIVE_RETAINED_SOURCE_INVALID')
        qualified_file_pins({name:Path(row['path']) for name,row in members.items()},
            identity={'generation':record['generation'],'members':members},
            expected={name:{k:row[k] for k in ('sha256','size_bytes')} for name,row in members.items()},
            record=folder/'members.qualified.json')
    return members


def prepare_oss_rebuild(run, inventories, *, acceptance_path, available_cny,
                        estimated_cny, probe_receipt, readers_quiescent, funding_authority=None):
    """Native preflight outside the deletable project root; metadata only."""
    from .f4 import validate_post_result_archive_acceptance
    from .bundle import sha256_file
    transfer=validate_archive_transfer(run);root=Path(transfer['project_root'])
    validate_post_result_archive_acceptance(run,Path(acceptance_path))
    qualified_file_pins({k:Path(v['path']) for k,v in transfer['controller_sources'].items()},
        identity=run['identity'],expected={k:{x:v[x] for x in ('sha256','size_bytes')}
            for k,v in transfer['controller_sources'].items()},
        record=Path(transfer['rebuild_record']).with_name('archive-controller-sources.qualified.json'))
    _need(_archive_volume(root)==transfer['volume'] and readers_quiescent is True,
        'ARCHIVE_REBUILD_READERS_OR_VOLUME_INVALID')
    _need(probe_receipt.get('status')=='UPLOAD_DOWNLOAD_RESUME_DELETE_PASSED'
        and probe_receipt.get('prefix')==transfer['relay_prefix'],'ARCHIVE_REBUILD_PROBE_REQUIRED')
    funds=_archive_rebuild_funds(available_cny,estimated_cny,transfer['generation'],funding_authority)
    _need(set(inventories)=={'6','12','24','36'} and all(set(v)==set(run['hosts']) for v in inventories.values()),
        'ARCHIVE_REBUILD_SOURCE_COVERAGE')
    source_pins={};source_heads={}
    for horizon,hosts in inventories.items():
        source_heads[horizon]={}
        covered_units=set();covered_selections=set();negative=set()
        for host,inventory in hosts.items():
            _need(inventory['horizon']==int(horizon) and not inventory.get('materials_only',False)
                and inventory['run_identity'] in same_batch_generations(run)
                and n._sealed({k:v for k,v in inventory.items() if k!='identity_sha256'})==inventory
                and all(inventory.get(k)==v for k,v in _archive_version(run).items()),
                'ARCHIVE_REBUILD_SOURCE_DRIFT')
            source_heads[horizon][host]=inventory['identity_sha256']
            covered_units.update(inventory['units']);covered_selections.update(inventory['selections'])
            negative.update(inventory.get('not_estimable_units',[]))
            _need(set(inventory.get('not_estimable_units',[]))<=set(inventory['units']),
                'ARCHIVE_REBUILD_SOURCE_COVERAGE')
            for name,row in inventory['members'].items():
                source_pins.setdefault(name,set()).add((row['sha256'],row['size_bytes']))
        units={u['unit_id']:u for u in run['units'] if u['horizon']==int(horizon)}
        required={uid for uid,u in units.items() if u['kind'] in {'PRIMARY','FULL0'}}-negative
        _need(covered_units==set(units) and covered_selections==required,
            'ARCHIVE_REBUILD_SOURCE_COVERAGE')
    record_path=Path(transfer['rebuild_record']);record_path.parent.mkdir(parents=True,exist_ok=True)
    _need(not record_path.exists(),'ARCHIVE_REBUILD_ALREADY_REGISTERED')
    old_index=root/run['run_id']/'index.json'
    old=strict_json_bytes(old_index.read_bytes())
    _need(n._sealed({k:v for k,v in old.items() if k!='identity_sha256'})==old,'ARCHIVE_OLD_INDEX_DRIFT')
    recoverable={pin for values in source_pins.values() for pin in values}
    recoverable.update((v['sha256'],v['size_bytes']) for v in transfer['controller_sources'].values())
    from .run import f45_unit_predecessors, _f45_predecessor_paths
    for predecessor in (run,*f45_unit_predecessors(run)):
        bindings=([predecessor['unit_predecessor']] if predecessor.get('unit_predecessor') else [])
        bindings+=predecessor.get('unit_source_predecessors',[])
        for binding in bindings:
            for kind,path in zip(('run','source'),_f45_predecessor_paths(binding),strict=True):
                recoverable.add((binding[kind+'_sha256'],path.stat().st_size))
    # An old required member absent from the new inventories is still at risk.
    # A differently named identical source is sufficient; an omitted pin is not.
    missing=[name for name,item in old['members'].items() if
        (item['pin']['sha256'],item['pin']['size_bytes']) not in recoverable]
    retained=_preserve_archive_controller_reviews(old_index,old,missing,record_path)
    backup=record_path.with_name('archive-rebuild-old-index.json')
    _publish(backup,old_index.read_bytes(),'ARCHIVE_OLD_INDEX_DRIFT')
    entries={p.name:{'device':p.lstat().st_dev,'inode':p.lstat().st_ino} for p in root.iterdir()}
    record=n._sealed({'kind':'PADML_ARCHIVE_REBUILD_V1','phase':'PREPARED','generation':transfer['generation'],
        'run_identity':run['identity'],'root':str(root),'volume':transfer['volume'],
        'entries':entries,'source_inventories':source_heads,'final_member_pin_sets_sha256':n._sha(
            {k:sorted(v) for k,v in source_pins.items()}),'old_index':{'path':str(backup),
            'sha256':sha256_file(backup),'size_bytes':backup.stat().st_size},
        'funds':funds,'probe':probe_receipt,'retained_controller_reviews':retained,
        'acceptance':{'path':str(acceptance_path),'sha256':sha256_file(Path(acceptance_path))},
        'prepared_at':time.time(),'readers_quiescent':True})
    _publish(record_path,canonical_json_bytes(record),'ARCHIVE_REBUILD_RECORD_DRIFT')
    return record


def clear_old_archive(run, *, acceptance_path):
    """Called under the original dispatcher lock; never clear a published new generation."""
    from .f4 import validate_post_result_archive_acceptance
    from .bundle import sha256_file
    cfg=validate_archive_transfer(run);path=Path(cfg['rebuild_record']);root=Path(cfg['project_root'])
    record=strict_json_bytes(path.read_bytes())
    _need(n._sealed({k:v for k,v in record.items() if k!='identity_sha256'})==record
        and record['generation']==cfg['generation'] and record['root']==str(root)
        and record['volume']==cfg['volume']==_archive_volume(root),'ARCHIVE_REBUILD_RECORD_DRIFT')
    if record['phase']=='CLEARED':return record
    _need(record['phase'] in {'PREPARED','CLEARING'} and record['run_identity']==run['identity'],
        'ARCHIVE_REBUILD_STATE_INVALID')
    validate_post_result_archive_acceptance(run,Path(acceptance_path))
    _archive_rebuild_funds(record['funds']['available_cny'],record['funds']['estimated_cny'],
        cfg['generation'],record['funds'].get('proceed_before_recharge'))
    _qualify_retained_controller_reviews(record,root)
    _need(record['acceptance']=={'path':str(acceptance_path),'sha256':sha256_file(Path(acceptance_path))}
        and record['readers_quiescent']
        and record['probe']['status']=='UPLOAD_DOWNLOAD_RESUME_DELETE_PASSED','ARCHIVE_REBUILD_NOT_ACCEPTED')
    _need(set(p.name for p in root.iterdir())<=set(record['entries']),'ARCHIVE_REBUILD_UNEXPECTED_NEW_CONTENT')
    # Root inode identity survives partial deletion. No new archive writes are
    # admitted until CLEARED is durable outside this directory.
    for name,pin in record['entries'].items():
        target=root/name
        if not target.exists() and not target.is_symlink():continue
        st=target.lstat()
        _need({'device':st.st_dev,'inode':st.st_ino}==pin and st.st_dev==root.stat().st_dev,
            'ARCHIVE_REBUILD_ENTRY_CHANGED')
        if target.is_dir() and not target.is_symlink():
            for parent,dirs,files in os.walk(target,followlinks=False):
                _need(Path(parent).stat().st_dev==st.st_dev,'ARCHIVE_REBUILD_NESTED_MOUNT')
    if record['phase']=='PREPARED':
        _need(time.time()-record['prepared_at'] <= 3600,'ARCHIVE_REBUILD_PREFLIGHT_EXPIRED')
        record=n._sealed({k:v for k,v in record.items() if k!='identity_sha256'}|{'phase':'CLEARING'})
        _publish(path,canonical_json_bytes(record),'ARCHIVE_REBUILD_RECORD_DRIFT',replace=True)
    for name in record['entries']:
        target=root/name
        if target.is_symlink() or target.is_file():target.unlink()
        elif target.exists():shutil.rmtree(target)
    fd=os.open(root,os.O_RDONLY)
    try:os.fsync(fd)
    finally:os.close(fd)
    _need(not any(root.iterdir()),'ARCHIVE_REBUILD_NOT_EMPTY')
    record=n._sealed({k:v for k,v in record.items() if k!='identity_sha256'}|{'phase':'CLEARED','cleared_at':time.time()})
    _publish(path,canonical_json_bytes(record),'ARCHIVE_REBUILD_RECORD_DRIFT',replace=True)
    return record


def archive_members_from_stream(pin, source, *, idle_seconds=15, total_seconds=60, envelope=False):
    """Read the bounded transport envelope; inventory admission remains authoritative."""
    _need(isinstance(pin, dict) and set(pin) == {"sha256", "size_bytes"}
        and type(pin["size_bytes"]) is int and 0 < pin["size_bytes"] <= 16*1024**2,
        "ARCHIVE_REQUEST_INVALID")
    try:
        fd = source.fileno()
    except (AttributeError, io.UnsupportedOperation):
        raw = source.read(pin["size_bytes"] + 1)
    else:
        import select
        deadline = time.monotonic() + total_seconds
        parts, count = [], 0
        while count <= pin["size_bytes"]:
            remaining = deadline-time.monotonic()
            _need(remaining > 0 and select.select([fd], [], [], min(idle_seconds, remaining))[0],
                "ARCHIVE_REQUEST_TIMEOUT")
            block = os.read(fd, min(1024**2, pin["size_bytes"]+1-count))
            if not block:
                break
            parts.append(block); count += len(block)
        raw = b"".join(parts)
    _need(len(raw) == pin["size_bytes"] and hashlib.sha256(raw).hexdigest() == pin["sha256"],
        "ARCHIVE_REQUEST_BYTES_DRIFT")
    members = strict_json_bytes(raw)
    if envelope:
        _need(isinstance(members,dict) and {'members','pins'} <= set(members) <= {'members','pins','tokens'},
            'ARCHIVE_REQUEST_INVALID')
        return members
    _need(isinstance(members, list) and 0 < len(members) <= 2048
        and all(isinstance(name, str) for name in members), "ARCHIVE_REQUEST_INVALID")
    return members


class _ArchiveSenderUnknown(ContractError):
    def __init__(self, request, reason):
        self.request = request
        super().__init__('ARCHIVE_SENDER_OUTCOME_UNKNOWN:' + json.dumps(request, separators=(',', ':')) + ':' + str(reason))


def receive_archive(run, target, record, *, command, slots):
    """Resume one stream, hash while receiving, then atomically publish once."""
    import shutil
    from .runtime import ConsumedStream, advise_completed_io, mark_cache_use
    members, pins = record["members"], record["pins"]
    _need(target.stat().st_dev == record["volume_device"], "ARCHIVE_VOLUME_CHANGED")
    packed = len(members) > 1
    identity = n._sha(pins) if packed else pins[members[0]]["sha256"]
    relative = ("packs/" + identity + ".zip") if packed else ("objects/" + identity)
    path = target / relative
    expected = None if packed else pins[members[0]]
    limit = sum(pin["size_bytes"] for pin in pins.values()) + (1024**2 if packed else 0)
    part = path.with_suffix(path.suffix + ".part")
    _need(not path.is_symlink() and not part.is_symlink(), "ARCHIVE_DESTINATION_INVALID")
    if not path.is_file():
        count, hasher = 0, hashlib.sha256()
        if part.is_file():
            # Packed prefixes have an immediate ZIP/member consumer below.
            prefix = part.open("rb")
            with (prefix if packed else ConsumedStream(prefix, rolling=True)) as stream:
                while block := stream.read(1024**2):
                    hasher.update(block); count += len(block)
        _need(count <= limit, "ARCHIVE_PART_TOO_LARGE")
        _need(shutil.disk_usage(target).free >= max(0, limit-count)+4*1024**3, "ARCHIVE_SPACE_INSUFFICIENT")
        mark_cache_use([part])
        # Keep the exact pack grouping and resumable prefix. Long member lists
        # must not enter the SSH shell's single argv (Linux MAX_ARG_STRLEN).
        request = canonical_json_bytes(members)
        request_pin = {"sha256": hashlib.sha256(request).hexdigest(), "size_bytes": len(request)}
        _need(len(request) <= 16*1024**2 and 0 < len(members) <= 2048, "ARCHIVE_REQUEST_INVALID")
        with slots, part.open("ab") as output, tempfile.TemporaryFile() as errors, tempfile.TemporaryFile() as envelope:
            envelope.write(request); envelope.seek(0)
            offset = count
            send_request = {'horizon':record['horizon'], 'inventory_identity':record['inventory_identity'],
                'members_pin':request_pin, 'offset':offset}
            send_request['request_id'] = n._sha({'host':record['host'], **send_request})
            process = subprocess.Popen(command(record["host"], "archive_send", horizon=record["horizon"],
                inventory_identity=record["inventory_identity"], members_pin=request_pin, offset=offset,
                archive_request_id=send_request['request_id']),
                stdin=envelope, stdout=subprocess.PIPE, stderr=errors)
            remote_exited = False
            try:
                with selectors.DefaultSelector() as ready:
                    ready.register(process.stdout,selectors.EVENT_READ)
                    while True:
                        _need(ready.select(timeout=60), "ARCHIVE_TRANSFER_STALLED")
                        block=os.read(process.stdout.fileno(),1024**2)
                        if not block:break
                        count += len(block)
                        _need(count <= limit, "ARCHIVE_STREAM_TOO_LARGE")
                        hasher.update(block); output.write(block)
                returncode = process.wait(timeout=30)
                remote_exited = 0 <= returncode < 255
                if returncode:
                    errors.seek(0, os.SEEK_END)
                    errors.seek(max(0, errors.tell()-1024))
                    detail = {"host": record["host"], "horizon": record["horizon"],
                        "storage": relative, "inventory": record["inventory_identity"],
                        "offset": offset, "received_bytes": count-offset, "exit_code": returncode,
                        "stderr": "".join(c if ord(c) >= 32 else " " for c in
                            errors.read(1024).decode("utf-8", errors="replace"))[-512:]}
                    raise ContractError("ARCHIVE_TRANSFER_FAILED:" + json.dumps(detail,
                        ensure_ascii=False, separators=(",", ":")))
            finally:
                original_error = sys.exception()
                try:
                    process.stdout.close()
                    if process.poll() is None:
                        process.terminate()
                        try:
                            process.wait(timeout=15)
                        except subprocess.TimeoutExpired:
                            # Reap this local SSH child only. Its exit is not a
                            # claim that a remote scientific owner has stopped.
                            process.kill(); process.wait(timeout=15)
                finally:
                    # Persist a legal resumable prefix on every exit. fsync
                    # failure remains an I/O failure, never advisory UNKNOWN.
                    try:
                        output.flush(); os.fsync(output.fileno())
                    except OSError as persistence_error:
                        if original_error is None:
                            raise
                        original_error.add_note('ARCHIVE_PART_PERSISTENCE_FAILED:' + str(persistence_error))
                    if original_error is not None or not packed:
                        advise_completed_io([part], sync=False)
                    if original_error is not None and not remote_exited:
                        raise _ArchiveSenderUnknown(send_request, original_error) from original_error
        try:
            if expected is not None:
                _need(count == expected["size_bytes"] and hasher.hexdigest() == expected["sha256"], "ARCHIVE_BYTES_DRIFT")
            else:
                with ConsumedStream(part.open('rb')) as physical_stream, zipfile.ZipFile(physical_stream) as archive:
                    _need(sorted(archive.namelist()) == sorted(members), "ARCHIVE_PACK_MEMBERS_DRIFT")
                    for name in members:
                        h = hashlib.sha256()
                        with archive.open(name) as stream:
                            while block := stream.read(1024**2):
                                h.update(block)
                        _need(archive.getinfo(name).file_size == pins[name]["size_bytes"]
                            and h.hexdigest() == pins[name]["sha256"], "ARCHIVE_PACK_BYTES_DRIFT")
        except (ContractError, zipfile.BadZipFile):
            # A completed corrupt partial cannot be resumed from its end.
            # Retire only this failed transfer; the source remains untouched.
            part.unlink()
            raise
        os.replace(part, path)
        physical = {"sha256": hasher.hexdigest(), "size_bytes": count}
    else:
        from .bundle import sha256_file
        mark_cache_use([path])
        try:
            physical = {"sha256":sha256_file(path), "size_bytes":path.stat().st_size}
            _need(expected is None or physical == expected, "ARCHIVE_BYTES_DRIFT")
            if packed:
                with ConsumedStream(path.open('rb')) as physical_stream, zipfile.ZipFile(physical_stream) as archive:
                    _need(sorted(archive.namelist()) == sorted(members), "ARCHIVE_PACK_MEMBERS_DRIFT")
                    for name in members:
                        _need(hashlib.sha256(archive.read(name)).hexdigest() == pins[name]["sha256"], "ARCHIVE_PACK_BYTES_DRIFT")
            part.unlink(missing_ok=True)
        finally:
            advise_completed_io([path], sync=False)
    _persist_published(path)
    return {record.get('archive_names', {}).get(name, name): {"pin": pins[name], "storage": relative, "physical": physical,
        "member": name if packed else None} for name in members}


_ARCHIVE_INDEX_CACHE = {}


def _archive_index(path, run):
    st = path.stat()
    stamp = (str(path), st.st_dev, st.st_ino, st.st_size, st.st_mtime_ns, st.st_ctime_ns)
    index = _ARCHIVE_INDEX_CACHE.get(stamp)
    if index is None:
        index = strict_json_bytes(path.read_bytes())
        _need(index["kind"] == "PADML_WINDOW_ARCHIVE_INDEX_V1"
            and n._sealed({k:v for k,v in index.items() if k != "identity_sha256"}) == index, "ARCHIVE_INDEX_DRIFT")
        _ARCHIVE_INDEX_CACHE.clear()
        _ARCHIVE_INDEX_CACHE[stamp] = index
    _need(same_batch_generations(run).get(index["run_identity"]) == index["source_identity"],
        "ARCHIVE_INDEX_DRIFT")
    _need(index.get('archive_generation') == (run.get('archive_transfer') or {}).get('generation'),
        'ARCHIVE_INDEX_GENERATION_DRIFT')
    return index


def _calibration_logical_name(name):
    """Only numerical leaves admit producer variants; aliases are index-only."""
    import re
    prefix = 'shared/evaluation-calibration-20261008/'
    match = re.fullmatch(re.escape(prefix) + r'([0-9a-f]{64})\.json', name)
    if match:
        return name
    match = re.fullmatch(re.escape(prefix) + r'\.archive-pins/([0-9a-f]{64})/[0-9a-f]{64}-[1-9][0-9]*\.json', name)
    return prefix + match[1] + '.json' if match else None


def _calibration_archive_key(name, pin):
    from .bundle import validate_sha256
    _need(_calibration_logical_name(name) == name and type(pin['size_bytes']) is int
        and 0 < pin['size_bytes'] < 1024**2, 'ARCHIVE_VARIANT_ROLE_INVALID')
    digest = validate_sha256(pin['sha256'], 'archive.variant.sha256')
    return str(Path(name).parent / '.archive-pins' / Path(name).stem / (digest + '-' + str(pin['size_bytes']) + '.json'))


def _qualify_archive_entity(path,pin):
    record=path.parent.parent/'qualifications'/(path.name+'.json')
    return qualified_file_pins({'physical':path},identity={'physical':pin},
        expected={'physical':pin},record=record)['physical']


def _archive_physical_location(item, index_path):
    from .bundle import validate_relative_path, sha256_file
    root = index_path.parent
    storage = validate_relative_path(item['storage'], 'archive.storage')
    path = root / storage
    _need(not path.is_symlink() and path.resolve().is_relative_to(root.resolve()), 'ARCHIVE_STORAGE_INVALID')
    # Missing physical objects are recoverable by the existing collector;
    # a present but unqualified/drifting object is not equivalent to absence.
    path.stat()
    # The unchanged-file byte cache qualifies one physical pack, not every leaf.
    _need(_qualify_archive_entity(path,item['physical']) == item['physical'], 'ARCHIVE_BYTES_DRIFT')
    return path, item


def archived_location(name, run, *, index_path=None, expected=None):
    """Resolve physical storage without changing the Linux scientific run_root."""
    index_path = index_path or os.environ.get("PADML_ARCHIVE_INDEX")
    if not index_path:
        return None
    index_path = Path(index_path)
    index = _archive_index(index_path, run)
    item = index["members"].get(name)
    if _calibration_logical_name(name) == name:
        prefix = str(Path(name).parent / '.archive-pins' / Path(name).stem) + '/'
        if expected is not None:
            canonical = item
            if item is None or item['pin'] != expected:
                item = index['members'].get(_calibration_archive_key(name, expected))
            _need(item is not None or canonical is None and not any(key.startswith(prefix)
                for key in index['members']), 'ARCHIVE_PIN_NOT_FOUND:' + name)
        else:
            variants = [value for key,value in index['members'].items() if key.startswith(prefix)]
            pins = {(value['pin']['sha256'], value['pin']['size_bytes']) for value in variants}
            if item is not None:
                pins.add((item['pin']['sha256'], item['pin']['size_bytes']))
            _need(len(pins) <= 1, 'ARCHIVE_AMBIGUOUS_PRODUCER:' + name)
            if item is None and variants:
                item = variants[0]
    if item is None:
        return None
    _need(expected is None or item['pin'] == expected, 'ARCHIVE_REFERENCE_PIN_DRIFT:' + name)
    return _archive_physical_location(item, index_path)


def archived_bytes(name, run, *, index_path=None, expected=None):
    location = archived_location(name, run, index_path=index_path, expected=expected)
    _need(location is not None, "ARCHIVE_MEMBER_NOT_FOUND:" + name)
    return _archive_item_bytes(*location)


def _archive_item_bytes(path, item):
    from .runtime import ConsumedStream
    if item["member"] is None:
        with ConsumedStream(path.open('rb'), rolling=True) as stream:
            return stream.read()
    _need(item["pin"]["size_bytes"] < 1024**2, "ARCHIVE_PACK_MEMBER_TOO_LARGE")
    with ConsumedStream(path.open('rb')) as stream, zipfile.ZipFile(stream) as archive:
        raw = archive.read(item["member"])
    _need(len(raw) == item["pin"]["size_bytes"] and hashlib.sha256(raw).hexdigest() == item["pin"]["sha256"],
        "ARCHIVE_PACK_BYTES_DRIFT")
    return raw


class WindowArchive:
    """Window transfers submitted to the dispatcher's existing seven IO slots."""
    def __init__(self, run, root, *, pool, call, command, slots, staging=False, acceptance_path=None):
        from collections import deque
        self.run, self.pool, self.call, self.command, self.slots = run, pool, call, command, slots
        self.oss = run.get('archive_transfer') is not None
        if self.oss:
            transfer = validate_archive_transfer(run)
            _need(not staging, 'OSS_RELAY_REQUIRES_FINAL_ACCEPTANCE')
            _need(Path(root).is_absolute() and str(Path(root))==transfer['project_root']
                and _archive_volume(Path(root))==transfer['volume'],'ARCHIVE_REBUILD_DESTINATION_DRIFT')
            _need(acceptance_path is not None, 'POST_RESULT_ARCHIVE_REMAINS_PAUSED')
            record = clear_old_archive(run, acceptance_path=acceptance_path)
            _need(record.get('phase') == 'CLEARED' and record.get('generation') == transfer['generation']
                and record.get('root') == str(Path(root)) and record.get('volume') == _archive_volume(Path(root)),
                'ARCHIVE_REBUILD_NOT_ACCEPTED')
        self.target = prepare_archive(run, root)
        self.device = self.target.stat().st_dev
        self.states, self.pending, self.futures, self.blobs = {}, deque(), {}, {}
        self.blob_stamps = {}
        self.staging, self.reserved = staging, {}
        path = self.target / "index.json"
        self.index = (_archive_index(path, run) if path.is_file() else n._sealed({
            "kind": "PADML_WINDOW_ARCHIVE_INDEX_V1", "run_identity": run["identity"],
            "source_identity": run["source_identity"], "scientific_run_root": run["run_root"],
            **({'archive_generation':run['archive_transfer']['generation']} if self.oss else {}),
            "members": {}, "windows": {}}))
        self.member_pins = {name: item['pin'] for name, item in self.index['members'].items()}
        self.variant_keys, self.variant_checks = {}, {}
        self._remember_variant_keys(self.index['members'])
        if self.oss:
            rows={}
            for name,ref in transfer['controller_sources'].items():
                pin={k:ref[k] for k in ('sha256','size_bytes')}
                raw=Path(ref['path']).read_bytes()
                _need(len(raw)==pin['size_bytes'] and hashlib.sha256(raw).hexdigest()==pin['sha256'],
                    'ARCHIVE_LOCAL_SOURCE_DRIFT')
                storage='objects/'+pin['sha256']
                _publish(self.target/storage,raw,'ARCHIVE_LOCAL_SOURCE_DRIFT')
                # A transport-only release may continue the same relay generation.
                # Keep earlier source pins instead of rebinding their logical name.
                member = ('sources/'+pin['sha256']+'.zip') if name == 'source.zip' else name
                rows['shared/archive-inputs/'+member]={'pin':pin,'physical':pin,'storage':storage,'member':None}
            for name,ref in _qualify_retained_controller_reviews(record,Path(root)).items():
                pin={k:ref[k] for k in ('sha256','size_bytes')}
                raw=Path(ref['path']).read_bytes()
                _need(len(raw)==pin['size_bytes'] and hashlib.sha256(raw).hexdigest()==pin['sha256'],
                    'ARCHIVE_CONTROLLER_REVIEW_DRIFT')
                storage='objects/'+pin['sha256']
                _publish(self.target/storage,raw,'ARCHIVE_CONTROLLER_REVIEW_DRIFT')
                rows[name]={'pin':pin,'physical':pin,'storage':storage,'member':None}
            self._store_staged(rows)
        if not staging and run.get('post_result_repair') is not None:
            _need(acceptance_path is not None, 'POST_RESULT_ARCHIVE_REMAINS_PAUSED')
            self._archive_acceptance(Path(acceptance_path))
        # Cold recovery verifies physical objects asynchronously, once per
        # unique entity. Three existing IO slots leave room for dispatch.
        unique = {item["storage"]: name for name, item in self.index["members"].items()}
        names = list(unique.values())
        self.restore_futures = [pool.submit(self._check_existing, names[i::3]) for i in range(min(3,len(names)))]
        self.restored = not names
        self.restorable_windows = self._qualified_window_versions() if not names else set()

    def _archive_acceptance(self, path):
        """Preserve the already-required controller review in the same object store."""
        from .f4 import validate_post_result_archive_acceptance
        report = validate_post_result_archive_acceptance(self.run, path)
        prefix = 'shared/final-review/' + self.run['identity'] + '/'
        raw = path.read_bytes()
        _need(strict_json_bytes(raw) == report, 'POST_RESULT_ARCHIVE_ACCEPTANCE_IDENTITY_DRIFT')
        records = [('repair-acceptance.json', raw)] + [(name, (path.parent/name).read_bytes())
            for name in report['evidence']]
        existing = {(v['pin']['sha256'],v['pin']['size_bytes']):v for v in self.index['members'].values()}
        rows = {}
        for name, raw in records:
            pin = {'sha256':hashlib.sha256(raw).hexdigest(),'size_bytes':len(raw)}
            _need(name == 'repair-acceptance.json' or pin == report['evidence'][name],
                'POST_RESULT_ARCHIVE_EVIDENCE_DRIFT')
            item = existing.get((pin['sha256'],pin['size_bytes']))
            if item is not None:
                _archive_physical_location(item, self.target/'index.json')
            else:
                storage = 'objects/' + pin['sha256']
                _publish(self.target/storage, raw, 'POST_RESULT_ARCHIVE_EVIDENCE_DRIFT')
                item = {'pin':pin,'physical':pin,'storage':storage,'member':None}
                existing[(pin['sha256'],pin['size_bytes'])] = item
            rows[prefix+name] = item
        self._store_staged(rows)

    def _qualified_window_versions(self):
        version = _archive_version(self.run)
        return {h for h,row in self.index['windows'].items() if all(row.get(k) == version.get(k) for k in ('closure_version','evaluation_decision_sha256','post_result_repair_sha256','curve_rmse_sha256','result_closure_sha256','evaluation_extension_sha256','archive_generation'))}

    def _stamp(self, item):
        path = self.target / item["storage"]
        _need(not path.is_symlink(), "ARCHIVE_STORAGE_INVALID")
        st = path.stat()
        return (st.st_dev, st.st_ino, st.st_size, st.st_mtime_ns, st.st_ctime_ns)

    def _check_existing(self, names):
        from .runtime import advise_completed_io
        valid = {}
        for name in names:
            item = self.index["members"][name]
            try:
                archived_location(name, self.run, index_path=self.target / "index.json", expected=item['pin'])
                valid[item["storage"]] = self._stamp(item)
            except FileNotFoundError:
                pass  # Reacquire missing objects from the retained source.
            finally:
                advise_completed_io([self.target / item['storage']], sync=False)
        return valid

    def _remember_variant_keys(self, rows):
        for key in rows:
            name = _calibration_logical_name(key)
            if name is not None and key != name:
                self.variant_keys.setdefault(name, set()).add(key)

    def _check_producer_variants(self, rows):
        """Check only colliding small leaves, never rescan numerical carriers."""
        from .f4 import _evaluation_check_producer, evaluation_decision, post_result_repair_decision
        groups = {}
        for key,item in rows.items():
            name = _calibration_logical_name(key)
            if name is not None:
                groups.setdefault(name, {})[key] = item
        for name,items in groups.items():
            for key in {name} | self.variant_keys.get(name, set()):
                if key in self.index['members']:
                    items.setdefault(key, self.index['members'][key])
            if set(items) == {name}:
                continue
            if len(items) == 1 and name not in items:
                key = next(iter(items))
                if key in self.index['members']:
                    continue  # Previously admitted immutable variant.
                pin = self.member_pins.get(name, {})
                base = self.blobs.get((pin.get('sha256'), pin.get('size_bytes')))
                _need(base is not None, 'ARCHIVE_VARIANT_BASE_PENDING:' + name)
                items[name] = base
            signatures = set()
            for key,item in items.items():
                pin = item['pin']
                _need(key == name or key == _calibration_archive_key(name, pin), 'ARCHIVE_VARIANT_KEY_DRIFT')
                _need(0 < pin['size_bytes'] < 1024**2, 'ARCHIVE_VARIANT_TOO_LARGE')
                token = (name, pin['sha256'], pin['size_bytes'], self._stamp(item))
                signature = self.variant_checks.get(token)
                if signature is None:
                    path, _ = _archive_physical_location(item, self.target / 'index.json')
                    raw = _archive_item_bytes(path, item)
                    _need(len(raw) == pin['size_bytes'] and hashlib.sha256(raw).hexdigest() == pin['sha256'],
                        'ARCHIVE_VARIANT_PIN_DRIFT')
                    leaf = strict_json_bytes(raw)
                    _need(canonical_json_bytes(leaf) == raw and n._sealed({k:v for k,v in leaf.items()
                        if k != 'identity_sha256'}) == leaf, 'ARCHIVE_VARIANT_SEAL_DRIFT')
                    _evaluation_check_producer(leaf, same_batch_generations(self.run))
                    _need(leaf['kind'] == 'PADML_CALIBRATION_NUMERIC_LEAF_20261008_V1'
                        and leaf['input_identity'] == Path(name).stem == n._sha(leaf['binding'])
                        and leaf['binding']['calibration_contract_sha256'] == n._sha({
                            'original_evaluation':evaluation_decision()['identity_sha256'],
                            'calibration':post_result_repair_decision()['calibration']})
                        and leaf['status'] == 'COMPLETED' and leaf['completed_calibration_fit_calls'] == 1,
                        'ARCHIVE_VARIANT_INPUT_DRIFT')
                    signature = n._sha({k:v for k,v in leaf.items() if k not in {'producer','identity_sha256'}})
                    self.variant_checks[token] = signature
                signatures.add(signature)
            _need(len(signatures) == 1, 'ARCHIVE_VARIANT_NUMERIC_DRIFT:' + name)

    @staticmethod
    def _closure_pins_sha(rows):
        # A one-producer scope keeps its original logical digest, even when a
        # different scope requires an index alias. Conflicting full closures
        # bind every original pin, independently of which host finished first.
        pins, variants = {}, {}
        for key,item in rows.items():
            name = _calibration_logical_name(key)
            if name is None:
                pins[key] = item['pin']
            else:
                variants.setdefault(name, {})[_calibration_archive_key(name, item['pin'])] = item['pin']
        for name,items in variants.items():
            if len(items) == 1:
                pins[name] = next(iter(items.values()))
            else:
                pins.update(items)
        return n._sha(pins)

    def _variant_bases_ready(self, record, state):
        for name,key in record.get('archive_names', {}).items():
            if name == key:
                continue
            pin = self.member_pins.get(name, {})
            if (pin.get('sha256'), pin.get('size_bytes')) in self.blobs:
                continue
            origin = state.get('aliases', {}).get(name, name)
            if origin not in state.get('resolved', {}):
                return False
        return True

    def _plan(self, horizon, inventories, *, state_key=None):
        state_key = horizon if state_key is None else state_key
        state = self.states[state_key]
        all_members, producers, not_estimable, admitted = {}, {}, set(), {}
        previous = getattr(self, 'member_pins', {})
        for host, inventory in (sorted(inventories.items()) if getattr(self,'oss',False) else inventories.items()):
            _need(inventory["run_identity"] in same_batch_generations(self.run) and inventory["horizon"] == horizon
                and (getattr(self, 'staging', False) or not inventory.get('materials_only', False))
                and n._sealed({k:v for k,v in inventory.items() if k != "identity_sha256"}) == inventory,
                "ARCHIVE_INVENTORY_DRIFT")
            negative = inventory.get("not_estimable_units", [])
            _need(isinstance(negative, list) and all(isinstance(uid, str) for uid in negative)
                and negative == sorted(set(negative)) and set(negative) <= set(inventory["units"]),
                "ARCHIVE_INVENTORY_DRIFT")
            not_estimable.update(negative)
            for name, record in inventory["members"].items():
                pin = {k:record[k] for k in ('sha256', 'size_bytes')}
                canonical = admitted.get(name, previous.get(name, pin))
                key = name
                if canonical != pin:
                    _need(_calibration_logical_name(name) == name,
                        'ARCHIVE_CONFLICTING_PRODUCER:' + name)
                    key = _calibration_archive_key(name, pin)
                elif name not in previous and name not in admitted and _calibration_logical_name(name) == name:
                    variant = _calibration_archive_key(name, pin)
                    if variant in previous:
                        key = variant
                _need(admitted.get(key, previous.get(key, pin)) == pin,
                    'ARCHIVE_CONFLICTING_PRODUCER:' + name)
                admitted[key] = pin
                old = all_members.setdefault(key, dict(record))
                old["native_file"] |= record["native_file"]
                producers.setdefault(key, (host, name))
        _need(not_estimable == state.get("not_estimable", set()),
            "ARCHIVE_TERMINAL_SOURCE_DRIFT")
        if getattr(self, 'staging', False):
            _need(len(inventories) == 1 and set(inventory['units']) == state['units']
                and set(inventory['selections']) == state['training'], 'ARCHIVE_SCOPE_INVALID')
        self.member_pins = previous
        self.member_pins.update(admitted)
        groups, unique, aliases, resolved, shared = {}, {}, {}, {}, {}
        for name, row in sorted(all_members.items(), key=lambda item: (not item[1]["native_file"], item[0])):
            pin = {k: row[k] for k in ("sha256", "size_bytes")}
            key = (pin["sha256"], pin["size_bytes"])
            if key in self.blobs and (not row["native_file"] or self.blobs[key]["member"] is None):
                existing = self.blobs[key]
                try:
                    unchanged = self._stamp(existing) == self.blob_stamps.get(existing["storage"])
                except FileNotFoundError:
                    unchanged = False
                if unchanged:
                    resolved[name] = existing
                    continue
            if key in unique:
                aliases[name] = unique[key]
                continue
            if getattr(self, 'staging', False) or getattr(self,'oss',False):
                prior = self.reserved.get(key)
                if prior is not None and (prior[2] or not row['native_file']):
                    shared[name] = prior[:2]
                    continue
                self.reserved[key] = (state_key, name, row['native_file'])
            unique[key] = name
            host, _ = producers[name]
            groups.setdefault(host, []).append((name, row))
        state.update(inventories=inventories, expected=all_members, resolved=resolved, aliases=aliases,
            shared=shared, transfers=0, inventory_futures=None)
        for host, entries in groups.items():
            small, count = [], 0
            def queue(items):
                if (getattr(self, 'staging', False) or getattr(self,'oss',False)) and len(items) == 1:
                    name, row = items[0]
                    # A singleton metadata group is an object too, so a later
                    # native consumer must share its actual in-flight writer.
                    self.reserved[(row['sha256'], row['size_bytes'])] = (state_key, name, True)
                state["transfers"] += 1
                self.pending.append({"horizon": horizon, "host": host,
                    **({'state_key': state_key} if getattr(self, 'staging', False) else {}),
                    "inventory_identity": inventories[host]["identity_sha256"],
                    "members": [producers[name][1] for name, _ in items],
                    "pins": {producers[name][1]: {k: row[k] for k in ("sha256", "size_bytes")} for name, row in items},
                    "archive_names": {producers[name][1]:name for name, _ in items},
                    "volume_device": self.device})
            for name, row in entries:
                if row["native_file"]:
                    queue([(name, row)])
                else:
                    if small and (count + row["size_bytes"] > 64*1024**2 or len(small) >= 2048):
                        queue(small); small, count = [], 0
                    small.append((name, row)); count += row["size_bytes"]
            if small:
                queue(small)

    def _finish(self, horizon):
        _need(not getattr(self, 'staging', False), 'ARCHIVE_STAGING_CANNOT_CONFIRM')
        state = self.states[horizon]
        for name, origin in state["aliases"].items():
            state["resolved"][name] = state["resolved"][origin]
        _need(set(state["resolved"]) == set(state["expected"]), "ARCHIVE_CLOSURE_INCOMPLETE")
        self._check_producer_variants(state['resolved'])
        for name, item in state["resolved"].items():
            _need(item["pin"] == {k: state["expected"][name][k] for k in ("sha256", "size_bytes")},
                "ARCHIVE_CLOSURE_DRIFT")
            old = self.index["members"].get(name, item)
            _need(old["pin"] == item["pin"], "ARCHIVE_PREVIOUS_WINDOW_DRIFT")
            self.index["members"][name] = item
            self.blobs[(item["pin"]["sha256"], item["pin"]["size_bytes"])] = item
            self.blob_stamps[item["storage"]] = self._stamp(item)
        window = n._sealed({"kind": "PADML_WINDOW_ARCHIVE_RECEIPT_V1", "run_identity": self.run["identity"],
            **_archive_version(self.run),
            "horizon": horizon, "units": sorted(state["units"]), "selections": sorted(state["training"]),
            **({"not_estimable_units": sorted(state["not_estimable"])} if state.get("not_estimable") else {}),
            "inventories": {h: inv["identity_sha256"] for h, inv in state["inventories"].items()},
            "member_pins_sha256": self._closure_pins_sha(state['resolved']),
            "status": "ARCHIVED"})
        folder = self.target / 'windows'
        previous = self.index['windows'].get(str(horizon))
        if previous is None and (folder / f'H{horizon:02d}.json').is_file():
            previous = strict_json_bytes((folder / f'H{horizon:02d}.json').read_bytes())
        if previous is not None:
            _need(n._sealed({k:v for k,v in previous.items() if k != 'identity_sha256'}) == previous
                and previous['run_identity'] in same_batch_generations(self.run)
                and all(previous.get(k) == window.get(k) for k in
                    ('kind','horizon','units','selections','not_estimable_units','status')), 'ARCHIVE_WINDOW_DRIFT')
            comparable = lambda v: {k:x for k,x in v.items() if k not in
                {'run_identity','identity_sha256','previous_window_identity'}}
            if comparable(previous) == comparable(window):
                window = previous
            else:
                _need(any(previous.get(k) != v for k,v in _archive_version(self.run).items()),
                    'ARCHIVE_WINDOW_DRIFT')
                state['previous_receipt'] = previous
                window = n._sealed({k:v for k,v in window.items() if k != 'identity_sha256'} |
                    {'previous_window_identity':previous['identity_sha256']})
        window_path = _archive_receipt_path(folder, horizon, window)
        if window_path.is_file():
            previous = strict_json_bytes(window_path.read_bytes())
            _need(n._sealed({k:v for k,v in previous.items() if k != 'identity_sha256'}) == previous
                and previous['run_identity'] in same_batch_generations(self.run)
                and {k:v for k,v in previous.items() if k not in {'run_identity','identity_sha256'}} ==
                    {k:v for k,v in window.items() if k not in {'run_identity','identity_sha256'}}, 'ARCHIVE_WINDOW_DRIFT')
            window = previous
        # The index may only point at a durable leaf. A crash between leaf and
        # head publication resumes by checking the same immutable leaf again.
        _publish(window_path, canonical_json_bytes(window), "ARCHIVE_WINDOW_DRIFT")
        self.index["windows"][str(horizon)] = window
        self.index = n._sealed({k:v for k,v in self.index.items() if k != "identity_sha256"})
        _publish(self.target / "index.json", canonical_json_bytes(self.index), "ARCHIVE_INDEX_DRIFT", replace=True)
        self._remember_variant_keys(state['resolved'])
        # Acknowledgements are small control operations, submitted after the
        # complete closure's publication. Source bytes survive failed acks.
        state["receipt"] = window
        state["published"] = True

    @staticmethod
    def _failed(state, error):
        # A storage/transport failure must not stop independent scientific work.
        # Keep the original transfer, partial bytes and successful peers; retry
        # only unfinished operations on the dispatcher's existing polling loop.
        count = state.get("failures", 0) + 1
        state.update(failures=count, error=f"{type(error).__name__}: {error}"[-1800:],
            retry_at=time.monotonic() + min(300, 5 * 2**min(count - 1, 6)))

    def _store_staged(self, rows, *, receipt=None):
        """Durable member locations only; no window leaf or remote retirement ACK."""
        self._check_producer_variants(rows)
        body = {k:v for k,v in self.index.items() if k != 'identity_sha256'}
        body['members'] = dict(body['members'])
        for name, item in rows.items():
            old = body['members'].get(name, item)
            _need(old['pin'] == item['pin'], 'ARCHIVE_PREVIOUS_WINDOW_DRIFT')
            body['members'][name] = item
        if receipt is not None:
            body['staged_inventories'] = dict(body.get('staged_inventories', {}))
            key = n._sha([receipt['host'], receipt['inventory_identity']])
            old = body['staged_inventories'].get(key, receipt)
            _need(old == receipt, 'ARCHIVE_STAGING_RECEIPT_DRIFT')
            body['staged_inventories'][key] = receipt
        index = n._sealed(body)
        _publish(self.target / 'index.json', canonical_json_bytes(index), 'ARCHIVE_INDEX_DRIFT', replace=True)
        self.index = index
        self._remember_variant_keys(rows)
        for item in rows.values():
            self.blobs[(item['pin']['sha256'], item['pin']['size_bytes'])] = item
            self.blob_stamps[item['storage']] = self._stamp(item)

    def _sender_wait(self, future, record, state, observations):
        if record.get('sender_request') is None:
            return False
        if time.monotonic() < record.get('retry_at', 0):
            return True
        probe = record.get('sender_probe')
        owner=record.get('oss_owner',record)
        request_horizon=record['sender_request'].get('horizon',record['horizon'])
        if probe is not None and probe.done():
            record.pop('sender_probe')
            try:
                value = probe.result()
                if value == {'status':'IDLE', 'horizon':request_horizon,
                        'request_id':record['sender_request']['request_id']}:
                    record['sender_idle_observations'] = record.get('sender_idle_observations', 0)+1
                else:
                    _need(value.get('status') == 'IN_PROGRESS', 'ARCHIVE_SENDER_STATUS_INVALID')
                    record['sender_idle_observations'] = 0
                if record.get('sender_idle_observations') == 2:
                    record.pop('sender_request')
                    del self.futures[future]
                    self.pending.append(record)
                record['retry_at'] = time.monotonic()+5
            except Exception as error:
                record['sender_idle_observations'] = 0
                self._failed(record, error)
            return True
        if probe is None and observations.get(owner['host'], {}).get('state') in {'IDLE', 'RUNNING'}:
            record['sender_probe'] = self.pool.submit(self.call, owner['host'], 'archive_inventory',
                horizon=request_horizon, units=[], selections=[],
                staging=getattr(self, 'staging', False), status_only=True, sender_request=record['sender_request'])
        return True

    def _advance_staging(self, observations, *, draining=False):
        # Each scope contains only published units and completed appendices.
        # A RUNNING worker does not prevent reading its immutable older results.
        try:
            _need(_archive_volume(self.target.parent) == strict_json_bytes((self.target / 'volume.json').read_bytes()),
                'ARCHIVE_VOLUME_CHANGED')
        except Exception as error:
            return {'status': 'RETRY_WAIT', 'reason': str(error)[-1800:]}
        known = {u['unit_id']: u for u in self.run['units']}
        if not draining:
            for host, o in observations.items():
                if o.get('state') not in {'IDLE', 'RUNNING'}:
                    continue
                completed, negative = set(o.get('completed_units', [])), set(o.get('not_estimable_units', []))
                _need(not completed & negative, 'ARCHIVE_CONFLICTING_UNIT_TERMINALS')
                for horizon in (6, 12, 24, 36):
                    units = {uid for uid in completed | negative if known[uid]['horizon'] == horizon
                        and (uid in negative or known[uid]['kind'] not in {'PRIMARY', 'FULL0'}
                             or uid in o.get('postprocess_ready_units', []))}
                    selections = {uid for uid in o.get('selection_completed_units', [])
                        if known[uid]['horizon'] == horizon}
                    if self.run.get('evaluation_decision') is not None:
                        units = {uid for uid in units if uid in negative or known[uid]['kind'] == 'AAR'
                            or uid in o.get('evaluation_amendment_units', [])}
                        selections &= set(o.get('selection_amendment_units', []))
                    if not units and not selections:
                        continue
                    key = (horizon, host, n._sha([sorted(units), sorted(selections)]))
                    self.states.setdefault(key, {'host': host, 'horizon': horizon, 'units': units,
                        'training': selections, 'not_estimable': units & negative})

        for future, record in list(self.futures.items()):
            state = self.states[record['state_key']]
            if not future.done() or time.monotonic() < record.get('retry_at', 0):
                continue
            errors = state.setdefault('transfer_errors', {})
            transfer_key = n._sha(record['pins'])
            if self._sender_wait(future, record, state, observations):
                continue
            try:
                rows = future.result()
            except Exception as error:
                if isinstance(error, _ArchiveSenderUnknown):
                    record['sender_request'] = error.request
                    record.pop('sender_idle_observations', None)
                    record.pop('sender_probe', None)
                else:
                    del self.futures[future]
                    self.pending.append(record)
                self._failed(record, error)
                errors[transfer_key] = record['error']
                continue
            try:
                _need(_archive_volume(self.target.parent) == strict_json_bytes((self.target / 'volume.json').read_bytes()),
                    'ARCHIVE_VOLUME_CHANGED')
                self._store_staged(rows)
            except Exception as error:
                # A failed index barrier retains the completed future, so the
                # next attempt persists its rows instead of retransferring.
                self._failed(record, error)
                errors[transfer_key] = record['error']
                continue
            del self.futures[future]
            state['resolved'].update(rows)
            state['transfers'] -= 1
            errors.pop(transfer_key, None)

        for key, state in self.states.items():
            future = state.get('inventory_future')
            if future is not None and future.done():
                state.pop('inventory_future')
                try:
                    value = future.result()
                    if value.get('status') == 'IN_PROGRESS':
                        request = state.get('reader_request')
                        _need(value.get('horizon') == state['horizon'] and (
                            request is None or value.get('request_id') == request['request_id']),
                            'ARCHIVE_READER_STATUS_INVALID')
                        state.pop('reader_idle', None)
                        state.update(reader_pending=True, retry_at=time.monotonic()+5)
                    elif state.pop('reader_probe', False):
                        request = state.get('reader_request')
                        _need(value == {'status':'IDLE', 'horizon':state['horizon'],
                            **({'request_id':request['request_id']} if request else {})}, 'ARCHIVE_READER_STATUS_INVALID')
                        state['reader_idle'] = state.get('reader_idle', 0)+1
                        if state['reader_idle'] >= (2 if request else 1):
                            state.pop('reader_pending', None)
                            state.pop('reader_request', None)
                            state.pop('reader_idle', None)
                        else:
                            state['retry_at'] = time.monotonic()+5
                    else:
                        self._plan(state['horizon'], {state['host']: value}, state_key=key)
                        state.pop('reader_pending', None)
                        state.pop('reader_request', None)
                        for field in ('error', 'retry_at', 'failures'):
                            state.pop(field, None)
                except Exception as error:
                    state['reader_pending'] = True
                    state.pop('reader_idle', None)
                    self._failed(state, error)
            if 'expected' not in state or state.get('staged'):
                continue
            for name, (origin_key, origin_name) in state['shared'].items():
                if origin_name in self.states[origin_key]['resolved']:
                    state['resolved'][name] = self.states[origin_key]['resolved'][origin_name]
            for name, origin in state['aliases'].items():
                if origin in state['resolved']:
                    state['resolved'][name] = state['resolved'][origin]
            if (state['transfers'] == 0 and set(state['resolved']) == set(state['expected'])
                    and time.monotonic() >= state.get('retry_at', 0)):
                try:
                    for name, item in state['resolved'].items():
                        _need(item['pin'] == {k:state['expected'][name][k] for k in ('sha256', 'size_bytes')},
                            'ARCHIVE_CLOSURE_DRIFT')
                    inventory = state['inventories'][state['host']]
                    receipt = {'status': 'MATERIALS_SAVED', 'host': state['host'], 'horizon': state['horizon'],
                        'inventory_identity': inventory['identity_sha256'],
                        'units': sorted(state['units']), 'selections': sorted(state['training']),
                        'member_pins_sha256': self._closure_pins_sha(state['resolved'])}
                    self._store_staged(state['resolved'], receipt=receipt)
                    state['staged'] = True
                    for field in ('error', 'retry_at', 'failures'):
                        state.pop(field, None)
                except Exception as error:
                    self._failed(state, error)

        # At most five archive calls in the original seven-slot IO pool. A
        # timed-out reader keeps its host lease; drain only probes that lease.
        busy = {s['host'] for s in self.states.values() if s.get('inventory_future') is not None}
        leased = {s['host']: k for k,s in self.states.items() if s.get('reader_pending')}
        count = len(self.futures) + len(busy)
        # A ready transfer consumes its published inventory before the next
        # heavy inventory can take this host's exclusive directory lease.
        if not draining:
            active_hosts = {record['host'] for record in self.futures.values()}
            for _ in range(len(self.pending)):
                if len(self.futures) >= 2 or count >= 5:
                    break
                record = self.pending.popleft()
                state = self.states[record['state_key']]
                if (record['host'] in busy or record['host'] in leased
                        or not self._variant_bases_ready(record, state)
                        or time.monotonic() < record.get('retry_at', 0)
                        or observations.get(record['host'], {}).get('state') not in {'IDLE', 'RUNNING'}
                        or record['host'] in active_hosts and any(r['host'] not in active_hosts
                            and r['host'] not in busy and r['host'] not in leased
                            and self._variant_bases_ready(r, self.states[r['state_key']])
                            and observations.get(r['host'], {}).get('state') in {'IDLE', 'RUNNING'}
                            and time.monotonic() >= r.get('retry_at', 0) for r in self.pending)):
                    self.pending.append(record)
                    continue
                future = self.pool.submit(receive_archive, self.run, self.target, record,
                    command=self.command, slots=self.slots)
                self.futures[future] = record
                active_hosts.add(record['host']); count += 1
        sender_hosts = {record['host'] for record in self.futures.values()}
        for key, state in sorted(self.states.items(), key=lambda item: item[1].get('inventory_requested_at', 0)):
            host = state['host']
            probe_only = draining or state.get('reader_pending', False)
            if (count >= 5 or len(busy) >= 3 or 'expected' in state or host in busy
                    or host in sender_hosts and not probe_only
                    or leased.get(host, key) != key or time.monotonic() < state.get('retry_at', 0)
                    or observations.get(host, {}).get('state') not in {'IDLE', 'RUNNING'}
                    or draining and not state.get('reader_pending')):
                continue
            state['reader_probe'] = probe_only
            state['inventory_requested_at'] = time.monotonic()
            if not probe_only:
                state['reader_request'] = _archive_request('archive_inventory', state['horizon'])
            state['inventory_future'] = self.pool.submit(self.call, host, 'archive_inventory',
                horizon=state['horizon'], units=sorted(state['units']), selections=sorted(state['training']),
                staging=True, **({'status_only': True, **({'request':state['reader_request']}
                    if state.get('reader_request') else {})} if probe_only else
                    {'archive_request_id':state['reader_request']['request_id']}))
            busy.add(host); count += 1
        return {'status': 'STAGING_ONLY', 'window_confirmations': 0, 'hosts': {
            host: {'status': 'MATERIALS_SAVED' if states and all(s.get('staged') for s in states)
                    else 'RETRY_WAIT' if any(s.get('error') or s.get('transfer_errors') for s in states) else 'IN_PROGRESS',
                'saved_scopes': sum(bool(s.get('staged')) for s in states), 'scopes': len(states),
                'saved_members': sum(len(s.get('resolved', {})) for s in states),
                'pending_transfers': sum(s.get('transfers', 0) for s in states),
                'reasons': list(dict.fromkeys(reason for s in states
                    for reason in ([s['error']] if s.get('error') else []) + list(s.get('transfer_errors', {}).values())))}
            for host in self.run['host_connections']
            for states in [[s for s in self.states.values() if s['host'] == host]]}}

    def drained(self):
        return all(f.done() for f in self.restore_futures) and not self.futures and not any(
            r.get('oss_phase') == 'poll' for r in self.pending) and all(
            not s.get('inventory_future') and not s.get('reader_pending')
            and not s.get('inventory_futures') and not s.get('inventory_readers')
            and not s.get('ack_futures') and not s.get('ack_pending')
            for s in self.states.values())

    def staged(self):
        return self.staging and bool(self.states) and all(s.get('staged') for s in self.states.values())

    def _harvest_requests(self, state, horizon, *, confirmation=False):
        key = 'ack_futures' if confirmation else 'inventory_futures'
        futures = state[key] = state.get(key) or {}
        pending = state.setdefault('ack_pending' if confirmation else 'inventory_readers', {})
        for host, future in list(futures.items()):
            if not future.done():
                continue
            del futures[host]
            row = pending.setdefault(host, {})
            try:
                value = future.result()
                if value.get('status') == 'IN_PROGRESS':
                    if row.get('probe') and row.get('request'):
                        _need(value.get('horizon') == horizon
                            and value.get('request_id') == row['request']['request_id'],
                            'ARCHIVE_REQUEST_STATUS_INVALID')
                    row.update(status='UNKNOWN', idle=0, retry_at=time.monotonic()+5)
                    continue
                if row.pop('probe', False):
                    request = row.get('request')
                    expected = {'status':'IDLE', 'horizon':horizon,
                        **({'request_id':request['request_id']} if request else {})}
                    _need({k:v for k,v in value.items() if k != 'confirmation'} == expected,
                        'ARCHIVE_REQUEST_STATUS_INVALID')
                    row['idle'] = row.get('idle', 0)+1
                    row['retry_at'] = time.monotonic()+5
                    if row['idle'] < (2 if request else 1):
                        continue
                    if confirmation and value.get('confirmation') == state['receipt']['identity_sha256']:
                        state.setdefault('acknowledged', set()).add(host)
                    # IDLE is not an inventory or a confirmation. Only a new
                    # enabled iteration may issue genuinely unfinished work.
                elif confirmation:
                    _need(value.get('status') == 'CONFIRMED', 'ARCHIVE_ACKNOWLEDGEMENT_INVALID')
                    state.setdefault('acknowledged', set()).add(host)
                else:
                    _need(value.get('status') != 'IDLE', 'ARCHIVE_INVENTORY_RESULT_INVALID')
                    state.setdefault('inventory_results', {})[host] = value
                old_reason = row.get('reason')
                del pending[host]
                if old_reason == state.get('error'):
                    state.pop('error', None)
            except Exception as error:
                row.update(status='UNKNOWN', idle=0)
                self._failed(row, error)
                row['reason'] = row['error']
                state['error'] = row['reason']

    def _probe_requests(self, state, horizon, observations, *, confirmation=False):
        key = 'ack_futures' if confirmation else 'inventory_futures'
        futures = state[key] = state.get(key) or {}
        pending = state.setdefault('ack_pending' if confirmation else 'inventory_readers', {})
        for host, row in pending.items():
            if host not in observations or host in futures or time.monotonic() < row.get('retry_at', 0):
                continue
            row['probe'] = True
            futures[host] = self.pool.submit(self.call, host, 'archive_inventory',
                horizon=horizon, units=[], selections=[], status_only=True,
                **({'request':row['request']} if row.get('request') else {}))

    def advance(self, observations, *, draining=False):
        if not self.restored:
            if not all(f.done() for f in self.restore_futures):
                return {"restore": "VERIFYING_ARCHIVE"}
            try:
                for future in self.restore_futures:
                    self.blob_stamps.update(future.result())
                for item in self.index["members"].values():
                    if item["storage"] in self.blob_stamps:
                        self.blobs[(item["pin"]["sha256"],item["pin"]["size_bytes"])] = item
                if all(item["storage"] in self.blob_stamps for item in self.index["members"].values()):
                    self.restorable_windows = self._qualified_window_versions()
                self.restored = True
            except Exception as error:
                # Corrupt published bytes cannot authorize a remote deletion.
                return {"restore": {"status": "ATTENTION_REQUIRED", "reason": str(error)[-1800:]}}
        if getattr(self, 'staging', False):
            return self._advance_staging(observations, draining=draining)
        completed = set().union(*(set(o.get("completed_units", [])) for o in observations.values()))
        not_estimable = set().union(*(set(o.get("not_estimable_units", [])) for o in observations.values()))
        _need(not completed.intersection(not_estimable), "ARCHIVE_CONFLICTING_UNIT_TERMINALS")
        terminal = completed | not_estimable
        selected = set().union(*(set(o.get("selection_completed_units", [])) for o in observations.values()))
        post = set().union(*(set(o.get("postprocess_ready_units", [])) for o in observations.values()))
        for horizon in (6, 12, 24, 36):
            units = {u["unit_id"] for u in self.run["units"] if u["horizon"] == horizon}
            training = {u["unit_id"] for u in self.run["units"] if u["horizon"] == horizon and u["kind"] in {"PRIMARY", "FULL0"}} - not_estimable
            if draining or not units or horizon in self.states or not units <= terminal or not training <= selected & post:
                continue
            # One window inventory at a time prevents two horizons publishing
            # the same content-addressed object concurrently. Its independent
            # members still use all three transport slots.
            if not getattr(self,'oss',False) and any(not state.get("done") for state in self.states.values()):
                break
            state = self.states[horizon] = {"units": units, "training": training, "not_estimable": units & not_estimable}
            if str(horizon) in self.restorable_windows:
                receipt = self.index["windows"][str(horizon)]
                _need(set(receipt.get("not_estimable_units", [])) == state["not_estimable"]
                    and set(receipt["units"]) == units and set(receipt["selections"]) == training,
                    "ARCHIVE_TERMINAL_SOURCE_DRIFT")
                state.update(published=True, receipt=receipt)
        for future in list(self.futures):
            if future.done():
                record = self.futures[future]
                state = self.states[record["horizon"]]
                if self._sender_wait(future, record, state, observations):
                    continue
                key = (record["host"], record["inventory_identity"], n._sha(record["pins"]))
                errors = state.setdefault("transfer_errors", {})
                try:
                    rows = future.result()
                    if getattr(self,'oss',False) and 'oss_phase' in rows:
                        record.update(rows, retry_at=time.monotonic()+(5 if rows['oss_phase']=='poll' else
                            2.05 if rows['oss_phase']=='qualify' else 0))
                        del self.futures[future]
                        self.pending.append(record)
                        continue
                    self._store_staged(rows)
                    del self.futures[future]
                    state["resolved"].update(rows)
                    state["transfers"] -= 1
                    recovered = errors.pop(key, None)
                    if recovered is not None and state.get("error") == recovered:
                        if errors:
                            state["error"] = next(reversed(errors.values()))
                        else:
                            state.pop("error", None)
                            state.pop("retry_at", None)
                            state.pop("failures", None)
                except Exception as error:
                    if isinstance(error, _ArchiveSenderUnknown):
                        record['sender_request'] = error.request
                        record.pop('sender_idle_observations', None)
                        record.pop('sender_probe', None)
                        self.futures[future] = record
                        self._failed(record, error)
                    elif future.exception() is not None:
                        del self.futures[future]
                        self.pending.append(record)
                    # A successful transfer with failed index publication stays
                    # in self.futures, holding its result for publication retry.
                    self._failed(state, error)
                    errors[key] = state["error"]
        for horizon, state in self.states.items():
            # Accepted requests are harvested even in backoff or drain. Probe
            # exact requests read-only; never resend an ACK to establish exit.
            inventories = state.setdefault('inventory_results', {})
            readers = state.setdefault('inventory_readers', {})
            self._harvest_requests(state, horizon)
            self._harvest_requests(state, horizon, confirmation=True)
            self._probe_requests(state, horizon, observations)
            self._probe_requests(state, horizon, observations, confirmation=True)
            if 'error' not in state:
                reasons = [row['reason'] for pending in ('inventory_readers','ack_pending')
                    for row in state.get(pending,{}).values()
                    if row.get('status') == 'UNKNOWN' and row.get('reason')]
                if reasons: state['error'] = reasons[0]
            if draining or state.get("done") or time.monotonic() < state.get("retry_at", 0):
                continue
            try:
                _need(_archive_volume(self.target.parent) == strict_json_bytes((self.target / "volume.json").read_bytes()),
                    "ARCHIVE_VOLUME_CHANGED")
                if "expected" not in state and not state.get("published"):
                    inventories = state.setdefault("inventory_results", {})
                    futures = state.setdefault("inventory_futures", {})
                    for host, o in observations.items():
                        if host not in inventories and host not in futures and host not in readers:
                            if getattr(self,'oss',False) and (any(host in s.get('inventory_readers',{})
                                    for s in self.states.values()) or any(r['host']==host and r.get('oss_phase') in
                                        {'prepare','upload','poll'} for r in [*self.pending,*self.futures.values()])):
                                continue
                            request = _archive_request('archive_inventory', horizon)
                            readers[host] = {'request':request, 'status':'RUNNING'}
                            futures[host] = self.pool.submit(self.call, host, "archive_inventory", horizon=horizon,
                                units=sorted(state["units"] & (set(o.get("completed_units", [])) | set(o.get("not_estimable_units", [])))),
                                selections=sorted(state["training"] & set(o.get("selection_completed_units", []))),
                                archive_request_id=request['request_id'])
                    if set(inventories) == set(self.run["host_connections"]):
                        state.pop('error', None)
                        self._plan(horizon, inventories)
                for name,(origin_key,origin_name) in state.get('shared',{}).items():
                    origin = self.states[origin_key].get('resolved',{})
                    if origin_name in origin: state['resolved'][name]=origin[origin_name]
                if state.get("transfers") == 0 and not state.get("published") and all(
                        name in state.get('resolved',{}) for name in state.get('shared',{})):
                    self._finish(horizon)
                if state.get("published"):
                    acknowledged = state.setdefault("acknowledged", set())
                    futures = state.setdefault("ack_futures", {})
                    for host in self.run["host_connections"]:
                        if host not in acknowledged and host not in futures and host not in state['ack_pending']:
                            receipt = state['receipt']
                            extra = {}
                            if receipt.get('previous_window_identity'):
                                parent = state.get('previous_receipt') or _archive_parent_receipt(
                                    self.target/'windows', horizon, receipt['previous_window_identity'])
                                extra['previous_receipt'] = parent
                            request = _archive_request('archive_confirm', horizon, receipt=receipt)
                            state['ack_pending'][host] = {'request':request, 'status':'RUNNING'}
                            futures[host] = self.pool.submit(self.call, host, 'archive_confirm', receipt=receipt,
                                archive_request_id=request['request_id'], **extra)
                    if acknowledged == set(self.run["host_connections"]):
                        if getattr(self,'oss',False):
                            confirmed=n._sealed({'status':'ALL_HOSTS_CONFIRMED',
                                'generation':self.run['archive_transfer']['generation'],
                                'window_identity':state['receipt']['identity_sha256'],
                                'hosts':sorted(acknowledged)})
                            _publish(self.target/'windows'/f'H{horizon:02d}-oss-confirmed.json',
                                canonical_json_bytes(confirmed),'ARCHIVE_ACKNOWLEDGEMENT_DRIFT')
                        state["done"] = True
                        state.pop("error", None)
            except Exception as error:
                self._failed(state, error)
        if getattr(self,'oss',False):
            self._refill_oss(observations,draining=draining)
        for _ in range(0 if getattr(self,'oss',False) else len(self.pending)):
            # Leave a global large-transfer slot for ready scientific inputs.
            if draining or len(self.futures) >= 2:
                break
            record = self.pending.popleft()
            if time.monotonic() < self.states[record["horizon"]].get("retry_at", 0):
                self.pending.append(record)
                continue
            future = self.pool.submit(receive_archive, self.run, self.target, record, command=self.command, slots=self.slots)
            self.futures[future] = record
        return {str(h): ("CONFIRMED" if s.get("done") else
            {"status": "RETRY_WAIT", "reason": s["error"]} if s.get("error") else
            {"status": "IN_PROGRESS", "phase": "INVENTORY"}
                if 'expected' not in s and not s.get('published') else "TRANSFERRING")
            for h, s in self.states.items()}

    def _refill_oss(self, observations, *, draining=False):
        # Remote uploads are asynchronous; small phase RPCs release the original
        # seven-slot pool. Two downloads still leave slots for owners and probes.
        records = [*self.pending,*self.futures.values()]
        for r in records:
            if 'oss_owner' not in r:_oss_transport_owner(self.run,self.target,r)
        host_of=lambda r:r.get('oss_owner',r)['host']
        uploading = {host_of(r) for r in records if r.get('oss_phase') in {'upload','poll'}}
        busy = {host_of(r) for r in self.futures.values()}
        readers = {h for s in self.states.values() for h in s.get('inventory_readers',{})}
        self.pending = __import__('collections').deque(sorted(self.pending,key=lambda r:
            (r.get('oss_phase')!='poll',-sum(p['size_bytes'] for p in r['pins'].values()))))
        for _ in range(len(self.pending)):
            if len(self.futures) >= 5: break
            record = self.pending.popleft(); phase=record.get('oss_phase','prepare'); host=host_of(record)
            downloads=[r for r in self.futures.values() if r.get('oss_phase') in {'download','qualify'}]
            if ((draining and phase!='poll') or host in busy or host in readers
                or phase=='prepare' and host in uploading or phase in {'download','qualify'} and len(downloads)>=2
                or time.monotonic() < record.get('retry_at',0)
                or observations.get(host,{}).get('state') not in {'IDLE','RUNNING'}
                or not self._variant_bases_ready(record,self.states[record['horizon']])):
                self.pending.append(record); continue
            if phase=='download':
                def remaining(r):
                    material=r['oss_material'];destination=self.target/material['storage']
                    partial=destination.with_name(destination.name+'.part')
                    if destination.is_file():return 0
                    _need(not partial.is_symlink(),'ARCHIVE_PART_PATH_INVALID')
                    return max(0,material['physical']['size_bytes']-(partial.stat().st_size if partial.is_file() else 0))
                record['other_write_reserve']=sum(remaining(r) for r in downloads)
            record['oss_phase']=phase
            future=self.pool.submit(archive_oss_step,self.run,self.target,record,command=self.command)
            self.futures[future]=record;busy.add(host)
            if phase in {'upload','poll'}: uploading.add(host)

    def complete(self):
        return not getattr(self, 'staging', False) and len(self.states) == 4 and all(state.get("done") for state in self.states.values())


def report_names(run, units, selections, *, receipts=None):
    known = {u["unit_id"]:u for u in run["units"]}
    if not set(units) <= set(known) or not set(selections) <= {u for u,v in known.items() if v["kind"] in {"PRIMARY","FULL0"}}:
        raise ContractError("REPORT_SCOPE_INVALID")
    names = []
    for uid in sorted(units):
        unit, prefix = known[uid], "units/" + uid + "/"
        names.append(prefix + "unit.json")
        receipt = receipts[uid] if receipts is not None else None
        if receipt is not None and receipt["status"] == "NOT_ESTIMABLE":
            # Negative report tables are optional real members, never fake model outputs.
            names.extend(prefix + name for name in ("report-estimability.json",
                *(f"report-H{unit['horizon']:02d}-{kind}.csv" for kind in ("absolute_rows", "paired_rows")))
                if name in receipt["artifacts"])
            continue
        if unit["kind"] in {"PRIMARY", "FULL0"}:
            names += [prefix + "postprocess/" + name for name in ("result.json", "o-fit.csv", "diagnostics/result.json")]
        if unit["kind"] == "EVALUATION":
            names += [prefix + f"report-H{unit['horizon']:02d}-{name}.csv" for name in ("absolute_rows", "paired_rows")]
            if receipt is not None and "report-estimability.json" in receipt["artifacts"]:
                names.append(prefix + "report-estimability.json")
        if unit["kind"] == "FULL0":
            names += [prefix + name for name in ("application.json", "report-summary.json")]
        if run.get('evaluation_decision') is not None and unit['kind'] in {'PRIMARY','FULL0','EVALUATION'}:
            appendix = prefix + ('postprocess/' if unit['kind'] in {'PRIMARY','FULL0'} else '') + 'evaluation-amendment/'
            names += [appendix+name for name in ('result.json','point.zip','metrics.csv','intervals.zip')]
        if run.get('post_result_repair') is not None and unit['kind'] in {'PRIMARY','FULL0','EVALUATION'}:
            repaired = prefix + ('postprocess/' if unit['kind'] in {'PRIMARY','FULL0'} else '') + 'post-result-repair-20261008/'
            names += [repaired+name for name in ('result.json','calibration/result.json',
                'calibration/metrics.csv','calibration/intervals.zip')]
            names += [prefix+'post-result-repair-20261008/auc-exp1/'+name for name in ('result.json','intervals.json')]
            if unit['kind'] == 'PRIMARY':
                names += [prefix+'post-result-repair-20261008/a04/'+name for name in ('result.json','evaluation.json')]
                if unit['horizon'] == 6:
                    names.append(prefix+'post-result-repair-20261008/auc-validation/result.json')
            elif unit['kind'] == 'FULL0':
                from .f5_application import application_repair_decision
                application = prefix+'application-repair/'+application_repair_decision()['identity_sha256']+'/'
                names += [application+'result.json',application+'full-a04/result.json']
                if unit['horizon'] == 36: names.append(prefix+'post-result-repair-20261008/mi-diagnostic.json')
            else:
                names.append(prefix+'post-result-repair-20261008/a04-summary.json')
    if run.get('curve_rmse') is not None:
        from .curve_rmse import eligible,relative_result
        names += [relative_result(known[uid]) for uid in units if eligible(run,known[uid])]
    if run.get('result_closure') is not None:
        from .result_closure import eligible,relative_result
        names += [relative_result(known[uid]) for uid in units if eligible(run,known[uid])]
    if run.get('evaluation_extension') is not None:
        from .evaluation_extension import eligible,relative_result,clinical_eligible,clinical_name,GATE
        names += [relative_result(known[uid]) for uid in units if eligible(run,known[uid])]
        names += [clinical_name(known[uid]) for uid in units if clinical_eligible(run,known[uid])]
        names.append(GATE)
    for uid in sorted(selections):
        names += [f"units/EVALUATION-H{known[uid]['horizon']:02d}/selection/{uid}/{name}"
                  for name in ("result.json", "selection.csv")]
        if run.get('evaluation_decision') is not None:
            names += [f"units/EVALUATION-H{known[uid]['horizon']:02d}/selection/{uid}/evaluation-amendment/{name}"
                for name in ('result.json','point.zip','metrics.csv','intervals.zip')]
        if run.get('post_result_repair') is not None:
            names.append(f"units/EVALUATION-H{known[uid]['horizon']:02d}/selection/{uid}/post-result-repair-20261008/result.json")
    return names


def _repair_report_names(unit):
    from .f5_application import application_repair_decision
    prefix = 'units/'+unit['unit_id']+'/'
    tail = prefix+('postprocess/' if unit['kind'] in {'PRIMARY','FULL0'} else '')+'post-result-repair-20261008/'
    names = [tail+'result.json',tail+'calibration/result.json',
        prefix+'post-result-repair-20261008/auc-exp1/result.json']
    if unit['kind'] == 'PRIMARY':
        names.append(prefix+'post-result-repair-20261008/a04/result.json')
        if unit['horizon'] == 6: names.append(prefix+'post-result-repair-20261008/auc-validation/result.json')
    elif unit['kind'] == 'FULL0':
        application = prefix+'application-repair/'+application_repair_decision()['identity_sha256']+'/'
        names += [application+'result.json',application+'full-a04/result.json']
        if unit['horizon'] == 36: names.append(prefix+'post-result-repair-20261008/mi-diagnostic.json')
    else:
        _need(unit['kind'] == 'EVALUATION','REPORT_REPAIR_SCOPE_INVALID')
        names.append(prefix+'post-result-repair-20261008/a04-summary.json')
    return names


def _repair_report_child_pin(run,completion,name):
    refs = [ref for ref in completion['formal_references'] if ref['path'] == name]
    _need(len(refs) == 1 and refs[0]['producer'] in same_batch_generations(run).values(),
        'REPORT_REPAIR_REFERENCE_DRIFT')
    pin = {k:refs[0][k] for k in ('sha256','size_bytes')}
    _need(type(pin['size_bytes']) is int and 0 < pin['size_bytes'] <= 64*1024**2,
        'REPORT_REPAIR_METADATA_SIZE_INVALID')
    return pin


def repair_report_dependencies(run,unit):
    """Exact small heads for existing pin/send; no archive inventory or leaf scan."""
    from . import f4
    base = Path(run['run_root'])
    original_path = f4.evaluation_appendix_root(run,unit)/'result.json'
    _need(original_path.is_file() and not original_path.is_symlink()
        and original_path.stat().st_size <= 8*1024**2,'REPORT_REPAIR_ORIGINAL_HEADER_INVALID')
    raw = original_path.read_bytes()
    original = f4._f45_optimism_json(raw)
    f4._evaluation_check_producer(original,same_batch_generations(run))
    identity = f4._evaluation_appendix_identity(run,unit,None,original['sources'])
    _need(all(original[k] == v for k,v in identity.items()) and original['status'] == 'COMPLETED'
        and original['direct_consumer_completed'] is True,'REPORT_REPAIR_ORIGINAL_HEADER_DRIFT')
    completion = f4._post_result_repair_read(run,unit,None,original,observation=True)
    _need(completion is not None,'REPORT_REPAIR_COMPONENT_INCOMPLETE')
    original_pin = _repair_report_child_pin(run,completion,original_path.relative_to(base).as_posix())
    _need(original_pin == {'sha256':hashlib.sha256(raw).hexdigest(),'size_bytes':len(raw)},
        'REPORT_REPAIR_ORIGINAL_HEADER_DRIFT')
    names = _repair_report_names(unit)
    return {names[0]:None,**{name:_repair_report_child_pin(run,completion,name) for name in names[1:]}}


def collect_repair(run,observations,*,report_root,call,command,pool):
    """Pre-archive direct consumer, under the original dispatcher and I/O pool."""
    from .f4 import _f45_optimism_csv
    hosts = {}
    for host,observed in observations.items():
        for uid in observed.get('evaluation_amendment_units',[]):
            _need(uid not in hosts,'REPORT_REPAIR_MULTIPLE_PRODUCERS')
            hosts[uid] = host
    units = [u for u in run['units'] if u['kind'] in {'PRIMARY','FULL0','EVALUATION'}]
    _need(all(u['unit_id'] in hosts for u in units),'REPORT_REPAIR_HOST_MISSING')
    # One already qualified historical report, not another 47 MiB copy. The
    # native completion heads bind every child consumed by that old report.
    from .run import f45_unit_predecessors
    candidates = [(Path(report_root)/'repair-results.json', run)]
    if run.get('result_closure') is not None and not candidates[0][0].exists():
        # The native chain verifier checks every edge and reuses source proof.
        # Locate each report beside its immutable manifest, nearest first.
        generations = [run, *f45_unit_predecessors(run)]
        for owner, previous_run in zip(generations, generations[1:]):
            predecessor = owner.get('unit_predecessor', {})
            prior_tag = Path(predecessor.get('run_path', '')).parent.name
            candidates.append((Path(report_root).parent /
                ('run-repair-'+prior_tag+'.repair-report') / 'repair-results.json', previous_run))
    for retained, previous_run in candidates:
        if not retained.exists() and not retained.is_symlink():
            continue
        _need(retained.is_file() and not any(p.is_symlink() for p in (retained,*retained.parents)),
            'REPORT_RETAINED_HISTORY_DRIFT')
        old = strict_json_bytes(retained.read_bytes())
        _need(not retained.is_symlink() and old['run_identity'] == previous_run['identity']
            and n._sealed({k:v for k,v in old.items() if k != 'identity_sha256'}) == old,
            'REPORT_RETAINED_HISTORY_DRIFT')
        names = [(u['unit_id'],_repair_report_names(u)[0]) for u in units]
        probes = [pool.submit(call,hosts[uid],'pin',member=name,report_of=uid) for uid,name in names]
        _need(all(f.result() == old['direct_consumer_sources'][name]
            for f,(_,name) in zip(probes,names,strict=True)), 'REPORT_RETAINED_SOURCE_DRIFT')
        # A crash after the JSON publication only owes its tiny CSV consumer.
        _publish(retained.with_name('original-application-96.csv'),
            _f45_optimism_csv(old['original_application_rows']), 'REPORT_APPLICATION_REGRESSION_DRIFT')
        return {'status':'REUSED_UNCHANGED_HISTORICAL_REPAIR','report':str(retained),
            'source_head_count':len(names),'new_historical_report_copies':0,'archive_mode':'PAUSED'}
    def fetch_unit(unit):
        names = _repair_report_names(unit)
        host,values,pins = hosts[unit['unit_id']],{},{}
        for name in names:
            pin = (call(host,'pin',member=name,report_of=unit['unit_id']) if name == names[0]
                else _repair_report_child_pin(run,values[names[0]],name))
            _need(set(pin) == {'sha256','size_bytes'} and 0 < pin['size_bytes'] <= 64*1024**2,
                'REPORT_REPAIR_SOURCE_ABSENT_OR_OVERSIZE')
            response = subprocess.run(command(host,'send',member=name,pin=pin,report_of=unit['unit_id']),
                capture_output=True,timeout=60,check=False)
            _need(response.returncode == 0,'REPORT_REPAIR_TRANSPORT_FAILED:'+host+':'+name)
            _need(len(response.stdout) == pin['size_bytes']
                and hashlib.sha256(response.stdout).hexdigest() == pin['sha256'],'REPORT_REPAIR_BYTES_DRIFT')
            values[name],pins[name] = strict_json_bytes(response.stdout),pin
        return values,pins
    jobs = [pool.submit(fetch_unit,unit) for unit in units]
    values,pins = {},{}
    for job in jobs:
        v,p = job.result(); values.update(v); pins.update(p)
    repaired = post_result_report(run,values.__getitem__)
    repaired = n._sealed({**{k:v for k,v in repaired.items() if k != 'identity_sha256'},
        'direct_consumer_sources':pins})
    base = Path(report_root)
    _need(base.is_absolute() and not any(p.is_symlink() for p in (base,*base.parents)),
        'REPORT_DESTINATION_PATH_INVALID')
    base.mkdir(parents=True,exist_ok=True)
    _publish(base/'repair-results.json',canonical_json_bytes(repaired),'REPORT_REPAIR_DRIFT')
    _publish(base/'original-application-96.csv',_f45_optimism_csv(repaired['original_application_rows']),
        'REPORT_APPLICATION_REGRESSION_DRIFT')
    return {'status':'COMPUTED_NOT_AUTOMATICALLY_ACCEPTED','report':str(base/'repair-results.json'),
        'archive_mode':'PAUSED','source_head_count':len(pins)}


def collect_curves(run,observations,*,report_root,call,command,pool):
    """Eight independent small transfers on the original I/O pool."""
    from .curve_rmse import eligible,relative_result,RESULT_LIMIT,write_report
    units = [u for u in run['units'] if eligible(run,u)]
    hosts = {}
    for host, observation in observations.items():
        for uid in observation.get('evaluation_amendment_units',[]):
            _need(uid not in hosts,'CURVE_RMSE_MULTIPLE_PRODUCERS')
            hosts[uid] = host
    _need(len(units)==8 and all(u['unit_id'] in hosts for u in units),'CURVE_RMSE_SOURCE_INCOMPLETE')
    saved = Path(report_root)/'curve-rmse-results.json'
    if saved.is_file():
        from .f4 import _f45_optimism_json
        _need(not saved.is_symlink() and saved.stat().st_size<=16*RESULT_LIMIT,'CURVE_RMSE_REPORT_INVALID')
        # Each remote observation has just checked the real source stamps. The
        # local direct consumer can reuse its compact numerical output.
        previous = _f45_optimism_json(saved.read_bytes())
        _need({uid:v['identity_sha256'] for uid,v in previous['coordinates'].items()} ==
            {u['unit_id']:observations[hosts[u['unit_id']]].get('curve_result_identities',{}).get(u['unit_id'])
             for u in units},'CURVE_RMSE_REPORT_SOURCE_DRIFT')
        return write_report(run,previous['coordinates'],Path(report_root))
    def fetch(unit):
        uid=unit['unit_id'];name=relative_result(unit);host=hosts[uid]
        pin=call(host,'pin',member=name,report_of=uid)
        _need(set(pin)=={'sha256','size_bytes'} and 0<pin['size_bytes']<=RESULT_LIMIT,'CURVE_RMSE_TRANSFER_INVALID')
        response=subprocess.run(command(host,'send',member=name,pin=pin,report_of=uid),
            capture_output=True,timeout=60,check=False)
        _need(response.returncode==0 and len(response.stdout)==pin['size_bytes']
            and hashlib.sha256(response.stdout).hexdigest()==pin['sha256'],'CURVE_RMSE_TRANSFER_DRIFT')
        return uid,strict_json_bytes(response.stdout)
    jobs=[pool.submit(fetch,u) for u in units]
    return write_report(run,dict(job.result() for job in jobs),Path(report_root))


def collect_closure(run,observations,*,report_root,call,command,pool,repair_report):
    """Pre-archive report consumption of eight bounded evaluation-only heads."""
    from .result_closure import eligible,relative_result,validate_result,effective_report,LIMIT
    from .f4 import _f45_optimism_csv
    units = [u for u in run['units'] if eligible(run,u)]
    hosts = {uid:h for h,o in observations.items() for uid in o.get('result_closure_identities',{})}
    _need(len(units)==8 and all(u['unit_id'] in hosts for u in units),'REPORT_CLOSURE_COVERAGE')
    def fetch(unit):
        uid=unit['unit_id'];host=hosts[uid];name=relative_result(unit)
        pin=call(host,'pin',member=name,report_of=uid)
        _need(set(pin)=={'sha256','size_bytes'} and 0<pin['size_bytes']<=LIMIT,'REPORT_CLOSURE_SIZE')
        response=subprocess.run(command(host,'send',member=name,pin=pin,report_of=uid),
            capture_output=True,timeout=60,check=False)
        _need(response.returncode==0 and len(response.stdout)==pin['size_bytes']
            and hashlib.sha256(response.stdout).hexdigest()==pin['sha256'],'REPORT_CLOSURE_TRANSPORT')
        value=validate_result(run,unit,strict_json_bytes(response.stdout))
        _need(value['identity_sha256']==observations[host]['result_closure_identities'][uid],
            'REPORT_CLOSURE_OBSERVATION_DRIFT')
        return uid,value
    root=Path(report_root);root.mkdir(parents=True,exist_ok=True)
    destination=root/'current-evaluation.json'
    if destination.is_file():
        saved=strict_json_bytes(destination.read_bytes())
        _need(saved['run_identity']==run['identity']
            and saved['decision_sha256']==run['result_closure']['identity_sha256'],
            'REPORT_CLOSURE_RULE_DRIFT')
        _need(saved['cross_time']['sources']=={u['unit_id']:observations[hosts[u['unit_id']]][
            'result_closure_identities'][u['unit_id']] for u in units},'REPORT_CLOSURE_SOURCE_DRIFT')
        _need(n._sealed({k:v for k,v in saved.items() if k!='identity_sha256'})==saved,
            'REPORT_CLOSURE_BYTES_DRIFT')
        history=strict_json_bytes(Path(repair_report['report']).read_bytes())
        _need(saved['history']['direct_consumer_sources']==history['direct_consumer_sources'],
            'REPORT_CLOSURE_HISTORY_DRIFT')
        write_effective_report(root,saved)
        return {'status':saved['status'],'report':str(destination),'identity_sha256':saved['identity_sha256']}
    jobs=[pool.submit(fetch,u) for u in units]
    records=dict(f.result() for f in jobs)
    history=strict_json_bytes(Path(repair_report['report']).read_bytes())
    report=effective_report(run,records,history,repair_reference={
        'direct_consumer_sources':history['direct_consumer_sources'],
        'status':'HISTORICAL_UNCHANGED_CURRENT_DEFINITIONS_SEPARATE'})
    write_effective_report(root,report)
    return {'status':report['status'],'report':str(destination),'identity_sha256':report['identity_sha256']}


def write_effective_report(root,report):
    from .f4 import _f45_optimism_csv
    root=Path(root);root.mkdir(parents=True,exist_ok=True)
    _need(n._sealed({k:v for k,v in report.items() if k!='identity_sha256'})==report,
        'REPORT_CLOSURE_BYTES_DRIFT')
    _publish(root/'cross-time-diagnostics.json',canonical_json_bytes(report['cross_time']),'REPORT_CROSS_TIME_DRIFT')
    rows=[]
    for h,line in report['a04'].items():
        for case,scopes in line['a04']['cases'].items():
            for scope,item in scopes.items():
                for branch,months in item['rows'].items():
                    for month,values in months.items():
                        metrics={'auc':values['auc'],**{k:v for k,v in values['calibration'].items() if k!='curve'},
                            **({'uno':values['uno']} if 'uno' in values else {})}
                        for metric,value in metrics.items():
                            rows.append({'development_month':int(h),'case':case,'scope':scope,'branch':branch,
                                'report_month':int(month),'metric':metric,'definition':'EVALUATION_CLOSURE_20261009',
                                'diagnostic_role':_closure_metric_role(metric,int(h),int(month)),
                                'metric_scale':'ORIGINAL_METRIC','coordinate_role':'BASE_COORDINATE',
                                'status':value['status'],'value':value['value'],'reasons':'|'.join(value['reasons'])})
        for case,methods in line['a04']['fixed_center_macros'].items():
            for method,item in methods.items():
                for branch,months in item['rows'].items():
                    for month,metrics in months.items():
                        for metric,value in metrics.items():
                            rows.append({'development_month':int(h),'case':case,'scope':method,'branch':branch,
                                'report_month':int(month),'metric':metric,'definition':'EVALUATION_CLOSURE_20261009',
                                'diagnostic_role':_closure_metric_role(metric,int(h),int(month)),
                                'metric_scale':item['metric_scales'].get(metric,item['metric_scales']['other']),
                                'coordinate_role':'FIXED_CENTER_MACRO',
                                'status':value['status'],'value':value['value'],'reasons':'|'.join(value['reasons'])})
    rows.sort(key=lambda r:tuple(r[k] for k in ('development_month','case','scope',
        'branch','report_month','coordinate_role','metric')))
    _publish(root/'a04-current-metrics.csv',_f45_optimism_csv(rows),'REPORT_A04_METRICS_DRIFT')
    _publish(root/'current-evaluation.json',canonical_json_bytes(report),'REPORT_CLOSURE_DRIFT')


def extension_report(run, heads, children, current):
    """One direct numerical consumer, also used by the future offline reader."""
    from .bundle import validate_sha256
    from .evaluation_extension import decision, eligible, relative_result, validate_result, validate_mi, PREFIX, RESEARCH_UNITS
    from .auc_research import complete_summary
    from .f4 import _evaluation_check_producer
    known = {u['unit_id']:u for u in run['units'] if eligible(run,u)}
    _need(set(heads) == set(known), 'REPORT_EXTENSION_OWNER_COVERAGE')
    generations = same_batch_generations(run)
    mi, research, h36 = {}, {}, None
    for uid,head in heads.items():
        validate_result(run,known[uid],head)
        for name,value in children[uid].items():
            raw = canonical_json_bytes(value)
            _need(head['sources'][name] == {'sha256':hashlib.sha256(raw).hexdigest(), 'size_bytes':len(raw)}
                and n._sealed({k:v for k,v in value.items() if k != 'identity_sha256'}) == value,
                'REPORT_EXTENSION_CHILD_DRIFT')
            if name == 'units/FULL0-H36/post-result-repair-20261008/mi-diagnostic.json':
                validate_mi(value)
                _need(uid == 'FULL0-H06' and value['identity_sha256'] ==
                    head['components']['h36_mi_reference']['source_identity']
                    and value['binding']['source_unit'] == 'FULL0-H36',
                    'REPORT_EXTENSION_H36_SOURCE_DRIFT')
                h36 = value
            elif name.endswith('/mi-diagnostic.json'):
                validate_mi(value)
                _need(value['binding']['source_unit'] == uid
                    and value['binding']['decision_sha256'] == decision()['identity_sha256']
                    and value['identity_sha256'] == head['components']['mi']['source_identity']
                    and value['new_prediction_model_fits'] == value['new_mice_chains'] == value['new_shap_solves'] == 0
                    and value['status'] == 'COMPLETED' and value['unresolved_numerical_failures'] == 0
                    and len(value['coordinates']) == 10,'REPORT_EXTENSION_MI_DRIFT')
                mi[str(known[uid]['horizon'])] = {k:value[k] for k in ('identity_sha256','coordinates',
                    'patient_count','patient_order_sha256','centers','ipcw_population','statistical_not_estimable')}
            elif name.endswith('/research/result.json'):
                _evaluation_check_producer(value,generations)
                _need(uid in RESEARCH_UNITS and value['identity_sha256'] ==
                    head['components']['research']['identity_sha256'], 'REPORT_EXTENSION_RESEARCH_DRIFT')
                research[uid] = value
            else:
                raise ContractError('REPORT_EXTENSION_UNEXPECTED_CHILD')
    _need(set(mi) == {'6','12','24'}, 'REPORT_EXTENSION_MI_COVERAGE')
    original = current['full0_h36_legacy_incomplete_resolution']
    _need(h36 is not None and len(original['current_coordinates']) == 10
        and original['unresolved_numerical_failures'] == h36['unresolved_numerical_failures'] == 0
        and original['current_source_identity'] == h36['identity_sha256']
        and original['current_coordinates'] == h36['coordinates'],
        'REPORT_EXTENSION_H36_REQUIRED')
    mi['36'] = {**{k:h36[k] for k in ('identity_sha256','coordinates','ipcw_population',
        'patient_count','patient_order_sha256','centers','statistical_not_estimable')},
        'role':'REFERENCE_UNCHANGED_PREVIOUS_DIAGNOSTIC','new_calibration_fits':0}
    populations = {(r['patient_count'],r['patient_order_sha256'],tuple(r['centers']))
        for r in mi.values()}
    _need(len(populations) == 1, 'REPORT_EXTENSION_MI_POPULATION_DRIFT')
    coverage = heads['FULL0-H06']['components']['application_coverage']
    from .f5_application import application_repair_decision
    for h,line in coverage['lines'].items():
        _need(line['source']==f'\u0075nits/FULL0-H{int(h):02d}/application-repair/'+
            application_repair_decision()['identity_sha256']+'/full-a04/cohort/cohort.json',
            'REPORT_EXTENSION_APPLICATION_SOURCE_DRIFT')
        validate_sha256(line['patient_order_sha256'],'application.patient_order')
    _need(coverage['unique_patients_across_four_lines'] == 179
        and coverage['line_patient_assessments'] == 716
        and set(coverage['lines']) == {'6','12','24','36'}
        and all(v['center_counts'] == {'36':50,'38':2,'39':50,'48':12,'52':50,'54':15}
            and v['patient_count'] == 179 for v in coverage['lines'].values()),
        'REPORT_EXTENSION_APPLICATION_COVERAGE_DRIFT')
    study = complete_summary(research)
    return n._sealed({'kind':'PADML_RESULT_EXTENSION_REPORT_V1','run_identity':run['identity'],
        'decision_sha256':decision()['identity_sha256'],'status':'COMPUTED_REQUIRES_CHAIN_ACCEPTANCE',
        'source_identities':{uid:head['identity_sha256'] for uid,head in heads.items()},
        'current_evaluation_identity':current['identity_sha256'],
        'mi_panel':mi,'mi_coordinate_count':40,'new_mi_coordinates':30,'mi_calibration_fit_ceiling':18,
        'application_coverage':coverage,'research':study,
        'completion_domains':{
            'required_diagnostics':{'status':'COMPUTED_AND_DIRECTLY_CONSUMED','mi_coordinates':40},
            'new_method_research':{'status':study['status'], 'clinical_reliability':'SCOPE_SPECIFIC_NOT_AUTOMATIC'},
            'engineering_closure':{'status':'REQUIRES_REPRODUCTION_FIX_PRODUCT_CONSUMPTION_RECOVERY_EVIDENCE'},
            'statistical_limitations':{'status':'RETAINED','historical_interval_disposition_reference':
                current['identity_sha256'],'negative_control_alerts':current['a04_review_required_lines'],
                'cross_time_reference':current['cross_time']['identity_sha256']},
            'delivery':{'status':'PAUSED_BY_USER','archive_resume':'REQUIRES_NEW_EXPLICIT_AUTHORIZATION'}},
        'historical_results':'UNCHANGED_REFERENCE_ONLY','original96_regression':current['original_application'],
        'new_training_mice':0,'new_prediction_model_fits':0,'new_shap_solves':0,
        'clinical_validity':'NOT_ESTABLISHED_BY_TASK_COMPLETION_OR_SIMULATION_PASS'})


def write_extension_report(root, value, *, filename='evaluation-extension.json'):
    from .f4 import _f45_optimism_csv
    _need(n._sealed({k:v for k,v in value.items() if k != 'identity_sha256'}) == value,
        'REPORT_EXTENSION_BYTES_DRIFT')
    root = Path(root); root.mkdir(parents=True,exist_ok=True)
    rows = []
    for h,line in sorted(value['mi_panel'].items(),key=lambda item:int(item[0])):
        for item in line['coordinates']:
            rows.append({'development_month':int(h),'report_month':36,'diagnostic':item['original_check'],
                **{k:item[k]['value'] for k in ('odd','even','absolute_difference')},
                **{k+'_status':item[k]['status'] for k in ('odd','even','absolute_difference')},
                'population':line['ipcw_population'],'source_identity':line['identity_sha256']})
    _publish(root/'four-line-mi36.csv',_f45_optimism_csv(rows),'REPORT_EXTENSION_MI_TABLE_DRIFT')
    _publish(root/filename,canonical_json_bytes(value),'REPORT_EXTENSION_DRIFT')


def collect_extension(run,observations,*,report_root,call,command,pool,repair_report,closure_report):
    from .evaluation_extension import eligible,relative_result,validate_result,LIMIT
    units = [u for u in run['units'] if eligible(run,u)]
    hosts = {uid:h for h,o in observations.items() for uid in o.get('evaluation_extension_identities',{})}
    _need(len(units) == 9 and all(u['unit_id'] in hosts for u in units),'REPORT_EXTENSION_COVERAGE')
    expected = {u['unit_id']:observations[hosts[u['unit_id']]]['evaluation_extension_identities'][u['unit_id']]
        for u in units}
    root = Path(report_root); root.mkdir(parents=True,exist_ok=True)
    target = root/'research-extension.json'
    if not target.is_file() and (root/'evaluation-extension.json').is_file():
        target=root/'evaluation-extension.json'
    if target.is_file():
        saved = strict_json_bytes(target.read_bytes())
        _need(saved['run_identity'] == run['identity'] and saved['decision_sha256'] == run['evaluation_extension']['identity_sha256']
            and saved['source_identities'] == expected and saved['current_evaluation_identity'] == closure_report['identity_sha256'],
            'REPORT_EXTENSION_SOURCE_DRIFT')
        write_extension_report(root,saved,filename=target.name)
        return {'status':saved['status'],'report':str(target),'identity_sha256':saved['identity_sha256']}
    def fetch(unit):
        uid = unit['unit_id']; host = hosts[uid]
        def read(name,pin=None):
            pin = call(host,'pin',member=name,report_of=uid) if pin is None else pin
            _need(set(pin) == {'sha256','size_bytes'} and 0 < pin['size_bytes'] <= LIMIT,'REPORT_EXTENSION_SIZE')
            response = subprocess.run(command(host,'send',member=name,pin=pin,report_of=uid),
                capture_output=True,timeout=60,check=False)
            _need(response.returncode == 0 and len(response.stdout) == pin['size_bytes']
                and hashlib.sha256(response.stdout).hexdigest() == pin['sha256'],'REPORT_EXTENSION_TRANSPORT')
            return strict_json_bytes(response.stdout)
        head = validate_result(run,unit,read(relative_result(unit)))
        _need(head['identity_sha256'] == expected[uid],'REPORT_EXTENSION_OBSERVATION_DRIFT')
        prefix = relative_result(unit).rsplit('/',1)[0]+'/'
        return uid,head,{name:read(name,pin) for name,pin in head['sources'].items()
            if name.startswith(prefix) or name ==
                head['components'].get('h36_mi_reference',{}).get('source')}
    jobs = [pool.submit(fetch,u) for u in units]
    material = [job.result() for job in jobs]
    current = strict_json_bytes(Path(closure_report['report']).read_bytes())
    _need(current['identity_sha256'] == closure_report['identity_sha256'], 'REPORT_EXTENSION_CURRENT_DRIFT')
    value = extension_report(run,{uid:head for uid,head,_ in material},
        {uid:children for uid,_,children in material},current)
    write_extension_report(root,value,filename=target.name)
    return {'status':value['status'],'report':str(target),'identity_sha256':value['identity_sha256']}


def finish_extension_report(run,research,gate,records):
    from .evaluation_extension import clinical_eligible,validate_clinical,validate_gate,research_gate
    validate_gate(run,gate)
    _need(gate==research_gate(run,research['research'],research['source_identities']),
        'REPORT_EXTENSION_CLINICAL_GATE_DRIFT')
    units={u['unit_id']:u for u in run['units'] if clinical_eligible(run,u)}
    _need(len(units)==32 and set(records)==set(units),'REPORT_EXTENSION_CLINICAL_COVERAGE')
    for uid,value in records.items():validate_clinical(run,units[uid],value,gate)
    body={k:v for k,v in research.items() if k not in {'identity_sha256','clinical_supplement',
        'clinical_source_identities','clinical_gate_identity'}}
    body.update(clinical_supplement={'status':'ALL_32_SCOPES_DISPOSITION_COMPLETE',
        'units':{uid:{'rows':v['rows'],'coordinate_count':v['coordinate_count']} for uid,v in records.items()},
        'scope_notice':'EXPLICIT_UNVALIDATED_DISPOSITIONS_ARE_NOT_RELIABLE_INTERVALS'},
        clinical_source_identities={uid:v['identity_sha256'] for uid,v in records.items()},
        clinical_gate_identity=gate['identity_sha256'])
    return n._sealed(body)


def collect_extension_clinical(run,observations,*,report_root,call,command,pool,research_report):
    from .evaluation_extension import clinical_eligible,clinical_name,research_gate,LIMIT
    root=Path(report_root);target=root/'evaluation-extension.json'
    research=strict_json_bytes(Path(research_report['report']).read_bytes())
    gate=research_gate(run,research['research'],research['source_identities'])
    hosts={uid:h for h,o in observations.items() for uid in o.get('clinical_extension_identities',{})}
    units=[u for u in run['units'] if clinical_eligible(run,u)]
    _need(len(units)==32 and all(u['unit_id'] in hosts for u in units),'REPORT_EXTENSION_CLINICAL_COVERAGE')
    expected={u['unit_id']:observations[hosts[u['unit_id']]]['clinical_extension_identities'][u['unit_id']] for u in units}
    if target.is_file():
        saved=strict_json_bytes(target.read_bytes())
        _need(saved['clinical_source_identities']==expected and saved['clinical_gate_identity']==gate['identity_sha256']
            and saved['source_identities']==research['source_identities']
            and n._sealed({k:v for k,v in saved.items() if k!='identity_sha256'})==saved,
            'REPORT_EXTENSION_CLINICAL_DRIFT')
    else:
        def fetch(u):
            uid=u['unit_id'];name=clinical_name(u);h=hosts[uid]
            pin=call(h,'pin',member=name,report_of=uid)
            _need(0<pin['size_bytes']<=LIMIT,'REPORT_EXTENSION_SIZE')
            result=subprocess.run(command(h,'send',member=name,pin=pin,report_of=uid),capture_output=True,timeout=60,check=False)
            _need(result.returncode==0 and len(result.stdout)==pin['size_bytes']
                and hashlib.sha256(result.stdout).hexdigest()==pin['sha256'],'REPORT_EXTENSION_TRANSPORT')
            value=strict_json_bytes(result.stdout)
            _need(value['identity_sha256']==expected[uid],'REPORT_EXTENSION_CLINICAL_OBSERVATION_DRIFT')
            return uid,value
        jobs=[pool.submit(fetch,u) for u in units]
        saved=finish_extension_report(run,research,gate,dict(job.result() for job in jobs))
        write_extension_report(root,saved)
    intermediate=root/'research-extension.json'
    if intermediate.is_file():
        old=strict_json_bytes(intermediate.read_bytes())
        _need(old['source_identities']==saved['source_identities'],'REPORT_EXTENSION_INTERMEDIATE_DRIFT')
        intermediate.unlink()
    return {'status':saved['status'],'report':str(target),'identity_sha256':saved['identity_sha256'],
        'clinical_scopes':32,'research_status':saved['research']['status']}


def _closure_metric_role(metric,development,month):
    if metric != 'uno':return 'REPORT_TIME_METRIC'
    return ('MATCHED_WINDOW_AND_24_MONTH_REFERENCE' if development == month == 24 else
        'MATCHED_DEVELOPMENT_WINDOW' if development == month else '24_MONTH_REFERENCE')


def post_result_report(run,read):
    """Consume only declared numerical summaries; historical rows stay distinct."""
    from .f4 import post_result_repair_decision,_evaluation_check_producer
    from .f5_application import application_repair_decision
    _need(run.get('post_result_repair') == post_result_repair_decision(),'REPORT_REPAIR_DECISION_DRIFT')
    generations = same_batch_generations(run)
    application_prefix = application_repair_decision()['identity_sha256']
    primary,application,original,calibration,inference,coverage,lines,mi = {},{},{},{},{},{},{},None
    required_primary = {f'PRIMARY-H{h:02d}-O{o}' for h in (6,12,24,36) for o in range(1,7)}
    for unit in run['units']:
        uid,kind = unit['unit_id'],unit['kind']
        if kind not in {'PRIMARY','FULL0','EVALUATION'}: continue
        prefix = f'units/{uid}/'
        tail = prefix+('postprocess/' if kind in {'PRIMARY','FULL0'} else '')+'post-result-repair-20261008/'
        completion = read(tail+'result.json')
        _need(n._sealed({k:v for k,v in completion.items() if k != 'identity_sha256'}) == completion,
            'REPORT_REPAIR_COMPLETION_SEAL_DRIFT')
        _evaluation_check_producer(completion,generations)
        _need(completion['decision_sha256'] == run['post_result_repair']['identity_sha256']
            and completion['target_unit'] == uid and completion['status'] == 'COMPLETED'
            and completion['direct_consumer_completed'] is True,'REPORT_REPAIR_COMPONENT_INCOMPLETE')
        def child(name):
            value = read(name)
            raw = canonical_json_bytes(value)
            _need(_repair_report_child_pin(run,completion,name) ==
                {'sha256':hashlib.sha256(raw).hexdigest(),'size_bytes':len(raw)}
                and n._sealed({k:v for k,v in value.items() if k != 'identity_sha256'}) == value,
                'REPORT_REPAIR_CHILD_DRIFT')
            return value
        calibration[uid] = child(tail+'calibration/result.json')
        inference[uid] = child(prefix+'post-result-repair-20261008/auc-exp1/result.json')
        if kind == 'PRIMARY':
            primary[uid] = child(prefix+'post-result-repair-20261008/a04/result.json')
            if unit['horizon'] == 6:
                coverage[unit['outer_fold']] = child(prefix+'post-result-repair-20261008/auc-validation/result.json')
        elif kind == 'FULL0':
            original[uid] = child(prefix+'application-repair/'+application_prefix+'/result.json')
            application[uid] = child(prefix+'application-repair/'+application_prefix+'/full-a04/result.json')
            if unit['horizon'] == 36: mi = child(prefix+'post-result-repair-20261008/mi-diagnostic.json')
        else:
            lines[unit['horizon']] = child(prefix+'post-result-repair-20261008/a04-summary.json')
    _need(set(primary) == required_primary and len(original) == len(application) == 4
        and len(calibration) == len(inference) == 32 and set(coverage) == set(range(1,7))
        and set(lines) == {6,12,24,36} and mi is not None,'REPORT_REPAIR_COVERAGE_INCOMPLETE')
    rows = []
    for uid,result in original.items():
        _need(result['coordinate_count'] == len(result['comparisons']) == 24
            and result['new_model_fits'] == 0,'REPORT_ORIGINAL_REGRESSION_COORDINATES_INVALID')
        for item in result['comparisons']:
            rows.append({'unit_id':uid,**item})
    _need(len(rows) == 96 and sum(r['original_status']=='FAIL' for r in rows) == 10
        and len({(r['unit_id'],r['center'],r['report_month']) for r in rows}) == 96,
        'REPORT_ORIGINAL_REGRESSION_DENOMINATOR_DRIFT')
    for uid,result in primary.items():
        _evaluation_check_producer(result,generations)
        _need(result['target_unit'] == uid and result['status'] == 'COMPLETED'
            and result['selection_effect'] == 'NONE','REPORT_A04_CURRENT_SOURCE_DRIFT')
    for ordinal,result in coverage.items():
        _need(result['scenario_ordinal'] == ordinal and result['dataset_ids_preserved'] == 2000
            and result['P_per_dataset'] == 1999 and result['status'] == 'COMPLETED',
            'REPORT_AUC_COVERAGE_INCOMPLETE')
    def summary(record):
        return {k:v for k,v in record.items() if k not in {'formal_references','members','sources','shared_members'}}
    return n._sealed({'kind':'PADML_POST_RESULT_REPAIR_NUMERICAL_REPORT_20261008_V1',
        'decision_sha256':run['post_result_repair']['identity_sha256'],'run_identity':run['identity'],
        'status':'COMPUTED_NOT_AUTOMATICALLY_ACCEPTED','original_application_rows':rows,
        'original_application':{'coordinates':96,'original_failures':10,
            'passed':sum(r['status']=='PASS' for r in rows),
            'failed_original_coordinates_closed':sum(r['original_status']=='FAIL' and r['status']=='PASS'
                and bool(r['cause']) for r in rows),
            'original_successes_without_regression':sum(r['original_status']=='PASS' and r['status']=='PASS' for r in rows)},
        'complete_a04_application':{u:summary(v) for u,v in application.items()},
        'complete_a04_lines':{str(h):summary(v) for h,v in lines.items()},
        'primary_scope_count':24,'calibration':{u:summary(v) for u,v in calibration.items()},
        'auc_perturbation':{u:summary(v) for u,v in inference.items()},
        'auc_validation':{str(i):summary(v) for i,v in coverage.items()},
        'clinical_interval_reliability':'ONLY_EXPLICITLY_VALIDATED_SCOPE_MAY_BE_LABELLED_RELIABLE',
        'full0_h36_odd_even':mi,'formal_prediction_model_fits':0,'new_shap_solves':0,
        'diagnostic_fit_coordinates':sum(63+sum(c['qualified_fit_coordinate_count'] for c in v['p2c2t'].values())
            for v in primary.values()),
        'recorded_new_diagnostic_fits':sum(v['actual_new_this_invocation']['model_fits'] for v in primary.values()),
        'recorded_new_mice_chains':sum(v['actual_new_this_invocation']['mice_chain_starts'] for v in primary.values())
            +sum(v['new_mice_chains'] for v in original.values())+sum(v['new_mice_chains'] for v in application.values()),
        'counts_interpretation':'QUALIFIED_COORDINATES_AND_RECORDED_NEW_CALLS_ARE_DISTINCT_NOT_RETRY_LIFETIME_COUNTS',
        'application_admission':'REQUIRES_CAUSAL_96_AND_ALL_A04_REVIEW_DISPOSITIONS',
        'historical_results':'UNCHANGED_REFERENCED_SEPARATELY'})


def archived_review(run, archive_folder):
    """Validate the original acceptance and exact evidence with no controller files."""
    from .f4 import validate_post_result_archive_acceptance
    prefix = 'shared/final-review/' + run['identity'] + '/'
    read = lambda name: archived_bytes(prefix+name, run, index_path=archive_folder/'index.json')
    acceptance = validate_post_result_archive_acceptance(run, Path('repair-acceptance.json'), read=read)
    return acceptance, [prefix+'repair-acceptance.json', *[prefix+n for n in acceptance['evidence']]]


def collect(run, observations, *, archive_root, call, command):
    archive_root = Path(archive_root)
    archive_folder = archive_root / run['run_id']
    if run.get('archive_transfer') is not None:
        ownership=n._sealed({'generation':run['archive_transfer']['generation'],
            'run_identity':run['identity'],'hosts':{h:{k:sorted(o.get(k,[]))
                for k in ('completed_units','not_estimable_units')} for h,o in observations.items()}})
        _publish(archive_folder/'ownership.json',canonical_json_bytes(ownership),'ARCHIVE_OWNERSHIP_DRIFT')
    base = archive_folder / 'reports'
    if run.get('evaluation_decision') is not None:
        base = base / ('evaluation-'+run['evaluation_decision']['identity_sha256'][:12])
    if run.get('post_result_repair') is not None:
        base = base / ('repair-'+run['post_result_repair']['identity_sha256'][:12])
    if run.get('curve_rmse') is not None:
        base = base / ('curve-'+run['curve_rmse']['identity_sha256'][:12])
    if run.get('result_closure') is not None:
        base = base / ('closure-'+run['result_closure']['identity_sha256'][:12])
    if run.get('evaluation_extension') is not None:
        base = base / ('extension-'+run['evaluation_extension']['identity_sha256'][:12])
    if base.is_symlink() or not base.resolve().is_relative_to(archive_root.resolve()):
        raise ContractError("REPORT_DESTINATION_PATH_INVALID")
    base.mkdir(parents=True, exist_ok=True)
    archived = _archive_index(archive_folder / 'index.json', run)
    _need(set(archived["windows"]) == {"6", "12", "24", "36"}, "REPORT_ARCHIVE_INCOMPLETE")
    def read(name):
        return strict_json_bytes(archived_bytes(name, run, index_path=archive_folder / 'index.json'))
    units = {u["unit_id"]:u for u in run["units"]}
    receipts = {uid: read(f"units/{uid}/unit.json") for uid in units}
    _need(all(receipt.get("status") in {"COMPLETED", "NOT_ESTIMABLE"}
        and receipt.get("direct_consumer_completed") is True and receipt.get("unit_id") == uid
        and receipt.get("run_identity") in same_batch_generations(run)
        for uid, receipt in receipts.items()), "REPORT_TERMINAL_SOURCE_DRIFT")
    not_estimable = {uid for uid, receipt in receipts.items() if receipt["status"] == "NOT_ESTIMABLE"}
    _need(not_estimable == set().union(*(set(window.get("not_estimable_units", []))
        for window in archived["windows"].values())), "REPORT_TERMINAL_SOURCE_DRIFT")
    training = {uid for uid, u in units.items() if u["kind"] in {"PRIMARY", "FULL0"}} - not_estimable
    required = report_names(run, units, training, receipts=receipts)
    acceptance = None
    if run.get('post_result_repair') is not None:
        acceptance, review_members = archived_review(run, archive_folder)
        required += review_members
    for uid,unit in units.items():
        if uid in not_estimable or unit['kind'] not in {'PRIMARY','FULL0','EVALUATION'}:
            continue
        if run.get('evaluation_decision') is not None:
            prefix=f'units/{uid}/'+('postprocess/' if unit['kind'] in {'PRIMARY','FULL0'} else '')+'evaluation-amendment/'
            head=read(prefix+'result.json')
            required += [prefix+name for name in ('historical-dca.csv','historical-calibration.csv')
                if name in head['members']]
    _need(set(required) <= set(archived["members"]), "REPORT_COVERAGE_INCOMPLETE")
    unit_hosts = {uid: host for host, o in observations.items()
        for uid in (*o["completed_units"], *o.get("not_estimable_units", []))}
    _need(set(unit_hosts) == set(units), "REPORT_TERMINAL_HOST_MISSING")
    entries = {name: {**archived["members"][name]["pin"],
        "storage": os.path.relpath(archive_folder / archived['members'][name]['storage'],base),
        "member": archived["members"][name]["member"]} for name in required}
    locations, diagnostics, selections, applications = [], [], [], []
    for uid, unit in units.items():
        receipt = receipts[uid]
        record = entries[f"units/{uid}/unit.json"]
        locations.append({"unit":uid, "host":unit_hosts[uid], "run_root":run["run_root"],
            "receipt_sha256":record["sha256"], "artifacts":receipt["artifacts"],
            **({"status":receipt["status"], "estimability":receipt["estimability"]} if "estimability" in receipt else {})})
        if uid in training:
            diagnostics += read(f"units/{uid}/postprocess/result.json")["report_rows"]
            selections += read(f"units/EVALUATION-H{unit['horizon']:02d}/selection/{uid}/result.json")["report_rows"]
        if uid in training and unit["kind"] == "FULL0":
            applications.append(read(f"units/{uid}/application.json"))
    from .f4 import _f45_optimism_csv
    if diagnostics:
        _publish(base / "o-fit-all.csv", _f45_optimism_csv(diagnostics), "REPORT_AGGREGATE_DRIFT")
    if selections:
        _publish(base / "selection-all.csv", _f45_optimism_csv(selections), "REPORT_AGGREGATE_DRIFT")
    estimability = {uid: receipt["estimability"] for uid, receipt in receipts.items() if "estimability" in receipt}
    partial = set(estimability) - not_estimable
    upstream = {uid for uid in not_estimable if receipts[uid]["estimability"]["reason_code"] == "UPSTREAM_PRIMARY_NOT_ESTIMABLE"}
    outcomes = {"completed": sorted(set(units) - set(estimability)),
        "partially_not_estimable": sorted(partial), "not_estimable": sorted(not_estimable - upstream),
        "upstream_not_executable": sorted(upstream)}
    status = "NOT_ESTIMABLE" if not_estimable else "PARTIALLY_NOT_ESTIMABLE" if partial else "COMPLETED"
    body = {"kind":"PADML_FINAL_REPORT_INDEX_V1", "run_identity":run["identity"], "status":status,
        "scientific_units":len(outcomes["completed"]), "training_contexts":len(training),
        **({"terminal_units":len(units), "not_estimable_units":sorted(not_estimable)} if not_estimable else {}),
        **({"unit_estimability":estimability, "unit_outcomes":outcomes} if estimability else {}), "development_horizons":[6,12,24,36],
        "report_months":[6,12,24,36], "files":entries, "formal_artifact_locations":locations,
        "o_fit_estimable_rows":sum(r["status"] == "ESTIMABLE" for r in diagnostics),
        "application_self_checks":[{"source":a["source"],"status":a["status"],"patient_count":a["patient_count"],
                                    "full_A04_audit":False} for a in applications]}
    if acceptance is not None:
        body['review_acceptance'] = {'identity_sha256':acceptance['identity_sha256'],
            'member':'shared/final-review/'+run['identity']+'/repair-acceptance.json',
            'status':'ACCEPTED_WITH_EXPLICIT_STATISTICAL_LIMITATIONS',
            'original_alerts':'RETAINED_UNCHANGED_SEPARATE_CAUSAL_REVIEW',
            'clinical_validity':'NOT_ESTABLISHED_BY_ENGINEERING_OR_A04_COMPLETION'}
    if run.get('evaluation_decision') is not None and run.get('result_closure') is None:
        from .f4 import evaluation_cross_time_report
        previous_index = os.environ.get('PADML_ARCHIVE_INDEX')
        os.environ['PADML_ARCHIVE_INDEX'] = str(archive_folder/'index.json')
        try:
            crossing = evaluation_cross_time_report(run,receipts)
        finally:
            if previous_index is None: os.environ.pop('PADML_ARCHIVE_INDEX',None)
            else: os.environ['PADML_ARCHIVE_INDEX'] = previous_index
        _publish(base/'cross-time-diagnostics.json',canonical_json_bytes(crossing),'REPORT_CROSS_TIME_DRIFT')
        body.update(evaluation_decision=run['evaluation_decision'],
            evaluation_role='POST_RESULT_EVALUATION_AMENDMENT_WITH_ORIGINAL_TRAINING_AND_PREDICTIONS',
            new_prediction_model_fits=0,new_mice_chains=0,new_shap_solves=0,
            inference_scope='CONDITIONAL_FIXED_PREDICTIONS_NOT_FULL_DEVELOPMENT',
            crossing_diagnostics='cross-time-diagnostics.json')
    if run.get('post_result_repair') is not None:
        repaired = post_result_report(run,read)
        if run.get('result_closure') is None:
            _publish(base/'repair-results.json',canonical_json_bytes(repaired),'REPORT_REPAIR_DRIFT')
        _publish(base/'original-application-96.csv',_f45_optimism_csv(repaired['original_application_rows']),
            'REPORT_APPLICATION_REGRESSION_DRIFT')
        body.update(post_result_repair=run['post_result_repair'],repair_results='repair-results.json',
            original_application_regression='original-application-96.csv',
            formal_prediction_model_fits_in_repair=0,
            diagnostic_fit_coordinates=repaired['diagnostic_fit_coordinates'],
            recorded_new_diagnostic_fits=repaired['recorded_new_diagnostic_fits'],
            recorded_new_mice_chains=repaired['recorded_new_mice_chains'])
        if run.get('result_closure') is not None:
            from .result_closure import eligible as closure_eligible,relative_result as closure_name,effective_report
            # Only archived compact numbers are reduced here. Neither original
            # matrices nor any controller-local report is an offline dependency.
            records={u['unit_id']:read(closure_name(u)) for u in run['units'] if closure_eligible(run,u)}
            heads=[name for u in run['units'] if u['kind'] in {'PRIMARY','FULL0','EVALUATION'}
                for name in _repair_report_names(u)]
            effective=effective_report(run,records,repaired,repair_reference={
                'direct_consumer_sources':{name:archived['members'][name]['pin'] for name in heads},
                'status':'HISTORICAL_UNCHANGED_CURRENT_DEFINITIONS_SEPARATE'})
            reviewed=read('shared/final-review/'+run['identity']+'/'+
                acceptance['result_closure_evidence']['current_report'])
            _need(reviewed['identity_sha256'] == effective['identity_sha256'],
                'REPORT_REVIEWED_RESULT_DRIFT')
            write_effective_report(base,effective)
            body.update(result_closure=run['result_closure'],current_evaluation='current-evaluation.json',
                a04_current_metrics='a04-current-metrics.csv',crossing_diagnostics='cross-time-diagnostics.json',
                legacy_o_fit_and_selection_tables='HISTORICAL_ORIGINAL_DEFINITIONS',
                repair_results='current-evaluation.json')
            if run.get('evaluation_extension') is not None:
                from .evaluation_extension import eligible as extension_eligible,relative_result as extension_name
                heads = {u['unit_id']:read(extension_name(u)) for u in run['units'] if extension_eligible(run,u)}
                children = {uid:{name:read(name) for name in head['sources']
                    if name.startswith(extension_name(units[uid]).rsplit('/',1)[0]+'/') or name ==
                        head['components'].get('h36_mi_reference',{}).get('source')}
                    for uid,head in heads.items()}
                extension = extension_report(run,heads,children,effective)
                from .evaluation_extension import clinical_eligible,clinical_name,GATE
                extension=finish_extension_report(run,extension,read(GATE),
                    {u['unit_id']:read(clinical_name(u)) for u in run['units'] if clinical_eligible(run,u)})
                reviewed = read('shared/final-review/'+run['identity']+'/'+
                    acceptance['evaluation_extension_evidence']['current_report'])
                _need(reviewed['identity_sha256'] == extension['identity_sha256'], 'REPORT_EXTENSION_REVIEWED_DRIFT')
                write_extension_report(base,extension)
                body.update(evaluation_extension=run['evaluation_extension'],
                    extension_results='evaluation-extension.json',mi_panel='four-line-mi36.csv',
                    completion_domains=extension['completion_domains'])
        # The old zeros refer to the historical evaluation-only appendage.
        # They cannot describe the newly authorized diagnostic experiments.
        body.pop('new_prediction_model_fits',None)
        body.pop('new_mice_chains',None)
    curve_links = []
    if run.get('curve_rmse') is not None:
        from .curve_rmse import eligible,relative_result,write_report
        curves = {u['unit_id']:read(relative_result(u)) for u in run['units'] if eligible(run,u)}
        write_report(run,curves,base)
        body.update(curve_rmse=run['curve_rmse'],curve_results='curve-rmse-results.json')
        curve_links = ['curve-rmse-summary.csv','curve-rmse-monthly.csv']
    text = ["# Nested LOCO results", "", "Run: " + run["run_id"], "",
        f"{len(units)} terminal units: {len(outcomes['completed'])} complete, {len(partial)} partial, {len(not_estimable)-len(upstream)} NOT_ESTIMABLE, {len(upstream)} upstream-dependent; {len(training)} completed training contexts.",
        "Unit completion does not assert that every required AAR branch is estimable; retained unit estimability and six-fold coverage are authoritative.",
        "FULL0 is a full-data development model. Application checks are engineering batch/single checks, not full A04 validation.",
        "NOT_ESTIMABLE values are retained; process completion does not imply every metric is estimable.", "",
        " · ".join((["[All O_fit rows](o-fit-all.csv)"] if diagnostics else [])
            + (["[All selection intervals](selection-all.csv)"] if selections else [])), ""]
    if run.get('post_result_repair') is not None:
        text += ['The original application self-checks above are historical evidence. The original96 regression, full A04, numerical repairs and interval reliability are separate in [Repair results]('+body['repair_results']+').',
            '[Original96 patient-coordinate regression](original-application-96.csv)',
            'A04 execution completion does not establish deployment admission or clinical validity.','']
    if curve_links:
        text += ['KM versus mean predicted curves: LOCO validation and FULL0 apparent results are separate.',
            ' · '.join(f'[{name}]({name})' for name in curve_links),'']
    current_links = ['current-evaluation.json','a04-current-metrics.csv','cross-time-diagnostics.json'] if run.get('result_closure') else []
    if current_links:
        text += ['Current evaluation definitions and completed reliability dispositions:',
            ' · '.join(f'[{name}]({name})' for name in current_links),'']
    if acceptance is not None:
        review_name = body['review_acceptance']['member']
        text += ['Final causal review and delivery acceptance are separate from the unchanged numerical alerts.',
            '[Validated acceptance and exact evidence]('+entries[review_name]['storage']+')',
            'Reviewed warnings and unreliable or non-estimable intervals remain limitations; this is not clinical validation.','']
    for uid, evidence in sorted(estimability.items()):
        text.append(f"- {uid}: {receipts[uid]['status']}; estimability is retained in its unit receipt.")
    for name in sorted(entries):
        text.append(f"- [{name}]({entries[name]['storage']})")
    _publish(base / "report.md", ("\n".join(text)+"\n").encode(), "REPORT_INDEX_DRIFT")
    links = "".join(f'<li><a href="{html.escape(entries[name]["storage"])}">{html.escape(name)}</a></li>' for name in sorted(entries))
    links += ''.join(f'<li><a href="{html.escape(name)}">{html.escape(name)}</a></li>' for name in curve_links+current_links)
    page = '<!doctype html><meta charset="utf-8"><title>Nested LOCO reports</title><h1>Nested LOCO reports</h1><p>Numeric estimability is reported separately from completion. FULL0 is a development model.</p><ul>'+links+'</ul>'
    _publish(base / "index.html", page.encode(), "REPORT_INDEX_DRIFT")
    _publish(base / "index.json", canonical_json_bytes(n._sealed(body)), "REPORT_INDEX_DRIFT")
    return {"status":status, "scientific_units":len(outcomes["completed"]), "training_diagnostics":len(training),
            "terminal_units":len(units), "not_estimable_units":sorted(not_estimable),
            **({"unit_outcomes":outcomes} if estimability else {}),
            "report_index":str(base / "index.json")}


def offline_archive_acceptance(run, archive_root):
    """Run in a fresh process: every network/subprocess attempt is forbidden."""
    from .bundle import sha256_file
    cfg=validate_archive_transfer(run);root=Path(archive_root);folder=root/run['run_id']
    _need(str(root)==cfg['project_root'],'ARCHIVE_OFFLINE_ROOT_DRIFT')
    _need(strict_json_bytes((folder/'run.json').read_bytes())==run,'ARCHIVE_OFFLINE_RUN_DRIFT')
    os.environ['PADML_ARCHIVE_INDEX']=str(folder/'index.json')
    os.environ['PADML_F45_RUN_PATH']=str(folder/'run.json')
    index=_archive_index(folder/'index.json',run)
    _need(set(index['windows'])=={'6','12','24','36'},'ARCHIVE_OFFLINE_WINDOWS_INCOMPLETE')
    windows={}
    for h,window in index['windows'].items():
        ack=strict_json_bytes((folder/'windows'/f'H{int(h):02d}-oss-confirmed.json').read_bytes())
        _need(n._sealed({k:v for k,v in ack.items() if k!='identity_sha256'})==ack
            and ack['status']=='ALL_HOSTS_CONFIRMED' and ack['generation']==cfg['generation']
            and ack['window_identity']==window['identity_sha256']
            and ack['hosts']==sorted(run['hosts']),'ARCHIVE_OFFLINE_ACK_INVALID')
        windows[h]=window['identity_sha256']
    own=strict_json_bytes((folder/'ownership.json').read_bytes())
    _need(n._sealed({k:v for k,v in own.items() if k!='identity_sha256'})==own
        and own['generation']==cfg['generation'] and own['run_identity']==run['identity'],
        'ARCHIVE_OWNERSHIP_DRIFT')
    physical={r['storage']:r['physical'] for r in index['members'].values()}
    # Streaming transfers already established SHA. This offline pass resolves
    # every location and declared packed member; the real report reads its data.
    grouped={}
    for row in index['members'].values(): grouped.setdefault(row['storage'],[]).append(row)
    for rows in grouped.values():
        path,_=_archive_physical_location(rows[0],folder/'index.json')
        packed=[row for row in rows if row['member'] is not None]
        if packed:
            with zipfile.ZipFile(path) as z:
                for row in packed:
                    _need(z.getinfo(row['member']).file_size==row['pin']['size_bytes'],
                        'ARCHIVE_OFFLINE_MEMBER_DRIFT')
    expected={}
    for path in sorted((folder/'transfers').glob('*.json')):
        binding=strict_json_bytes(path.read_bytes())['binding'];key=binding['object_key']
        _need(key.startswith(cfg['relay_prefix']) and
            physical.get(key[len(cfg['relay_prefix']):])==binding['pin'],'ARCHIVE_OFFLINE_RELAY_DRIFT')
        expected[key]=binding['pin']
    _need(bool(expected),'ARCHIVE_OFFLINE_RELAY_EMPTY')
    # The hook is deliberately process-long: the acceptance caller exits after
    # publication, so neither remote fallbacks nor OSS can silently satisfy reads.
    def deny_remote(event,args):
        if event in {'socket.connect','socket.getaddrinfo','subprocess.Popen','os.system','os.posix_spawn'}:
            raise ContractError('ARCHIVE_OFFLINE_REMOTE_ACCESS_ATTEMPT')
    sys.addaudithook(deny_remote)
    os.environ['PADML_ARCHIVE_INDEX']=str(folder/'index.json')
    def forbidden(*args,**kwargs):raise ContractError('ARCHIVE_OFFLINE_REMOTE_ACCESS_ATTEMPT')
    result=collect(run,own['hosts'],archive_root=root,call=forbidden,command=forbidden)
    report=Path(result['report_index'])
    receipt=n._sealed({'kind':'PADML_OSS_OFFLINE_CONSUMPTION_V1','status':'OFFLINE_CONSUMED',
        'generation':cfg['generation'],'relay_prefix':cfg['relay_prefix'],
        'run_identity':run['identity'],'window_identities':windows,
        'object_pins_sha256':n._sha(expected),'archive_index_sha256':sha256_file(folder/'index.json'),
        'report':{'path':str(report.relative_to(folder)),'sha256':sha256_file(report)},
        'members_resolved':len(index['members']),'physical_objects':len(physical),
        'network_and_subprocesses':'BLOCKED_DURING_REAL_CONSUMPTION'})
    _publish(folder/'offline-consumption.json',canonical_json_bytes(receipt),'ARCHIVE_OFFLINE_RECEIPT_DRIFT')
    return receipt


def finish_oss_relay(run, archive_root):
    """The controller deletes only the relay proven consumable by the offline run."""
    from . import oss
    from .bundle import sha256_file
    cfg=validate_archive_transfer(run);root=Path(archive_root);folder=root/run['run_id']
    _need(str(root)==cfg['project_root'] and _archive_volume(root)==cfg['volume'],'ARCHIVE_VOLUME_CHANGED')
    receipt=strict_json_bytes((folder/'offline-consumption.json').read_bytes())
    _need(receipt['run_identity']==run['identity'] and receipt['generation']==cfg['generation']
        and receipt['archive_index_sha256']==sha256_file(folder/'index.json')
        and receipt['report']['sha256']==sha256_file(folder/receipt['report']['path']),
        'ARCHIVE_OFFLINE_ACCEPTANCE_DRIFT')
    expected={}
    for path in sorted((folder/'transfers').glob('*.json')):
        binding=strict_json_bytes(path.read_bytes())['binding']
        expected[binding['object_key']]=binding['pin']
    done=folder/'relay-cleared.json'
    if done.exists():
        saved=strict_json_bytes(done.read_bytes())
        _need(n._sealed({k:v for k,v in saved.items() if k!='identity_sha256'})==saved
            and saved['offline_identity']==receipt['identity_sha256'] and saved['generation']==cfg['generation'],
            'OSS_RELAY_CLEARANCE_DRIFT')
        return saved
    result=oss.clear_relay(cfg['relay_prefix'],expected=expected,offline_receipt=receipt)
    _publish(done,canonical_json_bytes(result),'OSS_RELAY_CLEARANCE_DRIFT')
    return result


def preserve_oss_environment(run_path, *, code_root, remote_run_path, environment_identity):
    """Explicit post-relay phase using the same dispatcher lock and SSH adapter."""
    from . import oss, runtime_bundle
    from .run import load_f45_run, _f45_remote_command
    from .bundle import validate_sha256, sha256_file
    run_path=Path(run_path);run=load_f45_run(run_path);cfg=validate_archive_transfer(run)
    validate_sha256(environment_identity,'environment.identity')
    external=Path(cfg['project_root'])/run['run_id']
    authority=strict_json_bytes((external/'relay-cleared.json').read_bytes())
    _need(n._sealed({k:v for k,v in authority.items() if k!='identity_sha256'})==authority
        and authority['status']=='RELAY_CLEARED' and authority['generation']==cfg['generation']
        and authority['prefix']==cfg['relay_prefix'],'ENVIRONMENT_RESULT_RELAY_NOT_CLEARED')
    prefix='padml-environments/'+environment_identity+'/'
    folder=run_path.parent/'environment-archive'/environment_identity
    folder.mkdir(parents=True,exist_ok=True)
    def command(host,operation,**extra):
        return _f45_remote_command(run,host,code_root,{'run':str(remote_run_path),
            'identity':run['identity'],'operation':operation,**extra})
    def invoke(host,action,**body):
        number=body.pop('layer',None)
        request_id=n._sha([run['identity'],environment_identity,host,action,number])
        request_path=folder/(request_id+'.request.json')
        if request_path.exists() and strict_json_bytes(request_path.read_bytes())['status']=='UNKNOWN':
            probe=subprocess.run(command(host,'archive_inventory',horizon=6,units=[],selections=[],
                status_only=True,sender_request={'request_id':request_id,'horizon':6}),
                capture_output=True,timeout=60)
            _need(probe.returncode==0,'ENVIRONMENT_REQUEST_STATUS_UNKNOWN')
            state=strict_json_bytes(probe.stdout)
            _need(state.get('status')=='IDLE' and state.get('request_id')==request_id,
                'ENVIRONMENT_REQUEST_STILL_ACTIVE')
        envelope=canonical_json_bytes({'members':[],'pins':{},'tokens':{'relay_cleanup':authority,**body}})
        _need(len(envelope)<=16*1024**2,'ENVIRONMENT_REQUEST_TOO_LARGE')
        # UNKNOWN is durable before launch, including a lost reply or controller
        # interruption. Recovery probes this exact adapter before re-entering.
        _publish(request_path,canonical_json_bytes({'status':'UNKNOWN','host':host,'action':action,
            'layer':number,'request_id':request_id}),'ENVIRONMENT_REQUEST_DRIFT',replace=True)
        response=subprocess.run(command(host,'archive_environment',action=action,layer=number,
            environment_identity=environment_identity,archive_request_id=request_id,
            envelope_pin={'sha256':hashlib.sha256(envelope).hexdigest(),'size_bytes':len(envelope)}),
            input=envelope,capture_output=True,timeout=1800)
        _need(response.returncode==0,'ENVIRONMENT_REMOTE_ACTION_FAILED:'+host+':'+action)
        value=strict_json_bytes(response.stdout)
        _publish(request_path,canonical_json_bytes({'status':'RETURNED','host':host,'action':action,
            'layer':number,'request_id':request_id}),'ENVIRONMENT_REQUEST_DRIFT',replace=True)
        return value
    def publish_object(path,key):
        receipt=folder/(n._sha(key)+'.object.json')
        pin={'sha256':sha256_file(path),'size_bytes':path.stat().st_size}
        if receipt.exists():
            saved=strict_json_bytes(receipt.read_bytes())
            _need(saved['object_key']==key and all(saved[k]==v for k,v in pin.items()),
                'ENVIRONMENT_OBJECT_DRIFT')
            head=oss.head(key)
            _need(all(head[k]==v for k,v in pin.items()) and head['server_side_encryption']=='AES256',
                'ENVIRONMENT_OBJECT_DRIFT')
        else:
            saved=oss.put(path,key)
            _publish(receipt,canonical_json_bytes(saved),'ENVIRONMENT_OBJECT_DRIFT')
        return {**pin,'object_key':key}
    with (Path(cfg['rebuild_record']).parent/'.dispatch.lock').open('a+') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        _need(_archive_volume(Path(cfg['project_root']))==cfg['volume'],'ARCHIVE_VOLUME_CHANGED')
        if (folder/'completed.json').exists():
            done=strict_json_bytes((folder/'completed.json').read_bytes())
            _need(n._sealed({k:v for k,v in done.items() if k!='identity_sha256'})==done
                and done['environment_identity']==environment_identity
                and done['relay_cleanup_identity']==authority['identity_sha256'],
                'ENVIRONMENT_COMPLETION_DRIFT')
            # Lost final object receipt only republishes that small record.
            publish_object(folder/'completed.json',prefix+'completed.json')
            return done
        snapshots={};snapshot=None;snapshot_path=folder/'snapshot.json'
        # Native snapshot reuse is per-host; one canonical metadata entity is
        # retained locally. Host-specific qualifications never enter its identity.
        for host in sorted(run['hosts']):
            result=invoke(host,'snapshot');candidate=result['snapshot']
            runtime_bundle.environment_layers(candidate)
            if snapshot is None:
                snapshot=candidate
                _publish(snapshot_path,canonical_json_bytes(snapshot),'ENVIRONMENT_HOST_CONTENT_DRIFT')
            _need(candidate['identity_sha256']==snapshot['identity_sha256'],
                'ENVIRONMENT_HOST_CONTENT_DRIFT:'+host)
            snapshots[host]=result['pin']
        owner='H0';_need(owner in snapshots,'ENVIRONMENT_H01_REQUIRED')
        obj=publish_object(snapshot_path,prefix+'snapshot-'+sha256_file(snapshot_path)+'.json')
        pins=[]
        for number in range(len(runtime_bundle.environment_layers(snapshot))):
            pin=invoke(owner,'layer',layer=number);key=prefix+'layers/'+pin['sha256']+'.tgz'
            upload_id=oss.begin_multipart(key,{k:pin[k] for k in ('sha256','size_bytes')},
                folder/f'layer-{number:04d}.upload.json')
            uploaded=invoke(owner,'upload',layer=number,
                tokens=oss.multipart_tokens(key,upload_id,pin['size_bytes']))
            _need(uploaded['status']=='UPLOADED' and uploaded['pin']==pin and uploaded['key']==key,
                'ENVIRONMENT_UPLOAD_RECEIPT_DRIFT')
            pins.append({**pin,'object_key':key})
        source=Path(cfg['controller_sources']['source.zip']['path'])
        source_object=publish_object(source,prefix+'restore-source-'+run['source_bundle_sha256']+'.zip')
        descriptor=n._sealed({'kind':'PADML_OSS_ENVIRONMENT_V1','environment_identity':environment_identity,
            'snapshot':obj,'layers':pins,'restore_source':source_object,'platform':'Ubuntu22.04-x86_64',
            'qualified_hosts':snapshots,'data_root':'/root/autodl-tmp/padml',
            'minimum_system_free_bytes':4*1024**3,'status':'UPLOADED_RESTORE_PENDING'})
        descriptor_path=folder/'environment.json'
        _publish(descriptor_path,canonical_json_bytes(descriptor),'ENVIRONMENT_DESCRIPTOR_DRIFT')
        descriptor_object=publish_object(descriptor_path,prefix+'environment.json')
        acceptance_path=folder/'restore-acceptance.json'
        if acceptance_path.exists():
            accepted=strict_json_bytes(acceptance_path.read_bytes())
            _need(n._sealed({k:v for k,v in accepted.items() if k!='identity_sha256'})==accepted,
                'ENVIRONMENT_RESTORE_ACCEPTANCE_DRIFT')
        else:
            bootstrap={'descriptor':descriptor_object,'capabilities':{entry['object_key']:
                oss.signed_get(entry['object_key'],ttl_seconds=3600) for entry in [descriptor_object,obj,*pins]}}
            accepted=invoke(owner,'bootstrap',source=source_object,
                source_capability=oss.signed_get(source_object['object_key'],ttl_seconds=3600),bootstrap=bootstrap)
        _need(accepted['status']=='ISOLATED_NATIVE_PASS' and
            accepted['snapshot_identity']==snapshot['identity_sha256'],'ENVIRONMENT_RESTORE_NOT_ACCEPTED')
        _publish(acceptance_path,canonical_json_bytes(accepted),'ENVIRONMENT_RESTORE_ACCEPTANCE_DRIFT')
        publish_object(acceptance_path,prefix+'restore-acceptance.json')
        retired=invoke(owner,'retire_test')
        _need(retired['status']=='ISOLATED_TEST_RETIRED','ENVIRONMENT_TEST_RETIREMENT_INCOMPLETE')
        done=n._sealed({'status':'OSS_ENVIRONMENT_RESTORED_AND_TEST_RETIRED',
            'environment_identity':environment_identity,'descriptor_identity':descriptor['identity_sha256'],
            'acceptance_identity':accepted['identity_sha256'],'relay_cleanup_identity':authority['identity_sha256']})
        _publish(folder/'completed.json',canonical_json_bytes(done),'ENVIRONMENT_COMPLETION_DRIFT')
        publish_object(folder/'completed.json',prefix+'completed.json')
        return done
