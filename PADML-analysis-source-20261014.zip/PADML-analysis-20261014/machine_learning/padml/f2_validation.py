from __future__ import annotations

import math
from decimal import Decimal, ROUND_HALF_UP
from fractions import Fraction
from pathlib import Path
from typing import Any, Mapping
from ._science_authority import selector_parent_names

from .bundle import (
    ContractError,
    canonical_json_bytes,
    execution_result_contract,
    read_safe_zip,
    science_projection_sha256,
    sha256_bytes,
    strict_json_bytes,
    unit_exact_key,
    validate_envelope,
    validate_sha256,
)


def _require(condition: bool, reason: str) -> None:
    if not condition:
        raise ContractError(reason)


def _contains_absolute_path(value: Any) -> bool:
    if isinstance(value, str):
        return Path(value).is_absolute()
    if isinstance(value, dict):
        return any(_contains_absolute_path(item) for item in value.values())
    return isinstance(value, list) and any(_contains_absolute_path(item) for item in value)


def _finite_number(value: Any) -> bool:
    return (
        isinstance(value, (int, float))
        and not isinstance(value, bool)
        and math.isfinite(value)
    )


def _validate_primary_metric_qc(value: Any) -> None:
    _require(
        isinstance(value, dict)
        and set(value) == {
            "censoring_model", "evaluation_count", "minimum_g",
            "minimum_effective_sample_size", "maximum_weight",
            "positive_weight_quantiles", "truncation_applied", "metric_estimable",
        }
        and value["censoring_model"] == "EVALUATION_CENTER_STRATIFIED_KM"
        and type(value["evaluation_count"]) is int
        and value["evaluation_count"] >= 30
        and _finite_number(value["minimum_g"])
        and 0.05 <= value["minimum_g"] <= 1.0
        and _finite_number(value["minimum_effective_sample_size"])
        and value["minimum_effective_sample_size"]
        >= max(30.0, 0.20 * value["evaluation_count"])
        and _finite_number(value["maximum_weight"])
        and value["maximum_weight"] >= 1.0
        and isinstance(value["positive_weight_quantiles"], list)
        and len(value["positive_weight_quantiles"]) == 5
        and all(_finite_number(item) and item >= 1.0 for item in value["positive_weight_quantiles"])
        and value["positive_weight_quantiles"] == sorted(value["positive_weight_quantiles"])
        and value["positive_weight_quantiles"][-1] == value["maximum_weight"]
        and value["truncation_applied"] is False
        and value["metric_estimable"] is True,
        "F2_PRIMARY_METRIC_QC_INVALID",
    )


def _validate_prediction_scientific_variation(
    predictions: list[dict[str, Any]],
) -> None:
    """Independent probability-domain check, including valid constant curves."""

    _require(
        bool(predictions) and all(
            isinstance(row.get("survival"), list) and bool(row["survival"])
            and all(_finite_number(value) and 0 <= value <= 1 for value in row["survival"])
            and all(left + 1e-10 >= right for left, right in zip(row["survival"], row["survival"][1:]))
            for row in predictions),
        "F2_PREDICTION_MATRIX_INVALID",
    )


def _validate_model_row_universe(
    value: Mapping[str, Any], expected_model_input: Mapping[str, Any]
) -> dict[str, Any]:
    row_universe = value.get("row_universe")
    model_partitions = expected_model_input.get("model_partitions")
    outer_partitions = (
        [row for row in model_partitions if row.get("kind") == "OUTER"]
        if isinstance(model_partitions, list)
        else []
    )
    expected = (
        {
            "training_count": outer_partitions[0]["fit_count"],
            "heldout_count": outer_partitions[0]["evaluation_count"],
            "training_ids_sha256": outer_partitions[0]["fit_ids_sha256"],
            "heldout_ids_sha256": outer_partitions[0]["evaluation_ids_sha256"],
            "overlap_count": 0,
        }
        if len(outer_partitions) == 1
        else None
    )
    _require(
        isinstance(row_universe, dict)
        and row_universe == expected
        and row_universe["training_count"] > 0
        and row_universe["heldout_count"] > 0
        and sha256_bytes(canonical_json_bytes(row_universe))
        == value.get("row_universe_sha256"),
        "F2_MODEL_ROW_UNIVERSE_INVALID",
    )
    validate_sha256(row_universe["training_ids_sha256"], "f2.training_ids_sha256")
    validate_sha256(row_universe["heldout_ids_sha256"], "f2.heldout_ids_sha256")
    return row_universe


def _validate_registered_partition_execution(
    value: Mapping[str, Any],
    fold: int,
    family: str,
    expected_model_input: Mapping[str, Any],
    expected_selector_search: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    execution = value.get("registered_partition_execution")
    reuse = expected_selector_search is not None
    _require(not reuse or family == "ELASTIC_NET_COX", "F2_REUSED_SEARCH_EXECUTION_SCOPE_INVALID")
    _require(
        isinstance(execution, dict)
        and set(execution)
        == {
            "schema_version",
            "kind",
            "fold",
            "family",
            "registered_input_identity",
            "expected_partition_count",
            "executed_partition_count",
            "partitions",
            "identity",
        } | ({"reused_partition_count"} if reuse else set())
        and execution["schema_version"] == ("1.1.0" if reuse else "1.0.0")
        and execution["kind"] == "PADML_F2_REGISTERED_PARTITION_EXECUTION"
        and execution["fold"] == fold
        and execution["family"] == family
        and execution["registered_input_identity"]
        == value.get("lineage", {}).get("f1_registered_partition_identity")
        and type(execution["expected_partition_count"]) is int
        and type(execution["executed_partition_count"]) is int
        and (not reuse or type(execution["reused_partition_count"]) is int)
        and isinstance(execution["partitions"], list)
        and execution["expected_partition_count"]
        == execution["executed_partition_count"] + execution.get("reused_partition_count", 0)
        == len(execution["partitions"])
        and (not reuse or (execution["executed_partition_count"] == 1 and execution["reused_partition_count"] == 15))
        and execution["identity"]
        == sha256_bytes(
            canonical_json_bytes(
                {key: item for key, item in execution.items() if key != "identity"}
            )
        ),
        "F2_REGISTERED_EXECUTION_INVALID",
    )
    validate_sha256(
        execution["registered_input_identity"], "f2.registered_input_identity"
    )
    expected_count = 1 if family == "FPM_TVC_SET_A" else 16
    if family == "RSF":
        expected_count = 21
    if family in {"GBM_COX", "XGBOOST_COX"}:
        expected_count = 36
    if family == "COXTIME_SET_A":
        expected_count = 31
    _require(
        execution["expected_partition_count"] == expected_count,
        "F2_REGISTERED_EXECUTION_PARTITION_DENOMINATOR_INVALID",
    )
    model_partitions = expected_model_input.get("model_partitions")
    diagnostic_partitions = expected_model_input.get("diagnostic_partitions")
    _require(
        isinstance(model_partitions, list)
        and isinstance(diagnostic_partitions, list),
        "F2_REGISTERED_EXECUTION_MODEL_INPUT_INVALID",
    )
    by_kind = {
        kind: [row for row in model_partitions if row.get("kind") == kind]
        for kind in ("OUTER", "INNER", "STOP")
    }
    expected_partitions = {
        "COX_PH": [*by_kind["INNER"], *by_kind["OUTER"]],
        "ELASTIC_NET_COX": [*by_kind["INNER"], *by_kind["OUTER"]],
        "RSF": [*by_kind["INNER"], *diagnostic_partitions, *by_kind["OUTER"]],
        "GBM_COX": [
            *by_kind["INNER"],
            *by_kind["STOP"],
            *diagnostic_partitions,
            *by_kind["OUTER"],
        ],
        "XGBOOST_COX": [
            *by_kind["INNER"],
            *by_kind["STOP"],
            *diagnostic_partitions,
            *by_kind["OUTER"],
        ],
        "FPM_TVC_SET_A": by_kind["OUTER"],
        "COXTIME_SET_A": [
            *by_kind["INNER"],
            *by_kind["STOP"],
            *by_kind["OUTER"],
        ],
    }.get(family)
    _require(
        expected_partitions is not None
        and len(expected_partitions) == expected_count
        and len(
            {
                row.get("partition_id")
                for row in expected_partitions
                if isinstance(row, dict)
            }
        )
        == expected_count,
        "F2_REGISTERED_EXECUTION_MODEL_INPUT_INVALID",
    )
    expected_by_id = {row["partition_id"]: row for row in expected_partitions}
    rows = execution["partitions"]
    rank = {"INNER": 0, "STOP": 1, "CENTER_STRESS": 2, "OUTER": 3}
    _require(
        isinstance(rows, list)
        and len({row.get("partition_id") for row in rows if isinstance(row, dict)})
        == len(rows)
        and rows
        == sorted(
            rows,
            key=lambda row: (
                rank.get(row.get("kind"), 99),
                row.get("repeat", 0),
                row.get("inner_fold", 0),
                row.get("partition_id", "").encode("utf-8"),
            ),
        )
        and not _contains_absolute_path(rows)
        and "Patient_ID" not in str(rows),
        "F2_REGISTERED_EXECUTION_PARTITION_SET_INVALID",
    )
    common_keys = {
        "kind",
        "partition_id",
        "repeat",
        "inner_fold",
        "purpose",
        "input_record_sha256",
        "prediction_seal_count",
        "evaluation_count",
        "evaluation_response_sha256",
        "evaluation_ids_sha256",
        "prediction_seal_set_sha256",
        "metric_set_sha256",
    }
    for row in rows:
        expected_keys = set(common_keys)
        reused_inner = reuse and row.get("kind") == "INNER"
        if reused_inner:
            expected_keys -= {"prediction_seal_count", "evaluation_count", "prediction_seal_set_sha256", "metric_set_sha256"}
            expected_keys |= {"evidence_kind", "source_identity", "reused_path_count", "current_fit_count", "source_partition_sha256"}
        if row.get("kind") == "OUTER":
            expected_keys |= {
                "final_prediction_seal_sha256", "metric_prediction_seal_sha256",
                "ibs_0_24", "metric_qc",
            }
        if row.get("kind") == "STOP":
            expected_keys.add("lock_identity_sha256")
        if row.get("kind") == "INNER" and family in {
            "GBM_COX",
            "XGBOOST_COX",
            "COXTIME_SET_A",
        }:
            expected_keys |= {"lock_identity_sha256", "refit_scope"}
        _require(
            isinstance(row, dict)
            and set(row) == expected_keys
            and row.get("kind") in {"OUTER", "INNER", "STOP", "CENTER_STRESS"}
            and isinstance(row.get("partition_id"), str)
            and row["partition_id"]
            and (reused_inner or (
                isinstance(row.get("prediction_seal_count"), int)
                and row["prediction_seal_count"] > 0
                and isinstance(row.get("evaluation_count"), int)
                and row["evaluation_count"] > 0
            )),
            "F2_REGISTERED_EXECUTION_PARTITION_INVALID",
        )
        expected_partition = expected_by_id.get(row["partition_id"])
        _require(
            isinstance(expected_partition, dict)
            and row["kind"] == expected_partition.get("kind")
            and row["repeat"] == expected_partition.get("repeat")
            and row["inner_fold"] == expected_partition.get("inner_fold")
            and row["input_record_sha256"]
            == sha256_bytes(canonical_json_bytes(expected_partition)),
            "F2_REGISTERED_EXECUTION_INPUT_RECORD_MISMATCH",
        )
        if family == "COX_PH" and row["kind"] == "INNER":
            confirmations = value.get("search_trace", {}).get("FORMAL_CONFIRMATION")
            _require(isinstance(confirmations, list) and len(confirmations) == 1,
                     "F2_COX_PH_FORMAL_CONFIRMATION_MISSING")
            confirmation = confirmations[0]
            position = (row["repeat"] - 1) * 5 + row["inner_fold"] - 1
            _require(isinstance(confirmation, dict)
                     and len(confirmation.get("partition_ids", [])) == 15
                     and len(confirmation.get("prediction_seal_sha256s", [])) == 300
                     and len(confirmation.get("metric_values", [])) == 300
                     and confirmation["partition_ids"][position] == row["partition_id"]
                     and row["purpose"] == "FORMAL_CONFIRMATION"
                     and row["prediction_seal_count"] == row["evaluation_count"] == 20
                     and row["evaluation_response_sha256"] == expected_partition["evaluation_response_sha256"]
                     and row["evaluation_ids_sha256"] == expected_partition["evaluation_ids_sha256"]
                     and row["prediction_seal_set_sha256"] == sha256_bytes(canonical_json_bytes(
                         confirmation["prediction_seal_sha256s"][position*20:(position+1)*20]))
                     and row["metric_set_sha256"] == sha256_bytes(canonical_json_bytes(
                         confirmation["metric_values"][position*20:(position+1)*20])),
                     "F2_COX_PH_FORMAL_CONFIRMATION_EXECUTION_INVALID")
        digest_fields = [
            "input_record_sha256",
            "evaluation_response_sha256",
            "evaluation_ids_sha256",
            "prediction_seal_set_sha256",
            "metric_set_sha256",
        ]
        if reused_inner:
            trace = value["search_trace"]
            paths = [
                {"alpha": record["alpha"], "partition_losses": item}
                for record in trace["derivation_records"]
                for item in record["partition_losses"]
                if (item["repeat"], item["inner_fold"]) == (row["repeat"], row["inner_fold"])
            ]
            _require(
                row["purpose"] == "MODEL_SELECTION" and row["evidence_kind"] == "REUSED_SEARCH_PATHS"
                and row["source_identity"] == expected_selector_search["identity"]
                and type(row["current_fit_count"]) is int and row["current_fit_count"] == 0
                and type(row["reused_path_count"]) is int
                and row["reused_path_count"] == len(paths) * 20
                and len(paths) == trace["distinct_alpha_count"] > 0
                and row["source_partition_sha256"] == sha256_bytes(canonical_json_bytes(paths))
                and row["evaluation_response_sha256"] == expected_partition["evaluation_response_sha256"]
                and row["evaluation_ids_sha256"] == expected_partition["evaluation_ids_sha256"],
                "F2_REUSED_SEARCH_PARTITION_EVIDENCE_INVALID",
            )
            digest_fields = [*digest_fields[:3], "source_identity", "source_partition_sha256"]
        for field in digest_fields:
            validate_sha256(row.get(field), f"f2.registered.{field}")
        if row["kind"] == "STOP":
            _require(
                family in {"GBM_COX", "XGBOOST_COX", "COXTIME_SET_A"},
                "F2_REGISTERED_STOP_CONSUMER_INVALID",
            )
            validate_sha256(
                row.get("lock_identity_sha256"),
                "f2.registered.lock_identity_sha256",
            )
        if row["kind"] == "INNER" and family in {
            "GBM_COX",
            "XGBOOST_COX",
            "COXTIME_SET_A",
        }:
            _require(
                row.get("refit_scope") == "FULL_INNER_ANALYSIS",
                "F2_REGISTERED_STOP_REFIT_INVALID",
            )
            validate_sha256(
                row.get("lock_identity_sha256"),
                "f2.registered.lock_identity_sha256",
            )
    final = [row for row in rows if row.get("purpose") == "FINAL_EVALUATION"]
    _require(
        {row["partition_id"] for row in rows} == set(expected_by_id)
        and
        len(final) == 1
        and final[0].get("kind") == "OUTER"
        and final[0].get("final_prediction_seal_sha256")
        == value.get("prediction_sha256")
        and final[0].get("metric_prediction_seal_sha256")
        == value.get("monthly_oof_sha256")
        and final[0].get("evaluation_ids_sha256")
        == value.get("row_universe", {}).get("heldout_ids_sha256"),
        "F2_REGISTERED_FINAL_EVALUATION_INVALID",
    )
    _validate_primary_metric_qc(final[0]["metric_qc"])
    _require(
        final[0]["metric_qc"]["evaluation_count"]
        == value.get("row_universe", {}).get("heldout_count"),
        "F2_REGISTERED_FINAL_EVALUATION_INVALID",
    )
    _require(
        final[0]["prediction_seal_count"] == 20
        and final[0]["evaluation_count"] == 1
        and final[0]["metric_set_sha256"]
        == sha256_bytes(canonical_json_bytes([final[0]["ibs_0_24"]])),
        "F2_REGISTERED_FINAL_EVALUATION_INVALID",
    )
    if family in {"GBM_COX", "XGBOOST_COX", "COXTIME_SET_A"}:
        inner_locks = {
            (row["repeat"], row["inner_fold"]): row["lock_identity_sha256"]
            for row in rows
            if row["kind"] == "INNER"
        }
        stop_locks = {
            (row["repeat"], row["inner_fold"]): row["lock_identity_sha256"]
            for row in rows
            if row["kind"] == "STOP"
        }
        _require(
            inner_locks == stop_locks and len(inner_locks) == 15,
            "F2_REGISTERED_STOP_REFIT_INVALID",
        )
    return final[0]


def _validate_python_family_execution_budget(
    value: Mapping[str, Any],
    trace: Mapping[str, Any],
    family: str,
) -> None:
    expected = {
        "XGBOOST_COX": {
            "S1": (40, 5),
            "S2": (14, 25),
            "S3A": (3, 100),
            "S3B1": (2, 75),
            "S3B2": (1, 300),
            "SEED_AUDIT": (2, 75),
            "CENTER_STRESS": (2, 25),
        },
        "COXTIME_SET_A": {
            "S1": (12, 5),
            "S2": (4, 25),
            "S3A": (2, 100),
            "S3B1": (2, 75),
            "S3B2": (1, 300),
        },
    }[family]
    _require(
        isinstance(trace, Mapping)
        and set(trace) == set(expected)
        and all(
            isinstance(trace[phase], list)
            and len(trace[phase]) == count
            and all(
                isinstance(row, Mapping)
                and row.get("evaluation_units") == units
                and row.get("stage_id") == phase
                for row in trace[phase]
            )
            for phase, (count, units) in expected.items()
        ),
        f"F2_{family}_PHASE_BUDGET_INVALID",
    )
    rows = value["registered_partition_execution"]["partitions"]
    totals = {
        kind: {
            "seals": sum(
                row["prediction_seal_count"]
                for row in rows
                if row["kind"] == kind
            ),
            "evaluations": sum(
                row["evaluation_count"]
                for row in rows
                if row["kind"] == kind
            ),
        }
        for kind in {row["kind"] for row in rows}
    }
    expected_totals = (
        {
            "INNER": {"seals": 1450, "evaluations": 1450},
            "STOP": {"seals": 1450, "evaluations": 1450},
            "CENTER_STRESS": {"seals": 50, "evaluations": 50},
            "OUTER": {"seals": 20, "evaluations": 1},
        }
        if family == "XGBOOST_COX"
        else {
            "INNER": {"seals": 810, "evaluations": 810},
            "STOP": {"seals": 810, "evaluations": 810},
            "OUTER": {"seals": 20, "evaluations": 1},
        }
    )
    _require(
        totals == expected_totals,
        f"F2_{family}_REGISTERED_BUDGET_INVALID",
    )


def _validate_selector_evidence(
    selector: Any,
    contract: Mapping[str, Any],
    sensitivity_contract: Mapping[str, Any],
    checkpoint: Mapping[str, Any],
    predictors: Mapping[str, Any],
    expected_model_input: Mapping[str, Any],
    expected_primary_execution: Mapping[str, Any],
    expected_sensitivity_profiles: Mapping[str, Any],
) -> dict[str, Any]:
    expected_keys = {
        "schema_version",
        "common_alpha",
        "active_design_df_by_imputation",
        "median_active_design_df",
        "p90_active_design_df",
        "median_active_epv",
        "conservative_active_epv",
        "common_set_design_df",
        "common_set_epv",
        "diagnostics_selection_effect",
        "direction_diagnostic_flags",
        "eligible_parent_count",
        "forced_parent",
        "final_refit_lambda_by_imputation",
        "heldout_outcome_read_count",
        "jaccard_diagnostic",
        "jaccard_empty_set_vacuous",
        "lambda_upper_bound_by_imputation",
        "natural_frequency",
        "outer_training_event_count",
        "primary_frequency_threshold",
        "primary_selector_sha256",
        "primary_execution",
        "r_0_5se_by_imputation",
        "r_min_by_imputation",
        "recipe_count",
        "recipe_set",
        "recipe_set_sha256",
        "outer_recipe_sha256",
        "selected_design_sha256",
        "selected_parent_design",
        "selected_parent_count",
        "selected_parent_sha256",
        "selected_parents",
        "selected_ratio_by_imputation",
        "selector_contract_sha256",
        "sensitivity_frequency_thresholds",
        "sensitivity_evidence",
        "selector_execution_identity_sha256",
        "transform_registry_sha256",
    }
    _require(
        type(selector) is dict
        and set(selector) == expected_keys
        and selector["schema_version"] == "1.3.0"
        and selector["selector_contract_sha256"]
        == sha256_bytes(canonical_json_bytes(dict(contract)))
        and selector["transform_registry_sha256"]
        == predictors["transform_registry_sha256"]
        and selector["eligible_parent_count"]
        == checkpoint.get("eligible_parent_count")
        == len(selector_parent_names())
        and selector["forced_parent"] == checkpoint.get("forced_parent") == "AST_ALT"
        and selector["primary_frequency_threshold"] == 12
        and selector["sensitivity_frequency_thresholds"] == [14, 16]
        and selector["heldout_outcome_read_count"] == 0
        and selector["diagnostics_selection_effect"] == "NONE",
        "F2_SELECTOR_EVIDENCE_INVALID",
    )
    _require(
        selector["primary_execution"] == dict(expected_primary_execution),
        "F2_SELECTOR_PRIMARY_EXECUTION_BINDING_INVALID",
    )
    _require(_finite_number(selector["common_alpha"]) and 0.01 <= selector["common_alpha"] <= 1,
             "F2_SELECTOR_RATIO_INVALID")
    ratio_grid = [10 ** (-4 * index / 149) for index in range(150)]
    for field in ("selected_ratio_by_imputation", "r_min_by_imputation", "r_0_5se_by_imputation"):
        _require(
            isinstance(selector[field], list) and len(selector[field]) == 20
            and all(_finite_number(value) and value in ratio_grid for value in selector[field]),
            "F2_SELECTOR_RATIO_INVALID",
        )
    _require(
        all(minimum <= half <= one for minimum, half, one in zip(
            selector["r_min_by_imputation"], selector["r_0_5se_by_imputation"],
            selector["selected_ratio_by_imputation"], strict=True))
        and isinstance(selector["final_refit_lambda_by_imputation"], list)
        and len(selector["final_refit_lambda_by_imputation"]) == 20
        and isinstance(selector["lambda_upper_bound_by_imputation"], list)
        and len(selector["lambda_upper_bound_by_imputation"]) == 20
        and all(
            _finite_number(value) and value > 0
            for value in selector["final_refit_lambda_by_imputation"]
        ),
        "F2_SELECTOR_RATIO_INVALID",
    )
    frequencies = selector["natural_frequency"]
    direction = selector["direction_diagnostic_flags"]
    selected = selector["selected_parents"]
    _require(
        type(frequencies) is dict
        and set(frequencies) == set(selector_parent_names()) - {"AST_ALT"}
        and "AST_ALT" not in frequencies
        and sha256_bytes(
            canonical_json_bytes(
                sorted(
                    {"AST_ALT", *frequencies},
                    key=lambda value: value.encode("utf-8"),
                )
            )
        )
        == checkpoint.get("eligible_parent_set_sha256")
        and all(
            isinstance(parent, str)
            and parent
            and type(count) is int
            and 0 <= count <= 20
            for parent, count in frequencies.items()
        )
        and type(direction) is dict
        and set(direction) == set(frequencies)
        and all(value is None or type(value) is bool for value in direction.values())
        and isinstance(selected, list)
        and selected
        == sorted(
            {"AST_ALT", *(parent for parent, count in frequencies.items() if count >= 12)},
            key=lambda value: value.encode("utf-8"),
        )
        and selector["selected_parent_count"] == len(selected)
        and selector["selected_parent_sha256"]
        == sha256_bytes(canonical_json_bytes(selected)),
        "F2_SELECTOR_FREQUENCY_INVALID",
    )
    from .f2_kernel import (
        _outer_recipe_from_selector,
        _selector_evidence_execution_identity,
        _selected_design_record,
        _validate_transform_recipe_set,
    )

    recipe_set = _validate_transform_recipe_set(
        selector["recipe_set"],
        predictors,
        expected_count=16,
    )
    expected_recipe_set = _validate_transform_recipe_set(
        expected_model_input["selector_recipe_expectations"],
        predictors,
        expected_count=16,
    )
    _require(
        recipe_set == expected_recipe_set,
        "F2_SELECTOR_RECIPE_LOCAL_RECOMPUTATION_MISMATCH",
    )
    expected_partitions = sorted(
        (
            row
            for row in expected_model_input["model_partitions"]
            if row["kind"] == "INNER"
        ),
        key=lambda row: (row["repeat"], row["inner_fold"]),
    ) + [
        row
        for row in expected_model_input["model_partitions"]
        if row["kind"] == "OUTER"
    ]
    recipes = recipe_set["recipes"]
    _require(
        len(expected_partitions) == len(recipes) == 16
        and all(
            recipe["partition_id"] == partition["partition_id"]
            and recipe["analysis_view_sha256"]
            == partition["analysis_view_sha256"]
            and recipe["analysis_ids_sha256"]
            == partition["analysis_ids_sha256"]
            and recipe["fit_ids_sha256"] == partition["fit_ids_sha256"]
            and recipe["training_member_set_sha256"]
            == partition["fit_covariate_member_set_sha256"]
            for recipe, partition in zip(recipes, expected_partitions, strict=True)
        ),
        "F2_SELECTOR_RECIPE_MODEL_INPUT_MISMATCH",
    )
    outer_recipe = _outer_recipe_from_selector(selector, predictors)
    _require(
        outer_recipe["partition_id"] == expected_partitions[-1]["partition_id"]
        and outer_recipe["analysis_view_sha256"]
        == expected_partitions[-1]["analysis_view_sha256"]
        and outer_recipe["analysis_ids_sha256"]
        == expected_partitions[-1]["analysis_ids_sha256"]
        and outer_recipe["fit_ids_sha256"]
        == expected_partitions[-1]["fit_ids_sha256"],
        "F2_SELECTOR_OUTER_RECIPE_MODEL_INPUT_MISMATCH",
    )
    expected_design = _selected_design_record(
        selected,
        predictors,
        outer_recipe,
    )
    _require(
        selector["recipe_count"] == recipe_set["recipe_count"] == 16
        and selector["recipe_set_sha256"] == recipe_set["recipe_set_sha256"]
        and selector["outer_recipe_sha256"] == outer_recipe["recipe_sha256"]
        and selector["selected_parent_design"]
        == expected_design["ordered_selected_parent_map"]
        and selector["selected_design_sha256"]
        == sha256_bytes(canonical_json_bytes(expected_design)),
        "F2_SELECTOR_RECIPE_OR_DESIGN_IDENTITY_INVALID",
    )
    event_count = selector["outer_training_event_count"]
    design_df = selector["common_set_design_df"]
    epv = selector["common_set_epv"]
    active_dfs = selector["active_design_df_by_imputation"]
    _require(
        type(event_count) is int
        and event_count > 0
        and type(design_df) is int
        and design_df > 0
        and design_df == sum(row["design_df"] for row in expected_design["ordered_selected_parent_map"])
        and isinstance(active_dfs, list) and len(active_dfs) == 20
        and all(type(df) is int and df > 0 and event_count / df >= 15 for df in active_dfs)
        and selector["p90_active_design_df"] == sorted(active_dfs)[17]
        and selector["median_active_design_df"] == (sorted(active_dfs)[9] + sorted(active_dfs)[10]) / 2
        and selector["median_active_epv"] == event_count / selector["median_active_design_df"]
        and selector["conservative_active_epv"] == event_count / selector["p90_active_design_df"]
        and _finite_number(epv)
        and epv >= contract["epv_contract"]["minimum"]
        and abs(epv - event_count / design_df)
        <= 1e-12 + 1e-10 * max(1.0, abs(epv))
        and _finite_number(selector["jaccard_diagnostic"])
        and 0 <= selector["jaccard_diagnostic"] <= 1
        and type(selector["jaccard_empty_set_vacuous"]) is bool
        and selector["jaccard_empty_set_vacuous"] == (not any(frequencies.values())),
        "F2_SELECTOR_EPV_OR_DIAGNOSTIC_INVALID",
    )
    _validate_selector_sensitivity_evidence(
        selector,
        sensitivity_contract,
        predictors,
        event_count,
        expected_sensitivity_profiles,
        expected_model_input,
    )
    _require(
        selector["selector_execution_identity_sha256"]
        == _selector_evidence_execution_identity(selector),
        "F2_SELECTOR_EXECUTION_IDENTITY_INVALID",
    )
    return selector


def _validate_selector_sensitivity_evidence(
    selector: Mapping[str, Any],
    contract: Mapping[str, Any],
    predictors: Mapping[str, Any],
    event_count: int,
    expected_profiles: Mapping[str, Any],
    expected_model_input: Mapping[str, Any],
) -> None:
    from .f2_kernel import (
        _elastic_parent_design_columns,
        _outer_recipe_from_selector,
        _selector_sensitivity_method_execution_identity,
        _selector_sensitivity_method_science_identity,
        _selector_sensitivity_execution_identity,
        _selector_sensitivity_science_identity,
        _selector_sensitivity_seed,
        _selector_sensitivity_task_spec_record,
        _validate_selector_sensitivity_numerics,
    )

    core = {
        key: value
        for key, value in selector.items()
        if key
        not in {
            "primary_selector_sha256",
            "primary_execution",
            "sensitivity_evidence",
            "selector_execution_identity_sha256",
        }
    }
    evidence = selector.get("sensitivity_evidence")
    _require(
        selector.get("primary_selector_sha256")
        == sha256_bytes(canonical_json_bytes(core))
        and isinstance(evidence, dict)
        and set(evidence)
        == {
            "schema_version",
            "kind",
            "status",
            "method_order",
            "methods",
            "primary_writeback",
            "heldout_outcome_read_count",
            "identity_sha256",
            "execution_identity_sha256",
        }
        and evidence["schema_version"] == "1.0.0"
        and evidence["kind"] == "PADML_F2_SELECTOR_SENSITIVITY"
        and evidence["status"] == "PASS"
        and evidence["method_order"] == ["MRMRE", "BORUTA"]
        and evidence["primary_writeback"] == "FORBIDDEN"
        and evidence["heldout_outcome_read_count"] == 0
        and evidence["identity_sha256"]
        == _selector_sensitivity_science_identity(evidence)
        and evidence["execution_identity_sha256"]
        == _selector_sensitivity_execution_identity(evidence)
        and isinstance(evidence["methods"], dict)
        and set(evidence["methods"]) == {"MRMRE", "BORUTA"},
        "F2_SELECTOR_SENSITIVITY_EVIDENCE_INVALID",
    )
    forbidden = canonical_json_bytes(evidence).lower()
    _require(
        all(
            token not in forbidden
            for token in (
                b'"patient_id"',
                b'"predictions"',
                b'"heldout_metrics"',
                b'"raw_importance"',
                b'"knots"',
            )
        ),
        "F2_SELECTOR_SENSITIVITY_PRIVATE_FIELD_INVALID",
    )
    parent_df = _elastic_parent_design_columns(predictors)
    outer_partitions = [
        row
        for row in expected_model_input["model_partitions"]
        if row.get("kind") == "OUTER"
    ]
    _require(
        len(outer_partitions) == 1,
        "F2_SELECTOR_SENSITIVITY_OUTER_INVALID",
    )
    outer_partition = outer_partitions[0]
    outer_recipe = _outer_recipe_from_selector(selector, predictors)
    for method in ("MRMRE", "BORUTA"):
        method_value = evidence["methods"][method]
        expected_profile = expected_profiles[method]
        _require(
            isinstance(method_value, dict)
            and method_value.get("method") == method
            and method_value.get("admission_identity")
            == expected_profile["admission_identity"]
            and method_value.get("status")
            in {"PASS", "GLOBAL_DEFERRED", "DEFERRED_TYPED"},
            "F2_SELECTOR_SENSITIVITY_METHOD_INVALID",
        )
        if method_value["status"] != "PASS":
            _require(
                set(method_value)
                == {
                    "schema_version",
                    "kind",
                    "status",
                    "method",
                    "reason",
                    "task_count",
                    "admission_identity",
                    "execution",
                    "execution_identity_sha256",
                    "identity_sha256",
                }
                and method_value["task_count"] == 0
                and method_value["identity_sha256"] is None
                and method_value["execution_identity_sha256"]
                == _selector_sensitivity_method_execution_identity(method_value),
                "F2_SELECTOR_SENSITIVITY_DEFERRED_INVALID",
            )
            _require(
                (
                    method_value["status"] == "GLOBAL_DEFERRED"
                    and expected_profile["selection"] == "GLOBAL_DEFERRED"
                    and method_value["execution"] is None
                    and method_value["reason"]
                    == contract["failure_semantics"]["global_deferred_reason"]
                )
                or (
                    method_value["status"] == "DEFERRED_TYPED"
                    and expected_profile["selection"] != "GLOBAL_DEFERRED"
                    and method_value["execution"]
                    == expected_profile["execution"]
                    and method_value["reason"]
                    in set(
                        contract["failure_semantics"][
                            "typed_deferred_reason_allowlist"
                        ][method]
                    )
                ),
                "F2_SELECTOR_SENSITIVITY_DEFERRED_PROFILE_INVALID",
            )
            continue
        _require(
            set(method_value)
            == {
                "schema_version",
                "kind",
                "status",
                "method",
                "candidate_parent_count",
                "task_count",
                "event_count",
                "natural_frequency",
                "tentative_frequency",
                "threshold_sets",
                "threshold_set_diagnostics",
                "stability_summary",
                "private_records",
                "task_set_sha256",
                "admission_identity",
                "execution",
                "execution_identity_sha256",
                "identity_sha256",
            }
            and method_value["schema_version"] == "1.0.0"
            and method_value["kind"]
            == "PADML_F2_SELECTOR_SENSITIVITY_METHOD"
            and method_value["task_count"] == 20
            and method_value["event_count"] == event_count
            and method_value["identity_sha256"]
            == _selector_sensitivity_method_science_identity(method_value)
            and method_value["execution_identity_sha256"]
            == _selector_sensitivity_method_execution_identity(method_value)
            and method_value["execution"]["engine_threads"] == 1
            and type(method_value["execution"]["threads"]) is int
            and method_value["execution"]["threads"] >= 1
            and method_value["execution"]["pool_workers"]
            == method_value["execution"]["threads"],
            "F2_SELECTOR_SENSITIVITY_METHOD_INVALID",
        )
        _require(
            expected_profile["selection"] != "GLOBAL_DEFERRED"
            and method_value["execution"] == expected_profile["execution"],
            "F2_SELECTOR_SENSITIVITY_EXECUTION_BINDING_INVALID",
        )
        candidates = list(predictors["parents"])
        if method == "MRMRE":
            candidates = [
                parent for parent in candidates if parent != "Prior_LE_Surgery_cat"
            ]
        _require(
            method_value["candidate_parent_count"] == len(candidates)
            == len(set(selector_parent_names()) - (set(contract['mrmre']['excluded_parents']) if method == 'MRMRE' else set()))
            and isinstance(method_value["private_records"], list)
            and len(method_value["private_records"]) == 20,
            "F2_SELECTOR_SENSITIVITY_DENOMINATOR_INVALID",
        )
        selected_sets: list[list[str]] = []
        task_hashes: list[str] = []
        for imputation, record in enumerate(method_value["private_records"], start=1):
            _require(
                isinstance(record, dict)
                and record.get("imputation") == imputation
                and isinstance(record.get("task_spec"), Mapping),
                "F2_SELECTOR_SENSITIVITY_DENOMINATOR_INVALID",
            )
            if method == "MRMRE":
                _require(
                    set(record)
                    == {
                        "imputation",
                        "task_id",
                        "seed",
                        "task_spec",
                        "task_spec_sha256",
                        "task_echo",
                        "task_echo_sha256",
                        "ranking",
                        "selected_prefix",
                        "complete_design_df",
                        "epv",
                        "result_sha256",
                        "task_identity_sha256",
                    }
                    and isinstance(record["ranking"], list)
                    and len(record["ranking"]) == len(candidates)
                    and set(record["ranking"]) == set(candidates)
                    and len(set(record["ranking"])) == len(candidates),
                    "F2_MRMRE_RANK_DENOMINATOR_INVALID",
                )
                expected_selected = ["AST_ALT"]
                expected_df = parent_df["AST_ALT"]
                for parent in record["ranking"]:
                    if parent == "AST_ALT":
                        continue
                    proposed = expected_df + parent_df[parent]
                    if event_count / proposed < contract["shared_contract"]["epv_minimum"]:
                        break
                    expected_selected.append(parent)
                    expected_df = proposed
                _require(
                    record["selected_prefix"] == expected_selected
                    and record["complete_design_df"] == expected_df
                    and abs(record["epv"] - event_count / expected_df)
                    <= 1e-12 + 1e-10 * max(1.0, abs(record["epv"])),
                    "F2_MRMRE_EPV_PREFIX_INVALID",
                )
                selected_sets.append(expected_selected)
            else:
                _require(
                    set(record)
                    == {
                        "imputation",
                        "task_id",
                        "seed",
                        "task_spec",
                        "task_spec_sha256",
                        "task_echo",
                        "task_echo_sha256",
                        "decisions",
                        "algorithm_confirmed",
                        "selected_with_forced",
                        "complete_design_df",
                        "epv",
                        "epv_status",
                        "result_sha256",
                        "task_identity_sha256",
                    }
                    and isinstance(record["decisions"], dict)
                    and list(record["decisions"]) == sorted(candidates)
                    and set(record["decisions"].values())
                    <= {"Confirmed", "Tentative", "Rejected"},
                    "F2_BORUTA_DECISION_DENOMINATOR_INVALID",
                )
                confirmed = [
                    parent
                    for parent in candidates
                    if record["decisions"][parent] == "Confirmed"
                ]
                selected = list(dict.fromkeys(["AST_ALT", *confirmed]))
                expected_df = sum(parent_df[parent] for parent in selected)
                expected_epv = event_count / expected_df
                _require(
                    record["algorithm_confirmed"] == confirmed
                    and record["selected_with_forced"] == selected
                    and record["complete_design_df"] == expected_df
                    and abs(record["epv"] - expected_epv)
                    <= 1e-12 + 1e-10 * max(1.0, abs(record["epv"]))
                    and record["epv_status"]
                    == (
                        "ELIGIBLE"
                        if expected_epv >= contract["shared_contract"]["epv_minimum"]
                        else "EPV_INELIGIBLE"
                    ),
                    "F2_BORUTA_EPV_STATUS_INVALID",
                )
                selected_sets.append(selected)
            expected_seed = _selector_sensitivity_seed(
                {
                    "fold": expected_model_input["fold"],
                    "selector_sensitivity_contract": contract,
                },
                method,
                imputation,
            )
            expected_task_id = (
                f"{method}_F{expected_model_input['fold']}_M{imputation:02d}"
            )
            expected_task_spec = _selector_sensitivity_task_spec_record(
                fold=expected_model_input["fold"],
                method=method,
                imputation=imputation,
                seed=expected_seed,
                task_id=expected_task_id,
                seed_policy=contract["seed_policy"],
                candidate_parents=candidates,
                outer_partition_id=outer_partition["partition_id"],
                analysis_view_sha256=outer_partition[
                    "analysis_view_sha256"
                ],
                fit_ids_sha256=outer_partition["fit_ids_sha256"],
                fit_covariate_member_set_sha256=outer_partition[
                    "fit_covariate_member_set_sha256"
                ],
                fit_response_sha256=outer_partition[
                    "fit_response_sha256"
                ],
                fit_response_size_bytes=outer_partition[
                    "fit_response_size_bytes"
                ],
                covariate_member=outer_partition[
                    "fit_covariate_members"
                ][imputation - 1],
                predictor_catalog_sha256=predictors["sha256"],
                transform_registry_sha256=predictors[
                    "transform_registry_sha256"
                ],
                package_versions=(
                    {
                        "mRMRe": contract["mrmre"]["version"],
                        "Boruta": None,
                        "ranger": None,
                    }
                    if method == "MRMRE"
                    else {
                        "mRMRe": None,
                        "Boruta": contract["boruta"]["version"],
                        "ranger": contract["boruta"]["ranger_version"],
                    }
                ),
            )
            result_record = (
                {"ranking": record["ranking"]}
                if method == "MRMRE"
                else {"decisions": record["decisions"]}
            )
            expected_task_echo = {
                "task_spec_sha256": record["task_spec_sha256"],
                "method": method,
                "imputation": imputation,
                "seed": expected_seed,
                "candidate_parent_count": len(candidates),
                "package_versions": expected_task_spec["package_versions"],
                "thread_count": 1,
                "numerical_health": _validate_selector_sensitivity_numerics(
                    method, record.get("task_echo", {}).get("numerical_health"),
                    package_version=expected_task_spec["package_versions"]["mRMRe"]
                ),
            }
            for field in (
                "task_spec_sha256",
                "task_echo_sha256",
                "result_sha256",
                "task_identity_sha256",
            ):
                validate_sha256(record.get(field), f"f2.{method}.{field}")
            _require(
                record["task_id"] == expected_task_id
                and record["seed"] == expected_seed
                and record["task_spec"] == expected_task_spec
                and record["task_spec_sha256"]
                == sha256_bytes(canonical_json_bytes(expected_task_spec))
                and record["task_echo"] == expected_task_echo
                and record["task_echo_sha256"]
                == sha256_bytes(canonical_json_bytes(expected_task_echo))
                and record["result_sha256"]
                == sha256_bytes(canonical_json_bytes(result_record))
                and record["task_identity_sha256"]
                == sha256_bytes(
                    canonical_json_bytes(
                        {
                            "task_spec_sha256": record[
                                "task_spec_sha256"
                            ],
                            "task_echo_sha256": record[
                                "task_echo_sha256"
                            ],
                            "result_sha256": record["result_sha256"],
                        }
                    )
                ),
                "F2_SELECTOR_SENSITIVITY_TASK_IDENTITY_INVALID",
            )
            task_hashes.append(record["task_identity_sha256"])
        observed_members = [
            record["task_spec"]["covariate_member"]
            for record in method_value["private_records"]
        ]
        _require(
            observed_members == outer_partition["fit_covariate_members"]
            and sha256_bytes(canonical_json_bytes(observed_members))
            == outer_partition["fit_covariate_member_set_sha256"]
            == outer_recipe["training_member_set_sha256"],
            "F2_SELECTOR_SENSITIVITY_MEMBER_SET_INVALID",
        )
        counts = {
            parent: sum(parent in selected for selected in selected_sets)
            for parent in candidates
            if parent != "AST_ALT"
        }
        expected_thresholds = {
            f"{threshold}/20": [
                parent
                for parent in candidates
                if parent != "AST_ALT" and counts[parent] >= threshold
            ]
            for threshold in (12, 14, 16)
        }
        expected_threshold_diagnostics = {}
        for threshold in (12, 14, 16):
            selected = ["AST_ALT", *expected_thresholds[f"{threshold}/20"]]
            design_df = sum(parent_df[parent] for parent in selected)
            epv = event_count / design_df
            expected_threshold_diagnostics[f"{threshold}/20"] = {
                "natural_parent_count": len(selected) - 1,
                "complete_design_df": design_df,
                "event_count": event_count,
                "epv": epv,
                "epv_status": (
                    "ELIGIBLE"
                    if epv >= contract["shared_contract"]["epv_minimum"]
                    else "EPV_INELIGIBLE"
                ),
            }
        if method == "MRMRE":
            natural_rank_domain = [
                parent for parent in candidates if parent != "AST_ALT"
            ]
            correlations = []
            for left in range(20):
                left_positions = {
                    parent: index
                    for index, parent in enumerate(
                        (
                            parent
                            for parent in method_value["private_records"][left][
                                "ranking"
                            ]
                            if parent != "AST_ALT"
                        ),
                        start=1,
                    )
                }
                for right in range(left + 1, 20):
                    right_positions = {
                        parent: index
                        for index, parent in enumerate(
                            (
                                parent
                                for parent in method_value["private_records"][
                                    right
                                ]["ranking"]
                                if parent != "AST_ALT"
                            ),
                            start=1,
                        )
                    }
                    squared_difference = sum(
                        (left_positions[parent] - right_positions[parent]) ** 2
                        for parent in natural_rank_domain
                    )
                    correlations.append(
                        1
                        - 6
                        * squared_difference
                        / (
                            len(natural_rank_domain)
                            * (len(natural_rank_domain) ** 2 - 1)
                        )
                    )
            expected_stability = {
                "kind": "PAIRWISE_SPEARMAN_NATURAL_RANK_STABILITY",
                "natural_candidate_count": len(natural_rank_domain),
                "comparison_count": 190,
                "mean": math.fsum(correlations) / len(correlations),
                "minimum": min(correlations),
                "maximum": max(correlations),
            }
            expected_tentative_frequency = None
        else:
            confirmed_counts = [
                len(record["algorithm_confirmed"])
                for record in method_value["private_records"]
            ]
            expected_stability = {
                "kind": "CONFIRMED_COUNT_STABILITY",
                "imputation_count": 20,
                "mean": math.fsum(confirmed_counts) / len(confirmed_counts),
                "minimum": min(confirmed_counts),
                "maximum": max(confirmed_counts),
            }
            expected_tentative_frequency = {
                parent: sum(
                    record["decisions"][parent] == "Tentative"
                    for record in method_value["private_records"]
                )
                for parent in candidates
                if parent != "AST_ALT"
            }
        _require(
            method_value["natural_frequency"] == counts
            and method_value["tentative_frequency"]
            == expected_tentative_frequency
            and method_value["threshold_sets"] == expected_thresholds
            and method_value["threshold_set_diagnostics"]
            == expected_threshold_diagnostics
            and method_value["stability_summary"] == expected_stability
            and method_value["task_set_sha256"]
            == sha256_bytes(canonical_json_bytes(task_hashes)),
            "F2_SELECTOR_SENSITIVITY_SUMMARY_INVALID",
        )


def _elastic_registered_facts(
    expected_model_input: Mapping[str, Any],
    checkpoint: Mapping[str, Any],
    predictors: Mapping[str, Any],
) -> tuple[dict[tuple[int, int], int], int, dict[str, int]]:
    from .f2_kernel import _elastic_parent_design_columns

    partitions = expected_model_input.get("model_partitions")
    _require(
        isinstance(partitions, list) and len(partitions) == 31,
        "F2_SELECTOR_REGISTERED_FACTS_INVALID",
    )
    inner = {
        (row.get("repeat"), row.get("inner_fold")): row.get("evaluation_count")
        for row in partitions
        if isinstance(row, dict) and row.get("kind") == "INNER"
    }
    outer = [
        row
        for row in partitions
        if isinstance(row, dict) and row.get("kind") == "OUTER"
    ]
    parent_columns = _elastic_parent_design_columns(predictors)
    _require(
        set(inner)
        == {
            (repeat, inner_fold)
            for repeat in range(1, 4)
            for inner_fold in range(1, 6)
        }
        and all(type(value) is int and value > 0 for value in inner.values())
        and len(outer) == 1
        and type(outer[0].get("fit_event_count")) is int
        and outer[0]["fit_event_count"] > 0
        and sha256_bytes(
            canonical_json_bytes(
                sorted(parent_columns, key=lambda value: value.encode("utf-8"))
            )
        )
        == checkpoint.get("eligible_parent_set_sha256"),
        "F2_SELECTOR_REGISTERED_FACTS_INVALID",
    )
    return inner, outer[0]["fit_event_count"], parent_columns


def _validate_elastic_search_trace(
    trace: Any,
    selector: Mapping[str, Any],
    contract: Mapping[str, Any],
    search_evaluation_unit_count: Any,
    expected_validation_n: Mapping[tuple[int, int], int],
    expected_event_count: int,
    expected_parent_columns: Mapping[str, int],
    *,
    predictors: Mapping[str, Any],
    expected_selector_search: Mapping[str, Any] | None = None,
) -> None:
    from .f2_kernel import (
        _choose_elastic_alpha, _summarize_elastic_alpha,
        _elastic_parent_design_columns, _expected_family_parent_column_map,
    )

    ratios = [10 ** (-4 * index / 149) for index in range(150)]
    recipe_set = selector.get("recipe_set")
    recipes = recipe_set.get("recipes") if isinstance(recipe_set, dict) else None
    _require(
        isinstance(recipes, list)
        and len(recipes) == 16
        and all(
            isinstance(recipe, dict)
            and isinstance(recipe.get("ordered_parent_column_map"), list)
            for recipe in recipes
        ),
        "F2_SELECTOR_LAMBDA_PENALTY_IDENTITY_INVALID",
    )
    candidates = sorted(_elastic_parent_design_columns(predictors), key=lambda value: value.encode("utf-8"))
    column_maps = [
        _expected_family_parent_column_map(candidates, "ELASTIC_NET_COX", predictors, recipe)
        for recipe in recipes
    ]
    _require(
        all(column_map == column_maps[0] for column_map in column_maps),
        "F2_SELECTOR_LAMBDA_PENALTY_IDENTITY_INVALID",
    )
    design_columns: list[str] = []
    penalty_factor: list[float] = []
    for row in column_maps[0]:
        parent = row.get("parent") if isinstance(row, dict) else None
        columns = row.get("columns") if isinstance(row, dict) else None
        _require(
            isinstance(parent, str)
            and parent in expected_parent_columns
            and isinstance(columns, list)
            and len(columns) == expected_parent_columns[parent]
            and all(isinstance(column, str) and column for column in columns),
            "F2_SELECTOR_LAMBDA_PENALTY_IDENTITY_INVALID",
        )
        design_columns.extend(columns)
        penalty_factor.extend(
            [0.0 if parent == "AST_ALT" else 1.0] * len(columns)
        )
    expected_penalty_identity = sha256_bytes(
        canonical_json_bytes(
            {
                "design_columns": design_columns,
                "penalty_factor": penalty_factor,
            }
        )
    )

    def validate_lambda_health(value: Any, alpha: float, imputation: int) -> None:
        _require(
            isinstance(value, dict)
            and set(value)
            == {
                "imputation",
                "lambda_max",
                "lambda_path_sha256",
                "lambda_upper_bound",
                "penalized_active_count_path",
                "penalized_design_column_count",
                "penalized_entry_covered",
            }
            and value.get("imputation") == imputation,
            "F2_SELECTOR_LAMBDA_PATH_HEALTH_INVALID",
        )
        provenance = value.get("lambda_upper_bound")
        head = (
            provenance.get("pilot_lambda_head")
            if isinstance(provenance, dict)
            else None
        )
        lambda_max = value.get("lambda_max")
        big = provenance.get("glmnet_big") if isinstance(provenance, dict) else None
        path = (
            [float(lambda_max) * ratio for ratio in ratios]
            if _finite_number(lambda_max)
            else []
        )
        active_path = value.get("penalized_active_count_path")
        penalized_count = value.get("penalized_design_column_count")
        path_identity = value.get("lambda_path_sha256")
        _require(
            isinstance(provenance, dict)
            and set(provenance)
            == {
                "alpha",
                "cox_ties",
                "family",
                "glmnet_big",
                "glmnet_version",
                "kind",
                "penalty_factor_identity_sha256",
                "pilot_lambda_head",
                "pilot_requested_nlambda",
                "pilot_returned_nlambda",
                "resolved_lambda_max",
                "schema_version",
                "sentinel_equivalent",
                "standardize",
            }
            and provenance.get("schema_version") == "1.0.0"
            and provenance.get("kind")
            == "PADML_F2_ELASTIC_LAMBDA_UPPER_BOUND_V1"
            and provenance.get("glmnet_version") == "5.0"
            and provenance.get("family") == "cox"
            and provenance.get("cox_ties") == "breslow"
            and provenance.get("standardize") is True
            and provenance.get("pilot_requested_nlambda") == 100
            and type(provenance.get("pilot_returned_nlambda")) is int
            and provenance["pilot_returned_nlambda"] >= 3
            and _finite_number(provenance.get("alpha"))
            and math.isclose(
                provenance["alpha"], alpha, rel_tol=0.0, abs_tol=1e-15
            )
            and isinstance(head, list)
            and len(head) == 3
            and all(_finite_number(item) and item > 0 for item in head)
            and all(
                left > right for left, right in zip(head, head[1:])
            )
            and _finite_number(lambda_max)
            and lambda_max > 0
            and _finite_number(provenance.get("resolved_lambda_max"))
            and provenance["resolved_lambda_max"] == lambda_max == head[0]
            and _finite_number(big)
            and big > 1e30
            and provenance.get("sentinel_equivalent") is False
            and not math.isclose(
                lambda_max,
                big,
                rel_tol=math.sqrt(2.220446049250313e-16),
                abs_tol=0.0,
            )
            and provenance.get("penalty_factor_identity_sha256")
            == expected_penalty_identity
            and isinstance(path_identity, str)
            and len(path_identity) == 64
            and all(character in "0123456789abcdef" for character in path_identity)
            # A reused seal identifies the observed R vector, validated at the
            # original R boundary; max * ratio reconstructs different float bytes.
            and (expected_selector_search is not None
                 or path_identity == sha256_bytes(canonical_json_bytes(path)))
            and len(path) == 150
            and all(left > right for left, right in zip(path, path[1:]))
            and type(penalized_count) is int
            and penalized_count
            == sum(
                count
                for parent, count in expected_parent_columns.items()
                if parent != "AST_ALT"
            )
            and isinstance(active_path, list)
            and len(active_path) == 150
            and all(
                type(count) is int and 0 <= count <= penalized_count
                for count in active_path
            )
            and value.get("penalized_entry_covered") is True
            and max(active_path) > 0,
            "F2_SELECTOR_LAMBDA_PATH_HEALTH_INVALID",
        )

    _require(
        type(trace) is dict
        and set(trace)
        == {
            "alpha_feasibility",
            "coarse_alpha_order",
            "derivation_records",
            "diagnostics_selection_effect",
            "distinct_alpha_count",
            "fine_alpha_order",
            "outer_coefficient_path_count",
        }
        and trace["diagnostics_selection_effect"] == "NONE"
        and isinstance(trace["coarse_alpha_order"], list)
        and isinstance(trace["fine_alpha_order"], list)
        and isinstance(trace["derivation_records"], list),
        "F2_SELECTOR_SEARCH_TRACE_INVALID",
    )
    records = trace["derivation_records"]
    if expected_selector_search is not None:
        _require(
            isinstance(expected_selector_search, dict)
            and expected_selector_search.get("schema_version") == "1.0.0"
            and expected_selector_search.get("kind") == "PADML_F2_ELASTIC_SEARCH_REUSE"
            and expected_selector_search.get("identity") == sha256_bytes(canonical_json_bytes(
                {key: item for key, item in expected_selector_search.items() if key != "identity"}
            ))
            and expected_selector_search.get("derivation_records_sha256")
            == sha256_bytes(canonical_json_bytes(records)),
            "F2_REUSED_SEARCH_SOURCE_MISMATCH",
        )
    record_alphas = [
        float(row.get("alpha"))
        for row in records
        if type(row) is dict and _finite_number(row.get("alpha"))
    ]
    _require(
        records
        and len(record_alphas) == len(records) == len(set(record_alphas))
        and record_alphas == sorted(record_alphas)
        and all(
            type(row) is dict
            and set(row) == {"alpha", "outer_paths", "partition_losses"}
            and isinstance(row["partition_losses"], list)
            and all(
                type(partition) is dict
                and set(partition)
                == {
                    "inner_fold",
                    "mi_lambda_path_health",
                    "mi_losses",
                    "repeat",
                    "validation_n",
                }
                and partition["validation_n"]
                == expected_validation_n.get(
                    (partition["repeat"], partition["inner_fold"])
                )
                and isinstance(partition["mi_lambda_path_health"], list)
                and len(partition["mi_lambda_path_health"]) == 20
                for partition in row["partition_losses"]
            )
            and isinstance(row["outer_paths"], list)
            and all(
                type(path) is dict
                and set(path)
                == {
                    "coefficient_path_sha256",
                    "event_count",
                    "imputation",
                    "lambda_max",
                    "lambda_path_sha256",
                    "lambda_upper_bound",
                    "parent_coefficients",
                    "parent_design_columns",
                    "penalized_active_count_path",
                    "penalized_design_column_count",
                    "penalized_entry_covered",
                }
                and path["coefficient_path_sha256"]
                == sha256_bytes(
                    canonical_json_bytes(
                        {
                            "parent_design_columns": path[
                                "parent_design_columns"
                            ],
                            "parent_coefficients": path[
                                "parent_coefficients"
                            ],
                        }
                    )
                )
                and path["event_count"] == expected_event_count
                and path["parent_design_columns"]
                == dict(expected_parent_columns)
                for path in row["outer_paths"]
            )
            for row in records
        ),
        "F2_SELECTOR_DERIVATION_EVIDENCE_INVALID",
    )
    for row in records:
        alpha = float(row["alpha"])
        for partition in row["partition_losses"]:
            for imputation, health in enumerate(
                partition["mi_lambda_path_health"], start=1
            ):
                validate_lambda_health(health, alpha, imputation)
        for imputation, path in enumerate(row["outer_paths"], start=1):
            validate_lambda_health(
                {
                    "imputation": path["imputation"],
                    "lambda_max": path["lambda_max"],
                    "lambda_path_sha256": path["lambda_path_sha256"],
                    "lambda_upper_bound": path["lambda_upper_bound"],
                    "penalized_active_count_path": path[
                        "penalized_active_count_path"
                    ],
                    "penalized_design_column_count": path[
                        "penalized_design_column_count"
                    ],
                    "penalized_entry_covered": path[
                        "penalized_entry_covered"
                    ],
                },
                alpha,
                imputation,
            )
            recomputed_active = [
                sum(
                    coefficient != 0
                    for parent, coefficient_path in path[
                        "parent_coefficients"
                    ].items()
                    if parent != "AST_ALT"
                    for coefficient in coefficient_path[index]
                )
                for index in range(150)
            ]
            _require(
                recomputed_active == path["penalized_active_count_path"],
                "F2_SELECTOR_PENALIZED_ENTRY_REPLAY_MISMATCH",
            )
    by_alpha = dict(zip(record_alphas, records, strict=True))
    coarse = trace["coarse_alpha_order"]
    _require(
        coarse == [float(value) for value in contract["alpha_grid"]["coarse"]]
        and all(alpha in by_alpha for alpha in coarse),
        "F2_SELECTOR_COARSE_ALPHA_GRID_INVALID",
    )
    coarse_choice, _ = _choose_elastic_alpha(
        [by_alpha[alpha] for alpha in coarse],
        coarse,
        contract,
    )
    fine_contract = contract["alpha_grid"]["fine"]
    lower, upper = [float(value) for value in fine_contract["clip"]]
    expected_fine = sorted(
        {
            min(
                upper,
                max(
                    lower,
                    round(coarse_choice["alpha"] + float(offset), 3),
                ),
            )
            for offset in fine_contract["offsets"]
        }
    )
    fine = trace["fine_alpha_order"]
    _require(
        fine == expected_fine and all(alpha in by_alpha for alpha in fine),
        "F2_SELECTOR_FINE_ALPHA_GRID_INVALID",
    )
    chosen, _ = _choose_elastic_alpha(
        [by_alpha[alpha] for alpha in fine],
        fine,
        contract,
    )
    expected_alphas = sorted(set(coarse) | set(fine))
    _require(
        trace["alpha_feasibility"] == [
            {key: summary[key] for key in ("alpha", "status", "reason_code")}
            for summary in (_summarize_elastic_alpha(by_alpha[alpha], contract) for alpha in record_alphas)
        ],
        "F2_SELECTOR_ALPHA_FEASIBILITY_REPLAY_MISMATCH",
    )
    _require(
        trace["distinct_alpha_count"]
        == len(records)
        == len(expected_alphas)
        and record_alphas == expected_alphas
        and trace["outer_coefficient_path_count"]
        == len(records) * 20
        and search_evaluation_unit_count
        == len(records) * 15 * 20
        and chosen["alpha"] == selector["common_alpha"]
        and all(chosen[field] == selector[field] for field in (
            "r_min_by_imputation", "r_0_5se_by_imputation", "selected_ratio_by_imputation",
            "active_design_df_by_imputation", "median_active_design_df", "p90_active_design_df",
            "median_active_epv", "conservative_active_epv", "common_set_design_df", "common_set_epv",
        ))
        and chosen["selected_parents"] == selector["selected_parents"]
        and chosen["outer_training_event_count"]
        == selector["outer_training_event_count"]
        and chosen["natural_frequency"] == selector["natural_frequency"]
        and chosen["jaccard_diagnostic"] == selector["jaccard_diagnostic"]
        and chosen["jaccard_empty_set_vacuous"]
        == selector["jaccard_empty_set_vacuous"]
        and chosen["direction_diagnostic_flags"]
        == selector["direction_diagnostic_flags"]
        and chosen["lambda_by_imputation"] == selector["final_refit_lambda_by_imputation"]
        and chosen["lambda_upper_bound_by_imputation"] == selector["lambda_upper_bound_by_imputation"]
        and all(
            _finite_number(value) and value > 0
            for value in chosen["lambda_by_imputation"]
        ),
        "F2_SELECTOR_SEARCH_DECISION_MISMATCH",
    )


def _validate_elastic_final_stopping(
    stopping: Any,
    selector: Mapping[str, Any],
    family_design_binding: Mapping[str, Any],
    prediction_seal_set_sha256: str,
    *,
    predictors: Mapping[str, Any],
) -> None:
    from .f2_kernel import _elastic_parent_design_columns, _expected_family_parent_column_map

    expected_lambdas = selector.get("final_refit_lambda_by_imputation")
    expected_upper_bounds = selector.get("lambda_upper_bound_by_imputation")
    selected_parent_sha256 = sha256_bytes(
        canonical_json_bytes(selector["selected_parents"])
    )
    selected_design_sha256 = selector["selected_design_sha256"]
    parent_map = family_design_binding.get("ordered_parent_column_map")
    _require(
        family_design_binding.get("family") == "ELASTIC_NET_COX"
        and isinstance(parent_map, list)
        and parent_map,
        "F2_ELASTIC_FINAL_REFIT_DESIGN_INVALID",
    )
    # The locked lambda was selected on the complete candidate design, not
    # re-tuned after SetA aggregation or for a downstream diagnostic subset.
    source_recipes = [row for row in selector["recipe_set"]["recipes"]
                      if row["recipe_sha256"] == selector["outer_recipe_sha256"]]
    _require(len(source_recipes) == 1, "F2_ELASTIC_FINAL_REFIT_DESIGN_INVALID")
    source_map = _expected_family_parent_column_map(
        sorted(_elastic_parent_design_columns(predictors), key=lambda value: value.encode("utf-8")),
        "ELASTIC_NET_COX", predictors, source_recipes[0],
    )
    _require(parent_map == [row for row in source_map if row["parent"] in selector["selected_parents"]],
             "F2_ELASTIC_FINAL_REFIT_DESIGN_INVALID")
    design_columns: list[str] = []
    penalty_factor: list[float] = []
    for parent_row in source_map:
        _require(
            isinstance(parent_row, dict)
            and set(parent_row) == {"columns", "parent"}
            and isinstance(parent_row["columns"], list)
            and bool(parent_row["columns"]),
            "F2_ELASTIC_FINAL_REFIT_DESIGN_INVALID",
        )
        design_columns.extend(parent_row["columns"])
        penalty_factor.extend(
            [0.0 if parent_row["parent"] == "AST_ALT" else 1.0]
            * len(parent_row["columns"])
        )
    if design_columns == ["AST_ALT"]:
        design_columns.append("PADML_GLMNET_INERT_ZERO")
        penalty_factor.append(1.0)
    expected_penalty_identity = sha256_bytes(
        canonical_json_bytes(
            {
                "design_columns": design_columns,
                "penalty_factor": penalty_factor,
            }
        )
    )
    _require(
        isinstance(stopping, list)
        and len(stopping) == 20
        and isinstance(expected_lambdas, list)
        and len(expected_lambdas) == 20
        and isinstance(expected_upper_bounds, list)
        and len(expected_upper_bounds) == 20,
        "F2_ELASTIC_FINAL_REFIT_DENOMINATOR_INVALID",
    )
    for index, (row, expected_lambda) in enumerate(
        zip(stopping, expected_lambdas, strict=True), start=1
    ):
        provenance = row.get("lambda_upper_bound") if isinstance(row, dict) else None
        head = provenance.get("pilot_lambda_head") if isinstance(provenance, dict) else None
        big = provenance.get("glmnet_big") if isinstance(provenance, dict) else None
        _require(
            type(row) is dict
            and set(row)
            == {
                "alpha",
                "converged",
                "engine",
                "imputation",
                "lambda",
                "lambda_max",
                "lambda_upper_bound",
                "prediction_seal_sha256",
                "ratio",
                "selected_design_sha256",
                "selected_parent_sha256",
            }
            and row["engine"] == "glmnet::glmnet"
            and row["converged"] is True
            and row["imputation"] == index
            and row["selected_parent_sha256"] == selected_parent_sha256
            and row["selected_design_sha256"] == selected_design_sha256
            and row["lambda_upper_bound"] == expected_upper_bounds[index - 1]
            and isinstance(provenance, dict)
            and set(provenance)
            == {
                "alpha",
                "cox_ties",
                "family",
                "glmnet_big",
                "glmnet_version",
                "kind",
                "penalty_factor_identity_sha256",
                "pilot_lambda_head",
                "pilot_requested_nlambda",
                "pilot_returned_nlambda",
                "resolved_lambda_max",
                "schema_version",
                "sentinel_equivalent",
                "standardize",
            }
            and provenance["schema_version"] == "1.0.0"
            and provenance["kind"]
            == "PADML_F2_ELASTIC_LAMBDA_UPPER_BOUND_V1"
            and provenance["glmnet_version"] == "5.0"
            and provenance["family"] == "cox"
            and provenance["cox_ties"] == "breslow"
            and provenance["standardize"] is True
            and provenance["pilot_requested_nlambda"] == 100
            and type(provenance["pilot_returned_nlambda"]) is int
            and provenance["pilot_returned_nlambda"] >= 3
            and isinstance(head, list)
            and len(head) == 3
            and all(_finite_number(item) and item > 0 for item in head)
            and all(left > right for left, right in zip(head, head[1:]))
            and provenance["sentinel_equivalent"] is False
            and _finite_number(big)
            and big > 1e30
            and not math.isclose(
                float(provenance["resolved_lambda_max"]),
                float(big),
                rel_tol=math.sqrt(2.220446049250313e-16),
                abs_tol=0.0,
            )
            and provenance["penalty_factor_identity_sha256"]
            == expected_penalty_identity
            and row["lambda_max"]
            == expected_upper_bounds[index - 1]["resolved_lambda_max"]
            and all(
                _finite_number(row[field]) and row[field] > 0
                for field in ("alpha", "ratio", "lambda_max", "lambda")
            )
            and math.isclose(
                row["alpha"],
                selector["common_alpha"],
                rel_tol=1e-10,
                abs_tol=1e-12,
            )
            and math.isclose(
                row["ratio"],
                selector["selected_ratio_by_imputation"][index - 1],
                rel_tol=1e-10,
                abs_tol=1e-12,
            )
            and math.isclose(
                row["lambda"],
                row["lambda_max"] * row["ratio"],
                rel_tol=1e-10,
                abs_tol=1e-12,
            )
            and math.isclose(
                row["lambda"],
                expected_lambda,
                rel_tol=1e-10,
                abs_tol=1e-12,
            ),
            "F2_ELASTIC_FINAL_REFIT_INVALID",
        )
        validate_sha256(
            row["prediction_seal_sha256"],
            f"f2.elastic_final_prediction_seal[{index}]",
        )
    _require(
        sha256_bytes(
            canonical_json_bytes(
                [row["prediction_seal_sha256"] for row in stopping]
            )
        )
        == prediction_seal_set_sha256,
        "F2_ELASTIC_FINAL_PREDICTION_SET_MISMATCH",
    )


def _fpm_piece_arithmetic(matrix: list[list[float]], beta: list[float]) -> dict[str, Any]:
    """Exact stored-binary64 polynomial; round only the values sent to consumers."""
    q = [sum((Fraction(x)*Fraction(b) for x, b in zip(row, beta, strict=True)), Fraction())
         for row in matrix]
    locations = [Fraction(0), Fraction(1)]
    if q[2] > 0 and 0 < -q[1]/(2*q[2]) < 1:
        locations.append(-q[1]/(2*q[2]))
    def evaluate(z: Fraction) -> Fraction:
        return q[0] + z*(q[1] + z*q[2])
    location = min(locations, key=evaluate)
    coordinates = [float(z) for z in locations]
    rows = [[float(Fraction(matrix[0][j]) + Fraction(z)*(
                 Fraction(matrix[1][j]) + Fraction(z)*Fraction(matrix[2][j])))
             for j in range(len(beta))] for z in coordinates]
    return {"q": [float(x) for x in q], "coordinates": coordinates, "rows": rows,
            "values": [float(evaluate(Fraction(z))) for z in coordinates],
            "location": float(location), "minimum": float(evaluate(location)),
            "left": float(q[0]), "right": float(sum(q))}


def _validate_fpm_continuous_domain(
    value: Any, bases: list[dict[str, Any]], computed: list[dict[str, Any]],
) -> None:
    """Replay native cubic-piece derivative extrema within the existing validator."""
    reason = "F2_FPM_CONTINUOUS_DOMAIN_INVALID"
    _require(isinstance(value, dict) and set(value) == {
        "definition", "ast_alt_closure", "actual_input_lower_open", "time_domain",
        "natural_linear_tails", "log_time_breaks", "pieces", "minimum_log_time_derivative",
        "left_tail_log_time_derivatives", "right_tail_log_time_derivatives",
        "baseline_linear_initialization_shift", "optimizer_rounds", "max_iterations_per_round",
        "max_rounds", "covariance_role", "constrained_wald_inference_validated"}, reason)
    breaks = sorted({x for b in bases for x in b["knots"] + b["boundary_knots"]})
    _require(value["definition"] == "AST_ALT_0_15_CONTINUOUS_LOG_TIME_V1"
             and value["ast_alt_closure"] == [0, 15]
             and value["actual_input_lower_open"] is True
             and value["time_domain"] == "ALL_POSITIVE_TIMES"
             and value["natural_linear_tails"] is True
             and len(breaks) == 4 and value["log_time_breaks"] == breaks
             and type(value["optimizer_rounds"]) is int and 1 <= value["optimizer_rounds"] <= 10
             and value["max_iterations_per_round"] == 100 and value["max_rounds"] == 10
             and _finite_number(value["baseline_linear_initialization_shift"])
             and value["baseline_linear_initialization_shift"] >= 0
             and value["covariance_role"] == "UNPENALIZED_LIKELIHOOD_CURVATURE_ONLY"
             and value["constrained_wald_inference_validated"] is False, reason)
    pieces = value["pieces"]
    _require(isinstance(pieces, list) and len(pieces) == 6, reason)
    minima: list[float] = []
    left_tails: list[float] = []
    right_tails: list[float] = []

    def same(observed: Any, expected: float) -> bool:
        return _finite_number(observed) and math.isclose(
            observed, expected, rel_tol=1e-10, abs_tol=1e-10)

    for index, piece in enumerate(pieces):
        interval = index % 3
        _require(isinstance(piece, dict) and set(piece) == {
            "ast_alt", "log_time_interval", "derivative_coefficients", "minimum_coordinate", "minimum"}
            and piece["ast_alt"] == (0 if index < 3 else 15)
            and piece["log_time_interval"] == breaks[interval:interval+2], reason)
        coefficients = piece["derivative_coefficients"]
        _require(isinstance(coefficients, list) and len(coefficients) == 3
                 and all(_finite_number(c) for c in coefficients), reason)
        canonical = computed[index]
        _require(all(same(observed, expected) for observed, expected
                     in zip(coefficients, canonical["q"], strict=True)), reason)
        constant, linear, quadratic = canonical["q"]
        location, minimum = canonical["location"], canonical["minimum"]
        _require(math.isfinite(minimum) and minimum > 0
                 and same(piece["minimum_coordinate"], location)
                 and same(piece["minimum"], minimum), reason)
        minima.append(minimum)
        if interval == 0:
            _require(same(linear, 0.0), reason)
            left_tails.append(canonical["left"])
        else:
            previous = pieces[index-1]["derivative_coefficients"]
            _require(same(constant, sum(previous)), reason)
        if interval == 2:
            _require(same(linear + 2*quadratic, 0.0), reason)
            right_tails.append(canonical["right"])
    for field, expected in (("left_tail_log_time_derivatives", left_tails),
                            ("right_tail_log_time_derivatives", right_tails)):
        _require(isinstance(value[field], list) and len(value[field]) == 2
                 and all(x > 0 and same(y, x) for x, y in zip(expected, value[field], strict=True)), reason)
    _require(same(value["minimum_log_time_derivative"], min(minima)), reason)


def _validate_fpm_fit_evidence(value: Any, expected_df: list[int], coefficient_count: int) -> None:
    """Check observed rstpm2 knots and native convergence controls, not fitted guesses."""
    _require(
        isinstance(value, dict) and set(value) == {
            "optimizer_method", "termination_code", "maximum_gradient", "objective_value",
            "controls", "log_time_transform", "spline_bases", "constraint_correction", "native_feasible",
            "continuous_domain", "constrained_optimality"}
        and value["constraint_correction"] == "ph-continuous-domain-bfgs-v1"
        and value["native_feasible"] is True
        and value["optimizer_method"] == "BFGS"
        and type(value["termination_code"]) is int and value["termination_code"] == 0
        and _finite_number(value["maximum_gradient"]) and value["maximum_gradient"] >= 0
        and _finite_number(value["objective_value"])
        and value["log_time_transform"] is True,
        "F2_FPM_FIT_EVIDENCE_INVALID",
    )
    controls = value["controls"]
    _require(
        isinstance(controls, dict) and set(controls) == {
            "reltol", "reltol_search", "reltol_outer", "outer_optim", "parscale", "maxkappa", "final_kappa"}
        and controls["reltol"] == controls["reltol_search"] == 1e-10
        and controls["reltol_outer"] == 1e-5
        and type(controls["outer_optim"]) is int and controls["outer_optim"] == 1
        and controls["maxkappa"] == 1000
        and _finite_number(controls["final_kappa"]) and 0 < controls["final_kappa"] <= 1000
        and isinstance(controls["parscale"], list) and len(controls["parscale"]) == coefficient_count
        and all(_finite_number(item) and item == 1 for item in controls["parscale"]),
        "F2_FPM_CONVERGENCE_CONTROLS_INVALID",
    )
    bases = value["spline_bases"]
    _require(isinstance(bases, list) and len(bases) == len(expected_df) == 2,
             "F2_FPM_ACTUAL_SPLINE_EVIDENCE_INVALID")
    for basis, df, role in zip(bases, expected_df, ("BASELINE_LOG_TIME", "AST_ALT_TVC_LOG_TIME"), strict=True):
        _require(isinstance(basis, dict) and set(basis) == {
            "role", "df", "knots", "boundary_knots", "intercept", "derivatives", "centre", "log"}
            and basis["role"] == role and type(basis["df"]) is int and basis["df"] == df
            and isinstance(basis["knots"], list) and len(basis["knots"]) == df - 1
            and all(_finite_number(item) for item in basis["knots"])
            and all(left < right for left, right in zip(basis["knots"], basis["knots"][1:]))
            and isinstance(basis["boundary_knots"], list) and len(basis["boundary_knots"]) == 2
            and all(_finite_number(item) for item in basis["boundary_knots"])
            and basis["boundary_knots"][0] < basis["boundary_knots"][1]
            and all(basis["boundary_knots"][0] < item < basis["boundary_knots"][1] for item in basis["knots"])
            and basis["intercept"] is False and basis["centre"] is False and basis["log"] is False
            and basis["derivatives"] == [2, 2],
            "F2_FPM_ACTUAL_SPLINE_EVIDENCE_INVALID")
    optimality = value["constrained_optimality"]
    reason = "F2_FPM_CONSTRAINED_OPTIMALITY_INVALID"
    _require(isinstance(optimality, dict) and set(optimality) == {
        "definition", "coefficients", "gradient", "multipliers", "derivative_matrices"}
        and optimality["definition"] == "PH_CONTINUOUS_DOMAIN_KKT_V1", reason)
    coefficients, gradient = optimality["coefficients"], optimality["gradient"]
    _require(all(isinstance(row, list) and len(row) == coefficient_count
                 and all(_finite_number(item) for item in row)
                 for row in (coefficients, gradient)), reason)
    _require(math.isclose(max(abs(x) for x in gradient), value["maximum_gradient"],
                         rel_tol=1e-10, abs_tol=1e-10), reason)
    matrices = optimality["derivative_matrices"]
    _require(isinstance(matrices, list) and len(matrices) == 6, reason)
    computed = []
    for matrix in matrices:
        _require(isinstance(matrix, list) and len(matrix) == 3
                 and all(isinstance(row, list) and len(row) == coefficient_count
                         and all(_finite_number(item) for item in row) for row in matrix), reason)
        computed.append(_fpm_piece_arithmetic(matrix, coefficients))
    _validate_fpm_continuous_domain(value["continuous_domain"], bases, computed)
    normals, gaps = [], []
    for piece in computed:
        for row, gap in zip(piece["rows"], piece["values"], strict=True):
            norm = math.sqrt(math.fsum(x*x for x in row))
            _require(math.isfinite(norm) and norm > 0, reason)
            normals.append([x/norm for x in row])
            gaps.append(gap/norm)
    multipliers = optimality["multipliers"]
    _require(isinstance(multipliers, list) and len(multipliers) == len(normals)
             and all(_finite_number(x) and x >= 0 for x in multipliers), reason)
    residual = [gradient[j]-math.fsum(weight*row[j] for weight, row in zip(multipliers, normals, strict=True))
                for j in range(coefficient_count)]
    scale = 0.001 + abs(value["objective_value"])
    active_limit = math.sqrt(controls["reltol"])*(1+max(abs(x) for x in coefficients))
    _require(all(math.isfinite(gap) and gap >= 0 for gap in gaps)
             and all(weight == 0 or gap <= active_limit
                     for weight, gap in zip(multipliers, gaps, strict=True))
             and max(abs(x) for x in residual)/scale <= math.sqrt(controls["reltol"])
             and math.fsum(weight*gap for weight, gap in zip(multipliers, gaps, strict=True))/scale
                 <= controls["reltol"], reason)


def _validate_nonelastic_fit_health(
    family: str,
    stopping: Any,
    family_design_binding: Mapping[str, Any],
    science: Mapping[str, Any],
    prediction_seal_set_sha256: str,
    *,
    selected_spec: Mapping[str, Any] | None = None,
    training_count: int | None = None,
) -> None:
    """Validate fit health and actual numerical evidence emitted by native R engines."""

    _require(
        family in {"COX_PH", "RSF", "GBM_COX", "FPM_TVC_SET_A"}
        and isinstance(stopping, list)
        and len(stopping) == 20,
        "F2_NATIVE_FIT_HEALTH_DENOMINATOR_INVALID",
    )
    parent_map = family_design_binding.get("ordered_parent_column_map")
    _require(
        isinstance(parent_map, list)
        and parent_map
        and all(
            isinstance(row, dict)
            and set(row) == {"parent", "columns"}
            and isinstance(row["columns"], list)
            and bool(row["columns"])
            for row in parent_map
        ),
        "F2_NATIVE_FIT_HEALTH_DESIGN_INVALID",
    )
    design_columns = sum(len(row["columns"]) for row in parent_map)
    expected_prediction_seals: list[str] = []
    for imputation, row in enumerate(stopping, start=1):
        _require(
            isinstance(row, dict)
            and row.get("imputation") == imputation
            and row.get("converged") is True
            and row.get("warning_count") == 0
            and isinstance(row.get("prediction_seal_sha256"), str)
            and len(row["prediction_seal_sha256"]) == 64,
            "F2_NATIVE_FIT_HEALTH_INVALID",
        )
        validate_sha256(
            row["prediction_seal_sha256"],
            f"f2.native_fit_prediction_seal[{imputation}]",
        )
        if family == "COX_PH":
            _require(
                set(row)
                == {
                    "coefficient_count",
                    "converged",
                    "covariance_rank",
                    "engine",
                    "imputation",
                    "iteration_count",
                    "prediction_seal_sha256",
                    "ties",
                    "warning_count",
                }
                and row["engine"] == "survival::coxph"
                and row["ties"] == "breslow"
                and type(row.get("coefficient_count")) is int
                and row["coefficient_count"] == design_columns
                and row.get("covariance_rank") == row["coefficient_count"]
                and type(row.get("iteration_count")) is int
                and row["iteration_count"] >= 0,
                "F2_COX_PH_FIT_HEALTH_INVALID",
            )
        elif family == "FPM_TVC_SET_A":
            fpm_df = science["fpm"]["set_a_df"]
            expected_coefficients = design_columns + sum(fpm_df) + 1
            _require(
                set(row)
                == {
                    "coefficient_count",
                    "converged",
                    "covariance_rank",
                    "df",
                    "engine",
                    "fit_evidence",
                    "imputation",
                    "optimizer",
                    "optimizer_convergence",
                    "prediction_seal_sha256",
                    "tvc_df",
                    "warning_count",
                }
                and row["engine"] == "rstpm2::stpm2"
                and row["df"] == fpm_df[0]
                and row["tvc_df"] == fpm_df[1]
                and row.get("optimizer") == "optim"
                and type(row["optimizer_convergence"]) is int and row["optimizer_convergence"] == 0
                and type(row.get("coefficient_count")) is int
                and row["coefficient_count"] == expected_coefficients
                and row.get("covariance_rank") == row["coefficient_count"],
                "F2_FPM_FIT_HEALTH_INVALID",
            )
            _validate_fpm_fit_evidence(row["fit_evidence"], fpm_df, expected_coefficients)
        elif family == "RSF":
            parameters = (
                selected_spec.get("parameters")
                if isinstance(selected_spec, Mapping)
                else None
            )
            _require(
                isinstance(parameters, Mapping),
                "F2_RSF_FIT_HEALTH_INVALID",
            )
            try:
                expected_trees = int(parameters["num.trees"])
                expected_mtry = min(
                    design_columns,
                    max(
                        1,
                        int(
                            (
                                Decimal(str(parameters["mtry_fraction"]))
                                * Decimal(design_columns)
                            ).quantize(Decimal("1"), rounding=ROUND_HALF_UP)
                        ),
                    ),
                )
            except (KeyError, TypeError, ValueError, ArithmeticError) as exc:
                raise ContractError("F2_RSF_FIT_HEALTH_INVALID") from exc
            _require(
                set(row)
                == {
                    "converged",
                    "death_time_count",
                    "engine",
                    "imputation",
                    "independent_variable_count",
                    "mtry",
                    "num_trees",
                    "prediction_error",
                    "prediction_seal_sha256",
                    "tree_count",
                    "warning_count",
                }
                and row["engine"] == "ranger::ranger"
                and row["num_trees"] == expected_trees
                and row["tree_count"] == expected_trees
                and row["independent_variable_count"] == design_columns
                and row["mtry"] == expected_mtry
                and type(row.get("death_time_count")) is int
                and row["death_time_count"] > 0
                and _finite_number(row.get("prediction_error"))
                and 0 <= row["prediction_error"] <= 1,
                "F2_RSF_FIT_HEALTH_INVALID",
            )
        else:
            _require(
                isinstance(selected_spec, Mapping)
                and selected_spec.get("family") == "GBM_COX"
                and type(selected_spec.get("selected_trees")) is int
                and type(training_count) is int
                and training_count > 0,
                "F2_GBM_FIT_HEALTH_INVALID",
            )
            selected_trees = selected_spec["selected_trees"]
            _require(
                set(row)
                == {
                    "cox_objective",
                    "converged",
                    "engine",
                    "imputation",
                    "independent_variable_count",
                    "maximum_training_loss",
                    "minimum_training_loss",
                    "prediction_seal_sha256",
                    "selected_trees",
                    "stopping_reselected",
                    "training_loss_count",
                    "training_only_stop_count",
                    "training_row_count",
                    "tree_count",
                    "warning_count",
                }
                and row["engine"] == "gbm::gbm"
                and row["selected_trees"] == selected_trees
                and row["tree_count"] == selected_trees
                and row["training_loss_count"] == selected_trees
                and row["training_row_count"] == training_count
                and row["independent_variable_count"] == design_columns
                and row["training_only_stop_count"] == 0
                and row["stopping_reselected"] is False
                and _finite_number(row.get("minimum_training_loss"))
                and _finite_number(row.get("maximum_training_loss"))
                and row["minimum_training_loss"]
                <= row["maximum_training_loss"],
                "F2_GBM_FIT_HEALTH_INVALID",
            )
            from .f2_kernel import _validate_gbm_cox_objective_health
            _validate_gbm_cox_objective_health(row["cox_objective"])
        expected_prediction_seals.append(row["prediction_seal_sha256"])
    _require(
        sha256_bytes(canonical_json_bytes(expected_prediction_seals))
        == prediction_seal_set_sha256,
        "F2_NATIVE_FIT_PREDICTION_SET_MISMATCH",
    )


def _validate_python_final_fit_health(
    family: str,
    stopping: Any,
    *,
    selected_spec: Mapping[str, Any],
    training_count: int,
    heldout_count: int,
    prediction_seal_set_sha256: str,
) -> None:
    """Independently validate final XGBoost/CoxTime native observations."""
    from .f2_kernel import _validate_coxtime_baseline_health, _validate_xgb_cox_objective_health

    _require(
        family in {"XGBOOST_COX", "COXTIME_SET_A"}
        and isinstance(stopping, list)
        and len(stopping) == 20
        and isinstance(selected_spec, Mapping)
        and selected_spec.get("family") == family
        and type(training_count) is int
        and training_count > 0
        and type(heldout_count) is int
        and heldout_count > 0,
        "F2_PYTHON_FIT_HEALTH_DENOMINATOR_INVALID",
    )
    lock_key = (
        "selected_rounds" if family == "XGBOOST_COX" else "locked_epoch"
    )
    stopping_key = (
        "locked_rounds" if family == "XGBOOST_COX" else "locked_epoch"
    )
    locked_value = selected_spec.get(lock_key)
    _require(
        type(locked_value) is int and locked_value > 0,
        f"F2_{family}_FIT_HEALTH_INVALID",
    )
    prediction_seals: list[str] = []
    for imputation, row in enumerate(stopping, start=1):
        _require(
            isinstance(row, dict)
            and row.get("imputation") == imputation
            and row.get(stopping_key) == locked_value
            and row.get("stopping_reselected") is False
            and row.get("converged") is True
            and isinstance(row.get("prediction_seal_sha256"), str),
            f"F2_{family}_FIT_HEALTH_INVALID",
        )
        validate_sha256(
            row["prediction_seal_sha256"],
            f"f2.python_fit_prediction_seal[{imputation}]",
        )
        if family == "XGBOOST_COX":
            _require(
                set(row)
                == {
                    "booster_round_count",
                    "converged",
                    "engine",
                    "evaluation_margin_count",
                    "imputation",
                    "locked_rounds",
                    "model_binary_sha256",
                    "objective",
                    "cox_objective",
                    "prediction_seal_sha256",
                    "stopping_reselected",
                    "training_margin_count",
                }
                and row["engine"] == "xgboost survival:cox"
                and row["objective"] == "survival:cox"
                and row["booster_round_count"] == locked_value
                and row["training_margin_count"] == training_count
                and row["evaluation_margin_count"] == heldout_count
                and isinstance(row.get("model_binary_sha256"), str),
                "F2_XGBOOST_FIT_HEALTH_INVALID",
            )
            validate_sha256(
                row["model_binary_sha256"],
                f"f2.xgboost_model_binary[{imputation}]",
            )
            _validate_xgb_cox_objective_health(row["cox_objective"], locked_value, training_count)
        else:
            _require(
                set(row)
                == {
                    "converged",
                    "engine",
                    "evaluation_row_count",
                    "final_training_loss",
                    "imputation",
                    "locked_epoch",
                    "model_state_sha256",
                    "prediction_seal_sha256",
                    "raw_survival_grid_validated",
                    "baseline_numerics",
                    "stopping_reselected",
                    "training_epoch_count",
                    "training_row_count",
                }
                and row["engine"] == "pycox.models.CoxTime"
                and row["training_epoch_count"] == locked_value
                and row["training_row_count"] == training_count
                and row["evaluation_row_count"] == heldout_count
                and _finite_number(row.get("final_training_loss"))
                and row["raw_survival_grid_validated"] is True
                and isinstance(row.get("model_state_sha256"), str),
                "F2_COXTIME_FIT_HEALTH_INVALID",
            )
            validate_sha256(
                row["model_state_sha256"],
                f"f2.coxtime_model_state[{imputation}]",
            )
            _validate_coxtime_baseline_health(row["baseline_numerics"], training_count)
        prediction_seals.append(row["prediction_seal_sha256"])
    _require(
        sha256_bytes(canonical_json_bytes(prediction_seals))
        == prediction_seal_set_sha256,
        "F2_PYTHON_FIT_PREDICTION_SET_MISMATCH",
    )


def _trial_projection(rows: Any) -> list[dict[str, Any]]:
    _require(isinstance(rows, list), "F2_TRIAL_TRACE_INVALID")
    projected: list[dict[str, Any]] = []
    for row in rows:
        metric_values = row.get("metric_values") if isinstance(row, dict) else None
        ranking_values = row.get("ranking_metric_values") if isinstance(row, dict) else None
        fold_values = row.get("fold_metric_values") if isinstance(row, dict) else None
        ranking_qc = row.get("ranking_metric_qc") if isinstance(row, dict) else None
        _require(
            isinstance(row, dict)
            and isinstance(row.get("candidate_id"), str)
            and bool(row["candidate_id"])
            and isinstance(row.get("parameters"), dict)
            and isinstance(metric_values, list)
            and metric_values
            and all(
                _finite_number(metric) and metric >= 0
                for metric in metric_values
            )
            and _finite_number(row.get("mean_ibs"))
            and _finite_number(row.get("maximum_ibs"))
            and row["mean_ibs"] >= 0
            and row["maximum_ibs"] >= row["mean_ibs"]
            and type(row.get("evaluation_units")) is int
            and row["evaluation_units"] == len(metric_values)
            and isinstance(ranking_values, list)
            and ranking_values
            and all(_finite_number(metric) and metric >= 0 for metric in ranking_values)
            and isinstance(fold_values, list)
            and fold_values
            and all(_finite_number(metric) and metric >= 0 for metric in fold_values)
            and type(row.get("ranking_evaluation_count")) is int
            and row["ranking_evaluation_count"] == len(ranking_values)
            and isinstance(ranking_qc, list)
            and len(ranking_qc) == len(ranking_values)
            and row["mean_ibs"]
            == math.fsum(ranking_values) / len(ranking_values)
            and row["maximum_ibs"] == max(ranking_values),
            "F2_TRIAL_TRACE_INVALID",
        )
        for qc in ranking_qc:
            _validate_primary_metric_qc(qc)
        projected.append(
            {
                "candidate_id": row["candidate_id"],
                "parameters": row["parameters"],
                "parameter_sha256": row.get("parameter_sha256"),
            }
        )
    return projected


def _validate_rank_boundary(rows: Any, retain: int) -> None:
    """Independently reject a scientifically tied promotion boundary."""

    _require(
        isinstance(rows, list)
        and rows
        and isinstance(retain, int)
        and not isinstance(retain, bool)
        and 1 <= retain <= len(rows),
        "F2_MODEL_SELECTION_RANK_BOUNDARY_INVALID",
    )
    _trial_projection(rows)
    ranked = sorted(
        rows,
        key=lambda row: (
            row.get("mean_ibs") if isinstance(row, dict) else None,
            row.get("maximum_ibs") if isinstance(row, dict) else None,
            row.get("parameter_sha256") if isinstance(row, dict) else None,
        ),
    )
    if retain < len(ranked):
        selected_boundary = ranked[retain - 1]
        excluded_boundary = ranked[retain]
        _require(
            (
                selected_boundary.get("mean_ibs"),
                selected_boundary.get("maximum_ibs"),
            )
            != (
                excluded_boundary.get("mean_ibs"),
                excluded_boundary.get("maximum_ibs"),
            ),
            "F2_MODEL_SELECTION_INDISTINGUISHABLE",
        )


def _validate_nonelastic_winner(
    family: str,
    trace: Any,
    selected_spec: Any,
    selector: Mapping[str, Any],
    f2: Mapping[str, Any],
    science: Mapping[str, Any],
    search_evaluation_unit_count: Any,
) -> None:
    """Rebuild each non-Elastic winner from the frozen candidate trace."""

    if family == "COX_PH":
        _require(
            f2["search_budgets"]["COX_PH"] == {"formal_confirmation": "M20_X15"}
            and isinstance(trace, dict) and set(trace) == {"FORMAL_CONFIRMATION"}
            and isinstance(trace["FORMAL_CONFIRMATION"], list) and len(trace["FORMAL_CONFIRMATION"]) == 1
            and type(search_evaluation_unit_count) is int and search_evaluation_unit_count == 320
            and selected_spec
            == {
                "family": "COX_PH",
                "selected_parents": selector["selected_parents"],
                "ties": "breslow",
            },
            "F2_COX_PH_SELECTED_SPEC_MISMATCH",
        )
        confirmation = trace["FORMAL_CONFIRMATION"][0]
        parameters = {"ties": "breslow"}
        _require(_trial_projection([confirmation]) == [{"candidate_id": "COX_PH_FIXED",
                  "parameters": parameters, "parameter_sha256": sha256_bytes(canonical_json_bytes(parameters))}]
                 and set(confirmation) == {"candidate_id", "parameters", "parameter_sha256",
                     "selected_parent_sha256", "imputation_count", "partition_ids", "recipe_sha256s",
                     "prediction_seal_sha256s", "metric_values", "fold_metric_values", "ranking_metric_values",
                     "ranking_metric_qc", "ranking_evaluation_count", "mean_ibs", "maximum_ibs", "evaluation_units"}
                 and type(confirmation["imputation_count"]) is int and confirmation["imputation_count"] == 20
                 and confirmation["evaluation_units"] == 300 and len(confirmation["fold_metric_values"]) == 15
                 and confirmation["ranking_evaluation_count"] == 3
                 and confirmation["selected_parent_sha256"] == sha256_bytes(canonical_json_bytes(selector["selected_parents"]))
                 and isinstance(confirmation["partition_ids"], list) and len(confirmation["partition_ids"]) == 15
                 and len(set(confirmation["partition_ids"])) == 15
                 and isinstance(confirmation["recipe_sha256s"], list) and len(confirmation["recipe_sha256s"]) == 15
                 and isinstance(confirmation["prediction_seal_sha256s"], list)
                 and len(confirmation["prediction_seal_sha256s"]) == 300,
                 "F2_COX_PH_FORMAL_CONFIRMATION_INVALID")
        recipe_by_id = {row["partition_id"]: row["recipe_sha256"] for row in selector["recipe_set"]["recipes"]}
        _require(confirmation["recipe_sha256s"] == [recipe_by_id.get(key) for key in confirmation["partition_ids"]],
                 "F2_COX_PH_FORMAL_CONFIRMATION_RECIPE_INVALID")
        for digest in confirmation["prediction_seal_sha256s"]:
            validate_sha256(digest, "f2.cox_ph.confirmation_prediction")
        return
    if family == "FPM_TVC_SET_A":
        _require(
            trace == {}
            and search_evaluation_unit_count == 20
            and selected_spec
            == {
                "family": "FPM_TVC_SET_A",
                "selected_parents": selector["selected_parents"],
                "df": science["fpm"]["set_a_df"],
                "tvc_parent": "AST_ALT",
            },
            "F2_FPM_SELECTED_SPEC_MISMATCH",
        )
        return

    from .f2_kernel import _rank_trials, _v20_owner_sha, candidate_trials

    if family in {"RSF", "GBM_COX", "XGBOOST_COX"}:
        _require(
            isinstance(trace, dict)
            and set(trace)
            == {
                "S1",
                "S2",
                "S3A",
                "S3B1",
                "S3B2",
                "SEED_AUDIT",
                "CENTER_STRESS",
            },
            "F2_FROZEN_TRIAL_TRACE_SET_INVALID",
        )
        budget = f2["search_budgets"][family]
        initial = {
            phase: candidate_trials(
                family,
                phase,
                budget[f"{phase.lower()}_trials"],
                f2["search_spaces"][family],
                f2["candidate_sequence"],
                science["modeling_seed_policy"]["sampler"],
            )
            for phase in ("S1", "S2")
        }
        for phase in ("S1", "S2"):
            expected = [
                {
                    "candidate_id": row["trial_id"],
                    "parameters": row["parameters"],
                    "parameter_sha256": row["parameter_sha256"],
                }
                for row in initial[phase]
            ]
            _require(
                _trial_projection(trace[phase]) == expected
                and all(
                    row["parameter_sha256"] == _v20_owner_sha(row["parameters"])
                    for row in trace[phase]
                ),
                f"F2_{family}_{phase}_CANDIDATE_SEQUENCE_MISMATCH",
            )
        initial_rows = trace["S2"]
        _validate_rank_boundary(initial_rows, 3)
        _validate_rank_boundary(trace["S3A"], 2)
        _validate_rank_boundary(trace["S3B1"], 1)
        expected_s3a = _trial_projection(_rank_trials(initial_rows)[:3])
        expected_s3b1 = _trial_projection(_rank_trials(trace["S3A"])[:2])
        expected_s3b2 = _trial_projection(_rank_trials(trace["S3B1"])[:1])
        _require(
            _trial_projection(trace["S3A"]) == expected_s3a
            and _trial_projection(trace["S3B1"]) == expected_s3b1
            and _trial_projection(trace["S3B2"]) == expected_s3b2,
            f"F2_{family}_PROMOTION_MISMATCH",
        )
        winner = trace["S3B2"][0]
        expected_selected = {
            "family": family,
            "candidate_id": winner["candidate_id"],
            "parameters": winner["parameters"],
            "selection_metric": "IBS_0_24",
            "selection_stage": "S3B2",
        }
        if family == "GBM_COX":
            expected_selected["selected_trees"] = winner.get(
                "selected_trees_median"
            )
        if family == "XGBOOST_COX":
            expected_selected["selected_rounds"] = winner.get(
                "selected_rounds_median"
            )
        _require(
            selected_spec == expected_selected,
            f"F2_{family}_SELECTED_SPEC_RECONSTRUCTION_MISMATCH",
        )
        return

    _require(family == "COXTIME_SET_A", "F2_NONELASTIC_FAMILY_INVALID")
    _require(
        isinstance(trace, dict)
        and set(trace) == {"S1", "S2", "S3A", "S3B1", "S3B2"},
        "F2_COXTIME_TRIAL_TRACE_SET_INVALID",
    )
    candidates = list(f2["coxtime"]["candidates"])
    _require(
        [row["parameters"] for row in trace["S1"]] == candidates
        and [row["candidate_id"] for row in trace["S1"]]
        == [row["candidate_id"] for row in candidates]
        and all(
            row.get("candidate_config_sha256")
            == row["parameters"]["candidate_config_sha256"]
            and row.get("parameter_sha256")
            == sha256_bytes(canonical_json_bytes(row["parameters"]))
            for row in trace["S1"]
        ),
        "F2_COXTIME_CANDIDATE_SEQUENCE_MISMATCH",
    )
    _validate_rank_boundary(trace["S1"], 4)
    _validate_rank_boundary(trace["S2"], 2)
    _validate_rank_boundary(trace["S3A"], 2)
    _validate_rank_boundary(trace["S3B1"], 1)
    expected_s2 = _trial_projection(_rank_trials(trace["S1"])[:4])
    expected_s3a = _trial_projection(_rank_trials(trace["S2"])[:2])
    expected_s3b1 = _trial_projection(_rank_trials(trace["S3A"])[:2])
    expected_s3b2 = _trial_projection(_rank_trials(trace["S3B1"])[:1])
    _require(
        _trial_projection(trace["S2"]) == expected_s2
        and _trial_projection(trace["S3A"]) == expected_s3a
        and _trial_projection(trace["S3B1"]) == expected_s3b1
        and _trial_projection(trace["S3B2"]) == expected_s3b2,
        "F2_COXTIME_PROMOTION_MISMATCH",
    )
    winner = trace["S3B2"][0]
    _require(
        selected_spec
        == {
            "family": "COXTIME_SET_A",
            "candidate_id": winner["candidate_id"],
            "parameters": winner["parameters"],
            "locked_epoch": winner.get("locked_epoch"),
            "selection_metric": "IBS_0_24",
            "selection_stage": "S3B2",
        },
        "F2_COXTIME_SELECTED_SPEC_RECONSTRUCTION_MISMATCH",
    )


def _local_outer_metric(
    value: Mapping[str, Any],
    fold: int,
    final_execution: Mapping[str, Any],
    expected_model_input: Mapping[str, Any],
    local_f1_response: Mapping[str, Any],
) -> dict[str, Any]:
    """Recompute the final held-out IBS at the local response boundary."""

    _require(
        isinstance(local_f1_response, Mapping)
        and set(local_f1_response)
        == {"binding_contract", "lineage", "response_csv"}
        and isinstance(local_f1_response["binding_contract"], Mapping)
        and isinstance(local_f1_response["lineage"], Mapping)
        and isinstance(local_f1_response["response_csv"], bytes),
        "F2_LOCAL_RESPONSE_REPLAY_INPUT_INVALID",
    )
    contract = dict(local_f1_response["binding_contract"])
    observed_lineage = dict(local_f1_response["lineage"])
    response_csv = local_f1_response["response_csv"]
    lineage = expected_model_input.get("lineage")
    _require(
        isinstance(lineage, Mapping)
        and all(lineage.get(key) == value for key, value in observed_lineage.items())
        and lineage.get("f1_binding_contract_sha256")
        == sha256_bytes(canonical_json_bytes(contract))
        and lineage.get("f1_response_seal_sha256")
        == sha256_bytes(response_csv),
        "F2_LOCAL_RESPONSE_REPLAY_LINEAGE_MISMATCH",
    )
    outer_rows = [
        row
        for row in contract.get("registry", {}).get("outer", [])
        if row.get("outer_fold") == fold
    ]
    expected_outer = [
        row
        for row in expected_model_input.get("model_partitions", [])
        if row.get("kind") == "OUTER"
    ]
    _require(
        len(outer_rows) == len(expected_outer) == 1,
        "F2_LOCAL_RESPONSE_REPLAY_PARTITION_INVALID",
    )
    outer = outer_rows[0]
    expected = expected_outer[0]
    from .f2_kernel import (
        _center_stratified_evaluation_context,
        _evaluate_prediction_seal,
        _response_rows,
        _write_response_subset,
    )

    fields, by_id = _response_rows(response_csv)
    fit_response = _write_response_subset(
        fields, by_id, list(outer["analysis_ids"]), None
    )
    evaluation_response = _write_response_subset(
        fields, by_id, list(outer["validation_ids"]), None
    )
    _require(
        expected.get("partition_id") == outer.get("partition_id")
        and expected.get("fit_ids_sha256") == fit_response["row_ids_sha256"]
        and expected.get("fit_count") == fit_response["row_count"]
        and expected.get("fit_event_count") == fit_response["event_count"]
        and expected.get("fit_response_sha256") == fit_response["sha256"]
        and expected.get("fit_response_size_bytes") == fit_response["size_bytes"]
        and expected.get("evaluation_ids_sha256")
        == evaluation_response["row_ids_sha256"]
        and expected.get("evaluation_count") == evaluation_response["row_count"]
        and expected.get("evaluation_response_sha256")
        == evaluation_response["sha256"]
        and expected.get("evaluation_response_size_bytes")
        == evaluation_response["size_bytes"]
        and final_execution.get("evaluation_response_sha256")
        == evaluation_response["sha256"],
        "F2_LOCAL_RESPONSE_REPLAY_PARTITION_MISMATCH",
    )
    prediction_payload = {
        "schema_version": "1.0.0",
        "kind": "PADML_F2_PREDICTION_MATRIX",
        "patient_ids": [row["Patient_ID"] for row in value["monthly_oof"]["predictions"]],
        "horizons": list(value["monthly_oof"]["horizons"]),
        "survival": [row["survival"] for row in value["monthly_oof"]["predictions"]],
    }
    return _evaluate_prediction_seal(
        {
            "status": "SEALED",
            "payload": prediction_payload,
            "sha256": sha256_bytes(canonical_json_bytes(prediction_payload)),
        },
        fit_response=evaluation_response,
        evaluation_response=evaluation_response,
        evaluation_context=_center_stratified_evaluation_context(
            evaluation_response,
            prediction_payload["patient_ids"],
            [str(value["heldout_center"])] * len(prediction_payload["patient_ids"]),
        ),
    )


def _replay_local_outer_metric(
    value: Mapping[str, Any],
    fold: int,
    final_execution: Mapping[str, Any],
    expected_model_input: Mapping[str, Any],
    local_f1_response: Mapping[str, Any],
) -> None:
    metric = _local_outer_metric(value, fold, final_execution, expected_model_input, local_f1_response)
    _require(
        final_execution.get("ibs_0_24") == metric["ibs_0_24"]
        and final_execution.get("metric_set_sha256")
        == sha256_bytes(canonical_json_bytes([metric["ibs_0_24"]]))
        and final_execution.get("metric_prediction_seal_sha256")
        == metric["prediction_sha256"]
        and final_execution.get("metric_qc") == metric["ipcw_qc"],
        "F2_LOCAL_OUTER_METRIC_REPLAY_MISMATCH",
    )


def _validate_f2_model(
    request: dict[str, Any],
    value: Any,
    authority_slice: dict[str, Any],
    route_profiles: Mapping[str, Any],
    expected_model_input: Mapping[str, Any] | None,
    local_f1_response: Mapping[str, Any] | None,
    expected_selector_search: Mapping[str, Any] | None = None,
    expected_selector_primary: Mapping[str, Any] | None = None,
    expected_selector_result: Mapping[str, Any] | None = None,
) -> None:
    _require(isinstance(value, dict), "F2_MODEL_PAYLOAD_INVALID")
    if expected_selector_result is not None:
        from .capsule import result_reuse_receipt, selector_result_projection, validate_selector_result_source

        _require(expected_selector_search is None and expected_selector_primary is None
                 and isinstance(expected_model_input, Mapping), "F2_SELECTOR_REUSE_MODE_CONFLICT")
        validate_selector_result_source(expected_selector_result, request, expected_model_input)
        _require(sha256_bytes(canonical_json_bytes(selector_result_projection(value)))
                 == expected_selector_result["preserved_value_sha256"]
                 and canonical_json_bytes(value.get("result_reuse"))
                 == canonical_json_bytes(result_reuse_receipt(expected_selector_result)),
                 "F2_REUSED_SELECTOR_WRITEBACK_FORBIDDEN")
        expected_selector_search = value.get("search_trace", {}).get("search_reuse")
    elif expected_selector_primary is not None:
        from .capsule import primary_reuse_receipt, selector_primary_projection, validate_selector_primary_source

        _require(expected_selector_search is None and isinstance(expected_model_input, Mapping),
                 "F2_SELECTOR_REUSE_MODE_CONFLICT")
        validate_selector_primary_source(expected_selector_primary, request, expected_model_input)
        _require(sha256_bytes(canonical_json_bytes(selector_primary_projection(value)))
                 == expected_selector_primary["primary_sha256"]
                 and canonical_json_bytes(value.get("primary_reuse"))
                 == canonical_json_bytes(primary_reuse_receipt(expected_selector_primary)),
                 "F2_SENSITIVITY_PRIMARY_WRITEBACK_FORBIDDEN")
        expected_selector_search = expected_selector_primary["selector_search_reuse"]
    else:
        _require("primary_reuse" not in value, "F2_PRIMARY_REUSE_SOURCE_MISSING")
    _require(expected_selector_result is not None or "result_reuse" not in value,
             "F2_SELECTOR_RESULT_REUSE_SOURCE_MISSING")
    coordinates = {row["axis"]: row["value"] for row in request["plan"]["coordinates"]}
    fold, family = coordinates.get("outer_fold"), coordinates.get("family")
    _require(
        isinstance(expected_model_input, Mapping)
        and value.get("model_input") == dict(expected_model_input)
        and expected_model_input.get("fold") == fold
        and expected_model_input.get("lineage") == value.get("lineage")
        and expected_model_input.get("registered_input_identity")
        == value.get("lineage", {}).get("f1_registered_partition_identity"),
        "F2_MODEL_INPUT_EXPECTATION_MISMATCH",
    )
    science = authority_slice["science"]
    f2 = science["f2_model_development"]
    execution = execution_result_contract(request["plan"])
    _require(
        value.get("schema_version") == "1.0.0"
        and value.get("artifact_kind") == "F2_MODEL_DEVELOPMENT"
        and value.get("status") == "PASS"
        and value.get("fold") == fold
        and value.get("heldout_center") == science["population"]["validation_centers"][fold - 1]
        and value.get("family") == family
        and value.get("backend") == "CPU"
        and value.get("threads") == execution["threads"]
        and value.get("pool_workers") == execution["pool_workers"]
        and value.get("engine_threads") == execution["engine_threads"]
        and value.get("retained_model_binary_count") == 0
        and value.get("heldout_outcome_read_count_for_selection") == 0
        and value.get("typed_terminal") == "PASS",
        "F2_MODEL_HEADER_INVALID",
    )
    for field in (
        "row_universe_sha256",
        "selector_evidence_sha256",
        "search_trace_sha256",
        "selected_spec_sha256",
        "prediction_sha256",
        "monthly_oof_sha256",
        "stopping_and_convergence_sha256",
        "numeric_qc_sha256",
        "science_contract_sha256",
        "f1_library_summary_sha256",
    ):
        validate_sha256(value.get(field), f"f2.{field}")
    if family in {"XGBOOST_COX", "COXTIME_SET_A"}:
        validate_sha256(
            value.get("execution_graph_sha256"),
            "f2.execution_graph_sha256",
        )
    row_universe = _validate_model_row_universe(value, expected_model_input)
    checkpoint = f2.get("selector_review_checkpoint")
    _require(isinstance(checkpoint, dict), "F2_SELECTOR_REVIEW_AUTHORITY_MISSING")
    from .f2_kernel import (
        _model_family_design_binding,
        _selector_evidence_science_identity,
        predictor_contract,
    )

    predictors = predictor_contract(
        Path(__file__).resolve().parent,
        authority_slice,
    )
    from ._science_authority import execution_mode, selected_route_profiles, validate_route_profile_map

    route_profiles = validate_route_profile_map(
        route_profiles, require_formal=True
    )
    # A model can reuse an earlier selector computed at another capacity.
    # Validate its retained execution facts, not this model's or the reader's CPU.
    selector_value = value.get("selector_evidence")
    _require(isinstance(selector_value, Mapping), "F2_SELECTOR_EVIDENCE_INVALID")
    primary_reused = (family != "ELASTIC_NET_COX" or expected_selector_primary is not None
                      or expected_selector_result is not None)
    selector_workers = (selector_value.get("primary_execution", {}).get("pool_workers")
                        if primary_reused else execution["pool_workers"])
    route_profiles = selected_route_profiles(pool_workers=selector_workers)
    elastic_profile = route_profiles["F2_ELASTIC"]["profile"]
    _require(elastic_profile is not None, "F2_PRIMARY_ROUTE_DEFERRED")
    selector_primary_execution = {
        "execution_mode": execution_mode(elastic_profile),
        "threads": elastic_profile["internal_threads"],
        "pool_workers": elastic_profile["pool_workers"],
        "engine_threads": elastic_profile["engine_threads"],
    }
    selector_profile_records: dict[str, Any] = {}
    for method, route_name in (
        ("MRMRE", "F2_SELECTOR_MRMRE"),
        ("BORUTA", "F2_SELECTOR_BORUTA"),
    ):
        if family != "ELASTIC_NET_COX" or expected_selector_result is not None:
            methods = selector_value.get("sensitivity_evidence", {}).get("methods", {})
            method_workers = methods.get(method, {}).get("execution", {}).get("pool_workers")
        else:
            method_workers = execution["pool_workers"]
        record = selected_route_profiles(pool_workers=method_workers)[route_name]
        profile = record["profile"]
        selector_profile_records[method] = {
            "admission_identity": record["admission_identity"],
            "execution": (
                None
                if profile is None
                else {
                    "execution_mode": execution_mode(profile),
                    "threads": profile["internal_threads"],
                    "pool_workers": profile["pool_workers"],
                    "engine_threads": profile["engine_threads"],
                }
            ),
            "selection": record["selection"],
        }
    selector = _validate_selector_evidence(
        value.get("selector_evidence"),
        f2["selector_contract"],
        f2["selector_sensitivity"],
        checkpoint,
        predictors,
        expected_model_input,
        selector_primary_execution,
        selector_profile_records,
    )
    _require(
        _selector_evidence_science_identity(selector)
        == value["selector_evidence_sha256"],
        "F2_SELECTOR_EVIDENCE_INVALID",
    )
    family_design_binding = _model_family_design_binding(
        family,
        selector,
        predictors,
    )
    _require(
        value.get("family_design_binding") == family_design_binding,
        "F2_FAMILY_DESIGN_BINDING_INVALID",
    )
    predictions = value.get("predictions")
    horizons = value.get("prediction_horizons")
    _require(
        horizons == science["horizons_months"]
        and isinstance(predictions, list)
        and len(predictions) == row_universe["heldout_count"],
        "F2_MODEL_PREDICTION_DENOMINATOR_INVALID",
    )
    observed_ids: list[str] = []
    for row in predictions:
        _require(isinstance(row, dict) and set(row) == {"Patient_ID", "survival"}, "F2_MODEL_PREDICTION_ROW_INVALID")
        observed_ids.append(row["Patient_ID"])
        survival = row["survival"]
        _require(
            isinstance(row["Patient_ID"], str)
            and row["Patient_ID"]
            and isinstance(survival, list)
            and len(survival) == len(horizons)
            and all(_finite_number(item) and 0 <= item <= 1 for item in survival)
            and all(left + 1e-10 >= right for left, right in zip(survival, survival[1:])),
            "F2_MODEL_PREDICTION_VALUE_INVALID",
        )
    _validate_prediction_scientific_variation(predictions)
    prediction_payload = {
        "schema_version": "1.0.0",
        "kind": "PADML_F2_PREDICTION_MATRIX",
        "patient_ids": observed_ids,
        "horizons": horizons,
        "survival": [row["survival"] for row in predictions],
    }
    _require(
        len(set(observed_ids)) == len(observed_ids)
        and sha256_bytes(canonical_json_bytes(observed_ids)) == row_universe["heldout_ids_sha256"],
        "F2_MODEL_PREDICTION_ROW_IDENTITY_INVALID",
    )
    _require(
        sha256_bytes(canonical_json_bytes(prediction_payload))
        == value["prediction_sha256"],
        "F2_MODEL_PREDICTION_SEAL_INVALID",
    )
    monthly_contract = f2.get("f4_monthly_oof_handoff")
    monthly_oof = value.get("monthly_oof")
    _require(
        isinstance(monthly_contract, dict)
        and isinstance(monthly_oof, dict)
        and set(monthly_oof)
        == {"schema_version", "classification", "horizons", "predictions"}
        and monthly_oof.get("schema_version") == "MONTHLY_OOF_V1"
        and monthly_oof.get("classification") == "PRIVATE_SCIENCE"
        and monthly_oof.get("horizons")
        == monthly_contract.get("horizons_months")
        == list(range(37))
        and isinstance(monthly_oof.get("predictions"), list)
        and len(monthly_oof["predictions"]) == len(predictions),
        "F2_MONTHLY_OOF_CONTRACT_INVALID",
    )
    projection_indices = [monthly_oof["horizons"].index(value) for value in horizons]
    monthly_matrix: list[list[float]] = []
    for monthly_row, registered_row in zip(
        monthly_oof["predictions"], predictions, strict=True
    ):
        _require(
            isinstance(monthly_row, dict)
            and set(monthly_row) == {"Patient_ID", "survival"}
            and monthly_row.get("Patient_ID") == registered_row["Patient_ID"]
            and isinstance(monthly_row.get("survival"), list)
            and len(monthly_row["survival"]) == 37
            and monthly_row["survival"][0] == 1.0
            and all(
                _finite_number(item) and 0 <= item <= 1
                for item in monthly_row["survival"]
            )
            and all(
                left + 1e-10 >= right
                for left, right in zip(
                    monthly_row["survival"], monthly_row["survival"][1:]
                )
            )
            and [monthly_row["survival"][index] for index in projection_indices]
            == registered_row["survival"],
            "F2_MONTHLY_OOF_PROJECTION_MISMATCH",
        )
        monthly_matrix.append(monthly_row["survival"])
    monthly_payload = {
        "schema_version": "1.0.0",
        "kind": "PADML_F2_PREDICTION_MATRIX",
        "patient_ids": observed_ids,
        "horizons": monthly_oof["horizons"],
        "survival": monthly_matrix,
    }
    _require(
        sha256_bytes(canonical_json_bytes(monthly_payload))
        == value["monthly_oof_sha256"],
        "F2_MONTHLY_OOF_IDENTITY_INVALID",
    )
    trace = value.get("search_trace")
    _require(
        isinstance(trace, dict)
        and sha256_bytes(canonical_json_bytes(trace)) == value["search_trace_sha256"],
        "F2_SEARCH_TRACE_IDENTITY_INVALID",
    )
    science_trace = trace
    if expected_selector_search is not None:
        from .capsule import validate_selector_search_source

        if expected_selector_primary is None and expected_selector_result is None:
            validate_selector_search_source(expected_selector_search, request, expected_model_input)
        _require(
            family == "ELASTIC_NET_COX" and trace.get("search_reuse") == expected_selector_search
            and sha256_bytes(canonical_json_bytes(trace.get("derivation_records")))
            == expected_selector_search["derivation_records_sha256"],
            "F2_REUSED_SEARCH_SOURCE_MISMATCH",
        )
        science_trace = {key: item for key, item in trace.items() if key != "search_reuse"}
    else:
        _require("search_reuse" not in trace, "F2_REUSED_SEARCH_SOURCE_UNEXPECTED")
    final_execution = _validate_registered_partition_execution(
        value,
        fold,
        family,
        expected_model_input,
        expected_selector_search,
    )
    if local_f1_response is not None:
        _replay_local_outer_metric(
            value,
            fold,
            final_execution,
            expected_model_input,
            local_f1_response,
        )
    elastic_facts: tuple[
        dict[tuple[int, int], int], int, dict[str, int]
    ] | None = None
    if family == "ELASTIC_NET_COX":
        elastic_facts = _elastic_registered_facts(
            expected_model_input,
            checkpoint,
            predictors,
        )
        _validate_elastic_search_trace(
            science_trace,
            selector,
            f2["selector_contract"],
            value.get("search_evaluation_unit_count"),
            *elastic_facts,
            predictors=predictors,
            expected_selector_search=expected_selector_search,
        )
    if family in {"RSF", "GBM_COX", "XGBOOST_COX"}:
        budget = f2["search_budgets"][family]
        _require(
            isinstance(trace, dict)
            and set(trace) >= {"S1", "S2", "S3A", "S3B1", "S3B2", "SEED_AUDIT", "CENTER_STRESS"}
            and len(trace["SEED_AUDIT"]) == 2
            and len(trace["CENTER_STRESS"]) == 2
            and sum(row.get("evaluation_units", -1) for row in trace["SEED_AUDIT"]) == 150
            and sum(row.get("evaluation_units", -1) for row in trace["CENTER_STRESS"]) == 50
            and value.get("search_evaluation_unit_count") == budget["standard_outer_units"],
            "F2_STANDARD_OUTER_BUDGET_INVALID",
        )
    if family == "XGBOOST_COX":
        _validate_python_family_execution_budget(value, trace, family)
        graph = value.get("execution_graph")
        parent_response_evaluations = sum(
            row["evaluation_count"]
            for row in value["registered_partition_execution"]["partitions"]
        ) + sum(
            len(row["fold_metric_values"]) + row["ranking_evaluation_count"]
            for values in trace.values() for row in values
        )
        _require(
            graph
            == {
                "schema_version": "1.0.0",
                "family": "XGBOOST_COX",
                "search_budget_evaluation_unit_count": 1520,
                "parent_response_evaluation_count": parent_response_evaluations,
                "response_free_function_fit_count": 1450,
                "locked_refit_fit_count": 1520,
                "total_fit_count": 2970,
                "parent_evaluation_owner": "UNIQUE_LOCAL_PARENT",
            }
            and sha256_bytes(canonical_json_bytes(graph))
            == value["execution_graph_sha256"],
            "F2_XGBOOST_GRAPH_INVALID",
        )
    if family == "COXTIME_SET_A":
        _validate_python_family_execution_budget(value, trace, family)
        graph = value.get("execution_graph")
        parent_response_evaluations = sum(
            row["evaluation_count"]
            for row in value["registered_partition_execution"]["partitions"]
        ) + sum(
            len(row["fold_metric_values"]) + row["ranking_evaluation_count"]
            for values in trace.values() for row in values
        )
        s3b2 = trace.get("S3B2") if isinstance(trace, dict) else None
        _require(
            value.get("search_evaluation_unit_count") == 830
            and isinstance(s3b2, list)
            and len(s3b2) == 1
            and s3b2[0].get("evaluation_units") == 300
            and s3b2[0].get("validation_curve_count") == 300
            and s3b2[0].get("locked_refit_dispatch_count") == 300
            and isinstance(graph, dict)
            and graph
            == {
                "schema_version": "1.0.0",
                "family": "COXTIME_SET_A",
                "search_budget_evaluation_unit_count": 830,
                "parent_response_evaluation_count": parent_response_evaluations,
                "response_free_function_fit_count": 810,
                "locked_refit_fit_count": 830,
                "total_fit_count": 1640,
                "parent_evaluation_owner": "UNIQUE_LOCAL_PARENT",
                "s3b2_validation_curve_count": 300,
                "s3b2_global_lock_identity_sha256": s3b2[0].get(
                    "global_lock_identity_sha256"
                ),
            }
            and graph["s3b2_global_lock_identity_sha256"]
            == s3b2[0].get("global_lock_identity_sha256")
            and sha256_bytes(canonical_json_bytes(graph))
            == value["execution_graph_sha256"],
            "F2_COXTIME_GRAPH_INVALID",
        )
    selected_spec = value.get("selected_spec")
    _require(sha256_bytes(canonical_json_bytes(selected_spec)) == value["selected_spec_sha256"], "F2_SELECTED_SPEC_IDENTITY_INVALID")
    if family == "ELASTIC_NET_COX":
        _require(
            isinstance(selected_spec, dict)
            and set(selected_spec)
            == {
                "alpha",
                "family",
                "lambda_by_imputation",
                "lambda_upper_bound_by_imputation",
                "ratio_by_imputation",
                "selected_parents",
                "selection_rule",
            }
            and selected_spec.get("alpha") == selector["common_alpha"]
            and selected_spec.get("ratio_by_imputation") == selector["selected_ratio_by_imputation"]
            and selected_spec.get("selected_parents") == selector["selected_parents"]
            and selected_spec.get("lambda_by_imputation")
            == selector["final_refit_lambda_by_imputation"]
            and selected_spec.get("lambda_upper_bound_by_imputation")
            == selector["lambda_upper_bound_by_imputation"]
            and selected_spec.get("selection_rule")
            == "LOSS_THEN_P90_ACTIVE_DF_THEN_SMALLER_ALPHA",
            "F2_SELECTOR_SELECTED_SPEC_MISMATCH",
        )
    else:
        _validate_nonelastic_winner(
            family,
            trace,
            selected_spec,
            selector,
            f2,
            science,
            value.get("search_evaluation_unit_count"),
        )
    stopping = value.get("stopping_and_convergence")
    _require(
        sha256_bytes(canonical_json_bytes(stopping))
        == value["stopping_and_convergence_sha256"],
        "F2_STOPPING_IDENTITY_INVALID",
    )
    if family == "ELASTIC_NET_COX":
        assert elastic_facts is not None
        _validate_elastic_final_stopping(
            stopping,
            selector,
            family_design_binding,
            final_execution["prediction_seal_set_sha256"],
            predictors=predictors,
        )
    elif family in {"COX_PH", "RSF", "GBM_COX", "FPM_TVC_SET_A"}:
        _validate_nonelastic_fit_health(
            family,
            stopping,
            family_design_binding,
            science,
            final_execution["prediction_seal_set_sha256"],
            selected_spec=selected_spec,
            training_count=row_universe["training_count"],
        )
    elif family in {"XGBOOST_COX", "COXTIME_SET_A"}:
        _validate_python_final_fit_health(
            family,
            stopping,
            selected_spec=selected_spec,
            training_count=row_universe["training_count"],
            heldout_count=row_universe["heldout_count"],
            prediction_seal_set_sha256=final_execution[
                "prediction_seal_set_sha256"
            ],
        )
    numeric_qc = value.get("numeric_qc")
    _require(
        isinstance(numeric_qc, dict)
        and numeric_qc.get("prediction_count") == row_universe["heldout_count"] * len(horizons)
        and numeric_qc.get("finite_count") == numeric_qc["prediction_count"]
        and numeric_qc.get("monotonic_violation_count") == 0
        and _finite_number(numeric_qc.get("minimum_survival"))
        and _finite_number(numeric_qc.get("maximum_survival"))
        and 0 <= numeric_qc["minimum_survival"]
        <= numeric_qc["maximum_survival"]
        <= 1
        and sha256_bytes(canonical_json_bytes(numeric_qc)) == value["numeric_qc_sha256"],
        "F2_NUMERIC_QC_INVALID",
    )
    expected_contract = {
        "selector": f2["selector_contract"],
        "selector_sensitivity": (
            f2["selector_sensitivity"]
            if family == "ELASTIC_NET_COX"
            else None
        ),
        "candidate_sequence": f2["candidate_sequence"],
        "multifidelity": f2["multifidelity"],
        "trial_scoring": f2["trial_scoring"],
        "model_seed_policy": science["modeling_seed_policy"]["model"],
        "search_space": f2["search_spaces"].get(family),
        "search_budget": f2["search_budgets"].get(family),
        "coxtime": f2["coxtime"] if family == "COXTIME_SET_A" else None,
        "fpm": science["fpm"] if family == "FPM_TVC_SET_A" else None,
        "family_design_binding": family_design_binding,
        "monthly_oof": monthly_contract,
    }
    _require(sha256_bytes(canonical_json_bytes(expected_contract)) == value["science_contract_sha256"], "F2_SCIENCE_CONTRACT_IDENTITY_INVALID")


def _validate_p2c2t_partition_metrics(
    row: Mapping[str, Any],
    *,
    imputation_count: int,
    expected_partitions: list[Mapping[str, Any]],
    fpm_coefficient_count: int | None = None,
) -> None:
    metrics = row.get("partition_metrics")
    pooled = row.get("pooled_metric_values")
    pooled_qc = row.get("pooled_metric_qc")
    pooled_count = 5 if row.get("component") == "CENTER_BLOCKED_STRESS" else 1
    _require(
        isinstance(metrics, list)
        and isinstance(expected_partitions, list)
        and bool(expected_partitions)
        and all(
            isinstance(partition, Mapping)
            and set(partition)
            == {"evaluation_response_sha256", "partition_id"}
            and isinstance(partition["partition_id"], str)
            and bool(partition["partition_id"])
            for partition in expected_partitions
        )
        and len(metrics) == len(expected_partitions) * imputation_count
        and all(
            isinstance(metric, dict)
            and set(metric)
            == {
                "evaluation_response_sha256",
                "ibs_0_24",
                "imputation",
                "partition_id",
                "prediction_seal_sha256",
            } | ({"stopping"} if fpm_coefficient_count is not None else set())
            and isinstance(metric["partition_id"], str)
            and bool(metric["partition_id"])
            and isinstance(metric["imputation"], int)
            and not isinstance(metric["imputation"], bool)
            and 1 <= metric["imputation"] <= imputation_count
            and _finite_number(metric["ibs_0_24"])
            and metric["ibs_0_24"] >= 0
            for metric in metrics
        )
        and [
            (
                metric["partition_id"],
                metric["imputation"],
                metric["evaluation_response_sha256"],
            )
            for metric in metrics
        ]
        == [
            (
                partition["partition_id"],
                imputation,
                partition["evaluation_response_sha256"],
            )
            for partition in expected_partitions
            for imputation in range(1, imputation_count + 1)
        ]
        and row.get("partition_metrics_sha256")
        == sha256_bytes(canonical_json_bytes(metrics))
        and isinstance(pooled, list)
        and len(pooled) == pooled_count
        and all(_finite_number(metric) and metric >= 0 for metric in pooled)
        and isinstance(pooled_qc, list)
        and len(pooled_qc) == pooled_count
        and row.get("mean_ibs")
        == math.fsum(pooled) / len(pooled)
        and row.get("maximum_ibs")
        == max(pooled),
        "F2_P2C2T_PARTITION_METRIC_RECONSTRUCTION_INVALID",
    )
    for qc in pooled_qc:
        _validate_primary_metric_qc(qc)
    for partition in expected_partitions:
        validate_sha256(
            partition["evaluation_response_sha256"],
            "f2.p2c2t.expected_evaluation_response_sha256",
        )
    for metric in metrics:
        validate_sha256(
            metric["evaluation_response_sha256"],
            "f2.p2c2t.metric_evaluation_response_sha256",
        )
        validate_sha256(
            metric["prediction_seal_sha256"],
            "f2.p2c2t.metric_prediction_seal_sha256",
        )
        if fpm_coefficient_count is not None:
            stopping = metric["stopping"]
            _require(
                isinstance(stopping, dict) and set(stopping) == {
                    "coefficient_count", "converged", "covariance_rank", "df", "engine",
                    "fit_evidence", "optimizer", "optimizer_convergence", "tvc_df", "warning_count"}
                and stopping["engine"] == "rstpm2::stpm2"
                and stopping["converged"] is True and stopping["warning_count"] == 0
                and stopping["optimizer"] == "optim" and stopping["optimizer_convergence"] == 0
                and stopping["df"] == 3 and stopping["tvc_df"] == 1
                and type(stopping["coefficient_count"]) is int
                and stopping["coefficient_count"] == stopping["covariance_rank"] == fpm_coefficient_count,
                "F2_FPM_FIT_HEALTH_INVALID",
            )
            _validate_fpm_fit_evidence(stopping["fit_evidence"], [3, 1], fpm_coefficient_count)
    if fpm_coefficient_count is not None:
        _require(row.get("stopping_sha256") == sha256_bytes(canonical_json_bytes(
            [metric["stopping"] for metric in metrics])), "F2_P2C2T_STOPPING_IDENTITY_INVALID")


def _validate_f2_p2c2t(
    request: dict[str, Any],
    value: dict[str, Any],
    component: str,
    authority_slice: dict[str, Any],
    route_profiles: Mapping[str, Any],
    admitted_values: Mapping[str, Mapping[str, Any]],
) -> None:
    science = authority_slice["science"]
    f2 = science["f2_model_development"]
    contract = f2["p2c2t_contract"]
    from ._science_authority import (
        execution_mode,
        validate_route_profile_map,
    )
    from .f2_kernel import compile_p2c2t_registry, predictor_contract

    route_profiles = validate_route_profile_map(
        route_profiles, require_formal=True
    )
    family_routes = {
        "COX_PH": "COX_PH",
        "ELASTIC_NET_COX": "F2_ELASTIC",
        "RSF": "RSF",
        "GBM_COX": "GBM_COX",
        "XGBOOST_COX": "XGBOOST_COX",
        "FPM_TVC_SET_A": "FPM_TVC",
        "COXTIME_SET_A": "COXTIME",
    }

    predictor_contract_value = predictor_contract(
        Path(__file__).resolve().parent,
        authority_slice,
    )
    transform_registry_sha256 = predictor_contract_value[
        "transform_registry_sha256"
    ]
    registry = value.get("task_registry")
    results = value.get("task_results")
    execution = execution_result_contract(request["plan"])
    _require(
        value.get("schema_version") == "1.0.0"
        and value.get("artifact_kind") == "F2_P2C2T"
        and value.get("status") == "PASS"
        and value.get("component") == component
        and value.get("selection_effect") == "NONE"
        and value.get("population_scope") == "OUTER_APPLICATION_RESPONSE_SEALED"
        and value.get("contract") == contract["components"][component]
        and value.get("contract_sha256") == sha256_bytes(canonical_json_bytes(contract))
        and value.get("model_result_count") == 42
        and value.get("outer_heldout_outcome_read_count_for_selection") == 0
        and value.get("threads") == execution["threads"]
        and value.get("pool_workers") == execution["pool_workers"]
        and value.get("engine_threads") == execution["engine_threads"]
        and value.get("typed_terminal") == "PASS"
        and isinstance(registry, dict)
        and isinstance(results, list),
        "F2_P2C2T_RESULT_INVALID",
    )
    dependencies = request["plan"]["depends_on"]
    _require(
        len(dependencies) == 42
        and set(admitted_values) == set(dependencies),
        "F2_P2C2T_ADMITTED_MODEL_SET_INVALID",
    )
    expected_registry = compile_p2c2t_registry(
        component,
        [dict(admitted_values[unit_id]) for unit_id in dependencies],
        request,
        contract,
        f2["coxtime"],
    )
    _require(
        registry == expected_registry,
        "F2_P2C2T_REGISTRY_SOURCE_BINDING_INVALID",
    )
    for field in (
        "model_result_set_sha256",
        "task_registry_sha256",
        "task_result_set_sha256",
        "f1_configuration_index_sha256",
        "f1_response_seal_sha256",
        "result_identity_sha256",
    ):
        validate_sha256(value.get(field), f"f2.p2c2t.{field}")
    registry_without_identity = {key: item for key, item in registry.items() if key != "registry_sha256"}
    _require(
        registry.get("component") == component
        and registry.get("population_scope") == "OUTER_APPLICATION_RESPONSE_SEALED"
        and registry.get("scope_count") == len(registry.get("scopes", []))
        and registry.get("task_count") == len(registry.get("tasks", []))
        and registry.get("registry_sha256") == sha256_bytes(canonical_json_bytes(registry_without_identity))
        and value["task_registry_sha256"] == sha256_bytes(canonical_json_bytes(registry)),
        "F2_P2C2T_REGISTRY_IDENTITY_INVALID",
    )
    tasks = registry["tasks"]
    task_by_id = {row.get("task_id"): row for row in tasks if isinstance(row, dict)}
    _require(len(task_by_id) == len(tasks) and None not in task_by_id, "F2_P2C2T_TASK_SET_INVALID")
    scope_by_id = {
        row.get("scope_id"): row
        for row in registry["scopes"]
        if isinstance(row, dict)
    }
    scope_ids = set(scope_by_id)
    _require(
        len(scope_by_id) == len(registry["scopes"]) and None not in scope_by_id,
        "F2_P2C2T_SCOPE_SET_INVALID",
    )
    model_by_scope_id = {
        f"F{model.get('fold')}::{model.get('family')}": model
        for model in admitted_values.values()
        if isinstance(model, Mapping)
    }
    _require(
        len(model_by_scope_id) == 42
        and set(scope_by_id).issubset(model_by_scope_id),
        "F2_P2C2T_MODEL_SCOPE_SET_INVALID",
    )

    def expected_metric_partitions(task: Mapping[str, Any]) -> list[dict[str, Any]]:
        model_input = model_by_scope_id[task["scope_id"]].get("model_input")
        _require(
            isinstance(model_input, Mapping),
            "F2_P2C2T_MODEL_INPUT_REQUIRED",
        )
        if component == "CENTER_BLOCKED_STRESS":
            partitions = sorted(
                model_input.get("diagnostic_partitions", []),
                key=lambda row: row.get("validation_center"),
            )
        elif component == "LOCAL_PERTURBATION":
            partitions = sorted(
                (
                    row
                    for row in model_input.get("model_partitions", [])
                    if row.get("kind") == "INNER" and row.get("repeat") == 1
                ),
                key=lambda row: row.get("inner_fold"),
            )
        else:
            outer = [
                row
                for row in model_input.get("model_partitions", [])
                if row.get("kind") == "OUTER"
            ]
            _require(len(outer) == 1, "F2_P2C2T_SAMPLE_OUTER_INVALID")
            partitions = [
                {
                    "partition_id": (
                        "P2C2T_SAMPLE_"
                        + sha256_bytes(canonical_json_bytes(dict(task)))[:24]
                    ),
                    "evaluation_response_sha256": outer[0][
                        "evaluation_response_sha256"
                    ],
                }
            ]
        _require(
            len(partitions)
            == (1 if component == "LOCKED_MODEL_SAMPLE_SIZE_DIAGNOSTIC" else 5),
            "F2_P2C2T_METRIC_PARTITION_DOMAIN_INVALID",
        )
        return [
            {
                "partition_id": row["partition_id"],
                "evaluation_response_sha256": row[
                    "evaluation_response_sha256"
                ],
            }
            for row in partitions
        ]

    _require(
        all(
            row.get("scope_id") in scope_ids
            and row.get("fold") in range(1, 7)
            and row.get("family") in science["families"]
            and row.get("selection_effect") == "NONE"
            and row.get("selected_spec_sha256") == sha256_bytes(canonical_json_bytes(row.get("selected_spec")))
            for row in tasks
        ),
        "F2_P2C2T_TASK_CONTRACT_INVALID",
    )
    if component == "CENTER_BLOCKED_STRESS":
        owner = contract["components"][component]
        fixed = set(contract["fixed_formal_families"])
        expected = sum(1 if row["family"] in fixed else 2 for row in registry["scopes"])
        _require(
            owner
            == {
                "covariate_source": "OUTER_APPLICATION_M20",
                "estimand_id": "F2_P2C2T_CENTER_BLOCKED_STRESS",
                "family_change": False,
                "imputations": 20,
                "locked": [
                    "MICE",
                    "PREPROCESSING",
                    "SELECTOR",
                    "TUNING",
                    "TREE_ROUND_EPOCH",
                ],
                "retuning": False,
                "selection_effect": "NONE",
            }
            and registry["scope_count"] == 42
            and registry["task_count"] == expected == 66
            and all(
                row.get("imputations") == 20
                and row.get("task_id", "").endswith("::M20")
                and "conditional_m20" not in row
                for row in tasks
            ),
            "F2_P2C2T_CENTER_REGISTRY_INVALID",
        )
    elif component == "LOCKED_MODEL_SAMPLE_SIZE_DIAGNOSTIC":
        grid = {(seed, fraction) for seed in range(1, 4) for fraction in (0.40, 0.60, 0.80, 1.00)}
        owner = contract["components"][component]
        _require(
            registry["scope_count"] == 42
            and registry["task_count"] == 504
            and all(
                {(row["seed_ordinal"], row["sample_fraction"]) for row in tasks if row["scope_id"] == scope_id} == grid
                for scope_id in scope_ids
            )
            and all(
                row.get("imputations") == 20
                and row.get("nesting_strata") == "PRE_REGISTERED_PRIVATE_ID_REGISTRY"
                and row.get("forbidden_rerun") == owner["forbidden_rerun"]
                for row in tasks
            ),
            "F2_P2C2T_SAMPLE_SIZE_REGISTRY_INVALID",
        )
    else:
        allowed = set(contract["local_registry_families"])
        owner = contract["components"][component]
        _require(
            registry["scope_count"] == 24
            and registry.get("candidate_rule") == owner["candidate_rule"]
            and registry.get("parameter_order") == owner["parameter_order"]
            and registry.get("deduplicate") is True
            and registry.get("percentage_perturbation") == "FORBIDDEN"
            and registry.get("boundary_expansion") == "FORBIDDEN"
            and registry.get("retuning") is False
            and all(row["family"] in allowed and row.get("imputations") == 20 for row in tasks)
            and all(
                isinstance(row.get("locked_registry_order_index"), int)
                and isinstance(row.get("candidate_registry_order_index"), int)
                and row["locked_registry_order_index"] >= 1
                and row["candidate_registry_order_index"] >= 1
                and abs(row["candidate_registry_order_index"] - row["locked_registry_order_index"]) == 1
                and isinstance(row.get("candidate_registry_candidate_id"), str)
                and row["candidate_registry_candidate_id"]
                and row.get("candidate_value")
                == (
                    row["selected_spec"].get("candidate_id")
                    if row["parameter_name"] == "candidate_id"
                    else row["selected_spec"]["parameters"].get(row["parameter_name"])
                )
                for row in tasks
            )
            and all(
                len({row["selected_spec_sha256"] for row in tasks if row["scope_id"] == scope_id})
                == sum(row["scope_id"] == scope_id for row in tasks)
                for scope_id in scope_ids
            )
            and all(1 <= sum(item["scope_id"] == scope_id for item in tasks) <= 8 for scope_id in scope_ids),
            "F2_P2C2T_LOCAL_REGISTRY_INVALID",
        )
    result_by_id = {row.get("task_id"): row for row in results if isinstance(row, dict)}
    _require(set(result_by_id) == set(task_by_id) and len(result_by_id) == len(results), "F2_P2C2T_RESULT_TASK_SET_INVALID")
    for task_id, row in result_by_id.items():
        task = task_by_id[task_id]
        _validate_p2c2t_partition_metrics(
            row,
            imputation_count=task["imputations"],
            expected_partitions=expected_metric_partitions(task),
            fpm_coefficient_count=(
                sum(len(row["columns"]) for row in model_by_scope_id[task["scope_id"]]
                    ["family_design_binding"]["ordered_parent_column_map"])
                + sum(science["fpm"]["set_a_df"]) + 1
                if task["family"] == "FPM_TVC_SET_A" else None
            ),
        )
        route_record = route_profiles[family_routes[task["family"]]]
        profile = route_record["profile"]
        _require(profile is not None, "F2_P2C2T_ROUTE_PROFILE_DEFERRED")
        expected_task_execution = {
            "execution_mode": execution_mode(profile),
            **execution,
        }
        scope = scope_by_id[task["scope_id"]]
        design_source = scope.get("design_source")
        design_binding = row.get("family_design_binding")
        transformed = task["family"] in {
            "ELASTIC_NET_COX",
            "COX_PH",
            "FPM_TVC_SET_A",
        }
        expected_recipe_count = (
            1
            if component == "LOCKED_MODEL_SAMPLE_SIZE_DIAGNOSTIC"
            else 5
        )
        recipes = (
            design_binding.get("recipes")
            if isinstance(design_binding, dict)
            else None
        )
        _require(
            row.get("status") == "PASS"
            and row.get("component") == component
            and row.get("scope_id") == task["scope_id"]
            and row.get("family") == task["family"]
            and row.get("fold") == task["fold"]
            and row.get("task_contract_sha256") == sha256_bytes(canonical_json_bytes(task))
            and row.get("selected_spec_sha256") == task["selected_spec_sha256"]
            and row.get("model_selected_spec_sha256")
            == scope["selected_spec_sha256"]
            and isinstance(design_source, dict)
            and row.get("selected_parent_sha256")
            == design_source.get("selected_parent_sha256")
            and row.get("selector_evidence_sha256")
            == design_source.get("selector_evidence_sha256")
            and row.get("selection_effect") == "NONE"
            and row.get("expected_fit_count", 0) > 0
            and row.get("executed_fit_count") == row["expected_fit_count"]
            and _finite_number(row.get("mean_ibs"))
            and _finite_number(row.get("maximum_ibs"))
            and row["maximum_ibs"] >= row["mean_ibs"] >= 0
            and row.get("outer_heldout_outcome_read_count_for_selection") == 0
            and {
                key: row.get(key)
                for key in (
                    "execution_mode",
                    "threads",
                    "pool_workers",
                    "engine_threads",
                )
            }
            == expected_task_execution
            and row.get("admission_identity")
            == route_record["admission_identity"]
            and row.get("finite") is True
            and row.get("typed_terminal") == "PASS"
            and "Patient_ID" not in str(row)
            and not _contains_absolute_path(row),
            "F2_P2C2T_TASK_RESULT_INVALID",
        )
        _require(
            isinstance(design_binding, dict)
            and set(design_binding)
            == {
                "mode",
                "transform_registry_sha256",
                "continuous_policy",
                "categorical_policy",
                "scaling",
                "recipe_count",
                "recipes",
                "recipe_set_sha256",
                "fixed_representation",
                "source_family_design_binding_sha256",
                "source_selector_evidence_sha256",
                "source_selected_parent_sha256",
                "source_registered_input_identity",
                "source_selector_recipe_set_sha256",
                "source_outer_recipe_sha256",
            }
            and design_binding["mode"]
            == ("TRANSFORM_RECIPE" if transformed else "RAW_CANONICAL")
            and design_binding["transform_registry_sha256"]
            == transform_registry_sha256
            and {
                "continuous": design_binding["continuous_policy"],
                "categorical": design_binding["categorical_policy"],
                "scaling": design_binding["scaling"],
            }
            == predictor_contract_value["family_policy"][task["family"]]
            and isinstance(recipes, list)
            and design_binding["recipe_count"]
            == (expected_recipe_count if transformed else 0)
            == len(recipes)
            and design_binding["recipe_set_sha256"]
            == sha256_bytes(canonical_json_bytes(recipes))
            and design_binding["fixed_representation"]
            is (
                transformed
                and component == "LOCKED_MODEL_SAMPLE_SIZE_DIAGNOSTIC"
            )
            and design_binding["source_family_design_binding_sha256"]
            == design_source["family_design_binding_sha256"]
            and design_binding["source_selector_evidence_sha256"]
            == design_source["selector_evidence_sha256"]
            and design_binding["source_selected_parent_sha256"]
            == design_source["selected_parent_sha256"]
            and design_binding["source_registered_input_identity"]
            == design_source["registered_input_identity"]
            and design_binding["source_selector_recipe_set_sha256"]
            == design_source["selector_recipe_set_sha256"]
            and design_binding["source_outer_recipe_sha256"]
            == design_source["outer_recipe"]["recipe_sha256"]
            and all(
                isinstance(recipe, dict)
                and set(recipe)
                == {
                    "consumer_partition_id",
                    "recipe_partition_id",
                    "recipe_sha256",
                    "analysis_view_sha256",
                    "analysis_ids_sha256",
                    "fit_ids_sha256",
                }
                and isinstance(recipe["consumer_partition_id"], str)
                and bool(recipe["consumer_partition_id"])
                and isinstance(recipe["recipe_partition_id"], str)
                and bool(recipe["recipe_partition_id"])
                and isinstance(recipe["recipe_sha256"], str)
                for recipe in recipes
            )
            and len(
                {recipe["consumer_partition_id"] for recipe in recipes}
            )
            == len(recipes)
            and (
                not transformed
                or component == "LOCKED_MODEL_SAMPLE_SIZE_DIAGNOSTIC"
                or all(
                    recipe["consumer_partition_id"]
                    == recipe["recipe_partition_id"]
                    for recipe in recipes
                )
            ),
            "F2_P2C2T_FAMILY_DESIGN_BINDING_INVALID",
        )
        if transformed and component == "LOCAL_PERTURBATION":
            _require(
                recipes == design_source["local_recipe_bindings"],
                "F2_P2C2T_FAMILY_DESIGN_SOURCE_MISMATCH",
            )
        elif transformed and component == "LOCKED_MODEL_SAMPLE_SIZE_DIAGNOSTIC":
            outer_recipe = design_source["outer_recipe"]
            _require(
                len(recipes) == 1
                and all(
                    recipes[0][field] == outer_recipe[field]
                    for field in (
                        "recipe_partition_id",
                        "recipe_sha256",
                        "analysis_view_sha256",
                        "analysis_ids_sha256",
                        "fit_ids_sha256",
                    )
                ),
                "F2_P2C2T_FAMILY_DESIGN_SOURCE_MISMATCH",
            )
        elif transformed:
            _require(
                recipes == design_source["center_recipe_bindings"],
                "F2_P2C2T_FAMILY_DESIGN_SOURCE_MISMATCH",
            )
        for recipe in recipes:
            validate_sha256(
                recipe["recipe_sha256"],
                f"f2.p2c2t.{task_id}.recipe_sha256",
            )
        for field in (
            "partition_metrics_sha256",
            "selected_spec_sha256",
            "selected_parent_sha256",
            "warning_set_sha256",
            "model_selected_spec_sha256",
            "f1_outer_analysis_sha256",
            "f1_outer_application_sha256",
            "selector_evidence_sha256",
        ):
            validate_sha256(row.get(field), f"f2.p2c2t.{task_id}.{field}")
        if component == "LOCKED_MODEL_SAMPLE_SIZE_DIAGNOSTIC":
            validate_sha256(row.get("task_contract_sha256"), f"f2.p2c2t.{task_id}.contract")
            _require(row.get("mice_rerun_summary_sha256") is None, "F2_P2C2T_SAMPLE_SIZE_RERUN_FORBIDDEN")
        if component == "CENTER_BLOCKED_STRESS":
            _require(
                row.get("imputation_count") == 20
                and row.get("expected_fit_count")
                == row.get("executed_fit_count")
                == 100
                and not {
                    "m5_disposition",
                    "m20_upgrade_triggers",
                    "m20_upgraded",
                    "m20_result",
                }.intersection(row),
                "F2_P2C2T_CENTER_M20_RESULT_INVALID",
            )
    _require(
        value.get("expected_scope_count") == value.get("executed_scope_count") == registry["scope_count"]
        and value.get("expected_task_count") == value.get("executed_task_count") == registry["task_count"]
        and value.get("expected_fit_count") == value.get("executed_fit_count") == sum(row["executed_fit_count"] for row in results)
        and value["task_result_set_sha256"] == sha256_bytes(canonical_json_bytes(results)),
        "F2_P2C2T_DENOMINATOR_INVALID",
    )
    config = value.get("f1_configuration_index")
    _require(
        isinstance(config, list)
        and [row.get("fold") for row in config] == list(range(1, 7))
        and value["f1_configuration_index_sha256"] == sha256_bytes(canonical_json_bytes(config)),
        "F2_P2C2T_F1_CONFIGURATION_INDEX_INVALID",
    )
    for row in config:
        validate_sha256(row.get("f1_outer_analysis_sha256"), "f2.p2c2t.f1_outer_analysis_sha256")
        validate_sha256(row.get("f1_outer_application_sha256"), "f2.p2c2t.f1_outer_application_sha256")
    identity = {key: item for key, item in value.items() if key != "result_identity_sha256"}
    _require(value["result_identity_sha256"] == sha256_bytes(canonical_json_bytes(identity)), "F2_P2C2T_RESULT_IDENTITY_INVALID")


def _validate_f2_value(
    request: dict[str, Any],
    data: bytes,
    authority_slice: dict[str, Any],
    route_profiles: Mapping[str, Any],
    expected_model_input: Mapping[str, Any] | None,
    admitted_values: Mapping[str, Mapping[str, Any]],
    consumed_sources: list[dict[str, Any]],
    local_f1_response: Mapping[str, Any] | None,
    expected_selector_search: Mapping[str, Any] | None = None,
    expected_selector_primary: Mapping[str, Any] | None = None,
    expected_selector_result: Mapping[str, Any] | None = None,
) -> None:
    value = strict_json_bytes(data, request["artifacts"][0]["relative_path"])
    _require(isinstance(value, dict), "F2_PAYLOAD_INVALID")
    action = request["plan"]["action"]
    if action == "MODEL_DEVELOPMENT":
        _validate_f2_model(
            request,
            value,
            authority_slice,
            route_profiles,
            expected_model_input,
            local_f1_response,
            expected_selector_search,
            expected_selector_primary,
            expected_selector_result,
        )
        return
    if action == "P2C2T":
        coordinates = {row["axis"]: row["value"] for row in request["plan"]["coordinates"]}
        _validate_f2_p2c2t(
            request,
            value,
            coordinates.get("component"),
            authority_slice,
            route_profiles,
            admitted_values,
        )
        return
    _require(action == "MODEL_CONFIRMATION_AGGREGATE", "F2_PAYLOAD_ACTION_INVALID")
    dependencies = request["plan"]["depends_on"]
    _require(
        len(dependencies) == 45
        and set(admitted_values) == set(dependencies)
        and all(isinstance(admitted_values[unit_id], Mapping) for unit_id in dependencies),
        "F2_CONFIRMATION_ADMITTED_VALUE_SET_INVALID",
    )
    # The local sole-validator rebuilds the aggregate from the exact 42 model
    # and three diagnostic values it already admitted. The worker-produced
    # aggregate is never accepted from shape/self-hash checks alone.
    from .f2_kernel import aggregate_confirmation

    expected = aggregate_confirmation(
        [dict(admitted_values[unit_id]) for unit_id in dependencies[:42]],
        [dict(admitted_values[unit_id]) for unit_id in dependencies[42:]],
        consumed_sources,
    )
    expected.update(execution_result_contract(request["plan"]))
    expected["consumed_sources"] = consumed_sources
    _require(value == expected, "F2_CONFIRMATION_LOCAL_RECONSTRUCTION_MISMATCH")


def _validate_consumed_sources(
    request: dict[str, Any],
    value: dict[str, Any],
    admitted_sources: Mapping[str, Mapping[str, Any]],
) -> list[dict[str, Any]]:
    consumed = value.get("consumed_sources")
    dependencies = request["plan"]["depends_on"]
    _require(
        isinstance(consumed, list)
        and [row.get("unit_id") if isinstance(row, dict) else None for row in consumed]
        == dependencies,
        "LINEAGE_DEPENDENCY_SET_INVALID",
    )
    for row in consumed:
        _require(
            isinstance(row, dict)
            and set(row)
            == {"unit_id", "result_sha256", "artifact_id", "artifact_sha256"},
            "LINEAGE_RECORD_INVALID",
        )
        validate_sha256(row["result_sha256"], f"lineage.{row['unit_id']}.result_sha256")
        validate_sha256(row["artifact_sha256"], f"lineage.{row['unit_id']}.artifact_sha256")
        _require(
            isinstance(row["artifact_id"], str)
            and row["artifact_id"]
            and admitted_sources.get(row["unit_id"]) == row,
            f"LINEAGE_PRODUCER_IDENTITY_MISMATCH:{row['unit_id']}",
        )
    return consumed


def validate_f2_unit_result(
    request: Mapping[str, Any],
    result_source: Path | bytes,
    authority_slice: Mapping[str, Any],
    *,
    route_profiles: Mapping[str, Any] | None = None,
    admitted_sources: Mapping[str, Mapping[str, Any]] | None = None,
    admitted_values: Mapping[str, Mapping[str, Any]] | None = None,
    expected_model_input: Mapping[str, Any] | None = None,
    local_f1_response: Mapping[str, Any] | None = None,
    expected_selector_search: Mapping[str, Any] | None = None,
    expected_selector_primary: Mapping[str, Any] | None = None,
    expected_selector_result: Mapping[str, Any] | None = None,
    authority_mode: str,
) -> dict[str, Any]:
    from ._science_authority import validate_route_profile_map

    validated_route_profiles = validate_route_profile_map(
        route_profiles, require_formal=True
    )
    _require(
        authority_mode in {"LOCAL_SOLE_VALIDATOR", "REMOTE_CANDIDATE"},
        "F2_VALIDATION_AUTHORITY_MODE_INVALID",
    )
    _require(
        authority_mode == "LOCAL_SOLE_VALIDATOR"
        or local_f1_response is None,
        "F2_REMOTE_LOCAL_RESPONSE_FORBIDDEN",
    )
    validated_request = validate_envelope(dict(request))
    _require(
        validated_request["kind"] == "request"
        and validated_request["stage_id"] == "F2",
        "F2_UNIT_REQUEST_INVALID",
    )
    if isinstance(result_source, Path):
        _require(
            result_source.is_absolute()
            and result_source.is_file()
            and not result_source.is_symlink()
            and result_source.resolve(strict=True) == result_source,
            "F2_UNIT_RESULT_PATH_INVALID",
        )
        result_bytes = result_source.read_bytes()
    else:
        _require(isinstance(result_source, bytes), "F2_UNIT_RESULT_SOURCE_INVALID")
        result_bytes = result_source
    entries = read_safe_zip(result_bytes)
    _require("manifest.json" in entries, "F2_UNIT_RESULT_MANIFEST_MISSING")
    manifest_bytes = entries["manifest.json"]
    result = validate_envelope(strict_json_bytes(manifest_bytes, "manifest.json"))
    _require(
        canonical_json_bytes(result) == manifest_bytes,
        "F2_UNIT_RESULT_MANIFEST_NONCANONICAL",
    )
    _require(result["kind"] == "result", "F2_UNIT_RESULT_KIND_INVALID")
    for field in (
        "run_id",
        "stage_id",
        "unit_id",
        "transaction_id",
        "identities",
        "seed",
        "plan",
    ):
        _require(result[field] == validated_request[field], f"F2_UNIT_RESULT_IDENTITY_MISMATCH:{field}")
    result_sha256 = sha256_bytes(result_bytes)
    if result["terminal"]["status"] != "COMPLETED":
        _require(set(entries) == {"manifest.json"}, "F2_NONCOMPLETED_RESULT_HAS_SIDECAR")
        return {
            "status": "NONCOMPLETED",
            "result_sha256": result_sha256,
            "envelope": result,
            "value": None,
            "evidence": None,
        }
    if validated_request["plan"]["action"] == "MODEL_DEVELOPMENT":
        _require(
            authority_mode != "LOCAL_SOLE_VALIDATOR"
            or local_f1_response is not None,
            "F2_LOCAL_MODEL_RESPONSE_REPLAY_REQUIRED",
        )
    _require(
        len(result["artifacts"]) == len(validated_request["artifacts"]) == 1,
        "F2_UNIT_RESULT_ARTIFACT_COUNT_INVALID",
    )
    artifact = result["artifacts"][0]
    expected = validated_request["artifacts"][0]
    _require(
        artifact["artifact_id"] == expected["artifact_id"]
        and artifact["relative_path"] == expected["relative_path"]
        and artifact["classification"] == expected["classification"]
        and artifact["status"] == "OK"
        and set(entries) == {"manifest.json", artifact["relative_path"]},
        "F2_UNIT_RESULT_ARTIFACT_SET_INVALID",
    )
    payload = entries[artifact["relative_path"]]
    _require(
        artifact["size_bytes"] == len(payload)
        and artifact["sha256"] == sha256_bytes(payload),
        "F2_UNIT_RESULT_ARTIFACT_IDENTITY_INVALID",
    )
    value = strict_json_bytes(payload, artifact["relative_path"])
    _require(
        isinstance(value, dict) and canonical_json_bytes(value) == payload,
        "F2_UNIT_RESULT_PAYLOAD_INVALID",
    )
    _require(
        sha256_bytes(canonical_json_bytes(dict(authority_slice)))
        == validated_request["identities"]["authority"],
        "F2_UNIT_AUTHORITY_IDENTITY_INVALID",
    )
    sources = dict(admitted_sources or {})
    _require(
        set(sources) == set(validated_request["plan"]["depends_on"]),
        "F2_ADMITTED_SOURCE_SET_INVALID",
    )
    consumed = _validate_consumed_sources(validated_request, value, sources)
    local_science_replay_sha256 = None
    if local_f1_response is not None:
        _require(
            isinstance(local_f1_response, Mapping)
            and set(local_f1_response)
            == {"binding_contract", "lineage", "response_csv"}
            and isinstance(local_f1_response["binding_contract"], Mapping)
            and isinstance(local_f1_response["lineage"], Mapping)
            and isinstance(local_f1_response["response_csv"], bytes),
            "F2_LOCAL_RESPONSE_REPLAY_INPUT_INVALID",
        )
        local_science_replay_sha256 = sha256_bytes(
            canonical_json_bytes(
                {
                    "binding_contract_sha256": sha256_bytes(
                        canonical_json_bytes(
                            dict(local_f1_response["binding_contract"])
                        )
                    ),
                    "lineage": dict(local_f1_response["lineage"]),
                    "response_seal_sha256": sha256_bytes(
                        local_f1_response["response_csv"]
                    ),
                }
            )
        )
    _validate_f2_value(
        validated_request,
        payload,
        dict(authority_slice),
        validated_route_profiles,
        expected_model_input,
        dict(admitted_values or {}),
        consumed,
        local_f1_response,
        expected_selector_search,
        expected_selector_primary,
        expected_selector_result,
    )
    request_sha256 = sha256_bytes(canonical_json_bytes(validated_request))
    exact_key = unit_exact_key(
        {
            "source_identity": validated_request["identities"]["source"],
            "authority_identity": validated_request["identities"]["authority"],
            "input_identity": validated_request["identities"]["input"],
            "runtime_capability_identity": validated_request["identities"]["runtime"],
            "stage_id": "F2",
            "unit_id": validated_request["unit_id"],
            "transaction_id": validated_request["transaction_id"],
            "plan_identity": validated_request["identities"]["plan"],
            "seed": validated_request["seed"],
            "request_sha256": request_sha256,
        }
    )
    evidence = None
    if authority_mode == "LOCAL_SOLE_VALIDATOR":
        evidence = {
            "schema_version": "1.0.0",
            "kind": "PADML_F2_UNIT_VALIDATION",
            "outcome": "PASS",
            "run_id": validated_request["run_id"],
            "stage_id": "F2",
            "unit_id": validated_request["unit_id"],
            "transaction_id": validated_request["transaction_id"],
            "exact_key_sha256": exact_key,
            "request_sha256": request_sha256,
            "result_sha256": result_sha256,
            "artifact_sha256": artifact["sha256"],
            "authority_sha256": validated_request["identities"]["authority"],
            "consumed_source_set_sha256": sha256_bytes(canonical_json_bytes(consumed)),
            "local_science_replay_sha256": local_science_replay_sha256,
        }
    return {
        "status": (
            "PASS"
            if authority_mode == "LOCAL_SOLE_VALIDATOR"
            else "CANDIDATE_VALID"
        ),
        "result_sha256": result_sha256,
        "science_projection_sha256": science_projection_sha256(value),
        "envelope": result,
        "artifact": artifact,
        "value": value,
        "evidence": evidence,
    }


def admitted_source_record(validated: Mapping[str, Any]) -> dict[str, Any]:
    _require(
        validated.get("status") in {"PASS", "CANDIDATE_VALID"},
        "F2_SOURCE_NOT_ADMITTED",
    )
    envelope = validated["envelope"]
    artifact = validated["artifact"]
    return {
        "unit_id": envelope["unit_id"],
        "result_sha256": validated["result_sha256"],
        "artifact_id": artifact["artifact_id"],
        "artifact_sha256": artifact["sha256"],
    }


def validate_f2_stage_values(
    values: Mapping[str, Mapping[str, Any]],
    authority_slice: Mapping[str, Any],
    *,
    f1_result_sha256: str,
) -> dict[str, Any]:
    from .f2 import canonical_unit_ids

    validate_sha256(f1_result_sha256, "f1_result_sha256")
    expected_keys = canonical_unit_ids()
    _require(
        len(values) == 46 and tuple(values) == expected_keys,
        "F2_STAGE_CANONICAL_KEYSET_ORDER_INVALID",
    )
    families = authority_slice["science"]["families"]
    model_values = [
        value
        for value in values.values()
        if value.get("artifact_kind") == "F2_MODEL_DEVELOPMENT"
    ]
    _require(len(model_values) == 42, "F2_STAGE_MODEL_DENOMINATOR_INVALID")
    expected_grid = {(fold, family) for fold in range(1, 7) for family in families}
    _require(
        {(value["fold"], value["family"]) for value in model_values} == expected_grid,
        "F2_STAGE_MODEL_GRID_INVALID",
    )
    _require(
        {value["lineage"]["f1_approved_result_sha256"] for value in model_values}
        == {f1_result_sha256},
        "F2_STAGE_F1_RESULT_LINEAGE_INVALID",
    )
    for fold in range(1, 7):
        fold_values = [value for value in model_values if value["fold"] == fold]
        _require(
            len({value["selector_evidence_sha256"] for value in fold_values}) == 1,
            f"F2_STAGE_SELECTOR_DRIFT:FOLD_{fold}",
        )
        prediction_sets = [
            {row["Patient_ID"] for row in value["predictions"]}
            for value in fold_values
        ]
        _require(
            all(current == prediction_sets[0] for current in prediction_sets[1:]),
            f"F2_STAGE_HELDOUT_ROW_DRIFT:FOLD_{fold}",
        )
    for family in families:
        family_values = sorted(
            (value for value in model_values if value["family"] == family),
            key=lambda value: value["fold"],
        )
        seen: set[str] = set()
        for value in family_values:
            current = {row["Patient_ID"] for row in value["predictions"]}
            _require(
                not seen.intersection(current),
                f"F2_STAGE_OUTER_PREDICTION_OVERLAP:{family}",
            )
            seen.update(current)
    monthly_set = [
        {
            "fold": value["fold"],
            "family": value["family"],
            "monthly_oof_sha256": value["monthly_oof_sha256"],
        }
        for value in sorted(
            model_values, key=lambda item: (item["fold"], item["family"])
        )
    ]
    monthly_prediction_value_count = sum(
        len(value["monthly_oof"]["predictions"])
        * len(value["monthly_oof"]["horizons"])
        for value in model_values
    )
    diagnostics = [
        value for value in values.values() if value.get("artifact_kind") == "F2_P2C2T"
    ]
    _require(
        len(diagnostics) == 3
        and {value["component"] for value in diagnostics}
        == set(authority_slice["science"]["p2c2t"]),
        "F2_STAGE_DIAGNOSTIC_DENOMINATOR_INVALID",
    )
    confirmation = values.get("model-confirmation")
    _require(
        isinstance(confirmation, dict)
        and confirmation.get("artifact_kind") == "F2_MODEL_CONFIRMATION",
        "F2_STAGE_CONFIRMATION_MISSING",
    )
    value_index = [
        {
            "unit_id": unit_id,
            "artifact_kind": value["artifact_kind"],
            "value_sha256": sha256_bytes(canonical_json_bytes(value)),
        }
        for unit_id, value in values.items()
    ]
    return {
        "schema_version": "1.0.0",
        "kind": "PADML_F2_STAGE_VALIDATION",
        "outcome": "PASS",
        "unit_count": 46,
        "model_count": 42,
        "diagnostic_count": 3,
        "confirmation_count": 1,
        "monthly_oof_model_count": 42,
        "monthly_oof_horizon_count": 37,
        "monthly_oof_prediction_value_count": monthly_prediction_value_count,
        "monthly_oof_set_sha256": sha256_bytes(canonical_json_bytes(monthly_set)),
        "f1_result_sha256": f1_result_sha256,
        "value_index_sha256": sha256_bytes(canonical_json_bytes(value_index)),
        "science_summary_sha256": sha256_bytes(canonical_json_bytes(confirmation)),
    }


__all__ = [
    "admitted_source_record",
    "validate_f2_stage_values",
    "validate_f2_unit_result",
]
