"""A04 fixed outer M20 variants: native MICE -> original model -> held-out risk.

One outer per host, one pool at a time. This is a calculation, not a controller.
The accepted log/donor5 baseline is read; no selector, search or STOP is run.
"""

from __future__ import annotations

import csv
import io
import math
import shutil
from pathlib import Path
from typing import Any, Mapping

from ._science_authority import load_science_authority
from .bundle import (canonical_json_bytes, extract_safe_zip, sha256_bytes,
                     sha256_file, strict_json_bytes, write_deterministic_zip)
from .f2_kernel import (
    _expected_family_parent_column_map, _fit_covariate_member_records,
    _merge_registered_views, _recipe_by_partition, _recipe_training_member_bytes,
    _registered_partition_identity_record, _response_rows, _seal_prediction_matrix,
    _validate_transform_recipe_set, _write_response_subset, predictor_contract, _locked_family_parameters,
)
from .f4 import HORIZONS, _f4_outer_elastic_source, _outer_elastic_parameters
from .f5_application import _audit_json, _new_target, _require, application_context
from .f5_sensitivity import (
    A04_NEW_MICE_VARIANTS, _a04_variant_model_seed, _a04_variant_view_inputs,
    _ablation_component_inputs, _execute_ablation_component, _replay_ablation_component,
    _validate_a04_variant_model_task, execute_a12_total_mice_bundle,
    materialize_a12_total_mice_view,
)
from .runtime import _bounded_ordered_spawn, resolve_pool_workers


VARIANTS = ("LOG_DONOR5", *A04_NEW_MICE_VARIANTS)
_TRANSFORMED = {"COX_PH", "ELASTIC_NET_COX", "FPM_TVC_SET_A"}
_STOCHASTIC = {"RSF", "GBM_COX", "XGBOOST_COX", "COXTIME_SET_A"}


def _frozen(context):
    return context['current_primary']['frozen'] if 'current_primary' in context else context['_f4_inputs']['o_fit_source']


def _parameters(context, layout, imputation):
    if 'current_primary' in context:
        from .f5_a04_current import current_parameter_source
        current=context['current_primary']
        task, recipe=current['templates'][imputation]
        parameters, source, _=current_parameter_source(current, imputation, task, recipe)
        return parameters, source
    family=layout['family']
    parameters, columns=(_outer_elastic_parameters(_f4_outer_elastic_source(layout['model']),
        layout['outer_fold'], imputation) if family=='ELASTIC_NET_COX'
        else (dict(layout['model']['selected_spec']),None))
    return parameters, {'selected_spec_sha256':layout['model']['selected_spec_sha256'],
                        'lambda_source_column_map':columns}


def _source(context: Mapping[str, Any]) -> dict:
    if 'current_primary' in context:
        return context['current_primary']['source']
    return {**context["_f4_inputs"]["source"], **context["source"]}


def _layout(context: Mapping[str, Any], outer: int) -> dict:
    if 'current_primary' in context:
        from .f5_a04_current import current_layout
        return current_layout(context['current_primary'], outer)
    _require(type(outer) is int and outer in range(1, 7), "F5_A04_VARIANT_OUTER_INVALID")
    frozen, family = context["_f4_inputs"]["o_fit_source"], context["lineage"]["final_family"]
    model = frozen["models"][outer, family]
    row, = [item for item in frozen["registry"]["outer"] if item["outer_fold"] == outer]
    _require(model["status"] == "PASS" and model["family"] == family and model["fold"] == outer
             and model["selected_spec_sha256"] == sha256_bytes(canonical_json_bytes(model["selected_spec"])),
             "F5_A04_ORIGINAL_OUTER_MODEL_INVALID")
    _locked_family_parameters(family, model["selected_spec"])
    if family == "ELASTIC_NET_COX":
        _outer_elastic_parameters(_f4_outer_elastic_source(model), outer, 1)
    selected = model["selector_evidence"]["selected_parents"]
    predictors = predictor_contract(Path(__file__).parent)
    recipes = _validate_transform_recipe_set(model["selector_evidence"]["recipe_set"], predictors, expected_count=16)
    original_recipe = _recipe_by_partition(recipes, row["partition_id"])
    common_df = sum(len(item["columns"]) for item in _expected_family_parent_column_map(
        selected, "ELASTIC_NET_COX", predictors, original_recipe))
    fields, response = _response_rows(frozen["response_csv"])
    events = _write_response_subset(fields, response, row["analysis_ids"], None)["event_count"]
    _require(selected and "AST_ALT" in selected and common_df > 0 and events / common_df >= 15
             and model["selector_evidence"]["common_set_design_df"] == common_df
             and model["selector_evidence"]["outer_training_event_count"] == events,
             "F5_A04_ORIGINAL_SETA_EPV_INVALID")
    return {"outer_fold": outer, "family": family, "model": model, "row": row,
            "selected_parents": selected, "original_recipe": original_recipe,
            "common_set_design_df": common_df, "training_event_count": events}


def _partition(frozen: Mapping[str, Any], row: Mapping[str, Any], views: Path, root: Path) -> dict:
    root.mkdir(mode=0o700)
    fit_ids, ids = row["analysis_ids"], row["validation_ids"]
    _require(fit_ids and ids and set(fit_ids).isdisjoint(ids)
             and set(fit_ids) | set(ids) == set(row["application_ids"]), "F5_A04_VARIANT_PARTITION_INVALID")
    fields, response = _response_rows(frozen["response_csv"])
    binding = _merge_registered_views(views / "OUTER_ANALYSIS", views / "OUTER_APPLICATION",
        analysis_ids=fit_ids, application_ids=row["application_ids"],
        destination=root / "covariates", partition_id=row["partition_id"])
    return {"kind": "OUTER", "partition_id": row["partition_id"], "repeat": 0, "inner_fold": 0,
        "fit_ids": fit_ids, "evaluation_ids": ids, "application_ids": row["application_ids"],
        "evaluation_ids_sha256": sha256_bytes(canonical_json_bytes(ids)), "covariates": binding,
        "fit_response": _write_response_subset(fields, response, fit_ids, root / "fit-response.csv"),
        "evaluation_response": _write_response_subset(fields, response, ids, None),
        "fit_covariate_members": _fit_covariate_member_records(binding, fit_ids)}


def _original_outer(frozen: Mapping[str, Any], layout: Mapping[str, Any], root: Path) -> dict:
    """Read two accepted F1 views and their actual configurations, never rerun MICE."""
    from .f1_kernel import _validate_view_library, _view_seed_rows, view_row_ids
    from .f2_kernel import admitted_f1_fold

    root.mkdir(mode=0o700)
    outer = layout["outer_fold"]
    contract = frozen['binding_contract']
    current = layout.get('current_primary')
    if current is not None:
        records=current['canonical_receipts']
        fold_input={'root':current['canonical_root'], 'views':{name:r['view'] for name,r in records.items()}}
        for name, record in records.items():
            path=fold_input['root']/record['library']['relative_path']
            _require(path.is_file() and not path.is_symlink()
                and {'sha256':sha256_file(path),'size_bytes':path.stat().st_size}
                    == {k:record['library'][k] for k in ('sha256','size_bytes')},
                'F5_A04_CURRENT_CANONICAL_LIBRARY_DRIFT')
        lineage={'kind':'PADML_A04_CURRENT_CANONICAL_MICE_SOURCE_V1',
                 'source':current['source'], 'views':{name:r['library'] for name,r in records.items()}}
    else:
        manifest, contract = frozen["f1_manifest"], frozen["binding_contract"]
        records = manifest["direct_objects"]
        paths = {row["unit_id"]: Path(frozen["f1_object_root"]) / f"{row['unit_id']}.zip" for row in records}
        capsule = {"run_id": manifest["identity"], "approved_registry": {"direct_objects": records},
            "manifest": {"identity_records": {"approved_predecessor": {"manifest_identity": manifest["identity"]}}}}
        _, fold_input, lineage = admitted_f1_fold(root / "unused-capsule.zip", capsule, outer, root, contract, paths)
    science = load_science_authority()["science"]["mice"]
    _require([row["target"] for row in science["target_rules"] if row["working_scale"] == "log1p"] == ["Creatinine"],
             "F5_A04_FROZEN_LOG_SCALE_INVALID")
    views = root / "views"
    views.mkdir(mode=0o700)
    evidence = {}
    for role in ("ANALYSIS", "APPLICATION"):
        name = "OUTER_" + role
        expected = fold_input["views"][name]
        analysis_ids, row_ids = view_row_ids(frozen["registry"], outer, name)
        seed_rows = _view_seed_rows(frozen["registry"], outer, name)
        record = _validate_view_library(fold_input["root"] / f"libraries/{name}.zip", expected,
            seed_rows, science["private_handoff"]["columns"], row_ids, views / name)
        value = strict_json_bytes((views / name / "manifest.json").read_bytes())
        summary = value["summary"]
        from .f1_kernel import complete_data_passthrough, mice_terminal_valid
        passthrough = complete_data_passthrough(summary)
        _require(value["outer_fold"] == outer and summary["kind"] == "PADML_F1_MICE_VIEW_SUMMARY"
                 and summary["role"] == role and summary["outer_fold"] == outer
                 and summary["analysis_row_count"] == len(analysis_ids)
                 and summary["formal_m"] == 20 and mice_terminal_valid(summary),
                 "F5_A04_ORIGINAL_MICE_QC_MISMATCH")
        config = {component: strict_json_bytes((views / name / f"configuration/{component}.json").read_bytes())["payload"]
                  for component in ("ACTUAL_MICE_METHOD", "ACTUAL_BLOT", "ACTUAL_CONTINUATION_CONFIG")}
        method = config["ACTUAL_MICE_METHOD"]
        active = [target for target, method_name in zip(method["names"], method["values"], strict=True) if method_name]
        blot_targets = [row["target"] for row in science["target_rules"] if row["target"] in active]
        _require(len(active) == len(set(active)) == len(blot_targets)
                 and all(item in {"", "pmm"} for item in method["values"])
                 and config["ACTUAL_BLOT"] == {"rows": [{"target": target, **science["pmm"]} for target in blot_targets]},
                 "F5_A04_ORIGINAL_MICE_CONFIGURATION_MISMATCH")
        from .f1_kernel import validate_mice_continuation
        validate_mice_continuation(config['ACTUAL_CONTINUATION_CONFIG'], summary,
            [item['seed'] for item in seed_rows], active)
        evidence[name] = {**record, "chain_seeds": seed_rows, "summary": summary,
                         "manifest_sha256": sha256_file(views / name / "manifest.json")}
    partition = _partition(frozen, layout["row"], views, root / "partition")
    original, = [row for row in layout["model"]["model_input"]["model_partitions"] if row["kind"] == "OUTER"]
    identity = _registered_partition_identity_record(
        {key:value for key,value in partition.items() if key != 'evaluation_response'} if current is not None else partition,
        **({'prediction_only':True} if current is not None else {}))
    recipe = layout['original_recipe']
    _require(identity == original
             and recipe["training_member_set_sha256"] == identity["fit_covariate_member_set_sha256"]
             and recipe["fit_ids_sha256"] == identity["fit_ids_sha256"]
             and recipe["analysis_view_sha256"] == identity["analysis_view_sha256"],
             "F5_A04_ORIGINAL_MICE_MODEL_RECIPE_MISMATCH")
    return {"f1_lineage": lineage, "views": evidence, "partition": identity,
            "outer_model_sha256": sha256_bytes(canonical_json_bytes(layout["model"])),
            "historical_f1_authority_sha256": contract["authority_sha256"],
            "baseline_policy": ('CURRENT_PRIMARY_CANONICAL_LOG_DONOR5_AND_ORIGINAL_SELECTED_PREDICTIONS_NO_REFIT'
                if current is not None else 'ACCEPTED_F1_LOG_DONOR5_AND_F2_OUTER_PREDICTIONS_NO_REFIT')}


def _prepare(context: Mapping[str, Any], outer: int, archives: Mapping[str, Path], root: Path,
             *, original_evidence: Mapping[str, Any] | None = None,
             retain_evidence: bool = False) -> tuple[dict, list[dict]]:
    from .f5 import _compile_partition_design_recipe, _validate_final_design_recipe
    layout = _layout(context, outer)
    frozen, family = _frozen(context), layout["family"]
    _require(set(archives) == {f"{variant}/OUTER_{role}" for variant in A04_NEW_MICE_VARIANTS
                               for role in ("ANALYSIS", "APPLICATION")}, "F5_A04_VARIANT_VIEW_COVERAGE_INVALID")
    root.mkdir(mode=0o700)
    original = (_original_outer(frozen, layout, root / "original")
                if original_evidence is None else dict(original_evidence))
    predictors = predictor_contract(Path(__file__).parent)
    selected, jobs, prepared = layout["selected_parents"], [], {}
    for variant in A04_NEW_MICE_VARIANTS:
        work = root / variant
        work.mkdir(mode=0o700)
        for role in ("ANALYSIS", "APPLICATION"):
            name = "OUTER_" + role
            source = work / f"{name}-input.zip"
            write_deterministic_zip(source, _a04_variant_view_inputs(frozen, outer, variant, role))
            materialize_a12_total_mice_view(source, archives[f"{variant}/{name}"], work / name,
                                           a04_variant=True, retain_evidence=retain_evidence)
        partition = _partition(frozen, layout["row"], work, work / "partition")
        recipe = _compile_partition_design_recipe(family, selected, partition, work,
            **({"native_evidence": work / "recipe-native"} if family in _TRANSFORMED else {}))
        _validate_final_design_recipe(recipe, family=family, selected_parents=selected)
        design_count = sum(len(row["columns"]) for row in _expected_family_parent_column_map(
            selected, family, predictors, recipe["transform_recipe"]))
        _require(design_count > 0, "F5_A04_VARIANT_EMPTY_MODEL_DESIGN")
        if family in _TRANSFORMED:
            common = sum(len(row["columns"]) for row in _expected_family_parent_column_map(
                selected, "ELASTIC_NET_COX", predictors, recipe["transform_recipe"]))
            _require(common == layout["common_set_design_df"], "F5_A04_VARIANT_COMMON_SETA_COMPLEXITY_DRIFT")
        identity = _registered_partition_identity_record(partition)
        prepared[variant] = {"partition": identity, "recipe": recipe}
        for imp, member in enumerate(partition["covariates"]["members"], 1):
            path = Path(partition["covariates"]["input_dir"]) / member["name"]
            reader = csv.DictReader(io.StringIO(path.read_text(encoding="utf-8-sig")))
            rows = list(reader)
            _require(member["name"] == f"imp{imp:02d}.csv"
                     and reader.fieldnames == load_science_authority()["science"]["mice"]["private_handoff"]["columns"]
                     and [row["Patient_ID"] for row in rows] == layout["row"]["application_ids"]
                     and all(row["Center"] == frozen["centers"][row["Patient_ID"]] for row in rows),
                     "F5_A04_VARIANT_COMPLETED_DATA_DRIFT")
            coordinates = {"outer_fold": outer, "variant": variant, "imputation": imp}
            seed = _a04_variant_model_seed(coordinates)
            parameters, parameter_source = _parameters(context, layout, imp)
            task = {"family": family, "selected_parents": selected, "parameters": parameters,
                "imputation": imp, "a04_coordinates": coordinates, "registered_model_seed": seed,
                "model_seed": seed if family in _STOCHASTIC else None, "row_count": len(partition["fit_ids"]),
                "family_design_column_count": design_count, "common_set_design_df": layout["common_set_design_df"],
                "training_event_count": layout["training_event_count"], "a04_parameter_source": parameter_source}
            _validate_a04_variant_model_task(family, task)
            entries = {"task.json": canonical_json_bytes(task), "recipe.json": canonical_json_bytes(recipe),
                "fit-covariates.csv": _recipe_training_member_bytes(path, partition["fit_ids"]),
                "fit-response.csv": Path(partition["fit_response"]["path"]).read_bytes(),
                "prediction-covariates.csv": _recipe_training_member_bytes(path, partition["evaluation_ids"])}
            _ablation_component_inputs(entries)
            jobs.append({"name": f"O{outer}_{variant}_M{imp:02d}", "entries": entries})
    _require(len(jobs) == 60 and len({row["name"] for row in jobs}) == 60, "F5_A04_VARIANT_MODEL_COVERAGE_INVALID")
    return {"source": _source(context), "family": family, "outer_fold": outer,
            "original_log_donor5": original, "variants": prepared}, jobs


def _predictions(prepared: Mapping[str, Any], jobs: list[dict], rows: list[dict]) -> dict:
    _require(len(jobs) == len(rows) == 60, "F5_A04_VARIANT_MODEL_COVERAGE_INVALID")
    _, _, _, _, application = _ablation_component_inputs(jobs[0]["entries"])
    ids, centers = [row["Patient_ID"] for row in application], [row["Center"] for row in application]
    values = {}
    for job, row in zip(jobs, rows, strict=True):
        task = strict_json_bytes(job["entries"]["task.json"])
        coordinate = task["a04_coordinates"]
        key = coordinate["variant"], coordinate["imputation"]
        _require(key not in values and coordinate["outer_fold"] == prepared["outer_fold"]
                 and row["a04_coordinates"] == coordinate and row["family"] == prepared["family"]
                 and row["patient_ids"] == ids and row["centers"] == centers and row["horizons"] == HORIZONS,
                 "F5_A04_VARIANT_PREDICTION_COORDINATE_MISMATCH")
        _seal_prediction_matrix(ids, row["survival"], HORIZONS)
        _require(all(item[0] == 1.0 for item in row["survival"]), "F5_A04_VARIANT_MONTH_ZERO_INVALID")
        values[key] = row["survival"]
    _require(set(values) == {(variant, imp) for variant in A04_NEW_MICE_VARIANTS for imp in range(1, 21)},
             "F5_A04_VARIANT_MODEL_COVERAGE_INVALID")
    survival = {variant: [[math.fsum(values[variant, imp][patient][month] for imp in range(1, 21)) / 20
        for month in range(len(HORIZONS))] for patient in range(len(ids))] for variant in A04_NEW_MICE_VARIANTS}
    for matrix in survival.values():
        _seal_prediction_matrix(ids, matrix, HORIZONS)
    return {"patient_ids": ids, "centers": centers, "horizons": HORIZONS, "survival": survival}


def _member_names(family: str, outer: int, *, compact: bool = False) -> set[str]:
    return ({f"views/{variant}/OUTER_{role}.zip" for variant in A04_NEW_MICE_VARIANTS for role in ("ANALYSIS", "APPLICATION")}
        | {f"fits/O{outer}_{variant}_M{imp:02d}.{'numbers.json' if compact else 'zip'}" for variant in A04_NEW_MICE_VARIANTS for imp in range(1, 21)}
        | ({f"recipes/{variant}/{name}" for variant in A04_NEW_MICE_VARIANTS
             for name in ("spec.json", "recipe.json", "stdout.log", "stderr.log")} if family in _TRANSFORMED else set()))


def _execute_view(job: Mapping[str, Any]) -> dict:
    return execute_a12_total_mice_bundle(Path(job["input"]), Path(job["target"]), a04_variant=True)


def execute_variant_outer(lineage: Mapping[str, Any], target: Path, *, f2_run_root: Path,
                          outer: int, workers: int | None = None, f1_runtime_root: Path | None = None) -> dict:
    _new_target(target)
    context = application_context(f2_run_root, lineage, f1_runtime_root=f1_runtime_root)
    layout = _layout(context, outer)
    capacity = resolve_pool_workers(workers)
    root = target.with_name(target.name + ".work")
    root.mkdir(mode=0o700)
    try:
        # Check the accepted baseline before any new chain spends its allowance.
        original = _original_outer(context["_f4_inputs"]["o_fit_source"], layout, root / "original")
        jobs, archives = [], {}
        for variant in A04_NEW_MICE_VARIANTS:
            work = root / "views" / variant
            work.mkdir(mode=0o700, parents=True)
            for role in ("ANALYSIS", "APPLICATION"):
                name = "OUTER_" + role
                source, result = work / f"{name}-input.zip", work / f"{name}.zip"
                write_deterministic_zip(source, _a04_variant_view_inputs(context["_f4_inputs"]["o_fit_source"], outer, variant, role))
                jobs.append({"input": str(source), "target": str(result)})
                archives[f"{variant}/{name}"] = result
        _bounded_ordered_spawn(_execute_view, jobs, selected_slots=capacity)
        prepared, jobs = _prepare(context, outer, archives, root / "prepared", original_evidence=original)
        (root / "fits").mkdir(mode=0o700)
        jobs = [{**job, "root": str(root / "fits" / job["name"])} for job in jobs]
        rows = _bounded_ordered_spawn(_execute_ablation_component, jobs, selected_slots=capacity)
        members = {name: root / name for name in _member_names(layout["family"], outer)}
        for name in list(members):
            if name.startswith("recipes/"):
                _, variant, leaf = name.split("/")
                members[name] = root / "prepared" / variant / "recipe-native" / leaf
        body = {"kind": "PADML_F5_A04_VARIANT_OUTER_NATIVE", **prepared,
            "predictions": _predictions(prepared, jobs, rows),
            "members": {name: {"sha256": sha256_file(path), "size_bytes": path.stat().st_size}
                        for name, path in sorted(members.items())}}
        write_deterministic_zip(target, {"variant-outer.json": canonical_json_bytes(body), **members},
                                stored_members={name for name in members if name.endswith(".zip")})
    except BaseException as exc:
        exc.add_note(f"F5_A04_VARIANT_OUTER_EVIDENCE_RETAINED:{root}")
        raise
    shutil.rmtree(root)
    return {"status": "COMPUTED_NATIVE_VARIANTS", "stage_acceptance": False, "outer_fold": outer,
        "model_fit_count": 60, "mice_chain_execution_count": 120, "stop_fit_count": 0,
        "pool_workers": min(capacity, 60), "sha256": sha256_file(target), "size_bytes": target.stat().st_size}


def replay_variant_outer(source: Path, context: Mapping[str, Any], root: Path, *, retain_evidence: bool = False) -> dict:
    stored, _ = _audit_json(source, "variant-outer.json")
    layout = _layout(context, stored.get("outer_fold"))
    compact='current_primary' in context
    names = _member_names(layout["family"], layout["outer_fold"],compact=compact)
    _require(set(stored) == {"kind", "source", "family", "outer_fold", "original_log_donor5", "variants", "predictions", "members"}
             and stored["kind"] == ("PADML_CURRENT_A04_VARIANT_OUTER_NUMERICAL_V1" if compact else "PADML_F5_A04_VARIANT_OUTER_NATIVE")
             and stored["source"] == _source(context) and stored["family"] == layout["family"]
             and set(stored["members"]) == names, "F5_A04_VARIANT_OUTER_SOURCE_INVALID")
    _new_target(root)
    root.mkdir(mode=0o700)
    try:
        extracted = root / "archive"
        extract_safe_zip(source, extracted, expected_members={"variant-outer.json": {
            "sha256": sha256_bytes(canonical_json_bytes(stored)), "size_bytes": len(canonical_json_bytes(stored))}, **stored["members"]},
            max_member_bytes=4*1024**3, max_total_bytes=82*1024**3)
        archives = {f"{variant}/OUTER_{role}": extracted / f"views/{variant}/OUTER_{role}.zip"
                    for variant in A04_NEW_MICE_VARIANTS for role in ("ANALYSIS", "APPLICATION")}
        prepared, jobs = _prepare(context, layout["outer_fold"], archives, root / "prepared", retain_evidence=retain_evidence)
        _require(all(stored[key] == value for key, value in prepared.items()), "F5_A04_VARIANT_INPUT_REPLAY_MISMATCH")
        for variant in A04_NEW_MICE_VARIANTS:
            if layout["family"] in _TRANSFORMED:
                _require((extracted / f"recipes/{variant}/recipe.json").read_bytes()
                         == (root / f"prepared/{variant}/recipe-native/recipe.json").read_bytes(),
                         "F5_A04_VARIANT_RECIPE_NATIVE_REPLAY_MISMATCH")
        if compact:
            from .f5_a04_current import _a04_replay_numbers
            rows=[_a04_replay_numbers(job,extracted/f"fits/{job['name']}.numbers.json") for job in jobs]
        else:
            rows = [_replay_ablation_component({**job, "archive": extracted / f"fits/{job['name']}.zip",
                **({"replay_evidence": root / (job["name"] + "-replay")} if retain_evidence else {})}) for job in jobs]
        predictions = _predictions(prepared, jobs, rows)
        if retain_evidence:
            (root / "replayed-predictions.json").write_bytes(canonical_json_bytes(predictions))
        _require(predictions == stored["predictions"], "F5_A04_VARIANT_PREDICTION_REPLAY_MISMATCH")
    except BaseException as exc:
        exc.add_note(f"F5_A04_VARIANT_REPLAY_EVIDENCE_RETAINED:{root}")
        raise
    if not retain_evidence:
        shutil.rmtree(root)
    return stored


def variant_handoff(context: Mapping[str, Any], outers: list[dict]) -> dict:
    _require([row["outer_fold"] for row in outers] == list(range(1, 7)), "F5_A04_VARIANT_SIX_OUTERS_REQUIRED")
    primary = context["_f4_inputs"]["handoff"]
    family = context["lineage"]["final_family"]
    ids, centers = primary["patient_ids"], primary["centers"]
    survival = {"LOG_DONOR5": primary["survival"][family]}
    for variant in A04_NEW_MICE_VARIANTS:
        by_id = {}
        for row in outers:
            prediction = row["predictions"]
            _require(row["family"] == family and row["source"] == _source(context)
                     and prediction["horizons"] == HORIZONS
                     and not set(prediction["patient_ids"]).intersection(by_id), "F5_A04_VARIANT_PATIENT_COVERAGE_INVALID")
            by_id.update({patient: (center, values) for patient, center, values in zip(
                prediction["patient_ids"], prediction["centers"], prediction["survival"][variant], strict=True)})
        _require(set(by_id) == set(ids) and [by_id[patient][0] for patient in ids] == centers,
                 "F5_A04_VARIANT_PATIENT_COVERAGE_INVALID")
        survival[variant] = [by_id[patient][1] for patient in ids]
    for matrix in survival.values():
        _seal_prediction_matrix(ids, matrix, HORIZONS)
    return {"patient_ids": ids, "centers": centers, "horizons": HORIZONS, "survival": survival}


def variant_result(context: Mapping[str, Any], outers: list[dict], evaluation: dict) -> dict:
    return {"status": "NATIVE_MICE_AND_ORIGINAL_OUTER_MODELS_REPLAYED", "source": _source(context),
        "final_family": context["lineage"]["final_family"], "variants": list(VARIANTS),
        "model_fit_count": 360, "mice_chain_execution_count": 720, "selector_path_count": 0,
        "search_fit_count": 0, "stop_fit_count": 0, "selection_effect": "NONE", "stage_acceptance": False,
        "outer_sources": [{"outer_fold": row["outer_fold"], "original_log_donor5": row["original_log_donor5"]} for row in outers],
        "evaluation": evaluation}
