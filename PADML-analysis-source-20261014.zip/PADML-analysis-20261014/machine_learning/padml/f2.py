from __future__ import annotations

from typing import Any, Mapping

from ._science_authority import load_science_authority, selected_route_profiles
from .bundle import ContractError, canonical_json_bytes, sha256_bytes, validate_envelope
from .f1_contract import validate_f1_input_manifest


F2_FAMILIES = (
    "COX_PH", "ELASTIC_NET_COX", "RSF", "GBM_COX",
    "XGBOOST_COX", "FPM_TVC_SET_A", "COXTIME_SET_A",
)
F2_COMPONENTS = (
    "CENTER_BLOCKED_STRESS",
    "LOCKED_MODEL_SAMPLE_SIZE_DIAGNOSTIC",
    "LOCAL_PERTURBATION",
)
F2_UNIT_COUNT = 46
F2_MAX_PARALLEL_UNITS = 6
F2_AUTHORITY_SHA256 = sha256_bytes(canonical_json_bytes(load_science_authority()))
MODEL_SEED = load_science_authority()["science"]["modeling_seed_policy"]["model"]
SAMPLER_SEED = load_science_authority()["science"]["modeling_seed_policy"]["sampler"]
_FAMILY_SLUG = {
    "COX_PH": "cox-ph",
    "RSF": "rsf",
    "GBM_COX": "gbm-cox",
    "XGBOOST_COX": "xgboost-cox",
    "FPM_TVC_SET_A": "fpm-tvc-set-a",
    "COXTIME_SET_A": "coxtime-set-a",
}


def _require(condition: bool, reason: str) -> None:
    if not condition:
        raise ContractError(reason)


def load_f2_authority() -> dict[str, Any]:
    return load_science_authority()


def validate_approved_f1(value: Any) -> dict[str, Any]:
    return validate_f1_input_manifest(value)


def approved_f1_identity(value: Mapping[str, Any]) -> str:
    return validate_approved_f1(dict(value))["identity"]


def _artifact(unit_id: str, classification: str) -> dict[str, Any]:
    return {
        "artifact_id": f"{unit_id}.unit_result",
        "relative_path": f"outputs/{unit_id}/unit.json",
        "classification": classification,
    }


def _unit(
    unit_id: str,
    action: str,
    role: str,
    *,
    coordinates: list[dict[str, Any]],
    depends_on: list[str],
    seed: int | None,
    classification: str = "PRIVATE_SCIENCE",
    serial: bool = False,
) -> dict[str, Any]:
    return {
        "unit_id": unit_id,
        "action": action,
        "role": role,
        "coordinates": [*coordinates, {"axis": "execution_mode", "value": "SERIAL" if serial else "PROCESS_POOL"}],
        "depends_on": depends_on,
        "internal_threads": 1 if serial else 24,
        "seed": seed,
        "expected_artifact": _artifact(unit_id, classification),
    }


def compile_f2_units(
    route_profiles: Mapping[str, Any] | None = None,
    *, p2c2t_pool_workers: Mapping[str, int] | None = None,
    unit_pool_workers: Mapping[str, int] | None = None,
) -> list[dict[str, Any]]:
    _require(
        (dict(route_profiles) if route_profiles is not None else selected_route_profiles())
        == selected_route_profiles(),
        "F2_ROUTE_PROFILE_MAP_INVALID",
    )
    diagnostic_workers = (
        {component: 24 for component in F2_COMPONENTS}
        if p2c2t_pool_workers is None else dict(p2c2t_pool_workers)
    )
    _require(
        set(diagnostic_workers) == set(F2_COMPONENTS)
        and all(type(value) is int and value >= 1
                for value in diagnostic_workers.values()),
        "F2_P2C2T_POOL_WORKERS_INVALID",
    )
    selectors = [
        _unit(
            f"selector-f{fold}-elastic-net-cox",
            "MODEL_DEVELOPMENT",
            "SELECTOR_FIT_PREDICT",
            coordinates=[{"axis": "outer_fold", "value": fold}, {"axis": "family", "value": "ELASTIC_NET_COX"}],
            depends_on=[],
            seed=MODEL_SEED["base"] + fold * MODEL_SEED["outer_multiplier"],
        )
        for fold in range(1, 7)
    ]
    models = [
        _unit(
            f"model-f{fold}-{_FAMILY_SLUG[family]}",
            "MODEL_DEVELOPMENT",
            "FIT_PREDICT",
            coordinates=[{"axis": "outer_fold", "value": fold}, {"axis": "family", "value": family}],
            depends_on=[f"selector-f{fold}-elastic-net-cox"],
            seed=MODEL_SEED["base"] + fold * MODEL_SEED["outer_multiplier"],
        )
        for fold in range(1, 7)
        for family in F2_FAMILIES
        if family != "ELASTIC_NET_COX"
    ]
    model_ids = [row["unit_id"] for row in [*selectors, *models]]
    diagnostics = [
        _unit(
            f"p2c2t-{component.lower().replace('_', '-')}",
            "P2C2T",
            "DIAGNOSTIC",
            coordinates=[{"axis": "component", "value": component}],
            depends_on=model_ids,
            seed=SAMPLER_SEED["base"] + index * SAMPLER_SEED["model_index_multiplier"],
            classification="DIAGNOSTIC",
        )
        for index, component in enumerate(F2_COMPONENTS, start=1)
    ]
    for unit, component in zip(diagnostics, F2_COMPONENTS, strict=True):
        unit["internal_threads"] = diagnostic_workers[component]
    aggregate = _unit(
        "model-confirmation",
        "MODEL_CONFIRMATION_AGGREGATE",
        "AGGREGATE",
        coordinates=[],
        depends_on=[*model_ids, *(row["unit_id"] for row in diagnostics)],
        seed=None,
        classification="PUBLIC_AGGREGATE",
        serial=True,
    )
    units = [*selectors, *models, *diagnostics, aggregate]
    if unit_pool_workers is not None:
        _require(p2c2t_pool_workers is None
                 and set(unit_pool_workers) == {row["unit_id"] for row in units[:-1]}
                 and all(type(value) is int and value >= 1 for value in unit_pool_workers.values()),
                 "F2_UNIT_POOL_WORKERS_INVALID")
        for unit in units[:-1]:
            unit["internal_threads"] = unit_pool_workers[unit["unit_id"]]
    _require(len(units) == F2_UNIT_COUNT and len({row["unit_id"] for row in units}) == F2_UNIT_COUNT, "F2_UNIT_TOPOLOGY_INVALID")
    return units


def canonical_unit_ids() -> tuple[str, ...]:
    return tuple(row["unit_id"] for row in compile_f2_units())


def selector_checkpoint_projection(
    authority: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Map frozen authority selector IDs onto production topology IDs.

    The authority predates the production-facing selector slug.  This record is
    deliberately operational metadata: it preserves the authority bytes while
    making the one-to-one topology projection explicit and hashable.
    """

    value = dict(authority) if authority is not None else load_science_authority()
    _require(value == load_science_authority(), "F2_SELECTOR_PROJECTION_AUTHORITY_DRIFT")
    authority_ids = value["science"]["f2_model_development"][
        "selector_review_checkpoint"
    ]["selector_unit_ids"]
    expected_authority_ids = [
        f"model-f{fold}-elastic_net_cox" for fold in range(1, 7)
    ]
    production_ids = [
        f"selector-f{fold}-elastic-net-cox" for fold in range(1, 7)
    ]
    _require(
        authority_ids == expected_authority_ids,
        "F2_SELECTOR_PROJECTION_AUTHORITY_IDS_INVALID",
    )
    records = [
        {
            "fold": fold,
            "authority_unit_id": authority_id,
            "production_unit_id": production_id,
        }
        for fold, authority_id, production_id in zip(
            range(1, 7), authority_ids, production_ids, strict=True
        )
    ]
    _require(
        len(records)
        == len({row["authority_unit_id"] for row in records})
        == len({row["production_unit_id"] for row in records})
        == 6
        and tuple(row["production_unit_id"] for row in records)
        == canonical_unit_ids()[:6],
        "F2_SELECTOR_PROJECTION_NOT_BIJECTIVE",
    )
    projection = {
        "schema_version": "1.0.0",
        "kind": "PADML_F2_NON_SCIENTIFIC_SELECTOR_TOPOLOGY_PROJECTION",
        "classification": "NON_SCIENTIFIC_TOPOLOGY_ONLY",
        "records": records,
    }
    projection["identity"] = sha256_bytes(canonical_json_bytes(projection))
    return projection


def compile_f2_plan(
    *, p2c2t_pool_workers: Mapping[str, int] | None = None,
    unit_pool_workers: Mapping[str, int] | None = None,
) -> dict[str, Any]:
    units = compile_f2_units(p2c2t_pool_workers=p2c2t_pool_workers,
                             unit_pool_workers=unit_pool_workers)
    model_slots = {row["unit_id"]: row["internal_threads"] for row in units[:42]}
    value = {
        "schema_version": "1.0.0",
        "kind": "PADML_F2_V1_EXECUTION_PLAN",
        "stage_id": "F2",
        "max_parallel_units": 6,
        "pool_workers": (next(iter(model_slots.values()))
                         if len(set(model_slots.values())) == 1 else model_slots),
        "engine_threads": 1,
        "canonical_acceptance": list(canonical_unit_ids()),
        "selector_checkpoint_projection": selector_checkpoint_projection(),
        "units": units,
    }
    value["identity"] = sha256_bytes(canonical_json_bytes(value))
    return value


def materialize_requests(
    *, run_id: str, source_identity: str, runtime_identity: str,
    worker_identity: str, input_identity: str,
    p2c2t_pool_workers: Mapping[str, int] | None = None,
    unit_pool_workers: Mapping[str, int] | None = None,
) -> dict[str, dict[str, Any]]:
    plan = compile_f2_plan(p2c2t_pool_workers=p2c2t_pool_workers,
                           unit_pool_workers=unit_pool_workers)
    identities = {
        "source": source_identity,
        "authority": F2_AUTHORITY_SHA256,
        "runtime": runtime_identity,
        "worker": worker_identity,
        "input": input_identity,
        "plan": plan["identity"],
    }
    requests: dict[str, dict[str, Any]] = {}
    for unit in plan["units"]:
        transaction = sha256_bytes(
            canonical_json_bytes({"run_id": run_id, "unit_id": unit["unit_id"], "plan": plan["identity"]})
        )[:32]
        request = {
            "schema_version": "1.0.0", "kind": "request", "run_id": run_id,
            "stage_id": "F2", "unit_id": unit["unit_id"], "transaction_id": transaction,
            "identities": identities, "seed": unit["seed"],
            "plan": {
                "action": unit["action"], "role": unit["role"],
                "coordinates": unit["coordinates"], "depends_on": unit["depends_on"],
                "internal_threads": unit["internal_threads"],
            },
            "artifacts": [{**unit["expected_artifact"], "size_bytes": None, "sha256": None, "status": "EXPECTED"}],
            "terminal": None, "decision": None,
        }
        requests[unit["unit_id"]] = validate_envelope(request)
    _require(tuple(requests) == canonical_unit_ids(), "F2_REQUEST_ORDER_INVALID")
    return requests
