from __future__ import annotations

import csv
import hashlib
import io
import math
import os
import re
import subprocess
import tempfile
from collections import defaultdict
from pathlib import Path
from typing import Any, Iterable, Mapping

from .bundle import (
    ContractError,
    canonical_json_bytes,
    execution_contract,
    execution_result_contract,
    extract_safe_zip,
    inspect_safe_zip_manifest,
    read_safe_zip,
    science_projection_sha256,
    sha256_bytes,
    sha256_file,
    strict_json_bytes,
    validate_envelope,
    validate_sha256,
    write_deterministic_zip,
)
from .f1 import (
    F1_AUTHORITY_SHA256,
    F1_COMMON_INPUT_NAME,
    F1_WORKBOOK_MEMBER,
    load_f1_authority,
)
from .runtime import RSCRIPT_EXECUTABLE, THREAD_ENV, _bounded_ordered_spawn


_CENTERS = (36, 38, 39, 48, 52, 54, 55)
_VALIDATION_CENTERS = (36, 38, 39, 48, 52, 54)
_FORBIDDEN_APPLICATION_COLUMNS = {
    "All_Cause_Death",
    "Death_Followup_months",
    "event",
    "nelson_aalen",
}
_CONFIGURATION_NAMES = (
    "ACTUAL_MICE_METHOD",
    "ACTUAL_PREDICTOR_MATRIX",
    "ACTUAL_BLOT",
    "ACTUAL_CONTINUATION_CONFIG",
)
_TYPED_F1 = re.compile(r"(?<![A-Z0-9_])((?:F1_|F5_MICE_(?:NATIVE_|SUBSTREAM_))[A-Z0-9_]+)(?![A-Z0-9_])")


def _require(condition: bool, reason: str) -> None:
    if not condition:
        raise ContractError(reason)


def _sha(value: Any) -> str:
    return sha256_bytes(canonical_json_bytes(value))


def _ordered(ids: Iterable[str], global_order: Mapping[str, int]) -> list[str]:
    return sorted(ids, key=global_order.__getitem__)


def _partition_hash(patient_id: str, **coordinates: Any) -> str:
    return _sha({"Patient_ID": patient_id, **coordinates})


def _inner_assignments(
    ids: list[str],
    centers: Mapping[str, int],
    events: Mapping[str, int],
    *,
    outer_fold: int,
    repeat: int,
    seed: int,
) -> dict[str, int]:
    strata: dict[tuple[int, int], list[str]] = defaultdict(list)
    for patient_id in ids:
        strata[(centers[patient_id], events[patient_id])].append(patient_id)
    assignments: dict[str, int] = {}
    for key in sorted(strata):
        ordered = sorted(
            strata[key],
            key=lambda patient_id: _partition_hash(
                patient_id,
                kind="INNER_FOLD",
                outer_fold=outer_fold,
                repeat=repeat,
                seed=seed,
            ),
        )
        for index, patient_id in enumerate(ordered):
            assignments[patient_id] = index % 5 + 1
    _require(set(assignments) == set(ids), "F1_INNER_ASSIGNMENT_INCOMPLETE")
    return assignments


def _stop_ids(
    inner_train: list[str],
    centers: Mapping[str, int],
    events: Mapping[str, int],
    *,
    outer_fold: int,
    repeat: int,
    inner_fold: int,
    seed: int,
) -> set[str]:
    strata: dict[tuple[int, int], list[str]] = defaultdict(list)
    for patient_id in inner_train:
        strata[(centers[patient_id], events[patient_id])].append(patient_id)
    selected: set[str] = set()
    for key in sorted(strata):
        ordered = sorted(
            strata[key],
            key=lambda patient_id: _partition_hash(
                patient_id,
                kind="STOP",
                outer_fold=outer_fold,
                repeat=repeat,
                inner_fold=inner_fold,
                seed=seed,
            ),
        )
        count = max(1, int(len(ordered) * 0.15 + 0.5)) if len(ordered) > 1 else 0
        count = min(count, max(0, len(ordered) - 1))
        selected.update(ordered[:count])
    fit = set(inner_train) - selected
    _require(
        bool(selected)
        and bool(fit)
        and any(events[item] == 1 for item in selected)
        and any(events[item] == 1 for item in fit),
        "F1_STOP_EVENT_SUPPORT_INVALID",
    )
    return selected


def _view(
    view_id: str,
    kind: str,
    role: str,
    partition_id: str,
    analysis_ids: list[str],
    row_ids: list[str],
) -> dict[str, Any]:
    return {
        "view_id": view_id,
        "kind": kind,
        "role": role,
        "partition_id": partition_id,
        "analysis_ids_sha256": _sha(analysis_ids),
        "row_ids_sha256": _sha(row_ids),
        "row_count": len(row_ids),
        "response_visibility": (
            "FIT_EVENT_AND_NELSON_AALEN_TRANSIENT_ONLY"
            if role == "ANALYSIS"
            else "PHYSICALLY_ABSENT"
        ),
    }


def compile_split_registry(
    patient_ids: list[str], centers_by_id: Mapping[str, int], events_by_id: Mapping[str, int]
) -> dict[str, Any]:
    """Compile the sole deterministic F1 outer/inner/STOP/seed registry."""

    _require(
        patient_ids
        and len(patient_ids) == len(set(patient_ids))
        and all(type(item) is str and bool(item) for item in patient_ids)
        and set(centers_by_id) == set(patient_ids)
        and set(events_by_id) == set(patient_ids)
        and all(centers_by_id[item] in _CENTERS for item in patient_ids)
        and all(events_by_id[item] in {0, 1} for item in patient_ids),
        "F1_BINDING_ROW_DOMAIN_INVALID",
    )
    stable_ids = sorted(patient_ids, key=lambda item: hashlib.sha256(item.encode()).hexdigest())
    global_order = {patient_id: index for index, patient_id in enumerate(stable_ids)}
    authority = load_f1_authority()
    split_seed = authority["science"]["mice"]["seed_policy"]["split"]
    chain_base = authority["science"]["mice"]["seed_policy"]["chain"]["base"]
    outer_rows: list[dict[str, Any]] = []
    inner_rows: list[dict[str, Any]] = []
    stopping_rows: list[dict[str, Any]] = []
    center_stress_rows: list[dict[str, Any]] = []
    sample_size_rows: list[dict[str, Any]] = []
    fold_views: dict[str, list[dict[str, Any]]] = {}
    seed_rows: list[dict[str, Any]] = []

    for outer_fold, heldout_center in enumerate(_VALIDATION_CENTERS, start=1):
        outer_train = _ordered(
            (item for item in stable_ids if centers_by_id[item] != heldout_center),
            global_order,
        )
        outer_validation = _ordered(
            (item for item in stable_ids if centers_by_id[item] == heldout_center),
            global_order,
        )
        _require(
            outer_train
            and outer_validation
            and set(outer_train).isdisjoint(outer_validation)
            and set(outer_train) | set(outer_validation) == set(stable_ids)
            and any(events_by_id[item] == 1 for item in outer_train)
            and any(events_by_id[item] == 1 for item in outer_validation),
            "F1_OUTER_PARTITION_INVALID",
        )
        outer_id = f"OUTER_F{outer_fold}"
        outer_rows.append(
            {
                "partition_id": outer_id,
                "outer_fold": outer_fold,
                "heldout_center": heldout_center,
                "analysis_ids": outer_train,
                "validation_ids": outer_validation,
                "application_ids": stable_ids,
            }
        )
        for validation_center in _VALIDATION_CENTERS:
            if validation_center == heldout_center:
                continue
            validation = _ordered(
                (
                    item
                    for item in outer_train
                    if centers_by_id[item] == validation_center
                ),
                global_order,
            )
            validation_set = set(validation)
            analysis = _ordered(
                (item for item in outer_train if item not in validation_set),
                global_order,
            )
            _require(
                analysis
                and validation
                and set(analysis).isdisjoint(validation)
                and set(analysis) | set(validation) == set(outer_train)
                and any(events_by_id[item] == 1 for item in analysis)
                and any(events_by_id[item] == 1 for item in validation),
                "F1_CENTER_STRESS_PARTITION_INVALID",
            )
            center_stress_rows.append(
                {
                    "partition_id": f"CENTER_STRESS_F{outer_fold}_C{validation_center}",
                    "outer_fold": outer_fold,
                    "validation_center": validation_center,
                    "analysis_ids": analysis,
                    "validation_ids": validation,
                    "application_ids": outer_train,
                    "view_source": "OUTER_APPLICATION",
                    "selection_effect": "NONE",
                }
            )
        for seed_ordinal in range(1, 4):
            strata: dict[tuple[int, int], list[str]] = defaultdict(list)
            for patient_id in outer_train:
                strata[(centers_by_id[patient_id], events_by_id[patient_id])].append(
                    patient_id
                )
            ordered_strata = {
                key: sorted(
                    values,
                    key=lambda patient_id: _partition_hash(
                        patient_id,
                        kind="LOCKED_SAMPLE_SIZE",
                        outer_fold=outer_fold,
                        seed_ordinal=seed_ordinal,
                        seed=split_seed["base"] + 50_000 + outer_fold * 1000 + seed_ordinal,
                    ),
                )
                for key, values in strata.items()
            }
            previous: set[str] = set()
            for fraction in (0.4, 0.6, 0.8, 1.0):
                selected: set[str] = set()
                for values in ordered_strata.values():
                    count = len(values) if fraction == 1.0 else max(
                        1, int(len(values) * fraction + 0.5)
                    )
                    selected.update(values[: min(count, len(values))])
                _require(
                    previous.issubset(selected)
                    and selected.issubset(outer_train)
                    and any(events_by_id[item] == 1 for item in selected),
                    "F1_LOCKED_SAMPLE_SIZE_REGISTRY_INVALID",
                )
                sample_size_rows.append(
                    {
                        "outer_fold": outer_fold,
                        "seed_ordinal": seed_ordinal,
                        "fraction": fraction,
                        "sample_ids": _ordered(selected, global_order),
                    }
                )
                previous = selected
        views = [
            _view("OUTER_ANALYSIS", "OUTER", "ANALYSIS", outer_id, outer_train, outer_train),
            _view("OUTER_APPLICATION", "OUTER", "APPLICATION", outer_id, outer_train, stable_ids),
        ]
        for repeat in range(1, 4):
            seed = split_seed["base"] + outer_fold * split_seed["outer_multiplier"] + repeat
            assignments = _inner_assignments(
                outer_train,
                centers_by_id,
                events_by_id,
                outer_fold=outer_fold,
                repeat=repeat,
                seed=seed,
            )
            for patient_id in outer_train:
                _require(assignments[patient_id] in range(1, 6), "F1_INNER_ASSIGNMENT_INVALID")
            for inner_fold in range(1, 6):
                validation = _ordered(
                    (item for item in outer_train if assignments[item] == inner_fold),
                    global_order,
                )
                inner_train = _ordered(
                    (item for item in outer_train if assignments[item] != inner_fold),
                    global_order,
                )
                partition_id = f"INNER_F{outer_fold}_R{repeat}_K{inner_fold}"
                inner_rows.append(
                    {
                        "partition_id": partition_id,
                        "outer_fold": outer_fold,
                        "repeat": repeat,
                        "inner_fold": inner_fold,
                        "analysis_ids": inner_train,
                        "validation_ids": validation,
                        "application_ids": outer_train,
                    }
                )
                views.extend(
                    [
                        _view(
                            f"INNER_R{repeat}_K{inner_fold}_ANALYSIS",
                            "INNER",
                            "ANALYSIS",
                            partition_id,
                            inner_train,
                            inner_train,
                        ),
                        _view(
                            f"INNER_R{repeat}_K{inner_fold}_APPLICATION",
                            "INNER",
                            "APPLICATION",
                            partition_id,
                            inner_train,
                            outer_train,
                        ),
                    ]
                )
                stop = _stop_ids(
                    inner_train,
                    centers_by_id,
                    events_by_id,
                    outer_fold=outer_fold,
                    repeat=repeat,
                    inner_fold=inner_fold,
                    seed=seed,
                )
                fit = _ordered((item for item in inner_train if item not in stop), global_order)
                stop_ordered = _ordered(stop, global_order)
                stop_id = f"STOP_F{outer_fold}_R{repeat}_K{inner_fold}"
                stopping_rows.append(
                    {
                        "partition_id": stop_id,
                        "outer_fold": outer_fold,
                        "repeat": repeat,
                        "inner_fold": inner_fold,
                        "analysis_ids": fit,
                        "stop_ids": stop_ordered,
                        "application_ids": inner_train,
                        "consumers": ["GBM_COX", "XGBOOST_COX", "COXTIME_SET_A"],
                    }
                )
                views.extend(
                    [
                        _view(
                            f"STOP_R{repeat}_K{inner_fold}_ANALYSIS",
                            "STOP",
                            "ANALYSIS",
                            stop_id,
                            fit,
                            fit,
                        ),
                        _view(
                            f"STOP_R{repeat}_K{inner_fold}_APPLICATION",
                            "STOP",
                            "APPLICATION",
                            stop_id,
                            fit,
                            inner_train,
                        ),
                    ]
                )
        _require(len(views) == 62, "F1_VIEW_DENOMINATOR_INVALID")
        fold_views[str(outer_fold)] = views
        for view_ordinal, view in enumerate(views, start=1):
            for chain in range(1, 21):
                seed_rows.append(
                    {
                        "outer_fold": outer_fold,
                        "view": view["view_id"],
                        "repeat": (
                            int(view["partition_id"].split("_R", 1)[1].split("_", 1)[0])
                            if "_R" in view["partition_id"]
                            else 0
                        ),
                        "inner_fold": (
                            int(view["partition_id"].rsplit("K", 1)[1])
                            if "_K" in view["partition_id"]
                            else 0
                        ),
                        "chain": chain,
                        "seed": chain_base
                        + (outer_fold - 1) * 62 * 20
                        + (view_ordinal - 1) * 20
                        + chain,
                    }
                )

    _require(
        len(outer_rows) == 6
        and len(inner_rows) == 90
        and len(stopping_rows) == 90
        and len(center_stress_rows) == 30
        and len(sample_size_rows) == 72
        and len(seed_rows) == 7440
        and len({row["seed"] for row in seed_rows}) == 7440
        and len({_sha({key: row[key] for key in ("outer_fold", "view", "repeat", "inner_fold", "chain")}) for row in seed_rows}) == 7440,
        "F1_REGISTRY_DENOMINATOR_INVALID",
    )
    for outer_fold in range(1, 7):
        outer = next(row for row in outer_rows if row["outer_fold"] == outer_fold)
        for repeat in range(1, 4):
            rows = [
                row
                for row in inner_rows
                if row["outer_fold"] == outer_fold and row["repeat"] == repeat
            ]
            validation = [item for row in rows for item in row["validation_ids"]]
            _require(
                len(rows) == 5
                and len(validation) == len(set(validation))
                and set(validation) == set(outer["analysis_ids"]),
                "F1_INNER_VALIDATION_MEMBERSHIP_INVALID",
            )
    return {
        "schema_version": "1.0.0",
        "kind": "PADML_F1_SPLIT_SEED_REGISTRY",
        "authority_sha256": F1_AUTHORITY_SHA256,
        "row_order_sha256": _sha(stable_ids),
        "row_count": len(stable_ids),
        "outer": outer_rows,
        "inner": inner_rows,
        "stopping": stopping_rows,
        "center_stress": center_stress_rows,
        "sample_size": sample_size_rows,
        "views": fold_views,
        "seeds": seed_rows,
    }


def view_row_ids(
    registry: Mapping[str, Any], outer_fold: int, view_id: str
) -> tuple[list[str], list[str]]:
    _require(outer_fold in range(1, 7), "F1_VIEW_FOLD_INVALID")
    views = registry["views"].get(str(outer_fold))
    _require(type(views) is list, "F1_VIEW_REGISTRY_MISSING")
    matches = [row for row in views if row["view_id"] == view_id]
    _require(len(matches) == 1, "F1_VIEW_ID_INVALID")
    view = matches[0]
    source_name = {"OUTER": "outer", "INNER": "inner", "STOP": "stopping"}[view["kind"]]
    partitions = [
        row for row in registry[source_name] if row["partition_id"] == view["partition_id"]
    ]
    _require(len(partitions) == 1, "F1_VIEW_PARTITION_INVALID")
    partition = partitions[0]
    analysis = list(partition["analysis_ids"])
    rows = analysis if view["role"] == "ANALYSIS" else list(partition["application_ids"])
    _require(
        view["analysis_ids_sha256"] == _sha(analysis)
        and view["row_ids_sha256"] == _sha(rows)
        and view["row_count"] == len(rows),
        "F1_VIEW_IDENTITY_INVALID",
    )
    return analysis, rows


def compile_binding_contract(
    covariates_csv: bytes,
    response_csv: bytes,
    *,
    workbook_sha256: str,
    enforce_formal_denominator: bool = True,
) -> dict[str, Any]:
    validate_sha256(workbook_sha256, "workbook_sha256")
    covariates = list(csv.DictReader(io.StringIO(covariates_csv.decode("utf-8-sig"))))
    responses = list(csv.DictReader(io.StringIO(response_csv.decode("utf-8-sig"))))
    _require(covariates and responses, "F1_BINDING_ROWS_EMPTY")
    covariate_columns = list(covariates[0])
    response_columns = list(responses[0])
    authority = load_f1_authority()
    handoff = authority["science"]["mice"]["private_handoff"]["columns"]
    _require(
        covariate_columns == handoff
        and not (_FORBIDDEN_APPLICATION_COLUMNS & set(covariate_columns))
        and response_columns
        == ["Patient_ID", "All_Cause_Death", "Death_Followup_months"],
        "F1_BINDING_COLUMN_CONTRACT_INVALID",
    )
    ids = [row["Patient_ID"] for row in covariates]
    response_ids = [row["Patient_ID"] for row in responses]
    _require(ids == response_ids and len(ids) == len(set(ids)), "F1_BINDING_ROW_IDENTITY_INVALID")
    if enforce_formal_denominator:
        _require(len(ids) == 2124, "F1_BINDING_FORMAL_DENOMINATOR_INVALID")
    centers: dict[str, int] = {}
    events: dict[str, int] = {}
    for covariate, response in zip(covariates, responses, strict=True):
        patient_id = covariate["Patient_ID"]
        try:
            center = int(covariate["Center"])
            event = int(response["All_Cause_Death"])
            followup = float(response["Death_Followup_months"])
        except ValueError as exc:
            raise ContractError("F1_BINDING_RESPONSE_DOMAIN_INVALID") from exc
        _require(event in {0, 1} and followup > 0, "F1_BINDING_RESPONSE_DOMAIN_INVALID")
        centers[patient_id] = center
        events[patient_id] = event
    registry = compile_split_registry(ids, centers, events)
    return {
        "schema_version": "1.0.0",
        "kind": "PADML_F1_BINDING_CONTRACT",
        "authority_sha256": F1_AUTHORITY_SHA256,
        "workbook_sha256": workbook_sha256,
        "covariates_sha256": sha256_bytes(covariates_csv),
        "response_seal_sha256": sha256_bytes(response_csv),
        "covariate_columns": covariate_columns,
        "response_columns": response_columns,
        "registry": registry,
    }


def _file_record(path: Path) -> dict[str, Any]:
    return {"sha256": sha256_file(path), "size_bytes": path.stat().st_size}


def _run_r(spec: Mapping[str, Any], scratch: Path, repo_root: Path) -> None:
    spec_path = scratch / "spec.json"
    spec_path.write_bytes(canonical_json_bytes(dict(spec)))
    environment = dict(os.environ)
    environment.update(THREAD_ENV)
    completed = subprocess.run(
        [RSCRIPT_EXECUTABLE, str(repo_root / "kernels/f1_nested_mice.R"), str(spec_path)],
        cwd=scratch,
        env=environment,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        check=False,
        timeout=12 * 60 * 60,
    )
    if completed.returncode == 0:
        return
    tokens = sorted(set(_TYPED_F1.findall((completed.stderr or "") + (completed.stdout or ""))))
    raise ContractError(tokens[0] if len(tokens) == 1 else "F1_R_EXECUTION_FAILED")


def _run_mice_phase_task(job):
    """One original chain or joint reader in the existing flat scientific pool."""
    from . import runtime
    spec_path, root = Path(job["spec_path"]), Path(job["spec_path"]).parent
    _require(sha256_file(spec_path) == job["spec_sha256"], "F1_MICE_PHASE_SPEC_DRIFT")
    spec = strict_json_bytes(spec_path.read_bytes())
    phase = job["phase"]
    args = ([phase, str(spec_path)] if job["entry"] == "F5" else [str(spec_path), phase])
    if phase == "CHAIN":
        args += [str(job["checkpoint"]), str(job["chain_index"])]
    remaining = (runtime._ACTIVE_TASK_DEADLINE - runtime.monotonic()
                 if runtime._ACTIVE_TASK_DEADLINE is not None else 12 * 3600)
    _require(remaining > 0, "BOUNDED_SPAWN_TASK_DEADLINE_EXCEEDED")
    environment = {**os.environ, **THREAD_ENV}
    if job.get("r_library"):
        environment["R_LIBS_USER"] = job["r_library"]
    completed = subprocess.run([*job["command_prefix"], *args], cwd=root, env=environment,
        capture_output=True, text=True, check=False, timeout=remaining)
    if completed.returncode:
        # One original log per view, not a directory/log for every chain phase.
        for name, value in (("stdout.txt", completed.stdout), ("stderr.txt", completed.stderr)):
            with (root / name).open("a") as stream:
                stream.write(value or "")
        tokens = sorted(set(_TYPED_F1.findall((completed.stderr or "") + (completed.stdout or ""))))
        raise ContractError(tokens[0] if len(tokens) == 1 else "F1_R_EXECUTION_FAILED")
    prefix = "PADML_MICE_PHASE_RESULT="
    lines = [line[len(prefix):] for line in completed.stdout.splitlines() if line.startswith(prefix)]
    _require(len(lines) == 1, "F1_MICE_PHASE_RESULT_INVALID")
    result = strict_json_bytes(lines[0].encode())
    _require(result.get("view_id") == spec["view"]["view_id"], "F1_MICE_PHASE_RESULT_INVALID")
    if phase == "CHAIN":
        _require(result.get("status") == "CHAIN_CHECKPOINT" and result.get("chain_index") == job["chain_index"]
            and result.get("iteration") == job["checkpoint"]
            and result.get("root_seed") == spec["chain_seeds"][job["chain_index"] - 1], "F1_MICE_PHASE_RESULT_INVALID")
    else:
        _require(result.get("status") in {"VIEW_OUTPUT_READY", "NEEDS_CHECKPOINT"}, "F1_MICE_PHASE_RESULT_INVALID")
    if phase == 'CHAIN':
        runtime.advise_completed_io([root / 'native' / f"imp{job['chain_index']:02d}.rds"])
    return {**result, "spec_sha256": job["spec_sha256"]}


def _coordinate_mice_phases(prepared, policy, root, estimates, deadline):
    """Parent-only continuation; current_ready_pool owns every scientific leaf."""
    from .runtime import current_ready_pool, admit_stage
    _require(current_ready_pool() is not None, "F1_MICE_SHARED_POOL_REQUIRED")
    checkpoint = 0
    while True:
        admission = admit_stage(policy, root, legal_tasks=1, **estimates,
            task_disk_bytes=[(estimates["retained_bytes"], estimates["publication_bytes"])])
        result, = _bounded_ordered_spawn(_run_mice_phase_task, [{**prepared, "phase": "GATHER"}],
            selected_slots=admission["admitted_worker_ceiling"], task_deadlines=deadline)
        if result["status"] == "VIEW_OUTPUT_READY":
            _require(result.get("native_objects_validated") is True, "F1_MICE_PHASE_RESULT_INVALID")
            return result
        indices, next_checkpoint = result.get("chain_indices"), result.get("checkpoint")
        _require(isinstance(indices, list) and indices and indices == sorted(set(indices))
            and all(type(i) is int and i in range(1, 21) for i in indices)
            and next_checkpoint in (30, 40, 50) and next_checkpoint > checkpoint, "F1_MICE_PHASE_RESULT_INVALID")
        checkpoint = next_checkpoint
        jobs = [{**prepared, "phase": "CHAIN", "chain_index": i, "checkpoint": checkpoint} for i in indices]
        admission = admit_stage(policy, root, legal_tasks=len(jobs), **estimates)
        results = _bounded_ordered_spawn(_run_mice_phase_task, jobs,
            selected_slots=admission["admitted_worker_ceiling"], task_deadlines=[deadline[0]] * len(jobs))
        _require([r["chain_index"] for r in results] == indices, "F1_MICE_CHAIN_COVERAGE_INVALID")

def _run_r_view_task(task: tuple[dict[str, Any], str, str]) -> str:
    """Execute one sealed F1 view; the parent alone packages ordered results."""

    spec, scratch, repo_root = task
    _run_r(spec, Path(scratch), Path(repo_root))
    return str(spec["view"]["view_id"])


def _canonicalize_json(path: Path, label: str) -> dict[str, Any]:
    value = strict_json_bytes(path.read_bytes(), label)
    _require(type(value) is dict, f"{label}_NOT_OBJECT")
    path.write_bytes(canonical_json_bytes(value))
    return value


def _subset_csv(data: bytes, row_ids: list[str], target: Path) -> None:
    reader = csv.DictReader(io.StringIO(data.decode("utf-8-sig")))
    rows = {row["Patient_ID"]: row for row in reader}
    _require(len(rows) == len(row_ids) or set(row_ids).issubset(rows), "F1_SUBSET_ROW_SET_INVALID")
    _require(reader.fieldnames is not None, "F1_SUBSET_HEADER_INVALID")
    stream = io.StringIO(newline="")
    writer = csv.DictWriter(stream, fieldnames=reader.fieldnames, lineterminator="\n")
    writer.writeheader()
    for patient_id in row_ids:
        _require(patient_id in rows, "F1_SUBSET_ROW_MISSING")
        writer.writerow(rows[patient_id])
    target.write_bytes(stream.getvalue().encode("utf-8"))


def execute_data_binding(
    capsule_path: Path,
    capsule: Mapping[str, Any],
    request: Mapping[str, Any],
    scratch: Path,
    repo_root: Path,
) -> Path:
    _require(request["plan"]["action"] == "F1_DATA_BINDING_V2", "F1_DATA_BINDING_ACTION_INVALID")
    common = capsule["input"]["common_input"]
    common_path = capsule_path.parent / F1_COMMON_INPUT_NAME
    _require(
        common_path.is_file()
        and not common_path.is_symlink()
        and common_path.stat().st_size == common["size_bytes"]
        and sha256_file(common_path) == common["sha256"],
        "F1_COMMON_INPUT_IDENTITY_INVALID",
    )
    extracted = scratch / "common"
    extract_safe_zip(
        common_path,
        extracted,
        expected_members={"manifest.json", F1_WORKBOOK_MEMBER},
        max_member_bytes=16 * 1024 * 1024,
        max_total_bytes=20 * 1024 * 1024,
    )
    workbook = extracted / F1_WORKBOOK_MEMBER
    _require(
        workbook.stat().st_size == capsule["input"]["workbook"]["size_bytes"]
        and sha256_file(workbook) == request["identities"]["input"],
        "F1_WORKBOOK_IDENTITY_INVALID",
    )
    prepared = scratch / "prepared"
    prepared.mkdir()
    _run_r(
        {
            "mode": "PREPARE",
            "authority_path": str(repo_root / "science/authority.json"),
            "workbook_path": str(workbook),
            "output_dir": str(prepared),
        },
        scratch,
        repo_root,
    )
    covariates = prepared / "covariates.csv"
    response = prepared / "response-seal.csv"
    summary = prepared / "summary.json"
    _require(
        covariates.is_file() and response.is_file() and summary.is_file(),
        "F1_PREPARE_OUTPUT_MISSING",
    )
    summary_value = _canonicalize_json(summary, "f1-prepare-summary")
    contract = compile_binding_contract(
        covariates.read_bytes(),
        response.read_bytes(),
        workbook_sha256=request["identities"]["input"],
    )
    contract_path = prepared / "contract.json"
    contract_path.write_bytes(canonical_json_bytes(contract))
    members = {
        "binding/contract.json": contract_path,
        "binding/covariates.csv": covariates,
        "binding/response-seal.csv": response,
    }
    manifest = {
        "schema_version": "1.0.0",
        "kind": "PADML_F1_DATA_BINDING_PAYLOAD",
        "status": "PASS",
        "authority_sha256": F1_AUTHORITY_SHA256,
        "workbook_sha256": request["identities"]["input"],
        "row_count": contract["registry"]["row_count"],
        "view_count": sum(len(value) for value in contract["registry"]["views"].values()),
        "seed_count": len(contract["registry"]["seeds"]),
        "prepare_summary_sha256": sha256_bytes(canonical_json_bytes(summary_value)),
        "members": {
            name: _file_record(path) for name, path in sorted(members.items())
        },
        **execution_result_contract(request["plan"]),
    }
    manifest_path = prepared / "manifest.json"
    manifest_path.write_bytes(canonical_json_bytes(manifest))
    payload = scratch / "data-binding-payload.zip"
    write_deterministic_zip(payload, {"manifest.json": manifest_path, **members})
    return payload


def _extract_completed_artifact(
    request: Mapping[str, Any], result_path: Path, destination: Path
) -> tuple[dict[str, Any], Path]:
    expected_artifact = request["artifacts"][0]
    extracted = destination / "result"
    extract_safe_zip(
        result_path,
        extracted,
        expected_members={"manifest.json", expected_artifact["relative_path"]},
        max_member_bytes=64 * 1024 * 1024 * 1024,
        max_total_bytes=64 * 1024 * 1024 * 1024,
    )
    raw_manifest = (extracted / "manifest.json").read_bytes()
    result = validate_envelope(strict_json_bytes(raw_manifest, "f1-result-manifest"))
    _require(
        canonical_json_bytes(result) == raw_manifest
        and result["kind"] == "result"
        and result["terminal"]["status"] == "COMPLETED"
        and result["unit_id"] == request["unit_id"]
        and result["transaction_id"] == request["transaction_id"]
        and len(result["artifacts"]) == 1,
        "F1_DEPENDENCY_RESULT_INVALID",
    )
    _validate_result_request_binding(request, result)
    artifact = extracted / result["artifacts"][0]["relative_path"]
    _require(
        result["artifacts"][0]["sha256"] == sha256_file(artifact)
        and result["artifacts"][0]["size_bytes"] == artifact.stat().st_size,
        "F1_DEPENDENCY_ARTIFACT_INVALID",
    )
    return result, artifact


def _load_binding_payload(
    request: Mapping[str, Any], result_path: Path, destination: Path
) -> tuple[dict[str, Any], bytes, bytes]:
    _, payload = _extract_completed_artifact(request, result_path, destination)
    entries = read_safe_zip(
        payload,
        expected_members={
            "manifest.json",
            "binding/contract.json",
            "binding/covariates.csv",
            "binding/response-seal.csv",
        },
        max_member_bytes=64 * 1024 * 1024,
        max_total_bytes=128 * 1024 * 1024,
    )
    manifest = strict_json_bytes(entries["manifest.json"], "binding.manifest")
    contract = strict_json_bytes(entries["binding/contract.json"], "binding.contract")
    _require(
        canonical_json_bytes(manifest) == entries["manifest.json"]
        and canonical_json_bytes(contract) == entries["binding/contract.json"]
        and manifest["kind"] == "PADML_F1_DATA_BINDING_PAYLOAD",
        "F1_BINDING_PAYLOAD_INVALID",
    )
    expected_contract = compile_binding_contract(
        entries["binding/covariates.csv"],
        entries["binding/response-seal.csv"],
        workbook_sha256=request["identities"]["input"],
    )
    _require(contract == expected_contract, "F1_BINDING_CONTRACT_INVALID")
    for name, record in manifest["members"].items():
        _require(
            record
            == {
                "sha256": sha256_bytes(entries[name]),
                "size_bytes": len(entries[name]),
            },
            f"F1_BINDING_MEMBER_INVALID:{name}",
        )
    return contract, entries["binding/covariates.csv"], entries["binding/response-seal.csv"]


def _view_seed_rows(registry: Mapping[str, Any], outer_fold: int, view_id: str) -> list[dict[str, Any]]:
    rows = [
        row
        for row in registry["seeds"]
        if row["outer_fold"] == outer_fold and row["view"] == view_id
    ]
    _require(len(rows) == 20 and [row["chain"] for row in rows] == list(range(1, 21)), "F1_VIEW_SEED_SET_INVALID")
    return rows


def complete_data_passthrough(summary):
    return (summary.get("completion_mode") == "COMPLETE_DATA_PASSTHROUGH"
        and type(summary.get("active_target_count")) is int and summary["active_target_count"] == 0
        and type(summary.get("actual_mice_chains")) is int and summary["actual_mice_chains"] == 0
        and summary.get("rng_consumed") is False and summary.get("final_iteration") == 0
        and summary.get("convergence_max_psrf") is None
        and summary.get("analysis_auxiliary_predictor_edges") == 0)


def mice_terminal_valid(summary):
    if "completion_mode" in summary:
        return complete_data_passthrough(summary)
    iteration, psrf = summary.get('final_iteration'), summary.get('convergence_max_psrf')
    return (type(iteration) is int and iteration in {30, 40, 50}
        and type(summary.get('active_target_count')) is int and summary['active_target_count'] > 0
        and type(psrf) in {float, int} and math.isfinite(psrf)
        and 0 <= psrf < (1.2 if iteration == 50 else 1.1))


def formula_value(row, rule):
    try:
        operands = [float(row[name]) for name in rule['numerator'] + rule['denominator']]
        if not all(math.isfinite(x) and x > 0 for x in operands):
            return None
        numerator = math.prod(float(row[name]) for name in rule['numerator'])
        denominator = math.prod(float(row[name]) for name in rule['denominator'])
        value = (numerator / denominator) ** rule.get('power', 1) * rule['factor'] / rule.get('divisor', 1)
        return value if math.isfinite(value) and value > 0 else None
    except (KeyError, TypeError, ValueError, ZeroDivisionError, OverflowError):
        return None


def effective_mice_rows(rows, science=None):
    """Same one-pass observed-snapshot formulas as the native MICE entry."""
    science = science or load_f1_authority()['science']['mice']
    policy = science['formula_completion']
    result = {}
    for pid, source in rows.items():
        row = dict(source)
        for target, rules in policy['rules'].items():
            if target not in row or str(row[target]).strip():
                continue
            candidates = [v for rule in rules if (v := formula_value(source, rule)) is not None]
            if candidates and all(math.isclose(x, candidates[0], rel_tol=policy['relative_agreement_tolerance'],
                                              abs_tol=0) for x in candidates):
                row[target] = format(candidates[0], '.17g')
        result[pid] = row
    return result


def validate_mice_continuation(value, summary, chain_seeds, active):
    """Validate the actual stopping coordinate and its complete terminal grid."""
    iteration = summary['final_iteration']
    _require(mice_terminal_valid(summary) and set(value) == {'initial_iteration', 'continuation_iterations',
        'continuation_increment', 'chain_seeds', 'final_iterations', 'terminal_diagnostics'},
        'F1_MICE_CONTINUATION_INVALID')
    expected = {'initial_iteration':30 if iteration else 0,
        'continuation_iterations':[i for i in (40, 50) if i <= iteration],
        'continuation_increment':10 if iteration else 0, 'chain_seeds':chain_seeds,
        'final_iterations':[iteration] * len(chain_seeds)}
    _require({k:value[k] for k in expected} == expected, 'F1_MICE_CONTINUATION_INVALID')
    diagnostics = value['terminal_diagnostics']
    window = load_f1_authority()['science']['mice']['convergence']['terminal_window_iterations']
    coordinates = {(i, name, parameter) for i in range(iteration-window+1, iteration+1)
                   for name in active for parameter in ('mean', 'sd')} if iteration else set()
    _require(isinstance(diagnostics, list) and len(diagnostics) == len(coordinates)
        and all(isinstance(r, dict) and set(r) == {'.it', 'vrb', 'parameter', 'psrf', 'ac'}
            and type(r['.it']) is int and all(type(r[k]) in {int, float} and math.isfinite(r[k])
            for k in ('psrf', 'ac')) for r in diagnostics)
        and {(r['.it'], r['vrb'], r['parameter']) for r in diagnostics} == coordinates,
        'F1_MICE_CONVERGENCE_DIAGNOSTIC_DOMAIN_INVALID')
    _require((max(r['psrf'] for r in diagnostics) if diagnostics else None) == summary['convergence_max_psrf'],
             'F1_MICE_CONVERGENCE_SUMMARY_DRIFT')


def _package_view(
    view_output: Path,
    view: Mapping[str, Any],
    outer_fold: int,
    seed_rows: list[dict[str, Any]],
    target: Path,
    *,
    expected_columns: list[str] | None = None,
    expected_row_ids: list[str] | None = None,
) -> dict[str, Any]:
    summary_path = view_output / "summary.json"
    summary = _canonicalize_json(summary_path, f"{view['view_id']}.summary")
    _require(
        mice_terminal_valid(summary)
        and summary.get("kind") == "PADML_F1_MICE_VIEW_SUMMARY"
        and summary.get("status") == "PASS"
        and summary.get("view_id") == view["view_id"]
        and summary.get("role") == view["role"]
        and summary.get("outer_fold") == outer_fold
        and summary.get("row_count") == view["row_count"]
        and summary.get("row_ids_sha256") == view["row_ids_sha256"]
        and summary.get("formal_m") == 20
        and summary.get("application_response_columns") == 0
        and summary.get("application_predictor_matrix_response_edges") == 0
        and type(summary.get("analysis_auxiliary_predictor_edges")) is int
        and (
            (summary["analysis_auxiliary_predictor_edges"] > 0 or complete_data_passthrough(summary))
            if view["role"] == "ANALYSIS"
            else summary["analysis_auxiliary_predictor_edges"] == 0
        ),
        "F1_VIEW_SUMMARY_INVALID",
    )
    members: dict[str, Path] = {}
    for index in range(1, 21):
        path = view_output / "imputations" / f"imp{index:02d}.csv"
        _require(path.is_file(), "F1_VIEW_IMPUTATION_MISSING")
        members[f"imputations/imp{index:02d}.csv"] = path
    for component in _CONFIGURATION_NAMES:
        path = view_output / "configuration" / f"{component}.json"
        value = _canonicalize_json(path, f"{view['view_id']}.{component}")
        _require(
            value.get("schema_version") == "1.0.0"
            and value.get("component") == component
            and value.get("view_id") == view["view_id"],
            f"F1_VIEW_CONFIGURATION_INVALID:{component}",
        )
        members[f"configuration/{component}.json"] = path
    manifest = {
        "schema_version": "1.0.0",
        "kind": "PADML_F1_MICE_VIEW",
        "status": "PASS",
        "outer_fold": outer_fold,
        "view": dict(view),
        "chain_seeds": seed_rows,
        "summary": summary,
        "members": {
            name: _file_record(path) for name, path in sorted(members.items())
        },
    }
    manifest_path = view_output / "manifest.json"
    manifest_path.write_bytes(canonical_json_bytes(manifest))
    if expected_columns is not None or expected_row_ids is not None:
        _require(expected_columns is not None and expected_row_ids is not None,
                 "F1_VIEW_VALIDATION_INPUT_MISSING")
        _validate_view_directory(view_output, view, seed_rows, expected_columns, expected_row_ids)
    write_deterministic_zip(target, {"manifest.json": manifest_path, **members})
    return {
        "view_id": view["view_id"],
        "relative_path": f"libraries/{view['view_id']}.zip",
        **_file_record(target),
        "row_count": view["row_count"],
        "row_ids_sha256": view["row_ids_sha256"],
    }


def execute_mice_fold(
    capsule: Mapping[str, Any],
    request: Mapping[str, Any],
    binding_result_path: Path,
    scratch: Path,
    repo_root: Path,
) -> Path:
    _require(request["plan"]["action"] == "F1_NESTED_MICE_FOLD_V2", "F1_MICE_FOLD_ACTION_INVALID")
    coordinates = {row["axis"]: row["value"] for row in request["plan"]["coordinates"]}
    outer_fold = coordinates.get("outer_fold")
    _require(type(outer_fold) is int and outer_fold in range(1, 7), "F1_MICE_FOLD_INVALID")
    binding_request = capsule["requests"]["data-binding"]
    binding_dir = scratch / "binding"
    binding_dir.mkdir()
    contract, covariates, response = _load_binding_payload(
        binding_request, binding_result_path, binding_dir
    )
    registry = contract["registry"]
    views = registry["views"][str(outer_fold)]
    libraries_dir = scratch / "libraries"
    libraries_dir.mkdir()
    prepared_views: list[
        tuple[dict[str, Any], list[dict[str, Any]], Path, Path]
    ] = []
    tasks: list[tuple[dict[str, Any], str, str]] = []
    for ordinal, view in enumerate(views, start=1):
        view_id = view["view_id"]
        analysis_ids, row_ids = view_row_ids(registry, outer_fold, view_id)
        view_root = scratch / f"view-{ordinal:02d}"
        view_root.mkdir()
        covariate_path = view_root / "covariates.csv"
        _subset_csv(covariates, row_ids, covariate_path)
        seed_rows = _view_seed_rows(registry, outer_fold, view_id)
        spec: dict[str, Any] = {
            "mode": "IMPUTE_VIEW",
            "authority_path": str(repo_root / "science/authority.json"),
            "variable_path": str(repo_root / "science/variable.csv"),
            "covariates_path": str(covariate_path),
            "output_dir": str(view_root / "output"),
            "chain_seeds": [row["seed"] for row in seed_rows],
            "view": {
                "view_id": view_id,
                "role": view["role"],
                "outer_fold": outer_fold,
                "analysis_ids": analysis_ids,
                "row_ids": row_ids,
                "row_ids_sha256": view["row_ids_sha256"],
            },
        }
        if view["role"] == "ANALYSIS":
            response_path = view_root / "response.csv"
            _subset_csv(response, analysis_ids, response_path)
            spec["response_path"] = str(response_path)
        library_path = libraries_dir / f"{view_id}.zip"
        prepared_views.append((dict(view), seed_rows, view_root, library_path))
        tasks.append((spec, str(view_root), str(repo_root)))

    execution = execution_contract(request["plan"])
    _require(
        execution["execution_mode"] == "PROCESS_POOL"
        and execution["engine_threads"] == 1
        and type(execution["threads"]) is int
        and execution["threads"] >= 1
        and execution["pool_workers"] == execution["threads"],
        "F1_EXECUTION_PROFILE_INVALID",
    )
    completed_ids = _bounded_ordered_spawn(
        _run_r_view_task,
        tasks,
        selected_slots=execution["pool_workers"],
    )
    _require(
        completed_ids == [view[0]["view_id"] for view in prepared_views],
        "F1_VIEW_EXECUTION_SET_INVALID",
    )

    library_records: list[dict[str, Any]] = []
    library_paths: dict[str, Path] = {}
    for view, seed_rows, view_root, library_path in prepared_views:
        record = _package_view(
            view_root / "output", view, outer_fold, seed_rows, library_path
        )
        library_records.append(record)
        library_paths[record["relative_path"]] = library_path
    _require(len(library_records) == 62, "F1_FOLD_LIBRARY_DENOMINATOR_INVALID")
    manifest = {
        "schema_version": "1.0.0",
        "kind": "PADML_F1_MICE_FOLD_PAYLOAD",
        "status": "PASS",
        "outer_fold": outer_fold,
        "binding_contract_sha256": _sha(contract),
        "library_count": 62,
        "completed_dataset_count": 1240,
        "libraries": library_records,
        **execution_result_contract(request["plan"]),
    }
    manifest_path = scratch / "fold-manifest.json"
    manifest_path.write_bytes(canonical_json_bytes(manifest))
    payload = scratch / f"mice-fold-{outer_fold}-payload.zip"
    write_deterministic_zip(
        payload,
        {"manifest.json": manifest_path, **library_paths},
        stored_members=set(library_paths),
    )
    return payload


def execute_mice_aggregate(
    request: Mapping[str, Any],
    validated_results: Mapping[str, Mapping[str, Any]],
    scratch: Path,
) -> Path:
    _require(request["plan"]["action"] == "F1_MICE_AGGREGATE_V2", "F1_MICE_AGGREGATE_ACTION_INVALID")
    _require(
        set(validated_results) == set(request["plan"]["depends_on"])
        and validated_results["data-binding"].get("status")
        in {"PASS", "CANDIDATE_VALID"},
        "F1_AGGREGATE_VALIDATED_SOURCE_SET_INVALID",
    )
    records: list[dict[str, Any]] = []
    for fold in range(1, 7):
        unit_id = f"mice-fold-{fold}"
        validated = validated_results[unit_id]
        source = validated.get("source_record")
        value = validated.get("value")
        _require(
            validated.get("status") in {"PASS", "CANDIDATE_VALID"}
            and isinstance(source, dict)
            and isinstance(value, dict)
            and value.get("kind") == "PADML_F1_MICE_FOLD_PAYLOAD"
            and value.get("outer_fold") == fold
            and value.get("library_count") == 62
            and value.get("completed_dataset_count") == 1240
            and source.get("unit_id") == unit_id
            and source.get("value_identity_sha256") == _sha(value),
            f"F1_AGGREGATE_VALIDATED_SOURCE_INVALID:{unit_id}",
        )
        records.append(
            {
                "unit_id": unit_id,
                "result_sha256": source["result_sha256"],
                "result_size_bytes": source["result_size_bytes"],
                "artifact_sha256": source["artifact_sha256"],
                "artifact_size_bytes": source["artifact_size_bytes"],
                "value_identity_sha256": source["value_identity_sha256"],
                "library_set_sha256": value["library_set_sha256"],
            }
        )
    registry = {
        "schema_version": "1.0.0",
        "kind": "PADML_F1_AGGREGATE_REGISTRY",
        "fold_count": 6,
        "library_count": 372,
        "completed_dataset_count": 7440,
        "folds": records,
    }
    registry_path = scratch / "registry.json"
    registry_path.write_bytes(canonical_json_bytes(registry))
    manifest = {
        "schema_version": "1.0.0",
        "kind": "PADML_F1_MICE_AGGREGATE_PAYLOAD",
        "status": "PASS",
        "registry_sha256": sha256_file(registry_path),
        "registry_size_bytes": registry_path.stat().st_size,
        "patient_rows": "FORBIDDEN",
        **execution_result_contract(request["plan"]),
    }
    manifest_path = scratch / "aggregate-manifest.json"
    manifest_path.write_bytes(canonical_json_bytes(manifest))
    payload = scratch / "mice-aggregate-payload.zip"
    write_deterministic_zip(
        payload,
        {"manifest.json": manifest_path, "aggregate/registry.json": registry_path},
    )
    return payload


def _validate_result_request_binding(
    request: Mapping[str, Any], result: Mapping[str, Any]
) -> None:
    for field in (
        "schema_version",
        "run_id",
        "stage_id",
        "unit_id",
        "transaction_id",
        "identities",
        "seed",
        "plan",
        "decision",
    ):
        _require(result.get(field) == request.get(field), "F1_RESULT_REQUEST_BINDING_INVALID")
    _require(result.get("kind") == "result", "F1_RESULT_KIND_INVALID")


def _validate_binding_payload(
    payload: Path,
    workbook_sha256: str,
    destination: Path,
    execution: Mapping[str, Any],
) -> tuple[dict[str, Any], dict[str, Any]]:
    extracted = destination / "binding-payload"
    extract_safe_zip(
        payload,
        extracted,
        expected_members={
            "manifest.json",
            "binding/contract.json",
            "binding/covariates.csv",
            "binding/response-seal.csv",
        },
        max_member_bytes=64 * 1024 * 1024,
        max_total_bytes=128 * 1024 * 1024,
    )
    raw_manifest = (extracted / "manifest.json").read_bytes()
    raw_contract = (extracted / "binding/contract.json").read_bytes()
    manifest = strict_json_bytes(raw_manifest, "binding.manifest")
    contract = strict_json_bytes(raw_contract, "binding.contract")
    covariates = (extracted / "binding/covariates.csv").read_bytes()
    response = (extracted / "binding/response-seal.csv").read_bytes()
    _require(
        canonical_json_bytes(manifest) == raw_manifest
        and canonical_json_bytes(contract) == raw_contract
        and manifest
        == {
            "schema_version": "1.0.0",
            "kind": "PADML_F1_DATA_BINDING_PAYLOAD",
            "status": "PASS",
            "authority_sha256": F1_AUTHORITY_SHA256,
            "workbook_sha256": workbook_sha256,
            "row_count": contract.get("registry", {}).get("row_count"),
            "view_count": 372,
            "seed_count": 7440,
            "prepare_summary_sha256": manifest.get("prepare_summary_sha256"),
            "members": manifest.get("members"),
            **dict(execution),
        },
        "F1_BINDING_MANIFEST_INVALID",
    )
    validate_sha256(manifest["prepare_summary_sha256"], "prepare_summary_sha256")
    expected_contract = compile_binding_contract(
        covariates, response, workbook_sha256=workbook_sha256
    )
    _require(contract == expected_contract, "F1_BINDING_CONTRACT_INVALID")
    raw_members = {
        "binding/contract.json": raw_contract,
        "binding/covariates.csv": covariates,
        "binding/response-seal.csv": response,
    }
    _require(
        manifest["members"]
        == {
            name: {"sha256": sha256_bytes(data), "size_bytes": len(data)}
            for name, data in sorted(raw_members.items())
        },
        "F1_BINDING_MEMBER_IDENTITY_INVALID",
    )
    return contract, {
        "kind": manifest["kind"],
        "row_count": manifest["row_count"],
        "view_count": manifest["view_count"],
        "seed_count": manifest["seed_count"],
        "binding_contract_sha256": sha256_bytes(raw_contract),
        "covariates_sha256": sha256_bytes(covariates),
        "response_seal_sha256": sha256_bytes(response),
    }


def _validate_imputation_csv(
    path: Path, expected_columns: list[str], expected_ids: list[str]
) -> None:
    nullable = set(load_f1_authority()['science']['mice']['formula_completion']['raw_only_nullable'])
    with path.open(encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        _require(
            reader.fieldnames == expected_columns
            and not (_FORBIDDEN_APPLICATION_COLUMNS & set(reader.fieldnames or [])),
            "F1_LIBRARY_COLUMN_SET_INVALID",
        )
        observed_ids: list[str] = []
        for row in reader:
            patient_id = row.get("Patient_ID", "")
            observed_ids.append(patient_id)
            _require(
                all(value not in {None, "NaN", "Inf", "-Inf"} and (value != "" or name in nullable)
                    for name, value in row.items()),
                "F1_LIBRARY_VALUE_INVALID",
            )
    _require(observed_ids == expected_ids, "F1_LIBRARY_ROW_IDENTITY_INVALID")


def _validate_view_library(
    library_path: Path,
    expected_view: Mapping[str, Any],
    expected_seed_rows: list[dict[str, Any]],
    expected_columns: list[str],
    expected_row_ids: list[str],
    destination: Path,
) -> dict[str, Any]:
    member_names = {
        "manifest.json",
        *(f"imputations/imp{index:02d}.csv" for index in range(1, 21)),
        *(f"configuration/{component}.json" for component in _CONFIGURATION_NAMES),
    }
    extract_safe_zip(
        library_path,
        destination,
        expected_members=member_names,
        max_member_bytes=128 * 1024 * 1024,
        max_total_bytes=3 * 1024 * 1024 * 1024,
    )
    return {
        **_validate_view_directory(destination, expected_view, expected_seed_rows,
                                  expected_columns, expected_row_ids),
        "library_sha256": sha256_file(library_path),
        "library_size_bytes": library_path.stat().st_size,
    }


def _validate_view_directory(
    destination: Path,
    expected_view: Mapping[str, Any],
    expected_seed_rows: list[dict[str, Any]],
    expected_columns: list[str],
    expected_row_ids: list[str],
) -> dict[str, Any]:
    """The same scientific consumer for fresh output and a recovered ZIP."""
    member_names = {
        "manifest.json",
        *(f"imputations/imp{index:02d}.csv" for index in range(1, 21)),
        *(f"configuration/{component}.json" for component in _CONFIGURATION_NAMES),
    }
    raw_manifest = (destination / "manifest.json").read_bytes()
    manifest = strict_json_bytes(raw_manifest, "f1-view.manifest")
    _require(
        canonical_json_bytes(manifest) == raw_manifest
        and manifest.get("schema_version") == "1.0.0"
        and manifest.get("kind") == "PADML_F1_MICE_VIEW"
        and manifest.get("status") == "PASS"
        and manifest.get("view") == expected_view
        and manifest.get("chain_seeds") == expected_seed_rows,
        "F1_VIEW_MANIFEST_INVALID",
    )
    members = manifest.get("members")
    _require(type(members) is dict and set(members) == member_names - {"manifest.json"}, "F1_VIEW_MEMBER_INDEX_INVALID")
    for name, record in members.items():
        path = destination / name
        _require(record == _file_record(path), f"F1_VIEW_MEMBER_IDENTITY_INVALID:{name}")
    for index in range(1, 21):
        _validate_imputation_csv(
            destination / f"imputations/imp{index:02d}.csv",
            expected_columns,
            expected_row_ids,
        )
    configurations: dict[str, dict[str, Any]] = {}
    for component in _CONFIGURATION_NAMES:
        path = destination / f"configuration/{component}.json"
        raw = path.read_bytes()
        value = strict_json_bytes(raw, component)
        _require(
            canonical_json_bytes(value) == raw
            and value.get("schema_version") == "1.0.0"
            and value.get("component") == component
            and value.get("view_id") == expected_view["view_id"],
            f"F1_VIEW_CONFIGURATION_INVALID:{component}",
        )
        configurations[component] = value
    method = configurations["ACTUAL_MICE_METHOD"].get("payload")
    matrix = configurations["ACTUAL_PREDICTOR_MATRIX"].get("payload")
    expected_configuration_names = [
        name for name in expected_columns if name != "Patient_ID"
    ]
    if expected_view["role"] == "ANALYSIS":
        expected_configuration_names.extend(["event_aux", "nelson_aalen_aux"])
    _require(
        isinstance(method, dict)
        and set(method) == {"names", "values"}
        and method["names"] == expected_configuration_names
        and isinstance(method["values"], list)
        and len(method["names"]) == len(method["values"])
        and isinstance(matrix, dict)
        and set(matrix) == {"row_names", "column_names", "values"}
        and matrix["row_names"] == method["names"] == expected_configuration_names
        and matrix["column_names"] == expected_configuration_names
        and isinstance(matrix["values"], list)
        and len(matrix["values"]) == len(matrix["row_names"]),
        "F1_VIEW_RESPONSE_EDGE_CONFIGURATION_INVALID",
    )
    if expected_view["role"] == "APPLICATION":
        _require(
            not (
                (
                    _FORBIDDEN_APPLICATION_COLUMNS
                    | {"event_aux", "nelson_aalen_aux"}
                )
                & set(expected_configuration_names)
            ),
            "F1_APPLICATION_RESPONSE_CONFIGURATION_REACHABLE",
        )
    active_rows = {
        index
        for index, value in enumerate(method["values"])
        if isinstance(value, str) and value != ""
    }
    response_columns = {
        index
        for index, name in enumerate(matrix["column_names"])
        if name in {"event_aux", "nelson_aalen_aux"}
    }
    _require(
        all(
            isinstance(row, list)
            and len(row) == len(matrix["column_names"])
            and all(type(item) is int and item in {0, 1} for item in row)
            for row in matrix["values"]
        ),
        "F1_VIEW_RESPONSE_EDGE_CONFIGURATION_INVALID",
    )
    analysis_edges = sum(
        matrix["values"][row][column]
        for row in active_rows
        for column in response_columns
    )
    application_edges = sum(
        row[column]
        for row in matrix["values"]
        for column in response_columns
    )
    summary = manifest.get("summary")
    _require(
        type(summary) is dict and mice_terminal_valid(summary)
        and summary.get("status") == "PASS"
        and summary.get("view_id") == expected_view["view_id"]
        and summary.get("row_count") == len(expected_row_ids)
        and summary.get("row_ids_sha256") == _sha(expected_row_ids)
        and summary.get("application_response_columns") == 0
        and summary.get("application_predictor_matrix_response_edges") == 0
        and type(summary.get("analysis_auxiliary_predictor_edges")) is int
        and (
            (summary["analysis_auxiliary_predictor_edges"] == analysis_edges
             and (analysis_edges > 0 or complete_data_passthrough(summary)))
            if expected_view["role"] == "ANALYSIS"
            else (
                not response_columns
                and application_edges == 0
                and summary["analysis_auxiliary_predictor_edges"]
                == analysis_edges
                == 0
            )
        ),
        "F1_VIEW_SUMMARY_INVALID",
    )
    if complete_data_passthrough(summary):
        _require(not active_rows and method["values"] == [""] * len(method["names"]), "F1_PASSTHROUGH_METHOD_INVALID")
        config = {name: strict_json_bytes((destination / "configuration" / (name + ".json")).read_bytes())["payload"]
                  for name in ("ACTUAL_BLOT", "ACTUAL_CONTINUATION_CONFIG")}
        _require(config["ACTUAL_BLOT"] == {"rows": []}
            and len({manifest["members"][f"imputations/imp{i:02d}.csv"]["sha256"] for i in range(1,21)}) == 1,
            "F1_PASSTHROUGH_VALUES_INVALID")
    validate_mice_continuation(configurations['ACTUAL_CONTINUATION_CONFIG']['payload'], summary,
        [r['seed'] for r in expected_seed_rows], [method['names'][i] for i in active_rows])
    return {
        "view_id": expected_view["view_id"],
        "row_count": len(expected_row_ids),
        "row_ids_sha256": _sha(expected_row_ids),
    }


def _validate_fold_payload(
    payload: Path,
    fold: int,
    binding_contract: Mapping[str, Any],
    destination: Path,
    execution: Mapping[str, Any],
) -> dict[str, Any]:
    registry = binding_contract["registry"]
    views = registry["views"][str(fold)]
    expected_members = {
        "manifest.json",
        *(f"libraries/{view['view_id']}.zip" for view in views),
    }
    extracted = destination / "fold-payload"
    extract_safe_zip(
        payload,
        extracted,
        expected_members=expected_members,
        max_member_bytes=64 * 1024 * 1024 * 1024,
        max_total_bytes=64 * 1024 * 1024 * 1024,
    )
    raw_manifest = (extracted / "manifest.json").read_bytes()
    manifest = strict_json_bytes(raw_manifest, "fold.manifest")
    _require(
        canonical_json_bytes(manifest) == raw_manifest
        and manifest.get("schema_version") == "1.0.0"
        and manifest.get("kind") == "PADML_F1_MICE_FOLD_PAYLOAD"
        and manifest.get("status") == "PASS"
        and manifest.get("outer_fold") == fold
        and manifest.get("binding_contract_sha256") == _sha(binding_contract)
        and manifest.get("library_count") == 62
        and manifest.get("completed_dataset_count") == 1240
        and {
            key: manifest.get(key)
            for key in ("threads", "pool_workers", "engine_threads")
        }
        == {
            key: execution[key]
            for key in ("threads", "pool_workers", "engine_threads")
        },
        "F1_FOLD_MANIFEST_INVALID",
    )
    library_index = manifest.get("libraries")
    _require(type(library_index) is list and len(library_index) == 62, "F1_FOLD_LIBRARY_INDEX_INVALID")
    indexed = {row.get("view_id"): row for row in library_index if type(row) is dict}
    _require(set(indexed) == {view["view_id"] for view in views}, "F1_FOLD_LIBRARY_SET_INVALID")
    summaries: list[dict[str, Any]] = []
    columns = list(binding_contract["covariate_columns"])
    for ordinal, view in enumerate(views, start=1):
        path = extracted / f"libraries/{view['view_id']}.zip"
        record = indexed[view["view_id"]]
        _require(
            record
            == {
                "view_id": view["view_id"],
                "relative_path": f"libraries/{view['view_id']}.zip",
                "sha256": sha256_file(path),
                "size_bytes": path.stat().st_size,
                "row_count": view["row_count"],
                "row_ids_sha256": view["row_ids_sha256"],
            },
            f"F1_FOLD_LIBRARY_RECORD_INVALID:{view['view_id']}",
        )
        _, row_ids = view_row_ids(registry, fold, view["view_id"])
        summaries.append(
            _validate_view_library(
                path,
                view,
                _view_seed_rows(registry, fold, view["view_id"]),
                columns,
                row_ids,
                destination / f"library-{ordinal:02d}",
            )
        )
    return {
        "kind": manifest["kind"],
        "outer_fold": fold,
        "binding_contract_sha256": manifest["binding_contract_sha256"],
        "library_count": 62,
        "completed_dataset_count": 1240,
        "library_set_sha256": _sha(summaries),
        **dict(execution),
    }


def _validate_aggregate_payload(
    payload: Path,
    admitted_sources: Mapping[str, Mapping[str, Any]],
    destination: Path,
    execution: Mapping[str, Any],
) -> dict[str, Any]:
    extracted = destination / "aggregate-payload"
    extract_safe_zip(
        payload,
        extracted,
        expected_members={"manifest.json", "aggregate/registry.json"},
        max_member_bytes=16 * 1024 * 1024,
        max_total_bytes=32 * 1024 * 1024,
    )
    raw_manifest = (extracted / "manifest.json").read_bytes()
    raw_registry = (extracted / "aggregate/registry.json").read_bytes()
    manifest = strict_json_bytes(raw_manifest, "aggregate.manifest")
    registry = strict_json_bytes(raw_registry, "aggregate.registry")
    expected_units = [f"mice-fold-{fold}" for fold in range(1, 7)]
    _require(
        canonical_json_bytes(manifest) == raw_manifest
        and canonical_json_bytes(registry) == raw_registry
        and manifest
        == {
            "schema_version": "1.0.0",
            "kind": "PADML_F1_MICE_AGGREGATE_PAYLOAD",
            "status": "PASS",
            "registry_sha256": sha256_bytes(raw_registry),
            "registry_size_bytes": len(raw_registry),
            "patient_rows": "FORBIDDEN",
            **dict(execution),
        }
        and registry.get("schema_version") == "1.0.0"
        and registry.get("kind") == "PADML_F1_AGGREGATE_REGISTRY"
        and registry.get("fold_count") == 6
        and registry.get("library_count") == 372
        and registry.get("completed_dataset_count") == 7440
        and [row.get("unit_id") for row in registry.get("folds", [])] == expected_units,
        "F1_AGGREGATE_PAYLOAD_INVALID",
    )
    for row in registry["folds"]:
        source = admitted_sources.get(row["unit_id"])
        _require(
            source is not None
            and row["result_sha256"] == source["result_sha256"]
            and row["artifact_sha256"] == source["artifact_sha256"],
            f"F1_AGGREGATE_SOURCE_INVALID:{row['unit_id']}",
        )
        _require(
            row.get("result_size_bytes") == source.get("result_size_bytes")
            and row.get("artifact_size_bytes") == source.get("artifact_size_bytes")
            and row.get("value_identity_sha256")
            == source.get("value_identity_sha256")
            and isinstance(row.get("library_set_sha256"), str),
            f"F1_AGGREGATE_SOURCE_SUMMARY_INVALID:{row['unit_id']}",
        )
        validate_sha256(
            row["library_set_sha256"], f"{row['unit_id']}.library_set_sha256"
        )
    _require("Patient_ID" not in raw_manifest.decode() and "Patient_ID" not in raw_registry.decode(), "F1_AGGREGATE_PATIENT_ROWS_PRESENT")
    return {
        "kind": manifest["kind"],
        "registry_sha256": manifest["registry_sha256"],
        "fold_count": 6,
        "library_count": 372,
        "completed_dataset_count": 7440,
        **dict(execution),
    }


def validate_f1_unit_result(
    request: Mapping[str, Any],
    result_path: Path,
    authority: Mapping[str, Any],
    *,
    binding_contract: Mapping[str, Any] | None = None,
    admitted_sources: Mapping[str, Mapping[str, Any]] | None = None,
    authority_mode: str = "LOCAL_SOLE_VALIDATOR",
) -> dict[str, Any]:
    _require(
        authority == load_f1_authority()
        and authority_mode in {"LOCAL_SOLE_VALIDATOR", "REMOTE_CANDIDATE"}
        and result_path.is_absolute()
        and result_path.is_file()
        and not result_path.is_symlink()
        and result_path.resolve(strict=True) == result_path,
        "F1_RESULT_ADMISSION_INPUT_INVALID",
    )
    manifest_bytes, names = inspect_safe_zip_manifest(result_path)
    result = validate_envelope(
        strict_json_bytes(manifest_bytes, "f1-result-manifest")
    )
    _validate_result_request_binding(request, result)
    if result["terminal"]["status"] != "COMPLETED":
        _require(names == ("manifest.json",), "F1_NONCOMPLETED_RESULT_HAS_SIDECAR")
        return {
            "status": "NONCOMPLETED",
            "result_sha256": sha256_file(result_path),
            "envelope": result,
            "value": None,
            "evidence": None,
        }
    with tempfile.TemporaryDirectory(
        dir=result_path.parent, prefix=f".{request['unit_id']}-validation-"
    ) as temporary:
        root = Path(temporary).resolve()
        result, artifact = _extract_completed_artifact(request, result_path, root)
        action = request["plan"]["action"]
        execution = execution_result_contract(request["plan"])
        private_contract: dict[str, Any] | None = None
        if action == "F1_DATA_BINDING_V2":
            private_contract, value = _validate_binding_payload(
                artifact, request["identities"]["input"], root, execution
            )
        elif action == "F1_NESTED_MICE_FOLD_V2":
            _require(binding_contract is not None, "F1_FOLD_BINDING_CONTRACT_REQUIRED")
            coordinates = {row["axis"]: row["value"] for row in request["plan"]["coordinates"]}
            value = _validate_fold_payload(
                artifact,
                coordinates["outer_fold"],
                binding_contract,
                root,
                execution,
            )
        elif action == "F1_MICE_AGGREGATE_V2":
            _require(admitted_sources is not None, "F1_AGGREGATE_SOURCES_REQUIRED")
            value = _validate_aggregate_payload(
                artifact, admitted_sources, root, execution
            )
        else:
            raise ContractError("F1_ACTION_INVALID")
        artifact_record = result["artifacts"][0]
        source_record = {
            "unit_id": request["unit_id"],
            "transaction_id": request["transaction_id"],
            "result_sha256": sha256_file(result_path),
            "result_size_bytes": result_path.stat().st_size,
            "artifact_sha256": artifact_record["sha256"],
            "artifact_size_bytes": artifact_record["size_bytes"],
            "value_identity_sha256": _sha(value),
        }
        evidence = None
        if authority_mode == "LOCAL_SOLE_VALIDATOR":
            evidence = {
                "schema_version": "1.0.0",
                "kind": "PADML_F1_UNIT_VALIDATOR_EVIDENCE",
                "status": "PASS",
                **source_record,
            }
        return {
            "status": "PASS" if evidence is not None else "CANDIDATE_VALID",
            "result_sha256": source_record["result_sha256"],
            "science_projection_sha256": science_projection_sha256(value),
            "value": value,
            "binding_contract": private_contract,
            "source_record": source_record,
            "evidence": evidence,
            "evidence_sha256": None if evidence is None else _sha(evidence),
        }


def validate_f1_stage_values(
    validated_results: Mapping[str, Mapping[str, Any]]
) -> dict[str, Any]:
    expected = {
        "data-binding",
        *(f"mice-fold-{fold}" for fold in range(1, 7)),
        "mice-aggregate",
    }
    _require(
        set(validated_results) == expected
        and all(row.get("status") == "PASS" for row in validated_results.values()),
        "F1_STAGE_RESULT_SET_INVALID",
    )
    aggregate = validated_results["mice-aggregate"]["value"]
    _require(
        aggregate.get("fold_count") == 6
        and aggregate.get("library_count") == 372
        and aggregate.get("completed_dataset_count") == 7440,
        "F1_STAGE_DENOMINATOR_INVALID",
    )
    rows = [
        {
            "unit_id": unit_id,
            "result_sha256": validated_results[unit_id]["source_record"]["result_sha256"],
            "artifact_sha256": validated_results[unit_id]["source_record"]["artifact_sha256"],
            "validator_evidence_sha256": validated_results[unit_id]["evidence_sha256"],
        }
        for unit_id in sorted(expected)
    ]
    return {
        "schema_version": "1.0.0",
        "kind": "PADML_F1_STAGE_VALIDATION",
        "status": "PASS",
        "unit_count": 8,
        "fold_count": 6,
        "library_count": 372,
        "completed_dataset_count": 7440,
        "unit_set_sha256": _sha(rows),
        "units": rows,
        "patient_rows": "FORBIDDEN",
    }


__all__ = [
    "compile_binding_contract",
    "compile_split_registry",
    "execute_data_binding",
    "execute_mice_aggregate",
    "execute_mice_fold",
    "validate_f1_stage_values",
    "validate_f1_unit_result",
    "view_row_ids",
]
