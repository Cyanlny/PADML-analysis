"""Current-batch raw inputs for the existing whole-unit scientific pipeline.

This module owns no queue or acceptance service. It binds the workbook and
publishes the original split-local MICE views in the existing context directory.
"""
from __future__ import annotations

from .runtime import MIN_WORKER_MEMORY_BYTES

from .carriers import open_carrier

import csv
import copy
import io
import os
import shutil
import tempfile
from collections import OrderedDict
from threading import Lock
from pathlib import Path
from typing import Any, Mapping

from .bundle import ContractError, canonical_json_bytes, sha256_bytes, sha256_file, strict_json_bytes, validate_sha256

RUN_KIND = "PADML_INTEGRATED_RAW_RUN_V1"
BINDING_KIND = "PADML_CURRENT_RAW_BINDING_V1"
_QUALIFIED: dict[tuple, dict] = {}
_BYTE_PINS: OrderedDict[tuple, dict] = OrderedDict()
_BYTE_PINS_LOCK = Lock()


def _require(ok, reason):
    if not ok:
        raise ContractError(reason)


def _sha(value):
    return sha256_bytes(canonical_json_bytes(value))


def is_integrated(run: Mapping[str, Any]) -> bool:
    return run.get("kind") == RUN_KIND


def _compact_gbm_retained_job(job):
    from .f5 import (_current_q_gbm_projection, _current_q_retire_gbm, _current_q_import,
        _current_q_gbm_h36_members, _current_q_json)
    from .reports import _persist_published
    root, partition = Path(job['root']), job['partition']
    projection = _current_q_gbm_projection(root, partition, publish=True)
    if projection is None:
        return {'key': root.name, 'status': 'RETAINED_UNSCORABLE_H36', 'released_bytes': 0}
    aliases = []
    receipt = _current_q_json(root / 'receipt.json')
    for child in job.get('consumers', []):
        child = Path(child)
        _current_q_import(child, {'root': str(root), 'key': root.name, 'receipt': receipt},
            {'compact': True, 'references': {}})
        _current_q_gbm_h36_members(child, partition=partition)
        alias = child / 'native/atoms' / root.name
        _persist_published(alias / 'gbm-losses.json')
        published = _current_q_json(child / 'receipt.json')['members']
        for name, pin in receipt['members'].items():
            if (alias / name).exists():
                _require(published.get('native/atoms/' + root.name + '/' + name) == pin,
                    'RAW_STORAGE_ALIAS_DRIFT')
        aliases.append(alias)
    return {'key': root.name, 'status': 'CONSUMED_COMPACT_VALUES',
        'released_bytes': _current_q_retire_gbm(root, projection, aliases)}


def compact_retained_storage(run):
    """The already registered sole worker closes old STOP numerical lifetimes.

    No model producer is called. Original response seals supply the exact
    evaluation population; the shared matrix/covariate inputs are not expanded.
    """
    from . import f2_kernel as k
    from .f5 import _current_q_json, _current_q_key, _current_q_branch
    from .nested_loco import _write_exact_once
    from .runtime import _ready_ordered
    base = Path(run['run_root'])
    target = base / 'shared' / ('compact-storage-' + run['source_identity'] + '.json')
    # A reviewed source-only successor does not create new historical storage.
    # Keep the original V1 migration receipt and its actual released-byte count;
    # new atoms already publish/retire through their direct consumer below.
    generations = {run['identity']: run['source_identity']} if target.exists() else same_batch_generations(run)
    for identity, source in generations.items():
        completed = base / 'shared' / ('compact-storage-' + source + '.json')
        _require(not completed.is_symlink() and (not completed.exists() or completed.is_file()),
            'RAW_STORAGE_COMPLETION_DRIFT')
        if not completed.is_file():
            continue
        result = strict_json_bytes(completed.read_bytes())
        _require(result.get('kind') == 'PADML_COMPACT_STORAGE_COMPLETION_V1'
            and result.get('source_identity') == source and result.get('run_identity') == identity
            and result.get('status') == 'COMPLETED'
            and result.get('new_model_fits') == 0
            and _sha({k:v for k,v in result.items() if k != 'identity_sha256'}) == result['identity_sha256'],
            'RAW_STORAGE_COMPLETION_DRIFT')
        return result
    private_released = 0
    for unit in run['units']:
        directory = base / 'units' / unit['unit_id']
        if (directory / 'unit.json').is_file():
            private_released += _retire_completed_private_copies(run, unit, directory)
    caches = sorted((base / 'contexts').glob('*/q-atoms'))
    authorities = set(same_batch_generations(run).values())
    eligible, consumers = [], {}
    for cache in caches:
        _require(not cache.is_symlink(), 'RAW_STORAGE_SOURCE_INVALID')
        for atom in sorted((cache / 'atoms').glob('*')):
            if not (atom / 'receipt.json').is_file():
                continue
            producer = _current_q_json(atom / 'producer.json')
            if producer['task'].get('producer_kind') != 'GBM_STOP_CURVE':
                continue
            _require(producer['executor_source_identity'] in authorities and not atom.is_symlink(),
                'RAW_STORAGE_PRODUCER_DRIFT')
            source = producer.get('stop_function_source')
            if source is None:
                eligible.append((cache, atom, producer))
            else:
                consumers.setdefault(cache / 'atoms' / source['key'], []).append(str(atom))
    if not eligible:
        return {'status': 'NO_RETAINED_Q', 'released_unique_inode_bytes': private_released, 'new_model_fits': 0}
    frozen = load_raw_binding(base / 'binding', expected_input=run['raw_input'])
    fields, rows = k._response_rows(frozen['response_csv'])
    scopes, jobs = {}, []
    for cache, atom, producer in eligible:
            task = producer['task']
            if task.get('producer_kind') != 'GBM_STOP_CURVE' or 'stop_function_source' in producer:
                continue
            _require(producer['executor_source_identity'] in authorities and not atom.is_symlink(),
                'RAW_STORAGE_PRODUCER_DRIFT')
            scope = cache / 'inputs' / producer['q_input_sha256']
            if scope not in scopes:
                source = _current_q_json(scope / 'input.json', producer['q_input_sha256'])
                registered = _current_q_json(scope / 'registered.json')
                partitions = {}
                for p in registered['partitions']:
                    if p['kind'] != 'STOP':
                        continue
                    fit = k._write_response_subset(fields, rows, p['fit_ids'], None)
                    _require(all(fit[n] == p['fit_response'][n] for n in p['fit_response']),
                        'RAW_STORAGE_RESPONSE_DRIFT')
                    partitions[p['partition_id']] = {**p, 'fit_response': fit,
                        'evaluation_response': k._write_response_subset(fields, rows, p['evaluation_ids'], None),
                        'evaluation_centers': {'data_identity': p['covariates']['data_identity'],
                            'evaluation_ids_sha256': k._sha(p['evaluation_ids']),
                            'values': [frozen['centers'][i] for i in p['evaluation_ids']]}}
                scopes[scope] = (source, registered, partitions)
            source, registered, partitions = scopes[scope]
            p = partitions[task['partition_id']]
            spec = {**source['spec'], 'current_q': {'source_identity': producer['executor_source_identity']}}
            branch = _current_q_branch(spec)
            if branch is not None:
                spec['current_q']['aar_branch'] = branch
            # Key consumption uses the persisted science fields directly;
            # native child projection would require discarded process paths.
            call = (spec, registered, [task], None, None, producer['evaluation_mode'], p)
            keys = {_current_q_key(spec, k._run_r_prediction_pool_task, call)}
            if branch is not None:
                legacy = {**spec, 'current_q': {k:v for k,v in spec['current_q'].items() if k != 'aar_branch'}}
                keys.add(_current_q_key(legacy, k._run_r_prediction_pool_task, call))
            _require(atom.name in keys, 'RAW_STORAGE_COORDINATE_DRIFT')
            jobs.append({'root': str(atom), 'partition': p, 'consumers': consumers.get(atom, [])})
    # Only the small new losses/qualification remain. Mapped original matrices
    # already occupy disk and must not be reserved as new output again.
    results = _ready_ordered(_compact_gbm_retained_job, jobs, policy=run['resource_policy'], root=base,
        retained_bytes_per_task=2 * 1024**2, transient_bytes_per_worker=8 * 1024**2,
        task_write_paths=[(Path(job['root']) / 'gbm-losses.json',) for job in jobs])
    body = {'kind': 'PADML_COMPACT_STORAGE_COMPLETION_V1', 'status': 'COMPLETED',
        'run_identity': run['identity'], 'source_identity': run['source_identity'],
        'converted_objects': sum(row['status'] == 'CONSUMED_COMPACT_VALUES' for row in results),
        'retained_unscorable_objects': sum(row['status'] == 'RETAINED_UNSCORABLE_H36' for row in results),
        'released_private_copies_bytes': private_released,
        'released_unique_inode_bytes': private_released + sum(row['released_bytes'] for row in results), 'new_model_fits': 0}
    result = {**body, 'identity_sha256': _sha(body)}
    target.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    _write_exact_once(target, canonical_json_bytes(result), 'RAW_STORAGE_COMPLETION_DRIFT')
    return result


def same_batch_generations(run):
    """Qualified run/source pairs; previous clinical batches never enter here."""
    from .run import f45_unit_predecessors
    _require(is_integrated(run), "RAW_RUN_REQUIRED")
    return {row["identity"]: row["source_identity"]
            for row in (run, *f45_unit_predecessors(run))}


def _file_pin(path: Path) -> dict:
    _require(path.is_file() and not path.is_symlink(), "RAW_INPUT_FILE_INVALID")
    return {"sha256": sha256_file(path), "size_bytes": path.stat().st_size}


def qualified_file_pins(paths, *, identity, record, expected=None, validate=None, cached_only=False):
    """Reuse a previous byte qualification; filesystem stamps only invalidate it."""
    import time
    _require(type(cached_only) is bool and (not cached_only or validate is not None),
             "RAW_QUALIFICATION_PROBE_INVALID")
    paths = {name: Path(path) for name, path in paths.items()}
    def stamps():
        result = {}
        for name, path in paths.items():
            _require(path.is_file() and not path.is_symlink(), "RAW_QUALIFIED_FILE_INVALID")
            st = path.stat()
            result[name] = [str(path.resolve()), st.st_dev, st.st_ino, st.st_size,
                            st.st_mtime_ns, st.st_ctime_ns]
        return result
    before = stamps()
    binding = _sha(identity)
    old = strict_json_bytes(record.read_bytes()) if record.is_file() else None
    hit = (old is not None and old.get("binding") == binding and old.get("stamps") == before
        and old.get("stable_stamps") is True)
    # The parent may consume an unchanged prior scientific qualification, but
    # a miss must reach the original worker before any SHA or numeric read.
    if cached_only and (not hit or old.get("scientifically_validated") is not True):
        return None
    if hit:
        pins = old["pins"]
        _require(set(pins) == set(paths) and (expected is None or pins == expected),
                 "RAW_QUALIFICATION_DRIFT")
        from .bundle import _remember_qualified_digest
        for name, row in before.items():
            _remember_qualified_digest(row[0], pins[name]["sha256"], row[1:])
        if validate is None or old.get("scientifically_validated") is True:
            return copy.deepcopy(pins)
    else:
        pins = {}
        for name, path in paths.items():
            key = tuple(before[name])
            with _BYTE_PINS_LOCK:
                cached = _BYTE_PINS.get(key)
                if cached is not None:
                    _BYTE_PINS.move_to_end(key)
                pin = dict(cached) if cached is not None else None
            if pin is None:
                pin = _file_pin(path)
            pins[name] = pin
            # Network filesystems can report the same mtime/ctime for two
            # writes within a clock tick. Newly written bytes qualify now but
            # only enter the persistent reuse cache after that ambiguity ends.
            # No wait or background watcher: the next necessary consumer does
            # the one fresh check; older immutable sources remain zero-read.
            if time.time_ns() - max(before[name][-2:]) > 2_000_000_000:
                with _BYTE_PINS_LOCK:
                    _BYTE_PINS[key] = dict(pin)
                    while len(_BYTE_PINS) > 4096:
                        _BYTE_PINS.popitem(last=False)
    _require(stamps() == before and (expected is None or pins == expected), "RAW_QUALIFIED_BYTES_DRIFT")
    science_hit = (old is not None and old.get("binding") == binding and old.get("pins") == pins
        and old.get("scientifically_validated") is True)
    if validate is not None and not science_hit:
        validate()
        _require(stamps() == before, "RAW_QUALIFIED_BYTES_DRIFT")
    record.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(dir=record.parent, prefix=".qualification-", delete=False) as stream:
        temporary = Path(stream.name)
        try:
            stream.write(canonical_json_bytes({"binding": binding, "stamps": before, "pins": pins,
                "stable_stamps": all(time.time_ns()-max(row[-2:]) > 2_000_000_000 for row in before.values()),
                "scientifically_validated": science_hit or validate is not None}))
            stream.flush(); os.fsync(stream.fileno())
            os.replace(temporary, record)
        finally:
            temporary.unlink(missing_ok=True)
    return pins


def load_raw_binding(root: Path, *, expected_input: Mapping[str, Any] | None = None) -> dict:
    """One first qualification per unchanged, locally frozen set of members."""
    names = ("binding.json", "contract.json", "covariates.csv", "response-seal.csv")
    paths = [root / name for name in names]
    _require(all(p.is_file() and not p.is_symlink() for p in paths), "RAW_BINDING_INCOMPLETE")
    stamp = tuple((str(p.resolve()), p.stat().st_size, p.stat().st_mtime_ns, p.stat().st_ctime_ns) for p in paths)
    key = (stamp, _sha(dict(expected_input)) if expected_input is not None else None)
    import time
    stable = all(time.time_ns() - max(row[-2:]) > 2_000_000_000 for row in stamp)
    if stable and key in _QUALIFIED:
        # Callers must not change a qualified input object.
        return copy.deepcopy(_QUALIFIED[key])
    receipt = strict_json_bytes(paths[0].read_bytes())
    _require(set(receipt) - {"relationship_diagnostics"} == {"kind", "identity", "raw_input", "run_id", "source_identity", "status",
             "validation_center_counts", "members"} and receipt.get("kind") == BINDING_KIND
             and receipt.get("status") == "COMPUTED_AND_CONSUMED" and receipt.get("identity") ==
             _sha({k: v for k, v in receipt.items() if k != "identity"}), "RAW_BINDING_IDENTITY_DRIFT")
    _require(expected_input is None or receipt["raw_input"] == dict(expected_input), "RAW_BATCH_IDENTITY_DRIFT")
    raw = {p.name: p.read_bytes() for p in paths[1:]}
    _require(all(receipt["members"][n] == {"sha256": sha256_bytes(b), "size_bytes": len(b)}
                 for n, b in raw.items()), "RAW_BINDING_MEMBER_DRIFT")
    contract = strict_json_bytes(raw["contract.json"])
    from .f1_kernel import compile_binding_contract
    expected = compile_binding_contract(raw["covariates.csv"], raw["response-seal.csv"],
        workbook_sha256=receipt["raw_input"]["sha256"], enforce_formal_denominator=False)
    _require(contract == expected, "RAW_BINDING_SCIENCE_DRIFT")
    rows = list(csv.DictReader(io.StringIO(raw["covariates.csv"].decode("utf-8-sig"))))
    centers = {row["Patient_ID"]: row["Center"] for row in rows}
    counts = {str(c): sum(v == str(c) for v in centers.values()) for c in (36, 38, 39, 48, 52, 54)}
    _require(receipt["validation_center_counts"] == counts, "RAW_CENTER_COUNTS_DRIFT")
    value = {"root": root, "receipt": receipt, "binding_contract": contract,
        "registry": contract["registry"], "centers": centers,
        "covariates_csv": raw["covariates.csv"], "response_csv": raw["response-seal.csv"]}
    _QUALIFIED.clear()  # Bound resident input generations; do not cache failures.
    if stable:
        _QUALIFIED[key] = copy.deepcopy(value)
    return value


def ensure_raw_binding(run: Mapping[str, Any]) -> dict:
    from .f1_kernel import _run_r, compile_binding_contract
    from .nested_loco import _write_exact_once
    _require(is_integrated(run), "RAW_RUN_REQUIRED")
    root = Path(run["run_root"]) / "binding"
    if (root / "binding.json").is_file():
        value = load_raw_binding(root, expected_input=run["raw_input"])
        _require(value["receipt"]["run_id"] == run["run_id"]
                 and value["receipt"]["source_identity"] in same_batch_generations(run).values(), "RAW_RUN_BINDING_DRIFT")
        return value
    root.mkdir(mode=0o700, parents=True, exist_ok=True)
    workbook = Path(run["raw_input"]["path"])
    _require(_file_pin(workbook) == {k: run["raw_input"][k] for k in ("sha256", "size_bytes")},
             "RAW_WORKBOOK_DRIFT")
    package = Path(__file__).resolve().parent
    # PREPARE has no MICE or model fit; a interrupted preparation is atomic.
    with tempfile.TemporaryDirectory(prefix="raw-prepare-", dir=root) as temporary:
        stage = Path(temporary)
        _run_r({"mode": "PREPARE", "fresh_data": True,
            "authority_path": str(package / "science/authority.json"),
            "workbook_path": str(workbook), "output_dir": str(stage / "prepared")}, stage, package)
        cov = (stage / "prepared/covariates.csv").read_bytes()
        response = (stage / "prepared/response-seal.csv").read_bytes()
        preparation = strict_json_bytes((stage / "prepared/summary.json").read_bytes())
        _require(preparation.get("status") == "PASS"
            and preparation.get("covariates_sha256") == sha256_bytes(cov)
            and preparation.get("response_seal_sha256") == sha256_bytes(response)
            and isinstance(preparation.get("relationship_diagnostics"), dict),
            "RAW_RELATIONSHIP_DIAGNOSTICS_MISSING")
        contract = compile_binding_contract(cov, response, workbook_sha256=run["raw_input"]["sha256"],
                                            enforce_formal_denominator=False)
        members = {"covariates.csv": cov, "response-seal.csv": response,
                   "contract.json": canonical_json_bytes(contract)}
        for name, raw in members.items():
            _write_exact_once(root / name, raw, "RAW_BINDING_RESUME_DRIFT")
        centers = [row["Center"] for row in csv.DictReader(io.StringIO(cov.decode("utf-8-sig")))]
        body = {"kind": BINDING_KIND, "raw_input": run["raw_input"], "run_id": run["run_id"],
            "source_identity": run["source_identity"], "status": "COMPUTED_AND_CONSUMED",
            "relationship_diagnostics": preparation["relationship_diagnostics"],
            "validation_center_counts": {str(c): centers.count(str(c)) for c in (36, 38, 39, 48, 52, 54)},
            "members": {n: {"sha256": sha256_bytes(b), "size_bytes": len(b)} for n, b in members.items()}}
        _write_exact_once(root / "binding.json", canonical_json_bytes({**body, "identity": _sha(body)}),
                          "RAW_BINDING_RESUME_DRIFT")
    return load_raw_binding(root, expected_input=run["raw_input"])


def _run_publish_mice_view(task, *, native_ready=None):
    """Fit, consume and publish one view in its existing scientific worker."""
    from . import f1_kernel as f1
    from .nested_loco import _write_exact_once
    native_task, view, seeds, rows, columns, archive, receipt, identity = task
    archive, receipt = Path(archive), Path(receipt)
    work = Path(native_task[1])
    if archive.is_file():
        # A crash after ZIP publication but before the receipt is recoverable;
        # it must complete the original scientific consumer, never refit.
        with tempfile.TemporaryDirectory(prefix="consume-", dir=work.parent) as tmp:
            f1._validate_view_library(archive, view, seeds, columns, rows, Path(tmp) / "view")
        library = {"view_id": view["view_id"], "relative_path": f"libraries/{view['view_id']}.zip",
                   **_file_pin(archive), "row_count": view["row_count"],
                   "row_ids_sha256": view["row_ids_sha256"]}
    else:
        if native_ready is None:
            _require(f1._run_r_view_task(native_task) == view["view_id"], "RAW_MICE_VIEW_RESULT_DRIFT")
        else:
            _require(native_ready.get("status") == "VIEW_OUTPUT_READY"
                and native_ready.get("view_id") == view["view_id"]
                and native_ready.get("native_objects_validated") is True
                and native_ready.get("spec_sha256") == f1.sha256_file(work / "spec.json"),
                "RAW_MICE_NATIVE_READBACK_DRIFT")
        library = f1._package_view(work / "output", view, native_task[0]["view"]["outer_fold"],
                                  seeds, archive, expected_columns=columns, expected_row_ids=rows)
    _write_exact_once(receipt, canonical_json_bytes({**identity, "library": library}), "RAW_MICE_VIEW_DRIFT")
    # Receipt is the final publication point. A lost worker return can now be
    # recovered without redoing either MICE or the first scientific consumer.
    shutil.rmtree(work)
    from .runtime import advise_completed_io
    advise_completed_io([archive, receipt])
    return view["view_id"], library


def _publish_mice_phase_result(job):
    return _run_publish_mice_view(job[0], native_ready=job[1])


def _coordinate_outer_mice_view(task, policy, root):
    from . import f1_kernel as f1
    from .runtime import admit_stage, _bounded_ordered_spawn
    from .nested_loco import _write_exact_once
    native_task, view, _, _, _, archive, _, _ = task
    estimates = {"retained_bytes": policy["scratch_bytes_per_worker"],
        "publication_bytes": policy["scratch_bytes_per_worker"],
        "transient_bytes_per_worker": policy["scratch_bytes_per_worker"],
        "memory_bytes_per_worker": max(MIN_WORKER_MEMORY_BYTES, policy["memory_bytes_per_worker"])}
    deadline = [None]
    if Path(archive).is_file():
        estimates.update(retained_bytes=min(estimates['retained_bytes'], 8 * 1024**2), publication_bytes=0)
        admission = admit_stage(policy, root, legal_tasks=1, **estimates)
        result, = _bounded_ordered_spawn(_run_publish_mice_view, [task],
            selected_slots=admission["admitted_worker_ceiling"], task_deadlines=deadline)
        return result
    spec_path = Path(native_task[1]) / "spec.json"
    # Sole view owner prepares this once; chain workers only read it.
    raw = canonical_json_bytes(native_task[0])
    _write_exact_once(spec_path, raw, "RAW_MICE_SPEC_DRIFT")
    prepared = {"entry": "F1", "spec_path": str(spec_path), "spec_sha256": f1.sha256_bytes(raw),
        "command_prefix": [f1.RSCRIPT_EXECUTABLE, str(Path(native_task[2]) / "kernels/f1_nested_mice.R")]}
    consumed = f1._coordinate_mice_phases(prepared, policy, root, estimates, deadline)
    admission = admit_stage(policy, root, legal_tasks=1, **estimates)
    result, = _bounded_ordered_spawn(_publish_mice_phase_result, [(task, consumed)],
        selected_slots=admission["admitted_worker_ceiling"], task_deadlines=deadline)
    return result


def prepare_outer_mice(run: Mapping[str, Any], outer: int, context_root: Path) -> dict:
    """Publish each validated view immediately; only missing views/chains run."""
    from . import f1_kernel as f1
    from .nested_loco import _write_exact_once
    from .runtime import _bounded_ordered_spawn, observe_execution_resources, resource_admission
    frozen = ensure_raw_binding(run)
    registry = frozen["registry"]
    _require(type(outer) is int and outer in range(1, 7), "RAW_OUTER_INVALID")
    root = context_root / "mice"
    libraries = root / "libraries"
    libraries.mkdir(mode=0o700, parents=True, exist_ok=True)
    package = Path(__file__).resolve().parent
    views = registry["views"][str(outer)]
    tasks, records = [], {}
    for ordinal, view in enumerate(views, 1):
        vid = view["view_id"]
        seeds = f1._view_seed_rows(registry, outer, vid)
        analysis, rows = f1.view_row_ids(registry, outer, vid)
        archive, receipt = libraries / f"{vid}.zip", libraries / f"{vid}.json"
        if receipt.is_file():
            record = strict_json_bytes(receipt.read_bytes())
            _require(record["raw_binding_identity"] == frozen["receipt"]["identity"]
                     and record["source_identity"] in same_batch_generations(run).values()
                     and record["view"] == view and record["chain_seeds"] == seeds
                     and _file_pin(archive) == {k: record["library"][k] for k in ("sha256", "size_bytes")},
                     "RAW_MICE_COMPLETED_VIEW_DRIFT")
            records[vid] = record["library"]
            work = root / "work" / vid
            if work.exists():
                _require(not work.is_symlink() and (work / "input.json").is_file()
                         and strict_json_bytes((work / "input.json").read_bytes()) ==
                             {k: record[k] for k in ("raw_binding_identity", "source_identity", "view", "chain_seeds")},
                         "RAW_MICE_RETIREMENT_IDENTITY_DRIFT")
                shutil.rmtree(work)
            continue
        view_root = root / "work" / vid
        view_root.mkdir(mode=0o700, parents=True, exist_ok=True)
        identity = {"raw_binding_identity": frozen["receipt"]["identity"],
                    "source_identity": run["source_identity"], "view": view, "chain_seeds": seeds}
        if (view_root / "input.json").is_file():
            previous = strict_json_bytes((view_root / "input.json").read_bytes())
            _require(previous == {**identity, "source_identity": previous.get("source_identity")}
                and previous["source_identity"] in same_batch_generations(run).values(), "RAW_MICE_VIEW_DRIFT")
            identity = previous
        if archive.is_file():
            _require((view_root / "input.json").is_file()
                and strict_json_bytes((view_root / "input.json").read_bytes()) == identity,
                "RAW_MICE_UNQUALIFIED_ARCHIVE")
            tasks.append(((None, str(view_root), str(package)), view, seeds, rows,
                          frozen["binding_contract"]["covariate_columns"], str(archive), str(receipt), identity))
            continue
        _write_exact_once(view_root / "input.json", canonical_json_bytes(identity), "RAW_MICE_INPUT_DRIFT")
        cov_path = view_root / "covariates.csv"
        f1._subset_csv(frozen["covariates_csv"], rows, cov_path)
        spec = {"mode": "IMPUTE_VIEW", "authority_path": str(package / "science/authority.json"),
            "variable_path": str(package / "science/variable.csv"), "covariates_path": str(cov_path),
            "output_dir": str(view_root / "output"), "chain_seeds": [r["seed"] for r in seeds],
            "view": {"view_id": vid, "role": view["role"], "outer_fold": outer,
                "analysis_ids": analysis, "row_ids": rows, "row_ids_sha256": view["row_ids_sha256"]}}
        if view["role"] == "ANALYSIS":
            response = view_root / "response.csv"
            f1._subset_csv(frozen["response_csv"], analysis, response)
            spec["response_path"] = str(response)
        tasks.append(((spec, str(view_root), str(package)), view, seeds, rows,
                      frozen["binding_contract"]["covariate_columns"], str(archive), str(receipt), identity))
    def publish(index, result):
        vid, library = result
        _require(vid == tasks[index][1]["view_id"], "RAW_MICE_VIEW_RESULT_DRIFT")
        records[vid] = library
    if tasks:
        from .runtime import run_ready_families, _ready_ordered, resolve_pool_workers
        admission = resource_admission(run["resource_policy"], observe_execution_resources(root), legal_tasks=20 * len(tasks))
        workers = admission["admitted_worker_ceiling"]
        incomplete = sum(not Path(task[5]).is_file() for task in tasks)
        if incomplete == 0 or incomplete >= workers or workers == 1:
            retained = run['budgets']['retained_bytes_per_view']
            _ready_ordered(_run_publish_mice_view, tasks, policy=run['resource_policy'], root=root,
                retained_bytes_per_task=retained, transient_bytes_per_worker=3 * retained,
                retained_bytes_by_task=[min(retained, 8 * 1024**2) if Path(task[5]).is_file()
                    else retained for task in tasks],
                selected_slots=resolve_pool_workers(None), on_result=publish)
        else:
            results = run_ready_families([
                lambda task=task: _coordinate_outer_mice_view(task, run["resource_policy"], root)
                for task in tasks], policy=run["resource_policy"], root=root, workers=workers)
            for index, result in enumerate(results):
                publish(index, result)
    _require(set(records) == {v["view_id"] for v in views}, "RAW_MICE_VIEW_COVERAGE_INVALID")
    return {"root": root, "views": {v["view_id"]: v for v in views},
            "library_index": records, "binding": frozen}


def prepare_primary_context(run: Mapping[str, Any], outer: int, root: Path) -> dict:
    from .f2_kernel import (_materialize_registered_partitions, _registered_partition_identity_record,
                            _response_rows, _write_response_subset, predictor_contract)
    from . import nested_loco as n
    from ._science_authority import load_science_authority
    frozen = ensure_raw_binding(run)
    root.mkdir(mode=0o700, parents=True, exist_ok=True)
    source = {"raw_binding_identity": frozen["receipt"]["identity"], "source_identity": run["source_identity"],
              "outer_fold": outer, "run_id": run["run_id"]}
    if (root / "input.json").is_file():
        previous = strict_json_bytes((root / "input.json").read_bytes())
        _require(previous == {**source, "source_identity": previous.get("source_identity")}
            and previous["source_identity"] in same_batch_generations(run).values(), "RAW_CONTEXT_INPUT_DRIFT")
        source = previous
    n._write_exact_once(root / "input.json", canonical_json_bytes(source), "RAW_CONTEXT_INPUT_DRIFT")
    record = root / "primary-context.json"
    if record.is_file():
        value = strict_json_bytes(record.read_bytes())
        _require(value["source"] == source and value["identity_sha256"] ==
                 _sha({k: v for k, v in value.items() if k != "identity_sha256"}), "RAW_CONTEXT_DRIFT")
        registered = value["registered"]
        files, expected_pins = {}, {}
        for part in registered["partitions"]:
            cov = part["covariates"]
            for member in cov["members"]:
                path = Path(cov["input_dir"]) / member["name"]
                files[str(path)] = path
                expected_pins[str(path)] = {k: member[k] for k in ("sha256", "size_bytes")}
            for role in ("fit_response", "evaluation_response"):
                if role not in part:
                    continue
                pin = part[role]
                files[pin["path"]] = Path(pin["path"])
                expected_pins[pin["path"]] = {k: pin[k] for k in ("sha256", "size_bytes")}
        qualified_file_pins(files, identity=value["identity_sha256"], expected=expected_pins,
                            record=root / "primary-context.qualified.json")
        expected = _sha({"model_partitions": [_registered_partition_identity_record(
            p, prediction_only=p["kind"] == "OUTER") for p in registered["partitions"]], "diagnostic_partitions": []})
        _require(registered["identity"] == expected, "RAW_REGISTERED_INPUT_DRIFT")
    else:
        mice = prepare_outer_mice(run, outer, root)
        destination = root / "registered"
        # No downstream stage exists before this atomic context is published.
        # A failed merge may be rebuilt from the completed canonical views.
        if destination.exists():
            _require(destination.is_dir() and not destination.is_symlink(), "RAW_CONTEXT_PATH_INVALID")
            shutil.rmtree(destination)
        from .runtime import observe_execution_resources, resource_admission
        def admit_io(*, memory_bytes=0, pending_bytes=0):
            observation = observe_execution_resources(root)
            _require(observation["scratch_available_bytes"] >= pending_bytes, "RAW_CONTEXT_STORAGE_INSUFFICIENT")
            return resource_admission({**run["resource_policy"],
                "memory_reserve_bytes": run["resource_policy"]["memory_reserve_bytes"] + memory_bytes}, observation, legal_tasks=1)
        registered = _materialize_registered_partitions(mice, frozen["binding_contract"],
            frozen["response_csv"], outer, destination, include_diagnostics=False, admit_io=admit_io,
            resource_policy=run["resource_policy"])
        for part in registered["partitions"]:
            if part["kind"] == "OUTER":
                part.pop("evaluation_response", None)
            else:
                pin = part["evaluation_response"]
                raw = pin.pop("private_bytes")
                path = destination / "partitions" / part["partition_id"] / "evaluation-response.csv"
                n._write_exact_once(path, raw, "RAW_CONTEXT_RESPONSE_DRIFT")
                pin["path"] = str(path)
        registered["identity"] = _sha({"model_partitions": [_registered_partition_identity_record(
            p, prediction_only=p["kind"] == "OUTER") for p in registered["partitions"]], "diagnostic_partitions": []})
        outer_part, = [p for p in registered["partitions"] if p["kind"] == "OUTER"]
        training = Path(outer_part["fit_response"]["path"]).read_bytes()
        context = n.compile_training_context(scope="OUTER", outer_fold=outer, heldout_center=n.OUTER_CENTERS[outer-1],
            training_ids=outer_part["fit_ids"], heldout_ids=outer_part["evaluation_ids"],
            centers_by_patient=frozen["centers"], training_response_csv=training,
            mice_member_set_sha256=_sha(outer_part["covariates"]["members"]),
            preprocessing_program_sha256=_sha({"predictor_contract": predictor_contract(Path(__file__).parent),
                "recipe_owner": sha256_file(Path(__file__).with_name("f2_kernel.py"))}),
            modeling_program_sha256=source["source_identity"],
            seed_program_sha256=_sha(load_science_authority()["science"]["modeling_seed_policy"]))
        value = n._sealed({"kind": "PADML_INTEGRATED_PRIMARY_CONTEXT_V1", "source": source,
                           "training_context": context, "registered": registered})
        n._write_exact_once(record, canonical_json_bytes(value), "RAW_CONTEXT_DRIFT")
    expansion = root / "registered/view-sources"
    if expansion.exists():
        _require(expansion.is_dir() and not expansion.is_symlink(), "RAW_CONTEXT_RETIREMENT_INVALID")
        shutil.rmtree(expansion)
    context = value["training_context"]
    fields, rows = _response_rows(frozen["response_csv"])
    training = _write_response_subset(fields, rows, context["training_ids"], None)["private_bytes"]
    n.validate_training_context(context, training)
    # Outcomes of the outer validation patients never enter development.
    physical = {"origin": "CURRENT_RAW_CONTEXT", "raw_context_sha256": value["identity_sha256"],
        "registry": {name: [r for r in frozen["registry"][name] if r["outer_fold"] == outer]
                     for name in ("outer", "inner", "stopping")},
        "centers": frozen["centers"], "response_csv": training}
    return {"projection": {"origin": "CURRENT_RAW_CONTEXT", "raw_context_sha256": value["identity_sha256"],
                "training_context": context}, "frozen": physical,
            "registered": registered, "source_registered_identity": registered["identity"]}


def primary_projection(state: Mapping[str, Any], development: Mapping[str, Any], horizon: int) -> dict:
    from . import nested_loco as n
    context = state["projection"]["training_context"]
    _require(development["identity_sha256"] == _sha({k: v for k, v in development.items() if k != "identity_sha256"})
        and development["source"]["raw_context_sha256"] == state["projection"]["raw_context_sha256"]
        and development["source"]["registered_inputs_identity_sha256"] == state["source_registered_identity"]
        and development["outer_fold"] == context["outer_fold"]
        and development["source"].get("origin") == "CURRENT_RAW_CONTEXT"
        and development["source"]["selection_horizon_months"] == (36 if horizon == 36 else 24)
        and development["source"]["training_ids_sha256"] == context["training_ids_sha256"]
        and development["source"]["training_response_sha256"] == context["training_response_sha256"], "RAW_SELECTOR_BINDING_DRIFT")
    selector = development["selector"]
    science = (n.science_decision_template(horizon) if "frequency_policy_sha256" in selector["epv_resolution"]
               else n._base_science_decision_template(horizon))
    return {**state["projection"], "science_decision": science,
        "selector_evidence_sha256": development["identity_sha256"],
        "selector_recipe_set_sha256": development["transform_recipes"]["recipe_set_sha256"],
        "outer_recipe_sha256": development["outer_training_recipe_sha256"],
        "selected_parents": selector["selected_parents"], "common_set_design_df": selector["common_set_design_df"],
        "training_event_count": selector["outer_training_event_count"], "registered": state["registered"]}


def compile_primary_input(run, unit, root, state, development, searches, selector_root):
    from . import f4, f5, nested_loco as n
    from .f2_kernel import _registered_partition_identity_record
    from .bundle import write_deterministic_zip
    from .runtime import observe_execution_resources, resource_admission
    h, outer, budgets = unit["horizon"], unit["outer_fold"], run["budgets"]
    context, selector = state["projection"]["training_context"], development["selector"]
    science = primary_projection(state, development, h)["science_decision"]
    n._validate_outer_primary_searches(searches, outer=outer, science_decision=science, context=context)
    specifications = {"COX_PH": {"family": "COX_PH", "ties": "breslow"},
        "ELASTIC_NET_COX": {"family": "ELASTIC_NET_COX", "alpha": selector["alpha"],
            "ratio_by_imputation": selector["selected_ratio_by_imputation"],
            "lambda_by_imputation": selector["lambda_by_imputation"],
            "lambda_upper_bound_by_imputation": selector["lambda_upper_bound_by_imputation"]},
        "FPM_TVC_SET_A": {"family": "FPM_TVC_SET_A", "df": [3, 1], "tvc_parent": "AST_ALT"},
        **{f: searches[f]["result"]["selected_spec"] for f in searches}}
    for family, specification in specifications.items():
        f5._validate_final_refit_locked_spec(family, specification)
    identities = [_registered_partition_identity_record(p, prediction_only=p["kind"] == "OUTER")
                  for p in state["registered"]["partitions"]]
    models = {f: {"kind": "PADML_CURRENT_PRIMARY_FAMILY_SPEC_V1", "fold": outer, "family": f,
        "raw_context_sha256": state["projection"]["raw_context_sha256"],
        "selected_spec": specifications[f],
        "selected_spec_sha256": _sha(specifications[f]),
        "selector_evidence": {**selector, "recipe_set": development["transform_recipes"],
            "outer_recipe_sha256": development["outer_training_recipe_sha256"]},
        "selector_evidence_sha256": development["identity_sha256"],
        "model_input": {"model_partitions": identities}} for f in n._families()}
    parts = f4._o_fit_partitions(state["registered"])
    def admit(*, memory_bytes=0, pending_bytes=0, component_bytes=None):
        observation = observe_execution_resources(root)
        _require(observation["scratch_available_bytes"] >= pending_bytes + sum((component_bytes or {}).values()),
                 "RAW_COMPILE_STORAGE_INSUFFICIENT")
        return resource_admission({**run["resource_policy"],
            "memory_reserve_bytes": run["resource_policy"]["memory_reserve_bytes"] + memory_bytes}, observation, legal_tasks=1)
    with tempfile.TemporaryDirectory(prefix="primary-compile-", dir=root) as temporary:
        work = Path(temporary)
        projected = n._project_outer_scoring_suffix(frozen=state["frozen"], models=models, partitions=parts,
            outer_partition=parts["OUTER", 0, 0], outer=outer, scratch=work, context=context,
            science_decision=science, f2_acceptance_sha256=None, reused=[],
            selector_evidence_sha256=development["identity_sha256"], selected_parents=selector["selected_parents"],
            common_design_df=selector["common_set_design_df"], training_event_count=selector["outer_training_event_count"],
            training_response=state["frozen"]["response_csv"], heldout_ids=context["heldout_ids"],
            fresh_families=n._families(), fresh_seven=True, primary_searches=searches,
            selection_horizon_months=h, admit_io=admit,
            component_limits={k: budgets[k] for k in ("retained_bytes_per_component", "expanded_bytes_per_component")},
            prediction_only=True, primary_selector=development)
        components, templates, members = [], [], {}
        for row in sorted(projected["score_components"], key=lambda r: (n._families().index(r["family"]), r["repeat"], r["inner_fold"], r["imputation"])):
            path = row["archive"]
            name = f"components/score/{row['family']}/R{row['repeat']}_K{row['inner_fold']}_M{row['imputation']:02d}.zip"
            components.append({**n._component_input_record(path, role="FRESH_SCORE", path=name),
                **n._validate_outer_component(path, role="FRESH_SCORE", family=row["family"], context=context)})
            members[name] = path
        for family in n._families():
            for imp, path in enumerate(projected["post_lock_templates"][family], 1):
                name = f"templates/{family}/M{imp:02d}.zip"
                templates.append({**n._component_input_record(path, role="POST_LOCK_TEMPLATE", path=name),
                    **n._validate_outer_component(path, role="POST_LOCK_TEMPLATE", family=family, context=context)})
                members[name] = path
        raw_context_path = Path(run["run_root"]) / "contexts" / unit["context"] / "primary-context.json"
        members["source/raw-context.json"] = raw_context_path
        selector_members = {}
        for name, path in f5._nested_selector_numerical_members(selector_root).items():
            selector_members[name] = _file_pin(path)
            members["source/primary-selector/" + name] = path
        value = n._sealed({"schema_version": n.SCHEMA_VERSION, "kind": "PADML_F4_O_FIT_INPUT_V1",
            "origin": "CURRENT_RAW_CONTEXT", "raw_context_sha256": state["projection"]["raw_context_sha256"],
            "raw_context_member": _file_pin(raw_context_path), "program_id": n.PROGRAM_ID, "training_context": context, "science_decision": projected["science_decision"],
            "reused_training_scores": [], "selector_evidence_sha256": development["identity_sha256"],
            "development_metadata": projected["development_metadata"], "score_partitions": projected["score_partitions"],
            "component_records": components, "post_lock_templates": templates, "resource_policy": run["resource_policy"],
            **{k: budgets[k] for k in ("retained_bytes_per_component", "expanded_bytes_per_component", "shared_storage_bytes")},
            "planned_scoring_fits": 2100, "post_lock_model_fits": 20, "new_stop_fits": 0, "new_mice_chains": 0,
            "selection_horizon_months": h, "primary_selector_members": selector_members, "primary_searches": searches})
        raw = canonical_json_bytes(value)
        admit(pending_bytes=sum(p.stat().st_size for p in members.values()) + len(raw)
              + len(projected["training_response_csv"]) + 4096 * (len(members) + 3), memory_bytes=4*1024**2)
        target = root / "input.zip"
        write_deterministic_zip(target, {"o-fit-input.json": raw,
            "training/response.csv": projected["training_response_csv"], **members}, stored_members=set(members))
    return {"status": "COMPILED_ZERO_FITS", "outer_fold": outer, "identity_sha256": value["identity_sha256"],
        **_file_pin(target), "model_fit_count": 0, "heldout_response_member_count": 0,
        "origin": "CURRENT_RAW_CONTEXT", "raw_context_sha256": value["raw_context_sha256"]}


def _not_estimable_coverage(run, unit, source, receipt, missing, generations):
    """Bind every declared fold receipt without requesting absent model objects."""
    name = source["unit_id"]
    _require(receipt.get("status") in {"COMPLETED", "NOT_ESTIMABLE"}
        and receipt.get("unit_id") == name and receipt.get("direct_consumer_completed") is True
        and receipt.get("selection_horizon_months") == unit["horizon"]
        and receipt.get("run_identity") in generations, "RAW_NOT_ESTIMABLE_COVERAGE_INVALID")
    upstream = sorted(set(source["depends_on"]).intersection(missing)) if source["kind"] == "AAR" else []
    expected_negative = name in missing or bool(upstream)
    _require((receipt["status"] == "NOT_ESTIMABLE") == expected_negative,
        "RAW_NOT_ESTIMABLE_COVERAGE_INVALID")
    if upstream:
        proof = receipt.get("estimability", {})
        _require(proof.get("status") == "NOT_ESTIMABLE" and proof.get("upstream_units") == upstream
            and proof.get("reason_code") == "UPSTREAM_PRIMARY_NOT_ESTIMABLE",
            "RAW_NOT_ESTIMABLE_COVERAGE_INVALID")
        validate_sha256(proof.get("evidence_identity"), "coverage.estimability")
    return {"unit_id": name, "kind": source["kind"], "outer_fold": source["outer_fold"],
        "status": receipt["status"], **({"estimability": receipt["estimability"]} if "estimability" in receipt else {})}


def publish_unit_not_estimable(run, unit, root, *, development=None, selector_root=None, dependencies=None):
    """Publish the original selector's negative result, never a replacement fit.

    The normal unit carrier owns small metadata and references the already
    consumed complete paths. Dependent units reference that same evidence.
    """
    from . import nested_loco as n
    from .carriers import write_carrier
    from .f5 import _nested_selector_numerical_members
    _require(is_integrated(run) and (development is not None) != (dependencies is not None),
             "RAW_NOT_ESTIMABLE_SCOPE_INVALID")
    references = {}
    body = {"kind": "PADML_UNIT_NOT_ESTIMABLE_V1", "status": "NOT_ESTIMABLE",
        "run_identity": run["identity"], "source_identity": run["source_identity"],
        "unit_id": unit["unit_id"], "raw_input": run["raw_input"],
        "selection_horizon_months": unit["horizon"],
        "science_decision": n.science_decision_template(unit["horizon"])}
    if development is not None:
        _require(unit["kind"] in {"PRIMARY", "FULL0"} and selector_root is not None
            and development.get("identity_sha256") == _sha({k:v for k,v in development.items() if k != "identity_sha256"})
            and development["selector"].get("status") == "NOT_ESTIMABLE",
            "RAW_NOT_ESTIMABLE_SELECTOR_INVALID")
        trace = n.validate_epv_resolution(development["selector"]["epv_resolution"])
        _require(trace.get("status") == "NOT_ESTIMABLE" and trace.get("reason_code") == "FREQUENCY_LADDER_EXHAUSTED"
            and development.get("selected_alpha_evidence_sha256") is None,
            "RAW_NOT_ESTIMABLE_SELECTOR_INVALID")
        references = {"selector/" + name: path for name, path in
            _nested_selector_numerical_members(selector_root).items()}
        body.update(reason_code="FREQUENCY_LADDER_EXHAUSTED", selector_identity=development["identity_sha256"],
            epv_resolution=trace, upstream_units=[])
    else:
        _require(unit["kind"] in {"AAR", "EVALUATION"} and isinstance(dependencies, list) and dependencies,
            "RAW_NOT_ESTIMABLE_DEPENDENCY_INVALID")
        by_id = {row["unit_id"]: row for row in run["units"]}
        ids = sorted(dependencies)
        _require(len(ids) == len(set(ids)) and set(ids) <= set(unit["depends_on"])
            and all(by_id[name]["kind"] == "PRIMARY" for name in ids), "RAW_NOT_ESTIMABLE_DEPENDENCY_INVALID")
        for name in ids:
            path = Path(run["run_root"]) / "units" / name
            receipt = strict_json_bytes((path / "unit.json").read_bytes())
            consume_unit_estimability(run, by_id[name], path, receipt)
            references["upstream/" + name + "/unit.json"] = path / "unit.json"
            references["upstream/" + name + "/result.zip"] = path / "result.zip"
        body.update(reason_code="UPSTREAM_PRIMARY_NOT_ESTIMABLE", upstream_units=ids,
            missing_outer_folds=[by_id[name]["outer_fold"] for name in ids])
        if unit["kind"] == "EVALUATION":
            coverage = []
            for name in sorted(unit["depends_on"]):
                path = Path(run["run_root"]) / "units" / name / "unit.json"
                receipt = strict_json_bytes(path.read_bytes())
                coverage.append(_not_estimable_coverage(run, unit, by_id[name], receipt, ids, same_batch_generations(run)))
                references["coverage/" + name + "/unit.json"] = path
            body["coverage"] = coverage
    body = n._sealed(body)
    target = root / "result.zip"
    if not target.is_file():
        write_carrier(target, {"estimability.json": canonical_json_bytes(body)}, references=references, run=run)
        from .reports import _persist_published
        _persist_published(target)
    record = consume_not_estimable_result(run, unit, target)
    provenance = {"run_identity", "source_identity", "identity_sha256"}
    _require({k:v for k,v in record.items() if k not in provenance} ==
        {k:v for k,v in body.items() if k not in provenance}, "RAW_NOT_ESTIMABLE_PUBLICATION_DRIFT")
    return [target]


def consume_not_estimable_result(run, unit, target):
    """Direct typed reader shared by recovery, dispatch and offline archives."""
    import io
    from . import nested_loco as n
    from .carriers import open_carrier, validate_reference
    from .bundle import validate_relative_path
    generations = same_batch_generations(run)
    with open_carrier(target) as archive:
        _require("estimability.json" in archive.namelist(), "RAW_NOT_ESTIMABLE_EVIDENCE_MISSING")
        value = strict_json_bytes(archive.read("estimability.json"))
        _require(value.get("kind") == "PADML_UNIT_NOT_ESTIMABLE_V1" and value.get("status") == "NOT_ESTIMABLE"
            and value.get("unit_id") == unit["unit_id"] and value.get("raw_input") == run["raw_input"]
            and value.get("selection_horizon_months") == unit["horizon"]
            and generations.get(value.get("run_identity")) == value.get("source_identity")
            and value == n._sealed({k:v for k,v in value.items() if k != "identity_sha256"})
            and value.get("science_decision") == n.science_decision_template(unit["horizon"]),
            "RAW_NOT_ESTIMABLE_IDENTITY_DRIFT")
        if value["reason_code"] == "FREQUENCY_LADDER_EXHAUSTED":
            _require(unit["kind"] in {"PRIMARY", "FULL0"} and value["upstream_units"] == [],
                "RAW_NOT_ESTIMABLE_SCOPE_INVALID")
            development = strict_json_bytes(archive.read("selector/development-input.json"))
            selector = strict_json_bytes(archive.read("selector/selector.json"))
            trace = n.validate_epv_resolution(development["selector"]["epv_resolution"])
            _require(trace.get("status") == "NOT_ESTIMABLE" and trace == value["epv_resolution"]
                and development.get("identity_sha256") == value["selector_identity"] ==
                    _sha({k:v for k,v in development.items() if k != "identity_sha256"})
                and development["selector"] == selector["selector"]
                and development["source"] == selector["source"]
                and development["selector_result_sha256"] == _sha(selector)
                and development.get("selected_alpha_evidence_sha256") is None
                and selector["coarse_alpha_order"] == [0.05, 0.1, 0.2, 0.4, 0.6, 0.8, 1.0]
                and selector["fine_alpha_order"] == [] and selector["distinct_alpha_count"] == 7
                and selector["selector_path_count"] == 7 * 320
                and selector["new_mice_chains"] == selector["final_model_fits"] == 0,
                "RAW_NOT_ESTIMABLE_SELECTOR_DRIFT")
            source = development["source"]
            expected_kind = "PADML_NESTED_PRIMARY_SELECTOR_SOURCE_V1" if unit["kind"] == "PRIMARY" else "PADML_NESTED_FULL_DATA_SELECTOR_SOURCE_V1"
            _require(source["kind"] == expected_kind and source["context"] == (unit["outer_fold"] if unit["kind"] == "PRIMARY" else 0),
                "RAW_NOT_ESTIMABLE_SELECTOR_SCOPE_DRIFT")
            _require(source.get("selection_horizon_months", 24) == (36 if unit["horizon"] == 36 else 24)
                and archive.references.get("selector/coarse/paths.json", {}).get("sha256") == trace["coarse_records_sha256"],
                "RAW_NOT_ESTIMABLE_COARSE_SOURCE_DRIFT")
            names = set(archive.namelist())
            _require({"selector/coarse/paths.json", "selector/native-members.json", "selector/partitions.json",
                "selector/recipes/recipes.json"} <= names and all(name == "estimability.json" or name.startswith("selector/") for name in names),
                "RAW_NOT_ESTIMABLE_PATH_CLOSURE_INCOMPLETE")
            # Full numerical paths stay in their original physical carrier. The
            # producer already ran their native consumer; unchanged pins qualify
            # later reads without replaying glmnet or expanding MICE.
            for name, ref in archive.references.items():
                validate_relative_path(name)
                validate_reference(ref, run)
        elif value["reason_code"] == "UPSTREAM_PRIMARY_NOT_ESTIMABLE":
            ids = value["upstream_units"]
            by_id = {row["unit_id"]: row for row in run["units"]}
            _require(unit["kind"] in {"AAR", "EVALUATION"} and isinstance(ids, list) and ids
                and ids == sorted(set(ids)) and set(ids) <= set(unit["depends_on"])
                and all(by_id[name]["kind"] == "PRIMARY" for name in ids)
                and value["missing_outer_folds"] == [by_id[name]["outer_fold"] for name in ids]
                and set(archive.namelist()) == {"estimability.json", *("upstream/" + name + "/" + member
                    for name in ids for member in ("unit.json", "result.zip")),
                    *("coverage/" + name + "/unit.json" for name in unit["depends_on"] if unit["kind"] == "EVALUATION")},
                "RAW_NOT_ESTIMABLE_DEPENDENCY_INVALID")
            for name in ids:
                receipt = strict_json_bytes(archive.read("upstream/" + name + "/unit.json"))
                raw = archive.read("upstream/" + name + "/result.zip")
                _require(receipt.get("status") == "NOT_ESTIMABLE" and receipt.get("direct_consumer_completed") is True
                    and receipt.get("unit_id") == name and receipt.get("run_identity") in generations
                    and receipt.get("artifacts", {}).get("result.zip") == {"sha256": sha256_bytes(raw), "size_bytes": len(raw)},
                    "RAW_NOT_ESTIMABLE_DEPENDENCY_DRIFT")
                upstream = consume_not_estimable_result(run, by_id[name], io.BytesIO(raw))
                _require(receipt.get("estimability") == _unit_estimability_summary(upstream),
                    "RAW_NOT_ESTIMABLE_DEPENDENCY_DRIFT")
            if unit["kind"] == "EVALUATION":
                coverage = []
                for name in sorted(unit["depends_on"]):
                    receipt = strict_json_bytes(archive.read("coverage/" + name + "/unit.json"))
                    coverage.append(_not_estimable_coverage(run, unit, by_id[name], receipt, ids, generations))
                _require(value.get("coverage") == coverage, "RAW_NOT_ESTIMABLE_COVERAGE_DRIFT")
        else:
            raise ContractError("RAW_NOT_ESTIMABLE_REASON_INVALID")
    return value


def _unit_estimability_summary(value):
    return {"status": "NOT_ESTIMABLE", "reason_code": value["reason_code"],
        "evidence_identity": value["identity_sha256"], "upstream_units": value["upstream_units"]}


def consume_unit_estimability(run, unit, root, receipt):
    from .carriers import source_pin
    _require(receipt.get("status") == "NOT_ESTIMABLE" and receipt.get("direct_consumer_completed") is True
        and receipt.get("unit_id") == unit["unit_id"] and receipt.get("run_identity") in same_batch_generations(run)
        and receipt.get("selection_horizon_months") == unit["horizon"]
        and set(receipt.get("artifacts", {})) == {"result.zip"}, "RAW_NOT_ESTIMABLE_RECEIPT_INVALID")
    target = root / "result.zip"
    _require(source_pin(target) == receipt["artifacts"]["result.zip"], "RAW_NOT_ESTIMABLE_ARTIFACT_DRIFT")
    value = consume_not_estimable_result(run, unit, target)
    _require(receipt.get("estimability") == _unit_estimability_summary(value), "RAW_NOT_ESTIMABLE_RECEIPT_DRIFT")
    return value


def execute_primary(run, unit, root, context_root):
    from . import f4, f5
    from .worker import _f45_write, _f45_read, _f45_score_reuse_candidates
    from .runtime import observe_execution_resources, resource_admission
    h, outer = unit["horizon"], unit["outer_fold"]
    state = prepare_primary_context(run, outer, context_root)
    state["projection"]["selector_horizon_months"] = 36 if h == 36 else 24
    selector_root = context_root / ("selector-h36" if h == 36 else "selector")
    development = f5._primary_selector_program(state, selector_root,
        replay=(selector_root / "development-input.json").is_file(), workers=None, resource_policy=run["resource_policy"])
    if development["selector"].get("status") == "NOT_ESTIMABLE":
        return publish_unit_not_estimable(run, unit, root, development=development, selector_root=selector_root)
    projected = primary_projection(state, development, h)
    (root / "search").mkdir(mode=0o700, exist_ok=True)
    def admit_io(*, memory_bytes=0, pending_bytes=0, **unused):
        observation = observe_execution_resources(root)
        _require(observation["scratch_available_bytes"] >= pending_bytes, "RAW_Q_STORAGE_INSUFFICIENT")
        return resource_admission({**run["resource_policy"],
            "memory_reserve_bytes": run["resource_policy"]["memory_reserve_bytes"] + memory_bytes}, observation, legal_tasks=1)
    from .runtime import run_ready_families
    families = ("RSF", "GBM_COX", "XGBOOST_COX", "COXTIME_SET_A")
    searches = dict(zip(families, run_ready_families([
        lambda family=family: f5._prepare_primary_outer_rsf_search(projected, root / "search" / family,
            run["resource_policy"], retained_bytes_per_task=run["budgets"]["retained_bytes_per_q_task"],
            admit_io=admit_io, family=family, selection_horizon_months=h,
            source_registered_identity=state["source_registered_identity"])
        for family in families], policy=run["resource_policy"], root=root), strict=True))
    compile_path = root / "input.compile.json"
    if not compile_path.is_file():
        compiled = compile_primary_input(run, unit, root, state, development, searches, selector_root)
        _f45_write(compile_path, compiled)
    else:
        compiled = _f45_read(compile_path)
        _require(compiled["raw_context_sha256"] == state["projection"]["raw_context_sha256"]
                 and _file_pin(root / "input.zip") == {k: compiled[k] for k in ("sha256", "size_bytes")},
                 "RAW_PRIMARY_INPUT_DRIFT")
    result = root / "result.zip"
    if not result.is_file():
        from .run import f45_score_repair
        f4.execute_o_fit_bundle(input_bundle=root / "input.zip", target=result, outer_fold=outer,
            completed_score_units=_f45_score_reuse_candidates(run, unit), score_repair=f45_score_repair(run, unit))
    metadata = f4.load_o_fit_execution_archive(result, input_bundle=root / "input.zip", compiled_input_record=compiled)
    models = [root / "result.zip.work" / f"fits/M{imp:02d}.zip" for imp in range(1, 21)]
    _require(set(metadata["native_members"]) == {f"fits/M{imp:02d}.zip" for imp in range(1, 21)}
        and all(_file_pin(model) == metadata["native_members"][f"fits/M{imp:02d}.zip"]
                for imp, model in enumerate(models, 1)), "RAW_PRIMARY_FINAL_MODELS_INCOMPLETE")
    return [root / "input.zip", compile_path, result, *models]


def qualify_primary_request(request, compiled, input_bundle):
    import os
    from .run import load_f45_run
    _require("PADML_F45_RUN_PATH" in os.environ, "RAW_RUN_CONTEXT_REQUIRED")
    run = load_f45_run(Path(os.environ["PADML_F45_RUN_PATH"]))
    _require(is_integrated(run), "RAW_RUN_CONTEXT_REQUIRED")
    binding = load_raw_binding(Path(run["run_root"]) / "binding", expected_input=run["raw_input"])
    context = request["training_context"]
    path = Path(run["run_root"]) / "contexts" / f"OUTER-{context['outer_fold']}" / "primary-context.json"
    if path.is_file():
        raw = path.read_bytes()
    else:
        import zipfile
        with open_carrier(input_bundle) as archive:
            _require(0 < archive.getinfo("source/raw-context.json").file_size <= 16*1024**2, "RAW_CONTEXT_TOO_LARGE")
            raw = archive.read("source/raw-context.json")
    _require(request["raw_context_member"] == {"sha256": sha256_bytes(raw), "size_bytes": len(raw)}, "RAW_CONTEXT_DRIFT")
    value = strict_json_bytes(raw)
    _require(value["identity_sha256"] == _sha({k: v for k, v in value.items() if k != "identity_sha256"})
        and value["identity_sha256"] == request["raw_context_sha256"] == compiled["raw_context_sha256"]
        and value["source"] == {"raw_binding_identity": binding["receipt"]["identity"],
            "source_identity": context["modeling_program_sha256"], "outer_fold": context["outer_fold"], "run_id": run["run_id"]}
        and value["source"]["source_identity"] in same_batch_generations(run).values()
        and value["training_context"] == context and compiled["origin"] == request["origin"] == "CURRENT_RAW_CONTEXT",
        "RAW_PRIMARY_SOURCE_DRIFT")


def configure_environment(run_path: Path) -> None:
    """Re-exec once before scientific imports can observe another runtime."""
    import os
    import sys
    run = strict_json_bytes(run_path.read_bytes())
    if not is_integrated(run):
        return
    env = run["environment"]
    _require(all(Path(env[k]).is_absolute() and Path(env[k]).is_file() for k in ("python", "rscript")),
             "RAW_DEPENDENCY_EXECUTABLE_MISSING")
    expected = {"PADML_PYTHON": env["python"], "PADML_RSCRIPT": env["rscript"],
        "PADML_R_LIBRARY": env["r_library"], "R_LIBS_USER": env["r_library"],
        "R_LIBS_SITE": env["r_library"], "RETICULATE_PYTHON": env["python"],
        "PYTHON": env["python"], "PADML_INTEGRATED_RUN": run["identity"]}
    expected["PYTHONPYCACHEPREFIX"] = str(Path(run["run_root"]).parent.parent / "cache/python")
    expected["PYTHONDONTWRITEBYTECODE"] = ""
    if Path(sys.executable).resolve() != Path(env["python"]).resolve() or any(os.environ.get(k) != v for k, v in expected.items()):
        _require(os.environ.get("PADML_ENV_REEXEC") != _sha(env), "RAW_DEPENDENCY_ENVIRONMENT_MISMATCH")
        environment = {**os.environ, **expected, "PADML_ENV_REEXEC": _sha(env)}
        os.execve(env["python"], [env["python"], "-m", "padml.worker", *sys.argv[1:]], environment)
    # Loaded-file qualification runs under execute_f45's registered owner.
    # It can outlast the dispatcher's start handshake on a fresh installation.



def _retire_completed_private_copies(run, unit, root):
    """Published members, not directory names, authorize temporary retirement."""
    from . import f5_sensitivity as a
    from .worker import _f45_file_pins
    if unit['kind'] not in {'PRIMARY', 'AAR'} or not (root / 'evaluation-input.zip').is_file():
        return 0
    receipt = strict_json_bytes((root / 'unit.json').read_bytes())
    if receipt.get('status') == 'NOT_ESTIMABLE':
        consume_unit_estimability(run, unit, root, receipt)
        return 0  # Negative evidence is its own retained result, not an unmade model carrier.
    if unit['kind'] == 'PRIMARY' and not (root / 'postprocess/result.json').is_file():
        return 0
    loaded = a.load_f45_evaluation_source(root / 'evaluation-input.zip', run, unit)
    receipt = strict_json_bytes((root / 'unit.json').read_bytes())
    _require(loaded['manifest']['source_receipt'] == receipt, 'RAW_RETIREMENT_SOURCE_DRIFT')
    if unit['kind'] == 'PRIMARY':
        post = strict_json_bytes((root / 'postprocess/result.json').read_bytes())
        _require(post.get('kind') == 'PADML_F45_O_FIT_V1' and post.get('status') == 'COMPLETED'
            and post.get('source_unit') == unit['unit_id']
            and post.get('source_receipt_sha256') == sha256_file(root / 'unit.json')
            and post.get('identity_sha256') == _sha({k:v for k,v in post.items() if k != 'identity_sha256'}),
            'RAW_RETIREMENT_DIAGNOSTIC_DRIFT')
    sources = ['result.zip'] + (['input.zip', 'mice.zip'] if unit['kind'] == 'AAR' else [])
    _f45_file_pins({name: root / name for name in sources}, policy=run['resource_policy'], root=root,
        expected={name: receipt['artifacts'][name] for name in sources})
    protected = {root / name for name in receipt['artifacts']}
    with open_carrier(root / 'result.zip') as archive:
        header = strict_json_bytes(archive.read('o-fit-execution.json' if unit['kind'] == 'PRIMARY' else 'a12-outer.json'))
        protected.update(path for name in archive.references if (path := archive.external_path(name)) is not None)
        members = {root / 'result.zip.work' / name: pin for name, pin in header['members'].items()
            if name not in archive.references and name not in header.get('native_members', {})}
    released = a._retire_a12_member_copies(root, members, protected=protected)
    if unit['kind'] != 'AAR':
        return released
    with open_carrier(root / 'input.zip') as archive:
        raw = archive.read('a12-inputs.json')
        projected = strict_json_bytes(raw)
        projected_members = {**projected['members'], 'a12-inputs.json': {'sha256': sha256_bytes(raw), 'size_bytes': len(raw)}}
        protected.update(path for name in archive.references if (path := archive.external_path(name)) is not None)
    with open_carrier(root / 'mice.zip') as archive:
        whole = strict_json_bytes(archive.read('a12-inputs.json'))
        protected.update(path for name in archive.references if (path := archive.external_path(name)) is not None)
    _require(whole['projected_input_identity_sha256'] == projected['identity_sha256'], 'RAW_RETIREMENT_MICE_DRIFT')
    for name, numbers in whole['mice_views'].items():
        coordinate = root / 'input.zip.mice' / name
        report_path = coordinate / 'numerical.zip.json'
        if not report_path.is_file():
            continue  # A reused view remains at its original producer.
        report = strict_json_bytes(report_path.read_bytes())
        _require(report['numerical_view'] == numbers and report['executor_source_identity'] in same_batch_generations(run).values()
            and _file_pin(coordinate / 'input.zip') == numbers['members']['input.zip']
            and _file_pin(coordinate / 'numerical.zip') == {k:report[k] for k in ('sha256', 'size_bytes')},
            'RAW_RETIREMENT_VIEW_DRIFT')
        released += a._retire_a12_view_copies(coordinate / 'input.zip', report)
    for gather in sorted(root.glob('mice.zip.input-*')):
        execution = gather / 'execution.json'
        if not execution.is_file() or execution.is_symlink() or _file_pin(execution) != whole['members']['execution.json']:
            continue  # A failed or unknown attempt is not the published gather.
        members = {gather / 'input' / name: pin for name, pin in projected_members.items()}
        for name, numbers in whole['mice_views'].items():
            members.update({gather / 'prepared' / name / member: pin for member, pin in numbers['members'].items()})
            members[gather / 'numerical-views' / (name + '.zip')] = whole['members']['views/' + name + '.zip']
        for branch, record in whole['branches'].items():
            for partition in record['partitions']:
                directory = gather / 'prepared' / branch / partition['partition_id']
                paths = [directory / 'covariates' / f'imp{imp:02d}.csv' for imp in range(1, 21)]
                if all(path.is_file() and not path.is_symlink() for path in paths):
                    records = [{'name': path.name, **_file_pin(path)} for path in paths]
                    if _sha(records) == partition['data_identity']:
                        members.update({path: {k:pin[k] for k in ('sha256', 'size_bytes')}
                            for path, pin in zip(paths, records, strict=True)})
                members[directory / 'fit-response.csv'] = {'sha256': partition['fit_response_sha256'],
                    'size_bytes': partition['fit_response_size_bytes']}
                if branch == 'A12_WITHOUT_AST_ALT_DIRECT':
                    members[gather / 'input/direct' / partition['partition_id'] / 'fit-response.csv'] = {
                        'sha256': partition['fit_response_sha256'], 'size_bytes': partition['fit_response_size_bytes']}
        released += a._retire_a12_member_copies(gather, members, protected=protected)
    return released


def retire_completed_outputs(run, unit, root):
    """Last consumers retire only this new run's identified temporary carriers."""
    import zipfile
    from .f4 import _f45_optimism_json
    if not is_integrated(run):
        return
    _retire_completed_private_copies(run, unit, root)
    if unit['kind'] == 'EVALUATION':
        # The result is the sole final carrier; published unit pins precede this call.
        # Its independent reader can restore these small members after interrupted publication.
        _require((root / 'unit.json').is_file() and (root / 'result.zip').is_file(), 'RAW_RETIREMENT_BEFORE_PUBLICATION')
        work = root / 'result.zip.work'
        compact = root / 'evaluation-input.zip'
        _require(not work.is_symlink() and not compact.is_symlink(), 'RAW_RETIREMENT_PATH_INVALID')
        from . import f5_sensitivity as a
        from .worker import _f45_file_pins
        receipt = strict_json_bytes((root / 'unit.json').read_bytes())
        _require(receipt.get('status') in {'COMPLETED', 'NOT_ESTIMABLE'} and receipt.get('direct_consumer_completed') is True
            and receipt.get('unit_id') == unit['unit_id'] and receipt.get('run_identity') in same_batch_generations(run),
            'RAW_RETIREMENT_SOURCE_DRIFT')
        if receipt['status'] == 'NOT_ESTIMABLE':
            consume_unit_estimability(run, unit, root, receipt)
        _f45_file_pins({'result.zip': root / 'result.zip'}, policy=run['resource_policy'], root=root,
            expected={'result.zip': receipt['artifacts']['result.zip']})
        members = {}
        with open_carrier(root / 'result.zip') as archive:
            protected = {path for name in archive.references if (path := archive.external_path(name)) is not None}
            for name in {'evaluation-input.zip', *(f'evaluation/{name}'
                    for name in a._a12_evaluation_member_names(nested=True))}.intersection(archive.namelist()):
                path = compact if name == 'evaluation-input.zip' else work / name
                if not path.is_file() or path.is_symlink() or path in protected:
                    continue
                digest = __import__('hashlib').sha256()
                with archive.open(name) as stream:
                    for block in iter(lambda: stream.read(4 * 1024**2), b''):
                        digest.update(block)
                members[path] = {'sha256': digest.hexdigest(), 'size_bytes': archive.getinfo(name).file_size}
            if work.is_dir() and 'evaluation-input.zip' in archive.namelist():
                raw = a._f45_evaluation_nested_index(archive, 'evaluation-input.zip', 'evaluation-input.json')
                manifest = strict_json_bytes(raw)
                _require(manifest.get('kind') == 'PADML_F45_COMPACT_EVALUATION_V1'
                    and manifest.get('unit_id') == unit['unit_id']
                    and manifest.get('identity_sha256') == _sha({k:v for k,v in manifest.items() if k != 'identity_sha256'}),
                    'RAW_RETIREMENT_COMPACT_DRIFT')
                for name, pin in manifest['members'].items():
                    if name.startswith('sources/'):
                        members[work / 'compact-sources' / name.removeprefix('sources/')] = pin
                    elif name in {'response.csv', 'primary-point-native.zip'}:
                        members[work / 'primary-context' / name] = pin
        a._retire_a12_member_copies(root, members, protected=protected)
        return
    base = Path(run['run_root'])
    context_units = [row for row in run['units'] if row['context'] == unit['context']]
    protected = set()
    # Unit consumption is not the last consumer. Window acknowledgements bind
    # the completed selection, evaluation and durable archive closure; all four
    # windows must finish before cross-window Q state can be retired.
    for horizon in {row['horizon'] for row in context_units}:
        from .reports import _archive_confirmed_head
        confirmation = _archive_confirmed_head(run, horizon)
        if confirmation is None:
            return
        proof, declared = confirmation
        protected.update(declared['members'])
    for row in context_units:
        directory = base / 'units' / row['unit_id']
        if not (directory / 'unit.json').is_file():
            return
        receipt = strict_json_bytes((directory / 'unit.json').read_bytes())
        _require(receipt.get('run_identity') in same_batch_generations(run) and receipt.get('unit_id') == row['unit_id']
            and receipt.get('status') in {'COMPLETED', 'NOT_ESTIMABLE'} and receipt.get('direct_consumer_completed') is True,
            'RAW_RETIREMENT_SOURCE_DRIFT')
        negative = receipt['status'] == 'NOT_ESTIMABLE'
        if negative:
            consume_unit_estimability(run, row, directory, receipt)
        if not negative and row['kind'] in {'PRIMARY', 'FULL0'}:
            if not (directory / 'postprocess/result.json').is_file():
                return
            result = _f45_optimism_json((directory / 'postprocess/result.json').read_bytes())
            _require(result['source_unit'] == row['unit_id'] and result['status'] == 'COMPLETED'
                and result['source_receipt_sha256'] == sha256_file(directory / 'unit.json'),
                'RAW_RETIREMENT_DIAGNOSTIC_DRIFT')
        if not negative and row['kind'] in {'PRIMARY', 'AAR'} and not (directory / 'evaluation-input.zip').is_file():
            return
    # All actual consumers and the four archived closures are complete. Retire
    # the context's one normalized preparation, except explicitly retained refs.
    preparation = base / 'contexts' / unit['context'] / 'mice-preparation'
    if preparation.is_dir():
        for manifest in preparation.glob('*/prepared.json'):
            saved = strict_json_bytes(manifest.read_bytes())
            _require(saved['binding']['producer'] in same_batch_generations(run).values()
                and _sha({k:v for k,v in saved.items() if k != 'identity_sha256'}) == saved['identity_sha256'],
                'RAW_RETIREMENT_PREPARATION_DRIFT')
            for name, pin in saved['members'].items():
                member = Path(name)
                _require(member.is_absolute() and not member.is_symlink()
                    and member.resolve().is_relative_to(manifest.parent / 'values'),
                    'RAW_RETIREMENT_PATH_INVALID')
                if member.relative_to(base).as_posix() not in protected and member.exists():
                    _require(_file_pin(member) == pin, 'RAW_RETIREMENT_PREPARATION_DRIFT')
                    member.unlink()
    # All four populations and branches of this context have finished Q and final fitting.
    # Only members explicitly pinned by each original native audit are candidates.
    cache = base / 'contexts' / unit['context'] / 'q-atoms' / 'atoms'
    if not cache.is_dir():
        return
    for atom in sorted(cache.iterdir()):
        _require(atom.is_dir() and not atom.is_symlink(), 'RAW_RETIREMENT_ATOM_INVALID')
        if not (atom / 'receipt.json').is_file():
            continue  # An incomplete/unpublished atom is never retired by a completed neighbour.
        producer = strict_json_bytes((atom / 'producer.json').read_bytes())
        receipt = strict_json_bytes((atom / 'receipt.json').read_bytes())
        _require(producer['executor_source_identity'] in same_batch_generations(run).values()
            and producer['key'] == receipt['key'] == atom.name
            and receipt['audit'] == strict_json_bytes((atom / 'audit.json').read_bytes())
            and receipt['values'] == _file_pin(atom / 'values.json'), 'RAW_RETIREMENT_ATOM_DRIFT')
        for name, pin in receipt['members'].items():
            relative = Path(name)
            if not relative.parts or relative.parts[0] != 'native':
                continue
            member = atom / relative
            _require(not relative.is_absolute() and '..' not in relative.parts
                and not member.is_symlink() and member.resolve().is_relative_to(atom), 'RAW_RETIREMENT_PATH_INVALID')
            if member.relative_to(base).as_posix() in protected:
                continue  # A formal reference keeps its real producer.
            if member.exists():
                _require(_file_pin(member) == pin, 'RAW_RETIREMENT_NATIVE_DRIFT')
                member.unlink()
