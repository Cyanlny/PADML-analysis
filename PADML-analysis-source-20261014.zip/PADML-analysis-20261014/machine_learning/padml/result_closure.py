"""Evaluation-only completion of retained A04 and independent horizon outputs.

This is a tail of the existing appendage worker. It has no training, imputation,
prediction, bootstrap or archive dispatcher entry point.
"""
from __future__ import annotations

import math
from collections import Counter
from pathlib import Path

from . import nested_loco as n
from .bundle import ContractError, canonical_json_bytes, strict_json_bytes
from .curve_rmse import CENTERS, HORIZONS

LIMIT = 8 * 1024**2
PREFIX = 'evaluation-closure-20261009'


def need(ok, reason):
    if not ok:
        raise ContractError('RESULT_CLOSURE_' + reason)


def decision():
    return n._sealed({'kind': 'PADML_RESULT_CLOSURE_20261009_V1',
        'amendment': 'POST_RESULT_EVALUATION_ONLY', 'centers': CENTERS,
        'a04_report_months': list(HORIZONS), 'a04_review_month': 24,
        'a04_uno_months': 'MATCHED_DEVELOPMENT_WINDOW_PLUS_24_MONTH_REFERENCE',
        'a04_uno_score': 'RISK_AT_THE_SAME_TRUNCATION_MONTH',
        'a04_support': 'CURRENT_METRIC_SPECIFIC_G_ESS_PAIRS_RANK_SEPARATION',
        'a04_calibration': 'CURRENT_UNPENALIZED_LOGIT_NATURAL_SPLINE_ALL_PATIENT_ICI',
        'a04_scope': {'auc': 784, 'calibration_groups': 784, 'uno': 343},
        'negative_review': {'single_strictly_above': .65, 'three_mean_strictly_above': .60},
        'interval_disposition': 'REGISTERED_SIX_EXP1_RESULTS_NO_NEW_METHOD',
        'cross_time': 'SIX_CENTER_COMMON_PATIENTS_FULL0_AND_LOCO_SEPARATE',
        'new_training_mice': 0, 'new_prediction_model_fits': 0, 'new_shap_solves': 0,
        'new_resampling': 0, 'selection_effect': 'NONE', 'risk_projection': 'NONE'})


def eligible(run, unit, source_unit=None):
    return run.get('result_closure') is not None and source_unit is None and unit['kind'] in {'FULL0', 'EVALUATION'}


def relative_result(unit):
    return f"units/{unit['unit_id']}/{PREFIX}/result.json"


def validate_result(run, unit, value):
    from .f4 import _evaluation_check_producer
    from .integrated import same_batch_generations
    need(run.get('result_closure') == decision() and eligible(run, unit)
        and value.get('kind') == 'PADML_RESULT_CLOSURE_UNIT_V1'
        and value.get('decision_sha256') == decision()['identity_sha256']
        and value.get('target_unit') == unit['unit_id']
        and value.get('development_month') == unit['horizon']
        and value.get('status') == 'COMPLETED' and value.get('direct_consumer_completed') is True
        and n._sealed({k:v for k,v in value.items() if k != 'identity_sha256'}) == value,
        'RESULT_IDENTITY_DRIFT')
    _evaluation_check_producer(value, same_batch_generations(run))
    need(value['new_computation'] == {'training_mice':0, 'prediction_model_fits':0,
        'shap_solves':0, 'resampling':0}, 'FORBIDDEN_COMPUTATION')
    cross = value['cross_time']
    need(len(cross['patient_ids']) == len(cross['centers']) > 0
        and len(set(cross['patient_ids'])) == len(cross['patient_ids'])
        and set(cross['centers']) == set(CENTERS), 'CROSS_POPULATION_INVALID')
    branches = {'FULL0'} if unit['kind'] == 'FULL0' else {'PRIMARY', *n.AAR_ESTIMANDS}
    need(set(cross['risks']) == branches and set(cross['within_model']) == branches,
        'CROSS_BRANCH_COVERAGE')
    for values in cross['risks'].values():
        need(len(values) == len(cross['patient_ids']) and all(type(v) in (int,float)
            and math.isfinite(v) and 0 <= v <= 1 for v in values), 'CROSS_RISK_INVALID')
    if unit['kind'] == 'EVALUATION':
        need(value['a04']['development_month'] == unit['horizon'],'A04_DEVELOPMENT_MONTH_DRIFT')
        validate_a04(value['a04'])
    else:
        need(value['a04'] is None, 'FULL0_HAS_NO_A04_REEVALUATION')
    return value


def read_result(run, unit, *, observation=False):
    from .carriers import source_bytes
    from .integrated import qualified_file_pins
    path = Path(run['run_root']) / relative_result(unit)
    if not path.is_file():
        return None
    value = validate_result(run, unit, strict_json_bytes(source_bytes(path, limit=LIMIT)))
    paths = {name: Path(run['run_root'])/name for name in value['sources']}
    pins = qualified_file_pins(paths, identity=value['identity_sha256'],
        expected=value['sources'], record=path.with_name('result.qualified.json'),
        validate=lambda: validate_result(run,unit,value), cached_only=observation)
    if pins is None:
        return None
    return value


def _metrics_job(task):
    from .f4 import (_evaluation_projection, _evaluation_discrimination,
        _evaluation_calibration, _response_rows, _write_response_subset, censoring_context,
        _evaluation_check_producer)
    binding, view, scope, target, provenance = task
    need(binding['development_month'] in HORIZONS,'DEVELOPMENT_MONTH_INVALID')
    uno_months = {24,binding['development_month']}
    target = Path(target)
    if target.is_file():
        value = strict_json_bytes(target.read_bytes())
        _evaluation_check_producer(value,provenance['generations'])
        need(value['binding'] == binding and value['scope'] == scope
            and n._sealed({k:v for k,v in value.items() if k != 'identity_sha256'}) == value,
            'PARTIAL_METRIC_DRIFT')
        _check_metric_rows(value['rows'],uno_months)
        return value
    indices = [i for i,c in enumerate(view['centers']) if scope == 'MICRO' or c == scope]
    selected = _evaluation_projection(view['patient_ids'], view['centers'], view['response_csv'],
        view['matrices'], indices)
    fields, response = _response_rows(selected['response_csv'])
    context = censoring_context(selected['patient_ids'], selected['centers'],
        _write_response_subset(fields, response, selected['patient_ids'], None))
    rows = {}
    for name,matrix in selected['matrices'].items():
        rows[name] = {}
        for h in HORIZONS:
            d = _evaluation_discrimination(matrix, context, h, h, include_uno=h in uno_months)
            c = _evaluation_calibration([1-r[h] for r in matrix], context['rows'][h], curves=False)
            rows[name][str(h)] = {'auc': d['auc'], 'calibration': c,
                **({'uno': d['uno_c']} if h in uno_months else {})}
    _check_metric_rows(rows,uno_months)
    value = n._sealed({'binding':binding, 'producer':provenance['producer'], 'scope':scope, 'patient_count':len(indices),
        'center_counts':dict(sorted(Counter(selected['centers']).items())), 'rows':rows})
    n._write_exact_once(target, canonical_json_bytes(value), 'RESULT_CLOSURE_PARTIAL_METRIC_DRIFT')
    return value


def _check_metric_rows(rows,uno_months):
    need(bool(rows), 'EMPTY_METRIC_ROWS')
    for months in rows.values():
        need(set(months) == {'6','12','24','36'}, 'REPORT_MONTH_COVERAGE')
        for h,row in months.items():
            need(set(row) == {'auc','calibration'} | ({'uno'} if int(h) in uno_months else set()), 'METRIC_SCOPE')
            cal = row['calibration']
            need({'citl','calibration_slope','oe','ici','e50','e90'} <= set(cal), 'CALIBRATION_COVERAGE')
            for metric in [row['auc'], *([row['uno']] if int(h) in uno_months else []),
                           *[cal[k] for k in ('citl','calibration_slope','oe','ici','e50','e90')]]:
                good = metric['status'] == 'ESTIMABLE'
                need((good and metric['value'] is not None and math.isfinite(metric['value'])
                      and not metric['reasons']) or (metric['status'] == 'NOT_ESTIMABLE'
                      and metric['value'] is None and bool(metric['reasons'])), 'UNHANDLED_NUMERICAL_FAILURE')


def validate_a04(value):
    need(value['development_month'] in HORIZONS,'DEVELOPMENT_MONTH_INVALID')
    uno_months = {24,value['development_month']}
    need(value['metric_horizon'] == 24 and value['coordinate_counts'] ==
        {'auc':196,'calibration_groups':196,'uno':49*len(uno_months)}
        and value['uno_months'] == sorted(uno_months), 'A04_DENOMINATOR_DRIFT')
    need(set(value['cases']) == {'VARIANTS','NEGATIVE-P1','NEGATIVE-P2','NEGATIVE-P3'}, 'A04_CASE_COVERAGE')
    for name,scopes in value['cases'].items():
        need(set(scopes) == {'MICRO',*CENTERS}, 'A04_CENTER_COVERAGE')
        for row in scopes.values():
            _check_metric_rows(row['rows'],uno_months)
            from .f5_mice_variants import VARIANTS
            from .f5_negative_controls import BRANCH
            need(set(row['rows']) == (set(VARIANTS) if name == 'VARIANTS' else {BRANCH}),
                'A04_BRANCH_COVERAGE')
    return value


def _a04(run, unit, folder, sources):
    from .f5_a04_current import read_current_a04_evaluation, current_a04_handoffs
    from .carriers import source_pin
    from .integrated import load_raw_binding, same_batch_generations
    from .runtime import admit_stage, _ready_ordered, MIN_WORKER_MEMORY_BYTES
    from .f4 import _evaluation_fixed_macro, _evaluation_provenance
    from .f5_negative_controls import BRANCH, _threshold_summary
    base = Path(run['run_root']); h = unit['horizon']
    units = {u['unit_id']:u for u in run['units']}
    paths = [base/f'units/PRIMARY-H{h:02d}-O{o}/post-result-repair-20261008/a04/evaluation.json' for o in range(1,7)]
    sizes = sum(p.stat().st_size for p in paths)
    admit_stage(run['resource_policy'],folder,legal_tasks=1,retained_bytes=LIMIT,
        publication_bytes=LIMIT,transient_bytes_per_worker=16*1024**2,
        memory_bytes_per_worker=max(MIN_WORKER_MEMORY_BYTES,16*sizes))
    consumed = [*paths,*[base/'binding'/name for name in
        ('binding.json','contract.json','covariates.csv','response-seal.csv')]]
    before = {p.relative_to(base).as_posix():source_pin(p) for p in consumed}
    sources.update(before)
    projections = [read_current_a04_evaluation(p,run,units[f'PRIMARY-H{h:02d}-O{o}'])
        for o,p in enumerate(paths,1)]
    line = current_a04_handoffs(projections,horizons=(h,))[h]
    frozen = load_raw_binding(base/'binding', expected_input=run['raw_input'])
    need(frozen['receipt']['run_id'] == run['run_id']
        and frozen['receipt']['source_identity'] in same_batch_generations(run).values()
        and all(p['source']['raw_binding_identity'] == frozen['receipt']['identity'] for p in projections)
        and all(frozen['centers'][pid] == c for pid,c in zip(line['variants']['patient_ids'],line['variants']['centers'])),
        'A04_RAW_BINDING_DRIFT')
    binding = {'decision':decision()['identity_sha256'], 'unit':unit['unit_id'], 'development_month':h,
        'sources':before,
        'raw_binding_identity':frozen['receipt']['identity']}
    cases = [('VARIANTS',line['variants'],frozen['response_csv']),
        *[(f'NEGATIVE-P{i}',handoff,raw) for i,(handoff,raw) in enumerate(line['negative'],1)]]
    tasks = []
    provenance = _evaluation_provenance(run)
    for case,handoff,raw in cases:
        view = {'patient_ids':handoff['patient_ids'],'centers':handoff['centers'],
            'response_csv':raw,'matrices':handoff['survival']}
        for scope in ['MICRO',*CENTERS]:
            tasks.append(({**binding,'case':case},view,scope,folder/f'{case}-{scope}.json',provenance))
    # One pool, 28 independent outcome/population jobs. Each shares its KM among
    # variants and report times. Only compact metric rows cross back to the parent.
    results = _ready_ordered(_metrics_job,tasks,policy=run['resource_policy'],root=folder,
        retained_bytes_per_task=128*1024,transient_bytes_per_worker=16*1024**2,publication_bytes=LIMIT,
        memory_bytes_per_worker=max(MIN_WORKER_MEMORY_BYTES,16*sizes),
        task_write_paths=[(t[3],) for t in tasks])
    grouped = {case:{r['scope']:{k:v for k,v in r.items() if k not in {'identity_sha256','binding'}}
        for r in results if r['binding']['case'] == case} for case,_,_ in cases}
    macros = {}
    counts = Counter(line['variants']['centers'])
    for case,scopes in grouped.items():
        macros[case] = {}
        for method in ('EQUAL_CENTER','PATIENT_WEIGHTED_CENTER'):
            weights = {c:1 if method == 'EQUAL_CENTER' else counts[c] for c in CENTERS}
            output = {}
            for name in scopes['MICRO']['rows']:
                output[name] = {}
                for month in HORIZONS:
                    by_center = {}
                    for c in CENTERS:
                        r = scopes[c]['rows'][name][str(month)]
                        by_center[c] = {'auc':r['auc'], **{k:r['calibration'][k]
                            for k in ('citl','calibration_slope','oe','ici','e50','e90')},
                            **({'uno':r['uno']} if month in {24,h} else {})}
                    output[name][str(month)] = _evaluation_fixed_macro(by_center,weights)
            macros[case][method] = {'fixed_center_weights':weights,'rows':output,
                'metric_scales':{'calibration_slope':'ABSOLUTE_DEVIATION_FROM_ONE',
                    'citl':'ABSOLUTE_DEVIATION_FROM_ZERO','other':'ORIGINAL_METRIC'}}
    review = {scope:{metric:_threshold_summary([grouped[f'NEGATIVE-P{i}'][scope]['rows'][BRANCH]['24'][metric]
        for i in range(1,4)]) for metric in ('auc','uno')} for scope in ['MICRO',*CENTERS]}
    hard = any(r['hard_review_required'] for v in review.values() for r in v.values())
    pooled_na = any(r['estimable_count'] != 3 for r in review['MICRO'].values())
    value = {'metric_horizon':24,'development_month':h,'uno_months':sorted({24,h}),
        'coordinate_counts':{'auc':196,'calibration_groups':196,'uno':49*len({24,h})},
        'cases':grouped,'fixed_center_macros':macros,'negative_review':review,
        'negative_gate':'HARD_REVIEW_REQUIRED' if hard else 'BLOCKED_POOLED_NOT_ESTIMABLE' if pooled_na else 'PASS',
        'review_status':'REQUIRES_CAUSE_DISPOSITION' if hard or pooled_na else 'NO_NEGATIVE_THRESHOLD_TRIGGER',
        'calibration_definition':decision()['a04_calibration'],
        'source_policies':line['sources'],'raw_binding_identity':frozen['receipt']['identity'],
        'outcome_pins':{case:n._sha(raw.decode()) for case,_,raw in cases},
        'legacy_results':'UNCHANGED_OLD_THRESHOLD_AND_CALIBRATION_DEFINITION'}
    need(before == {p.relative_to(base).as_posix():source_pin(p) for p in consumed},
        'A04_SOURCE_CHANGED_DURING_CONSUMPTION')
    return validate_a04(value), [t[3] for t in tasks]


def _cross_component(run, unit, sources):
    from .curve_rmse import _bindings
    from .carriers import open_carrier, resolve_reference
    from .f4 import _f45_optimism_json, _f45_optimism_member, _seal_prediction_matrix
    from .f5_sensitivity import _f45_evaluation_input, _validate_a12_handoff
    import struct
    path, declared = _bindings(run,unit); sources.update(declared)
    if unit['kind'] == 'FULL0':
        with open_carrier(path) as carrier:
            manifest = _f45_optimism_json(carrier.read('input.json'))
            ids,centers = manifest['patient_ids'],manifest['centers']
            raw = _f45_optimism_member(carrier,'apparent.f64',manifest['members']['apparent.f64'])
            need(len(raw) == len(ids)*37*8,'PREDICTION_SHAPE')
            matrices = {'FULL0':list(struct.iter_unpack('<37d',raw))}
            # Only physically consumed members enter this closure.
            for name in ('input.json','apparent.f64'):
                ref = carrier.references.get(name)
                if ref:
                    resolve_reference(ref,run); sources[ref['path']] = {k:ref[k] for k in ('sha256','size_bytes')}
    else:
        with _f45_evaluation_input(path,'evaluation-input.zip') as carrier:
            handoff = _validate_a12_handoff(_f45_optimism_json(carrier.read('predictions.json')))
            ids,centers,matrices = handoff['patient_ids'],handoff['centers'],handoff['survival']
            ref = carrier.references.get('predictions.json')
            if ref:
                resolve_reference(ref,run); sources[ref['path']] = {k:ref[k] for k in ('sha256','size_bytes')}
    selected = [i for i,c in enumerate(centers) if c in CENTERS]
    need(len(ids) == len(centers) and len(ids) == len(set(ids)),'CROSS_ALIGNMENT')
    within,risks = {},{}
    for name,matrix in matrices.items():
        _seal_prediction_matrix(ids,matrix,list(range(37)))
        increments = [matrix[i][t]-matrix[i][t-1] for i in selected for t in range(1,37)]
        within[name] = {'patient_count':len(selected),'positive_survival_increments':sum(v > 0 for v in increments),
            'maximum_survival_increment':max([0.,*increments])}
        risks[name] = [1-matrix[i][unit['horizon']] for i in selected]
    return {'population':'SIX_REGISTERED_CENTERS','patient_ids':[ids[i] for i in selected],
        'centers':[centers[i] for i in selected], 'risks':risks,'within_model':within}


def run_closure(run, unit):
    from .f4 import _evaluation_provenance
    from .carriers import source_pin
    from .curve_rmse import relative_result as curve_name, read_result as read_curve
    from .integrated import qualified_file_pins
    from .runtime import admit_stage, MIN_WORKER_MEMORY_BYTES
    saved = read_result(run,unit)
    if saved is not None:
        _retire_metric_leaves(Path(run['run_root'])/relative_result(unit),saved)
        return {'target_unit':unit['unit_id'],'identity_sha256':saved['identity_sha256'],'reused':True}
    need(run.get('result_closure') == decision() and eligible(run,unit),'NOT_AUTHORIZED')
    base = Path(run['run_root']); target = base/relative_result(unit)
    folder = target.parent; folder.mkdir(parents=True,exist_ok=True)
    need(not any(p.is_symlink() for p in (target,folder,*folder.parents)),'PATH_INVALID')
    admit_stage(run['resource_policy'],folder,legal_tasks=1,retained_bytes=LIMIT,publication_bytes=LIMIT,
        transient_bytes_per_worker=64*1024**2,memory_bytes_per_worker=MIN_WORKER_MEMORY_BYTES)
    curve = read_curve(run,unit)
    need(curve is not None,'ORIGINAL_CURVE_REQUIRED')
    sources = {curve_name(unit):source_pin(base/curve_name(unit))}
    a04,partials = _a04(run,unit,folder,sources) if unit['kind'] == 'EVALUATION' else (None,[])
    cross = _cross_component(run,unit,sources)
    value = n._sealed({'kind':'PADML_RESULT_CLOSURE_UNIT_V1','decision_sha256':decision()['identity_sha256'],
        'target_unit':unit['unit_id'],'development_month':unit['horizon'],
        'producer':_evaluation_provenance(run)['producer'],'status':'COMPLETED','direct_consumer_completed':True,
        'sources':sources,'a04':a04,'cross_time':cross,'original_curve_identity':curve['identity_sha256'],
        'retireable_metric_leaves':{p.name:source_pin(p) for p in partials},
        'new_computation':{'training_mice':0,'prediction_model_fits':0,'shap_solves':0,'resampling':0}})
    validate_result(run,unit,value)
    raw = canonical_json_bytes(value); need(len(raw) <= LIMIT,'RESULT_SIZE')
    qualified_file_pins({k:base/k for k in sources},identity=value['identity_sha256'],expected=sources,
        record=target.with_name('result.qualified.json'),validate=lambda: validate_result(run,unit,value))
    n._write_exact_once(target,raw,'RESULT_CLOSURE_PUBLICATION_DRIFT')
    # These exact private metric leaves have been consumed by the published head.
    # Unknown members and failed jobs are never removed by directory traversal.
    _retire_metric_leaves(target,value)
    return {'target_unit':unit['unit_id'],'identity_sha256':value['identity_sha256'],'reused':False}


def _retire_metric_leaves(target,value):
    from .carriers import source_pin
    allowed = {f'{case}-{scope}.json' for case in ('VARIANTS','NEGATIVE-P1','NEGATIVE-P2','NEGATIVE-P3')
        for scope in ('MICRO',*CENTERS)}
    for name,pin in value.get('retireable_metric_leaves',{}).items():
        need(name in allowed,'UNDECLARED_METRIC_RETIREMENT')
        path=target.parent/name
        need(not path.is_symlink(),'METRIC_RETIREMENT_SYMLINK')
        if path.exists():
            need(source_pin(path)==pin,'METRIC_RETIREMENT_DRIFT')
            path.unlink()


def cross_report(run, records):
    checked = {u['unit_id']:validate_result(run,u,records[u['unit_id']])
        for u in run['units'] if eligible(run,u)}
    need(len(checked) == 8 and set(records) == set(checked),'EIGHT_RESULTS_REQUIRED')
    output = {}
    for role,prefix in (('FULL0_APPARENT','FULL0'),('LOCO','EVALUATION')):
        lines = {h:checked[f'{prefix}-H{h:02d}']['cross_time'] for h in HORIZONS}
        common = sorted(set.intersection(*(set(v['patient_ids']) for v in lines.values())))
        need(bool(common),'NO_COMMON_PATIENTS')
        mappings = {h:dict(zip(v['patient_ids'],v['centers'],strict=True)) for h,v in lines.items()}
        need(all(len({m[pid] for m in mappings.values()}) == 1 for pid in common),'CENTER_DRIFT')
        counts = dict(sorted(Counter(mappings[6][p] for p in common).items()))
        need(set(counts) == set(CENTERS),'COMMON_CENTER_COVERAGE')
        branches = {}
        for branch in lines[6]['risks']:
            risks = {h:dict(zip(v['patient_ids'],v['risks'][branch],strict=True)) for h,v in lines.items()}
            drops = [[risks[a][p]-risks[b][p] for a,b in zip(HORIZONS,HORIZONS[1:])] for p in common]
            patients = sum(any(d > 0 for d in ds) for ds in drops)
            branches[branch] = {'common_patients':len(common),'crossing_patients':patients,
                'crossing_proportion':patients/len(common),'crossing_adjacent_pairs':sum(d > 0 for ds in drops for d in ds),
                'maximum_risk_drop':max([0.,*(d for ds in drops for d in ds)]),
                'within_model':{str(h):v['within_model'][branch] for h,v in lines.items()}}
        output[role] = {'population':'SIX_CENTER_COMMON_PATIENTS','patient_ids':common,
            'center_counts':counts,'branches':branches,
            'patients_by_line':{str(h):len(v['patient_ids']) for h,v in lines.items()}}
    return n._sealed({'kind':'PADML_CROSS_TIME_CLOSURE_V1','decision_sha256':decision()['identity_sha256'],
        'sources':{k:v['identity_sha256'] for k,v in checked.items()},'results':output,
        'joint_survival_curve_validated':False,'risk_projection':'NONE','prediction_changes':0})


def interval_disposition(repair):
    """Resolve the finished validation, without claiming clinical-center coverage."""
    need(set(repair['auc_validation']) == {str(i) for i in range(1,7)}, 'SIX_SCENARIOS_REQUIRED')
    scenarios = {}
    for ordinal,result in repair['auc_validation'].items():
        need(result['status'] == 'COMPLETED' and result['scenario_ordinal'] == int(ordinal)
            and result['dataset_ids_preserved'] == 2000 and result['P_per_dataset'] == 1999,
            'SIMULATION_INCOMPLETE')
        rows = []
        for r in result['metrics']:
            need(r['replicates'] == 2000 and r['validation_status'] in
                {'UNRELIABLE','REGISTERED_SIMULATION_GATES_PASSED'},'SIMULATION_STATUS_INVALID')
            rows.append({k:r[k] for k in ('scope','metric','method','point_estimable',
                'publication_rate_point_estimable','coverage_point_estimable_unpublished_not_covered',
                'coverage_available','validation_status','validation_failure_reasons')})
        exp = [r for r in rows if r['method'] == 'EXP1_REESTIMATED_KM']
        need(exp and all(r['validation_status'] == 'UNRELIABLE' for r in exp),
            'REGISTERED_EXP1_DISPOSITION_REQUIRES_REVIEW')
        scenarios[ordinal] = {'source_identity':result['identity_sha256'],
            'scenario_sha256':result['scenario_sha256'],'metrics':rows,
            'conclusion':'REGISTERED_EXP1_GATES_FAILED'}
    clinical = {}
    need(len(repair['auc_perturbation']) == 32,'CLINICAL_INTERVAL_COVERAGE')
    for uid,old in repair['auc_perturbation'].items():
        need(old['status'] == 'COMPLETED' and old['new_prediction_model_fits'] == 0,
            'CLINICAL_INTERVAL_NOT_COMPLETE')
        clinical[uid] = {'source_identity':old['identity_sha256'],
            'coordinate_count':old['coordinate_count'],'point_estimable_count':old['point_estimable_count'],
            'complete_vectors':old['complete_vectors'],
            'final_reliability':'DIAGNOSTIC_ONLY_NO_VALIDATED_RELIABLE_CLINICAL_RANGE',
            'tested_ranges':'FAILED_REGISTERED_GATES','other_ranges':'NOT_VALIDATED',
            'original_point_estimates_and_NA':'UNCHANGED', 'original_interval_arrays':'UNCHANGED_REFERENCES'}
    return {'status':'VALIDATION_DISPOSITION_COMPLETE','scenarios':scenarios,'clinical':clinical,
        'simulated_coverage_is_not_individual_clinical_center_coverage':True,
        'IF_unpublished_coverage':'UNDEFINED_AMONG_PUBLISHED_WHEN_DENOMINATOR_ZERO',
        'inference_scope':'CONDITIONAL_ON_RETAINED_PREDICTIONS','new_resampling':0}


def effective_report(run, records, repair, *, repair_reference):
    """Small authoritative current index, with the immutable large history referenced."""
    crossing = cross_report(run,records)
    intervals = interval_disposition(repair)
    need(repair['original_application'] == {'coordinates':96,'original_failures':10,'passed':96,
        'failed_original_coordinates_closed':10,'original_successes_without_regression':86},
        'ORIGINAL_96_REGRESSION_REQUIRED')
    need(len(repair['calibration']) == 32 and repair['primary_scope_count'] == 24
        and repair['diagnostic_fit_coordinates'] == 27372,'PRIOR_REPAIR_COVERAGE')
    lines = {str(v['development_month']):{'source_identity':v['identity_sha256'],
        'a04':v['a04']} for v in records.values() if v['a04'] is not None}
    need(set(lines) == {'6','12','24','36'},'A04_FOUR_LINES_REQUIRED')
    for h,line in lines.items():
        need(line['a04']['development_month'] == int(h),'A04_DEVELOPMENT_MONTH_DRIFT')
        validate_a04(line['a04'])
    legacy_disposition = _legacy_a04_disposition(repair['complete_a04_lines'],lines)
    mi = repair['full0_h36_odd_even']
    need(len(mi['coordinates']) == 10 and mi['unresolved_numerical_failures'] == 0,
        'H36_DIAGNOSTICS_INCOMPLETE')
    unresolved = [h for h,v in lines.items() if v['a04']['negative_gate'] != 'PASS']
    return n._sealed({'kind':'PADML_EFFECTIVE_EVALUATION_CLOSURE_REPORT_V1',
        'decision_sha256':decision()['identity_sha256'],'run_identity':run['identity'],
        'status':'COMPUTED_REVIEW_REQUIRED' if unresolved else 'COMPUTED_PENDING_FINAL_ACCEPTANCE',
        'history':repair_reference,'original_application':repair['original_application'],
        'a04':lines,'coordinate_counts':{'auc':784,'calibration_groups':784,'uno':343},
        'uno_counts':{'24_month_reference':196,'additional_matched_window':147,
            'matched_window_including_24_month_line':196},
        'historical_threshold_disposition':legacy_disposition,
        'interval_disposition':intervals,'cross_time':crossing,
        'current_calibration':{uid:{'source_identity':r['identity_sha256'],
            'summary':r['summary'],'status':r['status']} for uid,r in repair['calibration'].items()},
        'full0_h36_legacy_incomplete_resolution':{'legacy_status':'INCOMPLETE',
            'current_source_identity':mi['identity_sha256'],'current_coordinates':mi['coordinates'],
            'population':mi['ipcw_population'],'unresolved_numerical_failures':0},
        'a04_review_required_lines':unresolved,
        'application_admission':'REQUIRES_EXPLICIT_FOUR_LINE_REVIEW_AND_FINAL_ACCEPTANCE',
        'formal_selection':'ORIGINAL_IBS_WINNERS_UNCHANGED_SENSITIVITY_RESULTS_SEPARATE',
        'new_training_mice':0,'new_prediction_model_fits':0,'new_shap_solves':0,'new_resampling':0})


def _legacy_a04_disposition(old_lines, current):
    """Account for the fixed old denominator without embedding its arrays again."""
    blocked, unchanged = [], Counter()
    for h in ('6','12','24','36'):
        old = old_lines[h]
        cases = [('VARIANTS',old['variants']['evaluation']), *[
            (f'NEGATIVE-P{i}',v) for i,v in enumerate(old['negative_controls']['evaluations'],1)]]
        for case,evaluation in cases:
            for scope in evaluation['scopes']:
                name = scope['scope']
                new = current[h]['a04']['cases'][case][name]['rows']
                for branch,values in scope['families'].items():
                    coordinates = [(month,'auc',values['discrimination']['auc'][str(month)],new[branch][str(month)]['auc'])
                        for month in HORIZONS]
                    coordinates += [(24,'uno',values['discrimination']['uno_c_24'],new[branch]['24']['uno'])]
                    for month in HORIZONS:
                        legacy = values['calibration']['horizons'][str(month)]
                        if any('BELOW_20' in reason for reason in legacy['reasons']):
                            blocked.append({'development_month':int(h),'case':case,'scope':name,
                                'branch':branch,'report_month':month,'metric':'calibration_groups',
                                'original_reasons':legacy['reasons'],
                                'current_components':{k:{'status':v['status'],'reasons':v['reasons']}
                                    for k,v in new[branch][str(month)]['calibration'].items() if k != 'curve'}})
                    for month,metric,legacy,value in coordinates:
                        if any('BELOW_20' in reason for reason in legacy['reasons']):
                            blocked.append({'development_month':int(h),'case':case,'scope':name,
                                'branch':branch,'report_month':month,'metric':metric,
                                'original_reasons':legacy['reasons'],'current_status':value['status'],
                                'current_reasons':value['reasons']})
                        elif legacy['status'] == 'ESTIMABLE':
                            need(value['status'] == 'ESTIMABLE' and
                                math.isclose(legacy['value'],value['value'],rel_tol=0,abs_tol=1e-10),
                                'UNCHANGED_DISCRIMINATION_DRIFT')
                            unchanged[metric] += 1
    counts = dict(Counter(row['metric'] for row in blocked))
    need(counts == {'auc':252,'calibration_groups':252,'uno':56},'OLD_BLOCKED_COORDINATES_DRIFT')
    blocked.sort(key=lambda r:tuple(r[k] for k in ('development_month','case','scope','branch','report_month','metric')))
    return {'status':'ALL_560_DISPOSED','blocked_counts':counts,'coordinates':blocked,
        'unchanged_qualified_point_estimates_checked':dict(unchanged),
        'legacy_calibration':'HISTORICAL_DEFINITION_PRESERVED_NOT_MIXED'}
