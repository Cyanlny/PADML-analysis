from __future__ import annotations

import calendar
import getpass
import hashlib
import hmac
import json
import os
import re
import secrets
import subprocess
import time
import urllib.parse
import urllib.request
import urllib.error
import xml.etree.ElementTree as ET
from dataclasses import dataclass
from pathlib import Path, PurePosixPath
from typing import Mapping

from .bundle import ContractError, sha256_file, validate_sha256


BUCKET = "padml-v22-transfer-1111"
HOST = f"{BUCKET}.oss-cn-beijing.aliyuncs.com"
ACCESS_KEY_SERVICE = "PADML_OSS_ACCESS_KEY_ID"
SECRET_KEY_SERVICE = "PADML_OSS_ACCESS_KEY_SECRET"


def _require(condition: bool, reason: str) -> None:
    if not condition:
        raise ContractError(reason)


@dataclass(frozen=True, repr=False)
class Credentials:
    access_key_id: str
    access_key_secret: str


def _keychain(service: str) -> str:
    completed = subprocess.run(
        [
            "/usr/bin/security",
            "find-generic-password",
            "-w",
            "-s",
            service,
            "-a",
            getpass.getuser(),
        ],
        stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE,
        stderr=subprocess.DEVNULL,
        check=False,
        timeout=30,
    )
    value = completed.stdout.rstrip(b"\r\n")
    _require(
        completed.returncode == 0
        and value
        and b"\n" not in value
        and b"\0" not in value,
        "OSS_KEYCHAIN_BINDING_ABSENT",
    )
    return value.decode()


def _credentials() -> Credentials:
    return Credentials(
        _keychain(ACCESS_KEY_SERVICE),
        _keychain(SECRET_KEY_SERVICE),
    )


def _key(value: str) -> str:
    path = PurePosixPath(value)
    _require(
        bool(value)
        and not path.is_absolute()
        and path.as_posix() == value
        and ".." not in path.parts,
        "OSS_OBJECT_KEY_INVALID",
    )
    return value


def _headers(
    key: str, digest: str, size: int, *, public_read: bool = False
) -> dict[str, str]:
    key = _key(key)
    validate_sha256(digest, "oss.sha256")
    _require(type(size) is int and size > 0, "OSS_SIZE_INVALID")
    context = hashlib.sha256(
        f"PADML_F2_V1_IMMUTABLE_OBJECT_PLANE\0{key}".encode()
    ).hexdigest()
    headers = {
        "content-length": str(size),
        "content-type": "application/zip",
        "x-oss-forbid-overwrite": "true",
        "x-oss-object-acl": "private",
        "x-oss-meta-padml-context": context,
        "x-oss-server-side-encryption": "AES256",
        "x-oss-meta-padml-sha256": digest,
        "x-oss-meta-padml-size": str(size),
    }
    if public_read:
        _require(
            key.endswith("/thin-worker.zip"),
            "OSS_PUBLIC_READ_SCOPE_INVALID",
        )
        headers["x-oss-object-acl"] = "public-read"
    return headers


def signed_url(
    method: str,
    key: str,
    *,
    headers: Mapping[str, str] | None = None,
    ttl_seconds: int = 900,
    query: Mapping[str, str] | None = None,
) -> str:
    _require(
        method in {"GET", "HEAD", "PUT", "POST", "DELETE"}
        and 60 <= ttl_seconds <= 86400,
        "OSS_SIGN_INPUT_INVALID",
    )
    key = _key(key) if key else ""
    parameters = dict(query or {})
    _require(set(parameters) <= {"uploads", "uploadId", "partNumber", "prefix", "marker",
        "key-marker", "upload-id-marker", "part-number-marker", "max-keys", "max-uploads", "max-parts"},
        "OSS_QUERY_INVALID")
    normalized = {
        name.lower(): " ".join(value.split())
        for name, value in (headers or {}).items()
    }
    normalized['host'] = HOST
    canonical_headers = "".join(
        f"{name}:{value}\n"
        for name, value in sorted(normalized.items())
        if name.startswith("x-oss-") or name in {'host', 'content-type', 'content-md5'}
    )
    timestamp = time.strftime('%Y%m%dT%H%M%SZ', time.gmtime(time.time()))
    date = timestamp[:8]
    scope = f'{date}/cn-beijing/oss/aliyun_v4_request'
    credentials = _credentials()
    parameters.update({
        'x-oss-signature-version': 'OSS4-HMAC-SHA256',
        'x-oss-credential': f'{credentials.access_key_id}/{scope}',
        'x-oss-date': timestamp, 'x-oss-expires': str(ttl_seconds),
        'x-oss-additional-headers': 'host',
    })
    encoded = sorted((urllib.parse.quote(k, safe=''), urllib.parse.quote(v, safe=''))
                     for k, v in parameters.items())
    query_string = '&'.join(k + ('=' + v if v else '') for k, v in encoded)
    resource = urllib.parse.quote(f'/{BUCKET}/{key}', safe='/')
    canonical = f'{method}\n{resource}\n{query_string}\n{canonical_headers}\nhost\nUNSIGNED-PAYLOAD'
    message = f'OSS4-HMAC-SHA256\n{timestamp}\n{scope}\n{hashlib.sha256(canonical.encode()).hexdigest()}'
    signing_key = ('aliyun_v4' + credentials.access_key_secret).encode()
    for component in (date, 'cn-beijing', 'oss', 'aliyun_v4_request'):
        signing_key = hmac.new(signing_key, component.encode(), hashlib.sha256).digest()
    signature = hmac.new(signing_key, message.encode(), hashlib.sha256).hexdigest()
    path = urllib.parse.quote(key, safe="/-_.~")
    return f"https://{HOST}/{path}?{query_string}&x-oss-signature={signature}"


def _token_scope(url, key, extra):
    """Check the exact delegated V4 object capability without an account key."""
    parsed = urllib.parse.urlsplit(url)
    query = urllib.parse.parse_qs(parsed.query, keep_blank_values=True)
    auth = {'x-oss-signature-version', 'x-oss-credential', 'x-oss-date',
            'x-oss-expires', 'x-oss-additional-headers', 'x-oss-signature'}
    _require(parsed.scheme == 'https' and parsed.netloc == HOST and not parsed.fragment
        and urllib.parse.unquote(parsed.path) == '/' + _key(key)
        and set(query) == auth | set(extra) and all(len(v) == 1 for v in query.values())
        and all(query.get(k) == [str(v)] for k, v in extra.items()), 'OSS_TOKEN_SCOPE_INVALID')
    values = {k:v[0] for k,v in query.items()}
    date = values['x-oss-date']
    _require(values['x-oss-signature-version'] == 'OSS4-HMAC-SHA256'
        and values['x-oss-additional-headers'] == 'host'
        and re.fullmatch(r'[0-9]{8}T[0-9]{6}Z', date) is not None
        and re.fullmatch(r'[0-9a-f]{64}', values['x-oss-signature']) is not None
        and re.fullmatch(r'[^/\s]+/' + date[:8] + r'/cn-beijing/oss/aliyun_v4_request',
                         values['x-oss-credential']) is not None
        and values['x-oss-expires'].isdigit(), 'OSS_TOKEN_SCOPE_INVALID')
    try:
        issued = calendar.timegm(time.strptime(date, '%Y%m%dT%H%M%SZ'))
    except ValueError:
        raise ContractError('OSS_TOKEN_SCOPE_INVALID') from None
    ttl = int(values['x-oss-expires'])
    _require(60 <= ttl <= 86400, 'OSS_TOKEN_SCOPE_INVALID')
    _require(-900 <= time.time() - issued < ttl, 'OSS_TOKEN_EXPIRED')


def signed_get(key: str, *, ttl_seconds: int = 900) -> str:
    return signed_url("GET", key, ttl_seconds=ttl_seconds)


def signed_put(
    key: str,
    digest: str,
    size: int,
    *,
    ttl_seconds: int = 900,
    public_read: bool = False,
) -> tuple[str, dict[str, str]]:
    headers = _headers(key, digest, size, public_read=public_read)
    return (
        signed_url("PUT", key, headers=headers, ttl_seconds=ttl_seconds),
        headers,
    )


def _status(stdout: str) -> int:
    rows = [
        row.removeprefix("PADML_STATUS:")
        for row in stdout.splitlines()
        if row.startswith("PADML_STATUS:")
    ]
    return int(rows[0]) if len(rows) == 1 else 0


def _curl(
    method: str,
    url: str,
    *,
    headers: Mapping[str, str] | None = None,
    source: Path | None = None,
    target: Path | None = None,
) -> subprocess.CompletedProcess[str]:
    config = [
        "silent",
        "show-error",
        "fail-with-body",
        "retry = 1",
        'noproxy = "*"',
        "connect-timeout = 15",
        "max-time = 7200",
        'proto = "=https"',
        f'request = "{method}"',
        f'url = "{url}"',
        'write-out = "\\nPADML_STATUS:%{http_code}\\n"',
    ]
    for name, value in sorted((headers or {}).items()):
        config.append(f'header = "{name}: {value}"')
    if method == "PUT":
        _require(source is not None, "OSS_PUT_SOURCE_MISSING")
        config.extend((f'upload-file = "{source}"', 'output = "/dev/null"'))
    elif method == "GET":
        _require(target is not None, "OSS_GET_TARGET_MISSING")
        config.append(f'output = "{target}"')
    else:
        config.extend(("head", 'dump-header = "-"', 'output = "/dev/null"'))
    return subprocess.run(
        ["curl", "--disable", "--config", "-"],
        input="\n".join(config) + "\n",
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        check=False,
        timeout=7210,
    )


def put(
    path: Path, key: str, *, public_read: bool = False
) -> dict[str, object]:
    path = path.resolve(strict=True)
    _require(path.is_file() and not path.is_symlink(), "OSS_PUT_SOURCE_INVALID")
    digest = sha256_file(path)
    size = path.stat().st_size
    url, headers = signed_put(
        key, digest, size, public_read=public_read
    )
    completed = _curl("PUT", url, headers=headers, source=path)
    status = _status(completed.stdout)
    _require(status in {200, 409, 412}, f"OSS_PUT_FAILED:{status}")
    observed = head(key)
    _require(
        observed["size_bytes"] == size
        and observed.get("sha256") == digest
        and observed.get("server_side_encryption") == "AES256",
        "OSS_PUT_HEAD_MISMATCH",
    )
    return {
        "object_key": key,
        "sha256": digest,
        "size_bytes": size,
        "public_read": public_read,
    }


def head(key: str) -> dict[str, object]:
    completed = _curl("HEAD", signed_url("HEAD", key))
    status = _status(completed.stdout)
    _require(
        completed.returncode == 0 and status == 200,
        f"OSS_HEAD_FAILED:{status}",
    )
    values: dict[str, str] = {}
    for line in completed.stdout.splitlines():
        if ":" in line and not line.startswith(("HTTP/", "PADML_STATUS:")):
            name, value = line.split(":", 1)
            values[name.lower().strip()] = value.strip()
    return {
        "object_key": key,
        "size_bytes": int(values["content-length"]),
        "sha256": values.get("x-oss-meta-padml-sha256"),
        "server_side_encryption": values.get(
            "x-oss-server-side-encryption"
        ),
    }


def get(path: Path, key: str, digest: str, size: int) -> dict[str, object]:
    validate_sha256(digest, "oss.get.sha256")
    _require(
        path.is_absolute()
        and path.parent.is_dir()
        and not path.exists()
        and type(size) is int
        and size > 0,
        "OSS_GET_TARGET_INVALID",
    )
    temporary = path.with_name(
        f".{path.name}.{os.getpid()}-{secrets.token_hex(8)}"
    )
    completed = None
    status, observed_size, observed_sha = None, None, None
    phase = "download"
    try:
        completed = _curl("GET", signed_get(key), target=temporary)
        status = _status(completed.stdout)
        _require(
            completed.returncode == 0 and status == 200,
            f"OSS_GET_FAILED:{status}",
        )
        phase = "size"
        observed_size = temporary.stat().st_size
        _require(observed_size == size, f"OSS_GET_FAILED:{status}")
        phase = "sha256"
        observed_sha = sha256_file(temporary)
        _require(observed_sha == digest, f"OSS_GET_FAILED:{status}")
        phase = "publish"
        os.replace(temporary, path)
    except BaseException as exc:
        # Preserve the original failed operation, including partial bytes;
        # a new name or later source version does not authorize another GET.
        stderr = completed.stderr if completed is not None else getattr(exc, "stderr", "")
        if isinstance(stderr, bytes):
            stderr = stderr.decode("utf-8", errors="replace")
        stderr = re.sub(r"https?://\S+|(?:OSSAccessKeyId|Signature|Expires|x-oss-credential|x-oss-signature|x-oss-security-token)[\"']?\s*[:=]\s*(?:\"[^\"]*\"|'[^']*'|[^\s&\"'<>]+)",
                        "[REDACTED]", stderr or "", flags=re.IGNORECASE)
        exists, target_exists, stat_error = None, None, None
        try:
            exists = temporary.is_file()
            if exists:
                observed_size = temporary.stat().st_size
            target_exists = path.exists()
        except OSError as evidence_error:
            stat_error = type(evidence_error).__name__
        exc.add_note("OSS_GET_EVIDENCE:" + json.dumps({
            "phase": phase, "curl_exit_code": None if completed is None else completed.returncode,
            "http_status": status, "expected_size_bytes": size,
            "expected_sha256": digest,
            "actual_size_bytes": observed_size, "evidence_stat_error": stat_error,
            "observed_sha256": observed_sha, "partial_path": str(temporary),
            "partial_retained": exists, "target_exists": target_exists,
            "stderr_excerpt": stderr[:4096], "stderr_truncated": len(stderr) > 4096,
        }, sort_keys=True))
        raise
    return {"object_key": key, "sha256": digest, "size_bytes": size}


def request(method, key='', *, query=None, headers=None, body=None, statuses=(200,)):
    """Small control requests only. Never disclose a signed URL in an exception."""
    headers = {k.lower():v for k,v in (headers or {}).items()}
    if body is not None:
        headers.setdefault('content-type', 'application/xml')
    url = signed_url(method, key, query=query, headers=headers)
    try:
        response = urllib.request.urlopen(urllib.request.Request(url, data=body,
            headers=headers, method=method), timeout=60)
    except urllib.error.HTTPError as error:
        response = error
    except (OSError, TimeoutError):
        raise ContractError('OSS_CONTROL_OUTCOME_UNKNOWN') from None
    with response:
        status = response.status
        data = response.read(4*1024**2+1)
        _require(len(data) <= 4*1024**2, 'OSS_CONTROL_RESPONSE_TOO_LARGE')
        _require(status in statuses, f'OSS_CONTROL_FAILED:{method}:{status}')
        return status, {k.lower():v for k,v in response.headers.items()}, data


def list_objects(prefix):
    _require(prefix.startswith(('padml-relay/', 'padml-environments/')) and prefix.endswith('/'),
        'OSS_PREFIX_INVALID')
    marker = ''; result = []
    while True:
        _, _, raw = request('GET', query={'prefix':prefix, 'marker':marker, 'max-keys':'1000'})
        root = ET.fromstring(raw)
        for item in root.findall('Contents'):
            key = item.findtext('Key')
            _require(key.startswith(prefix), 'OSS_LIST_ESCAPED_PREFIX')
            result.append({'key':key, 'size_bytes':int(item.findtext('Size'))})
        if root.findtext('IsTruncated') != 'true': return result
        next_marker = root.findtext('NextMarker')
        _require(bool(next_marker) and next_marker != marker, 'OSS_LIST_CURSOR_INVALID')
        marker = next_marker


def multipart_uploads(prefix):
    key_marker = upload_marker = ''; result = []
    while True:
        _, _, raw = request('GET', query={'uploads':'', 'prefix':prefix, 'max-uploads':'1000',
            'key-marker':key_marker, 'upload-id-marker':upload_marker})
        root = ET.fromstring(raw)
        for item in root.findall('Upload'):
            key = item.findtext('Key')
            _require(key.startswith(prefix), 'OSS_LIST_ESCAPED_PREFIX')
            result.append({'key':key, 'upload_id':item.findtext('UploadId')})
        if root.findtext('IsTruncated') != 'true': return result
        cursors = root.findtext('NextKeyMarker'), root.findtext('NextUploadIdMarker')
        _require(cursors != (key_marker, upload_marker) and all(cursors), 'OSS_LIST_CURSOR_INVALID')
        key_marker, upload_marker = cursors


def begin_multipart(key, pin, record):
    """Recover the same initiation after a lost reply; never guess a second session."""
    from .reports import _publish
    from .bundle import canonical_json_bytes, strict_json_bytes
    binding = {'object_key':_key(key), 'pin':pin}
    state = {}
    if record.is_file():
        state = strict_json_bytes(record.read_bytes())
        _require(state.get('binding',binding) == binding, 'OSS_UPLOAD_RECORD_DRIFT')
        if state.get('upload_id'): return state['upload_id']
    if state.get('status') == 'INITIATING':
        uploads = [r for r in multipart_uploads(key) if r['key'] == key]
        _require(len(uploads) == 1, 'OSS_INITIATION_UNKNOWN_REQUIRES_RECONCILIATION')
        upload_id = uploads[0]['upload_id']
    else:
        state.update(binding=binding,status='INITIATING')
        _publish(record, canonical_json_bytes(state), 'OSS_UPLOAD_RECORD_DRIFT',replace=True)
        headers = _headers(key, pin['sha256'], pin['size_bytes'])
        headers.pop('content-length')
        headers['x-oss-object-acl'] = 'private'
        headers['x-oss-storage-class'] = 'Standard'
        try:
            _, _, raw = request('POST', key, query={'uploads':''}, headers=headers, body=b'')
        except ContractError as error:
            if re.fullmatch(r'OSS_CONTROL_FAILED:POST:4\d\d',str(error)):
                state['status']='INITIATION_REJECTED'
                _publish(record,canonical_json_bytes(state),'OSS_UPLOAD_RECORD_DRIFT',replace=True)
            raise
        upload_id = ET.fromstring(raw).findtext('UploadId')
    _require(isinstance(upload_id, str) and 0 < len(upload_id) <= 1024, 'OSS_UPLOAD_ID_INVALID')
    _publish(record, canonical_json_bytes({**state,'binding':binding, 'status':'UPLOADING',
        'upload_id':upload_id}), 'OSS_UPLOAD_RECORD_DRIFT', replace=True)
    return upload_id


def multipart_tokens(key, upload_id, size, *, part_size=128*1024**2):
    """Object/part-scoped, expiring capabilities; send only in private stdin."""
    _require(type(size) is int and size > 0 and part_size >= 100*1024, 'OSS_PART_SIZE_INVALID')
    count = (size+part_size-1)//part_size
    _require(count <= 1000, 'OSS_PART_COUNT_EXCEEDED')
    query = {'uploadId':upload_id}
    headers = {'content-type':'application/xml', 'x-oss-forbid-overwrite':'true'}
    return {'key':key, 'upload_id':upload_id, 'size_bytes':size, 'part_size':part_size,
        'parts':[signed_url('PUT', key, query={**query, 'partNumber':str(i)}, ttl_seconds=3600)
            for i in range(1,count+1)],
        'list':signed_url('GET',key,query={**query,'max-parts':'1000'},ttl_seconds=3600),
        'complete':signed_url('POST',key,query=query,headers=headers,ttl_seconds=3600),
        'complete_headers':headers, 'head':signed_url('HEAD',key,ttl_seconds=3600)}


def relay_policy(principal, relay_prefix, environment_prefix):
    """Append these statements to the existing policy; unrelated grants are unchanged."""
    _require(re.fullmatch(r'[0-9]+', principal) is not None, 'OSS_PRINCIPAL_INVALID')
    _require(relay_prefix.startswith('padml-relay/') and environment_prefix.startswith('padml-environments/')
        and all(p.endswith('/') and '..' not in p for p in (relay_prefix,environment_prefix)), 'OSS_PREFIX_INVALID')
    base = {'Effect':'Allow', 'Principal':[principal], 'Condition':{'Bool':{'acs:SecureTransport':['true']}}}
    resource = 'acs:oss:*:*:'+BUCKET
    return [
        {**base, 'Action':['oss:ListObjects'], 'Resource':[resource],
            'Condition':{'Bool':{'acs:SecureTransport':['true']},
                'StringLike':{'oss:Prefix':[relay_prefix+'*',environment_prefix+'*']}}},
        # OSS does not support oss:Prefix for this bucket-level metadata API.
        # This separate read grant was explicitly authorized on 2026-10-09.
        {**base, 'Action':['oss:ListMultipartUploads'], 'Resource':[resource]},
        {**base, 'Action':['oss:PutObject','oss:GetObject','oss:ListParts','oss:AbortMultipartUpload','oss:DeleteObject'],
            'Resource':[resource+'/'+relay_prefix+'*']},
        {**base, 'Action':['oss:PutObject','oss:GetObject','oss:ListParts','oss:AbortMultipartUpload'],
            'Resource':[resource+'/'+environment_prefix+'*']}]


def clear_relay(prefix, *, expected, offline_receipt):
    from . import nested_loco as n
    _require(prefix.startswith('padml-relay/') and prefix.endswith('/') and len(prefix.split('/')) == 4,
        'OSS_RELAY_DELETE_SCOPE_INVALID')
    _require(offline_receipt.get('status') == 'OFFLINE_CONSUMED'
        and offline_receipt.get('relay_prefix') == prefix
        and set(offline_receipt.get('window_identities',{})) == {'6','12','24','36'}
        and offline_receipt.get('object_pins_sha256') == n._sha(expected)
        and n._sealed({k:v for k,v in offline_receipt.items() if k != 'identity_sha256'}) == offline_receipt,
        'OSS_RELAY_OFFLINE_ACCEPTANCE_REQUIRED')
    objects = list_objects(prefix)
    _require(all(r['key'] in expected and expected[r['key']]['size_bytes'] == r['size_bytes']
        for r in objects), 'OSS_RELAY_UNKNOWN_OBJECT')
    for row in objects:
        value = head(row['key'])
        _require({k:value[k] for k in ('sha256','size_bytes')} == expected[row['key']], 'OSS_RELAY_OBJECT_DRIFT')
    uploads = multipart_uploads(prefix)
    _require(all(r['key'] in expected for r in uploads), 'OSS_RELAY_UNKNOWN_MULTIPART')
    for row in objects: request('DELETE',row['key'],statuses=(204,))
    for row in uploads: request('DELETE',row['key'],query={'uploadId':row['upload_id']},statuses=(204,404))
    _require(not list_objects(prefix) and not multipart_uploads(prefix), 'OSS_RELAY_NOT_EMPTY')
    return n._sealed({'status':'RELAY_CLEARED', 'prefix':prefix,
        'generation':offline_receipt['generation'],'offline_identity':offline_receipt['identity_sha256'],
        'objects_deleted':len(objects), 'uploads_aborted':len(uploads)})


def _token_request(method, url, *, headers=None, body=None, statuses=(200,)):
    parsed = urllib.parse.urlsplit(url)
    _require(parsed.scheme == 'https' and parsed.netloc == HOST and not parsed.fragment,
        'OSS_TOKEN_DESTINATION_INVALID')
    try:
        response = urllib.request.urlopen(urllib.request.Request(url, data=body,
            headers=headers or {}, method=method), timeout=60)
    except urllib.error.HTTPError as error:
        response = error
    except (OSError, TimeoutError):
        raise ContractError('OSS_SIGNED_REQUEST_UNKNOWN') from None
    with response:
        raw = response.read(4*1024**2+1)
        _require(len(raw) <= 4*1024**2, 'OSS_CONTROL_RESPONSE_TOO_LARGE')
        _require(response.status in statuses, f'OSS_SIGNED_REQUEST_FAILED:{method}:{response.status}')
        return response.status, {k.lower():v for k,v in response.headers.items()}, raw


def upload_parts(path, pin, tokens):
    """Linux sender; it has expiring object capabilities, never an account key."""
    import http.client
    _require(path.is_file() and not path.is_symlink() and path.stat().st_size == pin['size_bytes']
        and tokens['size_bytes'] == pin['size_bytes'], 'OSS_UPLOAD_SOURCE_DRIFT')
    validate_sha256(pin['sha256'], 'oss.upload.sha256')
    key = _key(tokens['key'])
    def token_scope(url, extra):
        _token_scope(url, key, extra)
    _require(type(tokens['part_size']) is int and tokens['part_size'] >= 100*1024,
        'OSS_PART_SIZE_INVALID')
    query = {'uploadId':tokens['upload_id']}
    token_scope(tokens['head'], {})
    token_scope(tokens['list'], {**query,'max-parts':'1000'})
    token_scope(tokens['complete'], query)
    _require(tokens['complete_headers'] == {'content-type':'application/xml',
        'x-oss-forbid-overwrite':'true'}, 'OSS_TOKEN_SCOPE_INVALID')
    for i,url in enumerate(tokens['parts'],1): token_scope(url,{**query,'partNumber':str(i)})
    stamp = path.stat()
    size, part_size = pin['size_bytes'], tokens['part_size']
    count = (size+part_size-1)//part_size
    _require(0 < count <= 1000 and len(tokens['parts']) == count, 'OSS_PART_COUNT_EXCEEDED')
    status, headers, _ = _token_request('HEAD',tokens['head'],statuses=(200,404))
    if status == 200:
        _require(int(headers['content-length']) == size and headers.get('x-oss-meta-padml-sha256') == pin['sha256']
            and headers.get('x-oss-server-side-encryption') == 'AES256', 'OSS_COMPLETED_OBJECT_DRIFT')
        return
    _, _, raw = _token_request('GET',tokens['list'])
    root = ET.fromstring(raw)
    _require(root.findtext('Key') == key and root.findtext('UploadId') == tokens['upload_id'],
        'OSS_PART_LIST_IDENTITY_DRIFT')
    _require(root.findtext('IsTruncated') != 'true', 'OSS_PART_LIST_TRUNCATED')
    parts = {}
    for row in root.findall('Part'):
        number = int(row.findtext('PartNumber')); length = int(row.findtext('Size'))
        _require(1 <= number <= count and number not in parts
            and length == min(part_size,size-(number-1)*part_size), 'OSS_RETAINED_PART_DRIFT')
        parts[number] = row.findtext('ETag')
    with path.open('rb') as stream:
        for number, url in enumerate(tokens['parts'],1):
            if number in parts: continue
            parsed = urllib.parse.urlsplit(url)
            _require(parsed.scheme == 'https' and parsed.netloc == HOST, 'OSS_TOKEN_DESTINATION_INVALID')
            length = min(part_size,size-(number-1)*part_size)
            stream.seek((number-1)*part_size)
            digest = hashlib.md5()
            connection = http.client.HTTPSConnection(HOST,timeout=60)
            try:
                connection.putrequest('PUT',parsed.path+'?'+parsed.query)
                connection.putheader('Content-Length',str(length)); connection.endheaders()
                remaining = length
                while remaining:
                    block = stream.read(min(1024**2,remaining))
                    _require(bool(block),'OSS_UPLOAD_SOURCE_SHORT')
                    digest.update(block); connection.send(block); remaining -= len(block)
                response = connection.getresponse()
                _require(response.status == 200,f'OSS_PART_FAILED:{response.status}')
                etag = response.getheader('ETag')
                _require(etag is not None and etag.strip('"').lower() == digest.hexdigest(), 'OSS_PART_BYTES_DRIFT')
                parts[number] = etag
                response.read(4096)
            except (OSError,TimeoutError,http.client.HTTPException):
                raise ContractError('OSS_PART_OUTCOME_UNKNOWN') from None
            finally:
                connection.close()
    after = path.stat()
    _require((stamp.st_dev,stamp.st_ino,stamp.st_size,stamp.st_mtime_ns,stamp.st_ctime_ns) ==
        (after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns,after.st_ctime_ns), 'OSS_UPLOAD_SOURCE_CHANGED')
    root = ET.Element('CompleteMultipartUpload')
    for number in range(1,count+1):
        part = ET.SubElement(root,'Part')
        ET.SubElement(part,'PartNumber').text=str(number)
        ET.SubElement(part,'ETag').text=parts[number]
    _token_request('POST',tokens['complete'],headers=tokens['complete_headers'],
        body=ET.tostring(root),statuses=(200,409))
    _, headers, _ = _token_request('HEAD',tokens['head'])
    _require(int(headers['content-length']) == size and headers.get('x-oss-meta-padml-sha256') == pin['sha256']
        and headers.get('x-oss-server-side-encryption') == 'AES256', 'OSS_COMPLETED_OBJECT_DRIFT')


def download_resume(path, key, pin, *, before_write=None, capability=None):
    """One Range stream and one SHA pass per resumed prefix, durable ExFAT publish."""
    from .reports import _persist_published
    from .bundle import sha256_file
    if capability is not None:
        _token_scope(capability, key, {})
    _require(path.is_absolute() and path.parent.is_dir() and not path.is_symlink(), 'OSS_GET_TARGET_INVALID')
    if path.exists():
        _require(path.stat().st_size == pin['size_bytes'] and sha256_file(path) == pin['sha256'], 'OSS_GET_BYTES_DRIFT')
        _persist_published(path)
        return pin
    part = path.with_name(path.name+'.part')
    _require(not part.is_symlink(), 'OSS_GET_TARGET_INVALID')
    count = 0; digest = hashlib.sha256()
    if part.exists():
        with part.open('rb') as stream:
            while block := stream.read(1024**2): digest.update(block); count += len(block)
    _require(count <= pin['size_bytes'],'OSS_GET_PART_TOO_LARGE')
    if count == pin['size_bytes'] and digest.hexdigest() != pin['sha256']:
        # Only this failed, fully received unpublished partial is disposable.
        # Retain its small diagnosis, not another full corrupted byte copy.
        from .reports import _publish
        from .bundle import canonical_json_bytes
        _publish(part.with_name(part.name+'.failed.json'),canonical_json_bytes({
            'expected':pin,'observed_sha256':digest.hexdigest(),'size_bytes':count,
            'reason':'FAILED_UNPUBLISHED_COMPLETE_PARTIAL'}),'OSS_PART_FAILURE_DRIFT',replace=True)
        part.unlink();count=0;digest=hashlib.sha256()
    if before_write is not None: before_write(pin['size_bytes']-count)
    if count < pin['size_bytes']:
        headers = {'Range':f'bytes={count}-'} if count else {}
        req = urllib.request.Request(capability or signed_get(key,ttl_seconds=3600),headers=headers)
        try: response = urllib.request.urlopen(req,timeout=60)
        except (OSError,TimeoutError): raise ContractError('OSS_DOWNLOAD_UNKNOWN_PART_RETAINED') from None
        with response:
            _require(response.status == (206 if count else 200), 'OSS_RANGE_NOT_HONORED')
            if count:
                _require(response.headers.get('Content-Range') ==
                    f"bytes {count}-{pin['size_bytes']-1}/{pin['size_bytes']}", 'OSS_RANGE_DRIFT')
            with part.open('ab') as output:
                try:
                    while block := response.read(1024**2):
                        count += len(block)
                        _require(count <= pin['size_bytes'],'OSS_GET_SIZE_DRIFT')
                        digest.update(block); output.write(block)
                except (OSError,TimeoutError):
                    raise ContractError('OSS_DOWNLOAD_UNKNOWN_PART_RETAINED') from None
                finally: output.flush(); os.fsync(output.fileno())
    _require(count == pin['size_bytes'] and digest.hexdigest() == pin['sha256'], 'OSS_GET_BYTES_DRIFT')
    os.replace(part,path); _persist_published(path)
    return pin
