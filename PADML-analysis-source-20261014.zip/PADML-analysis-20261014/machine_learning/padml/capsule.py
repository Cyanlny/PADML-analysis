from __future__ import annotations

import os
import tempfile
from pathlib import Path
from typing import Any, Mapping

from ._science_authority import (
    load_science_authority,
    selected_route_profiles,
    validate_route_profile_map,
)
from .bundle import (
    ContractError,
    canonical_json_bytes,
    read_safe_zip,
    sha256_bytes,
    sha256_file,
    strict_json_bytes,
    validate_envelope,
    validate_sha256,
    write_deterministic_zip,
)
from .f1_contract import (
    DIRECT_UNIT_IDS,
    load_f1_input_manifest,
    validate_f1_input_manifest,
)
from .f2 import (
    canonical_unit_ids,
    compile_f2_plan,
    materialize_requests,
    selector_checkpoint_projection,
)
from .f2_kernel import expected_model_inputs_from_approved_f1, validate_expected_model_input


def _require(condition: bool, reason: str) -> None:
    if not condition:
        raise ContractError(reason)


def build_common_input(
    *, manifest_path: Path, result_root: Path, target: Path, scratch_parent: Path
) -> dict[str, Any]:
    manifest = load_f1_input_manifest(manifest_path)
    result_paths = {unit_id: result_root / f"{unit_id}.zip" for unit_id in DIRECT_UNIT_IDS}
    _require(
        target.is_absolute() and target.parent.is_dir() and not target.exists()
        and scratch_parent.is_absolute() and scratch_parent.is_dir(),
        "F2_COMMON_INPUT_TARGET_INVALID",
    )
    with tempfile.TemporaryDirectory(prefix="f2-input-replay-", dir=scratch_parent) as temporary:
        model_inputs = expected_model_inputs_from_approved_f1(
            manifest,
            [dict(row) for row in manifest["direct_objects"]],
            result_paths,
            Path(temporary).resolve(),
            load_science_authority(),
        )
    _require(
        [row["fold"] for row in model_inputs] == list(range(1, 7))
        and all(validate_expected_model_input(row) == row for row in model_inputs),
        "F2_MODEL_INPUT_REPLAY_INVALID",
    )
    registry = {
        "schema_version": "1.0.0",
        "kind": "PADML_F2_V1_APPROVED_INPUT_REGISTRY",
        "f1_input_manifest": manifest,
        "direct_objects": manifest["direct_objects"],
        "model_inputs": model_inputs,
    }
    registry["identity"] = sha256_bytes(canonical_json_bytes(registry))
    registry_bytes = canonical_json_bytes(registry)
    common_manifest = {
        "schema_version": "1.0.0",
        "kind": "PADML_F2_V1_COMMON_INPUT",
        "status": "PASS",
        "f1_input_manifest_identity": manifest["identity"],
        "model_input_count": 6,
        "registry_sha256": sha256_bytes(registry_bytes),
        "registry_size_bytes": len(registry_bytes),
    }
    write_deterministic_zip(
        target,
        {"manifest.json": canonical_json_bytes(common_manifest), "approved-f1.json": registry_bytes},
    )
    os.chmod(target, 0o600)
    return {
        "path": str(target),
        "sha256": sha256_file(target),
        "size_bytes": target.stat().st_size,
        "registry_identity": registry["identity"],
        "model_input_set_sha256": sha256_bytes(canonical_json_bytes(model_inputs)),
    }


def load_common_input(path: Path) -> dict[str, Any]:
    _require(path.is_absolute() and path.is_file() and not path.is_symlink(), "F2_COMMON_INPUT_PATH_INVALID")
    entries = read_safe_zip(
        path,
        expected_members={"manifest.json", "approved-f1.json"},
        max_member_bytes=64 * 1024 * 1024,
        max_total_bytes=128 * 1024 * 1024,
    )
    manifest = strict_json_bytes(entries["manifest.json"], "F2_COMMON_INPUT_MANIFEST")
    registry = strict_json_bytes(entries["approved-f1.json"], "F2_APPROVED_INPUT_REGISTRY")
    _require(
        canonical_json_bytes(manifest) == entries["manifest.json"]
        and canonical_json_bytes(registry) == entries["approved-f1.json"]
        and manifest["registry_sha256"] == sha256_bytes(entries["approved-f1.json"])
        and registry["identity"] == sha256_bytes(canonical_json_bytes({key: item for key, item in registry.items() if key != "identity"}))
        and validate_f1_input_manifest(registry["f1_input_manifest"])["identity"] == manifest["f1_input_manifest_identity"]
        and registry["direct_objects"] == registry["f1_input_manifest"]["direct_objects"]
        and [validate_expected_model_input(row)["fold"] for row in registry["model_inputs"]] == list(range(1, 7)),
        "F2_COMMON_INPUT_INVALID",
    )
    return registry


def build_capsule(
    *, run_id: str, source_identity: str, runtime_identity: str,
    worker_identity: str, common_input_path: Path, target: Path,
    selector_search_reuse: Mapping[str, Any] | None = None,
    selector_primary_reuse: Mapping[str, Any] | None = None,
    selector_result_reuse: Mapping[str, Any] | None = None,
    p2c2t_pool_workers: Mapping[str, int] | None = None,
    unit_pool_workers: Mapping[str, int] | None = None,
) -> dict[str, Any]:
    _require(sum(value is not None for value in
                 (selector_search_reuse, selector_primary_reuse, selector_result_reuse)) <= 1,
             "F2_SELECTOR_REUSE_MODE_CONFLICT")
    registry = load_common_input(common_input_path)
    input_identity = registry["f1_input_manifest"]["identity"]
    requests = materialize_requests(
        run_id=run_id,
        source_identity=source_identity,
        runtime_identity=runtime_identity,
        worker_identity=worker_identity,
        input_identity=input_identity,
        p2c2t_pool_workers=p2c2t_pool_workers,
        unit_pool_workers=unit_pool_workers,
    )
    plan = compile_f2_plan(p2c2t_pool_workers=p2c2t_pool_workers,
                           unit_pool_workers=unit_pool_workers)
    manifest = {
        "schema_version": "1.0.0",
        "kind": "PADML_F2_V1_CAPSULE_MANIFEST",
        "run_id": run_id,
        "stage_id": "F2",
        "plan": plan,
        "identity_records": {
            "approved_predecessor": {"manifest_identity": input_identity},
            "execution_plan": {"route_profiles": selected_route_profiles()},
        },
        "request_index": [
            {"unit_id": unit_id, "request_sha256": sha256_bytes(canonical_json_bytes(requests[unit_id]))}
            for unit_id in canonical_unit_ids()
        ],
        "common_input": {"sha256": sha256_file(common_input_path), "size_bytes": common_input_path.stat().st_size},
    }
    if selector_search_reuse is not None:
        manifest["selector_search_reuse"] = dict(selector_search_reuse)
    if selector_primary_reuse is not None:
        _require(selector_search_reuse is None, "F2_SELECTOR_REUSE_MODE_CONFLICT")
        manifest["selector_primary_reuse"] = dict(selector_primary_reuse)
    if selector_result_reuse is not None:
        manifest["selector_result_reuse"] = dict(selector_result_reuse)
    manifest["identity"] = sha256_bytes(canonical_json_bytes(manifest))
    entries = {
        "manifest.json": canonical_json_bytes(manifest),
        "authority.json": canonical_json_bytes(load_science_authority()),
        **{f"requests/{unit_id}.json": canonical_json_bytes(requests[unit_id]) for unit_id in canonical_unit_ids()},
    }
    _require(target.is_absolute() and target.parent.is_dir() and not target.exists(), "F2_CAPSULE_TARGET_INVALID")
    write_deterministic_zip(target, entries)
    os.chmod(target, 0o600)
    load_capsule(target, common_input_path)
    return {
        "path": str(target), "sha256": sha256_file(target),
        "size_bytes": target.stat().st_size, "identity": manifest["identity"],
    }


def load_capsule(path: Path, common_input_path: Path) -> dict[str, Any]:
    entries = read_safe_zip(path, max_member_bytes=64 * 1024 * 1024, max_total_bytes=256 * 1024 * 1024)
    manifest = strict_json_bytes(entries["manifest.json"], "F2_CAPSULE_MANIFEST")
    authority = strict_json_bytes(entries["authority.json"], "F2_CAPSULE_AUTHORITY")
    unit_workers = {unit["unit_id"]: unit["internal_threads"]
                    for unit in manifest["plan"]["units"][:-1]}
    _require(
        canonical_json_bytes(manifest) == entries["manifest.json"]
        and authority == load_science_authority()
        and manifest["identity"] == sha256_bytes(canonical_json_bytes({key: item for key, item in manifest.items() if key != "identity"}))
        and manifest["plan"] == compile_f2_plan(unit_pool_workers=unit_workers)
        and manifest["plan"]["selector_checkpoint_projection"]
        == selector_checkpoint_projection(authority)
        and validate_route_profile_map(
            manifest["identity_records"]["execution_plan"]["route_profiles"],
            require_formal=True,
        )
        == selected_route_profiles()
        and tuple(row["unit_id"] for row in manifest["request_index"]) == canonical_unit_ids(),
        "F2_CAPSULE_INVALID",
    )
    expected_members = {"manifest.json", "authority.json", *(f"requests/{unit_id}.json" for unit_id in canonical_unit_ids())}
    _require(set(entries) == expected_members, "F2_CAPSULE_MEMBER_SET_INVALID")
    requests = {
        unit_id: strict_json_bytes(entries[f"requests/{unit_id}.json"], f"F2_REQUEST:{unit_id}")
        for unit_id in canonical_unit_ids()
    }
    _require(
        all(requests[unit["unit_id"]]["plan"]["internal_threads"] == unit["internal_threads"]
            for unit in manifest["plan"]["units"]),
        "F2_REQUEST_POOL_MISMATCH",
    )
    _require(
        all(
            manifest["request_index"][index]["request_sha256"] == sha256_bytes(canonical_json_bytes(requests[unit_id]))
            for index, unit_id in enumerate(canonical_unit_ids())
        )
        and manifest["common_input"] == {"sha256": sha256_file(common_input_path), "size_bytes": common_input_path.stat().st_size},
        "F2_CAPSULE_REQUEST_OR_INPUT_DRIFT",
    )
    registry = load_common_input(common_input_path)
    fpm_reuse = manifest.get("fpm_fixed_reuse", {})
    _require(isinstance(fpm_reuse, dict), "F2_FPM_REUSE_SOURCE_INVALID")
    for unit_id, source in fpm_reuse.items():
        _require(unit_id in requests and (unit_id in {
                     "p2c2t-center-blocked-stress", "p2c2t-locked-model-sample-size-diagnostic"}
                 or unit_id in {f"model-f{fold}-fpm-tvc-set-a" for fold in range(1, 7)})
                 and isinstance(source, dict) and set(source) == {"sha256", "size_bytes", "task_id"}
                 and type(source["size_bytes"]) is int and source["size_bytes"] > 0
                 and isinstance(source["task_id"], str) and source["task_id"],
                 "F2_FPM_REUSE_SOURCE_INVALID")
        validate_sha256(source["sha256"], "fpm_fixed_reuse.sha256")
    reuse = manifest.get("selector_search_reuse", {})
    _require(isinstance(reuse, dict) and (
        "selector_search_reuse" not in manifest or set(reuse) == set(canonical_unit_ids()[:6])),
             "F2_SELECTOR_SEARCH_SOURCE_SET_INVALID")
    for fold, unit_id in enumerate(canonical_unit_ids()[:6], start=1):
        if unit_id in reuse:
            validate_selector_search_source(reuse[unit_id], requests[unit_id], registry["model_inputs"][fold - 1])
    primary = manifest.get("selector_primary_reuse", {})
    _require(isinstance(primary, dict) and ("selector_primary_reuse" not in manifest or
             not reuse and set(primary) == set(canonical_unit_ids()[:6])), "F2_SELECTOR_PRIMARY_SOURCE_SET_INVALID")
    for fold, unit_id in enumerate(canonical_unit_ids()[:6], start=1):
        if unit_id in primary:
            validate_selector_primary_source(primary[unit_id], requests[unit_id], registry["model_inputs"][fold - 1])
    results = manifest.get("selector_result_reuse", {})
    _require(isinstance(results, dict) and ("selector_result_reuse" not in manifest or
             not reuse and not primary and set(results) == set(canonical_unit_ids()[:6])),
             "F2_SELECTOR_RESULT_SOURCE_SET_INVALID")
    for fold, unit_id in enumerate(canonical_unit_ids()[:6], start=1):
        if unit_id in results:
            validate_selector_result_source(results[unit_id], requests[unit_id], registry["model_inputs"][fold - 1])
    return {
        "run_id": manifest["run_id"],
        "manifest": manifest,
        "authority_slice": authority,
        "runtime": {"f2_backend": "CPU"},
        "requests": requests,
        "approved_registry": registry,
    }


def expected_f2_model_input(capsule: Mapping[str, Any], unit_id: str) -> dict[str, Any] | None:
    request = capsule["requests"][unit_id]
    if request["plan"]["action"] != "MODEL_DEVELOPMENT":
        return None
    coordinates = {row["axis"]: row["value"] for row in request["plan"]["coordinates"]}
    fold = coordinates["outer_fold"]
    return validate_expected_model_input(capsule["approved_registry"]["model_inputs"][fold - 1])


def primary_science_identity(authority: Mapping[str, Any]) -> str:
    """Exclude only this numerical correction, not seeds, grids or EPV rules."""
    science = authority["science"]
    f2 = science["f2_model_development"]
    sensitivity = f2["selector_sensitivity"]
    preserved_sensitivity = {
        **sensitivity,
        "mrmre": {key: value for key, value in sensitivity["mrmre"].items()
                  if key not in {"version", "implementation", "association_validation", "numerical_warning_policy"}},
        "boruta": {key: value for key, value in sensitivity["boruta"].items()
                   if key not in {"importance_validation", "numerical_warning_policy"}},
    }
    return sha256_bytes(canonical_json_bytes({**authority, "science": {
        **science, "f2_model_development": {**f2, "selector_sensitivity": preserved_sensitivity},
    }}))


def selector_result_projection(value: Mapping[str, Any]) -> dict[str, Any]:
    """Preserve all completed science except the independently replayed outer score."""
    execution = value.get("registered_partition_execution")
    _require(value.get("family") == "ELASTIC_NET_COX" and isinstance(execution, dict)
             and isinstance(execution.get("partitions"), list)
             and all(isinstance(row, dict) for row in execution["partitions"])
             and sum(row.get("kind") == "OUTER" for row in execution["partitions"]) == 1,
             "F2_SELECTOR_RESULT_REUSE_SCOPE_INVALID")
    # Keep the prediction seal, all inner scores, search paths, parameters,
    # recipes, SetA, sensitivity evidence and previous primary-reuse receipt.
    return {**{key: item for key, item in value.items() if key != "result_reuse"},
            "registered_partition_execution": {
                **{key: item for key, item in execution.items() if key != "identity"},
                "partitions": [
                    {key: item for key, item in row.items()
                     if key not in {"ibs_0_24", "metric_set_sha256", "metric_qc"}}
                    if row["kind"] == "OUTER" else row
                    for row in execution["partitions"]]}}


def result_reuse_receipt(source: Mapping[str, Any]) -> dict[str, Any]:
    return {"schema_version": "1.0.0", "source_identity": source["identity"],
            "current_elastic_fit_count": 0, "current_search_path_count": 0,
            "current_sensitivity_fit_count": 0, "reused_outer_fit_count": 20,
            "reused_inner_partition_count": 15, "reused_sensitivity_fit_count": 40,
            "outer_metric_recomputed": True}


def validate_selector_result_source(source: Any, request: Mapping[str, Any],
                                   model_input: Mapping[str, Any]) -> dict[str, Any]:
    _require(isinstance(source, dict) and set(source) == {
        "schema_version", "kind", "source_run_identity", "source_capsule_sha256",
        "source_request", "source_result", "preserved_value_sha256", "model_input_identity", "identity",
    } and source.get("schema_version") == "1.0.0"
        and source.get("kind") == "PADML_F2_SELECTOR_RESULT_REUSE"
        and source.get("identity") == sha256_bytes(canonical_json_bytes(
            {key: item for key, item in source.items() if key != "identity"})),
        "F2_SELECTOR_RESULT_SOURCE_INVALID")
    previous = validate_envelope(source["source_request"])
    _require(previous["kind"] == "request" and previous["stage_id"] == "F2"
             and previous["unit_id"] in canonical_unit_ids()[:6]
             and previous["run_id"] != request["run_id"]
             and all(previous[field] == request[field] for field in ("unit_id", "seed", "plan", "artifacts"))
             and all(previous["identities"][axis] == request["identities"][axis]
                     for axis in ("authority", "input", "plan"))
             and source["model_input_identity"] == model_input["identity"],
             "F2_SELECTOR_RESULT_SOURCE_SCIENCE_MISMATCH")
    record = source["source_result"]
    _require(isinstance(record, dict) and set(record) == {"object_key", "sha256", "size_bytes"}
             and type(record["size_bytes"]) is int and record["size_bytes"] > 0
             and record["object_key"] == f"v22/padml/science/{previous['run_id']}/F2/"
                 f"{previous['transaction_id']}/{previous['unit_id']}/result.zip",
             "F2_SELECTOR_RESULT_SOURCE_OBJECT_INVALID")
    for digest in (source["source_run_identity"], source["source_capsule_sha256"],
                   source["preserved_value_sha256"], source["model_input_identity"], record["sha256"]):
        validate_sha256(digest, "selector.result_source")
    return source


def selector_primary_projection(value: Mapping[str, Any]) -> dict[str, Any]:
    _require(value.get("family") == "ELASTIC_NET_COX" and isinstance(value.get("selector_evidence"), dict),
             "F2_PRIMARY_REUSE_SCOPE_INVALID")
    # Preserve every fit, prediction, search, recipe and SetA byte. Remove only
    # the sensitivity payload, its dependent hashes and current reuse receipt.
    return {**{key: item for key, item in value.items()
               if key not in {"primary_reuse", "selector_evidence_sha256", "science_contract_sha256"}},
            "selector_evidence": {key: item for key, item in value["selector_evidence"].items()
                                  if key not in {"sensitivity_evidence", "selector_execution_identity_sha256"}}}


def primary_reuse_receipt(source: Mapping[str, Any]) -> dict[str, Any]:
    return {"schema_version": "1.0.0", "source_identity": source["identity"],
            "current_elastic_fit_count": 0, "current_search_path_count": 0,
            "reused_outer_fit_count": 20, "reused_inner_partition_count": 15}


def validate_selector_primary_source(source: Any, request: Mapping[str, Any],
                                    model_input: Mapping[str, Any]) -> dict[str, Any]:
    _require(isinstance(source, dict) and set(source) == {
        "schema_version", "kind", "source_run_identity", "source_capsule_sha256", "source_request",
        "source_result", "primary_science_identity", "primary_sha256", "model_input_identity",
        "selector_search_reuse", "archive", "identity",
    } and source.get("schema_version") == "1.0.0" and source.get("kind") == "PADML_F2_SELECTOR_PRIMARY_REUSE"
        and source.get("identity") == sha256_bytes(canonical_json_bytes({key: value for key, value in source.items()
                                                                       if key != "identity"})),
        "F2_SELECTOR_PRIMARY_SOURCE_INVALID")
    previous = validate_envelope(source["source_request"])
    _require(previous["kind"] == "request" and previous["stage_id"] == "F2"
             and previous["unit_id"] in canonical_unit_ids()[:6] and previous["run_id"] != request["run_id"]
             and all(previous[field] == request[field] for field in ("unit_id", "seed", "plan", "artifacts"))
             and all(previous["identities"][axis] == request["identities"][axis] for axis in ("input", "plan"))
             and source["model_input_identity"] == model_input["identity"]
             and source["primary_science_identity"] == primary_science_identity(load_science_authority()),
             "F2_SELECTOR_PRIMARY_SOURCE_SCIENCE_MISMATCH")
    for record, origin, name in ((source["source_result"], previous, "result"), (source["archive"], request, "primary")):
        _require(isinstance(record, dict) and set(record) == {"object_key", "sha256", "size_bytes"}
                 and type(record["size_bytes"]) is int and record["size_bytes"] > 0
                 and record["object_key"] == f"v22/padml/science/{origin['run_id']}/F2/"
                     f"{origin['transaction_id']}/{origin['unit_id']}/{name}.zip", "F2_SELECTOR_PRIMARY_OBJECT_INVALID")
        validate_sha256(record["sha256"], "primary.archive")
    for field in ("source_run_identity", "source_capsule_sha256", "primary_science_identity", "primary_sha256", "model_input_identity"):
        validate_sha256(source[field], "primary." + field)
    search = source["selector_search_reuse"]
    _require(isinstance(search, dict) and search.get("kind") == "PADML_F2_ELASTIC_SEARCH_REUSE"
             and search.get("identity") == sha256_bytes(canonical_json_bytes({key: item for key, item in search.items()
                                                                            if key != "identity"}))
             and search.get("model_input_identity") == model_input["identity"], "F2_PRIMARY_SEARCH_SOURCE_INVALID")
    return source


def load_selector_primary(path: Path, source: Mapping[str, Any], request: Mapping[str, Any],
                          model_input: Mapping[str, Any]) -> dict[str, Any]:
    validate_selector_primary_source(source, request, model_input)
    _require(path.is_absolute() and path.is_file() and not path.is_symlink() and path.resolve(strict=True) == path,
             "F2_SELECTOR_PRIMARY_PATH_INVALID")
    raw = path.read_bytes()
    _require(len(raw) == source["archive"]["size_bytes"] and sha256_bytes(raw) == source["archive"]["sha256"],
             "F2_SELECTOR_PRIMARY_ARCHIVE_INVALID")
    payload = read_safe_zip(raw, expected_members={"primary.json"})["primary.json"]
    value = strict_json_bytes(payload, "primary.json")
    _require(canonical_json_bytes(value) == payload and sha256_bytes(payload) == source["primary_sha256"]
             and value == selector_primary_projection(value)
             and value.get("model_input") == model_input
             and value.get("search_trace", {}).get("search_reuse") == source["selector_search_reuse"],
             "F2_SELECTOR_PRIMARY_PAYLOAD_INVALID")
    return value


def validate_selector_search_source(
    source: Any, request: Mapping[str, Any], model_input: Mapping[str, Any],
) -> dict[str, Any]:
    """Bind reused paths to their actual previous request, never to a new fit."""
    _require(
        isinstance(source, dict)
        and set(source) == {
            "schema_version", "kind", "source_run_identity", "source_capsule_sha256",
            "source_request", "archive", "model_input_identity",
            "derivation_records_sha256", "identity",
        }
        and source.get("schema_version") == "1.0.0"
        and source.get("kind") == "PADML_F2_ELASTIC_SEARCH_REUSE"
        and isinstance(source.get("source_request"), dict)
        and isinstance(source.get("archive"), dict)
        and set(source["archive"]) == {"object_key", "sha256", "size_bytes"}
        and source.get("model_input_identity") == model_input.get("identity")
        and source.get("identity") == sha256_bytes(canonical_json_bytes(
            {key: value for key, value in source.items() if key != "identity"}
        )),
        "F2_SELECTOR_SEARCH_SOURCE_INVALID",
    )
    previous = validate_envelope(source["source_request"])
    _require(
        previous["kind"] == "request" and previous["stage_id"] == "F2"
        and previous["unit_id"] in canonical_unit_ids()[:6]
        and previous["run_id"] != request["run_id"]
        and all(previous[field] == request[field] for field in ("unit_id", "seed", "plan", "artifacts"))
        and all(previous["identities"][axis] == request["identities"][axis]
                for axis in ("authority", "input", "runtime", "plan"))
        and previous == materialize_requests(
            run_id=previous["run_id"], source_identity=previous["identities"]["source"],
            runtime_identity=previous["identities"]["runtime"], worker_identity=previous["identities"]["worker"],
            input_identity=previous["identities"]["input"],
        )[previous["unit_id"]],
        "F2_SELECTOR_SEARCH_SOURCE_REQUEST_MISMATCH",
    )
    archive = source["archive"]
    _require(
        archive["object_key"] == (
            f"v22/padml/science/{previous['run_id']}/F2/"
            f"{previous['transaction_id']}/{previous['unit_id']}/fine-search.zip"
        )
        and type(archive["size_bytes"]) is int and archive["size_bytes"] > 0,
        "F2_SELECTOR_SEARCH_SOURCE_OBJECT_INVALID",
    )
    for digest in (source["source_run_identity"], source["source_capsule_sha256"],
                   source["model_input_identity"], source["derivation_records_sha256"], archive["sha256"]):
        validate_sha256(digest, "selector.search_source")
    return source


def load_selector_search(
    path: Path, source: Mapping[str, Any], request: Mapping[str, Any],
    model_input: Mapping[str, Any],
) -> dict[str, Any]:
    validate_selector_search_source(source, request, model_input)
    _require(path.is_absolute() and path.is_file() and not path.is_symlink()
             and path.resolve(strict=True) == path, "F2_SELECTOR_SEARCH_ARCHIVE_PATH_INVALID")
    raw = path.read_bytes()
    _require(len(raw) == source["archive"]["size_bytes"]
             and sha256_bytes(raw) == source["archive"]["sha256"], "F2_SELECTOR_SEARCH_ARCHIVE_IDENTITY_INVALID")
    entries = read_safe_zip(raw, expected_members={"selector-search.json"})
    value = strict_json_bytes(entries["selector-search.json"], "selector-search.json")
    previous = source["source_request"]
    contract = load_science_authority()["science"]["f2_model_development"]["selector_contract"]
    _require(
        isinstance(value, dict) and set(value) == {
            "schema_version", "kind", "unit_id", "transaction_id", "identities",
            "selector_contract_sha256", "recipe_set_sha256", "phase", "derivation_records",
            "scientific_acceptance",
        }
        and canonical_json_bytes(value) == entries["selector-search.json"]
        and value["schema_version"] == "1.0.0" and value["kind"] == "PADML_F2_SELECTOR_SEARCH_EVIDENCE"
        and value["phase"] == "fine" and value["scientific_acceptance"] is False
        and all(value[field] == previous[field] for field in ("unit_id", "transaction_id", "identities"))
        and value["selector_contract_sha256"] == sha256_bytes(canonical_json_bytes(contract))
        and value["recipe_set_sha256"] == model_input["selector_recipe_expectations"]["recipe_set_sha256"]
        and isinstance(value["derivation_records"], list)
        and sha256_bytes(canonical_json_bytes(value["derivation_records"])) == source["derivation_records_sha256"],
        "F2_SELECTOR_SEARCH_ARCHIVE_BINDING_INVALID",
    )
    return value
