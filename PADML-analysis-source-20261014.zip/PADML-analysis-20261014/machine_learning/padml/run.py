from __future__ import annotations

from .runtime import MIN_WORKER_MEMORY_BYTES

import argparse
import json
import os
import re
from pathlib import Path
from threading import RLock
from typing import Any, Mapping

from ._science_authority import load_science_authority
from .bundle import (
    ContractError,
    canonical_json_bytes,
    execution_result_contract,
    read_safe_zip,
    sha256_bytes,
    sha256_file,
    strict_json_bytes,
    validate_envelope,
    validate_sha256,
    write_deterministic_zip,
)
from .capsule import (
    build_capsule,
    expected_f2_model_input,
    load_capsule,
    load_common_input,
    load_selector_search,
)
from .f1_contract import load_f1_input_manifest
from .f2 import canonical_unit_ids, materialize_requests
from .f2_kernel import aggregate_confirmation
from .f2_validation import (
    admitted_source_record,
    validate_f2_stage_values,
    validate_f2_unit_result,
)
from .runtime_bundle import RUNTIME_IDENTITY
from .runtime import pool_capacity


DEFAULT_RUNTIME_ROOT = Path(
    "/Users/liuningyuan/Desktop/PAD/PADML_F2_V1_Runtime"
)
HOSTS = ("H0", "H1", "H4", "H5", "H6", "H7")
WORKER_FILES = (
    "padml/__init__.py",
    "padml/_science_authority.py",
    "padml/bundle.py",
    "padml/capsule.py",
    "padml/f1.py",
    "padml/f1_contract.py",
    "padml/f1_kernel.py",
    "padml/f2.py",
    "padml/f2_kernel.py",
    "padml/f2_validation.py",
    "padml/runtime.py",
    "padml/worker.py",
    "padml/kernels/f2_model_development.R",
    "padml/science/authority.json",
    "padml/science/variable.csv",
)
SCIENCE_SHA256 = {
    "padml/_science_authority.py": "24eb51866a1ef344b4099190768bb7e945910b69ee77e1a443ca4690f2370ee2",
    "padml/f1_contract.py": "9ed4ebf87bb49f9658fae278f0bb0bba5d332f660ba6088cf97886cf7f21a159",
    "padml/f1_kernel.py": "de62a97e0beaae006276f04c647c5b3ce019c39f136b61f9faf064089ee66c76",
    "padml/f2.py": "c84125e37a305d569f4087316840ce477d1ee90d15a91d25cfe37e3f5bc764fe",
    "padml/f2_kernel.py": "0257ec8d2c0f2ee74fa96543ee2bba82ea8aba2e9438620fb76099d4ecdcc7d0",
    "padml/f2_validation.py": "6de5819754de575140830444f2163d999e9325dcbee6e7eebdd25739db6a5eb4",
    "padml/kernels/f2_model_development.R": "04d7499974964284dd7db7bec922d114679ec2a4c4a1097b676f5b8e9dc34508",
    "padml/kernels/gbm-breslow.patch": "b8a1daca824e0f86b28ed3e9064486e4d2ab0d28e0720f9666b38c1d180e98e5",
    "padml/kernels/rstpm2-feasible.patch": "2dfe22fb08e68f33fb24fef9833002a965160fda1f70dce195d9e836cec4c17e",
    "padml/science/authority.json": "29e7a6821a2fbc21c6b1be4b30ec9951e0c9761e928d38ecff8735a6cb6b5f91",
    "padml/science/variable.csv": "c623b2d6e95be1487be63e71536c40d6f2a5868fa17e7dda6be78b1cfb49bc0f",
}
LPT_FAMILY_SLUGS = (
    "coxtime-set-a",
    "xgboost-cox",
    "gbm-cox",
    "rsf",
    "fpm-tvc-set-a",
    "cox-ph",
)


def _require(condition: bool, reason: str) -> None:
    if not condition:
        raise ContractError(reason)


def _science_check(repo_root: Path) -> str:
    observed = {
        relative: sha256_file(repo_root / relative)
        for relative in SCIENCE_SHA256
    }
    _require(observed == SCIENCE_SHA256, "F2_SCIENCE_SOURCE_DRIFT")
    return sha256_bytes(canonical_json_bytes(observed))


def _build_worker(repo_root: Path, target: Path) -> dict[str, Any]:
    members = []
    entries: dict[str, bytes] = {}
    for relative in WORKER_FILES:
        path = repo_root / relative
        _require(path.is_file() and not path.is_symlink(), "F2_WORKER_MEMBER_MISSING")
        data = path.read_bytes()
        entries[relative] = data
        members.append(
            {
                "path": relative,
                "sha256": sha256_bytes(data),
                "size_bytes": len(data),
            }
        )
    source_identity = sha256_bytes(canonical_json_bytes(members))
    write_deterministic_zip(target, entries)
    return {
        "path": str(target),
        "sha256": sha256_file(target),
        "size_bytes": target.stat().st_size,
        "source_identity": source_identity,
        "members": members,
    }


def _result_key(
    run_id: str, unit_id: str, request: Mapping[str, Any]
) -> str:
    return (
        f"v22/padml/science/{run_id}/F2/"
        f"{request['transaction_id']}/{unit_id}/result.zip"
    )


def _selector_search_sources(
    previous_root: Path, common_input: Path, run_id: str,
) -> dict[str, Any]:
    previous_root = previous_root.resolve(strict=True)
    previous = load_run(previous_root)
    registry = load_common_input(common_input)
    _require(
        previous["run_id"] != run_id
        and previous["runtime_identity"] == RUNTIME_IDENTITY
        and previous["f1_identity"] == registry["f1_input_manifest"]["identity"]
        and previous["common_input"]["sha256"] == sha256_file(common_input)
        and previous["common_input"]["size_bytes"] == common_input.stat().st_size,
        "F2_SELECTOR_SEARCH_PREDECESSOR_INVALID",
    )
    old_capsule_path = Path(previous["capsule"]["path"])
    _require(old_capsule_path.is_file() and not old_capsule_path.is_symlink()
             and sha256_file(old_capsule_path) == previous["capsule"]["sha256"]
             and old_capsule_path.stat().st_size == previous["capsule"]["size_bytes"],
             "F2_SELECTOR_SEARCH_PREDECESSOR_CAPSULE_INVALID")
    old_capsule = load_capsule(old_capsule_path, common_input)
    _require(old_capsule["run_id"] == previous["run_id"]
             and old_capsule["approved_registry"] == registry,
             "F2_SELECTOR_SEARCH_PREDECESSOR_INPUT_INVALID")
    comparison_requests = materialize_requests(
        run_id=run_id, source_identity=previous["worker"]["source_identity"],
        runtime_identity=RUNTIME_IDENTITY, worker_identity=previous["worker"]["sha256"],
        input_identity=previous["f1_identity"],
    )
    sources = {}
    for fold, unit_id in enumerate(canonical_unit_ids()[:6], start=1):
        path = previous_root / "results" / f"{unit_id}.fine-search.zip"
        _require(path.is_file() and not path.is_symlink()
                 and not (previous_root / "results" / f"{unit_id}.zip").exists(),
                 "F2_SELECTOR_SEARCH_PREDECESSOR_RESULT_INVALID")
        value = strict_json_bytes(read_safe_zip(path, expected_members={"selector-search.json"})["selector-search.json"],
                                  "selector-search.json")
        request = old_capsule["requests"][unit_id]
        _require(request["identities"]["source"] == previous["worker"]["source_identity"]
                 and request["identities"]["worker"] == previous["worker"]["sha256"],
                 "F2_SELECTOR_SEARCH_PREDECESSOR_WORKER_MISMATCH")
        source = {
            "schema_version": "1.0.0", "kind": "PADML_F2_ELASTIC_SEARCH_REUSE",
            "source_run_identity": previous["identity"],
            "source_capsule_sha256": previous["capsule"]["sha256"],
            "source_request": request,
            "archive": {"object_key": _result_key(previous["run_id"], unit_id, request).removesuffix("result.zip") + "fine-search.zip",
                        "sha256": sha256_file(path), "size_bytes": path.stat().st_size},
            "model_input_identity": registry["model_inputs"][fold - 1]["identity"],
            "derivation_records_sha256": sha256_bytes(canonical_json_bytes(value.get("derivation_records"))),
        }
        source["identity"] = sha256_bytes(canonical_json_bytes(source))
        load_selector_search(path, source, comparison_requests[unit_id], registry["model_inputs"][fold - 1])
        sources[unit_id] = source
    return sources


def _selector_primary_sources(previous_root: Path, common_input: Path, run_root: Path,
                              requests: Mapping[str, Any]) -> dict[str, Any]:
    from .capsule import load_selector_primary, primary_science_identity, selector_primary_projection

    previous_root = previous_root.resolve(strict=True)
    previous = load_run(previous_root)
    _require(previous["common_input"]["sha256"] == sha256_file(common_input), "F2_PRIMARY_F1_INPUT_CHANGED")
    old_capsule_path = previous_root / "capsule.zip"
    _require(not old_capsule_path.is_symlink() and sha256_file(old_capsule_path) == previous["capsule"]["sha256"],
             "F2_PRIMARY_SOURCE_CAPSULE_CHANGED")
    old_entries = read_safe_zip(old_capsule_path)
    old_manifest = strict_json_bytes(old_entries["manifest.json"], "primary.source_manifest")
    old_authority = strict_json_bytes(old_entries["authority.json"], "primary.source_authority")
    _require(old_manifest["identity"] == previous["capsule"]["identity"]
             == sha256_bytes(canonical_json_bytes({key: value for key, value in old_manifest.items() if key != "identity"}))
             and primary_science_identity(old_authority) == primary_science_identity(load_science_authority()),
             "F2_PRIMARY_SOURCE_SCIENCE_CHANGED")
    registry = load_common_input(common_input)
    directory = run_root / "selector-primary"
    directory.mkdir(mode=0o700)
    sources = {}
    for fold, unit_id in enumerate(canonical_unit_ids()[:6], start=1):
        old_request = strict_json_bytes(old_entries[f"requests/{unit_id}.json"], "primary.source_request")
        expected_request_hash = next(row["request_sha256"] for row in old_manifest["request_index"] if row["unit_id"] == unit_id)
        _require(sha256_bytes(canonical_json_bytes(old_request)) == expected_request_hash
                 and old_request["identities"]["authority"] == sha256_bytes(canonical_json_bytes(old_authority)),
                 "F2_PRIMARY_SOURCE_REQUEST_CHANGED")
        path = previous_root / "results" / f"{unit_id}.zip"
        _require(path.is_file() and not path.is_symlink(), "F2_PRIMARY_SOURCE_RESULT_ABSENT")
        result_bytes = path.read_bytes()
        entries = read_safe_zip(result_bytes)
        envelope = validate_envelope(strict_json_bytes(entries["manifest.json"], "primary.result_manifest"))
        _require(all(envelope[field] == old_request[field] for field in
                     ("run_id", "stage_id", "unit_id", "transaction_id", "identities", "seed", "plan"))
                 and envelope["kind"] == "result" and envelope["terminal"]["status"] == "COMPLETED"
                 and len(envelope["artifacts"]) == 1, "F2_PRIMARY_SOURCE_RESULT_INVALID")
        artifact = envelope["artifacts"][0]
        payload = entries[artifact["relative_path"]]
        _require(set(entries) == {"manifest.json", artifact["relative_path"]}
                 and len(payload) == artifact["size_bytes"] and sha256_bytes(payload) == artifact["sha256"],
                 "F2_PRIMARY_SOURCE_PAYLOAD_CHANGED")
        value = strict_json_bytes(payload, "primary.source_payload")
        _require(value.get("status") == "PASS" and value.get("model_input") == registry["model_inputs"][fold - 1]
                 and value.get("search_trace", {}).get("search_reuse")
                 == old_manifest.get("selector_search_reuse", {}).get(unit_id), "F2_PRIMARY_SOURCE_INPUT_CHANGED")
        primary = canonical_json_bytes(selector_primary_projection(value))
        target = directory / f"{unit_id}.zip"
        write_deterministic_zip(target, {"primary.json": primary})
        os.chmod(target, 0o600)
        source = {
            "schema_version": "1.0.0", "kind": "PADML_F2_SELECTOR_PRIMARY_REUSE",
            "source_run_identity": previous["identity"], "source_capsule_sha256": previous["capsule"]["sha256"],
            "source_request": old_request,
            "source_result": {"object_key": _result_key(previous["run_id"], unit_id, old_request),
                              "sha256": sha256_bytes(result_bytes), "size_bytes": len(result_bytes)},
            "primary_science_identity": primary_science_identity(old_authority),
            "primary_sha256": sha256_bytes(primary), "model_input_identity": value["model_input"]["identity"],
            "selector_search_reuse": value["search_trace"]["search_reuse"],
            "archive": {"object_key": _result_key(run_root.name, unit_id, requests[unit_id]).removesuffix("result.zip") + "primary.zip",
                        "sha256": sha256_file(target), "size_bytes": target.stat().st_size},
        }
        source["identity"] = sha256_bytes(canonical_json_bytes(source))
        load_selector_primary(target, source, requests[unit_id], registry["model_inputs"][fold - 1])
        sources[unit_id] = source
    return sources


def _rescore_selector_result(value: Mapping[str, Any], source: Mapping[str, Any],
                             model_input: Mapping[str, Any], local_f1: Mapping[str, Any]) -> dict[str, Any]:
    from .capsule import result_reuse_receipt, selector_result_projection
    from .f2_validation import _local_outer_metric

    execution = value["registered_partition_execution"]
    outer = next(row for row in execution["partitions"] if row["kind"] == "OUTER")
    metric = _local_outer_metric(value, value["fold"], outer, model_input, local_f1)
    _require(outer["metric_prediction_seal_sha256"] == metric["prediction_sha256"],
             "F2_SELECTOR_RESCORING_PREDICTION_CHANGED")
    corrected = {**outer, "ibs_0_24": metric["ibs_0_24"],
                 "metric_set_sha256": sha256_bytes(canonical_json_bytes([metric["ibs_0_24"]])),
                 "metric_qc": metric["ipcw_qc"]}
    execution = {**{key: item for key, item in execution.items() if key != "identity"},
                 "partitions": [corrected if row["kind"] == "OUTER" else row
                                for row in execution["partitions"]]}
    execution["identity"] = sha256_bytes(canonical_json_bytes(execution))
    result = {**value, "registered_partition_execution": execution,
              "result_reuse": result_reuse_receipt(source)}
    _require(sha256_bytes(canonical_json_bytes(selector_result_projection(result)))
             == source["preserved_value_sha256"], "F2_REUSED_SELECTOR_WRITEBACK_FORBIDDEN")
    return result


def _selector_result_sources(previous_root: Path, common_input: Path, run_root: Path,
                             requests: Mapping[str, Any], local_f1: Mapping[str, Any]) -> dict[str, Any]:
    from .capsule import selector_result_projection
    from .worker import _write_result

    previous_root = previous_root.resolve(strict=True)
    previous = load_run(previous_root)
    _require(previous["common_input"]["sha256"] == sha256_file(common_input),
             "F2_SELECTOR_RESULT_F1_INPUT_CHANGED")
    old_capsule_path = previous_root / "capsule.zip"
    _require(not old_capsule_path.is_symlink()
             and sha256_file(old_capsule_path) == previous["capsule"]["sha256"],
             "F2_SELECTOR_RESULT_SOURCE_CAPSULE_CHANGED")
    old_capsule = load_capsule(old_capsule_path, common_input)
    _require(old_capsule["run_id"] == previous["run_id"]
             and old_capsule["manifest"]["identity"] == previous["capsule"]["identity"],
             "F2_SELECTOR_RESULT_SOURCE_RUN_CHANGED")
    routes = old_capsule["manifest"]["identity_records"]["execution_plan"]["route_profiles"]
    sources = {}
    for fold, unit_id in enumerate(canonical_unit_ids()[:6], start=1):
        old_request = old_capsule["requests"][unit_id]
        _require(old_request["identities"]["source"] == previous["worker"]["source_identity"]
                 and old_request["identities"]["worker"] == previous["worker"]["sha256"],
                 "F2_SELECTOR_RESULT_SOURCE_WORKER_CHANGED")
        model_input = old_capsule["approved_registry"]["model_inputs"][fold - 1]
        path = previous_root / "results" / f"{unit_id}.zip"
        _require(path.is_file() and not path.is_symlink(), "F2_SELECTOR_RESULT_SOURCE_ABSENT")
        raw = path.read_bytes()
        # Validate complete old computation, including every numerical error
        # boundary. Only its outer metric is replayed below using local F1.
        previous_result = validate_f2_unit_result(
            old_request, raw, old_capsule["authority_slice"], route_profiles=routes,
            expected_model_input=model_input,
            expected_selector_search=old_capsule["manifest"].get("selector_search_reuse", {}).get(unit_id),
            expected_selector_primary=old_capsule["manifest"].get("selector_primary_reuse", {}).get(unit_id),
            expected_selector_result=old_capsule["manifest"].get("selector_result_reuse", {}).get(unit_id),
            authority_mode="REMOTE_CANDIDATE")
        _require(previous_result["status"] == "CANDIDATE_VALID", "F2_SELECTOR_RESULT_SOURCE_INCOMPLETE")
        value = previous_result["value"]
        source = {
            "schema_version": "1.0.0", "kind": "PADML_F2_SELECTOR_RESULT_REUSE",
            "source_run_identity": previous["identity"], "source_capsule_sha256": previous["capsule"]["sha256"],
            "source_request": old_request,
            "source_result": {"object_key": _result_key(previous["run_id"], unit_id, old_request),
                              "sha256": previous_result["result_sha256"], "size_bytes": len(raw)},
            "preserved_value_sha256": sha256_bytes(canonical_json_bytes(selector_result_projection(value))),
            "model_input_identity": model_input["identity"],
        }
        source["identity"] = sha256_bytes(canonical_json_bytes(source))
        result = _rescore_selector_result(value, source, model_input, local_f1)
        target = run_root / "results" / f"{unit_id}.zip"
        _write_result(requests[unit_id], target, result)
        accepted = validate_f2_unit_result(
            requests[unit_id], target, old_capsule["authority_slice"], route_profiles=routes,
            expected_model_input=model_input, local_f1_response=local_f1,
            expected_selector_result=source, authority_mode="LOCAL_SOLE_VALIDATOR")
        _require(accepted["status"] == "PASS", "F2_SELECTOR_RESCORING_NOT_ACCEPTED")
        sources[unit_id] = source
    return sources


def prepare(runtime_root: Path, run_id: str, *, selector_search_from: Path | None = None,
            selector_primary_from: Path | None = None,
            selector_results_from: Path | None = None,
            host_effective_cpus: Mapping[str, int] | None = None) -> dict[str, Any]:
    _require(isinstance(host_effective_cpus, Mapping) and set(host_effective_cpus) == set(HOSTS),
             "F2_EXECUTION_HOST_CPU_OBSERVATIONS_REQUIRED")
    host_workers = {host: pool_capacity(host_effective_cpus[host]) for host in HOSTS}
    unit_workers = {}
    for fold, host in enumerate(HOSTS, start=1):
        for unit in canonical_unit_ids()[:42]:
            if unit.startswith((f"selector-f{fold}-", f"model-f{fold}-")):
                unit_workers[unit] = host_workers[host]
    unit_workers.update(dict(zip(canonical_unit_ids()[42:45],
                                 (host_workers[host] for host in HOSTS[:3]), strict=True)))
    _require(
        re.fullmatch(r"[a-z0-9][a-z0-9-]{2,63}", run_id) is not None,
        "F2_RUN_ID_INVALID",
    )
    repo_root = Path(__file__).resolve().parent.parent
    _require(sum(value is not None for value in
                 (selector_search_from, selector_primary_from, selector_results_from)) <= 1,
             "F2_SELECTOR_REUSE_MODE_CONFLICT")
    runtime_root = runtime_root.resolve(strict=True)
    science_identity = _science_check(repo_root)
    f1_manifest_path = runtime_root / "input/f1/input-manifest.json"
    common_input = runtime_root / "build/common-input.zip"
    replay_seal = runtime_root / "build/f1-replay-seal.zip"
    f1_manifest = load_f1_input_manifest(f1_manifest_path)
    load_common_input(common_input)
    local_f1 = _load_replay(replay_seal, common_input, f1_manifest)
    search_sources = None
    if selector_search_from is not None:
        search_sources = _selector_search_sources(selector_search_from, common_input, run_id)
    run_root = runtime_root / "runs" / run_id
    _require(not run_root.exists(), "F2_RUN_ALREADY_EXISTS")
    run_root.mkdir(parents=True, mode=0o700)
    (run_root / "results").mkdir(mode=0o700)
    worker_path = run_root / "worker.zip"
    worker = _build_worker(repo_root, worker_path)
    primary_sources = None
    result_sources = None
    if selector_primary_from is not None:
        comparison_requests = materialize_requests(run_id=run_id, source_identity=worker["source_identity"],
            runtime_identity=RUNTIME_IDENTITY, worker_identity=worker["sha256"], input_identity=f1_manifest["identity"],
            unit_pool_workers=unit_workers)
        primary_sources = _selector_primary_sources(selector_primary_from, common_input, run_root, comparison_requests)
    if selector_results_from is not None:
        comparison_requests = materialize_requests(run_id=run_id, source_identity=worker["source_identity"],
            runtime_identity=RUNTIME_IDENTITY, worker_identity=worker["sha256"], input_identity=f1_manifest["identity"],
            unit_pool_workers=unit_workers)
        result_sources = _selector_result_sources(
            selector_results_from, common_input, run_root, comparison_requests, local_f1)
    capsule_path = run_root / "capsule.zip"
    capsule_record = build_capsule(
        run_id=run_id,
        source_identity=worker["source_identity"],
        runtime_identity=RUNTIME_IDENTITY,
        worker_identity=worker["sha256"],
        common_input_path=common_input,
        target=capsule_path,
        selector_search_reuse=search_sources,
        selector_primary_reuse=primary_sources,
        selector_result_reuse=result_sources,
        unit_pool_workers=unit_workers,
    )
    capsule = load_capsule(capsule_path, common_input)
    if search_sources is not None:
        (run_root / "selector-search").mkdir(mode=0o700)
        for unit_id, source in search_sources.items():
            target = run_root / "selector-search" / f"{unit_id}.zip"
            os.link(selector_search_from / "results" / f"{unit_id}.fine-search.zip", target, follow_symlinks=False)
            load_selector_search(target, source, capsule["requests"][unit_id], expected_f2_model_input(capsule, unit_id))
    queues = {
        host: [
            *([] if result_sources is not None else [f"selector-f{fold}-elastic-net-cox"]),
            *(f"model-f{fold}-{slug}" for slug in LPT_FAMILY_SLUGS),
        ]
        for host, fold in zip(HOSTS, range(1, 7), strict=True)
    }
    for host, unit_id in zip(HOSTS[:3], canonical_unit_ids()[42:45], strict=True):
        queues[host].append(unit_id)
    remote_ids = canonical_unit_ids()[:45]
    manifest: dict[str, Any] = {
        "schema_version": "1.0.0",
        "kind": "PADML_F2_DIRECT_RUN",
        "run_id": run_id,
        "science_identity": science_identity,
        "f1_identity": f1_manifest["identity"],
        "runtime_identity": RUNTIME_IDENTITY,
        "worker": worker,
        "capsule": capsule_record,
        "common_input": {
            "path": str(common_input),
            "sha256": sha256_file(common_input),
            "size_bytes": common_input.stat().st_size,
        },
        "replay_seal": {
            "path": str(replay_seal),
            "sha256": sha256_file(replay_seal),
            "size_bytes": replay_seal.stat().st_size,
        },
        "objects": {
            "worker": (
                f"v22/padml/runtime/{worker['source_identity']}/"
                f"{worker['sha256']}/thin-worker.zip"
            ),
            "capsule": (
                f"v22/padml/science/{run_id}/F2/"
                f"{capsule_record['sha256']}/input/f2-capsule.zip"
            ),
            "common_input": (
                f"v22/padml/science/{run_id}/F2/"
                f"{sha256_file(common_input)}/input/common-input.zip"
            ),
        },
        "f1_objects": f1_manifest["direct_objects"],
        "result_keys": {
            unit_id: _result_key(
                run_id, unit_id, capsule["requests"][unit_id]
            )
            for unit_id in remote_ids
        },
        "host_queues": queues,
        "execution": {
            "host_parallelism": 6,
            "pool_workers": host_workers,
            "engine_threads": 1,
            "order": "LONGEST_EXPECTED_FAMILY_FIRST",
            "aggregate": "LOCAL_AFTER_45_VALIDATED_RESULTS",
        },
    }
    manifest["identity"] = sha256_bytes(canonical_json_bytes(manifest))
    (run_root / "run.json").write_bytes(canonical_json_bytes(manifest))
    return manifest


def load_run(run_root: Path) -> dict[str, Any]:
    run_root = run_root.resolve(strict=True)
    raw = (run_root / "run.json").read_bytes()
    value = strict_json_bytes(raw, "F2_RUN_MANIFEST")
    _require(
        canonical_json_bytes(value) == raw
        and value["identity"]
        == sha256_bytes(
            canonical_json_bytes(
                {key: item for key, item in value.items() if key != "identity"}
            )
        ),
        "F2_RUN_MANIFEST_INVALID",
    )
    return value


def _load_replay(
    path: Path,
    common_input: Path,
    f1_manifest: Mapping[str, Any],
    *, admit_io=None,
) -> dict[str, Any]:
    entries = read_safe_zip(
        path,
        expected_members={
            "manifest.json",
            "binding-contract.json",
            "response-seal.csv",
        },
        max_member_bytes=64 * 1024 * 1024,
        max_total_bytes=128 * 1024 * 1024,
        admit_io=admit_io,
    )
    if admit_io is not None:
        admit_io(memory_bytes=32 * sum(map(len, entries.values())))
    seal = strict_json_bytes(entries["manifest.json"], "F1_REPLAY_SEAL")
    binding = strict_json_bytes(
        entries["binding-contract.json"], "F1_REPLAY_BINDING"
    )
    response = entries["response-seal.csv"]
    _require(
        canonical_json_bytes(seal) == entries["manifest.json"]
        and canonical_json_bytes(binding)
        == entries["binding-contract.json"]
        and seal["identity"]
        == sha256_bytes(
            canonical_json_bytes(
                {key: item for key, item in seal.items() if key != "identity"}
            )
        )
        and seal["f1_input_manifest_identity"] == f1_manifest["identity"]
        and seal["common_input_sha256"] == sha256_file(common_input)
        and seal["binding_contract_sha256"]
        == f1_manifest["binding_contract_sha256"]
        == sha256_bytes(entries["binding-contract.json"])
        and seal["response_seal_sha256"] == sha256_bytes(response)
        and seal["response_size_bytes"] == len(response),
        "F1_REPLAY_SEAL_INVALID",
    )
    for value in seal["lineage"].values():
        validate_sha256(value, "f1.replay.lineage")
    return {
        "binding_contract": binding,
        "lineage": seal["lineage"],
        "response_csv": response,
    }


def validate_present(
    run_root: Path,
) -> tuple[dict[str, dict[str, Any]], tuple[str, ...]]:
    run = load_run(run_root)
    runtime_root = run_root.resolve(strict=True).parents[1]
    common_input = Path(run["common_input"]["path"])
    capsule = load_capsule(Path(run["capsule"]["path"]), common_input)
    f1_manifest = load_f1_input_manifest(
        runtime_root / "input/f1/input-manifest.json"
    )
    local_f1 = _load_replay(
        Path(run["replay_seal"]["path"]), common_input, f1_manifest
    )
    validated: dict[str, dict[str, Any]] = {}
    missing: list[str] = []
    routes = capsule["manifest"]["identity_records"]["execution_plan"][
        "route_profiles"
    ]
    for unit_id in canonical_unit_ids():
        request = capsule["requests"][unit_id]
        path = run_root / "results" / f"{unit_id}.zip"
        dependencies = request["plan"]["depends_on"]
        if not path.is_file() or not set(dependencies) <= set(validated):
            missing.append(unit_id)
            continue
        result = validate_f2_unit_result(
            request,
            path,
            capsule["authority_slice"],
            route_profiles=routes,
            admitted_sources={
                item: admitted_source_record(validated[item])
                for item in dependencies
            },
            admitted_values={
                item: validated[item]["value"] for item in dependencies
            },
            expected_model_input=expected_f2_model_input(capsule, unit_id),
            expected_selector_search=capsule["manifest"].get("selector_search_reuse", {}).get(unit_id),
            expected_selector_primary=capsule["manifest"].get("selector_primary_reuse", {}).get(unit_id),
            expected_selector_result=capsule["manifest"].get("selector_result_reuse", {}).get(unit_id),
            local_f1_response=(
                local_f1
                if request["plan"]["action"] == "MODEL_DEVELOPMENT"
                else None
            ),
            authority_mode="LOCAL_SOLE_VALIDATOR",
        )
        _require(result["status"] == "PASS", f"F2_RESULT_INVALID:{unit_id}")
        _require(result["value"].get("fpm_fixed_reuse")
                 == capsule["manifest"].get("fpm_fixed_reuse", {}).get(unit_id),
                 "F2_FPM_REUSE_SOURCE_INVALID")
        validated[unit_id] = result
    return validated, tuple(missing)


def validation_summary(run_root: Path) -> dict[str, Any]:
    validated, missing = validate_present(run_root)
    return {
        "status": "PASS",
        "validated_count": len(validated),
        "validated_units": list(validated),
        "missing_units": list(missing),
    }


def aggregate(run_root: Path) -> dict[str, Any]:
    run_root = run_root.resolve(strict=True)
    run = load_run(run_root)
    validated, _ = validate_present(run_root)
    unit_ids = canonical_unit_ids()
    _require(
        tuple(validated) == unit_ids[:45],
        "F2_REMOTE_RESULT_SET_INCOMPLETE",
    )
    capsule = load_capsule(
        Path(run["capsule"]["path"]), Path(run["common_input"]["path"])
    )
    request = capsule["requests"]["model-confirmation"]
    dependencies = request["plan"]["depends_on"]
    sources = [
        admitted_source_record(validated[item]) for item in dependencies
    ]
    value = aggregate_confirmation(
        [validated[item]["value"] for item in dependencies[:42]],
        [validated[item]["value"] for item in dependencies[42:]],
        sources,
    )
    value.update(execution_result_contract(request["plan"]))
    value["consumed_sources"] = sources
    payload = canonical_json_bytes(value)
    artifact = {
        **request["artifacts"][0],
        "size_bytes": len(payload),
        "sha256": sha256_bytes(payload),
        "status": "OK",
    }
    envelope = validate_envelope(
        {
            **request,
            "kind": "result",
            "artifacts": [artifact],
            "terminal": {
                "status": "COMPLETED",
                "reason_code": "OK",
                "message_sha256": None,
            },
            "decision": None,
        }
    )
    target = run_root / "results/model-confirmation.zip"
    _require(not target.exists(), "F2_AGGREGATE_ALREADY_EXISTS")
    write_deterministic_zip(
        target,
        {
            "manifest.json": canonical_json_bytes(envelope),
            artifact["relative_path"]: payload,
        },
    )
    aggregate_validated = validate_f2_unit_result(
        request,
        target,
        capsule["authority_slice"],
        route_profiles=capsule["manifest"]["identity_records"]["execution_plan"][
            "route_profiles"
        ],
        admitted_sources={row["unit_id"]: row for row in sources},
        admitted_values={item: validated[item]["value"] for item in dependencies},
        authority_mode="LOCAL_SOLE_VALIDATOR",
    )
    _require(
        aggregate_validated["status"] == "PASS",
        "F2_FINAL_RESULT_SET_INVALID",
    )
    all_validated = {**validated, "model-confirmation": aggregate_validated}
    stage = validate_f2_stage_values(
        {unit_id: all_validated[unit_id]["value"] for unit_id in unit_ids},
        load_science_authority(),
        f1_result_sha256=run["f1_identity"],
    )
    summary: dict[str, Any] = {
        "schema_version": "1.0.0",
        "kind": "PADML_F2_FINAL_ACCEPTANCE",
        "status": "SCIENTIFICALLY_ACCEPTED",
        "run_id": run["run_id"],
        "run_identity": run["identity"],
        "unit_count": 46,
        "remote_unit_count": 45,
        "host_parallelism": 6,
        "pool_workers": capsule["manifest"]["plan"]["pool_workers"],
        "p2c2t_pool_workers": {
            unit_id: execution_result_contract(capsule["requests"][unit_id]["plan"])[
                "pool_workers"
            ]
            for unit_id in unit_ids[42:45]
        },
        "aggregate_sha256": aggregate_validated["result_sha256"],
        "stage_validation": stage,
        "result_sha256": {
            unit_id: all_validated[unit_id]["result_sha256"]
            for unit_id in unit_ids
        },
    }
    summary["identity"] = sha256_bytes(canonical_json_bytes(summary))
    (run_root / "f2-acceptance.json").write_bytes(
        canonical_json_bytes(summary)
    )
    return summary



F45_HOSTS = ("H0", "H1", "H4", "H5", "H6", "H7-3", "H9-2")


def f45_units() -> list[dict[str, Any]]:
    """Four independent development lines; dependencies are complete scientific units."""
    from .nested_loco import SELECTION_HORIZONS
    rows = []
    for h in SELECTION_HORIZONS:
        for outer in range(1, 7):
            primary = f"PRIMARY-H{h:02d}-O{outer}"
            rows.extend([
                {"unit_id": primary, "kind": "PRIMARY", "horizon": h, "outer_fold": outer,
                 "context": f"OUTER-{outer}", "depends_on": []},
                {"unit_id": f"AAR-H{h:02d}-O{outer}", "kind": "AAR", "horizon": h,
                 "outer_fold": outer, "context": f"OUTER-{outer}", "depends_on": [primary]},
            ])
        rows.append({"unit_id": f"FULL0-H{h:02d}", "kind": "FULL0", "horizon": h,
                     "context": "FULL0", "depends_on": []})
        rows.append({"unit_id": f"EVALUATION-H{h:02d}", "kind": "EVALUATION", "horizon": h,
                     "context": "EVALUATION", "depends_on": [f"{kind}-H{h:02d}-O{o}"
                         for o in range(1, 7) for kind in ("PRIMARY", "AAR")]})
    return rows


def prepare_f45_run(target: Path, *, run_root: Path, f2_run_root: Path | None = None,
                    f1_runtime_root: Path | None = None, source_bundle_sha256: str,
                    workbook: Path | None = None, run_id: str | None = None,
                    hosts: Mapping[str, Any] | None = None, environment: Mapping[str, Any] | None = None) -> dict[str, Any]:
    from .f4 import _f45_source_member_sha256
    from .nested_loco import PROGRAM_ID, _write_exact_once, validate_science_decision
    from .runtime import validate_resource_policy
    source = Path(__file__).resolve().parent.parent
    decision = validate_science_decision(strict_json_bytes((source / "science-decision.json").read_bytes()))
    validate_sha256(source_bundle_sha256, "source_bundle_sha256")
    integrated = workbook is not None
    paths = (target, run_root, workbook) if integrated else (target, run_root, f2_run_root, f1_runtime_root)
    _require(all(isinstance(path, Path) and path.is_absolute() for path in paths), "F45_RUN_ABSOLUTE_PATHS_REQUIRED")
    if integrated:
        import re
        _require(f2_run_root is None and f1_runtime_root is None and isinstance(run_id, str)
                 and re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,79}", run_id)
                 and workbook.is_file() and not workbook.is_symlink(), "RAW_RUN_INPUT_INVALID")
        _require(isinstance(hosts, Mapping) and set(hosts) == set(F45_HOSTS), "RAW_SEVEN_HOST_CONFIG_REQUIRED")
        for connection in hosts.values():
            _f45_connection(connection)
        _require(isinstance(environment, Mapping) and set(environment) - {"runtime_manifest"} == {"python", "rscript", "r_library", "lock_sha256", "artifact_paths"}
                 and all(isinstance(environment[k], str) and environment[k] for k in ("python", "rscript", "r_library", "lock_sha256"))
                 and isinstance(environment["artifact_paths"], dict) and environment["artifact_paths"], "RAW_DEPENDENCY_ENVIRONMENT_REQUIRED")
        validate_sha256(environment["lock_sha256"], "dependency_lock")
        _require(environment["lock_sha256"] == sha256_file(source / "dependency-lock.json"),
                 "RAW_DEPENDENCY_LOCK_DRIFT")
    policy = validate_resource_policy({"configured_worker_ceiling": "EXECUTION_HOST_C_MINUS_8",
        "memory_bytes_per_worker": MIN_WORKER_MEMORY_BYTES, "memory_reserve_bytes": 1024**3,
        "scratch_bytes_per_worker": 2 * 1024**3, "scratch_reserve_bytes": 0,
        "transfer_archive_worker_ceiling": 2147483647})
    body = {"kind": "PADML_F45_WHOLE_UNIT_RUN_V1", "program_id": PROGRAM_ID,
        "run_root": str(run_root), "f2_run_root": str(f2_run_root), "f1_runtime_root": str(f1_runtime_root),
        "source_bundle_sha256": source_bundle_sha256,
        "source_identity": sha256_bytes(canonical_json_bytes(_f45_source_member_sha256())),
        "science_decision": decision, "hosts": list(F45_HOSTS), "units": f45_units(),
        "resource_policy": policy, "budgets": {
            "retained_bytes_per_view": 2 * 1024**3, "retained_bytes_per_component": 64 * 1024**2,
            "expanded_bytes_per_component": 16 * 1024**2, "shared_storage_bytes": 4 * 1024**3,
            "retained_bytes_per_replicate": 16 * 1024**2, "retained_bytes_per_q_task": 512 * 1024**2},
        "oss_prefix": "v22/padml/science/f45-rebuild-20260925",
        "reuse": {"scope": "EXACT_INPUT_PARAMETER_SEED_KERNEL_MATCH_WITH_ORIGINAL_PRODUCER",
            "context_affinity": True, "full0_common_mice_selector": True,
            "new_q_atoms": True, "shared_bootstrap_draws": 1000, "old_f45_admitted": False},
        "protected": {"f2_accepted_result_count": 46,
            "f2_run_identity": "6df9516e8181361c7524dadd163f235bbff84b71174d2d205c7064158d9dc9c3",
            "f2_aggregate_sha256": "f6b8debb900e616590e3bea0c8f79457ea34d53d9a708acdc2fb275665641913"}}
    if integrated:
        from .integrated import RUN_KIND
        from .f4 import evaluation_decision
        body['evaluation_decision'] = evaluation_decision()
        for key in ("f1_runtime_root", "f2_run_root", "protected"):
            body.pop(key)
        body["budgets"]["retained_bytes_per_replicate"] = 256 * 1024
        body.update(kind=RUN_KIND, run_id=run_id,
            raw_input={"path": str(workbook), "sha256": sha256_file(workbook), "size_bytes": workbook.stat().st_size},
            host_connections=dict(hosts), environment=dict(environment),
            oss_prefix="padml/integrated/" + run_id,
            reuse={**body["reuse"], "scope": "CURRENT_BATCH_EXACT_SCIENTIFIC_DEPENDENCIES", "old_f2_admitted": False},
            delivery={"unit_carrier": "IMMUTABLE_CORE_RECEIPT_AND_DIRECT_ARTIFACT_REFERENCES", "nested_archives": False})
    value = {**body, "identity": sha256_bytes(canonical_json_bytes(body))}
    target.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    _write_exact_once(target, canonical_json_bytes(value), "F45_RUN_MANIFEST_DRIFT")
    return value


def _f45_aar_binding_ast(raw, name):
    """Qualify exact same-run producer revisions; consumers bind each line's science."""
    import ast
    # BEGIN COMPACT EVALUATION DOCS
    compact_evaluation_raw = {'AGENTS.md': ('f8ceb15e6715894ae1414ddae9d314d0a9e3b73916422fe5ab22e2237f9dbd0e', 'ca23d5bb49e8e4be84135e68edb18e511847a0b16e92e993a5e61734185ff727', 'cf62b6fc5c9e1ba3587af5379082f940e818ccdcffe53ab7a217ac04a224c660', '56c360f006ca0f0d399935b6f8df061bd0ea05692dec2130c8996a2bab5bd7ab'), 'NESTED_LOCO_PROTOCOL.md': ('c59bb1ab7a1f96e0a4ff1323551563513c7c244475926c2b9258a019aee5d0aa', '1b85e795b4e5bfa5fede793bc9e9f75d67f96f16b626ff5328532b9ba34b06c6', '3e5fde45863e85149f35523fb0eb12c70af7db1718c62ed9af6c8fab6ef07caf', '4657743690b45f8e99505c5b6d02ba2d5e4d3f1e2ff9dfa36ff9b19e30ca1dda')}
    if name in compact_evaluation_raw and sha256_bytes(raw) in compact_evaluation_raw[name]:
        return ast.parse(repr(b""))
    # END COMPACT EVALUATION DOCS
    # Exact 28-context appended diagnostics; old model decisions stay sealed.
    optimism_raw = {'AGENTS.md': '8c969effe96303e73e408efb4e1bb55e39410ba6ddee590b79f8dc5de22cb22a', 'NESTED_LOCO_PROTOCOL.md': '5a01757064f17822903a33d483ef352c8a8d996fe9a7c3ff1d30f735a61a16c6', 'padml/kernels/f4_metrics.R': '7f9fc8c923b9578c03533fce8d98d166f24fac882fe3dae95af3072bdffb03dd'}
    if name in optimism_raw and sha256_bytes(raw) == optimism_raw[name]:
        return ast.parse(repr(b""))
    if name == "padml/kernels/f4_metrics.R":
        return ast.parse(repr(b"" if sha256_bytes(raw) == "ec0d598e5bc304b4989996b61f2e9043d8b0460f7ad401e6146450267e77f34e" else raw))
    execution_handoff_docs = {
        "AGENTS.md": "b73a57a0ff4ad71747592e6d9edf15149017b11fc60c323aed73f62c85f3a031",
        "NESTED_LOCO_PROTOCOL.md": "f7a42a858d9454b69e120a270ee0a7c312c9d8967a4167523373c016b9ade37e"}
    if name in execution_handoff_docs and sha256_bytes(raw) == execution_handoff_docs[name]:
        return ast.parse(repr(b""))
    equivalent_hotpath_docs = {
        "AGENTS.md": "7b94bb7cd5541805ebcebe15977eaaa89059deca14629250ca24fd5b4a7d481f",
        "NESTED_LOCO_PROTOCOL.md": "c5900822fb381ab59346c8b3dd1a922e583db5603a0e19556ae718ae3cc59ce9"}
    if name in equivalent_hotpath_docs and sha256_bytes(raw) == equivalent_hotpath_docs[name]:
        return ast.parse(repr(b""))
    # Exact authorized patient recovery and within-candidate readback revision.
    patient_recovery_raw = {'AGENTS.md': '0a18f0ebc3476c43c8843a81f45fbdd9f9fbf2573d4cce8384938ba0785650aa',
     'NESTED_LOCO_PROTOCOL.md': '0c9b9564b738aae928863e4d81ef5e1254bdfdf7840fe8864ac5875d5869bba4',
     'padml/kernels/f5_shap.R': 'c0fe2ef61c998341e9d47a7d90af6e5a513fd5ba413d0b42902f87fa17e2e3ea'}
    if name in patient_recovery_raw and sha256_bytes(raw) == patient_recovery_raw[name]:
        return ast.parse(repr(b""))
    # Begin exact H36 non-Python sources.
    revised_raw = {'AGENTS.md': ('bef3907630dea10bcc1d3fb086558954b96411874ebbedb791e027e7c482952c',
                   'd0b75218cbe146e2f791ec54a807eb3e6faeb2ac8259d0b571c320d066cb1bfa'),
     'NESTED_LOCO_PROTOCOL.md': ('da81e7ff70fc891bcf5a0f8100e8d179cf869ab04ddd9953f13fb26b77c29aea',
                                 '57578fa2aea45b82eb537a095cf7c28ef29b2ab8706bcfcbde29ac86d81740e1'),
     'padml/kernels/f4_learning_selector.R': ('1fdb225904161dee2690f4117eec50960a95dc48521b6bc76c2d7aeaea48d28d',
                                              '826624b34088495df32638652192a02939c9bbc62fd897cffc766b3a1767bbd3'),
     'padml/kernels/f5_shap.R': ('584000e05f81ebbc6cdbb7406e069561be71ef4d32071480168db800a0032fe0',
                                 '0ac8ff1d23782146798b6349df318f53b25b4fa2e9a553a8b69a116fb13333e7'),
     'science-decision.json': ('9024cb72138c902ec82f49dea57f5a05af537f270b4e192de16c426ea2028b8f',
                               '2fdec130a59934a1556deaad7d34bef270e3ad2198f153dd72ea2fa89aacd93e')}
    if name in revised_raw and sha256_bytes(raw) in revised_raw[name]:
        return ast.parse(repr(b""))
    # End exact H36 non-Python sources.
    if name in {"AGENTS.md", "NESTED_LOCO_PROTOCOL.md"}:
        documented = {'AGENTS.md': ('92a866c800a633b97d0799df36e7e9659803072defa2ac6aa9029ca541480a10', '9825ffa9b3362638a1bda9320709309d54a78d92fcf65dd404284d65afe55d2f', 'b3e6ec8373a91ea943fea78f3cf87d118b2e1017d8cdec3423205beacadc6c19', 'f821151db1cd85fd7dfa9b715bdc704602e68e22f6c5a59d48a921dda49a9226', 'bef3907630dea10bcc1d3fb086558954b96411874ebbedb791e027e7c482952c'), 'NESTED_LOCO_PROTOCOL.md': ('170a958b9d4f088214129f495fcd9b2f6159c11e807361c12e94b3530f5ec3ed', '918b5ca9d43fcdc483eb60004aaa4d8cac069b322d0b598e5e6dae628bb738bd', 'c1b9b463442fdbe07f865e5f7b5ccc7cd7345bb5241b12d58bd0ecd57116aa44', 'd891420ef9ee21ea23adbfad3d4eceeebea0d33ee9adb182396718ed13e3f1e6', 'f4dd8ec3435c2b0eecf4818a6823d3d5d972607cd71b513fc24f80c47ebffb18', 'da81e7ff70fc891bcf5a0f8100e8d179cf869ab04ddd9953f13fb26b77c29aea')}
        return ast.parse(repr(b"" if sha256_bytes(raw) in documented[name] else raw))
    tree = ast.parse(raw)
    if name == "padml/f5_sensitivity.py":
        before = ast.parse('_f45_source_member_sha256()', mode="eval").body
        after = ast.parse('_f45_same_run_source(context["modeling_program_sha256"])', mode="eval").body
        class ProducerQualificationOnly(ast.NodeTransformer):
            def visit_Call(self, node):
                if ast.dump(node, include_attributes=False) == ast.dump(after, include_attributes=False):
                    return before
                return self.generic_visit(node)
        for node in tree.body:
            if isinstance(node, ast.FunctionDef) and node.name == "_a12_nested_mice_source":
                node.body = [n for n in node.body if not (
                    isinstance(n, ast.ImportFrom) and n.level == 1 and n.module == "f4"
                    and [(a.name, a.asname) for a in n.names] == [("_f45_same_run_source", None)])]
                ProducerQualificationOnly().visit(node)
    # Exact audited function-AST pairs for the same-run reuse revision.
    # Unknown edits remain in the tree and fail the existing source comparison;
    # numerical kernels, loss/reduction code and all other functions stay exact.
    qualified = {
        'padml/f4.py': {
            # Previously verified scoring-contract repair; no numerical change.
            '_prepare_o_fit_partition': ('33f2a79a7097752ee84e3f7c563e69b8617cbd4a8164bc76dd3d47a1f689db74', '308785c4f5f7b371c8a434a5ed10be122977e0564bcd3709069285adf2b87fe0'),
        },
        'padml/f5.py': {
            '_nested_selector_numerical_members': ('d6b3d49a501eb38deca853fee5c1c2c4a8b2bd0ab0c7fd6cc41bcb7245b178a4', 'e0d023365a054984effd2ce10ac52fea841599e8cd7c0ac455e662b9df04f8d3'),
            '_current_q_key': ('1d6e170d54c7f31d6d04d5f9fd7631e3760c968fb08c574002b1d232f1ceefcc', 'd07a9debd15255b25cc9e60eedbe6c22ca8561d3805d4e940884509aa7c9ca23'),
            '_current_q_branch': (None, '425b417976003ab7193cb9ffe5d86c3bac704634432643114b3a26627251921e'),
            '_current_q_completed_branch': (None, '1fce7a7e46cd72adaabcafde21ea3fe117b1a924b860b56ed3087e51b6500289'),
            '_current_q_reuse_key': ('934615acbaffad8aba2046ab59c0158872572e0ac90ba26e2b5114499f6110f9', 'd070265b415da5b8c5334b1e7db993d5d6222dd89ff6d40b754e0cf4b3ae4b42'),
            '_current_q_atom_result': ('0f97f84014e7e6a2c548369967abdb71db5c568732fc934acc8f75ad5e8d9535', '5a1ad640720ac0be47d5612c672580e2121f091fc3e4635f274221e2b40bf2fe'),
            '_current_q_program': ('52581a01680ff8fa63806bbcb8da4df4901e66609729b73c8cee91c0c0e89f91', 'aacef2a08a5d8ee60d58ba45a7ee0c907bba8c66964d5b7957d6c0a9745b51ba'),
        },
        'padml/f5_sensitivity.py': {
            '_a12_mice_reuse_identity': (None, '20520ca3f550cc063adaf102a8d045a25d58062d9479eeb09ccbbb15dcf8c8ea'),
            '_a12_reused_mice_input': (None, 'bb09a1fdb235880851a518fad16c14cbb925065713c28fa14f96fa8e7e7b0a7e'),
            '_materialize_a12_projected_branches': ('940aa8d4fbe2a8e10bad1dfa64a02b4d477861d068a9af89a1500e4f29cea95b', '9936a489f4bd6d07f5ee594a60be8ed9d0c71ca759543c5af5a51c49f8db3a21'),
            '_a12_completed_mice_reuse': (None, '5d14a54aecb790f728d9333426d78ee11714c987b451e159243f448b5b5129fa'),
            'execute_a12_outer_inputs': ('115d82de5f912588dff8d5658d2c7903d3d8347f2bf6302d6fbc0109078b70ef', 'b9ca5d70f4adf9f072fd99e1441002b5389a91140b466e4ec65c427365d29931'),
            'materialize_a12_outer_inputs': ('44b3d557bd2f9ff803bf900e9bc7cf2fc80e82bebc37c8135e1ca009a62b945f', 'dbebcda78d0d6949f8d50a9eef2f311fcb87a3c6420eeea3247166adf7457397'),
            '_a12_selector_reuse_context': (None, '5df0e3381377c3837492b9c1382c32dd3fc50582764047449588592b8401235b'),
            '_a12_no_aar_selector_program': ('2e19ae21113ff41e953372d8e06a596ac2245961facbf3dce34089125bbc4328', 'e101d838341846b5f407e0c9cf23ac3e986769c8c9f3660c73cf635bedfd9d93'),
            'execute_a12_outer_bundle': ('30765c7b4863a28b9ab04e40acc18143572b1a9d31eb4dbe5c5f71fddbe20e89', 'beb2c03c7635415358feb90cfed6d0c33fe84b10b6e17a144a619c9bb403182f'),
            '_a12_outer_archive_record': ('575be22309007b6cbb34e71f289d6bb1a060bb6954c7cd3056df658d73e0b9d7', '1c2926839bb11a23422ce815b1d67c7e4622354c9beedeef3238e92c6bed82a0'),
        },
        'padml/worker.py': {
            '_f45_aar_reuse_candidates': (None, '02d2f511078e2c83ded7f5c39997e0dbd00123e086907c693d8db58d6b8b9801'),
            '_f45_aar': ('ddbf460e2525150d82a62792ca64d9ada26b183a02b79d5aabdd5dcbab703d62', '50a37e974c51a0dfd03f84b3143fbbc93eaefa77b5bd914b70b1d0fcf1d19f97'),
        },
    }
    # Exact reviewed score-reuse and FULL0 entry-boundary changes. The
    # seven numerical engines and all unlisted source stay byte/AST exact.
    score_qualified = {
        'padml/f4.py': {
            '_execute_o_fit_training_bundle': ('0903d8be2223a61991069a5d6c50b5ca781288aba8fba9e148e15769926df355', '55c085904bc279a4647715aa0c32244f7369f3887f4ea126191af11a3a0d4706'),
            '_load_o_fit_execution_archive': ('70184187f33e5a2f21991fd31504a6f44ae904b763f6eb0d01b4ee1aa5d33621', 'b8d0e372dcddf61f083959eb8bd9626ebc059195bde9fa69ac988ab8839be52e'),
            'execute_o_fit_bundle': ('337553a8bf20cb02971e078759bf8a1f7766c4d0ba36e5cc3face08397b6d6c7', '056291859a58a3fd86eb0d9102443a1fa85f5208f276a5a46de301e59bd53a56'),
        },
        'padml/f5.py': {
            '_F45ReusedScoreInputs': (None, '355c49c65ffd000ca86bfe52d9e8a743e61ccc32ddfe8b90c7c34b2e10f62bbf'),
            '_FullScoreArchiveOutputs': ('47a8b7d12a17638ceb30a05045b1763bbf479b40e90712de319d068afcfca2bf', '04d7663d0c3cacad14258dc32348577424a875873ab793d9e9cb25755007e99c'),
            '_execute_final_refit_engine': ('6907d49f72b7c70c4a5a9b0015fb15e892daee5808d81c46c88d01b59194066b', 'aab566265312dcf8ae3b1a9910f33709dfe5cb783b92c8b78253340c3365481a'),
            '_f45_score_component_numerics': (None, '5e6e3dc1ed08572499a34e78f8df1418c183be159ebe10eb2a503621c797b488'),
            '_f45_score_reuse_authorities': (None, '40e3b0c27531e01333e9630a2f50677fbf9d433272c5bec456d4bf9c774866d1'),
            '_f45_score_reuse_members': (None, 'bd8fb1b85c51a4f015c8b46760f47d45a0bc6e8d6f0f88f0066ad5f417563bba'),
            '_f45_score_reuse_source': (None, '7561315db1205113601023f0301bb20e2453ce75fbc7cb13d84e6027eee89382'),
            '_full_data_locked_score_program': ('3ce2efc0fb5e6e417fdcbc53ba999d76ea71005159d07c9b4be29d6df68e8f9a', 'fa3826d8b59d9b2468308fd3f22f9fc7902301deca010919e3162aadbf83204c'),
            '_full_score_storage_usage': ('fd196525c31bf8fbf8a6adbbf2ca0b795fdaf96efe96cea8197856730d4bd387', 'e4ed302bdb804896e2c80767157d3f06337e6b8cd39a24dcc32d3e6a3e0e4d39'),
            '_prepare_f45_score_reuse': (None, 'dec754520b62fbea477361295156710881c989867c33407cf4aecb010de00bad'),
            'execute_full_data_locked_scores': ('f566d86596b5a865d6f6ea284011e4dd76ab26a7b74effcf7eaec6707f14f72d', '61f784b5d6335b0208ec9756947c0148bc98882064cd9bad50bc1940f81358a8'),
        },
        'padml/nested_loco.py': {
            '_recompute_fresh_score_from_evidence': ('b4aacd7feaa72e9ece2ddee56d8a011b1b8b09f461d8fc3408c766ef2894db75', '8b1505ad1fece1a3f84fbb9eefef0d4e9f45046158961d23f667b78656bead11'),
            '_score_fresh_family': ('9b1513d6a55bd3fffd41864ca46a971f48e27a6cff2ef4404b0f2c786fd0dfd3', '0a1d8c1e48d5a565e37f1150796e839b62165679da792a65c160aef368faf42a'),
            'validate_fresh_score_execution': ('628e3bf80a39a27eaa03a51aa0957d9c86574a7beac8ebe9ffbaa2900d4551f7', 'd869cfdbf9fc14a4ac2a45fb2efa8147dfbd65ad3b81242e65fa901990373457'),
        },
        'padml/worker.py': {
            '_f45_full0': ('478e3fd7b1266c26da0a5a0609c9211e3f92529dd72b04950925127aef970ef8', '5fcbbffa6c35ab311ecf9361a273dc428293eb3c484e38ba1d63221f38fe2aeb'),
            '_f45_full0_score_archive': (None, '7b4f071c078b479100c5c09aa2a36cd9176e7e3175d5bed8a6cc8b88f69ed1a6'),
            '_f45_primary': ('59ea942d61de1c6c7ae399c1402adff6389f7d94ebe49082d4be8d2c8dcbe8c2', '2fb1276626bf4f9fd1735b16d539721482d32997a2fa6e2853fdde4fbfc9d5e6'),
            '_f45_score_reuse_candidates': (None, 'cff23bb624e582f28bf0b6bfddba4c54bc561d1f5069d3f8e3ed02c2409470c6'),
        },
    }
    for module, definitions in score_qualified.items():
        qualified.setdefault(module, {}).update(definitions)
    # Exact C/E producer-reader revisions; every other AST node remains exact.
    final_development_qualified = {
        'padml/f2_kernel.py': {
            '_engine_registered_partitions': ('d61297551ba7d3a7064a1bef69aac015e2096b1529f287595964486069ff6ed6', '84e0865eb0f537cff10bc7954aaf83502ac7944376301722dbbab65896b59d9c'),
        },
        'padml/f4.py': {
            '_execute_o_fit_training_bundle': ('55c085904bc279a4647715aa0c32244f7369f3887f4ea126191af11a3a0d4706', 'b346a7414dcc4eea9f96500cd58e2932a77f2841dafab3200a0f81c10ac8b14f'),
            '_load_o_fit_execution_archive': ('b8d0e372dcddf61f083959eb8bd9626ebc059195bde9fa69ac988ab8839be52e', '6ef578f773e85e8478730ad6c65449094e1c7c8995ed54418a9fcf47a1a80194'),
            '_o_fit_post_lock_m20': ('772073487ac7802c23116b379a3a50905af534a1e5ecf16b829446d841aeb4d0', 'c1befb757d0e2e1ae2544f660ca7ccd70743db18b32f725c6e95ea658568ae41'),
        },
        'padml/f4_compact.py': {
            '_o_fit_final_component_numbers': (None, '5df36fa2e8490536a33e86fb1d1a5949ef7f9ddf7622bccbe8055535d0502290'),
            '_o_fit_final_numbers': ('555bbc8ab4dbcb55c501152484cdd575c84ad330a43466a03ef80b6d3a29c31a', 'dd4dec644468c6137cd5f21d328197afb86b8696331f9a259424c6652dbd8b32'),
        },
        'padml/f5.py': {
            '_collect_final_refit_component': ('f9fc6a6fa0e4e902c356791bee0d35e0ac3d30d6cc8a8f15943307af75bfeaaf', '4dbbfda2094baddbac30b8f228aeaaef5b749fec93a6c9047a2c9b2a68a442d2'),
            '_collect_final_shap_component': ('db2ee20e24803907e68b77dc914f49d27228d754ccd8fec7c0d51df27f226e4f', '5fb86cf68a571e8b593a89a1d0ef23fd00c344028d97ae8930511c52e3b19e96'),
            '_execute_final_refit_bundle_pair': ('1792b13db71334c2ad84ad8170132f51534a9d70de9b5631fcf92c7f19f14242', '0848b4834ac1b11b232d2f7d1bcb706e57652e3d43deec1b82801c20c65f975c'),
            '_execute_paired_diagnostic': ('f14f5c20564a3f6036e78f2837fab8eb8db94a57682e485c58989e71e23ee4b8', 'c4e345dd5da9b904b4a0a3dee79fb5071864f807d2608d2771fc9d602ab9ff22'),
            '_f45_final_component_numerics': (None, 'c0dae40389af85e0f4a880c01972624dc40048a18757907ad1810959a566923f'),
            '_f45_final_consumer_receipt': (None, '1e8ec07cc89170add555dfba74bb68f6a68acb015486e7c67ae557c8374a1364'),
            '_f45_final_native_objects': (None, '6fd10ed216b34a902e313d8506b643b4d3dbe82239fa7dd4724ce8746297eb89'),
            '_f45_final_shap_binding': (None, '021e7d660bdb6fca6728cb320208f5629e2f2461608f8bcd882fbe898f4b4685'),
            '_f45_full_final_reuse_evidence': (None, '251229d243c8b415d6b38cd95e6419cf1bbb387bdcaf1b6d9cb1f4b566b4180d'),
            '_f45_full_final_reuse_members': (None, '2c31e8cdc3489a485e10c677911f39b933eae44b08b41ca4c99c239c670fe9cd'),
            '_f45_full_final_reuse_read': (None, '18eade9a4c28bf54c8637051f3de40eac532a105bbd7a5cb3ff9f81c6c3b3ef6'),
            '_f45_full_final_reuse_source': (None, 'aba28a09dc266102a9398ba62990d1e704342d8b8e5895eabbf6490a0c249780'),
            '_f45_full_shap_checkpoint': (None, '2ee7a5cd360e2f91659e668d95246b7a0314426bc9c1380c066005b1a99f55e9'),
            '_f45_primary_final_reuse_members': (None, '8af9929ebb221e72708712203d01caf1b9e496a26f39750ef3ec0977267b9eb7'),
            '_f45_primary_final_reuse_read': (None, 'ae0476bef25ac5aad5a391269e0c68148b4e85350c30bd90e1acdafb63df1131'),
            '_f45_retain_final_object': (None, '3ff245fb81965e139173ede519499ca3c53f548356231da73573f80ab19d89f6'),
            '_full_final_component_numbers': ('a7371e50323fb6282b5276f50bba59bf12d409cf7bfc073441dfdb8a634708e2', 'b5d126788c388526a18bb35bf452e9c2ef74058a82ebbcbed4881d30bc0d6605'),
            '_load_or_produce_final_shap_checkpoint': ('63b4719bf1a55ddd24ff1bcf5e9efe6b7c047ec95c5e04fa63efba68f11fdab3', 'da396b5687b694c611c6957a60a3dda39b6049aada30ed2711f8dd116f9a122f'),
            '_prepare_f45_full_final_reuse': (None, '090561abd0dae9dc127280f62d3f2588d9063a3c7c7809975d52266f816a83e0'),
            '_prepare_f45_full_shap_reuse': (None, 'a77508833bc2607acf13ff067f5209b67e288cf5140467ea99565b9a52c0f37e'),
            '_prepare_f45_primary_final_reuse': (None, '5393c2c99b4d3a258c43df5f68edba3fc6d2e847bdd5dd9b625d6e75163e9a32'),
            'collect_final_refit_results': ('cdc1e786623beb8a688375141b5a71be36af559000519e8cd4ec7fbf1e38f329', '829a9532af4a52d9e943e0965c97ff39914e397f3bbe8cdb18bcac0096d27c69'),
            'execute_final_refit_batch': ('b5ce11e1b37bea0b238284bd2820551f8b578bfa32b073bda8712af6c3f45a32', 'a33dfcbe7edc04b2332dfe55b41e6afe11e5ff81ae848de722b4ad0f37a39800'),
        },
        'padml/f5_application.py': {
            'load_application_models': ('c6eb635d0d78d344235d401026bb3111b5b3c5ab7cea98a3ac8b71b5763eac15', 'c6d3bd9f78c499a30e1046d6d49465d8be08cdf64db1c9ec4b8696a531ad1940'),
            'predict_completed_application': ('8f9ddaab2b39eaf4733615a0fe1c6d66ddd02f6b0b37071ccc0d5e9252299718', 'b74c35a6d4757807bb274053a15c4ac91d0572d18e25a79d452e559971f7cca9'),
        },
        'padml/f5_sensitivity.py': {
            '_a12_development_reuse_sources': (None, '47fcacd039a33f775123d92efe916f3abc047d0125d875297cc34ee5673f7e61'),
            '_a12_elastic_reuse': (None, 'df6dde09694bbd413a2f4a5e6cc3eb6bcaa01994461c0c4654008ea02b056411'),
            '_a12_elastic_search_program': ('a327cff4eed949dfe480be9f9f3f329387343145233303883927b6e3c98d4f3d', '7d7639476614fd05e8cfd3f2f717322772dcea43f17d6afb41797e1293555b58'),
            '_a12_execute_final_pool': (None, '464500ae6115397e808e4f2ae7ca26aa0d304ac92a0398013107f6db18ff6386'),
            '_a12_final_reuse_members': (None, 'b764b4db41dd7afcc26a34321e26b09926088e683faa818972f8ad5ca57dfbf9'),
            '_a12_final_reuse_read': (None, '19527ba8171d54ddc0cbd4ceaa11b48cc43d07dab77c5027b7f8bc330deb7dd7'),
            '_a12_final_reuse_source': (None, '635f1baba7a514839788c093397ba29a76f4e7f7fceb14d3815ab2b9f7cf00b6'),
            '_a12_outer_archive_record': ('1c2926839bb11a23422ce815b1d67c7e4622354c9beedeef3238e92c6bed82a0', '50db5a309da8af1c61c175d80e671170099d3719f804ebff59dea1cbd3156272'),
            '_a12_outer_model_jobs': ('c2ca90b3a297c31fcdd577afdc98b0ef2e91c629222f82c907450198faae17d2', 'c26da0cf6c63f738d0a62eed8d260238d1066f8380a8c3505489ec4b4f571cfb'),
            '_a12_outer_retained_members': ('6604cd8b3da1c1171e02dcdd26e0aaa9c83adbc769810f1f8cb10242c99aaf06', '9c1933e43a987cb1ecc73b334b458990b7b25a183fa3b44ba0461d1caf77d02d', '4996dccc91a10271608c636dc3673f112c590f25353880112795901a183516a8'),
            '_a12_projected_development_inputs': ('e82688492d8b7104ca81695d6f2efbe521416ce24889c5e8b2f70c7d360932ae', 'fc40229f10ec427bf5f211ec27d3cfa138df0c726eeb0cb1cfb07045e69edab9'),
            '_a12_recipe_reuse': (None, 'cea5b736d7c17593b315e89313f636ed57db89ad813666c1eda841bfcec08f8a'),
            '_ablation_component_numbers': ('5a2e82bb43387263af774807254d904e0ee7d50d64d650594f3f1a2c43367bbf', '57fddbecb6ba52b826eba238cd802067a731b566d2cbe5e5e009903dda044f93'),
            '_execute_ablation_component': ('e1e63c13a1f97f89d6af270556bf5691f5f0772b346611e4ef312aafd35b150b', '1e181eba3d165bc5cb6404e38ec900fcca354aa8ea27b142fc1fff5c9321356d'),
            '_load_a12_outer_archive': ('b5cb330cf0bed019fc434534d0482b97f9062342193ed865e50614acb9d659f6', '503e9d18514c6a1487ff72a3e55e00dc90c43a717bb124a80f3126310487e014'),
            '_prepare_a12_final_reuse': (None, '3d40020d670c695cd3ce3e60203fd0f8d0f532f482131fa0674bbe5d125298ab'),
            '_replay_ablation_component': ('a35ac10794289c207089ad3ad8d23d120ac3eaece4a8f7a555cfed406a8ad668', 'e8cd9f01f90473727779708e99ba827a5fcf08fa3bdb969e7744b9a583a62670'),
            'execute_a12_outer_bundle': ('beb2c03c7635415358feb90cfed6d0c33fe84b10b6e17a144a619c9bb403182f', '058d4ad8f5f03082350a25a632c00827fc9de3db7ca353a1b504caae5eb7ee23'),
        },
        'padml/worker.py': {
            '_f45_full0': ('5fcbbffa6c35ab311ecf9361a273dc428293eb3c484e38ba1d63221f38fe2aeb', '3b8540e6cd9e08dcad052bae59c074113acd18f024d318e13dd01ef69bc7cc25'),
        },
    }
    for module, definitions in final_development_qualified.items():
        target = qualified.setdefault(module, {})
        for function, revisions in definitions.items():
            target[function] = tuple(dict.fromkeys((*target.get(function, ()), *revisions)))
    # Completed FULL0 Q readers release file-cache pressure before scoring.
    # Both reviewed bodies preserve numerical returns and producer identities.
    qualified['padml/f5.py']['_nested_full_score_development'] = (
        '1949b35e6a9aadd75aa6f5443c23c7190b0a18680406d1ed3da96a29e770d351',
        'c3955fc49f14b2cd0090be820267023e63c9fa0d32c95dd94d3e203be1581ff7')
    qualified['padml/f5.py']['_full_score_resume_development'] = (
        None, 'e28f58029d61f5fa38970d4b9a8eba5979b82bf4e81a7317826ac7785867c371')
    qualified['padml/f5.py']['_compile_full_score_inputs'] = (
        '9a6b510e94604c69c9a8a189ebb83344ed36953274e15615829b00c6639e3040',
        'fe9cd5eddd612e9157ccc8ce5d2d5f944dff1cdfe2cbcba8ed2139a31d474d29')
    # Pinned completed-consumer diagnostics repair; no numerical body is generalized.
    completed_consumer_qualified = {'padml/f5_sensitivity.py': {'_validate_a12_final_input_execution': ('b55307aed46dd790844578dea479f175c0eefead45f612cae45ec1693000eac7',
                                                                     '26e18affc56c291b9726f33268b3c356e94ef2609bb615d5a77c535160ac1dcb'),
                             '_validate_a12_whole_artifacts': (None,
                                                               '2b7af6f53e0c7d46b9a6ac5a664ab35cb18d9121f1d608ffeb7b014140acb8d4'),
                             '_a12_final_reuse_source': ('635f1baba7a514839788c093397ba29a76f4e7f7fceb14d3815ab2b9f7cf00b6',
                                                         '9e627747507b094fc4895ec4b3bb16fdbb01ca9d1224f2a097e0a14cc80e7aaa'),
                             '_resume_a12_outer_consumer': (None,
                                                            'daf9cfbd3c2ad430a7821abef6be05305ac3f543f588a8019f703606a341118d'),
                             '_load_a12_outer_archive': ('503e9d18514c6a1487ff72a3e55e00dc90c43a717bb124a80f3126310487e014',
                                                         '6430cb06cfc878e626117874c63788b8fa3a9f923f81ce9c0a43d65cce5fbcaa')},
 'padml/worker.py': {'_f45_aar': ('50a37e974c51a0dfd03f84b3143fbbc93eaefa77b5bd914b70b1d0fcf1d19f97',
                                  '1896b37adc13ecc1770a11bf966123a603fcf40678fcb1c0e64c553898ed595f'),
                     '_f45_aar_reuse_candidates': ('02d2f511078e2c83ded7f5c39997e0dbd00123e086907c693d8db58d6b8b9801',
                                                   '4c8869d891f66dac25a5bc92caef6ae3d5b283621842373de53a91c9c2cc3fd3')}}
    for module, definitions in completed_consumer_qualified.items():
        target = qualified.setdefault(module, {})
        for function, revisions in definitions.items():
            target[function] = tuple(dict.fromkeys((*target.get(function, ()), *revisions)))
    # Exact authorized cumulative-step release and pre-SHAP dependency repair.
    step_cache_shap_qualified = {'padml/runtime.py': {'_scan_visible_open_file_keys': ('ec74343f6785960b4dd57044735b933099e43071487e5ffc138b1a15b3e1fdf5',), 'release_step_resources': ('28da04ab358b8d99316cf76dce67b0803fa690393d569379534c94434113521b', 'a3026291c42ebbf66c00d2c72a5432c51a07dfc73fd0a0f606af0f89f2a1151e', 'b032e8ff557ce51d76afbe20b402f6e3f3d97b6304b2d7c43d7f55dc73c1ac54'), 'release_completed_files': ('51d0afca718a1a2c0a1f1573b35d59d6e0a85a945c6b63bb1d4a93044f936cb6', 'f7c0e9db20c2779d351d11d41e703e2724438fcc0b1a14c78821ca047bd5f0d8'), 'release_f45_cumulative_files': ('07f783396d5dfb2987988039f4a6c992325def66e7951e83ff4f45febda72246',), '_release_f45_cumulative_files': ('a683d79ed490222dd15205dd071f28c3f987649907fdfdd950c902650fa0943d',), 'validate_resource_release': ('2652468b85e4505179bbc7905f336606f36bacc652c6048346ee837af93473d4', 'd6c8c82d276f7789639975551dd0695d64f5090da8cbab11dd30dd521a0f1510')}, 'padml/f5.py': {'_current_q_task_batch': ('8a1962ff1c6029ad878e31c4a97f8e93a663feb51a8040f103158ceaf5ff1988', 'aa4dfb42e8ca6770db89e38a8d637b5618cb8ea02f223d15cdae48d56a2dbe66', 'eb5ca07eed1dcf23d9aaed787467333607ab2f8e715442c4dd28baa2fb280398'), '_f45_shap_dependency_repair': ('b775bcfba80c29633f9f445cad4d3574c0fff6e49caaf1c92b0bcf565def9b6b',), '_load_or_produce_final_shap_checkpoint': ('63b4719bf1a55ddd24ff1bcf5e9efe6b7c047ec95c5e04fa63efba68f11fdab3', '9dd32ee8584bf79cce03359c7c2beea2f7ed9a564b3a7431e2fed95c661aaa1d', 'da396b5687b694c611c6957a60a3dda39b6049aada30ed2711f8dd116f9a122f'), '_consume_final_parameter_source': ('0544c05ef518453ae042d97c6e46a6b615165b6b582ab27392d4f0b49205ae5b', 'bc96941a28790b9ea19616f4722337bc1e9ad3ebe50893ac54b6f2820a82f1d2')}, 'padml/worker.py': {'_f45_release': ('a1ab7ae13a39d419f8ebcb9a292c47f1f04d9079cfbb1a0c677ef80ee2ec8cee', 'a498906bb2e4b8d0f3850424ae93cafd68683a4b1d0c3ee6b5f3695abe3d02c6'), 'execute_f45': ('0dd7be61976d9b9e94688f10bfd7ba84bb9a5e77d620f25da107880dee2188d3', '4b18ed2a36959c12a96df38e956bdfd266bae6d39bd58deff8a70396c5010ddf', '593eb76a54bf0ea003f6290740b5c7cc485424138dec4929c84c1a61b6360e09', '8be31787aa87841d67a5c5c013dd54f5e08c15f017fe00917afba6815647b2cb', '9d61df91a7180a93bb958aa4e99d6a5706106384d668ee0b8b88fedc3cd3f799')}, 'padml/f4.py': {'_f45_source_member_sha256': ('0306b9ef6ff4e9aa1eb95e9a4a2dfc63731e1f9a2163289cc8ddba987d425828', 'cb8948fac64e68da9236cb8076e8cedda63ee16e1606da4ec5d616a5a1ebe61d'), 'load_f45_source_bundle': ('87b4473f06015c5fc23d25f87b59d7154d78d6ad2b5463d0c667ccc2aa336cd8', 'cccfba68e23cc82314963d392d32e75bcc7d30c2be168cc59d9ae96e811550f3'), '_read_f45_source_bundle': ('111142aaa5427d15f37d1d05263fdbde429acb95048fa1558f27f228d1672479',)}, 'padml/run.py': {'_f45_cached_source_validation': ('769c25dac78d62cd000be8a31a8d8e4cf4d5829b9be9e0bed1bd7a40815bf8eb',), '_f45_source_structure': ('d0721078d5f1b5d17c3f5ce459307b485fa4a62da80371b65425dcc8a988cb1b',), '_f45_unit_predecessor_uncached': ('81f106e9a042fa90067d99db1d0a0dcb1a3be45d22827f997c65dc26e1493034',), '_validate_f45_resource_revision_uncached': ('3f20cb696a88985d9b19d966cb5cb1dd5ba153fb545675d62d6db5db5e5b87ab',)}, 'padml/f5_sensitivity.py': {'_a12_outer_searches': ('5fd773e4f104f37375540324f198e9ee6d195a6de49178827a65936f9996097d', '8a3f566297c4d12959ea3c71cad7d93cc337462efdd45934aeb4c6b1f5da124d', 'fbae81cf80bae6f346eb75bf9e9eb381eeccb7b05a45d2dd00685abb4f5afc78'), 'execute_a12_outer_bundle': ('058d4ad8f5f03082350a25a632c00827fc9de3db7ca353a1b504caae5eb7ee23', '3a36e4f89106f3ea2c3b1db466df3e168e12cdc0ced3d5c488620ccd05683320')}}
    for module, definitions in step_cache_shap_qualified.items():
        target = qualified.setdefault(module, {})
        for function, revisions in definitions.items():
            target[function] = tuple(dict.fromkeys((*target.get(function, ()), *revisions)))
    # Exact completed-readback revision; preserves numerical bodies and original producers.
    readback_qualified = {'padml/f4_compact.py': {'_full_pipeline_q_numerical_members': ('2bd175490e2230d7b433eea3d93c9604ffef16fe7ebe46121f56861eb6353951',
                                                                    '43997cbbefbd681eae5c196918feb0e3974fba0317595fb8a2a5e2123f71b512'),
                             '_q_coordinate_read_job': ('6fedf1d729f9b42258d65acbde9277f078efe073fce3e40a0eac57b438b97e26',),
                             '_q_object_audit_read': ('fe2ed4a2b987fd995f1d0acde7c3cff9df420017e34c96189e62b55398bc08e1',)},
     'padml/f5.py': {'_compile_full_final_inputs': ('aaaf440debf0e74cec09d87795b47685a19725a785b91859e02668ec57d09d29',
                                                    '260545836a5a72cd9e4fec877a46d0c6b673e5e32b5f38d64c22a39ab66720f7'),
                     '_completed_score_family_read_job': ('97b5019810fda2c02d53a4db961e6316599755e756c8de40f4dd0111455709e9',),
                     '_consume_final_parameter_source': ('bc96941a28790b9ea19616f4722337bc1e9ad3ebe50893ac54b6f2820a82f1d2',
                                                         '7674206cc6131ede05fb2f69e5c67220f88d61c42f571aeda284cd821b4f2f4d'),
                     '_current_q_program': ('aacef2a08a5d8ee60d58ba45a7ee0c907bba8c66964d5b7957d6c0a9745b51ba',
                                            'b0e27512a9ef925f822a83c076b46877a492664d70691538dfec094e2281076d',
                                            '2e67f6f26cb0bd90a7bcd846097fb9904b7b0c89b5509dcfb1be32d7ed4f9b3d'),
                     '_current_q_task_batch': ('aa4dfb42e8ca6770db89e38a8d637b5618cb8ea02f223d15cdae48d56a2dbe66',
                                               '65bc2c48d81c2d528c1187bccb5581c35cb28a78302c28d30d42acfac36a143d'),
                     '_full_data_locked_score_program': ('fa3826d8b59d9b2468308fd3f22f9fc7902301deca010919e3162aadbf83204c',
                                                         'b33ea9f5bcfbed5fba9ce49a966c7fa99c019c5373ef9471427c64a2091ae5f5'),
                     '_full_data_partition_read_job': ('56f6c10cef95ab60b771c1450ffde5911a17de9d85e0093c2855eceb5b1c059b',),
                     '_full_final_bound_read_job': ('9a36a409081e218407c4c7614f5f7a8f181c344353e242b0984131f544f3b1c9',),
                     '_full_final_component_numbers': ('b5d126788c388526a18bb35bf452e9c2ef74058a82ebbcbed4881d30bc0d6605',
                                                       '745397e128f5a62b8591b6f50026c950b23574e35e916c0ee5370fd42a5fb33b'),
                     '_materialize_final_search_inputs': ('4a43b95cb970e40d0bbd544847b7fbe1a0c0b76c29e549bf997660ebbe281731',
                                                          '231249c69b67c0c72974ceac93d958927ee905f3a9a1d436088be0cc4581ddd0'),
                     '_materialized_full_data_development_sources': ('68e8071b69d098249c0b04e44e0aadc6eaeeb26721d9eef74d066668b9af4e8e',
                                                                     '73efc856bd866c21e888fdf76cc7f094ae0d0e2a2a793dc0bf99ab187f3be06b'),
                     '_mice_readback_memory': ('34b97dab9500fa943d27d649b7787a40193b3d3aa9d2199db20943803de8dd7c',),
                     'collect_final_refit_results': ('829a9532af4a52d9e943e0965c97ff39914e397f3bbe8cdb18bcac0096d27c69',
                                                     '997e3b02b72985e2de29084a381ebcaa1a3df9a5046976adee32eeb0c5381437')},
     'padml/f5_application.py': {'_read_full_application_component': ('283b6ee89365d76ca6c05464c2235f972dcdcfbc27569ed74242120b39e0f401',),
                                 'load_application_models': ('c6d3bd9f78c499a30e1046d6d49465d8be08cdf64db1c9ec4b8696a531ad1940',
                                                             '1f91b1b4dcf9826493fe19904458e7cb7e4d6e62a5f3a46c06bd7fdb2704bee5')},
     'padml/f5_sensitivity.py': {'_a12_outer_retained_members': ('4996dccc91a10271608c636dc3673f112c590f25353880112795901a183516a8',
                                                                 'a1a3f4b5adf9a5290921d29d2f9898dccaa7d36b8f8f5b5ed72bb1e4be0e9624'),
                                 '_a12_outer_searches': ('5fd773e4f104f37375540324f198e9ee6d195a6de49178827a65936f9996097d',
                                                         '3759cd580dea5e23add630019559816fc0fea87090393da6468b52770d7f9f90'),
                                 '_a12_projected_input_read_job': ('9eb67b1d56e0b7bad22e4bfa623b0dcdf526d7a3cb60c5dce9f68f0151c9fa17',),
                                 '_a12_projected_partition_read_job': ('c7492c46f4b041087eba0ef8b834ba15bec2a42f94796d90771b259d464b1b9f',),
                                 '_load_a12_projected_outer_inputs': ('82464de0a607f6d9621809859f11be467d74ce2906a7c1ca372db84802964c6e',
                                                                      'e11900882801db951811d9e965379347bdf7b29e773015c1519731b552f2fe82'),
                                 '_materialize_a12_projected_branches': ('9936a489f4bd6d07f5ee594a60be8ed9d0c71ca759543c5af5a51c49f8db3a21',
                                                                         '117622aca0eebca13d942b5c3cd1a594c918befd40f7772d562f80ed4af31083'),
                                 'execute_a12_outer_bundle': ('058d4ad8f5f03082350a25a632c00827fc9de3db7ca353a1b504caae5eb7ee23',
                                                              '3a36e4f89106f3ea2c3b1db466df3e168e12cdc0ced3d5c488620ccd05683320')},
     'padml/runtime.py': {'_readback_ordered': ('d7e7e0aa35e5fdb2dc8f034a5ec9aabcafe377c58f53214d1985505c117a3622',
                                                '3fe87fb977f0195ea7dabb6dd91a16f63a39f4f4df42b8837a08e70c5ae246cf'),
                          '_release_f45_cumulative_files': ('a683d79ed490222dd15205dd071f28c3f987649907fdfdd950c902650fa0943d',
                                                            'e831566f1ab8b4be2a6b2e58a5d243fe993ed14277bfbdfd400ca382aedda8ef')},
     'padml/worker.py': {'_f45_archive_group_read_job': ('536d6de0e3cba45fcde2dbae682550cab278a81dd90f696ba713090c79e4425a',),
                         '_f45_file_group_read_job': ('568a86c48c93df67265349656e0477872c2451af3dbac0f662aec04413fe2d6e',),
                         '_f45_file_pins': ('8af5a4f3dd85fca177a6165b0e05b2ccadf4413e3d077fa85768f54023a57b3b',),
                         '_f45_full0': ('3b8540e6cd9e08dcad052bae59c074113acd18f024d318e13dd01ef69bc7cc25',
                                        '52fc6542c54ec6b445865dd1552a9cb9b5a91780ef799478f18cabd6cb313e03'),
                         '_f45_full0_score_archive': ('7b4f071c078b479100c5c09aa2a36cd9176e7e3175d5bed8a6cc8b88f69ed1a6',
                                                      '8a476dbce4ec0fb48b865795fa0f95b3f6fb0edfc0fbb6b0c4c90a7916e73263'),
                         'execute_f45': ('593eb76a54bf0ea003f6290740b5c7cc485424138dec4929c84c1a61b6360e09',
                                         '73f2ae9329ca13b3d6c76df3b22582ad4faabfb0ed667e9dd8fc5bb3dd327e26')}}
    for module, definitions in readback_qualified.items():
        target = qualified.setdefault(module, {})
        for function, revisions in definitions.items():
            target[function] = tuple(dict.fromkeys((*target.get(function, ()), *revisions)))
    # End exact completed-readback revision.
    # Equivalent retained SHAP conversion/prediction, checked against the
    # original encoder and native margin API. All other class edits reject.
    qualified['padml/f5.py']['_FinalShapPythonPredictor'] = (
        '4af7b71984e112a652c5d732d747aefe9037505b14123ee2571d8cd0809e5eb3',
        '2e3cda5a0afb926afd7881fb22184dc4b303b220b17cbe86c7a4e66de4740f6e')
    # Begin exact H36 population and SHAP500 revision.
    population_qualified = {'padml/f2_kernel.py': {'_center_stratified_evaluation_context': ('c00a42b4fd37a68b67ec502e22be6ee287c244e32d5e9d637113f7a6ae7d0bf9',
                                                                      '57740a34f5e85efeeec8dc596deae6cf87e6bc179afac27b5c96e564f91c0702'),
                            '_consume_r_prediction': ('545df5f2b9fb28fcb673f87f5dfdba4ac7f292008fdd90799f003e4a5623f96c',
                                                      '5bb2c28a9264a9c5ef90617ec8e824b0410d275c356d45e4d3cf4de09dcac906'),
                            '_coxtime_evaluate_locked_seal': ('db61548ca59df9d37ffee1796e92a8bf668382e813cb949db62d5f0d1fcd4ed4',
                                                              '58372b890eaa05533d2fdd7a986a675fa320440cbf337c9f16039eb53db23601'),
                            '_development_evaluation_indices': (None,
                                                                '16832a442cf73257a3c019c8d9123d20267470c6a63c8e67530ea3bb1725a108'),
                            '_evaluate_coxtime_function_seal': ('cc073ad49cddabad84b1c8ca03b8ed3a36ac7481eebecd2683cad12fc317e06a',
                                                                'd3dd92edff663da85f108c3dadb4865f1addbec0a40cbbfe30ce88c9b9069cc0'),
                            '_evaluate_elastic_alpha_phase': ('f31bb57cba7ccd1503f918cdb5c5d5296f48ebcb59297cc3cb5b9f56216c1ed3',
                                                              '246e5a78924e97aa4f3ca5df63a299df99ef17a50f3d90ced8a347794e6aa7de'),
                            '_evaluate_prediction_seal': ('8a82f03c902b275f4f6a66d3bd5c004d10fcff50c8c1b565477c415a4d57255f',
                                                          '20dddbeca70fbc1fb5b77aa17ac1242b07919c8c2544e8f91c36c77fe6e7447d'),
                            '_grouped_cox_evaluation_context': ('7a40c47028680bead654acef91a75664a4b9b436cb7cfe83d9a5d7a43241f2d7',
                                                                '459f6b49aee1172e3f1013a3949d24d8582390329b40c98ce6499845c1da9760'),
                            '_grouped_cox_loss_path': ('86bcec70c2657abe0ac3d94bf3d8abb279d4610202f06d51fd68be27f2bd7259',
                                                       'b4d109d78a27fb28150f446da5b6fea70d411fdf40ec8b20083ae3c84361ec08'),
                            '_prediction_evaluation_context': ('23da676181b5869f27ab220a6e5ddd4a46b951528ad4b40d970fbf164a44c6d1',
                                                               'e88419927e9fede3e20939f618f54f757886805befbb041ba2df25286c789ad8'),
                            '_run_coxtime_function_evaluator_pool_task': ('edd8d0ef28c6e89e8ba676147212a87f32f006fce8e67538a7a3f5a237d5e635',
                                                                          '888695ba770aace34c57467e06c2efe7fb7c1ebcfb42f9185694c3ff6292a20f'),
                            '_run_xgb_function_evaluator_pool_task': ('f65035a6264919ebccb2bc6d43a8ca90630dc4bcdccb51a9c1504bd13312a9da',
                                                                      '1445d6ae6481e8c6dea340ae88be308f6226a15e5c129ba33d319fe863fbb266'),
                            '_trial_scoring_context': ('c74300f862a430ddd8ccdcf5958ab643de4724d1bab869475d621de6fe267ec7',
                                                       '3c41bc670b86f13ba57ab500a589c43975e93e6bb22401c48e26b1357986a83c'),
                            '_xgb_evaluate_locked_seal': ('f65d7d170d34e8566e08f4a0bcf8a4d1c391094923dc0f141a78ba57f2e2e0fc',
                                                          'ed57c4dab3784ad125b88c1daddbabf2a1d76629fe33faa59da8df7afb1b7cf7')},
     'padml/f4.py': {'_compile_o_fit_bundle': ('4e48c075628b8e160cb6647b08a37f00f3ea4c6f2a81a33abc2a78c0712c0bf8',
                                               '7604af9bfa4ec631f543227002256fdbbb25d02ac51072c97f2ce4063142cb02'),
                     '_consume_learning_selector_path': ('be342cf364f8717d8d682efa822ee1a6b62878cb18521f8b06c8b3496481cac5',
                                                         '304e7e25b23e315c38720cd841b26bf6d9cf48f60afa84cec8848da7644dc28d'),
                     '_full_pipeline_selector_phase_calls': ('96214bed32429b202ef6469b103c94511e88bf24d8aa619538bf7f4427799cdf',
                                                             '0581b5bdeee463ff06503084441142b3ffb03beaa9b28b49d3b026f53cfd4551'),
                     '_full_pipeline_selector_search': ('3ac5dd6553bf54e3726bc69ae05d0e1c7103b14dafd45a028b4b77a167f6eaba',
                                                        '49ea72642435329c5385da5834c57eaecbbca12c2277f8b67c5b419c04646dc0'),
                     '_load_o_fit_execution_archive': ('6ef578f773e85e8478730ad6c65449094e1c7c8995ed54418a9fcf47a1a80194',
                                                       'f482315bc1572752edcb1eed0173e22be9d14ce18c2859ff9ae6802b5343939b'),
                     '_materialize_o_fit_input_bundle': ('a3646ae944eed6727b4bfbb0e7aa38ab23144fc275326fd0c5efe578f3735c2e',
                                                         'af8a011fe52a0a62ec04e112df1d1735fde808103c98a9dcbf8eb8e2f62a928e'),
                     '_prepare_o_fit_partition': ('308785c4f5f7b371c8a434a5ed10be122977e0564bcd3709069285adf2b87fe0',
                                                  '0901bdc70c9dc34f6c96fcea61cc5de469aafb6076b7f36337e3e6de5e0cf696'),
                     '_primary_pre_search_family_projection': ('5a56b1e99c1f74e4e9b9da869221c71e1942c14cb78f6fa700e8112bf9593026',
                                                               '2220005c0fb6d0da7a6e228e25173990addf644dd09368dbde42ba152c7400d9'),
                     '_reduce_full_pipeline_selector_phase': ('7a872896634d6729b3dad913ecc8b6bd5657e670350ad5a73a6effe04054a092',
                                                              '34468998da52fc79fe5c41bbf02f1cc811e605b06b13af771fc9c4032c910c53'),
                     '_run_learning_selector_path': ('da66311d69ea51cf7171a10cdff3aafc17b012bc524c62b8104281887a1cf849',
                                                     '85b5afda2f90b5f7735ed50fc26a5316946c975fd2facf20e6e49ae072f946cb'),
                     'compile_o_fit_bundle': ('e107df0d3846133c9eda0c15c3abd72c4d2f707fb1dc7e9b6bbe60793ff1b56e',
                                              'c36fff2ca61ec69e35d732311194faab50a17a260017371a2c71a8077471fbd3')},
     'padml/f4_compact.py': {'_full_pipeline_python_stop_evaluate_numbers': ('a64842613150051638764b23732c8d43506f3ddec9d91768a4160468562370a6',
                                                                             '04c1915895a7de727a30ea611f066fc2c3653b8703e29db1895c4074a2a01c01'),
                             '_full_pipeline_q_stop_numbers': ('984b6a9058ffc8897755075d70bb878b196dc0ac8948aed876018d63e9a5f552',
                                                               'f21809c7ccc918fe6c93ee89981f576c0ef9c63397f5c9fbd70a168b824cc1e1')},
     'padml/f5.py': {'_FinalShapBudgetExhausted': (None,
                                                   '6f61849a9f92bb78246dfe37336a9984c77386e7d73d2d3f34a6d8c958a086e3'),
                     '_current_q_atom_result': ('5a1ad640720ac0be47d5612c672580e2121f091fc3e4635f274221e2b40bf2fe',
                                                '5e21c3f74855f14433233c1df1bc5a60dc30ee2775cafdd9860729e8b7ef3017'),
                     '_current_q_key': ('d07a9debd15255b25cc9e60eedbe6c22ca8561d3805d4e940884509aa7c9ca23',
                                        '6e340ffee6ac14465afc7377002d5dee51efd6e8000f381ffc4c0788b0c8ec12'),
                     '_current_q_row': ('2604388466a93eec585ab9edfa4899beb8eb3fa0d87bc4ed1262337afc10d958',
                                        '2faccea7aab0f3dfa14c78067808ad9aa3d8b9baf521a084fd56e9bd10441daf'),
                     '_current_q_stop_rescore': (None, '960d505a4c32876a97f25bc4617db36b8479bc44398d22949b189b4e31753daf'),
                     '_current_q_stop_source': (None, '7162b31e5264e1e7bf7a96bf580ec92a46fb15c5659e1675787e379c36db6647'),
                     '_execute_final_refit_bundle_pair': ('0848b4834ac1b11b232d2f7d1bcb706e57652e3d43deec1b82801c20c65f975c',
                                                          '47197cb67705c8338774400a0a4a00e2f7cf633078a451780d22fd993c45d799'),
                     '_f45_full_final_reuse_source': ('aba28a09dc266102a9398ba62990d1e704342d8b8e5895eabbf6490a0c249780',
                                                      '6d5067f49f29459811d9a7a93eae1a271e15a982391b873cd7b1cdad95674c59'),
                     '_f45_full_shap_checkpoint': ('2ee7a5cd360e2f91659e668d95246b7a0314426bc9c1380c066005b1a99f55e9',
                                                   'f6db602afad1ebdb625ed3490d2a5b3dc4f9f28b222bdb0b4ffc0fd3caffa450'),
                     '_f45_score_reuse_source': ('7561315db1205113601023f0301bb20e2453ce75fbc7cb13d84e6027eee89382',
                                                 'b8d636cf856d706506081ffc2f128d5a720f7b10e144be50918cbc5316b762db'),
                     '_full_development_science_decision': ('dafcd6f61b15518fd7252fd602003840add6e7b82af8d05bf69516cac3211f50',
                                                            'abb3cffdd03989be2058cc4ceacc6cbe186fef57fc526ac9ce3aaf40062dc71d'),
                     '_load_or_produce_final_shap_checkpoint': ('9dd32ee8584bf79cce03359c7c2beea2f7ed9a564b3a7431e2fed95c661aaa1d',
                                                                '8946158e212b3fb2d40287564abd3c412e5d702edc99e3f7ff12cabe528079da'),
                     '_nested_full_score_development': ('c3955fc49f14b2cd0090be820267023e63c9fa0d32c95dd94d3e203be1581ff7',
                                                        '624f234d4e00ef3c567ace76a6f51eeacdc8910fed22fb380ddaa182e63ee8b1'),
                     '_nested_full_selector_program': ('8bd9bc1422616b7485f6e688c162583e717a4361ff2f83c046cc12bd5eb34f0e',
                                                       'e3143281cc91819a1e2df2570cbc73b6917881529ee7ea99308427980ac2b08e'),
                     '_nested_selector_numerical_members': ('e0d023365a054984effd2ce10ac52fea841599e8cd7c0ac455e662b9df04f8d3',
                                                            '56bfdcf6aea8ca43cb1d870b286de7011a9f9e754492745abba7dfabb9c88e84'),
                     '_nested_selector_program': ('acb3902adfdeb5874567e29c90982142e75cafce9449f0d87aeddad7c6800df4',
                                                  'f408e674ffce9a244eec041b78e32b75d5da12e62b87f268d7ec515ed71afd49'),
                     '_primary_selector_program': (None,
                                                   'adcac0452461f171bcb21e17abfc47a5ba133be2cac7771f2a747365050b8afc'),
                     '_produce_final_shap_component': ('e801949162e35cc0d7c21bc61b1cf840fc1a1c491afaa500505ee9d0786cbbea',
                                                       'a958510d4b2d763cb0ecb5c578dbbfe500c143d35fd8d7a13c5d96d9069a313e'),
                     '_read_final_shap_diagnostic': (None,
                                                     '8b34fb3143173ecf730ef5eb7fc6d2b855adf9ac1e6a094c986363e2fb6ee52c'),
                     '_validate_final_shap_component': ('f5edb7b265c7e9fb85f47081848de6364a693c217bac0bcb4cccd90ab0b2fd96',
                                                        '6758c1fbd819ead2fb3b2bcd188532b2510c28250c2530adf1858ed21931970a'),
                     '_validate_nested_full_selector_development': ('76b469a294e15da348a2d80d57321dfd71434e647eb4848c7b2f9a1be7656722',
                                                                    '0ca802ce61bfa11d66abd86c283fd4283bcccdfdfa3008e582d44c7daa06b257'),
                     '_validate_primary_complex_search_result': ('71ef943ebe7df7a35e9ee7ac4b673671f06250834b12724c70e6d89a5f8b0450',
                                                                 '37b637c27385b2968b440427fc2653cb7cea669d993f8cddb375dbd490db7778'),
                     'compile_nested_full_complex_search_task': ('11bc5c925d29e25766d77d1ee9820d1b6bebbb9b24df9f01c2d1bb84e8f1a362',
                                                                 '3cc6bd092330f7606975efc5bd93572229bfa8c16c077c2977d3d18669738485'),
                     'execute_final_refit_batch': ('a33dfcbe7edc04b2332dfe55b41e6afe11e5ff81ae848de722b4ad0f37a39800',
                                                   '36466eb2f67d743d91395c89da814996bfb15eb64f0a02a35c5ee6fbcad83cdd'),
                     'execute_full_data_selector': ('8bf1c6a447054edb8f56586d352a1d26af08824d1393d5bac266ba7ac9e61bec',
                                                    '28cedd26951a76582636ab497b8594a78d6df35dab5d9e104f63660cf8cbadf1')},
     'padml/f5_sensitivity.py': {'_a12_elastic_configuration': ('be7d79e0df3928d4fbedb913cc8c288a0e353a4aa0b8a608533c2e182feacdf8',
                                                                '2571645e3c5e9ea5c08832111c03f4d07b7f7421c4f2914484d5e06d31a14452'),
                                 '_a12_elastic_reuse': ('df6dde09694bbd413a2f4a5e6cc3eb6bcaa01994461c0c4654008ea02b056411',
                                                        '821b0944d2fa826db81ed9d69db69804805d81c2f82f2351631dcdc6f6a2af9c'),
                                 '_a12_final_reuse_source': ('9e627747507b094fc4895ec4b3bb16fdbb01ca9d1224f2a097e0a14cc80e7aaa',
                                                             '22e9fe8a3fac2efefb1cc7c578a68342d2b7fd2cfa023b64685190fa5e4fa348'),
                                 '_a12_mice_reuse_identity': ('20520ca3f550cc063adaf102a8d045a25d58062d9479eeb09ccbbb15dcf8c8ea',
                                                              'e60c39b7262b7a8c195806b54c5288ab7e4d696a34fb7f5f127e01e877480501'),
                                 '_a12_no_aar_selector_inputs': ('69e90e7b1088797f0b7cc0f4a219e91ee578384ef6839666c60504b7c90e5f81',
                                                                 '696c017e188375c7b7e5cb662f2424d4808db929f231d4a7624fe2addcd96069'),
                                 '_a12_selector_reuse_context': ('5df0e3381377c3837492b9c1382c32dd3fc50582764047449588592b8401235b',
                                                                 'd29aceba3b16378ce144bb9e3c3047bee7d04e643daebc91dd0154ea530f5184'),
                                 '_summarize_a12_elastic_alpha': ('094d24d2502434e736f98566e517da1f719d15458b885c931827bb9136cc5915',
                                                                  '5b6abd637168b54c5967c30589591fafb853cbf0133fd4848bb68f44b6dfbd43')},
     'padml/nested_loco.py': {'_project_outer_development_from_inputs': ('adac0c4fc146de087ebdf16bfc147d84dd938e1724909d60cbfb35ad2ef2dfca',
                                                                         '9922f93439d7338395a0855a990e59c534a512a2aad57aacf161d4aee1bb8319'),
                              '_project_outer_scoring_suffix': ('d9420bfb4065b02a6303700b13e00b75ce825f82de3c518ce28d3e1fc10cfa01',
                                                                'cc55c748089b5cc6181ff5be5695595f62644b72eab709af3956a2a95a1588dd'),
                              '_recompute_fresh_score_from_evidence': ('8b1505ad1fece1a3f84fbb9eefef0d4e9f45046158961d23f667b78656bead11',
                                                                       'd5942f934ef8a54c1e6ffdcde9b97cb9b52ef584a73c452c6b0945bc7074e181'),
                              '_score_fresh_family': ('0a1d8c1e48d5a565e37f1150796e839b62165679da792a65c160aef368faf42a',
                                                      'f674e50b771c27cd527a054b3a8770bf9d69a4d076d71e61351345baef0566e2'),
                              'evaluate_selected_ooc': ('1e387708424f5a0bbf51c9076a768cb3b9a1215154368004fb6224b0fb0b9b61',
                                                        '8573b7160995167f1a21f51805e0e0a87ec3659ef95a4c759034d7a13b48f652'),
                              'project_accepted_training_score': ('15502ecc3ec99d0ab4607db27e95192a897d4fed10e3d5427c03e176c45445fe',
                                                                  'd1fa94d4e439ea7dcc5a9857ca9b58be844fd966461a61ef4e9e06c95e2d9af8'),
                              'project_outer_development_from_accepted': ('58ecd01b61f16e29ef49a4f97966bd7c527181d5ef335c23d272fe1d5a96ade4',
                                                                          'c17e09c18005088ed75d9c4eae16b38eb820e0f8b8b675ac8d1bf456fd144147'),
                              'science_decision_template': ('7fb78766acbf4c4ae30ed93422abd115d6d5e5641f68a53c68f73c7ec44ba729',
                                                            '7cfec3337f8428560cc436cfdc7fff0a919805b863c199abaa1d7821149370b3'),
                              'seal_development_lock': ('aa09bb9c6c9646db489eeb5cef83f92e2010206f61bd2420deb76016db658ff2',
                                                        '6292fdefb9bca019776655b37981d85b44f1cd149564780bc7618bc00d804c54'),
                              'seal_fresh_training_score': ('5e0821285a472814455408edba12fd737aa1f4fbcea3d0352e45de7a39a521ec',
                                                            '38f1efe3e05236e7f68c76fd56114f55e71e5a47529c20701e0ed63e4d24fc10'),
                              'validate_development_lock': ('6c56492aeaf5b73bcde3b1fdd91a366d3538bc80b69c21143ffd0630001c76dc',
                                                            '854b731402314bdd512ba91c0403b2963b7f4cb5e1092dda62bf3becd6e6e46b'),
                              'validate_family_decision': ('6bc71c78047ebc4d58d37ec3b09a2e249d945fe6432619082c6bb84f2f17edad',
                                                           '8cada5a5e6552cd729460bbb08c697ec259ea9cf401f64280e12f51540d1e18a'),
                              'validate_science_decision': ('99900c0f254a4a53fedacddeea288e65c82edf41a27a66ed202861105df69ff5',
                                                            'abf9db362ee729f3b5385ead9ba1d656c1496f07d5e91a6cc8e4c7ef5a0b3601'),
                              'validate_training_score': ('3512c75c5189db26c4ef94b539db7ee72d5e3973aaf555994b2befc0d279879a',
                                                          '75f5336dba603641b51a69c100a787248cd5ecd0668bf3fd71ea010150ea192c')},
     'padml/run.py': {'_f45_unit_predecessor_uncached': ('81f106e9a042fa90067d99db1d0a0dcb1a3be45d22827f997c65dc26e1493034',
                                                         'c3b79df0ed078dd2a1be9c8f04f1628d621b59a531ab94c2fcc2465ea0c21742'),
                      '_validate_f45_resource_revision_uncached': ('3f20cb696a88985d9b19d966cb5cb1dd5ba153fb545675d62d6db5db5e5b87ab',
                                                                   'bb06e188b339e3aa0eb66e269ead360d241365008719bf626af9147d3f880785'),
                      'f45_unit_predecessors': ('c1d6542400a0a57dc64b5d84500286c33ea966657c1e9987482839461ced4b4e',
                                                '2038c20155b4b347df220074fa662bcf1afbb3e2defb258707c8db1ee5edda9b'),
                      'load_f45_run': ('5e83e3cb5eac245a1c11ae2421219041c711b12550ce8eb0673eec7c78a7e15b',
                                       'b5c5efeed6aca5e340a331285fd0ec63a6b0435a4345bbcaf29ccf79ea35f571')},
     'padml/worker.py': {'_f45_aar_reuse_candidates': ('4c8869d891f66dac25a5bc92caef6ae3d5b283621842373de53a91c9c2cc3fd3',
                                                       '1964e4b45701e26538e575a7cdc237b46cf19d961692bfbca83755eeec37e3e3'),
                         '_f45_evaluation': ('27e47b0288648bebc3d0924bc28a7a43f58719ef1886b4f5cebf482ecd00b04e',
                                             '112611efac0f19f2f5a4599de748a316800df874089372bf31ad568334796dbf'),
                         '_f45_full0': ('52fc6542c54ec6b445865dd1552a9cb9b5a91780ef799478f18cabd6cb313e03',
                                        '7c7a767aacd6c00d3d81e874ed5bd3074142f6435b12e55129c5033dc206e14d'),
                         '_f45_primary': ('2fb1276626bf4f9fd1735b16d539721482d32997a2fa6e2853fdde4fbfc9d5e6',
                                          '8d0bbf610afafee024ad3787d9ba682c8c20d404501e090585566f1922399630'),
                         '_f45_resume_evaluation': ('39b4bad14428cd5cdd3fac428906e6d9f5e131c6e44e41a847cfa7d29e713f90',
                                                    'afde21ed8e4a968a8a420875b61e55343757d815c246ddd264400580d3f691e6'),
                         '_f45_score_reuse_candidates': ('cff23bb624e582f28bf0b6bfddba4c54bc561d1f5069d3f8e3ed02c2409470c6',
                                                         '4db88425ac4b2c1939d08f5f93469d82fa222e4fa6ab1ea24a0af7437deba4a8'),
                         'execute_f45': ('73f2ae9329ca13b3d6c76df3b22582ad4faabfb0ed667e9dd8fc5bb3dd327e26',
                                         '1766dc2797aa8b9b622482691752deefa83174853913697c8d69cb2c05c6367b')}}
    for module, definitions in population_qualified.items():
        target = qualified.setdefault(module, {})
        for function, revisions in definitions.items():
            target[function] = tuple(dict.fromkeys((*target.get(function, ()), *revisions)))
    # End exact H36 population and SHAP500 revision.
    # Exact AAR hash/release/admission boundary; scientific consumers are unchanged.
    qualified["padml/f5_sensitivity.py"]["_load_a12_outer_archive"] += ('d3a0e53c582c34ef94fe04b25910fe6e0df6e672c3628178e3517705cbef8669',)
    # Equivalent scalar Breslow arithmetic and post-extraction AAR cache boundary.
    qualified["padml/f2_kernel.py"]["_cox_breslow_log_likelihood"] = (
        'd0a1674fc932ff131370018a7aa3e916d67a1b6529fe2ae3bccbe58671e4aefe',
        '836f9ffe8c3408cc61ff5ddea8b76a39d1585ff6a442944995f629e018c34590')
    qualified["padml/f5_sensitivity.py"]["_load_a12_outer_archive"] += (
        '8f6dc3342eb9dad77b98cfa4f2c9cfaaeda8f3e3802c631a3c970a600ebd9231',)
    qualified["padml/f5_sensitivity.py"]["_a12_elastic_search_program"] += (
        '9b0b86cdf4960c4e10ea09760424cbced60cb022326a5571374e6b7a37222c88',)
    # Current H36 Q donor references; original numerical/member checks remain.
    qualified["padml/f4_compact.py"]["_full_pipeline_q_numerical_members"] += (
        '3a6d201d176a14547ba21b4d2772d0f3e9f9befad259ff19c1e88a643a7b2516',)
    # Closed projected-input extraction before the unchanged readback admission.
    qualified["padml/f5_sensitivity.py"]["_load_a12_projected_outer_inputs"] += (
        'f63f537ecbbd22a94577006f123fed1f9340c66d8a48870c6dd2913a95abf8e3',)
    # H36 AAR inherits its verified PRIMARY selector; F2 recipes/M20 remain original.
    qualified["padml/f5_sensitivity.py"].update({
        '_a12_outer_layout': ('d4946de21363d53958a141109ac58cdd43780573713bbec950ac2416857e2a79', '7600957a90c979b8e539564685e397b481cb80a0e60fbb1cf5d305cc5a148196'),
        'compile_a12_outer_inputs': ('281085a17058cf49f26aa7f4aa7d7040cbe6b080ff79d3463c77ed2bd72e1df7', '9eb51ec3e7913ee6db2134139a830b7f58626639fef0ae483a2e22c4dbdd717e'),
    })
    # Current FULL0 RSF uses the original native producer; legacy tail limits stay scoped.
    qualified["padml/f4.py"]["_run_full_pipeline_r_search_batch"] = (
        '07006508ea684c22f1d9d3dbbcecef5801c962c2a50f61aa94ab21be52884819',
        'c8153f726682cf28dbcf05386121a3badeeddadfc30a5a97214ac7409ba95940',
        'a9447d6983aa33b96f9e9efeb0e06b71719f828852ae5c04a779027db50ecc21')
    # Completed AAR artifact hashes release cache before their direct consumers.
    qualified["padml/f5_sensitivity.py"]["_prepare_a12_final_reuse"] += (
        '2671bbc48f83442461eff9e4fa6dd70c9598ae0c5288c12dee16e79721b61ed4',)
    # Only the reviewed AST revisions qualify; unknown scientific edits remain visible.
    patient_recovery_qualified = {'padml/f5.py': {'_F45ReusedScoreInputs': ('355c49c65ffd000ca86bfe52d9e8a743e61ccc32ddfe8b90c7c34b2e10f62bbf',
                                               '1933e40ba3f65ffb922772506b122f8d0200f4f0c16f531d6b561116f06239a5'),
                     '_f45_full_final_reuse_job': ('a6117e2a0ce4035d5dc906c1dcc76a62520bce2371f9d42235a115eb3fcc41fb',),
                     '_f45_full_shap_checkpoint': ('f6db602afad1ebdb625ed3490d2a5b3dc4f9f28b222bdb0b4ffc0fd3caffa450',
                                                   '128d2c79d01766fbf18e575a01426888ddaa54717fb8399d6c3b158d1f0546cb'),
                     '_f45_previous_shap': ('e3d2d98f05af07eb40ae5b2091bd23947b4c98057c9829f7a2c6b759ea16efc9',),
                     '_f45_primary_final_reuse_job': ('7e55adabcefad66bd5d2365953e4cd6bbdd3127b615074018321ba77674f3fa8',),
                     '_f45_score_reuse_read_job': ('668ee7a7efdd7acbc4f95a2476c8fe8c67dd9e0657ce82b36b140040156fc1c4',),
                     '_f45_shap_dependency_repair': ('b775bcfba80c29633f9f445cad4d3574c0fff6e49caaf1c92b0bcf565def9b6b',),
                     '_full_data_locked_score_program': ('b33ea9f5bcfbed5fba9ce49a966c7fa99c019c5373ef9471427c64a2091ae5f5',
                                                         'efebb7cff0b7a5e8289c31eedb9252a1f685ac79eff86d7f9ca93ef07445fd12'),
                     '_load_or_produce_final_shap_checkpoint': ('8946158e212b3fb2d40287564abd3c412e5d702edc99e3f7ff12cabe528079da',
                                                                'f973e72c8b96464fc8d31c144b4a37539b24c09b06a6dcbfc5e6ee12745d1d66'),
                     '_prepare_f45_full_final_reuse': ('090561abd0dae9dc127280f62d3f2588d9063a3c7c7809975d52266f816a83e0',
                                                       '9c5e979e2b09cd4ac13eb4bcf3431319a29083032906a8093283e8b5f4cc1313'),
                     '_prepare_f45_primary_final_reuse': ('5393c2c99b4d3a258c43df5f68edba3fc6d2e847bdd5dd9b625d6e75163e9a32',
                                                          '656e83fb4d6bb715b7b10ccc7f76c63063889b887d56941d606a09b5f02137fe'),
                     '_prepare_f45_score_reuse': ('dec754520b62fbea477361295156710881c989867c33407cf4aecb010de00bad',
                                                  '401c9851de11a67439a1b12bc51c7c3000a579be394221c5a27003974c399b66'),
                     '_produce_final_shap_component': ('a958510d4b2d763cb0ecb5c578dbbfe500c143d35fd8d7a13c5d96d9069a313e',
                                                       '38600f1c15d9d1ddfeb3a1e5c072a1fd545d7a1a89de3b9503607a77d637b824'),
                     '_read_final_shap_diagnostic': ('8b34fb3143173ecf730ef5eb7fc6d2b855adf9ac1e6a094c986363e2fb6ee52c',
                                                     '849fdc771aa808dafc1376abd5db767c4df9df52e98562aa608930952108b82e'),
                     '_validate_final_shap_component': ('6758c1fbd819ead2fb3b2bcd188532b2510c28250c2530adf1858ed21931970a',
                                                        '00386c0f04bcd961a8dad935681005fbf251554827adfd078e76b7e73d176e01'),
                     'execute_final_refit_batch': ('36466eb2f67d743d91395c89da814996bfb15eb64f0a02a35c5ee6fbcad83cdd',
                                                   '1d52fee90b067935eeb3b5fd6efbf027b155329f571ab61edfb3a9ec77e41ee2')},
     'padml/f5_sensitivity.py': {'_a12_final_reuse_job': ('6242dd196885c11f0f62cdfcc08b151617cc4e1d04ae0b521b4cac97849a2161',),
                                 '_prepare_a12_final_reuse': ('2671bbc48f83442461eff9e4fa6dd70c9598ae0c5288c12dee16e79721b61ed4',
                                                              '34a3f6f73eafc1830bb8744c99eee0ebc999f34d9ee9644d2fac89a8da2de1ef')},
     'padml/runtime.py': {'_bounded_ordered_spawn': ('e439a87ff51a30958b7be8e626d241213d1dd86b97bebef8485c7905c40d5094',
                                                     '0d503cfd581857b0fa5331ddc587804047b2d4529592b5b6d8fe2296d574928e'),
                          '_spawn_task_entry': ('0a22bfd5e4c4fdcd0e2b6b482926fd1ea177b6484357558d3b2d1730e5411261',
                                                'd4eb40ab6d42afb915d83a960acf88701d8327145a3beb89e3fd18cb677070b4')}}
    for module, definitions in patient_recovery_qualified.items():
        target = qualified.setdefault(module, {})
        for function, revisions in definitions.items():
            target[function] = tuple(dict.fromkeys((*target.get(function, ()), *revisions)))
    # BEGIN EXACT OPTIMISM DEFINITIONS
    optimism_qualified = {'padml/f4.py': {'_f45_o_fit_rows': (None, 'cff0304ee95ef09226c72296678f0b4c63e7a6238f5a003c40879a5f7051d90b'),
                 '_f45_optimism_csv': (None, 'a665880301d20018f891b0083b0e5b6f11c338f4a03c8cc1fe71a5402ff0f00e'),
                 '_f45_optimism_json': (None, '09206882ecef2595ba4b2d48e8d474412c34cedf9fb44e52d77abf7b5ef0d268'),
                 '_f45_optimism_mean': (None, 'f5f848c9f0d3277bc6f47b204bc2b91813a65addd5605674036f6b60ce53afed'),
                 '_f45_optimism_member': (None, '19c37f820efd1160a88a8da573e2d048e085c8f737ec7fed207b80cc53fc1590'),
                 '_f45_optimism_metrics': (None, '5f3b6aa635b8d38c850f5db257a237f016e1af2cfa93cc8959ad8763aeb79cdb'),
                 '_f45_optimism_oof': (None, '01441a07fc9007be7a3f6c5bd789a9f721af3afe9ccd715bc3b7ff3724d1a66b'),
                 '_f45_optimism_primary_apparent': (None,
                                                    '3d1e6d66f092f25de7720c70e7bcef46541ffc8055bd19199d5015461e393f33'),
                 '_f45_read_selection_replicate': (None,
                                                   'b038678998553e2a89c9dd4d0a94f67ae9002de3548a2169a4d2a9c6af21589f'),
                 '_f45_selection_identity': (None, 'ce32ffba3dd79b7fb9cfb8cc7f5ce5c91caa3cf696a9a9adee9ab0b2b0858bec'),
                 '_f45_selection_replicate': (None, 'aa8395af044b5f939d29dbac226ef5cb22b57c83c0b3ab8f5fa2769ed91513e2'),
                 '_metric_kernel_compatible': ('248779e8ae0a982d314ca3b3837fc8a301e2d89cf5274f3335ba339620abf3e2',
                                               'eda9379fa4633fc4f5b26eb515bd62388c06003b22e1f4e16b1a846f05ed96dc'),
                 'bootstrap_draws': ('ac2f0b727208a7f364aecfc4b3829189f2f1da15df544e5aa94c607fd21cd3ba',
                                     '615a900048f8e143d985cb24c82ea484f68715139f3e1aa6baf77e29d0fec606'),
                 'f45_optimism_contract': (None, '72c86bdf0d33cfe936f40b50fc997faf43fc38d5c206df35747e32f409d8f0a0'),
                 'load_f45_optimism_inputs': (None, '86f2e35df209f5065ff6dcc43ebb9823e720e27b813db836da5ca22e85e36e43'),
                 'load_f45_postprocess': (None, 'a7afaa4e6f2bb9e092e222b391df431652fe5a88721d979b2587ae9db47babe4'),
                 'load_f45_selection': (None, 'f37cd6842e38632a0b7cfef77aee97d65fb7722d1af97a8308e0224dfc4f1f9f'),
                 'prepare_f45_optimism_inputs': (None,
                                                 '19a93e6b09e1ee3d6b7208de99c38bde2561b56e9fd528e0524c9481b17ed455'),
                 'run_f45_postprocess': (None, '8aba98d8460806044d1c9918be00d680c3e3af5221d9c6b120e0c0b8151bcc30'),
                 'run_f45_selection': (None, '79c6189fa83df850729df3f0075e299786264472eaaee2374c6f33d0036e179d')},
 'padml/f5.py': {'diagnose_mi': ('fe6e29526ea364e504f6e6a929aa0d170b83172172cbfd29a1c5424fdc489613',
                                 '8ea8978eebb6338c6129b006894701ec140bccac3e6d1177bb5b4b656ebd8846')},
 'padml/nested_loco.py': {'_rank_training_families': (None,
                                                      '6e2d930b5797d193ab9ce5c28784f21aa39d31ea028d3bc0ec2d24474cbf40bf'),
                          'select_training_family': ('0f39fef8e3b44ce07af2647c9b6885857e79d953ab98ff4988ce3e75fc44945f',
                                                     '145bca5c841e96de29495c0617b27566fd0de504cd5daf395802c19e92dde15d')},
 'padml/run.py': {'_f45_unit_predecessor_uncached': ('c3b79df0ed078dd2a1be9c8f04f1628d621b59a531ab94c2fcc2465ea0c21742',
                                                     'f6db14e5a7dbbf103f1e97e729cd07710d66c1899691dc9e7e1d963d75e3f397'),
                  '_validate_f45_resource_revision_uncached': ('bb06e188b339e3aa0eb66e269ead360d241365008719bf626af9147d3f880785',
                                                               '88fa0e3612486632b9f7033d1e904a6395d2ce33a075b81bf93a1cc70254ba03'),
                  'f45_ready_assignments': ('cdd4301b6b62b3507124446537b3dd5942ab8aac50178ebb82030183bd051a81',
                                            'df0f8ce986630e392ab5da6e05f3662f7906401aa66dbe25f682675de53ef79c'),
                  'f45_unit_predecessors': ('b9fc4f15f4c5f8ac72df0a7ea04afcb4033df33b87431b24d7213a1e0cd0d737',
                                            '6a2787a836f93e5ba067f5faf839291923c815d15ff404131f5b5008f4a5b29c')},
 'padml/worker.py': {'execute_f45': ('1766dc2797aa8b9b622482691752deefa83174853913697c8d69cb2c05c6367b',
                                     'df7ae27e116c59569f8b58fac5867a6beedef112ad1f85050099a4b553eff40b'),
                     'main': ('3be1f64f056d97df7d2dbaff9a29489e01abd8e2fd5698d80b5b646dc77433f3',
                              '2173f08a4ab94afd2d8ce2b9fde5279ad91b48da0ae927ff246aa16978ccf18e')}}
    for module, definitions in optimism_qualified.items():
        target = qualified.setdefault(module, {})
        for function, revisions in definitions.items():
            target[function] = tuple(dict.fromkeys((*target.get(function, ()), *revisions)))
    # END EXACT OPTIMISM DEFINITIONS
    # BEGIN EXACT COMPACT EVALUATION DEFINITIONS
    compact_evaluation_qualified = {'padml/f4.py': {'_decision_curve_values': (None, '491d88f528a49588437eae85e3654f2aec5eb8e8c50c286c0579bad35219d13f'),
                 '_prediction_error_values': (None, '28b1e7d0f1c1a5e3197390832ec8184b3463dacc507c97d1435400842b2fc384'),
                 '_prediction_metrics': (None, 'ee855581cbc4844cf7bc6c04204564e23087e0bf259888271c63d4da2c4430f5'),
                 'decision_curve': ('cbed67c7fd6d2559c4e201d0465a54055029cfd399b667ebab48234830c2f3c8',
                                    'cc304f21563795f5d0a15dfd782514e3c5d753edbb9d6ca13e2d3d3c0894dcc2'),
                 'evaluate_predictions': ('3daa83ef651b210a2115683189eb909caab56d993f86af783f155999594d03a9',
                                          '34dc0a2fe269a99e33c26def95fd05a94c019ab7609ca6c598ea72bd4d30d069'),
                 'prediction_error': ('c0cc4788e2a1be7f5ebe0debb5442e85e862ab0b8ce104a300c6c33ca532b33b',
                                      '79973475b2a4ba08ab47394821c5cee4076f0cfea8b63fb9b582ceb66ee9f79e')},
 'padml/f4_compact.py': {'_full_pipeline_q_numerical_members': ('3a6d201d176a14547ba21b4d2772d0f3e9f9befad259ff19c1e88a643a7b2516',
                                                                '3a54db7cf670292f4a9290f6e16e92bf01e1694b86f0315008bc6d02af2349ce')},
 'padml/f5.py': {'_consume_final_parameter_source': ('7674206cc6131ede05fb2f69e5c67220f88d61c42f571aeda284cd821b4f2f4d',
                                                     'c93a513ba07598df4d1738fa94e474812049f990dccf0e8ae6c7cf66368eb000'),
                 '_current_q_task_batch': ('65bc2c48d81c2d528c1187bccb5581c35cb28a78302c28d30d42acfac36a143d',
                                           'd8eef0b41e3c643d2f3a49ab3ce752efc247894ce7b38233341f97cd4dd874f1'),
                 '_full_data_locked_score_program': ('efebb7cff0b7a5e8289c31eedb9252a1f685ac79eff86d7f9ca93ef07445fd12',
                                                     'a72bf27b1362e1bfa01380ce63c36c1a2839b297bd9b1c0da09feaf522db9a0c'),
                 '_materialize_final_search_inputs': ('231249c69b67c0c72974ceac93d958927ee905f3a9a1d436088be0cc4581ddd0',
                                                      '70add7b83a46100fb7c00e4500c31e73839e8929e07667ab9e4721cf7a8c1b7f'),
                 '_prepare_f45_full_final_reuse': ('9c5e979e2b09cd4ac13eb4bcf3431319a29083032906a8093283e8b5f4cc1313',
                                                   'f0d53b26f427189f0b8adfa89e08f49a27f3d12c0eaa585494de1af634f348b5'),
                 '_prepare_f45_primary_final_reuse': ('656e83fb4d6bb715b7b10ccc7f76c63063889b887d56941d606a09b5f02137fe',
                                                      'f3c0c509df08ec78b6d3e0cf7d719cd253196b12e5eebe5f3564cc01f62f0f19'),
                 '_prepare_f45_score_reuse': ('401c9851de11a67439a1b12bc51c7c3000a579be394221c5a27003974c399b66',
                                              '04d460073fe0082868f2116414802737fe39bd363c262790b7b5e78e59a5a9e0')},
 'padml/f5_sensitivity.py': {'_a12_bootstrap_replicate': ('4d5d0cce7d52c0752c2d4f8ae128af62be36bf53d87d715c724f98ce2b335565',
                                                          'c1cfd3ae21cf34a41724434eccb0cebbedd2225e14101a225f643053ce09a8b9',
                                                          '49b68fe9db925867c7a4ae201de53e0633d83d97201cb2370648edde2083a942'),
                             '_a12_compatible_binding': (None,
                                                         '23c233b182aa844384e110fffdcda1bfa9ead288978ad768a7cd734b485eb1ae'),
                             '_a12_native_summary': ('21e9a9aafb2259997ea8e95bb9e90f4706d6283736de58fb4609131c2c2c0012',
                                                     '5d66de9a85d15aa5808cf4ce2457469b834c8925399241a82a44c899c4d1101f'),
                             '_a12_outer_archive_record': ('50db5a309da8af1c61c175d80e671170099d3719f804ebff59dea1cbd3156272',
                                                           '2bf268b93f32c76226664d8421cb12143b1b88eba81e9e45c2583d5b9376cdca'),
                             '_a12_outer_searches': ('3759cd580dea5e23add630019559816fc0fea87090393da6468b52770d7f9f90',
                                                     '3217f1bb0a1da6d3754f7db033b5911b40a0e0f800ffcabb7ab96be8321a43ea'),
                             '_execute_and_replay_a12_bootstrap_replicate': ('c3a55dee2c3983d53fdba3cafde7dafb2a08fd62e0f89362ade448886bbe2bff',
                                                                             'dfe7ecbf76fce9941cd009d5041f9a61f9185505a46b4aaee9226b007e23db27'),
                             '_f45_evaluation_completed_outer': (None,
                                                                 'd15ecc87856282faf825a77944f82e7e282a53b94e091f4ce704cf87a83ccc55'),
                             '_f45_evaluation_context': (None,
                                                         'cd22f66f6bf8aa347978028f495a888c078779c2f8a77d9e07ecbacfac866563'),
                             '_f45_evaluation_load_job': (None,
                                                          '64030a0c2c8f4807679e3c29cdf0487d97956f91dd137dcd812a75234fc2426a'),
                             '_f45_evaluation_nested_index': (None,
                                                              '0fde38918c28dcb3b9ce9c6aff8284567ba62a4a0cfcd9e8054c2ed20c42af4c'),
                             '_f45_evaluation_numbers': (None,
                                                         '14c7710138c56944b20432d52f9c4559c87220925d85174e3979093fa2db56ab',
                                                         'e041b620f7842889616161083dff66912881701828684157df6983db5ec0cd52'),
                             '_f45_evaluation_receipt': (None,
                                                         '046413c6f0090745227d12621241ee72a464f0cddbeb7e1d815df3bd34be0c98'),
                             '_f45_evaluation_restore_member': (None,
                                                                '72929583ed204601102fe36686eae2614ac09e29dcce5d5ab5cc8cae704ac149'),
                             '_f45_evaluation_source_job': (None,
                                                            '404297430e4f86d0764a711f03084055ad344b51503625495483e86f633a39c0'),
                             '_load_a12_projected_outer_inputs': ('f63f537ecbbd22a94577006f123fed1f9340c66d8a48870c6dd2913a95abf8e3',
                                                                  'b53ef5cfd0723dc5f027600141581cd568a181aa9cca248bceade53edd76a0d1'),
                             '_materialize_a12_projected_branches': ('117622aca0eebca13d942b5c3cd1a594c918befd40f7772d562f80ed4af31083',
                                                                     '802f3538db12911028671c402b71836e27cb582bc54d72dc34739f3ab978647f'),
                             '_prepare_a12_final_reuse': ('34a3f6f73eafc1830bb8744c99eee0ebc999f34d9ee9644d2fac89a8da2de1ef',
                                                          '15a8b89ae96af7e674e1026ae3d5bf758f227c0ed9e434096d6c4bc6eab7f0e9'),
                             '_read_a12_bootstrap_shard': ('237f01cb78b632d74f4f03133d2f3315dcacafde2b23d6cb3bf43a36b5e6e2c3',
                                                           'c4306346a089630ee341740eede573c89305769daa58e78a2fb7aa78a9be0293'),
                             '_replay_a12_bootstrap_plan': ('f8cc991bccf27742eb6a46c7ef084f4b578bcf6b277839f33513033bb8043a9d',
                                                            '1017de1bd4f1ee328ec25532aef8961159c716ab47f70455fc4995df406a30fa'),
                             '_replay_a12_bootstrap_replicate': ('7b7cb846cd7a28dc9be688eaccf2eab9c0bbf959e4bb1df33b1cf43f2995ba94',
                                                                 '96cd096a823dff1d60220f17a2db5152a613cc62bd2967db0d3902dea98c9643',
                                                                 'f4ba112feb11f3e2c649ead1181a55cc2160af94b6806c776dee03ce45567acc'),
                             '_replay_a12_evaluation': ('3ca154d147372ed823b32fb7565f4e4e81ab2b8b8369f046be2042e6ea62c6ee',
                                                        '3590dac0b5f2b8af1cbfef0b3a0086ffd3cbf64ac443e0d771a7e9c62b7b0ae0',
                                                        'a2117cefaea83557448301ec13a7ae62c01ee081c336bf58f8a0d0e44b404375'),
                             '_validate_a12_native_evaluation': ('e15943f8715fbee66a79c67817585471fab4dd5603313c882aaee8f04653acef',
                                                                 'c15b49dbf33703c72e4798427adb11086618b2d2f93a563b95a515bc317209ec'),
                             'evaluate_a12_incremental_value': ('2179d15f33f262726e081836fd436933836377e1ce98704176a46dc5d306ac0c',
                                                                'ba83810623f0a3f833b169352500a200fd330132c5d9d07074a3e7aeda250620',
                                                                'd69472987ccfd0b0ba2366964da8fc7d3a333887eacf47e5b67a27d15d223f90'),
                             'execute_f45_compact_evaluation': (None,
                                                                '76996a665d3bbd7833cb16ea33ff17d2beed2708829a7c089f916043d47a1af6'),
                             'load_f45_evaluation': (None,
                                                     '62c6fa142d0f6bfe2e64fd3706fb442427efe601caade176af4ae257c9473095'),
                             'load_f45_evaluation_source': (None,
                                                            '3376d043500436ac77c4aeafe320c627f64edf3066fcb2e1de1e5daf9cdeff80'),
                             'prepare_f45_evaluation': (None,
                                                        '3a21e6d31d416eae56375120975b367a6c8f7ddf3e781e05e580e8ccbb7797f1',
                                                        'a3ccb798eea509cd83c9dd6887ef1f5e9e48959a59d57d9c3ddaa76e8875a1a9',
                                                        '766d3e2e3d50b0f8f3c7f2af8b4409d097e40c34e52fbaa53fcf6a2ee4b38647'),
                             'prepare_f45_evaluation_source': (None,
                                                               '91ba8739d1022fa70629d60f3484e9d49dac1b8aa4b9210d9d64eb143f6dc33e'),
                             'replay_f45_compact_evaluation': (None,
                                                               'c0b39938a0391cc7dd7574c474ee13f88cc4ee68822794d91676d28432c8b4f3')},
 'padml/run.py': {'_f45_compatible_retention_budgets': (None,
                                                        'c7645aef1ce7c966c9207502705f0b51522dbba1b2bbc1a764fb90b632748a88'),
                  '_f45_unit_predecessor_uncached': ('f6db14e5a7dbbf103f1e97e729cd07710d66c1899691dc9e7e1d963d75e3f397',
                                                     'c32762e31b65f22a23117ce21eb7d78dd4ad91c239b767820139963de2683064'),
                  '_validate_f45_resource_revision_uncached': ('88fa0e3612486632b9f7033d1e904a6395d2ce33a075b81bf93a1cc70254ba03',
                                                               '54614b23e1b9c3fd5e5b5f6ce47ee7845ec521e72563db8abd38e55fc1808cc7'),
                  'f45_unit_predecessors': ('6a2787a836f93e5ba067f5faf839291923c815d15ff404131f5b5008f4a5b29c',
                                            'b49d3b9a12462b0ca29385082a39aa1629f6bd68dfea65dbcfddce1c355beed6',
                                            'de5c9736b8daad8f8cde7d0b17c687400f668958dadd38492da6d1a342a592e6',
                                            '26b6fbe5473de4aaa3a558f7c646dea2ae6423988594576d5ef30972bd9919d1',
                                            'acd5a54a522f8cf115407c783cf19378dd21e300db94cb6914ea89d32712b75e'),
                  'prepare_f45_run': ('b3ae4a93141696d5e009d7446b1b5130f8543557a84633d95b7425cfba86db98',
                                      '93469b83c6ef6ee6335a0954b1ff797e20b745595d60a22115de85976be345ae')},
 'padml/runtime.py': {'_cgroup_memory_headrooms': ('91fa38aafe42f961e342ce1ecda7d994f9401db83de265d285de4af1c0a1f6b4',
                                                   '9af443193b9f9ded9581655062ec074093b0645fe6240fb6396b515b5e6592b0'),
                      '_readback_ordered': ('3fe87fb977f0195ea7dabb6dd91a16f63a39f4f4df42b8837a08e70c5ae246cf',
                                            'ca7ddd208805870c1128e644540ff1f7743a661df0a8d585879f588e669d7a9f'),
                      '_release_f45_cumulative_files': ('e831566f1ab8b4be2a6b2e58a5d243fe993ed14277bfbdfd400ca382aedda8ef',
                                                        '12273ae99cae6b15d64075c4711a3483785bad113eefa58ae66de8f24f7c34f5'),
                      'release_f45_cumulative_files': ('07f783396d5dfb2987988039f4a6c992325def66e7951e83ff4f45febda72246',
                                                       '88cb09a19490a03034eacf61d9ce15ca7283a1b46ed958788144b4af51f3fdfc')},
 'padml/worker.py': {'_f45_evaluation': ('112611efac0f19f2f5a4599de748a316800df874089372bf31ad568334796dbf',
                                         '178fd39a611873f1b3bc8acaa3aabc99c77657966d50cefc577005453b393d8e'),
                     '_f45_file_pins': ('8af5a4f3dd85fca177a6165b0e05b2ccadf4413e3d077fa85768f54023a57b3b',
                                        '8f61e7bff0cf2e50c40ab5ab851b56d065450a93b5df4c940f2f8f8305c2d4d2'),
                     '_f45_full0_score_archive': ('8a476dbce4ec0fb48b865795fa0f95b3f6fb0edfc0fbb6b0c4c90a7916e73263',
                                                  'c192b11a0d4565413af8fa9b2762538d453c8e1264a00ed9bc9f85fbc8636fe2'),
                     '_f45_release': ('a1ab7ae13a39d419f8ebcb9a292c47f1f04d9079cfbb1a0c677ef80ee2ec8cee',
                                      'cb645e2562b100585ebc85b15555f4cf04b74862b1a5d62123205a18582df5a4'),
                     'execute_f45': ('df7ae27e116c59569f8b58fac5867a6beedef112ad1f85050099a4b553eff40b',
                                     'f471ec86bb160db951c2b22c260c7d5f812a5009a0c8c2e1753c7bea9bdade1e')}}
    for module, definitions in compact_evaluation_qualified.items():
        target = qualified.setdefault(module, {})
        for function, revisions in definitions.items():
            target[function] = tuple(dict.fromkeys((*target.get(function, ()), *revisions)))
    # END EXACT COMPACT EVALUATION DEFINITIONS
    if name == "padml/runtime.py":
        tree.body = [node for node in tree.body if not (isinstance(node, ast.Assign)
            and sha256_bytes(ast.dump(node, include_attributes=False).encode())
            == '00f65eb27bacfb40428b9febd5d0d3b279feed83ed7c3237e4fb1924ba8ffdcc')]
    def unchanged_or_qualified(node):
        if not isinstance(node, (ast.FunctionDef, ast.ClassDef)) or node.name not in qualified.get(name, {}):
            return True
        return sha256_bytes(ast.dump(node, include_attributes=False).encode()) not in qualified[name][node.name]
    tree.body = [node for node in tree.body if unchanged_or_qualified(node)]
    return tree


_F45_SOURCE_VALIDATION_LOCK = RLock()


def _f45_cached_source_validation(kind, key, paths, compute):
    """Bounded compact engineering conclusions; never cache numerical data."""
    with _F45_SOURCE_VALIDATION_LOCK:
        from .f4 import F45_SOURCE_MEMBERS
        root = Path(__file__).resolve(strict=True).parent.parent
        def fingerprint(path):
            path = Path(path)
            value = path.stat()
            link = path.lstat()
            return (str(path), str(path.resolve(strict=True)), link.st_dev, link.st_ino,
                    link.st_mode, link.st_ctime_ns, value.st_dev, value.st_ino,
                    value.st_mode, value.st_size, value.st_mtime_ns, value.st_ctime_ns)
        generation = (os.getpid(), os.environ.get("PADML_F45_RUN_PATH"),
            tuple(fingerprint(root / name) for name in F45_SOURCE_MEMBERS),
            id(_f45_aar_binding_ast), id(_f45_unit_predecessor_uncached),
            id(_validate_f45_resource_revision_uncached), id(type(root).read_bytes))
        state = getattr(_f45_cached_source_validation, "_state", None)
        if state is None or state["generation"] != generation:
            state = {"generation": generation, "entries": {}, "bytes": 0}
            _f45_cached_source_validation._state = state
        watched = tuple(fingerprint(path) for path in paths)
        token = (kind, sha256_bytes(canonical_json_bytes(key)), watched)
        entries = state["entries"]
        raw = entries.pop(token, None)
        if raw is not None:
            entries[token] = raw
            return strict_json_bytes(raw)
        result = compute()
        _require(watched == tuple(fingerprint(path) for path in paths)
            and generation[2] == tuple(fingerprint(root / name) for name in F45_SOURCE_MEMBERS),
            "F45_SOURCE_VALIDATION_CHANGED_DURING_READ")
        raw = canonical_json_bytes(result)
        if len(raw) <= 1024**2:
            while entries and (len(entries) >= 256 or state["bytes"] + len(raw) > 8 * 1024**2):
                state["bytes"] -= len(entries.pop(next(iter(entries))))
            entries[token] = raw
            state["bytes"] += len(raw)
        return strict_json_bytes(raw)


def _f45_source_structure(raw, name, removed, *, resource_revision=False):
    """Reuse only a digest of the reviewed normalized AST, never a large AST."""
    import ast
    def compute():
        tree = _f45_aar_binding_ast(raw, name)
        if resource_revision and name == "padml/f4.py":
            before = ast.parse('decision.get("twelve_month_development") == '
                'nested._twelve_month_development_contract()', mode="eval").body
            after = ast.parse('decision.get("four_horizon_development") == '
                'nested.four_horizon_contract()', mode="eval").body
            class ScoringContractOnly(ast.NodeTransformer):
                def visit_Compare(self, node):
                    if ast.dump(node, include_attributes=False) == ast.dump(after, include_attributes=False):
                        return before
                    return self.generic_visit(node)
            for node in tree.body:
                if isinstance(node, ast.FunctionDef) and node.name == "_prepare_o_fit_partition":
                    ScoringContractOnly().visit(node)
        tree.body = [node for node in tree.body
            if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) or node.name not in removed]
        return sha256_bytes(ast.dump(tree, include_attributes=False).encode())
    return _f45_cached_source_validation("normalized-source", {
        "sha256": sha256_bytes(raw), "member": name, "removed": sorted(removed),
        "resource_revision": resource_revision}, (), compute)


def _f45_predecessor_paths(pin):
    paths = tuple(Path(pin[name]) for name in ("run_path", "source_path"))
    _require(all(path.is_absolute() for path in paths), "F45_UNIT_PREDECESSOR_BYTES_DRIFT")
    if os.environ.get("PADML_ARCHIVE_INDEX"):
        # Use the archive's original pinned bytes, never rewrite scientific
        # manifests or depend on the former Linux /var/tmp installation.
        index = Path(os.environ["PADML_ARCHIVE_INDEX"])
        _require(index.is_absolute() and index.is_file() and not index.is_symlink(),
                 "F45_ARCHIVE_PREDECESSOR_INDEX_INVALID")
        for name in ("run_sha256", "source_sha256"):
            validate_sha256(pin[name], name)
        paths = tuple(index.parent / "objects" / pin[name]
                      for name in ("run_sha256", "source_sha256"))
        _require(all(path.resolve().is_relative_to(index.parent.resolve()) for path in paths),
                 "F45_ARCHIVE_PREDECESSOR_PATH_INVALID")
    return paths


def f45_unit_predecessor(value: Mapping[str, Any]) -> dict[str, Any] | None:
    pin = value.get("unit_predecessor")
    if pin is None:
        return None
    _require(set(pin) == {"run_path", "run_sha256", "source_path", "source_sha256"},
             "F45_UNIT_PREDECESSOR_INVALID")
    paths = _f45_predecessor_paths(pin)
    _require(all(path.is_file() and not path.is_symlink() for path in paths),
             "F45_UNIT_PREDECESSOR_BYTES_DRIFT")
    return _f45_cached_source_validation("unit-predecessor", value,
        paths,
        lambda: _f45_unit_predecessor_uncached(value))


def _f45_compatible_retention_budgets(previous: Mapping[str, Any], current: Mapping[str, Any]) -> bool:
    """Only the measured four-timepoint archive-cap correction is operational."""
    key = "retained_bytes_per_replicate"
    old, new = previous.get(key), current.get(key)
    return (type(old) is int and type(new) is int and old > 0 and new > 0
        and (old == new or (old, new) == (8 * 1024**2, 16 * 1024**2))
        and canonical_json_bytes({k: v for k, v in previous.items() if k != key})
            == canonical_json_bytes({k: v for k, v in current.items() if k != key}))


def _f45_integrated_source_pair(name, old, new):
    """Only this reviewed same-batch repair admits the preceding executor."""
    import ast
    def digest(raw):
        if name == "padml/run.py":
            tree = ast.parse(raw)
            lines = raw.splitlines(keepends=True)
            for node in reversed(tree.body):
                if isinstance(node, ast.FunctionDef) and node.name == "_f45_integrated_source_pair":
                    del lines[node.lineno - 1:node.end_lineno]
            # AST only locates the self-referential table. Its dump format
            # differs between Python 3.12 and 3.13; all other bytes stay exact.
            raw = b"".join(lines)
        return sha256_bytes(raw)
    # Filled from the final reviewed byte pairs; run.py excludes only this
    # digest table's own function to avoid a self-referential hash.
    reviewed = {'@environment': [('a4db2c27d786a7a3ba9194ecdd065b245a78fae5ec982ec71f2f697dd80bd14b',
                   'ddcced898a068358f66d6d0ff7ac5da39fcb89c655542a452dbb21432668d2b3')],
 'AGENTS.md': [('dd6d8a55befdba8b291b48362f2475d3fd00cd669b77a88832925f6998e2a4a7',
                '04eeb316a0360f87efe91cbb29b35cc97131ea1e024b63237c85ecb1b8fbd905'),
               ('5ada32a510a6a5be0885bc1d517a7e06f67372cd317d18e51bac9e2b28278005',
                '04eeb316a0360f87efe91cbb29b35cc97131ea1e024b63237c85ecb1b8fbd905'),
               ('1738811d9100acf092c3f5686bc34341747b5b8892d5e9ab7b16a5d632094cb8',
                '04eeb316a0360f87efe91cbb29b35cc97131ea1e024b63237c85ecb1b8fbd905'),
               ('58aaf913044a82b7c57c7994dff203dc11a8f343f73f41099211c8962952e382',
                '04eeb316a0360f87efe91cbb29b35cc97131ea1e024b63237c85ecb1b8fbd905'),
               ('5fabe691493580a4ed58a2dff69ed0781cdb024579945e7cccb1f3690139848e',
                '04eeb316a0360f87efe91cbb29b35cc97131ea1e024b63237c85ecb1b8fbd905'),
               ('5d61a2997b90859edbff352e3dde2395ef585082b47e220d73e42a61d7069777',
                '04eeb316a0360f87efe91cbb29b35cc97131ea1e024b63237c85ecb1b8fbd905'),
               ('d0f4aba31fd6efd01cfb2ff3706ea43086b0f6941894324c0a32e051ef87e8af',
                '04eeb316a0360f87efe91cbb29b35cc97131ea1e024b63237c85ecb1b8fbd905'),
               ('5da7fc9efd185cfbc2d62db2e42e1f3191e78e05a8c8cb4ded3756dc555cfb94',
                '04eeb316a0360f87efe91cbb29b35cc97131ea1e024b63237c85ecb1b8fbd905'),
               ('427c00e4e7f53d4f59315bc6ad960a2702e6fa9aa83e9b2db264171dcd32109e',
                '04eeb316a0360f87efe91cbb29b35cc97131ea1e024b63237c85ecb1b8fbd905'),
               ('e925c002274c0f1d24cf606db0d7202a6a77a1101b7880444fda367488b4ee7a',
                '04eeb316a0360f87efe91cbb29b35cc97131ea1e024b63237c85ecb1b8fbd905'),
               ('c842859e562193c6a192872e28c0954a9367975e221eac074c1cd6405115fb05',
                '04eeb316a0360f87efe91cbb29b35cc97131ea1e024b63237c85ecb1b8fbd905'),
               ('0ff3a3c3ddae5665c540233b9c4116a1365d93854f39d284439e5580f83b2c92',
                '04eeb316a0360f87efe91cbb29b35cc97131ea1e024b63237c85ecb1b8fbd905'),
               ('bd716b65316a0077e211c4378d3a71f49ed518782921508f2b3d9688f6008b01',
                '04eeb316a0360f87efe91cbb29b35cc97131ea1e024b63237c85ecb1b8fbd905'),
               ('fadea3cb47af33905840b7819597dc561e6246c7a85b50a1615cded878bc3e2d',
                '04eeb316a0360f87efe91cbb29b35cc97131ea1e024b63237c85ecb1b8fbd905'),
               ('76e96fe7a418a106dec7937c439abd03f9d93aab2bf0c5c1566ab23d656abe65',
                '04eeb316a0360f87efe91cbb29b35cc97131ea1e024b63237c85ecb1b8fbd905'),
               ('7f9454a89547604172e1c9a785dc9de40d57a4ef5867a088bd00a1ebc82df59e',
                '04eeb316a0360f87efe91cbb29b35cc97131ea1e024b63237c85ecb1b8fbd905'),
               ('6f3db7826019fd23e70047d5fc97a82c21c4f2ddf69fa5142b1b15a2d9fa8b8f',
                '04eeb316a0360f87efe91cbb29b35cc97131ea1e024b63237c85ecb1b8fbd905'),
               ('04eeb316a0360f87efe91cbb29b35cc97131ea1e024b63237c85ecb1b8fbd905',
                '1cf5045d7a22e2bfe6b39139e112e048f7db19d013d1e3f6fb9337f23d7d7832'),
               ('dd6d8a55befdba8b291b48362f2475d3fd00cd669b77a88832925f6998e2a4a7',
                '1cf5045d7a22e2bfe6b39139e112e048f7db19d013d1e3f6fb9337f23d7d7832'),
               ('5ada32a510a6a5be0885bc1d517a7e06f67372cd317d18e51bac9e2b28278005',
                '1cf5045d7a22e2bfe6b39139e112e048f7db19d013d1e3f6fb9337f23d7d7832'),
               ('1738811d9100acf092c3f5686bc34341747b5b8892d5e9ab7b16a5d632094cb8',
                '1cf5045d7a22e2bfe6b39139e112e048f7db19d013d1e3f6fb9337f23d7d7832'),
               ('58aaf913044a82b7c57c7994dff203dc11a8f343f73f41099211c8962952e382',
                '1cf5045d7a22e2bfe6b39139e112e048f7db19d013d1e3f6fb9337f23d7d7832'),
               ('5fabe691493580a4ed58a2dff69ed0781cdb024579945e7cccb1f3690139848e',
                '1cf5045d7a22e2bfe6b39139e112e048f7db19d013d1e3f6fb9337f23d7d7832'),
               ('5d61a2997b90859edbff352e3dde2395ef585082b47e220d73e42a61d7069777',
                '1cf5045d7a22e2bfe6b39139e112e048f7db19d013d1e3f6fb9337f23d7d7832'),
               ('d0f4aba31fd6efd01cfb2ff3706ea43086b0f6941894324c0a32e051ef87e8af',
                '1cf5045d7a22e2bfe6b39139e112e048f7db19d013d1e3f6fb9337f23d7d7832'),
               ('5da7fc9efd185cfbc2d62db2e42e1f3191e78e05a8c8cb4ded3756dc555cfb94',
                '1cf5045d7a22e2bfe6b39139e112e048f7db19d013d1e3f6fb9337f23d7d7832'),
               ('427c00e4e7f53d4f59315bc6ad960a2702e6fa9aa83e9b2db264171dcd32109e',
                '1cf5045d7a22e2bfe6b39139e112e048f7db19d013d1e3f6fb9337f23d7d7832'),
               ('e925c002274c0f1d24cf606db0d7202a6a77a1101b7880444fda367488b4ee7a',
                '1cf5045d7a22e2bfe6b39139e112e048f7db19d013d1e3f6fb9337f23d7d7832'),
               ('c842859e562193c6a192872e28c0954a9367975e221eac074c1cd6405115fb05',
                '1cf5045d7a22e2bfe6b39139e112e048f7db19d013d1e3f6fb9337f23d7d7832'),
               ('0ff3a3c3ddae5665c540233b9c4116a1365d93854f39d284439e5580f83b2c92',
                '1cf5045d7a22e2bfe6b39139e112e048f7db19d013d1e3f6fb9337f23d7d7832'),
               ('bd716b65316a0077e211c4378d3a71f49ed518782921508f2b3d9688f6008b01',
                '1cf5045d7a22e2bfe6b39139e112e048f7db19d013d1e3f6fb9337f23d7d7832'),
               ('fadea3cb47af33905840b7819597dc561e6246c7a85b50a1615cded878bc3e2d',
                '1cf5045d7a22e2bfe6b39139e112e048f7db19d013d1e3f6fb9337f23d7d7832'),
               ('76e96fe7a418a106dec7937c439abd03f9d93aab2bf0c5c1566ab23d656abe65',
                '1cf5045d7a22e2bfe6b39139e112e048f7db19d013d1e3f6fb9337f23d7d7832'),
               ('7f9454a89547604172e1c9a785dc9de40d57a4ef5867a088bd00a1ebc82df59e',
                '1cf5045d7a22e2bfe6b39139e112e048f7db19d013d1e3f6fb9337f23d7d7832'),
               ('6f3db7826019fd23e70047d5fc97a82c21c4f2ddf69fa5142b1b15a2d9fa8b8f',
                '1cf5045d7a22e2bfe6b39139e112e048f7db19d013d1e3f6fb9337f23d7d7832'),
               ('1cf5045d7a22e2bfe6b39139e112e048f7db19d013d1e3f6fb9337f23d7d7832',
                'cfc0473b0931e99774ffdbb2502991eac49e6ffccb052167da5e3e9beaca9e1b'),
               ('04eeb316a0360f87efe91cbb29b35cc97131ea1e024b63237c85ecb1b8fbd905',
                'cfc0473b0931e99774ffdbb2502991eac49e6ffccb052167da5e3e9beaca9e1b'),
               ('dd6d8a55befdba8b291b48362f2475d3fd00cd669b77a88832925f6998e2a4a7',
                'cfc0473b0931e99774ffdbb2502991eac49e6ffccb052167da5e3e9beaca9e1b'),
               ('5ada32a510a6a5be0885bc1d517a7e06f67372cd317d18e51bac9e2b28278005',
                'cfc0473b0931e99774ffdbb2502991eac49e6ffccb052167da5e3e9beaca9e1b'),
               ('1738811d9100acf092c3f5686bc34341747b5b8892d5e9ab7b16a5d632094cb8',
                'cfc0473b0931e99774ffdbb2502991eac49e6ffccb052167da5e3e9beaca9e1b'),
               ('58aaf913044a82b7c57c7994dff203dc11a8f343f73f41099211c8962952e382',
                'cfc0473b0931e99774ffdbb2502991eac49e6ffccb052167da5e3e9beaca9e1b'),
               ('5fabe691493580a4ed58a2dff69ed0781cdb024579945e7cccb1f3690139848e',
                'cfc0473b0931e99774ffdbb2502991eac49e6ffccb052167da5e3e9beaca9e1b'),
               ('5d61a2997b90859edbff352e3dde2395ef585082b47e220d73e42a61d7069777',
                'cfc0473b0931e99774ffdbb2502991eac49e6ffccb052167da5e3e9beaca9e1b'),
               ('d0f4aba31fd6efd01cfb2ff3706ea43086b0f6941894324c0a32e051ef87e8af',
                'cfc0473b0931e99774ffdbb2502991eac49e6ffccb052167da5e3e9beaca9e1b'),
               ('5da7fc9efd185cfbc2d62db2e42e1f3191e78e05a8c8cb4ded3756dc555cfb94',
                'cfc0473b0931e99774ffdbb2502991eac49e6ffccb052167da5e3e9beaca9e1b'),
               ('427c00e4e7f53d4f59315bc6ad960a2702e6fa9aa83e9b2db264171dcd32109e',
                'cfc0473b0931e99774ffdbb2502991eac49e6ffccb052167da5e3e9beaca9e1b'),
               ('e925c002274c0f1d24cf606db0d7202a6a77a1101b7880444fda367488b4ee7a',
                'cfc0473b0931e99774ffdbb2502991eac49e6ffccb052167da5e3e9beaca9e1b'),
               ('c842859e562193c6a192872e28c0954a9367975e221eac074c1cd6405115fb05',
                'cfc0473b0931e99774ffdbb2502991eac49e6ffccb052167da5e3e9beaca9e1b'),
               ('0ff3a3c3ddae5665c540233b9c4116a1365d93854f39d284439e5580f83b2c92',
                'cfc0473b0931e99774ffdbb2502991eac49e6ffccb052167da5e3e9beaca9e1b'),
               ('bd716b65316a0077e211c4378d3a71f49ed518782921508f2b3d9688f6008b01',
                'cfc0473b0931e99774ffdbb2502991eac49e6ffccb052167da5e3e9beaca9e1b'),
               ('fadea3cb47af33905840b7819597dc561e6246c7a85b50a1615cded878bc3e2d',
                'cfc0473b0931e99774ffdbb2502991eac49e6ffccb052167da5e3e9beaca9e1b'),
               ('76e96fe7a418a106dec7937c439abd03f9d93aab2bf0c5c1566ab23d656abe65',
                'cfc0473b0931e99774ffdbb2502991eac49e6ffccb052167da5e3e9beaca9e1b'),
               ('7f9454a89547604172e1c9a785dc9de40d57a4ef5867a088bd00a1ebc82df59e',
                'cfc0473b0931e99774ffdbb2502991eac49e6ffccb052167da5e3e9beaca9e1b'),
               ('6f3db7826019fd23e70047d5fc97a82c21c4f2ddf69fa5142b1b15a2d9fa8b8f',
                'cfc0473b0931e99774ffdbb2502991eac49e6ffccb052167da5e3e9beaca9e1b'),
               ('cfc0473b0931e99774ffdbb2502991eac49e6ffccb052167da5e3e9beaca9e1b',
                '772f3ab79e35e2dcb4f7ddc98472564988aa4bba5c11438264a1db4958caf93f'),
               ('1cf5045d7a22e2bfe6b39139e112e048f7db19d013d1e3f6fb9337f23d7d7832',
                '772f3ab79e35e2dcb4f7ddc98472564988aa4bba5c11438264a1db4958caf93f'),
               ('04eeb316a0360f87efe91cbb29b35cc97131ea1e024b63237c85ecb1b8fbd905',
                '772f3ab79e35e2dcb4f7ddc98472564988aa4bba5c11438264a1db4958caf93f'),
               ('dd6d8a55befdba8b291b48362f2475d3fd00cd669b77a88832925f6998e2a4a7',
                '772f3ab79e35e2dcb4f7ddc98472564988aa4bba5c11438264a1db4958caf93f'),
               ('5ada32a510a6a5be0885bc1d517a7e06f67372cd317d18e51bac9e2b28278005',
                '772f3ab79e35e2dcb4f7ddc98472564988aa4bba5c11438264a1db4958caf93f'),
               ('1738811d9100acf092c3f5686bc34341747b5b8892d5e9ab7b16a5d632094cb8',
                '772f3ab79e35e2dcb4f7ddc98472564988aa4bba5c11438264a1db4958caf93f'),
               ('58aaf913044a82b7c57c7994dff203dc11a8f343f73f41099211c8962952e382',
                '772f3ab79e35e2dcb4f7ddc98472564988aa4bba5c11438264a1db4958caf93f'),
               ('5fabe691493580a4ed58a2dff69ed0781cdb024579945e7cccb1f3690139848e',
                '772f3ab79e35e2dcb4f7ddc98472564988aa4bba5c11438264a1db4958caf93f'),
               ('5d61a2997b90859edbff352e3dde2395ef585082b47e220d73e42a61d7069777',
                '772f3ab79e35e2dcb4f7ddc98472564988aa4bba5c11438264a1db4958caf93f'),
               ('d0f4aba31fd6efd01cfb2ff3706ea43086b0f6941894324c0a32e051ef87e8af',
                '772f3ab79e35e2dcb4f7ddc98472564988aa4bba5c11438264a1db4958caf93f'),
               ('5da7fc9efd185cfbc2d62db2e42e1f3191e78e05a8c8cb4ded3756dc555cfb94',
                '772f3ab79e35e2dcb4f7ddc98472564988aa4bba5c11438264a1db4958caf93f'),
               ('427c00e4e7f53d4f59315bc6ad960a2702e6fa9aa83e9b2db264171dcd32109e',
                '772f3ab79e35e2dcb4f7ddc98472564988aa4bba5c11438264a1db4958caf93f'),
               ('e925c002274c0f1d24cf606db0d7202a6a77a1101b7880444fda367488b4ee7a',
                '772f3ab79e35e2dcb4f7ddc98472564988aa4bba5c11438264a1db4958caf93f'),
               ('c842859e562193c6a192872e28c0954a9367975e221eac074c1cd6405115fb05',
                '772f3ab79e35e2dcb4f7ddc98472564988aa4bba5c11438264a1db4958caf93f'),
               ('0ff3a3c3ddae5665c540233b9c4116a1365d93854f39d284439e5580f83b2c92',
                '772f3ab79e35e2dcb4f7ddc98472564988aa4bba5c11438264a1db4958caf93f'),
               ('bd716b65316a0077e211c4378d3a71f49ed518782921508f2b3d9688f6008b01',
                '772f3ab79e35e2dcb4f7ddc98472564988aa4bba5c11438264a1db4958caf93f'),
               ('fadea3cb47af33905840b7819597dc561e6246c7a85b50a1615cded878bc3e2d',
                '772f3ab79e35e2dcb4f7ddc98472564988aa4bba5c11438264a1db4958caf93f'),
               ('76e96fe7a418a106dec7937c439abd03f9d93aab2bf0c5c1566ab23d656abe65',
                '772f3ab79e35e2dcb4f7ddc98472564988aa4bba5c11438264a1db4958caf93f'),
               ('7f9454a89547604172e1c9a785dc9de40d57a4ef5867a088bd00a1ebc82df59e',
                '772f3ab79e35e2dcb4f7ddc98472564988aa4bba5c11438264a1db4958caf93f'),
               ('6f3db7826019fd23e70047d5fc97a82c21c4f2ddf69fa5142b1b15a2d9fa8b8f',
                '772f3ab79e35e2dcb4f7ddc98472564988aa4bba5c11438264a1db4958caf93f'),
               ('772f3ab79e35e2dcb4f7ddc98472564988aa4bba5c11438264a1db4958caf93f',
                '22af49c3fd8eb60850f27c6164c84493824215411ea75451df5d00e6f1b43fd2'),
               ('cfc0473b0931e99774ffdbb2502991eac49e6ffccb052167da5e3e9beaca9e1b',
                '22af49c3fd8eb60850f27c6164c84493824215411ea75451df5d00e6f1b43fd2'),
               ('1cf5045d7a22e2bfe6b39139e112e048f7db19d013d1e3f6fb9337f23d7d7832',
                '22af49c3fd8eb60850f27c6164c84493824215411ea75451df5d00e6f1b43fd2'),
               ('04eeb316a0360f87efe91cbb29b35cc97131ea1e024b63237c85ecb1b8fbd905',
                '22af49c3fd8eb60850f27c6164c84493824215411ea75451df5d00e6f1b43fd2'),
               ('dd6d8a55befdba8b291b48362f2475d3fd00cd669b77a88832925f6998e2a4a7',
                '22af49c3fd8eb60850f27c6164c84493824215411ea75451df5d00e6f1b43fd2'),
               ('5ada32a510a6a5be0885bc1d517a7e06f67372cd317d18e51bac9e2b28278005',
                '22af49c3fd8eb60850f27c6164c84493824215411ea75451df5d00e6f1b43fd2'),
               ('1738811d9100acf092c3f5686bc34341747b5b8892d5e9ab7b16a5d632094cb8',
                '22af49c3fd8eb60850f27c6164c84493824215411ea75451df5d00e6f1b43fd2'),
               ('58aaf913044a82b7c57c7994dff203dc11a8f343f73f41099211c8962952e382',
                '22af49c3fd8eb60850f27c6164c84493824215411ea75451df5d00e6f1b43fd2'),
               ('5fabe691493580a4ed58a2dff69ed0781cdb024579945e7cccb1f3690139848e',
                '22af49c3fd8eb60850f27c6164c84493824215411ea75451df5d00e6f1b43fd2'),
               ('5d61a2997b90859edbff352e3dde2395ef585082b47e220d73e42a61d7069777',
                '22af49c3fd8eb60850f27c6164c84493824215411ea75451df5d00e6f1b43fd2'),
               ('d0f4aba31fd6efd01cfb2ff3706ea43086b0f6941894324c0a32e051ef87e8af',
                '22af49c3fd8eb60850f27c6164c84493824215411ea75451df5d00e6f1b43fd2'),
               ('5da7fc9efd185cfbc2d62db2e42e1f3191e78e05a8c8cb4ded3756dc555cfb94',
                '22af49c3fd8eb60850f27c6164c84493824215411ea75451df5d00e6f1b43fd2'),
               ('427c00e4e7f53d4f59315bc6ad960a2702e6fa9aa83e9b2db264171dcd32109e',
                '22af49c3fd8eb60850f27c6164c84493824215411ea75451df5d00e6f1b43fd2'),
               ('e925c002274c0f1d24cf606db0d7202a6a77a1101b7880444fda367488b4ee7a',
                '22af49c3fd8eb60850f27c6164c84493824215411ea75451df5d00e6f1b43fd2'),
               ('c842859e562193c6a192872e28c0954a9367975e221eac074c1cd6405115fb05',
                '22af49c3fd8eb60850f27c6164c84493824215411ea75451df5d00e6f1b43fd2'),
               ('0ff3a3c3ddae5665c540233b9c4116a1365d93854f39d284439e5580f83b2c92',
                '22af49c3fd8eb60850f27c6164c84493824215411ea75451df5d00e6f1b43fd2'),
               ('bd716b65316a0077e211c4378d3a71f49ed518782921508f2b3d9688f6008b01',
                '22af49c3fd8eb60850f27c6164c84493824215411ea75451df5d00e6f1b43fd2'),
               ('fadea3cb47af33905840b7819597dc561e6246c7a85b50a1615cded878bc3e2d',
                '22af49c3fd8eb60850f27c6164c84493824215411ea75451df5d00e6f1b43fd2'),
               ('76e96fe7a418a106dec7937c439abd03f9d93aab2bf0c5c1566ab23d656abe65',
                '22af49c3fd8eb60850f27c6164c84493824215411ea75451df5d00e6f1b43fd2'),
               ('7f9454a89547604172e1c9a785dc9de40d57a4ef5867a088bd00a1ebc82df59e',
                '22af49c3fd8eb60850f27c6164c84493824215411ea75451df5d00e6f1b43fd2'),
               ('6f3db7826019fd23e70047d5fc97a82c21c4f2ddf69fa5142b1b15a2d9fa8b8f',
                '22af49c3fd8eb60850f27c6164c84493824215411ea75451df5d00e6f1b43fd2'),
               ('22af49c3fd8eb60850f27c6164c84493824215411ea75451df5d00e6f1b43fd2',
                '0fed88631430d45a3891425a5affca884a13f976c50457726f6cebaaab673bba'),
               ('772f3ab79e35e2dcb4f7ddc98472564988aa4bba5c11438264a1db4958caf93f',
                '0fed88631430d45a3891425a5affca884a13f976c50457726f6cebaaab673bba'),
               ('cfc0473b0931e99774ffdbb2502991eac49e6ffccb052167da5e3e9beaca9e1b',
                '0fed88631430d45a3891425a5affca884a13f976c50457726f6cebaaab673bba'),
               ('1cf5045d7a22e2bfe6b39139e112e048f7db19d013d1e3f6fb9337f23d7d7832',
                '0fed88631430d45a3891425a5affca884a13f976c50457726f6cebaaab673bba'),
               ('04eeb316a0360f87efe91cbb29b35cc97131ea1e024b63237c85ecb1b8fbd905',
                '0fed88631430d45a3891425a5affca884a13f976c50457726f6cebaaab673bba'),
               ('dd6d8a55befdba8b291b48362f2475d3fd00cd669b77a88832925f6998e2a4a7',
                '0fed88631430d45a3891425a5affca884a13f976c50457726f6cebaaab673bba'),
               ('5ada32a510a6a5be0885bc1d517a7e06f67372cd317d18e51bac9e2b28278005',
                '0fed88631430d45a3891425a5affca884a13f976c50457726f6cebaaab673bba'),
               ('1738811d9100acf092c3f5686bc34341747b5b8892d5e9ab7b16a5d632094cb8',
                '0fed88631430d45a3891425a5affca884a13f976c50457726f6cebaaab673bba'),
               ('58aaf913044a82b7c57c7994dff203dc11a8f343f73f41099211c8962952e382',
                '0fed88631430d45a3891425a5affca884a13f976c50457726f6cebaaab673bba'),
               ('5fabe691493580a4ed58a2dff69ed0781cdb024579945e7cccb1f3690139848e',
                '0fed88631430d45a3891425a5affca884a13f976c50457726f6cebaaab673bba'),
               ('5d61a2997b90859edbff352e3dde2395ef585082b47e220d73e42a61d7069777',
                '0fed88631430d45a3891425a5affca884a13f976c50457726f6cebaaab673bba'),
               ('d0f4aba31fd6efd01cfb2ff3706ea43086b0f6941894324c0a32e051ef87e8af',
                '0fed88631430d45a3891425a5affca884a13f976c50457726f6cebaaab673bba'),
               ('5da7fc9efd185cfbc2d62db2e42e1f3191e78e05a8c8cb4ded3756dc555cfb94',
                '0fed88631430d45a3891425a5affca884a13f976c50457726f6cebaaab673bba'),
               ('427c00e4e7f53d4f59315bc6ad960a2702e6fa9aa83e9b2db264171dcd32109e',
                '0fed88631430d45a3891425a5affca884a13f976c50457726f6cebaaab673bba'),
               ('e925c002274c0f1d24cf606db0d7202a6a77a1101b7880444fda367488b4ee7a',
                '0fed88631430d45a3891425a5affca884a13f976c50457726f6cebaaab673bba'),
               ('c842859e562193c6a192872e28c0954a9367975e221eac074c1cd6405115fb05',
                '0fed88631430d45a3891425a5affca884a13f976c50457726f6cebaaab673bba'),
               ('0ff3a3c3ddae5665c540233b9c4116a1365d93854f39d284439e5580f83b2c92',
                '0fed88631430d45a3891425a5affca884a13f976c50457726f6cebaaab673bba'),
               ('bd716b65316a0077e211c4378d3a71f49ed518782921508f2b3d9688f6008b01',
                '0fed88631430d45a3891425a5affca884a13f976c50457726f6cebaaab673bba'),
               ('fadea3cb47af33905840b7819597dc561e6246c7a85b50a1615cded878bc3e2d',
                '0fed88631430d45a3891425a5affca884a13f976c50457726f6cebaaab673bba'),
               ('76e96fe7a418a106dec7937c439abd03f9d93aab2bf0c5c1566ab23d656abe65',
                '0fed88631430d45a3891425a5affca884a13f976c50457726f6cebaaab673bba'),
               ('7f9454a89547604172e1c9a785dc9de40d57a4ef5867a088bd00a1ebc82df59e',
                '0fed88631430d45a3891425a5affca884a13f976c50457726f6cebaaab673bba'),
               ('6f3db7826019fd23e70047d5fc97a82c21c4f2ddf69fa5142b1b15a2d9fa8b8f',
                '0fed88631430d45a3891425a5affca884a13f976c50457726f6cebaaab673bba'),
               ('0fed88631430d45a3891425a5affca884a13f976c50457726f6cebaaab673bba',
                'a749026e7e955876c83b4c8a80414ad8143f0daacebceb7f28daaf9b40fc092f'),
               ('22af49c3fd8eb60850f27c6164c84493824215411ea75451df5d00e6f1b43fd2',
                'a749026e7e955876c83b4c8a80414ad8143f0daacebceb7f28daaf9b40fc092f'),
               ('772f3ab79e35e2dcb4f7ddc98472564988aa4bba5c11438264a1db4958caf93f',
                'a749026e7e955876c83b4c8a80414ad8143f0daacebceb7f28daaf9b40fc092f'),
               ('cfc0473b0931e99774ffdbb2502991eac49e6ffccb052167da5e3e9beaca9e1b',
                'a749026e7e955876c83b4c8a80414ad8143f0daacebceb7f28daaf9b40fc092f'),
               ('1cf5045d7a22e2bfe6b39139e112e048f7db19d013d1e3f6fb9337f23d7d7832',
                'a749026e7e955876c83b4c8a80414ad8143f0daacebceb7f28daaf9b40fc092f'),
               ('04eeb316a0360f87efe91cbb29b35cc97131ea1e024b63237c85ecb1b8fbd905',
                'a749026e7e955876c83b4c8a80414ad8143f0daacebceb7f28daaf9b40fc092f'),
               ('dd6d8a55befdba8b291b48362f2475d3fd00cd669b77a88832925f6998e2a4a7',
                'a749026e7e955876c83b4c8a80414ad8143f0daacebceb7f28daaf9b40fc092f'),
               ('5ada32a510a6a5be0885bc1d517a7e06f67372cd317d18e51bac9e2b28278005',
                'a749026e7e955876c83b4c8a80414ad8143f0daacebceb7f28daaf9b40fc092f'),
               ('1738811d9100acf092c3f5686bc34341747b5b8892d5e9ab7b16a5d632094cb8',
                'a749026e7e955876c83b4c8a80414ad8143f0daacebceb7f28daaf9b40fc092f'),
               ('58aaf913044a82b7c57c7994dff203dc11a8f343f73f41099211c8962952e382',
                'a749026e7e955876c83b4c8a80414ad8143f0daacebceb7f28daaf9b40fc092f'),
               ('5fabe691493580a4ed58a2dff69ed0781cdb024579945e7cccb1f3690139848e',
                'a749026e7e955876c83b4c8a80414ad8143f0daacebceb7f28daaf9b40fc092f'),
               ('5d61a2997b90859edbff352e3dde2395ef585082b47e220d73e42a61d7069777',
                'a749026e7e955876c83b4c8a80414ad8143f0daacebceb7f28daaf9b40fc092f'),
               ('d0f4aba31fd6efd01cfb2ff3706ea43086b0f6941894324c0a32e051ef87e8af',
                'a749026e7e955876c83b4c8a80414ad8143f0daacebceb7f28daaf9b40fc092f'),
               ('5da7fc9efd185cfbc2d62db2e42e1f3191e78e05a8c8cb4ded3756dc555cfb94',
                'a749026e7e955876c83b4c8a80414ad8143f0daacebceb7f28daaf9b40fc092f'),
               ('427c00e4e7f53d4f59315bc6ad960a2702e6fa9aa83e9b2db264171dcd32109e',
                'a749026e7e955876c83b4c8a80414ad8143f0daacebceb7f28daaf9b40fc092f'),
               ('e925c002274c0f1d24cf606db0d7202a6a77a1101b7880444fda367488b4ee7a',
                'a749026e7e955876c83b4c8a80414ad8143f0daacebceb7f28daaf9b40fc092f'),
               ('c842859e562193c6a192872e28c0954a9367975e221eac074c1cd6405115fb05',
                'a749026e7e955876c83b4c8a80414ad8143f0daacebceb7f28daaf9b40fc092f'),
               ('0ff3a3c3ddae5665c540233b9c4116a1365d93854f39d284439e5580f83b2c92',
                'a749026e7e955876c83b4c8a80414ad8143f0daacebceb7f28daaf9b40fc092f'),
               ('bd716b65316a0077e211c4378d3a71f49ed518782921508f2b3d9688f6008b01',
                'a749026e7e955876c83b4c8a80414ad8143f0daacebceb7f28daaf9b40fc092f'),
               ('fadea3cb47af33905840b7819597dc561e6246c7a85b50a1615cded878bc3e2d',
                'a749026e7e955876c83b4c8a80414ad8143f0daacebceb7f28daaf9b40fc092f'),
               ('76e96fe7a418a106dec7937c439abd03f9d93aab2bf0c5c1566ab23d656abe65',
                'a749026e7e955876c83b4c8a80414ad8143f0daacebceb7f28daaf9b40fc092f'),
               ('7f9454a89547604172e1c9a785dc9de40d57a4ef5867a088bd00a1ebc82df59e',
                'a749026e7e955876c83b4c8a80414ad8143f0daacebceb7f28daaf9b40fc092f'),
               ('6f3db7826019fd23e70047d5fc97a82c21c4f2ddf69fa5142b1b15a2d9fa8b8f',
                'a749026e7e955876c83b4c8a80414ad8143f0daacebceb7f28daaf9b40fc092f'),
               ('a749026e7e955876c83b4c8a80414ad8143f0daacebceb7f28daaf9b40fc092f',
                'd1df5e8198dcb292f9676393ca6881e7513b47f155efeb23a6c5e510a002d070'),
               ('0fed88631430d45a3891425a5affca884a13f976c50457726f6cebaaab673bba',
                'd1df5e8198dcb292f9676393ca6881e7513b47f155efeb23a6c5e510a002d070'),
               ('22af49c3fd8eb60850f27c6164c84493824215411ea75451df5d00e6f1b43fd2',
                'd1df5e8198dcb292f9676393ca6881e7513b47f155efeb23a6c5e510a002d070'),
               ('772f3ab79e35e2dcb4f7ddc98472564988aa4bba5c11438264a1db4958caf93f',
                'd1df5e8198dcb292f9676393ca6881e7513b47f155efeb23a6c5e510a002d070'),
               ('cfc0473b0931e99774ffdbb2502991eac49e6ffccb052167da5e3e9beaca9e1b',
                'd1df5e8198dcb292f9676393ca6881e7513b47f155efeb23a6c5e510a002d070'),
               ('1cf5045d7a22e2bfe6b39139e112e048f7db19d013d1e3f6fb9337f23d7d7832',
                'd1df5e8198dcb292f9676393ca6881e7513b47f155efeb23a6c5e510a002d070'),
               ('04eeb316a0360f87efe91cbb29b35cc97131ea1e024b63237c85ecb1b8fbd905',
                'd1df5e8198dcb292f9676393ca6881e7513b47f155efeb23a6c5e510a002d070'),
               ('dd6d8a55befdba8b291b48362f2475d3fd00cd669b77a88832925f6998e2a4a7',
                'd1df5e8198dcb292f9676393ca6881e7513b47f155efeb23a6c5e510a002d070'),
               ('5ada32a510a6a5be0885bc1d517a7e06f67372cd317d18e51bac9e2b28278005',
                'd1df5e8198dcb292f9676393ca6881e7513b47f155efeb23a6c5e510a002d070'),
               ('1738811d9100acf092c3f5686bc34341747b5b8892d5e9ab7b16a5d632094cb8',
                'd1df5e8198dcb292f9676393ca6881e7513b47f155efeb23a6c5e510a002d070'),
               ('58aaf913044a82b7c57c7994dff203dc11a8f343f73f41099211c8962952e382',
                'd1df5e8198dcb292f9676393ca6881e7513b47f155efeb23a6c5e510a002d070'),
               ('5fabe691493580a4ed58a2dff69ed0781cdb024579945e7cccb1f3690139848e',
                'd1df5e8198dcb292f9676393ca6881e7513b47f155efeb23a6c5e510a002d070'),
               ('5d61a2997b90859edbff352e3dde2395ef585082b47e220d73e42a61d7069777',
                'd1df5e8198dcb292f9676393ca6881e7513b47f155efeb23a6c5e510a002d070'),
               ('d0f4aba31fd6efd01cfb2ff3706ea43086b0f6941894324c0a32e051ef87e8af',
                'd1df5e8198dcb292f9676393ca6881e7513b47f155efeb23a6c5e510a002d070'),
               ('5da7fc9efd185cfbc2d62db2e42e1f3191e78e05a8c8cb4ded3756dc555cfb94',
                'd1df5e8198dcb292f9676393ca6881e7513b47f155efeb23a6c5e510a002d070'),
               ('427c00e4e7f53d4f59315bc6ad960a2702e6fa9aa83e9b2db264171dcd32109e',
                'd1df5e8198dcb292f9676393ca6881e7513b47f155efeb23a6c5e510a002d070'),
               ('e925c002274c0f1d24cf606db0d7202a6a77a1101b7880444fda367488b4ee7a',
                'd1df5e8198dcb292f9676393ca6881e7513b47f155efeb23a6c5e510a002d070'),
               ('c842859e562193c6a192872e28c0954a9367975e221eac074c1cd6405115fb05',
                'd1df5e8198dcb292f9676393ca6881e7513b47f155efeb23a6c5e510a002d070'),
               ('0ff3a3c3ddae5665c540233b9c4116a1365d93854f39d284439e5580f83b2c92',
                'd1df5e8198dcb292f9676393ca6881e7513b47f155efeb23a6c5e510a002d070'),
               ('bd716b65316a0077e211c4378d3a71f49ed518782921508f2b3d9688f6008b01',
                'd1df5e8198dcb292f9676393ca6881e7513b47f155efeb23a6c5e510a002d070'),
               ('fadea3cb47af33905840b7819597dc561e6246c7a85b50a1615cded878bc3e2d',
                'd1df5e8198dcb292f9676393ca6881e7513b47f155efeb23a6c5e510a002d070'),
               ('76e96fe7a418a106dec7937c439abd03f9d93aab2bf0c5c1566ab23d656abe65',
                'd1df5e8198dcb292f9676393ca6881e7513b47f155efeb23a6c5e510a002d070'),
               ('7f9454a89547604172e1c9a785dc9de40d57a4ef5867a088bd00a1ebc82df59e',
                'd1df5e8198dcb292f9676393ca6881e7513b47f155efeb23a6c5e510a002d070'),
               ('6f3db7826019fd23e70047d5fc97a82c21c4f2ddf69fa5142b1b15a2d9fa8b8f',
                'd1df5e8198dcb292f9676393ca6881e7513b47f155efeb23a6c5e510a002d070'),
               ('04eeb316a0360f87efe91cbb29b35cc97131ea1e024b63237c85ecb1b8fbd905',
                '1fa61d83312ab8d2570b28c7ad28a945ad73c211dbe65ecba0d3c7eb6e5cd0c8'),
               ('0fed88631430d45a3891425a5affca884a13f976c50457726f6cebaaab673bba',
                '1fa61d83312ab8d2570b28c7ad28a945ad73c211dbe65ecba0d3c7eb6e5cd0c8'),
               ('0ff3a3c3ddae5665c540233b9c4116a1365d93854f39d284439e5580f83b2c92',
                '1fa61d83312ab8d2570b28c7ad28a945ad73c211dbe65ecba0d3c7eb6e5cd0c8'),
               ('1738811d9100acf092c3f5686bc34341747b5b8892d5e9ab7b16a5d632094cb8',
                '1fa61d83312ab8d2570b28c7ad28a945ad73c211dbe65ecba0d3c7eb6e5cd0c8'),
               ('1cf5045d7a22e2bfe6b39139e112e048f7db19d013d1e3f6fb9337f23d7d7832',
                '1fa61d83312ab8d2570b28c7ad28a945ad73c211dbe65ecba0d3c7eb6e5cd0c8'),
               ('22af49c3fd8eb60850f27c6164c84493824215411ea75451df5d00e6f1b43fd2',
                '1fa61d83312ab8d2570b28c7ad28a945ad73c211dbe65ecba0d3c7eb6e5cd0c8'),
               ('427c00e4e7f53d4f59315bc6ad960a2702e6fa9aa83e9b2db264171dcd32109e',
                '1fa61d83312ab8d2570b28c7ad28a945ad73c211dbe65ecba0d3c7eb6e5cd0c8'),
               ('58aaf913044a82b7c57c7994dff203dc11a8f343f73f41099211c8962952e382',
                '1fa61d83312ab8d2570b28c7ad28a945ad73c211dbe65ecba0d3c7eb6e5cd0c8'),
               ('5ada32a510a6a5be0885bc1d517a7e06f67372cd317d18e51bac9e2b28278005',
                '1fa61d83312ab8d2570b28c7ad28a945ad73c211dbe65ecba0d3c7eb6e5cd0c8'),
               ('5d61a2997b90859edbff352e3dde2395ef585082b47e220d73e42a61d7069777',
                '1fa61d83312ab8d2570b28c7ad28a945ad73c211dbe65ecba0d3c7eb6e5cd0c8'),
               ('5da7fc9efd185cfbc2d62db2e42e1f3191e78e05a8c8cb4ded3756dc555cfb94',
                '1fa61d83312ab8d2570b28c7ad28a945ad73c211dbe65ecba0d3c7eb6e5cd0c8'),
               ('5fabe691493580a4ed58a2dff69ed0781cdb024579945e7cccb1f3690139848e',
                '1fa61d83312ab8d2570b28c7ad28a945ad73c211dbe65ecba0d3c7eb6e5cd0c8'),
               ('6f3db7826019fd23e70047d5fc97a82c21c4f2ddf69fa5142b1b15a2d9fa8b8f',
                '1fa61d83312ab8d2570b28c7ad28a945ad73c211dbe65ecba0d3c7eb6e5cd0c8'),
               ('76e96fe7a418a106dec7937c439abd03f9d93aab2bf0c5c1566ab23d656abe65',
                '1fa61d83312ab8d2570b28c7ad28a945ad73c211dbe65ecba0d3c7eb6e5cd0c8'),
               ('772f3ab79e35e2dcb4f7ddc98472564988aa4bba5c11438264a1db4958caf93f',
                '1fa61d83312ab8d2570b28c7ad28a945ad73c211dbe65ecba0d3c7eb6e5cd0c8'),
               ('7f9454a89547604172e1c9a785dc9de40d57a4ef5867a088bd00a1ebc82df59e',
                '1fa61d83312ab8d2570b28c7ad28a945ad73c211dbe65ecba0d3c7eb6e5cd0c8'),
               ('a749026e7e955876c83b4c8a80414ad8143f0daacebceb7f28daaf9b40fc092f',
                '1fa61d83312ab8d2570b28c7ad28a945ad73c211dbe65ecba0d3c7eb6e5cd0c8'),
               ('bd716b65316a0077e211c4378d3a71f49ed518782921508f2b3d9688f6008b01',
                '1fa61d83312ab8d2570b28c7ad28a945ad73c211dbe65ecba0d3c7eb6e5cd0c8'),
               ('c842859e562193c6a192872e28c0954a9367975e221eac074c1cd6405115fb05',
                '1fa61d83312ab8d2570b28c7ad28a945ad73c211dbe65ecba0d3c7eb6e5cd0c8'),
               ('cfc0473b0931e99774ffdbb2502991eac49e6ffccb052167da5e3e9beaca9e1b',
                '1fa61d83312ab8d2570b28c7ad28a945ad73c211dbe65ecba0d3c7eb6e5cd0c8'),
               ('d0f4aba31fd6efd01cfb2ff3706ea43086b0f6941894324c0a32e051ef87e8af',
                '1fa61d83312ab8d2570b28c7ad28a945ad73c211dbe65ecba0d3c7eb6e5cd0c8'),
               ('d1df5e8198dcb292f9676393ca6881e7513b47f155efeb23a6c5e510a002d070',
                '1fa61d83312ab8d2570b28c7ad28a945ad73c211dbe65ecba0d3c7eb6e5cd0c8'),
               ('dd6d8a55befdba8b291b48362f2475d3fd00cd669b77a88832925f6998e2a4a7',
                '1fa61d83312ab8d2570b28c7ad28a945ad73c211dbe65ecba0d3c7eb6e5cd0c8'),
               ('e925c002274c0f1d24cf606db0d7202a6a77a1101b7880444fda367488b4ee7a',
                '1fa61d83312ab8d2570b28c7ad28a945ad73c211dbe65ecba0d3c7eb6e5cd0c8'),
               ('fadea3cb47af33905840b7819597dc561e6246c7a85b50a1615cded878bc3e2d',
                '1fa61d83312ab8d2570b28c7ad28a945ad73c211dbe65ecba0d3c7eb6e5cd0c8'),
               ('04eeb316a0360f87efe91cbb29b35cc97131ea1e024b63237c85ecb1b8fbd905',
                '0b8ecd3422e8a231198f41257793a90aec23c15c7db41601e2d46fa635b468a3'),
               ('0fed88631430d45a3891425a5affca884a13f976c50457726f6cebaaab673bba',
                '0b8ecd3422e8a231198f41257793a90aec23c15c7db41601e2d46fa635b468a3'),
               ('0ff3a3c3ddae5665c540233b9c4116a1365d93854f39d284439e5580f83b2c92',
                '0b8ecd3422e8a231198f41257793a90aec23c15c7db41601e2d46fa635b468a3'),
               ('1738811d9100acf092c3f5686bc34341747b5b8892d5e9ab7b16a5d632094cb8',
                '0b8ecd3422e8a231198f41257793a90aec23c15c7db41601e2d46fa635b468a3'),
               ('1cf5045d7a22e2bfe6b39139e112e048f7db19d013d1e3f6fb9337f23d7d7832',
                '0b8ecd3422e8a231198f41257793a90aec23c15c7db41601e2d46fa635b468a3'),
               ('1fa61d83312ab8d2570b28c7ad28a945ad73c211dbe65ecba0d3c7eb6e5cd0c8',
                '0b8ecd3422e8a231198f41257793a90aec23c15c7db41601e2d46fa635b468a3'),
               ('22af49c3fd8eb60850f27c6164c84493824215411ea75451df5d00e6f1b43fd2',
                '0b8ecd3422e8a231198f41257793a90aec23c15c7db41601e2d46fa635b468a3'),
               ('427c00e4e7f53d4f59315bc6ad960a2702e6fa9aa83e9b2db264171dcd32109e',
                '0b8ecd3422e8a231198f41257793a90aec23c15c7db41601e2d46fa635b468a3'),
               ('58aaf913044a82b7c57c7994dff203dc11a8f343f73f41099211c8962952e382',
                '0b8ecd3422e8a231198f41257793a90aec23c15c7db41601e2d46fa635b468a3'),
               ('5ada32a510a6a5be0885bc1d517a7e06f67372cd317d18e51bac9e2b28278005',
                '0b8ecd3422e8a231198f41257793a90aec23c15c7db41601e2d46fa635b468a3'),
               ('5d61a2997b90859edbff352e3dde2395ef585082b47e220d73e42a61d7069777',
                '0b8ecd3422e8a231198f41257793a90aec23c15c7db41601e2d46fa635b468a3'),
               ('5da7fc9efd185cfbc2d62db2e42e1f3191e78e05a8c8cb4ded3756dc555cfb94',
                '0b8ecd3422e8a231198f41257793a90aec23c15c7db41601e2d46fa635b468a3'),
               ('5fabe691493580a4ed58a2dff69ed0781cdb024579945e7cccb1f3690139848e',
                '0b8ecd3422e8a231198f41257793a90aec23c15c7db41601e2d46fa635b468a3'),
               ('6f3db7826019fd23e70047d5fc97a82c21c4f2ddf69fa5142b1b15a2d9fa8b8f',
                '0b8ecd3422e8a231198f41257793a90aec23c15c7db41601e2d46fa635b468a3'),
               ('76e96fe7a418a106dec7937c439abd03f9d93aab2bf0c5c1566ab23d656abe65',
                '0b8ecd3422e8a231198f41257793a90aec23c15c7db41601e2d46fa635b468a3'),
               ('772f3ab79e35e2dcb4f7ddc98472564988aa4bba5c11438264a1db4958caf93f',
                '0b8ecd3422e8a231198f41257793a90aec23c15c7db41601e2d46fa635b468a3'),
               ('7f9454a89547604172e1c9a785dc9de40d57a4ef5867a088bd00a1ebc82df59e',
                '0b8ecd3422e8a231198f41257793a90aec23c15c7db41601e2d46fa635b468a3'),
               ('a749026e7e955876c83b4c8a80414ad8143f0daacebceb7f28daaf9b40fc092f',
                '0b8ecd3422e8a231198f41257793a90aec23c15c7db41601e2d46fa635b468a3'),
               ('bd716b65316a0077e211c4378d3a71f49ed518782921508f2b3d9688f6008b01',
                '0b8ecd3422e8a231198f41257793a90aec23c15c7db41601e2d46fa635b468a3'),
               ('c842859e562193c6a192872e28c0954a9367975e221eac074c1cd6405115fb05',
                '0b8ecd3422e8a231198f41257793a90aec23c15c7db41601e2d46fa635b468a3'),
               ('cfc0473b0931e99774ffdbb2502991eac49e6ffccb052167da5e3e9beaca9e1b',
                '0b8ecd3422e8a231198f41257793a90aec23c15c7db41601e2d46fa635b468a3'),
               ('d0f4aba31fd6efd01cfb2ff3706ea43086b0f6941894324c0a32e051ef87e8af',
                '0b8ecd3422e8a231198f41257793a90aec23c15c7db41601e2d46fa635b468a3'),
               ('d1df5e8198dcb292f9676393ca6881e7513b47f155efeb23a6c5e510a002d070',
                '0b8ecd3422e8a231198f41257793a90aec23c15c7db41601e2d46fa635b468a3'),
               ('dd6d8a55befdba8b291b48362f2475d3fd00cd669b77a88832925f6998e2a4a7',
                '0b8ecd3422e8a231198f41257793a90aec23c15c7db41601e2d46fa635b468a3'),
               ('e925c002274c0f1d24cf606db0d7202a6a77a1101b7880444fda367488b4ee7a',
                '0b8ecd3422e8a231198f41257793a90aec23c15c7db41601e2d46fa635b468a3'),
               ('fadea3cb47af33905840b7819597dc561e6246c7a85b50a1615cded878bc3e2d',
                '0b8ecd3422e8a231198f41257793a90aec23c15c7db41601e2d46fa635b468a3'),
               ('04eeb316a0360f87efe91cbb29b35cc97131ea1e024b63237c85ecb1b8fbd905',
                '513ec96c7fe3ff70952e45522d10edd47b512ffe4683d8afc1adbf9b912c3e25'),
               ('0b8ecd3422e8a231198f41257793a90aec23c15c7db41601e2d46fa635b468a3',
                '513ec96c7fe3ff70952e45522d10edd47b512ffe4683d8afc1adbf9b912c3e25'),
               ('0fed88631430d45a3891425a5affca884a13f976c50457726f6cebaaab673bba',
                '513ec96c7fe3ff70952e45522d10edd47b512ffe4683d8afc1adbf9b912c3e25'),
               ('0ff3a3c3ddae5665c540233b9c4116a1365d93854f39d284439e5580f83b2c92',
                '513ec96c7fe3ff70952e45522d10edd47b512ffe4683d8afc1adbf9b912c3e25'),
               ('1738811d9100acf092c3f5686bc34341747b5b8892d5e9ab7b16a5d632094cb8',
                '513ec96c7fe3ff70952e45522d10edd47b512ffe4683d8afc1adbf9b912c3e25'),
               ('1cf5045d7a22e2bfe6b39139e112e048f7db19d013d1e3f6fb9337f23d7d7832',
                '513ec96c7fe3ff70952e45522d10edd47b512ffe4683d8afc1adbf9b912c3e25'),
               ('1fa61d83312ab8d2570b28c7ad28a945ad73c211dbe65ecba0d3c7eb6e5cd0c8',
                '513ec96c7fe3ff70952e45522d10edd47b512ffe4683d8afc1adbf9b912c3e25'),
               ('22af49c3fd8eb60850f27c6164c84493824215411ea75451df5d00e6f1b43fd2',
                '513ec96c7fe3ff70952e45522d10edd47b512ffe4683d8afc1adbf9b912c3e25'),
               ('427c00e4e7f53d4f59315bc6ad960a2702e6fa9aa83e9b2db264171dcd32109e',
                '513ec96c7fe3ff70952e45522d10edd47b512ffe4683d8afc1adbf9b912c3e25'),
               ('58aaf913044a82b7c57c7994dff203dc11a8f343f73f41099211c8962952e382',
                '513ec96c7fe3ff70952e45522d10edd47b512ffe4683d8afc1adbf9b912c3e25'),
               ('5ada32a510a6a5be0885bc1d517a7e06f67372cd317d18e51bac9e2b28278005',
                '513ec96c7fe3ff70952e45522d10edd47b512ffe4683d8afc1adbf9b912c3e25'),
               ('5d61a2997b90859edbff352e3dde2395ef585082b47e220d73e42a61d7069777',
                '513ec96c7fe3ff70952e45522d10edd47b512ffe4683d8afc1adbf9b912c3e25'),
               ('5da7fc9efd185cfbc2d62db2e42e1f3191e78e05a8c8cb4ded3756dc555cfb94',
                '513ec96c7fe3ff70952e45522d10edd47b512ffe4683d8afc1adbf9b912c3e25'),
               ('5fabe691493580a4ed58a2dff69ed0781cdb024579945e7cccb1f3690139848e',
                '513ec96c7fe3ff70952e45522d10edd47b512ffe4683d8afc1adbf9b912c3e25'),
               ('6f3db7826019fd23e70047d5fc97a82c21c4f2ddf69fa5142b1b15a2d9fa8b8f',
                '513ec96c7fe3ff70952e45522d10edd47b512ffe4683d8afc1adbf9b912c3e25'),
               ('76e96fe7a418a106dec7937c439abd03f9d93aab2bf0c5c1566ab23d656abe65',
                '513ec96c7fe3ff70952e45522d10edd47b512ffe4683d8afc1adbf9b912c3e25'),
               ('772f3ab79e35e2dcb4f7ddc98472564988aa4bba5c11438264a1db4958caf93f',
                '513ec96c7fe3ff70952e45522d10edd47b512ffe4683d8afc1adbf9b912c3e25'),
               ('7f9454a89547604172e1c9a785dc9de40d57a4ef5867a088bd00a1ebc82df59e',
                '513ec96c7fe3ff70952e45522d10edd47b512ffe4683d8afc1adbf9b912c3e25'),
               ('a749026e7e955876c83b4c8a80414ad8143f0daacebceb7f28daaf9b40fc092f',
                '513ec96c7fe3ff70952e45522d10edd47b512ffe4683d8afc1adbf9b912c3e25'),
               ('bd716b65316a0077e211c4378d3a71f49ed518782921508f2b3d9688f6008b01',
                '513ec96c7fe3ff70952e45522d10edd47b512ffe4683d8afc1adbf9b912c3e25'),
               ('c842859e562193c6a192872e28c0954a9367975e221eac074c1cd6405115fb05',
                '513ec96c7fe3ff70952e45522d10edd47b512ffe4683d8afc1adbf9b912c3e25'),
               ('cfc0473b0931e99774ffdbb2502991eac49e6ffccb052167da5e3e9beaca9e1b',
                '513ec96c7fe3ff70952e45522d10edd47b512ffe4683d8afc1adbf9b912c3e25'),
               ('d0f4aba31fd6efd01cfb2ff3706ea43086b0f6941894324c0a32e051ef87e8af',
                '513ec96c7fe3ff70952e45522d10edd47b512ffe4683d8afc1adbf9b912c3e25'),
               ('d1df5e8198dcb292f9676393ca6881e7513b47f155efeb23a6c5e510a002d070',
                '513ec96c7fe3ff70952e45522d10edd47b512ffe4683d8afc1adbf9b912c3e25'),
               ('dd6d8a55befdba8b291b48362f2475d3fd00cd669b77a88832925f6998e2a4a7',
                '513ec96c7fe3ff70952e45522d10edd47b512ffe4683d8afc1adbf9b912c3e25'),
               ('e925c002274c0f1d24cf606db0d7202a6a77a1101b7880444fda367488b4ee7a',
                '513ec96c7fe3ff70952e45522d10edd47b512ffe4683d8afc1adbf9b912c3e25'),
               ('fadea3cb47af33905840b7819597dc561e6246c7a85b50a1615cded878bc3e2d',
                '513ec96c7fe3ff70952e45522d10edd47b512ffe4683d8afc1adbf9b912c3e25'),
               ('04eeb316a0360f87efe91cbb29b35cc97131ea1e024b63237c85ecb1b8fbd905',
                'd00e41f79366135136a6f8ad9c292a6ef333dd04b0638de795c8b26aae491386'),
               ('0b8ecd3422e8a231198f41257793a90aec23c15c7db41601e2d46fa635b468a3',
                'd00e41f79366135136a6f8ad9c292a6ef333dd04b0638de795c8b26aae491386'),
               ('0fed88631430d45a3891425a5affca884a13f976c50457726f6cebaaab673bba',
                'd00e41f79366135136a6f8ad9c292a6ef333dd04b0638de795c8b26aae491386'),
               ('0ff3a3c3ddae5665c540233b9c4116a1365d93854f39d284439e5580f83b2c92',
                'd00e41f79366135136a6f8ad9c292a6ef333dd04b0638de795c8b26aae491386'),
               ('1738811d9100acf092c3f5686bc34341747b5b8892d5e9ab7b16a5d632094cb8',
                'd00e41f79366135136a6f8ad9c292a6ef333dd04b0638de795c8b26aae491386'),
               ('1cf5045d7a22e2bfe6b39139e112e048f7db19d013d1e3f6fb9337f23d7d7832',
                'd00e41f79366135136a6f8ad9c292a6ef333dd04b0638de795c8b26aae491386'),
               ('1fa61d83312ab8d2570b28c7ad28a945ad73c211dbe65ecba0d3c7eb6e5cd0c8',
                'd00e41f79366135136a6f8ad9c292a6ef333dd04b0638de795c8b26aae491386'),
               ('22af49c3fd8eb60850f27c6164c84493824215411ea75451df5d00e6f1b43fd2',
                'd00e41f79366135136a6f8ad9c292a6ef333dd04b0638de795c8b26aae491386'),
               ('427c00e4e7f53d4f59315bc6ad960a2702e6fa9aa83e9b2db264171dcd32109e',
                'd00e41f79366135136a6f8ad9c292a6ef333dd04b0638de795c8b26aae491386'),
               ('513ec96c7fe3ff70952e45522d10edd47b512ffe4683d8afc1adbf9b912c3e25',
                'd00e41f79366135136a6f8ad9c292a6ef333dd04b0638de795c8b26aae491386'),
               ('58aaf913044a82b7c57c7994dff203dc11a8f343f73f41099211c8962952e382',
                'd00e41f79366135136a6f8ad9c292a6ef333dd04b0638de795c8b26aae491386'),
               ('5ada32a510a6a5be0885bc1d517a7e06f67372cd317d18e51bac9e2b28278005',
                'd00e41f79366135136a6f8ad9c292a6ef333dd04b0638de795c8b26aae491386'),
               ('5d61a2997b90859edbff352e3dde2395ef585082b47e220d73e42a61d7069777',
                'd00e41f79366135136a6f8ad9c292a6ef333dd04b0638de795c8b26aae491386'),
               ('5da7fc9efd185cfbc2d62db2e42e1f3191e78e05a8c8cb4ded3756dc555cfb94',
                'd00e41f79366135136a6f8ad9c292a6ef333dd04b0638de795c8b26aae491386'),
               ('5fabe691493580a4ed58a2dff69ed0781cdb024579945e7cccb1f3690139848e',
                'd00e41f79366135136a6f8ad9c292a6ef333dd04b0638de795c8b26aae491386'),
               ('6f3db7826019fd23e70047d5fc97a82c21c4f2ddf69fa5142b1b15a2d9fa8b8f',
                'd00e41f79366135136a6f8ad9c292a6ef333dd04b0638de795c8b26aae491386'),
               ('76e96fe7a418a106dec7937c439abd03f9d93aab2bf0c5c1566ab23d656abe65',
                'd00e41f79366135136a6f8ad9c292a6ef333dd04b0638de795c8b26aae491386'),
               ('772f3ab79e35e2dcb4f7ddc98472564988aa4bba5c11438264a1db4958caf93f',
                'd00e41f79366135136a6f8ad9c292a6ef333dd04b0638de795c8b26aae491386'),
               ('7f9454a89547604172e1c9a785dc9de40d57a4ef5867a088bd00a1ebc82df59e',
                'd00e41f79366135136a6f8ad9c292a6ef333dd04b0638de795c8b26aae491386'),
               ('a749026e7e955876c83b4c8a80414ad8143f0daacebceb7f28daaf9b40fc092f',
                'd00e41f79366135136a6f8ad9c292a6ef333dd04b0638de795c8b26aae491386'),
               ('bd716b65316a0077e211c4378d3a71f49ed518782921508f2b3d9688f6008b01',
                'd00e41f79366135136a6f8ad9c292a6ef333dd04b0638de795c8b26aae491386'),
               ('c842859e562193c6a192872e28c0954a9367975e221eac074c1cd6405115fb05',
                'd00e41f79366135136a6f8ad9c292a6ef333dd04b0638de795c8b26aae491386'),
               ('cfc0473b0931e99774ffdbb2502991eac49e6ffccb052167da5e3e9beaca9e1b',
                'd00e41f79366135136a6f8ad9c292a6ef333dd04b0638de795c8b26aae491386'),
               ('d0f4aba31fd6efd01cfb2ff3706ea43086b0f6941894324c0a32e051ef87e8af',
                'd00e41f79366135136a6f8ad9c292a6ef333dd04b0638de795c8b26aae491386'),
               ('d1df5e8198dcb292f9676393ca6881e7513b47f155efeb23a6c5e510a002d070',
                'd00e41f79366135136a6f8ad9c292a6ef333dd04b0638de795c8b26aae491386'),
               ('dd6d8a55befdba8b291b48362f2475d3fd00cd669b77a88832925f6998e2a4a7',
                'd00e41f79366135136a6f8ad9c292a6ef333dd04b0638de795c8b26aae491386'),
               ('e925c002274c0f1d24cf606db0d7202a6a77a1101b7880444fda367488b4ee7a',
                'd00e41f79366135136a6f8ad9c292a6ef333dd04b0638de795c8b26aae491386'),
               ('fadea3cb47af33905840b7819597dc561e6246c7a85b50a1615cded878bc3e2d',
                'd00e41f79366135136a6f8ad9c292a6ef333dd04b0638de795c8b26aae491386'),
               ('04eeb316a0360f87efe91cbb29b35cc97131ea1e024b63237c85ecb1b8fbd905',
                '91cff507d2a72caa8b84ea7448f926e0aa8f96ad36dd4df9b944ed51e08659c3'),
               ('0b8ecd3422e8a231198f41257793a90aec23c15c7db41601e2d46fa635b468a3',
                '91cff507d2a72caa8b84ea7448f926e0aa8f96ad36dd4df9b944ed51e08659c3'),
               ('0fed88631430d45a3891425a5affca884a13f976c50457726f6cebaaab673bba',
                '91cff507d2a72caa8b84ea7448f926e0aa8f96ad36dd4df9b944ed51e08659c3'),
               ('0ff3a3c3ddae5665c540233b9c4116a1365d93854f39d284439e5580f83b2c92',
                '91cff507d2a72caa8b84ea7448f926e0aa8f96ad36dd4df9b944ed51e08659c3'),
               ('1738811d9100acf092c3f5686bc34341747b5b8892d5e9ab7b16a5d632094cb8',
                '91cff507d2a72caa8b84ea7448f926e0aa8f96ad36dd4df9b944ed51e08659c3'),
               ('1cf5045d7a22e2bfe6b39139e112e048f7db19d013d1e3f6fb9337f23d7d7832',
                '91cff507d2a72caa8b84ea7448f926e0aa8f96ad36dd4df9b944ed51e08659c3'),
               ('1fa61d83312ab8d2570b28c7ad28a945ad73c211dbe65ecba0d3c7eb6e5cd0c8',
                '91cff507d2a72caa8b84ea7448f926e0aa8f96ad36dd4df9b944ed51e08659c3'),
               ('22af49c3fd8eb60850f27c6164c84493824215411ea75451df5d00e6f1b43fd2',
                '91cff507d2a72caa8b84ea7448f926e0aa8f96ad36dd4df9b944ed51e08659c3'),
               ('427c00e4e7f53d4f59315bc6ad960a2702e6fa9aa83e9b2db264171dcd32109e',
                '91cff507d2a72caa8b84ea7448f926e0aa8f96ad36dd4df9b944ed51e08659c3'),
               ('513ec96c7fe3ff70952e45522d10edd47b512ffe4683d8afc1adbf9b912c3e25',
                '91cff507d2a72caa8b84ea7448f926e0aa8f96ad36dd4df9b944ed51e08659c3'),
               ('58aaf913044a82b7c57c7994dff203dc11a8f343f73f41099211c8962952e382',
                '91cff507d2a72caa8b84ea7448f926e0aa8f96ad36dd4df9b944ed51e08659c3'),
               ('5ada32a510a6a5be0885bc1d517a7e06f67372cd317d18e51bac9e2b28278005',
                '91cff507d2a72caa8b84ea7448f926e0aa8f96ad36dd4df9b944ed51e08659c3'),
               ('5d61a2997b90859edbff352e3dde2395ef585082b47e220d73e42a61d7069777',
                '91cff507d2a72caa8b84ea7448f926e0aa8f96ad36dd4df9b944ed51e08659c3'),
               ('5da7fc9efd185cfbc2d62db2e42e1f3191e78e05a8c8cb4ded3756dc555cfb94',
                '91cff507d2a72caa8b84ea7448f926e0aa8f96ad36dd4df9b944ed51e08659c3'),
               ('5fabe691493580a4ed58a2dff69ed0781cdb024579945e7cccb1f3690139848e',
                '91cff507d2a72caa8b84ea7448f926e0aa8f96ad36dd4df9b944ed51e08659c3'),
               ('6f3db7826019fd23e70047d5fc97a82c21c4f2ddf69fa5142b1b15a2d9fa8b8f',
                '91cff507d2a72caa8b84ea7448f926e0aa8f96ad36dd4df9b944ed51e08659c3'),
               ('76e96fe7a418a106dec7937c439abd03f9d93aab2bf0c5c1566ab23d656abe65',
                '91cff507d2a72caa8b84ea7448f926e0aa8f96ad36dd4df9b944ed51e08659c3'),
               ('772f3ab79e35e2dcb4f7ddc98472564988aa4bba5c11438264a1db4958caf93f',
                '91cff507d2a72caa8b84ea7448f926e0aa8f96ad36dd4df9b944ed51e08659c3'),
               ('7f9454a89547604172e1c9a785dc9de40d57a4ef5867a088bd00a1ebc82df59e',
                '91cff507d2a72caa8b84ea7448f926e0aa8f96ad36dd4df9b944ed51e08659c3'),
               ('a749026e7e955876c83b4c8a80414ad8143f0daacebceb7f28daaf9b40fc092f',
                '91cff507d2a72caa8b84ea7448f926e0aa8f96ad36dd4df9b944ed51e08659c3'),
               ('bd716b65316a0077e211c4378d3a71f49ed518782921508f2b3d9688f6008b01',
                '91cff507d2a72caa8b84ea7448f926e0aa8f96ad36dd4df9b944ed51e08659c3'),
               ('c842859e562193c6a192872e28c0954a9367975e221eac074c1cd6405115fb05',
                '91cff507d2a72caa8b84ea7448f926e0aa8f96ad36dd4df9b944ed51e08659c3'),
               ('cfc0473b0931e99774ffdbb2502991eac49e6ffccb052167da5e3e9beaca9e1b',
                '91cff507d2a72caa8b84ea7448f926e0aa8f96ad36dd4df9b944ed51e08659c3'),
               ('d00e41f79366135136a6f8ad9c292a6ef333dd04b0638de795c8b26aae491386',
                '91cff507d2a72caa8b84ea7448f926e0aa8f96ad36dd4df9b944ed51e08659c3'),
               ('d0f4aba31fd6efd01cfb2ff3706ea43086b0f6941894324c0a32e051ef87e8af',
                '91cff507d2a72caa8b84ea7448f926e0aa8f96ad36dd4df9b944ed51e08659c3'),
               ('d1df5e8198dcb292f9676393ca6881e7513b47f155efeb23a6c5e510a002d070',
                '91cff507d2a72caa8b84ea7448f926e0aa8f96ad36dd4df9b944ed51e08659c3'),
               ('dd6d8a55befdba8b291b48362f2475d3fd00cd669b77a88832925f6998e2a4a7',
                '91cff507d2a72caa8b84ea7448f926e0aa8f96ad36dd4df9b944ed51e08659c3'),
               ('e925c002274c0f1d24cf606db0d7202a6a77a1101b7880444fda367488b4ee7a',
                '91cff507d2a72caa8b84ea7448f926e0aa8f96ad36dd4df9b944ed51e08659c3'),
               ('fadea3cb47af33905840b7819597dc561e6246c7a85b50a1615cded878bc3e2d',
                '91cff507d2a72caa8b84ea7448f926e0aa8f96ad36dd4df9b944ed51e08659c3')],
 'COMPILE_REPORT.md': [('04c59dacc2699e0930f1048a03db5f42cc5cfece4aa8079aba15109c7769a026',
                        '7bd5c702cbe7c53069de40e000a1e45cfa4eecce8f56a663c6f40b7f102d7819'),
                       ('c6e4c33d480642c247948df41c1f3a76d828ec174d5a105b26fd17b4767df6cb',
                        '7bd5c702cbe7c53069de40e000a1e45cfa4eecce8f56a663c6f40b7f102d7819'),
                       ('916d4d0c6ec0eaa0cb1708abbfbe69fd63c90699ec0ddf87501b321244345cef',
                        '7bd5c702cbe7c53069de40e000a1e45cfa4eecce8f56a663c6f40b7f102d7819'),
                       ('06d3e7925f4c602a67c81a60edb585ae946f0d472d39557595ed96d3b3a98d1b',
                        '7bd5c702cbe7c53069de40e000a1e45cfa4eecce8f56a663c6f40b7f102d7819'),
                       ('f6dba91f7d916f203e224b3c4d6c23ed0d5677b8cfeba75717b869c1f408510c',
                        '7bd5c702cbe7c53069de40e000a1e45cfa4eecce8f56a663c6f40b7f102d7819'),
                       ('3636a2e9e099d2f161e0a1a6ab5342f4c4fb502fadc0cb264fce41700ba09837',
                        '7bd5c702cbe7c53069de40e000a1e45cfa4eecce8f56a663c6f40b7f102d7819'),
                       ('98fc7de00e343ad677131521866f5ce72e5cb64c87887b213ce2b8643e0b767c',
                        '7bd5c702cbe7c53069de40e000a1e45cfa4eecce8f56a663c6f40b7f102d7819'),
                       ('df52b4e688c267ece43041e920fe769b96fa66acf98c455977fb1bbbe6d6876f',
                        '7bd5c702cbe7c53069de40e000a1e45cfa4eecce8f56a663c6f40b7f102d7819'),
                       ('7300088082bed80d48d45e02a0bf8dcff0a2b1957806f33d2f5fdd5fcf8964c7',
                        '7bd5c702cbe7c53069de40e000a1e45cfa4eecce8f56a663c6f40b7f102d7819'),
                       ('22f17050109169292a72965cf20f32bfb1317313e56e2ab3ff5a705c37e5ea5e',
                        '7bd5c702cbe7c53069de40e000a1e45cfa4eecce8f56a663c6f40b7f102d7819'),
                       ('88facf4ed43fe1a3f0fe5945508155fc80cf3b9b51cb3b4fdb7753bc9b9ff38d',
                        '7bd5c702cbe7c53069de40e000a1e45cfa4eecce8f56a663c6f40b7f102d7819'),
                       ('067aef6ff9cf5c9429b8481c420e7fb9da5bafe9d5c76ee053ed4622b9023357',
                        '7bd5c702cbe7c53069de40e000a1e45cfa4eecce8f56a663c6f40b7f102d7819'),
                       ('884c3fb163cc8a56e808d0e79112bfc7cdfbc3569da21cdd4c2b38630875e97b',
                        '7bd5c702cbe7c53069de40e000a1e45cfa4eecce8f56a663c6f40b7f102d7819'),
                       ('ea22bf79b39b490a91a904019c13e7c07da6c2cedfd1ecc2bd5bd9b64e68646f',
                        '7bd5c702cbe7c53069de40e000a1e45cfa4eecce8f56a663c6f40b7f102d7819'),
                       ('04c59dacc2699e0930f1048a03db5f42cc5cfece4aa8079aba15109c7769a026',
                        'e5e101acefb248739f4d518e378529e10ed21adcb98a583fad6d8e603a0d52e0'),
                       ('067aef6ff9cf5c9429b8481c420e7fb9da5bafe9d5c76ee053ed4622b9023357',
                        'e5e101acefb248739f4d518e378529e10ed21adcb98a583fad6d8e603a0d52e0'),
                       ('06d3e7925f4c602a67c81a60edb585ae946f0d472d39557595ed96d3b3a98d1b',
                        'e5e101acefb248739f4d518e378529e10ed21adcb98a583fad6d8e603a0d52e0'),
                       ('22f17050109169292a72965cf20f32bfb1317313e56e2ab3ff5a705c37e5ea5e',
                        'e5e101acefb248739f4d518e378529e10ed21adcb98a583fad6d8e603a0d52e0'),
                       ('3636a2e9e099d2f161e0a1a6ab5342f4c4fb502fadc0cb264fce41700ba09837',
                        'e5e101acefb248739f4d518e378529e10ed21adcb98a583fad6d8e603a0d52e0'),
                       ('7300088082bed80d48d45e02a0bf8dcff0a2b1957806f33d2f5fdd5fcf8964c7',
                        'e5e101acefb248739f4d518e378529e10ed21adcb98a583fad6d8e603a0d52e0'),
                       ('7bd5c702cbe7c53069de40e000a1e45cfa4eecce8f56a663c6f40b7f102d7819',
                        'e5e101acefb248739f4d518e378529e10ed21adcb98a583fad6d8e603a0d52e0'),
                       ('884c3fb163cc8a56e808d0e79112bfc7cdfbc3569da21cdd4c2b38630875e97b',
                        'e5e101acefb248739f4d518e378529e10ed21adcb98a583fad6d8e603a0d52e0'),
                       ('88facf4ed43fe1a3f0fe5945508155fc80cf3b9b51cb3b4fdb7753bc9b9ff38d',
                        'e5e101acefb248739f4d518e378529e10ed21adcb98a583fad6d8e603a0d52e0'),
                       ('916d4d0c6ec0eaa0cb1708abbfbe69fd63c90699ec0ddf87501b321244345cef',
                        'e5e101acefb248739f4d518e378529e10ed21adcb98a583fad6d8e603a0d52e0'),
                       ('98fc7de00e343ad677131521866f5ce72e5cb64c87887b213ce2b8643e0b767c',
                        'e5e101acefb248739f4d518e378529e10ed21adcb98a583fad6d8e603a0d52e0'),
                       ('c6e4c33d480642c247948df41c1f3a76d828ec174d5a105b26fd17b4767df6cb',
                        'e5e101acefb248739f4d518e378529e10ed21adcb98a583fad6d8e603a0d52e0'),
                       ('df52b4e688c267ece43041e920fe769b96fa66acf98c455977fb1bbbe6d6876f',
                        'e5e101acefb248739f4d518e378529e10ed21adcb98a583fad6d8e603a0d52e0'),
                       ('ea22bf79b39b490a91a904019c13e7c07da6c2cedfd1ecc2bd5bd9b64e68646f',
                        'e5e101acefb248739f4d518e378529e10ed21adcb98a583fad6d8e603a0d52e0'),
                       ('f6dba91f7d916f203e224b3c4d6c23ed0d5677b8cfeba75717b869c1f408510c',
                        'e5e101acefb248739f4d518e378529e10ed21adcb98a583fad6d8e603a0d52e0'),
                       ('04c59dacc2699e0930f1048a03db5f42cc5cfece4aa8079aba15109c7769a026',
                        '19a32c1761a2431a62b2c7f89e9170538890758e1ee1dc55ba340ad4d86c229e'),
                       ('067aef6ff9cf5c9429b8481c420e7fb9da5bafe9d5c76ee053ed4622b9023357',
                        '19a32c1761a2431a62b2c7f89e9170538890758e1ee1dc55ba340ad4d86c229e'),
                       ('06d3e7925f4c602a67c81a60edb585ae946f0d472d39557595ed96d3b3a98d1b',
                        '19a32c1761a2431a62b2c7f89e9170538890758e1ee1dc55ba340ad4d86c229e'),
                       ('22f17050109169292a72965cf20f32bfb1317313e56e2ab3ff5a705c37e5ea5e',
                        '19a32c1761a2431a62b2c7f89e9170538890758e1ee1dc55ba340ad4d86c229e'),
                       ('3636a2e9e099d2f161e0a1a6ab5342f4c4fb502fadc0cb264fce41700ba09837',
                        '19a32c1761a2431a62b2c7f89e9170538890758e1ee1dc55ba340ad4d86c229e'),
                       ('7300088082bed80d48d45e02a0bf8dcff0a2b1957806f33d2f5fdd5fcf8964c7',
                        '19a32c1761a2431a62b2c7f89e9170538890758e1ee1dc55ba340ad4d86c229e'),
                       ('7bd5c702cbe7c53069de40e000a1e45cfa4eecce8f56a663c6f40b7f102d7819',
                        '19a32c1761a2431a62b2c7f89e9170538890758e1ee1dc55ba340ad4d86c229e'),
                       ('884c3fb163cc8a56e808d0e79112bfc7cdfbc3569da21cdd4c2b38630875e97b',
                        '19a32c1761a2431a62b2c7f89e9170538890758e1ee1dc55ba340ad4d86c229e'),
                       ('88facf4ed43fe1a3f0fe5945508155fc80cf3b9b51cb3b4fdb7753bc9b9ff38d',
                        '19a32c1761a2431a62b2c7f89e9170538890758e1ee1dc55ba340ad4d86c229e'),
                       ('916d4d0c6ec0eaa0cb1708abbfbe69fd63c90699ec0ddf87501b321244345cef',
                        '19a32c1761a2431a62b2c7f89e9170538890758e1ee1dc55ba340ad4d86c229e'),
                       ('98fc7de00e343ad677131521866f5ce72e5cb64c87887b213ce2b8643e0b767c',
                        '19a32c1761a2431a62b2c7f89e9170538890758e1ee1dc55ba340ad4d86c229e'),
                       ('c6e4c33d480642c247948df41c1f3a76d828ec174d5a105b26fd17b4767df6cb',
                        '19a32c1761a2431a62b2c7f89e9170538890758e1ee1dc55ba340ad4d86c229e'),
                       ('df52b4e688c267ece43041e920fe769b96fa66acf98c455977fb1bbbe6d6876f',
                        '19a32c1761a2431a62b2c7f89e9170538890758e1ee1dc55ba340ad4d86c229e'),
                       ('e5e101acefb248739f4d518e378529e10ed21adcb98a583fad6d8e603a0d52e0',
                        '19a32c1761a2431a62b2c7f89e9170538890758e1ee1dc55ba340ad4d86c229e'),
                       ('ea22bf79b39b490a91a904019c13e7c07da6c2cedfd1ecc2bd5bd9b64e68646f',
                        '19a32c1761a2431a62b2c7f89e9170538890758e1ee1dc55ba340ad4d86c229e'),
                       ('f6dba91f7d916f203e224b3c4d6c23ed0d5677b8cfeba75717b869c1f408510c',
                        '19a32c1761a2431a62b2c7f89e9170538890758e1ee1dc55ba340ad4d86c229e'),
                       ('04c59dacc2699e0930f1048a03db5f42cc5cfece4aa8079aba15109c7769a026',
                        'e8978e604e8c09fee732870788cfc7a60ac5ef0225b6768ee61161889ff3109a'),
                       ('067aef6ff9cf5c9429b8481c420e7fb9da5bafe9d5c76ee053ed4622b9023357',
                        'e8978e604e8c09fee732870788cfc7a60ac5ef0225b6768ee61161889ff3109a'),
                       ('06d3e7925f4c602a67c81a60edb585ae946f0d472d39557595ed96d3b3a98d1b',
                        'e8978e604e8c09fee732870788cfc7a60ac5ef0225b6768ee61161889ff3109a'),
                       ('19a32c1761a2431a62b2c7f89e9170538890758e1ee1dc55ba340ad4d86c229e',
                        'e8978e604e8c09fee732870788cfc7a60ac5ef0225b6768ee61161889ff3109a'),
                       ('22f17050109169292a72965cf20f32bfb1317313e56e2ab3ff5a705c37e5ea5e',
                        'e8978e604e8c09fee732870788cfc7a60ac5ef0225b6768ee61161889ff3109a'),
                       ('3636a2e9e099d2f161e0a1a6ab5342f4c4fb502fadc0cb264fce41700ba09837',
                        'e8978e604e8c09fee732870788cfc7a60ac5ef0225b6768ee61161889ff3109a'),
                       ('7300088082bed80d48d45e02a0bf8dcff0a2b1957806f33d2f5fdd5fcf8964c7',
                        'e8978e604e8c09fee732870788cfc7a60ac5ef0225b6768ee61161889ff3109a'),
                       ('7bd5c702cbe7c53069de40e000a1e45cfa4eecce8f56a663c6f40b7f102d7819',
                        'e8978e604e8c09fee732870788cfc7a60ac5ef0225b6768ee61161889ff3109a'),
                       ('884c3fb163cc8a56e808d0e79112bfc7cdfbc3569da21cdd4c2b38630875e97b',
                        'e8978e604e8c09fee732870788cfc7a60ac5ef0225b6768ee61161889ff3109a'),
                       ('88facf4ed43fe1a3f0fe5945508155fc80cf3b9b51cb3b4fdb7753bc9b9ff38d',
                        'e8978e604e8c09fee732870788cfc7a60ac5ef0225b6768ee61161889ff3109a'),
                       ('916d4d0c6ec0eaa0cb1708abbfbe69fd63c90699ec0ddf87501b321244345cef',
                        'e8978e604e8c09fee732870788cfc7a60ac5ef0225b6768ee61161889ff3109a'),
                       ('98fc7de00e343ad677131521866f5ce72e5cb64c87887b213ce2b8643e0b767c',
                        'e8978e604e8c09fee732870788cfc7a60ac5ef0225b6768ee61161889ff3109a'),
                       ('c6e4c33d480642c247948df41c1f3a76d828ec174d5a105b26fd17b4767df6cb',
                        'e8978e604e8c09fee732870788cfc7a60ac5ef0225b6768ee61161889ff3109a'),
                       ('df52b4e688c267ece43041e920fe769b96fa66acf98c455977fb1bbbe6d6876f',
                        'e8978e604e8c09fee732870788cfc7a60ac5ef0225b6768ee61161889ff3109a'),
                       ('e5e101acefb248739f4d518e378529e10ed21adcb98a583fad6d8e603a0d52e0',
                        'e8978e604e8c09fee732870788cfc7a60ac5ef0225b6768ee61161889ff3109a'),
                       ('ea22bf79b39b490a91a904019c13e7c07da6c2cedfd1ecc2bd5bd9b64e68646f',
                        'e8978e604e8c09fee732870788cfc7a60ac5ef0225b6768ee61161889ff3109a'),
                       ('f6dba91f7d916f203e224b3c4d6c23ed0d5677b8cfeba75717b869c1f408510c',
                        'e8978e604e8c09fee732870788cfc7a60ac5ef0225b6768ee61161889ff3109a')],
 'EXECUTION_HANDOFF.md': [('26919191198cde741edf2a495cef3b4d155ae47de391e106b7be250483f3834a',
                           '4428885b81968acd90324419c7ab8b0aa92cf862977bbaaa2b601a53557c4ce9'),
                          ('68f28f904231d725d9563595b08c47fb7df23849a51653227c8635f53d80dbef',
                           '4428885b81968acd90324419c7ab8b0aa92cf862977bbaaa2b601a53557c4ce9'),
                          ('eab502f3375f75dbd7aa4b4cab5029c6a0751f1d6853f86f485b6af8bcb9b98c',
                           '4428885b81968acd90324419c7ab8b0aa92cf862977bbaaa2b601a53557c4ce9'),
                          ('23dbc357d61024c5a63500d2ae22e1eb7ce941939a1dd148adfba1c68c57aca2',
                           '4428885b81968acd90324419c7ab8b0aa92cf862977bbaaa2b601a53557c4ce9')],
 'NESTED_LOCO_PROTOCOL.md': [('05b3c9a6f4561e5e6410c90382209a5ac7a338390030df2e52e7e6c78d999aa6',
                              '13ec230a9864ce32f6df4020f3bf01c3df702f7ef5b03c2b78e1718cb0d12207'),
                             ('e0ddfa4fba0185227e70e9340b87187669c8fc5224b1201d5e47ad3d4adccb66',
                              '13ec230a9864ce32f6df4020f3bf01c3df702f7ef5b03c2b78e1718cb0d12207'),
                             ('f2d2d2f3e93523bf0c7068b40763f9eb007a130eb21758da870ae5265623f6fd',
                              '13ec230a9864ce32f6df4020f3bf01c3df702f7ef5b03c2b78e1718cb0d12207'),
                             ('0a0dca03cf81c7115cc46268e7786ee4cea5be04514284a1a363c8cad664d6f6',
                              '13ec230a9864ce32f6df4020f3bf01c3df702f7ef5b03c2b78e1718cb0d12207'),
                             ('c4412a34068ca5de8f521a3e389c1c8d70898898e3ab2b38ca7fb4e9c10c77bb',
                              '13ec230a9864ce32f6df4020f3bf01c3df702f7ef5b03c2b78e1718cb0d12207'),
                             ('cb52b7f05c2656d6e5ea72473aeab3dfe2a5b3b9946d84f6c21d0f4d430ed2d1',
                              '13ec230a9864ce32f6df4020f3bf01c3df702f7ef5b03c2b78e1718cb0d12207'),
                             ('ee8c7d4ae33f450fb63f493b92ec4249cdba4a2e508b897c60fa068ad27feaff',
                              '13ec230a9864ce32f6df4020f3bf01c3df702f7ef5b03c2b78e1718cb0d12207'),
                             ('da2b1c2b04bd07cad3126a3691e7a4c6f5a92b4f2dfb65a7e40c13852aa9812d',
                              '13ec230a9864ce32f6df4020f3bf01c3df702f7ef5b03c2b78e1718cb0d12207'),
                             ('99eb98e0952d8ddfd22f3819dca3d0abd3a0c3592fb5e5afd760ed494406e8ba',
                              '13ec230a9864ce32f6df4020f3bf01c3df702f7ef5b03c2b78e1718cb0d12207'),
                             ('4a5c7c9384d331451a956eb0b19901549ae428d92532809db4380e404828009c',
                              '13ec230a9864ce32f6df4020f3bf01c3df702f7ef5b03c2b78e1718cb0d12207'),
                             ('1333c601a311873a648c711ef3bd143582da9f107347b1ee94da87ce36d57a20',
                              '13ec230a9864ce32f6df4020f3bf01c3df702f7ef5b03c2b78e1718cb0d12207'),
                             ('6cbccda83b507b731ffcfcc1f158d2a7bdca1bc27080ca481809daadf34ffd38',
                              '13ec230a9864ce32f6df4020f3bf01c3df702f7ef5b03c2b78e1718cb0d12207'),
                             ('f235eb9766cfeceeb3c1c9510e348b9c2f664bd82327ad372413cab7fec76359',
                              '13ec230a9864ce32f6df4020f3bf01c3df702f7ef5b03c2b78e1718cb0d12207'),
                             ('64b5c04554e2a3db1cb17f6023d4c8271d99515f05c8a24d8c7195afc8adc154',
                              '13ec230a9864ce32f6df4020f3bf01c3df702f7ef5b03c2b78e1718cb0d12207'),
                             ('302cc25fb29d0c42cab8a7dcfa9880d2a986d8601968772efbf975fad877ecd4',
                              '13ec230a9864ce32f6df4020f3bf01c3df702f7ef5b03c2b78e1718cb0d12207'),
                             ('5b4f2a95bb652b24f0fe2a3f4a519b966294426bd67d791de825ce39590d3a95',
                              '13ec230a9864ce32f6df4020f3bf01c3df702f7ef5b03c2b78e1718cb0d12207'),
                             ('13ec230a9864ce32f6df4020f3bf01c3df702f7ef5b03c2b78e1718cb0d12207',
                              'fa631c05d95e0d8fef7e30125e22ef56360a022cb6bea650ef97ce1751f957bb'),
                             ('05b3c9a6f4561e5e6410c90382209a5ac7a338390030df2e52e7e6c78d999aa6',
                              'fa631c05d95e0d8fef7e30125e22ef56360a022cb6bea650ef97ce1751f957bb'),
                             ('e0ddfa4fba0185227e70e9340b87187669c8fc5224b1201d5e47ad3d4adccb66',
                              'fa631c05d95e0d8fef7e30125e22ef56360a022cb6bea650ef97ce1751f957bb'),
                             ('f2d2d2f3e93523bf0c7068b40763f9eb007a130eb21758da870ae5265623f6fd',
                              'fa631c05d95e0d8fef7e30125e22ef56360a022cb6bea650ef97ce1751f957bb'),
                             ('0a0dca03cf81c7115cc46268e7786ee4cea5be04514284a1a363c8cad664d6f6',
                              'fa631c05d95e0d8fef7e30125e22ef56360a022cb6bea650ef97ce1751f957bb'),
                             ('c4412a34068ca5de8f521a3e389c1c8d70898898e3ab2b38ca7fb4e9c10c77bb',
                              'fa631c05d95e0d8fef7e30125e22ef56360a022cb6bea650ef97ce1751f957bb'),
                             ('cb52b7f05c2656d6e5ea72473aeab3dfe2a5b3b9946d84f6c21d0f4d430ed2d1',
                              'fa631c05d95e0d8fef7e30125e22ef56360a022cb6bea650ef97ce1751f957bb'),
                             ('ee8c7d4ae33f450fb63f493b92ec4249cdba4a2e508b897c60fa068ad27feaff',
                              'fa631c05d95e0d8fef7e30125e22ef56360a022cb6bea650ef97ce1751f957bb'),
                             ('da2b1c2b04bd07cad3126a3691e7a4c6f5a92b4f2dfb65a7e40c13852aa9812d',
                              'fa631c05d95e0d8fef7e30125e22ef56360a022cb6bea650ef97ce1751f957bb'),
                             ('99eb98e0952d8ddfd22f3819dca3d0abd3a0c3592fb5e5afd760ed494406e8ba',
                              'fa631c05d95e0d8fef7e30125e22ef56360a022cb6bea650ef97ce1751f957bb'),
                             ('4a5c7c9384d331451a956eb0b19901549ae428d92532809db4380e404828009c',
                              'fa631c05d95e0d8fef7e30125e22ef56360a022cb6bea650ef97ce1751f957bb'),
                             ('1333c601a311873a648c711ef3bd143582da9f107347b1ee94da87ce36d57a20',
                              'fa631c05d95e0d8fef7e30125e22ef56360a022cb6bea650ef97ce1751f957bb'),
                             ('6cbccda83b507b731ffcfcc1f158d2a7bdca1bc27080ca481809daadf34ffd38',
                              'fa631c05d95e0d8fef7e30125e22ef56360a022cb6bea650ef97ce1751f957bb'),
                             ('f235eb9766cfeceeb3c1c9510e348b9c2f664bd82327ad372413cab7fec76359',
                              'fa631c05d95e0d8fef7e30125e22ef56360a022cb6bea650ef97ce1751f957bb'),
                             ('64b5c04554e2a3db1cb17f6023d4c8271d99515f05c8a24d8c7195afc8adc154',
                              'fa631c05d95e0d8fef7e30125e22ef56360a022cb6bea650ef97ce1751f957bb'),
                             ('302cc25fb29d0c42cab8a7dcfa9880d2a986d8601968772efbf975fad877ecd4',
                              'fa631c05d95e0d8fef7e30125e22ef56360a022cb6bea650ef97ce1751f957bb'),
                             ('5b4f2a95bb652b24f0fe2a3f4a519b966294426bd67d791de825ce39590d3a95',
                              'fa631c05d95e0d8fef7e30125e22ef56360a022cb6bea650ef97ce1751f957bb'),
                             ('fa631c05d95e0d8fef7e30125e22ef56360a022cb6bea650ef97ce1751f957bb',
                              'b9bbedc5be90039b7c6384cb9a66c0309764639ed76a778bbc3ccc6bc8f5b769'),
                             ('13ec230a9864ce32f6df4020f3bf01c3df702f7ef5b03c2b78e1718cb0d12207',
                              'b9bbedc5be90039b7c6384cb9a66c0309764639ed76a778bbc3ccc6bc8f5b769'),
                             ('05b3c9a6f4561e5e6410c90382209a5ac7a338390030df2e52e7e6c78d999aa6',
                              'b9bbedc5be90039b7c6384cb9a66c0309764639ed76a778bbc3ccc6bc8f5b769'),
                             ('e0ddfa4fba0185227e70e9340b87187669c8fc5224b1201d5e47ad3d4adccb66',
                              'b9bbedc5be90039b7c6384cb9a66c0309764639ed76a778bbc3ccc6bc8f5b769'),
                             ('f2d2d2f3e93523bf0c7068b40763f9eb007a130eb21758da870ae5265623f6fd',
                              'b9bbedc5be90039b7c6384cb9a66c0309764639ed76a778bbc3ccc6bc8f5b769'),
                             ('0a0dca03cf81c7115cc46268e7786ee4cea5be04514284a1a363c8cad664d6f6',
                              'b9bbedc5be90039b7c6384cb9a66c0309764639ed76a778bbc3ccc6bc8f5b769'),
                             ('c4412a34068ca5de8f521a3e389c1c8d70898898e3ab2b38ca7fb4e9c10c77bb',
                              'b9bbedc5be90039b7c6384cb9a66c0309764639ed76a778bbc3ccc6bc8f5b769'),
                             ('cb52b7f05c2656d6e5ea72473aeab3dfe2a5b3b9946d84f6c21d0f4d430ed2d1',
                              'b9bbedc5be90039b7c6384cb9a66c0309764639ed76a778bbc3ccc6bc8f5b769'),
                             ('ee8c7d4ae33f450fb63f493b92ec4249cdba4a2e508b897c60fa068ad27feaff',
                              'b9bbedc5be90039b7c6384cb9a66c0309764639ed76a778bbc3ccc6bc8f5b769'),
                             ('da2b1c2b04bd07cad3126a3691e7a4c6f5a92b4f2dfb65a7e40c13852aa9812d',
                              'b9bbedc5be90039b7c6384cb9a66c0309764639ed76a778bbc3ccc6bc8f5b769'),
                             ('99eb98e0952d8ddfd22f3819dca3d0abd3a0c3592fb5e5afd760ed494406e8ba',
                              'b9bbedc5be90039b7c6384cb9a66c0309764639ed76a778bbc3ccc6bc8f5b769'),
                             ('4a5c7c9384d331451a956eb0b19901549ae428d92532809db4380e404828009c',
                              'b9bbedc5be90039b7c6384cb9a66c0309764639ed76a778bbc3ccc6bc8f5b769'),
                             ('1333c601a311873a648c711ef3bd143582da9f107347b1ee94da87ce36d57a20',
                              'b9bbedc5be90039b7c6384cb9a66c0309764639ed76a778bbc3ccc6bc8f5b769'),
                             ('6cbccda83b507b731ffcfcc1f158d2a7bdca1bc27080ca481809daadf34ffd38',
                              'b9bbedc5be90039b7c6384cb9a66c0309764639ed76a778bbc3ccc6bc8f5b769'),
                             ('f235eb9766cfeceeb3c1c9510e348b9c2f664bd82327ad372413cab7fec76359',
                              'b9bbedc5be90039b7c6384cb9a66c0309764639ed76a778bbc3ccc6bc8f5b769'),
                             ('64b5c04554e2a3db1cb17f6023d4c8271d99515f05c8a24d8c7195afc8adc154',
                              'b9bbedc5be90039b7c6384cb9a66c0309764639ed76a778bbc3ccc6bc8f5b769'),
                             ('302cc25fb29d0c42cab8a7dcfa9880d2a986d8601968772efbf975fad877ecd4',
                              'b9bbedc5be90039b7c6384cb9a66c0309764639ed76a778bbc3ccc6bc8f5b769'),
                             ('5b4f2a95bb652b24f0fe2a3f4a519b966294426bd67d791de825ce39590d3a95',
                              'b9bbedc5be90039b7c6384cb9a66c0309764639ed76a778bbc3ccc6bc8f5b769'),
                             ('b9bbedc5be90039b7c6384cb9a66c0309764639ed76a778bbc3ccc6bc8f5b769',
                              'cccbc9b2ade7815d0938177107423bdc2564b8bc3148aa69b8808ef9df730ba3'),
                             ('fa631c05d95e0d8fef7e30125e22ef56360a022cb6bea650ef97ce1751f957bb',
                              'cccbc9b2ade7815d0938177107423bdc2564b8bc3148aa69b8808ef9df730ba3'),
                             ('13ec230a9864ce32f6df4020f3bf01c3df702f7ef5b03c2b78e1718cb0d12207',
                              'cccbc9b2ade7815d0938177107423bdc2564b8bc3148aa69b8808ef9df730ba3'),
                             ('05b3c9a6f4561e5e6410c90382209a5ac7a338390030df2e52e7e6c78d999aa6',
                              'cccbc9b2ade7815d0938177107423bdc2564b8bc3148aa69b8808ef9df730ba3'),
                             ('e0ddfa4fba0185227e70e9340b87187669c8fc5224b1201d5e47ad3d4adccb66',
                              'cccbc9b2ade7815d0938177107423bdc2564b8bc3148aa69b8808ef9df730ba3'),
                             ('f2d2d2f3e93523bf0c7068b40763f9eb007a130eb21758da870ae5265623f6fd',
                              'cccbc9b2ade7815d0938177107423bdc2564b8bc3148aa69b8808ef9df730ba3'),
                             ('0a0dca03cf81c7115cc46268e7786ee4cea5be04514284a1a363c8cad664d6f6',
                              'cccbc9b2ade7815d0938177107423bdc2564b8bc3148aa69b8808ef9df730ba3'),
                             ('c4412a34068ca5de8f521a3e389c1c8d70898898e3ab2b38ca7fb4e9c10c77bb',
                              'cccbc9b2ade7815d0938177107423bdc2564b8bc3148aa69b8808ef9df730ba3'),
                             ('cb52b7f05c2656d6e5ea72473aeab3dfe2a5b3b9946d84f6c21d0f4d430ed2d1',
                              'cccbc9b2ade7815d0938177107423bdc2564b8bc3148aa69b8808ef9df730ba3'),
                             ('ee8c7d4ae33f450fb63f493b92ec4249cdba4a2e508b897c60fa068ad27feaff',
                              'cccbc9b2ade7815d0938177107423bdc2564b8bc3148aa69b8808ef9df730ba3'),
                             ('da2b1c2b04bd07cad3126a3691e7a4c6f5a92b4f2dfb65a7e40c13852aa9812d',
                              'cccbc9b2ade7815d0938177107423bdc2564b8bc3148aa69b8808ef9df730ba3'),
                             ('99eb98e0952d8ddfd22f3819dca3d0abd3a0c3592fb5e5afd760ed494406e8ba',
                              'cccbc9b2ade7815d0938177107423bdc2564b8bc3148aa69b8808ef9df730ba3'),
                             ('4a5c7c9384d331451a956eb0b19901549ae428d92532809db4380e404828009c',
                              'cccbc9b2ade7815d0938177107423bdc2564b8bc3148aa69b8808ef9df730ba3'),
                             ('1333c601a311873a648c711ef3bd143582da9f107347b1ee94da87ce36d57a20',
                              'cccbc9b2ade7815d0938177107423bdc2564b8bc3148aa69b8808ef9df730ba3'),
                             ('6cbccda83b507b731ffcfcc1f158d2a7bdca1bc27080ca481809daadf34ffd38',
                              'cccbc9b2ade7815d0938177107423bdc2564b8bc3148aa69b8808ef9df730ba3'),
                             ('f235eb9766cfeceeb3c1c9510e348b9c2f664bd82327ad372413cab7fec76359',
                              'cccbc9b2ade7815d0938177107423bdc2564b8bc3148aa69b8808ef9df730ba3'),
                             ('64b5c04554e2a3db1cb17f6023d4c8271d99515f05c8a24d8c7195afc8adc154',
                              'cccbc9b2ade7815d0938177107423bdc2564b8bc3148aa69b8808ef9df730ba3'),
                             ('302cc25fb29d0c42cab8a7dcfa9880d2a986d8601968772efbf975fad877ecd4',
                              'cccbc9b2ade7815d0938177107423bdc2564b8bc3148aa69b8808ef9df730ba3'),
                             ('5b4f2a95bb652b24f0fe2a3f4a519b966294426bd67d791de825ce39590d3a95',
                              'cccbc9b2ade7815d0938177107423bdc2564b8bc3148aa69b8808ef9df730ba3'),
                             ('cccbc9b2ade7815d0938177107423bdc2564b8bc3148aa69b8808ef9df730ba3',
                              '2c6053bb0e94751bc04417e4899777dc551cf40ca35f1bd9e744c63a017cc62a'),
                             ('b9bbedc5be90039b7c6384cb9a66c0309764639ed76a778bbc3ccc6bc8f5b769',
                              '2c6053bb0e94751bc04417e4899777dc551cf40ca35f1bd9e744c63a017cc62a'),
                             ('fa631c05d95e0d8fef7e30125e22ef56360a022cb6bea650ef97ce1751f957bb',
                              '2c6053bb0e94751bc04417e4899777dc551cf40ca35f1bd9e744c63a017cc62a'),
                             ('13ec230a9864ce32f6df4020f3bf01c3df702f7ef5b03c2b78e1718cb0d12207',
                              '2c6053bb0e94751bc04417e4899777dc551cf40ca35f1bd9e744c63a017cc62a'),
                             ('05b3c9a6f4561e5e6410c90382209a5ac7a338390030df2e52e7e6c78d999aa6',
                              '2c6053bb0e94751bc04417e4899777dc551cf40ca35f1bd9e744c63a017cc62a'),
                             ('e0ddfa4fba0185227e70e9340b87187669c8fc5224b1201d5e47ad3d4adccb66',
                              '2c6053bb0e94751bc04417e4899777dc551cf40ca35f1bd9e744c63a017cc62a'),
                             ('f2d2d2f3e93523bf0c7068b40763f9eb007a130eb21758da870ae5265623f6fd',
                              '2c6053bb0e94751bc04417e4899777dc551cf40ca35f1bd9e744c63a017cc62a'),
                             ('0a0dca03cf81c7115cc46268e7786ee4cea5be04514284a1a363c8cad664d6f6',
                              '2c6053bb0e94751bc04417e4899777dc551cf40ca35f1bd9e744c63a017cc62a'),
                             ('c4412a34068ca5de8f521a3e389c1c8d70898898e3ab2b38ca7fb4e9c10c77bb',
                              '2c6053bb0e94751bc04417e4899777dc551cf40ca35f1bd9e744c63a017cc62a'),
                             ('cb52b7f05c2656d6e5ea72473aeab3dfe2a5b3b9946d84f6c21d0f4d430ed2d1',
                              '2c6053bb0e94751bc04417e4899777dc551cf40ca35f1bd9e744c63a017cc62a'),
                             ('ee8c7d4ae33f450fb63f493b92ec4249cdba4a2e508b897c60fa068ad27feaff',
                              '2c6053bb0e94751bc04417e4899777dc551cf40ca35f1bd9e744c63a017cc62a'),
                             ('da2b1c2b04bd07cad3126a3691e7a4c6f5a92b4f2dfb65a7e40c13852aa9812d',
                              '2c6053bb0e94751bc04417e4899777dc551cf40ca35f1bd9e744c63a017cc62a'),
                             ('99eb98e0952d8ddfd22f3819dca3d0abd3a0c3592fb5e5afd760ed494406e8ba',
                              '2c6053bb0e94751bc04417e4899777dc551cf40ca35f1bd9e744c63a017cc62a'),
                             ('4a5c7c9384d331451a956eb0b19901549ae428d92532809db4380e404828009c',
                              '2c6053bb0e94751bc04417e4899777dc551cf40ca35f1bd9e744c63a017cc62a'),
                             ('1333c601a311873a648c711ef3bd143582da9f107347b1ee94da87ce36d57a20',
                              '2c6053bb0e94751bc04417e4899777dc551cf40ca35f1bd9e744c63a017cc62a'),
                             ('6cbccda83b507b731ffcfcc1f158d2a7bdca1bc27080ca481809daadf34ffd38',
                              '2c6053bb0e94751bc04417e4899777dc551cf40ca35f1bd9e744c63a017cc62a'),
                             ('f235eb9766cfeceeb3c1c9510e348b9c2f664bd82327ad372413cab7fec76359',
                              '2c6053bb0e94751bc04417e4899777dc551cf40ca35f1bd9e744c63a017cc62a'),
                             ('64b5c04554e2a3db1cb17f6023d4c8271d99515f05c8a24d8c7195afc8adc154',
                              '2c6053bb0e94751bc04417e4899777dc551cf40ca35f1bd9e744c63a017cc62a'),
                             ('302cc25fb29d0c42cab8a7dcfa9880d2a986d8601968772efbf975fad877ecd4',
                              '2c6053bb0e94751bc04417e4899777dc551cf40ca35f1bd9e744c63a017cc62a'),
                             ('5b4f2a95bb652b24f0fe2a3f4a519b966294426bd67d791de825ce39590d3a95',
                              '2c6053bb0e94751bc04417e4899777dc551cf40ca35f1bd9e744c63a017cc62a'),
                             ('2c6053bb0e94751bc04417e4899777dc551cf40ca35f1bd9e744c63a017cc62a',
                              'fbada1a3a9a426e2c4272f39a68ecd2037aca5e0f3352f9452877f0314851d18'),
                             ('cccbc9b2ade7815d0938177107423bdc2564b8bc3148aa69b8808ef9df730ba3',
                              'fbada1a3a9a426e2c4272f39a68ecd2037aca5e0f3352f9452877f0314851d18'),
                             ('b9bbedc5be90039b7c6384cb9a66c0309764639ed76a778bbc3ccc6bc8f5b769',
                              'fbada1a3a9a426e2c4272f39a68ecd2037aca5e0f3352f9452877f0314851d18'),
                             ('fa631c05d95e0d8fef7e30125e22ef56360a022cb6bea650ef97ce1751f957bb',
                              'fbada1a3a9a426e2c4272f39a68ecd2037aca5e0f3352f9452877f0314851d18'),
                             ('13ec230a9864ce32f6df4020f3bf01c3df702f7ef5b03c2b78e1718cb0d12207',
                              'fbada1a3a9a426e2c4272f39a68ecd2037aca5e0f3352f9452877f0314851d18'),
                             ('05b3c9a6f4561e5e6410c90382209a5ac7a338390030df2e52e7e6c78d999aa6',
                              'fbada1a3a9a426e2c4272f39a68ecd2037aca5e0f3352f9452877f0314851d18'),
                             ('e0ddfa4fba0185227e70e9340b87187669c8fc5224b1201d5e47ad3d4adccb66',
                              'fbada1a3a9a426e2c4272f39a68ecd2037aca5e0f3352f9452877f0314851d18'),
                             ('f2d2d2f3e93523bf0c7068b40763f9eb007a130eb21758da870ae5265623f6fd',
                              'fbada1a3a9a426e2c4272f39a68ecd2037aca5e0f3352f9452877f0314851d18'),
                             ('0a0dca03cf81c7115cc46268e7786ee4cea5be04514284a1a363c8cad664d6f6',
                              'fbada1a3a9a426e2c4272f39a68ecd2037aca5e0f3352f9452877f0314851d18'),
                             ('c4412a34068ca5de8f521a3e389c1c8d70898898e3ab2b38ca7fb4e9c10c77bb',
                              'fbada1a3a9a426e2c4272f39a68ecd2037aca5e0f3352f9452877f0314851d18'),
                             ('cb52b7f05c2656d6e5ea72473aeab3dfe2a5b3b9946d84f6c21d0f4d430ed2d1',
                              'fbada1a3a9a426e2c4272f39a68ecd2037aca5e0f3352f9452877f0314851d18'),
                             ('ee8c7d4ae33f450fb63f493b92ec4249cdba4a2e508b897c60fa068ad27feaff',
                              'fbada1a3a9a426e2c4272f39a68ecd2037aca5e0f3352f9452877f0314851d18'),
                             ('da2b1c2b04bd07cad3126a3691e7a4c6f5a92b4f2dfb65a7e40c13852aa9812d',
                              'fbada1a3a9a426e2c4272f39a68ecd2037aca5e0f3352f9452877f0314851d18'),
                             ('99eb98e0952d8ddfd22f3819dca3d0abd3a0c3592fb5e5afd760ed494406e8ba',
                              'fbada1a3a9a426e2c4272f39a68ecd2037aca5e0f3352f9452877f0314851d18'),
                             ('4a5c7c9384d331451a956eb0b19901549ae428d92532809db4380e404828009c',
                              'fbada1a3a9a426e2c4272f39a68ecd2037aca5e0f3352f9452877f0314851d18'),
                             ('1333c601a311873a648c711ef3bd143582da9f107347b1ee94da87ce36d57a20',
                              'fbada1a3a9a426e2c4272f39a68ecd2037aca5e0f3352f9452877f0314851d18'),
                             ('6cbccda83b507b731ffcfcc1f158d2a7bdca1bc27080ca481809daadf34ffd38',
                              'fbada1a3a9a426e2c4272f39a68ecd2037aca5e0f3352f9452877f0314851d18'),
                             ('f235eb9766cfeceeb3c1c9510e348b9c2f664bd82327ad372413cab7fec76359',
                              'fbada1a3a9a426e2c4272f39a68ecd2037aca5e0f3352f9452877f0314851d18'),
                             ('64b5c04554e2a3db1cb17f6023d4c8271d99515f05c8a24d8c7195afc8adc154',
                              'fbada1a3a9a426e2c4272f39a68ecd2037aca5e0f3352f9452877f0314851d18'),
                             ('302cc25fb29d0c42cab8a7dcfa9880d2a986d8601968772efbf975fad877ecd4',
                              'fbada1a3a9a426e2c4272f39a68ecd2037aca5e0f3352f9452877f0314851d18'),
                             ('5b4f2a95bb652b24f0fe2a3f4a519b966294426bd67d791de825ce39590d3a95',
                              'fbada1a3a9a426e2c4272f39a68ecd2037aca5e0f3352f9452877f0314851d18'),
                             ('fbada1a3a9a426e2c4272f39a68ecd2037aca5e0f3352f9452877f0314851d18',
                              '57329240aa38f3f565a6e31b97cb2f3068ddf288ddb70ce0f2ebbcb59261034e'),
                             ('2c6053bb0e94751bc04417e4899777dc551cf40ca35f1bd9e744c63a017cc62a',
                              '57329240aa38f3f565a6e31b97cb2f3068ddf288ddb70ce0f2ebbcb59261034e'),
                             ('cccbc9b2ade7815d0938177107423bdc2564b8bc3148aa69b8808ef9df730ba3',
                              '57329240aa38f3f565a6e31b97cb2f3068ddf288ddb70ce0f2ebbcb59261034e'),
                             ('b9bbedc5be90039b7c6384cb9a66c0309764639ed76a778bbc3ccc6bc8f5b769',
                              '57329240aa38f3f565a6e31b97cb2f3068ddf288ddb70ce0f2ebbcb59261034e'),
                             ('fa631c05d95e0d8fef7e30125e22ef56360a022cb6bea650ef97ce1751f957bb',
                              '57329240aa38f3f565a6e31b97cb2f3068ddf288ddb70ce0f2ebbcb59261034e'),
                             ('13ec230a9864ce32f6df4020f3bf01c3df702f7ef5b03c2b78e1718cb0d12207',
                              '57329240aa38f3f565a6e31b97cb2f3068ddf288ddb70ce0f2ebbcb59261034e'),
                             ('05b3c9a6f4561e5e6410c90382209a5ac7a338390030df2e52e7e6c78d999aa6',
                              '57329240aa38f3f565a6e31b97cb2f3068ddf288ddb70ce0f2ebbcb59261034e'),
                             ('e0ddfa4fba0185227e70e9340b87187669c8fc5224b1201d5e47ad3d4adccb66',
                              '57329240aa38f3f565a6e31b97cb2f3068ddf288ddb70ce0f2ebbcb59261034e'),
                             ('f2d2d2f3e93523bf0c7068b40763f9eb007a130eb21758da870ae5265623f6fd',
                              '57329240aa38f3f565a6e31b97cb2f3068ddf288ddb70ce0f2ebbcb59261034e'),
                             ('0a0dca03cf81c7115cc46268e7786ee4cea5be04514284a1a363c8cad664d6f6',
                              '57329240aa38f3f565a6e31b97cb2f3068ddf288ddb70ce0f2ebbcb59261034e'),
                             ('c4412a34068ca5de8f521a3e389c1c8d70898898e3ab2b38ca7fb4e9c10c77bb',
                              '57329240aa38f3f565a6e31b97cb2f3068ddf288ddb70ce0f2ebbcb59261034e'),
                             ('cb52b7f05c2656d6e5ea72473aeab3dfe2a5b3b9946d84f6c21d0f4d430ed2d1',
                              '57329240aa38f3f565a6e31b97cb2f3068ddf288ddb70ce0f2ebbcb59261034e'),
                             ('ee8c7d4ae33f450fb63f493b92ec4249cdba4a2e508b897c60fa068ad27feaff',
                              '57329240aa38f3f565a6e31b97cb2f3068ddf288ddb70ce0f2ebbcb59261034e'),
                             ('da2b1c2b04bd07cad3126a3691e7a4c6f5a92b4f2dfb65a7e40c13852aa9812d',
                              '57329240aa38f3f565a6e31b97cb2f3068ddf288ddb70ce0f2ebbcb59261034e'),
                             ('99eb98e0952d8ddfd22f3819dca3d0abd3a0c3592fb5e5afd760ed494406e8ba',
                              '57329240aa38f3f565a6e31b97cb2f3068ddf288ddb70ce0f2ebbcb59261034e'),
                             ('4a5c7c9384d331451a956eb0b19901549ae428d92532809db4380e404828009c',
                              '57329240aa38f3f565a6e31b97cb2f3068ddf288ddb70ce0f2ebbcb59261034e'),
                             ('1333c601a311873a648c711ef3bd143582da9f107347b1ee94da87ce36d57a20',
                              '57329240aa38f3f565a6e31b97cb2f3068ddf288ddb70ce0f2ebbcb59261034e'),
                             ('6cbccda83b507b731ffcfcc1f158d2a7bdca1bc27080ca481809daadf34ffd38',
                              '57329240aa38f3f565a6e31b97cb2f3068ddf288ddb70ce0f2ebbcb59261034e'),
                             ('f235eb9766cfeceeb3c1c9510e348b9c2f664bd82327ad372413cab7fec76359',
                              '57329240aa38f3f565a6e31b97cb2f3068ddf288ddb70ce0f2ebbcb59261034e'),
                             ('64b5c04554e2a3db1cb17f6023d4c8271d99515f05c8a24d8c7195afc8adc154',
                              '57329240aa38f3f565a6e31b97cb2f3068ddf288ddb70ce0f2ebbcb59261034e'),
                             ('302cc25fb29d0c42cab8a7dcfa9880d2a986d8601968772efbf975fad877ecd4',
                              '57329240aa38f3f565a6e31b97cb2f3068ddf288ddb70ce0f2ebbcb59261034e'),
                             ('5b4f2a95bb652b24f0fe2a3f4a519b966294426bd67d791de825ce39590d3a95',
                              '57329240aa38f3f565a6e31b97cb2f3068ddf288ddb70ce0f2ebbcb59261034e'),
                             ('05b3c9a6f4561e5e6410c90382209a5ac7a338390030df2e52e7e6c78d999aa6',
                              '9ddcfd50f5ca521b43fe14755e40ddbd3e9b5c6082328a0651ca8ff5c61f470c'),
                             ('0a0dca03cf81c7115cc46268e7786ee4cea5be04514284a1a363c8cad664d6f6',
                              '9ddcfd50f5ca521b43fe14755e40ddbd3e9b5c6082328a0651ca8ff5c61f470c'),
                             ('1333c601a311873a648c711ef3bd143582da9f107347b1ee94da87ce36d57a20',
                              '9ddcfd50f5ca521b43fe14755e40ddbd3e9b5c6082328a0651ca8ff5c61f470c'),
                             ('13ec230a9864ce32f6df4020f3bf01c3df702f7ef5b03c2b78e1718cb0d12207',
                              '9ddcfd50f5ca521b43fe14755e40ddbd3e9b5c6082328a0651ca8ff5c61f470c'),
                             ('2c6053bb0e94751bc04417e4899777dc551cf40ca35f1bd9e744c63a017cc62a',
                              '9ddcfd50f5ca521b43fe14755e40ddbd3e9b5c6082328a0651ca8ff5c61f470c'),
                             ('302cc25fb29d0c42cab8a7dcfa9880d2a986d8601968772efbf975fad877ecd4',
                              '9ddcfd50f5ca521b43fe14755e40ddbd3e9b5c6082328a0651ca8ff5c61f470c'),
                             ('4a5c7c9384d331451a956eb0b19901549ae428d92532809db4380e404828009c',
                              '9ddcfd50f5ca521b43fe14755e40ddbd3e9b5c6082328a0651ca8ff5c61f470c'),
                             ('57329240aa38f3f565a6e31b97cb2f3068ddf288ddb70ce0f2ebbcb59261034e',
                              '9ddcfd50f5ca521b43fe14755e40ddbd3e9b5c6082328a0651ca8ff5c61f470c'),
                             ('5b4f2a95bb652b24f0fe2a3f4a519b966294426bd67d791de825ce39590d3a95',
                              '9ddcfd50f5ca521b43fe14755e40ddbd3e9b5c6082328a0651ca8ff5c61f470c'),
                             ('64b5c04554e2a3db1cb17f6023d4c8271d99515f05c8a24d8c7195afc8adc154',
                              '9ddcfd50f5ca521b43fe14755e40ddbd3e9b5c6082328a0651ca8ff5c61f470c'),
                             ('6cbccda83b507b731ffcfcc1f158d2a7bdca1bc27080ca481809daadf34ffd38',
                              '9ddcfd50f5ca521b43fe14755e40ddbd3e9b5c6082328a0651ca8ff5c61f470c'),
                             ('99eb98e0952d8ddfd22f3819dca3d0abd3a0c3592fb5e5afd760ed494406e8ba',
                              '9ddcfd50f5ca521b43fe14755e40ddbd3e9b5c6082328a0651ca8ff5c61f470c'),
                             ('b9bbedc5be90039b7c6384cb9a66c0309764639ed76a778bbc3ccc6bc8f5b769',
                              '9ddcfd50f5ca521b43fe14755e40ddbd3e9b5c6082328a0651ca8ff5c61f470c'),
                             ('c4412a34068ca5de8f521a3e389c1c8d70898898e3ab2b38ca7fb4e9c10c77bb',
                              '9ddcfd50f5ca521b43fe14755e40ddbd3e9b5c6082328a0651ca8ff5c61f470c'),
                             ('cb52b7f05c2656d6e5ea72473aeab3dfe2a5b3b9946d84f6c21d0f4d430ed2d1',
                              '9ddcfd50f5ca521b43fe14755e40ddbd3e9b5c6082328a0651ca8ff5c61f470c'),
                             ('cccbc9b2ade7815d0938177107423bdc2564b8bc3148aa69b8808ef9df730ba3',
                              '9ddcfd50f5ca521b43fe14755e40ddbd3e9b5c6082328a0651ca8ff5c61f470c'),
                             ('da2b1c2b04bd07cad3126a3691e7a4c6f5a92b4f2dfb65a7e40c13852aa9812d',
                              '9ddcfd50f5ca521b43fe14755e40ddbd3e9b5c6082328a0651ca8ff5c61f470c'),
                             ('e0ddfa4fba0185227e70e9340b87187669c8fc5224b1201d5e47ad3d4adccb66',
                              '9ddcfd50f5ca521b43fe14755e40ddbd3e9b5c6082328a0651ca8ff5c61f470c'),
                             ('ee8c7d4ae33f450fb63f493b92ec4249cdba4a2e508b897c60fa068ad27feaff',
                              '9ddcfd50f5ca521b43fe14755e40ddbd3e9b5c6082328a0651ca8ff5c61f470c'),
                             ('f235eb9766cfeceeb3c1c9510e348b9c2f664bd82327ad372413cab7fec76359',
                              '9ddcfd50f5ca521b43fe14755e40ddbd3e9b5c6082328a0651ca8ff5c61f470c'),
                             ('f2d2d2f3e93523bf0c7068b40763f9eb007a130eb21758da870ae5265623f6fd',
                              '9ddcfd50f5ca521b43fe14755e40ddbd3e9b5c6082328a0651ca8ff5c61f470c'),
                             ('fa631c05d95e0d8fef7e30125e22ef56360a022cb6bea650ef97ce1751f957bb',
                              '9ddcfd50f5ca521b43fe14755e40ddbd3e9b5c6082328a0651ca8ff5c61f470c'),
                             ('fbada1a3a9a426e2c4272f39a68ecd2037aca5e0f3352f9452877f0314851d18',
                              '9ddcfd50f5ca521b43fe14755e40ddbd3e9b5c6082328a0651ca8ff5c61f470c'),
                             ('05b3c9a6f4561e5e6410c90382209a5ac7a338390030df2e52e7e6c78d999aa6',
                              '26dadb879d114c7242be2773fbd6c2c76cbdcd407c7dbd852b57598b45d4ee6b'),
                             ('0a0dca03cf81c7115cc46268e7786ee4cea5be04514284a1a363c8cad664d6f6',
                              '26dadb879d114c7242be2773fbd6c2c76cbdcd407c7dbd852b57598b45d4ee6b'),
                             ('1333c601a311873a648c711ef3bd143582da9f107347b1ee94da87ce36d57a20',
                              '26dadb879d114c7242be2773fbd6c2c76cbdcd407c7dbd852b57598b45d4ee6b'),
                             ('13ec230a9864ce32f6df4020f3bf01c3df702f7ef5b03c2b78e1718cb0d12207',
                              '26dadb879d114c7242be2773fbd6c2c76cbdcd407c7dbd852b57598b45d4ee6b'),
                             ('2c6053bb0e94751bc04417e4899777dc551cf40ca35f1bd9e744c63a017cc62a',
                              '26dadb879d114c7242be2773fbd6c2c76cbdcd407c7dbd852b57598b45d4ee6b'),
                             ('302cc25fb29d0c42cab8a7dcfa9880d2a986d8601968772efbf975fad877ecd4',
                              '26dadb879d114c7242be2773fbd6c2c76cbdcd407c7dbd852b57598b45d4ee6b'),
                             ('4a5c7c9384d331451a956eb0b19901549ae428d92532809db4380e404828009c',
                              '26dadb879d114c7242be2773fbd6c2c76cbdcd407c7dbd852b57598b45d4ee6b'),
                             ('57329240aa38f3f565a6e31b97cb2f3068ddf288ddb70ce0f2ebbcb59261034e',
                              '26dadb879d114c7242be2773fbd6c2c76cbdcd407c7dbd852b57598b45d4ee6b'),
                             ('5b4f2a95bb652b24f0fe2a3f4a519b966294426bd67d791de825ce39590d3a95',
                              '26dadb879d114c7242be2773fbd6c2c76cbdcd407c7dbd852b57598b45d4ee6b'),
                             ('64b5c04554e2a3db1cb17f6023d4c8271d99515f05c8a24d8c7195afc8adc154',
                              '26dadb879d114c7242be2773fbd6c2c76cbdcd407c7dbd852b57598b45d4ee6b'),
                             ('6cbccda83b507b731ffcfcc1f158d2a7bdca1bc27080ca481809daadf34ffd38',
                              '26dadb879d114c7242be2773fbd6c2c76cbdcd407c7dbd852b57598b45d4ee6b'),
                             ('99eb98e0952d8ddfd22f3819dca3d0abd3a0c3592fb5e5afd760ed494406e8ba',
                              '26dadb879d114c7242be2773fbd6c2c76cbdcd407c7dbd852b57598b45d4ee6b'),
                             ('9ddcfd50f5ca521b43fe14755e40ddbd3e9b5c6082328a0651ca8ff5c61f470c',
                              '26dadb879d114c7242be2773fbd6c2c76cbdcd407c7dbd852b57598b45d4ee6b'),
                             ('b9bbedc5be90039b7c6384cb9a66c0309764639ed76a778bbc3ccc6bc8f5b769',
                              '26dadb879d114c7242be2773fbd6c2c76cbdcd407c7dbd852b57598b45d4ee6b'),
                             ('c4412a34068ca5de8f521a3e389c1c8d70898898e3ab2b38ca7fb4e9c10c77bb',
                              '26dadb879d114c7242be2773fbd6c2c76cbdcd407c7dbd852b57598b45d4ee6b'),
                             ('cb52b7f05c2656d6e5ea72473aeab3dfe2a5b3b9946d84f6c21d0f4d430ed2d1',
                              '26dadb879d114c7242be2773fbd6c2c76cbdcd407c7dbd852b57598b45d4ee6b'),
                             ('cccbc9b2ade7815d0938177107423bdc2564b8bc3148aa69b8808ef9df730ba3',
                              '26dadb879d114c7242be2773fbd6c2c76cbdcd407c7dbd852b57598b45d4ee6b'),
                             ('da2b1c2b04bd07cad3126a3691e7a4c6f5a92b4f2dfb65a7e40c13852aa9812d',
                              '26dadb879d114c7242be2773fbd6c2c76cbdcd407c7dbd852b57598b45d4ee6b'),
                             ('e0ddfa4fba0185227e70e9340b87187669c8fc5224b1201d5e47ad3d4adccb66',
                              '26dadb879d114c7242be2773fbd6c2c76cbdcd407c7dbd852b57598b45d4ee6b'),
                             ('ee8c7d4ae33f450fb63f493b92ec4249cdba4a2e508b897c60fa068ad27feaff',
                              '26dadb879d114c7242be2773fbd6c2c76cbdcd407c7dbd852b57598b45d4ee6b'),
                             ('f235eb9766cfeceeb3c1c9510e348b9c2f664bd82327ad372413cab7fec76359',
                              '26dadb879d114c7242be2773fbd6c2c76cbdcd407c7dbd852b57598b45d4ee6b'),
                             ('f2d2d2f3e93523bf0c7068b40763f9eb007a130eb21758da870ae5265623f6fd',
                              '26dadb879d114c7242be2773fbd6c2c76cbdcd407c7dbd852b57598b45d4ee6b'),
                             ('fa631c05d95e0d8fef7e30125e22ef56360a022cb6bea650ef97ce1751f957bb',
                              '26dadb879d114c7242be2773fbd6c2c76cbdcd407c7dbd852b57598b45d4ee6b'),
                             ('fbada1a3a9a426e2c4272f39a68ecd2037aca5e0f3352f9452877f0314851d18',
                              '26dadb879d114c7242be2773fbd6c2c76cbdcd407c7dbd852b57598b45d4ee6b'),
                             ('05b3c9a6f4561e5e6410c90382209a5ac7a338390030df2e52e7e6c78d999aa6',
                              '67194a1f0b78ee523b40125ca2d3c21689afc4845fecc5020c726cda61d6e8e6'),
                             ('0a0dca03cf81c7115cc46268e7786ee4cea5be04514284a1a363c8cad664d6f6',
                              '67194a1f0b78ee523b40125ca2d3c21689afc4845fecc5020c726cda61d6e8e6'),
                             ('1333c601a311873a648c711ef3bd143582da9f107347b1ee94da87ce36d57a20',
                              '67194a1f0b78ee523b40125ca2d3c21689afc4845fecc5020c726cda61d6e8e6'),
                             ('13ec230a9864ce32f6df4020f3bf01c3df702f7ef5b03c2b78e1718cb0d12207',
                              '67194a1f0b78ee523b40125ca2d3c21689afc4845fecc5020c726cda61d6e8e6'),
                             ('26dadb879d114c7242be2773fbd6c2c76cbdcd407c7dbd852b57598b45d4ee6b',
                              '67194a1f0b78ee523b40125ca2d3c21689afc4845fecc5020c726cda61d6e8e6'),
                             ('2c6053bb0e94751bc04417e4899777dc551cf40ca35f1bd9e744c63a017cc62a',
                              '67194a1f0b78ee523b40125ca2d3c21689afc4845fecc5020c726cda61d6e8e6'),
                             ('302cc25fb29d0c42cab8a7dcfa9880d2a986d8601968772efbf975fad877ecd4',
                              '67194a1f0b78ee523b40125ca2d3c21689afc4845fecc5020c726cda61d6e8e6'),
                             ('4a5c7c9384d331451a956eb0b19901549ae428d92532809db4380e404828009c',
                              '67194a1f0b78ee523b40125ca2d3c21689afc4845fecc5020c726cda61d6e8e6'),
                             ('57329240aa38f3f565a6e31b97cb2f3068ddf288ddb70ce0f2ebbcb59261034e',
                              '67194a1f0b78ee523b40125ca2d3c21689afc4845fecc5020c726cda61d6e8e6'),
                             ('5b4f2a95bb652b24f0fe2a3f4a519b966294426bd67d791de825ce39590d3a95',
                              '67194a1f0b78ee523b40125ca2d3c21689afc4845fecc5020c726cda61d6e8e6'),
                             ('64b5c04554e2a3db1cb17f6023d4c8271d99515f05c8a24d8c7195afc8adc154',
                              '67194a1f0b78ee523b40125ca2d3c21689afc4845fecc5020c726cda61d6e8e6'),
                             ('6cbccda83b507b731ffcfcc1f158d2a7bdca1bc27080ca481809daadf34ffd38',
                              '67194a1f0b78ee523b40125ca2d3c21689afc4845fecc5020c726cda61d6e8e6'),
                             ('99eb98e0952d8ddfd22f3819dca3d0abd3a0c3592fb5e5afd760ed494406e8ba',
                              '67194a1f0b78ee523b40125ca2d3c21689afc4845fecc5020c726cda61d6e8e6'),
                             ('9ddcfd50f5ca521b43fe14755e40ddbd3e9b5c6082328a0651ca8ff5c61f470c',
                              '67194a1f0b78ee523b40125ca2d3c21689afc4845fecc5020c726cda61d6e8e6'),
                             ('b9bbedc5be90039b7c6384cb9a66c0309764639ed76a778bbc3ccc6bc8f5b769',
                              '67194a1f0b78ee523b40125ca2d3c21689afc4845fecc5020c726cda61d6e8e6'),
                             ('c4412a34068ca5de8f521a3e389c1c8d70898898e3ab2b38ca7fb4e9c10c77bb',
                              '67194a1f0b78ee523b40125ca2d3c21689afc4845fecc5020c726cda61d6e8e6'),
                             ('cb52b7f05c2656d6e5ea72473aeab3dfe2a5b3b9946d84f6c21d0f4d430ed2d1',
                              '67194a1f0b78ee523b40125ca2d3c21689afc4845fecc5020c726cda61d6e8e6'),
                             ('cccbc9b2ade7815d0938177107423bdc2564b8bc3148aa69b8808ef9df730ba3',
                              '67194a1f0b78ee523b40125ca2d3c21689afc4845fecc5020c726cda61d6e8e6'),
                             ('da2b1c2b04bd07cad3126a3691e7a4c6f5a92b4f2dfb65a7e40c13852aa9812d',
                              '67194a1f0b78ee523b40125ca2d3c21689afc4845fecc5020c726cda61d6e8e6'),
                             ('e0ddfa4fba0185227e70e9340b87187669c8fc5224b1201d5e47ad3d4adccb66',
                              '67194a1f0b78ee523b40125ca2d3c21689afc4845fecc5020c726cda61d6e8e6'),
                             ('ee8c7d4ae33f450fb63f493b92ec4249cdba4a2e508b897c60fa068ad27feaff',
                              '67194a1f0b78ee523b40125ca2d3c21689afc4845fecc5020c726cda61d6e8e6'),
                             ('f235eb9766cfeceeb3c1c9510e348b9c2f664bd82327ad372413cab7fec76359',
                              '67194a1f0b78ee523b40125ca2d3c21689afc4845fecc5020c726cda61d6e8e6'),
                             ('f2d2d2f3e93523bf0c7068b40763f9eb007a130eb21758da870ae5265623f6fd',
                              '67194a1f0b78ee523b40125ca2d3c21689afc4845fecc5020c726cda61d6e8e6'),
                             ('fa631c05d95e0d8fef7e30125e22ef56360a022cb6bea650ef97ce1751f957bb',
                              '67194a1f0b78ee523b40125ca2d3c21689afc4845fecc5020c726cda61d6e8e6'),
                             ('fbada1a3a9a426e2c4272f39a68ecd2037aca5e0f3352f9452877f0314851d18',
                              '67194a1f0b78ee523b40125ca2d3c21689afc4845fecc5020c726cda61d6e8e6'),
                             ('05b3c9a6f4561e5e6410c90382209a5ac7a338390030df2e52e7e6c78d999aa6',
                              '7998ae8a76cfb20afefd0664b97a44bd32ba80b12e08ee2d629fb22a0c265625'),
                             ('0a0dca03cf81c7115cc46268e7786ee4cea5be04514284a1a363c8cad664d6f6',
                              '7998ae8a76cfb20afefd0664b97a44bd32ba80b12e08ee2d629fb22a0c265625'),
                             ('1333c601a311873a648c711ef3bd143582da9f107347b1ee94da87ce36d57a20',
                              '7998ae8a76cfb20afefd0664b97a44bd32ba80b12e08ee2d629fb22a0c265625'),
                             ('13ec230a9864ce32f6df4020f3bf01c3df702f7ef5b03c2b78e1718cb0d12207',
                              '7998ae8a76cfb20afefd0664b97a44bd32ba80b12e08ee2d629fb22a0c265625'),
                             ('26dadb879d114c7242be2773fbd6c2c76cbdcd407c7dbd852b57598b45d4ee6b',
                              '7998ae8a76cfb20afefd0664b97a44bd32ba80b12e08ee2d629fb22a0c265625'),
                             ('2c6053bb0e94751bc04417e4899777dc551cf40ca35f1bd9e744c63a017cc62a',
                              '7998ae8a76cfb20afefd0664b97a44bd32ba80b12e08ee2d629fb22a0c265625'),
                             ('302cc25fb29d0c42cab8a7dcfa9880d2a986d8601968772efbf975fad877ecd4',
                              '7998ae8a76cfb20afefd0664b97a44bd32ba80b12e08ee2d629fb22a0c265625'),
                             ('4a5c7c9384d331451a956eb0b19901549ae428d92532809db4380e404828009c',
                              '7998ae8a76cfb20afefd0664b97a44bd32ba80b12e08ee2d629fb22a0c265625'),
                             ('57329240aa38f3f565a6e31b97cb2f3068ddf288ddb70ce0f2ebbcb59261034e',
                              '7998ae8a76cfb20afefd0664b97a44bd32ba80b12e08ee2d629fb22a0c265625'),
                             ('5b4f2a95bb652b24f0fe2a3f4a519b966294426bd67d791de825ce39590d3a95',
                              '7998ae8a76cfb20afefd0664b97a44bd32ba80b12e08ee2d629fb22a0c265625'),
                             ('64b5c04554e2a3db1cb17f6023d4c8271d99515f05c8a24d8c7195afc8adc154',
                              '7998ae8a76cfb20afefd0664b97a44bd32ba80b12e08ee2d629fb22a0c265625'),
                             ('67194a1f0b78ee523b40125ca2d3c21689afc4845fecc5020c726cda61d6e8e6',
                              '7998ae8a76cfb20afefd0664b97a44bd32ba80b12e08ee2d629fb22a0c265625'),
                             ('6cbccda83b507b731ffcfcc1f158d2a7bdca1bc27080ca481809daadf34ffd38',
                              '7998ae8a76cfb20afefd0664b97a44bd32ba80b12e08ee2d629fb22a0c265625'),
                             ('99eb98e0952d8ddfd22f3819dca3d0abd3a0c3592fb5e5afd760ed494406e8ba',
                              '7998ae8a76cfb20afefd0664b97a44bd32ba80b12e08ee2d629fb22a0c265625'),
                             ('9ddcfd50f5ca521b43fe14755e40ddbd3e9b5c6082328a0651ca8ff5c61f470c',
                              '7998ae8a76cfb20afefd0664b97a44bd32ba80b12e08ee2d629fb22a0c265625'),
                             ('b9bbedc5be90039b7c6384cb9a66c0309764639ed76a778bbc3ccc6bc8f5b769',
                              '7998ae8a76cfb20afefd0664b97a44bd32ba80b12e08ee2d629fb22a0c265625'),
                             ('c4412a34068ca5de8f521a3e389c1c8d70898898e3ab2b38ca7fb4e9c10c77bb',
                              '7998ae8a76cfb20afefd0664b97a44bd32ba80b12e08ee2d629fb22a0c265625'),
                             ('cb52b7f05c2656d6e5ea72473aeab3dfe2a5b3b9946d84f6c21d0f4d430ed2d1',
                              '7998ae8a76cfb20afefd0664b97a44bd32ba80b12e08ee2d629fb22a0c265625'),
                             ('cccbc9b2ade7815d0938177107423bdc2564b8bc3148aa69b8808ef9df730ba3',
                              '7998ae8a76cfb20afefd0664b97a44bd32ba80b12e08ee2d629fb22a0c265625'),
                             ('da2b1c2b04bd07cad3126a3691e7a4c6f5a92b4f2dfb65a7e40c13852aa9812d',
                              '7998ae8a76cfb20afefd0664b97a44bd32ba80b12e08ee2d629fb22a0c265625'),
                             ('e0ddfa4fba0185227e70e9340b87187669c8fc5224b1201d5e47ad3d4adccb66',
                              '7998ae8a76cfb20afefd0664b97a44bd32ba80b12e08ee2d629fb22a0c265625'),
                             ('ee8c7d4ae33f450fb63f493b92ec4249cdba4a2e508b897c60fa068ad27feaff',
                              '7998ae8a76cfb20afefd0664b97a44bd32ba80b12e08ee2d629fb22a0c265625'),
                             ('f235eb9766cfeceeb3c1c9510e348b9c2f664bd82327ad372413cab7fec76359',
                              '7998ae8a76cfb20afefd0664b97a44bd32ba80b12e08ee2d629fb22a0c265625'),
                             ('f2d2d2f3e93523bf0c7068b40763f9eb007a130eb21758da870ae5265623f6fd',
                              '7998ae8a76cfb20afefd0664b97a44bd32ba80b12e08ee2d629fb22a0c265625'),
                             ('fa631c05d95e0d8fef7e30125e22ef56360a022cb6bea650ef97ce1751f957bb',
                              '7998ae8a76cfb20afefd0664b97a44bd32ba80b12e08ee2d629fb22a0c265625'),
                             ('fbada1a3a9a426e2c4272f39a68ecd2037aca5e0f3352f9452877f0314851d18',
                              '7998ae8a76cfb20afefd0664b97a44bd32ba80b12e08ee2d629fb22a0c265625'),
                             ('05b3c9a6f4561e5e6410c90382209a5ac7a338390030df2e52e7e6c78d999aa6',
                              'd6b26419ad688fdc6a435c66237e45fe526d20a8519300683eb217e2cff4cf60'),
                             ('0a0dca03cf81c7115cc46268e7786ee4cea5be04514284a1a363c8cad664d6f6',
                              'd6b26419ad688fdc6a435c66237e45fe526d20a8519300683eb217e2cff4cf60'),
                             ('1333c601a311873a648c711ef3bd143582da9f107347b1ee94da87ce36d57a20',
                              'd6b26419ad688fdc6a435c66237e45fe526d20a8519300683eb217e2cff4cf60'),
                             ('13ec230a9864ce32f6df4020f3bf01c3df702f7ef5b03c2b78e1718cb0d12207',
                              'd6b26419ad688fdc6a435c66237e45fe526d20a8519300683eb217e2cff4cf60'),
                             ('26dadb879d114c7242be2773fbd6c2c76cbdcd407c7dbd852b57598b45d4ee6b',
                              'd6b26419ad688fdc6a435c66237e45fe526d20a8519300683eb217e2cff4cf60'),
                             ('2c6053bb0e94751bc04417e4899777dc551cf40ca35f1bd9e744c63a017cc62a',
                              'd6b26419ad688fdc6a435c66237e45fe526d20a8519300683eb217e2cff4cf60'),
                             ('302cc25fb29d0c42cab8a7dcfa9880d2a986d8601968772efbf975fad877ecd4',
                              'd6b26419ad688fdc6a435c66237e45fe526d20a8519300683eb217e2cff4cf60'),
                             ('4a5c7c9384d331451a956eb0b19901549ae428d92532809db4380e404828009c',
                              'd6b26419ad688fdc6a435c66237e45fe526d20a8519300683eb217e2cff4cf60'),
                             ('57329240aa38f3f565a6e31b97cb2f3068ddf288ddb70ce0f2ebbcb59261034e',
                              'd6b26419ad688fdc6a435c66237e45fe526d20a8519300683eb217e2cff4cf60'),
                             ('5b4f2a95bb652b24f0fe2a3f4a519b966294426bd67d791de825ce39590d3a95',
                              'd6b26419ad688fdc6a435c66237e45fe526d20a8519300683eb217e2cff4cf60'),
                             ('64b5c04554e2a3db1cb17f6023d4c8271d99515f05c8a24d8c7195afc8adc154',
                              'd6b26419ad688fdc6a435c66237e45fe526d20a8519300683eb217e2cff4cf60'),
                             ('67194a1f0b78ee523b40125ca2d3c21689afc4845fecc5020c726cda61d6e8e6',
                              'd6b26419ad688fdc6a435c66237e45fe526d20a8519300683eb217e2cff4cf60'),
                             ('6cbccda83b507b731ffcfcc1f158d2a7bdca1bc27080ca481809daadf34ffd38',
                              'd6b26419ad688fdc6a435c66237e45fe526d20a8519300683eb217e2cff4cf60'),
                             ('7998ae8a76cfb20afefd0664b97a44bd32ba80b12e08ee2d629fb22a0c265625',
                              'd6b26419ad688fdc6a435c66237e45fe526d20a8519300683eb217e2cff4cf60'),
                             ('99eb98e0952d8ddfd22f3819dca3d0abd3a0c3592fb5e5afd760ed494406e8ba',
                              'd6b26419ad688fdc6a435c66237e45fe526d20a8519300683eb217e2cff4cf60'),
                             ('9ddcfd50f5ca521b43fe14755e40ddbd3e9b5c6082328a0651ca8ff5c61f470c',
                              'd6b26419ad688fdc6a435c66237e45fe526d20a8519300683eb217e2cff4cf60'),
                             ('b9bbedc5be90039b7c6384cb9a66c0309764639ed76a778bbc3ccc6bc8f5b769',
                              'd6b26419ad688fdc6a435c66237e45fe526d20a8519300683eb217e2cff4cf60'),
                             ('c4412a34068ca5de8f521a3e389c1c8d70898898e3ab2b38ca7fb4e9c10c77bb',
                              'd6b26419ad688fdc6a435c66237e45fe526d20a8519300683eb217e2cff4cf60'),
                             ('cb52b7f05c2656d6e5ea72473aeab3dfe2a5b3b9946d84f6c21d0f4d430ed2d1',
                              'd6b26419ad688fdc6a435c66237e45fe526d20a8519300683eb217e2cff4cf60'),
                             ('cccbc9b2ade7815d0938177107423bdc2564b8bc3148aa69b8808ef9df730ba3',
                              'd6b26419ad688fdc6a435c66237e45fe526d20a8519300683eb217e2cff4cf60'),
                             ('da2b1c2b04bd07cad3126a3691e7a4c6f5a92b4f2dfb65a7e40c13852aa9812d',
                              'd6b26419ad688fdc6a435c66237e45fe526d20a8519300683eb217e2cff4cf60'),
                             ('e0ddfa4fba0185227e70e9340b87187669c8fc5224b1201d5e47ad3d4adccb66',
                              'd6b26419ad688fdc6a435c66237e45fe526d20a8519300683eb217e2cff4cf60'),
                             ('ee8c7d4ae33f450fb63f493b92ec4249cdba4a2e508b897c60fa068ad27feaff',
                              'd6b26419ad688fdc6a435c66237e45fe526d20a8519300683eb217e2cff4cf60'),
                             ('f235eb9766cfeceeb3c1c9510e348b9c2f664bd82327ad372413cab7fec76359',
                              'd6b26419ad688fdc6a435c66237e45fe526d20a8519300683eb217e2cff4cf60'),
                             ('f2d2d2f3e93523bf0c7068b40763f9eb007a130eb21758da870ae5265623f6fd',
                              'd6b26419ad688fdc6a435c66237e45fe526d20a8519300683eb217e2cff4cf60'),
                             ('fa631c05d95e0d8fef7e30125e22ef56360a022cb6bea650ef97ce1751f957bb',
                              'd6b26419ad688fdc6a435c66237e45fe526d20a8519300683eb217e2cff4cf60'),
                             ('fbada1a3a9a426e2c4272f39a68ecd2037aca5e0f3352f9452877f0314851d18',
                              'd6b26419ad688fdc6a435c66237e45fe526d20a8519300683eb217e2cff4cf60')],
 'README.md': [('ae178e9d907a4ac72199a4003a97b61918f7a87f24afd4f7261f325332828998',
                'b402cdd93a7e191d855f475c44278a3093f812e0fc6d2d2e47429a55e7e6d412')],
 'config/environment.example.json': [('3e6470b9783fa67c3087dbed441558b1e56061f9164ad45718044fc612270f02',
                                      'e3dd38238549a9d209e8d6f0713b09835f3a66c01de78ac4213e029367d314fc')],
 'dependency-lock.json': [('1e60b06713411771c0dd626b035f0169e2eaa8358627fcdd93e4a7ca6b449208',
                           '436e9e3431bc7d3e338f2eda8422d7ff79f4c1688d0a6d04961afd642e3b9f36')],
 'padml/auc_research.py': [('e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
                            '7deb9c55deacc6a7921ea0e3580a368a56fa5d91a207f5433ddca8830adf7185')],
 'padml/bundle.py': [('1bde8a3e4474548f264c8ec1ce62bcad3b46546f7e838304059b8acdcc4c01ac',
                      '626eb912d532a4406b3898b80702ce5031cdd44b7b8b2c03807887229832ff3e'),
                     ('42c6ebe50d531ead6287fe125455a46b9733706dace6f1808ff53ff4118d2560',
                      '626eb912d532a4406b3898b80702ce5031cdd44b7b8b2c03807887229832ff3e')],
 'padml/carriers.py': [('9d5e66284483cc03eb823f478e90d5085e65cebd7a60a6639be6e186ebab71d5',
                        '29ed9276a9441c0dc6bf7de88c59b3ea70c523c86ab0551b7e0697ee9ac5a79b'),
                       ('a03b82e825b4a094032616e32c1d6c9a029774b1c5d1fe778b4f8a2410185194',
                        '29ed9276a9441c0dc6bf7de88c59b3ea70c523c86ab0551b7e0697ee9ac5a79b'),
                       ('a38aa33b851d68cb3593e776cd08e1b1041d179d64a990b5051e4d70516d8b96',
                        '29ed9276a9441c0dc6bf7de88c59b3ea70c523c86ab0551b7e0697ee9ac5a79b'),
                       ('4eb5ff2de3b34a21a998a02eee16aaf2fbf32962a89133073d7861de1b42ebc9',
                        '29ed9276a9441c0dc6bf7de88c59b3ea70c523c86ab0551b7e0697ee9ac5a79b'),
                       ('29ed9276a9441c0dc6bf7de88c59b3ea70c523c86ab0551b7e0697ee9ac5a79b',
                        '0e1bbb509dea360b126038b4bd8050c3103ec05c27de886fec963204974286bd'),
                       ('9d5e66284483cc03eb823f478e90d5085e65cebd7a60a6639be6e186ebab71d5',
                        '0e1bbb509dea360b126038b4bd8050c3103ec05c27de886fec963204974286bd'),
                       ('a03b82e825b4a094032616e32c1d6c9a029774b1c5d1fe778b4f8a2410185194',
                        '0e1bbb509dea360b126038b4bd8050c3103ec05c27de886fec963204974286bd'),
                       ('a38aa33b851d68cb3593e776cd08e1b1041d179d64a990b5051e4d70516d8b96',
                        '0e1bbb509dea360b126038b4bd8050c3103ec05c27de886fec963204974286bd'),
                       ('4eb5ff2de3b34a21a998a02eee16aaf2fbf32962a89133073d7861de1b42ebc9',
                        '0e1bbb509dea360b126038b4bd8050c3103ec05c27de886fec963204974286bd')],
 'padml/curve_rmse.py': [('e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
                          '68b4b67a243e8c9750c80fc4b820c868dc87266d9056ad4ac94b21a2c52fd9a4'),
                         ('68b4b67a243e8c9750c80fc4b820c868dc87266d9056ad4ac94b21a2c52fd9a4',
                          'e5e6d5034fc4fa715912b84073a713ccd490d6f45d2f16b09527b1bb042f321d'),
                         ('e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
                          'e5e6d5034fc4fa715912b84073a713ccd490d6f45d2f16b09527b1bb042f321d'),
                         ('e5e6d5034fc4fa715912b84073a713ccd490d6f45d2f16b09527b1bb042f321d',
                          'ed7334d55f4b95342e93b34439d4c35e162672e97dfc6a83cbeead4f92facf2f'),
                         ('68b4b67a243e8c9750c80fc4b820c868dc87266d9056ad4ac94b21a2c52fd9a4',
                          'ed7334d55f4b95342e93b34439d4c35e162672e97dfc6a83cbeead4f92facf2f'),
                         ('e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
                          'ed7334d55f4b95342e93b34439d4c35e162672e97dfc6a83cbeead4f92facf2f'),
                         ('68b4b67a243e8c9750c80fc4b820c868dc87266d9056ad4ac94b21a2c52fd9a4',
                          'f453d5e72e0cffbd24c869cbb52d7a61151dd645c277647586645587a917966a'),
                         ('e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
                          'f453d5e72e0cffbd24c869cbb52d7a61151dd645c277647586645587a917966a'),
                         ('e5e6d5034fc4fa715912b84073a713ccd490d6f45d2f16b09527b1bb042f321d',
                          'f453d5e72e0cffbd24c869cbb52d7a61151dd645c277647586645587a917966a'),
                         ('ed7334d55f4b95342e93b34439d4c35e162672e97dfc6a83cbeead4f92facf2f',
                          'f453d5e72e0cffbd24c869cbb52d7a61151dd645c277647586645587a917966a')],
 'padml/diagnostics.py': [('69f6a5cf8a741e413535106642e33d154ae3a7f373ba39a8df1740735c75c3f2',
                           'd6672a1489bca9710d31b79e987ae988544cc712011a63e76001e8285538fcd4'),
                          ('aced19dd40f077fb4cb584168a1ca5d6d93fc31a693a57effd56c095e69960bc',
                           'd6672a1489bca9710d31b79e987ae988544cc712011a63e76001e8285538fcd4'),
                          ('f9123dd884f6f108e5ed3104e461f00ad38a351c02b2ada5e3e14a444a0c86e6',
                           'd6672a1489bca9710d31b79e987ae988544cc712011a63e76001e8285538fcd4')],
 'padml/evaluation_extension.py': [('e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
                                    '3366dae72757bec88c9e708efa1d46b0a2e2e76bd5ea3ed57be2b895e07ad3ad'),
                                   ('3366dae72757bec88c9e708efa1d46b0a2e2e76bd5ea3ed57be2b895e07ad3ad',
                                    '7856e030d7ffbee125b27629e59a1c9bf69ffe7a7597bd7076fac4ca566d5b4e'),
                                   ('e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
                                    '7856e030d7ffbee125b27629e59a1c9bf69ffe7a7597bd7076fac4ca566d5b4e')],
 'padml/f1_kernel.py': [('5b9cf7dee028f58a560dbcaf313db0e768c2746221634ddc11a987870dd8eb29',
                         'd3d559b6637191e1cd9d8e78ad3835c962c70fceadb55be4d78c7ead8c49fb68'),
                        ('e43929988011a2b8f7b0225bae0abd62c22fe89889b4d56535dbaa1d247fb1b4',
                         'd3d559b6637191e1cd9d8e78ad3835c962c70fceadb55be4d78c7ead8c49fb68')],
 'padml/f2_kernel.py': [('5af5f01fb9675d81bb091a87faa5817b441a7f72e9f0ba6346ad8cb43f9820d7',
                         '3e68204f6678fb13216005a875abd910373ddf35dffb5aa6afad6af8b80ac2ab'),
                        ('fa96c942ff6280b217bf056ff47ea58fbd7a2463f693adb378af9131641163f1',
                         '3e68204f6678fb13216005a875abd910373ddf35dffb5aa6afad6af8b80ac2ab'),
                        ('442282756368e47d5dd4f48ed0563e082a2b31ff204d0faa3139cdaaa5fa7cf2',
                         '3e68204f6678fb13216005a875abd910373ddf35dffb5aa6afad6af8b80ac2ab'),
                        ('20134dc0b08726deb0bec701d34c96b917ad2664b627771dae0ff87aafb7d2ce',
                         '3e68204f6678fb13216005a875abd910373ddf35dffb5aa6afad6af8b80ac2ab'),
                        ('37c01302e6124ee1704b6603e624115a75d0e6af14cf43df987eb08c58a9a9ae',
                         '3e68204f6678fb13216005a875abd910373ddf35dffb5aa6afad6af8b80ac2ab')],
 'padml/f2_validation.py': [('f238793eee0f61660d08c1c201c8959f99ee8fd88841e87cdd95dcd924c588aa',
                             '6968267c6cf4a76ca5a5400ba19a84638efc4c35f3ad3f0c19b82d371af68970')],
 'padml/f4.py': [('3ea61c70462010e51415f4cd01cebd2583dd4379d988f943d684f0cdfec3ca28',
                  'b7813f6c84fa81bdd5543ac30782f3805b9fddc2c7805997d620c2d40038531f'),
                 ('3e9daf79ded5c5d269cee3789e14940a47708b23150eb815b5caeffa45b7b05e',
                  'b7813f6c84fa81bdd5543ac30782f3805b9fddc2c7805997d620c2d40038531f'),
                 ('5161f1433501c7fe4103a3519ce6a76d2623b64a09994b3f6028026ca51c2bc3',
                  'b7813f6c84fa81bdd5543ac30782f3805b9fddc2c7805997d620c2d40038531f'),
                 ('3e5e932455fad1383a1705067113bac83d31e8a1a55e62e686b2a0fc5a5f5b95',
                  'b7813f6c84fa81bdd5543ac30782f3805b9fddc2c7805997d620c2d40038531f'),
                 ('3ce89f18ab9aabedb3e7aa8970fea2772602ae22909a03da56db96de8a91e9e3',
                  'b7813f6c84fa81bdd5543ac30782f3805b9fddc2c7805997d620c2d40038531f'),
                 ('8cb3096825b15ea4f4e696030e409a0198e4cb156d97499c634128b356279208',
                  'b7813f6c84fa81bdd5543ac30782f3805b9fddc2c7805997d620c2d40038531f'),
                 ('5ed2fd42f14916425f42bda5e574ec10c544fc4e2aab8d4839a7eaf74f3da7cf',
                  'b7813f6c84fa81bdd5543ac30782f3805b9fddc2c7805997d620c2d40038531f'),
                 ('6bd9e25a314aa2acbbcc2c0f3da978238488ad0498c94caa694c6e71428b3ffe',
                  'b7813f6c84fa81bdd5543ac30782f3805b9fddc2c7805997d620c2d40038531f'),
                 ('45d4d533def24abe9c9190c710dd420d67ebace3be69278cf42db5a2694df6d3',
                  'b7813f6c84fa81bdd5543ac30782f3805b9fddc2c7805997d620c2d40038531f'),
                 ('b7813f6c84fa81bdd5543ac30782f3805b9fddc2c7805997d620c2d40038531f',
                  'd1919c4a4c3e29c7361ad824e29e9344b89806d73dd686ca462a0e0050ccab53'),
                 ('3ea61c70462010e51415f4cd01cebd2583dd4379d988f943d684f0cdfec3ca28',
                  'd1919c4a4c3e29c7361ad824e29e9344b89806d73dd686ca462a0e0050ccab53'),
                 ('3e9daf79ded5c5d269cee3789e14940a47708b23150eb815b5caeffa45b7b05e',
                  'd1919c4a4c3e29c7361ad824e29e9344b89806d73dd686ca462a0e0050ccab53'),
                 ('5161f1433501c7fe4103a3519ce6a76d2623b64a09994b3f6028026ca51c2bc3',
                  'd1919c4a4c3e29c7361ad824e29e9344b89806d73dd686ca462a0e0050ccab53'),
                 ('3e5e932455fad1383a1705067113bac83d31e8a1a55e62e686b2a0fc5a5f5b95',
                  'd1919c4a4c3e29c7361ad824e29e9344b89806d73dd686ca462a0e0050ccab53'),
                 ('3ce89f18ab9aabedb3e7aa8970fea2772602ae22909a03da56db96de8a91e9e3',
                  'd1919c4a4c3e29c7361ad824e29e9344b89806d73dd686ca462a0e0050ccab53'),
                 ('8cb3096825b15ea4f4e696030e409a0198e4cb156d97499c634128b356279208',
                  'd1919c4a4c3e29c7361ad824e29e9344b89806d73dd686ca462a0e0050ccab53'),
                 ('5ed2fd42f14916425f42bda5e574ec10c544fc4e2aab8d4839a7eaf74f3da7cf',
                  'd1919c4a4c3e29c7361ad824e29e9344b89806d73dd686ca462a0e0050ccab53'),
                 ('6bd9e25a314aa2acbbcc2c0f3da978238488ad0498c94caa694c6e71428b3ffe',
                  'd1919c4a4c3e29c7361ad824e29e9344b89806d73dd686ca462a0e0050ccab53'),
                 ('45d4d533def24abe9c9190c710dd420d67ebace3be69278cf42db5a2694df6d3',
                  'd1919c4a4c3e29c7361ad824e29e9344b89806d73dd686ca462a0e0050ccab53'),
                 ('d1919c4a4c3e29c7361ad824e29e9344b89806d73dd686ca462a0e0050ccab53',
                  '86c7573fab912bd1dd9fdbcc60ef748c28a625623551f01ec24c33267e8afc7c'),
                 ('b7813f6c84fa81bdd5543ac30782f3805b9fddc2c7805997d620c2d40038531f',
                  '86c7573fab912bd1dd9fdbcc60ef748c28a625623551f01ec24c33267e8afc7c'),
                 ('3ea61c70462010e51415f4cd01cebd2583dd4379d988f943d684f0cdfec3ca28',
                  '86c7573fab912bd1dd9fdbcc60ef748c28a625623551f01ec24c33267e8afc7c'),
                 ('3e9daf79ded5c5d269cee3789e14940a47708b23150eb815b5caeffa45b7b05e',
                  '86c7573fab912bd1dd9fdbcc60ef748c28a625623551f01ec24c33267e8afc7c'),
                 ('5161f1433501c7fe4103a3519ce6a76d2623b64a09994b3f6028026ca51c2bc3',
                  '86c7573fab912bd1dd9fdbcc60ef748c28a625623551f01ec24c33267e8afc7c'),
                 ('3e5e932455fad1383a1705067113bac83d31e8a1a55e62e686b2a0fc5a5f5b95',
                  '86c7573fab912bd1dd9fdbcc60ef748c28a625623551f01ec24c33267e8afc7c'),
                 ('3ce89f18ab9aabedb3e7aa8970fea2772602ae22909a03da56db96de8a91e9e3',
                  '86c7573fab912bd1dd9fdbcc60ef748c28a625623551f01ec24c33267e8afc7c'),
                 ('8cb3096825b15ea4f4e696030e409a0198e4cb156d97499c634128b356279208',
                  '86c7573fab912bd1dd9fdbcc60ef748c28a625623551f01ec24c33267e8afc7c'),
                 ('5ed2fd42f14916425f42bda5e574ec10c544fc4e2aab8d4839a7eaf74f3da7cf',
                  '86c7573fab912bd1dd9fdbcc60ef748c28a625623551f01ec24c33267e8afc7c'),
                 ('6bd9e25a314aa2acbbcc2c0f3da978238488ad0498c94caa694c6e71428b3ffe',
                  '86c7573fab912bd1dd9fdbcc60ef748c28a625623551f01ec24c33267e8afc7c'),
                 ('45d4d533def24abe9c9190c710dd420d67ebace3be69278cf42db5a2694df6d3',
                  '86c7573fab912bd1dd9fdbcc60ef748c28a625623551f01ec24c33267e8afc7c'),
                 ('3ce89f18ab9aabedb3e7aa8970fea2772602ae22909a03da56db96de8a91e9e3',
                  'd0244a11509d6ae7956fe8e94e1b6f589370a05c01fcfe61989230671146fb4d'),
                 ('3e5e932455fad1383a1705067113bac83d31e8a1a55e62e686b2a0fc5a5f5b95',
                  'd0244a11509d6ae7956fe8e94e1b6f589370a05c01fcfe61989230671146fb4d'),
                 ('3e9daf79ded5c5d269cee3789e14940a47708b23150eb815b5caeffa45b7b05e',
                  'd0244a11509d6ae7956fe8e94e1b6f589370a05c01fcfe61989230671146fb4d'),
                 ('3ea61c70462010e51415f4cd01cebd2583dd4379d988f943d684f0cdfec3ca28',
                  'd0244a11509d6ae7956fe8e94e1b6f589370a05c01fcfe61989230671146fb4d'),
                 ('45d4d533def24abe9c9190c710dd420d67ebace3be69278cf42db5a2694df6d3',
                  'd0244a11509d6ae7956fe8e94e1b6f589370a05c01fcfe61989230671146fb4d'),
                 ('5161f1433501c7fe4103a3519ce6a76d2623b64a09994b3f6028026ca51c2bc3',
                  'd0244a11509d6ae7956fe8e94e1b6f589370a05c01fcfe61989230671146fb4d'),
                 ('5ed2fd42f14916425f42bda5e574ec10c544fc4e2aab8d4839a7eaf74f3da7cf',
                  'd0244a11509d6ae7956fe8e94e1b6f589370a05c01fcfe61989230671146fb4d'),
                 ('6bd9e25a314aa2acbbcc2c0f3da978238488ad0498c94caa694c6e71428b3ffe',
                  'd0244a11509d6ae7956fe8e94e1b6f589370a05c01fcfe61989230671146fb4d'),
                 ('86c7573fab912bd1dd9fdbcc60ef748c28a625623551f01ec24c33267e8afc7c',
                  'd0244a11509d6ae7956fe8e94e1b6f589370a05c01fcfe61989230671146fb4d'),
                 ('8cb3096825b15ea4f4e696030e409a0198e4cb156d97499c634128b356279208',
                  'd0244a11509d6ae7956fe8e94e1b6f589370a05c01fcfe61989230671146fb4d'),
                 ('b7813f6c84fa81bdd5543ac30782f3805b9fddc2c7805997d620c2d40038531f',
                  'd0244a11509d6ae7956fe8e94e1b6f589370a05c01fcfe61989230671146fb4d'),
                 ('d1919c4a4c3e29c7361ad824e29e9344b89806d73dd686ca462a0e0050ccab53',
                  'd0244a11509d6ae7956fe8e94e1b6f589370a05c01fcfe61989230671146fb4d'),
                 ('3ce89f18ab9aabedb3e7aa8970fea2772602ae22909a03da56db96de8a91e9e3',
                  'b6d0a3b8387fbcaae1c39abe48958e10210163c2768d8e3330af5e65df454317'),
                 ('3e5e932455fad1383a1705067113bac83d31e8a1a55e62e686b2a0fc5a5f5b95',
                  'b6d0a3b8387fbcaae1c39abe48958e10210163c2768d8e3330af5e65df454317'),
                 ('3e9daf79ded5c5d269cee3789e14940a47708b23150eb815b5caeffa45b7b05e',
                  'b6d0a3b8387fbcaae1c39abe48958e10210163c2768d8e3330af5e65df454317'),
                 ('3ea61c70462010e51415f4cd01cebd2583dd4379d988f943d684f0cdfec3ca28',
                  'b6d0a3b8387fbcaae1c39abe48958e10210163c2768d8e3330af5e65df454317'),
                 ('45d4d533def24abe9c9190c710dd420d67ebace3be69278cf42db5a2694df6d3',
                  'b6d0a3b8387fbcaae1c39abe48958e10210163c2768d8e3330af5e65df454317'),
                 ('5161f1433501c7fe4103a3519ce6a76d2623b64a09994b3f6028026ca51c2bc3',
                  'b6d0a3b8387fbcaae1c39abe48958e10210163c2768d8e3330af5e65df454317'),
                 ('5ed2fd42f14916425f42bda5e574ec10c544fc4e2aab8d4839a7eaf74f3da7cf',
                  'b6d0a3b8387fbcaae1c39abe48958e10210163c2768d8e3330af5e65df454317'),
                 ('6bd9e25a314aa2acbbcc2c0f3da978238488ad0498c94caa694c6e71428b3ffe',
                  'b6d0a3b8387fbcaae1c39abe48958e10210163c2768d8e3330af5e65df454317'),
                 ('86c7573fab912bd1dd9fdbcc60ef748c28a625623551f01ec24c33267e8afc7c',
                  'b6d0a3b8387fbcaae1c39abe48958e10210163c2768d8e3330af5e65df454317'),
                 ('8cb3096825b15ea4f4e696030e409a0198e4cb156d97499c634128b356279208',
                  'b6d0a3b8387fbcaae1c39abe48958e10210163c2768d8e3330af5e65df454317'),
                 ('b7813f6c84fa81bdd5543ac30782f3805b9fddc2c7805997d620c2d40038531f',
                  'b6d0a3b8387fbcaae1c39abe48958e10210163c2768d8e3330af5e65df454317'),
                 ('d0244a11509d6ae7956fe8e94e1b6f589370a05c01fcfe61989230671146fb4d',
                  'b6d0a3b8387fbcaae1c39abe48958e10210163c2768d8e3330af5e65df454317'),
                 ('d1919c4a4c3e29c7361ad824e29e9344b89806d73dd686ca462a0e0050ccab53',
                  'b6d0a3b8387fbcaae1c39abe48958e10210163c2768d8e3330af5e65df454317'),
                 ('3ce89f18ab9aabedb3e7aa8970fea2772602ae22909a03da56db96de8a91e9e3',
                  'd62387d2bb414d6cae3de5557fa41131cf2159d2719cf47a40e1450b5c77c388'),
                 ('3e5e932455fad1383a1705067113bac83d31e8a1a55e62e686b2a0fc5a5f5b95',
                  'd62387d2bb414d6cae3de5557fa41131cf2159d2719cf47a40e1450b5c77c388'),
                 ('3e9daf79ded5c5d269cee3789e14940a47708b23150eb815b5caeffa45b7b05e',
                  'd62387d2bb414d6cae3de5557fa41131cf2159d2719cf47a40e1450b5c77c388'),
                 ('3ea61c70462010e51415f4cd01cebd2583dd4379d988f943d684f0cdfec3ca28',
                  'd62387d2bb414d6cae3de5557fa41131cf2159d2719cf47a40e1450b5c77c388'),
                 ('45d4d533def24abe9c9190c710dd420d67ebace3be69278cf42db5a2694df6d3',
                  'd62387d2bb414d6cae3de5557fa41131cf2159d2719cf47a40e1450b5c77c388'),
                 ('5161f1433501c7fe4103a3519ce6a76d2623b64a09994b3f6028026ca51c2bc3',
                  'd62387d2bb414d6cae3de5557fa41131cf2159d2719cf47a40e1450b5c77c388'),
                 ('5ed2fd42f14916425f42bda5e574ec10c544fc4e2aab8d4839a7eaf74f3da7cf',
                  'd62387d2bb414d6cae3de5557fa41131cf2159d2719cf47a40e1450b5c77c388'),
                 ('6bd9e25a314aa2acbbcc2c0f3da978238488ad0498c94caa694c6e71428b3ffe',
                  'd62387d2bb414d6cae3de5557fa41131cf2159d2719cf47a40e1450b5c77c388'),
                 ('86c7573fab912bd1dd9fdbcc60ef748c28a625623551f01ec24c33267e8afc7c',
                  'd62387d2bb414d6cae3de5557fa41131cf2159d2719cf47a40e1450b5c77c388'),
                 ('8cb3096825b15ea4f4e696030e409a0198e4cb156d97499c634128b356279208',
                  'd62387d2bb414d6cae3de5557fa41131cf2159d2719cf47a40e1450b5c77c388'),
                 ('b6d0a3b8387fbcaae1c39abe48958e10210163c2768d8e3330af5e65df454317',
                  'd62387d2bb414d6cae3de5557fa41131cf2159d2719cf47a40e1450b5c77c388'),
                 ('b7813f6c84fa81bdd5543ac30782f3805b9fddc2c7805997d620c2d40038531f',
                  'd62387d2bb414d6cae3de5557fa41131cf2159d2719cf47a40e1450b5c77c388'),
                 ('d0244a11509d6ae7956fe8e94e1b6f589370a05c01fcfe61989230671146fb4d',
                  'd62387d2bb414d6cae3de5557fa41131cf2159d2719cf47a40e1450b5c77c388'),
                 ('d1919c4a4c3e29c7361ad824e29e9344b89806d73dd686ca462a0e0050ccab53',
                  'd62387d2bb414d6cae3de5557fa41131cf2159d2719cf47a40e1450b5c77c388')],
 'padml/f4_compact.py': [('206d1f7337185398a64ff43d2f162230c0ef38dd0a5bfba8b1cf8e8dd979e160',
                          'aed180cc00dda1fa37a9108d867e947ce34c8a9dce6593c0edaaba0409d1a105'),
                         ('3d9fae3934e0c90e20f29615ed03a93a720674348699a9ce153e6590409b8e06',
                          'aed180cc00dda1fa37a9108d867e947ce34c8a9dce6593c0edaaba0409d1a105'),
                         ('35bfa2a5d36e12f671cdced4c92add6f142be7a2ec8d0f73b34606ac398a47dc',
                          'aed180cc00dda1fa37a9108d867e947ce34c8a9dce6593c0edaaba0409d1a105')],
 'padml/f5.py': [('b6d56d499314fd0ee590de6202bb1bcddd734436a86c3609f99cb98c7e6843f1',
                  '256efb8632d1d963114a9f096059de5bdfbe23dee7794615ea8a69c1f2954e5b'),
                 ('6df7ade27abf45d1fb6a18a8e1b77a8732dee5436fdd61e6ed5b963593242679',
                  '256efb8632d1d963114a9f096059de5bdfbe23dee7794615ea8a69c1f2954e5b'),
                 ('b37ac2c2b41259ff010cfc92cca2ca8159626a8e3686541f080f95c116bfb164',
                  '256efb8632d1d963114a9f096059de5bdfbe23dee7794615ea8a69c1f2954e5b'),
                 ('ec20cfd954f6292397f9c87ff60c7a9e47b365afd1de42cde8cedd6bd07eb1ff',
                  '256efb8632d1d963114a9f096059de5bdfbe23dee7794615ea8a69c1f2954e5b'),
                 ('9332c79de09287eef77c3f6eb7c6d825b59767c37767a8cbf490e42c475105cc',
                  '256efb8632d1d963114a9f096059de5bdfbe23dee7794615ea8a69c1f2954e5b'),
                 ('9c3c932ebee936c5435d3cbc3008b4f160b3f3359c915ac365cb51b0b84062d9',
                  '256efb8632d1d963114a9f096059de5bdfbe23dee7794615ea8a69c1f2954e5b'),
                 ('2d94436a62a433241bc4c0e43e3b786e1c6376cb0c4df98a844b318c2269103e',
                  '256efb8632d1d963114a9f096059de5bdfbe23dee7794615ea8a69c1f2954e5b'),
                 ('40cb7b3f0190c33ff455ff4ea1e8b79d6ff19a76f994720de3cdddc1158dfc57',
                  '256efb8632d1d963114a9f096059de5bdfbe23dee7794615ea8a69c1f2954e5b'),
                 ('7a7895fe3f8591b61c64b123b035e4b793275af931875152d1a27b1b37d2c6ea',
                  '256efb8632d1d963114a9f096059de5bdfbe23dee7794615ea8a69c1f2954e5b')],
 'padml/f5_a04_current.py': [('e56662f440d4e66581cca02c3fb43afb62cdcff1093adea1a578ced42dcdee92',
                              '20ba45d7f2c2e41636e67c31fc8968f89fb76b97f908efe5e79176a97b6cad24'),
                             ('e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
                              '20ba45d7f2c2e41636e67c31fc8968f89fb76b97f908efe5e79176a97b6cad24')],
 'padml/f5_application.py': [('dafdd6f40e8d2080083e4568c97113ba9b78e54409ae41abad7cd94c2828f108',
                              'ea8cf2c260d14231c566410b489c1a8cef9ed3627490d22066b83f6e4531851a'),
                             ('abb67ab2a45af72b5575b0e9654703e7f1d3f4869e1b45400a262f4a901b8b75',
                              'ea8cf2c260d14231c566410b489c1a8cef9ed3627490d22066b83f6e4531851a'),
                             ('9c5fb7ec498653ad10814f38511bb226c3f60ad6a0caac34210d3d11c8d39b9f',
                              'ea8cf2c260d14231c566410b489c1a8cef9ed3627490d22066b83f6e4531851a'),
                             ('600cd6cf1304e5e861d79ff87d77f94dec3d41183a4214e30bb8871af25dc508',
                              'ea8cf2c260d14231c566410b489c1a8cef9ed3627490d22066b83f6e4531851a')],
 'padml/f5_mice_variants.py': [('c9204bebf2b59e3e79002ad0ef54aa29f6265de33bce8a61b254a1527657c24d',
                                '613a050f36701ddcbf2d7efa1d10b8293193522f5750ec1d562554686d75a471')],
 'padml/f5_negative_controls.py': [('69ed26238426e2f0c334b832c6f3582ce306ac476650cea0c30f6b502b3317d8',
                                    'e7ed407d95efd64268fad694bb0e5e925e50e77d878f5be14a24e0a7db5472b8')],
 'padml/f5_sensitivity.py': [('072533c70d3dad0ce9d6f9e5425398fbcb8af5a331b652cad0b5c0e776366504',
                              '5d7daea54165638cab2601a6cad2cebb53f4a0fde90585987971d54199ef2fce'),
                             ('09956d534c070446579c69970e16c3d61e74c342747ec52becced53bbeb466b0',
                              '5d7daea54165638cab2601a6cad2cebb53f4a0fde90585987971d54199ef2fce'),
                             ('546a7fcbbadbd5b4184ffd4da1ca7a5c52b270703e0c92e033f97926c5346d1a',
                              '5d7daea54165638cab2601a6cad2cebb53f4a0fde90585987971d54199ef2fce'),
                             ('10a3c3145d20e1b8c416bae4a4aa0ed1f14445dd039ddb5ed58ebc2e938d1d0c',
                              '5d7daea54165638cab2601a6cad2cebb53f4a0fde90585987971d54199ef2fce'),
                             ('1a02950f41078e4c5a201cbebb1a9b7e9ed67b3000b1660b1ad2c130742f958c',
                              '5d7daea54165638cab2601a6cad2cebb53f4a0fde90585987971d54199ef2fce'),
                             ('192e4e594cccf89992b9e1d2cf2fceceba36cab258f6f7df23f93103a6c49d95',
                              '5d7daea54165638cab2601a6cad2cebb53f4a0fde90585987971d54199ef2fce')],
 'padml/integrated.py': [('a1ff3ce962c8a2196737ad1dff0ec8abc67b8c75b142ab0d29524b671747cb97',
                          '255600ac12bf059e331415110241df3b67a1a59e964078aa70dd8611f66cd35b'),
                         ('36dfb14b6031e6804a1398539076c3a3a92059d7124af964c88b3158fcd8548e',
                          '255600ac12bf059e331415110241df3b67a1a59e964078aa70dd8611f66cd35b'),
                         ('3926ccd806d210a9a7a6b3da51bbec3b377d1c6367f71bbcd93aec531d7479c6',
                          '255600ac12bf059e331415110241df3b67a1a59e964078aa70dd8611f66cd35b'),
                         ('646620534d600f98d3f3f700a78de7cf7e91a2c099f2c8b88e725a01d72cc42e',
                          '255600ac12bf059e331415110241df3b67a1a59e964078aa70dd8611f66cd35b'),
                         ('da54c167e06f8f95bebad6dbf1d4740993b7eac91d92374d736404a02ec07923',
                          '255600ac12bf059e331415110241df3b67a1a59e964078aa70dd8611f66cd35b'),
                         ('5031138367ea16c06cd5852a2f52654b6848e735e2f2f4ef4880f6414a8e0b87',
                          '255600ac12bf059e331415110241df3b67a1a59e964078aa70dd8611f66cd35b'),
                         ('75d6e14188c729b25591ccbe60fc4349f1886ab011884edfe7b6889286499d1f',
                          '255600ac12bf059e331415110241df3b67a1a59e964078aa70dd8611f66cd35b'),
                         ('4ce7ebc4349aa8edf6b76aee3b612605913a5bcd5bf09ba64c4d2be3063e4fe8',
                          '255600ac12bf059e331415110241df3b67a1a59e964078aa70dd8611f66cd35b')],
 'padml/kernels/f1_nested_mice.R': [('2cd3c7bf474c9416ebca3ade840adfd48a37dedefd49633c3a9cf04ce5bbf411',
                                     '2a83d2f440ec13e45e557a586103b1ee6cad20255407644aeb98ca6a3cb51c5c')],
 'padml/kernels/f2_model_development.R': [('80ee3e6776abe2e9e2c0ad96182edf7e28a0dadb2d916cb5b04a6ad9638c26b3',
                                           'e5179df37958c73d08fc7697ffb3984061fb0b32eda17c1111219fe6ab25e583')],
 'padml/kernels/f5_design.R': [('7d6b55497cbb4538441066d7c795891babcc7d5e9d4cef87438fa2af11a44617',
                                'e904dd2567291a29cf49555dda5d8f374b0ba56d724390cbde83e529a367e9ab')],
 'padml/kernels/f5_final_refit.R': [('a57994f649b5befa91331091459472a4dccec0bc3186fdf92c4f0545d4ba1a77',
                                     '077092a7bb12e5ac7651992a81cf7cafd98c90efa249d43f028068460f77a561')],
 'padml/kernels/f5_mice.R': [('e53c44c71aa3a12117b74adbd34e4ed6a30a2c11bf8c73780aae927f81818850',
                              '98b42a95dec1c4c8579ec54c6b0ae79db682af197eba9ff13f8043fe55d615f8')],
 'padml/kernels/f5_shap.R': [('5164d47ba5a663734086ab034e51f41a5c3f3939a8467e01875d601a9f1e64dc',
                              'ad38b4d498bfb3d2be8fe42b89b06e582d3872db5559dc1d9b59a655a2141b5e'),
                             ('f696acc0b81c3c95586de35f774ece0ac1a0863fbab24574e9c31c4b7f0806a2',
                              'ad38b4d498bfb3d2be8fe42b89b06e582d3872db5559dc1d9b59a655a2141b5e')],
 'padml/kernels/native/mrmre-performance.patch': [('e435b4144a9979b46a97039076085a804b9d1535dc2550733b96e4a7a06282ca',
                                                   'daa01c06e337c537aa0a9747789d048b6fe03ee1d12672d54fd5ecbd6315f7b3')],
 'padml/kernels/native/ranger-performance.patch': [('c4a86befbd117cee3ea184001642a8cb0fe223883e176323c73e28a161187b5a',
                                                    '65c431503cd3cf00cb2a421367742dfdf7e1283c020e1b6dd10f0b76849ccd81')],
 'padml/nested_loco.py': [('b49fb5c0c4435f3a30388439a9bdb4fc0ef9f12fbba435937a52a912b9b86a20',
                           '50831edd83cbe1b736ae2cae8652a48a726b6f4436376f2d1f819abdab481e9a')],
 'padml/oss.py': [('c519b14d9a857d104616979dade621bea40f3bc853ed82f0fa610bb6512760bc',
                   'bc2c760b5ace7b23a1830d9544f6acf0b01fc402cfb7a560eb662ac333355e67'),
                  ('bc2c760b5ace7b23a1830d9544f6acf0b01fc402cfb7a560eb662ac333355e67',
                   '43ff2690c4b6286fc1cc278030241c76f5b897b2acbd9509984519f4f02865e6'),
                  ('c519b14d9a857d104616979dade621bea40f3bc853ed82f0fa610bb6512760bc',
                   '43ff2690c4b6286fc1cc278030241c76f5b897b2acbd9509984519f4f02865e6')],
 'padml/reports.py': [('e1741baac3dd5badbfb07aac423d7b9579ba191b150bbcf48d058e4c2d133666',
                       '228f67502f99fbe8f092bffc0805ee7519b5d6502a955763583649e4b28742fc'),
                      ('d30ba68129c0004d098ca7f99954dde0769fc6a2500c6bf2095f844a396f6659',
                       '228f67502f99fbe8f092bffc0805ee7519b5d6502a955763583649e4b28742fc'),
                      ('b7a62815c21c1514dcd784c936cbd12a85183b853178d74363d08faf72a3e991',
                       '228f67502f99fbe8f092bffc0805ee7519b5d6502a955763583649e4b28742fc'),
                      ('a571c910099f79408c0245800080f600709ccec8260164c2639a8057493c9ead',
                       '228f67502f99fbe8f092bffc0805ee7519b5d6502a955763583649e4b28742fc'),
                      ('144705dec455003363bf68355044ff91c6c533dc2d4ccfd7b8989d1674894924',
                       '228f67502f99fbe8f092bffc0805ee7519b5d6502a955763583649e4b28742fc'),
                      ('b07fa0507d39b9a423f4120cb8f4e183a4ca0d5715aee554b142e3b7c1efb92a',
                       '228f67502f99fbe8f092bffc0805ee7519b5d6502a955763583649e4b28742fc'),
                      ('3d022af23692b46e0bc3512ff04164d95cdb7dc780fdb43a1b29b1aa87b692d9',
                       '228f67502f99fbe8f092bffc0805ee7519b5d6502a955763583649e4b28742fc'),
                      ('71fdbcde175dea5c467672c9f51a5907621dab58c25d314d303a3296c43b3cb0',
                       '228f67502f99fbe8f092bffc0805ee7519b5d6502a955763583649e4b28742fc'),
                      ('55435c1d41fcd9f81113ef962078ab047917366c2570ab49de8568d4b3809ff9',
                       '228f67502f99fbe8f092bffc0805ee7519b5d6502a955763583649e4b28742fc'),
                      ('08b59ff80661d8cc2543d5b35964f7fefdabf030109e8e8d30ba9d24cdfbc86d',
                       '228f67502f99fbe8f092bffc0805ee7519b5d6502a955763583649e4b28742fc'),
                      ('228f67502f99fbe8f092bffc0805ee7519b5d6502a955763583649e4b28742fc',
                       'e899b3dcffbd0d8e872d8aa9fc73bc952ffd48a70483918a3173fec496070b7f'),
                      ('e1741baac3dd5badbfb07aac423d7b9579ba191b150bbcf48d058e4c2d133666',
                       'e899b3dcffbd0d8e872d8aa9fc73bc952ffd48a70483918a3173fec496070b7f'),
                      ('d30ba68129c0004d098ca7f99954dde0769fc6a2500c6bf2095f844a396f6659',
                       'e899b3dcffbd0d8e872d8aa9fc73bc952ffd48a70483918a3173fec496070b7f'),
                      ('b7a62815c21c1514dcd784c936cbd12a85183b853178d74363d08faf72a3e991',
                       'e899b3dcffbd0d8e872d8aa9fc73bc952ffd48a70483918a3173fec496070b7f'),
                      ('a571c910099f79408c0245800080f600709ccec8260164c2639a8057493c9ead',
                       'e899b3dcffbd0d8e872d8aa9fc73bc952ffd48a70483918a3173fec496070b7f'),
                      ('144705dec455003363bf68355044ff91c6c533dc2d4ccfd7b8989d1674894924',
                       'e899b3dcffbd0d8e872d8aa9fc73bc952ffd48a70483918a3173fec496070b7f'),
                      ('b07fa0507d39b9a423f4120cb8f4e183a4ca0d5715aee554b142e3b7c1efb92a',
                       'e899b3dcffbd0d8e872d8aa9fc73bc952ffd48a70483918a3173fec496070b7f'),
                      ('3d022af23692b46e0bc3512ff04164d95cdb7dc780fdb43a1b29b1aa87b692d9',
                       'e899b3dcffbd0d8e872d8aa9fc73bc952ffd48a70483918a3173fec496070b7f'),
                      ('71fdbcde175dea5c467672c9f51a5907621dab58c25d314d303a3296c43b3cb0',
                       'e899b3dcffbd0d8e872d8aa9fc73bc952ffd48a70483918a3173fec496070b7f'),
                      ('55435c1d41fcd9f81113ef962078ab047917366c2570ab49de8568d4b3809ff9',
                       'e899b3dcffbd0d8e872d8aa9fc73bc952ffd48a70483918a3173fec496070b7f'),
                      ('08b59ff80661d8cc2543d5b35964f7fefdabf030109e8e8d30ba9d24cdfbc86d',
                       'e899b3dcffbd0d8e872d8aa9fc73bc952ffd48a70483918a3173fec496070b7f'),
                      ('e899b3dcffbd0d8e872d8aa9fc73bc952ffd48a70483918a3173fec496070b7f',
                       '9de240cffcab82b94d3e4f9f37af54b7d1e7edd680f7bfaa544aecbac8b3bf29'),
                      ('228f67502f99fbe8f092bffc0805ee7519b5d6502a955763583649e4b28742fc',
                       '9de240cffcab82b94d3e4f9f37af54b7d1e7edd680f7bfaa544aecbac8b3bf29'),
                      ('e1741baac3dd5badbfb07aac423d7b9579ba191b150bbcf48d058e4c2d133666',
                       '9de240cffcab82b94d3e4f9f37af54b7d1e7edd680f7bfaa544aecbac8b3bf29'),
                      ('d30ba68129c0004d098ca7f99954dde0769fc6a2500c6bf2095f844a396f6659',
                       '9de240cffcab82b94d3e4f9f37af54b7d1e7edd680f7bfaa544aecbac8b3bf29'),
                      ('b7a62815c21c1514dcd784c936cbd12a85183b853178d74363d08faf72a3e991',
                       '9de240cffcab82b94d3e4f9f37af54b7d1e7edd680f7bfaa544aecbac8b3bf29'),
                      ('a571c910099f79408c0245800080f600709ccec8260164c2639a8057493c9ead',
                       '9de240cffcab82b94d3e4f9f37af54b7d1e7edd680f7bfaa544aecbac8b3bf29'),
                      ('144705dec455003363bf68355044ff91c6c533dc2d4ccfd7b8989d1674894924',
                       '9de240cffcab82b94d3e4f9f37af54b7d1e7edd680f7bfaa544aecbac8b3bf29'),
                      ('b07fa0507d39b9a423f4120cb8f4e183a4ca0d5715aee554b142e3b7c1efb92a',
                       '9de240cffcab82b94d3e4f9f37af54b7d1e7edd680f7bfaa544aecbac8b3bf29'),
                      ('3d022af23692b46e0bc3512ff04164d95cdb7dc780fdb43a1b29b1aa87b692d9',
                       '9de240cffcab82b94d3e4f9f37af54b7d1e7edd680f7bfaa544aecbac8b3bf29'),
                      ('71fdbcde175dea5c467672c9f51a5907621dab58c25d314d303a3296c43b3cb0',
                       '9de240cffcab82b94d3e4f9f37af54b7d1e7edd680f7bfaa544aecbac8b3bf29'),
                      ('55435c1d41fcd9f81113ef962078ab047917366c2570ab49de8568d4b3809ff9',
                       '9de240cffcab82b94d3e4f9f37af54b7d1e7edd680f7bfaa544aecbac8b3bf29'),
                      ('08b59ff80661d8cc2543d5b35964f7fefdabf030109e8e8d30ba9d24cdfbc86d',
                       '9de240cffcab82b94d3e4f9f37af54b7d1e7edd680f7bfaa544aecbac8b3bf29'),
                      ('9de240cffcab82b94d3e4f9f37af54b7d1e7edd680f7bfaa544aecbac8b3bf29',
                       'db53ba962b7355925515af2fa98853b9c8d120944d1b9dd09e8ea2553230c7fb'),
                      ('e899b3dcffbd0d8e872d8aa9fc73bc952ffd48a70483918a3173fec496070b7f',
                       'db53ba962b7355925515af2fa98853b9c8d120944d1b9dd09e8ea2553230c7fb'),
                      ('228f67502f99fbe8f092bffc0805ee7519b5d6502a955763583649e4b28742fc',
                       'db53ba962b7355925515af2fa98853b9c8d120944d1b9dd09e8ea2553230c7fb'),
                      ('e1741baac3dd5badbfb07aac423d7b9579ba191b150bbcf48d058e4c2d133666',
                       'db53ba962b7355925515af2fa98853b9c8d120944d1b9dd09e8ea2553230c7fb'),
                      ('d30ba68129c0004d098ca7f99954dde0769fc6a2500c6bf2095f844a396f6659',
                       'db53ba962b7355925515af2fa98853b9c8d120944d1b9dd09e8ea2553230c7fb'),
                      ('b7a62815c21c1514dcd784c936cbd12a85183b853178d74363d08faf72a3e991',
                       'db53ba962b7355925515af2fa98853b9c8d120944d1b9dd09e8ea2553230c7fb'),
                      ('a571c910099f79408c0245800080f600709ccec8260164c2639a8057493c9ead',
                       'db53ba962b7355925515af2fa98853b9c8d120944d1b9dd09e8ea2553230c7fb'),
                      ('144705dec455003363bf68355044ff91c6c533dc2d4ccfd7b8989d1674894924',
                       'db53ba962b7355925515af2fa98853b9c8d120944d1b9dd09e8ea2553230c7fb'),
                      ('b07fa0507d39b9a423f4120cb8f4e183a4ca0d5715aee554b142e3b7c1efb92a',
                       'db53ba962b7355925515af2fa98853b9c8d120944d1b9dd09e8ea2553230c7fb'),
                      ('3d022af23692b46e0bc3512ff04164d95cdb7dc780fdb43a1b29b1aa87b692d9',
                       'db53ba962b7355925515af2fa98853b9c8d120944d1b9dd09e8ea2553230c7fb'),
                      ('71fdbcde175dea5c467672c9f51a5907621dab58c25d314d303a3296c43b3cb0',
                       'db53ba962b7355925515af2fa98853b9c8d120944d1b9dd09e8ea2553230c7fb'),
                      ('55435c1d41fcd9f81113ef962078ab047917366c2570ab49de8568d4b3809ff9',
                       'db53ba962b7355925515af2fa98853b9c8d120944d1b9dd09e8ea2553230c7fb'),
                      ('08b59ff80661d8cc2543d5b35964f7fefdabf030109e8e8d30ba9d24cdfbc86d',
                       'db53ba962b7355925515af2fa98853b9c8d120944d1b9dd09e8ea2553230c7fb'),
                      ('db53ba962b7355925515af2fa98853b9c8d120944d1b9dd09e8ea2553230c7fb',
                       '44eab1cf47486c1ce61dfcbef57eeaf11bba36c64951f88fd2a4e16afb3ce776'),
                      ('9de240cffcab82b94d3e4f9f37af54b7d1e7edd680f7bfaa544aecbac8b3bf29',
                       '44eab1cf47486c1ce61dfcbef57eeaf11bba36c64951f88fd2a4e16afb3ce776'),
                      ('e899b3dcffbd0d8e872d8aa9fc73bc952ffd48a70483918a3173fec496070b7f',
                       '44eab1cf47486c1ce61dfcbef57eeaf11bba36c64951f88fd2a4e16afb3ce776'),
                      ('228f67502f99fbe8f092bffc0805ee7519b5d6502a955763583649e4b28742fc',
                       '44eab1cf47486c1ce61dfcbef57eeaf11bba36c64951f88fd2a4e16afb3ce776'),
                      ('e1741baac3dd5badbfb07aac423d7b9579ba191b150bbcf48d058e4c2d133666',
                       '44eab1cf47486c1ce61dfcbef57eeaf11bba36c64951f88fd2a4e16afb3ce776'),
                      ('d30ba68129c0004d098ca7f99954dde0769fc6a2500c6bf2095f844a396f6659',
                       '44eab1cf47486c1ce61dfcbef57eeaf11bba36c64951f88fd2a4e16afb3ce776'),
                      ('b7a62815c21c1514dcd784c936cbd12a85183b853178d74363d08faf72a3e991',
                       '44eab1cf47486c1ce61dfcbef57eeaf11bba36c64951f88fd2a4e16afb3ce776'),
                      ('a571c910099f79408c0245800080f600709ccec8260164c2639a8057493c9ead',
                       '44eab1cf47486c1ce61dfcbef57eeaf11bba36c64951f88fd2a4e16afb3ce776'),
                      ('144705dec455003363bf68355044ff91c6c533dc2d4ccfd7b8989d1674894924',
                       '44eab1cf47486c1ce61dfcbef57eeaf11bba36c64951f88fd2a4e16afb3ce776'),
                      ('b07fa0507d39b9a423f4120cb8f4e183a4ca0d5715aee554b142e3b7c1efb92a',
                       '44eab1cf47486c1ce61dfcbef57eeaf11bba36c64951f88fd2a4e16afb3ce776'),
                      ('3d022af23692b46e0bc3512ff04164d95cdb7dc780fdb43a1b29b1aa87b692d9',
                       '44eab1cf47486c1ce61dfcbef57eeaf11bba36c64951f88fd2a4e16afb3ce776'),
                      ('71fdbcde175dea5c467672c9f51a5907621dab58c25d314d303a3296c43b3cb0',
                       '44eab1cf47486c1ce61dfcbef57eeaf11bba36c64951f88fd2a4e16afb3ce776'),
                      ('55435c1d41fcd9f81113ef962078ab047917366c2570ab49de8568d4b3809ff9',
                       '44eab1cf47486c1ce61dfcbef57eeaf11bba36c64951f88fd2a4e16afb3ce776'),
                      ('08b59ff80661d8cc2543d5b35964f7fefdabf030109e8e8d30ba9d24cdfbc86d',
                       '44eab1cf47486c1ce61dfcbef57eeaf11bba36c64951f88fd2a4e16afb3ce776'),
                      ('44eab1cf47486c1ce61dfcbef57eeaf11bba36c64951f88fd2a4e16afb3ce776',
                       'f6b4333683d2e9ab96a2a35ceea0864182617bb4ca4a96d2a8a9673f96657638'),
                      ('db53ba962b7355925515af2fa98853b9c8d120944d1b9dd09e8ea2553230c7fb',
                       'f6b4333683d2e9ab96a2a35ceea0864182617bb4ca4a96d2a8a9673f96657638'),
                      ('9de240cffcab82b94d3e4f9f37af54b7d1e7edd680f7bfaa544aecbac8b3bf29',
                       'f6b4333683d2e9ab96a2a35ceea0864182617bb4ca4a96d2a8a9673f96657638'),
                      ('e899b3dcffbd0d8e872d8aa9fc73bc952ffd48a70483918a3173fec496070b7f',
                       'f6b4333683d2e9ab96a2a35ceea0864182617bb4ca4a96d2a8a9673f96657638'),
                      ('228f67502f99fbe8f092bffc0805ee7519b5d6502a955763583649e4b28742fc',
                       'f6b4333683d2e9ab96a2a35ceea0864182617bb4ca4a96d2a8a9673f96657638'),
                      ('e1741baac3dd5badbfb07aac423d7b9579ba191b150bbcf48d058e4c2d133666',
                       'f6b4333683d2e9ab96a2a35ceea0864182617bb4ca4a96d2a8a9673f96657638'),
                      ('d30ba68129c0004d098ca7f99954dde0769fc6a2500c6bf2095f844a396f6659',
                       'f6b4333683d2e9ab96a2a35ceea0864182617bb4ca4a96d2a8a9673f96657638'),
                      ('b7a62815c21c1514dcd784c936cbd12a85183b853178d74363d08faf72a3e991',
                       'f6b4333683d2e9ab96a2a35ceea0864182617bb4ca4a96d2a8a9673f96657638'),
                      ('a571c910099f79408c0245800080f600709ccec8260164c2639a8057493c9ead',
                       'f6b4333683d2e9ab96a2a35ceea0864182617bb4ca4a96d2a8a9673f96657638'),
                      ('144705dec455003363bf68355044ff91c6c533dc2d4ccfd7b8989d1674894924',
                       'f6b4333683d2e9ab96a2a35ceea0864182617bb4ca4a96d2a8a9673f96657638'),
                      ('b07fa0507d39b9a423f4120cb8f4e183a4ca0d5715aee554b142e3b7c1efb92a',
                       'f6b4333683d2e9ab96a2a35ceea0864182617bb4ca4a96d2a8a9673f96657638'),
                      ('3d022af23692b46e0bc3512ff04164d95cdb7dc780fdb43a1b29b1aa87b692d9',
                       'f6b4333683d2e9ab96a2a35ceea0864182617bb4ca4a96d2a8a9673f96657638'),
                      ('71fdbcde175dea5c467672c9f51a5907621dab58c25d314d303a3296c43b3cb0',
                       'f6b4333683d2e9ab96a2a35ceea0864182617bb4ca4a96d2a8a9673f96657638'),
                      ('55435c1d41fcd9f81113ef962078ab047917366c2570ab49de8568d4b3809ff9',
                       'f6b4333683d2e9ab96a2a35ceea0864182617bb4ca4a96d2a8a9673f96657638'),
                      ('08b59ff80661d8cc2543d5b35964f7fefdabf030109e8e8d30ba9d24cdfbc86d',
                       'f6b4333683d2e9ab96a2a35ceea0864182617bb4ca4a96d2a8a9673f96657638'),
                      ('f6b4333683d2e9ab96a2a35ceea0864182617bb4ca4a96d2a8a9673f96657638',
                       'f584b09bd46dc64e17418300d865554439245b0402c21ca6c12e032d9aa8f258'),
                      ('44eab1cf47486c1ce61dfcbef57eeaf11bba36c64951f88fd2a4e16afb3ce776',
                       'f584b09bd46dc64e17418300d865554439245b0402c21ca6c12e032d9aa8f258'),
                      ('db53ba962b7355925515af2fa98853b9c8d120944d1b9dd09e8ea2553230c7fb',
                       'f584b09bd46dc64e17418300d865554439245b0402c21ca6c12e032d9aa8f258'),
                      ('9de240cffcab82b94d3e4f9f37af54b7d1e7edd680f7bfaa544aecbac8b3bf29',
                       'f584b09bd46dc64e17418300d865554439245b0402c21ca6c12e032d9aa8f258'),
                      ('e899b3dcffbd0d8e872d8aa9fc73bc952ffd48a70483918a3173fec496070b7f',
                       'f584b09bd46dc64e17418300d865554439245b0402c21ca6c12e032d9aa8f258'),
                      ('228f67502f99fbe8f092bffc0805ee7519b5d6502a955763583649e4b28742fc',
                       'f584b09bd46dc64e17418300d865554439245b0402c21ca6c12e032d9aa8f258'),
                      ('e1741baac3dd5badbfb07aac423d7b9579ba191b150bbcf48d058e4c2d133666',
                       'f584b09bd46dc64e17418300d865554439245b0402c21ca6c12e032d9aa8f258'),
                      ('d30ba68129c0004d098ca7f99954dde0769fc6a2500c6bf2095f844a396f6659',
                       'f584b09bd46dc64e17418300d865554439245b0402c21ca6c12e032d9aa8f258'),
                      ('b7a62815c21c1514dcd784c936cbd12a85183b853178d74363d08faf72a3e991',
                       'f584b09bd46dc64e17418300d865554439245b0402c21ca6c12e032d9aa8f258'),
                      ('a571c910099f79408c0245800080f600709ccec8260164c2639a8057493c9ead',
                       'f584b09bd46dc64e17418300d865554439245b0402c21ca6c12e032d9aa8f258'),
                      ('144705dec455003363bf68355044ff91c6c533dc2d4ccfd7b8989d1674894924',
                       'f584b09bd46dc64e17418300d865554439245b0402c21ca6c12e032d9aa8f258'),
                      ('b07fa0507d39b9a423f4120cb8f4e183a4ca0d5715aee554b142e3b7c1efb92a',
                       'f584b09bd46dc64e17418300d865554439245b0402c21ca6c12e032d9aa8f258'),
                      ('3d022af23692b46e0bc3512ff04164d95cdb7dc780fdb43a1b29b1aa87b692d9',
                       'f584b09bd46dc64e17418300d865554439245b0402c21ca6c12e032d9aa8f258'),
                      ('71fdbcde175dea5c467672c9f51a5907621dab58c25d314d303a3296c43b3cb0',
                       'f584b09bd46dc64e17418300d865554439245b0402c21ca6c12e032d9aa8f258'),
                      ('55435c1d41fcd9f81113ef962078ab047917366c2570ab49de8568d4b3809ff9',
                       'f584b09bd46dc64e17418300d865554439245b0402c21ca6c12e032d9aa8f258'),
                      ('08b59ff80661d8cc2543d5b35964f7fefdabf030109e8e8d30ba9d24cdfbc86d',
                       'f584b09bd46dc64e17418300d865554439245b0402c21ca6c12e032d9aa8f258'),
                      ('f584b09bd46dc64e17418300d865554439245b0402c21ca6c12e032d9aa8f258',
                       'f180b9e2d2550658c07e95858575cbf0d07b1e59c990fec35ad964fd9f95cfd2'),
                      ('f6b4333683d2e9ab96a2a35ceea0864182617bb4ca4a96d2a8a9673f96657638',
                       'f180b9e2d2550658c07e95858575cbf0d07b1e59c990fec35ad964fd9f95cfd2'),
                      ('44eab1cf47486c1ce61dfcbef57eeaf11bba36c64951f88fd2a4e16afb3ce776',
                       'f180b9e2d2550658c07e95858575cbf0d07b1e59c990fec35ad964fd9f95cfd2'),
                      ('db53ba962b7355925515af2fa98853b9c8d120944d1b9dd09e8ea2553230c7fb',
                       'f180b9e2d2550658c07e95858575cbf0d07b1e59c990fec35ad964fd9f95cfd2'),
                      ('9de240cffcab82b94d3e4f9f37af54b7d1e7edd680f7bfaa544aecbac8b3bf29',
                       'f180b9e2d2550658c07e95858575cbf0d07b1e59c990fec35ad964fd9f95cfd2'),
                      ('e899b3dcffbd0d8e872d8aa9fc73bc952ffd48a70483918a3173fec496070b7f',
                       'f180b9e2d2550658c07e95858575cbf0d07b1e59c990fec35ad964fd9f95cfd2'),
                      ('228f67502f99fbe8f092bffc0805ee7519b5d6502a955763583649e4b28742fc',
                       'f180b9e2d2550658c07e95858575cbf0d07b1e59c990fec35ad964fd9f95cfd2'),
                      ('e1741baac3dd5badbfb07aac423d7b9579ba191b150bbcf48d058e4c2d133666',
                       'f180b9e2d2550658c07e95858575cbf0d07b1e59c990fec35ad964fd9f95cfd2'),
                      ('d30ba68129c0004d098ca7f99954dde0769fc6a2500c6bf2095f844a396f6659',
                       'f180b9e2d2550658c07e95858575cbf0d07b1e59c990fec35ad964fd9f95cfd2'),
                      ('b7a62815c21c1514dcd784c936cbd12a85183b853178d74363d08faf72a3e991',
                       'f180b9e2d2550658c07e95858575cbf0d07b1e59c990fec35ad964fd9f95cfd2'),
                      ('a571c910099f79408c0245800080f600709ccec8260164c2639a8057493c9ead',
                       'f180b9e2d2550658c07e95858575cbf0d07b1e59c990fec35ad964fd9f95cfd2'),
                      ('144705dec455003363bf68355044ff91c6c533dc2d4ccfd7b8989d1674894924',
                       'f180b9e2d2550658c07e95858575cbf0d07b1e59c990fec35ad964fd9f95cfd2'),
                      ('b07fa0507d39b9a423f4120cb8f4e183a4ca0d5715aee554b142e3b7c1efb92a',
                       'f180b9e2d2550658c07e95858575cbf0d07b1e59c990fec35ad964fd9f95cfd2'),
                      ('3d022af23692b46e0bc3512ff04164d95cdb7dc780fdb43a1b29b1aa87b692d9',
                       'f180b9e2d2550658c07e95858575cbf0d07b1e59c990fec35ad964fd9f95cfd2'),
                      ('71fdbcde175dea5c467672c9f51a5907621dab58c25d314d303a3296c43b3cb0',
                       'f180b9e2d2550658c07e95858575cbf0d07b1e59c990fec35ad964fd9f95cfd2'),
                      ('55435c1d41fcd9f81113ef962078ab047917366c2570ab49de8568d4b3809ff9',
                       'f180b9e2d2550658c07e95858575cbf0d07b1e59c990fec35ad964fd9f95cfd2'),
                      ('08b59ff80661d8cc2543d5b35964f7fefdabf030109e8e8d30ba9d24cdfbc86d',
                       'f180b9e2d2550658c07e95858575cbf0d07b1e59c990fec35ad964fd9f95cfd2'),
                      ('08b59ff80661d8cc2543d5b35964f7fefdabf030109e8e8d30ba9d24cdfbc86d',
                       '557157fe97ce410f5f7d8fd78603e89c82c42156f34eb6c739ea9973df3d9378'),
                      ('144705dec455003363bf68355044ff91c6c533dc2d4ccfd7b8989d1674894924',
                       '557157fe97ce410f5f7d8fd78603e89c82c42156f34eb6c739ea9973df3d9378'),
                      ('228f67502f99fbe8f092bffc0805ee7519b5d6502a955763583649e4b28742fc',
                       '557157fe97ce410f5f7d8fd78603e89c82c42156f34eb6c739ea9973df3d9378'),
                      ('3d022af23692b46e0bc3512ff04164d95cdb7dc780fdb43a1b29b1aa87b692d9',
                       '557157fe97ce410f5f7d8fd78603e89c82c42156f34eb6c739ea9973df3d9378'),
                      ('44eab1cf47486c1ce61dfcbef57eeaf11bba36c64951f88fd2a4e16afb3ce776',
                       '557157fe97ce410f5f7d8fd78603e89c82c42156f34eb6c739ea9973df3d9378'),
                      ('55435c1d41fcd9f81113ef962078ab047917366c2570ab49de8568d4b3809ff9',
                       '557157fe97ce410f5f7d8fd78603e89c82c42156f34eb6c739ea9973df3d9378'),
                      ('71fdbcde175dea5c467672c9f51a5907621dab58c25d314d303a3296c43b3cb0',
                       '557157fe97ce410f5f7d8fd78603e89c82c42156f34eb6c739ea9973df3d9378'),
                      ('9de240cffcab82b94d3e4f9f37af54b7d1e7edd680f7bfaa544aecbac8b3bf29',
                       '557157fe97ce410f5f7d8fd78603e89c82c42156f34eb6c739ea9973df3d9378'),
                      ('a571c910099f79408c0245800080f600709ccec8260164c2639a8057493c9ead',
                       '557157fe97ce410f5f7d8fd78603e89c82c42156f34eb6c739ea9973df3d9378'),
                      ('b07fa0507d39b9a423f4120cb8f4e183a4ca0d5715aee554b142e3b7c1efb92a',
                       '557157fe97ce410f5f7d8fd78603e89c82c42156f34eb6c739ea9973df3d9378'),
                      ('b7a62815c21c1514dcd784c936cbd12a85183b853178d74363d08faf72a3e991',
                       '557157fe97ce410f5f7d8fd78603e89c82c42156f34eb6c739ea9973df3d9378'),
                      ('d30ba68129c0004d098ca7f99954dde0769fc6a2500c6bf2095f844a396f6659',
                       '557157fe97ce410f5f7d8fd78603e89c82c42156f34eb6c739ea9973df3d9378'),
                      ('db53ba962b7355925515af2fa98853b9c8d120944d1b9dd09e8ea2553230c7fb',
                       '557157fe97ce410f5f7d8fd78603e89c82c42156f34eb6c739ea9973df3d9378'),
                      ('e1741baac3dd5badbfb07aac423d7b9579ba191b150bbcf48d058e4c2d133666',
                       '557157fe97ce410f5f7d8fd78603e89c82c42156f34eb6c739ea9973df3d9378'),
                      ('e899b3dcffbd0d8e872d8aa9fc73bc952ffd48a70483918a3173fec496070b7f',
                       '557157fe97ce410f5f7d8fd78603e89c82c42156f34eb6c739ea9973df3d9378'),
                      ('f180b9e2d2550658c07e95858575cbf0d07b1e59c990fec35ad964fd9f95cfd2',
                       '557157fe97ce410f5f7d8fd78603e89c82c42156f34eb6c739ea9973df3d9378'),
                      ('f584b09bd46dc64e17418300d865554439245b0402c21ca6c12e032d9aa8f258',
                       '557157fe97ce410f5f7d8fd78603e89c82c42156f34eb6c739ea9973df3d9378'),
                      ('f6b4333683d2e9ab96a2a35ceea0864182617bb4ca4a96d2a8a9673f96657638',
                       '557157fe97ce410f5f7d8fd78603e89c82c42156f34eb6c739ea9973df3d9378'),
                      ('08b59ff80661d8cc2543d5b35964f7fefdabf030109e8e8d30ba9d24cdfbc86d',
                       'd5445137319e0ef9306cf8fa825f684ade7ee7400ca54dec7bd6fc9be1f83bfc'),
                      ('144705dec455003363bf68355044ff91c6c533dc2d4ccfd7b8989d1674894924',
                       'd5445137319e0ef9306cf8fa825f684ade7ee7400ca54dec7bd6fc9be1f83bfc'),
                      ('228f67502f99fbe8f092bffc0805ee7519b5d6502a955763583649e4b28742fc',
                       'd5445137319e0ef9306cf8fa825f684ade7ee7400ca54dec7bd6fc9be1f83bfc'),
                      ('3d022af23692b46e0bc3512ff04164d95cdb7dc780fdb43a1b29b1aa87b692d9',
                       'd5445137319e0ef9306cf8fa825f684ade7ee7400ca54dec7bd6fc9be1f83bfc'),
                      ('44eab1cf47486c1ce61dfcbef57eeaf11bba36c64951f88fd2a4e16afb3ce776',
                       'd5445137319e0ef9306cf8fa825f684ade7ee7400ca54dec7bd6fc9be1f83bfc'),
                      ('55435c1d41fcd9f81113ef962078ab047917366c2570ab49de8568d4b3809ff9',
                       'd5445137319e0ef9306cf8fa825f684ade7ee7400ca54dec7bd6fc9be1f83bfc'),
                      ('557157fe97ce410f5f7d8fd78603e89c82c42156f34eb6c739ea9973df3d9378',
                       'd5445137319e0ef9306cf8fa825f684ade7ee7400ca54dec7bd6fc9be1f83bfc'),
                      ('71fdbcde175dea5c467672c9f51a5907621dab58c25d314d303a3296c43b3cb0',
                       'd5445137319e0ef9306cf8fa825f684ade7ee7400ca54dec7bd6fc9be1f83bfc'),
                      ('9de240cffcab82b94d3e4f9f37af54b7d1e7edd680f7bfaa544aecbac8b3bf29',
                       'd5445137319e0ef9306cf8fa825f684ade7ee7400ca54dec7bd6fc9be1f83bfc'),
                      ('a571c910099f79408c0245800080f600709ccec8260164c2639a8057493c9ead',
                       'd5445137319e0ef9306cf8fa825f684ade7ee7400ca54dec7bd6fc9be1f83bfc'),
                      ('b07fa0507d39b9a423f4120cb8f4e183a4ca0d5715aee554b142e3b7c1efb92a',
                       'd5445137319e0ef9306cf8fa825f684ade7ee7400ca54dec7bd6fc9be1f83bfc'),
                      ('b7a62815c21c1514dcd784c936cbd12a85183b853178d74363d08faf72a3e991',
                       'd5445137319e0ef9306cf8fa825f684ade7ee7400ca54dec7bd6fc9be1f83bfc'),
                      ('d30ba68129c0004d098ca7f99954dde0769fc6a2500c6bf2095f844a396f6659',
                       'd5445137319e0ef9306cf8fa825f684ade7ee7400ca54dec7bd6fc9be1f83bfc'),
                      ('db53ba962b7355925515af2fa98853b9c8d120944d1b9dd09e8ea2553230c7fb',
                       'd5445137319e0ef9306cf8fa825f684ade7ee7400ca54dec7bd6fc9be1f83bfc'),
                      ('e1741baac3dd5badbfb07aac423d7b9579ba191b150bbcf48d058e4c2d133666',
                       'd5445137319e0ef9306cf8fa825f684ade7ee7400ca54dec7bd6fc9be1f83bfc'),
                      ('e899b3dcffbd0d8e872d8aa9fc73bc952ffd48a70483918a3173fec496070b7f',
                       'd5445137319e0ef9306cf8fa825f684ade7ee7400ca54dec7bd6fc9be1f83bfc'),
                      ('f180b9e2d2550658c07e95858575cbf0d07b1e59c990fec35ad964fd9f95cfd2',
                       'd5445137319e0ef9306cf8fa825f684ade7ee7400ca54dec7bd6fc9be1f83bfc'),
                      ('f584b09bd46dc64e17418300d865554439245b0402c21ca6c12e032d9aa8f258',
                       'd5445137319e0ef9306cf8fa825f684ade7ee7400ca54dec7bd6fc9be1f83bfc'),
                      ('f6b4333683d2e9ab96a2a35ceea0864182617bb4ca4a96d2a8a9673f96657638',
                       'd5445137319e0ef9306cf8fa825f684ade7ee7400ca54dec7bd6fc9be1f83bfc'),
                      ('08b59ff80661d8cc2543d5b35964f7fefdabf030109e8e8d30ba9d24cdfbc86d',
                       'd630274a281d7b6c55951a8dc2b77cd449242b193c9a1e1fb616a1a25c5bd734'),
                      ('144705dec455003363bf68355044ff91c6c533dc2d4ccfd7b8989d1674894924',
                       'd630274a281d7b6c55951a8dc2b77cd449242b193c9a1e1fb616a1a25c5bd734'),
                      ('228f67502f99fbe8f092bffc0805ee7519b5d6502a955763583649e4b28742fc',
                       'd630274a281d7b6c55951a8dc2b77cd449242b193c9a1e1fb616a1a25c5bd734'),
                      ('3d022af23692b46e0bc3512ff04164d95cdb7dc780fdb43a1b29b1aa87b692d9',
                       'd630274a281d7b6c55951a8dc2b77cd449242b193c9a1e1fb616a1a25c5bd734'),
                      ('44eab1cf47486c1ce61dfcbef57eeaf11bba36c64951f88fd2a4e16afb3ce776',
                       'd630274a281d7b6c55951a8dc2b77cd449242b193c9a1e1fb616a1a25c5bd734'),
                      ('55435c1d41fcd9f81113ef962078ab047917366c2570ab49de8568d4b3809ff9',
                       'd630274a281d7b6c55951a8dc2b77cd449242b193c9a1e1fb616a1a25c5bd734'),
                      ('557157fe97ce410f5f7d8fd78603e89c82c42156f34eb6c739ea9973df3d9378',
                       'd630274a281d7b6c55951a8dc2b77cd449242b193c9a1e1fb616a1a25c5bd734'),
                      ('71fdbcde175dea5c467672c9f51a5907621dab58c25d314d303a3296c43b3cb0',
                       'd630274a281d7b6c55951a8dc2b77cd449242b193c9a1e1fb616a1a25c5bd734'),
                      ('9de240cffcab82b94d3e4f9f37af54b7d1e7edd680f7bfaa544aecbac8b3bf29',
                       'd630274a281d7b6c55951a8dc2b77cd449242b193c9a1e1fb616a1a25c5bd734'),
                      ('a571c910099f79408c0245800080f600709ccec8260164c2639a8057493c9ead',
                       'd630274a281d7b6c55951a8dc2b77cd449242b193c9a1e1fb616a1a25c5bd734'),
                      ('b07fa0507d39b9a423f4120cb8f4e183a4ca0d5715aee554b142e3b7c1efb92a',
                       'd630274a281d7b6c55951a8dc2b77cd449242b193c9a1e1fb616a1a25c5bd734'),
                      ('b7a62815c21c1514dcd784c936cbd12a85183b853178d74363d08faf72a3e991',
                       'd630274a281d7b6c55951a8dc2b77cd449242b193c9a1e1fb616a1a25c5bd734'),
                      ('d30ba68129c0004d098ca7f99954dde0769fc6a2500c6bf2095f844a396f6659',
                       'd630274a281d7b6c55951a8dc2b77cd449242b193c9a1e1fb616a1a25c5bd734'),
                      ('d5445137319e0ef9306cf8fa825f684ade7ee7400ca54dec7bd6fc9be1f83bfc',
                       'd630274a281d7b6c55951a8dc2b77cd449242b193c9a1e1fb616a1a25c5bd734'),
                      ('db53ba962b7355925515af2fa98853b9c8d120944d1b9dd09e8ea2553230c7fb',
                       'd630274a281d7b6c55951a8dc2b77cd449242b193c9a1e1fb616a1a25c5bd734'),
                      ('e1741baac3dd5badbfb07aac423d7b9579ba191b150bbcf48d058e4c2d133666',
                       'd630274a281d7b6c55951a8dc2b77cd449242b193c9a1e1fb616a1a25c5bd734'),
                      ('e899b3dcffbd0d8e872d8aa9fc73bc952ffd48a70483918a3173fec496070b7f',
                       'd630274a281d7b6c55951a8dc2b77cd449242b193c9a1e1fb616a1a25c5bd734'),
                      ('f180b9e2d2550658c07e95858575cbf0d07b1e59c990fec35ad964fd9f95cfd2',
                       'd630274a281d7b6c55951a8dc2b77cd449242b193c9a1e1fb616a1a25c5bd734'),
                      ('f584b09bd46dc64e17418300d865554439245b0402c21ca6c12e032d9aa8f258',
                       'd630274a281d7b6c55951a8dc2b77cd449242b193c9a1e1fb616a1a25c5bd734'),
                      ('f6b4333683d2e9ab96a2a35ceea0864182617bb4ca4a96d2a8a9673f96657638',
                       'd630274a281d7b6c55951a8dc2b77cd449242b193c9a1e1fb616a1a25c5bd734'),
                      ('08b59ff80661d8cc2543d5b35964f7fefdabf030109e8e8d30ba9d24cdfbc86d',
                       '1615609e76c8a4f9f061dbe07135949402488eace772f25dafa677add9544b0d'),
                      ('144705dec455003363bf68355044ff91c6c533dc2d4ccfd7b8989d1674894924',
                       '1615609e76c8a4f9f061dbe07135949402488eace772f25dafa677add9544b0d'),
                      ('228f67502f99fbe8f092bffc0805ee7519b5d6502a955763583649e4b28742fc',
                       '1615609e76c8a4f9f061dbe07135949402488eace772f25dafa677add9544b0d'),
                      ('3d022af23692b46e0bc3512ff04164d95cdb7dc780fdb43a1b29b1aa87b692d9',
                       '1615609e76c8a4f9f061dbe07135949402488eace772f25dafa677add9544b0d'),
                      ('44eab1cf47486c1ce61dfcbef57eeaf11bba36c64951f88fd2a4e16afb3ce776',
                       '1615609e76c8a4f9f061dbe07135949402488eace772f25dafa677add9544b0d'),
                      ('55435c1d41fcd9f81113ef962078ab047917366c2570ab49de8568d4b3809ff9',
                       '1615609e76c8a4f9f061dbe07135949402488eace772f25dafa677add9544b0d'),
                      ('557157fe97ce410f5f7d8fd78603e89c82c42156f34eb6c739ea9973df3d9378',
                       '1615609e76c8a4f9f061dbe07135949402488eace772f25dafa677add9544b0d'),
                      ('71fdbcde175dea5c467672c9f51a5907621dab58c25d314d303a3296c43b3cb0',
                       '1615609e76c8a4f9f061dbe07135949402488eace772f25dafa677add9544b0d'),
                      ('9de240cffcab82b94d3e4f9f37af54b7d1e7edd680f7bfaa544aecbac8b3bf29',
                       '1615609e76c8a4f9f061dbe07135949402488eace772f25dafa677add9544b0d'),
                      ('a571c910099f79408c0245800080f600709ccec8260164c2639a8057493c9ead',
                       '1615609e76c8a4f9f061dbe07135949402488eace772f25dafa677add9544b0d'),
                      ('b07fa0507d39b9a423f4120cb8f4e183a4ca0d5715aee554b142e3b7c1efb92a',
                       '1615609e76c8a4f9f061dbe07135949402488eace772f25dafa677add9544b0d'),
                      ('b7a62815c21c1514dcd784c936cbd12a85183b853178d74363d08faf72a3e991',
                       '1615609e76c8a4f9f061dbe07135949402488eace772f25dafa677add9544b0d'),
                      ('d30ba68129c0004d098ca7f99954dde0769fc6a2500c6bf2095f844a396f6659',
                       '1615609e76c8a4f9f061dbe07135949402488eace772f25dafa677add9544b0d'),
                      ('d5445137319e0ef9306cf8fa825f684ade7ee7400ca54dec7bd6fc9be1f83bfc',
                       '1615609e76c8a4f9f061dbe07135949402488eace772f25dafa677add9544b0d'),
                      ('d630274a281d7b6c55951a8dc2b77cd449242b193c9a1e1fb616a1a25c5bd734',
                       '1615609e76c8a4f9f061dbe07135949402488eace772f25dafa677add9544b0d'),
                      ('db53ba962b7355925515af2fa98853b9c8d120944d1b9dd09e8ea2553230c7fb',
                       '1615609e76c8a4f9f061dbe07135949402488eace772f25dafa677add9544b0d'),
                      ('e1741baac3dd5badbfb07aac423d7b9579ba191b150bbcf48d058e4c2d133666',
                       '1615609e76c8a4f9f061dbe07135949402488eace772f25dafa677add9544b0d'),
                      ('e899b3dcffbd0d8e872d8aa9fc73bc952ffd48a70483918a3173fec496070b7f',
                       '1615609e76c8a4f9f061dbe07135949402488eace772f25dafa677add9544b0d'),
                      ('f180b9e2d2550658c07e95858575cbf0d07b1e59c990fec35ad964fd9f95cfd2',
                       '1615609e76c8a4f9f061dbe07135949402488eace772f25dafa677add9544b0d'),
                      ('f584b09bd46dc64e17418300d865554439245b0402c21ca6c12e032d9aa8f258',
                       '1615609e76c8a4f9f061dbe07135949402488eace772f25dafa677add9544b0d'),
                      ('f6b4333683d2e9ab96a2a35ceea0864182617bb4ca4a96d2a8a9673f96657638',
                       '1615609e76c8a4f9f061dbe07135949402488eace772f25dafa677add9544b0d'),
                      ('08b59ff80661d8cc2543d5b35964f7fefdabf030109e8e8d30ba9d24cdfbc86d',
                       'b5d1701874b2eab90f384ffc11963efe48e42edc7cc57132fbbd7d543659c2de'),
                      ('144705dec455003363bf68355044ff91c6c533dc2d4ccfd7b8989d1674894924',
                       'b5d1701874b2eab90f384ffc11963efe48e42edc7cc57132fbbd7d543659c2de'),
                      ('1615609e76c8a4f9f061dbe07135949402488eace772f25dafa677add9544b0d',
                       'b5d1701874b2eab90f384ffc11963efe48e42edc7cc57132fbbd7d543659c2de'),
                      ('228f67502f99fbe8f092bffc0805ee7519b5d6502a955763583649e4b28742fc',
                       'b5d1701874b2eab90f384ffc11963efe48e42edc7cc57132fbbd7d543659c2de'),
                      ('3d022af23692b46e0bc3512ff04164d95cdb7dc780fdb43a1b29b1aa87b692d9',
                       'b5d1701874b2eab90f384ffc11963efe48e42edc7cc57132fbbd7d543659c2de'),
                      ('44eab1cf47486c1ce61dfcbef57eeaf11bba36c64951f88fd2a4e16afb3ce776',
                       'b5d1701874b2eab90f384ffc11963efe48e42edc7cc57132fbbd7d543659c2de'),
                      ('55435c1d41fcd9f81113ef962078ab047917366c2570ab49de8568d4b3809ff9',
                       'b5d1701874b2eab90f384ffc11963efe48e42edc7cc57132fbbd7d543659c2de'),
                      ('557157fe97ce410f5f7d8fd78603e89c82c42156f34eb6c739ea9973df3d9378',
                       'b5d1701874b2eab90f384ffc11963efe48e42edc7cc57132fbbd7d543659c2de'),
                      ('71fdbcde175dea5c467672c9f51a5907621dab58c25d314d303a3296c43b3cb0',
                       'b5d1701874b2eab90f384ffc11963efe48e42edc7cc57132fbbd7d543659c2de'),
                      ('9de240cffcab82b94d3e4f9f37af54b7d1e7edd680f7bfaa544aecbac8b3bf29',
                       'b5d1701874b2eab90f384ffc11963efe48e42edc7cc57132fbbd7d543659c2de'),
                      ('a571c910099f79408c0245800080f600709ccec8260164c2639a8057493c9ead',
                       'b5d1701874b2eab90f384ffc11963efe48e42edc7cc57132fbbd7d543659c2de'),
                      ('b07fa0507d39b9a423f4120cb8f4e183a4ca0d5715aee554b142e3b7c1efb92a',
                       'b5d1701874b2eab90f384ffc11963efe48e42edc7cc57132fbbd7d543659c2de'),
                      ('b7a62815c21c1514dcd784c936cbd12a85183b853178d74363d08faf72a3e991',
                       'b5d1701874b2eab90f384ffc11963efe48e42edc7cc57132fbbd7d543659c2de'),
                      ('d30ba68129c0004d098ca7f99954dde0769fc6a2500c6bf2095f844a396f6659',
                       'b5d1701874b2eab90f384ffc11963efe48e42edc7cc57132fbbd7d543659c2de'),
                      ('d5445137319e0ef9306cf8fa825f684ade7ee7400ca54dec7bd6fc9be1f83bfc',
                       'b5d1701874b2eab90f384ffc11963efe48e42edc7cc57132fbbd7d543659c2de'),
                      ('d630274a281d7b6c55951a8dc2b77cd449242b193c9a1e1fb616a1a25c5bd734',
                       'b5d1701874b2eab90f384ffc11963efe48e42edc7cc57132fbbd7d543659c2de'),
                      ('db53ba962b7355925515af2fa98853b9c8d120944d1b9dd09e8ea2553230c7fb',
                       'b5d1701874b2eab90f384ffc11963efe48e42edc7cc57132fbbd7d543659c2de'),
                      ('e1741baac3dd5badbfb07aac423d7b9579ba191b150bbcf48d058e4c2d133666',
                       'b5d1701874b2eab90f384ffc11963efe48e42edc7cc57132fbbd7d543659c2de'),
                      ('e899b3dcffbd0d8e872d8aa9fc73bc952ffd48a70483918a3173fec496070b7f',
                       'b5d1701874b2eab90f384ffc11963efe48e42edc7cc57132fbbd7d543659c2de'),
                      ('f180b9e2d2550658c07e95858575cbf0d07b1e59c990fec35ad964fd9f95cfd2',
                       'b5d1701874b2eab90f384ffc11963efe48e42edc7cc57132fbbd7d543659c2de'),
                      ('f584b09bd46dc64e17418300d865554439245b0402c21ca6c12e032d9aa8f258',
                       'b5d1701874b2eab90f384ffc11963efe48e42edc7cc57132fbbd7d543659c2de'),
                      ('f6b4333683d2e9ab96a2a35ceea0864182617bb4ca4a96d2a8a9673f96657638',
                       'b5d1701874b2eab90f384ffc11963efe48e42edc7cc57132fbbd7d543659c2de')],
 'padml/result_closure.py': [('e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
                              '5092b71558590a01969c472a1af7ffa88ccc78b22c2669a9caa4964724624a29')],
 'padml/run.py': [('622fd3821cdcc6d76cd50b81a9843a65a1ecf386a484619de41d955a36b899d6',
                   '622fd3821cdcc6d76cd50b81a9843a65a1ecf386a484619de41d955a36b899d6'),
                  ('7fb8b0e124e9ef68867475fdd40a87e06329c22b651fa7633a430b6609f0a2dc',
                   '622fd3821cdcc6d76cd50b81a9843a65a1ecf386a484619de41d955a36b899d6'),
                  ('cd883e2ea724c84a254696c722a03af42b3e6a8c53857b9b654bbcef1d416911',
                   '622fd3821cdcc6d76cd50b81a9843a65a1ecf386a484619de41d955a36b899d6'),
                  ('e4607078a7efc86a64ab97682b2b0c438453723024130c8a0a197f4c7e31e939',
                   '622fd3821cdcc6d76cd50b81a9843a65a1ecf386a484619de41d955a36b899d6'),
                  ('ae75f62b4d6622bdda5a093cf0057e699ef78adf6cede16879b1859b7c4220ad',
                   '622fd3821cdcc6d76cd50b81a9843a65a1ecf386a484619de41d955a36b899d6'),
                  ('dcae7a5b23fc084f997d2bcaa432039f2e71adf9c5121f56e71c0c707d2742df',
                   '622fd3821cdcc6d76cd50b81a9843a65a1ecf386a484619de41d955a36b899d6'),
                  ('5a070f3d72e46b0cc8ca926dc06a1118405a0b8a28413176d19bbdde8fc21aff',
                   '622fd3821cdcc6d76cd50b81a9843a65a1ecf386a484619de41d955a36b899d6'),
                  ('44a237bb746364e67f008f6278540874d798a85a1726cc360a4a1b242e6bad84',
                   '622fd3821cdcc6d76cd50b81a9843a65a1ecf386a484619de41d955a36b899d6'),
                  ('9b6da4f5454d597f701447a3a438b2473f3ffea3e6674e50510561c663080209',
                   '622fd3821cdcc6d76cd50b81a9843a65a1ecf386a484619de41d955a36b899d6'),
                  ('2d3d0be0c14de4f673f23d90128086d66425e36daf488bc21897aeb199a21c76',
                   '622fd3821cdcc6d76cd50b81a9843a65a1ecf386a484619de41d955a36b899d6'),
                  ('75795806022c7b433c33a6cb7509c0b2073048087b2dc3be9c31da3557b5ea6b',
                   '622fd3821cdcc6d76cd50b81a9843a65a1ecf386a484619de41d955a36b899d6'),
                  ('7a646c6f2cf6b42b51eb2db74aaab7fd721991b9f69560b0b626123c74109fb8',
                   '622fd3821cdcc6d76cd50b81a9843a65a1ecf386a484619de41d955a36b899d6'),
                  ('622fd3821cdcc6d76cd50b81a9843a65a1ecf386a484619de41d955a36b899d6',
                   'b5b4482c4e668b96d3be49529ea6672c677fe965ec07fe3e34128f3070eee29f'),
                  ('7fb8b0e124e9ef68867475fdd40a87e06329c22b651fa7633a430b6609f0a2dc',
                   'b5b4482c4e668b96d3be49529ea6672c677fe965ec07fe3e34128f3070eee29f'),
                  ('cd883e2ea724c84a254696c722a03af42b3e6a8c53857b9b654bbcef1d416911',
                   'b5b4482c4e668b96d3be49529ea6672c677fe965ec07fe3e34128f3070eee29f'),
                  ('e4607078a7efc86a64ab97682b2b0c438453723024130c8a0a197f4c7e31e939',
                   'b5b4482c4e668b96d3be49529ea6672c677fe965ec07fe3e34128f3070eee29f'),
                  ('ae75f62b4d6622bdda5a093cf0057e699ef78adf6cede16879b1859b7c4220ad',
                   'b5b4482c4e668b96d3be49529ea6672c677fe965ec07fe3e34128f3070eee29f'),
                  ('dcae7a5b23fc084f997d2bcaa432039f2e71adf9c5121f56e71c0c707d2742df',
                   'b5b4482c4e668b96d3be49529ea6672c677fe965ec07fe3e34128f3070eee29f'),
                  ('5a070f3d72e46b0cc8ca926dc06a1118405a0b8a28413176d19bbdde8fc21aff',
                   'b5b4482c4e668b96d3be49529ea6672c677fe965ec07fe3e34128f3070eee29f'),
                  ('44a237bb746364e67f008f6278540874d798a85a1726cc360a4a1b242e6bad84',
                   'b5b4482c4e668b96d3be49529ea6672c677fe965ec07fe3e34128f3070eee29f'),
                  ('9b6da4f5454d597f701447a3a438b2473f3ffea3e6674e50510561c663080209',
                   'b5b4482c4e668b96d3be49529ea6672c677fe965ec07fe3e34128f3070eee29f'),
                  ('2d3d0be0c14de4f673f23d90128086d66425e36daf488bc21897aeb199a21c76',
                   'b5b4482c4e668b96d3be49529ea6672c677fe965ec07fe3e34128f3070eee29f'),
                  ('75795806022c7b433c33a6cb7509c0b2073048087b2dc3be9c31da3557b5ea6b',
                   'b5b4482c4e668b96d3be49529ea6672c677fe965ec07fe3e34128f3070eee29f'),
                  ('7a646c6f2cf6b42b51eb2db74aaab7fd721991b9f69560b0b626123c74109fb8',
                   'b5b4482c4e668b96d3be49529ea6672c677fe965ec07fe3e34128f3070eee29f'),
                  ('b5b4482c4e668b96d3be49529ea6672c677fe965ec07fe3e34128f3070eee29f',
                   '5d3af4c0d7974a8c79d1fcb66eb5238af659cee72da9cbcc0ecfdb1dfd06ad8d'),
                  ('622fd3821cdcc6d76cd50b81a9843a65a1ecf386a484619de41d955a36b899d6',
                   '5d3af4c0d7974a8c79d1fcb66eb5238af659cee72da9cbcc0ecfdb1dfd06ad8d'),
                  ('7fb8b0e124e9ef68867475fdd40a87e06329c22b651fa7633a430b6609f0a2dc',
                   '5d3af4c0d7974a8c79d1fcb66eb5238af659cee72da9cbcc0ecfdb1dfd06ad8d'),
                  ('cd883e2ea724c84a254696c722a03af42b3e6a8c53857b9b654bbcef1d416911',
                   '5d3af4c0d7974a8c79d1fcb66eb5238af659cee72da9cbcc0ecfdb1dfd06ad8d'),
                  ('e4607078a7efc86a64ab97682b2b0c438453723024130c8a0a197f4c7e31e939',
                   '5d3af4c0d7974a8c79d1fcb66eb5238af659cee72da9cbcc0ecfdb1dfd06ad8d'),
                  ('ae75f62b4d6622bdda5a093cf0057e699ef78adf6cede16879b1859b7c4220ad',
                   '5d3af4c0d7974a8c79d1fcb66eb5238af659cee72da9cbcc0ecfdb1dfd06ad8d'),
                  ('dcae7a5b23fc084f997d2bcaa432039f2e71adf9c5121f56e71c0c707d2742df',
                   '5d3af4c0d7974a8c79d1fcb66eb5238af659cee72da9cbcc0ecfdb1dfd06ad8d'),
                  ('5a070f3d72e46b0cc8ca926dc06a1118405a0b8a28413176d19bbdde8fc21aff',
                   '5d3af4c0d7974a8c79d1fcb66eb5238af659cee72da9cbcc0ecfdb1dfd06ad8d'),
                  ('44a237bb746364e67f008f6278540874d798a85a1726cc360a4a1b242e6bad84',
                   '5d3af4c0d7974a8c79d1fcb66eb5238af659cee72da9cbcc0ecfdb1dfd06ad8d'),
                  ('9b6da4f5454d597f701447a3a438b2473f3ffea3e6674e50510561c663080209',
                   '5d3af4c0d7974a8c79d1fcb66eb5238af659cee72da9cbcc0ecfdb1dfd06ad8d'),
                  ('2d3d0be0c14de4f673f23d90128086d66425e36daf488bc21897aeb199a21c76',
                   '5d3af4c0d7974a8c79d1fcb66eb5238af659cee72da9cbcc0ecfdb1dfd06ad8d'),
                  ('75795806022c7b433c33a6cb7509c0b2073048087b2dc3be9c31da3557b5ea6b',
                   '5d3af4c0d7974a8c79d1fcb66eb5238af659cee72da9cbcc0ecfdb1dfd06ad8d'),
                  ('7a646c6f2cf6b42b51eb2db74aaab7fd721991b9f69560b0b626123c74109fb8',
                   '5d3af4c0d7974a8c79d1fcb66eb5238af659cee72da9cbcc0ecfdb1dfd06ad8d'),
                  ('5d3af4c0d7974a8c79d1fcb66eb5238af659cee72da9cbcc0ecfdb1dfd06ad8d',
                   '5d3af4c0d7974a8c79d1fcb66eb5238af659cee72da9cbcc0ecfdb1dfd06ad8d'),
                  ('5d3af4c0d7974a8c79d1fcb66eb5238af659cee72da9cbcc0ecfdb1dfd06ad8d',
                   'ad211a3b94807b1a58b7ace0ff9b661f953157c308ed7494a247cf22f7fe5292'),
                  ('b5b4482c4e668b96d3be49529ea6672c677fe965ec07fe3e34128f3070eee29f',
                   'ad211a3b94807b1a58b7ace0ff9b661f953157c308ed7494a247cf22f7fe5292'),
                  ('622fd3821cdcc6d76cd50b81a9843a65a1ecf386a484619de41d955a36b899d6',
                   'ad211a3b94807b1a58b7ace0ff9b661f953157c308ed7494a247cf22f7fe5292'),
                  ('7fb8b0e124e9ef68867475fdd40a87e06329c22b651fa7633a430b6609f0a2dc',
                   'ad211a3b94807b1a58b7ace0ff9b661f953157c308ed7494a247cf22f7fe5292'),
                  ('cd883e2ea724c84a254696c722a03af42b3e6a8c53857b9b654bbcef1d416911',
                   'ad211a3b94807b1a58b7ace0ff9b661f953157c308ed7494a247cf22f7fe5292'),
                  ('e4607078a7efc86a64ab97682b2b0c438453723024130c8a0a197f4c7e31e939',
                   'ad211a3b94807b1a58b7ace0ff9b661f953157c308ed7494a247cf22f7fe5292'),
                  ('ae75f62b4d6622bdda5a093cf0057e699ef78adf6cede16879b1859b7c4220ad',
                   'ad211a3b94807b1a58b7ace0ff9b661f953157c308ed7494a247cf22f7fe5292'),
                  ('dcae7a5b23fc084f997d2bcaa432039f2e71adf9c5121f56e71c0c707d2742df',
                   'ad211a3b94807b1a58b7ace0ff9b661f953157c308ed7494a247cf22f7fe5292'),
                  ('5a070f3d72e46b0cc8ca926dc06a1118405a0b8a28413176d19bbdde8fc21aff',
                   'ad211a3b94807b1a58b7ace0ff9b661f953157c308ed7494a247cf22f7fe5292'),
                  ('44a237bb746364e67f008f6278540874d798a85a1726cc360a4a1b242e6bad84',
                   'ad211a3b94807b1a58b7ace0ff9b661f953157c308ed7494a247cf22f7fe5292'),
                  ('9b6da4f5454d597f701447a3a438b2473f3ffea3e6674e50510561c663080209',
                   'ad211a3b94807b1a58b7ace0ff9b661f953157c308ed7494a247cf22f7fe5292'),
                  ('2d3d0be0c14de4f673f23d90128086d66425e36daf488bc21897aeb199a21c76',
                   'ad211a3b94807b1a58b7ace0ff9b661f953157c308ed7494a247cf22f7fe5292'),
                  ('75795806022c7b433c33a6cb7509c0b2073048087b2dc3be9c31da3557b5ea6b',
                   'ad211a3b94807b1a58b7ace0ff9b661f953157c308ed7494a247cf22f7fe5292'),
                  ('7a646c6f2cf6b42b51eb2db74aaab7fd721991b9f69560b0b626123c74109fb8',
                   'ad211a3b94807b1a58b7ace0ff9b661f953157c308ed7494a247cf22f7fe5292'),
                  ('ad211a3b94807b1a58b7ace0ff9b661f953157c308ed7494a247cf22f7fe5292',
                   'ad211a3b94807b1a58b7ace0ff9b661f953157c308ed7494a247cf22f7fe5292'),
                  ('2d3d0be0c14de4f673f23d90128086d66425e36daf488bc21897aeb199a21c76',
                   '04cc51ab1c4c5a57ec2fdff4ec7777a8f5055810681ba962d933bb46d9a7d7a9'),
                  ('44a237bb746364e67f008f6278540874d798a85a1726cc360a4a1b242e6bad84',
                   '04cc51ab1c4c5a57ec2fdff4ec7777a8f5055810681ba962d933bb46d9a7d7a9'),
                  ('5a070f3d72e46b0cc8ca926dc06a1118405a0b8a28413176d19bbdde8fc21aff',
                   '04cc51ab1c4c5a57ec2fdff4ec7777a8f5055810681ba962d933bb46d9a7d7a9'),
                  ('5d3af4c0d7974a8c79d1fcb66eb5238af659cee72da9cbcc0ecfdb1dfd06ad8d',
                   '04cc51ab1c4c5a57ec2fdff4ec7777a8f5055810681ba962d933bb46d9a7d7a9'),
                  ('622fd3821cdcc6d76cd50b81a9843a65a1ecf386a484619de41d955a36b899d6',
                   '04cc51ab1c4c5a57ec2fdff4ec7777a8f5055810681ba962d933bb46d9a7d7a9'),
                  ('75795806022c7b433c33a6cb7509c0b2073048087b2dc3be9c31da3557b5ea6b',
                   '04cc51ab1c4c5a57ec2fdff4ec7777a8f5055810681ba962d933bb46d9a7d7a9'),
                  ('7a646c6f2cf6b42b51eb2db74aaab7fd721991b9f69560b0b626123c74109fb8',
                   '04cc51ab1c4c5a57ec2fdff4ec7777a8f5055810681ba962d933bb46d9a7d7a9'),
                  ('7fb8b0e124e9ef68867475fdd40a87e06329c22b651fa7633a430b6609f0a2dc',
                   '04cc51ab1c4c5a57ec2fdff4ec7777a8f5055810681ba962d933bb46d9a7d7a9'),
                  ('9b6da4f5454d597f701447a3a438b2473f3ffea3e6674e50510561c663080209',
                   '04cc51ab1c4c5a57ec2fdff4ec7777a8f5055810681ba962d933bb46d9a7d7a9'),
                  ('ad211a3b94807b1a58b7ace0ff9b661f953157c308ed7494a247cf22f7fe5292',
                   '04cc51ab1c4c5a57ec2fdff4ec7777a8f5055810681ba962d933bb46d9a7d7a9'),
                  ('ae75f62b4d6622bdda5a093cf0057e699ef78adf6cede16879b1859b7c4220ad',
                   '04cc51ab1c4c5a57ec2fdff4ec7777a8f5055810681ba962d933bb46d9a7d7a9'),
                  ('b5b4482c4e668b96d3be49529ea6672c677fe965ec07fe3e34128f3070eee29f',
                   '04cc51ab1c4c5a57ec2fdff4ec7777a8f5055810681ba962d933bb46d9a7d7a9'),
                  ('cd883e2ea724c84a254696c722a03af42b3e6a8c53857b9b654bbcef1d416911',
                   '04cc51ab1c4c5a57ec2fdff4ec7777a8f5055810681ba962d933bb46d9a7d7a9'),
                  ('dcae7a5b23fc084f997d2bcaa432039f2e71adf9c5121f56e71c0c707d2742df',
                   '04cc51ab1c4c5a57ec2fdff4ec7777a8f5055810681ba962d933bb46d9a7d7a9'),
                  ('e4607078a7efc86a64ab97682b2b0c438453723024130c8a0a197f4c7e31e939',
                   '04cc51ab1c4c5a57ec2fdff4ec7777a8f5055810681ba962d933bb46d9a7d7a9'),
                  ('04cc51ab1c4c5a57ec2fdff4ec7777a8f5055810681ba962d933bb46d9a7d7a9',
                   'c67417e1ab46a294339279f28be7e432eee4869d9eb0101f50fe2eda5c275269'),
                  ('2d3d0be0c14de4f673f23d90128086d66425e36daf488bc21897aeb199a21c76',
                   'c67417e1ab46a294339279f28be7e432eee4869d9eb0101f50fe2eda5c275269'),
                  ('44a237bb746364e67f008f6278540874d798a85a1726cc360a4a1b242e6bad84',
                   'c67417e1ab46a294339279f28be7e432eee4869d9eb0101f50fe2eda5c275269'),
                  ('5a070f3d72e46b0cc8ca926dc06a1118405a0b8a28413176d19bbdde8fc21aff',
                   'c67417e1ab46a294339279f28be7e432eee4869d9eb0101f50fe2eda5c275269'),
                  ('5d3af4c0d7974a8c79d1fcb66eb5238af659cee72da9cbcc0ecfdb1dfd06ad8d',
                   'c67417e1ab46a294339279f28be7e432eee4869d9eb0101f50fe2eda5c275269'),
                  ('622fd3821cdcc6d76cd50b81a9843a65a1ecf386a484619de41d955a36b899d6',
                   'c67417e1ab46a294339279f28be7e432eee4869d9eb0101f50fe2eda5c275269'),
                  ('75795806022c7b433c33a6cb7509c0b2073048087b2dc3be9c31da3557b5ea6b',
                   'c67417e1ab46a294339279f28be7e432eee4869d9eb0101f50fe2eda5c275269'),
                  ('7a646c6f2cf6b42b51eb2db74aaab7fd721991b9f69560b0b626123c74109fb8',
                   'c67417e1ab46a294339279f28be7e432eee4869d9eb0101f50fe2eda5c275269'),
                  ('7fb8b0e124e9ef68867475fdd40a87e06329c22b651fa7633a430b6609f0a2dc',
                   'c67417e1ab46a294339279f28be7e432eee4869d9eb0101f50fe2eda5c275269'),
                  ('9b6da4f5454d597f701447a3a438b2473f3ffea3e6674e50510561c663080209',
                   'c67417e1ab46a294339279f28be7e432eee4869d9eb0101f50fe2eda5c275269'),
                  ('ad211a3b94807b1a58b7ace0ff9b661f953157c308ed7494a247cf22f7fe5292',
                   'c67417e1ab46a294339279f28be7e432eee4869d9eb0101f50fe2eda5c275269'),
                  ('ae75f62b4d6622bdda5a093cf0057e699ef78adf6cede16879b1859b7c4220ad',
                   'c67417e1ab46a294339279f28be7e432eee4869d9eb0101f50fe2eda5c275269'),
                  ('b5b4482c4e668b96d3be49529ea6672c677fe965ec07fe3e34128f3070eee29f',
                   'c67417e1ab46a294339279f28be7e432eee4869d9eb0101f50fe2eda5c275269'),
                  ('cd883e2ea724c84a254696c722a03af42b3e6a8c53857b9b654bbcef1d416911',
                   'c67417e1ab46a294339279f28be7e432eee4869d9eb0101f50fe2eda5c275269'),
                  ('dcae7a5b23fc084f997d2bcaa432039f2e71adf9c5121f56e71c0c707d2742df',
                   'c67417e1ab46a294339279f28be7e432eee4869d9eb0101f50fe2eda5c275269'),
                  ('e4607078a7efc86a64ab97682b2b0c438453723024130c8a0a197f4c7e31e939',
                   'c67417e1ab46a294339279f28be7e432eee4869d9eb0101f50fe2eda5c275269'),
                  ('04cc51ab1c4c5a57ec2fdff4ec7777a8f5055810681ba962d933bb46d9a7d7a9',
                   'd61581ad0ddf79309404f7dd281e9beca99c560bc70293f85c2c8fe2d96e8c57'),
                  ('2d3d0be0c14de4f673f23d90128086d66425e36daf488bc21897aeb199a21c76',
                   'd61581ad0ddf79309404f7dd281e9beca99c560bc70293f85c2c8fe2d96e8c57'),
                  ('44a237bb746364e67f008f6278540874d798a85a1726cc360a4a1b242e6bad84',
                   'd61581ad0ddf79309404f7dd281e9beca99c560bc70293f85c2c8fe2d96e8c57'),
                  ('5a070f3d72e46b0cc8ca926dc06a1118405a0b8a28413176d19bbdde8fc21aff',
                   'd61581ad0ddf79309404f7dd281e9beca99c560bc70293f85c2c8fe2d96e8c57'),
                  ('5d3af4c0d7974a8c79d1fcb66eb5238af659cee72da9cbcc0ecfdb1dfd06ad8d',
                   'd61581ad0ddf79309404f7dd281e9beca99c560bc70293f85c2c8fe2d96e8c57'),
                  ('622fd3821cdcc6d76cd50b81a9843a65a1ecf386a484619de41d955a36b899d6',
                   'd61581ad0ddf79309404f7dd281e9beca99c560bc70293f85c2c8fe2d96e8c57'),
                  ('75795806022c7b433c33a6cb7509c0b2073048087b2dc3be9c31da3557b5ea6b',
                   'd61581ad0ddf79309404f7dd281e9beca99c560bc70293f85c2c8fe2d96e8c57'),
                  ('7a646c6f2cf6b42b51eb2db74aaab7fd721991b9f69560b0b626123c74109fb8',
                   'd61581ad0ddf79309404f7dd281e9beca99c560bc70293f85c2c8fe2d96e8c57'),
                  ('7fb8b0e124e9ef68867475fdd40a87e06329c22b651fa7633a430b6609f0a2dc',
                   'd61581ad0ddf79309404f7dd281e9beca99c560bc70293f85c2c8fe2d96e8c57'),
                  ('9b6da4f5454d597f701447a3a438b2473f3ffea3e6674e50510561c663080209',
                   'd61581ad0ddf79309404f7dd281e9beca99c560bc70293f85c2c8fe2d96e8c57'),
                  ('ad211a3b94807b1a58b7ace0ff9b661f953157c308ed7494a247cf22f7fe5292',
                   'd61581ad0ddf79309404f7dd281e9beca99c560bc70293f85c2c8fe2d96e8c57'),
                  ('ae75f62b4d6622bdda5a093cf0057e699ef78adf6cede16879b1859b7c4220ad',
                   'd61581ad0ddf79309404f7dd281e9beca99c560bc70293f85c2c8fe2d96e8c57'),
                  ('b5b4482c4e668b96d3be49529ea6672c677fe965ec07fe3e34128f3070eee29f',
                   'd61581ad0ddf79309404f7dd281e9beca99c560bc70293f85c2c8fe2d96e8c57'),
                  ('c67417e1ab46a294339279f28be7e432eee4869d9eb0101f50fe2eda5c275269',
                   'd61581ad0ddf79309404f7dd281e9beca99c560bc70293f85c2c8fe2d96e8c57'),
                  ('cd883e2ea724c84a254696c722a03af42b3e6a8c53857b9b654bbcef1d416911',
                   'd61581ad0ddf79309404f7dd281e9beca99c560bc70293f85c2c8fe2d96e8c57'),
                  ('dcae7a5b23fc084f997d2bcaa432039f2e71adf9c5121f56e71c0c707d2742df',
                   'd61581ad0ddf79309404f7dd281e9beca99c560bc70293f85c2c8fe2d96e8c57'),
                  ('e4607078a7efc86a64ab97682b2b0c438453723024130c8a0a197f4c7e31e939',
                   'd61581ad0ddf79309404f7dd281e9beca99c560bc70293f85c2c8fe2d96e8c57'),
                  ('04cc51ab1c4c5a57ec2fdff4ec7777a8f5055810681ba962d933bb46d9a7d7a9',
                   '8ee2a0aa6a32b12d09166451315254262eea7e8d77965962be4cb58ec0e360a1'),
                  ('2d3d0be0c14de4f673f23d90128086d66425e36daf488bc21897aeb199a21c76',
                   '8ee2a0aa6a32b12d09166451315254262eea7e8d77965962be4cb58ec0e360a1'),
                  ('44a237bb746364e67f008f6278540874d798a85a1726cc360a4a1b242e6bad84',
                   '8ee2a0aa6a32b12d09166451315254262eea7e8d77965962be4cb58ec0e360a1'),
                  ('5a070f3d72e46b0cc8ca926dc06a1118405a0b8a28413176d19bbdde8fc21aff',
                   '8ee2a0aa6a32b12d09166451315254262eea7e8d77965962be4cb58ec0e360a1'),
                  ('5d3af4c0d7974a8c79d1fcb66eb5238af659cee72da9cbcc0ecfdb1dfd06ad8d',
                   '8ee2a0aa6a32b12d09166451315254262eea7e8d77965962be4cb58ec0e360a1'),
                  ('622fd3821cdcc6d76cd50b81a9843a65a1ecf386a484619de41d955a36b899d6',
                   '8ee2a0aa6a32b12d09166451315254262eea7e8d77965962be4cb58ec0e360a1'),
                  ('75795806022c7b433c33a6cb7509c0b2073048087b2dc3be9c31da3557b5ea6b',
                   '8ee2a0aa6a32b12d09166451315254262eea7e8d77965962be4cb58ec0e360a1'),
                  ('7a646c6f2cf6b42b51eb2db74aaab7fd721991b9f69560b0b626123c74109fb8',
                   '8ee2a0aa6a32b12d09166451315254262eea7e8d77965962be4cb58ec0e360a1'),
                  ('7fb8b0e124e9ef68867475fdd40a87e06329c22b651fa7633a430b6609f0a2dc',
                   '8ee2a0aa6a32b12d09166451315254262eea7e8d77965962be4cb58ec0e360a1'),
                  ('9b6da4f5454d597f701447a3a438b2473f3ffea3e6674e50510561c663080209',
                   '8ee2a0aa6a32b12d09166451315254262eea7e8d77965962be4cb58ec0e360a1'),
                  ('ad211a3b94807b1a58b7ace0ff9b661f953157c308ed7494a247cf22f7fe5292',
                   '8ee2a0aa6a32b12d09166451315254262eea7e8d77965962be4cb58ec0e360a1'),
                  ('ae75f62b4d6622bdda5a093cf0057e699ef78adf6cede16879b1859b7c4220ad',
                   '8ee2a0aa6a32b12d09166451315254262eea7e8d77965962be4cb58ec0e360a1'),
                  ('b5b4482c4e668b96d3be49529ea6672c677fe965ec07fe3e34128f3070eee29f',
                   '8ee2a0aa6a32b12d09166451315254262eea7e8d77965962be4cb58ec0e360a1'),
                  ('c67417e1ab46a294339279f28be7e432eee4869d9eb0101f50fe2eda5c275269',
                   '8ee2a0aa6a32b12d09166451315254262eea7e8d77965962be4cb58ec0e360a1'),
                  ('cd883e2ea724c84a254696c722a03af42b3e6a8c53857b9b654bbcef1d416911',
                   '8ee2a0aa6a32b12d09166451315254262eea7e8d77965962be4cb58ec0e360a1'),
                  ('d61581ad0ddf79309404f7dd281e9beca99c560bc70293f85c2c8fe2d96e8c57',
                   '8ee2a0aa6a32b12d09166451315254262eea7e8d77965962be4cb58ec0e360a1'),
                  ('dcae7a5b23fc084f997d2bcaa432039f2e71adf9c5121f56e71c0c707d2742df',
                   '8ee2a0aa6a32b12d09166451315254262eea7e8d77965962be4cb58ec0e360a1'),
                  ('e4607078a7efc86a64ab97682b2b0c438453723024130c8a0a197f4c7e31e939',
                   '8ee2a0aa6a32b12d09166451315254262eea7e8d77965962be4cb58ec0e360a1'),
                  ('04cc51ab1c4c5a57ec2fdff4ec7777a8f5055810681ba962d933bb46d9a7d7a9',
                   '1c070596b3cfd5c97caac82dbfff2051acd6b2de649d639251b02526a7e595fe'),
                  ('2d3d0be0c14de4f673f23d90128086d66425e36daf488bc21897aeb199a21c76',
                   '1c070596b3cfd5c97caac82dbfff2051acd6b2de649d639251b02526a7e595fe'),
                  ('44a237bb746364e67f008f6278540874d798a85a1726cc360a4a1b242e6bad84',
                   '1c070596b3cfd5c97caac82dbfff2051acd6b2de649d639251b02526a7e595fe'),
                  ('5a070f3d72e46b0cc8ca926dc06a1118405a0b8a28413176d19bbdde8fc21aff',
                   '1c070596b3cfd5c97caac82dbfff2051acd6b2de649d639251b02526a7e595fe'),
                  ('5d3af4c0d7974a8c79d1fcb66eb5238af659cee72da9cbcc0ecfdb1dfd06ad8d',
                   '1c070596b3cfd5c97caac82dbfff2051acd6b2de649d639251b02526a7e595fe'),
                  ('622fd3821cdcc6d76cd50b81a9843a65a1ecf386a484619de41d955a36b899d6',
                   '1c070596b3cfd5c97caac82dbfff2051acd6b2de649d639251b02526a7e595fe'),
                  ('75795806022c7b433c33a6cb7509c0b2073048087b2dc3be9c31da3557b5ea6b',
                   '1c070596b3cfd5c97caac82dbfff2051acd6b2de649d639251b02526a7e595fe'),
                  ('7a646c6f2cf6b42b51eb2db74aaab7fd721991b9f69560b0b626123c74109fb8',
                   '1c070596b3cfd5c97caac82dbfff2051acd6b2de649d639251b02526a7e595fe'),
                  ('7fb8b0e124e9ef68867475fdd40a87e06329c22b651fa7633a430b6609f0a2dc',
                   '1c070596b3cfd5c97caac82dbfff2051acd6b2de649d639251b02526a7e595fe'),
                  ('8ee2a0aa6a32b12d09166451315254262eea7e8d77965962be4cb58ec0e360a1',
                   '1c070596b3cfd5c97caac82dbfff2051acd6b2de649d639251b02526a7e595fe'),
                  ('9b6da4f5454d597f701447a3a438b2473f3ffea3e6674e50510561c663080209',
                   '1c070596b3cfd5c97caac82dbfff2051acd6b2de649d639251b02526a7e595fe'),
                  ('ad211a3b94807b1a58b7ace0ff9b661f953157c308ed7494a247cf22f7fe5292',
                   '1c070596b3cfd5c97caac82dbfff2051acd6b2de649d639251b02526a7e595fe'),
                  ('ae75f62b4d6622bdda5a093cf0057e699ef78adf6cede16879b1859b7c4220ad',
                   '1c070596b3cfd5c97caac82dbfff2051acd6b2de649d639251b02526a7e595fe'),
                  ('b5b4482c4e668b96d3be49529ea6672c677fe965ec07fe3e34128f3070eee29f',
                   '1c070596b3cfd5c97caac82dbfff2051acd6b2de649d639251b02526a7e595fe'),
                  ('c67417e1ab46a294339279f28be7e432eee4869d9eb0101f50fe2eda5c275269',
                   '1c070596b3cfd5c97caac82dbfff2051acd6b2de649d639251b02526a7e595fe'),
                  ('cd883e2ea724c84a254696c722a03af42b3e6a8c53857b9b654bbcef1d416911',
                   '1c070596b3cfd5c97caac82dbfff2051acd6b2de649d639251b02526a7e595fe'),
                  ('d61581ad0ddf79309404f7dd281e9beca99c560bc70293f85c2c8fe2d96e8c57',
                   '1c070596b3cfd5c97caac82dbfff2051acd6b2de649d639251b02526a7e595fe'),
                  ('dcae7a5b23fc084f997d2bcaa432039f2e71adf9c5121f56e71c0c707d2742df',
                   '1c070596b3cfd5c97caac82dbfff2051acd6b2de649d639251b02526a7e595fe'),
                  ('e4607078a7efc86a64ab97682b2b0c438453723024130c8a0a197f4c7e31e939',
                   '1c070596b3cfd5c97caac82dbfff2051acd6b2de649d639251b02526a7e595fe')],
 'padml/runtime.py': [('f0cf53a3b363164f9455f2002e9cc358891188985df7856a93159be2c52d126d',
                       'cc6e68fd6da35fdfa165cb27f7d6b5961a6cf87e57ac5014d78a83a7a0641c41'),
                      ('f321f103426cb37820a770438da3d8d9d842266fe19cdbd1e526eb1393fa9167',
                       'cc6e68fd6da35fdfa165cb27f7d6b5961a6cf87e57ac5014d78a83a7a0641c41'),
                      ('8a45d16c1b2829b00a06910cb0de47298e62d7261f81fee8444d86ceef9b39b6',
                       'cc6e68fd6da35fdfa165cb27f7d6b5961a6cf87e57ac5014d78a83a7a0641c41'),
                      ('a160793f49657ca66d70b79a958b69abc7dd6128eaf36238b1049959d60fb804',
                       'cc6e68fd6da35fdfa165cb27f7d6b5961a6cf87e57ac5014d78a83a7a0641c41'),
                      ('53f1121f31a416ca89b6571ec3964c1a8a88d034c06d44c5507f7b807939b3e6',
                       'cc6e68fd6da35fdfa165cb27f7d6b5961a6cf87e57ac5014d78a83a7a0641c41'),
                      ('6880403fd0e619731639e4a7c526e43af7b860c10ed28475fa26daddb126a522',
                       'cc6e68fd6da35fdfa165cb27f7d6b5961a6cf87e57ac5014d78a83a7a0641c41'),
                      ('c0c635f55050b332f615693079860c4992ed1e6500734f1e22eff6ed1050a297',
                       'cc6e68fd6da35fdfa165cb27f7d6b5961a6cf87e57ac5014d78a83a7a0641c41')],
 'padml/runtime_bundle.py': [('d8860759e11dc6e600a87982f5f63c2f3b526b8f0d784773277fb8984552c94d',
                              'bfd892ce36692c56979be6eb686b9561adb1275dbbaff249f2af63e4ac674ca2'),
                             ('bfd892ce36692c56979be6eb686b9561adb1275dbbaff249f2af63e4ac674ca2',
                              'a2d743c063b9c2295d00744558c75f5da06ef28e5bcdc1b900710e3a0a7dc0de'),
                             ('d8860759e11dc6e600a87982f5f63c2f3b526b8f0d784773277fb8984552c94d',
                              'a2d743c063b9c2295d00744558c75f5da06ef28e5bcdc1b900710e3a0a7dc0de')],
 'padml/worker.py': [('b84fed7457b1efac09a31a24cf9ec3c73014ebf5b4a6620c7066bbc84b471723',
                      '00cdfccafa67086607095ab17c1b30b3dc8cb0462118059b394746d19321abbd'),
                     ('c417c16ca33cda6c0f1170e0ca1dd0d6f42d004f6a4f1a4447d51c3c23ddc8cd',
                      '00cdfccafa67086607095ab17c1b30b3dc8cb0462118059b394746d19321abbd'),
                     ('07b6b1ed83e7c933320efde44044c710b90567e8975abcb8c3c5bc3564fb4e35',
                      '00cdfccafa67086607095ab17c1b30b3dc8cb0462118059b394746d19321abbd'),
                     ('868e3185791bd7df2c85a7f439189c8a04b37bb363eec9460e3fdab2daded49c',
                      '00cdfccafa67086607095ab17c1b30b3dc8cb0462118059b394746d19321abbd'),
                     ('e9107b71f578a5943472cf34b5c8cb03fa41cdb4309774e739b3b0a51ccaa90c',
                      '00cdfccafa67086607095ab17c1b30b3dc8cb0462118059b394746d19321abbd'),
                     ('730aee755e3a9141493325fa9b0e1bd28faab332e55003b9ab24b9b0186976d7',
                      '00cdfccafa67086607095ab17c1b30b3dc8cb0462118059b394746d19321abbd'),
                     ('304254ea362339c0b0ba234e477482e1d3abbd803f8a640bb0472237f7c37bde',
                      '00cdfccafa67086607095ab17c1b30b3dc8cb0462118059b394746d19321abbd'),
                     ('cd0fb060ce9f02053119164169afc85225f66be43a23e092d38e1a49796850ac',
                      '00cdfccafa67086607095ab17c1b30b3dc8cb0462118059b394746d19321abbd'),
                     ('7716be521e6940b6c33a5ef630dc9b097b94db74d0d3de6ccd7370ac3b47a355',
                      '00cdfccafa67086607095ab17c1b30b3dc8cb0462118059b394746d19321abbd'),
                     ('00cdfccafa67086607095ab17c1b30b3dc8cb0462118059b394746d19321abbd',
                      '42d0dbf1eea94696052d205dbc170626085856c3d935accba4a5a18423f8c3c6'),
                     ('b84fed7457b1efac09a31a24cf9ec3c73014ebf5b4a6620c7066bbc84b471723',
                      '42d0dbf1eea94696052d205dbc170626085856c3d935accba4a5a18423f8c3c6'),
                     ('c417c16ca33cda6c0f1170e0ca1dd0d6f42d004f6a4f1a4447d51c3c23ddc8cd',
                      '42d0dbf1eea94696052d205dbc170626085856c3d935accba4a5a18423f8c3c6'),
                     ('07b6b1ed83e7c933320efde44044c710b90567e8975abcb8c3c5bc3564fb4e35',
                      '42d0dbf1eea94696052d205dbc170626085856c3d935accba4a5a18423f8c3c6'),
                     ('868e3185791bd7df2c85a7f439189c8a04b37bb363eec9460e3fdab2daded49c',
                      '42d0dbf1eea94696052d205dbc170626085856c3d935accba4a5a18423f8c3c6'),
                     ('e9107b71f578a5943472cf34b5c8cb03fa41cdb4309774e739b3b0a51ccaa90c',
                      '42d0dbf1eea94696052d205dbc170626085856c3d935accba4a5a18423f8c3c6'),
                     ('730aee755e3a9141493325fa9b0e1bd28faab332e55003b9ab24b9b0186976d7',
                      '42d0dbf1eea94696052d205dbc170626085856c3d935accba4a5a18423f8c3c6'),
                     ('304254ea362339c0b0ba234e477482e1d3abbd803f8a640bb0472237f7c37bde',
                      '42d0dbf1eea94696052d205dbc170626085856c3d935accba4a5a18423f8c3c6'),
                     ('cd0fb060ce9f02053119164169afc85225f66be43a23e092d38e1a49796850ac',
                      '42d0dbf1eea94696052d205dbc170626085856c3d935accba4a5a18423f8c3c6'),
                     ('7716be521e6940b6c33a5ef630dc9b097b94db74d0d3de6ccd7370ac3b47a355',
                      '42d0dbf1eea94696052d205dbc170626085856c3d935accba4a5a18423f8c3c6'),
                     ('00cdfccafa67086607095ab17c1b30b3dc8cb0462118059b394746d19321abbd',
                      '71f6366bf95cd82dec70b2b687f7b16febfe2d9b710a9b75f83f44b8de5f18d0'),
                     ('07b6b1ed83e7c933320efde44044c710b90567e8975abcb8c3c5bc3564fb4e35',
                      '71f6366bf95cd82dec70b2b687f7b16febfe2d9b710a9b75f83f44b8de5f18d0'),
                     ('304254ea362339c0b0ba234e477482e1d3abbd803f8a640bb0472237f7c37bde',
                      '71f6366bf95cd82dec70b2b687f7b16febfe2d9b710a9b75f83f44b8de5f18d0'),
                     ('42d0dbf1eea94696052d205dbc170626085856c3d935accba4a5a18423f8c3c6',
                      '71f6366bf95cd82dec70b2b687f7b16febfe2d9b710a9b75f83f44b8de5f18d0'),
                     ('730aee755e3a9141493325fa9b0e1bd28faab332e55003b9ab24b9b0186976d7',
                      '71f6366bf95cd82dec70b2b687f7b16febfe2d9b710a9b75f83f44b8de5f18d0'),
                     ('7716be521e6940b6c33a5ef630dc9b097b94db74d0d3de6ccd7370ac3b47a355',
                      '71f6366bf95cd82dec70b2b687f7b16febfe2d9b710a9b75f83f44b8de5f18d0'),
                     ('868e3185791bd7df2c85a7f439189c8a04b37bb363eec9460e3fdab2daded49c',
                      '71f6366bf95cd82dec70b2b687f7b16febfe2d9b710a9b75f83f44b8de5f18d0'),
                     ('b84fed7457b1efac09a31a24cf9ec3c73014ebf5b4a6620c7066bbc84b471723',
                      '71f6366bf95cd82dec70b2b687f7b16febfe2d9b710a9b75f83f44b8de5f18d0'),
                     ('c417c16ca33cda6c0f1170e0ca1dd0d6f42d004f6a4f1a4447d51c3c23ddc8cd',
                      '71f6366bf95cd82dec70b2b687f7b16febfe2d9b710a9b75f83f44b8de5f18d0'),
                     ('cd0fb060ce9f02053119164169afc85225f66be43a23e092d38e1a49796850ac',
                      '71f6366bf95cd82dec70b2b687f7b16febfe2d9b710a9b75f83f44b8de5f18d0'),
                     ('e9107b71f578a5943472cf34b5c8cb03fa41cdb4309774e739b3b0a51ccaa90c',
                      '71f6366bf95cd82dec70b2b687f7b16febfe2d9b710a9b75f83f44b8de5f18d0'),
                     ('00cdfccafa67086607095ab17c1b30b3dc8cb0462118059b394746d19321abbd',
                      'c78a38e90f637e104bfdcde11552855dc0d4a1f6c66ef04b2734acc8a26b3c16'),
                     ('07b6b1ed83e7c933320efde44044c710b90567e8975abcb8c3c5bc3564fb4e35',
                      'c78a38e90f637e104bfdcde11552855dc0d4a1f6c66ef04b2734acc8a26b3c16'),
                     ('304254ea362339c0b0ba234e477482e1d3abbd803f8a640bb0472237f7c37bde',
                      'c78a38e90f637e104bfdcde11552855dc0d4a1f6c66ef04b2734acc8a26b3c16'),
                     ('42d0dbf1eea94696052d205dbc170626085856c3d935accba4a5a18423f8c3c6',
                      'c78a38e90f637e104bfdcde11552855dc0d4a1f6c66ef04b2734acc8a26b3c16'),
                     ('71f6366bf95cd82dec70b2b687f7b16febfe2d9b710a9b75f83f44b8de5f18d0',
                      'c78a38e90f637e104bfdcde11552855dc0d4a1f6c66ef04b2734acc8a26b3c16'),
                     ('730aee755e3a9141493325fa9b0e1bd28faab332e55003b9ab24b9b0186976d7',
                      'c78a38e90f637e104bfdcde11552855dc0d4a1f6c66ef04b2734acc8a26b3c16'),
                     ('7716be521e6940b6c33a5ef630dc9b097b94db74d0d3de6ccd7370ac3b47a355',
                      'c78a38e90f637e104bfdcde11552855dc0d4a1f6c66ef04b2734acc8a26b3c16'),
                     ('868e3185791bd7df2c85a7f439189c8a04b37bb363eec9460e3fdab2daded49c',
                      'c78a38e90f637e104bfdcde11552855dc0d4a1f6c66ef04b2734acc8a26b3c16'),
                     ('b84fed7457b1efac09a31a24cf9ec3c73014ebf5b4a6620c7066bbc84b471723',
                      'c78a38e90f637e104bfdcde11552855dc0d4a1f6c66ef04b2734acc8a26b3c16'),
                     ('c417c16ca33cda6c0f1170e0ca1dd0d6f42d004f6a4f1a4447d51c3c23ddc8cd',
                      'c78a38e90f637e104bfdcde11552855dc0d4a1f6c66ef04b2734acc8a26b3c16'),
                     ('cd0fb060ce9f02053119164169afc85225f66be43a23e092d38e1a49796850ac',
                      'c78a38e90f637e104bfdcde11552855dc0d4a1f6c66ef04b2734acc8a26b3c16'),
                     ('e9107b71f578a5943472cf34b5c8cb03fa41cdb4309774e739b3b0a51ccaa90c',
                      'c78a38e90f637e104bfdcde11552855dc0d4a1f6c66ef04b2734acc8a26b3c16')],
 'science-decision.json': [('a45df6db27fd66cf0db6e6cdba0e08467b2857c40577f1bdd1f0731065db283b',
                            '47cc9a97628498e6db58efa1d1cc64aacf455aaccf54949328cd6bb05f1b1a9d')],
 'validation/local-checks.json': [('2c2ae9d542d0e2c13fb87c6a439d4b76d473ce36eda23b6a2a2e576514e4960d',
                                   '4c799a809e7594c73eadbf77be1ecea5f9ea6740ea3416854a4b3bdf2403f254'),
                                  ('af5b6069d998a7445c5e3b682b99b4be25921fdfebc3e17fd7d4d91103558aac',
                                   '4c799a809e7594c73eadbf77be1ecea5f9ea6740ea3416854a4b3bdf2403f254'),
                                  ('a9b643192d7fd6faf1a4735551984d695299838c38c634e47e85fd0b4708e4a3',
                                   '4c799a809e7594c73eadbf77be1ecea5f9ea6740ea3416854a4b3bdf2403f254'),
                                  ('0fc5a35e8b4b9b6d61bbb20f0dc75a53962831dc348fafd35b3e99140c6f4fe2',
                                   '4c799a809e7594c73eadbf77be1ecea5f9ea6740ea3416854a4b3bdf2403f254'),
                                  ('220a9ef3a97b9511b9bd62097f5978382d0029dc37c9c3e804c6845dc4e94484',
                                   '4c799a809e7594c73eadbf77be1ecea5f9ea6740ea3416854a4b3bdf2403f254'),
                                  ('c68aa48642d31a490bc83e0dcb4266e285ce13de7316af2d1d97351d51614b41',
                                   '4c799a809e7594c73eadbf77be1ecea5f9ea6740ea3416854a4b3bdf2403f254'),
                                  ('08aa3f48258cbe51d831e01dcb2eeae8b8b266b5c7350df170e788a46f522330',
                                   '4c799a809e7594c73eadbf77be1ecea5f9ea6740ea3416854a4b3bdf2403f254'),
                                  ('9cd60bbf1f66f9157387af9efc3ac28c34634f9869baae89842a8df78fe7ce73',
                                   '4c799a809e7594c73eadbf77be1ecea5f9ea6740ea3416854a4b3bdf2403f254'),
                                  ('e88fa927d45329bacfa988778ed9791f02ce900d4bc8fd3f7e7f74ff85d24117',
                                   '4c799a809e7594c73eadbf77be1ecea5f9ea6740ea3416854a4b3bdf2403f254'),
                                  ('04f9c75a9eb5c6b1c9c1cc30a286c011fb5375bb0af17b53b2edd06b9906613c',
                                   '4c799a809e7594c73eadbf77be1ecea5f9ea6740ea3416854a4b3bdf2403f254'),
                                  ('e24efa3f9dd41c9860ac3da17dfe6fd93212ea854017db164413eab3a486bf2c',
                                   '4c799a809e7594c73eadbf77be1ecea5f9ea6740ea3416854a4b3bdf2403f254'),
                                  ('c857c9ed9d9064a8325ef3b961c6fcc69b7d8d72b23a0dfd2ef6a337c2b7fd51',
                                   '4c799a809e7594c73eadbf77be1ecea5f9ea6740ea3416854a4b3bdf2403f254'),
                                  ('66abb8cf200cdbd8fe1a87c34a9f57837779ab2c17a795ff3bd7e835d9eede5a',
                                   '4c799a809e7594c73eadbf77be1ecea5f9ea6740ea3416854a4b3bdf2403f254'),
                                  ('04f9c75a9eb5c6b1c9c1cc30a286c011fb5375bb0af17b53b2edd06b9906613c',
                                   '3839e31dd6ca53e7620c03ba6b62545177fc7e0427d09fb1c88d0f94dcef3c1b'),
                                  ('08aa3f48258cbe51d831e01dcb2eeae8b8b266b5c7350df170e788a46f522330',
                                   '3839e31dd6ca53e7620c03ba6b62545177fc7e0427d09fb1c88d0f94dcef3c1b'),
                                  ('0fc5a35e8b4b9b6d61bbb20f0dc75a53962831dc348fafd35b3e99140c6f4fe2',
                                   '3839e31dd6ca53e7620c03ba6b62545177fc7e0427d09fb1c88d0f94dcef3c1b'),
                                  ('220a9ef3a97b9511b9bd62097f5978382d0029dc37c9c3e804c6845dc4e94484',
                                   '3839e31dd6ca53e7620c03ba6b62545177fc7e0427d09fb1c88d0f94dcef3c1b'),
                                  ('2c2ae9d542d0e2c13fb87c6a439d4b76d473ce36eda23b6a2a2e576514e4960d',
                                   '3839e31dd6ca53e7620c03ba6b62545177fc7e0427d09fb1c88d0f94dcef3c1b'),
                                  ('4c799a809e7594c73eadbf77be1ecea5f9ea6740ea3416854a4b3bdf2403f254',
                                   '3839e31dd6ca53e7620c03ba6b62545177fc7e0427d09fb1c88d0f94dcef3c1b'),
                                  ('66abb8cf200cdbd8fe1a87c34a9f57837779ab2c17a795ff3bd7e835d9eede5a',
                                   '3839e31dd6ca53e7620c03ba6b62545177fc7e0427d09fb1c88d0f94dcef3c1b'),
                                  ('9cd60bbf1f66f9157387af9efc3ac28c34634f9869baae89842a8df78fe7ce73',
                                   '3839e31dd6ca53e7620c03ba6b62545177fc7e0427d09fb1c88d0f94dcef3c1b'),
                                  ('a9b643192d7fd6faf1a4735551984d695299838c38c634e47e85fd0b4708e4a3',
                                   '3839e31dd6ca53e7620c03ba6b62545177fc7e0427d09fb1c88d0f94dcef3c1b'),
                                  ('af5b6069d998a7445c5e3b682b99b4be25921fdfebc3e17fd7d4d91103558aac',
                                   '3839e31dd6ca53e7620c03ba6b62545177fc7e0427d09fb1c88d0f94dcef3c1b'),
                                  ('c68aa48642d31a490bc83e0dcb4266e285ce13de7316af2d1d97351d51614b41',
                                   '3839e31dd6ca53e7620c03ba6b62545177fc7e0427d09fb1c88d0f94dcef3c1b'),
                                  ('c857c9ed9d9064a8325ef3b961c6fcc69b7d8d72b23a0dfd2ef6a337c2b7fd51',
                                   '3839e31dd6ca53e7620c03ba6b62545177fc7e0427d09fb1c88d0f94dcef3c1b'),
                                  ('e24efa3f9dd41c9860ac3da17dfe6fd93212ea854017db164413eab3a486bf2c',
                                   '3839e31dd6ca53e7620c03ba6b62545177fc7e0427d09fb1c88d0f94dcef3c1b'),
                                  ('e88fa927d45329bacfa988778ed9791f02ce900d4bc8fd3f7e7f74ff85d24117',
                                   '3839e31dd6ca53e7620c03ba6b62545177fc7e0427d09fb1c88d0f94dcef3c1b')]}
    archive_launch = {
        'AGENTS.md': ('91cff507d2a72caa8b84ea7448f926e0aa8f96ad36dd4df9b944ed51e08659c3', 'd3df3e6c316f08961928d84c12bfb60d7f31155ba20f3930cac7b97696c53347'),
        'padml/reports.py': ('b5d1701874b2eab90f384ffc11963efe48e42edc7cc57132fbbd7d543659c2de', '5afbb3902fd7d95ea0f1497c551d3aeae7bebfa3178881b0840a92fc297885c6'),
        'padml/run.py': ('1c070596b3cfd5c97caac82dbfff2051acd6b2de649d639251b02526a7e595fe', '34e5e56f193bacf526ce8b3b07b41ddd591dd0e246c0600776ee8a94c591d916')}
    pair = (digest(old), digest(new))
    launch = archive_launch.get(name)
    # Ancestors are compared with the current executor as well. Extend only
    # the exact previously reviewed source pairs through this launch repair.
    def admitted(candidate):
        return (candidate in reviewed.get(name, ()) or candidate == launch
            or (launch is not None and candidate[1] == launch[1]
                and (candidate[0], launch[0]) in reviewed.get(name, ())))
    archive_transport = {'padml/run.py': ('34e5e56f193bacf526ce8b3b07b41ddd591dd0e246c0600776ee8a94c591d916', '94e1cd7818215c017ef308641e0e9593665307717a591a3cfde68f5650483005'), 'padml/reports.py': ('5afbb3902fd7d95ea0f1497c551d3aeae7bebfa3178881b0840a92fc297885c6', '44d49e57095f67bbde38fa54cdd9195f8063e352326ed207aa49a3b6c8f4d4ba')}
    transport = archive_transport.get(name)
    return (admitted(pair) or pair == transport or (transport is not None
        and pair[1] == transport[1] and admitted((pair[0], transport[0]))))


def _f45_worker_memory_revision(previous, current):
    """The authorized 2-to-1 GiB admission change alters no scientific budget."""
    from .runtime import validate_resource_policy
    before, after = validate_resource_policy(previous), validate_resource_policy(current)
    return before == after or (before["memory_bytes_per_worker"] == 2 * 1024**3
        and after["memory_bytes_per_worker"] == MIN_WORKER_MEMORY_BYTES
        and before == {**after, "memory_bytes_per_worker": before["memory_bytes_per_worker"]})


def _f45_archive_transfer_revision(previous, current):
    """A reviewed executor repair updates its own source pin, not deletion scope."""
    from .reports import validate_archive_transfer
    after = validate_archive_transfer(current)
    if previous.get('archive_transfer') is not None:
        before = validate_archive_transfer(previous)
        _require({k:v for k,v in before.items() if k != 'controller_sources'} ==
            {k:v for k,v in after.items() if k != 'controller_sources'}
            and before['controller_sources']['raw-input.xlsx'] == after['controller_sources']['raw-input.xlsx'],
            'ARCHIVE_GENERATION_REBASE_REQUIRED')


def _f45_unit_predecessor_uncached(value: Mapping[str, Any]) -> dict[str, Any] | None:
    """Admit the pinned same-run executor's whole receipts without relabeling."""
    from .f4 import F45_SOURCE_MEMBERS, load_f45_source_bundle
    from .nested_loco import validate_science_decision
    pin = value.get("unit_predecessor")
    if pin is None:
        return None
    _require(set(pin) == {"run_path", "run_sha256", "source_path", "source_sha256"},
             "F45_UNIT_PREDECESSOR_INVALID")
    path, source = _f45_predecessor_paths(pin)
    _require(all(p.is_absolute() and p.is_file() and not p.is_symlink() for p in (path, source))
        and sha256_file(path) == pin["run_sha256"] and sha256_file(source) == pin["source_sha256"],
        "F45_UNIT_PREDECESSOR_BYTES_DRIFT")
    previous = strict_json_bytes(path.read_bytes())
    for manifest in (previous, value):
        validate_science_decision(manifest["science_decision"])
    integrated = value.get("kind") == "PADML_INTEGRATED_RAW_RUN_V1"
    ignored = {"identity", "source_identity", "source_bundle_sha256", "unit_predecessor", "unit_source_predecessors", "science_decision", "budgets"}
    if integrated and previous.get('evaluation_decision') != value.get('evaluation_decision'):
        from .f4 import evaluation_decision
        _require(previous.get('evaluation_decision') is None and value.get('evaluation_decision') == evaluation_decision(),
            'EVALUATION_PREDECESSOR_CONTRACT_DRIFT')
        ignored.add('evaluation_decision')
    if integrated and previous.get('post_result_repair') != value.get('post_result_repair'):
        from .f4 import post_result_repair_decision
        repair = post_result_repair_decision()
        _require(previous.get('post_result_repair') is None and value.get('post_result_repair') == repair
            and previous['source_identity'] == repair['baseline_source_identity'],
            'POST_RESULT_REPAIR_PREDECESSOR_DRIFT')
        ignored.add('post_result_repair')
    if integrated and previous.get('curve_rmse') != value.get('curve_rmse'):
        from .curve_rmse import decision
        _require(previous.get('curve_rmse') is None and value.get('curve_rmse') == decision()
            and previous.get('post_result_repair') == value.get('post_result_repair'),
            'CURVE_RMSE_PREDECESSOR_CONTRACT_DRIFT')
        ignored.add('curve_rmse')
    if integrated and previous.get('result_closure') != value.get('result_closure'):
        from .result_closure import decision
        _require(previous.get('result_closure') is None and value.get('result_closure') == decision()
            and previous.get('curve_rmse') == value.get('curve_rmse')
            and previous.get('post_result_repair') == value.get('post_result_repair'),
            'RESULT_CLOSURE_PREDECESSOR_CONTRACT_DRIFT')
        ignored.add('result_closure')
    if integrated and previous.get('evaluation_extension') != value.get('evaluation_extension'):
        from .evaluation_extension import decision
        _require(previous.get('evaluation_extension') is None and value.get('evaluation_extension') == decision()
            and previous.get('result_closure') == value.get('result_closure'),
            'EVALUATION_EXTENSION_PREDECESSOR_DRIFT')
        ignored.add('evaluation_extension')
    if integrated and previous.get('archive_transfer') != value.get('archive_transfer'):
        _f45_archive_transfer_revision(previous, value)
        ignored.add('archive_transfer')
    if integrated and previous.get("score_repair") != value.get("score_repair"):
        _require(previous.get("score_repair") is None and isinstance(value.get("score_repair"), Mapping),
            "F45_SCORE_REPAIR_REPORT_DRIFT")
        ignored.add("score_repair")
    if integrated and previous.get("resource_policy") != value.get("resource_policy"):
        _require(_f45_worker_memory_revision(previous.get("resource_policy"), value.get("resource_policy")),
            "RAW_PREDECESSOR_RESOURCE_POLICY_DRIFT")
        ignored.add("resource_policy")
    if integrated and previous.get("environment") != value.get("environment"):
        # @environment is a final reviewed exact pair in the existing table,
        # including both lock pins, loader paths and installed manifest pins.
        _require(_f45_integrated_source_pair("@environment",
            canonical_json_bytes(previous.get("environment")),
            canonical_json_bytes(value.get("environment"))), "RAW_PREDECESSOR_ENVIRONMENT_DRIFT")
        ignored.add("environment")
    _require(previous["identity"] == sha256_bytes(canonical_json_bytes({k: v for k, v in previous.items() if k != "identity"}))
        and previous["source_bundle_sha256"] == pin["source_sha256"]
        and _f45_compatible_retention_budgets(previous["budgets"], value["budgets"])
        and {k: v for k, v in previous.items() if k not in ignored}
            == {k: v for k, v in value.items() if k not in ignored}, "F45_UNIT_PREDECESSOR_SCIENCE_DRIFT")
    _, entries = load_f45_source_bundle(source, _with_entries=True)
    root, members = Path(__file__).resolve().parent.parent, {}
    if integrated:
        _require(previous["environment"]["lock_sha256"] == sha256_bytes(entries["dependency-lock.json"])
            and value["environment"]["lock_sha256"] == sha256_file(root / "dependency-lock.json"),
            "RAW_PREDECESSOR_DEPENDENCY_LOCK_DRIFT")
        _require(previous.get("kind") == value["kind"]
            and __import__('padml.nested_loco', fromlist=['compatible_science_decisions']).compatible_science_decisions(
                previous["science_decision"], value["science_decision"])
            and previous["budgets"] == value["budgets"], "RAW_PREDECESSOR_BATCH_DRIFT")
    for name in F45_SOURCE_MEMBERS:
        old, new = entries.get(name), (root / name).read_bytes()
        if old is None:
            _require(integrated and name in {'padml/f5_a04_current.py','padml/curve_rmse.py','padml/result_closure.py',
                'padml/evaluation_extension.py','padml/auc_research.py'}
                and _f45_integrated_source_pair(name,b'',new),
                'RAW_PREDECESSOR_ADDED_SOURCE_DRIFT:'+name)
            continue
        members[name] = sha256_bytes(old)
        if old == new:
            continue
        if integrated:
            _require(_f45_integrated_source_pair(name, old, new),
                     "RAW_PREDECESSOR_SOURCE_DRIFT:" + name)
            continue
        _require(name in {"padml/f4.py", "padml/f5.py", "padml/f5_sensitivity.py", "padml/nested_loco.py", "padml/run.py", "padml/worker.py",
                          "padml/f2_kernel.py", "padml/f4_compact.py", "padml/f5_application.py",
                          "NESTED_LOCO_PROTOCOL.md", "AGENTS.md", "padml/runtime.py", "science-decision.json",
                          "padml/kernels/f4_learning_selector.R", "padml/kernels/f5_shap.R", "padml/kernels/f4_metrics.R"},
                 "F45_UNIT_PREDECESSOR_NUMERICAL_DRIFT:" + name)
        def stable(raw):
            operational = ({"_f45_aar_binding_ast", "f45_unit_predecessor", "f45_unit_predecessors", "validate_f45_resource_revision",
                            "load_f45_run"} if name == "padml/run.py" else
                           {"execute_f45"} if name == "padml/worker.py" else
                           {"_f45_same_run_source"} if name == "padml/f4.py" else set())
            return _f45_source_structure(raw, name, operational)
        _require(stable(old) == stable(new), "F45_UNIT_PREDECESSOR_NUMERICAL_DRIFT:" + name)
    _require(previous["source_identity"] == sha256_bytes(canonical_json_bytes(members)),
             "F45_UNIT_PREDECESSOR_SOURCE_DRIFT")
    return previous


def f45_unit_predecessors(value: Mapping[str, Any]) -> list[dict[str, Any]]:
    """Read pinned same-run executors, including an earlier resource cutover.

    A later manifest may name an omitted earlier executor without modifying
    any original manifest. Every edge uses the same byte/science/AST consumer.
    """
    from .integrated import is_integrated
    if is_integrated(value):
        _require(not any(value.get(k) for k in ("unit_source_predecessors", "resource_revision")),
                 "RAW_HISTORICAL_SOURCE_FORBIDDEN")
    previous, seen = [], {value["identity"]}
    def visit(owner, ancestors):
        additional = owner.get("unit_source_predecessors", [])
        _require(isinstance(additional, list) and len(additional) <= 8,
                 "F45_UNIT_PREDECESSOR_CHAIN_INVALID")
        pins = ([owner["unit_predecessor"]] if owner.get("unit_predecessor") is not None else []) + additional
        for pin in pins:
            current = f45_unit_predecessor({**owner, "unit_predecessor": pin})
            _require(current is not None and current["identity"] not in ancestors,
                     "F45_UNIT_PREDECESSOR_CHAIN_INVALID")
            if current["identity"] in seen:
                continue
            _require(len(previous) < 128, "F45_UNIT_PREDECESSOR_CHAIN_INVALID")
            seen.add(current["identity"])
            previous.append(current)
            visit(current, ancestors | {current["identity"]})
    visit(value, {value["identity"]})
    return previous


def validate_f45_resource_revision(value: Mapping[str, Any]) -> dict[str, str] | None:
    revision = value.get("resource_revision")
    if revision is None:
        return None
    _require(set(revision) == {"previous_run_path", "previous_run_sha256", "previous_source_path",
                              "previous_source_sha256"}, "F45_RESOURCE_REVISION_INVALID")
    return _f45_cached_source_validation("resource-revision", value,
        (Path(revision["previous_run_path"]), Path(revision["previous_source_path"])),
        lambda: _validate_f45_resource_revision_uncached(value))


def _validate_f45_resource_revision_uncached(value: Mapping[str, Any]) -> dict[str, str] | None:
    """Bound operational cutover to the actual earlier package of this run.

    The explicit revision keeps its own executor identity. Only exact reviewed
    source pairs qualify; line-specific readers independently enforce the H36
    population and SHAP amendments. Historical F4/F5 results remain excluded.
    """
    import ast
    from .f4 import F45_SOURCE_MEMBERS, load_f45_source_bundle
    from .nested_loco import validate_science_decision
    revision = value.get("resource_revision")
    if revision is None:
        return None
    _require(set(revision) == {"previous_run_path", "previous_run_sha256", "previous_source_path",
                              "previous_source_sha256"}, "F45_RESOURCE_REVISION_INVALID")
    old_path, source = Path(revision["previous_run_path"]), Path(revision["previous_source_path"])
    _require(old_path.is_absolute() and source.is_absolute() and not old_path.is_symlink()
        and not source.is_symlink() and sha256_file(old_path) == revision["previous_run_sha256"]
        and sha256_file(source) == revision["previous_source_sha256"], "F45_RESOURCE_REVISION_SOURCE_DRIFT")
    old = strict_json_bytes(old_path.read_bytes())
    _require(old["identity"] == sha256_bytes(canonical_json_bytes({k: v for k, v in old.items() if k != "identity"}))
        and old["source_bundle_sha256"] == revision["previous_source_sha256"]
        and "resource_revision" not in old, "F45_RESOURCE_REVISION_PREVIOUS_RUN_INVALID")
    for manifest in (old, value):
        validate_science_decision(manifest["science_decision"])
    ignored = {"identity", "source_identity", "source_bundle_sha256", "resource_revision", "unit_predecessor", "unit_source_predecessors", "science_decision", "budgets"}
    _require(_f45_compatible_retention_budgets(old["budgets"], value["budgets"])
        and {k: v for k, v in old.items() if k not in ignored}
        == {k: v for k, v in value.items() if k not in ignored}, "F45_RESOURCE_REVISION_SCIENCE_DRIFT")
    _, entries = load_f45_source_bundle(source, _with_entries=True)
    changed = {
        "padml/runtime.py": {"_visible_open_file_keys", "_scan_visible_open_file_keys", "release_step_resources",
            "_check_release_aliases", "release_completed_files"},
        "padml/f5.py": {"_current_q_atom", "_current_q_atom_result", "_current_q_reuse_key",
            "_current_q_task_batch", "_current_q_program", "_prepare_primary_outer_rsf_search"},
        "padml/f4.py": {"_f45_same_run_source", "_materialize_o_fit_input_bundle"},
        "padml/run.py": {"validate_f45_resource_revision", "load_f45_run", "_f45_aar_binding_ast", "f45_unit_predecessor", "f45_unit_predecessors"},
        "padml/worker.py": {"_f45_release", "_f45_primary", "_f45_aar", "_f45_full0", "_f45_evaluation", "execute_f45"},
        "padml/f5_sensitivity.py": {"_a12_outer_searches"},
        "padml/nested_loco.py": set(),  # Only exact score-qualified functions above.
        "padml/f2_kernel.py": set(),  # Only the exact AAR OUTER isolation adapter.
        "padml/f4_compact.py": set(),  # Only exact final-number consumer revisions.
        "padml/f5_application.py": set(),  # Only exact original-model consumer routing.
        "NESTED_LOCO_PROTOCOL.md": set(),  # Exact authorized protocol text only.
        "AGENTS.md": set(),  # Exact authorized cumulative cache instructions only.
        "science-decision.json": set(),
        "padml/kernels/f4_learning_selector.R": set(),
        "padml/kernels/f5_shap.R": set(),
        "padml/kernels/f4_metrics.R": set(),
    }
    root = Path(__file__).resolve().parent.parent
    members = {}
    for name in F45_SOURCE_MEMBERS:
        previous, current = entries[name], (root / name).read_bytes()
        members[name] = sha256_bytes(previous)
        if previous == current:
            continue
        _require(name in changed, "F45_RESOURCE_REVISION_NUMERICAL_SOURCE_DRIFT:" + name)
        def stable(raw):
            return _f45_source_structure(raw, name, changed[name], resource_revision=True)
        _require(stable(previous) == stable(current), "F45_RESOURCE_REVISION_NUMERICAL_SOURCE_DRIFT:" + name)
        if name == "padml/f5.py":
            original = next(n for n in ast.parse(previous).body if isinstance(n, ast.FunctionDef)
                            and n.name == "_current_q_atom")
            retained = next(n for n in ast.parse(current).body if isinstance(n, ast.FunctionDef)
                            and n.name == "_current_q_atom_result")
            class ProducerMetadataOnly(ast.NodeTransformer):
                def visit_Expr(self, node):
                    branch_guard = ast.parse('_require(_current_q_branch(strict_json_bytes('
                        '(root / "input.json").read_bytes())["spec"]) == job["control"].get("aar_branch"), '
                        '"F45_Q_BRANCH_MISMATCH")').body[0]
                    if ast.dump(node, include_attributes=False) == ast.dump(branch_guard, include_attributes=False):
                        return None
                    return self.generic_visit(node)
                def visit_Name(self, node):
                    if node.id == "_current_q_reuse_key":
                        node.id = "_current_q_key"
                    return node
                def visit_Dict(self, node):
                    pairs = [(k, v) for k, v in zip(node.keys, node.values)
                             if not isinstance(k, ast.Constant) or k.value != "executor_source_identity"]
                    node.keys, node.values = [k for k, _ in pairs], [v for _, v in pairs]
                    return self.generic_visit(node)
            retained_h36_stop = sha256_bytes(ast.dump(retained, include_attributes=False).encode()) == '5e21c3f74855f14433233c1df1bc5a60dc30ee2775cafdd9860729e8b7ef3017' and sha256_bytes(ast.dump(original, include_attributes=False).encode()) == "95cafc8b2370ea0532109a8e5491cd48ea788198524ceb950b5488f25571ebb5"
            retained = ProducerMetadataOnly().visit(retained)
            retained.name = original.name
            _require(retained_h36_stop or ast.dump(original, include_attributes=False) == ast.dump(retained, include_attributes=False),
                     "F45_RESOURCE_REVISION_ATOM_NUMERICS_DRIFT")
    _require(old["source_identity"] == sha256_bytes(canonical_json_bytes(members)),
             "F45_RESOURCE_REVISION_PRODUCER_DRIFT")
    return members


def _f45_score_repair_path(run, manifest_path=None):
    from .bundle import validate_relative_path
    ref = run["score_repair"]
    name = validate_relative_path(ref["path"], "score_repair.path")
    if os.environ.get("PADML_ARCHIVE_INDEX"):
        index = Path(os.environ["PADML_ARCHIVE_INDEX"])
        _require(index.is_absolute() and index.is_file() and not index.is_symlink(),
            "F45_ARCHIVE_PREDECESSOR_INDEX_INVALID")
        validate_sha256(ref["sha256"], "score_repair.report")
        return index.parent / "objects" / ref["sha256"]
    path = Path(run["run_root"]) / name
    if path.exists() or path.is_symlink():
        return path
    # The control-side manifest may live on Mac while science.run_root remains
    # its original Linux path. Only the pinned report is staged beside it.
    manifest_path = manifest_path or os.environ.get("PADML_F45_RUN_PATH")
    if manifest_path is not None:
        manifest = Path(manifest_path)
        declared = strict_json_bytes(manifest.read_bytes())
        _require(declared.get("score_repair") == ref and declared.get("run_id") == run["run_id"],
            "F45_SCORE_REPAIR_REPORT_DRIFT")
        return manifest.parent / name
    return path


def f45_score_repair(run, unit=None, *, manifest_path=None):
    """Read the one pinned, user-authorized repair report through the existing run."""
    from .bundle import validate_relative_path
    ref = run.get("score_repair")
    if ref is None:
        return None
    failure = "F45_SCORE_REPAIR_REPORT_INVALID"
    _require(isinstance(ref, Mapping) and set(ref) == {"path", "sha256", "size_bytes"}, failure)
    path = _f45_score_repair_path(run, manifest_path)
    _require(path.is_file() and not path.is_symlink() and path.resolve(strict=True) == path
        and type(ref["size_bytes"]) is int and 0 < ref["size_bytes"] <= 2 * 1024**2
        and path.stat().st_size == ref["size_bytes"] and sha256_file(path) == ref["sha256"], failure)
    report = strict_json_bytes(path.read_bytes()).get("score_repair")
    _require(isinstance(report, dict) and report.get("kind") == "PADML_F45_SCORE_REPAIR_V1"
        and report.get("run_id") == run["run_id"] and report.get("unit_id") == "PRIMARY-H06-O5"
        and report.get("source_run_identity") in {v["identity"] for v in f45_unit_predecessors(run)}
        and isinstance(report.get("coordinates"), list) and len(report["coordinates"]) == 14, failure)
    validate_sha256(report.get("request_identity_sha256"), "score_repair.request")
    paths = set()
    for row in report["coordinates"]:
        _require(isinstance(row, dict) and set(row) == {"source_record", "decision", "reason"}
            and row["decision"] in {"REFIT", "RECOVERED"} and isinstance(row["reason"], str)
            and bool(row["reason"]) and isinstance(row["source_record"], dict), failure)
        source = row["source_record"]
        _require(source.get("path") not in paths and source.get("family") in {"RSF", "GBM_COX", "COXTIME_SET_A"}, failure)
        validate_relative_path(source["path"], "score_repair.coordinate")
        paths.add(source["path"])
    if unit is not None and unit["unit_id"] != report["unit_id"]:
        return None
    return {**report, "report_sha256": ref["sha256"]}


def load_f45_run(path: Path) -> dict[str, Any]:
    from .f4 import _f45_source_member_sha256
    from .nested_loco import PROGRAM_ID, validate_science_decision, science_decision_template
    value = strict_json_bytes(path.read_bytes())
    _require(value.get("kind") in {"PADML_F45_WHOLE_UNIT_RUN_V1", "PADML_INTEGRATED_RAW_RUN_V1"} and value.get("program_id") == PROGRAM_ID
        and value.get("identity") == sha256_bytes(canonical_json_bytes({k: v for k, v in value.items() if k != "identity"}))
        and value["units"] == f45_units() and value["hosts"] == list(F45_HOSTS)
        and value["source_identity"] == sha256_bytes(canonical_json_bytes(_f45_source_member_sha256())),
        "F45_RUN_MANIFEST_OR_SOURCE_DRIFT")
    validate_science_decision(value["science_decision"])
    if value.get('archive_transfer') is not None:
        from .reports import validate_archive_transfer
        validate_archive_transfer(value)
    if value.get('evaluation_decision') is not None:
        from .f4 import evaluation_decision
        _require(value['evaluation_decision'] == evaluation_decision(),'EVALUATION_RUN_CONTRACT_DRIFT')
    if value.get('post_result_repair') is not None:
        from .f4 import post_result_repair_decision
        _require(value['post_result_repair'] == post_result_repair_decision()
            and value.get('evaluation_decision') is not None,'POST_RESULT_REPAIR_CONTRACT_DRIFT')
    if value.get('result_closure') is not None:
        from .result_closure import decision
        _require(value['result_closure'] == decision() and value.get('curve_rmse') is not None,
            'RESULT_CLOSURE_RUN_CONTRACT_DRIFT')
    if value.get('evaluation_extension') is not None:
        from .evaluation_extension import decision
        _require(value['evaluation_extension'] == decision() and value.get('result_closure') is not None,
            'EVALUATION_EXTENSION_RUN_CONTRACT_DRIFT')
    if value.get('curve_rmse') is not None:
        from .curve_rmse import decision
        _require(value['curve_rmse'] == decision() and value.get('post_result_repair') is not None,
            'CURVE_RMSE_RUN_CONTRACT_DRIFT')
    if value["kind"] == "PADML_INTEGRATED_RAW_RUN_V1":
        import re
        from .runtime import validate_resource_policy
        _require(not any(k in value for k in ("f1_runtime_root", "f2_run_root", "protected",
            "unit_source_predecessors", "resource_revision")) and isinstance(value.get("run_id"), str)
            and re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,79}", value["run_id"])
            and isinstance(value.get("raw_input"), dict) and set(value["raw_input"]) == {"path", "sha256", "size_bytes"}
            and isinstance(value["raw_input"]["path"], str) and Path(value["raw_input"]["path"]).is_absolute()
            and type(value["raw_input"]["size_bytes"]) is int and value["raw_input"]["size_bytes"] > 0
            and set(value.get("host_connections", {})) == set(F45_HOSTS)
            and set(value.get("environment", {})) - {"runtime_manifest"} == {"python", "rscript", "r_library", "lock_sha256", "artifact_paths"},
            "RAW_RUN_MANIFEST_INVALID")
        validate_sha256(value["raw_input"]["sha256"], "raw_input")
        validate_sha256(value["environment"]["lock_sha256"], "dependency_lock")
        _require(value["environment"]["lock_sha256"] == sha256_file(Path(__file__).resolve().parent.parent / "dependency-lock.json"),
                 "RAW_DEPENDENCY_LOCK_DRIFT")
        validate_resource_policy(value["resource_policy"])
    _require(value["science_decision"] == science_decision_template(), "F45_RUN_SCIENCE_REVISION_REQUIRED")
    validate_f45_resource_revision(value)
    f45_unit_predecessors(value)
    f45_score_repair(value, manifest_path=path)
    return value


def f45_ready_assignments(run: Mapping[str, Any], observations: Mapping[str, Any]) -> list[dict[str, str]]:
    """Pure next-unit choice from observed processes and consumed results, no scheduler state."""
    _require(set(observations) == set(F45_HOSTS), "F45_SEVEN_HOST_OBSERVATIONS_REQUIRED")
    units = {u["unit_id"]: u for u in run["units"]}
    completed, not_estimable, active, idle, blocked = set(), set(), set(), [], set()
    evaluation_ready = set()
    integrated = run.get("kind") == "PADML_INTEGRATED_RAW_RUN_V1"
    postprocessed, selected, active_sources, selection_lines = set(), set(), set(), set()
    source_hosts, active_science = {}, set()
    sources = {u for u, row in units.items() if row["kind"] in {"PRIMARY", "FULL0"}}
    for host, observed in observations.items():
        _require(observed.get("state") in {"IDLE", "RUNNING", "UNKNOWN"}, "F45_HOST_STATE_INVALID")
        done = set(observed.get("completed_units", []))
        _require(done <= set(units), "F45_UNKNOWN_COMPLETED_UNIT")
        completed.update(done)
        negative = set(observed.get("not_estimable_units", []))
        _require(negative <= set(units), "F45_UNKNOWN_NOT_ESTIMABLE_UNIT")
        not_estimable.update(negative)
        evaluation_sources = set(observed.get("evaluation_ready_units", []))
        _require(evaluation_sources <= {uid for uid, row in units.items() if row["kind"] in {"PRIMARY", "AAR"}},
                 "F45_UNKNOWN_EVALUATION_SOURCE")
        evaluation_ready.update(evaluation_sources)
        ready = set(observed.get("postprocess_ready_units", []))
        selection_done = set(observed.get("selection_completed_units", []))
        _require(ready <= sources and selection_done <= sources, "F45_UNKNOWN_POSTPROCESS_SOURCE")
        postprocessed.update(ready)
        selected.update(selection_done)
        for source in sorted(ready):
            source_hosts.setdefault(source, host)
        unit = observed.get("active_unit")
        mode = observed.get("active_mode", "execute")
        source = observed.get("active_source_unit")
        _require(mode in {"execute", "postprocess", "selection", "appendage"}, "F45_HOST_MODE_INVALID")
        if observed["state"] == "IDLE":
            _require(unit is None, "F45_IDLE_HOST_HAS_ACTIVE_UNIT")
            idle.append(host)
        elif unit is not None:
            _require(unit in units and (unit, mode) not in active, "F45_DUPLICATE_ACTIVE_UNIT")
            if mode == "selection" or mode == 'appendage' and source is not None:
                _require(units[unit]["kind"] == "EVALUATION" and source in sources
                    and units[source]["horizon"] == units[unit]["horizon"]
                    and units[unit]["horizon"] not in selection_lines, "F45_DUPLICATE_SELECTION_LINE")
                selection_lines.add(units[unit]["horizon"])
                active_sources.add(source)
            else:
                _require(source is None and (mode != "postprocess" or unit in sources)
                    and unit not in active_science, "F45_DUPLICATE_ACTIVE_UNIT")
                active_science.add(unit)
            active.add((unit, mode))
        else:
            # Unknown identity could be any in-flight unit: resolve it before dispatch.
            blocked.add(host)
    _require(not not_estimable.intersection(completed | postprocessed | selected),
             "F45_CONFLICTING_UNIT_TERMINALS")
    terminal = completed | not_estimable
    if blocked:
        return []
    pending = [u for u in run["units"] if u["unit_id"] not in terminal | active_science
               and set(u["depends_on"]) <= terminal
               and (not integrated or u["kind"] not in {"AAR", "EVALUATION"}
                    or set(u["depends_on"]) <= evaluation_ready
                    or u["kind"] == "EVALUATION"
                        and any(uid in not_estimable and units[uid]["kind"] == "PRIMARY" for uid in u["depends_on"])
                        and set(u["depends_on"]).intersection(not_estimable) <= evaluation_ready)]
    if integrated:
        pending.extend(u for u in run["units"] if u["kind"] == "AAR"
            and u["unit_id"] in completed - evaluation_ready - active_science)
    owners = {}
    for host, observed in observations.items():
        for context in observed.get("local_contexts", []):
            if context != "EVALUATION":
                _require(context not in owners, "F45_CONTEXT_RELOCATION_MUST_BE_RESOLVED")
                owners[context] = host
    assignments = []
    active_contexts = {units[u]["context"] for u in active_science}
    for host in idle:
        local = set(observations[host].get("local_contexts", []))
        eligible = [u for u in pending if u["context"] == "EVALUATION" or
                    u["context"] not in active_contexts and owners.get(u["context"], host) == host]
        ranked = sorted(eligible, key=lambda u: (
            u["context"] not in local, u["context"] in active_contexts,
            {"AAR": 0, "EVALUATION": 1, "PRIMARY": 2, "FULL0": 2}[u["kind"]],
            u["horizon"], u["unit_id"]))
        if ranked:
            chosen = ranked[0]
            assignments.append({"host": host, "unit_id": chosen["unit_id"]})
            pending.remove(chosen)
            active_contexts.add(chosen["context"])
            continue
        # Completed sources remain on their original context owner for the small tail.
        incomplete_tails = sources - postprocessed
        if integrated:
            incomplete_tails |= {uid for uid in sources - evaluation_ready if units[uid]["kind"] == "PRIMARY"}
        tails = sorted(incomplete_tails & completed & set(observations[host].get("completed_units", []))
            - active_science, key=lambda uid: (units[uid]["horizon"], uid))
        tails = [uid for uid in tails if units[uid]["context"] not in active_contexts
            and owners.get(units[uid]["context"], host) == host]
        if tails:
            chosen = tails[0]
            assignments.append({"host": host, "unit_id": chosen, "mode": "postprocess"})
            active_science.add(chosen)
            active_contexts.add(units[chosen]["context"])
            continue
        candidates = sorted((postprocessed & completed) - selected - active_sources,
            key=lambda uid: (units[uid]["horizon"], uid))
        candidates = [uid for uid in candidates if units[uid]["horizon"] not in selection_lines]
        if candidates:
            source = candidates[0]
            h = units[source]["horizon"]
            assignments.append({"host": host, "unit_id": f"EVALUATION-H{h:02d}", "mode": "selection",
                "source_unit": source, "source_host": source_hosts[source]})
            selection_lines.add(h)
            active_sources.add(source)
            continue
        if run.get('evaluation_decision') is not None:
            points = set().union(*(set(o.get('evaluation_amendment_units',[])) for o in observations.values()))
            revised_selection = set().union(*(set(o.get('selection_amendment_units',[])) for o in observations.values()))
            local_done = set(observations[host].get('completed_units',[]))
            extension_pending = set(observations[host].get('evaluation_extension_pending_units',[])) | set(
                observations[host].get('clinical_extension_pending_units',[]))
            if extension_pending:
                from .evaluation_extension import eligible,clinical_eligible
                _require(extension_pending <= local_done and all(eligible(run,units[u]) or clinical_eligible(run,units[u]) for u in extension_pending),
                    'EVALUATION_EXTENSION_PENDING_SCOPE')
                available = extension_pending-active_science
                available = {uid for uid in available if units[uid]['context'] not in active_contexts}
                if available:
                    uid = min(available, key=lambda u:(units[u]['horizon'],u))
                    assignments.append({'host':host,'unit_id':uid,'mode':'appendage'})
                    active_science.add(uid)
                    active_contexts.add(units[uid]['context'])
                    continue
            curve_only = set(observations[host].get('curve_pending_units',[])) | set(
                observations[host].get('result_closure_pending_units',[]))
            _require(curve_only <= local_done & {u for u in units if units[u]['kind'] in {'FULL0','EVALUATION'}},
                'F45_CURVE_PENDING_SCOPE_INVALID')
            point_candidates = sorted((local_done & (sources|{u for u in units if units[u]['kind']=='EVALUATION'}))
                - points - active_science,key=lambda u:(units[u]['kind']=='EVALUATION',units[u]['horizon'],u))
            point_candidates = [uid for uid in point_candidates if
                uid in curve_only or (uid in postprocessed and units[uid]['context'] not in active_contexts if uid in sources else
                 {v for v in units[uid]['depends_on'] if units[v]['kind']=='PRIMARY'} <= points
                    and units[uid]['horizon'] not in selection_lines)]
            if run.get('post_result_repair') is not None:
                regression_complete = any(o.get('original_application_regression_complete') is True
                    for o in observations.values())
                point_candidates = [uid for uid in point_candidates if units[uid]['kind'] != 'PRIMARY'
                    or regression_complete]
            if point_candidates:
                uid = point_candidates[0]
                assignments.append({'host':host,'unit_id':uid,'mode':'appendage'})
                active_science.add(uid)
                active_contexts.add(units[uid]['context'])
                continue
            candidates = sorted(set(observations[host].get('selection_completed_units',[]))
                - revised_selection - active_sources,key=lambda u:(units[u]['horizon'],u))
            candidates = [uid for uid in candidates if units[uid]['horizon'] not in selection_lines
                and f"EVALUATION-H{units[uid]['horizon']:02d}" not in active_science]
            if candidates:
                uid = candidates[0]
                assignments.append({'host':host,'unit_id':f"EVALUATION-H{units[uid]['horizon']:02d}",
                    'mode':'appendage','source_unit':uid})
                selection_lines.add(units[uid]['horizon'])
                active_sources.add(uid)
    return assignments


def _f45_connection(value):
    """Use normal OpenSSH configuration; credentials never enter the run package."""
    _require(isinstance(value, Mapping) and set(value) <= {"ssh_target", "port"}
        and isinstance(value.get("ssh_target"), str)
        and re.fullmatch(r"[A-Za-z0-9_][A-Za-z0-9_.@:-]*", value["ssh_target"])
        and type(value.get("port", 22)) is int and 1 <= value.get("port", 22) <= 65535,
        "RAW_SSH_CONNECTION_INVALID")
    return ["ssh", "-T", "-o", "BatchMode=yes", "-o", "ConnectTimeout=15",
        "-o", "ServerAliveInterval=15", "-o", "ServerAliveCountMax=2",
        "-p", str(value.get("port", 22)), value["ssh_target"]]


def _f45_remote_command(run, host, code_root, payload):
    import shlex
    script = "import json,sys; from padml.run import _f45_remote_operation; value=_f45_remote_operation(json.loads(sys.argv[1])); print(json.dumps(value)) if value is not None else None"
    # The original adapter argv is visible before any import/qualification.
    # A probe carries `request`, never this original-only marker.
    if payload.get('operation') in {'archive_inventory', 'archive_confirm'} and not payload.get('status_only'):
        from .bundle import validate_sha256
        validate_sha256(payload['archive_request_id'], 'archive.request')
    if payload.get('operation') in {'archive_send','archive_oss','archive_environment'}:
        # Hold the existing directory lease before source qualification/import.
        # Inventory/status probes cannot mistake a live sender for quiescence.
        script = ('import os,fcntl; archive_fd=os.open(' + repr(str(Path(run['run_root'])/'shared/archives'))
            + ',os.O_RDONLY); fcntl.flock(archive_fd,fcntl.LOCK_SH); ' + script)
    command = "cd " + shlex.quote(str(code_root)) + " && exec " + shlex.join([
            "env", *[key + "=" + value for key, value in {
                "PADML_PYTHON": run["environment"]["python"], "PYTHON": run["environment"]["python"],
                "RETICULATE_PYTHON": run["environment"]["python"],
                "PADML_RSCRIPT": run["environment"]["rscript"], "PADML_R_LIBRARY": run["environment"]["r_library"],
                "R_LIBS_USER": run["environment"]["r_library"], "R_LIBS_SITE": run["environment"]["r_library"],
                "PADML_F45_RUN_PATH": payload["run"], "PADML_INTEGRATED_RUN": run["identity"]}.items()],
            run["environment"]["python"], "-c", script, json.dumps(payload, separators=(",", ":"))])
    # The wrapper supplies loader paths, one-thread engines and data-disk caches.
    # Its own cwd change must precede our selection of the frozen source tree.
    return [*_f45_connection(run["host_connections"][host]),
        "exec " + shlex.join(["/opt/padml/bin/padml-env", "sh", "-c", command])]


def _f45_host_observation(run):
    """Observe the existing owner, stage receipts and small headers; never replay a model."""
    import fcntl
    import subprocess
    import zipfile
    from .f4 import _f45_optimism_json
    generations = {row["identity"]: row["source_identity"] for row in (run, *f45_unit_predecessors(run))}
    base = Path(run["run_root"])
    base.mkdir(mode=0o700, parents=True, exist_ok=True)
    value = {"state": "IDLE", "active_unit": None, "completed_units": [], "not_estimable_units": [], "local_contexts": [],
        "postprocess_ready_units": [], "evaluation_ready_units": [], "selection_completed_units": []}
    if run.get('evaluation_decision') is not None:
        value.update(evaluation_amendment_units=[],selection_amendment_units=[])
    units = {u["unit_id"]: u for u in run["units"]}
    # Imported selector/draw members are references, not context ownership.
    # Both private preparation markers stay on their original producer.
    value["local_contexts"] = [c for c in sorted({u["context"] for u in units.values()} - {"EVALUATION"})
        if ((base / "contexts" / c / ("common/full-development.json" if c == "FULL0"
                else "primary-context.json")).is_file()
            if run.get("kind") == "PADML_INTEGRATED_RAW_RUN_V1"
            else (base / "contexts" / c).is_dir())]
    with (base / "active.lock").open("a+") as handle:
        for snapshot in range(2):
            value.pop("owner_record", None)
            try:
                fcntl.flock(handle, fcntl.LOCK_SH | fcntl.LOCK_NB)
                busy = False
            except BlockingIOError:
                busy = True
            handle.seek(0)
            try:
                # While the exclusive writer is active, child registrations
                # may be mid-append. Only its complete live header is needed;
                # IDLE requires the entire log under a stable shared lock.
                lines = [handle.readline()] if busy else handle
                rows = [json.loads(line) for line in lines if line.strip()]
            except ValueError:
                # A writer may be between truncate and its flushed owner header.
                _require(busy, "F45_OWNER_IDENTITY_UNKNOWN")
                rows = []
            if not rows:
                if busy and snapshot == 0:
                    continue
                if busy:
                    value.update(state="UNKNOWN", reason="OWNER_LOCKED_WITHOUT_IDENTITY")
                break
            owner = rows[0]
            _require(all(isinstance(row, dict) for row in rows)
                and owner.get("run_identity") in generations and owner.get("unit_id") in units
                and type(owner.get("pid")) is int and owner["pid"] > 0
                and all(type(row.get("pgid")) is int and row["pgid"] > 0 for row in rows),
                "F45_OWNER_IDENTITY_UNKNOWN")
            value["owner_record"] = {**owner, "exit_status": rows[-1].get("exit_status")}
            processes = subprocess.run(["ps", "-eo", "pid=,pgid="], capture_output=True, text=True, check=True)
            live = {tuple(map(int, line.split())) for line in processes.stdout.splitlines()}
            groups_live = any(group in {p[1] for p in live} for group in {row["pgid"] for row in rows})
            if busy and (owner["pid"], owner["pgid"]) not in live:
                if snapshot == 0:
                    # The writer may have returned after the lock probe, or the
                    # next writer may still be checking the previous owner.
                    continue
                value.update(state="UNKNOWN", reason="OWNER_LOCKED_WITHOUT_LIVE_IDENTITY")
                break
            if busy:
                value.update(state="RUNNING", active_unit=owner["unit_id"],
                    active_mode=owner.get("mode", "execute"), active_source_unit=owner.get("source_unit"))
            elif (rows[-1].get("exit_status") == "RETURNED" and (owner["pid"], owner["pgid"]) in live
                and not any(group != owner["pgid"] and group in {p[1] for p in live} for group in {r["pgid"] for r in rows})):
                # The worker has released its lock but is still printing/closing its own process.
                value.update(state="RUNNING", active_unit=owner["unit_id"],
                    active_mode=owner.get("mode", "execute"), active_source_unit=owner.get("source_unit"))
            elif groups_live or rows[-1].get("exit_status") != "RETURNED":
                value.update(state="UNKNOWN", active_unit=owner["unit_id"],
                    active_mode=owner.get("mode", "execute"), active_source_unit=owner.get("source_unit"),
                    reason="OWNER_EXIT_OR_REGISTERED_GROUP_REQUIRES_RESOLUTION")
            break
    if value.get("active_unit") is not None and value.get("active_mode", "execute") != "selection":
        context = units[value["active_unit"]]["context"]
        if context != "EVALUATION" and context not in value["local_contexts"]:
            value["local_contexts"].append(context)
            value["local_contexts"].sort()
    def header(path, name):
        with zipfile.ZipFile(path) as archive:
            _require(archive.getinfo(name).file_size <= 8 * 1024**2, "F45_OBSERVATION_HEADER_TOO_LARGE")
            return _f45_optimism_json(archive.read(name))
    for uid, unit in units.items():
        root = base / "units" / uid
        receipt_path = root / "unit.json"
        if receipt_path.is_file():
            raw = receipt_path.read_bytes()
            receipt = strict_json_bytes(raw)
            _require(receipt.get("status") in {"COMPLETED", "NOT_ESTIMABLE"} and receipt.get("direct_consumer_completed") is True
                and receipt.get("run_identity") in generations and receipt.get("unit_id") == uid
                and receipt.get("selection_horizon_months") == unit["horizon"], "F45_OBSERVED_RECEIPT_DRIFT")
            owned = (unit["context"] in value["local_contexts"] if unit["kind"] != "EVALUATION"
                else (root / "result.zip").is_file())
            if owned:
                _require(all((root / n).is_file() and not (root / n).is_symlink()
                    and (root / n).stat().st_size == pin["size_bytes"] for n, pin in receipt["artifacts"].items()),
                    "F45_OBSERVED_ARTIFACT_MISSING_OR_CHANGED")
                negative = receipt["status"] == "NOT_ESTIMABLE"
                if negative:
                    from .integrated import consume_unit_estimability
                    consume_unit_estimability(run, unit, root, receipt)
                    value["not_estimable_units"].append(uid)
                else:
                    value["completed_units"].append(uid)
                if negative and unit["kind"] in {"PRIMARY", "AAR"}:
                    # The typed result is the source; no absent prediction matrix is required.
                    value["evaluation_ready_units"].append(uid)
                elif unit["kind"] in {"PRIMARY", "AAR"} and (root / "evaluation-input.zip").is_file():
                    saved = header(root / "evaluation-input.zip", "evaluation-input.json")
                    _require(saved["source_receipt"] == receipt and saved["source_receipt_sha256"] == sha256_bytes(raw)
                        and saved["producer_source_identity"] in generations.values(), "F45_OBSERVED_COMPACT_DRIFT")
                    value["evaluation_ready_units"].append(uid)
                if not negative and unit["kind"] in {"PRIMARY", "FULL0"} and (root / "postprocess/result.json").is_file():
                    result = _f45_optimism_json((root / "postprocess/result.json").read_bytes())
                    saved = header(root / "postprocess/input.zip", "input.json")
                    _require(result["status"] == "COMPLETED" and result["source_unit"] == uid
                        and result["source_receipt_sha256"] == sha256_bytes(raw)
                        and result["input_identity_sha256"] == saved["identity_sha256"]
                        and result["csv_sha256"] == sha256_file(root / "postprocess/o-fit.csv"),
                        "F45_OBSERVED_POSTPROCESS_DRIFT")
                    diagnostic_path = root / "postprocess/diagnostics/result.json"
                    if diagnostic_path.is_file():
                        diagnostic = _f45_optimism_json(diagnostic_path.read_bytes())
                        _require(diagnostic["status"] == "COMPLETED" and diagnostic["source_unit"] == uid
                            and diagnostic["source_receipt_sha256"] == sha256_bytes(raw)
                            and diagnostic["development_lock"] == saved["development_lock"],
                            "F45_OBSERVED_DIAGNOSTIC_DRIFT")
                        value["postprocess_ready_units"].append(uid)
        if unit["kind"] == "EVALUATION":
            for source in (u for u in units.values() if u["kind"] in {"PRIMARY", "FULL0"} and u["horizon"] == unit["horizon"]):
                result_path = root / "selection" / source["unit_id"] / "result.json"
                if result_path.is_file():
                    result = _f45_optimism_json(result_path.read_bytes())
                    saved = header(base / "units" / source["unit_id"] / "postprocess/input.zip", "input.json")
                    _require(result["status"] == "COMPLETED" and result["source_unit"] == source["unit_id"]
                        and result["replicate_count"] == len(result["replicate_identities"]) == 1000
                        and result["input_identity_sha256"] == saved["identity_sha256"]
                        and result["csv_sha256"] == sha256_file(result_path.with_name("selection.csv")),
                        "F45_OBSERVED_SELECTION_DRIFT")
                    value["selection_completed_units"].append(source["unit_id"])
    if run.get('evaluation_decision') is not None:
        from .f4 import evaluation_appendix_observation
        from .curve_rmse import eligible as curve_eligible, read_result as read_curve
        value['curve_pending_units'] = []
        value['curve_result_identities'] = {}
        value['result_closure_pending_units'] = []
        value['result_closure_identities'] = {}
        value['evaluation_extension_pending_units'] = []
        value['evaluation_extension_identities'] = {}
        value['clinical_extension_pending_units'] = []
        value['clinical_extension_identities'] = {}
        from .evaluation_extension import GATE,validate_gate,clinical_eligible,read_clinical
        gate=validate_gate(run,strict_json_bytes((base/GATE).read_bytes())) if run.get('evaluation_extension') and (base/GATE).is_file() else None
        if gate:value['clinical_gate_identity']=gate['identity_sha256']
        for uid in value['completed_units']:
            unit = units[uid]
            if unit['kind'] in {'PRIMARY','FULL0','EVALUATION'} and evaluation_appendix_observation(run,unit,include_curve=False):
                if curve_eligible(run,unit):
                    curve = read_curve(run,unit,observation=True)
                    if curve is None:
                        value['curve_pending_units'].append(uid)
                        continue
                    value['curve_result_identities'][uid] = curve['identity_sha256']
                from .result_closure import eligible as closure_eligible,read_result as read_closure
                if closure_eligible(run,unit):
                    closure = read_closure(run,unit,observation=True)
                    if closure is None:
                        value['result_closure_pending_units'].append(uid)
                        continue
                    value['result_closure_identities'][uid] = closure['identity_sha256']
                value['evaluation_amendment_units'].append(uid)
                from .evaluation_extension import eligible as extension_eligible, read_result as read_extension
                if extension_eligible(run,unit):
                    extension = read_extension(run,unit,observation=True)
                    if extension is None:
                        value['evaluation_extension_pending_units'].append(uid)
                    else:
                        value['evaluation_extension_identities'][uid] = extension['identity_sha256']
                if gate and clinical_eligible(run,unit):
                    clinical=read_clinical(run,unit,observation=True)
                    if clinical is None:value['clinical_extension_pending_units'].append(uid)
                    else:value['clinical_extension_identities'][uid]=clinical['identity_sha256']
        for uid in value['selection_completed_units']:
            unit = units[f"EVALUATION-H{units[uid]['horizon']:02d}"]
            if evaluation_appendix_observation(run,unit,units[uid]):
                value['selection_amendment_units'].append(uid)
    if run.get('post_result_repair') is not None:
        from .f5_application import application_regression_observation
        value['original_application_regression_complete'] = application_regression_observation(run)
    preparation = base / "shared/bootstrap-preparation.json"
    if preparation.is_file():
        record = strict_json_bytes(preparation.read_bytes())
        _require(record["f45_source_sha256"] in generations.values()
            and (base / "shared/bootstrap.zip").stat().st_size == record["rng_archive"]["size_bytes"],
            "F45_SHARED_RNG_DRIFT")
        value["shared_draws"] = record["rng_archive"]
    return value


def _f45_selection_dependencies(run, source_unit):
    """Numerical reference closure declared by this source's sealed input."""
    from .carriers import open_carrier
    from .f4 import _f45_optimism_json
    from .bundle import validate_relative_path
    from .integrated import same_batch_generations
    _require(source_unit in {u["unit_id"] for u in run["units"] if u["kind"] in {"PRIMARY", "FULL0"}},
        "F45_SELECTION_SOURCE_INVALID")
    path = Path(run["run_root"]) / "units" / source_unit / "postprocess/input.zip"
    with open_carrier(path) as archive:
        _require(archive.getinfo("input.json").file_size <= 32*1024**2, "F45_SELECTION_INPUT_TOO_LARGE")
        manifest = _f45_optimism_json(archive.read("input.json"))
        _require(manifest["source_unit"] == source_unit, "F45_SELECTION_SOURCE_DRIFT")
        refs = list(archive.references.values())
    refs += [p["pooled_survival_ref"] for parts in manifest.get("oof_partitions", {}).values() for p in parts]
    pins = {}
    for ref in refs:
        name = validate_relative_path(ref["path"], "dependency.path")
        _require(name.startswith(("shared/oof/", "shared/optimism-values/",
                "contexts/" + next(u["context"] for u in run["units"] if u["unit_id"] == source_unit) + "/selection-draws/"))
            and ref["producer"] in same_batch_generations(run).values(), "F45_SELECTION_REFERENCE_SCOPE_INVALID")
        pin = {k:ref[k] for k in ("sha256", "size_bytes")}
        _require(pins.setdefault(name, pin) == pin, "F45_SELECTION_REFERENCE_ALIAS")
    return pins


def _f45_estimability_dependencies(run, source_unit, *, complete=False):
    """Admit only a typed negative carrier and its declared selector/upstream pins.

    The source inventory performs the scientific consumer once. Receiving a
    pinned index admits its children without requiring those children to exist.
    Ordinary model result archives never enter this transport domain.
    """
    from . import nested_loco as n
    from .carriers import open_carrier
    from .integrated import consume_unit_estimability, qualified_file_pins, same_batch_generations
    from .bundle import validate_relative_path
    by_id = {u["unit_id"]: u for u in run["units"]}
    _require(source_unit in by_id and by_id[source_unit]["kind"] in {"PRIMARY", "AAR"},
             "F45_ESTIMABILITY_SOURCE_INVALID")
    unit, base = by_id[source_unit], Path(run["run_root"])
    root = base / "units" / source_unit
    receipt = strict_json_bytes((root / "unit.json").read_bytes())
    generations = same_batch_generations(run)
    _require(receipt.get("status") == "NOT_ESTIMABLE" and receipt.get("direct_consumer_completed") is True
        and receipt.get("unit_id") == source_unit and receipt.get("run_identity") in generations
        and receipt.get("selection_horizon_months") == unit["horizon"]
        and set(receipt.get("artifacts", {})) == {"result.zip"}
        and receipt.get("estimability", {}).get("status") == "NOT_ESTIMABLE",
        "F45_ESTIMABILITY_RECEIPT_INVALID")
    if complete:
        consume_unit_estimability(run, unit, root, receipt)
    pins = {}
    def add(name, pin):
        name = validate_relative_path(name, "estimability.path")
        _require(set(pin) == {"sha256", "size_bytes"} and type(pin["size_bytes"]) is int
            and pin["size_bytes"] > 0, "F45_ESTIMABILITY_REFERENCE_INVALID")
        validate_sha256(pin["sha256"], "estimability.sha256")
        _require(pins.setdefault(name, pin) == pin, "F45_ESTIMABILITY_REFERENCE_ALIAS")
        return name
    def walk(uid, name, pin, depth):
        name = add(name, pin)
        path = base / name
        if not path.exists():
            _require(not complete, "F45_ESTIMABILITY_INDEX_MISSING")
            return  # Receive this independently pinned index before its child members.
        _require(not path.is_symlink() and path.is_file()
            and path.resolve(strict=True).is_relative_to(base.resolve(strict=True)),
            "F45_ESTIMABILITY_REFERENCE_INVALID")
        qualified_file_pins({name:path}, identity=run["source_identity"], expected={name:pin},
            record=base / "shared/file-qualifications" / (sha256_bytes(name.encode()) + ".transfer.json"))
        current = by_id[uid]
        with open_carrier(path) as archive:
            _require("estimability.json" not in archive.references
                and archive.getinfo("estimability.json").file_size <= 32*1024**2,
                "F45_ESTIMABILITY_INDEX_INVALID")
            value = strict_json_bytes(archive.read("estimability.json"))
            _require(value.get("kind") == "PADML_UNIT_NOT_ESTIMABLE_V1"
                and value.get("status") == "NOT_ESTIMABLE" and value.get("unit_id") == uid
                and value.get("raw_input") == run["raw_input"]
                and value.get("selection_horizon_months") == current["horizon"]
                and generations.get(value.get("run_identity")) == value.get("source_identity")
                and value == n._sealed({k:v for k,v in value.items() if k != "identity_sha256"}),
                "F45_ESTIMABILITY_INDEX_INVALID")
            if depth == 0:
                _require(receipt["estimability"] == {"status":"NOT_ESTIMABLE",
                    "reason_code":value["reason_code"], "evidence_identity":value["identity_sha256"],
                    "upstream_units":value["upstream_units"]}, "F45_ESTIMABILITY_INDEX_INVALID")
            refs = archive.references
            _require(set(archive.namelist()) == {"estimability.json", *refs},
                "F45_ESTIMABILITY_INDEX_INVALID")
            if value.get("reason_code") == "FREQUENCY_LADDER_EXHAUSTED":
                _require(current["kind"] == "PRIMARY" and value.get("upstream_units") == []
                    and refs and all(member.startswith("selector/") for member in refs),
                    "F45_ESTIMABILITY_REFERENCE_SCOPE_INVALID")
                prefix = "contexts/" + current["context"] + ("/selector-h36/" if current["horizon"] == 36 else "/selector/")
                expected = {member:prefix + member.removeprefix("selector/") for member in refs}
                upstream = []
            else:
                upstream = value.get("upstream_units")
                _require(depth == 0 and current["kind"] == "AAR"
                    and value.get("reason_code") == "UPSTREAM_PRIMARY_NOT_ESTIMABLE"
                    and isinstance(upstream, list) and upstream and upstream == sorted(set(upstream))
                    and set(upstream) <= set(current["depends_on"])
                    and all(by_id[u]["kind"] == "PRIMARY" and by_id[u]["horizon"] == current["horizon"] for u in upstream),
                    "F45_ESTIMABILITY_REFERENCE_SCOPE_INVALID")
                expected = {f"upstream/{u}/{member}":f"units/{u}/{member}"
                    for u in upstream for member in ("unit.json", "result.zip")}
                _require(set(refs) == set(expected), "F45_ESTIMABILITY_REFERENCE_SCOPE_INVALID")
            for member, ref in refs.items():
                _require(ref.get("role") == member and ref.get("path") == expected[member]
                    and ref.get("producer") in generations.values(), "F45_ESTIMABILITY_REFERENCE_SCOPE_INVALID")
                add(ref["path"], {k:ref[k] for k in ("sha256", "size_bytes")})
            for u in upstream:
                ref = refs[f"upstream/{u}/result.zip"]
                walk(u, ref["path"], {k:ref[k] for k in ("sha256", "size_bytes")}, depth+1)
    walk(source_unit, f"units/{source_unit}/result.zip", receipt["artifacts"]["result.zip"], 0)
    return dict(sorted(pins.items()))


class _F45TransferOutcomeUnknown(ConnectionError):
    """A launched SSH transport has no confirmed remote completion receipt."""


def _f45_receive_file(target, pin, source, *, idle_seconds=60, total_seconds=540):
    """Receive a pinned member without waiting indefinitely for a pipe's EOF."""
    import hashlib
    import select
    import tempfile
    import time
    deadline = time.monotonic() + total_seconds
    hasher, count = hashlib.sha256(), 0
    try:
        with tempfile.NamedTemporaryFile(dir=target.parent, prefix=".transfer-", delete=False) as stream:
            temporary = Path(stream.name)
            try:
                while True:
                    remaining = deadline - time.monotonic()
                    if remaining <= 0:
                        raise TimeoutError("F45_TRANSFER_TOTAL_TIMEOUT")
                    if not select.select([source.fileno()], [], [], min(idle_seconds, remaining))[0]:
                        raise TimeoutError("F45_TRANSFER_INPUT_TIMEOUT")
                    block = os.read(source.fileno(), 1024**2)
                    if not block:
                        break
                    count += len(block)
                    _require(count <= pin["size_bytes"], "F45_TRANSFER_TOO_LARGE")
                    hasher.update(block); stream.write(block)
                stream.flush(); os.fsync(stream.fileno())
                _require(count == pin["size_bytes"] and hasher.hexdigest() == pin["sha256"],
                    "F45_TRANSFER_BYTES_DRIFT")
                if target.exists():
                    _require(target.stat().st_size == count and sha256_file(target) == pin["sha256"],
                        "F45_TRANSFER_DESTINATION_DRIFT")
                else:
                    os.link(temporary, target)
            finally:
                temporary.unlink(missing_ok=True)
    except TimeoutError as error:
        # This receipt is emitted only after the unpublished temporary is gone.
        # Lost SSH receipts remain UNKNOWN at the coordinator, not safe retries.
        return {"status": "TRANSFER_RETRY_REQUIRED", "reason": str(error), "pin": pin}
    return pin


def _f45_remote_operation(payload):
    """Small SSH adapter for next/worker; no separate scheduler or persisted queue."""
    import fcntl
    import hashlib
    import shutil
    import subprocess
    import sys
    import tempfile
    import time
    run_path = Path(payload["run"])
    run = load_f45_run(run_path)
    _require(run["kind"] == "PADML_INTEGRATED_RAW_RUN_V1" and run["identity"] == payload["identity"],
             "RAW_REMOTE_RUN_DRIFT")
    operation = payload["operation"]
    base = Path(run["run_root"])
    if operation == 'evaluation_extension_gate':
        from .evaluation_extension import publish_gate
        return publish_gate(run,payload['gate'])
    if operation == "dependency_inventory":
        source_type = payload.get("source_type", "selection")
        _require(source_type in {"selection", "estimability"}, "F45_DEPENDENCY_SOURCE_TYPE_INVALID")
        if source_type == "estimability":
            return _f45_estimability_dependencies(run, payload["source_unit"], complete=True)
        return _f45_selection_dependencies(run, payload["source_unit"])
    if operation == "archive_inventory":
        from .reports import archive_inventory
        _require(type(payload.get('staging', False)) is bool and type(payload.get('status_only', False)) is bool,
            'ARCHIVE_SCOPE_INVALID')
        if not payload.get('status_only', False):
            observed = _f45_host_observation(run)
            _require(set(payload["units"]) <= set(observed["completed_units"]) | set(observed.get("not_estimable_units", []))
                and set(payload["selections"]) <= set(observed["selection_completed_units"]), "ARCHIVE_OWNER_DRIFT")
        return archive_inventory(run, payload["horizon"], payload["units"], payload["selections"],
            staging=payload.get('staging', False), status_only=payload.get('status_only', False),
            sender_request=payload.get('sender_request'), request=payload.get('request'))
    if operation == "archive_send":
        from .reports import archive_send, archive_members_from_stream
        members = archive_members_from_stream(payload["members_pin"], sys.stdin.buffer)
        archive_send(run, payload["horizon"], payload["inventory_identity"], members,
            payload["offset"], sys.stdout.buffer)
        return None
    if operation == 'archive_oss':
        from .reports import archive_oss_operation,archive_members_from_stream
        envelope=archive_members_from_stream(payload['envelope_pin'],sys.stdin.buffer,envelope=True)
        return archive_oss_operation(run,payload,envelope)
    if operation == 'archive_environment':
        from .reports import archive_members_from_stream
        from .runtime_bundle import environment_archive_operation
        envelope=archive_members_from_stream(payload['envelope_pin'],sys.stdin.buffer,envelope=True)
        _require(envelope.get('members')==[] and envelope.get('pins')=={},'ENVIRONMENT_ENVELOPE_INVALID')
        return environment_archive_operation(run,payload,envelope['tokens'])
    if operation == "archive_confirm":
        from . import nested_loco as n
        from .integrated import same_batch_generations
        receipt = payload["receipt"]
        horizon = receipt["horizon"]
        units = [u for u in run["units"] if u["horizon"] == horizon]
        negative = receipt.get("not_estimable_units", [])
        _require(isinstance(negative, list) and all(isinstance(uid, str) for uid in negative)
            and negative == sorted(set(negative)) and set(negative) <= {u["unit_id"] for u in units},
            "ARCHIVE_ACKNOWLEDGEMENT_INVALID")
        _require(receipt["run_identity"] in same_batch_generations(run) and receipt["status"] == "ARCHIVED"
            and receipt["kind"] == "PADML_WINDOW_ARCHIVE_RECEIPT_V1"
            and n._sealed({k:v for k,v in receipt.items() if k != "identity_sha256"}) == receipt
            and set(receipt["units"]) == {u["unit_id"] for u in units}
            and set(receipt["selections"]) == {u["unit_id"] for u in units if u["kind"] in {"PRIMARY", "FULL0"}} - set(negative),
            "ARCHIVE_ACKNOWLEDGEMENT_INVALID")
        folder = base / "shared/archives"
        from .reports import _read_archive_inventory
        own = _read_archive_inventory(base, horizon, set(receipt['inventories'].values()))
        _require(own["identity_sha256"] in receipt["inventories"].values()
            and not own.get('materials_only', False)
            and n._sealed({k:v for k,v in own.items() if k != "identity_sha256"}) == own
            and set(own.get("not_estimable_units", [])) == set(negative).intersection(own["units"]),
            "ARCHIVE_ACKNOWLEDGEMENT_DRIFT")
        from .reports import _archive_version, _archive_receipt_path, _publish
        _require(all(receipt.get(k) == _archive_version(run).get(k) for k in ('closure_version','evaluation_decision_sha256','post_result_repair_sha256','curve_rmse_sha256','result_closure_sha256','evaluation_extension_sha256','archive_generation')),
            'ARCHIVE_ACKNOWLEDGEMENT_VERSION_DRIFT')
        confirmation = _archive_receipt_path(folder, horizon, receipt, confirmation=True)
        if receipt.get('previous_window_identity') is not None:
            parent = payload.get('previous_receipt')
            if parent is None:
                from .reports import _archive_parent_receipt
                parent = _archive_parent_receipt(folder, horizon, receipt['previous_window_identity'], confirmation=True)
            _require(n._sealed({k:v for k,v in parent.items() if k != 'identity_sha256'}) == parent
                and parent['identity_sha256'] == receipt['previous_window_identity']
                and parent['run_identity'] in same_batch_generations(run)
                and all(parent.get(k) == receipt.get(k) for k in
                    ('kind','horizon','units','selections','not_estimable_units','status')),
                'ARCHIVE_ACKNOWLEDGEMENT_PREDECESSOR_DRIFT')
            prior = _read_archive_inventory(base, horizon, set(parent['inventories'].values()))
            _require(all(own['members'].get(name) == pin for name,pin in prior['members'].items()),
                'ARCHIVE_ACKNOWLEDGEMENT_PREDECESSOR_DRIFT')
            # A lost previous ACK never invalidates the already durable parent
            # window. The dispatcher supplies its exact original leaf bytes.
            parent_path = _archive_receipt_path(folder, horizon, parent, confirmation=True)
            _publish(parent_path, canonical_json_bytes(parent), 'ARCHIVE_ACKNOWLEDGEMENT_PREDECESSOR_DRIFT')
        if confirmation.is_file():
            previous = strict_json_bytes(confirmation.read_bytes())
            _require(n._sealed({k:v for k,v in previous.items() if k != 'identity_sha256'}) == previous
                and previous['run_identity'] in same_batch_generations(run)
                and {k:v for k,v in previous.items() if k not in {'run_identity','identity_sha256'}} ==
                    {k:v for k,v in receipt.items() if k not in {'run_identity','identity_sha256'}},
                'ARCHIVE_ACKNOWLEDGEMENT_DRIFT')
            receipt = previous
        _publish(confirmation, canonical_json_bytes(receipt), 'ARCHIVE_ACKNOWLEDGEMENT_DRIFT')
        if run.get('archive_transfer') is not None:
            return {'horizon':horizon,'status':'CONFIRMED','retirement':'RETAINED_PENDING_OFFLINE_AND_ENVIRONMENT_ACCEPTANCE'}
        observed = _f45_host_observation(run)
        if observed["state"] == "IDLE":
            with (base / "active.lock").open("a+") as owner:
                try:
                    fcntl.flock(owner, fcntl.LOCK_EX | fcntl.LOCK_NB)
                except BlockingIOError:
                    return {"horizon": horizon, "status": "CONFIRMED", "retirement": "NEXT_OWNER_EXIT"}
                from .integrated import retire_completed_outputs
                contexts = {}
                for unit in run["units"]:
                    if (unit["kind"] != "EVALUATION" and unit["context"] in observed["local_contexts"]
                        and (base / "units" / unit["unit_id"] / "unit.json").is_file()):
                        contexts.setdefault(unit["context"], unit)
                for unit in contexts.values():
                    retire_completed_outputs(run, unit, base / "units" / unit["unit_id"])
        return {"horizon": horizon, "status": "CONFIRMED"}
    if operation in {"pin", "send", "receive"}:
        # Only direct numerical inputs may move between contexts.
        relative = payload["member"]
        legal = {"shared/bootstrap.zip", "shared/bootstrap-preparation.json"}
        for unit in run["units"]:
            uid = unit["unit_id"]
            if unit["kind"] in {"PRIMARY", "AAR"}:
                legal.update((f"units/{uid}/unit.json", f"units/{uid}/evaluation-input.zip"))
            if unit["kind"] in {"PRIMARY", "FULL0"}:
                legal.add(f"units/{uid}/postprocess/input.zip")
                if run.get('evaluation_decision') is not None:
                    legal.add(f"units/{uid}/postprocess/evaluation-amendment/training-km.json")
                if run.get('post_result_repair') is not None and unit['kind'] == 'PRIMARY':
                    legal.add(f"units/{uid}/post-result-repair-20261008/a04/evaluation.json")
        dependency = None
        if payload.get('report_of') is not None:
            from .reports import repair_report_dependencies
            _require(operation in {'pin','send'} and payload.get('dependency_of') is None
                and payload.get('estimability_of') is None,'REPORT_REPAIR_TRANSFER_INVALID')
            selected = [u for u in run['units'] if u['unit_id'] == payload['report_of']
                and u['kind'] in {'PRIMARY','FULL0','EVALUATION'}]
            _require(len(selected) == 1,'REPORT_REPAIR_SCOPE_INVALID')
            from .curve_rmse import eligible,relative_result,read_result
            from .result_closure import eligible as closure_eligible,relative_result as closure_name,read_result as read_closure
            from .evaluation_extension import eligible as extension_eligible,relative_result as extension_name,read_result as read_extension
            from .evaluation_extension import clinical_eligible,clinical_name,read_clinical
            if clinical_eligible(run,selected[0]) and relative==clinical_name(selected[0]):
                _require(read_clinical(run,selected[0],observation=True) is not None,'EVALUATION_EXTENSION_CLINICAL_REQUIRED')
                dependencies={relative:None}
            elif extension_eligible(run,selected[0]) and (relative.startswith(
                    extension_name(selected[0]).rsplit('/',1)[0]+'/') or (
                    selected[0]['unit_id'] == 'FULL0-H06' and relative ==
                    'units/FULL0-H36/post-result-repair-20261008/mi-diagnostic.json')):
                result = read_extension(run,selected[0],observation=True)
                _require(result is not None,'EVALUATION_EXTENSION_RESULT_REQUIRED')
                dependencies = {extension_name(selected[0]):None, **result['sources']}
            elif closure_eligible(run,selected[0]) and relative == closure_name(selected[0]):
                _require(read_closure(run,selected[0],observation=True) is not None,'RESULT_CLOSURE_RESULT_REQUIRED')
                dependencies = {relative:None}
            elif eligible(run,selected[0]) and relative == relative_result(selected[0]):
                _require(read_result(run,selected[0],observation=True) is not None,'CURVE_RMSE_RESULT_REQUIRED')
                dependencies = {relative:None}
            else:
                dependencies = repair_report_dependencies(run,selected[0])
            _require(relative in dependencies,'REPORT_REPAIR_MEMBER_NOT_DECLARED')
            legal.update(dependencies)
            dependency = dependencies[relative]
        _require(payload.get("dependency_of") is None or payload.get("estimability_of") is None,
            "F45_DEPENDENCY_SOURCE_TYPE_INVALID")
        if payload.get("estimability_of") is not None:
            dependencies = _f45_estimability_dependencies(run, payload["estimability_of"])
            _require(relative in dependencies, "F45_TRANSFER_MEMBER_NOT_REQUIRED")
            legal.update(dependencies)
            dependency = dependencies[relative]
        if payload.get("dependency_of") is not None:
            dependencies = _f45_selection_dependencies(run, payload["dependency_of"])
            legal.update(dependencies)
            dependency = dependencies.get(relative)
        _require(relative in legal, "F45_TRANSFER_MEMBER_NOT_REQUIRED")
        target = base / relative
        _require(not base.is_symlink() and target.resolve().is_relative_to(base.resolve())
            and all(not ancestor.is_symlink() for ancestor in (target, *target.parents) if ancestor == base or base in ancestor.parents),
            "F45_TRANSFER_PATH_INVALID")
        if operation == "pin":
            if not target.exists():
                return {"status": "ABSENT"}
            _require(target.is_file(), "F45_TRANSFER_PATH_INVALID")
            from .integrated import qualified_file_pins
            return qualified_file_pins({relative:target}, identity=run["source_identity"],
                expected={relative:dependency} if dependency else None,
                record=base / "shared/file-qualifications" / (sha256_bytes(relative.encode()) + ".transfer.json"))[relative]
        pin = payload["pin"]
        _require(dependency is None or pin == dependency, "F45_TRANSFER_REFERENCE_DRIFT")
        validate_sha256(pin["sha256"], "transfer.sha256")
        _require(type(pin["size_bytes"]) is int and pin["size_bytes"] > 0, "F45_TRANSFER_PIN_INVALID")
        if operation == "send":
            _require(target.stat().st_size == pin["size_bytes"], "F45_TRANSFER_SOURCE_DRIFT")
            if payload.get('report_of') is not None:
                from .integrated import qualified_file_pins
                qualified_file_pins({relative:target},identity=run['source_identity'],
                    expected={relative:pin},record=base/'shared/file-qualifications'/
                    (sha256_bytes(relative.encode())+'.transfer.json'))
            if relative.endswith('/post-result-repair-20261008/a04/evaluation.json'):
                from .f5_a04_current import read_current_a04_evaluation
                unit, = [u for u in run['units'] if relative ==
                    f"units/{u['unit_id']}/post-result-repair-20261008/a04/evaluation.json"]
                head = target.parent/'result.json'
                _require(head.is_file() and not head.is_symlink(),'A04_CURRENT_SOURCE_RESULT_REQUIRED')
                read_current_a04_evaluation(target,run,unit,
                    source_result=strict_json_bytes(head.read_bytes()))
            with target.open("rb") as source:
                shutil.copyfileobj(source, sys.stdout.buffer, 1024**2)
            return None
        target.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
        _require(shutil.disk_usage(target.parent).free >= pin["size_bytes"], "F45_TRANSFER_SPACE_INSUFFICIENT")
        return _f45_receive_file(target, pin, sys.stdin.buffer)
    if operation == "observe":
        return _f45_host_observation(run)
    _require(operation == "start", "F45_REMOTE_OPERATION_INVALID")
    assignment = payload["assignment"]
    uid, mode, source = assignment["unit_id"], assignment.get("mode", "execute"), assignment.get("source_unit")
    _require(uid in {u["unit_id"] for u in run["units"]} and mode in {"execute", "postprocess", "selection", "appendage"},
             "F45_REMOTE_ASSIGNMENT_INVALID")
    command = [run["environment"]["python"], "-m", "padml.worker", "f45", str(run_path), uid, "--mode", mode]
    _require(re.fullmatch(r'[0-9a-f]{32}', assignment.get('attempt_id', '')) is not None,
             'F45_START_ATTEMPT_INVALID')
    observed = _f45_host_observation(run)
    if observed["state"] != "IDLE":
        # This reply precedes Popen: unlike a lost start receipt it proves that
        # this attempt created no child. A fresh native observation may retry.
        return {"status": "START_NOT_ADMITTED", **assignment,
            "reason": observed.get("reason", "F45_REMOTE_OWNER_NOT_IDLE")}
    command += ['--attempt-id', assignment['attempt_id']]
    if source is not None:
        command += ["--source-unit", source]
    # One append-only bounded-to-current-job log, not a copy of scientific output.
    with (base / "active.log").open("wb") as log:
        child = subprocess.Popen(command, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT,
            start_new_session=True, close_fds=True)
    for _ in range(100):
        try:
            rows = [json.loads(line) for line in (base / "active.lock").read_text().splitlines() if line.strip()]
            row = rows[0]
        except (OSError, ValueError, IndexError):
            row, rows = {}, []
        exit_code = child.poll()
        matched = (row.get("pid") == child.pid and row.get("unit_id") == uid and row.get("mode") == mode
            and row.get("source_unit") == source and row.get("run_identity") == run["identity"]
            and row.get('attempt_id') == assignment['attempt_id'])
        _require(exit_code in {None, 0} and not (matched and rows[-1].get("exit_status") == "FAILED"),
            "F45_REMOTE_WORKER_START_FAILED")
        if matched:
            if exit_code == 0:
                _require(rows[-1].get("exit_status") == "RETURNED"
                    and _f45_host_observation(run)["state"] == "IDLE", "F45_REMOTE_WORKER_EXIT_UNKNOWN")
            return {"status": "OWNER_RETURNED" if exit_code == 0 else "OWNER_REGISTERED", "pid": child.pid, **assignment}
        _require(exit_code is None, "F45_REMOTE_WORKER_START_FAILED")
        time.sleep(.1)
    raise ContractError("F45_REMOTE_WORKER_START_STATE_UNKNOWN")


def _f45_launch_assignments(assignments, units, source_hosts, draw_hosts, *, pool, call, transfer,
                            inflight=None, not_estimable_units=(), post_result_repair=False, curve_only_units=()):
    """Flatten transfers into the existing IO pool and start each ready closure."""
    from collections import deque
    from concurrent.futures import wait, FIRST_COMPLETED
    state = {} if inflight is None else inflight
    queued = state.setdefault('queued', deque())
    futures = state.setdefault('futures', {})
    pending = state.setdefault('pending', {})
    owned = state.setdefault('assignments', {})
    failed = state.setdefault('failed', {})
    uncertain = state.setdefault('uncertain', {})
    results = {}
    active_transfers = state.get('active_transfers',0)
    not_estimable = set(not_estimable_units)
    admitted = []
    for assignment in assignments:
        import uuid
        assignment = {**assignment, 'attempt_id': uuid.uuid4().hex}
        _require(assignment['host'] not in {row['host'] for row in owned.values()}, 'F45_PENDING_HOST_ALREADY_OWNED')
        index = state.get('next_index',0)
        state['next_index'] = index+1
        owned[index], pending[index] = assignment, 0
        admitted.append(index)
    def submit(index, kind, function, *args, **kwargs):
        pending[index] += 1
        futures[pool.submit(function, *args, **kwargs)] = (index, kind)
    def enqueue(index, kind, source, destination, member, **kwargs):
        pending[index] += 1
        queued.append((index, kind, source, destination, member, kwargs))
    def start(index):
        assignment = owned[index]
        submit(index, 'start', call, assignment['host'], 'start', assignment=assignment)
    def negative_members(index, uid, source, members):
        for member in members:
            enqueue(index, 'member', source, owned[index]['host'], member, estimability_of=uid)
    for index in admitted:
        assignment = owned[index]
        host, unit = assignment['host'], units[assignment['unit_id']]
        if assignment.get('mode') == 'appendage':
            if unit['kind'] == 'EVALUATION' and assignment.get('source_unit') is None and assignment['unit_id'] not in curve_only_units:
                for uid in unit['depends_on']:
                    if units[uid]['kind'] == 'PRIMARY':
                        enqueue(index,'member',source_hosts[uid],host,
                            f'units/{uid}/postprocess/evaluation-amendment/training-km.json')
                        if post_result_repair:
                            enqueue(index,'member',source_hosts[uid],host,
                                f'units/{uid}/post-result-repair-20261008/a04/evaluation.json')
            if not pending[index]: start(index)
        elif assignment.get('mode') == 'selection':
            enqueue(index, 'index', assignment['source_host'], host,
                'units/' + assignment['source_unit'] + '/postprocess/input.zip')
        elif unit['kind'] == 'EVALUATION':
            direct_negative_primaries = frozenset(uid for uid in unit['depends_on']
                if uid in not_estimable and units.get(uid, {}).get('kind') == 'PRIMARY')
            for uid in unit['depends_on']:
                if uid in direct_negative_primaries or not direct_negative_primaries and uid in not_estimable:
                    enqueue(index, ('negative_receipt', uid, source_hosts[uid], direct_negative_primaries), source_hosts[uid], host,
                        f'units/{uid}/unit.json')
                else:
                    names = ('unit.json',) if direct_negative_primaries else ('unit.json', 'evaluation-input.zip')
                    for name in names:
                        enqueue(index, 'member', source_hosts[uid], host, f'units/{uid}/{name}')
            if draw_hosts and not direct_negative_primaries:
                for name in ('bootstrap.zip', 'bootstrap-preparation.json'):
                    enqueue(index, 'member', draw_hosts[0], host, 'shared/' + name)
            if not pending[index]:
                start(index)
        else:
            start(index)
    while futures or queued:
        while queued and active_transfers < 3:
            index, kind, source, destination, member, kwargs = queued.popleft()
            futures[pool.submit(transfer, source, destination, member, **kwargs)] = (index, kind)
            active_transfers += 1
        completed, _ = wait(futures, timeout=None if inflight is None else 0, return_when=FIRST_COMPLETED)
        if not completed:
            break
        for future in completed:
            index, kind = futures.pop(future)
            pending[index] -= 1
            assignment = owned[index]
            category = kind[0] if isinstance(kind, tuple) else kind
            if category in {'index', 'member', 'negative_receipt', 'negative_index', 'negative_dependencies'}:
                active_transfers -= 1
            try:
                value = future.result()
            except Exception as error:
                import subprocess
                transient = isinstance(error, (TimeoutError, ConnectionError, OSError, subprocess.TimeoutExpired))
                start_unknown = kind == 'start' and any(code in str(error) for code in (
                    'F45_REMOTE_WORKER_START_FAILED', 'F45_REMOTE_WORKER_START_STATE_UNKNOWN'))
                if not (transient or start_unknown):
                    raise
                reason = f'{type(error).__name__}: {error}'[-1800:]
                if kind == 'start' or isinstance(error, _F45TransferOutcomeUnknown):
                    uncertain[index] = ('' if kind == 'start' else 'TRANSFER_OUTCOME_UNKNOWN:') + reason
                    results[index] = {'status': ('START_OUTCOME_UNKNOWN' if kind == 'start'
                        else 'TRANSFER_OUTCOME_UNKNOWN'), **assignment, 'reason': reason}
                    if kind == 'start':
                        continue
                failed[index] = reason
                for item in list(queued):
                    if item[0] == index:
                        queued.remove(item)
                        pending[index] -= 1
            if index in failed:
                if not pending[index]:
                    status = 'TRANSFER_OUTCOME_UNKNOWN' if index in uncertain else 'TRANSFER_RETRY_REQUIRED'
                    results[index] = {'status': status, **assignment, 'reason': failed.pop(index)}
                    if index not in uncertain:
                        del owned[index], pending[index]
                continue
            if kind == 'start':
                results[index] = value
                del owned[index], pending[index]
                continue
            if category == 'negative_receipt':
                _, uid, source, covered = kind
                submit(index, ('negative_inventory', uid, source, covered), call, source,
                    'dependency_inventory', source_unit=uid, source_type='estimability')
            elif category == 'negative_inventory':
                _, uid, source, covered = kind
                _require(isinstance(value, Mapping) and f'units/{uid}/result.zip' in value,
                    'F45_ESTIMABILITY_REFERENCE_SCOPE_INVALID')
                enqueue(index, ('negative_index', uid, source, value, covered), source, assignment['host'],
                    f'units/{uid}/result.zip', estimability_of=uid)
            elif category == 'negative_index':
                _, uid, source, members, covered = kind
                top = f'units/{uid}/result.zip'
                indexes = [name for name in members if name != top and name.startswith('units/')
                    and name.endswith(('/unit.json', '/result.zip'))]
                leaves = [name for name in members if name != top and name not in indexes]
                upstream = {name.split('/')[1] for name in indexes}
                _require(not upstream.intersection(covered) or upstream <= covered,
                    'F45_ESTIMABILITY_SHARED_SOURCE_INCOMPLETE')
                if upstream and upstream <= covered:
                    # The same assignment already owns these PRIMARY flows. Its pending
                    # count keeps this AAR from starting before their unique closure arrives.
                    indexes, leaves = [], []
                if indexes:
                    barrier = {'remaining':len(indexes), 'members':leaves}
                    for member in indexes:
                        enqueue(index, ('negative_dependencies', uid, source, barrier), source,
                            assignment['host'], member, estimability_of=uid)
                else:
                    negative_members(index, uid, source, leaves)
            elif category == 'negative_dependencies':
                _, uid, source, barrier = kind
                barrier['remaining'] -= 1
                if barrier['remaining'] == 0:
                    negative_members(index, uid, source, barrier['members'])
            elif kind == 'index':
                # Both endpoints now have the small index used to admit members.
                submit(index, 'inventory', call, assignment['source_host'],
                    'dependency_inventory', source_unit=assignment['source_unit'])
            elif kind == 'inventory':
                for member in value:
                    enqueue(index, 'member', assignment['source_host'], assignment['host'], member,
                        dependency_of=assignment['source_unit'])
            if not pending[index]:
                start(index)
    state['active_transfers'] = active_transfers
    return [results[i] for i in sorted(results)]


def _f45_reconcile_launches(state, observations, run_identity):
    """An unacknowledged start keeps its original coordinate until native proof arrives."""
    if not state:
        return
    for index, assignment in list(state.get('assignments', {}).items()):
        host = assignment['host']
        observed = observations[host]
        owner = observed.get('owner_record', {})
        matched = (owner.get('run_identity') == run_identity
            and owner.get('attempt_id') == assignment['attempt_id']
            and owner.get('unit_id') == assignment['unit_id']
            and owner.get('mode', 'execute') == assignment.get('mode', 'execute')
            and owner.get('source_unit') == assignment.get('source_unit'))
        if (index in state.get('uncertain', {})
                and not state['uncertain'][index].startswith('TRANSFER_OUTCOME_UNKNOWN:')
                and matched and (observed['state'] in {'RUNNING', 'UNKNOWN'}
                or observed['state'] == 'IDLE' and owner.get('exit_status') == 'RETURNED')):
            del state['assignments'][index], state['pending'][index], state['uncertain'][index]
        elif observed['state'] == 'IDLE' or (observed['state'] == 'UNKNOWN'
                and observed.get('active_unit') is None and observed.get('reason') in {
                    'OWNER_LOCKED_WITHOUT_IDENTITY', 'OWNER_LOCKED_WITHOUT_LIVE_IDENTITY'}):
            observations[host] = {**observed, 'state': 'UNKNOWN',
                'active_unit': assignment['unit_id'], 'active_mode': assignment.get('mode', 'execute'),
                'active_source_unit': assignment.get('source_unit'),
                'reason': 'LAUNCH_PENDING:' + state.get('uncertain', {}).get(index, 'TRANSFER_OR_START_IN_FLIGHT')}
        elif observed.get('active_unit') is not None:
            _require(matched, 'F45_START_OWNER_IDENTITY_DRIFT')


def dispatch_f45_next(run_path, *, code_root, remote_run_path, archive_root=None,
                      archive_mode="paused", follow=False, poll_seconds=30):
    """Act on the existing next assignment once, or refill it while this command runs."""
    import concurrent.futures
    import fcntl
    import subprocess
    import time
    os.environ["PADML_F45_RUN_PATH"] = str(run_path)
    run = load_f45_run(run_path)
    _require(run["kind"] == "PADML_INTEGRATED_RAW_RUN_V1" and Path(code_root).is_absolute()
        and Path(remote_run_path).is_absolute()
        and archive_mode in {"paused", "staging", "enabled"}
        and (archive_mode == "paused" or archive_root is not None and Path(archive_root).is_absolute())
        and 5 <= poll_seconds <= 60, "RAW_DISPATCH_CONFIG_INVALID")
    acceptance_path = None
    pause_record = Path(run_path).with_name('resume-start.json')
    if run.get('evaluation_extension') is not None and archive_mode != 'paused':
        _require(pause_record.is_file() and strict_json_bytes(pause_record.read_bytes()).get(
            'archive_resume_authorization',{}).get('source') == 'SUBSEQUENT_EXPLICIT_HUMAN_MESSAGE',
            'ARCHIVE_USER_PAUSE_REQUIRES_NEW_AUTHORIZATION')
    if archive_mode != 'paused' and pause_record.is_file():
        _require(not strict_json_bytes(pause_record.read_bytes()).get('user_pause_active',False),
            'ARCHIVE_USER_PAUSE_REQUIRES_NEW_AUTHORIZATION')
    if archive_mode == 'enabled' and run.get('post_result_repair') is not None:
        from .f4 import validate_post_result_archive_acceptance
        acceptance_path = Path(run_path).with_suffix('.repair-acceptance.json')
        validate_post_result_archive_acceptance(run, acceptance_path)
    for connection in run["host_connections"].values():
        _f45_connection(connection)
    def payload(operation, **extra):
        return {"run": str(remote_run_path), "identity": run["identity"], "operation": operation, **extra}
    def call(host, operation, **extra):
        # A retained inventory can exceed the short control-RPC deadline.
        # Status probes keep their bounded wait and exact UNKNOWN reconciliation.
        timeout = 600 if operation == "archive_inventory" and not extra.get("status_only") else 60
        result = subprocess.run(_f45_remote_command(run, host, code_root, payload(operation, **extra)),
            capture_output=True, timeout=timeout, check=False)
        if result.returncode == 255:
            raise ConnectionError("F45_SSH_UNAVAILABLE:" + host + ":" + operation)
        _require(result.returncode == 0, "F45_REMOTE_CALL_FAILED:" + host + ":" + operation + ":" + result.stderr.decode(errors="replace")[-1500:])
        return strict_json_bytes(result.stdout)
    def transfer(source, destination, member, *, dependency_of=None, estimability_of=None):
        with transfer_slots:
            return transfer_member(source, destination, member, dependency_of=dependency_of,
                estimability_of=estimability_of)
    def transfer_member(source, destination, member, *, dependency_of=None, estimability_of=None):
        if source == destination:
            return
        scope = ({"dependency_of": dependency_of} if dependency_of else {}) | (
            {"estimability_of": estimability_of} if estimability_of else {})
        pin = call(source, "pin", member=member, **scope)
        _require(set(pin) == {"sha256", "size_bytes"}, "F45_TRANSFER_SOURCE_ABSENT")
        # Only explicit absence permits a transfer; an SSH/permission error is unknown.
        existing = call(destination, "pin", member=member, **scope)
        if existing != {"status": "ABSENT"}:
            _require(existing == pin, "F45_TRANSFER_DESTINATION_DRIFT")
            return
        command = _f45_remote_command(run, source, code_root, payload("send", member=member, pin=pin, **scope))
        with tempfile.TemporaryFile() as errors:
            sender = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=errors)
            try:
                try:
                    receiver = subprocess.run(_f45_remote_command(run, destination, code_root,
                        payload("receive", member=member, pin=pin, **scope)), stdin=sender.stdout, capture_output=True, timeout=600)
                    sender.stdout.close()
                    sent = sender.wait(timeout=30)
                except (OSError, subprocess.TimeoutExpired) as error:
                    raise _F45TransferOutcomeUnknown(
                        "F45_TRANSFER_RECEIPT_UNKNOWN:" + source + ":" + destination + ":" + member) from error
                if 255 in (sent, receiver.returncode):
                    raise _F45TransferOutcomeUnknown("F45_TRANSFER_SSH_UNAVAILABLE:" + source + ":" + destination + ":" + member)
                receipt = strict_json_bytes(receiver.stdout) if receiver.returncode == 0 else None
                if (isinstance(receipt, dict) and receipt.get('status') == 'TRANSFER_RETRY_REQUIRED'
                        and receipt.get('pin') == pin and receipt.get('reason') in {
                            'F45_TRANSFER_INPUT_TIMEOUT', 'F45_TRANSFER_TOTAL_TIMEOUT'}):
                    raise ConnectionError(receipt['reason'] + ':' + destination + ':' + member)
                _require(sent == receiver.returncode == 0 and receipt == pin,
                    "F45_TRANSFER_FAILED:" + source + ":" + destination + ":" + member)
            finally:
                try:
                    if sender.poll() is None:
                        sender.terminate()
                        try:
                            sender.wait(timeout=15)
                        except subprocess.TimeoutExpired:
                            # Reap only our local SSH child. This is not remote
                            # completion evidence and cannot release its attempt.
                            sender.kill(); sender.wait(timeout=15)
                            raise _F45TransferOutcomeUnknown("F45_TRANSFER_LOCAL_SENDER_REQUIRED_KILL")
                except (OSError, subprocess.TimeoutExpired) as error:
                    raise _F45TransferOutcomeUnknown(
                        "F45_TRANSFER_LOCAL_SENDER_EXIT_UNKNOWN:" + source + ":" + destination + ":" + member) from error
                finally:
                    try:
                        sender.stdout.close()
                    except OSError as error:
                        raise _F45TransferOutcomeUnknown("F45_TRANSFER_LOCAL_PIPE_CLOSE_UNKNOWN") from error
    import tempfile
    import threading
    import signal
    from contextlib import contextmanager

    @contextmanager
    def drain_on_interrupt():
        draining = threading.Event()
        main = threading.current_thread() is threading.main_thread()
        previous = signal.getsignal(signal.SIGINT) if main else None
        if main:
            signal.signal(signal.SIGINT, lambda *_: draining.set())
        try:
            yield draining
        finally:
            if main:
                signal.signal(signal.SIGINT, previous)

    transfer_slots = threading.BoundedSemaphore(3)
    controller_lock=(Path(run['archive_transfer']['rebuild_record']).with_name('.dispatch.lock')
        if run.get('archive_transfer') is not None else run_path.with_name('.dispatch.lock'))
    with controller_lock.open("a+") as coordinator, drain_on_interrupt() as draining:
        try:
            fcntl.flock(coordinator, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise ContractError("F45_NEXT_ALREADY_ACTIVE") from None
        with concurrent.futures.ThreadPoolExecutor(max_workers=7) as pool:
            from .reports import WindowArchive
            archives, archive_retry_at, archive_error = None, 0, None
            curve_report, repair_report, closure_report, extension_report = None, None, None, None
            launch_state = {} if follow else None
            units = {u['unit_id']:u for u in run['units']}
            while True:
                observations = {}
                jobs = {pool.submit(call, host, "observe"): host for host in F45_HOSTS}
                for future in concurrent.futures.as_completed(jobs):
                    host = jobs[future]
                    try:
                        observations[host] = future.result()
                    except Exception as error:
                        observations[host] = {"state": "UNKNOWN", "active_unit": None, "reason": str(error)[-1800:]}
                _f45_reconcile_launches(launch_state, observations, run['identity'])
                unknown = {h: o for h, o in observations.items() if o["state"] == "UNKNOWN"}
                if unknown:
                    print(json.dumps({"status": "ATTENTION_REQUIRED", "hosts": unknown}), flush=True)
                    if any(o.get('active_unit') is None for o in unknown.values()):
                        if not follow:
                            return {"status": "ATTENTION_REQUIRED", "new_jobs": 0}
                        # Retain the same lock, futures and attempts. Do not pump
                        # queued RPCs or archive a partial/unlocatable snapshot.
                        time.sleep(poll_seconds)
                        continue
                started = _f45_launch_assignments([], units, {}, [], pool=pool,call=call,transfer=transfer,
                    inflight=launch_state) if follow else []
                pending_launches = launch_state.get('assignments',{}) if follow else {}
                if draining.is_set():
                    # Keep the original lock and attempt state until accepted
                    # transfer/inventory/start work has a reconciled receipt.
                    archive_drained = True
                    if archive_mode in {'staging', 'enabled'} and archives is not None:
                        archives.advance(observations, draining=True)
                        archive_drained = archives.drained()
                    if not pending_launches and not (launch_state or {}).get('futures') and archive_drained:
                        return {"status": "DRAINED", "new_jobs": 0, "hosts": observations}
                    print(json.dumps({"status": "DRAINING", "pending_attempts": [
                        {k: row.get(k) for k in ('host', 'unit_id', 'mode', 'source_unit', 'attempt_id')}
                        for row in pending_launches.values()]}), flush=True)
                    time.sleep(min(poll_seconds, 5))
                    continue
                assignments = f45_ready_assignments(run, observations)
                assignments = [a for a in assignments if a['host'] not in {
                    pending['host'] for pending in pending_launches.values()}]
                completed = set().union(*(set(o["completed_units"]) for o in observations.values()))
                not_estimable = set().union(*(set(o.get("not_estimable_units", [])) for o in observations.values()))
                terminal = completed | not_estimable
                selected = set().union(*(set(o["selection_completed_units"]) for o in observations.values()))
                postprocessed = set().union(*(set(o["postprocess_ready_units"]) for o in observations.values()))
                training = {u["unit_id"] for u in run["units"] if u["kind"] in {"PRIMARY", "FULL0"}} - not_estimable
                if archive_mode != "paused" and archives is None and time.monotonic() >= archive_retry_at:
                    try:
                        archives = WindowArchive(run, archive_root, pool=pool, call=call, slots=transfer_slots,
                            command=lambda h, op, **kw: _f45_remote_command(run, h, code_root, payload(op, **kw)),
                            **({'staging':True} if archive_mode == 'staging' else
                               {'acceptance_path':acceptance_path} if acceptance_path is not None else {}))
                    except Exception as error:
                        archive_error = f"{type(error).__name__}: {error}"[-1800:]
                        archive_retry_at = time.monotonic() + 60
                archive_states = ({"status": "PAUSED"} if archive_mode == "paused" else
                    archives.advance(observations) if archives is not None else {
                        "initialization": {"status": "RETRY_WAIT", "reason": archive_error}})
                computations_done = not pending_launches and terminal == set(units) and selected == postprocessed == training and all(
                    o["state"] == "IDLE" for o in observations.values())
                if run.get('evaluation_decision') is not None:
                    points = set().union(*(set(o.get('evaluation_amendment_units',[])) for o in observations.values()))
                    selections = set().union(*(set(o.get('selection_amendment_units',[])) for o in observations.values()))
                    expected_points = training | {uid for uid in completed if units[uid]['kind']=='EVALUATION'}
                    computations_done = computations_done and points == expected_points and selections == training
                if run.get('evaluation_extension') is not None:
                    from .evaluation_extension import eligible as extension_eligible
                    required_extension = {uid for uid,u in units.items() if extension_eligible(run,u)}
                    done_extension = set().union(*(set(o.get('evaluation_extension_identities',{}))
                        for o in observations.values()))
                    computations_done = computations_done and done_extension == required_extension
                if run.get('curve_rmse') is not None and curve_report is None:
                    from .curve_rmse import eligible as curve_eligible
                    curve_units = {uid for uid,u in units.items() if curve_eligible(run,u)}
                    if curve_units <= points:
                        from .reports import collect_curves
                        curve_report = collect_curves(run,observations,
                            report_root=run_path.with_suffix('.repair-report'),pool=pool,call=call,
                            command=lambda h,op,**kw:_f45_remote_command(run,h,code_root,payload(op,**kw)))
                        print(json.dumps({**curve_report,'status':'CURVE_REPORT_COMPLETED'}),flush=True)
                if computations_done and (archive_mode != "enabled" or run.get('evaluation_extension') is not None):
                    if run.get('post_result_repair') is not None and repair_report is None:
                        from .reports import collect_repair
                        repair_report = collect_repair(run,observations,
                            report_root=run_path.with_suffix('.repair-report'),pool=pool,call=call,
                            command=lambda h,op,**kw:_f45_remote_command(run,h,code_root,payload(op,**kw)))
                    if run.get('result_closure') is not None and closure_report is None:
                        from .reports import collect_closure
                        closure_report = collect_closure(run,observations,
                            report_root=run_path.with_suffix('.repair-report'),pool=pool,call=call,
                            command=lambda h,op,**kw:_f45_remote_command(run,h,code_root,payload(op,**kw)),
                            repair_report=repair_report)
                    if run.get('evaluation_extension') is not None and extension_report is None:
                        from .reports import collect_extension
                        extension_report = collect_extension(run,observations,
                            report_root=run_path.with_suffix('.repair-report'),pool=pool,call=call,
                            command=lambda h,op,**kw:_f45_remote_command(run,h,code_root,payload(op,**kw)),
                            repair_report=repair_report,closure_report=closure_report)
                    if run.get('evaluation_extension') is not None:
                        from .evaluation_extension import research_gate,clinical_eligible
                        research=strict_json_bytes(Path(extension_report['report']).read_bytes())
                        gate=research_gate(run,research['research'],research['source_identities'])
                        missing=[h for h,o in observations.items() if o.get('clinical_gate_identity')!=gate['identity_sha256']]
                        jobs=[pool.submit(call,h,'evaluation_extension_gate',gate=gate) for h in missing]
                        for job in jobs:
                            _require(job.result()=={'status':'PUBLISHED','identity_sha256':gate['identity_sha256']},
                                'EVALUATION_EXTENSION_GATE_RECEIPT_DRIFT')
                        clinical_required={uid for uid,u in units.items() if clinical_eligible(run,u)}
                        clinical_done=set().union(*(set(o.get('clinical_extension_identities',{})) for o in observations.values()))
                        if clinical_done!=clinical_required:
                            # The existing appendage queue consumes the gate on
                            # its next fresh observation; do not report complete.
                            if not follow:return {'status':'RESEARCH_COMPLETE_CLINICAL_DISPOSITION_PENDING',
                                'clinical_completed':len(clinical_done),'archive_mode':archive_mode}
                            if missing:continue
                            computations_done=False
                        else:
                            from .reports import collect_extension_clinical
                            extension_report=collect_extension_clinical(run,observations,
                                report_root=run_path.with_suffix('.repair-report'),pool=pool,call=call,
                                command=lambda h,op,**kw:_f45_remote_command(run,h,code_root,payload(op,**kw)),
                                research_report=extension_report)
                    if computations_done and (archive_mode == 'paused' or archives is not None and archives.staged()):
                        return {"status": "COMPUTE_COMPLETE_ARCHIVE_PAUSED" if archive_mode == 'paused'
                                else 'COMPUTE_COMPLETE_MATERIALS_SAVED', "new_jobs": 0,
                                "completed": len(completed), "not_estimable": len(not_estimable),
                                "selection_completed": len(selected), "archives": archive_states,
                                **({'repair_report':repair_report} if repair_report is not None else {}),
                                **({'closure_report':closure_report} if closure_report is not None else {}),
                                **({'extension_report':extension_report} if extension_report is not None else {}),
                                **({'curve_report':curve_report} if curve_report is not None else {})}
                if computations_done and archives is not None and archives.complete():
                    from .reports import collect
                    return collect(run, observations, archive_root=archive_root, call=call, command=lambda h, op, **kw:
                        _f45_remote_command(run, h, code_root, payload(op, **kw)))
                source_hosts = {uid: h for h, o in observations.items() for uid in
                    set(o["evaluation_ready_units"]) | set(o["completed_units"]) | set(o.get("not_estimable_units", []))}
                units = {u["unit_id"]: u for u in run["units"]}
                def needs_draws(assignment):
                    unit = units[assignment["unit_id"]]
                    return unit["kind"] == "EVALUATION" and assignment.get("mode", "execute") == "execute" and not any(
                        uid in not_estimable and units[uid]["kind"] == "PRIMARY" for uid in unit["depends_on"])
                evaluations = [a for a in assignments if needs_draws(a)]
                draw_hosts = [h for h, o in observations.items() if "shared_draws" in o]
                if evaluations and not draw_hosts:
                    # The first original EVALUATION worker creates the shared draws under its owner.
                    # Other lines start as soon as that receipt appears, without waiting for B1000.
                    preparing_draws = any(o["state"] in {"RUNNING", "UNKNOWN"} and needs_draws({
                        "unit_id":o["active_unit"], "mode":o.get("active_mode", "execute")}) for o in observations.values())
                    preparing_draws |= any(needs_draws(a) for a in pending_launches.values())
                    held = evaluations if preparing_draws else evaluations[1:]
                    assignments = [a for a in assignments if a not in held]
                results = started + _f45_launch_assignments([] if draining.is_set() else assignments, units, source_hosts, draw_hosts,
                    pool=pool, call=call, transfer=transfer, inflight=launch_state, not_estimable_units=not_estimable,
                    post_result_repair=run.get('post_result_repair') is not None,
                    curve_only_units=set().union(*(set(o.get('curve_pending_units',[])) |
                        set(o.get('result_closure_pending_units',[])) | set(o.get('evaluation_extension_pending_units',[])) |
                        set(o.get('clinical_extension_pending_units',[]))
                        for o in observations.values())))
                print(json.dumps({"status": "DISPATCHED" if results else "WAITING", "completed": len(completed),
                    "not_estimable": len(not_estimable), "terminal": len(terminal),
                    "selection_completed": len(selected), "jobs": results, "archives": archive_states}), flush=True)
                if not follow:
                    return {"status": "OBSERVED_AND_DISPATCHED", "jobs": results}
                if not computations_done and not assignments and not (launch_state or {}).get('assignments') and all(o["state"] == "IDLE" for o in observations.values()):
                    raise ContractError("F45_NO_READY_JOB_WITH_UNFINISHED_RESULTS")
                time.sleep(poll_seconds)

def prepare_f45_bootstrap(f1_runtime_root: Path, target_root: Path) -> dict[str, Any]:
    """One original RNG draw set, independent of all four fitted policies."""
    from .f4 import _load_o_fit_frozen_source, _f45_source_member_sha256, bootstrap_draws
    from .nested_loco import _write_exact_once
    from .runtime import RSCRIPT_EXECUTABLE
    target_root.mkdir(mode=0o700, parents=True, exist_ok=True)
    if isinstance(f1_runtime_root, Mapping):
        from .integrated import ensure_raw_binding
        frozen = ensure_raw_binding(f1_runtime_root)
        source_binding = {"raw_binding_identity": frozen["receipt"]["identity"]}
    else:
        manifest = load_f1_input_manifest(f1_runtime_root / "input/f1/input-manifest.json")
        replay = _load_replay(f1_runtime_root / "build/f1-replay-seal.zip",
            f1_runtime_root / "build/common-input.zip", manifest)
        frozen = _load_o_fit_frozen_source(f1_runtime_root, manifest, replay, [])
        source_binding = {"f1_identity": manifest["identity"]}
    ids = [p for p in frozen["registry"]["outer"][0]["application_ids"] if frozen["centers"][p] != "55"]
    centers = [frozen["centers"][p] for p in ids]
    archive, record = target_root / "bootstrap.zip", target_root / "bootstrap-preparation.json"
    producer = sha256_bytes(canonical_json_bytes(_f45_source_member_sha256()))
    retained_archive_pin = None
    retained_archive_stat = None
    if record.exists():
        _require(record.is_file() and not record.is_symlink(), "F45_SHARED_RNG_DRIFT")
        saved = strict_json_bytes(record.read_bytes())
        admitted = {producer}
        if isinstance(f1_runtime_root, Mapping):
            from .integrated import same_batch_generations
            admitted.update(same_batch_generations(f1_runtime_root).values())
        _require(saved.get("f45_source_sha256") in admitted
            and archive.is_file() and not archive.is_symlink(), "F45_SHARED_RNG_DRIFT")
        retained_archive_stat = archive.stat()
        retained_archive_pin = {"sha256": sha256_file(archive), "size_bytes": retained_archive_stat.st_size}
        _require(saved.get("rng_archive") == retained_archive_pin, "F45_SHARED_RNG_DRIFT")
        producer = saved["f45_source_sha256"]
    plan = bootstrap_draws(ids, centers, "FIXED_MODEL_PAIRED", replicate_count=1000,
        rscript=RSCRIPT_EXECUTABLE, **({"replay_archive": archive} if archive.is_file() else {"retained_archive": archive}))
    if retained_archive_stat is not None:
        after = archive.stat()
        _require(not archive.is_symlink() and all(getattr(after, key) == getattr(retained_archive_stat, key) for key in
            ("st_dev", "st_ino", "st_size", "st_mtime_ns", "st_ctime_ns")), "F45_SHARED_RNG_DRIFT")
    value = {"status": "PREPARED_SHARED_F45_DRAWS", "stage_acceptance": False,
        "shared_rng_invocations": 1, "new_model_fits": 0, "bootstrap_replicates_executed": 0,
        "rng_archive": retained_archive_pin or {"sha256": sha256_file(archive), "size_bytes": archive.stat().st_size},
        "f45_source_sha256": producer,
        **source_binding, "patient_ids_sha256": sha256_bytes(canonical_json_bytes(ids)),
        "centers_sha256": sha256_bytes(canonical_json_bytes(centers)),
        "draws_sha256": sha256_bytes(canonical_json_bytes(plan["draws"]))}
    _write_exact_once(record, canonical_json_bytes(value), "F45_SHARED_RNG_DRIFT")
    return value



def main() -> None:
    import sys
    if len(sys.argv)>1 and sys.argv[1]=='f45-archive':
        parser=argparse.ArgumentParser(prog='padml.run f45-archive')
        parser.add_argument('phase',choices=['prepare','offline','clear-relay','environment'])
        parser.add_argument('run',type=Path)
        parser.add_argument('--archive-root',type=Path,required=True)
        parser.add_argument('--preflight',type=Path)
        parser.add_argument('--code-root',type=Path)
        parser.add_argument('--remote-run-path',type=Path)
        parser.add_argument('--environment-identity')
        args=parser.parse_args(sys.argv[2:])
        from . import reports
        import fcntl
        run_path=args.run.resolve(strict=True)
        os.environ['PADML_F45_RUN_PATH']=str(run_path)
        if args.phase=='offline':os.environ['PADML_ARCHIVE_INDEX']=str(run_path.parent/'index.json')
        run=load_f45_run(run_path);cfg=reports.validate_archive_transfer(run)
        _require(str(args.archive_root)==cfg['project_root'],'ARCHIVE_OFFLINE_ROOT_DRIFT')
        if args.phase=='environment':
            _require(args.code_root is not None and args.remote_run_path is not None
                and args.environment_identity is not None,'ENVIRONMENT_CONFIG_REQUIRED')
            value=reports.preserve_oss_environment(run_path,code_root=args.code_root,
                remote_run_path=args.remote_run_path,environment_identity=args.environment_identity)
        else:
            # The same controller lock excludes enabled transfers and deletion.
            control=Path(cfg['rebuild_record']).parent/'.dispatch.lock'
            from contextlib import nullcontext
            with (nullcontext(None) if args.phase=='offline' and not control.exists() else control.open('a+')) as lock:
                if lock is not None:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
                if args.phase=='prepare':
                    _require(args.preflight is not None,'ARCHIVE_PREFLIGHT_REQUIRED')
                    preflight=strict_json_bytes(args.preflight.read_bytes())
                    value=reports.prepare_oss_rebuild(run,preflight['inventories'],
                        acceptance_path=Path(preflight['acceptance_path']),available_cny=preflight['available_cny'],
                        estimated_cny=preflight['estimated_cny'],probe_receipt=preflight['probe_receipt'],
                        readers_quiescent=preflight['readers_quiescent'],
                        funding_authority=preflight.get('funding_authority'))
                elif args.phase=='offline':value=reports.offline_archive_acceptance(run,args.archive_root)
                else:value=reports.finish_oss_relay(run,args.archive_root)
        print(json.dumps(value));return
    if len(sys.argv) > 1 and sys.argv[1] == "f45-bootstrap":
        parser = argparse.ArgumentParser(prog="padml.run f45-bootstrap")
        parser.add_argument("f1_runtime_root", type=Path)
        parser.add_argument("target_root", type=Path)
        args = parser.parse_args(sys.argv[2:])
        print(json.dumps(prepare_f45_bootstrap(args.f1_runtime_root, args.target_root)))
        return
    if len(sys.argv) > 1 and sys.argv[1] == "f45-prepare":
        parser = argparse.ArgumentParser(prog="padml.run f45-prepare")
        parser.add_argument("target", type=Path)
        parser.add_argument("--run-root", type=Path, required=True)
        parser.add_argument("--workbook", type=Path, required=True)
        parser.add_argument("--run-id", required=True)
        parser.add_argument("--hosts", type=Path, required=True)
        parser.add_argument("--environment", type=Path, required=True)
        parser.add_argument("--source-bundle-sha256", required=True)
        args = parser.parse_args(sys.argv[2:])
        value = prepare_f45_run(args.target, run_root=args.run_root, workbook=args.workbook, run_id=args.run_id,
            hosts=strict_json_bytes(args.hosts.read_bytes()), environment=strict_json_bytes(args.environment.read_bytes()),
            source_bundle_sha256=args.source_bundle_sha256)
        print(json.dumps({"identity": value["identity"], "unit_count": len(value["units"])}))
        return
    if len(sys.argv) > 1 and sys.argv[1] == "f45-next":
        parser = argparse.ArgumentParser(prog="padml.run f45-next")
        parser.add_argument("run", type=Path)
        parser.add_argument("observations", type=Path, nargs="?")
        parser.add_argument("--dispatch", action="store_true")
        parser.add_argument("--follow", action="store_true")
        parser.add_argument("--code-root", type=Path)
        parser.add_argument("--remote-run-path", type=Path)
        parser.add_argument("--archive-root", type=Path)
        parser.add_argument("--archive-mode", choices=("paused", "staging", "enabled"), default="paused")
        parser.add_argument("--poll-seconds", type=int, default=30)
        args = parser.parse_args(sys.argv[2:])
        if args.dispatch:
            _require(args.observations is None and all(v is not None for v in
                (args.code_root, args.remote_run_path)), "F45_DISPATCH_REAL_OBSERVATIONS_REQUIRED")
            value = dispatch_f45_next(args.run.resolve(strict=True), code_root=args.code_root,
                remote_run_path=args.remote_run_path, archive_root=args.archive_root, archive_mode=args.archive_mode,
                follow=args.follow, poll_seconds=args.poll_seconds)
        else:
            _require(args.observations is not None and not args.follow, "F45_OBSERVATIONS_OR_DISPATCH_REQUIRED")
            value = f45_ready_assignments(load_f45_run(args.run), strict_json_bytes(args.observations.read_bytes()))
        print(json.dumps(value))
        return
    parser = argparse.ArgumentParser(prog="padml-f2")
    commands = parser.add_subparsers(dest="command", required=True)
    build = commands.add_parser("prepare")
    build.add_argument("--runtime-root", type=Path, default=DEFAULT_RUNTIME_ROOT)
    build.add_argument("--run-id", required=True)
    build.add_argument("--selector-search-from", type=Path)
    build.add_argument("--selector-primary-from", type=Path)
    build.add_argument("--selector-results-from", type=Path)
    build.add_argument("--host-effective-cpus", type=int, nargs=6, required=True,
                       help="SSH-observed effective CPUs in H0 H1 H4 H5 H6 H7 order")
    validate = commands.add_parser("validate")
    validate.add_argument("run_root", type=Path)
    final = commands.add_parser("aggregate")
    final.add_argument("run_root", type=Path)
    args = parser.parse_args()
    if args.command == "prepare":
        value = prepare(args.runtime_root, args.run_id, selector_search_from=args.selector_search_from,
                        selector_primary_from=args.selector_primary_from,
                        selector_results_from=args.selector_results_from,
                        host_effective_cpus=dict(zip(HOSTS, args.host_effective_cpus, strict=True)))
    elif args.command == "validate":
        value = validation_summary(args.run_root)
    else:
        value = aggregate(args.run_root)
    print(json.dumps(value, sort_keys=True, separators=(",", ":")))


if __name__ == "__main__":
    main()
