"""The one approved non-formal F4/F5 pass-through, not a stage launcher.

Four fixed components run serially, using the production scientific functions.
There is no retry/resume, family selection, budget transfer or formal receipt.
"""

from __future__ import annotations

import argparse
from collections import Counter
import csv
import io
import os
from pathlib import Path
import subprocess
import tempfile
from typing import Any, Mapping

from .bundle import (ContractError, canonical_json_bytes, read_safe_zip,
                     sha256_bytes, sha256_file, strict_json_bytes, write_deterministic_zip)
from .runtime import RSCRIPT_EXECUTABLE, THREAD_ENV


FAMILY = "FPM_TVC_SET_A"
SCOPE = {
    "kind": "PADML_F45_ONE_REAL_PASS_THROUGH_M2_QC",
    "family": FAMILY, "family_role": "NONFORMAL_VALIDATION_NOT_A15_SELECTION",
    "learning": {"outer_fold": 1, "repeat": 2, "inner_fold": 1,
                 "sample_fraction": 0.4, "seed_ordinal": 1, "imputations": 5},
    "a12": {"outer_fold": 1, "branch": "WITHOUT_AST_ALT_TOTAL", "imputation": 1},
    "clone": {"replicate": 1, "outer_fold": 1, "repeat": 1, "inner_fold": 1},
    "application": {"center": "36", "patients": 2, "models": 0,
                    "seta_source": "ACCEPTED_OUTER1_NOT_FINAL_F5",
                    "order": "FIRST_TWO_A04_CANONICAL_RAW_MISSING"},
    "authorized_maximum": {"prediction_fits": 6, "stop_fits": 5,
                           "mice_chains": 34, "selector_paths": 375, "attempts": 1},
    "planned": {"prediction_fits": 6, "stop_fits": 0, "mice_chains": 24},
    "stage_acceptance": False,
}


def _require(condition: bool, reason: str) -> None:
    if not condition:
        raise ContractError(reason)


def _write(path: Path, value: Any) -> None:
    path.write_bytes(canonical_json_bytes(value))


def compile_input(f2_run_root: Path, target: Path) -> dict[str, Any]:
    """Copy only frozen source bytes and the accepted outer1 FPM, without RNG."""
    from .f4 import load_f4_inputs
    from .f5_application import _new_target
    _new_target(target)
    inputs = load_f4_inputs(f2_run_root, include_o_fit_source=True)
    frozen = inputs["o_fit_source"]
    members = {"scope.json": canonical_json_bytes(SCOPE),
               "source.json": canonical_json_bytes(inputs["source"]),
               "binding.json": canonical_json_bytes(frozen["binding_contract"]),
               "f1-manifest.json": canonical_json_bytes(frozen["f1_manifest"]),
               "model.json": canonical_json_bytes(frozen["models"][1, FAMILY]),
               "covariates.csv": frozen["covariates_csv"], "response.csv": frozen["response_csv"]}
    write_deterministic_zip(target, members)
    return {"sha256": sha256_file(target), "size_bytes": target.stat().st_size,
            "stage_acceptance": False}


def _load_input(source: Path) -> tuple[dict, dict]:
    from .f4 import _registered_learning_curve_cells
    _require(source.is_absolute() and source.is_file() and not source.is_symlink(),
             "F45_VALIDATION_INPUT_PATH_INVALID")
    entries = read_safe_zip(source, expected_members={"scope.json", "source.json", "binding.json",
        "f1-manifest.json", "model.json", "covariates.csv", "response.csv"})
    _require(strict_json_bytes(entries["scope.json"]) == SCOPE, "F45_VALIDATION_SCOPE_MISMATCH")
    binding, manifest, model, origin = [strict_json_bytes(entries[name]) for name in (
        "binding.json", "f1-manifest.json", "model.json", "source.json")]
    _require(binding["covariates_sha256"] == sha256_bytes(entries["covariates.csv"])
             and binding["response_seal_sha256"] == sha256_bytes(entries["response.csv"])
             and origin["f1_identity"] == manifest["identity"]
             and manifest["binding_contract_sha256"] == sha256_bytes(entries["binding.json"])
             and model["family"] == FAMILY and model["fold"] == 1 and model["status"] == "PASS",
             "F45_VALIDATION_SOURCE_MISMATCH")
    rows = list(csv.DictReader(io.StringIO(entries["covariates.csv"].decode("utf-8-sig"))))
    frozen = {"registry": binding["registry"], "binding_contract": binding,
              "f1_manifest": manifest, "models": {(1, FAMILY): model},
              "covariates_csv": entries["covariates.csv"], "response_csv": entries["response.csv"],
              "centers": {row["Patient_ID"]: row["Center"] for row in rows}}
    cells = _registered_learning_curve_cells(binding, frozen["covariates_csv"], frozen["response_csv"],
                                             None, family=FAMILY)
    cell, = [cell for cell in cells if all(cell[key] == value for key, value in SCOPE["learning"].items())]
    return frozen, cell


def _b1_plan(frozen: Mapping[str, Any], root: Path, *, retained: Path | None = None) -> dict:
    """Call the original sampler once for B1; replay reads, never redraws."""
    from .f4 import FULL_PIPELINE_CENTER_ORDER, _full_pipeline_clone_ids, _full_pipeline_seed_record
    root.mkdir(mode=0o700)
    ordered = sorted(frozen["centers"], key=lambda patient: (
        FULL_PIPELINE_CENTER_ORDER.index(int(frozen["centers"][patient])), patient.encode("utf-8")))
    centers = [int(frozen["centers"][patient]) for patient in ordered]
    request = {"center_order": list(FULL_PIPELINE_CENTER_ORDER), "centers": centers,
               "patient_ids": ordered, "replicate_seeds": [720000001]}
    kernel = Path(__file__).with_name("kernels") / "f4_full_pipeline_resampling.R"
    _write(root / "input.json", request)
    if retained is None:
        with (root / "output.json").open("wb") as stdout, (root / "stderr.txt").open("wb") as stderr:
            completed = subprocess.run([RSCRIPT_EXECUTABLE, "--vanilla", str(kernel), "--validation-b1"],
                input=canonical_json_bytes(request), stdout=stdout, stderr=stderr,
                env={**os.environ, **THREAD_ENV}, check=False, timeout=300)
        _require(completed.returncode == 0, "F45_VALIDATION_B1_NATIVE_FAILURE")
    else:
        _require((retained / "input.json").read_bytes() == canonical_json_bytes(request),
                 "F45_VALIDATION_B1_SOURCE_MISMATCH")
        for name in ("output.json", "stderr.txt"):
            (root / name).write_bytes((retained / name).read_bytes())
    output = strict_json_bytes((root / "output.json").read_bytes())
    _require(set(output) == {"draws", "replicate_seeds", "r_version", "rng"}
             and output["replicate_seeds"] == [720000001]
             and output["rng"] == ["L'Ecuyer-CMRG", "Inversion", "Rejection"]
             and isinstance(output["r_version"], str) and output["r_version"]
             and isinstance(output["draws"], list) and len(output["draws"]) == 1,
             "F45_VALIDATION_B1_NATIVE_INVALID")
    indices = output["draws"][0]
    _require(isinstance(indices, list) and len(indices) == len(ordered)
             and all(type(index) is int and 0 <= index < len(ordered) for index in indices)
             and Counter(centers[index] for index in indices) == Counter(centers),
             "F45_VALIDATION_B1_MULTIPLICITY_INVALID")
    population = {"patient_ids": ordered, "centers": centers,
                  "source_identity_sha256": sha256_bytes(canonical_json_bytes({
                      "patient_ids_sha256": sha256_bytes(canonical_json_bytes(ordered)),
                      "center_assignment_sha256": sha256_bytes(canonical_json_bytes([
                          {"patient_id": patient, "center": center}
                          for patient, center in zip(ordered, centers, strict=True)])),
                      "center_order": list(FULL_PIPELINE_CENTER_ORDER)}))}
    counts = Counter(indices)
    row = {"replicate": 1, "draw_indices": indices, "draw_count": len(indices),
           "unique_source_patient_count": len(counts),
           "draw_membership_sha256": sha256_bytes(canonical_json_bytes([ordered[index] for index in indices])),
           "multiplicity_sha256": sha256_bytes(canonical_json_bytes([[index, counts[index]] for index in sorted(counts)])),
           "bootstrap_clone_ids_sha256": sha256_bytes(canonical_json_bytes(_full_pipeline_clone_ids(
               population["source_identity_sha256"], 1, ordered, indices))),
           "seed_registry": _full_pipeline_seed_record(1)}
    row["replicate_identity_sha256"] = sha256_bytes(canonical_json_bytes(row))
    plan = {"kind": "PADML_F45_VALIDATION_B1_NOT_FORMAL_BOOTSTRAP_PLAN", "family": FAMILY,
            "population": population, "replicates": [row], "native_engine_sha256": sha256_file(kernel),
            "native_output_sha256": sha256_file(root / "output.json"), "stage_acceptance": False}
    plan["identity_sha256"] = sha256_bytes(canonical_json_bytes(plan))
    _write(root / "plan.json", plan)
    if retained is not None:
        _require((retained / "plan.json").read_bytes() == canonical_json_bytes(plan),
                 "F45_VALIDATION_B1_PLAN_MISMATCH")
    return plan


def _prepare(source: Path, root: Path, *, retained: Path | None = None) -> dict:
    from .f2_kernel import _response_rows
    from .f4 import _patient_key_mapping, _prepare_full_pipeline_mice_context, _full_pipeline_mice_validation
    from .f5_application import _csv_rows, application_cohort, application_input_members, load_application_input
    from .f5_sensitivity import _a12_outer_layout, _a12_total_mice_input_members, _load_a12_total_mice_input
    frozen, cell = _load_input(source)
    root.mkdir(mode=0o700)
    layout = _a12_outer_layout({"family": FAMILY, "frozen": frozen}, 1)
    a12 = {}
    for name in ("OUTER_ANALYSIS", "OUTER_APPLICATION"):
        entries = _a12_total_mice_input_members(frozen["binding_contract"], frozen["covariates_csv"],
                                               frozen["response_csv"], 1, name)
        value = strict_json_bytes(entries["input.json"])
        value.update(kind="PADML_F45_A12_M2_VALIDATION_INPUT", chain_seeds=value["chain_seeds"][:2])
        entries["input.json"] = canonical_json_bytes(value)
        a12[name] = root / (name + ".zip")
        write_deterministic_zip(a12[name], entries)
        _load_a12_total_mice_input(a12[name], a12_validation=True)
    ids = list(_response_rows(frozen["response_csv"])[1])
    columns, rows = _csv_rows(frozen["covariates_csv"])
    app_context = {"donor_ids": ids, "patient_keys": _patient_key_mapping(ids),
        "columns": columns, "raw_rows": {row["Patient_ID"]: row for row in rows},
        "validation_family": FAMILY,
        "validation_selected_parents": frozen["models"][1, FAMILY]["selector_evidence"]["selected_parents"],
        "source": {"validation_source_sha256": sha256_file(source),
                   "binding_contract_sha256": sha256_bytes(canonical_json_bytes(frozen["binding_contract"])),
                   "raw_covariates_sha256": sha256_bytes(frozen["covariates_csv"])}}
    cohort = application_cohort(app_context, root / "membership")
    center, = [row for row in cohort["centers"] if row["center"] == "36"]
    patients = center["selected_ids"][:2]
    _require(len(patients) == 2, "F45_VALIDATION_TWO_ORIGINAL_MISSING_PATIENTS_REQUIRED")
    application = {}
    for name, subset in (("batch", patients), ("single1", patients[:1]), ("single2", patients[1:])):
        application[name] = root / (name + "-input.zip")
        write_deterministic_zip(application[name], application_input_members(app_context, subset, validation=True))
        load_application_input(application[name])
    plan = _b1_plan(frozen, root / "b1", retained=retained / "b1" if retained is not None else None)
    clone = _prepare_full_pipeline_mice_context(plan, 1, 1, frozen, root / "clone", rscript=RSCRIPT_EXECUTABLE)
    names = ["INNER_R1_K1_ANALYSIS", "INNER_R1_K1_APPLICATION"]
    clone["mice_specs"] = {name: {**clone["mice_specs"][name],
        "chain_seeds": clone["mice_specs"][name]["chain_seeds"][:2],
        "pass_through": "CLONE_B1_OUTER1_R1_K1_M1"} for name in names}
    _require(all(_full_pipeline_mice_validation(spec) for spec in clone["mice_specs"].values()),
             "F45_VALIDATION_CLONE_SCOPE_MISMATCH")
    lock = {"scope": SCOPE, "source_sha256": sha256_file(source), "learning_cell": cell,
            "a12_selected_parents": layout["selected_parents"], "application_patients": patients,
            "application_membership_sha256": sha256_bytes(canonical_json_bytes(cohort)),
            "b1_plan_identity": plan["identity_sha256"], "clone_mapping": clone["clone_mapping"],
            "clone_partition": clone["inner_partitions"][0],
            "input_sha256": {name: sha256_file(path) for name, path in {**a12, **application}.items()}}
    _write(root / "lock.json", lock)
    if retained is not None:
        _require((retained / "lock.json").read_bytes() == canonical_json_bytes(lock),
                 "F45_VALIDATION_LOCK_REPLAY_MISMATCH")
    return {"frozen": frozen, "cell": cell, "layout": layout, "a12": a12,
            "application": application, "clone": clone}


def _a12_job(prepared: Mapping[str, Any], archives: Path, root: Path, *, retain_evidence: bool = False) -> dict:
    """Both native chains are replayed; only imp01 enters the one fixed fit."""
    from .f2_kernel import (predictor_contract, _expected_family_parent_column_map,
                           _recipe_training_member_bytes, _response_rows, _write_response_subset)
    from .f5 import _compile_partition_design_recipe, _validate_final_design_recipe
    from .f5_sensitivity import materialize_a12_total_mice_view
    root.mkdir(mode=0o700)
    materialized = {name: materialize_a12_total_mice_view(path, archives / (name + ".zip"),
        root / name, a12_validation=True, **({"retain_evidence": True} if retain_evidence else {}))
        for name, path in prepared["a12"].items()}
    analysis, application = materialized["OUTER_ANALYSIS"], materialized["OUTER_APPLICATION"]
    layout = prepared["layout"]
    definition, = layout["definitions"]
    ids = definition["source"]["analysis_ids"]
    partition = {"partition_id": definition["source"]["partition_id"], "fit_ids": ids,
        "covariates": {"input_dir": analysis["input_dir"], "members": analysis["members"][:1],
                       "analysis_ids_sha256": sha256_bytes(canonical_json_bytes(ids)),
                       "analysis_view_sha256": analysis["native_archive_sha256"]}}
    selected = layout["selected_parents"]
    recipe = _compile_partition_design_recipe(FAMILY, selected, partition, root,
        a12=True, a12_validation=True, native_evidence=root / "recipe-native")
    _validate_final_design_recipe(recipe, family=FAMILY, selected_parents=selected)
    design = _expected_family_parent_column_map(selected, FAMILY, predictor_contract(Path(__file__).parent),
                                                recipe["transform_recipe"])
    fields, response = _response_rows(prepared["frozen"]["response_csv"])
    fit_response = _write_response_subset(fields, response, ids, None)
    _require(fit_response["event_count"] == layout["outer_training_event_count"],
             "F45_VALIDATION_A12_EVENT_DRIFT")
    task = {"family": FAMILY, "selected_parents": selected, "parameters": {"family": FAMILY, "df": 3, "tvc_df": 0},
            "imputation": 1, "a12_coordinates": SCOPE["a12"], "registered_model_seed": 301001,
            "model_seed": None, "row_count": len(ids),
            "family_design_column_count": sum(len(row["columns"]) for row in design),
            "common_set_design_df": layout["common_set_design_df"],
            "training_event_count": layout["outer_training_event_count"]}
    return {"entries": {"task.json": canonical_json_bytes(task), "recipe.json": canonical_json_bytes(recipe),
        "fit-covariates.csv": _recipe_training_member_bytes(Path(analysis["input_dir"]) / "imp01.csv", ids),
        "fit-response.csv": fit_response["private_bytes"],
        "prediction-covariates.csv": _recipe_training_member_bytes(
            Path(application["input_dir"]) / "imp01.csv", definition["evaluation_ids"])}}


def execute(source: Path, root: Path) -> dict:
    from .f4 import _execute_learning_curve_cell, _execute_full_pipeline_mice_view
    from .f5_application import _new_target, execute_application_mice
    from .f5_sensitivity import execute_a12_total_mice_bundle, _execute_ablation_component
    _new_target(root)
    root.mkdir(mode=0o700)
    scratch = root / "scratch"
    scratch.mkdir(mode=0o700)
    previous = tempfile.tempdir
    tempfile.tempdir = str(scratch)
    try:
        prepared = _prepare(source, root / "prepared")
        _execute_learning_curve_cell({"cell": prepared["cell"], "source": prepared["frozen"],
                                      "root": str(root / "learning")})
        a12 = root / "a12"
        a12.mkdir(mode=0o700)
        for name, path in prepared["a12"].items():
            execute_a12_total_mice_bundle(path, a12 / (name + ".zip"), a12_validation=True)
        job = _a12_job(prepared, a12, root / "a12-design")
        _execute_ablation_component({**job, "root": str(a12 / "M1")})
        clone = root / "clone"
        clone.mkdir(mode=0o700)
        for name in prepared["clone"]["mice_specs"]:
            _execute_full_pipeline_mice_view(prepared["clone"], name, clone / (name + ".zip"),
                                            rscript=RSCRIPT_EXECUTABLE)
        app = root / "application"
        app.mkdir(mode=0o700)
        for name, path in prepared["application"].items():
            execute_application_mice(path, app / (name + ".zip"))
        result = {"status": "NATIVE_COMPONENTS_COMPUTED_PENDING_LOCAL_REPLAY", "scope": SCOPE,
                  "source_sha256": sha256_file(source), "stage_acceptance": False}
        _write(root / "computed.json", result)
        return result
    except BaseException as exc:
        _write(root / "failure.json", {"error": str(exc), "native_evidence": getattr(exc, "__notes__", []),
                                       "scope": SCOPE, "stage_acceptance": False})
        raise
    finally:
        tempfile.tempdir = previous


def replay(source: Path, results: Path, destination: Path) -> dict:
    """Actual native replay; no new bootstrap draw, MICE or model fit."""
    from .f4 import load_learning_curve_cell_archive, _load_full_pipeline_mice_view
    from .f5_application import _new_target, materialize_application_mice
    from .f5_sensitivity import _replay_ablation_component
    _new_target(destination)
    destination.mkdir(mode=0o700)
    _require(not (results / "failure.json").exists()
             and strict_json_bytes((results / "computed.json").read_bytes()) == {
                 "status": "NATIVE_COMPONENTS_COMPUTED_PENDING_LOCAL_REPLAY", "scope": SCOPE,
                 "source_sha256": sha256_file(source), "stage_acceptance": False},
             "F45_VALIDATION_COMPONENTS_INCOMPLETE")
    prepared = _prepare(source, destination / "prepared", retained=results / "prepared")
    learning = load_learning_curve_cell_archive(results / "learning.zip", frozen_source=prepared["frozen"],
                                                replay_evidence=destination / "learning")
    _require(learning["cell"] == prepared["cell"], "F45_VALIDATION_LEARNING_COORDINATE_DRIFT")
    job = _a12_job(prepared, results / "a12", destination / "a12-design", retain_evidence=True)
    a12 = _replay_ablation_component({**job, "archive": results / "a12/M1.zip",
                                     "replay_evidence": destination / "a12-model"})
    for name in prepared["clone"]["mice_specs"]:
        _load_full_pipeline_mice_view(prepared["clone"], name, results / "clone" / (name + ".zip"),
                                     destination / name, rscript=RSCRIPT_EXECUTABLE, retain_evidence=True)
    for name, path in prepared["application"].items():
        materialize_application_mice(path, results / "application" / (name + ".zip"), destination / name,
                                     retain_evidence=True)
    _write(destination / "component-replay.json", {"learning": learning, "a12_prediction": a12})
    result = {"status": "PASS", "kind": "NONFORMAL_NATIVE_PASS_THROUGH_REPLAY", "scope": SCOPE,
              "source_sha256": sha256_file(source), "stage_acceptance": False,
              "prediction_fits": 6, "stop_fits": 0, "mice_chains": 24,
              "a12_fit_imputations": [1], "a12_qc_only_imputations": [2],
              "application_predictions_validated": False, "formal_f4_f5_started": False}
    _write(destination / "verification.json", result)
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    actions = parser.add_subparsers(dest="action", required=True)
    compiler = actions.add_parser("compile")
    compiler.add_argument("--f2-run", type=Path, required=True)
    compiler.add_argument("--output", type=Path, required=True)
    worker = actions.add_parser("execute")
    worker.add_argument("--input", type=Path, required=True)
    worker.add_argument("--root", type=Path, required=True)
    reader = actions.add_parser("replay")
    reader.add_argument("--input", type=Path, required=True)
    reader.add_argument("--results", type=Path, required=True)
    reader.add_argument("--destination", type=Path, required=True)
    args = parser.parse_args()
    result = (compile_input(args.f2_run, args.output) if args.action == "compile" else
              execute(args.input, args.root) if args.action == "execute" else
              replay(args.input, args.results, args.destination))
    print(canonical_json_bytes(result).decode(), end="")
