"""Direct F5 A12, A19, A04 and C10 sensitivity calculations.

A19 fits the fixed, already locked family. A12 uses original outer SetA,
split-local M20 and the same family's approved search. All diagnostics are
zero-feedback: none changes F2 or the final family, SetA or parameters.
"""

from __future__ import annotations

from .runtime import MIN_WORKER_MEMORY_BYTES, RECORDED_WORKER_MEMORY_BYTES

from .carriers import open_carrier

import argparse
import csv
import io
import json
import math
import os
import re
import shutil
import subprocess
import tempfile
import zipfile
from contextlib import contextmanager
from functools import partial
from decimal import Decimal
from pathlib import Path
from typing import Any, Mapping, Sequence

from ._science_authority import load_science_authority
from .bundle import (
    ContractError,
    canonical_json_bytes,
    extract_safe_zip,
    read_safe_zip,
    sha256_bytes,
    sha256_file,
    strict_json_bytes,
    validate_sha256,
    write_deterministic_zip,
)
from .f2_kernel import (
    _response_rows,
    _seal_prediction_matrix,
    _type7_quantile,
    _write_response_subset,
)
from .f4 import (
    HORIZONS,
    REPORT_HORIZONS,
    _patient_key_mapping,
    _resampled_response_receipt,
    _statistical_support_reasons,
    bootstrap_draws,
    censoring_context,
    decision_curve,
    evaluate_predictions,
    materialize_resampled_view,
    prediction_error,
)

from .runtime import CPU_MINUS_8, RSCRIPT_EXECUTABLE, THREAD_ENV, _bounded_ordered_spawn, resolve_pool_workers


A12_BRANCHES = (
    "PRIMARY_POLICY_A",
    "WITHOUT_AST_ALT_DIRECT",
    "WITHOUT_AST_ALT_TOTAL",
)


def _a12_prediction_branches(survival: Mapping[str, Any]) -> tuple[str, ...]:
    """Choose only the original or approved nested branch domain, canonically."""
    from .nested_loco import fixed_prediction_bootstrap_contract
    nested = tuple(fixed_prediction_bootstrap_contract()["fixed_prediction"]["branches"])
    branches = (nested if set(survival) == set(nested) else
                nested[:3] if set(survival) == set(nested[:3]) else A12_BRANCHES)
    _require(set(survival) == set(branches), "F5_A12_PREDICTION_BRANCH_SET_INVALID")
    return branches


A19_SEED_ROLES = (
    "BASE",
    "EXTRA_OFFSET_10000",
    "EXTRA_OFFSET_20000",
)
A04_MODES = (
    "BATCH_CENTER_TRANSPORTED_M20",
    "SINGLE_PATIENT_APPEND_TO_TRAINING_M20",
)
C10_BRANCHES = ("Creatinine", "eGFR_calc")
_VALIDATION_CENTERS = tuple(
    str(value)
    for value in load_science_authority()["science"]["population"][
        "validation_centers"
    ]
)

_A12_VARIABLE_POLICIES = {
    "PRIMARY_POLICY_A": "AST_ALT_INCLUDED_POLICY_A",
    "WITHOUT_AST_ALT_DIRECT": "REMOVE_AST_ALT_KEEP_IMPUTATION_AUXILIARIES",
    "WITHOUT_AST_ALT_TOTAL": "REMOVE_AST_ALT_AND_AST_ALT_INFORMATION_CHANNEL",
}
_A12_MICE_POLICIES = {
    "PRIMARY_POLICY_A": "REUSE_ACCEPTED_POLICY_A_M20",
    "WITHOUT_AST_ALT_DIRECT": "REUSE_ACCEPTED_POLICY_A_M20",
    "WITHOUT_AST_ALT_TOTAL": "FRESH_SPLIT_LOCAL_M20",
}
_A12_TUNED_FAMILIES = frozenset(
    {
        "ELASTIC_NET_COX",
        "RSF",
        "GBM_COX",
        "XGBOOST_COX",
        "COXTIME_SET_A",
    }
)
_A12_FIXED_FAMILIES = frozenset({"COX_PH", "FPM_TVC_SET_A"})
_A12_POINT_METRICS = tuple(
    metric
    for horizon in REPORT_HORIZONS
    for metric in (
        f"ibs_0_{horizon}",
        f"brier_{horizon}",
        f"auc_{horizon}",
        f"calibration_slope_{horizon}",
        f"calibration_citl_{horizon}",
        f"calibration_oe_{horizon}",
        f"calibration_ici_{horizon}",
        f"calibration_e50_{horizon}",
        f"calibration_e90_{horizon}",
    )
) + ("uno_c_24", "integrated_raw_net_benefit_24")
_A12_MACRO_METRICS = tuple(
    metric
    for horizon in REPORT_HORIZONS
    for metric in (
        f"equal_center_ibs_0_{horizon}",
        f"equal_center_brier_{horizon}",
        f"equal_center_auc_{horizon}",
        f"mean_absolute_calibration_slope_error_{horizon}",
        f"mean_absolute_calibration_citl_{horizon}",
        f"equal_center_calibration_oe_{horizon}",
        f"equal_center_calibration_ici_{horizon}",
        f"equal_center_calibration_e50_{horizon}",
        f"equal_center_calibration_e90_{horizon}",
    )
) + (
    "equal_center_uno_c_24",
    "equal_center_integrated_raw_net_benefit_24",
)
_A19_ROW_FIELDS = frozenset(
    {
        "inner_repeat_id",
        "inner_fold_id",
        "split_identity_sha256",
        "split_seed",
        "seed_role",
        "seed_identity_sha256",
        "model_seed",
        "imp_id",
        "final_family",
        "final_family_decision_sha256",
        "final_parameter_lock_sha256",
        "fit_receipt_sha256",
        "prediction_sha256",
        "patient_set_sha256",
        "time_grid_months",
        "patients",
    }
)
_A19_PATIENT_FIELDS = frozenset(
    {"patient_key_hash", "survival_probabilities"}
)
_A04_ROW_FIELDS = frozenset(
    {"patient_key_hash", "center", "risk_probability_24"}
)
_C10_ROW_FIELDS = frozenset(
    {
        "branch",
        "outer_fold_id",
        "center",
        "family",
        "selected_parents",
        "parameter_lock_sha256",
        "fit_receipts",
        "mi_prediction_sha256",
        "metrics",
        "metric_support",
    }
)


def _require(condition: bool, reason: str) -> None:
    if not condition:
        raise ContractError(reason)


def _finite_probability(value: Any) -> bool:
    return (
        type(value) in {int, float}
        and math.isfinite(value)
        and 0.0 <= value <= 1.0
    )


def _valid_sensitivity_metric(name: str, value: Any, *, nullable: bool) -> bool:
    if value is None:
        return nullable
    if type(value) not in {int, float} or not math.isfinite(value):
        return False
    numeric = float(value)
    probability_tokens = ("auc_", "uno_c_", "harrell_c")
    if any(token in name for token in probability_tokens):
        return 0.0 <= numeric <= 1.0
    if any(token in name for token in (
        "ibs_", "brier_", "calibration_oe_", "calibration_ici_", "calibration_e50_", "calibration_e90_",
    )):
        return numeric >= 0.0
    if "integrated_raw_net_benefit_" in name:
        return -(1.0 / 3.0) <= numeric <= 1.0
    if name.startswith("mean_absolute_calibration_"):
        return numeric >= 0.0
    return True


def _a12_metric_vector(row: Mapping[str, Any], *, selection_horizon_months: int = 24) -> dict[str, float | None]:
    _require(type(selection_horizon_months) is int and selection_horizon_months in {6, 12, 24, 36},
             "F5_A12_METRIC_HORIZON_INVALID")
    primary = selection_horizon_months
    try:
        result = {}
        for horizon in REPORT_HORIZONS:
            calibration = row["calibration"]["horizons"][str(horizon)]
            result.update(
                {
                    f"ibs_0_{horizon}": row["ibs_0_to"][str(horizon)],
                    f"brier_{horizon}": row["brier_monthly"][horizon],
                    f"auc_{horizon}": row["discrimination"]["auc"][
                        str(horizon)
                    ]["value"],
                    **{
                        f"calibration_{metric}_{horizon}": calibration[metric]
                        for metric in ("slope", "citl", "oe", "ici", "e50", "e90")
                    },
                    f"integrated_raw_net_benefit_{horizon}": row[f"dca_{horizon}"]["integrated_raw_nb"],
                }
            )
        result.update(
            {
                f"uno_c_{primary}": row["discrimination"][f"uno_c_{primary}"]["value"],
                "harrell_c": row["discrimination"]["harrell_c"]["value"],
            }
        )
    except (KeyError, IndexError, TypeError) as error:
        raise ContractError("F5_A12_METRIC_SCHEMA_INVALID") from error
    _require(set(result) == set(_A12_POINT_METRICS[:-2]) | {
        f"uno_c_{primary}", "harrell_c", *(f"integrated_raw_net_benefit_{t}" for t in REPORT_HORIZONS)}, "F5_A12_METRIC_SCHEMA_INVALID")
    _require(
        all(
            _valid_sensitivity_metric(name, value, nullable=True)
            for name, value in result.items()
        ),
        "F5_A12_NUMERICAL_ERROR",
    )
    return result


def _a12_macro_metric_vector(row: Mapping[str, Any], *, selection_horizon_months: int = 24) -> dict[str, float | None]:
    _require(type(selection_horizon_months) is int and selection_horizon_months in {6, 12, 24, 36},
             "F5_A12_METRIC_HORIZON_INVALID")
    primary = selection_horizon_months
    try:
        result: dict[str, float | None] = {}
        for horizon in REPORT_HORIZONS:
            values = row[str(horizon)]
            result.update({
                f"equal_center_ibs_0_{horizon}": values["equal_center_ibs"],
                f"equal_center_brier_{horizon}": values["equal_center_brier"],
                f"equal_center_auc_{horizon}": values["equal_center_auc"],
                f"mean_absolute_calibration_slope_error_{horizon}": values[
                    "mean_absolute_slope_error"
                ],
                f"mean_absolute_calibration_citl_{horizon}": values[
                    "mean_absolute_citl"
                ],
                f"equal_center_calibration_oe_{horizon}": values[
                    "equal_center_oe"
                ],
                f"equal_center_calibration_ici_{horizon}": values[
                    "equal_center_ici"
                ],
                f"equal_center_calibration_e50_{horizon}": values[
                    "equal_center_e50"
                ],
                f"equal_center_calibration_e90_{horizon}": values[
                    "equal_center_e90"
                ],
                f"worst_center_ibs_0_{horizon}": values["worst_center_ibs"],
                f"center_gap_ibs_0_{horizon}": values["center_gap_ibs"],
                f"equal_center_integrated_raw_net_benefit_{horizon}": values["equal_center_raw_dca"],
            })
        result.update({
            f"equal_center_uno_c_{primary}": row[str(primary)]["equal_center_uno_c"],
            "equal_center_harrell_c": row["all_followup"]["equal_center_harrell_c"],
        })
    except (KeyError, TypeError) as error:
        raise ContractError("F5_A12_MACRO_METRIC_SCHEMA_INVALID") from error
    _require(
        set(result) == set(_A12_MACRO_METRICS[:-2]) | {
            f"equal_center_uno_c_{primary}", "equal_center_harrell_c",
            *(f"equal_center_integrated_raw_net_benefit_{t}" for t in REPORT_HORIZONS),
            *(f"worst_center_ibs_0_{t}" for t in REPORT_HORIZONS),
            *(f"center_gap_ibs_0_{t}" for t in REPORT_HORIZONS)}
        and all(
            _valid_sensitivity_metric(name, value, nullable=True)
            for name, value in result.items()
        ),
        "F5_A12_MACRO_NUMERICAL_ERROR",
    )
    return result


def _a12_scope_metrics(evaluation: Mapping[str, Any], *, branches: tuple[str, ...] = A12_BRANCHES) -> dict[str, Any]:
    scopes = evaluation.get("scopes")
    _require(
        isinstance(scopes, list)
        and scopes
        and scopes[0].get("scope") == "MICRO"
        and len({row.get("scope") for row in scopes if isinstance(row, Mapping)})
        == len(scopes)
        and all(
            isinstance(row, Mapping)
            and set(row.get("families", {})) == set(branches)
            for row in scopes
        ),
        "F5_A12_EVALUATION_INVALID",
    )
    return {
        row["scope"]: {
            branch: _a12_metric_vector(row["families"][branch],
                selection_horizon_months=evaluation.get("selection_horizon_months", 24))
            for branch in branches
        }
        for row in scopes
    }


def _a12_macro_metrics(evaluation: Mapping[str, Any], *, branches: tuple[str, ...] = A12_BRANCHES) -> dict[str, Any]:
    macro = evaluation.get("macro")
    _require(
        isinstance(macro, Mapping) and set(macro) == set(branches),
        "F5_A12_MACRO_EVALUATION_INVALID",
    )
    return {
        branch: _a12_macro_metric_vector(macro[branch],
            selection_horizon_months=evaluation.get("selection_horizon_months", 24))
        for branch in branches
    }


def _a12_weighted_center_metrics(scopes: Mapping[str, Any], counts: Mapping[str, int], *,
                                 branches: tuple[str, ...]) -> dict[str, dict[str, float | None]]:
    """Fixed raw-cohort weights, never bootstrap-dependent or renormalized."""
    _require(set(counts) == set(_VALIDATION_CENTERS)
             and all(type(n) is int and n > 0 for n in counts.values())
             and set(_VALIDATION_CENTERS) <= set(scopes), "F45_CENTER_WEIGHTS_INVALID")
    total = sum(counts.values())
    names = tuple(scopes[_VALIDATION_CENTERS[0]][branches[0]])
    result = {}
    for branch in branches:
        row = {}
        for metric in names:
            values = [scopes[c][branch][metric] for c in _VALIDATION_CENTERS]
            name = "weighted_center_" + metric
            if metric.startswith("calibration_slope_"):
                name = metric.replace("calibration_slope_", "weighted_mean_absolute_calibration_slope_error_")
                values = [None if x is None else abs(x - 1.0) for x in values]
            elif metric.startswith("calibration_citl_"):
                name = metric.replace("calibration_citl_", "weighted_mean_absolute_calibration_citl_")
                values = [None if x is None else abs(x) for x in values]
            _require(all(x is None or type(x) in (float, int) and math.isfinite(x) for x in values),
                     "F45_WEIGHTED_CENTER_NUMERICAL_ERROR")
            row[name] = (None if any(x is None for x in values) else
                         math.fsum(counts[c] * x for c, x in zip(_VALIDATION_CENTERS, values, strict=True)) / total)
        result[branch] = row
    return result


def _a12_deltas(
    metrics: Mapping[str, Mapping[str, Any]],
    metric_names: Sequence[str] = _A12_POINT_METRICS,
) -> dict[str, Any]:
    branches = _a12_prediction_branches(metrics)
    primary = metrics[branches[0]]
    result = {}
    for branch in branches[1:]:
        result[branch] = {
            metric: (
                None
                if primary[metric] is None or metrics[branch][metric] is None
                else metrics[branch][metric] - primary[metric]
            )
            for metric in metric_names
        }
    return result


def _sensitivity_summary(values: Sequence[float | None]) -> dict[str, Any]:
    _require(bool(values) and all(value is None or type(value) in {int, float} and math.isfinite(value)
                                 for value in values), "F5_SENSITIVITY_NUMERICAL_ERROR")
    numeric = [
        float(value)
        for value in values
        if type(value) in {int, float} and math.isfinite(value)
    ]
    complete = len(numeric) == len(values)
    return {
        "status": "ESTIMABLE" if complete else "NOT_ESTIMABLE",
        "estimable_replicates": len(numeric),
        "total_replicates": len(values),
        "median": _type7_quantile(numeric, 0.5) if complete else None,
        "percentile_95_ci": (
            [_type7_quantile(numeric, 0.025), _type7_quantile(numeric, 0.975)]
            if complete
            else None
        ),
    }


def _validate_a12_handoff(value: Mapping[str, Any]) -> dict[str, Any]:
    if isinstance(value, Mapping) and value.get("kind") == "PADML_F5_A12_ALIGNED_PREDICTIONS_V2":
        from . import nested_loco as nested
        _require(set(value) == {"kind", "program_id", "science_decision", "population_registry", "primary_ooc",
                               "patient_keys", "survival", "branch_provenance"}
                 | ({"estimability"} if "estimability" in value else set())
                 and value["program_id"] == nested.PROGRAM_ID, "F5_A12_INPUT_SCHEMA_INVALID")
        science = nested.validate_science_decision(value["science_decision"])
        _require(science["bootstrap"] == nested.fixed_prediction_bootstrap_contract(),
                 "F5_A12_FIXED_BOOTSTRAP_NOT_AUTHORIZED")
        registry = nested.validate_population_registry(value["population_registry"])
        primary = nested.validate_selected_ooc(value["primary_ooc"], population_registry=registry)
        horizon = nested.selection_horizon(primary["selection_horizon_months"])
        _require(primary["science_decision_sha256"] == science["identity_sha256"],
                 "F5_A12_PRIMARY_HORIZON_SOURCE_INVALID")
        unavailable = _a12_aggregate_estimability(value.get("estimability"))
        branches = ("PRIMARY", *(nested.AAR_ESTIMANDS[:2] if unavailable else nested.AAR_ESTIMANDS))
        survival = value["survival"]
        _require(isinstance(survival, Mapping) and set(survival) == set(branches)
                 and survival["PRIMARY"] == primary["survival"]["NESTED_SELECTED_POLICY"],
                 "F5_A12_ALIGNMENT_INVALID")
        ids = primary["patient_ids"]
        keys = _patient_key_mapping(ids, value["patient_keys"])
        families = {str(row["outer_fold"]): row["selected_family"] for row in primary["selection_by_outer"]}
        rows = value["branch_provenance"]
        _require(isinstance(rows, list) and len(rows) == len(branches)
                 and all(isinstance(row, Mapping) for row in rows), "F5_A12_PROVENANCE_INVALID")
        indexed = {row.get("branch"): row for row in rows}
        _require(set(indexed) == set(branches), "F5_A12_PROVENANCE_INVALID")
        for branch in branches:
            row = indexed[branch]
            seal = _seal_prediction_matrix(ids, survival[branch], HORIZONS)
            _require(all(values[0] == 1.0 for values in survival[branch])
                     and set(row) == {"branch", "family_by_outer", "primary_ooc_sha256", "prediction_sha256",
                                      "producer_receipt_sha256", "estimand_contract", "parameter_policy_by_outer",
                                      "primary_prediction_reused", "selection_effect"}
                     and row["family_by_outer"] == families and row["primary_ooc_sha256"] == primary["identity_sha256"]
                     and row["prediction_sha256"] == seal["sha256"]
                     and row["estimand_contract"] == (None if branch == "PRIMARY" else nested.aar_estimand_contract(branch))
                     and row["parameter_policy_by_outer"] == {outer: (
                         "REUSE_POST_LOCK_PRIMARY_OUTER_M20" if branch == "PRIMARY" else
                         "FAIR_WITHIN_FAMILY_UNCHANGED_GRID" if family in _A12_TUNED_FAMILIES else "FIXED_SPEC_NO_TUNING")
                         for outer, family in families.items()}
                     and row["primary_prediction_reused"] is (branch == "PRIMARY")
                     and row["selection_effect"] == "NONE", "F5_A12_PROVENANCE_INVALID")
            validate_sha256(row["producer_receipt_sha256"], "f5.a12.producer_receipt_sha256")
        _require(len({row["producer_receipt_sha256"] for row in rows}) == len(branches),
                 "F5_A12_PRODUCER_ALIAS_FORBIDDEN")
        return {"patient_ids": ids.copy(), "patient_keys": keys, "centers": primary["centers"].copy(),
            "horizons": HORIZONS.copy(), "survival": {branch: [row.copy() for row in survival[branch]] for branch in branches},
            "science_decision": science, "primary_ooc_sha256": primary["identity_sha256"],
            "selection_horizon_months": horizon,
            "selection_by_outer": primary["selection_by_outer"], "family_by_outer": families,
            "branch_provenance": [dict(indexed[branch]) for branch in branches],
            **({"estimability": unavailable} if unavailable else {})}
    _require(
        isinstance(value, Mapping)
        and set(value)
        == {
            "kind",
            "final_family",
            "patient_ids",
            "patient_keys",
            "centers",
            "horizons",
            "survival",
            "branch_provenance",
        }
        and value["kind"] == "PADML_F5_A12_ALIGNED_PREDICTIONS_V1",
        "F5_A12_INPUT_SCHEMA_INVALID",
    )
    families = set(load_science_authority()["science"]["families"])
    expected_centers = set(_VALIDATION_CENTERS)
    family = value["final_family"]
    ids = value["patient_ids"]
    centers = value["centers"]
    survival = value["survival"]
    _require(
        family in families
        and isinstance(ids, list)
        and isinstance(value["patient_keys"], Mapping)
        and len(ids) == len(set(ids)) > 0
        and isinstance(centers, list)
        and len(centers) == len(ids)
        and all(isinstance(center, str) and center for center in centers)
        and set(centers) == expected_centers
        and value["horizons"] == HORIZONS
        and isinstance(survival, Mapping)
        and list(survival) == list(A12_BRANCHES),
        "F5_A12_ALIGNMENT_INVALID",
    )
    seals = {
        branch: _seal_prediction_matrix(ids, survival[branch], HORIZONS)
        for branch in A12_BRANCHES
    }
    keys = _patient_key_mapping(ids, value["patient_keys"])
    rows = value["branch_provenance"]
    _require(
        isinstance(rows, list) and len(rows) == len(A12_BRANCHES),
        "F5_A12_PROVENANCE_INVALID",
    )
    by_branch = {
        row.get("branch"): row
        for row in rows
        if isinstance(row, Mapping)
    }
    _require(
        len(by_branch) == len(rows) and set(by_branch) == set(A12_BRANCHES),
        "F5_A12_PROVENANCE_INVALID",
    )
    expected_parameter_policy = (
        "FAIR_WITHIN_FAMILY_UNCHANGED_GRID"
        if family in _A12_TUNED_FAMILIES
        else "FIXED_SPEC_NO_TUNING"
    )
    _require(
        family in _A12_TUNED_FAMILIES | _A12_FIXED_FAMILIES,
        "F5_A12_FAMILY_POLICY_INVALID",
    )
    sealed_rows = []
    for branch in A12_BRANCHES:
        row = by_branch[branch]
        _require(
            set(row)
            == {
                "branch",
                "family",
                "prediction_sha256",
                "producer_receipt_sha256",
                "variable_policy",
                "mice_policy",
                "parameter_policy",
                "primary_prediction_reused",
                "family_reselection",
                "grid_relaxed",
                "selection_effect",
            }
            and row["family"] == family
            and row["prediction_sha256"] == seals[branch]["sha256"]
            and row["variable_policy"] == _A12_VARIABLE_POLICIES[branch]
            and row["mice_policy"] == _A12_MICE_POLICIES[branch]
            and row["parameter_policy"]
            == (
                "REUSE_ACCEPTED_POLICY_A_PREDICTIONS"
                if branch == "PRIMARY_POLICY_A"
                else expected_parameter_policy
            )
            and row["primary_prediction_reused"]
            is (branch == "PRIMARY_POLICY_A")
            and row["family_reselection"] is False
            and row["grid_relaxed"] is False
            and row["selection_effect"] == "NONE",
            "F5_A12_PROVENANCE_INVALID",
        )
        validate_sha256(
            row["producer_receipt_sha256"],
            f"f5.a12.{branch}.producer_receipt_sha256",
        )
        sealed_rows.append(dict(row))
    _require(
        len({row["producer_receipt_sha256"] for row in sealed_rows})
        == len(A12_BRANCHES),
        "F5_A12_PRODUCER_ALIAS_FORBIDDEN",
    )
    return {
        "patient_ids": ids.copy(),
        "patient_keys": keys,
        "centers": centers.copy(),
        "horizons": HORIZONS.copy(),
        "survival": {
            branch: [row.copy() for row in survival[branch]]
            for branch in A12_BRANCHES
        },
        "final_family": family,
        "branch_provenance": sealed_rows,
    }


def _a12_evaluation_scope(handoff: Mapping[str, Any]) -> dict[str, Any]:
    """Carry the actual line through fixed-prediction evaluation."""
    from .nested_loco import selection_horizon, validate_science_decision
    horizon = selection_horizon(handoff.get("selection_horizon_months", 24))
    if "science_decision" not in handoff:
        _require(horizon == 24, "F5_A12_EVALUATION_SCOPE_INVALID")
        return {}
    return {"selection_horizon_months": horizon,
        "science_decision": validate_science_decision(handoff["science_decision"])}


def _a12_replicate_items(plan: Mapping[str, Any], replicate_ids: list[int] | None = None) -> list[tuple[int, list[int]]]:
    """Keep original draw IDs when dispatching a non-prefix subset of one plan."""
    count = plan.get("replicate_count")
    draws = plan.get("draws")
    _require(type(count) is int and count > 0 and isinstance(draws, list) and len(draws) == count,
             "F5_A12_RETAINED_PLAN_INVALID")
    ids = list(range(1, count + 1)) if replicate_ids is None else replicate_ids
    _require(isinstance(ids, list) and bool(ids)
             and all(type(rid) is int and 1 <= rid <= count for rid in ids)
             and len(set(ids)) == len(ids), "F5_A12_BOOTSTRAP_REPLICATE_IDS_INVALID")
    return [(rid, draws[rid - 1]) for rid in sorted(ids)]


def _a12_bootstrap_replicate(
    item: tuple[int, list[int]], *,
    evaluation_handoff: Mapping[str, Any], response_csv: bytes,
    work_root: Path | None = None, source_binding: Mapping[str, Any] | None = None,
    retained_bytes_per_replicate: int | None = None,
    admit_io=None,
) -> dict[str, Any]:
    replicate, indices = item
    if work_root is not None:
        archive_path = work_root / f"replicate-{replicate:04d}.zip"
        _require(not archive_path.is_symlink(), "F5_A12_BOOTSTRAP_COORDINATE_INVALID")
        if archive_path.is_file():
            result = _replay_a12_bootstrap_replicate(item, root=work_root,
                evaluation_handoff=evaluation_handoff, response_csv=response_csv,
                source_binding=source_binding, admit_io=admit_io,
                retained_bytes_per_replicate=retained_bytes_per_replicate)
            _retire_a12_compact_copies(archive_path, work_root / f"replicate-{replicate:04d}")
            return result
    selected, response, receipt = materialize_resampled_view(
        evaluation_handoff,
        response_csv,
        indices,
        f"A12-PAIRED-{replicate:04d}",
    )
    native = None if work_root is None else work_root / f"replicate-{replicate:04d}"
    if native is not None:
        native.mkdir(mode=0o700, exist_ok=True)
        _require(not archive_path.exists() and not archive_path.is_symlink(),
                 "F5_A12_BOOTSTRAP_COORDINATE_ALREADY_PRESENT")
        _require(source_binding is not None, "F5_A12_BOOTSTRAP_SOURCE_REQUIRED")
        from .nested_loco import _write_exact_once
        expected_input = {**source_binding, "replicate": replicate, "draw_indices": indices}
        input_path = native / "input.json"
        if input_path.is_file():
            raw = input_path.read_bytes()
            original = strict_json_bytes(raw)
            _require(canonical_json_bytes(original) == raw and _a12_compatible_binding(original, expected_input),
                     "F5_A12_RETAINED_INPUT_MISMATCH")
        else:
            _write_exact_once(input_path, canonical_json_bytes(expected_input), "F5_A12_RETAINED_INPUT_MISMATCH")
    evaluation = evaluate_predictions(selected, response,
        **_a12_evaluation_scope(evaluation_handoff),
        **({"replay_native_archive": native / "metrics.zip"} if native is not None and (native / "metrics.zip").is_file()
           else {"evidence_root": native, "native_archive": native / "metrics.zip"} if native is not None else {}))
    if native is not None:
        (native / "evaluation.json").write_bytes(canonical_json_bytes(evaluation))
        _validate_a12_native_evaluation(evaluation, selected, response, native_archive=native / "metrics.zip",
            **_a12_evaluation_scope(evaluation_handoff),
            admit_io=admit_io)
    branches = _a12_prediction_branches(evaluation_handoff["survival"])
    result = _a12_bootstrap_row(replicate, receipt, evaluation, branches=branches)
    if native is not None:
        if evaluation_handoff.get("science_decision", {}).get("integrated_raw_data", {}).get("compact_coordinates"):
            # The original independent numerical consumer has returned above.
            # Publish only its bound numbers/support, then retire this draw's
            # duplicate patient/native arrays after the compact reader passes.
            _write_a12_compact_coordinate(archive_path, native, source_binding, indices, result, evaluation)
            _require(retained_bytes_per_replicate is None or archive_path.stat().st_size <= retained_bytes_per_replicate,
                     "F5_A12_BOOTSTRAP_STORAGE_ESTIMATE_EXCEEDED")
            _replay_a12_bootstrap_replicate(item, root=work_root, evaluation_handoff=evaluation_handoff,
                response_csv=response_csv, source_binding=source_binding, admit_io=admit_io,
                retained_bytes_per_replicate=retained_bytes_per_replicate)
            _retire_a12_compact_copies(archive_path, native)
            return result
        if retained_bytes_per_replicate is not None:
            from .runtime import observe_execution_resources
            size = sum((native / name).stat().st_size for name in ("input.json", "evaluation.json", "metrics.zip"))
            size += len(canonical_json_bytes(result))
            # Raw members and publication workspace are transient. The run's
            # retained budget bounds the actual archive, not three raw copies.
            _require(observe_execution_resources(work_root)["scratch_available_bytes"] >= 3 * size + 16384,
                     "F5_A12_BOOTSTRAP_PACKAGING_SPACE_INSUFFICIENT")
        write_deterministic_zip(work_root / f"replicate-{replicate:04d}.zip", {
            "input.json": native / "input.json", "evaluation.json": native / "evaluation.json",
            "result.json": canonical_json_bytes(result), "metrics.zip": native / "metrics.zip"}, stored_members={"metrics.zip"})
        _require(retained_bytes_per_replicate is None or archive_path.stat().st_size <= retained_bytes_per_replicate,
                 "F5_A12_BOOTSTRAP_STORAGE_ESTIMATE_EXCEEDED")
        # Only this successful coordinate's own copies; failures remain intact.
        (native / "input.json").unlink()
        (native / "evaluation.json").unlink()
        (native / "metrics.zip").unlink()
        if not any(native.iterdir()):
            native.rmdir()
    return result


def _retire_a12_compact_copies(archive_path, native):
    if not native.exists():
        return
    _require(native.is_dir() and not native.is_symlink(), "F45_PAIRED_RETIREMENT_PATH_INVALID")
    with open_carrier(archive_path) as archive:
        if "consumption.json" not in archive.namelist():
            return
        pins = strict_json_bytes(archive.read("consumption.json"))["original_members"]
    for name, pin in pins.items():
        _require(name in {"input.json", "evaluation.json", "metrics.zip"}, "F45_PAIRED_RETIREMENT_MEMBER_INVALID")
        path = native / name
        if path.exists():
            _require(path.is_file() and not path.is_symlink() and path.stat().st_size == pin["size_bytes"]
                and sha256_file(path) == pin["sha256"], "F45_PAIRED_RETIREMENT_MEMBER_DRIFT")
            path.unlink()
    if not any(native.iterdir()):
        native.rmdir()


def _write_a12_compact_coordinate(path, native, source, indices, result, evaluation):
    """Retain the first consumed numbers, never a new scientific authority."""
    from .nested_loco import _sealed
    compact_input = {**source, "replicate": result["replicate"],
        "draw_indices_sha256": sha256_bytes(canonical_json_bytes(indices))}
    input_raw, result_raw = canonical_json_bytes(compact_input), canonical_json_bytes(result)
    h = evaluation.get("selection_horizon_months", 24)
    support = {}
    for scope in evaluation["scopes"]:
        families = {}
        for branch, row in scope["families"].items():
            def status(value):
                return {k: v for k, v in value.items() if k in {"status", "reason", "reasons", "comparable_pairs", "n_events", "n_controls"}}
            families[branch] = {"auc": {str(t): status(row["discrimination"]["auc"][str(t)]) for t in REPORT_HORIZONS},
                "calibration": {str(t): status(row["calibration"]["horizons"][str(t)]) for t in REPORT_HORIZONS},
                "uno": status(row["discrimination"][f"uno_c_{h}"]),
                "harrell": status(row["discrimination"]["harrell_c"])}
        support[scope["scope"]] = {"patient_count": scope["patient_count"], "ipcw_qc": scope["ipcw_qc"], "families": families}
    consumed = _sealed({"kind": "PADML_PAIRED_CONSUMED_NUMBERS_V1",
        "status": "ORIGINAL_NUMERICAL_CONSUMER_COMPLETED", "selection_horizon_months": h,
        "science_decision_sha256": evaluation["science_decision_sha256"],
        "input_sha256": sha256_bytes(input_raw), "result_sha256": sha256_bytes(result_raw),
        "receipt_sha256": sha256_bytes(canonical_json_bytes(result["receipt"])),
        "original_members": {name: {"sha256": sha256_file(native / name), "size_bytes": (native / name).stat().st_size}
            for name in ("input.json", "evaluation.json", "metrics.zip")}, "support": support})
    write_deterministic_zip(path, {"input.json": input_raw, "result.json": result_raw,
        "consumption.json": canonical_json_bytes(consumed)})


def _read_a12_compact_coordinate(entries, *, source, indices, replicate, handoff):
    """Resume this frozen draw from first-consumed scalar evidence only."""
    from collections import Counter
    failure = "F45_PAIRED_COMPACT_COORDINATE_DRIFT"
    values = {k: strict_json_bytes(v) for k, v in entries.items()}
    _require(all(canonical_json_bytes(values[k]) == raw for k, raw in entries.items()), failure)
    row, proof, original = values["result.json"], values["consumption.json"], values["input.json"]
    h = handoff["selection_horizon_months"]
    _require(handoff.get("science_decision", {}).get("integrated_raw_data", {}).get("compact_coordinates") is True
        and _a12_compatible_binding(original, {**source, "replicate": replicate,
            "draw_indices_sha256": sha256_bytes(canonical_json_bytes(indices))})
        and proof.get("kind") == "PADML_PAIRED_CONSUMED_NUMBERS_V1"
        and proof.get("status") == "ORIGINAL_NUMERICAL_CONSUMER_COMPLETED"
        and proof.get("identity_sha256") == sha256_bytes(canonical_json_bytes({k: v for k, v in proof.items() if k != "identity_sha256"}))
        and proof.get("input_sha256") == sha256_bytes(entries["input.json"])
        and proof.get("result_sha256") == sha256_bytes(entries["result.json"])
        and proof.get("science_decision_sha256") == handoff["science_decision"]["identity_sha256"]
        and proof.get("selection_horizon_months") == h
        and set(proof.get("original_members", {})) == {"input.json", "evaluation.json", "metrics.zip"}
        and set(row) == {"replicate", "receipt", "macro_metrics", "scope_metrics", "macro_deltas", "scope_deltas"}
        and row["replicate"] == replicate, failure)
    for pin in proof["original_members"].values():
        _require(set(pin) == {"sha256", "size_bytes"} and type(pin["size_bytes"]) is int and pin["size_bytes"] > 0, failure)
        validate_sha256(pin["sha256"], "paired.original_member")
    receipt = row["receipt"]
    counts = Counter(indices)
    _require(proof["receipt_sha256"] == sha256_bytes(canonical_json_bytes(receipt))
        and receipt["replicate_id"] == f"A12-PAIRED-{replicate:04d}"
        and receipt["source_patient_count"] == receipt["draw_count"] == len(handoff["patient_ids"])
        and receipt["unique_source_patient_count"] == len(counts)
        and receipt["multiplicity_sha256"] == sha256_bytes(canonical_json_bytes([[i, counts[i]] for i in sorted(counts)])), failure)
    for name in ("resampled_patient_ids_sha256", "response_sha256"):
        validate_sha256(receipt[name], "paired." + name)
    branches = _a12_prediction_branches(handoff["survival"])
    scopes, macro, support = row["scope_metrics"], row["macro_metrics"], proof["support"]
    metric_names = set(_A12_POINT_METRICS[:-2]) | {f"uno_c_{h}", "harrell_c", *(f"integrated_raw_net_benefit_{t}" for t in REPORT_HORIZONS)}
    _require(set(scopes) == set(support) == {"MICRO", *_VALIDATION_CENTERS} and set(macro) == set(branches), failure)
    for scope, metrics in scopes.items():
        sc = support[scope]
        expected_n = len(indices) if scope == "MICRO" else sum(handoff["centers"][i] == scope for i in indices)
        _require(set(metrics) == set(sc["families"]) == set(branches) and sc["patient_count"] == expected_n
            and [q["horizon"] for q in sc["ipcw_qc"]] == HORIZONS, failure)
        for q in sc["ipcw_qc"]:
            _require(q["status"] == ("NOT_ESTIMABLE" if q["reasons"] else "ESTIMABLE"), failure)
            if q["reasons"]:
                _statistical_support_reasons(q)
        for branch, vector in metrics.items():
            _require(set(vector) == metric_names and all(_valid_sensitivity_metric(k, v, nullable=True) for k, v in vector.items()), failure)
            qc, evidence = sc["ipcw_qc"], sc["families"][branch]
            for t in REPORT_HORIZONS:
                _require((vector[f"ibs_0_{t}"] is None) == any(q["status"] == "NOT_ESTIMABLE" for q in qc[1:t+1])
                    and (vector[f"brier_{t}"] is None) == (qc[t]["status"] == "NOT_ESTIMABLE")
                    and (vector[f"integrated_raw_net_benefit_{t}"] is None) == (qc[t]["status"] == "NOT_ESTIMABLE"), failure)
                for native, keys in ((evidence["auc"][str(t)], [f"auc_{t}"]),
                    (evidence["calibration"][str(t)], [f"calibration_{k}_{t}" for k in ("slope", "citl", "oe", "ici", "e50", "e90")])):
                    expected_reasons = list(qc[t]["reasons"])
                    if qc[t]["n_events"] < 20:
                        expected_reasons.append("CASES_BELOW_20")
                    if qc[t]["n_non_events"] < 20:
                        expected_reasons.append("CONTROLS_BELOW_20")
                    allowed = [expected_reasons]
                    if keys[0].startswith("calibration_") and not expected_reasons:
                        allowed.append(["CONSTANT_RISK_CALIBRATION_NOT_IDENTIFIABLE"])
                    _require(native["reasons"] in allowed
                        and native["status"] == ("NOT_ESTIMABLE" if native["reasons"] else "ESTIMABLE")
                        and all((vector[k] is None) == bool(native["reasons"]) for k in keys), failure)
                    if native["reasons"]:
                        _statistical_support_reasons(native)
            value = evidence["uno"]
            expected_reasons = list(qc[h]["reasons"])
            if qc[h]["n_events"] < 20:
                expected_reasons.append("CASES_BELOW_20")
            if qc[h]["n_non_events"] < 20:
                expected_reasons.append("CONTROLS_BELOW_20")
            _require(value["reasons"] == expected_reasons
                and value["status"] == ("NOT_ESTIMABLE" if value["reasons"] else "ESTIMABLE")
                and (vector[f"uno_c_{h}"] is None) == bool(value["reasons"]), failure)
            if value["reasons"]:
                _statistical_support_reasons(value)
            value = evidence["harrell"]
            _require(type(value["comparable_pairs"]) is int and value["comparable_pairs"] >= 0, failure)
            supported = value["comparable_pairs"] > 0
            _require(value["status"] == ("ESTIMABLE" if supported else "NOT_ESTIMABLE")
                and value["reason"] == (None if supported else "NO_COMPARABLE_PAIRS")
                and (vector["harrell_c"] is not None) == supported, failure)
    for branch in branches:
        expected = {}
        for metric in metric_names:
            vals = [scopes[c][branch][metric] for c in sorted(_VALIDATION_CENTERS)]
            name = "equal_center_" + metric
            if metric.startswith("calibration_slope_"):
                name = metric.replace("calibration_slope_", "mean_absolute_calibration_slope_error_")
                vals = [None if v is None else abs(v - 1.0) for v in vals]
            elif metric.startswith("calibration_citl_"):
                name = metric.replace("calibration_citl_", "mean_absolute_calibration_citl_")
                vals = [None if v is None else abs(v) for v in vals]
            expected[name] = None if any(v is None for v in vals) else math.fsum(vals) / 6
        for t in REPORT_HORIZONS:
            vals = [scopes[c][branch][f"ibs_0_{t}"] for c in _VALIDATION_CENTERS]
            complete = all(v is not None for v in vals)
            expected[f"worst_center_ibs_0_{t}"] = max(vals) if complete else None
            expected[f"center_gap_ibs_0_{t}"] = max(vals) - min(vals) if complete else None
        _require(macro[branch] == expected and all(_valid_sensitivity_metric(k, v, nullable=True) for k, v in macro[branch].items()), failure)
    _require(row["macro_deltas"] == _a12_deltas(macro, tuple(macro[branches[0]]))
        and row["scope_deltas"] == {scope: _a12_deltas(values, tuple(values[branches[0]])) for scope, values in scopes.items()}, failure)
    return row


def _a12_bootstrap_row(replicate: int, receipt: Mapping[str, Any], evaluation: Mapping[str, Any], *,
                        branches: tuple[str, ...]) -> dict[str, Any]:
    """One original metric-to-delta reduction, shared by production and readers."""
    scope_metrics = _a12_scope_metrics(evaluation, branches=branches)
    _require(
        set(scope_metrics) == {"MICRO", *_VALIDATION_CENTERS},
        "F5_A12_CENTER_COVERAGE_INVALID",
    )
    macro_metrics = _a12_macro_metrics(evaluation, branches=branches)
    return {
        "replicate": replicate,
        "receipt": receipt, "macro_metrics": macro_metrics, "scope_metrics": scope_metrics,
        "macro_deltas": _a12_deltas(macro_metrics, tuple(macro_metrics[branches[0]])),
        "scope_deltas": {
            scope: _a12_deltas(metrics, tuple(metrics[branches[0]]))
            for scope, metrics in scope_metrics.items()
        },
    }


def _validate_a12_native_evaluation(evaluation: Mapping[str, Any], handoff: Mapping[str, Any], response_csv: bytes,
                                    *, native_archive: Path | bytes, a04_variants: bool = False,
                                    a04_negative: bool = False, point_branch_scope: str | None = None,
                                    selection_horizon_months: int = 24,
                                    science_decision: Mapping[str, Any] | None = None,
                                    admit_io=None) -> None:
    """Replay deterministic errors/DCA and retained R values without R or new draws."""
    from .nested_loco import AAR_ESTIMANDS
    from .nested_loco import selection_horizon, validate_science_decision
    primary = selection_horizon(selection_horizon_months)
    _require(evaluation.get("selection_horizon_months", 24) == primary,
        "F5_A12_NATIVE_HORIZON_SOURCE_INVALID")
    if science_decision is not None:
        science = validate_science_decision(science_decision)
        _require(evaluation.get("science_decision_sha256") == science["identity_sha256"]
            and not (a04_variants or a04_negative), "F5_A12_NATIVE_HORIZON_SOURCE_INVALID")
    else:
        _require(primary == 24, "F5_A12_NATIVE_HORIZON_SOURCE_INVALID")
    _require(type(a04_variants) is bool and type(a04_negative) is bool and not (a04_variants and a04_negative)
             and point_branch_scope in {None, "PRIMARY_ORIGIN", "THREE_AAR"}
             and (point_branch_scope is None or not (a04_variants or a04_negative)),
             "F5_FIXED_EVALUATION_BRANCH_SCOPE_INVALID")
    branches = (("NESTED_SELECTED_POLICY",) if point_branch_scope == "PRIMARY_ORIGIN" else
                tuple(AAR_ESTIMANDS[:2] if _a12_evaluation_estimability(handoff) else AAR_ESTIMANDS) if point_branch_scope == "THREE_AAR" else
                ("LOG_DONOR5", *A04_NEW_MICE_VARIANTS) if a04_variants else
                ("NEGATIVE_CONTROL",) if a04_negative else _a12_prediction_branches(handoff["survival"]))
    _require(set(handoff["survival"]) == set(branches)
             and (point_branch_scope is None or tuple(handoff["survival"]) == branches),
             "F5_FIXED_EVALUATION_BRANCH_SCOPE_INVALID")
    _require(evaluation.get("status") == "COMPUTED"
             and evaluation.get("censoring_method") == "CENTER_KM_FROZEN_F2_RISK_SET_TIES"
             and evaluation.get("model_refit_count") == 0 and evaluation.get("weight_truncation") is False,
             "F5_A12_NATIVE_EVALUATION_INVALID")
    scopes = _a12_scope_metrics(evaluation, branches=branches)
    _require(list(scopes) == ["MICRO", *sorted(_VALIDATION_CENTERS)], "F5_A12_CENTER_COVERAGE_INVALID")
    fields, responses = _response_rows(response_csv)
    native_jobs, native_rows = [], []
    center_step_cache = {}  # independent of production and every other draw/readback
    for scope in evaluation["scopes"]:
        indices = [i for i, center in enumerate(handoff["centers"]) if scope["scope"] == "MICRO" or center == scope["scope"]]
        _require(scope["patient_count"] == len(indices) > 0 and "censoring_reference" not in scope
                 and [row["horizon"] for row in scope["ipcw_qc"]] == HORIZONS,
                 "F5_A12_NATIVE_SUPPORT_DENOMINATOR_INVALID")
        qc = scope["ipcw_qc"]
        ids = [handoff["patient_ids"][i] for i in indices]
        centers = [handoff["centers"][i] for i in indices]
        response = _write_response_subset(fields, responses, ids, None)
        context = censoring_context(ids, centers, response, _center_step_cache=center_step_cache)
        _require(qc == [{key: value for key, value in item.items() if key not in {"weights", "truth"}}
                        for item in context["rows"]], "F5_A12_NATIVE_IPCW_SOURCE_MISMATCH")
        for branch, matrix in handoff["survival"].items():
            metrics = scope["families"][branch]
            selected_survival = [matrix[i] for i in indices]
            from .f4 import _prediction_metrics
            checked_metrics = _prediction_metrics(ids, selected_survival, context)
            _require({key: metrics[key] for key in checked_metrics} == checked_metrics,
                     "F5_A12_NATIVE_DETERMINISTIC_METRICS_MISMATCH")
            native_jobs.append({"primary_report_horizon_months": primary,
                "label": f"{scope['scope']}/{branch}", "patient_ids": ids,
                "times": context["times"], "events": context["events"], "centers": context["centers"],
                "censoring_steps": context["censoring_steps"],
                "survival": [[row[h] for h in REPORT_HORIZONS] for row in selected_survival],
                "ipcw": [context["rows"][h] for h in REPORT_HORIZONS]})
            native_rows.append({**metrics["calibration"], "discrimination": metrics["discrimination"]})
        for support in qc:
            if support["status"] == "NOT_ESTIMABLE":
                _statistical_support_reasons(support)
            else:
                _require(support["status"] == "ESTIMABLE" and support["reasons"] == [],
                         "F5_A12_NATIVE_SUPPORT_INVALID")
        for branch, row in scope["families"].items():
            values = scopes[scope["scope"]][branch]
            for horizon in REPORT_HORIZONS:
                _require((values[f"ibs_0_{horizon}"] is None)
                         == any(item["status"] == "NOT_ESTIMABLE" for item in qc[1:horizon + 1])
                         and (values[f"brier_{horizon}"] is None) == (qc[horizon]["status"] == "NOT_ESTIMABLE"),
                         "F5_A12_NATIVE_SUPPORT_VALUE_MISMATCH")
                expected = list(qc[horizon]["reasons"])
                if qc[horizon]["n_events"] < 20:
                    expected.append("CASES_BELOW_20")
                if qc[horizon]["n_non_events"] < 20:
                    expected.append("CONTROLS_BELOW_20")
                calibration = row["calibration"]["horizons"][str(horizon)]
                native_metrics = [(row["discrimination"]["auc"][str(horizon)], ("value",)),
                                  (calibration, ("slope", "citl", "oe", "ici", "e50", "e90"))]
                if horizon == primary:
                    native_metrics.append((row["discrimination"][f"uno_c_{primary}"], ("value",)))
                for native, metric_fields in native_metrics:
                    reasons = expected
                    if native is calibration and not expected:
                        risks = {min(max(1.0 - handoff["survival"][branch][i][horizon], 1e-6), 1.0 - 1e-6) for i in indices}
                        if len(risks) < 2:
                            reasons = ["CONSTANT_RISK_CALIBRATION_NOT_IDENTIFIABLE"]
                    _require(native["reasons"] == reasons
                             and native["status"] == ("NOT_ESTIMABLE" if reasons else "ESTIMABLE")
                             and all((native[field] is None) == bool(reasons) for field in metric_fields),
                             "F5_A12_NATIVE_SUPPORT_VALUE_MISMATCH")
                    if reasons:
                        _statistical_support_reasons(native)
            for t in REPORT_HORIZONS:
                dca = row[f"dca_{t}"]
                _require(dca["horizon"] == t and dca["status"] == qc[t]["status"]
                    and dca["reasons"] == qc[t]["reasons"]
                    and (dca["integrated_raw_nb"] is None) == (qc[t]["status"] == "NOT_ESTIMABLE"),
                    "F5_A12_NATIVE_SUPPORT_VALUE_MISMATCH")
    observed = _a12_macro_metrics(evaluation, branches=branches)
    for branch in branches:
        mean_names = [k for k in observed[branch] if not k.startswith(("worst_center_ibs_0_", "center_gap_ibs_0_"))]
        for macro_name, scope_name in zip(mean_names, scopes["MICRO"][branch], strict=True):
            values = [scopes[center][branch][scope_name] for center in sorted(_VALIDATION_CENTERS)]
            if scope_name.startswith("calibration_slope_"):
                values = [None if value is None else abs(value - 1.0) for value in values]
            elif scope_name.startswith("calibration_citl_"):
                values = [None if value is None else abs(value) for value in values]
            expected = None if any(value is None for value in values) else math.fsum(values) / 6
            _require(observed[branch][macro_name] == expected, "F5_A12_NATIVE_MACRO_REDUCTION_MISMATCH")
        for horizon in REPORT_HORIZONS:
            values = [scopes[c][branch][f"ibs_0_{horizon}"] for c in _VALIDATION_CENTERS]
            complete = all(value is not None for value in values)
            _require(observed[branch][f"worst_center_ibs_0_{horizon}"] == (max(values) if complete else None)
                and observed[branch][f"center_gap_ibs_0_{horizon}"] == (max(values) - min(values) if complete else None),
                "F5_A12_NATIVE_MACRO_REDUCTION_MISMATCH")
            macro = evaluation["macro"][branch][str(horizon)]
            _require(macro["total_center_count"] == 6 and macro["estimable_center_count"]
                     == sum(scopes[center][branch][f"ibs_0_{horizon}"] is not None for center in _VALIDATION_CENTERS),
                     "F5_A12_NATIVE_MACRO_DENOMINATOR_INVALID")
    entries = read_safe_zip(native_archive, admit_io=admit_io,
        expected_members={"input.json", "stdout.txt", "stderr.txt", "f4_metrics.R", "execution.json"})
    from .f4 import _metric_kernel_compatible
    kernel = Path(__file__).parent / "kernels/f4_metrics.R"
    execution = strict_json_bytes(entries["execution.json"])
    _require(entries["input.json"] == canonical_json_bytes({"jobs": native_jobs})
             and _metric_kernel_compatible(entries["f4_metrics.R"], kernel.read_bytes(),
                 horizon=evaluation.get("selection_horizon_months", 24))
             and execution["exit_code"] == 0 and execution["engine_threads"] == THREAD_ENV
             and execution["kernel_sha256"] == sha256_bytes(entries["f4_metrics.R"])
             and canonical_json_bytes(strict_json_bytes(entries["stdout.txt"])["results"]) == canonical_json_bytes(native_rows),
             "F5_A12_FIRST_NATIVE_METRICS_MISMATCH")


def _a12_primary_point_origin(
    handoff: Mapping[str, Any], response_csv: bytes, point: Mapping[str, Any], native: Path | bytes,
    *, admit_io=None,
) -> dict[str, Any]:
    """Read the original seven PRIMARY jobs, retaining their original labels."""
    from . import nested_loco as nested
    scope_options = _a12_evaluation_scope(handoff)
    science, horizon = scope_options["science_decision"], scope_options["selection_horizon_months"]
    value = nested._validate_seal(point, {"schema_version", "kind", "status", "selected_ooc_sha256",
        "heldout_response_sha256", "outcome_join_location", "evaluation", "full_data_final_model_external_validation"}
        | {"selection_horizon_months", "science_decision_sha256"},
        "F5_A12_PRIMARY_POINT_SOURCE_INVALID")
    _require(value["schema_version"] == nested.SCHEMA_VERSION
             and value["kind"] == "PADML_NESTED_LOCO_SELECTED_POLICY_EVALUATION_V1"
             and value["status"] == "COMPUTED_NOT_EXTERNAL_VALIDATION_OF_FULL_DATA_MODEL"
             and value["selected_ooc_sha256"] == handoff["primary_ooc_sha256"]
             and value["selection_horizon_months"] == horizon
             and value["science_decision_sha256"] == science["identity_sha256"]
             and value["heldout_response_sha256"] == sha256_bytes(response_csv)
             and value["outcome_join_location"] == "WHOLE_UNIT_ORIGINAL_F4_F5_EVALUATION"
             and value["full_data_final_model_external_validation"] is False,
             "F5_A12_PRIMARY_POINT_SOURCE_INVALID")
    selected = {name: handoff[name] for name in ("patient_ids", "centers", "horizons")}
    selected["survival"] = {"NESTED_SELECTED_POLICY": handoff["survival"]["PRIMARY"]}
    _validate_a12_native_evaluation(value["evaluation"], selected, response_csv,
        native_archive=native, point_branch_scope="PRIMARY_ORIGIN", admit_io=admit_io, **scope_options)
    return value["evaluation"]


def _merge_a12_point_evaluations(primary: Mapping[str, Any], aar: Mapping[str, Any], *, estimability=None) -> dict[str, Any]:
    """Merge separately native-verified values; never rewrite an R archive/label."""
    from .nested_loco import AAR_ESTIMANDS
    branches = AAR_ESTIMANDS[:2] if _a12_aggregate_estimability(estimability) else AAR_ESTIMANDS
    primary_fields = {key: value for key, value in primary.items() if key not in {"scopes", "macro"}}
    _require(primary_fields == {key: value for key, value in aar.items() if key not in {"scopes", "macro"}}
             and set(primary["macro"]) == {"NESTED_SELECTED_POLICY"} and set(aar["macro"]) == set(branches)
             and len(primary["scopes"]) == len(aar["scopes"]) == 7,
             "F5_A12_POINT_SOURCE_SCOPE_MISMATCH")
    scopes = []
    for original, ablated in zip(primary["scopes"], aar["scopes"], strict=True):
        common = {key: value for key, value in original.items() if key != "families"}
        _require(common == {key: value for key, value in ablated.items() if key != "families"}
                 and set(original["families"]) == {"NESTED_SELECTED_POLICY"}
                 and set(ablated["families"]) == set(branches), "F5_A12_POINT_SOURCE_SCOPE_MISMATCH")
        scopes.append({**common, "families": {"PRIMARY": original["families"]["NESTED_SELECTED_POLICY"],
            **{branch: ablated["families"][branch] for branch in branches}}})
    return {**primary_fields, "scopes": scopes, "macro": {"PRIMARY": primary["macro"]["NESTED_SELECTED_POLICY"],
        **{branch: aar["macro"][branch] for branch in branches}}}


def _a12_bootstrap_binding(handoff: Mapping[str, Any], response_csv: bytes, plan: Mapping[str, Any]) -> dict:
    package = Path(__file__).parent
    return {"handoff_sha256": sha256_bytes(canonical_json_bytes(dict(handoff))), "response_sha256": sha256_bytes(response_csv),
            "producer_sha256": sha256_file(Path(__file__)), "evaluation_module_sha256": sha256_file(package / "f4.py"),
            "metric_engine_sha256": sha256_file(package / "kernels/f4_metrics.R"),
            "plan": {key: value for key, value in plan.items() if key != "draws"}}


def _a12_compatible_binding(original, current):
    """Preserve original producers; qualify one exact source tuple, never mixed files."""
    keys = ("producer_sha256", "evaluation_module_sha256", "metric_engine_sha256")
    if original == current:
        return True
    if (not isinstance(original, Mapping) or set(original) != set(current)
            or {k: v for k, v in original.items() if k not in keys}
                != {k: v for k, v in current.items() if k not in keys}):
        return False
    from .f5 import _f45_score_reuse_authorities
    _, sources = _f45_score_reuse_authorities()
    names = ("padml/f5_sensitivity.py", "padml/f4.py", "padml/kernels/f4_metrics.R")
    admitted = {tuple(source[name] for name in names) for source in sources.values()}
    return tuple(original[k] for k in keys) in admitted and tuple(current[k] for k in keys) in admitted


_A12_NESTED_POINT_MEMBERS = ("point-evaluation.json", "point-native.zip", "primary-point-evaluation.json",
                             "primary-point-native.zip", "aar-point-evaluation.json")


_A12_BOOTSTRAP_INPUT_MEMBERS = {"predictions.json", "response.csv", "plan.json", "rng.zip"}


def _admit_a12_bootstrap_io(*, resource_policy: Mapping[str, Any], scratch_root: Path, memory_bytes: int,
                            memory_limit_bytes: int | None = None) -> None:
    """Use the caller's existing live resource boundary at each nested read."""
    from .runtime import observe_execution_resources, resource_admission
    _require(memory_limit_bytes is None or memory_bytes <= memory_limit_bytes,
             "F5_A12_BOOTSTRAP_READER_MEMORY_ESTIMATE_EXCEEDED")
    resource_admission({**resource_policy, "memory_bytes_per_worker": MIN_WORKER_MEMORY_BYTES,
        "scratch_reserve_bytes": 0,
        "memory_reserve_bytes": resource_policy["memory_reserve_bytes"] + memory_bytes},
        observe_execution_resources(scratch_root), legal_tasks=1)


def _write_a12_bootstrap_inputs(target: Path, point_target: Path, handoff: Mapping[str, Any],
                               response_csv: bytes, root: Path, *,
                               shared_rng_invocations: int,
                               prepared_members: Mapping[str, Path] | None = None,
                               resource_policy: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """Ship only fixed evaluation rows/draws; the point evidence stays on H7."""
    from . import nested_loco as nested
    from .f4 import _f45_source_member_sha256

    _require(type(shared_rng_invocations) is int and shared_rng_invocations in (0, 1),
             "F5_A12_BOOTSTRAP_RNG_EXECUTION_INVALID")
    fixed = {name: handoff[name] for name in ("patient_ids", "patient_keys", "centers", "horizons", "survival")}
    fixed.update(_a12_evaluation_scope(handoff))
    fixed.update(_a12_evaluation_estimability(handoff))
    branches = _a12_prediction_branches(fixed["survival"])
    _require(branches[0] == "PRIMARY" and (len(branches) == 3) is ("estimability" in fixed),
             "F5_A12_NONESTIMABLE_BRANCH_INVALID")
    (root / "predictions.json").write_bytes(canonical_json_bytes(fixed))
    (root / "response.csv").write_bytes(response_csv)
    point_members = {name: root / name for name in _A12_NESTED_POINT_MEMBERS}
    if prepared_members is not None:
        from .runtime import observe_execution_resources, resource_admission
        _require("preparation-sources.json" in prepared_members
                 and not set(point_members).intersection(prepared_members), "F5_A12_PREPARATION_MEMBERS_INVALID")
        point_members.update(prepared_members)
        pending = sum(path.stat().st_size for path in point_members.values()) + 4096 * (len(point_members) + 1)
        observation = observe_execution_resources(root)
        resource_admission({**resource_policy, "memory_bytes_per_worker": MIN_WORKER_MEMORY_BYTES,
            "scratch_reserve_bytes": 0}, observation, legal_tasks=1)
        _require(observation["scratch_available_bytes"] >= pending, "F5_A12_PREPARATION_SPACE_INSUFFICIENT")
    write_deterministic_zip(point_target, point_members,
        stored_members={name for name in point_members if name.endswith(".zip")})
    members = {name: {"sha256": sha256_file(root / name), "size_bytes": (root / name).stat().st_size}
               for name in sorted(_A12_BOOTSTRAP_INPUT_MEMBERS)}
    value = nested._sealed({"kind": "PADML_F5_A12_FIXED_BOOTSTRAP_INPUT_V1",
        "f45_source_sha256": sha256_bytes(canonical_json_bytes(_f45_source_member_sha256())),
        "science_decision": handoff["science_decision"], "primary_ooc_sha256": handoff["primary_ooc_sha256"],
        "point_archive": {"sha256": sha256_file(point_target), "size_bytes": point_target.stat().st_size},
        **({"preparation_sources_sha256": sha256_file(prepared_members["preparation-sources.json"])}
           if prepared_members is not None else {}),
        "members": members})
    write_deterministic_zip(target, {"bootstrap-input.json": canonical_json_bytes(value),
        **{name: root / name for name in members}}, stored_members={"rng.zip"})
    return {"status": "PREPARED_FIXED_PREDICTIONS_AND_SHARED_DRAWS", "stage_acceptance": False,
        "sha256": sha256_file(target), "size_bytes": target.stat().st_size,
        "f45_source_sha256": value["f45_source_sha256"],
        **({"preparation_sources_sha256": value["preparation_sources_sha256"]} if prepared_members is not None else {}),
        "point_archive": {"path": str(point_target), **value["point_archive"]},
        "rng_archive": members["rng.zip"],
        "bootstrap_replicates_executed": 0, "new_model_fits": 0, "new_aar_point_metric_jobs": 7 * (len(branches) - 1),
        "reused_primary_point_metric_jobs": 7, "shared_rng_invocations": shared_rng_invocations}


def _a12_prepared_input_record(record: Mapping[str, Any] | None, source: Path, *, point: bool = False) -> None:
    """The caller supplies the original prepare return, not a packet self-proof."""
    from .f4 import _f45_source_member_sha256
    _require(isinstance(record, Mapping)
             and record.get("status") == "PREPARED_FIXED_PREDICTIONS_AND_SHARED_DRAWS"
             and record.get("f45_source_sha256") == sha256_bytes(canonical_json_bytes(_f45_source_member_sha256()))
             and type(record.get("shared_rng_invocations")) is int and record["shared_rng_invocations"] in (0, 1)
             and all(type(record.get(name)) is int and record[name] == 0
                     for name in ("new_model_fits", "bootstrap_replicates_executed")),
             "F5_A12_INDEPENDENT_PREPARATION_RECORD_REQUIRED")
    expected = record.get("point_archive") if point else record
    _require(isinstance(expected, Mapping) and type(expected.get("size_bytes")) is int and expected["size_bytes"] > 0
             and isinstance(source, Path) and source.is_absolute() and source.is_file() and not source.is_symlink()
             and source.stat().st_size == expected["size_bytes"] and sha256_file(source) == expected.get("sha256"),
             "F5_A12_PREPARED_INPUT_BYTES_CHANGED")


def _capture_a12_prepared_outer(value, jobs, record, *, root, captured, resource_policy):
    """Keep the actual owner-verified inputs, after predictions and ledger agree."""
    from .runtime import observe_execution_resources, resource_admission
    outer = value["outer_fold"]
    count = 20 * len(_a12_estimable_branches(value)) if "estimability" in value else 60
    _require(outer not in captured["records"] and len(jobs) == count
             and record.get("estimability") == value.get("estimability"),
             "F5_A12_PREPARATION_COORDINATES_INVALID")
    pending = len(canonical_json_bytes(value)) + sum(sum(map(len, job["entries"].values()))
        + job["numbers_path"].stat().st_size + 4096 * 6 for job in jobs)
    observation = observe_execution_resources(root)
    resource_admission({**resource_policy, "memory_bytes_per_worker": MIN_WORKER_MEMORY_BYTES,
        "scratch_reserve_bytes": 0,
        "memory_reserve_bytes": resource_policy["memory_reserve_bytes"] + 4 * 1024**2},
        observation, legal_tasks=1)
    _require(observation["scratch_available_bytes"] >= pending, "F5_A12_PREPARATION_SPACE_INSUFFICIENT")
    prefix = f"prepared/aar/outer-{outer}"
    destination = root / prefix
    destination.mkdir(mode=0o700, parents=True)
    index_path = destination / "a12-outer.json"
    index_path.write_bytes(canonical_json_bytes(value))
    captured["members"][f"{prefix}/a12-outer.json"] = index_path
    for job in jobs:
        name = job["name"]
        inputs, numbers = destination / f"{name}.inputs.zip", destination / f"{name}.numbers.json"
        write_deterministic_zip(inputs, job["entries"])
        shutil.copyfile(job["numbers_path"], numbers)
        _require({"sha256": sha256_file(numbers), "size_bytes": numbers.stat().st_size}
                 == value["members"][f"fits/{name}.numbers.json"], "F5_A12_PREPARATION_MEMBER_DRIFT")
        input_member, numbers_member = f"{prefix}/{inputs.name}", f"{prefix}/{numbers.name}"
        captured["members"].update({input_member: inputs, numbers_member: numbers})
        captured["jobs"].append({"outer_fold": outer, "name": name,
            "input_member": input_member, "numbers_member": numbers_member,
            "native_archive": job["native_archive"], "retained_bytes_per_component": job["retained_bytes_per_component"]})
    captured["records"][outer] = record


def _a12_prepare_sources(context, root, captured, resource_policy):
    """Seal the existing preparation source index before either public ZIP."""
    from . import nested_loco as nested
    from .runtime import observe_execution_resources, resource_admission
    unavailable = 0
    for record in captured["records"].values():
        if "estimability" in record:
            _require(set(record["estimability"]) == {nested.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT},
                     "F5_A12_NONESTIMABLE_BRANCH_INVALID")
            proof = _a12_validate_nonestimable_branch(record["estimability"][nested.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT])
            _require(proof["outer_fold"] == record["outer_fold"], "F5_A12_NONESTIMABLE_BRANCH_INVALID")
            unavailable += 1
    _require(set(captured["records"]) == set(range(1, 7)) and len(captured["jobs"]) == 360 - 20 * unavailable,
             "F5_A12_PREPARATION_COORDINATES_INVALID")
    members = captured["members"]
    for outer in range(1, 7):
        original = root / f"primary-replay/native-replay/outer-{outer}/archive"
        request_path = original / "request/o-fit-input.json"
        resource_admission({**resource_policy, "memory_bytes_per_worker": MIN_WORKER_MEMORY_BYTES,
            "scratch_reserve_bytes": 0,
            "memory_reserve_bytes": resource_policy["memory_reserve_bytes"] + 32 * request_path.stat().st_size},
            observe_execution_resources(root), legal_tasks=1)
        request = strict_json_bytes(request_path.read_bytes())
        family = context["family_by_outer"][str(outer)]
        templates = [row for row in request["post_lock_templates"] if row["family"] == family]
        _require([row["imputation"] for row in templates] == list(range(1, 21)),
                 "F5_A12_PREPARATION_COORDINATES_INVALID")
        prefix = f"prepared/primary/outer-{outer}"
        members.update({f"{prefix}/{name}": original / name for name in
            ("o-fit-execution.json", "development-lock.json", "final-numbers.zip", "request/o-fit-input.json")})
        members.update({f"{prefix}/request/{row['path']}": original / "request" / row["path"] for row in templates})
    response = root / "prepared/response.csv"
    response.write_bytes(context["evaluation_response_csv"])
    members["prepared/response.csv"] = response
    _require(all(path.is_file() and not path.is_symlink() and path.resolve(strict=True) == path
                 for path in members.values()), "F5_A12_PREPARATION_MEMBERS_INVALID")
    jobs = sorted(captured["jobs"], key=lambda row: (row["outer_fold"],
        nested.AAR_ESTIMANDS.index(row["name"].split("_", 1)[1].rsplit("_M", 1)[0]), int(row["name"].rsplit("_M", 1)[1])))
    value = {"source": context["source"], "source_archives": [captured["records"][outer] for outer in range(1, 7)],
        "context": {name: context[name] for name in ("primary", "population_registry", "science_decision", "family_by_outer")},
        "aar_jobs": jobs, "members": {name: {"sha256": sha256_file(path), "size_bytes": path.stat().st_size}
                                    for name, path in sorted(members.items())}}
    source_path = root / "preparation-sources.json"
    source_path.write_bytes(canonical_json_bytes(value))
    return {**members, "preparation-sources.json": source_path}


def _read_a12_prepared_numerical_job(job):
    """One flat numerical leaf: an original primary M20 or one original AAR MI."""
    from . import nested_loco as nested
    from .f4_compact import read_o_fit_final_numbers
    for path, expected in job["files"].items():
        _require(path.is_file() and not path.is_symlink() and path.resolve(strict=True) == path
                 and path.stat().st_size == expected["size_bytes"] and sha256_file(path) == expected["sha256"],
                 "F5_A12_PREPARATION_MEMBER_DRIFT")
    if job["kind"] == "primary":
        root = job["root"]
        values = []
        for name in ("request/o-fit-input.json", "development-lock.json", "o-fit-execution.json"):
            raw = (root / name).read_bytes()
            value = strict_json_bytes(raw)
            _require(canonical_json_bytes(value) == raw
                     and value["identity_sha256"] == nested._sha({key: item for key, item in value.items()
                                                                    if key != "identity_sha256"}),
                     "F5_A12_PREPARATION_MEMBER_DRIFT")
            values.append(value)
        request, lock, execution = values
        _require(request["training_context"]["outer_fold"] == execution["outer_fold"] == job["outer_fold"]
                 and execution["input_identity_sha256"] == request["identity_sha256"]
                 and execution["development_lock"] == lock,
                 "F5_A12_PREPARATION_COORDINATES_INVALID")
        rebuilt = read_o_fit_final_numbers(root / "final-numbers.zip", request=request, request_root=root / "request",
            lock=lock, native_members=execution["native_members"],
            **({"retained_primary_source_bundle": job["retained_primary_source_bundle"]}
               if job.get("retained_primary_source_bundle") is not None else {}))
        _require(all(rebuilt[name] == execution[name] for name in ("development_lock", "selected_prediction", "component_receipts")),
                 "F5_A12_PREPARATION_PREDICTION_DRIFT")
        return {"kind": "primary", "outer_fold": job["outer_fold"], "selected_prediction": rebuilt["selected_prediction"]}
    _require(job["kind"] == "aar", "F5_A12_PREPARATION_COORDINATES_INVALID")
    entries = read_safe_zip(job["input"], expected_members={"task.json", "recipe.json", "fit-covariates.csv",
        "fit-response.csv", "prediction-covariates.csv"}, max_member_bytes=job["input_expanded_bytes"],
        max_total_bytes=job["input_expanded_bytes"])
    prediction = _replay_ablation_component({"entries": entries, "numbers_path": job["numbers"],
        "native_archive": job["native_archive"], "retained_bytes_per_component": job["retained_bytes_per_component"]})
    task = strict_json_bytes(entries["task.json"])
    coordinates = task["a12_coordinates"]
    _require(coordinates["outer_fold"] == job["outer_fold"] and job["name"]
             == f"O{coordinates['outer_fold']}_{coordinates['branch']}_M{coordinates['imputation']:02d}",
             "F5_A12_PREPARATION_COORDINATES_INVALID")
    return {"kind": "aar", "outer_fold": job["outer_fold"], "task": task, "prediction": prediction}


def _read_a12_prepared_sources(source, root, *, prepared_input_record, resource_policy,
                               retained_primary_source_bundle: Path | None = None):
    """Consume only first-preparation bytes, with substantive M20 reads and one pool."""
    from . import nested_loco as nested
    from .bundle import _admit_zip_directory, _validated_zip_infos
    from .f4 import O_FIT_COMPONENT_BYTES, _f45_source_member_sha256
    from .runtime import observe_execution_resources, resource_admission, validate_resource_policy
    policy = validate_resource_policy(resource_policy)
    _a12_prepared_input_record(prepared_input_record, source, point=True)
    _require(isinstance(prepared_input_record.get("preparation_sources_sha256"), str),
             "F5_A12_INDEPENDENT_PREPARATION_RECORD_REQUIRED")
    admit_io = partial(_admit_a12_bootstrap_io, resource_policy=policy, scratch_root=root.parent)
    _admit_zip_directory(source, admit_io)
    with open_carrier(source) as archive:
        info = archive.getinfo("preparation-sources.json")
        _require(0 < info.file_size <= 32 * 1024**2, "F5_A12_PREPARATION_INDEX_TOO_LARGE")
        admit_io(memory_bytes=32 * info.file_size + 4 * 1024**2)
        raw = archive.read(info)
    value = strict_json_bytes(raw)
    _require(canonical_json_bytes(value) == raw and set(value) == {"source", "source_archives", "context", "aar_jobs", "members"}
             and sha256_bytes(raw) == prepared_input_record["preparation_sources_sha256"]
             and isinstance(value["members"], Mapping) and value["members"]
             and all(isinstance(row, Mapping) and set(row) == {"sha256", "size_bytes"}
                     and type(row["size_bytes"]) is int and row["size_bytes"] > 0 for row in value["members"].values()),
             "F5_A12_PREPARATION_MEMBERS_INVALID")
    names = {*value["members"], "preparation-sources.json", *_A12_NESTED_POINT_MEMBERS}
    _require(len(names) == len(value["members"]) + 6, "F5_A12_PREPARATION_MEMBERS_INVALID")
    material_bytes = sum(row["size_bytes"] for row in value["members"].values())
    opened = _extract_a12_bootstrap_archive(source, root, {**policy,
        "memory_reserve_bytes": policy["memory_reserve_bytes"] + 32 * len(raw)}, members=names,
        max_member_bytes=max(512 * 1024**2, max(row["size_bytes"] for row in value["members"].values())),
        max_total_bytes=material_bytes + len(raw) + 5 * 512 * 1024**2,
        decoded_members={"preparation-sources.json", "prepared/response.csv", "primary-point-evaluation.json"})
    _require(value["members"] == {name: {field: opened["members"][name][field] for field in ("sha256", "size_bytes")}
                                   for name in value["members"]}, "F5_A12_PREPARATION_MEMBER_DRIFT")
    _a12_prepared_input_record(prepared_input_record, source, point=True)
    expected_names = {"prepared/response.csv"}
    jobs, outers = [], []
    coordinator = 32 * (len(raw) + value["members"]["prepared/response.csv"]["size_bytes"]
        + opened["members"]["primary-point-evaluation.json"]["size_bytes"]) + 4 * 1024**2
    maximum_worker = 0
    for outer in range(1, 7):
        prefix = f"prepared/primary/outer-{outer}"
        primary_names = {name for name in value["members"] if name.startswith(prefix + "/")}
        headers = {f"{prefix}/{name}" for name in ("request/o-fit-input.json", "development-lock.json", "o-fit-execution.json")}
        request_path = root / prefix / "request/o-fit-input.json"
        admit_io(memory_bytes=coordinator + 32 * request_path.stat().st_size)
        request = strict_json_bytes(request_path.read_bytes())
        templates = [row for row in request["post_lock_templates"]
                     if row["family"] == value["context"]["family_by_outer"][str(outer)]]
        _require([row["imputation"] for row in templates] == list(range(1, 21))
                 and primary_names == headers | {f"{prefix}/final-numbers.zip"}
                     | {f"{prefix}/request/{row['path']}" for row in templates},
                 "F5_A12_PREPARATION_COORDINATES_INVALID")
        expected_names.update(primary_names)
        expanded = {}
        for name in primary_names - headers:
            _admit_zip_directory(root / name, lambda *, memory_bytes: admit_io(memory_bytes=coordinator + memory_bytes))
            with open_carrier(root / name) as archive:
                bound = (min(request["shared_storage_bytes"], O_FIT_COMPONENT_BYTES)
                         if name.endswith("final-numbers.zip") else request["expanded_bytes_per_component"])
                infos = _validated_zip_infos(archive, None, max_member_bytes=bound, max_total_bytes=bound,
                    max_compression_ratio=1000)
                expanded[name] = sum(info.file_size for info in infos)
        final_bytes = expanded[f"{prefix}/final-numbers.zip"]
        maximum_worker = max(maximum_worker, 32 * (sum(value["members"][name]["size_bytes"] for name in headers)
            + final_bytes + max(expanded.values())) + 4 * 1024**2)
        coordinator += 32 * final_bytes
        jobs.append({"kind": "primary", "outer_fold": outer, "root": root / prefix,
            "files": {root / name: value["members"][name] for name in primary_names},
            **({"retained_primary_source_bundle": retained_primary_source_bundle}
               if retained_primary_source_bundle is not None else {})})
        outer_name = f"prepared/aar/outer-{outer}/a12-outer.json"
        expected_names.add(outer_name)
        coordinator += 32 * value["members"][outer_name]["size_bytes"]
        admit_io(memory_bytes=coordinator)
        outer_raw = (root / outer_name).read_bytes()
        row = strict_json_bytes(outer_raw)
        _require(canonical_json_bytes(row) == outer_raw and row["outer_fold"] == outer
                 and row["identity_sha256"] == nested._sha({key: item for key, item in row.items() if key != "identity_sha256"})
                 and value["source_archives"][outer - 1]["outer_fold"] == outer
                 and value["source_archives"][outer - 1]["identity_sha256"] == row["identity_sha256"],
                 "F5_A12_PREPARATION_MEMBER_DRIFT")
        outers.append(row)
    expected_coordinates = [f"O{outer}_{branch}_M{imp:02d}" for outer in range(1, 7)
                            for branch in _a12_estimable_branches(outers[outer - 1]) for imp in range(1, 21)]
    _require([row["name"] for row in value["aar_jobs"]] == expected_coordinates,
             "F5_A12_PREPARATION_COORDINATES_INVALID")
    for item in value["aar_jobs"]:
        outer, name = item["outer_fold"], item["name"]
        _require(type(outer) is int and outer in range(1, 7)
                 and item["input_member"] == f"prepared/aar/outer-{outer}/{name}.inputs.zip"
                 and item["numbers_member"] == f"prepared/aar/outer-{outer}/{name}.numbers.json"
                 and item["input_member"] in value["members"] and item["numbers_member"] in value["members"]
                 and item["native_archive"] == outers[outer - 1]["native_members"][f"fits/{name}.zip"]
                 and value["members"][item["numbers_member"]] == outers[outer - 1]["members"][f"fits/{name}.numbers.json"]
                 and type(item["retained_bytes_per_component"]) is int and item["retained_bytes_per_component"] > 0,
                 "F5_A12_PREPARATION_COORDINATES_INVALID")
        inputs, numbers = root / item["input_member"], root / item["numbers_member"]
        expected_names.update({item["input_member"], item["numbers_member"]})
        _admit_zip_directory(inputs, lambda *, memory_bytes: admit_io(memory_bytes=coordinator + memory_bytes))
        with open_carrier(inputs) as archive:
            infos = _validated_zip_infos(archive, {"task.json", "recipe.json", "fit-covariates.csv",
                "fit-response.csv", "prediction-covariates.csv"}, max_member_bytes=item["retained_bytes_per_component"],
                max_total_bytes=item["retained_bytes_per_component"], max_compression_ratio=1000)
            expanded = sum(info.file_size for info in infos)
            task_bytes = archive.getinfo("task.json").file_size
        numbers_bytes = value["members"][item["numbers_member"]]["size_bytes"]
        coordinator += 32 * (task_bytes + numbers_bytes)
        maximum_worker = max(maximum_worker, 32 * (expanded + numbers_bytes) + 4 * 1024**2)
        jobs.append({**item, "kind": "aar", "input": inputs, "numbers": numbers,
            "input_expanded_bytes": expanded,
            "files": {root / name: value["members"][name] for name in (item["input_member"], item["numbers_member"])}})
    _require(expected_names == set(value["members"]), "F5_A12_PREPARATION_MEMBERS_INVALID")
    reservation = {"kind": "OPERATIONAL_ESTIMATE_NOT_MEASURED_PEAK", "coordinator_memory_estimate_bytes": coordinator,
        "worker_memory_estimate_bytes": maximum_worker, "future_retention_reserved_bytes": 64 * 1024,
        "primary_m20_reader_count": 6, "aar_mi_reader_count": len(expected_coordinates)}
    effective = _a12_bootstrap_reader_policy(policy, reservation, execution_worker_memory_bytes=MIN_WORKER_MEMORY_BYTES,
        execution_scratch_reserve_bytes=0)
    observation = observe_execution_resources(root)
    admission = resource_admission(effective, observation, legal_tasks=len(jobs))
    execution = {"resource_policy": policy, "resource_reservation": reservation, "effective_policy": effective,
        "resource_observation": observation, "resource_admission": admission, "pool": {},
        "execution_scratch_reserve_bytes": 0,
        "execution_worker_memory_bytes": MIN_WORKER_MEMORY_BYTES,
        "executor_source_identity": sha256_bytes(canonical_json_bytes(_f45_source_member_sha256()))}
    try:
        rows = _bounded_ordered_spawn(_read_a12_prepared_numerical_job, jobs,
            selected_slots=admission["admitted_worker_ceiling"], execution_report=execution["pool"])
        primary = nested.assemble_selected_ooc([row["selected_prediction"] for row in rows[:6]],
            population_registry=value["context"]["population_registry"])
        _require(primary == value["context"]["primary"], "F5_A12_PREPARATION_PREDICTION_DRIFT")
        cursor = 6
        for outer in range(1, 7):
            count = 20 * len(_a12_estimable_branches(outers[outer - 1]))
            batch = rows[cursor:cursor + count]
            cursor += count
            predictions = _a12_outer_predictions(outers[outer - 1],
                [{"entries": {"task.json": canonical_json_bytes(row["task"])}} for row in batch],
                [row["prediction"] for row in batch])
            _require(predictions == outers[outer - 1]["predictions"], "F5_A12_PREPARATION_PREDICTION_DRIFT")
        context = {**value["context"], "source": value["source"],
            "prepared_numerical_sources": True,
            "evaluation_response_csv": (root / "prepared/response.csv").read_bytes(),
            "primary_point": strict_json_bytes((root / "primary-point-evaluation.json").read_bytes()),
            "primary_point_native": root / "primary-point-native.zip"}
        handoff = _a12_handoff_from_outers(context, outers)
    finally:
        execution_raw = canonical_json_bytes(execution)
        _require(len(execution_raw) <= reservation["future_retention_reserved_bytes"], "F5_A12_PREPARATION_REPORT_TOO_LARGE")
        (root / "execution.json").write_bytes(execution_raw)
    return {"context": context, "outers": outers, "source_archives": value["source_archives"], "execution": execution,
        "handoff": handoff,
        "points": {"root": root, "members": {name: opened["members"][name] for name in _A12_NESTED_POINT_MEMBERS},
                   "sha256": prepared_input_record["point_archive"]["sha256"]}}


def _extract_a12_bootstrap_archive(source: Path, root: Path, policy: Mapping[str, Any], *,
                                   members: set[str], max_member_bytes: int, max_total_bytes: int,
                                   decoded_members: set[str] | None = None) -> dict:
    """Bound this retained evaluation archive before directory decode or expansion."""
    from .bundle import _admit_zip_directory, _validated_zip_infos
    from .runtime import observe_execution_resources, resource_admission, validate_resource_policy

    policy = validate_resource_policy(policy)
    _require(source.is_absolute() and source.is_file() and not source.is_symlink()
             and root.is_absolute() and root.parent.is_dir() and root.parent.resolve(strict=True) == root.parent
             and not root.exists() and not root.is_symlink(), "F5_A12_BOOTSTRAP_ARCHIVE_PATH_INVALID")
    admit_io = partial(_admit_a12_bootstrap_io, resource_policy=policy, scratch_root=root.parent)
    _admit_zip_directory(source, admit_io=admit_io)
    with open_carrier(source) as archive:
        infos = _validated_zip_infos(archive, members, max_member_bytes=max_member_bytes,
            max_total_bytes=max_total_bytes, max_compression_ratio=1000)
        expanded = sum(info.file_size for info in infos)
        decoded = sum(info.file_size for info in infos if decoded_members is None or info.filename in decoded_members)
    observation = observe_execution_resources(root.parent)
    effective = {**policy, "memory_bytes_per_worker": MIN_WORKER_MEMORY_BYTES,
        "scratch_reserve_bytes": 0,
        "memory_reserve_bytes": policy["memory_reserve_bytes"] + 32 * decoded}
    admission = resource_admission(effective, observation, legal_tasks=1)
    _require(observation["scratch_available_bytes"] >= expanded,
             "F5_A12_BOOTSTRAP_ARCHIVE_SPACE_INSUFFICIENT")
    records = extract_safe_zip(source, root, expected_members=members,
        max_member_bytes=max_member_bytes, max_total_bytes=max_total_bytes, max_compression_ratio=1000,
        durable=False)
    return {"members": records, "resource_policy": policy, "effective_policy": effective,
        "resource_observation": observation, "resource_admission": admission}


def _load_a12_bootstrap_inputs(source: Path, root: Path, policy: Mapping[str, Any], *,
                               prepared_input_record: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """Read the one original RNG archive; never create draws on a shard."""
    from . import nested_loco as nested
    from .f4 import _f45_source_member_sha256

    _a12_prepared_input_record(prepared_input_record, source)
    opened = _extract_a12_bootstrap_archive(source, root, policy,
        members={"bootstrap-input.json", *_A12_BOOTSTRAP_INPUT_MEMBERS},
        max_member_bytes=1024**3, max_total_bytes=2 * 1024**3)
    raw = (root / "bootstrap-input.json").read_bytes()
    declared = strict_json_bytes(raw)
    value = nested._validate_seal(declared, {"kind", "f45_source_sha256", "science_decision",
        "primary_ooc_sha256", "point_archive", "members"}
        | ({"preparation_sources_sha256"} if "preparation_sources_sha256" in declared else set()),
        "F5_A12_BOOTSTRAP_INPUT_INVALID")
    science = nested.validate_science_decision(value["science_decision"])
    _require(raw == canonical_json_bytes(value) and value["kind"] == "PADML_F5_A12_FIXED_BOOTSTRAP_INPUT_V1"
             and value["f45_source_sha256"] == sha256_bytes(canonical_json_bytes(_f45_source_member_sha256()))
             and science["bootstrap"] == nested.fixed_prediction_bootstrap_contract()
             and value["members"] == {name: {field: opened["members"][name][field]
                 for field in ("sha256", "size_bytes")} for name in _A12_BOOTSTRAP_INPUT_MEMBERS}
             and set(value["point_archive"]) == {"sha256", "size_bytes"}
             and type(value["point_archive"]["size_bytes"]) is int and value["point_archive"]["size_bytes"] > 0,
             "F5_A12_BOOTSTRAP_INPUT_INVALID")
    _require(value["point_archive"] == {name: prepared_input_record["point_archive"][name]
                 for name in ("sha256", "size_bytes")}
             and value["members"]["rng.zip"] == prepared_input_record.get("rng_archive")
             and value.get("preparation_sources_sha256") == prepared_input_record.get("preparation_sources_sha256"),
             "F5_A12_PREPARED_INPUT_BYTES_CHANGED")
    validate_sha256(value["primary_ooc_sha256"], "a12.bootstrap.primary_ooc")
    validate_sha256(value["point_archive"]["sha256"], "a12.bootstrap.point_archive")
    fixed_raw = (root / "predictions.json").read_bytes()
    fixed = strict_json_bytes(fixed_raw)
    scope = _a12_evaluation_scope(fixed)
    estimability = _a12_evaluation_estimability(fixed)
    _require(set(fixed) == {"patient_ids", "patient_keys", "centers", "horizons", "survival"} | set(scope) | set(estimability)
             and (not scope or scope["science_decision"] == science)
             and fixed_raw == canonical_json_bytes(fixed) and fixed["horizons"] == HORIZONS
             and len(fixed["patient_ids"]) == len(fixed["centers"])
             and set(fixed["centers"]) == set(_VALIDATION_CENTERS), "F5_A12_BOOTSTRAP_INPUT_INVALID")
    fixed["patient_keys"] = _patient_key_mapping(fixed["patient_ids"], fixed["patient_keys"])
    branches = _a12_prediction_branches(fixed["survival"])
    _require(branches[0] == "PRIMARY" and (len(branches) == 3) is bool(estimability), "F5_A12_BOOTSTRAP_INPUT_INVALID")
    for branch in branches:
        _seal_prediction_matrix(fixed["patient_ids"], fixed["survival"][branch], HORIZONS)
    # Restore the original branch order after canonical JSON's key sorting.
    fixed["survival"] = {branch: fixed["survival"][branch] for branch in branches}
    response = (root / "response.csv").read_bytes()
    fields, responses = _response_rows(response)
    _require(list(responses) == fixed["patient_ids"]
             and response == _write_response_subset(fields, responses, fixed["patient_ids"], None)["private_bytes"],
             "F5_A12_BOOTSTRAP_RESPONSE_INVALID")
    plan, binding = _replay_a12_bootstrap_plan(root, fixed, response, nested=True,
        admit_io=partial(_admit_a12_bootstrap_io, resource_policy=policy, scratch_root=root))
    return {"manifest": value, "handoff": fixed, "response_csv": response, "plan": plan, "source": binding,
        "input_sha256": sha256_file(source), "input_size_bytes": source.stat().st_size,
        "input_expansion": opened}


def _execute_and_replay_a12_bootstrap_replicate(item: tuple[int, list[int]], *,
        root: Path, evaluation_handoff: Mapping[str, Any], response_csv: bytes,
        source_binding: Mapping[str, Any], retained_bytes_per_replicate: int, admit_io=None) -> dict[str, Any]:
    """One flat worker owns calculation, original ZIP readback and its returned row."""
    _a12_bootstrap_replicate(item, evaluation_handoff=evaluation_handoff, response_csv=response_csv,
        work_root=root, source_binding=source_binding, retained_bytes_per_replicate=retained_bytes_per_replicate,
        admit_io=admit_io)
    row = _replay_a12_bootstrap_replicate(item, root=root, evaluation_handoff=evaluation_handoff,
        response_csv=response_csv, source_binding=source_binding, admit_io=admit_io,
        retained_bytes_per_replicate=retained_bytes_per_replicate)
    path = root / f"replicate-{item[0]:04d}.zip"
    result = {"row": row, "member": path.name, "sha256": sha256_file(path), "size_bytes": path.stat().st_size}
    from .runtime import advise_completed_io
    advise_completed_io([path])
    return result


def _a12_shard_effective_policy(policy: Mapping[str, Any], *, fixed_bytes: int, row_count: int,
                                 retained: int, execution_worker_memory_bytes: int = MIN_WORKER_MEMORY_BYTES,
                                 execution_scratch_reserve_bytes: int | None = None) -> tuple[dict, dict]:
    _require(type(execution_worker_memory_bytes) is int
             and execution_worker_memory_bytes in RECORDED_WORKER_MEMORY_BYTES, "F5_A12_BOOTSTRAP_WORKER_MEMORY_BUDGET_INVALID")
    _require(execution_scratch_reserve_bytes is None or type(execution_scratch_reserve_bytes) is int
             and execution_scratch_reserve_bytes == 0, "F5_A12_BOOTSTRAP_SCRATCH_BUDGET_INVALID")
    reservation = {"kind": "OPERATIONAL_ESTIMATE_NOT_MEASURED_PEAK", "fixed_input_bytes": fixed_bytes,
        "retained_bytes_per_replicate": retained, "metric_retention_reserved_bytes": row_count * retained,
        "coordinator_memory_estimate_bytes": 32 * fixed_bytes + 128 * row_count * ((2 * 4 - 1) * ((12 * len(REPORT_HORIZONS) + 2) + 7 * (10 * len(REPORT_HORIZONS) + 2)))}
    effective = {**policy, "scratch_reserve_bytes": (policy["scratch_reserve_bytes"] + row_count * retained
        if execution_scratch_reserve_bytes is None else execution_scratch_reserve_bytes),
        "memory_reserve_bytes": policy["memory_reserve_bytes"] + reservation["coordinator_memory_estimate_bytes"],
        "memory_bytes_per_worker": execution_worker_memory_bytes}
    return reservation, effective


def execute_a12_bootstrap_shard(source: Path, target: Path, *, replicate_ids: list[int],
                                resource_policy: Mapping[str, Any], retained_bytes_per_replicate: int,
                                prepared_input_record: Mapping[str, Any] | None = None) -> dict:
    """Execute disjoint complete-six-center draws; no point jobs, RNG or local CI."""
    from . import nested_loco as nested
    from .f4 import _f45_source_member_sha256
    from .f5 import _full_score_scratch
    from .runtime import observe_execution_resources, resource_admission, validate_resource_policy

    _a12_replicate_items({"replicate_count": 1000, "draws": [None] * 1000}, replicate_ids)
    policy = validate_resource_policy(resource_policy)
    _require(type(retained_bytes_per_replicate) is int and retained_bytes_per_replicate > 0
             and source.is_absolute() and target.is_absolute() and target.parent == source.parent
             and not target.exists() and not target.is_symlink(), "F5_A12_BOOTSTRAP_SHARD_PATH_INVALID")
    resource_admission({**policy, "memory_bytes_per_worker": MIN_WORKER_MEMORY_BYTES,
        "scratch_reserve_bytes": 0}, observe_execution_resources(target.parent), legal_tasks=1)
    root = target.with_name(target.name + ".work")
    root.mkdir(mode=0o700)
    execution = {}
    try:
        with _full_score_scratch(root):
            loaded = _load_a12_bootstrap_inputs(source, root / "inputs", policy,
                prepared_input_record=prepared_input_record)
            items = _a12_replicate_items(loaded["plan"], replicate_ids)
            ids = [item[0] for item in items]
            fixed = loaded["handoff"]
            handoff = {name: fixed[name] for name in ("patient_ids", "centers", "horizons", "survival")}
            handoff.update(_a12_evaluation_scope(fixed))
            handoff.update(_a12_evaluation_estimability(fixed))
            coordinate_root = source.parent / "bootstrap-replicates"
            if not coordinate_root.exists():
                coordinate_root.mkdir(mode=0o700)
            _require(coordinate_root.is_dir() and not coordinate_root.is_symlink()
                     and coordinate_root.resolve(strict=True) == coordinate_root,
                     "F5_A12_BOOTSTRAP_SHARD_PATH_INVALID")
            for rid in ids:
                for suffix in ("", ".zip"):
                    path = coordinate_root / f"replicate-{rid:04d}{suffix}"
                    _require(not path.exists() and not path.is_symlink(),
                             "F5_A12_BOOTSTRAP_COORDINATE_ALREADY_PRESENT")
            fixed_bytes = len(canonical_json_bytes(handoff)) + len(loaded["response_csv"])
            reservation, effective = _a12_shard_effective_policy(policy, fixed_bytes=fixed_bytes,
                row_count=len(ids), retained=retained_bytes_per_replicate, execution_worker_memory_bytes=MIN_WORKER_MEMORY_BYTES,
                execution_scratch_reserve_bytes=0)
            observation = observe_execution_resources(root)
            admission = resource_admission(effective, observation, legal_tasks=len(ids))
            execution = {"resource_policy": policy, "resource_reservation": reservation, "effective_policy": effective,
                "resource_observation": observation, "resource_admission": admission, "bootstrap_pool": {},
                "executor_source_identity": sha256_bytes(canonical_json_bytes(_f45_source_member_sha256())),
                "execution_worker_memory_bytes": MIN_WORKER_MEMORY_BYTES,
                "execution_scratch_reserve_bytes": 0,
                "assigned_replicate_ids": ids, "completed_replicate_ids": []}
            results = _bounded_ordered_spawn(partial(_execute_and_replay_a12_bootstrap_replicate,
                root=coordinate_root, evaluation_handoff=handoff, response_csv=loaded["response_csv"],
                source_binding=loaded["source"], retained_bytes_per_replicate=retained_bytes_per_replicate,
                admit_io=partial(_admit_a12_bootstrap_io, resource_policy=policy, scratch_root=root)),
                items, selected_slots=admission["admitted_worker_ceiling"], execution_report=execution["bootstrap_pool"])
            _require([item["row"]["replicate"] for item in results] == ids,
                     "F5_A12_BOOTSTRAP_SHARD_COVERAGE_INVALID")
            execution["completed_replicate_ids"] = ids
            value = nested._sealed({"kind": "PADML_F5_A12_FIXED_BOOTSTRAP_SHARD_V1",
                "input_sha256": loaded["input_sha256"], "input_identity_sha256": loaded["manifest"]["identity_sha256"],
                "replicate_ids": ids, "replicate_results": results, "execution": execution,
                "new_rng_invocations": 0, "new_prediction_model_fits": 0, "new_point_metric_jobs": 0,
                "metric_scope_branch_job_count": 7 * len(_a12_prediction_branches(handoff["survival"])) * len(ids), "confidence_interval_reductions": 0})
            write_deterministic_zip(target, {"bootstrap-shard.json": canonical_json_bytes(value),
                **{item["member"]: coordinate_root / item["member"] for item in results}},
                stored_members={item["member"] for item in results})
    except BaseException as exc:
        exc.add_note(f"F5_A12_BOOTSTRAP_SHARD_EVIDENCE_RETAINED:{root}")
        raise
    finally:
        (root / "execution.json").write_bytes(canonical_json_bytes(execution))
    return {"status": "COMPUTED_FIXED_PREDICTION_REPLICATES", "stage_acceptance": False,
        "replicate_ids": ids, "numerically_reopened_replicates": len(ids), "sha256": sha256_file(target),
        "size_bytes": target.stat().st_size, "new_model_fits": 0, "new_rng_invocations": 0}


def _read_a12_bootstrap_shard(source: Path, root: Path, shared: Mapping[str, Any],
                              resource_policy: Mapping[str, Any], *, response_rows: tuple | None = None,
                              read_reservation: Mapping[str, Any] | None = None) -> dict:
    """Bind actual native ZIP/row bytes after the shard's original numerical reader.

    This transport consumer does not substitute a PASS bit for a result row and
    does not repeat the shard's censoring/error calculations or R metric jobs.
    """
    from . import nested_loco as nested
    from .f4 import _f45_source_member_sha256
    from .bundle import _admit_zip_directory, _validated_zip_infos
    from .runtime import resource_admission, validate_resource_policy

    policy = validate_resource_policy(resource_policy)
    if read_reservation is not None:
        _require(set(read_reservation) == {"index_sha256", "io_memory_bytes", "expanded_bytes"}
                 and all(type(read_reservation[name]) is int and read_reservation[name] > 0
                         for name in ("io_memory_bytes", "expanded_bytes")),
                 "F5_A12_BOOTSTRAP_READER_RESERVATION_INVALID")
        validate_sha256(read_reservation["index_sha256"], "a12.bootstrap.reader_index")
    admit_io = partial(_admit_a12_bootstrap_io, resource_policy=policy, scratch_root=root.parent,
        memory_limit_bytes=None if read_reservation is None else read_reservation["io_memory_bytes"])
    _require(source.is_absolute() and source.is_file() and not source.is_symlink(),
             "F5_A12_BOOTSTRAP_SHARD_PATH_INVALID")
    _admit_zip_directory(source, admit_io)
    with open_carrier(source) as archive:
        info = archive.getinfo("bootstrap-shard.json")
        _require(0 < info.file_size <= 64 * 1024**2, "F5_A12_BOOTSTRAP_SHARD_INDEX_TOO_LARGE")
        admit_io(memory_bytes=32 * info.file_size + 4 * 1024**2)
        raw = archive.read(info)
    _require(read_reservation is None or sha256_bytes(raw) == read_reservation["index_sha256"],
             "F5_A12_BOOTSTRAP_READER_INPUT_CHANGED")
    value = nested._validate_seal(strict_json_bytes(raw), {"kind", "input_sha256", "input_identity_sha256",
        "replicate_ids", "replicate_results", "execution", "new_rng_invocations", "new_prediction_model_fits",
        "new_point_metric_jobs", "metric_scope_branch_job_count", "confidence_interval_reductions"},
        "F5_A12_BOOTSTRAP_SHARD_INVALID")
    items = _a12_replicate_items(shared["plan"], value["replicate_ids"])
    ids = [item[0] for item in items]
    _require(raw == canonical_json_bytes(value) and value["kind"] == "PADML_F5_A12_FIXED_BOOTSTRAP_SHARD_V1"
             and value["input_sha256"] == shared["input_sha256"]
             and value["input_identity_sha256"] == shared["manifest"]["identity_sha256"]
             and value["replicate_ids"] == ids and len(value["replicate_results"]) == len(ids)
             and all(type(value[name]) is int and value[name] == 0 for name in
                 ("new_rng_invocations", "new_prediction_model_fits", "new_point_metric_jobs", "confidence_interval_reductions"))
             and value["metric_scope_branch_job_count"] == 7 * len(_a12_prediction_branches(shared["handoff"]["survival"])) * len(ids), "F5_A12_BOOTSTRAP_SHARD_INVALID")
    execution = value["execution"]
    _require(execution.get("executor_source_identity") == sha256_bytes(canonical_json_bytes(_f45_source_member_sha256()))
             and type(execution.get("execution_worker_memory_bytes")) is int
             and execution["execution_worker_memory_bytes"] in RECORDED_WORKER_MEMORY_BYTES,
             "F5_A12_BOOTSTRAP_SHARD_EXECUTION_INVALID")
    original_policy = validate_resource_policy(execution["resource_policy"])
    fixed = {name: shared["handoff"][name] for name in ("patient_ids", "centers", "horizons", "survival")}
    fixed.update(_a12_evaluation_scope(shared["handoff"]))
    fixed.update(_a12_evaluation_estimability(shared["handoff"]))
    fixed_bytes = len(canonical_json_bytes(fixed)) + len(shared["response_csv"])
    retained = execution["resource_reservation"]["retained_bytes_per_replicate"]
    _require(type(retained) is int and retained > 0, "F5_A12_BOOTSTRAP_SHARD_EXECUTION_INVALID")
    reservation, effective = _a12_shard_effective_policy(original_policy, fixed_bytes=fixed_bytes,
        row_count=len(ids), retained=retained,
        execution_worker_memory_bytes=execution["execution_worker_memory_bytes"],
        execution_scratch_reserve_bytes=execution.get("execution_scratch_reserve_bytes"))
    admission = resource_admission(effective, execution["resource_observation"], legal_tasks=len(ids))
    pool = execution["bootstrap_pool"]
    _require(execution["resource_reservation"] == reservation and execution["effective_policy"] == effective
             and execution["resource_admission"] == admission
             and execution["assigned_replicate_ids"] == execution["completed_replicate_ids"] == ids
             and pool["status"] == "COMPLETED" and pool["configured_worker_ceiling"]
                 == execution["resource_observation"]["effective_cpus"] - 8
             and pool["admitted_worker_ceiling"] == admission["admitted_worker_ceiling"]
             and pool["completed_task_count"] == pool["runnable_task_count"] == len(ids)
             and pool["engine_threads"] == 1 and 1 <= pool["actual_worker_process_peak"] <= admission["admitted_worker_ceiling"],
             "F5_A12_BOOTSTRAP_SHARD_EXECUTION_INVALID")
    members = {f"replicate-{rid:04d}.zip" for rid in ids}
    opened = _extract_a12_bootstrap_archive(source, root, policy, members={"bootstrap-shard.json", *members},
        max_member_bytes=max(retained, len(raw)), max_total_bytes=min(len(ids) * retained + len(raw),
            read_reservation["expanded_bytes"] if read_reservation is not None else len(ids) * retained + len(raw)),
        decoded_members={"bootstrap-shard.json"})
    _require((root / "bootstrap-shard.json").read_bytes() == raw, "F5_A12_BOOTSTRAP_SHARD_INVALID")
    if response_rows is None:
        response_rows = _response_rows(shared["response_csv"])
    branches = _a12_prediction_branches(fixed["survival"])
    for (rid, indices), record in zip(items, value["replicate_results"], strict=True):
        name = f"replicate-{rid:04d}.zip"
        _require(set(record) == {"row", "member", "sha256", "size_bytes"} and record["member"] == name
                 and record["size_bytes"] <= retained
                 and {key: record[key] for key in ("sha256", "size_bytes")}
                     == {key: opened["members"][name][key] for key in ("sha256", "size_bytes")}
                 and type(record["row"]["replicate"]) is int and record["row"]["replicate"] == rid,
                 "F5_A12_BOOTSTRAP_SHARD_MEMBER_MISMATCH")
        path = root / name
        _admit_zip_directory(path, admit_io)
        with open_carrier(path) as archive:
            infos = {info.filename: info for info in _validated_zip_infos(archive,
                {"input.json", "evaluation.json", "result.json", "metrics.zip"},
                max_member_bytes=512 * 1024**2, max_total_bytes=1024**3, max_compression_ratio=1000)}
            admit_io(memory_bytes=32 * sum(infos[name].file_size for name in
                ("input.json", "evaluation.json", "result.json")) + 4 * 1024**2)
            _require(archive.read("input.json") == canonical_json_bytes({**shared["source"], "replicate": rid,
                         "draw_indices": indices}) and archive.read("result.json") == canonical_json_bytes(record["row"]),
                     "F5_A12_BOOTSTRAP_SHARD_NATIVE_ROW_MISMATCH")
            evaluation = strict_json_bytes(archive.read("evaluation.json"))
        # H7 consumes the actual retained metric values and original draw receipt;
        # it does not rerun each shard's KM/Brier/DCA or native metric engine.
        _, _, receipt = _resampled_response_receipt(fixed, shared["response_csv"], indices,
            f"A12-PAIRED-{rid:04d}", response_rows=response_rows)
        row = _a12_bootstrap_row(rid, receipt, evaluation, branches=branches)
        _require(canonical_json_bytes(row) == canonical_json_bytes(record["row"]),
                 "F5_A12_RETAINED_REDUCTION_MISMATCH")
    return value


def _read_a12_bootstrap_shard_job(job, *, shared, resource_policy, response_rows):
    """One original transport/numerical reader; never a replicate/native pool."""
    return _read_a12_bootstrap_shard(job["source"], job["root"], shared, resource_policy,
        response_rows=response_rows, read_reservation=job["read_reservation"])


def _a12_bootstrap_reader_policy(policy, reservation, *, execution_worker_memory_bytes=MIN_WORKER_MEMORY_BYTES,
                                execution_scratch_reserve_bytes=None):
    """One host allowance for all six retained trees and parent/worker copies."""
    _require(type(execution_worker_memory_bytes) is int
             and execution_worker_memory_bytes in RECORDED_WORKER_MEMORY_BYTES, "F5_A12_BOOTSTRAP_WORKER_MEMORY_BUDGET_INVALID")
    _require(execution_scratch_reserve_bytes is None or type(execution_scratch_reserve_bytes) is int
             and execution_scratch_reserve_bytes == 0, "F5_A12_BOOTSTRAP_SCRATCH_BUDGET_INVALID")
    return {**policy,
        "memory_bytes_per_worker": execution_worker_memory_bytes,
        "memory_reserve_bytes": policy["memory_reserve_bytes"] + reservation["coordinator_memory_estimate_bytes"],
        "scratch_reserve_bytes": (policy["scratch_reserve_bytes"] + reservation["future_retention_reserved_bytes"]
            if execution_scratch_reserve_bytes is None else execution_scratch_reserve_bytes)}


def replay_a12_bootstrap_shard(source: Path, input_bundle: Path, root: Path, *,
                               resource_policy: Mapping[str, Any],
                               prepared_input_record: Mapping[str, Any] | None = None) -> dict:
    """An explicit original numerical shard consumer; no engine or new draws."""
    from .f5 import _full_score_scratch
    from .runtime import observe_execution_resources, resource_admission, validate_resource_policy

    policy = validate_resource_policy(resource_policy)
    _require(root.is_absolute() and root.parent.is_dir() and not root.exists() and not root.is_symlink(),
             "F5_A12_BOOTSTRAP_SHARD_PATH_INVALID")
    resource_admission({**policy, "memory_bytes_per_worker": MIN_WORKER_MEMORY_BYTES,
        "scratch_reserve_bytes": 0}, observe_execution_resources(root.parent), legal_tasks=1)
    root.mkdir(mode=0o700)
    execution = {}
    try:
        with _full_score_scratch(root):
            shared = _load_a12_bootstrap_inputs(input_bundle, root / "inputs", policy,
                prepared_input_record=prepared_input_record)
            value = _read_a12_bootstrap_shard(source, root / "retained", shared, policy)
            items = _a12_replicate_items(shared["plan"], value["replicate_ids"])
            handoff = {name: shared["handoff"][name] for name in ("patient_ids", "centers", "horizons", "survival")}
            handoff.update(_a12_evaluation_scope(shared["handoff"]))
            handoff.update(_a12_evaluation_estimability(shared["handoff"]))
            fixed_bytes = len(canonical_json_bytes(handoff)) + len(shared["response_csv"])
            _, effective = _a12_shard_effective_policy(policy, fixed_bytes=fixed_bytes,
                row_count=len(items), retained=value["execution"]["resource_reservation"]["retained_bytes_per_replicate"],
                execution_worker_memory_bytes=MIN_WORKER_MEMORY_BYTES, execution_scratch_reserve_bytes=0)
            observation = observe_execution_resources(root)
            admission = resource_admission(effective, observation, legal_tasks=len(items))
            execution = {"resource_policy": policy, "effective_policy": effective, "resource_observation": observation,
                "resource_admission": admission, "bootstrap_pool": {}, "new_rng_invocations": 0, "new_metric_jobs": 0}
            rows = _bounded_ordered_spawn(partial(_replay_a12_bootstrap_replicate, root=root / "retained",
                evaluation_handoff=handoff, response_csv=shared["response_csv"], source_binding=shared["source"],
                admit_io=partial(_admit_a12_bootstrap_io, resource_policy=policy, scratch_root=root)),
                items, selected_slots=admission["admitted_worker_ceiling"], execution_report=execution["bootstrap_pool"])
            _require(canonical_json_bytes(rows) == canonical_json_bytes([record["row"] for record in value["replicate_results"]]),
                     "F5_A12_BOOTSTRAP_SHARD_NATIVE_ROW_MISMATCH")
    except BaseException as exc:
        exc.add_note(f"F5_A12_BOOTSTRAP_SHARD_REPLAY_EVIDENCE_RETAINED:{root}")
        raise
    finally:
        (root / "execution.json").write_bytes(canonical_json_bytes(execution))
    return value


def _collect_a12_bootstrap_shards(root: Path, handoff: Mapping[str, Any], response_csv: bytes, *,
        resource_policy: Mapping[str, Any], retained_primary_point: Mapping[str, Any],
        primary_point_native: Path | bytes,
        original_paths: Mapping[str, Path] | None = None,
        execution_report: dict | None = None,
        prepared_input_record: Mapping[str, Any] | None = None,
        prepared_points: Mapping[str, Any] | None = None) -> tuple[dict, dict, list[dict], dict]:
    """One H7 completeness join of actual input/native-row bytes, not new metrics."""
    from .bundle import _admit_zip_directory
    from .f4 import _f45_source_member_sha256
    from .runtime import observe_execution_resources, resource_admission, validate_resource_policy
    policy = validate_resource_policy(resource_policy)
    names = {"bootstrap-input.zip", "point-sources.zip", *[f"shard-{index}.zip" for index in range(1, 7)]}
    paths = {name: root / name for name in names} if original_paths is None else original_paths
    _require(isinstance(paths, Mapping) and set(paths) == names
             and all(isinstance(path, Path) and path.is_absolute() and path.is_file()
                     and not path.is_symlink() and path.resolve(strict=True) == path for path in paths.values()),
             "F5_A12_BOOTSTRAP_GATHER_PATH_INVALID")
    shared = _load_a12_bootstrap_inputs(paths["bootstrap-input.zip"], root / "shared", resource_policy,
        prepared_input_record=prepared_input_record)
    fixed = {name: handoff[name] for name in ("patient_ids", "patient_keys", "centers", "horizons", "survival")}
    fixed.update(_a12_evaluation_scope(handoff))
    fixed.update(_a12_evaluation_estimability(handoff))
    _require(canonical_json_bytes(shared["handoff"]) == canonical_json_bytes(fixed)
             and shared["response_csv"] == response_csv
             and shared["manifest"]["science_decision"] == handoff["science_decision"]
             and shared["manifest"]["primary_ooc_sha256"] == handoff["primary_ooc_sha256"],
             "F5_A12_BOOTSTRAP_AGGREGATE_INPUT_MISMATCH")
    point_archive = paths["point-sources.zip"]
    point_record = {"sha256": sha256_file(point_archive), "size_bytes": point_archive.stat().st_size}
    _require(point_record == shared["manifest"]["point_archive"], "F5_A12_PRIMARY_POINT_SOURCE_INVALID")
    if prepared_points is None:
        _require("preparation_sources_sha256" not in shared["manifest"], "F5_A12_PREPARED_POINTS_REQUIRED")
        _extract_a12_bootstrap_archive(point_archive, root / "points", resource_policy,
            members=set(_A12_NESTED_POINT_MEMBERS), max_member_bytes=512 * 1024**2, max_total_bytes=1024**3)
        point_root = root / "points"
    else:
        point_root = prepared_points["root"]
        _admit_a12_bootstrap_io(resource_policy=resource_policy, scratch_root=root,
            memory_bytes=32 * sum((point_root / name).stat().st_size for name in _A12_NESTED_POINT_MEMBERS)
                + 4 * 1024**2)
        _require(prepared_points["sha256"] == point_record["sha256"]
                 and sha256_file(point_root / "preparation-sources.json") == shared["manifest"]["preparation_sources_sha256"]
                 and all((point_root / name).is_file() and not (point_root / name).is_symlink()
                     and sha256_file(point_root / name) == prepared_points["members"][name]["sha256"]
                     and (point_root / name).stat().st_size == prepared_points["members"][name]["size_bytes"]
                     for name in _A12_NESTED_POINT_MEMBERS), "F5_A12_PREPARATION_MEMBER_DRIFT")
    point = _replay_a12_point(point_root, handoff, response_csv,
        retained_primary_point=retained_primary_point, primary_point_native=primary_point_native,
        admit_io=partial(_admit_a12_bootstrap_io, resource_policy=resource_policy, scratch_root=root))
    indexed, shards = {}, []
    response_rows = _response_rows(shared["response_csv"])
    # Only this call's original fixed inputs cross spawn, not point archives or
    # prepared source trees. Each process copy is included in the RAM budget.
    reader_shared = {name: shared[name] for name in
        ("manifest", "handoff", "response_csv", "plan", "source", "input_sha256")}
    shared_bytes = len(shared["response_csv"]) + len(canonical_json_bytes({
        name: value for name, value in reader_shared.items() if name != "response_csv"}))
    admit_io = partial(_admit_a12_bootstrap_io, resource_policy=policy, scratch_root=root)
    jobs, index_bytes = [], 0
    for index in range(1, 7):
        source = paths[f"shard-{index}.zip"]
        _admit_zip_directory(source, admit_io)
        with open_carrier(source) as archive:
            info = archive.getinfo("bootstrap-shard.json")
            _require(0 < info.file_size <= 64 * 1024**2, "F5_A12_BOOTSTRAP_SHARD_INDEX_TOO_LARGE")
            admit_io(memory_bytes=32 * info.file_size + 4 * 1024**2)
            raw = archive.read(info)
            expanded = sum(item.file_size for item in archive.infolist())
        declaration = strict_json_bytes(raw)
        retained = declaration["execution"]["resource_reservation"]["retained_bytes_per_replicate"]
        _require(type(retained) is int and retained > 0 and expanded > 0,
                 "F5_A12_BOOTSTRAP_SHARD_EXECUTION_INVALID")
        index_bytes += len(raw)
        jobs.append({"source": source, "root": root / f"shard-{index}", "read_reservation": {
            "index_sha256": sha256_bytes(raw), "io_memory_bytes": 32 * (len(raw) + retained) + 4 * 1024**2,
            "expanded_bytes": expanded}})
        del raw, declaration
    reservation = {"kind": "OPERATIONAL_ESTIMATE_NOT_MEASURED_PEAK", "shared_input_bytes": shared_bytes,
        "future_retention_reserved_bytes": sum(job["read_reservation"]["expanded_bytes"] for job in jobs)
            + 2 * sum(path.stat().st_size for path in paths.values()),
        "coordinator_memory_estimate_bytes": 32 * (shared_bytes + 2 * index_bytes) + 4 * 1024**2,
        "worker_memory_estimate_bytes": 32 * shared_bytes + max(job["read_reservation"]["io_memory_bytes"] for job in jobs),
        "reader_reservations": [job["read_reservation"] for job in jobs]}
    effective = _a12_bootstrap_reader_policy(policy, reservation, execution_worker_memory_bytes=MIN_WORKER_MEMORY_BYTES,
        execution_scratch_reserve_bytes=0)
    observation = observe_execution_resources(root)
    admission = resource_admission(effective, observation, legal_tasks=6)
    report = {} if execution_report is None else execution_report
    report.update(resource_reservation=reservation, effective_policy=effective,
        resource_observation=observation, resource_admission=admission, pool={}, execution_worker_memory_bytes=MIN_WORKER_MEMORY_BYTES,
        execution_scratch_reserve_bytes=0,
        executor_source_identity=sha256_bytes(canonical_json_bytes(_f45_source_member_sha256())))
    values = _bounded_ordered_spawn(partial(_read_a12_bootstrap_shard_job, shared=reader_shared,
        resource_policy=policy, response_rows=response_rows), jobs,
        selected_slots=admission["admitted_worker_ceiling"], execution_report=report["pool"])
    for index, value in enumerate(values, 1):
        name = f"shard-{index}.zip"
        source = paths[name]
        for record in value["replicate_results"]:
            rid = record["row"]["replicate"]
            _require(rid not in indexed, "F5_A12_BOOTSTRAP_COVERAGE_INVALID")
            indexed[rid] = record["row"]
        shards.append({"member": name, "sha256": sha256_file(source), "size_bytes": source.stat().st_size,
            "identity_sha256": value["identity_sha256"], "replicate_ids": value["replicate_ids"],
            "execution": value["execution"]})
    _require(sorted(indexed) == list(range(1, 1001)), "F5_A12_BOOTSTRAP_COVERAGE_INVALID")
    origin = {"bootstrap_input": {"sha256": shared["input_sha256"], "size_bytes": shared["input_size_bytes"],
        "identity_sha256": shared["manifest"]["identity_sha256"]}, "point_archive": point_record, "shards": shards}
    return shared["plan"], point, [indexed[rid] for rid in range(1, 1001)], origin


def _gather_a12_bootstrap_evaluation(predictions: Mapping[str, Any], response_csv: bytes, *,
        evidence_root: Path, bootstrap_input: Path, point_archive: Path, bootstrap_shards: list[Path],
        resource_policy: Mapping[str, Any], retained_primary_point: Mapping[str, Any],
        primary_point_native: Path | bytes,
        prepared_input_record: Mapping[str, Any] | None = None,
        prepared_points: Mapping[str, Any] | None = None) -> dict:
    from .f5 import _full_score_scratch
    from .f4 import _f45_source_member_sha256
    from .runtime import observe_execution_resources, resource_admission, validate_resource_policy

    policy = validate_resource_policy(resource_policy)
    handoff = _validate_a12_handoff(predictions)
    _require(len(bootstrap_shards) == 6 and len({path.resolve() for path in bootstrap_shards}) == 6
             and evidence_root.is_absolute() and evidence_root.parent.is_dir()
             and not evidence_root.exists() and not evidence_root.is_symlink(), "F5_A12_BOOTSTRAP_GATHER_PATH_INVALID")
    paths = {"bootstrap-input.zip": bootstrap_input, "point-sources.zip": point_archive,
             **{f"shard-{index}.zip": path for index, path in enumerate(bootstrap_shards, 1)}}
    _require(all(path.is_absolute() and path.is_file() and not path.is_symlink() for path in paths.values()),
             "F5_A12_BOOTSTRAP_GATHER_PATH_INVALID")
    reserved = 2 * sum(path.stat().st_size for path in paths.values())
    observation = observe_execution_resources(evidence_root.parent)
    admission = resource_admission({**policy, "memory_bytes_per_worker": MIN_WORKER_MEMORY_BYTES,
        "scratch_reserve_bytes": 0},
        observation, legal_tasks=1)
    evidence_root.mkdir(mode=0o700)
    execution = {"kind": "PADML_F5_A12_FIXED_BOOTSTRAP_GATHER_V1", "resource_policy": policy,
        "execution_worker_memory_bytes": MIN_WORKER_MEMORY_BYTES,
        "execution_scratch_reserve_bytes": 0,
        "executor_source_identity": sha256_bytes(canonical_json_bytes(_f45_source_member_sha256())),
        "archive_reserved_bytes": reserved, "resource_observation": observation, "resource_admission": admission,
        "new_rng_invocations": 0, "new_metric_engine_invocations": 0, "global_reduction_count": 0,
        "numerical_reader_execution": {}}
    try:
        with _full_score_scratch(evidence_root):
            plan, point, rows, origin = _collect_a12_bootstrap_shards(evidence_root, handoff, response_csv,
                resource_policy=policy, retained_primary_point=retained_primary_point,
                primary_point_native=primary_point_native, original_paths=paths,
                execution_report=execution["numerical_reader_execution"],
                prepared_input_record=prepared_input_record, prepared_points=prepared_points)
            result = _reduce_a12_incremental_value(handoff, plan, point, rows, formal=True)
            execution.update(origin=origin, global_reduction_count=1)
    except BaseException as exc:
        exc.add_note(f"F5_A12_BOOTSTRAP_GATHER_EVIDENCE_RETAINED:{evidence_root}")
        raise
    finally:
        (evidence_root / "execution.json").write_bytes(canonical_json_bytes(execution))
    return {**result, "evaluation_execution": execution}


def _replay_a12_sharded_evaluation(root: Path, predictions: Mapping[str, Any], response_csv: bytes, *,
        resource_policy: Mapping[str, Any], retained_primary_point: Mapping[str, Any],
        primary_point_native: Path | bytes,
        prepared_input_record: Mapping[str, Any] | None = None,
        prepared_points: Mapping[str, Any] | None = None) -> dict:
    """Rebuild the original global summary from numerically-read shard rows."""
    from .runtime import resource_admission, validate_resource_policy
    from .f4 import _f45_source_member_sha256
    handoff = _validate_a12_handoff(predictions)
    execution = strict_json_bytes((root / "execution.json").read_bytes())
    original_policy = validate_resource_policy(execution["resource_policy"])
    names = {"bootstrap-input.zip", "point-sources.zip", *(f"shard-{i}.zip" for i in range(1, 7))}
    reserved = 2 * sum((root / name).stat().st_size for name in names)
    worker_budget = execution.get("execution_worker_memory_bytes")
    _require(type(worker_budget) is int and worker_budget in RECORDED_WORKER_MEMORY_BYTES
             and execution.get("executor_source_identity") == sha256_bytes(canonical_json_bytes(_f45_source_member_sha256())),
             "F5_A12_BOOTSTRAP_WORKER_MEMORY_BUDGET_INVALID")
    scratch_budget = execution.get("execution_scratch_reserve_bytes")
    _require(scratch_budget is None or type(scratch_budget) is int and scratch_budget == 0,
             "F5_A12_BOOTSTRAP_SCRATCH_BUDGET_INVALID")
    admission = resource_admission({**original_policy,
        "memory_bytes_per_worker": worker_budget,
        "scratch_reserve_bytes": original_policy["scratch_reserve_bytes"] + reserved if scratch_budget is None else scratch_budget},
        execution["resource_observation"], legal_tasks=1)
    _require(execution["kind"] == "PADML_F5_A12_FIXED_BOOTSTRAP_GATHER_V1"
             and execution["archive_reserved_bytes"] == reserved and execution["resource_admission"] == admission
             and execution["new_rng_invocations"] == execution["new_metric_engine_invocations"] == 0
             and execution["global_reduction_count"] == 1, "F5_A12_BOOTSTRAP_GATHER_EXECUTION_INVALID")
    reader_execution = {}
    plan, point, rows, origin = _collect_a12_bootstrap_shards(root, handoff, response_csv,
        resource_policy=resource_policy, retained_primary_point=retained_primary_point,
        primary_point_native=primary_point_native, execution_report=reader_execution,
        prepared_input_record=prepared_input_record, prepared_points=prepared_points)
    original_reader = execution["numerical_reader_execution"]
    _require(original_reader.get("executor_source_identity") == execution["executor_source_identity"]
             and type(original_reader.get("execution_worker_memory_bytes")) is int
             and original_reader["execution_worker_memory_bytes"] in RECORDED_WORKER_MEMORY_BYTES,
             "F5_A12_BOOTSTRAP_READER_EXECUTION_INVALID")
    reader_policy = _a12_bootstrap_reader_policy(original_policy, reader_execution["resource_reservation"],
        execution_worker_memory_bytes=original_reader["execution_worker_memory_bytes"],
        execution_scratch_reserve_bytes=original_reader.get("execution_scratch_reserve_bytes"))
    reader_admission = resource_admission(reader_policy, original_reader["resource_observation"], legal_tasks=6)
    pool = original_reader["pool"]
    _require(canonical_json_bytes(original_reader["resource_reservation"])
                 == canonical_json_bytes(reader_execution["resource_reservation"])
             and canonical_json_bytes(original_reader["effective_policy"]) == canonical_json_bytes(reader_policy)
             and canonical_json_bytes(original_reader["resource_admission"]) == canonical_json_bytes(reader_admission)
             and isinstance(pool, Mapping) and set(pool) == {"status", "engine_threads", "configured_worker_ceiling",
                 "admitted_worker_ceiling", "completed_task_count", "runnable_task_count", "actual_worker_process_peak"}
             and all(type(pool[name]) is int for name in pool if name != "status")
             and pool["status"] == "COMPLETED" and pool["engine_threads"] == 1
             and pool["configured_worker_ceiling"] == original_reader["resource_observation"]["effective_cpus"] - 8
             and pool["admitted_worker_ceiling"] == reader_admission["admitted_worker_ceiling"]
             and pool["completed_task_count"] == pool["runnable_task_count"] == 6
             and 1 <= pool["actual_worker_process_peak"] <= reader_admission["admitted_worker_ceiling"],
             "F5_A12_BOOTSTRAP_READER_EXECUTION_INVALID")
    _require(canonical_json_bytes(origin) == canonical_json_bytes(execution["origin"]),
             "F5_A12_BOOTSTRAP_GATHER_EXECUTION_INVALID")
    return {**_reduce_a12_incremental_value(handoff, plan, point, rows, formal=True), "evaluation_execution": execution}


def evaluate_a12_incremental_value(
    predictions: Mapping[str, Any],
    response_csv: bytes,
    *,
    replicate_count: int = 1000,
    workers: int | None = None,
    formal: bool = False,
    evidence_root: Path | None = None,
    resource_policy: Mapping[str, Any] | None = None,
    retained_bytes_per_replicate: int | None = None,
    retained_primary_point: Mapping[str, Any] | None = None,
    primary_point_native: Path | bytes | None = None,
    bootstrap_input_target: Path | None = None,
    point_archive_target: Path | None = None,
    prepared_members: Mapping[str, Path] | None = None,
    retained_rng_archive: Path | None = None,
    retained_rng_preparation_record: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Evaluate already-produced A12 branches using one shared set of draws.

    The fixed signed contrast is ``ablation - primary`` for every metric.
    The caller supplies references for the protocol-specific direct and total
    ablation fits; this consumer does not create or replay those fits, so its
    numerical reduction remains blocked as declared evidence.
    """
    _require(
        type(replicate_count) is int
        and replicate_count > 0
        and (workers is None or type(workers) is int and workers >= 1)
        and (not formal or replicate_count == 1000),
        "F5_A12_BOOTSTRAP_PROFILE_INVALID",
    )
    from contextlib import nullcontext
    from .f5 import _full_score_scratch
    from .f4 import _f45_source_member_sha256
    from .runtime import observe_execution_resources, resource_admission, validate_resource_policy

    handoff = _validate_a12_handoff(predictions)
    nested = _a12_prediction_branches(handoff["survival"])[0] == "PRIMARY"
    prepare_only = bootstrap_input_target is not None or point_archive_target is not None
    _require(prepared_members is None or prepare_only, "F5_A12_BOOTSTRAP_PROFILE_INVALID")
    _require((retained_rng_archive is None) == (retained_rng_preparation_record is None),
             "F5_A12_RETAINED_RNG_SOURCE_REQUIRED")
    _require(retained_rng_archive is None or nested and isinstance(retained_rng_archive, Path)
             and retained_rng_archive.is_absolute() and retained_rng_archive.is_file()
             and not retained_rng_archive.is_symlink() and retained_rng_archive.resolve(strict=True) == retained_rng_archive,
             "F5_A12_RETAINED_RNG_SCOPE_INVALID")
    if retained_rng_archive is not None:
        # This is the independently retained first prepare return, not a
        # digest supplied by the candidate RNG archive being checked.
        _require(isinstance(retained_rng_preparation_record, Mapping)
                 and retained_rng_preparation_record.get("status") in {"PREPARED_SHARED_F45_DRAWS", "PREPARED_FIXED_PREDICTIONS_AND_SHARED_DRAWS"}
                 and retained_rng_preparation_record.get("stage_acceptance") is False
                 and type(retained_rng_preparation_record.get("shared_rng_invocations")) is int
                 and retained_rng_preparation_record["shared_rng_invocations"] == 1
                 and all(type(retained_rng_preparation_record.get(name)) is int
                         and retained_rng_preparation_record[name] == 0
                         for name in ("new_model_fits", "bootstrap_replicates_executed")),
                 "F5_A12_RETAINED_RNG_SOURCE_REQUIRED")
        rng_reference = retained_rng_preparation_record.get("rng_archive")
        _require(isinstance(rng_reference, Mapping) and set(rng_reference) == {"sha256", "size_bytes"}
                 and type(rng_reference["size_bytes"]) is int and rng_reference["size_bytes"] > 0,
                 "F5_A12_RETAINED_RNG_SOURCE_REQUIRED")
        validate_sha256(rng_reference["sha256"], "a12.retained_rng")
        validate_sha256(retained_rng_preparation_record.get("f45_source_sha256"), "a12.retained_rng.producer")
        # Preserve this draw set's original producer. bootstrap_draws below
        # checks the original request, patient order, seed and exact R kernel;
        # the retained preparation pins its bytes independently of this caller.
        _require(retained_rng_archive.stat().st_size == rng_reference["size_bytes"],
                 "F5_A12_RETAINED_RNG_BYTES_CHANGED")
    _require(not prepare_only or nested and isinstance(bootstrap_input_target, Path)
             and isinstance(point_archive_target, Path) and bootstrap_input_target != point_archive_target
             and all(path.is_absolute() and path.parent.is_dir() and not path.exists() and not path.is_symlink()
                     for path in (bootstrap_input_target, point_archive_target)), "F5_A12_BOOTSTRAP_PREPARATION_PATH_INVALID")
    evaluation_handoff = {
        key: handoff[key]
        for key in ("patient_ids", "centers", "horizons", "survival")
    }
    evaluation_scope = _a12_evaluation_scope(handoff)
    evaluation_handoff.update(evaluation_scope)
    evaluation_handoff.update(_a12_evaluation_estimability(handoff))
    if evidence_root is not None:
        _require(evidence_root.is_absolute() and evidence_root.parent.is_dir()
                 and not evidence_root.is_symlink() and (not evidence_root.exists() or evidence_root.is_dir()),
                 "F5_A12_NATIVE_EVALUATION_PATH_INVALID")
    if nested:
        _require(workers is None and formal is True and replicate_count == 1000 and evidence_root is not None
                 and type(retained_bytes_per_replicate) is int and retained_bytes_per_replicate > 0
                 and isinstance(retained_primary_point, Mapping) and isinstance(primary_point_native, (Path, bytes)),
                 "F5_A12_NESTED_BOOTSTRAP_PROFILE_INVALID")
        policy = validate_resource_policy(resource_policy)
        # Retain every first metric archive and the shared draw plan. These
        # are operational estimates, never extra model-fit authorization.
        handoff_bytes = len(canonical_json_bytes(evaluation_handoff))
        draw_bytes = 16 * replicate_count * len(handoff["patient_ids"])
        primary_bytes = len(canonical_json_bytes(dict(retained_primary_point))) + (
            primary_point_native.stat().st_size if isinstance(primary_point_native, Path) else len(primary_point_native))
        reservation = {"kind": "OPERATIONAL_ESTIMATE_NOT_MEASURED_PEAK",
            "retained_bytes_per_replicate": retained_bytes_per_replicate,
            "shared_draw_storage_reserved_bytes": 2 * draw_bytes,
            "metric_retention_reserved_bytes": (0 if prepare_only else replicate_count) * retained_bytes_per_replicate,
            "coordinator_memory_estimate_bytes": 32 * (handoff_bytes + draw_bytes + primary_bytes) + 128 * replicate_count * ((2 * 4 - 1) * ((12 * len(REPORT_HORIZONS) + 2) + 7 * (10 * len(REPORT_HORIZONS) + 2)))}
        _require(retained_rng_archive is None or rng_reference["size_bytes"]
                 <= reservation["shared_draw_storage_reserved_bytes"], "F5_A12_BOOTSTRAP_STORAGE_ESTIMATE_EXCEEDED")
        effective_policy = {**policy,
            "scratch_reserve_bytes": 0,
            "memory_reserve_bytes": policy["memory_reserve_bytes"] + reservation["coordinator_memory_estimate_bytes"],
            "memory_bytes_per_worker": MIN_WORKER_MEMORY_BYTES}
        observation = observe_execution_resources(evidence_root.parent)
        admission = resource_admission(effective_policy, observation, legal_tasks=1 if prepare_only else replicate_count)
        workers = admission["admitted_worker_ceiling"]
        execution = {"resource_policy": policy, "resource_reservation": reservation, "effective_policy": effective_policy,
            "resource_observation": observation, "resource_admission": admission, "bootstrap_pool": {},
            "executor_source_identity": sha256_bytes(canonical_json_bytes(_f45_source_member_sha256())),
            "execution_worker_memory_bytes": MIN_WORKER_MEMORY_BYTES, "execution_scratch_reserve_bytes": 0}
    else:
        _require(resource_policy is None and retained_bytes_per_replicate is None
                 and retained_primary_point is None and primary_point_native is None, "F5_A12_BOOTSTRAP_PROFILE_INVALID")
        workers = resolve_pool_workers(workers)
    if evidence_root is not None:
        evidence_root.mkdir(mode=0o700, exist_ok=True)
    admit_io = partial(_admit_a12_bootstrap_io, resource_policy=policy, scratch_root=evidence_root) if nested else None
    try:
        with _full_score_scratch(evidence_root) if nested else nullcontext():
            if nested:
                origin = _a12_primary_point_origin(handoff, response_csv, retained_primary_point, primary_point_native,
                    admit_io=admit_io)
                from .nested_loco import _write_exact_once
                _write_exact_once(evidence_root / "primary-point-evaluation.json",
                    canonical_json_bytes(dict(retained_primary_point)), "F5_A12_PRIMARY_POINT_SOURCE_INVALID")
                _write_exact_once(evidence_root / "primary-point-native.zip",
                    primary_point_native.read_bytes() if isinstance(primary_point_native, Path) else primary_point_native,
                    "F5_A12_PRIMARY_POINT_SOURCE_INVALID")
            rng_options = {"retained_archive": evidence_root / "rng.zip"} if nested else {}
            if retained_rng_archive is not None:
                rng_target = evidence_root / "rng.zip"
                if not rng_target.exists():
                    shutil.copyfile(retained_rng_archive, rng_target)
                _require(rng_target.stat().st_size == rng_reference["size_bytes"]
                    and sha256_file(rng_target) == rng_reference["sha256"], "F5_A12_RETAINED_RNG_BYTES_CHANGED")
            if nested and (evidence_root / "rng.zip").is_file():
                rng_options = {"replay_archive": evidence_root / "rng.zip", "admit_io": admit_io}
            plan = bootstrap_draws(handoff["patient_ids"], handoff["centers"], "FIXED_MODEL_PAIRED",
                replicate_count=replicate_count, patient_keys=handoff["patient_keys"], rscript=RSCRIPT_EXECUTABLE,
                **rng_options)
            source = _a12_bootstrap_binding(evaluation_handoff, response_csv, plan) if evidence_root is not None else None
            if evidence_root is not None:
                from .nested_loco import _write_exact_once
                if (evidence_root / "plan.json").is_file():
                    previous = strict_json_bytes((evidence_root / "plan.json").read_bytes())
                    _require(previous["plan"] == plan and _a12_compatible_binding(previous["source"], source),
                             "F5_A12_RETAINED_SOURCE_MISMATCH")
                else:
                    _write_exact_once(evidence_root / "plan.json", canonical_json_bytes({"source": source, "plan": plan}),
                                      "F5_A12_RETAINED_SOURCE_MISMATCH")
            if nested:
                _require(sum((evidence_root / name).stat().st_size for name in ("rng.zip", "plan.json"))
                         <= reservation["shared_draw_storage_reserved_bytes"], "F5_A12_BOOTSTRAP_STORAGE_ESTIMATE_EXCEEDED")
            point_handoff = ({**evaluation_handoff, "survival": {
                branch: matrix for branch, matrix in evaluation_handoff["survival"].items() if branch != "PRIMARY"}}
                if nested else evaluation_handoff)
            point_evaluation = evaluate_predictions(point_handoff, response_csv,
                **evaluation_scope,
                **({"replay_native_archive": evidence_root / "point-native.zip"}
                   if evidence_root is not None and (evidence_root / "point-native.zip").is_file() else
                   {"evidence_root": evidence_root / "point", "native_archive": evidence_root / "point-native.zip"}
                   if evidence_root is not None else {}))
            if evidence_root is not None:
                _validate_a12_native_evaluation(point_evaluation, point_handoff, response_csv,
                    **evaluation_scope,
                    native_archive=evidence_root / "point-native.zip",
                    **({"point_branch_scope": "THREE_AAR", "admit_io": admit_io} if nested else {}))
                if nested:
                    _write_exact_once(evidence_root / "aar-point-evaluation.json", canonical_json_bytes(point_evaluation),
                                      "F5_A12_POINT_SOURCE_SCOPE_MISMATCH")
                    point_evaluation = _merge_a12_point_evaluations(origin, point_evaluation, estimability=handoff.get("estimability"))
                _write_exact_once(evidence_root / "point-evaluation.json", canonical_json_bytes(point_evaluation),
                                  "F5_A12_POINT_SOURCE_SCOPE_MISMATCH")
            if nested:
                point_reserved = 3 * sum((evidence_root / name).stat().st_size
                                        for name in _A12_NESTED_POINT_MEMBERS) + 16384
                reservation["point_retention_reserved_bytes"] = point_reserved
                reservation["metric_retention_reserved_bytes"] += point_reserved
                # One point result plus the retained coordinates and both
                # delivery archives. This guard also runs on compact resume.
                execution["point_storage_observation"] = observe_execution_resources(evidence_root)
                _require(execution["point_storage_observation"]["scratch_available_bytes"] >= point_reserved
                         + (0 if prepare_only else 3 * replicate_count * retained_bytes_per_replicate),
                         "F5_A12_BOOTSTRAP_PACKAGING_SPACE_INSUFFICIENT")
                if not prepare_only and handoff.get("science_decision", {}).get("integrated_raw_data", {}).get("compact_coordinates"):
                    transient = max(policy["scratch_bytes_per_worker"], 3 * (64 * handoff_bytes + 16 * 1024**2))
                    free = execution["point_storage_observation"]["scratch_available_bytes"]
                    disk_slots = (free - point_reserved - 3 * replicate_count * retained_bytes_per_replicate) // transient
                    _require(disk_slots >= 1, "F5_A12_BOOTSTRAP_ACTIVE_DISK_INSUFFICIENT")
                    workers = min(workers, disk_slots)
                    execution["active_worker_temporary_bytes"] = transient
                    execution["storage_worker_ceiling"] = int(disk_slots)
            if prepare_only:
                return _write_a12_bootstrap_inputs(bootstrap_input_target, point_archive_target,
                    handoff, response_csv, evidence_root, shared_rng_invocations=int(retained_rng_archive is None),
                    prepared_members=prepared_members, resource_policy=resource_policy)
            replicates = _bounded_ordered_spawn(
                partial(_a12_bootstrap_replicate, evaluation_handoff=evaluation_handoff, response_csv=response_csv,
                    **({"work_root": evidence_root, "source_binding": source} if evidence_root is not None else {}),
                    **({"retained_bytes_per_replicate": retained_bytes_per_replicate, "admit_io": admit_io} if nested else {})),
                _a12_replicate_items(plan), selected_slots=workers,
                **({"execution_report": execution["bootstrap_pool"]} if nested else {}))
    finally:
        if nested:
            (evidence_root / "execution.json").write_bytes(canonical_json_bytes(execution))
    result = _reduce_a12_incremental_value(handoff, plan, point_evaluation, replicates, formal=formal)
    return {**result, **({"evaluation_execution": execution} if nested else {})}


def _reduce_a12_incremental_value(handoff: Mapping[str, Any], plan: Mapping[str, Any],
                                 point_evaluation: Mapping[str, Any], replicates: list[dict], *, formal: bool) -> dict:
    """The producer and retained-result consumer share only the original pure reduction."""
    replicate_count = plan["replicate_count"]
    _require(len(replicates) == replicate_count
             and [row["replicate"] for row in replicates] == list(range(1, replicate_count + 1)),
             "F5_A12_BOOTSTRAP_COVERAGE_INVALID")
    branches = _a12_prediction_branches(handoff["survival"])
    primary = branches[0]
    nested = primary == "PRIMARY"
    horizon = handoff.get("selection_horizon_months", 24)
    _require(type(horizon) is int and horizon in {6, 12, 24, 36}
             and point_evaluation.get("selection_horizon_months", 24) == horizon,
             "F5_A12_REDUCTION_HORIZON_MISMATCH")
    if nested:
        from .nested_loco import validate_science_decision
        science = validate_science_decision(handoff["science_decision"])
        _require(point_evaluation.get("science_decision_sha256") == science["identity_sha256"],
            "F5_A12_REDUCTION_HORIZON_MISMATCH")
    point_metrics_by_scope = _a12_scope_metrics(point_evaluation, branches=branches)
    _require(
        set(point_metrics_by_scope) == {"MICRO", *_VALIDATION_CENTERS},
        "F5_A12_CENTER_COVERAGE_INVALID",
    )
    point_deltas_by_scope = {
        scope: _a12_deltas(metrics, tuple(metrics[primary]))
        for scope, metrics in point_metrics_by_scope.items()
    }
    point_macro_metrics = _a12_macro_metrics(point_evaluation, branches=branches)
    point_names = tuple(point_metrics_by_scope["MICRO"][primary])
    macro_names = tuple(point_macro_metrics[primary])
    for row in replicates:
        _require(set(row["macro_deltas"]) == set(branches[1:])
                 and set(row["scope_deltas"]) == set(point_metrics_by_scope)
                 and all(set(row["macro_deltas"][branch]) == set(macro_names) for branch in branches[1:])
                 and all(set(values) == set(branches[1:])
                         and all(set(values[branch]) == set(point_names) for branch in branches[1:])
                         for values in row["scope_deltas"].values()),
                 "F5_A12_REDUCTION_METRIC_COVERAGE_INVALID")
        _require(set(row["macro_metrics"]) == set(branches)
            and all(set(row["macro_metrics"][b]) == set(macro_names) for b in branches)
            and set(row["scope_metrics"]) == set(point_metrics_by_scope)
            and all(set(values) == set(branches)
                and all(set(values[b]) == set(point_names) for b in branches)
                for values in row["scope_metrics"].values()), "F5_A12_REDUCTION_METRIC_COVERAGE_INVALID")
    point_macro_deltas = _a12_deltas(
        point_macro_metrics, macro_names
    )
    point_metrics = point_metrics_by_scope["MICRO"]
    point_deltas = point_deltas_by_scope["MICRO"]
    paired_rows = []
    for branch in branches[1:]:
        for metric in macro_names:
            reference = point_macro_metrics[primary][metric]
            ablation = point_macro_metrics[branch][metric]
            paired_rows.append({
                "branch": branch,
                "estimand": "EQUAL_CENTER_MACRO_PRIMARY",
                "scope": "MACRO",
                "metric": metric,
                "reference_estimate": reference,
                "ablation_estimate": ablation,
                "paired_delta": point_macro_deltas[branch][metric],
                "bootstrap": _sensitivity_summary([
                    row["macro_deltas"][branch][metric]
                    for row in replicates
                ]),
            })
        for scope in ("MICRO", *_VALIDATION_CENTERS):
            for metric in point_names:
                reference = point_metrics_by_scope[scope][
                    primary
                ][metric]
                ablation = point_metrics_by_scope[scope][branch][metric]
                paired_rows.append({
                    "branch": branch,
                    "estimand": "POOLED_PATIENT_MICRO_DESCRIPTIVE"
                    if scope == "MICRO" else "CENTER_SPECIFIC_DESCRIPTIVE",
                    "scope": scope,
                    "metric": metric,
                    "reference_estimate": reference,
                    "ablation_estimate": ablation,
                    "paired_delta": point_deltas_by_scope[scope][branch][metric],
                    "bootstrap": _sensitivity_summary([
                        row["scope_deltas"][scope][branch][metric]
                        for row in replicates
                    ]),
                })
    absolute_rows = []
    for branch in branches:
        for metric in macro_names:
            absolute_rows.append({"branch": branch, "scope": "MACRO", "metric": metric,
                "selection_horizon_months": horizon, "estimand": "EQUAL_CENTER_MACRO_PRIMARY",
                "point_estimate": point_macro_metrics[branch][metric],
                "bootstrap": _sensitivity_summary([row["macro_metrics"][branch][metric] for row in replicates])})
        for scope in ("MICRO", *_VALIDATION_CENTERS):
            for metric in point_names:
                absolute_rows.append({"branch": branch, "scope": scope, "metric": metric,
                    "selection_horizon_months": horizon,
                    "estimand": "POOLED_PATIENT_MICRO_DESCRIPTIVE" if scope == "MICRO" else "CENTER_SPECIFIC_DESCRIPTIVE",
                    "point_estimate": point_metrics_by_scope[scope][branch][metric],
                    "bootstrap": _sensitivity_summary([row["scope_metrics"][scope][branch][metric] for row in replicates])})
    weighted = None
    if nested:
        # The handoff contains the original validation cohort, never a resample.
        counts = {c: handoff["centers"].count(c) for c in _VALIDATION_CENTERS}
        _require(len(handoff["patient_ids"]) == len(set(handoff["patient_ids"]))
                 == sum(counts.values()), "F45_CENTER_WEIGHTS_COHORT_INVALID")
        weighted_point = _a12_weighted_center_metrics(point_metrics_by_scope, counts, branches=branches)
        weighted_names = tuple(weighted_point[primary])
        weighted_draws = [_a12_weighted_center_metrics(row["scope_metrics"], counts, branches=branches)
                          for row in replicates]
        weighted_deltas = [_a12_deltas(row, weighted_names) for row in weighted_draws]
        weighted_point_deltas = _a12_deltas(weighted_point, weighted_names)
        estimand = "ORIGINAL_PATIENT_COUNT_WEIGHTED_CENTER_MACRO"
        for branch in branches:
            for metric in weighted_names:
                absolute_rows.append({"branch": branch, "scope": "WEIGHTED_MACRO", "metric": metric,
                    "selection_horizon_months": horizon, "estimand": estimand,
                    "point_estimate": weighted_point[branch][metric],
                    "bootstrap": _sensitivity_summary([row[branch][metric] for row in weighted_draws])})
                if branch != primary:
                    paired_rows.append({"branch": branch, "scope": "WEIGHTED_MACRO", "metric": metric,
                        "selection_horizon_months": horizon, "estimand": estimand,
                        "reference_estimate": weighted_point[primary][metric],
                        "ablation_estimate": weighted_point[branch][metric],
                        "paired_delta": weighted_point_deltas[branch][metric],
                        "bootstrap": _sensitivity_summary([row[branch][metric] for row in weighted_deltas])})
        weighted = {"patient_counts": counts, "denominator": sum(counts.values()),
            "weight_definition": "ORIGINAL_VALIDATION_PATIENT_COUNT_OVER_TOTAL",
            "missing_center_policy": "NOT_ESTIMABLE_WITHOUT_RENORMALIZATION",
            "point_metrics": weighted_point, "point_deltas": weighted_point_deltas}
    point_missing = ([
        {"estimand": "SCOPE", "scope": scope, "branch": branch, "metric": metric}
        for scope, metrics in point_metrics_by_scope.items()
        for branch, values in metrics.items()
        for metric, value in values.items()
        if value is None
    ] + [
        {"estimand": "MACRO", "scope": "MACRO", "branch": branch, "metric": metric}
        for branch, values in point_macro_metrics.items()
        for metric, value in values.items()
        if value is None
    ])
    if weighted is not None:
        point_missing.extend({"estimand": "ORIGINAL_PATIENT_COUNT_WEIGHTED_CENTER_MACRO", "scope": "WEIGHTED_MACRO", "branch": branch, "metric": metric}
            for branch, values in weighted["point_metrics"].items() for metric, value in values.items() if value is None)
    complete = not point_missing and not handoff.get("estimability") and all(
        row["bootstrap"]["status"] == "ESTIMABLE" for row in [*paired_rows, *absolute_rows]
    )
    replicate_evidence = [
        {
            "replicate": row["replicate"],
            "evidence_sha256": sha256_bytes(canonical_json_bytes({
                key: value for key, value in row.items() if key != "replicate"
            })),
        }
        for row in replicates
    ]
    return {
        "kind": "PADML_F5_A12_INCREMENTAL_VALUE_V2" if nested else "PADML_F5_A12_INCREMENTAL_VALUE_V1",
        "status": "REDUCED_DECLARED_EVIDENCE",
        "selection_horizon_months": horizon,
        **_a12_evaluation_estimability(handoff),
        "statistical_status": "ESTIMABLE" if complete else "PARTIALLY_NOT_ESTIMABLE",
        "execution_scope": (
            "FORMAL_PROFILE_ONLY_UNVERIFIED_PRODUCERS"
            if formal else "TEST_ONLY"
        ),
        "execution_evidence_status": "NOT_VERIFIED_REFERENCES_ONLY",
        "unverified_authority_sources": (["SIX_PRIMARY_NATIVE_OUTERS", "SIX_THREE_BRANCH_AAR_NATIVE_OUTERS"] if nested else [
            "PRIMARY_POLICY_A_FINAL_PREDICTION_ARCHIVE",
            "WITHOUT_AST_ALT_DIRECT_FIT_AND_PREDICTION_ARCHIVE",
            "WITHOUT_AST_ALT_TOTAL_MICE_FIT_AND_PREDICTION_ARCHIVE",
            "FINAL_FAMILY_DECISION_ARTIFACT",
            "FINAL_PARAMETER_LOCK_ARTIFACT",
            "FINAL_SET_A_ARTIFACT",
        ]),
        **({"family_by_outer": handoff["family_by_outer"], "selection_by_outer": handoff["selection_by_outer"],
            "primary_ooc_sha256": handoff["primary_ooc_sha256"],
            "science_decision_sha256": handoff["science_decision"]["identity_sha256"]} if nested else
           {"final_family": handoff["final_family"]}),
        "branch_provenance": handoff["branch_provenance"],
        "point_evaluation": point_evaluation,
        "point_metrics_by_scope": point_metrics_by_scope,
        "point_deltas_by_scope": point_deltas_by_scope,
        "point_macro_metrics": point_macro_metrics,
        "point_macro_deltas": point_macro_deltas,
        **({"weighted_center_macro": weighted} if weighted is not None else {}),
        "point_metrics": point_metrics,
        "point_deltas": point_deltas,
        "point_not_estimable": point_missing,
        "delta_definition": "CONTROL_MINUS_PRIMARY" if nested else "ABLATION_MINUS_PRIMARY_POLICY_A",
        "bootstrap": {
            "replicate_count": replicate_count,
            **({"uncertainty": "CONDITIONAL_ON_FIXED_PREDICTIONS_NOT_FULL_DEVELOPMENT_OR_FAMILY_SELECTION",
                "full_retraining_bootstrap_replicates": 0} if nested else {}),
            "root_seed": plan["root_seed"],
            "rng": plan["rng"],
            "stratification": "CENTER_FIXED_COUNTS",
            "primary_estimand": "EQUAL_CENTER_MACRO",
            "descriptive_estimands": [
                "POOLED_PATIENT_MICRO", "CENTER_SPECIFIC",
                *(["ORIGINAL_PATIENT_COUNT_WEIGHTED_CENTER_MACRO"] if weighted is not None else [])
            ],
            "metrics": {
                "macro": list(macro_names),
                "scope": list(point_names),
                **({"weighted_macro": list(weighted_names)} if weighted is not None else {}),
            },
            "horizons_months": list(REPORT_HORIZONS),
            "center_count": len(_VALIDATION_CENTERS),
            "paired_row_count": len(paired_rows),
            "draws_sha256": sha256_bytes(canonical_json_bytes(plan["draws"])),
            "paired_rows": paired_rows,
            "absolute_rows": absolute_rows, "absolute_row_count": len(absolute_rows),
            "replicate_evidence_sha256": sha256_bytes(
                canonical_json_bytes(replicate_evidence)
            ),
        },
        "model_fit_count": 0,
        "grid_search_count": 0,
        "family_reselection_count": 0,
        "selection_effect": "NONE",
        "blocking_for_production": True,
        "stage_acceptance": False,
    }


def _a19_patient_map(row: Mapping[str, Any]) -> dict[str, tuple[float, ...]]:
    patients = row["patients"]
    _require(
        isinstance(patients, Sequence)
        and not isinstance(patients, (str, bytes)),
        "F5_A19_PATIENT_ROWS_INVALID",
    )
    result: dict[str, tuple[float, ...]] = {}
    for patient in patients:
        _require(
            isinstance(patient, Mapping)
            and set(patient) == _A19_PATIENT_FIELDS,
            "F5_A19_PATIENT_ROW_SCHEMA_INVALID",
        )
        patient_id = patient["patient_key_hash"]
        values = patient["survival_probabilities"]
        validate_sha256(patient_id, "f5.a19.patient_key_hash")
        _require(
            patient_id not in result
            and isinstance(values, Sequence)
            and not isinstance(values, (str, bytes))
            and len(values) == len(HORIZONS)
            and all(_finite_probability(value) for value in values),
            "F5_A19_PATIENT_PREDICTION_INVALID",
        )
        result[patient_id] = tuple(float(value) for value in values)
    _require(bool(result), "F5_A19_PATIENT_ROWS_INVALID")
    return result


def compute_a19_multi_seed_stability(
    prediction_rows: Sequence[Mapping[str, Any]],
    center_by_patient: Mapping[str, str],
    response_csv: bytes,
) -> dict[str, Any]:
    """Compute A19 from seed/split/lock-bound prediction payloads."""
    _require(
        isinstance(prediction_rows, Sequence)
        and not isinstance(prediction_rows, (str, bytes))
        and len(prediction_rows) == 225,
        "F5_A19_INPUT_ROW_COVERAGE_INVALID",
    )
    expected = {
        (repeat, fold, seed_role, imputation)
        for repeat in range(1, 4)
        for fold in range(1, 6)
        for seed_role in A19_SEED_ROLES
        for imputation in range(1, 6)
    }
    science = load_science_authority()["science"]
    families = set(science["families"])
    development_centers = sorted({
        str(value)
        for role in ("validation_centers", "training_only_centers")
        for value in science["population"][role]
    })
    indexed: dict[tuple[int, int, str, int], dict[str, Any]] = {}
    for raw in prediction_rows:
        _require(
            isinstance(raw, Mapping) and set(raw) == _A19_ROW_FIELDS,
            "F5_A19_INPUT_ROW_SCHEMA_INVALID",
        )
        row = dict(raw)
        key = (
            row["inner_repeat_id"],
            row["inner_fold_id"],
            row["seed_role"],
            row["imp_id"],
        )
        _require(
            key in expected and key not in indexed,
            "F5_A19_INPUT_IDENTITY_INVALID",
        )
        for field in (
            "split_identity_sha256",
            "seed_identity_sha256",
            "final_family_decision_sha256",
            "final_parameter_lock_sha256",
            "fit_receipt_sha256",
            "prediction_sha256",
            "patient_set_sha256",
        ):
            validate_sha256(row[field], f"f5.a19.{field}")
        _require(
            row["time_grid_months"] == HORIZONS,
            "F5_A19_TIME_GRID_INVALID",
        )
        _require(
            row["final_family"] in families,
            "F5_A19_FINAL_FAMILY_INVALID",
        )
        indexed[key] = row
    _require(set(indexed) == expected, "F5_A19_INPUT_IDENTITY_INCOMPLETE")
    final_families = {row["final_family"] for row in indexed.values()}
    family_decisions = {
        row["final_family_decision_sha256"] for row in indexed.values()
    }
    parameter_locks = {
        row["final_parameter_lock_sha256"] for row in indexed.values()
    }
    fit_receipts = {row["fit_receipt_sha256"] for row in indexed.values()}
    _require(
        len(final_families) == len(family_decisions) == len(parameter_locks) == 1
        and len(fit_receipts) == 225,
        "F5_A19_FINAL_LOCK_OR_RECEIPT_BINDING_INVALID",
    )
    _require(
        isinstance(center_by_patient, Mapping)
        and bool(center_by_patient)
        and all(
            isinstance(key, str)
            and isinstance(value, str)
            and value in development_centers
            for key, value in center_by_patient.items()
        )
        and set(center_by_patient.values()) == set(development_centers),
        "F5_A19_CENTER_MAP_INVALID",
    )
    for patient in center_by_patient:
        validate_sha256(patient, "f5.a19.center_map.patient_key_hash")
    fields, responses = _response_rows(response_csv)
    _require(set(responses) == set(center_by_patient),
             "F5_A19_PARENT_RESPONSE_COVERAGE_INVALID")
    parent_ids = sorted(center_by_patient)
    parent_population = (
        parent_ids, [center_by_patient[patient] for patient in parent_ids],
        _write_response_subset(fields, responses, parent_ids, None),
    )
    split_sd_rows = []
    risk_by_repeat_patient: dict[tuple[int, str], dict[str, float]] = {}
    repeat_patient_sets: dict[tuple[int, str], set[str]] = {}
    for repeat in range(1, 4):
        for fold in range(1, 6):
            split_rows = [
                indexed[(repeat, fold, seed_role, imputation)]
                for seed_role in A19_SEED_ROLES
                for imputation in range(1, 6)
            ]
            _require(
                len({row["split_identity_sha256"] for row in split_rows}) == 1,
                "F5_A19_SPLIT_IDENTITY_MISMATCH",
            )
            _require(
                len({row["patient_set_sha256"] for row in split_rows}) == 1,
                "F5_A19_PATIENT_SET_IDENTITY_MISMATCH",
            )
            split_seed = 100_000 + repeat * 100
            _require(
                all(row["split_seed"] == split_seed for row in split_rows),
                "F5_A19_SPLIT_SEED_INVALID",
            )
            patient_set_sha256 = split_rows[0]["patient_set_sha256"]
            seed_ibs = []
            split_patient_set = None
            context = None
            seed_identities = set()
            for seed_role in A19_SEED_ROLES:
                rows = [
                    indexed[(repeat, fold, seed_role, imputation)]
                    for imputation in range(1, 6)
                ]
                identities = {row["seed_identity_sha256"] for row in rows}
                _require(
                    len(identities) == 1,
                    "F5_A19_SEED_IDENTITY_MISMATCH",
                )
                expected_model_seed = (
                    300_000
                    + repeat * 100
                    + fold
                    + {
                        "BASE": 0,
                        "EXTRA_OFFSET_10000": 10_000,
                        "EXTRA_OFFSET_20000": 20_000,
                    }[seed_role]
                )
                expected_seed_identity = sha256_bytes(canonical_json_bytes({
                    "rng_kind": "L'Ecuyer-CMRG",
                    "coordinates": {
                        "virtual_outer": 0,
                        "repeat": repeat,
                        "inner_fold": fold,
                    },
                    "seed_role": seed_role,
                    "model_seed": expected_model_seed,
                }))
                _require(
                    all(
                        row["model_seed"] == expected_model_seed
                        and row["seed_identity_sha256"]
                        == expected_seed_identity
                        for row in rows
                    ),
                    "F5_A19_MODEL_SEED_BINDING_INVALID",
                )
                seed_identities.update(identities)
                maps = [_a19_patient_map(row) for row in rows]
                for mapping in maps:
                    ordered_patients = sorted(mapping)
                    _seal_prediction_matrix(
                        ordered_patients,
                        [list(mapping[patient]) for patient in ordered_patients],
                        HORIZONS,
                    )
                _require(
                    all(
                        row["prediction_sha256"]
                        == sha256_bytes(canonical_json_bytes(row["patients"]))
                        for row in rows
                    ),
                    "F5_A19_PREDICTION_BINDING_INVALID",
                )
                patient_sets = [set(row) for row in maps]
                _require(
                    all(value == patient_sets[0] for value in patient_sets[1:]),
                    "F5_A19_M5_PATIENT_COVERAGE_MISMATCH",
                )
                patients = sorted(patient_sets[0])
                _require(
                    sha256_bytes(canonical_json_bytes(patients))
                    == patient_set_sha256,
                    "F5_A19_PATIENT_SET_HASH_MISMATCH",
                )
                expected_split_identity = sha256_bytes(canonical_json_bytes({
                    "coordinates": {
                        "virtual_outer": 0,
                        "repeat": repeat,
                        "inner_fold": fold,
                    },
                    "split_seed": split_seed,
                    "evaluation_patient_keys": patients,
                }))
                _require(
                    all(
                        row["split_identity_sha256"]
                        == expected_split_identity
                        for row in rows
                    ),
                    "F5_A19_SPLIT_IDENTITY_BINDING_INVALID",
                )
                _require(
                    split_patient_set is None
                    or patient_sets[0] == split_patient_set,
                    "F5_A19_SEED_PATIENT_COVERAGE_MISMATCH",
                )
                split_patient_set = patient_sets[0]
                mean_survival = [
                    [
                        math.fsum(mapping[patient][horizon] for mapping in maps)
                        / 5.0
                        for horizon in HORIZONS
                    ]
                    for patient in patients
                ]
                _seal_prediction_matrix(patients, mean_survival, HORIZONS)
                _require(
                    set(patients).issubset(responses)
                    and set(patients).issubset(center_by_patient),
                    "F5_A19_RESPONSE_OR_CENTER_MISSING",
                )
                if context is None:
                    response = _write_response_subset(fields, responses, patients, None)
                    centers = [center_by_patient[patient] for patient in patients]
                    context = censoring_context(
                        patients, centers, response, reference_population=parent_population
                    )
                ibs = prediction_error(patients, mean_survival, context)[
                    "ibs_0_to"
                ]["24"]
                unsupported = [row for row in context["rows"][1:25]
                               if row["status"] != "ESTIMABLE"]
                if ibs is None:
                    _require(bool(unsupported), "F5_A19_IBS_SUPPORT_EVIDENCE_REQUIRED")
                    for support in unsupported:
                        _statistical_support_reasons(support)
                else:
                    _require(type(ibs) in {int, float} and math.isfinite(ibs)
                             and 0.0 <= ibs <= 1.0 and not unsupported,
                             "F5_A19_IBS_INVALID")
                seed_ibs.append(None if ibs is None else float(ibs))
                repeat_key = (repeat, seed_role)
                accumulated = repeat_patient_sets.setdefault(repeat_key, set())
                _require(
                    accumulated.isdisjoint(patients),
                    "F5_A19_REPEAT_PATIENT_DUPLICATED_ACROSS_FOLDS",
                )
                accumulated.update(patients)
                for patient, survival in zip(
                    patients, mean_survival, strict=True
                ):
                    values = risk_by_repeat_patient.setdefault(
                        (repeat, patient), {}
                    )
                    _require(
                        seed_role not in values,
                        "F5_A19_REPEAT_PATIENT_SEED_DUPLICATED",
                    )
                    decimal_mean = math.fsum(
                        float(mapping[patient][24]) for mapping in maps
                    ) / 5.0
                    decimal_risk = Decimal(1) - sum(
                        (Decimal(str(mapping[patient][24])) for mapping in maps),
                        Decimal(0),
                    ) / Decimal(5)
                    _require(
                        math.isclose(
                            float(decimal_risk),
                            1.0 - decimal_mean,
                            rel_tol=0.0,
                            abs_tol=1e-15,
                        )
                        and math.isclose(
                            survival[24], decimal_mean, rel_tol=0.0, abs_tol=1e-15
                        ),
                        "F5_A19_RISK_AGGREGATION_ERROR",
                    )
                    values[seed_role] = float(decimal_risk)
            _require(
                len(seed_identities) == 3,
                "F5_A19_SEED_IDENTITY_ALIAS_FORBIDDEN",
            )
            sample_sd = None
            if all(value is not None for value in seed_ibs):
                mean_ibs = math.fsum(seed_ibs) / 3.0
                sample_sd = math.sqrt(
                    math.fsum((value - mean_ibs) ** 2 for value in seed_ibs) / 2.0
                )
            split_sd_rows.append(
                {
                    "inner_repeat_id": repeat,
                    "inner_fold_id": fold,
                    "split_identity_sha256": split_rows[0][
                        "split_identity_sha256"
                    ],
                    "ibs_0_24_by_seed_role": dict(
                        zip(A19_SEED_ROLES, seed_ibs, strict=True)
                    ),
                    "sd_seed_ibs_0_24": sample_sd,
                    "statistical_status": "ESTIMABLE" if sample_sd is not None else "NOT_ESTIMABLE",
                    "patient_count": len(context["patient_ids"]),
                    "censoring_reference": context["censoring_reference"],
                    "ipcw_qc": [{key: value for key, value in row.items()
                                 if key not in {"weights", "truth"}}
                                for row in context["rows"][1:25]],
                }
            )
    repeat_sets = []
    for repeat in range(1, 4):
        seed_sets = [
            repeat_patient_sets[(repeat, role)] for role in A19_SEED_ROLES
        ]
        _require(
            all(value == seed_sets[0] for value in seed_sets[1:]),
            "F5_A19_REPEAT_PATIENT_SET_MISMATCH_ACROSS_SEEDS",
        )
        repeat_sets.append(seed_sets[0])
    _require(
        all(value == repeat_sets[0] for value in repeat_sets[1:])
        and set(center_by_patient) == repeat_sets[0],
        "F5_A19_PATIENT_SET_MISMATCH_ACROSS_REPEATS",
    )
    _require(
        len({row["split_identity_sha256"] for row in split_sd_rows}) == 15,
        "F5_A19_SPLIT_IDENTITY_ALIAS_FORBIDDEN",
    )
    risk_ranges = []
    for values in risk_by_repeat_patient.values():
        _require(
            set(values) == set(A19_SEED_ROLES),
            "F5_A19_REPEAT_PATIENT_SEED_COVERAGE_INCOMPLETE",
        )
        risk_ranges.append(max(values.values()) - min(values.values()))
    statistics = {
        "sd_seed_ibs_0_24": None if any(row["sd_seed_ibs_0_24"] is None for row in split_sd_rows) else max(
            row["sd_seed_ibs_0_24"] for row in split_sd_rows
        ),
        "p95_patient_24m_risk_seed_range": _type7_quantile(
            risk_ranges, 0.95
        ),
    }
    warning_rows = _a19_warning_rows(statistics)
    return {
        "kind": "PADML_F5_A19_MULTI_SEED_STABILITY_V1",
        "status": "REDUCED_DECLARED_EVIDENCE",
        "execution_evidence_status": "NOT_VERIFIED_REFERENCES_ONLY",
        "unverified_authority_sources": [
            "A19_FIT_RECEIPT_ARCHIVES",
            "FINAL_FAMILY_DECISION_ARTIFACT",
            "FINAL_PARAMETER_LOCK_ARTIFACT",
            "FINAL_SET_A_ARTIFACT",
            "FULL_DATA_INNER_SPLIT_ARCHIVE",
            "FINAL_MICE_ARCHIVE",
        ],
        "final_family": next(iter(final_families)),
        "final_family_decision_sha256": next(iter(family_decisions)),
        "final_parameter_lock_sha256": next(iter(parameter_locks)),
        "input_row_count": len(prediction_rows),
        "split_count": len(split_sd_rows),
        "seed_roles": list(A19_SEED_ROLES),
        "imputation_ids": list(range(1, 6)),
        "development_centers": development_centers,
        "center_map_sha256": sha256_bytes(canonical_json_bytes([
            {"patient_key_hash": patient, "center": center_by_patient[patient]}
            for patient in sorted(center_by_patient)
        ])),
        "aggregation_order": "M5_SURVIVAL_MEAN_THEN_IBS",
        "split_seed_sd_ddof": 1,
        "statistical_status": "ESTIMABLE" if statistics["sd_seed_ibs_0_24"] is not None else "PARTIALLY_NOT_ESTIMABLE",
        "sd_estimable_split_count": sum(row["sd_seed_ibs_0_24"] is not None for row in split_sd_rows),
        "sd_reduction_policy": "ALL_15_SPLITS_REQUIRED_NO_SUCCESSFUL_SUBSET",
        "statistics": statistics,
        "split_statistics": split_sd_rows,
        "repeat_patient_range_count": len(risk_ranges),
        "risk_range_values_sha256": sha256_bytes(
            canonical_json_bytes(sorted(risk_ranges))
        ),
        "warnings": warning_rows,
        "any_warning": (True if any(row["triggered"] is True for row in warning_rows)
                        else None if any(row["triggered"] is None for row in warning_rows)
                        else False),
        "warning_only": True,
        "declared_fit_receipt_count": len(fit_receipts),
        "bound_prediction_payload_count": len(prediction_rows),
        "model_fit_count": 0,
        "family_reselection_count": 0,
        "selection_effect": "NONE",
        "blocking_for_production": True,
        "stage_acceptance": False,
    }


def _a19_warning_rows(statistics: Mapping[str, float | None]) -> list[dict[str, Any]]:
    _require(
        set(statistics)
        == {"sd_seed_ibs_0_24", "p95_patient_24m_risk_seed_range"}
        and all(
            (key == "sd_seed_ibs_0_24" and value is None)
            or (type(value) is float and math.isfinite(value) and value >= 0.0)
            for key, value in statistics.items()
        ),
        "F5_A19_STATISTICS_INVALID",
    )
    return [
        {
            "warning_id": "SD_SEED_IBS_0_24_MAJOR_WARNING",
            "value": statistics["sd_seed_ibs_0_24"],
            "threshold": 0.002,
            "comparison_operator": "STRICT_GREATER_THAN",
            "triggered": None if statistics["sd_seed_ibs_0_24"] is None else (
                Decimal(str(statistics["sd_seed_ibs_0_24"])) > Decimal("0.002")
            ),
            "selection_effect": "NONE",
        },
        {
            "warning_id": "P95_PATIENT_24M_RISK_SEED_RANGE_MAJOR_WARNING",
            "value": statistics["p95_patient_24m_risk_seed_range"],
            "threshold": 0.03,
            "comparison_operator": "STRICT_GREATER_THAN",
            "triggered": Decimal(
                str(statistics["p95_patient_24m_risk_seed_range"])
            )
            > Decimal("0.03"),
            "selection_effect": "NONE",
        },
    ]


def _average_ranks(values: Sequence[float]) -> list[float]:
    order = sorted(range(len(values)), key=lambda index: (values[index], index))
    ranks = [0.0] * len(values)
    start = 0
    while start < len(order):
        stop = start + 1
        while stop < len(order) and values[order[stop]] == values[order[start]]:
            stop += 1
        average = ((start + 1) + stop) / 2.0
        for position in range(start, stop):
            ranks[order[position]] = average
        start = stop
    return ranks


def _spearman_average_ranks(
    left_values: Sequence[float], right_values: Sequence[float]
) -> tuple[float | None, str]:
    if len(left_values) != len(right_values) or len(left_values) < 2:
        return None, "NOT_ESTIMABLE_DIAGNOSTIC_ONLY"
    left = _average_ranks(left_values)
    right = _average_ranks(right_values)
    left_mean = math.fsum(left) / len(left)
    right_mean = math.fsum(right) / len(right)
    left_ss = math.fsum((value - left_mean) ** 2 for value in left)
    right_ss = math.fsum((value - right_mean) ** 2 for value in right)
    if left_ss == 0.0 or right_ss == 0.0:
        return None, "NOT_ESTIMABLE_DIAGNOSTIC_ONLY"
    numerator = math.fsum(
        (left[index] - left_mean) * (right[index] - right_mean)
        for index in range(len(left))
    )
    return numerator / math.sqrt(left_ss * right_ss), "ESTIMATED"


def _a04_index(rows: Sequence[Mapping[str, Any]], mode: str, horizon: int = 24) -> dict[str, Any]:
    _require(
        isinstance(rows, Sequence)
        and not isinstance(rows, (str, bytes))
        and rows,
        "F5_A04_INPUT_ROWS_INVALID",
    )
    indexed = {}
    for raw in rows:
        _require(
            isinstance(raw, Mapping) and horizon in {6, 12, 24, 36}
            and set(raw) == {"patient_key_hash", "center", f"risk_probability_{horizon}"},
            "F5_A04_OUTCOME_FREE_SCHEMA_INVALID",
        )
        patient = raw["patient_key_hash"]
        center = raw["center"]
        risk = raw[f"risk_probability_{horizon}"]
        validate_sha256(patient, "f5.a04.patient_key_hash")
        _require(
            patient not in indexed
            and isinstance(center, str)
            and center
            and _finite_probability(risk),
            "F5_A04_PREDICTION_INVALID",
        )
        indexed[patient] = {
            "center": center,
            "risk": float(risk),
            "risk_decimal": Decimal(str(risk)),
            "mode": mode,
        }
    return indexed


def evaluate_a04_batch_single(
    batch_rows: Sequence[Mapping[str, Any]],
    single_rows: Sequence[Mapping[str, Any]],
    *, horizon: int = 24,
) -> dict[str, Any]:
    """Compare outcome-free batch and single-patient M20 risks at one report time."""
    batch = _a04_index(batch_rows, A04_MODES[0], horizon)
    single = _a04_index(single_rows, A04_MODES[1], horizon)
    _require(set(batch) == set(single), "F5_A04_PATIENT_SET_MISMATCH")
    _require(
        all(batch[key]["center"] == single[key]["center"] for key in batch),
        "F5_A04_CENTER_ALIGNMENT_INVALID",
    )
    centers = sorted({row["center"] for row in batch.values()})
    center_rows = []
    all_differences = []
    all_batch = []
    all_single = []
    total_intersection = 0
    total_k = 0
    for center in centers:
        patients = sorted(
            key for key, row in batch.items() if row["center"] == center
        )
        _require(bool(patients), "F5_A04_CENTER_EMPTY")
        top_k = max(1, math.ceil(len(patients) / 10))
        batch_top = tuple(
            sorted(patients, key=lambda key: (-batch[key]["risk"], key))[:top_k]
        )
        single_top = tuple(
            sorted(patients, key=lambda key: (-single[key]["risk"], key))[:top_k]
        )
        intersection = len(set(batch_top).intersection(single_top))
        batch_values = [batch[key]["risk"] for key in patients]
        single_values = [single[key]["risk"] for key in patients]
        differences = [
            float(abs(batch[key]["risk_decimal"] - single[key]["risk_decimal"]))
            for key in patients
        ]
        spearman, spearman_status = _spearman_average_ranks(
            batch_values, single_values
        )
        all_differences.extend(differences)
        all_batch.extend(batch_values)
        all_single.extend(single_values)
        total_intersection += intersection
        total_k += top_k
        center_p95 = _type7_quantile(differences, 0.95)
        center_overlap_failed = intersection * 10 < 9 * top_k
        center_p95_failed = Decimal(str(center_p95)) > Decimal("0.02")
        center_rows.append(
            {
                "center": center,
                "patient_count": len(patients),
                "top_k_count": top_k,
                "intersection_count": intersection,
                "top_risk_agreement": intersection / top_k,
                "batch_top_set_sha256": sha256_bytes(
                    canonical_json_bytes(list(batch_top))
                ),
                "single_top_set_sha256": sha256_bytes(
                    canonical_json_bytes(list(single_top))
                ),
                "median_absolute_risk_difference": _type7_quantile(
                    differences, 0.5
                ),
                "p95_absolute_risk_difference": center_p95,
                "top_risk_status": "FAIL" if center_overlap_failed else "PASS",
                "p95_status": "FAIL" if center_p95_failed else "PASS",
                "deployment_status": "FAIL" if center_overlap_failed or center_p95_failed else "PASS",
                "spearman_rho": spearman,
                "spearman_status": spearman_status,
            }
        )
    agreement = total_intersection / total_k
    p95_difference = _type7_quantile(all_differences, 0.95)
    overlap_failed = total_intersection * 10 < 9 * total_k
    p95_failed = Decimal(str(p95_difference)) > Decimal("0.02")
    failed_centers = [row["center"] for row in center_rows if row["deployment_status"] == "FAIL"]
    spearman, spearman_status = _spearman_average_ranks(
        all_batch, all_single
    )
    return {
        "kind": "PADML_F5_A04_BATCH_SINGLE_APPLICATION_V1",
        "status": "REDUCED_DECLARED_EVIDENCE",
        "execution_evidence_status": "NOT_VERIFIED_REFERENCES_ONLY",
        "unverified_authority_sources": [
            "A04_BATCH_CENTER_PREDICTION_ARCHIVE",
            "A04_SINGLE_PATIENT_PREDICTION_ARCHIVE",
            "FINAL_FAMILY_DECISION_ARTIFACT",
            "FINAL_PARAMETER_LOCK_ARTIFACT",
            "FINAL_MICE_ARCHIVE",
            "DEPLOYMENT_AUDIT_COHORT_ARTIFACT",
        ],
        "modes": list(A04_MODES),
        "horizon_month": horizon,
        "top_k_definition": "MAX_1_CEILING_CENTER_N_DIVIDED_BY_10",
        "tie_break": "RISK_DESC_PATIENT_KEY_HASH_ASC",
        "center_results": center_rows,
        "summary": {
            "intersection_count": total_intersection,
            "denominator_count": total_k,
            "top_risk_agreement": agreement,
            "median_absolute_risk_difference": _type7_quantile(
                all_differences, 0.5
            ),
            "p95_absolute_risk_difference": p95_difference,
            "spearman_rho": spearman,
            "spearman_status": spearman_status,
        },
        "deployment_gate": {
            "scope": "SUPPLIED_CENTERS_ONLY",
            "assessed_centers": centers,
            "failed_centers": failed_centers,
            "pooled_status": "FAIL" if overlap_failed or p95_failed else "PASS",
            "top_risk_operator": "FAIL_IFF_AGREEMENT_LT_THRESHOLD",
            "top_risk_threshold": 0.90,
            "top_risk_status": "FAIL" if overlap_failed or any(
                row["top_risk_status"] == "FAIL" for row in center_rows
            ) else "PASS",
            "p95_operator": "FAIL_IFF_P95_GT_THRESHOLD",
            "p95_threshold": 0.02,
            "p95_status": "FAIL" if p95_failed or any(
                row["p95_status"] == "FAIL" for row in center_rows
            ) else "PASS",
            "status": "FAIL" if overlap_failed or p95_failed or failed_centers else "PASS",
        },
        "outcome_read_count": 0,
        "followup_read_count": 0,
        "model_fit_count": 0,
        "selector_rerun_count": 0,
        "family_reselection_count": 0,
        "patient_drop_count": 0,
        "fallback_count": 0,
        "selection_effect": "NONE",
        "blocking_for_production": True,
        "stage_acceptance": False,
    }


A04_NEW_MICE_VARIANTS = {"RAW_DONOR5": 5, "RAW_DONOR3": 3, "RAW_DONOR10": 10}


def _a04_variant_view_inputs(frozen: Mapping[str, Any], outer: int, variant: str, role: str) -> dict[str, bytes]:
    """Original outer patients, raw mask and each view's own twenty seed rows."""
    _require(variant in A04_NEW_MICE_VARIANTS and role in {"ANALYSIS", "APPLICATION"}
             and type(outer) is int and outer in range(1, 7), "F5_A04_MICE_VARIANT_INVALID")
    members = _a12_total_mice_input_members(frozen["binding_contract"], frozen["covariates_csv"],
        frozen["response_csv"], outer, "OUTER_" + role)
    value = strict_json_bytes(members["input.json"])
    members["input.json"] = canonical_json_bytes({**value,
        "kind": "PADML_F5_A04_VARIANT_MICE_INPUT", "a04_variant": variant})
    return members


def _a04_variant_model_seed(coordinates: Mapping[str, Any]) -> int:
    negative = isinstance(coordinates, Mapping) and coordinates.get("variant") == "NEGATIVE_CONTROL"
    _require(isinstance(coordinates, Mapping) and set(coordinates) == (
                 {"outer_fold", "imputation", "variant", "permutation_index"} if negative
                 else {"outer_fold", "imputation", "variant"})
             and type(coordinates["outer_fold"]) is int and coordinates["outer_fold"] in range(1, 7)
             and type(coordinates["imputation"]) is int and coordinates["imputation"] in range(1, 21)
             and ((coordinates["imputation"] == 1 and type(coordinates["permutation_index"]) is int
                   and coordinates["permutation_index"] in range(1, 4)) if negative
                  else coordinates["variant"] in A04_NEW_MICE_VARIANTS), "F5_A04_VARIANT_COORDINATES_INVALID")
    policy = load_science_authority()["science"]["modeling_seed_policy"]["model"]
    return policy["base"] + coordinates["outer_fold"] * policy["outer_multiplier"] + coordinates["imputation"]


def _validate_a04_variant_model_task(family: str, task: Mapping[str, Any]) -> list[dict] | None:
    from .f2_kernel import _locked_family_parameters, _validate_elastic_lambda_upper_bound
    seed = _a04_variant_model_seed(task["a04_coordinates"])
    stochastic = family in {"RSF", "GBM_COX", "XGBOOST_COX", "COXTIME_SET_A"}
    _require(not {"f4_coordinates", "a12_coordinates", "a19_coordinates", "c10_coordinates"}.intersection(task)
             and task.get("family") == family and type(task.get("imputation")) is int
             and task["imputation"] == task["a04_coordinates"]["imputation"]
             and type(task.get("registered_model_seed")) is int and task["registered_model_seed"] == seed
             and ((type(task.get("model_seed")) is int and task["model_seed"] == seed)
                  if stochastic else task.get("model_seed") is None), "F5_A04_VARIANT_MODEL_SEED_INVALID")
    source = task.get("a04_parameter_source")
    _require(isinstance(source, Mapping) and set(source) == {"selected_spec_sha256", "lambda_source_column_map"},
             "F5_A04_VARIANT_PARAMETER_SOURCE_INVALID")
    validate_sha256(source["selected_spec_sha256"], "f5.a04.original_outer_spec")
    if family != "ELASTIC_NET_COX":
        _locked_family_parameters(family, task["parameters"])
        _require(source["lambda_source_column_map"] is None
                 and sha256_bytes(canonical_json_bytes(task["parameters"])) == source["selected_spec_sha256"],
                 "F5_A04_VARIANT_ORIGINAL_PARAMETER_DRIFT")
        return None
    columns, parameters = source["lambda_source_column_map"], task["parameters"]
    _require(isinstance(columns, list) and bool(columns), "F5_A04_VARIANT_LAMBDA_SOURCE_REQUIRED")
    _validate_elastic_lambda_upper_bound(parameters.get("lambda_upper_bound"),
        alpha=parameters["alpha"], ordered_parent_column_map=columns)
    return columns


def _a04_temporal_applicability(frozen: Mapping[str, Any]) -> dict[str, Any]:
    """Derive the frozen input's absent calendar-date source, not a caller N/A."""
    from ._science_authority import VARIABLE_CATALOG_PATH, _load_variable_catalog

    authority = load_science_authority()
    contract = frozen["binding_contract"]
    # F1 keeps its original authority identity, already admitted by load_f4_inputs.
    # Only the date-relevant scientific projection must match current inputs.
    validate_sha256(contract.get("authority_sha256"), "f5.a04.temporal.f1_authority")
    raw, response = frozen["covariates_csv"], frozen["response_csv"]
    header = next(csv.reader(io.StringIO(raw.decode("utf-8-sig"))))
    response_header = next(csv.reader(io.StringIO(response.decode("utf-8-sig"))))
    catalog = _load_variable_catalog(VARIABLE_CATALOG_PATH)
    auxiliary = {"Patient_ID", "Center", "Weight_kg", "Height_cm", "RR", "Barthel_Admission",
                 "TP", "Urea", "Ca", "TT"}
    roles = {"ALTERNATIVE_RENAL_SENSITIVITY_ONLY", "BASELINE_PARENT", "DERIVED_FORCED_MODEL_PARENT",
             "ORDINARY_ELIGIBLE_MODEL_PARENT", "PRIMARY_RENAL_MODEL_PARENT",
             "RAW_BASELINE_SOURCE_MICE_AUXILIARY"}
    _require(set(contract) == {"schema_version", "kind", "authority_sha256", "workbook_sha256",
                              "covariates_sha256", "response_seal_sha256", "covariate_columns",
                              "response_columns", "registry"}
             and header == contract["covariate_columns"] == authority["science"]["mice"]["private_handoff"]["columns"]
             and response_header == contract["response_columns"]
                 == ["Patient_ID", "All_Cause_Death", "Death_Followup_months"]
             and sha256_bytes(raw) == contract["covariates_sha256"]
             and sha256_bytes(response) == contract["response_seal_sha256"]
             and set(header) - {row["variable"] for row in catalog} == auxiliary
             and all(row["type"] in {"continuous", "binary", "ordered", "unordered"}
                     and row["source_role"] in roles and row["measurement_time"] == "baseline" for row in catalog),
             "F5_A04_TEMPORAL_FROZEN_SOURCE_UNRESOLVED")
    return {"status": "NOT_APPLICABLE", "reason": "NO_APPROVED_BASELINE_CALENDAR_DATE_IN_FROZEN_INPUT",
            "f1_authority_sha256": contract["authority_sha256"],
            "binding_contract_sha256": sha256_bytes(canonical_json_bytes(contract)),
            "covariates_sha256": sha256_bytes(raw), "variable_catalog_sha256": sha256_file(VARIABLE_CATALOG_PATH),
            "covariate_columns": header, "response_columns": response_header,
            "date_fields": [], "cutoff": None, "model_fit_count": 0, "mice_chain_count": 0,
            "scope": "CURRENT_FROZEN_INPUT_ONLY_NEW_DATE_SOURCE_REQUIRES_EXPLICIT_ADMISSION",
            "selection_effect": "NONE"}


def _a04_p2c2t_reuse(f2_run_root: Path, inputs: Mapping[str, Any], family: str) -> dict[str, Any]:
    """Open three accepted originals; project the final family's outer diagnostics.

    The existing F2 acceptance owns numerical QC. Rebuild the source/task join,
    not fits or metrics, and do not relabel outer locks as full-data parameters.
    """
    from .f2 import F2_COMPONENTS, F2_FAMILIES, compile_f2_units
    from .f2_kernel import _p2c2t_model_grid, compile_p2c2t_registry
    from .run import load_run

    _require(family in F2_FAMILIES, "F5_A04_P2C2T_FAMILY_INVALID")
    frozen = inputs["o_fit_source"]
    raw = (f2_run_root / "f2-acceptance.json").read_bytes()
    _require(sha256_bytes(raw) == inputs["source"]["f2_acceptance_sha256"], "F5_A04_F2_ACCEPTANCE_DRIFT")
    acceptance, run = strict_json_bytes(raw), load_run(f2_run_root)
    models = _p2c2t_model_grid(list(frozen["models"].values()))
    units = compile_f2_units()
    models_by_unit = {}
    for unit in units[:42]:
        coordinates = {row["axis"]: row["value"] for row in unit["coordinates"]}
        models_by_unit[unit["unit_id"]] = frozen["models"][coordinates["outer_fold"], coordinates["family"]]
    model_set = [{key: row[key] for key in ("fold", "family", "selected_spec_sha256", "numeric_qc_sha256")}
                 for row in models]
    consumed = [{"unit_id": unit, "artifact_id": unit + ".unit_result",
                 "artifact_sha256": sha256_bytes(canonical_json_bytes(models_by_unit[unit])),
                 "result_sha256": acceptance["result_sha256"][unit]} for unit in models_by_unit]
    f2 = load_science_authority()["science"]["f2_model_development"]
    contract = f2["p2c2t_contract"]
    components = []
    for component, unit in zip(F2_COMPONENTS, units[42:45], strict=True):
        unit_id = unit["unit_id"]
        path = f2_run_root / "results" / (unit_id + ".zip")
        _require(path.is_file() and not path.is_symlink()
                 and sha256_file(path) == acceptance["result_sha256"][unit_id], "F5_A04_P2C2T_ACCEPTED_SOURCE_DRIFT")
        entries = read_safe_zip(path)
        manifest = strict_json_bytes(entries["manifest.json"])
        artifact, = manifest["artifacts"]
        payload = entries[artifact["relative_path"]]
        _require(manifest["unit_id"] == unit_id and manifest["run_id"] == run["run_id"]
                 and set(entries) == {"manifest.json", artifact["relative_path"]}
                 and len(payload) == artifact["size_bytes"] and sha256_bytes(payload) == artifact["sha256"],
                 "F5_A04_P2C2T_ARTIFACT_INVALID")
        value = strict_json_bytes(payload)
        registry = compile_p2c2t_registry(component, models, {"seed": unit["seed"]}, contract, f2["coxtime"])
        task_results = value["task_results"]
        _require(value["artifact_kind"] == "F2_P2C2T" and value["status"] == "PASS"
                 and value["component"] == component and value["seed"] == unit["seed"]
                 and value["selection_effect"] == "NONE" and value["contract"] == contract["components"][component]
                 and value["contract_sha256"] == sha256_bytes(canonical_json_bytes(contract))
                 and value["consumed_sources"] == consumed and value["model_result_count"] == 42
                 and value["model_result_set_sha256"] == sha256_bytes(canonical_json_bytes(model_set))
                 and value["f1_response_seal_sha256"] == frozen["binding_contract"]["response_seal_sha256"]
                 and value["task_registry"] == registry
                 and value["task_registry_sha256"] == sha256_bytes(canonical_json_bytes(registry))
                 and [row["task_id"] for row in task_results] == [row["task_id"] for row in registry["tasks"]]
                 and value["expected_task_count"] == value["executed_task_count"] == len(task_results)
                 and value["expected_fit_count"] == value["executed_fit_count"]
                    == sum(row["executed_fit_count"] for row in task_results), "F5_A04_P2C2T_SOURCE_JOIN_INVALID")
        selected_tasks = [row for row in registry["tasks"] if row["family"] == family]
        selected_ids = {row["task_id"] for row in selected_tasks}
        selected_results = [row for row in task_results if row["task_id"] in selected_ids]
        applicable = component != "LOCAL_PERTURBATION" or family in contract["local_registry_families"]
        _require(bool(selected_tasks) == applicable, "F5_A04_P2C2T_APPLICABILITY_INVALID")
        components.append({"component": component, "status": "REUSED_ACCEPTED_OUTER_DIAGNOSTIC" if applicable else "NOT_APPLICABLE",
            "reason": None if applicable else "LOCKED_FAMILY_OUTSIDE_ORIGINAL_LOCAL_PARAMETER_SCOPE",
            "source_unit": unit_id, "source_sha256": acceptance["result_sha256"][unit_id],
            "artifact_sha256": artifact["sha256"], "task_registry_sha256": value["task_registry_sha256"],
            "historical_all_family_task_count": len(task_results), "historical_all_family_fit_count": value["executed_fit_count"],
            "selected_family_task_count": len(selected_tasks),
            "selected_family_historical_fit_count": sum(row["executed_fit_count"] for row in selected_results),
            "scopes": [row for row in registry["scopes"] if row["family"] == family],
            "tasks": selected_tasks, "results": selected_results})
    return {"status": "ORIGINAL_ACCEPTED_ARTIFACTS_AND_SOURCE_TASK_JOINS_READ",
            "source": inputs["source"], "final_family": family, "components": components,
            "new_model_fit_count": 0, "new_mice_chain_count": 0, "selection_effect": "NONE",
            "scope": "ORIGINAL_OUTER_LOCKS_NOT_FINAL_FULL_DATA_MODEL_OR_FRESH_LEARNING_CURVE"}


def _a04_frozen_diagnostics(f2_run_root: Path, inputs: Mapping[str, Any], family: str) -> dict[str, Any]:
    return {"p2c2t": _a04_p2c2t_reuse(f2_run_root, inputs, family),
            "temporal": _a04_temporal_applicability(inputs["o_fit_source"])}


def _c10_predictor_contract() -> dict[str, Any]:
    """Expose the frozen passive alternative only to this zero-feedback action."""
    from .f2_kernel import predictor_contract
    root = Path(__file__).parent
    contract = predictor_contract(root)
    with (root / "science/variable.csv").open(encoding="utf-8", newline="") as handle:
        row, = [row for row in csv.DictReader(handle) if row["variable"] == "eGFR_calc"]
    _require(row["model_parent_eligible"] == "false" and row["selector_eligible"] == "false"
             and row["sensitivity_only"] == "true" and row["selector_representation"] == "NATURAL_SPLINE_K3",
             "F5_C10_FROZEN_ALTERNATIVE_INVALID")
    return {**contract, "variables": [*contract["variables"], {
        "name": row["variable"], "type": row["type"], "levels_or_coding": row["levels_or_coding"],
        **{key: row[key] == "true" for key in ("set_a_eligible", "selector_eligible", "forced")},
        "selector_representation": row["selector_representation"],
    }]}


def _c10_parent_column_map(selected: list[str], family: str, recipe: Mapping[str, Any]) -> list[dict]:
    from .f2_kernel import _expected_family_parent_column_map, _validate_recipe_representation_rows
    predictors = _c10_predictor_contract()
    transformed = family in {"COX_PH", "ELASTIC_NET_COX", "FPM_TVC_SET_A"}
    if "eGFR_calc" not in selected or not transformed:
        _require("c10_egfr_representation" not in recipe, "F5_C10_RECIPE_SCOPE_INVALID")
        return _expected_family_parent_column_map(selected, family, predictors, recipe["transform_recipe"])
    registry = [row for row in predictors["transform_registry"]["rows"] if row["parent"] == "eGFR_calc"]
    row = recipe.get("c10_egfr_representation")
    _require(isinstance(row, dict) and len(registry) == 1, "F5_C10_EGFR_RECIPE_REQUIRED")
    _, alternative = _validate_recipe_representation_rows(
        [row], [{"parent": "eGFR_calc", "columns": row.get("design_columns")}], predictors, registry)
    original = _expected_family_parent_column_map(
        [parent for parent in selected if parent != "eGFR_calc"], family, predictors, recipe["transform_recipe"])
    by_parent = {row["parent"]: row for row in [*original, *alternative]}
    return [by_parent[parent] for parent in selected]


def _c10_model_seed(coordinates: Mapping[str, Any]) -> int:
    _require(isinstance(coordinates, Mapping) and set(coordinates) == {"outer_fold", "imputation", "branch"}
             and type(coordinates["outer_fold"]) is int and coordinates["outer_fold"] in range(1, 7)
             and type(coordinates["imputation"]) is int and coordinates["imputation"] in range(1, 21)
             and coordinates["branch"] in C10_BRANCHES, "F5_C10_COORDINATES_INVALID")
    policy = load_science_authority()["science"]["modeling_seed_policy"]["model"]
    return policy["base"] + coordinates["outer_fold"] * policy["outer_multiplier"] + coordinates["imputation"]


def _validate_c10_model_task(family: str, task: Mapping[str, Any]) -> list[dict] | None:
    """Keep final lambda provenance separate from the new outer branch design."""
    from .f2_kernel import _expected_family_parent_column_map, _validate_elastic_lambda_upper_bound, predictor_contract
    seed = _c10_model_seed(task["c10_coordinates"])
    stochastic = family in {"RSF", "GBM_COX", "XGBOOST_COX", "COXTIME_SET_A"}
    _require(not {"f4_coordinates", "a12_coordinates", "a19_coordinates"}.intersection(task)
             and task.get("family") == family and type(task.get("imputation")) is int
             and task["imputation"] == task["c10_coordinates"]["imputation"]
             and type(task.get("registered_model_seed")) is int and task["registered_model_seed"] == seed
             and ((type(task.get("model_seed")) is int and task["model_seed"] == seed)
                  if stochastic else task.get("model_seed") is None), "F5_C10_MODEL_SEED_INVALID")
    source = task.get("final_parameter_source")
    _require(isinstance(source, Mapping) and set(source) == {"selected_parents", "parameters", "transform_recipe"}
             and isinstance(source["selected_parents"], list) and "Creatinine" in source["selected_parents"]
             and "eGFR_calc" not in source["selected_parents"]
             and task.get("selected_parents") == [task["c10_coordinates"]["branch"] if parent == "Creatinine" else parent
                                                   for parent in source["selected_parents"]]
             and task.get("parameters") == source["parameters"], "F5_C10_FINAL_PARAMETER_DRIFT")
    validate_sha256(task.get("final_parameter_lock_sha256"), "f5.c10.final_parameter_lock_sha256")
    if family != "ELASTIC_NET_COX":
        _require(source["transform_recipe"] is None, "F5_C10_FINAL_PARAMETER_DRIFT")
        return None
    predictors = predictor_contract(Path(__file__).parent)
    columns = _expected_family_parent_column_map(source["selected_parents"], family, predictors, source["transform_recipe"])
    parameters = source["parameters"]
    _validate_elastic_lambda_upper_bound(parameters.get("lambda_upper_bound"),
                                         alpha=parameters["alpha"], ordered_parent_column_map=columns)
    return columns


def _c10_egfr_representation(partition: Mapping[str, Any], root: Path) -> dict[str, Any]:
    """Original M20 training-only quantile/ns kernel, restricted to passive eGFR."""
    from .f2_kernel import _recipe_partition_projection, _validate_recipe_representation_rows
    predictors = _c10_predictor_contract()
    root.mkdir(mode=0o700)
    inputs = root / "training-inputs"
    inputs.mkdir(mode=0o700)
    projection = _recipe_partition_projection({"partitions": [partition]}, partition["partition_id"], predictors, inputs)
    rows = [row for row in predictors["transform_registry"]["rows"] if row["parent"] == "eGFR_calc"]
    _require(len(rows) == 1, "F5_C10_FROZEN_ALTERNATIVE_INVALID")
    projection["recipe_registry_record"]["registry"]["rows"] = rows
    output = root / "native-values.json"
    spec = root / "projection.json"
    spec.write_bytes(canonical_json_bytes({"action": "COMPILE_C10_EGFR_RECIPE", "projection": projection,
                                          "output_path": str(output)}))
    try:
        with (root / "stdout.log").open("wb") as stdout, (root / "stderr.log").open("wb") as stderr:
            completed = subprocess.run([RSCRIPT_EXECUTABLE, str(Path(__file__).parent / "kernels/f5_final_refit.R"), str(spec)],
                                       env={**os.environ, **THREAD_ENV}, stdout=stdout, stderr=stderr, check=False)
        _require(completed.returncode == 0 and output.is_file(), "F5_C10_EGFR_RECIPE_FAILED")
        value = strict_json_bytes(output.read_bytes())
        _require(isinstance(value, dict) and set(value) == {"partition_id", "representations", "ordered_parent_column_map"}
                 and value["partition_id"] == partition["partition_id"], "F5_C10_EGFR_RECIPE_INVALID")
        representations, _ = _validate_recipe_representation_rows(
            value["representations"], value["ordered_parent_column_map"], predictors, rows)
        return representations[0]
    except BaseException as exc:
        exc.add_note(f"F5_C10_EGFR_RECIPE_EVIDENCE_RETAINED:{root}")
        raise


def _c10_context(f2_run_root: Path, lineage: Mapping[str, Any], *,
                 f1_runtime_root: Path | None = None) -> dict[str, Any]:
    from .f4 import load_f4_inputs
    from .f5 import _validate_final_aggregate_lineage
    final_tasks = _validate_final_aggregate_lineage(lineage)
    selected = lineage["final_seta"]["lock"]["selected_parents"]
    _require("Creatinine" in selected and "eGFR_calc" not in selected, "F5_C10_NOT_APPLICABLE_NO_EXECUTION")
    inputs = load_f4_inputs(f2_run_root, include_o_fit_source=True, f1_runtime_root=f1_runtime_root)
    frozen = inputs["o_fit_source"]
    selectors = {row["fold"]: row for row in lineage["final_seta_selector_results"]}
    _require(selectors == {outer: frozen["models"][outer, "ELASTIC_NET_COX"] for outer in range(1, 7)},
             "F5_C10_ACCEPTED_SELECTOR_SOURCE_MISMATCH")
    ids = lineage["final_mice"]["fit_ids"]
    _require(sha256_bytes(frozen["response_csv"]) == lineage["final_mice"]["fit_response"]["sha256"]
             and ids == list(_response_rows(frozen["response_csv"])[1])
             and lineage["centers"] == [frozen["centers"][patient] for patient in ids],
             "F5_C10_FROZEN_POPULATION_MISMATCH")
    return {"lineage": lineage, "final_tasks": final_tasks, "frozen": frozen,
            "source": {**inputs["source"], "final_lineage_sha256": sha256_bytes(canonical_json_bytes(lineage))}}


def _prepare_c10_outer(context: Mapping[str, Any], outer: int, root: Path) -> list[dict[str, Any]]:
    """Read one original outer M20; replace neither its MICE nor final parameters."""
    from .f2_kernel import (
        _expected_family_parent_column_map, _recipe_by_partition, _recipe_training_member_bytes,
        _registered_partition_identity_record, _validate_transform_recipe_set,
    )
    from .f4 import _materialize_o_fit_fold
    from .f5 import _validate_final_design_recipe
    _require(type(outer) is int and outer in range(1, 7), "F5_C10_OUTER_INVALID")
    frozen, lineage = context["frozen"], context["lineage"]
    family = lineage["final_family"]
    registered = _materialize_o_fit_fold(frozen, outer, root / "f1")
    partition, = [row for row in registered["partitions"] if row["kind"] == "OUTER"]
    source, = [row for row in frozen["registry"]["outer"] if row["outer_fold"] == outer]
    model = frozen["models"][outer, family]
    original, = [row for row in model["model_input"]["model_partitions"] if row["kind"] == "OUTER"]
    _require(_registered_partition_identity_record(partition) == original
             and partition["fit_ids"] == source["analysis_ids"]
             and partition["evaluation_ids"] == source["validation_ids"]
             and partition["application_ids"] == source["application_ids"], "F5_C10_F1_OUTER_MISMATCH")
    fit_ids, evaluation_ids = partition["fit_ids"], partition["evaluation_ids"]
    fields, responses = _response_rows(frozen["response_csv"])
    fit_response = _write_response_subset(fields, responses, fit_ids, None)
    _require(Path(partition["fit_response"]["path"]).read_bytes() == fit_response["private_bytes"]
             and fit_response["sha256"] == original["fit_response_sha256"], "F5_C10_TRAINING_RESPONSE_MISMATCH")
    predictors = _c10_predictor_contract()
    recipes = _validate_transform_recipe_set(model["selector_evidence"]["recipe_set"], predictors, expected_count=16)
    original_recipe = _recipe_by_partition(recipes, partition["partition_id"])
    _require(original_recipe["training_member_set_sha256"] == original["fit_covariate_member_set_sha256"]
             and original_recipe["fit_ids_sha256"] == original["fit_ids_sha256"]
             and original_recipe["analysis_view_sha256"] == original["analysis_view_sha256"],
             "F5_C10_TRAINING_RECIPE_MISMATCH")
    transformed = family in {"COX_PH", "ELASTIC_NET_COX", "FPM_TVC_SET_A"}
    alternative = _c10_egfr_representation(partition, root / "egfr-recipe") if transformed else None
    selected = lineage["final_seta"]["lock"]["selected_parents"]
    original_common = _expected_family_parent_column_map(selected, "ELASTIC_NET_COX", predictors, original_recipe)
    common_df = sum(len(row["columns"]) for row in original_common)
    _require(next(row for row in original_common if row["parent"] == "Creatinine")["columns"] == ["Creatinine__LOG1P"],
             "F5_C10_FROZEN_ALTERNATIVE_INVALID")
    covariates = partition["covariates"]
    _require([row["name"] for row in covariates["members"]] == [f"imp{i:02d}.csv" for i in range(1, 21)],
             "F5_C10_M20_REQUIRED")
    datasets = []
    for imp, (member, fit_member) in enumerate(zip(covariates["members"], original["fit_covariate_members"], strict=True), 1):
        path = Path(covariates["input_dir"]) / member["name"]
        raw = path.read_bytes()
        rows = list(csv.DictReader(io.StringIO(raw.decode("utf-8-sig"))))
        _require(len(raw) == member["size_bytes"] and sha256_bytes(raw) == member["sha256"]
                 and [row["Patient_ID"] for row in rows] == source["application_ids"]
                 and all(row["Center"] == frozen["centers"][row["Patient_ID"]] for row in rows),
                 "F5_C10_COMPLETED_M20_MISMATCH")
        training = _recipe_training_member_bytes(path, fit_ids)
        _require(fit_member == {"name": member["name"], "sha256": sha256_bytes(training), "size_bytes": len(training)},
                 "F5_C10_TRAINING_M20_MISMATCH")
        datasets.append((training, _recipe_training_member_bytes(path, evaluation_ids)))
    jobs = []
    for branch in C10_BRANCHES:
        parents = [branch if parent == "Creatinine" else parent for parent in selected]
        recipe = {
            "schema_version": "1.0.0", "kind": "PADML_F5_FINAL_DESIGN_RECIPE_V1", "family": family,
            "selected_parents": parents,
            "preprocessing_mode": "F2_LOCKED_TRANSFORM_RECIPE" if transformed else "F2_RAW_CANONICAL_AUTHORITY_LEVELS",
            "predictor_contract_sha256": sha256_bytes(canonical_json_bytes(predictors)),
            "predictor_rows": [row for row in predictors["variables"] if row["name"] in parents],
            "transform_recipe": original_recipe if transformed else None,
            "coxtime_standardization": "FIT_IMPUTATION_Z_SCORE" if family == "COXTIME_SET_A" else None,
            **({"c10_egfr_representation": alternative} if transformed and branch == "eGFR_calc" else {}),
        }
        _validate_final_design_recipe(recipe, family=family, selected_parents=parents, c10=True)
        design_count = sum(len(row["columns"]) for row in _c10_parent_column_map(parents, family, recipe))
        branch_common_df = common_df + int(branch == "eGFR_calc")
        _require(fit_response["event_count"] / branch_common_df >= 15
                 and design_count > 0 and fit_response["event_count"] / design_count >= 15,
                 "F5_C10_TRAINING_EPV_INFEASIBLE")
        for imp, (training, application) in enumerate(datasets, 1):
            coordinates = {"outer_fold": outer, "branch": branch, "imputation": imp}
            seed = _c10_model_seed(coordinates)
            parameters = context["final_tasks"][imp]["parameters"]
            task = {"family": family, "selected_parents": parents, "parameters": parameters,
                    "imputation": imp, "c10_coordinates": coordinates, "registered_model_seed": seed,
                    "model_seed": seed if family in {"RSF", "GBM_COX", "XGBOOST_COX", "COXTIME_SET_A"} else None,
                    "row_count": len(fit_ids), "family_design_column_count": design_count,
                    "common_set_design_df": branch_common_df, "training_event_count": fit_response["event_count"],
                    "final_parameter_lock_sha256": lineage["final_parameter_lock"]["identity_sha256"],
                    "final_parameter_source": {"selected_parents": selected, "parameters": parameters,
                        "transform_recipe": lineage["final_recipe"]["recipe"]["transform_recipe"] if family == "ELASTIC_NET_COX" else None}}
            _validate_c10_model_task(family, task)
            jobs.append({"name": f"O{outer}_{branch}_M{imp:02d}", "entries": {
                "task.json": canonical_json_bytes(task), "recipe.json": canonical_json_bytes(recipe),
                "fit-covariates.csv": training, "fit-response.csv": fit_response["private_bytes"],
                "prediction-covariates.csv": application}})
    _require(len(jobs) == 40 and len({job["name"] for job in jobs}) == 40, "F5_C10_M20_REQUIRED")
    return jobs


def _ablation_component_inputs(entries: Mapping[str, bytes]) -> tuple:
    _require(set(entries) == {"task.json", "recipe.json", "fit-covariates.csv", "fit-response.csv", "prediction-covariates.csv"},
             "F5_ABLATION_NATIVE_INPUT_INVALID")
    task, recipe = strict_json_bytes(entries["task.json"]), strict_json_bytes(entries["recipe.json"])
    label = "A04" if "a04_coordinates" in task else "A12" if "a12_coordinates" in task else "C10"
    if label == "A04":
        _validate_a04_variant_model_task(task["family"], task)
    elif label == "A12":
        from .f5 import _validate_a12_model_task
        _validate_a12_model_task(task["family"], task)
    else:
        _validate_c10_model_task(task["family"], task)
    training, application = [list(csv.DictReader(io.StringIO(entries[name].decode("utf-8-sig"))))
                             for name in ("fit-covariates.csv", "prediction-covariates.csv")]
    response = _response_rows(entries["fit-response.csv"])[1]
    fit_ids, ids = [[row["Patient_ID"] for row in rows] for rows in (training, application)]
    _require(fit_ids == list(response) and len(fit_ids) == len(set(fit_ids)) == task["row_count"]
             and len(ids) == len(set(ids)) > 0 and set(fit_ids).isdisjoint(ids)
             and all(not {"All_Cause_Death", "Death_Followup_months"}.intersection(row) for row in [*training, *application]),
             f"F5_{label}_TRAINING_ISOLATION_INVALID")
    if label == "A12" and task.get("nested_aar_final_source") is not None:
        _require(sum(int(row["All_Cause_Death"]) for row in response.values()) == task["training_event_count"],
            "F5_A12_OUTER_SETA_EPV_INVALID")
    if label == "A12" and task["a12_coordinates"]["branch"] in {
            "A12_WITHOUT_AST_ALT_TOTAL", "OUTER_SELECTED_FAMILY_NO_AAR_REDEVELOPMENT"}:
        _require(all(not {"AST", "ALT", "AST_ALT"}.intersection(row) for row in [*training, *application]),
                 "NESTED_AAR_FINAL_INFORMATION_CHANNEL_PRESENT")
    return task, recipe, training, response, application


def _ablation_prediction(task: Mapping[str, Any], rows: list[dict], survival: list) -> dict[str, Any]:
    label = "A04" if "a04_coordinates" in task else "A12" if "a12_coordinates" in task else "C10"
    coordinate_key = label.lower() + "_coordinates"
    ids = [row["Patient_ID"] for row in rows]
    _seal_prediction_matrix(ids, survival, HORIZONS)
    _require(all(row[0] == 1.0 for row in survival), f"F5_{label}_MONTH_ZERO_INVALID")
    return {coordinate_key: task[coordinate_key], "family": task["family"], "patient_ids": ids,
            "centers": [row["Center"] for row in rows], "horizons": HORIZONS, "survival": survival}


def _ablation_component_numbers(expected: Mapping[str, bytes], value: Mapping[str, Any], *,
                                reuse_root: Path | None = None,
                                consumer_source: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """Read the original first-audit values against this branch's real inputs."""
    from .bundle import validate_sha256
    from .f2_kernel import _expected_family_parent_column_map, _locked_family_parameters, _validate_python_fit_health, predictor_contract
    from .f5 import _validate_final_design_recipe, _validate_final_r_fit_health, _validate_retained_r_audit_numbers
    task, recipe, training, response, application = _ablation_component_inputs(expected)
    family = task["family"]
    if isinstance(value, Mapping) and "reused_final" in value:
        _require(reuse_root is not None and consumer_source is not None,
                 "F45_AAR_FINAL_REUSE_SOURCE_REQUIRED")
        rebuilt = _a12_final_reuse_read(consumer_source, reuse_root, expected, value["reused_final"])
        _require(rebuilt == value, "F45_AAR_FINAL_REUSE_NUMBERS_DRIFT")
        value = {key: item for key, item in value.items() if key != "reused_final"}
    a04 = 'a04_coordinates' in task
    lambda_columns = _validate_a04_variant_model_task(family,task) if a04 else None
    _require(("nested_aar_final_source" in task or a04) and isinstance(value, Mapping) and set(value) == {
        "input_members", "prediction", "training_prediction", "fit_health", "object_audit",
        "model_sha256", "baseline_sha256", "native_archive", "native_expanded_bytes"}, "F5_A12_FINAL_NUMBERS_REQUIRED")
    _require(value["input_members"] == {name: {"sha256": sha256_bytes(raw), "size_bytes": len(raw)}
        for name, raw in sorted(expected.items())}, "F5_A12_FINAL_NUMBERS_INPUT_DRIFT")
    native = value["native_archive"]
    _require(isinstance(native, Mapping) and set(native) == {"sha256", "size_bytes"}
             and type(native["size_bytes"]) is int and native["size_bytes"] > 0,
             "F5_A12_FINAL_NUMBERS_NATIVE_REFERENCE_INVALID")
    _require(type(value["native_expanded_bytes"]) is int and value["native_expanded_bytes"] > 0,
             "F5_A12_FINAL_NUMBERS_NATIVE_REFERENCE_INVALID")
    for digest in (value["model_sha256"], value["baseline_sha256"], native["sha256"]):
        validate_sha256(digest, "a12.final.native")
    for name, rows in (("prediction", application), ("training_prediction", training)):
        prediction = value[name]
        _require(isinstance(prediction, Mapping) and isinstance(prediction.get("survival"), list)
                 and prediction == _ablation_prediction(task, rows, prediction["survival"]),
                 "F5_A12_FINAL_NUMBERS_PREDICTION_DRIFT")
    _validate_final_design_recipe(recipe, family=family, selected_parents=task["selected_parents"])
    columns_by_parent = _expected_family_parent_column_map(task["selected_parents"], family,
        predictor_contract(Path(__file__).parent), recipe["transform_recipe"])
    columns = [column for row in columns_by_parent for column in row["columns"]]
    if family in {"XGBOOST_COX", "COXTIME_SET_A"}:
        columns.sort(key=lambda name: name.encode())
    health, audit = value["fit_health"], value["object_audit"]
    events = sum(int(row["All_Cause_Death"]) for row in response.values())
    _require(isinstance(health, Mapping) and isinstance(audit, Mapping)
             and audit.get("design_columns") == columns and task["family_design_column_count"] == len(columns),
             "F5_A12_FINAL_NUMBERS_DESIGN_DRIFT")
    _require(task["training_event_count"] == events
             and (family not in {"COX_PH", "FPM_TVC_SET_A"} or audit.get("training_event_count") == events),
             "F5_A12_FINAL_NUMBERS_EVENT_DENOMINATOR_DRIFT")
    if family in {"XGBOOST_COX", "COXTIME_SET_A"}:
        locked = task["parameters"]["selected_rounds" if family == "XGBOOST_COX" else "locked_epoch"]
        _validate_python_fit_health(family, health, locked_value=locked,
            training_count=len(training), evaluation_count=len(training))
        _require(audit == {"design_columns": columns,
            **({"booster_round_count": locked} if family == "XGBOOST_COX" else {"input_width": len(columns)})},
            "F5_A12_FINAL_NUMBERS_AUDIT_DRIFT")
        _require(family != "XGBOOST_COX" or health.get("model_binary_sha256") == value["model_sha256"],
                 "F5_A12_FINAL_NUMBERS_MODEL_BINDING_DRIFT")
    else:
        _validate_final_r_fit_health(family, health,
            (_locked_family_parameters(family, task["parameters"])
             if family in {"RSF", "GBM_COX"} else task["parameters"]),
            ordered_parent_column_map=columns_by_parent, training_count=len(training), a12=not a04,
            lambda_source_column_map=lambda_columns)
        _validate_retained_r_audit_numbers(family, audit, health, task)
    return dict(value["prediction"])


def _validate_a12_whole_artifacts(artifacts):
    """A whole AAR may retain its one original completed-consumer report."""
    failure = "F45_AAR_WHOLE_ARTIFACTS_INVALID"
    base = {"input.zip", "input.compile.json", "result.zip"}
    from .carriers import run_context
    if run_context() is not None and isinstance(artifacts, Mapping):
        base |= {name for name in artifacts if name == "mice.zip" or
                 re.fullmatch(r"result\.zip\.work/fits/O[1-6]_[A-Z0-9_]+_M(0[1-9]|1[0-9]|20)\.zip", name)}
    _require(isinstance(artifacts, Mapping) and base <= set(artifacts)
             and len(set(artifacts) - base) <= 1, failure)
    for name in set(artifacts) - base:
        parts = Path(name).parts
        _require(len(parts) == 2 and parts[1] == "execution.json"
                 and re.fullmatch(r"padml-a12-outer-replay-[a-zA-Z0-9_-]+", parts[0]) is not None
                 and str(Path(name)) == name, failure)
        pin = artifacts[name]
        _require(isinstance(pin, Mapping) and set(pin) == {"sha256", "size_bytes"}
                 and type(pin["size_bytes"]) is int and 0 < pin["size_bytes"] <= 64 * 1024**2, failure)
        validate_sha256(pin["sha256"], failure)


def _a12_final_reuse_source(proof, current, authorities):
    """Qualify a completed whole AAR and both independently bound PRIMARYs."""
    from . import nested_loco as nested
    failure = "F45_AAR_FINAL_REUSE_SOURCE_INVALID"
    _require(isinstance(proof, Mapping) and set(proof) == {
        "kind", "whole_unit", "result_metadata", "execution", "identity_sha256"}
        and proof["kind"] == "PADML_F45_AAR_FINAL_REUSE_SOURCE_V1"
        and proof["identity_sha256"] == nested._sha({k: v for k, v in proof.items()
                                                   if k != "identity_sha256"}), failure)
    result, receipt, execution = (proof[key] for key in ("result_metadata", "whole_unit", "execution"))
    previous = result["source"]
    original = _a12_nested_mice_source({**previous["primary_source"], "estimand": nested.A12_TOTAL_AAR})
    consumer = _a12_nested_mice_source({**current["primary_source"], "estimand": nested.A12_TOTAL_AAR})
    horizon = previous["primary_source"]["primary_development_lock"]["selection_horizon_months"]
    unit = f"AAR-H{horizon:02d}-O{consumer['outer_fold']}"
    executors, sources = authorities
    _validate_a12_whole_artifacts(receipt.get("artifacts", {}))
    _require(receipt.get("status") == "COMPLETED" and receipt.get("direct_consumer_completed") is True
        and receipt.get("unit_id") == unit and receipt.get("selection_horizon_months") == horizon
        and receipt.get("report_horizons_months") == [6, 12, 24, 36]
        and receipt.get("run_identity") in executors
        and execution.get("executor_source_identity") in executors.values()
        and execution["executor_source_identity"] in sources
        and original["modeling_program_sha256"] in sources
        and consumer["modeling_program_sha256"] in sources
        and horizon != current["primary_source"]["primary_development_lock"]["selection_horizon_months"]
        and result.get("kind") == "PADML_F5_A12_OUTER_NATIVE_V2"
        and result.get("outer_fold") == previous["outer_fold"] == current["outer_fold"] == consumer["outer_fold"]
        and result.get("family") == previous["family"] == current["family"]
            == previous["primary_source"]["primary_development_lock"]["selected_family"]
            == current["primary_source"]["primary_development_lock"]["selected_family"]
        and result["members"].get("execution.json") == {
            "sha256": nested._sha(execution), "size_bytes": len(canonical_json_bytes(execution))}, failure)
    ignored = {"identity_sha256", "modeling_program_sha256", "preprocessing_program_sha256"}
    _require({k: v for k, v in original.items() if k not in ignored}
             == {k: v for k, v in consumer.items() if k not in ignored}, failure)
    names = {f"fits/O{consumer['outer_fold']}_{branch}_M{imp:02d}" for branch in _a12_estimable_branches(result)
             for imp in range(1, 21)}
    _require(set(result.get("native_members", {})) == {name + ".zip" for name in names}
             and {name + ".numbers.json" for name in names} <= set(result["members"]), failure)
    for value in (current, previous, result):
        _require(value.get("identity_sha256") == nested._sha({k: v for k, v in value.items()
                                                             if k != "identity_sha256"}), failure)
    return unit


def _a12_final_reuse_read(source, root, entries, binding):
    """Read unchanged producer objects/audit, then bind the current branch inputs."""
    from .f5 import _f45_final_native_objects, _f45_score_reuse_authorities
    from . import nested_loco as nested
    failure = "F45_AAR_FINAL_REUSE_SOURCE_DRIFT"
    task, _, _, _, _ = _ablation_component_inputs(entries)
    coordinates = task["a12_coordinates"]
    name = f"O{coordinates['outer_fold']}_{coordinates['branch']}_M{coordinates['imputation']:02d}"
    _require(isinstance(binding, Mapping) and set(binding) == {"source", "component"}
             and binding["component"] == name, failure)
    pin = binding["source"]
    _require(isinstance(pin, Mapping) and set(pin) == {"path", "sha256", "size_bytes"}
        and pin["path"] in {f"final-reuse/AAR-H{h:02d}-O{coordinates['outer_fold']}/source.json"
                            for h in (6, 12, 24, 36)}, failure)

    def read(path, expected):
        _require(path.is_file() and not path.is_symlink() and path.resolve(strict=True) == path
            and type(expected["size_bytes"]) is int and 0 < expected["size_bytes"] <= 32 * 1024**2
            and path.stat().st_size == expected["size_bytes"], failure)
        raw = path.read_bytes()
        value = strict_json_bytes(raw)
        _require(sha256_bytes(raw) == expected["sha256"] and canonical_json_bytes(value) == raw, failure)
        return value

    location = root / pin["path"]
    proof = read(location, pin)
    _require(location.parent.name == _a12_final_reuse_source(proof, source, _f45_score_reuse_authorities()), failure)
    result = proof["result_metadata"]
    number_member = f"fits/{name}.numbers.json"
    original = read(location.parent / number_member, result["members"][number_member])
    _require("reused_final" not in original
             and original["native_archive"] == result["native_members"][f"fits/{name}.zip"], failure)
    objects = _f45_final_native_objects(root / "fits" / (name + ".zip"), entries, original)
    origin_task = strict_json_bytes(objects["task.json"])
    for current_task, declared, inputs in ((task, source, entries), (origin_task, result["source"], objects)):
        primary, bound = declared["primary_source"], current_task["nested_aar_final_source"]
        context = nested.validate_training_context(primary["primary_training_context"], inputs["fit-response.csv"])
        _, _, training, _, application = _ablation_component_inputs({name: inputs[name] for name in entries})
        _require(current_task["family"] == declared["family"]
            and current_task["a12_coordinates"]["outer_fold"] == context["outer_fold"]
            and [row["Patient_ID"] for row in training] == context["training_ids"]
            and [row["Patient_ID"] for row in application] == context["heldout_ids"]
            and bound["primary_development_lock_sha256"] == primary["primary_development_lock"]["identity_sha256"]
            and bound["training_context_sha256"] == primary["primary_training_context"]["identity_sha256"]
            and bound["science_decision_sha256"] == primary["science_decision"]["identity_sha256"]
            and bound["selection_horizon_months"] == primary["primary_development_lock"]["selection_horizon_months"], failure)
    current = {**original, "input_members": {name: {"sha256": sha256_bytes(raw), "size_bytes": len(raw)}
                for name, raw in sorted(entries.items())}}
    _ablation_component_numbers(entries, current)
    return {**current, "reused_final": dict(binding)}


def _a12_final_reuse_job(item):
    """Retain and consume one branch MI, without changing candidate priority."""
    from . import nested_loco as nested
    from .f5 import _f45_final_component_numerics, _f45_retain_final_object
    from .bundle import _validated_zip_infos
    source, root, job, binding = (item[k] for k in ("source", "root", "job", "binding"))
    name, destination = job["name"], Path(job["root"])
    failure = "F45_AAR_FINAL_REUSE_SOURCE_DRIFT"
    if "candidate" not in item:
        value = _a12_final_reuse_read(source, root, job["entries"], binding)
        nested._write_exact_once(destination.with_suffix(".numbers.json"), canonical_json_bytes(value), failure)
        return {"numbers": value}
    owner, result, location = item["candidate"], item["result"], item["location"]
    def member(archive, name):
        infos = [info for info in archive.infolist() if info.filename == name]
        _require(len(infos) == 1 and 0 < infos[0].file_size <= 32 * 1024**2, failure)
        raw = archive.read(infos[0])
        value = strict_json_bytes(raw)
        _require(canonical_json_bytes(value) == raw, failure)
        return raw, value
    with open_carrier(owner / "result.zip") as archive:
        raw, numbers = member(archive, f"fits/{name}.numbers.json")
        _require(result["members"][f"fits/{name}.numbers.json"] == {
            "sha256": sha256_bytes(raw), "size_bytes": len(raw)}, failure)
        if "reused_final" in numbers:
            return {"numbers": None}  # Only the first complete whole producer owns the fit.
        native_member = f"fits/{name}.zip"
        pin = result["native_members"][native_member]
        _require(numbers["native_archive"] == pin, failure)
        native = owner / "result.zip.work" / native_member
        carried = native_member in result["members"]
        if not carried and not native.is_file():
            return {"numbers": None}  # A model digest without original bytes is a miss.
        _require(pin["size_bytes"] < job["retained_bytes_per_component"], failure)
        if carried:
            _require(result["members"][native_member] == pin
                     and archive.getinfo(native_member).file_size == pin["size_bytes"], failure)
            with archive.open(native_member) as payload, open_carrier(payload) as model:
                _validated_zip_infos(model, set(job["entries"]) | {"model.bin", "baseline.bin",
                    "fit-health.json", "training-prediction.json", "prediction.json"},
                    max_member_bytes=job["retained_bytes_per_component"],
                    max_total_bytes=job["retained_bytes_per_component"], max_compression_ratio=1000)
                original = {key: model.read(key) for key in job["entries"]}
        else:
            _require(native.resolve(strict=True) == native and native.stat().st_size == pin["size_bytes"]
                     and sha256_file(native) == pin["sha256"], failure)
            with open_carrier(native) as model:
                _validated_zip_infos(model, set(job["entries"]) | {"model.bin", "baseline.bin",
                    "fit-health.json", "training-prediction.json", "prediction.json"},
                    max_member_bytes=job["retained_bytes_per_component"],
                    max_total_bytes=job["retained_bytes_per_component"], max_compression_ratio=1000)
                original = {key: model.read(key) for key in job["entries"]}
        if _f45_final_component_numerics(original) != _f45_final_component_numerics(job["entries"]):
            return {"numbers": None}
        nested._write_exact_once(location.parent / f"fits/{name}.numbers.json", raw, failure)
        destination = Path(job["root"])
        nested._write_exact_once(destination.with_suffix(".reuse.json"), canonical_json_bytes(binding), failure)
        with (archive.open(native_member) if carried else native.open("rb")) as payload:
            _f45_retain_final_object(payload, destination.with_suffix(".zip"), pin)
        value = _a12_final_reuse_read(source, root, job["entries"], binding)
        nested._write_exact_once(destination.with_suffix(".numbers.json"), canonical_json_bytes(value), failure)
        return {"numbers": value}


def _prepare_a12_final_reuse(prepared, root, jobs):
    """Reuse only unstarted MI after native branch development and parameter binding."""
    from . import nested_loco as nested
    from .f5 import _f45_score_reuse_authorities
    from .runtime import observe_execution_resources, _readback_ordered, release_f45_cumulative_files
    failure = "F45_AAR_FINAL_REUSE_SOURCE_DRIFT"
    found, wanted, pending, completed = {}, {}, {}, []
    for job in jobs:
        name, directory = job["name"], Path(job["root"])
        marker, archive = directory.with_suffix(".reuse.json"), directory.with_suffix(".zip")
        if marker.exists():
            _require(marker.is_file() and not marker.is_symlink(), failure)
            raw = marker.read_bytes()
            binding = strict_json_bytes(raw)
            _require(raw == canonical_json_bytes(binding), failure)
            if archive.is_file():
                completed.append(dict(source=prepared["source"], root=root, job=job, binding=binding))
            else:
                pending[name], wanted[name] = binding, job
        elif not any(path.exists() for path in (directory, archive, directory.with_suffix(".numbers.json"))):
            wanted[name] = job
    policy = prepared["source"]["resource_policy"]
    reserve = 32 * (len(canonical_json_bytes(prepared["source"])) + sum(sum(map(len, j["entries"].values())) for j in jobs))
    if completed:
        returned = sum((root / Path(item["binding"]["source"]["path"]).parent / "fits" /
            (item["job"]["name"] + ".numbers.json")).stat().st_size for item in completed)
        values = _readback_ordered(_a12_final_reuse_job, completed, policy=policy, root=root,
            per_worker_bytes=32 * max(Path(item["job"]["root"]).with_suffix(".zip").stat().st_size for item in completed),
            retained_bytes=reserve + 32 * returned,
            cache_files=(path for item in completed for path in (
                root / item["binding"]["source"]["path"],
                root / Path(item["binding"]["source"]["path"]).parent / "fits" / (item["job"]["name"] + ".numbers.json"),
                *(Path(item["job"]["root"]).with_suffix(suffix)
                  for suffix in (".zip", ".numbers.json", ".reuse.json"))) if path.is_file()))
        found.update((item["job"]["name"], value["numbers"]) for item, value in zip(completed, values, strict=True))
    candidates = prepared.get("completed_aar_units", [])
    authorities = _f45_score_reuse_authorities() if candidates and wanted else None

    def member(archive, name):
        infos = [info for info in archive.infolist() if info.filename == name]
        _require(len(infos) == 1 and 0 < infos[0].file_size <= 32 * 1024**2, failure)
        raw = archive.read(infos[0])
        value = strict_json_bytes(raw)
        _require(canonical_json_bytes(value) == raw, failure)
        return raw, value

    for candidate in candidates:
        if not wanted:
            break
        _require(isinstance(candidate, Mapping) and set(candidate) == {"root", "receipt"}, failure)
        owner, receipt = Path(candidate["root"]), candidate["receipt"]
        _require(owner.is_absolute() and owner.resolve(strict=True) == owner
            and (owner / "unit.json").read_bytes() == canonical_json_bytes(receipt), failure)
        for name, pin in receipt["artifacts"].items():
            path = owner / name
            _require(not Path(name).is_absolute() and ".." not in Path(name).parts
                and path.is_file() and path.resolve(strict=True) == path
                and {"sha256": sha256_file(path), "size_bytes": path.stat().st_size} == pin, failure)
        # Whole-artifact hashes close before either reuse or Q readback admission.
        release_f45_cumulative_files([owner / name for name in receipt["artifacts"]],
            owner="AAR_FINAL_REUSE_HASHED_INPUTS", report_root=root,
            released_references=["closed_a12_final_reuse_artifact_hash_streams"])
        with open_carrier(owner / "result.zip") as archive:
            _, result = member(archive, "a12-outer.json")
            if result["family"] != prepared["family"]:
                continue
            _, execution = member(archive, "execution.json")
            proof = nested._sealed({"kind": "PADML_F45_AAR_FINAL_REUSE_SOURCE_V1", "whole_unit": receipt,
                                    "result_metadata": result, "execution": execution})
            unit = _a12_final_reuse_source(proof, prepared["source"], authorities)
            _require(owner.name == unit, failure)
            proof_raw = canonical_json_bytes(proof)
            location = root / "final-reuse" / unit / "source.json"
            source_pin = {"path": location.relative_to(root).as_posix(),
                          "sha256": sha256_bytes(proof_raw), "size_bytes": len(proof_raw)}
            eligible = [(name, wanted[name], {"source": source_pin, "component": name})
                for name in sorted(wanted)
                if f"fits/{name}.zip" in result["native_members"]
                and (name not in pending or pending[name] == {"source": source_pin, "component": name})]
            if not eligible:
                continue
            _require(observe_execution_resources(root)["scratch_available_bytes"] >= 2 * (len(proof_raw)
                + sum(job["retained_bytes_per_component"] for _, job, _ in eligible)),
                "F45_AAR_FINAL_REUSE_STORAGE_INSUFFICIENT")
            location.parent.joinpath("fits").mkdir(parents=True, exist_ok=True)
            nested._write_exact_once(location, proof_raw, failure)
            read_jobs = [dict(source=prepared["source"], root=root, job=job, binding=binding,
                candidate=owner, result=result, location=location) for _, job, binding in eligible]
            values = _readback_ordered(_a12_final_reuse_job, read_jobs, policy=policy, root=root,
                per_worker_bytes=32 * (len(proof_raw) + max(result["native_members"][f"fits/{name}.zip"]["size_bytes"]
                    for name, _, _ in eligible)),
                retained_bytes=reserve + 32 * (len(proof_raw) + sum(result["members"][f"fits/{name}.numbers.json"]["size_bytes"]
                    for name, _, _ in eligible)),
                cache_files=(path for item in read_jobs for path in (
                    item["candidate"] / "result.zip", item["location"],
                    item["location"].parent / "fits" / (item["job"]["name"] + ".numbers.json"),
                    *(Path(item["job"]["root"]).with_suffix(suffix)
                      for suffix in (".zip", ".numbers.json", ".reuse.json")),
                    *((item["candidate"] / "result.zip.work/fits" / (item["job"]["name"] + ".zip"),)
                      if "fits/" + item["job"]["name"] + ".zip" not in item["result"]["members"] else ()))
                    if path.is_file()))
            for (name, _, _), output in zip(eligible, values, strict=True):
                value = output["numbers"]
                if value is not None:
                    found[name] = value
                    del wanted[name]
    _require(not set(pending).intersection(wanted), "F45_AAR_FINAL_REUSE_PENDING_ORIGINAL_OBJECT_REQUIRED")
    return {name: row["prediction"] for name, row in found.items()}


def _a12_final_reuse_members(root, outer, branches):
    """Only provenance referenced by the current branch prefix belongs in its reservation."""
    names = set()
    for branch in branches:
        for imp in range(1, 21):
            name = f"O{outer}_{branch}_M{imp:02d}"
            numbers = root / "fits" / (name + ".numbers.json")
            if not numbers.is_file():
                continue
            value = strict_json_bytes(numbers.read_bytes())
            if "reused_final" not in value:
                continue
            binding = value["reused_final"]
            path = binding["source"]["path"]
            _require(binding["component"] == name and path in {
                f"final-reuse/AAR-H{h:02d}-O{outer}/source.json" for h in (6, 12, 24, 36)},
                "F45_AAR_FINAL_REUSE_SOURCE_DRIFT")
            names.update({path, str(Path(path).parent / "fits" / (name + ".numbers.json"))})
    return names


def _a12_execute_final_pool(jobs, reused, capacity, record):
    """Keep native job order; an all-hit branch opens no model worker pool."""
    _require(set(reused) <= {job["name"] for job in jobs}, "F45_AAR_FINAL_REUSE_COORDINATE_INVALID")
    missing = [job for job in jobs if job["name"] not in reused]
    if reused:
        record.update(reused_final_model_count=len(reused), physical_final_model_count=len(missing))
    rows = (_bounded_ordered_spawn(_execute_ablation_component, missing, selected_slots=capacity,
                                  execution_report=record["final_model_pool"]) if missing else [])
    values = {**reused, **{job["name"]: row for job, row in zip(missing, rows, strict=True)}}
    return [values[job["name"]] for job in jobs]


def _execute_ablation_component(job: Mapping[str, Any]) -> dict[str, Any]:
    from .f5 import _execute_final_refit_engine, _retained_tree_bytes
    entries, root = job["entries"], Path(job["root"])
    task, recipe, training, response, application = _ablation_component_inputs(entries)
    label = "A04" if "a04_coordinates" in task else "A12" if "a12_coordinates" in task else "C10"
    from .nested_loco import _write_exact_once
    archive, numbers_path = root.with_suffix(".zip"), root.with_suffix(".numbers.json")
    if "nested_aar_final_source" in task and archive.is_file():
        if numbers_path.is_file():
            return _replay_ablation_component({"entries": entries, "numbers_path": numbers_path,
                "native_archive": {"sha256": sha256_file(archive), "size_bytes": archive.stat().st_size},
                "retained_bytes_per_component": job["retained_bytes_per_component"],
                "consumer_source": job.get("consumer_source")})
        numbers = _replay_ablation_component({"entries": entries, "archive": archive, "collect_numbers": True})
        _write_exact_once(numbers_path, canonical_json_bytes(numbers), "F5_A12_FINAL_NUMBERS_DRIFT")
        return numbers["prediction"]
    root.mkdir(mode=0o700, exist_ok=True)
    for name, raw in entries.items():
        _write_exact_once(root / name, raw, "F5_A12_FINAL_INPUT_DRIFT")
    try:
        complete_objects = all((root / name).is_file() for name in ("model.bin", "baseline.bin", "fit-health.json"))
        fitted = _execute_final_refit_engine(task["family"], task, training, response, recipe,
            **({"retained_objects": ((root / "model.bin").read_bytes(), (root / "baseline.bin").read_bytes())}
               if complete_objects else {}))
        if complete_objects:
            fitted.update(model=(root / "model.bin").read_bytes(), baseline=(root / "baseline.bin").read_bytes(),
                          fit_health=strict_json_bytes((root / "fit-health.json").read_bytes()))
        for name in ("model", "baseline"):
            (root / f"{name}.bin").write_bytes(fitted[name])
        (root / "fit-health.json").write_bytes(canonical_json_bytes(fitted["fit_health"]))
        (root / "training-prediction.json").write_bytes(canonical_json_bytes(fitted["survival"]))
        _ablation_prediction(task, training, fitted["survival"])
        predicted = _execute_final_refit_engine(task["family"], task, training, response, recipe,
            retained_objects=(fitted["model"], fitted["baseline"]), prediction_rows=application)
        row = _ablation_prediction(task, application, predicted["survival"])
        (root / "prediction.json").write_bytes(canonical_json_bytes(row))
        retained = job.get("retained_bytes_per_component")
        if retained is not None:
            # The expanded directory remains live after the worker exits.
            # Allow the ZIP's worst-case deflate/header overhead as well.
            expanded = _retained_tree_bytes(root)
            overhead = sum(1024 + 4 * len(path.name.encode("utf-8")) for path in root.iterdir())
            _require(3 * expanded + overhead <= retained, "F5_A12_COMPONENT_STORAGE_ESTIMATE_EXCEEDED")
        write_deterministic_zip(root.with_suffix(".zip"), {name: root / name for name in (*entries, "model.bin", "baseline.bin", "fit-health.json", "training-prediction.json", "prediction.json")},
            stored_members={"model.bin", "baseline.bin"} if task["family"] in {
                "COX_PH", "ELASTIC_NET_COX", "RSF", "GBM_COX", "FPM_TVC_SET_A"} else set())
        if retained is not None:
            _require(expanded + root.with_suffix(".zip").stat().st_size <= retained,
                     "F5_A12_COMPONENT_STORAGE_ESTIMATE_EXCEEDED")
        if "nested_aar_final_source" in task:
            numbers = _replay_ablation_component({"entries": entries, "archive": root.with_suffix(".zip"),
                                                  "collect_numbers": True})
            raw = canonical_json_bytes(numbers)
            _require(retained is not None and expanded + root.with_suffix(".zip").stat().st_size + len(raw) <= retained,
                     "F5_A12_COMPONENT_STORAGE_ESTIMATE_EXCEEDED")
            _write_exact_once(numbers_path, raw, "F5_A12_FINAL_NUMBERS_DRIFT")
        return row
    except BaseException as exc:
        (root / "native-failure.json").write_bytes(canonical_json_bytes({"error": str(exc), "native_evidence": getattr(exc, "__notes__", [])}))
        exc.add_note(f"F5_{label}_MODEL_EVIDENCE_RETAINED:{root}")
        raise


def _replay_ablation_component(job: Mapping[str, Any]) -> dict[str, Any]:
    from .f5 import _execute_final_refit_engine, _validate_retained_model_objects
    expected = job["entries"]
    task, recipe, training, response, application = _ablation_component_inputs(expected)
    label = "A04" if "a04_coordinates" in task else "A12" if "a12_coordinates" in task else "C10"
    if "numbers_path" in job:
        path = job["numbers_path"]
        _require(path.is_file() and not path.is_symlink(), "F5_A12_FINAL_NUMBERS_REQUIRED")
        raw = path.read_bytes()
        value = strict_json_bytes(raw)
        _require(canonical_json_bytes(value) == raw and isinstance(value, Mapping)
                 and value.get("native_archive") == job["native_archive"],
                 "F5_A12_FINAL_NUMBERS_NATIVE_REFERENCE_INVALID")
        prediction = _ablation_component_numbers(expected, value, reuse_root=path.parent.parent,
                                                consumer_source=job.get("consumer_source"))
        _require(value["native_expanded_bytes"] + value["native_archive"]["size_bytes"] + len(raw)
                 <= job["retained_bytes_per_component"], "F5_A12_COMPONENT_STORAGE_ESTIMATE_EXCEEDED")
        return prediction
    entries = read_safe_zip(Path(job["archive"]), expected_members=set(expected) | {
        "model.bin", "baseline.bin", "fit-health.json", "training-prediction.json", "prediction.json"})
    _require(all(entries[name] == raw for name, raw in expected.items()), f"F5_{label}_NATIVE_INPUT_REPLAY_MISMATCH")
    objects = entries["model.bin"], entries["baseline.bin"]
    evidence = job.get("replay_evidence")
    if evidence is not None:
        _require(evidence.is_absolute() and evidence.parent.is_dir() and not evidence.exists()
                 and not evidence.is_symlink(), f"F5_{label}_REPLAY_EVIDENCE_TARGET_INVALID")
        evidence.mkdir(mode=0o700)
    audit = _validate_retained_model_objects(task["family"], *objects, strict_json_bytes(entries["fit-health.json"]), task,
        **({"native_evidence": evidence / "object-audit"} if evidence is not None else {}))
    paired_r = task["family"] in {"COX_PH", "ELASTIC_NET_COX", "RSF", "GBM_COX", "FPM_TVC_SET_A"}
    if paired_r:
        predictions = _execute_final_refit_engine(task["family"], task, training, response, recipe,
            retained_objects=objects, prediction_rows=application, replay_training=True,
            **({"replay_evidence": evidence / "predictions"} if evidence is not None else {}))
    for rows, member in ((None, "training-prediction.json"), (application, "prediction.json")):
        survival = predictions["training_survival" if rows is None else "survival"] if paired_r else (
            _execute_final_refit_engine(task["family"], task, training, response, recipe,
                retained_objects=objects, prediction_rows=rows,
                **({"replay_evidence": evidence / ("training" if rows is None else "application")}
                   if evidence is not None else {}))["survival"])
        row = _ablation_prediction(task, training if rows is None else rows, survival)
        _require(canonical_json_bytes(survival if rows is None else row) == entries[member],
                 f"F5_{label}_NATIVE_PREDICTION_REPLAY_MISMATCH")
    if evidence is not None:
        (evidence / "object-audit.json").write_bytes(canonical_json_bytes(audit))
        (evidence / "prediction.json").write_bytes(canonical_json_bytes(row))
    if job.get("collect_numbers"):
        archive = Path(job["archive"])
        numbers = {"input_members": {name: {"sha256": sha256_bytes(raw), "size_bytes": len(raw)}
                      for name, raw in sorted(expected.items())},
            "prediction": row, "training_prediction": _ablation_prediction(task, training,
                strict_json_bytes(entries["training-prediction.json"])),
            "fit_health": strict_json_bytes(entries["fit-health.json"]), "object_audit": audit,
            "model_sha256": sha256_bytes(entries["model.bin"]), "baseline_sha256": sha256_bytes(entries["baseline.bin"]),
            "native_archive": {"sha256": sha256_file(archive), "size_bytes": archive.stat().st_size},
            "native_expanded_bytes": sum(map(len, entries.values()))}
        _ablation_component_numbers(expected, numbers)
        return numbers
    return row


def _c10_metric_vector(value: Any) -> dict[str, float | None]:
    _require(
        isinstance(value, Mapping) and set(value) == set(_A12_POINT_METRICS),
        "F5_C10_METRIC_SCHEMA_INVALID",
    )
    metrics = dict(value)
    _require(
        all(
            metric is None or (
                type(metric) in {int, float} and math.isfinite(metric)
                and (0 <= metric <= 1 if name.startswith(("auc_", "uno_c_")) else
                     metric >= 0 if name.startswith(("ibs_", "brier_", "calibration_oe_",
                                                     "calibration_ici_", "calibration_e50_", "calibration_e90_"))
                     else True)
            )
            for name, metric in metrics.items()
        ),
        "F5_C10_NUMERICAL_ERROR",
    )
    return {name: None if metrics[name] is None else float(metrics[name]) for name in _A12_POINT_METRICS}


def evaluate_c10_creatinine_egfr_swap(
    evidence: Mapping[str, Any],
) -> dict[str, Any]:
    """Aggregate the locked C10 representation swap without fitting.

    Callers supply the declared two-branch, six-outer-fold, M20 references.
    This consumer validates their shape and performs only the approved
    equal-center arithmetic mean and signed ``eGFR_calc - Creatinine``
    comparison. Hash references alone are not execution proof, so the result
    remains blocked for production until retained task/object evidence exists.
    """
    _require(
        isinstance(evidence, Mapping)
        and set(evidence)
        == {
            "kind",
            "analysis_id",
            "final_family",
            "final_family_decision_sha256",
            "final_parameter_lock_sha256",
            "selected_parents",
            "branch_policy",
            "branch_rows",
        }
        and evidence["kind"] == "PADML_F5_C10_CENTER_METRICS_V1"
        and evidence["analysis_id"]
        == "CREATININE_EGFR_REPRESENTATION",
        "F5_C10_INPUT_SCHEMA_INVALID",
    )
    families = set(load_science_authority()["science"]["families"])
    family = evidence["final_family"]
    validate_sha256(
        evidence["final_family_decision_sha256"],
        "f5.c10.final_family_decision_sha256",
    )
    parameter_lock = evidence["final_parameter_lock_sha256"]
    validate_sha256(parameter_lock, "f5.c10.final_parameter_lock_sha256")
    selected = evidence["selected_parents"]
    branch_policy = evidence["branch_policy"]
    rows = evidence["branch_rows"]
    _require(
        family in families
        and isinstance(selected, list)
        and selected
        and len(selected) == len(set(selected))
        and all(isinstance(parent, str) and parent for parent in selected)
        and not {"Creatinine", "eGFR_calc"}.issubset(selected)
        and branch_policy
        == {
            "trigger_parent": "Creatinine",
            "replacement_parent": "eGFR_calc",
            "other_parents_unchanged": True,
            "family_unchanged": True,
            "hyperparameters_unchanged": True,
            "selector_rerun": False,
            "simultaneous_representation": False,
            "egfr_derivation": (
                "PASSIVE_RECOMPUTATION_EXISTING_AUTHORITY_FORMULA"
            ),
            "independent_egfr_imputation": False,
            "formal_imputation_count": 20,
        }
        and isinstance(rows, list),
        "F5_C10_LOCK_INVALID",
    )
    if "Creatinine" not in selected:
        _require(not rows, "F5_C10_NOT_APPLICABLE_ROWS_FORBIDDEN")
        return {
            "kind": "PADML_F5_C10_REPRESENTATION_SWAP_V1",
            "status": "DECLARED_NOT_APPLICABLE_UNVERIFIED",
            "execution_evidence_status": "NOT_VERIFIED_REFERENCES_ONLY",
            "reason": "LOCKED_FINAL_SETA_DOES_NOT_CONTAIN_CREATININE",
            "analysis_id": "CREATININE_EGFR_REPRESENTATION",
            "final_family": family,
            "final_family_decision_sha256": evidence[
                "final_family_decision_sha256"
            ],
            "final_parameter_lock_sha256": parameter_lock,
            "selected_parents": list(selected),
            "unverified_authority_sources": [
                "FINAL_FAMILY_DECISION_ARTIFACT",
                "FINAL_PARAMETER_LOCK_ARTIFACT",
                "FINAL_SET_A_ARTIFACT",
            ],
            "fit_execution_count": 0,
            "prediction_execution_count": 0,
            "mi_aggregate_count": 0,
            "evaluation_count": 0,
            "selector_rerun_count": 0,
            "tuning_trial_count": 0,
            "family_reselection_count": 0,
            "selection_effect": "NONE",
            "blocking_for_production": True,
            "stage_acceptance": False,
        }

    replacement = [
        "eGFR_calc" if parent == "Creatinine" else parent
        for parent in selected
    ]
    expected_parents = {
        "Creatinine": selected,
        "eGFR_calc": replacement,
    }
    expected_coordinates = {
        (branch, f"OUTER_{fold:02d}")
        for branch in C10_BRANCHES
        for fold in range(1, 7)
    }
    by_coordinate: dict[tuple[str, str], dict[str, Any]] = {}
    all_fit_receipts: list[str] = []
    all_mi_predictions: list[str] = []
    for row in rows:
        _require(
            isinstance(row, Mapping) and set(row) == _C10_ROW_FIELDS,
            "F5_C10_ROW_SCHEMA_INVALID",
        )
        branch = row["branch"]
        outer_fold = row["outer_fold_id"]
        coordinate = (branch, outer_fold)
        expected_center = (
            _VALIDATION_CENTERS[int(outer_fold[-2:]) - 1]
            if isinstance(outer_fold, str)
            and outer_fold.startswith("OUTER_")
            and outer_fold[-2:].isdigit()
            and 1 <= int(outer_fold[-2:]) <= 6
            else None
        )
        receipts = row["fit_receipts"]
        _require(
            coordinate in expected_coordinates
            and coordinate not in by_coordinate
            and row["center"] == expected_center
            and row["family"] == family
            and row["selected_parents"] == expected_parents[branch]
            and row["parameter_lock_sha256"] == parameter_lock
            and isinstance(receipts, list)
            and [
                receipt.get("imputation")
                for receipt in receipts
                if isinstance(receipt, Mapping)
            ]
            == list(range(1, 21))
            and all(
                isinstance(receipt, Mapping)
                and set(receipt) == {"imputation", "receipt_sha256"}
                for receipt in receipts
            ),
            "F5_C10_COORDINATE_INVALID",
        )
        for receipt in receipts:
            validate_sha256(
                receipt["receipt_sha256"],
                "f5.c10.fit_receipt_sha256",
            )
        validate_sha256(
            row["mi_prediction_sha256"],
            "f5.c10.mi_prediction_sha256",
        )
        by_coordinate[coordinate] = {
            **dict(row),
            "metrics": _c10_metric_vector(row["metrics"]),
        }
        support = row["metric_support"]
        _require(isinstance(support, Mapping) and set(support) == set(_A12_POINT_METRICS),
                 "F5_C10_METRIC_SUPPORT_INVALID")
        for metric, value in by_coordinate[coordinate]["metrics"].items():
            detail = support[metric]
            _require(isinstance(detail, Mapping) and set(detail) == {"status", "value", "support"}
                     and detail["value"] == value and isinstance(detail["support"], list)
                     and detail["status"] == ("NOT_ESTIMABLE" if value is None else "ESTIMABLE"),
                     "F5_C10_METRIC_SUPPORT_INVALID")
            if value is None:
                _require(bool(detail["support"]), "F5_C10_METRIC_SUPPORT_INVALID")
                for native in detail["support"]:
                    _statistical_support_reasons(native)
            else:
                _require(not detail["support"], "F5_C10_METRIC_SUPPORT_INVALID")
        all_fit_receipts.extend(
            receipt["receipt_sha256"] for receipt in receipts
        )
        all_mi_predictions.append(row["mi_prediction_sha256"])
    _require(
        set(by_coordinate) == expected_coordinates
        and len(all_fit_receipts) == 240,
        "F5_C10_COVERAGE_INVALID",
    )
    _require(
        len(all_mi_predictions) == 12,
        "F5_C10_COVERAGE_INVALID",
    )

    center_results = {
        branch: [
            {
                "outer_fold_id": outer_fold,
                "center": by_coordinate[(branch, outer_fold)]["center"],
                "metrics": by_coordinate[(branch, outer_fold)]["metrics"],
                "metric_support": by_coordinate[(branch, outer_fold)]["metric_support"],
                "mi_prediction_sha256": by_coordinate[
                    (branch, outer_fold)
                ]["mi_prediction_sha256"],
            }
            for outer_fold in sorted(
                fold for candidate, fold in expected_coordinates
                if candidate == branch
            )
        ]
        for branch in C10_BRANCHES
    }
    macro = {
        branch: {
            metric: math.fsum(
                row["metrics"][metric] for row in center_results[branch]
            )
            / 6 if all(row["metrics"][metric] is not None for row in center_results[branch]) else None
            for metric in _A12_POINT_METRICS
        }
        for branch in C10_BRANCHES
    }
    differences = {
        metric: (macro["eGFR_calc"][metric] - macro["Creatinine"][metric]
                 if all(macro[branch][metric] is not None for branch in C10_BRANCHES) else None)
        for metric in _A12_POINT_METRICS
    }
    _require(
        all(value is None or math.isfinite(value) for value in differences.values()),
        "F5_C10_NUMERICAL_ERROR",
    )
    return {
        "kind": "PADML_F5_C10_REPRESENTATION_SWAP_V1",
        "status": "REDUCED_DECLARED_EVIDENCE",
        "execution_evidence_status": "NOT_VERIFIED_REFERENCES_ONLY",
        "analysis_id": "CREATININE_EGFR_REPRESENTATION",
        "final_family": family,
        "final_family_decision_sha256": evidence[
            "final_family_decision_sha256"
        ],
        "final_parameter_lock_sha256": parameter_lock,
        "trigger_parent": "Creatinine",
        "replacement_parent": "eGFR_calc",
        "selected_parents_by_branch": expected_parents,
        "paired_difference_direction": "EGFR_MINUS_CREATININE",
        "center_aggregation": "UNWEIGHTED_ARITHMETIC_MEAN_EXACT_SIX",
        "center_level_results": center_results,
        "equal_center_macro_results": macro,
        "paired_difference": differences,
        "statistical_status": "PARTIAL_NOT_ESTIMABLE" if any(value is None for value in differences.values()) else "ESTIMABLE",
        "estimable_center_count": {branch: {metric: sum(row["metrics"][metric] is not None for row in center_results[branch])
                                             for metric in _A12_POINT_METRICS} for branch in C10_BRANCHES},
        "total_center_count": 6,
        "declared_fit_receipt_count": 240,
        "declared_mi_prediction_reference_count": 12,
        "metric_row_reduction_count": 12,
        "fit_execution_count": 0,
        "prediction_execution_count": 0,
        "mi_aggregate_count": 0,
        "evaluation_count": 0,
        "selector_rerun_count": 0,
        "tuning_trial_count": 0,
        "family_reselection_count": 0,
        "simultaneous_representation_count": 0,
        "selection_effect": "NONE",
        "blocking_for_production": True,
        "stage_acceptance": False,
    }


def _c10_native_metric_support(evaluation: Mapping[str, Any], branch: str) -> tuple[dict, dict]:
    _require(evaluation["status"] == "COMPUTED" and len(evaluation["scopes"]) == 1
             and evaluation["scopes"][0]["scope"] == "MICRO", "F5_C10_EVALUATION_INVALID")
    scope = evaluation["scopes"][0]
    row = scope["families"][branch]
    qc = {item["horizon"]: item for item in scope["ipcw_qc"]}
    values, sources = {}, {}
    for horizon in REPORT_HORIZONS:
        calibration = row["calibration"]["horizons"][str(horizon)]
        auc = row["discrimination"]["auc"][str(horizon)]
        values[f"ibs_0_{horizon}"] = row["ibs_0_to"][str(horizon)]
        sources[f"ibs_0_{horizon}"] = [qc[index] for index in range(1, horizon + 1) if qc[index]["status"] == "NOT_ESTIMABLE"]
        values[f"brier_{horizon}"] = row["brier_monthly"][horizon]
        sources[f"brier_{horizon}"] = [qc[horizon]]
        values[f"auc_{horizon}"], sources[f"auc_{horizon}"] = auc["value"], [auc]
        for metric in ("slope", "citl", "oe", "ici", "e50", "e90"):
            values[f"calibration_{metric}_{horizon}"] = calibration[metric]
            sources[f"calibration_{metric}_{horizon}"] = [calibration]
    values["uno_c_24"] = row["discrimination"]["uno_c_24"]["value"]
    sources["uno_c_24"] = [row["discrimination"]["uno_c_24"]]
    values["integrated_raw_net_benefit_24"] = row["dca_24"]["integrated_raw_nb"]
    sources["integrated_raw_net_benefit_24"] = [row["dca_24"]]
    values = _c10_metric_vector(values)
    support = {}
    for metric, value in values.items():
        details = []
        if value is None:
            _require(bool(sources[metric]), "F5_C10_METRIC_SUPPORT_INVALID")
            for native in sources[metric]:
                details.append({"status": "NOT_ESTIMABLE", "reasons": _statistical_support_reasons(native)})
        support[metric] = {"status": "NOT_ESTIMABLE" if value is None else "ESTIMABLE", "value": value, "support": details}
    return values, support


def _c10_outer_results(context: Mapping[str, Any], outer: int, jobs: list[dict], rows: list[dict], root: Path,
                       *, replay_metrics: bytes | Path | None = None) -> dict:
    """M20 probabilities first, then one shared held-out-center evaluator."""
    _require(len(jobs) == len(rows) == 40, "F5_C10_NATIVE_FIT_COVERAGE_INVALID")
    family = context["lineage"]["final_family"]
    source, = [row for row in context["frozen"]["registry"]["outer"] if row["outer_fold"] == outer]
    ids = source["validation_ids"]
    by_coordinate = {}
    for job, row in zip(jobs, rows, strict=True):
        task = strict_json_bytes(job["entries"]["task.json"])
        coordinates = task["c10_coordinates"]
        coordinate = coordinates["branch"], coordinates["imputation"]
        _require(coordinate not in by_coordinate and row["c10_coordinates"] == coordinates
                 and coordinates["outer_fold"] == outer and row["family"] == family
                 and row["patient_ids"] == ids and row["centers"] == [str(source["heldout_center"])] * len(ids)
                 and row["horizons"] == HORIZONS, "F5_C10_NATIVE_COORDINATE_MISMATCH")
        _seal_prediction_matrix(ids, row["survival"], HORIZONS)
        _require(all(value[0] == 1.0 for value in row["survival"]), "F5_C10_MONTH_ZERO_INVALID")
        by_coordinate[coordinate] = (job, row)
    _require(set(by_coordinate) == {(branch, imp) for branch in C10_BRANCHES for imp in range(1, 21)},
             "F5_C10_NATIVE_FIT_COVERAGE_INVALID")
    mean = {branch: [[math.fsum(by_coordinate[branch, imp][1]["survival"][patient][horizon] for imp in range(1, 21)) / 20
                       for horizon in HORIZONS] for patient in range(len(ids))] for branch in C10_BRANCHES}
    predictions = {"patient_ids": ids, "centers": [str(source["heldout_center"])] * len(ids),
                   "horizons": HORIZONS, "survival": mean}
    evaluation = evaluate_predictions(predictions, context["frozen"]["response_csv"], include_center_scopes=False,
        **({"evidence_root": root / "metrics", "native_archive": root / "metrics.zip"} if replay_metrics is None else
           {"replay_native_archive": replay_metrics}))
    branch_rows = []
    for branch in C10_BRANCHES:
        values, support = _c10_native_metric_support(evaluation, branch)
        branch_rows.append({"branch": branch, "outer_fold_id": f"OUTER_{outer:02d}", "center": str(source["heldout_center"]),
            "family": family, "selected_parents": strict_json_bytes(by_coordinate[branch, 1][0]["entries"]["task.json"])["selected_parents"],
            "parameter_lock_sha256": context["lineage"]["final_parameter_lock"]["identity_sha256"],
            "fit_receipts": [{"imputation": imp, "receipt_sha256": sha256_file(root / "fits" / f"{by_coordinate[branch, imp][0]['name']}.zip")}
                             for imp in range(1, 21)],
            "mi_prediction_sha256": sha256_bytes(canonical_json_bytes({**predictions, "survival": {branch: mean[branch]}})),
            "metrics": values, "metric_support": support})
    return {"predictions": predictions, "evaluation": evaluation, "branch_rows": branch_rows}


def _c10_outer_member_names(outer: int, family: str) -> set[str]:
    names = {"metrics.zip", *{f"fits/O{outer}_{branch}_M{imp:02d}.zip" for branch in C10_BRANCHES for imp in range(1, 21)}}
    if family in {"COX_PH", "ELASTIC_NET_COX", "FPM_TVC_SET_A"}:
        names |= {f"egfr-recipe/{name}" for name in ("projection.json", "native-values.json", "stdout.log", "stderr.log")}
    return names


def execute_c10_bundle(source: Path, target: Path, *, f2_run_root: Path, outer_fold: int,
                       workers: int | None = None, f1_runtime_root: Path | None = None) -> dict[str, Any]:
    """One of six original outer folds, both branches in one forty-task pool."""
    _require(source.is_absolute() and source.is_file() and not source.is_symlink()
             and target.is_absolute() and target.parent.is_dir() and not target.exists() and not target.is_symlink()
             and type(outer_fold) is int and outer_fold in range(1, 7), "F5_C10_PATH_INVALID")
    raw = source.read_bytes()
    lineage = strict_json_bytes(raw)
    _require(canonical_json_bytes(lineage) == raw, "F5_C10_LINEAGE_NONCANONICAL")
    context = _c10_context(f2_run_root, lineage, f1_runtime_root=f1_runtime_root)
    capacity = resolve_pool_workers(workers)
    root = target.with_name(target.name + ".work")
    root.mkdir(mode=0o700)
    try:
        jobs = _prepare_c10_outer(context, outer_fold, root)
        (root / "fits").mkdir(mode=0o700)
        jobs = [{**job, "root": str(root / "fits" / job["name"])} for job in jobs]
        rows = _bounded_ordered_spawn(_execute_ablation_component, jobs, selected_slots=capacity)
        result = _c10_outer_results(context, outer_fold, jobs, rows, root)
        names = _c10_outer_member_names(outer_fold, lineage["final_family"])
        body = {"kind": "PADML_F5_C10_OUTER_NATIVE_V1", "outer_fold": outer_fold, "family": lineage["final_family"],
                "source": context["source"], **result,
                "members": {name: {"sha256": sha256_file(root / name), "size_bytes": (root / name).stat().st_size} for name in sorted(names)}}
        value = {**body, "identity_sha256": sha256_bytes(canonical_json_bytes(body))}
        write_deterministic_zip(target, {"c10-outer.json": canonical_json_bytes(value), **{name: root / name for name in names}},
                                stored_members=names)
    except BaseException as exc:
        exc.add_note(f"F5_C10_OUTER_EVIDENCE_RETAINED:{root}")
        raise
    shutil.rmtree(root)
    return {"status": "COMPUTED_NATIVE_MODELS", "stage_acceptance": False, "outer_fold": outer_fold,
            "model_fit_count": 40, "pool_workers": min(capacity, 40), "sha256": sha256_file(target), "size_bytes": target.stat().st_size}


def _load_c10_outer_archive(path: Path, context: Mapping[str, Any], *, replay_evidence: Path | None = None) -> dict[str, Any]:
    from .f4 import O_FIT_COMPONENT_BYTES
    _require(path.is_absolute() and path.is_file() and not path.is_symlink(), "F5_C10_ARCHIVE_PATH_INVALID")
    with open_carrier(path) as archive:
        info = archive.getinfo("c10-outer.json")
        _require(info.file_size <= 64 * 1024 * 1024, "F5_C10_OUTER_METADATA_INVALID")
        raw = archive.read(info)
    value = strict_json_bytes(raw)
    _require(isinstance(value, dict) and set(value) == {"kind", "outer_fold", "family", "source", "predictions", "evaluation",
                                                      "branch_rows", "members", "identity_sha256"}
             and canonical_json_bytes(value) == raw and value["kind"] == "PADML_F5_C10_OUTER_NATIVE_V1"
             and type(value["outer_fold"]) is int and value["outer_fold"] in range(1, 7)
             and value["family"] == context["lineage"]["final_family"] and value["source"] == context["source"]
             and value["identity_sha256"] == sha256_bytes(canonical_json_bytes({key: item for key, item in value.items() if key != "identity_sha256"})),
             "F5_C10_OUTER_METADATA_INVALID")
    names = _c10_outer_member_names(value["outer_fold"], value["family"])
    _require(isinstance(value["members"], dict) and set(value["members"]) == names, "F5_C10_NATIVE_FIT_COVERAGE_INVALID")
    root = Path(tempfile.mkdtemp(prefix="padml-f5-c10-replay-")).resolve() if replay_evidence is None else replay_evidence
    if replay_evidence is not None:
        root.mkdir(mode=0o700)
    try:
        extracted = root / "archive"
        extract_safe_zip(path, extracted, expected_members={"c10-outer.json": {"sha256": sha256_bytes(raw), "size_bytes": len(raw)},
                                                          **value["members"]},
                         max_member_bytes=O_FIT_COMPONENT_BYTES, max_total_bytes=41 * O_FIT_COMPONENT_BYTES)
        jobs = _prepare_c10_outer(context, value["outer_fold"], root)
        if replay_evidence is not None:
            (root / "models").mkdir(mode=0o700)
        rows = [_replay_ablation_component({**job, "archive": extracted / "fits" / f"{job['name']}.zip",
            **({"replay_evidence": root / "models" / job["name"]} if replay_evidence is not None else {})}) for job in jobs]
        observed = _c10_outer_results(context, value["outer_fold"], jobs, rows, extracted, replay_metrics=extracted / "metrics.zip")
        if replay_evidence is not None:
            (root / "replayed-results.json").write_bytes(canonical_json_bytes(observed))
        _require(all(value[key] == item for key, item in observed.items()), "F5_C10_OUTER_NATIVE_REPLAY_MISMATCH")
        if (root / "egfr-recipe").is_dir():
            _require(strict_json_bytes((root / "egfr-recipe/native-values.json").read_bytes()) ==
                     strict_json_bytes((extracted / "egfr-recipe/native-values.json").read_bytes()),
                     "F5_C10_EGFR_NATIVE_REPLAY_MISMATCH")
    except BaseException as exc:
        exc.add_note(f"F5_C10_OUTER_REPLAY_EVIDENCE_RETAINED:{root}")
        raise
    if replay_evidence is None:
        shutil.rmtree(root)
    return value


def _c10_native_summary(context: Mapping[str, Any], outers: list[dict]) -> dict[str, Any]:
    _require(len(outers) == 6 and [row["outer_fold"] for row in outers] == list(range(1, 7)), "F5_C10_SIX_OUTER_ARCHIVES_REQUIRED")
    lineage = context["lineage"]
    result = evaluate_c10_creatinine_egfr_swap({
        "kind": "PADML_F5_C10_CENTER_METRICS_V1", "analysis_id": "CREATININE_EGFR_REPRESENTATION",
        "final_family": lineage["final_family"], "final_family_decision_sha256": sha256_bytes(canonical_json_bytes(lineage["family_decision"])),
        "final_parameter_lock_sha256": lineage["final_parameter_lock"]["identity_sha256"],
        "selected_parents": lineage["final_seta"]["lock"]["selected_parents"],
        "branch_policy": {"trigger_parent": "Creatinine", "replacement_parent": "eGFR_calc", "other_parents_unchanged": True,
            "family_unchanged": True, "hyperparameters_unchanged": True, "selector_rerun": False, "simultaneous_representation": False,
            "egfr_derivation": "PASSIVE_RECOMPUTATION_EXISTING_AUTHORITY_FORMULA", "independent_egfr_imputation": False, "formal_imputation_count": 20},
        "branch_rows": [row for outer in outers for row in outer["branch_rows"]]})
    from .f4 import PROSPECTIVE_PROTOCOL_REVISION
    result.update({"status": "COMPLETED_ZERO_FEEDBACK", "execution_evidence_status": "NATIVE_OBJECTS_AND_INPUTS_REPLAYED",
        "blocking_for_production": False, "unverified_authority_sources": [], "fit_execution_count": 240,
        "prediction_execution_count": 240, "mi_aggregate_count": 12, "evaluation_count": 12,
        "mice_chain_execution_count": 0, "stop_fit_execution_count": 0, "source": context["source"],
        "scientific_revision": PROSPECTIVE_PROTOCOL_REVISION,
        "evidence_label": "CONDITIONAL_FINAL_CONFIGURATION_REPRESENTATION_SENSITIVITY_NOT_INDEPENDENT_NESTED_VALIDATION"})
    return result


def aggregate_c10_archives(sources: list[Path], target: Path, *, f2_run_root: Path, lineage: Mapping[str, Any],
                           f1_runtime_root: Path | None = None) -> dict:
    _require(len(sources) == 6 and len({path.resolve() for path in sources}) == 6
             and target.is_absolute() and target.parent.is_dir() and not target.exists(), "F5_C10_SIX_OUTER_ARCHIVES_REQUIRED")
    context = _c10_context(f2_run_root, lineage, f1_runtime_root=f1_runtime_root)
    loaded = [(_load_c10_outer_archive(path, context), path) for path in sources]
    loaded.sort(key=lambda item: item[0]["outer_fold"])
    result = _c10_native_summary(context, [item[0] for item in loaded])
    records = [{"outer_fold": row["outer_fold"], "member": f"outer-o{row['outer_fold']}.zip", "identity_sha256": row["identity_sha256"],
                "sha256": sha256_file(path), "size_bytes": path.stat().st_size} for row, path in loaded]
    result["source_archives"] = records
    write_deterministic_zip(target, {"c10.json": canonical_json_bytes(result),
                                    **{record["member"]: path for record, (_, path) in zip(records, loaded, strict=True)}},
                            stored_members={record["member"] for record in records})
    return {"status": result["status"], "statistical_status": result["statistical_status"], "stage_acceptance": False,
            "model_fit_count": 240, "sha256": sha256_file(target), "size_bytes": target.stat().st_size}


def replay_c10_bundle(source: Path, final_lineage: Mapping[str, Any], *, f2_run_root: Path,
                      f1_runtime_root: Path | None = None, replay_evidence: Path | None = None) -> tuple[dict, dict]:
    from .bundle import _validated_zip_infos, _stream_zip_member
    from .f4 import O_FIT_COMPONENT_BYTES
    context = _c10_context(f2_run_root, final_lineage, f1_runtime_root=f1_runtime_root)
    _require(source.is_absolute() and source.is_file() and not source.is_symlink(), "F5_C10_ARCHIVE_PATH_INVALID")
    root = Path(tempfile.mkdtemp(prefix="padml-f5-c10-aggregate-")).resolve()
    if replay_evidence is not None:
        replay_evidence.mkdir(mode=0o700)
    try:
        with open_carrier(source) as archive:
            info = archive.getinfo("c10.json")
            _require(info.file_size <= 64 * 1024 * 1024, "F5_C10_AGGREGATE_METADATA_INVALID")
            raw = archive.read(info)
            value = strict_json_bytes(raw)
            _require(isinstance(value, dict) and canonical_json_bytes(value) == raw
                     and isinstance(value.get("source_archives"), list) and len(value["source_archives"]) == 6,
                     "F5_C10_NATIVE_EXECUTION_ARCHIVE_REQUIRED")
            names = {f"outer-o{outer}.zip" for outer in range(1, 7)}
            infos = {info.filename: info for info in _validated_zip_infos(archive, names | {"c10.json"},
                     max_member_bytes=41 * O_FIT_COMPONENT_BYTES, max_total_bytes=247 * O_FIT_COMPONENT_BYTES,
                     max_compression_ratio=1000)}
            loaded = []
            for outer, record in enumerate(value["source_archives"], 1):
                name = f"outer-o{outer}.zip"
                _require(isinstance(record, dict) and set(record) == {"outer_fold", "member", "identity_sha256", "sha256", "size_bytes"}
                         and type(record["outer_fold"]) is int and record["outer_fold"] == outer and record["member"] == name,
                         "F5_C10_AGGREGATE_COORDINATE_INVALID")
                path = root / name
                with path.open("xb") as handle:
                    digest, size = _stream_zip_member(archive, infos[name], handle)
                _require(digest == record["sha256"] and size == record["size_bytes"], "F5_C10_AGGREGATE_MEMBER_MISMATCH")
                item = _load_c10_outer_archive(path, context,
                    **({"replay_evidence": replay_evidence / f"outer-o{outer}"} if replay_evidence is not None else {}))
                _require(item["outer_fold"] == outer and item["identity_sha256"] == record["identity_sha256"],
                         "F5_C10_AGGREGATE_COORDINATE_INVALID")
                loaded.append(item)
                path.unlink()
            result = {**_c10_native_summary(context, loaded), "source_archives": value["source_archives"]}
            _require(canonical_json_bytes(result) == raw, "F5_C10_NATIVE_SUMMARY_REPLAY_MISMATCH")
    except BaseException as exc:
        exc.add_note(f"F5_C10_AGGREGATE_REPLAY_EVIDENCE_RETAINED:{root}")
        raise
    shutil.rmtree(root)
    return result, value


def _canonical_bundle_json(
    source: Path, expected_members: set[str], label: str
) -> tuple[dict[str, Any], dict[str, bytes]]:
    _require(
        source.is_absolute()
        and source.is_file()
        and not source.is_symlink(),
        f"F5_{label}_SOURCE_INVALID",
    )
    entries = read_safe_zip(source, expected_members=expected_members)
    raw = entries["predictions.json"]
    value = strict_json_bytes(raw, f"F5_{label}_INPUT")
    _require(
        isinstance(value, dict) and canonical_json_bytes(value) == raw,
        f"F5_{label}_INPUT_NONCANONICAL",
    )
    return value, entries


def _write_sensitivity_result(
    target: Path, member: str, result: Mapping[str, Any]
) -> dict[str, Any]:
    _require(
        target.is_absolute()
        and target.parent.is_dir()
        and not target.exists(),
        "F5_SENSITIVITY_RESULT_TARGET_INVALID",
    )
    write_deterministic_zip(target, {member: canonical_json_bytes(result)})
    return {
        "status": result["status"],
        "stage_acceptance": False,
        "sha256": sha256_file(target),
        "size_bytes": target.stat().st_size,
    }


def _f45_evaluation_receipt(receipt, run, unit):
    from .run import f45_unit_predecessors
    owners = [run, *f45_unit_predecessors(run)]
    _require(receipt.get("status") == "COMPLETED" and receipt.get("direct_consumer_completed") is True
        and receipt.get("unit_id") == unit["unit_id"] and unit["kind"] in {"PRIMARY", "AAR"}
        and receipt.get("selection_horizon_months") == unit["horizon"]
        and receipt.get("report_horizons_months") == [6, 12, 24, 36]
        and receipt.get("run_identity") in {r["identity"] for r in owners
            if unit["horizon"] != 36 or "amendment_20260928" in r["science_decision"]},
        "F45_EVALUATION_COMPLETED_SOURCE_REQUIRED")


def _f45_evaluation_nested_index(archive, name, member, pin=None):
    """Read a stored nested ZIP by bounded seeks, not ZipExtFile's linear replay."""
    import struct
    from .f4 import _f45_optimism_member
    info = archive.getinfo(name)
    if pin is not None:
        _require(info.file_size == pin['size_bytes'], 'F45_EVALUATION_SOURCE_MEMBER_DRIFT')
    if name in getattr(archive, 'references', {}):
        reference = archive.references[name]
        _require(pin is None or {key: reference[key] for key in ('sha256', 'size_bytes')} == pin,
                 'F45_EVALUATION_SOURCE_MEMBER_DRIFT')
        external = archive.external_path(name)  # Includes source/producer qualification.
        if external is not None:
            with open_carrier(external) as nested:
                return _f45_optimism_member(nested, member, limit=32 * 1024**2)
        # An offline packed reference is bounded by the existing <1 MiB pack
        # contract. It has no header offset in this logical carrier.
        with archive.open(name) as stream, open_carrier(stream) as nested:
            return _f45_optimism_member(nested, member, limit=32 * 1024**2)
    _require(info.compress_type == zipfile.ZIP_STORED and info.compress_size == info.file_size,
             "F45_EVALUATION_STORED_SOURCE_REQUIRED")
    stream = archive.fp
    stream.seek(info.header_offset)
    header = stream.read(30)
    _require(len(header) == 30 and header[:4] == b"PK\x03\x04", "F45_EVALUATION_SOURCE_HEADER_INVALID")
    fields = struct.unpack("<4s5H3I2H", header)
    start = info.header_offset + 30 + fields[-2] + fields[-1]
    class MemberView(io.RawIOBase):
        def __init__(self):
            self.position = 0
        def seekable(self):
            return True
        def readable(self):
            return True
        def tell(self):
            return self.position
        def seek(self, offset, whence=0):
            target = offset + (self.position if whence == 1 else info.file_size if whence == 2 else 0)
            _require(whence in {0, 1, 2} and 0 <= target <= info.file_size, "F45_EVALUATION_SOURCE_SEEK_INVALID")
            self.position = target
            return target
        def read(self, size=-1):
            remaining = info.file_size - self.position
            size = remaining if size is None or size < 0 else min(size, remaining)
            stream.seek(start + self.position)
            value = stream.read(size)
            self.position += len(value)
            return value
    with open_carrier(MemberView()) as nested:
        return _f45_optimism_member(nested, member, limit=32 * 1024**2)


def _f45_evaluation_completed_outer(root, receipt, header, authorities):
    """Migrate a finished original consumer, without requiring its temporary tree."""
    keys = ("executor_source_identity", "operation", "outer_fold", "family", "task_names",
            "input_archive", "projected_input", "projected_input_identity_sha256", "work_root")
    candidates = sorted(root.glob("padml-a12-outer-replay-*/execution.json"))
    for path in candidates[:128]:
        _require(path.is_file() and not path.is_symlink() and path.stat().st_size <= 64 * 1024**2,
                 "F45_EVALUATION_CONSUMER_REPORT_INVALID")
        raw = path.read_bytes()
        pin = {"sha256": sha256_bytes(raw), "size_bytes": len(raw)}
        relative = path.relative_to(root).as_posix()
        pinned = relative in receipt["artifacts"]
        _require(not pinned or receipt["artifacts"][relative] == pin,
                 "F45_EVALUATION_CONSUMER_REPORT_DRIFT")
        try:
            record = strict_json_bytes(raw)
        except ContractError:
            continue
        value = record.get("input_execution")
        if not isinstance(value, Mapping) or type(value.get("last_consumer_finished_ns")) is not int \
                or value["last_consumer_finished_ns"] <= 0:
            continue  # An expansion-only record conveys no completed boundary.
        matches = (value.get("executor_source_identity") in authorities[0].values()
            and value.get("operation") == "OUTER_REPLAY"
            and value.get("outer_fold") == header["outer_fold"] and value.get("family") == header["family"]
            and value.get("input_archive") == receipt["artifacts"]["result.zip"]
            and value.get("projected_input") == receipt["artifacts"]["input.zip"]
            and value.get("projected_input_identity_sha256") == header["source"]["identity_sha256"])
        _require(not pinned or matches, "F45_EVALUATION_CONSUMER_SOURCE_DRIFT")
        if not matches or not all(k in value for k in keys):
            continue
        result_pin = {"sha256": sha256_bytes(canonical_json_bytes(header)),
                      "size_bytes": len(canonical_json_bytes(header))}
        try:
            _validate_a12_final_input_execution(raw, binding={k: value[k] for k in keys},
                result_pin=result_pin, policy=header["source"]["resource_policy"],
                loader_report=True, expected_pin=pin)
        except ContractError:
            continue
        return {"original_report": {"path": relative, **pin}, "binding": {k: value[k] for k in keys},
                "result": result_pin, "last_consumer_finished_ns": value["last_consumer_finished_ns"],
                "temporary_trees_required": False}
    return None


def prepare_f45_evaluation_source(run, unit, root):
    """Append a compact consumer to a completed unit; preserve every original byte."""
    from . import nested_loco as nested
    from .f4 import _f45_optimism_json, _f45_optimism_member, _f45_source_member_sha256
    from .runtime import observe_execution_resources, resource_admission
    from .worker import _f45_file_pins
    receipt_raw = (root / "unit.json").read_bytes()
    receipt = _f45_optimism_json(receipt_raw)
    _f45_evaluation_receipt(receipt, run, unit)
    target = root / "evaluation-input.zip"
    if target.is_file():
        loaded = load_f45_evaluation_source(target, run, unit)
        _require(loaded["manifest"]["source_receipt"] == receipt, "F45_EVALUATION_SOURCE_RECEIPT_DRIFT")
        return target
    policy = run["resource_policy"]
    resource_admission({**policy, "memory_bytes_per_worker": MIN_WORKER_MEMORY_BYTES, "scratch_reserve_bytes": 0},
        observe_execution_resources(root), legal_tasks=1)
    # One qualification when converting an old source. Subsequent consumers
    # read this appendage, even after the large original has been archived.
    _f45_file_pins({n: root / n for n in ("input.zip", "result.zip")},
        expected={n: receipt["artifacts"][n] for n in ("input.zip", "result.zip")}, policy=policy, root=root,
        failure="F45_EVALUATION_SOURCE_ARTIFACT_DRIFT")
    entries = {"source-unit.json": receipt_raw}
    with open_carrier(root / "result.zip") as archive:
        primary = unit["kind"] == "PRIMARY"
        header_name = "o-fit-execution.json" if primary else "a12-outer.json"
        entries[header_name] = _f45_optimism_member(archive, header_name)
        header = _f45_optimism_json(entries[header_name])
        names = ({"final-numbers.zip"} if primary else
            {f"fits/O{unit['outer_fold']}_{branch}_M{imp:02d}.numbers.json"
             for branch in _a12_estimable_branches(header) for imp in range(1, 21)})
        names.update(n for n in header["members"] if n.startswith("final-reuse/"))
        if primary:
            with open_carrier(root / "input.zip") as source:
                entries["o-fit-input.json"] = _f45_optimism_member(source, "o-fit-input.json")
        else:
            names.add("development/selector/development-input.json")
            if "estimability" in header:
                names.add("development/" + nested.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT + ".json")
            names.update(n for n in header["members"] if n in {
                "development/selector/reuse.json", f"development/{nested.A12_TOTAL_AAR}.json"}
                or n.startswith("search/") and n.endswith(("/search.json", "/result.json")))
            entries["inputs-index.json"] = _f45_evaluation_nested_index(archive, "inputs.zip", "a12-inputs.json",
                header['members']['inputs.zip'])
        for name in sorted(names):
            entries[name] = _f45_optimism_member(archive, name, header["members"][name])
    from .f5 import _f45_score_reuse_authorities
    authorities = _f45_score_reuse_authorities()
    completed_outer = (None if primary else _f45_evaluation_completed_outer(root, receipt, header, authorities))
    manifest = nested._sealed({"kind": "PADML_F45_EVALUATION_SOURCE_V1",
        "source_kind": unit["kind"], "unit_id": unit["unit_id"], "horizon": unit["horizon"],
        "outer_fold": unit["outer_fold"], "source_receipt": receipt,
        "source_receipt_sha256": sha256_bytes(receipt_raw),
        "producer_source_identity": nested._sha(_f45_source_member_sha256()),
        "qualification": "ORIGINAL_COMPLETED_WHOLE_CONSUMER_AND_BYTE_VERIFIED_ARTIFACTS",
        "completed_outer_consumer": completed_outer,
        "members": {n: {"sha256": sha256_bytes(b), "size_bytes": len(b)} for n, b in entries.items()}})
    _f45_evaluation_numbers(entries, manifest, authorities)
    pending = sum(map(len, entries.values())) + len(canonical_json_bytes(manifest)) + 4096 * (len(entries) + 1)
    _require(observe_execution_resources(root)["scratch_available_bytes"] >= pending,
             "F45_EVALUATION_COMPACT_SPACE_INSUFFICIENT")
    write_deterministic_zip(target, {"evaluation-input.json": canonical_json_bytes(manifest), **entries},
                            stored_members={n for n in entries if n.endswith(".zip")})
    load_f45_evaluation_source(target, run, unit)
    return target


def load_f45_evaluation_source(path, run, unit):
    """Direct numerical consumer, independent of retired development trees."""
    from .f4 import _f45_optimism_json, _f45_optimism_member
    from .f5 import _f45_score_reuse_authorities
    with open_carrier(path) as archive:
        manifest = _f45_optimism_json(_f45_optimism_member(archive, "evaluation-input.json"))
        names = archive.namelist()
        _require(manifest.get("kind") == "PADML_F45_EVALUATION_SOURCE_V1"
            and manifest["unit_id"] == unit["unit_id"] and manifest["source_kind"] == unit["kind"]
            and manifest["horizon"] == unit["horizon"] and manifest["outer_fold"] == unit["outer_fold"]
            and len(names) == len(set(names)) and set(names) == {"evaluation-input.json", *manifest["members"]},
            "F45_EVALUATION_COMPACT_SOURCE_INVALID")
        _f45_evaluation_receipt(manifest["source_receipt"], run, unit)
        authorities = _f45_score_reuse_authorities()
        _require(manifest["producer_source_identity"] in authorities[1], "F45_EVALUATION_PRODUCER_INVALID")
        entries = {n: _f45_optimism_member(archive, n, pin) for n, pin in manifest["members"].items()}
        _require(entries["source-unit.json"] == canonical_json_bytes(manifest["source_receipt"])
            and sha256_bytes(entries["source-unit.json"]) == manifest["source_receipt_sha256"],
            "F45_EVALUATION_SOURCE_RECEIPT_DRIFT")
        checked = _f45_evaluation_numbers(entries, manifest, authorities)
        if unit["kind"] == "AAR":
            checked["archive_record"] = _a12_outer_archive_record(checked["metadata"], path,
                source_pin=manifest["source_receipt"]["artifacts"]["result.zip"],
                mice_index=_f45_optimism_json(entries["inputs-index.json"]), _archive=archive)
        return {"manifest": manifest, **checked}


def _f45_evaluation_numbers(entries, manifest, authorities):
    """Consume qualified complete-unit prediction numbers; never open a model.

    The caller has qualified source_receipt, original input/result archive bytes,
    and the compact member bytes. This function rechecks the original member pins,
    original first-audit provenance, coordinates and actual M20 arithmetic.
    No file writes, model reads, MICE, search, RNG, or native engine calls.
    """
    import struct
    from pathlib import PurePosixPath
    from collections.abc import Mapping
    from padml import f4, f5, f5_sensitivity as a, nested_loco as n
    from padml.bundle import canonical_json_bytes, read_safe_zip, sha256_bytes, validate_sha256
    from padml.f2_kernel import _require, _seal_prediction_matrix, _pool_prediction_batch, _locked_family_parameters

    failure = "F45_EVALUATION_NUMBERS_SOURCE_DRIFT"
    horizons = list(n.HORIZONS)
    kind, outer, h = (manifest[k] for k in ("source_kind", "outer_fold", "horizon"))
    receipt = manifest["source_receipt"]
    executors, sources = authorities
    _require(manifest["kind"] == "PADML_F45_EVALUATION_SOURCE_V1"
        and kind in {"PRIMARY", "AAR"} and type(outer) is int and outer in range(1, 7)
        and type(h) is int and h in n.SELECTION_HORIZONS
        and manifest["unit_id"] == f"{kind}-H{h:02d}-O{outer}"
        and receipt["unit_id"] == manifest["unit_id"]
        and receipt["status"] == "COMPLETED" and receipt["direct_consumer_completed"] is True
        and receipt["selection_horizon_months"] == h
        and receipt["report_horizons_months"] == [6, 12, 24, 36]
        and receipt["run_identity"] in executors
        and executors[receipt["run_identity"]] in sources, failure)
    required = set()

    def pin(raw, expected):
        _require(isinstance(raw, bytes) and isinstance(expected, Mapping)
            and set(expected) == {"sha256", "size_bytes"}
            and type(expected["size_bytes"]) is int and expected["size_bytes"] > 0
            and len(raw) == expected["size_bytes"] and sha256_bytes(raw) == expected["sha256"], failure)
        return raw

    def take(name, expected=None):
        _require(name in entries and isinstance(entries[name], bytes), failure)
        required.add(name)
        return entries[name] if expected is None else pin(entries[name], expected)

    def js(name, expected=None):
        return f4._f45_optimism_json(take(name, expected))

    _require(take("source-unit.json") == canonical_json_bytes(receipt)
        and sha256_bytes(entries["source-unit.json"]) == manifest["source_receipt_sha256"], failure)

    def seal(value):
        _require(isinstance(value, Mapping) and value.get("identity_sha256")
            == n._sha({k: v for k, v in value.items() if k != "identity_sha256"}), failure)
        return value

    def bind(context, lock, horizon):
        context = n.validate_training_context(context)
        lock = n.validate_development_lock(lock, context=context)
        _require(context["scope"] == "OUTER" and context["channel"] == "PRIMARY"
            and context["outer_fold"] == outer and lock["selection_horizon_months"] == horizon
            and context["modeling_program_sha256"] in sources
            and all(lock[k] == context[k] for k in
                ("outer_fold", "heldout_center", "training_ids_sha256", "heldout_ids_sha256")), failure)
        return context, lock

    def component(value, imp, context, lock, native):
        _require(isinstance(value, Mapping) and set(value) == {
            "receipt", "prediction", "fit_health", "object_audit", "native_archive"}
            | ({"reused_final"} if "reused_final" in value else set()), failure)
        _require(isinstance(native, Mapping) and set(native) == {"sha256", "size_bytes"}
            and type(native["size_bytes"]) is int and native["size_bytes"] > 0, failure)
        validate_sha256(native["sha256"], failure)
        r = n.validate_component_receipt(value["receipt"], lock)
        prediction = value["prediction"]
        coordinates = {"purpose": "NESTED_OUTER", "outer_fold": outer,
                       "repeat": 0, "inner_fold": 0, "imputation": imp}
        family = lock["selected_family"]
        ids = context["heldout_ids"]
        _require(r["imputation"] == imp
            and r["training_response_sha256"] == context["training_response_sha256"]
            and r["seed"] == f4._f4_model_seed(family, coordinates)
            and value["native_archive"] == {"member": f"fits/M{imp:02d}.zip", **native}
            and isinstance(prediction, Mapping) and set(prediction) == {
                "f4_coordinates", "patient_ids", "centers", "horizons", "survival"}
            and prediction["f4_coordinates"] == coordinates
            and all(type(prediction["f4_coordinates"][k]) is int
                for k in ("outer_fold", "repeat", "inner_fold", "imputation"))
            and prediction["patient_ids"] == ids
            and prediction["centers"] == [context["centers_by_patient"][p] for p in ids]
            and prediction["horizons"] == horizons
            and isinstance(prediction["survival"], Mapping) and set(prediction["survival"]) == {family}
            and isinstance(value["fit_health"], Mapping) and isinstance(value["object_audit"], Mapping)
            and r["prediction_sha256"] == n._sha(prediction)
            and r["fit_health_sha256"] == n._sha(value["fit_health"]), failure)
        curve = _seal_prediction_matrix(ids, prediction["survival"][family], horizons)
        _require(all(row[0] == 1.0 for row in prediction["survival"][family]), failure)
        _require(family != "XGBOOST_COX" or value["fit_health"].get("model_binary_sha256")
            == r["model_sha256"], failure)
        return r, {"sealed_prediction": curve}

    def final(raw, request, lock):
        inner = read_safe_zip(raw, expected_members={"final.json", "heldout-mean.f64"},
            max_member_bytes=f4.O_FIT_COMPONENT_BYTES, max_total_bytes=f4.O_FIT_COMPONENT_BYTES)
        value = f4._f45_optimism_json(inner["final.json"])
        _require(set(value) == {"kind", "input_identity_sha256", "development_lock_sha256",
            "components", "mean", "identity_sha256"}
            | ({"batch_executions"} if "batch_executions" in value else set())
            and value["kind"] == "PADML_F4_O_FIT_FINAL_NUMBERS_V1"
            and value["input_identity_sha256"] == request["identity_sha256"]
            and value["development_lock_sha256"] == lock["identity_sha256"]
            and isinstance(value["components"], list) and len(value["components"]) == 20, failure)
        return value, inner["heldout-mean.f64"]

    def engine_parameters(lock, imp):
        # Match the original final-reuse engine ABI. Each receipt remains
        # bound to its own full lock, including its development horizon.
        family = lock["selected_family"]
        parameters = lock["parameters_by_imputation"][imp - 1]
        engine = dict(parameters) if family == "ELASTIC_NET_COX" else _locked_family_parameters(family, parameters)
        if family == "XGBOOST_COX":
            engine = {**engine, "selected_rounds": parameters["selected_rounds"]}
        elif family == "COXTIME_SET_A":
            engine = {**engine, "locked_epoch": parameters["locked_epoch"]}
        return family, engine

    if kind == "PRIMARY":
        request, header = js("o-fit-input.json"), js("o-fit-execution.json")
        ctx, lock = bind(request["training_context"], header["development_lock"], h)
        science = n.validate_science_decision(request["science_decision"], selection_horizon_months=h)
        _require(request["kind"] == "PADML_F4_O_FIT_INPUT_V1" and request["selection_horizon_months"] == h
            and header["kind"] == "PADML_F4_O_FIT_EXECUTION_ARCHIVE_V3"
            and header["outer_fold"] == outer and header["family"] == lock["selected_family"]
            and header["input_identity_sha256"] == request["identity_sha256"]
            and header["input_archive"] == receipt["artifacts"]["input.zip"]
            and header["science_decision_sha256"] == science["identity_sha256"]
                == lock["science_decision_binding"]["science_decision_sha256"]
            and set(header["native_members"]) == {f"fits/M{i:02d}.zip" for i in range(1, 21)}, failure)
        numbers, mean = final(take("final-numbers.zip", header["members"]["final-numbers.zip"]), request, lock)
        reused, origins, receipts, produced = 0, {}, [], []
        for imp, value in enumerate(numbers["components"], 1):
            r, prediction = component(value, imp, ctx, lock, header["native_members"][f"fits/M{imp:02d}.zip"])
            _require(r == header["component_receipts"][imp - 1], failure)
            if "reused_final" in value:
                reused += 1
                binding = value["reused_final"]
                _require(isinstance(binding, Mapping) and set(binding) == {"source", "imputation"}
                    and type(binding["imputation"]) is int and binding["imputation"] == imp, failure)
                reference = binding["source"]
                _require(isinstance(reference, Mapping) and set(reference) == {"path", "sha256", "size_bytes"}
                    and reference["path"] in {f"final-reuse/PRIMARY-H{x:02d}-O{outer}/source.json" for x in n.SELECTION_HORIZONS}, failure)
                path = reference["path"]
                expected = {k: reference[k] for k in ("sha256", "size_bytes")}
                _require(header["members"][path] == expected, failure)
                if path not in origins:
                    proof = js(path, expected)
                    unit = f5._f45_score_reuse_source(proof, request, authorities)
                    _require(PurePosixPath(path).parent.name == unit, failure)
                    old_request, old_header = proof["request"], proof["result_metadata"]
                    old_ctx, old_lock = bind(old_request["training_context"], old_header["development_lock"],
                        old_request["selection_horizon_months"])
                    old_name = str(PurePosixPath(path).parent / "final-numbers.zip")
                    old_pin = old_header["members"]["final-numbers.zip"]
                    _require(header["members"][old_name] == old_pin, failure)
                    old, _ = final(take(old_name, old_pin), old_request, old_lock)
                    origins[path] = old, old_header, old_ctx, old_lock
                old, old_header, old_ctx, old_lock = origins[path]
                original = old["components"][imp - 1]
                _require("reused_final" not in original, failure)
                old_receipt, _ = component(original, imp, old_ctx, old_lock,
                    old_header["native_members"][f"fits/M{imp:02d}.zip"])
                _require(original["receipt"] == old_header["component_receipts"][imp - 1]
                    and engine_parameters(lock, imp) == engine_parameters(old_lock, imp)
                    and {k: v for k, v in value.items() if k not in {"receipt", "reused_final"}}
                        == {k: v for k, v in original.items() if k != "receipt"}
                    and all(r[k] == old_receipt[k] for k in ("model_sha256", "baseline_sha256", "mice_member_sha256",
                        "recipe_sha256", "training_ids_sha256", "application_ids_sha256", "training_response_sha256")), failure)
            receipts.append(r)
            produced.append(prediction)
        pooled = _pool_prediction_batch(produced, horizons)["payload"]["survival"]
        expected_mean = b"".join(struct.pack("<37d", *row) for row in pooled)
        mean_meta = {"encoding": "IEEE754_FLOAT64_LE_ROW_MAJOR", "patient_ids": ctx["heldout_ids"],
            "centers": [ctx["centers_by_patient"][p] for p in ctx["heldout_ids"]], "horizons": horizons,
            "imputation_count": 20, "sha256": sha256_bytes(mean), "size_bytes": len(mean)}
        _require(mean == expected_mean and numbers["mean"] == mean_meta, failure)
        selected = n.seal_selected_prediction(lock=lock, patient_ids=mean_meta["patient_ids"],
            centers=mean_meta["centers"], survival=pooled, component_receipts=receipts)
        _require(selected == header["selected_prediction"] and receipts == header["component_receipts"]
            and set(entries) == required, failure)
        return {"metadata": header, "request": request, "training_context": ctx,
                "selected_prediction": selected, "reused_final_count": reused}

    header = js("a12-outer.json")
    source = seal(header["source"])
    _require(set(header) == {"kind", "source", "family", "outer_fold", "predictions", "members",
        "identity_sha256", "native_members"} | ({"estimability"} if "estimability" in header else set())
        and source["kind"] == "PADML_F5_A12_PROJECTED_OUTER_INPUTS_V1", failure)
    index = js("inputs-index.json")
    _require(index["kind"] == "PADML_F5_A12_OUTER_INPUTS_NATIVE_V2"
        and index["outer_fold"] == outer and index["family"] == header["family"]
        and index["projected_input_identity_sha256"] == source["identity_sha256"]
        and index["stage"] == "MICE_MATERIALIZED_PRE_DEVELOPMENT"
        and set(index.get("mice_reuse", {})) <= set(index["mice_views"]), failure)
    # The unchanged direct ledger reader consumes these original small leaves.
    extra = {name for name in entries if name in {
        "development/selector/development-input.json", "development/selector/reuse.json",
        f"development/{n.A12_TOTAL_AAR}.json",
        *({f"development/{n.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT}.json"} if "estimability" in header else set())}
        or name.startswith("search/") and name.endswith(("/search.json", "/result.json"))}
    _require("development/selector/development-input.json" in extra, failure)
    for name in extra:
        js(name, header["members"][name])
    primary = source["primary_source"]
    ctx, lock = bind(primary["primary_training_context"], primary["primary_development_lock"], h)
    science = n.validate_science_decision(primary["science_decision"], selection_horizon_months=h)
    _require(header["kind"] == "PADML_F5_A12_OUTER_NATIVE_V2"
        and header["outer_fold"] == source["outer_fold"] == outer
        and header["family"] == source["family"] == lock["selected_family"]
        and lock["science_decision_binding"]["science_decision_sha256"] == science["identity_sha256"], failure)
    branches = a._a12_estimable_branches(header)
    if "estimability" in header:
        proof = header["estimability"][n.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT]
        development = js("development/selector/development-input.json",
            header["members"]["development/selector/development-input.json"])
        branch_name = f"development/{n.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT}.json"
        _require(js(branch_name, header["members"][branch_name]) == proof
            and development["identity_sha256"] == proof["selector_development_sha256"]
            and development["selector"].get("status") == "NOT_ESTIMABLE"
            and development["selector"]["epv_resolution"] == proof["epv_resolution"], failure)
    names = [f"O{outer}_{branch}_M{imp:02d}" for branch in branches for imp in range(1, 21)]
    _require(set(header["native_members"]) == {f"fits/{name}.zip" for name in names}, failure)
    inputs = {"task.json", "recipe.json", "fit-covariates.csv", "fit-response.csv", "prediction-covariates.csv"}

    def aar_numbers(value, branch, imp, context, native):
        keys = {"input_members", "prediction", "training_prediction", "fit_health", "object_audit",
                "model_sha256", "baseline_sha256", "native_archive", "native_expanded_bytes"}
        _require(isinstance(value, Mapping) and set(value) == keys | ({"reused_final"} if "reused_final" in value else set())
            and isinstance(value["input_members"], Mapping) and set(value["input_members"]) == inputs
            and value["native_archive"] == native
            and type(value["native_expanded_bytes"]) is int and value["native_expanded_bytes"] > 0
            and isinstance(value["fit_health"], Mapping) and isinstance(value["object_audit"], Mapping), failure)
        for record in [*value["input_members"].values(), native]:
            _require(isinstance(record, Mapping) and set(record) == {"sha256", "size_bytes"}
                and type(record["size_bytes"]) is int and record["size_bytes"] > 0, failure)
            validate_sha256(record["sha256"], failure)
        for key in ("model_sha256", "baseline_sha256"):
            validate_sha256(value[key], failure)
        _require(value["input_members"]["fit-response.csv"] == {
            "sha256": context["training_response_sha256"], "size_bytes": context["training_response_size_bytes"]}, failure)
        coordinates = {"outer_fold": outer, "branch": branch, "imputation": imp}
        for field, ids in (("prediction", context["heldout_ids"]), ("training_prediction", context["training_ids"])):
            p = value[field]
            _require(isinstance(p, Mapping) and set(p) == {"a12_coordinates", "family", "patient_ids", "centers", "horizons", "survival"}
                and p["a12_coordinates"] == coordinates
                and all(type(p["a12_coordinates"][k]) is int for k in ("outer_fold", "imputation"))
                and p["family"] == header["family"] and p["patient_ids"] == ids
                and p["centers"] == [context["centers_by_patient"][pid] for pid in ids]
                and p["horizons"] == horizons, failure)
            _seal_prediction_matrix(ids, p["survival"], horizons)
            _require(all(row[0] == 1.0 for row in p["survival"]), failure)
        _require(header["family"] != "XGBOOST_COX" or value["fit_health"].get("model_binary_sha256")
            == value["model_sha256"], failure)
        return coordinates

    reused, origins, jobs, predictions = 0, {}, [], []
    for branch in branches:
        for imp in range(1, 21):
            name = f"O{outer}_{branch}_M{imp:02d}"
            number_name = f"fits/{name}.numbers.json"
            value = js(number_name, header["members"][number_name])
            coordinates = aar_numbers(value, branch, imp, ctx, header["native_members"][f"fits/{name}.zip"])
            if "reused_final" in value:
                reused += 1
                binding = value["reused_final"]
                _require(isinstance(binding, Mapping) and set(binding) == {"source", "component"}
                    and binding["component"] == name, failure)
                reference = binding["source"]
                _require(isinstance(reference, Mapping) and set(reference) == {"path", "sha256", "size_bytes"}
                    and reference["path"] in {f"final-reuse/AAR-H{x:02d}-O{outer}/source.json" for x in n.SELECTION_HORIZONS}, failure)
                path = reference["path"]
                expected = {k: reference[k] for k in ("sha256", "size_bytes")}
                _require(header["members"][path] == expected, failure)
                if path not in origins:
                    proof = js(path, expected)
                    unit = a._a12_final_reuse_source(proof, source, authorities)
                    _require(PurePosixPath(path).parent.name == unit
                        and executors[proof["whole_unit"]["run_identity"]] == proof["execution"]["executor_source_identity"], failure)
                    old_header = proof["result_metadata"]
                    old_primary = old_header["source"]["primary_source"]
                    old_ctx, _ = bind(old_primary["primary_training_context"], old_primary["primary_development_lock"],
                        old_primary["primary_development_lock"]["selection_horizon_months"])
                    origins[path] = old_header, old_ctx
                old_header, old_ctx = origins[path]
                old_name = str(PurePosixPath(path).parent / number_name)
                old_pin = old_header["members"][number_name]
                _require(header["members"][old_name] == old_pin, failure)
                original = js(old_name, old_pin)
                _require("reused_final" not in original, failure)
                aar_numbers(original, branch, imp, old_ctx, old_header["native_members"][f"fits/{name}.zip"])
                _require({k: v for k, v in value.items() if k not in {"input_members", "reused_final"}}
                        == {k: v for k, v in original.items() if k != "input_members"}
                    and all(value["input_members"][k] == original["input_members"][k] for k in inputs - {"task.json"}), failure)
            jobs.append({"entries": {"task.json": canonical_json_bytes({"a12_coordinates": coordinates})}})
            predictions.append(value["prediction"])
    observed = a._a12_outer_predictions(header, jobs, predictions)
    _require(observed == header["predictions"] and set(entries) == required, failure)
    return {"metadata": header, "request": None, "training_context": ctx,
            "selected_prediction": observed, "reused_final_count": reused}


def _f45_evaluation_context(run, root, primary_sources):
    """Reuse the original point/OOC, or compute its first point from six M20 reads.

    Appends only paired-context/{context.json,response.csv,primary-point-native.zip}.
    The context record is published last. It never rewrites primary.zip or a receipt.
    The compact source explicitly binds the aggregate HEADER identity, not an
    uncomputed whole-ZIP digest; old full-archive source records remain unchanged.
    """
    from . import f4, f5_sensitivity as a, nested_loco as n
    from .run import f45_unit_predecessors
    from .runtime import observe_execution_resources, resource_admission
    fail = 'F45_COMPACT_EVALUATION_PRIMARY_SOURCE_DRIFT'
    require = a._require
    require(root.is_absolute() and root.is_dir() and not root.is_symlink()
            and isinstance(primary_sources, (list, tuple)) and len(primary_sources) == 6, fail)
    require(all(isinstance(row, Mapping) and {'manifest','metadata','request','selected_prediction'} <= set(row)
                for row in primary_sources), fail)
    ordered = sorted(primary_sources, key=lambda row: row['manifest']['outer_fold'])
    require([row['manifest']['outer_fold'] for row in ordered] == list(range(1,7)), fail)
    h = n.selection_horizon(ordered[0]['manifest']['horizon'])
    require(root.name == f'EVALUATION-H{h:02d}', fail)
    generations = [run, *f45_unit_predecessors(run)]
    admitted = {row['identity']: row['source_identity'] for row in generations}
    sciences = [n.validate_science_decision(row['request']['science_decision'], selection_horizon_months=h)
                for row in ordered]
    science = next((row for row in sciences if 'selector_frequency_amendment' in row), sciences[0])
    require(all(n.compatible_science_decisions(row, science) for row in sciences), fail)
    records, bindings, requests, predictions = [], [], [], []

    def pin(value):
        require(isinstance(value, Mapping) and set(value) == {'sha256','size_bytes'}
                and type(value['size_bytes']) is int and value['size_bytes'] > 0, fail)
        validate_sha256(value['sha256'], fail)
        return dict(value)

    for outer, row in enumerate(ordered, 1):
        manifest, meta, request, selected = (row[key] for key in
            ('manifest','metadata','request','selected_prediction'))
        receipt = manifest['source_receipt']
        uid = f'PRIMARY-H{h:02d}-O{outer}'
        require(manifest['unit_id'] == uid and manifest['horizon'] == h
                and receipt['unit_id'] == uid and receipt.get('status') == 'COMPLETED'
                and receipt.get('direct_consumer_completed') is True
                and receipt.get('selection_horizon_months') == h
                and receipt.get('report_horizons_months') == [6,12,24,36]
                and receipt.get('run_identity') in admitted, fail)
        for value in (meta, request):
            require(isinstance(value, Mapping) and n._sealed({key:item for key,item in value.items()
                        if key != 'identity_sha256'}) == value, fail)
        input_pin = pin(receipt['artifacts']['input.zip'])
        result_pin = pin(receipt['artifacts']['result.zip'])
        context = n.validate_training_context(request['training_context'])
        producer_science = sciences[outer - 1]
        lock = n.validate_development_lock(meta['development_lock'], context=context,
                                          science_decision=producer_science)
        selected = n.validate_selected_prediction(selected, lock)
        require(meta.get('kind') == 'PADML_F4_O_FIT_EXECUTION_ARCHIVE_V3'
                and request.get('kind') == 'PADML_F4_O_FIT_INPUT_V1'
                and meta['outer_fold'] == context['outer_fold'] == selected['outer_fold'] == outer
                and request['selection_horizon_months'] == selected['selection_horizon_months'] == h
                and request['science_decision'] == producer_science
                and meta['science_decision_sha256'] == producer_science['identity_sha256']
                and meta['input_archive'] == input_pin
                and meta['input_identity_sha256'] == request['identity_sha256']
                and meta['selected_prediction'] == selected
                and meta['family'] == lock['selected_family'] == selected['selected_family'], fail)
        receipts = [n.validate_component_receipt(item, lock) for item in meta['component_receipts']]
        require([item['imputation'] for item in receipts] == list(range(1,21))
                and selected['component_receipt_sha256'] == [item['identity_sha256'] for item in receipts], fail)
        records.append({'outer_fold':outer, 'member':f'execution-o{outer:02d}.zip',
                        'identity_sha256':meta['identity_sha256'], **result_pin})
        bindings.append({'unit_id':uid, 'source_receipt_sha256':n._sha(receipt),
            'metadata_sha256':n._sha(meta), 'request_identity_sha256':request['identity_sha256'],
            'selected_prediction_sha256':selected['identity_sha256'],
            'input_archive':input_pin, 'result_archive':result_pin})
        requests.append(request)
        predictions.append(selected)

    destination = root / 'result.zip.work' / 'primary-context'
    destination.mkdir(mode=0o700, parents=True, exist_ok=True)
    require(destination.is_dir() and not destination.is_symlink()
            and destination.resolve(strict=True) == destination, fail)
    context_path = destination / 'context.json'
    response_path = destination / 'response.csv'
    native_path = destination / 'primary-point-native.zip'

    def small_read(path, maximum):
        require(path.is_file() and not path.is_symlink() and 0 < path.stat().st_size <= maximum, fail)
        return path.read_bytes()

    def admit(memory_bytes=0):
        policy = run['resource_policy']
        resource_admission({**policy, 'memory_bytes_per_worker':MIN_WORKER_MEMORY_BYTES,
            'scratch_reserve_bytes':0,
            'memory_reserve_bytes':policy['memory_reserve_bytes'] + memory_bytes},
            observe_execution_resources(root), legal_tasks=1)

    def validate_context(context, response, native):
        registry = n.validate_population_registry(context['population_registry'])
        expected_ooc = n.assemble_selected_ooc(predictions, population_registry=registry)
        require(context['primary'] == expected_ooc and context['science_decision'] == science
                and context['family_by_outer'] == {str(row['outer_fold']):row['selected_family']
                    for row in expected_ooc['selection_by_outer']}
                and context['source']['primary_source_archives'] == records
                and context['source']['primary_input_sha256'] == {str(i):bindings[i-1]['input_archive']['sha256']
                    for i in range(1,7)}, fail)
        for request, part in zip(requests, registry['outer'], strict=True):
            tc = request['training_context']
            require(tc['training_ids'] == part['training_ids'] and tc['heldout_ids'] == part['heldout_ids']
                    and tc['centers_by_patient'] == registry['centers_by_patient'], fail)
        require(list(_response_rows(response)[1]) == expected_ooc['patient_ids']
                and context['primary_point']['heldout_response_sha256'] == sha256_bytes(response), fail)
        origin_handoff = {'patient_ids':expected_ooc['patient_ids'], 'centers':expected_ooc['centers'],
            'horizons':expected_ooc['horizons'],
            'survival':{'PRIMARY':expected_ooc['survival']['NESTED_SELECTED_POLICY']},
            'primary_ooc_sha256':expected_ooc['identity_sha256'],
            'selection_horizon_months':h, 'science_decision':science}
        a._a12_primary_point_origin(origin_handoff, response, context['primary_point'], native)
        return {**context, 'evaluation_response_csv':response, 'primary_point_native':native,
                'compact_evaluation':True}

    if context_path.is_file():
        raw = small_read(context_path, 64*1024**2)
        admit(32*len(raw))
        record = strict_json_bytes(raw)
        require(canonical_json_bytes(record) == raw and n._sealed({key:item for key,item in record.items()
                    if key != 'identity_sha256'}) == record
                and record.get('kind') == 'PADML_F45_PAIRED_CONTEXT_V1'
                and record['primary_sources'] == bindings
                and admitted.get(record['producer']['run_identity']) == record['producer']['source_identity'], fail)
        response, native = small_read(response_path, 32*1024**2), small_read(native_path, 64*1024**2)
        require(record['response'] == {'sha256':sha256_bytes(response),'size_bytes':len(response)}
                and record['primary_point_native'] == {'sha256':sha256_bytes(native),'size_bytes':len(native)}, fail)
        return validate_context(record['context'], response, native)
    require(not context_path.exists() and not context_path.is_symlink(), fail)

    if run.get("kind") == "PADML_INTEGRATED_RAW_RUN_V1":
        from .integrated import ensure_raw_binding
        frozen = ensure_raw_binding(run)
        accepted = {"source": {"origin": "CURRENT_RAW_CONTEXT", "raw_binding_identity": frozen["receipt"]["identity"]}}
    else:
        accepted = f4._load_f4_source_records(Path(run['f2_run_root']),
            f1_runtime_root=Path(run['f1_runtime_root']), admit_io=lambda **kw:admit(kw.get('memory_bytes',0)))
        frozen = f4._load_o_fit_frozen_source(accepted['runtime_root'], accepted['f1_manifest'],
            accepted['replay'], [], admit_io=lambda **kw:admit(kw.get('memory_bytes',0)))
    all_ids = frozen['registry']['outer'][0]['application_ids']
    registry = n.validate_population_registry({'all_patient_ids':all_ids,
        'evaluation_patient_ids':[patient for patient in all_ids if frozen['centers'][patient] != '55'],
        'centers_by_patient':frozen['centers'], 'outer':[{'outer_fold':part['outer_fold'],
            'heldout_center':part['heldout_center'], 'training_ids':part['analysis_ids'],
            'heldout_ids':part['validation_ids']} for part in frozen['registry']['outer']]})
    ooc = n.assemble_selected_ooc(predictions, population_registry=registry)
    fields, responses = _response_rows(frozen['response_csv'])
    response = _write_response_subset(fields,responses,ooc['patient_ids'],None)['private_bytes']
    for request in requests:
        tc = request['training_context']
        n.validate_training_context(tc,
            _write_response_subset(fields,responses,tc['training_ids'],None)['private_bytes'])
    frozen_identity = accepted['source']
    del frozen, accepted, responses

    original = root / 'primary.zip'
    if original.exists():
        require(original.is_file() and not original.is_symlink(), fail)
        with open_carrier(original) as archive:
            raw_values = []
            for name, maximum in (('o-fit-aggregate.json',32*1024**2),('evaluation/metrics.zip',64*1024**2)):
                info = archive.getinfo(name)
                require(0 < info.file_size <= maximum, fail)
                admit(32*info.file_size)
                raw_values.append(archive.read(info))
        aggregate_raw,native = raw_values
        aggregate = strict_json_bytes(aggregate_raw)
        require(canonical_json_bytes(aggregate) == aggregate_raw
                and n._sealed({key:item for key,item in aggregate.items() if key != 'identity_sha256'}) == aggregate
                and aggregate['kind'] == 'PADML_F4_O_FIT_AGGREGATE_ARCHIVE_V4'
                and aggregate['source_archives'] == records and aggregate['selected_ooc'] == ooc
                and aggregate['science_decision_sha256'] == science['identity_sha256']
                and aggregate['native_metric_archive'] == {'member':'evaluation/metrics.zip',
                    'sha256':sha256_bytes(native),'size_bytes':len(native)}, fail)
        point = aggregate['evaluation']
        n._write_exact_once(native_path,native,fail)
    else:
        # An interrupted first point may have saved the native archive already.
        point = n.evaluate_selected_ooc(ooc,response,population_registry=registry,science_decision=science,
            **({'replay_native_archive':native_path} if native_path.is_file() else
               {'evidence_root':destination / 'point','native_archive':native_path}))
        native = small_read(native_path,64*1024**2)
        aggregate = n._sealed({'schema_version':n.SCHEMA_VERSION,
            'kind':'PADML_F4_O_FIT_AGGREGATE_ARCHIVE_V4',
            'status':'COMPUTED_PROGRAM_OOC_NOT_STAGE_ACCEPTANCE','source_archives':records,
            'science_decision_sha256':science['identity_sha256'],
            'native_metric_archive':{'member':'evaluation/metrics.zip','sha256':sha256_bytes(native),'size_bytes':len(native)},
            'selected_ooc':ooc,'evaluation':point,'model_fit_count':0,
            'outer_family_consensus_required':False,'full_data_model_independently_validated':False})
    source = {'kind':'PADML_F45_COMPACT_EVALUATION_PRIMARY_SOURCE_V1','program_id':n.PROGRAM_ID,
        'primary_aggregate_identity_sha256':aggregate['identity_sha256'],
        'primary_point_native':{'sha256':sha256_bytes(native),'size_bytes':len(native)},
        'science_decision_sha256':science['identity_sha256'],'primary_ooc_sha256':ooc['identity_sha256'],
        'primary_source_archives':records,
        'primary_input_sha256':{str(i):bindings[i-1]['input_archive']['sha256'] for i in range(1,7)}}
    context = {'primary':ooc,'population_registry':registry,'science_decision':science,
        'primary_point':point,'family_by_outer':{str(row['outer_fold']):row['selected_family']
            for row in ooc['selection_by_outer']},'source':source}
    result = validate_context(context,response,native)
    n._write_exact_once(response_path,response,fail)
    saved = n._sealed({'kind':'PADML_F45_PAIRED_CONTEXT_V1',
        'producer':{'run_identity':run['identity'],'source_identity':run['source_identity']},
        'primary_sources':bindings,'frozen_input':frozen_identity,'context':context,
        'response':{'sha256':sha256_bytes(response),'size_bytes':len(response)},
        'primary_point_native':{'sha256':sha256_bytes(native),'size_bytes':len(native)}})
    n._write_exact_once(context_path,canonical_json_bytes(saved),fail)
    return result


def _f45_evaluation_source_job(job):
    run, unit, root = job
    from .runtime import release_f45_cumulative_files
    root = Path(root)
    existed = (root / "evaluation-input.zip").is_file()
    path = prepare_f45_evaluation_source(run, unit, root)
    release_f45_cumulative_files([path, root / "unit.json", *([] if existed else
        [root / "input.zip", root / "result.zip", *sorted(root.glob("padml-a12-outer-replay-*/execution.json"))[:128]])],
        owner="COMPACT_SOURCE:" + unit["unit_id"], report_root=root)
    return str(path)


@contextmanager
def _f45_evaluation_input(path, member=None):
    """Read the unique retained input, including a result's stored ZIP member."""
    from .reports import _StoredArchiveMember
    with open_carrier(path) as archive:
        if member is None:
            yield archive
            return
        info = archive.getinfo(member)
        _require(archive.namelist().count(member) == 1, 'F45_EVALUATION_RESULT_MEMBER_DRIFT')
        external = archive.external_path(member) if member in archive.references else None
        if external is not None:
            with open_carrier(external) as nested_archive:
                yield nested_archive
        elif member not in archive.references and info.compress_type == zipfile.ZIP_STORED:
            with _StoredArchiveMember(archive, info) as source, open_carrier(source) as nested_archive:
                yield nested_archive
        else:
            _require(0 < info.file_size <= 512 * 1024**2, 'ARCHIVE_COMPRESSED_NESTED_TOO_LARGE')
            # Only legacy compressed inputs need a bounded, temporary decode.
            # The original outer carrier remains the source identity.
            with tempfile.SpooledTemporaryFile(max_size=8*1024**2) as source, archive.open(info) as compressed:
                count = 0
                for block in iter(lambda: compressed.read(1024**2), b''):
                    count += len(block)
                    _require(count <= info.file_size, 'F45_EVALUATION_RESULT_MEMBER_DRIFT')
                    source.write(block)
                _require(count == info.file_size, 'F45_EVALUATION_RESULT_MEMBER_DRIFT')
                source.seek(0)
                with open_carrier(source) as nested_archive:
                    yield nested_archive


def _f45_evaluation_load_job(job):
    if len(job) == 3:
        path, run, unit = job
        return load_f45_evaluation_source(Path(path), run, unit)
    _require(len(job) in {5,6}, "F45_EVALUATION_SOURCE_JOB_INVALID")
    path, run, unit, member, pin = job[:5]
    import hashlib
    from .reports import _StoredArchiveMember
    with _f45_evaluation_input(Path(path), job[5] if len(job) == 6 else None) as archive:
        info = archive.getinfo(member)
        _require(archive.namelist().count(member) == 1 and info.file_size == pin["size_bytes"],
                 "F45_EVALUATION_RESULT_MEMBER_DRIFT")
        def qualify(source, copy_to=None):
            digest, size = hashlib.sha256(), 0
            for block in iter(lambda: source.read(1024**2), b""):
                size += len(block)
                _require(size <= info.file_size, "F45_EVALUATION_RESULT_MEMBER_DRIFT")
                digest.update(block)
                if copy_to is not None:
                    copy_to.write(block)
            _require({"sha256": digest.hexdigest(), "size_bytes": size} == pin,
                     "F45_EVALUATION_RESULT_MEMBER_DRIFT")
        if info.compress_type == zipfile.ZIP_STORED:
            with _StoredArchiveMember(archive, info) as source:
                qualify(source)
                source.seek(0)
                return load_f45_evaluation_source(source, run, unit)
        # Same bounded legacy fallback as the existing archive reader. Decode
        # once; backward ZIP seeks use the spool, never replay compressed bytes.
        _require(0 < info.file_size <= 512 * 1024**2, "ARCHIVE_COMPRESSED_NESTED_TOO_LARGE")
        with tempfile.SpooledTemporaryFile(max_size=8 * 1024**2,
                dir=Path(path).parent) as source, archive.open(info) as compressed:
            qualify(compressed, source)
            source.seek(0)
            return load_f45_evaluation_source(source, run, unit)


def _f45_evaluation_restore_member(archive, name, path, pin=None):
    """Stream one compact carrier through the original publish-once boundary."""
    import hashlib
    info = archive.getinfo(name)
    _require(archive.namelist().count(name) == 1 and not path.is_symlink()
        and (pin is None or info.file_size == pin["size_bytes"]), "F45_EVALUATION_RESULT_MEMBER_DRIFT")
    temporary = None
    digest, size = hashlib.sha256(), 0
    try:
        if not path.exists():
            _require(shutil.disk_usage(path.parent).free >= info.file_size + 65536,
                     "F45_EVALUATION_COMPACT_SPACE_INSUFFICIENT")
            handle = tempfile.NamedTemporaryFile(prefix=".compact-", dir=path.parent, delete=False)
            temporary = Path(handle.name)
        else:
            _require(path.is_file() and path.stat().st_size == info.file_size,
                     "F45_EVALUATION_RESULT_MEMBER_DRIFT")
            handle = None
        with archive.open(info) as source:
            for block in iter(lambda: source.read(1024**2), b""):
                digest.update(block); size += len(block)
                if handle is not None:
                    handle.write(block)
        actual = {"sha256": digest.hexdigest(), "size_bytes": size}
        _require(size == info.file_size and (pin is None or actual == pin), "F45_EVALUATION_RESULT_MEMBER_DRIFT")
        if handle is not None:
            handle.flush(); os.fsync(handle.fileno()); handle.close()
            try:
                os.link(temporary, path)
            except FileExistsError:
                _require(not path.is_symlink() and path.stat().st_size == size and sha256_file(path) == actual["sha256"],
                         "F45_EVALUATION_RESULT_MEMBER_DRIFT")
            directory = os.open(path.parent, os.O_RDONLY)
            try:
                os.fsync(directory)
            finally:
                os.close(directory)
        else:
            _require(sha256_file(path) == actual["sha256"], "F45_EVALUATION_RESULT_MEMBER_DRIFT")
    finally:
        if temporary is not None:
            if not handle.closed:
                handle.close()
            temporary.unlink(missing_ok=True)


def prepare_f45_evaluation(run, unit, root):
    """Resume at a durable outer boundary; use only compact numerical sources."""
    from . import nested_loco as nested
    from .runtime import _readback_ordered, observe_execution_resources
    target = root / "evaluation-input.zip"
    if target.is_file():
        return load_f45_evaluation(target, run, unit, root)
    required = 3 * 1000 * run["budgets"]["retained_bytes_per_replicate"]
    _require(observe_execution_resources(root)["scratch_available_bytes"] >= required,
             "F45_EVALUATION_DELIVERY_PEAK_INSUFFICIENT")
    by_id = {u["unit_id"]: u for u in run["units"]}
    source_units = [by_id[f"{kind}-H{unit['horizon']:02d}-O{o}"]
                    for kind in ("PRIMARY", "AAR") for o in range(1, 7)]
    jobs = [(run, u, str(Path(run["run_root"]) / "units" / u["unit_id"])) for u in source_units]
    if run.get("kind") == "PADML_INTEGRATED_RAW_RUN_V1":
        paths = [str(Path(location) / "evaluation-input.zip") for _, _, location in jobs]
        _require(all(Path(p).is_file() for p in paths), "F45_COMPACT_DEPENDENCIES_NOT_READY")
    else:
        paths = _readback_ordered(_f45_evaluation_source_job, jobs, policy=run["resource_policy"], root=root,
            retained_bytes=4096 * len(jobs))
    loaded = _readback_ordered(_f45_evaluation_load_job,
        [(p, run, u) for p, u in zip(paths, source_units, strict=True)],
        policy=run["resource_policy"], root=root,
        retained_bytes=32 * sum(Path(p).stat().st_size for p in paths), cache_files=map(Path, paths))
    context = _f45_evaluation_context(run, root, loaded[:6])
    handoff = _a12_handoff_from_outers(context, [row["metadata"] for row in loaded[6:]])
    records = [row["archive_record"] for row in loaded[6:]]
    _a12_primary_point_origin(_validate_a12_handoff(handoff), context["evaluation_response_csv"],
                              context["primary_point"], context["primary_point_native"])
    members = {"context.json": canonical_json_bytes({k: v for k, v in context.items()
                if k not in {"evaluation_response_csv", "primary_point_native"}}),
        "response.csv": context["evaluation_response_csv"],
        "primary-point-native.zip": context["primary_point_native"],
        "predictions.json": canonical_json_bytes(handoff),
        **{f"sources/{u['unit_id']}.zip": Path(p) for p, u in zip(paths, source_units, strict=True)}}
    pins = {n: {"sha256": sha256_file(b) if isinstance(b, Path) else sha256_bytes(b),
                "size_bytes": b.stat().st_size if isinstance(b, Path) else len(b)} for n, b in members.items()}
    manifest = nested._sealed({"kind": "PADML_F45_COMPACT_EVALUATION_V1", "unit_id": unit["unit_id"],
        "horizon": unit["horizon"], "source_archives": records, "members": pins})
    # Coordinates, their temporary publication, result.zip and enclosing unit.zip.
    # The compact input is also retained beside and inside result.zip.
    reserved = required + 4 * sum(pin["size_bytes"] for pin in pins.values()) + 1024**2
    observation = observe_execution_resources(root)
    _require(observation["scratch_available_bytes"] >= reserved, "F45_EVALUATION_DELIVERY_PEAK_INSUFFICIENT")
    capacity = {
        "kind": "OPERATIONAL_UPPER_BOUND_NOT_MEASURED_PEAK", "coordinate_count": 1000,
        "coordinate_retention_bytes": 1000 * run["budgets"]["retained_bytes_per_replicate"],
        "compact_uncompressed_bytes": sum(pin["size_bytes"] for pin in pins.values()),
        "additional_peak_bound_bytes": reserved}
    capacity_path = root / "evaluation-capacity.json"
    if capacity_path.is_file():
        # Preserve the two actually published 8-MiB operational records. The
        # new live admission above still uses this run's corrected ZIP budget.
        retained_old = 8 * 1024**2
        legacy = [{**capacity, "coordinate_retention_bytes": count * retained_old,
            "additional_peak_bound_bytes": 3 * count * retained_old
                + 4 * capacity["compact_uncompressed_bytes"] + 1024**2} for count in (1000, 1001)]
        _require(capacity_path.read_bytes() in tuple(canonical_json_bytes(row) for row in [capacity, *legacy]),
                 "F45_EVALUATION_CAPACITY_DRIFT")
    else:
        nested._write_exact_once(capacity_path, canonical_json_bytes(capacity), "F45_EVALUATION_CAPACITY_DRIFT")
    write_deterministic_zip(target, {"evaluation-input.json": canonical_json_bytes(manifest), **members},
        stored_members={n for n in members if n.endswith(".zip")})
    return {"context": context, "handoff": handoff, "records": records, "path": target}


def load_f45_evaluation(path, run, unit, root, *, input_member=None):
    """Read the complete OOC/point source without any development archive."""
    from . import nested_loco as nested
    from .f4 import _f45_optimism_json, _f45_optimism_member
    from .runtime import _readback_ordered
    by_id = {u["unit_id"]: u for u in run["units"]}
    source_units = [by_id[f"{kind}-H{unit['horizon']:02d}-O{o}"]
                    for kind in ("PRIMARY", "AAR") for o in range(1, 7)]
    with _f45_evaluation_input(path,input_member) as archive:
        manifest = _f45_optimism_json(_f45_optimism_member(archive, "evaluation-input.json"))
        expected = {"context.json", "response.csv", "primary-point-native.zip", "predictions.json",
                    *(f"sources/{u['unit_id']}.zip" for u in source_units)}
        _require(manifest.get("kind") == "PADML_F45_COMPACT_EVALUATION_V1"
            and manifest["unit_id"] == unit["unit_id"] and manifest["horizon"] == unit["horizon"]
            and set(manifest["members"]) == expected and len(archive.namelist()) == len(expected) + 1
            and set(archive.namelist()) == expected | {"evaluation-input.json"},
            "F45_EVALUATION_COMPACT_INPUT_INVALID")
        data = {}
        for name, pin in manifest["members"].items():
            if not name.startswith("sources/"):
                data[name] = _f45_optimism_member(archive, name, pin)
    loaded = _readback_ordered(_f45_evaluation_load_job,
        [(str(path), run, u, f"sources/{u['unit_id']}.zip",
          manifest["members"][f"sources/{u['unit_id']}.zip"],input_member) for u in source_units],
        policy=run["resource_policy"], root=root,
        retained_bytes=32 * sum(pin["size_bytes"] for pin in manifest["members"].values()),
        cache_files=[path])
    context = _f45_optimism_json(data["context.json"])
    context.update(evaluation_response_csv=data["response.csv"], primary_point_native=data["primary-point-native.zip"])
    registry = nested.validate_population_registry(context["population_registry"])
    ooc = nested.assemble_selected_ooc([row["selected_prediction"] for row in loaded[:6]], population_registry=registry)
    _require(context["primary"] == ooc
        and context["science_decision"]["identity_sha256"] == ooc["science_decision_sha256"]
        and all(nested.compatible_science_decisions(row["request"]["science_decision"], context["science_decision"])
                for row in loaded[:6])
        and context["source"]["primary_source_archives"] == [
            {"outer_fold": u["outer_fold"], "member": f"execution-o{u['outer_fold']:02d}.zip",
             "identity_sha256": row["metadata"]["identity_sha256"],
             **row["manifest"]["source_receipt"]["artifacts"]["result.zip"]}
            for u, row in zip(source_units[:6], loaded[:6], strict=True)]
        and context["source"]["primary_input_sha256"] == {
            str(u["outer_fold"]): row["manifest"]["source_receipt"]["artifacts"]["input.zip"]["sha256"]
            for u, row in zip(source_units[:6], loaded[:6], strict=True)}, "F45_EVALUATION_PRIMARY_BINDING_DRIFT")
    handoff = _a12_handoff_from_outers(context, [row["metadata"] for row in loaded[6:]])
    records = [row["archive_record"] for row in loaded[6:]]
    _require(canonical_json_bytes(handoff) == data["predictions.json"] and records == manifest["source_archives"],
             "F45_EVALUATION_COMPACT_REDUCTION_DRIFT")
    _a12_primary_point_origin(_validate_a12_handoff(handoff), context["evaluation_response_csv"],
                              context["primary_point"], context["primary_point_native"])
    return {"context": context, "handoff": handoff, "records": records, "path": path,
        "training_contexts":{str(u['outer_fold']):row['request']['training_context']
            for u,row in zip(source_units[:6],loaded[:6],strict=True)}}


def execute_f45_compact_evaluation(run, unit, root, prepared):
    """The original B1000 engine consumes compact sources and writes one compact result."""
    from . import nested_loco as nested
    from .runtime import observe_execution_resources
    context, handoff, records = (prepared[k] for k in ("context", "handoff", "records"))
    shared = Path(run["run_root"]) / "shared"
    stage = root / "result.zip.work"
    stage.mkdir(mode=0o700, exist_ok=True)
    evaluation = stage / "evaluation"
    numeric = evaluate_a12_incremental_value(handoff, context["evaluation_response_csv"],
        replicate_count=1000, formal=True, evidence_root=evaluation, resource_policy=run["resource_policy"],
        retained_bytes_per_replicate=run["budgets"]["retained_bytes_per_replicate"],
        retained_primary_point=context["primary_point"], primary_point_native=context["primary_point_native"],
        retained_rng_archive=shared / "bootstrap.zip",
        retained_rng_preparation_record=strict_json_bytes((shared / "bootstrap-preparation.json").read_bytes()))
    result = _a12_native_summary(context, numeric, records)
    members = {"evaluation-input.zip": prepared["path"], "a12.json": canonical_json_bytes(result),
        "predictions.json": canonical_json_bytes(handoff),
        **{f"evaluation/{n}": evaluation / n for n in _a12_evaluation_member_names(nested=True)}}
    total = sum(v.stat().st_size if isinstance(v, Path) else len(v) for v in members.values())
    _require(observe_execution_resources(root)["scratch_available_bytes"] >= 2 * (total + 4096 * len(members)),
             "F45_EVALUATION_DELIVERY_PEAK_INSUFFICIENT")
    write_deterministic_zip(root / "result.zip", members, stored_members={n for n in members if n.endswith(".zip")})
    from .runtime import advise_completed_io
    advise_completed_io([v for v in members.values() if isinstance(v, Path)] + [root/'result.zip'])
    return result


def replay_f45_compact_evaluation(run, unit, root):
    """Final reports depend only on retained compact sources and native metric bytes."""
    from . import nested_loco as nested
    from .f4 import _f45_optimism_member, _f45_optimism_json
    stage = root / "result.zip.work"
    evaluation = stage / "evaluation"
    evaluation.mkdir(mode=0o700, parents=True, exist_ok=True)
    with open_carrier(root / "result.zip") as archive:
        expected = {"evaluation-input.zip", "a12.json", "predictions.json",
            *(f"evaluation/{n}" for n in _a12_evaluation_member_names(nested=True))}
        _require(len(archive.namelist()) == len(expected) and set(archive.namelist()) == expected,
                 "F45_EVALUATION_COMPACT_RESULT_MEMBERS_INVALID")
        value = _f45_optimism_json(_f45_optimism_member(archive, "a12.json"))
        prediction = _f45_optimism_member(archive, "predictions.json")
        for name in sorted(expected - {"a12.json", "predictions.json"}):
            path = root / name if name == "evaluation-input.zip" else stage / name
            _f45_evaluation_restore_member(archive, name, path)
    prepared = load_f45_evaluation(root / "evaluation-input.zip", run, unit, root)
    _require(canonical_json_bytes(prepared["handoff"]) == prediction, "F45_EVALUATION_COMPACT_REDUCTION_DRIFT")
    context = prepared["context"]
    numeric = _replay_a12_evaluation(evaluation, prepared["handoff"], context["evaluation_response_csv"],
        retained_primary_point=context["primary_point"], primary_point_native=context["primary_point_native"])
    _require(value == _a12_native_summary(context, numeric, prepared["records"]),
             "F45_EVALUATION_SUMMARY_REDUCTION_DRIFT")
    return value


def execute_a12_bundle(source: Path, target: Path, *, sources: list[Path] | None=None, f2_run_root: Path | None=None, workers: int | None=None, f1_runtime_root: Path | None=None, primary_input_bundles: Mapping[int, Path] | None=None, primary_compiled_input_records: Mapping[int, Mapping[str, Any]] | None=None, input_bundles: Mapping[int, Path] | None=None, resource_policy: Mapping[str, Any] | None=None, retained_bytes_per_replicate: int | None=None, bootstrap_inputs_only: bool=False, bootstrap_input: Path | None=None, point_archive: Path | None=None, bootstrap_shards: list[Path] | None=None, prepared_input_record: Mapping[str, Any] | None=None, retained_primary_source_bundle: Path | None=None, retained_rng_archive: Path | None=None, retained_rng_preparation_record: Mapping[str, Any] | None=None, unstarted_replicates: Mapping[int, list[int]] | None=None, complete_evaluation: bool=False) -> dict[str, Any]:
    """Open six native outers; prepare shared B inputs or gather their fixed rows."""
    _require(source.is_absolute() and source.is_file() and (not source.is_symlink()) and target.is_absolute() and target.parent.is_dir() and (not target.exists()) and (not target.is_symlink()), 'F5_A12_SIX_NATIVE_OUTERS_REQUIRED')
    _require(not complete_evaluation and not bootstrap_inputs_only and all(x is None for x in (bootstrap_input, point_archive, bootstrap_shards, prepared_input_record, retained_primary_source_bundle, unstarted_replicates)), "OLD_F45_EVALUATION_SHARD_ENTRY_REMOVED")
    from .f5 import _full_score_scratch
    from .f4 import _full_pipeline_archive_limits, _f45_source_member_sha256
    from .runtime import observe_execution_resources, resource_admission, validate_resource_policy
    from contextlib import nullcontext
    _require(type(False) is bool, 'F5_A12_BOOTSTRAP_PROFILE_INVALID')
    nested = primary_input_bundles is not None or input_bundles is not None
    _require(True, 'F5_RETAINED_AAR_SOURCE_SCOPE_INVALID')
    retained_primary = {}
    _require((retained_rng_archive is None) == (retained_rng_preparation_record is None), 'F5_A12_RETAINED_RNG_SOURCE_REQUIRED')
    _require(retained_rng_archive is None or nested, 'F5_A12_RETAINED_RNG_SCOPE_INVALID')
    _require(type(False) is bool, 'F5_A12_BOOTSTRAP_PROFILE_INVALID')
    _require(isinstance(sources, list) and len(sources) == 6 and (len({path.resolve() for path in sources}) == 6) and (f2_run_root is not None), 'F5_A12_PREPARATION_AUTHORITY_MIXED')
    if nested:
        _require(workers is None and (primary_input_bundles is not None and input_bundles is not None and (set(primary_input_bundles) == set(input_bundles) == set(range(1, 7))) and (workers is None) and isinstance(primary_compiled_input_records, Mapping) and (set(primary_compiled_input_records) == set(range(1, 7))) and (type(retained_bytes_per_replicate) is int) and (retained_bytes_per_replicate > 0)), 'F5_A12_NESTED_AGGREGATE_SCOPE_INVALID')
        resource_policy = validate_resource_policy(resource_policy)
        resource_admission({**resource_policy, 'memory_bytes_per_worker': MIN_WORKER_MEMORY_BYTES, 'scratch_reserve_bytes': 0}, observe_execution_resources(target.parent), legal_tasks=1)
        lineage = None
    else:
        _require(resource_policy is None and retained_bytes_per_replicate is None and (primary_compiled_input_records is None), 'F5_A12_NESTED_AGGREGATE_SCOPE_INVALID')
        raw = source.read_bytes()
        lineage = strict_json_bytes(raw)
        _require(canonical_json_bytes(lineage) == raw, 'F5_A12_LINEAGE_NONCANONICAL')
    root = target.with_name(target.name + '.work')
    root.mkdir(mode=448, exist_ok=True)
    try:
        with _full_score_scratch(root) if nested else nullcontext():
            captured = {'members': {}, 'records': {}, 'jobs': []}
            outer_input_reports = {}
            prepared_data = None
            context = _a12_context(f2_run_root, lineage, f1_runtime_root=f1_runtime_root, **retained_primary, **{'primary_archive': source, 'primary_input_bundles': primary_input_bundles, 'primary_compiled_input_records': primary_compiled_input_records, 'replay_evidence': Path(tempfile.mkdtemp(prefix='primary-read-', dir=root)) / 'evidence'} if nested else {})
            loaded = []
            for path in sources or []:
                if nested:
                    with open_carrier(path) as archive:
                        metadata_limit = 3 * max((_full_pipeline_archive_limits(family)['metadata'] for family in _A12_FIXED_FAMILIES | _A12_TUNED_FAMILIES))
                        _require(archive.getinfo('a12-outer.json').file_size <= metadata_limit, 'F5_A12_OUTER_INDEX_TOO_LARGE')
                        outer = strict_json_bytes(archive.read('a12-outer.json'))['outer_fold']
                    _require(type(outer) is int and outer in range(1, 7), 'F5_A12_SIX_NATIVE_OUTERS_REQUIRED')
                    loader_execution = {}
                    row = _load_a12_outer_archive(path, input_bundle=input_bundles[outer], execution_report=loader_execution, **retained_primary, **{})
                else:
                    row = _load_a12_outer_archive(path, lineage, f2_run_root=f2_run_root, workers=workers, f1_runtime_root=f1_runtime_root)
                if nested:
                    from .f4 import _f45_source_member_sha256
                    _require(str(outer) not in outer_input_reports and set(loader_execution) == {'path', 'sha256', 'size_bytes'} and (type(loader_execution['size_bytes']) is int) and (0 < loader_execution['size_bytes'] <= 64 * 1024 ** 2), 'F5_A12_FINAL_INPUT_EXECUTION_INVALID')
                    resource_admission({**resource_policy, 'memory_bytes_per_worker': MIN_WORKER_MEMORY_BYTES, 'scratch_reserve_bytes': 0, 'memory_reserve_bytes': resource_policy['memory_reserve_bytes'] + 32 * loader_execution['size_bytes']}, observe_execution_resources(root), legal_tasks=1)
                    report_path = Path(loader_execution['path'])
                    _require(report_path.is_file() and (not report_path.is_symlink()) and (report_path.resolve(strict=True) == report_path), 'F5_A12_FINAL_INPUT_EXECUTION_INVALID')
                    with report_path.open('rb') as handle:
                        report_raw = handle.read(loader_execution['size_bytes'] + 1)
                    row_raw = canonical_json_bytes(row)
                    _validate_a12_final_input_execution(report_raw, binding={'executor_source_identity': sha256_bytes(canonical_json_bytes(_f45_source_member_sha256())), 'operation': 'OUTER_REPLAY', 'outer_fold': outer, 'family': row['family'], 'task_names': list(_a12_final_task_coordinates(outer)), 'input_archive': {'sha256': sha256_file(path), 'size_bytes': path.stat().st_size}, 'projected_input': {'sha256': sha256_file(input_bundles[outer]), 'size_bytes': input_bundles[outer].stat().st_size}, 'projected_input_identity_sha256': row['source']['identity_sha256'], 'work_root': str(report_path.parent)}, result_pin={'sha256': sha256_bytes(row_raw), 'size_bytes': len(row_raw)}, policy=row['source']['resource_policy'], loader_report=True, expected_pin={key: loader_execution[key] for key in ('sha256', 'size_bytes')})
                    del report_raw, row_raw
                    outer_input_reports[str(outer)] = loader_execution
                loaded.append((row, path))
            loaded.sort(key=lambda item: item[0]['outer_fold'])
            handoff = _a12_handoff_from_outers(context, [row for row, _ in loaded])
            records = [_a12_outer_archive_record(row, path) for row, path in loaded]
            prepared_members = None
            result = evaluate_a12_incremental_value(handoff, context['evaluation_response_csv'] if nested else context['frozen']['response_csv'], replicate_count=1000, workers=workers, formal=True, evidence_root=root / 'evaluation', **{'resource_policy': resource_policy, 'retained_bytes_per_replicate': retained_bytes_per_replicate, 'retained_primary_point': context['primary_point'], 'primary_point_native': context['primary_point_native'], 'retained_rng_archive': retained_rng_archive, 'retained_rng_preparation_record': retained_rng_preparation_record} if nested else {})
            result = _a12_native_summary(context, result, records)
            members = {record['member']: path for record, (_, path) in zip(records, loaded, strict=True)}
            members.update({f'evaluation/{name}': root / 'evaluation' / name for name in _a12_evaluation_member_names(nested=nested, sharded=False)})
            if nested:
                members['primary.zip'] = source
                (root / 'predictions.json').write_bytes(canonical_json_bytes(handoff))
                members['predictions.json'] = root / 'predictions.json'
                reserved = 2 * (sum((path.stat().st_size for path in members.values())) + len(canonical_json_bytes(result)) + 1024 * len(members))
                observation = observe_execution_resources(root)
                _require(observation['scratch_available_bytes'] >= reserved, 'F5_A12_PREPARATION_SPACE_INSUFFICIENT')
                admission = resource_admission({**resource_policy, 'memory_bytes_per_worker': MIN_WORKER_MEMORY_BYTES, 'scratch_reserve_bytes': 0}, observation, legal_tasks=1)
                (root / 'aggregate-execution.json').write_bytes(canonical_json_bytes({'resource_policy': resource_policy, 'executor_source_identity': sha256_bytes(canonical_json_bytes(_f45_source_member_sha256())), 'execution_worker_memory_bytes': MIN_WORKER_MEMORY_BYTES, 'execution_scratch_reserve_bytes': 0, 'archive_reserved_bytes': reserved, 'resource_observation': observation, 'resource_admission': admission, **{}}))
                members['aggregate-execution.json'] = root / 'aggregate-execution.json'
            write_deterministic_zip(target, {'a12.json': canonical_json_bytes(result), **members}, stored_members={name for name in members if name.endswith('.zip')})
    except BaseException as exc:
        exc.add_note(f'F5_A12_AGGREGATE_EVIDENCE_RETAINED:{root}')
        raise
    if not nested:
        shutil.rmtree(root)
    return {'status': result['status'], 'statistical_status': result['statistical_status'], 'stage_acceptance': False, 'bootstrap_replicates': 1000, 'new_model_fits': 0, 'sha256': sha256_file(target), 'size_bytes': target.stat().st_size, **({'work_evidence_retained': str(root), 'outer_input_execution': outer_input_reports} if nested else {}), **{}}


def _a12_nested_mice_source(value: Any, *, retained_primary_source_bundle: Path | None = None,
                            retained_mice_gather: bool = False,
                            retained_no_aar_selector: bool = False,
                            retained_no_aar_selector_input: bool = False,
                            retained_primary_context: bool = False) -> dict[str, Any]:
    """The new raw channel inherits one primary outer, never a global family."""
    from . import nested_loco as nested
    from .f4 import _f45_source_member_sha256, _retained_full0_source_members
    from .f4 import _f45_same_run_source

    _require(isinstance(value, Mapping) and set(value) == {
        "program_id", "estimand", "primary_training_context", "primary_development_lock", "science_decision"}
        and value.get("program_id") == nested.PROGRAM_ID
        and value.get("estimand") in {nested.A12_TOTAL_AAR, nested.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT},
        "NESTED_AAR_MICE_SOURCE_INVALID")
    science_decision = nested.validate_science_decision(value["science_decision"])
    resolved_primary_context = (retained_primary_context
        or retained_primary_source_bundle is not None
        and not (retained_mice_gather or retained_no_aar_selector))
    _require(all(type(flag) is bool for flag in (retained_mice_gather, retained_no_aar_selector,
                                                retained_no_aar_selector_input,
                                                retained_primary_context))
             and type(resolved_primary_context) is bool
             and sum((retained_mice_gather, retained_no_aar_selector, resolved_primary_context)) <= 1
             and (not retained_no_aar_selector_input or retained_no_aar_selector)
             and (not retained_no_aar_selector or value["estimand"] == nested.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT)
             and (not (retained_mice_gather or retained_no_aar_selector or resolved_primary_context)
             or retained_primary_source_bundle is not None
             and "twelve_month_development" not in science_decision
             and science_decision["identity_sha256"] == "37c96bdd67c8e08a8ae4f1e29bf43023b8d8fb2375bc057079d1ca8581ef4648"),
             "F5_RETAINED_AAR_SOURCE_SCOPE_INVALID")
    context = nested.validate_training_context(value["primary_training_context"])
    lock = nested.validate_development_lock(value["primary_development_lock"], context=context,
                                            science_decision=science_decision)
    _require(not retained_no_aar_selector_input or value["estimand"] == nested.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT
             and context["outer_fold"] == lock["outer_fold"] == 3
             and lock["selected_family"] == "GBM_COX",
             "F5_RETAINED_AAR_SELECTOR_INPUT_SOURCE_DRIFT")
    producer = (_f45_same_run_source(context["modeling_program_sha256"]) if retained_primary_source_bundle is None else
                _retained_full0_source_members(retained_primary_source_bundle,
                    **({"aar_mice_gather": True} if retained_mice_gather else {}),
                    **({"aar_no_aar_selector": True} if retained_no_aar_selector else {}),
                    **({"aar_no_aar_selector_input": True} if retained_no_aar_selector_input else {}),
                    **({"aar_primary_context": True} if resolved_primary_context else {})))
    _require(context["scope"] == "OUTER" and context["channel"] == "PRIMARY"
             and context["modeling_program_sha256"] == sha256_bytes(canonical_json_bytes(producer))
             and all(lock[name] == context[name] for name in (
                 "outer_fold", "heldout_center", "training_ids_sha256", "heldout_ids_sha256")),
             "NESTED_AAR_MICE_PRIMARY_BINDING_INVALID")
    return context


def _a12_total_mice_input_members(
    contract: Mapping[str, Any], covariates: bytes, response: bytes,
    outer_fold: int, view_id: str, *, nested_source: Mapping[str, Any] | None = None,
    resource_policy: Mapping[str, Any] | None = None,
) -> dict[str, bytes]:
    """Project one original F1 view, never regenerate patients, splits or seeds."""
    from .f1_kernel import _view_seed_rows, view_row_ids

    _require(contract.get("covariates_sha256") == sha256_bytes(covariates)
             and contract.get("response_seal_sha256") == sha256_bytes(response),
             "F5_A12_MICE_BINDING_DATA_MISMATCH")
    registry = contract["registry"]
    analysis, rows = view_row_ids(registry, outer_fold, view_id)
    view = next(row for row in registry["views"][str(outer_fold)] if row["view_id"] == view_id)
    if nested_source is not None:
        from .nested_loco import validate_training_context
        from .runtime import validate_resource_policy

        resource_policy = validate_resource_policy(resource_policy)
        context = _a12_nested_mice_source(nested_source)
        _require(outer_fold == context["outer_fold"], "NESTED_AAR_MICE_PRIMARY_BINDING_INVALID")
        fields, responses = _response_rows(response)
        validate_training_context(context, _write_response_subset(
            fields, responses, context["training_ids"], None)["private_bytes"])
    else:
        _require(resource_policy is None, "NESTED_AAR_MICE_SOURCE_INVALID")
    package = Path(__file__).parent
    value = {
        "kind": "PADML_F5_A12_TOTAL_MICE_INPUT" if nested_source is None else "PADML_NESTED_AAR_MICE_INPUT_V1",
        **({"nested_source": dict(nested_source), "resource_policy": resource_policy,
            "execution_profile": {"pool_workers": CPU_MINUS_8, "engine_threads": 1}}
           if nested_source is not None else {}),
        "binding_contract_sha256": sha256_bytes(canonical_json_bytes(dict(contract))),
        "authority_sha256": sha256_file(package / "science/authority.json"),
        "variable_sha256": sha256_file(package / "science/variable.csv"),
        "chain_seeds": [row["seed"] for row in _view_seed_rows(registry, outer_fold, view_id)],
        "view": {"view_id": view_id, "role": view["role"], "outer_fold": outer_fold,
                 "analysis_ids": analysis, "row_ids": rows,
                 "row_ids_sha256": view["row_ids_sha256"]},
    }
    members = {"input.json": canonical_json_bytes(value)}
    for name, raw, ids in [("covariates.csv", covariates, rows)] + (
        [("response.csv", response, analysis)] if view["role"] == "ANALYSIS" else []
    ):
        reader = csv.DictReader(io.StringIO(raw.decode("utf-8-sig")))
        records = list(reader)
        by_id = {row["Patient_ID"]: row for row in records}
        _require(len(records) == len(by_id) and set(ids).issubset(by_id),
                 "F5_A12_MICE_SOURCE_ROWS_INVALID")
        stream = io.StringIO(newline="")
        columns = [column for column in reader.fieldnames
                   if not (nested_source is not None and name == "covariates.csv"
                           and column in {"AST", "ALT", "AST_ALT"})]
        writer = csv.DictWriter(stream, fieldnames=columns, lineterminator="\n")
        writer.writeheader()
        writer.writerows({column: by_id[patient][column] for column in columns} for patient in ids)
        members[name] = stream.getvalue().encode()
    return members


def _a12_native_primary_source(
    outer_fold: int, estimand: str, primary_input_bundle: Path, primary_outer_archive: Path,
    f2_run_root: Path, f1_runtime_root: Path | None, resource_policy: Mapping[str, Any],
    *, accepted_source_reader=None, on_materialized_fold=None, replay_evidence: Path | None = None,
    compiled_input_record: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Shared local primary reader for a single view or its complete outer."""
    from . import nested_loco as nested
    from .f4 import _load_o_fit_execution_archive, load_o_fit_execution_archive
    from .runtime import validate_resource_policy

    _require(on_materialized_fold is None or callable(accepted_source_reader) and callable(on_materialized_fold),
             "F4_O_FIT_SHARED_FOLD_SCOPE_INVALID")
    _require(estimand in {nested.A12_TOTAL_AAR, nested.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT}
             and all(isinstance(path, Path) and path.is_absolute() for path in
                     (primary_input_bundle, primary_outer_archive, f2_run_root))
             and primary_input_bundle.is_file() and not primary_input_bundle.is_symlink(),
             "NESTED_AAR_NATIVE_PRIMARY_SOURCE_REQUIRED")
    validate_resource_policy(resource_policy)
    with open_carrier(primary_input_bundle) as archive:
        info = archive.getinfo("o-fit-input.json")
        _require(info.file_size <= 32 * 1024 * 1024, "F4_O_FIT_INPUT_INVALID")
        raw = archive.read(info)
    request = strict_json_bytes(raw)
    _require(canonical_json_bytes(request) == raw, "F4_O_FIT_INPUT_INVALID")
    nested.validate_science_decision(request["science_decision"])
    _require(request["training_context"]["outer_fold"] == outer_fold,
             "NESTED_AAR_MICE_PRIMARY_BINDING_INVALID")
    reader = load_o_fit_execution_archive if accepted_source_reader is None else _load_o_fit_execution_archive
    primary = reader(primary_outer_archive, input_bundle=primary_input_bundle,
        f2_run_root=f2_run_root, f1_runtime_root=f1_runtime_root,
        **({} if accepted_source_reader is None else {"accepted_source_reader": accepted_source_reader}),
        **({} if on_materialized_fold is None else {"on_materialized_fold": on_materialized_fold}),
        **({} if compiled_input_record is None else {"compiled_input_record": compiled_input_record}),
        **({} if replay_evidence is None else {"replay_evidence": replay_evidence}))
    _require(primary["kind"] == "PADML_F4_O_FIT_EXECUTION_ARCHIVE_V3"
             and primary["outer_fold"] == outer_fold
             and primary["input_identity_sha256"] == request["identity_sha256"]
             and primary["science_decision_sha256"] == request["science_decision"]["identity_sha256"]
             and primary["input_archive"] == {"sha256": sha256_file(primary_input_bundle),
                                              "size_bytes": primary_input_bundle.stat().st_size}
             and primary["family"] == primary["development_lock"]["selected_family"],
             "NESTED_AAR_MICE_PRIMARY_BINDING_INVALID")
    source = {"program_id": nested.PROGRAM_ID, "estimand": estimand,
        "primary_training_context": request["training_context"],
        "primary_development_lock": primary["development_lock"], "science_decision": request["science_decision"]}
    _a12_nested_mice_source(source)
    return source


def compile_a12_total_mice_input(
    f1_manifest: Path, binding_result: Path, outer_fold: int, view_id: str, target: Path,
    *, estimand: str | None = None, primary_input_bundle: Path | None = None,
    primary_outer_archive: Path | None = None, f2_run_root: Path | None = None,
    f1_runtime_root: Path | None = None,
    resource_policy: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Local custody: native-replay the primary, then send only one projected view."""
    from .f1_contract import load_f1_input_manifest

    nested_source = None
    if any(value is not None for value in (estimand, primary_input_bundle, primary_outer_archive,
                                           f2_run_root, f1_runtime_root, resource_policy)):
        nested_source = _a12_native_primary_source(outer_fold, estimand, primary_input_bundle,
            primary_outer_archive, f2_run_root, f1_runtime_root, resource_policy)
    approved = load_f1_input_manifest(f1_manifest)
    record = next(row for row in approved["direct_objects"] if row["unit_id"] == "data-binding")
    _require(binding_result.is_absolute() and binding_result.is_file()
             and not binding_result.is_symlink()
             and binding_result.stat().st_size == record["result_size_bytes"]
             and sha256_file(binding_result) == record["result_sha256"]
             and target.is_absolute() and target.parent.is_dir() and not target.exists(),
             "F5_A12_MICE_APPROVED_BINDING_REQUIRED")
    result = read_safe_zip(binding_result, expected_members={
        "manifest.json", "outputs/data-binding/payload.zip"})
    payload = result["outputs/data-binding/payload.zip"]
    _require(sha256_bytes(payload) == record["artifact_sha256"],
             "F5_A12_MICE_APPROVED_BINDING_REQUIRED")
    binding = read_safe_zip(payload, expected_members={
        "manifest.json", "binding/contract.json", "binding/covariates.csv",
        "binding/response-seal.csv"})
    raw = binding["binding/contract.json"]
    contract = strict_json_bytes(raw)
    _require(canonical_json_bytes(contract) == raw
             and sha256_bytes(raw) == approved["binding_contract_sha256"],
             "F5_A12_MICE_APPROVED_BINDING_REQUIRED")
    members = _a12_total_mice_input_members(
        contract, binding["binding/covariates.csv"], binding["binding/response-seal.csv"],
        outer_fold, view_id, nested_source=nested_source, resource_policy=resource_policy,
    )
    write_deterministic_zip(target, members)
    _load_a12_total_mice_input(target)
    return {"sha256": sha256_file(target), "size_bytes": target.stat().st_size,
            "view_id": view_id, "outer_fold": outer_fold, "stage_acceptance": False}


def _load_a12_total_mice_input(source: Path, *, a04_variant: bool = False,
                             a04_negative: bool = False, a12_validation: bool = False,
                             retained_primary_source_bundle: Path | None = None,
                             retained_mice_gather: bool = False,
                             retained_primary_context: bool = False) -> tuple[dict, dict[str, bytes]]:
    """Shared frozen F1 view admission; A04 changes only its explicit variant."""
    _require(source.is_absolute() and source.is_file() and not source.is_symlink(),
             "F5_A12_MICE_INPUT_PATH_INVALID")
    entries = read_safe_zip(source)
    _require("input.json" in entries, "F5_A12_MICE_INPUT_INVALID")
    value = strict_json_bytes(entries["input.json"])
    nested = isinstance(value, dict) and value.get("kind") == "PADML_NESTED_AAR_MICE_INPUT_V1"
    _require(retained_primary_source_bundle is None or nested and not any((a04_variant, a04_negative, a12_validation)),
             "F5_RETAINED_AAR_SOURCE_SCOPE_INVALID")
    package = Path(__file__).parent
    _require(all(type(flag) is bool for flag in (a04_variant, a04_negative, a12_validation))
        and sum((a04_variant, a04_negative, a12_validation, nested)) <= 1 and isinstance(value, dict) and set(value) == ({
        "kind", "binding_contract_sha256", "authority_sha256", "variable_sha256",
        "chain_seeds", "view"} | ({"a04_variant"} if a04_variant else
                                 {"a04_coordinates"} if a04_negative else
                                 {"nested_source", "resource_policy", "execution_profile"} if nested else set()))
        and canonical_json_bytes(value) == entries["input.json"]
        and value["kind"] == ("PADML_F5_A04_VARIANT_MICE_INPUT" if a04_variant else
                              "PADML_F5_A04_NEGATIVE_MICE_INPUT" if a04_negative else
                              "PADML_F45_A12_M2_VALIDATION_INPUT" if a12_validation else
                              "PADML_NESTED_AAR_MICE_INPUT_V1" if nested else "PADML_F5_A12_TOTAL_MICE_INPUT")
        and value["authority_sha256"] == sha256_file(package / "science/authority.json")
        and value["variable_sha256"] == sha256_file(package / "science/variable.csv"),
        "F5_A12_MICE_INPUT_INVALID")
    validate_sha256(value["binding_contract_sha256"], "F5_A12_MICE_BINDING")
    view, seeds = value["view"], value["chain_seeds"]
    count = 2 if a04_negative or a12_validation else 20
    if a12_validation:
        _require(isinstance(view, dict) and view.get("outer_fold") == 1
                 and view.get("view_id") in {"OUTER_ANALYSIS", "OUTER_APPLICATION"}
                 and view.get("view_id") == "OUTER_" + str(view.get("role"))
                 and seeds == ([150000001, 150000002] if view.get("role") == "ANALYSIS" else
                               [150000021, 150000022]),
                 "F45_A12_VALIDATION_COORDINATES_INVALID")
    if a04_negative:
        _a04_variant_model_seed(value["a04_coordinates"])
        _require(value["a04_coordinates"]["variant"] == "NEGATIVE_CONTROL" and isinstance(view, dict)
                 and view.get("role") == "ANALYSIS" and view.get("view_id") == "OUTER_ANALYSIS"
                 and view.get("outer_fold") == value["a04_coordinates"]["outer_fold"],
                 "F5_A04_NEGATIVE_MICE_COORDINATES_INVALID")
    if a04_variant:
        _require(isinstance(value["a04_variant"], str) and value["a04_variant"] in A04_NEW_MICE_VARIANTS
                 and isinstance(view, dict)
                 and view.get("view_id") in {"OUTER_ANALYSIS", "OUTER_APPLICATION"}
                 and view.get("view_id") == "OUTER_" + str(view.get("role")),
                 "F5_A04_MICE_VARIANT_INVALID")
    _require(isinstance(view, dict) and set(view) == {
        "view_id", "role", "outer_fold", "analysis_ids", "row_ids", "row_ids_sha256"}
        and view["role"] in {"ANALYSIS", "APPLICATION"}
        and type(view["outer_fold"]) is int and view["outer_fold"] in range(1, 7)
        and isinstance(view["view_id"], str) and bool(view["view_id"])
        and isinstance(seeds, list) and len(seeds) == count
        and all(type(seed) is int and 0 < seed < 2**31 for seed in seeds)
        and len(set(seeds)) == count,
        "F5_A12_MICE_VIEW_INVALID")
    for field in ("analysis_ids", "row_ids"):
        ids = view[field]
        _require(isinstance(ids, list) and ids
                 and all(isinstance(patient, str) and patient for patient in ids)
                 and len(ids) == len(set(ids)), "F5_A12_MICE_VIEW_ROWS_INVALID")
    _require(set(view["analysis_ids"]).issubset(view["row_ids"])
             and view["row_ids_sha256"] == sha256_bytes(canonical_json_bytes(view["row_ids"]))
             and (view["role"] != "ANALYSIS" or view["row_ids"] == view["analysis_ids"])
             and set(entries) == {"input.json", "covariates.csv"} | (
                 {"response.csv"} if view["role"] == "ANALYSIS" else set()),
             "F5_A12_MICE_VIEW_ROWS_OR_RESPONSE_INVALID")
    context = (_a12_nested_mice_source(value["nested_source"],
        **({"retained_mice_gather": True} if retained_mice_gather else {}),
        **({"retained_primary_context": True} if retained_primary_context else {}),
        **({"retained_primary_source_bundle": retained_primary_source_bundle}
           if retained_primary_source_bundle is not None else {})) if nested else None)
    if nested:
        from .runtime import validate_resource_policy

        validate_resource_policy(value["resource_policy"])
        _require(value["execution_profile"] == {"pool_workers": CPU_MINUS_8, "engine_threads": 1},
                 "NESTED_AAR_MICE_EXECUTION_PROFILE_INVALID")
        training, heldout = set(context["training_ids"]), set(context["heldout_ids"])
        outer_view = view["view_id"] in {"OUTER_ANALYSIS", "OUTER_APPLICATION"}
        _require(view["outer_fold"] == context["outer_fold"]
                 and view["view_id"].endswith("_" + view["role"])
                 and set(view["analysis_ids"]) <= training
                 and set(view["row_ids"]) <= (training | heldout if outer_view else training)
                 and (not outer_view or view["analysis_ids"] == context["training_ids"])
                 and (view["view_id"] != "OUTER_APPLICATION" or set(view["row_ids"]) == training | heldout),
                 "NESTED_AAR_MICE_VIEW_SCOPE_INVALID")
    reader = csv.DictReader(io.StringIO(entries["covariates.csv"].decode("utf-8-sig")))
    records = list(reader)
    columns = load_science_authority()["science"]["mice"]["private_handoff"]["columns"]
    if nested:
        columns = [column for column in columns if column not in {"AST", "ALT", "AST_ALT"}]
    _require(reader.fieldnames == columns
             and [row.get("Patient_ID") for row in records] == view["row_ids"],
             "F5_A12_MICE_COVARIATES_INVALID")
    if nested:
        _require(all(row["Center"] == context["centers_by_patient"][row["Patient_ID"]] for row in records),
                 "NESTED_AAR_MICE_CENTER_BINDING_INVALID")
    if view["role"] == "ANALYSIS":
        fields, response = _response_rows(entries["response.csv"])
        _require(fields == ["Patient_ID", "All_Cause_Death", "Death_Followup_months"]
                 and list(response) == view["analysis_ids"], "F5_A12_MICE_RESPONSE_INVALID")
        if nested and view["view_id"] == "OUTER_ANALYSIS":
            from .nested_loco import validate_training_context
            validate_training_context(context, entries["response.csv"])
    return value, entries


def _a12_mice_native_sources(*, a04_variant: bool = False, a04_negative: bool = False,
                             a12_validation: bool = False) -> dict[str, str]:
    from .f5 import _mice_native_sources
    name = "f5_a04_mice.R" if a04_variant else "f5_a04_negative.R" if a04_negative else "f5_a12_mice.R"
    names = [name, *(["f45_validation_mice.R", "f5_a04_negative.R"] if a12_validation else [])]
    return {**_mice_native_sources(), **{name: sha256_file(Path(__file__).with_name("kernels") / name)
                                        for name in names}}


def _a12_mice_reuse_identity(source: Path) -> str:
    """Identity of one same-branch calculation, after native input admission.

    The primary lock remains in the original input/RDS provenance. Its family
    and selection horizon choose which views are needed, not their MICE math.
    Both primary producers are still independently admitted by the input reader.
    """
    from .nested_loco import _base_science_decision_template
    value, entries = _load_a12_total_mice_input(source)
    _require(value["kind"] == "PADML_NESTED_AAR_MICE_INPUT_V1",
             "F45_AAR_MICE_REUSE_SCOPE_INVALID")
    origin = value["nested_source"]
    context = origin["primary_training_context"]
    body = {key: value[key] for key in (
        "kind", "binding_contract_sha256", "authority_sha256", "variable_sha256", "view", "chain_seeds")}
    body.update(program_id=origin["program_id"], estimand=origin["estimand"],
        science_decision=_base_science_decision_template(24),
        training_context={key: item for key, item in context.items()
                          if key not in {"identity_sha256", "modeling_program_sha256"}},
        native_sources=_a12_mice_native_sources(), engine_threads=1,
        inputs={name: {"sha256": sha256_bytes(raw), "size_bytes": len(raw)}
                for name, raw in entries.items() if name != "input.json"})
    return sha256_bytes(canonical_json_bytes(body))


def _a12_reused_mice_input(consumer: Path, payload: Path, record: Mapping[str, Any], target: Path) -> Path:
    """Read a completed producer's untouched input; never retag its numbers."""
    _require(isinstance(record, Mapping) and set(record) == {
        "whole_unit", "result_archive", "mice_archive", "view_archive",
        "producer_input", "consumer_input", "numerical_identity_sha256"},
        "F45_AAR_MICE_REUSE_RECORD_INVALID")
    for name in ("result_archive", "mice_archive", "view_archive", "producer_input", "consumer_input"):
        pin = record[name]
        _require(isinstance(pin, Mapping) and set(pin) == {"sha256", "size_bytes"}
                 and type(pin["size_bytes"]) is int and pin["size_bytes"] > 0,
                 "F45_AAR_MICE_REUSE_RECORD_INVALID")
        validate_sha256(pin["sha256"], "aar.mice.reuse." + name)
    receipt = record["whole_unit"]
    _require(isinstance(receipt, Mapping) and receipt.get("status") == "COMPLETED"
             and receipt.get("direct_consumer_completed") is True
             and receipt.get("artifacts", {}).get("result.zip") == record["result_archive"],
             "F45_AAR_MICE_REUSE_WHOLE_REQUIRED")
    validate_sha256(receipt.get("run_identity"), "aar.mice.reuse.run")
    _require(record["consumer_input"] == {"sha256": sha256_file(consumer), "size_bytes": consumer.stat().st_size}
             and record["view_archive"] == {"sha256": sha256_file(payload), "size_bytes": payload.stat().st_size},
             "F45_AAR_MICE_REUSE_BYTES_DRIFT")
    with open_carrier(payload) as archive:
        _require(archive.getinfo("input.zip").file_size == record["producer_input"]["size_bytes"]
                 and archive.getinfo("input.zip").file_size <= 128 * 1024**2,
                 "F45_AAR_MICE_REUSE_BYTES_DRIFT")
        raw = archive.read("input.zip")
    _require(sha256_bytes(raw) == record["producer_input"]["sha256"], "F45_AAR_MICE_REUSE_BYTES_DRIFT")
    from .nested_loco import _write_exact_once
    _write_exact_once(target, raw, "F45_AAR_MICE_REUSE_BYTES_DRIFT")
    producer, _ = _load_a12_total_mice_input(target)
    consumer_value, _ = _load_a12_total_mice_input(consumer)
    lock = producer["nested_source"]["primary_development_lock"]
    _require(receipt.get("unit_id") == f"AAR-H{lock['selection_horizon_months']:02d}-O{producer['view']['outer_fold']}"
             and receipt.get("selection_horizon_months") == lock["selection_horizon_months"]
             and receipt.get("report_horizons_months") == [6, 12, 24, 36]
             and consumer_value["nested_source"]["primary_development_lock"]["selection_horizon_months"]
                 != lock["selection_horizon_months"], "F45_AAR_MICE_REUSE_SCOPE_INVALID")
    _require(_a12_mice_reuse_identity(target) == record["numerical_identity_sha256"]
             == _a12_mice_reuse_identity(consumer), "F45_AAR_MICE_REUSE_DEPENDENCY_DRIFT")
    return target


def _a12_mice_output_members(*, a04_negative: bool = False, a12_validation: bool = False) -> set[str]:
    from .f5 import _MICE_CONFIGURATION_NAMES
    return {"summary.json", *{f"configuration/{name}.json" for name in _MICE_CONFIGURATION_NAMES},
            *{f"imputations/imp{index:02d}.csv" for index in range(1, 3 if a04_negative or a12_validation else 21)}}


def _a12_total_mice_spec(value: Mapping[str, Any], root: Path, *, a04_variant: bool = False,
                         a04_negative: bool = False, a12_validation: bool = False) -> dict[str, Any]:
    """The original native specification, also reconstructed by its numerical reader."""
    inputs = root / "inputs"
    package = Path(__file__).parent
    spec = {"mode": "IMPUTE_VIEW", "authority_path": str(package / "science/authority.json"),
            "variable_path": str(package / "science/variable.csv"),
            "covariates_path": str(inputs / "covariates.csv"),
            "output_dir": str(root / "output"), "view": value["view"],
            "chain_seeds": value["chain_seeds"]}
    if "nested_source" in value:
        spec["nested_aar_source"] = value["nested_source"]
    if value["view"]["role"] == "ANALYSIS":
        spec["response_path"] = str(inputs / "response.csv")
    if a04_variant:
        spec["a04_variant"] = value["a04_variant"]
    if a04_negative:
        spec["a04_coordinates"] = value["a04_coordinates"]
    if a12_validation:
        spec["pass_through"] = "A12_TOTAL_OUTER1_M1"
    return spec


def _run_a12_total_mice_input(
    source: Path, root: Path, *, native: Path | None = None, a04_variant: bool = False,
    a04_negative: bool = False, a12_validation: bool = False,
    retained_primary_source_bundle: Path | None = None,
    mice_restoration: Mapping[str, Any] | None = None,
    native_first_replay: bool = False,
) -> dict[str, Any]:
    from .f5 import _TYPED_MICE_ERROR
    from .runtime import R_LIBRARY, THREAD_ENV

    _require(type(native_first_replay) is bool, "F5_A12_NATIVE_FIRST_REPLAY_SCOPE_INVALID")
    if native_first_replay:
        record = _a12_h0_native_first_replay_record()
        attempt = Path(record["attempt_root"])
        _require(mice_restoration is None and not any((a04_variant, a04_negative, a12_validation))
                 and retained_primary_source_bundle is not None and source == attempt.parent / "input.zip"
                 and sha256_file(source) == record["original_input"]["sha256"]
                 and root == attempt / "native-work/first-audit/replay"
                 and native == attempt / "native-work/first-audit/native",
                 "F5_A12_NATIVE_FIRST_REPLAY_SCOPE_INVALID")
    if mice_restoration is not None:
        _validate_a12_mice_restoration_view(mice_restoration, source=source,
            retained_primary_source_bundle=retained_primary_source_bundle)
        attempt = Path(mice_restoration["attempt_root"])
        _require(root == attempt / ("native-work" if native is None else "native-work/first-audit/replay")
                 and (native is None or native == attempt / "native-work/first-audit/native")
                 and retained_primary_source_bundle is not None,
                 "F5_A12_MICE_RESTORATION_ATTEMPT_SCOPE_INVALID")
    value, entries = _load_a12_total_mice_input(source, a04_variant=a04_variant, a04_negative=a04_negative,
        **({"retained_primary_context": True} if mice_restoration is not None or native_first_replay else {}),
        a12_validation=a12_validation, **({"retained_primary_source_bundle": retained_primary_source_bundle}
                                          if retained_primary_source_bundle is not None else {}))
    admission = None
    if "nested_source" in value:
        from .runtime import observe_execution_resources, resource_admission

        admission = resource_admission({**value["resource_policy"], "memory_bytes_per_worker": MIN_WORKER_MEMORY_BYTES},
            observe_execution_resources(root.parent), legal_tasks=1)
    inputs = root / "inputs"
    from .nested_loco import _write_exact_once
    inputs.mkdir(mode=0o700, exist_ok=True)
    for name, raw in entries.items():
        _write_exact_once(inputs / name, raw, "F45_MICE_INPUT_DRIFT")
    package = Path(__file__).parent
    spec = _a12_total_mice_spec(value, root, a04_variant=a04_variant, a04_negative=a04_negative,
                               a12_validation=a12_validation)
    spec_path = root / "spec.json"
    _write_exact_once(spec_path, canonical_json_bytes(spec), "F45_MICE_SPEC_DRIFT")
    environment = {**os.environ, **THREAD_ENV}
    if admission is not None:
        environment.update({name: str(root) for name in ("TMPDIR", "TMP", "TEMP")})
    if any(Path(path).is_dir() for path in R_LIBRARY.split(":")):
        environment["R_LIBS_USER"] = R_LIBRARY
    kernel = ("f45_validation_mice.R" if a12_validation else "f5_a04_mice.R" if a04_variant
              else "f5_a04_negative.R" if a04_negative else "f5_a12_mice.R")
    command = [RSCRIPT_EXECUTABLE, "--vanilla", str(package / "kernels" / kernel),
               "FIT" if native is None else "REPLAY", str(spec_path)]
    if native is not None:
        command.append(str(native))
    with (root / "stdout.txt").open("wb") as stdout, (root / "stderr.txt").open("wb") as stderr:
        completed = subprocess.run(command, cwd=root, env=environment, stdout=stdout, stderr=stderr,
                                   check=False, timeout=12*60*60 if native is None else 3600)
    if completed.returncode != 0:
        tokens = sorted(set(_TYPED_MICE_ERROR.findall(
            (root / "stderr.txt").read_text() + (root / "stdout.txt").read_text())))
        label = "A04" if a04_variant or a04_negative else "A12"
        raise ContractError(tokens[0] if len(tokens) == 1 else f"F5_{label}_MICE_NATIVE_EXECUTION_FAILED")
    if admission is not None:
        # One synchronous R view was actually started and completed. M20's
        # original sequential chain iterator is not twenty pool workers.
        return {**value, "execution_report": {
            "configured_worker_ceiling": admission["limits"]["configured"],
            "admitted_worker_ceiling": admission["admitted_worker_ceiling"],
            "actual_worker_process_peak": 1, "runnable_task_count": 1,
            "completed_task_count": 1, "engine_threads": 1, "status": "COMPLETED"}}
    return value


def _pack_a12_total_mice_view(source: Path, root: Path, target: Path, *, a04_variant: bool = False,
                            a04_negative: bool = False, a12_validation: bool = False,
                            retained_primary_source_bundle: Path | None = None,
                            mice_restoration: Mapping[str, Any] | None = None) -> dict[str, Any]:
    if mice_restoration is not None:
        _validate_a12_mice_restoration_view(mice_restoration, source=source,
            retained_primary_source_bundle=retained_primary_source_bundle)
        _require(root == Path(mice_restoration["attempt_root"]) / "native-work"
                 and target == root / "native-view.zip", "F5_A12_MICE_RESTORATION_ATTEMPT_SCOPE_INVALID")
    value, _ = _load_a12_total_mice_input(source, a04_variant=a04_variant, a04_negative=a04_negative,
        **({"retained_primary_context": True} if mice_restoration is not None else {}),
        a12_validation=a12_validation, **({"retained_primary_source_bundle": retained_primary_source_bundle}
                                          if retained_primary_source_bundle is not None else {}))
    outputs = _a12_mice_output_members(a04_negative=a04_negative, a12_validation=a12_validation)
    count = 2 if a04_negative or a12_validation else 20
    _require({path.relative_to(root / "output").as_posix()
              for path in (root / "output").rglob("*") if path.is_file()} == outputs
             and {path.name for path in (root / "native").iterdir()}
             == {f"imp{index:02d}.rds" for index in range(1, count + 1)},
             "F5_A12_MICE_NATIVE_OUTPUT_SET_INVALID")
    summary = strict_json_bytes((root / "output/summary.json").read_bytes())
    view = value["view"]
    _require(summary.get("status") == "PASS" and summary.get("formal_m") == count
             and __import__("padml.f1_kernel", fromlist=["mice_terminal_valid"]).mice_terminal_valid(summary)
             and all(summary.get(name) == view[name] for name in ("view_id", "role", "outer_fold", "row_ids_sha256"))
             and summary.get("row_count") == len(view["row_ids"])
             and summary.get("analysis_row_count") == len(view["analysis_ids"])
             and summary.get("application_response_columns") == 0
             and summary.get("application_predictor_matrix_response_edges") == 0,
             "F5_A12_MICE_NATIVE_SUMMARY_INVALID")
    members = {name: root / "output" / name for name in outputs}
    members.update({f"native/imp{index:02d}.rds": root / "native" / f"imp{index:02d}.rds"
                    for index in range(1, count + 1)})
    members.update({name: root / name for name in
                    ("native-session.txt", "stdout.txt", "stderr.txt")})
    if not (a04_variant or a04_negative):
        members["covariates-total.csv"] = root / "covariates-total.csv"
    members["input.zip"] = source
    members["manifest.json"] = canonical_json_bytes({
        "kind": "PADML_F5_A04_VARIANT_MICE_NATIVE" if a04_variant else
                "PADML_F5_A04_NEGATIVE_MICE_NATIVE" if a04_negative else
                "PADML_F45_A12_M2_VALIDATION_NATIVE" if a12_validation else
                "PADML_NESTED_AAR_MICE_NATIVE_V1" if "nested_source" in value else "PADML_F5_A12_TOTAL_MICE_NATIVE",
        "input_sha256": sha256_file(source), "native_sources": _a12_mice_native_sources(
            a04_variant=a04_variant, a04_negative=a04_negative, a12_validation=a12_validation),
    })
    _require(all(not isinstance(path, Path) or (path.is_file() and not path.is_symlink())
                 for path in members.values()), "F5_A12_MICE_NATIVE_MEMBER_INVALID")
    write_deterministic_zip(target, members,
                            stored_members={name for name in members if name.endswith((".zip", ".rds"))})
    return {"sha256": sha256_file(target), "size_bytes": target.stat().st_size,
            "status": "COMPUTED", "stage_acceptance": False}


def _a12_mice_numerical_policy(source: Path, retained_bytes_limit: int, *,
                             execution_worker_memory_bytes: int | None = None) -> dict[str, Any]:
    """Bound the original one-view fit/audit/number lifetime before loading CSVs."""
    from .bundle import _validated_zip_infos
    from .runtime import validate_resource_policy

    _require(type(retained_bytes_limit) is int and retained_bytes_limit > 0
             and source.is_absolute() and source.is_file() and not source.is_symlink(),
             "F5_A12_MICE_RETENTION_ESTIMATE_REQUIRED")
    with open_carrier(source) as archive:
        _require(archive.getinfo("input.json").file_size <= 32 * 1024**2,
                 "F5_A12_MICE_INPUT_INDEX_TOO_LARGE")
        raw = archive.read("input.json")
        value = strict_json_bytes(raw)
        _require(isinstance(value, dict) and value.get("kind") == "PADML_NESTED_AAR_MICE_INPUT_V1"
                 and canonical_json_bytes(value) == raw, "F5_A12_MICE_NUMERICAL_SCOPE_INVALID")
        infos = _validated_zip_infos(archive, None, max_member_bytes=128 * 1024**2,
                                     max_total_bytes=3 * 1024**3, max_compression_ratio=1000)
        expanded = sum(info.file_size for info in infos)
    policy = validate_resource_policy(value["resource_policy"])
    _require(execution_worker_memory_bytes is None or type(execution_worker_memory_bytes) is int
             and execution_worker_memory_bytes in RECORDED_WORKER_MEMORY_BYTES, "F5_A12_MICE_WORKER_MEMORY_BUDGET_INVALID")
    # The original formula remains available only for historical accounting.
    # New admission uses the final user budget without a retained-byte charge.
    return {**policy, "memory_bytes_per_worker": (policy["memory_bytes_per_worker"]
            + 32 * (expanded + retained_bytes_limit)
            if execution_worker_memory_bytes is None else execution_worker_memory_bytes),
            "scratch_reserve_bytes": 0}


def _a12_mice_restoration_coordinate_root(unit: Mapping[str, Any]) -> Path:
    """The inventoried owner, independent of copied input or new executor paths."""
    prefix = ("resource-release-1e9b98e5f7f6-20260911" if unit["original_producer_source_identity"]
              == "1e9b98e5f7f640155bff611e94ba322b402114440eb2fbeef34d7f2c88e36268"
              else "tree-numeric-compat-1513ecba9638-20260911")
    return (Path("/root/autodl-tmp/PADML_V22/nested-loco-f1c67b6e7252-20260910") / prefix
            / "outer-3.aar.input.zip.mice" / unit["estimand"] / unit["view_id"])


def _a12_mice_restoration_partial_refs(unit: Mapping[str, Any]) -> dict[str, Any]:
    # Exact eleven partial RDS bytes observed in the immutable 00:28 inventory.
    rows = {
        "71309248e16a30312849d87366d8b6729ae0af6c5e6139827c044022688da1ab": [
            ("8502f097a44f1a6d9f9a0a611632a8457d9beaded9ccad28c2f9ea7245d133ee", 184676),
            ("e622495e97209149a42a6446ac4893ece4bec92a48c2e6af901791745c200874", 184648)],
        "9130582dcc6f228b645d54b2b87e0673c203b2d153c25c485bd563f4e51e6426": [
            ("07d5402fce02f5016aff8d018e0333e88b72fe3ab655843dc572777b50ce54af", 184543),
            ("9b68a4bad1533a112c1b34371a19f0ac6421907aff8b775025edeb9b46f1bff5", 184539),
            ("bd705816ce444246ef7efd15b8c9496714fc9a5906c388292d8e9a30de9e59a2", 184651)],
        "276907cc5e61dda2e197bbd80d08dc65bae52bab8ccc43ac8a5a9d3b79826bc1": [
            ("0cefa6859777e7aa5d5de3beafdf9047badec11fc4d5413deb7924fc4d840577", 184696),
            ("31cec5b525dd6ba1eef7cab63c7d15637a6ef17bda8c1bac99e1ae2ebd915995", 184666),
            ("e0cf48950fb32c37e72565f7bc7213e0f0f9dc1bb9b6668bf0ac5daf85f90b32", 184695),
            ("a78c3fe6f6f8b7f938a501dec0cfcf2d130331f6b799beb90de5e4e112c64432", 184737),
            ("561ff6116b6034ca7ba75a4ff3d215beea49b4b8ec9e90533ddbf78e3a725df9", 184678),
            ("f8abe3aa26eb8a2746af1358b03d0fc2fd76fb33e0d063d27817b0977ab4b054", 184618)],
    }
    _require(unit["original_spec"]["sha256"] in rows, "F5_A12_MICE_RESTORATION_RECORD_INVALID")
    return {f"input.zip.native-work/native/imp{index:02d}.rds": {"sha256": sha, "size_bytes": size}
            for index, (sha, size) in enumerate(rows[unit["original_spec"]["sha256"]], 1)}


def _a12_mice_restoration_original_files(unit: Mapping[str, Any]) -> dict[str, Any]:
    coordinate = _a12_mice_restoration_coordinate_root(unit)
    original = coordinate / "input.zip.native-work"
    _require(coordinate.is_dir() and coordinate.resolve(strict=True) == coordinate
             and original.is_dir() and not original.is_symlink() and (original / "native").is_dir()
             and not any((path.exists() or path.is_symlink()) for path in (
                 coordinate / "numerical.zip", coordinate / "numerical.zip.json",
                 original / "native-view.zip", original / "output/summary.json")),
             "F5_A12_MICE_RESTORATION_NOT_INCOMPLETE")
    paths = [coordinate / "input.zip", *sorted(original.rglob("*"))]
    _require(all(not path.is_symlink() and (path.is_file() or path.is_dir()) for path in paths)
             and {path.name for path in (original / "native").iterdir()}
                 == set(unit["preserve_original_partial_rds"]), "F5_A12_MICE_RESTORATION_ORIGINAL_DRIFT")
    paths = [path for path in paths if path.is_file()]
    _require(sum(path.stat().st_size for path in paths) <= 268435456,
             "F5_A12_MICE_RESTORATION_ORIGINAL_TOO_LARGE")
    refs = {str(path.relative_to(coordinate)): {"sha256": sha256_file(path), "size_bytes": path.stat().st_size}
            for path in paths}
    _require(refs.get("input.zip") == unit["original_input"]
             and refs.get("input.zip.native-work/spec.json") == unit["original_spec"],
             "F5_A12_MICE_RESTORATION_ORIGINAL_DRIFT")
    spec = strict_json_bytes((original / "spec.json").read_bytes())
    _require(spec.get("chain_seeds") == unit["chain_seeds"]
             and spec.get("view", {}).get("view_id") == unit["view_id"]
             and spec["view"].get("role") == "ANALYSIS" and spec["view"].get("outer_fold") == 3
             and spec.get("nested_aar_source", {}).get("estimand") == unit["estimand"],
             "F5_A12_MICE_RESTORATION_ORIGINAL_DRIFT")
    return refs


def _validate_a12_mice_restoration_record(record: Mapping[str, Any], *,
                                         retained_primary_source_bundle: Path) -> dict[str, Any]:
    """The paired number reader needs these pins, not access to the old owner."""
    from . import nested_loco as nested
    from .f4 import _retained_full0_source_members
    _retained_full0_source_members(retained_primary_source_bundle,
                                  aar_primary_context=True, aar_mice_restoration=True)
    _require(isinstance(record, Mapping) and set(record) == {
        "science_decision", "unit", "original_files", "attempt_root", "historical_interruption_cause"},
        "F5_A12_MICE_RESTORATION_RECORD_INVALID")
    decision = nested.validate_science_decision(record["science_decision"])
    authority = decision.get("aar3_mice_view_restoration")
    _require(isinstance(authority, Mapping)
             and any(canonical_json_bytes(record["unit"]) == canonical_json_bytes(unit) for unit in authority["atomic_units"])
             and record["historical_interruption_cause"] == "UNKNOWN", "F5_A12_MICE_RESTORATION_RECORD_INVALID")
    unit = record["unit"]
    coordinate = _a12_mice_restoration_coordinate_root(unit)
    refs = record["original_files"]
    _require(record["attempt_root"] == str(coordinate / "restoration-20260913-00-28")
             and isinstance(refs, Mapping) and refs.get("input.zip") == unit["original_input"]
             and refs.get("input.zip.native-work/spec.json") == unit["original_spec"],
             "F5_A12_MICE_RESTORATION_ORIGINAL_DRIFT")
    for name, ref in refs.items():
        _require(isinstance(name, str) and not Path(name).is_absolute() and ".." not in Path(name).parts
                 and (name == "input.zip" or name.startswith("input.zip.native-work/"))
                 and isinstance(ref, Mapping) and set(ref) == {"sha256", "size_bytes"}
                 and type(ref["size_bytes"]) is int and ref["size_bytes"] >= 0,
                 "F5_A12_MICE_RESTORATION_ORIGINAL_DRIFT")
        validate_sha256(ref["sha256"], "mice.restoration.original")
    _require(sum(ref["size_bytes"] for ref in refs.values()) <= 268435456
             and {name: ref for name, ref in refs.items() if name.endswith(".rds")}
                 == _a12_mice_restoration_partial_refs(unit), "F5_A12_MICE_RESTORATION_ORIGINAL_DRIFT")
    return unit


def _validate_a12_mice_restoration_view(record: Mapping[str, Any], *, source: Path,
                                       retained_primary_source_bundle: Path) -> dict[str, Any]:
    unit = _validate_a12_mice_restoration_record(record,
        retained_primary_source_bundle=retained_primary_source_bundle)
    _require(source == _a12_mice_restoration_coordinate_root(unit) / "input.zip"
             and record["original_files"] == _a12_mice_restoration_original_files(unit),
             "F5_A12_MICE_RESTORATION_ORIGINAL_DRIFT")
    return unit


def _a12_h0_native_first_replay_record() -> dict[str, Any]:
    """The single complete native view in the 2026-09-13 00:28 inventory; no FIT authority."""
    unit = {"original_producer_source_identity": "1e9b98e5f7f640155bff611e94ba322b402114440eb2fbeef34d7f2c88e36268",
            "estimand": "A12_WITHOUT_AST_ALT_TOTAL", "view_id": "OUTER_ANALYSIS"}
    return {**unit, "inventory": "2026-09-13 00:28", "outer_fold": 3,
        "original_input": {"sha256": "6bca0db0be0fe78830e366994b40e51d75dba475b69cebe417d16606124ac721", "size_bytes": 170596},
        "original_native": {"sha256": "ad6a33debf98daa6b826017b2f780cd7827d7530f9df14eed13e8cb30352620b", "size_bytes": 7632730},
        "original_spec": {"sha256": "8f33f68333f71aa6d1396f89f064753f2713c27c81d98f84939056ad0fb4e0a5", "size_bytes": 131272},
        "chain_seeds": list(range(150002481, 150002501)),
        "attempt_root": str(_a12_mice_restoration_coordinate_root(unit) / "first-replay-restoration-20260913"),
        "historical_fit_execution": {"status": "UNKNOWN", "reason": "ORIGINAL_FIT_EXECUTION_REPORT_NOT_RETAINED"},
        "new_model_fits": 0, "new_stop_fits": 0, "new_mice_chains": 0, "new_mice_fit_invocations": 0,
        "new_native_replay_invocations": 1, "new_selector_paths": 0, "new_glmnet_calls": 0}


def _validate_a12_h0_native_first_replay_report(report: Mapping[str, Any], numbers: Mapping[str, Any], source: Path | None,
                                                *, retained_historical_source_proven: bool = False) -> None:
    """The original gather and NativeV2 reader share this one-view provenance boundary."""
    from .f4 import _f45_source_member_sha256
    from .runtime import resource_admission, validate_resource_release
    record = _a12_h0_native_first_replay_record()
    expected_members = _a12_mice_output_members() | {
        "covariates-total.csv", "input.zip", "manifest.json", "native-session.txt", "stdout.txt", "stderr.txt",
        *(f"native/imp{index:02d}.rds" for index in range(1, 21))}
    _require(isinstance(numbers, Mapping) and isinstance(numbers.get("members"), Mapping)
             and set(numbers["members"]) == expected_members, "F5_A12_NATIVE_FIRST_REPLAY_MEMBER_SET_INVALID")
    for member, ref in numbers["members"].items():
        _require(isinstance(ref, Mapping) and set(ref) == {"sha256", "size_bytes"}
                 and type(ref["size_bytes"]) is int and ref["size_bytes"] >= (1 if member.endswith(".rds") else 0),
                 "F5_A12_NATIVE_FIRST_REPLAY_MEMBER_SET_INVALID")
        validate_sha256(ref["sha256"], "a12.native_first_replay_member")
    _require(canonical_json_bytes(report.get("native_first_replay")) == canonical_json_bytes(record)
             and (report.get("executor_source_identity") == sha256_bytes(canonical_json_bytes(_f45_source_member_sha256()))
                  or retained_historical_source_proven and report.get("executor_source_identity")
                     == "0f469526284d7c20008b183e1a22dff63acaed7050f67b78fc40de7ced920a41")
             and canonical_json_bytes(report.get("execution_report")) == canonical_json_bytes(record["historical_fit_execution"])
             and numbers.get("native_archive") == record["original_native"]
             and numbers.get("members", {}).get("input.zip") == record["original_input"]
             and numbers.get("spec", {}).get("chain_seeds") == record["chain_seeds"]
             and numbers["spec"].get("nested_aar_source", {}).get("estimand") == record["estimand"]
             and numbers["spec"].get("view", {}).get("view_id") == record["view_id"]
             and numbers["spec"]["view"].get("outer_fold") == record["outer_fold"]
             and numbers["spec"]["view"].get("role") == "ANALYSIS"
             and (source is None or source.stat().st_size == record["original_input"]["size_bytes"]
                  and sha256_file(source) == record["original_input"]["sha256"]),
             "F5_A12_NATIVE_FIRST_REPLAY_RECORD_INVALID")
    observation = report.get("resource_observation")
    # An inactive TOTAL branch keeps its immutable metadata without opening
    # its input. Full gather and every actual TOTAL consumer recheck policy.
    if source is not None:
        effective = _a12_mice_numerical_policy(source, report.get("retained_bytes_limit"))
        admission = resource_admission(effective, observation, legal_tasks=1)
        _require(canonical_json_bytes(report.get("resource_admission")) == canonical_json_bytes(admission),
                 "F5_A12_MICE_PRODUCER_GEOMETRY_INVALID")
    _require(canonical_json_bytes(report.get("first_audit_execution_report")) == canonical_json_bytes({
                 "configured_worker_ceiling": observation["effective_cpus"] - 8, "admitted_worker_ceiling": 1,
                 "actual_worker_process_peak": 1, "runnable_task_count": 1, "completed_task_count": 1,
                 "engine_threads": 1, "status": "COMPLETED"}), "F5_A12_MICE_PRODUCER_GEOMETRY_INVALID")
    release = report.get("resource_release")
    validate_resource_release(release)
    _require(release["owner"] == "AAR_MICE_VIEW:3:" + record["estimand"] + "/" + record["view_id"]
             and release.get("reader_scan_status") in {"OBSERVED", "WAIVED_BY_USER"} and release.get("files")
             and all(row["status"] in {"ADVISED", "UNSUPPORTED"} and row["error"] is None for row in release["files"])
             and all(type(release[key]["rss_bytes"]) is int for key in ("before", "after")),
             "F5_A12_NATIVE_FIRST_REPLAY_RELEASE_INCOMPLETE")
    attempt = Path(record["attempt_root"])
    first = attempt / "native-work/first-audit"
    bound = {str(first / name): row["size_bytes"] for name, row in numbers["members"].items()}
    bound.update({str(attempt.parent / name): record[key]["size_bytes"] for name, key in (
        ("input.zip", "original_input"), ("input.zip.native-work/native-view.zip", "original_native"),
        ("input.zip.native-work/spec.json", "original_spec"))})
    bound.update({str(first / "replay/output" / name): numbers["members"][name]["size_bytes"]
                  for name in _a12_mice_output_members()})
    bound[str(first / "replay/covariates-total.csv")] = numbers["members"]["covariates-total.csv"]["size_bytes"]
    # The native reader already compared every replay output byte. Its spec,
    # three inputs and logs have exact owned names but no invented old sizes.
    auxiliary = {str(first / "replay" / name) for name in (
        "spec.json", "native-session.txt", "stdout.txt", "stderr.txt",
        "inputs/input.json", "inputs/covariates.csv", "inputs/response.csv")}
    actual = {row["path"]: row["size_bytes"] for row in release["files"]}
    _require(set(actual) == set(bound) | auxiliary
             and all(actual[name] == size for name, size in bound.items()),
             "F5_A12_NATIVE_FIRST_REPLAY_RELEASE_FILES_INVALID")


def _retire_a12_member_copies(root, members, *, protected=()):
    """Retire exact already-consumed members, never a tree or a name pattern."""
    protected = {Path(path).resolve() for path in protected}
    parents = set()
    released = 0
    for path, pin in members.items():
        path = Path(path)
        _require(path.resolve().is_relative_to(root.resolve())
            and not any(p.is_symlink() for p in (path, *path.parents) if p == root or root in p.parents),
            'F5_A12_RETIREMENT_PATH_INVALID')
        if path.resolve() in protected or not path.exists():
            continue
        _require(path.is_file() and path.stat().st_size == pin['size_bytes']
            and sha256_file(path) == pin['sha256'], 'F5_A12_RETIREMENT_MEMBER_DRIFT')
        before = path.stat()
        path.unlink()
        if before.st_nlink == 1:
            released += before.st_blocks * 512
        parents.update(parent for parent in path.parents if parent != root and root in parent.parents)
    for parent in sorted(parents, key=lambda p: (-len(p.parts), str(p))):
        try:
            parent.rmdir()
        except OSError as error:
            import errno
            if error.errno not in {errno.ENOTEMPTY, errno.ENOENT}:
                raise
    return released


def _retire_a12_view_copies(source, report):
    if 'mice_restoration' in report or 'native_first_replay' in report:
        return 0
    root = source.with_name(source.name + '.native-work')
    numbers = report['numerical_view']
    native = root / 'native-view.zip'
    _require(native.is_file() and not native.is_symlink()
        and {'sha256': sha256_file(native), 'size_bytes': native.stat().st_size} == numbers['native_archive'],
        'F45_AAR_MICE_NATIVE_RETIREMENT_DRIFT')
    paths = {root / 'first-audit' / name: pin for name, pin in numbers['members'].items()}
    for name, pin in numbers['members'].items():
        if name.startswith('native/') or name == 'covariates-total.csv':
            paths[root / name] = pin
        if name in _a12_mice_output_members():
            paths[root / 'output' / name] = pin
            paths[root / 'first-audit/replay/output' / name] = pin
    return _retire_a12_member_copies(root, paths)


def execute_a12_total_mice_bundle(source: Path, target: Path, *, a04_variant: bool = False,
                                a04_negative: bool = False, a12_validation: bool = False,
                                numerical_output: bool = False,
                                retained_bytes_limit: int | None = None,
                                retained_primary_source_bundle: Path | None = None,
                                mice_restoration: Mapping[str, Any] | None = None,
                                native_first_replay: bool = False) -> dict[str, Any]:
    """Run one branch-local M20 view; no model fit, tuning or scheduling layer."""
    _require(type(numerical_output) is bool and (numerical_output or retained_bytes_limit is None)
             and (not numerical_output or not (a04_variant or a04_negative or a12_validation)),
             "F5_A12_MICE_NUMERICAL_SCOPE_INVALID")
    _require(retained_primary_source_bundle is None or numerical_output, "F5_RETAINED_AAR_SOURCE_SCOPE_INVALID")
    _require(mice_restoration is None or numerical_output and retained_primary_source_bundle is not None,
             "F5_A12_MICE_RESTORATION_RECORD_INVALID")
    _require(type(native_first_replay) is bool and (not native_first_replay or numerical_output
             and mice_restoration is None and retained_primary_source_bundle is not None),
             "F5_A12_NATIVE_FIRST_REPLAY_SCOPE_INVALID")
    replay_record = _a12_h0_native_first_replay_record() if native_first_replay else None
    if replay_record is not None:
        coordinate = Path(replay_record["attempt_root"]).parent
        _require(source == coordinate / "input.zip"
                 and target == Path(replay_record["attempt_root"]) / "numerical.zip"
                 and all(not (coordinate / name).exists() and not (coordinate / name).is_symlink()
                         for name in ("numerical.zip", "numerical.zip.json",
                                      "input.zip.native-work/first-audit/replay/output/summary.json")),
                 "F5_A12_NATIVE_FIRST_REPLAY_SCOPE_INVALID")
        for name, ref in (("input.zip", replay_record["original_input"]),
                          ("input.zip.native-work/native-view.zip", replay_record["original_native"]),
                          ("input.zip.native-work/spec.json", replay_record["original_spec"])):
            path = coordinate / name
            _require(path.is_file() and not path.is_symlink() and path.resolve(strict=True) == path
                     and path.stat().st_size == ref["size_bytes"] and sha256_file(path) == ref["sha256"],
                     "F5_A12_NATIVE_FIRST_REPLAY_ORIGINAL_DRIFT")
    if mice_restoration is not None:
        _validate_a12_mice_restoration_view(mice_restoration, source=source,
            retained_primary_source_bundle=retained_primary_source_bundle)
        _require(target == Path(mice_restoration["attempt_root"]) / "numerical.zip",
                 "F5_A12_MICE_RESTORATION_ATTEMPT_SCOPE_INVALID")
    producer = ({} if retained_primary_source_bundle is None else
                {"retained_primary_source_bundle": retained_primary_source_bundle})
    if mice_restoration is not None:
        producer["mice_restoration"] = mice_restoration
    if native_first_replay:
        producer["native_first_replay"] = True
    if numerical_output:
        from .f5 import _full_score_scratch, _retained_tree_bytes
        from .f4 import _f45_source_member_sha256
        from .runtime import observe_execution_resources, resource_admission, observe_step_memory, release_step_resources

        # The input, not a caller's report name, owns this one native attempt.
        # Main-task disjoint allocation remains responsible across hosts.
        root = (source.with_name(source.name + ".native-work") if mice_restoration is None
                else Path(mice_restoration["attempt_root"]) / "native-work")
        if replay_record is not None:
            root = Path(replay_record["attempt_root"]) / "native-work"
        report_path = target.with_name(target.name + ".json")
        from .nested_loco import _write_exact_once
        if target.is_file() and report_path.is_file():
            report = strict_json_bytes(report_path.read_bytes())
            _require(report["sha256"] == sha256_file(target) and report["size_bytes"] == target.stat().st_size
                and report["numerical_view"]["members"]["input.zip"] == {
                    "sha256": sha256_file(source), "size_bytes": source.stat().st_size},
                "F45_AAR_MICE_RESUME_DRIFT")
            if report['executor_source_identity'] != sha256_bytes(canonical_json_bytes(_f45_source_member_sha256())):
                from .f4 import _f45_same_run_source
                previous = _f45_same_run_source(report['executor_source_identity'])
                _require(all(previous.get('padml/kernels/' + name) == digest
                    for name, digest in _a12_mice_native_sources().items()), 'F45_AAR_MICE_RESUME_DRIFT')
            _retire_a12_view_copies(source, report)
            return report

        _require(target.is_absolute() and target.parent.is_dir() and target.suffix == ".zip"
                 and not target.is_symlink()
                 and not report_path.is_symlink()
                 and not root.is_symlink()
                 and source.parent.stat().st_dev == target.parent.stat().st_dev,
                 "F5_A12_MICE_COORDINATE_ALREADY_STARTED")
        policy = _a12_mice_numerical_policy(source, retained_bytes_limit,
            execution_worker_memory_bytes=MIN_WORKER_MEMORY_BYTES)
        observation = observe_execution_resources(source.parent)
        admission = resource_admission(policy, observation, legal_tasks=1)
        _load_a12_total_mice_input(source,
            **({"retained_primary_source_bundle": retained_primary_source_bundle}
               if retained_primary_source_bundle is not None else {}),
            **({"retained_primary_context": True} if mice_restoration is not None or native_first_replay else {}))
        root.mkdir(mode=0o700, exist_ok=True)
        native = (root / "native-view.zip" if replay_record is None
                  else source.parent / "input.zip.native-work/native-view.zip")
        retained_original_bytes = (0 if replay_record is None else
            replay_record["original_native"]["size_bytes"] + replay_record["original_spec"]["size_bytes"])
        try:
            with _full_score_scratch(root.parent):
                if replay_record is None:
                    if native.is_file():
                        executed = strict_json_bytes((root / "fit-execution.json").read_bytes())
                    else:
                        executed = _run_a12_total_mice_input(source, root, **producer)
                        _write_exact_once(root / "fit-execution.json", canonical_json_bytes(executed), "F45_AAR_MICE_EXECUTION_DRIFT")
                else:
                    # Only the original native REPLAY below may start. There
                    # is no FIT call, repack, partial-chain repair or fallback.
                    executed = {"execution_report": replay_record["historical_fit_execution"]}
                held = _retained_tree_bytes(root) + source.stat().st_size
                _require(3 * held + 4 * 1024**2 <= retained_bytes_limit,
                         "F5_A12_MICE_RETENTION_ESTIMATE_EXCEEDED")
                if replay_record is None and not native.is_file():
                    _pack_a12_total_mice_view(source, root, native, **producer)
                with open_carrier(native) as archive:
                    expanded = sum(info.file_size for info in archive.infolist())
                held = _retained_tree_bytes(root) + source.stat().st_size + retained_original_bytes
                _require(held + 2 * expanded + 32 * 1024**2 <= retained_bytes_limit,
                         "F5_A12_MICE_RETENTION_ESTIMATE_EXCEEDED")
                if (root / "first-audit").exists():
                    shutil.rmtree(root / "first-audit")
                first = materialize_a12_total_mice_view(source, native, root / "first-audit",
                                                       retain_evidence=True, collect_numbers=True, **producer)
                numbers = first["numerical_view"]
                members = {name: root / "first-audit" / name for name in numbers["members"]
                           if not name.startswith("native/")}
                pending = 2 * sum(path.stat().st_size for path in members.values()) + 4 * 1024**2
                held = _retained_tree_bytes(root) + source.stat().st_size + retained_original_bytes
                _require(held + pending + 32 * 1024**2 <= retained_bytes_limit,
                         "F5_A12_MICE_RETENTION_ESTIMATE_EXCEEDED")
                write_deterministic_zip(target, members, stored_members={"input.zip"})
                report = {"sha256": sha256_file(target), "size_bytes": target.stat().st_size,
                    "status": "COMPUTED", "stage_acceptance": False, "numerical_view": numbers,
                    "execution_report": executed["execution_report"],
                    "first_audit_execution_report": first["execution_report"],
                    "resource_admission": admission, "resource_observation": observation,
                    "execution_worker_memory_bytes": MIN_WORKER_MEMORY_BYTES,
                    "retained_bytes_limit": retained_bytes_limit,
                    "retained_bytes_before_report": _retained_tree_bytes(root) + source.stat().st_size
                                                   + target.stat().st_size + retained_original_bytes}
                if replay_record is not None:
                    _require(numbers["members"]["input.zip"] == replay_record["original_input"]
                             and numbers["native_archive"] == replay_record["original_native"]
                             and numbers["spec"]["chain_seeds"] == replay_record["chain_seeds"],
                             "F5_A12_NATIVE_FIRST_REPLAY_ORIGINAL_DRIFT")
                    report["native_first_replay"] = replay_record
                before = observe_step_memory()
                first_root = root / 'first-audit'
                owned_files = {first_root / name for name in numbers['members']}
                owned_files.update(root / name for name in numbers['members']
                    if name.startswith('native/') and (root / name).is_file())
                if replay_record is None:
                    owned_files.update((source, native, target))
                    # Original FIT and retained REPLAY have their own input
                    # and completed-output paths, beyond the extracted ZIP.
                    for completed_root in (root, first_root / 'replay'):
                        owned_files.update(path for name in _a12_mice_output_members()
                            if (path := completed_root / 'output' / name).is_file())
                        owned_files.update(path for name in (
                            'covariates-total.csv', 'spec.json', 'native-session.txt', 'stdout.txt', 'stderr.txt',
                            'inputs/input.json', 'inputs/covariates.csv', 'inputs/response.csv')
                            if (path := completed_root / name).is_file())
                del executed, first, members
                # FIT and first REPLAY both used synchronous subprocess.run;
                # their stdout/stderr and ZIP contexts are closed at this
                # complete M20 view boundary. Keep all files for later readers.
                if replay_record is not None:
                    original_spec = source.parent / "input.zip.native-work/spec.json"
                    _require(sha256_file(source) == replay_record["original_input"]["sha256"]
                             and sha256_file(native) == replay_record["original_native"]["sha256"]
                             and sha256_file(original_spec) == replay_record["original_spec"]["sha256"],
                             "F5_A12_NATIVE_FIRST_REPLAY_ORIGINAL_DRIFT")
                    owned_files.update((source, native, original_spec))
                    owned_files.update(first_root / 'replay/output' / name for name in _a12_mice_output_members())
                    owned_files.update(first_root / 'replay' / name for name in (
                        'covariates-total.csv', 'spec.json', 'native-session.txt', 'stdout.txt', 'stderr.txt',
                        'inputs/input.json', 'inputs/covariates.csv', 'inputs/response.csv'))
                owned_files = sorted(owned_files)
                report["executor_source_identity"] = sha256_bytes(canonical_json_bytes(_f45_source_member_sha256()))
                report["resource_release"] = release_step_resources(owned_files,
                    owner="AAR_MICE_VIEW:" + str(numbers["spec"]["nested_aar_source"]["primary_training_context"]["outer_fold"])
                        + ":" + numbers["spec"]["nested_aar_source"]["estimand"] + "/" + numbers["spec"]["view"]["view_id"],
                    before=before,
                    released_references=["executed_input", "first_audit_result_except_retained_numbers", "zip_member_paths"])
                if mice_restoration is not None:
                    _validate_a12_mice_restoration_view(mice_restoration, source=source,
                        retained_primary_source_bundle=retained_primary_source_bundle)
                    report["mice_restoration"] = mice_restoration
                raw = canonical_json_bytes(report)
                _require(len(raw) <= 32 * 1024**2
                         and report["retained_bytes_before_report"] + len(raw) <= retained_bytes_limit,
                         "F5_A12_MICE_RETENTION_ESTIMATE_EXCEEDED")
                _write_exact_once(report_path, raw, "F45_AAR_MICE_REPORT_DRIFT")
                _retire_a12_view_copies(source, report)
        except BaseException as exc:
            exc.add_note(f"F5_A12_MICE_NATIVE_EVIDENCE:{root}")
            raise
        return report
    _load_a12_total_mice_input(source, a04_variant=a04_variant, a04_negative=a04_negative,
                             a12_validation=a12_validation)
    _require(target.is_absolute() and target.parent.is_dir() and not target.exists(),
             "F5_A12_MICE_TARGET_INVALID")
    label = "a04-variant" if a04_variant else "a04-negative" if a04_negative else "a12"
    root = Path(tempfile.mkdtemp(prefix=f".{label}-mice-", dir=target.parent))
    try:
        executed = _run_a12_total_mice_input(source, root, a04_variant=a04_variant, a04_negative=a04_negative,
                                             a12_validation=a12_validation)
        report = _pack_a12_total_mice_view(source, root, target, a04_variant=a04_variant, a04_negative=a04_negative,
                                          a12_validation=a12_validation)
        if "execution_report" in executed:
            report["execution_report"] = executed["execution_report"]
    except BaseException as exc:
        exc.add_note(f"F5_{label.upper()}_MICE_NATIVE_EVIDENCE:{root}")
        raise
    shutil.rmtree(root)
    return report


def materialize_a12_total_mice_view(source: Path, payload: Path, destination: Path, *, a04_variant: bool = False,
                                  a04_negative: bool = False, a12_validation: bool = False,
                                  retain_evidence: bool = False, collect_numbers: bool = False,
                                  numerical_view: Mapping[str, Any] | None = None,
                                  retained_primary_source_bundle: Path | None = None,
                                  retained_mice_gather: bool = False,
                                  mice_restoration: Mapping[str, Any] | None = None,
                                  native_first_replay: bool = False) -> dict[str, Any]:
    """First audit opens mids; subsequent nested readers consume its full numbers."""
    _require(type(native_first_replay) is bool, "F5_A12_NATIVE_FIRST_REPLAY_SCOPE_INVALID")
    if native_first_replay:
        record = _a12_h0_native_first_replay_record()
        attempt = Path(record["attempt_root"])
        _require(mice_restoration is None and not any((a04_variant, a04_negative, a12_validation, retained_mice_gather))
                 and numerical_view is None and retain_evidence and collect_numbers
                 and retained_primary_source_bundle is not None and source == attempt.parent / "input.zip"
                 and destination == attempt / "native-work/first-audit"
                 and payload == attempt.parent / "input.zip.native-work/native-view.zip"
                 and sha256_file(source) == record["original_input"]["sha256"]
                 and payload.stat().st_size == record["original_native"]["size_bytes"]
                 and sha256_file(payload) == record["original_native"]["sha256"],
                 "F5_A12_NATIVE_FIRST_REPLAY_SCOPE_INVALID")
    _require(type(retained_mice_gather) is bool and (not retained_mice_gather
             or numerical_view is not None and not collect_numbers and retained_primary_source_bundle is not None),
             "F5_RETAINED_AAR_SOURCE_SCOPE_INVALID")
    _require(retained_primary_source_bundle is None or not any((a04_variant, a04_negative, a12_validation))
             and (numerical_view is not None and not collect_numbers
                  or numerical_view is None and retain_evidence and collect_numbers),
             "F5_RETAINED_AAR_SOURCE_SCOPE_INVALID")
    if mice_restoration is not None:
        _validate_a12_mice_restoration_view(mice_restoration, source=source,
            retained_primary_source_bundle=retained_primary_source_bundle)
        _require(not retained_mice_gather and numerical_view is None and retain_evidence and collect_numbers
                 and retained_primary_source_bundle is not None
                 and destination == Path(mice_restoration["attempt_root"]) / "native-work/first-audit"
                 and payload == destination.parent / "native-view.zip",
                 "F5_A12_MICE_RESTORATION_ATTEMPT_SCOPE_INVALID")
    value, input_entries = _load_a12_total_mice_input(source, a04_variant=a04_variant, a04_negative=a04_negative,
        a12_validation=a12_validation,
        **({"retained_primary_context": True} if mice_restoration is not None or native_first_replay else {}),
        **({"retained_mice_gather": True} if retained_mice_gather else {}),
        **({"retained_primary_source_bundle": retained_primary_source_bundle}
           if retained_primary_source_bundle is not None else {}))
    _require(type(collect_numbers) is bool and not (collect_numbers and numerical_view is not None)
             and (not collect_numbers and numerical_view is None or
                  "nested_source" in value and not (a04_variant or a04_negative or a12_validation)),
             "F5_A12_MICE_NUMERICAL_SCOPE_INVALID")
    outputs = _a12_mice_output_members(a04_negative=a04_negative, a12_validation=a12_validation)
    count = 2 if a04_negative or a12_validation else 20
    projected = set() if a04_variant or a04_negative else {"covariates-total.csv"}
    transport = outputs | projected | {"input.zip", "manifest.json", "native-session.txt", "stdout.txt", "stderr.txt"}
    expected = transport | {f"native/imp{index:02d}.rds" for index in range(1, count + 1)}
    native_reference = {"sha256": sha256_file(payload), "size_bytes": payload.stat().st_size}
    numbers = None
    if numerical_view is not None:
        from .bundle import validate_sha256
        _require(isinstance(numerical_view, Mapping) and set(numerical_view) == {
            "spec", "summary", "configuration", "members", "native_archive"}
            and isinstance(numerical_view["members"], Mapping) and set(numerical_view["members"]) == expected,
            "F5_A12_MICE_NUMBERS_REQUIRED")
        native_reference = numerical_view["native_archive"]
        _require(isinstance(native_reference, Mapping) and set(native_reference) == {"sha256", "size_bytes"}
                 and type(native_reference["size_bytes"]) is int and native_reference["size_bytes"] > 0,
                 "F5_A12_MICE_NATIVE_REFERENCE_INVALID")
        for record in [native_reference, *numerical_view["members"].values()]:
            _require(isinstance(record, Mapping) and set(record) == {"sha256", "size_bytes"}
                     and type(record["size_bytes"]) is int and record["size_bytes"] >= 0,
                     "F5_A12_MICE_NATIVE_REFERENCE_INVALID")
            validate_sha256(record["sha256"], "a12.mice.native")
        _require(all(numerical_view["members"][name]["size_bytes"] > 0 for name in expected if name.endswith(".rds")),
                 "F5_A12_MICE_NATIVE_REFERENCE_INVALID")
        expected = {name: numerical_view["members"][name] for name in transport}
        numbers = dict(numerical_view)
    _require(destination.is_absolute() and destination.parent.is_dir() and not destination.exists(),
             "F5_A12_MICE_MATERIALIZATION_TARGET_INVALID")
    # The numerical projection physically contains no RDS. The first native
    # reader's exact member records bind every remaining byte before use.
    records = extract_safe_zip(payload, destination, expected_members=expected,
                               max_member_bytes=128*1024*1024, max_total_bytes=3*1024**3)
    try:
        _require((destination / "input.zip").read_bytes() == source.read_bytes(), "F5_A12_MICE_SOURCE_MISMATCH")
        _require((destination / "manifest.json").read_bytes() == canonical_json_bytes({
            "kind": "PADML_F5_A04_VARIANT_MICE_NATIVE" if a04_variant else
                    "PADML_F5_A04_NEGATIVE_MICE_NATIVE" if a04_negative else
                    "PADML_F45_A12_M2_VALIDATION_NATIVE" if a12_validation else
                    "PADML_NESTED_AAR_MICE_NATIVE_V1" if "nested_source" in value else "PADML_F5_A12_TOTAL_MICE_NATIVE",
            "input_sha256": sha256_file(source), "native_sources": _a12_mice_native_sources(
                a04_variant=a04_variant, a04_negative=a04_negative, a12_validation=a12_validation),
        }), "F5_A12_MICE_NATIVE_SOURCE_INVALID")
        executed = {}
        if numerical_view is None:
            replay = destination / "replay"
            replay.mkdir(mode=0o700)
            executed = _run_a12_total_mice_input(source, replay, native=destination / "native", a04_variant=a04_variant,
                a04_negative=a04_negative, a12_validation=a12_validation,
                **({"mice_restoration": mice_restoration} if mice_restoration is not None else {}),
                **({"native_first_replay": True} if native_first_replay else {}),
                **({"retained_primary_source_bundle": retained_primary_source_bundle}
                   if retained_primary_source_bundle is not None else {}))
            for name in outputs | projected:
                path = replay / name if name == "covariates-total.csv" else replay / "output" / name
                _require(path.read_bytes() == (destination / name).read_bytes(), "F5_A12_MICE_NATIVE_REPLAY_MISMATCH")
            if collect_numbers:
                paths = {"authority_path", "variable_path", "covariates_path", "response_path", "output_dir"}
                original_spec = strict_json_bytes((replay / "spec.json").read_bytes())
                numbers = {"spec": {key: item for key, item in original_spec.items() if key not in paths},
                    "summary": strict_json_bytes((destination / "summary.json").read_bytes()),
                    "configuration": {Path(name).stem: strict_json_bytes((destination / name).read_bytes())
                        for name in outputs if name.startswith("configuration/")},
                    "members": {name: {key: record[key] for key in ("sha256", "size_bytes")}
                                for name, record in records.items()}, "native_archive": native_reference}
        if numbers is not None:
            from .f4_compact import _full_pipeline_mice_numbers
            _full_pipeline_mice_numbers({"view": {key: numbers[key] for key in ("spec", "summary", "configuration")}},
                {"covariates_csv": input_entries["covariates.csv"],
                 "mice_specs": {"view": _a12_total_mice_spec(value, destination)}})
            _require(strict_json_bytes((destination / "summary.json").read_bytes()) == numbers["summary"]
                     and all(strict_json_bytes((destination / "configuration" / (name + ".json")).read_bytes()) == item
                             for name, item in numbers["configuration"].items())
                     and list(csv.reader(io.StringIO((destination / "covariates-total.csv").read_text(encoding="utf-8-sig"))))
                         == list(csv.reader(io.StringIO(input_entries["covariates.csv"].decode("utf-8-sig")))),
                     "F5_A12_MICE_NUMBERS_VALUE_DRIFT")
            from .f4_compact import _full_pipeline_mice_completed_values
            _full_pipeline_mice_completed_values(input_entries["covariates.csv"], value["view"],
                                                 destination / "imputations")
        if numerical_view is None and not retain_evidence:
            shutil.rmtree(replay)
    except BaseException as exc:
        exc.add_note(f"F5_A12_MICE_MATERIALIZATION_EVIDENCE:{destination}")
        raise
    return {"view": value["view"], "chain_seeds": value["chain_seeds"],
            **({"execution_report": executed["execution_report"]} if "execution_report" in executed else {}),
            "binding_contract_sha256": value["binding_contract_sha256"],
            "input_dir": str(destination / "imputations"),
            "members": [{"name": f"imp{index:02d}.csv",
                         **{key: records[f"imputations/imp{index:02d}.csv"][key]
                            for key in ("sha256", "size_bytes")}}
                        for index in range(1, count + 1)],
            "native_archive_sha256": native_reference["sha256"],
            **({"numerical_view": numbers} if numbers is not None else {}), "stage_acceptance": False}


def compile_a12_total_recipe(
    family: str, selected: list[str], source: Path, payload: Path, destination: Path,
) -> tuple[dict[str, Any], dict[str, Any]]:
    """Prepare one native analysis M20 recipe; no selection, search or model fit."""
    from .f2_kernel import F2_FAMILIES
    from .f5 import _compile_partition_design_recipe

    _require(family in F2_FAMILIES and isinstance(selected, list) and selected
             and all(isinstance(parent, str) for parent in selected)
             and len(set(selected)) == len(selected)
             and not {"AST", "ALT", "AST_ALT"}.intersection(selected),
             "F5_A12_DESIGN_CHANNEL_NOT_REMOVED")
    value, _ = _load_a12_total_mice_input(source)
    _require(value["view"]["role"] == "ANALYSIS", "F5_A12_RECIPE_ANALYSIS_REQUIRED")
    native = materialize_a12_total_mice_view(source, payload, destination)
    view = native["view"]
    recipe = _compile_partition_design_recipe(family, selected, {
        "partition_id": f"A12_TOTAL_F{view['outer_fold']}_{view['view_id']}",
        "fit_ids": view["analysis_ids"],
        "covariates": {"input_dir": native["input_dir"],
                       "analysis_ids_sha256": sha256_bytes(canonical_json_bytes(view["analysis_ids"])),
                       "analysis_view_sha256": native["native_archive_sha256"]},
    }, destination, a12=True)
    return native, recipe


def _a12_context(f2_run_root: Path, lineage: Mapping[str, Any] | None, *,
                 f1_runtime_root: Path | None = None, primary_archive: Path | None = None,
                 primary_input_bundles: Mapping[int, Path] | None = None,
                 primary_compiled_input_records: Mapping[int, Mapping[str, Any]] | None = None,
                 replay_evidence: Path | None = None,
                 retained_primary_source_bundle: Path | None = None) -> dict[str, Any]:
    """Open the native primary OOC, or the legacy fixed-family source."""
    from .f4 import load_f4_inputs
    from .f5 import _validate_final_aggregate_lineage
    _require(retained_primary_source_bundle is None or primary_archive is not None,
             "F5_RETAINED_AAR_SOURCE_SCOPE_INVALID")
    if primary_archive is not None:
        from . import nested_loco as nested
        from .f4 import load_o_fit_aggregate_archive
        _require(lineage is None and primary_input_bundles is not None
                 and set(primary_input_bundles) == set(range(1, 7))
                 and isinstance(primary_compiled_input_records, Mapping)
                 and set(primary_compiled_input_records) == set(range(1, 7)), "F5_A12_PRIMARY_INPUTS_REQUIRED")
        snapshot = {}
        def consume_source(frozen, registry):
            _require(not snapshot, "F5_A12_PRIMARY_SOURCE_ALIAS")
            snapshot.update(frozen=frozen, registry=registry)
        verified = load_o_fit_aggregate_archive(primary_archive, input_bundles=primary_input_bundles,
            compiled_input_records=primary_compiled_input_records,
            f2_run_root=f2_run_root, f1_runtime_root=f1_runtime_root, replay_evidence=replay_evidence,
            _source_consumer=consume_source,
            **({"retained_primary_source_bundle": retained_primary_source_bundle}
               if retained_primary_source_bundle is not None else {}))
        _require(verified["kind"] == "PADML_F4_O_FIT_AGGREGATE_ARCHIVE_V4", "F5_A12_NESTED_PRIMARY_REQUIRED")
        _require(set(snapshot) == {"frozen", "registry"}, "F5_A12_PRIMARY_INPUTS_REQUIRED")
        frozen, registry = snapshot["frozen"], snapshot["registry"]
        primary = nested.validate_selected_ooc(verified["selected_ooc"], population_registry=registry)
        with open_carrier(primary_input_bundles[1]) as archive:
            _require(archive.getinfo("o-fit-input.json").file_size <= 32 * 1024**2, "F5_A12_PRIMARY_INDEX_TOO_LARGE")
            science = nested.validate_science_decision(strict_json_bytes(archive.read("o-fit-input.json"))["science_decision"])
        _require(science["identity_sha256"] == verified["science_decision_sha256"], "F5_A12_PRIMARY_DECISION_MISMATCH")
        fields, responses = _response_rows(frozen["response_csv"])
        evaluation_response = _write_response_subset(fields, responses, primary["patient_ids"], None)["private_bytes"]
        point = verified["evaluation"]
        metric = verified["native_metric_archive"]
        _require(metric["member"] == "evaluation/metrics.zip" and 0 < metric["size_bytes"] <= 64 * 1024**2
                 and point["selected_ooc_sha256"] == primary["identity_sha256"]
                 and point["heldout_response_sha256"] == sha256_bytes(evaluation_response),
                 "F5_A12_PRIMARY_POINT_SOURCE_INVALID")
        if replay_evidence is not None:
            native_path = replay_evidence / "archive/evaluation/metrics.zip"
            _require(native_path.is_file() and not native_path.is_symlink()
                     and native_path.stat().st_size == metric["size_bytes"], "F5_A12_PRIMARY_POINT_SOURCE_INVALID")
            primary_native = native_path.read_bytes()
        else:
            with open_carrier(primary_archive) as archive:
                _require(archive.getinfo(metric["member"]).file_size == metric["size_bytes"],
                         "F5_A12_PRIMARY_POINT_SOURCE_INVALID")
                primary_native = archive.read(metric["member"])
        _require(len(primary_native) == metric["size_bytes"] and sha256_bytes(primary_native) == metric["sha256"],
                 "F5_A12_PRIMARY_POINT_SOURCE_INVALID")
        return {"primary": primary, "frozen": frozen, "population_registry": registry, "science_decision": science,
            "primary_point": point, "primary_point_native": primary_native, "evaluation_response_csv": evaluation_response,
            "family_by_outer": {str(row["outer_fold"]): row["selected_family"] for row in primary["selection_by_outer"]},
            "source": {"kind": "PADML_F5_NESTED_AAR_PRIMARY_SOURCE_V1", "program_id": nested.PROGRAM_ID,
                "primary_aggregate_sha256": sha256_file(primary_archive), "primary_aggregate_identity_sha256": verified["identity_sha256"],
                "science_decision_sha256": science["identity_sha256"], "primary_ooc_sha256": primary["identity_sha256"],
                "primary_source_archives": verified["source_archives"],
                "primary_input_sha256": {str(outer): sha256_file(primary_input_bundles[outer]) for outer in range(1, 7)}}}
    _require(primary_input_bundles is None and primary_compiled_input_records is None and replay_evidence is None,
             "F5_A12_PRIMARY_INPUTS_REQUIRED")
    _validate_final_aggregate_lineage(lineage)
    inputs = load_f4_inputs(f2_run_root, include_o_fit_source=True, f1_runtime_root=f1_runtime_root)
    frozen = inputs["o_fit_source"]
    _require({row["fold"]: row for row in lineage["final_seta_selector_results"]}
             == {outer: frozen["models"][outer, "ELASTIC_NET_COX"] for outer in range(1, 7)},
             "F5_A12_ACCEPTED_SELECTOR_SOURCE_MISMATCH")
    ids = lineage["final_mice"]["fit_ids"]
    _require(sha256_bytes(frozen["response_csv"]) == lineage["final_mice"]["fit_response"]["sha256"]
             and ids == list(_response_rows(frozen["response_csv"])[1])
             and lineage["centers"] == [frozen["centers"][patient] for patient in ids],
             "F5_A12_FROZEN_POPULATION_MISMATCH")
    return {"family": lineage["final_family"], "frozen": frozen, "primary": inputs["handoff"],
            "source": {**inputs["source"], "final_lineage_sha256": sha256_bytes(canonical_json_bytes(lineage))}}


def _a12_outer_layout(context: Mapping[str, Any], outer: int, *, include_selector_inner: bool = False,
                      primary_lock: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """Select only original views used by this fixed family; generate no split or seed."""
    from .f2_kernel import predictor_contract, _expected_family_parent_column_map, _recipe_by_partition, _validate_transform_recipe_set
    family, frozen = context["family"], context["frozen"]
    _require(family in _A12_FIXED_FAMILIES | _A12_TUNED_FAMILIES
             and type(outer) is int and outer in range(1, 7)
             and type(include_selector_inner) is bool, "F5_A12_OUTER_INVALID")
    fresh = "primary_selector" in context
    if fresh:
        selector = context["primary_selector"]
        _require(primary_lock is not None, "RAW_AAR_PRIMARY_LOCK_REQUIRED")
    else:
        model = frozen["models"][outer, family]
        _require(model["family"] == family and model["fold"] == outer and model["status"] == "PASS",
                 "F5_A12_ACCEPTED_MODEL_REQUIRED")
        selector = model["selector_evidence"]
    minimum = 15
    if primary_lock is not None:
        from . import nested_loco as nested
        lock = nested.validate_development_lock(primary_lock)
        _require(lock["selection_horizon_months"] in ({6, 12, 24, 36} if fresh else {36}) and lock["outer_fold"] == outer
                 and lock["selected_family"] == family, "NESTED_AAR_PRIMARY_SELECTOR_SOURCE_MISMATCH")
        # The original PRIMARY reader has consumed the H36 selector and lock.
        # F2 still supplies the unchanged recipes, registered splits and M20.
        selector = {**selector, "selected_parents": lock["selected_parents"],
                    "common_set_design_df": lock["common_set_design_df"],
                    "outer_training_event_count": lock["training_event_count"]}
        minimum = lock["epv_resolution"]["minimum"]
    original_parents = selector["selected_parents"]
    selected = [parent for parent in original_parents if parent != "AST_ALT"]
    _require("AST_ALT" in original_parents and selected and len(set(original_parents)) == len(original_parents)
             and not {"AST", "ALT", "AST_ALT"}.intersection(selected), "F5_A12_FIXED_ABLATION_SET_INVALID")
    definitions = []
    for registry_name, kind in (("outer", "OUTER"), ("inner", "INNER"), ("stopping", "STOP")):
        if kind == "INNER" and family in _A12_FIXED_FAMILIES and not include_selector_inner:
            continue
        if kind == "STOP" and family not in {"GBM_COX", "XGBOOST_COX", "COXTIME_SET_A"}:
            continue
        rows = [row for row in frozen["registry"][registry_name] if row["outer_fold"] == outer]
        _require(len(rows) == (1 if kind == "OUTER" else 15), "F5_A12_PARTITION_DENOMINATOR_INVALID")
        if kind != "OUTER":
            rows.sort(key=lambda row: (row["repeat"], row["inner_fold"]))
            _require([(row["repeat"], row["inner_fold"]) for row in rows]
                     == [(r, k) for r in range(1, 4) for k in range(1, 6)], "F5_A12_PARTITION_DENOMINATOR_INVALID")
        for row in rows:
            name = kind if kind == "OUTER" else f"{kind}_R{row['repeat']}_K{row['inner_fold']}"
            evaluation_ids = row["stop_ids" if kind == "STOP" else "validation_ids"]
            _require(row["analysis_ids"] and evaluation_ids
                     and set(row["analysis_ids"]).isdisjoint(evaluation_ids)
                     and set(row["analysis_ids"] + evaluation_ids) == set(row["application_ids"]),
                     "F5_A12_PARTITION_MEMBERSHIP_INVALID")
            definitions.append({"kind": kind, "source": row, "analysis": name + "_ANALYSIS",
                                "application": name + "_APPLICATION", "evaluation_ids": evaluation_ids})
    predictors = predictor_contract(Path(__file__).parent)
    recipes = _validate_transform_recipe_set(selector["recipe_set"], predictors, expected_count=16)
    outer_recipe = _recipe_by_partition(recipes, definitions[0]["source"]["partition_id"])
    original_map = _expected_family_parent_column_map(original_parents, "ELASTIC_NET_COX", predictors, outer_recipe)
    common_map = _expected_family_parent_column_map(selected, "ELASTIC_NET_COX", predictors, outer_recipe)
    fields, response = _response_rows(frozen["response_csv"])
    events = _write_response_subset(fields, response, definitions[0]["source"]["analysis_ids"], None)["event_count"]
    common_df = sum(len(row["columns"]) for row in common_map)
    _require(selector["common_set_design_df"] == sum(len(row["columns"]) for row in original_map)
             and selector["outer_training_event_count"] == events
             and common_df > 0 and events >= minimum * common_df, "F5_A12_OUTER_SETA_EPV_INVALID")
    return {"outer_fold": outer, "family": family, "selected_parents": selected,
            "common_set_design_df": common_df, "outer_training_event_count": events,
            "definitions": definitions, "original_recipes": recipes,
            "view_names": [name for row in definitions for name in (row["analysis"], row["application"])]}


def compile_a12_outer_inputs(
    primary_input_bundle: Path, primary_outer_archive: Path, target: Path, *,
    f2_run_root: Path | None = None, outer_fold: int, resource_policy: Mapping[str, Any],
    f1_runtime_root: Path | None = None,
    compiled_input_record: Mapping[str, Any] | None = None, current_raw: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Local zero-fit transport for direct M20 and two distinct fresh-MICE branches.

    The original F4 reader establishes the primary lock. F1 data custody may
    read the frozen response here; no held-out response enters this ZIP.
    """
    from . import nested_loco as nested
    from .f2_kernel import _registered_partition_identity_record
    from .f4 import load_f4_inputs, _materialize_o_fit_fold

    _require(target.is_absolute() and target.parent.is_dir() and not target.exists() and not target.is_symlink(),
             "F5_A12_INPUT_PATH_INVALID")
    accepted_inputs = None
    materialized_fold = None
    source_admission = None

    def read_accepted_source(*, admit_io):
        nonlocal accepted_inputs, source_admission
        source_admission = admit_io
        if accepted_inputs is None:
            accepted_inputs = load_f4_inputs(f2_run_root, include_o_fit_source=True,
                f1_runtime_root=f1_runtime_root, admit_io=admit_io)
        return accepted_inputs

    def retain_materialized_fold(frozen, outer, registered):
        nonlocal materialized_fold
        _require(isinstance(accepted_inputs, Mapping) and frozen is accepted_inputs["o_fit_source"]
                 and outer == outer_fold and materialized_fold is None and isinstance(registered, Mapping),
                 "F4_O_FIT_SHARED_FOLD_SCOPE_INVALID")
        materialized_fold = registered

    work = Path(tempfile.mkdtemp(prefix="a12-projected-input-", dir=target.parent)).resolve()
    try:
        if current_raw is not None:
            from .integrated import ensure_raw_binding, primary_projection
            run, state = current_raw["run"], current_raw["state"]
            _require(f2_run_root is None and f1_runtime_root is None, "RAW_AAR_LEGACY_SOURCE_FORBIDDEN")
            with open_carrier(primary_input_bundle) as archive:
                request = strict_json_bytes(archive.read("o-fit-input.json"))
                raw = archive.read("source/primary-selector/development-input.json")
            h = request["selection_horizon_months"]
            primary_unit, = [u for u in run["units"] if u["kind"] == "PRIMARY"
                             and u["outer_fold"] == outer_fold and u["horizon"] == h]
            checked = load_f45_evaluation_source(primary_outer_archive.parent / "evaluation-input.zip", run, primary_unit)
            _require(request == checked["request"], "RAW_AAR_PRIMARY_REQUEST_DRIFT")
            lock = checked["metadata"]["development_lock"]
            development = strict_json_bytes(raw)
            _require(request["primary_selector_members"]["development-input.json"] ==
                {"sha256": sha256_bytes(raw), "size_bytes": len(raw)}
                and development["identity_sha256"] == request["selector_evidence_sha256"] == lock["selector_evidence_sha256"]
                and request["raw_context_sha256"] == state["projection"]["raw_context_sha256"]
                and request["training_context"] == state["projection"]["training_context"], "RAW_AAR_SELECTOR_DRIFT")
            primary_projection(state, development, h)
            primary_context = request["training_context"]
            source = {"program_id": nested.PROGRAM_ID, "estimand": nested.A12_TOTAL_AAR,
                "primary_training_context": primary_context, "primary_development_lock": lock,
                "science_decision": request["science_decision"]}
            frozen, materialized_fold = ensure_raw_binding(run), state["registered"]
            context = {"family": lock["selected_family"], "frozen": frozen,
                "primary_selector": {**development["selector"], "recipe_set": development["transform_recipes"],
                    "outer_recipe_sha256": development["outer_training_recipe_sha256"]}}
            primary_lock = lock
            accepted = {"model_input": {"model_partitions": [_registered_partition_identity_record(
                p, prediction_only=p["kind"] == "OUTER") for p in materialized_fold["partitions"]]}}
        else:
            source = _a12_native_primary_source(outer_fold, nested.A12_TOTAL_AAR, primary_input_bundle,
                primary_outer_archive, f2_run_root, f1_runtime_root, resource_policy,
                accepted_source_reader=read_accepted_source,
                **({"on_materialized_fold": retain_materialized_fold} if compiled_input_record is None else
                   {"compiled_input_record": compiled_input_record}),
                replay_evidence=work / "primary-replay")
            if compiled_input_record is not None:
                _require(isinstance(accepted_inputs, Mapping) and callable(source_admission),
                         "F4_O_FIT_ACCEPTED_INPUT_REQUIRED")
                materialized_fold = _materialize_o_fit_fold(accepted_inputs["o_fit_source"], outer_fold,
                    work / "primary-mice", admit_io=source_admission)
            primary_context, lock = source["primary_training_context"], source["primary_development_lock"]
            _require(isinstance(accepted_inputs, Mapping) and isinstance(materialized_fold, Mapping),
                     "F4_O_FIT_ACCEPTED_INPUT_REQUIRED")
            frozen = accepted_inputs["o_fit_source"]
            context = {"family": lock["selected_family"], "frozen": frozen}
            accepted = frozen["models"][outer_fold, lock["selected_family"]]
            primary_lock = lock if lock["selection_horizon_months"] == 36 else None
            if primary_lock is None:
                _require(accepted["selector_evidence_sha256"] == lock["selector_evidence_sha256"]
                         and accepted["selector_evidence"]["selected_parents"] == lock["selected_parents"]
                         and accepted["selector_evidence"]["common_set_design_df"] == lock["common_set_design_df"],
                         "NESTED_AAR_PRIMARY_SELECTOR_SOURCE_MISMATCH")
        fixed = _a12_outer_layout(context, outer_fold, primary_lock=primary_lock)
        redevelopment = _a12_outer_layout(context, outer_fold, include_selector_inner=True, primary_lock=primary_lock)
        fields, response_rows = _response_rows(frozen["response_csv"])
        response = _write_response_subset(fields, response_rows, primary_context["training_ids"], None)["private_bytes"]
        nested.validate_training_context(primary_context, response)
        # This owned work retains the one admitted real F1 fold until the AAR
        # output's original consumer succeeds; direct member bytes rebind below.
        direct = materialized_fold
        direct_by_id = {row["partition_id"]: row for row in direct["partitions"]}
        expected_by_id = {row["partition_id"]: row for row in accepted["model_input"]["model_partitions"]}
        members: dict[str, bytes | Path] = {"training-response.csv": response}
        direct_records, definitions, mice_inputs = {}, [], []
        for definition in redevelopment["definitions"]:
            row, kind = definition["source"], definition["kind"]
            definitions.append({"kind": kind, "partition_id": row["partition_id"],
                "repeat": row.get("repeat", 0), "inner_fold": row.get("inner_fold", 0),
                "fit_ids": row["analysis_ids"], "evaluation_ids": definition["evaluation_ids"],
                "application_ids": row["application_ids"], "analysis": definition["analysis"],
                "application": definition["application"],
                **({"consumer_set": list(row["consumers"])} if kind == "STOP" else {})})
        for definition in fixed["definitions"]:
            partition_id = definition["source"]["partition_id"]
            partition = direct_by_id[partition_id]
            _require(_registered_partition_identity_record(partition, prediction_only=(current_raw is not None and partition["kind"] == "OUTER")) == expected_by_id[partition_id],
                     "F5_A12_DIRECT_PARTITION_MISMATCH")
            covariates = partition["covariates"]
            direct_records[partition_id] = {"covariates": {key: value for key, value in covariates.items() if key != "input_dir"},
                "fit_covariate_members": partition["fit_covariate_members"]}
            for member in covariates["members"]:
                path = Path(covariates["input_dir"]) / member["name"]
                _require(path.is_file() and not path.is_symlink() and sha256_file(path) == member["sha256"]
                         and path.stat().st_size == member["size_bytes"], "F5_A12_DIRECT_PARTITION_MISMATCH")
                members[f"direct/{partition_id}/{member['name']}"] = path
        for estimand, layout in ((nested.A12_TOTAL_AAR, fixed), (nested.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT, redevelopment)):
            for name in layout["view_names"]:
                path = work / f"{estimand}-{name}.zip"
                write_deterministic_zip(path, _a12_total_mice_input_members(frozen["binding_contract"],
                    frozen["covariates_csv"], frozen["response_csv"], outer_fold, name,
                    nested_source={**source, "estimand": estimand}, resource_policy=resource_policy))
                _load_a12_total_mice_input(path)
                member = f"mice-inputs/{estimand}/{name}.zip"
                members[member] = path
                mice_inputs.append({"estimand": estimand, "view_id": name, "member": member})
        records = {name: {"sha256": sha256_bytes(raw) if isinstance(raw, bytes) else sha256_file(raw),
                          "size_bytes": len(raw) if isinstance(raw, bytes) else raw.stat().st_size}
                   for name, raw in sorted(members.items())}
        body = {"kind": "PADML_F5_A12_PROJECTED_OUTER_INPUTS_V1", "outer_fold": outer_fold, "family": context["family"],
            "primary_source": {key: value for key, value in source.items() if key != "estimand"},
            "primary_input_sha256": (checked["manifest"]["source_receipt"]["artifacts"]["input.zip"]["sha256"]
                if current_raw is not None else sha256_file(primary_input_bundle)),
            "primary_archive_sha256": (checked["manifest"]["source_receipt"]["artifacts"]["result.zip"]["sha256"]
                if current_raw is not None else sha256_file(primary_outer_archive)),
            "fixed_selected_parents": fixed["selected_parents"], "fixed_common_set_design_df": fixed["common_set_design_df"],
            "outer_training_event_count": fixed["outer_training_event_count"], "definitions": definitions,
            "direct_partitions": direct_records, "original_recipes": fixed["original_recipes"],
            "mice_inputs": mice_inputs, "resource_policy": dict(resource_policy), "members": records}
        value = {**body, "identity_sha256": sha256_bytes(canonical_json_bytes(body))}
        if current_raw is not None:
            from .carriers import write_carrier
            external = {name: path for name, path in members.items() if name.startswith('direct/')}
            write_carrier(target, {'a12-inputs.json': canonical_json_bytes(value),
                **{name: path for name, path in members.items() if name not in external}},
                references=external, run=current_raw['run'])
        else:
            write_deterministic_zip(target, {"a12-inputs.json": canonical_json_bytes(value), **members},
                                    stored_members={name for name in members if name.endswith(".zip")})
        _load_a12_projected_outer_inputs(target, work / "check")
    except BaseException as exc:
        exc.add_note(f"F5_A12_PROJECTED_INPUT_EVIDENCE:{work}")
        raise
    else:
        shutil.rmtree(work)
    return {"status": "COMPILED_NOT_EXECUTED", "stage_acceptance": False, "outer_fold": outer_fold,
        "family": context["family"], "planned_mice_chain_count": 20 * len(mice_inputs), "new_model_fits": 0,
        "new_mice_chains": 0, "sha256": sha256_file(target), "size_bytes": target.stat().st_size}


def _a12_total_view_inputs(context: Mapping[str, Any], layout: Mapping[str, Any], name: str) -> dict[str, bytes]:
    _require(name in layout["view_names"], "F5_A12_VIEW_SCOPE_INVALID")
    frozen = context["frozen"]
    return _a12_total_mice_input_members(frozen["binding_contract"], frozen["covariates_csv"],
                                       frozen["response_csv"], layout["outer_fold"], name)


def _a12_input_expansion_resources(source: Path, target: Path, policy: Mapping[str, Any], *,
                                   members: set[str], max_member_bytes: int, max_total_bytes: int,
                                   selected_members: set[str] | None = None,
                                   execution_scratch_reserve_bytes: int | None = None) -> dict:
    """Check byte-only input I/O before extraction, including zero-fit compilation.

    This is not a scientific-worker admission. Native MICE/model consumers
    separately require the unchanged execution-host C-8/RAM rule.
    """
    from .bundle import _validated_zip_infos
    from .runtime import validate_resource_policy
    policy = validate_resource_policy(policy)
    _require(execution_scratch_reserve_bytes is None
             or type(execution_scratch_reserve_bytes) is int and execution_scratch_reserve_bytes == 0,
             "F5_A12_INPUT_SCRATCH_BUDGET_INVALID")
    with open_carrier(source) as archive:
        infos = _validated_zip_infos(archive, members, max_member_bytes=max_member_bytes,
            max_total_bytes=max_total_bytes, max_compression_ratio=1000)
        _require(selected_members is None or isinstance(selected_members, set) and selected_members
                 and selected_members <= members, "F5_A12_PROJECTED_MEMBER_SET_INVALID")
        expanded = sum(info.file_size for info in infos
                       if selected_members is None or info.filename in selected_members)
    available = shutil.disk_usage(target.parent).free
    reserved = (expanded + policy["scratch_reserve_bytes"] + policy["scratch_bytes_per_worker"]
                if execution_scratch_reserve_bytes is None else expanded)
    _require(type(available) is int and available >= reserved, "F5_A12_INPUT_EXPANSION_SPACE_INSUFFICIENT")
    return {"expanded_bytes": expanded, "reserved_bytes": reserved, "scratch_available_bytes": available,
            "scratch_root": str(target.parent.resolve(strict=True)), "scientific_worker_count": 0,
            **({"execution_scratch_reserve_bytes": execution_scratch_reserve_bytes}
               if execution_scratch_reserve_bytes is not None else {})}


def _a12_projected_input_read_job(job):
    from .f2_kernel import _fit_covariate_member_records, _recipe_by_partition
    target = job["target"]
    if job["kind"] == "DIRECT":
        row, record, members = job["row"], job["record"], job["members"]
        fields, responses, context = job["fields"], job["responses"], job["context"]
        recipes, columns = job["recipes"], job["columns"]
        _require(set(record) == {"covariates", "fit_covariate_members"} and set(record["covariates"]) == {
            "schema_version", "kind", "status", "partition_id", "analysis_view_sha256", "application_view_sha256",
            "analysis_ids_sha256", "application_ids_sha256", "members", "data_identity"},
                 "F5_A12_DIRECT_PARTITION_MISMATCH")
        covariates = {**record["covariates"], "input_dir": str(target / "direct" / row["partition_id"])}
        _require(covariates["kind"] == "PADML_F2_REGISTERED_VIEW_BINDING" and covariates["status"] == "PASS"
                 and covariates["schema_version"] == "1.0.0" and covariates["partition_id"] == row["partition_id"]
                 and covariates["analysis_ids_sha256"] == sha256_bytes(canonical_json_bytes(row["fit_ids"]))
                 and covariates["application_ids_sha256"] == sha256_bytes(canonical_json_bytes(row["application_ids"]))
                 and covariates["data_identity"] == sha256_bytes(canonical_json_bytes(covariates["members"]))
                 and [member["name"] for member in covariates["members"]] == [f"imp{i:02d}.csv" for i in range(1, 21)]
                 and all({key: member[key] for key in ("sha256", "size_bytes")}
                         == members[f"direct/{row['partition_id']}/{member['name']}"] for member in covariates["members"])
                 and _fit_covariate_member_records(covariates, row["fit_ids"]) == record["fit_covariate_members"],
                 "F5_A12_DIRECT_PARTITION_MISMATCH")
        if row["kind"] != "STOP":
            recipe = _recipe_by_partition(recipes, row["partition_id"])
            _require(recipe["fit_ids_sha256"] == covariates["analysis_ids_sha256"]
                     and recipe["training_member_set_sha256"] == sha256_bytes(canonical_json_bytes(record["fit_covariate_members"]))
                     and recipe["analysis_view_sha256"] == covariates["analysis_view_sha256"],
                     "F5_A12_DIRECT_RECIPE_SOURCE_MISMATCH")
        for member in covariates["members"]:
            with (Path(covariates["input_dir"]) / member["name"]).open(newline="") as handle:
                reader = csv.DictReader(handle)
                frames = list(reader)
            _require(reader.fieldnames == columns and [item["Patient_ID"] for item in frames] == row["application_ids"]
                     and all(item["Center"] == context["centers_by_patient"][item["Patient_ID"]] for item in frames),
                     "F5_A12_DIRECT_PARTITION_MISMATCH")
        fit = target / "direct" / row["partition_id"] / "fit-response.csv"
        return {**row, "covariates": covariates, "fit_covariate_members": record["fit_covariate_members"],
            "fit_response": _write_response_subset(fields, responses, row["fit_ids"], fit),
            "evaluation_ids_sha256": sha256_bytes(canonical_json_bytes(row["evaluation_ids"])),
            **({"evaluation_response": _write_response_subset(fields, responses, row["evaluation_ids"], None)}
               if row["kind"] != "OUTER" else {})}
    record, definition, primary, policy = (job[name] for name in ("record", "definition", "primary", "policy"))
    retained_primary_context = job["retained_primary_context"]
    retained_mice_gather = job["retained_mice_gather"]
    retained_primary_source_bundle = job["retained_primary_source_bundle"]
    spec, _ = _load_a12_total_mice_input(target / record["member"],
        **({"retained_primary_context": True} if retained_primary_context else {}),
        **({"retained_mice_gather": True} if retained_mice_gather else {}),
        **({"retained_primary_source_bundle": retained_primary_source_bundle}
           if retained_primary_source_bundle is not None else {}))
    _require(spec["nested_source"] == {**primary, "estimand": record["estimand"]}
             and spec["resource_policy"] == policy
             and spec["view"]["analysis_ids"] == definition["fit_ids"]
             and spec["view"]["row_ids"] == (definition["fit_ids"] if spec["view"]["role"] == "ANALYSIS"
                                              else definition["application_ids"]),
             "F5_A12_PROJECTED_MICE_SOURCE_MISMATCH")
    return True


def _load_a12_projected_outer_inputs(source: Path, target: Path, *,
                                     branches: tuple[str, ...] | None = None,
                                     retained_primary_source_bundle: Path | None = None,
                                     retained_mice_gather: bool = False,
                                     retained_primary_context: bool = False,
                                     execution_scratch_reserve_bytes: int | None = 0) -> dict[str, Any]:
    """Open response-free inputs, with complete M20 dependencies per active branch."""
    from . import nested_loco as nested
    from .f2_kernel import (_fit_covariate_member_records, _expected_family_parent_column_map,
                            _recipe_by_partition, _validate_transform_recipe_set, predictor_contract)
    from .f4 import O_FIT_COMPONENT_BYTES
    from .runtime import release_f45_cumulative_files, validate_resource_policy

    _require(branches is None or isinstance(branches, tuple) and branches
             and branches == tuple(name for name in nested.AAR_ESTIMANDS if name in branches),
             "F5_A12_SEARCH_BRANCH_INVALID")
    _require(source.is_absolute() and source.is_file() and not source.is_symlink()
             and target.is_absolute() and target.parent.is_dir() and not target.exists(), "F5_A12_INPUT_PATH_INVALID")
    with open_carrier(source) as archive:
        info = archive.getinfo("a12-inputs.json")
        _require(info.file_size <= 32 * 1024**2, "F5_A12_INPUT_INDEX_TOO_LARGE")
        raw = archive.read(info)
    value = strict_json_bytes(raw)
    _require(isinstance(value, dict) and set(value) == {
        "kind", "outer_fold", "family", "primary_source", "primary_input_sha256", "primary_archive_sha256",
        "fixed_selected_parents", "fixed_common_set_design_df", "outer_training_event_count", "definitions",
        "direct_partitions", "original_recipes", "mice_inputs", "resource_policy", "members", "identity_sha256"}
        and value["kind"] == "PADML_F5_A12_PROJECTED_OUTER_INPUTS_V1" and canonical_json_bytes(value) == raw
        and value["identity_sha256"] == sha256_bytes(canonical_json_bytes({key: item for key, item in value.items()
                                                                       if key != "identity_sha256"})),
        "F5_A12_PROJECTED_INPUT_INVALID")
    primary = value["primary_source"]
    context = _a12_nested_mice_source({**primary, "estimand": nested.A12_TOTAL_AAR},
        **({"retained_primary_context": True} if retained_primary_context else {}),
        **({"retained_mice_gather": True} if retained_mice_gather else {}),
        **({"retained_primary_source_bundle": retained_primary_source_bundle}
           if retained_primary_source_bundle is not None else {}))
    lock, family = primary["primary_development_lock"], value["family"]
    _require(value["outer_fold"] == context["outer_fold"] and family == lock["selected_family"]
             and value["fixed_selected_parents"] == [name for name in lock["selected_parents"] if name != "AST_ALT"]
             and value["fixed_selected_parents"] and value["outer_training_event_count"] == context["training_event_count"],
             "F5_A12_PROJECTED_PRIMARY_BINDING_INVALID")
    for name in ("primary_input_sha256", "primary_archive_sha256"):
        validate_sha256(value[name], name)
    validate_resource_policy(value["resource_policy"])
    definitions = value["definitions"]
    stopping = family in {"GBM_COX", "XGBOOST_COX", "COXTIME_SET_A"}
    coordinates = [("OUTER", 0, 0), *[("INNER", r, k) for r in range(1, 4) for k in range(1, 6)],
                   *([("STOP", r, k) for r in range(1, 4) for k in range(1, 6)] if stopping else [])]
    _require(isinstance(definitions, list) and [(row["kind"], row["repeat"], row["inner_fold"]) for row in definitions] == coordinates
             and len({row["partition_id"] for row in definitions}) == len(definitions), "F5_A12_PARTITION_DENOMINATOR_INVALID")
    train, heldout = set(context["training_ids"]), set(context["heldout_ids"])
    for row in definitions:
        kind = row["kind"]
        _require(set(row) == {"kind", "partition_id", "repeat", "inner_fold", "fit_ids", "evaluation_ids",
                             "application_ids", "analysis", "application"} | ({"consumer_set"} if kind == "STOP" else set())
                 and all(isinstance(row[name], list) and row[name] and len(row[name]) == len(set(row[name]))
                         for name in ("fit_ids", "evaluation_ids", "application_ids"))
                 and set(row["fit_ids"]) <= train and set(row["fit_ids"]).isdisjoint(row["evaluation_ids"])
                 and set(row["fit_ids"]) | set(row["evaluation_ids"]) == set(row["application_ids"])
                 and set(row["application_ids"]) == (train | heldout if kind == "OUTER" else train if kind == "INNER"
                       else set(next(item["fit_ids"] for item in definitions if item["kind"] == "INNER"
                                     and item["repeat"] == row["repeat"] and item["inner_fold"] == row["inner_fold"])))
                 and (kind != "OUTER" or row["fit_ids"] == context["training_ids"] and row["evaluation_ids"] == context["heldout_ids"]),
                 "F5_A12_PROJECTED_PARTITION_SCOPE_INVALID")
        name = kind if kind == "OUTER" else f"{kind}_R{row['repeat']}_K{row['inner_fold']}"
        _require(isinstance(row["partition_id"], str) and row["partition_id"]
                 and Path(row["partition_id"]).name == row["partition_id"] and row["partition_id"] not in {".", ".."}
                 and row["analysis"] == name + "_ANALYSIS" and row["application"] == name + "_APPLICATION"
                 and (kind != "STOP" or row["consumer_set"] == ["GBM_COX", "XGBOOST_COX", "COXTIME_SET_A"]),
                 "F5_A12_VIEW_SCOPE_INVALID")
    for repeat in range(1, 4):
        validation = [patient for row in definitions if row["kind"] == "INNER" and row["repeat"] == repeat
                      for patient in row["evaluation_ids"]]
        _require(len(validation) == len(train) and set(validation) == train, "F5_A12_PARTITION_DENOMINATOR_INVALID")
    predictors = predictor_contract(Path(__file__).parent)
    recipes = _validate_transform_recipe_set(value["original_recipes"], predictors, expected_count=16)
    outer_recipe = _recipe_by_partition(recipes, definitions[0]["partition_id"])
    column_count = sum(len(row["columns"]) for row in _expected_family_parent_column_map(
        value["fixed_selected_parents"], "ELASTIC_NET_COX", predictors, outer_recipe))
    _require(type(value["fixed_common_set_design_df"]) is int and value["fixed_common_set_design_df"] == column_count > 0
             and context["training_event_count"] >= column_count * nested.validate_epv_resolution(lock["epv_resolution"])["minimum"]
             and lock["common_set_design_df"] == sum(len(row["columns"]) for row in _expected_family_parent_column_map(
                 lock["selected_parents"], "ELASTIC_NET_COX", predictors, outer_recipe)), "F5_A12_OUTER_SETA_EPV_INVALID")
    fixed = [row for row in definitions if row["kind"] != "INNER" or family not in _A12_FIXED_FAMILIES]
    expected_views = [{"estimand": branch, "view_id": row[role], "member": f"mice-inputs/{branch}/{row[role]}.zip"}
        for branch, selected in ((nested.A12_TOTAL_AAR, fixed), (nested.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT, definitions))
        for row in selected for role in ("analysis", "application")]
    direct_members = {f"direct/{row['partition_id']}/imp{i:02d}.csv" for row in fixed for i in range(1, 21)}
    _require(value["mice_inputs"] == expected_views
             and set(value["direct_partitions"]) == {row["partition_id"] for row in fixed}
             and set(value["members"]) == {"training-response.csv"} | direct_members | {row["member"] for row in expected_views},
             "F5_A12_PROJECTED_MEMBER_SET_INVALID")
    selected_members = None if branches is None else {
        "a12-inputs.json", "training-response.csv",
        *(direct_members if nested.A12_DIRECT_AAR in branches else set()),
        *(row["member"] for row in expected_views if row["estimand"] in branches)}
    expansion = _a12_input_expansion_resources(source, target, value["resource_policy"],
        members={"a12-inputs.json", *value["members"]}, max_member_bytes=O_FIT_COMPONENT_BYTES,
        max_total_bytes=(len(value["members"]) + 1) * O_FIT_COMPONENT_BYTES, selected_members=selected_members,
        execution_scratch_reserve_bytes=execution_scratch_reserve_bytes)
    extracted = extract_safe_zip(source, target, expected_members={"a12-inputs.json": {"sha256": sha256_bytes(raw), "size_bytes": len(raw)},
                                                     **value["members"]},
                     max_member_bytes=O_FIT_COMPONENT_BYTES, max_total_bytes=(len(value["members"]) + 1) * O_FIT_COMPONENT_BYTES,
                     selected_members=selected_members)
    release_f45_cumulative_files([source], owner="AAR_PROJECTED_INPUTS_EXTRACTED", report_root=target,
        released_references=["closed_a12_projected_input_extraction_streams"])
    response = (target / "training-response.csv").read_bytes()
    nested.validate_training_context(context, response)
    fields, responses = _response_rows(response)
    from .runtime import _readback_ordered
    columns = load_science_authority()["science"]["mice"]["private_handoff"]["columns"]
    direct_jobs = [{"kind": "DIRECT", "target": target, "row": row,
        "record": value["direct_partitions"][row["partition_id"]],
        "members": {name: pin for name, pin in value["members"].items()
                    if name.startswith(f"direct/{row['partition_id']}/")},
        "fields": fields, "responses": responses, "context": context, "recipes": recipes, "columns": columns}
        for row in fixed if branches is None or nested.A12_DIRECT_AAR in branches]
    jobs = direct_jobs + [{"kind": "VIEW", "target": target, "record": record,
        "definition": next(row for row in definitions if record["view_id"] in (row["analysis"], row["application"])),
        "primary": primary, "policy": value["resource_policy"],
        "retained_primary_context": retained_primary_context, "retained_mice_gather": retained_mice_gather,
        "retained_primary_source_bundle": retained_primary_source_bundle}
        for record in expected_views if branches is None or record["estimand"] in branches]
    results = _readback_ordered(_a12_projected_input_read_job, jobs,
        policy=value["resource_policy"], root=target,
        retained_bytes=32 * (len(raw) + len(response)),
        cache_files=(path for group in (
            (target / name for name in ({"a12-inputs.json", *value["members"]}
                if selected_members is None else selected_members)),
            (target / "direct" / job["row"]["partition_id"] / "fit-response.csv" for job in direct_jobs),
            (() if retained_primary_source_bundle is None else (retained_primary_source_bundle,)))
            for path in group if path.is_file()))
    direct = results[:len(direct_jobs)]
    return {"input": value, "root": target, "direct_partitions": direct, "expansion_resources": expansion,
        'owned_members': {target / name: pin for name, pin in extracted.items()},
        **({"retained_mice_gather": True} if retained_mice_gather else {}),
        **({"retained_primary_source_bundle": retained_primary_source_bundle}
           if retained_primary_source_bundle is not None else {})}


def _execute_a12_total_view_job(job: Mapping[str, Any]) -> dict[str, Any]:
    result = execute_a12_total_mice_bundle(Path(job["input"]), Path(job["target"]),
        **({"mice_restoration": job["mice_restoration"]} if "mice_restoration" in job else {}),
        **({"native_first_replay": True} if job.get("native_first_replay") is True else {}),
        **({"numerical_output": True, "retained_bytes_limit": job["retained_bytes_per_view"]}
           if "retained_bytes_per_view" in job else {}),
        **({"retained_primary_source_bundle": Path(job["retained_primary_source_bundle"])}
           if "retained_primary_source_bundle" in job else {}))
    if "retained_bytes_per_view" in job:
        # The original pool retains every returned value. Keep full per-view
        # numbers only in their already-published original report, not all in
        # the pool coordinator's memory or a second batch numerical index.
        path = Path(job["target"] + ".json")
        return {"name": job["name"], "result_path": str(path), "result_sha256": sha256_file(path),
                "result_size_bytes": path.stat().st_size, "status": result["status"], "stage_acceptance": False}
    return {"name": job["name"], **result}


def _a12_projected_partition_read_job(job):
    from .f2_kernel import _fit_covariate_member_records, _merge_registered_views
    opened, archives, reuse = job["opened"], job["archives"], job["reuse"]
    estimand, root, numerical_views = job["estimand"], job["root"], job["numerical_views"]
    fields, responses, context, columns = (job[name] for name in ("fields", "responses", "context", "columns"))
    retain_evidence = job["retain_evidence"]
    views, view_reports = {}, []
    for row in job["records"]:
        name = f"{estimand}/{row['view_id']}"
        original = opened["root"] / row["member"]
        if name in reuse:
            original = _a12_reused_mice_input(original, archives[estimand, row["view_id"]], reuse[name],
                                             root / (row["view_id"] + ".producer-input.zip"))
        native = materialize_a12_total_mice_view(original,
            archives[estimand, row["view_id"]], root / row["view_id"], retain_evidence=retain_evidence,
            collect_numbers=numerical_views is None,
            numerical_view=None if numerical_views is None else numerical_views[name],
            **({"retained_mice_gather": True} if opened.get("retained_mice_gather") else {}),
            **({"retained_primary_source_bundle": opened["retained_primary_source_bundle"]}
               if "retained_primary_source_bundle" in opened else {}))
        views[name] = native["numerical_view"]
        view_reports.append({"estimand": estimand, "view_id": row["view_id"],
                             **({"execution_report": native["execution_report"]} if numerical_views is None
                                else {"numerical_read": True})})
    row = job["definition"]
    destination = root / row["partition_id"]
    destination.mkdir(mode=0o700)
    prepared = {}
    covariates = _merge_registered_views(root / row["analysis"], root / row["application"],
        analysis_ids=row["fit_ids"], application_ids=row["application_ids"],
        destination=destination / "covariates", partition_id=row["partition_id"], prepared=prepared,
        expected_columns=columns, expected_centers=context['centers_by_patient'])
    partition = {**row, "covariates": covariates,
        "fit_covariate_members": prepared['fit_covariate_members'],
        "fit_response": _write_response_subset(fields, responses, row["fit_ids"], destination / "fit-response.csv"),
        "evaluation_ids_sha256": sha256_bytes(canonical_json_bytes(row["evaluation_ids"])),
        **({"evaluation_response": _write_response_subset(fields, responses, row["evaluation_ids"], None)}
           if row["kind"] != "OUTER" else {})}
    return estimand, partition, views, view_reports


def _materialize_a12_projected_branches(
    opened: Mapping[str, Any], archives: Mapping[tuple[str, str], Path], target: Path,
    *, retain_evidence: bool = False, numerical_views: Mapping[str, Any] | None = None,
    mice_reuse: Mapping[str, Any] | None = None,
    branches: tuple[str, ...] | None = None,
    execution_scratch_reserve_bytes: int | None = 0,
) -> dict[str, Any]:
    """Use original mids replay/merge for both fresh branches; no selector or model.

    The inherited direct inputs are already open. Redevelopment has no SetA
    yet: exposing the primary SetA as its own would silently skip reselection.
    """
    from . import nested_loco as nested
    from .bundle import _validated_zip_infos
    from .f2_kernel import _fit_covariate_member_records, _merge_registered_views, _registered_partition_identity_record
    from .runtime import observe_execution_resources, resource_admission

    value = opened["input"]
    _require(execution_scratch_reserve_bytes is None
             or type(execution_scratch_reserve_bytes) is int and execution_scratch_reserve_bytes == 0,
             "F5_A12_INPUT_SCRATCH_BUDGET_INVALID")
    active = nested.AAR_ESTIMANDS if branches is None else branches
    _require(isinstance(active, tuple) and active
             and active == tuple(name for name in nested.AAR_ESTIMANDS if name in active),
             "F5_A12_SEARCH_BRANCH_INVALID")
    _require(set(archives) == {(row["estimand"], row["view_id"]) for row in value["mice_inputs"]
                               if row["estimand"] in active}
             and target.is_absolute() and target.parent.is_dir() and not target.exists(), "F5_A12_INPUT_MATERIALIZATION_INVALID")
    _require(numerical_views is None or isinstance(numerical_views, Mapping)
             and set(numerical_views) == {f"{estimand}/{view}" for estimand, view in archives},
             "F5_A12_MICE_NUMERICAL_VIEW_COVERAGE_INVALID")
    reuse = {} if mice_reuse is None else mice_reuse
    _require(isinstance(reuse, Mapping) and set(reuse) <= {f"{estimand}/{view}" for estimand, view in archives}
             and (not reuse or numerical_views is not None and not opened.get("retained_primary_source_bundle")),
             "F45_AAR_MICE_REUSE_SCOPE_INVALID")
    # Every view remains available until the partition merge has completed.
    # Reserve the whole expansion, its replay copy and merged M20 matrices,
    # not just one active R worker's scratch. ZIP headers are bounded here;
    # the original native reader still verifies every byte and object below.
    expanded, merged, largest = 0, 0, 0
    for archive_path in archives.values():
        with open_carrier(archive_path) as archive:
            infos = _validated_zip_infos(archive, None, max_member_bytes=128 * 1024**2,
                                         max_total_bytes=3 * 1024**3, max_compression_ratio=1000)
            size = sum(info.file_size for info in infos)
            expanded += size
            largest = max(largest, size)
            merged += sum(info.file_size for info in infos if info.filename.startswith("imputations/"))
    reservation = {"kind": "OPERATIONAL_ESTIMATE_NOT_MEASURED_PEAK", "view_expanded_bytes": expanded,
                   "replay_reserved_bytes": (expanded if retain_evidence else largest) if numerical_views is None else 0,
                   "merged_matrix_reserved_bytes": merged, "coordinator_memory_estimate_bytes": 4 * largest,
                   "numerical_index_memory_reserved_bytes": 32 * 32 * 1024**2}
    policy = value["resource_policy"]
    observation = observe_execution_resources(target.parent)
    if execution_scratch_reserve_bytes is not None:
        # These are bytes this materialization actually writes, not an
        # additional reserve deducted from the scientific-worker pool.
        _require(observation["scratch_available_bytes"]
                 >= expanded + reservation["replay_reserved_bytes"] + merged,
                 "F5_A12_INPUT_EXPANSION_SPACE_INSUFFICIENT")
    admission = resource_admission({**policy, "memory_bytes_per_worker": MIN_WORKER_MEMORY_BYTES,
        "scratch_reserve_bytes": (policy["scratch_reserve_bytes"] + expanded + reservation["replay_reserved_bytes"] + merged
            if execution_scratch_reserve_bytes is None else execution_scratch_reserve_bytes),
        "memory_reserve_bytes": policy["memory_reserve_bytes"] + reservation["coordinator_memory_estimate_bytes"]
                                + reservation["numerical_index_memory_reserved_bytes"]},
        observation, legal_tasks=1)
    target.mkdir(mode=0o700)
    fields, responses = _response_rows((opened["root"] / "training-response.csv").read_bytes())
    context = value["primary_source"]["primary_training_context"]
    columns = [name for name in load_science_authority()["science"]["mice"]["private_handoff"]["columns"]
               if name not in {"AST", "ALT", "AST_ALT"}]
    branches = {estimand: {"partitions": [], "estimand_contract": nested.aar_estimand_contract(estimand)}
                for estimand in active}
    if nested.A12_DIRECT_AAR in active:
        branches[nested.A12_DIRECT_AAR]["partitions"] = opened["direct_partitions"]
    view_reports, views = [], {}
    jobs = []
    for estimand in (nested.A12_TOTAL_AAR, nested.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT):
        if estimand not in active:
            continue
        root = target / estimand
        root.mkdir(mode=0o700)
        records = [row for row in value["mice_inputs"] if row["estimand"] == estimand]
        names = {row["view_id"] for row in records}
        for definition in value["definitions"]:
            if definition["analysis"] not in names:
                continue
            pair = [row for row in records if row["view_id"] in (definition["analysis"], definition["application"])]
            keys = [f"{estimand}/{row['view_id']}" for row in pair]
            jobs.append({"estimand": estimand, "root": root, "records": pair, "definition": definition,
                "opened": {key: opened[key] for key in ("root", "retained_mice_gather", "retained_primary_source_bundle") if key in opened},
                "archives": {(estimand, row["view_id"]): archives[estimand, row["view_id"]] for row in pair},
                "reuse": {key: reuse[key] for key in keys if key in reuse},
                "numerical_views": None if numerical_views is None else {key: numerical_views[key] for key in keys},
                "fields": fields, "responses": responses, "context": context, "columns": columns,
                "retain_evidence": retain_evidence})
    readback = {}
    if numerical_views is None:
        results = [_a12_projected_partition_read_job(job) for job in jobs]
    else:
        from .runtime import _readback_ordered
        from .f5 import _mice_readback_memory
        def readback_cache_files():
            yield opened["root"] / "training-response.csv"
            for job in jobs:
                if "retained_primary_source_bundle" in job["opened"]:
                    yield job["opened"]["retained_primary_source_bundle"]
                for record in job["records"]:
                    key = (job["estimand"], record["view_id"])
                    name = "/".join(key)
                    yield job["archives"][key]
                    yield job["opened"]["root"] / record["member"]
                    if name in job["reuse"]:
                        yield job["root"] / (record["view_id"] + ".producer-input.zip")
                    for member in job["numerical_views"][name]["members"]:
                        if not member.startswith("native/"):
                            yield job["root"] / record["view_id"] / member
                partition_root = job["root"] / job["definition"]["partition_id"]
                yield partition_root / "fit-response.csv"
                for imp in range(1, 21):
                    yield partition_root / "covariates" / f"imp{imp:02d}.csv"
        results = _readback_ordered(_a12_projected_partition_read_job, jobs,
            policy=policy, root=target,
            per_worker_bytes=max((_mice_readback_memory(list(job["archives"].values())) for job in jobs), default=0),
            retained_bytes=reservation["coordinator_memory_estimate_bytes"]
                + reservation["numerical_index_memory_reserved_bytes"], execution_report=readback,
            cache_files=(path for path in readback_cache_files() if path.is_file()))
    for estimand, partition, restored_views, reports in results:
        branches[estimand]["partitions"].append(partition)
        views.update(restored_views)
        view_reports.extend(reports)
    for estimand, branch in branches.items():
        identities = [_registered_partition_identity_record(row, prediction_only=row["kind"] == "OUTER")
                      for row in branch["partitions"]]
        branch.update(kind="PADML_F5_A12_REGISTERED_INPUTS", status="MICE_MATERIALIZED_PRE_DEVELOPMENT",
            branch=estimand, fold=value["outer_fold"], outer_count=1,
            inner_count=sum(row["kind"] == "INNER" for row in branch["partitions"]),
            stop_count=sum(row["kind"] == "STOP" for row in branch["partitions"]),
            selected_parents=None if estimand == nested.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT else value["fixed_selected_parents"],
            identity=sha256_bytes(canonical_json_bytes(identities)))
    return {"source": value, "family": value["family"], "outer_fold": value["outer_fold"],
            "branches": branches, "root": target, "view_replay_reports": view_reports, "mice_views": views,
            "materialization_resources": {"reservation": reservation, "resource_admission": admission, "readback": readback},
            **({"retained_primary_source_bundle": opened["retained_primary_source_bundle"]}
               if "retained_primary_source_bundle" in opened else {})}


def _materialize_a12_outer_inputs(context: Mapping[str, Any], outer: int,
                                 archives: Mapping[str, Path], target: Path, *, retain_evidence: bool = False) -> dict[str, Any]:
    """Reopen every total mids, reuse direct F1, then expose original split-local inputs."""
    from .f2_kernel import (
        predictor_contract, _expected_family_parent_column_map, _fit_covariate_member_records,
        _merge_registered_views, _recipe_by_partition, _registered_partition_identity_record,
    )
    from .f4 import _materialize_o_fit_fold
    from .f5 import _compile_partition_design_recipe, _validate_final_design_recipe
    layout = _a12_outer_layout(context, outer)
    _require(set(archives) == set(layout["view_names"]) and target.is_absolute() and target.parent.is_dir()
             and not target.exists() and not target.is_symlink(), "F5_A12_INPUT_MATERIALIZATION_INVALID")
    target.mkdir(mode=0o700)
    frozen, family, selected = context["frozen"], context["family"], layout["selected_parents"]
    try:
        direct = _materialize_o_fit_fold(frozen, outer, target / "direct-f1")
        original = {row["partition_id"]: row for row in frozen["models"][outer, family]["model_input"]["model_partitions"]}
        direct_rows = {row["partition_id"]: row for row in direct["partitions"]}
        views = target / "total-views"
        views.mkdir(mode=0o700)
        for name in layout["view_names"]:
            input_path = views / f"{name}-input.zip"
            write_deterministic_zip(input_path, _a12_total_view_inputs(context, layout, name))
            # This loader compares original input bytes and opens all20 mids.
            materialize_a12_total_mice_view(input_path, archives[name], views / name, retain_evidence=retain_evidence)
        total_root = target / "total-partitions"
        total_root.mkdir(mode=0o700)
        fields, response = _response_rows(frozen["response_csv"])
        predictors = predictor_contract(Path(__file__).parent)
        transformed = family in {"COX_PH", "ELASTIC_NET_COX", "FPM_TVC_SET_A"}
        branches = {branch: {"partitions": [], "recipes": {}} for branch in A12_BRANCHES[1:]}
        for definition in layout["definitions"]:
            row, kind = definition["source"], definition["kind"]
            partition_id, fit_ids = row["partition_id"], row["analysis_ids"]
            evaluation_ids = definition["evaluation_ids"]
            native_direct = direct_rows[partition_id]
            _require(_registered_partition_identity_record(native_direct) == original[partition_id]
                     and native_direct["fit_ids"] == fit_ids and native_direct["evaluation_ids"] == evaluation_ids
                     and native_direct["application_ids"] == row["application_ids"]
                     and native_direct["repeat"] == row.get("repeat", 0)
                     and native_direct["inner_fold"] == row.get("inner_fold", 0), "F5_A12_DIRECT_PARTITION_MISMATCH")
            expected_response = _write_response_subset(fields, response, fit_ids, None)
            _require(Path(native_direct["fit_response"]["path"]).read_bytes() == expected_response["private_bytes"],
                     "F5_A12_DIRECT_RESPONSE_MISMATCH")
            root = total_root / partition_id
            root.mkdir(mode=0o700)
            covariates = _merge_registered_views(views / definition["analysis"], views / definition["application"],
                analysis_ids=fit_ids, application_ids=row["application_ids"], destination=root / "covariates",
                partition_id=partition_id)
            native_total = {"kind": kind, "partition_id": partition_id, "repeat": row.get("repeat", 0),
                "inner_fold": row.get("inner_fold", 0), "fit_ids": fit_ids, "evaluation_ids": evaluation_ids,
                "evaluation_ids_sha256": sha256_bytes(canonical_json_bytes(evaluation_ids)),
                "application_ids": row["application_ids"], "covariates": covariates,
                "fit_response": _write_response_subset(fields, response, fit_ids, root / "fit-response.csv"),
                "evaluation_response": _write_response_subset(fields, response, evaluation_ids, None),
                "fit_covariate_members": _fit_covariate_member_records(covariates, fit_ids),
                **({"consumer_set": list(row["consumers"])} if kind == "STOP" else {})}
            for member in covariates["members"]:
                path = Path(covariates["input_dir"]) / member["name"]
                reader = csv.DictReader(io.StringIO(path.read_text(encoding="utf-8-sig")))
                completed = list(reader)
                _require(reader.fieldnames == [name for name in load_science_authority()["science"]["mice"]["private_handoff"]["columns"]
                                                if name not in {"AST", "ALT", "AST_ALT"}]
                         and [item["Patient_ID"] for item in completed] == row["application_ids"]
                         and all(item["Center"] == frozen["centers"][item["Patient_ID"]] for item in completed),
                         "F5_A12_TOTAL_CHANNEL_OR_PATIENT_DRIFT")
            for branch, partition in zip(A12_BRANCHES[1:], (native_direct, native_total), strict=True):
                branches[branch]["partitions"].append(partition)
                if transformed and branch == A12_BRANCHES[1]:
                    transform = _recipe_by_partition(layout["original_recipes"], partition_id)
                    identity = _registered_partition_identity_record(partition)
                    _require(transform["training_member_set_sha256"] == identity["fit_covariate_member_set_sha256"]
                             and transform["fit_ids_sha256"] == identity["fit_ids_sha256"]
                             and transform["analysis_view_sha256"] == identity["analysis_view_sha256"],
                             "F5_A12_DIRECT_RECIPE_SOURCE_MISMATCH")
                    recipe = {"schema_version": "1.0.0", "kind": "PADML_F5_FINAL_DESIGN_RECIPE_V1",
                        "family": family, "selected_parents": selected, "preprocessing_mode": "F2_LOCKED_TRANSFORM_RECIPE",
                        "predictor_contract_sha256": sha256_bytes(canonical_json_bytes(predictors)),
                        "predictor_rows": [item for item in predictors["variables"] if item["name"] in selected],
                        "transform_recipe": transform, "coxtime_standardization": None}
                else:
                    recipe = _compile_partition_design_recipe(family, selected, partition, root, a12=True,
                        **({"native_evidence": root / "recipe-native"} if transformed else {}))
                _validate_final_design_recipe(recipe, family=family, selected_parents=selected)
                columns = _expected_family_parent_column_map(selected, family, predictors, recipe["transform_recipe"])
                _require(sum(len(item["columns"]) for item in columns) > 0, "F5_A12_EMPTY_DESIGN")
                branches[branch]["recipes"][partition_id] = recipe
        for branch, registered in branches.items():
            identities = [_registered_partition_identity_record(row) for row in registered["partitions"]]
            registered.update({"kind": "PADML_F5_A12_REGISTERED_INPUTS", "status": "PASS", "fold": outer,
                "branch": branch, "outer_count": 1, "inner_count": sum(row["kind"] == "INNER" for row in registered["partitions"]),
                "stop_count": sum(row["kind"] == "STOP" for row in registered["partitions"]), "diagnostic_count": 0,
                "diagnostic_partitions": [], "view_count": len(layout["view_names"]),
                "identity": sha256_bytes(canonical_json_bytes(identities))})
        return {"source": context["source"], **layout, "branches": branches, "root": target}
    except BaseException as exc:
        exc.add_note(f"F5_A12_INPUT_EVIDENCE_RETAINED:{target}")
        raise


def _a12_outer_input_record(prepared: Mapping[str, Any], *, branch: str | None = None) -> dict[str, Any]:
    from .f2_kernel import _registered_partition_identity_record
    if branch is not None:
        from .nested_loco import AAR_ESTIMANDS
        _require(prepared["source"].get("kind") == "PADML_F5_A12_PROJECTED_OUTER_INPUTS_V1"
                 and branch in AAR_ESTIMANDS, "F5_A12_SEARCH_BRANCH_INVALID")
        original = (prepared["source_input_record"] if "source_input_record" in prepared
                    else _a12_outer_input_record(prepared))
        _require(branch in original["branches"], "F5_A12_BRANCH_DEVELOPMENT_REQUIRED")
        return {**original, "branches": {branch: original["branches"][branch]}}
    if prepared["source"].get("kind") == "PADML_F5_A12_PROJECTED_OUTER_INPUTS_V1":
        return {"kind": "PADML_F5_A12_OUTER_INPUTS_NATIVE_V2", "family": prepared["family"],
            "outer_fold": prepared["outer_fold"], "projected_input_identity_sha256": prepared["source"]["identity_sha256"],
            "stage": "MICE_MATERIALIZED_PRE_DEVELOPMENT",
            "branches": {estimand: {**{key: branch[key] for key in (
                "identity", "status", "estimand_contract", "selected_parents", "outer_count", "inner_count", "stop_count")},
                "partitions": [_registered_partition_identity_record(row, prediction_only=row["kind"] == "OUTER")
                               for row in branch["partitions"]]} for estimand, branch in prepared["branches"].items()}}
    return {"kind": "PADML_F5_A12_OUTER_INPUTS_NATIVE_V1",
        **{name: prepared[name] for name in ("source", "family", "outer_fold", "selected_parents",
                                             "common_set_design_df", "outer_training_event_count", "view_names")},
        "branches": {branch: {"identity": value["identity"], "recipes": value["recipes"],
                               "partitions": [_registered_partition_identity_record(row) for row in value["partitions"]]}
                     for branch, value in prepared["branches"].items()}}


def _a12_recipe_archive_members(layout: Mapping[str, Any]) -> set[str]:
    if layout["family"] not in {"COX_PH", "ELASTIC_NET_COX", "FPM_TVC_SET_A"}:
        return set()
    return {f"recipes/{row['source']['partition_id']}/{name}" for row in layout["definitions"]
            for name in ("spec.json", "recipe.json", "stdout.log", "stderr.log")}


def _a12_retained_complete_view_report_pins() -> dict[str, dict[str, Any]]:
    """The 14 complete H6 reports inventoried on 2026-09-13 00:28; no FIT authority.

    Each immutable report binds its input, full native M20, first audit and
    numerical bytes. The ordinary scientific readers still check all of them.
    These pins cannot manufacture the missing historical batch/CLI record.
    """
    total = "A12_WITHOUT_AST_ALT_TOTAL/"
    no_aar = "OUTER_SELECTED_FAMILY_NO_AAR_REDEVELOPMENT/"
    rows = (
        (total + "INNER_R1_K2_ANALYSIS", "5dfd58f2b21f7212ceab91bf67a5b042ad1dfb2586b3ea3b4a5737afc4d19444", 144478),
        (total + "INNER_R1_K5_ANALYSIS", "3244e6ff0cf9a97aec715afdefa7b417eaaf17e57d452a07429daaaac5d256fb", 144768),
        (total + "INNER_R2_K3_ANALYSIS", "2a91bcb5ec1f0d384ab720401c597eb2af4b909b01f443c5dba5dae315b1e437", 144557),
        (total + "INNER_R3_K1_ANALYSIS", "e56293603d6f007941f2c2f354125e893f3792dd5926b37cad2a8e9ca169a3b2", 144514),
        (total + "INNER_R3_K4_ANALYSIS", "f7f258f8f6cef5eb2bf5a688623712940fca3514c220c5de14ab761554bbb49d", 144666),
        (total + "STOP_R1_K2_ANALYSIS", "c6bd4c71559b7703d7005f51932efbbe0ba5435099e362793757b05f9975343a", 140141),
        (total + "STOP_R1_K5_ANALYSIS", "9169eed55a4af480470a5dabd9fbb751acf1f4b04fb0e3a1552bda72788e0b3a", 140363),
        (total + "STOP_R2_K3_ANALYSIS", "6a4af180c9a1fdd4dc497f2d2c50023cbf5d21d882119e22234e6d9399fb2d41", 140211),
        (total + "STOP_R3_K1_ANALYSIS", "2af78c4be4cac6b97ce038fd03508293b1eb65e85c6ab26f32bbb81934aeadde", 140165),
        (total + "STOP_R3_K4_ANALYSIS", "f40084fb7e65dc63172d4600caee50e29f150b0a610e9ae11e74a650c8d3199b", 140295),
        (no_aar + "INNER_R1_K1_ANALYSIS", "b30ad32707f6bffd6841979ec2f49e0ad16b17b07911acd6acc6cfe19edc4cc1", 144541),
        (no_aar + "INNER_R1_K4_ANALYSIS", "6720f08e113a80a7f16086811808142b82cab6a560ced9b2c4029ccc40193410", 144657),
        (no_aar + "INNER_R2_K2_ANALYSIS", "7fc3a5a8a0f3dec616f02342803e142febc0aa3a45ca273d76e97cefc5e21767", 144566),
        (no_aar + "INNER_R2_K5_ANALYSIS", "83d43f519c791161ab58c9a1335853f4f7e5e8d395854d55e519d4cd53d5d652", 144780),
    )
    return {name: {"sha256": digest, "size_bytes": size} for name, digest, size in rows}


def _retained_a12_view_report_pins(batches, *, source: Path, value: Mapping[str, Any], root: Path,
                                  retained_view_source_bundle: Path | list[Path] | None = None,
                                  retained_primary_source_bundle: Path | None = None) -> dict[str, Any]:
    """Read original returned shard handles through independent OSS byte pins."""
    from .bundle import inspect_safe_zip_manifest
    from .runtime import observe_execution_resources, resource_admission
    from .f4 import _f45_source_member_sha256
    _require(isinstance(batches, list) and 0 < len(batches) <= len(value["mice_inputs"]),
             "F5_A12_RETAINED_VIEW_RECORD_INVALID")
    expected = {row["estimand"] + "/" + row["view_id"] for row in value["mice_inputs"]}
    legacy_identity = "1513ecba963857099c6b99413b8e976393c551a3ec30ed90da1cb14178338bd7"
    identities = {legacy_identity}
    current = _f45_source_member_sha256()
    current_identity = sha256_bytes(canonical_json_bytes(current))
    restoration_identity = "a1fabe4424b844025db0449126d60dd81dded09a88cd15e2cd7e78b0c154fa9b"
    h0_identity = "0f469526284d7c20008b183e1a22dff63acaed7050f67b78fc40de7ced920a41"
    delivery_identity = "58a0c27a611f6126809e2c26f8d6ed786590da80f8a20acb7c1a7d52228bc83b"
    historical_sources = {
        "1e9b98e5f7f640155bff611e94ba322b402114440eb2fbeef34d7f2c88e36268":
            ("e3cb8bf4c5a11032fdc4ff410dc7e490c9ac9677038152ea5353f979a997a9d5", 881560,
             "14a32821e116e911c9d9cfb3678e2f2191daf589d642547e9268f166cbdae908"),
        restoration_identity:
            ("74effa70e56307e38d5b632acbf49311b8f1bfec3d19753f728ac60e7c9e6f01", 923320,
             "4b01ec16df691c155cbd04d1b7a9a27832cd41e0a564276a996fbceba748a644"),
        h0_identity: ("cb13f910856b951159ca26e85de072a4201f6d823a20bed513af218ad1fe56db", 960061,
                      "93f25df7a8a5d1dab9c34d2035969b020250ea0b1cb18b06db0c49c807ea91d2"),
        delivery_identity: ("8621e6e805203d4d0575232eaec3a9afdc27db94ca34b5122eecab796bb08b60", 933377,
                            "6fa2424376844ae030d19beb7c5fb06c067d541783c58a9fe2fda255b57e115f"),
    }
    bundles = ([] if retained_view_source_bundle is None else [retained_view_source_bundle]
               if isinstance(retained_view_source_bundle, Path) else retained_view_source_bundle)
    # The four-archive arm is confined to one reviewed extension of e55c.
    # Both edited members are proved below; the other 47 retain the frozen map.
    def reviewed_joint_extension() -> bool:
        baseline = {**current,
            "padml/f4.py": "91fce97171a68e8a48ff5b5d47cd75991aa9e860958fce917310380a3048383c",
            "padml/f5_sensitivity.py": "7344406913f9b948628ff93a6582c4ffb8c41e967daf5df4a8cfd08165b92792"}
        if sha256_bytes(canonical_json_bytes(baseline)) != (
                "235fdeb65bd801161fb22487e12929fbcd2a66799203ad97c35b5690e2106205"):
            return False
        source_root = Path(__file__).resolve(strict=True).parent.parent
        f4_raw = (source_root / "padml/f4.py").read_bytes()
        sensitivity_raw = (source_root / "padml/f5_sensitivity.py").read_bytes()
        if (sha256_bytes(f4_raw) != current["padml/f4.py"]
                or sha256_bytes(sensitivity_raw) != current["padml/f5_sensitivity.py"]):
            return False
        sensitivity_proof = "f93192ad609cceb249565f79b2d4cf01e4c2e5b27ee3ea9a5a39966249eeae4b"
        own = sensitivity_proof.encode("ascii")
        if (sensitivity_raw.count(own) != 1
                or sha256_bytes(sensitivity_raw.replace(own, b"CURRENT_A12_SENSITIVITY_PROOF"))
                    != sensitivity_proof):
            return False
        import ast
        sensitivity_lines = sensitivity_raw.splitlines(keepends=True)
        view_definitions = [node for node in ast.parse(sensitivity_raw).body
                            if isinstance(node, ast.FunctionDef)
                            and node.name == "_retained_a12_view_report_pins"]
        if len(view_definitions) != 1:
            return False
        view_node = view_definitions[0]
        view_sha = sha256_bytes(b"".join(sensitivity_lines[
            min([view_node.lineno, *(item.lineno for item in view_node.decorator_list)]) - 1:
            view_node.end_lineno])).encode("ascii")
        f4_text = f4_raw.decode("utf-8")
        tree = ast.parse(f4_text)
        lines = f4_raw.splitlines(keepends=True)
        definitions = [node for node in tree.body if isinstance(node, ast.FunctionDef)]
        if len({node.name for node in definitions}) != len(definitions):
            return False
        nodes = {node.name: node for node in definitions}
        functions = {node.name: b"".join(lines[
            min([node.lineno, *(item.lineno for item in node.decorator_list)]) - 1:node.end_lineno])
            for node in definitions}
        if not {"_retained_full0_source_members", "_retained_gbm_q_source_members"} <= set(functions):
            return False
        full0 = functions["_retained_full0_source_members"]
        gbm = functions["_retained_gbm_q_source_members"]
        full0_sha = sha256_bytes(full0).encode("ascii")
        if gbm.count(full0_sha) != 2:
            return False
        gbm_zero_sha = sha256_bytes(gbm.replace(full0_sha, b"0" * 64)).encode("ascii")
        gbm_reciprocal_sha = sha256_bytes(gbm.replace(
            full0_sha, b"CURRENT_PRIMARY_SOURCE_PROOF")).encode("ascii")
        sensitivity_sha = current["padml/f5_sensitivity.py"].encode("ascii")
        def mapped_pin_count(symbol: str, key: str, digest: bytes) -> int:
            return sum(
                isinstance(key_node, ast.Constant) and key_node.value == key
                and isinstance(value_node, ast.Constant) and value_node.value == digest.decode("ascii")
                for mapping in ast.walk(nodes[symbol]) if isinstance(mapping, ast.Dict)
                for key_node, value_node in zip(mapping.keys, mapping.values, strict=True))
        def pair_pin_count(symbol: str, key: str, digest: bytes) -> int:
            return sum(
                isinstance(key_node, ast.Constant) and key_node.value == key
                and isinstance(value_node, ast.Tuple) and len(value_node.elts) in {2, 3}
                and isinstance(value_node.elts[-1], ast.Constant)
                and value_node.elts[-1].value == digest.decode("ascii")
                for mapping in ast.walk(nodes[symbol]) if isinstance(mapping, ast.Dict)
                for key_node, value_node in zip(mapping.keys, mapping.values, strict=True))
        zero_assignments = [assignment for assignment in ast.walk(nodes["_retained_full0_source_members"])
            if isinstance(assignment, ast.Assign)
            and any(isinstance(target, ast.Name) and target.id == "gbm_proof_sha256"
                    for target in assignment.targets)]
        full0_node = nodes["_retained_full0_source_members"]
        parents = {id(child): parent for parent in ast.walk(full0_node)
                   for child in ast.iter_child_nodes(parent)}
        reciprocal_contexts = sorted(type(parents[id(node)]).__name__ for node in ast.walk(full0_node)
            if isinstance(node, ast.Constant) and node.value == gbm_reciprocal_sha.decode("ascii"))
        if (mapped_pin_count("_retained_gbm_q_source_members", "_retained_full0_source_members", full0_sha) != 2
                or mapped_pin_count("_retained_gbm_q_source_members", "padml/f5_sensitivity.py", sensitivity_sha) != 1
                or mapped_pin_count("_retained_gbm_q_source_members", "_retained_a12_view_report_pins", view_sha) != 1
                or mapped_pin_count("_retained_full0_source_members", "padml/f5_sensitivity.py", sensitivity_sha) != 1
                or pair_pin_count("_retained_full0_source_members", "_retained_a12_view_report_pins", view_sha) != 3
                or len(zero_assignments) != 1
                or not isinstance(zero_assignments[0].value, ast.Constant)
                or zero_assignments[0].value.value != gbm_zero_sha.decode("ascii")
                or reciprocal_contexts != ["Compare", "Compare", "IfExp", "IfExp", "Tuple"]):
            return False
        if (f4_raw.count(sensitivity_sha) != 3 or f4_raw.count(gbm_zero_sha) != 1
                or f4_raw.count(gbm_reciprocal_sha) != 5 or f4_raw.count(full0_sha) != 2
                or f4_raw.count(view_sha) != 4):
            return False
        constants = [node for node in ast.walk(tree) if isinstance(node, ast.Constant)]
        for digest, count in ((sensitivity_sha, 3), (gbm_zero_sha, 1),
                              (gbm_reciprocal_sha, 5), (full0_sha, 2), (view_sha, 4)):
            value = digest.decode("ascii")
            matches = [node for node in constants if node.value == value]
            if len(matches) != count or any(ast.get_source_segment(f4_text, node)
                                            not in {f"'{value}'", f'"{value}"'} for node in matches):
                return False
        normalized = f4_raw
        for actual, marker in (
                (sensitivity_sha, b"CURRENT_A12_SENSITIVITY_MEMBER"),
                (gbm_zero_sha, b"CURRENT_A12_GBM_ZERO_PROOF"),
                (gbm_reciprocal_sha, b"CURRENT_A12_GBM_RECIPROCAL_PROOF"),
                (full0_sha, b"CURRENT_A12_FULL0_PROOF"),
                (view_sha, b"CURRENT_A12_VIEW_PROOF")):
            normalized = normalized.replace(actual, marker)
        f4_proof = "7fda2a6f9d539e4c151efbcf7e4936fcc941ac86b236842b6ed99c02552eaf99"
        return sha256_bytes(normalized) == f4_proof

    e55c_extension = reviewed_joint_extension()
    _require(isinstance(bundles, list) and len(bundles) <= 4
             and all(isinstance(path, Path) for path in bundles) and len(set(bundles)) == len(bundles),
             "F5_A12_RETAINED_VIEW_EXECUTOR_SOURCE_INVALID")
    _require(len(bundles) <= 2 or e55c_extension,
             "F5_A12_RETAINED_VIEW_EXECUTOR_SOURCE_INVALID")
    proven_sources = {}
    for bundle in bundles:
        from .f4 import load_f45_source_bundle
        manifest = load_f45_source_bundle(bundle)
        members = {row["path"]: row["sha256"] for row in manifest["members"]}
        identity = sha256_bytes(canonical_json_bytes(members))
        _require(identity not in proven_sources and set(members) == set(current),
                 "F5_A12_RETAINED_VIEW_EXECUTOR_SOURCE_INVALID")
        if identity == restoration_identity and not e55c_extension:
            # a1 performed the three authorized whole-M20 recoveries. Keep its
            # real identity and prove the unchanged MICE dependency closure;
            # never execute the archived package or alias it to this executor.
            import ast
            _require(manifest["identity_sha256"] == "4b01ec16df691c155cbd04d1b7a9a27832cd41e0a564276a996fbceba748a644"
                     and sha256_file(bundle) == "74effa70e56307e38d5b632acbf49311b8f1bfec3d19753f728ac60e7c9e6f01"
                     and all(members[name] == current[name] for name in members
                             if name not in {"padml/f5.py", "padml/f5_sensitivity.py"}),
                     "F5_A12_RETAINED_VIEW_EXECUTOR_SOURCE_INVALID")
            boundaries = {"padml/f5_sensitivity.py": {"_retained_a12_view_report_pins", "execute_a12_outer_inputs",
                                                       "materialize_a12_outer_inputs"},
                          "padml/f5.py": {"main", "_materialized_full_data_development_sources",
                                          "execute_final_complex_search", "_validate_final_search_plan"}}
            # The paired H0 change adds one fixed native-first-REPLAY arm.
            # Pin each changed body exactly, including its disabled default;
            # all other a1 producer/reader dependencies remain byte-identical.
            h0_frontier = {
                "_run_a12_total_mice_input": "884268b74be94f175bee9aede8af76a957566640e3b7cd87ee836d15eabf484d",
                "execute_a12_total_mice_bundle": "22bb451071c378fe134ba88bac439aae5c453a3c51d4782c42cc9eccd2fb7c3d",
                "materialize_a12_total_mice_view": "5eccf32f764e6ca3191ecd7d49fa54109c5680cb5ecc34ee1904aa8f98497069",
                "_execute_a12_total_view_job": "0c532c90e3aba82e294b18df113724722ff1ffd49300bdb87c8b10f8c0ef5eef",
                "_a12_h0_native_first_replay_record": "6bd894d20e5cb1f61e0bc1014a720f4ad7ac3661a1c728f710d79228983f4995",
                "_validate_a12_h0_native_first_replay_report": "4ca2cc4ef517cbc25500c941894ef6ec9a79ba1f6aa6648ce119a617db7e89a5",
            }
            boundaries["padml/f5_sensitivity.py"] |= set(h0_frontier)
            additions = {"padml/f5_sensitivity.py": {"_a12_retained_complete_view_report_pins",
                "_a12_h0_native_first_replay_record", "_validate_a12_h0_native_first_replay_report"}, "padml/f5.py": set()}
            with open_carrier(bundle) as archive:
                for member, frontier in boundaries.items():
                    fragments, scopes, decorators = [], [], []
                    for raw_source, digest in ((archive.read(member), members[member]),
                            ((Path(__file__).resolve().parent.parent / member).read_bytes(), current[member])):
                        _require(sha256_bytes(raw_source) == digest, "F5_A12_RETAINED_VIEW_MICE_DEPENDENCY_DRIFT")
                        lines, nodes = raw_source.splitlines(keepends=True), ast.parse(raw_source).body
                        functions = [node for node in nodes if isinstance(node, ast.FunctionDef)]
                        _require(len({node.name for node in functions}) == len(functions)
                                 and all(default is None or isinstance(default, (ast.Constant, ast.Name))
                                         or isinstance(default, ast.Tuple) and all(isinstance(item, ast.Constant) for item in default.elts)
                                         for node in functions for default in (*node.args.defaults, *node.args.kw_defaults)),
                                 "F5_A12_RETAINED_VIEW_MICE_DEPENDENCY_DRIFT")
                        fragments.append({node.name: b"".join(lines[node.lineno - 1:node.end_lineno]) for node in functions})
                        decorators.append({node.name: b"".join(lines[min(item.lineno for item in node.decorator_list) - 1:node.lineno - 1])
                                           for node in functions if node.decorator_list})
                        scopes.append([b"".join(lines[node.lineno - 1:node.end_lineno]) for node in nodes
                                       if not isinstance(node, ast.FunctionDef)])
                    old, new = fragments
                    _require(scopes[0] == scopes[1] and decorators[0] == decorators[1]
                             and set(new) == set(old) | additions[member]
                             and all(old[name] == new[name] for name in old if name not in frontier),
                             "F5_A12_RETAINED_VIEW_MICE_DEPENDENCY_DRIFT")
                    if member == "padml/f5_sensitivity.py":
                        _require(all(sha256_bytes(new[name]) == digest for name, digest in h0_frontier.items()),
                                 "F5_A12_RETAINED_VIEW_MICE_DEPENDENCY_DRIFT")
                    if member == "padml/f5.py":
                        # These already-tested 12-month full0 changes are not
                        # MICE gather dependencies. Still pin their exact bodies.
                        for name, digest in {
                            "_materialized_full_data_development_sources": "94288fd9826a84d4b80a715c058ec308f2a5f2f820395f61943397028ea72ee6",
                            "execute_final_complex_search": "19ee48bbe4eab2cfab74cbac39abec89238e67e69f34149f1a2e4a6de555a94c",
                            "_validate_final_search_plan": "5db75d6ed3e5cef10e5e72ddf4a1932c369dda15b0266532cd3ff07efb1626a9",
                        }.items():
                            _require(sha256_bytes(new[name]) == digest, "F5_A12_RETAINED_VIEW_MICE_DEPENDENCY_DRIFT")
        elif not e55c_extension:
            _require(identity == "1e9b98e5f7f640155bff611e94ba322b402114440eb2fbeef34d7f2c88e36268"
                 and manifest["identity_sha256"] == "14a32821e116e911c9d9cfb3678e2f2191daf589d642547e9268f166cbdae908"
                 and members["padml/f2_kernel.py"] == "54dac91205d59d10f677d254350921b06a09a1be1a431e6d87c47c273b20eebd"
                 and members["padml/nested_loco.py"] == "606a741f12fd95ec39df1477940bdf0de67a64c52915f831d3f33d7a11b62e88"
                 and all(members[name] == current[name] for name in members
                         if name not in {"padml/f4.py", "padml/f5.py", "padml/f5_sensitivity.py",
                                         "padml/f2_kernel.py", "padml/nested_loco.py"}),
                     "F5_A12_RETAINED_VIEW_EXECUTOR_SOURCE_INVALID")
        else:
            # New historical arms are exact immutable archives, not a source
            # allowlist. Only the MICE producer slice is compared to this reader;
            # each packet's original reports and receipts are checked below.
            _require(identity in historical_sources
                     and (sha256_file(bundle), bundle.stat().st_size, manifest["identity_sha256"])
                         == historical_sources[identity], "F5_A12_RETAINED_VIEW_EXECUTOR_SOURCE_INVALID")
            stable_members = {"padml/kernels/f5_a12_mice.R", "padml/kernels/f5_mice.R",
                              "padml/kernels/f45_validation_mice.R", "padml/science/authority.json"}
            _require(all(members[name] == current[name] for name in stable_members),
                     "F5_A12_RETAINED_VIEW_MICE_DEPENDENCY_DRIFT")
            import ast
            def function_bodies(raw):
                lines = raw.splitlines(keepends=True)
                nodes = [node for node in ast.parse(raw).body if isinstance(node, ast.FunctionDef)]
                _require(len({node.name for node in nodes}) == len(nodes),
                         "F5_A12_RETAINED_VIEW_MICE_DEPENDENCY_DRIFT")
                return {node.name: b"".join(lines[node.lineno - 1:node.end_lineno]) for node in nodes}
            with open_carrier(bundle) as archive:
                for member, names in {
                    "padml/f4.py": {"_f45_source_member_sha256", "load_f45_source_bundle"},
                    "padml/f5_sensitivity.py": {"_a12_total_mice_input_members", "_a12_total_mice_spec",
                        "_a12_mice_native_sources", "_a12_mice_output_members"},
                }.items():
                    old = function_bodies(archive.read(member))
                    new = function_bodies((Path(__file__).resolve().parent.parent / member).read_bytes())
                    if member == "padml/f5_sensitivity.py" and identity in {h0_identity, delivery_identity}:
                        names |= {"_load_a12_total_mice_input", "_pack_a12_total_mice_view",
                                  "materialize_a12_total_mice_view", "_a12_h0_native_first_replay_record",
                                  "_a12_retained_complete_view_report_pins"}
                    _require(all(old.get(name) == new.get(name) and old.get(name) is not None for name in names),
                             "F5_A12_RETAINED_VIEW_MICE_DEPENDENCY_DRIFT")
        proven_sources[identity] = {"sha256": sha256_file(bundle), "size_bytes": bundle.stat().st_size,
                                   "manifest_identity_sha256": manifest["identity_sha256"]}
        if identity != delivery_identity:
            identities.add(identity)
    source_sha, pins = sha256_file(source), {}
    for index, (path, ref) in enumerate(batches):
        _require(isinstance(path, Path) and path.is_absolute() and path.is_file() and not path.is_symlink()
                 and path.resolve(strict=True) == path and isinstance(ref, Mapping)
                 and set(ref) == {"object_key", "sha256", "size_bytes"}
                 and isinstance(ref["object_key"], str) and bool(ref["object_key"])
                 and type(ref["size_bytes"]) is int and ref["size_bytes"] > 0,
                 "F5_A12_RETAINED_PACKET_REFERENCE_INVALID")
        validate_sha256(ref["sha256"], "a12.retained_packet")
        _require(path.stat().st_size == ref["size_bytes"] and sha256_file(path) == ref["sha256"],
                 "F5_A12_RETAINED_PACKET_DRIFT")
        raw, names = inspect_safe_zip_manifest(path, manifest_name="collection.json",
            max_manifest_bytes=32 * 1024**2, max_member_bytes=64 * 1024**2, max_total_bytes=128 * 1024**2)
        collection = strict_json_bytes(raw)
        identity = collection.get("source_identity") if isinstance(collection, dict) else None
        restoration = collection.get("mice_restoration") if isinstance(collection, dict) else None
        first_replay = collection.get("native_first_replay") if isinstance(collection, dict) else None
        if first_replay is not None:
            from .nested_loco import _aar3_mice_view_restoration_contract
            original = _aar3_mice_view_restoration_contract()["original_projected_input"]
            expected_replay = _a12_h0_native_first_replay_record()
            _require(restoration is None
                     and (identity == current_identity or identity == h0_identity and identity in proven_sources)
                     and retained_primary_source_bundle is not None
                     and canonical_json_bytes(first_replay) == canonical_json_bytes(expected_replay)
                     and collection.get("view_ids") == [expected_replay["estimand"] + "/" + expected_replay["view_id"]]
                     and source_sha == original["sha256"] and value["identity_sha256"] == original["identity_sha256"],
                     "F5_A12_NATIVE_FIRST_REPLAY_RECORD_INVALID")
        _require(identity != restoration_identity or restoration is not None,
                 "F5_A12_MICE_RESTORATION_RECORD_REQUIRED")
        if restoration is not None:
            _require(identity == restoration_identity and identity in proven_sources
                     and retained_primary_source_bundle is not None
                     and isinstance(restoration, Mapping) and set(restoration) == set(collection.get("view_ids", [])),
                     "F5_A12_MICE_RESTORATION_RECORD_INVALID")
            for name, record in restoration.items():
                unit = _validate_a12_mice_restoration_record(record,
                    retained_primary_source_bundle=retained_primary_source_bundle)
                authority = record["science_decision"]["aar3_mice_view_restoration"]
                _require(name == unit["estimand"] + "/" + unit["view_id"]
                         and source_sha == authority["original_projected_input"]["sha256"]
                         and value["identity_sha256"] == authority["original_projected_input"]["identity_sha256"],
                         "F5_A12_MICE_RESTORATION_RECORD_INVALID")
        _require(isinstance(collection, dict) and canonical_json_bytes(collection) == raw
                 and (identity in identities or first_replay is not None and identity == current_identity)
                 and collection.get("input_sha256") == source_sha
                 and (identity == legacy_identity or collection.get("producer_source_identity") == legacy_identity)
                 and collection.get("input_identity_sha256") == value["identity_sha256"]
                 and isinstance(collection.get("view_ids"), list) and collection["view_ids"]
                 and all(isinstance(name, str) for name in collection["view_ids"])
                 and len(set(collection["view_ids"])) == len(collection["view_ids"])
                 and set(collection["view_ids"]) <= expected
                 and isinstance(collection.get("members"), dict), "F5_A12_RETAINED_PACKET_SOURCE_INVALID")
        selected = collection["view_ids"]
        delivery = collection.get("retained_complete_views")
        if delivery is not None:
            from .nested_loco import _aar3_mice_view_restoration_contract
            from .runtime import validate_resource_release
            original = _aar3_mice_view_restoration_contract()["original_projected_input"]
            original_pins = _a12_retained_complete_view_report_pins()
            zero_counts = {"new_model_fits", "new_stop_fits", "new_mice_chains", "new_mice_fit_invocations",
                           "new_native_replay_invocations", "new_selector_paths", "new_glmnet_calls"}
            _require(identity == legacy_identity and restoration is None
                     and retained_primary_source_bundle is not None
                     and source_sha == original["sha256"] and value["identity_sha256"] == original["identity_sha256"]
                     and value["outer_fold"] == 3 and value["family"] == "GBM_COX"
                     and set(selected) <= set(original_pins)
                     and set(collection) == {"source_identity", "input_sha256", "input_identity_sha256",
                                            "view_ids", "members", "retained_complete_views"}
                     and isinstance(delivery, dict)
                     and set(delivery) == zero_counts | {"executor_source_identity", "historical_batch_status", "view_ids",
                                                         "original_report_pins", "resource_release"}
                     and (delivery["executor_source_identity"] == current_identity
                          or delivery["executor_source_identity"] == delivery_identity
                             and delivery_identity in proven_sources)
                     and delivery["view_ids"] == selected
                     and delivery["historical_batch_status"] == "UNKNOWN"
                     and all(type(delivery[key]) is int and delivery[key] == 0 for key in zero_counts)
                     and delivery["original_report_pins"] == {name: original_pins[name] for name in selected},
                     "F5_A12_RETAINED_COMPLETE_VIEW_DELIVERY_INVALID")
            validate_resource_release(delivery["resource_release"])
            release = delivery["resource_release"]
            _require(release.get("reader_scan_status") == "OBSERVED" and release.get("files")
                     and all(row["status"] in {"ADVISED", "UNSUPPORTED"} and row["error"] is None for row in release["files"])
                     and all(type(release[key]["rss_bytes"]) is int for key in ("before", "after")),
                     "F5_A12_RETAINED_COMPLETE_VIEW_RELEASE_INCOMPLETE")
            _require(release["owner"] == "AAR_RETAINED_VIEW_DELIVERY:3:"
                     + sha256_bytes(canonical_json_bytes(selected)), "F5_A12_VIEW_RELEASE_OWNER_MISMATCH")
            declared = {"collection.json": {"sha256": sha256_bytes(raw), "size_bytes": len(raw)}, **collection["members"]}
            metadata = {"collection.json", *("views/" + name + "/numerical.zip.json" for name in selected)}
            _require(set(names) == set(declared) == {"collection.json", *("views/" + name + "/numerical.zip" + suffix
                     for name in selected for suffix in ("", ".json"))}
                     and all(declared["views/" + name + "/numerical.zip.json"] == original_pins[name] for name in selected),
                     "F5_A12_RETAINED_COMPLETE_VIEW_REPORT_DRIFT")
            release_files = {str(_a12_mice_restoration_coordinate_root({
                "original_producer_source_identity": legacy_identity, "estimand": name.split("/")[0],
                "view_id": name.split("/")[1]}) / ("numerical.zip" + suffix)):
                    declared["views/" + name + "/numerical.zip" + suffix]["size_bytes"]
                for name in selected for suffix in ("", ".json")}
            _require({row["path"]: row["size_bytes"] for row in release["files"]} == release_files,
                     "F5_A12_RETAINED_COMPLETE_VIEW_RELEASE_FILES_INVALID")
            def admit_delivery(*, pending_bytes=0, memory_bytes=0):
                policy = value["resource_policy"]
                resource_admission({**policy, "memory_bytes_per_worker": MIN_WORKER_MEMORY_BYTES,
                                    "memory_reserve_bytes": policy["memory_reserve_bytes"] + memory_bytes
                                    + 32 * sum(declared[name]["size_bytes"] for name in metadata),
                                    "scratch_reserve_bytes": policy["scratch_reserve_bytes"] + pending_bytes},
                                   observe_execution_resources(root), legal_tasks=1)
            destination = root / f"retained-view-batch-{index}"
            extract_safe_zip(path, destination, expected_members=declared, selected_members=metadata,
                max_member_bytes=64 * 1024**2, max_total_bytes=128 * 1024**2, admit_io=admit_delivery)
            for name in selected:
                report = strict_json_bytes((destination / ("views/" + name + "/numerical.zip.json")).read_bytes())
                _require(name not in pins and isinstance(report, dict)
                         and {"sha256": report.get("sha256"), "size_bytes": report.get("size_bytes")}
                             == declared["views/" + name + "/numerical.zip"],
                         "F5_A12_RETAINED_COMPLETE_VIEW_REPORT_DRIFT")
                # This is a new delivery pin, not a recreated historical handle.
                pins[name] = {"name": name, "result_sha256": original_pins[name]["sha256"],
                    "result_size_bytes": original_pins[name]["size_bytes"], "executor_source_identity": legacy_identity,
                    "packet_reference": dict(ref), "retained_complete_view_delivery": delivery,
                    **({"retained_source_bundle": proven_sources[delivery_identity]}
                       if delivery["executor_source_identity"] == delivery_identity else {})}
            continue
        cli_names = [name for name in names if name.startswith("cli/") and name.endswith("-execution.json")]
        _require(len(cli_names) == 1, "F5_A12_RETAINED_PACKET_SOURCE_INVALID")
        stem = cli_names[0].removesuffix("-execution.json")
        metadata = {"collection.json", "batch/execution.json", "batch/mice-results.json",
                    cli_names[0], stem + ".stdout", stem + ".stderr"}
        _require(set(names) == metadata | {"views/" + name + "/numerical.zip" + suffix
                 for name in selected for suffix in ("", ".json")}
                 and set(names) == {"collection.json", *collection["members"]},
                 "F5_A12_RETAINED_PACKET_MEMBER_INVALID")
        declared = {"collection.json": {"sha256": sha256_bytes(raw), "size_bytes": len(raw)}, **collection["members"]}
        def admit_io(*, pending_bytes=0, memory_bytes=0):
            policy = value["resource_policy"]
            resource_admission({**policy, "memory_bytes_per_worker": MIN_WORKER_MEMORY_BYTES,
                                "memory_reserve_bytes": policy["memory_reserve_bytes"] + memory_bytes
                                + 32 * sum(declared[name]["size_bytes"] for name in metadata),
                                "scratch_reserve_bytes": policy["scratch_reserve_bytes"] + pending_bytes},
                               observe_execution_resources(root), legal_tasks=1)
        destination = root / f"retained-view-batch-{index}"
        extract_safe_zip(path, destination, expected_members=declared, selected_members=metadata,
            max_member_bytes=64 * 1024**2, max_total_bytes=128 * 1024**2, admit_io=admit_io)
        cli = strict_json_bytes((destination / cli_names[0]).read_bytes())
        output = strict_json_bytes((destination / (stem + ".stdout")).read_bytes())
        execution = strict_json_bytes((destination / "batch/execution.json").read_bytes())
        _require(execution.get("mice_restoration") == restoration,
                 "F5_A12_MICE_RESTORATION_RECORD_INVALID")
        _require(canonical_json_bytes(execution.get("native_first_replay")) == canonical_json_bytes(first_replay),
                 "F5_A12_NATIVE_FIRST_REPLAY_RECORD_INVALID")
        if first_replay is not None:
            _require(all(type(execution.get(key)) is int and execution[key] == expected_count for key, expected_count in (
                         ("completed_mice_fit_invocations", 0), ("completed_mice_chain_count", 0),
                         ("completed_native_replay_invocations", 1))), "F5_A12_NATIVE_FIRST_REPLAY_RECORD_INVALID")
        if restoration is not None:
            _require(type(execution.get("completed_mice_fit_invocations")) is int
                     and execution["completed_mice_fit_invocations"] == len(selected)
                     and type(execution.get("completed_mice_chain_count")) is int
                     and execution["completed_mice_chain_count"] == 20 * len(selected),
                     "F5_A12_MICE_RESTORATION_RECORD_INVALID")
        _require(cli.get("source_identity") == identity and type(cli.get("exit_code")) is int and cli["exit_code"] == 0
                 and cli.get("stdout_sha256") == declared[stem + ".stdout"]["sha256"]
                 and cli.get("stderr_sha256") == declared[stem + ".stderr"]["sha256"]
                 and cli.get("view_ids") == selected and output.get("view_ids") == selected
                 and output.get("status") == "COMPUTED_NATIVE_VIEWS" and output.get("stage_acceptance") is False
                 and output.get("outer_fold") == value["outer_fold"] and output.get("family") == value["family"]
                 and output.get("execution_report") == execution and execution.get("view_ids") == selected
                 and execution.get("projected_input_identity_sha256") == value["identity_sha256"]
                 and execution.get("mice_pool") == collection.get("pool")
                 and execution.get("mice_pool", {}).get("status") == "COMPLETED"
                 and execution["mice_pool"].get("completed_task_count") == len(selected)
                 and all(type(output.get(key)) is int and output[key] == 0 for key in ("model_fit_count", "selector_path_count"))
                 and type(output.get("mice_chain_execution_count")) is int
                 and output["mice_chain_execution_count"] == (0 if first_replay is not None else 20 * len(selected)),
                 "F5_A12_RETAINED_PACKET_EXECUTION_INVALID")
        handles = strict_json_bytes((destination / "batch/mice-results.json").read_bytes())
        _require(isinstance(handles, list) and [row.get("name") for row in handles] == selected,
                 "F5_A12_RETAINED_VIEW_RECORD_INVALID")
        for handle in handles:
            _require(set(handle) == {"name", "result_path", "result_sha256", "result_size_bytes", "status", "stage_acceptance"}
                     and handle["name"] not in pins and handle["status"] == "COMPUTED" and handle["stage_acceptance"] is False
                     and type(handle["result_size_bytes"]) is int and handle["result_size_bytes"] > 0
                     and {"sha256": handle["result_sha256"], "size_bytes": handle["result_size_bytes"]}
                         == collection["members"]["views/" + handle["name"] + "/numerical.zip.json"],
                     "F5_A12_RETAINED_VIEW_RECORD_INVALID")
            if restoration is not None:
                _require(handle["result_path"] == restoration[handle["name"]]["attempt_root"] + "/numerical.zip.json",
                         "F5_A12_MICE_RESTORATION_RECORD_INVALID")
            if first_replay is not None:
                _require(handle["result_path"] == first_replay["attempt_root"] + "/numerical.zip.json",
                         "F5_A12_NATIVE_FIRST_REPLAY_RECORD_INVALID")
            pins[handle["name"]] = {**handle, "executor_source_identity": identity,
                "packet_reference": dict(ref),
                **({"retained_source_bundle": proven_sources[identity]} if identity in proven_sources else {}),
                **({"mice_restoration": restoration[handle["name"]]} if restoration is not None else {}),
                **({"native_first_replay": first_replay} if first_replay is not None else {})}
    return pins


def _a12_completed_mice_reuse(source: Path, opened: Mapping[str, Any], candidates: list[dict], target: Path) -> dict:
    """Select original, first-audited views from byte-verified whole units.

    The worker admits the whole receipts and bytes before calling this reader.
    A completed unit that itself reused a view does not become its producer;
    the original whole producer remains among the context's local units.
    """
    from .bundle import _validated_zip_infos
    value = opened["input"]
    # A present native coordinate belongs to this original attempt, including
    # an unfinished/failed one. Reuse never hides or replaces that producer.
    wanted = {f"{row['estimand']}/{row['view_id']}": row for row in value["mice_inputs"]
              if not (source.with_name(source.name + ".mice") / row["estimand"] / row["view_id"]).exists()}
    horizon = value["primary_source"]["primary_development_lock"]["selection_horizon_months"]
    found = {}
    if not wanted:
        return found
    target.mkdir(mode=0o700)
    for candidate in candidates:
        _require(isinstance(candidate, dict) and set(candidate) == {"root", "receipt"},
                 "F45_AAR_MICE_REUSE_WHOLE_REQUIRED")
        root, receipt = Path(candidate["root"]), candidate["receipt"]
        _require(root.is_absolute() and root.is_dir() and not root.is_symlink()
                 and (root / "unit.json").read_bytes() == canonical_json_bytes(receipt)
                 and receipt.get("status") == "COMPLETED" and receipt.get("direct_consumer_completed") is True
                 and receipt.get("selection_horizon_months") in {6, 12, 24, 36} - {horizon}
                 and root.name == receipt.get("unit_id")
                     == f"AAR-H{receipt['selection_horizon_months']:02d}-O{value['outer_fold']}",
                 "F45_AAR_MICE_REUSE_WHOLE_REQUIRED")
        destination = target / root.name
        destination.mkdir(mode=0o700)
        with open_carrier(root / "result.zip") as archive:
            _require(archive.getinfo("a12-outer.json").file_size <= 32 * 1024**2,
                     "F5_A12_OUTER_INDEX_TOO_LARGE")
            raw = archive.read("a12-outer.json")
            result = strict_json_bytes(raw)
            _require(canonical_json_bytes(result) == raw
                     and result.get("kind") == "PADML_F5_A12_OUTER_NATIVE_V2"
                     and result.get("outer_fold") == value["outer_fold"]
                     and result.get("identity_sha256") == sha256_bytes(canonical_json_bytes({
                         key: item for key, item in result.items() if key != "identity_sha256"})),
                     "F45_AAR_MICE_REUSE_WHOLE_REQUIRED")
            pin = result["members"]["inputs.zip"]
            _require(archive.getinfo("inputs.zip").file_size == pin["size_bytes"]
                     and pin["size_bytes"] <= 12 * 1024**3,
                     "F5_A12_INPUT_EXPANSION_SPACE_INSUFFICIENT")
            mice = archive.external_path("inputs.zip")
            if mice is None:
                _require(shutil.disk_usage(destination).free >= 2 * pin["size_bytes"],
                         "F5_A12_INPUT_EXPANSION_SPACE_INSUFFICIENT")
                mice = destination / "inputs.zip"
                with archive.open("inputs.zip") as src, mice.open("xb") as dst:
                    shutil.copyfileobj(src, dst)
        _require(sha256_file(mice) == pin["sha256"], "F45_AAR_MICE_REUSE_BYTES_DRIFT")
        with open_carrier(mice) as archive:
            _validated_zip_infos(archive, None, max_member_bytes=3 * 1024**3,
                                 max_total_bytes=12 * 1024**3, max_compression_ratio=1000)
            _require(archive.getinfo("a12-inputs.json").file_size <= 32 * 1024**2,
                     "F5_A12_INPUT_INDEX_TOO_LARGE")
            raw = archive.read("a12-inputs.json")
            index = strict_json_bytes(raw)
            _require(canonical_json_bytes(index) == raw
                     and index.get("kind") == "PADML_F5_A12_OUTER_INPUTS_NATIVE_V2"
                     and index.get("stage") == "MICE_MATERIALIZED_PRE_DEVELOPMENT"
                     and index.get("projected_input_identity_sha256") == result["source"]["identity_sha256"]
                     and index.get("identity_sha256") == sha256_bytes(canonical_json_bytes({
                         key: item for key, item in index.items() if key != "identity_sha256"})),
                     "F45_AAR_MICE_REUSE_BYTES_DRIFT")
            for name in sorted(set(wanted) & set(index["mice_views"]) - set(found) - set(index.get("mice_reuse", {}))):
                member = "views/" + name + ".zip"
                numbers = index["mice_views"][name]
                local = destination / member
                local.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
                path = archive.external_path(member)
                if path is None:
                    path = local
                    with archive.open(member) as src, path.open("xb") as dst:
                        shutil.copyfileobj(src, dst)
                view_pin = {"sha256": sha256_file(path), "size_bytes": path.stat().st_size}
                _require(view_pin == index["members"][member], "F45_AAR_MICE_REUSE_BYTES_DRIFT")
                with open_carrier(path) as view:
                    _require(view.getinfo("input.zip").file_size <= 128 * 1024**2,
                             "F45_AAR_MICE_REUSE_BYTES_DRIFT")
                    original_raw = view.read("input.zip")
                original = local.with_suffix(".producer-input.zip")
                original.write_bytes(original_raw)
                original_pin = {"sha256": sha256_bytes(original_raw), "size_bytes": len(original_raw)}
                _require(original_pin == numbers["members"]["input.zip"], "F45_AAR_MICE_REUSE_BYTES_DRIFT")
                current = opened["root"] / wanted[name]["member"]
                key = _a12_mice_reuse_identity(original)
                if key != _a12_mice_reuse_identity(current):
                    continue
                found[name] = {"path": path, "numbers": numbers, "record": {
                    "whole_unit": receipt, "result_archive": receipt["artifacts"]["result.zip"],
                    "mice_archive": pin, "view_archive": view_pin, "producer_input": original_pin,
                    "consumer_input": {"sha256": sha256_file(current), "size_bytes": current.stat().st_size},
                    "numerical_identity_sha256": key}}
        if set(found) == set(wanted):
            break
    return found


def execute_a12_outer_inputs(source: Path, target: Path, *, f2_run_root: Path | None = None, outer_fold: int | None = None,
                             workers: int | None = None, f1_runtime_root: Path | None = None,
                             view_ids: list[str] | None = None, view_results: list[Path] | None = None,
                             retained_bytes_per_view: int | None = None,
                             retained_primary_source_bundle: Path | None = None,
                             retained_view_batches: list[tuple[Path, Mapping[str, Any]]] | None = None,
                             retained_view_source_bundle: Path | list[Path] | None = None,
                             mice_restoration_decision: Mapping[str, Any] | None = None,
                             native_first_replay: bool = False,
                             completed_aar_units: list[dict] | None = None) -> dict[str, Any]:
    """One original input shard; projected input runs both fresh branches in one pool."""
    _require(source.is_absolute() and source.is_file() and not source.is_symlink()
             and target.is_absolute() and target.parent.is_dir() and not target.exists(), "F5_A12_INPUT_PATH_INVALID")
    _require(completed_aar_units is None or isinstance(completed_aar_units, list)
             and zipfile.is_zipfile(source) and view_ids is None and view_results is None
             and retained_primary_source_bundle is None and mice_restoration_decision is None
             and not native_first_replay, "F45_AAR_MICE_REUSE_SCOPE_INVALID")
    _require(not (view_ids is not None and view_results is not None)
             and (view_ids is None and view_results is None or zipfile.is_zipfile(source)),
             "F5_A12_PROJECTED_ARGUMENT_SCOPE_INVALID")
    _require(retained_view_batches is None or view_results is not None
             and retained_primary_source_bundle is not None,
             "F5_A12_RETAINED_VIEW_RECORD_SCOPE_INVALID")
    _require(retained_view_source_bundle is None or view_results is not None and retained_view_batches is not None
             and retained_primary_source_bundle is not None, "F5_A12_RETAINED_VIEW_RECORD_SCOPE_INVALID")
    _require(retained_primary_source_bundle is None or zipfile.is_zipfile(source)
             and (view_ids is not None or view_results is not None), "F5_RETAINED_AAR_SOURCE_SCOPE_INVALID")
    _require(type(native_first_replay) is bool and (not native_first_replay
             or mice_restoration_decision is None and view_results is None and view_ids is not None
             and retained_primary_source_bundle is not None and retained_view_batches is None
             and retained_view_source_bundle is None), "F5_A12_NATIVE_FIRST_REPLAY_SCOPE_INVALID")
    first_replay = _a12_h0_native_first_replay_record() if native_first_replay else None
    if first_replay is not None:
        from .nested_loco import _aar3_mice_view_restoration_contract
        original = _aar3_mice_view_restoration_contract()["original_projected_input"]
        coordinate = Path(first_replay["attempt_root"]).parent
        _require(view_ids == [first_replay["estimand"] + "/" + first_replay["view_id"]]
                 and source == coordinate.parents[2] / "outer-3.aar.input.zip"
                 and sha256_file(source) == original["sha256"]
                 and not Path(first_replay["attempt_root"]).exists()
                 and not Path(first_replay["attempt_root"]).is_symlink(),
                 "F5_A12_NATIVE_FIRST_REPLAY_COORDINATE_ALREADY_STARTED")
    restorations = {}
    if mice_restoration_decision is not None:
        from . import nested_loco as nested
        from .f4 import _retained_full0_source_members
        _require(view_ids is not None and retained_primary_source_bundle is not None
                 and retained_view_batches is None and retained_view_source_bundle is None,
                 "F5_A12_MICE_RESTORATION_RECORD_INVALID")
        _retained_full0_source_members(retained_primary_source_bundle,
                                      aar_primary_context=True, aar_mice_restoration=True)
        decision = nested.validate_science_decision(mice_restoration_decision)
        authority = decision.get("aar3_mice_view_restoration")
        _require(isinstance(authority, Mapping) and isinstance(view_ids, list) and view_ids
                 and len(set(view_ids)) == len(view_ids)
                 and sha256_file(source) == authority["original_projected_input"]["sha256"],
                 "F5_A12_MICE_RESTORATION_RECORD_INVALID")
        units = {unit["estimand"] + "/" + unit["view_id"]: unit for unit in authority["atomic_units"]}
        _require(set(view_ids) <= set(units), "F5_A12_MICE_RESTORATION_RECORD_INVALID")
        for name in view_ids:
            unit = units[name]
            coordinate = _a12_mice_restoration_coordinate_root(unit)
            attempt = coordinate / "restoration-20260913-00-28"
            _require(source == coordinate.parents[2] / "outer-3.aar.input.zip"
                     and not attempt.exists() and not attempt.is_symlink(),
                     "F5_A12_MICE_COORDINATE_ALREADY_STARTED")
            record = {"science_decision": decision, "unit": unit,
                "original_files": _a12_mice_restoration_original_files(unit), "attempt_root": str(attempt),
                "historical_interruption_cause": "UNKNOWN"}
            _validate_a12_mice_restoration_view(record, source=coordinate / "input.zip",
                retained_primary_source_bundle=retained_primary_source_bundle)
            restorations[name] = record
    if zipfile.is_zipfile(source):
        from . import nested_loco as nested
        from .f4 import _f45_source_member_sha256
        from .runtime import observe_execution_resources, resource_admission, validate_resource_release

        producer = ({} if retained_primary_source_bundle is None else
                    {"retained_primary_source_bundle": retained_primary_source_bundle})

        _require(f2_run_root is None and f1_runtime_root is None and outer_fold is None and workers is None,
                 "F5_A12_PROJECTED_ARGUMENT_SCOPE_INVALID")
        if view_ids is not None:
            _require(isinstance(view_ids, list) and bool(view_ids)
                     and all(isinstance(name, str) for name in view_ids) and len(set(view_ids)) == len(view_ids)
                     and type(retained_bytes_per_view) is int and retained_bytes_per_view > 0
                     and not target.is_symlink() and source.parent.stat().st_dev == target.parent.stat().st_dev,
                     "F5_A12_MICE_VIEW_IDS_INVALID")
            target.mkdir(mode=0o700)
            execution = {}
            try:
                opened = _load_a12_projected_outer_inputs(source, target / "input", **producer,
                    **({"retained_primary_context": True} if restorations or first_replay is not None else {}))
                value = opened["input"]
                if first_replay is not None:
                    _require(value["identity_sha256"] == original["identity_sha256"]
                             and value["outer_fold"] == 3 and value["family"] == "GBM_COX",
                             "F5_A12_NATIVE_FIRST_REPLAY_SCOPE_INVALID")
                if restorations:
                    _require(value["identity_sha256"] == authority["original_projected_input"]["identity_sha256"]
                             and value["outer_fold"] == 3 and value["family"] == "GBM_COX",
                             "F5_A12_MICE_RESTORATION_RECORD_INVALID")
                by_id = {f"{row['estimand']}/{row['view_id']}": row for row in value["mice_inputs"]}
                _require(set(view_ids) <= set(by_id), "F5_A12_MICE_VIEW_IDS_INVALID")
                # Native coordinate paths do not depend on this batch's report
                # directory. Disjoint subsequent subsets may use the same input;
                # existing or partial coordinates may not start again.
                coordinate_root = source.with_name(source.name + ".mice")
                _require(not coordinate_root.is_symlink(), "F5_A12_MICE_COORDINATE_ALREADY_STARTED")
                selected = [name for name in by_id if name in view_ids]
                for name in selected:
                    path = (Path(restorations[name]["attempt_root"]) if restorations else coordinate_root / name)
                    if first_replay is not None:
                        path = Path(first_replay["attempt_root"])
                    _require(not path.parent.is_symlink() and not path.exists() and not path.is_symlink(),
                             "F5_A12_MICE_COORDINATE_ALREADY_STARTED")
                    if restorations:
                        _require(sha256_file(opened["root"] / by_id[name]["member"])
                                 == restorations[name]["unit"]["original_input"]["sha256"],
                                 "F5_A12_MICE_RESTORATION_ORIGINAL_DRIFT")
                    if first_replay is not None:
                        _require(sha256_file(opened["root"] / by_id[name]["member"])
                                 == first_replay["original_input"]["sha256"],
                                 "F5_A12_NATIVE_FIRST_REPLAY_ORIGINAL_DRIFT")
                policies = [_a12_mice_numerical_policy(opened["root"] / by_id[name]["member"],
                    retained_bytes_per_view, execution_worker_memory_bytes=MIN_WORKER_MEMORY_BYTES) for name in selected]
                policy = value["resource_policy"]
                batch_report_reserved_bytes = 64 * 1024**2
                effective = {**policy,
                    "memory_bytes_per_worker": max(item["memory_bytes_per_worker"] for item in policies),
                    "memory_reserve_bytes": policy["memory_reserve_bytes"] + 32 * 32 * 1024**2,
                    "scratch_reserve_bytes": policy["scratch_reserve_bytes"] + len(selected) * retained_bytes_per_view
                                             + batch_report_reserved_bytes}
                observation = observe_execution_resources(source.parent)
                admission = resource_admission(effective, observation, legal_tasks=len(selected))
                execution.update(resource_observation=observation, resource_admission=admission,
                    effective_policy=effective, projected_input_identity_sha256=value["identity_sha256"],
                    view_ids=selected, retained_bytes_per_view=retained_bytes_per_view,
                    batch_report_reserved_bytes=batch_report_reserved_bytes, mice_pool={}, resource_release={})
                if restorations:
                    execution["mice_restoration"] = restorations
                if first_replay is not None:
                    execution["native_first_replay"] = first_replay
                jobs = []
                for name in selected:
                    path = (Path(restorations[name]["attempt_root"]) if restorations else coordinate_root / name)
                    if first_replay is not None:
                        path = Path(first_replay["attempt_root"])
                    path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
                    # Existing native coordinate exclusion, with one fixed
                    # recovery slot. Failure and pre-FIT residue both stay put;
                    # neither a new batch path nor a new decision resets it.
                    path.mkdir(mode=0o700)
                    if not restorations and first_replay is None:
                        shutil.copyfile(opened["root"] / by_id[name]["member"], path / "input.zip")
                    jobs.append({"name": name, "input": str((path.parent if restorations or first_replay is not None else path) / "input.zip"),
                                 "target": str(path / "numerical.zip"),
                                 **({"mice_restoration": restorations[name]} if restorations else {}),
                                 **({"native_first_replay": True} if first_replay is not None else {}),
                                 "retained_bytes_per_view": retained_bytes_per_view, **producer})
                results = _bounded_ordered_spawn(_execute_a12_total_view_job, jobs,
                    selected_slots=admission["admitted_worker_ceiling"], execution_report=execution["mice_pool"],
                    resource_release_report=execution["resource_release"])
                raw = canonical_json_bytes(results)
                _require(len(raw) <= 32 * 1024**2, "F5_A12_INPUT_INDEX_TOO_LARGE")
                (target / "mice-results.json").write_bytes(raw)
                if restorations:
                    execution.update(completed_mice_fit_invocations=len(results),
                                     completed_mice_chain_count=20 * len(results))
                if first_replay is not None:
                    execution.update(completed_mice_fit_invocations=0, completed_mice_chain_count=0,
                                     completed_native_replay_invocations=1)
            except BaseException as exc:
                exc.add_note(f"F5_A12_INPUT_EXECUTION_EVIDENCE:{target}")
                raise
            finally:
                (target / "execution.json").write_bytes(canonical_json_bytes(execution))
            return {"status": "COMPUTED_NATIVE_VIEWS", "stage_acceptance": False,
                "outer_fold": value["outer_fold"], "family": value["family"], "view_ids": selected,
                "mice_chain_execution_count": 0 if first_replay is not None else 20 * len(selected),
                "model_fit_count": 0, "selector_path_count": 0,
                "view_result_paths": [job["target"] + ".json" for job in jobs], "execution_report": execution}
        root = Path(tempfile.mkdtemp(prefix=target.name + ".input-", dir=target.parent))
        execution = {}
        try:
            opened = _load_a12_projected_outer_inputs(source, root / "input", **producer,
                **({"retained_mice_gather": True} if view_results is not None and retained_primary_source_bundle is not None else {}))
            value, jobs, archives = opened["input"], [], {}
            resumed_views, resumed_audits = [], []
            reused = (_a12_completed_mice_reuse(source, opened, completed_aar_units, root / "completed-units")
                      if completed_aar_units else {})
            mice_reuse = {name: item["record"] for name, item in reused.items()}
            numerical_views = None
            if view_results is not None:
                _require(isinstance(view_results, list) and len(view_results) == len(value["mice_inputs"])
                         and all(isinstance(path, Path) and path.is_absolute() and path.is_file()
                                 and not path.is_symlink() and path.name.endswith(".zip.json") for path in view_results),
                         "F5_A12_MICE_NUMERICAL_VIEW_COVERAGE_INVALID")
                report_bytes = sum(path.stat().st_size for path in view_results)
                _require(report_bytes <= 32 * 1024**2, "F5_A12_INPUT_INDEX_TOO_LARGE")
                policy = value["resource_policy"]
                admission = resource_admission({**policy, "memory_bytes_per_worker": MIN_WORKER_MEMORY_BYTES,
                    "memory_reserve_bytes": policy["memory_reserve_bytes"] + 32 * report_bytes},
                    observe_execution_resources(root), legal_tasks=1)
                expected = {(row["estimand"], row["view_id"]): row for row in value["mice_inputs"]}
                retained_reports = {}
                if retained_view_batches is not None:
                    retained_reports = _retained_a12_view_report_pins(retained_view_batches, source=source, value=value, root=root,
                        retained_primary_source_bundle=retained_primary_source_bundle,
                        **({"retained_view_source_bundle": retained_view_source_bundle}
                           if retained_view_source_bundle is not None else {}))
                    execution["retained_view_batches"] = [{"path": str(path), **ref} for path, ref in retained_view_batches]
                    if retained_view_source_bundle is not None:
                        sources = ([retained_view_source_bundle] if isinstance(retained_view_source_bundle, Path)
                                   else retained_view_source_bundle)
                        execution["retained_view_source"] = {"bundles": [{"sha256": sha256_file(path),
                            "size_bytes": path.stat().st_size} for path in sources],
                            "executor_source_identities": sorted({row["executor_source_identity"] for row in retained_reports.values()})}
                    execution["retained_view_report_bindings"] = {name: {
                        "executor_source_identity": pin["executor_source_identity"],
                        "original_report": {"sha256": pin["result_sha256"], "size_bytes": pin["result_size_bytes"]},
                        "packet_reference": pin["packet_reference"],
                        **({"retained_source_bundle": pin["retained_source_bundle"]} if "retained_source_bundle" in pin else {}),
                        **({"retained_complete_view_delivery": pin["retained_complete_view_delivery"]}
                           if "retained_complete_view_delivery" in pin else {}),
                        **({"native_first_replay": pin["native_first_replay"]} if "native_first_replay" in pin else {})}
                        for name, pin in retained_reports.items()}
                numerical_views, reports = {}, {}
                for path in view_results:
                    raw = path.read_bytes()
                    report = strict_json_bytes(raw)
                    legacy = isinstance(report, dict) and "resource_release" not in report
                    restoration = report.get("mice_restoration") if isinstance(report, dict) else None
                    first_replay_report = report.get("native_first_replay") if isinstance(report, dict) else None
                    from .f4 import _f45_source_member_sha256
                    current_executor = isinstance(report, dict) and report.get("executor_source_identity") == sha256_bytes(
                        canonical_json_bytes(_f45_source_member_sha256()))
                    worker_budget = report.get("execution_worker_memory_bytes") if isinstance(report, dict) else None
                    _require(isinstance(report, dict) and (type(worker_budget) is int and worker_budget in RECORDED_WORKER_MEMORY_BYTES
                             if current_executor else "execution_worker_memory_bytes" not in report),
                             "F5_A12_MICE_WORKER_MEMORY_BUDGET_INVALID")
                    keys = {"sha256", "size_bytes", "status", "stage_acceptance", "numerical_view",
                                 "execution_report", "first_audit_execution_report", "resource_admission",
                                 "resource_observation", "retained_bytes_limit", "retained_bytes_before_report"}
                    if current_executor:
                        keys.add("execution_worker_memory_bytes")
                    _require(isinstance(report, dict) and canonical_json_bytes(report) == raw
                             and set(report) == (keys if legacy else keys | {"resource_release", "executor_source_identity"}
                                                | ({"mice_restoration"} if restoration is not None else set())
                                                | ({"native_first_replay"} if first_replay_report is not None else set()))
                             and report.get("status") == "COMPUTED" and report.get("stage_acceptance") is False
                             and isinstance(report.get("numerical_view"), Mapping), "F5_A12_MICE_NUMBERS_REQUIRED")
                    numbers = report["numerical_view"]
                    spec = numbers.get("spec", {})
                    _require(isinstance(spec, Mapping) and isinstance(spec.get("nested_aar_source"), Mapping)
                             and isinstance(spec.get("view"), Mapping), "F5_A12_MICE_NUMBERS_REQUIRED")
                    coordinate = (spec.get("nested_aar_source", {}).get("estimand"), spec.get("view", {}).get("view_id"))
                    _require(coordinate in expected and coordinate not in archives,
                             "F5_A12_MICE_NUMERICAL_VIEW_COVERAGE_INVALID")
                    name = "/".join(coordinate)
                    pin = retained_reports.get(name)
                    # These exact incomplete old views have no ordinary current
                    # completion route. Stripping the restoration binding must
                    # not downgrade a restored view to an unqualified report.
                    recovery_contract = nested._aar3_mice_view_restoration_contract()
                    recovery_scope = (value["identity_sha256"] == recovery_contract["original_projected_input"]["identity_sha256"]
                        and name in {unit["estimand"] + "/" + unit["view_id"] for unit in recovery_contract["atomic_units"]})
                    delivery_scope = (value["identity_sha256"] == recovery_contract["original_projected_input"]["identity_sha256"]
                                      and name in _a12_retained_complete_view_report_pins())
                    replay_record = _a12_h0_native_first_replay_record()
                    replay_scope = (value["identity_sha256"] == recovery_contract["original_projected_input"]["identity_sha256"]
                                    and name == replay_record["estimand"] + "/" + replay_record["view_id"])
                    _require((first_replay_report is not None) == replay_scope,
                             "F5_A12_NATIVE_FIRST_REPLAY_RECORD_REQUIRED")
                    if replay_scope:
                        _require(not legacy and restoration is None and isinstance(pin, Mapping)
                                 and canonical_json_bytes(pin.get("native_first_replay")) == canonical_json_bytes(first_replay_report),
                                 "F5_A12_NATIVE_FIRST_REPLAY_RECORD_REQUIRED")
                    _require(not delivery_scope or legacy and isinstance(pin, Mapping)
                             and "retained_complete_view_delivery" in pin
                             and {"sha256": sha256_bytes(raw), "size_bytes": len(raw)}
                                 == _a12_retained_complete_view_report_pins()[name],
                             "F5_A12_RETAINED_COMPLETE_VIEW_DELIVERY_REQUIRED")
                    _require(not recovery_scope or restoration is not None,
                             "F5_A12_MICE_RESTORATION_RECORD_REQUIRED")
                    _require(not recovery_scope or isinstance(pin, Mapping)
                             and pin.get("executor_source_identity") == "a1fabe4424b844025db0449126d60dd81dded09a88cd15e2cd7e78b0c154fa9b"
                             and "retained_source_bundle" in pin, "F5_A12_MICE_RESTORATION_RETAINED_SOURCE_REQUIRED")
                    if restoration is not None:
                        _require(not legacy and retained_primary_source_bundle is not None and isinstance(pin, Mapping)
                                 and pin.get("mice_restoration") == restoration,
                                 "F5_A12_MICE_RESTORATION_RECORD_INVALID")
                        unit = _validate_a12_mice_restoration_record(restoration,
                            retained_primary_source_bundle=retained_primary_source_bundle)
                        _require(name == unit["estimand"] + "/" + unit["view_id"]
                                 and spec.get("chain_seeds") == unit["chain_seeds"]
                                 and numbers.get("members", {}).get("input.zip") == unit["original_input"],
                                 "F5_A12_MICE_RESTORATION_ORIGINAL_DRIFT")
                    if legacy or pin is not None:
                        _require(isinstance(pin, Mapping), "F5_A12_LEGACY_VIEW_REPORT_PIN_REQUIRED")
                        _require(pin.get("result_sha256") == sha256_bytes(raw)
                                 and pin.get("result_size_bytes") == len(raw),
                                 "F5_A12_LEGACY_VIEW_REPORT_PIN_REQUIRED")
                    if legacy:
                        _require(pin["executor_source_identity"] == "1513ecba963857099c6b99413b8e976393c551a3ec30ed90da1cb14178338bd7",
                                 "F5_A12_VIEW_EXECUTOR_SOURCE_MISMATCH")
                    else:
                        from .f4 import _f45_source_member_sha256
                        executor = (pin["executor_source_identity"] if pin is not None else
                                    sha256_bytes(canonical_json_bytes(_f45_source_member_sha256())))
                        _require(report["executor_source_identity"] == executor,
                                 "F5_A12_VIEW_EXECUTOR_SOURCE_MISMATCH")
                        validate_resource_release(report["resource_release"])
                        _require(report["resource_release"]["owner"] == "AAR_MICE_VIEW:" + str(value["outer_fold"]) + ":" + name,
                                 "F5_A12_VIEW_RELEASE_OWNER_MISMATCH")
                    original = opened["root"] / expected[coordinate]["member"]
                    if replay_scope:
                        historical_h0 = (isinstance(pin, Mapping)
                                         and pin.get("executor_source_identity")
                                             == "0f469526284d7c20008b183e1a22dff63acaed7050f67b78fc40de7ced920a41"
                                         and pin.get("retained_source_bundle") == {
                                             "sha256": "cb13f910856b951159ca26e85de072a4201f6d823a20bed513af218ad1fe56db",
                                             "size_bytes": 960061,
                                             "manifest_identity_sha256": "93f25df7a8a5d1dab9c34d2035969b020250ea0b1cb18b06db0c49c807ea91d2"})
                        _validate_a12_h0_native_first_replay_report(report, numbers, original,
                            retained_historical_source_proven=historical_h0)
                    effective = _a12_mice_numerical_policy(original, report.get("retained_bytes_limit"),
                        execution_worker_memory_bytes=worker_budget)
                    _require(canonical_json_bytes(report.get("resource_admission")) == canonical_json_bytes(
                        resource_admission(effective, report.get("resource_observation"), legal_tasks=1)),
                        "F5_A12_MICE_PRODUCER_GEOMETRY_INVALID")
                    configured = report["resource_observation"]["effective_cpus"] - 8
                    expected_execution = {"configured_worker_ceiling": configured, "admitted_worker_ceiling": 1,
                        "actual_worker_process_peak": 1, "runnable_task_count": 1, "completed_task_count": 1,
                        "engine_threads": 1, "status": "COMPLETED"}
                    _require(all(canonical_json_bytes(report.get(key)) == canonical_json_bytes(expected_execution)
                                 for key in (("first_audit_execution_report",) if replay_scope
                                             else ("execution_report", "first_audit_execution_report"))),
                             "F5_A12_MICE_PRODUCER_GEOMETRY_INVALID")
                    archive = path.with_suffix("")
                    _require(type(report.get("size_bytes")) is int and archive.is_file() and not archive.is_symlink()
                             and archive.stat().st_size == report["size_bytes"] and sha256_file(archive) == report.get("sha256")
                             and type(report.get("retained_bytes_before_report")) is int
                             and report["retained_bytes_before_report"] >= archive.stat().st_size
                             and report["retained_bytes_before_report"] + len(raw) <= report["retained_bytes_limit"],
                             "F5_A12_MICE_NUMERICAL_SOURCE_MISMATCH")
                    archives[coordinate], numerical_views[name] = archive, numbers
                    reports[name] = {key: item for key, item in report.items() if key != "numerical_view"}
                    if legacy:
                        reports[name]["resource_release"] = {"status": "UNKNOWN", "reason": "LEGACY_REPORT_HAS_NO_DIAGNOSTICS",
                                                              "report_sha256": sha256_bytes(raw)}
                _require(set(archives) == set(expected), "F5_A12_MICE_NUMERICAL_VIEW_COVERAGE_INVALID")
                del raw, report
                execution.update(numerical_gather_resource_admission=admission, view_execution_reports=reports,
                                 mice_chain_execution_count=0, source_mice_chain_count=20 * len(archives))
            else:
                from .nested_loco import _write_exact_once
                _require(type(retained_bytes_per_view) is int and retained_bytes_per_view > 0,
                         "F5_A12_MICE_RETENTION_ESTIMATE_REQUIRED")
                numerical_views = {}
                for row in value["mice_inputs"]:
                    name = f"{row['estimand']}/{row['view_id']}"
                    if name in reused:
                        archives[row["estimand"], row["view_id"]] = reused[name]["path"]
                        numerical_views[name] = reused[name]["numbers"]
                        continue
                    coordinate = source.with_name(source.name + ".mice") / name
                    coordinate.mkdir(mode=0o700, parents=True, exist_ok=True)
                    original = coordinate / "input.zip"
                    _write_exact_once(original, (opened["root"] / row["member"]).read_bytes(), "F45_AAR_MICE_INPUT_DRIFT")
                    path = coordinate / "numerical.zip"
                    complete = path.is_file() and (coordinate / "numerical.zip.json").is_file()
                    if complete or (coordinate / "input.zip.native-work/native-view.zip").is_file():
                        resumed_views.append(name)
                    if complete:
                        resumed_audits.append(name)
                    jobs.append({"name": name, "input": str(original), "target": str(path),
                                 "retained_bytes_per_view": retained_bytes_per_view})
                    archives[row["estimand"], row["view_id"]] = path
                observation = observe_execution_resources(root)
                admission = resource_admission({**value["resource_policy"], "memory_bytes_per_worker": MIN_WORKER_MEMORY_BYTES},
                    observation, legal_tasks=max(1, len(jobs)))
                execution.update(resource_observation=observation, resource_admission=admission, mice_pool={})
                try:
                    if jobs:
                        from .runtime import _ready_ordered
                        _ready_ordered(_execute_a12_total_view_job, jobs,
                            policy=value['resource_policy'], root=root,
                            retained_bytes_per_task=retained_bytes_per_view,
                            retained_bytes_by_task=[min(retained_bytes_per_view, 8 * 1024**2)
                                if Path(job['target']).is_file() else retained_bytes_per_view for job in jobs],
                            transient_bytes_per_worker=3 * retained_bytes_per_view,
                            selected_slots=resolve_pool_workers(None), execution_report=execution["mice_pool"])
                    else:
                        execution["mice_pool"] = {"status": "COMPLETED", "runnable_task_count": 0,
                            "completed_task_count": 0, "actual_worker_process_peak": 0, "engine_threads": 1,
                            "configured_worker_ceiling": admission["limits"]["configured"], "admitted_worker_ceiling": 0}
                finally:
                    (root / "execution.json").write_bytes(canonical_json_bytes(execution))
                for job in jobs:
                    numerical_views[job["name"]] = strict_json_bytes(Path(job["target"] + ".json").read_bytes())["numerical_view"]
            prepared = _materialize_a12_projected_branches(opened, archives, root / "prepared", retain_evidence=True,
                **({"mice_reuse": mice_reuse} if mice_reuse else {}),
                **({"numerical_views": numerical_views} if numerical_views is not None else {}))
            execution["view_replay_reports"] = prepared["view_replay_reports"]
            execution["materialization_resources"] = prepared["materialization_resources"]
            # Native ZIPs and their complete first audits remain on this owner.
            # Transport the original view bytes except RDS, bound to the full
            # first-audit record; do not propagate these large records into Q.
            transport_members = {}
            bounds = []
            for name, numbers in prepared["mice_views"].items():
                members = {member: prepared["root"] / name / member for member in numbers["members"]
                           if not member.startswith("native/")}
                transport_members[name] = members
                bounds.append(2 * sum(numbers["members"][member]["size_bytes"] for member in members)
                              + 4096 + sum(1024 + 4 * len(member.encode()) for member in members))
            reserved = 2 * sum(bounds) + 2 * source.stat().st_size + 64 * 1024**2
            observation = observe_execution_resources(root)
            transport_policy = {**value["resource_policy"],
                "memory_bytes_per_worker": MIN_WORKER_MEMORY_BYTES,
                "scratch_reserve_bytes": 0,
                "memory_reserve_bytes": value["resource_policy"]["memory_reserve_bytes"] + 32 * 32 * 1024**2}
            admission = resource_admission(transport_policy, observation, legal_tasks=1)
            execution["numerical_transport"] = {"reserved_bytes": reserved, "resource_observation": observation,
                "resource_admission": admission, "execution_worker_memory_bytes": MIN_WORKER_MEMORY_BYTES,
                "executor_source_identity": sha256_bytes(canonical_json_bytes(_f45_source_member_sha256()))}
            from .carriers import run_context, write_carrier
            current_run = run_context()
            if view_results is not None or current_run is not None:
                projected_views = {"/".join(coordinate): path for coordinate, path in archives.items()}
            else:
                compact = root / "numerical-views"
                compact.mkdir(mode=0o700)
                projected_views = {}
                for name, members in transport_members.items():
                    path = compact / (name + ".zip")
                    path.parent.mkdir(mode=0o700, exist_ok=True)
                    write_deterministic_zip(path, members, stored_members={"input.zip"})
                    projected_views[name] = path
            body = {**_a12_outer_input_record(prepared), "mice_views": prepared["mice_views"]}
            if mice_reuse:
                body["mice_reuse"] = mice_reuse
                execution["mice_reuse"] = {"logical_chain_count": 20 * len(archives),
                    "new_chain_count": 20 * (len(jobs) - len(resumed_views)),
                    "reused_chain_count": 20 * len(mice_reuse), "resumed_chain_count": 20 * len(resumed_views),
                    "reused_view_count": len(mice_reuse),
                    "reused_native_audit_count": len(mice_reuse) + len(resumed_audits),
                    "new_native_audit_count": len(jobs) - len(resumed_audits),
                    "resumed_view_ids": resumed_views, "resumed_audit_view_ids": resumed_audits}
            completed = {"outer_fold": value["outer_fold"], "family": value["family"],
                         "mice_chain_execution_count": 20 * (len(jobs) - len(resumed_views)),
                         **({"mice_reuse": execution["mice_reuse"]} if mice_reuse else {})}
            # Materialization and merging have finished. The final transport
            # reads only source/projected_views, not these private expansions.
            # Keep the numerical manifest needed by the archive and every file;
            # drop only branch/input objects that this caller no longer uses.
            from .runtime import observe_step_memory, release_step_resources
            owned_files = sorted({path for group in transport_members.values() for path in group.values()
                if path not in {source, *projected_views.values()}})
            disposable = {path: numbers['members'][name]
                for view, numbers in prepared['mice_views'].items()
                for name, path in transport_members[view].items()}
            for branch in prepared['branches'].values():
                for partition in branch['partitions']:
                    disposable.update({Path(partition['covariates']['input_dir']) / member['name']:
                        {key: member[key] for key in ('sha256', 'size_bytes')}
                        for member in partition['covariates']['members']})
                    for role in ('fit_response', 'evaluation_response'):
                        if 'path' in partition.get(role, {}):
                            disposable[Path(partition[role]['path'])] = {
                                key: partition[role][key] for key in ('sha256', 'size_bytes')}
            disposable.update({opened['root'] / name: pin for name, pin in value['members'].items()})
            disposable = {path: pin for path, pin in disposable.items() if path.resolve().is_relative_to(root)}
            _require(not set(owned_files).intersection({source, *projected_views.values()}),
                     "F5_A12_GATHER_RELEASE_HAS_PENDING_CONSUMER")
            before = observe_step_memory()
            del opened, prepared, value, numerical_views, transport_members, members
            execution["resource_release"] = release_step_resources(owned_files,
                owner="AAR_INPUT_GATHER:" + str(completed["outer_fold"]) + ":" + body["projected_input_identity_sha256"],
                before=before, released_references=["projected_input_objects", "merged_branch_objects",
                                                     "transport_member_paths"])
            observation = observe_execution_resources(root)
            post = {"resource_observation": observation}
            execution["numerical_transport"]["after_release"] = post
            post["resource_admission"] = resource_admission(transport_policy, observation, legal_tasks=1)
            (root / "execution.json").write_bytes(canonical_json_bytes(execution))
            members = {"input.zip": source, "execution.json": root / "execution.json",
                       **{f"views/{name}.zip": path for name, path in projected_views.items()}}
            body["members"] = {
                name: {"sha256": sha256_file(path), "size_bytes": path.stat().st_size} for name, path in sorted(members.items())}
            manifest = {**body, "identity_sha256": sha256_bytes(canonical_json_bytes(body))}
            raw = canonical_json_bytes(manifest)
            _require(len(raw) <= 32 * 1024**2, "F5_A12_INPUT_INDEX_TOO_LARGE")
            if current_run is not None:
                external = {name: path for name, path in members.items() if name != 'execution.json'}
                write_carrier(target, {'a12-inputs.json': raw, 'execution.json': members['execution.json']},
                    references=external, run=current_run)
            else:
                write_deterministic_zip(target, {"a12-inputs.json": raw, **members},
                                        stored_members={name for name in members if name.endswith(".zip")})
            _require(target.stat().st_size + sum(path.stat().st_size for path in projected_views.values()) <= reserved,
                     "F5_A12_INPUT_TRANSPORT_ESTIMATE_EXCEEDED")
            with open_carrier(target) as published:
                _require(published.read('a12-inputs.json') == raw, 'F5_A12_INPUT_TRANSPORT_DRIFT')
                for name, pin in body['members'].items():
                    _require(published.getinfo(name).file_size == pin['size_bytes'], 'F5_A12_INPUT_TRANSPORT_DRIFT')
            _retire_a12_member_copies(root, disposable, protected=(source, *projected_views.values()))
        except BaseException as exc:
            (root / "execution.json").write_bytes(canonical_json_bytes(execution))
            exc.add_note(f"F5_A12_INPUT_EXECUTION_EVIDENCE:{root}")
            raise
        return {"status": "COMPUTED_NATIVE_INPUTS", "stage": "MICE_MATERIALIZED_PRE_DEVELOPMENT",
                "stage_acceptance": False, **completed, "model_fit_count": 0, "selector_path_count": 0,
                "execution_report": execution, "identity_sha256": manifest["identity_sha256"],
                "work_evidence_retained": str(root),
                "sha256": sha256_file(target), "size_bytes": target.stat().st_size}
    _require(f2_run_root is not None and outer_fold is not None, "F5_A12_F2_AND_OUTER_REQUIRED")
    raw = source.read_bytes()
    lineage = strict_json_bytes(raw)
    _require(canonical_json_bytes(lineage) == raw, "F5_A12_LINEAGE_NONCANONICAL")
    context = _a12_context(f2_run_root, lineage, f1_runtime_root=f1_runtime_root)
    layout = _a12_outer_layout(context, outer_fold)
    root = target.with_name(target.name + ".work")
    _require(not root.exists() and not root.is_symlink(), "F5_A12_INPUT_WORK_EXISTS")
    root.mkdir(mode=0o700)
    try:
        jobs = []
        for name in layout["view_names"]:
            input_path = root / f"{name}-input.zip"
            write_deterministic_zip(input_path, _a12_total_view_inputs(context, layout, name))
            jobs.append({"name": name, "input": str(input_path), "target": str(root / f"{name}.zip")})
        _bounded_ordered_spawn(_execute_a12_total_view_job, jobs, selected_slots=resolve_pool_workers(workers))
        archives = {name: root / f"{name}.zip" for name in layout["view_names"]}
        prepared = _materialize_a12_outer_inputs(context, outer_fold, archives, root / "prepared")
        members = {f"views/{name}.zip": path for name, path in archives.items()}
        for member in _a12_recipe_archive_members(layout):
            _, partition_id, name = member.split("/")
            members[member] = prepared["root"] / "total-partitions" / partition_id / "recipe-native" / name
        record = _a12_outer_input_record(prepared)
        body = {**record, "members": {name: {"sha256": sha256_file(path), "size_bytes": path.stat().st_size}
                                     for name, path in sorted(members.items())}}
        manifest = {**body, "identity_sha256": sha256_bytes(canonical_json_bytes(body))}
        write_deterministic_zip(target, {"a12-inputs.json": canonical_json_bytes(manifest), **members},
                                stored_members={name for name in members if name.endswith(".zip")})
    except BaseException as exc:
        exc.add_note(f"F5_A12_INPUT_EXECUTION_EVIDENCE:{root}")
        raise
    else:
        shutil.rmtree(root)
    return {"status": "COMPUTED_NATIVE_INPUTS", "stage_acceptance": False,
            "mice_chain_execution_count": 20 * len(layout["view_names"]), "model_fit_count": 0,
            "identity_sha256": manifest["identity_sha256"], "sha256": sha256_file(target), "size_bytes": target.stat().st_size}


def materialize_a12_outer_inputs(source: Path, lineage: Mapping[str, Any] | None, target: Path,
                                 *, f2_run_root: Path | None = None, f1_runtime_root: Path | None = None,
                                 input_bundle: Path | None = None,
                                 retain_evidence: bool = False,
                                 final_task_ids: list[str] | None = None,
                                 retained_primary_source_bundle: Path | None = None,
                                 execution_scratch_reserve_bytes: int | None = 0) -> dict[str, Any]:
    """Production search/refit input consumer; no MICE fitting or model execution."""
    from .f4 import O_FIT_COMPONENT_BYTES
    _require(execution_scratch_reserve_bytes is None
             or type(execution_scratch_reserve_bytes) is int and execution_scratch_reserve_bytes == 0
             and input_bundle is not None, "F5_A12_INPUT_SCRATCH_BUDGET_INVALID")
    _require(retained_primary_source_bundle is None or input_bundle is not None and lineage is None
             and f2_run_root is None and f1_runtime_root is None, "F5_RETAINED_AAR_SOURCE_SCOPE_INVALID")
    _require(final_task_ids is None or input_bundle is not None, "F5_A12_FINAL_BATCH_SCOPE_INVALID")
    _require(source.is_file() and not source.is_symlink() and target.is_absolute() and target.parent.is_dir()
             and not target.exists() and not target.is_symlink(), "F5_A12_INPUT_ARCHIVE_INVALID")
    if input_bundle is not None:
        from .runtime import observe_execution_resources, resource_admission, validate_resource_policy
        _require(lineage is None and f2_run_root is None and f1_runtime_root is None
                 and isinstance(input_bundle, Path) and input_bundle.is_absolute()
                 and input_bundle.is_file() and not input_bundle.is_symlink(), "F5_A12_PROJECTED_INPUT_SOURCE_REQUIRED")
        # Obtain the policy from the independent original input, before even
        # reading the enlarged numerical output index. The full original
        # input consumer below still verifies its scientific/member contents.
        with open_carrier(input_bundle) as archive:
            _require(archive.getinfo("a12-inputs.json").file_size <= 32 * 1024**2, "F5_A12_INPUT_INDEX_TOO_LARGE")
            projected_raw = archive.read("a12-inputs.json")
        projected_index = strict_json_bytes(projected_raw)
        _require(isinstance(projected_index, dict)
                 and projected_index.get("kind") == "PADML_F5_A12_PROJECTED_OUTER_INPUTS_V1"
                 and canonical_json_bytes(projected_index) == projected_raw
                 and projected_index.get("identity_sha256") == sha256_bytes(canonical_json_bytes({
                     key: item for key, item in projected_index.items() if key != "identity_sha256"})),
                 "F5_A12_PROJECTED_INPUT_INVALID")
        policy = validate_resource_policy(projected_index["resource_policy"])
        resource_admission({**policy, "memory_bytes_per_worker": MIN_WORKER_MEMORY_BYTES,
                           "memory_reserve_bytes": policy["memory_reserve_bytes"] + 32 * 32 * 1024**2,
                           **({"scratch_reserve_bytes": execution_scratch_reserve_bytes}
                              if execution_scratch_reserve_bytes is not None else {})},
                           observe_execution_resources(target.parent), legal_tasks=1)
        del projected_index, projected_raw
    with open_carrier(source) as archive:
        _require(archive.getinfo("a12-inputs.json").file_size <= 32 * 1024 * 1024, "F5_A12_INPUT_INDEX_TOO_LARGE")
        raw = archive.read("a12-inputs.json")
    value = strict_json_bytes(raw)
    _require(isinstance(value, dict) and canonical_json_bytes(value) == raw, "F5_A12_INPUT_INDEX_INVALID")
    if value.get("kind") == "PADML_F5_A12_OUTER_INPUTS_NATIVE_V2":
        from .nested_loco import AAR_ESTIMANDS, _aar3_mice_view_restoration_contract
        _require(lineage is None and f2_run_root is None and f1_runtime_root is None
                 and isinstance(input_bundle, Path) and input_bundle.is_absolute()
                 and input_bundle.is_file() and not input_bundle.is_symlink(), "F5_A12_PROJECTED_INPUT_SOURCE_REQUIRED")
        _require(set(value) == {"kind", "family", "outer_fold", "projected_input_identity_sha256", "stage",
                               "branches", "mice_views", "members", "identity_sha256"}
                              | ({"mice_reuse"} if "mice_reuse" in value else set())
                 and isinstance(value["mice_views"], Mapping)
                 and isinstance(value.get("mice_reuse", {}), dict)
                 and set(value.get("mice_reuse", {})) <= set(value["mice_views"])
                 and (not value.get("mice_reuse") or retained_primary_source_bundle is None)
                 and value["stage"] == "MICE_MATERIALIZED_PRE_DEVELOPMENT"
                 and value["identity_sha256"] == sha256_bytes(canonical_json_bytes({key: item for key, item in value.items()
                                                                                  if key != "identity_sha256"})),
                 "F5_A12_INPUT_INDEX_INVALID")
        coordinates = _a12_final_task_coordinates(value["outer_fold"], final_task_ids)
        active = (None if final_task_ids is None else tuple(name for name in AAR_ESTIMANDS
                  if any(branch == name for branch, imp in coordinates.values())))
        target.mkdir(mode=0o700)
        try:
            opened = _load_a12_projected_outer_inputs(input_bundle, target / "input", branches=active,
                execution_scratch_reserve_bytes=execution_scratch_reserve_bytes,
                **({"retained_mice_gather": True} if retained_primary_source_bundle is not None else {}),
                **({"retained_primary_source_bundle": retained_primary_source_bundle}
                   if retained_primary_source_bundle is not None else {}))
            projected = opened["input"]
            names = {"input.zip", "execution.json", *[f"views/{row['estimand']}/{row['view_id']}.zip"
                                                      for row in projected["mice_inputs"]]}
            _require(value["projected_input_identity_sha256"] == projected["identity_sha256"]
                     and value["family"] == projected["family"] and value["outer_fold"] == projected["outer_fold"]
                     and set(value["branches"]) == set(AAR_ESTIMANDS)
                     and set(value["mice_views"]) == {f"{row['estimand']}/{row['view_id']}" for row in projected["mice_inputs"]}
                     and set(value["members"]) == names
                     and value["members"]["input.zip"] == {"sha256": sha256_file(input_bundle), "size_bytes": input_bundle.stat().st_size},
                     "F5_A12_INPUT_ARCHIVE_SOURCE_MISMATCH")
            selected_views = [row for row in projected["mice_inputs"] if active is None or row["estimand"] in active]
            selected_members = None if active is None else {"a12-inputs.json", "execution.json",
                *(f"views/{row['estimand']}/{row['view_id']}.zip" for row in selected_views)}
            expansion = _a12_input_expansion_resources(source, target / "archive", projected["resource_policy"],
                members={"a12-inputs.json", *value["members"]}, max_member_bytes=4 * O_FIT_COMPONENT_BYTES,
                max_total_bytes=(len(names) + 1) * 4 * O_FIT_COMPONENT_BYTES, selected_members=selected_members,
                execution_scratch_reserve_bytes=execution_scratch_reserve_bytes)
            extracted = extract_safe_zip(source, target / "archive", expected_members={
                "a12-inputs.json": {"sha256": sha256_bytes(raw), "size_bytes": len(raw)}, **value["members"]},
                max_member_bytes=4 * O_FIT_COMPONENT_BYTES, max_total_bytes=(len(names) + 1) * 4 * O_FIT_COMPONENT_BYTES,
                selected_members=selected_members)
            execution_raw = (target / "archive/execution.json").read_bytes()
            input_execution = strict_json_bytes(execution_raw)
            _require(isinstance(input_execution, dict) and canonical_json_bytes(input_execution) == execution_raw,
                     "F5_A12_GATHER_EXECUTION_INVALID")
            if value.get("mice_reuse"):
                counts = input_execution.get("mice_reuse", {})
                resumed = counts.get("resumed_view_ids", [])
                audited = counts.get("resumed_audit_view_ids", [])
                current = set(value["mice_views"]) - set(value["mice_reuse"])
                _require(isinstance(resumed, list) and isinstance(audited, list)
                    and len(resumed) == len(set(resumed)) and len(audited) == len(set(audited))
                    and set(audited) <= set(resumed) <= current
                    and counts == {"logical_chain_count": 20 * len(value["mice_views"]),
                        "new_chain_count": 20 * (len(current) - len(resumed)),
                        "reused_chain_count": 20 * len(value["mice_reuse"]),
                        "resumed_chain_count": 20 * len(resumed),
                        "reused_view_count": len(value["mice_reuse"]),
                        "reused_native_audit_count": len(value["mice_reuse"]) + len(audited),
                        "new_native_audit_count": len(current) - len(audited),
                        "resumed_view_ids": resumed, "resumed_audit_view_ids": audited},
                    "F45_AAR_MICE_REUSE_ACCOUNTING_INVALID")
            restoration_evidence = {}
            recovery_contract = _aar3_mice_view_restoration_contract()
            view_bindings = input_execution.get("retained_view_report_bindings", {})
            reports = input_execution.get("view_execution_reports", {})
            complete_pins = _a12_retained_complete_view_report_pins()
            first_replay_record = _a12_h0_native_first_replay_record()
            first_replay_name = first_replay_record["estimand"] + "/" + first_replay_record["view_id"]
            _require(isinstance(view_bindings, dict) and isinstance(reports, dict)
                     and set(view_bindings) <= set(value["mice_views"]), "F5_A12_RETAINED_VIEW_BINDING_INVALID")
            if projected["identity_sha256"] == recovery_contract["original_projected_input"]["identity_sha256"]:
                required_bindings = (set(complete_pins) & set(value["mice_views"])) | {
                    unit["estimand"] + "/" + unit["view_id"] for unit in recovery_contract["atomic_units"]}
                required_bindings |= {first_replay_name} & set(value["mice_views"])
                _require(required_bindings <= set(view_bindings), "F5_A12_RETAINED_VIEW_BINDING_REQUIRED")
            for name, binding in view_bindings.items():
                report = reports.get(name)
                _require(isinstance(binding, dict) and isinstance(report, dict)
                         and set(binding) == {"executor_source_identity", "original_report", "packet_reference"}
                             | ({"retained_source_bundle"} if "retained_source_bundle" in binding else set())
                             | ({"retained_complete_view_delivery"} if "retained_complete_view_delivery" in binding else set())
                             | ({"native_first_replay"} if "native_first_replay" in binding else set()),
                         "F5_A12_RETAINED_VIEW_BINDING_INVALID")
                ref = binding["packet_reference"]
                _require(isinstance(ref, dict) and set(ref) == {"object_key", "sha256", "size_bytes"}
                         and isinstance(ref["object_key"], str) and bool(ref["object_key"])
                         and type(ref["size_bytes"]) is int and ref["size_bytes"] > 0
                         and any({key: row.get(key) for key in ref} == ref
                                 for row in input_execution.get("retained_view_batches", [])),
                         "F5_A12_RETAINED_VIEW_BINDING_INVALID")
                validate_sha256(ref["sha256"], "a12.retained_packet")
                original_report = dict(report)
                legacy = "executor_source_identity" not in report
                if legacy:
                    _require(binding["executor_source_identity"] == "1513ecba963857099c6b99413b8e976393c551a3ec30ed90da1cb14178338bd7"
                             and original_report.pop("resource_release", None) == {"status": "UNKNOWN",
                                 "reason": "LEGACY_REPORT_HAS_NO_DIAGNOSTICS",
                                 "report_sha256": binding["original_report"].get("sha256")},
                             "F5_A12_RETAINED_VIEW_BINDING_INVALID")
                else:
                    _require(report["executor_source_identity"] == binding["executor_source_identity"],
                             "F5_A12_VIEW_EXECUTOR_SOURCE_MISMATCH")
                original_raw = canonical_json_bytes({**original_report, "numerical_view": value["mice_views"][name]})
                _require(binding["original_report"] == {"sha256": sha256_bytes(original_raw), "size_bytes": len(original_raw)}
                         and {"sha256": report.get("sha256"), "size_bytes": report.get("size_bytes")}
                             == value["members"]["views/" + name + ".zip"], "F5_A12_RETAINED_VIEW_REPORT_DRIFT")
                replay_scope = (projected["identity_sha256"] == recovery_contract["original_projected_input"]["identity_sha256"]
                                and name == first_replay_name)
                _require(("native_first_replay" in report) == replay_scope
                         and ("native_first_replay" in binding) == replay_scope,
                         "F5_A12_NATIVE_FIRST_REPLAY_RECORD_REQUIRED")
                if replay_scope:
                    historical_h0 = (binding["executor_source_identity"]
                                     == "0f469526284d7c20008b183e1a22dff63acaed7050f67b78fc40de7ced920a41"
                                     and binding.get("retained_source_bundle") == {
                                         "sha256": "cb13f910856b951159ca26e85de072a4201f6d823a20bed513af218ad1fe56db",
                                         "size_bytes": 960061,
                                         "manifest_identity_sha256": "93f25df7a8a5d1dab9c34d2035969b020250ea0b1cb18b06db0c49c807ea91d2"})
                    _require(not legacy and "mice_restoration" not in report
                             and canonical_json_bytes(binding["native_first_replay"]) == canonical_json_bytes(first_replay_record),
                             "F5_A12_NATIVE_FIRST_REPLAY_RECORD_INVALID")
                    row = next(row for row in projected["mice_inputs"] if row["estimand"] + "/" + row["view_id"] == name)
                    _validate_a12_h0_native_first_replay_report(report, value["mice_views"][name],
                        opened["root"] / row["member"] if active is None or row["estimand"] in active else None,
                        retained_historical_source_proven=historical_h0)
                if binding["executor_source_identity"] == "a1fabe4424b844025db0449126d60dd81dded09a88cd15e2cd7e78b0c154fa9b":
                    _require("mice_restoration" in report and binding.get("retained_source_bundle") == {
                        "sha256": "74effa70e56307e38d5b632acbf49311b8f1bfec3d19753f728ac60e7c9e6f01", "size_bytes": 923320,
                        "manifest_identity_sha256": "4b01ec16df691c155cbd04d1b7a9a27832cd41e0a564276a996fbceba748a644"},
                        "F5_A12_MICE_RESTORATION_RECORD_INVALID")
                if (projected["identity_sha256"] == recovery_contract["original_projected_input"]["identity_sha256"]
                        and name in complete_pins):
                    delivery = binding.get("retained_complete_view_delivery")
                    from .f4 import _f45_source_member_sha256
                    current_delivery_identity = sha256_bytes(canonical_json_bytes(_f45_source_member_sha256()))
                    archived_delivery_identity = "58a0c27a611f6126809e2c26f8d6ed786590da80f8a20acb7c1a7d52228bc83b"
                    zero_counts = {"new_model_fits", "new_stop_fits", "new_mice_chains", "new_mice_fit_invocations",
                                   "new_native_replay_invocations", "new_selector_paths", "new_glmnet_calls"}
                    _require(legacy and binding["original_report"] == complete_pins[name] and isinstance(delivery, dict)
                             and delivery.get("executor_source_identity") in {current_delivery_identity, archived_delivery_identity}
                             and (delivery.get("executor_source_identity") == current_delivery_identity
                                  and "retained_source_bundle" not in binding
                                  or delivery.get("executor_source_identity") == archived_delivery_identity
                                  and binding.get("retained_source_bundle") == {
                                      "sha256": "8621e6e805203d4d0575232eaec3a9afdc27db94ca34b5122eecab796bb08b60",
                                      "size_bytes": 933377,
                                      "manifest_identity_sha256": "6fa2424376844ae030d19beb7c5fb06c067d541783c58a9fe2fda255b57e115f"})
                             and set(delivery) == zero_counts | {"executor_source_identity", "historical_batch_status", "view_ids",
                                                                 "original_report_pins", "resource_release"}
                             and delivery["historical_batch_status"] == "UNKNOWN"
                             and isinstance(delivery["view_ids"], list) and name in delivery["view_ids"]
                             and len(set(delivery["view_ids"])) == len(delivery["view_ids"])
                             and set(delivery["view_ids"]) <= set(complete_pins)
                             and delivery["original_report_pins"] == {key: complete_pins[key] for key in delivery["view_ids"]}
                             and all(type(delivery[key]) is int and delivery[key] == 0 for key in zero_counts),
                             "F5_A12_RETAINED_COMPLETE_VIEW_DELIVERY_REQUIRED")
                    validate_sha256(delivery["executor_source_identity"], "a12.delivery_executor")
                    from .runtime import validate_resource_release
                    validate_resource_release(delivery["resource_release"])
                    release = delivery["resource_release"]
                    _require(release.get("reader_scan_status") == "OBSERVED" and release.get("files")
                             and all(row["status"] in {"ADVISED", "UNSUPPORTED"} and row["error"] is None for row in release["files"])
                             and all(type(release[key]["rss_bytes"]) is int for key in ("before", "after")),
                             "F5_A12_RETAINED_COMPLETE_VIEW_RELEASE_INCOMPLETE")
                    _require(release["owner"] == "AAR_RETAINED_VIEW_DELIVERY:3:"
                             + sha256_bytes(canonical_json_bytes(delivery["view_ids"])), "F5_A12_VIEW_RELEASE_OWNER_MISMATCH")
                    release_files = {str(_a12_mice_restoration_coordinate_root({
                        "original_producer_source_identity": "1513ecba963857099c6b99413b8e976393c551a3ec30ed90da1cb14178338bd7",
                        "estimand": key.split("/")[0], "view_id": key.split("/")[1]}) / ("numerical.zip" + suffix)):
                            (complete_pins[key]["size_bytes"] if suffix else value["members"]["views/" + key + ".zip"]["size_bytes"])
                        for key in delivery["view_ids"] for suffix in ("", ".json")}
                    _require({row["path"]: row["size_bytes"] for row in release["files"]} == release_files,
                             "F5_A12_RETAINED_COMPLETE_VIEW_RELEASE_FILES_INVALID")
            if projected["identity_sha256"] == recovery_contract["original_projected_input"]["identity_sha256"]:
                _require(isinstance(reports, Mapping) and retained_primary_source_bundle is not None,
                         "F5_A12_MICE_RESTORATION_RECORD_REQUIRED")
                for allowed in recovery_contract["atomic_units"]:
                    name = allowed["estimand"] + "/" + allowed["view_id"]
                    report = reports.get(name, {})
                    _require(isinstance(report, Mapping) and "mice_restoration" in report,
                             "F5_A12_MICE_RESTORATION_RECORD_REQUIRED")
                    # All three real once-only restorations are already closed
                    # under a1. Neither this executor nor an arbitrary third
                    # identity may relabel them or reset the exhausted budget.
                    _require(report.get("executor_source_identity")
                             == view_bindings[name]["executor_source_identity"]
                             == "a1fabe4424b844025db0449126d60dd81dded09a88cd15e2cd7e78b0c154fa9b",
                             "F5_A12_MICE_RESTORATION_RETAINED_SOURCE_REQUIRED")
                    from .runtime import validate_resource_release
                    validate_resource_release(report.get("resource_release"))
                    _require(report["resource_release"]["owner"] == "AAR_MICE_VIEW:3:" + name,
                             "F5_A12_VIEW_RELEASE_OWNER_MISMATCH")
                    record = report["mice_restoration"]
                    unit = _validate_a12_mice_restoration_record(record,
                        retained_primary_source_bundle=retained_primary_source_bundle)
                    numbers = value["mice_views"][name]
                    _require(name == unit["estimand"] + "/" + unit["view_id"]
                             and numbers["members"]["input.zip"] == unit["original_input"]
                             and canonical_json_bytes(numbers["spec"]["chain_seeds"]) == canonical_json_bytes(unit["chain_seeds"])
                             and {"sha256": report.get("sha256"), "size_bytes": report.get("size_bytes")}
                                 == value["members"]["views/" + name + ".zip"],
                             "F5_A12_MICE_RESTORATION_ORIGINAL_DRIFT")
                    restoration_evidence[name] = {
                        "science_decision_sha256": record["science_decision"]["identity_sha256"],
                        "record_sha256": sha256_bytes(canonical_json_bytes(record)),
                        "mice_chains": 20, "mice_fit_invocations": 1, "native_archive": numbers["native_archive"]}
            input_release = input_execution.get("resource_release")
            if "resource_release" in input_execution:
                from .runtime import validate_resource_release
                validate_resource_release(input_release)
                _require(input_release["owner"] == "AAR_INPUT_GATHER:" + str(projected["outer_fold"])
                         + ":" + projected["identity_sha256"], "F5_A12_GATHER_RELEASE_OWNER_MISMATCH")
                transport = input_execution.get("numerical_transport", {})
                transport_budget = transport.get("execution_worker_memory_bytes")
                if "executor_source_identity" in transport:
                    # This is the historical gather executor, not this reader.
                    # Its original execution bytes are bound by the archive;
                    # scientific view producers are checked independently above.
                    validate_sha256(transport["executor_source_identity"], "a12.gather_executor")
                    _require(type(transport_budget) is int and transport_budget in RECORDED_WORKER_MEMORY_BYTES,
                             "F5_A12_GATHER_POST_RELEASE_ADMISSION_INVALID")
                else:
                    # Original executor fe21aea376355e15cd72b644aab97c6f
                    # af4945af63ed699623b68ca99d355f11 is independently
                    # bound by the privately returned outer4/outer5/outer6 packets.
                    # Missing fields alone never select historical arithmetic.
                    # All original input/view/kernel checks above still apply.
                    _require("execution_worker_memory_bytes" not in transport
                             and (value["identity_sha256"], source.stat().st_size, sha256_file(source),
                                  sha256_file(input_bundle), len(execution_raw), sha256_bytes(execution_raw)) in {
                                 ("f974194f400c018391b5507a3aa3ede1699f96c139b77a0a845d3d7dd6fca3a5", 339620865,
                                  "995bb522e8eef784b10167a87e9959e7272f17debc514de39c03ae4754e28474",
                                  "41b247105716d4fcb3ba3be3222138efb35bebe1bc36565abc47da8b9169c4de", 4771639,
                                  "f8a4211043f102bd166bd6f5362eed1831d0573fb5b509d89aee8aac7245c426"),
                                 ("1bf4abbbbe2dab27fdb52d2d95e762b7a61817a654afd64ac2c5a8ec27f1c9df", 476875237,
                                  "4ed22cadfedad5848cd3c30525140bfd6f8615652f7e1efbe5ef78a2dfc7d522",
                                  "0d37bd6b216155c9397d401d654aa686681309bb948e5c861c94eb0c9c4f6368", 9232260,
                                  "9ba31df82a0d6e8f8c670c98be117f35bc54f56b80f7ea1306edf06c9255d9bf"),
                                 ("17aa48672117e1cb65019bab308e6875c514bc7509550841ea81ef42a64ea774", 534813564,
                                  "da743a317060a6e10a47965867fd0306d951472a94d3386732e58a7f5b64c8d9",
                                  "47cf4066a54fcb1f738382e03317f18183ce8539644cb7b46bb5a289caafc7bf", 2379022,
                                  "61de02031d004cb1dba5874ba154ae004099237b97d6ebc0c6f25cf9950b2795")},
                             "F5_A12_RETAINED_GATHER_EXECUTION_RECEIPT_REQUIRED")
                _require(type(transport.get("reserved_bytes")) is int and transport["reserved_bytes"] > 0
                         and isinstance(transport.get("after_release"), dict)
                         and set(transport["after_release"]) == {"resource_observation", "resource_admission"},
                         "F5_A12_GATHER_POST_RELEASE_ADMISSION_INVALID")
                post = transport["after_release"]
                policy = projected["resource_policy"]
                _require(canonical_json_bytes(post["resource_admission"]) == canonical_json_bytes(resource_admission({**policy,
                    **({"memory_bytes_per_worker": transport_budget} if transport_budget is not None else {}),
                    "scratch_reserve_bytes": 0,
                    "memory_reserve_bytes": policy["memory_reserve_bytes"] + 32 * 32 * 1024**2},
                    post["resource_observation"], legal_tasks=1)), "F5_A12_GATHER_POST_RELEASE_ADMISSION_INVALID")
            else:
                # Exact completed outer2/1513 gather predates diagnostics.
                # Its absent historical release stays UNKNOWN; current input
                # preparation/release and every numerical check still run.
                _require(retained_primary_source_bundle is not None
                         and projected["outer_fold"] == 2 and projected["family"] == "XGBOOST_COX"
                         and value["identity_sha256"] == "2cac50c2e67f692d2389aef66e7877e2a46624da5a69c1c1dc21cf926ba3e4d1"
                         and source.stat().st_size == 591759073
                         and sha256_file(source) == "4f0a22120dec47b8b781c01d828dc00ba90a4cf96d0b2d50de3af645b927dfb1"
                         and sha256_file(input_bundle) == "5e92d3897161feb2aa13c703a3154866e59e10f508cf61da43893d52e3293801"
                         and len(execution_raw) == 169858
                         and sha256_bytes(execution_raw) == "17db6a2ce4f3a76fd19c210e0b889f17ad4b304312c7ba548291a0a0ab526565",
                         "F5_A12_RETAINED_GATHER_EXECUTION_RECEIPT_REQUIRED")
            prepared = _materialize_a12_projected_branches(opened, {
                (row["estimand"], row["view_id"]): target / "archive" / f"views/{row['estimand']}/{row['view_id']}.zip"
                for row in selected_views}, target / "prepared", retain_evidence=retain_evidence, branches=active,
                execution_scratch_reserve_bytes=execution_scratch_reserve_bytes,
                mice_reuse={name: record for name, record in value.get("mice_reuse", {}).items()
                            if active is None or name.split("/")[0] in active},
                numerical_views={f"{row['estimand']}/{row['view_id']}": value["mice_views"][f"{row['estimand']}/{row['view_id']}"]
                                 for row in selected_views})
            original_record = {key: item for key, item in value.items()
                               if key not in {"mice_views", "mice_reuse", "members", "identity_sha256"}}
            _require(_a12_outer_input_record(prepared) == {**original_record,
                     "branches": {name: value["branches"][name] for name in prepared["branches"]}}
                     and prepared["mice_views"] == {f"{row['estimand']}/{row['view_id']}":
                         value["mice_views"][f"{row['estimand']}/{row['view_id']}"] for row in selected_views},
                     "F5_A12_INPUT_NATIVE_REPLAY_MISMATCH")
            # Keep complete immutable metadata for the original branch source
            # identities; unselected payloads have not been re-read here.
            prepared["source_input_record"] = original_record
            owned = {**opened['owned_members'], **{target / 'archive' / name: pin for name, pin in extracted.items()}}
            for name, numbers in prepared['mice_views'].items():
                owned.update({prepared['root'] / name / member: pin for member, pin in numbers['members'].items()
                    if not member.startswith('native/')})
                if name in value.get('mice_reuse', {}):
                    branch, view = name.split('/', 1)
                    owned[prepared['root'] / branch / (view + '.producer-input.zip')] = {
                        k:value['mice_reuse'][name]['producer_input'][k] for k in ('sha256', 'size_bytes')}
            for branch in prepared['branches'].values():
                for partition in branch['partitions']:
                    cov = partition['covariates']
                    owned.update({Path(cov['input_dir']) / member['name']: {k:member[k] for k in ('sha256', 'size_bytes')}
                        for member in cov['members']})
                    for role in ('fit_response', 'evaluation_response'):
                        response = partition.get(role, {})
                        if 'path' in response:
                            owned[Path(response['path'])] = {k:response[k] for k in ('sha256', 'size_bytes')}
            prepared['owned_members'] = owned
            prepared["input_expansion_resources"] = {"projected": opened["expansion_resources"], "native": expansion}
            prepared["input_resource_release"] = input_release
            if view_bindings:
                prepared["input_retained_view_bindings"] = view_bindings
            if restoration_evidence:
                prepared["input_restoration_evidence"] = {"execution_sha256": sha256_bytes(execution_raw),
                                                          "views": restoration_evidence}
            return prepared
        except BaseException as exc:
            exc.add_note(f"F5_A12_INPUT_REPLAY_EVIDENCE:{target}")
            raise
    _require(input_bundle is None and lineage is not None and f2_run_root is not None,
             "F5_A12_F2_AND_OUTER_REQUIRED")
    context = _a12_context(f2_run_root, lineage, f1_runtime_root=f1_runtime_root)
    layout = _a12_outer_layout(context, value.get("outer_fold"))
    names = {f"views/{name}.zip" for name in layout["view_names"]} | _a12_recipe_archive_members(layout)
    target.mkdir(mode=0o700)
    try:
        # Each native view already has its own tighter member/count limits.
        records = extract_safe_zip(source, target / "archive", expected_members=names | {"a12-inputs.json"},
            max_member_bytes=4 * O_FIT_COMPONENT_BYTES, max_total_bytes=(len(names) + 1) * 4 * O_FIT_COMPONENT_BYTES)
        _require(value.get("source") == context["source"]
                 and value.get("members") == {name: {key: records[name][key] for key in ("sha256", "size_bytes")} for name in names},
                 "F5_A12_INPUT_ARCHIVE_SOURCE_MISMATCH")
        prepared = _materialize_a12_outer_inputs(context, layout["outer_fold"],
            {name: target / "archive/views" / f"{name}.zip" for name in layout["view_names"]}, target / "prepared",
            retain_evidence=retain_evidence)
        body = {**_a12_outer_input_record(prepared), "members": value["members"]}
        _require(value == {**body, "identity_sha256": sha256_bytes(canonical_json_bytes(body))},
                 "F5_A12_INPUT_NATIVE_REPLAY_MISMATCH")
        for member in _a12_recipe_archive_members(layout):
            if member.endswith("/recipe.json"):
                _, partition_id, name = member.split("/")
                _require((target / "archive" / member).read_bytes()
                         == (prepared["root"] / "total-partitions" / partition_id / "recipe-native" / name).read_bytes(),
                         "F5_A12_INPUT_RECIPE_REPLAY_MISMATCH")
        return prepared
    except BaseException as exc:
        exc.add_note(f"F5_A12_INPUT_REPLAY_EVIDENCE:{target}")
        raise


def _a12_no_aar_selector_inputs(prepared: Mapping[str, Any], target: Path) -> tuple[dict, list[dict]]:
    """Project fresh redevelopment M20 to the original training-only selector.

    The final selector path consumes only OUTER analysis patients. Its physical
    matrices are not aliases of the held-out application or full-data branch.
    INNER inputs keep their original training/validation split and STOP is not
    sent to the selector. Native MICE must have been replayed by the caller.
    """
    from . import nested_loco as nested
    from .f2_kernel import _recipe_training_member_bytes, _registered_partition_identity_record

    source = prepared["source"]
    branch = prepared["branches"][nested.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT]
    if ("retained_primary_source_bundle" in prepared and prepared.get("outer_fold") == 3
            and prepared.get("family") == "GBM_COX"
            and source.get("kind") == "PADML_F5_A12_PROJECTED_OUTER_INPUTS_V1"
            and source.get("outer_fold") == 3 and source.get("family") == "GBM_COX"):
        _require(source.get("identity_sha256") ==
                 "6d93ae98e4425805d8fa22e51caabedc527302d3f9ca278852fac1ab8a4ad5e0",
                 "F5_RETAINED_AAR_SELECTOR_DEPENDENCY_DRIFT")
    context = _a12_nested_mice_source({**source["primary_source"], "estimand": nested.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT},
        **({"retained_primary_source_bundle": prepared["retained_primary_source_bundle"],
            # This is the inherited PRIMARY context, not the selector result.
            # The selector program independently binds its actual producer.
            **({"retained_no_aar_selector": True, "retained_no_aar_selector_input": True}
               if prepared.get("outer_fold") == 3
               and prepared.get("family") == "GBM_COX"
               and source.get("kind") == "PADML_F5_A12_PROJECTED_OUTER_INPUTS_V1"
               and source.get("outer_fold") == 3 and source.get("family") == "GBM_COX"
               and source.get("identity_sha256")
                   == "6d93ae98e4425805d8fa22e51caabedc527302d3f9ca278852fac1ab8a4ad5e0"
               else {"retained_primary_context": True})}
           if "retained_primary_source_bundle" in prepared else {}))
    _require(source["kind"] == "PADML_F5_A12_PROJECTED_OUTER_INPUTS_V1"
             and prepared["family"] == source["family"] == source["primary_source"]["primary_development_lock"]["selected_family"]
             and prepared["outer_fold"] == source["outer_fold"] == context["outer_fold"]
             and branch["branch"] == nested.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT
             and branch["selected_parents"] is None and branch["status"] == "MICE_MATERIALIZED_PRE_DEVELOPMENT"
             and branch["inner_count"] == 15 and branch["outer_count"] == 1
             and target.is_absolute() and target.parent.is_dir() and not target.exists(),
             "NESTED_NO_AAR_SELECTOR_INPUT_INVALID")
    original = branch["partitions"]
    records = [_registered_partition_identity_record(row, prediction_only=row["kind"] == "OUTER") for row in original]
    _require(branch["identity"] == sha256_bytes(canonical_json_bytes(records)), "NESTED_NO_AAR_SELECTOR_INPUT_DRIFT")
    inner = sorted((row for row in original if row["kind"] == "INNER"), key=lambda row: (row["repeat"], row["inner_fold"]))
    outer, = [row for row in original if row["kind"] == "OUTER"]
    _require([(row["repeat"], row["inner_fold"]) for row in inner] == [(r, k) for r in range(1, 4) for k in range(1, 6)]
             and outer["fit_ids"] == context["training_ids"] and outer["evaluation_ids"] == context["heldout_ids"],
             "NESTED_NO_AAR_SELECTOR_PARTITION_SCOPE_INVALID")
    training = Path(outer["fit_response"]["path"]).read_bytes()
    nested.validate_training_context(context, training)
    fields, responses = _response_rows(training)
    target.mkdir(mode=0o700)
    columns = [name for name in load_science_authority()["science"]["mice"]["private_handoff"]["columns"]
               if name not in {"AST", "ALT", "AST_ALT"}]
    for part in [*inner, outer]:
        for role, id_key in [("fit_response", "fit_ids"), *([] if part is outer else [("evaluation_response", "evaluation_ids")])]:
            binding = part[role]
            raw = binding["private_bytes"] if role == "evaluation_response" else Path(binding["path"]).read_bytes()
            expected = _write_response_subset(fields, responses, part[id_key], None)
            _require(raw == expected["private_bytes"] and binding["sha256"] == expected["sha256"],
                     "NESTED_NO_AAR_SELECTOR_RESPONSE_SOURCE_DRIFT")
        _require(part is outer or set(part["application_ids"]) <= set(context["training_ids"]),
                 "NESTED_NO_AAR_SELECTOR_HELDOUT_REACHABLE")
        for member, fit in zip(part["covariates"]["members"], part["fit_covariate_members"], strict=True):
            path = Path(part["covariates"]["input_dir"]) / member["name"]
            _require(not path.is_symlink() and sha256_file(path) == member["sha256"] and path.stat().st_size == member["size_bytes"],
                     "NESTED_NO_AAR_SELECTOR_M20_DRIFT")
            with path.open(encoding="utf-8-sig", newline="") as handle:
                reader = csv.DictReader(handle)
                rows = list(reader)
            _require(reader.fieldnames == columns and [row["Patient_ID"] for row in rows] == part["application_ids"]
                     and all(row["Center"] == context["centers_by_patient"][row["Patient_ID"]] for row in rows),
                     "NESTED_NO_AAR_SELECTOR_CHANNEL_OR_PATIENT_DRIFT")
            raw = _recipe_training_member_bytes(path, part["fit_ids"])
            _require(fit == {"name": member["name"], "sha256": sha256_bytes(raw), "size_bytes": len(raw)},
                     "NESTED_NO_AAR_SELECTOR_M20_DRIFT")
            if part is outer:
                (target / member["name"]).write_bytes(raw)
    ids = outer["fit_ids"]
    covariates = {**outer["covariates"], "input_dir": str(target), "members": outer["fit_covariate_members"],
        "application_ids_sha256": sha256_bytes(canonical_json_bytes(ids)),
        "data_identity": sha256_bytes(canonical_json_bytes(outer["fit_covariate_members"]))}
    # application_view_sha256 remains provenance of the original merged input;
    # row/member identities above describe its exact training-only projection.
    final = {key: outer[key] for key in ("partition_id", "repeat", "inner_fold", "fit_ids", "fit_response", "fit_covariate_members")}
    final.update(kind="OUTER_TRAINING", evaluation_ids=ids, application_ids=ids,
        evaluation_ids_sha256=sha256_bytes(canonical_json_bytes(ids)), covariates=covariates)
    return {"source": {"kind": "PADML_NESTED_NO_AAR_SELECTOR_SOURCE_V1", "program_id": nested.PROGRAM_ID,
        "context": context["outer_fold"], "inherited_family": prepared["family"],
        **({"selection_horizon_months": 36} if source["primary_source"]["primary_development_lock"]["selection_horizon_months"] == 36 else {}),
        "primary_development_lock_sha256": source["primary_source"]["primary_development_lock"]["identity_sha256"],
        "training_ids_sha256": context["training_ids_sha256"], "training_response_sha256": context["training_response_sha256"],
        "mice_plan_sha256": sha256_bytes(canonical_json_bytes([
            row for row in source["mice_inputs"] if row["estimand"] == nested.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT]))}}, [
        *[{key: value for key, value in row.items() if key not in {"analysis", "application", "stopping"}} for row in inner], final]


def _a12_selector_reuse_context(prepared: Mapping[str, Any], context: dict, partitions: list[dict],
                               root: Path) -> dict | None:
    """Keep an original whole unit's selector; independently bind this consumer.

    Only a complete, byte-admitted AAR can supply the numerical members. The
    original selector reader still checks all recipes, paths and reductions
    against the current physical M20 inputs after this source projection.
    """
    from . import nested_loco as nested
    from .bundle import validate_relative_path
    from .f5 import _nested_full_selector_partition_records, _nested_selector_numerical_members

    failure = "F45_AAR_SELECTOR_REUSE_DEPENDENCY_DRIFT"
    current = prepared["source"]
    horizon = current["primary_source"]["primary_development_lock"]["selection_horizon_months"]
    portable = _nested_full_selector_partition_records(partitions)
    reference = root / "reuse.json"

    def producer_context(source, development, previous):
        _require(source.get("identity_sha256") == sha256_bytes(canonical_json_bytes({
            key: value for key, value in source.items() if key != "identity_sha256"})), failure)
        original = _a12_nested_mice_source({**source["primary_source"],
            "estimand": nested.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT})
        expected = {"kind": "PADML_NESTED_NO_AAR_SELECTOR_SOURCE_V1", "program_id": nested.PROGRAM_ID,
            "context": original["outer_fold"], "inherited_family": source["family"],
            "primary_development_lock_sha256": source["primary_source"]["primary_development_lock"]["identity_sha256"],
            "training_ids_sha256": original["training_ids_sha256"],
            "training_response_sha256": original["training_response_sha256"],
            "mice_plan_sha256": sha256_bytes(canonical_json_bytes([row for row in source["mice_inputs"]
                if row["estimand"] == nested.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT]))}
        if source["primary_source"]["primary_development_lock"]["selection_horizon_months"] == 36:
            expected["selection_horizon_months"] = 36
        _require(development["source"] == expected
            and development["kind"] == "PADML_NESTED_NO_AAR_SELECTOR_DEVELOPMENT_V1"
            and development["outer_fold"] == source["outer_fold"] == original["outer_fold"]
            and source["family"] == source["primary_source"]["primary_development_lock"]["selected_family"]
            and "common_set_epv_binding" not in development, failure)
        before, after = (value["primary_source"]["science_decision"] for value in (source, current))
        science_matches = before == after
        if not science_matches and nested.compatible_science_decisions(before, after):
            # An unchanged successful 12/20 prefix may keep its original
            # producer. Failures still enter this amendment's real reduction.
            selector = development["selector"]
            epv = nested.validate_epv_resolution(selector["epv_resolution"])
            science_matches = (selector.get("status") == "FEASIBLE"
                and bool(selector.get("selected_parents"))
                and "frequency_policy_sha256" not in epv
                and epv.get("source") is None
                and "coarse_records_sha256" in epv)
        ignored = {"inherited_family", "primary_development_lock_sha256", "mice_plan_sha256"}
        matches = ({k: v for k, v in expected.items() if k not in ignored}
            == {k: v for k, v in context["source"].items() if k not in ignored}
            and science_matches
            and [{k: v for k, v in row.items() if k != "transform_recipe"} for row in previous] == portable)
        return {"source": expected} if matches else None

    if not reference.is_file():
        # Any existing original coordinate, complete or partial, keeps its owner.
        if root.exists():
            return None
        for candidate in prepared.get("completed_aar_units", []):
            owner, receipt = Path(candidate["root"]), candidate["receipt"]
            _require(owner.is_absolute() and owner.is_dir() and not owner.is_symlink()
                and (owner / "unit.json").read_bytes() == canonical_json_bytes(receipt)
                and receipt.get("status") == "COMPLETED" and receipt.get("direct_consumer_completed") is True
                and receipt.get("selection_horizon_months") in {6, 12, 24, 36} - {horizon}
                and owner.name == receipt.get("unit_id")
                    == f"AAR-H{receipt['selection_horizon_months']:02d}-O{prepared['outer_fold']}",
                "F45_AAR_SELECTOR_REUSE_WHOLE_REQUIRED")
            with open_carrier(owner / "result.zip") as archive:
                def read_json(name):
                    _require(archive.getinfo(name).file_size <= 32 * 1024**2, failure)
                    return strict_json_bytes(archive.read(name))
                result = read_json("a12-outer.json")
                _require(result.get("kind") == "PADML_F5_A12_OUTER_NATIVE_V2"
                    and result.get("outer_fold") == prepared["outer_fold"]
                    and result.get("identity_sha256") == sha256_bytes(canonical_json_bytes({
                        k: v for k, v in result.items() if k != "identity_sha256"})), failure)
                prefix = "development/selector/"
                if prefix + "reuse.json" in result["members"]:
                    continue  # The first whole producer remains the owner.
                development = read_json(prefix + "development-input.json")
                previous = read_json(prefix + "partitions.json")
                if producer_context(result["source"], development, previous) is None:
                    continue
                members = {validate_relative_path(name[len(prefix):]): pin
                    for name, pin in result["members"].items() if name.startswith(prefix)}
                total = sum(pin["size_bytes"] for pin in members.values())
                _require(0 < total <= 2 * 1024**3 and shutil.disk_usage(root.parent).free >= 2 * total, failure)
                staged = Path(tempfile.mkdtemp(prefix="a12-selector-reuse-", dir=root.parent))
                for name, pin in members.items():
                    _require(archive.getinfo(prefix + name).file_size == pin["size_bytes"], failure)
                    path = staged / name
                    path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
                    with archive.open(prefix + name) as src, path.open("xb") as dst:
                        shutil.copyfileobj(src, dst)
                    _require(sha256_file(path) == pin["sha256"], failure)
                _require(set(_nested_selector_numerical_members(staged)) == set(members), failure)
                record = {"whole_unit": receipt, "result_archive": receipt["artifacts"]["result.zip"],
                    "producer_source": result["source"], "members": members,
                    "consumer_input_identity_sha256": current["identity_sha256"],
                    "consumer_source": context["source"],
                    "execution": {"logical_selector_paths": development["selector_path_count"],
                        "reused_selector_paths": development["selector_path_count"],
                        "new_selector_paths": 0, "new_glmnet_calls": 0, "new_recipe_fits": 0}}
                nested._write_exact_once(staged / "reuse.json", canonical_json_bytes(record), failure)
                _require(not root.exists() and not root.is_symlink(), failure)
                staged.rename(root)
            break
        if not reference.is_file():
            return None
    _require(not reference.is_symlink() and reference.stat().st_size <= 32 * 1024**2, failure)
    record = strict_json_bytes(reference.read_bytes())
    _require(set(record) == {"whole_unit", "result_archive", "producer_source", "members",
        "consumer_input_identity_sha256", "consumer_source", "execution"}
        and record["consumer_input_identity_sha256"] == current["identity_sha256"]
        and record["consumer_source"] == context["source"], failure)
    receipt, source = record["whole_unit"], record["producer_source"]
    producer_h = source["primary_source"]["primary_development_lock"]["selection_horizon_months"]
    _require(receipt.get("status") == "COMPLETED" and receipt.get("direct_consumer_completed") is True
        and receipt.get("selection_horizon_months") == producer_h and producer_h != horizon
        and receipt.get("unit_id") == f"AAR-H{producer_h:02d}-O{prepared['outer_fold']}"
        and receipt.get("report_horizons_months") == [6, 12, 24, 36]
        and receipt["artifacts"]["result.zip"] == record["result_archive"], failure)
    actual = {name: {"sha256": sha256_file(path), "size_bytes": path.stat().st_size}
        for name, path in _nested_selector_numerical_members(root).items() if name != "reuse.json"}
    _require(actual == record["members"], failure)
    development = strict_json_bytes((root / "development-input.json").read_bytes())
    previous = strict_json_bytes((root / "partitions.json").read_bytes())
    original = producer_context(source, development, previous)
    _require(original is not None and record["execution"] == {
        "logical_selector_paths": development["selector_path_count"],
        "reused_selector_paths": development["selector_path_count"], "new_selector_paths": 0,
        "new_glmnet_calls": 0, "new_recipe_fits": 0}, failure)
    return original


def _a12_no_aar_selector_program(prepared: Mapping[str, Any], root: Path, *, replay: bool,
                                  workers: int | None = None, retain_evidence: bool = False,
                                  prepare_only: bool = False, phase_name: str | None = None,
                                  task_ids: list[str] | None = None, phase_batches: list[Path] | None = None,
                                  batch_root: Path | None = None, retained_bytes_per_task: int | None = None,
                                  preparation_release: dict[str, Any] | None = None,
                                  phase_release: dict[str, Any] | None = None,
                                  q_input_lifecycle: dict[str, Any] | None = None,
                                  execution_scratch_reserve_bytes: int | None = None) -> dict[str, Any]:
    """Original fresh selector and retained replay, conditional on the local family."""
    from .f5 import _nested_selector_program
    from .runtime import observe_execution_resources, resource_admission
    _require(execution_scratch_reserve_bytes is None
             or type(execution_scratch_reserve_bytes) is int and execution_scratch_reserve_bytes == 0,
             "NESTED_SELECTOR_SCRATCH_BUDGET_INVALID")
    _require(workers is None and root.is_absolute() and root.parent.is_dir()
             and root.parent.resolve(strict=True) == root.parent and not root.is_symlink()
             and type(replay) is bool and type(prepare_only) is bool
             and (phase_name is not None or all(value is None for value in (
                 task_ids, phase_batches, batch_root, retained_bytes_per_task)))
             and (root.is_dir() if replay else not root.exists() or root.is_dir()),
             "NESTED_NO_AAR_SELECTOR_PATH_OR_CPU_INVALID")
    _require(preparation_release is None or isinstance(preparation_release, dict) and not preparation_release
             and prepare_only and not replay and phase_name is None and not retain_evidence,
             "NESTED_NO_AAR_SELECTOR_PREPARATION_RELEASE_SCOPE_INVALID")
    phase_operation = phase_name is not None
    _require(not phase_operation and phase_release is None or phase_operation
             and isinstance(phase_release, dict) and not phase_release and not retain_evidence,
             "NESTED_SELECTOR_PHASE_RELEASE_SCOPE_INVALID")
    _require(q_input_lifecycle is None or isinstance(q_input_lifecycle, dict) and not q_input_lifecycle
             and not phase_operation and not prepare_only and not retain_evidence
             and preparation_release is None, "F5_A12_Q_INPUT_LIFECYCLE_SCOPE_INVALID")
    admission = resource_admission({**prepared["source"]["resource_policy"], "memory_bytes_per_worker": MIN_WORKER_MEMORY_BYTES,
                                   **({"scratch_reserve_bytes": execution_scratch_reserve_bytes}
                                      if execution_scratch_reserve_bytes is not None else {})},
                                   observe_execution_resources(root.parent), legal_tasks=320)
    work = Path(tempfile.mkdtemp(prefix="a12-selector-inputs-", dir=root.parent))
    try:
        context, partitions = _a12_no_aar_selector_inputs(prepared, work / "outer-training")
        if not prepare_only and phase_name is None:
            reused = _a12_selector_reuse_context(prepared, context, partitions, root)
            if reused is not None:
                context, replay = reused, True
        from .nested_loco import validate_science_decision, _validate_outer4_common_set_epv_binding
        epv_binding = None
        if "selector_science_decision" in prepared:
            decision = validate_science_decision(prepared["selector_science_decision"])
            epv_binding = {"science_decision_sha256": decision["identity_sha256"],
                           "exception": decision.get("outer4_common_set_epv_exception")}
        elif replay:
            saved = root / "development-input.json"
            _require(saved.is_file() and not saved.is_symlink() and saved.stat().st_size <= 32 * 1024**2,
                     "NESTED_FULL_SELECTOR_DEVELOPMENT_REPLAY_MISMATCH")
            epv_binding = strict_json_bytes(saved.read_bytes()).get("common_set_epv_binding")
        if epv_binding is not None:
            epv_binding = _validate_outer4_common_set_epv_binding(epv_binding,
                selector_source=context["source"], projected_source=prepared["source"])
            _require(not prepare_only and (replay or phase_name is not None)
                     and prepared.get("retained_selector_source_bundle") is not None,
                     "NESTED_OUTER4_COMMON_SETA_EPV_SOURCE_INVALID")
        preserved_replay = False
        if (replay and prepared["outer_fold"] == 3 and prepared["family"] == "GBM_COX"
                and context["source"].get("kind") == "PADML_NESTED_NO_AAR_SELECTOR_SOURCE_V1"
                and context["source"].get("context") == 3 and epv_binding is None
                and "retained_selector_source_bundle" not in prepared
                and "retained_selector_executor_source_bundle" not in prepared):
            coarse_record = root / "coarse" / "execution.json"
            if coarse_record.is_file():
                _require(not coarse_record.is_symlink()
                         and coarse_record.resolve(strict=True) == coarse_record
                         and 0 < coarse_record.stat().st_size <= 1024**2,
                         "NESTED_SELECTOR_PRESERVED_COARSE_INVALID")
                recorded = strict_json_bytes(coarse_record.read_bytes())
                if (isinstance(recorded, list) and len(recorded) == 1
                        and isinstance(recorded[0], dict)
                        and recorded[0].get("kind") == "PADML_AAR_OUTER3_PRESERVED_COARSE_RECOVERY_V1"):
                    from .f4 import _preserved_outer3_coarse_projection_members
                    _preserved_outer3_coarse_projection_members(root)
                    preserved_replay = True
        result = _nested_selector_program(context, partitions, root, rscript=RSCRIPT_EXECUTABLE,
            replay=replay, workers=admission["admitted_worker_ceiling"], retain_evidence=retain_evidence,
            resource_policy=prepared["source"]["resource_policy"],
            **({"retained_aar_source_bundle": prepared.get("retained_selector_source_bundle",
                                                           prepared["retained_primary_source_bundle"])}
               if (replay or epv_binding is not None) and not preserved_replay
               and prepared.get("retained_primary_source_bundle") is not None else {}),
            **({"common_set_epv_binding": epv_binding} if epv_binding is not None else {}),
            **({"retained_selector_executor_source_bundle": prepared["retained_selector_executor_source_bundle"]}
               if "retained_selector_executor_source_bundle" in prepared else {}),
            **({"prepare_only": True} if prepare_only else {}),
            **({"phase_name": phase_name, "task_ids": task_ids, "phase_batches": phase_batches,
                "batch_root": batch_root, "retained_bytes_per_task": retained_bytes_per_task}
               if phase_name is not None else {}),
            **({"phase_release": phase_release} if phase_release is not None else {}),
            **({"q_input_lifecycle": q_input_lifecycle} if q_input_lifecycle is not None else {}))
        if phase_release is not None:
            phase_release["input_lifecycle"]["selector_inputs"] = {"temporary_root": str(work)}
        if q_input_lifecycle is not None:
            q_input_lifecycle["selector_inputs"] = {"temporary_root": str(work)}
        if preparation_release is not None:
            from .runtime import observe_step_memory, release_step_resources
            _require(result.get("status") == "PREPARED_SELECTOR_INPUTS",
                     "NESTED_NO_AAR_SELECTOR_PREPARATION_RELEASE_SCOPE_INVALID")
            # The original selector has finished reading the training projection.
            # Persistent recipes/partitions/validation responses are under root,
            # never under this private work directory, and have future consumers.
            files = sorted(path for path in work.rglob("*") if path.is_file())
            before = observe_step_memory()
            del context, partitions
            preparation_release.update(temporary_root=str(work), resource_release=release_step_resources(files,
                owner="AAR_SELECTOR_PREPARE_INPUTS:" + str(prepared["outer_fold"]) + ":"
                    + prepared["source"]["identity_sha256"], before=before,
                released_references=["selector_input_context", "selector_input_partitions"]))
    except BaseException as exc:
        exc.add_note(f"NESTED_NO_AAR_SELECTOR_INPUT_EVIDENCE:{work}")
        raise
    else:
        # The preparation caller owns the combined success boundary. Keep this
        # input evidence if its later release/admission/reader check fails.
        if not retain_evidence and preparation_release is None and phase_release is None and q_input_lifecycle is None:
            shutil.rmtree(work)
    return result


def _a12_branch_names(prepared: Mapping[str, Any]) -> tuple[str, ...]:
    from .nested_loco import AAR_ESTIMANDS
    source = prepared["source"]
    return AAR_ESTIMANDS if isinstance(source, Mapping) and source.get("kind") == "PADML_F5_A12_PROJECTED_OUTER_INPUTS_V1" else A12_BRANCHES[1:]


def _a12_validate_nonestimable_branch(value: Mapping[str, Any], *, source=None, members=None) -> dict:
    """Only a fully exhausted, healthy six-tier selector can omit AAR refits."""
    from . import nested_loco as nested
    failure = "F5_A12_NONESTIMABLE_BRANCH_INVALID"
    fields = {"kind", "branch", "status", "reason_code", "outer_fold", "source_identity_sha256",
        "source_input_identity_sha256", "selector_development_sha256", "selector_members", "epv_resolution"}
    _require(isinstance(value, Mapping) and set(value) == fields | {"identity_sha256"}
        and value.get("kind") == "PADML_F5_A12_NONESTIMABLE_BRANCH_V1"
        and value.get("branch") == nested.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT
        and value.get("status") == "NOT_ESTIMABLE" and value.get("reason_code") == "FREQUENCY_LADDER_EXHAUSTED"
        and type(value.get("outer_fold")) is int and value["outer_fold"] in range(1, 7)
        and nested._sealed({key: item for key, item in value.items() if key != "identity_sha256"}) == value, failure)
    epv = nested.validate_epv_resolution(value["epv_resolution"])
    _require(epv.get("status") == "NOT_ESTIMABLE" and "frequency_policy_sha256" in epv
        and epv.get("reason_code") == "FREQUENCY_LADDER_EXHAUSTED", failure)
    for name in ("source_identity_sha256", "source_input_identity_sha256", "selector_development_sha256"):
        validate_sha256(value[name], failure)
    proof = value["selector_members"]
    _require(isinstance(proof, Mapping) and set(proof) == {
        "development-input.json", "selector.json", "coarse/paths.json"}, failure)
    for name, pin in proof.items():
        _require(isinstance(pin, Mapping) and set(pin) == {"sha256", "size_bytes"}
            and type(pin["size_bytes"]) is int and pin["size_bytes"] > 0, failure)
        validate_sha256(pin["sha256"], failure)
        if members is not None:
            _require(members.get("development/selector/" + name) == pin, failure)
    _require(proof["coarse/paths.json"]["sha256"] == epv["coarse_records_sha256"], failure)
    if source is not None:
        _require(source.get("kind") == "PADML_F5_A12_PROJECTED_OUTER_INPUTS_V1"
            and source["identity_sha256"] == value["source_identity_sha256"]
            and source["outer_fold"] == value["outer_fold"], failure)
    return dict(value)


def _a12_estimable_branches(prepared: Mapping[str, Any]) -> tuple[str, ...]:
    """Keep the original branch domain unless the pinned terminal proof is present."""
    from . import nested_loco as nested
    branches = _a12_branch_names(prepared)
    if "estimability" not in prepared:
        return branches
    _require(branches == nested.AAR_ESTIMANDS and isinstance(prepared["estimability"], Mapping)
        and set(prepared["estimability"]) == {nested.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT},
        "F5_A12_NONESTIMABLE_BRANCH_INVALID")
    _a12_validate_nonestimable_branch(prepared["estimability"][nested.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT],
        source=prepared["source"], members=prepared.get("members"))
    return nested.AAR_ESTIMANDS[:2]


def _a12_aggregate_estimability(value: Mapping[str, Any] | None) -> dict:
    """No patient deletion or partial-outer estimate for the missing third branch."""
    from . import nested_loco as nested
    if value is None:
        return {}
    branch = nested.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT
    failure = "F5_A12_NONESTIMABLE_BRANCH_INVALID"
    _require(isinstance(value, Mapping) and set(value) == {branch}, failure)
    row = value[branch]
    _require(isinstance(row, Mapping) and set(row) == {"status", "reason_code", "unavailable_outers"}
        and row["status"] == "NOT_ESTIMABLE" and row["reason_code"] == "FREQUENCY_LADDER_EXHAUSTED"
        and isinstance(row["unavailable_outers"], list) and 1 <= len(row["unavailable_outers"]) <= 6, failure)
    outer_ids = []
    for proof in row["unavailable_outers"]:
        _require(isinstance(proof, Mapping) and set(proof) == {"outer_fold", "native_outer_identity_sha256", "selector"}, failure)
        validate_sha256(proof["native_outer_identity_sha256"], failure)
        checked = _a12_validate_nonestimable_branch(proof["selector"])
        _require(type(proof["outer_fold"]) is int and proof["outer_fold"] == checked["outer_fold"], failure)
        outer_ids.append(proof["outer_fold"])
    _require(outer_ids == sorted(set(outer_ids)), failure)
    return dict(value)


def _a12_evaluation_estimability(handoff: Mapping[str, Any]) -> dict:
    """The optional proof travels with fixed predictions, never as a metric kwarg."""
    proof = _a12_aggregate_estimability(handoff.get("estimability"))
    return {"estimability": proof} if proof else {}


def _validate_a12_search_source(source: Mapping[str, Any], *, family: str, outer: int,
                                retained_primary_source_bundle: Path | None = None,
                                retained_primary_context: bool = False) -> None:
    """Keep legacy searches distinct from locally inherited three-branch searches."""
    from . import nested_loco as nested
    _require(retained_primary_source_bundle is None and not retained_primary_context,
        "OLD_F45_PRODUCER_NOT_ALLOWED_IN_REBUILD")
    _require(source["family"] == family and type(outer) is int and outer in range(1, 7)
             and source["outer_fold"] == outer and source["branch"] in _a12_branch_names(source),
             "F5_A12_SEARCH_SOURCE_INVALID")
    if source["branch"] in nested.AAR_ESTIMANDS:
        projected = source["source"]
        context = _a12_nested_mice_source({**projected["primary_source"], "estimand": nested.A12_TOTAL_AAR},
            **({"retained_primary_source_bundle": retained_primary_source_bundle}
               if retained_primary_source_bundle is not None else {}),
            **({"retained_primary_context": True} if retained_primary_context else {}))
        _require(projected["family"] == projected["primary_source"]["primary_development_lock"]["selected_family"] == family
                 and projected["outer_fold"] == context["outer_fold"] == outer
                 and projected["identity_sha256"] == sha256_bytes(canonical_json_bytes(
                     {key: value for key, value in projected.items() if key != "identity_sha256"}))
                 and all(isinstance(source.get(key), str) and re.fullmatch(r"[0-9a-f]{64}", source[key])
                         for key in ("inputs_identity_sha256", "development_input_sha256")),
                 "F5_A12_SEARCH_DEVELOPMENT_SOURCE_INVALID")

        epv = nested.validate_epv_resolution(source["epv_resolution"])
        events, df = source["outer_training_event_count"], source["common_set_design_df"]
        _require(type(df) is int and df > 0 and events == context["training_event_count"]
            and events >= epv["minimum"] * df, "F5_A12_OUTER_SETA_EPV_INVALID")
        if source["branch"] == nested.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT:
            _require("coarse_records_sha256" in epv, "F5_A12_SEARCH_DEVELOPMENT_SOURCE_INVALID")
        else:
            _require(epv.get("source") == "FIXED_PRIMARY_NON_AAR_SETA"
                and epv["primary_development_lock_sha256"] == projected["primary_source"]["primary_development_lock"]["identity_sha256"]
                and epv["training_event_count"] == events and epv["common_set_design_df"] == df,
                "F5_A12_SEARCH_DEVELOPMENT_SOURCE_INVALID")


def _a12_search_source(prepared: Mapping[str, Any], branch: str) -> dict[str, Any]:
    from .nested_loco import WITHIN_FAMILY_NO_AAR_REDEVELOPMENT
    record = (_a12_outer_input_record(prepared, branch=branch) if "branch_development" in prepared else
              prepared["source_input_record"] if "source_input_record" in prepared else _a12_outer_input_record(prepared))
    source = {"source": prepared["source"], "family": prepared["family"], "outer_fold": prepared["outer_fold"],
              "branch": branch, "inputs_identity_sha256": sha256_bytes(canonical_json_bytes(record))}
    if "branch_development" in prepared:
        source["development_input_sha256"] = prepared["branch_development"][branch]["identity_sha256"]
        development = prepared["branch_development"][branch]
        source.update(epv_resolution=development["epv_resolution"],
            common_set_design_df=development["common_set_design_df"],
            outer_training_event_count=development["outer_training_event_count"])
    _validate_a12_search_source(source, family=prepared["family"], outer=prepared["outer_fold"],
        **({"retained_primary_source_bundle": prepared["retained_primary_source_bundle"]}
           if "retained_primary_source_bundle" in prepared else {}),
        **({"retained_primary_context": True} if (prepared["family"] == "GBM_COX"
           or source.get("common_set_epv_binding") is not None
           or (prepared["outer_fold"], prepared["family"]) in {(2, "XGBOOST_COX"), (6, "COXTIME_SET_A")}
               and branch == WITHIN_FAMILY_NO_AAR_REDEVELOPMENT)
           and "retained_primary_source_bundle" in prepared else {}))
    return source


def _a12_branch_search_inputs(prepared: Mapping[str, Any], branch: str) -> dict[str, Any]:
    """Pass each branch's own SetA/recipes into the unchanged family search."""
    _require(branch in _a12_branch_names(prepared), "F5_A12_SEARCH_BRANCH_INVALID")
    if "branch_development" not in prepared:
        _require(branch in A12_BRANCHES[1:] and "common_set_epv_binding" not in prepared,
                 "F5_A12_BRANCH_DEVELOPMENT_REQUIRED")
        return dict(prepared)
    _require(branch in prepared["branch_development"], "F5_A12_BRANCH_DEVELOPMENT_REQUIRED")
    development = prepared["branch_development"][branch]
    from .nested_loco import validate_epv_resolution
    epv = validate_epv_resolution(development["epv_resolution"])
    registered = prepared["branches"][branch]
    _require(development["branch"] == branch
             and registered.get("status") == "DEVELOPMENT_INPUTS_MATERIALIZED"
             and development["identity_sha256"] == sha256_bytes(canonical_json_bytes(
                 {key: value for key, value in development.items() if key != "identity_sha256"}))
             and development["source_input_identity_sha256"] == sha256_bytes(canonical_json_bytes(
                 _a12_outer_input_record(prepared, branch=branch)))
             and registered["selected_parents"] == development["selected_parents"]
             and registered["recipes"] == development["recipes"], "F5_A12_BRANCH_DEVELOPMENT_MISMATCH")
    view_count = 2 * len(registered["partitions"])
    _require("view_count" not in registered or type(registered["view_count"]) is int
             and registered["view_count"] == view_count, "F5_A12_BRANCH_VIEW_COUNT_MISMATCH")
    return {**prepared, "selected_parents": development["selected_parents"],
        # The retained development state is not the F2 registered-input ABI.
        # Project its complete analysis/application view count before the
        # engine selects individual partitions; that subset is not the denominator.
        "branches": {**prepared["branches"], branch: {**registered, "status": "PASS", "view_count": view_count}},
        "common_set_design_df": development["common_set_design_df"],
        "epv_resolution": epv,
        "outer_training_event_count": prepared["source"]["outer_training_event_count"],
        "heldout_center": prepared["source"]["primary_source"]["primary_training_context"]["heldout_center"]}


def _a12_development_reuse_sources(prepared):
    """Read this run's completed whole AARs, preserving their original index."""
    from .f5 import _f45_score_reuse_authorities
    from .nested_loco import _sealed
    from .bundle import _validated_zip_infos, validate_relative_path
    failure = "F45_AAR_DEVELOPMENT_REUSE_SOURCE_INVALID"
    candidates = prepared.get("completed_aar_units", [])
    authorities = _f45_score_reuse_authorities() if candidates else None
    for candidate in candidates:
        _require(isinstance(candidate, Mapping) and set(candidate) == {"root", "receipt"}, failure)
        owner, receipt = Path(candidate["root"]), candidate["receipt"]
        _require(owner.is_absolute() and owner.resolve(strict=True) == owner
            and (owner / "unit.json").read_bytes() == canonical_json_bytes(receipt), failure)
        for name, pin in receipt["artifacts"].items():
            path = owner / validate_relative_path(name)
            _require(path.is_file() and path.resolve(strict=True) == path
                and {"sha256": sha256_file(path), "size_bytes": path.stat().st_size} == pin, failure)
        with open_carrier(owner / "result.zip") as archive:
            _validated_zip_infos(archive, None, max_member_bytes=8 * 1024**3,
                max_total_bytes=512 * 1024**3, max_compression_ratio=10000)
            def read(name):
                _require(0 < archive.getinfo(name).file_size <= 32 * 1024**2, failure)
                raw = archive.read(name)
                value = strict_json_bytes(raw)
                _require(canonical_json_bytes(value) == raw, failure)
                return value
            result = read("a12-outer.json")
            if result["family"] != prepared["family"]:
                continue
            proof = _sealed({"kind": "PADML_F45_AAR_FINAL_REUSE_SOURCE_V1", "whole_unit": receipt,
                "result_metadata": result, "execution": read("execution.json")})
            _require(owner.name == _a12_final_reuse_source(proof, prepared["source"], authorities), failure)
            yield archive, proof


def _a12_recipe_reuse(prepared, branch, partitions, selected, directory, predictors, *, replay):
    """Retain first TOTAL recipe bytes; the original M20 recipe reader consumes them."""
    from . import nested_loco as nested
    from .f5 import _f45_retain_final_object, _f45_score_reuse_authorities, _replay_partition_design_recipe
    from .runtime import observe_execution_resources, resource_admission
    failure = "F45_AAR_RECIPE_REUSE_INVALID"
    _require(branch == nested.A12_TOTAL_AAR and prepared["family"] in {
        "COX_PH", "ELASTIC_NET_COX", "FPM_TVC_SET_A"}, failure)
    names = ("spec.json", "recipe.json", "stdout.log", "stderr.log")
    by_id = {row["partition_id"]: row for row in partitions}
    found, pending = set(), {}
    sources = {}

    def original_source(unit, pin):
        key = (unit, pin["sha256"], pin["size_bytes"])
        if key not in sources:
            _require(unit in {f"AAR-H{h:02d}-O{prepared['outer_fold']}" for h in (6, 12, 24, 36)}, failure)
            path = directory / "reuse-sources" / (unit + ".json")
            _require(path.is_file() and path.resolve(strict=True) == path
                and 0 < path.stat().st_size == pin["size_bytes"] <= 32 * 1024**2
                and sha256_file(path) == pin["sha256"], failure)
            raw = path.read_bytes()
            proof = strict_json_bytes(raw)
            _require(canonical_json_bytes(proof) == raw
                and _a12_final_reuse_source(proof, prepared["source"], _f45_score_reuse_authorities()) == unit
                and proof["result_metadata"]["source"]["fixed_selected_parents"] == selected, failure)
            sources[key] = proof
        return sources[key]

    def consume(partition, binding):
        pid = partition["partition_id"]
        _require(set(binding) == {"kind", "unit", "source", "consumer_source", "partition_id", "selected_parents", "members"}
            and binding["kind"] == "PADML_F45_AAR_TOTAL_RECIPE_REUSE_V1"
            and binding["consumer_source"] == prepared["source"]["identity_sha256"]
            and binding["partition_id"] == pid and binding["selected_parents"] == selected
            and set(binding["members"]) == set(names), failure)
        proof = original_source(binding["unit"], binding["source"])
        prefix = f"development/recipes/{branch}/{pid}/"
        _require(prefix + "reuse.json" not in proof["result_metadata"]["members"]
            and binding["members"] == {name: proof["result_metadata"]["members"][prefix + name] for name in names}, failure)
        if not all((directory / pid / name).is_file() for name in names):
            return False
        for name, pin in binding["members"].items():
            path = directory / pid / name
            _require(path.resolve(strict=True) == path
                and {"sha256": sha256_file(path), "size_bytes": path.stat().st_size} == pin, failure)
        _replay_partition_design_recipe(partition, directory / pid, predictors)
        return True

    for pid, partition in by_id.items():
        reference = directory / pid / "reuse.json"
        if reference.exists():
            _require(reference.is_file() and reference.resolve(strict=True) == reference
                and 0 < reference.stat().st_size <= 1024**2, failure)
            raw = reference.read_bytes()
            binding = strict_json_bytes(raw)
            _require(canonical_json_bytes(binding) == raw, failure)
            if consume(partition, binding):
                found.add(pid)
            else:
                pending[pid] = binding
    _require(not replay or not pending, "F45_AAR_RECIPE_REUSE_PENDING_ORIGINAL_REQUIRED")
    wanted = {pid for pid in by_id if pid in pending or not (directory / pid).exists()}
    if not replay and wanted:
        for archive, proof in _a12_development_reuse_sources(prepared):
            result, unit = proof["result_metadata"], proof["whole_unit"]["unit_id"]
            if result["source"]["fixed_selected_parents"] != selected:
                continue
            source_raw = canonical_json_bytes(proof)
            source_pin = {"sha256": sha256_bytes(source_raw), "size_bytes": len(source_raw)}
            for pid in sorted(wanted - found):
                partition = by_id[pid]
                prefix = f"development/recipes/{branch}/{pid}/"
                if prefix + "reuse.json" in result["members"] or not all(prefix + name in result["members"] for name in names):
                    continue
                pins = {name: result["members"][prefix + name] for name in names}
                _require(all(0 <= pin["size_bytes"] <= 32 * 1024**2
                    and archive.getinfo(prefix + name).file_size == pin["size_bytes"] for name, pin in pins.items()), failure)
                raw = archive.read(prefix + "spec.json")
                _require(sha256_bytes(raw) == pins["spec.json"]["sha256"], failure)
                spec = strict_json_bytes(raw)
                _require(spec.get("action") == "COMPILE_A12_RECIPE", failure)
                projection = spec["projection"]
                registry = projection["recipe_registry_record"]
                fit_sha = nested._sha(partition["fit_ids"])
                expected_registry = {**predictors["transform_registry"], "rows": [row for row in
                    predictors["transform_registry"]["rows"] if row["parent"] != "eGFR_calc"]}
                if not (projection["partition_id"] == pid and projection["fit_ids_sha256"] == fit_sha
                    and projection["analysis_ids_sha256"] == fit_sha
                    and projection["analysis_view_sha256"] == partition["covariates"]["analysis_view_sha256"]
                    and registry["fit_ids"] == partition["fit_ids"]
                    and registry["members"] == partition["fit_covariate_members"]
                    and registry["registry"] == expected_registry and registry["conflict_map"] == predictors["conflict_map"]):
                    continue
                binding = {"kind": "PADML_F45_AAR_TOTAL_RECIPE_REUSE_V1", "unit": unit, "source": source_pin,
                    "consumer_source": prepared["source"]["identity_sha256"], "partition_id": pid,
                    "selected_parents": selected, "members": pins}
                if pid in pending and binding != pending[pid]:
                    continue
                observation = observe_execution_resources(directory)
                resource_admission({**prepared["source"]["resource_policy"], "memory_bytes_per_worker": MIN_WORKER_MEMORY_BYTES,
                    "scratch_reserve_bytes": 0}, observation, legal_tasks=1)
                _require(observation["scratch_available_bytes"] >= 2 * (len(source_raw) + sum(p["size_bytes"] for p in pins.values())), failure)
                source_root = directory / "reuse-sources"
                source_root.mkdir(mode=0o700, exist_ok=True)
                _f45_retain_final_object(io.BytesIO(source_raw), source_root / (unit + ".json"), source_pin)
                destination = directory / pid
                destination.mkdir(mode=0o700, exist_ok=True)
                nested._write_exact_once(destination / "reuse.json", canonical_json_bytes(binding), failure)
                for name, pin in pins.items():
                    with archive.open(prefix + name) as stream:
                        _f45_retain_final_object(stream, destination / name, pin)
                _require(consume(partition, binding), failure)
                found.add(pid)
            if found >= wanted:
                break
    _require(set(pending) <= found, "F45_AAR_RECIPE_REUSE_PENDING_ORIGINAL_REQUIRED")
    return found


def _a12_projected_development_inputs(prepared: Mapping[str, Any], root: Path, *, replay: bool,
                                       retain_evidence: bool = False, branch: str | None = None,
                                       selector_root: Path | None = None,
                                       q_input_lifecycle: dict[str, Any] | None = None) -> dict[str, Any]:
    """Original A12 recipe owner, with one fresh conditional selector upstream.

    Direct reuses primary recipes; total consumes its exact M20 recipe values;
    redevelopment reuses its newly replayed selector recipes. No family is
    selected here, and none of these inputs is a final-model task or lock.
    """
    from . import nested_loco as nested
    from .f2_kernel import _recipe_by_partition, predictor_contract, _expected_family_parent_column_map, _registered_partition_identity_record
    from .f5 import _compile_partition_design_recipe, _validate_final_design_recipe, _nested_selector_numerical_members

    if not replay and branch is not None and (root / f"{branch}.json").is_file():
        previous = dict(prepared.get("branch_development", {}))
        restored = _a12_projected_development_inputs(prepared, root, replay=True, branch=branch,
            retain_evidence=retain_evidence, q_input_lifecycle=q_input_lifecycle)
        merged = {**previous, **restored["branch_development"]}
        if set(merged) == set(nested.AAR_ESTIMANDS):
            nested._write_exact_once(root / "development.json", canonical_json_bytes(merged), "F5_A12_BRANCH_DEVELOPMENT_REPLAY_MISMATCH")
        return {**restored, "branch_development": merged}
    source, family = prepared["source"], prepared["family"]
    # The projected source is independently sealed by materialization. This
    # read-only primary-context route precedes selector replay; only the exact
    # approved selector binding below can make a low-EPV development eligible.
    outer4_redevelopment = ((prepared["outer_fold"], family) == (4, "RSF")
        and (branch == nested.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT or replay and branch is None)
        and source.get("identity_sha256") == "1204c950c4f61b4a30ae3302825cad8720c77bd9c5daff68159c7eaaad88f9af"
        and sha256_bytes(canonical_json_bytes({key: value for key, value in source.items()
                if key != "identity_sha256"})) == source["identity_sha256"])
    context = _a12_nested_mice_source({**source["primary_source"], "estimand": nested.A12_TOTAL_AAR},
        **({"retained_primary_source_bundle": prepared["retained_primary_source_bundle"]}
           if "retained_primary_source_bundle" in prepared else {}),
        **({"retained_primary_context": True} if (family == "GBM_COX" or outer4_redevelopment
           or (prepared["outer_fold"], family) in {(2, "XGBOOST_COX"), (6, "COXTIME_SET_A")}
               and branch == nested.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT)
           and "retained_primary_source_bundle" in prepared else {}))
    active = nested.AAR_ESTIMANDS if branch is None else (branch,)
    previous = prepared.get("branch_development", {}) if branch is not None and not replay else {}
    _require(source["kind"] == "PADML_F5_A12_PROJECTED_OUTER_INPUTS_V1"
             and family == source["family"] == source["primary_source"]["primary_development_lock"]["selected_family"]
             and (set(prepared["branches"]) == set(nested.AAR_ESTIMANDS)
                  or branch is not None and set(active) <= set(prepared["branches"]) <= set(nested.AAR_ESTIMANDS))
             and set(active) <= set(nested.AAR_ESTIMANDS)
             and set(previous) < set(nested.AAR_ESTIMANDS) and not set(active).intersection(previous)
             and root.is_absolute() and root.parent.is_dir() and not root.is_symlink()
             and type(replay) is bool and (root.is_dir() if replay else not root.exists() or root.is_dir()),
             "F5_A12_BRANCH_DEVELOPMENT_INPUT_INVALID")
    _require(selector_root is None or not replay and nested.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT in active,
             "F5_A12_SELECTOR_RESULT_SCOPE_INVALID")
    _require(q_input_lifecycle is None or isinstance(q_input_lifecycle, dict) and not q_input_lifecycle
             and not retain_evidence and (replay or nested.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT in active),
             "F5_A12_Q_INPUT_LIFECYCLE_SCOPE_INVALID")
    original_record = prepared.get("source_input_record") or _a12_outer_input_record(prepared)
    _require(all(branch["identity"] == sha256_bytes(canonical_json_bytes(branch["partitions"]))
                 for branch in original_record["branches"].values()), "F5_A12_BRANCH_PARTITION_IDENTITY_INVALID")
    for name, value in previous.items():
        _require((root / f"{name}.json").read_bytes() == canonical_json_bytes(value),
                 "F5_A12_BRANCH_DEVELOPMENT_REPLAY_MISMATCH")
    if not replay and not previous:
        root.mkdir(mode=0o700, exist_ok=True)
    work = Path(tempfile.mkdtemp(prefix="a12-development-replay-", dir=root.parent)) if replay else root
    try:
        selector = (_a12_no_aar_selector_program(prepared, selector_root or root / "selector",
                    replay=replay or selector_root is not None or (root / "selector/development-input.json").is_file(), retain_evidence=retain_evidence,
                    **({"q_input_lifecycle": q_input_lifecycle} if q_input_lifecycle is not None else {}))
                    if nested.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT in active else None)
        if selector_root is not None:
            from .runtime import observe_execution_resources, resource_admission
            destination = root / "selector"
            _require(not destination.exists() and not destination.is_symlink(), "F5_A12_SELECTOR_RESULT_CONFLICT")
            members = _nested_selector_numerical_members(selector_root)
            resource_admission({**source["resource_policy"],
                "memory_bytes_per_worker": MIN_WORKER_MEMORY_BYTES,
                "scratch_reserve_bytes": source["resource_policy"]["scratch_reserve_bytes"]
                    + sum(path.stat().st_size for path in members.values())},
                observe_execution_resources(root), legal_tasks=1)
            for name, path in members.items():
                target = destination / name
                target.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
                shutil.copyfile(path, target)
        predictors = predictor_contract(Path(__file__).parent)
        transformed = family in {"COX_PH", "ELASTIC_NET_COX", "FPM_TVC_SET_A"}
        branches, developments = dict(prepared["branches"]), dict(previous)
        recipes_root = work / "recipes"
        recipes_root.mkdir(mode=0o700, exist_ok=True)
        for branch in active:
            registered = prepared["branches"][branch]
            selected = (selector["selector"]["selected_parents"] if branch == nested.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT
                        else source["fixed_selected_parents"])
            if branch == nested.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT and selector["selector"].get("status") == "NOT_ESTIMABLE":
                epv = nested.validate_epv_resolution(selector["selector"]["epv_resolution"])
                _require(not selected and epv.get("status") == "NOT_ESTIMABLE",
                         "F5_A12_NONESTIMABLE_BRANCH_INVALID")
                selector_members = _nested_selector_numerical_members(root / "selector")
                proof = nested._sealed({"kind": "PADML_F5_A12_NONESTIMABLE_BRANCH_V1",
                    "branch": branch, "status": "NOT_ESTIMABLE", "reason_code": "FREQUENCY_LADDER_EXHAUSTED",
                    "outer_fold": prepared["outer_fold"], "source_identity_sha256": source["identity_sha256"],
                    "source_input_identity_sha256": sha256_bytes(canonical_json_bytes(
                        _a12_outer_input_record({**prepared, "source_input_record": original_record}, branch=branch))),
                    "selector_development_sha256": selector["identity_sha256"], "epv_resolution": epv,
                    "selector_members": {name: {"sha256": sha256_file(selector_members[name]),
                        "size_bytes": selector_members[name].stat().st_size}
                        for name in ("development-input.json", "selector.json", "coarse/paths.json")}})
                _a12_validate_nonestimable_branch(proof, source=source)
                branch_raw = canonical_json_bytes(proof)
                if replay:
                    _require((root / f"{branch}.json").read_bytes() == branch_raw,
                             "F5_A12_BRANCH_DEVELOPMENT_REPLAY_MISMATCH")
                else:
                    nested._write_exact_once(root / f"{branch}.json", branch_raw,
                                             "F5_A12_BRANCH_DEVELOPMENT_REPLAY_MISMATCH")
                developments[branch] = proof
                branches[branch] = {**registered, "status": "NOT_ESTIMABLE", "selected_parents": [], "recipes": {},
                    "diagnostic_count": 0, "diagnostic_partitions": []}
                continue
            _require(selected and selected == sorted(set(selected), key=lambda name: name.encode("utf-8"))
                     and not {"AST", "ALT", "AST_ALT"}.intersection(selected), "F5_A12_BRANCH_SETA_INVALID")
            recipe_set = selector["transform_recipes"] if branch == nested.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT else source["original_recipes"]
            outer, = [row for row in registered["partitions"] if row["kind"] == "OUTER"]
            common_map = _expected_family_parent_column_map(selected, "ELASTIC_NET_COX", predictors,
                _recipe_by_partition(recipe_set, outer["partition_id"]))
            common_df = sum(len(row["columns"]) for row in common_map)
            _require(common_df > 0, "F5_A12_OUTER_SETA_EPV_INVALID")
            events = context["training_event_count"]
            if branch == nested.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT:
                epv = nested.validate_epv_resolution(selector["selector"]["epv_resolution"])
            else:
                minimum = 15 if events >= 15 * common_df else 10
                epv = nested.validate_epv_resolution({
                    "preferred_minimum": 15, "minimum": minimum, "fallback_used": minimum == 10,
                    "source": "FIXED_PRIMARY_NON_AAR_SETA",
                    "primary_development_lock_sha256": source["primary_source"]["primary_development_lock"]["identity_sha256"],
                    "training_event_count": events, "common_set_design_df": common_df,
                    "common_set_epv": events / common_df,
                    "reason_code": "OK" if minimum == 15 else "FIXED_SETA_EPV_BELOW_15"})
            _require(events >= epv["minimum"] * common_df
                and common_df == (selector["selector"]["common_set_design_df"]
                    if branch == nested.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT
                    else source["fixed_common_set_design_df"]), "F5_A12_OUTER_SETA_EPV_INVALID")
            directory = recipes_root / branch
            directory.mkdir(mode=0o700, exist_ok=True)
            if transformed and branch == nested.A12_TOTAL_AAR:
                _a12_recipe_reuse(prepared, branch, registered["partitions"], selected,
                    root / "recipes" / branch if replay else directory, predictors, replay=replay)
            recipes = {}
            for partition in registered["partitions"]:
                partition_id = partition["partition_id"]
                if transformed and branch != nested.A12_TOTAL_AAR:
                    transform = _recipe_by_partition(recipe_set, partition_id)
                    identity = _registered_partition_identity_record(partition, prediction_only=partition["kind"] == "OUTER")
                    _require(transform["training_member_set_sha256"] == identity["fit_covariate_member_set_sha256"]
                             and transform["fit_ids_sha256"] == identity["fit_ids_sha256"]
                             and transform["analysis_view_sha256"] == identity["analysis_view_sha256"],
                             "F5_A12_BRANCH_RECIPE_SOURCE_MISMATCH")
                    recipe = {"schema_version": "1.0.0", "kind": "PADML_F5_FINAL_DESIGN_RECIPE_V1", "family": family,
                        "selected_parents": selected, "preprocessing_mode": "F2_LOCKED_TRANSFORM_RECIPE",
                        "predictor_contract_sha256": sha256_bytes(canonical_json_bytes(predictors)),
                        "predictor_rows": [row for row in predictors["variables"] if row["name"] in selected],
                        "transform_recipe": transform, "coxtime_standardization": None}
                else:
                    recipe = _compile_partition_design_recipe(family, selected, partition, directory, a12=True,
                        replay=replay or transformed and (directory / partition_id / "recipe.json").is_file(),
                        **({"native_evidence": (root / "recipes" / branch / partition_id
                            if replay else directory / partition_id)} if transformed else {}))
                _validate_final_design_recipe(recipe, family=family, selected_parents=selected)
                recipes[partition_id] = recipe
            body = {"branch": branch, "source_input_identity_sha256": sha256_bytes(canonical_json_bytes(
                _a12_outer_input_record({**prepared, "source_input_record": original_record}, branch=branch))),
                "selected_parents": selected, "common_set_design_df": common_df,
                "outer_training_event_count": context["training_event_count"], "recipes": recipes,
                "epv_resolution": epv, "common_set_epv": events / common_df,
                "epv_band": "10_LE_EPV_LT_15" if events < 15 * common_df else "EPV_GE_15",
                "selector_development_sha256": selector["identity_sha256"] if branch == nested.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT else None}
            developments[branch] = {**body, "identity_sha256": sha256_bytes(canonical_json_bytes(body))}
            # The original per-branch scientific value is immutable before its
            # Q/final consumers start. The whole-three-branch file is sealed
            # only at completeness, never rewritten as a progress controller.
            branch_raw = canonical_json_bytes(developments[branch])
            if replay:
                _require((root / f"{branch}.json").read_bytes() == branch_raw,
                         "F5_A12_BRANCH_DEVELOPMENT_REPLAY_MISMATCH")
            else:
                nested._write_exact_once(root / f"{branch}.json", branch_raw,
                                         "F5_A12_BRANCH_DEVELOPMENT_REPLAY_MISMATCH")
            branches[branch] = {**registered, "recipes": recipes, "selected_parents": selected,
                "status": "DEVELOPMENT_INPUTS_MATERIALIZED", "diagnostic_count": 0, "diagnostic_partitions": []}
        if set(developments) == set(nested.AAR_ESTIMANDS):
            raw = canonical_json_bytes(developments)
            if replay:
                _require((root / "development.json").read_bytes() == raw, "F5_A12_BRANCH_DEVELOPMENT_REPLAY_MISMATCH")
            else:
                nested._write_exact_once(root / "development.json", raw, "F5_A12_BRANCH_DEVELOPMENT_REPLAY_MISMATCH")
    except BaseException as exc:
        exc.add_note(f"F5_A12_BRANCH_DEVELOPMENT_EVIDENCE:{root}:{work}")
        raise
    else:
        if replay and q_input_lifecycle is not None:
            # This is only the private replay expansion, never the persistent
            # development/recipe tree. Its final caller still owns the inputs.
            q_input_lifecycle["development_inputs"] = {"temporary_root": str(work)}
        if replay and not retain_evidence and q_input_lifecycle is None:
            shutil.rmtree(work)
    unavailable = {name: value for name, value in developments.items() if value.get("status") == "NOT_ESTIMABLE"}
    result = {**prepared, "branches": branches, "branch_development": developments, "source_input_record": original_record}
    if unavailable:
        result["estimability"] = unavailable
        _a12_estimable_branches(result)
    return result


def _a12_elastic_configuration(prepared: Mapping[str, Any], branch: str,
                               *, workers: int | None = None) -> dict[str, Any]:
    """Bind original 15 inner splits and one outer to the same path kernel."""
    from .f2_kernel import predictor_contract, _expected_family_parent_column_map, _validate_transform_recipe_set
    prepared = _a12_branch_search_inputs(prepared, branch)
    _require(prepared["family"] == "ELASTIC_NET_COX" and branch in _a12_branch_names(prepared),
             "F5_A12_ELASTIC_SCOPE_INVALID")
    registered = prepared["branches"][branch]
    inner = sorted((row for row in registered["partitions"] if row["kind"] == "INNER"),
                   key=lambda row: (row["repeat"], row["inner_fold"]))
    outer, = [row for row in registered["partitions"] if row["kind"] == "OUTER"]
    _require(registered["kind"] == "PADML_F5_A12_REGISTERED_INPUTS" and registered["branch"] == branch
             and registered["fold"] == prepared["outer_fold"]
             and [(row["repeat"], row["inner_fold"]) for row in inner]
             == [(r, k) for r in range(1, 4) for k in range(1, 6)]
             and len(registered["partitions"]) == 16, "F5_A12_ELASTIC_PARTITIONS_INVALID")
    predictors = predictor_contract(Path(__file__).parent)
    recipes = [registered["recipes"][row["partition_id"]]["transform_recipe"] for row in [*inner, outer]]
    body = {"recipe_schema_version": "1.0.0", "kind": "PADML_F2_TRANSFORM_RECIPE_SET",
            "recipe_count": 16, "recipes": recipes}
    recipe_set = _validate_transform_recipe_set({**body, "recipe_set_sha256": sha256_bytes(canonical_json_bytes(body))},
                                               predictors, expected_count=16)
    column_maps = {row["partition_id"]: _expected_family_parent_column_map(
        prepared["selected_parents"], "ELASTIC_NET_COX", predictors,
        registered["recipes"][row["partition_id"]]["transform_recipe"]) for row in [*inner, outer]}
    parent_df = {row["parent"]: len(row["columns"]) for row in column_maps[outer["partition_id"]]}
    _require(sum(parent_df.values()) == prepared["common_set_design_df"], "F5_A12_FIXED_ELASTIC_DOMAIN_INVALID")
    science = load_science_authority()["science"]
    policy, contract = science["modeling_seed_policy"]["model"], science["f2_model_development"]["selector_contract"]
    execution = {"execution_mode": "PROCESS_POOL", "threads": resolve_pool_workers(workers),
                 "engine_threads": 1}
    execution["pool_workers"] = execution["threads"]
    source = _a12_search_source(prepared, branch)
    spec = {"schema_version": "1.0.0", "execution_scope": "F5_A12_SEARCH", "a12_source": source,
            "family": prepared["family"], "fold": prepared["outer_fold"], "backend": "CPU",
            "seed": policy["base"] + prepared["outer_fold"] * policy["outer_multiplier"],
            "imputation_count": 20, "outcome": science["population"]["outcome"], "time": science["population"]["time"],
            "horizons": science["horizons_months"], "monthly_fit_horizons": HORIZONS[1:],
            "heldout_center": (prepared["heldout_center"] if "branch_development" in prepared else
                               prepared["definitions"][0]["source"]["heldout_center"]),
            "predictors": predictors, "selector_contract": contract,
            "selector_from_dependency": {"selected_parents": prepared["selected_parents"],
                                         "outer_recipe_sha256": recipes[-1]["recipe_sha256"]},
            "fpm": None, "registered_inputs_identity_sha256": registered["identity"],
            "primary_execution": execution, **execution}
    horizon = prepared["source"]["primary_source"]["primary_development_lock"]["selection_horizon_months"]
    if horizon == 36:
        spec["selection_horizon_months"] = 36
        spec["trial_scoring"] = {**science["f2_model_development"]["trial_scoring"],
            "ibs_grid_months": list(range(37)), "ibs_integration": "TRAPEZOID_DIVIDE_BY_36"}
    return {"spec": spec, "registered": registered, "recipe_set": recipe_set, "inner": inner, "outer": outer,
            "column_maps": column_maps, "domain": {"selected_parents": prepared["selected_parents"],
                "parent_design_columns": parent_df, "common_set_design_df": prepared["common_set_design_df"],
                "outer_training_event_count": prepared["outer_training_event_count"]}}


def _summarize_a12_elastic_alpha(configuration: Mapping[str, Any], record: Mapping[str, Any]) -> dict[str, Any]:
    from .f2_kernel import _development_evaluation_indices, _elastic_ratios, _summarize_elastic_alpha, _validate_elastic_lambda_upper_bound
    _require(isinstance(record, Mapping) and set(record) == {"alpha", "partition_losses", "outer_paths"},
             "F5_A12_ELASTIC_RECORD_INVALID")
    spec, contract = configuration["spec"], configuration["spec"]["selector_contract"]
    # First run all original completeness/finite/health checks, even if a
    # later caller would classify a completely computed candidate infeasible.
    summary = _summarize_elastic_alpha(record, contract, fixed_a12=configuration["domain"])
    ratios = _elastic_ratios(contract)
    for row, partition in zip(record["partition_losses"], configuration["inner"], strict=True):
        _require((row["repeat"], row["inner_fold"]) == (partition["repeat"], partition["inner_fold"])
                 and row["validation_n"] == len(_development_evaluation_indices(partition, spec.get("selection_horizon_months", 24)) or partition["evaluation_ids"]), "F5_A12_ELASTIC_VALIDATION_WEIGHT_DRIFT")
    for partition, paths in [*[(partition, row["mi_lambda_path_health"]) for partition, row in
                              zip(configuration["inner"], record["partition_losses"], strict=True)],
                             (configuration["outer"], record["outer_paths"])]:
        columns = configuration["column_maps"][partition["partition_id"]]
        for path in paths:
            upper = _validate_elastic_lambda_upper_bound(path["lambda_upper_bound"], alpha=float(record["alpha"]),
                                                       ordered_parent_column_map=columns, a12=True)
            _require(path["penalized_design_column_count"] == sum(len(row["columns"]) for row in columns)
                     and path["lambda_max"] == upper
                     and path["lambda_path_sha256"] == sha256_bytes(canonical_json_bytes([upper * ratio for ratio in ratios])),
                     "F5_A12_ELASTIC_PATH_SOURCE_MISMATCH")
    return {**summary, "source": spec["a12_source"], "repeat_se_method": "ORIGINAL_THREE_REPEAT_SAMPLE_SD_DIVIDE_SQRT3"}


def _run_a12_elastic_native_batch(spec_path: Path, output_path: Path, repo_root: Path,
                                  environment: Mapping[str, str]) -> dict[str, Any]:
    """Retain original risk/coefficient bytes; replay never calls a fitter."""
    from .f2_kernel import _execute_r_prediction, _fpm_reuse_spec
    spec = strict_json_bytes(spec_path.read_bytes())
    _require(spec["execution_scope"] == "F5_A12_SEARCH" and spec["family"] == "ELASTIC_NET_COX"
             and len(spec["producer_tasks"]) == 1 and spec["producer_tasks"][0]["producer_kind"]
             in {"ELASTIC_INNER_PATH", "ELASTIC_OUTER_PATH"}
             and type(spec["native_search_replay"]) is bool, "F5_A12_ELASTIC_NATIVE_SCOPE_INVALID")
    native = Path(spec["native_search_root"]) / spec_path.parent.name
    def scientific(value):
        result = _fpm_reuse_spec(value)
        result.pop("native_search_root")
        result.pop("native_search_replay")
        return result
    if not spec["native_search_replay"]:
        # Keep a native original outside the disposable exact-member scratch.
        # The shared consumer intentionally deletes its risk-file copies.
        _require(not native.is_symlink(), "F5_A12_ELASTIC_NATIVE_OUTPUT_EXISTS")
        native.mkdir(mode=0o700, exist_ok=True)
        native_spec, native_output = native / "spec.json", native / "output.json"
        if native_spec.is_file():
            _require(scientific(strict_json_bytes(native_spec.read_bytes())) == scientific(spec), "F45_ELASTIC_INPUT_DRIFT")
        else:
            from .nested_loco import _write_exact_once
            _write_exact_once(native_spec, canonical_json_bytes({**spec, "output_path": str(native_output)}), "F45_ELASTIC_INPUT_DRIFT")
        if not native_output.is_file():
            _execute_r_prediction(native_spec, native_output, repo_root, environment, preserve_logs=True)
    _require(native.is_dir() and not native.is_symlink()
             and scientific(strict_json_bytes((native / "spec.json").read_bytes())) == scientific(spec),
             "F5_A12_ELASTIC_NATIVE_INPUT_MISMATCH")
    _require((native / "output.json").is_file() and (native / "r.stdout.log").is_file()
             and (native / "r.stderr.log").is_file() and not (native / "native-failure.rda").exists(),
             "F5_A12_ELASTIC_NATIVE_OUTPUT_INCOMPLETE")
    for path in native.iterdir():
        _require(path.is_file() and not path.is_symlink(), "F5_A12_ELASTIC_NATIVE_MEMBER_INVALID")
        if path.name not in {"spec.json", "r.stdout.log", "r.stderr.log"}:
            shutil.copyfile(path, spec_path.parent / path.name)
    return strict_json_bytes(output_path.read_bytes())


def _a12_elastic_reuse(prepared, branch, configuration, root):
    """Reuse a complete fixed-SetA path tree, never the no-AAR selector tree."""
    from . import nested_loco as nested
    from .f2_kernel import (_elastic_ratios, _recipe_by_partition, _r_prediction_child_spec,
                            _engine_registered_partitions, _fpm_reuse_spec)
    from .f5 import _f45_retain_final_object, _f45_score_reuse_authorities
    from .runtime import observe_execution_resources, resource_admission
    from .bundle import validate_relative_path
    failure = "F45_AAR_ELASTIC_REUSE_INVALID"
    reference = root / "reuse.json"
    prefix = f"search/{branch}/"
    spec = configuration["spec"]

    def match(proof, prior, read, pins):
        _a12_final_reuse_source(proof, prepared["source"], _f45_score_reuse_authorities())
        _require(prior.get("kind") == "PADML_F5_A12_ELASTIC_SEARCH_NATIVE_V1"
            and prior.get("status") == "COMPUTED" and "reused_search" not in prior
            and prior["identity_sha256"] == nested._sha({k: v for k, v in prior.items() if k != "identity_sha256"})
            and prior["source"]["source"] == proof["result_metadata"]["source"]
            and prior["source"]["branch"] == branch
            and prior["source"]["family"] == "ELASTIC_NET_COX"
            and prior["source"]["outer_fold"] == prepared["outer_fold"], failure)
        original_h = proof["result_metadata"]["source"]["primary_source"]["primary_development_lock"]["selection_horizon_months"]
        if (original_h == 36) != (spec.get("selection_horizon_months", 24) == 36):
            return False
        if prior["registered_identity"] != configuration["registered"]["identity"] or (
            prior["recipe_set_sha256"] != configuration["recipe_set"]["recipe_set_sha256"]):
            return False
        coarse = [float(a) for a in spec["selector_contract"]["alpha_grid"]["coarse"]]
        if prior["coarse_alphas"] != coarse:
            return False
        missing = [a for a in prior["fine_alphas"] if a not in coarse]
        groups = [coarse, *([missing] if missing else [])]
        _require(prior["distinct_alphas"] == sorted(set(coarse) | set(prior["fine_alphas"]))
            and prior["path_execution_count"] == len(prior["distinct_alphas"]) * 320
            and prior["glmnet_pilot_and_path_call_count"] == 2 * prior["path_execution_count"]
            and prior["native_batch_count"] == 320 * len(groups), failure)
        child = _r_prediction_child_spec({**spec, "a12_source": prior["source"],
            "native_search_root": str(root / "native"), "native_search_replay": True})
        expected_names = set()
        for alphas in groups:
            for partition in [*configuration["inner"], configuration["outer"]]:
                pid = partition["partition_id"]
                kind = "ELASTIC_INNER_PATH" if partition["kind"] == "INNER" else "ELASTIC_OUTER_PATH"
                registered = _engine_registered_partitions(configuration["registered"], {pid})
                recipe = _recipe_by_partition(configuration["recipe_set"], pid)
                for imp in range(1, 21):
                    task = {"task_id": f"{kind}_{pid}_M{imp:02d}_{nested._sha(alphas)[:12]}",
                        "partition_id": pid, "imputation": imp, "family": "ELASTIC_NET_COX",
                        "selected_parents": configuration["domain"]["selected_parents"], "parameters": {},
                        "producer_kind": kind, "alphas": alphas, "ratios": _elastic_ratios(spec["selector_contract"]),
                        "seed": spec["seed"] + imp}
                    name = "native/f2-r-batch-" + nested._sha([task["task_id"]])[:16] + "/spec.json"
                    expected_names.add(name)
                    if name not in pins:
                        return False
                    original = strict_json_bytes(read(name))
                    expected = {**child, "action": "MODEL_PREDICTION_BATCH", "threads": 1,
                        "pool_workers": 1, "engine_threads": 1, "registered_partitions": registered,
                        "transform_recipe": recipe, "producer_tasks": [task]}
                    def numbers(value):
                        result = _fpm_reuse_spec(value)
                        result.pop("native_search_root")
                        result.pop("native_search_replay")
                        return result
                    if numbers(original) != numbers(expected):
                        return False
        _require(expected_names == {name for name in pins if name.endswith("/spec.json")}, failure)
        _require(all(name.removesuffix("spec.json") + suffix in pins for name in expected_names
            for suffix in ("output.json", "r.stdout.log", "r.stderr.log")), failure)
        return True

    def read_record():
        _require(reference.is_file() and reference.resolve(strict=True) == reference
            and 0 < reference.stat().st_size <= 64 * 1024**2, failure)
        raw = reference.read_bytes()
        record = strict_json_bytes(raw)
        _require(canonical_json_bytes(record) == raw and set(record) == {
            "kind", "proof", "branch", "consumer_source", "members"}
            and record["kind"] == "PADML_F45_AAR_FIXED_SETA_ELASTIC_REUSE_V1"
            and record["branch"] == branch
            and record["consumer_source"] == spec["a12_source"], failure)
        result = record["proof"]["result_metadata"]
        _require(prefix + "reuse.json" not in result["members"]
            and record["members"] == {validate_relative_path(name[len(prefix):]): pin
                for name, pin in result["members"].items()
                if name == prefix + "search.json" or name.startswith(prefix + "native/")}, failure)
        _a12_final_reuse_source(record["proof"], prepared["source"], _f45_score_reuse_authorities())
        return record

    def consume(record):
        def read(name):
            path = root / ("producer-search.json" if name == "search.json" else validate_relative_path(name))
            pin = record["members"][name]
            _require(path.is_file() and path.resolve(strict=True) == path
                and {"sha256": sha256_file(path), "size_bytes": path.stat().st_size} == pin
                and 0 < pin["size_bytes"] <= 32 * 1024**2, failure)
            return path.read_bytes()
        prior = strict_json_bytes(read("search.json"))
        for name, pin in record["members"].items():
            path = root / ("producer-search.json" if name == "search.json" else validate_relative_path(name))
            if not path.is_file():
                return None
            _require(path.resolve(strict=True) == path
                and {"sha256": sha256_file(path), "size_bytes": path.stat().st_size} == pin, failure)
        _require(match(record["proof"], prior, read, record["members"]), failure)
        return prior

    pending = read_record() if reference.exists() else None
    if pending is not None:
        # Missing retained bytes never fall back to a new path producer.
        if all((root / ("producer-search.json" if name == "search.json" else name)).is_file()
               for name in pending["members"]):
            return consume(pending)
    elif root.exists():
        return None  # Preserve any original, even incomplete, native coordinate.
    for archive, proof in _a12_development_reuse_sources(prepared):
        result = proof["result_metadata"]
        if prefix + "search.json" not in result["members"] or prefix + "reuse.json" in result["members"]:
            continue
        pins = {validate_relative_path(name[len(prefix):]): pin for name, pin in result["members"].items()
            if name == prefix + "search.json" or name.startswith(prefix + "native/")}
        def read(name):
            pin = pins[name]
            _require(0 < pin["size_bytes"] <= 32 * 1024**2
                and archive.getinfo(prefix + name).file_size == pin["size_bytes"], failure)
            raw = archive.read(prefix + name)
            _require(sha256_bytes(raw) == pin["sha256"], failure)
            return raw
        prior = strict_json_bytes(read("search.json"))
        record = {"kind": "PADML_F45_AAR_FIXED_SETA_ELASTIC_REUSE_V1", "proof": proof,
            "branch": branch, "consumer_source": spec["a12_source"], "members": pins}
        if pending is not None and pending != record or not match(proof, prior, read, pins):
            continue
        total = sum(pin["size_bytes"] for pin in pins.values()) + len(canonical_json_bytes(record))
        observation = observe_execution_resources(root.parent)
        resource_admission({**prepared["source"]["resource_policy"], "memory_bytes_per_worker": MIN_WORKER_MEMORY_BYTES,
            "scratch_reserve_bytes": 0}, observation, legal_tasks=1)
        _require(observation["scratch_available_bytes"] >= 2 * total, failure)
        root.mkdir(mode=0o700, exist_ok=True)
        nested._write_exact_once(reference, canonical_json_bytes(record), failure)
        for name, pin in pins.items():
            target = root / ("producer-search.json" if name == "search.json" else name)
            target.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
            with archive.open(prefix + name) as stream:
                _f45_retain_final_object(stream, target, pin)
        return consume(record)
    _require(pending is None, "F45_AAR_ELASTIC_REUSE_PENDING_ORIGINAL_REQUIRED")
    return None


def _a12_elastic_search_program(prepared: Mapping[str, Any], branch: str, root: Path,
                                *, replay: bool, workers: int | None = None, retain_evidence: bool = False,
                                q_input_lifecycle: dict[str, Any] | None = None) -> dict[str, Any]:
    """Original coarse/fine path cache, with fixed SetA and an explicit no-fit replay."""
    from .f2_kernel import _evaluate_elastic_alpha_phase, _choose_elastic_coarse_epv_tier
    from .f5 import _choose_a16_summaries
    _require(type(replay) is bool and root.is_absolute() and root.parent.is_dir()
             and not root.is_symlink() and (root.is_dir() if replay else not root.exists() or root.is_dir()),
             "F5_A12_ELASTIC_SEARCH_PATH_INVALID")
    _require(q_input_lifecycle is None or isinstance(q_input_lifecycle, dict) and not q_input_lifecycle
             and replay and not retain_evidence and "branch_development" in prepared,
             "F5_A12_Q_INPUT_LIFECYCLE_SCOPE_INVALID")
    replay = replay or (root / "search.json").is_file()
    configuration = _a12_elastic_configuration(prepared, branch, workers=workers)
    reused = (_a12_elastic_reuse(prepared, branch, configuration, root)
              if "branch_development" in prepared else None)
    if not replay:
        root.mkdir(mode=0o700, exist_ok=True)
        (root / "native").mkdir(mode=0o700, exist_ok=True)
    scratch = Path(tempfile.mkdtemp(prefix="a12-elastic-replay-" if replay else "a12-elastic-consume-", dir=root.parent))
    if q_input_lifecycle is not None:
        q_input_lifecycle["q_program"] = {"temporary_root": str(scratch)}
    spec = {**configuration["spec"], "native_search_root": str(root / "native"), "native_search_replay": replay}
    accumulator = {}
    try:
        def phase(alphas):
            if reused is not None:
                # The completed whole producer and every retained member were
                # checked above; keep its original loss/health records.
                records = {record["alpha"]: record for record in reused["records"]}
                _require(len(records) == len(reused["records"])
                    and sorted(records) == reused["distinct_alphas"]
                    and set(alphas) <= set(records), "F45_AAR_ELASTIC_REUSE_RECORDS_INVALID")
                return {alpha: records[alpha] for alpha in alphas}
            return _evaluate_elastic_alpha_phase(spec, configuration["registered"], configuration["recipe_set"],
                alphas, scratch, Path(__file__).parent, accumulator,
                inner_partitions=configuration["inner"], full_partition=configuration["outer"],
                selected_parents=configuration["domain"]["selected_parents"], full_path_field="outer_paths")
        def summarize_epv(record, contract):
            current = {**configuration, "spec": {
                **configuration["spec"], "selector_contract": contract}}
            return _summarize_a12_elastic_alpha(current, record)
        grid = spec["selector_contract"]["alpha_grid"]
        coarse = [float(value) for value in grid["coarse"]]
        cache = phase(coarse)
        coarse_choice, _, epv_resolution, resolved = _choose_elastic_coarse_epv_tier(
            [cache[alpha] for alpha in coarse], coarse, spec["selector_contract"],
            summarize=summarize_epv, choose=lambda rows: _choose_a16_summaries(rows)[0])
        lower, upper = map(float, grid["fine"]["clip"])
        fine = sorted({min(upper, max(lower, round(coarse_choice["alpha"] + float(offset), 3)))
                       for offset in grid["fine"]["offsets"]})
        missing = [alpha for alpha in fine if alpha not in cache]
        if missing:
            cache.update(phase(missing))
        chosen = {**_choose_a16_summaries([summarize_epv(cache[a], resolved) for a in fine])[0],
                  "epv_resolution": epv_resolution}
        _require(set(cache) == set(coarse) | set(fine) and len(cache) <= 15,
                 "F5_A12_ELASTIC_GRID_OR_BUDGET_DRIFT")
        parameters = [{"family": "ELASTIC_NET_COX", "alpha": chosen["alpha"], "ratio": ratio,
                       "lambda": value, "lambda_upper_bound": bound}
                      for ratio, value, bound in zip(chosen["selected_ratio_by_imputation"],
                          chosen["lambda_by_imputation"], chosen["lambda_upper_bound_by_imputation"], strict=True)]
        body = {"kind": "PADML_F5_A12_ELASTIC_SEARCH_NATIVE_V1", "status": "COMPUTED",
            "source": spec["a12_source"], "registered_identity": configuration["registered"]["identity"],
            "recipe_set_sha256": configuration["recipe_set"]["recipe_set_sha256"],
            "coarse_alphas": coarse, "fine_alphas": fine, "distinct_alphas": sorted(cache),
            "records": [cache[alpha] for alpha in sorted(cache)], "selected": chosen,
            "epv_resolution": epv_resolution,
            "parameters_by_imputation": parameters,
            "path_execution_count": len(cache) * 20 * 16, "glmnet_pilot_and_path_call_count": len(cache) * 20 * 16 * 2,
            "native_batch_count": 320 * (1 + bool(missing)), "model_fit_count": 0,
            "new_mice_chains": 0, "parent_reselection_count": 0, "stage_acceptance": False}
        if reused is not None:
            def numerical(value):
                return {key: ({k: v for k, v in item.items() if k != "source"} if key == "selected" else item)
                    for key, item in value.items() if key not in {"source", "identity_sha256", "reused_search"}}
            _require(numerical(body) == numerical(reused), "F45_AAR_ELASTIC_REUSE_REDUCTION_DRIFT")
            reference = strict_json_bytes((root / "reuse.json").read_bytes())
            body["reused_search"] = {"whole_unit": reference["proof"]["whole_unit"]["unit_id"],
                "producer_search_sha256": sha256_file(root / "producer-search.json"),
                "shared_elastic_paths": body["path_execution_count"],
                "shared_glmnet_calls": body["glmnet_pilot_and_path_call_count"],
                "new_elastic_paths": 0, "new_glmnet_calls": 0}
        result = {**body, "identity_sha256": sha256_bytes(canonical_json_bytes(body))}
        if replay:
            if retain_evidence:
                (scratch / "search.json").write_bytes(canonical_json_bytes(result))
            _require((root / "search.json").read_bytes() == canonical_json_bytes(result),
                     "F5_A12_ELASTIC_SEARCH_NATIVE_REPLAY_MISMATCH")
        else:
            __import__("padml.nested_loco", fromlist=["_write_exact_once"])._write_exact_once(root / "search.json", canonical_json_bytes(result), "F45_ELASTIC_RESULT_DRIFT")
    except BaseException as exc:
        exc.add_note(f"F5_A12_ELASTIC_SEARCH_EVIDENCE:{scratch}")
        raise
    else:
        if not (replay and retain_evidence) and q_input_lifecycle is None:
            shutil.rmtree(scratch)
    return result


def _a12_complex_configuration(prepared: Mapping[str, Any], branch: str,
                               *, workers: int | None = None) -> dict[str, Any]:
    """Original-outer Q inputs, not a virtual full-data or bootstrap search."""
    from .nested_loco import validate_epv_resolution
    from .f2_kernel import predictor_contract
    from .f5 import _final_complex_candidate_trials
    prepared = _a12_branch_search_inputs(prepared, branch)
    family, outer = prepared["family"], prepared["outer_fold"]
    _require(family in {"RSF", "GBM_COX", "XGBOOST_COX", "COXTIME_SET_A"}
             and type(outer) is int and outer in range(1, 7) and branch in _a12_branch_names(prepared),
             "F5_A12_Q_SCOPE_INVALID")
    registered = prepared["branches"][branch]
    _require(registered["kind"] == "PADML_F5_A12_REGISTERED_INPUTS"
             and registered["branch"] == branch and registered["fold"] == outer
             and registered["outer_count"] == 1 and registered["inner_count"] == 15
             and registered["stop_count"] == (0 if family == "RSF" else 15)
             and registered["diagnostic_count"] == 0
             and len(registered["partitions"]) == (16 if family == "RSF" else 31)
             and prepared["selected_parents"] and not {"AST", "ALT", "AST_ALT"}.intersection(prepared["selected_parents"])
             and prepared["common_set_design_df"] > 0
             and prepared["outer_training_event_count"] >= prepared["common_set_design_df"] * validate_epv_resolution(prepared["epv_resolution"])["minimum"],
             "F5_A12_Q_FIXED_INPUT_INVALID")
    for kind in ("INNER", *(() if family == "RSF" else ("STOP",))):
        _require(sorted((row["repeat"], row["inner_fold"]) for row in registered["partitions"] if row["kind"] == kind)
                 == [(r, k) for r in range(1, 4) for k in range(1, 6)], "F5_A12_Q_PARTITION_COORDINATES_INVALID")
    authority = load_science_authority()
    science, f2 = authority["science"], authority["science"]["f2_model_development"]
    policy = science["modeling_seed_policy"]["model"]
    slots = resolve_pool_workers(workers)
    source = _a12_search_source(prepared, branch)
    horizon = 24
    if isinstance(source["source"], Mapping) and source["source"].get("kind") == "PADML_F5_A12_PROJECTED_OUTER_INPUTS_V1":
        from .nested_loco import validate_development_lock, validate_science_decision
        primary = source["source"]["primary_source"]
        decision = validate_science_decision(primary["science_decision"])
        lock = validate_development_lock(primary["primary_development_lock"],
            context=primary["primary_training_context"], science_decision=decision)
        horizon = lock.get("selection_horizon_months", 24)
    scoring = dict(f2["trial_scoring"])
    scoring.update(ibs_grid_months=list(range(horizon + 1)),
                   ibs_integration=f"TRAPEZOID_DIVIDE_BY_{horizon}")
    spec = {"schema_version": "1.0.0", "execution_scope": "F5_A12_SEARCH", "a12_source": source,
            "family": family, "fold": outer, "backend": "CPU", "imputation_count": 20,
            "seed": policy["base"] + outer * policy["outer_multiplier"],
            "outcome": science["population"]["outcome"], "time": science["population"]["time"],
            "horizons": science["horizons_months"], "monthly_fit_horizons": HORIZONS[1:],
            "heldout_center": (prepared["heldout_center"] if "branch_development" in prepared else
                               prepared["definitions"][0]["source"]["heldout_center"]),
            "predictors": predictor_contract(Path(__file__).parent, authority),
            "selector_from_dependency": {"selected_parents": prepared["selected_parents"], "outer_recipe_sha256": "RAW_CANONICAL"},
            "candidate_trials": _final_complex_candidate_trials(family),
            "candidate_sequence": f2["candidate_sequence"], "multifidelity": f2["multifidelity"],
            "trial_scoring": scoring, "search_space": f2["search_spaces"].get(family),
            "search_budget": f2["search_budgets"].get(family), "model_seed_policy": policy,
            "coxtime": f2["coxtime"] if family == "COXTIME_SET_A" else None, "fpm": None,
            "registered_inputs_identity_sha256": registered["identity"],
            "execution_mode": "PROCESS_POOL", "threads": slots, "pool_workers": slots, "engine_threads": 1,
            "selection_horizon_months": horizon}
    return {"spec": spec, "registered": registered}


def _a12_python_search_binding(task: Mapping[str, Any], loaded: Mapping[str, Any], design: Any,
                                *, stop: bool = False) -> dict[str, Any]:
    """Bind actual Q coordinates; original candidates deliberately share seeds."""
    from .f2_kernel import _engine_parameters, _selection_horizon_from_spec
    spec, partition = task["spec"], loaded["partition"]
    source, family, imp = spec["a12_source"], spec["family"], task["imputation"]
    proof = spec.get("retained_a12_primary_context_source_bundle")
    _require((proof is None) == ("a12_executor_source_identity" not in spec)
             and (proof is None or "retained_primary_source_bundle" not in spec),
             "F5_RETAINED_AAR_SOURCE_SCOPE_INVALID")
    _validate_a12_search_source(source, family=family, outer=spec["fold"],
        **({"retained_primary_source_bundle": Path(proof), "retained_primary_context": True}
           if proof is not None else
           {"retained_primary_source_bundle": Path(spec["retained_primary_source_bundle"])}
           if "retained_primary_source_bundle" in spec else {}))
    horizon = _selection_horizon_from_spec(spec)
    projected = source.get("source")
    if isinstance(projected, Mapping) and projected.get("kind") == "PADML_F5_A12_PROJECTED_OUTER_INPUTS_V1":
        _require(horizon == projected["primary_source"]["primary_development_lock"].get("selection_horizon_months", 24),
                 "F5_A12_Q_SELECTION_HORIZON_MISMATCH")
    if proof is not None:
        from .f4 import _f45_source_member_sha256
        _require(horizon == 24 and spec["a12_executor_source_identity"]
                 == sha256_bytes(canonical_json_bytes(_f45_source_member_sha256())),
                 "F5_RETAINED_AAR_Q_EXECUTOR_DRIFT")
    stage = task["task_id"].split("_", 1)[0]
    stages = ("S1", "S2", "S3A", "S3B1", "S3B2")
    _require(spec["execution_scope"] == "F5_A12_SEARCH" and type(stop) is bool
             and family in {"XGBOOST_COX", "COXTIME_SET_A"} and source["family"] == family
             and type(source["outer_fold"]) is int and source["outer_fold"] == spec["fold"] in range(1, 7)
             and stage in stages
             and partition["kind"] == ("STOP" if stop else "INNER")
             and partition["repeat"] in range(1, 4) and partition["inner_fold"] in range(1, 6)
             and partition["partition_id"] == task["partition_id"]
             and task["registered"]["identity"] == spec["registered_inputs_identity_sha256"]
             and type(imp) is int and imp in range(1, 21) and loaded["imputation_indices"] == [imp]
             and (stop or task.get("prediction_horizons", spec["horizons"]) == spec["monthly_fit_horizons"] == HORIZONS[1:])
             and "full_pipeline_source" not in spec, "F5_A12_Q_COORDINATE_INVALID")
    index = stages.index(stage)
    p = partition["inner_fold"] if index < 3 else (partition["repeat"] - 1) * 5 + partition["inner_fold"]
    _require((index >= 3 or partition["repeat"] == index + 1)
             and imp <= (1, 5, 20, 5, 20)[index]
             and spec["seed"] == 300_000 + spec["fold"] * 1_000
             and task["seed"] == spec["seed"] + (index + 1) * 10_000 + imp * 100 + p,
             "F5_A12_Q_ORIGINAL_SEED_INVALID")
    suffix = "FUNCTION" if stop else "LOCKED_REFIT"
    tail = f"P{p:02d}_M{imp:02d}_{suffix}"
    # The dedicated CoxTime S3B2 branch intentionally has no trial ordinal.
    if family == "COXTIME_SET_A" and stage == "S3B2":
        _require(task["task_id"] == f"{stage}_{tail}", "F5_A12_Q_TASK_COORDINATE_INVALID")
    else:
        counts = (40, 14, 3, 2, 1) if family == "XGBOOST_COX" else (12, 4, 2, 2, 1)
        _require(task["task_id"] in {f"{stage}_T{trial:03d}_{tail}" for trial in range(1, counts[index] + 1)},
                 "F5_A12_Q_TASK_COORDINATE_INVALID")
    parameters = task["parameters" if family == "XGBOOST_COX" else "candidate"]
    candidates = spec["candidate_trials"]["S1" if family == "COXTIME_SET_A" or stage == "S1" else "S2"]
    matches = [row for row in candidates if parameters ==
               (_engine_parameters(family, row["parameters"]) if family == "XGBOOST_COX" else row)]
    _require(len(matches) == 1, "F5_A12_Q_CANDIDATE_DRIFT")
    candidate = matches[0]
    coordinates = {"source": source, "task_id": task["task_id"], "partition_id": task["partition_id"],
                   "stage": stage, "candidate_id": candidate.get("trial_id", candidate.get("candidate_id"))}
    return {"model_seed": task["seed"], "imputation": imp, "coordinates": coordinates,
            "consumed_input_sha256": sha256_bytes(canonical_json_bytes({
                "parameters": parameters, "stop": stop,
                "locked_value": None if stop else task["locked_rounds" if family == "XGBOOST_COX" else "locked_epoch"],
                "selected_parents": spec["selector_from_dependency"]["selected_parents"],
                "registered_identity": spec["registered_inputs_identity_sha256"],
                "patient_ids": loaded["fit_ids"], "design_columns": loaded["columns"],
                "design_dtype": str(design.dtype), "design": design.tolist(),
                "time": loaded["fit_time"].tolist(), "event": loaded["fit_event"].tolist(),
            }))}


def _run_a12_complex_search(spec: dict[str, Any], registered: dict[str, Any], scratch: Path) -> dict[str, Any]:
    """One original five-stage program; no seed audit, center stress or outer fit."""
    from .f2_kernel import (_run_r_registered_rsf, _run_r_registered_gbm,
                            _run_python_registered_xgboost, _run_python_registered_coxtime)
    family = spec["family"]
    options = {"search_only": True, "full_pipeline_replicate": None}
    if family in {"RSF", "GBM_COX"}:
        run = _run_r_registered_rsf if family == "RSF" else _run_r_registered_gbm
        return run(spec, registered, scratch, Path(__file__).parent, **options)
    try:
        import numpy as np
        import pandas as pd
        if family == "XGBOOST_COX":
            import xgboost as xgb
            return _run_python_registered_xgboost(spec, registered, scratch, xgb, np, pd, **options)
        _require(family == "COXTIME_SET_A", "F5_A12_Q_FAMILY_INVALID")
        from pycox import models
        import torch
        import torchtuples as tt
    except ImportError as exc:
        raise ContractError("F5_A12_Q_CAPABILITY_UNAVAILABLE") from exc
    return _run_python_registered_coxtime(spec, registered, scratch, (models, torch, tt), np, pd, **options)


def _a12_complex_search_program(prepared: Mapping[str, Any], branch: str, root: Path,
    *, replay: bool, workers: int | None = None, retain_evidence: bool = False,
    native_audit: bool = False, batch_options: Mapping[str, Any] | None = None,
    continuous_batch_root: Path | None = None, q_input_lifecycle: dict[str, Any] | None = None) -> dict[str, Any]:
    """Each AAR branch runs its own complete Q, sharing only identical audited fits."""
    from .f5 import _current_q_program
    _require(batch_options is None and continuous_batch_root is None and not native_audit,
        "OLD_F45_STAGE_DISPATCH_REMOVED")
    configuration = _a12_complex_configuration(prepared, branch, workers=workers)
    spec, registered = configuration["spec"], configuration["registered"]
    q_input = {"kind": "PADML_F5_A12_Q_INPUT_V1", "spec": spec,
        "registered_identity": registered["identity"],
        "inputs": _a12_outer_input_record(prepared, branch=branch)}
    result = _current_q_program(q_input, registered, root,
        resource_policy=prepared["source"]["resource_policy"], replay=replay,
        workers=workers, retain_evidence=retain_evidence)
    _require(result["execution_scope"] == "F5_A12_SEARCH" and result["a12_source"] == spec["a12_source"],
        "F5_A12_Q_RESULT_SOURCE_INVALID")
    return result


def _a12_final_task_coordinates(outer: int, task_names: list[str] | None = None) -> dict[str, tuple[str, int]]:
    """Validate assignments against the original complete, ordered 3 x M20 grid."""
    from .nested_loco import AAR_ESTIMANDS
    _require(type(outer) is int and outer in range(1, 7), "F5_A12_FINAL_BATCH_COORDINATES_INVALID")
    coordinates = {f"O{outer}_{branch}_M{imp:02d}": (branch, imp)
                   for branch in AAR_ESTIMANDS for imp in range(1, 21)}
    _require(task_names is None or isinstance(task_names, list) and task_names
             and all(isinstance(name, str) for name in task_names)
             and task_names == [name for name in coordinates if name in task_names],
             "F5_A12_FINAL_BATCH_COORDINATES_INVALID")
    return {name: coordinate for name, coordinate in coordinates.items() if task_names is None or name in task_names}


def _a12_outer_model_jobs(prepared: Mapping[str, Any], searches: Mapping[str, Any],
                          *, branch: str | None = None, task_names: list[str] | None = None) -> list[dict]:
    """Pair each original outer imputation with its own branch's final parameters."""
    from . import nested_loco as nested
    from .f2_kernel import predictor_contract, _expected_family_parent_column_map, _recipe_training_member_bytes
    from .f5 import _validate_a12_model_task, _validate_final_design_recipe
    family, outer = prepared["family"], prepared["outer_fold"]
    complete = _a12_branch_names(prepared)
    assigned = None if task_names is None else _a12_final_task_coordinates(outer, task_names)
    available = _a12_estimable_branches(prepared)
    branches = (available if assigned is None else tuple(name for name in complete
                 if any(coordinate[0] == name for coordinate in assigned.values()))) if branch is None else (branch,)
    _require(family in _A12_FIXED_FAMILIES | _A12_TUNED_FAMILIES
             and type(outer) is int and outer in range(1, 7)
             and (branch is None or complete == nested.AAR_ESTIMANDS and branch in complete)
             and (assigned is None or branch is None and complete == nested.AAR_ESTIMANDS)
             and (set(prepared["branches"]) == set(complete)
                  or assigned is not None and set(prepared["branches"]) == set(branches))
             and set(branches) <= set(available)
             and set(searches) == (set(branches) if family in _A12_TUNED_FAMILIES else set()),
             "F5_A12_OUTER_MODEL_INPUT_INVALID")
    predictors = predictor_contract(Path(__file__).parent)
    policy = load_science_authority()["science"]["modeling_seed_policy"]["model"]
    jobs = []
    for branch in branches:
        branch_inputs = _a12_branch_search_inputs(prepared, branch)
        source = _a12_search_source(prepared, branch)
        selected = branch_inputs["selected_parents"]
        common_df, events = branch_inputs["common_set_design_df"], branch_inputs["outer_training_event_count"]
        _require(type(common_df) is int and common_df > 0
                 and events >= common_df * nested.validate_epv_resolution(branch_inputs["epv_resolution"])["minimum"],
                 "F5_A12_OUTER_SETA_EPV_INVALID")
        registered = prepared["branches"][branch]
        partition, = [row for row in registered["partitions"] if row["kind"] == "OUTER"]
        recipe = registered["recipes"][partition["partition_id"]]
        _validate_final_design_recipe(recipe, family=family, selected_parents=selected)
        columns = _expected_family_parent_column_map(selected, family, predictors, recipe["transform_recipe"])
        design_count = sum(len(row["columns"]) for row in columns)
        _require(design_count > 0, "F5_A12_EMPTY_DESIGN")
        if family in _A12_TUNED_FAMILIES:
            search = searches[branch]
            _require(search["source" if family == "ELASTIC_NET_COX" else "a12_source"] == source,
                     "F5_A12_OUTER_SEARCH_SOURCE_MISMATCH")
            parameters = (search["parameters_by_imputation"] if family == "ELASTIC_NET_COX"
                          else [search["selected_spec"] for _ in range(20)])
            _require(isinstance(parameters, list) and len(parameters) == 20
                     and all(isinstance(row, dict) and row.get("family") == family for row in parameters),
                     "F5_A12_OUTER_PARAMETER_M20_INVALID")
        else:
            parameters = [{"family": family, **({"ties": "breslow"} if family == "COX_PH"
                                                else {"df": 3, "tvc_df": 0})} for _ in range(20)]
        final_source = None
        if branch in nested.AAR_ESTIMANDS:
            primary = prepared["source"]["primary_source"]
            context = _a12_nested_mice_source({**primary, "estimand": nested.A12_TOTAL_AAR},
                **({"retained_primary_source_bundle": prepared["retained_primary_source_bundle"]}
                   if "retained_primary_source_bundle" in prepared else {}),
                **({"retained_primary_context": True} if (family == "GBM_COX"
                   or source.get("common_set_epv_binding") is not None
                   or (outer, family) in {(2, "XGBOOST_COX"), (6, "COXTIME_SET_A")}
                       and branch == nested.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT)
                   and "retained_primary_source_bundle" in prepared else {}))
            final_source = {
                "kind": "PADML_NESTED_AAR_FINAL_SOURCE_V1", "program_id": nested.PROGRAM_ID,
                "science_decision_sha256": primary["science_decision"]["identity_sha256"],
                "primary_development_lock_sha256": primary["primary_development_lock"]["identity_sha256"],
                "training_context_sha256": context["identity_sha256"],
                "inputs_identity_sha256": source["inputs_identity_sha256"],
                "development_input_sha256": source["development_input_sha256"],
                "parameter_source_sha256": sha256_bytes(canonical_json_bytes(
                    searches[branch] if family in _A12_TUNED_FAMILIES else parameters)),
                "epv_resolution": branch_inputs["epv_resolution"],
                "parameter_epv_resolution": searches[branch]["epv_resolution"] if family == "ELASTIC_NET_COX" else None,
                "selection_horizon_months": primary["primary_development_lock"]["selection_horizon_months"],
                "epv_band": "10_LE_EPV_LT_15" if events < 15 * common_df else "EPV_GE_15",
            }
        fit_ids, evaluation_ids = partition["fit_ids"], partition["evaluation_ids"]
        if final_source is not None:
            _require(fit_ids == context["training_ids"] and evaluation_ids == context["heldout_ids"]
                     and "evaluation_response" not in partition,
                     "F5_A12_OUTER_TRAINING_CONTEXT_MISMATCH")
        response = Path(partition["fit_response"]["path"]).read_bytes()
        response_rows = _response_rows(response)[1]
        _require(list(response_rows) == fit_ids and sha256_bytes(response) == partition["fit_response"]["sha256"]
                 and sum(int(row["All_Cause_Death"]) for row in response_rows.values()) == events,
                 "F5_A12_OUTER_RESPONSE_MISMATCH")
        covariates = partition["covariates"]
        _require([row["name"] for row in covariates["members"]] == [f"imp{i:02d}.csv" for i in range(1, 21)]
                 and len(partition["fit_covariate_members"]) == 20, "F5_A12_OUTER_M20_REQUIRED")
        for imp, (member, fit_member, parameter) in enumerate(zip(
                covariates["members"], partition["fit_covariate_members"], parameters, strict=True), 1):
            if assigned is not None and f"O{outer}_{branch}_M{imp:02d}" not in assigned:
                continue
            path = Path(covariates["input_dir"]) / member["name"]
            raw = path.read_bytes()
            _require(len(raw) == member["size_bytes"] and sha256_bytes(raw) == member["sha256"],
                     "F5_A12_OUTER_COVARIATE_MISMATCH")
            training = _recipe_training_member_bytes(path, fit_ids)
            _require(fit_member == {"name": member["name"], "sha256": sha256_bytes(training), "size_bytes": len(training)},
                     "F5_A12_OUTER_TRAINING_M20_MISMATCH")
            coordinates = {"outer_fold": outer, "branch": branch, "imputation": imp}
            seed = policy["base"] + outer * policy["outer_multiplier"] + imp
            task = {"family": family, "selected_parents": selected, "parameters": parameter,
                    "imputation": imp, "a12_coordinates": coordinates, "registered_model_seed": seed,
                    "model_seed": seed if family in {"RSF", "GBM_COX", "XGBOOST_COX", "COXTIME_SET_A"} else None,
                    "row_count": len(fit_ids), "family_design_column_count": design_count,
                    "common_set_design_df": common_df, "training_event_count": events,
                    **({"nested_aar_final_source": final_source} if final_source is not None else {})}
            _validate_a12_model_task(family, task)
            entries = {"task.json": canonical_json_bytes(task), "recipe.json": canonical_json_bytes(recipe),
                       "fit-covariates.csv": training, "fit-response.csv": response,
                       "prediction-covariates.csv": _recipe_training_member_bytes(path, evaluation_ids)}
            _ablation_component_inputs(entries)
            jobs.append({"name": f"O{outer}_{branch}_M{imp:02d}", "entries": entries,
                         **({"consumer_source": prepared["source"]} if final_source is not None else {})})
    _require(len(jobs) == len({row["name"] for row in jobs}) == (20 * len(branches) if assigned is None else len(assigned))
             and (assigned is None or [job["name"] for job in jobs] == list(assigned)), "F5_A12_OUTER_M20_REQUIRED")
    return jobs


def _a12_outer_predictions(prepared: Mapping[str, Any], jobs: list[dict], rows: list[dict]) -> dict:
    """Require every branch/imputation before the original M20 probability mean."""
    branches = _a12_estimable_branches(prepared)
    _require(len(jobs) == len(rows) == 20 * len(branches), "F5_A12_NATIVE_FIT_COVERAGE_INVALID")
    source = (prepared["source"]["primary_source"]["primary_training_context"]
              if branches != A12_BRANCHES[1:] else prepared["definitions"][0]["source"])
    ids = source["heldout_ids"] if branches != A12_BRANCHES[1:] else source["validation_ids"]
    family, outer = prepared["family"], prepared["outer_fold"]
    centers = [str(source["heldout_center"])] * len(ids)
    by_coordinate = {}
    for job, row in zip(jobs, rows, strict=True):
        task = strict_json_bytes(job["entries"]["task.json"])
        coordinates = task["a12_coordinates"]
        key = coordinates["branch"], coordinates["imputation"]
        _require(key not in by_coordinate and row["a12_coordinates"] == coordinates
                 and coordinates["outer_fold"] == outer and row["family"] == family
                 and row["patient_ids"] == ids and row["centers"] == centers and row["horizons"] == HORIZONS,
                 "F5_A12_NATIVE_COORDINATE_MISMATCH")
        _seal_prediction_matrix(ids, row["survival"], HORIZONS)
        _require(all(values[0] == 1.0 for values in row["survival"]), "F5_A12_MONTH_ZERO_INVALID")
        by_coordinate[key] = row["survival"]
    _require(set(by_coordinate) == {(branch, imp) for branch in branches for imp in range(1, 21)},
             "F5_A12_NATIVE_FIT_COVERAGE_INVALID")
    survival = {branch: [[math.fsum(by_coordinate[branch, imp][patient][month] for imp in range(1, 21)) / 20
                         for month in range(len(HORIZONS))] for patient in range(len(ids))] for branch in branches}
    for matrix in survival.values():
        _seal_prediction_matrix(ids, matrix, HORIZONS)
    return {"patient_ids": ids, "centers": centers, "horizons": HORIZONS, "survival": survival}


def _a12_outer_retained_members(root: Path, family: str, outer: int, input_archive: Path,
                                 *, prepared: Mapping[str, Any] | None = None,
                                 before_final: bool = False,
                                 completed_branches: tuple[str, ...] | None = None,
                                 assigned_branches: tuple[str, ...] | None = None,
                                 replay_input_roots: tuple[Path, ...] = ()) -> dict[str, Path]:
    """Keep original inputs/Q plus first-audit selector and final-model numbers."""
    branches = A12_BRANCHES[1:] if prepared is None else _a12_branch_names(prepared)
    complete = branches
    available = branches if prepared is None else _a12_estimable_branches(prepared)
    _require(isinstance(replay_input_roots, tuple) and len(set(replay_input_roots)) == len(replay_input_roots)
             and (not replay_input_roots or complete != A12_BRANCHES[1:])
             and all(isinstance(path, Path) and path.parent == root / "development"
                 and path.is_dir() and not path.is_symlink() and path.resolve(strict=True) == path
                 and any(path.name.startswith(prefix) and len(path.name) > len(prefix)
                     for prefix in ("a12-selector-inputs-", "nested-full-selector-replay-"))
                 for path in replay_input_roots), "F5_A12_FINAL_INPUT_EXECUTION_INVALID")
    _require(completed_branches is None or before_final and branches != A12_BRANCHES[1:]
             and isinstance(completed_branches, tuple) and completed_branches
             and completed_branches == branches[:len(completed_branches)], "F5_A12_SEARCH_BRANCH_INVALID")
    if completed_branches is not None:
        branches = completed_branches
    _require(assigned_branches is None or completed_branches is None and before_final
             and complete != A12_BRANCHES[1:] and isinstance(assigned_branches, tuple) and assigned_branches
             and assigned_branches == tuple(name for name in complete if name in assigned_branches),
             "F5_A12_SEARCH_BRANCH_INVALID")
    if assigned_branches is not None:
        branches = assigned_branches
    if completed_branches is None and assigned_branches is None:
        branches = available
    members = {"inputs.zip": input_archive}
    if complete != A12_BRANCHES[1:]:
        members.update({name: root / name for name in _a12_final_reuse_members(root, outer, branches)})
    if not before_final:
        suffix = ".zip" if branches == A12_BRANCHES[1:] else ".numbers.json"
        members.update({f"fits/O{outer}_{branch}_M{imp:02d}{suffix}": root / "fits" / f"O{outer}_{branch}_M{imp:02d}{suffix}"
                        for branch in branches for imp in range(1, 21)})
        if complete != A12_BRANCHES[1:]:
            native = {f"fits/O{outer}_{branch}_M{imp:02d}.zip": root / "fits" / f"O{outer}_{branch}_M{imp:02d}.zip"
                      for branch in branches for imp in range(1, 21)}
            available = {name for name, path in native.items() if path.is_file()}
            _require(not available or available == set(native), "F45_AAR_FINAL_NATIVE_COVERAGE_INVALID")
            _require(available or not any(name.startswith("final-reuse/") for name in members),
                     "F45_AAR_FINAL_REUSE_NATIVE_OBJECT_REQUIRED")
            if available:
                members.update(native)
    if complete != A12_BRANCHES[1:]:
        from .f5 import _nested_selector_numerical_members
        from .nested_loco import WITHIN_FAMILY_NO_AAR_REDEVELOPMENT
        if not before_final:
            members["execution.json"] = root / "execution.json"
            execution_path = members["execution.json"]
            _require(execution_path.is_file() and not execution_path.is_symlink()
                     and 0 < execution_path.stat().st_size <= 16 * 1024**2,
                     "F5_A12_FINAL_BATCH_EXECUTION_INVALID")
            with execution_path.open("rb") as handle:
                raw = handle.read(16 * 1024**2 + 1)
            _require(len(raw) <= 16 * 1024**2, "F5_A12_FINAL_BATCH_EXECUTION_INVALID")
            execution = strict_json_bytes(raw)
            if "final_batches" in execution:
                records = execution["final_batches"]
                _require(isinstance(records, list) and 0 < len(records) <= 60,
                         "F5_A12_FINAL_BATCH_EXECUTION_INVALID")
                for record in records:
                    names = record["task_names"]
                    _a12_final_task_coordinates(outer, names)
                    relative = "final-batches/" + sha256_bytes(canonical_json_bytes(names)) + "/resource-release.json"
                    pin = record["resource_release"]
                    _require(isinstance(pin, Mapping) and set(pin) == {"path", "sha256", "size_bytes"}
                             and pin["path"] == relative and relative not in members
                             and type(pin["size_bytes"]) is int and 0 < pin["size_bytes"] <= len(names) * _A12_FINAL_BATCH_RECORD_LIMIT,
                             "F5_A12_FINAL_BATCH_RELEASE_INVALID")
                    member = root / relative
                    _require(member.is_file() and not member.is_symlink() and member.resolve(strict=True) == member
                             and member.stat().st_size == pin["size_bytes"] and sha256_file(member) == pin["sha256"],
                             "F5_A12_FINAL_BATCH_RELEASE_INVALID")
                    members[relative] = member
                _require(sum(path.stat().st_size for name, path in members.items() if name.startswith("final-batches/"))
                         <= 60 * _A12_FINAL_BATCH_RECORD_LIMIT, "F5_A12_FINAL_BATCH_RELEASE_LIMIT_EXCEEDED")
        development = root / "development"
        _require(development.is_dir() and not development.is_symlink()
                 and (completed_branches is not None and branches != complete
                      or assigned_branches is not None or (development / "development.json").is_file())
                 and (WITHIN_FAMILY_NO_AAR_REDEVELOPMENT not in branches
                      or (development / "selector/development-input.json").is_file()),
                 "F5_A12_BRANCH_DEVELOPMENT_REQUIRED")
        for path in sorted(development.rglob("*")):
            if any(path == owned or owned in path.parents for owned in replay_input_roots):
                continue
            if assigned_branches is not None and not _a12_final_shared_members(
                    {path.relative_to(root).as_posix(): path}, set(branches)):
                continue
            _require(not path.is_symlink() and (path.is_dir() or path.is_file()), "F5_A12_NATIVE_MEMBER_INVALID")
            if path.is_file():
                relative = path.relative_to(development).parts
                # Fresh NO_AAR selector response inputs are created after the
                # DIRECT/TOTAL reservations. Keep them in the complete archive,
                # but do not add future files to those earlier producer budgets.
                if completed_branches is not None and (
                    relative[0] == "development.json" and branches != complete
                    or WITHIN_FAMILY_NO_AAR_REDEVELOPMENT not in branches
                        and relative[0].startswith("selector-inputs-")
                        and len(relative[0]) > len("selector-inputs-")
                    or relative[0] in {f"{name}.json" for name in complete if name not in branches}
                    or relative[0] == "recipes" and len(relative) >= 2 and relative[1] not in branches):
                    continue
                if relative[0] == "recipes" and len(relative) >= 5 and relative[3] == "training-inputs":
                    # First recipe values/spec remain; their original training
                    # copies stay with the producer, outside numerical transport.
                    continue
                if relative[0] != "selector":
                    members[path.relative_to(root).as_posix()] = path
        if (WITHIN_FAMILY_NO_AAR_REDEVELOPMENT in branches
                or "estimability" in prepared and completed_branches is None and assigned_branches is None):
            members.update({f"development/selector/{name}": path
                            for name, path in _nested_selector_numerical_members(development / "selector").items()})
    if family in _A12_TUNED_FAMILIES:
        for branch in branches:
            search = root / "search" / branch
            if complete != A12_BRANCHES[1:] and family != "ELASTIC_NET_COX":
                from .f4_compact import _full_pipeline_q_numerical_members
                projected, _ = _full_pipeline_q_numerical_members(search, resource_policy=prepared["source"]["resource_policy"])
                members.update({f"search/{branch}/{name}": path for name, path in projected.items()})
                continue
            required = ["search.json"] if family == "ELASTIC_NET_COX" else ["input.json", "result.json"]
            if family == "ELASTIC_NET_COX" and (search / "reuse.json").exists():
                # The native spec keeps the first producer's source. Its
                # consumer binding and original search record must travel too.
                required.extend(("reuse.json", "producer-search.json"))
            for name in required:
                members[f"search/{branch}/{name}"] = search / name
            native = search / "native"
            _require(native.is_dir() and not native.is_symlink(), "F5_A12_NATIVE_SEARCH_REQUIRED")
            for path in sorted(native.rglob("*")):
                _require(not path.is_symlink() and (path.is_dir() or path.is_file()), "F5_A12_NATIVE_MEMBER_INVALID")
                if path.is_file():
                    members[path.relative_to(root).as_posix()] = path
    if prepared is not None and "retained_a12_q_executor_source_bundle" in prepared:
        from .nested_loco import WITHIN_FAMILY_NO_AAR_REDEVELOPMENT

        _require(WITHIN_FAMILY_NO_AAR_REDEVELOPMENT in branches or before_final
                 and completed_branches is not None,
                 "F5_RETAINED_AAR_Q_EXECUTOR_DRIFT")
        if WITHIN_FAMILY_NO_AAR_REDEVELOPMENT in branches:
            source = prepared["retained_a12_q_executor_source_bundle"]
            _require(family == "RSF" and outer == 4 and prepared["family"] == family
                     and prepared["outer_fold"] == outer
                     and prepared["source"].get("identity_sha256")
                         == "1204c950c4f61b4a30ae3302825cad8720c77bd9c5daff68159c7eaaad88f9af"
                     and prepared["source"]["primary_source"]["primary_development_lock"].get(
                         "selection_horizon_months", 24) == 24
                     and isinstance(source, Path) and source.is_absolute() and source.is_file()
                     and not source.is_symlink() and source.resolve(strict=True) == source,
                     "F5_RETAINED_AAR_Q_EXECUTOR_DRIFT")
            members["execution-evidence/retained-sources/a12-q-executor.zip"] = source
    _require(all(path.is_file() and not path.is_symlink() for path in members.values()), "F5_A12_NATIVE_MEMBER_MISSING")
    return members


def _a12_final_shared_members(members: Mapping[str, Any], branches: set[str]) -> dict[str, Any]:
    """Project the existing shared-file index identically on worker and gather."""
    from .nested_loco import AAR_ESTIMANDS, WITHIN_FAMILY_NO_AAR_REDEVELOPMENT
    excluded = {f"development/{name}.json" for name in AAR_ESTIMANDS if name not in branches}
    prefixes = tuple(prefix for name in AAR_ESTIMANDS if name not in branches
                     for prefix in (f"development/recipes/{name}/", f"search/{name}/"))
    if WITHIN_FAMILY_NO_AAR_REDEVELOPMENT not in branches:
        prefixes += ("development/selector/",)
    return {name: value for name, value in members.items() if name not in excluded and not name.startswith(prefixes)}


_A12_FINAL_BATCH_RECORD_LIMIT = 128 * 1024


def _a12_final_resource_reservation(source: Mapping[str, Any], jobs: list[dict],
                                  shared_sizes: Mapping[str, int], retained_bytes_per_component: int,
                                  *, allow_partial: bool = False,
                                  task_names: list[str] | None = None,
                                  execution_worker_memory_bytes: int | None = None,
                                  execution_scratch_reserve_bytes: int | None = None) -> dict:
    """Bound the final stage's accumulated outputs, not only active workers.

    The existing execution report owns these operational estimates. They do
    not change the scientific ledger or the execution-host CPU ceiling.
    """
    from .runtime import validate_resource_policy
    policy = validate_resource_policy(source["resource_policy"])
    _require(execution_worker_memory_bytes is None or type(execution_worker_memory_bytes) is int
             and execution_worker_memory_bytes in RECORDED_WORKER_MEMORY_BYTES, "F5_A12_FINAL_WORKER_MEMORY_BUDGET_INVALID")
    _require(execution_scratch_reserve_bytes is None or type(execution_scratch_reserve_bytes) is int
             and execution_scratch_reserve_bytes == 0, "F5_A12_FINAL_SCRATCH_BUDGET_INVALID")
    _require(type(retained_bytes_per_component) is int and retained_bytes_per_component > 0
             and type(allow_partial) is bool
             and (0 < len(jobs) <= 60 if task_names else len(jobs) in ((20, 40, 60) if allow_partial else (60,)))
             and len({job["name"] for job in jobs}) == len(jobs), "F5_A12_FINAL_RETENTION_ESTIMATE_REQUIRED")
    _require(task_names is None or not allow_partial and isinstance(task_names, list)
             and all(isinstance(name, str) for name in task_names)
             and task_names == [job["name"] for job in jobs if job["name"] in task_names],
             "F5_A12_FINAL_BATCH_COORDINATES_INVALID")
    _require(isinstance(shared_sizes, Mapping) and all(isinstance(name, str) and type(size) is int and size >= 0
                 for name, size in shared_sizes.items()), "F5_A12_FINAL_RETENTION_ESTIMATE_REQUIRED")
    if task_names:
        assigned = _a12_final_task_coordinates(source["outer_fold"], task_names)
        jobs = [job for job in jobs if job["name"] in assigned]
        shared_sizes = _a12_final_shared_members(shared_sizes, {branch for branch, imp in assigned.values()})
    inputs = sum(len(raw) for job in jobs for raw in job["entries"].values())
    _require(all(3 * sum(len(raw) for raw in job["entries"].values()) + 16384 < retained_bytes_per_component
                 for job in jobs), "F5_A12_COMPONENT_STORAGE_ESTIMATE_EXCEEDED")
    patients = len(source["primary_source"]["primary_training_context"]["heldout_ids"])
    cells = patients * len(HORIZONS)
    # The shared input/development/search files already occupy disk, but a
    # new copy is written into the outer ZIP. No existing bytes earn credit
    # against the 60 not-yet-created component directories and archives.
    metadata = (2 * len(canonical_json_bytes(source)) + 1024 * (len(shared_sizes) + 61)
                + sum(4 * len(name.encode("utf-8")) for name in shared_sizes)
                + 128 * 3 * cells + 1024**2)
    # All three final-M20 allocations share the original whole-outer allowance.
    # Completed branches already consume free disk; they receive no credit or
    # independent machine budget when the next branch becomes runnable.
    retention = (60 if task_names is None else len(task_names)) * retained_bytes_per_component
    returned = 0
    if task_names is not None:
        # Workers retain their originals plus one numerical return copy;
        # a complete gather reserves actual incoming numerical copies, not
        # another 60 future models. Neither path credits existing residue.
        returned = retention if task_names else sum(size for name, size in shared_sizes.items() if name.startswith("fits/"))
        metadata += 60 * _A12_FINAL_BATCH_RECORD_LIMIT
    release_bytes = ((len(task_names) or 60) * _A12_FINAL_BATCH_RECORD_LIMIT
                     if task_names is not None else 0)
    # Full worker/file observations do not fit the existing 128-KiB index.
    # Their pinned operational leaf has its own gross allowance, including
    # staging, transport/archive copies and bounded coordinator decoding.
    metadata += release_bytes
    archive = 2 * (sum(shared_sizes.values()) + retention + metadata
                   + (60 * _A12_FINAL_BATCH_RECORD_LIMIT if task_names is not None else 0))
    coordinator = 32 * inputs + 128 * (len(jobs) + 3) * cells
    if task_names is not None:
        coordinator += 32 * (60 * _A12_FINAL_BATCH_RECORD_LIMIT + release_bytes)
    decoded = (max((size for name, size in shared_sizes.items() if name.startswith("fits/")), default=0)
               if task_names == [] else retained_bytes_per_component)
    return {"kind": "OPERATIONAL_ESTIMATE_NOT_MEASURED_PEAK",
        "component_count": 60, "retained_bytes_per_component": retained_bytes_per_component,
        "component_retention_reserved_bytes": retention, "shared_member_bytes": sum(shared_sizes.values()),
        "metadata_reserved_bytes": metadata, "archive_reserved_bytes": archive,
        "coordinator_memory_estimate_bytes": coordinator,
        **({"execution_worker_memory_bytes": execution_worker_memory_bytes}
           if execution_worker_memory_bytes is not None else {}),
        **({"execution_scratch_reserve_bytes": execution_scratch_reserve_bytes}
           if execution_scratch_reserve_bytes is not None else {}),
        **({"assigned_task_names": task_names, "numerical_copy_reserved_bytes": returned} if task_names is not None else {}),
        **({"resource_release_reserved_bytes": release_bytes} if task_names is not None else {}),
        "effective_policy": {**policy,
            "scratch_reserve_bytes": (policy["scratch_reserve_bytes"] + retention + returned + archive + release_bytes
                if execution_scratch_reserve_bytes is None else execution_scratch_reserve_bytes),
            "memory_reserve_bytes": policy["memory_reserve_bytes"] + coordinator,
            "memory_bytes_per_worker": (max(policy["memory_bytes_per_worker"], 32 * decoded)
                if execution_worker_memory_bytes is None else execution_worker_memory_bytes)}}


def _a12_final_batch_execution(executions, components, *, prepared, jobs, shared_sizes, retained, complete=True,
                               release_reports=None, component_native=None, expected_roots=None):
    """The original AAR numerical consumer also checks first-audit accounting."""
    from .f4 import _f45_source_member_sha256
    from .runtime import OPERATIONAL_IDENTITY, resource_admission, validate_resource_release
    names = list(_a12_final_task_coordinates(prepared["outer_fold"]))
    job_names = [job["name"] for job in jobs]
    _require(job_names == [name for name in names if name in job_names]
             and (not complete or job_names == names) and isinstance(components, Mapping)
             and 0 < len(components) <= 60 and set(components) <= set(names)
             and set(components) <= set(job_names)
             and (not complete or set(components) == set(names))
             and isinstance(executions, list) and 0 < len(executions) <= 60,
             "F5_A12_FINAL_BATCH_COMPLETE_SET_REQUIRED")
    source_identity = sha256_bytes(canonical_json_bytes(_f45_source_member_sha256()))
    source_input_sha256 = sha256_bytes(canonical_json_bytes(prepared["source"]))
    development_inputs_sha256 = sha256_bytes(canonical_json_bytes(prepared["branch_development"]))
    _require(isinstance(release_reports, Mapping) and isinstance(component_native, Mapping)
             and set(component_native) == set(components)
             and (expected_roots is None or len(executions) == 1 and isinstance(expected_roots, tuple)
                  and len(expected_roots) == 2 and all(isinstance(path, Path) and path.is_absolute()
                      and ".." not in path.parts for path in expected_roots)),
             "F5_A12_FINAL_BATCH_RELEASE_INVALID")
    seen = set()
    used_reports = set()
    for value in executions:
        _require(isinstance(value, Mapping) and set(value) == {"source_identity", "operational_identity",
            "source_input_sha256", "development_inputs_sha256", "task_names", "components_sha256",
            "resource_observation", "resource_admission", "resource_reservation", "final_model_pool",
            "new_model_fits", "new_model_native_verification_count", "native_model_replay_count",
            "new_mice_chains", "new_stop_fits", "resource_release"}, "F5_A12_FINAL_BATCH_EXECUTION_INVALID")
        active = value["task_names"]
        _require(isinstance(active, list) and active and all(isinstance(name, str) and name in components for name in active)
                 and active == [name for name in names if name in active] and not seen.intersection(active),
                 "F5_A12_FINAL_BATCH_COORDINATES_INVALID")
        _require(value["source_identity"] == source_identity
                 and value["operational_identity"] == OPERATIONAL_IDENTITY
                 and value["source_input_sha256"] == source_input_sha256
                 and value["development_inputs_sha256"] == development_inputs_sha256
                 and value["components_sha256"] == sha256_bytes(canonical_json_bytes({name: components[name] for name in active}))
                 and all(type(value[key]) is int for key in ("new_model_fits", "new_model_native_verification_count",
                     "native_model_replay_count", "new_mice_chains", "new_stop_fits"))
                 and value["new_model_fits"] == value["new_model_native_verification_count"] == len(active)
                 and value["native_model_replay_count"] == value["new_mice_chains"] == value["new_stop_fits"] == 0,
                 "F5_A12_FINAL_BATCH_SOURCE_DRIFT")
        reserved = _a12_final_resource_reservation(prepared["source"], jobs, shared_sizes, retained, task_names=active,
            execution_worker_memory_bytes=MIN_WORKER_MEMORY_BYTES,
            execution_scratch_reserve_bytes=value["resource_reservation"].get("execution_scratch_reserve_bytes"))
        admission = resource_admission(reserved["effective_policy"], value["resource_observation"], legal_tasks=len(active))
        _require(value["resource_reservation"] == reserved and value["resource_admission"] == admission,
                 "F5_A12_FINAL_BATCH_RESOURCE_DRIFT")
        pool = value["final_model_pool"]
        _require(isinstance(pool, Mapping) and set(pool) == {"configured_worker_ceiling", "admitted_worker_ceiling",
            "runnable_task_count", "actual_worker_process_peak", "completed_task_count", "engine_threads", "status"}
            and all(type(pool[key]) is int for key in pool if key != "status")
            and pool["configured_worker_ceiling"] == admission["limits"]["configured"]
            and pool["admitted_worker_ceiling"] == admission["admitted_worker_ceiling"]
            and pool["runnable_task_count"] == pool["completed_task_count"] == len(active)
            and 1 <= pool["actual_worker_process_peak"] <= min(len(active), admission["admitted_worker_ceiling"])
            and pool["engine_threads"] == 1 and pool["status"] == "COMPLETED",
            "F5_A12_FINAL_BATCH_POOL_INVALID")
        pin = value["resource_release"]
        relative = "final-batches/" + sha256_bytes(canonical_json_bytes(active)) + "/resource-release.json"
        _require(isinstance(pin, Mapping) and set(pin) == {"path", "sha256", "size_bytes"}
                 and pin["path"] == relative and relative not in used_reports
                 and type(pin["size_bytes"]) is int and 0 < pin["size_bytes"] <= len(active) * _A12_FINAL_BATCH_RECORD_LIMIT
                 and relative in release_reports and isinstance(release_reports[relative], bytes),
                 "F5_A12_FINAL_BATCH_RELEASE_INVALID")
        raw = release_reports[relative]
        _require(len(raw) == pin["size_bytes"] and sha256_bytes(raw) == pin["sha256"],
                 "F5_A12_FINAL_BATCH_RELEASE_INVALID")
        release = strict_json_bytes(raw)
        future_operations = reserved.get("execution_scratch_reserve_bytes") == 0
        _require(isinstance(release, Mapping) and set(release) == {
            "source_identity", "source_input_sha256", "development_inputs_sha256", "task_names", "components_sha256",
            "native_root", "batch_root", "worker_results", "coordinator", "after_release"}
            | ({"operational_errors"} if future_operations else set())
            and canonical_json_bytes(release) == raw and all(release[key] == value[key] for key in (
                "source_identity", "source_input_sha256", "development_inputs_sha256", "task_names", "components_sha256"))
            and isinstance(release["native_root"], str) and isinstance(release["batch_root"], str),
            "F5_A12_FINAL_BATCH_RELEASE_INVALID")
        if future_operations:
            _require(isinstance(release["operational_errors"], list)
                     and all(isinstance(row, Mapping) and set(row) == {"operation", "error"}
                         and row["operation"] in {"POST_STEP_ADMISSION", "POST_STEP_OBSERVATION"}
                         and isinstance(row["error"], str)
                         and row["error"].startswith("RESOURCE_ADMISSION_ZERO:" if row["operation"] == "POST_STEP_ADMISSION"
                             else "RESOURCE_OBSERVATION_FAILED:") for row in release["operational_errors"])
                     and len(release["operational_errors"]) <= 1, "F5_A12_FINAL_BATCH_RELEASE_INVALID")
        native_root, batch_root = Path(release["native_root"]), Path(release["batch_root"])
        _require(all(path.is_absolute() and ".." not in path.parts and str(path) == release[key]
                 for path, key in ((native_root, "native_root"), (batch_root, "batch_root")))
                 and str(native_root) == value["resource_observation"]["scratch_root"]
                 and batch_root.parent == native_root / "final-batches"
                 and (expected_roots is None or expected_roots == (native_root, batch_root)),
                 "F5_A12_FINAL_BATCH_RELEASE_INVALID")
        workers = release["worker_results"]
        _require(isinstance(workers, Mapping) and set(workers) == {str(index) for index in range(len(active))},
                 "F5_A12_FINAL_BATCH_RELEASE_INVALID")
        for index, worker in workers.items():
            validate_resource_release(worker)
            _require(worker.get("files") == [] and worker["owner"] == "POOL_TASK_RESULT:" + index
                     and worker["released_references"] == ["serialized_result", "task", "received_message"],
                     "F5_A12_FINAL_BATCH_RELEASE_INVALID")
        coordinator = release["coordinator"]
        validate_resource_release(coordinator)
        _require("files" in coordinator and coordinator["owner"] == "AAR_FINAL_BATCH_FILES:" + value["components_sha256"]
                 and coordinator["released_references"] == ["final_component_predictions", "completed_final_callbacks",
                                                            "completed_final_copy_handles"]
                 and coordinator["before"]["started_ns"] >= max(worker["after"]["finished_ns"] for worker in workers.values())
                 and (future_operations or coordinator["reader_scan_status"] == "OBSERVED")
                 and all((future_operations or row["status"] in {"ADVISED", "UNSUPPORTED"})
                         and (row["error"] is None or future_operations and row["error"].startswith((
                             "RESOURCE_READER_SCAN_FAILED:", "RESOURCE_RELEASE_ADVICE_FAILED:")))
                         for row in coordinator["files"]),
                 "F5_A12_FINAL_BATCH_RELEASE_INVALID")
        files = {row["path"]: row["size_bytes"] for row in coordinator["files"]}
        expected_files = {}
        for job in jobs:
            name = job["name"]
            if name not in active:
                continue
            directory = native_root / "fits" / name
            native = component_native[name]
            _require(isinstance(native, Mapping) and set(native) == {"native_archive", "native_expanded_bytes"}
                     and type(native["native_expanded_bytes"]) is int and native["native_expanded_bytes"] > 0
                     and isinstance(native["native_archive"], Mapping) and set(native["native_archive"]) == {"sha256", "size_bytes"}
                     and type(native["native_archive"]["size_bytes"]) is int and native["native_archive"]["size_bytes"] > 0,
                     "F5_A12_FINAL_BATCH_RELEASE_INVALID")
            validate_sha256(native["native_archive"]["sha256"], "a12_final_native_sha256")
            expected_files.update({str(directory / member): len(raw) for member, raw in job["entries"].items()})
            outputs = [str(directory / member) for member in ("model.bin", "baseline.bin", "fit-health.json",
                       "training-prediction.json", "prediction.json")]
            _require(all(member in files and files[member] > 0 for member in outputs)
                     and sum(len(raw) for raw in job["entries"].values()) + sum(files[member] for member in outputs)
                         == native["native_expanded_bytes"], "F5_A12_FINAL_BATCH_RELEASE_INVALID")
            expected_files.update({member: files[member] for member in outputs})
            expected_files[str(directory.with_suffix(".zip"))] = native["native_archive"]["size_bytes"]
            expected_files[str(directory.with_suffix(".numbers.json"))] = components[name]["size_bytes"]
            expected_files[str(batch_root / "fits" / (name + ".numbers.json"))] = components[name]["size_bytes"]
        _require(files == expected_files and isinstance(release["after_release"], Mapping)
                 and set(release["after_release"]) == {"resource_observation", "resource_admission"},
                 "F5_A12_FINAL_BATCH_RELEASE_INVALID")
        after = release["after_release"]
        expected_after = None
        if after["resource_observation"] is None:
            _require(future_operations and len(release["operational_errors"]) == 1
                     and release["operational_errors"][0]["operation"] == "POST_STEP_OBSERVATION",
                     "F5_A12_FINAL_BATCH_RELEASE_INVALID")
        else:
            try:
                expected_after = resource_admission(reserved["effective_policy"], after["resource_observation"], legal_tasks=1)
            except ContractError as error:
                _require(future_operations and str(error).startswith("RESOURCE_ADMISSION_ZERO:")
                         and release["operational_errors"] == [{"operation": "POST_STEP_ADMISSION",
                             "error": str(error)}], "F5_A12_FINAL_BATCH_RELEASE_INVALID")
            else:
                _require(not future_operations or release["operational_errors"] == [], "F5_A12_FINAL_BATCH_RELEASE_INVALID")
            _require(after["resource_observation"]["scratch_root"] == str(native_root), "F5_A12_FINAL_BATCH_RELEASE_INVALID")
        _require(canonical_json_bytes(after["resource_admission"]) == canonical_json_bytes(expected_after),
                 "F5_A12_FINAL_BATCH_RELEASE_INVALID")
        used_reports.add(relative)
        seen.update(active)
    _require(seen == set(components) and used_reports == set(release_reports), "F5_A12_FINAL_BATCH_COMPLETE_SET_REQUIRED")


def _a12_final_component_batches(prepared, jobs, root, shared, retained, *, task_names=None,
                                 batch_root=None, final_batches=None, execution_report=None):
    """Disjoint original final workers, or their complete original numeric read."""
    from .f4 import _f45_source_member_sha256
    from .nested_loco import _write_exact_once
    from .runtime import OPERATIONAL_IDENTITY, observe_execution_resources, resource_admission
    names = list(_a12_final_task_coordinates(prepared["outer_fold"]))
    job_names = [job["name"] for job in jobs]
    shared_sizes = {name: path.stat().st_size for name, path in shared.items()}
    _require(job_names == [name for name in names if name in job_names]
             and (job_names == names if final_batches is not None else bool(job_names))
             and (task_names is None) != (final_batches is None),
             "F5_A12_FINAL_BATCH_SCOPE_INVALID")
    if task_names is not None:
        _require(isinstance(task_names, list) and task_names and all(isinstance(name, str) for name in task_names)
                 and task_names == [name for name in names if name in task_names]
                 and set(task_names) <= set(job_names),
                 "F5_A12_FINAL_BATCH_COORDINATES_INVALID")
        _require(isinstance(batch_root, Path) and batch_root.is_absolute()
                 and batch_root.parent == root / "final-batches"
                 and not batch_root.exists() and not batch_root.is_symlink()
                 and not batch_root.parent.is_symlink(), "F5_A12_FINAL_BATCH_ALREADY_STARTED")
        active = [{**job, "root": str(root / "fits" / job["name"]), "retained_bytes_per_component": retained}
                  for job in jobs if job["name"] in task_names]
        _require(not (root / "fits").is_symlink(), "F5_A12_FINAL_BATCH_ALREADY_STARTED")
        for name in task_names:
            for suffix in ("", ".zip", ".numbers.json"):
                path = root / "fits" / (name + suffix)
                _require(not path.exists() and not path.is_symlink(), "F5_A12_FINAL_COORDINATE_ALREADY_STARTED")
        reservation = _a12_final_resource_reservation(prepared["source"], jobs, shared_sizes, retained, task_names=task_names,
            execution_worker_memory_bytes=MIN_WORKER_MEMORY_BYTES, execution_scratch_reserve_bytes=0)
        observation = observe_execution_resources(root)
        admission = resource_admission(reservation["effective_policy"], observation, legal_tasks=len(active))
        batch_root.mkdir(mode=0o700, parents=True)
        (batch_root / "fits").mkdir(mode=0o700)
        (root / "fits").mkdir(mode=0o700, exist_ok=True)
        record = {"source_identity": sha256_bytes(canonical_json_bytes(_f45_source_member_sha256())),
            "operational_identity": OPERATIONAL_IDENTITY,
            "source_input_sha256": sha256_bytes(canonical_json_bytes(prepared["source"])),
            "development_inputs_sha256": sha256_bytes(canonical_json_bytes(prepared["branch_development"])),
            "task_names": task_names, "components_sha256": None, "resource_reservation": reservation,
            "resource_observation": observation, "resource_admission": admission, "final_model_pool": {},
            "new_model_fits": None, "new_model_native_verification_count": 0,
            "native_model_replay_count": 0, "new_mice_chains": 0, "new_stop_fits": 0, "resource_release": None}
        components, component_native = {}, {}
        release = {key: record[key] for key in ("source_identity", "source_input_sha256",
            "development_inputs_sha256", "task_names", "components_sha256")}
        release.update(native_root=str(root), batch_root=str(batch_root), worker_results={},
                       coordinator=None, after_release=None, operational_errors=[])
        def collect(index, prediction):
            job = active[index]
            path = root / "fits" / (job["name"] + ".numbers.json")
            _require(path.is_file() and not path.is_symlink() and 0 < path.stat().st_size <= retained,
                     "F5_A12_FINAL_NUMBERS_REQUIRED")
            size = path.stat().st_size
            with path.open("rb") as handle:
                raw = handle.read(size + 1)
            _require(len(raw) == size, "F5_A12_FINAL_NUMBERS_REQUIRED")
            numbers = strict_json_bytes(raw)
            native = numbers["native_archive"]
            observed = _replay_ablation_component({**job, "numbers_path": path, "native_archive": native})
            _require(observed == prediction, "F5_A12_OUTER_PREDICTION_REPLAY_MISMATCH")
            archive = root / "fits" / (job["name"] + ".zip")
            _require(archive.is_file() and not archive.is_symlink() and archive.stat().st_size == native["size_bytes"],
                     "F5_A12_FINAL_NUMBERS_NATIVE_REFERENCE_INVALID")
            destination = batch_root / "fits" / path.name
            shutil.copyfile(path, destination)
            components[job["name"]] = {"sha256": sha256_file(path), "size_bytes": path.stat().st_size}
            _require(sha256_file(destination) == components[job["name"]]["sha256"],
                     "F5_A12_FINAL_BATCH_NUMBER_COPY_MISMATCH")
            component_native[job["name"]] = {key: numbers[key] for key in ("native_archive", "native_expanded_bytes")}
            record["new_model_native_verification_count"] = len(components)
        try:
            try:
                produced = _bounded_ordered_spawn(_execute_ablation_component, active,
                    selected_slots=admission["admitted_worker_ceiling"], execution_report=record["final_model_pool"],
                    on_result=collect, resource_release_report=release["worker_results"])
                record["components_sha256"] = sha256_bytes(canonical_json_bytes(components))
                record["new_model_fits"] = len(active)
                from .runtime import observe_step_memory, release_step_resources
                files = []
                for job in active:
                    directory = root / "fits" / job["name"]
                    members = set(job["entries"]) | {"model.bin", "baseline.bin", "fit-health.json",
                              "training-prediction.json", "prediction.json"}
                    _require({path.name for path in directory.iterdir()} == members,
                             "F5_A12_FINAL_BATCH_RELEASE_INVALID")
                    files.extend(directory / name for name in sorted(members))
                    files.extend((directory.with_suffix(".zip"), directory.with_suffix(".numbers.json"),
                                  batch_root / "fits" / (job["name"] + ".numbers.json")))
                before = observe_step_memory()
                del produced
                # Callback verification and copy handles have finished. The
                # input jobs/prepared owner still lives in the outer caller.
                release["coordinator"] = release_step_resources(sorted(files),
                    owner="AAR_FINAL_BATCH_FILES:" + record["components_sha256"], before=before,
                    released_references=["final_component_predictions", "completed_final_callbacks",
                                         "completed_final_copy_handles"])
                release["after_release"] = {"resource_observation": None, "resource_admission": None}
                try:
                    observation_after = observe_execution_resources(root)
                except OSError as error:
                    release["operational_errors"].append({"operation": "POST_STEP_OBSERVATION",
                        "error": "RESOURCE_OBSERVATION_FAILED:" + type(error).__name__ + ":" + str(error)})
                else:
                    release["after_release"]["resource_observation"] = observation_after
                    try:
                        release["after_release"]["resource_admission"] = resource_admission(
                            reservation["effective_policy"], observation_after, legal_tasks=1)
                    except ContractError as error:
                        if not str(error).startswith("RESOURCE_ADMISSION_ZERO:"):
                            raise
                        release["operational_errors"].append({"operation": "POST_STEP_ADMISSION", "error": str(error)})
            finally:
                release["components_sha256"] = record["components_sha256"]
                raw = canonical_json_bytes(release)
                _require(len(raw) <= len(active) * _A12_FINAL_BATCH_RECORD_LIMIT,
                         "F5_A12_FINAL_BATCH_RELEASE_LIMIT_EXCEEDED")
                _write_exact_once(batch_root / "resource-release.json", raw, "F5_A12_FINAL_BATCH_ALREADY_STARTED")
                record["resource_release"] = {
                    "path": "final-batches/" + sha256_bytes(canonical_json_bytes(task_names)) + "/resource-release.json",
                    "sha256": sha256_bytes(raw), "size_bytes": len(raw)}
            _a12_final_batch_execution([record], components, prepared=prepared, jobs=jobs, shared_sizes=shared_sizes,
                retained=retained, complete=False, release_reports={record["resource_release"]["path"]: raw},
                component_native=component_native, expected_roots=(root, batch_root))
            raw = canonical_json_bytes(record)
            _require(len(raw) <= _A12_FINAL_BATCH_RECORD_LIMIT, "F5_A12_FINAL_BATCH_EXECUTION_INVALID")
            _write_exact_once(batch_root / "execution.json", raw, "F5_A12_FINAL_BATCH_ALREADY_STARTED")
        except BaseException:
            # A post-compute release fault does not erase known completed fits
            # or turn their coordinates into a retry allowance.
            _write_exact_once(batch_root / "failure.json", canonical_json_bytes({
                "execution": record, "confirmed_native_audits": components}), "F5_A12_FINAL_BATCH_ALREADY_STARTED")
            raise
        return {"status": "COMPUTED_A12_FINAL_BATCH", "stage_acceptance": False,
            "outer_fold": prepared["outer_fold"], "task_names": task_names,
            "new_model_fits": len(active), "new_model_native_verification_count": len(components),
            "new_mice_chains": 0, "new_stop_fits": 0, "native_model_replay_count": 0,
            "batch_root": str(batch_root), "execution_report": record}
    _require(batch_root is None and isinstance(final_batches, list) and 0 < len(final_batches) <= 60
             and all(isinstance(path, Path) and path.is_absolute() and path.is_dir() and not path.is_symlink()
                     and path.resolve(strict=True) == path for path in final_batches)
             and len(set(final_batches)) == len(final_batches), "F5_A12_FINAL_BATCHES_INVALID")
    paths, records, release_paths = {}, [], {}
    for batch in final_batches:
        record_path = batch / "execution.json"
        _require(record_path.is_file() and not record_path.is_symlink()
                 and 0 < record_path.stat().st_size <= _A12_FINAL_BATCH_RECORD_LIMIT
                 and (batch / "fits").is_dir() and not (batch / "fits").is_symlink(),
                 "F5_A12_FINAL_BATCH_EXECUTION_INVALID")
        for path in (batch / "fits").iterdir():
            name = path.name.removesuffix(".numbers.json")
            _require(path.is_file() and not path.is_symlink() and path.name == name + ".numbers.json"
                     and name in names and name not in paths and 0 < path.stat().st_size <= retained,
                     "F5_A12_FINAL_BATCH_COORDINATES_INVALID")
            paths[name] = path
        records.append(record_path)
        release_path = batch / "resource-release.json"
        _require(release_path.is_file() and not release_path.is_symlink()
                 and 0 < release_path.stat().st_size <= 60 * _A12_FINAL_BATCH_RECORD_LIMIT,
                 "F5_A12_FINAL_BATCH_RELEASE_INVALID")
        release_paths[batch] = release_path
    _require(set(paths) == set(names), "F5_A12_FINAL_BATCH_COMPLETE_SET_REQUIRED")
    _require(sum(path.stat().st_size for path in release_paths.values()) <= 60 * _A12_FINAL_BATCH_RECORD_LIMIT,
             "F5_A12_FINAL_BATCH_RELEASE_LIMIT_EXCEEDED")
    incoming = {f"fits/{name}.numbers.json": path.stat().st_size for name, path in paths.items()}
    reservation = _a12_final_resource_reservation(prepared["source"], jobs, {**shared_sizes, **incoming},
        retained, task_names=[], execution_worker_memory_bytes=MIN_WORKER_MEMORY_BYTES, execution_scratch_reserve_bytes=0)
    observation = observe_execution_resources(root)
    admission = resource_admission(reservation["effective_policy"], observation, legal_tasks=len(jobs))
    executions, release_members = [], {}
    for record_path in records:
        raw = record_path.read_bytes()
        value = strict_json_bytes(raw)
        _require(canonical_json_bytes(value) == raw and isinstance(value, Mapping)
                 and isinstance(value.get("task_names"), list)
                 and all(isinstance(name, str) for name in value["task_names"])
                 and set(value["task_names"]) == {path.name.removesuffix(".numbers.json")
                     for path in (record_path.parent / "fits").iterdir()}, "F5_A12_FINAL_BATCH_EXECUTION_INVALID")
        executions.append(value)
        relative = "final-batches/" + sha256_bytes(canonical_json_bytes(value["task_names"])) + "/resource-release.json"
        _require(relative not in release_members, "F5_A12_FINAL_BATCH_COORDINATES_INVALID")
        release_members[relative] = release_paths[record_path.parent]
    # The initial admission bounded metadata parsing. Once exact canonical
    # leaf names are known, reserve their actual incoming bytes as well as
    # the gross report allowance before opening any full observation leaf.
    incoming.update({name: path.stat().st_size for name, path in release_members.items()})
    reservation = _a12_final_resource_reservation(prepared["source"], jobs, {**shared_sizes, **incoming},
        retained, task_names=[], execution_worker_memory_bytes=MIN_WORKER_MEMORY_BYTES, execution_scratch_reserve_bytes=0)
    observation = observe_execution_resources(root)
    admission = resource_admission(reservation["effective_policy"], observation, legal_tasks=len(jobs))
    release_reports = {}
    for name, path in release_members.items():
        size = incoming[name]
        with path.open("rb") as handle:
            raw = handle.read(size + 1)
        _require(len(raw) == size, "F5_A12_FINAL_BATCH_RELEASE_INVALID")
        release_reports[name] = raw
    components = {name: {"sha256": sha256_file(path), "size_bytes": path.stat().st_size} for name, path in paths.items()}
    component_native = {}
    for name, path in paths.items():
        size = components[name]["size_bytes"]
        with path.open("rb") as handle:
            raw = handle.read(size + 1)
        _require(len(raw) == size, "F5_A12_FINAL_NUMBERS_REQUIRED")
        number = strict_json_bytes(raw)
        component_native[name] = {key: number[key] for key in ("native_archive", "native_expanded_bytes")}
    del number
    _a12_final_batch_execution(executions, components, prepared=prepared, jobs=jobs,
        shared_sizes=shared_sizes, retained=retained, release_reports=release_reports, component_native=component_native)
    executions.sort(key=lambda row: tuple(names.index(name) for name in row["task_names"]))
    active = [{**job, "numbers_path": paths[job["name"]], "retained_bytes_per_component": retained,
               "native_archive": strict_json_bytes(paths[job["name"]].read_bytes())["native_archive"]} for job in jobs]
    execution = {} if execution_report is None else execution_report
    execution.update(resource_reservation=reservation, resource_observation=observation,
        resource_admission=admission, final_batches=executions, numerical_read_pool={})
    rows = _bounded_ordered_spawn(_replay_ablation_component, active,
        selected_slots=admission["admitted_worker_ceiling"], execution_report=execution["numerical_read_pool"])
    # Publish no pooled prediction until every original rich component and
    # every first-audit ledger has passed. Originals remain with their workers.
    _require(not (root / "fits").is_symlink(), "F5_A12_FINAL_BATCH_ALREADY_STARTED")
    (root / "fits").mkdir(mode=0o700, exist_ok=True)
    for name in names:
        destination = root / "fits" / (name + ".numbers.json")
        _write_exact_once(destination, paths[name].read_bytes(), "F5_A12_FINAL_BATCH_NUMBER_COPY_MISMATCH")
        _require(sha256_file(destination) == components[name]["sha256"], "F5_A12_FINAL_BATCH_NUMBER_COPY_MISMATCH")
    for name, raw in release_reports.items():
        destination = root / name
        _require(not destination.parent.is_symlink(), "F5_A12_FINAL_BATCH_RELEASE_INVALID")
        destination.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
        _write_exact_once(destination, raw, "F5_A12_FINAL_BATCH_NUMBER_COPY_MISMATCH")
    return {"rows": rows, "execution": execution,
        "native_members": {f"fits/{job['name']}.zip": job["native_archive"] for job in active}}


def _a12_outer_searches(prepared: Mapping[str, Any], root: Path, *, replay: bool,
                       workers: int | None = None, retain_evidence: bool = False,
                       branch: str | None = None, q_roots: Mapping[str, Path] | None = None,
                       q_batches: Mapping[str, list[Path]] | None = None,
                       continuous_batch_root: Path | None = None,
                       retained_bytes_per_task: int | None = None,
                       q_input_lifecycle: dict[str, Any] | None = None) -> dict[str, Any]:
    from contextlib import nullcontext
    from .f5 import _full_score_scratch
    from .runtime import observe_execution_resources, resource_admission
    family = prepared["family"]
    branches = _a12_branch_names(prepared)
    projected = branches != A12_BRANCHES[1:]
    continuous = continuous_batch_root is not None
    _require(continuous or q_batches is None and retained_bytes_per_task is None,
             "F5_Q_CONTINUOUS_BATCH_SCOPE_INVALID")
    if continuous:
        _require(projected and not replay and not retain_evidence
                 and family in {"RSF", "GBM_COX", "XGBOOST_COX", "COXTIME_SET_A"}
                 and isinstance(q_batches, Mapping) and isinstance(q_roots, Mapping)
                 and not set(q_batches).intersection(q_roots)
                 and set(q_batches) | set(q_roots) == set(branches)
                 and all(isinstance(rows, list) for rows in q_batches.values())
                 and type(retained_bytes_per_task) is int and retained_bytes_per_task > 0
                 and isinstance(continuous_batch_root, Path) and continuous_batch_root.is_absolute()
                 and continuous_batch_root.is_dir() and not continuous_batch_root.is_symlink()
                 and continuous_batch_root.resolve(strict=True) == continuous_batch_root,
                 "F5_Q_CONTINUOUS_BATCH_SCOPE_INVALID")
    _require(q_input_lifecycle is None or isinstance(q_input_lifecycle, dict) and not q_input_lifecycle
             and projected and not retain_evidence and (replay or q_roots is not None),
             "F5_A12_Q_INPUT_LIFECYCLE_SCOPE_INVALID")
    _require(branch is None or projected and branch in branches, "F5_A12_SEARCH_BRANCH_INVALID")
    available = _a12_estimable_branches(prepared)
    active = available if branch is None else (branch,)
    _require(set(active) <= set(available), "F5_A12_NONESTIMABLE_BRANCH_INVALID")
    _require(q_roots is None or projected and not replay and family in {
        "RSF", "GBM_COX", "XGBOOST_COX", "COXTIME_SET_A"} and isinstance(q_roots, Mapping)
        and (set(q_roots) <= set(branches) if continuous else set(q_roots) == set(branches))
        and all(isinstance(path, Path) and path.is_absolute()
            and path.is_dir() and not path.is_symlink() and path.resolve(strict=True) == path
            for path in q_roots.values()), "F5_A12_Q_RESULT_SCOPE_INVALID")
    if projected:
        _require(workers is None and set(active) <= set(prepared.get("branch_development", {})) <= set(branches),
                 "F5_A12_BRANCH_DEVELOPMENT_OR_CPU_INVALID")
        for branch in active:
            _a12_branch_search_inputs(prepared, branch)
    if family in _A12_FIXED_FAMILIES:
        return {}
    if projected and q_roots is not None:
        workers = resource_admission({**prepared["source"]["resource_policy"],
            "memory_bytes_per_worker": MIN_WORKER_MEMORY_BYTES, "scratch_reserve_bytes": 0},
            observe_execution_resources(root),
            legal_tasks=320)["admitted_worker_ceiling"]
    search = _a12_elastic_search_program if family == "ELASTIC_NET_COX" else _a12_complex_search_program
    if not replay:
        (root / "search").mkdir(mode=0o700, exist_ok=active != branches)
        _require(not (root / "search").is_symlink(), "F5_A12_NATIVE_SEARCH_REQUIRED")
    # Each branch's inner pool ends before the next search or final fits.
    with _full_score_scratch(root) if projected else nullcontext():
        if q_roots is not None:
            from .f4_compact import _full_pipeline_q_numerical_members
            results = {}
            for name in active:
                owners = {} if q_input_lifecycle is not None else None
                if owners is not None:
                    q_input_lifecycle[name] = owners
                if continuous and name in q_batches:
                    owner = continuous_batch_root / name
                    _require(not owner.exists() and not owner.is_symlink(),
                             "F5_Q_BATCH_ALREADY_STARTED")
                    owner.mkdir(mode=0o700, exist_ok=True)
                    results[name] = search(prepared, name, root / "search" / name,
                        replay=False, workers=workers,
                        batch_options={"prepare_only": True, "task_ids": None, "batch_root": None,
                            "q_batches": q_batches[name], "retained_bytes_per_task": retained_bytes_per_task},
                        continuous_batch_root=owner,
                        **({"q_input_lifecycle": owners} if owners is not None else {}))
                    _require(results[name].get("execution_scope") == "F5_A12_SEARCH",
                             "F5_A12_Q_RESULT_SOURCE_INVALID")
                    continue
                # Reconstruct through the same rich Q consumer before its
                # numerical projection becomes input to the original M20.
                results[name] = search(prepared, name, q_roots[name], replay=True,
                    workers=workers, retain_evidence=retain_evidence,
                    **({"q_input_lifecycle": owners} if owners is not None else {}))
                members, _ = _full_pipeline_q_numerical_members(q_roots[name])
                policy = prepared["source"]["resource_policy"]
                observation = observe_execution_resources(root)
                resource_admission({**policy, "memory_bytes_per_worker": MIN_WORKER_MEMORY_BYTES,
                    "scratch_reserve_bytes": 0}, observation, legal_tasks=1)
                pending = sum(path.stat().st_size for path in members.values()) + 4096 * (len(members) + 1)
                _require(observation["scratch_available_bytes"] >= pending,
                         "F5_A12_PREPARATION_SPACE_INSUFFICIENT")
                destination = root / "search" / name
                _require(not destination.exists() and not destination.is_symlink(), "F5_A12_NATIVE_SEARCH_REQUIRED")
                destination.mkdir(mode=0o700, exist_ok=True)
                for member, path in members.items():
                    output = destination / member
                    output.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
                    shutil.copyfile(path, output)
                _full_pipeline_q_numerical_members(destination)
                from .runtime import release_f45_cumulative_files
                release_f45_cumulative_files(list(members.values()) +
                    [p for p in destination.rglob("*") if p.is_file()],
                    owner="AAR_SEARCH_READBACK:" + name, report_root=destination,
                    released_references=["completed_branch_search"])
            return results
        results = {}
        for name in active:
            owners = {} if q_input_lifecycle is not None else None
            if owners is not None:
                q_input_lifecycle[name] = owners
            # Complex Q remeasures each native batch. Do not pass a stale
            # branch-entry memory ceiling as a permanent user limit.
            branch_workers = (resolve_pool_workers(None) if family != "ELASTIC_NET_COX" else
                resource_admission({**prepared["source"]["resource_policy"],
                    "memory_bytes_per_worker": MIN_WORKER_MEMORY_BYTES, "scratch_reserve_bytes": 0},
                    observe_execution_resources(root), legal_tasks=320)["admitted_worker_ceiling"])
            results[name] = search(prepared, name, root / "search" / name, replay=replay,
                workers=branch_workers, retain_evidence=retain_evidence,
                **({"q_input_lifecycle": owners} if owners is not None else {}))
            from .runtime import release_completed_files, release_f45_cumulative_files
            branch_root = root / "search" / name
            completed_files = [p for p in branch_root.rglob("*")
                if p.is_file() and "resource-release" not in p.parts]
            release_completed_files(completed_files, owner="AAR_SEARCH:" + name,
                report_root=branch_root, alias_roots=[root], released_references=["completed_branch_search"])
        return results


def _validate_a12_selector_prepare_execution(result: Mapping[str, Any], *, input_source: Mapping[str, Any],
        source_sha256: str, executor_source_identity: str) -> None:
    """Consume the original prepare stdout's operational record, not a science seal."""
    from .f4 import _f45_source_member_sha256
    from .runtime import resource_admission, validate_resource_release
    failure = "F5_A12_SELECTOR_PREPARE_EXECUTION_INVALID"
    report = result.get("execution_report")
    current_executor = executor_source_identity == sha256_bytes(canonical_json_bytes(_f45_source_member_sha256()))
    worker_budget = report.get("execution_worker_memory_bytes") if isinstance(report, Mapping) else None
    future_operations = isinstance(report, Mapping) and "execution_scratch_reserve_bytes" in report
    _require(not future_operations or current_executor
             and type(report["execution_scratch_reserve_bytes"]) is int
             and report["execution_scratch_reserve_bytes"] == 0, failure)
    _require(isinstance(report, Mapping) and (type(worker_budget) is int and worker_budget in RECORDED_WORKER_MEMORY_BYTES
             if current_executor else "execution_worker_memory_bytes" not in report), failure)
    _require(result.get("status") == "PREPARED_SELECTOR_INPUTS" and result.get("stage_acceptance") is False
             and all(type(result.get(key)) is int and result[key] == 0 for key in
                     ("selector_path_count", "glmnet_call_count", "new_mice_chains", "final_model_fits"))
             and len(canonical_json_bytes(result)) <= 32 * 1024**2
             and isinstance(report, Mapping) and set(report) == {
                 "source_identity", "outer_fold", "projected_input_identity_sha256", "input_archive_sha256",
                 "partition_inputs_sha256", "resource_policy", "effective_policy", "resource_observation",
                 "resource_admission", "resource_release", "after_release"}
                 | ({"execution_worker_memory_bytes"} if current_executor else set())
                 | ({"execution_scratch_reserve_bytes"} if future_operations else set()), failure)
    policy = input_source["resource_policy"]
    effective = {**policy, "memory_reserve_bytes": policy["memory_reserve_bytes"] + 32 * 32 * 1024**2,
                 "scratch_reserve_bytes": policy["scratch_reserve_bytes"] + 32 * 1024**2}
    if worker_budget is not None:
        effective["memory_bytes_per_worker"] = worker_budget
    if future_operations:
        effective["scratch_reserve_bytes"] = 0
    _require(report["source_identity"] == executor_source_identity
             and type(report["outer_fold"]) is int and report["outer_fold"] == input_source["outer_fold"]
             and report["projected_input_identity_sha256"] == input_source["identity_sha256"]
             and report["input_archive_sha256"] == source_sha256
             and report["partition_inputs_sha256"] == result["partition_inputs_sha256"]
             and canonical_json_bytes(report["resource_policy"]) == canonical_json_bytes(policy)
             and canonical_json_bytes(report["effective_policy"]) == canonical_json_bytes(effective)
             and isinstance(report["resource_release"], Mapping)
             and set(report["resource_release"]) == {"selector_inputs", "materialized_inputs"}
             and isinstance(report["after_release"], Mapping)
             and set(report["after_release"]) == {"resource_observation", "resource_admission"}, failure)
    for observed in (report, report["after_release"]):
        _require(canonical_json_bytes(observed["resource_admission"]) == canonical_json_bytes(resource_admission(
            effective, observed["resource_observation"], legal_tasks=1)), failure)
    roots = []
    for name, prefix, owner in (("selector_inputs", "a12-selector-inputs-", "AAR_SELECTOR_PREPARE_INPUTS"),
                               ("materialized_inputs", "a12-selector-source-", "AAR_SELECTOR_PREPARE_SOURCE")):
        row = report["resource_release"][name]
        _require(isinstance(row, Mapping) and set(row) == {"temporary_root", "resource_release"}
                 and isinstance(row["temporary_root"], str), failure)
        root = Path(row["temporary_root"])
        _require(root.is_absolute() and str(root) == row["temporary_root"] and ".." not in root.parts
                 and root.name.startswith(prefix) and len(root.name) > len(prefix), failure)
        release = row["resource_release"]
        validate_resource_release(release)
        _require("files" in release and release["files"]
                 and release["owner"] == owner + ":" + str(input_source["outer_fold"]) + ":"
                     + input_source["identity_sha256"], failure)
        for member in release["files"]:
            path = Path(member["path"])
            _require(str(path) == member["path"] and ".." not in path.parts and root in path.parents, failure)
        roots.append(root)
    _require(roots[0] != roots[1] and roots[0].parent == roots[1].parent
             and all(Path(observed["resource_observation"]["scratch_root"]) == roots[0].parent
                     for observed in (report, report["after_release"])), failure)


def _validate_a12_selector_gather_execution(value: Mapping[str, Any], *, input_source: Mapping[str, Any],
        source_sha256: str, executor_source_identity: str, selector_root: Path,
        expected_phase: str, expected_selector_result: Mapping[str, Any],
        expected_selector_source: Mapping[str, Any],
        expected_partitions: list[dict[str, Any]]) -> None:
    """Original gather CLI/collector check; the sealed scientific child is unchanged."""
    from .f4 import _f45_source_member_sha256
    from .f5 import _validate_selector_input_release
    from .runtime import resource_admission
    failure = "F5_A12_SELECTOR_GATHER_EXECUTION_INVALID"
    _require(isinstance(value, Mapping) and set(value) == {
        "status", "stage_acceptance", "selector_result", "execution_report"}
        and value["status"] == "COMPUTED_SELECTOR_GATHER" and value["stage_acceptance"] is False
        and canonical_json_bytes(value["selector_result"]) == canonical_json_bytes(expected_selector_result)
        and len(canonical_json_bytes(value)) <= 32 * 1024**2
        and len((json.dumps(value, sort_keys=True) + "\n").encode()) <= 32 * 1024**2, failure)
    report = value["execution_report"]
    current_executor = executor_source_identity == sha256_bytes(canonical_json_bytes(_f45_source_member_sha256()))
    worker_budget = report.get("execution_worker_memory_bytes") if isinstance(report, Mapping) else None
    future_operations = isinstance(report, Mapping) and "execution_scratch_reserve_bytes" in report
    _require(not future_operations or current_executor
             and type(report["execution_scratch_reserve_bytes"]) is int
             and report["execution_scratch_reserve_bytes"] == 0, failure)
    _require(isinstance(report, Mapping) and (type(worker_budget) is int and worker_budget in RECORDED_WORKER_MEMORY_BYTES
             if current_executor else "execution_worker_memory_bytes" not in report), failure)
    policy = input_source["resource_policy"]
    effective = {**policy, "memory_reserve_bytes": policy["memory_reserve_bytes"] + 32 * 32 * 1024**2,
                 "scratch_reserve_bytes": policy["scratch_reserve_bytes"] + 64 * 1024**2}
    if worker_budget is not None:
        effective["memory_bytes_per_worker"] = worker_budget
    if future_operations:
        effective["scratch_reserve_bytes"] = 0
    _require(isinstance(report, Mapping) and set(report) == {"source_identity", "source", "phase", "pid",
        "selector_root", "selector_result_sha256",
        "resource_policy", "effective_policy", "resource_observation", "resource_admission", "input_lifecycle"}
        | ({"execution_worker_memory_bytes"} if current_executor else set())
        | ({"execution_scratch_reserve_bytes"} if future_operations else set())
        and report["source_identity"] == executor_source_identity and type(report["pid"]) is int and report["pid"] > 0
        and report["phase"] == expected_phase and expected_phase in {"coarse", "fine"}
        and selector_root.is_absolute() and report["selector_root"] == str(selector_root)
        and report["selector_result_sha256"] == sha256_bytes(canonical_json_bytes(expected_selector_result))
        and canonical_json_bytes(report["source"]) == canonical_json_bytes(expected_selector_source)
        and type(report["source"]["context"]) is int and report["source"]["context"] == input_source["outer_fold"]
        and report["source"]["inherited_family"] == input_source["family"]
        and report["source"]["primary_development_lock_sha256"]
            == input_source["primary_source"]["primary_development_lock"]["identity_sha256"]
        and canonical_json_bytes(report["resource_policy"]) == canonical_json_bytes(policy)
        and canonical_json_bytes(report["effective_policy"]) == canonical_json_bytes(effective)
        and report["resource_observation"]["scratch_root"] == str(selector_root.parent)
        and canonical_json_bytes(report["resource_admission"]) == canonical_json_bytes(resource_admission(
            effective, report["resource_observation"], legal_tasks=1)), failure)
    _validate_selector_input_release(report["input_lifecycle"], execution=report,
        owner_parent=selector_root.parent, owner_pid=report["pid"],
        expected_partition_sha256=sha256_bytes(canonical_json_bytes(expected_partitions)),
        expected_partitions=expected_partitions, expected_input_binding={"input_archive_sha256": source_sha256,
            "projected_input_identity_sha256": input_source["identity_sha256"],
            "partition_inputs_sha256": sha256_bytes(canonical_json_bytes(expected_partitions))})


def _validate_a12_q_input_execution(value: Mapping[str, Any], *, input_source: Mapping[str, Any],
        source_sha256: str, executor_source_identity: str, q_root: Path,
        q_input: Mapping[str, Any], q_source: Mapping[str, Any],
        expected_search_result_sha256: str, selector_root: Path | None,
        selector_binding: Mapping[str, Any], selector_partitions: list[dict[str, Any]] | None,
        expected_q_batches: Mapping[str, Any] | None = None, expected_batch_root: Path | None = None,
        retained_executor_source_bundle: Path | None = None,
        retained_primary_source_bundle: Path | None = None) -> None:
    """Read the original Q call's input-release report, separately from Q numbers.

    Its file table never enters unit/batch scientific metadata. The original
    Q numerical consumer still owns candidate, STOP and first-audit acceptance.
    """
    from .nested_loco import AAR_ESTIMANDS, WITHIN_FAMILY_NO_AAR_REDEVELOPMENT
    from .runtime import resource_admission, validate_resource_release
    failure = "F5_A12_Q_INPUT_EXECUTION_INVALID"
    _require(isinstance(value, Mapping) and value.get("status") in {
        "PREPARED_Q_BATCH", "COMPUTED_Q_BATCH", "COMPUTED_Q_NUMERICAL_BATCH", "COMPUTED_Q_SEARCH"}
        and value.get("stage_acceptance") is False and value.get("native_search_root") == str(q_root)
        and len(canonical_json_bytes(value)) <= 32 * 1024**2
        and len((json.dumps(value, sort_keys=True) + "\n").encode()) <= 32 * 1024**2, failure)
    report = value.get("execution_report")
    from .f4 import _f45_source_member_sha256
    current_identity = sha256_bytes(canonical_json_bytes(_f45_source_member_sha256()))
    worker_budget = report.get("execution_worker_memory_bytes") if isinstance(report, Mapping) else None
    retained_refit_receipts = (isinstance(report, Mapping)
        and executor_source_identity == "cb0f1fff3adf46cb2187c5006dd727c8994e3cc7acabd26f20976b8944c4317b"
        and sha256_bytes(canonical_json_bytes(report))
            == "4218a603c608cec9501d939578fdb4a7958dce419d4dcf340a454d776e72b70d")
    _require((retained_executor_source_bundle is None) == (retained_primary_source_bundle is None)
        or retained_refit_receipts and retained_executor_source_bundle is not None
            and retained_primary_source_bundle is None, failure)
    retained_two_gib = False
    if retained_refit_receipts and retained_executor_source_bundle is not None:
        # Use the same finite old-Python producer proof as its Q batch reader.
        # The exact original receipt stays bound above; neither its producer
        # nor its historical resource formula is replaced by the executor.
        from .f4 import _retained_full0_source_members
        _require(retained_primary_source_bundle is None and value["status"] == "PREPARED_Q_BATCH", failure)
        producer = _retained_full0_source_members(retained_executor_source_bundle, aar_python_q=True)
        _require(sha256_bytes(canonical_json_bytes(producer)) == executor_source_identity, failure)
        retained_two_gib = True
    elif retained_executor_source_bundle is not None:
        from .f4 import _retained_gbm_q_source_members
        proved = sha256_bytes(canonical_json_bytes(_retained_gbm_q_source_members(
            retained_executor_source_bundle, retained_primary_source_bundle)))
        _require(proved == executor_source_identity
                 == "2cc45b03c24e50859910111b64e0bd54b17fda87e9d15efd9c8e4428f012ae19", failure)
        retained_two_gib = True
    if executor_source_identity == current_identity or retained_two_gib:
        _require(type(worker_budget) is int and worker_budget in RECORDED_WORKER_MEMORY_BYTES, failure)
    else:
        _require(isinstance(report, Mapping) and "execution_worker_memory_bytes" not in report, failure)
    _require(isinstance(report, Mapping) and set(report) == {
        "source_identity", "outer_fold", "family", "branch", "pid", "input_archive_sha256",
        "projected_input_identity_sha256", "q_root", "q_input", "q_source_sha256", "result_sha256",
        "selector_root", "selector_binding", "resource_policy", "effective_policy",
        "resource_observation", "resource_admission", "input_lifecycle", "after_release", "report_path"}
        | ({"q_batches"} if value["status"] == "COMPUTED_Q_NUMERICAL_BATCH" else set())
        | ({"post_batch_write"} if "post_batch_write" in report else set())
        | ({"execution_worker_memory_bytes"} if worker_budget is not None else set())
        | ({"execution_scratch_reserve_bytes"} if "execution_scratch_reserve_bytes" in report else set())
        | ({"operational_errors"} if "operational_errors" in report else set()), failure)
    branch = report["branch"]
    no_aar = branch == WITHIN_FAMILY_NO_AAR_REDEVELOPMENT
    policy = input_source["resource_policy"]
    effective = {**policy, "memory_reserve_bytes": policy["memory_reserve_bytes"] + 32 * 32 * 1024**2,
                 "scratch_reserve_bytes": policy["scratch_reserve_bytes"] + 64 * 1024**2}
    if worker_budget is not None:
        effective["memory_bytes_per_worker"] = worker_budget
    if "execution_scratch_reserve_bytes" in report:
        _require(executor_source_identity == current_identity
                 and type(report["execution_scratch_reserve_bytes"]) is int
                 and report["execution_scratch_reserve_bytes"] == 0, failure)
        effective["scratch_reserve_bytes"] = 0
    if "operational_errors" in report:
        _require(isinstance(report["operational_errors"], list)
                 and all(isinstance(row, Mapping) and set(row) == {"operation", "error"}
                     and isinstance(row["operation"], str) and isinstance(row["error"], str)
                     for row in report["operational_errors"]), failure)
    _require(branch in AAR_ESTIMANDS and q_source["branch"] == branch
        and report["source_identity"] == executor_source_identity
        and type(report["pid"]) is int and report["pid"] > 0
        and type(report["outer_fold"]) is int and report["outer_fold"] == input_source["outer_fold"]
        and report["family"] == input_source["family"] == q_source["family"]
        and q_source["outer_fold"] == report["outer_fold"]
        and report["input_archive_sha256"] == source_sha256
        and report["projected_input_identity_sha256"] == input_source["identity_sha256"]
        and q_source["source"]["identity_sha256"] == input_source["identity_sha256"]
        and report["q_root"] == str(q_root) and q_root.is_absolute() and ".." not in q_root.parts
        and canonical_json_bytes(report["q_input"]) == canonical_json_bytes(q_input)
        and set(q_input) == {"sha256", "size_bytes"}
        and type(q_input["size_bytes"]) is int and 0 < q_input["size_bytes"] <= 16 * 1024**2
        and report["q_source_sha256"] == sha256_bytes(canonical_json_bytes(q_source))
        and report["result_sha256"] == expected_search_result_sha256 == sha256_bytes(canonical_json_bytes(
            {key: item for key, item in value.items() if key != "execution_report"}))
        and report["selector_root"] == (str(selector_root) if no_aar else None)
        and (selector_root is not None) == no_aar
        and canonical_json_bytes(report["selector_binding"]) == canonical_json_bytes(selector_binding)
        and set(selector_binding) == ({"partitions.json", "selector.json", "development-input.json"} if no_aar else set())
        and canonical_json_bytes(report["resource_policy"]) == canonical_json_bytes(policy)
        and canonical_json_bytes(report["effective_policy"]) == canonical_json_bytes(effective), failure)
    validate_sha256(q_input["sha256"], "a12_q_input_sha256")
    validate_sha256(expected_search_result_sha256, "a12_q_original_result_sha256")
    for pin in selector_binding.values():
        _require(isinstance(pin, Mapping) and set(pin) == {"sha256", "size_bytes"}
                 and type(pin["size_bytes"]) is int and 0 < pin["size_bytes"] <= 32 * 1024**2, failure)
        validate_sha256(pin["sha256"], "a12_q_selector_member_sha256")
    if value["status"] == "PREPARED_Q_BATCH":
        _require(type(value.get("new_model_fits")) is int and value["new_model_fits"] == 0, failure)
    if value["status"] == "COMPUTED_Q_BATCH":
        _require(canonical_json_bytes(value["execution"]["input"]) == canonical_json_bytes(q_input)
                 and value["execution"]["source_identity"] == executor_source_identity, failure)
    if "post_batch_write" in report:
        # The existing input-release observations follow the completed call.
        # Bind their write boundary without changing its sealed batch report.
        pin = report["post_batch_write"]
        _require(value["status"] == "COMPUTED_Q_BATCH" and isinstance(pin, Mapping)
                 and set(pin) == {"path", "sha256", "size_bytes"}
                 and isinstance(expected_batch_root, Path) and expected_batch_root.is_absolute()
                 and ".." not in expected_batch_root.parts
                 and value["batch_root"] == str(expected_batch_root)
                 and pin["path"] == str(expected_batch_root / "execution.json")
                 and type(pin["size_bytes"]) is int and 0 < pin["size_bytes"] <= 16 * 1024**2, failure)
        raw = canonical_json_bytes(value["execution"])
        _require(pin["sha256"] == sha256_bytes(raw) and pin["size_bytes"] == len(raw), failure)
    if value["status"] == "COMPUTED_Q_NUMERICAL_BATCH":
        from .f5 import _validate_q_gbm_loss_consumption
        execution = value["execution"]
        _require(execution["source_identity"] == "73c9698680d7e1d054d26a1bf569855d6aac443e8750945736c67d9d09567c47"
                 and canonical_json_bytes(execution["input"]) == canonical_json_bytes(q_input)
                 and execution["task_ids"] == value["task_ids"] and execution["phase"] == value["phase"]
                 and input_source["family"] == "GBM_COX"
                 and all(type(value.get(key)) is int and value[key] == 0
                         for key in ("new_model_fits", "new_first_native_audits"))
                 and type(value.get("new_loss_evaluations")) is int
                 and value["new_loss_evaluations"] == len(value["task_ids"]), failure)
        _require(isinstance(expected_q_batches, Mapping) and 0 < len(expected_q_batches) <= 2600
                 and canonical_json_bytes(report["q_batches"]) == canonical_json_bytes(expected_q_batches)
                 and isinstance(expected_batch_root, Path) and value.get("batch_root") == str(expected_batch_root), failure)
        for path, pin in expected_q_batches.items():
            _require(isinstance(path, str) and Path(path).is_absolute() and str(Path(path)) == path
                     and ".." not in Path(path).parts and isinstance(pin, Mapping)
                     and set(pin) == {"sha256", "size_bytes"} and type(pin["size_bytes"]) is int
                     and 0 < pin["size_bytes"] <= 16 * 1024**2, failure)
            validate_sha256(pin["sha256"], failure)
        selected = [path for path, pin in expected_q_batches.items()
                    if pin == execution["numerical_consumption"]["producer_execution"]]
        _require(len(selected) == 1, failure)
        _validate_q_gbm_loss_consumption({key: row for key, row in execution.items() if key != "numerical_consumption"},
            execution["numerical_consumption"], executor_source_identity=executor_source_identity, policy=policy,
            expected_source_root=Path(selected[0]), expected_destination_root=expected_batch_root,
            retained_executor_source_bundle=retained_executor_source_bundle,
            retained_primary_source_bundle=retained_primary_source_bundle)
    if no_aar:
        _require(isinstance(selector_partitions, list) and len(selector_partitions) == 16
            and selector_binding["partitions.json"] == {
                "sha256": sha256_bytes(canonical_json_bytes(selector_partitions)),
                "size_bytes": len(canonical_json_bytes(selector_partitions))}, failure)
    else:
        _require(selector_partitions is None, failure)
    inputs = report["input_lifecycle"]
    owners = {"q_program": ("a12-q-consume-", "a12-q-replay-"), "materialized_inputs": ("a12-q-source-",)}
    if no_aar:
        owners = {"selector_program": ("nested-full-selector-replay-",),
                  "selector_inputs": ("a12-selector-inputs-",), **owners}
    _require(isinstance(inputs, Mapping) and set(inputs) == set(owners)
        and (report["after_release"] is None or isinstance(report["after_release"], Mapping)
        and set(report["after_release"]) == {"resource_observation", "resource_admission"}), failure)
    roots = []
    for name, prefixes in owners.items():
        row = inputs[name]
        _require(isinstance(row, Mapping) and set(row) == {"temporary_root", "resource_release"}
                 | ({"numerical_phase_releases"} if name == "q_program" and "numerical_phase_releases" in row else set())
                 and isinstance(row["temporary_root"], str), failure)
        if "numerical_phase_releases" in row:
            from .f5 import _a12_q_stop_phase
            phases = row["numerical_phase_releases"]
            _require(report["family"] == "GBM_COX" and isinstance(phases, Mapping)
                     and set(phases) <= {_a12_q_stop_phase(stage)[0]
                         for stage in ("S1", "S2", "S3A", "S3B1", "S3B2")}, failure)
            for phase, observed in phases.items():
                validate_resource_release(observed)
                _require(observed["owner"] == "Q_NUMERICAL_PHASE:" + phase + ":" + q_input["sha256"]
                         and (observed["pid"] if observed.get("status") == "UNKNOWN"
                              else observed["before"]["pid"]) == report["pid"], failure)
        owned = Path(row["temporary_root"])
        parent = selector_root.parent if name.startswith("selector_") else q_root.parent
        _require(owned.is_absolute() and str(owned) == row["temporary_root"] and ".." not in owned.parts
                 and owned.parent == parent and any(owned.name.startswith(prefix)
                     and len(owned.name) > len(prefix) for prefix in prefixes), failure)
        release = row["resource_release"]
        validate_resource_release(release)
        if release.get("status") == "UNKNOWN":
            _require(release["owner"] == "AAR_Q_INPUTS:" + str(report["outer_fold"]) + ":" + branch + ":"
                     + name + ":" + q_input["sha256"], failure)
            roots.append(owned)
            continue
        # The user authorized only these two sealed outer6 S3A REFIT-input
        # receipts after the original once-only call failed its final reader.
        # Preserve UNKNOWN and the failed call; never repeat their reclamation.
        retained_selector_unknown = (
            name in {"selector_inputs", "selector_program"}
            and release.get("reader_scan_status") == "UNKNOWN"
            and sha256_bytes(canonical_json_bytes(report))
                == "4218a603c608cec9501d939578fdb4a7958dce419d4dcf340a454d776e72b70d"
            and len(release.get("files", ())) == {"selector_inputs": 20, "selector_program": 15}[name])
        _require("files" in release and (name == "q_program" or release["files"])
            and release["owner"] == "AAR_Q_INPUTS:" + str(report["outer_fold"]) + ":" + branch + ":"
                + name + ":" + q_input["sha256"]
            and release["before"]["pid"] == report["pid"]
            and release["released_references"] == ["completed_q_callers", "materialized_a12_inputs"]
            and all(str(Path(member["path"])) == member["path"] and ".." not in Path(member["path"]).parts
                    and owned in Path(member["path"]).parents for member in release["files"]), failure)
        relative_files = {Path(member["path"]).relative_to(owned).as_posix(): member["size_bytes"]
                          for member in release["files"]}
        if name == "selector_program":
            _require(relative_files == {f"validation-responses/inner-{index:02d}.csv": part["evaluation_response"]["size_bytes"]
                for index, part in enumerate(selector_partitions[:-1], 1)}, failure)
        elif name == "selector_inputs":
            _require(relative_files == {"outer-training/" + member["name"]: member["size_bytes"]
                for member in selector_partitions[-1]["covariates"]["members"]}, failure)
        roots.append(owned)
    _require(len(set(roots)) == len(roots) and all(
        not left.is_relative_to(right) for left in roots for right in roots if left != right), failure)
    _require(report["report_path"] == str(q_root / (
        "input-execution-" + Path(inputs["materialized_inputs"]["temporary_root"]).name + ".json")), failure)
    for observed in (report, report["after_release"]):
        if observed is None or observed is not report and observed["resource_admission"] is None:
            continue
        _require(observed["resource_observation"]["scratch_root"] == str(q_root.parent)
            and canonical_json_bytes(observed["resource_admission"]) == canonical_json_bytes(resource_admission(
                effective, observed["resource_observation"], legal_tasks=1)), failure)


def _validate_a12_final_input_execution(raw: bytes, *, binding: Mapping[str, Any],
        result_pin: Mapping[str, Any], policy: Mapping[str, Any],
        expected_owners: Mapping[str, Any] | None = None,
        expected_pin: Mapping[str, Any] | None = None,
        loader_report: bool = False) -> dict[str, Any]:
    """Read one original final caller's diagnostics, never its scientific result.

    The live owner supplies its independently enumerated files. A transporter
    instead supplies the original call/collector's independent byte pin; it
    cannot infer expected input, result or executor identity from this leaf.
    """
    from .f4 import _f45_source_member_sha256
    from .nested_loco import AAR_ESTIMANDS
    from .runtime import resource_admission, validate_resource_release
    failure = "F5_A12_FINAL_INPUT_EXECUTION_INVALID"
    _require(type(loader_report) is bool and (not loader_report or expected_pin is not None
                 and binding.get("operation") == "OUTER_REPLAY")
             and isinstance(raw, bytes) and 0 < len(raw) <= (64 if loader_report or binding.get("operation") == "OUTER_REPLAY" else 32) * 1024**2
             and (expected_owners is not None or expected_pin is not None), failure)
    if expected_pin is not None:
        _require(isinstance(expected_pin, Mapping) and set(expected_pin) == {"sha256", "size_bytes"}
                 and type(expected_pin["size_bytes"]) is int
                 and expected_pin["size_bytes"] == len(raw)
                 and expected_pin["sha256"] == sha256_bytes(raw), failure)
    value = strict_json_bytes(raw)
    _require(canonical_json_bytes(value) == raw, failure)
    if loader_report:
        _require(isinstance(value, Mapping) and isinstance(value.get("input_execution"), Mapping), failure)
        value = value["input_execution"]
        raw = canonical_json_bytes(value)
        _require(len(raw) <= 64 * 1024**2, failure)
    keys = {"executor_source_identity", "operation", "outer_fold", "family", "task_names",
            "input_archive", "projected_input", "projected_input_identity_sha256", "work_root"}
    current_executor = binding.get("executor_source_identity") == sha256_bytes(canonical_json_bytes(_f45_source_member_sha256()))
    worker_budget = value.get("execution_worker_memory_bytes") if isinstance(value, Mapping) else None
    if not current_executor and binding.get("operation") == "OUTER_REPLAY" and worker_budget is not None:
        from .f5 import _f45_score_reuse_authorities
        executors, _ = _f45_score_reuse_authorities()
        # This is the original same-run reader's field dialect, not a new
        # executor label. Unknown producers still fail the native source chain.
        current_executor = binding.get("executor_source_identity") in executors.values()
    future_operations = isinstance(value, Mapping) and "execution_scratch_reserve_bytes" in value
    if future_operations:
        _require(current_executor and type(value["execution_scratch_reserve_bytes"]) is int
                 and value["execution_scratch_reserve_bytes"] == 0
                 and isinstance(value.get("operational_errors"), list)
                 and all(isinstance(row, Mapping) and set(row) == {"operation", "error"}
                     and row["operation"] in {"POST_STEP_ADMISSION", "POST_STEP_OBSERVATION", "DISPOSABLE_INPUT_REMOVAL"}
                     and isinstance(row["error"], str) and row["error"] for row in value["operational_errors"]), failure)
    _require(isinstance(value, Mapping) and (type(worker_budget) is int and worker_budget in RECORDED_WORKER_MEMORY_BYTES
             if current_executor else "execution_worker_memory_bytes" not in value), failure)
    _require(isinstance(binding, Mapping) and set(binding) == keys
             and isinstance(value, Mapping) and set(value) == keys | {
                 "result", "resource_policy", "effective_policy", "resource_observation",
                 "resource_admission", "last_consumer_finished_ns", "input_lifecycle", "after_release"}
             | ({"execution_worker_memory_bytes"} if current_executor else set())
             | ({"execution_scratch_reserve_bytes", "operational_errors"} if future_operations else set())
             and canonical_json_bytes(value) == raw
             and canonical_json_bytes({key: value[key] for key in keys}) == canonical_json_bytes(binding)
             and value["operation"] in {"PREPARE_FINAL", "FINAL_BATCH", "FINAL_GATHER", "OUTER_EXECUTE", "OUTER_REPLAY"}
             and type(value["outer_fold"]) is int and value["outer_fold"] in range(1, 7)
             and value["family"] in _A12_FIXED_FAMILIES | _A12_TUNED_FAMILIES
             and value["task_names"] == list(_a12_final_task_coordinates(value["outer_fold"], value["task_names"]))
             and (value["operation"] == "FINAL_BATCH" or len(value["task_names"]) == 60), failure)
    for key in ("executor_source_identity", "projected_input_identity_sha256"):
        validate_sha256(value[key], failure)
    for pin in (value["input_archive"], value["projected_input"], result_pin):
        _require(isinstance(pin, Mapping) and set(pin) == {"sha256", "size_bytes"}
                 and type(pin["size_bytes"]) is int and pin["size_bytes"] > 0, failure)
        validate_sha256(pin["sha256"], failure)
    _require(canonical_json_bytes(value["result"]) == canonical_json_bytes(result_pin), failure)
    work = Path(value["work_root"])
    _require(work.is_absolute() and str(work) == value["work_root"] and ".." not in work.parts, failure)
    effective = {**policy, "memory_reserve_bytes": policy["memory_reserve_bytes"] + 32 * 32 * 1024**2,
                 "scratch_reserve_bytes": policy["scratch_reserve_bytes"] + 64 * 1024**2}
    if worker_budget is not None:
        effective["memory_bytes_per_worker"] = worker_budget
    if future_operations:
        effective["scratch_reserve_bytes"] = 0
    _require(canonical_json_bytes(value["resource_policy"]) == canonical_json_bytes(policy)
             and canonical_json_bytes(value["effective_policy"]) == canonical_json_bytes(effective)
             and type(value["last_consumer_finished_ns"]) is int and value["last_consumer_finished_ns"] > 0
             and isinstance(value["after_release"], Mapping)
             and set(value["after_release"]) == {"resource_observation", "resource_admission"}, failure)
    for observed in (value, value["after_release"]):
        observation_errors = ([row for row in value["operational_errors"]
            if row["operation"] == "POST_STEP_OBSERVATION"] if future_operations else [])
        if observed is value["after_release"] and observed["resource_observation"] is None:
            _require(future_operations and observed["resource_admission"] is None
                     and len(observation_errors) == 1
                     and observation_errors[0]["error"].startswith("RESOURCE_OBSERVATION_FAILED:")
                     and not any(row["operation"] == "POST_STEP_ADMISSION" for row in value["operational_errors"]), failure)
            continue
        if observed is value["after_release"]:
            _require(not observation_errors, failure)
        expected_admission = None
        try:
            expected_admission = resource_admission(effective, observed["resource_observation"], legal_tasks=1)
        except ContractError as error:
            _require(future_operations and observed is value["after_release"]
                     and str(error).startswith("RESOURCE_ADMISSION_ZERO:")
                     and [row for row in value["operational_errors"] if row["operation"] == "POST_STEP_ADMISSION"]
                         == [{"operation": "POST_STEP_ADMISSION", "error": str(error)}], failure)
        else:
            if future_operations and observed is value["after_release"]:
                _require(not any(row["operation"] == "POST_STEP_ADMISSION" for row in value["operational_errors"]), failure)
        _require(observed["resource_observation"]["scratch_root"] == str(work)
                 and canonical_json_bytes(observed["resource_admission"]) == canonical_json_bytes(expected_admission), failure)
    owners = value["input_lifecycle"]
    _require(isinstance(owners, Mapping) and "materialized_inputs" in owners
             and ("archive" in owners) == (value["operation"] == "OUTER_REPLAY")
             and (expected_owners is None or set(owners) == set(expected_owners)), failure)
    files, pid = set(), None
    previous = value["last_consumer_finished_ns"]
    for name, row in sorted(owners.items()):
        if name not in {"materialized_inputs", "archive", "development_inputs"}:
            branch, separator, role = name.partition("/")
            _require(separator == "/" and branch in AAR_ESTIMANDS and role in {
                "development_inputs", "selector_inputs", "selector_program", "q_program"}, failure)
        _require(isinstance(row, Mapping) and set(row) == {"temporary_root", "resource_release"}
                 | ({"numerical_phase_releases"} if name.endswith("/q_program")
                    and "numerical_phase_releases" in row else set())
                 and isinstance(row["temporary_root"], str), failure)
        if "numerical_phase_releases" in row:
            from .f5 import _a12_q_stop_phase
            phases = row["numerical_phase_releases"]
            _require(value["family"] == "GBM_COX" and isinstance(phases, Mapping)
                     and set(phases) <= {_a12_q_stop_phase(stage)[0]
                         for stage in ("S1", "S2", "S3A", "S3B1", "S3B2")}, failure)
            for phase, observed in phases.items():
                validate_resource_release(observed)
                prefix = "Q_NUMERICAL_PHASE:" + phase + ":"
                _require(observed["owner"].startswith(prefix), failure)
                validate_sha256(observed["owner"][len(prefix):], failure)
        owned = Path(row["temporary_root"])
        _require(owned.is_absolute() and str(owned) == row["temporary_root"] and ".." not in owned.parts, failure)
        release = row["resource_release"]
        validate_resource_release(release)
        _require("files" in release and (future_operations or release["reader_scan_status"] == "OBSERVED")
                 and release["owner"] == "AAR_FINAL_INPUTS:" + value["operation"] + ":"
                     + str(value["outer_fold"]) + ":" + name + ":" + result_pin["sha256"]
                 and release["released_references"] == ["completed_a12_input_callers", "materialized_a12_inputs",
                     "completed_a12_component_jobs", "completed_a12_prediction_rows"]
                 and release["before"]["started_ns"] >= previous
                 and (pid is None or release["before"]["pid"] == pid)
                 and all((future_operations or member["status"] in {"ADVISED", "UNSUPPORTED"})
                         and (member["error"] is None or future_operations and member["error"].startswith((
                             "RESOURCE_READER_SCAN_FAILED:", "RESOURCE_RELEASE_ADVICE_FAILED:")))
                         for member in release["files"]), failure)
        pid, previous = release["before"]["pid"], release["after"]["finished_ns"]
        current = {}
        for member in release["files"]:
            path = Path(member["path"])
            _require(path.is_absolute() and str(path) == member["path"] and ".." not in path.parts
                     and owned in path.parents and str(path) not in files, failure)
            current[str(path)] = member["size_bytes"]
            files.add(str(path))
        if expected_owners is not None:
            expected = expected_owners[name]
            _require(str(expected["root"]) == str(owned)
                     and canonical_json_bytes(current) == canonical_json_bytes(expected["files"]), failure)
    return value


def execute_a12_outer_bundle(source: Path, target: Path, *, lineage: Mapping[str, Any] | None=None, f2_run_root: Path | None=None, workers: int | None=None, f1_runtime_root: Path | None=None, input_bundle: Path | None=None, retained_bytes_per_component: int | None=None, selector_only: bool=False, selector_root: Path | None=None, selector_replay: bool=False, prepare_only: bool=False, phase_name: str | None=None, task_ids: list[str] | None=None, phase_batches: list[Path] | None=None, batch_root: Path | None=None, retained_bytes_per_task: int | None=None, search_only: bool=False, search_branch: str | None=None, q_batches: list[Path] | Mapping[str, list[Path]] | None=None, q_roots: Mapping[str, Path] | None=None, prepare_final: bool=False, final_task_ids: list[str] | None=None, final_batch_root: Path | None=None, final_batches: list[Path] | None=None, retained_primary_source_bundle: Path | None=None, retained_selector_source_bundle: Path | None=None, retained_selector_executor_source_bundle: Path | None=None, retained_a12_q_executor_source_bundle: Path | None=None, retained_gbm_q_source_bundle: Path | list[Path] | None=None, recover_gbm_losses: bool=False, q_unit_outputs: list[list[str]] | None=None, prepared_q_input_sha256: str | None=None, prepared_source_bundle: Path | None=None, q_resource_supplement: tuple[Path, ...] | None=None, selector_science_decision: Mapping[str, Any] | None=None, continuous_batch_root: Path | None=None, completed_aar_units: list[dict] | None=None) -> dict:
    """Original outer owner: each branch's development, search and final M20."""
    _require(not any((selector_only, selector_replay, prepare_only, search_only, prepare_final, recover_gbm_losses)) and all(value is None for value in (selector_root, phase_name, task_ids, phase_batches, batch_root, retained_bytes_per_task, search_branch, q_batches, q_roots, final_task_ids, final_batch_root, final_batches, retained_primary_source_bundle, retained_selector_source_bundle, retained_selector_executor_source_bundle, retained_a12_q_executor_source_bundle, retained_gbm_q_source_bundle, q_unit_outputs, prepared_q_input_sha256, prepared_source_bundle, q_resource_supplement, selector_science_decision, continuous_batch_root)), "OLD_F45_STAGE_MODES_RETIRED")
    from contextlib import nullcontext
    from .f5 import _full_score_scratch
    from .runtime import observe_execution_resources, resource_admission
    _require(True, 'F5_RETAINED_AAR_SOURCE_SCOPE_INVALID')
    _require(True, 'F5_RETAINED_AAR_Q_EXECUTOR_DRIFT')
    _require(True, 'F5_A12_PYTHON_Q_RESOURCE_EVIDENCE_INVALID')
    _require(True, 'F5_A12_PREPARED_STOP_INPUT_INVALID')
    _require(True, 'F5_A12_PREPARED_STOP_INPUT_INVALID')
    _require(True, 'F5_RETAINED_AAR_SOURCE_SCOPE_INVALID')
    _require(True, 'F5_RETAINED_AAR_SOURCE_SCOPE_INVALID')
    _require(True, 'F5_RETAINED_GBM_Q_NUMBERS_ONLY')
    _require(type(False) is bool, 'F5_GBM_LOSS_RECOVERY_SCOPE_INVALID')
    final_mode = False
    _require(type(False) is bool and sum((False, False, False)) <= 1 and (not final_mode or (input_bundle is not None and all((value is None for value in (None, None, None, None, None, None, None))))), 'F5_A12_FINAL_BATCH_SCOPE_INVALID')
    _require(type(False) is bool and type(False) is bool and (type(False) is bool) and (type(False) is bool), 'F5_A12_SELECTOR_RESULT_SCOPE_INVALID')
    _require(all((value is None for value in (None, None, None, None, None))), 'F5_A12_SELECTOR_RESULT_SCOPE_INVALID')
    _require(True, 'F5_A12_Q_RESULT_SCOPE_INVALID')
    _require(source.is_absolute() and source.is_file() and (not source.is_symlink()) and target.is_absolute() and target.parent.is_dir() and (not target.exists()) and (not target.is_symlink()), 'F5_A12_OUTER_PATH_INVALID')
    projected = input_bundle is not None
    _require(completed_aar_units is None or projected and isinstance(completed_aar_units, list),
             "F45_AAR_SELECTOR_REUSE_SCOPE_INVALID")
    _require(lineage is None and f2_run_root is None and (f1_runtime_root is None) and (workers is None) if projected else lineage is not None and f2_run_root is not None, 'F5_A12_OUTER_ARGUMENT_SCOPE_INVALID')
    _require(type(retained_bytes_per_component) is int and retained_bytes_per_component > 0 if projected else retained_bytes_per_component is None, 'F5_A12_FINAL_RETENTION_ESTIMATE_REQUIRED')
    capacity = None if projected else resolve_pool_workers(workers)
    root = target.with_name(target.name + '.work')
    _require(not root.is_symlink(), 'F5_A12_OUTER_WORK_EXISTS')
    root.mkdir(mode=448, exist_ok=True)
    input_work = Path(tempfile.mkdtemp(prefix='a12-inputs-', dir=root))
    execution = {}
    native_members = None
    input_owners, call = ({}, {})
    completed = None

    def consume():
        nonlocal execution, capacity
        try:
            with _full_score_scratch(root) if projected else nullcontext():
                if projected:
                    from .nested_loco import AAR_ESTIMANDS
                    with open_carrier(source) as source_archive:
                        outer = strict_json_bytes(source_archive.read('a12-inputs.json'))['outer_fold']
                    branch_names = AAR_ESTIMANDS
                    coordinates = _a12_final_task_coordinates(outer)
                    (input_work / 'inputs').mkdir(mode=0o700)
                    branch_input = input_work / 'inputs' / branch_names[0]
                    prepared = materialize_a12_outer_inputs(source, None, branch_input,
                        input_bundle=input_bundle,
                        final_task_ids=[name for name, (which, _) in coordinates.items() if which == branch_names[0]])
                else:
                    prepared = materialize_a12_outer_inputs(source, lineage, input_work / 'inputs',
                        f2_run_root=f2_run_root, f1_runtime_root=f1_runtime_root)
                if completed_aar_units:
                    prepared['completed_aar_units'] = completed_aar_units
                if projected:
                    from .f4 import _f45_source_member_sha256
                    policy = prepared['source']['resource_policy']
                    effective = {**policy, 'memory_bytes_per_worker': MIN_WORKER_MEMORY_BYTES, 'memory_reserve_bytes': policy['memory_reserve_bytes'] + 32 * 32 * 1024 ** 2, 'scratch_reserve_bytes': 0}
                    observation = observe_execution_resources(root)
                    call['report'] = {'executor_source_identity': sha256_bytes(canonical_json_bytes(_f45_source_member_sha256())), 'execution_worker_memory_bytes': MIN_WORKER_MEMORY_BYTES, 'execution_scratch_reserve_bytes': 0, 'operational_errors': [], 'operation': 'OUTER_EXECUTE', 'outer_fold': prepared['outer_fold'], 'family': prepared['family'], 'task_names': list(_a12_final_task_coordinates(prepared['outer_fold'], None)), 'input_archive': {'sha256': sha256_file(source), 'size_bytes': source.stat().st_size}, 'projected_input': {'sha256': sha256_file(input_bundle), 'size_bytes': input_bundle.stat().st_size}, 'projected_input_identity_sha256': prepared['source']['identity_sha256'], 'work_root': str(root), 'resource_policy': policy, 'effective_policy': effective, 'resource_observation': observation, 'resource_admission': resource_admission(effective, observation, legal_tasks=1), 'input_lifecycle': input_owners, 'after_release': None}
                    input_owners['materialized_inputs'] = {'temporary_root': str(input_work / 'inputs')}
                continuous_sources = {}
                if projected and (prepared['family'] == 'GBM_COX' or ((prepared['outer_fold'], prepared['family']) == (4, 'RSF') and prepared['source'].get('identity_sha256') == '1204c950c4f61b4a30ae3302825cad8720c77bd9c5daff68159c7eaaad88f9af')):
                    from .f5 import _q_gbm_source_evidence
                    from .nested_loco import WITHIN_FAMILY_NO_AAR_REDEVELOPMENT
                    _require(True, 'F5_A12_Q_RESULT_SCOPE_INVALID')
                    q_root = root / 'search' / WITHIN_FAMILY_NO_AAR_REDEVELOPMENT
                    _require(isinstance(q_root, Path), 'F5_A12_Q_RESULT_SCOPE_INVALID')
                    if q_root is not None and (q_root / 'execution.json').is_file():
                        sources, _ = _q_gbm_source_evidence(q_root, prepared['source']['resource_policy'])
                        if sources:
                            _require(False, 'F5_GBM_Q_SOURCE_EVIDENCE_INVALID')
                            prepared['retained_selector_source_bundle'] = sources['retained_selector_source_bundle']
                            if 'retained_selector_executor_source_bundle' in sources:
                                prepared['retained_selector_executor_source_bundle'] = sources['retained_selector_executor_source_bundle']
                if not final_mode:
                    (root / 'fits').mkdir(mode=448, exist_ok=True)
                if projected:
                    execution['input_expansion'] = prepared['input_expansion_resources']
                    execution['branch_final_models'] = {}
                    jobs, rows = ([], [])
                    branches = _a12_branch_names(prepared)
                    for index, branch in enumerate(branches, 1):
                        from .nested_loco import WITHIN_FAMILY_NO_AAR_REDEVELOPMENT
                        names = [name for name, (which, _) in coordinates.items() if which == branch]
                        if index > 1:
                            developments = prepared['branch_development']
                            branch_input = input_work / 'inputs' / branch
                            prepared = materialize_a12_outer_inputs(source, None, branch_input,
                                input_bundle=input_bundle, final_task_ids=names)
                            prepared['branch_development'] = developments
                            if completed_aar_units:
                                prepared['completed_aar_units'] = completed_aar_units
                        # This new private branch has just been byte-validated by
                        # materialization. Keep its exact members, not a later tree scan.
                        branch_members = prepared['owned_members']
                        development_owners = {}
                        prepared = _a12_projected_development_inputs(prepared, root / 'development', replay=False, branch=branch, **{}, **{'q_input_lifecycle': development_owners} if branch == WITHIN_FAMILY_NO_AAR_REDEVELOPMENT else {})
                        input_owners.update({branch + '/' + role: row for role, row in development_owners.items()})
                        if branch not in _a12_estimable_branches(prepared):
                            _retire_a12_member_copies(branch_input, branch_members)
                            continue
                        search_owners = {}
                        searches = _a12_outer_searches(prepared, root, replay=False, branch=branch, **{}, **{})
                        for name, owners in search_owners.items():
                            input_owners.update({name + '/' + role: row for role, row in owners.items()})
                        active = [{**job, 'root': str(root / 'fits' / job['name']), 'retained_bytes_per_component': retained_bytes_per_component} for job in _a12_outer_model_jobs(prepared, searches, task_names=names)]
                        jobs.extend(active)
                        reused = _prepare_a12_final_reuse(prepared, root, active)
                        shared = _a12_outer_retained_members(root, prepared['family'], prepared['outer_fold'], source, prepared=prepared, before_final=True, completed_branches=branches[:index], replay_input_roots=tuple((Path(row['temporary_root']) for row in input_owners.values() if Path(row['temporary_root']).parent == root / 'development')))
                        reservation = _a12_final_resource_reservation(prepared['source'], jobs, {name: path.stat().st_size for name, path in shared.items()}, retained_bytes_per_component, allow_partial=True, execution_worker_memory_bytes=MIN_WORKER_MEMORY_BYTES, execution_scratch_reserve_bytes=0)
                        # Retained-member validation reads the completed search again.
                        # Clear those pages before measuring the next original pool.
                        from .runtime import release_f45_cumulative_files
                        release_f45_cumulative_files(list(shared.values()),
                            owner="AAR_FINAL_PRE_ADMISSION:" + branch, report_root=root)
                        observation = observe_execution_resources(root)
                        admission = resource_admission(reservation['effective_policy'], observation, legal_tasks=max(1, len(active) - len(reused)))
                        capacity = admission['admitted_worker_ceiling']
                        record = {'resource_reservation': reservation, 'resource_observation': observation, 'resource_admission': admission, 'final_model_pool': {}}
                        execution['branch_final_models'][branch] = record
                        try:
                            rows.extend(_a12_execute_final_pool(active, reused, capacity, record))
                        finally:
                            (root / 'execution.json').write_bytes(canonical_json_bytes(execution))
                        _retire_a12_member_copies(branch_input, branch_members)
                    if 'estimability' in prepared:
                        shared = _a12_outer_retained_members(root, prepared['family'], prepared['outer_fold'], source,
                            prepared=prepared, before_final=True, replay_input_roots=tuple(
                                Path(row['temporary_root']) for row in input_owners.values()
                                if Path(row['temporary_root']).parent == root / 'development'))
                        reservation = _a12_final_resource_reservation(prepared['source'], jobs,
                            {name: path.stat().st_size for name, path in shared.items()}, retained_bytes_per_component,
                            allow_partial=True, execution_worker_memory_bytes=MIN_WORKER_MEMORY_BYTES,
                            execution_scratch_reserve_bytes=0)
                    execution['resource_reservation'] = reservation
                    (root / 'execution.json').write_bytes(canonical_json_bytes(execution))
                else:
                    searches = _a12_outer_searches(prepared, root, replay=False, workers=workers)
                    jobs = [{**job, 'root': str(root / 'fits' / job['name'])} for job in _a12_outer_model_jobs(prepared, searches)]
                    rows = _bounded_ordered_spawn(_execute_ablation_component, jobs, selected_slots=capacity)
                predictions = _a12_outer_predictions(prepared, jobs, rows)
                members = _a12_outer_retained_members(root, prepared['family'], prepared['outer_fold'], source, prepared=prepared, replay_input_roots=tuple((Path(row['temporary_root']) for row in input_owners.values() if Path(row['temporary_root']).parent == root / 'development')))
                from .carriers import run_context, write_carrier
                current_run = run_context()
                external = {name: path for name, path in members.items() if name == 'inputs.zip'
                    or name.startswith('fits/') and name.endswith('.zip')} if projected and current_run else {}
                physical = {name: path for name, path in members.items() if name not in external}
                if projected:
                    policy = prepared['source']['resource_policy']
                    required = 2 * (sum(path.stat().st_size for path in physical.values()) + reservation['metadata_reserved_bytes']
                                    + len(external) * 4096)
                    _require(required <= reservation['archive_reserved_bytes'], 'F5_A12_OUTER_STORAGE_ESTIMATE_EXCEEDED')
                    archive_observation = observe_execution_resources(root)
                    archive_admission = resource_admission({**policy, 'memory_bytes_per_worker': MIN_WORKER_MEMORY_BYTES, 'scratch_reserve_bytes': 0}, archive_observation, legal_tasks=1)
                    _require(archive_observation['scratch_available_bytes'] >= required, 'F5_A12_OUTER_ARCHIVE_SPACE_INSUFFICIENT')
                    execution['executor_source_identity'] = call['report']['executor_source_identity']
                    execution['archive_write'] = {'reserved_bytes': required, 'resource_observation': archive_observation, 'execution_scratch_reserve_bytes': 0, 'resource_admission': archive_admission}
                    (root / 'execution.json').write_bytes(canonical_json_bytes(execution))
                body = {'kind': 'PADML_F5_A12_OUTER_NATIVE_V2' if projected else 'PADML_F5_A12_OUTER_NATIVE_V1', 'source': prepared['source'], 'family': prepared['family'], 'outer_fold': prepared['outer_fold'], 'predictions': predictions, 'members': {name: {'sha256': sha256_file(path), 'size_bytes': path.stat().st_size} for name, path in sorted(members.items())}}
                if 'estimability' in prepared:
                    body['estimability'] = prepared['estimability']
                if projected:
                    body['native_members'] = {f"fits/{job['name']}.zip": {'sha256': sha256_file(root / 'fits' / f"{job['name']}.zip"), 'size_bytes': (root / 'fits' / f"{job['name']}.zip").stat().st_size} for job in jobs}
                value = {**body, 'identity_sha256': sha256_bytes(canonical_json_bytes(body))}
                if external:
                    write_carrier(target, {'a12-outer.json': canonical_json_bytes(value), **physical}, references=external, run=current_run)
                else:
                    write_deterministic_zip(target, {'a12-outer.json': canonical_json_bytes(value), **members}, stored_members={name for name in members if name.endswith(('.zip', '.rds'))})
                if projected:
                    _require(target.stat().st_size <= execution['archive_write']['reserved_bytes'], 'F5_A12_OUTER_STORAGE_ESTIMATE_EXCEEDED')
                    ledger = _a12_outer_archive_record(value, target)['execution_ledger']
            return {'status': 'COMPUTED_NATIVE_MODELS', 'stage_acceptance': False, 'outer_fold': prepared['outer_fold'], 'outer_model_fit_count': len(jobs), 'outer_stop_fit_count': 0, 'pool_workers': max((record['resource_admission']['admitted_worker_ceiling'] for record in execution['branch_final_models'].values())) if projected else min(capacity, len(jobs)), 'sha256': sha256_file(target), 'size_bytes': target.stat().st_size, **({'execution_report': execution, 'execution_ledger': ledger, 'work_evidence_retained': str(root)} if projected else {}), **({'estimability': prepared['estimability']} if 'estimability' in prepared else {})}
        finally:
            if projected:
                from .runtime import observe_step_memory
                call['before'] = observe_step_memory()
    try:
        completed = consume()
        if projected:
            from .nested_loco import _write_exact_once
            from .runtime import observe_step_memory, release_step_resources
            report = call['report']
            policy = report['resource_policy']
            result_raw = canonical_json_bytes(completed)
            result_pin = {'sha256': sha256_bytes(result_raw), 'size_bytes': len(result_raw)}
            binding = {key: report[key] for key in ('executor_source_identity', 'operation', 'outer_fold', 'family', 'task_names', 'input_archive', 'projected_input', 'projected_input_identity_sha256', 'work_root')}
            report.update(result=result_pin, last_consumer_finished_ns=call['before']['started_ns'])
            expected_owners = {}
            before = call.pop('before')
            for name, row in sorted(input_owners.items()):
                owned = Path(row['temporary_root'])
                paths = sorted(owned.rglob('*'))
                _require(owned.is_dir() and (not owned.is_symlink()) and (owned.resolve(strict=True) == owned) and all((not path.is_symlink() and (path.is_dir() or path.is_file()) for path in paths)), 'F5_A12_FINAL_INPUT_EXECUTION_INVALID')
                files = [path for path in paths if path.is_file()]
                expected_owners[name] = {'root': owned, 'files': {str(path): path.stat().st_size for path in files}}
                row['resource_release'] = release_step_resources(files, owner='AAR_FINAL_INPUTS:' + report['operation'] + ':' + str(report['outer_fold']) + ':' + name + ':' + result_pin['sha256'], before=before, released_references=['completed_a12_input_callers', 'materialized_a12_inputs', 'completed_a12_component_jobs', 'completed_a12_prediction_rows'])
                before = observe_step_memory()
            report['after_release'] = {'resource_observation': None, 'resource_admission': None}
            try:
                observation = observe_execution_resources(root)
            except OSError as error:
                report['operational_errors'].append({'operation': 'POST_STEP_OBSERVATION', 'error': 'RESOURCE_OBSERVATION_FAILED:' + type(error).__name__ + ':' + str(error)})
            else:
                report['after_release']['resource_observation'] = observation
                try:
                    report['after_release']['resource_admission'] = resource_admission(report['effective_policy'], observation, legal_tasks=1)
                except ContractError as error:
                    if not str(error).startswith('RESOURCE_ADMISSION_ZERO:'):
                        raise
                    report['operational_errors'].append({'operation': 'POST_STEP_ADMISSION', 'error': str(error)})
            raw = canonical_json_bytes(report)
            _validate_a12_final_input_execution(raw, binding=binding, result_pin=result_pin, policy=policy, expected_owners=expected_owners)
            removable = {Path(row['temporary_root']) for row in input_owners.values() if row['resource_release']['reader_scan_status'] == 'OBSERVED' and all((member['status'] in {'ADVISED', 'UNSUPPORTED'} and member['error'] is None for member in row['resource_release']['files']))}
            from .carriers import run_context
            if run_context() is not None:
                removable = {row['root'] for row in expected_owners.values()}
            for owned in sorted(removable, key=lambda path: (-len(path.parts), str(path))):
                _require(not owned.is_symlink(), 'F5_A12_RETIREMENT_PATH_INVALID')
                try:
                    shutil.rmtree(owned)
                except OSError as error:
                    report['operational_errors'].append({'operation': 'DISPOSABLE_INPUT_REMOVAL', 'error': str(owned) + ':' + type(error).__name__ + ':' + str(error)})
            raw = canonical_json_bytes(report)
            _validate_a12_final_input_execution(raw, binding=binding, result_pin=result_pin, policy=policy, expected_owners=expected_owners)
            report_path = root / ('input-execution-' + input_work.name + '.json')
            _write_exact_once(report_path, raw, 'F5_A12_FINAL_INPUT_EXECUTION_EXISTS')
            completed['input_execution'] = {'path': str(report_path), 'sha256': sha256_bytes(raw), 'size_bytes': len(raw)}
        else:
            shutil.rmtree(root)
    except BaseException as exc:
        if projected:
            from .nested_loco import _write_exact_once
            failure_path = root / ('input-execution-failure-' + input_work.name + '.json')
            try:
                failure_raw = canonical_json_bytes({'result': completed, 'execution': execution, 'input_execution': call.get('report')})
                _require(len(failure_raw) <= 64 * 1024 ** 2, 'F5_A12_FINAL_INPUT_EXECUTION_INVALID')
                _write_exact_once(failure_path, failure_raw, 'F5_A12_FINAL_INPUT_EXECUTION_EXISTS')
            except BaseException as diagnostic_error:
                exc.add_note('F5_A12_FINAL_INPUT_DIAGNOSTIC_WRITE_FAILED:' + str(diagnostic_error))
        exc.add_note(f'F5_A12_OUTER_EVIDENCE_RETAINED:{root}')
        raise
    return completed


def _resume_a12_outer_consumer(path: Path, input_bundle: Path, value: Mapping[str, Any], pin: Mapping[str, Any]) -> None:
    """Finish a completed original consumer whose diagnostic tail failed.

    The original input report is emitted only after consume returned, including
    its prediction comparison. A completed numerical pool alone is insufficient.
    This route preserves that report and performs no numerical read or release.
    """
    from .f5 import _f45_score_reuse_authorities
    from .nested_loco import AAR_ESTIMANDS
    from .runtime import observe_execution_resources, resource_admission, validate_resource_release
    failure = "F5_A12_COMPLETED_CONSUMER_INVALID"
    _require(isinstance(pin, Mapping) and set(pin) == {"path", "sha256", "size_bytes"}
             and isinstance(pin["path"], str) and type(pin["size_bytes"]) is int
             and 0 < pin["size_bytes"] <= 64 * 1024**2, failure)
    validate_sha256(pin["sha256"], failure)
    report_path = Path(pin["path"])
    root = report_path.parent
    _require(root.parent == path.parent and root.name.startswith("padml-a12-outer-replay-")
             and report_path.name == "execution.json" and root.is_dir()
             and not root.is_symlink() and root.resolve(strict=True) == root
             and report_path.is_file() and not report_path.is_symlink()
             and report_path.stat().st_size == pin["size_bytes"], failure)
    policy = value["source"]["resource_policy"]
    resource_admission({**policy, "memory_bytes_per_worker": MIN_WORKER_MEMORY_BYTES,
        "scratch_reserve_bytes": 0, "memory_reserve_bytes": policy["memory_reserve_bytes"] + 32 * pin["size_bytes"]},
        observe_execution_resources(root), legal_tasks=1)
    with report_path.open("rb") as handle:
        raw = handle.read(pin["size_bytes"] + 1)
    _require(len(raw) == pin["size_bytes"] and sha256_bytes(raw) == pin["sha256"], failure)
    report = strict_json_bytes(raw)
    _require(canonical_json_bytes(report) == raw and isinstance(report, Mapping)
             and isinstance(report.get("input_execution"), Mapping)
             and "last_consumer_finished_ns" in report["input_execution"], failure)
    leaf = report["input_execution"]
    executors, _ = _f45_score_reuse_authorities()
    executor = leaf.get("executor_source_identity")
    _require(executor in executors.values(), failure)
    binding = {"executor_source_identity": executor, "operation": "OUTER_REPLAY",
        "outer_fold": value["outer_fold"], "family": value["family"],
        "task_names": list(_a12_final_task_coordinates(value["outer_fold"])),
        "input_archive": {"sha256": sha256_file(path), "size_bytes": path.stat().st_size},
        "projected_input": {"sha256": sha256_file(input_bundle), "size_bytes": input_bundle.stat().st_size},
        "projected_input_identity_sha256": value["source"]["identity_sha256"], "work_root": str(root)}
    result_raw = canonical_json_bytes(value)
    result_pin = {"sha256": sha256_bytes(result_raw), "size_bytes": len(result_raw)}
    owners, covered = {}, set()
    _require(isinstance(leaf.get("input_lifecycle"), Mapping), failure)
    for name, row in leaf["input_lifecycle"].items():
        owned = Path(row["temporary_root"])
        _require(root in owned.parents and owned.is_dir() and not owned.is_symlink()
                 and owned.resolve(strict=True) == owned, failure)
        if name == "archive":
            _require(owned == root / "archive", failure)
            files = {owned / member for member in ("a12-outer.json", *value["members"])}
        else:
            if name == "materialized_inputs":
                _require(owned == root / "inputs", failure)
            entries = list(owned.rglob("*"))
            _require(all(not p.is_symlink() and (p.is_dir() or p.is_file()) for p in entries), failure)
            files = {p for p in entries if p.is_file()}
        _require(all(p.is_file() and not p.is_symlink() and p.resolve(strict=True) == p for p in files), failure)
        owners[name] = {"root": owned, "files": {str(p): p.stat().st_size for p in files}}
        covered.update(files)
        for member in row["resource_release"]["files"]:
            p = Path(member["path"])
            _require(p in files, failure)
            st = p.stat()
            _require({k: member[k] for k in ("device", "inode", "size_bytes", "mtime_ns", "ctime_ns")} == {
                "device": st.st_dev, "inode": st.st_ino, "size_bytes": st.st_size,
                "mtime_ns": st.st_mtime_ns, "ctime_ns": st.st_ctime_ns}, failure)
    entries = list(root.rglob("*"))
    _require(all(not p.is_symlink() and (p.is_file() or p.is_dir()) for p in entries), failure)
    _validate_a12_final_input_execution(raw, binding=binding, result_pin=result_pin, policy=policy,
        expected_owners=owners, expected_pin={k: pin[k] for k in ("sha256", "size_bytes")}, loader_report=True)
    # The original search replay writes one operational release report per
    # branch after reading the archived Q. These are not archive members or
    # scientific inputs, and cannot replace any pinned completion evidence.
    extras = {p for p in entries if p.is_file()} - covered - {report_path}
    _require(len(extras) <= len(AAR_ESTIMANDS), failure)
    if extras:
        _require(all(0 < p.stat().st_size <= 64 * 1024**2 for p in extras), failure)
        resource_admission({**policy, "memory_bytes_per_worker": MIN_WORKER_MEMORY_BYTES,
            "scratch_reserve_bytes": 0, "memory_reserve_bytes": policy["memory_reserve_bytes"]
                + 32 * (pin["size_bytes"] + max(p.stat().st_size for p in extras))},
            observe_execution_resources(root), legal_tasks=1)
        original = leaf["input_lifecycle"]["archive"]["resource_release"]
        identity_keys = ("device", "inode", "size_bytes", "mtime_ns", "ctime_ns")
        original_files = {row["path"]: {k: row[k] for k in identity_keys} for row in original["files"]}
        seen_branches = set()
        for diagnostic_path in sorted(extras):
            branch_root = diagnostic_path.parent.parent
            branch = branch_root.name
            match = re.fullmatch(r"([1-9][0-9]*)-([1-9][0-9]*)\.json", diagnostic_path.name)
            _require(branch in AAR_ESTIMANDS and branch not in seen_branches
                     and branch_root.parent == root / "archive/search"
                     and diagnostic_path.parent.name == "resource-release" and match is not None, failure)
            diagnostic_raw = diagnostic_path.read_bytes()
            diagnostic = strict_json_bytes(diagnostic_raw)
            _require(isinstance(diagnostic, Mapping) and set(diagnostic) == {
                "aliases", "error", "files_deleted", "owner", "release", "resource_observation_after", "skipped"}
                and canonical_json_bytes(diagnostic) == diagnostic_raw
                and diagnostic["owner"] == "AAR_SEARCH:" + branch
                and diagnostic["error"] is None and diagnostic["files_deleted"] == 0
                and diagnostic["aliases"] == {} and diagnostic["skipped"] == [], failure)
            release = diagnostic["release"]
            validate_resource_release(release)
            _require("files" in release and release["owner"] == diagnostic["owner"]
                     and release["released_references"] == ["completed_branch_search"]
                     and int(match[1]) == release["before"]["pid"] == original["before"]["pid"]
                     and release["after"]["finished_ns"] < int(match[2]) < leaf["last_consumer_finished_ns"], failure)
            expected = {str(root / "archive" / member) for member in value["members"]
                        if member.startswith("search/" + branch + "/") and "/resource-release/" not in member}
            _require(expected and set(row["path"] for row in release["files"]) == expected
                     and all(row["path"] in original_files and
                         {k: row[k] for k in identity_keys} == original_files[row["path"]]
                         for row in release["files"]), failure)
            seen_branches.add(branch)
            del diagnostic, diagnostic_raw, release
    producer_pin = value["members"]["execution.json"]
    _require(type(producer_pin["size_bytes"]) is int and 0 < producer_pin["size_bytes"] <= 64 * 1024**2, failure)
    with open_carrier(path) as archive:
        _require(archive.getinfo("execution.json").file_size == producer_pin["size_bytes"], failure)
        producer_raw = archive.read("execution.json")
    _require(sha256_bytes(producer_raw) == producer_pin["sha256"], failure)
    producer = strict_json_bytes(producer_raw)
    coordinator = producer["resource_reservation"]["coordinator_memory_estimate_bytes"]
    _require(type(coordinator) is int and coordinator >= 0, failure)
    recorded_memory = report.get("effective_policy", {}).get("memory_bytes_per_worker")
    _require(type(recorded_memory) is int and recorded_memory in RECORDED_WORKER_MEMORY_BYTES, failure)
    effective = {**policy, "memory_bytes_per_worker": recorded_memory, "scratch_reserve_bytes": 0,
        "memory_reserve_bytes": policy["memory_reserve_bytes"] + coordinator}
    observation = report["resource_observation"]
    _require(observation["scratch_root"] == str(root)
             and canonical_json_bytes(report["effective_policy"]) == canonical_json_bytes(effective)
             and type(report["replay_retention_reserved_bytes"]) is int
             and report["replay_retention_reserved_bytes"] == 0, failure)
    task_count = 20 * len(_a12_estimable_branches(value)) if "estimability" in value else 60
    admission = resource_admission(effective, observation, legal_tasks=task_count)
    pool = report["numerical_read_pool"]
    _require(canonical_json_bytes(admission) == canonical_json_bytes(report["resource_admission"])
             and set(pool) == {"status", "engine_threads", "configured_worker_ceiling", "admitted_worker_ceiling",
                 "completed_task_count", "runnable_task_count", "actual_worker_process_peak"}
             and all(type(pool[k]) is int for k in pool if k != "status")
             and pool["status"] == "COMPLETED" and pool["engine_threads"] == 1
             and pool["configured_worker_ceiling"] == observation["effective_cpus"] - 8
             and pool["admitted_worker_ceiling"] == admission["admitted_worker_ceiling"]
             and pool["completed_task_count"] == pool["runnable_task_count"] == task_count
             and 1 <= pool["actual_worker_process_peak"] <= pool["admitted_worker_ceiling"], failure)
    _require(report_path.read_bytes() == raw, failure)


def _load_a12_outer_archive(path: Path, lineage: Mapping[str, Any] | None = None, *, f2_run_root: Path | None = None,
                            workers: int | None = None, f1_runtime_root: Path | None = None,
                            replay_evidence: Path | None = None, input_bundle: Path | None = None,
                            _prepared_consumer=None, retained_primary_source_bundle: Path | None = None,
                            execution_report: dict[str, Any] | None = None, completed_replay: Mapping[str, Any] | None = None) -> dict:
    """Rebuild inputs/parameters; nested final models use their first-audit numbers."""
    from contextlib import nullcontext
    from .bundle import _validated_zip_infos
    from .f4 import _full_pipeline_archive_limits
    from .f5 import _full_score_scratch
    from .runtime import observe_execution_resources, resource_admission

    projected = input_bundle is not None
    _require(completed_replay is None or (projected
             and replay_evidence is None and _prepared_consumer is None and execution_report is None),
             "F5_A12_OUTER_ARGUMENT_SCOPE_INVALID")
    _require(execution_report is None or projected and isinstance(execution_report, dict) and not execution_report,
             "F5_A12_FINAL_INPUT_EXECUTION_INVALID")
    _require(retained_primary_source_bundle is None or projected, "F5_RETAINED_AAR_SOURCE_SCOPE_INVALID")
    _require(_prepared_consumer is None or projected and callable(_prepared_consumer), "F5_A12_OUTER_ARGUMENT_SCOPE_INVALID")
    _require((lineage is None and f2_run_root is None and f1_runtime_root is None and workers is None)
             if projected else (lineage is not None and f2_run_root is not None),
             "F5_A12_OUTER_ARGUMENT_SCOPE_INVALID")
    if projected:
        _require(input_bundle.is_absolute() and input_bundle.is_file() and not input_bundle.is_symlink(),
                 "F5_A12_PROJECTED_INPUT_SOURCE_REQUIRED")
        with open_carrier(input_bundle) as archive:
            _require(archive.getinfo("a12-inputs.json").file_size <= 32 * 1024 * 1024, "F5_A12_INPUT_INDEX_TOO_LARGE")
            declared = strict_json_bytes(archive.read("a12-inputs.json"))
        # This header selects only a byte bound. The original input consumer
        # below still validates and reopens the entire projected source.
        context = {"family": declared["family"], "source": declared}
    else:
        context = _a12_context(f2_run_root, lineage, f1_runtime_root=f1_runtime_root)
    # The existing full-pipeline bounds cover native input, path and checkpoint files.
    limits = _full_pipeline_archive_limits(context["family"])
    scale = 3 if projected else 2
    _require(path.is_absolute() and path.is_file() and not path.is_symlink(), "F5_A12_OUTER_PATH_INVALID")
    with open_carrier(path) as archive:
        _require(archive.getinfo("a12-outer.json").file_size <= scale * limits["metadata"], "F5_A12_OUTER_INDEX_TOO_LARGE")
        raw = archive.read("a12-outer.json")
    value = strict_json_bytes(raw)
    _require(isinstance(value, dict) and set(value) == {"kind", "source", "family", "outer_fold", "predictions", "members", "identity_sha256"}
             | ({"native_members"} if projected else set())
             | ({"estimability"} if projected and "estimability" in value else set())
             and canonical_json_bytes(value) == raw
             and value["kind"] == ("PADML_F5_A12_OUTER_NATIVE_V2" if projected else "PADML_F5_A12_OUTER_NATIVE_V1")
             and value["source"] == context["source"] and value["family"] == context["family"]
             and type(value["outer_fold"]) is int and value["outer_fold"] in range(1, 7)
             and isinstance(value["members"], dict)
             and value["identity_sha256"] == sha256_bytes(canonical_json_bytes({k: v for k, v in value.items() if k != "identity_sha256"})),
             "F5_A12_OUTER_INDEX_INVALID")
    _a12_estimable_branches(value)
    if completed_replay is not None:
        _resume_a12_outer_consumer(path, input_bundle, value, completed_replay)
        return value
    root = (Path(tempfile.mkdtemp(prefix="padml-a12-outer-replay-", dir=path.parent if projected else None)).resolve()
            if replay_evidence is None else replay_evidence)
    if replay_evidence is not None:
        root.mkdir(mode=0o700)
    execution, input_owners, call = {}, {}, {}
    if projected:
        from .f4 import _f45_source_member_sha256
        policy = declared["resource_policy"]
        effective = {**policy, "memory_bytes_per_worker": MIN_WORKER_MEMORY_BYTES,
                     "memory_reserve_bytes": policy["memory_reserve_bytes"] + 32 * 32 * 1024**2,
                     "scratch_reserve_bytes": 0}
        binding = {
            "executor_source_identity": sha256_bytes(canonical_json_bytes(_f45_source_member_sha256())),
            "operation": "OUTER_REPLAY", "outer_fold": value["outer_fold"], "family": value["family"],
            "task_names": list(_a12_final_task_coordinates(value["outer_fold"])),
            "input_archive": {"sha256": sha256_file(path), "size_bytes": path.stat().st_size},
            "projected_input": {"sha256": sha256_file(input_bundle), "size_bytes": input_bundle.stat().st_size},
            "projected_input_identity_sha256": declared["identity_sha256"], "work_root": str(root)}
        result_raw = canonical_json_bytes(value)
        result_pin = {"sha256": sha256_bytes(result_raw), "size_bytes": len(result_raw)}
        # The original hash streams are closed. Release their file-cache
        # pressure before measuring this reader's actual available memory.
        from .runtime import release_f45_cumulative_files
        release_f45_cumulative_files([path, input_bundle], owner="AAR_OUTER_REPLAY_HASHED_INPUTS",
            report_root=root, released_references=["closed_a12_archive_hash_streams"])
        observation = observe_execution_resources(root)
        report = {**binding, "result": result_pin, "resource_policy": policy, "effective_policy": effective,
            "execution_worker_memory_bytes": MIN_WORKER_MEMORY_BYTES,
            "execution_scratch_reserve_bytes": 0, "operational_errors": [],
            "resource_observation": observation, "resource_admission": resource_admission(effective, observation, legal_tasks=1),
            "input_lifecycle": input_owners, "after_release": None}
        input_owners.update(archive={"temporary_root": str(root / "archive")},
                            materialized_inputs={"temporary_root": str(root / "inputs")})
    def consume():
        nonlocal execution, retained_primary_source_bundle, raw
        try:
            extracted = root / "archive"
            with _full_score_scratch(root) if projected else nullcontext():
                if projected:
                    with open_carrier(path) as archive:
                        infos = _validated_zip_infos(archive, {"a12-outer.json", *value["members"]},
                            max_member_bytes=scale * limits["member"], max_total_bytes=scale * limits["replicate"],
                            max_compression_ratio=1000)
                        expanded = sum(info.file_size for info in infos)
                    policy = declared["resource_policy"]
                    observation = observe_execution_resources(root)
                    admission = resource_admission({**policy,
                        "memory_bytes_per_worker": MIN_WORKER_MEMORY_BYTES,
                        "scratch_reserve_bytes": 0,
                        "memory_reserve_bytes": policy["memory_reserve_bytes"] + 32 * len(raw)}, observation, legal_tasks=1)
                    _require(observation["scratch_available_bytes"] >= expanded,
                             "F5_A12_OUTER_ARCHIVE_SPACE_INSUFFICIENT")
                    execution["archive_expansion"] = {"expanded_bytes": expanded, "resource_observation": observation,
                                                       "resource_admission": admission}
                    (root / "execution.json").write_bytes(canonical_json_bytes(execution))
                extract_safe_zip(path, extracted, expected_members={"a12-outer.json": {"sha256": sha256_bytes(raw), "size_bytes": len(raw)},
                                                                  **value["members"]},
                                 max_member_bytes=scale * limits["member"], max_total_bytes=scale * limits["replicate"])
                retained_sources = {}
                if projected and (context["family"] == "GBM_COX"
                        or context["family"] == "RSF" and value["outer_fold"] == 4
                        and declared.get("identity_sha256")
                            == "1204c950c4f61b4a30ae3302825cad8720c77bd9c5daff68159c7eaaad88f9af"):
                    from .f5 import _q_gbm_source_evidence
                    from .nested_loco import WITHIN_FAMILY_NO_AAR_REDEVELOPMENT
                    q_root = extracted / "search" / WITHIN_FAMILY_NO_AAR_REDEVELOPMENT
                    if (q_root / "execution.json").is_file():
                        retained_sources, _ = _q_gbm_source_evidence(q_root, declared["resource_policy"])
                        if retained_sources:
                            carried = retained_sources["retained_primary_source_bundle"]
                            _require(retained_primary_source_bundle is None
                                     or sha256_file(retained_primary_source_bundle) == sha256_file(carried),
                                     "F5_GBM_Q_SOURCE_EVIDENCE_INVALID")
                            # Extracted source bytes already belong to the exact
                            # original outer member index. Prove them before the
                            # original input materializer needs its primary proof.
                            retained_primary_source_bundle = carried
                if projected:
                    release_f45_cumulative_files([path, input_bundle, extracted / "inputs.zip"],
                        owner="AAR_OUTER_REPLAY_EXTRACTED_INPUTS", report_root=root,
                        released_references=["closed_a12_outer_archive_extraction_streams"])
                prepared = materialize_a12_outer_inputs(extracted / "inputs.zip", lineage, root / "inputs", f2_run_root=f2_run_root,
                    f1_runtime_root=f1_runtime_root, retain_evidence=replay_evidence is not None,
                    **({"input_bundle": input_bundle} if projected else {}),
                    **({"retained_primary_source_bundle": retained_primary_source_bundle}
                       if retained_primary_source_bundle is not None else {}))
                if retained_sources:
                    prepared["retained_selector_source_bundle"] = retained_sources["retained_selector_source_bundle"]
                    if "retained_selector_executor_source_bundle" in retained_sources:
                        prepared["retained_selector_executor_source_bundle"] = retained_sources["retained_selector_executor_source_bundle"]
                q_executor_member = "execution-evidence/retained-sources/a12-q-executor.zip"
                if q_executor_member in value["members"]:
                    from .f4 import _retained_full0_source_members
                    from .nested_loco import WITHIN_FAMILY_NO_AAR_REDEVELOPMENT

                    carried = extracted / q_executor_member
                    _require(projected and context["family"] == "RSF" and value["outer_fold"] == 4
                             and declared.get("identity_sha256")
                                 == "1204c950c4f61b4a30ae3302825cad8720c77bd9c5daff68159c7eaaad88f9af"
                             and prepared["source"]["primary_source"]["primary_development_lock"].get(
                                 "selection_horizon_months", 24) == 24
                             and WITHIN_FAMILY_NO_AAR_REDEVELOPMENT in _a12_branch_names(prepared)
                             and carried.is_file() and not carried.is_symlink()
                             and carried.resolve(strict=True) == carried
                             and sha256_bytes(canonical_json_bytes(_retained_full0_source_members(
                                 carried, aar_q_executor=True)))
                                 == "5c30305f8279acc7407bffc1b9d2d09cb1d100f819f69d4e7486c131c8bee5df",
                             "F5_RETAINED_AAR_Q_EXECUTOR_DRIFT")
                    prepared["retained_a12_q_executor_source_bundle"] = carried
                if projected:
                    execution["input_expansion"] = prepared["input_expansion_resources"]
                _require(prepared["outer_fold"] == value["outer_fold"] and prepared["source"] == value["source"],
                         "F5_A12_OUTER_INPUT_COORDINATE_MISMATCH")
                if "estimability" in value:
                    prepared["estimability"] = value["estimability"]
                members = _a12_outer_retained_members(extracted, context["family"], value["outer_fold"], extracted / "inputs.zip", prepared=prepared)
                _require(set(members) == set(value["members"]), "F5_A12_OUTER_MEMBER_SET_INVALID")
                if projected:
                    # Replay may retain its own selector/Q input work beneath
                    # this directory. Producer reservations refer only to the
                    # exact archive members validated before that work starts.
                    branches = _a12_estimable_branches(prepared)
                    producer_shared_sizes = [
                        {name: value["members"][name]["size_bytes"] for name in _a12_outer_retained_members(
                            extracted, prepared["family"], prepared["outer_fold"], extracted / "inputs.zip",
                            prepared=prepared, before_final=True, completed_branches=branches[:index])}
                        for index in range(1, len(branches) + 1)]
                    development_owners = {}
                    prepared = _a12_projected_development_inputs(prepared, extracted / "development", replay=True,
                        q_input_lifecycle=development_owners)
                    _require(prepared.get("estimability") == value.get("estimability"),
                             "F5_A12_NONESTIMABLE_BRANCH_INVALID")
                    for role, row in development_owners.items():
                        input_owners[("development_inputs" if role == "development_inputs" else
                            "OUTER_SELECTED_FAMILY_NO_AAR_REDEVELOPMENT/" + role)] = row
                search_owners = {}
                searches = _a12_outer_searches(prepared, extracted, replay=True, workers=workers,
                    retain_evidence=replay_evidence is not None and not projected,
                    **({"q_input_lifecycle": search_owners} if projected else {}))
                for name, owners in search_owners.items():
                    input_owners.update({name + "/" + role: row for role, row in owners.items()})
                jobs = _a12_outer_model_jobs(prepared, searches)
                if replay_evidence is not None:
                    (root / "models").mkdir(mode=0o700)
                if projected:
                    _require(isinstance(value["native_members"], Mapping)
                             and set(value["native_members"]) == {f"fits/{job['name']}.zip" for job in jobs},
                             "F5_A12_OUTER_M20_REQUIRED")
                    jobs = [{**job, "numbers_path": extracted / "fits" / f"{job['name']}.numbers.json",
                        "native_archive": value["native_members"][f"fits/{job['name']}.zip"]} for job in jobs]
                else:
                    jobs = [{**job, "archive": extracted / "fits" / f"{job['name']}.zip",
                        **({"replay_evidence": root / "models" / job["name"]} if replay_evidence is not None else {})} for job in jobs]
                if projected:
                    producer = strict_json_bytes((extracted / "execution.json").read_bytes())
                    policy = prepared["source"]["resource_policy"]
                    retained = producer["resource_reservation"]["retained_bytes_per_component"]
                    worker_budget = producer["resource_reservation"].get("execution_worker_memory_bytes")
                    from .f5 import _f45_score_reuse_authorities
                    producer_identity = producer.get("executor_source_identity")
                    # The whole's original receipt stays intact. Only exact
                    # executors from this run's verified predecessor chain qualify.
                    _require((producer_identity == binding["executor_source_identity"]
                              or producer_identity in _f45_score_reuse_authorities()[0].values())
                             and type(worker_budget) is int and worker_budget in RECORDED_WORKER_MEMORY_BYTES,
                             "F5_A12_RETAINED_FINAL_EXECUTION_RECEIPT_REQUIRED")
                    sharded = "final_batches" in producer
                    _require(not sharded or "estimability" not in value, "F5_A12_OUTER_PRODUCER_GEOMETRY_INVALID")
                    reservation = _a12_final_resource_reservation(prepared["source"], jobs,
                        {name: record["size_bytes"] for name, record in value["members"].items()
                         if name != "execution.json" and (sharded or not name.startswith("fits/"))}, retained,
                        **({"task_names": []} if sharded else {"allow_partial": True} if "estimability" in value else {}), execution_worker_memory_bytes=worker_budget,
                        execution_scratch_reserve_bytes=producer["resource_reservation"].get("execution_scratch_reserve_bytes"))
                    _require(reservation == producer["resource_reservation"], "F5_A12_OUTER_RESOURCE_RESERVATION_DRIFT")
                    branches = _a12_estimable_branches(prepared)
                    if sharded:
                        _require(not {"branch_final_models", "final_model_pool"}.intersection(producer),
                                 "F5_A12_OUTER_PRODUCER_GEOMETRY_INVALID")
                        expected = resource_admission(reservation["effective_policy"], producer["resource_observation"], legal_tasks=60)
                        pool = producer["numerical_read_pool"]
                        _require(producer["resource_admission"] == expected and pool["status"] == "COMPLETED"
                                 and pool["configured_worker_ceiling"] == expected["limits"]["configured"]
                                 and pool["admitted_worker_ceiling"] == expected["admitted_worker_ceiling"]
                                 and pool["completed_task_count"] == pool["runnable_task_count"] == 60
                                 and pool["engine_threads"] == 1
                                 and 1 <= pool["actual_worker_process_peak"] <= min(60, expected["admitted_worker_ceiling"]),
                                 "F5_A12_OUTER_PRODUCER_GEOMETRY_INVALID")
                    else:
                        _require(isinstance(producer.get("branch_final_models"), Mapping)
                                 and set(producer["branch_final_models"]) == set(branches)
                                 and not {"resource_observation", "resource_admission", "final_model_pool"}.intersection(producer),
                                 "F5_A12_OUTER_PRODUCER_GEOMETRY_INVALID")
                        for index, branch in enumerate(branches, 1):
                            prefix = [job for job in jobs if strict_json_bytes(job["entries"]["task.json"])
                                      ["a12_coordinates"]["branch"] in branches[:index]]
                            _require(len(prefix) == 20 * index, "F5_A12_OUTER_M20_REQUIRED")
                            record = producer["branch_final_models"][branch]
                            reserved = _a12_final_resource_reservation(prepared["source"], prefix,
                                producer_shared_sizes[index - 1], retained, allow_partial=True,
                                execution_worker_memory_bytes=worker_budget,
                                execution_scratch_reserve_bytes=record["resource_reservation"].get("execution_scratch_reserve_bytes"))
                            _require(record["resource_reservation"] == reserved
                                     and (index != len(branches) or "estimability" in value or reserved == reservation),
                                     "F5_A12_OUTER_RESOURCE_RESERVATION_DRIFT")
                            current_jobs = [job for job in prefix if strict_json_bytes(job["entries"]["task.json"])
                                            ["a12_coordinates"]["branch"] == branch]
                            reused_count = sum("reused_final" in strict_json_bytes(job["numbers_path"].read_bytes())
                                               for job in current_jobs)
                            if reused_count:
                                _require(record.get("reused_final_model_count") == reused_count
                                    and record.get("physical_final_model_count") == 20 - reused_count,
                                    "F45_AAR_FINAL_REUSE_ACCOUNTING_INVALID")
                            else:
                                _require("reused_final_model_count" not in record
                                    and "physical_final_model_count" not in record,
                                    "F45_AAR_FINAL_REUSE_ACCOUNTING_INVALID")
                            runnable = 20 - reused_count
                            expected = resource_admission(reserved["effective_policy"], record["resource_observation"], legal_tasks=max(1, runnable))
                            pool = record["final_model_pool"]
                            _require(record["resource_admission"] == expected, "F5_A12_OUTER_PRODUCER_GEOMETRY_INVALID")
                            if not runnable:
                                _require(pool == {}, "F5_A12_OUTER_PRODUCER_GEOMETRY_INVALID")
                                continue
                            _require(pool["status"] == "COMPLETED"
                                     and pool["configured_worker_ceiling"] == record["resource_observation"]["effective_cpus"] - 8
                                     and pool["admitted_worker_ceiling"] == expected["admitted_worker_ceiling"]
                                     and pool["completed_task_count"] == pool["runnable_task_count"] == runnable
                                     and pool["engine_threads"] == 1
                                     and 1 <= pool["actual_worker_process_peak"] <= min(runnable, expected["admitted_worker_ceiling"]),
                                     "F5_A12_OUTER_PRODUCER_GEOMETRY_INVALID")
                    written = producer["archive_write"]
                    scratch_budget = written.get("execution_scratch_reserve_bytes")
                    _require(scratch_budget is None or type(scratch_budget) is int and scratch_budget == 0,
                             "F5_A12_OUTER_STORAGE_ESTIMATE_EXCEEDED")
                    archive_admission = resource_admission({**policy,
                        **({"memory_bytes_per_worker": worker_budget} if worker_budget is not None else {}),
                        "scratch_reserve_bytes": (policy["scratch_reserve_bytes"] + written["reserved_bytes"]
                            if scratch_budget is None else scratch_budget)},
                        written["resource_observation"], legal_tasks=1)
                    _require(written["resource_admission"] == archive_admission
                             and (scratch_budget is None or written["resource_observation"]["scratch_available_bytes"]
                                  >= written["reserved_bytes"])
                             and path.stat().st_size <= written["reserved_bytes"] <= reservation["archive_reserved_bytes"],
                             "F5_A12_OUTER_STORAGE_ESTIMATE_EXCEEDED")
                    component_sizes = [job["numbers_path"].stat().st_size for job in jobs]
                    _require(all(0 < size <= retained for size in component_sizes),
                             "F5_A12_COMPONENT_STORAGE_ESTIMATE_EXCEEDED")
                    # The already extracted numerical records need no additional
                    # model/audit/replay directories. Preserve their decode bound.
                    replay_policy = {**policy,
                        "scratch_reserve_bytes": 0,
                        "memory_reserve_bytes": policy["memory_reserve_bytes"] + reservation["coordinator_memory_estimate_bytes"],
                        "memory_bytes_per_worker": MIN_WORKER_MEMORY_BYTES}
                    observation = observe_execution_resources(root)
                    admission = resource_admission(replay_policy, observation, legal_tasks=len(jobs))
                    if sharded:
                        # Decode only after current admission, and only the exact
                        # leaves already bound by the original outer member index.
                        # Their roots describe the sealed producer, not this host.
                        release_reports = {}
                        for record in producer["final_batches"]:
                            pin = record["resource_release"]
                            with (extracted / pin["path"]).open("rb") as handle:
                                raw = handle.read(pin["size_bytes"] + 1)
                            _require(len(raw) == pin["size_bytes"], "F5_A12_FINAL_BATCH_RELEASE_INVALID")
                            release_reports[pin["path"]] = raw
                        component_native = {}
                        for job, size in zip(jobs, component_sizes, strict=True):
                            with job["numbers_path"].open("rb") as handle:
                                raw = handle.read(size + 1)
                            _require(len(raw) == size, "F5_A12_FINAL_NUMBERS_REQUIRED")
                            number = strict_json_bytes(raw)
                            component_native[job["name"]] = {key: number[key]
                                for key in ("native_archive", "native_expanded_bytes")}
                        del number
                        _a12_final_batch_execution(producer["final_batches"],
                            {job["name"]: value["members"][f"fits/{job['name']}.numbers.json"] for job in jobs},
                            prepared=prepared, jobs=jobs, shared_sizes=producer_shared_sizes[-1], retained=retained,
                            release_reports=release_reports, component_native=component_native)
                        del release_reports, component_native
                    execution.update(resource_observation=observation, resource_admission=admission,
                        replay_retention_reserved_bytes=0, effective_policy=replay_policy, numerical_read_pool={})
                    jobs = [{**job, "retained_bytes_per_component": retained} for job in jobs]
                    try:
                        rows = _bounded_ordered_spawn(_replay_ablation_component, jobs,
                            selected_slots=admission["admitted_worker_ceiling"], execution_report=execution["numerical_read_pool"])
                    finally:
                        (root / "execution.json").write_bytes(canonical_json_bytes(execution))
                else:
                    rows = [_replay_ablation_component(job) for job in jobs]
                observed = _a12_outer_predictions(prepared, jobs, rows)
                if replay_evidence is not None:
                    (root / "predictions.json").write_bytes(canonical_json_bytes(observed))
                _require(observed == value["predictions"], "F5_A12_OUTER_PREDICTION_REPLAY_MISMATCH")
                if projected:
                    record = _a12_outer_archive_record(value, path)
                    if _prepared_consumer is not None:
                        _prepared_consumer(value, jobs, record)
        finally:
            if projected:
                from .runtime import observe_step_memory
                call["before"] = observe_step_memory()
    try:
        consume()
        if projected:
            # These decoded-header/raw-byte copies have no remaining consumer.
            # Keep only the scientific return and independently bound small pins.
            del raw, declared, context, result_raw
            from .nested_loco import _write_exact_once
            from .runtime import observe_step_memory, release_step_resources
            expected_owners = {}
            report["last_consumer_finished_ns"] = call["before"]["started_ns"]
            before = call.pop("before")
            release_error = None
            try:
                for name, row in sorted(input_owners.items()):
                    owned = Path(row["temporary_root"])
                    if name == "archive":
                        # Exact extracted members exclude the separately owned
                        # replay scratch now nested beneath this archive root.
                        files = sorted(owned / name for name in ("a12-outer.json", *value["members"]))
                    else:
                        paths = sorted(owned.rglob("*"))
                        _require(all(not entry.is_symlink() and (entry.is_dir() or entry.is_file()) for entry in paths),
                                 "F5_A12_FINAL_INPUT_EXECUTION_INVALID")
                        files = [entry for entry in paths if entry.is_file()]
                    _require(owned.is_dir() and not owned.is_symlink() and owned.resolve(strict=True) == owned,
                             "F5_A12_FINAL_INPUT_EXECUTION_INVALID")
                    expected_owners[name] = {"root": owned, "files": {str(entry): entry.stat().st_size for entry in files}}
                    row["resource_release"] = release_step_resources(files,
                        owner="AAR_FINAL_INPUTS:OUTER_REPLAY:" + str(value["outer_fold"]) + ":" + name
                            + ":" + result_pin["sha256"], before=before,
                        released_references=["completed_a12_input_callers", "materialized_a12_inputs",
                                             "completed_a12_component_jobs", "completed_a12_prediction_rows"])
                    before = observe_step_memory()
                report["after_release"] = {"resource_observation": None, "resource_admission": None}
                try:
                    observation = observe_execution_resources(root)
                except OSError as error:
                    report["operational_errors"].append({"operation": "POST_STEP_OBSERVATION",
                        "error": "RESOURCE_OBSERVATION_FAILED:" + type(error).__name__ + ":" + str(error)})
                else:
                    report["after_release"]["resource_observation"] = observation
                    try:
                        report["after_release"]["resource_admission"] = resource_admission(effective, observation, legal_tasks=1)
                    except ContractError as error:
                        if not str(error).startswith("RESOURCE_ADMISSION_ZERO:"):
                            raise
                        report["operational_errors"].append({"operation": "POST_STEP_ADMISSION", "error": str(error)})
                report_raw = canonical_json_bytes(report)
                if len(report_raw) > 32 * 1024**2:
                    resource_admission({**effective, "memory_reserve_bytes": policy["memory_reserve_bytes"]
                        + 32 * len(report_raw)}, observe_execution_resources(root), legal_tasks=1)
                _validate_a12_final_input_execution(report_raw, binding=binding, result_pin=result_pin,
                    policy=policy, expected_owners=expected_owners)
            except BaseException as exc:
                release_error = exc
                raise
            finally:
                # This loader's original report is not the sealed producer's
                # archive/execution.json. Keep it even after successful cleanup.
                # Stage before replacement so a diagnostic write failure cannot
                # truncate the completed numerical report or mask its first error.
                try:
                    execution_raw = canonical_json_bytes({**execution, "input_execution": report})
                    _require(len(execution_raw) <= 64 * 1024**2, "F5_A12_FINAL_INPUT_EXECUTION_INVALID")
                    pending = root / "execution.json.input-pending"
                    _write_exact_once(pending, execution_raw, "F5_A12_FINAL_INPUT_EXECUTION_EXISTS")
                    pending.replace(root / "execution.json")
                except BaseException as diagnostic_error:
                    if release_error is None:
                        raise
                    release_error.add_note("F5_A12_FINAL_INPUT_DIAGNOSTIC_WRITE_FAILED:" + str(diagnostic_error))
            report_path = root / "execution.json"
            with report_path.open("rb") as handle:
                persisted = handle.read(len(execution_raw) + 1)
            _require(persisted == execution_raw, "F5_A12_FINAL_INPUT_EXECUTION_INVALID")
            if replay_evidence is None:
                owned_roots = {row["root"] for row in expected_owners.values()}
                removable = {Path(row["temporary_root"]) for row in input_owners.values()
                    if row["resource_release"]["reader_scan_status"] == "OBSERVED"
                    and all(member["status"] in {"ADVISED", "UNSUPPORTED"} and member["error"] is None
                        for member in row["resource_release"]["files"])}
                from .carriers import run_context
                if run_context() is not None:
                    removable = owned_roots
                blocked = owned_roots - removable
                for owned in sorted(removable, key=lambda entry: (-len(entry.parts), str(entry))):
                    # An archive owner excludes separately tracked nested roots.
                    # Its clean file list cannot authorize removing those roots.
                    if any(owned in child.parents for child in blocked):
                        blocked.add(owned)
                        continue
                    try:
                        shutil.rmtree(owned)
                    except OSError as error:
                        blocked.add(owned)
                        report["operational_errors"].append({"operation": "DISPOSABLE_INPUT_REMOVAL",
                            "error": str(owned) + ":" + type(error).__name__ + ":" + str(error)})
                _validate_a12_final_input_execution(canonical_json_bytes(report), binding=binding, result_pin=result_pin,
                    policy=policy, expected_owners=expected_owners)
                execution_raw = canonical_json_bytes({**execution, "input_execution": report})
                _require(len(execution_raw) <= 64 * 1024**2, "F5_A12_FINAL_INPUT_EXECUTION_INVALID")
                pending = root / "execution.json.input-pending"
                _write_exact_once(pending, execution_raw, "F5_A12_FINAL_INPUT_EXECUTION_EXISTS")
                pending.replace(report_path)
                with report_path.open("rb") as handle:
                    persisted = handle.read(len(execution_raw) + 1)
                _require(persisted == execution_raw, "F5_A12_FINAL_INPUT_EXECUTION_INVALID")
            if execution_report is not None:
                execution_report.update(path=str(report_path), sha256=sha256_bytes(persisted), size_bytes=len(persisted))
        elif replay_evidence is None:
            shutil.rmtree(root)
    except BaseException as exc:
        exc.add_note(f"F5_A12_OUTER_REPLAY_EVIDENCE_RETAINED:{root}")
        raise
    return value


def _a12_handoff_from_outers(context: Mapping[str, Any], outers: list[dict]) -> dict:
    if context["primary"].get("kind") == "PADML_NESTED_LOCO_SELECTED_POLICY_OOC_V1":
        from . import nested_loco as nested
        primary = nested.validate_selected_ooc(context["primary"], population_registry=context["population_registry"])
        science = nested.validate_science_decision(context["science_decision"])
        horizon = nested.selection_horizon(primary["selection_horizon_months"])
        _require(primary["science_decision_sha256"] == science["identity_sha256"],
                 "F5_A12_PRIMARY_HORIZON_SOURCE_INVALID")
        _require(len(outers) == 6 and [row["outer_fold"] for row in outers] == list(range(1, 7)),
                 "F5_A12_SIX_NATIVE_OUTERS_REQUIRED")
        families = {str(row["outer_fold"]): row["selected_family"] for row in primary["selection_by_outer"]}
        primary_archives = {row["outer_fold"]: row for row in context["source"]["primary_source_archives"]}
        indexed, unavailable = {}, []
        for row, selection in zip(outers, primary["selection_by_outer"], strict=True):
            outer, source = row["outer_fold"], row["source"]
            expected = context["population_registry"]["outer"][outer - 1]
            _require(row["kind"] == "PADML_F5_A12_OUTER_NATIVE_V2"
                     and row["family"] == selection["selected_family"]
                     and nested.compatible_science_decisions(source["primary_source"]["science_decision"], science)
                     and source["primary_source"]["primary_development_lock"]["identity_sha256"] == selection["development_lock_sha256"]
                     and source["primary_source"]["primary_development_lock"].get("selection_horizon_months", 24) == horizon
                     and (source["primary_source"]["primary_development_lock"].get(
                         "science_decision_binding", {}).get("science_decision_sha256")
                          == source["primary_source"]["science_decision"]["identity_sha256"])
                     and source["primary_source"]["primary_training_context"]["heldout_ids"] == expected["heldout_ids"]
                     and source["primary_source"]["primary_training_context"]["training_ids"] == expected["training_ids"]
                     and source["primary_archive_sha256"] == primary_archives[outer]["sha256"]
                     and source["primary_input_sha256"] == context["source"]["primary_input_sha256"][str(outer)],
                     "F5_A12_PRIMARY_OUTER_SOURCE_MISMATCH")
            active = _a12_estimable_branches(row)
            if "estimability" in row:
                unavailable.append({"outer_fold": outer, "native_outer_identity_sha256": row["identity_sha256"],
                    "selector": row["estimability"][nested.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT]})
            prediction = row["predictions"]
            _require(prediction["patient_ids"] == expected["heldout_ids"]
                     and prediction["centers"] == [str(expected["heldout_center"])] * len(expected["heldout_ids"])
                     and prediction["horizons"] == HORIZONS and set(prediction["survival"]) == set(active),
                     "F5_A12_OUTER_PREDICTION_SCHEMA_INVALID")
            for branch in active:
                _seal_prediction_matrix(prediction["patient_ids"], prediction["survival"][branch], HORIZONS)
            for index, patient in enumerate(prediction["patient_ids"]):
                _require(patient not in indexed, "F5_A12_OUTER_PATIENT_OVERLAP")
                indexed[patient] = prediction, index
        ids = primary["patient_ids"]
        _require(set(indexed) == set(ids), "F5_A12_ACCEPTED_PRIMARY_PATIENT_MISMATCH")
        branches = nested.AAR_ESTIMANDS[:2] if unavailable else nested.AAR_ESTIMANDS
        survival = {"PRIMARY": primary["survival"]["NESTED_SELECTED_POLICY"],
            **{branch: [indexed[patient][0]["survival"][branch][indexed[patient][1]] for patient in ids]
               for branch in branches}}
        provenance = []
        for branch in ("PRIMARY", *branches):
            objects = primary if branch == "PRIMARY" else [{"outer_fold": row["outer_fold"], "branch": branch,
                "native_outer_identity_sha256": row["identity_sha256"],
                "models": [row["native_members"][f"fits/O{row['outer_fold']}_{branch}_M{imp:02d}.zip"] for imp in range(1, 21)]}
                for row in outers]
            provenance.append({"branch": branch, "family_by_outer": families,
                "primary_ooc_sha256": primary["identity_sha256"],
                "prediction_sha256": _seal_prediction_matrix(ids, survival[branch], HORIZONS)["sha256"],
                "producer_receipt_sha256": sha256_bytes(canonical_json_bytes({"branch": branch, "objects": objects})),
                "estimand_contract": None if branch == "PRIMARY" else nested.aar_estimand_contract(branch),
                "parameter_policy_by_outer": {outer: (
                    "REUSE_POST_LOCK_PRIMARY_OUTER_M20" if branch == "PRIMARY" else
                    "FAIR_WITHIN_FAMILY_UNCHANGED_GRID" if family in _A12_TUNED_FAMILIES else "FIXED_SPEC_NO_TUNING")
                    for outer, family in families.items()},
                "primary_prediction_reused": branch == "PRIMARY", "selection_effect": "NONE"})
        handoff = {"kind": "PADML_F5_A12_ALIGNED_PREDICTIONS_V2", "program_id": nested.PROGRAM_ID,
            "science_decision": science, "population_registry": context["population_registry"], "primary_ooc": primary,
            "patient_keys": _patient_key_mapping(ids, None), "survival": survival, "branch_provenance": provenance}
        if unavailable:
            handoff["estimability"] = _a12_aggregate_estimability({nested.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT: {
                "status": "NOT_ESTIMABLE", "reason_code": "FREQUENCY_LADDER_EXHAUSTED", "unavailable_outers": unavailable}})
        _validate_a12_handoff(handoff)
        return handoff
    _require(len(outers) == 6 and [row["outer_fold"] for row in outers] == list(range(1, 7))
             and all(row["source"] == context["source"] and row["family"] == context["family"] for row in outers),
             "F5_A12_SIX_NATIVE_OUTERS_REQUIRED")
    primary, family = context["primary"], context["family"]
    ids, centers = primary["patient_ids"], primary["centers"]
    indices = {}
    for outer in outers:
        prediction = outer["predictions"]
        _require(prediction["horizons"] == HORIZONS and set(prediction["survival"]) == set(A12_BRANCHES[1:]),
                 "F5_A12_OUTER_PREDICTION_SCHEMA_INVALID")
        for index, (patient, center) in enumerate(zip(prediction["patient_ids"], prediction["centers"], strict=True)):
            _require(patient not in indices, "F5_A12_OUTER_PATIENT_OVERLAP")
            indices[patient] = (prediction, index, center)
    _require(set(indices) == set(ids) and [indices[patient][2] for patient in ids] == centers,
             "F5_A12_ACCEPTED_PRIMARY_PATIENT_MISMATCH")
    survival = {"PRIMARY_POLICY_A": primary["survival"][family]}
    survival.update({branch: [indices[patient][0]["survival"][branch][indices[patient][1]] for patient in ids]
                     for branch in A12_BRANCHES[1:]})
    provenance = []
    for branch in A12_BRANCHES:
        primary_branch = branch == "PRIMARY_POLICY_A"
        objects = context["source"] if primary_branch else [
            {"outer_fold": row["outer_fold"], "branch": branch,
             "models": [row["members"][f"fits/O{row['outer_fold']}_{branch}_M{imp:02d}.zip"] for imp in range(1, 21)]}
            for row in outers]
        provenance.append({"branch": branch, "family": family,
            "prediction_sha256": _seal_prediction_matrix(ids, survival[branch], HORIZONS)["sha256"],
            "producer_receipt_sha256": sha256_bytes(canonical_json_bytes({"branch": branch, "family": family, "objects": objects})),
            "variable_policy": _A12_VARIABLE_POLICIES[branch], "mice_policy": _A12_MICE_POLICIES[branch],
            "parameter_policy": ("REUSE_ACCEPTED_POLICY_A_PREDICTIONS" if primary_branch else
                                 "FAIR_WITHIN_FAMILY_UNCHANGED_GRID" if family in _A12_TUNED_FAMILIES else "FIXED_SPEC_NO_TUNING"),
            "primary_prediction_reused": primary_branch, "family_reselection": False, "grid_relaxed": False,
            "selection_effect": "NONE"})
    handoff = {"kind": "PADML_F5_A12_ALIGNED_PREDICTIONS_V1", "final_family": family,
               "patient_ids": ids, "patient_keys": primary["patient_keys"], "centers": centers,
               "horizons": HORIZONS, "survival": survival, "branch_provenance": provenance}
    _validate_a12_handoff(handoff)
    return handoff


def _a12_outer_archive_record(row: Mapping[str, Any], path: Path, *, source_pin=None, mice_index=None, _archive=None) -> dict:
    """Report replayed native quantities, never fill an authorized path maximum."""
    from contextlib import nullcontext
    # A compact member is not the original model ZIP: keep its original pin.
    _require(_archive is None or source_pin is not None, "F45_A12_BORROWED_SOURCE_PIN_REQUIRED")
    def reader():
        return open_carrier(path) if _archive is None else nullcontext(_archive)
    counts, reused_paths = {}, 0
    family = row["family"]
    branches = _a12_estimable_branches(row)
    if family in _A12_TUNED_FAMILIES:
        with reader() as archive:
            for branch in branches:
                name = "search.json" if family == "ELASTIC_NET_COX" else "result.json"
                value = strict_json_bytes(archive.read(f"search/{branch}/{name}"))
                if family == "ELASTIC_NET_COX" and "reused_search" in value:
                    shared = value["reused_search"]
                    _require(shared["shared_elastic_paths"] == value["path_execution_count"]
                        and shared["shared_glmnet_calls"] == value["glmnet_pilot_and_path_call_count"]
                        and shared["new_elastic_paths"] == shared["new_glmnet_calls"] == 0,
                        "F45_AAR_REUSE_ACCOUNTING_INVALID")
                    reused_paths += shared["shared_elastic_paths"]
                counts[branch] = ({"model_fits": 0, "stop_fits": 0, "elastic_paths": value["path_execution_count"],
                                   "glmnet_calls": value["glmnet_pilot_and_path_call_count"]} if family == "ELASTIC_NET_COX" else
                                  {"model_fits": value["locked_training_refit_count"], "stop_fits": value["response_free_stopping_fit_count"],
                                   "elastic_paths": 0, "glmnet_calls": 0})
    record = {"outer_fold": row["outer_fold"], "member": f"outer-o{row['outer_fold']}.zip", "identity_sha256": row["identity_sha256"],
              **(source_pin if source_pin is not None else
                 {"sha256": sha256_file(path), "size_bytes": path.stat().st_size}), "search_execution": counts}
    if branches != A12_BRANCHES[1:]:
        from .nested_loco import validate_science_decision
        science = validate_science_decision(row["source"]["primary_source"]["science_decision"])
        expected = {key: sum(science["fit_budget"][name]["per_outer_by_inherited_family"][family][key]
                             for name in ("a12_direct_total", "outer_selected_family_no_aar_redevelopment"))
                    for key in science["fit_budget"]["a12_direct_total"]["per_outer_by_inherited_family"][family]}
        if "estimability" in row:
            from .nested_loco import WITHIN_FAMILY_NO_AAR_REDEVELOPMENT
            # All MICE and coarse paths remain real work; there is no replacement model.
            direct = science["fit_budget"]["a12_direct_total"]["per_outer_by_inherited_family"][family]
            for key in ("candidate_prediction_fits", "stop_fits", "inner_scoring_fits", "post_lock_fits", "total_model_fits"):
                expected[key] = direct[key]
            record["estimability"] = row["estimability"]
        with reader() as archive:
            selector = strict_json_bytes(archive.read("development/selector/development-input.json"))
            if "estimability" in row:
                proof = row["estimability"][WITHIN_FAMILY_NO_AAR_REDEVELOPMENT]
                branch_name = f"development/{WITHIN_FAMILY_NO_AAR_REDEVELOPMENT}.json"
                raw = archive.read(branch_name)
                _require(sha256_bytes(raw) == row["members"][branch_name]["sha256"]
                    and len(raw) == row["members"][branch_name]["size_bytes"]
                    and strict_json_bytes(raw) == proof
                    and selector["identity_sha256"] == proof["selector_development_sha256"]
                    and selector["selector"].get("status") == "NOT_ESTIMABLE"
                    and selector["selector"]["epv_resolution"] == proof["epv_resolution"],
                    "F5_A12_NONESTIMABLE_BRANCH_INVALID")
            final_members = {f"fits/O{row['outer_fold']}_{branch}_M{imp:02d}.numbers.json" for branch in branches for imp in range(1, 21)}
            native_members = {name.removesuffix(".numbers.json") + ".zip" for name in final_members}
            present_native = {name for name in archive.namelist() if name in native_members}
            _require((not present_native or present_native == native_members)
                     and final_members | present_native == {name for name in archive.namelist() if name.startswith("fits/")}
                     and all(row["members"][name] == row["native_members"][name] for name in present_native),
                     "F5_A12_OUTER_M20_REQUIRED")
            reused_final_count = sum("reused_final" in strict_json_bytes(archive.read(name)) for name in final_members)
        observed = {
            "mice_chains": 20 * len(row["source"]["mice_inputs"]),
            "elastic_path_executions": selector["selector_path_count"] + sum(item["elastic_paths"] for item in counts.values()),
            "glmnet_pilot_and_path_calls": selector["glmnet_call_count"] + sum(item["glmnet_calls"] for item in counts.values()),
            "candidate_prediction_fits": sum(item["model_fits"] for item in counts.values()),
            "stop_fits": sum(item["stop_fits"] for item in counts.values()),
            "inner_scoring_fits": 0, "post_lock_fits": len(final_members),
        }
        observed["total_model_fits"] = sum(observed[key] for key in (
            "candidate_prediction_fits", "stop_fits", "inner_scoring_fits", "post_lock_fits"))
        _require(all(type(number) is int and number >= 0 for number in observed.values())
                 and all(type(number) is int and number >= 0 for item in counts.values() for number in item.values())
                 and type(selector["selector_path_count"]) is int and type(selector["glmnet_call_count"]) is int
                 and selector["glmnet_call_count"] == 2 * selector["selector_path_count"]
                 and observed["glmnet_pilot_and_path_calls"] == 2 * observed["elastic_path_executions"]
                 and observed["elastic_path_executions"] <= expected["elastic_path_executions_maximum"]
                 and observed["glmnet_pilot_and_path_calls"] <= expected["glmnet_pilot_and_path_calls_maximum"]
                 and all(observed[key] == expected[key] for key in observed
                         if key not in {"elastic_path_executions", "glmnet_pilot_and_path_calls"}),
                 "F5_A12_OUTER_EXECUTION_BUDGET_DRIFT")
        record["execution_ledger"] = observed
        # Budget coverage above remains logical. A shared computation belongs
        # to its first whole producer, including that unit's original resumes.
        with reader() as archive:
            selector_member = "development/selector/reuse.json"
            selector_reuse = (strict_json_bytes(archive.read(selector_member))
                              if selector_member in row["members"] else None)
            if mice_index is None:
                with archive.open("inputs.zip") as payload, open_carrier(payload) as mice:
                    _require(mice.getinfo("a12-inputs.json").file_size <= 32 * 1024**2,
                             "F5_A12_INPUT_INDEX_TOO_LARGE")
                    mice_index = strict_json_bytes(mice.read("a12-inputs.json"))
            reused_views = mice_index.get("mice_reuse", {})
        if reused_views or selector_reuse is not None or reused_final_count or reused_paths:
            shared = {key: 0 for key in observed}
            shared["mice_chains"] = 20 * len(reused_views)
            shared["post_lock_fits"] = shared["total_model_fits"] = reused_final_count
            if selector_reuse is not None:
                shared["elastic_path_executions"] = selector_reuse["execution"]["reused_selector_paths"]
            shared["elastic_path_executions"] += reused_paths
            shared["glmnet_pilot_and_path_calls"] = 2 * shared["elastic_path_executions"]
            _require(all(0 <= shared[key] <= observed[key] for key in shared),
                     "F45_AAR_REUSE_ACCOUNTING_INVALID")
            record["logical_execution_ledger"] = observed
            record["reused_execution_ledger"] = shared
            record["execution_ledger"] = {key: observed[key] - shared[key] for key in observed}
        from .carriers import run_context
        if run_context() is not None:
            passthrough_slots = 20 * sum(name not in reused_views and
                values["summary"].get("actual_mice_chains") == 0
                for name,values in mice_index.get("mice_views", {}).items())
            if passthrough_slots:
                record.setdefault("logical_execution_ledger", observed)
                record["execution_ledger"] = dict(record["execution_ledger"])
                record["execution_ledger"]["mice_chains"] -= passthrough_slots
                _require(record["execution_ledger"]["mice_chains"] >= 0, "F45_AAR_PASSTHROUGH_COUNT_DRIFT")
                record["nonexecuted_passthrough_mice_slots"] = passthrough_slots
        if family in {"COX_PH", "ELASTIC_NET_COX", "FPM_TVC_SET_A"}:
            from .nested_loco import A12_TOTAL_AAR
            prefix = f"development/recipes/{A12_TOTAL_AAR}/"
            retained = [name[len(prefix):].removesuffix("/reuse.json") for name in row["members"]
                if name.startswith(prefix) and name.endswith("/reuse.json")]
            if retained:
                with reader() as archive:
                    total = strict_json_bytes(archive.read(f"development/{A12_TOTAL_AAR}.json"))
                _require(set(retained) <= set(total["recipes"]), "F45_AAR_REUSE_ACCOUNTING_INVALID")
                record["total_recipe_execution"] = {"logical": len(total["recipes"]),
                    "shared": len(retained), "physical": len(total["recipes"]) - len(retained)}
    return record


def _a12_evaluation_member_names(*, nested: bool = False, sharded: bool = False) -> set[str]:
    _require(not sharded or nested, "F5_A12_BOOTSTRAP_PROFILE_INVALID")
    if sharded:
        return {"bootstrap-input.zip", "point-sources.zip", "execution.json", *(f"shard-{i}.zip" for i in range(1, 7))}
    return {"plan.json", "point-evaluation.json", "point-native.zip", *(f"replicate-{i:04d}.zip" for i in range(1, 1001)),
            *({"rng.zip", "execution.json", "primary-point-evaluation.json", "primary-point-native.zip",
               "aar-point-evaluation.json"} if nested else set())}


def _replay_a12_bootstrap_replicate(
    item: tuple[int, list[int]], *, root: Path, evaluation_handoff: Mapping[str, Any],
    response_csv: bytes, source_binding: Mapping[str, Any], admit_io=None,
    retained_bytes_per_replicate: int | None = None,
) -> dict[str, Any]:
    """Rebuild one retained paired row from actual draw, response and metric bytes.

    This is the original numerical consumer, usable in the same flat replicate
    partition as production. It runs neither a model, RNG nor an R metric job.
    """
    replicate, indices = item
    _require(retained_bytes_per_replicate is None
             or (root / f"replicate-{replicate:04d}.zip").stat().st_size <= retained_bytes_per_replicate,
             "F5_A12_BOOTSTRAP_STORAGE_ESTIMATE_EXCEEDED")
    ids, centers = evaluation_handoff["patient_ids"], evaluation_handoff["centers"]
    branches = _a12_prediction_branches(evaluation_handoff["survival"])
    counts = {center: centers.count(center) for center in _VALIDATION_CENTERS}
    _require(type(replicate) is int and 1 <= replicate <= source_binding["plan"]["replicate_count"]
             and isinstance(indices, list) and len(indices) == len(ids)
             and all(type(index) is int and 0 <= index < len(ids) for index in indices)
             and {center: sum(centers[index] == center for index in indices) for center in _VALIDATION_CENTERS} == counts,
             "F5_A12_RETAINED_DRAW_INVALID")
    path = root / f"replicate-{replicate:04d}.zip"
    with open_carrier(path) as archive:
        compact = "consumption.json" in archive.namelist()
    entries = read_safe_zip(path, expected_members=({"input.json", "result.json", "consumption.json"} if compact else
        {"input.json", "evaluation.json", "result.json", "metrics.zip"}), admit_io=admit_io)
    if compact:
        return _read_a12_compact_coordinate(entries, source=source_binding, indices=indices,
            replicate=replicate, handoff=evaluation_handoff)
    original_input = strict_json_bytes(entries["input.json"])
    _require(canonical_json_bytes(original_input) == entries["input.json"]
             and _a12_compatible_binding(original_input,
                 {**source_binding, "replicate": replicate, "draw_indices": indices}),
             "F5_A12_RETAINED_INPUT_MISMATCH")
    selected, response, receipt = materialize_resampled_view(evaluation_handoff, response_csv, indices, f"A12-PAIRED-{replicate:04d}")
    native = strict_json_bytes(entries["evaluation.json"])
    _validate_a12_native_evaluation(native, selected, response, native_archive=entries["metrics.zip"], admit_io=admit_io,
        **_a12_evaluation_scope(evaluation_handoff))
    row = _a12_bootstrap_row(replicate, receipt, native, branches=branches)
    _require(entries["result.json"] == canonical_json_bytes(row), "F5_A12_RETAINED_REDUCTION_MISMATCH")
    return row


def _replay_a12_bootstrap_plan(root: Path, handoff: Mapping[str, Any], response_csv: bytes, *,
                                nested: bool, admit_io=None) -> tuple[dict, dict]:
    """Validate all original draws before selecting any shard's replicate IDs."""
    from .f4 import PATIENT_KEY_RULE
    evaluation_handoff = {key: handoff[key] for key in ("patient_ids", "centers", "horizons", "survival")}
    evaluation_handoff.update(_a12_evaluation_scope(handoff))
    evaluation_handoff.update(_a12_evaluation_estimability(handoff))
    record = strict_json_bytes((root / "plan.json").read_bytes())
    plan = record["plan"]
    ids, centers = handoff["patient_ids"], handoff["centers"]
    _require(set(plan) == {"domain", "root_seed", "replicate_count", "rng", "r_version", "patient_key_rule", "source_sha256", "draws"}
             and plan["domain"] == "FIXED_MODEL_PAIRED" and plan["root_seed"] == 700000001 and plan["replicate_count"] == 1000
             and plan["rng"] == ["L'Ecuyer-CMRG", "Inversion", "Rejection"] and plan["patient_key_rule"] == PATIENT_KEY_RULE
             and isinstance(plan["r_version"], str) and bool(plan["r_version"])
             and plan["source_sha256"] == sha256_bytes(canonical_json_bytes({"patient_ids": ids, "centers": centers,
                 "patient_keys": [handoff["patient_keys"][patient] for patient in ids]}))
             and isinstance(plan["draws"], list) and len(plan["draws"]) == 1000,
             "F5_A12_RETAINED_PLAN_INVALID")
    source = _a12_bootstrap_binding(evaluation_handoff, response_csv, plan)
    _require(set(record) == {"source", "plan"} and _a12_compatible_binding(record["source"], source),
             "F5_A12_RETAINED_SOURCE_MISMATCH")
    if nested:
        actual_plan = bootstrap_draws(ids, centers, "FIXED_MODEL_PAIRED", replicate_count=1000,
            patient_keys=handoff["patient_keys"], replay_archive=root / "rng.zip", admit_io=admit_io)
        _require(actual_plan == plan, "F5_A12_RETAINED_RNG_MISMATCH")
    return plan, source


def _replay_a12_point(root: Path, handoff: Mapping[str, Any], response_csv: bytes, *,
                        retained_primary_point: Mapping[str, Any] | None = None,
                        primary_point_native: Path | bytes | None = None, admit_io=None) -> dict:
    """Consume the retained point sources without another metric-engine call."""
    nested = _a12_prediction_branches(handoff["survival"])[0] == "PRIMARY"
    evaluation_handoff = {key: handoff[key] for key in ("patient_ids", "centers", "horizons", "survival")}
    scope = _a12_evaluation_scope(handoff)
    evaluation_handoff.update(scope)
    evaluation_handoff.update(_a12_evaluation_estimability(handoff))
    point_raw = (root / "point-evaluation.json").read_bytes()
    point = strict_json_bytes(point_raw)
    if nested:
        primary_raw = (root / "primary-point-evaluation.json").read_bytes()
        primary_native = (root / "primary-point-native.zip").read_bytes()
        if retained_primary_point is not None or primary_point_native is not None:
            _require(isinstance(retained_primary_point, Mapping) and isinstance(primary_point_native, (Path, bytes))
                     and primary_raw == canonical_json_bytes(dict(retained_primary_point))
                     and primary_native == (primary_point_native.read_bytes() if isinstance(primary_point_native, Path)
                                            else primary_point_native), "F5_A12_PRIMARY_POINT_SOURCE_INVALID")
        origin = _a12_primary_point_origin(handoff, response_csv, strict_json_bytes(primary_raw), primary_native,
            admit_io=admit_io)
        aar = strict_json_bytes((root / "aar-point-evaluation.json").read_bytes())
        point_handoff = {**evaluation_handoff, "survival": {
            branch: matrix for branch, matrix in evaluation_handoff["survival"].items() if branch != "PRIMARY"}}
        _validate_a12_native_evaluation(aar, point_handoff, response_csv,
            native_archive=root / "point-native.zip", point_branch_scope="THREE_AAR", admit_io=admit_io, **scope)
        _require(point_raw == canonical_json_bytes(_merge_a12_point_evaluations(origin, aar, estimability=handoff.get("estimability"))),
                 "F5_A12_POINT_SOURCE_SCOPE_MISMATCH")
    else:
        _require(retained_primary_point is None and primary_point_native is None, "F5_A12_BOOTSTRAP_PROFILE_INVALID")
        _validate_a12_native_evaluation(point, evaluation_handoff, response_csv, native_archive=root / "point-native.zip",
            admit_io=admit_io)
    return point


def _replay_a12_evaluation(root: Path, predictions: Mapping[str, Any], response_csv: bytes, *,
                           retained_primary_point: Mapping[str, Any] | None = None,
                           primary_point_native: Path | bytes | None = None) -> dict:
    """Read the first B1000, validate original draws/support, and only redo derived arithmetic."""
    handoff = _validate_a12_handoff(predictions)
    nested = _a12_prediction_branches(handoff["survival"])[0] == "PRIMARY"
    evaluation_handoff = {key: handoff[key] for key in ("patient_ids", "centers", "horizons", "survival")}
    evaluation_handoff.update(_a12_evaluation_scope(handoff))
    evaluation_handoff.update(_a12_evaluation_estimability(handoff))
    ids = handoff["patient_ids"]
    plan, source = _replay_a12_bootstrap_plan(root, handoff, response_csv, nested=nested)
    execution = strict_json_bytes((root / "execution.json").read_bytes()) if nested else None
    point = _replay_a12_point(root, handoff, response_csv,
        retained_primary_point=retained_primary_point, primary_point_native=primary_point_native)
    replicates = [_replay_a12_bootstrap_replicate(item, root=root,
        evaluation_handoff=evaluation_handoff, response_csv=response_csv, source_binding=source,
        retained_bytes_per_replicate=execution["resource_reservation"]["retained_bytes_per_replicate"] if nested else None)
        for item in _a12_replicate_items(plan)]
    result = _reduce_a12_incremental_value(handoff, plan, point, replicates, formal=True)
    if nested:
        from .runtime import resource_admission, validate_resource_policy
        from .f4 import _f45_source_member_sha256
        policy = validate_resource_policy(execution["resource_policy"])
        reservation = execution["resource_reservation"]
        worker_budget = execution.get("execution_worker_memory_bytes")
        from .f5 import _f45_score_reuse_authorities
        _require(type(worker_budget) is int and worker_budget in RECORDED_WORKER_MEMORY_BYTES
                 and execution.get("executor_source_identity") in _f45_score_reuse_authorities()[0].values(),
                 "F5_A12_BOOTSTRAP_WORKER_MEMORY_BUDGET_INVALID")
        retained = reservation["retained_bytes_per_replicate"]
        _require(type(retained) is int and retained > 0, "F5_A12_BOOTSTRAP_EXECUTION_INVALID")
        handoff_bytes = len(canonical_json_bytes(evaluation_handoff))
        draw_bytes = 16 * 1000 * len(ids)
        primary_bytes = sum((root / name).stat().st_size for name in ("primary-point-evaluation.json", "primary-point-native.zip"))
        point_reserved = 3 * sum((root / name).stat().st_size for name in _A12_NESTED_POINT_MEMBERS) + 16384
        separate_point = "point_retention_reserved_bytes" in reservation
        _require(reservation == {"kind": "OPERATIONAL_ESTIMATE_NOT_MEASURED_PEAK",
            "retained_bytes_per_replicate": retained, "shared_draw_storage_reserved_bytes": 2 * draw_bytes,
            "metric_retention_reserved_bytes": 1000 * retained + point_reserved if separate_point else 1001 * retained,
            **({"point_retention_reserved_bytes": point_reserved} if separate_point else {}),
            "coordinator_memory_estimate_bytes": 32 * (handoff_bytes + draw_bytes + primary_bytes) + 128 * 1000 * ((2 * 4 - 1) * ((12 * len(REPORT_HORIZONS) + 2) + 7 * (10 * len(REPORT_HORIZONS) + 2)))},
            "F5_A12_BOOTSTRAP_EXECUTION_INVALID")
        if separate_point:
            _require(execution["point_storage_observation"]["scratch_available_bytes"] >= point_reserved + 3 * 1000 * retained,
                     "F5_A12_BOOTSTRAP_PACKAGING_SPACE_INSUFFICIENT")
        scratch_budget = execution.get("execution_scratch_reserve_bytes")
        _require(scratch_budget is None or type(scratch_budget) is int and scratch_budget == 0,
                 "F5_A12_BOOTSTRAP_SCRATCH_BUDGET_INVALID")
        effective_policy = {**policy,
            "scratch_reserve_bytes": (policy["scratch_reserve_bytes"] + 2 * draw_bytes + 1001 * retained
                if scratch_budget is None else scratch_budget),
            "memory_reserve_bytes": policy["memory_reserve_bytes"] + reservation["coordinator_memory_estimate_bytes"],
            "memory_bytes_per_worker": worker_budget}
        admission = resource_admission(effective_policy, execution["resource_observation"], legal_tasks=1000)
        pool = execution["bootstrap_pool"]
        expected_slots = admission["admitted_worker_ceiling"]
        if "active_worker_temporary_bytes" in execution or "storage_worker_ceiling" in execution:
            _require(handoff["science_decision"].get("integrated_raw_data", {}).get("compact_coordinates") is True,
                     "F5_A12_BOOTSTRAP_EXECUTION_INVALID")
            transient = max(policy["scratch_bytes_per_worker"], 3 * (64 * handoff_bytes + 16 * 1024**2))
            disk_slots = (execution["point_storage_observation"]["scratch_available_bytes"] - point_reserved - 3 * 1000 * retained) // transient
            _require(execution["active_worker_temporary_bytes"] == transient
                and execution["storage_worker_ceiling"] == disk_slots and disk_slots >= 1,
                "F5_A12_BOOTSTRAP_EXECUTION_INVALID")
            expected_slots = min(expected_slots, disk_slots)
        _require(execution["effective_policy"] == effective_policy and execution["resource_admission"] == admission
                 and pool["status"] == "COMPLETED" and pool["configured_worker_ceiling"] == execution["resource_observation"]["effective_cpus"] - 8
                 and pool["admitted_worker_ceiling"] == expected_slots
                 and pool["completed_task_count"] == pool["runnable_task_count"] == 1000
                 and pool["engine_threads"] == 1
                 and 1 <= pool["actual_worker_process_peak"] <= expected_slots,
                 "F5_A12_BOOTSTRAP_EXECUTION_INVALID")
        _require(sum((root / name).stat().st_size for name in ("rng.zip", "plan.json")) <= 2 * draw_bytes
                 and (separate_point or point_reserved <= retained)
                 and all((root / f"replicate-{i:04d}.zip").stat().st_size <= retained for i in range(1, 1001)),
                 "F5_A12_BOOTSTRAP_STORAGE_ESTIMATE_EXCEEDED")
        result["evaluation_execution"] = execution
    return result


def _a12_native_summary(context: Mapping[str, Any], numeric: Mapping[str, Any], records: list[dict]) -> dict:
    if context["primary"].get("kind") == "PADML_NESTED_LOCO_SELECTED_POLICY_OOC_V1":
        from .nested_loco import AAR_ESTIMANDS, WITHIN_FAMILY_NO_AAR_REDEVELOPMENT
        estimability = _a12_aggregate_estimability(numeric.get("estimability"))
        branch_count = 2 if estimability else 3
        unavailable = [{"outer_fold": row["outer_fold"], "native_outer_identity_sha256": row["identity_sha256"],
            "selector": row["estimability"][WITHIN_FAMILY_NO_AAR_REDEVELOPMENT]}
            for row in records if "estimability" in row]
        _require((estimability[WITHIN_FAMILY_NO_AAR_REDEVELOPMENT]["unavailable_outers"] if estimability else [])
            == unavailable, "F5_A12_NATIVE_AGGREGATE_INVALID")
        _require([row["outer_fold"] for row in records] == list(range(1, 7))
                 and numeric["family_by_outer"] == context["family_by_outer"]
                 and numeric["science_decision_sha256"] == context["science_decision"]["identity_sha256"]
                 and numeric["primary_ooc_sha256"] == context["primary"]["identity_sha256"]
                 and numeric["bootstrap"]["replicate_count"] == 1000 and numeric["bootstrap"]["paired_row_count"] == branch_count * (len(numeric["bootstrap"]["metrics"]["macro"]) + (8 if "weighted_center_macro" in numeric else 7) * len(numeric["bootstrap"]["metrics"]["scope"])),
                 "F5_A12_NATIVE_AGGREGATE_INVALID")
        totals = {key: sum(row["execution_ledger"][key] for row in records) for key in records[0]["execution_ledger"]}
        logical = {key: sum(row.get("logical_execution_ledger", row["execution_ledger"])[key]
                          for row in records) for key in totals}
        reused = {key: sum(row.get("reused_execution_ledger", {}).get(key, 0)
                         for row in records) for key in totals}
        _require(logical["post_lock_fits"] == 360 - 20 * len(unavailable) and logical["inner_scoring_fits"] == 0
                 and all(logical[key] == totals[key] + reused[key] for key in totals),
                 "F5_A12_NATIVE_AGGREGATE_INVALID")
        result = {key: value for key, value in numeric.items() if key not in {"model_fit_count", "grid_search_count"}}
        return {**result, "status": "COMPLETED_ZERO_FEEDBACK", "execution_scope": ("FORMAL_SIX_OUTER_PARTIAL_AAR_FIXED_PREDICTION_B1000" if estimability else
                "FORMAL_SIX_OUTER_THREE_AAR_FIXED_PREDICTION_B1000"),
            "execution_evidence_status": "NATIVE_PRIMARY_AND_AAR_OBJECTS_AND_FIRST_PAIRED_BOOTSTRAP_RESULTS",
            "blocking_for_production": False, "unverified_authority_sources": [], "source": context["source"],
            "source_archives": records, "actual_aar_execution_ledger": totals,
            "post_lock_model_fit_execution_count": totals["post_lock_fits"],
            **({"logical_aar_execution_ledger": logical, "reused_aar_execution_ledger": reused,
                "post_lock_logical_fit_count": logical["post_lock_fits"],
                "post_lock_reused_fit_count": reused["post_lock_fits"]}
               if context.get("compact_evaluation") else {}),
            "post_lock_additional_stop_fit_execution_count": 0,
            "mice_chain_execution_count": totals["mice_chains"], "evaluation_new_model_fit_count": 0,
            "metric_calibration_engine_invocations": 1001, "metric_scope_branch_job_count": 7 * branch_count + 1000 * 7 * (1 + branch_count),
            "new_aar_point_metric_job_count": 7 * branch_count, "reused_primary_point_metric_job_count": 7,
            "primary_archive_point_metric_reexecution_count": 0,
            "bootstrap_evaluation_execution_count": 1000, "full_retraining_bootstrap_replicates": 0,
            "full_data_model_independently_validated": False, "stage_acceptance": False,
            "replay_scope": ("PREPARED_PRIMARY_AND_AAR_M20_NUMBERS_THEN_FIRST_POINT_RNG_AND_METRIC_ARCHIVES_WITHOUT_REEXECUTION"
                             if context.get("prepared_numerical_sources") else
                             "NATIVE_PRIMARY_AND_AAR_THEN_FIRST_POINT_RNG_AND_METRIC_ARCHIVES_WITHOUT_REEXECUTION")}
    from .f4 import PROSPECTIVE_PROTOCOL_REVISION
    _require([row["outer_fold"] for row in records] == list(range(1, 7))
             and numeric["final_family"] == context["family"] and numeric["bootstrap"]["replicate_count"] == 1000
             and numeric["bootstrap"]["paired_row_count"] == 608, "F5_A12_NATIVE_AGGREGATE_INVALID")
    totals = {key: sum(value[key] for row in records for value in row["search_execution"].values())
              for key in ("model_fits", "stop_fits", "elastic_paths", "glmnet_calls")}
    result = {key: value for key, value in numeric.items() if key not in {"model_fit_count", "grid_search_count"}}
    return {**result, "status": "COMPLETED_ZERO_FEEDBACK", "execution_scope": "FORMAL_SIX_OUTER_A12",
            "execution_evidence_status": "NATIVE_OBJECTS_INPUTS_AND_FIRST_BOOTSTRAP_RESULTS",
            "blocking_for_production": False, "unverified_authority_sources": [], "source": context["source"],
            "source_archives": records, "outer_model_fit_execution_count": 240, "outer_stop_fit_execution_count": 0,
            "search_execution_totals": totals, "search_program_execution_count": sum(len(row["search_execution"]) for row in records),
            "evaluation_new_model_fit_count": 0,
            "mice_chain_execution_count": sum(20 * len(_a12_outer_layout(context, outer)["view_names"]) for outer in range(1, 7)),
            "bootstrap_evaluation_execution_count": 1000, "scientific_revision": PROSPECTIVE_PROTOCOL_REVISION,
            "replay_scope": "NATIVE_MODELS_AND_INPUTS_THEN_RETAINED_BOOTSTRAP_DERIVED_ARITHMETIC_NOT_METRIC_REEXECUTION"}


def replay_a12_bundle(source: Path, lineage: Mapping[str, Any] | None = None, *, f2_run_root: Path | None = None,
                      f1_runtime_root: Path | None = None, replay_evidence: Path | None = None,
                      primary_input_bundles: Mapping[int, Path] | None = None,
                      primary_compiled_input_records: Mapping[int, Mapping[str, Any]] | None = None,
                      input_bundles: Mapping[int, Path] | None = None,
                      resource_policy: Mapping[str, Any] | None = None,
                      prepared_input_record: Mapping[str, Any] | None = None,
                      retained_primary_source_bundle: Path | None = None,
                      execution_report: dict[str, Any] | None = None) -> tuple[dict, dict]:
    from contextlib import nullcontext
    from .bundle import _admit_zip_directory, _validated_zip_infos, _stream_zip_member
    from .f4 import _full_pipeline_archive_limits, O_FIT_COMPONENT_BYTES
    from .f5 import _full_score_scratch
    from .runtime import observe_execution_resources, resource_admission, validate_resource_policy

    _require(source.is_absolute() and source.is_file() and not source.is_symlink(), "F5_A12_NATIVE_ARCHIVE_REQUIRED")
    prepared = prepared_input_record is not None
    nested = primary_input_bundles is not None or input_bundles is not None or prepared
    _require(execution_report is None or nested and isinstance(execution_report, dict) and not execution_report,
             "F5_A12_FINAL_INPUT_EXECUTION_INVALID")
    outer_input_reports = {}
    _require(retained_primary_source_bundle is None or nested, "F5_RETAINED_AAR_SOURCE_SCOPE_INVALID")
    retained_primary = ({"retained_primary_source_bundle": retained_primary_source_bundle}
                        if retained_primary_source_bundle is not None else {})
    if prepared:
        _require(lineage is None and f2_run_root is None and f1_runtime_root is None
                 and primary_input_bundles is None and primary_compiled_input_records is None and input_bundles is None,
                 "F5_A12_PREPARATION_AUTHORITY_MIXED")
    if nested:
        _require(lineage is None and (prepared or primary_input_bundles is not None and input_bundles is not None
                 and set(primary_input_bundles) == set(input_bundles) == set(range(1, 7))
                 and isinstance(primary_compiled_input_records, Mapping)
                 and set(primary_compiled_input_records) == set(range(1, 7)))
                 and replay_evidence is not None and replay_evidence.is_absolute()
                 and replay_evidence.parent.is_dir() and not replay_evidence.exists() and not replay_evidence.is_symlink(),
                 "F5_A12_NESTED_AGGREGATE_SCOPE_INVALID")
        resource_policy = validate_resource_policy(resource_policy)
        resource_admission({**resource_policy, "memory_bytes_per_worker": MIN_WORKER_MEMORY_BYTES},
            observe_execution_resources(replay_evidence.parent), legal_tasks=1)
        root = replay_evidence
        limits = {key: max(_full_pipeline_archive_limits(family)[key]
                          for family in _A12_FIXED_FAMILIES | _A12_TUNED_FAMILIES)
                  for key in ("replicate", "metadata")}
        primary_limit = (6 * (3 * 2100 + 166) + 2) * O_FIT_COMPONENT_BYTES
        member_limit = max(3 * limits["replicate"], primary_limit)
        total_limit = primary_limit + 18 * limits["replicate"] + 1010 * O_FIT_COMPONENT_BYTES
    else:
        _require(resource_policy is None and lineage is not None and primary_compiled_input_records is None,
                 "F5_A12_NESTED_AGGREGATE_SCOPE_INVALID")
        context = _a12_context(f2_run_root, lineage, f1_runtime_root=f1_runtime_root)
        limits = _full_pipeline_archive_limits(context["family"])
        member_limit, total_limit = 2 * limits["replicate"], 12 * limits["replicate"] + 1003 * O_FIT_COMPONENT_BYTES
        root = Path(tempfile.mkdtemp(prefix="padml-a12-aggregate-replay-")).resolve()
        if replay_evidence is not None:
            replay_evidence.mkdir(mode=0o700)
    sharded = False
    if nested:
        def admit_directory(*, memory_bytes: int) -> None:
            resource_admission({**resource_policy,
                "memory_bytes_per_worker": MIN_WORKER_MEMORY_BYTES,
                "memory_reserve_bytes": resource_policy["memory_reserve_bytes"] + memory_bytes},
                observe_execution_resources(root.parent), legal_tasks=1)
        _admit_zip_directory(source, admit_directory)
        with open_carrier(source) as archive:
            sharded = "evaluation/bootstrap-input.zip" in archive.namelist()
    _require(not prepared or sharded, "F5_A12_BOOTSTRAP_PROFILE_INVALID")
    names = {"a12.json", *(() if prepared else (f"outer-o{i}.zip" for i in range(1, 7))),
             *(f"evaluation/{name}" for name in _a12_evaluation_member_names(nested=nested, sharded=sharded)),
             *({"predictions.json", "aggregate-execution.json"} if nested else set()),
             *({"primary.zip"} if nested and not prepared else set())}
    if nested:
        expansion = _a12_input_expansion_resources(source, root, resource_policy, members=names,
            max_member_bytes=member_limit, max_total_bytes=total_limit)
        root.mkdir(mode=0o700)
        (root / "input-expansion.json").write_bytes(canonical_json_bytes(expansion))
    try:
        with (_full_score_scratch(root) if nested else nullcontext()), open_carrier(source) as archive:
            _require(archive.getinfo("a12.json").file_size <= O_FIT_COMPONENT_BYTES, "F5_A12_AGGREGATE_INDEX_TOO_LARGE")
            raw = archive.read("a12.json")
            value = strict_json_bytes(raw)
            _require(canonical_json_bytes(value) == raw and len(value.get("source_archives", [])) == 6,
                     "F5_A12_NATIVE_ARCHIVE_REQUIRED")
            infos = {info.filename: info for info in _validated_zip_infos(archive, names,
                max_member_bytes=member_limit, max_total_bytes=total_limit, max_compression_ratio=1000)}
            if nested:
                _require(value["kind"] == "PADML_F5_A12_INCREMENTAL_VALUE_V2"
                         and infos["aggregate-execution.json"].file_size <= 64 * 1024
                         and infos["predictions.json"].file_size <= O_FIT_COMPONENT_BYTES,
                         "F5_A12_NESTED_AGGREGATE_SCOPE_INVALID")
                written = strict_json_bytes(archive.read("aggregate-execution.json"))
                from .f4 import _f45_source_member_sha256
                _require(written.get("executor_source_identity") == sha256_bytes(canonical_json_bytes(_f45_source_member_sha256()))
                         and type(written.get("execution_worker_memory_bytes")) is int
                         and written["execution_worker_memory_bytes"] in RECORDED_WORKER_MEMORY_BYTES,
                         "F5_A12_AGGREGATE_EXECUTION_MISMATCH")
                original_policy = validate_resource_policy(written["resource_policy"])
                reserved = 2 * (sum(info.file_size for name, info in infos.items()
                    if name not in {"a12.json", "aggregate-execution.json"}) + len(raw) + 1024 * (len(infos) - 2))
                admission = resource_admission({**original_policy,
                    "memory_bytes_per_worker": written["execution_worker_memory_bytes"],
                    "scratch_reserve_bytes": (0 if "execution_scratch_reserve_bytes" in written
                        else original_policy["scratch_reserve_bytes"] + reserved)},
                    written["resource_observation"], legal_tasks=1)
                _require("execution_scratch_reserve_bytes" not in written or
                         type(written["execution_scratch_reserve_bytes"]) is int
                         and written["execution_scratch_reserve_bytes"] == 0
                         and written["resource_observation"]["scratch_available_bytes"] >= reserved,
                         "F5_A12_AGGREGATE_EXECUTION_MISMATCH")
                _require(written["archive_reserved_bytes"] == reserved and written["resource_admission"] == admission,
                         "F5_A12_AGGREGATE_EXECUTION_MISMATCH")
                # Finish the already-admitted flat archive extraction before
                # native readers add their separately retained working trees.
                for name, info in infos.items():
                    destination = root / name
                    destination.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
                    with destination.open("xb") as handle:
                        _stream_zip_member(archive, info, handle)
                if prepared:
                    _a12_prepared_input_record(prepared_input_record, root / "evaluation/bootstrap-input.zip")
                    prepared_data = _read_a12_prepared_sources(root / "evaluation/point-sources.zip", root / "prepared-replay",
                        prepared_input_record=prepared_input_record, resource_policy=resource_policy, **retained_primary)
                    context = prepared_data["context"]
                    original_reader = written["prepared_numerical_reader"]
                    _require(original_reader.get("executor_source_identity") == written["executor_source_identity"]
                             and type(original_reader.get("execution_worker_memory_bytes")) is int
                             and original_reader["execution_worker_memory_bytes"] in RECORDED_WORKER_MEMORY_BYTES,
                             "F5_A12_PREPARATION_READER_EXECUTION_INVALID")
                    reader_policy = _a12_bootstrap_reader_policy(validate_resource_policy(original_reader["resource_policy"]),
                        prepared_data["execution"]["resource_reservation"],
                        execution_worker_memory_bytes=original_reader["execution_worker_memory_bytes"],
                        execution_scratch_reserve_bytes=original_reader.get("execution_scratch_reserve_bytes"))
                    reader_count = 6 + prepared_data["execution"]["resource_reservation"]["aar_mi_reader_count"]
                    reader_admission = resource_admission(reader_policy, original_reader["resource_observation"], legal_tasks=reader_count)
                    pool = original_reader["pool"]
                    _require(canonical_json_bytes(original_reader["resource_reservation"])
                                 == canonical_json_bytes(prepared_data["execution"]["resource_reservation"])
                             and canonical_json_bytes(original_reader["effective_policy"]) == canonical_json_bytes(reader_policy)
                             and canonical_json_bytes(original_reader["resource_admission"]) == canonical_json_bytes(reader_admission)
                             and set(pool) == {"status", "engine_threads", "configured_worker_ceiling", "admitted_worker_ceiling",
                                 "completed_task_count", "runnable_task_count", "actual_worker_process_peak"}
                             and all(type(pool[key]) is int for key in pool if key != "status")
                             and pool["status"] == "COMPLETED" and pool["engine_threads"] == 1
                             and pool["configured_worker_ceiling"] == original_reader["resource_observation"]["effective_cpus"] - 8
                             and pool["admitted_worker_ceiling"] == reader_admission["admitted_worker_ceiling"]
                             and pool["completed_task_count"] == pool["runnable_task_count"] == reader_count
                             and 1 <= pool["actual_worker_process_peak"] <= reader_admission["admitted_worker_ceiling"],
                             "F5_A12_PREPARATION_READER_EXECUTION_INVALID")
                else:
                    primary_path = root / "primary.zip"
                    _require(sha256_file(primary_path) == value["source"]["primary_aggregate_sha256"], "F5_A12_PRIMARY_ARCHIVE_MISMATCH")
                    context = _a12_context(f2_run_root, None, f1_runtime_root=f1_runtime_root,
                        primary_archive=primary_path, primary_input_bundles=primary_input_bundles,
                        primary_compiled_input_records=primary_compiled_input_records,
                        replay_evidence=root / "primary-replay", **retained_primary)
            outers, records = [], []
            if prepared:
                outers, records = prepared_data["outers"], prepared_data["source_archives"]
                _require(records == value["source_archives"], "F5_A12_AGGREGATE_OUTER_MISMATCH")
            for outer, expected in (() if prepared else enumerate(value["source_archives"], 1)):
                path = root / f"outer-o{outer}.zip"
                if nested:
                    digest, size = sha256_file(path), path.stat().st_size
                else:
                    with path.open("xb") as handle:
                        digest, size = _stream_zip_member(archive, infos[path.name], handle)
                _require(expected["outer_fold"] == outer and expected["member"] == path.name
                         and expected["sha256"] == digest and expected["size_bytes"] == size,
                         "F5_A12_AGGREGATE_MEMBER_MISMATCH")
                loader_execution = {}
                row = (_load_a12_outer_archive(path, input_bundle=input_bundles[outer],
                       execution_report=loader_execution, **retained_primary) if nested else
                       _load_a12_outer_archive(path, lineage, f2_run_root=f2_run_root, f1_runtime_root=f1_runtime_root,
                        **({"replay_evidence": replay_evidence / f"outer-o{outer}"} if replay_evidence is not None else {})))
                if nested:
                    from .f4 import _f45_source_member_sha256
                    _require(set(loader_execution) == {"path", "sha256", "size_bytes"}
                             and type(loader_execution["size_bytes"]) is int
                             and 0 < loader_execution["size_bytes"] <= 64 * 1024**2,
                             "F5_A12_FINAL_INPUT_EXECUTION_INVALID")
                    resource_admission({**resource_policy, "memory_bytes_per_worker": MIN_WORKER_MEMORY_BYTES,
                        "memory_reserve_bytes": resource_policy["memory_reserve_bytes"]
                        + 32 * loader_execution["size_bytes"]}, observe_execution_resources(root), legal_tasks=1)
                    report_path = Path(loader_execution["path"])
                    _require(report_path.is_file() and not report_path.is_symlink()
                             and report_path.resolve(strict=True) == report_path, "F5_A12_FINAL_INPUT_EXECUTION_INVALID")
                    with report_path.open("rb") as handle:
                        report_raw = handle.read(loader_execution["size_bytes"] + 1)
                    row_raw = canonical_json_bytes(row)
                    _validate_a12_final_input_execution(report_raw, binding={
                        "executor_source_identity": sha256_bytes(canonical_json_bytes(_f45_source_member_sha256())),
                        "operation": "OUTER_REPLAY", "outer_fold": outer, "family": row["family"],
                        "task_names": list(_a12_final_task_coordinates(outer)),
                        "input_archive": {"sha256": digest, "size_bytes": size},
                        "projected_input": {"sha256": sha256_file(input_bundles[outer]), "size_bytes": input_bundles[outer].stat().st_size},
                        "projected_input_identity_sha256": row["source"]["identity_sha256"], "work_root": str(report_path.parent)},
                        result_pin={"sha256": sha256_bytes(row_raw), "size_bytes": len(row_raw)},
                        policy=row["source"]["resource_policy"], loader_report=True,
                        expected_pin={key: loader_execution[key] for key in ("sha256", "size_bytes")})
                    del report_raw, row_raw
                    outer_input_reports[str(outer)] = loader_execution
                actual = _a12_outer_archive_record(row, path)
                _require(row["outer_fold"] == outer and actual == expected, "F5_A12_AGGREGATE_OUTER_MISMATCH")
                outers.append(row)
                records.append(actual)
                if not nested:
                    path.unlink()
            if not nested:
                (root / "evaluation").mkdir(mode=0o700)
                for name in _a12_evaluation_member_names():
                    with (root / "evaluation" / name).open("xb") as handle:
                        _stream_zip_member(archive, infos[f"evaluation/{name}"], handle)
        handoff = prepared_data["handoff"] if prepared else _a12_handoff_from_outers(context, outers)
        if nested:
            _require((root / "predictions.json").read_bytes() == canonical_json_bytes(handoff),
                     "F5_A12_AGGREGATE_PREDICTION_MISMATCH")
        if nested and not sharded:
            opened = _validate_a12_handoff(handoff)
            evaluation_handoff = {name: opened[name] for name in ("patient_ids", "centers", "horizons", "survival")}
            evaluation_handoff.update(_a12_evaluation_scope(opened))
            evaluation_handoff.update(_a12_evaluation_estimability(opened))
            primary_bytes = sum((root / "evaluation" / name).stat().st_size for name in
                ("primary-point-evaluation.json", "primary-point-native.zip"))
            coordinator_bytes = 32 * (len(canonical_json_bytes(evaluation_handoff))
                + 16 * 1000 * len(opened["patient_ids"]) + primary_bytes) + 128 * 1000 * ((2 * 4 - 1) * ((12 * len(REPORT_HORIZONS) + 2) + 7 * (10 * len(REPORT_HORIZONS) + 2)))
            retained_execution = strict_json_bytes((root / "evaluation/execution.json").read_bytes())
            _require(retained_execution == value["evaluation_execution"]
                     and retained_execution["resource_reservation"]["coordinator_memory_estimate_bytes"] == coordinator_bytes,
                     "F5_A12_BOOTSTRAP_EXECUTION_INVALID")
            observation = observe_execution_resources(root)
            replay_policy = {**resource_policy,
                "memory_bytes_per_worker": MIN_WORKER_MEMORY_BYTES,
                "memory_reserve_bytes": resource_policy["memory_reserve_bytes"] + coordinator_bytes}
            admission = resource_admission(replay_policy, observation, legal_tasks=1)
            (root / "execution.json").write_bytes(canonical_json_bytes({"resource_policy": replay_policy,
                "resource_observation": observation, "resource_admission": admission,
                "new_paired_metric_engine_invocations": 0, "new_random_draws": 0}))
        if sharded:
            _require((root / "evaluation/execution.json").read_bytes() == canonical_json_bytes(value["evaluation_execution"]),
                     "F5_A12_BOOTSTRAP_GATHER_EXECUTION_INVALID")
            numeric = _replay_a12_sharded_evaluation(root / "evaluation", handoff, context["evaluation_response_csv"],
                resource_policy=resource_policy, retained_primary_point=context["primary_point"],
                primary_point_native=context["primary_point_native"], prepared_input_record=prepared_input_record,
                prepared_points=prepared_data["points"] if prepared else None)
        else:
            numeric = _replay_a12_evaluation(root / "evaluation", handoff,
                context["evaluation_response_csv"] if nested else context["frozen"]["response_csv"],
                **({"retained_primary_point": context["primary_point"], "primary_point_native": context["primary_point_native"]}
                   if nested else {}))
        result = _a12_native_summary(context, numeric, records)
        _require(canonical_json_bytes(result) == raw, "F5_A12_NATIVE_SUMMARY_REPLAY_MISMATCH")
        if execution_report is not None and outer_input_reports:
            execution_report["outer_input_execution"] = outer_input_reports
    except BaseException as exc:
        exc.add_note(f"F5_A12_AGGREGATE_REPLAY_EVIDENCE_RETAINED:{root}")
        raise
    if not nested:
        shutil.rmtree(root)
    return result, value


def _prepare_a19_models(source: Path, root: Path, *, retain_evidence: bool = False) -> tuple[dict, list[dict], bytes]:
    """Materialize the existing split-local M20 archives, without MICE or search."""
    from .f5 import (
        _a19_model_seed, _compile_partition_design_recipe,
        _expected_family_parent_column_map, _validate_final_aggregate_lineage,
        compile_full_data_mice_plan, compile_full_data_search_mice_tasks,
        materialize_full_data_search_partition,
        predictor_contract,
    )
    entries = read_safe_zip(source)
    _require("a19-input.json" in entries, "F5_A19_NATIVE_MODEL_INPUT_REQUIRED")
    raw = entries["a19-input.json"]
    value = strict_json_bytes(raw, "F5_A19_MODEL_INPUT")
    _require(
        isinstance(value, dict)
        and set(value) == {"kind", "final_lineage", "mice_plan"}
        and value["kind"] == "PADML_F5_A19_MODEL_INPUT_V1"
        and canonical_json_bytes(value) == raw,
        "F5_A19_INPUT_SCHEMA_INVALID",
    )
    (root / "a19-input.json").write_bytes(raw)
    lineage, plan = value["final_lineage"], value["mice_plan"]
    final_tasks = _validate_final_aggregate_lineage(lineage)
    _require(plan.get("family") == lineage["final_family"], "F5_A19_MICE_FAMILY_MISMATCH")
    mice_tasks = compile_full_data_search_mice_tasks(plan)
    split_ids = sorted(row["split_id"] for row in plan["split_pairs"])
    expected_members = {"a19-input.json", "response.csv"} | {
        f"{task['split_id']}/{task['role'].lower()}.zip" for task in mice_tasks
    }
    _require(set(entries) == expected_members, "F5_A19_MICE_ARCHIVE_SET_INVALID")
    response = entries["response.csv"]
    (root / "response.csv").write_bytes(response)
    responses = _response_rows(response)[1]
    final_response = lineage["final_mice"]["fit_response"]
    _require(
        sha256_bytes(response) == final_response["sha256"]
        and list(responses) == plan["source_ids"] == lineage["final_mice"]["fit_ids"]
        and len(lineage["centers"]) == len(responses),
        "F5_A19_DEVELOPMENT_COHORT_MISMATCH",
    )
    key_by_id = dict(zip(plan["source_ids"], plan["patient_keys"], strict=True))
    center_by_id = dict(zip(plan["source_ids"], map(str, lineage["centers"]), strict=True))
    population = load_science_authority()["science"]["population"]
    _require(
        set(center_by_id.values()) == {
            str(center) for role in ("validation_centers", "training_only_centers")
            for center in population[role]
        }
        and sha256_bytes(canonical_json_bytes([
            {"patient_key": key_by_id[patient], "center": int(center_by_id[patient])}
            for patient in plan["source_ids"]
        ])) == plan["resampling_center_sha256"],
        "F5_A19_RESAMPLING_CENTER_MISMATCH",
    )
    replayed_plan = compile_full_data_mice_plan(
        plan["source_ids"], plan["patient_keys"],
        [int(center_by_id[patient]) for patient in plan["source_ids"]],
        [int(responses[patient]["All_Cause_Death"]) for patient in plan["source_ids"]],
        family=lineage["final_family"],
        rscript=RSCRIPT_EXECUTABLE,
        workers=plan["execution_profile"]["pool_workers"],
    )
    if retain_evidence:
        (root / "replayed-plan.json").write_bytes(canonical_json_bytes(replayed_plan))
    _require(replayed_plan == plan, "F5_A19_SPLIT_PLAN_REPLAY_MISMATCH")
    family = lineage["final_family"]
    selected = lineage["final_seta"]["lock"]["selected_parents"]
    predictors = predictor_contract(Path(__file__).parent)
    tasks = []
    for split_id in split_ids:
        split_root = root / split_id
        split_root.mkdir(mode=0o700)
        for role in ("analysis", "application"):
            (split_root / f"{role}.zip").write_bytes(entries[f"{split_id}/{role}.zip"])
        stop_payloads = {}
        if "stop_mice" in next(row for row in plan["split_pairs"] if row["split_id"] == split_id):
            stop_id = next(row["stopping"]["partition_id"] for row in plan["split_pairs"] if row["split_id"] == split_id)
            for role in ("analysis", "application"):
                path = split_root / f"stop-{role}.zip"
                path.write_bytes(entries[f"{stop_id}/{role}.zip"])
                stop_payloads[f"stop_{role}_payload"] = path
        partition = materialize_full_data_search_partition(
            plan, split_id, split_root / "analysis.zip", split_root / "application.zip",
            response, split_root / "partition", retain_evidence=retain_evidence, **stop_payloads,
        )
        recipe = _compile_partition_design_recipe(family, selected, partition, split_root,
            **({"native_evidence": split_root / "recipe-native"} if retain_evidence else {}))
        columns = _expected_family_parent_column_map(
            selected, family, predictors, recipe["transform_recipe"],
        )
        design_count = sum(len(row["columns"]) for row in columns)
        event_count = partition["fit_response"]["event_count"]
        _require(
            event_count / lineage["final_seta"]["lock"]["common_set_design_df"] >= 15
            and event_count / design_count >= 15,
            "F5_A19_TRAINING_EPV_INFEASIBLE",
        )
        fit_response = Path(partition["fit_response"]["path"]).read_bytes()
        fit_ids, evaluation_ids = partition["fit_ids"], partition["evaluation_ids"]
        for imputation in range(1, 6):
            covariates = (Path(partition["covariates"]["input_dir"]) / f"imp{imputation:02d}.csv").read_bytes()
            reader = csv.DictReader(io.StringIO(covariates.decode("utf-8-sig")))
            rows = list(reader)
            by_id = {row["Patient_ID"]: row for row in rows}
            _require(
                len(rows) == len(by_id) == len(plan["source_ids"])
                and set(by_id) == set(plan["source_ids"])
                and all(row["Center"] == center_by_id[patient] for patient, row in by_id.items())
                and not {"All_Cause_Death", "Death_Followup_months"}.intersection(reader.fieldnames or []),
                "F5_A19_COVARIATE_DOMAIN_INVALID",
            )
            def subset(ids: list[str]) -> bytes:
                stream = io.StringIO(newline="")
                writer = csv.DictWriter(stream, fieldnames=reader.fieldnames, lineterminator="\n")
                writer.writeheader()
                writer.writerows(by_id[patient] for patient in ids)
                return stream.getvalue().encode()
            for role in A19_SEED_ROLES:
                coordinates = {"virtual_outer": 0, "repeat": partition["repeat"],
                               "inner_fold": partition["inner_fold"], "seed_role": role}
                seed = _a19_model_seed(coordinates)
                stochastic = family in {"RSF", "GBM_COX", "XGBOOST_COX", "COXTIME_SET_A"}
                task = {
                    "family": family, "selected_parents": selected,
                    "parameters": final_tasks[imputation]["parameters"],
                    "imputation": imputation, "a19_coordinates": coordinates,
                    "model_seed": seed if stochastic else None,
                    "row_count": len(fit_ids), "family_design_column_count": design_count,
                    "family_decision_sha256": lineage["final_refit_plan"]["family_decision_sha256"],
                    "final_parameter_lock_sha256": lineage["final_parameter_lock"]["identity_sha256"],
                    "evaluation_patient_keys": [key_by_id[patient] for patient in evaluation_ids],
                }
                tasks.append({
                    "name": f"{split_id}_{role}_M{imputation:02d}",
                    "entries": {
                        "task.json": canonical_json_bytes(task),
                        "recipe.json": canonical_json_bytes(recipe),
                        "fit-covariates.csv": subset(fit_ids), "fit-response.csv": fit_response,
                        "prediction-covariates.csv": subset(evaluation_ids),
                    },
                })
    tasks.sort(key=lambda row: row["name"])
    _require(len(tasks) == 225, "F5_A19_TASK_COVERAGE_INVALID")
    context = {"lineage": lineage, "center_by_patient": {
        key_by_id[patient]: center_by_id[patient] for patient in plan["source_ids"]
    }}
    # Evaluation uses the plan's source-derived keys; fitting keeps sealed source IDs.
    stream = io.StringIO(newline="")
    writer = csv.DictWriter(stream, fieldnames=list(next(iter(responses.values()))), lineterminator="\n")
    writer.writeheader()
    writer.writerows({**row, "Patient_ID": key_by_id[patient]}
                     for patient, row in responses.items())
    return context, tasks, stream.getvalue().encode()


def _execute_a19_component(job: Mapping[str, Any]) -> dict[str, Any]:
    """One native fit, retained objects, and outcome-free held-out prediction."""
    from .f5 import _execute_final_refit_engine
    root = Path(job["root"])
    inputs = job["entries"]
    root.mkdir(mode=0o700)
    for member, raw in inputs.items():
        (root / member).write_bytes(raw)
    task = strict_json_bytes(inputs["task.json"])
    recipe = strict_json_bytes(inputs["recipe.json"])
    fit_rows = list(csv.DictReader(io.StringIO(inputs["fit-covariates.csv"].decode())))
    application = list(csv.DictReader(io.StringIO(inputs["prediction-covariates.csv"].decode())))
    response = _response_rows(inputs["fit-response.csv"])[1]
    fit_ids, evaluation_ids = [row["Patient_ID"] for row in fit_rows], [row["Patient_ID"] for row in application]
    _require(
        fit_ids == list(response) and len(fit_ids) == len(set(fit_ids))
        and len(evaluation_ids) == len(set(evaluation_ids)) > 0
        and set(fit_ids).isdisjoint(evaluation_ids)
        and len(evaluation_ids) == len(task["evaluation_patient_keys"]),
        "F5_A19_FIT_APPLICATION_ISOLATION_INVALID",
    )
    try:
        fitted = _execute_final_refit_engine(task["family"], task, fit_rows, response, recipe)
    except BaseException as exc:
        (root / "native-failure.json").write_bytes(canonical_json_bytes({
            "error": str(exc), "native_evidence": getattr(exc, "__notes__", []),
        }))
        raise
    # Persist the expensive native result before any later prediction can fail.
    for member in ("model", "baseline"):
        (root / f"{member}.bin").write_bytes(fitted[member])
    (root / "fit-health.json").write_bytes(canonical_json_bytes(fitted["fit_health"]))
    (root / "training-prediction.json").write_bytes(canonical_json_bytes(fitted["survival"]))
    _seal_prediction_matrix(fit_ids, fitted["survival"], HORIZONS)
    try:
        replay = _execute_final_refit_engine(
            task["family"], task, fit_rows, response, recipe,
            retained_objects=(fitted["model"], fitted["baseline"]), prediction_rows=application,
        )
    except BaseException as exc:
        (root / "native-failure.json").write_bytes(canonical_json_bytes({
            "error": str(exc), "native_evidence": getattr(exc, "__notes__", []),
        }))
        raise
    survival = replay["survival"]
    _seal_prediction_matrix(evaluation_ids, survival, HORIZONS)
    row = _a19_prediction_row(task, inputs, fitted["model"], fitted["baseline"], survival)
    (root / "prediction.json").write_bytes(canonical_json_bytes(row))
    target = root.with_suffix(".zip")
    write_deterministic_zip(target, {path.name: path for path in root.iterdir()})
    return row


def _a19_prediction_row(task: Mapping[str, Any], inputs: Mapping[str, bytes],
                        model: bytes, baseline: bytes, survival: list) -> dict[str, Any]:
    from .f5 import _a19_model_seed
    patients = [{"patient_key_hash": key, "survival_probabilities": row}
                for key, row in zip(task["evaluation_patient_keys"], survival, strict=True)]
    coordinates = task["a19_coordinates"]
    split_coordinates = {key: coordinates[key] for key in ("virtual_outer", "repeat", "inner_fold")}
    seed = _a19_model_seed(coordinates)
    split_seed = 100_000 + coordinates["repeat"] * 100
    keys = sorted(task["evaluation_patient_keys"])
    row = {
        "inner_repeat_id": coordinates["repeat"], "inner_fold_id": coordinates["inner_fold"],
        "seed_role": coordinates["seed_role"], "imp_id": task["imputation"],
        "final_family": task["family"], "model_seed": seed, "split_seed": split_seed,
        "time_grid_months": HORIZONS, "patients": patients,
        "patient_set_sha256": sha256_bytes(canonical_json_bytes(keys)),
        "prediction_sha256": sha256_bytes(canonical_json_bytes(patients)),
        "final_family_decision_sha256": task["family_decision_sha256"],
        "final_parameter_lock_sha256": task["final_parameter_lock_sha256"],
        "fit_receipt_sha256": sha256_bytes(canonical_json_bytes({
            "task": task, "input": {key: sha256_bytes(raw) for key, raw in inputs.items()},
            "model": sha256_bytes(model), "baseline": sha256_bytes(baseline),
        })),
        "split_identity_sha256": sha256_bytes(canonical_json_bytes({
            "coordinates": split_coordinates, "split_seed": split_seed, "evaluation_patient_keys": keys,
        })),
        "seed_identity_sha256": sha256_bytes(canonical_json_bytes({
            "rng_kind": "L'Ecuyer-CMRG", "coordinates": split_coordinates,
            "seed_role": coordinates["seed_role"], "model_seed": seed,
        })),
    }
    return row


def _replay_a19_component(job: Mapping[str, Any]) -> dict[str, Any]:
    from .f5 import _execute_final_refit_engine, _validate_retained_model_objects
    expected = job["entries"]
    entries = read_safe_zip(Path(job["archive"]), expected_members=set(expected) | {
        "model.bin", "baseline.bin", "fit-health.json", "training-prediction.json", "prediction.json",
    })
    _require(all(entries[name] == data for name, data in expected.items()),
             "F5_A19_NATIVE_INPUT_REPLAY_MISMATCH")
    task, recipe = strict_json_bytes(entries["task.json"]), strict_json_bytes(entries["recipe.json"])
    training = list(csv.DictReader(io.StringIO(entries["fit-covariates.csv"].decode())))
    application = list(csv.DictReader(io.StringIO(entries["prediction-covariates.csv"].decode())))
    response = _response_rows(entries["fit-response.csv"])[1]
    objects = (entries["model.bin"], entries["baseline.bin"])
    evidence = Path(job["replay_evidence"]) if job.get("replay_evidence") is not None else None
    if evidence is not None:
        evidence.mkdir(mode=0o700)
    audit = _validate_retained_model_objects(task["family"], *objects,
        strict_json_bytes(entries["fit-health.json"]), task,
        **({"native_evidence": evidence / "object-audit"} if evidence is not None else {}))
    if evidence is not None:
        (evidence / "audit.json").write_bytes(canonical_json_bytes(audit))
    for rows, member in ((None, "training-prediction.json"), (application, "prediction.json")):
        observed = _execute_final_refit_engine(
            task["family"], task, training, response, recipe,
            retained_objects=objects, prediction_rows=rows,
            **({"replay_evidence": evidence / member.removesuffix(".json")} if evidence is not None else {}),
        )["survival"]
        prediction = (observed if rows is None else
                      _a19_prediction_row(task, expected, *objects, observed))
        if evidence is not None:
            (evidence / member).write_bytes(canonical_json_bytes(prediction))
        _require(canonical_json_bytes(prediction) == entries[member],
                 "F5_A19_NATIVE_PREDICTION_REPLAY_MISMATCH")
    return prediction


def replay_a19_bundle(source: Path, final_lineage: Mapping[str, Any], *,
                      replay_evidence: Path | None = None) -> tuple[dict, dict]:
    """Rebuild the 225 inputs and replay native objects; never append a fit."""
    entries = read_safe_zip(source)
    _require({"a19.json", "input.zip"}.issubset(entries), "F5_A19_NATIVE_EXECUTION_ARCHIVE_REQUIRED")
    root = replay_evidence or Path(tempfile.mkdtemp(prefix="padml-f5-a19-replay-")).resolve()
    if replay_evidence is not None:
        _require(root.is_absolute() and root.parent.is_dir() and not root.exists() and not root.is_symlink(),
                 "F5_A19_REPLAY_EVIDENCE_TARGET_INVALID")
        root.mkdir(mode=0o700)
    try:
        input_path = root / "input.zip"
        input_path.write_bytes(entries["input.zip"])
        context, tasks, response = _prepare_a19_models(input_path, root, retain_evidence=replay_evidence is not None)
        _require(context["lineage"] == final_lineage, "F5_A19_FINAL_LINEAGE_MISMATCH")
        expected = {"a19.json", "input.zip"} | {f"fits/{task['name']}.zip" for task in tasks}
        _require(set(entries) == expected, "F5_A19_NATIVE_FIT_COVERAGE_INVALID")
        jobs = []
        for task in tasks:
            archive = root / f"{task['name']}.zip"
            archive.write_bytes(entries[f"fits/{task['name']}.zip"])
            jobs.append({**task, "archive": str(archive),
                **({"replay_evidence": str(root / (task["name"] + "-replay"))} if replay_evidence is not None else {})})
        rows = _bounded_ordered_spawn(_replay_a19_component, jobs)
        result = compute_a19_multi_seed_stability(rows, context["center_by_patient"], response)
        result.update({
            "status": "COMPUTED_NATIVE_MODELS", "model_fit_count": 225,
            "source_archive_sha256": sha256_file(input_path),
            "execution_evidence_status": "NATIVE_MODELS_PENDING_REPLAY",
            "unverified_authority_sources": ["A19_NATIVE_OBJECT_REPLAY"],
        })
        if replay_evidence is not None:
            (root / "replayed-rows.json").write_bytes(canonical_json_bytes(rows))
            (root / "replayed-result.json").write_bytes(canonical_json_bytes(result))
        _require(canonical_json_bytes(result) == entries["a19.json"],
                 "F5_A19_NATIVE_SUMMARY_REPLAY_MISMATCH")
    except BaseException as exc:
        exc.add_note(f"F5_A19_NATIVE_REPLAY_EVIDENCE:{root}")
        raise
    if replay_evidence is None:
        shutil.rmtree(root)
    return ({**result, "status": "COMPLETED_ZERO_FEEDBACK",
             "execution_evidence_status": "NATIVE_OBJECTS_AND_INPUTS_REPLAYED",
             "unverified_authority_sources": [], "blocking_for_production": False}, result)


def execute_a19_bundle(
    source: Path, target: Path, *, workers: int | None = None,
) -> dict[str, Any]:
    """Fit M5 × 15 × 3 from native inputs; no search, STOP selection or feedback."""
    _require(source.is_absolute() and source.is_file() and not source.is_symlink()
             and target.is_absolute() and target.parent.is_dir() and not target.exists(),
             "F5_A19_PATH_INVALID")
    capacity = resolve_pool_workers(workers)
    root = Path(tempfile.mkdtemp(prefix="padml-f5-a19-", dir=target.parent)).resolve()
    try:
        context, tasks, response = _prepare_a19_models(source, root)
        jobs = [{**task, "root": str(root / task["name"])} for task in tasks]
        rows = _bounded_ordered_spawn(_execute_a19_component, jobs, selected_slots=capacity)
        result = compute_a19_multi_seed_stability(rows, context["center_by_patient"], response)
        # Scientific acceptance still requires the native object/input replay below.
        result.update({
            "status": "COMPUTED_NATIVE_MODELS", "model_fit_count": 225,
            "source_archive_sha256": sha256_file(source),
            "execution_evidence_status": "NATIVE_MODELS_PENDING_REPLAY",
            "unverified_authority_sources": ["A19_NATIVE_OBJECT_REPLAY"],
        })
        write_deterministic_zip(target, {
            "a19.json": canonical_json_bytes(result), "input.zip": source,
            **{f"fits/{task['name']}.zip": root / f"{task['name']}.zip" for task in tasks},
        })
        shutil.rmtree(root)
        return {"status": result["status"], "stage_acceptance": False,
                "model_fit_count": 225, "pool_workers": capacity,
                "sha256": sha256_file(target), "size_bytes": target.stat().st_size}
    except BaseException as exc:
        exc.add_note(f"F5_A19_NATIVE_EVIDENCE_RETAINED:{root}")
        raise


def execute_a04_bundle(source: Path, target: Path, *, sources: list[Path],
                       f2_run_root: Path, input_root: Path, result_root: Path,
                       variant_sources: list[Path] | None = None,
                       negative_sources: list[Path] | None = None,
                       f1_runtime_root: Path | None = None) -> dict[str, Any]:
    """Reopen all six native application shards, not declared risk scalars."""
    from .f5_application import aggregate_application_audit
    raw = source.read_bytes()
    lineage = strict_json_bytes(raw)
    _require(canonical_json_bytes(lineage) == raw, "F5_A04_LINEAGE_NONCANONICAL")
    return aggregate_application_audit(sources, target, lineage, f2_run_root=f2_run_root,
        input_root=input_root, result_root=result_root, variant_sources=variant_sources, negative_sources=negative_sources,
        f1_runtime_root=f1_runtime_root)


def main() -> None:
    raise ContractError("USE_PYTHON_M_PADML_WORKER_F45_RUN_JSON_UNIT_ID")
