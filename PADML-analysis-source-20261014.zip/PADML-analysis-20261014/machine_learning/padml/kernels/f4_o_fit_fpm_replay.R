#!/usr/bin/env Rscript

# Open the actual accepted F2 object. This entry has no fitting action.
suppressPackageStartupMessages({library(jsonlite); library(digest); library(survival); library(rstpm2)})
fail <- function(code) stop(code, call. = FALSE)
need <- function(value, code) if (!isTRUE(value)) fail(code)
scalar <- function(value) unname(unlist(value, use.names = FALSE)[[1L]])
args <- commandArgs(trailingOnly = TRUE)
need(length(args) == 1L, "F4_O_FIT_REPLAY_ARGUMENT_INVALID")
request <- fromJSON(args[[1L]], simplifyVector = FALSE)
output_path <- scalar(request$output_path)
options(error = function() {
  dump.frames(dumpto = file.path(dirname(output_path), "native-failure"),
              to.file = TRUE, include.GlobalEnv = TRUE)
  quit(save = "no", status = 1L, runLast = FALSE)
})
spec <- fromJSON(scalar(request$original_spec_path), simplifyVector = FALSE)
task <- fromJSON(scalar(request$original_task_path), simplifyVector = FALSE)
original <- fromJSON(scalar(request$original_output_path), simplifyVector = FALSE)$tasks[[1L]]
script <- grep("^--file=", commandArgs(), value = TRUE)
need(length(script) == 1L, "F4_O_FIT_REPLAY_KERNEL_INVALID")
kernel <- file.path(dirname(gsub("~+~", " ", sub("^--file=", "", script), fixed = TRUE)), "f2_model_development.R")
expressions <- as.list(parse(kernel))
required <- c("canonical_json", "sha_object", "categorical_contract", "locked_levels",
              "prepare_frame", "read_response", "validate_compiled_conflicts", "apply_design_recipe",
              "ordered_parent_column_map", "fpm_constraint_identity", "fpm_evaluate_checks",
              "fpm_require_checks", "validate_fpm_fit_health")
definitions <- Filter(function(x) is.call(x) && identical(x[[1L]], as.name("<-")) &&
  is.symbol(x[[2L]]) && as.character(x[[2L]]) %in% required && is.call(x[[3L]]) &&
  identical(x[[3L]][[1L]], as.name("function")), expressions)
need(length(definitions) == length(required) &&
       setequal(vapply(definitions, function(x) as.character(x[[2L]]), character(1)), required),
     "F4_O_FIT_REPLAY_KERNEL_INVALID")
for (definition in definitions) eval(definition)
projections <- Filter(function(x) is.call(x) && identical(x[[1L]], as.name("<-")) &&
                       identical(x[[2L]], as.name("variable_rows")), expressions)
need(length(projections) == 2L, "F4_O_FIT_REPLAY_KERNEL_INVALID")
for (projection in projections) eval(projection)
parents <- vapply(Filter(function(row) row$set_a_eligible, variable_rows), `[[`, character(1), "name")
time_col <- scalar(spec$time); event_col <- scalar(spec$outcome)
selected <- as.character(unlist(task$selected_parents, use.names = FALSE))
part <- spec$registered_partitions$partitions[[1L]]
fit_ids <- as.character(unlist(part$fit_ids, use.names = FALSE))
evaluation_ids <- as.character(unlist(part$evaluation_ids, use.names = FALSE))
data <- prepare_frame(read.csv(scalar(request$covariate_path), check.names = FALSE, stringsAsFactors = FALSE))
need(identical(as.character(data$Patient_ID), as.character(unlist(part$application_ids, use.names = FALSE))),
     "F4_O_FIT_REPLAY_PATIENT_DRIFT")
response_record <- part$fit_response; response_record$path <- request$response_path
response <- read_response(response_record)
need(identical(as.character(response$Patient_ID), fit_ids), "F4_O_FIT_REPLAY_RESPONSE_DRIFT")
train <- data[match(fit_ids, data$Patient_ID), , drop = FALSE]
test <- data[match(evaluation_ids, data$Patient_ID), , drop = FALSE]
train_mapping <- apply_design_recipe(train, selected, task$transform_recipe, "FPM_TVC_SET_A")
test_mapping <- apply_design_recipe(test, selected, task$transform_recipe, "FPM_TVC_SET_A")
train_design <- train_mapping$x; test_design <- test_mapping$x
need(identical(colnames(train_design), colnames(test_design)) &&
       identical(ordered_parent_column_map(train_mapping$parent_map, selected),
                 ordered_parent_column_map(test_mapping$parent_map, selected)),
     "F4_O_FIT_REPLAY_DESIGN_DRIFT")
fit <- readRDS(scalar(request$model_path))
need(inherits(fit, "stpm2") &&
       all(c(".time", ".event", colnames(train_design)) %in% names(fit@data)) &&
       identical(as.numeric(fit@data$.time), response[[time_col]]) &&
       identical(as.integer(fit@data$.event), response[[event_col]]) &&
       all(vapply(colnames(train_design), function(name)
         identical(as.numeric(fit@data[[name]]), as.numeric(train_design[, name])), logical(1))),
     "F4_O_FIT_NATIVE_TRAINING_DATA_DRIFT")
health <- validate_fpm_fit_health(fit, 0L, spec$fpm$set_a_df)
# The accepted fixed archives used this exact historical transport. Verify the
# actual archived producer expression, never invent a numeric replay tolerance.
old_expressions <- as.list(parse(scalar(request$original_kernel_path)))
old_batch <- Filter(function(x) is.call(x) && identical(x[[1L]], as.name("<-")) &&
                      identical(x[[2L]], as.name("run_registered_prediction_batch")), old_expressions)
need(length(old_batch) == 1L &&
       identical(tail(as.list(old_batch[[1L]][[3L]][[3L]]), 1L)[[1L]],
                 quote(writeLines(canonical_json(result), output_path, useBytes = TRUE))),
     "F4_O_FIT_ORIGINAL_TRANSPORT_UNSUPPORTED")
predict_original <- function(design) {
  need("AST_ALT" %in% colnames(design) && all(is.finite(design)) &&
         all(design[, "AST_ALT"] > 0 & design[, "AST_ALT"] <= 15),
       "F2_FPM_FIXED_COMPUTATIONAL_DOMAIN_INVALID")
  # Same native expansion as the original F2 fit_predict FPM branch.
  test_frame <- data.frame(design, check.names = FALSE)
  expanded <- test_frame[rep(seq_len(nrow(test_frame)), times = 36L), , drop = FALSE]
  rownames(expanded) <- NULL
  expanded$.time <- rep(1:36, each = nrow(test_frame))
  values <- withCallingHandlers(as.numeric(predict(fit, newdata = expanded, type = "surv")),
                               warning = function(condition) stop(condition))
  value <- t(matrix(values, nrow = 36L, byrow = TRUE))
  need(identical(dim(value), c(nrow(design), 36L)) && all(is.finite(value)) &&
         all(value >= 0 & value <= 1) &&
         all(apply(value, 1L, function(row) all(diff(row) <= 1e-10))),
       "F4_O_FIT_NATIVE_PREDICTION_INVALID")
  value
}
rows <- function(value) lapply(seq_len(nrow(value)), function(i) as.list(as.numeric(value[i, ])))
rng <- get0(".Random.seed", envir = .GlobalEnv, inherits = FALSE)
heldout <- predict_original(test_design)
need(identical(fromJSON(canonical_json(rows(heldout)), simplifyVector = FALSE), original$survival),
     "F4_O_FIT_ORIGINAL_PREDICTION_REPLAY_MISMATCH")
apparent <- predict_original(train_design)
need(identical(rng, get0(".Random.seed", envir = .GlobalEnv, inherits = FALSE)),
     "F4_O_FIT_REPLAY_UNEXPECTED_RNG_CONSUMPTION")
result <- list(outer_fold = scalar(spec$fold), imputation = scalar(task$imputation),
  model_seed = scalar(task$seed), fit_count = 0L, rng_consumed = FALSE,
  original_prediction_replayed = TRUE,
  stopping = c(list(engine = "rstpm2::stpm2", df = 3L, tvc_df = 1L), health),
  apparent_survival = rows(cbind(1, apparent)), heldout_survival = rows(cbind(1, heldout)))
writeLines(canonical_json(result, digits = I(17)), output_path, useBytes = TRUE)
