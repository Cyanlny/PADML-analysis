suppressPackageStartupMessages(library(jsonlite))

request <- fromJSON(file("stdin"), simplifyVector = TRUE)
stopifnot(
  identical(names(request), c(
    "center_order", "centers", "patient_ids", "replicate_count", "root_seed"
  )),
  length(request$patient_ids) == length(request$centers),
  length(unique(request$patient_ids)) == length(request$patient_ids),
  is.character(request$patient_ids),
  all(grepl("^[0-9a-f]{64}$", request$patient_ids)),
  identical(sort(unique(request$centers)), sort(request$center_order)),
  request$replicate_count >= 1L,
  request$replicate_count <= 1000L
)

source <- unlist(lapply(request$center_order, function(center) {
  index <- which(request$centers == center)
  index[order(request$patient_ids[index], method = "radix")]
}), use.names = FALSE)
stopifnot(length(source) == length(request$patient_ids))

set.seed(
  as.integer(request$root_seed),
  kind = "L'Ecuyer-CMRG", normal.kind = "Inversion", sample.kind = "Rejection"
)
draws <- lapply(seq_len(request$replicate_count), function(replicate) {
  sampled <- unlist(lapply(request$center_order, function(center) {
    index <- source[request$centers[source] == center]
    sample(index, length(index), replace = TRUE)
  }), use.names = FALSE)
  as.list(as.integer(sampled - 1L))
})

cat(toJSON(list(
  draws = draws,
  r_version = paste(R.version$major, R.version$minor, sep = "."),
  rng = c("L'Ecuyer-CMRG", "Inversion", "Rejection")
), auto_unbox = TRUE, digits = NA, null = "null"))
