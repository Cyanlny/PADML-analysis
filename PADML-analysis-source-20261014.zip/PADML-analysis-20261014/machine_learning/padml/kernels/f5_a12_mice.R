#!/usr/bin/env Rscript

# A12 total uses the original F1 view/spec and chain coordinates. Import the
# retaining F5 bridge, stopping before its sole scientific entry point.
script <- grep("^--file=", commandArgs(), value = TRUE)
stopifnot(length(script) == 1L)
bridge <- parse(file.path(dirname(gsub("~+~", " ", sub("^--file=", "", script), fixed = TRUE)), "f5_mice.R"))
entry <- which(vapply(as.list(bridge), function(x) {
  identical(x, quote(impute_view(spec, authority)))
}, logical(1)))
stopifnot(length(entry) == 1L, entry[[1L]] == length(bridge) - 1L)
for (expression in as.list(bridge)[seq_len(entry[[1L]] - 1L)]) eval(expression)

# Remove the information channel before casting, predictor construction or MICE.
# Keep the frozen patients, the remaining fields and the active imputation targets.
excluded <- c("AST", "ALT", "AST_ALT")
columns <- chars(authority$science$mice$private_handoff$columns)
input_columns <- if (is.null(nested_aar_source)) columns else setdiff(columns, excluded)
raw <- read.csv(as.character(spec$covariates_path), colClasses = "character",
                check.names = FALSE, na.strings = character(), quote = "\"",
                fileEncoding = "UTF-8")
if (!identical(names(raw), input_columns) ||
    any(vapply(authority$science$mice$target_rules, function(x) {
      as.character(x$target) %in% excluded
    }, logical(1)))) fail("F5_A12_TOTAL_MICE_INPUT_INVALID")
columns <- setdiff(columns, excluded)
projected <- file.path(root, "covariates-total.csv")
if (file.exists(projected)) {
  previous <- read.csv(projected, colClasses = "character", check.names = FALSE,
                       na.strings = character(), fileEncoding = "UTF-8")
  if (!identical(previous, raw[columns])) fail("F5_A12_TOTAL_MICE_INPUT_DRIFT")
} else {
  write.table(raw[columns], projected, sep = ",", row.names = FALSE,
              col.names = TRUE, quote = TRUE, na = "", fileEncoding = "UTF-8",
              qmethod = "double")
}
spec$covariates_path <- projected
authority$science$mice$private_handoff$columns <- as.list(columns)

# These two primary-policy expressions otherwise reintroduce the ratio.
# Replace only their exact syntax; a changed upstream contract must fail closed.
removed <- c(0L, 0L)
without_channel <- function(expression) {
  targets <- list(quote(candidates <- unique(c(candidates, "AST_ALT"))),
                  quote(output$AST_ALT <- completed$AST / completed$ALT))
  for (index in seq_along(targets)) {
    if (identical(expression, targets[[index]])) {
      removed[[index]] <<- removed[[index]] + 1L
      return(quote(invisible(NULL)))
    }
  }
  if (is.call(expression)) {
    for (index in seq_along(expression)) {
      # Preserve missing subscripts and literal NULL: [[i]] <- NULL deletes i.
      if (!is.null(expression[[index]]) &&
          !identical(expression[[index]], quote(expr = ))) {
        expression[[index]] <- without_channel(expression[[index]])
      }
    }
  }
  expression
}
body(impute_view) <- without_channel(body(impute_view))
if (!identical(removed, c(1L, 1L))) fail("F5_A12_TOTAL_MICE_SOURCE_INVALID")
impute_view(spec, authority)
writeLines(capture.output(sessionInfo()), file.path(root, "native-session.txt"))
