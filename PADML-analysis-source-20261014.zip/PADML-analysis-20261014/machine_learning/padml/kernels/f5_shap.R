#!/usr/bin/env Rscript

padml_shap_tensors <- function(result, exact, root, need) {
  # Native handoff uses the same row-major float64 layout as the formal carrier.
  # Stream one patient at a time; never build a second nested contribution list.
  n <- nrow(result$predictions); p <- ncol(result$S[[1L]])
  fields <- c("risk_contributions", "standard_errors", "predicted_risk")
  descriptors <- setNames(vector("list", length(fields)), fields)
  for (field in fields) {
    member <- paste0(gsub("_", "-", field, fixed=TRUE), ".f64")
    path <- file.path(root, member); temporary <- paste0(path, ".part")
    con <- file(temporary, "wb")
    tryCatch(for (i in seq_len(n)) {
      values <- if (field == "predicted_risk") 1 - result$predictions[i, ] else
        unlist(lapply(seq_len(4L), function(j) {
          if (field == "risk_contributions") -result$S[[j]][i, ] else
            if (exact) rep(0, p) else result$SE[[j]][i, ]
        }), use.names=FALSE)
      writeBin(as.double(values), con, size=8L, endian="little")
    }, finally=close(con))
    shape <- if (field == "predicted_risk") c(n, 4L) else c(n, 4L, p)
    need(file.info(temporary)$size == prod(shape) * 8, "F5_SHAP_TENSOR_INVALID")
    pin <- digest::digest(temporary, algo="sha256", file=TRUE, serialize=FALSE)
    if (file.exists(path)) {
      need(identical(digest::digest(path, algo="sha256", file=TRUE, serialize=FALSE), pin),
           "F5_SHAP_TENSOR_DRIFT")
      unlink(temporary)
    } else need(file.rename(temporary, path), "F5_SHAP_TENSOR_SAVE_FAILED")
    descriptors[[field]] <- list(member=member, shape=as.list(shape), dtype="<f8",
      sha256=pin, size_bytes=prod(shape)*8)
  }
  descriptors
}

padml_shap_diagnostic <- function(result, family, imputation, model_sha256, selected,
  patient_ids, seed, exact, max_iter, need, diagnostic_root = NULL) {
  horizons <- c(6L, 12L, 24L, 36L)
  output_names <- paste0("t", horizons)
  p <- length(selected)
  diagnostic <- list(
    kind = "PADML_F5_KERNELSHAP_RETURN_V1", status = "INVALID",
    family = family, imputation = as.integer(imputation), model_sha256 = model_sha256,
    patient_ids = as.list(patient_ids), selected_parents = as.list(selected),
    horizons = as.list(horizons), seed = as.integer(seed), max_iter = max_iter,
    tol = 0.005, exact = exact, converged = as.list(result$converged),
    n_iter = as.list(result$n_iter), S = result$S, SE = result$SE,
    baseline = as.list(result$baseline), predictions = result$predictions
  )
  save_diagnostic <- function() {
    if (!is.null(diagnostic_root)) {
      target <- file.path(diagnostic_root, "kernelshap-diagnostic.json")
      stored <- diagnostic
      # Patient checkpoints already retain failed native values. Valid numerical
      # arrays are shared with the final component, not embedded a second time.
      stored[c("S", "SE", "predictions")] <- NULL
      writeLines(jsonlite::toJSON(stored, auto_unbox = TRUE, null = "null", na = "null", digits = I(17)),
                 paste0(target, ".tmp"), useBytes = TRUE)
      need(file.rename(paste0(target, ".tmp"), target), "F5_SHAP_DIAGNOSTIC_SAVE_FAILED")
    }
  }
  save_diagnostic()
  need(
    inherits(result, "kernelshap") &&
      identical(result$algorithm, "kernelshap") &&
      identical(names(result$S), output_names) &&
      length(result$baseline) == length(horizons) &&
      identical(dim(result$predictions), c(length(patient_ids), length(horizons))),
    "F5_SHAP_KERNEL_RESULT_INVALID"
  )
  need(all(is.finite(result$baseline)) && all(is.finite(result$predictions)) &&
    all(result$predictions >= 0 & result$predictions <= 1) &&
    all(vapply(result$S, function(x) identical(dim(x), c(length(patient_ids), p)) &&
      all(is.finite(x)), logical(1))), "F5_SHAP_KERNEL_RESULT_INVALID")
  need(all(vapply(seq_along(output_names), function(j) {
    max(abs(rowSums(result$S[[j]]) + result$baseline[[j]] - result$predictions[, j])) <= 1e-6
  }, logical(1))), "F5_SHAP_LOCAL_ACCURACY_INVALID")
  if (!exact) {
    need(is.logical(result$converged) && length(result$converged) == length(patient_ids) &&
      !anyNA(result$converged) && is.integer(result$n_iter) &&
      length(result$n_iter) == length(patient_ids) && !anyNA(result$n_iter) &&
      all(result$n_iter >= 2L & result$n_iter <= max_iter) &&
      identical(names(result$SE), output_names) &&
      all(vapply(result$SE, function(x) identical(dim(x), c(length(patient_ids), p)) &&
        all(is.finite(x)) && all(x >= 0), logical(1))), "F5_SHAP_KERNEL_RESULT_INVALID")
    ranges <- do.call(cbind, lapply(result$S, function(x) apply(x, 1L, function(row) max(row) - min(row))))
    max_se <- do.call(cbind, lapply(result$SE, function(x) apply(x, 1L, max)))
    criterion <- max_se <= 0.005 * ranges
    need(identical(as.logical(result$converged), apply(criterion, 1L, all)) &&
      all(result$converged | result$n_iter == max_iter), "F5_SHAP_CONVERGENCE_RESULT_INVALID")
    diagnostic$shap_range <- ranges
    diagnostic$maximum_se <- max_se
    diagnostic$criterion <- criterion
  }
  diagnostic$status <- if (exact || all(result$converged)) "CONVERGED" else "BUDGET_EXHAUSTED"
  if (!is.null(diagnostic_root))
    diagnostic$tensors <- padml_shap_tensors(result, exact, diagnostic_root, need)
  save_diagnostic()
  diagnostic

}

padml_shap_sigma_failure_screen <- function(p,K) {
  n <- 0L
  mean_lo <- mean_hi <- lower <- upper <- maxabs <- matrix(0,p,K)
  safe <- .Machine$double.base==2L && .Machine$double.digits==53L &&
    .Machine$double.rounding %in% c(2L,5L)
  eps <- .Machine$double.eps
  # Deliberately wider than one binary64 rounding step, including cancellation.
  down <- function(value,scale) value-8*eps*pmax(scale,.Machine$double.xmin)
  up <- function(value,scale) value+8*eps*pmax(scale,.Machine$double.xmin)
  push <- function(value) {
    n <<- n+1L
    if(!safe) return(invisible(NULL))
    if(!is.matrix(value) || !identical(dim(value),c(as.integer(p),as.integer(K))) ||
       any(!is.finite(value)) || any(abs(value)>1e140) ||
       any(abs(value)>0 & abs(value)<1e-140)) {
      safe <<- FALSE
      return(invisible(NULL))
    }
    maxabs <<- pmax(maxabs,abs(value))
    if(n==1L) {
      mean_lo <<- value; mean_hi <<- value
      return(invisible(NULL))
    }
    dlo <- down(value-mean_hi,abs(value)+abs(mean_hi))
    dhi <- up(value-mean_lo,abs(value)+abs(mean_lo))
    qlo <- down(dlo/n,abs(dlo)/n); qhi <- up(dhi/n,abs(dhi)/n)
    mlo <- down(mean_lo+qlo,abs(mean_lo)+abs(qlo))
    mhi <- up(mean_hi+qhi,abs(mean_hi)+abs(qhi))
    elo <- down(value-mhi,abs(value)+abs(mhi))
    ehi <- up(value-mlo,abs(value)+abs(mlo))
    aa <- dlo*elo; ab <- dlo*ehi; ba <- dhi*elo; bb <- dhi*ehi
    scale <- pmax(abs(aa),abs(ab),abs(ba),abs(bb))
    prod_lo <- down(pmin(aa,ab,ba,bb),scale)
    prod_hi <- up(pmax(aa,ab,ba,bb),scale)
    next_lower <- down(lower+prod_lo,abs(lower)+abs(prod_lo))
    next_upper <- up(upper+prod_hi,abs(upper)+abs(prod_hi))
    if(any(!is.finite(c(mlo,mhi,next_lower,next_upper)))) {
      safe <<- FALSE
      return(invisible(NULL))
    }
    mean_lo <<- mlo; mean_hi <<- mhi
    lower <<- next_lower; upper <<- next_upper
    invisible(NULL)
  }
  definitely_fails <- function(beta,tol) {
    if(!safe || n<2L || any(!is.finite(beta)) || !is.finite(tol) || tol<0) return(FALSE)
    # The interval Welford recurrence encloses the exact SSE of the computed
    # per-iteration estimates. Widen again for the native stats::var two-pass
    # summation/centering/division and kernelshap's (n-1)/n/n arithmetic.
    # gamma covers far more elementary operations than the locked var path;
    # 128*n*M^2 is a conservative cancellation allowance. Do not tune it down
    # for speed. Overflow or an interval spanning the boundary falls back.
    operation_count <- 16*n+128
    if(operation_count*eps>=.01) return(FALSE)
    gamma <- operation_count*eps/(1-operation_count*eps)
    allowance <- 128*gamma*n*maxabs^2
    if(any(!is.finite(allowance))) return(FALSE)
    sse_lower <- pmax(0,lower-allowance)
    sigma_lower <- sqrt(sse_lower)/n
    sigma_lower <- pmax(0,down(sigma_lower,abs(sigma_lower)))
    beta_range <- apply(beta,2L,function(z)diff(range(z)))
    cutoff <- tol*beta_range
    if(any(!is.finite(cutoff))) return(FALSE)
    cutoff <- up(cutoff,abs(cutoff))
    any(sigma_lower > matrix(rep(cutoff,each=p),p,K))
  }
  list(push=push,definitely_fails=definitely_fails)
}

# Apply after existing deterministic get_vz/coalition rewrites, to the local
# copied kernelshap_one only. Its prior private environment remains the parent.
padml_patch_shap_sigma_screen <- function(one,need=function(ok,code)
    if(!isTRUE(ok)) stop(code,call.=FALSE)) {
  ns <- asNamespace("kernelshap")
  need(identical(as.character(utils::packageVersion("kernelshap")),"0.9.1"),
    "F5_SHAP_SIGMA_KERNEL_UNSUPPORTED")
  environment_new <- new.env(parent=environment(one))
  environment_new$padml_sigma_factory <- padml_shap_sigma_failure_screen
  environment_new$padml_original_sigma <- get("get_sigma",ns)
  edits <- c(init=0L,push=0L,sigma=0L)
  walk <- function(expr) {
    if(is.call(expr) && identical(expr[[1L]],as.name("<-")) &&
      identical(expr[[2L]],as.name("est_m"))) {
      edits[["init"]] <<- edits[["init"]]+1L
      return(as.call(list(as.name("{"),expr,
        quote(.padml_sigma <- padml_sigma_factory(p,K)))))
    }
    if(is.call(expr) && identical(expr[[1L]],as.name("<-")) &&
      is.call(expr[[2L]]) && identical(expr[[2L]][[1L]],as.name("[")) &&
      identical(expr[[2L]][[2L]],as.name("est_m"))) {
      edits[["push"]] <<- edits[["push"]]+1L
      # Keep the original solver call and exact matrix assignment.
      assignment <- expr
      assignment[[3L]] <- as.name(".padml_estimate")
      return(as.call(list(as.name("{"),
        as.call(list(as.name("<-"),as.name(".padml_estimate"),expr[[3L]])),
        assignment,quote(.padml_sigma$push(.padml_estimate)))))
    }
    if(is.call(expr) && identical(expr[[1L]],as.name("get_sigma"))) {
      edits[["sigma"]] <<- edits[["sigma"]]+1L
      reference_call <- expr; reference_call[[1L]] <- as.name("padml_original_sigma")
      return(substitute({
        # Boundary, budget endpoints and first SE check retain native sigma.
        if(n_iter!=2L && n_iter!=500L && n_iter<max_iter &&
           .padml_sigma$definitely_fails(beta_n,tol)) {
          # Never published: original convergence check deterministically fails.
          matrix(Inf,p,K,dimnames=list(feature_names,K_names))
        } else ORIGINAL
      },list(ORIGINAL=reference_call)))
    }
    if(is.call(expr)) for(i in seq_along(expr))
      if(!is.null(expr[[i]]) && !identical(expr[[i]],quote(expr=))) expr[[i]] <- walk(expr[[i]])
    expr
  }
  body(one) <- walk(body(one))
  need(identical(unname(edits),c(1L,1L,1L)),"F5_SHAP_SIGMA_KERNEL_REWRITE_INVALID")
  environment(one) <- environment_new
  one
}

# Retain sampling and native convergence; deterministic preparation and the
# shared-matrix solve are local to this immutable model/MI runner.
padml_kernelshap_runner <- function(background, pred_fun, selected, exact, degree, need,
                                   background_predictions = NULL) {
  ns <- asNamespace("kernelshap")
  p <- length(selected); bg_n <- nrow(background); m <- 2L * p
  one <- get("kernelshap_one", ns)
  original_vz <- get("get_vz", ns)
  sampling <- get("input_sampling", ns)
  reorganize <- get("reorganize_list", ns)
  if (is.null(background_predictions)) background_predictions <- pred_fun(NULL, background)
  v0 <- get("wcolMeans", ns)(get("align_pred", ns)(background_predictions), NULL)
  precalc <- if (p == 1L) list() else if (exact) get("input_exact", ns)(p, feature_names=selected) else
    if (degree >= 1L) get("input_partly_exact", ns)(p=p, deg=degree, feature_names=selected) else list()
  e <- new.env(parent=ns)
  e$solver <- function(A,b,constraint) {
    solved <- solve(A,cbind(matrix(1,nrow=nrow(A)),b))
    Ainv1 <- solved[,1L,drop=FALSE]; Ainvb <- solved[,-1L,drop=FALSE]
    colnames(Ainv1) <- NULL
    num <- rbind(colSums(Ainvb))-constraint
    Ainvb-Ainv1 %*% num/sum(Ainv1)
  }
  state <- new.env(parent=emptyenv())
  e$input_sampling <- function(...) {
    value <- sampling(...)
    state$draws <- state$draws + 1L
    if (state$draws == 500L) state$original_rng <- .Random.seed
    value
  }
  e$padml_vz <- function(x, Z, object, pred_fun, w, bg_n, ...) {
    keys <- apply(Z, 1L, function(z) paste0(as.integer(z), collapse=""))
    missing <- which(!vapply(keys, exists, logical(1), envir=state$cache, inherits=FALSE))
    missing <- missing[!duplicated(keys[missing])]
    # Whole coalitions preserve rowsum's exact background order. At most one
    # full background plus a bounded number of additional coalitions is live.
    width <- max(1L, 2000L %/% bg_n)
    for (lo in seq.int(1L, max(1L, length(missing)), by=width)) {
      if (!length(missing)) break
      indices <- missing[lo:min(length(missing), lo+width-1L)]
      group <- rep(seq_along(indices), each=bg_n)
      block <- background[rep.int(seq_len(bg_n), length(indices)), , drop=FALSE]
      values <- original_vz(x=x, bg_rep=block, Z_rep=Z[indices[group], , drop=FALSE],
        object=object, pred_fun=pred_fun, w=w, bg_n=bg_n, ...)
      for (j in seq_along(indices)) assign(keys[indices[j]], values[j, , drop=FALSE], envir=state$cache)
    }
    value <- do.call(rbind, lapply(keys, get, envir=state$cache, inherits=FALSE))
    # Cache only this patient's deterministic four-output coalition values.
    # Evict after assembling this request so duplicates retain their weights.
    if (length(ls(state$cache, all.names=TRUE)) > 4096L)
      rm(list=ls(state$cache, all.names=TRUE), envir=state$cache)
    value
  }
  edits <- c(vz=0L, grouping=0L)
  walk <- function(x) {
    if (is.call(x) && identical(x[[1L]], as.name("get_vz"))) {
      edits[["vz"]] <<- edits[["vz"]] + 1L
      return(quote(padml_vz(x=x, Z=Z, object=object, pred_fun=pred_fun, w=bg_w, bg_n=bg_n, ...)))
    }
    if (identical(x, quote(g <- rep_each(m, each=bg_n)))) {
      edits[["grouping"]] <<- edits[["grouping"]] + 1L
      return(quote(invisible(NULL)))
    }
    if (is.call(x)) for (i in seq_along(x))
      if (!is.null(x[[i]]) && !identical(x[[i]], quote(expr=))) x[[i]] <- walk(x[[i]])
    x
  }
  body(one) <- walk(body(one)); environment(one) <- e
  need(identical(unname(edits), c(2L, 1L)), "F5_SHAP_KERNEL_IMPLEMENTATION_UNSUPPORTED")
  # Retained 500-budget patients were produced by the locked native solver.
  # Replay that implementation exactly; numerical agreement of the new solve
  # is not a substitute for the original checkpoint's bitwise replay guard.
  original_one <- one
  original_environment <- new.env(parent=e)
  original_environment$solver <- get("solver", ns)
  environment(original_one) <- original_environment
  one <- padml_patch_shap_sigma_screen(one, need)
  function(value, rng_seed=NULL, original_budget=FALSE, original_max_iter=500L,
           endpoint_prediction=NULL) {
    if (!is.null(rng_seed)) set.seed(as.integer(rng_seed))
    state$draws <- 0L; state$original_rng <- NULL
    state$cache <- new.env(hash=TRUE, parent=emptyenv())
    # Only the current MI runner's already-computed full prediction may be lent.
    # A missing endpoint always performs the independent native prediction.
    v1 <- get("align_pred", ns)(if (is.null(endpoint_prediction))
      pred_fun(NULL, value) else endpoint_prediction)
    need(identical(dim(v1), c(nrow(value), length(v0))) &&
      all(is.finite(v1)) && all(v1 >= 0 & v1 <= 1), "F5_SHAP_ENDPOINT_INVALID")
    if (p == 1L) {
      ans <- get("case_p1", ns)(n=1L, feature_names=selected, v0=v0, v1=v1, X=value, verbose=FALSE)
    } else {
      selected_one <- if (original_budget) original_one else one
      native <- selected_one(x=value, v1=v1, object=NULL, pred_fun=pred_fun, feature_names=selected,
        bg_w=NULL, exact=exact, deg=degree, m=m, tol=0.005,
        max_iter=if (original_budget) original_max_iter else 2000L,
        v0=v0, precalc=precalc, bg_n=bg_n)
      ans <- list(S=reorganize(list(native$beta)), baseline=as.vector(v0), predictions=v1,
        algorithm="kernelshap")
      if (!exact) {
        ans$SE <- reorganize(list(native$sigma)); ans$n_iter <- native$n_iter
        ans$converged <- native$converged
      }
      class(ans) <- "kernelshap"
    }
    attr(ans, "padml_rng_after_original") <- if (is.null(state$original_rng)) .Random.seed else state$original_rng
    rm(list=ls(state$cache, all.names=TRUE), envir=state$cache)
    ans
  }
}

padml_shap_replay <- function(run, row, expected, state, exact, need,
                             original_budget=FALSE, original_max_iter=500L) {
  previous <- .Random.seed
  on.exit(assign(".Random.seed", previous, envir=.GlobalEnv),add=TRUE)
  assign(".Random.seed", state, envir=.GlobalEnv)
  sentinel <- if (original_budget) run(row, original_budget=TRUE,
    original_max_iter=original_max_iter) else run(row)
  sentinel_equal <- all(vapply(names(expected$S), function(name) {
    identical(
      as.numeric(sentinel$S[[name]][1L, ]),
      as.numeric(expected$S[[name]][1L, ])
    )
  }, logical(1))) &&
    identical(as.numeric(sentinel$baseline), as.numeric(expected$baseline)) &&
    identical(
      as.numeric(sentinel$predictions[1L, ]),
      as.numeric(expected$predictions[1L, ])
    )
  if (!exact) {
    sentinel_equal <- sentinel_equal && all(vapply(names(expected$S), function(name) {
      identical(as.numeric(sentinel$SE[[name]][1L, ]), as.numeric(expected$SE[[name]][1L, ]))
    }, logical(1))) &&
      isTRUE(sentinel$converged[[1L]]) &&
      identical(sentinel$n_iter[[1L]], expected$n_iter[[1L]])
  }
  need(sentinel_equal, "F5_SHAP_FIXED_SEED_REPLAY_DRIFT")
  TRUE
}

padml_shap_patients <- function(run, data, ids, selected, seed, exact, degree, need,
  root, spec, recovery, pilot, family, imputation, model_sha256, expected) {
  suppressPackageStartupMessages(library(digest))
  n <- length(ids)
  need(is.null(pilot) || pilot <= n, "F5_SHAP_PILOT_PATIENT_INVALID")
  scalar <- function(x) unname(unlist(x, use.names = FALSE)[[1L]])
  pin <- function(x) digest(x, algo = "sha256")
  spec_sha <- digest(spec, algo = "sha256", serialize = FALSE)
  legacy <- NULL
  legacy_sha <- NULL
  patient_pins <- list()
  read_legacy <- function(source) {
    old_spec <- as.character(scalar(source$spec_path))
    raw_path <- as.character(scalar(source$raw_path))
    legacy_sha <<- as.character(scalar(source$raw_sha256))
    need(identical(digest(old_spec, algo="sha256", file=TRUE, serialize=FALSE),
      as.character(scalar(source$spec_sha256))) &&
      identical(digest(raw_path, algo="sha256", file=TRUE, serialize=FALSE), legacy_sha),
      "F5_SHAP_RAW_BINDING_INVALID")
    retained <- readRDS(raw_path)
    need(identical(retained$spec, readBin(old_spec, "raw", n=file.info(old_spec)$size)),
      "F5_SHAP_RAW_BINDING_INVALID")
    legacy <<- retained$result
    padml_shap_diagnostic(legacy, family, imputation, model_sha256, selected,
      ids, seed, exact, 500L, need)
    need(max(abs(legacy$predictions - expected)) <= 1e-12, "F5_SHAP_PREDICTION_BINDING_INVALID")
  }
  if (!is.null(recovery)) {
    source <- recovery
    seen <- character()
    current_kernel <- NULL
    binding_path <- if (is.null(root)) NULL else file.path(root, "binding.json")
    if (!is.null(binding_path) && file.exists(binding_path))
      current_kernel <- jsonlite::fromJSON(binding_path, simplifyVector=FALSE)$source_member_sha256[["padml/kernels/f5_shap.R"]]
    inherited_solver <- FALSE
    while (!is.null(source)) {
      old_spec <- as.character(scalar(source$spec_path))
      source_spec <- as.character(scalar(source$spec_sha256))
      need(length(seen) < 28L && !source_spec %in% seen &&
        identical(digest(old_spec, algo="sha256", file=TRUE, serialize=FALSE), source_spec),
        "F5_SHAP_RAW_BINDING_INVALID")
      seen <- c(seen, source_spec)
      if (!identical(source$kind, "PATIENT_CHECKPOINTS")) {
        legacy_sha <- as.character(scalar(source$raw_sha256))
        if (length(patient_pins) < n) read_legacy(source)
        break
      }
      inherited_solver <- inherited_solver || isTRUE(source$original_solver)
      replay_original <- if (is.null(current_kernel)) inherited_solver else
        !source$source_member_sha256[["padml/kernels/f5_shap.R"]] %in% c(current_kernel,
          "5164d47ba5a663734086ab034e51f41a5c3f3939a8467e01875d601a9f1e64dc")
      for (entry in source$patients) {
        index <- as.integer(scalar(entry$patient_index))
        need(index >= 1L && index <= n && is.null(patient_pins[[as.character(index)]]),
          "F5_SHAP_PATIENT_BINDING_INVALID")
        entry$spec_sha256 <- source_spec
        entry$original_solver <- replay_original
        patient_pins[[as.character(index)]] <- entry
      }
      source <- source$upstream
    }
  }
  if (!is.null(pilot))
    need(!is.null(legacy) && !exact && !legacy$converged[[pilot]],
         "F5_SHAP_PILOT_REQUIRES_FAILED_ORIGINAL_PATIENT")
  part <- function(value, i) {
    ans <- list(S=lapply(value$S, function(x) x[i,,drop=FALSE]), baseline=value$baseline,
      predictions=value$predictions[i,,drop=FALSE], algorithm="kernelshap",
      SE=if (exact) NULL else lapply(value$SE, function(x) x[i,,drop=FALSE]),
      n_iter=if (exact) NULL else value$n_iter[i],
      converged=if (exact) NULL else value$converged[i])
    class(ans) <- "kernelshap"
    ans
  }
  sample_step <- getFromNamespace("input_sampling", "kernelshap")
  advance <- function(state, count) {
    assign(".Random.seed", state, envir=.GlobalEnv)
    if (!exact) for (j in seq_len(count))
      sample_step(p=length(selected), m=2L*length(selected), deg=degree, feature_names=selected)
    .Random.seed
  }
  directory <- if (is.null(root)) NULL else file.path(root, "patients")
  if (!is.null(directory)) dir.create(directory, showWarnings=FALSE)
  set.seed(as.integer(seed))
  shadow <- .Random.seed
  metadata <- vector("list", n)
  result <- NULL
  first_verified <- FALSE
  for (i in seq_len(n)) {
    before <- shadow
    # A pilot reaches one original anchor by sampling alone; no other patient is explained.
    if (!is.null(pilot) && i != pilot) {
      need(!is.null(legacy), "F5_SHAP_PILOT_REQUIRES_ORIGINAL_RETURN")
      shadow <- advance(before, if (exact) 0L else legacy$n_iter[[i]])
      next
    }
    path <- if (is.null(directory)) NULL else file.path(directory, sprintf("P%05d.rds", i))
    donor_pin <- patient_pins[[as.character(i)]]
    external <- !is.null(donor_pin)
    if (external) {
      path <- as.character(scalar(donor_pin$path))
      need(file.exists(path) && identical(digest(path, algo="sha256", file=TRUE, serialize=FALSE),
        as.character(scalar(donor_pin$sha256))) && file.info(path)$size == as.numeric(scalar(donor_pin$size_bytes)),
        "F5_SHAP_PATIENT_BINDING_INVALID")
    }
    if (!is.null(path) && file.exists(path)) {
      record <- readRDS(path)
      need(identical(record$spec_sha256, if (external) donor_pin$spec_sha256 else spec_sha) && identical(record$patient_index, i) &&
        identical(record$patient_id, ids[[i]]) && identical(record$rng_before, before) &&
        identical(record$rng_kind, RNGkind()) && identical(record$r_version, as.character(getRversion())),
        "F5_SHAP_PATIENT_BINDING_INVALID")
    } else {
      use_old <- !is.null(legacy) && (exact || isTRUE(legacy$converged[[i]]))
      assign(".Random.seed", before, envir=.GlobalEnv)
      value <- if (use_old) part(legacy, i) else if (i == 1L) run(data[i,,drop=FALSE]) else
        run(data[i,,drop=FALSE], endpoint_prediction=expected[i,,drop=FALSE])
      count <- if (exact) 0L else if (!is.null(legacy)) legacy$n_iter[[i]] else min(value$n_iter[[1L]], 500L)
      original_rng <- if (use_old) advance(before, count) else attr(value, "padml_rng_after_original")
      need(is.integer(original_rng) && length(original_rng) == length(before), "F5_SHAP_ORIGINAL_RNG_MISSING")
      attr(value, "padml_rng_after_original") <- NULL
      # Background bytes are already bound by spec; retain every numerical guard field.
      value[c("X", "bg_X", "bg_w")] <- NULL
      record <- list(spec_sha256=spec_sha, patient_index=i, patient_id=ids[[i]],
        rng_before=before, rng_after_original=original_rng, original_stream_n_iter=count,
        rng_after_original_sha256=pin(original_rng),
        rng_kind=RNGkind(), r_version=as.character(getRversion()),
        producer=list(max_iter=if (use_old) 500L else 2000L,
          source_sha256=if (use_old) legacy_sha else spec_sha), result=value)
      # Preserve a returned patient before guards, just as the original whole-MI raw return.
      if (!is.null(path)) {
        saveRDS(record, paste0(path, ".tmp"))
        need(file.rename(paste0(path, ".tmp"), path), "F5_SHAP_PATIENT_SAVE_FAILED")
      }
    }
    cap <- record$producer$max_iter
    need(cap %in% c(500L, 2000L) && identical(record$producer$source_sha256,
         if (cap == 500L) legacy_sha else if (external) donor_pin$spec_sha256 else spec_sha),
         "F5_SHAP_PATIENT_BINDING_INVALID")
    value <- record$result
    diagnostic <- padml_shap_diagnostic(value, family, imputation, model_sha256,
      selected, ids[i], seed, exact, cap, need)
    need(max(abs(value$predictions - expected[i,,drop=FALSE])) <= 1e-12 &&
      (cap != 500L || diagnostic$status == "CONVERGED"), "F5_SHAP_PREDICTION_BINDING_INVALID")
    if (i == 1L && (exact || isTRUE(value$converged[[1L]]))) {
      if (!isTRUE(record$first_patient_replay_exact)) {
        record$first_patient_replay_exact <- padml_shap_replay(run,data[i,,drop=FALSE],
          value,before,exact,need,original_budget=cap == 500L ||
            (external && isTRUE(donor_pin$original_solver)), original_max_iter=cap)
        if (!is.null(path) && !external) {
          saveRDS(record,paste0(path,".tmp"))
          need(file.rename(paste0(path,".tmp"),path),"F5_SHAP_PATIENT_SAVE_FAILED")
        }
      }
      first_verified <- TRUE
    }
    count <- if (exact) 0L else if (!is.null(legacy)) legacy$n_iter[[i]] else min(value$n_iter[[1L]], 500L)
    need(identical(record$original_stream_n_iter, count) && is.integer(record$rng_after_original) &&
      length(record$rng_after_original) == length(before), "F5_SHAP_ORIGINAL_RNG_INVALID")
    if (exact) {
      need(identical(record$rng_after_original, before), "F5_SHAP_ORIGINAL_RNG_INVALID")
    } else if (!is.null(record$rng_after_original_sha256)) {
      need(identical(record$rng_after_original_sha256, pin(record$rng_after_original)),
        "F5_SHAP_ORIGINAL_RNG_INVALID")
    } else {
      # Legacy partial records lack the write-time RNG checksum. The next
      # retained patient's before-state anchors interior records; only an
      # unqualified segment boundary needs the original sampling-state check.
      next_retained <- i < n && (!is.null(patient_pins[[as.character(i + 1L)]]) ||
        (!is.null(directory) && file.exists(file.path(directory, sprintf("P%05d.rds", i + 1L)))))
      if (!next_retained || !is.null(pilot))
        need(identical(record$rng_after_original, advance(before, count)), "F5_SHAP_ORIGINAL_RNG_INVALID")
    }
    shadow <- record$rng_after_original
    metadata[[i]] <- list(patient_id=ids[[i]], patient_index=i, producer=record$producer,
      n_iter=if (exact) 0L else value$n_iter[[1L]], original_stream_n_iter=count,
      rng_before_sha256=pin(before), rng_after_original_sha256=pin(shadow))
    if (!is.null(pilot)) {
      diagnostic$patient_execution <- metadata[[i]]
      return(diagnostic)
    }
    if (is.null(result)) {
      result <- value
      result$S <- lapply(value$S, function(x) matrix(NA_real_, nrow=n, ncol=length(selected),
        dimnames=list(NULL, colnames(x))))
      result$predictions <- matrix(NA_real_, nrow=n, ncol=4L, dimnames=list(NULL, colnames(value$predictions)))
      if (!exact) {
        result$SE <- lapply(result$S, function(x) x)
        result$n_iter <- integer(n); result$converged <- logical(n)
      }
    }
    need(identical(value$baseline, result$baseline), "F5_SHAP_BASELINE_DRIFT")
    for (name in names(result$S)) result$S[[name]][i, ] <- value$S[[name]][1L, ]
    result$predictions[i, ] <- value$predictions[1L, ]
    if (!exact) {
      for (name in names(result$SE)) result$SE[[name]][i, ] <- value$SE[[name]][1L, ]
      result$n_iter[[i]] <- value$n_iter[[1L]]; result$converged[[i]] <- value$converged[[1L]]
    }
  }
  assign(".Random.seed", shadow, envir=.GlobalEnv)
  list(result=result, patient_execution=list(rng_policy="ORIGINAL_500_PATIENT_START",
    first_patient_replay_exact=first_verified,
    spec_sha256=spec_sha, recovery_source=recovery,
    original_stream_max_iter=500L, rng_kind=as.list(RNGkind()), r_version=as.character(getRversion()),
    rows=metadata))
}

padml_kernelshap_component <- function(
  family, imputation, model_sha256, selected, patient_ids, parent_data,
  predict_survival, seed, need, diagnostic_root = NULL, spec_binding = NULL,
  recovery_source = NULL, pilot_patient = NULL
) {
  suppressPackageStartupMessages(library(kernelshap))
  need(
    identical(as.character(packageVersion("kernelshap")), "0.9.1"),
    "F5_SHAP_KERNELSHAP_VERSION_INVALID"
  )
  horizons <- c(6L, 12L, 24L, 36L)
  output_names <- paste0("t", horizons)
  p <- length(selected)
  exact <- p <= 8L
  hybrid_degree <- if (p >= 9L && p <= 16L) 2L else if (p > 16L) 1L else 0L
  m <- 2L * p
  need(
    is.data.frame(parent_data) && nrow(parent_data) == length(patient_ids) &&
      nrow(parent_data) > 1L && ncol(parent_data) == p && p > 0L &&
      identical(colnames(parent_data), selected) && !anyDuplicated(patient_ids) &&
      is.numeric(seed) && length(seed) == 1L && is.finite(seed),
    "F5_SHAP_INPUT_INVALID"
  )

  need(identical(RNGkind(), c("Mersenne-Twister", "Inversion", "Rejection")),
       "F5_SHAP_RNG_KIND_DRIFT")
  set.seed(as.integer(seed))
  prediction_function <- function(object, newdata) {
    rng_before <- .Random.seed
    value <- as.matrix(predict_survival(newdata))
    need(
      identical(dim(value), c(nrow(newdata), length(horizons))) &&
        all(is.finite(value)) && all(value >= 0 & value <= 1),
      "F5_SHAP_SURVIVAL_PREDICTION_INVALID"
    )
    need(identical(rng_before, .Random.seed), "F5_SHAP_PREDICTION_CONSUMED_RNG")
    colnames(value) <- output_names
    value
  }
  full_predictions <- prediction_function(NULL, parent_data)
  run <- padml_kernelshap_runner(parent_data, prediction_function, selected, exact, hybrid_degree,
                               need, background_predictions = full_predictions)
  raw_path <- if (is.null(diagnostic_root)) NULL else file.path(diagnostic_root, "kernelshap-return.rds")
  if (is.null(pilot_patient) && !is.null(raw_path) && file.exists(raw_path)) {
    retained <- readRDS(raw_path)
    need(identical(retained$spec, spec_binding), "F5_SHAP_RAW_BINDING_INVALID")
    result <- retained$result
    patient_execution <- retained$patient_execution
  } else {
    rows <- padml_shap_patients(run, parent_data, patient_ids, selected, seed, exact,
      hybrid_degree, need, diagnostic_root, spec_binding, recovery_source, pilot_patient,
      family, imputation, model_sha256, full_predictions)
    if (!is.null(pilot_patient)) return(rows)
    result <- rows$result
    patient_execution <- rows$patient_execution
    # The per-patient checkpoints are the recovery source. Do not duplicate them
    # in a whole-MI RDS; legacy whole-MI returns above remain readable.
  }
  diagnostic <- padml_shap_diagnostic(result, family, imputation, model_sha256,
    selected, patient_ids, seed, exact, 2000L, need, diagnostic_root)
  need(diagnostic$status == "CONVERGED", "F5_SHAP_BUDGET_EXHAUSTED")

  if (!isTRUE(patient_execution$first_patient_replay_exact)) {
    # Compatibility for the legacy whole-MI carrier, which predates per-patient qualification.
    previous <- .Random.seed
    set.seed(as.integer(seed)); initial <- .Random.seed
    assign(".Random.seed",previous,envir=.GlobalEnv)
    padml_shap_replay(run,parent_data[1L,,drop=FALSE],result,initial,exact,need)
    patient_execution$first_patient_replay_exact <- TRUE
  }

  base_risk <- 1 - as.numeric(result$baseline)
  predicted_risk <- 1 - as.matrix(result$predictions)
  additivity_error <- matrix(0, nrow(parent_data), length(horizons))
  for (patient in seq_len(nrow(parent_data))) {
    for (column in seq_along(horizons)) {
      additivity_error[patient, column] <- abs(
        base_risk[[column]] +
          sum(-result$S[[column]][patient, ]) -
          predicted_risk[patient, column]
      )
    }
  }
  maximum_error <- max(additivity_error)
  need(
    all(is.finite(base_risk)) && all(is.finite(predicted_risk)) &&
      all(vapply(result$S, function(x) all(is.finite(x)), logical(1))) &&
      is.finite(maximum_error) && maximum_error <= 1e-6,
    "F5_SHAP_LOCAL_ACCURACY_INVALID"
  )
  within_imputation_global <- lapply(seq_along(horizons), function(column) {
    as.list(vapply(seq_along(selected), function(parent) {
      mean(abs(result$S[[column]][, parent]))
    }, numeric(1)))
  })
  component <- list(
    schema_version = "2.0.0",
    kind = "PADML_F5_FINAL_SHAP_COMPONENT_V2",
    status = "PASS",
    label = "FINAL_FULL_DATA_APPARENT_SHAP",
    family = family,
    imputation = as.integer(imputation),
    model_sha256 = model_sha256,
    patient_ids = as.list(patient_ids),
    horizons = as.list(horizons),
    primary_horizon_months = 24L,
    selected_parent_groups = as.list(selected),
    ast_alt_information_channels = as.integer(sum(selected == "AST_ALT")),
    raw_ast_or_alt_channels = as.integer(sum(selected %in% c("AST", "ALT"))),
    background = list(
      source = "FULL_CORRESPONDING_IMPUTATION_TRAINING_PATIENTS",
      patient_count = nrow(parent_data),
      patient_ids = as.list(patient_ids),
      weighting = "EQUAL_PATIENT_WEIGHT",
      bg_w = NULL,
      bg_n = NULL,
      subsampling = FALSE,
      validation_row_count = 0L,
      outcome_column_count = 0L
    ),
    estimand = list(
      survival = "S_T_X",
      risk = "ONE_MINUS_S_T_X",
      risk_contribution = "NEGATIVE_SURVIVAL_CONTRIBUTION",
      base_risk = "ONE_MINUS_BASE_SURVIVAL"
    ),
    engine = list(
      package = "kernelshap",
      version = "0.9.1",
      algorithm = "kernelshap",
      exact = exact,
      hybrid_degree = if (exact) NULL else hybrid_degree,
      m = if (exact) NULL else m,
      tol = 0.005,
      max_iter = 2000L,
      parallel = FALSE,
      seed = as.integer(seed)
    ),
    patient_execution = patient_execution,
    convergence = list(
      required = TRUE,
      all_rows_converged = TRUE,
      maximum_iterations_used = if (exact) 0L else max(result$n_iter),
      fixed_seed_first_patient_replay_exact = TRUE
    ),
    base_risk = as.list(base_risk),
    within_imputation_global_mean_absolute_contribution =
      within_imputation_global,
    local_accuracy = list(
      tolerance = 1e-6,
      maximum_absolute_error = maximum_error,
      status = "PASS"
    ),
    selection_effect = "NONE"
  )
  if (!is.null(diagnostic_root)) return(list(kind="PADML_SHAP_FLOAT64_COMPONENT_V1",
    component=component, tensors=diagnostic$tensors))
  # In-memory callers need no transport or new on-disk entity.
  component$predicted_risk <- lapply(seq_len(nrow(parent_data)), function(i) as.list(predicted_risk[i, ]))
  component$risk_contributions <- lapply(seq_len(nrow(parent_data)), function(i)
    lapply(result$S, function(x) as.list(-x[i, ])))
  component$standard_errors <- lapply(seq_len(nrow(parent_data)), function(i)
    lapply(seq_len(4L), function(j) as.list(if (exact) rep(0, p) else result$SE[[j]][i, ])))
  component
}

padml_shap_main <- function() {
  suppressPackageStartupMessages(library(jsonlite))
  fail <- function(code) stop(code, call. = FALSE)
  need <- function(value, code) if (!isTRUE(value)) fail(code)
  scalar <- function(value) unname(unlist(value, use.names = FALSE)[[1L]])
  args <- commandArgs(trailingOnly = TRUE)
  need(length(args) %in% c(1L, 2L), "F5_SHAP_ARGUMENT_INVALID")
  pilot_patient <- if (length(args) == 2L) as.integer(args[[2L]]) else NULL
  need(is.null(pilot_patient) || length(pilot_patient) == 1L && !is.na(pilot_patient) && pilot_patient > 0L,
       "F5_SHAP_PILOT_PATIENT_INVALID")
  spec_path <- args[[1L]]
  spec <- fromJSON(spec_path, simplifyVector = FALSE)
  fields <- c(
    "action", "family", "imputation", "model_sha256", "selected_parents",
    "seed", "model_path", "baseline_path", "covariate_path",
    "response_path", "recipe", "task", "horizons", "output_path",
    "python_executable", "shap_contract", "recovery_source"
  )
  need(
    identical(sort(names(spec)), sort(fields)) &&
      identical(as.character(scalar(spec$action)), "FINAL_SHAP") &&
      identical(
        as.integer(unlist(spec$horizons, use.names = FALSE)),
        c(6L, 12L, 24L, 36L)
      ),
    "F5_SHAP_SPEC_INVALID"
  )
  need(identical(as.integer(scalar(spec$shap_contract$max_iter)), 2000L) &&
       identical(as.integer(scalar(spec$shap_contract$original_stream_max_iter)), 500L) &&
       identical(as.character(scalar(spec$shap_contract$rng_policy)), "ORIGINAL_500_PATIENT_START") &&
       identical(as.numeric(scalar(spec$shap_contract$tol)), 0.005), "F5_SHAP_SPEC_INVALID")
  family <- as.character(scalar(spec$family))
  selected <- as.character(unlist(spec$selected_parents, use.names = FALSE))
  patient_data <- read.csv(
    as.character(scalar(spec$covariate_path)),
    check.names = FALSE,
    stringsAsFactors = FALSE,
    colClasses = "character"
  )
  response <- read.csv(
    as.character(scalar(spec$response_path)),
    check.names = FALSE,
    stringsAsFactors = FALSE,
    colClasses = "character"
  )
  patient_ids <- as.character(patient_data$Patient_ID)
  need(
    identical(
      names(response),
      c("Patient_ID", "All_Cause_Death", "Death_Followup_months")
    ) &&
      identical(patient_ids, as.character(response$Patient_ID)) &&
      nrow(patient_data) > 1L && !anyDuplicated(patient_ids) &&
      all(c("Patient_ID", "Center", selected) %in% names(patient_data)) &&
      !any(c("All_Cause_Death", "Death_Followup_months") %in%
             names(patient_data)),
    "F5_SHAP_DATA_INVALID"
  )
  script <- grep("^--file=", commandArgs(), value = TRUE)
  need(length(script) == 1L, "F5_SHAP_KERNEL_PATH_INVALID")
  source(
    file.path(dirname(gsub("~+~", " ", sub("^--file=", "", script), fixed = TRUE)), "f5_design.R"),
    local = TRUE
  )
  recipe <- spec$recipe
  prepared <- padml_prepare_final_r_design(
    patient_data,
    selected,
    recipe$predictor_rows,
    recipe$transform_recipe,
    family,
    scalar,
    need
  )
  parent_data <- prepared$covariates[, selected, drop = FALSE]
  report_horizons <- c(6, 12, 24, 36)

  if (family %in% c(
    "COX_PH", "ELASTIC_NET_COX", "RSF", "GBM_COX", "FPM_TVC_SET_A"
  )) {
    suppressPackageStartupMessages(library(survival))
    if (family == "ELASTIC_NET_COX") {
      suppressPackageStartupMessages(library(glmnet))
    }
    if (family == "RSF") suppressPackageStartupMessages(library(ranger))
    if (family == "GBM_COX") suppressPackageStartupMessages(library(gbm))
    if (family == "FPM_TVC_SET_A") {
      suppressPackageStartupMessages(library(rstpm2))
    }
    suppressPackageStartupMessages(library(digest))
    model_path <- as.character(scalar(spec$model_path))
    need(
      identical(
        digest(model_path, algo = "sha256", serialize = FALSE, file = TRUE),
        as.character(scalar(spec$model_sha256))
      ),
      "F5_SHAP_MODEL_HASH_INVALID"
    )
    model <- readRDS(model_path)
    baseline <- readRDS(as.character(scalar(spec$baseline_path)))
    fit <- model$fit
    build_design <- function(newdata) {
      padml_masked_r_design(prepared, newdata, selected, need)
    }
    cumulative <- if (family == "COX_PH")
      c(0, baseline$baseline$hazard)[findInterval(report_horizons, baseline$baseline$time)+1L] else
      if (family %in% c("ELASTIC_NET_COX", "GBM_COX"))
        c(0, baseline$baseline$cumulative)[findInterval(report_horizons, baseline$baseline$times)+1L] else NULL
    prepared_survival <- if(family=="RSF") padml_prepare_rsf_survival(fit,report_horizons,need) else
      if(family=="FPM_TVC_SET_A") padml_prepare_fpm_fixed_basis(fit,colnames(prepared$design),report_horizons,need=need) else NULL
    predict_chunk <- function(newdata) {
      design <- build_design(newdata)
      if (family == "COX_PH") {
        colnames(design) <- model$engine_columns
        return(padml_coxph_survival(fit, design, report_horizons, need, baseline$baseline))
      }
      if (family == "ELASTIC_NET_COX") {
        engine_design <- design
        if (!is.null(model$inert_column)) {
          engine_design <- cbind(engine_design, PADML_GLMNET_INERT_ZERO = 0)
        }
        risk <- exp(as.numeric(predict(
          fit, engine_design, s = model$lambda, type = "link"
        )))
        return(exp(-outer(risk, cumulative)))
      }
      if (family == "GBM_COX") {
        risk <- exp(as.numeric(predict(
          fit, design, n.trees = fit$n.trees, type = "link"
        )))
        return(exp(-outer(risk, cumulative)))
      }
      if (family == "RSF") {
        return(prepared_survival(design))
      }
      prepared_survival(design)
    }
    predict_survival <- function(newdata) {
      width <- 2000L
      groups <- split(
        seq_len(nrow(newdata)),
        ceiling(seq_len(nrow(newdata)) / width)
      )
      do.call(rbind, lapply(groups, function(index) {
        predict_chunk(newdata[index, , drop = FALSE])
      }))
    }
  } else {
    need(
      family %in% c("XGBOOST_COX", "COXTIME_SET_A"),
      "F5_SHAP_FAMILY_INVALID"
    )
    suppressPackageStartupMessages(library(reticulate))
    use_python(
      as.character(scalar(spec$python_executable)), required = TRUE
    )
    module <- import("padml.f5", convert = FALSE)
    predictor <- module$`_FinalShapPythonPredictor`(spec_path)
    predict_survival <- function(newdata) {
      py_to_r(predictor$predict_survival(r_to_py(newdata)))
    }
  }
  value <- padml_kernelshap_component(
    family = family,
    imputation = as.integer(scalar(spec$imputation)),
    model_sha256 = as.character(scalar(spec$model_sha256)),
    selected = selected,
    patient_ids = patient_ids,
    parent_data = parent_data,
    predict_survival = predict_survival,
    seed = as.integer(scalar(spec$seed)),
    need = need,
    diagnostic_root = dirname(spec_path),
    spec_binding = readBin(spec_path, "raw", n = file.info(spec_path)$size),
    recovery_source = spec$recovery_source,
    pilot_patient = pilot_patient
  )
  writeLines(
    toJSON(value, auto_unbox = TRUE, null = "null", na = "null", digits = NA),
    if (is.null(pilot_patient)) as.character(scalar(spec$output_path)) else
      file.path(dirname(spec_path), "pilot-diagnostic.json"),
    useBytes = TRUE
  )
}

if (sys.nframe() == 0L) padml_shap_main()
