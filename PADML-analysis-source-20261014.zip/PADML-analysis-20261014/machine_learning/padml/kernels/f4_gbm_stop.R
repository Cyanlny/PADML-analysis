#!/usr/bin/env Rscript

# Storage adapter only. The original GBM fit, health, prediction and numeric
# transport expressions come from F2, in their original order.
gbm_stop_native_function <- function(original, replay = FALSE) {
  code <- as.list(body(original))
  positions <- which(vapply(code, function(x) {
    is.call(x) && identical(x[[1L]], as.name("<-")) &&
      identical(x[[2L]], as.name("fit")) && is.call(x[[3L]]) &&
      identical(x[[3L]][[1L]], as.name("withCallingHandlers")) &&
      is.call(x[[3L]][[2L]]) && identical(x[[3L]][[2L]][[1L]], as.name("gbm.fit"))
  }, logical(1)))
  stopifnot(length(positions) == 1L)
  position <- positions[[1L]]
  capture <- quote({
    binding <- list(train = train, test = test, selected = selected,
                    parameters = parameters, model_seed = model_seed, recipe = recipe,
                    train_design = train_design, test_design = test_design,
                    design_map = design_map, task = task)
    if (replay) {
      need(identical(binding, retained$binding), "F4_GBM_STOP_NATIVE_INPUT_MISMATCH")
    } else {
      saveRDS(list(fit = fit, binding = binding, fit_warnings = fit_warnings,
                   rng_state = .Random.seed), paste0(model_path, ".partial"), version = 2L)
      stopifnot(file.rename(paste0(model_path, ".partial"), model_path))
    }
  })
  if (replay) {
    # This derived replay function contains no gbm.fit call. The original
    # health and every-tree prediction expressions below it stay unchanged.
    code[[position]] <- quote({fit <- retained$fit; fit_warnings <- retained$fit_warnings})
  }
  code <- append(code, list(capture), after = position)
  if (replay) {
    seeds <- which(vapply(code, function(x) is.call(x) &&
      identical(x[[1L]], as.name("set.seed")), logical(1)))
    stopifnot(length(seeds) == 1L)
    code <- code[-seeds]
  }
  body(original) <- as.call(code)
  original
}

full_pipeline_q_native_prefix <- function(original, replay, baseline) {
  code <- as.list(body(original))
  prefix <- substitute({
    task <- parent.frame()$task
    native_root <- as.character(scalar(spec$native_search_root))
    native_name <- as.character(scalar(task$task_id))
    need(grepl("^/", native_root) && dir.exists(native_root) &&
           identical(Sys.readlink(native_root), "") &&
           grepl("^[A-Za-z0-9_-]+$", native_name), "F4_Q_NATIVE_PATH_INVALID")
    native_root <- file.path(native_root, native_name)
    replay <- REPLAY
    model_path <- file.path(native_root, "model.rds")
    baseline_path <- file.path(native_root, "baseline.rds")
    if (replay) {
      need(dir.exists(native_root) && identical(Sys.readlink(native_root), "") &&
             identical(sort(list.files(native_root, all.files = TRUE, no.. = TRUE)),
                       sort(c("model.rds", if (BASELINE) "baseline.rds"))) &&
             all(Sys.readlink(list.files(native_root, full.names = TRUE)) == ""),
           "F4_Q_NATIVE_MEMBER_SET_INVALID")
      retained <- readRDS(model_path)
    } else {
      need(!file.exists(native_root) && !dir.exists(native_root) &&
             dir.create(native_root, mode = "0700"), "F4_Q_NATIVE_COLLISION")
    }
    source <- if (identical(as.character(scalar(spec$execution_scope)), "F5_A12_SEARCH"))
      list(a12_source = spec$a12_source, registered_identity = spec$registered_inputs_identity_sha256)
    else if (identical(as.character(scalar(spec$execution_scope)), "F5_FULL_DEVELOPMENT_SEARCH"))
      list(final_search_source = spec$final_search_source,
           registered_identity = spec$registered_inputs_identity_sha256)
    else if (identical(as.character(scalar(spec$execution_scope)), "F2_OUTER_DEVELOPMENT"))
      list(primary_search_source = spec$primary_search_source,
           registered_identity = spec$registered_inputs_identity_sha256)
    else list(full_pipeline_source = spec$full_pipeline_source, seta_lock_sha256 = spec$seta_lock_sha256,
              registered_identity = spec$registered_inputs_identity_sha256)
    task <- c(task, source)
  }, list(REPLAY = replay, BASELINE = baseline))
  body(original) <- as.call(append(code, list(prefix), after = 1L))
  original
}

full_pipeline_q_refit_function <- function(original, target_family, replay) {
  code <- as.list(body(original))
  condition <- substitute(family == FAMILY, list(FAMILY = target_family))
  positions <- which(vapply(code, function(x) is.call(x) &&
    identical(x[[1L]], as.name("if")) && identical(x[[2L]], condition), logical(1)))
  stopifnot(length(positions) == 1L)
  position <- positions[[1L]]
  branch <- as.list(code[[position]][[3L]])
  fits <- which(vapply(branch, function(x) is.call(x) &&
    identical(x[[1L]], as.name("<-")) && identical(x[[2L]], as.name("fit")) &&
    is.call(x[[3L]]) && identical(x[[3L]][[1L]], as.name("withCallingHandlers")) &&
    is.call(x[[3L]][[2L]]) &&
    (if (identical(target_family, "RSF"))
       identical(x[[3L]][[2L]][[1L]], as.name("do.call")) &&
         identical(x[[3L]][[2L]][[2L]], as.name("ranger"))
     else identical(x[[3L]][[2L]][[1L]], as.name("gbm.fit"))), logical(1)))
  stopifnot(length(fits) == 1L)
  fit_position <- fits[[1L]]
  capture <- quote({
    binding <- list(family = family, train = train, test = test, selected = selected,
                    parameters = parameters, model_seed = model_seed, horizons = horizons,
                    recipe = recipe, train_design = train_design, test_design = test_design,
                    design_map = design_map, task = task)
    if (replay) {
      need(identical(binding, retained$binding), "F4_Q_NATIVE_INPUT_MISMATCH")
    } else {
      saveRDS(list(fit = fit, binding = binding, fit_warnings = fit_warnings,
                   rng_state = .Random.seed), paste0(model_path, ".partial"), version = 2L)
      stopifnot(file.rename(paste0(model_path, ".partial"), model_path))
    }
  })
  if (replay) branch[[fit_position]] <- quote({fit <- retained$fit; fit_warnings <- retained$fit_warnings})
  branch <- append(branch, list(capture), after = fit_position)
  if (identical(target_family, "GBM_COX")) {
    bases <- which(vapply(branch, function(x) is.call(x) &&
      identical(x[[1L]], as.name("<-")) && identical(x[[2L]], as.name("base")) &&
      is.call(x[[3L]]) && identical(x[[3L]][[1L]], as.name("breslow")), logical(1)))
    stopifnot(length(bases) == 1L)
    branch <- append(branch, list(quote({
      if (replay) need(identical(base, readRDS(baseline_path)), "F4_Q_NATIVE_BASELINE_MISMATCH")
      else {
        saveRDS(base, paste0(baseline_path, ".partial"), version = 2L)
        stopifnot(file.rename(paste0(baseline_path, ".partial"), baseline_path))
      }
    })), after = bases[[1L]])
  }
  if (replay) {
    seeds <- which(vapply(branch, function(x) is.call(x) &&
      identical(x[[1L]], as.name("set.seed")), logical(1)))
    stopifnot(length(seeds) == 1L)
    branch <- branch[-seeds]
  }
  code[[position]][[3L]] <- as.call(branch)
  body(original) <- as.call(code)
  full_pipeline_q_native_prefix(original, replay, identical(target_family, "GBM_COX"))
}

full_pipeline_q_program <- function(program, family, replay) {
  stopifnot(family %in% c("RSF", "GBM_COX"), is.logical(replay), length(replay) == 1L, !is.na(replay))
  arguments <- which(vapply(program, function(x) is.call(x) &&
    identical(x[[1L]], as.name("<-")) && identical(x[[2L]], as.name("args")), logical(1)))
  stopifnot(length(arguments) == 1L)
  program[[arguments]] <- quote(args <- spec_path)
  for (name in c("fit_predict", "gbm_stop_curve")) {
    positions <- which(vapply(program, function(x) is.call(x) &&
      identical(x[[1L]], as.name("<-")) && identical(x[[2L]], as.name(name)) &&
      is.call(x[[3L]]) && identical(x[[3L]][[1L]], as.name("function")), logical(1)))
    stopifnot(length(positions) == 1L)
    index <- positions[[1L]]
    definition <- program[[index]][[3L]]
    program[[index]][[3L]] <- if (identical(name, "fit_predict"))
      substitute(full_pipeline_q_refit_function(DEFINITION, FAMILY, REPLAY),
                 list(DEFINITION = definition, FAMILY = family, REPLAY = replay))
    else substitute(full_pipeline_q_native_prefix(gbm_stop_native_function(DEFINITION, REPLAY), REPLAY, FALSE),
                    list(DEFINITION = definition, REPLAY = replay))
  }
  program
}

run_full_pipeline_q <- function(spec_path, small_batch=FALSE) {
  spec <- jsonlite::fromJSON(spec_path, simplifyVector = FALSE)
  stopifnot(spec$execution_scope %in% c("F4_FULL_PIPELINE_SEARCH", "F5_A12_SEARCH", "F5_FULL_DEVELOPMENT_SEARCH", "F2_OUTER_DEVELOPMENT"),
            identical(spec$action, "MODEL_PREDICTION_BATCH"),
            spec$family %in% c("RSF", "GBM_COX"), is.logical(spec$native_search_replay),
            length(spec$native_search_replay) == 1L, !is.na(spec$native_search_replay))
  if (identical(spec$execution_scope, "F2_OUTER_DEVELOPMENT")) {
    stopifnot(spec$family %in% c("RSF", "GBM_COX"),
              identical(spec$primary_search_source$program_id, "PADML_F45_REBUILD_20260925"),
              identical(spec$primary_search_source$channel, "PRIMARY"),
              identical(spec$primary_search_source$family, spec$family),
              identical(spec$primary_search_source$outer_fold, spec$fold),
              identical(spec$primary_search_source$heldout_center, spec$heldout_center),
              spec$selection_horizon_months %in% c(6L, 12L, 24L, 36L),
              spec$primary_search_source$selection_horizon_months == spec$selection_horizon_months,
              is.null(spec$a12_source), is.null(spec$final_search_source), is.null(spec$full_pipeline_source))
  }
  script <- grep("^--file=", commandArgs(), value = TRUE)
  stopifnot(length(script) == 1L)
  kernel <- file.path(dirname(gsub("~+~", " ", sub("^--file=", "", script), fixed = TRUE)), "f2_model_development.R")
  options(error = function() {
    dump.frames(dumpto = file.path(dirname(spec$output_path), "native-failure"),
                to.file = TRUE, include.GlobalEnv = TRUE)
    quit(save = "no", status = 1L, runLast = FALSE)
  })
  # Execute the same batch loader, design cache, health, prediction transport and
  # task ordering. Only the selected native fit/STOP definitions gain storage.
  scope <- new.env(parent = environment())
  if (small_batch) scope$quit <- function(save="no", status=0L, runLast=FALSE, ...) {
    if (status != 0L) stop("F45_R_SMALL_BATCH_NATIVE_FAILED", call.=FALSE)
    stop(structure(list(message="native request complete", call=NULL),
                   class=c("padml_batch_complete", "condition")))
  }
  tryCatch(eval(full_pipeline_q_program(parse(kernel), spec$family, spec$native_search_replay),
                envir=scope), padml_batch_complete=function(e) invisible(NULL))
}

run_gbm_stop <- function(spec_path) {
  suppressPackageStartupMessages({library(jsonlite); library(digest); library(survival)})
  spec <- fromJSON(spec_path, simplifyVector = FALSE)
  script <- grep("^--file=", commandArgs(), value = TRUE)
  stopifnot(length(script) == 1L)
  kernel <- file.path(dirname(gsub("~+~", " ", sub("^--file=", "", script), fixed = TRUE)), "f2_model_development.R")
  required <- c("fail", "need", "scalar", "canonical_json", "python_json_number_values",
                "write_operation_local_risk_matrix", "risk_matrix_channel",
                "categorical_contract", "locked_levels", "prepare_frame",
                "validate_compiled_conflicts", "apply_design_recipe", "ordered_parent_column_map",
                "gbm_cox_objective_identity", "validate_gbm_fit_health", "gbm_stop_curve")
  definitions <- Filter(function(x) is.call(x) && identical(x[[1L]], as.name("<-")) &&
    is.symbol(x[[2L]]) && as.character(x[[2L]]) %in% required &&
    is.call(x[[3L]]) && identical(x[[3L]][[1L]], as.name("function")), as.list(parse(kernel)))
  stopifnot(length(definitions) == length(required))
  for (definition in definitions) eval(definition)
  need(identical(sort(names(spec)), sort(c("action", "task", "predictors", "covariate_path",
       "fit_response_path", "prediction_covariate_path", "model_path", "output_path"))),
       "F4_GBM_STOP_SPEC_INVALID")
  task <- spec$task
  need(identical(scalar(task$family), "GBM_COX") &&
         scalar(spec$action) %in% c("FIT", "REPLAY"), "F4_GBM_STOP_SPEC_INVALID")
  output_path <- scalar(spec$output_path)
  model_path <- scalar(spec$model_path)
  replay <- identical(scalar(spec$action), "REPLAY")
  # dump.frames is invoked before the native stack is lost; no retry follows.
  options(error = function() {
    dump.frames(dumpto = file.path(dirname(output_path), "native-failure"),
                to.file = TRUE, include.GlobalEnv = TRUE)
    quit(save = "no", status = 1L, runLast = FALSE)
  })
  time_col <- "Death_Followup_months"
  event_col <- "All_Cause_Death"
  variable_rows <- lapply(spec$predictors$variables, function(row) list(
    name = scalar(row$name), type = scalar(row$type), levels = scalar(row$levels_or_coding),
    set_a_eligible = isTRUE(row$set_a_eligible), selector_eligible = isTRUE(row$selector_eligible),
    forced = isTRUE(row$forced), selector_representation = as.character(scalar(row$selector_representation))))
  parents <- vapply(Filter(function(row) row$set_a_eligible, variable_rows), `[[`, character(1), "name")
  read_covariates <- function(path) prepare_frame(read.csv(path, check.names = FALSE,
    stringsAsFactors = FALSE, colClasses = "character", encoding = "UTF-8"))
  train <- read_covariates(scalar(spec$covariate_path))
  test <- read_covariates(scalar(spec$prediction_covariate_path))
  response <- read.csv(scalar(spec$fit_response_path), check.names = FALSE,
                       stringsAsFactors = FALSE, colClasses = "character", encoding = "UTF-8")
  need(identical(names(response), c("Patient_ID", event_col, time_col)) &&
         identical(train$Patient_ID, response$Patient_ID) &&
         !length(intersect(train$Patient_ID, test$Patient_ID)) &&
         !any(c(time_col, event_col) %in% names(test)), "F4_GBM_STOP_RESPONSE_ISOLATION_INVALID")
  train[[time_col]] <- suppressWarnings(as.numeric(response[[time_col]]))
  train[[event_col]] <- suppressWarnings(as.integer(response[[event_col]]))
  need(all(is.finite(train[[time_col]])) && all(train[[time_col]] > 0) &&
         all(train[[event_col]] %in% c(0L, 1L)) && any(train[[event_col]] == 1L),
       "F4_GBM_STOP_FIT_RESPONSE_INVALID")
  if (replay) retained <- readRDS(model_path)
  native <- gbm_stop_native_function(gbm_stop_curve, replay)
  result <- native(train, test, as.character(unlist(task$selected_parents)),
                   task$stop_parameters, as.integer(scalar(task$model_seed)), NULL, "risk-001-gbm")
  writeLines(canonical_json(result, always_decimal = TRUE, digits = I(17)), output_path, useBytes = TRUE)
}

args <- commandArgs(trailingOnly = TRUE)
stopifnot(length(args) == 1L)
if (identical(args[[1L]], "--small-batch")) {
  # This child belongs to one existing pool worker and exits after at most four
  # atom pairs. Each request keeps its original specification/output paths.
  input <- file("stdin", "r")
  .padml_r_batch_design_cache <- new.env(parent=emptyenv())
  for (i in seq_len(8L)) {
    line <- readLines(input, n=1L, warn=FALSE)
    if (!length(line)) break
    request <- jsonlite::fromJSON(line, simplifyVector=FALSE)
    stopifnot(identical(sort(names(request)), sort(c("spec", "cwd", "stdout", "stderr"))))
    setwd(request$cwd)
    out <- file(request$stdout, "a"); err <- file(request$stderr, "a")
    sink(out); sink(err, type="message")
    ok <- tryCatch({run_full_pipeline_q(request$spec, small_batch=TRUE); TRUE}, error=function(e) {
      message(conditionMessage(e)); FALSE
    })
    sink(type="message"); sink(); close(out); close(err)
    cat(if (ok) "PASS\n" else "FAIL\n"); flush(stdout())
    if (!ok) quit(save="no", status=1L, runLast=FALSE)
  }
  close(input)
  quit(save="no", status=0L, runLast=FALSE)
}
scope <- jsonlite::fromJSON(args[[1L]], simplifyVector = FALSE)$execution_scope
if (!is.null(scope) && scope %in% c("F4_FULL_PIPELINE_SEARCH", "F5_A12_SEARCH", "F5_FULL_DEVELOPMENT_SEARCH", "F2_OUTER_DEVELOPMENT")) {
  run_full_pipeline_q(args[[1L]])
} else {
  run_gbm_stop(args[[1L]])
}
