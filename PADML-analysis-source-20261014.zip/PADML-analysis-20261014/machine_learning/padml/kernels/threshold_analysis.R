# 独立AAR阈值补充分析；科学输入只来自冻结关联A01，旧ML入口不参与。
ta_require <- function(ok, code) if (!isTRUE(ok)) stop(code, call. = FALSE)
ta_bind <- function(x) if (length(x)) do.call(rbind, x) else data.frame()
ta_atomic <- function(value, path) {
  # 保存当前坐标的唯一可恢复数值，不保存展开患者或原生模型副本。
  saveRDS(value, paste0(path, ".part"), compress = TRUE, version = 3)
  ta_require(file.rename(paste0(path, ".part"), path), "PUBLICATION_RENAME_FAILED")
}
ta_csv <- function(value, path) {
  # 公开CSV仅由数值层归约，不包含患者标识。
  write.csv(value, paste0(path, ".part"), row.names = FALSE, na = "")
  ta_require(file.rename(paste0(path, ".part"), path), "CSV_PUBLICATION_FAILED")
}
ta_round <- function(x) {
  # 用可往返的十进制表示half-up，不能先把半位邻点量化到半位。
  vapply(x, function(v) {
    if (!is.finite(v)) return(NA_real_)
    ta_require(v >= 0, "NEGATIVE_AAR_CUTOFF")
    for (digits in 1:17) {
      txt <- format(v, digits = digits, scientific = FALSE, trim = TRUE)
      if (identical(as.numeric(txt),v)) break
    }
    bits <- strsplit(txt, ".", fixed = TRUE)[[1]]
    decimals <- paste0(if (length(bits) == 2L) bits[[2]] else "", "000")
    (as.numeric(bits[[1]]) * 100 + as.numeric(substr(decimals, 1, 2)) +
      as.integer(substr(decimals, 3, 3) >= "5")) / 100
  }, numeric(1), USE.NAMES = FALSE)
}

ta_km <- function(time, event, multiplicity, censor = TRUE) {
  active <- multiplicity > 0
  time <- time[active]; event <- event[active]; m <- multiplicity[active]
  ta_require(length(time) > 0L && all(is.finite(time)) && all(time >= 0) &&
    all(event %in% 0:1) && all(m == as.integer(m)) && all(m > 0), "KM_INPUT_INVALID")
  grid <- sort(unique(time)); ix <- match(time, grid)
  counts <- as.numeric(rowsum(m, ix, reorder = TRUE))
  fail <- as.numeric(rowsum(m * if (censor) (event == 0L) else (event == 1L), ix, reorder = TRUE))
  risk <- rev(cumsum(rev(counts)))
  after <- cumprod(1 - fail / risk)
  data.frame(time = grid, risk = risk, failed = fail, after = after,
    before = c(1, head(after, -1L)))
}
ta_km_at <- function(km, x, before = FALSE) {
  j <- findInterval(x, km$time)
  if (before) {
    exact <- j > 0L & x == km$time[pmax(j, 1L)]
    j[exact] <- j[exact] - 1L
  }
  c(1, km$after)[j + 1L]
}
ta_weights <- function(d, m, cfg, by_center = FALSE, support = TRUE) {
  cases <- d$All_Cause_Death == 1L & d$Death_Followup_months <= cfg$horizon
  controls <- d$Death_Followup_months > cfg$horizon
  w <- rep(0, nrow(d)); required_g <- numeric(); reasons <- character()
  strata <- if (by_center) as.character(d$Center) else rep("ALL", nrow(d))
  for (center in unique(strata[m > 0])) {
    ix <- which(strata == center & m > 0)
    km <- ta_km(d$Death_Followup_months[ix], d$All_Cause_Death[ix], m[ix])
    g_t <- ta_km_at(km, cfg$horizon)
    g_case <- ta_km_at(km, d$Death_Followup_months[ix[cases[ix]]], before = TRUE)
    # G(t)是目标人口随访支持，不能因该次全部早删失便跳过该中心。
    required_g <- c(required_g, g_t, g_case)
    if (!is.finite(g_t) || g_t < cfg$g_min || any(!is.finite(g_case) | g_case < cfg$g_min)) {
      reasons <- c(reasons, paste0("CENSOR_SUPPORT:", center)); next
    }
    w[ix[cases[ix]]] <- 1 / g_case
    w[ix[controls[ix]]] <- 1 / g_t
  }
  den <- sum(m * w^2)
  ess <- if (den > 0) sum(m * w)^2 / den else 0
  n_eval <- sum(m * (cases | controls))
  if (support && ess < max(cfg$ess_min, cfg$ess_fraction * n_eval)) reasons <- c(reasons, "ESS_SUPPORT")
  list(w = w, cases = cases, controls = controls, m = m, n = sum(m), n_eval = n_eval,
    case_n = sum(m * cases), control_n = sum(m * controls), censor_n = sum(m * !(cases | controls)),
    min_g = if (length(required_g)) min(required_g) else NA_real_,
    max_weight = max(w), ess = ess, reason = paste(unique(reasons), collapse = ";"))
}
ta_select <- function(d, m, cfg, by_center = FALSE) {
  wt <- ta_weights(d, m, cfg, by_center)
  reason <- wt$reason
  if (!wt$case_n) reason <- paste(c(reason, "ZERO_TRAIN_CASES"), collapse = ";")
  if (!wt$control_n) reason <- paste(c(reason, "ZERO_TRAIN_CONTROLS"), collapse = ";")
  values <- sort(unique(d$AST_ALT[m > 0]))
  if (length(values) < 2L) reason <- paste(c(reason, "CONSTANT_TRAIN_AAR"), collapse = ";")
  result <- list(raw = NA_real_, rounded = NA_real_, youden = NA_real_, candidates = max(0L, length(values)-1L),
    tie_n = 0L, tie_low = NA_real_, tie_high = NA_real_, reason = sub("^;", "", reason), support = wt[c("n","n_eval","case_n","control_n","min_g","max_weight","ess")])
  if (nzchar(result$reason)) return(result)
  ix <- match(d$AST_ALT, values); live <- m > 0
  cw <- as.numeric(rowsum((m * wt$w * wt$cases)[live], ix[live], reorder = TRUE))
  sw <- as.numeric(rowsum((m * wt$w * wt$controls)[live], ix[live], reorder = TRUE))
  # 同一排序一次累计，等价于逐候选扫描；没有按结果减少候选。
  sensitivity <- 1 - head(cumsum(cw), -1L) / sum(cw)
  specificity <- head(cumsum(sw), -1L) / sum(sw)
  youden <- sensitivity + specificity - 1
  candidates <- head(values, -1L) + diff(values) / 2
  tied <- which(max(youden) - youden <= cfg$youden_tie_tolerance)
  selected <- tied[[floor((length(tied) + 1L) / 2L)]]
  result$raw <- candidates[[selected]]; result$rounded <- ta_round(result$raw)
  result$youden <- youden[[selected]]; result$tie_n <- length(tied)
  result$tie_low <- min(candidates[tied]); result$tie_high <- max(candidates[tied])
  result
}
ta_counts <- function(d, m, wt, cutoff) {
  high <- if (is.finite(cutoff)) d$AST_ALT > cutoff else rep(NA, nrow(d))
  if (!is.finite(cutoff)) return(list(counts = setNames(rep(NA_real_, 4), c("TP","FN","FP","TN")),
    high = NA_real_, n = sum(m), reason = "TRAIN_SELECTOR_NOT_ESTIMABLE"))
  list(counts = c(TP = sum(m * wt$w * wt$cases * high), FN = sum(m * wt$w * wt$cases * !high),
    FP = sum(m * wt$w * wt$controls * high), TN = sum(m * wt$w * wt$controls * !high)),
    high = sum(m * high), n = sum(m), reason = wt$reason)
}
ta_metric <- function(counts) {
  c <- counts$counts
  ratio <- function(num, den, why) {
    if (nzchar(counts$reason)) return(list(value = NA_real_, reason = counts$reason))
    if (!is.finite(den) || den <= 0) return(list(value = NA_real_, reason = why))
    list(value = unname(num / den), reason = "")
  }
  ans <- list(Se = ratio(c[["TP"]], c[["TP"]]+c[["FN"]], "ZERO_CASES"),
    Sp = ratio(c[["TN"]], c[["TN"]]+c[["FP"]], "ZERO_CONTROLS"),
    PPV = ratio(c[["TP"]], c[["TP"]]+c[["FP"]], "NO_WEIGHTED_POSITIVES"),
    NPV = ratio(c[["TN"]], c[["TN"]]+c[["FN"]], "NO_WEIGHTED_NEGATIVES"))
  ans$Youden <- list(value = ans$Se$value + ans$Sp$value - 1,
    reason = paste(unique(c(ans$Se$reason, ans$Sp$reason)[nzchar(c(ans$Se$reason, ans$Sp$reason))]), collapse = ";"))
  ans$HighFraction <- list(value = counts$high / counts$n,
    reason = if (is.finite(counts$high)) "" else "TRAIN_SELECTOR_NOT_ESTIMABLE")
  ans
}
ta_rows <- function(metrics, branch, variant, scope, center = "ALL") ta_bind(lapply(names(metrics), function(metric) {
  item <- metrics[[metric]]
  data.frame(branch = branch, variant = variant, scope = scope, center = as.character(center), metric = metric,
    value = item$value, status = if (is.finite(item$value)) "ESTIMABLE" else "NOT_ESTIMABLE", reason = item$reason,
    stringsAsFactors = FALSE)
}))
ta_original_cutoff <- function(layer, summary) {
  row <- summary[summary$time_month == 24, , drop = FALSE]
  ta_require(nrow(row) == 1, "ORIGINAL_ROC_TIME_INVALID")
  hits <- lapply(layer, function(branch) {
    d <- branch$thresholds
    i <- order(-d$youden_j, -d$balance, abs(d$cutoff-row$frozen_marker_median), d$cutoff)[[1]]
    best <- d[i, , drop = FALSE]
    if (all(abs(unlist(best[c("cutoff","sensitivity","specificity","youden_j")]) -
      unlist(row[c("cutoff","sensitivity","specificity","youden_j")])) < 1e-12)) best$cutoff else NULL
  })
  hits <- unlist(hits, use.names = FALSE)
  ta_require(length(hits) == 1L, "ORIGINAL_ROC_LAYER_AMBIGUOUS")
  hits[[1]]
}
ta_context <- function(req) {
  # 加载冻结的关联M20，而非ML插补载体。
  cfg <- jsonlite::read_json(req$config, simplifyVector = TRUE)
  ta_require(identical(as.character(getRversion()), cfg$runtime$R), "R_VERSION_DRIFT")
  for (pkg in setdiff(names(cfg$runtime), "R")) ta_require(requireNamespace(pkg,quietly=TRUE) &&
    identical(as.character(utils::packageVersion(pkg)),cfg$runtime[[pkg]]),paste0("R_PACKAGE_DRIFT:",pkg))
  if (!req$mode %in% c("prepare","cox")) {
    obs <- readRDS(file.path(req$output,"observation.rds"))
    ta_require(identical(obs$identity,req$identity),"OBSERVATION_IDENTITY_DRIFT")
    return(list(cfg=cfg,d=obs$d,roc=obs$roc))
  }
  s <- readRDS(req$input_state); d <- s$exposure$imp0_eligible; mi <- s$exposure$completed
  required <- c("Patient_ID","Center","AST","ALT","AST_ALT","Death_Followup_months","All_Cause_Death")
  ta_require(all(required %in% names(d)) && nrow(d) == cfg$cohort_n && length(mi) == cfg$imputations,
    "ASSOCIATION_SOURCE_SHAPE")
  ta_require(!anyNA(d[required]) && !anyDuplicated(d$Patient_ID) && all(d$AST > 0 & d$ALT > 0) &&
    all(d$AST_ALT == d$AST / d$ALT) && all(is.finite(d$Death_Followup_months)) &&
    all(d$Death_Followup_months >= 0) && all(d$All_Cause_Death %in% 0:1), "ASSOCIATION_OBSERVED_INVALID")
  ta_require(identical(as.integer(table(factor(d$Center, levels = c(cfg$centers, cfg$training_only_center)))),
    as.integer(cfg$center_counts)) && sum(d$All_Cause_Death) == cfg$events, "ASSOCIATION_POPULATION_DRIFT")
  for (x in mi) ta_require(identical(x$Patient_ID, d$Patient_ID) && identical(x$AST_ALT, d$AST_ALT) &&
    identical(x$All_Cause_Death, d$All_Cause_Death) && identical(x$Death_Followup_months, d$Death_Followup_months) &&
    identical(x$Center, d$Center), "MI_FIXED_FIELDS_DRIFT")
  # 本模块不使用不完整MI子集；配置和软件版本进入冻结身份。
  roc <- ta_original_cutoff(readRDS(req$roc_layer), read.csv(req$roc_summary))
  list(cfg = cfg, d = d, mi = mi, roc = roc)
}
ta_boot_counts <- function(d, cfg, b) {
  # 每B独立CMRG子流；并行顺序和恢复不改变抽样。
  RNGkind(cfg$rng[[1]], cfg$rng[[2]], cfg$rng[[3]]); set.seed(cfg$seed)
  stream <- .Random.seed
  if (b > 1L) for (i in seq_len(b-1L)) stream <- parallel::nextRNGStream(stream)
  assign(".Random.seed", stream, envir = .GlobalEnv)
  m <- integer(nrow(d))
  for (center in c(cfg$centers, cfg$training_only_center)) {
    ix <- which(d$Center == center)
    m[ix] <- tabulate(sample.int(length(ix), length(ix), replace = TRUE), nbins = length(ix))
  }
  list(m = m, stream = stream)
}
ta_km_risk <- function(d, m, cutoff, cfg) {
  result <- list()
  for (group in c("LOW","HIGH")) {
    ix <- m > 0 & (d$AST_ALT > cutoff) == (group == "HIGH")
    reason <- ""; value <- NA_real_
    if (!any(ix)) reason <- "EMPTY_KM_GROUP" else if (max(d$Death_Followup_months[ix]) < cfg$horizon) {
      reason <- "KM_FOLLOWUP_SUPPORT"
    } else value <- 1 - ta_km_at(ta_km(d$Death_Followup_months[ix], d$All_Cause_Death[ix], m[ix], FALSE), cfg$horizon)
    result[[paste0("Risk24_", group)]] <- list(value = value, reason = reason)
  }
  result$RiskDifference24 <- list(value = result$Risk24_HIGH$value-result$Risk24_LOW$value,
    reason = paste(unique(c(result$Risk24_HIGH$reason, result$Risk24_LOW$reason)), collapse = ";"))
  result
}
ta_evaluate <- function(ctx, m, b = 0L) {
  d <- ctx$d; cfg <- ctx$cfg; records <- list(); selections <- list(); patients <- list(); diagnostics <- list()
  fixed <- c(FIXED146 = cfg$fixed_cutoff, ROC_ORIGINAL = ctx$roc)
  wt_full <- ta_weights(d, m, cfg)
  for (branch in names(fixed)) {
    records[[length(records)+1L]] <- ta_rows(ta_metric(ta_counts(d, m, wt_full, fixed[[branch]])), branch, "FIXED", "FULL2124")
    records[[length(records)+1L]] <- ta_rows(ta_km_risk(d, m, fixed[[branch]], cfg), branch, "FIXED", "FULL2124")
  }
  branches <- c(names(fixed), "LOCO_MAIN", "LOCO_CENTER_KM", "LOCO_NO55")
  all_counts <- list()
  for (center in cfg$centers) {
    ix <- which(d$Center == center); val <- d[ix, , drop = FALSE]; mv <- m[ix]
    wt <- ta_weights(val, mv, cfg)
    diagnostics[[length(diagnostics)+1L]] <- data.frame(center = center, as.data.frame(wt[c("n","n_eval","case_n","control_n","censor_n","min_g","max_weight","ess","reason")]))
    for (branch in branches) {
      if (branch %in% names(fixed)) thresholds <- c(FIXED = fixed[[branch]]) else {
        train <- d$Center != center & (branch != "LOCO_NO55" | d$Center != cfg$training_only_center)
        sel <- ta_select(d[train, , drop = FALSE], m[train], cfg, branch == "LOCO_CENTER_KM")
        selections[[length(selections)+1L]] <- data.frame(branch = branch, center = as.character(center),
          as.data.frame(sel[setdiff(names(sel), "support")]), as.data.frame(sel$support), stringsAsFactors = FALSE)
        thresholds <- c(RAW = sel$raw, ROUNDED = sel$rounded)
      }
      for (variant in names(thresholds)) {
        cutoff <- thresholds[[variant]]; key <- paste(branch, variant, sep = "/")
        counts <- ta_counts(val, mv, wt, cutoff)
        all_counts[[key]][[as.character(center)]] <- counts
        records[[length(records)+1L]] <- ta_rows(ta_metric(counts), branch, variant, "CENTER", center)
        if (b == 0L) patients[[length(patients)+1L]] <- data.frame(Patient_ID = val$Patient_ID,
          Center = center, branch = branch, variant = variant, cutoff = cutoff,
          high = if (is.finite(cutoff)) val$AST_ALT > cutoff else NA, weight = wt$w)
      }
    }
  }
  for (key in names(all_counts)) {
    parts <- strsplit(key, "/", fixed = TRUE)[[1]]; items <- all_counts[[key]]
    ta_require(length(items) == 6L, "SIX_CENTER_COVERAGE")
    reasons <- unique(vapply(items, `[[`, "", "reason")); reasons <- reasons[nzchar(reasons)]
    merged <- list(counts = Reduce(`+`, lapply(items, `[[`, "counts")), high = sum(vapply(items, `[[`, 0, "high")),
      n = sum(vapply(items, `[[`, 0, "n")), reason = paste(reasons, collapse = ";"))
    records[[length(records)+1L]] <- ta_rows(ta_metric(merged), parts[[1]], parts[[2]], "MICRO6")
    metrics <- lapply(items, ta_metric)
    macro <- lapply(names(metrics[[1]]), function(name) {
      values <- vapply(metrics, function(x) x[[name]]$value, 0)
      list(value = if (all(is.finite(values))) mean(values) else NA_real_,
        reason = paste(unique(vapply(metrics, function(x) x[[name]]$reason, "")), collapse = ";"))
    }); names(macro) <- names(metrics[[1]])
    records[[length(records)+1L]] <- ta_rows(macro, parts[[1]], parts[[2]], "MACRO6")
  }
  global <- ta_select(d, m, cfg)
  selections[[length(selections)+1L]] <- data.frame(branch = "GLOBAL_NEW_RULE", center = "ALL",
    as.data.frame(global[setdiff(names(global), "support")]), as.data.frame(global$support), stringsAsFactors = FALSE)
  rows <- ta_bind(records)
  comparisons <- list(c("LOCO_MAIN","ROUNDED","FIXED146","FIXED"),
    c("ROC_ORIGINAL","FIXED","FIXED146","FIXED"),
    c("LOCO_CENTER_KM","ROUNDED","LOCO_MAIN","ROUNDED"),
    c("LOCO_NO55","ROUNDED","LOCO_MAIN","ROUNDED"))
  for (branch in c("LOCO_MAIN","LOCO_CENTER_KM","LOCO_NO55")) comparisons[[length(comparisons)+1L]] <- c(branch,"RAW",branch,"ROUNDED")
  for (pair in comparisons) {
    a <- rows[rows$branch == pair[[1]] & rows$variant == pair[[2]], , drop = FALSE]
    z <- rows[rows$branch == pair[[3]] & rows$variant == pair[[4]], , drop = FALSE]
    joined <- merge(a, z, by = c("scope","center","metric"), suffixes = c(".a",".z"), sort = FALSE)
    out <- data.frame(branch = paste(paste(pair[1:2], collapse = "/"), paste(pair[3:4], collapse = "/"), sep = "_MINUS_"),
      variant = "PAIRED_DIFFERENCE", scope = joined$scope, center = joined$center, metric = joined$metric,
      value = joined$value.a-joined$value.z, status = ifelse(is.finite(joined$value.a) & is.finite(joined$value.z), "ESTIMABLE", "NOT_ESTIMABLE"),
      reason = paste(joined$reason.a, joined$reason.z, sep = ";"))
    records[[length(records)+1L]] <- out
  }
  list(b = b, metrics = ta_bind(records), thresholds = ta_bind(selections), support = ta_bind(diagnostics),
    patients = if (b == 0L) ta_bind(patients) else NULL)
}

ta_fit_data <- function(ctx, spec) {
  d <- if (spec$kind == "COMPLETE_CASE") ctx$d else ctx$mi[[spec$imputation]]
  covariates <- unlist(ctx$cfg$model_covariates[[spec$model]], use.names = FALSE)
  cols <- unique(c("Patient_ID","Center","AST_ALT","All_Cause_Death","Death_Followup_months", covariates))
  d <- d[, cols, drop = FALSE]
  # 复用正式关联 normalize_cox_factor_levels 的 treatment 编码及参照水平。
  factor_levels <- list(Sex=c("0","1"), Rutherford_cat=c("Grade 0-2","Grade 3-4","Grade 5-6"),
    Prior_LE_Surgery_cat=c("None","Procedure","Amputation","Other"),
    Surgery_Type_cat=c("None","Procedure","Amputation","Other"), HF_NYHA_bin=c("No","Yes"))
  for (name in intersect(names(factor_levels),names(d))) {
    observed <- as.character(d[[name]])
    if (all(observed[!is.na(observed)] %in% factor_levels[[name]]))
      d[[name]] <- factor(observed,levels=factor_levels[[name]])
  }
  if (spec$kind == "COMPLETE_CASE") d <- d[complete.cases(d), , drop = FALSE]
  d$H <- as.integer(d$AST_ALT > ctx$cfg$fixed_cutoff)
  if (spec$kind == "TVE" && spec$model == "M5") {
    d$Rutherford_G34 <- as.integer(as.character(d$Rutherford_cat) == "Grade 3-4")
    d$Rutherford_G56 <- as.integer(as.character(d$Rutherford_cat) == "Grade 5-6")
  }
  d
}
ta_fit <- function(ctx, spec) {
  # 加载 survival，在冻结关联协变量上拟合必要的二分类Cox；不进入七家族。
  ta_require(requireNamespace("survival", quietly = TRUE), "SURVIVAL_MISSING")
  d <- ta_fit_data(ctx, spec); covs <- unlist(ctx$cfg$model_covariates[[spec$model]], use.names = FALSE)
  terms <- c("H", covs)
  if (spec$kind == "TVE") {
    terms <- c(terms, "tt(H)")
    if (spec$model == "M5") terms <- c(setdiff(terms, "Rutherford_cat"), "Rutherford_G34","Rutherford_G56",
      "tt(Rutherford_G34)","tt(Rutherford_G56)")
  }
  if (spec$kind == "CENTER_STRATA") terms <- c(terms, "strata(Center)")
  formula <- as.formula(paste("survival::Surv(Death_Followup_months, All_Cause_Death) ~", paste(terms, collapse = " + ")))
  warnings <- character()
  # Cox求解异常不能吞并成统计NA；记录后由直接消费者阻止完成。
  fit <- withCallingHandlers(survival::coxph(formula, data = d, ties = "efron", na.action = na.fail,
    tt = function(x, t, ...) x * (log1p(t) - log(13)), x = spec$kind != "TVE", y = FALSE, model = FALSE),
    warning = function(w) {warnings <<- c(warnings, conditionMessage(w)); invokeRestart("muffleWarning")})
  beta <- stats::coef(fit); covariance <- stats::vcov(fit)
  ta_require(all(is.finite(beta)) && all(is.finite(covariance)) && is.null(fit$fail) &&
    !length(warnings), "COX_NUMERICAL_FAILURE")
  ph <- if (spec$kind != "TVE") survival::cox.zph(fit, transform = "km", terms = TRUE)$table else NULL
  list(spec = spec, formula = paste(deparse(formula), collapse = " "), n = nrow(d), events = sum(d$All_Cause_Death),
    coefficients = beta, covariance = covariance, loglik = fit$loglik, ph = ph, warnings = warnings,
    status = "ESTIMABLE")
}
ta_pool <- function(q, u) {
  # 正式关联代码的Rubin 1987自由度；不按注册表误写为Barnard–Rubin。
  ta_require(length(q) == 20L && length(u) == 20L && all(is.finite(q)) && all(is.finite(u) & u >= 0), "INCOMPLETE_M20_COX")
  estimate <- mean(q); within <- mean(u); between <- stats::var(q)
  total <- within + (1+1/20)*between
  r <- if (within > 0) (1+1/20)*between/within else Inf
  df <- if (is.finite(r) && r > 0) 19*(1+1/r)^2 else Inf
  critical <- if (is.finite(df)) stats::qt(.975, df) else stats::qnorm(.975)
  se <- sqrt(total)
  data.frame(beta = estimate, se = se, hr = exp(estimate), lower = exp(estimate-critical*se), upper = exp(estimate+critical*se),
    p = if (is.finite(df)) 2*stats::pt(-abs(estimate/se), df) else 2*stats::pnorm(-abs(estimate/se)),
    within = within, between = between, total = total, df = df, m = 20L)
}

ta_prepare <- function(ctx, req) {
  tasks <- list(); aliases <- list(); keys <- character()
  logical <- list()
  for (kind in c("FIXED","TVE")) for (model in c("M1","M2","M5")) for (i in 1:20) {
    logical[[length(logical)+1L]] <- list(kind = kind, model = model, imputation = i)
  }
  for (i in 1:20) logical[[length(logical)+1L]] <- list(kind = "CENTER_STRATA", model = "M5", imputation = i)
  logical[[length(logical)+1L]] <- list(kind = "COMPLETE_CASE", model = "M5", imputation = 0L)
  for (spec in logical) {
    d <- ta_fit_data(ctx, spec)
    # 只按真实模型消费的数据去重；患者身份、顺序、因子水平仍属于准备身份。
    key <- digest::digest(list(spec$kind, spec$model, d), algo = "sha256")
    task <- paste0("cox-", substr(key, 1, 24))
    if (!key %in% keys) { tasks[[length(tasks)+1L]] <- c(spec, list(task = task)); keys <- c(keys, key) }
    aliases[[length(aliases)+1L]] <- c(spec, list(task = task))
  }
  list(identity = req$identity, logical_fit_n = length(logical), physical_fit_n = length(tasks), tasks = tasks, aliases = aliases,
    n = nrow(ctx$d), events = sum(ctx$d$All_Cause_Death), original_cutoff = ctx$roc,
    fixed_reclassification_n = sum((ctx$d$AST_ALT > ctx$roc) != (ctx$d$AST_ALT > ctx$cfg$fixed_cutoff)))
}
ta_check_record <- function(x, identity, id) {
  ta_require(identical(x$identity, identity) && identical(x$id, id) && identical(x$status, "COMPLETED"), "RETAINED_COORDINATE_DRIFT")
  invisible(x)
}
ta_reduce <- function(ctx, req) {
  root <- req$output; prepared <- readRDS(file.path(root, "prepared.rds"))
  point <- readRDS(file.path(root, "point.rds")); ta_check_record(point, req$identity, "point")
  point <- point$result
  boot <- lapply(1:ctx$cfg$bootstrap_n, function(b) {
    id <- sprintf("B%04d", b); x <- readRDS(file.path(root, "numerical", paste0(id,".rds")))
    ta_check_record(x, req$identity, id); ta_require(x$result$b == b && is.null(x$result$patients), "BOOTSTRAP_COORDINATE_INVALID")
    x$result
  })
  key <- function(d) do.call(paste, c(d[c("branch","variant","scope","center","metric")], sep = "|"))
  expected <- key(point$metrics)
  ta_require(!anyDuplicated(expected), "DUPLICATE_METRIC_COORDINATE")
  values <- vapply(boot, function(x) {
    k <- key(x$metrics); ta_require(identical(k, expected), "BOOTSTRAP_METRIC_GRID_DRIFT")
    x$metrics$value
  }, numeric(length(expected)))
  intervals <- point$metrics
  intervals$valid_b <- rowSums(is.finite(values)); intervals$bootstrap_n <- ctx$cfg$bootstrap_n
  eligible <- intervals$valid_b >= ctx$cfg$minimum_valid_bootstrap & is.finite(intervals$value)
  endpoints <- t(vapply(seq_len(nrow(values)), function(i) {
    if (!eligible[[i]]) return(c(NA_real_, NA_real_))
    as.numeric(stats::quantile(values[i, is.finite(values[i, ])], c(.025,.975), type = 7, names = FALSE))
  }, numeric(2)))
  intervals$lower <- endpoints[,1]; intervals$upper <- endpoints[,2]
  intervals$interval_status <- ifelse(eligible, "EXPLORATORY_VALID_SUBSET_NOT_COVERAGE_VALIDATED", "NOT_PUBLISHED")
  intervals$zero_width <- eligible & intervals$lower == intervals$upper
  intervals$conditionality <- ifelse(intervals$variant=="PAIRED_DIFFERENCE",
    "Observed_centers;paired_same_B_valid_intersection",
    ifelse(grepl("^LOCO",intervals$branch),"Observed_centers;training_selected_rule_validation",
      "Observed_centers;post_hoc_fixed_cutoff_descriptive"))
  intervals$interval_method <- "CENTER_BOOTSTRAP_TYPE7_VALID_SUBSET"
  reasons <- ta_bind(lapply(boot, function(x) {
    z <- x$metrics[x$metrics$status != "ESTIMABLE", c("branch","variant","scope","center","metric","reason"), drop = FALSE]
    if (nrow(z)) transform(z, b = x$b) else NULL
  }))
  # 逐B完整数值只保留在numerical成员，公开表只归约失败次数而不重复嵌入原始数组。
  reason_counts <- if (nrow(reasons)) aggregate(rep(1L,nrow(reasons)), reasons[setdiff(names(reasons),"b")], length) else
    data.frame(branch=character(),variant=character(),scope=character(),center=character(),metric=character(),reason=character(),count=integer())
  if (nrow(reason_counts)) names(reason_counts)[ncol(reason_counts)] <- "count"
  ts <- ta_bind(lapply(boot, function(x) transform(x$thresholds, b = x$b)))
  threshold_summary <- ta_bind(lapply(split(ts, paste(ts$branch, ts$center, sep = "|")), function(x) {
    ta_bind(lapply(c("raw","rounded"), function(v) {
      z <- x[[v]][is.finite(x[[v]])]
      q <- if (length(z)) stats::quantile(z, c(.025,.25,.5,.75,.975), type = 7, names = FALSE) else rep(NA_real_,5)
      data.frame(branch=x$branch[[1]],center=x$center[[1]],variant=v,valid_b=length(z),lower=q[1],q25=q[2],median=q[3],q75=q[4],upper=q[5],
        interpretation="DESCRIPTIVE_SELECTION_DISTRIBUTION_NOT_TRUE_THRESHOLD_CI")
    }))
  }))
  coefs <- list(); summaries <- list(); ph <- list()
  for (task in prepared$tasks) {
    rec <- readRDS(file.path(root,"numerical",paste0(task$task,".rds"))); ta_check_record(rec,req$identity,task$task)
    ta_require(rec$result$status == "ESTIMABLE", "COX_RESULT_NOT_ACCEPTED"); coefs[[task$task]] <- rec$result
  }
  for (kind in c("FIXED","TVE","CENTER_STRATA")) for (model in if (kind == "CENTER_STRATA") "M5" else c("M1","M2","M5")) {
    aliases <- Filter(function(x) x$kind == kind && x$model == model, prepared$aliases)
    ta_require(length(aliases) == 20L && identical(vapply(aliases, `[[`, 0L, "imputation"), 1:20), "COX_ALIAS_M20_INCOMPLETE")
    fits <- lapply(aliases, function(x) coefs[[x$task]])
    for (t in if (kind == "TVE") ctx$cfg$time_reports else -1) {
      weights <- if (kind == "TVE") c(H=1, `tt(H)`=log1p(t)-log(13)) else c(H=1)
      q <- vapply(fits,function(x) sum(x$coefficients[names(weights)]*weights),0)
      u <- vapply(fits,function(x) as.numeric(t(weights)%*%x$covariance[names(weights),names(weights),drop=FALSE]%*%weights),0)
      summaries[[length(summaries)+1L]] <- cbind(data.frame(kind=kind,model=model,time=t,contrast="HIGH_V_LOW"),ta_pool(q,u))
    }
    if (kind == "TVE") {
      p <- ta_pool(vapply(fits,function(x) x$coefficients[["tt(H)"]],0),vapply(fits,function(x) x$covariance["tt(H)","tt(H)"],0))
      summaries[[length(summaries)+1L]] <- cbind(data.frame(kind=kind,model=model,time=-1,contrast="BINARY_TIME_INTERACTION"),p)
    } else for (i in 1:20) ph[[length(ph)+1L]] <- data.frame(kind=kind,model=model,imputation=i,term=rownames(fits[[i]]$ph),fits[[i]]$ph,row.names=NULL)
  }
  cc <- Filter(function(x) x$kind == "COMPLETE_CASE", prepared$aliases)[[1]]
  fit <- coefs[[cc$task]]; beta <- fit$coefficients[["H"]]; se <- sqrt(fit$covariance["H","H"])
  complete_case <- data.frame(n=fit$n,events=fit$events,beta=beta,se=se,hr=exp(beta),lower=exp(beta-qnorm(.975)*se),upper=exp(beta+qnorm(.975)*se),p=2*pnorm(-abs(beta/se)))
  # KM数值由原生survfit一次生成；仅发布0–36月，不作图或延长无支持尾部。
  dd <- ctx$d; dd$group <- factor(ifelse(dd$AST_ALT > ctx$cfg$fixed_cutoff,"HIGH","LOW"),levels=c("LOW","HIGH"))
  km <- survival::survfit(survival::Surv(Death_Followup_months,All_Cause_Death)~group,data=dd,conf.type="log",conf.int=.95)
  sk <- summary(km,censored=TRUE)
  km_table <- data.frame(group=as.character(sk$strata),time=sk$time,survival=sk$surv,lower=sk$lower,upper=sk$upper,n_risk=sk$n.risk,n_event=sk$n.event,n_censor=sk$n.censor)
  km_table <- km_table[km_table$time<=36,,drop=FALSE]
  riskset <- ta_bind(lapply(levels(dd$group),function(g) data.frame(group=g,time=c(0,6,12,24,36),n_risk=vapply(c(0,6,12,24,36),function(t) sum(dd$group==g & dd$Death_Followup_months>=t),0L))))
  groups <- ta_bind(lapply(c("FIXED146","ROC_ORIGINAL"),function(branch) {
    cutoff <- if(branch=="FIXED146") ctx$cfg$fixed_cutoff else ctx$roc
    ta_bind(lapply(c("LOW","HIGH"),function(g) {
      gd <- dd[(dd$AST_ALT>cutoff)==(g=="HIGH"),,drop=FALSE]
      sf <- survival::survfit(survival::Surv(Death_Followup_months,All_Cause_Death)~1,data=gd,conf.type="log",conf.int=.95)
      st <- summary(sf,times=24)
      has <- nrow(gd)>0 && max(gd$Death_Followup_months)>=24 && length(st$surv)==1L
      value <- if(has) 1-st$surv else NA_real_
      low <- if(has) 1-st$upper else NA_real_; high <- if(has) 1-st$lower else NA_real_
      row <- intervals$branch==branch & intervals$scope=="FULL2124" & intervals$metric==paste0("Risk24_",g)
      ta_require(sum(row)==1L && isTRUE(all.equal(intervals$value[row],value,tolerance=1e-12)),"KM24_POINT_MISMATCH")
      intervals$lower[row] <<- low; intervals$upper[row] <<- high
      intervals$interval_method[row] <<- "GREENWOOD_LOG_SURVIVAL_COMPLEMENT"
      intervals$interval_status[row] <<- if(has) "POINTWISE_GREENWOOD_LOG" else "NOT_PUBLISHED"
      intervals$zero_width[row] <<- has && is.finite(low) && is.finite(high) && low==high
      data.frame(branch=branch,group=g,n=nrow(gd),events=sum(gd$All_Cause_Death),
        crude_death_proportion=mean(gd$All_Cause_Death),
        deaths_by24=sum(gd$All_Cause_Death==1 & gd$Death_Followup_months<=24),
        known_alive24=sum(gd$Death_Followup_months>24),
        censored_by24=sum(gd$All_Cause_Death==0 & gd$Death_Followup_months<=24),
        risk24=value,lower=low,upper=high,interval_method="GREENWOOD_LOG_SURVIVAL_COMPLEMENT")
    }))
  }))
  tables <- list(classification=intervals,threshold_points=point$thresholds,threshold_distribution=threshold_summary,
    support=point$support,bootstrap_failure_counts=reason_counts,cox=ta_bind(summaries),ph=ta_bind(ph),complete_case=complete_case,
    km=km_table,riskset=riskset,groups=groups)
  dir.create(file.path(root,"tables"),showWarnings=FALSE)
  for (name in names(tables)) ta_csv(tables[[name]],file.path(root,"tables",paste0(name,".csv")))
  acceptance <- list(identity=req$identity,status="COMPLETED",direct_consumer_completed=TRUE,
    n=prepared$n,events=prepared$events,logical_cox_fits=prepared$logical_fit_n,unique_cox_fits=length(coefs),
    bootstrap_completed=length(boot),original_cutoff=prepared$original_cutoff,fixed_reclassification_n=prepared$fixed_reclassification_n,
    table_rows=lapply(tables,nrow),numerical_failures=0,new_mice_chains=0,new_ml_fits=0,plotting=FALSE,
    limitations=c("POST_HOC_EXPLORATORY","FIXED146_NOT_INDEPENDENTLY_VALIDATED","OBSERVED_CENTERS_CONDITIONAL",
      "VALID_SUBSET_INTERVALS_NOT_COVERAGE_VALIDATED","THRESHOLD_DISTRIBUTIONS_NOT_CLINICAL_CI"))
  # 下游实际回读全部汇总；不能用文件存在替代完成。
  for (name in names(tables)) {
    original <- tables[[name]]
    classes <- vapply(original,function(x) if(is.numeric(x)) "numeric" else if(is.logical(x)) "logical" else "character", "")
    consumed <- read.csv(file.path(root,"tables",paste0(name,".csv")),check.names=FALSE,colClasses=classes)
    ta_require(identical(names(consumed),names(original)) && nrow(consumed)==nrow(original),"TABLE_CONSUMER_SCHEMA_MISMATCH")
    for(col in names(original)) {
      a<-original[[col]]; z<-consumed[[col]]
      if(is.numeric(a)) ta_require(isTRUE(all.equal(as.numeric(a),as.numeric(z),tolerance=1e-12,check.attributes=FALSE)),"TABLE_CONSUMER_NUMERIC_MISMATCH")
      else ta_require(identical(as.character(a),as.character(z)),"TABLE_CONSUMER_LABEL_MISMATCH")
    }
  }
  jsonlite::write_json(acceptance,file.path(root,"acceptance.json.part"),auto_unbox=TRUE,pretty=TRUE,na="null",digits=NA)
  ta_require(file.rename(file.path(root,"acceptance.json.part"),file.path(root,"acceptance.json")),"ACCEPTANCE_PUBLICATION_FAILED")
  invisible(acceptance)
}

ta_main <- function(args) {
  # 加载必要的序列化包；正式内核只由固定请求调用。
  ta_require(requireNamespace("jsonlite",quietly=TRUE) && requireNamespace("digest",quietly=TRUE),"SERIALIZATION_PACKAGES_MISSING")
  req <- jsonlite::read_json(args[[1]],simplifyVector=FALSE)
  ctx <- ta_context(req); dir.create(file.path(req$output,"numerical"),showWarnings=FALSE,recursive=TRUE)
  if (req$mode == "prepare") {
    value <- ta_prepare(ctx,req); ta_atomic(value,file.path(req$output,"prepared.rds"))
    ta_atomic(list(identity=req$identity,roc=ctx$roc,d=ctx$d[,c("Patient_ID","Center","AST_ALT","Death_Followup_months","All_Cause_Death")]),file.path(req$output,"observation.rds"))
    jsonlite::write_json(value,file.path(req$output,"prepared.json.part"),auto_unbox=TRUE,pretty=TRUE,digits=NA)
    ta_require(file.rename(file.path(req$output,"prepared.json.part"),file.path(req$output,"prepared.json")),"PREPARE_PUBLICATION_FAILED")
  } else if (req$mode == "point") {
    result <- ta_evaluate(ctx,rep(1L,nrow(ctx$d)))
    ta_atomic(list(identity=req$identity,id="point",status="COMPLETED",result=result),file.path(req$output,"point.rds"))
  } else if (req$mode == "bootstrap") {
    for (b in unlist(req$indices)) {
      id <- sprintf("B%04d",b); path <- file.path(req$output,"numerical",paste0(id,".rds"))
      if (file.exists(path)) {ta_check_record(readRDS(path),req$identity,id); next}
      draw <- ta_boot_counts(ctx$d,ctx$cfg,b); result <- ta_evaluate(ctx,draw$m,b)
      result$rng_start <- draw$stream; result$multiplicity_sha256 <- digest::digest(draw$m,algo="sha256")
      ta_atomic(list(identity=req$identity,id=id,status="COMPLETED",result=result),path)
    }
  } else if (req$mode == "cox") {
    spec <- req$spec; id <- spec$task; path <- file.path(req$output,"numerical",paste0(id,".rds"))
    if (file.exists(path)) ta_check_record(readRDS(path),req$identity,id) else {
      marker <- jsonlite::read_json(paste0(path,".started"))
      ta_require(isTRUE(req$fit_authorized) && identical(marker$identity,req$identity) &&
        identical(marker$id,id) && identical(marker$attempt_id,req$attempt_id),"COX_FIT_NOT_AUTHORIZED")
      result <- ta_fit(ctx,spec)
      ta_atomic(list(identity=req$identity,id=id,status="COMPLETED",result=result),path)
    }
  } else if (req$mode == "reduce") ta_reduce(ctx,req) else stop("UNKNOWN_THRESHOLD_MODE")
}
if (sys.nframe() == 0L) ta_main(commandArgs(trailingOnly=TRUE))
