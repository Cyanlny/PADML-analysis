#!/usr/bin/env Rscript
# Numerical-only port of the approved P3B evaluator: no execution controller.
suppressPackageStartupMessages({library(jsonlite); library(survival)})

require_value <- function(ok, reason) {
  if (!isTRUE(ok)) stop(reason, call. = FALSE)
}

support_reasons <- function(support) {
  reasons <- unlist(support$reasons, use.names = FALSE)
  if (support$n_events < 20L) reasons <- c(reasons, "CASES_BELOW_20")
  if (support$n_non_events < 20L) reasons <- c(reasons, "CONTROLS_BELOW_20")
  reasons
}

discriminate <- function(survival, time, event, ipcw, centers, censoring_steps, horizon = 24L) {
  require_value(length(horizon) == 1L && is.numeric(horizon) && horizon %in% c(6L, 12L, 24L, 36L),
    "F4_DISCRIMINATION_HORIZON_INVALID")
  primary_index <- match(horizon, c(6L, 12L, 24L, 36L))
  centers <- unlist(centers, use.names = FALSE)
  require_value(length(centers) == length(time) && is.list(censoring_steps) &&
    setequal(unique(centers), names(censoring_steps)), "F4_UNO_CENSORING_CONTEXT_INVALID")
  paths <- lapply(censoring_steps, function(path) {
    require_value(length(path) == 2L, "F4_UNO_CENSORING_CONTEXT_INVALID")
    points <- unlist(path[[1L]], use.names = FALSE)
    values <- unlist(path[[2L]], use.names = FALSE)
    require_value(length(points) == length(values) && length(points) > 0L &&
      all(is.finite(points)) && all(points >= 0) && all(diff(points) > 0) &&
      all(is.finite(values)) && all(values >= 0 & values <= 1) &&
      all(diff(values) <= 0), "F4_UNO_CENSORING_CONTEXT_INVALID")
    list(points, values)
  })
  score <- 1 - survival[, primary_index]
  auc <- list()
  for (index in seq_len(4L)) {
    support <- ipcw[[index]]
    reasons <- support_reasons(support)
    value <- NULL
    if (identical(support$status, "ESTIMABLE") && !length(reasons)) {
      cases <- which(event == 1L & time <= support$horizon)
      controls <- which(time > support$horizon)
      weight <- unlist(support$weights, use.names = FALSE)
      risk <- 1 - survival[, index]
      numerator <- denominator <- 0
      for (i in cases) {
        pair_weight <- weight[i] * weight[controls]
        comparison <- as.numeric(risk[i] > risk[controls]) +
          0.5 * as.numeric(risk[i] == risk[controls])
        numerator <- numerator + sum(pair_weight * comparison)
        denominator <- denominator + sum(pair_weight)
      }
      require_value(is.finite(denominator) && denominator > 0,
        "F4_AUC_PAIR_WEIGHT_INVALID")
      value <- numerator / denominator
      require_value(is.finite(value) && value >= 0 && value <= 1,
        "F4_AUC_NUMERICAL_FAILURE")
    }
    auc[[as.character(support$horizon)]] <- list(
      status = if (is.null(value)) "NOT_ESTIMABLE" else "ESTIMABLE",
      reasons = as.list(reasons), value = value)
  }
  support <- ipcw[[primary_index]]
  reasons <- support_reasons(support)
  uno <- NULL
  if (identical(support$status, "ESTIMABLE") && !length(reasons)) {
    # Strict T_j > T_i pairs require G_i(T_i-) * G_j(T_i), not G_i(T_i-)^2.
    # Reuse the shared center KM steps; never materialize a patient-pair matrix.
    weight <- unlist(support$weights, use.names = FALSE)
    numerator <- denominator <- 0
    for (i in which(event == 1L & time <= horizon)) {
      controls <- which(time > time[i])
      comparison <- as.numeric(score[i] > score[controls]) +
        0.5 * as.numeric(score[i] == score[controls])
      right_g <- vapply(paths, function(path) {
        position <- findInterval(time[i], path[[1L]])
        if (position == 0L) 1 else path[[2L]][[position]]
      }, numeric(1L))
      control_g <- right_g[centers[controls]]
      require_value(all(is.finite(control_g)) && all(control_g > 0 & control_g <= 1),
        "F4_UNO_PAIR_WEIGHT_INVALID")
      pair_weight <- weight[i] / control_g
      numerator <- numerator + sum(pair_weight * comparison)
      denominator <- denominator + sum(pair_weight)
    }
    require_value(is.finite(denominator) && denominator > 0,
      "F4_UNO_PAIR_WEIGHT_INVALID")
    uno <- numerator / denominator
    require_value(is.finite(uno) && uno >= 0 && uno <= 1, "F4_UNO_NUMERICAL_FAILURE")
  }
  harrell <- survival::concordance(survival::Surv(time, event) ~ score, reverse = TRUE)
  comparable <- sum(harrell$count[1:3])
  require_value(is.finite(comparable) && comparable >= 0, "F4_HARRELL_PAIR_COUNT_INVALID")
  hc <- if (comparable > 0) as.numeric(harrell$concordance) else NULL
  require_value(is.null(hc) || (is.finite(hc) && hc >= 0 && hc <= 1),
    "F4_HARRELL_NUMERICAL_FAILURE")
  result <- list(auc = auc, uno_c_24 = list(value = uno, reasons = as.list(reasons),
    status = if (is.null(uno)) "NOT_ESTIMABLE" else "ESTIMABLE"),
    harrell_c = list(value = hc, comparable_pairs = comparable,
      status = if (is.null(hc)) "NOT_ESTIMABLE" else "ESTIMABLE",
      reason = if (is.null(hc)) "NO_COMPARABLE_PAIRS" else NULL),
    risk_score_common = as.list(score))
  names(result)[names(result) == "uno_c_24"] <- paste0("uno_c_", horizon)
  result
}

evaluate_job <- function(job) {
  ids <- unlist(job$patient_ids, use.names = FALSE)
  survival <- do.call(rbind, lapply(job$survival, unlist, use.names = FALSE))
  require_value(length(ids) > 0L && !anyDuplicated(ids) &&
    identical(dim(survival), c(length(ids), 4L)) &&
    all(is.finite(survival)) && all(survival >= 0 & survival <= 1),
    paste0("F4_CALIBRATION_INPUT_INVALID:", job$label))
  time <- unlist(job$times, use.names = FALSE)
  event <- unlist(job$events, use.names = FALSE)
  require_value(length(time) == length(ids) && length(event) == length(ids) &&
    all(is.finite(time)) && all(time >= 0) && all(event %in% c(0L, 1L)),
    "F4_NATIVE_RESPONSE_INVALID")
  require_value(length(job$ipcw) == 4L, "F4_CALIBRATION_IPCW_GRID_INVALID")
  horizons <- c(6L, 12L, 24L, 36L)
  estimates <- list()
  errors <- error_weights <- numeric()
  for (index in seq_along(horizons)) {
    horizon <- horizons[[index]]
    support <- job$ipcw[[index]]
    require_value(identical(as.integer(support$horizon), horizon),
      "F4_CALIBRATION_HORIZON_INVALID")
    reasons <- support_reasons(support)
    if (!identical(support$status, "ESTIMABLE") || length(reasons)) {
      estimates[[as.character(horizon)]] <- list(status = "NOT_ESTIMABLE",
        reasons = as.list(reasons), citl = NULL, oe = NULL, slope = NULL,
        ici = NULL, e50 = NULL, e90 = NULL, curve = NULL, warnings = list())
      next
    }
    weight <- unlist(support$weights, use.names = FALSE)
    y <- 1 - unlist(support$truth, use.names = FALSE)
    require_value(length(weight) == length(ids) && length(y) == length(ids) &&
      all(is.finite(weight)) && all(weight >= 0) && all(y %in% c(0, 1)),
      "F4_CALIBRATION_WEIGHT_INVALID")
    # Epsilon is a registered calibration-link transform, not curve repair.
    risk_probability <- pmin(pmax(1 - survival[, index], 1e-6), 1 - 1e-6)
    linear_predictor <- qlogis(risk_probability)
    if (length(unique(linear_predictor)) < 2L) {
      estimates[[as.character(horizon)]] <- list(status = "NOT_ESTIMABLE",
        reasons = list("CONSTANT_RISK_CALIBRATION_NOT_IDENTIFIABLE"),
        citl = NULL, oe = NULL, slope = NULL, ici = NULL, e50 = NULL,
        e90 = NULL, curve = NULL, warnings = list())
      next
    }
    warnings <- character()
    values <- withCallingHandlers({
        intercept_fit <- glm(y ~ offset(linear_predictor),
          family = quasibinomial(), weights = weight)
        slope_fit <- glm(y ~ linear_predictor,
          family = quasibinomial(), weights = weight)
        require_value(intercept_fit$converged && slope_fit$converged &&
          all(is.finite(coef(intercept_fit))) && all(is.finite(coef(slope_fit))),
          "F4_CALIBRATION_GLM_NUMERICAL_FAILURE")
        smooth <- loess(y ~ risk_probability, weights = weight,
          span = 0.75, degree = 1L)
        calibrated <- as.numeric(predict(smooth,
          newdata = data.frame(risk_probability = risk_probability)))
        require_value(length(calibrated) == length(ids) &&
          all(is.finite(calibrated)),
          "F4_CALIBRATION_SMOOTHER_NUMERICAL_FAILURE")
        list(citl = unname(coef(intercept_fit)[[1L]]),
          oe = (sum(weight * y) / length(ids)) / mean(risk_probability),
          slope = unname(coef(slope_fit)[["linear_predictor"]]),
          calibrated = calibrated)
      }, warning = function(w) {
        warnings <<- c(warnings, conditionMessage(w))
        invokeRestart("muffleWarning")
      })
    require_value(all(is.finite(unlist(values[c("citl", "oe", "slope")]))),
      "F4_CALIBRATION_NONFINITE_ESTIMATE")
    used <- weight > 0
    horizon_errors <- abs(values$calibrated[used] - risk_probability[used])
    horizon_weights <- weight[used]
    require_value(length(horizon_errors) > 0L && sum(horizon_weights) > 0,
      "F4_CALIBRATION_ERROR_WEIGHT_INVALID")
    normalized <- horizon_weights / sum(horizon_weights)
    error_order <- order(horizon_errors)
    cumulative <- cumsum(normalized[error_order])
    horizon_ici <- sum(horizon_errors * normalized)
    horizon_e50 <- horizon_errors[error_order][which(cumulative >= 0.50)[[1L]]]
    horizon_e90 <- horizon_errors[error_order][which(cumulative >= 0.90)[[1L]]]
    require_value(all(is.finite(c(horizon_ici, horizon_e50, horizon_e90))),
      "F4_CALIBRATION_ERROR_SUMMARY_NONFINITE")
    errors <- c(errors, horizon_errors)
    error_weights <- c(error_weights, horizon_weights)
    estimates[[as.character(horizon)]] <- list(status = "ESTIMABLE", reasons = list(),
      citl = values$citl, oe = values$oe, slope = values$slope,
      ici = horizon_ici, e50 = horizon_e50, e90 = horizon_e90,
      smoother = list(kind = "UNBOUNDED_GAUSSIAN_LOCAL_LINEAR_LOESS",
        below_zero_count = sum(values$calibrated < 0),
        above_one_count = sum(values$calibrated > 1),
        positive_weight_count = sum(used),
        positive_weight_below_zero_count = sum(used & values$calibrated < 0),
        positive_weight_above_one_count = sum(used & values$calibrated > 1),
        minimum = min(values$calibrated), maximum = max(values$calibrated),
        clipping = FALSE),
      curve = list(patient_ids = as.list(ids),
        calibration_risk = as.list(risk_probability),
        calibrated_risk = as.list(values$calibrated)), warnings = as.list(warnings))
  }
  aggregate <- list(status = "NOT_ESTIMABLE", ici = NULL, e50 = NULL, e90 = NULL,
    interpretation = "POOLED_ACROSS_HORIZONS_DESCRIPTIVE_ONLY",
    estimable_horizons = as.list(as.integer(names(estimates)[vapply(estimates,
      function(x) identical(x$status, "ESTIMABLE"), logical(1))])))
  if (length(aggregate$estimable_horizons) == length(horizons) &&
      length(errors) && sum(error_weights) > 0) {
    normalized <- error_weights / sum(error_weights)
    order <- order(errors)
    cumulative <- cumsum(normalized[order])
    aggregate$status <- "ESTIMABLE"
    aggregate$ici <- sum(errors * normalized)
    aggregate$e50 <- errors[order][which(cumulative >= 0.50)[[1L]]]
    aggregate$e90 <- errors[order][which(cumulative >= 0.90)[[1L]]]
  }
  list(label = job$label, horizons = estimates, aggregate = aggregate,
    discrimination = discriminate(survival, time, event, job$ipcw,
      job$centers, job$censoring_steps,
      if (is.null(job$primary_report_horizon_months)) 24L else job$primary_report_horizon_months))
}

# BEGIN NESTED_OPTIMISM: fixed predictions, no model fitting.
evaluate_optimism_job <- function(job) {
  ids <- unlist(job$patient_ids, use.names = FALSE)
  prediction <- do.call(rbind, lapply(job$survival, unlist, use.names = FALSE))
  time <- unlist(job$times, use.names = FALSE)
  event <- unlist(job$events, use.names = FALSE)
  centers <- unlist(job$centers, use.names = FALSE)
  horizons <- c(6L, 12L, 24L, 36L)
  require_value(length(job$primary_report_horizon_months) == 1L &&
    is.numeric(job$primary_report_horizon_months) && job$primary_report_horizon_months %in% horizons,
    "F4_DISCRIMINATION_HORIZON_INVALID")
  risk_h <- as.integer(job$primary_report_horizon_months)
  require_value(length(ids) > 0L && !anyDuplicated(ids) &&
    identical(dim(prediction), c(length(ids), 4L)) &&
    all(is.finite(prediction)) && all(prediction >= 0 & prediction <= 1) &&
    length(time) == length(ids) && all(is.finite(time)) && all(time >= 0) &&
    length(event) == length(ids) && all(event %in% c(0L, 1L)) &&
    length(centers) == length(ids) && length(job$ipcw) == 4L &&
    length(risk_h) == 1L && risk_h %in% horizons &&
    setequal(unique(centers), names(job$censoring_steps)), "F45_OPTIMISM_NATIVE_INPUT_INVALID")
  paths <- lapply(job$censoring_steps, function(path) {
    require_value(length(path) == 2L, "F4_UNO_CENSORING_CONTEXT_INVALID")
    points <- unlist(path[[1L]], use.names = FALSE)
    values <- unlist(path[[2L]], use.names = FALSE)
    require_value(length(points) == length(values) && length(points) > 0L &&
      all(is.finite(points)) && all(points >= 0) && all(diff(points) > 0) &&
      all(is.finite(values)) && all(values >= 0 & values <= 1) &&
      all(diff(values) <= 0), "F4_UNO_CENSORING_CONTEXT_INVALID")
    list(points, values)
  })
  score <- 1 - prediction[, match(risk_h, horizons)]
  rows <- list()
  for (index in seq_along(horizons)) {
    cutoff <- horizons[[index]]
    support <- job$ipcw[[index]]
    require_value(identical(as.integer(support$horizon), cutoff), "F45_OPTIMISM_TIME_DRIFT")
    reasons <- support_reasons(support)
    uno <- slope <- NULL
    slope_reasons <- reasons
    warnings <- character()
    if (identical(support$status, "ESTIMABLE") && !length(reasons)) {
      weight <- unlist(support$weights, use.names = FALSE)
      require_value(length(weight) == length(ids) && all(is.finite(weight)) && all(weight >= 0),
        "F4_CALIBRATION_WEIGHT_INVALID")
      # Original Uno pair order and arithmetic; risk_h stays fixed as cutoff changes.
      numerator <- denominator <- 0
      for (i in which(event == 1L & time <= cutoff)) {
        controls <- which(time > time[i])
        comparison <- as.numeric(score[i] > score[controls]) +
          0.5 * as.numeric(score[i] == score[controls])
        right_g <- vapply(paths, function(path) {
          position <- findInterval(time[i], path[[1L]])
          if (position == 0L) 1 else path[[2L]][[position]]
        }, numeric(1L))
        control_g <- right_g[centers[controls]]
        require_value(all(is.finite(control_g)) && all(control_g > 0 & control_g <= 1),
          "F4_UNO_PAIR_WEIGHT_INVALID")
        pair_weight <- weight[i] / control_g
        numerator <- numerator + sum(pair_weight * comparison)
        denominator <- denominator + sum(pair_weight)
      }
      require_value(is.finite(denominator) && denominator > 0, "F4_UNO_PAIR_WEIGHT_INVALID")
      uno <- numerator / denominator
      require_value(is.finite(uno) && uno >= 0 && uno <= 1, "F4_UNO_NUMERICAL_FAILURE")
      if (isTRUE(job$include_slope)) {
        y <- 1 - unlist(support$truth, use.names = FALSE)
        require_value(length(y) == length(ids) && all(y %in% c(0, 1)), "F4_CALIBRATION_WEIGHT_INVALID")
        linear_predictor <- qlogis(pmin(pmax(1 - prediction[, index], 1e-6), 1 - 1e-6))
        if (length(unique(linear_predictor)) < 2L) {
          slope_reasons <- "CONSTANT_RISK_CALIBRATION_NOT_IDENTIFIABLE"
        } else {
          fit <- withCallingHandlers(glm(y ~ linear_predictor,
            family = quasibinomial(), weights = weight), warning = function(w) {
              warnings <<- c(warnings, conditionMessage(w)); invokeRestart("muffleWarning")
            })
          require_value(fit$converged && all(is.finite(coef(fit))), "F4_CALIBRATION_GLM_NUMERICAL_FAILURE")
          slope <- unname(coef(fit)[["linear_predictor"]])
        }
      }
    }
    rows[[as.character(cutoff)]] <- list(
      uno_c = list(value = uno, reasons = as.list(reasons),
        status = if (is.null(uno)) "NOT_ESTIMABLE" else "ESTIMABLE"),
      calibration_slope = list(value = slope, reasons = as.list(slope_reasons),
        status = if (!isTRUE(job$include_slope)) "NOT_REQUESTED" else
          if (is.null(slope)) "NOT_ESTIMABLE" else "ESTIMABLE", warnings = as.list(warnings)))
  }
  list(label = job$label, risk_horizon = risk_h, horizons = rows)
}
# END NESTED_OPTIMISM

if (sys.nframe() == 0L) {
  preserve_failure <- function(error) {
    if (!file.exists("native-failure.rda")) {
      writeLines(conditionMessage(error), "native-error.txt")
      dump.frames("native-failure", to.file = TRUE, include.GlobalEnv = TRUE)
      writeLines(capture.output(sessionInfo()), "native-session.txt")
    }
  }
  withCallingHandlers({
    input <- fromJSON(file("stdin"), simplifyVector = FALSE)
    result <- lapply(input$jobs, function(job) {
      tryCatch(withCallingHandlers(if (isTRUE(job$nested_optimism)) evaluate_optimism_job(job) else evaluate_job(job), error = preserve_failure),
        error = function(e) {
          stop(paste0(job$label, ":", conditionMessage(e)), call. = FALSE)
        })
    })
    cat(toJSON(list(results = result), auto_unbox = TRUE, null = "null", digits = NA))
  }, error = preserve_failure)
}
