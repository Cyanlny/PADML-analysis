#!/usr/bin/env Rscript

suppressPackageStartupMessages({ library(mice); library(jsonlite) })
args <- commandArgs(trailingOnly = TRUE)
if (!length(args) || !args[[1L]] %in% c("FIT", "REPLAY", "GATHER", "CHAIN") ||
    length(args) != switch(args[[1L]], FIT = 2L, REPLAY = 3L, GATHER = 2L, CHAIN = 4L)) {
  stop("F5_MICE_NATIVE_ARGUMENT_INVALID", call. = FALSE)
}
action <- args[[1L]]
spec <- fromJSON(args[[2L]], simplifyVector = FALSE)
root <- dirname(normalizePath(args[[2L]], mustWork = TRUE))
options(error = function() {
  dump.frames(file.path(root, "native-failure"), to.file = TRUE,
              include.GlobalEnv = TRUE)
  quit(save = "no", status = 1L, runLast = FALSE)
})
script <- grep("^--file=", commandArgs(), value = TRUE)
stopifnot(length(script) == 1L)
kernel <- file.path(dirname(gsub("~+~", " ", sub("^--file=", "", script), fixed = TRUE)), "f1_nested_mice.R")
# Import the existing scientific functions, never the F1 entry point/workbook.
required <- c("fail", "exact_names", "chars", "ints", "numeric_strict",
              "mapped_factor", "egfr", "nelson_aalen", "factor_support_ok",
              "parse_levels", "cast_covariates", "formula_values", "formula_prefill", "formula_derived", "relationship_diagnostics",
              "active_terminal_convergence", "chain_convergence",
              "addressed_mice_chain", "native_chains", "impute_view", "native_phase_view")
definitions <- Filter(function(expression) {
  is.call(expression) && identical(expression[[1L]], as.name("<-")) &&
    is.symbol(expression[[2L]]) && as.character(expression[[2L]]) %in% required &&
    is.call(expression[[3L]]) && identical(expression[[3L]][[1L]], as.name("function"))
}, as.list(parse(kernel)))
stopifnot(length(definitions) == length(required),
          setequal(vapply(definitions, function(x) as.character(x[[2L]]), character(1)), required))
for (definition in definitions) eval(definition)
# Only prospective downstream views request an addressed substream. Ordinary
# F1/F5 calls retain their original seed-resetting chain body and objects.
chain_rng_substream <- spec$chain_rng_substream
if (!is.null(chain_rng_substream)) {
  if (length(chain_rng_substream) != 1L || !is.numeric(chain_rng_substream) ||
      !is.finite(chain_rng_substream) || chain_rng_substream < 0 ||
      chain_rng_substream > 216L ||
      chain_rng_substream != as.integer(chain_rng_substream)) {
    fail("F5_MICE_SUBSTREAM_INVALID")
  }
  chain_rng_substream <- as.integer(chain_rng_substream)
  spec$chain_rng_substream <- NULL
}
nested_aar_source <- spec$nested_aar_source
if (!is.null(nested_aar_source)) {
  if (!is.list(nested_aar_source) ||
      !identical(nested_aar_source$program_id, "PADML_F45_REBUILD_20260925") ||
      !is.character(nested_aar_source$estimand) || length(nested_aar_source$estimand) != 1L ||
      !nested_aar_source$estimand %in% c("A12_WITHOUT_AST_ALT_TOTAL",
        "OUTER_SELECTED_FAMILY_NO_AAR_REDEVELOPMENT")) fail("F5_MICE_NESTED_AAR_SOURCE_INVALID")
  spec$nested_aar_source <- NULL
}
authority <- fromJSON(as.character(spec$authority_path), simplifyVector = FALSE)
native <- if (identical(action, "REPLAY")) args[[3L]] else file.path(root, "native")
if (!identical(action, "REPLAY")) {
  if (!dir.exists(native)) dir.create(native, mode = "0700")
}
# The shared iterator persists completed chains; only missing chains fit.
if (action %in% c("GATHER", "CHAIN")) {
  result <- native_phase_view(spec, authority, native, action,
    if (action == "CHAIN") as.integer(args[[3L]]) else NULL,
    if (action == "CHAIN") as.integer(args[[4L]]) else NULL,
    rng_substream = chain_rng_substream, aar_source = nested_aar_source)
  if (identical(result$status, "VIEW_OUTPUT_READY"))
    writeLines(capture.output(sessionInfo()), file.path(root, "native-session.txt"))
  cat("PADML_MICE_PHASE_RESULT=", toJSON(result, auto_unbox = TRUE, null = "null", digits = NA), "\n", sep = "")
  quit(save = "no", status = 0L)
}
formals(impute_view)$chain_apply <- quote(native_chains)
impute_view(spec, authority)
writeLines(capture.output(sessionInfo()), file.path(root, "native-session.txt"))
