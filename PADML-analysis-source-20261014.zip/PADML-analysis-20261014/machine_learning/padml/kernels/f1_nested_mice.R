#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(digest)
  library(jsonlite)
  library(mice)
  library(readxl)
})

fail <- function(code) stop(code, call. = FALSE)
exact_names <- function(value, expected, code) {
  if (!identical(sort(names(value)), sort(expected))) fail(code)
}
chars <- function(value) as.character(unlist(value, use.names = FALSE))
ints <- function(value) as.integer(unlist(value, use.names = FALSE))

numeric_strict <- function(value, name) {
  blank <- is.na(value) | trimws(as.character(value)) == ""
  result <- suppressWarnings(as.numeric(value))
  if (any(!blank & !is.finite(result))) fail(paste0("F1_NONNUMERIC_COLUMN:", name))
  result[blank] <- NA_real_
  result
}

mapped_factor <- function(value, source, groups, labels, levels) {
  x <- numeric_strict(value, source)
  answer <- rep(NA_character_, length(x))
  for (index in seq_along(groups)) answer[x %in% groups[[index]]] <- labels[[index]]
  if (any(!is.na(x) & is.na(answer))) fail(paste0("F1_DERIVED_MAPPING_UNKNOWN:", source))
  factor(answer, levels = levels)
}

egfr <- function(creatinine, age, sex) {
  scr <- creatinine / 88.4
  female <- as.numeric(sex == 1)
  kappa <- ifelse(female == 1, 0.7, 0.9)
  alpha <- ifelse(female == 1, -0.241, -0.302)
  142 * pmin(scr / kappa, 1)^alpha * pmax(scr / kappa, 1)^(-1.200) *
    0.9938^age * 1.012^female
}

nelson_aalen <- function(time, event) {
  if (any(!is.finite(time)) || any(time <= 0) || any(!event %in% c(0, 1))) {
    fail("F1_ANALYSIS_RESPONSE_DOMAIN_INVALID")
  }
  event_times <- sort(unique(time[event == 1]))
  increments <- vapply(event_times, function(t) {
    sum(event == 1 & time == t) / sum(time >= t)
  }, numeric(1))
  cumulative <- cumsum(increments)
  vapply(time, function(t) {
    index <- which(event_times <= t)
    if (length(index)) cumulative[max(index)] else 0
  }, numeric(1))
}

factor_support_ok <- function(x, y, training, min_n = 5L) {
  if (!is.factor(x) && !is.character(x)) return(TRUE)
  levels_all <- if (is.factor(x)) levels(x) else sort(unique(as.character(x[training & !is.na(x)])))
  counts <- table(factor(as.character(x[training & !is.na(y)]), levels = levels_all))
  length(counts) >= 2L && all(counts >= min_n)
}

parse_levels <- function(contract, variable) {
  fields <- trimws(strsplit(as.character(contract), ";", fixed = TRUE)[[1L]])
  level_fields <- fields[startsWith(fields, "levels=")]
  if (length(level_fields) != 1L) fail(paste0("F1_CATEGORICAL_CONTRACT_INVALID:", variable))
  levels <- trimws(strsplit(sub("^levels=", "", level_fields), "\\|", perl = TRUE)[[1L]])
  if (!length(levels) || any(levels == "") || anyDuplicated(levels)) {
    fail(paste0("F1_CATEGORICAL_CONTRACT_INVALID:", variable))
  }
  levels
}

prepare_workbook <- function(spec, authority) {
  fresh <- identical(spec$fresh_data, TRUE)
  if (!is.null(spec$fresh_data) && !fresh) fail("F1_RAW_PROFILE_INVALID")
  spec$fresh_data <- NULL
  exact_names(
    spec,
    c("authority_path", "mode", "output_dir", "workbook_path"),
    "F1_PREPARE_SPEC_KEYS_INVALID"
  )
  data <- as.data.frame(
    readxl::read_excel(as.character(spec$workbook_path), sheet = "Analysis_Data", col_types = "text"),
    check.names = FALSE,
    stringsAsFactors = FALSE
  )
  if ((!fresh && (nrow(data) != 2247L || ncol(data) != 195L)) ||
      nrow(data) == 0L || anyDuplicated(names(data))) {
    fail("F1_WORKBOOK_SHAPE_INVALID")
  }
  needed <- c("Patient_ID", "Center", "AST", "ALT", "AST_ALT", "Creatinine", "Age", "Sex",
              "Rutherford", "HTN", "HF_NYHA", "CKD_Stage", "Anemia", "Prior_LE_Surgery",
              "Anesthesia", "Surgery_Type", "All_Cause_Death", "Death_Followup_months")
  if (!all(needed %in% names(data))) fail("F1_WORKBOOK_REQUIRED_COLUMNS_MISSING")
  ast <- numeric_strict(data$AST, "AST")
  alt <- numeric_strict(data$ALT, "ALT")
  ratio <- numeric_strict(data$AST_ALT, "AST_ALT")
  cohort <- is.finite(ast) & ast > 0 & is.finite(alt) & alt > 0 &
    is.finite(ratio) & abs(ratio - ast / alt) <= 1e-8
  if (!any(cohort) || (!fresh && sum(cohort) != 2124L)) fail("F1_COHORT_DENOMINATOR_INVALID")
  data <- data[cohort, , drop = FALSE]
  ast <- ast[cohort]
  alt <- alt[cohort]
  ids <- trimws(as.character(data$Patient_ID))
  center <- numeric_strict(data$Center, "Center")
  event <- numeric_strict(data$All_Cause_Death, "All_Cause_Death")
  followup <- numeric_strict(data$Death_Followup_months, "Death_Followup_months")
  if (any(ids == "" | is.na(ids)) || anyDuplicated(ids) ||
      any(!center %in% c(36, 38, 39, 48, 52, 54, 55)) ||
      any(!event %in% c(0, 1)) || any(!is.finite(followup)) || any(followup <= 0)) {
    fail("F1_COHORT_IDENTITY_INVALID")
  }
  mice_authority <- authority$science$mice
  handoff <- chars(mice_authority$private_handoff$columns)
  if (length(handoff) != 63L || anyDuplicated(handoff) ||
      any(c("All_Cause_Death", "Death_Followup_months", "event", "nelson_aalen") %in% handoff)) {
    fail("F1_HANDOFF_COLUMN_AUTHORITY_INVALID")
  }
  prepared <- list()
  prepared$Patient_ID <- ids
  prepared$Center <- as.integer(center)
  prepared$AST <- ast
  prepared$ALT <- alt
  prepared$AST_ALT <- ast / alt
  prepared$eGFR_calc <- egfr(
    numeric_strict(data$Creatinine, "Creatinine"),
    numeric_strict(data$Age, "Age"),
    numeric_strict(data$Sex, "Sex")
  )
  prepared$Rutherford_cat <- mapped_factor(
    data$Rutherford, "Rutherford", list(0:2, 3:4, 5:6),
    c("Grade 0-2", "Grade 3-4", "Grade 5-6"),
    c("Grade 0-2", "Grade 3-4", "Grade 5-6")
  )
  prepared$HTN_bin <- as.integer(numeric_strict(data$HTN, "HTN") > 0)
  prepared$HF_NYHA_bin <- mapped_factor(
    data$HF_NYHA, "HF_NYHA", list(0, 1:5), c("No", "Yes"), c("No", "Yes")
  )
  prepared$CKD_bin <- as.integer(numeric_strict(data$CKD_Stage, "CKD_Stage") > 0)
  prepared$Anemia <- as.integer(numeric_strict(data$Anemia, "Anemia") > 0)
  prepared$Hyperhcy <- as.integer(numeric_strict(data$Hyperhcy, "Hyperhcy") > 0)
  prepared$Prior_LE_Surgery_cat <- mapped_factor(
    data$Prior_LE_Surgery, "Prior_LE_Surgery", list(0, 1:4, 6, c(5, 7)),
    c("None", "Procedure", "Amputation", "Other"),
    c("None", "Procedure", "Amputation", "Other")
  )
  prepared$Anesthesia_cat <- mapped_factor(
    data$Anesthesia, "Anesthesia", list(0, 1, 2, 3),
    c("None", "Local", "Nerve block", "General"),
    c("None", "Local", "Nerve block", "General")
  )
  prepared$Surgery_Type_cat <- mapped_factor(
    data$Surgery_Type, "Surgery_Type", list(0, 1:4, 6, c(5, 7)),
    c("None", "Procedure", "Amputation", "Other"),
    c("None", "Procedure", "Amputation", "Other")
  )
  for (name in setdiff(handoff, names(prepared))) {
    if (!name %in% names(data)) fail(paste0("F1_HANDOFF_SOURCE_MISSING:", name))
    prepared[[name]] <- numeric_strict(data[[name]], name)
  }
  covariates <- as.data.frame(prepared[handoff], check.names = FALSE)
  response <- data.frame(
    Patient_ID = ids,
    All_Cause_Death = as.integer(event),
    Death_Followup_months = followup,
    check.names = FALSE
  )
  output_dir <- as.character(spec$output_dir)
  dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
  write.table(
    covariates, file.path(output_dir, "covariates.csv"), sep = ",", row.names = FALSE,
    col.names = TRUE, quote = TRUE, na = "", fileEncoding = "UTF-8", qmethod = "double"
  )
  write.table(
    response, file.path(output_dir, "response-seal.csv"), sep = ",", row.names = FALSE,
    col.names = TRUE, quote = TRUE, na = "", fileEncoding = "UTF-8", qmethod = "double"
  )
  write_json(
    list(
      schema_version = "1.0.0", kind = "PADML_F1_PREPARE_SUMMARY", status = "PASS",
      row_count = nrow(covariates), column_count = ncol(covariates),
      covariates_sha256 = digest(file.path(output_dir, "covariates.csv"), algo = "sha256", file = TRUE),
      response_seal_sha256 = digest(file.path(output_dir, "response-seal.csv"), algo = "sha256", file = TRUE),
      application_response_columns = 0L,
      relationship_diagnostics = relationship_diagnostics(data, ids, include_rows = TRUE)
    ),
    file.path(output_dir, "summary.json"), auto_unbox = TRUE, null = "null", na = "null"
  )
}

cast_covariates <- function(data, variable_path) {
  catalog <- read.csv(variable_path, colClasses = "character", check.names = FALSE, na.strings = character())
  if (nrow(catalog) != 53L || anyDuplicated(catalog$variable)) fail("F1_VARIABLE_CATALOG_INVALID")
  categorical <- catalog[catalog$type %in% c("binary", "ordered", "unordered"), , drop = FALSE]
  for (index in seq_len(nrow(categorical))) {
    name <- categorical$variable[[index]]
    if (!name %in% names(data)) next
    levels <- parse_levels(categorical$levels_or_coding[[index]], name)
    observed <- trimws(as.character(data[[name]]))
    observed[observed == ""] <- NA_character_
    if (any(!is.na(observed) & !observed %in% levels)) fail(paste0("F1_FACTOR_LEVEL_INVALID:", name))
    data[[name]] <- factor(observed, levels = levels, ordered = categorical$type[[index]] == "ordered")
  }
  for (name in setdiff(names(data), c("Patient_ID", categorical$variable))) {
    data[[name]] <- numeric_strict(data[[name]], name)
  }
  data
}

formula_values <- function(data, rule) {
  operands <- c(chars(rule$numerator), chars(rule$denominator))
  answer <- rep(NA_real_, nrow(data))
  if (!all(operands %in% names(data))) return(answer)
  good <- rep(TRUE, nrow(data))
  for (name in operands) good <- good & is.finite(data[[name]]) & data[[name]] > 0
  numerator <- denominator <- rep(1, nrow(data))
  for (name in chars(rule$numerator)) numerator <- numerator * data[[name]]
  for (name in chars(rule$denominator)) denominator <- denominator * data[[name]]
  value <- numerator / denominator
  if (!is.null(rule$power)) value <- value^as.numeric(rule$power)
  value <- value * as.numeric(rule$factor)
  if (!is.null(rule$divisor)) value <- value / as.numeric(rule$divisor)
  good <- good & is.finite(value) & value > 0
  answer[good] <- value[good]
  answer
}

formula_prefill <- function(data, authority) {
  source <- data
  policy <- authority$science$mice$formula_completion
  for (target in intersect(names(policy$rules), names(data))) {
    candidates <- lapply(policy$rules[[target]], function(rule) formula_values(source, rule))
    for (i in which(is.na(source[[target]]))) {
      values <- vapply(candidates, function(value) value[[i]], numeric(1))
      values <- values[is.finite(values)]
      if (length(values) && all(abs(values - values[[1L]]) <=
          as.numeric(policy$relative_agreement_tolerance) * pmax(abs(values), abs(values[[1L]])))) {
        data[[target]][[i]] <- values[[1L]]
      }
    }
  }
  data
}

formula_derived <- function(data, authority) {
  rules <- authority$science$mice$formula_completion$derived
  # MCHC consumes the just-derived HCT, on the declared percent scale.
  for (target in c("HCT", "MCH", "MCHC")) {
    if (target %in% names(data)) data[[target]] <- formula_values(data, rules[[target]])
  }
  data
}

relationship_diagnostics <- function(data, ids = NULL, include_rows = FALSE) {
  # No acceptance threshold or random draw: these relations remain unconfirmed
  # for this batch's units, sampling provenance and columnwise truncation.
  definitions <- list(WBC_NEUT_LYMPH_MONO_ESO_BASO = c("WBC","NEUT","LYMPH","MONO","ESO","BASO"),
                      TP_ALB_GLB = c("TP","ALB","GLB"))
  lapply(definitions, function(columns) {
    absent <- setdiff(columns, names(data))
    if (length(absent)) return(list(status="UNCONFIRMED_VARIABLE_UNAVAILABLE", missing_columns=as.list(absent),
      hard_constraint=FALSE, tolerance=NULL, adjusted_cells=0L))
    values <- vapply(columns, function(name) suppressWarnings(as.numeric(as.character(data[[name]]))), numeric(nrow(data)))
    total <- values[,1L]; parts <- values[,-1L,drop=FALSE]
    negative <- rowSums(is.finite(values) & values < 0) > 0
    observed <- rowSums(is.finite(parts))
    residual <- total-rowSums(replace(parts, !is.finite(parts), 0))
    complete <- is.finite(total) & observed == ncol(parts) & !negative
    impossible <- is.finite(total) & observed < ncol(parts) & !negative & residual < 0
    result <- list(status="UNCONFIRMED_DIAGNOSTIC_ONLY", hard_constraint=FALSE, tolerance=NULL,
      adjusted_cells=0L, complete_rows=sum(complete), incomplete_rows=sum(!complete),
      maximum_absolute_observed_residual=if (any(complete)) max(abs(residual[complete])) else NULL,
      observed_negative_rows=sum(negative), negative_remaining_sum_rows=sum(impossible),
      negative_remaining_sum_interpretation="NO_NONNEGATIVE_SOLUTION_IF_SUM_RELATION_APPLIES")
    if (include_rows) result$negative_remaining_sum_patient_ids <- as.list(as.character(ids[impossible]))
    result
  })
}

active_terminal_convergence <- function(diagnostics, active, final_iteration, terminal_window,
                                        require_finite = TRUE) {
  diagnostics <- diagnostics[
    as.character(diagnostics$vrb) %in% active &
      as.integer(diagnostics$.it) %in% seq.int(final_iteration - terminal_window + 1L, final_iteration),
    , drop = FALSE
  ]
  expected_n <- length(active) * terminal_window * 2L
  expected <- expand.grid(.it = seq.int(final_iteration - terminal_window + 1L, final_iteration),
                          vrb = active, parameter = c("mean", "sd"), stringsAsFactors = FALSE)
  keys <- function(x) paste(x$.it, x$vrb, x$parameter, sep = "/")
  if (nrow(diagnostics) != expected_n || anyDuplicated(keys(diagnostics)) ||
      !setequal(keys(diagnostics), keys(expected)) ||
      (require_finite && any(!is.finite(diagnostics$psrf) | !is.finite(diagnostics$ac)))) {
    fail("F1_MICE_CONVERGENCE_DIAGNOSTIC_DOMAIN_INVALID")
  }
  diagnostics
}

chain_convergence <- function(fits, active, final_iteration, terminal_window) {
  # Same mice 3.19.0 Rhat and cummean definitions, without copying complete mids.
  # Every retained coordinate uses its full 1:t history, including the AC terms.
  last <- seq.int(final_iteration - terminal_window + 1L, final_iteration)
  rows <- lapply(c("mean", "sd"), function(parameter) {
    do.call(rbind, lapply(active, function(variable) {
      traces <- vapply(fits, function(fit) {
        a <- if (parameter == "mean") fit$chainMean else fit$chainVar
        values <- as.numeric(a[variable, seq_len(final_iteration), 1L])
        if (parameter == "mean") values else sqrt(values)
      }, numeric(final_iteration))
      lag <- vapply(2:final_iteration, function(i) suppressWarnings(stats::cor(
        traces[i - 1L, ], traces[i, ], use = "pairwise.complete.obs")), numeric(1))
      ac <- c(NA_real_, dplyr::cummean(dplyr::coalesce(lag, 0))) + 0 * traces[, 1L]
      data.frame(.it = last, vrb = variable, parameter = parameter,
        psrf = vapply(last, function(i) rstan::Rhat(traces[seq_len(i), , drop = FALSE]), numeric(1)),
        ac = ac[last], stringsAsFactors = FALSE)
    }))
  })
  active_terminal_convergence(do.call(rbind, rows), active, final_iteration, terminal_window,
                             require_finite = FALSE)
}

addressed_mice_chain <- function(FUN, states) {
  changes <- integer(2L)
  project <- function(expression) {
    if (identical(expression, quote(set.seed(chain_seed)))) {
      changes[[1L]] <<- changes[[1L]] + 1L
      return(quote(assign(".Random.seed", initial_states[[as.character(chain_seed)]],
                          envir = .GlobalEnv)))
    }
    if (is.call(expression)) {
      if (identical(expression[[1L]], quote(mice::mice))) {
        if (!identical(expression[["seed"]], as.name("chain_seed"))) fail("F5_MICE_SUBSTREAM_SOURCE_INVALID")
        expression[["seed"]] <- quote(NA_integer_)
        changes[[2L]] <<- changes[[2L]] + 1L
      }
      for (index in seq_along(expression)) {
        if (!is.null(expression[[index]]) && !identical(expression[[index]], quote(expr = ))) {
          expression[[index]] <- project(expression[[index]])
        }
      }
    }
    expression
  }
  body(FUN) <- project(body(FUN))
  if (!identical(changes, c(1L, 1L))) fail("F5_MICE_SUBSTREAM_SOURCE_INVALID")
  context <- new.env(parent = environment(FUN))
  context$initial_states <- states
  environment(FUN) <- context
  FUN
}

native_chains <- function(chain_seeds, FUN, fit_chain = NULL, validate_fit = NULL,
                          native_dir = native, chain_action = action,
                          rng_substream = chain_rng_substream,
                          aar_source = nested_aar_source,
                          chain_indices = seq_along(chain_seeds)) {
  inputs <- environment(FUN)
  states <- NULL
  if (!is.null(rng_substream) && !isTRUE(inputs$passthrough)) {
    # Materialize every initial state before the first chain. The continuation
    # stays 30 -> 40 -> 50 using mids$lastSeedValue, with no restart or reseed.
    states <- setNames(lapply(chain_seeds, function(seed) {
      RNGkind("L'Ecuyer-CMRG", "Inversion", "Rejection")
      set.seed(seed)
      state <- .Random.seed
      for (unused in seq_len(rng_substream)) state <- parallel::nextRNGSubStream(state)
      state
    }), as.character(chain_seeds))
    FUN <- addressed_mice_chain(FUN, states)
  }
  if (is.null(fit_chain)) fit_chain <- FUN
  if (anyNA(chain_indices) || anyDuplicated(chain_indices) ||
      any(!chain_indices %in% seq_along(chain_seeds))) fail("F1_CHAIN_INDEX_INVALID")
  lapply(chain_indices, function(index) {
    path <- file.path(native_dir, sprintf("imp%02d.rds", index))
    new_chain <- identical(chain_action, "FIT") && !file.exists(path)
    # A continuation in this process already owns the exact validated mids.
    # The checkpoint remains the recovery source after a process interruption.
    prior <- if (!is.null(inputs$fits)) inputs$fits[[index]] else NULL
    fit <- if (new_chain) fit_chain(chain_seeds[[index]], NULL) else
      if (!is.null(prior)) prior else readRDS(path)
    if (new_chain && !is.null(aar_source)) {
      attr(fit, "padml_nested_aar_source") <- aar_source
    }
    if (new_chain && !is.null(states)) {
      attr(fit, "padml_rng") <- list(
        root_seed = as.integer(chain_seeds[[index]]), substream = rng_substream,
        initial_state = states[[index]], final_state = .Random.seed
      )
    }
    # Persist each completed chain before convergence/output checks can fail.
    publish <- function(fit) {
      pending <- paste0(path, ".partial")
      saveRDS(fit, pending, version = 3L)
      if (!file.rename(pending, path)) fail("F5_MICE_NATIVE_PUBLISH_FAILED")
    }
    if (new_chain) publish(fit)
    if (isTRUE(inputs$passthrough)) {
      if (!inherits(fit, "padml_complete_data_view") || fit$iteration != 0L || fit$m != 1L ||
          !identical(fit$data, inputs$mice_data) || !identical(fit$method, inputs$method) ||
          !identical(fit$predictorMatrix, inputs$matrix) || !identical(fit$ignore, inputs$ignore) ||
          !identical(fit$blots, inputs$blots) || !identical(fit$where, is.na(inputs$mice_data)) ||
          !identical(fit$slot_seed, as.integer(chain_seeds[[index]])) ||
          !identical(attr(fit, "padml_nested_aar_source"), aar_source) ||
          !is.null(fit$lastSeedValue) || !is.null(attr(fit, "padml_rng"))) {
        fail("F5_COMPLETE_DATA_INPUT_BINDING_INVALID")
      }
      if (!is.null(validate_fit)) validate_fit(fit, inputs)
      return(fit)
    }
    seed_matches <- if (is.null(states)) {
      identical(as.integer(fit$seed), as.integer(chain_seeds[[index]])) &&
        is.null(attr(fit, "padml_rng"))
    } else {
      identical(fit$seed, NA_integer_) &&
        identical(attr(fit, "padml_rng"), list(
          root_seed = as.integer(chain_seeds[[index]]), substream = rng_substream,
          initial_state = states[[index]], final_state = fit$lastSeedValue
        ))
    }
    if (!inherits(fit, "mids") || fit$m != 1L || !fit$iteration %in% c(30L, 40L, 50L) ||
        !identical(fit$data, inputs$mice_data) ||
        !identical(fit$method, inputs$method) ||
        !identical(fit$predictorMatrix, inputs$matrix) ||
        !identical(fit$ignore, inputs$ignore) ||
        !identical(fit$blots, inputs$blots) ||
        !identical(attr(fit, "padml_nested_aar_source"), aar_source) ||
        !seed_matches ||
        (!is.null(fit$loggedEvents) && nrow(fit$loggedEvents))) {
      fail("F5_MICE_NATIVE_INPUT_BINDING_INVALID")
    }
    if (!is.null(validate_fit)) validate_fit(fit, inputs)
    if (fit$iteration < inputs$checkpoint) {
      if (!identical(chain_action, "FIT")) fail("F5_MICE_REPLAY_INCOMPLETE_CHECKPOINT")
      fit <- fit_chain(chain_seeds[[index]], fit)
      if (!is.null(states)) attr(fit, "padml_rng") <- list(
        root_seed = as.integer(chain_seeds[[index]]), substream = rng_substream,
        initial_state = states[[index]], final_state = fit$lastSeedValue)
      if (!is.null(aar_source)) attr(fit, "padml_nested_aar_source") <- aar_source
      if (!is.null(validate_fit)) validate_fit(fit, inputs)
      publish(fit)
    }
    fit
  })
}
impute_view <- function(spec, authority, chain_apply = lapply) {
  common <- c(
    "authority_path", "chain_seeds", "covariates_path", "mode", "output_dir",
    "variable_path", "view"
  )
  role <- as.character(spec$view$role)
  expected <- if (identical(role, "ANALYSIS")) c(common, "response_path") else common
  exact_names(spec, expected, "F1_IMPUTE_SPEC_KEYS_INVALID")
  exact_names(
    spec$view,
    c("analysis_ids", "outer_fold", "row_ids", "row_ids_sha256", "view_id", "role"),
    "F1_IMPUTE_VIEW_KEYS_INVALID"
  )
  if (!role %in% c("ANALYSIS", "APPLICATION")) fail("F1_IMPUTE_VIEW_ROLE_INVALID")
  analysis_ids <- chars(spec$view$analysis_ids)
  row_ids <- chars(spec$view$row_ids)
  if (!length(analysis_ids) || !length(row_ids) || anyDuplicated(analysis_ids) || anyDuplicated(row_ids) ||
      !all(analysis_ids %in% row_ids)) fail("F1_IMPUTE_VIEW_ROW_SET_INVALID")
  raw <- read.csv(
    as.character(spec$covariates_path), colClasses = "character", check.names = FALSE,
    na.strings = character(), quote = "\"", fileEncoding = "UTF-8"
  )
  if (anyDuplicated(raw$Patient_ID) || !setequal(raw$Patient_ID, row_ids)) {
    fail("F1_IMPUTE_COVARIATE_ROW_SET_INVALID")
  }
  raw <- raw[match(row_ids, raw$Patient_ID), , drop = FALSE]
  if (!identical(as.character(raw$Patient_ID), row_ids)) fail("F1_IMPUTE_ROW_ORDER_INVALID")
  mice_data <- formula_prefill(cast_covariates(raw, as.character(spec$variable_path)), authority)
  ids <- as.character(mice_data$Patient_ID)
  mice_data$Patient_ID <- NULL
  training <- ids %in% analysis_ids
  if (identical(role, "ANALYSIS")) {
    response <- read.csv(
      as.character(spec$response_path), colClasses = "character", check.names = FALSE,
      na.strings = character(), quote = "\"", fileEncoding = "UTF-8"
    )
    if (anyDuplicated(response$Patient_ID) || !setequal(response$Patient_ID, analysis_ids)) {
      fail("F1_ANALYSIS_RESPONSE_ROW_SET_INVALID")
    }
    response <- response[match(ids, response$Patient_ID), , drop = FALSE]
    event <- numeric_strict(response$All_Cause_Death, "All_Cause_Death")
    time <- numeric_strict(response$Death_Followup_months, "Death_Followup_months")
    mice_data$event_aux <- event
    mice_data$nelson_aalen_aux <- nelson_aalen(time, event)
  } else if (any(c("All_Cause_Death", "Death_Followup_months", "event", "nelson_aalen") %in% names(mice_data))) {
    fail("F1_APPLICATION_RESPONSE_VISIBLE")
  }
  mice_authority <- authority$science$mice
  targets <- vapply(mice_authority$target_rules, function(row) as.character(row$target), character(1))
  if (length(targets) != as.integer(mice_authority$expected_targets) ||
      anyDuplicated(targets) || !all(targets %in% names(mice_data))) {
    fail("F1_MICE_TARGET_AUTHORITY_INVALID")
  }
  original_creatinine <- mice_data$Creatinine
  if (any(is.finite(original_creatinine) & original_creatinine < 0)) fail("F1_CREATININE_SCALE_INVALID")
  mice_data$Creatinine <- log1p(original_creatinine)
  active <- targets[vapply(targets, function(name) anyNA(mice_data[[name]]), logical(1))]
  passthrough <- !length(active)
  method <- mice::make.method(mice_data)
  method[] <- ""
  method[active] <- "pmm"
  matrix <- mice::make.predictorMatrix(mice_data)
  matrix[,] <- 0L
  forbidden_all <- chars(mice_authority$always_forbidden_predictors)
  groups <- mice_authority$predictor_groups
  for (rule in mice_authority$target_rules) {
    target <- as.character(rule$target)
    group_ids <- chars(rule$optional_group_ids)
    if (any(!group_ids %in% names(groups))) fail("F1_MICE_PREDICTOR_GROUP_UNKNOWN")
    candidates <- unique(c(
      chars(rule$required_predictors),
      unlist(lapply(group_ids, function(group) chars(groups[[group]])), use.names = FALSE)
    ))
    candidates <- intersect(candidates, colnames(mice_data))
    candidates <- setdiff(candidates, unique(c(chars(rule$forbidden_predictors), forbidden_all, target)))
    candidates <- unique(c(candidates, "AST_ALT"))
    if (identical(role, "ANALYSIS")) {
      candidates <- unique(c(candidates, "event_aux", "nelson_aalen_aux"))
    }
    candidates <- candidates[vapply(
      candidates,
      function(name) factor_support_ok(mice_data[[name]], mice_data[[target]], training),
      logical(1)
    )]
    matrix[target, candidates] <- 1L
  }
  diag(matrix) <- 0L
  pmm <- mice_authority$pmm
  blots <- setNames(lapply(active, function(unused) list(
    donors = as.integer(pmm$donors), matchtype = as.integer(pmm$matchtype),
    trim = as.integer(pmm$trim), ridge = as.numeric(pmm$ridge),
    ls.meth = as.character(pmm$ls_meth)
  )), active)
  chain_seeds <- ints(spec$chain_seeds)
  if (length(chain_seeds) != 20L || anyNA(chain_seeds) || anyDuplicated(chain_seeds)) {
    fail("F1_MICE_CHAIN_SEED_INVALID")
  }
  ignore <- !training
  if (!passthrough) RNGkind("L'Ecuyer-CMRG", "Inversion", "Rejection")
  visit <- if (length(active) == 1L) "roman" else active
  fits <- NULL
  terminal <- NULL
  for (checkpoint in if (passthrough) 0L else ints(mice_authority$maxit_continuation)) {
  fits <- chain_apply(chain_seeds, function(chain_seed, prior = NULL) {
    if (passthrough) return(structure(list(
      data = mice_data, method = method, predictorMatrix = matrix, ignore = ignore,
      blots = blots, where = is.na(mice_data), visitSequence = character(),
      iteration = 0L, m = 1L, slot_seed = as.integer(chain_seed), lastSeedValue = NULL
    ), class = "padml_complete_data_view"))
    if (is.null(prior) && !is.null(fits)) prior <- fits[[match(chain_seed, chain_seeds)]]
    if (is.null(prior)) {
      set.seed(chain_seed)
      fit <- mice::mice(
      mice_data, m = 1L, method = method, predictorMatrix = matrix, ignore = ignore,
      visitSequence = visit, blots = blots, maxit = 30L, printFlag = FALSE,
      seed = chain_seed, remove.constant = FALSE, remove.collinear = FALSE
      )
    } else fit <- mice::mice.mids(prior, maxit = checkpoint - prior$iteration, printFlag = FALSE)
    if (!inherits(fit, "mids") || fit$m != 1L || !fit$iteration %in% c(30L, 40L, 50L) ||
        !identical(fit$method, method) || !identical(fit$predictorMatrix, matrix) ||
        (!is.null(fit$loggedEvents) && nrow(fit$loggedEvents))) {
      fail("F1_MICE_TERMINAL_IDENTITY_INVALID")
    }
    fit
  })
  if (passthrough) break
  iterations <- vapply(fits, function(fit) as.integer(fit$iteration), integer(1))
  if (any(iterations > checkpoint)) next
  if (any(iterations != checkpoint)) fail("F1_MICE_CHECKPOINT_INCOMPLETE")
  terminal <- chain_convergence(fits, active, checkpoint,
      as.integer(mice_authority$convergence$terminal_window_iterations))
  finite <- all(is.finite(terminal$psrf) & is.finite(terminal$ac))
  threshold <- if (checkpoint == 50L) as.numeric(mice_authority$convergence$residual_psrf_exception_max)
               else as.numeric(mice_authority$convergence$psrf_standard_max)
  if (finite && max(terminal$psrf) < threshold) break
  if (checkpoint == 50L) fail("F1_MICE_CONVERGENCE_FAILED")
  }
  final_iteration <- if (passthrough) 0L else checkpoint
  output_dir <- as.character(spec$output_dir)
  dir.create(file.path(output_dir, "imputations"), recursive = TRUE, showWarnings = FALSE)
  dir.create(file.path(output_dir, "configuration"), recursive = TRUE, showWarnings = FALSE)
  handoff <- chars(mice_authority$private_handoff$columns)
  relation_summaries <- vector("list", length(fits))
  for (index in seq_len(20L)) {
    completed <- as.data.frame(
      if (passthrough) fits[[index]]$data else mice::complete(fits[[index]], action = 1L), check.names = FALSE
    )
    completed$Creatinine <- expm1(completed$Creatinine)
    observed <- !is.na(original_creatinine)
    completed$Creatinine[observed] <- original_creatinine[observed]
    completed$BMI <- completed$Weight_kg / (completed$Height_cm / 100)^2
    completed$eGFR_calc <- egfr(completed$Creatinine, completed$Age, completed$Sex)
    completed <- formula_derived(completed, authority)
    relation_summaries[[index]] <- relationship_diagnostics(completed)
    output <- raw
    for (target in targets) output[[target]] <- completed[[target]]
    output$BMI <- completed$BMI
    output$eGFR_calc <- completed$eGFR_calc
    output$AST_ALT <- completed$AST / completed$ALT
    for (name in intersect(c("HCT", "MCH", "MCHC"), names(output))) output[[name]] <- completed[[name]]
    output <- output[handoff]
    required <- setdiff(names(output), chars(mice_authority$formula_completion$raw_only_nullable))
    if (any(vapply(output[required], function(column) any(is.na(column) | as.character(column) == ""), logical(1)))) {
      fail("F1_MICE_COMPLETED_DATA_INVALID")
    }
    write.table(
      output, file.path(output_dir, "imputations", sprintf("imp%02d.csv", index)),
      sep = ",", row.names = FALSE, col.names = TRUE, quote = TRUE, na = "",
      fileEncoding = "UTF-8", qmethod = "double"
    )
  }
  configuration <- list(
    ACTUAL_MICE_METHOD = list(names = names(method), values = unname(as.character(method))),
    ACTUAL_PREDICTOR_MATRIX = list(
      row_names = rownames(matrix), column_names = colnames(matrix),
      values = unname(lapply(seq_len(nrow(matrix)), function(index) unname(as.integer(matrix[index, ]))))
    ),
    ACTUAL_BLOT = list(rows = unname(lapply(names(blots), function(target) {
      value <- blots[[target]]
      list(
        target = target, donors = as.integer(value$donors), matchtype = as.integer(value$matchtype),
        trim = as.integer(value$trim), ridge = as.numeric(value$ridge), ls_meth = as.character(value$ls.meth)
      )
    }))),
    ACTUAL_CONTINUATION_CONFIG = list(
      initial_iteration = if (passthrough) 0L else 30L,
      continuation_iterations = c(40L, 50L)[c(40L, 50L) <= final_iteration],
      continuation_increment = if (passthrough) 0L else 10L, chain_seeds = chain_seeds,
      final_iterations = rep.int(final_iteration, length(chain_seeds)),
      terminal_diagnostics = if (passthrough) list() else terminal
    )
  )
  for (component in names(configuration)) {
    write_json(
      list(
        schema_version = "1.0.0", component = component,
        view_id = as.character(spec$view$view_id), payload = configuration[[component]]
      ),
      file.path(output_dir, "configuration", paste0(component, ".json")),
      auto_unbox = TRUE, null = "null", na = "null", digits = NA
    )
  }
  summary <- list(
      schema_version = "1.0.0", kind = "PADML_F1_MICE_VIEW_SUMMARY", status = "PASS",
      view_id = as.character(spec$view$view_id), role = role,
      outer_fold = as.integer(spec$view$outer_fold), row_count = length(row_ids),
      analysis_row_count = length(analysis_ids), row_ids_sha256 = as.character(spec$view$row_ids_sha256),
      formal_m = 20L, active_target_count = length(active), final_iteration = final_iteration,
      application_response_columns = 0L,
      application_predictor_matrix_response_edges = 0L,
      analysis_auxiliary_predictor_edges = if (identical(role, "ANALYSIS")) {
        sum(matrix[active, intersect(c("event_aux", "nelson_aalen_aux"), colnames(matrix)), drop = FALSE] != 0L)
      } else 0L,
      convergence_max_psrf = if (passthrough) NULL else max(terminal$psrf),
      relationship_diagnostics = relation_summaries
    )
  if (passthrough) summary <- c(summary, list(completion_mode = "COMPLETE_DATA_PASSTHROUGH",
    actual_mice_chains = 0L, rng_consumed = FALSE))
  write_json(summary, file.path(output_dir, "summary.json"), auto_unbox = TRUE, null = "null", na = "null", digits = NA)
}

native_phase_view <- function(spec, authority, native_dir, phase,
                              checkpoint = NULL, chain_index = NULL,
                              rng_substream = NULL, aar_source = NULL) {
  if (!phase %in% c("GATHER", "CHAIN") ||
      (phase == "CHAIN" && (length(checkpoint) != 1L || !checkpoint %in% c(30L, 40L, 50L) ||
       length(chain_index) != 1L || !chain_index %in% 1:20))) fail("F1_MICE_PHASE_INVALID")
  yield <- function(value) stop(structure(list(message = "PADML_MICE_PHASE_RESULT", value = value),
    class = c("padml_mice_phase_result", "error", "condition")))
  tryCatch({
    impute_view(spec, authority, chain_apply = function(chain_seeds, FUN) {
      inputs <- environment(FUN)
      if (phase == "CHAIN") {
        if (isTRUE(inputs$passthrough)) fail("F1_PASSTHROUGH_CHAIN_DISPATCH_INVALID")
        path <- file.path(native_dir, sprintf("imp%02d.rds", chain_index))
        if (checkpoint > 30L && !file.exists(path)) fail("F1_CHAIN_PREDECESSOR_MISSING")
        predecessor <- if (checkpoint == 30L) 30L else checkpoint - 10L
        validate <- function(fit, inputs) {
          if (!fit$iteration %in% c(predecessor, checkpoint)) fail("F1_CHAIN_PREDECESSOR_INVALID")
        }
        inputs$checkpoint <- checkpoint
        fit <- native_chains(chain_seeds, FUN, native_dir = native_dir, chain_action = "FIT",
          rng_substream = rng_substream, aar_source = aar_source,
          chain_indices = chain_index, validate_fit = validate)[[1L]]
        if (fit$iteration != checkpoint) fail("F1_CHAIN_PHASE_RESULT_INVALID")
        yield(list(status = "CHAIN_CHECKPOINT", view_id = spec$view$view_id,
          chain_index = chain_index, iteration = as.integer(fit$iteration),
          root_seed = as.integer(chain_seeds[[chain_index]])))
      }
      if (is.null(inputs$fits)) {
        present <- which(file.exists(file.path(native_dir, sprintf("imp%02d.rds", 1:20))))
        # Read and validate each retained object once. A bad old object cannot
        # authorize fitting a missing chain. Original indices/seeds stay intact.
        retained <- native_chains(chain_seeds, FUN, native_dir = native_dir, chain_action = "REPLAY",
          rng_substream = rng_substream, aar_source = aar_source, chain_indices = present)
        missing <- setdiff(1:20, present)
        if (length(missing) && !isTRUE(inputs$passthrough))
          yield(list(status = "NEEDS_CHECKPOINT", view_id = spec$view$view_id,
            checkpoint = 30L, chain_indices = unname(as.list(missing))))
        fits <- vector("list", 20L)
        fits[present] <- retained
        if (length(missing)) {
          # Typed zero-missing slots: no mice() call, no RNG, no fitted-chain count.
          fits[missing] <- native_chains(chain_seeds, FUN, native_dir = native_dir, chain_action = "FIT",
            rng_substream = rng_substream, aar_source = aar_source, chain_indices = missing)
        }
      } else fits <- inputs$fits
      if (!isTRUE(inputs$passthrough)) {
        lagging <- which(vapply(fits, function(fit) as.integer(fit$iteration), integer(1)) < inputs$checkpoint)
        if (length(lagging)) yield(list(status = "NEEDS_CHECKPOINT", view_id = spec$view$view_id,
          checkpoint = as.integer(inputs$checkpoint), chain_indices = unname(as.list(lagging))))
      }
      # impute_view itself performs unchanged complete-M20 diagnostics and output.
      # Its later loop iterations reuse these objects; they are not read again.
      fits
    })
    list(status = "VIEW_OUTPUT_READY", view_id = spec$view$view_id, native_objects_validated = TRUE)
  }, padml_mice_phase_result = function(condition) condition$value)
}
main <- function() {
  args <- commandArgs(trailingOnly = TRUE)
  if (!length(args) || !(length(args) == 1L || length(args) == 2L && args[[2L]] == "GATHER" ||
      length(args) == 4L && args[[2L]] == "CHAIN")) fail("F1_NESTED_MICE_USAGE")
  spec <- fromJSON(args[[1L]], simplifyVector = FALSE)
  authority <- fromJSON(as.character(spec$authority_path), simplifyVector = FALSE)
  mice_authority <- authority$science$mice
  if (!identical(authority$activation, "ACTIVATED") ||
      !identical(authority$schema_version, "1.0.0") ||
      !identical(authority$kind, "PADML_F2_V1_SCIENCE_AUTHORITY") ||
      !identical(as.integer(mice_authority$formal_m), 20L) ||
      !identical(ints(mice_authority$maxit_continuation), c(30L, 40L, 50L)) ||
      !identical(as.character(mice_authority$scope), "NESTED_SPLIT_SPECIFIC_OUTCOME_BLIND_DOUBLE_VIEW") ||
      !identical(as.character(mice_authority$analysis_outcome_auxiliary_scope), "FIT_ROWS_ONLY") ||
      !identical(as.character(mice_authority$application_response_visibility), "PHYSICALLY_ABSENT") ||
      !identical(as.integer(mice_authority$application_predictor_matrix_response_edges), 0L) ||
      !identical(as.character(mice_authority$restart_or_reseed), "FORBIDDEN") ||
      !identical(as.character(mice_authority$seed_policy$rng_kind), "L'Ecuyer-CMRG/Inversion/Rejection") ||
      !identical(as.character(mice_authority$private_handoff$mode), "SEALED_PRIVATE_M20_BY_OUTER_FOLD")) {
    fail("F1_AUTHORITY_INVALID")
  }
  if (identical(spec$mode, "PREPARE")) {
    if (length(args) != 1L) fail("F1_NESTED_MICE_USAGE")
    prepare_workbook(spec, authority)
  } else if (identical(spec$mode, "IMPUTE_VIEW")) {
    native_dir <- file.path(dirname(normalizePath(args[[1L]], mustWork = TRUE)), "native")
    dir.create(native_dir, mode = "0700", showWarnings = FALSE)
    if (length(args) > 1L) {
      result <- native_phase_view(spec, authority, native_dir, args[[2L]],
        if (length(args) == 4L) as.integer(args[[3L]]) else NULL,
        if (length(args) == 4L) as.integer(args[[4L]]) else NULL)
      cat("PADML_MICE_PHASE_RESULT=", toJSON(result, auto_unbox = TRUE, null = "null", digits = NA), "\n", sep = "")
    } else {
      impute_view(spec, authority, chain_apply = function(chain_seeds, FUN) {
        native_chains(chain_seeds, FUN, native_dir = native_dir,
                      chain_action = "FIT", rng_substream = NULL, aar_source = NULL)
      })
    }
  } else {
    fail("F1_MODE_INVALID")
  }
}

tryCatch(main(), error = function(error) {
  message(conditionMessage(error))
  quit(status = 2L)
})
