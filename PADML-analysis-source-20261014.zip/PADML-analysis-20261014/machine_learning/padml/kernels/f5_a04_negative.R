#!/usr/bin/env Rscript

# Three fixed centre-wise outcome-pair permutations. RNG is wholly generated
# before MICE/model calls, which have their own unchanged registered seeds.
a04_negative_permutation <- function(response, centers, analysis_ids, evaluation_ids, outer, index) {
  need <- function(ok, reason) if (!isTRUE(ok)) stop(reason, call. = FALSE)
  need(identical(names(response), c("Patient_ID", "All_Cause_Death", "Death_Followup_months")) &&
         !anyDuplicated(response$Patient_ID) && is.numeric(outer) && outer %in% 1:6 &&
         is.numeric(index) && index %in% 1:3, "F5_A04_NEGATIVE_PERMUTATION_INPUT_INVALID")
  roles <- list(ANALYSIS = as.character(analysis_ids), EVALUATION = as.character(evaluation_ids))
  ids <- unlist(roles, use.names = FALSE)
  center <- as.character(unlist(centers, use.names = TRUE))
  names(center) <- names(centers)
  need(all(lengths(roles) > 0L) && !anyDuplicated(ids) && all(ids %in% response$Patient_ID) &&
         !anyDuplicated(names(center)) && all(ids %in% names(center)) &&
         all(grepl("^[0-9]+$", center[ids])) && !"55" %in% center[roles$EVALUATION],
       "F5_A04_NEGATIVE_PERMUTATION_ROWS_INVALID")
  response <- response[match(ids, response$Patient_ID), , drop = FALSE]
  event <- suppressWarnings(as.numeric(response$All_Cause_Death))
  time <- suppressWarnings(as.numeric(response$Death_Followup_months))
  need(all(is.finite(event)) && all(event %in% 0:1) && all(is.finite(time)) && all(time > 0),
       "F5_A04_NEGATIVE_PERMUTATION_RESPONSE_INVALID")
  RNGkind("L'Ecuyer-CMRG", "Inversion", "Rejection")
  seed <- 500000L + as.integer(outer)*10L + as.integer(index)
  set.seed(seed)
  initial <- .Random.seed
  blocks <- list()
  result <- list()
  for (role in names(roles)) {
    role_ids <- roles[[role]]
    out <- response[match(role_ids, response$Patient_ID), , drop = FALSE]
    for (site in as.character(sort(unique(as.integer(center[role_ids]))))) {
      block_ids <- role_ids[center[role_ids] == site]
      need(length(block_ids) > 0L, "F5_A04_NEGATIVE_EMPTY_BLOCK_INTERNAL")
      before <- .Random.seed
      permutation <- sample.int(length(block_ids), length(block_ids), replace = FALSE)
      after <- .Random.seed
      source_ids <- block_ids[permutation]
      out[match(block_ids, role_ids), c("All_Cause_Death", "Death_Followup_months")] <-
        response[match(source_ids, response$Patient_ID), c("All_Cause_Death", "Death_Followup_months")]
      blocks[[length(blocks) + 1L]] <- list(role = role, center = site,
        patient_ids = as.list(block_ids), source_patient_ids = as.list(source_ids),
        permutation = as.list(permutation), rng_before = as.list(before), rng_after = as.list(after))
    }
    result[[role]] <- out
  }
  list(evidence = list(kind = "PADML_F5_A04_NEGATIVE_PERMUTATION_V1", outer_fold = outer,
    permutation_index = index, seed = seed, rng_kind = as.list(RNGkind()),
    rng_initial = as.list(initial), rng_final = as.list(.Random.seed), blocks = blocks),
    analysis = result$ANALYSIS, evaluation = result$EVALUATION)
}

a04_negative_m2 <- function(fun) {
  changes <- integer(3L)
  project <- function(expression) {
    original <- list(quote(length(chain_seeds) != 20L), quote(seq_len(20L)))
    replacement <- list(quote(length(chain_seeds) != 2L), quote(seq_len(2L)))
    for (index in seq_along(original)) if (identical(expression, original[[index]])) {
      changes[[index]] <<- changes[[index]] + 1L
      return(replacement[[index]])
    }
    if (is.call(expression)) {
      if (identical(expression[[1L]], as.name("list")) && "formal_m" %in% names(expression)) {
        if (!identical(expression[["formal_m"]], 20L)) stop("F5_A04_NEGATIVE_M2_SOURCE_INVALID")
        expression[["formal_m"]] <- 2L
        changes[[3L]] <<- changes[[3L]] + 1L
      }
      for (index in seq_along(expression))
        if (!is.null(expression[[index]]) && !identical(expression[[index]], quote(expr = )))
          expression[[index]] <- project(expression[[index]])
    }
    expression
  }
  body(fun) <- project(body(fun))
  if (!identical(changes, rep(1L, 3L))) stop("F5_A04_NEGATIVE_M2_SOURCE_INVALID")
  fun
}

args <- commandArgs(trailingOnly = TRUE)
if (length(args) == 2L && identical(args[[1L]], "PERMUTE")) {
  suppressPackageStartupMessages(library(jsonlite))
  spec <- fromJSON(args[[2L]], simplifyVector = FALSE)
  stopifnot(identical(sort(names(spec)), sort(c("response_path", "centers", "analysis_ids",
                    "evaluation_ids", "outer_fold", "permutation_index", "output_dir"))))
  root <- as.character(spec$output_dir)
  stopifnot(!file.exists(root), dir.create(root, mode = "0700"))
  options(error = function() {
    dump.frames(file.path(root, "native-failure"), to.file = TRUE, include.GlobalEnv = TRUE)
    quit(save = "no", status = 1L, runLast = FALSE)
  })
  response <- read.csv(as.character(spec$response_path), colClasses = "character",
                       stringsAsFactors = FALSE, check.names = FALSE)
  value <- a04_negative_permutation(response, spec$centers, unlist(spec$analysis_ids),
              unlist(spec$evaluation_ids), spec$outer_fold, spec$permutation_index)
  write_json(value$evidence, file.path(root, "permutation.json"), auto_unbox = TRUE, digits = NA)
  write.csv(value$analysis, file.path(root, "analysis-response.csv"), row.names = FALSE, na = "")
  write.csv(value$evaluation, file.path(root, "evaluation-response.csv"), row.names = FALSE, na = "")
  writeLines(capture.output(sessionInfo()), file.path(root, "native-session.txt"))
  quit(save = "no", status = 0L)
}

# Reuse native per-chain retention/reopening, with only explicit M2 cardinality.
script <- grep("^--file=", commandArgs(), value = TRUE)
stopifnot(length(script) == 1L)
bridge <- parse(file.path(dirname(gsub("~+~", " ", sub("^--file=", "", script), fixed = TRUE)), "f5_mice.R"))
entry <- which(vapply(as.list(bridge), function(x) identical(x, quote(impute_view(spec, authority))), logical(1)))
stopifnot(length(entry) == 1L, entry[[1L]] == length(bridge) - 1L)
for (expression in as.list(bridge)[seq_len(entry[[1L]] - 1L)]) eval(expression)
coordinates <- spec$a04_coordinates
exact_names(coordinates, c("outer_fold", "imputation", "variant", "permutation_index"),
            "F5_A04_NEGATIVE_COORDINATES_INVALID")
if (!identical(coordinates$variant, "NEGATIVE_CONTROL") ||
    !is.numeric(coordinates$outer_fold) || !coordinates$outer_fold %in% 1:6 ||
    !is.numeric(coordinates$imputation) || coordinates$imputation != 1L ||
    !is.numeric(coordinates$permutation_index) || !coordinates$permutation_index %in% 1:3 ||
    !identical(coordinates$outer_fold, spec$view$outer_fold) ||
    !identical(spec$view$view_id, "OUTER_ANALYSIS") || !identical(spec$view$role, "ANALYSIS") ||
    !is.null(chain_rng_substream)) fail("F5_A04_NEGATIVE_COORDINATES_INVALID")
spec$a04_coordinates <- NULL
impute_view <- a04_negative_m2(impute_view)
impute_view(spec, authority)
writeLines(capture.output(sessionInfo()), file.path(root, "native-session.txt"))
