#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(jsonlite)
  library(digest)
  library(survival)
})

fail <- function(code) stop(code, call. = FALSE)
need <- function(value, code) if (!isTRUE(value)) fail(code)
scalar <- function(value) unname(unlist(value, use.names = FALSE)[[1L]])
canonical_json <- function(value, always_decimal = FALSE, digits = NA) toJSON(value, auto_unbox = TRUE, null = "null", na = "null", digits = digits, pretty = FALSE, always_decimal = always_decimal)
sha_object <- function(value) digest(charToRaw(paste0(canonical_json(value, always_decimal = TRUE), "\n")), algo = "sha256", serialize = FALSE)
sha_text <- function(value) digest(charToRaw(value), algo = "sha256", serialize = FALSE)

cache_r_preparation <- function(cache, key, value) {
  size <- as.numeric(object.size(value))
  if (!is.null(cache) && size <= 64*1024^2) {
    resident <- sum(vapply(ls(cache), function(k) as.numeric(object.size(get(k,cache))), numeric(1)))
    if (resident + size > 64*1024^2) rm(list=ls(cache),envir=cache)
    assign(key,value,envir=cache)
  }
  value
}

python_json_number_values <- function(values) {
  values <- as.numeric(values)
  need(length(values) > 0L && all(is.finite(values)), "F2_R_RISK_MATRIX_INVALID")
  chunk_size <- 262144L
  result <- numeric(length(values))
  for (lower in seq.int(1L, length(values), by = chunk_size)) {
    upper <- min(length(values), lower + chunk_size - 1L)
    parsed <- unlist(
      fromJSON(toJSON(values[lower:upper], digits = NA)),
      use.names = FALSE
    )
    need(
      length(parsed) == upper - lower + 1L,
      "F2_R_RISK_MATRIX_INVALID"
    )
    result[lower:upper] <- parsed
  }
  result
}

write_operation_local_risk_matrix <- function(value, file_name) {
  need(
    is.matrix(value) && nrow(value) > 0L && ncol(value) > 0L &&
      all(is.finite(value)) && identical(basename(file_name), file_name),
    "F2_R_RISK_MATRIX_INVALID"
  )
  path <- file.path(dirname(output_path), file_name)
  need(!file.exists(path) && !dir.exists(path), "F2_R_RISK_MATRIX_COLLISION")
  connection <- file(path, open = "wxb")
  closed <- FALSE
  on.exit(if (!closed) close(connection), add = TRUE)
  writeBin(
    python_json_number_values(as.numeric(t(value))), connection,
    size = 8L, endian = "little"
  )
  close(connection)
  closed <- TRUE
  size_bytes <- as.numeric(file.info(path)$size)
  need(
    is.finite(size_bytes) && size_bytes == nrow(value) * ncol(value) * 8,
    "F2_R_RISK_MATRIX_INVALID"
  )
  list(
    schema_version = "1.0.0",
    kind = "PADML_F2_OPERATION_LOCAL_RISK_MATRIX",
    encoding = "IEEE754_FLOAT64",
    byte_order = "LITTLE_ENDIAN",
    row_order = "ROW_MAJOR",
    file_name = file_name,
    rows = nrow(value),
    columns = ncol(value),
    size_bytes = size_bytes,
    sha256 = digest(file = path, algo = "sha256", serialize = FALSE)
  )
}

risk_matrix_channel <- function(fit, evaluation, prefix) {
  list(
    schema_version = "1.0.0",
    kind = "PADML_F2_OPERATION_LOCAL_RISK_MATRIX_CHANNEL",
    fit = write_operation_local_risk_matrix(
      fit, paste0(prefix, "-fit.bin")
    ),
    evaluation = write_operation_local_risk_matrix(
      evaluation, paste0(prefix, "-evaluation.bin")
    )
  )
}

args <- commandArgs(trailingOnly = TRUE)
need(length(args) == 1L, "F2_R_ARGUMENT_INVALID")
spec <- fromJSON(args[[1L]], simplifyVector = FALSE)
if (identical(spec$execution_scope, "F5_A12_SEARCH")) options(error=function() {
  dump.frames(file.path(dirname(as.character(scalar(spec$output_path))), "native-failure"),
              to.file=TRUE, include.GlobalEnv=TRUE)
  quit(save="no", status=1L, runLast=FALSE)
})

recipe_forbidden_key <- function(value) {
  if (!is.list(value)) return(FALSE)
  keys <- tolower(gsub("-", "_", names(value)))
  forbidden <- c(
    "all_cause_death", "death_followup_months", "response", "outcome",
    "event", "followup", "nelson_aalen", "evaluation", "application"
  )
  if (any(vapply(keys, function(key) any(vapply(forbidden, grepl, logical(1), x = key, fixed = TRUE)), logical(1)))) return(TRUE)
  any(vapply(value, recipe_forbidden_key, logical(1)))
}

fit_design_recipe <- function(projection) {
  need(
    identical(sort(names(projection)), sort(c(
      "partition_id", "fit_ids_sha256", "analysis_view_sha256", "analysis_ids_sha256",
      "recipe_registry_record"
    ))) && !recipe_forbidden_key(projection),
    "F2_RECIPE_RESPONSE_ROLE_REACHABLE"
  )
  record <- projection$recipe_registry_record
  need(
    identical(sort(names(record)), sort(c(
      "schema_version", "kind", "input_dir", "fit_ids", "members", "registry", "conflict_map"
    ))) && identical(as.character(scalar(record$schema_version)), "1.0.0") &&
      identical(as.character(scalar(record$kind)), "PADML_F2_RECIPE_REGISTRY_RECORD") &&
      length(record$members) == 20L && !recipe_forbidden_key(record),
    "F2_RECIPE_REGISTRY_RECORD_INVALID"
  )
  fit_ids <- as.character(unlist(record$fit_ids, use.names = FALSE))
  need(
    length(fit_ids) > 0L && !anyDuplicated(fit_ids) &&
      identical(sha_object(as.list(fit_ids)), as.character(scalar(projection$fit_ids_sha256))) &&
      identical(as.character(scalar(projection$fit_ids_sha256)), as.character(scalar(projection$analysis_ids_sha256))),
    "F2_RECIPE_TRAINING_ROW_IDENTITY_INVALID"
  )
  input_dir <- as.character(scalar(record$input_dir))
  member_ok <- vapply(seq_len(20L), function(index) {
    member <- record$members[[index]]
    expected_name <- sprintf("imp%02d.csv", index)
    path <- file.path(input_dir, expected_name)
    is.list(member) &&
      identical(sort(names(member)), sort(c("name", "sha256", "size_bytes"))) &&
      identical(as.character(scalar(member$name)), expected_name) &&
      file.exists(path) && !dir.exists(path) &&
      identical(
        as.character(scalar(member$sha256)),
        digest(file = path, algo = "sha256", serialize = FALSE)
      ) &&
      identical(
        as.numeric(scalar(member$size_bytes)),
        as.numeric(file.info(path)$size)
      )
  }, logical(1))
  need(all(member_ok), "F2_RECIPE_TRAINING_MEMBER_INVALID")
  frames <- lapply(seq_len(20L), function(index) {
    path <- file.path(input_dir, sprintf("imp%02d.csv", index))
    need(file.exists(path), "F2_RECIPE_TRAINING_MEMBER_INVALID")
    data <- read.csv(path, check.names = FALSE, stringsAsFactors = FALSE)
    normalized <- tolower(gsub("-", "_", names(data)))
    forbidden <- c(
      "all_cause_death", "death_followup_months", "response", "outcome",
      "event", "followup", "nelson_aalen", "evaluation", "application"
    )
    need(
      "Patient_ID" %in% names(data) && !any(vapply(normalized, function(key) any(vapply(forbidden, grepl, logical(1), x = key, fixed = TRUE)), logical(1))),
      "F2_RECIPE_RESPONSE_ROLE_REACHABLE"
    )
    ids <- as.character(data$Patient_ID)
    rows <- match(fit_ids, ids)
    need(!anyNA(rows) && !anyDuplicated(ids), "F2_RECIPE_TRAINING_ROW_IDENTITY_INVALID")
    data[rows, , drop = FALSE]
  })
  registry <- record$registry
  rows <- registry$rows
  parents <- vapply(rows, function(row) as.character(scalar(row$parent)), character(1))
  need(
    identical(as.character(scalar(registry$schema_version)), "1.0.0") &&
      identical(as.character(scalar(registry$kind)), "PADML_F2_TRANSFORM_REGISTRY") &&
      length(rows) > 0L && !anyDuplicated(parents) && !"eGFR_calc" %in% parents,
    "F2_RECIPE_REGISTRY_RECORD_INVALID"
  )
  representations <- lapply(rows, function(row) {
    parent <- as.character(scalar(row$parent))
    canonical_unit <- as.character(scalar(row$canonical_unit))
    representation <- as.character(scalar(row$representation))
    need(all(vapply(frames, function(data) parent %in% names(data), logical(1))), "F2_RECIPE_PARENT_MISSING")
    values <- lapply(frames, function(data) suppressWarnings(as.numeric(data[[parent]])))
    need(all(vapply(values, function(value) all(is.finite(value)), logical(1))), "F2_RECIPE_PARENT_DOMAIN_INVALID")
    if (identical(representation, "IDENTITY")) {
      columns <- parent
      design_df <- 1L
      parameters <- list(identity = TRUE)
    } else if (identical(representation, "LOG1P")) {
      need(all(vapply(values, function(value) all(value >= 0), logical(1))), "F2_RECIPE_LOG1P_DOMAIN_INVALID")
      columns <- paste0(parent, "__LOG1P")
      design_df <- 1L
      parameters <- list(canonical_unit_scale = 1L)
    } else if (identical(representation, "NATURAL_SPLINE_K3")) {
      pooled <- unlist(values, use.names = FALSE)
      ordered <- sort(pooled)
      quantiles <- vapply(c(.1, .5, .9), function(probability) {
        position <- (length(ordered) - 1L) * probability
        lower <- floor(position)
        fraction <- position - lower
        if (lower + 1L == length(ordered)) return(ordered[[lower + 1L]])
        ordered[[lower + 1L]] + fraction * (ordered[[lower + 2L]] - ordered[[lower + 1L]])
      }, numeric(1))
      need(length(quantiles) == 3L && all(is.finite(quantiles)) && quantiles[[1L]] < quantiles[[2L]] && quantiles[[2L]] < quantiles[[3L]], "F2_RECIPE_SPLINE_PARAMETER_INVALID")
      columns <- paste0(parent, c("__NS1", "__NS2"))
      matrices <- lapply(values, function(value) {
        matrix <- splines::ns(
          value, knots = quantiles[[2L]], Boundary.knots = quantiles[c(1L, 3L)],
          intercept = FALSE
        )
        colnames(matrix) <- columns
        need(
          identical(dim(matrix), c(length(value), 2L)) && all(is.finite(matrix)) &&
            all(apply(matrix, 2L, var) > 0) && qr(matrix)$rank == 2L &&
            identical(colnames(matrix), columns),
          "F2_RECIPE_SPLINE_TRAINING_DESIGN_INVALID"
        )
        matrix
      })
      need(all(vapply(matrices, function(matrix) identical(colnames(matrix), columns), logical(1))), "F2_RECIPE_SPLINE_COLUMN_ORDER_INVALID")
      design_df <- 2L
      parameters <- list(
        boundary_knots = as.list(quantiles[c(1L, 3L)]),
        interior_knots = as.list(quantiles[[2L]]),
        quantile_type = 7L
      )
    } else {
      fail("F2_RECIPE_REPRESENTATION_INVALID")
    }
    list(
      parent = parent, canonical_unit = canonical_unit, representation = representation,
      design_df = design_df, design_columns = as.list(columns), parameters = parameters
    )
  })
  list(
    partition_id = as.character(scalar(projection$partition_id)),
    representations = representations,
    ordered_parent_column_map = lapply(representations, function(row) list(parent = row$parent, columns = row$design_columns))
  )
}

if (identical(scalar(spec$action), "COMPILE_TRANSFORM_RECIPES")) {
  projections <- spec$projections
  expected_count <- as.integer(scalar(spec$expected_count))
  need((expected_count %in% c(5L, 6L, 16L) ||
          (identical(spec$execution_scope, "F4_FULL_PIPELINE") && expected_count == 1L)) &&
         length(projections) == expected_count,
       "F2_RECIPE_COMPILE_DENOMINATOR_INVALID")
  recipes <- lapply(projections, fit_design_recipe)
  partition_ids <- vapply(recipes, function(row) row$partition_id, character(1))
  need(!anyDuplicated(partition_ids), "F2_RECIPE_COMPILE_DENOMINATOR_INVALID")
  result <- list(
    schema_version = "1.0.0", kind = "PADML_F2_R_RECIPE_VALUES", status = "PASS",
    recipe_count = length(recipes), recipes = recipes
  )
  writeLines(canonical_json(result, always_decimal = TRUE, digits = I(17)), as.character(scalar(spec$output_path)), useBytes = TRUE)
  quit(save = "no", status = 0L)
}

output_path <- scalar(spec$output_path)
action <- scalar(spec$action)
if (!identical(action, "SELECTOR_SENSITIVITY_TASK")) suppressPackageStartupMessages(library(glmnet))
script <- grep("^--file=", commandArgs(), value=TRUE)
need(length(script) == 1L, "F2_R_SCRIPT_PATH_INVALID")
source(file.path(dirname(gsub("~+~", " ", sub("^--file=", "", script), fixed=TRUE)), "f5_design.R"), local=TRUE)

fold <- as.integer(scalar(spec$fold))
family <- scalar(spec$family)
heldout_center <- as.integer(scalar(spec$heldout_center))
execution_scope <- if (is.null(spec$execution_scope)) "F2_OUTER_DEVELOPMENT" else as.character(scalar(spec$execution_scope))
a12_search <- identical(execution_scope, "F5_A12_SEARCH")
time_col <- scalar(spec$time)
event_col <- scalar(spec$outcome)
seed <- as.integer(scalar(spec$seed))
threads <- as.integer(scalar(spec$threads))
need(
  threads == 1L && (
    (identical(execution_scope, "F2_OUTER_DEVELOPMENT") && fold %in% seq_len(6L)) ||
    (identical(execution_scope, "INTEGRATED_SELECTOR_DIAGNOSTIC") && fold %in% 0:6 &&
      identical(action, "SELECTOR_SENSITIVITY_TASK") && (fold != 0L || heldout_center == 0L)) ||
    (a12_search && fold %in% seq_len(6L) && identical(action, "MODEL_PREDICTION_BATCH") &&
      family %in% c("ELASTIC_NET_COX", "RSF", "GBM_COX")) ||
    (execution_scope %in% c("F5_FULL_DEVELOPMENT_A16", "F5_FULL_DEVELOPMENT_SEARCH", "F4_FULL_PIPELINE_SEARCH") &&
      fold == 0L && heldout_center == 0L)
  ),
  "F2_R_SPEC_INVALID"
)
validate_a12_search_source <- function(spec) {
  source <- spec$a12_source
  projected <- is.list(source$source) && identical(scalar(source$source$kind), "PADML_F5_A12_PROJECTED_OUTER_INPUTS_V1")
  branches <- if (projected)
    c("A12_WITHOUT_AST_ALT_DIRECT", "A12_WITHOUT_AST_ALT_TOTAL", "OUTER_SELECTED_FAMILY_NO_AAR_REDEVELOPMENT")
    else c("WITHOUT_AST_ALT_DIRECT", "WITHOUT_AST_ALT_TOTAL")
  need(as.integer(scalar(source$outer_fold)) == as.integer(scalar(spec$fold)) &&
       identical(as.character(scalar(source$family)), as.character(scalar(spec$family))) &&
       as.character(scalar(source$branch)) %in% branches &&
       identical(as.character(scalar(source$branch)), as.character(scalar(spec$registered_partitions$branch))),
       "F5_A12_SEARCH_SOURCE_INVALID")
  if (projected) {
    primary <- source$source$primary_source
    need(identical(scalar(primary$program_id), "PADML_F45_REBUILD_20260925") &&
         identical(scalar(source$source$family), scalar(source$family)) &&
         identical(scalar(primary$primary_development_lock$selected_family), scalar(source$family)) &&
         as.integer(scalar(primary$primary_training_context$outer_fold)) == as.integer(scalar(source$outer_fold)) &&
         all(vapply(c("inputs_identity_sha256", "development_input_sha256"), function(key)
           is.character(source[[key]]) && length(source[[key]]) == 1L && grepl("^[0-9a-f]{64}$", source[[key]]), logical(1))),
         "F5_A12_SEARCH_DEVELOPMENT_SOURCE_INVALID")
  }
}
if (a12_search) validate_a12_search_source(spec)
imputation_count <- if (is.null(spec$imputation_count)) 20L else as.integer(scalar(spec$imputation_count))
need(
  imputation_count %in% c(1L, 5L, 20L) &&
    (!identical(action, "MODEL_DEVELOPMENT") || imputation_count == 20L) &&
    (imputation_count != 1L || identical(action, "LOCKED_FAMILY_EXECUTION")),
  "F2_R_IMPUTATION_COUNT_INVALID"
)

variable_rows <- spec$predictors$variables
variable_rows <- lapply(variable_rows, function(row) {
  list(
    name = scalar(row$name),
    type = scalar(row$type),
    levels = scalar(row$levels_or_coding),
    set_a_eligible = isTRUE(row$set_a_eligible),
    selector_eligible = isTRUE(row$selector_eligible),
    forced = isTRUE(row$forced),
    selector_representation = as.character(scalar(row$selector_representation))
  )
})
parents <- vapply(Filter(function(row) row$set_a_eligible, variable_rows), `[[`, character(1), "name")
selector_parents <- vapply(Filter(function(row) row$selector_eligible, variable_rows), `[[`, character(1), "name")
need(length(parents) > 0L && identical(intersect("AST_ALT", parents), "AST_ALT"), "F2_R_PARENT_CONTRACT_INVALID")

categorical_contract <- function(row) {
  if (!row$type %in% c("binary", "ordered", "unordered")) return(NULL)
  fields <- trimws(strsplit(as.character(row$levels), ";", fixed = TRUE)[[1L]])
  need(length(fields) > 0L && all(nzchar(fields)), "F2_R_DESIGN_INVALID")
  level_fields <- fields[startsWith(fields, "levels=")]
  reference_fields <- fields[startsWith(fields, "reference=")]
  need(length(level_fields) == 1L && length(reference_fields) == 1L, "F2_R_DESIGN_INVALID")
  level_value <- sub("^levels=", "", level_fields[[1L]])
  reference_token <- sub("^reference=", "", reference_fields[[1L]])
  need(nzchar(level_value) && nzchar(reference_token), "F2_R_DESIGN_INVALID")
  levels <- strsplit(level_value, "|", fixed = TRUE)[[1L]]
  need(
    length(levels) > 0L && all(nzchar(levels)) && !anyDuplicated(levels) && identical(levels, trimws(levels)),
    "F2_R_DESIGN_INVALID"
  )
  matches <- vapply(levels, function(level) {
    if (identical(reference_token, level)) return(TRUE)
    prefix <- paste0(level, " (")
    if (!startsWith(reference_token, prefix) || !endsWith(reference_token, ")")) return(FALSE)
    annotation <- substr(reference_token, nchar(prefix) + 1L, nchar(reference_token) - 1L)
    nzchar(annotation) && !grepl("[()]", annotation)
  }, logical(1))
  need(sum(matches) == 1L, "F2_R_DESIGN_INVALID")
  list(levels = levels, reference = levels[[which(matches)]])
}

locked_levels <- function(row) {
  contract <- categorical_contract(row)
  if (is.null(contract)) return(NULL)
  contract$levels
}

prepare_frame <- function(data, a12=FALSE, a12_total=FALSE) {
  need(!a12_total || a12, "F5_A12_FRAME_SCOPE_INVALID")
  required_parents <- if (a12) setdiff(parents, "AST_ALT") else parents
  need(all(c("Patient_ID", "Center", required_parents) %in% names(data)), "F2_R_INPUT_COLUMNS_INVALID")
  if (a12_total)
    need(!any(c("AST", "ALT", "AST_ALT") %in% names(data)), "F5_A12_TOTAL_CHANNEL_NOT_REMOVED")
  need(!time_col %in% names(data) && !event_col %in% names(data), "F2_R_APPLICATION_RESPONSE_VISIBLE")
  for (row in variable_rows) {
    if (!row$name %in% names(data)) next
    levels <- locked_levels(row)
    if (!is.null(levels)) {
      values <- as.character(data[[row$name]])
      data[[row$name]] <- factor(values, levels = levels, ordered = identical(row$type, "ordered"))
      need(!anyNA(data[[row$name]]), "F2_R_FACTOR_LEVEL_INVALID")
    } else {
      data[[row$name]] <- suppressWarnings(as.numeric(data[[row$name]]))
      need(all(is.finite(data[[row$name]])), "F2_R_NUMERIC_PREDICTOR_INVALID")
    }
  }
  data$Patient_ID <- as.character(data$Patient_ID)
  data$Center <- as.integer(data$Center)
  need(all(nzchar(data$Patient_ID)) && !anyDuplicated(data$Patient_ID), "F2_R_PATIENT_ID_INVALID")
  data
}

read_response <- function(record) {
  path <- as.character(scalar(record$path))
  need(file.exists(path), "F2_R_RESPONSE_SEAL_MISSING")
  need(
    identical(as.numeric(file.info(path)$size), as.numeric(scalar(record$size_bytes))) &&
      identical(digest(file = path, algo = "sha256", serialize = FALSE), as.character(scalar(record$sha256))),
    "F2_R_RESPONSE_SEAL_IDENTITY_INVALID"
  )
  value <- read.csv(path, colClasses = "character", check.names = FALSE, stringsAsFactors = FALSE)
  need(
    identical(names(value), c("Patient_ID", "All_Cause_Death", "Death_Followup_months")) &&
      nrow(value) == as.integer(scalar(record$row_count)) && !anyDuplicated(value$Patient_ID) &&
      identical(sha_object(as.list(as.character(value$Patient_ID))), as.character(scalar(record$row_ids_sha256))),
    "F2_R_RESPONSE_SEAL_IDENTITY_INVALID"
  )
  value[[event_col]] <- suppressWarnings(as.integer(value[[event_col]]))
  value[[time_col]] <- suppressWarnings(as.numeric(value[[time_col]]))
  need(
    all(value[[event_col]] %in% c(0L, 1L)) && all(is.finite(value[[time_col]])) && all(value[[time_col]] > 0),
    "F2_R_RESPONSE_DOMAIN_INVALID"
  )
  value
}

checked_boruta_importance <- function(value, x) {
  need(is.numeric(value) && is.null(dim(value)) && length(value) == ncol(x),
       "F2_BORUTA_IMPORTANCE_LENGTH_OR_TYPE_INVALID")
  need(!is.null(names(value)) && !anyDuplicated(names(value)) &&
         identical(names(value), colnames(x)), "F2_BORUTA_IMPORTANCE_NAMES_INVALID")
  need(all(is.finite(value)), "F2_BORUTA_IMPORTANCE_NONFINITE")
  value
}

checked_sensitivity_engine <- function(expression, method) {
  tryCatch(withCallingHandlers(expression, warning = function(w) {
    message(method, " numerical warning: ", conditionMessage(w))
    fail(paste0("F2_", method, "_NUMERICAL_WARNING"))
  }), error = function(e) {
    if (startsWith(conditionMessage(e), "F2_")) stop(e)
    message(method, " engine error: ", conditionMessage(e))
    fail(paste0("F2_", method, "_ENGINE_EXECUTION_FAILED"))
  })
}

checked_mrmre_numerics <- function(fit, data, x, y) {
  correlations <- mRMRe::mim(fit, method = "cor")
  need(is.matrix(correlations) && identical(dim(correlations), rep(ncol(x) + 1L, 2L)),
       "F2_MRMRE_ASSOCIATION_SHAPE_INVALID")
  observed <- correlations[row(correlations) != col(correlations)]
  need(all(is.finite(observed)) && all(abs(observed) <= 1),
       "F2_MRMRE_ASSOCIATION_NONFINITE_OR_RANGE_INVALID")
  mi <- -.5 * log(1 - observed^2)
  need(all(is.finite(mi)), "F2_MRMRE_MI_NONFINITE")
  reference <- vapply(x, function(column) {
    predictor <- as.numeric(column)
    2 * survival::concordance(y ~ predictor, reverse = TRUE, timefix = FALSE)$concordance - 1
  }, numeric(1))
  need(all(is.finite(reference)), "F2_MRMRE_REFERENCE_NONFINITE")
  delta <- max(abs(correlations[1L, -1L] - reference),
               abs(correlations[-1L, 1L] - reference))
  need(is.finite(delta) && delta <= 1e-12, "F2_MRMRE_CONCORDANCE_REFERENCE_MISMATCH")
  scores <- as.numeric(mRMRe::scores(fit)[[1L]])
  need(length(scores) == ncol(x) && all(is.finite(scores)), "F2_MRMRE_SCORE_NONFINITE")
  need(identical(mRMRe::featureNames(data), c(".SURV", names(x))),
       "F2_MRMRE_ASSOCIATION_NAMES_INVALID")
  list(
    schema_version = "1.0.0", implementation = paste0("mRMRe-", packageVersion("mRMRe"), "/association-ties-v1"),
    association_count = length(observed), finite_association_count = sum(is.finite(observed)),
    finite_mi_count = sum(is.finite(mi)), reference_count = length(reference),
    max_abs_reference_delta = delta, score_count = length(scores), finite_score_count = sum(is.finite(scores)),
    warning_count = 0L, warnings = list()
  )
}

run_selector_sensitivity_task <- function() {
  task <- spec$sensitivity_task
  need(
    is.list(task) && identical(sort(names(task)), sort(c(
      "candidate_parents", "covariate", "fit_ids", "fit_ids_sha256",
      "imputation", "method", "seed", "task_id", "fit_response",
      "task_spec_record", "task_spec_sha256"
    ))),
    "F2_SELECTOR_SENSITIVITY_TASK_INVALID"
  )
  method <- as.character(scalar(task$method))
  imputation <- as.integer(scalar(task$imputation))
  task_seed <- as.integer(scalar(task$seed))
  task_id <- as.character(scalar(task$task_id))
  candidates <- as.character(unlist(task$candidate_parents, use.names = FALSE))
  fit_ids <- as.character(unlist(task$fit_ids, use.names = FALSE))
  covariate <- task$covariate
  task_spec <- task$task_spec_record
  path <- as.character(scalar(covariate$path))
  need(
    method %in% c("MRMRE", "BORUTA") && imputation %in% seq_len(20L) &&
      task_seed > 0L && nzchar(task_id) && length(fit_ids) > 0L &&
      identical(as.character(scalar(task$task_spec_record$task_id)), task_id) &&
      identical(as.character(scalar(task$task_spec_record$method)), method) &&
      as.integer(scalar(task$task_spec_record$imputation)) == imputation &&
      as.integer(scalar(task$task_spec_record$seed)) == task_seed &&
      identical(sort(names(task_spec)), sort(c(
        "schema_version", "kind", "fold", "method", "imputation", "seed",
        "task_id", "outer_partition_id", "candidate_parent_set_sha256",
        "candidate_parent_count", "analysis_view_sha256", "fit_ids_sha256",
        "fit_covariate_member_set_sha256", "fit_response_sha256",
        "fit_response_size_bytes", "covariate_member", "predictor_catalog_sha256",
        "transform_registry_sha256", "seed_policy_sha256", "package_versions",
        "thread_capability"
      ))) &&
      identical(as.character(scalar(task_spec$schema_version)), "1.0.0") &&
      identical(as.character(scalar(task_spec$kind)), "PADML_F2_SELECTOR_SENSITIVITY_TASK_SPEC") &&
      as.integer(scalar(task_spec$candidate_parent_count)) == length(candidates) &&
      identical(as.character(scalar(task_spec$candidate_parent_set_sha256)), sha_object(as.list(candidates))) &&
      identical(as.character(scalar(task_spec$fit_ids_sha256)), as.character(scalar(task$fit_ids_sha256))) &&
      identical(as.character(scalar(task_spec$fit_response_sha256)), as.character(scalar(task$fit_response$sha256))) &&
      identical(as.numeric(scalar(task_spec$fit_response_size_bytes)), as.numeric(scalar(task$fit_response$size_bytes))) &&
      identical(as.character(scalar(task_spec$covariate_member$name)), as.character(scalar(covariate$name))) &&
      identical(as.character(scalar(task_spec$covariate_member$sha256)), as.character(scalar(covariate$sha256))) &&
      identical(as.numeric(scalar(task_spec$covariate_member$size_bytes)), as.numeric(scalar(covariate$size_bytes))) &&
      nzchar(as.character(scalar(task$task_spec_sha256))) &&
      identical(
        as.character(scalar(task$task_spec_sha256)),
        sha_object(task_spec)
      ) &&
      !anyDuplicated(fit_ids) &&
      identical(sha_object(as.list(fit_ids)), as.character(scalar(task$fit_ids_sha256))) &&
      file.exists(path) && !dir.exists(path) &&
      identical(as.numeric(file.info(path)$size), as.numeric(scalar(covariate$size_bytes))) &&
      identical(digest(file = path, algo = "sha256", serialize = FALSE), as.character(scalar(covariate$sha256))),
    "F2_SELECTOR_SENSITIVITY_INPUT_INVALID"
  )
  frame <- prepare_frame(read.csv(path, check.names = FALSE, stringsAsFactors = FALSE))
  need(identical(as.character(frame$Patient_ID), fit_ids), "F2_SELECTOR_SENSITIVITY_ROW_SET_INVALID")
  response <- read_response(task$fit_response)
  need(identical(as.character(response$Patient_ID), fit_ids), "F2_SELECTOR_SENSITIVITY_RESPONSE_ALIGNMENT_INVALID")
  rows <- setNames(variable_rows, vapply(variable_rows, `[[`, character(1), "name"))
  need(
    setequal(candidates, setdiff(names(rows)[vapply(rows, function(x)
      isTRUE(x$selector_eligible) || isTRUE(x$forced), logical(1))],
      if (identical(method, "MRMRE")) "Prior_LE_Surgery_cat" else character())) &&
      !anyDuplicated(candidates) && all(candidates %in% names(rows)) &&
      identical(intersect("AST_ALT", candidates), "AST_ALT") &&
      !"eGFR_calc" %in% candidates,
    "F2_SELECTOR_SENSITIVITY_CANDIDATE_SET_INVALID"
  )
  sensitivity <- lapply(candidates, function(parent) {
    row <- rows[[parent]]
    value <- frame[[parent]]
    if (row$type %in% c("binary", "ordered", "unordered")) {
      levels <- locked_levels(row)
      value <- factor(as.character(value), levels = levels, ordered = !identical(row$type, "unordered"))
      need(!anyNA(value), "F2_SELECTOR_SENSITIVITY_FACTOR_INVALID")
      return(value)
    }
    value <- suppressWarnings(as.numeric(value))
    need(all(is.finite(value)), "F2_SELECTOR_SENSITIVITY_NUMERIC_INVALID")
    representation <- row$selector_representation
    if (identical(representation, "LOG1P")) {
      need(all(value >= 0), "F2_SELECTOR_SENSITIVITY_LOG1P_DOMAIN_INVALID")
      value <- log1p(value)
    } else {
      need(
        representation %in% c("IDENTITY", "NATURAL_SPLINE_K3"),
        "F2_SELECTOR_SENSITIVITY_REPRESENTATION_INVALID"
      )
    }
    value
  })
  names(sensitivity) <- candidates
  x <- as.data.frame(sensitivity, check.names = FALSE, stringsAsFactors = FALSE)
  need(!anyNA(x), "F2_SELECTOR_SENSITIVITY_INPUT_INVALID")
  y <- Surv(response[[time_col]], response[[event_col]])
  set.seed(task_seed, kind = "L'Ecuyer-CMRG")
  if (identical(method, "MRMRE")) {
    need(
      identical(as.character(packageVersion("mRMRe")), as.character(scalar(task_spec$package_versions$mRMRe))) &&
        as.character(packageVersion("mRMRe")) %in% c("2.1.2.2.9002", "2.1.2.2.9003") &&
        identical(as.character(packageDescription("mRMRe")[["PADML-Correction"]]), "association-ties-v1") &&
        identical(as.character(packageDescription("mRMRe")[["PADML-Performance"]]), "complete-midranks-unit-concordance-v1") &&
        !any(vapply(x, is.factor, logical(1)) & !vapply(x, is.ordered, logical(1))),
      "F2_MRMRE_CAPABILITY_INVALID"
    )
    mRMRe::set.thread.count(1L)
    need(
      mRMRe::get.thread.count() %in% c(0L, 1L),
      "F2_MRMRE_THREAD_POLICY_INVALID"
    )
    data <- mRMRe::mRMR.data(data = data.frame(.SURV = y, x, check.names = FALSE))
    fit <- checked_sensitivity_engine(
      mRMRe::mRMR.classic(
        data = data, target_indices = 1L, feature_count = length(candidates),
        method = "exhaustive", continuous_estimator = "spearman",
        fixed_feature_count = 0L, outX = FALSE, bootstrap_count = 0L
      ),
      "MRMRE"
    )
    numerical_health <- checked_sensitivity_engine(checked_mrmre_numerics(fit, data, x, y), "MRMRE")
    solution <- mRMRe::solutions(fit)[[1L]]
    need(is.matrix(solution) && nrow(solution) == length(candidates) && ncol(solution) == 1L, "F2_MRMRE_RANK_DENOMINATOR_INVALID")
    ranking <- mRMRe::featureNames(data)[solution[, 1L]]
    need(
      length(ranking) == length(candidates) && !anyDuplicated(ranking) &&
        setequal(ranking, candidates),
      "F2_MRMRE_RANK_DENOMINATOR_INVALID"
    )
    method_result <- list(ranking = as.list(as.character(ranking)))
  } else {
    need(
      identical(as.character(packageVersion("Boruta")), "10.0.0") &&
        identical(as.character(packageVersion("ranger")), as.character(scalar(task_spec$package_versions$ranger))) &&
        as.character(packageVersion("ranger")) %in% c("0.18.0.9002", "0.18.0.9003"),
      "F2_BORUTA_CAPABILITY_INVALID"
    )
    importance_calls <- 0L
    checked_values <- 0L
    importance <- function(x, y, ...) {
      raw <- do.call(Boruta::getImpRfZ, c(list(
        x = x, y = y, num.trees = 500L, splitrule = "logrank", min.node.size = 3L,
        min.bucket = 3L, replace = TRUE, sample.fraction = 1,
        respect.unordered.factors = "partition", num.threads = 1L,
        seed = task_seed), list(...),
        if (identical(as.character(packageVersion("ranger")), "0.18.0.9003"))
          list(padml.boruta.tree.oob.only = TRUE) else list()))
      value <- checked_boruta_importance(raw, x)
      importance_calls <<- importance_calls + 1L
      checked_values <<- checked_values + length(value)
      value
    }
    fit <- checked_sensitivity_engine(
      Boruta::Boruta(
        x = x, y = y, pValue = .01, mcAdj = TRUE, maxRuns = 100L,
        doTrace = 0L, holdHistory = FALSE, getImp = importance
      ),
      "BORUTA"
    )
    decisions <- as.character(fit$finalDecision)
    names(decisions) <- names(fit$finalDecision)
    need(
      length(decisions) == length(candidates) && !anyDuplicated(names(decisions)) &&
        identical(names(decisions), candidates) &&
        all(decisions %in% c("Confirmed", "Tentative", "Rejected")),
      "F2_BORUTA_DECISION_DENOMINATOR_INVALID"
    )
    method_result <- list(decisions = as.list(decisions))
    names(method_result$decisions) <- candidates
    numerical_health <- list(
      schema_version = "1.0.0", implementation = "Boruta-getImpRfZ-pre-substitution-v1",
      importance_calls = importance_calls, checked_value_count = checked_values,
      length_checks = importance_calls, name_checks = importance_calls,
      finite_checks = importance_calls, nonfinite_count = 0L,
      warning_count = 0L, warnings = list()
    )
  }
  result <- list(
    schema_version = "1.1.0", kind = "PADML_F2_SELECTOR_SENSITIVITY_TASK",
    status = "PASS", task_id = task_id, method = method,
    imputation = imputation, seed = task_seed, candidate_parent_count = length(candidates),
    task_spec_sha256 = as.character(scalar(task$task_spec_sha256)),
    package_versions = list(
      mRMRe = if (identical(method, "MRMRE")) as.character(packageVersion("mRMRe")) else NULL,
      Boruta = if (identical(method, "BORUTA")) as.character(packageVersion("Boruta")) else NULL,
      ranger = if (identical(method, "BORUTA")) as.character(packageVersion("ranger")) else NULL
    ),
    thread_count = 1L, numerical_health = numerical_health, result = method_result
  )
  writeLines(canonical_json(result), output_path, useBytes = TRUE)
}

if (identical(action, "SELECTOR_SENSITIVITY_TASK")) {
  run_selector_sensitivity_task()
  quit(save = "no", status = 0L)
}

registered <- spec$registered_partitions
registered_kind <- as.character(scalar(registered$kind))
common_registered_valid <-
  identical(as.character(scalar(registered$status)), "PASS") &&
  as.integer(scalar(registered$fold)) == fold &&
  as.integer(scalar(registered$projected_partition_count)) > 0L &&
  length(c(registered$partitions, registered$diagnostic_partitions)) ==
    as.integer(scalar(registered$projected_partition_count))
raw_primary_search <- identical(action, "MODEL_PREDICTION_BATCH") &&
  family %in% c("RSF", "GBM_COX") &&
  identical(spec$primary_search_source$origin, "CURRENT_RAW_CONTEXT") &&
  identical(spec$primary_search_source$program_id, "PADML_F45_REBUILD_20260925") &&
  identical(spec$primary_search_source$channel, "PRIMARY") &&
  identical(spec$primary_search_source$family, family) &&
  identical(spec$primary_search_source$outer_fold, spec$fold) &&
  identical(spec$primary_search_source$heldout_center, spec$heldout_center) &&
  identical(spec$primary_search_source$registered_inputs_identity_sha256,
            spec$registered_inputs_identity_sha256) &&
  is.character(spec$registered_inputs_identity_sha256) &&
  length(spec$registered_inputs_identity_sha256) == 1L &&
  grepl("^[0-9a-f]{64}$", spec$registered_inputs_identity_sha256) &&
  length(registered$diagnostic_partitions) == 0L &&
  all(vapply(registered$partitions, function(p)
    as.character(scalar(p$kind)) %in% c("INNER", "STOP"), logical(1)))
f2_registered_valid <-
  identical(registered_kind, "PADML_F2_REGISTERED_PARTITION_INPUTS") &&
  identical(execution_scope, "F2_OUTER_DEVELOPMENT") &&
  as.integer(scalar(registered$outer_count)) == 1L &&
  as.integer(scalar(registered$inner_count)) == 15L &&
  as.integer(scalar(registered$stop_count)) == 15L &&
  (as.integer(scalar(registered$diagnostic_count)) == 5L ||
    (raw_primary_search && as.integer(scalar(registered$diagnostic_count)) == 0L)) &&
  as.integer(scalar(registered$view_count)) == 62L
f5_registered_valid <-
  identical(registered_kind, "PADML_F5_REGISTERED_PARTITION_INPUTS") &&
  as.integer(scalar(registered$outer_count)) == 0L &&
  as.integer(scalar(registered$diagnostic_count)) == 0L && (
    (identical(execution_scope, "F5_FULL_DEVELOPMENT_A16") &&
      as.integer(scalar(registered$inner_count)) == 5L &&
      as.integer(scalar(registered$stop_count)) == 0L &&
      as.integer(scalar(registered$full_count)) == 1L &&
      as.integer(scalar(registered$view_count)) == 6L) ||
    (identical(execution_scope, "F5_FULL_DEVELOPMENT_SEARCH") &&
      as.integer(scalar(registered$inner_count)) == 15L &&
      as.integer(scalar(registered$full_count)) == 0L &&
      ((as.integer(scalar(registered$stop_count)) == 15L &&
        as.integer(scalar(registered$view_count)) == 30L) ||
       (identical(family, "RSF") &&
        identical(as.character(unlist(spec$final_search_source$program_id, use.names=FALSE)),
          "PADML_F45_REBUILD_20260925") &&
        as.integer(scalar(registered$stop_count)) == 0L &&
        as.integer(scalar(registered$view_count)) == 15L)))
  )
f4_search_registered_valid <-
  identical(registered_kind, "PADML_F4_FULL_PIPELINE_REGISTERED_INPUTS") &&
  identical(execution_scope, "F4_FULL_PIPELINE_SEARCH") &&
  as.integer(scalar(registered$outer_count)) == 0L &&
  as.integer(scalar(registered$diagnostic_count)) == 0L &&
  as.integer(scalar(registered$full_count)) == 0L &&
  as.integer(scalar(registered$inner_count)) == 15L && (
    (identical(family, "RSF") && as.integer(scalar(registered$stop_count)) == 0L &&
      as.integer(scalar(registered$view_count)) == 15L) ||
    (identical(family, "GBM_COX") && as.integer(scalar(registered$stop_count)) == 15L &&
      as.integer(scalar(registered$view_count)) == 30L)
  )
a12_registered_valid <-
  identical(registered_kind, "PADML_F5_A12_REGISTERED_INPUTS") && a12_search &&
  as.integer(scalar(registered$outer_count)) == 1L &&
  as.integer(scalar(registered$inner_count)) == 15L &&
  as.integer(scalar(registered$diagnostic_count)) == 0L && (
    (family %in% c("ELASTIC_NET_COX", "RSF") && as.integer(scalar(registered$stop_count)) == 0L &&
      as.integer(scalar(registered$view_count)) == 32L) ||
    (identical(family, "GBM_COX") && as.integer(scalar(registered$stop_count)) == 15L &&
      as.integer(scalar(registered$view_count)) == 62L))
need(
  common_registered_valid && (f2_registered_valid || f5_registered_valid || f4_search_registered_valid || a12_registered_valid),
  "F2_R_REGISTERED_PARTITION_DENOMINATOR_INVALID"
)

required_imputations <- if (identical(action, "MODEL_PREDICTION_BATCH")) {
  tasks <- spec$producer_tasks
  need(is.list(tasks) && length(tasks) > 0L, "F2_R_PRODUCER_TASK_SET_INVALID")
  sort(unique(vapply(tasks, function(task) as.integer(scalar(task$imputation)), integer(1))))
} else {
  seq_len(imputation_count)
}
need(
  length(required_imputations) > 0L &&
    all(required_imputations %in% seq_len(imputation_count)),
  "F2_R_IMPUTATION_SCOPE_INVALID"
)

load_partition <- function(record) {
  cache <- get0(".padml_r_batch_design_cache", envir=.GlobalEnv, inherits=FALSE)
  key <- paste0("partition-", sha_object(list(record=record, imputations=required_imputations,
    columns=variable_rows, time=time_col, event=event_col, a12=a12_search,
    branch=spec$a12_source$branch)))
  input_dir <- as.character(scalar(record$covariates$input_dir))
  paths <- c(file.path(input_dir,sprintf("imp%02d.csv",required_imputations)),
             as.character(scalar(record$fit_response$path)))
  stamps <- file.info(paths)[,c("size","mtime","ctime"),drop=FALSE]
  need(!anyNA(stamps) && all(Sys.readlink(paths)==""), "F2_R_INPUT_SOURCE_INVALID")
  cached <- if (is.null(cache)) NULL else get0(key,envir=cache,inherits=FALSE)
  stable <- all(as.numeric(Sys.time())-as.numeric(stamps$mtime)>2 &
                as.numeric(Sys.time())-as.numeric(stamps$ctime)>2)
  if (!is.null(cached) && identical(stamps,cached$stamps) && stable) return(cached$value)
  if (!is.null(cache)) {
    pins <- c(record$covariates$members[required_imputations],list(record$fit_response))
    need(length(pins)==length(paths),"F2_R_INPUT_SOURCE_INVALID")
    for (i in seq_along(paths)) need(
      identical(as.numeric(stamps$size[[i]]),as.numeric(scalar(pins[[i]]$size_bytes))) &&
        identical(digest(file=paths[[i]],algo="sha256",serialize=FALSE),as.character(scalar(pins[[i]]$sha256))),
      "F2_R_INPUT_SOURCE_DRIFT")
    if (!is.null(cached)) {
      cache_r_preparation(cache,key,list(stamps=stamps,value=cached$value))
      return(cached$value)
    }
  }
  frames <- vector("list", imputation_count)
  for (index in required_imputations) {
    path <- file.path(input_dir, sprintf("imp%02d.csv", index))
    need(file.exists(path), "F2_R_IMPUTATION_MISSING")
    frames[[index]] <- prepare_frame(
      read.csv(path, check.names = FALSE, stringsAsFactors = FALSE), a12=a12_search,
      a12_total=a12_search && as.character(scalar(spec$a12_source$branch)) %in%
        c("WITHOUT_AST_ALT_TOTAL", "A12_WITHOUT_AST_ALT_TOTAL", "OUTER_SELECTED_FAMILY_NO_AAR_REDEVELOPMENT")
    )
  }
  application_ids <- as.character(unlist(record$application_ids, use.names = FALSE))
  need(
    length(application_ids) > 0L && !anyDuplicated(application_ids) &&
      all(vapply(
        frames[required_imputations],
        function(data) identical(as.character(data$Patient_ID), application_ids),
        logical(1)
      )),
    "F2_R_IMPUTATION_ROW_ORDER_DRIFT"
  )
  fit_ids <- as.character(unlist(record$fit_ids, use.names = FALSE))
  evaluation_ids <- as.character(unlist(record$evaluation_ids, use.names = FALSE))
  full_scope <- identical(as.character(scalar(record$kind)), "FINAL_FULL_DATA")
  need(
    length(fit_ids) > 0L && length(evaluation_ids) > 0L && !anyDuplicated(fit_ids) &&
      !anyDuplicated(evaluation_ids) && (
        (!full_scope && !length(intersect(fit_ids, evaluation_ids)) &&
          setequal(c(fit_ids, evaluation_ids), application_ids)) ||
        (full_scope && identical(fit_ids, evaluation_ids) &&
          identical(fit_ids, application_ids))
      ),
    "F2_R_REGISTERED_PARTITION_ROW_SET_INVALID"
  )
  need(
    identical(sha_object(as.list(evaluation_ids)), as.character(scalar(record$evaluation_ids_sha256))),
    "F2_R_REGISTERED_PARTITION_ROW_SET_INVALID"
  )
  fit_response <- read_response(record$fit_response)
  need(
    identical(as.character(fit_response$Patient_ID), fit_ids),
    "F2_R_REGISTERED_RESPONSE_ROW_SET_INVALID"
  )
  value <- list(
    kind = as.character(scalar(record$kind)), partition_id = as.character(scalar(record$partition_id)),
    repeat_index = as.integer(scalar(record[["repeat"]])), inner_fold = as.integer(scalar(record$inner_fold)),
    frames = frames, fit_ids = fit_ids, evaluation_ids = evaluation_ids,
    fit_response = fit_response, covariate_pins=record$covariates$members,
    fit_response_pin=record$fit_response$sha256
  )
  cache_r_preparation(cache,key,list(stamps=stamps,value=value))
  value
}

partitions <- lapply(c(registered$partitions, registered$diagnostic_partitions), load_partition)
need(
  identical(
    sort(vapply(partitions, function(value) value$partition_id, character(1))),
    sort(as.character(unlist(registered$projected_partition_ids, use.names = FALSE)))
  ),
  "F2_R_REGISTERED_PARTITION_SCOPE_INVALID"
)
partition <- function(kind, repeat_index = 0L, inner_fold = 0L) {
  matches <- Filter(function(value) {
    identical(value$kind, kind) && value$repeat_index == repeat_index && value$inner_fold == inner_fold
  }, partitions)
  need(length(matches) == 1L, "F2_R_REGISTERED_PARTITION_LOOKUP_INVALID")
  matches[[1L]]
}

fit_frame <- function(value, imputation) {
  source <- value$frames[[imputation]]
  rows <- match(value$fit_ids, source$Patient_ID)
  need(!anyNA(rows), "F2_R_FIT_COVARIATE_ROW_SET_INVALID")
  data <- source[rows, , drop = FALSE]
  response <- value$fit_response
  need(identical(as.character(data$Patient_ID), as.character(response$Patient_ID)), "F2_R_FIT_RESPONSE_ALIGNMENT_INVALID")
  data[[time_col]] <- response[[time_col]]
  data[[event_col]] <- response[[event_col]]
  data
}

evaluation_frame <- function(value, imputation) {
  source <- value$frames[[imputation]]
  rows <- match(value$evaluation_ids, source$Patient_ID)
  need(!anyNA(rows), "F2_R_EVALUATION_COVARIATE_ROW_SET_INVALID")
  data <- source[rows, , drop = FALSE]
  need(!time_col %in% names(data) && !event_col %in% names(data), "F2_R_EVALUATION_RESPONSE_VISIBLE")
  data
}

seal_prediction <- function(ids, survival, horizons) {
  need(nrow(survival) == length(ids) && all(is.finite(survival)), "F2_R_PREDICTION_SEAL_INVALID")
  payload <- list(
    schema_version = "1.0.0",
    kind = "PADML_F2_PREDICTION_MATRIX",
    patient_ids = as.list(as.character(ids)),
    horizons = as.list(as.integer(horizons)),
    survival = lapply(seq_len(nrow(survival)), function(index) as.list(as.numeric(survival[index, ])))
  )
  sha_object(payload)
}

validate_compiled_conflicts <- function(selected) {
  groups <- spec$predictors$conflict_map
  need(identical(sort(names(groups)), sort(c("ANTHROPOMETRY", "EXPOSURE_RATIO", "RENAL_FUNCTION"))), "F2_SELECTOR_REPRESENTATION_CONFLICT")
  for (group in groups) {
    members <- c(
      as.character(scalar(group$main_parent)),
      as.character(unlist(group$excluded_sources, use.names = FALSE))
    )
    if (!is.null(group$sensitivity_replacement)) members <- c(members, as.character(scalar(group$sensitivity_replacement)))
    need(sum(selected %in% members) <= 1L, "F2_SELECTOR_REPRESENTATION_CONFLICT")
  }
  invisible(TRUE)
}

apply_design_recipe <- function(data, selected, recipe, purpose) {
  need(
    purpose %in% c("SELECTOR", "COX_PH", "ELASTIC_NET_COX", "RSF", "GBM_COX", "FPM_TVC_SET_A"),
    "F2_R_DESIGN_INVALID"
  )
  validate_compiled_conflicts(selected)
  reference_coded <- purpose %in% c("COX_PH", "FPM_TVC_SET_A")
  raw_continuous <- purpose %in% c("RSF", "GBM_COX")
  rows <- setNames(variable_rows, vapply(variable_rows, `[[`, character(1), "name"))
  recipe_rows <- if (is.null(recipe)) list() else setNames(
    recipe$representations,
    vapply(recipe$representations, function(row) as.character(scalar(row$parent)), character(1))
  )
  if (!raw_continuous) {
    need(
      !is.null(recipe) && identical(as.character(scalar(recipe$recipe_schema_version)), "1.0.0") &&
        identical(as.character(scalar(recipe$kind)), "PADML_F2_TRANSFORM_RECIPE") &&
        identical(as.character(scalar(recipe$transform_registry_sha256)), as.character(scalar(spec$predictors$transform_registry_sha256))),
      "F2_R_TRANSFORM_RECIPE_INVALID"
    )
  }
  matrices <- lapply(selected, function(name) {
    row <- rows[[name]]
    need(!is.null(row), "F2_R_DESIGN_INVALID")
    if (row$type %in% c("binary", "ordered", "unordered")) {
      contract <- categorical_contract(row)
      need(!is.null(contract), "F2_R_DESIGN_INVALID")
      formula <- if (reference_coded) as.formula(sprintf("~ `%s`", name)) else as.formula(sprintf("~ `%s` - 1", name))
      contrasts_arg <- if (reference_coded) {
        contr.treatment(contract$levels, base = match(contract$reference, contract$levels), contrasts = TRUE)
      } else {
        result <- diag(length(contract$levels))
        dimnames(result) <- list(contract$levels, contract$levels)
        result
      }
      x <- model.matrix(
        formula, data, contrasts.arg = setNames(list(contrasts_arg), name),
        na.action = na.fail
      )
      if (reference_coded) x <- x[, colnames(x) != "(Intercept)", drop = FALSE]
      need(ncol(x) > 0L, "F2_R_DESIGN_INVALID")
      return(list(parent = name, x = x))
    }
    value <- suppressWarnings(as.numeric(data[[name]]))
    need(all(is.finite(value)), "F2_R_NUMERIC_PREDICTOR_INVALID")
    if (raw_continuous) {
      x <- matrix(value, ncol = 1L, dimnames = list(NULL, name))
    } else {
      recipe_row <- recipe_rows[[name]]
      need(!is.null(recipe_row), "F2_R_TRANSFORM_RECIPE_INVALID")
      representation <- as.character(scalar(recipe_row$representation))
      columns <- as.character(unlist(recipe_row$design_columns, use.names = FALSE))
      if (identical(representation, "IDENTITY")) {
        need(length(columns) == 1L && identical(columns, name), "F2_R_TRANSFORM_RECIPE_INVALID")
        x <- matrix(value, ncol = 1L, dimnames = list(NULL, columns))
      } else if (identical(representation, "LOG1P")) {
        need(length(columns) == 1L && all(value >= 0), "F2_RECIPE_LOG1P_DOMAIN_INVALID")
        x <- matrix(log1p(value), ncol = 1L, dimnames = list(NULL, columns))
      } else if (identical(representation, "NATURAL_SPLINE_K3")) {
        parameters <- recipe_row$parameters
        boundary <- as.numeric(unlist(parameters$boundary_knots, use.names = FALSE))
        interior <- as.numeric(unlist(parameters$interior_knots, use.names = FALSE))
        need(length(columns) == 2L && length(boundary) == 2L && length(interior) == 1L && boundary[[1L]] < interior[[1L]] && interior[[1L]] < boundary[[2L]], "F2_RECIPE_SPLINE_PARAMETER_INVALID")
        x <- splines::ns(value, knots = interior, Boundary.knots = boundary, intercept = FALSE)
        colnames(x) <- columns
        need(identical(dim(x), c(length(value), 2L)) && all(is.finite(x)), "F2_RECIPE_SPLINE_APPLICATION_DESIGN_INVALID")
      } else {
        fail("F2_R_TRANSFORM_RECIPE_INVALID")
      }
    }
    list(parent = name, x = x)
  })
  x <- do.call(cbind, lapply(matrices, `[[`, "x"))
  parent_map <- do.call(rbind, lapply(matrices, function(value) data.frame(
    parent = rep(value$parent, ncol(value$x)), column = colnames(value$x), stringsAsFactors = FALSE
  )))
  need(
    nrow(x) == nrow(data) && ncol(x) > 0L && all(is.finite(x)) &&
      !anyDuplicated(colnames(x)) && identical(as.character(parent_map$column), colnames(x)),
    "F2_R_DESIGN_INVALID"
  )
  list(x = x, parent_map = parent_map)
}

ordered_parent_column_map <- function(parent_map, selected) {
  lapply(selected, function(parent) {
    columns <- as.character(parent_map$column[parent_map$parent == parent])
    need(length(columns) > 0L && !anyDuplicated(columns), "F2_R_DESIGN_COLUMN_MAP_INVALID")
    list(parent = parent, columns = as.list(columns))
  })
}

selector <- spec$selector_from_dependency
selected_parents <- if (is.null(selector)) character() else as.character(unlist(selector$selected_parents))
if (!identical(action, "MODEL_PREDICTION_BATCH")) {
  need(length(selected_parents) > 0L && "AST_ALT" %in% selected_parents, "F2_R_SELECTOR_DEPENDENCY_INVALID")
}

breslow <- function(time, event, risk) {
  order <- order(time, method="radix")
  ordered_time <- time[order]
  starts <- c(1L, which(diff(ordered_time) != 0) + 1L)
  groups <- rep.int(seq_along(starts), diff(c(starts, length(time)+1L)))
  deaths <- as.numeric(rowsum(as.integer(event[order] == 1L), groups, reorder=FALSE))
  included <- deaths > 0L
  denominators <- rev(cumsum(rev(risk[order])))[starts][included]
  list(times=ordered_time[starts][included], cumulative=cumsum(deaths[included] / denominators))
}

survival_from_risk <- function(base, risk, horizons) {
  hazards <- vapply(horizons, function(value) {
    index <- which(base$times <= value)
    if (!length(index)) 0 else base$cumulative[max(index)]
  }, numeric(1))
  exp(-outer(risk, hazards))
}

censor_survival_step <- function(time, event) {
  need(
    length(time) > 0L && length(time) == length(event) &&
      all(is.finite(time)) && all(time > 0) && all(event %in% c(0L, 1L)),
    "F2_EVALUATION_RESPONSE_DOMAIN_INVALID"
  )
  step_times <- sort(unique(time))
  current <- 1
  step_survival <- numeric(length(step_times))
  for (index in seq_along(step_times)) {
    value <- step_times[[index]]
    at_risk <- sum(time >= value)
    censored <- sum(time == value & event == 0L)
    need(at_risk > 0L && censored <= at_risk, "F2_IPCW_CONTEXT_INVALID")
    current <- current * (1 - censored / at_risk)
    step_survival[[index]] <- current
  }
  need(
    all(is.finite(step_survival)) && all(step_survival >= 0 & step_survival <= 1) &&
      all(diff(step_survival) <= 0),
    "F2_IPCW_CONTEXT_INVALID"
  )
  list(times = step_times, survival = step_survival)
}

censor_survival_at <- function(step, query, side) {
  need(
    identical(sort(names(step)), c("survival", "times")) &&
      length(step$times) > 0L && length(step$times) == length(step$survival) &&
      (identical(side, "LEFT") || identical(side, "RIGHT")),
    "F2_IPCW_CONTEXT_INVALID"
  )
  need(
    all(is.finite(query)) && all(is.finite(step$times)) &&
      all(is.finite(step$survival)) && all(diff(step$times) > 0) &&
      all(step$survival >= 0 & step$survival <= 1) &&
      all(diff(step$survival) <= 0),
    "F2_IPCW_CONTEXT_INVALID"
  )
  result <- vapply(query, function(value) {
    index <- if (identical(side, "LEFT")) {
      sum(step$times < value)
    } else {
      sum(step$times <= value)
    }
    if (index == 0L) 1 else step$survival[[index]]
  }, numeric(1))
  need(all(result > 0), "F2_IPCW_SUPPORT_UNAVAILABLE")
  result
}

brier_score <- function(train_time, train_event, test_time, test_event, predicted, horizons) {
  step <- censor_survival_step(train_time, train_event)
  scores <- numeric(length(horizons))
  for (index in seq_along(horizons)) {
    horizon <- horizons[[index]]
    truth <- as.numeric(test_time > horizon)
    weights <- numeric(length(test_time))
    event_rows <- which(test_time <= horizon & test_event == 1L)
    if (length(event_rows)) {
      weights[event_rows] <- 1 / censor_survival_at(
        step, test_time[event_rows], "LEFT"
      )
    }
    survivor_rows <- which(test_time > horizon)
    if (length(survivor_rows)) {
      weights[survivor_rows] <- 1 / censor_survival_at(
        step, horizon, "RIGHT"
      )[[1L]]
    }
    scores[[index]] <- mean(weights * (truth - predicted[, index])^2)
  }
  mean(scores[horizons <= 24])
}

glmnet_engine_design <- function(train_design, test_design, penalty, a12=FALSE) {
  need(
    is.matrix(train_design) && is.matrix(test_design) &&
      ncol(train_design) >= 1L &&
      identical(colnames(train_design), colnames(test_design)) &&
      length(penalty) == ncol(train_design),
    "F2_ELASTIC_ENGINE_DESIGN_INVALID"
  )
  if (ncol(train_design) >= 2L) {
    return(list(
      train = train_design, test = test_design,
      penalty = penalty, inert_column = NULL
    ))
  }
  need(
    (identical(colnames(train_design), "AST_ALT") && identical(as.numeric(penalty), 0) && !a12) ||
      (a12 && !any(colnames(train_design) %in% c("AST", "ALT", "AST_ALT", "PADML_GLMNET_INERT_ZERO")) &&
        identical(as.numeric(penalty), 1)),
    "F2_ELASTIC_SINGLE_COLUMN_DESIGN_INVALID"
  )
  inert_column <- "PADML_GLMNET_INERT_ZERO"
  train <- cbind(train_design, PADML_GLMNET_INERT_ZERO = 0)
  test <- cbind(test_design, PADML_GLMNET_INERT_ZERO = 0)
  need(
    all(train[, inert_column] == 0) && all(test[, inert_column] == 0),
    "F2_ELASTIC_INERT_COLUMN_INVALID"
  )
  list(
    train = train, test = test, penalty = c(penalty, 1),
    inert_column = inert_column
  )
}

validate_cox_lambda_upper_bound <- function(provenance, alpha) {
  required <- c(
    "schema_version", "kind", "glmnet_version", "family", "cox_ties",
    "alpha", "standardize", "penalty_factor_identity_sha256",
    "pilot_requested_nlambda", "pilot_returned_nlambda",
    "pilot_lambda_head", "resolved_lambda_max", "glmnet_big",
    "sentinel_equivalent"
  )
  need(
    identical(sort(names(provenance)), sort(required)) &&
      identical(as.character(scalar(provenance$schema_version)), "1.0.0") &&
      identical(as.character(scalar(provenance$kind)), "PADML_F2_ELASTIC_LAMBDA_UPPER_BOUND_V1") &&
      identical(as.character(scalar(provenance$glmnet_version)), as.character(packageVersion("glmnet"))) &&
      identical(as.character(scalar(provenance$family)), "cox") &&
      identical(as.character(scalar(provenance$cox_ties)), "breslow") &&
      identical(as.numeric(scalar(provenance$alpha)), as.numeric(alpha)) &&
      isTRUE(scalar(provenance$standardize)) &&
      grepl("^[0-9a-f]{64}$", as.character(scalar(provenance$penalty_factor_identity_sha256))) &&
      identical(as.integer(scalar(provenance$pilot_requested_nlambda)), 100L) &&
      as.integer(scalar(provenance$pilot_returned_nlambda)) >= 3L,
    "F2_ELASTIC_LAMBDA_UPPER_BOUND_INVALID"
  )
  pilot_head <- as.numeric(unlist(provenance$pilot_lambda_head, use.names = FALSE))
  lambda_max <- as.numeric(scalar(provenance$resolved_lambda_max))
  big <- as.numeric(scalar(provenance$glmnet_big))
  sentinel_equivalent <- abs(lambda_max - big) <= sqrt(.Machine$double.eps) * max(1, abs(big))
  need(
    length(pilot_head) == 3L && all(is.finite(pilot_head)) &&
      all(pilot_head > 0) && all(diff(pilot_head) < 0) &&
      is.finite(lambda_max) && lambda_max > 0 &&
      identical(lambda_max, pilot_head[[1L]]) && is.finite(big) && big > 0 &&
      identical(isTRUE(scalar(provenance$sentinel_equivalent)), sentinel_equivalent) &&
      !sentinel_equivalent,
    "F2_ELASTIC_LAMBDA_SENTINEL_INVALID"
  )
  lambda_max
}

data_driven_cox_lambda_upper_bound <- function(train_design, time, event, alpha, penalty, a12=FALSE,
                                             prepared_identity=NULL) {
  need(
    is.matrix(train_design) && ncol(train_design) >= 2L &&
      length(penalty) == ncol(train_design) &&
      all(is.finite(penalty)) && all(penalty >= 0),
    "F2_ELASTIC_LAMBDA_UPPER_BOUND_INPUT_INVALID"
  )
  lambda_upper_cache <- get0("lambda_upper_cache", envir=environment(data_driven_cox_lambda_upper_bound), inherits=FALSE)
  if (is.null(lambda_upper_cache)) {
    lambda_upper_cache <- new.env(hash=TRUE, parent=emptyenv())
    assign("lambda_upper_cache", lambda_upper_cache, envir=environment(data_driven_cox_lambda_upper_bound))
  }
  if (is.null(prepared_identity))
    prepared_identity <- digest(list(train_design, time, event, penalty, a12), algo="sha256")
  need(is.character(prepared_identity) && length(prepared_identity)==1L &&
    grepl("^[0-9a-f]{64}$",prepared_identity),"F2_ELASTIC_LAMBDA_UPPER_BOUND_INPUT_INVALID")
  key <- digest(list(prepared_identity, alpha, glmnet.control()), algo="sha256")
  if (exists(key, lambda_upper_cache, inherits=FALSE)) return(get(key, lambda_upper_cache))
  # Keep the original automatic 100-point grid and its native first three
  # solutions (fix.lam needs points 2 and 3). Only the unused pilot suffix is
  # omitted; restore controls before fitting the registered 150-point path.
  controls <- glmnet.control()
  pilot <- tryCatch({
    glmnet.control(mnlam=3L, fdev=1, devmax=0)
    glmnet(
      train_design, Surv(time, event), family = "cox", cox.ties = "breslow",
      alpha = alpha, nlambda = 100L, lambda.min.ratio = 0.0001,
      penalty.factor = penalty, standardize = TRUE
    )
  }, finally=do.call(glmnet.control, controls))
  pilot_lambda <- as.numeric(pilot$lambda)
  if (a12 && "PADML_GLMNET_INERT_ZERO" %in% colnames(train_design)) {
    beta <- as.matrix(coef(pilot))
    need("PADML_GLMNET_INERT_ZERO" %in% rownames(beta) &&
           all(is.finite(beta["PADML_GLMNET_INERT_ZERO", ])) &&
           all(beta["PADML_GLMNET_INERT_ZERO", ] == 0), "F2_ELASTIC_INERT_COLUMN_INVALID")
  }
  big <- as.numeric(glmnet.control()$big)
  need(
    length(pilot$jerr) == 1L && is.finite(pilot$jerr) && pilot$jerr == 0L &&
      length(pilot_lambda) >= 3L && all(is.finite(pilot_lambda)) &&
      all(pilot_lambda > 0) && all(diff(pilot_lambda) < 0),
    "F2_ELASTIC_LAMBDA_UPPER_BOUND_INVALID"
  )
  lambda_max <- pilot_lambda[[1L]]
  sentinel_equivalent <- abs(lambda_max - big) <= sqrt(.Machine$double.eps) * max(1, abs(big))
  provenance <- list(
    schema_version = "1.0.0",
    kind = "PADML_F2_ELASTIC_LAMBDA_UPPER_BOUND_V1",
    glmnet_version = as.character(packageVersion("glmnet")),
    family = "cox",
    cox_ties = "breslow",
    alpha = alpha,
    standardize = TRUE,
    penalty_factor_identity_sha256 = sha_object(list(
      design_columns = as.list(colnames(train_design)),
      penalty_factor = as.list(as.numeric(penalty))
    )),
    pilot_requested_nlambda = 100L,
    pilot_returned_nlambda = length(pilot_lambda),
    pilot_lambda_head = as.list(pilot_lambda[seq_len(3L)]),
    resolved_lambda_max = lambda_max,
    glmnet_big = big,
    sentinel_equivalent = sentinel_equivalent
  )
  validate_cox_lambda_upper_bound(provenance, alpha)
  if (length(ls(lambda_upper_cache)) >= 256L) rm(list=ls(lambda_upper_cache), envir=lambda_upper_cache)
  assign(key, provenance, lambda_upper_cache)
  provenance
}

elastic_locked_parameters <- function(parameters) {
  if (!is.null(parameters$ratio_by_imputation)) {
    imp <- as.integer(scalar(parameters$imputation_index))
    need(
      length(imp) == 1L && imp %in% seq_len(20L) &&
        length(parameters$ratio_by_imputation) == 20L &&
        length(parameters$lambda_by_imputation) == 20L &&
        length(parameters$lambda_upper_bound_by_imputation) == 20L &&
        is.null(parameters[["ratio"]]) && is.null(parameters[["lambda"]]) &&
        is.null(parameters[["lambda_upper_bound"]]),
      "F2_ELASTIC_IMPUTATION_PARAMETER_INVALID"
    )
    parameters <- list(
      alpha = parameters$alpha,
      ratio = parameters$ratio_by_imputation[[imp]],
      lambda = parameters$lambda_by_imputation[[imp]],
      lambda_upper_bound = parameters$lambda_upper_bound_by_imputation[[imp]]
    )
  }
  alpha <- as.numeric(scalar(parameters[["alpha"]]))
  ratio <- as.numeric(scalar(parameters[["ratio"]]))
  lambda <- as.numeric(scalar(parameters[["lambda"]]))
  need(
    length(alpha) == 1L && is.finite(alpha) && alpha >= 0.01 && alpha <= 1 &&
      length(ratio) == 1L && is.finite(ratio) && ratio >= 0.0001 && ratio <= 1 &&
      length(lambda) == 1L && is.finite(lambda) && lambda > 0,
    "F2_ELASTIC_IMPUTATION_PARAMETER_INVALID"
  )
  lambda_max <- validate_cox_lambda_upper_bound(parameters$lambda_upper_bound, alpha)
  need(
    abs(lambda - lambda_max * ratio) <= 1e-12 * max(1, abs(lambda)),
    "F2_ELASTIC_SELECTED_PARAMETER_DRIFT"
  )
  list(alpha = alpha, ratio = ratio, lambda = lambda, lambda_max = lambda_max,
       lambda_upper_bound = parameters$lambda_upper_bound)
}

round_half_up_decimal_product <- function(value, multiplier) {
  text <- as.character(scalar(value))
  multiplier <- as.integer(multiplier)
  need(
    grepl("^(0(\\.[0-9]+)?|1(\\.0+)?)$", text) && multiplier > 0L,
    "F2_RSF_MTRY_DECIMAL_INVALID"
  )
  scale <- if (grepl("\\.", text)) nchar(sub("^[^.]*\\.", "", text)) else 0L
  digits <- as.integer(strsplit(gsub("\\.", "", text), "", fixed = TRUE)[[1L]])
  carry <- 0L
  product <- integer(length(digits))
  for (index in rev(seq_along(digits))) {
    current <- digits[[index]] * multiplier + carry
    product[[index]] <- current %% 10L
    carry <- current %/% 10L
  }
  prefix <- integer()
  while (carry > 0L) {
    prefix <- c(carry %% 10L, prefix)
    carry <- carry %/% 10L
  }
  product_text <- paste0(c(prefix, product), collapse = "")
  if (nchar(product_text) <= scale) {
    product_text <- paste0(
      paste0(rep("0", scale + 1L - nchar(product_text)), collapse = ""),
      product_text
    )
  }
  split <- nchar(product_text) - scale
  whole <- as.integer(substr(product_text, 1L, split))
  first_fraction <- if (scale) as.integer(substr(product_text, split + 1L, split + 1L)) else 0L
  rounded <- whole + as.integer(first_fraction >= 5L)
  need(rounded >= 0L && rounded <= multiplier, "F2_RSF_MTRY_DECIMAL_INVALID")
  rounded
}

rsf_survival_at_horizons <- function(predicted_survival, death_times, horizons) {
  need(
    is.matrix(predicted_survival) && nrow(predicted_survival) > 0L &&
      ncol(predicted_survival) == length(death_times) && length(death_times) > 0L &&
      all(is.finite(predicted_survival)) &&
      all(predicted_survival >= 0 & predicted_survival <= 1) &&
      all(is.finite(death_times)) && all(diff(death_times) > 0) &&
      length(horizons) > 0L && all(is.finite(horizons)),
    "F2_RSF_PREDICTION_DOMAIN_INVALID"
  )
  horizon_indices <- findInterval(horizons, death_times)
  survival <- matrix(
    1, nrow = nrow(predicted_survival), ncol = length(horizons)
  )
  observed_horizons <- which(horizon_indices > 0L)
  if (length(observed_horizons)) {
    survival[, observed_horizons] <- predicted_survival[
      , pmin(length(death_times), horizon_indices[observed_horizons]),
      drop = FALSE
    ]
  }
  need(
    all(is.finite(survival)) && all(survival >= 0 & survival <= 1) &&
      all(apply(survival, 1L, function(row) all(diff(row) <= 1e-10))),
    "F2_RSF_PREDICTION_DOMAIN_INVALID"
  )
  survival
}

validate_coxph_fit_health <- function(fit, warning_count, expected_columns) {
  coefficients <- fit$coefficients
  covariance <- fit$var
  iterations <- as.integer(fit$iter)
  expected_columns <- as.integer(expected_columns)
  need(
    inherits(fit, "coxph") && identical(as.integer(warning_count), 0L) &&
      expected_columns > 0L && length(coefficients) == expected_columns &&
      all(is.finite(coefficients)) && !anyNA(coefficients) &&
      is.matrix(covariance) && identical(dim(covariance), c(expected_columns, expected_columns)) &&
      all(is.finite(covariance)) &&
      max(abs(covariance - t(covariance))) <= 1e-10 &&
      qr(covariance)$rank == expected_columns && all(diag(covariance) >= 0) &&
      length(fit$loglik) == 2L && all(is.finite(fit$loglik)) &&
      length(iterations) == 1L && !is.na(iterations) && iterations >= 0L,
    "F2_COX_PH_FIT_HEALTH_INVALID"
  )
  list(
    converged = TRUE,
    warning_count = 0L,
    coefficient_count = expected_columns,
    covariance_rank = expected_columns,
    iteration_count = iterations
  )
}

fpm_constraint_identity <- function() {
  correction <- packageDescription("rstpm2")[["PADML-Correction"]]
  need(
    identical(as.character(packageVersion("rstpm2")), "1.7.1.9011") &&
      identical(correction, "ph-continuous-domain-bfgs-v1") &&
      identical(packageDescription("rstpm2")[["PADML-Initialization"]],
                "cox-eps-1e-11-iter20-v1"),
    "F2_FPM_CONSTRAINT_CORRECTION_MISSING"
  )
  correction
}

fpm_evaluate_checks <- function(expressions, envir = parent.frame()) {
  force(envir)
  lapply(expressions, function(expression) {
    tryCatch({
      value <- eval(expression, envir)
      list(passed = isTRUE(value), value = value, evaluation_error = NULL)
    }, error = function(condition) list(
      passed = FALSE, value = NULL, evaluation_error = conditionMessage(condition)
    ))
  })
}

fpm_require_checks <- function(checks, code) {
  failed <- names(checks)[!vapply(checks, function(value) value$passed, logical(1L))]
  if (length(failed)) stop(structure(
    list(message = code, call = NULL, failed_predicates = failed, checks = checks),
    class = c("padml_fpm_health_error", "error", "condition")
  ))
}

fpm_preserve_failure <- function(condition, fit, input) {
  # These are failure-only native artifacts, never a substitute for acceptance.
  root <- dirname(output_path)
  saveRDS(input, file.path(root, "fit-input.rds"))
  if (!is.null(fit)) saveRDS(fit, file.path(root, "fit.rds"))
  observe <- function(expression) {
    expression <- substitute(expression)
    envir <- parent.frame()
    tryCatch(list(value = eval(expression, envir), error = NULL),
      error = function(error) list(value = NULL, error = conditionMessage(error)))
  }
  evidence <- list(
    message = conditionMessage(condition), class = class(condition),
    call = conditionCall(condition), calls = sys.calls(), session = sessionInfo(),
    failed_predicates = condition$failed_predicates, checks = condition$checks,
    fit_present = !is.null(fit)
  )
  if (!is.null(fit)) {
    gradient <- observe({
      native_args <- fit@args
      native_args$init <- as.numeric(coef(fit))
      native_args$return_type <- "gradient"
      as.numeric(.Call("model_output", native_args, PACKAGE = "rstpm2"))
    })
    evidence$native <- list(
    details = observe(fit@details), objective = observe(fit@min),
    coefficients = observe(coef(fit)), covariance = observe(vcov(fit)),
    controls = observe(fit@args),
    gradient = gradient,
    optimality = observe(rstpm2:::padml_ph_optimality(
      fit@args$padml_domain_geometry, as.numeric(coef(fit)), gradient$value,
      fit@min, fit@args$reltol)),
    continuous_domain = observe(rstpm2:::padml_ph_domain_evidence(fit)),
    constrained_optimality = observe(rstpm2:::padml_ph_optimality_evidence(fit))
    )
  }
  saveRDS(evidence, file.path(root, "fit-error.rds"))
}

validate_fpm_fit_health <- function(fit, warning_count, expected_df) {
  correction <- fpm_constraint_identity()
  need(inherits(fit, "stpm2"), "F2_FPM_FIT_HEALTH_INVALID")
  details <- fit@details
  coefficients <- coef(fit)
  covariance <- vcov(fit)
  coefficient_count <- length(coefficients)
  expected_df <- as.integer(unlist(expected_df, use.names = FALSE))
  controls <- fit@args
  native_args <- controls
  native_args$init <- as.numeric(coefficients)
  native_args$return_type <- "feasible"
  native_feasible <- .Call("model_output", native_args, PACKAGE = "rstpm2")
  bases <- Filter(function(value) inherits(value, "nsx"), fit@lm$model)
  checks <- fpm_evaluate_checks(alist(
    native_feasible = isTRUE(native_feasible),
    no_warning = identical(as.integer(warning_count), 0L),
    details_list = is.list(details),
    optimizer_convergence = identical(as.integer(details$convergence), 0L),
    termination_code = identical(as.integer(details$conv), 0L),
    gradient_numeric = is.numeric(details$maxgrad),
    gradient_scalar = length(details$maxgrad) == 1L,
    gradient_finite = is.finite(details$maxgrad),
    gradient_nonnegative = details$maxgrad >= 0,
    objective_finite = is.finite(fit@min),
    optimizer = identical(as.character(fit@optimizer), "optim"),
    optimizer_method = identical(controls$optimiser, "BFGS"),
    reltol = identical(as.numeric(controls$reltol), 1e-10),
    reltol_search = identical(as.numeric(controls$reltol_search), 1e-10),
    reltol_outer = identical(as.numeric(controls$reltol_outer), 1e-5),
    outer_optim = identical(as.integer(controls$outer_optim), 1L),
    maxkappa = identical(as.numeric(controls$maxkappa), 1000),
    final_kappa_scalar = length(controls$kappa.final) == 1L,
    final_kappa_finite = is.finite(controls$kappa.final),
    final_kappa_positive = controls$kappa.final > 0,
    final_kappa_budget = controls$kappa.final <= controls$maxkappa,
    parscale_count = length(controls$parscale) == coefficient_count,
    parscale_finite = all(is.finite(controls$parscale)),
    parscale_one = all(controls$parscale == 1),
    log_time_transform = isTRUE(controls$log.time.transform),
    expected_df_count = length(expected_df) == 2L,
    spline_count = length(bases) == 2L,
    spline_df = identical(as.integer(vapply(bases, ncol, integer(1L))), expected_df),
    coefficient_count = coefficient_count > 0L,
    coefficients_finite = all(is.finite(coefficients)),
    covariance_matrix = is.matrix(covariance),
    covariance_shape = identical(dim(covariance), c(coefficient_count, coefficient_count)),
    covariance_finite = all(is.finite(covariance)),
    covariance_symmetric = max(abs(covariance - t(covariance))) <= 1e-10,
    covariance_rank = qr(covariance)$rank == coefficient_count,
    covariance_diagonal = all(diag(covariance) >= 0)
  ))
  fpm_require_checks(checks, "F2_FPM_FIT_HEALTH_INVALID")
  spline_bases <- lapply(seq_along(bases), function(index) {
    basis <- bases[[index]]
    knots <- attr(basis, "knots")
    boundaries <- attr(basis, "Boundary.knots")
    need(
      is.numeric(knots) && length(knots) == expected_df[[index]] - 1L &&
        all(is.finite(knots)) && all(diff(knots) > 0) &&
        is.numeric(boundaries) && length(boundaries) == 2L &&
        all(is.finite(boundaries)) && diff(boundaries) > 0 &&
        all(knots > boundaries[[1L]] & knots < boundaries[[2L]]) &&
        identical(attr(basis, "intercept"), FALSE) &&
        identical(as.integer(attr(basis, "derivs")), c(2L, 2L)) &&
        identical(attr(basis, "centre"), FALSE) && identical(attr(basis, "log"), FALSE),
      "F2_FPM_ACTUAL_SPLINE_EVIDENCE_INVALID"
    )
    list(
      role = c("BASELINE_LOG_TIME", "AST_ALT_TVC_LOG_TIME")[[index]],
      df = ncol(basis), knots = as.list(as.numeric(knots)),
      boundary_knots = as.list(as.numeric(boundaries)),
      intercept = attr(basis, "intercept"),
      derivatives = as.list(as.integer(attr(basis, "derivs"))),
      centre = attr(basis, "centre"), log = attr(basis, "log")
    )
  })
  list(
    converged = TRUE,
    warning_count = 0L,
    optimizer = as.character(fit@optimizer),
    optimizer_convergence = as.integer(details$convergence),
    coefficient_count = coefficient_count,
    covariance_rank = coefficient_count,
    fit_evidence = list(
      constraint_correction = correction,
      native_feasible = native_feasible,
      optimizer_method = controls$optimiser,
      termination_code = as.integer(details$conv),
      maximum_gradient = as.numeric(details$maxgrad),
      objective_value = as.numeric(fit@min),
      controls = list(
        reltol = as.numeric(controls$reltol),
        reltol_search = as.numeric(controls$reltol_search),
        reltol_outer = as.numeric(controls$reltol_outer),
        outer_optim = as.integer(controls$outer_optim),
        parscale = as.list(as.numeric(controls$parscale)),
        maxkappa = as.numeric(controls$maxkappa),
        final_kappa = as.numeric(controls$kappa.final)
      ),
      log_time_transform = controls$log.time.transform,
      spline_bases = spline_bases,
      continuous_domain = rstpm2:::padml_ph_domain_evidence(fit),
      constrained_optimality = rstpm2:::padml_ph_optimality_evidence(fit)
    )
  )
}

validate_rsf_fit_health <- function(fit, warning_count, expected_trees, expected_columns, expected_mtry) {
  expected_trees <- as.integer(expected_trees)
  expected_mtry <- as.integer(expected_mtry)
  expected_columns <- as.character(expected_columns)
  death_times <- as.numeric(fit$unique.death.times)
  need(
    inherits(fit, "ranger") && inherits(fit$forest, "ranger.forest") &&
      identical(as.integer(warning_count), 0L) && expected_trees > 0L &&
      length(expected_columns) > 0L && expected_mtry > 0L &&
      identical(as.integer(fit$num.trees), expected_trees) &&
      identical(as.integer(fit$forest$num.trees), expected_trees) &&
      identical(length(fit$forest$child.nodeIDs), expected_trees) &&
      identical(as.integer(fit$num.independent.variables), length(expected_columns)) &&
      identical(as.character(fit$forest$independent.variable.names), expected_columns) &&
      identical(as.integer(fit$mtry), expected_mtry) &&
      is.numeric(fit$prediction.error) && length(fit$prediction.error) == 1L &&
      is.finite(fit$prediction.error) && length(death_times) > 0L &&
      all(is.finite(death_times)) && all(diff(death_times) > 0) &&
      is.matrix(fit$survival) && nrow(fit$survival) == fit$num.samples &&
      ncol(fit$survival) == length(death_times) &&
      all(is.finite(fit$survival)) && all(fit$survival >= 0 & fit$survival <= 1),
    "F2_RSF_FIT_HEALTH_INVALID"
  )
  list(
    converged = TRUE,
    warning_count = 0L,
    tree_count = expected_trees,
    independent_variable_count = length(expected_columns),
    mtry = expected_mtry,
    death_time_count = length(death_times),
    prediction_error = as.numeric(fit$prediction.error)
  )
}

gbm_cox_objective_identity <- function() {
  version <- as.character(packageVersion("gbm"))
  correction <- packageDescription("gbm")[["PADML-Correction"]]
  need(identical(version, "2.3.1.9001") && identical(correction, "cox-breslow-ties-v1"),
       "F2_GBM_COX_CORRECTION_MISSING")
  list(implementation = "GROUPED_BRESLOW_V1", engine_version = version,
       source_correction = correction)
}

validate_gbm_fit_health <- function(fit, warning_count, expected_trees, expected_columns, expected_rows) {
  expected_trees <- as.integer(expected_trees)
  expected_columns <- as.character(expected_columns)
  expected_rows <- as.integer(expected_rows)
  need(
    inherits(fit, "gbm") && identical(as.integer(warning_count), 0L) &&
      expected_trees > 0L && length(expected_columns) > 0L && expected_rows > 0L &&
      identical(as.integer(fit$n.trees), expected_trees) &&
      identical(length(fit$trees), expected_trees) &&
      identical(as.integer(fit$nTrain), expected_rows) &&
      identical(as.character(fit$var.names), expected_columns) &&
      length(fit$train.error) == expected_trees &&
      all(is.finite(fit$train.error)) &&
      length(fit$oobag.improve) == expected_trees &&
      all(is.finite(fit$oobag.improve)) &&
      length(fit$fit) == expected_rows && all(is.finite(fit$fit)) &&
      is.numeric(fit$initF) && length(fit$initF) == 1L && is.finite(fit$initF),
    "F2_GBM_FIT_HEALTH_INVALID"
  )
  list(
    converged = TRUE,
    warning_count = 0L,
    tree_count = expected_trees,
    training_row_count = expected_rows,
    independent_variable_count = length(expected_columns),
    training_loss_count = length(fit$train.error),
    minimum_training_loss = min(fit$train.error),
    maximum_training_loss = max(fit$train.error),
    cox_objective = gbm_cox_objective_identity()
  )
}

fit_predict <- function(family, train, test, selected, parameters, model_seed, horizons, recipe, prepared_design = NULL) {
  if (is.null(prepared_design)) {
    train_mapping <- apply_design_recipe(train, selected, recipe, family)
    test_mapping <- apply_design_recipe(test, selected, recipe, family)
  } else {
    need(
      identical(sort(names(prepared_design)), c("test_mapping", "train_mapping")),
      "F2_R_PREPARED_DESIGN_INVALID"
    )
    train_mapping <- prepared_design$train_mapping
    test_mapping <- prepared_design$test_mapping
  }
  train_design <- train_mapping$x
  test_design <- test_mapping$x
  design_map <- ordered_parent_column_map(train_mapping$parent_map, selected)
  need(
    identical(colnames(train_design), colnames(test_design)) &&
      identical(design_map, ordered_parent_column_map(test_mapping$parent_map, selected)),
    "F2_R_TRAIN_TEST_DESIGN_DRIFT"
  )
  finish <- function(survival, stopping) list(
    survival = survival,
    stopping = stopping,
    ordered_parent_column_map = design_map
  )
  time <- train[[time_col]]; event <- train[[event_col]]
  if (family == "COX_PH") {
    # Formula parsing retains literal backticks in coefficient names for
    # non-syntactic design columns (for example Rutherford factor levels).
    # Fit the identical numeric matrices under private syntactic names so the
    # engine interface cannot change or mis-bind the frozen design labels.
    engine_columns <- sprintf(".padml_x_%04d", seq_len(ncol(train_design)))
    engine_train_design <- train_design
    engine_test_design <- test_design
    colnames(engine_train_design) <- engine_columns
    colnames(engine_test_design) <- engine_columns
    frame <- data.frame(
      .time = time, .event = event, engine_train_design, check.names = FALSE
    )
    formula <- Surv(.time, .event) ~ .
    fit_warnings <- character()
    fit <- withCallingHandlers(
      coxph(
        formula, data = frame, ties = "breslow", x = TRUE, y = TRUE,
        singular.ok = FALSE,
        control = coxph.control(eps = 1e-11, iter.max = 100L)
      ),
      warning = function(condition) {
        fit_warnings <<- c(fit_warnings, class(condition)[[1L]])
        invokeRestart("muffleWarning")
      }
    )
    coefficients <- fit$coefficients
    need(
      length(coefficients) > 0L && !anyNA(coefficients) && all(is.finite(coefficients)) &&
        identical(names(coefficients), engine_columns),
      "F2_COX_PH_COEFFICIENT_INVALID"
    )
    health <- validate_coxph_fit_health(
      fit, length(fit_warnings), ncol(train_design)
    )
    # Native prediction uses the fit's actual timefix response and its centered
    # risk scale. Uncentered exp(X beta) can overflow after a harmless translation.
    survival <- withCallingHandlers(
      padml_coxph_survival(fit, engine_test_design, horizons, need),
      warning=function(condition) {fit_warnings <<- c(fit_warnings, class(condition)[[1L]]); invokeRestart("muffleWarning")})
    need(length(fit_warnings) == 0L, "F2_COX_PH_NATIVE_PREDICTION_INVALID")
    need(all(apply(survival, 1L, function(row) all(diff(row) <= 1e-10))),
         "F2_COX_PH_NATIVE_PREDICTION_INVALID")
    return(finish(
      survival,
      c(list(engine = "survival::coxph", ties = "breslow"), health)
    ))
  }
  if (family == "ELASTIC_NET_COX") {
    locked <- elastic_locked_parameters(parameters)
    alpha <- locked$alpha; ratio <- locked$ratio; lambda <- locked$lambda
    lambda_max <- locked$lambda_max; lambda_upper_bound <- locked$lambda_upper_bound
    penalty <- rep(1, ncol(train_design)); penalty[grepl("^AST_ALT$", colnames(train_design))] <- 0
    engine_design <- glmnet_engine_design(train_design, test_design, penalty)
    fit <- glmnet(engine_design$train, Surv(time, event), family = "cox", cox.ties = "breslow", alpha = alpha, lambda = lambda, penalty.factor = engine_design$penalty, standardize = TRUE)
    need(
      length(fit$jerr) == 1L && is.finite(fit$jerr) && fit$jerr == 0L &&
        all(is.finite(as.matrix(coef(fit, s = lambda)))),
      "F2_ELASTIC_FIT_NONCONVERGENCE"
    )
    if (!is.null(engine_design$inert_column)) {
      inert_coefficient <- as.matrix(coef(fit, s = lambda))[engine_design$inert_column, , drop = FALSE]
      need(all(is.finite(inert_coefficient)) && all(inert_coefficient == 0), "F2_ELASTIC_INERT_COLUMN_INVALID")
    }
    train_risk <- exp(as.numeric(predict(fit, engine_design$train, s = lambda, type = "link")))
    test_risk <- exp(as.numeric(predict(fit, engine_design$test, s = lambda, type = "link")))
    base <- breslow(time, event, train_risk)
    return(finish(survival_from_risk(base, test_risk, horizons), list(engine = "glmnet::glmnet", converged = TRUE, lambda_max = lambda_max, lambda = lambda, ratio = ratio, alpha = alpha, lambda_upper_bound = lambda_upper_bound)))
  }
  if (family == "RSF") {
    suppressPackageStartupMessages(library(ranger))
    max_depth <- parameters$max_depth
    unlimited_depth <- identical(toupper(as.character(max_depth)), "UNLIMITED")
    mtry <- min(
      ncol(train_design),
      max(
        1L,
        round_half_up_decimal_product(
          parameters$mtry_fraction, ncol(train_design)
        )
      )
    )
    set.seed(model_seed, kind = "L'Ecuyer-CMRG")
    arguments <- list(
      x = train_design, y = Surv(time, event),
      num.trees = as.integer(parameters$num_trees), mtry = mtry,
      min.node.size = as.integer(parameters$min_node_size),
      sample.fraction = as.numeric(parameters$sample_fraction),
      splitrule = as.character(parameters$splitrule), seed = model_seed,
      num.threads = 1L, write.forest = TRUE
    )
    if (!unlimited_depth) arguments$max.depth <- as.integer(max_depth)
    fit_warnings <- character()
    fit <- withCallingHandlers(
      do.call(ranger, arguments),
      warning = function(condition) {
        fit_warnings <<- c(fit_warnings, class(condition)[[1L]])
        invokeRestart("muffleWarning")
      }
    )
    health <- validate_rsf_fit_health(
      fit, length(fit_warnings), parameters$num_trees,
      colnames(train_design), mtry
    )
    survival <- padml_rsf_survival(fit, test_design, horizons, need)
    return(finish(
      survival,
      c(list(engine = "ranger::ranger", num_trees = as.integer(parameters$num_trees)), health)
    ))
  }
  if (family == "GBM_COX") {
    suppressPackageStartupMessages(library(gbm))
    gbm_cox_objective_identity()
    max_trees <- as.integer(parameters$max_trees)
    locked_trees <- if (is.null(parameters$locked_trees)) NULL else as.integer(parameters$locked_trees)
    need(!is.null(locked_trees), "F2_GBM_STOPPING_LOCK_MISSING")
    need(locked_trees > 0L && locked_trees <= max_trees, "F2_GBM_LOCKED_TREE_COUNT_INVALID")
    set.seed(model_seed, kind = "L'Ecuyer-CMRG")
    fit_warnings <- character()
    fit <- withCallingHandlers(
      gbm.fit(
        x = train_design, y = Surv(time, event), distribution = "coxph", n.trees = locked_trees,
        interaction.depth = as.integer(parameters$interaction_depth),
        shrinkage = as.numeric(parameters$shrinkage),
        n.minobsinnode = as.integer(parameters$min_observations_in_node),
        bag.fraction = as.numeric(parameters$bag_fraction), nTrain = nrow(train_design),
        keep.data = FALSE, verbose = FALSE
      ),
      warning = function(condition) {
        fit_warnings <<- c(fit_warnings, class(condition)[[1L]])
        invokeRestart("muffleWarning")
      }
    )
    health <- validate_gbm_fit_health(
      fit, length(fit_warnings), locked_trees,
      colnames(train_design), nrow(train_design)
    )
    train_risk <- exp(as.numeric(predict(fit, train_design, n.trees = locked_trees, type = "link")))
    test_risk <- exp(as.numeric(predict(fit, test_design, n.trees = locked_trees, type = "link")))
    base <- breslow(time, event, train_risk)
    return(finish(
      survival_from_risk(base, test_risk, horizons),
      c(list(
        engine = "gbm::gbm", selected_trees = locked_trees,
        training_only_stop_count = 0L, stopping_reselected = FALSE
      ), health)
    ))
  }
  if (family == "FPM_TVC_SET_A") {
    suppressPackageStartupMessages(library(rstpm2))
    fpm_constraint_identity()
    need(
      "AST_ALT" %in% colnames(train_design) && "AST_ALT" %in% colnames(test_design) &&
        all(is.finite(train_design[,"AST_ALT"])) && all(is.finite(test_design[,"AST_ALT"])) &&
        all(train_design[,"AST_ALT"] > 0 & train_design[,"AST_ALT"] <= 15) &&
        all(test_design[,"AST_ALT"] > 0 & test_design[,"AST_ALT"] <= 15),
      "F2_FPM_FIXED_COMPUTATIONAL_DOMAIN_INVALID"
    )
    frame <- data.frame(.time = time, .event = event, train_design, check.names = FALSE)
    formula <- as.formula(paste("Surv(.time,.event) ~", paste(sprintf("`%s`", colnames(train_design)), collapse = "+")))
    fit <- NULL
    return(tryCatch({
    if (length(spec$producer_tasks) == 1L) saveRDS(list(train_design = train_design, test_design = test_design,
      time = time, event = event, formula = formula, spec = spec),
      file.path(dirname(output_path), "fit-input.rds"))
    fit <- withCallingHandlers(
      stpm2(formula, data = frame, df = as.integer(unlist(spec$fpm$set_a_df))[[1L]], tvc = list(AST_ALT = as.integer(unlist(spec$fpm$set_a_df))[[2L]]), padml.fpm.domain = c(0,15)),
      warning = function(condition) {
        stop("F2_FPM_FIT_WARNING: ", conditionMessage(condition), call. = FALSE)
      }
    )
    # Keep the actual object until the Python prediction consumer has passed.
    # It is deleted on success, retained if health or transport validation fails.
    if (length(spec$producer_tasks) == 1L) saveRDS(fit, file.path(dirname(output_path), "fit.rds"))
    health <- validate_fpm_fit_health(fit, 0L, spec$fpm$set_a_df)
    survival <- padml_predict_final_fpm_survival(fit, test_design, horizons, a12=a12_search)
    finish(survival, c(list(
      engine = "rstpm2::stpm2",
      df = as.integer(unlist(spec$fpm$set_a_df))[[1L]],
      tvc_df = as.integer(unlist(spec$fpm$set_a_df))[[2L]]
    ), health))
    }, error = function(condition) {
      fpm_preserve_failure(condition, fit, list(
        train_design = train_design, test_design = test_design,
        time = time, event = event, formula = formula, spec = spec
      ))
      stop(condition)
    }))
  }
  fail("F2_R_FAMILY_INVALID")
}

gbm_stop_curve <- function(train, test, selected, parameters, model_seed, recipe, risk_prefix) {
  suppressPackageStartupMessages(library(gbm))
  gbm_cox_objective_identity()
  train_mapping <- apply_design_recipe(train, selected, recipe, "GBM_COX")
  test_mapping <- apply_design_recipe(test, selected, recipe, "GBM_COX")
  train_design <- train_mapping$x
  test_design <- test_mapping$x
  design_map <- ordered_parent_column_map(train_mapping$parent_map, selected)
  need(
    identical(colnames(train_design), colnames(test_design)) &&
      identical(design_map, ordered_parent_column_map(test_mapping$parent_map, selected)),
    "F2_R_TRAIN_TEST_DESIGN_DRIFT"
  )
  maximum <- as.integer(scalar(parameters$max_trees))
  need(maximum > 0L && is.null(parameters$locked_trees), "F2_GBM_STOP_CURVE_SPEC_INVALID")
  set.seed(model_seed, kind = "L'Ecuyer-CMRG")
  fit_warnings <- character()
  fit <- withCallingHandlers(
    gbm.fit(
      x = train_design,
      y = Surv(train[[time_col]], train[[event_col]]),
      distribution = "coxph",
      n.trees = maximum,
      interaction.depth = as.integer(scalar(parameters$interaction_depth)),
      shrinkage = as.numeric(scalar(parameters$shrinkage)),
      n.minobsinnode = as.integer(scalar(parameters$min_observations_in_node)),
      bag.fraction = as.numeric(scalar(parameters$bag_fraction)),
      nTrain = nrow(train_design),
      keep.data = FALSE,
      verbose = FALSE
    ),
    warning = function(condition) {
      fit_warnings <<- c(fit_warnings, class(condition)[[1L]])
      invokeRestart("muffleWarning")
    }
  )
  health <- validate_gbm_fit_health(
    fit, length(fit_warnings), maximum,
    colnames(train_design), nrow(train_design)
  )
  tree_path <- seq_len(maximum)
  fit_eta <- predict(fit, train_design, n.trees = tree_path, type = "link")
  evaluation_eta <- predict(fit, test_design, n.trees = tree_path, type = "link")
  if (is.null(dim(fit_eta))) fit_eta <- matrix(fit_eta, ncol = maximum)
  if (is.null(dim(evaluation_eta))) evaluation_eta <- matrix(evaluation_eta, ncol = maximum)
  need(
    identical(dim(fit_eta), c(nrow(train_design), maximum)) &&
      identical(dim(evaluation_eta), c(nrow(test_design), maximum)) &&
      all(is.finite(fit_eta)) && all(is.finite(evaluation_eta)),
    "F2_GBM_STOP_CURVE_INVALID"
  )
  list(
    risk_matrix_channel = risk_matrix_channel(
      fit_eta, evaluation_eta, risk_prefix
    ),
    maximum = maximum,
    ordered_parent_column_map = design_map,
    fit_health = health
  )
}

elastic_ratio_path <- function(train, test, selected, alphas, ratios, emit_risk, emit_coefficients, recipe, risk_prefix, a12=FALSE, natural_audit=FALSE) {
  train_mapping <- apply_design_recipe(train, selected, recipe, "ELASTIC_NET_COX")
  test_mapping <- apply_design_recipe(test, selected, recipe, "ELASTIC_NET_COX")
  train_design <- train_mapping$x
  test_design <- test_mapping$x
  need(
    identical(colnames(train_design), colnames(test_design)) &&
      length(ratios) == 150L && all(is.finite(ratios)) &&
      all(diff(ratios) < 0) && ratios[[1L]] == 1 &&
      abs(ratios[[150L]] - 0.0001) <= .Machine$double.eps,
    "F2_ELASTIC_RATIO_PATH_INVALID"
  )
  penalty <- rep(1, ncol(train_design))
  if (!natural_audit) penalty[train_mapping$parent_map$parent == "AST_ALT"] <- 0
  engine_design <- glmnet_engine_design(train_design, test_design, penalty, a12=a12)
  # All alphas consume the same qualified representation and response. Hash
  # that representation once, while alpha and mutable glmnet controls stay in
  # each probe's own cache key.
  lambda_input_identity <- digest(list(engine_design$train, train[[time_col]],
    train[[event_col]], engine_design$penalty, a12), algo="sha256")
  values <- lapply(seq_along(alphas), function(alpha_index) {
    alpha <- alphas[[alpha_index]]
    need(is.finite(alpha) && alpha >= 0.01 && alpha <= 1, "F2_ELASTIC_ALPHA_INVALID")
    lambda_upper_bound <- data_driven_cox_lambda_upper_bound(
      engine_design$train, train[[time_col]], train[[event_col]],
      alpha, engine_design$penalty, a12=a12, prepared_identity=lambda_input_identity
    )
    lambda_max <- validate_cox_lambda_upper_bound(lambda_upper_bound, alpha)
    lambda_path <- lambda_max * ratios
    need(
      is.finite(lambda_max) && lambda_max > 0 &&
        all(is.finite(lambda_path)) && all(lambda_path > 0) &&
        all(diff(lambda_path) < 0),
      "F2_ELASTIC_LAMBDA_PATH_INVALID"
    )
    fit <- glmnet(
      engine_design$train, Surv(train[[time_col]], train[[event_col]]),
      family = "cox", cox.ties = "breslow", alpha = alpha,
      lambda = lambda_path, penalty.factor = engine_design$penalty, standardize = TRUE
    )
    observed_lambda <- as.numeric(fit$lambda)
    need(
      length(fit$jerr) == 1L && is.finite(fit$jerr) && fit$jerr == 0L &&
        length(observed_lambda) == 150L &&
        all(abs(observed_lambda - lambda_path) <= 1e-12 * pmax(1, abs(lambda_path))),
      "F2_ELASTIC_LAMBDA_PATH_INVALID"
    )
    beta_engine <- as.matrix(coef(fit, s = lambda_path))
    beta_engine <- beta_engine[rownames(beta_engine) != "(Intercept)", , drop = FALSE]
    need(
      identical(rownames(beta_engine), colnames(engine_design$train)) &&
        identical(dim(beta_engine), c(ncol(engine_design$train), 150L)) &&
        all(is.finite(beta_engine)),
      "F2_ELASTIC_COEFFICIENT_PATH_INVALID"
    )
    scientific_penalized <- engine_design$penalty > 0
    if (!is.null(engine_design$inert_column)) {
      if (a12) need(all(beta_engine[engine_design$inert_column, ] == 0),
                            "F2_ELASTIC_INERT_COLUMN_INVALID")
      scientific_penalized[colnames(engine_design$train) == engine_design$inert_column] <- FALSE
    }
    penalized_design_column_count <- sum(scientific_penalized)
    penalized_active_count_path <- if (penalized_design_column_count) {
      as.integer(colSums(beta_engine[scientific_penalized, , drop = FALSE] != 0))
    } else {
      rep(0L, 150L)
    }
    penalized_entry_covered <- penalized_design_column_count > 0L && any(penalized_active_count_path > 0L)
    need(
      penalized_design_column_count > 0L && (penalized_entry_covered || natural_audit),
      "F2_ELASTIC_PENALIZED_ENTRY_FRONTIER_NOT_COVERED"
    )
    result <- list(
      alpha = alpha,
      lambda_max = lambda_max,
      lambda_path = as.list(lambda_path),
      lambda_upper_bound = lambda_upper_bound,
      penalized_design_column_count = penalized_design_column_count,
      penalized_active_count_path = as.list(penalized_active_count_path),
      penalized_entry_covered = penalized_entry_covered,
      event_count = sum(train[[event_col]] == 1L)
    )
    if (emit_risk) {
      fit_eta <- predict(fit, engine_design$train, s = lambda_path, type = "link")
      evaluation_eta <- predict(fit, engine_design$test, s = lambda_path, type = "link")
      if (is.null(dim(fit_eta))) fit_eta <- matrix(fit_eta, ncol = 150L)
      if (is.null(dim(evaluation_eta))) evaluation_eta <- matrix(evaluation_eta, ncol = 150L)
      need(
        identical(dim(fit_eta), c(nrow(train_design), 150L)) &&
          identical(dim(evaluation_eta), c(nrow(test_design), 150L)) &&
          all(is.finite(fit_eta)) && all(is.finite(evaluation_eta)),
        "F2_ELASTIC_RISK_PATH_INVALID"
      )
      result$risk_matrix_channel <- risk_matrix_channel(
        fit_eta, evaluation_eta,
        sprintf("%s-alpha-%03d", risk_prefix, alpha_index)
      )
    }
    if (emit_coefficients) {
      beta <- beta_engine
      if (!is.null(engine_design$inert_column)) {
        need(
          engine_design$inert_column %in% rownames(beta) &&
            all(is.finite(beta[engine_design$inert_column, ])) &&
            all(beta[engine_design$inert_column, ] == 0),
          "F2_ELASTIC_INERT_COLUMN_INVALID"
        )
        beta <- beta[
          rownames(beta) != engine_design$inert_column, , drop = FALSE
        ]
      }
      need(identical(rownames(beta), colnames(train_design)) && identical(dim(beta), c(ncol(train_design), 150L)), "F2_ELASTIC_COEFFICIENT_PATH_INVALID")
      parents <- unique(as.character(train_mapping$parent_map$parent))
      result$parent_design_columns <- setNames(
        lapply(parents, function(parent) sum(train_mapping$parent_map$parent == parent)),
        parents
      )
      result$parent_coefficients <- setNames(lapply(parents, function(parent) {
        columns <- train_mapping$parent_map$column[train_mapping$parent_map$parent == parent]
        indices <- match(columns, rownames(beta))
        need(!anyNA(indices), "F2_ELASTIC_COEFFICIENT_PATH_INVALID")
        lapply(seq_len(150L), function(position) as.list(as.numeric(beta[indices, position])))
      }), parents)
    }
    result
  })
  list(
    alphas = values,
    ordered_parent_column_map = ordered_parent_column_map(train_mapping$parent_map, selected)
  )
}

run_registered_prediction_batch <- function() {
  tasks <- spec$producer_tasks
  need(length(tasks) > 0L, "F2_R_PRODUCER_TASK_SET_INVALID")
  task_ids <- vapply(tasks, function(task) as.character(scalar(task$task_id)), character(1))
  need(!anyDuplicated(task_ids), "F2_R_PRODUCER_TASK_SET_INVALID")
  horizons <- as.numeric(unlist(spec$horizons, use.names = FALSE))
  prepared_design_cache <- get0(".padml_r_batch_design_cache", envir=.GlobalEnv, inherits=FALSE)
  if (is.null(prepared_design_cache)) prepared_design_cache <- new.env(parent = emptyenv())
  values <- lapply(seq_along(tasks), function(task_index) {
    task <- tasks[[task_index]]
    partition_id <- as.character(scalar(task$partition_id))
    matches <- Filter(function(value) identical(value$partition_id, partition_id), partitions)
    need(length(matches) == 1L, "F2_R_REGISTERED_PARTITION_LOOKUP_INVALID")
    value <- matches[[1L]]
    imputation <- as.integer(scalar(task$imputation))
    need(imputation %in% seq_len(20L), "F2_R_IMPUTATION_INDEX_INVALID")
    task_family <- as.character(scalar(task$family))
    need(identical(task_family, family), "F2_R_PRODUCER_FAMILY_INVALID")
    selected <- as.character(unlist(task$selected_parents, use.names = FALSE))
    need(length(selected) > 0L && (if (a12_search)
      !any(c("AST", "ALT", "AST_ALT") %in% selected) &&
        identical(selected, as.character(unlist(spec$selector_from_dependency$selected_parents, use.names=FALSE))) else
      "AST_ALT" %in% selected), "F2_R_SELECTOR_DEPENDENCY_INVALID")
    transform_recipe <- spec$transform_recipe
    transform_recipe_sha256 <- if (is.null(transform_recipe)) "RAW_CANONICAL" else as.character(scalar(transform_recipe$recipe_sha256))
    parameters <- if (is.null(task$parameters)) list() else task$parameters
    if (identical(task_family, "ELASTIC_NET_COX")) {
      need(is.null(parameters$imputation_index) ||
           identical(as.integer(scalar(parameters$imputation_index)), imputation),
           "F2_ELASTIC_IMPUTATION_PARAMETER_INVALID")
      parameters$imputation_index <- imputation
    }
    train <- fit_frame(value, imputation)
    test <- evaluation_frame(value, imputation)
    producer_kind <- if (is.null(task$producer_kind)) "SURVIVAL" else as.character(scalar(task$producer_kind))
    if (producer_kind %in% c("ELASTIC_INNER_PATH", "ELASTIC_OUTER_PATH")) {
      need(identical(task_family, "ELASTIC_NET_COX"), "F2_ELASTIC_RATIO_PATH_INVALID")
      ratios <- as.numeric(unlist(task$ratios, use.names = FALSE))
      alphas <- as.numeric(unlist(task$alphas, use.names = FALSE))
      paths <- elastic_ratio_path(
        train, test, selected, alphas, ratios,
        identical(producer_kind, "ELASTIC_INNER_PATH"),
        identical(producer_kind, "ELASTIC_OUTER_PATH"), transform_recipe,
        sprintf("risk-%03d", task_index), a12=a12_search
      )
      return(list(
        task_id = as.character(scalar(task$task_id)), partition_id = partition_id,
        imputation = imputation, fit_ids = as.list(value$fit_ids),
        evaluation_ids = as.list(value$evaluation_ids), elastic_paths = paths,
        ordered_parent_column_map = paths$ordered_parent_column_map,
        transform_recipe_sha256 = transform_recipe_sha256
      ))
    }
    if (identical(producer_kind, "GBM_STOP_CURVE")) {
      need(identical(task_family, "GBM_COX") && identical(value$kind, "STOP"), "F2_GBM_STOP_CURVE_ROUTE_INVALID")
      curve <- gbm_stop_curve(
        train, test, selected, parameters, as.integer(scalar(task$seed)),
        transform_recipe, sprintf("risk-%03d-gbm", task_index)
      )
      return(list(
        task_id = as.character(scalar(task$task_id)), partition_id = partition_id,
        imputation = imputation, fit_ids = as.list(value$fit_ids),
        evaluation_ids = as.list(value$evaluation_ids), risk_curve = curve,
        ordered_parent_column_map = curve$ordered_parent_column_map,
        stopping = c(
          list(engine = "gbm::gbm", stopping_reselected = TRUE),
          curve$fit_health
        ),
        transform_recipe_sha256 = transform_recipe_sha256
      ))
    }
    need(identical(producer_kind, "SURVIVAL"), "F2_R_PRODUCER_KIND_INVALID")
    if (identical(task_family, "GBM_COX")) {
      need(!is.null(parameters$locked_trees), "F2_GBM_STOPPING_LOCK_MISSING")
    }
    prepared_design_key <- sha_object(list(partition=partition_id, imputation=imputation,
      family=task_family, transform=transform_recipe_sha256, selected=as.list(selected),
      covariates=value$covariate_pins[[imputation]], fit_ids=value$fit_ids,
      evaluation_ids=value$evaluation_ids, response=value$fit_response_pin))
    if (!exists(prepared_design_key, envir = prepared_design_cache, inherits = FALSE)) {
      # Sequential atoms keep no more than 64 MiB of deterministic preparation.
      # Other worker caches and transient native allocations remain separately admitted.
      prepared_design <- list(
          train_mapping = apply_design_recipe(train, selected, transform_recipe, task_family),
          test_mapping = apply_design_recipe(test, selected, transform_recipe, task_family)
      )
      cache_r_preparation(prepared_design_cache, prepared_design_key, prepared_design)
    } else prepared_design <- get(prepared_design_key, envir=prepared_design_cache, inherits=FALSE)
    fitted <- fit_predict(
      task_family, train, test, selected, parameters,
      as.integer(scalar(task$seed)), horizons, transform_recipe,
      prepared_design = prepared_design
    )
    list(
      task_id = as.character(scalar(task$task_id)), partition_id = partition_id,
      imputation = imputation, evaluation_ids = as.list(value$evaluation_ids),
      survival = lapply(seq_len(nrow(fitted$survival)), function(index) as.list(as.numeric(fitted$survival[index, ]))),
      stopping = fitted$stopping,
      ordered_parent_column_map = fitted$ordered_parent_column_map,
      transform_recipe_sha256 = transform_recipe_sha256
    )
  })
  result <- list(
    schema_version = "1.0.0", kind = "PADML_F2_R_PREDICTION_BATCH",
    status = "PASS", task_count = length(values), tasks = values
  )
  writeLines(canonical_json(
    result, digits = if (identical(family, "FPM_TVC_SET_A")) I(17) else NA
  ), output_path, useBytes = TRUE)
}

run_locked_family_execution <- function() {
  need(
    identical(action, "LOCKED_FAMILY_EXECUTION") &&
      length(partitions) == 1L && identical(partitions[[1L]]$kind, "OUTER"),
    "LOCKED_R_OWNER_PARTITION_INVALID"
  )
  outer <- partitions[[1L]]
  selected <- as.character(unlist(spec$selected_parents, use.names = FALSE))
  seeds <- as.integer(unlist(spec$locked_seeds, use.names = FALSE))
  horizons <- as.numeric(unlist(spec$horizons, use.names = FALSE))
  parameters <- if (is.null(spec$locked_parameters)) list() else spec$locked_parameters
  recipe <- spec$transform_recipe
  need(
    length(selected) > 0L && "AST_ALT" %in% selected &&
      length(seeds) == imputation_count && all(seeds > 0L) &&
      length(horizons) > 0L && identical(horizons, sort(unique(horizons))),
    "LOCKED_R_OWNER_SPEC_INVALID"
  )
  prediction_sum <- matrix(
    0, nrow = length(outer$evaluation_ids), ncol = length(horizons)
  )
  stopping <- vector("list", imputation_count)
  for (imp in seq_len(imputation_count)) {
    fitted <- fit_predict(
      family, fit_frame(outer, imp), evaluation_frame(outer, imp),
      selected, c(parameters, list(imputation_index = imp)),
      seeds[[imp]], horizons, recipe
    )
    need(
      identical(dim(fitted$survival), dim(prediction_sum)) &&
        all(is.finite(fitted$survival)) && all(fitted$survival >= 0) &&
        all(fitted$survival <= 1),
      "LOCKED_R_OWNER_PREDICTION_INVALID"
    )
    prediction_sum <- prediction_sum + fitted$survival
    stopping[[imp]] <- c(
      list(imputation = imp, seed = seeds[[imp]], search_performed = FALSE),
      fitted$stopping
    )
  }
  pooled <- prediction_sum / imputation_count
  need(
    all(apply(pooled, 1L, function(row) all(diff(row) <= 1e-10))),
    "LOCKED_R_OWNER_MONOTONICITY_INVALID"
  )
  result <- list(
    schema_version = "1.0.0", kind = "PADML_LOCKED_FAMILY_EXECUTION",
    status = "PASS", backend = "R", family = family,
    fit_count = imputation_count, model_search_performed = FALSE,
    patient_ids = as.list(outer$evaluation_ids),
    horizons = as.list(as.integer(horizons)),
    survival = lapply(seq_len(nrow(pooled)), function(index) {
      as.list(as.numeric(pooled[index, ]))
    }),
    retained_model_binary_count = 0L,
    stopping_and_convergence = stopping, threads = 1L
  )
  writeLines(canonical_json(result), output_path, useBytes = TRUE)
}

if (identical(action, "LOCKED_FAMILY_EXECUTION")) {
  run_locked_family_execution()
  quit(save = "no", status = 0L)
}

if (identical(action, "MODEL_PREDICTION_BATCH")) {
  run_registered_prediction_batch()
  quit(save = "no", status = 0L)
}

run_registered_cox_ph <- function() {
  need(identical(family, "COX_PH"), "F2_R_REGISTERED_ROUTE_INVALID")
  outer <- partition("OUTER")
  selected <- as.character(unlist(spec$selector_from_dependency$selected_parents, use.names = FALSE))
  need(length(selected) > 0L && "AST_ALT" %in% selected, "F2_R_SELECTOR_DEPENDENCY_INVALID")
  horizons <- as.numeric(unlist(spec$horizons, use.names = FALSE))
  heldout <- as.integer(scalar(spec$heldout_center))
  prediction_sum <- matrix(0, nrow = length(outer$evaluation_ids), ncol = length(horizons))
  stopping <- vector("list", 20L)
  for (imp in seq_len(20L)) {
    train <- fit_frame(outer, imp)
    test <- evaluation_frame(outer, imp)
    need(
      all(as.integer(train$Center) != heldout) && all(as.integer(test$Center) == heldout) &&
        identical(as.character(test$Patient_ID), outer$evaluation_ids) &&
        !time_col %in% names(test) && !event_col %in% names(test),
      "F2_R_OUTER_PARTITION_INVALID"
    )
    fitted <- fit_predict(
      "COX_PH", train, test, selected, list(imputation_index = imp),
      seed + imp, horizons, spec$transform_recipe
    )
    seal <- seal_prediction(outer$evaluation_ids, fitted$survival, horizons)
    prediction_sum <- prediction_sum + fitted$survival
    stopping[[imp]] <- c(fitted$stopping, list(prediction_seal_sha256 = seal))
  }
  pooled <- prediction_sum / 20
  need(
    all(is.finite(pooled)) && all(pooled >= 0 & pooled <= 1) &&
      !any(apply(pooled, 1L, function(row) any(diff(row) > 1e-10))),
    "F2_R_OUTPUT_QC_FAILED"
  )
  predictions <- lapply(seq_along(outer$evaluation_ids), function(index) list(
    Patient_ID = outer$evaluation_ids[[index]],
    survival = as.list(as.numeric(pooled[index, ]))
  ))
  row_universe <- list(
    training_count = length(outer$fit_ids),
    heldout_count = length(outer$evaluation_ids),
    training_ids_sha256 = sha_object(as.list(outer$fit_ids)),
    heldout_ids_sha256 = sha_object(as.list(outer$evaluation_ids)),
    overlap_count = length(intersect(outer$fit_ids, outer$evaluation_ids))
  )
  numeric_qc <- list(
    prediction_count = length(outer$evaluation_ids) * length(horizons),
    finite_count = sum(is.finite(pooled)),
    minimum_survival = min(pooled),
    maximum_survival = max(pooled),
    monotonic_violation_count = sum(apply(pooled, 1L, function(row) any(diff(row) > 1e-10)))
  )
  result <- list(
    schema_version = "1.0.0",
    artifact_kind = "F2_MODEL_DEVELOPMENT",
    status = "PASS",
    fold = fold,
    heldout_center = heldout,
    family = family,
    backend = scalar(spec$backend),
    threads = 1L,
    lineage = spec$lineage,
    row_universe = row_universe,
    selector_evidence = spec$selector_from_dependency,
    search_trace = list(),
    search_evaluation_unit_count = 20L,
    selected_spec = list(
      family = family, selected_parents = as.list(selected), ties = "breslow"
    ),
    predictions = predictions,
    prediction_horizons = as.list(horizons),
    stopping_and_convergence = stopping,
    numeric_qc = numeric_qc,
    retained_model_binary_count = 0L,
    heldout_outcome_read_count_for_selection = 0L,
    typed_terminal = "PASS"
  )
  writeLines(canonical_json(result), output_path, useBytes = TRUE)
}

if (identical(action, "MODEL_DEVELOPMENT") && identical(family, "COX_PH")) {
  run_registered_cox_ph()
  quit(save = "no", status = 0L)
}

engine_parameters <- function(parameters) {
  value <- parameters
  if (family == "RSF") {
    names(value)[names(value) == "num.trees"] <- "num_trees"
    names(value)[names(value) == "min.node.size"] <- "min_node_size"
    names(value)[names(value) == "max.depth"] <- "max_depth"
    names(value)[names(value) == "sample.fraction"] <- "sample_fraction"
    need(identical(as.character(value$splitrule), "logrank"), "F2_RSF_FIXED_PARAMETER_DRIFT")
  }
  if (family == "GBM_COX") {
    names(value)[names(value) == "interaction.depth"] <- "interaction_depth"
    names(value)[names(value) == "n.minobsinnode"] <- "min_observations_in_node"
    names(value)[names(value) == "bag.fraction"] <- "bag_fraction"
    names(value)[names(value) == "n.trees.max"] <- "max_trees"
    need(
      identical(as.character(value$early_stopping_metric), "cox_deviance") &&
        identical(as.character(value$post_selection_refit), "full_main_training_at_selected_n_trees") &&
        identical(as.character(value$locked_iteration_mode), "full_main_training_without_reselection"),
      "F2_GBM_FIXED_PARAMETER_DRIFT"
    )
  }
  value
}

evaluate_candidate <- function(parameters, imputation_count, split_count, stage_seed) {
  parameters <- engine_parameters(parameters)
  scores <- numeric(imputation_count * split_count); cursor <- 1L
  selected_trees <- integer()
  for (imp in seq_len(imputation_count)) {
    training <- datasets[[imp]][training_mask, , drop = FALSE]
    assignments <- split_ids(training, split_count, stage_seed + imp)
    for (inner in seq_len(split_count)) {
      fit <- fit_predict(family, training[assignments != inner, , drop = FALSE], training[assignments == inner, , drop = FALSE], selected_parents, c(parameters, list(imputation_index = imp)), stage_seed + imp * 100L + inner, as.numeric(unlist(spec$horizons)), NULL)
      scores[[cursor]] <- brier_score(training[[time_col]][assignments != inner], training[[event_col]][assignments != inner], training[[time_col]][assignments == inner], training[[event_col]][assignments == inner], fit$survival, as.numeric(unlist(spec$horizons)))
      if (family == "GBM_COX") selected_trees <- c(selected_trees, as.integer(fit$stopping$selected_trees))
      cursor <- cursor + 1L
    }
  }
  need(all(is.finite(scores)), "F2_R_METRIC_NONFINITE")
  result <- list(mean_ibs = mean(scores), maximum_ibs = max(scores), evaluation_units = length(scores))
  if (family == "GBM_COX") {
    need(length(selected_trees) == length(scores) && all(selected_trees > 0L), "F2_GBM_STOPPING_DENOMINATOR_INVALID")
    result$selected_trees_median <- as.integer(median(selected_trees))
  }
  result
}

evaluate_center_stress <- function(parameters, stage_seed) {
  parameters <- engine_parameters(parameters)
  centers <- sort(setdiff(unique(as.integer(datasets[[1L]]$Center)), c(heldout_center, 55L)))
  need(length(centers) == 5L, "F2_R_CENTER_STRESS_CENTER_SET_INVALID")
  scores <- numeric(5L * length(centers)); cursor <- 1L
  for (imp in seq_len(5L)) {
    outer <- datasets[[imp]][training_mask, , drop = FALSE]
    for (center in centers) {
      test <- as.integer(outer$Center) == center
      train <- !test
      need(any(train) && any(test), "F2_R_CENTER_STRESS_PARTITION_INVALID")
      fitted <- fit_predict(
        family, outer[train, , drop = FALSE], outer[test, , drop = FALSE], selected_parents,
        c(parameters, list(imputation_index = imp)), stage_seed + imp * 100L + center,
        as.numeric(unlist(spec$horizons)), NULL
      )
      scores[[cursor]] <- brier_score(
        outer[[time_col]][train], outer[[event_col]][train], outer[[time_col]][test], outer[[event_col]][test],
        fitted$survival, as.numeric(unlist(spec$horizons))
      )
      cursor <- cursor + 1L
    }
  }
  need(all(is.finite(scores)), "F2_R_CENTER_STRESS_NONFINITE")
  list(mean_ibs = mean(scores), maximum_ibs = max(scores), evaluation_units = length(scores))
}

if (identical(action, "P2C2T_LOCKED_EVALUATION")) {
  task <- spec$diagnostic_task
  component <- as.character(scalar(task$component))
  selected_spec <- task$selected_spec
  parameters <- if (is.null(selected_spec$parameters)) list() else selected_spec$parameters
  if (family == "GBM_COX") {
    need(!is.null(selected_spec$locked_trees), "F2_P2C2T_GBM_STOPPING_LOCK_MISSING")
    parameters$locked_trees <- as.integer(scalar(selected_spec$locked_trees))
  }
  if (isTRUE(task$selector_only)) {
    result <- list(
      status = "PASS", component = component, task_id = as.character(scalar(task$task_id)),
      scope_id = as.character(scalar(task$scope_id)), family = family, fold = fold,
      selector_evidence = selector, selector_evidence_sha256 = sha_object(selector),
      outer_heldout_outcome_read_count = 0L, threads = 1L, finite = TRUE, typed_terminal = "PASS"
    )
    writeLines(canonical_json(result), output_path, useBytes = TRUE)
    quit(save = "no", status = 0L)
  }
  warning_hashes <- character()
  guarded_fit <- function(...) withCallingHandlers(
    fit_predict(...),
    warning = function(value) {
      warning_hashes <<- c(warning_hashes, sha_text(conditionMessage(value)))
      invokeRestart("muffleWarning")
    }
  )
  scores <- numeric(); partitions <- list()
  if (identical(component, "CENTER_BLOCKED_STRESS")) {
    centers <- sort(setdiff(unique(as.integer(datasets[[1L]]$Center)), c(heldout_center, 55L)))
    need(length(centers) == 5L, "F2_P2C2T_CENTER_SET_INVALID")
    for (imp in seq_len(imputation_count)) {
      outer <- datasets[[imp]][training_mask, , drop = FALSE]
      for (center in centers) {
        test <- as.integer(outer$Center) == center; train <- !test
        fitted <- guarded_fit(
          family, outer[train, , drop = FALSE], outer[test, , drop = FALSE], selected_parents,
          c(engine_parameters(parameters), list(imputation_index = imp)), seed + imp * 100L + center,
          as.numeric(unlist(spec$horizons)), task$transform_recipe
        )
        value <- brier_score(
          outer[[time_col]][train], outer[[event_col]][train], outer[[time_col]][test], outer[[event_col]][test],
          fitted$survival, as.numeric(unlist(spec$horizons))
        )
        scores <- c(scores, value)
        partitions[[length(partitions) + 1L]] <- list(center = center, imputation = imp, ibs_0_24 = value)
      }
    }
  } else {
    need(component %in% c("LOCKED_MODEL_SAMPLE_SIZE_DIAGNOSTIC", "LOCAL_PERTURBATION"), "F2_P2C2T_COMPONENT_INVALID")
    for (imp in seq_len(imputation_count)) {
      train <- datasets[[imp]][training_mask, , drop = FALSE]
      test <- datasets[[imp]][heldout_mask, , drop = FALSE]
      fitted <- guarded_fit(
        family, train, test, selected_parents,
        c(engine_parameters(parameters), list(imputation_index = imp)), seed + imp * 100L,
        as.numeric(unlist(spec$horizons)), task$transform_recipe
      )
      value <- brier_score(
        train[[time_col]], train[[event_col]], test[[time_col]], test[[event_col]],
        fitted$survival, as.numeric(unlist(spec$horizons))
      )
      scores <- c(scores, value)
      partitions[[length(partitions) + 1L]] <- list(imputation = imp, ibs_0_24 = value)
    }
  }
  expected_fits <- imputation_count * if (identical(component, "CENTER_BLOCKED_STRESS")) 5L else 1L
  need(length(scores) == expected_fits && all(is.finite(scores)), "F2_P2C2T_R_METRIC_INVALID")
  result <- list(
    status = "PASS", component = component, task_id = as.character(scalar(task$task_id)),
    scope_id = as.character(scalar(task$scope_id)), family = family, fold = fold,
    imputation_count = imputation_count, expected_fit_count = expected_fits,
    executed_fit_count = length(scores), mean_ibs = mean(scores), maximum_ibs = max(scores),
    partition_metrics_sha256 = sha_object(partitions), selected_spec_sha256 = sha_object(selected_spec),
    selected_parent_sha256 = sha_object(as.list(selected_parents)), warning_count = length(unique(warning_hashes)),
    warning_set_sha256 = sha_object(as.list(sort(unique(warning_hashes)))), outer_heldout_outcome_read_count = 0L,
    selector_evidence = if (isTRUE(spec$rerun_selector)) selector else NULL,
    selector_evidence_sha256 = if (isTRUE(spec$rerun_selector)) sha_object(selector) else NULL,
    threads = 1L, finite = TRUE, typed_terminal = "PASS"
  )
  writeLines(canonical_json(result), output_path, useBytes = TRUE)
  quit(save = "no", status = 0L)
}

search_trace <- list(); selected_spec <- list(family = family); selected_parameters <- list()
if (family %in% c("RSF", "GBM_COX")) {
  stages <- list(
    S1 = list(trials = spec$candidate_trials$S1, imputations = 1L, splits = 5L),
    S2 = list(trials = spec$candidate_trials$S2, imputations = 5L, splits = 5L)
  )
  ranked <- list()
  for (stage in names(stages)) {
    current <- stages[[stage]]
    evaluations <- lapply(seq_along(current$trials), function(index) {
      trial <- current$trials[[index]]
      metric <- evaluate_candidate(trial$parameters, current$imputations, current$splits, seed + match(stage, c("S1", "S2")) * 10000L)
      c(
        list(
          stage_id = stage, trial_index = index,
          candidate_id = as.character(scalar(trial$trial_id)),
          parameters = trial$parameters,
          parameter_sha256 = as.character(scalar(trial$parameter_sha256))
        ),
        metric
      )
    })
    search_trace[[stage]] <- evaluations
    ranked <- c(ranked, evaluations)
  }
  rank_rows <- function(rows) rows[order(vapply(rows, `[[`, numeric(1), "mean_ibs"), vapply(rows, `[[`, numeric(1), "maximum_ibs"), vapply(rows, `[[`, character(1), "parameter_sha256"))]
  top3 <- rank_rows(ranked)[seq_len(3L)]
  s3a <- lapply(top3, function(row) modifyList(row, evaluate_candidate(row$parameters, 20L, 5L, seed + 30000L)))
  search_trace$S3A <- s3a
  top2 <- rank_rows(s3a)[seq_len(2L)]
  s3b1 <- lapply(top2, function(row) modifyList(row, evaluate_candidate(row$parameters, 5L, 15L, seed + 40000L)))
  search_trace$S3B1 <- s3b1
  winner <- rank_rows(s3b1)[[1L]]
  s3b2 <- modifyList(winner, evaluate_candidate(winner$parameters, 20L, 15L, seed + 50000L))
  search_trace$S3B2 <- list(s3b2)
  seed_offsets <- as.integer(unlist(spec$model_seed_policy$extra_seed_offsets))
  need(length(seed_offsets) == 2L && !anyDuplicated(seed_offsets) && all(seed_offsets > 0L), "F2_MODEL_SEED_AUDIT_POLICY_INVALID")
  search_trace$SEED_AUDIT <- lapply(seed_offsets, function(offset) {
    c(list(seed_offset = offset), evaluate_candidate(winner$parameters, 5L, 15L, seed + offset))
  })
  search_trace$CENTER_STRESS <- lapply(seq_along(top2), function(index) {
    c(
      list(candidate_rank = index, parameters = top2[[index]]$parameters, parameter_sha256 = top2[[index]]$parameter_sha256),
      evaluate_center_stress(top2[[index]]$parameters, seed + 80000L + index * 1000L)
    )
  })
  selected_parameters <- winner$parameters
  selected_spec <- list(
    family = family, candidate_id = winner$candidate_id, parameters = selected_parameters,
    selection_metric = "IBS_0_24", selection_stage = "S3B2"
  )
  if (family == "GBM_COX") {
    locked_trees <- as.integer(s3b2$selected_trees_median)
    need(locked_trees > 0L, "F2_GBM_FORMAL_STOPPING_LOCK_INVALID")
    selected_spec$locked_trees <- locked_trees
    selected_parameters$locked_trees <- locked_trees
  }
} else if (family == "ELASTIC_NET_COX") {
  selected_parameters <- list(
    alpha = as.numeric(scalar(selector$common_alpha)),
    ratio_by_imputation = selector$selected_ratio_by_imputation,
    lambda_by_imputation = selector$final_refit_lambda_by_imputation,
    lambda_upper_bound_by_imputation = selector$lambda_upper_bound_by_imputation
  )
  selected_spec <- list(
    family = family, common_alpha = selector$common_alpha,
    ratio_by_imputation = selector$selected_ratio_by_imputation, selected_parents = selector$selected_parents,
    lambda_policy = "IMPUTATION_SPECIFIC_DATA_DRIVEN_LAMBDA_EPV_1SE"
  )
} else if (family == "COX_PH") {
  selected_spec <- list(family = family, selected_parents = selector$selected_parents, ties = "breslow")
} else if (family == "FPM_TVC_SET_A") {
  selected_spec <- list(family = family, selected_parents = selector$selected_parents, df = spec$fpm$set_a_df, tvc_parent = "AST_ALT")
}

horizons <- as.numeric(unlist(spec$horizons))
prediction_sum <- matrix(0, nrow = sum(heldout_mask), ncol = length(horizons))
stopping <- vector("list", 20L)
for (imp in seq_len(20L)) {
  fitted <- fit_predict(family, datasets[[imp]][training_mask, , drop = FALSE], datasets[[imp]][heldout_mask, , drop = FALSE], selected_parents, c(selected_parameters, list(imputation_index = imp)), seed + imp, horizons, spec$transform_recipe)
  prediction_sum <- prediction_sum + fitted$survival
  stopping[[imp]] <- fitted$stopping
}
pooled <- prediction_sum / 20
need(all(is.finite(pooled)) && all(pooled >= 0 & pooled <= 1), "F2_R_PREDICTION_INVALID")
predictions <- lapply(seq_along(heldout_ids), function(index) list(Patient_ID = heldout_ids[[index]], survival = as.list(as.numeric(pooled[index, ]))))
row_universe <- list(
  training_count = length(training_ids),
  heldout_count = length(heldout_ids),
  training_ids_sha256 = sha_object(as.list(training_ids)),
  heldout_ids_sha256 = sha_object(as.list(heldout_ids)),
  overlap_count = length(intersect(training_ids, heldout_ids))
)
numeric_qc <- list(
  prediction_count = length(heldout_ids) * length(horizons),
  finite_count = sum(is.finite(pooled)),
  minimum_survival = min(pooled),
  maximum_survival = max(pooled),
  monotonic_violation_count = sum(apply(pooled, 1L, function(row) any(diff(row) > 1e-10)))
)
need(row_universe$overlap_count == 0L && numeric_qc$monotonic_violation_count == 0L, "F2_R_OUTPUT_QC_FAILED")

evaluation_units <- sum(vapply(search_trace, function(rows) {
  sum(vapply(rows, function(row) if (is.list(row) && !is.null(row$evaluation_units)) as.integer(row$evaluation_units) else 0L, integer(1)))
}, integer(1))) + 20L
if (family %in% c("RSF", "GBM_COX")) {
  need(evaluation_units == as.integer(scalar(spec$search_budget$standard_outer_units)), "F2_R_STANDARD_OUTER_BUDGET_INVALID")
}
result <- list(
  schema_version = "1.0.0",
  artifact_kind = "F2_MODEL_DEVELOPMENT",
  status = "PASS",
  fold = fold,
  heldout_center = heldout_center,
  family = family,
  backend = scalar(spec$backend),
  threads = 1L,
  lineage = spec$lineage,
  row_universe = row_universe,
  selector_evidence = selector,
  search_trace = search_trace,
  search_evaluation_unit_count = evaluation_units,
  selected_spec = selected_spec,
  predictions = predictions,
  prediction_horizons = as.list(horizons),
  stopping_and_convergence = stopping,
  numeric_qc = numeric_qc,
  retained_model_binary_count = 0L,
  heldout_outcome_read_count_for_selection = 0L,
  typed_terminal = "PASS"
)
writeLines(toJSON(result, auto_unbox = TRUE, null = "null", na = "null", digits = NA, pretty = FALSE), output_path, useBytes = TRUE)
