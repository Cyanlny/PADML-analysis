#!/usr/bin/env Rscript

# Only the two approved non-formal pass-through components use this M2 adapter.
# The original A12 channel removal and clone substream bridge remain intact.
args <- commandArgs(trailingOnly = TRUE)
stopifnot(length(args) >= 2L, args[[1L]] %in% c("FIT", "REPLAY"))
request <- jsonlite::fromJSON(args[[2L]], simplifyVector = FALSE)
component <- request$pass_through
stopifnot(identical(component, "A12_TOTAL_OUTER1_M1") ||
            identical(component, "CLONE_B1_OUTER1_R1_K1_M1"))
script <- grep("^--file=", commandArgs(), value = TRUE)
stopifnot(length(script) == 1L)
package <- dirname(gsub("~+~", " ", sub("^--file=", "", script), fixed = TRUE))
bridge <- parse(file.path(package, if (identical(component, "A12_TOTAL_OUTER1_M1"))
                           "f5_a12_mice.R" else "f5_mice.R"))
entry <- which(vapply(as.list(bridge), function(x) identical(x, quote(impute_view(spec, authority))), logical(1)))
stopifnot(length(entry) == 1L, entry[[1L]] == length(bridge) - 1L)
for (expression in as.list(bridge)[seq_len(entry[[1L]] - 1L)]) eval(expression)
if (!is.numeric(spec$view$outer_fold) || spec$view$outer_fold != 1L ||
    !spec$view$role %in% c("ANALYSIS", "APPLICATION")) fail("F45_VALIDATION_MICE_SCOPE_INVALID")
if (identical(component, "A12_TOTAL_OUTER1_M1")) {
  expected <- if (identical(spec$view$role, "ANALYSIS")) c(150000001L, 150000002L) else c(150000021L, 150000022L)
  if (!identical(spec$view$view_id, paste0("OUTER_", spec$view$role)) ||
      !is.null(chain_rng_substream) || !identical(ints(spec$chain_seeds), expected)) {
    fail("F45_A12_VALIDATION_COORDINATES_INVALID")
  }
} else {
  if (!identical(spec$view$view_id, paste0("F4_FULL_B001_F1_INNER_R1_K1_", spec$view$role)) ||
      !identical(chain_rng_substream, 1L) ||
      !identical(ints(spec$chain_seeds), c(730000101L, 730000102L))) {
    fail("F45_CLONE_VALIDATION_COORDINATES_INVALID")
  }
}
spec$pass_through <- NULL
# Reuse only the pure four-site cardinality projection, never A04 coordinates
# or its permutation entry. The original chain body and QC are untouched.
definition <- Filter(function(x) is.call(x) && identical(x[[1L]], as.name("<-")) &&
                       identical(x[[2L]], as.name("a04_negative_m2")),
                     as.list(parse(file.path(package, "f5_a04_negative.R"))))
stopifnot(length(definition) == 1L)
eval(definition[[1L]])
impute_view <- a04_negative_m2(impute_view)
impute_view(spec, authority)
writeLines(capture.output(sessionInfo()), file.path(root, "native-session.txt"))
