#!/usr/bin/env Rscript

# The three approved outer M20 variants use the unchanged retaining F5 bridge.
# Do not import the final-deployment application transaction/RNG adapter.
script <- grep("^--file=", commandArgs(), value = TRUE)
stopifnot(length(script) == 1L)
bridge <- parse(file.path(dirname(gsub("~+~", " ", sub("^--file=", "", script), fixed = TRUE)), "f5_mice.R"))
entry <- which(vapply(as.list(bridge), function(x) {
  identical(x, quote(impute_view(spec, authority)))
}, logical(1)))
stopifnot(length(entry) == 1L, entry[[1L]] == length(bridge) - 1L)
for (expression in as.list(bridge)[seq_len(entry[[1L]] - 1L)]) eval(expression)

variant <- spec$a04_variant
donors <- c(RAW_DONOR5 = 5L, RAW_DONOR3 = 3L, RAW_DONOR10 = 10L)
if (!is.character(variant) || length(variant) != 1L || !variant %in% names(donors) ||
    !is.null(chain_rng_substream) ||
    !identical(as.character(spec$view$view_id), paste0("OUTER_", spec$view$role)) ||
    !is.numeric(spec$view$outer_fold) || length(spec$view$outer_fold) != 1L ||
    !spec$view$outer_fold %in% 1:6) fail("F5_A04_MICE_VARIANT_INVALID")
spec$a04_variant <- NULL
rules <- authority$science$mice$target_rules
targets <- vapply(rules, function(row) as.character(row$target), character(1))
scales <- vapply(rules, function(row) as.character(row$working_scale), character(1))
if (!identical(targets[scales == "log1p"], "Creatinine") ||
    any(!scales %in% c("original", "log1p"))) fail("F5_A04_MICE_FROZEN_SCALE_INVALID")
pmm <- authority$science$mice$pmm
exact_names(pmm, c("donors", "matchtype", "trim", "ridge", "ls_meth"),
            "F5_A04_MICE_FROZEN_PMM_INVALID")
if (as.integer(pmm$donors) != 5L || as.integer(pmm$matchtype) != 1L ||
    as.integer(pmm$trim) != 1L || as.numeric(pmm$ridge) != 1e-5 ||
    !identical(as.character(pmm$ls_meth), "qr")) fail("F5_A04_MICE_FROZEN_PMM_INVALID")
authority$science$mice$pmm$donors <- unname(donors[[variant]])
authority$science$mice$target_rules[[which(targets == "Creatinine")]]$working_scale <- "original"

# Project both actual transformations; target-rule labels alone do not change
# the F1 implementation. The other formulas, observed restoration, chain body,
# twenty seeds, 30 -> 40 -> 50 continuation and full convergence QC stay intact.
changed <- integer(2L)
a04_raw_scale <- function(expression) {
  original <- list(quote(mice_data$Creatinine <- log1p(original_creatinine)),
                   quote(completed$Creatinine <- expm1(completed$Creatinine)))
  replacement <- list(quote(mice_data$Creatinine <- original_creatinine),
                      quote(invisible(NULL)))
  for (index in seq_along(original)) {
    if (identical(expression, original[[index]])) {
      changed[[index]] <<- changed[[index]] + 1L
      return(replacement[[index]])
    }
  }
  if (is.call(expression)) {
    for (index in seq_along(expression)) {
      if (!is.null(expression[[index]]) && !identical(expression[[index]], quote(expr = ))) {
        expression[[index]] <- a04_raw_scale(expression[[index]])
      }
    }
  }
  expression
}
body(impute_view) <- a04_raw_scale(body(impute_view))
if (!identical(changed, c(1L, 1L))) fail("F5_A04_MICE_SCALE_SOURCE_INVALID")
impute_view(spec, authority)
writeLines(capture.output(sessionInfo()), file.path(root, "native-session.txt"))
