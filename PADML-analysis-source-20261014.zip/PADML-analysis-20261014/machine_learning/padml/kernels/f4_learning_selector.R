#!/usr/bin/env Rscript

# Only the input scope changes. Design, glmnet path and risk arithmetic
# are the original F2 functions; this entry never enters an F2 production run.
suppressPackageStartupMessages({library(jsonlite); library(digest); library(survival); library(glmnet)})
fail <- function(code) stop(code, call. = FALSE)
need <- function(value, code) if (!isTRUE(value)) fail(code)
scalar <- function(value) unname(unlist(value, use.names = FALSE)[[1L]])
args <- commandArgs(trailingOnly = TRUE)
need(length(args) == 1L, "F4_LEARNING_SELECTOR_ARGUMENT_INVALID")
spec <- fromJSON(args[[1L]], simplifyVector = FALSE)
scope <- as.character(scalar(spec$execution_scope))
nested_full <- identical(scope, "NESTED_FULL_DATA_SELECTOR_M20")
nested_no_aar <- identical(scope, "NESTED_NO_AAR_SELECTOR_M20")
nested_primary <- identical(scope, "NESTED_PRIMARY_SELECTOR_M20")
need(is.null(spec$ast_alt_natural_audit) ||
       (is.logical(spec$ast_alt_natural_audit) && length(spec$ast_alt_natural_audit) == 1L &&
        !is.na(spec$ast_alt_natural_audit) && (nested_full || nested_primary)),
     "NATURAL_SELECTOR_SCOPE_INVALID")
imputation_count <- as.integer(scalar(spec$imputation_count))
need(((identical(scope, "F4_LEARNING_SELECTOR_M5") && imputation_count == 5L) ||
       (scope %in% c("F4_FULL_PIPELINE_SELECTOR_M20", "F4_FULL_PIPELINE_A16_M20", "NESTED_FULL_DATA_SELECTOR_M20", "NESTED_NO_AAR_SELECTOR_M20", "NESTED_PRIMARY_SELECTOR_M20") && imputation_count == 20L)) &&
       identical(scalar(spec$family), "ELASTIC_NET_COX"),
     "F4_LEARNING_SELECTOR_SCOPE_INVALID")
if (nested_full) need(
  identical(scalar(spec$nested_source$kind), "PADML_NESTED_FULL_DATA_SELECTOR_SOURCE_V1") &&
    identical(scalar(spec$nested_source$program_id), "PADML_F45_REBUILD_20260925") &&
    as.integer(scalar(spec$nested_source$context)) == 0L &&
    as.integer(scalar(spec$fold)) == 0L && as.integer(scalar(spec$seed)) == 300000L,
  "NESTED_FULL_DATA_SELECTOR_SOURCE_INVALID")
if (nested_no_aar) need(
  identical(scalar(spec$nested_source$kind), "PADML_NESTED_NO_AAR_SELECTOR_SOURCE_V1") &&
    identical(scalar(spec$nested_source$program_id), "PADML_F45_REBUILD_20260925") &&
    as.integer(scalar(spec$nested_source$context)) == as.integer(scalar(spec$fold)) &&
    as.integer(scalar(spec$fold)) %in% 0:6 &&
    as.integer(scalar(spec$seed)) == 300000L + 1000L * as.integer(scalar(spec$fold)) &&
    scalar(spec$nested_source$inherited_family) %in%
      c("COX_PH", "ELASTIC_NET_COX", "RSF", "GBM_COX", "XGBOOST_COX", "FPM_TVC_SET_A", "COXTIME_SET_A") &&
    grepl("^[0-9a-f]{64}$", scalar(spec$nested_source$primary_development_lock_sha256)),
  "NESTED_NO_AAR_SELECTOR_SOURCE_INVALID")
if (nested_primary) need(
  identical(scalar(spec$nested_source$kind), "PADML_NESTED_PRIMARY_SELECTOR_SOURCE_V1") &&
    identical(scalar(spec$nested_source$program_id), "PADML_F45_REBUILD_20260925") &&
    (as.integer(scalar(spec$nested_source$selection_horizon_months)) == 36L ||
      (identical(scalar(spec$nested_source$origin), "CURRENT_RAW_CONTEXT") &&
       as.integer(scalar(spec$nested_source$selection_horizon_months)) %in% c(6L, 12L, 24L, 36L))) &&
    as.integer(scalar(spec$nested_source$context)) == as.integer(scalar(spec$fold)) &&
    as.integer(scalar(spec$fold)) %in% 1:6 &&
    as.integer(scalar(spec$seed)) == 300000L + 1000L * as.integer(scalar(spec$fold)),
  "NESTED_PRIMARY_SELECTOR_SOURCE_INVALID")
output_path <- as.character(scalar(spec$output_path))
options(error = function() {
  dump.frames(dumpto = file.path(dirname(output_path), "native-failure"),
              to.file = TRUE, include.GlobalEnv = TRUE)
  quit(save = "no", status = 1L, runLast = FALSE)
})
script <- grep("^--file=", commandArgs(), value = TRUE)
need(length(script) == 1L, "F4_LEARNING_SELECTOR_KERNEL_PATH_INVALID")
kernel <- file.path(dirname(gsub("~+~", " ", sub("^--file=", "", script), fixed = TRUE)), "f2_model_development.R")
expressions <- as.list(parse(kernel))
required <- c("canonical_json", "sha_object", "sha_text", "python_json_number_values",
              "write_operation_local_risk_matrix", "risk_matrix_channel", "categorical_contract",
              "locked_levels", "prepare_frame", "read_response", "validate_compiled_conflicts",
              "apply_design_recipe", "ordered_parent_column_map", "glmnet_engine_design",
              "validate_cox_lambda_upper_bound", "data_driven_cox_lambda_upper_bound", "elastic_ratio_path")
definitions <- Filter(function(x) {
  is.call(x) && identical(x[[1L]], as.name("<-")) && is.symbol(x[[2L]]) &&
    as.character(x[[2L]]) %in% required && is.call(x[[3L]]) &&
    identical(x[[3L]][[1L]], as.name("function"))
}, expressions)
need(length(definitions) == length(required) &&
       setequal(vapply(definitions, function(x) as.character(x[[2L]]), character(1)), required),
     "F4_LEARNING_SELECTOR_KERNEL_DEFINITION_INVALID")
for (definition in definitions) eval(definition)
# Reuse both original variable-row projections, not a second coding dictionary.
projections <- Filter(function(x) is.call(x) && identical(x[[1L]], as.name("<-")) &&
                        identical(x[[2L]], as.name("variable_rows")), expressions)
need(length(projections) == 2L, "F4_LEARNING_SELECTOR_KERNEL_DEFINITION_INVALID")
for (projection in projections) eval(projection)
parents <- vapply(Filter(function(row) row$set_a_eligible, variable_rows), `[[`, character(1), "name")
time_col <- as.character(scalar(spec$time)); event_col <- as.character(scalar(spec$outcome))
need(identical(time_col, "Death_Followup_months") && identical(event_col, "All_Cause_Death"),
     "F4_LEARNING_SELECTOR_OUTCOME_INVALID")
task <- spec$task; partition <- spec$partition
imputation <- as.integer(scalar(task$imputation))
need(imputation %in% seq_len(imputation_count) && identical(scalar(task$partition_id), scalar(partition$partition_id)) &&
       is.null(partition$evaluation_response), "F4_LEARNING_SELECTOR_TASK_INVALID")
kind <- as.character(scalar(task$producer_kind))
need(kind %in% c("ELASTIC_INNER_PATH", "ELASTIC_OUTER_PATH"), "F4_LEARNING_SELECTOR_TASK_INVALID")
if (nested_full || nested_no_aar || nested_primary) need(
  as.integer(scalar(task$seed)) == as.integer(scalar(spec$seed)) + imputation &&
    ((identical(kind, "ELASTIC_INNER_PATH") &&
        identical(scalar(partition$kind), "INNER") &&
        as.integer(scalar(partition[["repeat"]])) %in% 1:3 &&
        as.integer(scalar(partition$inner_fold)) %in% 1:5) ||
      (identical(kind, "ELASTIC_OUTER_PATH") &&
        scalar(partition$kind) %in% (if (nested_full) "FINAL_FULL_DATA" else c("OUTER_TRAINING", "FINAL_FULL_DATA")) &&
        as.integer(scalar(partition[["repeat"]])) == 0L &&
        as.integer(scalar(partition$inner_fold)) == 0L)),
  "NESTED_FULL_DATA_SELECTOR_COORDINATE_INVALID")
data <- prepare_frame(read.csv(file.path(scalar(partition$covariates$input_dir),
                                        sprintf("imp%02d.csv", imputation)),
                               check.names = FALSE, stringsAsFactors = FALSE),
                      a12=nested_no_aar, a12_total=nested_no_aar)
fit_ids <- as.character(unlist(partition$fit_ids, use.names = FALSE))
evaluation_ids <- as.character(unlist(partition$evaluation_ids, use.names = FALSE))
application_ids <- as.character(unlist(partition$application_ids, use.names = FALSE))
need(identical(as.character(data$Patient_ID), application_ids) && length(fit_ids) > 0L &&
       length(evaluation_ids) > 0L && !anyDuplicated(fit_ids) && !anyDuplicated(evaluation_ids) &&
       setequal(c(fit_ids, evaluation_ids), application_ids) &&
       if (identical(kind, "ELASTIC_INNER_PATH")) !length(intersect(fit_ids, evaluation_ids))
       else identical(fit_ids, evaluation_ids), "F4_LEARNING_SELECTOR_PATIENT_SCOPE_INVALID")
response <- read_response(partition$fit_response)
need(identical(as.character(response$Patient_ID), fit_ids), "F4_LEARNING_SELECTOR_RESPONSE_INVALID")
train <- data[match(fit_ids, data$Patient_ID), , drop = FALSE]
test <- data[match(evaluation_ids, data$Patient_ID), , drop = FALSE]
train[[time_col]] <- response[[time_col]]; train[[event_col]] <- response[[event_col]]
selected <- as.character(unlist(task$selected_parents, use.names = FALSE))
if (nested_no_aar) {
  eligible <- vapply(Filter(function(row) row$selector_eligible || row$forced,
                           variable_rows), `[[`, character(1), "name")
  eligible <- sort(setdiff(eligible, c("AST", "ALT", "AST_ALT")), method = "radix")
  need(length(eligible) > 0L && identical(selected, eligible),
       "NESTED_NO_AAR_SELECTOR_COMPLETE_DOMAIN_REQUIRED")
}
need(length(selected) > 1L && (if (nested_no_aar)
       !any(c("AST", "ALT", "AST_ALT") %in% selected) && identical(selected, eligible) else "AST_ALT" %in% selected) &&
       !anyDuplicated(selected) &&
       identical(scalar(task$transform_recipe$partition_id), scalar(task$partition_id)),
     "F4_LEARNING_SELECTOR_DESIGN_INVALID")
# glmnet 5's read-only Rcpp control getter initializes an absent RNG state.
# Initialize that runtime bookkeeping before checking actual path consumption;
# neither change settings nor reseed any scientific calculation.
invisible(glmnet.control())
rng <- get0(".Random.seed", envir = .GlobalEnv, inherits = FALSE)
paths <- elastic_ratio_path(train, test, selected,
  as.numeric(unlist(task$alphas, use.names = FALSE)), as.numeric(unlist(task$ratios, use.names = FALSE)),
  identical(kind, "ELASTIC_INNER_PATH"), identical(kind, "ELASTIC_OUTER_PATH"),
  task$transform_recipe, "risk-001", a12=nested_no_aar,
  natural_audit=isTRUE(spec$ast_alt_natural_audit))
need(identical(rng, get0(".Random.seed", envir = .GlobalEnv, inherits = FALSE)),
     "F4_LEARNING_SELECTOR_UNEXPECTED_RNG_CONSUMPTION")
value <- list(schema_version = "1.0.0", kind = "PADML_F2_R_PREDICTION_BATCH", status = "PASS",
  task_count = 1L, tasks = list(list(task_id = scalar(task$task_id), partition_id = scalar(task$partition_id),
    imputation = imputation, fit_ids = as.list(fit_ids), evaluation_ids = as.list(evaluation_ids),
    elastic_paths = paths, ordered_parent_column_map = paths$ordered_parent_column_map,
    transform_recipe_sha256 = scalar(task$transform_recipe$recipe_sha256))))
writeLines(canonical_json(value, always_decimal = TRUE, digits = I(17)), output_path, useBytes = TRUE)
