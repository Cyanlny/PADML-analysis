padml_prepare_final_r_design <- function(
  covariates, selected, predictor_rows, transform, family, scalar, need
) {
  rows <- setNames(
    lapply(predictor_rows, function(row) list(
      name = as.character(scalar(row$name)),
      type = as.character(scalar(row$type)),
      levels = as.character(scalar(row$levels_or_coding))
    )),
    vapply(
      predictor_rows,
      function(row) as.character(scalar(row$name)),
      character(1)
    )
  )
  need(
    identical(sort(names(rows)), sort(selected)),
    "F5_R_RECIPE_PARENT_INVALID"
  )

  categorical_contract <- function(row) {
    if (!row$type %in% c("binary", "ordered", "unordered")) return(NULL)
    fields <- trimws(strsplit(row$levels, ";", fixed = TRUE)[[1L]])
    level_fields <- fields[startsWith(fields, "levels=")]
    reference_fields <- fields[startsWith(fields, "reference=")]
    need(
      length(level_fields) == 1L && length(reference_fields) == 1L,
      "F5_R_FACTOR_CONTRACT_INVALID"
    )
    levels <- strsplit(
      sub("^levels=", "", level_fields[[1L]]), "|", fixed = TRUE
    )[[1L]]
    reference <- sub("^reference=", "", reference_fields[[1L]])
    matches <- vapply(levels, function(level) {
      identical(reference, level) ||
        (startsWith(reference, paste0(level, " (")) &&
           endsWith(reference, ")"))
    }, logical(1))
    need(
      length(levels) > 0L && !anyDuplicated(levels) && sum(matches) == 1L,
      "F5_R_FACTOR_CONTRACT_INVALID"
    )
    list(levels = levels, reference = levels[[which(matches)]])
  }

  for (name in selected) {
    contract <- categorical_contract(rows[[name]])
    if (is.null(contract)) {
      covariates[[name]] <- suppressWarnings(as.numeric(covariates[[name]]))
      need(
        all(is.finite(covariates[[name]])),
        "F5_R_NUMERIC_PREDICTOR_INVALID"
      )
    } else {
      observed <- as.character(covariates[[name]])
      covariates[[name]] <- factor(
        observed,
        levels = contract$levels,
        ordered = identical(rows[[name]]$type, "ordered")
      )
      need(!anyNA(covariates[[name]]), "F5_R_FACTOR_LEVEL_INVALID")
    }
  }

  reference_coded <- family %in% c("COX_PH", "FPM_TVC_SET_A")
  raw_continuous <- family %in% c(
    "RSF", "GBM_COX", "XGBOOST_COX", "COXTIME_SET_A"
  )
  recipe_rows <- if (is.null(transform)) list() else setNames(
    transform$representations,
    vapply(
      transform$representations,
      function(row) as.character(scalar(row$parent)),
      character(1)
    )
  )
  need(raw_continuous || !is.null(transform), "F5_R_TRANSFORM_RECIPE_MISSING")

  matrices <- lapply(selected, function(name) {
    row <- rows[[name]]
    contract <- categorical_contract(row)
    if (!is.null(contract)) {
      formula <- if (reference_coded) {
        as.formula(sprintf("~ `%s`", name))
      } else {
        as.formula(sprintf("~ `%s` - 1", name))
      }
      contrast <- if (reference_coded) {
        contr.treatment(
          contract$levels,
          base = match(contract$reference, contract$levels),
          contrasts = TRUE
        )
      } else {
        value <- diag(length(contract$levels))
        dimnames(value) <- list(contract$levels, contract$levels)
        value
      }
      value <- model.matrix(
        formula,
        covariates,
        contrasts.arg = setNames(list(contrast), name),
        na.action = na.fail
      )
      if (reference_coded) {
        value <- value[, colnames(value) != "(Intercept)", drop = FALSE]
      }
      need(ncol(value) > 0L, "F5_R_DESIGN_INVALID")
      return(value)
    }
    value <- as.numeric(covariates[[name]])
    if (raw_continuous) {
      return(matrix(value, ncol = 1L, dimnames = list(NULL, name)))
    }
    recipe_row <- recipe_rows[[name]]
    need(!is.null(recipe_row), "F5_R_TRANSFORM_RECIPE_INVALID")
    representation <- as.character(scalar(recipe_row$representation))
    columns <- as.character(
      unlist(recipe_row$design_columns, use.names = FALSE)
    )
    if (identical(representation, "IDENTITY")) {
      need(length(columns) == 1L, "F5_R_TRANSFORM_RECIPE_INVALID")
      return(matrix(value, ncol = 1L, dimnames = list(NULL, columns)))
    }
    if (identical(representation, "LOG1P")) {
      need(
        length(columns) == 1L && all(value >= 0),
        "F5_R_LOG1P_DOMAIN_INVALID"
      )
      return(matrix(log1p(value), ncol = 1L, dimnames = list(NULL, columns)))
    }
    need(
      identical(representation, "NATURAL_SPLINE_K3"),
      "F5_R_TRANSFORM_RECIPE_INVALID"
    )
    boundary <- as.numeric(
      unlist(recipe_row$parameters$boundary_knots, use.names = FALSE)
    )
    interior <- as.numeric(
      unlist(recipe_row$parameters$interior_knots, use.names = FALSE)
    )
    need(
      length(columns) == 2L && length(boundary) == 2L &&
        length(interior) == 1L,
      "F5_R_SPLINE_PARAMETER_INVALID"
    )
    result <- splines::ns(
      value,
      knots = interior,
      Boundary.knots = boundary,
      intercept = FALSE
    )
    colnames(result) <- columns
    need(all(is.finite(result)), "F5_R_SPLINE_DESIGN_INVALID")
    result
  })
  design <- do.call(cbind, matrices)
  need(
    nrow(design) == nrow(covariates) && ncol(design) > 0L &&
      all(is.finite(design)) && !anyDuplicated(colnames(design)),
    "F5_R_DESIGN_INVALID"
  )
  widths <- vapply(matrices, ncol, integer(1))
  ends <- cumsum(widths)
  list(covariates = covariates, design = design, rows = rows,
    parent_columns = setNames(lapply(seq_along(selected), function(i)
      seq.int(ends[[i]]-widths[[i]]+1L, ends[[i]])), selected))
}

padml_masked_r_design <- function(prepared, newdata, selected, need) {
  # Every admitted recipe above transforms one parent independently. SHAP masks
  # draw only from this MI's original patients; copy its entire design-column
  # group, including factors and splines, without re-encoding that group.
  need(identical(names(newdata), selected) && nrow(newdata) > 0L &&
    identical(names(prepared$parent_columns), selected), "F5_SHAP_MASKED_DESIGN_INVALID")
  design <- matrix(0, nrow(newdata), ncol(prepared$design),
    dimnames=list(NULL, colnames(prepared$design)))
  for (parent in selected) {
    indices <- match(newdata[[parent]], prepared$covariates[[parent]])
    need(!anyNA(indices), "F5_SHAP_MASKED_VALUE_OUTSIDE_BACKGROUND")
    columns <- prepared$parent_columns[[parent]]
    design[, columns] <- prepared$design[indices, columns, drop=FALSE]
  }
  design
}

padml_prepare_fpm_fixed_basis <- function(fit, design_columns, horizons, a12=FALSE,
    need=function(ok,code) if(!isTRUE(ok)) stop(code,call.=FALSE)) {
  if(missing(need)) need <- eval(quote(function(ok,code) if(!isTRUE(ok)) stop(code,call.=FALSE)),baseenv())
  need(methods::is(fit,"stpm2") && !methods::is(fit,"pstpm2") &&
    identical(as.character(fit@args$link),"PH") && !isTRUE(fit@frailty) &&
    !isTRUE(fit@args$excess) && !isTRUE(fit@args$copula) &&
    !isTRUE(fit@interval) && !isTRUE(fit@delayed),"FPM_FIXED_BASIS_MODEL_UNSUPPORTED")
  need(is.character(design_columns) && length(design_columns)>0L &&
    !anyDuplicated(design_columns) && length(horizons)>0L &&
    all(is.finite(horizons)) && all(horizons>=0),"FPM_FIXED_BASIS_INPUT_INVALID")
  need(is.function(fit@args$transX) &&
    identical(names(formals(fit@args$transX)),c("X","data")) &&
    identical(body(fit@args$transX),quote(X)),"FPM_FIXED_BASIS_TRANSX_UNSUPPORTED")
  need(is.null(fit@args$offset) || all(fit@args$offset==0),"FPM_FIXED_BASIS_OFFSET_UNSUPPORTED")
  if(a12) {
    need(!any(c("AST","ALT","AST_ALT") %in% design_columns) &&
      identical(fit@args$padml_domain_geometry$domain,"A12_BASELINE_DF3_NO_TVC"),
      "F5_A12_FPM_DESIGN_INVALID")
  } else need("AST_ALT" %in% design_columns,"F5_FPM_FIXED_COMPUTATIONAL_DOMAIN_INVALID")

  tt <- stats::delete.response(stats::terms(fit@lm))
  need(identical(attr(tt,"intercept"),1L) && length(attr(tt,"offset"))==0L &&
    length(fit@lm$xlevels)==0L,"FPM_FIXED_BASIS_TERMS_UNSUPPORTED")
  factors <- attr(tt,"factors")
  variables <- as.list(attr(tt,"variables"))[-1L]
  need(is.matrix(factors) && nrow(factors)==length(variables),"FPM_FIXED_BASIS_TERMS_INVALID")
  time_variable <- fit@timeVar
  formula_env <- environment(tt)
  ns <- asNamespace("rstpm2")
  head_name <- function(x) {
    if(is.symbol(x)) return(as.character(x))
    if(is.call(x) && identical(x[[1L]],as.name("::")) && length(x)==3L &&
      identical(as.character(x[[2L]]),"rstpm2")) return(as.character(x[[3L]]))
    ""
  }
  classify <- function(expr) {
    if(is.symbol(expr) && as.character(expr) %in% design_columns)
      return(list(kind="covariate",name=as.character(expr)))
    if(is.call(expr) && identical(expr[[1L]],as.name("as.numeric")) && length(expr)==2L &&
      is.symbol(expr[[2L]]) && as.character(expr[[2L]]) %in% design_columns) {
      need(identical(get("as.numeric",formula_env,inherits=TRUE),base::as.numeric),
        "FPM_FIXED_BASIS_FUNCTION_SHADOWED")
      return(list(kind="covariate",name=as.character(expr[[2L]])))
    }
    if(is.call(expr) && identical(head_name(expr[[1L]]),"nsx") && length(expr)>=2L &&
      is.call(expr[[2L]]) && identical(expr[[2L]][[1L]],as.name("log")) &&
      length(expr[[2L]])==2L && identical(expr[[2L]][[2L]],as.name(time_variable)) &&
      identical(unique(all.vars(expr)),time_variable)) {
      need(identical(get("log",formula_env,inherits=TRUE),base::log),
        "FPM_FIXED_BASIS_FUNCTION_SHADOWED")
      if(is.symbol(expr[[1L]])) need(identical(get("nsx",formula_env,inherits=TRUE),get("nsx",ns)),
        "FPM_FIXED_BASIS_FUNCTION_SHADOWED")
      return(list(kind="time",name=time_variable))
    }
    stop("FPM_FIXED_BASIS_NONLINEAR_OR_UNKNOWN_TERM",call.=FALSE)
  }
  classified <- lapply(variables,classify)
  term_owner <- integer(ncol(factors))
  for(j in seq_len(ncol(factors))) {
    active <- which(factors[,j] != 0L)
    cov <- active[vapply(classified[active],function(x)x$kind=="covariate",logical(1L))]
    tim <- active[vapply(classified[active],function(x)x$kind=="time",logical(1L))]
    need(length(cov)<=1L && length(tim)<=1L && length(active)==length(cov)+length(tim) &&
      length(active)>0L,"FPM_FIXED_BASIS_CROSS_COVARIATE_INTERACTION")
    if(length(cov)) {
      parent <- classified[[cov]]$name
      if(length(tim)) need(!a12 && identical(parent,"AST_ALT"),"FPM_FIXED_BASIS_TVC_UNSUPPORTED")
      term_owner[[j]] <- match(parent,design_columns)
    } else need(length(tim)==1L,"FPM_FIXED_BASIS_TERM_UNSUPPORTED")
  }

  p <- length(design_columns); H <- length(horizons)
  unit_rows <- matrix(0,p+1L,p,dimnames=list(NULL,design_columns))
  unit_rows[cbind(seq_len(p)+1L,seq_len(p))] <- 1
  expanded <- as.data.frame(unit_rows[rep(seq_len(p+1L),times=H),,drop=FALSE])
  rownames(expanded) <- NULL
  adjusted_time <- horizons
  adjusted_time[adjusted_time==0] <- .Machine$double.xmin
  expanded[[time_variable]] <- rep(adjusted_time,each=p+1L)
  native_lpmatrix <- get("lpmatrix.lm",ns)
  raw <- native_lpmatrix(fit@lm,expanded)
  beta <- stats::coef(fit)
  assignment <- attr(raw,"assign")
  need(is.matrix(raw) && all(is.finite(raw)) && ncol(raw)==length(beta) &&
    length(assignment)==length(beta) && all(assignment %in% 0:ncol(factors)) &&
    all(is.finite(beta)) && (is.null(names(beta)) || identical(colnames(raw),names(beta))),
    "FPM_FIXED_BASIS_MATRIX_INVALID")
  owner <- c(0L,term_owner)[assignment+1L]
  zero_index <- (seq_len(H)-1L)*(p+1L)+1L
  constant <- raw[zero_index,,drop=FALSE]
  slope <- matrix(0,H,ncol(raw),dimnames=dimnames(constant))
  for(j in seq_len(p)) {
    unit <- raw[zero_index+j,,drop=FALSE]
    owned <- which(owner==j)
    unowned <- which(owner!=j)
    need(all(unit[,unowned,drop=FALSE]==constant[,unowned,drop=FALSE]),
      "FPM_FIXED_BASIS_OWNER_DRIFT")
    if(length(owned)) {
      # Avoid baseline subtraction or LP regrouping: all varying columns are
      # pure one-covariate products, with exactly zero baseline.
      need(all(constant[,owned,drop=FALSE]==0),"FPM_FIXED_BASIS_AFFINE_MIX_UNSUPPORTED")
      slope[,owned] <- unit[,owned,drop=FALSE]
    }
  }

  # Isolate the closure from the fitted object's training frame and preparation
  # temporaries. This keeps O(H * native_column_count), not a patient-wide cache.
  out <- new.env(parent=baseenv())
  out$need <- need; out$columns <- design_columns; out$horizons <- horizons
  out$a12 <- a12; out$constant <- constant; out$slope <- slope; out$owner <- owner
  out$beta <- beta; out$ilink <- fit@link$ilink
  out$native_columns <- colnames(raw)
  eval(quote(function(design) {
    need(is.matrix(design) && nrow(design)>0L && identical(colnames(design),columns) &&
      all(is.finite(design)),"FPM_FIXED_BASIS_DESIGN_DRIFT")
    if(!a12) need(all(design[,"AST_ALT"]>0 & design[,"AST_ALT"]<=15),
      "F5_FPM_FIXED_COMPUTATIONAL_DOMAIN_INVALID")
    previous <- options(matprod="internal")
    on.exit(options(previous),add=TRUE)
    H <- length(horizons)
    answer <- matrix(NA_real_,nrow(design),H)
    width <- max(1L,2000L %/% H)
    for(lo in seq.int(1L,nrow(design),by=width)) {
      rows <- lo:min(nrow(design),lo+width-1L)
      row_index <- rep(seq_along(rows),times=H)
      time_index <- rep(seq_len(H),each=length(rows))
      X <- constant[time_index,,drop=FALSE]
      for(j in unique(owner[owner>0L])) {
        locations <- which(owner==j)
        X[,locations] <- design[rows[row_index],j] * slope[time_index,locations,drop=FALSE]
      }
      # Keep original native matrix columns and a single original-order dot
      # product. Pre-multiplying coefficients into each parent LP regroups the
      # sum and can change SHAP's tiny differences/first convergence boundary.
      values <- as.numeric(ilink(as.vector(X %*% beta)))
      need(all(is.finite(values)) && all(values>=0 & values<=1),"FPM_FIXED_BASIS_SURVIVAL_INVALID")
      answer[rows,] <- t(matrix(values,nrow=H,byrow=TRUE))
    }
    answer
  }),out)
}

padml_predict_final_fpm_survival <- function(fit, design, horizons, a12=FALSE) {
  padml_prepare_fpm_fixed_basis(fit, colnames(design), horizons, a12=a12)(design)
}

padml_coxph_survival <- function(fit, design, horizons, need, baseline=NULL) {
  if (is.null(baseline)) baseline <- survival::basehaz(fit, centered=TRUE)
  need(is.data.frame(baseline) && all(c("time", "hazard") %in% names(baseline)) &&
    !"strata" %in% names(baseline) && nrow(baseline) > 0L &&
    all(is.finite(baseline$time)) && all(diff(baseline$time) > 0) &&
    all(is.finite(baseline$hazard)) && all(diff(baseline$hazard) >= 0),
    "COX_PH_BASELINE_DOMAIN_INVALID")
  positions <- findInterval(horizons, baseline$time)
  hazards <- c(0, baseline$hazard)[positions+1L]
  # BLAS dispatch changes the dot-product reduction between one and many
  # patients. Keep the centered native Cox calculation row-invariant; restore
  # the caller's option so fitting and the FPM engine retain their own policy.
  previous_matprod <- options(matprod="internal")
  on.exit(options(previous_matprod), add=TRUE)
  terms <- stats::terms(fit)
  direct <- is.matrix(design) && identical(colnames(design), names(fit$coefficients)) &&
    identical(names(fit$means), colnames(design)) && !length(fit$xlevels) &&
    !length(attr(terms,"offset")) && !length(attr(terms,"specials")$strata) &&
    !length(attr(terms,"specials")$tt) && all(attr(terms,"order")==1L) &&
    identical(gsub("`", "", attr(terms,"term.labels"), fixed=TRUE), colnames(design))
  if (direct) {
    # The locked recipe already produced numeric model columns. Match native
    # predict.coxph(reference="sample") exactly: center X first, then take
    # its original-order dot product; never recenter a precomputed LP.
    beta <- ifelse(is.na(fit$coefficients), 0, fit$coefficients)
    centered <- design - rep(fit$means, each=nrow(design))
    risk <- as.numeric(exp(drop(centered %*% beta) + 0))
  } else {
    risk <- as.numeric(predict(fit, newdata=as.data.frame(design), type="risk", reference="sample"))
  }
  need(length(risk) == nrow(design) && all(is.finite(risk)) && all(risk >= 0),
    "COX_PH_CENTERED_RISK_INVALID")
  # survfit's native Cox survivor is exp(-H0)^risk on its centered scale.
  value <- outer(risk, exp(-hazards), function(r, s) s^r)
  need(all(is.finite(value)) && all(value >= 0 & value <= 1) &&
    all(apply(value, 1L, function(row) all(diff(row) <= 1e-10))), "COX_PH_PREDICTION_INVALID")
  value
}

padml_prepare_rsf_survival <- function(fit, horizons, need) {
  times <- fit$unique.death.times
  need(identical(fit$treetype, "Survival") && inherits(fit$forest, "ranger.forest") &&
    identical(times, fit$forest$unique.death.times) && length(times)>0L &&
    all(is.finite(times)) && all(diff(times)>0) && all(is.finite(horizons)), "RSF_GRID_INVALID")
  indices <- findInterval(horizons, times)
  observed <- which(indices>0L)
  keep <- sort(unique(indices[observed]))
  terminal_counts <- vapply(fit$forest$chf, function(tree)
    sum(lengths(tree)>0L), integer(1))
  node_counts <- lengths(fit$forest$chf)
  additional_bytes <- sum(terminal_counts)*(8*length(keep)+64)+sum(node_counts)*8
  # The projection and other prepared inputs together stay below 256 MiB.
  # If projection exceeds its 128 MiB share, borrow the original forest and
  # immediately reduce bounded native predictions as before.
  project <- additional_bytes <= 128*1024^2
  if(!project) keep <- seq_along(times)
  # A bounded in-memory projection of terminal CHF values. Tree structure and
  # native tree reduction remain unchanged; the retained model stays complete.
  projected <- fit$forest
  if (length(keep) && project) {
    projected$unique.death.times <- times[keep]
    projected$chf <- lapply(projected$chf, function(tree) lapply(tree, function(chf) {
      if (!length(chf)) return(chf)
      need(length(chf)==length(times), "RSF_TERMINAL_GRID_INVALID")
      chf[keep]
    }))
  }
  columns <- match(indices[observed], keep)
  function(design) {
    need(is.matrix(design) && nrow(design)>0L && all(is.finite(design)), "RSF_DESIGN_INVALID")
    value <- matrix(1, nrow(design), length(horizons))
    if (!length(keep)) return(value)
    width <- max(1L,min(2000L,as.integer(16*1024^2/(8*length(keep)))))
    for(lo in seq.int(1L,nrow(design),by=width)) {
      rows <- lo:min(nrow(design),lo+width-1L)
      native <- as.matrix(predict(projected,data=design[rows,,drop=FALSE],num.threads=1L,seed=1L)$survival)
      if(length(rows)==1L) dim(native) <- c(1L,length(keep))
      need(identical(dim(native),c(length(rows),length(keep))) &&
        all(is.finite(native)) && all(native>=0 & native<=1), "RSF_PREDICTION_INVALID")
      value[rows,observed] <- native[,columns,drop=FALSE]
    }
    value
  }
}

padml_rsf_survival <- function(fit, design, horizons, need) {
  padml_prepare_rsf_survival(fit, horizons, need)(design)
}
