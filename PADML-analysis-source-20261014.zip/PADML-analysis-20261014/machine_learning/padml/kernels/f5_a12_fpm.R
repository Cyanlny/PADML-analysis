# A12's prescribed df=3 proportional-hazards ablation. Only the spline
# geometry changes; the installed native arithmetic and 100x10 BFGS stay intact.
padml_a12_ph_geometry <- function(lm.obj, data, timeVar, domain) {
  stopifnot(identical(domain, "A12_BASELINE_DF3_NO_TVC"),
            !any(c("AST", "ALT", "AST_ALT") %in% names(data)))
  bases <- Filter(function(x) inherits(x, "nsx"), lm.obj$model)
  stopifnot(length(bases) == 1L, ncol(bases[[1L]]) == 3L)
  basis <- bases[[1L]]
  stopifnot(identical(attr(basis, "intercept"), FALSE),
            identical(as.integer(attr(basis, "derivs")), c(2L, 2L)),
            identical(attr(basis, "centre"), FALSE), identical(attr(basis, "log"), FALSE))
  breaks <- sort(c(attr(basis, "Boundary.knots"), attr(basis, "knots")))
  stopifnot(length(breaks) == 4L, all(is.finite(breaks)), all(diff(breaks) > 0))
  z <- c(0, 1/3, 2/3, 1)
  inverse <- solve(cbind(1, z, z^2, z^3))
  pieces <- lapply(seq_len(3L), function(i) {
    lower <- breaks[[i]]; width <- breaks[[i+1L]] - lower
    frame <- data[rep(1L, 4L), , drop=FALSE]
    frame[[timeVar]] <- exp(lower + width*z)
    design <- rstpm2:::lpmatrix.lm(lm.obj, frame)
    polynomial <- inverse %*% design
    constant <- vapply(seq_len(ncol(design)), function(j)
      all(design[,j] == design[1L,j]), logical(1L))
    polynomial[2:4,constant] <- 0
    list(lower=lower, upper=breaks[[i+1L]],
         derivative=polynomial[2:4,,drop=FALSE] * (1:3)/width)
  })
  constraints <- do.call(rbind, lapply(pieces, `[[`, "derivative"))
  columns <- which(colSums(abs(constraints)) > 0)
  stopifnot(length(columns) == 3L)
  direction <- numeric(ncol(constraints))
  direction[columns] <- qr.solve(constraints[,columns,drop=FALSE], rep(c(1,0,0), 3L))
  intercept <- which(colnames(rstpm2:::lpmatrix.lm(lm.obj, data[1L,,drop=FALSE])) == "(Intercept)")
  stopifnot(length(intercept) == 1L)
  anchor <- data[1L,,drop=FALSE]
  anchor[[timeVar]] <- exp(mean(log(data[[timeVar]])))
  direction[intercept] <- -sum(rstpm2:::lpmatrix.lm(lm.obj, anchor) * direction)
  list(domain=domain, breaks=breaks, pieces=pieces, interior_direction=direction)
}

padml_a12_stpm2 <- function(formula, data) {
  stopifnot(!any(c("AST", "ALT", "AST_ALT") %in% names(data)))
  gsm <- getFromNamespace("gsm", "rstpm2")
  changed <- c(0L, 0L)
  rewrite <- function(expression) {
    if (identical(expression, quote(identical(names(tvc), "AST_ALT")))) {
      changed[[1L]] <<- changed[[1L]] + 1L
      return(quote(is.null(tvc)))
    }
    if (identical(expression, quote(as.integer(tvc[[1L]]) == 1L))) {
      changed[[2L]] <<- changed[[2L]] + 1L
      return(quote(is.null(tvc.formula)))
    }
    if (is.call(expression) || is.pairlist(expression)) {
      for (i in seq_along(expression)) {
        if (!identical(expression[[i]], quote(expr=)) && !is.null(expression[[i]]))
          expression[[i]] <- rewrite(expression[[i]])
      }
    }
    expression
  }
  body(gsm) <- rewrite(body(gsm))
  stopifnot(identical(changed, c(1L, 1L)))
  local_namespace <- new.env(parent=environment(gsm))
  local_namespace$padml_ph_domain_geometry <- padml_a12_ph_geometry
  environment(gsm) <- local_namespace
  # stpm2 evaluates its gsm call in the caller's frame. This local binding
  # changes neither the installed namespace nor another process's runtime.
  rstpm2::stpm2(formula, data=data, df=3L, tvc=NULL, tvc.formula=NULL,
                padml.fpm.domain="A12_BASELINE_DF3_NO_TVC")
}

padml_a12_ph_domain_evidence <- function(fit) {
  geometry <- fit@args$padml_domain_geometry
  stopifnot(identical(geometry$domain, "A12_BASELINE_DF3_NO_TVC"), length(geometry$pieces) == 3L)
  state <- rstpm2:::padml_ph_domain_state(geometry, as.numeric(coef(fit)))
  stopifnot(is.finite(state$minimum), state$minimum > 0)
  pieces <- lapply(state$pieces, function(piece) piece[names(piece) != "ast_alt"])
  list(definition="A12_BASELINE_DF3_CONTINUOUS_LOG_TIME_V1",
       time_domain="ALL_POSITIVE_TIMES", natural_linear_tails=TRUE,
       log_time_breaks=geometry$breaks, pieces=pieces,
       minimum_log_time_derivative=state$minimum,
       left_tail_log_time_derivatives=as.list(state$endpoints$left[[1L]]),
       right_tail_log_time_derivatives=as.list(state$endpoints$right[[3L]]),
       baseline_linear_initialization_shift=fit@args$padml_initialization_shift,
       optimizer_rounds=as.integer(fit@details$constrained_bfgs$outer.iterations),
       max_iterations_per_round=100L, max_rounds=10L,
       covariance_role="UNPENALIZED_LIKELIHOOD_CURVATURE_ONLY",
       constrained_wald_inference_validated=FALSE)
}
