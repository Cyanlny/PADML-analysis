#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(jsonlite)
})

fail <- function(code) stop(code, call. = FALSE)
need <- function(value, code) if (!isTRUE(value)) fail(code)
scalar <- function(value) unname(unlist(value, use.names = FALSE)[[1L]])

native_training_binding <- function(spec, patient_ids, centers, design, time, event) {
  # Hash the actual engine matrix/response, not a caller's input receipt.
  coordinates <- list(f4 = spec$f4_coordinates, a12 = spec$a12_coordinates,
                      a19 = spec$a19_coordinates)
  if (!is.null(spec$c10_coordinates)) coordinates$c10 <- spec$c10_coordinates
  if (!is.null(spec$a04_coordinates)) coordinates$a04 <- spec$a04_coordinates
  if (!is.null(spec$nested_full_score_source)) coordinates$nested_full_score_source <- spec$nested_full_score_source
  if (!is.null(spec$nested_full_final_source)) {
    coordinates$nested_full_final_source <- spec$nested_full_final_source
  }
  if (!is.null(spec$nested_aar_final_source)) coordinates$nested_aar_final_source <- spec$nested_aar_final_source
  if (!is.null(spec$f4_coordinates) && scalar(spec$f4_coordinates$purpose) %in% c("NESTED_OUTER", "NESTED_FULL_FINAL")) {
    lock <- unname(unlist(spec$development_lock_sha256, use.names=FALSE))
    need(is.character(lock) && length(lock) == 1L && !is.na(lock) && grepl("^[0-9a-f]{64}$", lock),
         "NESTED_NATIVE_DEVELOPMENT_LOCK_INVALID")
    coordinates$development_lock_sha256 <- spec$development_lock_sha256
  }
  list(
    model_seed = spec$model_seed, imputation = spec$imputation,
    coordinates = coordinates,
    consumed_input_sha256 = digest::digest(list(
      family = spec$family, selected_parents = spec$selected_parents,
      parameters = spec$parameters, recipe = spec$recipe,
      patient_ids = patient_ids, centers = centers,
      design = design, time = time, event = event
    ), algo = "sha256", serialize = TRUE, serializeVersion = 2L)
  )
}

validate_native_training_binding <- function(model, baseline, expected, model_path) {
  need(identical(model$training_binding, expected) &&
         identical(baseline$training_binding, expected) &&
         identical(baseline$model_object_sha256,
                   digest::digest(file=model_path, algo="sha256", serialize=FALSE)),
       "F5_REPLAY_NATIVE_TRAINING_BINDING_MISMATCH")
}

f4_model_seed <- function(family, coordinates) {
  families <- c("COX_PH","ELASTIC_NET_COX","RSF","GBM_COX","XGBOOST_COX","FPM_TVC_SET_A","COXTIME_SET_A")
  purpose <- scalar(coordinates$purpose)
  fields <- c("purpose","outer_fold","repeat","inner_fold","imputation")
  if (identical(purpose,"LEARNING_CURVE")) fields <- c(fields,"seed_ordinal","fraction_rank")
  if (identical(purpose,"FULL_PIPELINE")) fields <- c(fields,"bootstrap_replicate")
  need(family %in% families && purpose %in% c("O_FIT","NESTED_OUTER","NESTED_FULL_SCORE","NESTED_FULL_FINAL","LEARNING_CURVE","FULL_PIPELINE") &&
         identical(sort(names(coordinates)),sort(fields)), "F4_MODEL_COORDINATE_INVALID")
  number <- function(name, allowed) {
    value <- scalar(coordinates[[name]])
    need(is.numeric(value) && length(value)==1L && !is.na(value) && value %in% allowed,
         "F4_MODEL_COORDINATE_INVALID")
    as.integer(value)
  }
  if (identical(purpose,"FULL_PIPELINE")) {
    number("outer_fold",0L); number("repeat",0L); number("inner_fold",0L)
    replicate <- number("bootstrap_replicate",1:200); imputation <- number("imputation",1:20)
    return(770000000L+replicate*100L+imputation)
  }
  if (identical(purpose,"NESTED_FULL_FINAL")) {
    number("outer_fold",0L); number("repeat",0L); number("inner_fold",0L); number("imputation",1:20)
    return(300000L)
  }
  if (identical(purpose,"NESTED_FULL_SCORE")) {
    number("outer_fold",0L)
    repeat_id <- number("repeat",1:3); inner <- number("inner_fold",1:5)
    imputation <- number("imputation",1:20)
    if (family %in% c("RSF","GBM_COX","XGBOOST_COX","COXTIME_SET_A")) {
      return(350000L+imputation*100L+(repeat_id-1L)*5L+inner)
    }
    return(300000L+repeat_id*100L+inner+imputation)
  }
  outer <- number("outer_fold",1:6)
  if (identical(purpose,"LEARNING_CURVE")) {
    number("repeat",2L); number("imputation",1:5)
    inner <- number("inner_fold",1:5); ordinal <- number("seed_ordinal",1:3)
    fraction <- number("fraction_rank",1:4)
    return(600000000L+ordinal*10000000L+outer*1000000L+inner*100000L+fraction*10000L+500L+match(family,families))
  }
  repeat_id <- number("repeat",0:3); inner <- number("inner_fold",0:5)
  imputation <- number("imputation",1:20)
  need((repeat_id==0L && inner==0L) || (repeat_id>0L && inner>0L), "F4_MODEL_COORDINATE_INVALID")
  need(!identical(purpose,"NESTED_OUTER") || (repeat_id==0L && inner==0L), "F4_MODEL_COORDINATE_INVALID")
  base <- 300000L+outer*1000L
  if (repeat_id==0L) return(base+imputation)
  if (family %in% c("RSF","GBM_COX","XGBOOST_COX","COXTIME_SET_A")) {
    return(base+50000L+imputation*100L+(repeat_id-1L)*5L+inner)
  }
  base+repeat_id*100L+inner+imputation
}

validate_nested_full_final_binding <- function(spec) {
  final <- !is.null(spec$f4_coordinates) && identical(scalar(spec$f4_coordinates$purpose), "NESTED_FULL_FINAL")
  need(identical(final, !is.null(spec$nested_full_final_source)), "NESTED_FULL_FINAL_TASK_INVALID")
  if (!final) return(invisible(NULL))
  binding <- spec$nested_full_final_source
  hashes <- c("training_context_sha256", "score_development_sha256", "full_score_result_sha256",
              "family_decision_sha256", "selector_development_sha256", "selector_recipe_set_sha256",
              "selected_parents_sha256", "selected_spec_sha256", "recipe_sha256", "mice_member_sha256",
              "training_ids_sha256", "training_response_sha256")
  hash <- function(value) is.character(value) && length(value) == 1L && !is.na(value) && grepl("^[0-9a-f]{64}$", value)
  need(identical(sort(names(binding)), sort(c("kind", "program_id", hashes))) &&
         identical(scalar(binding$kind), "PADML_NESTED_FULL_FINAL_SOURCE_V1") &&
         identical(scalar(binding$program_id), "PADML_F45_REBUILD_20260925") &&
         all(vapply(hashes, function(name) hash(scalar(binding[[name]])), logical(1))) &&
         !is.null(spec$development_lock_sha256) && hash(scalar(spec$development_lock_sha256)) &&
         all(vapply(c("nested_full_score_source", "a12_coordinates", "a19_coordinates", "c10_coordinates",
                      "a04_coordinates", "registered_stop_seed", "stop_parameters"),
                    function(name) is.null(spec[[name]]), logical(1))), "NESTED_FULL_FINAL_TASK_INVALID")
  family <- scalar(spec$family)
  seed <- f4_model_seed(family, spec$f4_coordinates)
  stochastic <- family %in% c("RSF", "GBM_COX", "XGBOOST_COX", "COXTIME_SET_A")
  need(is.numeric(scalar(spec$imputation)) &&
         identical(scalar(spec$imputation), scalar(spec$f4_coordinates$imputation)) &&
         (if (stochastic) !is.null(spec$model_seed) && is.numeric(scalar(spec$model_seed)) &&
          identical(as.integer(scalar(spec$model_seed)), seed) && scalar(spec$model_seed) == seed
          else is.null(spec$model_seed)), "NESTED_FULL_FINAL_SEED_INVALID")
  invisible(NULL)
}

args <- commandArgs(trailingOnly = TRUE)
need(length(args) == 1L, "F5_R_ARGUMENT_INVALID")
spec <- fromJSON(args[[1L]], simplifyVector = FALSE)
if (as.character(scalar(spec$action)) %in% c("COMPILE_FINAL_RECIPE", "COMPILE_A12_RECIPE", "COMPILE_C10_EGFR_RECIPE", "COMPILE_A04_NEGATIVE_RECIPE", "COMPILE_A12_VALIDATION_M1_RECIPE")) {
  if (as.character(scalar(spec$action)) %in% c("COMPILE_A12_RECIPE", "COMPILE_A04_NEGATIVE_RECIPE", "COMPILE_A12_VALIDATION_M1_RECIPE")) {
    options(error = function() {
      dump.frames(file.path(dirname(normalizePath(args[[1L]], mustWork = TRUE)), "native-failure"),
                  to.file = TRUE, include.GlobalEnv = TRUE)
      quit(save = "no", status = 1L, runLast = FALSE)
    })
  }
  need(identical(sort(names(spec)), sort(c("action", "projection", "output_path"))),
       "F5_FINAL_RECIPE_INPUT_INVALID")
  suppressPackageStartupMessages(library(digest))
  script <- grep("^--file=", commandArgs(), value = TRUE)
  need(length(script) == 1L, "F5_FINAL_RECIPE_KERNEL_PATH_INVALID")
  kernel <- file.path(dirname(gsub("~+~", " ", sub("^--file=", "", script), fixed = TRUE)), "f2_model_development.R")
  # Import only the four recipe definitions, never the F2 entry point,
  # outcome reader, selector or model-fitting branches.
  required <- c("canonical_json", "sha_object", "recipe_forbidden_key", "fit_design_recipe")
  definitions <- Filter(function(expression) {
    is.call(expression) && identical(expression[[1L]], as.name("<-")) &&
      is.symbol(expression[[2L]]) && as.character(expression[[2L]]) %in% required &&
      is.call(expression[[3L]]) && identical(expression[[3L]][[1L]], as.name("function"))
  }, as.list(parse(kernel)))
  need(length(definitions) == length(required) &&
         setequal(vapply(definitions, function(expression) as.character(expression[[2L]]), character(1)), required),
       "F5_FINAL_RECIPE_KERNEL_DEFINITION_INVALID")
  for (definition in definitions) eval(definition)
  if (as.character(scalar(spec$action)) %in% c("COMPILE_A04_NEGATIVE_RECIPE", "COMPILE_A12_VALIDATION_M1_RECIPE")) {
    # One actual new analysis member; never duplicate M1 or read the QC M2.
    # Quantile type-7, ns and all isolation/health arithmetic remain original.
    changes <- integer(2L)
    m1_cardinality <- function(expression) {
      if (identical(expression, quote(length(record$members) == 20L))) {
        changes[[1L]] <<- changes[[1L]] + 1L
        return(quote(length(record$members) == 1L))
      }
      if (identical(expression, quote(seq_len(20L)))) {
        changes[[2L]] <<- changes[[2L]] + 1L
        return(quote(seq_len(1L)))
      }
      if (is.call(expression)) for (index in seq_along(expression)) {
        if (!is.null(expression[[index]]) && !identical(expression[[index]], quote(expr = )))
          expression[[index]] <- m1_cardinality(expression[[index]])
      }
      expression
    }
    body(fit_design_recipe) <- m1_cardinality(body(fit_design_recipe))
    need(identical(changes, c(1L, 2L)), "F5_A04_NEGATIVE_RECIPE_SOURCE_INVALID")
  }
  if (identical(as.character(scalar(spec$action)), "COMPILE_C10_EGFR_RECIPE")) {
    # Only the registry admission changes: the original M20 quantile/ns
    # arithmetic and all training/response isolation checks remain unchanged.
    code <- body(fit_design_recipe)
    original <- quote(identical(as.character(scalar(registry$schema_version)), "1.0.0") &&
      identical(as.character(scalar(registry$kind)), "PADML_F2_TRANSFORM_REGISTRY") &&
      length(rows) > 0L && !anyDuplicated(parents) && !"eGFR_calc" %in% parents)
    positions <- which(vapply(as.list(code), function(x) {
      is.call(x) && identical(x[[1L]], as.name("need")) && length(x) == 3L &&
        identical(x[[3L]], "F2_RECIPE_REGISTRY_RECORD_INVALID") && identical(x[[2L]], original)
    }, logical(1)))
    need(length(positions) == 1L, "F5_C10_RECIPE_KERNEL_INVALID")
    position <- positions[[1L]]
    need(identical(code[[position]][[2L]], original), "F5_C10_RECIPE_KERNEL_INVALID")
    code[[position]][[2L]] <- quote(
      identical(as.character(scalar(registry$schema_version)), "1.0.0") &&
      identical(as.character(scalar(registry$kind)), "PADML_F2_TRANSFORM_REGISTRY") &&
      length(rows) == 1L && identical(parents, "eGFR_calc") &&
      identical(as.character(scalar(rows[[1L]]$representation)), "NATURAL_SPLINE_K3"))
    body(fit_design_recipe) <- code
  }
  if (as.character(scalar(spec$action)) %in% c("COMPILE_A12_RECIPE", "COMPILE_A12_VALIDATION_M1_RECIPE")) {
    # AST_ALT's IDENTITY descriptor is a protocol constant, not a learned
    # parameter or an input column. A12 must not read its observed values.
    # Retain the shared recipe vocabulary; the selected model matrix excludes
    # the channel. All other representations run the original F2 function.
    code <- body(fit_design_recipe)
    positions <- which(vapply(as.list(code), function(x) {
      is.call(x) && identical(x[[1L]], as.name("<-")) &&
        identical(x[[2L]], as.name("representations"))
    }, logical(1)))
    need(length(positions) == 1L, "F5_A12_RECIPE_KERNEL_INVALID")
    position <- positions[[1L]]
    expression <- code[[position]][[3L]]
    need(identical(expression[[1L]], as.name("lapply")) &&
           identical(expression[[2L]], as.name("rows")) &&
           identical(expression[[3L]][[1L]], as.name("function")),
         "F5_A12_RECIPE_KERNEL_INVALID")
    block <- expression[[3L]][[3L]]
    need(identical(block[[2L]], quote(parent <- as.character(scalar(row$parent)))) &&
           identical(block[[3L]], quote(canonical_unit <- as.character(scalar(row$canonical_unit)))) &&
           identical(block[[4L]], quote(representation <- as.character(scalar(row$representation)))),
         "F5_A12_RECIPE_KERNEL_INVALID")
    constant <- quote(if (identical(parent, "AST_ALT")) {
      need(identical(canonical_unit, "ratio") && identical(representation, "IDENTITY"),
           "F5_A12_RECIPE_CONSTANT_INVALID")
      return(list(parent = parent, canonical_unit = canonical_unit,
                  representation = representation, design_df = 1L,
                  design_columns = as.list(parent), parameters = list(identity = TRUE)))
    })
    code[[position]][[3L]][[3L]][[3L]] <- as.call(append(as.list(block), list(constant), after = 4L))
    body(fit_design_recipe) <- code
  }
  value <- fit_design_recipe(spec$projection)
  writeLines(canonical_json(value, always_decimal = TRUE, digits = I(17)),
             as.character(scalar(spec$output_path)), useBytes = TRUE)
  quit(save = "no", status = 0L)
}
suppressPackageStartupMessages({
  library(survival)
  library(glmnet)
})
family <- as.character(scalar(spec$family))
action <- as.character(scalar(spec$action))
need(action %in% c("FINAL_REFIT", "REPLAY"), "F5_R_ACTION_INVALID")
replay_training <- !is.null(spec$replay_training)
need(!replay_training || identical(scalar(spec$replay_training), TRUE) &&
       identical(action, "REPLAY") && !is.null(spec$prediction_covariate_path),
     "F5_REPLAY_TRAINING_SCOPE_INVALID")
# Preserve the original R frames, inputs and any fitted object on failure.
# This handler runs only after the native error; it never retries or repairs it.
options(error = function() {
  dump.frames(
    dumpto = file.path(dirname(as.character(scalar(spec$output_path))), "native-failure"),
    to.file = TRUE, include.GlobalEnv = TRUE
  )
  quit(save = "no", status = 1L, runLast = FALSE)
})
selected <- as.character(unlist(spec$selected_parents, use.names = FALSE))
horizons <- as.numeric(unlist(spec$horizons, use.names = FALSE))
seed <- if (is.null(spec$model_seed)) NULL else as.integer(scalar(spec$model_seed))
expected_seed <- 300000L
if (!is.null(spec$f4_coordinates)) {
  need(is.null(spec$a12_coordinates) && is.null(spec$a19_coordinates), "F4_MODEL_COORDINATE_INVALID")
  expected_seed <- f4_model_seed(family,spec$f4_coordinates)
}
nested_full_score <- !is.null(spec$f4_coordinates) && identical(scalar(spec$f4_coordinates$purpose), "NESTED_FULL_SCORE")
validate_nested_full_final_binding(spec)
need(identical(nested_full_score, !is.null(spec$nested_full_score_source)), "NESTED_FULL_SCORE_SOURCE_INVALID")
if (nested_full_score) {
  binding <- spec$nested_full_score_source
  hashes <- c("training_context_sha256", "score_development_sha256", "selector_development_sha256",
              "selector_recipe_set_sha256", "selected_parents_sha256", "selected_spec_sha256")
  scope_fields <- character()
  if ("selection_horizon_months" %in% names(binding)) {
    horizon <- unname(unlist(binding$selection_horizon_months, use.names=FALSE))
    need(is.numeric(horizon) && length(horizon)==1L && !is.na(horizon) && horizon %in% c(6L,12L,24L,36L),
         "NESTED_FULL_SCORE_SOURCE_INVALID")
    scope_fields <- "selection_horizon_months"
    hashes <- c(hashes, "science_decision_sha256")
  }
  need(identical(sort(names(binding)), sort(c("kind", "program_id", hashes, scope_fields))) &&
         identical(scalar(binding$kind), "PADML_NESTED_FULL_SCORE_SOURCE_V1") &&
         identical(scalar(binding$program_id), "PADML_F45_REBUILD_20260925") &&
         all(vapply(hashes, function(name) grepl("^[0-9a-f]{64}$", scalar(binding[[name]])), logical(1))),
       "NESTED_FULL_SCORE_SOURCE_INVALID")
}
a12 <- !is.null(spec$a12_coordinates)
need(a12 || is.null(spec$nested_aar_final_source), "NESTED_AAR_FINAL_SOURCE_INVALID")
if (a12) {
  coordinates <- spec$a12_coordinates
  need(is.null(spec$a19_coordinates) && is.null(spec$c10_coordinates) && is.null(spec$a04_coordinates) &&
         identical(sort(names(coordinates)), c("branch", "imputation", "outer_fold")),
       "F5_A12_COORDINATES_INVALID")
  outer <- scalar(coordinates$outer_fold); imputation <- scalar(coordinates$imputation)
  nested_branches <- c("A12_WITHOUT_AST_ALT_DIRECT", "A12_WITHOUT_AST_ALT_TOTAL",
                       "OUTER_SELECTED_FAMILY_NO_AAR_REDEVELOPMENT")
  need(is.numeric(outer) && outer %in% 1:6 && is.numeric(imputation) && imputation %in% 1:20 &&
         identical(imputation, scalar(spec$imputation)) &&
         scalar(coordinates$branch) %in% c("WITHOUT_AST_ALT_DIRECT", "WITHOUT_AST_ALT_TOTAL", nested_branches) &&
         !any(c("AST", "ALT", "AST_ALT") %in% selected), "F5_A12_COORDINATES_INVALID")
  expected_seed <- 300000L + as.integer(outer)*1000L + as.integer(imputation)
  if (scalar(coordinates$branch) %in% nested_branches) {
    source <- spec$nested_aar_final_source
    hashes <- c("science_decision_sha256", "primary_development_lock_sha256", "training_context_sha256",
                "inputs_identity_sha256", "development_input_sha256", "parameter_source_sha256")
    extra <- c("selection_horizon_months", "epv_resolution", "parameter_epv_resolution", "epv_band")
    need(is.list(source) && identical(sort(names(source)), sort(c("kind", "program_id", hashes, extra))) &&
           identical(scalar(source$kind), "PADML_NESTED_AAR_FINAL_SOURCE_V1") &&
           identical(scalar(source$program_id), "PADML_F45_REBUILD_20260925") &&
           all(vapply(hashes, function(name) {
             value <- unname(unlist(source[[name]], use.names=FALSE))
             is.character(value) && length(value)==1L && !is.na(value) && grepl("^[0-9a-f]{64}$", value)
           }, logical(1))), "NESTED_AAR_FINAL_SOURCE_INVALID")
    valid_epv <- function(x) {
      if (!is.list(x)) return(FALSE)
      minimum <- scalar(x$minimum)
      is.numeric(minimum) && length(minimum) == 1L && minimum %in% c(10,15) &&
        identical(as.numeric(scalar(x$preferred_minimum)), 15) &&
        identical(scalar(x$fallback_used), minimum == 10)
    }
    need(scalar(source$selection_horizon_months) %in% c(6,12,24,36) &&
      valid_epv(source$epv_resolution) &&
      scalar(source$epv_band) %in% c("10_LE_EPV_LT_15", "EPV_GE_15") &&
      (if (family == "ELASTIC_NET_COX") valid_epv(source$parameter_epv_resolution)
       else is.null(source$parameter_epv_resolution)), "NESTED_AAR_FINAL_SOURCE_INVALID")
  } else need(is.null(spec$nested_aar_final_source), "NESTED_AAR_FINAL_SOURCE_INVALID")
}
if (!is.null(spec$a19_coordinates)) {
  coordinates <- spec$a19_coordinates
  need(identical(sort(names(coordinates)),
                 sort(c("virtual_outer", "repeat", "inner_fold", "seed_role"))),
       "F5_A19_COORDINATES_INVALID")
  number <- function(name, allowed) {
    value <- scalar(coordinates[[name]])
    need(is.numeric(value) && length(value) == 1L && !is.na(value) &&
           value %in% allowed, "F5_A19_COORDINATES_INVALID")
    as.integer(value)
  }
  number("virtual_outer", 0L)
  repeat_id <- number("repeat", 1:3)
  inner_id <- number("inner_fold", 1:5)
  offsets <- c(BASE = 0L, EXTRA_OFFSET_10000 = 10000L, EXTRA_OFFSET_20000 = 20000L)
  role <- scalar(coordinates$seed_role)
  need(is.character(role) && length(role) == 1L && role %in% names(offsets),
       "F5_A19_COORDINATES_INVALID")
  expected_seed <- 300000L + repeat_id * 100L + inner_id + unname(offsets[[role]])
}
if (!is.null(spec$c10_coordinates)) {
  coordinates <- spec$c10_coordinates
  need(is.null(spec$f4_coordinates) && is.null(spec$a12_coordinates) && is.null(spec$a19_coordinates) &&
         identical(sort(names(coordinates)), c("branch", "imputation", "outer_fold")),
       "F5_C10_COORDINATES_INVALID")
  outer <- scalar(coordinates$outer_fold); imputation <- scalar(coordinates$imputation)
  branch <- scalar(coordinates$branch)
  need(is.numeric(outer) && outer %in% 1:6 && is.numeric(imputation) && imputation %in% 1:20 &&
         identical(imputation, scalar(spec$imputation)) && branch %in% c("Creatinine", "eGFR_calc") &&
         branch %in% selected && sum(c("Creatinine", "eGFR_calc") %in% selected) == 1L,
       "F5_C10_COORDINATES_INVALID")
  expected_seed <- 300000L + as.integer(outer)*1000L + as.integer(imputation)
}
if (!is.null(spec$a04_coordinates)) {
  coordinates <- spec$a04_coordinates
  negative <- identical(scalar(coordinates$variant), "NEGATIVE_CONTROL")
  need(is.null(spec$f4_coordinates) && is.null(spec$a12_coordinates) && is.null(spec$a19_coordinates) &&
         is.null(spec$c10_coordinates) &&
         identical(sort(names(coordinates)), if (negative)
           c("imputation", "outer_fold", "permutation_index", "variant") else
           c("imputation", "outer_fold", "variant")),
       "F5_A04_VARIANT_COORDINATES_INVALID")
  outer <- scalar(coordinates$outer_fold); imputation <- scalar(coordinates$imputation)
  need(is.numeric(outer) && outer %in% 1:6 && is.numeric(imputation) && imputation %in% 1:20 &&
         identical(imputation, scalar(spec$imputation)) &&
         (if (negative) imputation == 1 && is.numeric(scalar(coordinates$permutation_index)) &&
             scalar(coordinates$permutation_index) %in% 1:3 else
           scalar(coordinates$variant) %in% c("RAW_DONOR5", "RAW_DONOR3", "RAW_DONOR10")),
       "F5_A04_VARIANT_COORDINATES_INVALID")
  expected_seed <- 300000L + as.integer(outer)*1000L + as.integer(imputation)
}
parameters <- if (is.null(spec$parameters)) list() else spec$parameters
if (a12 && family == "FPM_TVC_SET_A") need(
  identical(sort(names(parameters)), c("df", "tvc_df")) &&
    identical(as.numeric(scalar(parameters$df)), 3) &&
    identical(as.numeric(scalar(parameters$tvc_df)), 0), "F5_A12_FPM_SPEC_INVALID")
recipe <- spec$recipe
need(
  family %in% c("COX_PH", "ELASTIC_NET_COX", "RSF", "GBM_COX", "FPM_TVC_SET_A") &&
    length(selected) > 0L && (a12 || "AST_ALT" %in% selected) && !anyDuplicated(selected) &&
    identical(horizons, as.numeric(0:36)),
  "F5_R_SPEC_INVALID"
)

predictor_rows <- recipe$predictor_rows
covariates <- read.csv(
  as.character(scalar(spec$covariate_path)), check.names = FALSE,
  stringsAsFactors = FALSE, colClasses = "character", encoding = "UTF-8"
)
if (!is.null(spec$nested_aar_final_source) && scalar(spec$a12_coordinates$branch) != "A12_WITHOUT_AST_ALT_DIRECT") {
  need(!any(c("AST", "ALT", "AST_ALT") %in% names(covariates)), "NESTED_AAR_FINAL_INFORMATION_CHANNEL_PRESENT")
}
response <- read.csv(
  as.character(scalar(spec$response_path)), check.names = FALSE,
  stringsAsFactors = FALSE, colClasses = "character", encoding = "UTF-8"
)
need(
  identical(names(response), c("Patient_ID", "All_Cause_Death", "Death_Followup_months")) &&
    nrow(covariates) == nrow(response) && nrow(covariates) > 10L &&
    identical(as.character(covariates$Patient_ID), as.character(response$Patient_ID)) &&
    all(c("Patient_ID", "Center", selected) %in% names(covariates)) &&
    !anyDuplicated(covariates$Patient_ID),
  "F5_R_INPUT_INVALID"
)
time <- suppressWarnings(as.numeric(response$Death_Followup_months))
event <- suppressWarnings(as.integer(response$All_Cause_Death))
need(
  all(is.finite(time)) && all(time > 0) && all(event %in% c(0L, 1L)) &&
    any(event == 1L),
  "F5_R_RESPONSE_INVALID"
)
transform <- recipe$transform_recipe
if (!is.null(spec$c10_coordinates) && "eGFR_calc" %in% selected &&
    family %in% c("COX_PH", "ELASTIC_NET_COX", "FPM_TVC_SET_A")) {
  alternative <- recipe$c10_egfr_representation
  need(!is.null(alternative) && identical(scalar(alternative$parent), "eGFR_calc") &&
         identical(scalar(alternative$representation), "NATURAL_SPLINE_K3"), "F5_C10_EGFR_RECIPE_REQUIRED")
  transform$representations <- c(transform$representations, list(alternative))
}
script <- grep("^--file=", commandArgs(), value = TRUE)
need(length(script) == 1L, "F5_R_KERNEL_PATH_INVALID")
source(
  file.path(dirname(gsub("~+~", " ", sub("^--file=", "", script), fixed = TRUE)), "f5_design.R"),
  local = TRUE
)
if (a12 && family == "FPM_TVC_SET_A") source(
  file.path(dirname(gsub("~+~", " ", sub("^--file=", "", script), fixed = TRUE)), "f5_a12_fpm.R"), local=TRUE)
prepared <- padml_prepare_final_r_design(
  covariates, selected, predictor_rows, transform, family, scalar, need
)
covariates <- prepared$covariates
rows <- prepared$rows
design <- prepared$design
training_design <- design
training_binding <- native_training_binding(
  spec, as.character(covariates$Patient_ID), as.character(covariates$Center), design, time, event)

breslow <- function(time, event, risk) {
  order <- order(time, method="radix")
  ordered_time <- time[order]
  starts <- c(1L, which(diff(ordered_time) != 0) + 1L)
  groups <- rep.int(seq_along(starts), diff(c(starts, length(time)+1L)))
  deaths <- as.numeric(rowsum(as.integer(event[order] == 1L), groups, reorder=FALSE))
  included <- deaths > 0L
  denominators <- rev(cumsum(rev(risk[order])))[starts][included]
  list(times=ordered_time[starts][included], cumulative=cumsum(deaths[included] / denominators))
}

survival_from_risk <- function(base, risk) {
  hazard <- vapply(horizons, function(value) {
    index <- which(base$times <= value)
    if (!length(index)) 0 else base$cumulative[max(index)]
  }, numeric(1))
  exp(-outer(risk, hazard))
}

validate_coxph_fit_health <- function(fit, warning_count, expected_columns) {
  coefficients <- fit$coefficients
  covariance <- fit$var
  iterations <- as.integer(fit$iter)
  expected_columns <- as.integer(expected_columns)
  need(
    inherits(fit, "coxph") && identical(as.integer(warning_count), 0L) &&
      expected_columns > 0L && length(coefficients) == expected_columns &&
      all(is.finite(coefficients)) && !anyNA(coefficients) &&
      is.matrix(covariance) &&
      identical(dim(covariance), c(expected_columns, expected_columns)) &&
      all(is.finite(covariance)) &&
      max(abs(covariance - t(covariance))) <= 1e-10 &&
      qr(covariance)$rank == expected_columns && all(diag(covariance) >= 0) &&
      length(fit$loglik) == 2L && all(is.finite(fit$loglik)) &&
      length(iterations) == 1L && !is.na(iterations) && iterations >= 0L,
    "F5_COX_PH_FIT_HEALTH_INVALID"
  )
  list(
    converged = TRUE, warning_count = 0L,
    coefficient_count = expected_columns,
    covariance_rank = expected_columns,
    iteration_count = iterations
  )
}

fpm_constraint_identity <- function() {
  correction <- packageDescription("rstpm2")[["PADML-Correction"]]
  need(
    identical(as.character(packageVersion("rstpm2")), "1.7.1.9011") &&
      identical(correction, "ph-continuous-domain-bfgs-v1") &&
      identical(packageDescription("rstpm2")[["PADML-Initialization"]],
                "cox-eps-1e-11-iter20-v1"),
    "F5_FPM_CONSTRAINT_CORRECTION_MISSING"
  )
  correction
}

validate_fpm_fit_health <- function(fit, warning_count, expected_df) {
  correction <- fpm_constraint_identity()
  need(inherits(fit, "stpm2"), "F5_FPM_FIT_HEALTH_INVALID")
  details <- fit@details
  coefficients <- coef(fit)
  covariance <- vcov(fit)
  coefficient_count <- length(coefficients)
  expected_df <- as.integer(unlist(expected_df, use.names = FALSE))
  controls <- fit@args
  native_args <- controls
  native_args$init <- as.numeric(coefficients)
  native_args$return_type <- "feasible"
  native_feasible <- .Call("model_output", native_args, PACKAGE = "rstpm2")
  bases <- Filter(function(value) inherits(value, "nsx"), fit@lm$model)
  need(
    isTRUE(native_feasible) && identical(as.integer(warning_count), 0L) &&
      is.list(details) && identical(as.integer(details$convergence), 0L) &&
      identical(as.integer(details$conv), 0L) &&
      is.numeric(details$maxgrad) && length(details$maxgrad) == 1L &&
      is.finite(details$maxgrad) && details$maxgrad >= 0 && is.finite(fit@min) &&
      identical(as.character(fit@optimizer), "optim") &&
      identical(controls$optimiser, "BFGS") &&
      identical(as.numeric(controls$reltol), 1e-10) &&
      identical(as.numeric(controls$reltol_search), 1e-10) &&
      identical(as.numeric(controls$reltol_outer), 1e-5) &&
      identical(as.integer(controls$outer_optim), 1L) &&
      identical(as.numeric(controls$maxkappa), 1000) &&
      length(controls$kappa.final) == 1L && is.finite(controls$kappa.final) &&
      controls$kappa.final > 0 && controls$kappa.final <= controls$maxkappa &&
      length(controls$parscale) == coefficient_count &&
      all(is.finite(controls$parscale)) && all(controls$parscale == 1) &&
      isTRUE(controls$log.time.transform) &&
      identical(expected_df, if (a12) 3L else c(3L, 1L)) && length(bases) == length(expected_df) &&
      identical(as.integer(vapply(bases, ncol, integer(1L))), expected_df) &&
      coefficient_count > 0L && all(is.finite(coefficients)) &&
      is.matrix(covariance) &&
      identical(dim(covariance), c(coefficient_count, coefficient_count)) &&
      all(is.finite(covariance)) &&
      max(abs(covariance - t(covariance))) <= 1e-10 &&
      qr(covariance)$rank == coefficient_count && all(diag(covariance) >= 0),
    "F5_FPM_FIT_HEALTH_INVALID"
  )
  spline_bases <- lapply(seq_along(bases), function(index) {
    basis <- bases[[index]]
    knots <- attr(basis, "knots")
    boundaries <- attr(basis, "Boundary.knots")
    need(
      is.numeric(knots) && length(knots) == expected_df[[index]] - 1L &&
        all(is.finite(knots)) && all(diff(knots) > 0) &&
        is.numeric(boundaries) && length(boundaries) == 2L &&
        all(is.finite(boundaries)) && diff(boundaries) > 0 &&
        all(knots > boundaries[[1L]] & knots < boundaries[[2L]]) &&
        identical(attr(basis, "intercept"), FALSE) &&
        identical(as.integer(attr(basis, "derivs")), c(2L, 2L)) &&
        identical(attr(basis, "centre"), FALSE) &&
        identical(attr(basis, "log"), FALSE),
      "F5_FPM_ACTUAL_SPLINE_EVIDENCE_INVALID"
    )
    list(
      role = c("BASELINE_LOG_TIME", "AST_ALT_TVC_LOG_TIME")[[index]],
      df = ncol(basis), knots = as.list(as.numeric(knots)),
      boundary_knots = as.list(as.numeric(boundaries)),
      intercept = attr(basis, "intercept"),
      derivatives = as.list(as.integer(attr(basis, "derivs"))),
      centre = attr(basis, "centre"), log = attr(basis, "log")
    )
  })
  list(
    converged = TRUE, warning_count = 0L,
    optimizer = as.character(fit@optimizer),
    optimizer_convergence = as.integer(details$convergence),
    coefficient_count = coefficient_count,
    covariance_rank = coefficient_count,
    fit_evidence = list(
      constraint_correction = correction,
      native_feasible = native_feasible,
      optimizer_method = controls$optimiser,
      termination_code = as.integer(details$conv),
      maximum_gradient = as.numeric(details$maxgrad),
      objective_value = as.numeric(fit@min),
      controls = list(
        reltol = as.numeric(controls$reltol),
        reltol_search = as.numeric(controls$reltol_search),
        reltol_outer = as.numeric(controls$reltol_outer),
        outer_optim = as.integer(controls$outer_optim),
        parscale = as.list(as.numeric(controls$parscale)),
        maxkappa = as.numeric(controls$maxkappa),
        final_kappa = as.numeric(controls$kappa.final)
      ),
      log_time_transform = controls$log.time.transform,
      spline_bases = spline_bases,
      continuous_domain = if (a12) padml_a12_ph_domain_evidence(fit) else rstpm2:::padml_ph_domain_evidence(fit),
      constrained_optimality = rstpm2:::padml_ph_optimality_evidence(fit)
    )
  )
}

validate_rsf_fit_health <- function(
  fit, warning_count, expected_trees, expected_columns, expected_mtry
) {
  expected_trees <- as.integer(expected_trees)
  expected_mtry <- as.integer(expected_mtry)
  expected_columns <- as.character(expected_columns)
  death_times <- as.numeric(fit$unique.death.times)
  need(
    inherits(fit, "ranger") && inherits(fit$forest, "ranger.forest") &&
      identical(as.integer(warning_count), 0L) && expected_trees > 0L &&
      length(expected_columns) > 0L && expected_mtry > 0L &&
      identical(as.integer(fit$num.trees), expected_trees) &&
      identical(as.integer(fit$forest$num.trees), expected_trees) &&
      identical(length(fit$forest$child.nodeIDs), expected_trees) &&
      identical(as.integer(fit$num.independent.variables), length(expected_columns)) &&
      identical(as.character(fit$forest$independent.variable.names), expected_columns) &&
      identical(as.integer(fit$mtry), expected_mtry) &&
      is.numeric(fit$prediction.error) && length(fit$prediction.error) == 1L &&
      is.finite(fit$prediction.error) && length(death_times) > 0L &&
      all(is.finite(death_times)) && all(diff(death_times) > 0) &&
      is.matrix(fit$survival) && nrow(fit$survival) == fit$num.samples &&
      ncol(fit$survival) == length(death_times) &&
      all(is.finite(fit$survival)) &&
      all(fit$survival >= 0 & fit$survival <= 1),
    "F5_RSF_FIT_HEALTH_INVALID"
  )
  list(
    converged = TRUE, warning_count = 0L, tree_count = expected_trees,
    independent_variable_count = length(expected_columns),
    mtry = expected_mtry, death_time_count = length(death_times),
    prediction_error = as.numeric(fit$prediction.error)
  )
}

gbm_cox_objective_identity <- function() {
  version <- as.character(packageVersion("gbm"))
  correction <- packageDescription("gbm")[["PADML-Correction"]]
  need(
    identical(version, "2.3.1.9001") &&
      identical(correction, "cox-breslow-ties-v1"),
    "F5_GBM_COX_CORRECTION_MISSING"
  )
  list(
    implementation = "GROUPED_BRESLOW_V1", engine_version = version,
    source_correction = correction
  )
}

validate_gbm_fit_health <- function(
  fit, warning_count, expected_trees, expected_columns, expected_rows
) {
  expected_trees <- as.integer(expected_trees)
  expected_columns <- as.character(expected_columns)
  expected_rows <- as.integer(expected_rows)
  need(
    inherits(fit, "gbm") && identical(as.integer(warning_count), 0L) &&
      expected_trees > 0L && length(expected_columns) > 0L &&
      expected_rows > 0L &&
      identical(as.integer(fit$n.trees), expected_trees) &&
      identical(length(fit$trees), expected_trees) &&
      identical(as.integer(fit$nTrain), expected_rows) &&
      identical(as.character(fit$var.names), expected_columns) &&
      length(fit$train.error) == expected_trees &&
      all(is.finite(fit$train.error)) &&
      length(fit$oobag.improve) == expected_trees &&
      all(is.finite(fit$oobag.improve)) &&
      length(fit$fit) == expected_rows && all(is.finite(fit$fit)) &&
      is.numeric(fit$initF) && length(fit$initF) == 1L && is.finite(fit$initF),
    "F5_GBM_FIT_HEALTH_INVALID"
  )
  list(
    converged = TRUE, warning_count = 0L, tree_count = expected_trees,
    training_row_count = expected_rows,
    independent_variable_count = length(expected_columns),
    training_loss_count = length(fit$train.error),
    minimum_training_loss = min(fit$train.error),
    maximum_training_loss = max(fit$train.error),
    cox_objective = gbm_cox_objective_identity()
  )
}
round_half_up_decimal_product <- function(value, multiplier) {
  text <- as.character(scalar(value))
  multiplier <- as.integer(multiplier)
  need(
    grepl("^(0(\\.[0-9]+)?|1(\\.0+)?)$", text) && multiplier > 0L,
    "F5_RSF_MTRY_DECIMAL_INVALID"
  )
  scale <- if (grepl("\\.", text)) {
    nchar(sub("^[^.]*\\.", "", text))
  } else {
    0L
  }
  digits <- as.integer(strsplit(gsub("\\.", "", text), "", fixed = TRUE)[[1L]])
  carry <- 0L
  product <- integer(length(digits))
  for (index in rev(seq_along(digits))) {
    current <- digits[[index]] * multiplier + carry
    product[[index]] <- current %% 10L
    carry <- current %/% 10L
  }
  prefix <- integer()
  while (carry > 0L) {
    prefix <- c(carry %% 10L, prefix)
    carry <- carry %/% 10L
  }
  product_text <- paste0(c(prefix, product), collapse = "")
  if (nchar(product_text) <= scale) {
    product_text <- paste0(
      paste0(rep("0", scale + 1L - nchar(product_text)), collapse = ""),
      product_text
    )
  }
  split <- nchar(product_text) - scale
  whole <- as.integer(substr(product_text, 1L, split))
  first_fraction <- if (scale) {
    as.integer(substr(product_text, split + 1L, split + 1L))
  } else {
    0L
  }
  rounded <- whole + as.integer(first_fraction >= 5L)
  need(
    rounded >= 0L && rounded <= multiplier,
    "F5_RSF_MTRY_DECIMAL_INVALID"
  )
  rounded
}
write_objects <- function(model, baseline) {
  model$training_binding <- training_binding
  baseline$training_binding <- training_binding
  saveRDS(model, as.character(scalar(spec$model_path)), version = 3L)
  baseline$model_object_sha256 <- digest::digest(
    file=as.character(scalar(spec$model_path)), algo="sha256", serialize=FALSE)
  saveRDS(baseline, as.character(scalar(spec$baseline_path)), version = 3L)
}
glmnet_engine_design <- function(value, penalty) {
  need(
    is.matrix(value) && ncol(value) >= 1L &&
      length(penalty) == ncol(value),
    "F5_ELASTIC_ENGINE_DESIGN_INVALID"
  )
  if (ncol(value) >= 2L) {
    return(list(x = value, penalty = penalty, inert_column = NULL))
  }
  need(
    (identical(colnames(value), "AST_ALT") && identical(as.numeric(penalty), 0) && !a12) ||
      (a12 && !any(colnames(value) %in% c("AST", "ALT", "AST_ALT", "PADML_GLMNET_INERT_ZERO")) &&
        identical(as.numeric(penalty), 1)),
    "F5_ELASTIC_SINGLE_COLUMN_DESIGN_INVALID"
  )
  inert_column <- "PADML_GLMNET_INERT_ZERO"
  x <- cbind(value, PADML_GLMNET_INERT_ZERO = 0)
  need(all(x[, inert_column] == 0), "F5_ELASTIC_INERT_COLUMN_INVALID")
  list(x = x, penalty = c(penalty, 1), inert_column = inert_column)
}

if (identical(action, "REPLAY")) {
  training_covariates <- covariates
  if (!is.null(spec$prediction_covariate_path)) {
    application <- read.csv(
      as.character(scalar(spec$prediction_covariate_path)), check.names = FALSE,
      stringsAsFactors = FALSE, colClasses = "character", encoding = "UTF-8"
    )
    need(
      nrow(application) > 0L &&
        all(c("Patient_ID", "Center", selected) %in% names(application)) &&
        !anyDuplicated(application$Patient_ID) &&
        !any(c("All_Cause_Death", "Death_Followup_months") %in% names(application)),
      "F5_REPLAY_APPLICATION_INPUT_INVALID"
    )
    if (!is.null(spec$nested_aar_final_source) && scalar(spec$a12_coordinates$branch) != "A12_WITHOUT_AST_ALT_DIRECT") {
      need(!any(c("AST", "ALT", "AST_ALT") %in% names(application)), "NESTED_AAR_FINAL_INFORMATION_CHANNEL_PRESENT")
    }
    application_prepared <- padml_prepare_final_r_design(
      application, selected, predictor_rows, transform, family, scalar, need
    )
    need(identical(colnames(application_prepared$design), colnames(design)),
         "F5_REPLAY_DESIGN_DRIFT")
    covariates <- application_prepared$covariates
    design <- application_prepared$design
  }
  # Reuse the frozen recipe above; never enter any fitting branch below.
  if (family == "RSF") suppressPackageStartupMessages(library(ranger))
  if (family == "GBM_COX") suppressPackageStartupMessages(library(gbm))
  if (family == "FPM_TVC_SET_A") suppressPackageStartupMessages(library(rstpm2))
  model <- readRDS(as.character(scalar(spec$model_path)))
  baseline <- readRDS(as.character(scalar(spec$baseline_path)))
  validate_native_training_binding(model, baseline, training_binding,
                                    as.character(scalar(spec$model_path)))
  need(identical(model$design_columns, colnames(design)) &&
         identical(model$selected_parents, selected), "F5_REPLAY_DESIGN_DRIFT")
  fit <- model$fit
  if (family %in% c("ELASTIC_NET_COX", "GBM_COX")) {
    need(length(baseline$baseline$times) > 0L &&
           length(baseline$baseline$times) == length(baseline$baseline$cumulative) &&
           all(is.finite(baseline$baseline$times)) && all(baseline$baseline$times > 0) &&
           all(diff(baseline$baseline$times) > 0) &&
           all(is.finite(baseline$baseline$cumulative)) && all(baseline$baseline$cumulative >= 0) &&
           all(diff(baseline$baseline$cumulative) >= 0), "F5_REPLAY_BASELINE_INVALID")
  }
  if (family == "COX_PH") {
    need(identical(baseline$baseline, basehaz(fit, centered = TRUE)), "F5_REPLAY_BASELINE_DRIFT")
  } else if (family == "ELASTIC_NET_COX") {
    need(identical(as.numeric(model$alpha), as.numeric(scalar(parameters$alpha))) &&
      identical(as.numeric(model$ratio), as.numeric(scalar(parameters$ratio))) &&
      identical(as.numeric(model$lambda), as.numeric(scalar(parameters$lambda))), "F5_REPLAY_PARAMETER_DRIFT")
    penalty <- rep(1, ncol(training_design)); penalty[grepl("^AST_ALT$", colnames(training_design))] <- 0
    training_engine_design <- glmnet_engine_design(training_design, penalty)
    need(identical(model$inert_column, training_engine_design$inert_column), "F5_REPLAY_DESIGN_DRIFT")
    if (a12 && !is.null(training_engine_design$inert_column)) {
      beta <- as.matrix(coef(fit, s=model$lambda))
      need(training_engine_design$inert_column %in% rownames(beta) &&
        all(is.finite(beta[training_engine_design$inert_column, ])) &&
        all(beta[training_engine_design$inert_column, ] == 0), "F5_ELASTIC_INERT_COLUMN_INVALID")
    }
    training_risk <- exp(as.numeric(predict(fit, training_engine_design$x, s=model$lambda, type="link")))
    need(all(is.finite(training_risk)) && all(training_risk > 0) &&
      identical(baseline$baseline, breslow(time,event,training_risk)), "F5_REPLAY_BASELINE_DRIFT")
  } else if (family == "GBM_COX") {
    gbm_cox_objective_identity()
    trees <- as.integer(scalar(parameters$locked_trees))
    need(identical(as.integer(fit$n.trees), trees), "F5_REPLAY_PARAMETER_DRIFT")
    training_risk <- exp(as.numeric(predict(fit, training_design, n.trees=trees, type="link")))
    need(all(is.finite(training_risk)) && all(training_risk > 0) &&
      identical(baseline$baseline, breslow(time,event,training_risk)), "F5_REPLAY_BASELINE_DRIFT")
  } else if (family == "RSF") {
    need(identical(baseline$unique_death_times, fit$unique.death.times), "F5_REPLAY_BASELINE_DRIFT")
  } else {
    fpm_constraint_identity()
    need(identical(as.numeric(baseline$coefficients), as.numeric(coef(fit))), "F5_REPLAY_BASELINE_DRIFT")
  }
  prepared_survival <- if(family=="RSF") padml_prepare_rsf_survival(fit,horizons,need) else
    if(family=="FPM_TVC_SET_A") padml_prepare_fpm_fixed_basis(fit,colnames(training_design),horizons,a12,need) else NULL
  predict_population <- function(covariates, design) {
    survival <- withCallingHandlers({
      if (family == "COX_PH") {
        colnames(design) <- model$engine_columns
        padml_coxph_survival(fit, design, horizons, need, baseline$baseline)
      } else if (family == "ELASTIC_NET_COX") {
        engine_design <- glmnet_engine_design(design, penalty)
        need(identical(model$inert_column, engine_design$inert_column), "F5_REPLAY_DESIGN_DRIFT")
        risk <- exp(as.numeric(predict(fit, engine_design$x, s=model$lambda, type="link")))
        need(all(is.finite(risk)) && all(risk > 0), "F5_REPLAY_RISK_INVALID")
        survival_from_risk(baseline$baseline, risk)
      } else if (family == "GBM_COX") {
        risk <- exp(as.numeric(predict(fit, design, n.trees=trees, type="link")))
        need(all(is.finite(risk)) && all(risk > 0), "F5_REPLAY_RISK_INVALID")
        survival_from_risk(baseline$baseline, risk)
      } else if (family == "RSF") {
        prepared_survival(design)
      } else {
        prepared_survival(design)
      }
    }, warning = function(condition) stop(condition))
  need(identical(dim(survival), c(nrow(covariates), length(horizons))) &&
         all(is.finite(survival)) && all(survival >= 0 & survival <= 1) &&
         all(survival[, 1L] == 1) &&
         all(apply(survival, 1L, function(row) all(diff(row) <= 1e-10))),
       "F5_REPLAY_PREDICTION_INVALID")
  list(
    patient_ids = as.list(as.character(covariates$Patient_ID)),
    horizons = as.list(as.integer(horizons)),
    survival = lapply(seq_len(nrow(survival)), function(index) as.list(as.numeric(survival[index, ])))
  )
  }
  # Keep the original two prediction calls and their population ordering,
  # while loading the same frozen native objects only once in this R process.
  if (replay_training) training_prediction <- predict_population(training_covariates, training_design)
  result <- predict_population(covariates, design)
  if (replay_training) result$training_prediction <- training_prediction
  if (!is.null(spec$single_parity)) {
    need(identical(scalar(spec$single_parity), TRUE) && !is.null(spec$prediction_covariate_path),
      "F5_REPLAY_PARITY_SCOPE_INVALID")
    result$single_predictions <- lapply(seq_len(nrow(covariates)), function(i)
      predict_population(covariates[i,,drop=FALSE], design[i,,drop=FALSE]))
  }
  writeLines(toJSON(result, auto_unbox = TRUE, null = "null", na = "null", digits = I(17)),
  as.character(scalar(spec$output_path)), useBytes = TRUE)
  quit(save = "no", status = 0L)
}

warnings <- character()
health <- list(engine_threads = 1L, final_model_fit_count = 1L)
survival <- NULL
if (family == "COX_PH") {
  engine_columns <- sprintf(".padml_x_%04d", seq_len(ncol(design)))
  engine_design <- design
  colnames(engine_design) <- engine_columns
  frame <- data.frame(
    .time = time, .event = event, engine_design, check.names = FALSE
  )
  formula <- Surv(.time, .event) ~ .
  fit <- withCallingHandlers(
    coxph(
      formula, data = frame, ties = "breslow", x = TRUE, y = TRUE,
      singular.ok = FALSE,
      control = coxph.control(eps = 1e-11, iter.max = 100L)
    ),
    warning = function(condition) {
      warnings <<- c(warnings, class(condition)[[1L]])
      invokeRestart("muffleWarning")
    }
  )
  need(
    length(fit$coefficients) > 0L && !anyNA(fit$coefficients) &&
      all(is.finite(fit$coefficients)) &&
      identical(names(fit$coefficients), engine_columns),
    "F5_COX_PH_COEFFICIENT_INVALID"
  )
  cox_health <- validate_coxph_fit_health(
    fit, length(warnings), ncol(design)
  )
  baseline <- basehaz(fit, centered=TRUE)
  survival <- withCallingHandlers(padml_coxph_survival(fit, engine_design, horizons, need, baseline),
    warning=function(condition) {warnings <<- c(warnings, class(condition)[[1L]]); invokeRestart("muffleWarning")})
  need(length(warnings) == 0L, "F5_COX_PH_PREDICTION_INVALID")
  write_objects(
    list(
      fit = fit, selected_parents = selected,
      design_columns = colnames(design), engine_columns = engine_columns
    ),
    list(engine = "survival::coxph", centered = TRUE, baseline = baseline)
  )
  health <- c(
    health,
    list(engine = "survival::coxph", ties = "breslow"),
    cox_health
  )
} else if (family == "ELASTIC_NET_COX") {
  alpha <- as.numeric(scalar(parameters$alpha))
  ratio <- as.numeric(scalar(parameters$ratio))
  lambda <- as.numeric(scalar(parameters$lambda))
  maximum <- as.numeric(scalar(parameters$lambda_upper_bound$resolved_lambda_max))
  need(
    is.finite(alpha) && alpha >= .01 && alpha <= 1 &&
      is.finite(ratio) && ratio >= .0001 && ratio <= 1 &&
      is.finite(lambda) && lambda > 0 && is.finite(maximum) && maximum > 0 &&
      abs(lambda - maximum * ratio) <=
        1e-12 * max(abs(lambda), abs(maximum * ratio), 1e-15),
    "F5_ELASTIC_PARAMETER_INVALID"
  )
  penalty <- rep(1, ncol(design)); penalty[grepl("^AST_ALT$", colnames(design))] <- 0
  engine_design <- glmnet_engine_design(design, penalty)
  fit <- glmnet(
    engine_design$x, Surv(time, event), family = "cox", cox.ties = "breslow",
    alpha = alpha, lambda = lambda, penalty.factor = engine_design$penalty,
    standardize = TRUE
  )
  need(length(fit$jerr) == 1L && fit$jerr == 0L &&
         all(is.finite(as.matrix(coef(fit, s = lambda)))),
       "F5_ELASTIC_FIT_INVALID")
  fitted_coefficients <- as.matrix(coef(fit, s = lambda))[, 1L]
  coefficient_positions <- match(colnames(design), names(fitted_coefficients))
  need(
    !anyNA(coefficient_positions),
    "F5_ELASTIC_COEFFICIENT_ID_INVALID"
  )
  engine_center <- colMeans(engine_design$x)
  engine_scale <- sqrt(colMeans(sweep(
    engine_design$x, 2L, engine_center, "-"
  ) ^ 2))
  coefficient_scale <- engine_scale[colnames(design)]
  raw_coefficients <- fitted_coefficients[coefficient_positions]
  standardized_coefficients <- raw_coefficients * coefficient_scale
  need(
    length(raw_coefficients) == ncol(design) &&
      all(is.finite(raw_coefficients)) &&
      all(is.finite(coefficient_scale)) && all(coefficient_scale >= 0) &&
      all(is.finite(standardized_coefficients)),
    "F5_ELASTIC_STANDARDIZED_COEFFICIENT_INVALID"
  )
  if (!is.null(engine_design$inert_column)) {
    inert_coefficient <- as.matrix(coef(fit, s = lambda))[
      engine_design$inert_column, , drop = FALSE
    ]
    need(
      all(is.finite(inert_coefficient)) && all(inert_coefficient == 0),
      "F5_ELASTIC_INERT_COLUMN_INVALID"
    )
  }
  risk <- exp(as.numeric(predict(
    fit, engine_design$x, s = lambda, type = "link"
  )))
  need(all(is.finite(risk)) && all(risk > 0), "F5_ELASTIC_RISK_INVALID")
  baseline <- breslow(time, event, risk)
  need(
    all(is.finite(baseline$times)) && all(is.finite(baseline$cumulative)),
    "F5_ELASTIC_BASELINE_INVALID"
  )
  survival <- survival_from_risk(baseline, risk)
  write_objects(
    list(
      fit = fit, alpha = alpha, ratio = ratio, lambda = lambda,
      selected_parents = selected,
      design_columns = colnames(design),
      inert_column = engine_design$inert_column,
      coefficient_scale = unname(coefficient_scale),
      raw_coefficients = unname(raw_coefficients),
      standardized_coefficients = unname(standardized_coefficients)
    ),
    list(engine = "glmnet::glmnet", baseline = baseline)
  )
  health <- c(health, list(
    engine = "glmnet::glmnet", alpha = alpha, ratio = ratio,
    lambda = lambda, lambda_max = maximum,
    lambda_upper_bound = parameters$lambda_upper_bound,
    converged = TRUE
  ))
} else if (family == "RSF") {
  suppressPackageStartupMessages(library(ranger))
  need(!is.null(seed) && seed == expected_seed, "F5_RSF_SEED_INVALID")
  max_depth <- as.character(scalar(parameters$max_depth))
  mtry <- min(
    ncol(design),
    max(
      1L,
      round_half_up_decimal_product(
        parameters$mtry_fraction, ncol(design)
      )
    )
  )
  set.seed(seed, kind = "L'Ecuyer-CMRG")
  arguments <- list(
    x = design, y = Surv(time, event),
    num.trees = as.integer(scalar(parameters$num_trees)), mtry = mtry,
    min.node.size = as.integer(scalar(parameters$min_node_size)),
    sample.fraction = as.numeric(scalar(parameters$sample_fraction)),
    splitrule = as.character(scalar(parameters$splitrule)), seed = seed,
    num.threads = 1L, write.forest = TRUE
  )
  if (!identical(toupper(max_depth), "UNLIMITED")) {
    arguments$max.depth <- as.integer(max_depth)
  }
  fit_warnings <- character()
  fit <- withCallingHandlers(
    do.call(ranger, arguments),
    warning = function(condition) {
      fit_warnings <<- c(fit_warnings, class(condition)[[1L]])
      invokeRestart("muffleWarning")
    }
  )
  rsf_health <- validate_rsf_fit_health(
    fit, length(fit_warnings), as.integer(scalar(parameters$num_trees)),
    colnames(design), mtry
  )
  survival <- withCallingHandlers(
    padml_rsf_survival(fit, design, horizons, need),
    warning = function(condition) {
      fit_warnings <<- c(fit_warnings, class(condition)[[1L]])
      invokeRestart("muffleWarning")
    }
  )
  need(length(fit_warnings) == 0L, "F5_RSF_FIT_WARNING")
  write_objects(
    list(fit = fit, selected_parents = selected, design_columns = colnames(design)),
    list(engine = "ranger::ranger", unique_death_times = fit$unique.death.times)
  )
  health <- c(
    health,
    list(
      engine = "ranger::ranger",
      num_trees = as.integer(scalar(parameters$num_trees))
    ),
    rsf_health
  )
} else if (family == "GBM_COX") {
  suppressPackageStartupMessages(library(gbm))
  need(!is.null(seed) && seed == expected_seed, "F5_GBM_SEED_INVALID")
  gbm_cox_objective_identity()
  trees <- as.integer(scalar(parameters$locked_trees))
  maximum <- as.integer(scalar(parameters$max_trees))
  need(trees > 0L && trees <= maximum, "F5_GBM_TREE_LOCK_INVALID")
  set.seed(seed, kind = "L'Ecuyer-CMRG")
  fit_warnings <- character()
  fit <- withCallingHandlers(
    gbm.fit(
      x = design, y = Surv(time, event), distribution = "coxph",
      n.trees = trees,
      interaction.depth = as.integer(scalar(parameters$interaction_depth)),
      shrinkage = as.numeric(scalar(parameters$shrinkage)),
      n.minobsinnode = as.integer(scalar(parameters$min_observations_in_node)),
      bag.fraction = as.numeric(scalar(parameters$bag_fraction)),
      nTrain = nrow(design), keep.data = FALSE, verbose = FALSE
    ),
    warning = function(condition) {
      fit_warnings <<- c(fit_warnings, class(condition)[[1L]])
      invokeRestart("muffleWarning")
    }
  )
  gbm_health <- validate_gbm_fit_health(
    fit, length(fit_warnings), trees, colnames(design), nrow(design)
  )
  risk <- exp(as.numeric(predict(fit, design, n.trees = trees, type = "link")))
  need(all(is.finite(risk)) && all(risk > 0), "F5_GBM_RISK_INVALID")
  baseline <- breslow(time, event, risk)
  need(
    all(is.finite(baseline$times)) && all(is.finite(baseline$cumulative)),
    "F5_GBM_BASELINE_INVALID"
  )
  survival <- survival_from_risk(baseline, risk)
  write_objects(
    list(fit = fit, selected_parents = selected, design_columns = colnames(design)),
    list(engine = "gbm::gbm", baseline = baseline)
  )
  health <- c(
    health,
    list(
      engine = "gbm::gbm", selected_trees = trees,
      training_only_stop_count = 0L, stopping_reselected = FALSE
    ),
    gbm_health
  )
} else {
  suppressPackageStartupMessages(library(rstpm2))
  fpm_constraint_identity()
  if (!a12) need(
    "AST_ALT" %in% colnames(design) &&
      all(is.finite(design[, "AST_ALT"])) &&
      all(design[, "AST_ALT"] > 0 & design[, "AST_ALT"] <= 15),
    "F5_FPM_FIXED_COMPUTATIONAL_DOMAIN_INVALID"
  )
  frame <- data.frame(.time = time, .event = event, design, check.names = FALSE)
  formula <- as.formula(paste(
    "Surv(.time,.event) ~", paste(sprintf("`%s`", colnames(design)), collapse = "+")
  ))
  fit <- withCallingHandlers(
    if (a12) padml_a12_stpm2(formula, frame) else stpm2(
      formula, data = frame, df = 3L, tvc = list(AST_ALT = 1L),
      padml.fpm.domain = c(0, 15)
    ),
    warning = function(condition) {
      stop("F5_FPM_FIT_WARNING: ", conditionMessage(condition), call. = FALSE)
    }
  )
  fpm_health <- validate_fpm_fit_health(fit, 0L, if (a12) 3L else c(3L, 1L))
  survival <- padml_predict_final_fpm_survival(fit, design, horizons, a12=a12)
  non_ph_reference_design <- if (a12) NULL else colMeans(design)
  if (!a12) non_ph_reference_design["AST_ALT"] <- 1
  non_ph_support_by_center <- if (a12) NULL else lapply(
    sort(unique(as.character(covariates$Center))),
    function(center) {
      center_values <- as.numeric(
        design[as.character(covariates$Center) == center, "AST_ALT"]
      )
      list(
        center = center,
        patient_count = length(center_values),
        minimum_ast_alt = min(center_values),
        maximum_ast_alt = max(center_values)
      )
    }
  )
  write_objects(
    list(
      fit = fit, selected_parents = selected,
      design_columns = colnames(design),
      non_ph_reference_design = unname(non_ph_reference_design),
      non_ph_support_by_center = non_ph_support_by_center,
      training_event_count = as.integer(sum(event))
    ),
    list(engine = "rstpm2::stpm2", baseline_embedded_in_model = TRUE,
         coefficients = as.list(as.numeric(coef(fit))))
  )
  health <- c(
    health,
    list(engine = "rstpm2::stpm2", df = 3L, tvc_df = if (a12) 0L else 1L),
    fpm_health
  )
}

need(
  identical(dim(survival), c(nrow(covariates), length(horizons))) &&
    all(is.finite(survival)) && all(survival >= 0 & survival <= 1) &&
    all(survival[, 1L] == 1) &&
    all(apply(survival, 1L, function(row) all(diff(row) <= 1e-10))),
  "F5_R_PREDICTION_INVALID"
)
result <- list(
  schema_version = "1.0.0",
  kind = "PADML_F5_FINAL_REFIT_R_RESULT_V1",
  status = "PASS",
  family = family,
  patient_ids = as.list(as.character(covariates$Patient_ID)),
  horizons = as.list(as.integer(horizons)),
  survival = lapply(seq_len(nrow(survival)), function(index) {
    as.list(as.numeric(survival[index, ]))
  }),
  fit_health = health
)
writeLines(
  toJSON(result, auto_unbox = TRUE, null = "null", na = "null", digits = I(17)),
  as.character(scalar(spec$output_path)), useBytes = TRUE
)
