#!/usr/bin/env Rscript

# Private M5 cardinality adapter; all transform arithmetic stays in F2.
suppressPackageStartupMessages({library(jsonlite); library(digest)})
fail <- function(code) stop(code, call. = FALSE)
need <- function(value, code) if (!isTRUE(value)) fail(code)
scalar <- function(value) unname(unlist(value, use.names = FALSE)[[1L]])

learning_curve_recipe_m5 <- function(original) {
  changed <- integer(2L)
  project <- function(expression) {
    before <- list(quote(length(record$members) == 20L), quote(seq_len(20L)))
    after <- list(quote(length(record$members) == 5L), quote(seq_len(5L)))
    for (index in seq_along(before)) {
      if (identical(expression, before[[index]])) {
        changed[[index]] <<- changed[[index]] + 1L
        return(after[[index]])
      }
    }
    if (is.call(expression)) for (index in seq_along(expression)) {
      if (!is.null(expression[[index]]) && !identical(expression[[index]], quote(expr = )))
        expression[[index]] <- project(expression[[index]])
    }
    expression
  }
  body(original) <- project(body(original))
  need(identical(changed, c(1L, 2L)), "F4_LEARNING_RECIPE_SOURCE_INVALID")
  original
}

args <- commandArgs(trailingOnly = TRUE)
need(length(args) == 1L, "F4_LEARNING_RECIPE_ARGUMENT_INVALID")
spec <- fromJSON(args[[1L]], simplifyVector = FALSE)
need(identical(sort(names(spec)), c("output_path", "projection")), "F4_LEARNING_RECIPE_INPUT_INVALID")
options(error = function() {
  dump.frames(dumpto = file.path(dirname(as.character(scalar(spec$output_path))), "native-failure"),
              to.file = TRUE, include.GlobalEnv = TRUE)
  quit(save = "no", status = 1L, runLast = FALSE)
})
script <- grep("^--file=", commandArgs(), value = TRUE)
need(length(script) == 1L, "F4_LEARNING_RECIPE_KERNEL_PATH_INVALID")
kernel <- file.path(dirname(gsub("~+~", " ", sub("^--file=", "", script), fixed = TRUE)), "f2_model_development.R")
required <- c("canonical_json", "sha_object", "recipe_forbidden_key", "fit_design_recipe")
definitions <- Filter(function(x) {
  is.call(x) && identical(x[[1L]], as.name("<-")) && is.symbol(x[[2L]]) &&
    as.character(x[[2L]]) %in% required && is.call(x[[3L]]) &&
    identical(x[[3L]][[1L]], as.name("function"))
}, as.list(parse(kernel)))
need(length(definitions) == length(required) &&
       setequal(vapply(definitions, function(x) as.character(x[[2L]]), character(1)), required),
     "F4_LEARNING_RECIPE_SOURCE_INVALID")
for (definition in definitions) eval(definition)
rng <- get0(".Random.seed", envir = .GlobalEnv, inherits = FALSE)
value <- learning_curve_recipe_m5(fit_design_recipe)(spec$projection)
need(identical(rng, get0(".Random.seed", envir = .GlobalEnv, inherits = FALSE)),
     "F4_LEARNING_RECIPE_RNG_CONSUMED")
writeLines(canonical_json(value, always_decimal = TRUE, digits = I(17)),
           as.character(scalar(spec$output_path)), useBytes = TRUE)
