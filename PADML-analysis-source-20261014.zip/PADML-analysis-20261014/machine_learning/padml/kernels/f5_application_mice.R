#!/usr/bin/env Rscript

# Outcome-free application adapter. The original MICE calls and RNG consumption
# are unchanged; actual donor/estimation masks are retained inside each mids.
script <- grep("^--file=", commandArgs(), value = TRUE)
stopifnot(length(script) == 1L)
bridge <- parse(file.path(dirname(gsub("~+~", " ", sub("^--file=", "", script), fixed = TRUE)), "f5_mice.R"))
entry <- which(vapply(as.list(bridge), function(x) identical(x, quote(impute_view(spec, authority))), logical(1)))
stopifnot(length(entry) == 1L, entry[[1L]] == length(bridge) - 1L)
for (expression in as.list(bridge)[seq_len(entry[[1L]] - 1L)]) eval(expression)
validation <- spec$application_validation
spec$application_validation <- NULL
if (!is.null(validation) && !identical(validation, TRUE)) fail("F5_APPLICATION_PROFILE_INVALID")
application_m <- if (isTRUE(validation)) 2L else 20L
if (!identical(spec$view$role, "APPLICATION") || !is.null(spec$response_path) ||
    !is.null(chain_rng_substream) || as.integer(spec$view$outer_fold) != 0L ||
    !identical(ints(spec$chain_seeds), 150000000L + seq_len(application_m)) ||
    !identical(chars(spec$view$row_ids)[seq_along(chars(spec$view$analysis_ids))], chars(spec$view$analysis_ids)) ||
    length(chars(spec$view$row_ids)) <= length(chars(spec$view$analysis_ids))) {
  fail("F5_APPLICATION_VIEW_INVALID")
}

application_functions <- c("initialize.imp", "mice.impute.sample", "sampler.univ",
                          "mice.impute.pmm", ".norm.draw", "quantify", "estimice", "remove.lindep")
original_functions <- setNames(lapply(application_functions, function(name) get(name, asNamespace("mice"))), application_functions)
application_sources <- lapply(original_functions, function(fn) list(formals = formals(fn), body = body(fn)))
padml_application <- new.env(parent = emptyenv())

application_project <- function(fn, replacements, expected) {
  counts <- integer(length(replacements))
  walk <- function(x) {
    for (i in seq_along(replacements)) if (identical(x, replacements[[i]][[1L]])) {
      counts[[i]] <<- counts[[i]] + 1L
      return(replacements[[i]][[2L]])
    }
    if (is.call(x)) for (i in seq_along(x)) {
      if (!is.null(x[[i]]) && !identical(x[[i]], quote(expr = ))) x[[i]] <- walk(x[[i]])
    }
    x
  }
  body(fn) <- walk(body(fn))
  if (!identical(counts, as.integer(expected))) fail("F5_APPLICATION_MICE_IMPLEMENTATION_UNSUPPORTED")
  fn
}

application_mask <- function(x) {
  if (!is.logical(x) || anyNA(x)) fail("F5_APPLICATION_MASK_INVALID")
  packBits(c(as.integer(x), rep.int(0L, (-length(x)) %% 8L)), type = "raw")
}
application_unmask <- function(x, n) {
  if (!is.raw(x) || length(x) != ceiling(n / 8)) fail("F5_APPLICATION_MASK_INVALID")
  value <- as.logical(rawToBits(x))[seq_len(n)]
  if (!identical(application_mask(value), x)) fail("F5_APPLICATION_MASK_INVALID")
  value
}
application_initial <- function(y, ry, wy, value) {
  if (!any(ry) || any(ry & padml_application$ignore)) fail("F5_APPLICATION_INITIAL_DONOR_INVALID")
  padml_application$initial[[length(padml_application$initial) + 1L]] <- list(
    target = padml_application$initial_target, ry = application_mask(ry),
    wy = application_mask(wy), value = value)
}
application_begin <- function(target, iteration, ry, wy) {
  if (any(ry & padml_application$ignore)) fail("F5_APPLICATION_ESTIMATION_ROW_INVALID")
  padml_application$current <- list(target = target, iteration = as.integer(iteration),
                                    sampler_ry = application_mask(ry), sampler_wy = application_mask(wy))
}
application_estimation <- function(ry, rows, quantified = FALSE) {
  if (length(rows) != length(ry) || anyDuplicated(rows) || anyNA(rows) ||
      any(rows < 1L | rows > length(padml_application$ignore)) ||
      !any(ry) || any(padml_application$ignore[rows[ry]])) fail("F5_APPLICATION_ESTIMATION_ROW_INVALID")
  field <- if (quantified) "quantify_rows" else "estimation_rows"
  padml_application$current[[field]] <- rows[ry]
}
application_match <- function(y, ry, wy, rows, idx, value) {
  if (!identical(rows, seq_along(padml_application$ignore)) ||
      any(padml_application$ignore[rows[ry]]) || length(idx) != sum(wy) ||
      anyNA(idx) || any(idx != as.integer(idx) | idx < 1L | idx > sum(ry)) ||
      !identical(value, y[ry][idx])) fail("F5_APPLICATION_DONOR_MATCH_INVALID")
  padml_application$calls[[length(padml_application$calls) + 1L]] <- c(
    padml_application$current, list(source_rows = rows, ry = application_mask(ry),
                                   wy = application_mask(wy), donor_indices = as.integer(idx), value = value))
}

# Add statements in place, not wrapper stack frames around MICE's numerical
# functions. In particular updateLog()/state parent-frame semantics stay intact.
patched <- original_functions
patched$initialize.imp <- application_project(patched$initialize.imp, list(list(
  quote(imp[[j]][, i] <- mice.impute.sample(y, ry, wy = wy)),
  quote({padml_application$initial_target <- j; imp[[j]][, i] <- mice.impute.sample(y, ry, wy = wy)})
)), 1L)
patched$mice.impute.sample <- application_project(patched$mice.impute.sample, list(
  list(quote(yry <- y[ry]), quote(yry <- y[ry])),
  list(quote(sample(yry, size = sum(wy), replace = TRUE)), quote(sample(yry, size = sum(wy), replace = TRUE)))
), c(1L, 1L))
sample_body <- body(patched$mice.impute.sample)
body(patched$mice.impute.sample) <- as.call(c(list(as.name("{")), list(quote(
  on.exit(application_initial(y, ry, wy, returnValue()), add = TRUE))), as.list(sample_body)[-1L]))
patched$sampler.univ <- application_project(patched$sampler.univ, list(list(
  quote(ry <- complete.cases(x, y) & r[, j] & !ignore),
  quote(ry <- complete.cases(x, y) & r[, j] & !ignore)
), list(quote(imputes[cc] <- do.call(f, args = args)), quote({
  application_begin(j, k, ry, wy)
  imputes[cc] <- do.call(f, args = args)
}))), c(1L, 1L))
patched$mice.impute.pmm <- application_project(patched$mice.impute.pmm, list(
  list(quote(if (is.null(wy)) {wy <- !ry}), quote({
    if (is.null(wy)) wy <- !ry
    if (!identical(as.integer(trim), 1L) || !is.null(exclude)) fail("F5_APPLICATION_PMM_CONFIGURATION_INVALID")
    padml_rows <- seq_along(y)
  })),
  list(quote(y <- y[active]), quote({y <- y[active]; padml_rows <- padml_rows[active]})),
  list(quote(x <- cbind(1, as.matrix(x))), quote({
    padml_application$rows <- padml_rows
    x <- cbind(1, as.matrix(x))
  })),
  list(quote(parm <- .norm.draw(ynum, ry, x, ridge = ridge, ...)), quote({
    parm <- .norm.draw(ynum, ry, x, ridge = ridge, ...)
  })),
  list(quote(return(y[ry][idx])), quote({
    application_match(y, ry, wy, padml_rows, idx, y[ry][idx])
    return(y[ry][idx])
  }))
), c(1L, 2L, 1L, 1L, 1L))
patched[[".norm.draw"]] <- application_project(patched[[".norm.draw"]], list(list(
  quote(p <- estimice(x[ry, , drop = FALSE], y[ry], ...)), quote({
    application_estimation(ry, padml_application$rows)
    p <- estimice(x[ry, , drop = FALSE], y[ry], ...)
  })
)), 1L)
patched$quantify <- application_project(patched$quantify, list(list(
  quote(yf <- factor(y[ry], exclude = NULL)), quote({
    application_estimation(ry, padml_application$rows, quantified = TRUE)
    yf <- factor(y[ry], exclude = NULL)
  })
), list(quote(xd <- x[ry, , drop = FALSE]), quote(xd <- x[ry, , drop = FALSE]))), c(1L, 1L))

# Names are resolved in the original namespace without introducing a numerical
# wrapper frame. Only this short-lived application R process is modified.
capture_environment <- new.env(parent = asNamespace("mice"))
for (name in c("padml_application", "application_initial", "application_begin",
               "application_estimation", "application_match", "fail")) {
  assign(name, get(name, envir = .GlobalEnv), envir = capture_environment)
}
if (identical(action, "FIT")) for (name in setdiff(application_functions, c("estimice", "remove.lindep"))) {
  environment(patched[[name]]) <- capture_environment
  assignInNamespace(name, patched[[name]], ns = "mice")
}

validate_application_trace <- function(fit, trace, inputs) {
  n <- nrow(inputs$mice_data)
  if (!is.list(trace) || !identical(trace$sources, application_sources) ||
      !identical(trace$row_ids, chars(spec$view$row_ids)) ||
      !identical(trace$ignore, inputs$ignore) || !identical(fit$where, is.na(inputs$mice_data)) ||
      !is.list(trace$initial) || !is.list(trace$calls)) {
    fail("F5_APPLICATION_TRACE_BINDING_INVALID")
  }
  if (inherits(fit, "padml_complete_data_view")) {
    if (!isTRUE(inputs$passthrough) || any(fit$method != "") || fit$iteration != 0L ||
        length(trace$initial) || length(trace$calls) || !is.null(fit$lastSeedValue)) {
      fail("F5_APPLICATION_COMPLETE_DATA_TRACE_INVALID")
    }
    return(invisible(TRUE))
  }
  active <- fit$visitSequence[fit$method[fit$visitSequence] == "pmm"]
  initial_targets <- vapply(trace$initial, function(x) x$target, character(1))
  if (!setequal(initial_targets, active) || anyDuplicated(initial_targets)) fail("F5_APPLICATION_INITIAL_COVERAGE_INVALID")
  for (item in trace$initial) {
    y <- fit$data[[item$target]]
    ry <- application_unmask(item$ry, n); wy <- application_unmask(item$wy, n)
    if (!identical(ry, !is.na(y) & !inputs$ignore) || !identical(wy, is.na(y)) ||
        !any(ry) || length(item$value) != sum(wy) || anyNA(item$value) ||
        !all(item$value %in% y[ry])) fail("F5_APPLICATION_INITIAL_DONOR_INVALID")
  }
  expected <- unlist(lapply(seq_len(fit$iteration), function(k) paste(k, active, sep = "/")), use.names = FALSE)
  observed <- vapply(trace$calls, function(x) paste(x$iteration, x$target, sep = "/"), character(1))
  if (!identical(observed, expected)) fail("F5_APPLICATION_PMM_COVERAGE_INVALID")
  for (item in trace$calls) {
    y <- fit$data[[item$target]]
    ry <- application_unmask(item$ry, n); wy <- application_unmask(item$wy, n)
    if (!identical(item$source_rows, seq_len(n)) ||
        !identical(item$sampler_ry, item$ry) || !identical(item$sampler_wy, item$wy) ||
        any(ry & (inputs$ignore | is.na(y))) || any(wy & !is.na(y)) || !any(ry) ||
        !identical(item$estimation_rows, which(ry)) ||
        (is.factor(y) && !identical(item$quantify_rows, which(ry))) ||
        (!is.factor(y) && !is.null(item$quantify_rows)) ||
        !is.integer(item$donor_indices) || anyNA(item$donor_indices) ||
        length(item$donor_indices) != sum(wy) || any(item$donor_indices < 1L | item$donor_indices > sum(ry)) ||
        !identical(item$value, y[ry][item$donor_indices])) fail("F5_APPLICATION_DONOR_MATCH_INVALID")
    if (item$iteration == fit$iteration) {
      stored <- fit$imp[[item$target]]
      positions <- match(which(wy), which(is.na(y)))
      if (!is.data.frame(stored) || ncol(stored) != 1L || nrow(stored) != sum(is.na(y)) ||
          !identical(row.names(stored), row.names(fit$data)[is.na(y)]) || anyNA(positions) ||
          !identical(unname(stored[positions, 1L]), unname(item$value)) ||
          any(!is.na(stored[setdiff(seq_len(nrow(stored)), positions), 1L]))) {
        fail("F5_APPLICATION_TERMINAL_IMPUTATION_MISMATCH")
      }
    }
  }
  invisible(TRUE)
}

application_chains <- function(chain_seeds, FUN) {
  inputs <- environment(FUN)
  native_chains(chain_seeds, FUN, fit_chain = function(seed, prior = NULL) {
    padml_application$ignore <- inputs$ignore
    trace <- if (is.null(prior)) NULL else attr(prior, "padml_application")
    padml_application$initial <- if (is.null(trace)) list() else trace$initial
    padml_application$calls <- if (is.null(trace)) list() else trace$calls
    fit <- FUN(seed, prior)
    attr(fit, "padml_application") <- list(
      row_ids = chars(spec$view$row_ids), ignore = inputs$ignore,
      sources = application_sources, initial = padml_application$initial,
      calls = padml_application$calls)
    fit
  }, validate_fit = function(fit, inputs) {
    validate_application_trace(fit, attr(fit, "padml_application"), inputs)
  })
}
formals(impute_view)$chain_apply <- quote(application_chains)
# Only the seed count, output loop and summary count are M20 literals.
if (application_m == 2L) impute_view <- application_project(impute_view, list(list(20L, 2L)), 3L)
impute_view(spec, authority)
writeLines(capture.output(sessionInfo()), file.path(root, "native-session.txt"))
