suppressPackageStartupMessages(library(jsonlite))

request <- fromJSON(file("stdin"), simplifyVector = TRUE)
args <- commandArgs(trailingOnly = TRUE)
validation <- identical(args, "--validation-b1")
stopifnot(validation || length(args) == 0L)
replicates <- if (validation) 1L else 200L
stopifnot(
  identical(names(request), c(
    "center_order", "centers", "patient_ids", "replicate_seeds"
  )),
  length(request$patient_ids) == length(request$centers),
  length(unique(request$patient_ids)) == length(request$patient_ids),
  identical(sort(unique(request$centers)), sort(request$center_order)),
  length(request$replicate_seeds) == replicates,
  identical(
    as.integer(request$replicate_seeds),
    as.integer(720000000L + seq_len(replicates))
  )
)

source <- unlist(lapply(request$center_order, function(center) {
  index <- which(request$centers == center)
  index[order(request$patient_ids[index], method = "radix")]
}), use.names = FALSE)
stopifnot(length(source) == length(request$patient_ids))

draws <- lapply(seq_along(request$replicate_seeds), function(replicate) {
  set.seed(
    as.integer(request$replicate_seeds[[replicate]]),
    kind = "L'Ecuyer-CMRG",
    normal.kind = "Inversion",
    sample.kind = "Rejection"
  )
  sampled <- unlist(lapply(request$center_order, function(center) {
    index <- source[request$centers[source] == center]
    sample(index, length(index), replace = TRUE)
  }), use.names = FALSE)
  as.list(as.integer(sampled - 1L))
})

cat(toJSON(list(
  draws = draws,
  replicate_seeds = as.list(as.integer(request$replicate_seeds)),
  r_version = paste(R.version$major, R.version$minor, sep = "."),
  rng = c("L'Ecuyer-CMRG", "Inversion", "Rejection")
), auto_unbox = TRUE, digits = NA, null = "null"))
