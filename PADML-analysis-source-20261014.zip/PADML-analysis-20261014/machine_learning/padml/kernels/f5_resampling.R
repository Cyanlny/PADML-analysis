#!/usr/bin/env Rscript
suppressPackageStartupMessages(library(jsonlite))
input <- fromJSON(file("stdin"), simplifyVector = TRUE)
ids <- input$patient_ids
if (!length(ids) || anyDuplicated(ids) ||
    !all(grepl("^[0-9a-f]{64}$", ids)) ||
    length(input$centers) != length(ids) || length(input$events) != length(ids) ||
    anyNA(input$centers) || !all(input$events %in% c(0L, 1L))) {
  stop("F5_RESAMPLING_INPUT_INVALID", call. = FALSE)
}
index <- order(ids, method = "radix")
ids <- ids[index]
centers <- input$centers[index]
events <- input$events[index]
# Preserve the approved interaction level order: center varies within event.
strata <- interaction(as.character(centers), as.character(events), drop = TRUE)
repeats <- lapply(seq_len(3L), function(repeat_id) {
  seed <- 100000L + repeat_id * 100L
  set.seed(seed, kind = "L'Ecuyer-CMRG", normal.kind = "Inversion",
    sample.kind = "Rejection")
  fold <- integer(length(ids))
  for (level in levels(strata)) {
    members <- which(strata == level)
    # sample(members, 1) samples 1:members when members is a lone integer.
    # Sampling positions preserves the required permutation for every size.
    shuffled <- members[sample.int(length(members), length(members), replace = FALSE)]
    fold[shuffled] <- rep(seq_len(5L), length.out = length(shuffled))
  }
  if (any(fold < 1L | fold > 5L) || !identical(sort(unique(fold)), seq_len(5L))) {
    stop("F5_RESAMPLING_FIVE_FOLDS_INCOMPLETE", call. = FALSE)
  }
  list(repeat_id = repeat_id, seed = seed, fold = as.list(fold))
})
cat(toJSON(list(patient_ids = as.list(ids), repeats = repeats,
  r_version = as.character(getRversion())), auto_unbox = TRUE, digits = NA))
