#!/usr/bin/env Rscript

# Private learning-curve adapter: retain/replay the current F1 chains, with
# exactly five imputations. This is not a new public stage or controller.
script <- grep("^--file=", commandArgs(), value = TRUE)
stopifnot(length(script) == 1L)
bridge <- parse(file.path(dirname(gsub("~+~", " ", sub("^--file=", "", script), fixed = TRUE)), "f5_mice.R"))
entry <- which(vapply(as.list(bridge), function(x) {
  identical(x, quote(impute_view(spec, authority)))
}, logical(1)))
stopifnot(length(entry) == 1L, entry[[1L]] == length(bridge) - 1L)
for (expression in as.list(bridge)[seq_len(entry[[1L]] - 1L)]) eval(expression)

learning_curve_m5 <- function(original) {
  changed <- integer(3L)
  project <- function(expression) {
    before <- list(quote(length(chain_seeds) != 20L), quote(seq_len(20L)))
    after <- list(quote(length(chain_seeds) != 5L), quote(seq_len(5L)))
    for (index in seq_along(before)) {
      if (identical(expression, before[[index]])) {
        changed[[index]] <<- changed[[index]] + 1L
        return(after[[index]])
      }
    }
    if (is.call(expression)) {
      if (identical(expression[[1L]], as.name("list")) &&
          all(c("kind", "formal_m") %in% names(expression)) &&
          identical(expression[["kind"]], "PADML_F1_MICE_VIEW_SUMMARY") &&
          identical(expression[["formal_m"]], 20L)) {
        expression[["formal_m"]] <- 5L
        changed[[3L]] <<- changed[[3L]] + 1L
      }
      for (index in seq_along(expression)) {
        if (!is.null(expression[[index]]) &&
            !identical(expression[[index]], quote(expr = ))) {
          expression[[index]] <- project(expression[[index]])
        }
      }
    }
    expression
  }
  body(original) <- project(body(original))
  if (!identical(changed, rep(1L, 3L))) fail("F4_LEARNING_MICE_SOURCE_INVALID")
  original
}
impute_view <- learning_curve_m5(impute_view)
impute_view(spec, authority)
writeLines(capture.output(sessionInfo()), file.path(root, "native-session.txt"))
