#!/usr/bin/env Rscript

suppressPackageStartupMessages(library(jsonlite))
args <- commandArgs(trailingOnly = TRUE)
stopifnot(length(args) == 1L)
spec <- fromJSON(args[[1L]], simplifyVector = FALSE)
stopifnot(setequal(names(spec), c("covariates_path", "variable_path", "authority_path", "requests", "output_path")))
options(error = function() {
  dump.frames(file.path(dirname(as.character(spec$output_path)), "native-failure"),
              to.file = TRUE, include.GlobalEnv = TRUE)
  quit(save = "no", status = 1L, runLast = FALSE)
})
script <- grep("^--file=", commandArgs(), value = TRUE)
stopifnot(length(script) == 1L)
kernel <- file.path(dirname(gsub("~+~", " ", sub("^--file=", "", script), fixed = TRUE)), "f1_nested_mice.R")
# Reuse the F1 parser only. No outcome reader, MICE, model, or RNG entry point.
required <- c("fail", "chars", "numeric_strict", "parse_levels", "cast_covariates", "formula_values", "formula_prefill")
definitions <- Filter(function(x) {
  is.call(x) && identical(x[[1L]], as.name("<-")) && is.symbol(x[[2L]]) &&
    as.character(x[[2L]]) %in% required && is.call(x[[3L]]) &&
    identical(x[[3L]][[1L]], as.name("function"))
}, as.list(parse(kernel)))
stopifnot(length(definitions) == length(required),
          setequal(vapply(definitions, function(x) as.character(x[[2L]]), character(1)), required))
for (definition in definitions) eval(definition)
data <- read.csv(as.character(spec$covariates_path), check.names = FALSE,
                 stringsAsFactors = FALSE, colClasses = "character",
                 na.strings = character(), fileEncoding = "UTF-8")
stopifnot(!any(c("All_Cause_Death", "Death_Followup_months") %in% names(data)))
data <- cast_covariates(data, as.character(spec$variable_path))
data <- formula_prefill(data, fromJSON(as.character(spec$authority_path), simplifyVector = FALSE))
result <- lapply(spec$requests, function(request) {
  center <- as.character(request$center)
  selected <- as.character(unlist(request$selected_parents, use.names = FALSE))
  stopifnot(length(selected) > 0L, all(selected %in% names(data)))
  # These are the same three passive outputs recomputed by F1 complete().
  # An empty passive output with observed sources needs no MICE imputation.
  sources <- list(BMI = c("Weight_kg", "Height_cm"), AST_ALT = c("AST", "ALT"),
                  eGFR_calc = c("Creatinine", "Age", "Sex"))
  fields <- unique(unlist(lapply(selected, function(name) {
    if (name %in% names(sources)) sources[[name]] else name
  }), use.names = FALSE))
  stopifnot(all(fields %in% names(data)))
  index <- as.character(data$Center) == center
  stopifnot(!anyNA(index), any(index))
  list(center = center, patient_ids = as.list(as.character(data$Patient_ID[index])),
       raw_fields = as.list(fields),
       missing_sources = lapply(which(index), function(row) as.list(fields[is.na(data[row, fields])])) )
})
write_json(result, as.character(spec$output_path), auto_unbox = TRUE,
           null = "null", na = "null")
