from __future__ import annotations

from .carriers import open_carrier

import hashlib
import io
import json
import math
import os
import secrets
import shutil
import stat
import tempfile
import zlib
import zipfile
import time
from collections import OrderedDict
from threading import Lock
from pathlib import Path, PurePosixPath
from typing import Any, Callable, Mapping


class ContractError(ValueError):
    """A trust-boundary object is not canonical or admissible."""


UNIT_EXACT_KEY_FIELDS = {
    "source_identity",
    "authority_identity",
    "input_identity",
    "runtime_capability_identity",
    "stage_id",
    "unit_id",
    "transaction_id",
    "plan_identity",
    "seed",
    "request_sha256",
}
ENVELOPE_KEYS = {
    "schema_version",
    "kind",
    "run_id",
    "stage_id",
    "unit_id",
    "transaction_id",
    "identities",
    "seed",
    "plan",
    "artifacts",
    "terminal",
    "decision",
}
BASE_IDENTITY_KEYS = {"source", "authority", "runtime", "input", "plan"}
WORKER_BOUND_STAGE_IDS = {"F2", "F3", "F4", "F5", "F6"}
FRESH_F1_WORKER_ACTIONS = {
    "F1_DATA_BINDING_V2",
    "F1_MICE_AGGREGATE_V2",
    "F1_NESTED_MICE_FOLD_V2",
}
FRESH_F2_WORKER_ACTIONS = {
    "MODEL_CONFIRMATION_AGGREGATE",
    "MODEL_DEVELOPMENT",
    "P2C2T",
}
PLAN_KEYS = {"action", "role", "coordinates", "depends_on", "internal_threads"}
COORDINATE_KEYS = {"axis", "value"}
ARTIFACT_KEYS = {
    "artifact_id",
    "relative_path",
    "classification",
    "size_bytes",
    "sha256",
    "status",
}
TERMINAL_KEYS = {"status", "reason_code", "message_sha256"}
DECISION_KEYS = {"outcome", "reviewer", "note", "note_sha256", "package_sha256"}
STAGE_IDS = {f"F{index}" for index in range(7)}
CLASSIFICATIONS = {"CONTROL", "PRIVATE_SCIENCE", "PUBLIC_AGGREGATE", "DIAGNOSTIC"}
SCIENCE_PROJECTION_EXCLUDED_KEYS = {
    "admission_identity",
    "execution_identity_sha256",
    "execution_mode",
    "primary_execution",
    "threads",
    "pool_workers",
    "engine_threads",
    "selector_execution_identity_sha256",
    "telemetry",
}


def execution_contract(plan: Mapping[str, Any]) -> dict[str, Any]:
    coordinates = plan.get("coordinates")
    threads = plan.get("internal_threads")
    modes = [
        row.get("value")
        for row in coordinates or []
        if isinstance(row, Mapping) and row.get("axis") == "execution_mode"
    ]
    if (
        len(modes) != 1
        or isinstance(threads, bool)
        or not isinstance(threads, int)
        or (modes[0] == "SERIAL" and threads != 1)
        # Historical receipts describe their own host; capacity is enforced
        # only by the runtime about to spawn, never by a local archive reader.
        or (modes[0] == "PROCESS_POOL" and threads < 1)
        or modes[0] not in {"SERIAL", "PROCESS_POOL"}
    ):
        raise ContractError("EXECUTION_MODE_THREADS_INVALID")
    return {
        "execution_mode": modes[0],
        "threads": threads,
        "pool_workers": threads if modes[0] == "PROCESS_POOL" else 1,
        "engine_threads": 1,
    }


def execution_result_contract(plan: Mapping[str, Any]) -> dict[str, int]:
    """Return the only execution fields echoed by a scientific result."""

    contract = execution_contract(plan)
    return {
        key: contract[key]
        for key in ("threads", "pool_workers", "engine_threads")
    }


def _reject_nonfinite(value: Any) -> None:
    if isinstance(value, float) and not math.isfinite(value):
        raise ContractError("NONFINITE_JSON_NUMBER")
    if isinstance(value, dict):
        for key, item in value.items():
            if not isinstance(key, str):
                raise ContractError("JSON_OBJECT_KEY_NOT_STRING")
            _reject_nonfinite(item)
    elif isinstance(value, list):
        for item in value:
            _reject_nonfinite(item)


def canonical_json_bytes(value: Any) -> bytes:
    _reject_nonfinite(value)
    return json.dumps(
        value,
        ensure_ascii=False,
        allow_nan=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8") + b"\n"


def science_projection_sha256(value: Any) -> str:
    """Hash validated science bytes after removing only frozen execution fields."""

    def project(item: Any) -> Any:
        if isinstance(item, dict):
            return {
                key: project(child)
                for key, child in item.items()
                if key not in SCIENCE_PROJECTION_EXCLUDED_KEYS
            }
        if isinstance(item, list):
            return [project(child) for child in item]
        return item

    return sha256_bytes(canonical_json_bytes(project(value)))


def strict_json_bytes(data: bytes, label: str = "JSON") -> Any:
    def unique_pairs(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
        result: dict[str, Any] = {}
        for key, value in pairs:
            if key in result:
                raise ContractError(f"DUPLICATE_JSON_KEY:{label}:{key}")
            result[key] = value
        return result

    try:
        value = json.loads(
            data.decode("utf-8", errors="strict"),
            object_pairs_hook=unique_pairs,
            parse_constant=lambda token: (_ for _ in ()).throw(
                ContractError(f"INVALID_JSON_CONSTANT:{label}:{token}")
            ),
        )
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ContractError(f"INVALID_JSON:{label}") from exc
    _reject_nonfinite(value)
    return value


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


_FILE_DIGESTS = OrderedDict()
_FILE_DIGESTS_LOCK = Lock()


def _remember_qualified_digest(path, digest, stamp):
    # Called only after an existing persistent qualification matches all five
    # filesystem fields. This carries that byte fact to other native readers.
    if time.time_ns() - max(stamp[-2:]) > 2_000_000_000:
        with _FILE_DIGESTS_LOCK:
            _FILE_DIGESTS[(str(path), tuple(stamp))] = digest
            while len(_FILE_DIGESTS) > 8192:
                _FILE_DIGESTS.popitem(last=False)


def sha256_file(path: Path, chunk_size: int = 1024 * 1024) -> str:
    # Byte qualification only. Scientific consumers still validate numbers on
    # first use. Recent writes stay uncached on coarse-timestamp filesystems.
    def stamp(value):
        return (value.st_dev, value.st_ino, value.st_size, value.st_mtime_ns, value.st_ctime_ns)
    before = stamp(path.stat())
    key = (str(path.resolve()), before)
    with _FILE_DIGESTS_LOCK:
        if key in _FILE_DIGESTS:
            _FILE_DIGESTS.move_to_end(key)
            return _FILE_DIGESTS[key]
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        if stamp(os.fstat(handle.fileno())) != before:
            raise ContractError("HASH_SOURCE_CHANGED")
        while chunk := handle.read(chunk_size):
            digest.update(chunk)
        if stamp(os.fstat(handle.fileno())) != before or stamp(path.stat()) != before:
            raise ContractError("HASH_SOURCE_CHANGED")
    result = digest.hexdigest()
    _remember_qualified_digest(path.resolve(), result, before)
    return result


def validate_sha256(value: Any, field: str) -> str:
    if not isinstance(value, str) or len(value) != 64 or value.lower() != value:
        raise ContractError(f"INVALID_SHA256:{field}")
    try:
        int(value, 16)
    except ValueError as exc:
        raise ContractError(f"INVALID_SHA256:{field}") from exc
    return value


def validate_relative_path(value: Any, field: str = "relative_path") -> str:
    if not isinstance(value, str) or not value or "\\" in value:
        raise ContractError(f"INVALID_RELATIVE_PATH:{field}")
    path = PurePosixPath(value)
    if (
        path.is_absolute()
        or value != path.as_posix()
        or any(part in {"", ".", ".."} for part in path.parts)
    ):
        raise ContractError(f"UNSAFE_RELATIVE_PATH:{field}")
    return value


def _exact(value: Any, expected: set[str], label: str) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise ContractError(f"{label}_NOT_OBJECT")
    missing = sorted(expected - set(value))
    extra = sorted(set(value) - expected)
    if missing or extra:
        raise ContractError(
            f"{label}_KEY_SET_INVALID:missing={missing}:extra={extra}"
        )
    return value


def _nonempty(value: Any, field: str) -> str:
    if not isinstance(value, str) or not value:
        raise ContractError(f"INVALID_NONEMPTY_STRING:{field}")
    return value


def _validate_coordinate(value: Any, index: int) -> dict[str, Any]:
    row = _exact(value, COORDINATE_KEYS, f"COORDINATE_{index}")
    _nonempty(row["axis"], f"coordinates[{index}].axis")
    coordinate = row["value"]
    scalar = isinstance(coordinate, str) or (
        isinstance(coordinate, int) and not isinstance(coordinate, bool)
    )
    integer_list = (
        isinstance(coordinate, list)
        and bool(coordinate)
        and all(isinstance(item, int) and not isinstance(item, bool) for item in coordinate)
        and len(set(coordinate)) == len(coordinate)
    )
    if not (scalar or integer_list):
        raise ContractError(f"COORDINATE_VALUE_INVALID:{index}")
    return row


def _validate_artifact(value: Any, index: int, kind: str) -> dict[str, Any]:
    row = _exact(value, ARTIFACT_KEYS, f"ARTIFACT_{index}")
    _nonempty(row["artifact_id"], f"artifacts[{index}].artifact_id")
    validate_relative_path(row["relative_path"])
    if row["classification"] not in CLASSIFICATIONS:
        raise ContractError(f"ARTIFACT_CLASSIFICATION_INVALID:{index}")
    if row["status"] not in {"EXPECTED", "OK", "NOT_ESTIMABLE", "BLOCKED"}:
        raise ContractError(f"ARTIFACT_STATUS_INVALID:{index}")
    if kind == "request":
        if (
            row["status"] != "EXPECTED"
            or row["size_bytes"] is not None
            or row["sha256"] is not None
        ):
            raise ContractError(f"REQUEST_ARTIFACT_NOT_RESERVATION:{index}")
    else:
        if row["status"] == "EXPECTED":
            raise ContractError(f"RESULT_ARTIFACT_STILL_EXPECTED:{index}")
        if (
            isinstance(row["size_bytes"], bool)
            or not isinstance(row["size_bytes"], int)
            or row["size_bytes"] < 0
        ):
            raise ContractError(f"ARTIFACT_SIZE_INVALID:{index}")
        validate_sha256(row["sha256"], f"artifacts[{index}].sha256")
    return row


def validate_envelope(value: Any) -> dict[str, Any]:
    envelope = _exact(value, ENVELOPE_KEYS, "ENVELOPE")
    if envelope["schema_version"] != "1.0.0":
        raise ContractError("ENVELOPE_SCHEMA_VERSION_INVALID")
    kind = envelope["kind"]
    if kind not in {"request", "result", "decision"}:
        raise ContractError("ENVELOPE_KIND_INVALID")
    for field in ("run_id", "unit_id", "transaction_id"):
        _nonempty(envelope[field], field)
    if envelope["stage_id"] not in STAGE_IDS:
        raise ContractError("STAGE_ID_INVALID")

    raw_plan = envelope.get("plan")
    fresh_f1_worker = (
        envelope["stage_id"] == "F1"
        and kind in {"request", "result"}
        and isinstance(raw_plan, dict)
        and raw_plan.get("action") in FRESH_F1_WORKER_ACTIONS
    )
    identity_keys = BASE_IDENTITY_KEYS | (
        {"worker"}
        if envelope["stage_id"] in WORKER_BOUND_STAGE_IDS or fresh_f1_worker
        else set()
    )
    identities = _exact(envelope["identities"], identity_keys, "IDENTITIES")
    for field, identity in identities.items():
        validate_sha256(identity, f"identities.{field}")

    seed = envelope["seed"]
    if seed is not None and (
        isinstance(seed, bool) or not isinstance(seed, int) or seed < 0
    ):
        raise ContractError("SEED_INVALID")

    plan = _exact(envelope["plan"], PLAN_KEYS, "PLAN")
    _nonempty(plan["action"], "plan.action")
    _nonempty(plan["role"], "plan.role")
    if not isinstance(plan["coordinates"], list):
        raise ContractError("COORDINATES_NOT_LIST")
    coordinates = [
        _validate_coordinate(row, index)
        for index, row in enumerate(plan["coordinates"])
    ]
    axes = [row["axis"] for row in coordinates]
    if len(axes) != len(set(axes)):
        raise ContractError("DUPLICATE_COORDINATE_AXIS")
    active_worker_action = (
        kind in {"request", "result"}
        and (
            fresh_f1_worker
            or (
                envelope["stage_id"] == "F2"
                and plan["action"] in FRESH_F2_WORKER_ACTIONS
            )
        )
    )
    if active_worker_action:
        execution_contract(plan)
    elif plan["internal_threads"] != 1:
        raise ContractError("INTERNAL_THREADS_MUST_EQUAL_ONE")
    if (
        not isinstance(plan["depends_on"], list)
        or not all(isinstance(item, str) and item for item in plan["depends_on"])
        or len(set(plan["depends_on"])) != len(plan["depends_on"])
    ):
        raise ContractError("DEPENDS_ON_INVALID")

    if not isinstance(envelope["artifacts"], list):
        raise ContractError("ARTIFACTS_NOT_LIST")
    artifact_kind = "request" if kind == "request" else "result"
    artifacts = [
        _validate_artifact(row, index, artifact_kind)
        for index, row in enumerate(envelope["artifacts"])
    ]
    artifact_ids = [row["artifact_id"] for row in artifacts]
    paths = [row["relative_path"] for row in artifacts]
    if len(artifact_ids) != len(set(artifact_ids)) or len(paths) != len(set(paths)):
        raise ContractError("DUPLICATE_ARTIFACT_RESERVATION")

    if kind == "request":
        if envelope["terminal"] is not None or envelope["decision"] is not None:
            raise ContractError("REQUEST_TERMINAL_OR_DECISION_PRESENT")
    elif kind == "result":
        terminal = _exact(envelope["terminal"], TERMINAL_KEYS, "TERMINAL")
        if terminal["status"] not in {"COMPLETED", "BLOCKED", "FAILED_TYPED"}:
            raise ContractError("TERMINAL_STATUS_INVALID")
        _nonempty(terminal["reason_code"], "terminal.reason_code")
        if terminal["status"] == "COMPLETED":
            if terminal["message_sha256"] is not None:
                raise ContractError("COMPLETED_TERMINAL_MESSAGE_PRESENT")
            if any(row["status"] == "BLOCKED" for row in artifacts):
                raise ContractError("COMPLETED_RESULT_HAS_BLOCKED_ARTIFACT")
        else:
            validate_sha256(terminal["message_sha256"], "terminal.message_sha256")
            if artifacts:
                raise ContractError("NONCOMPLETED_RESULT_HAS_ARTIFACTS")
        if envelope["decision"] is not None:
            raise ContractError("RESULT_DECISION_PRESENT")
    else:
        if envelope["terminal"] is not None or artifacts:
            raise ContractError("DECISION_TERMINAL_OR_ARTIFACT_PRESENT")
        decision = _exact(envelope["decision"], DECISION_KEYS, "DECISION")
        if decision["outcome"] not in {"approve", "reject"}:
            raise ContractError("DECISION_OUTCOME_INVALID")
        _nonempty(decision["reviewer"], "decision.reviewer")
        _nonempty(decision["note"], "decision.note")
        validate_sha256(decision["note_sha256"], "decision.note_sha256")
        if decision["note_sha256"] != sha256_bytes(
            decision["note"].encode("utf-8")
        ):
            raise ContractError("DECISION_NOTE_HASH_MISMATCH")
        validate_sha256(decision["package_sha256"], "decision.package_sha256")
    return envelope


def unit_exact_key(value: Mapping[str, Any]) -> str:
    if set(value) != UNIT_EXACT_KEY_FIELDS:
        missing = sorted(UNIT_EXACT_KEY_FIELDS - set(value))
        extra = sorted(set(value) - UNIT_EXACT_KEY_FIELDS)
        raise ContractError(f"UNIT_EXACT_KEY_FIELDS_INVALID:missing={missing}:extra={extra}")
    for field in (
        "source_identity",
        "authority_identity",
        "input_identity",
        "runtime_capability_identity",
        "plan_identity",
        "request_sha256",
    ):
        validate_sha256(value[field], field)
    if value["stage_id"] not in {f"F{index}" for index in range(7)}:
        raise ContractError("UNIT_STAGE_ID_INVALID")
    for field in ("unit_id", "transaction_id"):
        if not isinstance(value[field], str) or not value[field]:
            raise ContractError(f"UNIT_{field.upper()}_INVALID")
    seed = value["seed"]
    if seed is not None and (
        isinstance(seed, bool) or not isinstance(seed, int) or seed < 0
    ):
        raise ContractError("UNIT_SEED_INVALID")
    return sha256_bytes(canonical_json_bytes(dict(value)))


def _zip_info(name: str, *, stored: bool = False) -> zipfile.ZipInfo:
    validate_relative_path(name, "zip_member")
    info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
    info.compress_type = zipfile.ZIP_STORED if stored else zipfile.ZIP_DEFLATED
    info.create_system = 3
    info.external_attr = (stat.S_IFREG | 0o644) << 16
    return info


def write_deterministic_zip(
    path: Path,
    entries: Mapping[str, bytes | Path | Callable[[], Any]],
    *,
    stored_members: set[str] | None = None,
) -> None:
    if not entries:
        raise ContractError("ZIP_ENTRIES_EMPTY")
    names = sorted(entries)
    stored = stored_members or set()
    if not stored.issubset(names):
        raise ContractError("ZIP_STORED_MEMBER_UNKNOWN")
    for name in names:
        validate_relative_path(name, "zip_member")
        value = entries[name]
        if isinstance(value, Path):
            if (
                not value.is_file()
                or value.is_symlink()
            ):
                raise ContractError(f"ZIP_MEMBER_SOURCE_INVALID:{name}")
        elif not isinstance(value, bytes) and not callable(value):
            raise ContractError(f"ZIP_MEMBER_SOURCE_INVALID:{name}")
    if (
        not path.is_absolute()
        or not path.parent.is_dir()
        or path.parent.is_symlink()
        or path.parent.resolve(strict=True) != path.parent
    ):
        raise ContractError("ZIP_TARGET_INVALID")
    temporary = path.with_name(
        f".{path.name}.tmp-{os.getpid()}-{secrets.token_hex(8)}"
    )
    if temporary.exists() or temporary.is_symlink():
        raise ContractError("ZIP_TEMPORARY_PATH_CONFLICT")
    try:
        with zipfile.ZipFile(temporary, "x") as archive:
            for name in names:
                value = entries[name]
                info = _zip_info(name, stored=name in stored)
                if isinstance(value, bytes):
                    archive.writestr(info, value)
                elif callable(value):
                    # A bounded result stream has no second uncompressed entity.
                    # Its final size is unknown until consumed; reserve ZIP64 now.
                    with archive.open(info, "w", force_zip64=True) as target:
                        for chunk in value():
                            if not isinstance(chunk, bytes):
                                raise ContractError(f"ZIP_MEMBER_SOURCE_INVALID:{name}")
                            target.write(chunk)
                else:
                    with value.open("rb") as source:
                        # Native model archives may exceed ZIP32. Reserve the
                        # correct header before streaming, not after the fit.
                        info.file_size = os.fstat(source.fileno()).st_size
                        with archive.open(info, "w") as target:
                            shutil.copyfileobj(source, target, length=1024 * 1024)
        os.chmod(temporary, 0o600)
        with temporary.open("rb") as handle:
            os.fsync(handle.fileno())
        try:
            os.link(temporary, path, follow_symlinks=False)
        except FileExistsError:
            metadata = path.stat(follow_symlinks=False)
            if (
                not stat.S_ISREG(metadata.st_mode)
                or stat.S_IMODE(metadata.st_mode) != 0o600
                or metadata.st_size != temporary.stat().st_size
                or sha256_file(path) != sha256_file(temporary)
            ):
                raise ContractError("ZIP_TARGET_DRIFT")
    finally:
        if temporary.exists() or temporary.is_symlink():
            temporary.unlink()
        directory_fd = os.open(path.parent, os.O_RDONLY)
        try:
            os.fsync(directory_fd)
        finally:
            os.close(directory_fd)


def _validated_zip_infos(
    archive: zipfile.ZipFile,
    expected_members: set[str] | None,
    *,
    max_member_bytes: int,
    max_total_bytes: int,
    max_compression_ratio: int,
) -> list[zipfile.ZipInfo]:
    infos: list[zipfile.ZipInfo] = []
    seen: set[str] = set()
    total = 0
    for info in archive.infolist():
        name = validate_relative_path(info.filename, "zip_member")
        if name in seen:
            raise ContractError(f"ZIP_DUPLICATE_MEMBER:{name}")
        seen.add(name)
        mode = (info.external_attr >> 16) & 0xFFFF
        file_type = stat.S_IFMT(mode)
        if info.flag_bits & 0x1:
            raise ContractError(f"ZIP_ENCRYPTED_MEMBER:{name}")
        if info.is_dir() or file_type not in {0, stat.S_IFREG}:
            raise ContractError(f"ZIP_NONREGULAR_MEMBER:{name}")
        if info.file_size < 0 or info.file_size > max_member_bytes:
            raise ContractError(f"ZIP_MEMBER_EXPANDED_LIMIT:{name}")
        total += info.file_size
        if total > max_total_bytes:
            raise ContractError("ZIP_TOTAL_EXPANDED_LIMIT")
        if info.file_size and (
            info.compress_size <= 0
            or info.file_size > info.compress_size * max_compression_ratio
        ):
            raise ContractError(f"ZIP_COMPRESSION_RATIO_INVALID:{name}")
        infos.append(info)
    if not infos:
        raise ContractError("ZIP_EMPTY")
    if expected_members is not None and seen != expected_members:
        missing = sorted(expected_members - seen)
        extra = sorted(seen - expected_members)
        raise ContractError(f"ZIP_MEMBER_SET_INVALID:missing={missing}:extra={extra}")
    return infos


def _stream_zip_member(
    archive: zipfile.ZipFile,
    info: zipfile.ZipInfo,
    target: Any,
) -> tuple[str, int]:
    digest = hashlib.sha256()
    crc = 0
    size = 0
    with archive.open(info, "r") as source:
        while chunk := source.read(1024 * 1024):
            target.write(chunk)
            digest.update(chunk)
            crc = zlib.crc32(chunk, crc)
            size += len(chunk)
    external = getattr(archive, "references", {}).get(info.filename)
    if size != info.file_size or (digest.hexdigest() != external["sha256"] if external else crc & 0xFFFFFFFF != info.CRC):
        raise ContractError(f"ZIP_MEMBER_INTEGRITY_INVALID:{info.filename}")
    return digest.hexdigest(), size


def _zip_source(source: Path | bytes) -> Path | io.BytesIO:
    if isinstance(source, bytes):
        return io.BytesIO(source)
    from .carriers import archive_source
    source = archive_source(source)
    if isinstance(source, io.BytesIO):
        return source
    if not source.is_file() or source.is_symlink():
        raise ContractError("ZIP_SOURCE_INVALID")
    return source.resolve(strict=True)


def _admit_zip_directory(source: Path | bytes, admit_io: Callable[..., None]) -> None:
    """Reserve before ZipFile allocates its directory, without inflating payloads.

    Use the same bounded EOCD/ZIP64 reader as ZipFile itself. Counting declared
    entries alone is insufficient: ZipFile parses the entire directory even
    when its entry count is false. These are conservative operational estimates.
    """
    admit_io(memory_bytes=1024 * 1024 + (len(source) if isinstance(source, bytes) else 0))
    handle = _zip_source(source)
    with (handle if isinstance(handle, io.BytesIO) else handle.open("rb")) as stream:
        end = zipfile._EndRecData(stream)
        if end is None:
            raise ContractError("ZIP_INVALID")
        stream.seek(0, 2)
        directory_bytes = end[zipfile._ECD_SIZE]
        if not 0 <= directory_bytes <= stream.tell():
            raise ContractError("ZIP_INVALID")
    admit_io(memory_bytes=1024 * 1024 + 32 * directory_bytes)


def read_safe_zip(
    source: Path | bytes,
    *,
    expected_members: set[str] | None = None,
    max_member_bytes: int = 512 * 1024 * 1024,
    max_total_bytes: int = 1024 * 1024 * 1024,
    max_compression_ratio: int = 1000,
    admit_io: Callable[..., None] | None = None,
) -> dict[str, bytes]:
    result: dict[str, bytes] = {}
    try:
        if admit_io is not None:
            _admit_zip_directory(source, admit_io)
        with open_carrier(_zip_source(source), "r") as archive:
            infos = _validated_zip_infos(
                archive,
                expected_members,
                max_member_bytes=max_member_bytes,
                max_total_bytes=max_total_bytes,
                max_compression_ratio=max_compression_ratio,
            )
            if admit_io is not None:
                admit_io(memory_bytes=32 * sum(info.file_size for info in infos) + 4 * 1024 * 1024)
            for info in infos:
                target = io.BytesIO()
                _stream_zip_member(archive, info, target)
                result[info.filename] = target.getvalue()
    except (zipfile.BadZipFile, RuntimeError) as exc:
        raise ContractError("ZIP_INVALID") from exc
    return result


def inspect_safe_zip_manifest(
    source: Path | bytes,
    *,
    manifest_name: str = "manifest.json",
    max_manifest_bytes: int = 1024 * 1024,
    max_member_bytes: int = 64 * 1024 * 1024 * 1024,
    max_total_bytes: int = 64 * 1024 * 1024 * 1024,
    max_compression_ratio: int = 1000,
) -> tuple[bytes, tuple[str, ...]]:
    """Bounded central-directory and CRC inspection for one named manifest."""

    validate_relative_path(manifest_name, "zip_manifest_member")
    try:
        with open_carrier(_zip_source(source), "r") as archive:
            infos = _validated_zip_infos(
                archive,
                None,
                max_member_bytes=max_member_bytes,
                max_total_bytes=max_total_bytes,
                max_compression_ratio=max_compression_ratio,
            )
            manifests = [info for info in infos if info.filename == manifest_name]
            if len(manifests) != 1:
                raise ContractError("ZIP_MANIFEST_MEMBER_INVALID")
            manifest = manifests[0]
            if manifest.file_size > max_manifest_bytes:
                raise ContractError("ZIP_MANIFEST_EXPANDED_LIMIT")
            target = io.BytesIO()
            _stream_zip_member(archive, manifest, target)
            return target.getvalue(), tuple(info.filename for info in infos)
    except (zipfile.BadZipFile, RuntimeError) as exc:
        raise ContractError("ZIP_INVALID") from exc


def extract_safe_zip(
    source: Path | bytes,
    destination: Path,
    *,
    expected_members: Mapping[str, Mapping[str, Any]] | set[str],
    max_member_bytes: int,
    max_total_bytes: int,
    max_compression_ratio: int = 1000,
    admit_io: Callable[..., None] | None = None,
    durable: bool = True,
    selected_members: set[str] | None = None,
) -> dict[str, dict[str, Any]]:
    """Verify every published byte; optionally project a retained source archive.

    Only consumers retaining the source archive may use ``durable=False`` for
    reconstructible private copies. This never changes archive/unique-result
    publication, CRC/SHA checks, quarantine isolation or recovery validation.
    A projection still checks the complete directory and declarations, but
    returns actual CRC/SHA records only for the selected, extracted payloads.
    """
    if type(durable) is not bool or not durable and not isinstance(source, Path):
        raise ContractError("ZIP_DURABILITY_SCOPE_INVALID")
    if (
        not destination.is_absolute()
        or destination.exists()
        or destination.is_symlink()
        or not destination.parent.is_dir()
        or destination.parent.is_symlink()
        or destination.parent.resolve(strict=True) != destination.parent
    ):
        raise ContractError("ZIP_DESTINATION_INVALID")
    expected_names = set(expected_members)
    declared = expected_members if isinstance(expected_members, Mapping) else None
    if selected_members is not None and (not isinstance(source, Path)
            or not isinstance(selected_members, set) or not selected_members
            or not selected_members <= expected_names):
        raise ContractError("ZIP_MEMBER_SELECTION_INVALID")
    quarantine = None
    records: dict[str, dict[str, Any]] = {}
    published = False
    try:
        if admit_io is not None:
            _admit_zip_directory(source, admit_io)
        with open_carrier(_zip_source(source), "r") as archive:
            infos = _validated_zip_infos(
                archive,
                expected_names,
                max_member_bytes=max_member_bytes,
                max_total_bytes=max_total_bytes,
                max_compression_ratio=max_compression_ratio,
            )
            if selected_members is not None:
                if declared is not None:
                    for info in infos:
                        expected = declared[info.filename]
                        if set(expected) != {"sha256", "size_bytes"}:
                            raise ContractError(f"ZIP_MEMBER_DECLARATION_INVALID:{info.filename}")
                        validate_sha256(expected["sha256"], f"{info.filename}.sha256")
                        if type(expected["size_bytes"]) is not int or expected["size_bytes"] != info.file_size:
                            raise ContractError(f"ZIP_MEMBER_DECLARATION_MISMATCH:{info.filename}")
                infos = [info for info in infos if info.filename in selected_members]
            external_paths = {info.filename: archive.external_path(info.filename)
                for info in infos if info.filename in getattr(archive, "references", {})}
            if admit_io is not None:
                device = destination.parent.stat().st_dev
                admit_io(pending_bytes=sum(info.file_size for info in infos
                    if external_paths.get(info.filename) is None or external_paths[info.filename].stat().st_dev != device),
                    memory_bytes=4 * 1024 * 1024)
            quarantine = Path(tempfile.mkdtemp(
                prefix=f".{destination.name}.quarantine-", dir=destination.parent)).resolve(strict=True)
            for info in infos:
                target = quarantine / info.filename
                target.parent.mkdir(parents=True, exist_ok=True)
                if not target.parent.resolve(strict=True).is_relative_to(quarantine):
                    raise ContractError(f"ZIP_MEMBER_PATH_ESCAPE:{info.filename}")
                external = external_paths.get(info.filename)
                if external is not None and external.stat().st_dev == quarantine.stat().st_dev:
                    os.link(external, target)
                    # Linking changes ctime. Requalify these published bytes once,
                    # and reject replacement between qualification and publication.
                    checked = archive.external_path(info.filename)
                    if not os.path.samestat(target.stat(), checked.stat()):
                        raise ContractError("CARRIER_LINK_SOURCE_CHANGED")
                    sha256, size = archive.references[info.filename]["sha256"], info.file_size
                else:
                    with target.open("xb") as handle:
                        sha256, size = _stream_zip_member(archive, info, handle)
                        if durable:
                            handle.flush()
                            os.fsync(handle.fileno())
                if declared is not None:
                    expected = declared[info.filename]
                    if set(expected) != {"sha256", "size_bytes"}:
                        raise ContractError(f"ZIP_MEMBER_DECLARATION_INVALID:{info.filename}")
                    validate_sha256(expected["sha256"], f"{info.filename}.sha256")
                    if expected != {"sha256": sha256, "size_bytes": size}:
                        raise ContractError(f"ZIP_MEMBER_DECLARATION_MISMATCH:{info.filename}")
                records[info.filename] = {
                    "relative_path": info.filename,
                    "sha256": sha256,
                    "size_bytes": size,
                }
        if durable:
            directory_fd = os.open(quarantine, os.O_RDONLY)
            try:
                os.fsync(directory_fd)
            finally:
                os.close(directory_fd)
        os.replace(quarantine, destination)
        if durable:
            parent_fd = os.open(destination.parent, os.O_RDONLY)
            try:
                os.fsync(parent_fd)
            finally:
                os.close(parent_fd)
        published = True
        return records
    except (zipfile.BadZipFile, RuntimeError) as exc:
        raise ContractError("ZIP_INVALID") from exc
    finally:
        if not published and quarantine is not None and quarantine.exists():
            shutil.rmtree(quarantine)
