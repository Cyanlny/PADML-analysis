"""Nested-LOCO scientific objects and adapters for the existing F4/F5 workflow.

Training-only family decisions and local DevelopmentLocks live here. Source
bundles, runtime, transport, native archives and acceptance belong to the
existing F4/F5 production lifecycle, not a second nested runner.
"""

from __future__ import annotations

from .carriers import open_carrier

import csv
import io
import math
import os
import tempfile
from pathlib import Path
from typing import Any, Mapping, Sequence

from ._science_authority import load_science_authority
from .bundle import (
    ContractError,
    canonical_json_bytes,
    read_safe_zip,
    sha256_bytes,
    sha256_file,
    strict_json_bytes,
    validate_relative_path,
    validate_sha256,
    write_deterministic_zip,
)


SCHEMA_VERSION = "1.0.0"
PROGRAM_ID = "PADML_F45_REBUILD_20260925"
SELECTION_HORIZONS = (6, 12, 24, 36)
OUTER_CENTERS = (36, 38, 39, 48, 52, 54)
TRAINING_ONLY_CENTER = 55
HORIZONS = tuple(range(37))
NEAR_OPTIMAL_MARGIN = 0.002
M = 20
REPEAT_COUNT = 3
INNER_FOLD_COUNT = 5
REUSED_SCORE_FAMILIES = (
    "COX_PH",
    "RSF",
    "GBM_COX",
    "XGBOOST_COX",
    "COXTIME_SET_A",
)
FRESH_SCORE_FAMILIES = ("ELASTIC_NET_COX", "FPM_TVC_SET_A")
A12_DIRECT_AAR = "A12_WITHOUT_AST_ALT_DIRECT"
A12_TOTAL_AAR = "A12_WITHOUT_AST_ALT_TOTAL"
WITHIN_FAMILY_NO_AAR_REDEVELOPMENT = (
    "OUTER_SELECTED_FAMILY_NO_AAR_REDEVELOPMENT"
)
WITHIN_FAMILY_NO_AAR_LABEL = "条件于各折已选家族的无 AAR 重开发/重筛对照"
AAR_ESTIMANDS = (
    A12_DIRECT_AAR,
    A12_TOTAL_AAR,
    WITHIN_FAMILY_NO_AAR_REDEVELOPMENT,
)


def _require(condition: bool, reason: str) -> None:
    if not condition:
        raise ContractError(reason)


def _sha(value: Any) -> str:
    return sha256_bytes(canonical_json_bytes(value))


def _sealed(body: Mapping[str, Any]) -> dict[str, Any]:
    result = dict(body)
    result["identity_sha256"] = _sha(result)
    return result


def _validate_seal(value: Any, fields: set[str], reason: str) -> dict[str, Any]:
    _require(isinstance(value, Mapping) and set(value) == fields | {"identity_sha256"}, reason)
    row = dict(value)
    validate_sha256(row["identity_sha256"], f"{reason}.identity")
    _require(row["identity_sha256"] == _sha({key: item for key, item in row.items()
                                             if key != "identity_sha256"}), reason)
    return row


def _finite(value: Any) -> bool:
    return type(value) in {int, float} and math.isfinite(float(value))


def _families() -> tuple[str, ...]:
    value = tuple(load_science_authority()["science"]["families"])
    _require(
        value
        == (
            "COX_PH",
            "ELASTIC_NET_COX",
            "RSF",
            "GBM_COX",
            "XGBOOST_COX",
            "FPM_TVC_SET_A",
            "COXTIME_SET_A",
        ),
        "NESTED_FAMILY_AUTHORITY_DRIFT",
    )
    return value


def selection_horizon(value: Any) -> int:
    _require(type(value) is int and value in SELECTION_HORIZONS,
             "NESTED_SELECTION_HORIZON_INVALID")
    return value


def family_selection_rule(selection_horizon_months: int = 24) -> dict[str, Any]:
    """The proposed 2026-09-08 training-only family rule.

    This record is prospective for the new program but post-result with respect
    to existing F2 outputs.  It is therefore never labelled result-blind.
    """
    from .f4 import FAMILY_COMPLEXITY, FAMILY_INTERPRETABILITY

    selection_horizon(selection_horizon_months)
    families = _families()
    _require(set(FAMILY_COMPLEXITY) == set(FAMILY_INTERPRETABILITY) == set(families),
             "NESTED_FAMILY_PREFERENCE_DRIFT")
    return {
        "effective_date": "2026-09-08",
        "classification": "POST_RESULT_PROSPECTIVE_NOT_RESULT_BLIND",
        "score": f"MEAN_OF_THREE_REPEAT_LEVEL_CONCATENATED_FIVE_FOLD_OOF_IBS_0_{selection_horizon_months}",
        "mi_reduction": "POOL_M20_SURVIVAL_PROBABILITIES_BEFORE_SCORING",
        "near_optimal": "MEAN_IBS_LE_MINIMUM_PLUS_0.002_INCLUSIVE",
        "tie_breakers": [
            "LOWER_MAXIMUM_REPEAT_IBS",
            "LOWER_FIXED_COMPLEXITY",
            "HIGHER_FIXED_INTERPRETABILITY",
            "CANONICAL_FAMILY_ORDER",
        ],
        "near_optimal_margin": NEAR_OPTIMAL_MARGIN,
        "canonical_family_order": list(families),
        "fixed_complexity": {family: FAMILY_COMPLEXITY[family] for family in families},
        "fixed_interpretability": {
            family: FAMILY_INTERPRETABILITY[family] for family in families
        },
        "failed_repeat_policy": "FAIL_UNIT_NO_DELETION_NO_DENOMINATOR_CHANGE",
        "additional_tolerances_or_metrics": "FORBIDDEN",
    }


_LEDGER_COUNT_FIELDS = {
    "mice_chains",
    "elastic_path_executions_maximum",
    "glmnet_pilot_and_path_calls_maximum",
    "candidate_prediction_fits",
    "stop_fits",
    "inner_scoring_fits",
    "post_lock_fits",
    "total_model_fits",
}


def _ledger_counts(
    *, mice: int, paths: int, glmnet_calls: int, candidate: int,
    stop: int, scoring: int, final: int,
) -> dict[str, int]:
    counts = {
        "mice_chains": mice,
        "elastic_path_executions_maximum": paths,
        "glmnet_pilot_and_path_calls_maximum": glmnet_calls,
        "candidate_prediction_fits": candidate,
        "stop_fits": stop,
        "inner_scoring_fits": scoring,
        "post_lock_fits": final,
        "total_model_fits": candidate + stop + scoring + final,
    }
    _require(
        set(counts) == _LEDGER_COUNT_FIELDS
        and all(type(value) is int and value >= 0 for value in counts.values()),
        "NESTED_INTERNAL_LEDGER_INVALID",
    )
    return counts


def exact_fit_budget_contract() -> dict[str, Any]:
    """Frozen pre-run caps and family-conditional exact model-fit equations.

    Elastic fine-grid overlap is data dependent.  Therefore path/call entries
    are explicit maxima over the frozen coarse-union-fine program; the result
    must later report its exact distinct-alpha count without filling the cap.
    Model-fit totals are exact because paths are accounted separately.
    """
    complex = {
        "RSF": (1070, 0),
        "GBM_COX": (1140, 1140),
        "XGBOOST_COX": (1300, 1300),
        "COXTIME_SET_A": (810, 810),
    }
    a12 = {}
    redevelopment = {}
    optional_full = {}
    for family in _families():
        candidate, stop = complex.get(family, (0, 0))
        total_mice = 1240 if family in {
            "GBM_COX", "XGBOOST_COX", "COXTIME_SET_A"
        } else 640 if family in {"ELASTIC_NET_COX", "RSF"} else 40
        a12_paths = 9600 if family == "ELASTIC_NET_COX" else 0
        a12[family] = _ledger_counts(
            mice=total_mice,
            paths=a12_paths,
            glmnet_calls=2 * a12_paths,
            candidate=2 * candidate,
            stop=2 * stop,
            scoring=0,
            final=40,
        )
        redevelop_mice = 1240 if family in {
            "GBM_COX", "XGBOOST_COX", "COXTIME_SET_A"
        } else 640
        redevelop_paths = 9600 if family == "ELASTIC_NET_COX" else 4800
        redevelopment[family] = _ledger_counts(
            mice=redevelop_mice,
            paths=redevelop_paths,
            glmnet_calls=2 * redevelop_paths,
            candidate=candidate,
            stop=stop,
            scoring=0,
            final=20,
        )
        # A fresh virtual-outer-zero selector uses its own 15 paired INNER
        # views and one full ANALYSIS view, not six historical selectors.
        # There is no held-out/full APPLICATION consumer in this branch.
        full_mice = 1220 if family in {
            "GBM_COX", "XGBOOST_COX", "COXTIME_SET_A"
        } else 620
        full_paths = 9600 if family == "ELASTIC_NET_COX" else 4800
        optional_full[family] = _ledger_counts(
            mice=full_mice,
            paths=full_paths,
            glmnet_calls=2 * full_paths,
            candidate=candidate,
            stop=stop,
            scoring=0,
            final=20,
        )
    return {
        "primary_outer": {
            "authorized": None,
            "basis": "FIXED_BY_TRAINING_SCORE_MODE_SIX_OUTERS",
            "ledger_options": {
                "REUSE_FIVE_EXACT_ACCEPTED_TRAINING_ONLY_M20_SCORE_SUMMARIES":
                    _ledger_counts(
                        mice=0, paths=0, glmnet_calls=0, candidate=0,
                        stop=0, scoring=3600, final=120,
                    ),
                "FRESH_SEVEN_FAMILY_REPLAY": _ledger_counts(
                    mice=0, paths=0, glmnet_calls=0, candidate=0,
                    stop=0, scoring=12600, final=120,
                ),
            },
        },
        "full_data_same_program": {
            "authorized": None,
            "basis": "FIXED_FRESH_SEVEN_FAMILY_VIRTUAL_OUTER_ZERO",
            "ledger": _ledger_counts(
                mice=(15 * 2 + 15 * 2 + 1) * M,
                paths=(15 + 1) * M * 15,
                glmnet_calls=2 * (15 + 1) * M * 15,
                candidate=4320,
                stop=3250,
                scoring=2100,
                final=20,
            ),
        },
        "a12_direct_total": {
            "authorized": None,
            "basis": "SUM_SIX_OUTERS_BY_EACH_PRIMARY_LOCK_FAMILY",
            "per_outer_by_inherited_family": a12,
        },
        "outer_selected_family_no_aar_redevelopment": {
            "authorized": None,
            "basis": "SUM_SIX_OUTERS_BY_EACH_PRIMARY_LOCK_FAMILY",
            "per_outer_by_inherited_family": redevelopment,
        },
        "bootstrap_b100_b200": {
            "authorized": None,
            "basis": "PENDING_USER_BOOTSTRAP_DECISION",
            "ledger": None,
        },
        "optional_no_aar_full_data": {
            "authorized": None,
            "basis": "ONE_FULL_DATA_BRANCH_BY_PRIMARY_FULL_DATA_LOCK_FAMILY",
            "by_inherited_family": optional_full,
        },
        "elastic_distinct_alpha_rule": (
            "EXECUTE_COARSE_UNION_ONLY_MISSING_FINE_MAXIMUM_15;"
            "RESULT_REPORTS_EXACT_ACTUAL_PATHS_AND_CALLS"
        ),
    }


def four_horizon_contract() -> dict[str, Any]:
    return {
        "selection_horizons_months": list(SELECTION_HORIZONS),
        "report_horizons_months": list(SELECTION_HORIZONS),
        "prediction_grid_months": list(HORIZONS),
        "family_selection_by_horizon": {
            str(h): family_selection_rule(h) for h in SELECTION_HORIZONS},
        "whole_units": {"PRIMARY": 24, "AAR": 24, "FULL0": 4, "EVALUATION": 4},
        "epv": {
            "preferred_minimum": 15, "fallback_minimum": 10, "inclusive": True,
            "scope": "COMPLETE_SELECTOR_CONTEXT_ALL_COARSE_ALPHA_AND_M20",
            "fallback": "ALL_VALID_COARSE_CANDIDATES_PURELY_EPV_INFEASIBLE_AT_15",
            "same_paths": True, "numerical_failure_fallback": False,
            "mixed_imputation_tiers": False, "label": "10_LE_EPV_LT_15"},
        "risk_ordering": "1_MINUS_SURVIVAL_AT_THIS_LINE_HORIZON",
        "uno_pairs": "event_i=1,T_i<=h,T_j>T_i",
        "harrell_pairs": "ORIGINAL_FULL_FOLLOWUP_PAIRS",
        "dca": {"min": 0.05, "max": 0.30, "step": 0.01, "count": 26,
                "normalization_divisor": 0.25},
        "reuse": "CURRENT_BATCH_IDENTICAL_SCIENTIFIC_DEPENDENCIES",
        "old_f45_results": "REJECTED",
        "physical_work": "UNION_OF_REQUIRED_ORIGINAL_COORDINATES_MINUS_VALID_COMPLETED",
        "shared_bootstrap": "ONE_CANONICAL_B1000_DRAW_ARCHIVE_ALL_LINES",
        "final_model_binding": "THIS_LINE_DEVELOPMENT_LOCK",
        "b100_b200": False, "no_aar_full0": False,
    }


def _confirmed_fit_budget() -> dict[str, Any]:
    budget = exact_fit_budget_contract()
    for name in ("primary_outer", "full_data_same_program", "a12_direct_total",
                 "outer_selected_family_no_aar_redevelopment"):
        budget[name]["authorized"] = True
    budget["optional_no_aar_full_data"]["authorized"] = False
    budget["bootstrap_b100_b200"] = {
        "authorized": False,
        "basis": "ZERO_CURRENT_BATCH_DEFERRED_REQUIRES_SEPARATE_CONFIRMATION",
        "ledger": _ledger_counts(mice=0, paths=0, glmnet_calls=0,
                                 candidate=0, stop=0, scoring=0, final=0)}
    budget["fixed_prediction_paired_b1000"] = {
        "authorized": True, "replicate_count": 1000,
        "basis": "SHARED_1000_PATIENT_DRAWS_PRIMARY_AND_THREE_AAR_FIXED_PREDICTIONS",
        "ledger": _ledger_counts(mice=0, paths=0, glmnet_calls=0,
                                 candidate=0, stop=0, scoring=0, final=0),
        "metric_and_calibration_cost": "ACCOUNTED_SEPARATELY"}
    return budget


def _base_science_decision_template(selection_horizon_months: int | None = None) -> dict[str, Any]:
    """The user-confirmed fresh four-line program; F2 authority is unchanged."""
    body = {
        "schema_version": SCHEMA_VERSION,
        "kind": "PADML_NESTED_LOCO_SCIENCE_DECISION_V1",
        "program_id": PROGRAM_ID,
        "status": "CONFIRMED",
        "classification": "POST_RESULT_PROSPECTIVE_NOT_RESULT_BLIND",
        "family_selection": family_selection_rule(),
        "training_score_reuse": {
            "proposal": "FRESH_SEVEN_FAMILY_CURRENT_RAW_DATA",
            "families": [],
            "fresh_families": list(_families()),
            "alternative": "FRESH_SEVEN_FAMILY_REPLAY",
            "confirmed": "FRESH_SEVEN_FAMILY_REPLAY",
        },
        "fpm": {
            "proposal": "FIXED_OUTCOME_FREE_COMPUTATIONAL_DOMAIN",
            "actual_input": {
                "lower_bound": 0,
                "lower_inclusive": False,
                "upper_bound": 15,
                "upper_inclusive": True,
            },
            "geometric_closure": [0, 15],
            "out_of_domain": "FAIL_NO_CLIP_NO_DROP_NO_REMAP",
            "origin_observed_range": [0.1752032358, 14.48611111],
            "origin_timing": "FULL_FROZEN_QUEUE_OUTWARD_ROUNDING_POST_RESULT_OUTCOME_FREE",
            "external_applicability_claim": False,
            "confirmed": True,
        },
        "aar": {
            "estimands": list(AAR_ESTIMANDS),
            "contracts": {
                estimand: aar_estimand_contract(estimand)
                for estimand in AAR_ESTIMANDS
            },
            "new_branch_label": WITHIN_FAMILY_NO_AAR_LABEL,
            "outer_family_source": "EACH_PRIMARY_OUTER_DEVELOPMENT_LOCK",
            "family_reselection_in_no_aar_branches": False,
            "no_aar_full_data_final_model": False,
        },
        "bootstrap": fixed_prediction_bootstrap_contract(),
        "fit_budget": _confirmed_fit_budget(),
        "four_horizon_development": four_horizon_contract(),
        "integrated_raw_data": {
            "input": "NEW_WORKBOOK_NEW_DATA_SPLIT_SOURCE_RUN_IDENTITIES",
            "legacy_results": "FORBIDDEN_IN_NEW_BATCH",
            "standalone_f1_f2_units": False,
            "split_local_mice": "M20_ORIGINAL_SEEDS_PMM_30_40_50_RESUME_MISSING_CHAINS",
            "compact_coordinates": True,
            "retention": "NECESSARY_FIRST_CONSUMED_NUMBERS_SUPPORT_AND_PROVENANCE",
            "center_macro": ["EQUAL_CENTER", "FIXED_ORIGINAL_VALIDATION_PATIENT_COUNTS"],
            "center_missing": "NO_REWEIGHTING_NO_COMPLETE_CASE_INTERVAL",
            "bootstrap_interval": "ALL_1000_IDS_TYPE7_0.025_0.975",
            "legacy_execution": "UNCHANGED_NOT_DEPLOYED_BY_THIS_PACKAGE",
            "post_lock_diagnostics": {
                "scope": "24_PRIMARY_AND_4_FULL0_ONLY",
                "selector_sensitivity": "MRMRE_BORUTA_M20_ORIGINAL_SEEDS_LOCKED_MAIN_EPV_15_OR_10",
                "natural_AST_ALT": "INDEPENDENT_PENALTY1_COARSE_FINE_MI_LAMBDA_ACTUAL_NONZERO_DF_15_THEN10",
                "natural_success_threshold": None,
                "seed_audit": "WINNER_ONLY_RSF_GBM_XGBOOST_TWO_ORIGINAL_EXTRA_SEEDS_INNER15_M5",
                "main_selection_writeback": "FORBIDDEN", "SetB": "NOT_IMPLEMENTED_THIS_BATCH"},
            "application_self_check": {"scope":"ENGINEERING_NOT_FULL_A04", "maximum_per_validation_center":2,
                "center55":"DONOR_ONLY", "m":20, "prediction_months":[6,12,24,36],
                "batch_and_single":True, "maximum_application_chains_per_full0":360,
                "cross_window_reuse":"EXACT_RAW_DONOR_PATIENT_CONFIG_SEED_KERNEL_IDENTITY"},
            "complete_data_mice": {"logical_slots":20,"actual_chains":0,"iterations":0,
                "convergence":"NOT_APPLICABLE","rng_consumed":False},
            "completion":"56_UNITS_28_POSTPROCESS_28_SELECTION_4_APPLICATION_CHECKS_AND_COLLECTED_REPORTS",
        },
    }
    if selection_horizon_months is None or selection_horizon_months == 36:
        body["amendment_20260928"] = {
            "h36_tuning_population": "EXCLUDE_VALIDATION_CENTER_55_KEEP_FULL_FIT",
            "scope": ["PRIMARY", "AAR_DIRECT", "AAR_TOTAL", "AAR_NO_AAR", "FULL0"],
            "consumers": ["SELECTOR_LOSS", "STOP_LOSS", "IBS_PROMOTION", "FAMILY_SELECTION", "LOCK"],
            "training_events_epv_mice": "UNCHANGED_INCLUDING_CENTER_55",
            "other_selection_horizons": "ORIGINAL_SCIENCE_IDENTITY_UNCHANGED",
            "shap": {"max_iter": 500, "tol": 0.005, "kernelshap": "0.9.1",
                "all_patients_and_background": True, "preserve_return_before_guard": True,
                "finite_budget_failure": "FINISH_OTHER_MI_THEN_FAIL_INCOMPLETE_UNIT",
                "retained_models": "NO_REFIT_FOR_MISSING_EXPLANATIONS"},
        }
    else:
        _require(selection_horizon_months in {6, 12, 24}, "NESTED_SELECTION_HORIZON_INVALID")
    return _sealed(body)


def selector_frequency_policy() -> dict[str, Any]:
    """The explicit post-failure amendment; native path computation is unchanged."""
    return _sealed({"kind": "PADML_FORMAL_SELECTOR_FREQUENCY_AMENDMENT_V1",
        "confirmation_date": "2026-10-06",
        "classification": "POST_RESULT_ANALYSIS_RULE_AMENDMENT_NOT_PRESPECIFIED",
        "scope": ["PRIMARY", "FULL0", "OUTER_SELECTED_FAMILY_NO_AAR_REDEVELOPMENT"],
        "ladder": [{"minimum": epv, "frequency_threshold": frequency} for epv, frequency in
            ((15, 12), (10, 12), (10, 14), (10, 16), (10, 18), (10, 20))],
        "denominator": 20, "stop": "FIRST_COMPLETE_VALID_FEASIBLE_COARSE_TIER",
        "common_df": "LOCKED_ELASTIC_DESIGN_COMPLETE_COLUMN_COUNT",
        "empty_frequency_aggregate": "NOT_ESTIMABLE_NO_REPLACEMENT_MODEL",
        "invalid_native_path": "ERROR_NO_FALLBACK",
        "fine": "ONE_ORIGINAL_GRID_AT_LOCKED_TIER_INCLUDING_COARSE_WINNER",
        "fixed_set_and_independent_diagnostics": "UNCHANGED",
        "new_native_path_budget": 0, "old_success": "UNCHANGED_SUCCESSFUL_PREFIX"})


def science_decision_template(selection_horizon_months: int | None = None) -> dict[str, Any]:
    base = _base_science_decision_template(selection_horizon_months)
    return _sealed({**{k: v for k, v in base.items() if k != "identity_sha256"},
        "selector_frequency_amendment": {"base_science_sha256": base["identity_sha256"],
                                        "policy": selector_frequency_policy()}})


def science_identity_matches(identity: str, horizon: int | None = None) -> bool:
    """Only the frozen base and this exact amendment are admissible identities."""
    return identity in {_base_science_decision_template(horizon)["identity_sha256"],
                        science_decision_template(horizon)["identity_sha256"]}


def compatible_science_decisions(previous, current) -> bool:
    before, after = validate_science_decision(previous), validate_science_decision(current)
    if before == after:
        return True
    amendment = after.get("selector_frequency_amendment")
    return ("selector_frequency_amendment" not in before and amendment is not None
            and amendment["base_science_sha256"] == before["identity_sha256"]
            and {k: v for k, v in after.items() if k not in {"identity_sha256", "selector_frequency_amendment"}}
                == {k: v for k, v in before.items() if k != "identity_sha256"})


def fixed_prediction_bootstrap_contract() -> dict[str, Any]:
    """The approved fixed-prediction batch, separate from deferred redevelopment."""
    from .f4 import BOOTSTRAP_ROOTS, PATIENT_KEY_RULE

    return {
        "fixed_prediction": {
            "authorized": True,
            "definition": "PAIRED_CENTER_STRATIFIED_FIXED_M20_POOLED_PREDICTIONS",
            "replicate_count": 1000,
            "resampling_unit": "PATIENT_WITH_REPLACEMENT_WITHIN_CENTER_FIXED_CENTER_COUNTS",
            "domain": "FIXED_MODEL_PAIRED",
            "root_seed": BOOTSTRAP_ROOTS["FIXED_MODEL_PAIRED"],
            "rng": ["L'Ecuyer-CMRG", "Inversion", "Rejection"],
            "patient_key_rule": PATIENT_KEY_RULE,
            "center_order": list(OUTER_CENTERS),
            "branches": ["PRIMARY", *AAR_ESTIMANDS],
            "paired_draws": "ONE_IDENTICAL_PATIENT_RESAMPLE_FOR_ALL_FOUR_BRANCHES_PER_REPLICATE",
            "contrast": "CONTROL_MINUS_PRIMARY",
            "uncertainty": "CONDITIONAL_ON_FIXED_PREDICTIONS_NOT_FULL_DEVELOPMENT_OR_FAMILY_SELECTION",
            "new_predictive_model_fits": 0,
            "metric_and_calibration_cost": "ACCOUNTED_SEPARATELY_NOT_PREDICTIVE_MODEL_FITS",
        },
        "full_retraining": {
            "authorized": False,
            "status": "DEFERRED_NOT_CANCELLED_NOT_WHOLE_STUDY_CLOSURE",
            "initial_replicates": 100,
            "maximum_replicates": 200,
            "b101_b200_trigger": "DEFERRED_SEPARATE_STATISTICS_TRIGGER_AND_INTEGER_BUDGET_CONFIRMATION_REQUIRED",
            "current_batch_additional_model_fit_budget": 0,
            "completed_batch_policy": "NO_RESEAL_OR_RECOMPUTE_TO_START_A_LATER_BATCH",
        },
    }


_DECISION_FIELDS = {
    "schema_version", "kind", "program_id", "status", "classification",
    "family_selection", "training_score_reuse", "fpm", "aar", "bootstrap",
    "fit_budget",
}


def _twelve_month_development_contract() -> dict[str, Any]:
    """The user-confirmed extension; never overwrite the original 24-month ledger."""
    original = exact_fit_budget_contract()
    initial = _ledger_counts(mice=0, paths=0, glmnet_calls=0, candidate=7920,
                             stop=6000, scoring=0, final=0)
    subsequent = _ledger_counts(mice=0, paths=0, glmnet_calls=0, candidate=18000,
                                stop=13500, scoring=7200, final=120)
    full0 = _ledger_counts(mice=0, paths=0, glmnet_calls=0, candidate=3000,
                           stop=2250, scoring=1200, final=20)
    return {
        "status": "CONFIRMED",
        "classification": "POST_RESULT_ADDED_ANALYSIS_NOT_RESULT_BLIND",
        "confirmation_recorded_utc": "2026-09-11T16:49:50Z",
        "original_24_month_decision_sha256": "37c96bdd67c8e08a8ae4f1e29bf43023b8d8fb2375bc057079d1ca8581ef4648",
        "selection_horizon_months": 12,
        "primary_report_horizon_months": 12,
        "secondary_report_horizons_months": [6, 24, 36],
        "prediction_grid_months": list(range(37)),
        "family_selection": {
            **family_selection_rule(),
            "effective_date": "2026-09-12",
            "score": "MEAN_OF_THREE_REPEAT_LEVEL_CONCATENATED_FIVE_FOLD_OOF_IBS_0_12",
        },
        "candidate_selection": "ORIGINAL_STAGE_MI_REPEAT_FIDELITY_AND_PROMOTION_WITH_IBS_0_12",
        "ibs": {"grid_months": list(range(13)), "integration": "TRAPEZOID_DIVIDE_BY_12",
                "support_months": list(range(13)), "followup_truncation": False},
        "uno": {"risk": "1-S(12)", "pairs": "event_i=1,T_i<=12,T_j>T_i",
                "weights": "1/[G_i(T_i-) G_j(T_i)]", "risk_tie_credit": 0.5},
        "harrell": {"risk": "1-S(12)", "pairs": "ORIGINAL_FULL_FOLLOWUP_PAIRS"},
        "dca": {"horizon_months": 12, "threshold_min": 0.05, "threshold_max": 0.30,
                "threshold_step": 0.01, "threshold_count": 26,
                "integration": "TRAPEZOID",
                "normalization_divisor": 0.25, "metric": "RAW_IPCW_NET_BENEFIT",
                "denominator": "ORIGINAL_PATIENT_DENOMINATOR",
                "additional_case_control_gate": False},
        "support_rules": "UNCHANGED_CENTER_KM_G_FLOOR_ESS_AND_METRIC_SPECIFIC_SUPPORT",
        "development_incremental_budget": {
            "basis": "REQUIRED_COORDINATES_MINUS_EXACT_VALID_COMPLETED_COMPUTATION",
            "initial_outer_f2_evidence_recovery_maximum": initial,
            "subsequent_outer_promotion_and_lock_maximum": subsequent,
            "full0_maximum": full0,
            "total_maximum": {key: initial[key] + subsequent[key] + full0[key] for key in initial},
            "initial_recovery_is_included_not_additional": True,
            "old_f2_evidence_recovery_refits_authorized": True,
            "full0_common_initial_work": "ORIGINAL_24_MONTH_TREE_S1_S2_COXTIME_S1_AND_FIXED_COX_ELASTIC_FPM_900_SCORING_FITS_MUST_FIRST_COMPLETE_BEFORE_EXACT_REUSE",
            "mice_and_selector_reuse": "EXACT_CONTEXT_REQUIRED_ELSE_STOP_NO_AUTOMATIC_REFIT",
        },
        "aar_incremental_budget": {
            "basis": "EACH_BRANCH_EACH_COUNT_CATEGORY_REQUIRED_COORDINATES_MINUS_EXACT_VALID_COMPLETED_COMPUTATION",
            "family_source": "THIS_LINE_EACH_PRIMARY_OUTER_DEVELOPMENT_LOCK",
            "model_formula_per_outer": "3*C+3*S+60_MINUS_EXACT_VALID_REUSE",
            "direct_total": {**original["a12_direct_total"], "authorized": True},
            "within_family_redevelopment": {
                **original["outer_selected_family_no_aar_redevelopment"], "authorized": True},
            "six_outer_marginal_maxima": {"total_model_fits": 47160, "mice_chains": 14880,
                "elastic_path_executions_maximum": 115200, "glmnet_pilot_and_path_calls_maximum": 230400},
            "marginal_maxima_are_not_one_family_combination": True,
        },
        "total_incremental_model_fit_ceiling": 106370,
        "fill_budget_caps": False,
        "protected_34_model_refits": 0,
        "fixed_prediction_evaluation": {"branch_scope_jobs_maximum": 28028,
            "basis": "4_BRANCHES_X_7_SCOPES_X_1001_POINT_AND_REPLICATES_NOT_TIMES_HORIZONS",
            "new_predictive_model_fits": 0, "canonical_rng": "ONE_DRAW_ARCHIVE_SHARED_BETWEEN_LINES",
            "point_reuse": "VALID_SAME_LINE_ONLY", "metric_calibration_cost": "ACCOUNTED_SEPARATELY"},
        "full0_shap": {"maximum_mi_components": 20, "risk_horizons_months": [6, 12, 24, 36],
            "explained_output": "THIS_LINE_RISK_1_MINUS_SURVIVAL_NOT_IBS",
            "prediction_calls_are_model_fits": False},
        "full_retraining_b100_b200_model_fits": 0,
        "no_aar_full0": False,
        "additional_hosts_or_cost_authorized": False,
    }


def _full0_rsf_tail_restoration_contract() -> dict[str, Any]:
    """The exact separately approved two interrupted four-model RSF units."""
    return {
        "status": "CONFIRMED",
        "classification": "POST_INTERRUPTION_EVIDENCE_RECOVERY_NOT_NEW_SEARCH",
        "confirmation_recorded_utc": "2026-09-12T11:39:27Z",
        "original_24_month_decision_sha256": "37c96bdd67c8e08a8ae4f1e29bf43023b8d8fb2375bc057079d1ca8581ef4648",
        "selection_horizon_months": 24,
        "virtual_outer": 0,
        "family": "RSF",
        "stage": "S3B2",
        "trial": "T001",
        "original_producer_source_identity": "1513ecba963857099c6b99413b8e976393c551a3ec30ed90da1cb14178338bd7",
        "original_q_input": {"sha256": "ff539adb9ed7463779f8553170e018080497f792a944153e9ce59eb157a65d56",
                             "size_bytes": 61442},
        "original_phase": "_run_r_prediction_pool_task-54a595d74288cc589fd67a87",
        "atomic_units": [
            {"unit_id": "batch-11732ff7f94c07ec89be80a1",
             "task_ids": ["S3B2_T001_P14_M05", "S3B2_T001_P14_M06",
                          "S3B2_T001_P14_M07", "S3B2_T001_P14_M08"],
             "existing_incomplete_model_task_ids": ["S3B2_T001_P14_M05", "S3B2_T001_P14_M06"]},
            {"unit_id": "batch-d913979f23fee6cc361ce63b",
             "task_ids": ["S3B2_T001_P15_M01", "S3B2_T001_P15_M02",
                          "S3B2_T001_P15_M03", "S3B2_T001_P15_M04"],
             "existing_incomplete_model_task_ids": ["S3B2_T001_P15_M01", "S3B2_T001_P15_M02"]},
        ],
        "additional_fit_budget": _ledger_counts(mice=0, paths=0, glmnet_calls=0,
                                               candidate=8, stop=0, scoring=0, final=0),
        "atomic_geometry": "ORIGINAL_FOUR_MODELS_NO_MIXED_PRODUCE_REPLAY",
        "existing_model_and_failure_evidence": "PRESERVE_ALL_ORIGINAL_BYTES_NO_OVERWRITE",
        "completed_units": "ORIGINAL_NUMERICAL_RECOVERY_ONLY_NO_REFIT",
        "unstarted_units": "ORIGINAL_BUDGET_NOT_THIS_ADDITIONAL_AUTHORIZATION",
        "prior_incomplete_fit_count": "UNKNOWN_NOT_INFERRED_FROM_RDS_PRESENCE",
        "protected_34_model_refits": 0,
        "changes_to_checks_parameters_or_seeds": False,
    }


def _aar3_mice_view_restoration_contract() -> dict[str, Any]:
    """Three conditionally approved whole-M20 views; not a retry allowance."""
    units = [
        (A12_TOTAL_AAR, "INNER_R1_K1_ANALYSIS",
         "cc0cae40e44516d3fb77c514f217a678bdead3fa80d5bc9bdb0fc983dd3e92cd", 141266,
         "71309248e16a30312849d87366d8b6729ae0af6c5e6139827c044022688da1ab", 124012,
         150002521, 2, "1e9b98e5f7f640155bff611e94ba322b402114440eb2fbeef34d7f2c88e36268"),
        (A12_TOTAL_AAR, "INNER_R1_K4_ANALYSIS",
         "58fa18489dbb3f477bffb521af8947f7cd6e587dbe373feb1352c01879a8243c", 142070,
         "9130582dcc6f228b645d54b2b87e0673c203b2d153c25c485bd563f4e51e6426", 124128,
         150002761, 3, "1e9b98e5f7f640155bff611e94ba322b402114440eb2fbeef34d7f2c88e36268"),
        (WITHIN_FAMILY_NO_AAR_REDEVELOPMENT, "INNER_R3_K3_ANALYSIS",
         "72a8b3504e3c47251ec66f9094a1c045c850cd9fe8979540602af12365413af7", 141786,
         "276907cc5e61dda2e197bbd80d08dc65bae52bab8ccc43ac8a5a9d3b79826bc1", 124075,
         150003481, 6, "1513ecba963857099c6b99413b8e976393c551a3ec30ed90da1cb14178338bd7"),
    ]
    return {
        "status": "CONFIRMED_CONDITIONAL_EXECUTION",
        "classification": "POST_INTERRUPTION_EVIDENCE_RECOVERY_NOT_NEW_SEARCH",
        "admission_amendment": "USER_CONFIRMED_HISTORICAL_UNKNOWN_ALLOWED_FOR_ONLY_THESE_THREE_VIEWS",
        "superseded_conditional_decision_sha256": "13092ae15a391937e2b92185d39efddec6576b731b3bef4b778b0810d0ec7087",
        "historical_interruption_cause": "UNKNOWN",
        "inventory": {"date": "2026-09-13", "version": "00:28_ASIA_SHANGHAI",
            "sha256": "18187491ee423c1a7eca39b42ef51b132a0ddf41366a5ac3207037f4f149a856"},
        "original_24_month_decision_sha256": "37c96bdd67c8e08a8ae4f1e29bf43023b8d8fb2375bc057079d1ca8581ef4648",
        "prior_decision_sha256": "7875d1c47e4a2815558acbc7ea0127e47defbc0d28c599ff4669035499583297",
        "selection_horizon_months": 24, "outer_fold": 3, "heldout_center": "39",
        "family": "GBM_COX", "role": "ANALYSIS", "formal_m": 20,
        "original_projected_input": {
            "sha256": "6fed6aeef53215755e3ed2584137370914529ad02da102c3eb0d0bd970e56e55",
            "identity_sha256": "6d93ae98e4425805d8fa22e51caabedc527302d3f9ca278852fac1ab8a4ad5e0"},
        "atomic_units": [{"estimand": estimand, "view_id": view,
            "original_input": {"sha256": input_sha, "size_bytes": input_size},
            "original_spec": {"sha256": spec_sha, "size_bytes": spec_size},
            "original_producer_source_identity": producer,
            "chain_seeds": list(range(seed, seed + 20)),
            "preserve_original_partial_rds": [f"imp{index:02d}.rds" for index in range(1, partial + 1)],
            "mice_chains_maximum": 20, "mice_fit_invocations_maximum": 1}
            for estimand, view, input_sha, input_size, spec_sha, spec_size, seed, partial, producer in units],
        "additional_fit_budget": _ledger_counts(mice=60, paths=0, glmnet_calls=0,
                                               candidate=0, stop=0, scoring=0, final=0),
        "mice_fit_invocations_maximum": 3,
        "required_per_unit_admission_evidence": ["PROVEN_NOT_ZERO_FIT_RECOVERABLE",
            "NECESSARY_COMPATIBILITY_TESTS_PASSED", "ORIGINAL_TASK_STOPPED",
            "NO_COMPLETE_OR_IN_FLIGHT_DUPLICATE", "NO_CURRENT_FAULT_DETECTED",
            "ORIGINAL_INPUT_SPEC_SEEDS_AND_PARTIAL_BYTES_PRESERVED", "FRESH_SHARED_RESOURCE_ADMISSION",
            "UNCHANGED_ORIGINAL_SCIENTIFIC_CHECKS"],
        "atomic_geometry": "ORIGINAL_WHOLE_M20_FIT_THEN_FIRST_REPLAY_NO_PARTIAL_CHAIN_RESUME",
        "attempt_scope": "ONE_PER_ORIGINAL_COORDINATE_NOT_RESET_BY_PATH_INPUT_COPY_OR_EXECUTOR",
        "again_failed_or_changed_rule": "STOP_AFFECTED_UNIT_AND_REQUEST_SEPARATE_APPROVAL",
        "existing_model_and_failure_evidence": "PRESERVE_ALL_ORIGINAL_BYTES_NO_OVERWRITE",
        "zero_fit_recoverable_views": "EXCLUDED_FROM_THIS_FIT_ALLOWANCE",
        "other_recovery_accounts": "EXHAUSTED_RSF8_AND_TWELVE_MONTH_OLD_F2_REMAIN_SEPARATE",
        "protected_34_model_refits": 0, "changes_to_checks_parameters_or_seeds": False,
        "fill_budget_caps": False,
    }


def _outer4_common_set_epv_exception_contract() -> dict[str, Any]:
    """The user's post-result exception for the demonstrated outer4 blocker.

    This is selection authority, not evidence that any consumer has executed.
    The original primary decision and every existing budget remain unchanged.
    """
    return {
        "status": "CONFIRMED",
        "classification": "POST_RESULT_COMMON_SETA_EPV_EXCEPTION_NOT_RESULT_BLIND",
        "confirmation_date": "2026-09-15",
        "prior_decision_sha256": "8d3489742472c51c868e1829de3edd94272698067b42c7c909ff1c7c895e07cf",
        "selection_horizon_months": 24, "outer_fold": 4, "heldout_center": "48",
        "family": "RSF", "estimand": WITHIN_FAMILY_NO_AAR_REDEVELOPMENT,
        "projected_input_sha256": "41b247105716d4fcb3ba3be3222138efb35bebe1bc36565abc47da8b9169c4de",
        "projected_input_identity_sha256": "1204c950c4f61b4a30ae3302825cad8720c77bd9c5daff68159c7eaaad88f9af",
        "selector_source": {
            "kind": "PADML_NESTED_NO_AAR_SELECTOR_SOURCE_V1", "program_id": PROGRAM_ID,
            "context": 4, "inherited_family": "RSF",
            "primary_development_lock_sha256": "edc45b4fa2687ce55351925a17b89fb26866cfc47574d00f7e52788033df3352",
            "training_ids_sha256": "d16a678a72896352e404ca973b6fb1e542bdb62a6e8cde08e1627dc50897f42d",
            "training_response_sha256": "87e60d3a58bf4d95f9163870592c6689f8c20f4148695cc03146c3e46e718052",
            "mice_plan_sha256": "b5cd62361e244e03c82571a418680e2512c7745cc3c1a6fa11b835b463321068",
        },
        "outer_training_event_count": 339,
        "common_set_epv_rule": "ALLOW_BELOW_15_FOR_THIS_CONTEXT_REPORT_ACTUAL_EPV",
        "replacement_minimum": None,
        "per_imputation_epv_minimum": 15,
        "per_imputation_lambda_rule": "UNCHANGED_ORIGINAL_FEASIBLE_DOMAIN_1SE",
        "parent_frequency_alpha_grid_loss_and_tie_rules": "UNCHANGED",
        "empty_set_nonfinite_missing_path_and_identity_failures": "STILL_FAIL",
        "original_coarse_paths": {
            "sha256": "101bbbab80ea8c91b5c55f3b00370c8887ad0309276050d72a2e3690dc75b065",
            "size_bytes": 42285170,
        },
        "original_coarse_execution_sha256": "ff4ef01734c50fb1553533ad0a05a4a687e3825731acc6da257a969d1c2d2b7a",
        "completed_coarse_paths": "REUSE_COMPLETE_ORIGINAL_EVIDENCE_NO_REEXECUTION",
        "future_paths": "ORIGINAL_FINE_MINUS_COMPLETED_COARSE_WITHIN_EXISTING_BUDGET",
        "additional_fit_budget": _ledger_counts(mice=0, paths=0, glmnet_calls=0,
                                               candidate=0, stop=0, scoring=0, final=0),
        "budget_policy": "UNCHANGED_EXISTING_AUTHORIZED_BUDGETS_NO_RESET_NO_FILL",
        "protected_34_model_refits": 0,
        "original_inputs_models_partial_results_and_failures": "PRESERVE_NO_OVERWRITE",
        "primary_direct_total_other_outers_full0_and_twelve_month_exception": False,
        "required_consumer_binding": "SAME_CONFIRMED_EXCEPTION_THROUGH_SELECTOR_DEVELOPMENT_Q_AND_FINAL",
        "again_failed_or_changed_rule": "STOP_AFFECTED_UNIT_AND_REQUEST_SEPARATE_APPROVAL",
    }


def _validate_outer4_common_set_epv_binding(
    value: Any, *, selector_source: Mapping[str, Any] | None = None,
    projected_source: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """The fixed approved rule, with independently materialized input binding.

    Kernel callers additionally validate actual event/design evidence. This
    does not approve an arbitrary decision SHA or change the primary lock.
    """
    exception = _outer4_common_set_epv_exception_contract()
    expected = {
        "science_decision_sha256": "7dd06b0438c0b3a9275296f44401d1607421665427b0c2a602f51699e19f2ee4",
        "exception": exception,
    }
    _require(isinstance(value, Mapping)
             and canonical_json_bytes(value) == canonical_json_bytes(expected),
             "NESTED_OUTER4_COMMON_SETA_EPV_BINDING_INVALID")
    if selector_source is not None:
        _require(canonical_json_bytes(selector_source) == canonical_json_bytes(exception["selector_source"]),
                 "NESTED_OUTER4_COMMON_SETA_EPV_SOURCE_INVALID")
    if projected_source is not None:
        _require(isinstance(projected_source, Mapping)
                 and projected_source.get("identity_sha256") == exception["projected_input_identity_sha256"]
                 and _sha({key: item for key, item in projected_source.items() if key != "identity_sha256"})
                     == exception["projected_input_identity_sha256"],
                 "NESTED_OUTER4_COMMON_SETA_EPV_SOURCE_INVALID")
    return dict(value)


def validate_science_decision(value: Any, *, selection_horizon_months: int | None = None) -> dict[str, Any]:
    """Reject superseded F4/F5 decisions, including the old outer4 exception."""
    template = (science_decision_template if isinstance(value, Mapping)
                and "selector_frequency_amendment" in value else _base_science_decision_template)
    expected = template(selection_horizon_months)
    if selection_horizon_months is None and isinstance(value, Mapping) and "amendment_20260928" not in value:
        expected = template(24)
    row = _validate_seal(value, set(expected) - {"identity_sha256"},
                         "NESTED_SCIENCE_DECISION_INVALID")
    _require(canonical_json_bytes(row) == canonical_json_bytes(expected),
             "NESTED_SCIENCE_DECISION_OR_PROGRAM_DRIFT")
    return row


def outer_fresh_score_families(science_decision: Mapping[str, Any]) -> tuple[str, ...]:
    decision = validate_science_decision(science_decision)
    return tuple(decision["training_score_reuse"]["fresh_families"])


def _outer_science_decision_binding(science_decision: Mapping[str, Any]) -> dict[str, Any]:
    science = validate_science_decision(science_decision)
    mode = science["training_score_reuse"]["confirmed"]
    return {
        "science_decision_sha256": science["identity_sha256"],
        "training_score_mode": mode,
        "per_outer_fit_budget": {
            key: count // 6 for key, count in science["fit_budget"]["primary_outer"]["ledger_options"][mode].items()
        },
    }


def _csv_rows(raw: bytes, label: str) -> tuple[list[str], list[dict[str, str]]]:
    try:
        reader = csv.DictReader(io.StringIO(raw.decode("utf-8-sig")))
        rows = list(reader)
    except (UnicodeDecodeError, csv.Error) as exc:
        raise ContractError(f"{label}_CSV_INVALID") from exc
    fields = reader.fieldnames
    _require(
        isinstance(fields, list) and bool(fields)
        and len(fields) == len(set(fields))
        and all(isinstance(x, str) and x for x in fields)
        and all(
            set(row) == set(fields)
            and all(isinstance(row[field], str) for field in fields)
            for row in rows
        ),
        f"{label}_CSV_INVALID",
    )
    return fields, rows


def _response_contract(raw: bytes, label: str) -> tuple[list[str], int]:
    fields, rows = _csv_rows(raw, label)
    _require(
        fields == ["Patient_ID", "All_Cause_Death", "Death_Followup_months"]
        and bool(rows),
        f"{label}_RESPONSE_SCHEMA_INVALID",
    )
    ids = [row["Patient_ID"] for row in rows]
    _require(len(ids) == len(set(ids)) and all(ids), f"{label}_RESPONSE_ID_INVALID")
    event_count = 0
    for row in rows:
        try:
            event = int(row["All_Cause_Death"])
            followup = float(row["Death_Followup_months"])
        except ValueError as exc:
            raise ContractError(f"{label}_RESPONSE_VALUE_INVALID") from exc
        _require(event in {0, 1} and math.isfinite(followup) and followup > 0,
                 f"{label}_RESPONSE_VALUE_INVALID")
        event_count += event
    return ids, event_count


def _response_ids(raw: bytes, label: str) -> list[str]:
    return _response_contract(raw, label)[0]


def compile_training_context(
    *,
    scope: str,
    outer_fold: int,
    heldout_center: int | None,
    training_ids: list[str],
    heldout_ids: list[str],
    centers_by_patient: Mapping[str, str],
    training_response_csv: bytes,
    mice_member_set_sha256: str,
    preprocessing_program_sha256: str,
    modeling_program_sha256: str,
    seed_program_sha256: str,
    channel: str = "PRIMARY",
) -> dict[str, Any]:
    """Bind every development input while accepting no held-out response."""
    response_ids, training_event_count = _response_contract(
        training_response_csv, "NESTED_TRAINING"
    )
    for name, digest in (
        ("mice", mice_member_set_sha256),
        ("preprocessing", preprocessing_program_sha256),
        ("modeling", modeling_program_sha256),
        ("seed", seed_program_sha256),
    ):
        validate_sha256(digest, f"nested.context.{name}")
    _require(
        scope in {"OUTER", "FULL_DATA"}
        and channel in {"PRIMARY", *AAR_ESTIMANDS}
        and isinstance(training_ids, list) and bool(training_ids)
        and len(training_ids) == len(set(training_ids))
        and isinstance(heldout_ids, list) and len(heldout_ids) == len(set(heldout_ids))
        and set(training_ids).isdisjoint(heldout_ids)
        and set(centers_by_patient) == set(training_ids) | set(heldout_ids)
        and response_ids == training_ids
        and training_event_count > 0,
        "NESTED_TRAINING_CONTEXT_INVALID",
    )
    if scope == "OUTER":
        _require(
            outer_fold in range(1, 7)
            and heldout_center == OUTER_CENTERS[outer_fold - 1]
            and bool(heldout_ids)
            and all(centers_by_patient[patient] == str(heldout_center) for patient in heldout_ids)
            and all(centers_by_patient[patient] != str(heldout_center) for patient in training_ids)
            and all(centers_by_patient[patient] != str(TRAINING_ONLY_CENTER) for patient in heldout_ids),
            "NESTED_OUTER_CONTEXT_ISOLATION_INVALID",
        )
    else:
        _require(outer_fold == 0 and heldout_center is None and heldout_ids == [],
                 "NESTED_FULL_CONTEXT_INVALID")
    body = {
        "schema_version": SCHEMA_VERSION,
        "kind": "PADML_NESTED_LOCO_TRAINING_CONTEXT_V1",
        "program_id": PROGRAM_ID,
        "scope": scope,
        "channel": channel,
        "outer_fold": outer_fold,
        "heldout_center": heldout_center,
        "training_ids": training_ids,
        "training_ids_sha256": _sha(training_ids),
        "heldout_ids": heldout_ids,
        "heldout_ids_sha256": _sha(heldout_ids),
        "centers_by_patient": dict(centers_by_patient),
        "center_binding_sha256": _sha(dict(centers_by_patient)),
        "training_response_sha256": sha256_bytes(training_response_csv),
        "training_response_size_bytes": len(training_response_csv),
        "training_event_count": training_event_count,
        "heldout_response_member_count": 0,
        "mice_member_set_sha256": mice_member_set_sha256,
        "preprocessing_program_sha256": preprocessing_program_sha256,
        "modeling_program_sha256": modeling_program_sha256,
        "seed_program_sha256": seed_program_sha256,
    }
    return _sealed(body)


_CONTEXT_FIELDS = {
    "schema_version", "kind", "program_id", "scope", "channel", "outer_fold",
    "heldout_center", "training_ids", "training_ids_sha256", "heldout_ids",
    "heldout_ids_sha256", "centers_by_patient", "center_binding_sha256",
    "training_response_sha256",
    "training_response_size_bytes", "training_event_count",
    "heldout_response_member_count",
    "mice_member_set_sha256", "preprocessing_program_sha256",
    "modeling_program_sha256", "seed_program_sha256",
}


def validate_training_context(value: Any, training_response_csv: bytes | None = None) -> dict[str, Any]:
    row = _validate_seal(value, _CONTEXT_FIELDS, "NESTED_TRAINING_CONTEXT_INVALID")
    training_ids, heldout_ids = row.get("training_ids"), row.get("heldout_ids")
    centers = row.get("centers_by_patient")
    _require(
        row["schema_version"] == SCHEMA_VERSION
        and row["kind"] == "PADML_NESTED_LOCO_TRAINING_CONTEXT_V1"
        and row["program_id"] == PROGRAM_ID
        and row["scope"] in {"OUTER", "FULL_DATA"}
        and row["channel"] in {"PRIMARY", *AAR_ESTIMANDS}
        and row["heldout_response_member_count"] == 0
        and isinstance(training_ids, list) and bool(training_ids)
        and len(training_ids) == len(set(training_ids))
        and all(isinstance(patient, str) and bool(patient) for patient in training_ids)
        and isinstance(heldout_ids, list) and len(heldout_ids) == len(set(heldout_ids))
        and all(isinstance(patient, str) and bool(patient) for patient in heldout_ids)
        and set(training_ids).isdisjoint(heldout_ids)
        and isinstance(centers, Mapping)
        and set(centers) == set(training_ids) | set(heldout_ids)
        and all(value in {str(center) for center in (*OUTER_CENTERS, TRAINING_ONLY_CENTER)}
                for value in centers.values())
        and row["training_ids_sha256"] == _sha(training_ids)
        and row["heldout_ids_sha256"] == _sha(heldout_ids)
        and row["center_binding_sha256"] == _sha(dict(centers))
        and type(row["training_response_size_bytes"]) is int
        and row["training_response_size_bytes"] > 0
        and type(row["training_event_count"]) is int
        and row["training_event_count"] > 0,
        "NESTED_TRAINING_CONTEXT_INVALID",
    )
    if row["scope"] == "OUTER":
        _require(
            type(row["outer_fold"]) is int and row["outer_fold"] in range(1, 7)
            and row["heldout_center"] == OUTER_CENTERS[row["outer_fold"] - 1]
            and bool(heldout_ids)
            and all(centers[patient] == str(row["heldout_center"])
                    for patient in heldout_ids)
            and all(centers[patient] != str(row["heldout_center"])
                    for patient in training_ids)
            and all(centers[patient] != str(TRAINING_ONLY_CENTER)
                    for patient in heldout_ids),
            "NESTED_OUTER_CONTEXT_ISOLATION_INVALID",
        )
    else:
        _require(
            row["outer_fold"] == 0 and row["heldout_center"] is None
            and heldout_ids == [],
            "NESTED_FULL_CONTEXT_INVALID",
        )
    for field in (
        "center_binding_sha256", "training_response_sha256", "mice_member_set_sha256",
        "preprocessing_program_sha256", "modeling_program_sha256", "seed_program_sha256",
    ):
        validate_sha256(row[field], f"nested.context.{field}")
    if training_response_csv is not None:
        response_ids, event_count = _response_contract(
            training_response_csv, "NESTED_TRAINING"
        )
        _require(
            len(training_response_csv) == row["training_response_size_bytes"]
            and sha256_bytes(training_response_csv) == row["training_response_sha256"]
            and response_ids == row["training_ids"]
            and event_count == row["training_event_count"],
            "NESTED_TRAINING_RESPONSE_DRIFT",
        )
    return row


_SCORE_FIELDS = {
    "schema_version", "kind", "status", "program_id", "outer_fold",
    "heldout_center", "training_context_sha256", "family", "source_kind",
    "source_result_sha256", "source_value_sha256", "selected_spec",
    "selected_spec_sha256", "selector_evidence_sha256", "ranking_metric_values",
    "fold_metric_values", "metric_values", "ranking_metric_qc",
    "ranking_evaluation_count",
    "evaluation_units", "imputation_count", "mean_ibs", "maximum_ibs",
    "heldout_metric_fields_in_projection", "heldout_outcome_read_count",
}


def validate_training_score(value: Any) -> dict[str, Any]:
    row = _validate_seal(value, _SCORE_FIELDS | {
        "selection_horizon_months", "science_decision_sha256"},
        "NESTED_TRAINING_SCORE_INVALID")
    selection_horizon(row["selection_horizon_months"])
    _require(science_identity_matches(row["science_decision_sha256"], row["selection_horizon_months"]),
             "NESTED_SELECTION_POPULATION_SCIENCE_DRIFT")
    validate_sha256(row["science_decision_sha256"], "nested.score.science_decision")
    ranking, folds, metrics = (
        row.get("ranking_metric_values"), row.get("fold_metric_values"), row.get("metric_values")
    )
    ranking_qc = row.get("ranking_metric_qc")
    _require(
        row["schema_version"] == SCHEMA_VERSION
        and row["kind"] == "PADML_NESTED_LOCO_TRAINING_SCORE_V1"
        and row["status"] == "PASS"
        and row["program_id"] == PROGRAM_ID
        and type(row["outer_fold"]) is int and row["outer_fold"] in range(0, 7)
        and row["heldout_center"] == (
            None if row["outer_fold"] == 0 else OUTER_CENTERS[row["outer_fold"] - 1]
        )
        and row["family"] in _families()
        and row["source_kind"] in {
            "ACCEPTED_F2_TRAINING_ONLY_SCORE_PROJECTION",
            "FRESH_M20_INNER_OOF",
            "FRESH_FULL_DATA_M20_INNER_OOF",
        }
        and (
            (row["source_kind"] == "ACCEPTED_F2_TRAINING_ONLY_SCORE_PROJECTION"
             and row["family"] in REUSED_SCORE_FAMILIES and row["outer_fold"] in range(1, 7))
            or (row["source_kind"] == "FRESH_M20_INNER_OOF"
                and row["family"] in _families() and row["outer_fold"] in range(1, 7))
            or (row["source_kind"] == "FRESH_FULL_DATA_M20_INNER_OOF" and row["outer_fold"] == 0)
        )
        and isinstance(ranking, list) and len(ranking) == REPEAT_COUNT
        and isinstance(folds, list) and len(folds) == REPEAT_COUNT * INNER_FOLD_COUNT
        and isinstance(metrics, list) and len(metrics) == REPEAT_COUNT * INNER_FOLD_COUNT * M
        and isinstance(ranking_qc, list) and len(ranking_qc) == REPEAT_COUNT
        and all(isinstance(item, Mapping) and bool(item) for item in ranking_qc)
        and all(_finite(number) and float(number) >= 0 for number in [*ranking, *folds, *metrics])
        and row["ranking_evaluation_count"] == REPEAT_COUNT
        and row["evaluation_units"] == REPEAT_COUNT * INNER_FOLD_COUNT * M
        and row["imputation_count"] == M
        and _finite(row["mean_ibs"]) and _finite(row["maximum_ibs"])
        and math.isclose(float(row["mean_ibs"]), math.fsum(float(x) for x in ranking) / REPEAT_COUNT,
                         rel_tol=0, abs_tol=1e-15)
        and float(row["maximum_ibs"]) == max(float(x) for x in ranking)
        and row["selected_spec_sha256"] == _sha(row["selected_spec"])
        and row["heldout_metric_fields_in_projection"] == []
        and row["heldout_outcome_read_count"] == 0,
        "NESTED_TRAINING_SCORE_INVALID",
    )
    for field in (
        "training_context_sha256", "source_result_sha256", "source_value_sha256",
        "selected_spec_sha256", "selector_evidence_sha256",
    ):
        validate_sha256(row[field], f"nested.score.{field}")
    return row


def project_accepted_training_score(
    model: Mapping[str, Any], *, source_result_sha256: str,
    training_context_sha256: str,
) -> dict[str, Any]:
    """Project only the common training score; outer metrics cannot enter."""
    validate_sha256(source_result_sha256, "nested.score.source_result")
    validate_sha256(training_context_sha256, "nested.score.context")
    family = model.get("family")
    _require(
        isinstance(model, Mapping) and model.get("status") == "PASS"
        and family in REUSED_SCORE_FAMILIES
        and type(model.get("fold")) is int and model["fold"] in range(1, 7)
        and model.get("heldout_center") == OUTER_CENTERS[model["fold"] - 1]
        and model.get("selected_spec_sha256") == _sha(model.get("selected_spec")),
        "NESTED_ACCEPTED_SCORE_SOURCE_INVALID",
    )
    trace_name = "FORMAL_CONFIRMATION" if family == "COX_PH" else "S3B2"
    trace = model.get("search_trace")
    rows = trace.get(trace_name) if isinstance(trace, Mapping) else None
    _require(isinstance(rows, list) and len(rows) == 1 and isinstance(rows[0], Mapping),
             "NESTED_ACCEPTED_SCORE_TRACE_INVALID")
    summary = rows[0]
    selector_sha = model.get("selector_evidence_sha256")
    _require(isinstance(selector_sha, str), "NESTED_ACCEPTED_SCORE_SELECTOR_INVALID")
    permitted_source_projection = {
        "family": family,
        "outer_fold": model["fold"],
        "heldout_center": model["heldout_center"],
        "selected_spec": dict(model["selected_spec"]),
        "selected_spec_sha256": model["selected_spec_sha256"],
        "selector_evidence_sha256": selector_sha,
        "trace_name": trace_name,
        "training_summary": dict(summary),
    }
    body = {
        "schema_version": SCHEMA_VERSION,
        "kind": "PADML_NESTED_LOCO_TRAINING_SCORE_V1",
        "status": "PASS",
        "selection_horizon_months": 24,
        "science_decision_sha256": science_decision_template(24)["identity_sha256"],
        "program_id": PROGRAM_ID,
        "outer_fold": model["fold"],
        "heldout_center": OUTER_CENTERS[model["fold"] - 1],
        "training_context_sha256": training_context_sha256,
        "family": family,
        "source_kind": "ACCEPTED_F2_TRAINING_ONLY_SCORE_PROJECTION",
        "source_result_sha256": source_result_sha256,
        # Bind the exact allow-listed projection.  The complete accepted
        # archive remains independently bound by source_result_sha256; hashing
        # the whole model here would make this training-only score depend on
        # forbidden outer-outcome fields that are intentionally not consumed.
        "source_value_sha256": _sha(permitted_source_projection),
        "selected_spec": dict(model["selected_spec"]),
        "selected_spec_sha256": model["selected_spec_sha256"],
        "selector_evidence_sha256": selector_sha,
        "ranking_metric_values": list(summary.get("ranking_metric_values", [])),
        "fold_metric_values": list(summary.get("fold_metric_values", [])),
        "metric_values": list(summary.get("metric_values", [])),
        "ranking_metric_qc": list(summary.get("ranking_metric_qc", [])),
        "ranking_evaluation_count": summary.get("ranking_evaluation_count"),
        "evaluation_units": summary.get("evaluation_units"),
        "imputation_count": M,
        "mean_ibs": summary.get("mean_ibs"),
        "maximum_ibs": summary.get("maximum_ibs"),
        "heldout_metric_fields_in_projection": [],
        "heldout_outcome_read_count": 0,
    }
    return validate_training_score(_sealed(body))


def seal_fresh_training_score(
    *, family: str, outer_fold: int, training_context_sha256: str,
    selected_spec: Mapping[str, Any], selector_evidence_sha256: str,
    summary: Mapping[str, Any], execution_evidence_sha256: str,
    source_kind: str = "FRESH_M20_INNER_OOF",
    selection_horizon_months: int = 24, science_decision_sha256: str | None = None,
) -> dict[str, Any]:
    selection_horizon(selection_horizon_months)
    _require(summary.get("selection_horizon_months", 24) == selection_horizon_months,
             "NESTED_TRAINING_SCORE_SELECTION_SCOPE_INVALID")
    if science_decision_sha256 is None:
        science_decision_sha256 = science_decision_template(selection_horizon_months)["identity_sha256"]
    validate_sha256(science_decision_sha256, "nested.score.science_decision")
    _require(type(outer_fold) is int and (
        source_kind == "FRESH_M20_INNER_OOF" and outer_fold in range(1, 7) and family in _families()
        or source_kind == "FRESH_FULL_DATA_M20_INNER_OOF" and outer_fold == 0 and family in _families()
    ), "NESTED_FRESH_SCORE_FAMILY_INVALID")
    for name, digest in (
        ("context", training_context_sha256), ("selector", selector_evidence_sha256),
        ("execution", execution_evidence_sha256),
    ):
        validate_sha256(digest, f"nested.fresh_score.{name}")
    body = {
        "schema_version": SCHEMA_VERSION,
        "kind": "PADML_NESTED_LOCO_TRAINING_SCORE_V1",
        "status": "PASS",
        "program_id": PROGRAM_ID,
        "outer_fold": outer_fold,
        "heldout_center": None if outer_fold == 0 else OUTER_CENTERS[outer_fold - 1],
        "training_context_sha256": training_context_sha256,
        "family": family,
        "source_kind": source_kind,
        "selection_horizon_months": selection_horizon_months,
        "science_decision_sha256": science_decision_sha256,
        "source_result_sha256": execution_evidence_sha256,
        "source_value_sha256": _sha(dict(summary)),
        "selected_spec": dict(selected_spec),
        "selected_spec_sha256": _sha(dict(selected_spec)),
        "selector_evidence_sha256": selector_evidence_sha256,
        "ranking_metric_values": list(summary.get("ranking_metric_values", [])),
        "fold_metric_values": list(summary.get("fold_metric_values", [])),
        "metric_values": list(summary.get("metric_values", [])),
        "ranking_metric_qc": list(summary.get("ranking_metric_qc", [])),
        "ranking_evaluation_count": summary.get("ranking_evaluation_count"),
        "evaluation_units": summary.get("evaluation_units"),
        "imputation_count": M,
        "mean_ibs": summary.get("mean_ibs"),
        "maximum_ibs": summary.get("maximum_ibs"),
        "heldout_metric_fields_in_projection": [],
        "heldout_outcome_read_count": 0,
    }
    return validate_training_score(_sealed(body))


def _rank_training_families(evidence: Sequence[Mapping[str, Any]]) -> tuple[Mapping[str, Any], list[dict[str, Any]]]:
    """The same numerical ranking for development and fixed-OOF resampling.

    Resampling uses this pure arithmetic, never a fabricated LOCKABLE score.
    """
    from .f4 import FAMILY_COMPLEXITY, FAMILY_INTERPRETABILITY
    families = _families()
    by_family = {row["family"]: row for row in evidence}
    _require(len(evidence) == len(by_family) == len(families)
             and set(by_family) == set(families)
             and all(type(row[key]) in {int, float} and math.isfinite(row[key]) and row[key] >= 0
                     for row in evidence for key in ("mean_ibs", "maximum_ibs")),
             "NESTED_FAMILY_RANKING_INVALID")
    evidence = [by_family[family] for family in families]
    minimum = min(float(row["mean_ibs"]) for row in evidence)
    current = [row for row in evidence
               if float(row["mean_ibs"]) <= minimum + NEAR_OPTIMAL_MARGIN]
    layers: list[dict[str, Any]] = [{
        "criterion": "MEAN_IBS_NEAR_OPTIMAL_INCLUSIVE",
        "direction": "LOWER_WITHIN_0.002",
        "before": list(families),
        "after": [row["family"] for row in current],
        "values": {row["family"]: row["mean_ibs"] for row in evidence},
    }]
    criteria = (
        ("MAXIMUM_REPEAT_IBS", "LOWER"),
        ("FIXED_COMPLEXITY", "LOWER"),
        ("FIXED_INTERPRETABILITY", "HIGHER"),
        ("CANONICAL_FAMILY_ORDER", "LOWER"),
    )
    order = {family: index for index, family in enumerate(families)}
    for criterion, direction in criteria:
        before = current.copy()
        if criterion == "MAXIMUM_REPEAT_IBS":
            values = {row["family"]: float(row["maximum_ibs"]) for row in before}
        elif criterion == "FIXED_COMPLEXITY":
            values = {row["family"]: FAMILY_COMPLEXITY[row["family"]] for row in before}
        elif criterion == "FIXED_INTERPRETABILITY":
            values = {row["family"]: FAMILY_INTERPRETABILITY[row["family"]] for row in before}
        else:
            values = {row["family"]: order[row["family"]] for row in before}
        if len(before) > 1:
            best = max(values.values()) if direction == "HIGHER" else min(values.values())
            current = [row for row in before if values[row["family"]] == best]
        layers.append({
            "criterion": criterion,
            "direction": f"{direction}_IS_BETTER" if criterion != "CANONICAL_FAMILY_ORDER"
            else "CANONICAL_FIRST",
            "before": [row["family"] for row in before],
            "after": [row["family"] for row in current],
            "values": values,
        })
    _require(len(current) == 1, "NESTED_FAMILY_SELECTION_NOT_UNIQUE")
    return current[0], layers


def select_training_family(scores: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
    """Select independently inside one training scope; input order is irrelevant."""
    from .f4 import FAMILY_COMPLEXITY, FAMILY_INTERPRETABILITY

    admitted = [validate_training_score(value) for value in scores]
    by_family = {row["family"]: row for row in admitted}
    families = _families()
    _require(
        len(admitted) == len(by_family) == len(families)
        and set(by_family) == set(families)
        and len({row["training_context_sha256"] for row in admitted}) == 1
        and len({row["outer_fold"] for row in admitted}) == 1
        and len({row["heldout_center"] for row in admitted}) == 1
        and len({row["selector_evidence_sha256"] for row in admitted}) == 1
        and len({(row.get("selection_horizon_months", 24), row.get("science_decision_sha256"))
                 for row in admitted}) == 1,
        "NESTED_FAMILY_SELECTION_INPUT_INVALID",
    )
    evidence = [by_family[family] for family in families]
    selected, layers = _rank_training_families(evidence)
    body = {
        "schema_version": SCHEMA_VERSION,
        "kind": "PADML_NESTED_LOCO_FAMILY_DECISION_V1",
        "status": "LOCKABLE",
        "program_id": PROGRAM_ID,
        "classification": "POST_RESULT_PROSPECTIVE_NOT_RESULT_BLIND",
        "outer_fold": selected["outer_fold"],
        "heldout_center": selected["heldout_center"],
        "training_context_sha256": selected["training_context_sha256"],
        "rule": family_selection_rule(selected["selection_horizon_months"]),
        "selection_horizon_months": selected["selection_horizon_months"],
        "science_decision_sha256": selected["science_decision_sha256"],
        "score_identity_by_family": {
            family: by_family[family]["identity_sha256"] for family in families
        },
        "near_optimal_families": layers[0]["after"],
        "selected_family": selected["family"],
        "selected_spec": selected["selected_spec"],
        "selected_spec_sha256": selected["selected_spec_sha256"],
        "selector_evidence_sha256": selected["selector_evidence_sha256"],
        "layers": layers,
        "heldout_outcome_read_count": 0,
    }
    return _sealed(body)


_DECISION_TRACE_FIELDS = {
    "schema_version", "kind", "status", "program_id", "classification",
    "outer_fold", "heldout_center", "training_context_sha256", "rule",
    "score_identity_by_family", "near_optimal_families", "selected_family",
    "selected_spec", "selected_spec_sha256", "selector_evidence_sha256",
    "layers", "heldout_outcome_read_count",
}


def validate_family_decision(value: Any, scores: Sequence[Mapping[str, Any]] | None = None) -> dict[str, Any]:
    row = _validate_seal(value, _DECISION_TRACE_FIELDS | {
        "selection_horizon_months", "science_decision_sha256"},
        "NESTED_FAMILY_DECISION_INVALID")
    selection_horizon(row["selection_horizon_months"])
    _require(science_identity_matches(row["science_decision_sha256"], row["selection_horizon_months"]),
             "NESTED_SELECTION_POPULATION_SCIENCE_DRIFT")
    validate_sha256(row["science_decision_sha256"], "nested.family.science_decision")
    _require(
        row["kind"] == "PADML_NESTED_LOCO_FAMILY_DECISION_V1"
        and row["status"] == "LOCKABLE"
        and row["program_id"] == PROGRAM_ID
        and row["classification"] == "POST_RESULT_PROSPECTIVE_NOT_RESULT_BLIND"
        and row["rule"] == family_selection_rule(row["selection_horizon_months"])
        and row["selected_family"] in _families()
        and row["selected_spec_sha256"] == _sha(row["selected_spec"])
        and row["heldout_outcome_read_count"] == 0,
        "NESTED_FAMILY_DECISION_INVALID",
    )
    if scores is not None:
        _require(row == select_training_family(scores), "NESTED_FAMILY_DECISION_REPLAY_MISMATCH")
    return row


_LOCK_FIELDS = {
    "schema_version", "kind", "status", "program_id", "outer_fold",
    "heldout_center", "training_context_sha256", "training_ids_sha256",
    "heldout_ids_sha256", "family_decision_sha256",
    "score_identity_by_family", "selected_family", "selected_spec",
    "selected_spec_sha256", "selector_evidence_sha256", "selected_parents",
    "selected_parents_sha256", "common_set_design_df", "training_event_count",
    "common_set_epv", "parameters_by_imputation", "mice_member_set_sha256",
    "recipe_sha256_by_imputation", "baseline_policy_sha256",
    "seed_policy_sha256", "post_lock_template_sha256_by_imputation",
    "post_lock_template_archive_sha256_by_imputation",
    "post_lock_model_fit_budget", "heldout_outcome_read_count",
    "family_selection_may_differ_by_outer", "writeback",
}


def validate_epv_resolution(value: Any) -> dict[str, Any]:
    _require(isinstance(value, Mapping) and value.get("preferred_minimum") == 15
             and type(value.get("minimum")) is int and value["minimum"] in (15, 10)
             and value.get("fallback_used") is (value["minimum"] == 10),
             "NESTED_SELECTOR_EPV_RESOLUTION_INVALID")
    row = dict(value)
    if "frequency_policy_sha256" in row:
        policy = selector_frequency_policy()
        _require(row["frequency_policy_sha256"] == policy["identity_sha256"]
                 and row.get("source") is None, "NESTED_SELECTOR_FREQUENCY_POLICY_INVALID")
        validate_sha256(row.get("coarse_records_sha256"), "nested.epv.coarse_paths")
        attempts = row.get("attempts")
        terminal = row.get("status") == "NOT_ESTIMABLE"
        _require(isinstance(attempts, list) and 1 <= len(attempts) <= 6
                 and [{k: attempt.get(k) for k in ("minimum", "frequency_threshold")} for attempt in attempts]
                     == policy["ladder"][:len(attempts)]
                 and row["minimum"] == attempts[-1]["minimum"]
                 and type(row.get("frequency_threshold")) is int
                 and row["frequency_threshold"] == attempts[-1]["frequency_threshold"]
                 and (not terminal or len(attempts) == 6 and row.get("reason_code") == "FREQUENCY_LADDER_EXHAUSTED"),
                 "NESTED_SELECTOR_FREQUENCY_TRACE_INVALID")
        coarse = load_science_authority()["science"]["f2_model_development"]["selector_contract"]["alpha_grid"]["coarse"]
        for index, attempt in enumerate(attempts):
            summaries = attempt.get("alpha_feasibility")
            _require(isinstance(summaries, list) and [r.get("alpha") for r in summaries] == coarse,
                     "NESTED_SELECTOR_FREQUENCY_TRACE_INVALID")
            for item in summaries:
                _require((item.get("status"), item.get("reason_code")) in {
                    ("FEASIBLE", "OK"), ("EPV_INFEASIBLE", "IMPUTATION_HAS_NO_EPV_FEASIBLE_RATIO"),
                    ("EPV_INFEASIBLE", "COMMON_SETA_EPV_BELOW_MINIMUM"),
                    ("NOT_ESTIMABLE", "EMPTY_FREQUENCY_AGGREGATE")},
                    "NESTED_SELECTOR_FREQUENCY_TRACE_INVALID")
                if item["reason_code"] != "IMPUTATION_HAS_NO_EPV_FEASIBLE_RATIO":
                    df, epv = item.get("common_set_design_df"), item.get("common_set_epv")
                    _require(type(df) is int and df >= 0
                        and ((df == 0 and epv is None and item["reason_code"] == "EMPTY_FREQUENCY_AGGREGATE")
                            or df > 0 and _finite(epv) and epv > 0
                            and ((epv >= attempt["minimum"]) == (item["status"] == "FEASIBLE"))),
                        "NESTED_SELECTOR_FREQUENCY_TRACE_INVALID")
            any_feasible = any(item["status"] == "FEASIBLE" for item in summaries)
            _require(any_feasible is (index == len(attempts) - 1 and not terminal),
                     "NESTED_SELECTOR_FREQUENCY_FALLBACK_NOT_NECESSARY")
        return row
    if row.get("source") == "ACCEPTED_F2_SELECTOR":
        _require(row["minimum"] == 15, "NESTED_F2_EPV_AUTHORITY_DRIFT")
        validate_sha256(row.get("selector_evidence_sha256"), "nested.epv.f2_selector")
    elif row.get("source") == "FIXED_PRIMARY_NON_AAR_SETA":
        validate_sha256(row.get("primary_development_lock_sha256"), "nested.epv.primary_lock")
        events, df = row.get("training_event_count"), row.get("common_set_design_df")
        _require(type(events) is int and events > 0 and type(df) is int and df > 0
            and events >= 10 * df, "NESTED_SELECTOR_EPV_BELOW_10")
        expected = 15 if events >= 15 * df else 10
        _require(row["minimum"] == expected
            and row.get("reason_code") == ("OK" if expected == 15 else "FIXED_SETA_EPV_BELOW_15")
            and _finite(row.get("common_set_epv"))
            and math.isclose(row["common_set_epv"], events / df, rel_tol=0, abs_tol=1e-12),
            "NESTED_SELECTOR_EPV_RESOLUTION_INVALID")
    else:
        validate_sha256(row.get("coarse_records_sha256"), "nested.epv.coarse_paths")
        attempts = row.get("attempts")
        _require(isinstance(attempts, list)
                 and [attempt.get("minimum") for attempt in attempts]
                     == ([15] if row["minimum"] == 15 else [15, 10]),
                 "NESTED_SELECTOR_EPV_RESOLUTION_INVALID")
        coarse = load_science_authority()["science"]["f2_model_development"]["selector_contract"]["alpha_grid"]["coarse"]
        for attempt in attempts:
            summaries = attempt.get("alpha_feasibility")
            _require(isinstance(summaries, list)
                     and [r.get("alpha") for r in summaries] == coarse
                     and all(r.get("status") == "FEASIBLE" or (
                         r.get("status") == "EPV_INFEASIBLE" and r.get("reason_code") in {
                             "IMPUTATION_HAS_NO_EPV_FEASIBLE_RATIO", "COMMON_SETA_EPV_BELOW_MINIMUM"})
                         for r in summaries), "NESTED_SELECTOR_EPV_RESOLUTION_INVALID")
        if row["fallback_used"]:
            _require(all(r["status"] == "EPV_INFEASIBLE" for r in attempts[0]["alpha_feasibility"]),
                     "NESTED_SELECTOR_EPV_FALLBACK_NOT_NECESSARY")
        _require(any(r["status"] == "FEASIBLE" for r in attempts[-1]["alpha_feasibility"]),
                 "NESTED_SELECTOR_EPV_BELOW_10")
    return row


def seal_development_lock(
    *, context: Mapping[str, Any], decision: Mapping[str, Any],
    selected_parents: list[str], common_set_design_df: int,
    training_event_count: int, parameters_by_imputation: list[Mapping[str, Any]],
    recipe_sha256_by_imputation: list[str], baseline_policy_sha256: str,
    seed_policy_sha256: str, post_lock_template_sha256_by_imputation: list[str],
    post_lock_template_archive_sha256_by_imputation: list[str],
    science_decision: Mapping[str, Any] | None = None,
    epv_resolution: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    context = validate_training_context(context)
    decision = validate_family_decision(decision)
    horizon = selection_horizon(decision["selection_horizon_months"])
    science_decision = validate_science_decision(
        science_decision if science_decision is not None else science_decision_template(horizon), selection_horizon_months=horizon)
    _require(decision["science_decision_sha256"] == science_decision["identity_sha256"],
             "NESTED_DEVELOPMENT_LOCK_SCIENCE_DECISION_MISMATCH")
    if epv_resolution is None:
        _require(context["scope"] == "OUTER", "NESTED_SELECTOR_EPV_RESOLUTION_REQUIRED")
        epv_resolution = {
            "preferred_minimum": 15, "minimum": 15, "fallback_used": False,
            "source": "ACCEPTED_F2_SELECTOR",
            "selector_evidence_sha256": decision["selector_evidence_sha256"]}
    epv_resolution = validate_epv_resolution(epv_resolution)
    _require(
        decision["training_context_sha256"] == context["identity_sha256"]
        and decision["outer_fold"] == context["outer_fold"]
        and decision["heldout_center"] == context["heldout_center"]
        and isinstance(selected_parents, list) and bool(selected_parents)
        and len(selected_parents) == len(set(selected_parents))
        and type(common_set_design_df) is int and common_set_design_df > 0
        and training_event_count == context["training_event_count"]
        and training_event_count / common_set_design_df >= epv_resolution["minimum"]
        and len(parameters_by_imputation) == len(recipe_sha256_by_imputation)
        == len(post_lock_template_sha256_by_imputation)
        == len(post_lock_template_archive_sha256_by_imputation) == M
        and all(isinstance(value, Mapping) and bool(value) for value in parameters_by_imputation),
        "NESTED_DEVELOPMENT_LOCK_INPUT_INVALID",
    )
    for digest in [baseline_policy_sha256, seed_policy_sha256,
                   *recipe_sha256_by_imputation, *post_lock_template_sha256_by_imputation,
                   *post_lock_template_archive_sha256_by_imputation]:
        validate_sha256(digest, "nested.development_lock.binding")
    body = {
        "schema_version": SCHEMA_VERSION,
        "kind": "PADML_NESTED_LOCO_DEVELOPMENT_LOCK_V1",
        "status": "IMMUTABLE_PRE_PREDICTION_LOCK",
        "program_id": PROGRAM_ID,
        "outer_fold": context["outer_fold"],
        "heldout_center": context["heldout_center"],
        "training_context_sha256": context["identity_sha256"],
        "training_ids_sha256": context["training_ids_sha256"],
        "heldout_ids_sha256": context["heldout_ids_sha256"],
        "family_decision_sha256": decision["identity_sha256"],
        "score_identity_by_family": decision["score_identity_by_family"],
        "selected_family": decision["selected_family"],
        "selected_spec": decision["selected_spec"],
        "selected_spec_sha256": decision["selected_spec_sha256"],
        "selector_evidence_sha256": decision["selector_evidence_sha256"],
        "selected_parents": selected_parents,
        "selected_parents_sha256": _sha(selected_parents),
        "common_set_design_df": common_set_design_df,
        "training_event_count": training_event_count,
        "common_set_epv": training_event_count / common_set_design_df,
        "epv_resolution": epv_resolution,
        "epv_band": "10_LE_EPV_LT_15" if training_event_count / common_set_design_df < 15 else "EPV_GE_15",
        "parameters_by_imputation": [dict(value) for value in parameters_by_imputation],
        "mice_member_set_sha256": context["mice_member_set_sha256"],
        "recipe_sha256_by_imputation": recipe_sha256_by_imputation,
        "baseline_policy_sha256": baseline_policy_sha256,
        "seed_policy_sha256": seed_policy_sha256,
        "post_lock_template_sha256_by_imputation": post_lock_template_sha256_by_imputation,
        "post_lock_template_archive_sha256_by_imputation": (
            post_lock_template_archive_sha256_by_imputation
        ),
        "post_lock_model_fit_budget": M,
        "heldout_outcome_read_count": 0,
        "family_selection_may_differ_by_outer": True,
        "writeback": "FORBIDDEN",
    }
    body["selection_horizon_months"] = horizon
    body["science_decision_binding"] = {
        "science_decision_sha256": science_decision["identity_sha256"],
        "selection_horizon_months": horizon,
    }
    return validate_development_lock(_sealed(body), context=context, decision=decision,
                                     science_decision=science_decision)


def validate_development_lock(
    value: Any, *, context: Mapping[str, Any] | None = None,
    decision: Mapping[str, Any] | None = None,
    science_decision: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    row = _validate_seal(value, _LOCK_FIELDS | {
        "science_decision_binding", "selection_horizon_months", "epv_resolution", "epv_band"},
        "NESTED_DEVELOPMENT_LOCK_INVALID")
    horizon = selection_horizon(row["selection_horizon_months"])
    binding = row["science_decision_binding"]
    _require(isinstance(binding, Mapping) and set(binding) == {
        "science_decision_sha256", "selection_horizon_months"}
        and binding["selection_horizon_months"] == horizon,
        "NESTED_DEVELOPMENT_LOCK_SCIENCE_DECISION_MISMATCH")
    validate_sha256(binding["science_decision_sha256"], "nested.lock.science_decision")
    _require(science_identity_matches(binding["science_decision_sha256"], horizon),
             "NESTED_SELECTION_POPULATION_SCIENCE_DRIFT")
    epv = validate_epv_resolution(row["epv_resolution"])
    _require(epv.get("status") != "NOT_ESTIMABLE",
             "NESTED_SELECTOR_NOT_ESTIMABLE_NO_DEVELOPMENT_LOCK")
    # The old science can carry only the unchanged successful 12/20 prefix.
    # A current declaration may reuse that exact prefix without relabeling it.
    _require(binding["science_decision_sha256"] != _base_science_decision_template(horizon)["identity_sha256"]
             or epv.get("frequency_threshold", 12) == 12,
             "NESTED_BASE_SCIENCE_FREQUENCY_POLICY_DRIFT")
    if science_decision is not None:
        science = validate_science_decision(science_decision)
        _require(binding["science_decision_sha256"] == science["identity_sha256"],
                 "NESTED_DEVELOPMENT_LOCK_SCIENCE_DECISION_MISMATCH")
    _require(
        row["schema_version"] == SCHEMA_VERSION
        and row["kind"] == "PADML_NESTED_LOCO_DEVELOPMENT_LOCK_V1"
        and row["status"] == "IMMUTABLE_PRE_PREDICTION_LOCK"
        and row["program_id"] == PROGRAM_ID
        and row["selected_family"] in _families()
        and row["selected_spec_sha256"] == _sha(row["selected_spec"])
        and row["selected_parents_sha256"] == _sha(row["selected_parents"])
        and type(row["common_set_design_df"]) is int
        and row["common_set_design_df"] > 0
        and type(row["training_event_count"]) is int
        and row["training_event_count"] > 0
        and row["training_event_count"] / row["common_set_design_df"] >= epv["minimum"]
        and row["epv_band"] == ("10_LE_EPV_LT_15" if row["common_set_epv"] < 15 else "EPV_GE_15")
        and math.isclose(row["common_set_epv"],
                         row["training_event_count"] / row["common_set_design_df"],
                         rel_tol=0, abs_tol=1e-12)
        and len(row["parameters_by_imputation"]) == M
        and len(row["recipe_sha256_by_imputation"]) == M
        and len(row["post_lock_template_sha256_by_imputation"]) == M
        and len(row["post_lock_template_archive_sha256_by_imputation"]) == M
        and row["post_lock_model_fit_budget"] == M
        and row["heldout_outcome_read_count"] == 0
        and row["family_selection_may_differ_by_outer"] is True
        and row["writeback"] == "FORBIDDEN",
        "NESTED_DEVELOPMENT_LOCK_INVALID",
    )
    for digest in (
        row["training_context_sha256"], row["family_decision_sha256"],
        row["training_ids_sha256"], row["heldout_ids_sha256"],
        row["selected_spec_sha256"], row["selector_evidence_sha256"],
        row["selected_parents_sha256"], row["mice_member_set_sha256"],
        row["baseline_policy_sha256"], row["seed_policy_sha256"],
        *row["recipe_sha256_by_imputation"],
        *row["post_lock_template_sha256_by_imputation"],
        *row["post_lock_template_archive_sha256_by_imputation"],
    ):
        validate_sha256(digest, "nested.development_lock.binding")
    if context is not None:
        context = validate_training_context(context)
        _require(
            row["training_context_sha256"] == context["identity_sha256"]
            and row["training_event_count"] == context["training_event_count"],
                 "NESTED_DEVELOPMENT_LOCK_CONTEXT_MISMATCH")
    if decision is not None:
        decision = validate_family_decision(decision)
        _require(row.get("selection_horizon_months", 24) == decision.get("selection_horizon_months", 24)
                 and (row["science_decision_binding"]["science_decision_sha256"]
                      == decision["science_decision_sha256"]),
                 "NESTED_DEVELOPMENT_LOCK_DECISION_MISMATCH")
        _require(
            row["family_decision_sha256"] == decision["identity_sha256"]
            and row["selected_family"] == decision["selected_family"]
            and row["selected_spec_sha256"] == decision["selected_spec_sha256"]
            and row["score_identity_by_family"] == decision["score_identity_by_family"],
            "NESTED_DEVELOPMENT_LOCK_DECISION_MISMATCH",
        )
    return row


def bind_post_lock_task(template: Mapping[str, Any], lock: Mapping[str, Any]) -> dict[str, Any]:
    """Turn a non-executable template into a task only after the lock exists."""
    lock = validate_development_lock(lock)
    _require(
        isinstance(template, Mapping)
        and template.get("family") == lock["selected_family"]
        and type(template.get("imputation")) is int
        and template["imputation"] in range(1, M + 1)
        and template.get("selected_parents") == lock["selected_parents"]
        and _sha(dict(template))
        == lock["post_lock_template_sha256_by_imputation"][template["imputation"] - 1]
        and "development_lock_sha256" not in template,
        "NESTED_POST_LOCK_TEMPLATE_INVALID",
    )
    return {**dict(template), "development_lock_sha256": lock["identity_sha256"]}


_RECEIPT_FIELDS = {
    "imputation", "development_lock_sha256", "training_context_sha256",
    "task_sha256", "input_sha256", "mice_member_sha256",
    "recipe_sha256", "parameter_sha256", "training_ids_sha256",
    "application_ids_sha256", "training_response_sha256", "model_sha256",
    "baseline_sha256", "prediction_sha256", "fit_health_sha256", "model_fit_count",
    "engine_threads", "seed",
}
_SCORE_RECEIPT_FIELDS = _RECEIPT_FIELDS | {
    "component_role", "family", "repeat", "inner_fold", "archive_sha256",
}


def validate_score_component_receipt(
    value: Any, *, context: Mapping[str, Any]
) -> dict[str, Any]:
    context = validate_training_context(context)
    row = _validate_seal(
        value, _SCORE_RECEIPT_FIELDS, "NESTED_SCORE_COMPONENT_RECEIPT_INVALID"
    )
    q_reuse = row["component_role"] == "REUSED_FULL0_RSF_Q_SCORE"
    _require(
        (row["component_role"] == "FRESH_SCORE" or q_reuse
         and context["scope"] == "FULL_DATA" and context["outer_fold"] == 0
         and row["family"] == "RSF" and row["baseline_sha256"] is None)
        and row["family"] in _families() and context["channel"] == "PRIMARY"
        and row["development_lock_sha256"] is None
        and row["training_context_sha256"] == context["identity_sha256"]
        and type(row["repeat"]) is int and row["repeat"] in range(1, REPEAT_COUNT + 1)
        and type(row["inner_fold"]) is int
        and row["inner_fold"] in range(1, INNER_FOLD_COUNT + 1)
        and type(row["imputation"]) is int and row["imputation"] in range(1, M + 1)
        and row["model_fit_count"] == 1
        and row["engine_threads"] == 1
        and type(row["seed"]) is int and row["seed"] > 0,
        "NESTED_SCORE_COMPONENT_RECEIPT_INVALID",
    )
    digest_fields = _SCORE_RECEIPT_FIELDS - {
        "component_role", "family", "repeat", "inner_fold", "imputation",
        "development_lock_sha256", "model_fit_count", "engine_threads", "seed",
    }
    for field in digest_fields:
        if q_reuse and field == "baseline_sha256":
            continue  # ranger retains its baseline inside the original model.rds.
        validate_sha256(row[field], f"nested.score_component.{field}")
    return row


_SCORE_COMPONENT_EVIDENCE_FIELDS = {
    "schema_version", "kind", "status", "program_id", "family", "outer_fold",
    "repeat", "inner_fold", "imputation", "partition_id",
    "request_component_path", "request_component_sha256", "receipt",
    "prediction", "fit_health", "object_audit", "model_binary_retained",
    "baseline_binary_retained", "heldout_outcome_read_count",
}

_RETAINED_SCORE_SOURCE_KINDS = {
    "COX_PH": "PADML_COX_RETAINED_SCORE_SOURCE_V1",
    "RSF": "PADML_RSF_RETAINED_SCORE_SOURCE_V1",
    "GBM_COX": "PADML_GBM_RETAINED_SCORE_SOURCE_V1",
    "XGBOOST_COX": "PADML_XGBOOST_RETAINED_SCORE_SOURCE_V1",
    "COXTIME_SET_A": "PADML_COXTIME_RETAINED_SCORE_SOURCE_V1",
    "FPM_TVC_SET_A": "PADML_FPM_RETAINED_SCORE_SOURCE_V1",
    "ELASTIC_NET_COX": "PADML_ELASTIC_RETAINED_SCORE_SOURCE_V1",
}


def _validate_full0_rsf_q_score_source(source, receipt, context):
    """Truthful Q provenance: no F4 native ZIP or separate baseline binary."""
    import re

    hashes = {"science_decision_sha256", "request_identity_sha256", "input_execution_sha256",
        "q_archive_sha256", "q_source_identity_sha256", "q_manifest_sha256", "q_task_sha256",
        "registered_inputs_identity_sha256", "batch_spec_sha256", "batch_output_sha256",
        "object_audit_sha256"}
    _require(isinstance(source, Mapping) and set(source) == hashes | {
        "kind", "selection_horizon_months", "q_archive_size_bytes", "unit_id", "producer_task", "first_native_audit",
        "historical_model_fit_count", "new_model_fit_count", "new_first_native_audit_count",
        "new_native_replay_count"}
        and source["kind"] == "PADML_FULL0_RSF_Q_SCORE_SOURCE_V1"
        and type(source["selection_horizon_months"]) is int and source["selection_horizon_months"] == 12
        and context["scope"] == "FULL_DATA" and context["outer_fold"] == 0
        and receipt["component_role"] == "REUSED_FULL0_RSF_Q_SCORE" and receipt["family"] == "RSF"
        and source["q_archive_sha256"] == receipt["archive_sha256"]
        and type(source["q_archive_size_bytes"]) is int and source["q_archive_size_bytes"] > 0
        and isinstance(source["unit_id"], str) and re.fullmatch(r"batch-[0-9a-f]{24}", source["unit_id"])
        and isinstance(source["producer_task"], Mapping)
        and source["producer_task"].get("task_id") == (
            f"S3B2_T001_P{5 * (receipt['repeat'] - 1) + receipt['inner_fold']:02d}_M{receipt['imputation']:02d}")
        and type(source["historical_model_fit_count"]) is int and source["historical_model_fit_count"] == 1
        and all(type(source[name]) is int and source[name] == 0 for name in (
            "new_model_fit_count", "new_first_native_audit_count", "new_native_replay_count")),
        "NESTED_FULL0_RSF_Q_SCORE_SOURCE_INVALID")
    for name in hashes:
        validate_sha256(source[name], "nested.full0_rsf_q_score." + name)
    audit = source["first_native_audit"]
    _require(isinstance(audit, Mapping) and set(audit) == {
        "kind", "member", "sha256", "size_bytes", "replay_output_sha256"}
        and audit["kind"] in {"ORIGINAL_BATCH_EXECUTION", "RETAINED_NATIVE_REPLAY"}
        and isinstance(audit["member"], str)
        and type(audit["size_bytes"]) is int and audit["size_bytes"] > 0,
        "NESTED_FULL0_RSF_Q_FIRST_AUDIT_INVALID")
    validate_relative_path(audit["member"], "nested.full0_rsf_q_first_audit.member")
    validate_sha256(audit["sha256"], "nested.full0_rsf_q_first_audit.sha256")
    if audit["kind"] == "RETAINED_NATIVE_REPLAY":
        validate_sha256(audit["replay_output_sha256"], "nested.full0_rsf_q_first_audit.output")
        _require(audit["replay_output_sha256"] == source["batch_output_sha256"],
                 "NESTED_FULL0_RSF_Q_FIRST_AUDIT_INVALID")
    else:
        _require(audit["replay_output_sha256"] is None, "NESTED_FULL0_RSF_Q_FIRST_AUDIT_INVALID")
    return dict(source)


def _validate_score_component_evidence(
    value: Any, *, context: Mapping[str, Any]
) -> dict[str, Any]:
    from .f2_kernel import _seal_prediction_matrix

    context = validate_training_context(context)
    retained = isinstance(value, Mapping) and "retained_model_source" in value
    row = _validate_seal(
        value,
        _SCORE_COMPONENT_EVIDENCE_FIELDS | ({"retained_model_source"} if retained else set()),
        "NESTED_SCORE_COMPONENT_EVIDENCE_INVALID",
    )
    receipt = validate_score_component_receipt(row["receipt"], context=context)
    q_reuse = receipt["component_role"] == "REUSED_FULL0_RSF_Q_SCORE"
    prediction = row.get("prediction")
    _require(
        row["schema_version"] == SCHEMA_VERSION
        and row["kind"] == "PADML_NESTED_LOCO_SCORE_COMPONENT_EVIDENCE_V1"
        and row["status"] == "SEALED_RESPONSE_FREE"
        and row["program_id"] == PROGRAM_ID
        and row["family"] == receipt["family"]
        and row["outer_fold"] == context["outer_fold"]
        and (row["repeat"], row["inner_fold"], row["imputation"])
        == (receipt["repeat"], receipt["inner_fold"], receipt["imputation"])
        and isinstance(row["partition_id"], str) and bool(row["partition_id"])
        and isinstance(row["request_component_path"], str)
        and bool(row["request_component_path"])
        and row["model_binary_retained"] is (not q_reuse)
        and row["baseline_binary_retained"] is (not q_reuse)
        and row["heldout_outcome_read_count"] == 0
        and isinstance(row["fit_health"], Mapping)
        and isinstance(row["object_audit"], Mapping) and bool(row["object_audit"])
        and isinstance(prediction, Mapping)
        and set(prediction) == {
            "f4_coordinates", "patient_ids", "centers", "horizons", "survival",
        }
        and prediction["f4_coordinates"] == {
            "purpose": "NESTED_FULL_SCORE" if context["scope"] == "FULL_DATA" else "O_FIT",
            "outer_fold": context["outer_fold"],
            "repeat": row["repeat"],
            "inner_fold": row["inner_fold"],
            "imputation": row["imputation"],
        }
        and prediction["horizons"] == list(HORIZONS)
        and set(prediction["survival"]) == {row["family"]}
        and len(prediction["patient_ids"])
        == len(set(prediction["patient_ids"]))
        == len(prediction["centers"]),
        "NESTED_SCORE_COMPONENT_EVIDENCE_INVALID",
    )
    _seal_prediction_matrix(
        prediction["patient_ids"], prediction["survival"][row["family"]],
        list(HORIZONS),
    )
    _require(
        all(curve[0] == 1.0 for curve in prediction["survival"][row["family"]]),
        "NESTED_SCORE_COMPONENT_MONTH_ZERO_INVALID",
    )
    _require(
        _sha(prediction) == receipt["prediction_sha256"]
        and _sha(dict(row["fit_health"])) == receipt["fit_health_sha256"],
        "NESTED_SCORE_COMPONENT_EVIDENCE_HASH_DRIFT",
    )
    _require(row["family"] != "XGBOOST_COX" or row["fit_health"].get("model_binary_sha256") == receipt["model_sha256"],
             "NESTED_SCORE_OBJECT_AUDIT_MODEL_BINDING_DRIFT")
    validate_sha256(row["request_component_sha256"],
                    "nested.score_evidence.request_component")
    if q_reuse:
        _require(retained, "NESTED_FULL0_RSF_Q_SCORE_SOURCE_INVALID")
        _validate_full0_rsf_q_score_source(row["retained_model_source"], receipt, context)
    elif retained:
        source = row["retained_model_source"]
        hashes = {"original_fit_source", "recovery_source", "recovery_archive_sha256",
            "original_failure_archive_sha256", "original_request_identity_sha256",
            "original_coordinate_identity", "input_component_sha256", "native_archive_sha256",
            "model_sha256", "baseline_sha256", "original_score_evidence_sha256"}
        _require(context["scope"] == "OUTER" and row["family"] in _RETAINED_SCORE_SOURCE_KINDS
                 and isinstance(source, Mapping) and set(source) == hashes | {
                     "kind", "native_archive_size_bytes", "historical_model_fit_count", "new_model_fit_count"}
                 and source["kind"] == _RETAINED_SCORE_SOURCE_KINDS[row["family"]]
                 and type(source["historical_model_fit_count"]) is int and source["historical_model_fit_count"] == 1
                 and type(source["new_model_fit_count"]) is int and source["new_model_fit_count"] == 0
                 and type(source["native_archive_size_bytes"]) is int and source["native_archive_size_bytes"] > 0
                 and source["input_component_sha256"] == row["request_component_sha256"]
                 and source["native_archive_sha256"] == receipt["archive_sha256"]
                 and source["model_sha256"] == receipt["model_sha256"]
                 and source["baseline_sha256"] == receipt["baseline_sha256"],
                 "NESTED_RETAINED_SCORE_SOURCE_DRIFT")
        for name in hashes:
            validate_sha256(source[name], "nested.retained_score." + name)
    return row


def validate_component_receipt(value: Any, lock: Mapping[str, Any]) -> dict[str, Any]:
    lock = validate_development_lock(lock)
    row = _validate_seal(value, _RECEIPT_FIELDS, "NESTED_COMPONENT_RECEIPT_INVALID")
    full_final = type(lock["outer_fold"]) is int and lock["outer_fold"] == 0
    _require(not full_final or lock["heldout_center"] is None and lock["heldout_ids_sha256"] == _sha([]),
             "NESTED_COMPONENT_RECEIPT_INVALID")
    _require(
        type(row["imputation"]) is int and row["imputation"] in range(1, M + 1)
        and row["development_lock_sha256"] == lock["identity_sha256"]
        and row["training_context_sha256"] == lock["training_context_sha256"]
        and row["recipe_sha256"] == lock["recipe_sha256_by_imputation"][row["imputation"] - 1]
        and row["parameter_sha256"] == _sha(lock["parameters_by_imputation"][row["imputation"] - 1])
        and row["training_ids_sha256"] == lock["training_ids_sha256"]
        and row["application_ids_sha256"] == lock["training_ids_sha256" if full_final else "heldout_ids_sha256"]
        and row["model_fit_count"] == 1 and row["engine_threads"] == 1
        and type(row["seed"]) is int and row["seed"] > 0
        and (not full_final or row["seed"] == 300000),
        "NESTED_COMPONENT_RECEIPT_INVALID",
    )
    for field in _RECEIPT_FIELDS - {"imputation", "model_fit_count", "engine_threads", "seed"}:
        validate_sha256(row[field], f"nested.component.{field}")
    return row


def seal_selected_prediction(
    *, lock: Mapping[str, Any], patient_ids: list[str], centers: list[str],
    survival: list[list[float]], component_receipts: Sequence[Mapping[str, Any]],
) -> dict[str, Any]:
    """Seal one outer's M20-pooled prediction before any outcome join."""
    from .f2_kernel import _seal_prediction_matrix

    lock = validate_development_lock(lock)
    _require(type(lock["outer_fold"]) is int and lock["outer_fold"] in range(1, 7),
             "NESTED_SELECTED_PREDICTION_REQUIRES_OUTER_LOCK")
    receipts = [validate_component_receipt(value, lock) for value in component_receipts]
    _require(
        [row["imputation"] for row in receipts] == list(range(1, M + 1))
        and isinstance(patient_ids, list) and bool(patient_ids)
        and len(patient_ids) == len(set(patient_ids)) == len(centers)
        and all(center == str(lock["heldout_center"]) for center in centers),
        "NESTED_SELECTED_PREDICTION_INPUT_INVALID",
    )
    sealed = _seal_prediction_matrix(patient_ids, survival, list(HORIZONS))
    _require(
        all(curve[0] == 1.0 for curve in survival),
        "NESTED_SELECTED_PREDICTION_MONTH_ZERO_INVALID",
    )
    body = {
        "schema_version": SCHEMA_VERSION,
        "kind": "PADML_NESTED_LOCO_SELECTED_OUTER_PREDICTION_V1",
        "selection_horizon_months": lock["selection_horizon_months"],
        "science_decision_sha256": lock["science_decision_binding"]["science_decision_sha256"],
        "status": "SEALED_RESPONSE_FREE",
        "outer_fold": lock["outer_fold"],
        "heldout_center": lock["heldout_center"],
        "selected_family": lock["selected_family"],
        "development_lock_sha256": lock["identity_sha256"],
        "patient_ids": patient_ids,
        "patient_ids_sha256": _sha(patient_ids),
        "centers": centers,
        "horizons": list(HORIZONS),
        "survival": survival,
        "survival_seal_sha256": sealed["sha256"],
        "component_receipt_sha256": [row["identity_sha256"] for row in receipts],
        "component_count": M,
        "model_fit_count": M,
        "heldout_outcome_read_count": 0,
    }
    return _sealed(body)


_PREDICTION_FIELDS = {
    "schema_version", "kind", "status", "outer_fold", "heldout_center",
    "selected_family", "development_lock_sha256", "patient_ids",
    "patient_ids_sha256", "centers", "horizons", "survival",
    "survival_seal_sha256", "component_receipt_sha256", "component_count",
    "model_fit_count", "heldout_outcome_read_count",
}


def validate_selected_prediction(value: Any, lock: Mapping[str, Any] | None = None) -> dict[str, Any]:
    from .f2_kernel import _seal_prediction_matrix

    row = _validate_seal(value, _PREDICTION_FIELDS | {"selection_horizon_months", "science_decision_sha256"},
                         "NESTED_SELECTED_PREDICTION_INVALID")
    selection_horizon(row["selection_horizon_months"])
    validate_sha256(row["science_decision_sha256"], "nested.prediction.science_decision")
    _require(
        row["schema_version"] == SCHEMA_VERSION
        and row["kind"] == "PADML_NESTED_LOCO_SELECTED_OUTER_PREDICTION_V1"
        and row["status"] == "SEALED_RESPONSE_FREE"
        and row["outer_fold"] in range(1, 7)
        and row["heldout_center"] == OUTER_CENTERS[row["outer_fold"] - 1]
        and row["selected_family"] in _families()
        and row["patient_ids_sha256"] == _sha(row["patient_ids"])
        and len(row["patient_ids"]) == len(set(row["patient_ids"])) == len(row["centers"])
        and all(center == str(row["heldout_center"]) for center in row["centers"])
        and row["horizons"] == list(HORIZONS)
        and row["survival_seal_sha256"]
        == _seal_prediction_matrix(row["patient_ids"], row["survival"], list(HORIZONS))["sha256"]
        and all(curve[0] == 1.0 for curve in row["survival"])
        and len(row["component_receipt_sha256"]) == row["component_count"] == M
        and row["model_fit_count"] == M
        and row["heldout_outcome_read_count"] == 0,
        "NESTED_SELECTED_PREDICTION_INVALID",
    )
    for digest in [row["development_lock_sha256"], row["survival_seal_sha256"],
                   *row["component_receipt_sha256"]]:
        validate_sha256(digest, "nested.prediction.binding")
    if lock is not None:
        lock = validate_development_lock(lock)
        _require(
            row["development_lock_sha256"] == lock["identity_sha256"]
            and row.get("selection_horizon_months", 24) == lock.get("selection_horizon_months", 24)
            and (row["science_decision_sha256"]
                 == lock["science_decision_binding"]["science_decision_sha256"])
            and row["selected_family"] == lock["selected_family"]
            and row["outer_fold"] == lock["outer_fold"],
            "NESTED_SELECTED_PREDICTION_LOCK_MISMATCH",
        )
    return row


_OOC_FIELDS = {
    "schema_version", "kind", "status", "variant", "population_registry_sha256",
    "patient_ids", "patient_ids_sha256", "centers", "horizons", "survival",
    "selection_by_outer", "outer_family_consensus_required", "heldout_outcome_read_count",
}


def validate_selected_ooc(
    value: Any, *, population_registry: Mapping[str, Any], variant: str = "PRIMARY",
) -> dict[str, Any]:
    from .f2_kernel import _seal_prediction_matrix

    registry = validate_population_registry(population_registry)
    row = _validate_seal(value, _OOC_FIELDS | {"selection_horizon_months", "science_decision_sha256"},
                         "NESTED_SELECTED_OOC_INVALID")
    selection_horizon(row["selection_horizon_months"])
    validate_sha256(row["science_decision_sha256"], "nested.ooc.science_decision")
    ids = registry["evaluation_patient_ids"]
    _require(
        variant in ("PRIMARY", *AAR_ESTIMANDS)
        and row["schema_version"] == SCHEMA_VERSION
        and row["kind"] == "PADML_NESTED_LOCO_SELECTED_POLICY_OOC_V1"
        and row["status"] == "SEALED_RESPONSE_FREE"
        and row["variant"] == variant
        and row["population_registry_sha256"] == _sha(registry)
        and row["patient_ids"] == ids and row["patient_ids_sha256"] == _sha(ids)
        and row["centers"] == [registry["centers_by_patient"][patient] for patient in ids]
        and row["horizons"] == list(HORIZONS)
        and isinstance(row["survival"], Mapping)
        and set(row["survival"]) == {"NESTED_SELECTED_POLICY"}
        and isinstance(row["selection_by_outer"], list)
        and len(row["selection_by_outer"]) == 6
        and row["outer_family_consensus_required"] is False
        and row["heldout_outcome_read_count"] == 0,
        "NESTED_SELECTED_OOC_INVALID",
    )
    _seal_prediction_matrix(ids, row["survival"]["NESTED_SELECTED_POLICY"], list(HORIZONS))
    _require(
        all(curve[0] == 1.0 for curve in row["survival"]["NESTED_SELECTED_POLICY"]),
        "NESTED_SELECTED_OOC_MONTH_ZERO_INVALID",
    )
    for outer, selection in enumerate(row["selection_by_outer"], 1):
        _require(
            isinstance(selection, Mapping) and set(selection) == {
                "outer_fold", "heldout_center", "selected_family",
                "development_lock_sha256", "primary_development_lock_sha256",
                "prediction_identity_sha256",
            }
            and selection["outer_fold"] == outer
            and selection["heldout_center"] == OUTER_CENTERS[outer - 1]
            and selection["selected_family"] in _families()
            and (variant != "PRIMARY" or selection["primary_development_lock_sha256"]
                 == selection["development_lock_sha256"]),
            "NESTED_SELECTED_OOC_SELECTION_INVALID",
        )
        for name in ("development_lock_sha256", "primary_development_lock_sha256",
                     "prediction_identity_sha256"):
            validate_sha256(selection[name], f"nested.ooc.{name}")
    return row


def assemble_selected_ooc(
    predictions: Sequence[Mapping[str, Any]], *, population_registry: Mapping[str, Any],
) -> dict[str, Any]:
    """Assemble six mutually exclusive outer predictions; winners may differ."""
    admitted = [validate_selected_prediction(value) for value in predictions]
    registry = validate_population_registry(population_registry)
    by_outer = {row["outer_fold"]: row for row in admitted}
    _require(len(admitted) == len(by_outer) == 6 and set(by_outer) == set(range(1, 7)),
             "NESTED_SELECTED_OOC_OUTER_SET_INVALID")
    horizons = {row["selection_horizon_months"] for row in admitted}
    _require(len(horizons) == 1, "NESTED_SELECTED_OOC_SELECTION_HORIZON_MISMATCH")
    horizon = next(iter(horizons))
    identities = {row["science_decision_sha256"] for row in admitted}
    _require(all(science_identity_matches(identity, horizon) for identity in identities),
             "NESTED_SELECTED_OOC_SELECTION_HORIZON_MISMATCH")
    # Original outer readers already bind each prediction to its own lock and
    # source. Aggregation admits only the exact approved base/amendment pair;
    # it never rewrites any producer prediction, lock or constituent identity.
    base_identity = _base_science_decision_template(horizon)["identity_sha256"]
    aggregate_science = (base_identity if identities == {base_identity} else
                         science_decision_template(horizon)["identity_sha256"])
    patient_ids: list[str] = []
    centers: list[str] = []
    survival: list[list[float]] = []
    selections = []
    for outer in range(1, 7):
        row = by_outer[outer]
        _require(
            row["patient_ids"] == registry["outer"][outer - 1]["heldout_ids"],
            "NESTED_SELECTED_OOC_REGISTRY_PATIENT_DRIFT",
        )
        _require(not set(patient_ids).intersection(row["patient_ids"]),
                 "NESTED_SELECTED_OOC_PATIENT_OVERLAP")
        patient_ids.extend(row["patient_ids"])
        centers.extend(row["centers"])
        survival.extend(row["survival"])
        selections.append({
            "outer_fold": outer,
            "heldout_center": row["heldout_center"],
            "selected_family": row["selected_family"],
            "development_lock_sha256": row["development_lock_sha256"],
            "primary_development_lock_sha256": row["development_lock_sha256"],
            "prediction_identity_sha256": row["identity_sha256"],
        })
    by_patient = dict(zip(patient_ids, survival, strict=True))
    patient_ids = list(registry["evaluation_patient_ids"])
    centers = [registry["centers_by_patient"][patient] for patient in patient_ids]
    survival = [by_patient[patient] for patient in patient_ids]
    body = {
        "schema_version": SCHEMA_VERSION,
        "kind": "PADML_NESTED_LOCO_SELECTED_POLICY_OOC_V1",
        "selection_horizon_months": horizon,
        "science_decision_sha256": aggregate_science,
        "status": "SEALED_RESPONSE_FREE",
        "variant": "PRIMARY",
        "population_registry_sha256": _sha(registry),
        "patient_ids": patient_ids,
        "patient_ids_sha256": _sha(patient_ids),
        "centers": centers,
        "horizons": list(HORIZONS),
        "survival": {"NESTED_SELECTED_POLICY": survival},
        "selection_by_outer": selections,
        "outer_family_consensus_required": False,
        "heldout_outcome_read_count": 0,
    }
    return validate_selected_ooc(_sealed(body), population_registry=registry)


def evaluate_selected_ooc(
    selected_ooc: Mapping[str, Any], heldout_response_csv: bytes,
    *, population_registry: Mapping[str, Any], evidence_root: Path | None = None,
    native_archive: Path | None = None, replay_native_archive: Path | bytes | None = None,
    science_decision: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Produce or read held-out metrics in H7's original consumer, not acceptance."""
    from .f4 import evaluate_predictions

    row = validate_selected_ooc(selected_ooc, population_registry=population_registry)
    horizon = selection_horizon(row["selection_horizon_months"])
    science = validate_science_decision(science_decision or science_decision_template(horizon), selection_horizon_months=horizon)
    _require(science["identity_sha256"] == row["science_decision_sha256"],
             "NESTED_SELECTED_OOC_SCIENCE_DECISION_MISMATCH")
    evaluation_options = {"selection_horizon_months": horizon, "science_decision": science}
    _require(
        row["kind"] == "PADML_NESTED_LOCO_SELECTED_POLICY_OOC_V1"
        and row["status"] == "SEALED_RESPONSE_FREE"
        and row["patient_ids_sha256"] == _sha(row["patient_ids"])
        and _response_ids(heldout_response_csv, "NESTED_HELDOUT") == row["patient_ids"]
        and row["heldout_outcome_read_count"] == 0,
        "NESTED_SELECTED_OOC_INVALID",
    )
    evaluation = evaluate_predictions(
        {
            "patient_ids": row["patient_ids"],
            "centers": row["centers"],
            "horizons": row["horizons"],
            "survival": row["survival"],
        },
        heldout_response_csv,
        evidence_root=evidence_root,
        **evaluation_options,
        **({"native_archive": native_archive} if native_archive is not None else {}),
        **({"replay_native_archive": replay_native_archive} if replay_native_archive is not None else {}),
    )
    body = {
        "schema_version": SCHEMA_VERSION,
        "kind": "PADML_NESTED_LOCO_SELECTED_POLICY_EVALUATION_V1",
        "selection_horizon_months": horizon,
        "science_decision_sha256": row["science_decision_sha256"],
        "status": "COMPUTED_NOT_EXTERNAL_VALIDATION_OF_FULL_DATA_MODEL",
        "selected_ooc_sha256": row["identity_sha256"],
        "heldout_response_sha256": sha256_bytes(heldout_response_csv),
        "outcome_join_location": "WHOLE_UNIT_ORIGINAL_F4_F5_EVALUATION",
        "evaluation": evaluation,
        "full_data_final_model_external_validation": False,
    }
    return _sealed(body)


def aar_estimand_contract(estimand: str) -> dict[str, Any]:
    _require(estimand in AAR_ESTIMANDS, "NESTED_AAR_ESTIMAND_INVALID")
    shared = {
        "estimand": estimand,
        "family_source": "EACH_PRIMARY_OUTER_DEVELOPMENT_LOCK",
        "family_reselection": False,
        "aar_raw_columns": ["AST", "ALT", "AST_ALT"],
        "writeback": "FORBIDDEN",
    }
    if estimand == A12_DIRECT_AAR:
        return {
            **shared,
            "label": "A12 direct ablation",
            "question": "PREDICTION_CHANGE_AFTER_DIRECT_MODEL_TERM_ABLATION",
            "seta_reselection": False,
            "mice_policy": "REUSE_PRIMARY_OUTER_M20",
            "variable_policy": "DELETE_AST_ALT_MODEL_TERM_KEEP_AAR_IMPUTATION_AUXILIARIES",
            "retuning": "FRESH_WITHIN_INHERITED_FAMILY_ONLY",
        }
    if estimand == A12_TOTAL_AAR:
        return {
            **shared,
            "label": "A12 total ablation",
            "question": "PREDICTION_CHANGE_AFTER_TOTAL_AAR_INFORMATION_REMOVAL_WITH_FIXED_NON_AAR_SETA",
            "seta_reselection": False,
            "mice_policy": "FRESH_SPLIT_LOCAL_M20",
            "variable_policy": "REMOVE_AST_ALT_AND_AST_ALT_INFORMATION_CHANNEL_AT_RAW_MICE_PASSIVE_MODEL_BOUNDARY",
            "retuning": "FRESH_WITHIN_INHERITED_FAMILY_ONLY",
        }
    return {
        **shared,
        "label": WITHIN_FAMILY_NO_AAR_LABEL,
        "question": "PREDICTION_CHANGE_AFTER_NO_AAR_REDEVELOPMENT_CONDITIONAL_ON_EACH_OUTER_SELECTED_FAMILY",
        "seta_reselection": True,
        "mice_policy": "FRESH_SPLIT_LOCAL_M20",
        "variable_policy": "REMOVE_AST_ALT_AND_AST_ALT_INFORMATION_CHANNEL_AT_RAW_MICE_PASSIVE_MODEL_BOUNDARY",
        "parent_policy": "FRESH_RESELECT_ALL_LEGAL_NON_AAR_PARENTS_NO_FORCED_REPLACEMENT",
        "retuning": "FRESH_WITHIN_INHERITED_FAMILY_ONLY",
        "family_comparison_count": 1,
    }


def paired_aar_contrast(
    primary: Mapping[str, Any], ablated: Mapping[str, Any], *, estimand: str,
    population_registry: Mapping[str, Any],
) -> dict[str, Any]:
    """Bind paired patient predictions without conflating the two estimands."""
    contract = aar_estimand_contract(estimand)
    p = validate_selected_ooc(primary, population_registry=population_registry)
    a = validate_selected_ooc(
        ablated, population_registry=population_registry, variant=estimand
    )
    _require(
        p["patient_ids"] == a["patient_ids"] and p["centers"] == a["centers"]
        and p["horizons"] == a["horizons"] == list(HORIZONS)
        and p.get("selection_horizon_months", 24) == a.get("selection_horizon_months", 24)
        and p.get("science_decision_sha256") == a.get("science_decision_sha256")
        and set(p["survival"]) == set(a["survival"]) == {"NESTED_SELECTED_POLICY"},
        "NESTED_AAR_PAIRING_INVALID",
    )
    _require(
        p["identity_sha256"] != a["identity_sha256"]
        and all(
            original["outer_fold"] == other["outer_fold"]
            and original["heldout_center"] == other["heldout_center"]
            and original["selected_family"] == other["selected_family"]
            and original["development_lock_sha256"] == other["primary_development_lock_sha256"]
            and original["development_lock_sha256"] != other["development_lock_sha256"]
            and original["prediction_identity_sha256"] != other["prediction_identity_sha256"]
            for original, other in zip(p["selection_by_outer"], a["selection_by_outer"], strict=True)
        ),
        "NESTED_AAR_INHERITED_FAMILY_OR_LOCK_INVALID",
    )
    pm = p["survival"]["NESTED_SELECTED_POLICY"]
    am = a["survival"]["NESTED_SELECTED_POLICY"]
    deltas = [[(1.0 - aa) - (1.0 - pp) for pp, aa in zip(prow, arow, strict=True)]
              for prow, arow in zip(pm, am, strict=True)]
    body = {
        "schema_version": SCHEMA_VERSION,
        "kind": "PADML_NESTED_LOCO_PAIRED_AAR_PREDICTION_CONTRAST_V1",
        "status": "COMPUTED_RESPONSE_FREE",
        "estimand_contract": contract,
        "primary_ooc_sha256": p["identity_sha256"],
        "ablated_ooc_sha256": a["identity_sha256"],
        "patient_ids_sha256": p["patient_ids_sha256"],
        "horizons": list(HORIZONS),
        "risk_delta_ablated_minus_primary": deltas,
        "writeback": "FORBIDDEN",
        "outcome_read_count": 0,
    }
    return _sealed(body)


def full_data_interpretation() -> dict[str, Any]:
    return {
        "training_scope": "ALL_SEVEN_CENTERS",
        "program": "SAME_NESTED_DEVELOPMENT_PROGRAM_WITH_VIRTUAL_OUTER_ZERO",
        "independent_external_validation": False,
        "allowed_claim": "FINAL_FULL_DATA_DEVELOPMENT_MODEL_ONLY",
        "forbidden_claim": "INDEPENDENTLY_EXTERNALLY_VALIDATED_FINAL_MODEL",
    }


def _seal_full_final_apparent_prediction(
    *, context: Mapping[str, Any], lock: Mapping[str, Any],
    predictions: Sequence[Mapping[str, Any]], component_receipts: Sequence[Mapping[str, Any]],
) -> dict[str, Any]:
    """Pool the final M20, explicitly as full-data apparent predictions.

    A native replay owner supplies the twenty archive predictions/receipts;
    it must reproduce this whole value for acceptance, not admit a bare mean.
    This kind cannot enter the selected-outer/OOC validators.
    """
    from .f2_kernel import _pool_prediction_batch, _seal_prediction_matrix

    context = validate_training_context(context)
    lock = validate_development_lock(lock, context=context)
    _require(context["scope"] == "FULL_DATA" and context["channel"] == "PRIMARY"
             and lock["outer_fold"] == 0 and lock["heldout_center"] is None
             and lock["training_ids_sha256"] == context["training_ids_sha256"]
             and lock["heldout_ids_sha256"] == _sha([]), "NESTED_FULL_FINAL_PREDICTION_SCOPE_INVALID")
    receipts = [validate_component_receipt(row, lock) for row in component_receipts]
    _require(len(predictions) == len(receipts) == M
             and [row["imputation"] for row in receipts] == list(range(1, M + 1)),
             "NESTED_FULL_FINAL_PREDICTION_COMPONENT_SET_INVALID")
    ids, family = context["training_ids"], lock["selected_family"]
    centers = [context["centers_by_patient"][patient] for patient in ids]
    components = []
    for imputation, (prediction, receipt) in enumerate(zip(predictions, receipts, strict=True), 1):
        _require(isinstance(prediction, Mapping) and set(prediction) == {
            "f4_coordinates", "patient_ids", "centers", "horizons", "survival"}
            and prediction["f4_coordinates"] == {"purpose": "NESTED_FULL_FINAL", "outer_fold": 0,
                "repeat": 0, "inner_fold": 0, "imputation": imputation}
            and prediction["patient_ids"] == ids and prediction["centers"] == centers
            and prediction["horizons"] == list(HORIZONS) and isinstance(prediction["survival"], Mapping)
            and set(prediction["survival"]) == {family} and _sha(prediction) == receipt["prediction_sha256"]
            and receipt["training_response_sha256"] == context["training_response_sha256"],
            "NESTED_FULL_FINAL_PREDICTION_COMPONENT_DRIFT")
        survival = prediction["survival"][family]
        sealed = _seal_prediction_matrix(ids, survival, list(HORIZONS))
        _require(all(curve[0] == 1.0 for curve in survival), "NESTED_FULL_FINAL_PREDICTION_MONTH_ZERO_INVALID")
        components.append({"sealed_prediction": sealed})
    pooled = _pool_prediction_batch(components, list(HORIZONS))
    return _sealed({"schema_version": SCHEMA_VERSION, "kind": "PADML_NESTED_FULL_FINAL_APPARENT_PREDICTION_V1",
        "status": "SEALED_RESPONSE_FREE_APPARENT_NOT_EXTERNAL_VALIDATION", "program_id": PROGRAM_ID,
        "outer_fold": 0, "selected_family": family, "development_lock_sha256": lock["identity_sha256"],
        "training_context_sha256": context["identity_sha256"], "patient_ids": ids, "patient_ids_sha256": _sha(ids),
        "centers": centers, "horizons": list(HORIZONS), "survival": pooled["payload"]["survival"],
        "survival_seal_sha256": pooled["sha256"],
        "component_receipt_sha256": [row["identity_sha256"] for row in receipts],
        "component_count": M, "model_fit_count": M, "heldout_outcome_read_count": 0,
        "interpretation": full_data_interpretation()})


_COMPONENT_MEMBERS = {
    "task.json", "recipe.json", "fit-covariates.csv", "fit-response.csv",
    "prediction-covariates.csv",
}


def _component_input_record(
    raw: bytes | Path, *, role: str, path: str,
    extracted_member: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    validate_relative_path(path, "nested.component.path")
    _require(role in {"FRESH_SCORE", "POST_LOCK_TEMPLATE"},
             "NESTED_COMPONENT_ROLE_INVALID")
    if isinstance(raw, Path):
        _require(raw.is_absolute() and raw.is_file() and not raw.is_symlink(),
                 "NESTED_COMPONENT_SOURCE_INVALID")
        if extracted_member is None:
            digest, size = sha256_file(raw), raw.stat().st_size
        else:
            # Only the owning materializer passes the extractor's actual stream
            # record, in its private no-write window. Replay/default rehashes.
            _require(isinstance(extracted_member, Mapping)
                     and set(extracted_member) == {"relative_path", "sha256", "size_bytes"}
                     and extracted_member["relative_path"] == path
                     and type(extracted_member["size_bytes"]) is int
                     and extracted_member["size_bytes"] > 0
                     and raw.stat().st_size == extracted_member["size_bytes"],
                     "NESTED_COMPONENT_SOURCE_INVALID")
            validate_sha256(extracted_member["sha256"], "nested.component.extracted_sha256")
            digest, size = extracted_member["sha256"], extracted_member["size_bytes"]
    else:
        _require(isinstance(raw, bytes) and bool(raw) and extracted_member is None,
                 "NESTED_COMPONENT_SOURCE_INVALID")
        digest, size = sha256_bytes(raw), len(raw)
    return {
        "role": role,
        "path": path,
        "sha256": digest,
        "size_bytes": size,
        "visibility": "TRAINING_RESPONSE_AND_RESPONSE_FREE_APPLICATION",
    }


def _read_component(raw: bytes | Path) -> tuple[dict[str, Any], dict[str, Any], dict[str, bytes]]:
    entries = read_safe_zip(
        raw,
        expected_members=_COMPONENT_MEMBERS,
        max_member_bytes=512 * 1024 * 1024,
        max_total_bytes=2 * 1024 * 1024 * 1024,
    )
    task = strict_json_bytes(entries["task.json"], "NESTED_COMPONENT_TASK")
    recipe = strict_json_bytes(entries["recipe.json"], "NESTED_COMPONENT_RECIPE")
    _require(isinstance(task, dict) and isinstance(recipe, dict),
             "NESTED_COMPONENT_JSON_INVALID")
    return task, recipe, entries


def _covariate_ids(raw: bytes, label: str) -> tuple[list[str], list[str], dict[str, str]]:
    fields, rows = _csv_rows(raw, label)
    expected_fields = load_science_authority()["science"]["mice"][
        "private_handoff"
    ]["columns"]
    _require(
        fields == expected_fields
        and bool(rows),
        f"{label}_COVARIATE_SCHEMA_INVALID",
    )
    ids = [row["Patient_ID"] for row in rows]
    _require(len(ids) == len(set(ids)) and all(ids), f"{label}_COVARIATE_ID_INVALID")
    centers: dict[str, str] = {}
    for row in rows:
        try:
            value = float(row["Center"])
        except ValueError as exc:
            raise ContractError(f"{label}_COVARIATE_CENTER_INVALID") from exc
        _require(
            math.isfinite(value) and value.is_integer()
            and str(int(value)) in {str(center) for center in (*OUTER_CENTERS, TRAINING_ONLY_CENTER)},
            f"{label}_COVARIATE_CENTER_INVALID",
        )
        centers[row["Patient_ID"]] = str(int(value))
    return ids, fields, centers


def _validate_outer_component(
    raw: bytes | Path, *, role: str, family: str, context: Mapping[str, Any],
) -> dict[str, Any]:
    from .f2_kernel import _expected_family_parent_column_map, predictor_contract
    from .f4 import _f4_elastic_parameters, _f4_model_seed, _nested_full_elastic_parameters
    from .f5 import _validate_final_design_recipe, _validate_final_refit_locked_spec, _validate_nested_full_score_task

    task, recipe, entries = _read_component(raw)
    context = validate_training_context(context)
    full_score = context["scope"] == "FULL_DATA"
    _require(not full_score or role == "FRESH_SCORE" and context["channel"] == "PRIMARY",
             "NESTED_FULL_SCORE_COMPONENT_SCOPE_INVALID")
    fit_ids, _, fit_centers = _covariate_ids(
        entries["fit-covariates.csv"], "NESTED_COMPONENT_FIT"
    )
    prediction_ids, _, prediction_centers = _covariate_ids(
        entries["prediction-covariates.csv"], "NESTED_COMPONENT_APPLICATION"
    )
    response_ids = _response_ids(entries["fit-response.csv"], "NESTED_COMPONENT_FIT")
    coordinates = task.get("f4_coordinates")
    stochastic = family in {"RSF", "GBM_COX", "XGBOOST_COX", "COXTIME_SET_A"}
    task_fields = {
        "family", "selected_parents", "parameters", "imputation",
        "f4_coordinates", "registered_model_seed", "model_seed", "row_count",
        "family_design_column_count",
    }
    elastic_field = "f4_nested_full_elastic_source" if full_score else "f4_outer_elastic_source"
    if family == "ELASTIC_NET_COX":
        task_fields.add(elastic_field)
    if full_score:
        task_fields.add("nested_full_score_source")
        _validate_nested_full_score_task(task)
        _require(task["nested_full_score_source"]["training_context_sha256"] == context["identity_sha256"],
                 "NESTED_FULL_SCORE_COMPONENT_CONTEXT_DRIFT")
    _require(
        set(task) == task_fields
        and task.get("family") == family
        and isinstance(task.get("selected_parents"), list)
        and bool(task["selected_parents"])
        and len(task["selected_parents"]) == len(set(task["selected_parents"]))
        and isinstance(task.get("parameters"), Mapping) and bool(task["parameters"])
        and type(task.get("imputation")) is int and task["imputation"] in range(1, M + 1)
        and isinstance(coordinates, Mapping)
        and coordinates.get("outer_fold") == context["outer_fold"]
        and coordinates.get("imputation") == task["imputation"]
        and task.get("registered_model_seed") == _f4_model_seed(family, coordinates)
        and task.get("model_seed")
        == (task["registered_model_seed"] if stochastic else None)
        and task.get("row_count") == len(fit_ids)
        and type(task.get("family_design_column_count")) is int
        and task["family_design_column_count"] > 0
        and fit_ids == response_ids
        and set(fit_ids).isdisjoint(prediction_ids)
        and set(fit_ids) <= set(context["training_ids"])
        and set(prediction_ids) <= set(context["training_ids"] + context["heldout_ids"]),
        "NESTED_COMPONENT_BINDING_INVALID",
    )
    _validate_final_design_recipe(
        recipe, family=family, selected_parents=task["selected_parents"]
    )
    column_map = _expected_family_parent_column_map(
        task["selected_parents"], family, predictor_contract(Path(__file__).parent),
        recipe["transform_recipe"],
    )
    _require(
        task["family_design_column_count"]
        == sum(len(row["columns"]) for row in column_map),
        "NESTED_COMPONENT_DESIGN_COUNT_INVALID",
    )
    if family == "ELASTIC_NET_COX":
        resolver = _nested_full_elastic_parameters if full_score else _f4_elastic_parameters
        expected_parameters, _ = resolver(task[elastic_field], coordinates)
        _require(task["parameters"] == expected_parameters,
                 "NESTED_COMPONENT_PARAMETER_DRIFT")
    else:
        _validate_final_refit_locked_spec(family, task["parameters"])
    _require(
        all(context["centers_by_patient"][patient] == center
            for patient, center in {**fit_centers, **prediction_centers}.items()),
        "NESTED_COMPONENT_CENTER_BINDING_INVALID",
    )
    if role == "FRESH_SCORE":
        _require(
            family in _families()
            and coordinates.get("purpose") == ("NESTED_FULL_SCORE" if full_score else "O_FIT")
            and coordinates.get("repeat") in range(1, REPEAT_COUNT + 1)
            and coordinates.get("inner_fold") in range(1, INNER_FOLD_COUNT + 1)
            and set(prediction_ids) <= set(context["training_ids"])
            and set(fit_ids).isdisjoint(prediction_ids)
            and "development_lock_sha256" not in task,
            "NESTED_SCORE_COMPONENT_ISOLATION_INVALID",
        )
    else:
        _require(
            family in _families()
            and coordinates
            == {
                "purpose": "NESTED_OUTER",
                "outer_fold": context["outer_fold"],
                "repeat": 0,
                "inner_fold": 0,
                "imputation": task["imputation"],
            }
            and prediction_ids == context["heldout_ids"]
            and set(fit_ids) == set(context["training_ids"])
            and "development_lock_sha256" not in task,
            "NESTED_POST_LOCK_TEMPLATE_ISOLATION_INVALID",
        )
    return {
        "family": family,
        "imputation": task["imputation"],
        "repeat": coordinates["repeat"],
        "inner_fold": coordinates["inner_fold"],
        "registered_model_seed": task["registered_model_seed"],
        "selected_parents_sha256": _sha(task["selected_parents"]),
        "parameter_sha256": _sha(task["parameters"]),
        "task_sha256": _sha(task),
        "recipe_sha256": _sha(recipe),
        "family_design_column_count": task["family_design_column_count"],
        "fit_ids_sha256": _sha(fit_ids),
        "prediction_ids_sha256": _sha(prediction_ids),
        "fit_response_sha256": sha256_bytes(entries["fit-response.csv"]),
        "development_spec_sha256": _sha(
            task[elastic_field]["selected_spec"]
            if family == "ELASTIC_NET_COX" else task["parameters"]
        ),
    }


def _validate_score_partitions(
    value: Any, context: Mapping[str, Any]
) -> tuple[list[dict[str, Any]], dict[tuple[int, int], dict[str, Any]]]:
    context = validate_training_context(context)
    _require(isinstance(value, list), "NESTED_SCORE_PARTITION_SET_INVALID")
    rows = [dict(row) if isinstance(row, Mapping) else row for row in value]
    expected_coordinates = [
        (repeat, inner)
        for repeat in range(1, REPEAT_COUNT + 1)
        for inner in range(1, INNER_FOLD_COUNT + 1)
    ]
    _require(
        len(rows) == REPEAT_COUNT * INNER_FOLD_COUNT
        and [(row.get("repeat"), row.get("inner_fold")) for row in rows]
        == expected_coordinates
        and len({row.get("partition_id") for row in rows}) == len(rows)
        and all(
            isinstance(row, Mapping)
            and set(row) == {
                "partition_id", "repeat", "inner_fold", "fit_ids", "evaluation_ids",
            }
            and isinstance(row["partition_id"], str) and bool(row["partition_id"])
            and isinstance(row["fit_ids"], list) and bool(row["fit_ids"])
            and isinstance(row["evaluation_ids"], list) and bool(row["evaluation_ids"])
            and all(isinstance(patient, str) and bool(patient)
                    for patient in row["fit_ids"] + row["evaluation_ids"])
            and len(row["fit_ids"]) == len(set(row["fit_ids"]))
            and len(row["evaluation_ids"]) == len(set(row["evaluation_ids"]))
            and set(row["fit_ids"]).isdisjoint(row["evaluation_ids"])
            and set(row["fit_ids"] + row["evaluation_ids"])
            == set(context["training_ids"])
            for row in rows
        )
        and all(
            sorted(
                patient
                for row in rows if row["repeat"] == repeat
                for patient in row["evaluation_ids"]
            ) == sorted(context["training_ids"])
            for repeat in range(1, REPEAT_COUNT + 1)
        ),
        "NESTED_SCORE_PARTITION_SET_INVALID",
    )
    return rows, {(row["repeat"], row["inner_fold"]): row for row in rows}


def _canonical_response_subset_sha256(raw: bytes, ids: list[str]) -> str:
    from .f2_kernel import _response_rows, _write_response_subset

    fields, rows = _response_rows(raw)
    subset = _write_response_subset(fields, rows, ids, None)
    _require(
        subset["row_count"] == len(ids)
        and subset["row_ids_sha256"] == _sha(ids),
        "NESTED_RESPONSE_SUBSET_ORDER_DRIFT",
    )
    return sha256_bytes(subset["private_bytes"])


def _component_archive_size_bound(entries: Mapping[str, bytes]) -> int:
    # Conservative DEFLATE/header estimate, also covering small incompressible
    # members. It is an allocation reservation, not a measured archive size.
    return 2 * sum(map(len, entries.values())) + 4096 * (len(entries) + 1)


def _write_component_archive(
    target: Path, entries: Mapping[str, bytes], *,
    retained_bytes_per_component: int | None = None,
    expanded_bytes_per_component: int | None = None,
) -> Path:
    _require(set(entries) == _COMPONENT_MEMBERS, "NESTED_COMPONENT_MEMBER_SET_INVALID")
    if expanded_bytes_per_component is not None:
        _require(sum(map(len, entries.values())) <= expanded_bytes_per_component,
                 "ZIP_TOTAL_EXPANDED_LIMIT")
    if retained_bytes_per_component is not None:
        _require(_component_archive_size_bound(entries) <= retained_bytes_per_component,
                 "F4_O_FIT_COMPILE_COMPONENT_STORAGE_EXCEEDED")
    write_deterministic_zip(target, entries)
    _read_component(target)
    return target


def _accepted_result_unit_id(outer: int, family: str) -> str:
    slugs = {
        "COX_PH": "cox-ph",
        "RSF": "rsf",
        "GBM_COX": "gbm-cox",
        "XGBOOST_COX": "xgboost-cox",
        "FPM_TVC_SET_A": "fpm-tvc-set-a",
        "COXTIME_SET_A": "coxtime-set-a",
    }
    if family == "ELASTIC_NET_COX":
        return f"selector-f{outer}-elastic-net-cox"
    _require(family in slugs, "NESTED_ACCEPTED_FAMILY_INVALID")
    return f"model-f{outer}-{slugs[family]}"


def _outer_template_entries(
    source_entries: Mapping[str, bytes], *, outer: int, imputation: int,
    heldout_covariates: bytes,
) -> dict[str, bytes]:
    from .f4 import _f4_model_seed

    _require(set(source_entries) == _COMPONENT_MEMBERS,
             "NESTED_POST_LOCK_TEMPLATE_SOURCE_INVALID")
    task = strict_json_bytes(source_entries["task.json"], "NESTED_TEMPLATE_TASK")
    family = task.get("family")
    coordinates = {
        "purpose": "NESTED_OUTER",
        "outer_fold": outer,
        "repeat": 0,
        "inner_fold": 0,
        "imputation": imputation,
    }
    seed = _f4_model_seed(family, coordinates)
    stochastic = family in {"RSF", "GBM_COX", "XGBOOST_COX", "COXTIME_SET_A"}
    task = {
        **task,
        "f4_coordinates": coordinates,
        "registered_model_seed": seed,
        "model_seed": seed if stochastic else None,
    }
    return {
        **dict(source_entries),
        "task.json": canonical_json_bytes(task),
        "prediction-covariates.csv": heldout_covariates,
    }


def _validate_outer_primary_searches(searches, *, outer, science_decision, context=None,
                                    source_bundles=None, _execution_rsf_suffix_preflight=False,
                                    _execution_pending_families=None):
    """Bind all horizon-dependent parameter sources on the original outer path."""
    from .f4 import (_primary_complex_search_source, _retained_full0_source_members,
                     _f45_source_member_sha256)
    from .f2_kernel import predictor_contract
    from .f5 import _validate_primary_complex_search_result

    decision = validate_science_decision(science_decision)
    all_families = {"RSF", "GBM_COX", "XGBOOST_COX", "COXTIME_SET_A"}
    families = set(all_families)
    # The execution owner may validate the three already-complete families
    # before RSF work.  This is not a complete-search acceptance: the public
    # compiler still requires all four through the unchanged default below.
    _require(type(_execution_rsf_suffix_preflight) is bool
             and (not _execution_rsf_suffix_preflight or context is not None
                  and isinstance(source_bundles, Mapping)),
             "NESTED_PRIMARY12_COMPLETE_SEARCHES_REQUIRED")
    if _execution_rsf_suffix_preflight:
        families = families - {"RSF"}
    if _execution_pending_families is not None:
        _require(not _execution_rsf_suffix_preflight and context is not None
                 and isinstance(source_bundles, Mapping)
                 and isinstance(_execution_pending_families, set)
                 and _execution_pending_families <= families,
                 "NESTED_PRIMARY12_COMPLETE_SEARCHES_REQUIRED")
        families = families - _execution_pending_families
    _require(decision.get("four_horizon_development") == four_horizon_contract()
             and isinstance(searches, Mapping) and set(searches) == families,
             "NESTED_PRIMARY12_COMPLETE_SEARCHES_REQUIRED")
    _require(source_bundles is None or isinstance(source_bundles, Mapping)
             and set(source_bundles) <= families,
             "NESTED_PRIMARY12_SEARCH_SOURCE_PROOF_INVALID")
    current = _f45_source_member_sha256() if source_bundles is not None else None
    contexts = []
    for family in sorted(families):
        row = searches[family]
        _require(isinstance(row, Mapping) and set(row) == {"input", "result"}
                 and isinstance(row["input"], Mapping)
                 and set(row["input"]) == {"kind", "task", "spec"}
                 and row["input"]["kind"] == "PADML_F5_Q_INPUT_V1",
                 "NESTED_PRIMARY12_SEARCH_BINDING_INVALID")
        q = row["input"]
        source = _primary_complex_search_source(q["spec"])
        task = q["task"]
        _require(source is not None and source["family"] == family and source["outer_fold"] == outer
                 and isinstance(task, Mapping) and set(task) == {"kind", "source", "training_context", "science_decision"}
                 and task["kind"] == "PADML_NESTED_PRIMARY_OUTER_COMPLEX_SEARCH_TASK_V1"
                 and task["source"] == source and task["science_decision"] == decision
                 and source["science_decision_sha256"] == decision["identity_sha256"],
                 "NESTED_PRIMARY12_SEARCH_BINDING_INVALID")
        training = validate_training_context(task["training_context"])
        _require(training["scope"] == "OUTER" and training["channel"] == "PRIMARY"
                 and training["outer_fold"] == outer and training["heldout_center"] == source["heldout_center"]
                 and training["identity_sha256"] == source["training_context_sha256"]
                 and training["modeling_program_sha256"] == source["producer_source_identity"],
                 "NESTED_PRIMARY12_SEARCH_BINDING_INVALID")
        _validate_primary_complex_search_result(q["spec"], row["result"])
        compared = training
        if source_bundles is not None:
            producer = current
            if family in source_bundles:
                producer = _retained_full0_source_members(
                    source_bundles[family], primary_rsf_inputs=True)
            _require(training["modeling_program_sha256"] == _sha(producer),
                     "NESTED_PRIMARY12_SEARCH_SOURCE_PROOF_INVALID")
            # Only source-bound program identities may differ. The original
            # proof covers recipe-owner changes; all actual scientific inputs
            # below remain byte-for-byte equal, including MICE and seeds.
            preprocessing = {"predictor_contract": predictor_contract(Path(__file__).parent),
                             "recipe_owner": producer["padml/f2_kernel.py"]}
            _require(training["preprocessing_program_sha256"] == _sha(preprocessing),
                     "NESTED_PRIMARY12_SEARCH_TRAINING_DRIFT")
            compared = _sealed({**{key: value for key, value in training.items()
                                   if key != "identity_sha256"},
                "modeling_program_sha256": _sha(current),
                "preprocessing_program_sha256": _sha({**preprocessing,
                    "recipe_owner": current["padml/f2_kernel.py"]})})
        # Comparison only: never rewrite the retained producer or Q result.
        contexts.append(compared)
        if context is not None:
            _require(compared == context,
                     "NESTED_PRIMARY12_SEARCH_TRAINING_DRIFT")
    if contexts:
        _require(all(row == contexts[0] for row in contexts), "NESTED_PRIMARY12_SEARCH_TRAINING_DRIFT")
    else:
        # An execution owner may legitimately begin with all four complex
        # families pending.  There is no completed training context to compare
        # until the original Q owner has produced one, but a partial empty set
        # must still be rejected above by the exact completed/pending split.
        _require(_execution_pending_families == all_families,
                 "NESTED_PRIMARY12_COMPLETE_SEARCHES_REQUIRED")
    return searches


def project_outer_development_from_accepted(
    *, outer: int, science_decision: Mapping[str, Any],
    accepted_f2_run_root: Path, accepted_f1_runtime_root: Path | None,
    scratch: Path,
    admit_io=None,
    retained_bytes_per_component: int | None = None,
    expanded_bytes_per_component: int | None = None,
    selection_horizon_months: int = 24,
    primary_searches: Mapping[str, Mapping[str, Any]] | None = None,
    primary_search_source_bundles: Mapping[str, Path] | None = None,
    primary_selector_root: Path | None = None,
) -> dict[str, Any]:
    """Project training science into the existing F4 component ABI, without fits."""
    from .f4 import load_f4_inputs

    science_decision = validate_science_decision(science_decision)
    # The public projector always opens the accepted producer itself.
    accepted_inputs = load_f4_inputs(
        accepted_f2_run_root, include_o_fit_source=True,
        f1_runtime_root=accepted_f1_runtime_root,
        **({} if admit_io is None else {"admit_io": admit_io}),
    )
    return _project_outer_development_from_inputs(
        accepted_inputs, outer=outer, science_decision=science_decision,
        accepted_f2_run_root=accepted_f2_run_root, scratch=scratch, admit_io=admit_io,
        retained_bytes_per_component=retained_bytes_per_component,
        expanded_bytes_per_component=expanded_bytes_per_component,
        selection_horizon_months=selection_horizon_months, primary_searches=primary_searches,
        primary_search_source_bundles=primary_search_source_bundles, primary_selector_root=primary_selector_root,
    )


def _project_outer_development_from_inputs(
    accepted_inputs: Mapping[str, Any], *, outer: int,
    science_decision: Mapping[str, Any], accepted_f2_run_root: Path, scratch: Path,
    admit_io=None, retained_bytes_per_component: int | None = None,
    expanded_bytes_per_component: int | None = None, on_materialized_fold=None,
    primary_rsf_prepare: bool = False,
    pre_search: bool = False,
    primary_prepare_family: str = "RSF",
    selection_horizon_months: int = 24,
    primary_searches: Mapping[str, Mapping[str, Any]] | None = None,
    primary_search_source_bundles: Mapping[str, Path] | None = None,
    primary_selector_root: Path | None = None,
) -> dict[str, Any]:
    """Body shared only by original readers on one accepted-source call stack.

    This is not a request/cache input: the original F4/F5 consumer owns the
    snapshot from load_f4_inputs. Each projection rebinds acceptance and this outer's
    seven original archives, and opens its F1 fold through original admission.
    """
    from .f2_kernel import (
        _recipe_training_member_bytes,
        _response_rows,
        _write_response_subset,
        predictor_contract,
    )
    from .f4 import (
        _f45_source_member_sha256,
        _materialize_o_fit_fold,
        _o_fit_partitions,
        _prepare_o_fit_partition,
    )

    science_decision = validate_science_decision(science_decision)
    _require(type(pre_search) is bool and (not pre_search or primary_rsf_prepare),
             "NESTED_PRIMARY_PRE_SEARCH_SCOPE_INVALID")
    _require(primary_prepare_family in {"RSF", "GBM_COX", "XGBOOST_COX", "COXTIME_SET_A"}
             and (primary_rsf_prepare or primary_prepare_family == "RSF"),
             "NESTED_PRIMARY12_SEARCH_BINDING_INVALID")
    _require(type(selection_horizon_months) is int and selection_horizon_months in {6, 12, 24, 36}
             and (not primary_rsf_prepare or selection_horizon_months == 24 and primary_searches is None),
             "NESTED_PRIMARY12_SEARCH_BINDING_INVALID")
    if selection_horizon_months != 24:
        _validate_outer_primary_searches(primary_searches, outer=outer, science_decision=science_decision,
                                        source_bundles=primary_search_source_bundles)
    else:
        _require(primary_searches is None and primary_search_source_bundles is None,
                 "NESTED_PRIMARY12_SEARCH_BINDING_INVALID")
    _require(type(primary_rsf_prepare) is bool and (not primary_rsf_prepare
             or science_decision.get("four_horizon_development") == four_horizon_contract()),
             "NESTED_PRIMARY_RSF_PREPARATION_AUTHORITY_INVALID")
    fresh_families = outer_fresh_score_families(science_decision)
    reused_families = science_decision["training_score_reuse"]["families"]
    fresh_seven = science_decision["training_score_reuse"]["confirmed"] == "FRESH_SEVEN_FAMILY_REPLAY"

    frozen = accepted_inputs.get("o_fit_source")
    accepted_result_sha256 = accepted_inputs.get("accepted_result_sha256")
    _require(
        accepted_f2_run_root.is_absolute()
        and accepted_f2_run_root.is_dir()
        and not accepted_f2_run_root.is_symlink(),
        "NESTED_ACCEPTED_F2_ROOT_INVALID",
    )
    acceptance_path = accepted_f2_run_root / "f2-acceptance.json"
    _require(
        acceptance_path.is_file() and not acceptance_path.is_symlink(),
        "NESTED_ACCEPTED_F2_ACCEPTANCE_MISSING",
    )
    if admit_io is not None:
        admit_io(memory_bytes=32 * acceptance_path.stat().st_size)
    acceptance_raw = acceptance_path.read_bytes()
    acceptance = strict_json_bytes(acceptance_raw, "NESTED_ACCEPTED_F2_ACCEPTANCE")
    _require(
        isinstance(frozen, Mapping)
        and isinstance(accepted_result_sha256, Mapping)
        and isinstance(acceptance, Mapping)
        and canonical_json_bytes(acceptance) == acceptance_raw
        and acceptance.get("status") == "SCIENTIFICALLY_ACCEPTED"
        and acceptance.get("result_sha256") == accepted_result_sha256
        and accepted_inputs.get("source", {}).get("f2_acceptance_sha256")
        == sha256_bytes(acceptance_raw)
        and all(
            _accepted_result_unit_id(outer, family) in accepted_result_sha256
            and isinstance(
                accepted_result_sha256[_accepted_result_unit_id(outer, family)], str
            )
            for family in _families()
        )
        and outer in range(1, 7)
        and scratch.is_absolute() and scratch.parent.is_dir() and not scratch.exists(),
        "NESTED_ACCEPTED_OUTER_SOURCE_INVALID",
    )
    for family in _families():
        unit = _accepted_result_unit_id(outer, family)
        result_path = accepted_f2_run_root / "results" / f"{unit}.zip"
        _require(
            result_path.is_file() and not result_path.is_symlink()
            and sha256_file(result_path) == accepted_result_sha256[unit],
            "NESTED_ACCEPTED_SCORE_ARCHIVE_DRIFT",
        )
    scratch.mkdir(mode=0o700)
    io_options = {} if admit_io is None else {"admit_io": admit_io}
    component_limits = {"retained_bytes_per_component": retained_bytes_per_component,
                        "expanded_bytes_per_component": expanded_bytes_per_component}
    registered = _materialize_o_fit_fold(frozen, outer, scratch / "materialized", **io_options)
    if on_materialized_fold is not None:
        # Observe the original admitted materialization; callers cannot supply
        # a replacement fold or skip the source/partition checks below.
        on_materialized_fold(frozen, outer, registered)
    if admit_io is not None:
        admit_io(memory_bytes=32 * len(frozen["response_csv"]))
    partitions = _o_fit_partitions(registered)
    outer_partition = partitions["OUTER", 0, 0]
    registry_outer, = [row for row in frozen["registry"]["outer"] if row["outer_fold"] == outer]
    training_ids = list(registry_outer["analysis_ids"])
    heldout_ids = list(registry_outer["validation_ids"])
    _require(
        outer_partition["fit_ids"] == training_ids
        and outer_partition["evaluation_ids"] == heldout_ids,
        "NESTED_ACCEPTED_OUTER_PARTITION_DRIFT",
    )
    response_fields, response_rows = _response_rows(frozen["response_csv"])
    training_response = _write_response_subset(
        response_fields, response_rows, training_ids, None
    )["private_bytes"]
    covariate_members = outer_partition["covariates"]["members"]
    authority = load_science_authority()["science"]
    context = compile_training_context(
        scope="OUTER",
        outer_fold=outer,
        heldout_center=OUTER_CENTERS[outer - 1],
        training_ids=training_ids,
        heldout_ids=heldout_ids,
        centers_by_patient={patient: frozen["centers"][patient]
                            for patient in [*training_ids, *heldout_ids]},
        training_response_csv=training_response,
        mice_member_set_sha256=_sha(covariate_members),
        preprocessing_program_sha256=_sha({
            "predictor_contract": predictor_contract(Path(__file__).parent),
            "recipe_owner": sha256_file(Path(__file__).with_name("f2_kernel.py")),
        }),
        modeling_program_sha256=_sha(_f45_source_member_sha256()),
        seed_program_sha256=_sha(authority["modeling_seed_policy"]),
    )
    models = {family: frozen["models"][outer, family] for family in _families()}
    if selection_horizon_months != 24:
        _validate_outer_primary_searches(primary_searches, outer=outer,
            science_decision=science_decision, context=context,
            source_bundles=primary_search_source_bundles)
        _require(all(row["input"]["spec"]["registered_inputs_identity_sha256"] == registered["identity"]
                     for row in primary_searches.values()), "NESTED_PRIMARY12_SEARCH_REGISTERED_DRIFT")
    selectors = [model["selector_evidence"] for model in models.values()]
    selected_parent_sets = {tuple(selector["selected_parents"]) for selector in selectors}
    common_design_dfs = {selector["common_set_design_df"] for selector in selectors}
    training_event_counts = {selector["outer_training_event_count"] for selector in selectors}
    selector_hashes = {model["selector_evidence_sha256"] for model in models.values()}
    _require(
        len(selected_parent_sets) == len(common_design_dfs)
        == len(training_event_counts) == len(selector_hashes) == 1,
        "NESTED_ACCEPTED_OUTER_SETA_DRIFT",
    )
    selected_parents = list(next(iter(selected_parent_sets)))
    common_design_df = next(iter(common_design_dfs))
    training_event_count = next(iter(training_event_counts))
    primary_selector = None
    if primary_selector_root is not None:
        from .f5 import _primary_selector_program
        state = {"projection": {"training_context": context,
            "f2_acceptance_sha256": accepted_inputs["source"]["f2_acceptance_sha256"]},
            "frozen": frozen, "registered": registered, "source_registered_identity": registered["identity"]}
        primary_selector = _primary_selector_program(state, primary_selector_root, replay=True, workers=None, resource_policy=None)
        selected_parents = primary_selector["selector"]["selected_parents"]
        common_design_df = primary_selector["selector"]["common_set_design_df"]
        selector_hashes = {primary_selector["identity_sha256"]}
    if primary_rsf_prepare:
        # This is the original accepted F1/F2 call stack, not a caller-supplied
        # replacement registered header. The original component compiler proves
        # every INNER member/response/recipe binding; none of its locked O_FIT
        # parameters or seeds becomes a candidate-search task.
        _require(common_design_df > 0 and training_event_count / common_design_df >= 15,
                 "NESTED_PRIMARY_RSF_SETA_EPV_INVALID")
        for repeat in range(1, 4):
            for inner in range(1, 6):
                jobs = _prepare_o_fit_partition(models[primary_prepare_family], partitions["INNER", repeat, inner], frozen,
                    locked_scoring_decision=science_decision, **io_options)
                _require(len(jobs) == M, "NESTED_PRIMARY_RSF_SOURCE_INCOMPLETE")
                del jobs
        projected = {
            "training_context": context, "science_decision": science_decision,
            "f1_identity": frozen["f1_manifest"]["identity"],
            "f2_acceptance_sha256": accepted_inputs["source"]["f2_acceptance_sha256"],
            ("accepted_rsf_result_sha256" if primary_prepare_family == "RSF" else "accepted_model_result_sha256"):
                accepted_result_sha256[_accepted_result_unit_id(outer, primary_prepare_family)],
            "selector_evidence_sha256": next(iter(selector_hashes)),
            "selector_recipe_set_sha256": models[primary_prepare_family]["selector_evidence"]["recipe_set"]["recipe_set_sha256"],
            "outer_recipe_sha256": models[primary_prepare_family]["selector_evidence"]["outer_recipe_sha256"],
            "selected_parents": selected_parents, "common_set_design_df": common_design_df,
            "training_event_count": training_event_count,
            "registered": registered,
        }
        if pre_search:
            return _outer_pre_search_projection(projected, frozen, admit_io=admit_io)
        return projected
    reused = [project_accepted_training_score(
        models[family],
        source_result_sha256=accepted_result_sha256[
            _accepted_result_unit_id(outer, family)
        ],
        training_context_sha256=context["identity_sha256"],
    ) for family in reused_families]
    return _project_outer_scoring_suffix(
        frozen=frozen, models=models, partitions=partitions,
        outer_partition=outer_partition, outer=outer, scratch=scratch,
        context=context, science_decision=science_decision,
        f2_acceptance_sha256=accepted_inputs["source"]["f2_acceptance_sha256"],
        reused=reused, selector_evidence_sha256=next(iter(selector_hashes)),
        selected_parents=selected_parents, common_design_df=common_design_df,
        training_event_count=training_event_count, training_response=training_response,
        heldout_ids=heldout_ids, fresh_families=fresh_families, fresh_seven=fresh_seven,
        primary_searches=primary_searches, selection_horizon_months=selection_horizon_months,
        admit_io=admit_io, component_limits=component_limits, primary_selector=primary_selector)


def _project_outer_scoring_suffix(*, frozen, models, partitions, outer_partition,
        outer, scratch, context, science_decision, f2_acceptance_sha256, reused,
        selector_evidence_sha256, selected_parents, common_design_df,
        training_event_count, training_response, heldout_ids, fresh_families,
        fresh_seven, primary_searches, selection_horizon_months, admit_io,
        component_limits, prediction_only=False, primary_selector=None):
    """Original component/template compilation, after the caller's source checks.

    This internal extraction is not an alternate accepted-source entry. A future
    transported-input caller must validate its original scoped members first;
    no caller-supplied source pins establish scientific acceptance here.
    """
    from .f4 import _prepare_o_fit_partition
    from .f2_kernel import _recipe_training_member_bytes

    io_options = {} if admit_io is None else {"admit_io": admit_io}
    if primary_selector is not None:
        io_options["primary_selector"] = primary_selector
    component_root = scratch / "components"
    component_root.mkdir(mode=0o700)
    score_components = []
    partition_records = []
    for repeat in range(1, 4):
        for inner in range(1, 6):
            part = partitions["INNER", repeat, inner]
            partition_records.append({
                "partition_id": part["partition_id"],
                "repeat": repeat,
                "inner_fold": inner,
                "fit_ids": list(part["fit_ids"]),
                "evaluation_ids": list(part["evaluation_ids"]),
            })
            for family in fresh_families:
                jobs = _prepare_o_fit_partition(models[family], part, frozen,
                    locked_scoring_decision=science_decision if fresh_seven else None,
                    **({"primary_search": (primary_searches[family]["input"], primary_searches[family]["result"])}
                       if primary_searches is not None and family in primary_searches else {}), **io_options)
                _require(len(jobs) == M, "NESTED_SCORE_COMPONENT_COMPILATION_INCOMPLETE")
                if admit_io is not None:
                    admit_io(component_bytes={
                        component_root / f"score-{family}-R{repeat}-K{inner}-M{imputation:02d}.zip":
                        _component_archive_size_bound(job["entries"])
                        for imputation, job in enumerate(jobs, 1)},
                        memory_bytes=32 * max(sum(map(len, job["entries"].values())) for job in jobs))
                for imputation, job in enumerate(jobs, start=1):
                    path = component_root / f"score-{family}-R{repeat}-K{inner}-M{imputation:02d}.zip"
                    _write_component_archive(path, job["entries"], **component_limits)
                    score_components.append({
                        "family": family,
                        "repeat": repeat,
                        "inner_fold": inner,
                        "imputation": imputation,
                        "archive": path,
                    })
    templates: dict[str, list[Path]] = {}
    for family in _families():
        jobs = _prepare_o_fit_partition(models[family], outer_partition, frozen,
            **({"prediction_only": True} if prediction_only else {}),
            **({"primary_search": (primary_searches[family]["input"], primary_searches[family]["result"])}
               if primary_searches is not None and family in primary_searches else {}), **io_options)
        _require(len(jobs) == M, "NESTED_POST_LOCK_TEMPLATE_COMPILATION_INCOMPLETE")
        rows, prepared = [], []
        for imputation, job in enumerate(jobs, start=1):
            covariate_path = Path(outer_partition["covariates"]["input_dir"]) / f"imp{imputation:02d}.csv"
            if admit_io is not None:
                admit_io(memory_bytes=32 * covariate_path.stat().st_size)
            heldout_covariates = _recipe_training_member_bytes(covariate_path, heldout_ids)
            entries = _outer_template_entries(
                job["entries"], outer=outer, imputation=imputation,
                heldout_covariates=heldout_covariates,
            )
            path = component_root / f"final-{family}-M{imputation:02d}.zip"
            prepared.append((path, entries))
        if admit_io is not None:
            admit_io(component_bytes={path: _component_archive_size_bound(entries) for path, entries in prepared},
                     memory_bytes=32 * max(sum(map(len, entries.values())) for _, entries in prepared))
        for path, entries in prepared:
            _write_component_archive(path, entries, **component_limits)
            rows.append(path)
        templates[family] = rows
    return {
        "training_context": context,
        "science_decision": science_decision,
        **({"origin": "CURRENT_RAW_CONTEXT", "raw_context_sha256": frozen["raw_context_sha256"]}
           if frozen.get("origin") == "CURRENT_RAW_CONTEXT" else
           {"f1_identity": frozen["f1_manifest"]["identity"], "f2_acceptance_sha256": f2_acceptance_sha256}),
        "reused_training_scores": reused,
        "selector_evidence_sha256": selector_evidence_sha256,
        "training_response_csv": training_response,
        "development_metadata": {"epv_resolution": (primary_selector["selector"]["epv_resolution"] if primary_selector is not None else {
            "preferred_minimum": 15, "minimum": 15, "fallback_used": False,
            "source": "ACCEPTED_F2_SELECTOR", "selector_evidence_sha256": selector_evidence_sha256}),
            "selected_parents": selected_parents,
            "common_set_design_df": common_design_df,
            "training_event_count": training_event_count,
            "baseline_policy_sha256": _sha({
                "horizons": list(HORIZONS),
                "cox_ties": "BRESLOW",
                "family_specific_native_baseline": True,
            }),
            "seed_policy_sha256": context["seed_program_sha256"],
        },
        "score_partitions": partition_records,
        "score_components": score_components,
        "post_lock_templates": templates,
        "selection_horizon_months": selection_horizon_months,
        **({"primary_searches": primary_searches} if primary_searches is not None else {}),
    }


def _outer_pre_search_projection(projected, frozen, *, admit_io=None):
    """Project an already source-checked outer; do not grant source acceptance.

    Returns the fields and exact existing files for the original o-fit carrier.
    It neither copies files nor produces scores/templates/ZIPs. The canonical
    source reader must still rebuild these fields at final acceptance.
    """
    from .f4 import _o_fit_partitions
    from .f2_kernel import _registered_partition_identity_record, _response_rows, _write_response_subset
    reason = "NESTED_PRIMARY_PRE_SEARCH_SOURCE_INVALID"
    context = validate_training_context(projected["training_context"])
    outer = context["outer_fold"]
    partitions = _o_fit_partitions(projected["registered"])
    fields, responses = _response_rows(frozen["response_csv"])
    training = _write_response_subset(fields, responses, context["training_ids"], None)["private_bytes"]
    validate_training_context(context, training)
    files, rows, identities = {}, [], {}
    for coordinate, original in partitions.items():
        prediction_only = coordinate == ("OUTER", 0, 0)
        _registered_partition_identity_record(original)
        names = {"kind", "partition_id", "repeat", "inner_fold", "fit_ids", "evaluation_ids",
                 "evaluation_ids_sha256", "application_ids", "fit_covariate_members"}
        if original["kind"] == "STOP":
            names.add("consumer_set")
        row = {key: original[key] for key in names}
        prefix = f"primary/partitions/{len(rows):02d}"
        cov_fields = {"schema_version", "kind", "status", "partition_id", "members",
            "analysis_view_sha256", "application_view_sha256", "analysis_ids_sha256",
            "application_ids_sha256", "data_identity"}
        _require(set(original["covariates"]) == cov_fields | {"input_dir"}, reason)
        cov = {key: original["covariates"][key] for key in cov_fields}
        directory = Path(original["covariates"]["input_dir"])
        _require(directory.is_absolute() and directory.is_dir() and not directory.is_symlink(), reason)
        for member in cov["members"]:
            _require(member["name"] in {f"imp{i:02d}.csv" for i in range(1, 21)}, reason)
            files[f"{prefix}/covariates/{member['name']}"] = directory / member["name"]
        row["covariates"] = {**cov, "input_dir": prefix + "/covariates"}
        for role in ("fit_response", "evaluation_response"):
            if prediction_only and role == "evaluation_response":
                continue
            response = dict(original[role])
            _require(set(response) in ({"event_count", "row_count", "row_ids_sha256", "sha256", "size_bytes", "path"},
                {"event_count", "row_count", "row_ids_sha256", "sha256", "size_bytes", "private_bytes"}), reason)
            payload = response.pop("private_bytes", None)
            source_path = response.pop("path", None)
            _require((isinstance(payload, bytes) and source_path is None)
                     or payload is None and isinstance(source_path, str), reason)
            relative = f"{prefix}/{role}.csv"
            row[role] = {**response, "path": relative}
            files[relative] = payload if payload is not None else Path(source_path)
        identity = _registered_partition_identity_record(row, prediction_only=prediction_only)
        identities[row["partition_id"]] = identity
        rows.append(row)
    models = {}
    selector_fields = {"selected_parents", "common_set_design_df", "outer_training_event_count",
                       "recipe_set", "outer_recipe_sha256"}
    for family in _families():
        model = frozen["models"][outer, family]
        _require(model["fold"] == outer and model["family"] == family and model["status"] == "PASS"
                 and model["selected_spec_sha256"] == _sha(model["selected_spec"]), reason)
        model_partitions = {row["partition_id"]: row for row in model["model_input"]["model_partitions"]}
        selected = []
        for original, row in zip(partitions.values(), rows, strict=True):
            _require(model_partitions[row["partition_id"]] == _registered_partition_identity_record(original), reason)
            selected.append(identities[row["partition_id"]])
        models[family] = {key: model[key] for key in (
            "fold", "family", "status", "selected_spec", "selected_spec_sha256", "selector_evidence_sha256")}
        models[family]["selector_evidence"] = {key: model["selector_evidence"][key] for key in selector_fields}
        models[family]["model_input"] = {"model_partitions": selected}
    registry = {}
    for kind, name in (("OUTER", "outer"), ("INNER", "inner"), ("STOP", "stopping")):
        registry[name] = [{key: row[key] for key in (
            "outer_fold", "partition_id", "analysis_ids", "application_ids",
            "stop_ids" if kind == "STOP" else "validation_ids", *(() if kind == "OUTER" else ("repeat", "inner_fold")))}
            for row in frozen["registry"][name] if row["outer_fold"] == outer]
    registered = {key: projected["registered"][key] for key in (
        "schema_version", "kind", "status", "fold", "outer_count", "inner_count", "stop_count",
        "diagnostic_count", "view_count")}
    registered["partitions"] = rows
    metadata = {key: projected[key] for key in ("training_context", "science_decision", "f1_identity",
        "f2_acceptance_sha256", "selector_evidence_sha256", "selector_recipe_set_sha256", "outer_recipe_sha256",
        "selected_parents", "common_set_design_df", "training_event_count")}
    value = {"projection": metadata, "registered": registered,
        "source_registered_identity": projected["registered"]["identity"], "models": models, "registry": registry,
        "centers": {patient: frozen["centers"][patient] for patient in context["training_ids"] + context["heldout_ids"]},
        "accepted_result_sha256": {_accepted_result_unit_id(outer, family):
            frozen["accepted_result_sha256"][_accepted_result_unit_id(outer, family)] for family in _families()}}
    # Use the same physical reader as restoration before handing files to a ZIP writer.
    _restore_outer_pre_search_projection(value, files, training, admit_io=admit_io)
    return {"pre_search": value, "members": files, "training_response_csv": training}


def _restore_outer_pre_search_projection(value, members, training_response, *, admit_io=None):
    """Read exact pre-search members; this is not canonical source acceptance."""
    from .f4 import _o_fit_partitions
    from .f2_kernel import (_registered_partition_identity_record, _response_rows, _write_response_subset,
        _validate_transform_recipe_set, _locked_family_parameters, predictor_contract)
    reason = "NESTED_PRIMARY_PRE_SEARCH_SOURCE_INVALID"
    _require(isinstance(value, Mapping) and set(value) == {"projection", "registered", "source_registered_identity", "models",
             "registry", "centers", "accepted_result_sha256"}, reason)
    validate_sha256(value["source_registered_identity"], "source_registered_identity")
    _require(set(value["projection"]) == {"training_context", "science_decision", "f1_identity",
        "f2_acceptance_sha256", "selector_evidence_sha256", "selector_recipe_set_sha256", "outer_recipe_sha256",
        "selected_parents", "common_set_design_df", "training_event_count"}, reason)
    if admit_io is not None:
        admit_io(memory_bytes=32 * 32 * 1024**2)
    raw = canonical_json_bytes(value)
    _require(len(raw) <= 32 * 1024**2, reason)
    context = validate_training_context(value["projection"]["training_context"], training_response)
    response_fields, response_rows = _response_rows(training_response)
    train, heldout = set(context["training_ids"]), set(context["heldout_ids"])
    _require(train.isdisjoint(heldout) and set(value["centers"]) == train | heldout
             and set(value["models"]) == set(_families())
             and set(value["accepted_result_sha256"]) == {_accepted_result_unit_id(context["outer_fold"], family)
                 for family in _families()} and set(value["registry"]) == {"outer", "inner", "stopping"}, reason)
    for digest in value["accepted_result_sha256"].values():
        validate_sha256(digest, "accepted_result_sha256")
    registered = strict_json_bytes(canonical_json_bytes(value["registered"]))
    _require(set(registered) == {"schema_version", "kind", "status", "fold", "outer_count",
             "inner_count", "stop_count", "diagnostic_count", "view_count", "partitions"}
             and registered["kind"] == "PADML_F2_REGISTERED_PARTITION_INPUTS"
             and registered["status"] == "PASS" and registered["fold"] == context["outer_fold"], reason)
    parts = _o_fit_partitions(registered)
    for model in value["models"].values():
        _validate_transform_recipe_set(model["selector_evidence"]["recipe_set"], predictor_contract(Path(__file__).parent), expected_count=16)
        _locked_family_parameters(model["family"], model["selected_spec"])
    expected = set()
    for coordinate, row in parts.items():
        prediction_only = coordinate == ("OUTER", 0, 0)
        allowed = {"kind", "partition_id", "repeat", "inner_fold", "fit_ids", "evaluation_ids",
                   "evaluation_ids_sha256", "application_ids", "fit_covariate_members", "covariates", "fit_response"}
        if not prediction_only:
            allowed.add("evaluation_response")
        if row["kind"] == "STOP":
            allowed.add("consumer_set")
        _require(set(row) == allowed, reason)
        _require(set(row["fit_ids"]) <= train
                 and (set(row["fit_ids"]) == train and set(row["evaluation_ids"]) == heldout
                      if prediction_only else set(row["evaluation_ids"]) <= train
                      and set(row["application_ids"]) <= train)
                 and ("evaluation_response" not in row if prediction_only else "evaluation_response" in row), reason)
        identity = _registered_partition_identity_record(row, prediction_only=prediction_only)
        registry_name = {"OUTER": "outer", "INNER": "inner", "STOP": "stopping"}[row["kind"]]
        registry_rows = [item for item in value["registry"][registry_name] if item["partition_id"] == row["partition_id"]]
        registry_expected = {"outer_fold": context["outer_fold"], "partition_id": row["partition_id"],
            "analysis_ids": row["fit_ids"], "application_ids": row["application_ids"],
            "stop_ids" if row["kind"] == "STOP" else "validation_ids": row["evaluation_ids"]}
        if not prediction_only:
            registry_expected.update(repeat=row["repeat"], inner_fold=row["inner_fold"])
        _require(registry_rows == [registry_expected], reason)
        for family, model in value["models"].items():
            _require(set(model) == {"fold", "family", "status", "selected_spec", "selected_spec_sha256",
                     "selector_evidence_sha256", "selector_evidence", "model_input"}
                     and model["fold"] == context["outer_fold"] and model["family"] == family
                     and model["status"] == "PASS" and model["selected_spec_sha256"] == _sha(model["selected_spec"])
                     and set(model["selector_evidence"]) == {"selected_parents", "common_set_design_df",
                         "outer_training_event_count", "recipe_set", "outer_recipe_sha256"}
                     and set(model["model_input"]) == {"model_partitions"}, reason)
            _require(len(model["model_input"]["model_partitions"]) == 31
                     and model["selector_evidence_sha256"] == value["projection"]["selector_evidence_sha256"]
                     and model["selector_evidence"]["selected_parents"] == value["projection"]["selected_parents"]
                     and model["selector_evidence"]["common_set_design_df"] == value["projection"]["common_set_design_df"]
                     and model["selector_evidence"]["outer_training_event_count"] == value["projection"]["training_event_count"], reason)
            matched = [part for part in model["model_input"]["model_partitions"] if part["partition_id"] == row["partition_id"]]
            _require(matched == [identity], reason)
        for role in ("fit_response", "evaluation_response"):
            if role not in row:
                continue
            record = row[role]
            _require(set(record) == {"event_count", "row_count", "row_ids_sha256", "sha256", "size_bytes", "path"}, reason)
            relative = record["path"]
            expected.add(relative)
            path = members[relative]
            _require(isinstance(path, bytes) or isinstance(path, Path) and path.is_absolute()
                     and path.is_file() and not path.is_symlink() and path.resolve(strict=True) == path, reason)
            size = len(path) if isinstance(path, bytes) else path.stat().st_size
            _require(size == record["size_bytes"], reason)
            if admit_io is not None:
                admit_io(memory_bytes=32 * size)
            payload = path if isinstance(path, bytes) else path.read_bytes()
            _require(sha256_bytes(payload) == record["sha256"], reason)
            _, outcomes = _response_rows(payload)
            _require(set(outcomes) == set(row["fit_ids"] if role == "fit_response" else row["evaluation_ids"])
                     and set(outcomes) <= train
                     and payload == _write_response_subset(response_fields, response_rows,
                         row["fit_ids"] if role == "fit_response" else row["evaluation_ids"], None)["private_bytes"], reason)
            if isinstance(path, bytes):
                _require(role == "evaluation_response", reason)
                del record["path"]
                record["private_bytes"] = payload
            else:
                record["path"] = str(path)
        cov = row["covariates"]
        _require(set(cov) == {"schema_version", "kind", "status", "partition_id", "members", "input_dir",
            "analysis_view_sha256", "application_view_sha256", "analysis_ids_sha256", "application_ids_sha256", "data_identity"}, reason)
        _require([record["name"] for record in cov["members"]] == [f"imp{i:02d}.csv" for i in range(1, 21)], reason)
        directories = set()
        for record in cov["members"]:
            relative = cov["input_dir"] + "/" + record["name"]
            expected.add(relative)
            path = members[relative]
            _require(isinstance(path, Path) and path.is_absolute() and path.is_file() and not path.is_symlink()
                     and path.resolve(strict=True) == path
                     and path.stat().st_size == record["size_bytes"]
                     and set(record) == {"name", "size_bytes", "sha256"}, reason)
            if admit_io is not None:
                admit_io(memory_bytes=32 * path.stat().st_size)
            _require(sha256_file(path) == record["sha256"], reason)
            reader = csv.DictReader(io.StringIO(path.read_text(encoding="utf-8-sig")))
            _require(reader.fieldnames == load_science_authority()["science"]["mice"]["private_handoff"]["columns"], reason)
            observed = list(reader)
            _require([item["Patient_ID"] for item in observed] == row["application_ids"]
                     and all(item["Center"] == value["centers"][item["Patient_ID"]] for item in observed), reason)
            directories.add(path.parent)
        _require(len(directories) == 1, reason)
        cov["input_dir"] = str(next(iter(directories)))
    _require(set(members) == expected and all(not Path(name).is_absolute() and ".." not in Path(name).parts
             for name in members), reason)
    _require([len(value["registry"][name]) for name in ("outer", "inner", "stopping")] == [1, 15, 15], reason)
    outer = context["outer_fold"]
    frozen = {"models": {(outer, family): model for family, model in value["models"].items()},
        "registry": value["registry"], "centers": value["centers"], "response_csv": training_response,
        "f1_manifest": {"identity": value["projection"]["f1_identity"]},
        "f2_acceptance_sha256": value["projection"]["f2_acceptance_sha256"],
        "accepted_result_sha256": value["accepted_result_sha256"],
        "model_payload_sizes": {(outer, family): len(canonical_json_bytes(model))
            for family, model in value["models"].items()}}
    # The historical registration seal is a reference, never the identity of
    # this response-redacted projection. Full owners must bind it explicitly.
    return {"projection": value["projection"], "registered": registered, "frozen": frozen,
            "source_registered_identity": value["source_registered_identity"]}


def _write_exact_once(path: Path, raw: bytes, reason: str) -> None:
    _require(path.is_absolute() and path.parent.is_dir()
             and path.parent.resolve(strict=True) == path.parent, reason)
    if path.exists():
        _require(
            path.is_file() and not path.is_symlink() and path.stat().st_size == len(raw),
            reason,
        )
        with path.open("rb") as stream:
            _require(stream.read(len(raw) + 1) == raw, reason)
        return
    _require(path.parent.is_dir() and not path.parent.is_symlink(), reason)
    descriptor, temporary_name = tempfile.mkstemp(
        prefix=f".{path.name}.pending-", dir=path.parent
    )
    temporary = Path(temporary_name)
    try:
        with os.fdopen(descriptor, "wb") as stream:
            stream.write(raw)
            stream.flush()
            os.fsync(stream.fileno())
        try:
            os.link(temporary, path)
        except FileExistsError:
            _require(
                path.is_file() and not path.is_symlink()
                and path.stat().st_size == len(raw),
                reason,
            )
            with path.open("rb") as stream:
                _require(stream.read(len(raw) + 1) == raw, reason)
        directory = os.open(path.parent, os.O_RDONLY)
        try:
            os.fsync(directory)
        finally:
            os.close(directory)
    finally:
        temporary.unlink(missing_ok=True)


def _validate_full_final_component(
    raw: bytes | Path, *, context: Mapping[str, Any], lock: Mapping[str, Any],
    parsed_component: tuple[dict[str, Any], dict[str, Any], dict[str, bytes]] | None = None,
) -> dict[str, Any]:
    """Bind the complete apparent/full0 population to its local M20 lock."""
    from .f2_kernel import _expected_family_parent_column_map, predictor_contract
    from .f4 import _f4_native_component_inputs
    from .f5 import _validate_final_design_recipe

    # Same-invocation callers retain the actual parsed input, not a PASS flag.
    task, recipe, entries = _read_component(raw) if parsed_component is None else parsed_component
    context = validate_training_context(context, entries["fit-response.csv"])
    lock = validate_development_lock(lock, context=context)
    _require(context["scope"] == "FULL_DATA" and context["channel"] == "PRIMARY"
             and lock["outer_fold"] == 0 and lock["heldout_center"] is None
             and lock["heldout_ids_sha256"] == _sha([]), "NESTED_FULL_FINAL_COMPONENT_SCOPE_INVALID")
    _, _, training, _, application, apparent = _f4_native_component_inputs(entries)
    recipe = _validate_final_design_recipe(recipe, family=task["family"], selected_parents=task["selected_parents"])
    _require(recipe["transform_recipe"] is None or recipe["transform_recipe"]["partition_id"] == "F5_FINAL_FULL_DATA",
             "NESTED_FULL_FINAL_RECIPE_INVALID")
    if task["family"] == "ELASTIC_NET_COX":
        _require(task["f4_nested_full_final_elastic_source"]["full_transform_recipe"] == recipe["transform_recipe"],
                 "NESTED_FULL_FINAL_ELASTIC_RECIPE_DRIFT")
    ids, _, centers = _covariate_ids(entries["fit-covariates.csv"], "NESTED_FULL_FINAL")
    source, imputation = task["nested_full_final_source"], task["imputation"]
    template = {key: value for key, value in task.items() if key != "development_lock_sha256"}
    column_map = _expected_family_parent_column_map(task["selected_parents"], task["family"],
        predictor_contract(Path(__file__).parent), recipe["transform_recipe"])
    _require(apparent and training == application and ids == context["training_ids"]
             and centers == context["centers_by_patient"] and task == bind_post_lock_task(template, lock)
             and task["parameters"] == lock["parameters_by_imputation"][imputation - 1]
             and _sha(recipe) == lock["recipe_sha256_by_imputation"][imputation - 1]
             and source["training_context_sha256"] == lock["training_context_sha256"]
             and source["family_decision_sha256"] == lock["family_decision_sha256"]
             and source["selected_spec_sha256"] == lock["selected_spec_sha256"]
             and source["selector_development_sha256"] == lock["selector_evidence_sha256"]
             and source["training_ids_sha256"] == lock["training_ids_sha256"]
             and source["training_response_sha256"] == context["training_response_sha256"]
             and task["family_design_column_count"] == sum(len(row["columns"]) for row in column_map),
             "NESTED_FULL_FINAL_COMPONENT_LOCK_DRIFT")
    return {"family": task["family"], "imputation": imputation, "repeat": 0, "inner_fold": 0,
            "registered_model_seed": task["registered_model_seed"], "task_sha256": _sha(task),
            "recipe_sha256": _sha(recipe), "parameter_sha256": _sha(task["parameters"]),
            "fit_ids_sha256": _sha(ids), "prediction_ids_sha256": _sha(ids),
            "fit_response_sha256": sha256_bytes(entries["fit-response.csv"]),
            "development_lock_sha256": lock["identity_sha256"]}


def _component_execution_receipt(
    *, component_path: Path, output_root: Path, record: Mapping[str, Any],
    context: Mapping[str, Any], development_lock_sha256: str | None,
) -> tuple[dict[str, Any], dict[str, Any], dict[str, Any]]:
    if context["scope"] == "FULL_DATA":
        _require(component_path.is_file() and not component_path.is_symlink(), "NESTED_COMPONENT_SOURCE_INVALID")
        with component_path.open("rb") as stream:
            source_raw = stream.read(record["size_bytes"] + 1)
        _require(len(source_raw) == record["size_bytes"] and sha256_bytes(source_raw) == record["sha256"],
                 "NESTED_COMPONENT_SOURCE_REQUEST_DRIFT")
        task, recipe, input_entries = _read_component(source_raw)
    else:
        task, recipe, input_entries = _read_component(component_path)
    archive = output_root.with_suffix(".zip")
    entries = read_safe_zip(
        archive,
        expected_members=_COMPONENT_MEMBERS | {
            "model.bin", "baseline.bin", "fit-health.json",
            "training-prediction.json", "prediction.json",
        },
        max_member_bytes=4 * 1024 * 1024 * 1024,
        max_total_bytes=8 * 1024 * 1024 * 1024,
    )
    _require(all(entries[name] == raw for name, raw in input_entries.items()),
             "NESTED_COMPONENT_EXECUTION_INPUT_DRIFT")
    prediction = strict_json_bytes(entries["prediction.json"], "NESTED_COMPONENT_PREDICTION")
    fit_health = strict_json_bytes(entries["fit-health.json"], "NESTED_COMPONENT_HEALTH")
    fit_ids = _response_ids(entries["fit-response.csv"], "NESTED_COMPONENT_RECEIPT")
    application_ids, _, _ = _covariate_ids(
        entries["prediction-covariates.csv"], "NESTED_COMPONENT_RECEIPT"
    )
    body = {
        "component_role": record["role"],
        "family": task["family"],
        "repeat": task["f4_coordinates"]["repeat"],
        "inner_fold": task["f4_coordinates"]["inner_fold"],
        "imputation": task["imputation"],
        "development_lock_sha256": development_lock_sha256,
        "training_context_sha256": context["identity_sha256"],
        "task_sha256": _sha(task),
        "input_sha256": _sha({name: sha256_bytes(raw) for name, raw in sorted(input_entries.items())}),
        "mice_member_sha256": sha256_bytes(entries["fit-covariates.csv"]),
        "recipe_sha256": _sha(recipe),
        "parameter_sha256": _sha(task["parameters"]),
        "training_ids_sha256": _sha(fit_ids),
        "application_ids_sha256": _sha(application_ids),
        "training_response_sha256": sha256_bytes(entries["fit-response.csv"]),
        "model_sha256": sha256_bytes(entries["model.bin"]),
        "baseline_sha256": sha256_bytes(entries["baseline.bin"]),
        "prediction_sha256": _sha(prediction),
        "fit_health_sha256": _sha(fit_health),
        "archive_sha256": sha256_file(archive),
        "model_fit_count": 1,
        "engine_threads": 1,
        "seed": task["registered_model_seed"],
    }
    return _sealed(body), prediction, fit_health


def _score_component_evidence(*, record, context, partition_id, receipt, prediction, fit_health, object_audit,
                              retained_model_source=None):
    """Keep the first native reader's numbers in the existing score member."""
    q_reuse = receipt["component_role"] == "REUSED_FULL0_RSF_Q_SCORE"
    return _sealed({
        "schema_version": SCHEMA_VERSION,
        "kind": "PADML_NESTED_LOCO_SCORE_COMPONENT_EVIDENCE_V1",
        "status": "SEALED_RESPONSE_FREE", "program_id": PROGRAM_ID,
        "family": record["family"], "outer_fold": context["outer_fold"],
        "repeat": record["repeat"], "inner_fold": record["inner_fold"],
        "imputation": record["imputation"], "partition_id": partition_id,
        "request_component_path": record["path"], "request_component_sha256": record["sha256"],
        "receipt": receipt, "prediction": prediction, "fit_health": fit_health, "object_audit": object_audit,
        "model_binary_retained": not q_reuse, "baseline_binary_retained": not q_reuse,
        "heldout_outcome_read_count": 0,
        **({"retained_model_source": retained_model_source} if retained_model_source is not None else {}),
    })


def _score_fresh_family(
    *, family: str, request: Mapping[str, Any], root: Path,
    outputs: Mapping[str, dict[str, Any]],
    retained_request: Mapping[str, Any] | None = None,
) -> tuple[dict[str, Any], dict[str, Any]]:
    from .f2_kernel import (
        _evaluate_prediction_seal,
        _monthly_prediction_seal,
        _prediction_evaluation_context, _development_evaluation_indices,
        _pool_prediction_batch,
        _seal_prediction_matrix,
        _trial_summary_from_pooled,
        _trial_scoring_context,
        _write_response_subset,
        _response_rows,
    )

    context = request["training_context"]
    evidence_context = context
    retained_records = None
    reused_inputs = getattr(outputs, "reused_inputs", None)
    reused_components = getattr(outputs, "reused_components", {})
    _require(not reused_components or retained_request is None, "F45_SCORE_REUSE_SOURCE_INVALID")
    if retained_request is not None:
        from .f5 import _FullScoreArchiveOutputs, _full0_cox_reuse_request_pair
        _full0_cox_reuse_request_pair(retained_request, request)
        _require(family == retained_request["component_records"][0]["family"]
                 and isinstance(outputs, _FullScoreArchiveOutputs)
                 and outputs.transported_request == retained_request and outputs.prepared_request == request
                 and outputs.prepared_request_root == root / "request",
                 "NESTED_FULL0_COX_REUSE_INPUT_INVALID")
        evidence_context = retained_request["training_context"]
        retained_records = {row["path"]: row for row in retained_request["component_records"]}
    full_score = context["scope"] == "FULL_DATA"
    horizon = selection_horizon(request["selection_horizon_months"])
    science = validate_science_decision(request["science_decision"])
    full_source = None
    if full_score:
        from .f5 import _full_score_family_source
        full_source = _full_score_family_source(request["development"], family)
        _require(full_source.get("selection_horizon_months", 24) == horizon
                 and request["science_decision"] == request["development"]["science_decision"],
                 "NESTED_FULL_SCORE_SELECTION_SCOPE_INVALID")
    selection_scope = {"selection_horizon_months": horizon,
                       "science_decision_sha256": science["identity_sha256"]}
    _require(not full_score or request.get("kind") == "PADML_NESTED_FULL_SCORE_INPUT_V1"
             and request.get("reused_training_scores") == [], "NESTED_FULL_SCORE_INPUT_INVALID")
    response_path = root / "request/training/response.csv"
    _require(response_path.is_file() and not response_path.is_symlink(), "NESTED_SCORE_RESPONSE_INVALID")
    response_raw = response_path.read_bytes()
    validate_training_context(context, response_raw)
    fields, responses = _response_rows(response_raw)
    partition_root = root / f"score-context/{family}"
    partition_root.mkdir(parents=True, exist_ok=True)
    partitions = []
    evaluated = []
    pooled_by_partition = {}
    pooled_evidence = []
    evidence_records = []
    q_archive = None
    evidence_root = root / "score-evidence" / family
    evidence_root.mkdir(parents=True, exist_ok=True)
    records = [row for row in request["component_records"] if row["family"] == family]
    by_coordinate = {
        (row["repeat"], row["inner_fold"], row["imputation"]): row for row in records
    }
    _require(len(by_coordinate) == 300, "NESTED_FRESH_SCORE_COMPONENT_SET_INVALID")
    for definition in request["score_partitions"]:
        repeat, inner = definition["repeat"], definition["inner_fold"]
        directory = partition_root / f"R{repeat}_K{inner}"
        directory.mkdir(exist_ok=True)
        first_record = by_coordinate[repeat, inner, 1]
        _, _, first_entries = _read_component(root / "request" / first_record["path"])
        _write_exact_once(
            directory / "imp01.csv",
            first_entries["prediction-covariates.csv"],
            "NESTED_SCORE_CONTEXT_RESUME_DRIFT",
        )
        fit_response = _write_response_subset(fields, responses, definition["fit_ids"], None)
        evaluation_response = _write_response_subset(
            fields, responses, definition["evaluation_ids"], None
        )
        partition = {
            "partition_id": definition["partition_id"],
            "kind": "INNER",
            "repeat": repeat,
            "inner_fold": inner,
            "fit_ids": definition["fit_ids"],
            "evaluation_ids": definition["evaluation_ids"],
            "covariates": {"input_dir": str(directory)},
            "fit_response": fit_response,
            "evaluation_response": evaluation_response,
        }
        partitions.append(partition)
        fold_context = _prediction_evaluation_context(
            fit_response, evaluation_response, definition["evaluation_ids"], selection_horizon_months=horizon,
            evaluation_indices=_development_evaluation_indices(partition, horizon)
        )
        component_rows = []
        component_predictions = []
        for imputation in range(1, M + 1):
            record = by_coordinate[repeat, inner, imputation]
            reused_unit = reused_components.get(record["path"])
            component_context = (reused_inputs.sources[reused_unit]["request"]["training_context"]
                                 if reused_unit is not None else evidence_context)
            evidence = _validate_score_component_evidence(outputs[record["path"]], context=component_context)
            prediction, receipt = evidence["prediction"], evidence["receipt"]
            q_reuse = receipt["component_role"] == "REUSED_FULL0_RSF_Q_SCORE"
            _require(not q_reuse or full_score and horizon == 12 and family == "RSF",
                     "NESTED_FULL0_RSF_Q_SCORE_SCOPE_INVALID")
            if q_reuse:
                retained = evidence["retained_model_source"]
                current_q = {"sha256": retained["q_archive_sha256"],
                             "size_bytes": retained["q_archive_size_bytes"]}
                declared_q = request["development"]["complex_search_evidence"][0]["retained_q_archive"]
                _require(current_q == {key: declared_q[key] for key in current_q}
                         and retained["request_identity_sha256"] == request["identity_sha256"]
                         and retained["science_decision_sha256"] == full_source["science_decision_sha256"]
                         and (not evidence_records or q_archive == current_q),
                         "NESTED_FULL0_RSF_Q_SCORE_SOURCE_DRIFT")
                q_archive = current_q
            else:
                _require(q_archive is None, "NESTED_FULL0_RSF_Q_SCORE_MIXED_COMPONENTS")
            evidence_record = record if retained_records is None else retained_records[record["path"]]
            if reused_unit is not None:
                evidence_record = reused_inputs.original_records[reused_unit][record["path"]]
            _require(evidence["request_component_path"] == evidence_record["path"]
                     and evidence["request_component_sha256"] == evidence_record["sha256"]
                     and evidence["partition_id"] == definition["partition_id"],
                     "NESTED_SCORE_COMPONENT_EVIDENCE_REQUEST_DRIFT")
            ids = prediction["patient_ids"]
            survival = prediction["survival"][family]
            _require(
                ids == definition["evaluation_ids"]
                and prediction["horizons"] == list(HORIZONS),
                "NESTED_FRESH_SCORE_PREDICTION_ALIGNMENT_INVALID",
            )
            seal = _seal_prediction_matrix(ids, [row[1:] for row in survival], list(HORIZONS[1:]))
            metric = _evaluate_prediction_seal(
                _monthly_prediction_seal(seal),
                fit_response=fit_response,
                evaluation_response=evaluation_response,
                evaluation_context=fold_context,
                selection_horizon_months=horizon,
            )
            evaluated.append({
                "partition_id": definition["partition_id"],
                "imputation": imputation,
                f"ibs_0_{horizon}": metric[f"ibs_0_{horizon}"],
            })
            component_predictions.append({"sealed_prediction": _monthly_prediction_seal(seal)})
            component_rows.append(receipt["identity_sha256"])
            member_path = (
                f"components/score-evidence/{family}/"
                f"R{repeat}_K{inner}_M{imputation:02d}.json"
            )
            local_path = evidence_root / f"R{repeat}_K{inner}_M{imputation:02d}.json"
            _write_exact_once(
                local_path, canonical_json_bytes(evidence),
                "NESTED_SCORE_EVIDENCE_RESUME_DRIFT",
            )
            evidence_records.append({
                "path": member_path,
                "sha256": sha256_file(local_path),
                "size_bytes": local_path.stat().st_size,
                "identity_sha256": evidence["identity_sha256"],
                "component_receipt_sha256": receipt["identity_sha256"],
                **({"reused_score_unit_id": reused_unit} if reused_unit is not None else {}),
                **({"q_archive_sha256": q_archive["sha256"], "q_archive_size_bytes": q_archive["size_bytes"]}
                   if q_reuse else {"native_archive_path": (
                    f"components/score-native/{family}/"
                    f"R{repeat}_K{inner}_M{imputation:02d}.zip"
                ),
                "native_archive_sha256": receipt["archive_sha256"]}),
            })
        pooled_seal = _pool_prediction_batch(component_predictions, list(HORIZONS))
        pooled_by_partition[definition["partition_id"]] = pooled_seal
        pooled = pooled_seal["payload"]["survival"]
        del component_predictions
        pooled_evidence.append({
            "partition_id": definition["partition_id"],
            "repeat": repeat,
            "inner_fold": inner,
            "patient_ids": definition["evaluation_ids"],
            "horizons": list(HORIZONS),
            **__import__("padml.carriers", fromlist=["publish_pooled"]).publish_pooled(pooled,
                patient_ids=definition["evaluation_ids"], receipts=component_rows, family=family, partition=definition["partition_id"]),
            "component_receipt_sha256": component_rows,
        })
    summary = _trial_summary_from_pooled(
        pooled_by_partition, [row[f"ibs_0_{horizon}"] for row in evaluated],
        _trial_scoring_context(partitions, selection_horizon_months=horizon), M
    )
    sample_task, _, _ = _read_component(root / "request" / records[0]["path"])
    _require(not full_score or sample_task["nested_full_score_source"] == full_source,
             "NESTED_FULL_SCORE_PARAMETER_SOURCE_DRIFT")
    if family == "ELASTIC_NET_COX":
        selected_spec = sample_task["f4_nested_full_elastic_source" if full_score else "f4_outer_elastic_source"]["selected_spec"]
    else:
        selected_spec = sample_task["parameters"]
    reused_count = sum("reused_score_unit_id" in row for row in evidence_records)
    reused_units = {row["reused_score_unit_id"] for row in evidence_records if "reused_score_unit_id" in row}
    execution = _sealed({
        "schema_version": SCHEMA_VERSION,
        "kind": "PADML_NESTED_FULL_SCORE_EXECUTION_V1" if full_score else "PADML_NESTED_LOCO_FRESH_SCORE_EXECUTION_V1",
        **selection_scope,
        "family": family,
        "outer_fold": context["outer_fold"],
        "training_context_sha256": context["identity_sha256"],
        "score_partitions_sha256": _sha(request["score_partitions"]),
        "component_count": 300,
        "component_receipt_sha256": [
            row["component_receipt_sha256"] for row in evidence_records
        ],
        "component_evidence_records": evidence_records,
        "pooled_partitions": pooled_evidence,
        "model_fit_count": 300,
        **({"reused_score_sources": {unit: reused_inputs.source_records[unit] for unit in sorted(reused_units)},
            "reused_component_count": reused_count, "new_model_fit_count": 300 - reused_count,
            "new_first_native_audit_count": 300 - reused_count, "new_native_replay_count": 0}
           if reused_count else {}),
        **({"retained_q_archive": q_archive, "new_model_fit_count": 0,
            "new_first_native_audit_count": 0, "new_native_replay_count": 0} if q_archive is not None else {}),
        **({"retained_score_request_sha256": retained_request["identity_sha256"],
            "retained_score_training_context_sha256": evidence_context["identity_sha256"],
            "new_model_fit_count": 0, "new_first_native_audit_count": 0,
            "new_native_replay_count": 0} if retained_request is not None else {}),
        "mice_chain_count": 0,
        "heldout_outcome_read_count": 0,
    })
    score = seal_fresh_training_score(
        family=family,
        outer_fold=context["outer_fold"],
        training_context_sha256=context["identity_sha256"],
        selected_spec=selected_spec,
        selector_evidence_sha256=(request["selector_development_sha256"] if full_score else
                                  request["selector_evidence_sha256"]),
        summary=summary,
        execution_evidence_sha256=execution["identity_sha256"],
        source_kind="FRESH_FULL_DATA_M20_INNER_OOF" if full_score else "FRESH_M20_INNER_OOF",
        **selection_scope,
    )
    return score, execution


_FINAL_RECEIPT_FIELDS = _RECEIPT_FIELDS
_FRESH_EXECUTION_FIELDS = {
    "schema_version", "kind", "family", "outer_fold",
    "training_context_sha256", "score_partitions_sha256", "component_count",
    "component_receipt_sha256", "component_evidence_records",
    "pooled_partitions", "model_fit_count", "mice_chain_count",
    "heldout_outcome_read_count",
}


def validate_fresh_score_execution(value: Any) -> dict[str, Any]:
    """Validate compact, response-free evidence for one fresh score family."""
    from .f2_kernel import _seal_prediction_matrix

    twelve = True
    q_reuse = isinstance(value, Mapping) and "retained_q_archive" in value
    score_reuse = isinstance(value, Mapping) and "retained_score_request_sha256" in value
    component_reuse = isinstance(value, Mapping) and "reused_score_sources" in value
    row = _validate_seal(value, _FRESH_EXECUTION_FIELDS | ({"selection_horizon_months", "science_decision_sha256"}
        if twelve else set()) | ({"retained_q_archive", "new_model_fit_count", "new_first_native_audit_count",
        "new_native_replay_count"} if q_reuse else set()) | ({"retained_score_request_sha256",
        "retained_score_training_context_sha256", "new_model_fit_count", "new_first_native_audit_count",
        "new_native_replay_count"} if score_reuse else set()) | ({"reused_score_sources",
        "reused_component_count", "new_model_fit_count", "new_first_native_audit_count",
        "new_native_replay_count"} if component_reuse else set()), "NESTED_FRESH_SCORE_EXECUTION_INVALID")
    if component_reuse:
        sources = row["reused_score_sources"]
        _require(not score_reuse and not q_reuse and isinstance(sources, Mapping) and 1 <= len(sources) <= 3
                 and type(row["reused_component_count"]) is int and 1 <= row["reused_component_count"] <= 300
                 and all(type(row[name]) is int and row[name] == 300 - row["reused_component_count"]
                         for name in ("new_model_fit_count", "new_first_native_audit_count"))
                 and type(row["new_native_replay_count"]) is int and row["new_native_replay_count"] == 0,
                 "F45_SCORE_REUSE_COUNTS_INVALID")
        kind = "FULL0" if row["outer_fold"] == 0 else "PRIMARY"
        allowed = {f"{kind}-H{h:02d}" + (f"-O{row['outer_fold']}" if row["outer_fold"] else "")
                   for h in SELECTION_HORIZONS if h != row["selection_horizon_months"]}
        _require(set(sources) <= allowed, "F45_SCORE_REUSE_SOURCE_INVALID")
        for unit, pin in sources.items():
            _require(isinstance(pin, Mapping) and set(pin) == {"path", "sha256", "size_bytes"}
                     and pin["path"] == f"score-reuse/{unit}/source.json"
                     and type(pin["size_bytes"]) is int and 0 < pin["size_bytes"] <= 32 * 1024**2,
                     "F45_SCORE_REUSE_SOURCE_INVALID")
            validate_sha256(pin["sha256"], "f45.score_reuse.source")
    if score_reuse:
        _require(not q_reuse and twelve and row["family"] in {"COX_PH", "ELASTIC_NET_COX", "FPM_TVC_SET_A"}
                 and (row["kind"] == "PADML_NESTED_FULL_SCORE_EXECUTION_V1" and row["outer_fold"] == 0
                      or row["kind"] == "PADML_NESTED_LOCO_FRESH_SCORE_EXECUTION_V1"
                      and type(row["outer_fold"]) is int and row["outer_fold"] in range(1, 7))
                 and all(type(row[name]) is int and row[name] == 0 for name in (
                     "new_model_fit_count", "new_first_native_audit_count", "new_native_replay_count")),
                 "NESTED_FULL0_COX_REUSE_EXECUTION_INVALID")
        for name in ("retained_score_request_sha256", "retained_score_training_context_sha256"):
            validate_sha256(row[name], f"nested.full0_cox_reuse.{name}")
    if twelve:
        _require(type(row["selection_horizon_months"]) is int and row["selection_horizon_months"] in SELECTION_HORIZONS
                 and (row["kind"] == "PADML_NESTED_FULL_SCORE_EXECUTION_V1" and row["outer_fold"] == 0
                      or row["kind"] == "PADML_NESTED_LOCO_FRESH_SCORE_EXECUTION_V1"
                      and row["outer_fold"] in range(1, 7)),
                 "NESTED_FRESH_SCORE_EXECUTION_INVALID")
        validate_sha256(row["science_decision_sha256"], "nested.fresh_execution.science_decision")
    if q_reuse:
        archive = row["retained_q_archive"]
        _require(twelve and row["family"] == "RSF" and isinstance(archive, Mapping)
                 and set(archive) == {"sha256", "size_bytes"}
                 and type(archive["size_bytes"]) is int and archive["size_bytes"] > 0
                 and all(type(row[name]) is int and row[name] == 0 for name in (
                     "new_model_fit_count", "new_first_native_audit_count", "new_native_replay_count")),
                 "NESTED_FULL0_RSF_Q_SCORE_EXECUTION_INVALID")
        validate_sha256(archive["sha256"], "nested.full0_rsf_q_score.archive")
    pooled = row.get("pooled_partitions")
    receipts = row.get("component_receipt_sha256")
    records = row.get("component_evidence_records")
    _require(
        row["schema_version"] == SCHEMA_VERSION
        and type(row["outer_fold"]) is int
        and (row["kind"] == "PADML_NESTED_LOCO_FRESH_SCORE_EXECUTION_V1"
             and row["family"] in _families() and row["outer_fold"] in range(1, 7)
             or row["kind"] == "PADML_NESTED_FULL_SCORE_EXECUTION_V1"
             and row["family"] in _families() and row["outer_fold"] == 0)
        and isinstance(records, list) and len(records) == 300
        and isinstance(receipts, list) and len(receipts) == 300
        and len(set(receipts)) == len(receipts)
        and isinstance(pooled, list) and len(pooled) == 15
        and [(item.get("repeat"), item.get("inner_fold")) for item in pooled]
        == [(repeat, inner) for repeat in range(1, 4) for inner in range(1, 6)]
        and row["component_count"] == row["model_fit_count"] == 300
        and row["mice_chain_count"] == 0
        and row["heldout_outcome_read_count"] == 0,
        "NESTED_FRESH_SCORE_EXECUTION_INVALID",
    )
    for digest in receipts:
        validate_sha256(digest, "nested.fresh_execution.component_receipt")
    for digest_name in ("training_context_sha256", "score_partitions_sha256"):
        validate_sha256(row[digest_name], f"nested.fresh_execution.{digest_name}")
    _require(
        all(
            isinstance(record, Mapping)
            and set(record) == {
                "path", "sha256", "size_bytes", "identity_sha256",
                "component_receipt_sha256"}
            | ({"q_archive_sha256", "q_archive_size_bytes"} if q_reuse else
               {"native_archive_path", "native_archive_sha256"})
            | ({"reused_score_unit_id"} if component_reuse and "reused_score_unit_id" in record else set())
            and ("reused_score_unit_id" not in record or record["reused_score_unit_id"] in sources)
            and isinstance(record["path"], str)
            and record["path"]
            == (
                f"components/score-evidence/{row['family']}/"
                f"R{repeat}_K{inner}_M{imputation:02d}.json"
            )
            and type(record["size_bytes"]) is int and record["size_bytes"] > 0
            and (record["q_archive_sha256"] == archive["sha256"]
                 and record["q_archive_size_bytes"] == archive["size_bytes"] if q_reuse else
                 record["native_archive_path"] == (
                f"components/score-native/{row['family']}/"
                f"R{repeat}_K{inner}_M{imputation:02d}.zip"
            ))
            for record, (repeat, inner, imputation) in zip(
                records,
                (
                    (repeat, inner, imputation)
                    for repeat in range(1, REPEAT_COUNT + 1)
                    for inner in range(1, INNER_FOLD_COUNT + 1)
                    for imputation in range(1, M + 1)
                ),
                strict=True,
            )
        )
        and [record["component_receipt_sha256"] for record in records] == receipts
        and len({record["path"] for record in records}) == len(records),
        "NESTED_FRESH_SCORE_EXECUTION_EVIDENCE_RECORD_INVALID",
    )
    for record in records:
        for key in ("sha256", "identity_sha256", "component_receipt_sha256",
                    "q_archive_sha256" if q_reuse else "native_archive_sha256"):
            validate_sha256(record[key], f"nested.fresh_execution.record.{key}")
    if component_reuse:
        _require(sum("reused_score_unit_id" in item for item in records) == row["reused_component_count"]
                 and {item["reused_score_unit_id"] for item in records if "reused_score_unit_id" in item} == set(sources),
                 "F45_SCORE_REUSE_COUNTS_INVALID")
    flattened = []
    for item in pooled:
        _require(
            isinstance(item, Mapping)
            and set(item) == {
                "partition_id", "repeat", "inner_fold", "patient_ids", "horizons",
                ("pooled_survival_ref" if "pooled_survival_ref" in item else "pooled_survival"), "component_receipt_sha256",
            }
            and isinstance(item["partition_id"], str) and bool(item["partition_id"])
            and isinstance(item["patient_ids"], list) and bool(item["patient_ids"])
            and len(item["patient_ids"]) == len(set(item["patient_ids"]))
            and item["horizons"] == list(HORIZONS)
            and isinstance(item["component_receipt_sha256"], list)
            and len(item["component_receipt_sha256"]) == M,
            "NESTED_FRESH_SCORE_EXECUTION_INVALID",
        )
        _seal_prediction_matrix(
            item["patient_ids"], __import__("padml.carriers", fromlist=["pooled_matrix"]).pooled_matrix(item), list(HORIZONS)
        )
        for digest in item["component_receipt_sha256"]:
            validate_sha256(digest, "nested.fresh_execution.partition_receipt")
        flattened.extend(item["component_receipt_sha256"])
    _require(flattened == receipts, "NESTED_FRESH_SCORE_EXECUTION_RECEIPT_DRIFT")
    return row


def _validate_fresh_score_component_numbers(
    *, evidence: Mapping[str, Any], request_record: Mapping[str, Any],
    request_component: Path, task: Mapping[str, Any], recipe: Mapping[str, Any],
    input_entries: Mapping[str, bytes], definition: Mapping[str, Any],
    context: Mapping[str, Any], expected_full_source: Mapping[str, Any] | None,
) -> None:
    """Original score replay checks, shared with the transported-number reader."""
    from .f2_kernel import _expected_family_parent_column_map, _locked_family_parameters, predictor_contract
    from .f5 import _validate_final_r_fit_health, _validate_retained_r_audit_numbers

    family = request_record["family"]
    repeat, inner, imputation = (request_record[name] for name in ("repeat", "inner_fold", "imputation"))
    full_score = context["scope"] == "FULL_DATA"
    if full_score:
        _require(task["nested_full_score_source"] == expected_full_source,
                 "NESTED_FULL_SCORE_PARAMETER_SOURCE_DRIFT")
    receipt, prediction = evidence["receipt"], evidence["prediction"]
    _require(
        evidence["family"] == family
        and (evidence["repeat"], evidence["inner_fold"], evidence["imputation"])
        == (repeat, inner, imputation)
        and evidence["partition_id"] == definition["partition_id"]
        and evidence["request_component_path"] == request_record["path"]
        and evidence["request_component_sha256"] == request_record["sha256"]
        and sha256_file(request_component) == request_record["sha256"]
        and receipt["task_sha256"] == request_record["task_sha256"] == _sha(task)
        and receipt["input_sha256"] == _sha({
            name: sha256_bytes(value)
            for name, value in sorted(input_entries.items())
        })
        and receipt["mice_member_sha256"]
        == sha256_bytes(input_entries["fit-covariates.csv"])
        and receipt["recipe_sha256"] == request_record["recipe_sha256"] == _sha(recipe)
        and receipt["parameter_sha256"]
        == request_record["parameter_sha256"] == _sha(task["parameters"])
        and receipt["training_ids_sha256"]
        == request_record["fit_ids_sha256"] == _sha(definition["fit_ids"])
        and receipt["application_ids_sha256"]
        == request_record["prediction_ids_sha256"]
        == _sha(definition["evaluation_ids"])
        and receipt["training_response_sha256"]
        == request_record["fit_response_sha256"]
        == sha256_bytes(input_entries["fit-response.csv"])
        and receipt["seed"] == request_record["registered_model_seed"]
        and prediction["patient_ids"] == definition["evaluation_ids"]
        and prediction["centers"] == [
            context["centers_by_patient"][patient]
            for patient in definition["evaluation_ids"]
        ],
        "NESTED_SCORE_COMPONENT_EVIDENCE_REQUEST_DRIFT",
    )
    column_map = _expected_family_parent_column_map(
        task["selected_parents"], family,
        predictor_contract(Path(__file__).parent), recipe["transform_recipe"],
    )
    audit = evidence["object_audit"]
    columns = [column for row in column_map for column in row["columns"]]
    if family in {"XGBOOST_COX", "COXTIME_SET_A"}:
        columns.sort(key=lambda text: text.encode())
    _require(audit.get("design_columns") == columns and task["family_design_column_count"] == len(columns),
             "NESTED_SCORE_OBJECT_AUDIT_DESIGN_DRIFT")
    if receipt["component_role"] == "REUSED_FULL0_RSF_Q_SCORE":
        from .f2_kernel import _validate_r_tree_fit_health
        source = _validate_full0_rsf_q_score_source(evidence["retained_model_source"], receipt, context)
        producer = source["producer_task"]
        _require(full_score and family == "RSF" and expected_full_source["selection_horizon_months"] == 12
                 and source["science_decision_sha256"] == expected_full_source["science_decision_sha256"]
                 and producer == {"family": "RSF", "imputation": imputation,
                     "parameters": _locked_family_parameters("RSF", task["parameters"]),
                     "partition_id": definition["partition_id"], "prediction_horizons": list(HORIZONS[1:]),
                     "seed": receipt["seed"], "selected_parents": task["selected_parents"],
                     "task_id": producer["task_id"]}
                 and set(audit) == {"design_columns", "ordered_parent_column_map", "native_object_members"}
                 and audit["ordered_parent_column_map"] == column_map
                 and isinstance(audit["native_object_members"], Mapping)
                 and set(audit["native_object_members"]) == {"model.rds"}
                 and set(audit["native_object_members"]["model.rds"]) == {"sha256", "size_bytes"}
                 and audit["native_object_members"]["model.rds"]["sha256"] == receipt["model_sha256"]
                 and type(audit["native_object_members"]["model.rds"]["size_bytes"]) is int
                 and audit["native_object_members"]["model.rds"]["size_bytes"] > 0,
                 "NESTED_FULL0_RSF_Q_SCORE_OBJECT_DRIFT")
        _validate_r_tree_fit_health("RSF", evidence["fit_health"], parameters=producer["parameters"],
            ordered_parent_column_map=column_map, fit_row_count=len(definition["fit_ids"]), stop_curve=False)
        return
    lambda_source_column_map = None
    if family == "ELASTIC_NET_COX":
        from .f4 import _f4_elastic_parameters, _nested_full_elastic_parameters
        resolver = _nested_full_elastic_parameters if full_score else _f4_elastic_parameters
        _, lambda_source_column_map = resolver(task[
            "f4_nested_full_elastic_source" if full_score else "f4_outer_elastic_source"
        ], task["f4_coordinates"])
    if family in {"XGBOOST_COX", "COXTIME_SET_A"}:
        from .f2_kernel import _validate_python_fit_health
        _validate_python_fit_health(
            family, evidence["fit_health"],
            locked_value=task["parameters"]["selected_rounds" if family == "XGBOOST_COX" else "locked_epoch"],
            training_count=len(definition["fit_ids"]), evaluation_count=len(definition["fit_ids"]),
        )
        expected_audit = {"design_columns": columns,
            **({"booster_round_count": task["parameters"]["selected_rounds"]}
               if family == "XGBOOST_COX" else {"input_width": len(columns)})}
        _require(audit == expected_audit, "NESTED_SCORE_OBJECT_AUDIT_DRIFT")
    else:
        _validate_final_r_fit_health(
            family, evidence["fit_health"],
            (_locked_family_parameters(family, task["parameters"])
             if family in {"RSF", "GBM_COX"} else task["parameters"]),
            ordered_parent_column_map=column_map, training_count=len(definition["fit_ids"]),
            **({"lambda_source_column_map": lambda_source_column_map}
               if lambda_source_column_map is not None else {}),
        )
        _validate_retained_r_audit_numbers(family, audit, evidence["fit_health"], task)


def _outer_fixed12_score_request_pair(original, prepared, family):
    """Pair original OUTER inputs after the F4 source consumer qualifies both.

    Program identities are not silently equated here. The original input
    readers retain their separate producer proofs; every fixed component is
    additionally compared byte-for-byte by the numerical consumer below.
    """
    failure = "NESTED_OUTER_FIXED12_SCORE_INPUT_DRIFT"
    _require(family in {"COX_PH", "ELASTIC_NET_COX", "FPM_TVC_SET_A"}, failure)
    for request, horizon in ((original, 24), (prepared, 12)):
        _require(isinstance(request, Mapping)
                 and request.get("kind") == "PADML_F4_O_FIT_INPUT_V1"
                 and request.get("identity_sha256") == _sha({
                     key: value for key, value in request.items() if key != "identity_sha256"})
                 and request.get("selection_horizon_months", 24) == horizon
                 and request.get("reused_training_scores") == [], failure)
        context = validate_training_context(request["training_context"])
        _require(context["scope"] == "OUTER" and context["channel"] == "PRIMARY"
                 and type(context["outer_fold"]) is int and context["outer_fold"] in range(1, 7), failure)
        _validate_score_partitions(request["score_partitions"], context)
        records = request["component_records"]
        _require(isinstance(records, list) and len(records) == 2100
                 and [(row["family"], row["repeat"], row["inner_fold"], row["imputation"])
                      for row in records] == [(name, repeat, inner, imp) for name in _families()
                         for repeat in range(1, 4) for inner in range(1, 6) for imp in range(1, 21)], failure)
    decision = validate_science_decision(prepared["science_decision"])
    _require(decision["twelve_month_development"]["original_24_month_decision_sha256"]
                 == original["science_decision"]["identity_sha256"], failure)
    program_fields = {"identity_sha256", "preprocessing_program_sha256", "modeling_program_sha256"}
    _require({key: value for key, value in original["training_context"].items() if key not in program_fields}
             == {key: value for key, value in prepared["training_context"].items() if key not in program_fields}
             and original["score_partitions"] == prepared["score_partitions"]
             and original["selector_evidence_sha256"] == prepared["selector_evidence_sha256"], failure)
    old = [row for row in original["component_records"] if row["family"] == family]
    new = [row for row in prepared["component_records"] if row["family"] == family]
    # OUTER component tasks contain the actual parameters, seed and recipe,
    # not a mutable source-role label. Their scientific bytes must be equal.
    _require(len(old) == len(new) == 300
             and all(left == right for left, right in zip(old, new, strict=True)), failure)
    return {row["path"]: row for row in new}


def _recompute_fresh_score_from_evidence(
    *, execution: Mapping[str, Any], score: Mapping[str, Any],
    request: Mapping[str, Any], request_root: Path, result_root: Path,
    replay_models: bool = False,
    expanded_bytes_per_component: int | None = None,
    retained_bytes_per_component: int | None = None,
    rescore_science_decision: Mapping[str, Any] | None = None,
    retained_request: Mapping[str, Any] | None = None,
    retained_request_root: Path | None = None,
    outer_fixed12_target_request: Mapping[str, Any] | None = None,
    outer_fixed12_target_root: Path | None = None,
    outer_fixed12_retained_result: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Replay M20 pooling and every training-only IBS from transferred curves."""
    from .f2_kernel import (
        _evaluate_prediction_seal,
        _monthly_prediction_seal,
        _prediction_evaluation_context, _development_evaluation_indices,
        _pool_prediction_batch,
        _response_rows,
        _seal_prediction_matrix,
        _trial_summary_from_pooled,
        _trial_scoring_context,
        _write_response_subset,
    )
    from .f5 import _score_archive_expanded_limit, _full_score_family_source

    execution = validate_fresh_score_execution(execution)
    q_reuse = "retained_q_archive" in execution
    score = validate_training_score(score)
    context = validate_training_context(request["training_context"])
    family = execution["family"]
    _require((outer_fixed12_target_request is None) == (outer_fixed12_target_root is None)
             and (outer_fixed12_target_request is None or rescore_science_decision is not None
                  and retained_request is None and retained_request_root is None and not replay_models
                  and isinstance(outer_fixed12_target_root, Path)
                  and outer_fixed12_target_root.is_absolute() and outer_fixed12_target_root.is_dir()
                  and outer_fixed12_target_root.resolve(strict=True) == outer_fixed12_target_root
                  and outer_fixed12_target_request["science_decision"] == rescore_science_decision),
             "NESTED_OUTER_FIXED12_SCORE_SCOPE_INVALID")
    target_records = (None if outer_fixed12_target_request is None else
                      _outer_fixed12_score_request_pair(request, outer_fixed12_target_request, family))
    _require(outer_fixed12_retained_result is None or outer_fixed12_target_request is not None
             and isinstance(outer_fixed12_retained_result, Mapping)
             and set(outer_fixed12_retained_result) == {"training_score", "fresh_score_execution"},
             "NESTED_OUTER_FIXED12_SCORE_SCOPE_INVALID")
    full_score = context["scope"] == "FULL_DATA"
    bounded = full_score or expanded_bytes_per_component is not None or retained_bytes_per_component is not None
    _require(not bounded or all(type(value) is int and value > 0
             for value in (expanded_bytes_per_component, retained_bytes_per_component)),
             "NESTED_FULL_SCORE_EXPANDED_ESTIMATE_REQUIRED")
    _require(not full_score or (
        request.get("kind") == "PADML_NESTED_FULL_SCORE_INPUT_V1"
        and request.get("reused_training_scores") == []
        and score["source_kind"] == "FRESH_FULL_DATA_M20_INNER_OOF"
        and score["selector_evidence_sha256"] == request["selector_development_sha256"]
        and score["selected_spec"] == request["development"]["locked_specs"][family]
    ), "NESTED_FULL_SCORE_INPUT_INVALID")
    expected_full_source = _full_score_family_source(request["development"], family) if full_score else None
    evidence_context = context
    evidence_request = request
    evidence_request_root = request_root
    evidence_full_source = expected_full_source
    prepared_records = None
    score_reuse = "retained_score_request_sha256" in execution
    _require(score_reuse == (retained_request is not None) == (retained_request_root is not None),
             "NESTED_FULL0_COX_REUSE_INPUT_REQUIRED")
    if score_reuse:
        from .f5 import _full0_cox_reuse_request_pair
        _require(not replay_models and rescore_science_decision is None
                 and family in {"COX_PH", "ELASTIC_NET_COX", "FPM_TVC_SET_A"},
                 "NESTED_FULL0_COX_REUSE_NATIVE_REPLAY_FORBIDDEN")
        prepared_records = (_full0_cox_reuse_request_pair(retained_request, request) if full_score else
                            _outer_fixed12_score_request_pair(retained_request, request, family))
        _require(not full_score or family == retained_request["component_records"][0]["family"],
                 "NESTED_FULL0_COX_REUSE_INPUT_INVALID")
        _require(retained_request_root.is_absolute() and retained_request_root.is_dir()
                 and retained_request_root.resolve(strict=True) == retained_request_root
                 and execution["retained_score_request_sha256"] == retained_request["identity_sha256"]
                 and execution["retained_score_training_context_sha256"]
                     == retained_request["training_context"]["identity_sha256"],
                 "NESTED_FULL0_COX_REUSE_INPUT_DRIFT")
        evidence_context = retained_request["training_context"]
        evidence_request = retained_request
        evidence_request_root = retained_request_root
        evidence_full_source = (_full_score_family_source(retained_request["development"], family)
                                if full_score else None)
    if q_reuse:
        _require(full_score and family == "RSF" and not replay_models,
                 "NESTED_FULL0_RSF_Q_SCORE_NATIVE_REPLAY_FORBIDDEN")
        declared_q = request["development"]["complex_search_evidence"][0]["retained_q_archive"]
        _require(execution["retained_q_archive"] == {key: declared_q[key] for key in ("sha256", "size_bytes")},
                 "NESTED_FULL0_RSF_Q_SCORE_SOURCE_DRIFT")
    horizon = selection_horizon(request["selection_horizon_months"])
    science = validate_science_decision(request["science_decision"])
    _require((not full_score or expected_full_source.get("selection_horizon_months", 24) == horizon)
             and all(row["selection_horizon_months"] == horizon for row in (score, execution))
             and score["science_decision_sha256"] == execution["science_decision_sha256"]
                 == science["identity_sha256"], "NESTED_FULL_SCORE_SELECTION_SCOPE_INVALID")
    _require(
        score["family"] == family
        and (full_score or score["selector_evidence_sha256"] == request["selector_evidence_sha256"])
        and score["source_result_sha256"] == execution["identity_sha256"]
        and execution["outer_fold"] == context["outer_fold"]
        and execution["training_context_sha256"] == context["identity_sha256"]
        and execution["score_partitions_sha256"] == _sha(request["score_partitions"]),
        "NESTED_FRESH_SCORE_REQUEST_BINDING_INVALID",
    )
    if rescore_science_decision is not None:
        decision = validate_science_decision(rescore_science_decision)
        _require(not replay_models and not q_reuse and bounded
                 and context["channel"] == "PRIMARY"
                 and family in {"COX_PH", "ELASTIC_NET_COX", "FPM_TVC_SET_A"}
                 and horizon == 24 and decision.get("twelve_month_development") == _twelve_month_development_contract()
                 and (full_score and context["outer_fold"] == 0
                      and score["source_kind"] == "FRESH_FULL_DATA_M20_INNER_OOF"
                      or not full_score and context["scope"] == "OUTER" and context["outer_fold"] in range(1, 7)
                      and request.get("kind") == "PADML_F4_O_FIT_INPUT_V1"
                      and decision["twelve_month_development"]["original_24_month_decision_sha256"]
                          == request["science_decision"]["identity_sha256"]
                      and score["source_kind"] == "FRESH_M20_INNER_OOF")
                 and score["outer_fold"] == context["outer_fold"]
                 and score["heldout_center"] == context["heldout_center"]
                 and score["training_context_sha256"] == context["identity_sha256"],
                 "NESTED_OUTER_FIXED_RESCORE_SCOPE_INVALID")
        # The old request, component receipts, seeds and first audits stay
        # untouched. Only this new numerical invocation owns the IBS horizon.
        horizon = 12
    partitions, partition_by_coordinate = _validate_score_partitions(
        request["score_partitions"], context
    )
    request_records = {
        (row["family"], row["repeat"], row["inner_fold"], row["imputation"]): row
        for row in evidence_request["component_records"]
    }
    _require(
        {row["development_spec_sha256"] for row in request_records.values()
         if row["family"] == family} == {score["selected_spec_sha256"]},
        "NESTED_FRESH_SCORE_SPEC_REQUEST_DRIFT",
    )
    response_raw = (request_root / "training/response.csv").read_bytes()
    validate_training_context(context, response_raw)
    if outer_fixed12_target_request is not None:
        target_response_path = outer_fixed12_target_root / "training/response.csv"
        _require(target_response_path.is_file() and not target_response_path.is_symlink()
                 and target_response_path.resolve(strict=True) == target_response_path
                 and target_response_path.stat().st_size == len(response_raw),
                 "NESTED_OUTER_FIXED12_SCORE_INPUT_DRIFT")
        target_response = target_response_path.read_bytes()
        validate_training_context(outer_fixed12_target_request["training_context"], target_response)
        _require(target_response == response_raw, "NESTED_OUTER_FIXED12_SCORE_INPUT_DRIFT")
    fields, responses = _response_rows(response_raw)
    replay_root = result_root / "score-context" / family
    replay_root.mkdir(parents=True, exist_ok=True)
    scoring_partitions = []
    evaluated = []
    pooled_by_partition = {}
    pooled_by_coordinate = {(row["repeat"], row["inner_fold"]): row
                            for row in execution["pooled_partitions"]}
    evidence_records = execution["component_evidence_records"]
    reused_inputs = None
    if "reused_score_sources" in execution:
        from .f5 import _F45ReusedScoreInputs
        _require(not replay_models and not score_reuse and not q_reuse
                 and rescore_science_decision is None, "F45_SCORE_REUSE_NATIVE_REPLAY_FORBIDDEN")
        reused_inputs = _F45ReusedScoreInputs(request, request_root, result_root,
            execution["reused_score_sources"], expanded_bytes_per_component=expanded_bytes_per_component,
            retained_bytes_per_component=retained_bytes_per_component)
    original_evidence_context, original_evidence_source = evidence_context, evidence_full_source
    for evidence_record, (repeat, inner, imputation) in zip(
        evidence_records,
        (
            (repeat, inner, imputation)
            for repeat in range(1, REPEAT_COUNT + 1)
            for inner in range(1, INNER_FOLD_COUNT + 1)
            for imputation in range(1, M + 1)
        ),
        strict=True,
    ):
        evidence_path = result_root / evidence_record["path"]
        if bounded:
            _require(evidence_path.is_file() and not evidence_path.is_symlink()
                     and evidence_path.stat().st_size == evidence_record["size_bytes"] <= retained_bytes_per_component,
                     "NESTED_FULL_SCORE_COMPONENT_STORAGE_ESTIMATE_EXCEEDED")
        raw = evidence_path.read_bytes()
        request_record = request_records[family, repeat, inner, imputation]
        request_component = evidence_request_root / request_record["path"]
        evidence_context, evidence_full_source = original_evidence_context, original_evidence_source
        reused_unit = evidence_record.get("reused_score_unit_id")
        if reused_unit is not None:
            evidence = reused_inputs.read(request_record["path"], reused_unit, raw)
            producer = reused_inputs.sources[reused_unit]["request"]
            request_record = reused_inputs.original_records[reused_unit][request_record["path"]]
            request_component = result_root / "score-reuse" / reused_unit / request_record["path"]
            evidence_context = producer["training_context"]
            evidence_full_source = (_full_score_family_source(producer["development"], family)
                                    if full_score else None)
        else:
            evidence = _validate_score_component_evidence(
                strict_json_bytes(raw, "NESTED_SCORE_COMPONENT_EVIDENCE"), context=evidence_context)
        if bounded:
            _require(request_component.is_file() and not request_component.is_symlink()
                     and request_component.stat().st_size == request_record["size_bytes"] < retained_bytes_per_component,
                     "NESTED_FULL_SCORE_COMPONENT_STORAGE_ESTIMATE_EXCEEDED")
            _score_archive_expanded_limit(request_component, expanded_bytes_per_component)
        task, recipe, input_entries = _read_component(request_component)
        if full_score:
            _require(task["nested_full_score_source"] == evidence_full_source,
                     "NESTED_FULL_SCORE_PARAMETER_SOURCE_DRIFT")
        receipt = evidence["receipt"]
        _require(evidence_record["q_archive_sha256" if q_reuse else "native_archive_sha256"]
                 == receipt["archive_sha256"]
                 and (receipt["component_role"] == "REUSED_FULL0_RSF_Q_SCORE") == q_reuse,
                 "NESTED_SCORE_NATIVE_ARCHIVE_DRIFT")
        if q_reuse:
            retained = evidence["retained_model_source"]
            _require(retained["request_identity_sha256"] == request["identity_sha256"]
                     and retained["q_archive_size_bytes"] == execution["retained_q_archive"]["size_bytes"],
                     "NESTED_FULL0_RSF_Q_SCORE_SOURCE_DRIFT")
        if replay_models:
            from .f4 import _replay_f4_model_component
            native_archive = result_root / evidence_record["native_archive_path"]
            if bounded:
                _require(native_archive.is_file() and not native_archive.is_symlink()
                         and native_archive.stat().st_size < retained_bytes_per_component,
                         "NESTED_FULL_SCORE_COMPONENT_STORAGE_ESTIMATE_EXCEEDED")
                _score_archive_expanded_limit(native_archive, expanded_bytes_per_component)
            _require(sha256_file(native_archive) == receipt["archive_sha256"], "NESTED_SCORE_NATIVE_ARCHIVE_DRIFT")
            native_receipt, native_prediction, native_health = _component_execution_receipt(
                component_path=request_component, output_root=native_archive.with_suffix(""),
                record=request_record, context=context, development_lock_sha256=None)
            replayed = _replay_f4_model_component({
                "entries": input_entries, "archive": native_archive,
            }, include_audit=True)
            _require(native_receipt == receipt and native_prediction == evidence["prediction"]
                     and native_health == evidence["fit_health"] and replayed == {
                         "prediction": evidence["prediction"], "fit_health": evidence["fit_health"],
                         "retained_audit": evidence["object_audit"]}, "NESTED_SCORE_NATIVE_REPLAY_DRIFT")
        definition = partition_by_coordinate[repeat, inner]
        if imputation == 1:
            directory = replay_root / f"R{repeat}_K{inner}"
            directory.mkdir(exist_ok=True)
            _write_exact_once(directory / "imp01.csv", input_entries["prediction-covariates.csv"],
                              "NESTED_SCORE_CONTEXT_RESUME_DRIFT")
            fit_response = _write_response_subset(fields, responses, definition["fit_ids"], None)
            evaluation_response = _write_response_subset(fields, responses, definition["evaluation_ids"], None)
            scoring_partitions.append({
                "partition_id": definition["partition_id"], "kind": "INNER", "repeat": repeat,
                "inner_fold": inner, "fit_ids": definition["fit_ids"],
                "evaluation_ids": definition["evaluation_ids"], "covariates": {"input_dir": str(directory)},
                "fit_response": fit_response, "evaluation_response": evaluation_response,
            })
            fold_context = _prediction_evaluation_context(
                fit_response, evaluation_response, definition["evaluation_ids"], selection_horizon_months=horizon,
                evaluation_indices=_development_evaluation_indices(scoring_partitions[-1], horizon))
            component_predictions, component_receipts = [], []
        prediction = evidence["prediction"]
        _require(
            canonical_json_bytes(evidence) == raw
            and len(raw) == evidence_record["size_bytes"]
            and sha256_bytes(raw) == evidence_record["sha256"]
            and evidence["identity_sha256"] == evidence_record["identity_sha256"]
            and receipt["identity_sha256"]
            == evidence_record["component_receipt_sha256"],
            "NESTED_SCORE_COMPONENT_EVIDENCE_REQUEST_DRIFT",
        )
        if reused_unit is None:
            _validate_fresh_score_component_numbers(
                evidence=evidence, request_record=request_record, request_component=request_component,
                task=task, recipe=recipe, input_entries=input_entries, definition=definition,
                context=evidence_context, expected_full_source=evidence_full_source)
        if score_reuse and full_score:
            from .f5 import _full0_cox_reuse_component_pair
            target_record = prepared_records[request_record["path"]]
            _full0_cox_reuse_component_pair(task, input_entries, target_record,
                request_root / target_record["path"], expected_full_source, expanded_bytes_per_component)
        elif score_reuse or target_records is not None:
            target_record = (prepared_records if score_reuse else target_records)[request_record["path"]]
            target_root = request_root if score_reuse else outer_fixed12_target_root
            target = target_root / target_record["path"]
            _require(target.is_file() and not target.is_symlink()
                     and target.resolve(strict=True) == target
                     and target.stat().st_size == target_record["size_bytes"]
                     and sha256_file(target) == target_record["sha256"],
                     "NESTED_OUTER_FIXED12_SCORE_INPUT_DRIFT")
            _score_archive_expanded_limit(target, expanded_bytes_per_component)
            target_task, target_recipe, target_entries = _read_component(target)
            _require(task == target_task and recipe == target_recipe and input_entries == target_entries,
                     "NESTED_OUTER_FIXED12_SCORE_INPUT_DRIFT")
        seal = _seal_prediction_matrix(
            prediction["patient_ids"],
            [row[1:] for row in prediction["survival"][family]],
            list(HORIZONS[1:]),
        )
        monthly = _monthly_prediction_seal(seal)
        metric = _evaluate_prediction_seal(
            monthly, fit_response=fit_response, evaluation_response=evaluation_response,
            evaluation_context=fold_context, selection_horizon_months=horizon,
        )
        evaluated.append(metric[f"ibs_0_{horizon}"])
        component_predictions.append({"sealed_prediction": monthly})
        component_receipts.append(receipt["identity_sha256"])
        if imputation == M:
            pooled = _pool_prediction_batch(component_predictions, list(HORIZONS))
            pooled_by_partition[definition["partition_id"]] = pooled
            declared = pooled_by_coordinate[repeat, inner]
            _require(declared["partition_id"] == definition["partition_id"]
                     and declared["patient_ids"] == definition["evaluation_ids"]
                     and __import__("padml.carriers", fromlist=["pooled_matrix"]).pooled_matrix(declared) == pooled["payload"]["survival"]
                     and declared["component_receipt_sha256"] == component_receipts,
                     "NESTED_FRESH_SCORE_POOLED_REPLAY_MISMATCH")
            del component_predictions, component_receipts
    summary = _trial_summary_from_pooled(
        pooled_by_partition, evaluated, _trial_scoring_context(scoring_partitions, selection_horizon_months=horizon), M
    )
    if rescore_science_decision is not None:
        execution = _sealed({**{key: value for key, value in execution.items() if key != "identity_sha256"},
            "selection_horizon_months": 12, "science_decision_sha256": decision["identity_sha256"]})
        validate_fresh_score_execution(execution)
    expected_score = seal_fresh_training_score(
        family=family,
        outer_fold=context["outer_fold"],
        training_context_sha256=context["identity_sha256"],
        selected_spec=score["selected_spec"],
        selector_evidence_sha256=score["selector_evidence_sha256"],
        summary=summary,
        execution_evidence_sha256=execution["identity_sha256"],
        source_kind="FRESH_FULL_DATA_M20_INNER_OOF" if full_score else "FRESH_M20_INNER_OOF",
        selection_horizon_months=horizon,
        science_decision_sha256=science["identity_sha256"],
    )
    if rescore_science_decision is not None:
        # A completed fixed12 report is consumed, not rewritten. Recomputing
        # its scalar from the original curves is the existing numerical
        # reader's verification, not another first-production/rescue call.
        _require(outer_fixed12_retained_result is None or outer_fixed12_retained_result == {
            "training_score": expected_score, "fresh_score_execution": execution},
            "NESTED_OUTER_FIXED12_RETAINED_RESULT_DRIFT")
        retained_result = {"training_score": expected_score, "fresh_score_execution": execution}
        if outer_fixed12_target_request is not None:
            target_context = outer_fixed12_target_request["training_context"]
            execution = _sealed({**{key: value for key, value in execution.items() if key != "identity_sha256"},
                "training_context_sha256": target_context["identity_sha256"],
                "retained_score_request_sha256": request["identity_sha256"],
                "retained_score_training_context_sha256": context["identity_sha256"],
                "new_model_fit_count": 0, "new_first_native_audit_count": 0, "new_native_replay_count": 0})
            validate_fresh_score_execution(execution)
            expected_score = _sealed({**{key: value for key, value in expected_score.items()
                                         if key != "identity_sha256"},
                "training_context_sha256": target_context["identity_sha256"],
                "source_result_sha256": execution["identity_sha256"]})
            validate_training_score(expected_score)
        return {"training_score": expected_score, "fresh_score_execution": execution,
                **({"retained_result": retained_result} if outer_fixed12_target_request is not None else {})}
    _require(expected_score == score, "NESTED_FRESH_SCORE_LOCAL_REPLAY_MISMATCH")
    return expected_score


def _final_receipt(
    execution_receipt: Mapping[str, Any], *, lock: Mapping[str, Any],
) -> dict[str, Any]:
    body = {key: execution_receipt[key] for key in _FINAL_RECEIPT_FIELDS}
    body["development_lock_sha256"] = lock["identity_sha256"]
    body["training_context_sha256"] = lock["training_context_sha256"]
    receipt = _sealed(body)
    validate_component_receipt(receipt, lock)
    return receipt


def _write_bound_component(
    template_path: Path, target: Path, lock: Mapping[str, Any],
) -> Path:
    task, _, entries = _read_component(template_path)
    bound = bind_post_lock_task(task, lock)
    _require(
        sha256_file(template_path)
        == lock["post_lock_template_archive_sha256_by_imputation"][bound["imputation"] - 1]
        and bound["parameters"] == lock["parameters_by_imputation"][bound["imputation"] - 1],
             "NESTED_POST_LOCK_PARAMETER_DRIFT")
    expected = {**entries, "task.json": canonical_json_bytes(bound)}
    if target.exists():
        _require(
            target.is_file() and not target.is_symlink()
            and read_safe_zip(target, expected_members=_COMPONENT_MEMBERS) == expected,
            "NESTED_POST_LOCK_BOUND_COMPONENT_RESUME_DRIFT",
        )
        return target
    return _write_component_archive(target, expected)


_POPULATION_REGISTRY_FIELDS = {
    "all_patient_ids", "evaluation_patient_ids", "centers_by_patient", "outer",
}


def validate_population_registry(value: Any) -> dict[str, Any]:
    """Bind every frozen patient to exactly one LOCO role and center."""
    _require(
        isinstance(value, Mapping) and set(value) == _POPULATION_REGISTRY_FIELDS,
        "NESTED_POPULATION_REGISTRY_INVALID",
    )
    row = dict(value)
    all_ids = row["all_patient_ids"]
    evaluation_ids = row["evaluation_patient_ids"]
    centers = row["centers_by_patient"]
    outer_rows = row["outer"]
    _require(
        isinstance(all_ids, list) and bool(all_ids)
        and all(isinstance(patient, str) and patient for patient in all_ids)
        and len(all_ids) == len(set(all_ids))
        and isinstance(evaluation_ids, list)
        and len(evaluation_ids) == len(set(evaluation_ids))
        and isinstance(centers, Mapping) and set(centers) == set(all_ids)
        and all(
            isinstance(center, str)
            and center in {*(str(value) for value in OUTER_CENTERS), "55"}
            for center in centers.values()
        )
        and evaluation_ids
        == [patient for patient in all_ids if centers[patient] != "55"]
        and isinstance(outer_rows, list) and len(outer_rows) == 6,
        "NESTED_POPULATION_REGISTRY_INVALID",
    )
    for outer, (center, part) in enumerate(
        zip(OUTER_CENTERS, outer_rows, strict=True), start=1
    ):
        expected_heldout = [
            patient for patient in all_ids if centers[patient] == str(center)
        ]
        expected_training = [
            patient for patient in all_ids if centers[patient] != str(center)
        ]
        _require(
            isinstance(part, Mapping)
            and set(part) == {
                "outer_fold", "heldout_center", "training_ids", "heldout_ids"
            }
            and part["outer_fold"] == outer
            and part["heldout_center"] == center
            and part["training_ids"] == expected_training
            and part["heldout_ids"] == expected_heldout
            and bool(expected_heldout),
            "NESTED_POPULATION_REGISTRY_OUTER_INVALID",
        )
    return row


def _read_canonical(path: Path, label: str) -> dict[str, Any]:
    _require(path.is_absolute() and path.is_file() and not path.is_symlink()
             and path.resolve(strict=True) == path, f"{label}_PATH_INVALID")
    raw = path.read_bytes()
    value = strict_json_bytes(raw, label)
    _require(isinstance(value, dict) and canonical_json_bytes(value) == raw, f"{label}_NONCANONICAL")
    return value
