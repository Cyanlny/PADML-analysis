from __future__ import annotations


# SHA256 of the canonical JSON encoding of RUNTIME_OBJECTS.
RUNTIME_IDENTITY = 'df108cf660ba642752abb39d2d12779ff568896f620de7bcb0375cd90a356c86'

RUNTIME_OBJECTS = ({'key': 'v22/padml/runtime/dependencies/4dd533d039544c2ee887945b8ff66f82d8aa18a9086257f4c1aa09b1507a6376/1a6b0ed57e5d910c5874817386bd8c65c8d213403decb4761f2bd35c8d926417/e95805b10280121c291f1dd21e6193113c81396b33482dbec4db1180d8bfa2bd/dependency.part-000',
  'role': 'DEPENDENCY_PART_000',
  'sha256': 'e95805b10280121c291f1dd21e6193113c81396b33482dbec4db1180d8bfa2bd',
  'size_bytes': 4000000000},
 {'key': 'v22/padml/runtime/dependencies/4dd533d039544c2ee887945b8ff66f82d8aa18a9086257f4c1aa09b1507a6376/1a6b0ed57e5d910c5874817386bd8c65c8d213403decb4761f2bd35c8d926417/45b3c20a9651b610be4a61a581a5c10f43f48418d76f65e195b2f7703a144271/dependency.part-001',
  'role': 'DEPENDENCY_PART_001',
  'sha256': '45b3c20a9651b610be4a61a581a5c10f43f48418d76f65e195b2f7703a144271',
  'size_bytes': 4000000000},
 {'key': 'v22/padml/runtime/dependencies/4dd533d039544c2ee887945b8ff66f82d8aa18a9086257f4c1aa09b1507a6376/1a6b0ed57e5d910c5874817386bd8c65c8d213403decb4761f2bd35c8d926417/273045769f8cc4e19dac1daa1007e0b9b7365410eea73fdf4215bf2120e1f02d/dependency.part-002',
  'role': 'DEPENDENCY_PART_002',
  'sha256': '273045769f8cc4e19dac1daa1007e0b9b7365410eea73fdf4215bf2120e1f02d',
  'size_bytes': 1027706880},
 {'key': 'v22/padml/runtime/r-overlay/49d742c25d2893627ab118ed016d3a6b369268c42de6d6da7cf6dff49eae867e/a2582f5047636412be0842f2abe55d0ac5a924edbd151066759b13652d79a7e4/r-overlay.tar',
  'role': 'R_SELECTOR_OVERLAY',
  'sha256': 'a2582f5047636412be0842f2abe55d0ac5a924edbd151066759b13652d79a7e4',
  'size_bytes': 6625280},
 {'key': 'padml/runtime/native/dbec6685b7d102c78513133b194bfdf99869c9d3af862e0f1f70ce3b6167d7b0/mrmre-2.1.2.2.9003.tar',
  'role': 'R_MRMRE_CORRECTION',
  'sha256': 'dbec6685b7d102c78513133b194bfdf99869c9d3af862e0f1f70ce3b6167d7b0',
  'size_bytes': 1955840},
 {'key': 'v22/padml/runtime/gbm-2.3.1.9001/8b90313113de5da562e604ffd319eb2c49918023797adad713e534bace5954fe/r-gbm-correction.tar',
  'role': 'R_GBM_BRESLOW_CORRECTION',
  'sha256': '8b90313113de5da562e604ffd319eb2c49918023797adad713e534bace5954fe',
  'size_bytes': 1372160},
 {'key': 'v22/padml/runtime/rstpm2-1.7.1.9011/ae434904007c8caf16694f6b30bb9309f01b6952e087534d2a34a67689d69aec/r-fpm-correction.tar',
  'role': 'R_FPM_CONSTRAINT_CORRECTION',
  'sha256': 'ae434904007c8caf16694f6b30bb9309f01b6952e087534d2a34a67689d69aec',
  'size_bytes': 4218880},
 {'key': 'padml/runtime/native/854d0fb0075bf5a7b3ce2533a31b98b59ceae587b0ad61fd420017c682212c4e/ranger-0.18.0.9003.tar',
  'role': 'R_RANGER_PERFORMANCE',
  'sha256': '854d0fb0075bf5a7b3ce2533a31b98b59ceae587b0ad61fd420017c682212c4e',
  'size_bytes': 1095680})

def qualify_current_environment(run):
    """Qualify the installed bytes once; installation media may then be absent."""
    import json
    import os
    import subprocess
    from pathlib import Path
    from .bundle import ContractError, canonical_json_bytes, strict_json_bytes
    from .integrated import qualified_file_pins
    from .nested_loco import _sha, _sealed, _write_exact_once
    lock = strict_json_bytes((Path(__file__).parent.parent / 'dependency-lock.json').read_bytes())
    env, base = run['environment'], Path(run['run_root']) / 'shared/environment'
    base.mkdir(parents=True, exist_ok=True)
    objects = [*lock['runtime_objects'], lock['additional_runtime_layers'][0]['artifact'],
               *lock['additional_runtime_layers'][1]['sources']]
    expected = {r['role']:{k:r[k] for k in ('sha256','size_bytes')} for r in objects}
    if set(env['artifact_paths']) != set(expected):
        raise ContractError('DEPENDENCY_ARTIFACT_COVERAGE_INCOMPLETE')
    loading_environment = {key:os.environ.get(key) for key in (
        'PATH', 'PYTHONPATH', 'PYTHONHOME', 'PYTHONUSERBASE', 'PYTHONNOUSERSITE',
        'PYTHONSAFEPATH', 'PYTHONPYCACHEPREFIX', 'PYTHONDONTWRITEBYTECODE', 'NUMBA_CACHE_DIR',
        'R_HOME', 'R_LIBS', 'R_LIBS_USER', 'R_LIBS_SITE',
        'RETICULATE_PYTHON', 'LD_LIBRARY_PATH', 'LD_PRELOAD', 'DYLD_LIBRARY_PATH',
        'DYLD_FALLBACK_LIBRARY_PATH', 'DYLD_INSERT_LIBRARIES')}
    identity = _sha({'environment':env, 'loading_environment':loading_environment})
    # Each approved installation/loader identity keeps one original qualification.
    # A new native build must qualify its actual bytes; old evidence is immutable.
    base = base / identity
    base.mkdir(parents=True, exist_ok=True)
    executable_targets = {k:str(Path(env[k]).resolve(strict=True)) for k in ('python','rscript')}
    def directory_stamps(names):
        return {name:[str(Path(name).resolve(strict=True)), Path(name).stat().st_dev,
            Path(name).stat().st_ino, Path(name).stat().st_mtime_ns, Path(name).stat().st_ctime_ns]
            for name in names}
    target = base / 'installed.json'
    if target.is_file():
        saved = strict_json_bytes(target.read_bytes())
        if saved['environment_identity'] != identity or _sealed({k:v for k,v in saved.items()
                if k != 'identity_sha256'}) != saved:
            raise ContractError('DEPENDENCY_INSTALLATION_DRIFT')
        if saved['executable_targets'] != executable_targets or directory_stamps(saved['directory_stamps']) != saved['directory_stamps']:
            raise ContractError('DEPENDENCY_INSTALLATION_STRUCTURE_DRIFT')
        qualified_file_pins({k:Path(k) for k in saved['installed_files']}, identity=identity,
            expected=saved['installed_files'], record=base/'installed.qualified.json')
        for path, link in saved.get('installed_links', {}).items():
            if not Path(path).is_symlink() or os.readlink(path) != link:
                raise ContractError('DEPENDENCY_INSTALLATION_STRUCTURE_DRIFT')
        return saved
    installed_expected, installed_links, installed_directories = {}, {}, set()
    if env.get('runtime_manifest') is not None:
        manifest = env['runtime_manifest']
        if set(manifest) != {'path', 'root', 'sha256', 'size_bytes'}:
            raise ContractError('DEPENDENCY_INSTALLATION_MANIFEST_INVALID')
        qualified_file_pins({'manifest':Path(manifest['path'])}, identity=env['lock_sha256'],
            expected={'manifest':{k:manifest[k] for k in ('sha256','size_bytes')}},
            record=base/'manifest.qualified.json')
        runtime_root = Path(manifest['root']).resolve(strict=True)
        installed_directories.add(str(runtime_root))
        from .bundle import validate_relative_path
        seen = set()
        with Path(manifest['path']).open() as stream:
            for line in stream:
                row = strict_json_bytes(line.encode())
                name = validate_relative_path(row['path'], 'installed.path')
                path = runtime_root / name
                if name in seen or not path.parent.resolve(strict=True).is_relative_to(runtime_root):
                    raise ContractError('DEPENDENCY_INSTALLATION_MANIFEST_INVALID')
                seen.add(name)
                if row['kind'] == 'file' and path.is_file() and not path.is_symlink():
                    installed_expected[str(path)] = {'sha256':row['sha256'], 'size_bytes':row['size']}
                elif row['kind'] == 'directory' and path.is_dir() and not path.is_symlink():
                    installed_directories.add(str(path))
                elif row['kind'] == 'symlink' and path.is_symlink() and os.readlink(path) == row['target']:
                    installed_links[str(path)] = row['target']
                else:
                    raise ContractError('DEPENDENCY_INSTALLATION_STRUCTURE_DRIFT')
        if not installed_expected:
            raise ContractError('DEPENDENCY_INSTALLATION_MANIFEST_EMPTY')
        # These are distribution provenance pins, not a claim that missing media
        # were read. The frozen manifest qualifies the actual installed bytes.
        artifact_pins = expected
    else:
        artifact_pins = qualified_file_pins({k:Path(v) for k,v in env['artifact_paths'].items()},
            identity=env['lock_sha256'], expected=expected, record=base/'artifacts.qualified.json')
    versions = {**{name:None for name in ('mice','survival','digest','readxl','jsonlite','Matrix','doFuture')},
                **lock['engine_contract_versions']}
    script = '''args <- commandArgs(TRUE)
    packages <- jsonlite::fromJSON(args[[1]])
    out <- lapply(names(packages), function(p) {
      ns <- loadNamespace(p)
      version <- as.character(utils::packageVersion(p))
      if (!is.null(packages[[p]]) && !is.na(packages[[p]]) && version != packages[[p]]) stop(paste("DEPENDENCY_VERSION_MISMATCH", p, version))
      list(package=p, version=version, path=normalizePath(find.package(p)))
    })
    bridge <- reticulate::py_config()
    cat(jsonlite::toJSON(list(packages=out,python=bridge$python),auto_unbox=TRUE))'''
    result = subprocess.run([env['rscript'],'--vanilla','-e',script,json.dumps(versions)],
        capture_output=True, text=True, timeout=120, env={**os.environ,'RETICULATE_PYTHON':env['python']})
    if result.returncode:
        raise ContractError('DEPENDENCY_R_LOAD_FAILED:'+result.stderr[-1500:])
    loaded = strict_json_bytes(result.stdout.encode())
    if Path(loaded['python']).resolve() != Path(env['python']).resolve():
        raise ContractError('DEPENDENCY_RETICULATE_PYTHON_MISMATCH')
    py_script = '''import importlib,json
names=['numpy','scipy','pandas','xgboost','torch','pycox','torchtuples']
print(json.dumps([{'name':n,'path':importlib.import_module(n).__file__} for n in names]))'''
    py = subprocess.run([env['python'],'-c',py_script], capture_output=True, timeout=120)
    if py.returncode:
        raise ContractError('DEPENDENCY_PYTHON_LOAD_FAILED:'+py.stderr.decode(errors='replace')[-1500:])
    python_packages = strict_json_bytes(py.stdout)
    files = {name:Path(name) for name in executable_targets.values()}
    directories = [Path(r['path']) for r in loaded['packages']] + [Path(r['path']).parent for r in python_packages]
    directory_names = set(env['r_library'].split(':')) | installed_directories
    for directory in directories:
        directory_names.add(str(directory))
        for path in directory.rglob('*'):
            if '__pycache__' in path.parts:
                continue
            if path.is_dir():
                directory_names.add(str(path))
            elif path.is_file():
                files[str(path.resolve())] = path.resolve()
    if installed_expected:
        if not set(files) <= set(installed_expected):
            raise ContractError('DEPENDENCY_LOADED_OUTSIDE_INSTALLATION')
        files = {name:Path(name) for name in installed_expected}
    installed = qualified_file_pins(files, identity=identity, expected=installed_expected or None,
        record=base/'installed.qualified.json')
    saved = _sealed({'kind':'PADML_DEPENDENCY_INSTALLATION_V1', 'status':'LOADED_AND_BYTE_FINGERPRINTED',
        'environment_identity':identity, 'loading_environment':loading_environment,
        'artifact_pins':artifact_pins, 'runtime_manifest':env.get('runtime_manifest'), 'R':loaded,
        'executable_targets':executable_targets,'directory_stamps':directory_stamps(sorted(directory_names)),
        'python_packages':python_packages,'installed_files':installed, 'installed_links':installed_links,
        'scope':'Pinned distribution inputs and actual loaded installation fingerprint; no claim of reproducible compilation.'})
    _write_exact_once(target, canonical_json_bytes(saved), 'DEPENDENCY_INSTALLATION_DRIFT')
    return saved


def environment_snapshot(run):
    """Exact installed runtime plus an explicit, credential-free OS loader closure."""
    import json, os, platform, re, shutil, stat, subprocess
    from pathlib import Path
    from .bundle import ContractError, sha256_file
    from .nested_loco import _sealed
    if platform.system()!='Linux' or platform.machine()!='x86_64':
        raise ContractError('ENVIRONMENT_PLATFORM_UNSUPPORTED')
    release=Path('/etc/os-release').read_text()
    if 'VERSION_ID="22.04"' not in release or 'ID=ubuntu' not in release:
        raise ContractError('ENVIRONMENT_PLATFORM_UNSUPPORTED')
    qualified=qualify_current_environment(run)
    root=Path(run['environment']['runtime_manifest']['root'])
    rows={}; elf=[]; seen_inodes={}
    def add(path, pin=None):
        path=Path(path)
        if not path.is_absolute() or '..' in path.parts:
            raise ContractError('ENVIRONMENT_PATH_INVALID')
        # Resolve parent aliases explicitly; later extraction never traverses
        # archive-created symlinks to write a regular file.
        for parent in reversed(path.parents):
            if parent==Path('/'):continue
            if parent.is_symlink():add(parent)
        canonical=path.parent.resolve()/path.name
        name=canonical.as_posix().lstrip('/')
        if name in rows:return
        st=canonical.lstat();mode=stat.S_IMODE(st.st_mode)
        if canonical.is_symlink():
            target=os.readlink(canonical)
            rows[name]={'kind':'symlink','mode':mode,'target':target}
            add(canonical.resolve(strict=True))
        elif canonical.is_dir():
            rows[name]={'kind':'directory','mode':mode}
        elif canonical.is_file():
            actual={'sha256':sha256_file(canonical),'size_bytes':st.st_size} if pin is None else pin
            if canonical.stat().st_size!=actual['size_bytes']:raise ContractError('ENVIRONMENT_FILE_DRIFT')
            inode=(st.st_dev,st.st_ino)
            if inode in seen_inodes:
                rows[name]={'kind':'hardlink','mode':mode,'target':seen_inodes[inode],**actual}
            else:
                seen_inodes[inode]=name;rows[name]={'kind':'file','mode':mode,**actual}
                with canonical.open('rb') as stream:
                    if stream.read(4)==b'\x7fELF':elf.append(canonical)
        else:raise ContractError('ENVIRONMENT_SPECIAL_FILE_REJECTED')
        for parent in canonical.parents:
            if parent==Path('/'):break
            if not parent.is_symlink():rows.setdefault(parent.as_posix().lstrip('/'),
                {'kind':'directory','mode':stat.S_IMODE(parent.stat().st_mode)})
    for name,pin in qualified['installed_files'].items():add(name,pin)
    for name in qualified.get('installed_links',{}):add(name)
    for name in qualified['directory_stamps']:
        if Path(name).is_relative_to(root):add(name)
    config=Path('/opt/padml/config/environment.json')
    if json.loads(config.read_bytes())!=run['environment']:
        raise ContractError('ENVIRONMENT_CONFIGURATION_DRIFT')
    for name in ('/opt/padml/bin/padml-env','/opt/padml/config/environment.sh',
                 str(config),
                 run['environment']['runtime_manifest']['path'],'/etc/os-release','/etc/ld.so.cache',
                 '/etc/nsswitch.conf'):
        if Path(name).exists():add(name)
    # No host passwd/shadow, SSH, cloud configuration, cache or clinical files.
    lock=Path(__file__).parent.parent/'dependency-lock.json'
    lock_value=json.loads(lock.read_bytes())
    if sha256_file(lock)!=run['environment']['lock_sha256']:raise ContractError('ENVIRONMENT_LOCK_DRIFT')
    for name in ('sh','bash','env','sed','grep','uname','mkdir','dirname','cat','tr','cut','which','readlink','ln','rm'):
        found=shutil.which(name)
        if found is None:raise ContractError('ENVIRONMENT_SYSTEM_COMMAND_MISSING:'+name)
        add(found)
    for name in ('/bin','/sbin','/lib','/lib64'):
        if Path(name).exists():add(name)
    legacy=Path('/opt/padml/legacy-runtime')
    if legacy.exists():
        add(legacy)
        for path in legacy.rglob('*'):
            if path.is_symlink():
                if not path.resolve(strict=True).is_relative_to(root):
                    raise ContractError('ENVIRONMENT_LEGACY_TARGET_INVALID')
                add(path)
            elif path.is_dir():add(path)
            else:raise ContractError('ENVIRONMENT_LEGACY_UNDECLARED_FILE')
    missing={};visited=set()
    while elf:
        executable=elf.pop()
        if executable in visited:continue
        visited.add(executable)
        out=subprocess.run(['/opt/padml/bin/padml-env','ldd',str(executable)],
            capture_output=True,text=True,timeout=30)
        # Record exact unresolved objects under the actual launch environment.
        # This inventory does not classify missing libraries as optional.
        for line in out.stdout.splitlines():
            if '=> not found' in line:missing.setdefault(str(executable),[]).append(line.strip().split()[0])
            match=re.search(r'(?:=>\s+)?(/[^\s]+)\s+\(',line)
            if match:add(match.group(1))
    return _sealed({'kind':'PADML_ENVIRONMENT_SNAPSHOT_V1','platform':'Ubuntu22.04-x86_64',
        'runtime_manifest':run['environment']['runtime_manifest'],
        'dependency_lock_sha256':run['environment']['lock_sha256'],
        'environment':run['environment'],'dependency_lock':lock_value,
        'entries':dict(sorted(rows.items())),'unresolved_loader_names':dict(sorted(missing.items())),
        'restore_data_root':'/root/autodl-tmp/padml',
        'compatibility_link':{'path':'/root/autodl-tmp/PADML_V22/runtime','target':'/opt/padml/legacy-runtime'},
        'acceptance':'REQUIRES_OSS_ROUNDTRIP_AND_ISOLATED_NATIVE_CONSUMPTION'})


def environment_layers(snapshot, maximum_bytes=512*1024**2):
    """Bounded parts; links follow every regular file and preserve inode aliases."""
    from .bundle import ContractError
    from .nested_loco import _sealed
    if _sealed({k:v for k,v in snapshot.items() if k!='identity_sha256'})!=snapshot:
        raise ContractError('ENVIRONMENT_SNAPSHOT_DRIFT')
    if not 16*1024**2<=maximum_bytes<=1024**3:raise ContractError('ENVIRONMENT_LAYER_LIMIT_INVALID')
    entries=snapshot['entries'];layers=[];current=[];size=0
    names=sorted(entries,key=lambda k:({'directory':0,'file':1,'hardlink':2,'symlink':3}[entries[k]['kind']],k))
    for name in names:
        row=entries[name];cost=row.get('size_bytes',0) if row['kind']=='file' else 0
        if current and (size+cost>maximum_bytes or len(current)>=8192):
            layers.append({'names':current,'uncompressed_bytes':size});current=[];size=0
        current.append(name);size+=cost
    if current:layers.append({'names':current,'uncompressed_bytes':size})
    return layers


def _environment_link_destination(snapshot,name,target):
    import posixpath
    from .bundle import ContractError
    entries=snapshot['entries']
    path=posixpath.normpath(target if target.startswith('/') else '/'+posixpath.dirname(name)+'/'+target).lstrip('/')
    seen=set()
    for _ in range(128):
        if path in seen:raise ContractError('ENVIRONMENT_LINK_CYCLE')
        seen.add(path);parts=path.split('/');changed=False
        for i in range(1,len(parts)+1):
            prefix='/'.join(parts[:i]);row=entries.get(prefix)
            if row and row['kind']=='symlink':
                suffix='/'.join(parts[i:]);t=row['target']
                base=t if t.startswith('/') else '/'+posixpath.dirname(prefix)+'/'+t
                path=posixpath.normpath(base+('/'+suffix if suffix else '')).lstrip('/')
                changed=True;break
        if not changed:
            if path not in entries:raise ContractError('ENVIRONMENT_LINK_TARGET_MISSING')
            return path
    raise ContractError('ENVIRONMENT_LINK_DEPTH')


def build_environment_layer(snapshot, number, target):
    import hashlib, os, shutil, tarfile
    from pathlib import Path
    from .bundle import ContractError, sha256_file
    from .reports import _persist_published
    target=Path(target);part=target.with_name(target.name+'.part')
    layer=environment_layers(snapshot)[number]
    if target.is_symlink() or part.is_symlink() or not target.parent.is_dir():
        raise ContractError('ENVIRONMENT_LAYER_PATH_INVALID')
    if target.exists():raise ContractError('ENVIRONMENT_LAYER_REUSE_REQUIRES_PUBLISHED_PIN')
    if target.parent.stat().st_dev!=Path('/opt/padml/runtime').stat().st_dev:
        raise ContractError('ENVIRONMENT_LAYER_MUST_USE_SYSTEM_DISK')
    if shutil.disk_usage(target.parent).free<layer['uncompressed_bytes']+4*1024**3+32*1024**2:
        raise ContractError('ENVIRONMENT_SYSTEM_SPACE_INSUFFICIENT')
    with part.open('wb') as output:
        with tarfile.open(fileobj=output,mode='w:gz',compresslevel=1,dereference=False) as archive:
            for name in layer['names']:
                row=snapshot['entries'][name];source=Path('/')/name
                import stat
                if stat.S_IMODE(source.lstat().st_mode)!=row['mode']:
                    raise ContractError('ENVIRONMENT_MODE_DRIFT')
                if row['kind']=='symlink' and (not source.is_symlink() or os.readlink(source)!=row['target']):
                    raise ContractError('ENVIRONMENT_LINK_DRIFT')
                item=tarfile.TarInfo(name);item.mode=row['mode'];item.mtime=0;item.uid=item.gid=0
                if row['kind']=='directory':
                    if not source.is_dir() or source.is_symlink():raise ContractError('ENVIRONMENT_DIRECTORY_DRIFT')
                    item.type=tarfile.DIRTYPE
                elif row['kind'] in {'symlink','hardlink'}:
                    if row['kind']=='hardlink' and (source.is_symlink() or not source.is_file()
                        or not os.path.samefile(source,Path('/')/row['target'])
                        or source.stat().st_size!=row['size_bytes'] or sha256_file(source)!=row['sha256']):
                        raise ContractError('ENVIRONMENT_HARDLINK_SOURCE_DRIFT')
                    item.type=tarfile.SYMTYPE if row['kind']=='symlink' else tarfile.LNKTYPE
                    item.linkname=row['target']
                else:
                    item.size=row['size_bytes']
                    if source.is_symlink() or sha256_file(source)!=row['sha256'] or source.stat().st_size!=item.size:
                        raise ContractError('ENVIRONMENT_FILE_DRIFT')
                    with source.open('rb') as stream:archive.addfile(item,stream)
                    continue
                archive.addfile(item)
        output.flush();os.fsync(output.fileno())
    os.replace(part,target);_persist_published(target)
    return {'snapshot_identity':snapshot['identity_sha256'],'layer':number,
        'sha256':sha256_file(target),'size_bytes':target.stat().st_size,
        'uncompressed_bytes':layer['uncompressed_bytes']}


def _environment_runtime_member(name):
    return name == 'opt/padml' or name.startswith('opt/padml/')


def restore_environment_layer(snapshot, number, source, pin, root, *, installed_root=False):
    """Extract explicit members only; interruption resumes without overwriting drift."""
    import hashlib, os, shutil, stat, tarfile
    from pathlib import Path, PurePosixPath
    from .bundle import ContractError, sha256_file
    from .reports import _persist_published
    source=Path(source);root=Path(root)
    if not root.is_absolute() or not root.is_dir() or root.is_symlink():
        raise ContractError('ENVIRONMENT_RESTORE_ROOT_INVALID')
    layer=environment_layers(snapshot)[number]
    if source.is_symlink() or sha256_file(source)!=pin['sha256'] or source.stat().st_size!=pin['size_bytes']:
        raise ContractError('ENVIRONMENT_LAYER_BYTES_DRIFT')
    if pin.get('snapshot_identity')!=snapshot['identity_sha256'] or pin.get('layer')!=number:
        raise ContractError('ENVIRONMENT_LAYER_IDENTITY_DRIFT')
    needed=0
    for name in layer['names']:
        row=snapshot['entries'][name];path=root/name
        if path.exists() or path.is_symlink():continue
        part=path.with_name(path.name+'.part')
        if part.is_symlink():raise ContractError('ENVIRONMENT_RESTORE_PART_LINK')
        remaining=max(0,row.get('size_bytes',0)-(part.stat().st_size if part.is_file() else 0)) if row['kind']=='file' else 0
        needed+=((remaining+4095)//4096)*4096+4096
    if shutil.disk_usage(root).free<needed+4*1024**3:
        raise ContractError('ENVIRONMENT_SYSTEM_SPACE_INSUFFICIENT')
    with tarfile.open(source,'r:gz') as archive:
        names=[]
        for member in archive:
            name=member.name
            if len(names)>=len(layer['names']) or name!=layer['names'][len(names)] or PurePosixPath(name).is_absolute() or '..' in PurePosixPath(name).parts:
                raise ContractError('ENVIRONMENT_LAYER_MEMBER_INVALID')
            names.append(name)
            row=snapshot['entries'][name];path=root/name
            if member.mode!=row['mode']:raise ContractError('ENVIRONMENT_LAYER_MODE_DRIFT')
            # A compatible host is not an OS byte clone. Preserve its existing
            # support files and permissions before any mkdir/chmod/write; only
            # missing declared support is installed. Host caches/configuration
            # are never copied from the original machine.
            if installed_root and not _environment_runtime_member(name):
                if (path.exists() or path.is_symlink() or name in
                    {'etc/ld.so.cache','etc/nsswitch.conf','etc/os-release','usr/lib/os-release'}):
                    continue
            if any(parent.is_symlink() for parent in path.parents if parent.is_relative_to(root)):
                raise ContractError('ENVIRONMENT_RESTORE_PARENT_LINK')
            path.parent.mkdir(parents=True,exist_ok=True)
            if row['kind']=='directory':
                if not member.isdir() or path.is_symlink():raise ContractError('ENVIRONMENT_LAYER_TYPE_DRIFT')
                path.mkdir(exist_ok=True);os.chmod(path,row['mode']);continue
            if row['kind'] in {'symlink','hardlink'}:
                wanted=member.issym() if row['kind']=='symlink' else member.islnk()
                if not wanted or member.linkname!=row['target']:raise ContractError('ENVIRONMENT_LAYER_LINK_DRIFT')
                if path.exists() or path.is_symlink():
                    if row['kind']=='symlink' and path.is_symlink() and os.readlink(path)==row['target']:continue
                    if row['kind']=='hardlink' and not path.is_symlink() and os.path.samefile(path,root/row['target']):continue
                    raise ContractError('ENVIRONMENT_RESTORE_EXISTING_DRIFT')
                if row['kind']=='symlink':
                    # Absolute links name locations inside the future chroot;
                    # no extraction operation follows them on the host.
                    _environment_link_destination(snapshot,name,row['target'])
                    os.symlink(row['target'],path)
                else:
                    target=root/row['target']
                    if not target.is_file() or target.is_symlink() or sha256_file(target)!=row['sha256']:
                        raise ContractError('ENVIRONMENT_HARDLINK_TARGET_DRIFT')
                    os.link(target,path)
                continue
            if not member.isfile() or member.size!=row['size_bytes']:raise ContractError('ENVIRONMENT_LAYER_TYPE_DRIFT')
            if path.exists():
                if path.is_symlink() or path.stat().st_size!=row['size_bytes'] or sha256_file(path)!=row['sha256']:
                    raise ContractError('ENVIRONMENT_RESTORE_EXISTING_DRIFT')
                if stat.S_IMODE(path.stat().st_mode)!=row['mode']:raise ContractError('ENVIRONMENT_RESTORE_MODE_DRIFT')
                continue
            part=path.with_name(path.name+'.part')
            if part.is_symlink():raise ContractError('ENVIRONMENT_RESTORE_PART_LINK')
            digest=hashlib.sha256()
            with archive.extractfile(member) as stream,part.open('wb') as output:
                while block:=stream.read(1024**2):digest.update(block);output.write(block)
                output.flush();os.fsync(output.fileno())
            if digest.hexdigest()!=row['sha256']:raise ContractError('ENVIRONMENT_RESTORE_BYTES_DRIFT')
            os.chmod(part,row['mode']);os.replace(part,path);_persist_published(path)
        if names!=layer['names']:raise ContractError('ENVIRONMENT_LAYER_COVERAGE_INVALID')
    directories={root}
    for name in names:
        path=root/name;directories.add(path.parent)
        if snapshot['entries'][name]['kind']=='directory':directories.add(path)
    for path in sorted(directories,key=str):
        fd=os.open(path,os.O_RDONLY)
        try:os.fsync(fd)
        finally:os.close(fd)
    return {'layer':number,'status':'RESTORED','members':len(names),'snapshot_identity':snapshot['identity_sha256']}


def isolated_environment_check(root, snapshot, *, installed_root=False):
    """A real chroot cannot reach the producer's original /opt installation."""
    import json, os, platform, shutil, stat, subprocess
    from pathlib import Path
    from .bundle import ContractError
    from .nested_loco import _sealed
    root=Path(root)
    environment_layers(snapshot)
    if platform.system()!='Linux' or os.geteuid()!=0 or (root==Path('/'))!=installed_root or root.is_symlink():
        raise ContractError('ENVIRONMENT_ISOLATION_UNAVAILABLE')
    if root.stat().st_dev!=Path('/').stat().st_dev or shutil.disk_usage(root).free<4*1024**3:
        raise ContractError('ENVIRONMENT_SYSTEM_SPACE_INSUFFICIENT')
    from .bundle import sha256_file,canonical_json_bytes
    for name,row in snapshot['entries'].items():
        if installed_root and not _environment_runtime_member(name):continue
        path=root/name
        if row['kind']=='symlink':
            if not path.is_symlink() or os.readlink(path)!=row['target']:raise ContractError('ENVIRONMENT_RESTORE_LINK_DRIFT')
            _environment_link_destination(snapshot,name,row['target']);continue
        if path.is_symlink() or not path.exists():raise ContractError('ENVIRONMENT_RESTORE_MEMBER_MISSING')
        if row['kind']=='directory':
            if not path.is_dir():raise ContractError('ENVIRONMENT_RESTORE_TYPE_DRIFT')
        elif sha256_file(path)!=row['sha256'] or path.stat().st_size!=row['size_bytes']:
            raise ContractError('ENVIRONMENT_RESTORE_BYTES_DRIFT')
        if stat.S_IMODE(path.stat().st_mode)!=row['mode']:raise ContractError('ENVIRONMENT_RESTORE_MODE_DRIFT')
    lock=root/'opt/padml/config/dependency-lock.json'
    lock.write_bytes(canonical_json_bytes(snapshot['dependency_lock']))
    for name in ('root/autodl-tmp/padml/tmp','root/autodl-tmp/padml/cache','root/autodl-tmp/PADML_V22','tmp','dev','etc'):
        (root/name).mkdir(parents=True,exist_ok=True)
    link=root/'root/autodl-tmp/PADML_V22/runtime'
    if not link.is_symlink():os.symlink('/opt/padml/legacy-runtime',link)
    elif os.readlink(link)!='/opt/padml/legacy-runtime':raise ContractError('ENVIRONMENT_COMPATIBILITY_DRIFT')
    for name,minor in (() if installed_root else (('null',3),('zero',5),('random',8),('urandom',9))):
        path=root/'dev'/name
        if not path.exists():os.mknod(path,stat.S_IFCHR|0o666,os.makedev(1,minor))
        st=path.stat()
        if not stat.S_ISCHR(st.st_mode) or st.st_rdev!=os.makedev(1,minor):
            raise ContractError('ENVIRONMENT_DEVICE_DRIFT')
    # Minimal identities contain no copied passwords or login material.
    for name,body in ([] if installed_root else [('passwd','root:x:0:0:root:/root:/bin/sh\n'),('group','root:x:0:\n')]):
        path=root/'etc'/name
        if path.exists() and path.read_text()!=body:raise ContractError('ENVIRONMENT_IDENTITY_DRIFT')
        path.write_text(body)
    py=r'''
import json,os, numpy as np, pandas, scipy, torch, xgboost, pycox, torchtuples
x=np.arange(120,dtype=float).reshape(40,3)/100;y=np.arange(1,41,dtype=float)
b=xgboost.train({'objective':'survival:cox','nthread':1,'seed':1},xgboost.DMatrix(x,label=y),num_boost_round=2)
assert np.isfinite(b.inplace_predict(x)).all()
from pycox.models import CoxTime
from pycox.models.cox_time import MLPVanillaCoxTime
lab=CoxTime.label_transform();out=lab.fit_transform(y,np.ones(40,dtype=int))
model=CoxTime(MLPVanillaCoxTime(3,[4],batch_norm=False,dropout=0),torchtuples.optim.Adam,labtrans=lab)
model.fit(x.astype('float32'),out,batch_size=16,epochs=1,verbose=False)
model.compute_baseline_hazards();assert np.isfinite(model.predict_surv_df(x[:3].astype('float32')).values).all()
assert os.environ['RETICULATE_PYTHON']=='/opt/padml/runtime/py-env/bin/python'
assert os.environ['OMP_NUM_THREADS']=='1'
print(json.dumps({'status':'PASS','python':os.sys.executable,'xgboost':xgboost.__version__,'torch':torch.__version__}))
'''
    r=r'''
pkgs<-c('mice','mRMRe','Boruta','ranger','gbm','glmnet','rstpm2','survival','kernelshap','reticulate')
paths<-setNames(lapply(pkgs,function(p) normalizePath(find.package(p))),pkgs)
environment<-jsonlite::fromJSON('/opt/padml/config/environment.json')
expected<-strsplit(environment$r_library,':',fixed=TRUE)[[1]]
stopifnot(identical(normalizePath(.libPaths()[seq_along(expected)]),normalizePath(expected)))
for(p in pkgs) stopifnot(startsWith(paths[[p]],'/opt/padml/runtime/'))
lock<-jsonlite::fromJSON('/opt/padml/config/dependency-lock.json')
for(p in intersect(names(lock$engine_contract_versions),pkgs)) stopifnot(as.character(utils::packageVersion(p))==lock$engine_contract_versions[[p]])
invisible(lapply(pkgs,loadNamespace));set.seed(771)
d<-data.frame(time=seq_len(100)+0.25,status=rep(c(1,1,0,1),25),x=rnorm(100),z=rnorm(100))
cf<-survival::coxph(survival::Surv(time,status)~x+z,data=d)
rf<-ranger::ranger(survival::Surv(time,status)~x+z,data=d,num.trees=10,num.threads=1)
gb<-gbm::gbm(survival::Surv(time,status)~x+z,data=d,distribution='coxph',n.trees=5,interaction.depth=1,verbose=FALSE)
en<-glmnet::glmnet(as.matrix(d[,c('x','z')]),survival::Surv(d$time,d$status),family='cox',lambda=c(.1,.01))
fp<-rstpm2::stpm2(survival::Surv(time,status)~x+z,data=d,df=3)
md<-d[,c('x','z')];md$x[c(2,4)]<-NA
mi<-mice::mice(md,m=2,maxit=1,method='pmm',printFlag=FALSE,seed=771)
mr<-mRMRe::mRMR.classic(data=mRMRe::mRMR.data(data=d[,c('time','x','z')]),target_indices=1,feature_count=1)
bo<-Boruta::Boruta(survival::Surv(time,status)~x+z,data=d,maxRuns=11,ntree=10,holdHistory=FALSE,doTrace=0)
pr<-function(object,X) sapply(c(.1,.2,.3,.4),function(h) 1-exp(-h*exp(X$x+X$z)))
sh<-kernelshap::kernelshap(NULL,d[1:2,c('x','z')],bg_X=d[3:6,c('x','z')],pred_fun=pr,verbose=FALSE)
stopifnot(all(is.finite(unlist(sh$S))),all(is.finite(predict(cf,newdata=d,type='lp'))),all(is.finite(predict(fp,newdata=d,type='surv'))))
reticulate::use_python('/opt/padml/runtime/py-env/bin/python',required=TRUE)
original<-matrix(as.double(1:12),nrow=3);back<-reticulate::py_to_r(reticulate::r_to_py(original))
stopifnot(identical(original,back))
cat(jsonlite::toJSON(list(status='PASS',packages=paths,library_paths=.libPaths(),python=reticulate::py_config()$python),auto_unbox=TRUE))
'''
    records={}
    for name,args in [('python',['/opt/padml/runtime/py-env/bin/python','-c',py]),
                      ('R',['/opt/padml/runtime/r-env/bin/Rscript','--vanilla','-e',r])]:
        command=[*([] if installed_root else ['chroot',str(root)]),'/opt/padml/bin/padml-env',*args]
        result=subprocess.run(command,capture_output=True,text=True,timeout=240,
            env={'PATH':'/usr/sbin:/usr/bin:/sbin:/bin','HOME':'/root','LANG':'C.UTF-8'})
        if result.returncode:raise ContractError('ENVIRONMENT_ISOLATED_'+name+'_FAILED:'+result.stderr[-2000:])
        records[name]={'returncode':0,'native_output':result.stdout[-12000:]}
    support={}
    if installed_root:
        # The actual linker is exercised on the restored runtimes. Preserve
        # evidence of the host closure, without claiming it matches the archive.
        for name in ('python','rscript'):
            executable=snapshot['environment'][name]
            result=subprocess.run(['/opt/padml/bin/padml-env','ldd',str(Path(executable).resolve())],
                capture_output=True,text=True,timeout=60)
            if result.returncode or 'not found' in result.stdout:
                raise ContractError('ENVIRONMENT_HOST_LOADER_UNRESOLVED')
            support[name]=result.stdout
    return _sealed({'kind':'PADML_ENVIRONMENT_ISOLATED_ACCEPTANCE_V1',
        'status':'INSTALLED_NATIVE_PASS' if installed_root else 'ISOLATED_NATIVE_PASS',
        'snapshot_identity':snapshot['identity_sha256'],
        'isolation':'INSTALLED_SYSTEM_ROOT' if installed_root else 'CHROOT_NO_ORIGINAL_PATH_ACCESS',
        'checks':records,'system_free_bytes':shutil.disk_usage(root).free,
        'os_support_policy':'EXISTING_HOST_PRESERVED_MISSING_DECLARED_SUPPORT_INSTALLED' if installed_root else 'EXACT_ISOLATED_OS_CLOSURE',
        'host_loader_checks':support,
        'data_disk_mount_check':'REQUIRED_OUTSIDE_CHROOT_NOT_CLAIMED_BY_ISOLATED_TEST',
        'formal_model_fits':0,'formal_mice_chains':0})


def restore_oss_environment(root, work, envelope):
    """System-Python bootstrap; no original run, owner or installed runtime needed."""
    import fcntl,os,platform,shutil
    from pathlib import Path
    from . import oss
    from .bundle import ContractError,canonical_json_bytes,strict_json_bytes
    from .nested_loco import _sealed
    from .reports import _publish,_persist_published
    from .integrated import qualified_file_pins
    root,work=Path(root),Path(work)
    if (platform.system()!='Linux' or platform.machine()!='x86_64' or os.geteuid()!=0
        or 'VERSION_ID="22.04"' not in Path('/etc/os-release').read_text()
        or not root.is_absolute() or root.is_symlink() or not work.is_absolute() or work.is_symlink()):
        raise ContractError('ENVIRONMENT_BOOTSTRAP_PLATFORM_OR_ROOT_INVALID')
    root.mkdir(parents=True,exist_ok=True);work.mkdir(parents=True,exist_ok=True)
    if root.stat().st_dev!=Path('/').stat().st_dev or work.stat().st_dev!=Path('/').stat().st_dev:
        raise ContractError('ENVIRONMENT_BOOTSTRAP_NOT_SYSTEM_DISK')
    if root==Path('/'):
        data=Path('/root/autodl-tmp')
        if not data.is_dir() or data.stat().st_dev==root.stat().st_dev:
            raise ContractError('ENVIRONMENT_DATA_DISK_NOT_MOUNTED')
    capabilities=envelope['capabilities']
    def fetch(obj,path,remaining=0):
        pin={k:obj[k] for k in ('sha256','size_bytes')}
        if path.exists():
            qualified_file_pins({'object':path},identity=pin,expected={'object':pin},
                record=path.with_name(path.name+'.qualified.json'))
        else:
            def space(count):
                if shutil.disk_usage(work).free<count+remaining+4*1024**3:
                    raise ContractError('ENVIRONMENT_SYSTEM_SPACE_INSUFFICIENT')
            oss.download_resume(path,obj['object_key'],pin,capability=capabilities[obj['object_key']],before_write=space)
    with (work/'active.lock').open('a+') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        descriptor_path=work/'environment.json';fetch(envelope['descriptor'],descriptor_path)
        descriptor=strict_json_bytes(descriptor_path.read_bytes())
        if (_sealed({k:v for k,v in descriptor.items() if k!='identity_sha256'})!=descriptor
            or descriptor['kind']!='PADML_OSS_ENVIRONMENT_V1'):
            raise ContractError('ENVIRONMENT_DESCRIPTOR_DRIFT')
        prefix='padml-environments/'+descriptor['environment_identity']+'/'
        if any(not obj['object_key'].startswith(prefix) for obj in
               [envelope['descriptor'],descriptor['snapshot'],*descriptor['layers']]):
            raise ContractError('ENVIRONMENT_BOOTSTRAP_SCOPE_INVALID')
        snapshot_path=work/'snapshot.json';fetch(descriptor['snapshot'],snapshot_path)
        snapshot=strict_json_bytes(snapshot_path.read_bytes());layers=environment_layers(snapshot)
        _publish(work/'root.json',canonical_json_bytes({'path':str(root),'device':root.stat().st_dev,
            'inode':root.stat().st_ino,'snapshot_identity':snapshot['identity_sha256']}),'ENVIRONMENT_RESTORE_ROOT_DRIFT')
        if len(descriptor['layers'])!=len(layers):raise ContractError('ENVIRONMENT_LAYER_COVERAGE_INVALID')
        for number,obj in enumerate(descriptor['layers']):
            if obj['layer']!=number or obj['snapshot_identity']!=snapshot['identity_sha256']:
                raise ContractError('ENVIRONMENT_LAYER_IDENTITY_DRIFT')
            path=work/f'layer-{number:04d}.tgz';done=work/f'layer-{number:04d}.json'
            if done.exists():
                saved=strict_json_bytes(done.read_bytes())
                if saved['pin']!=obj:raise ContractError('ENVIRONMENT_RESTORE_RECEIPT_DRIFT')
            else:
                remaining=sum(((snapshot['entries'][name].get('size_bytes',0)+4095)//4096)*4096+4096
                    for name in layers[number]['names'] if not (root/name).exists() and not (root/name).is_symlink())
                fetch(obj,path,remaining)
                restored=restore_environment_layer(snapshot,number,path,obj,root,installed_root=root==Path('/'))
                _publish(done,canonical_json_bytes({**restored,'pin':obj}),'ENVIRONMENT_RESTORE_RECEIPT_DRIFT')
            if path.exists():
                fetch(obj,path);path.unlink();_persist_published(done)
        def unchanged_files():
            stamps=[]
            for name in snapshot['entries']:
                path=root/name
                if root==Path('/') and not _environment_runtime_member(name) and not (path.exists() or path.is_symlink()):
                    stamps.append([name,'HOST_SUPPORT_ABSENT']);continue
                value=path.lstat()
                stamps.append([name,value.st_dev,value.st_ino,value.st_size,value.st_mode,value.st_mtime_ns,value.st_ctime_ns])
            return __import__('hashlib').sha256(canonical_json_bytes(stamps)).hexdigest()
        acceptance=work/'acceptance.json'
        if acceptance.exists():
            result=strict_json_bytes(acceptance.read_bytes())
            if (_sealed({k:v for k,v in result.items() if k!='identity_sha256'})!=result
                or result['snapshot_identity']!=snapshot['identity_sha256']
                or result['restored_files_stamp']!=unchanged_files()):
                raise ContractError('ENVIRONMENT_RESTORE_ACCEPTANCE_DRIFT')
            return result
        checked=isolated_environment_check(root,snapshot,installed_root=root==Path('/'))
        result=_sealed({k:v for k,v in checked.items() if k!='identity_sha256'}|
            {'restored_files_stamp':unchanged_files(),
             'stamp_scope':'EXACT_RUNTIME_AND_OBSERVED_HOST_STATE' if root==Path('/') else 'EXACT_ISOLATED_ENTRIES'})
        _publish(acceptance,canonical_json_bytes(result),'ENVIRONMENT_RESTORE_ACCEPTANCE_DRIFT')
        return result


def environment_archive_operation(run,payload,body):
    """Sequential environment phases under the original archive and worker leases."""
    import fcntl,json,os,re,shutil,tarfile,hashlib,subprocess
    from pathlib import Path
    from .bundle import ContractError,canonical_json_bytes,strict_json_bytes,sha256_file
    from .nested_loco import _sealed
    from .reports import _publish,_persist_published,validate_archive_transfer
    from . import oss
    cfg=validate_archive_transfer(run);identity=payload['environment_identity'];action=payload['action']
    if re.fullmatch('[0-9a-f]{64}',identity) is None:raise ContractError('ENVIRONMENT_IDENTITY_INVALID')
    if action not in {'snapshot','layer','upload','bootstrap','retire_test'}:
        raise ContractError('ENVIRONMENT_ACTION_INVALID')
    authority=body['relay_cleanup']
    if (_sealed({k:v for k,v in authority.items() if k!='identity_sha256'})!=authority
        or authority['status']!='RELAY_CLEARED' or authority['prefix']!=cfg['relay_prefix']
        or authority['generation']!=cfg['generation']):raise ContractError('ENVIRONMENT_RESULT_RELAY_NOT_CLEARED')
    folder=Path('/opt/padml/environment-archive')/identity
    if folder.is_symlink() or not folder.resolve().is_relative_to(Path('/opt/padml')):
        raise ContractError('ENVIRONMENT_ARCHIVE_PATH_INVALID')
    folder.mkdir(parents=True,exist_ok=True)
    # Holding a shared existing worker lock excludes a new scientific owner;
    # no synthetic owner record is introduced or overwritten.
    lock=Path(run['run_root'])/'active.lock'
    with lock.open('r') as owner, (folder/'active.lock').open('a+') as serial:
        fcntl.flock(owner,fcntl.LOCK_SH|fcntl.LOCK_NB);fcntl.flock(serial,fcntl.LOCK_EX|fcntl.LOCK_NB)
        records=[json.loads(line) for line in owner if line.strip()]
        if not records or records[-1].get('exit_status')!='RETURNED':
            raise ContractError('ENVIRONMENT_SCIENTIFIC_OWNER_NOT_RETURNED')
        live=subprocess.run(['ps','-eo','pgid='],capture_output=True,text=True,check=True).stdout.split()
        if {str(row['pgid']) for row in records}&set(live):raise ContractError('ENVIRONMENT_SCIENTIFIC_GROUP_ALIVE')
        prefix='padml-environments/'+identity+'/'
        path=folder/'snapshot.json'
        if action=='bootstrap':
            from .bundle import extract_safe_zip, inspect_safe_zip_manifest
            retired=folder/'restore-retired.json'
            if retired.exists():
                old=strict_json_bytes(retired.read_bytes());acceptance=strict_json_bytes((folder/'bootstrap/acceptance.json').read_bytes())
                descriptor=folder/'bootstrap/environment.json';pin=body['bootstrap']['descriptor']
                if (old['status']!='ISOLATED_TEST_RETIRED' or old['acceptance_identity']!=acceptance['identity_sha256']
                    or _sealed({k:v for k,v in acceptance.items() if k!='identity_sha256'})!=acceptance
                    or sha256_file(descriptor)!=pin['sha256'] or descriptor.stat().st_size!=pin['size_bytes']):
                    raise ContractError('ENVIRONMENT_RETIRED_ACCEPTANCE_DRIFT')
                return acceptance
            source=body['source'];pin={k:source[k] for k in ('sha256','size_bytes')}
            if source['sha256']!=run['source_bundle_sha256'] or source['object_key']!=prefix+'restore-source-'+source['sha256']+'.zip':
                raise ContractError('ENVIRONMENT_RESTORE_SOURCE_INVALID')
            archive=folder/'restore-source.zip'
            oss.download_resume(archive,source['object_key'],pin,capability=body['source_capability'])
            code=folder/'restore-source'
            manifest,names=inspect_safe_zip_manifest(archive,manifest_name='manifest.json')
            if not code.exists():
                extract_safe_zip(archive,code,expected_members=set(names),max_member_bytes=16*1024**2,
                    max_total_bytes=64*1024**2)
            else:
                import zipfile
                with zipfile.ZipFile(archive) as z:
                    if any(not (code/name).is_file() or (code/name).is_symlink()
                        or (code/name).read_bytes()!=z.read(name) for name in names):
                        raise ContractError('ENVIRONMENT_RESTORE_SOURCE_DRIFT')
            root=Path('/opt/padml/environment-restore')/identity
            bootstrap=canonical_json_bytes({'members':[],'pins':{},'tokens':body['bootstrap']})
            command=['/usr/bin/python3','-B','-S','-m','padml.runtime_bundle','restore',
                '--root',str(root),'--work',str(folder/'bootstrap'),'--envelope-pin',
                json.dumps({'sha256':hashlib.sha256(bootstrap).hexdigest(),'size_bytes':len(bootstrap)})]
            result=subprocess.run(command,cwd=code,input=bootstrap,
                capture_output=True,timeout=1700,
                env={'PATH':'/usr/sbin:/usr/bin:/sbin:/bin','HOME':'/root','LANG':'C.UTF-8'})
            if result.returncode:raise ContractError('ENVIRONMENT_SYSTEM_PYTHON_BOOTSTRAP_FAILED:'+result.stderr.decode(errors='replace')[-1500:])
            value=strict_json_bytes(result.stdout)
            if value['status']!='ISOLATED_NATIVE_PASS':raise ContractError('ENVIRONMENT_RESTORE_NOT_ACCEPTED')
            return value
        if action=='snapshot':
            if not path.exists():_publish(path,canonical_json_bytes(environment_snapshot(run)),'ENVIRONMENT_SNAPSHOT_DRIFT')
            snapshot=strict_json_bytes(path.read_bytes());environment_layers(snapshot)
            return {'snapshot':snapshot,'pin':{'sha256':sha256_file(path),'size_bytes':path.stat().st_size},
                'layers':len(environment_layers(snapshot))}
        if action=='retire_test':
            snapshot=strict_json_bytes((folder/'bootstrap/snapshot.json').read_bytes());environment_layers(snapshot)
        else:
            snapshot=strict_json_bytes(path.read_bytes());environment_layers(snapshot)
        if action in {'layer','upload'}:
            number=payload['layer']
            if type(number) is not int or not 0<=number<len(environment_layers(snapshot)):
                raise ContractError('ENVIRONMENT_LAYER_NUMBER_INVALID')
            layer_path=folder/f'layer-{number:04d}.tgz';record_path=folder/f'layer-{number:04d}.json'
            if action=='layer':
                if record_path.exists():return strict_json_bytes(record_path.read_bytes())
                if layer_path.exists():
                    # The former writer may have died after rename but before
                    # its small receipt. Verify this exact layer, then publish.
                    expected=environment_layers(snapshot)[number]['names'];seen=[]
                    with tarfile.open(layer_path,'r:gz') as archive:
                        for member in archive:
                            if len(seen)>=len(expected) or member.name!=expected[len(seen)]:
                                raise ContractError('ENVIRONMENT_LAYER_MEMBER_INVALID')
                            seen.append(member.name);row=snapshot['entries'][member.name]
                            if row['kind']=='file':
                                if not member.isfile() or member.size!=row['size_bytes']:raise ContractError('ENVIRONMENT_LAYER_TYPE_DRIFT')
                                digest=hashlib.sha256()
                                with archive.extractfile(member) as stream:
                                    while block:=stream.read(1024**2):digest.update(block)
                                if digest.hexdigest()!=row['sha256']:raise ContractError('ENVIRONMENT_LAYER_BYTES_DRIFT')
                            elif row['kind'] in {'symlink','hardlink'} and member.linkname!=row['target']:
                                raise ContractError('ENVIRONMENT_LAYER_LINK_DRIFT')
                    if seen!=expected:raise ContractError('ENVIRONMENT_LAYER_COVERAGE_INVALID')
                    result={'snapshot_identity':snapshot['identity_sha256'],'layer':number,
                        'sha256':sha256_file(layer_path),'size_bytes':layer_path.stat().st_size,
                        'uncompressed_bytes':environment_layers(snapshot)[number]['uncompressed_bytes']}
                else:result=build_environment_layer(snapshot,number,layer_path)
                _publish(record_path,canonical_json_bytes(result),'ENVIRONMENT_LAYER_RECORD_DRIFT')
                return result
            if action=='upload':
                pin=strict_json_bytes(record_path.read_bytes());key=prefix+'layers/'+pin['sha256']+'.tgz'
                if body['tokens']['key']!=key:raise ContractError('ENVIRONMENT_UPLOAD_SCOPE_INVALID')
                uploaded=folder/f'layer-{number:04d}-uploaded.json'
                if not uploaded.exists():
                    oss.upload_parts(layer_path,{k:pin[k] for k in ('sha256','size_bytes')},body['tokens'])
                    _publish(uploaded,canonical_json_bytes({'status':'UPLOADED','pin':pin,'key':key}),
                        'ENVIRONMENT_UPLOAD_RECEIPT_DRIFT')
                if layer_path.exists():
                    if layer_path.is_symlink() or sha256_file(layer_path)!=pin['sha256']:
                        raise ContractError('ENVIRONMENT_LAYER_BYTES_DRIFT')
                    layer_path.unlink();_persist_published(uploaded)
                return strict_json_bytes(uploaded.read_bytes())
        root=Path('/opt/padml/environment-restore')/identity
        if root.is_symlink() or not root.resolve().is_relative_to(Path('/opt/padml')):
            raise ContractError('ENVIRONMENT_RESTORE_ROOT_INVALID')
        binding=folder/'bootstrap/root.json'
        if action=='retire_test':
            acceptance=folder/'bootstrap/acceptance.json'
            value=strict_json_bytes(acceptance.read_bytes())
            if (_sealed({k:v for k,v in value.items() if k!='identity_sha256'})!=value
                or value['status']!='ISOLATED_NATIVE_PASS' or value['snapshot_identity']!=snapshot['identity_sha256']):
                raise ContractError('ENVIRONMENT_RESTORE_NOT_ACCEPTED')
            bound=strict_json_bytes(binding.read_bytes())
            if root.exists():
                if bound!={'path':str(root),'device':root.stat().st_dev,'inode':root.stat().st_ino,
                    'snapshot_identity':snapshot['identity_sha256']}:
                    raise ContractError('ENVIRONMENT_RESTORE_ROOT_DRIFT')
                shutil.rmtree(root)
            done=folder/'restore-retired.json'
            _publish(done,canonical_json_bytes({'status':'ISOLATED_TEST_RETIRED',
                'acceptance_identity':value['identity_sha256']}),'ENVIRONMENT_TEST_RETIREMENT_DRIFT')
            return strict_json_bytes(done.read_bytes())
        raise ContractError('ENVIRONMENT_ACTION_INVALID')


if __name__=='__main__':
    import argparse,json,sys
    from pathlib import Path
    from .reports import archive_members_from_stream
    from .bundle import ContractError
    parser=argparse.ArgumentParser(prog='python3 -m padml.runtime_bundle')
    parser.add_argument('operation',choices=['restore'])
    parser.add_argument('--root',type=Path,required=True)
    parser.add_argument('--work',type=Path,required=True)
    parser.add_argument('--envelope-pin',type=json.loads,required=True)
    args=parser.parse_args()
    # Use the same bounded pipe implementation; bootstrap JSON is data supplied
    # through stdin, never an account credential in argv or a saved config.
    data=archive_members_from_stream(args.envelope_pin,sys.stdin.buffer,envelope=True)
    if data['members']!=[] or data['pins']!={}:raise ContractError('ENVIRONMENT_BOOTSTRAP_INPUT_INVALID')
    print(json.dumps(restore_oss_environment(args.root,args.work,data['tokens'])))
