"""Outcome-free application MICE: raw donors -> native chains -> exact replay.

This is the deployment calculation entry, not a scheduler. A04 uses this same
entry for a center batch and each single patient, resetting the registered
imputation roots per transaction. No response or fitted model enters MICE.
"""

from __future__ import annotations

from .runtime import MIN_WORKER_MEMORY_BYTES

from .carriers import open_carrier, source_pin, source_root

from contextlib import contextmanager

import csv
import argparse
import io
import math
import json
import os
import shutil
import subprocess
import tempfile
import zipfile
from functools import partial
from pathlib import Path
from typing import Any, Mapping

from ._science_authority import load_science_authority
from .bundle import (ContractError, canonical_json_bytes, extract_safe_zip,
                     read_safe_zip, sha256_bytes, sha256_file, strict_json_bytes,
                     validate_sha256, write_deterministic_zip)
from .runtime import (RSCRIPT_EXECUTABLE, THREAD_ENV, R_LIBRARY,
                      _bounded_ordered_spawn, resolve_pool_workers)


def _require(condition: bool, reason: str) -> None:
    if not condition:
        raise ContractError(reason)


def _new_target(path: Path) -> None:
    _require(path.is_absolute() and path.parent.is_dir() and not path.parent.is_symlink()
             and path.parent.resolve(strict=True) == path.parent
             and not path.exists() and not path.is_symlink(), "F5_APPLICATION_TARGET_INVALID")


def _csv_rows(raw: bytes) -> tuple[list[str], list[dict[str, str]]]:
    try:
        reader = csv.DictReader(io.StringIO(raw.decode("utf-8-sig")))
        rows = list(reader)
    except (UnicodeDecodeError, csv.Error) as exc:
        raise ContractError("F5_APPLICATION_RAW_INPUT_INVALID") from exc
    columns = load_science_authority()["science"]["mice"]["private_handoff"]["columns"]
    _require(reader.fieldnames == columns and bool(rows)
             and all(set(row) == set(columns)
                     and all(isinstance(value, str) for value in row.values()) for row in rows),
             "F5_APPLICATION_RAW_INPUT_INVALID")
    ids = [row["Patient_ID"] for row in rows]
    _require(all(ids) and len(ids) == len(set(ids)), "F5_APPLICATION_RAW_PATIENT_INVALID")
    return columns, rows


def _csv_bytes(columns: list[str], rows: list[dict[str, str]]) -> bytes:
    stream = io.StringIO(newline="")
    writer = csv.DictWriter(stream, fieldnames=columns, lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
    return stream.getvalue().encode()


def application_context(f2_run_root: Path | None, lineage: Mapping[str, Any], *,
                        f1_runtime_root: Path | None = None,
                        raw_binding_root: Path | None = None,
                        input_root: Path | None = None,
                        compiled_input_record: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """Bind final SetA and the raw development population to accepted F1/F2.

    Training-response provenance is checked here, outside the response-free
    application process. This does not claim that all upstream readers are blind.
    """
    from .f2_kernel import _response_rows, _write_response_subset
    from .f4 import load_f4_inputs, _patient_key_mapping
    from .f5 import _validate_final_aggregate_lineage, _consume_final_parameter_source

    nested_full = lineage.get("final_refit_plan", {}).get("kind") == "PADML_NESTED_FULL_FINAL_INPUT_V1"
    if nested_full:
        _consume_final_parameter_source(lineage, None, input_root=input_root,
                                        compiled_input_record=compiled_input_record)
    else:
        _require(input_root is None and compiled_input_record is None,
                 "F5_APPLICATION_FINAL_POPULATION_MISMATCH")
        _validate_final_aggregate_lineage(lineage)
    if raw_binding_root is not None:
        from .integrated import load_raw_binding
        _require(nested_full and f2_run_root is None and f1_runtime_root is None, "FRESH_APPLICATION_SCOPE_INVALID")
        frozen = load_raw_binding(raw_binding_root)
        inputs = None
    else:
        inputs = load_f4_inputs(f2_run_root, include_o_fit_source=True, f1_runtime_root=f1_runtime_root)
        frozen = inputs["o_fit_source"]
    if nested_full:
        context = lineage["final_refit_plan"]["training_context"]
        ids = context["training_ids"]
        response_sha256 = context["training_response_sha256"]
        _require(context["scope"] == "FULL_DATA" and context["outer_fold"] == 0
                 and context["centers_by_patient"] == {patient: frozen["centers"][patient] for patient in ids},
                 "F5_APPLICATION_FINAL_POPULATION_MISMATCH")
    else:
        ids = lineage["final_mice"]["fit_ids"]
        response_sha256 = lineage["final_mice"]["fit_response"]["sha256"]
        _require({row["fold"]: row for row in lineage["final_seta_selector_results"]}
                 == {outer: frozen["models"][outer, "ELASTIC_NET_COX"] for outer in range(1, 7)},
                 "F5_APPLICATION_FINAL_POPULATION_MISMATCH")
    fields, responses = _response_rows(frozen["response_csv"])
    ordered_response = (_write_response_subset(fields, responses, ids, None)["private_bytes"]
        if nested_full else frozen["response_csv"])
    _require((set(ids) == set(responses) if nested_full else ids == list(responses))
        and sha256_bytes(ordered_response) == response_sha256
        and lineage["centers"] == [frozen["centers"][patient] for patient in ids],
        "F5_APPLICATION_FINAL_POPULATION_MISMATCH")
    columns, rows = _csv_rows(frozen["covariates_csv"])
    by_id = {row["Patient_ID"]: row for row in rows}
    _require(set(by_id) == set(ids)
             and all(by_id[patient]["Center"] == frozen["centers"][patient] for patient in ids)
             and frozen["binding_contract"]["covariates_sha256"] == sha256_bytes(frozen["covariates_csv"]),
             "F5_APPLICATION_RAW_SOURCE_MISMATCH")
    return {"lineage": lineage, "_f4_inputs": inputs, "donor_ids": ids, "patient_keys": _patient_key_mapping(ids),
            "columns": columns, "raw_rows": by_id,
            "source": {"final_lineage_sha256": sha256_bytes(canonical_json_bytes(dict(lineage))),
                       "binding_contract_sha256": sha256_bytes(canonical_json_bytes(frozen["binding_contract"])),
                       "raw_covariates_sha256": sha256_bytes(frozen["covariates_csv"])}}


def application_input_members(context: Mapping[str, Any], patients: list[str],
                              *, validation: bool = False) -> dict[str, bytes]:
    """Append raw copies with disjoint internal IDs; do not remove their donors."""
    _require(type(validation) is bool and isinstance(patients, list) and bool(patients)
             and len(patients) == len(set(patients))
             and set(patients).issubset(context["donor_ids"]),
             "F5_APPLICATION_PATIENTS_INVALID")
    keys, raw = context["patient_keys"], context["raw_rows"]
    application = [{"source_id": patient, "application_id": "A04/application/" + keys[patient],
                    "patient_key_hash": keys[patient], "center": raw[patient]["Center"]}
                   for patient in sorted(patients, key=keys.__getitem__)]
    donors = list(context["donor_ids"])
    application_ids = [row["application_id"] for row in application]
    _require(not set(donors).intersection(application_ids), "F5_APPLICATION_ID_COLLISION")
    row_ids = donors + application_ids
    m = 2 if validation else 20
    package = Path(__file__).parent
    mice_only = "validation_source_sha256" in context["source"]
    _require(not mice_only or validation and "final_lineage_sha256" not in context["source"],
             "F45_APPLICATION_VALIDATION_SCOPE_INVALID")
    value = {"kind": "PADML_F45_APPLICATION_MICE_ONLY_INPUT" if mice_only else "PADML_F5_APPLICATION_MICE_INPUT",
             **context["source"], "validation": validation,
             "authority_sha256": sha256_file(package / "science/authority.json"),
             "variable_sha256": sha256_file(package / "science/variable.csv"),
             "application_rows": application, "chain_seeds": [150000000 + imp for imp in range(1, m+1)],
             "view": {"view_id": "FINAL_APPLICATION", "role": "APPLICATION", "outer_fold": 0,
                      "analysis_ids": donors, "row_ids": row_ids,
                      "row_ids_sha256": sha256_bytes(canonical_json_bytes(row_ids))}}
    rows = [raw[patient] for patient in donors] + [
        {**raw[item["source_id"]], "Patient_ID": item["application_id"]} for item in application]
    return {"input.json": canonical_json_bytes(value),
            "covariates.csv": _csv_bytes(context["columns"], rows)}


def application_cohort(context: Mapping[str, Any], destination: Path, *, max_per_center: int = 50) -> dict[str, Any]:
    """Lock candidates still missing after the same formula pass used by MICE."""
    _require(max_per_center in {2, 50}, "APPLICATION_COHORT_LIMIT_INVALID")
    _new_target(destination)
    destination.mkdir(mode=0o700)
    package = Path(__file__).parent
    mice_only = "validation_source_sha256" in context["source"]
    _require(not mice_only or "lineage" not in context and "final_lineage_sha256" not in context["source"],
             "F45_APPLICATION_VALIDATION_SCOPE_INVALID")
    lineage = context.get("lineage")
    nested_full = lineage is not None and lineage.get("final_refit_plan", {}).get("kind") == "PADML_NESTED_FULL_FINAL_INPUT_V1"
    selected = (context["validation_selected_parents"] if mice_only else
        lineage["final_refit_plan"]["development_lock"]["selected_parents"] if nested_full else
        lineage["final_seta"]["lock"]["selected_parents"])
    centers = [str(center) for center in load_science_authority()["science"]["population"]["validation_centers"]]
    ids, raw, keys = context["donor_ids"], context["raw_rows"], context["patient_keys"]
    (destination / "covariates.csv").write_bytes(_csv_bytes(context["columns"], [raw[patient] for patient in ids]))
    spec = {"covariates_path": str(destination / "covariates.csv"),
            "variable_path": str(package / "science/variable.csv"),
            "authority_path": str(package / "science/authority.json"),
            "requests": [{"center": center, "selected_parents": selected} for center in centers],
            "output_path": str(destination / "missingness.json")}
    (destination / "spec.json").write_bytes(canonical_json_bytes(spec))
    try:
        with (destination / "stdout.txt").open("wb") as stdout, (destination / "stderr.txt").open("wb") as stderr:
            completed = subprocess.run(
                [RSCRIPT_EXECUTABLE, "--vanilla", str(package / "kernels/f5_a04_membership.R"), str(destination / "spec.json")],
                cwd=destination, env={**os.environ, **THREAD_ENV}, stdout=stdout, stderr=stderr,
                check=False, timeout=60)
        _require(completed.returncode == 0, "F5_APPLICATION_MISSINGNESS_FAILED")
        native = strict_json_bytes((destination / "missingness.json").read_bytes())
        _require(isinstance(native, list) and len(native) == len(centers), "F5_APPLICATION_MISSINGNESS_INVALID")
        result, candidates = [], []
        for ordinal, (center, row) in enumerate(zip(centers, native, strict=True), 1):
            patients = [patient for patient in ids if raw[patient]["Center"] == center]
            fields, missing = row.get("raw_fields"), row.get("missing_sources")
            _require(set(row) == {"center", "patient_ids", "raw_fields", "missing_sources"}
                     and row["center"] == center and row["patient_ids"] == patients
                     and isinstance(fields, list) and fields and len(fields) == len(set(fields))
                     and set(fields).issubset(context["columns"])
                     and isinstance(missing, list) and len(missing) == len(patients)
                     and all(isinstance(items, list) and set(items).issubset(fields)
                             and len(items) == len(set(items)) for items in missing),
                     "F5_APPLICATION_MISSINGNESS_INVALID")
            seed = 409000 + ordinal
            def rank(patient: str) -> tuple[str, str]:
                return (sha256_bytes(canonical_json_bytes({
                    "algorithm_id": "A04_APPLICATION_MEMBERSHIP_ORDER_V1",
                    "patient_key_hash": keys[patient], "sampling_seed": seed}).rstrip(b"\n")), keys[patient])
            eligible = [patient for patient, items in zip(patients, missing, strict=True) if items]
            chosen = sorted(eligible, key=rank)[:max_per_center]
            result.append({"center": center, "sampling_seed": seed, "eligible_count": len(eligible),
                           "selected_ids": chosen, "selected_patient_key_hashes": [keys[patient] for patient in chosen],
                           "status": "LOCKED" if chosen else "NO_APPLICABLE_MISSING_ROWS_IN_FROZEN_SAMPLE",
                           "raw_fields": fields})
            for patient, items in zip(patients, missing, strict=True):
                candidates.append({"source_id": patient, "patient_key_hash": keys[patient], "center": center,
                                   "missing_sources": items, "rank_digest": rank(patient)[0] if items else None,
                                   "included": patient in chosen, "reason": "SELECTED" if patient in chosen else
                                   f"OUTSIDE_FIRST_{max_per_center}_CANONICAL_ORDER" if items else "REQUIRED_RAW_SOURCES_OBSERVED"})
        candidates.extend({"source_id": patient, "patient_key_hash": keys[patient], "center": "55",
                           "missing_sources": None, "rank_digest": None, "included": False,
                           "reason": "TRAINING_DONOR_ONLY_CENTER"}
                          for patient in ids if raw[patient]["Center"] == "55")
        _require(len(candidates) == len(ids), "F5_APPLICATION_COHORT_COVERAGE_INVALID")
        cohort = {"kind": "PADML_F45_APPLICATION_VALIDATION_COHORT" if mice_only else "PADML_F5_APPLICATION_COHORT",
                  "source": context["source"],
                  **({"validation_family": context["validation_family"]} if mice_only else
                     {"final_family": context["lineage"]["final_family"]}), "selected_parents": selected,
                  "centers": result, "candidates": candidates,
                  "patient_count": sum(len(row["selected_ids"]) for row in result),
                  "scope": "INTERNAL_DEVELOPMENT_MISSING_PATTERN_AUDIT_NOT_EXTERNAL_VALIDATION"}
        (destination / "cohort.json").write_bytes(canonical_json_bytes(cohort))
    except BaseException as exc:
        exc.add_note(f"F5_APPLICATION_MEMBERSHIP_EVIDENCE:{destination}")
        raise
    return cohort


def load_application_input(source: Path) -> tuple[dict[str, Any], dict[str, bytes]]:
    from .f4 import _patient_key_mapping

    _require(source.is_absolute() and source.is_file() and not source.is_symlink(),
             "F5_APPLICATION_INPUT_PATH_INVALID")
    entries = read_safe_zip(source, expected_members={"input.json", "covariates.csv"})
    value = strict_json_bytes(entries["input.json"])
    package = Path(__file__).parent
    mice_only = isinstance(value, dict) and value.get("kind") == "PADML_F45_APPLICATION_MICE_ONLY_INPUT"
    lineage_key = "validation_source_sha256" if mice_only else "final_lineage_sha256"
    _require(isinstance(value, dict) and set(value) == {
        "kind", lineage_key, "binding_contract_sha256", "raw_covariates_sha256",
        "validation", "authority_sha256", "variable_sha256", "application_rows", "chain_seeds", "view"}
        and canonical_json_bytes(value) == entries["input.json"]
        and value["kind"] in {"PADML_F5_APPLICATION_MICE_INPUT", "PADML_F45_APPLICATION_MICE_ONLY_INPUT"}
        and type(value["validation"]) is bool and (not mice_only or value["validation"] is True)
        and value["authority_sha256"] == sha256_file(package / "science/authority.json")
        and value["variable_sha256"] == sha256_file(package / "science/variable.csv"),
        "F5_APPLICATION_INPUT_INVALID")
    for name in (lineage_key, "binding_contract_sha256", "raw_covariates_sha256"):
        validate_sha256(value[name], "F5_APPLICATION_SOURCE")
    view, application = value["view"], value["application_rows"]
    m = 2 if value["validation"] else 20
    _require(isinstance(view, dict) and set(view) == {
        "view_id", "role", "outer_fold", "analysis_ids", "row_ids", "row_ids_sha256"}
        and view["view_id"] == "FINAL_APPLICATION" and view["role"] == "APPLICATION"
        and type(view["outer_fold"]) is int and view["outer_fold"] == 0
        and value["chain_seeds"] == list(range(150000001, 150000001+m))
        and all(type(seed) is int for seed in value["chain_seeds"]),
        "F5_APPLICATION_VIEW_INVALID")
    keys = _patient_key_mapping(view["analysis_ids"])
    _require(isinstance(application, list) and bool(application)
             and all(isinstance(row, dict) and set(row) == {
                 "source_id", "application_id", "patient_key_hash", "center"}
                 and isinstance(row["source_id"], str) and row["source_id"] in keys
                 and row["patient_key_hash"] == keys[row["source_id"]]
                 and row["application_id"] == "A04/application/" + keys[row["source_id"]]
                 and row["application_id"] not in keys for row in application),
             "F5_APPLICATION_ID_MAPPING_INVALID")
    application_keys = [row["patient_key_hash"] for row in application]
    _require(application_keys == sorted(set(application_keys))
             and view["row_ids"] == view["analysis_ids"] + [row["application_id"] for row in application]
             and view["row_ids_sha256"] == sha256_bytes(canonical_json_bytes(view["row_ids"])),
             "F5_APPLICATION_ROW_ORDER_INVALID")
    columns, rows = _csv_rows(entries["covariates.csv"])
    _require([row["Patient_ID"] for row in rows] == view["row_ids"],
             "F5_APPLICATION_COVARIATE_ALIGNMENT_INVALID")
    by_id = {row["Patient_ID"]: row for row in rows}
    _require(all(by_id[item["application_id"]] == {
        **by_id[item["source_id"]], "Patient_ID": item["application_id"]}
        and item["center"] == by_id[item["source_id"]]["Center"] for item in application),
        "F5_APPLICATION_RAW_COPY_MISMATCH")
    return value, entries


def _native_sources() -> dict[str, str]:
    from .f5 import _mice_native_sources
    return {**_mice_native_sources(), "f5_application_mice.R": sha256_file(
        Path(__file__).with_name("kernels") / "f5_application_mice.R")}


def _outputs(m: int) -> set[str]:
    from .f5 import _MICE_CONFIGURATION_NAMES
    return {"summary.json", *{f"configuration/{name}.json" for name in _MICE_CONFIGURATION_NAMES},
            *{f"imputations/imp{imp:02d}.csv" for imp in range(1, m+1)}}


def _run(source: Path, root: Path, *, native: Path | None = None) -> dict[str, Any]:
    from .f5 import _TYPED_MICE_ERROR
    value, entries = load_application_input(source)
    (root / "covariates.csv").write_bytes(entries["covariates.csv"])
    package = Path(__file__).parent
    spec = {"mode": "IMPUTE_VIEW", "authority_path": str(package / "science/authority.json"),
            "variable_path": str(package / "science/variable.csv"),
            "covariates_path": str(root / "covariates.csv"), "output_dir": str(root / "output"),
            "view": value["view"], "chain_seeds": value["chain_seeds"]}
    if value["validation"]:
        spec["application_validation"] = True
    (root / "spec.json").write_bytes(canonical_json_bytes(spec))
    environment = {**os.environ, **THREAD_ENV}
    if any(Path(path).is_dir() for path in R_LIBRARY.split(":")):
        environment["R_LIBS_USER"] = R_LIBRARY
    command = [RSCRIPT_EXECUTABLE, "--vanilla", str(package / "kernels/f5_application_mice.R"),
               "FIT" if native is None else "REPLAY", str(root / "spec.json")]
    if native is not None:
        command.append(str(native))
    with (root / "stdout.txt").open("wb") as stdout, (root / "stderr.txt").open("wb") as stderr:
        completed = subprocess.run(command, cwd=root, env=environment, stdout=stdout, stderr=stderr,
                                   check=False, timeout=12*60*60 if native is None else 3600)
    if completed.returncode != 0:
        tokens = sorted(set(_TYPED_MICE_ERROR.findall(
            (root / "stderr.txt").read_text() + (root / "stdout.txt").read_text())))
        raise ContractError(tokens[0] if len(tokens) == 1 else "F5_APPLICATION_NATIVE_EXECUTION_FAILED")
    return value


def execute_application_mice(source: Path, target: Path, *, work_root: Path | None = None) -> dict[str, Any]:
    """Run each registered chain once. Failure evidence stays in its original root."""
    value, _ = load_application_input(source)
    _new_target(target)
    root = work_root or Path(tempfile.mkdtemp(prefix=".application-mice-", dir=target.parent))
    root.mkdir(mode=0o700, parents=True, exist_ok=True)
    m = len(value["chain_seeds"])
    completed_slots = sum((root / "native" / f"imp{i:02d}.rds").is_file() for i in range(1, m+1))
    try:
        _run(source, root)
        outputs = _outputs(m)
        _require({path.relative_to(root / "output").as_posix()
                  for path in (root / "output").rglob("*") if path.is_file()} == outputs
                 and {path.name for path in (root / "native").iterdir()}
                 == {f"imp{imp:02d}.rds" for imp in range(1, m+1)},
                 "F5_APPLICATION_NATIVE_OUTPUT_SET_INVALID")
        summary = strict_json_bytes((root / "output/summary.json").read_bytes())
        _require(summary.get("status") == "PASS" and summary.get("formal_m") == m
                 and __import__("padml.f1_kernel", fromlist=["mice_terminal_valid"]).mice_terminal_valid(summary)
                 and all(summary.get(name) == value["view"][name]
                         for name in ("view_id", "role", "outer_fold", "row_ids_sha256"))
                 and summary.get("row_count") == len(value["view"]["row_ids"])
                 and summary.get("analysis_row_count") == len(value["view"]["analysis_ids"])
                 and summary.get("application_response_columns") == 0
                 and summary.get("application_predictor_matrix_response_edges") == 0,
                 "F5_APPLICATION_NATIVE_SUMMARY_INVALID")
        members = {name: root / "output" / name for name in outputs}
        members.update({f"native/imp{imp:02d}.rds": root / "native" / f"imp{imp:02d}.rds"
                        for imp in range(1, m+1)})
        members.update({name: root / name for name in ("native-session.txt", "stdout.txt", "stderr.txt")})
        members["input.zip"] = source
        members["manifest.json"] = canonical_json_bytes({
            "kind": "PADML_F5_APPLICATION_MICE_NATIVE", "input_sha256": sha256_file(source),
            "native_sources": _native_sources()})
        _require(all(not isinstance(path, Path) or path.is_file() and not path.is_symlink()
                     for path in members.values()), "F5_APPLICATION_NATIVE_MEMBER_INVALID")
        write_deterministic_zip(target, members)
    except BaseException as exc:
        exc.add_note(f"F5_APPLICATION_NATIVE_EVIDENCE:{root}")
        raise
    shutil.rmtree(root)
    return {"status": "COMPUTED_NATIVE_APPLICATION", "stage_acceptance": False,
            "validation": value["validation"], "mice_chains": summary.get("actual_mice_chains", m), "new_model_fits": 0,
            "actual_new_mice_chains": 0 if summary.get("actual_mice_chains") == 0 else m-completed_slots,
            "sha256": sha256_file(target), "size_bytes": target.stat().st_size}


def materialize_application_mice(source: Path, payload: Path, destination: Path, *,
                                retain_evidence: bool = False) -> dict[str, Any]:
    """Reopen donor traces and mids, then regenerate every consumed completed CSV.

    The A04 caller must reconstruct source from the accepted raw context before
    this call. Matching a caller-declared source digest is not cohort acceptance.
    """
    value, _ = load_application_input(source)
    m = len(value["chain_seeds"])
    outputs = _outputs(m)
    expected = outputs | {"manifest.json", "input.zip", "native-session.txt", "stdout.txt", "stderr.txt"} | {
        f"native/imp{imp:02d}.rds" for imp in range(1, m+1)}
    entries = read_safe_zip(payload, expected_members=expected,
                            max_member_bytes=128*1024*1024, max_total_bytes=3*1024**3)
    _require(entries["input.zip"] == source.read_bytes()
             and entries["manifest.json"] == canonical_json_bytes({
                 "kind": "PADML_F5_APPLICATION_MICE_NATIVE", "input_sha256": sha256_file(source),
                 "native_sources": _native_sources()}), "F5_APPLICATION_NATIVE_SOURCE_MISMATCH")
    _new_target(destination)
    extract_safe_zip(payload, destination, expected_members=expected,
                     max_member_bytes=128*1024*1024, max_total_bytes=3*1024**3)
    replay = destination / "replay"
    replay.mkdir(mode=0o700)
    try:
        _run(source, replay, native=destination / "native")
        for name in outputs:
            _require((replay / "output" / name).read_bytes() == entries[name],
                     "F5_APPLICATION_NATIVE_REPLAY_MISMATCH")
    except BaseException as exc:
        exc.add_note(f"F5_APPLICATION_REPLAY_EVIDENCE:{destination}")
        raise
    if not retain_evidence:
        shutil.rmtree(replay)
    return {"input": value, "input_dir": str(destination / "imputations"),
            "native_archive_sha256": sha256_file(payload), "stage_acceptance": False}


def _read_full_application_component(application, imp, source, input_raw, parsed):
    """The collector's one MI consumer: bound input, original numbers, native bytes."""
    from .f5 import _read_final_lineage, _full_final_component_numbers, _f45_full_final_reuse_read
    from .f4 import _f4_native_component_inputs
    from .runtime import observe_execution_resources, resource_admission
    lineage, policy = application["lineage"], application["policy"]
    result = application["result_root"] / f"F5_FINAL_FULL_DATA_M{imp:02d}.zip"
    task, _, inputs = parsed
    numbers_path = result.with_suffix(".numbers.json")
    numbers = _read_final_lineage(numbers_path, bounded=True)
    record = numbers["archive"]
    def admit_io(*, memory_bytes):
        resource_admission({**policy, "memory_bytes_per_worker": MIN_WORKER_MEMORY_BYTES,
            "memory_reserve_bytes": policy["memory_reserve_bytes"] + memory_bytes,
            "scratch_reserve_bytes": 0}, observe_execution_resources(source_root(result.parent)), legal_tasks=1)
    producer_task, origin = task, {}
    if "reused_final" in numbers:
        reused = _f45_full_final_reuse_read(lineage["final_refit_plan"], source, result,
            numbers["reused_final"], admit_io=admit_io)
        _require(reused["numbers"] == numbers, "F5_APPLICATION_FINAL_MODEL_SOURCE_MISMATCH")
        entries, producer_task = reused["objects"], reused["original_task"]
        origin = {"reused_final": numbers["reused_final"],
                  "producer_task_sha256": sha256_bytes(canonical_json_bytes(producer_task))}
    else:
        _require(source_pin(result) == {"sha256":record["archive_sha256"], "size_bytes":record["archive_size_bytes"]},
            "F5_APPLICATION_FINAL_MODEL_SOURCE_MISMATCH")
        numbers = _full_final_component_numbers(numbers, input_bundle=source, task=task,
            plan=lineage["final_refit_plan"], native_archive=result, input_raw=input_raw, parsed_component=parsed)
        entries = read_safe_zip(result, expected_members=set(inputs) | {
            "model.bin", "baseline.bin", "fit-health.json", "training-prediction.json", "prediction.json"},
            max_member_bytes=4*1024**3, max_total_bytes=8*1024**3, admit_io=admit_io)
    _require((origin or all(entries[name] == raw for name, raw in inputs.items()))
        and sha256_bytes(entries["model.bin"]) == record["model_sha256"]
        and sha256_bytes(entries["baseline.bin"]) == record["baseline_sha256"],
        "F5_APPLICATION_FINAL_MODEL_SOURCE_MISMATCH")
    _, recipe, training, response, _, _ = _f4_native_component_inputs(inputs)
    model = {"task": task, "producer_task": producer_task,
        "source": {**origin, "imputation": imp, "input_sha256": sha256_bytes(input_raw),
            "selection_horizon_months": lineage["final_refit_plan"]["selection_horizon_months"],
            "final_lineage_sha256": sha256_bytes(canonical_json_bytes(dict(lineage))),
            "result_sha256": record["archive_sha256"], "model_sha256": record["model_sha256"],
            "baseline_sha256": record["baseline_sha256"], "task_sha256": sha256_bytes(canonical_json_bytes(task))}}
    if application["retain_objects"]:
        model.update(covariates=training, response=response, recipe=recipe,
                     objects=(entries["model.bin"], entries["baseline.bin"]))
    return {"numbers": numbers, "model": model}


def load_application_models(lineage: Mapping[str, Any], input_root: Path,
                            result_root: Path, *, replay_evidence: Path | None = None,
                            workers: int | None = 1,
                            resource_policy: Mapping[str, Any] | None = None,
                            compiled_input_record: Mapping[str, Any] | None = None,
                            retain_objects: bool = True) -> list[dict[str, Any]]:
    """Read the actual twenty final objects once, with their own original inputs."""
    from .f2_kernel import _response_rows
    from .f5 import (_read_final_refit_bundle, _validate_final_aggregate_lineage,
                     collect_final_refit_results)

    nested_full = lineage.get("final_refit_plan", {}).get("kind") == "PADML_NESTED_FULL_FINAL_INPUT_V1"
    _require(type(retain_objects) is bool, "F5_APPLICATION_FINAL_MODEL_SOURCE_MISMATCH")
    if nested_full:
        from .f5 import _read_final_lineage
        _require(isinstance(compiled_input_record, Mapping), "F5_FULL_FINAL_COMPILED_INPUT_RECORD_INVALID")
        _require(lineage == _read_final_lineage(input_root / "lineage.json", bounded=True,
            selection_horizon_months=lineage["final_refit_plan"]["selection_horizon_months"]),
            "F5_APPLICATION_FINAL_MODEL_SOURCE_MISMATCH")
        return collect_final_refit_results(result_root, lineage["family_decision"], lineage["final_refit_plan"],
            input_root=input_root, produce_shap=False, replay_evidence=replay_evidence, workers=workers,
            resource_policy=resource_policy, compiled_input_record=compiled_input_record,
            application_models=retain_objects)["application_models"]
    else:
        _require(compiled_input_record is None and resource_policy is None,
                 "F5_APPLICATION_FINAL_MODEL_SOURCE_MISMATCH")
        tasks = _validate_final_aggregate_lineage(lineage)
    collected = collect_final_refit_results(result_root, lineage["family_decision"],
        lineage["final_refit_plan"], input_root=input_root, produce_shap=False,
        replay_evidence=replay_evidence, workers=workers,
        **({"resource_policy": resource_policy, "compiled_input_record": compiled_input_record}
           if nested_full else {}))
    records = {row["imputation"]: row for row in collected["archives"]}
    models = []
    for imp in range(1, 21):
        task = tasks[imp]
        source = input_root / f"{task['task_id']}.zip"
        result = result_root / f"{task['task_id']}.zip"
        documents, inputs = _read_final_refit_bundle(source)
        entries = read_safe_zip(result, expected_members={
            "model.bin", "baseline.bin", "prediction.json", "receipt.json", "fit-health.json"},
            max_member_bytes=8*1024**3, max_total_bytes=16*1024**3)
        record = records[imp]
        _require(documents["task.json"] == task
                 and documents["plan.json"] == lineage["final_refit_plan"]
                 and documents["family-decision.json"] == lineage["family_decision"]
                 and sha256_file(result) == record["archive_sha256"]
                 and sha256_bytes(entries["model.bin"]) == record["model_sha256"]
                 and sha256_bytes(entries["baseline.bin"]) == record["baseline_sha256"],
                 "F5_APPLICATION_FINAL_MODEL_SOURCE_MISMATCH")
        _, rows = _csv_rows(inputs["covariates.csv"])
        models.append({"task": task, "covariates": rows,
                       "response": _response_rows(inputs["response.csv"])[1],
                       "recipe": documents["recipe.json"]["recipe"],
                       "objects": (entries["model.bin"], entries["baseline.bin"]),
                       "source": {"imputation": imp, "input_sha256": sha256_file(source),
                                  "final_lineage_sha256": sha256_bytes(canonical_json_bytes(dict(lineage))),
                                  "result_sha256": record["archive_sha256"],
                                  "model_sha256": record["model_sha256"],
                                  "baseline_sha256": record["baseline_sha256"],
                                  "task_sha256": task["task_sha256"]}})
    return models


def _model_pairing(models: list[dict[str, Any]], value: Mapping[str, Any], prepared_parity: bool) -> None:
    _require(value.get("kind") == "PADML_F5_APPLICATION_MICE_INPUT"
             and type(prepared_parity) is bool and isinstance(models, list) and len(models) == 20
             and [row["task"]["imputation"] for row in models] == list(range(1, 21))
             and len(value["chain_seeds"]) == (2 if value["validation"] else 20)
             and all(row["source"]["final_lineage_sha256"] == value["final_lineage_sha256"]
                     and [patient["Patient_ID"] for patient in row["covariates"]] == value["view"]["analysis_ids"]
                     for row in models), "F5_APPLICATION_MODEL_PAIRING_INVALID")
    horizon = models[0]["source"].get("selection_horizon_months", 24)
    _require(type(horizon) is int and horizon in {6, 12, 24, 36}
             and all(type(row["source"].get("selection_horizon_months", 24)) is int
                     and row["source"].get("selection_horizon_months", 24) == horizon for row in models),
             "F5_APPLICATION_MODEL_HORIZON_MISMATCH")


def predict_completed_application(models: list[dict[str, Any]], value: Mapping[str, Any],
                                  imputations: Path | None, evidence: Path, *, prepared_parity: bool,
                                  retain_evidence: bool = False,
                                  completed_rows: Mapping[int, list[dict[str, str]]] | None = None) -> dict[str, Any]:
    """Each MI uses its own model/recipe/baseline; average probabilities, not risk scores.

    Optional prepared parity reuses the identical completed rows, without MICE.
    It is recorded separately from the fresh batch/single imputation comparison.
    """
    from .f2_kernel import _seal_prediction_matrix
    from .f4 import HORIZONS, REPORT_HORIZONS
    from .f5 import _execute_final_refit_engine

    m = len(value["chain_seeds"])
    _model_pairing(models, value, prepared_parity)
    horizon = models[0]["source"].get("selection_horizon_months", 24)
    _new_target(evidence)
    evidence.mkdir(mode=0o700)
    application = value["application_rows"]
    ids = [row["application_id"] for row in application]
    _require((imputations is None) != (completed_rows is None)
        and (completed_rows is None or set(completed_rows) == set(range(1, m+1))),
        "F5_APPLICATION_COMPLETED_SOURCE_INVALID")
    components = []
    for imp, model in enumerate(models[:m], 1):
        if completed_rows is None:
            _, completed = _csv_rows((imputations / f"imp{imp:02d}.csv").read_bytes())
            _require([row["Patient_ID"] for row in completed] == value["view"]["row_ids"],
                     "F5_APPLICATION_COMPLETED_ALIGNMENT_INVALID")
            application_rows = completed[len(value["view"]["analysis_ids"]):]
        else:
            application_rows = completed_rows[imp]
        _require([row["Patient_ID"] for row in application_rows] == ids
            and [row["Center"] for row in application_rows] == [row["center"] for row in application],
                 "F5_APPLICATION_COMPLETED_CENTER_MISMATCH")
        producer = model.get("producer_task", model["task"])
        _require("producer_task_sha256" not in model["source"] or
            sha256_bytes(canonical_json_bytes(producer)) == model["source"]["producer_task_sha256"],
            "F5_APPLICATION_FINAL_MODEL_SOURCE_MISMATCH")
        predicted = _execute_final_refit_engine(model["task"]["family"], producer,
            model["covariates"], model["response"], model["recipe"],
            retained_objects=model["objects"], prediction_rows=application_rows,
            single_parity=prepared_parity,
            **({"replay_evidence": evidence / f"imp{imp:02d}"} if retain_evidence else {}))
        batch = predicted["survival"]
        single = predicted.get("single_survival") if prepared_parity else None
        _require(not prepared_parity or isinstance(single, list) and len(single) == len(batch),
            "F5_APPLICATION_PREPARED_PARITY_MISSING")
        _seal_prediction_matrix(ids, batch, HORIZONS)
        if single is not None:
            _seal_prediction_matrix(ids, single, HORIZONS)
        # Keep the actual separate predictions in the result, not a declaration
        # of exact parity unsupported by the consuming model path.
        if single is not None and single != batch:
            (evidence / f"imp{imp:02d}-parity-failure.json").write_bytes(canonical_json_bytes({
                "source": model["source"], "patient_ids": ids, "batch": batch, "single": single}))
        _require(single is None or single == batch, "F5_APPLICATION_PREPARED_PARITY_FAILED")
        components.append({"imputation": imp, "source": model["source"], "survival": batch,
                           "prepared_single_survival": single})
    mean = [[math.fsum(row["survival"][patient][month] for row in components) / m
             for month in HORIZONS] for patient in range(len(ids))]
    _seal_prediction_matrix(ids, mean, HORIZONS)
    return {"kind": "PADML_F5_APPLICATION_RETAINED_PREDICTIONS", "validation": value["validation"],
            "selection_horizon_months": horizon, "primary_horizon_months": horizon,
            "report_horizons": list(REPORT_HORIZONS),
            "application_rows": application, "horizons": HORIZONS, "components": components,
            "mean_survival": mean,
            "risks": [{"patient_key_hash": row["patient_key_hash"], "center": row["center"],
                       **{f"risk_probability_{h}": 1.0 - mean[patient][h] for h in REPORT_HORIZONS}}
                      for patient, row in enumerate(application)],
            "new_model_fits": 0, "prepared_parity": prepared_parity, "stage_acceptance": False}


def execute_application_transaction(source: Path, target: Path, models: list[dict[str, Any]],
                                    *, prepared_parity: bool) -> dict[str, Any]:
    """One application transaction; no scheduling, search or new model fit."""
    _new_target(target)
    value, _ = load_application_input(source)
    _model_pairing(models, value, prepared_parity)
    root = Path(tempfile.mkdtemp(prefix=".application-", dir=target.parent))
    try:
        execute_application_mice(source, root / "mice.zip")
        native = materialize_application_mice(source, root / "mice.zip", root / "completed")
        result = predict_completed_application(models, value, Path(native["input_dir"]), root / "predictions",
                                               prepared_parity=prepared_parity)
        write_deterministic_zip(target, {"input.zip": source, "mice.zip": root / "mice.zip",
                                         "predictions.json": canonical_json_bytes(result)})
    except BaseException as exc:
        exc.add_note(f"F5_APPLICATION_TRANSACTION_EVIDENCE:{root}")
        raise
    shutil.rmtree(root)
    return {"sha256": sha256_file(target), "size_bytes": target.stat().st_size,
            "mice_chains": len(value["chain_seeds"]), "new_model_fits": 0, "stage_acceptance": False}


def replay_application_transaction(source: Path, payload: Path, models: list[dict[str, Any]],
                                   destination: Path, *, prepared_parity: bool,
                                   retain_evidence: bool = False) -> dict[str, Any]:
    """Reopen the real application chains and the paired final model predictions."""
    _new_target(destination)
    value, _ = load_application_input(source)
    _model_pairing(models, value, prepared_parity)
    entries = read_safe_zip(payload, expected_members={"input.zip", "mice.zip", "predictions.json"},
                            max_member_bytes=3*1024**3, max_total_bytes=4*1024**3)
    _require(entries["input.zip"] == source.read_bytes(), "F5_APPLICATION_TRANSACTION_SOURCE_MISMATCH")
    destination.mkdir(mode=0o700)
    (destination / "mice.zip").write_bytes(entries["mice.zip"])
    try:
        native = materialize_application_mice(source, destination / "mice.zip", destination / "completed",
                                             retain_evidence=retain_evidence)
        result = predict_completed_application(models, value, Path(native["input_dir"]), destination / "predictions",
                                               prepared_parity=prepared_parity, retain_evidence=retain_evidence)
        if retain_evidence:
            (destination / "replayed-predictions.json").write_bytes(canonical_json_bytes(result))
        _require(canonical_json_bytes(result) == entries["predictions.json"],
                 "F5_APPLICATION_RETAINED_PREDICTION_MISMATCH")
    except BaseException as exc:
        exc.add_note(f"F5_APPLICATION_TRANSACTION_REPLAY_EVIDENCE:{destination}")
        raise
    return result


def _audit_json(source: Path, member: str) -> tuple[dict[str, Any], bytes]:
    _require(source.is_absolute() and source.is_file() and not source.is_symlink(),
             "F5_APPLICATION_AUDIT_ARCHIVE_INVALID")
    with open_carrier(source) as archive:
        info = archive.getinfo(member)
        _require(info.file_size <= 64*1024**2, "F5_APPLICATION_AUDIT_METADATA_LIMIT")
        raw = archive.read(info)
    value = strict_json_bytes(raw)
    _require(isinstance(value, dict) and canonical_json_bytes(value) == raw,
             "F5_APPLICATION_AUDIT_METADATA_INVALID")
    return value, raw


def _audit_jobs(cohort: Mapping[str, Any], center: str) -> list[dict[str, Any]]:
    matching = [row for row in cohort["centers"] if row["center"] == center]
    _require(len(matching) == 1, "F5_APPLICATION_AUDIT_CENTER_INVALID")
    row = matching[0]
    patients = [patient for _, patient in sorted(zip(
        row["selected_patient_key_hashes"], row["selected_ids"], strict=True))]
    if not patients:
        return []
    return [{"name": "batch", "patients": patients, "prepared_parity": True},
            *[{"name": f"single-{number:03d}", "patients": [patient], "prepared_parity": False}
              for number, patient in enumerate(patients, 1)]]


def _audit_transaction_result(job: Mapping[str, Any], value: Mapping[str, Any],
                              result: dict[str, Any], archive: Path) -> dict[str, Any]:
    _require(value["validation"] is False and result.get("validation") is False
             and result.get("kind") == "PADML_F5_APPLICATION_RETAINED_PREDICTIONS"
             and result.get("application_rows") == value["application_rows"]
             and result.get("horizons") == list(range(37))
             and result.get("prepared_parity") is job["prepared_parity"]
             and [row.get("imputation") for row in result.get("components", [])] == list(range(1, 21))
             and result.get("new_model_fits") == 0 and result.get("stage_acceptance") is False
             and [row["patient_key_hash"] for row in result["risks"]]
             == [row["patient_key_hash"] for row in value["application_rows"]]
             and [row["center"] for row in result["risks"]]
             == [row["center"] for row in value["application_rows"]],
             "F5_APPLICATION_AUDIT_TRANSACTION_INVALID")
    return {"name": job["name"], "sha256": sha256_file(archive), "size_bytes": archive.stat().st_size,
            "risks": result["risks"], "mice_chains": 20}


def _execute_audit_transaction(job: dict[str, Any], *, models: list[dict[str, Any]]) -> dict[str, Any]:
    source, target = Path(job["input"]), Path(job["target"])
    value, _ = load_application_input(source)
    execute_application_transaction(source, target, models, prepared_parity=job["prepared_parity"])
    result, _ = _audit_json(target, "predictions.json")
    return _audit_transaction_result(job, value, result, target)


def _audit_center_summary(context: Mapping[str, Any], cohort: Mapping[str, Any], center: str,
                          models: list[dict[str, Any]], rows: list[dict[str, Any]]) -> dict[str, Any]:
    jobs = _audit_jobs(cohort, center)
    _require([row["name"] for row in rows] == [job["name"] for job in jobs],
             "F5_APPLICATION_AUDIT_TRANSACTION_COVERAGE_INVALID")
    return {"kind": "PADML_F5_A04_APPLICATION_CENTER", "source": context["source"],
            "center": center, "cohort": cohort, "model_sources": [row["source"] for row in models],
            "transactions": rows, "mice_chain_execution_count": 20*len(jobs), "model_fit_count": 0,
            "status": "COMPUTED_NATIVE_APPLICATION" if jobs else "NO_APPLICABLE_MISSING_ROWS_IN_FROZEN_SAMPLE",
            "stage_acceptance": False}


def execute_application_audit(lineage: Mapping[str, Any], target: Path, *, f2_run_root: Path,
                              input_root: Path, result_root: Path, center: str,
                              workers: int | None = None, f1_runtime_root: Path | None = None) -> dict[str, Any]:
    """One center's batch and singles, in the existing top-level C-8 pool.

    The parent verifies final models once; each reused child receives that same
    immutable model set once, not in every task or every transaction archive.
    Complete transaction ZIPs remain in RESULT.zip.work if another task fails.
    """
    _new_target(target)
    root = target.with_name(target.name + ".work")
    _new_target(root)
    context = application_context(f2_run_root, lineage, f1_runtime_root=f1_runtime_root)
    root.mkdir(mode=0o700)
    try:
        cohort = application_cohort(context, root / "cohort")
        jobs = _audit_jobs(cohort, center)
        models = load_application_models(lineage, input_root, result_root, workers=workers) if jobs else []
        (root / "inputs").mkdir(mode=0o700)
        (root / "transactions").mkdir(mode=0o700)
        for job in jobs:
            source = root / "inputs" / f"{job['name']}.zip"
            write_deterministic_zip(source, application_input_members(context, job["patients"]))
            job.update(input=str(source), target=str(root / "transactions" / f"{job['name']}.zip"))
        capacity = resolve_pool_workers(workers) if jobs else 0
        rows = _bounded_ordered_spawn(partial(_execute_audit_transaction, models=models), jobs,
                                      selected_slots=capacity) if jobs else []
        summary = _audit_center_summary(context, cohort, center, models, rows)
        members = {f"transactions/{job['name']}.zip": Path(job["target"]) for job in jobs}
        write_deterministic_zip(target, {"application-center.json": canonical_json_bytes(summary), **members},
                                stored_members=set(members))
    except BaseException as exc:
        exc.add_note(f"F5_APPLICATION_AUDIT_EVIDENCE:{root}")
        raise
    shutil.rmtree(root)
    return {"status": summary["status"], "stage_acceptance": False, "center": center,
            "mice_chain_execution_count": summary["mice_chain_execution_count"], "model_fit_count": 0,
            "pool_workers": min(capacity, len(jobs)), "sha256": sha256_file(target),
            "size_bytes": target.stat().st_size}


def _replay_application_center(source: Path, context: Mapping[str, Any], cohort: Mapping[str, Any],
                                models: list[dict[str, Any]], destination: Path, *,
                                retain_evidence: bool = False) -> dict[str, Any]:
    from .bundle import _validated_zip_infos, _stream_zip_member

    stored, raw = _audit_json(source, "application-center.json")
    center = stored.get("center")
    jobs = _audit_jobs(cohort, center)
    # Reject changed raw source, cohort or actual final objects before native replay.
    _require(stored.get("source") == context["source"] and stored.get("cohort") == cohort
             and stored.get("model_sources") == ([row["source"] for row in models] if jobs else []),
             "F5_APPLICATION_AUDIT_SOURCE_MISMATCH")
    names = {f"transactions/{job['name']}.zip" for job in jobs}
    _new_target(destination)
    destination.mkdir(mode=0o700)
    try:
        rows = []
        with open_carrier(source) as archive:
            infos = {info.filename: info for info in _validated_zip_infos(archive,
                names | {"application-center.json"}, max_member_bytes=4*1024**3,
                max_total_bytes=205*1024**3, max_compression_ratio=1000)}
            for job in jobs:
                work = destination / job["name"]
                work.mkdir(mode=0o700)
                expected = work / "input.zip"
                write_deterministic_zip(expected, application_input_members(context, job["patients"]))
                value, _ = load_application_input(expected)
                payload = work / "transaction.zip"
                with payload.open("xb") as handle:
                    _stream_zip_member(archive, infos[f"transactions/{job['name']}.zip"], handle)
                prediction = replay_application_transaction(expected, payload, models, work / "replay",
                    prepared_parity=job["prepared_parity"], retain_evidence=retain_evidence)
                rows.append(_audit_transaction_result(job, value, prediction, payload))
                if not retain_evidence:
                    shutil.rmtree(work)
        observed = _audit_center_summary(context, cohort, center, models if jobs else [], rows)
        if retain_evidence:
            (destination / "replayed-center.json").write_bytes(canonical_json_bytes(observed))
        _require(canonical_json_bytes(observed) == raw, "F5_APPLICATION_AUDIT_CENTER_REPLAY_MISMATCH")
    except BaseException as exc:
        exc.add_note(f"F5_APPLICATION_AUDIT_CENTER_REPLAY_EVIDENCE:{destination}")
        raise
    if not retain_evidence:
        shutil.rmtree(destination)
    return observed


def _application_audit_result(context: Mapping[str, Any], cohort: Mapping[str, Any],
                               centers: list[dict[str, Any]], diagnostics: Mapping[str, Any],
                               variants: Mapping[str, Any] | None = None,
                               negative: Mapping[str, Any] | None = None) -> dict[str, Any]:
    from .f5_sensitivity import evaluate_a04_batch_single

    _require([row["center"] for row in centers] == [row["center"] for row in cohort["centers"]],
             "F5_APPLICATION_AUDIT_CENTER_COVERAGE_INVALID")
    batch, single = [], []
    for row in centers:
        transactions = row["transactions"]
        if transactions:
            batch.extend(transactions[0]["risks"])
            single.extend(risk for transaction in transactions[1:] for risk in transaction["risks"])
    expected = {row["patient_key_hash"]: row["center"] for row in cohort["candidates"] if row["included"]}
    _require(len(batch) == len(single) == cohort["patient_count"] == len(expected)
             and all({row["patient_key_hash"]: row["center"] for row in values} == expected
                     for values in (batch, single)), "F5_APPLICATION_AUDIT_PATIENT_COVERAGE_INVALID")
    if expected:
        result = evaluate_a04_batch_single(batch, single)
        # Only the application process is outcome-free: source/model replay
        # legitimately reads original training responses outside that process.
        del result["outcome_read_count"], result["followup_read_count"]
    else:
        result = {"kind": "PADML_F5_A04_BATCH_SINGLE_APPLICATION_V1", "center_results": [],
                  "summary": None, "deployment_gate": {
                      "status": "NOT_ESTIMABLE", "assessed_centers": [], "failed_centers": [],
                      "scope": "NO_APPLICABLE_MISSING_ROWS_IN_FROZEN_SAMPLE"},
                  "selection_effect": "NONE", "stage_acceptance": False}
    result.update({"status": "COMPUTED_NATIVE_APPLICATION_AUDIT",
        "execution_evidence_status": ("APPLICATION_MICE_AND_FINAL_MODELS_REPLAYED_OTHER_A04_BRANCHES_MISSING"
                                      if expected else "COHORT_REPLAYED_NO_APPLICABLE_APPLICATION_ROWS"),
        "application_evidence_status": ("NATIVE_MICE_FINAL_MODELS_AND_COHORT_REPLAYED"
                                        if expected else "COHORT_REPLAYED_NO_APPLICABLE_APPLICATION_ROWS"),
        "unverified_authority_sources": ["A04_MICE_VARIANTS", "A04_NEGATIVE_CONTROLS"],
        "p2c2t": diagnostics["p2c2t"], "temporal": diagnostics["temporal"],
        "blocking_for_production": True, "source": context["source"], "cohort": cohort,
        "application_response_columns": 0,
        "training_response_usage": "SOURCE_AND_RETAINED_MODEL_REPLAY_OUTSIDE_APPLICATION_MICE",
        "model_fit_count": 0, "mice_chain_execution_count": sum(row["mice_chain_execution_count"] for row in centers),
        "application_transaction_count": sum(len(row["transactions"]) for row in centers),
        "prepared_input_parity": "EXACT_REPLAYED_BATCH_AND_SINGLE" if expected else "NOT_APPLICABLE_NO_AUDIT_ROWS",
        "scope": cohort["scope"], "unaudited_centers": [row["center"] for row in cohort["centers"] if not row["selected_ids"]],
        "center_summaries": centers})
    _require(result["mice_chain_execution_count"] == 20*(len(result["deployment_gate"]["assessed_centers"])
                                                       + cohort["patient_count"])
             <= 6120, "F5_APPLICATION_AUDIT_CHAIN_COUNT_INVALID")
    if variants is not None:
        _require(variants["status"] == "NATIVE_MICE_AND_ORIGINAL_OUTER_MODELS_REPLAYED"
                 and variants["model_fit_count"] == 360 and variants["mice_chain_execution_count"] == 720,
                 "F5_A04_VARIANT_EXECUTION_REQUIRED")
        result.update({"mice_variants": dict(variants),
            "unverified_authority_sources": ["A04_NEGATIVE_CONTROLS"],
            "application_mice_chain_execution_count": result["mice_chain_execution_count"],
            "mice_chain_execution_count": result["mice_chain_execution_count"] + variants["mice_chain_execution_count"],
            "model_fit_count": variants["model_fit_count"]})
    if negative is not None:
        _require(negative["status"] == "NATIVE_NEGATIVE_MICE_MODELS_AND_PERMUTATIONS_REPLAYED"
                 and negative["model_fit_count"] == 18 and negative["mice_chain_execution_count"] == 36
                 and negative["application_new_chain_count"] == 0
                 and negative["prediction_m"] == 1 and negative["analysis_qc_m"] == 2,
                 "F5_A04_NEGATIVE_EXECUTION_REQUIRED")
        result.update({"negative_controls": dict(negative),
            "unverified_authority_sources": [name for name in result["unverified_authority_sources"]
                                              if name != "A04_NEGATIVE_CONTROLS"],
            "application_mice_chain_execution_count": result.get("application_mice_chain_execution_count",
                                                                 result["mice_chain_execution_count"]),
            "mice_chain_execution_count": result["mice_chain_execution_count"] + negative["mice_chain_execution_count"],
            "model_fit_count": result["model_fit_count"] + negative["model_fit_count"]})
    if not result["unverified_authority_sources"]:
        _require(diagnostics["p2c2t"]["status"] == "ORIGINAL_ACCEPTED_ARTIFACTS_AND_SOURCE_TASK_JOINS_READ"
                 and diagnostics["temporal"]["status"] == "NOT_APPLICABLE"
                 and diagnostics["temporal"]["reason"] == "NO_APPROVED_BASELINE_CALENDAR_DATE_IN_FROZEN_INPUT",
                 "F5_A04_FROZEN_DIAGNOSTICS_REQUIRED")
        result.update({"status": "COMPLETED_ZERO_FEEDBACK",
            "execution_evidence_status": "NATIVE_APPLICATION_VARIANTS_NEGATIVE_CONTROLS_AND_FROZEN_DIAGNOSTICS_REPLAYED",
            "blocking_for_production": result["deployment_gate"]["status"] != "PASS"
                                       or negative["blocking_for_production"]})
    return result


def aggregate_application_audit(sources: list[Path], target: Path, lineage: Mapping[str, Any], *,
                                f2_run_root: Path, input_root: Path, result_root: Path,
                                variant_sources: list[Path] | None = None,
                                negative_sources: list[Path] | None = None,
                                f1_runtime_root: Path | None = None) -> dict[str, Any]:
    """Stream six center archives through original raw/MICE/model consumers."""
    from .f5_sensitivity import _a04_frozen_diagnostics

    _new_target(target)
    _require(len(sources) == 6 and len({path.resolve() for path in sources}) == 6,
             "F5_APPLICATION_AUDIT_SIX_CENTERS_REQUIRED")
    context = application_context(f2_run_root, lineage, f1_runtime_root=f1_runtime_root)
    root = Path(tempfile.mkdtemp(prefix=".application-audit-", dir=target.parent))
    try:
        diagnostics = _a04_frozen_diagnostics(f2_run_root, context["_f4_inputs"], lineage["final_family"])
        cohort = application_cohort(context, root / "cohort")
        by_center = {_audit_json(path, "application-center.json")[0].get("center"): path for path in sources}
        _require(set(by_center) == {row["center"] for row in cohort["centers"]},
                 "F5_APPLICATION_AUDIT_CENTER_COVERAGE_INVALID")
        models = load_application_models(lineage, input_root, result_root) if cohort["patient_count"] else []
        loaded, members, records = [], {}, []
        for row in cohort["centers"]:
            center, path = row["center"], by_center[row["center"]]
            loaded.append(_replay_application_center(path, context, cohort, models, root / f"center-{center}"))
            name = f"centers/center-{center}.zip"
            members[name] = path
            records.append({"center": center, "member": name, "sha256": sha256_file(path),
                            "size_bytes": path.stat().st_size})
        variants, variant_records = None, []
        if variant_sources is not None:
            from .f4 import evaluate_predictions
            from .f5_mice_variants import replay_variant_outer, variant_handoff, variant_result
            from .f5_sensitivity import _validate_a12_native_evaluation
            _require(len(variant_sources) == len({path.resolve() for path in variant_sources}) == 6,
                     "F5_A04_VARIANT_SIX_OUTERS_REQUIRED")
            by_outer = {_audit_json(path, "variant-outer.json")[0].get("outer_fold"): path for path in variant_sources}
            _require(set(by_outer) == set(range(1, 7)), "F5_A04_VARIANT_SIX_OUTERS_REQUIRED")
            outers = []
            for outer in range(1, 7):
                path, name = by_outer[outer], f"mice-variants/outer-{outer}.zip"
                outers.append(replay_variant_outer(path, context, root / f"variant-{outer}"))
                members[name] = path
                variant_records.append({"outer_fold": outer, "member": name, "sha256": sha256_file(path),
                                        "size_bytes": path.stat().st_size})
            predictions = variant_handoff(context, outers)
            native = root / "mice-variant-metrics.zip"
            response = context["_f4_inputs"]["o_fit_source"]["response_csv"]
            evaluation = evaluate_predictions(predictions, response, evidence_root=root / "metrics", native_archive=native)
            _validate_a12_native_evaluation(evaluation, predictions, response, native_archive=native, a04_variants=True)
            variants = variant_result(context, outers, evaluation)
            members["mice-variants/metrics.zip"] = native
        negative, negative_records = None, []
        if negative_sources is not None:
            from .f5_negative_controls import replay_negative_outer, evaluate_negative
            _require(len(negative_sources) == len({path.resolve() for path in negative_sources}) == 6,
                     "F5_A04_NEGATIVE_SIX_OUTERS_REQUIRED")
            by_outer = {_audit_json(path, "negative-outer.json")[0].get("outer_fold"): path for path in negative_sources}
            _require(set(by_outer) == set(range(1, 7)), "F5_A04_NEGATIVE_SIX_OUTERS_REQUIRED")
            outers = []
            for outer in range(1, 7):
                path, name = by_outer[outer], f"negative-controls/outer-{outer}.zip"
                outers.append(replay_negative_outer(path, context, root / f"negative-{outer}"))
                members[name] = path
                negative_records.append({"outer_fold": outer, "member": name, "sha256": sha256_file(path),
                                         "size_bytes": path.stat().st_size})
            negative, native_members = evaluate_negative(context, outers, root)
            members.update(native_members)
        result = {**_application_audit_result(context, cohort, loaded, diagnostics, variants, negative), "source_archives": records,
                  **({"variant_source_archives": variant_records} if variants is not None else {}),
                  **({"negative_source_archives": negative_records} if negative is not None else {})}
        write_deterministic_zip(target, {"a04.json": canonical_json_bytes(result), **members}, stored_members=set(members))
    except BaseException as exc:
        exc.add_note(f"F5_APPLICATION_AUDIT_AGGREGATE_EVIDENCE:{root}")
        raise
    shutil.rmtree(root)
    return {"status": result["status"], "stage_acceptance": False,
            "mice_chain_execution_count": result["mice_chain_execution_count"], "model_fit_count": 0,
            "sha256": sha256_file(target), "size_bytes": target.stat().st_size}


def replay_application_audit(source: Path, lineage: Mapping[str, Any], *, f2_run_root: Path,
                             input_root: Path, result_root: Path,
                             f1_runtime_root: Path | None = None,
                             replay_evidence: Path | None = None) -> tuple[dict[str, Any], dict[str, Any]]:
    from .bundle import _validated_zip_infos, _stream_zip_member
    from .f5_sensitivity import _a04_frozen_diagnostics

    stored, raw = _audit_json(source, "a04.json")
    context = application_context(f2_run_root, lineage, f1_runtime_root=f1_runtime_root)
    root = replay_evidence or Path(tempfile.mkdtemp(prefix="padml-application-audit-replay-")).resolve()
    if replay_evidence is not None:
        _new_target(root)
        root.mkdir(mode=0o700)
    try:
        diagnostics = _a04_frozen_diagnostics(f2_run_root, context["_f4_inputs"], lineage["final_family"])
        cohort = application_cohort(context, root / "cohort")
        models = load_application_models(lineage, input_root, result_root,
            **({"replay_evidence": root / "final-models"} if replay_evidence is not None else {})) if cohort["patient_count"] else []
        names = {f"centers/center-{row['center']}.zip" for row in cohort["centers"]}
        has_variants = "mice_variants" in stored
        has_negative = "negative_controls" in stored
        if has_variants:
            names |= {f"mice-variants/outer-{outer}.zip" for outer in range(1, 7)} | {"mice-variants/metrics.zip"}
        if has_negative:
            names |= {f"negative-controls/outer-{outer}.zip" for outer in range(1, 7)} | {
                f"negative-controls/metrics-P{index}.zip" for index in range(1, 4)}
        loaded, records, variant_records, variants = [], [], [], None
        negative, negative_records = None, []
        with open_carrier(source) as archive:
            infos = {info.filename: info for info in _validated_zip_infos(archive, names | {"a04.json"},
                max_member_bytes=205*1024**3,
                max_total_bytes=((1724 if has_variants else 1231) + (91 if has_negative else 0))*1024**3,
                max_compression_ratio=1000)}
            for row in cohort["centers"]:
                center = row["center"]
                name = f"centers/center-{center}.zip"
                path = root / f"center-{center}.zip"
                with path.open("xb") as handle:
                    digest, size = _stream_zip_member(archive, infos[name], handle)
                item = _replay_application_center(path, context, cohort, models, root / f"center-{center}",
                                                  retain_evidence=replay_evidence is not None)
                _require(item["center"] == center, "F5_APPLICATION_AUDIT_CENTER_COVERAGE_INVALID")
                loaded.append(item)
                records.append({"center": center, "member": name, "sha256": digest, "size_bytes": size})
                path.unlink()
            if has_variants:
                from .f4 import evaluate_predictions
                from .f5_mice_variants import replay_variant_outer, variant_handoff, variant_result
                from .f5_sensitivity import _validate_a12_native_evaluation
                outers = []
                for outer in range(1, 7):
                    name, path = f"mice-variants/outer-{outer}.zip", root / f"variant-{outer}.zip"
                    with path.open("xb") as handle:
                        digest, size = _stream_zip_member(archive, infos[name], handle)
                    item = replay_variant_outer(path, context, root / f"variant-{outer}",
                                                retain_evidence=replay_evidence is not None)
                    _require(item["outer_fold"] == outer, "F5_A04_VARIANT_SIX_OUTERS_REQUIRED")
                    outers.append(item)
                    variant_records.append({"outer_fold": outer, "member": name, "sha256": digest, "size_bytes": size})
                    path.unlink()
                native = root / "mice-variant-metrics.zip"
                with native.open("xb") as handle:
                    _stream_zip_member(archive, infos["mice-variants/metrics.zip"], handle)
                predictions = variant_handoff(context, outers)
                evaluation = evaluate_predictions(predictions, context["_f4_inputs"]["o_fit_source"]["response_csv"],
                                                  replay_native_archive=native)
                _require(evaluation == stored["mice_variants"]["evaluation"], "F5_A04_VARIANT_METRIC_REPLAY_MISMATCH")
                _validate_a12_native_evaluation(evaluation, predictions,
                    context["_f4_inputs"]["o_fit_source"]["response_csv"], native_archive=native, a04_variants=True)
                variants = variant_result(context, outers, evaluation)
            if has_negative:
                from .f5_negative_controls import replay_negative_outer, evaluate_negative
                outers, native_archives = [], {}
                for outer in range(1, 7):
                    name, path = f"negative-controls/outer-{outer}.zip", root / f"negative-{outer}.zip"
                    with path.open("xb") as handle:
                        digest, size = _stream_zip_member(archive, infos[name], handle)
                    item = replay_negative_outer(path, context, root / f"negative-{outer}",
                                                 retain_evidence=replay_evidence is not None)
                    _require(item["outer_fold"] == outer, "F5_A04_NEGATIVE_SIX_OUTERS_REQUIRED")
                    outers.append(item)
                    negative_records.append({"outer_fold": outer, "member": name, "sha256": digest, "size_bytes": size})
                    path.unlink()
                for index in range(1, 4):
                    native = root / f"negative-metrics-P{index}.zip"
                    with native.open("xb") as handle:
                        _stream_zip_member(archive, infos[f"negative-controls/metrics-P{index}.zip"], handle)
                    native_archives[index] = native
                negative, _ = evaluate_negative(context, outers, root, native_archives=native_archives)
        result = {**_application_audit_result(context, cohort, loaded, diagnostics, variants, negative), "source_archives": records,
                  **({"variant_source_archives": variant_records} if variants is not None else {}),
                  **({"negative_source_archives": negative_records} if negative is not None else {})}
        if replay_evidence is not None:
            (root / "replayed-result.json").write_bytes(canonical_json_bytes(result))
        _require(canonical_json_bytes(result) == raw, "F5_APPLICATION_AUDIT_AGGREGATE_REPLAY_MISMATCH")
    except BaseException as exc:
        exc.add_note(f"F5_APPLICATION_AUDIT_REPLAY_EVIDENCE:{root}")
        raise
    if replay_evidence is None:
        shutil.rmtree(root)
    return result, stored


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path)
    parser.add_argument("result", type=Path)
    args = parser.parse_args()
    print(json.dumps(execute_application_mice(args.input.absolute(), args.result.absolute()), sort_keys=True))


def _application_mice_key(value, entries):
    from . import nested_loco as n
    scientific_input = {k:v for k,v in value.items() if k != "final_lineage_sha256"}
    return n._sha({"input": scientific_input, "covariates": sha256_bytes(entries["covariates.csv"]),
                   "native_sources": _native_sources()})


@contextmanager
def _qualified_application_tables(source, shared, *, retained_only=False):
    """One immutable native carrier and one bounded expansion under its existing owner."""
    import fcntl
    from . import nested_loco as n
    from .integrated import qualified_file_pins
    value, entries = load_application_input(source)
    scientific_input = {k:v for k,v in value.items() if k != "final_lineage_sha256"}
    key = _application_mice_key(value, entries)
    folder = shared / key
    folder.mkdir(parents=True, exist_ok=True)
    with (folder / ".owner").open("a+") as owner:
        fcntl.flock(owner, fcntl.LOCK_EX)
        canonical = folder / "input.zip"
        if not canonical.is_file():
            n._write_exact_once(canonical, source.read_bytes(), "APPLICATION_SHARED_INPUT_DRIFT")
        prior, prior_entries = load_application_input(canonical)
        _require({k:v for k,v in prior.items() if k != "final_lineage_sha256"} == scientific_input
            and prior_entries["covariates.csv"] == entries["covariates.csv"], "APPLICATION_SHARED_INPUT_DRIFT")
        native = folder / "mice.zip"
        qualification = folder / "consumed.json"
        if qualification.is_file():
            proof = strict_json_bytes(qualification.read_bytes())
            _require(proof["mice_key"] == key and native.is_file(), "APPLICATION_SHARED_QUALIFICATION_DRIFT")
            qualified_file_pins({"mice": native}, identity=key, expected={"mice": proof["pin"]},
                record=folder / "file-qualification.json")
        performed = 0
        if not native.is_file():
            _require(not retained_only, 'APPLICATION_RETAINED_MICE_REQUIRED')
            produced = execute_application_mice(canonical, native, work_root=folder / "pending-chains")
            performed = produced["actual_new_mice_chains"]
        qualification = folder / "consumed.json"
        completed = folder / "completed"
        if qualification.is_file():
            proof = strict_json_bytes(qualification.read_bytes())
            _require(proof["mice_key"] == key, "APPLICATION_SHARED_QUALIFICATION_DRIFT")
            qualified_file_pins({"mice": native}, identity=key, expected={"mice": proof["pin"]},
                record=folder / "file-qualification.json")
            # The first consumer already checked the actual donor trace and RDS.
            # Reopen just the required tables; never replay completed chains.
            completed.mkdir(exist_ok=True)
            with open_carrier(native) as archive:
                for i in range(1,21):
                    name = f"imputations/imp{i:02d}.csv"
                    n._write_exact_once(completed / f"imp{i:02d}.csv", archive.read(name), "APPLICATION_TABLE_DRIFT")
            imputed = completed
        else:
            if completed.exists():
                shutil.rmtree(completed)
            consumed = materialize_application_mice(canonical, native, completed)
            pin = {"sha256": sha256_file(native), "size_bytes": native.stat().st_size}
            n._write_exact_once(qualification, canonical_json_bytes({"mice_key": key, "pin": pin}),
                "APPLICATION_SHARED_QUALIFICATION_DRIFT")
            imputed = Path(consumed["input_dir"])
        yield value, imputed, performed, canonical, native, key
        shutil.rmtree(completed)


def _engineering_application_transaction(job, *, models):
    """Stable patient-set transaction; historical result bytes remain readable."""
    from . import nested_loco as n
    from .carriers import file_reference, validate_reference
    source, target, shared = (Path(job[k]) for k in ("source", "target", "shared"))
    value, entries = load_application_input(source)
    parity = job["prepared_parity"]
    _model_pairing(models, value, parity)
    key = _application_mice_key(value, entries)
    prediction_identity = n._sha({"mice": key, "models": [m["source"] for m in models],
                                 "input": value, "prepared_parity": parity, "four_outputs": [6,12,24,36]})
    if target.is_file():
        result = strict_json_bytes(target.read_bytes())
        _require(result["input_identity"] == prediction_identity and n._sealed({k:v for k,v in result.items()
            if k != "identity_sha256"}) == result, "APPLICATION_RESUME_DRIFT")
        for ref in result["formal_references"]:
            validate_reference(ref)
        return result
    with _qualified_application_tables(source, shared,
            retained_only=job.get('retained_mice_only', False)) as (_, imputed, performed, canonical, native, key):
        evidence = target.with_name(target.stem + ".prediction-work")
        if evidence.exists():
            _require(evidence.is_dir() and not evidence.is_symlink() and not any(evidence.iterdir()),
                'APPLICATION_PREDICTION_FAILURE_EVIDENCE_RETAINED')
            evidence.rmdir()
        prediction = predict_completed_application(models, value, imputed, evidence, prepared_parity=parity)
        causal = {}
        if job.get('capture_imputation_fingerprints'):
            parents = models[0]['task']['selected_parents']
            by_id = {r['application_id']:r['patient_key_hash'] for r in value['application_rows']}
            fingerprints = {key:[] for key in by_id.values()}
            for imp in range(1,21):
                _, completed = _csv_rows((imputed/f'imp{imp:02d}.csv').read_bytes())
                for row in completed:
                    if row['Patient_ID'] in by_id:
                        fingerprints[by_id[row['Patient_ID']]].append(
                            {parent:n._sha(row[parent]) for parent in parents})
            _require(all(len(v) == 20 for v in fingerprints.values()),'APPLICATION_CAUSAL_M20_INCOMPLETE')
            causal = {'completed_patient_fingerprints':fingerprints}
        result = n._sealed({"kind": "PADML_APPLICATION_SELF_CHECK_TRANSACTION_V1",
            "input_identity": prediction_identity, "mice_key": key, "status": "COMPLETED",
            "actual_new_mice_chains": performed, "prediction": prediction,
            "formal_references": [file_reference(canonical, "APPLICATION_MICE_INPUT"),
                                  file_reference(native, "APPLICATION_MICE_NATIVE")], "new_model_fits": 0, **causal})
        n._write_exact_once(target, canonical_json_bytes(result), "APPLICATION_PREDICTION_DRIFT")
        shutil.rmtree(evidence)
        from .runtime import advise_completed_io
        advise_completed_io([source, target, canonical, native])
        return result


def _patient_application_transaction(job, *, models):
    """Batching changes prediction grouping, never a patient's MICE experiment.

    Every input is the same singleton donor/application transaction used by the
    single endpoint. The independent cold lanes have separate native stores;
    both endpoints still call the retained model, including after a cache hit
    for imputation. Only a sealed completion of this exact invocation resumes.
    """
    from . import nested_loco as n
    from .carriers import file_reference, validate_reference
    target, shared = Path(job['target']), Path(job['shared'])
    inputs = [Path(p) for p in job['sources']]
    _require(bool(inputs) and len(inputs) == len(set(inputs)), 'APPLICATION_PATIENT_INPUTS_INVALID')
    loaded = [load_application_input(p) for p in inputs]
    values = [v for v, _ in loaded]
    first = values[0]
    common = {k:v for k,v in first.items() if k not in {'application_rows','view'}}
    donors = first['view']['analysis_ids']
    for value in values:
        _require(len(value['application_rows']) == 1 and not value['validation']
            and {k:v for k,v in value.items() if k not in {'application_rows','view'}} == common
            and value['view']['analysis_ids'] == donors
            and {k:v for k,v in value['view'].items() if k not in {'row_ids','row_ids_sha256'}} ==
                {k:v for k,v in first['view'].items() if k not in {'row_ids','row_ids_sha256'}},
            'APPLICATION_PATIENT_TRANSACTION_BINDING_DRIFT')
        _model_pairing(models, value, bool(job.get('prepared_parity')))
    application = [v['application_rows'][0] for v in values]
    ids = [r['application_id'] for r in application]
    _require(len(ids) == len(set(ids)), 'APPLICATION_PATIENT_INPUTS_INVALID')
    row_ids = donors + ids
    value = {**first, 'application_rows':application, 'view':{**first['view'],
        'row_ids':row_ids, 'row_ids_sha256':n._sha(row_ids)}}
    keys = [_application_mice_key(v,e) for v,e in loaded]
    identity = n._sha({'method':'PATIENT_TRANSACTION_APPLICATION_V1',
        'input':value, 'mice_keys':keys, 'models':[m['source'] for m in models],
        'prepared_parity':bool(job.get('prepared_parity')), 'cold_lane':job.get('cold_lane')})
    if target.is_file():
        saved = strict_json_bytes(target.read_bytes())
        _require(saved['input_identity'] == identity and saved['identity_sha256'] ==
            n._sha({k:v for k,v in saved.items() if k != 'identity_sha256'}),
            'APPLICATION_PATIENT_RESULT_DRIFT')
        for ref in saved['formal_references']: validate_reference(ref)
        return saved
    completed_rows = {i:[] for i in range(1,21)}
    references, patients = [], []
    for source, expected, key in zip(inputs, values, keys):
        with _qualified_application_tables(source, shared,
                retained_only=job.get('retained_mice_only', False)) as (actual, tables, performed, canonical, native, found):
            _require(actual == expected and found == key, 'APPLICATION_PATIENT_TRANSACTION_BINDING_DRIFT')
            selected = []
            for imp in range(1,21):
                _, rows = _csv_rows((tables/f'imp{imp:02d}.csv').read_bytes())
                _require([r['Patient_ID'] for r in rows] == actual['view']['row_ids']
                    and rows[-1]['Patient_ID'] == actual['application_rows'][0]['application_id'],
                    'APPLICATION_PATIENT_COMPLETED_ALIGNMENT_INVALID')
                completed_rows[imp].append(rows[-1])
                selected.append(rows[-1])
            patients.append({'patient_key_hash':actual['application_rows'][0]['patient_key_hash'],
                'mice_key':key, 'completed_patient_m20_sha256':n._sha(selected),
                'actual_new_mice_chains':performed})
            references.extend((file_reference(canonical,'APPLICATION_MICE_INPUT'),
                               file_reference(native,'APPLICATION_MICE_NATIVE')))
    evidence = target.with_name(target.stem+'.prediction-work')
    if evidence.exists():
        _require(evidence.is_dir() and not evidence.is_symlink() and not any(evidence.iterdir()),
            'APPLICATION_PREDICTION_FAILURE_EVIDENCE_RETAINED')
        evidence.rmdir()
    # This call is unconditional for an unfinished invocation. Imputation reuse
    # must never be mistaken for proof that two prediction calls agree.
    prediction = predict_completed_application(models,value,None,evidence,
        prepared_parity=bool(job.get('prepared_parity')),completed_rows=completed_rows)
    # The native calls above validate all monthly M20 values. Application
    # consumers use the four pooled risks; keep their numerical provenance,
    # not another copy of the monthly batch and single matrices.
    prediction = {**{k:v for k,v in prediction.items() if k not in {'components','mean_survival'}},
        'm20_prediction_sha256':n._sha(prediction['components']),
        'fixed_completed_data_parity':('PASS' if job.get('prepared_parity') else 'SEPARATE_SINGLE_CALL')}
    result = n._sealed({'kind':'PADML_PATIENT_APPLICATION_TRANSACTION_V1',
        'input_identity':identity, 'status':'COMPLETED', 'prediction':prediction,
        'patients':patients, 'formal_references':references, 'cold_lane':job.get('cold_lane'),
        'actual_new_mice_chains':sum(p['actual_new_mice_chains'] for p in patients),
        'new_model_fits':0, 'prediction_result_cache_used':False})
    n._write_exact_once(target,canonical_json_bytes(result),'APPLICATION_PATIENT_RESULT_DRIFT')
    shutil.rmtree(evidence)
    return result


def validate_application_self_check(result, run, root):
    """Completed application consumer: pins only, no model loads or MICE calls."""
    from . import nested_loco as n
    from .carriers import validate_reference
    from .integrated import same_batch_generations
    _require(result["kind"] == "PADML_FULL0_APPLICATION_SELF_CHECK_V1" and result["status"] == "COMPLETED"
        and result["source"]["run_identity"] in same_batch_generations(run)
        and result["source"]["unit_id"] == root.name
        and n._sealed({k:v for k,v in result.items() if k != "identity_sha256"}) == result,
        "APPLICATION_SELF_CHECK_RESULT_DRIFT")
    for ref in result["formal_references"]:
        validate_reference(ref, run)
    for item in result["transactions"]:
        from .bundle import validate_relative_path
        name = validate_relative_path(item["path"], "application.transaction")
        _require(name.startswith("application/"), "APPLICATION_TRANSACTION_PATH_INVALID")
        saved = strict_json_bytes((root / name).read_bytes())
        _require(saved["identity_sha256"] == item["identity_sha256"] and n._sealed({k:v for k,v in saved.items()
            if k != "identity_sha256"}) == saved, "APPLICATION_TRANSACTION_DRIFT")
        for ref in saved["formal_references"]:
            validate_reference(ref, run)
    return result


def run_application_self_check(run, unit, root, lineage, compiled, sources):
    from . import nested_loco as n
    from .carriers import file_reference, resolve_reference
    from .runtime import admit_stage
    from .f5_sensitivity import evaluate_a04_batch_single
    from .integrated import same_batch_generations
    folder = root / "application"
    folder.mkdir(parents=True, exist_ok=True)
    binding = {"run_identity": run["identity"], "unit_id": unit["unit_id"],
        "lineage_sha256": n._sha(lineage), "scope": "ENGINEERING_BATCH_SINGLE_SELF_CHECK_MAX2_PER_CENTER"}
    if (folder / "input.json").is_file():
        previous = strict_json_bytes((folder / "input.json").read_bytes())
        _require(previous == {**binding, "run_identity": previous.get("run_identity")}
            and previous["run_identity"] in same_batch_generations(run), "APPLICATION_SELF_CHECK_SOURCE_DRIFT")
        binding = previous
    n._write_exact_once(folder / "input.json", canonical_json_bytes(binding), "APPLICATION_SELF_CHECK_SOURCE_DRIFT")
    result_path = root / "application.json"
    if result_path.is_file():
        result = strict_json_bytes(result_path.read_bytes())
        _require(result["source"] == binding and n._sealed({k:v for k,v in result.items()
            if k != "identity_sha256"}) == result, "APPLICATION_SELF_CHECK_RESULT_DRIFT")
        validate_application_self_check(result, run, root)
        return result
    context = application_context(None, lineage, raw_binding_root=Path(sources["raw_binding_root"]),
        input_root=root / "final-input", compiled_input_record=compiled)
    if (folder / "cohort/cohort.json").is_file():
        cohort = strict_json_bytes((folder / "cohort/cohort.json").read_bytes())
        _require(cohort["source"] == context["source"] and all(len(c["selected_ids"]) <= 2 for c in cohort["centers"]),
                 "APPLICATION_SELF_CHECK_COHORT_DRIFT")
    else:
        if (folder / "cohort").exists():
            shutil.rmtree(folder / "cohort")
        cohort = application_cohort(context, folder / "cohort", max_per_center=2)
    jobs = []
    for center in cohort["centers"]:
        for job in _audit_jobs(cohort, center["center"]):
            name = center["center"] + "-" + job["name"]
            source, target = folder / (name + ".input.zip"), folder / (name + ".json")
            members = application_input_members(context, job["patients"])
            if source.is_file():
                _require(read_safe_zip(source) == members, "APPLICATION_SELF_CHECK_INPUT_DRIFT")
            else:
                write_deterministic_zip(source, members)
            jobs.append({**job, "center": center["center"], "source": str(source), "target": str(target),
                         "shared": str(Path(run["run_root"]) / "shared/application-mice")})
    rows = []
    if jobs:
        model_bytes = sum(p.stat().st_size for p in (root / "final-result").glob("*.zip"))
        raw_bytes = len(_csv_bytes(context["columns"], list(context["raw_rows"].values())))
        # Retained native chains/tables, one publication, and per-worker live bytes.
        admission = admit_stage(run["resource_policy"], folder, legal_tasks=len(jobs),
            retained_bytes=len(jobs)*raw_bytes*80, publication_bytes=raw_bytes*80,
            transient_bytes_per_worker=max(run["resource_policy"]["scratch_bytes_per_worker"], raw_bytes*160),
            memory_bytes_per_worker=max(MIN_WORKER_MEMORY_BYTES, model_bytes*3 + raw_bytes*160))
        models = load_application_models(lineage, root / "final-input", root / "final-result", workers=None,
            resource_policy=run["resource_policy"], compiled_input_record=compiled, retain_objects=True)
        rows = _bounded_ordered_spawn(partial(_engineering_application_transaction, models=models), jobs,
            selected_slots=admission["admitted_worker_ceiling"])
    comparisons = []
    for center in cohort["centers"]:
        selected = [(job,row) for job,row in zip(jobs, rows) if job["center"] == center["center"]]
        for h in (6,12,24,36):
            def project(row):
                return [{k:v for k,v in p.items() if k in {"patient_key_hash", "center", f"risk_probability_{h}"}}
                    for p in row["prediction"]["risks"]]
            batch = [p for job,row in selected if job["name"] == "batch" for p in project(row)]
            singles = [p for job,row in selected if job["name"] != "batch" for p in project(row)]
            numeric = evaluate_a04_batch_single(batch, singles, horizon=h) if batch else None
            comparisons.append({"center": center["center"], "report_month": h, "patient_count": len(batch),
                "status": "COMPUTED" if batch else "NO_APPLICABLE_MISSING_PATIENTS", "comparison": numeric})
    result = n._sealed({"kind": "PADML_FULL0_APPLICATION_SELF_CHECK_V1", "source": binding,
        "status": "COMPLETED", "full_A04_audit": False, "deployment_conclusion": None,
        "new_model_fits": 0, "actual_new_mice_chains": sum(r["actual_new_mice_chains"] for r in rows),
        "patient_count": cohort["patient_count"], "maximum_patients_per_center": 2,
        "formal_references": [file_reference(folder / "cohort/cohort.json", "APPLICATION_COHORT", run)],
        "comparisons": comparisons, "transactions": [{"path": Path(j["target"]).relative_to(root).as_posix(),
            "identity_sha256": r["identity_sha256"]} for j,r in zip(jobs,rows)]})
    n._write_exact_once(result_path, canonical_json_bytes(result), "APPLICATION_SELF_CHECK_RESULT_DRIFT")
    return result


def application_repair_decision():
    from .nested_loco import _sealed
    return _sealed({'kind':'PADML_APPLICATION_CAUSAL_REPAIR_20261008_V1',
        'registration':'POST_RESULT_ENGINEERING_REPAIR', 'original_coordinates':96,
        'original_failures':10, 'original_successes':86, 'original_patients':'UNCHANGED',
        'method':'SAME_PATIENT_MICE_TRANSACTION_FOR_BATCH_AND_SINGLE',
        'native_mice_rule_change':False, 'p95_max':.02, 'top_risk_agreement_min':.90,
        'cold_lanes':['A','B'], 'cold_chains_per_unique_patient_max':40,
        'cold_patients_max':48, 'prediction_cache_in_cold_comparison':False,
        'complete_a04_is_not_original_failure_acceptance':True, 'new_prediction_model_fits':0})


def _application_regression_job(job, *, models):
    return (_engineering_application_transaction(job,models=models) if job.get('original_replay')
            else _patient_application_transaction(job,models=models))


def run_application_regression(run, unit, root, lineage, compiled, sources):
    """Regress the original patients and all 24 coordinates in this FULL0 line.

    Cold A/B have separate native carriers and identical registered seeds.
    Their result identities cannot be satisfied by warm prediction records.
    Historical inputs and failed comparisons remain immutable.
    """
    from . import nested_loco as n
    from .carriers import file_reference, validate_reference
    from .runtime import admit_stage, run_ready_families
    from .f5_sensitivity import evaluate_a04_batch_single
    decision = application_repair_decision()
    _require(unit['kind'] == 'FULL0', 'APPLICATION_REPAIR_SCOPE_INVALID')
    original_path = root/'application.json'
    original = validate_application_self_check(strict_json_bytes(original_path.read_bytes()),run,root)
    context = application_context(None,lineage,raw_binding_root=Path(sources['raw_binding_root']),
        input_root=root/'final-input',compiled_input_record=compiled)
    cohort_path = root/'application/cohort/cohort.json'
    cohort = strict_json_bytes(cohort_path.read_bytes())
    _require(cohort['source'] == context['source'] and len(cohort['centers']) == 6
        and all(0 < len(c['selected_ids']) <= 2 for c in cohort['centers'])
        and len(original['comparisons']) == 24, 'APPLICATION_ORIGINAL_COHORT_DRIFT')
    folder = root/'application-repair'/decision['identity_sha256']
    folder.mkdir(parents=True,exist_ok=True)
    target = folder/'result.json'
    binding = {'decision':decision,'original_result_identity':original['identity_sha256'],
        'unit_id':unit['unit_id'],'lineage_sha256':n._sha(lineage)}
    if target.is_file():
        result = strict_json_bytes(target.read_bytes())
        from .f4 import _evaluation_check_producer, _evaluation_provenance
        _evaluation_check_producer(result, _evaluation_provenance(run)['generations'])
        _require(result['binding'] == binding and result == n._sealed({k:v for k,v in result.items()
            if k != 'identity_sha256'}), 'APPLICATION_REPAIR_RESULT_DRIFT')
        from .carriers import read_reference
        for ref in result['formal_references']:
            validate_reference(ref,run)
            if ref['role'] == 'PATIENT_APPLICATION_REGRESSION':
                transaction = strict_json_bytes(read_reference(ref,run))
                _require(transaction == n._sealed({k:v for k,v in transaction.items()
                    if k != 'identity_sha256'}) and transaction['status'] == 'COMPLETED'
                    and transaction['new_model_fits'] == 0, 'APPLICATION_REPAIR_TRANSACTION_DRIFT')
                for source in transaction['formal_references']: validate_reference(source,run)
        return result
    native = Path(run['run_root'])/'shared/application-mice'
    cold = Path(run['run_root'])/'shared/application-cold'/decision['identity_sha256']
    jobs, center_inputs, original_rows = [], {}, {}
    for center in cohort['centers']:
        center_id = center['center']
        center_inputs[center_id] = []
        for task in _audit_jobs(cohort,center_id):
            name = center_id+'-'+task['name']
            path = root/'application'/(name+'.input.zip')
            _require(read_safe_zip(path) == application_input_members(context,task['patients']),
                'APPLICATION_ORIGINAL_INPUT_DRIFT')
            previous = strict_json_bytes((root/'application'/(name+'.json')).read_bytes())
            original_rows[name] = previous
            if task['name'] != 'batch': center_inputs[center_id].append(str(path))
            if any(r['center'] == center_id and r['comparison']['deployment_gate']['status'] == 'FAIL'
                   for r in original['comparisons']):
                jobs.append({'name':'original-'+name,'center':center_id,'lane':'original','mode':task['name'],
                    'source':str(path),'target':str(folder/('original-'+name+'.json')),'shared':str(native),
                    'prepared_parity':task['prepared_parity'],'original_replay':True,
                    'retained_mice_only':True,'capture_imputation_fingerprints':True})
        selected = center_inputs[center_id]
        for lane in ('warm','A','B'):
            shared = native if lane == 'warm' else cold/lane
            groups = [('batch',selected)] if lane == 'A' else (
                [(f'single-{i:03d}',[p]) for i,p in enumerate(selected,1)] if lane == 'B' else
                [('batch',selected),*[(f'single-{i:03d}',[p]) for i,p in enumerate(selected,1)]])
            for name, inputs in groups:
                label = f'{lane}-{center_id}-{name}'
                jobs.append({'name':label,'center':center_id,'lane':lane,'mode':name,
                    'sources':inputs,'target':str(folder/(label+'.json')),'shared':str(shared),
                    'prepared_parity':name == 'batch','cold_lane':None if lane == 'warm' else lane,
                    'retained_mice_only':lane == 'warm'})
    all_inputs = [p for paths in center_inputs.values() for p in paths]
    _require(len(all_inputs) <= decision['cold_patients_max'], 'APPLICATION_COLD_BUDGET_EXCEEDED')
    # A heterogeneous batch, reversed batch and an odd split exercise grouping
    # using the same singleton MICE results, without extra chains.
    for label, inputs in [('mixed',all_inputs),('reversed',all_inputs[::-1]),
                          ('odd-split',all_inputs[::2]),('even-split',all_inputs[1::2])]:
        jobs.append({'name':label,'center':None,'lane':'warm','mode':'grouping','sources':inputs,
            'target':str(folder/(label+'.json')),'shared':str(native),'prepared_parity':True,'cold_lane':None,
            'retained_mice_only':True})
    raw_bytes = max(len(load_application_input(Path(p))[1]['covariates.csv']) for p in all_inputs)
    model_bytes = sum(p.stat().st_size for p in (root/'final-result').glob('*.zip'))
    models = load_application_models(lineage,root/'final-input',root/'final-result',workers=None,
        resource_policy=run['resource_policy'],compiled_input_record=compiled,retain_objects=True)
    def batch():
        admission = admit_stage(run['resource_policy'],folder,legal_tasks=len(jobs),
            retained_bytes=len(all_inputs)*raw_bytes*160,publication_bytes=raw_bytes*80,
            transient_bytes_per_worker=max(run['resource_policy']['scratch_bytes_per_worker'],raw_bytes*80),
            memory_bytes_per_worker=max(MIN_WORKER_MEMORY_BYTES,model_bytes*3+raw_bytes*160))
        return _bounded_ordered_spawn(partial(_application_regression_job,models=models),jobs,
            selected_slots=admission['admitted_worker_ceiling'])
    rows = run_ready_families([batch],policy=run['resource_policy'],root=folder)[0]
    by_name = {j['name']:row for j,row in zip(jobs,rows)}
    patient_m20 = {}
    for job, row in zip(jobs,rows):
        if job.get('original_replay'): continue
        _require(row['prediction_result_cache_used'] is False and row['new_model_fits'] == 0,
            'APPLICATION_REGRESSION_NOT_REAL_PREDICTION')
        for patient in row['patients']:
            key = patient['patient_key_hash']
            fingerprint = (patient['mice_key'],patient['completed_patient_m20_sha256'])
            _require(key not in patient_m20 or patient_m20[key] == fingerprint,
                'APPLICATION_REGRESSION_M20_DRIFT')
            patient_m20[key] = fingerprint
    _require(sum(r['actual_new_mice_chains'] for r in rows) <= len(patient_m20)*40,
        'APPLICATION_COLD_BUDGET_EXCEEDED')
    causal = {}
    for cid, paths in center_inputs.items():
        if 'original-'+cid+'-batch' not in by_name: continue
        origin = by_name['original-'+cid+'-batch']
        _require(origin['prediction'] == original_rows[cid+'-batch']['prediction']
            and origin['actual_new_mice_chains'] == 0,'APPLICATION_ORIGINAL_REPLAY_MISMATCH')
        batch_value,batch_entries = load_application_input(root/'application'/(cid+'-batch.input.zip'))
        batch_raw = _csv_rows(batch_entries['covariates.csv'])[1]
        differences = {}
        for i,path in enumerate(paths,1):
            name = f'{cid}-single-{i:03d}'
            single = by_name['original-'+name]
            _require(single['prediction'] == original_rows[name]['prediction']
                and single['actual_new_mice_chains'] == 0,'APPLICATION_ORIGINAL_REPLAY_MISMATCH')
            value,entries = load_application_input(Path(path))
            _require({k:v for k,v in value.items() if k not in {'view','application_rows'}} ==
                     {k:v for k,v in batch_value.items() if k not in {'view','application_rows'}}
                and value['view']['analysis_ids'] == batch_value['view']['analysis_ids'],
                'APPLICATION_ORIGINAL_BINDING_DIFFERENCE_UNRESOLVED')
            raw = _csv_rows(entries['covariates.csv'])[1]
            n_donors = len(value['view']['analysis_ids'])
            _require(raw[:n_donors] == batch_raw[:n_donors] and raw[-1] in batch_raw[n_donors:],
                'APPLICATION_ORIGINAL_BINDING_DIFFERENCE_UNRESOLVED')
            key = value['application_rows'][0]['patient_key_hash']
            a,b = origin['completed_patient_fingerprints'][key],single['completed_patient_fingerprints'][key]
            differences[key] = {p:sum(x[p] != y[p] for x,y in zip(a,b)) for p in a[0]}
        _require(any(n for d in differences.values() for n in d.values()),'APPLICATION_CAUSE_UNRESOLVED')
        causal[cid] = {'cause':'APPLICATION_MICE_DEPENDS_ON_APPENDED_PATIENT_MEMBERSHIP',
            'same_raw_donors_recipe_seeds_and_native_kernel':True,
            'original_prediction_replayed':True,'new_model_fits':0,'new_mice_chains':0,
            'changed_imputation_counts_by_patient_variable':differences,
            'fixed_completed_data_batch_single_exact':all(c['survival'] == c['prepared_single_survival']
                for c in origin['prediction']['components'])}
        _require(causal[cid]['fixed_completed_data_batch_single_exact'],'APPLICATION_PREDICTION_CAUSE_UNRESOLVED')
    def project(records,h):
        return [{k:v for k,v in patient.items() if k in {'patient_key_hash','center',f'risk_probability_{h}'}}
            for record in records for patient in record['prediction']['risks']]
    comparisons = []
    for center in cohort['centers']:
        cid = center['center']; count = len(center_inputs[cid])
        for h in (6,12,24,36):
            old, = [r for r in original['comparisons'] if r['center'] == cid and r['report_month'] == h]
            reproduced = evaluate_a04_batch_single(project([original_rows[cid+'-batch']],h),
                project([original_rows[f'{cid}-single-{i:03d}'] for i in range(1,count+1)],h),horizon=h)
            _require(reproduced == old['comparison'],'APPLICATION_ORIGINAL_COMPARISON_DRIFT')
            warm = evaluate_a04_batch_single(project([by_name[f'warm-{cid}-batch']],h),
                project([by_name[f'warm-{cid}-single-{i:03d}'] for i in range(1,count+1)],h),horizon=h)
            fresh = evaluate_a04_batch_single(project([by_name[f'A-{cid}-batch']],h),
                project([by_name[f'B-{cid}-single-{i:03d}'] for i in range(1,count+1)],h),horizon=h)
            keys = sorted(context['patient_keys'][p] for p in center['selected_ids'])
            comparisons.append({'center':cid,'report_month':h,'patient_key_hashes':keys,
                'original_status':reproduced['deployment_gate']['status'],
                'original':reproduced['summary'],'warm':warm['summary'],'cold':fresh['summary'],
                'cause':causal.get(cid) if reproduced['deployment_gate']['status'] == 'FAIL' else None,
                'status':'PASS' if warm['deployment_gate']['status'] == fresh['deployment_gate']['status'] == 'PASS'
                    else 'FAIL'})
    single_risks = {p['patient_key_hash']:p for j,r in zip(jobs,rows)
        if j['lane'] == 'warm' and j['mode'].startswith('single-') for p in r['prediction']['risks']}
    grouping = {label:all(single_risks[p['patient_key_hash']] == p
        for p in by_name[label]['prediction']['risks']) for label in ('mixed','reversed','odd-split','even-split')}
    passed = all(r['status'] == 'PASS' for r in comparisons) and all(grouping.values())
    result = n._sealed({'kind':'PADML_APPLICATION_ORIGINAL_PATIENT_REGRESSION_V1','binding':binding,
        'producer':{'run_identity':run['identity'],'source_identity':run['source_identity']},
        'status':'COMPLETED','regression_status':'PASS' if passed else 'FAIL',
        'original_failure_closure':'CLOSED' if passed else 'OPEN',
        'application_admission':'BLOCKED_PENDING_FULL_A04' if passed else 'BLOCKED_ORIGINAL_REGRESSION',
        'original_failure_count':sum(r['original_status']=='FAIL' for r in comparisons),
        'coordinate_count':len(comparisons),'comparisons':comparisons,'grouping':grouping,
        'new_model_fits':0,'new_mice_chains':sum(r['actual_new_mice_chains'] for r in rows),
        'cold_chain_slot_upper_bound':len(all_inputs)*40,'full_a04_completed':False,
        'independent_cold_m20_matches_warm':True,
        'formal_references':[file_reference(original_path,'ORIGINAL_APPLICATION_RECORD',run),
            file_reference(cohort_path,'ORIGINAL_APPLICATION_COHORT',run),
            *[file_reference(Path(j['target']),'PATIENT_APPLICATION_REGRESSION',run) for j in jobs]]})
    n._write_exact_once(target,canonical_json_bytes(result),'APPLICATION_REPAIR_RESULT_DRIFT')
    return result


def application_regression_observation(run):
    """Four fixed small heads; observation never grants a new native qualification."""
    from . import nested_loco as n
    from .integrated import same_batch_generations
    decision = application_repair_decision()
    records = []
    for h in (6,12,24,36):
        uid = f'FULL0-H{h:02d}'
        path = Path(run['run_root'])/'units'/uid/'application-repair'/decision['identity_sha256']/'result.json'
        if not path.is_file(): return False
        _require(not path.is_symlink() and path.stat().st_size <= 8*1024**2,
            'APPLICATION_REGRESSION_HEADER_INVALID')
        result = strict_json_bytes(path.read_bytes())
        _require(result == n._sealed({k:v for k,v in result.items() if k != 'identity_sha256'})
            and result['binding']['unit_id'] == uid and result['binding']['decision'] == decision
            and same_batch_generations(run).get(result['producer']['run_identity']) == result['producer']['source_identity']
            and result['status'] == 'COMPLETED' and result['coordinate_count'] == len(result['comparisons']) == 24,
            'APPLICATION_REGRESSION_HEADER_DRIFT')
        if (result['regression_status'] != 'PASS' or result['original_failure_closure'] != 'CLOSED'
            or not result['independent_cold_m20_matches_warm'] or not all(result['grouping'].values())
            or not all(r['status'] == 'PASS' and (r['original_status'] != 'FAIL' or bool(r['cause']))
                       for r in result['comparisons'])):
            return False
        records.append(result)
    _require(sum(r['original_failure_count'] for r in records) == 10,
        'APPLICATION_ORIGINAL_FAILURE_DENOMINATOR_DRIFT')
    return True


def _application_expand_qualified_cohort(original, context):
    """Use the original complete membership audit, changing only the fixed cap."""
    import copy
    _require(original['source'] == context['source']
        and {r['source_id'] for r in original['candidates']} == set(context['donor_ids']),
        'APPLICATION_A04_ORIGINAL_COHORT_DRIFT')
    value = copy.deepcopy(original)
    by_id = {r['source_id']:r for r in value['candidates']}
    _require(len(by_id) == len(context['donor_ids']), 'APPLICATION_A04_COHORT_DUPLICATE')
    for center in value['centers']:
        candidates = [r for r in value['candidates'] if r['center'] == center['center']]
        eligible = [r for r in candidates if r['missing_sources']]
        for row in eligible:
            key = context['patient_keys'][row['source_id']]
            expected = sha256_bytes(canonical_json_bytes({'algorithm_id':'A04_APPLICATION_MEMBERSHIP_ORDER_V1',
                'patient_key_hash':key,'sampling_seed':center['sampling_seed']}).rstrip(b'\n'))
            _require(row['patient_key_hash'] == key and row['rank_digest'] == expected,
                'APPLICATION_A04_MEMBERSHIP_ORDER_DRIFT')
        ordered = sorted(eligible,key=lambda r:(r['rank_digest'],r['patient_key_hash']))
        _require(center['eligible_count'] == len(ordered)
            and center['selected_ids'] == [r['source_id'] for r in ordered[:2]],
            'APPLICATION_A04_ORIGINAL_COHORT_DRIFT')
        chosen = ordered[:50]
        center['selected_ids'] = [r['source_id'] for r in chosen]
        center['selected_patient_key_hashes'] = [r['patient_key_hash'] for r in chosen]
        center['status'] = 'LOCKED' if chosen else 'NO_APPLICABLE_MISSING_ROWS_IN_FROZEN_SAMPLE'
        for row in candidates:
            row['included'] = row['source_id'] in center['selected_ids']
            row['reason'] = ('SELECTED' if row['included'] else 'OUTSIDE_FIRST_50_CANONICAL_ORDER'
                if row['missing_sources'] else 'REQUIRED_RAW_SOURCES_OBSERVED')
    value['patient_count'] = sum(len(c['selected_ids']) for c in value['centers'])
    return value


def run_full_application_cohort(run, unit, root, lineage, compiled, sources, *, original_regressions):
    """The original <=50-per-center application branch, after all original96 pass.

    Its inputs remain outcome-free. Diagnostic model fitting belongs to the
    independent PRIMARY A04 tails, not to this application patient branch.
    """
    from . import nested_loco as n
    from .carriers import file_reference, validate_reference, read_reference
    from .runtime import admit_stage, run_ready_families
    from .f5_sensitivity import evaluate_a04_batch_single
    _require(unit['kind'] == 'FULL0' and len(original_regressions) == 4
        and {r['binding']['unit_id'] for r in original_regressions} ==
            {f'FULL0-H{h:02d}' for h in (6,12,24,36)}
        and all(r['regression_status'] == 'PASS' and r['original_failure_closure'] == 'CLOSED'
            and r['coordinate_count'] == 24 for r in original_regressions)
        and sum(r['original_failure_count'] for r in original_regressions) == 10,
        'APPLICATION_ORIGINAL96_REGRESSION_REQUIRED')
    context = application_context(None,lineage,raw_binding_root=Path(sources['raw_binding_root']),
        input_root=root/'final-input',compiled_input_record=compiled)
    decision = application_repair_decision()
    folder = root/'application-repair'/decision['identity_sha256']/'full-a04'
    folder.mkdir(parents=True,exist_ok=True)
    target = folder/'result.json'
    binding = {'decision_sha256':decision['identity_sha256'],'source':context['source'],
        'unit_id':unit['unit_id'],'maximum_patients_per_center':50,
        'original_regressions':[r['identity_sha256'] for r in original_regressions]}
    def retire_construction_inputs():
        inputs = folder/'inputs'
        if not inputs.exists(): return
        expected = {context['patient_keys'][p]+'.zip':p
            for c in strict_json_bytes((folder/'cohort/cohort.json').read_bytes())['centers']
            for p in c['selected_ids']}
        _require(not inputs.is_symlink(), 'APPLICATION_A04_INPUT_PATH_INVALID')
        for path in inputs.iterdir():
            _require(path.name in expected and path.is_file() and not path.is_symlink(),
                'APPLICATION_A04_UNEXPECTED_CONSTRUCTION_INPUT')
            _require(read_safe_zip(path) == application_input_members(context,[expected[path.name]]),
                'APPLICATION_A04_CONSTRUCTION_INPUT_DRIFT')
            path.unlink()
        inputs.rmdir()
    if target.is_file():
        result = strict_json_bytes(target.read_bytes())
        _require(result['binding'] == binding and result == n._sealed({k:v for k,v in result.items()
            if k != 'identity_sha256'}), 'APPLICATION_A04_PATIENT_RESULT_DRIFT')
        for ref in result['formal_references']:
            validate_reference(ref,run)
            if ref['role'] == 'A04_PATIENT_TRANSACTION':
                transaction = strict_json_bytes(read_reference(ref,run))
                _require(transaction == n._sealed({k:v for k,v in transaction.items()
                    if k != 'identity_sha256'}) and transaction['status'] == 'COMPLETED'
                    and transaction['new_model_fits'] == 0, 'APPLICATION_A04_PATIENT_TRANSACTION_DRIFT')
                for source in transaction['formal_references']: validate_reference(source,run)
        retire_construction_inputs()
        return result
    cohort_path = folder/'cohort/cohort.json'
    _require(not cohort_path.parent.is_symlink(), 'APPLICATION_A04_COHORT_PATH_INVALID')
    cohort_path.parent.mkdir(exist_ok=True)
    cohort = _application_expand_qualified_cohort(
        strict_json_bytes((root/'application/cohort/cohort.json').read_bytes()),context)
    n._write_exact_once(cohort_path,canonical_json_bytes(cohort),'APPLICATION_A04_COHORT_DRIFT')
    shared = Path(run['run_root'])/'shared/application-mice'
    inputs = folder/'inputs'; inputs.mkdir(exist_ok=True)
    selected_ids = [patient for center in cohort['centers'] for patient in center['selected_ids']]
    first_members = application_input_members(context,[selected_ids[0]]) if selected_ids else None
    if first_members is not None:
        # All singleton inputs share the donor rows and protocol; only one
        # appended raw row differs. Account for construction before ZIP writes.
        largest_row = max(len(_csv_bytes(context['columns'],[context['raw_rows'][p]])) for p in selected_ids)
        input_upper = sum(map(len,first_members.values()))+largest_row+64*1024
        missing_inputs = sum(not (inputs/(context['patient_keys'][p]+'.zip')).exists() for p in selected_ids)
        admit_stage(run['resource_policy'],folder,legal_tasks=1,
            retained_bytes=missing_inputs*input_upper,publication_bytes=input_upper,
            transient_bytes_per_worker=2*input_upper,
            memory_bytes_per_worker=max(MIN_WORKER_MEMORY_BYTES,4*input_upper))
    jobs, input_paths = [], []
    for center in cohort['centers']:
        paths = []
        for patient in center['selected_ids']:
            key = context['patient_keys'][patient]
            source = inputs/(key+'.zip')
            members = first_members if patient == selected_ids[0] else application_input_members(context,[patient])
            if source.is_file():
                _require(read_safe_zip(source) == members,'APPLICATION_A04_PATIENT_INPUT_DRIFT')
            else:
                write_deterministic_zip(source,members)
            paths.append(str(source)); input_paths.append(source)
        if not paths: continue
        # Both calls predict independently. Their singleton imputation native
        # objects are shared under the existing per-input lock.
        for name, group in [('batch',paths), *[(f'single-{i:03d}',[p]) for i,p in enumerate(paths,1)]]:
            label = center['center']+'-'+name
            jobs.append({'name':label,'center':center['center'],'mode':name,'sources':group,
                'target':str(folder/(label+'.json')),'shared':str(shared),
                'prepared_parity':name == 'batch','cold_lane':None})
    rows = []
    if jobs:
        model_bytes = sum(p.stat().st_size for p in (root/'final-result').glob('*.zip'))
        raw_bytes = max(len(load_application_input(p)[1]['covariates.csv']) for p in input_paths)
        models = load_application_models(lineage,root/'final-input',root/'final-result',workers=None,
            resource_policy=run['resource_policy'],compiled_input_record=compiled,retain_objects=True)
        def batch():
            admission = admit_stage(run['resource_policy'],folder,legal_tasks=len(jobs),
                retained_bytes=len(input_paths)*raw_bytes*80,publication_bytes=raw_bytes*80,
                transient_bytes_per_worker=max(run['resource_policy']['scratch_bytes_per_worker'],raw_bytes*160),
                memory_bytes_per_worker=max(MIN_WORKER_MEMORY_BYTES,model_bytes*3+raw_bytes*160))
            return _bounded_ordered_spawn(partial(_patient_application_transaction,models=models),jobs,
                selected_slots=admission['admitted_worker_ceiling'])
        rows = run_ready_families([batch],policy=run['resource_policy'],root=folder)[0]
    comparisons = []
    for center in cohort['centers']:
        picked = [(job,row) for job,row in zip(jobs,rows) if job['center'] == center['center']]
        for h in (6,12,24,36):
            def risks(mode):
                return [{k:v for k,v in p.items() if k in {'patient_key_hash','center',f'risk_probability_{h}'}}
                    for job,row in picked if (job['mode'] == 'batch') == (mode == 'batch')
                    for p in row['prediction']['risks']]
            value = evaluate_a04_batch_single(risks('batch'),risks('single'),horizon=h) if picked else None
            comparisons.append({'center':center['center'],'report_month':h,
                'patient_count':len(center['selected_ids']),
                'status':value['deployment_gate']['status'] if value is not None else 'NOT_APPLICABLE',
                'reason':None if value is not None else 'NO_APPLICABLE_MISSING_ROWS_IN_FROZEN_SAMPLE',
                'comparison':value})
    _require(sum(r['actual_new_mice_chains'] for r in rows) <= cohort['patient_count']*20,
        'APPLICATION_A04_CHAIN_BUDGET_EXCEEDED')
    result = n._sealed({'kind':'PADML_CURRENT_A04_APPLICATION_PATIENT_BRANCH_V1','binding':binding,
        'status':'COMPLETED','patient_count':cohort['patient_count'],'comparisons':comparisons,
        'patient_branch_status':'PASS' if all(c['status'] in {'PASS','NOT_APPLICABLE'} for c in comparisons) else 'FAIL',
        'complete_a04_status':'REQUIRES_24_PRIMARY_DIAGNOSTIC_SCOPES_AND_REVIEW',
        'application_admission':'BLOCKED_PENDING_COMPLETE_A04_REVIEW',
        'new_model_fits':0,'new_mice_chains':sum(r['actual_new_mice_chains'] for r in rows),
        'patient_chain_slot_upper_bound':cohort['patient_count']*20,
        'formal_references':[file_reference(cohort_path,'A04_APPLICATION_COHORT',run),
            *[file_reference(Path(j['target']),'A04_PATIENT_TRANSACTION',run) for j in jobs]]})
    n._write_exact_once(target,canonical_json_bytes(result),'APPLICATION_A04_PATIENT_RESULT_DRIFT')
    # Qualified transaction records cite the canonical input/native carrier.
    # The local construction inputs are now redundant, exact known members.
    retire_construction_inputs()
    return result
