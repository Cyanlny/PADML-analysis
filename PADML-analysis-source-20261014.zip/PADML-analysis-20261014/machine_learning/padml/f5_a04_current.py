"""UNAPPLIED current PRIMARY A04 loader/callers; parent applies after review.

Pure adapters preserve current locked identities. Explicit execute_* functions
invoke the existing finite native leaves under the original owner and budget;
loading, binding, and final coverage reduction never invoke scientific fitting.
Engineering checks of this draft do not establish native/scientific completion.
"""
from copy import deepcopy
from pathlib import Path
from padml.bundle import ContractError, canonical_json_bytes, sha256_bytes
from padml import nested_loco as n
from padml import f2_kernel as k
from padml.f5 import _validate_final_refit_locked_spec
from padml.f4 import _outer_elastic_parameters

KIND = 'PADML_A04_CURRENT_PRIMARY_INPUT_V1'
SCOPE_KIND = 'PADML_A04_CURRENT_PRIMARY_LOCK_SCOPE_V1'

def require(value, reason):
    if not value:
        raise ContractError(reason)

def sha(value):
    return sha256_bytes(canonical_json_bytes(value))

def _sealed(value):
    return {**value, 'identity_sha256': sha(value)}

def fixed_model_ordinal(outer, family):
    require(type(outer) is int and outer in range(1, 7) and family in k.F2_FAMILIES,
            'A04_CURRENT_SCOPE_INVALID')
    return (outer - 1) * len(k.F2_FAMILIES) + k.F2_FAMILIES.index(family) + 1

def current_primary_context(*, unit, generations, receipt, optimism_manifest,
                            request, request_raw, raw_context, raw_context_raw,
                            frozen, training_response, development,
                            development_raw, canonical_receipts):
    """Adapt consumed current artifacts; keep full training IDs, including center55.

    request/raw: input.zip::o-fit-input.json
    raw_context/raw: input.zip::source/raw-context.json
    development/raw: input.zip::source/primary-selector/development-input.json
    training_response: input.zip::training/response.csv (NOT postprocess response)
    canonical_receipts: contexts/OUTER-N/mice/libraries/OUTER_{role}.json
    optimism_manifest: already-consumed postprocess/input.zip::input.json
    generations: integrated.same_batch_generations(run), not caller-supplied IDs.
    """
    h, outer = unit['horizon'], unit['outer_fold']
    require(unit['kind'] == 'PRIMARY' and h in (6, 12, 24, 36)
        and type(outer) is int and outer in range(1, 7)
        and unit['unit_id'] == f'PRIMARY-H{h:02d}-O{outer}', 'A04_CURRENT_UNIT_INVALID')
    m = optimism_manifest
    require(m.get('kind')=='PADML_F45_OPTIMISM_INPUT_V1'
        and m.get('identity_sha256')==sha({a:b for a,b in m.items() if a!='identity_sha256'}),
        'A04_CURRENT_POSTPROCESS_MANIFEST_DRIFT')
    require(receipt == m['source_receipt'] and receipt['run_identity'] in generations
        and receipt['unit_id'] == unit['unit_id'] and receipt['status'] == 'COMPLETED'
        and receipt['direct_consumer_completed'] is True
        and receipt['selection_horizon_months'] == h
        and sha(receipt) == m['source_receipt_sha256']
        and m['source_unit'] == unit['unit_id'] and m['selection_horizon_months'] == h,
        'A04_CURRENT_RECEIPT_DRIFT')
    context = n.validate_training_context(m['training_context'], training_response)
    lock = n.validate_development_lock(m['development_lock'], context=context,
                                     decision=m['family_decision'])
    require(context['scope'] == 'OUTER' and context['channel'] == 'PRIMARY'
        and context['outer_fold'] == outer and lock['selection_horizon_months'] == h
        and request['training_context'] == context
        and request['identity_sha256'] == sha({a:b for a,b in request.items() if a != 'identity_sha256'})
        and request['identity_sha256'] == m['request_identity_sha256']
        and request['selection_horizon_months'] == h
        and canonical_json_bytes(request) == request_raw,
        'A04_CURRENT_REQUEST_DRIFT')
    require(canonical_json_bytes(raw_context) == raw_context_raw
        and raw_context['identity_sha256'] == sha({a:b for a,b in raw_context.items() if a != 'identity_sha256'})
        and request['raw_context_sha256'] == raw_context['identity_sha256']
        and request['raw_context_member'] == {'sha256': sha256_bytes(raw_context_raw), 'size_bytes':len(raw_context_raw)}
        and raw_context['source']['source_identity'] in generations.values()
        and raw_context['source']['raw_binding_identity'] == frozen['receipt']['identity']
        and raw_context['training_context'] == context, 'A04_CURRENT_RAW_CONTEXT_DRIFT')
    require(canonical_json_bytes(development) == development_raw
        and development['identity_sha256'] == sha({a:b for a,b in development.items() if a != 'identity_sha256'})
        and request['primary_selector_members']['development-input.json'] == {
            'sha256':sha256_bytes(development_raw), 'size_bytes':len(development_raw)}
        and development['identity_sha256'] == lock['selector_evidence_sha256']
        and development['selector']['selected_parents'] == lock['selected_parents']
        and development['selector']['epv_resolution'] == lock['epv_resolution']
        and development['source']['training_ids_sha256'] == context['training_ids_sha256']
        and development['source']['training_response_sha256'] == context['training_response_sha256'],
        'A04_CURRENT_SELECTOR_DRIFT')
    require(frozen['receipt']['source_identity'] in generations.values()
        and frozen['receipt']['raw_input']['sha256'] == frozen['binding_contract']['workbook_sha256'],
        'A04_CURRENT_RAW_BINDING_DRIFT')
    row, = [r for r in frozen['registry']['outer'] if r['outer_fold'] == outer]
    require(row['analysis_ids'] == context['training_ids']
        and row['validation_ids'] == context['heldout_ids']
        and all(context['centers_by_patient'][pid] == frozen['centers'][pid]
                for pid in row['application_ids']), 'A04_CURRENT_POPULATION_DRIFT')
    fields, responses = k._response_rows(frozen['response_csv'])
    require(k._write_response_subset(fields, responses, row['analysis_ids'], None)['private_bytes']
        == training_response, 'A04_CURRENT_TRAINING_RESPONSE_DRIFT')
    from padml.f1_kernel import _view_seed_rows
    require(set(canonical_receipts) == {'OUTER_ANALYSIS','OUTER_APPLICATION'},
            'A04_CURRENT_TWO_CANONICAL_VIEWS_REQUIRED')
    for name, record in canonical_receipts.items():
        view, = [v for v in frozen['registry']['views'][str(outer)] if v['view_id'] == name]
        require(record['raw_binding_identity'] == frozen['receipt']['identity']
            and record['source_identity'] in generations.values() and record['view'] == view
            and record['chain_seeds'] == _view_seed_rows(frozen['registry'], outer, name)
            and record['library']['view_id'] == name
            and record['library']['relative_path'] == f'libraries/{name}.zip'
            and record['library']['row_ids_sha256'] == view['row_ids_sha256'],
            'A04_CURRENT_CANONICAL_VIEW_DRIFT')
    source = _sealed({'kind':KIND, 'unit_id':unit['unit_id'], 'selection_horizon_months':h,
        'producer_run_identity':receipt['run_identity'], 'producer_source_identity':generations[receipt['run_identity']],
        'source_receipt_sha256':sha(receipt), 'input_archive':receipt['artifacts']['input.zip'],
        'result_archive':receipt['artifacts']['result.zip'], 'training_context_sha256':context['identity_sha256'],
        'development_lock_sha256':lock['identity_sha256'], 'raw_context_sha256':raw_context['identity_sha256'],
        'raw_binding_identity':frozen['receipt']['identity'],
        'canonical_views':{name:deepcopy(record['library']) for name,record in canonical_receipts.items()}})
    return {'kind':KIND, 'source':source, 'lock':lock, 'training_context':context,
        'original_training_response':training_response, 'frozen':frozen, 'row':row,
        'registered':raw_context['registered'], 'development':development,
        'primary_searches':request['primary_searches'], 'post_lock_templates':request['post_lock_templates'],
        'canonical_receipts':deepcopy(canonical_receipts),
        'fixed_model_ordinal':fixed_model_ordinal(outer, lock['selected_family'])}

def current_parameter_source(current, imputation, template_task, template_recipe):
    """Return the exact original MI spec and its lambda source; no median fallback.

    task/recipe are read from the original selected-family POST_LOCK_TEMPLATE.
    Its CarrierZip archive pin is checked against the lock by the native caller.
    """
    lock = n.validate_development_lock(current['lock'], context=current['training_context'])
    require(type(imputation) is int and imputation in range(1, 21)
        and current['source']['development_lock_sha256'] == lock['identity_sha256'],
        'A04_CURRENT_LOCK_DRIFT')
    i = imputation - 1
    n.bind_post_lock_task(template_task, lock)
    require(template_task['imputation'] == imputation
        and sha(template_recipe) == lock['recipe_sha256_by_imputation'][i]
        and template_task['parameters'] == lock['parameters_by_imputation'][i],
        'A04_CURRENT_MI_PARAMETER_DRIFT')
    parameters = deepcopy(lock['parameters_by_imputation'][i])
    family, columns = lock['selected_family'], None
    _validate_final_refit_locked_spec(family, parameters)
    if family == 'ELASTIC_NET_COX':
        original, columns = _outer_elastic_parameters(template_task['f4_outer_elastic_source'],
                                                      lock['outer_fold'], imputation)
        require(parameters == original, 'A04_CURRENT_ELASTIC_PARAMETER_DRIFT')
    # Existing A04 native ABI receives this exact two-field source. The full
    # current provenance is an enclosing component/registry field, not a fake
    # legacy selected_spec or a renamed final-family acceptance.
    return parameters, {'selected_spec_sha256':sha(parameters), 'lambda_source_column_map':columns}, {
        'source_unit':current['source']['unit_id'], 'source_identity_sha256':current['source']['identity_sha256'],
        'development_lock_sha256':lock['identity_sha256'], 'imputation':imputation,
        'parameter_sha256':sha(parameters), 'post_lock_template_sha256':sha(template_task),
        'post_lock_template_archive_sha256':lock['post_lock_template_archive_sha256_by_imputation'][i]}

def validate_current_scope_rows(rows, *, require_complete=False):
    """A local PRIMARY scope; final reducer alone requires all 24 original locks."""
    require(1 <= len(rows) <= 24, 'A04_CURRENT_SCOPE_COUNT_INVALID')
    expected = {(h,o) for h in (6,12,24,36) for o in range(1,7)}
    coordinates = [(r['selection_horizon_months'],r['fold']) for r in rows]
    require(set(coordinates) <= expected and len(set(coordinates)) == len(rows),
            'A04_CURRENT_SCOPE_COVERAGE_INVALID')
    if require_complete:
        require(set(coordinates)==expected,'A04_CURRENT_24_LOCKS_REQUIRED')
    result=[]
    for row in rows:
        require(row.get('kind') == SCOPE_KIND and row.get('identity_sha256') == sha(
            {a:b for a,b in row.items() if a != 'identity_sha256'}), 'A04_CURRENT_SCOPE_IDENTITY_DRIFT')
        lock = n.validate_development_lock(row['development_lock'])
        h,o = row['selection_horizon_months'],row['fold']
        require(row['source']['unit_id'] == f'PRIMARY-H{h:02d}-O{o}'
            and row['source']['identity_sha256'] == sha({a:b for a,b in row['source'].items() if a != 'identity_sha256'})
            and row['source']['development_lock_sha256'] == lock['identity_sha256']
            and (lock['selection_horizon_months'],lock['outer_fold'],lock['selected_family']) == (h,o,row['family'])
            and row['selected_spec'] == lock['selected_spec']
            and row['selected_spec_sha256'] == lock['selected_spec_sha256']
            and row['parameters_by_imputation'] == lock['parameters_by_imputation']
            and row['fixed_model_ordinal'] == fixed_model_ordinal(o,row['family']),
            'A04_CURRENT_SCOPE_LOCK_DRIFT')
        # design_source comes from the five real center recipes / original
        # repeat1 recipes and original OUTER; no blank synthetic placeholder.
        design = row['design_source']
        require(design['source_identity_sha256'] == row['source']['identity_sha256']
            and design['registered_input_identity'] == row['registered_input_identity']
            and len(design['local_recipe_bindings']) == len(design['center_recipe_scopes'])
                == len(design['center_recipe_bindings']) == 5
            and design['selected_parent_sha256'] == lock['selected_parents_sha256']
            and design['selector_evidence_sha256'] == lock['selector_evidence_sha256'],
            'A04_CURRENT_DESIGN_SOURCE_INCOMPLETE')
        result.append(row)
    return sorted(result,key=lambda r:(r['selection_horizon_months'],r['fold']))

def current_scope_id(row):
    return f"H{row['selection_horizon_months']:02d}::F{row['fold']}::{row['family']}"

def bind_current_registry_task(row, task):
    """Preserve MI source; unavailable alternate candidate evidence is a hard stop.

    LOCAL parameter changes are declared by the original finite registry, not
    permission to replace the original MI-specific stopping/lambda parameters.
    CENTER uses the original, already-frozen S3B1 candidate diagnostic lock;
    this is explicit and never borrows the formal winner's MI stopping points.
    """
    require(task['family'] == row['family'] and task['fold'] == row['fold'],
            'A04_CURRENT_TASK_SCOPE_DRIFT')
    parameters=deepcopy(row['parameters_by_imputation'])
    parameter_policy = 'FORMAL_PARAMETERS_BY_IMPUTATION'
    if task['task_id'].startswith('CENTER::'):
        if row['family'] in {'RSF','GBM_COX','XGBOOST_COX','COXTIME_SET_A'}:
            # Task already came from _center_candidates(row, actual_contract).
            require(sha(task['selected_spec']) == task['selected_spec_sha256'],
                    'A04_CURRENT_S3B1_CANDIDATE_DRIFT')
            matching = [v for v in row['search_trace']['S3B1']
                if v.get('candidate_id',v.get('trial_id')) == task['selected_spec']['candidate_id']]
            require(len(matching) == 1, 'A04_CURRENT_S3B1_SOURCE_REQUIRED')
            record=matching[0]
            require(record['parameters'] == task['selected_spec']['parameters'],
                    'A04_CURRENT_S3B1_CANDIDATE_DRIFT')
            for family, field, origin in (
                ('GBM_COX','selected_trees','selected_trees_median'),
                ('XGBOOST_COX','selected_rounds','selected_rounds_median'),
                ('COXTIME_SET_A','locked_epoch','selected_epoch_median')):
                if row['family'] == family:
                    require(record[origin] == task['selected_spec'][field],
                            'A04_CURRENT_S3B1_STOP_SOURCE_REQUIRED')
            parameters=[deepcopy(task['selected_spec']) for _ in range(20)]
            parameter_policy='REGISTERED_S3B1_DIAGNOSTIC_CANDIDATE_LOCK'
    if task['task_id'].startswith('LOCAL::'):
        parameter = task['parameter_name']
        for spec in parameters:
            if parameter == 'candidate_id':
                spec['candidate_id'] = task['selected_spec']['candidate_id']
                spec['parameters'] = deepcopy(task['selected_spec']['parameters'])
            else:
                require(spec['parameters'][parameter] == row['selected_spec']['parameters'][parameter],
                        'A04_CURRENT_LOCAL_PARAMETER_SOURCE_DRIFT')
                spec['parameters'][parameter] = task['candidate_value']
    for spec in parameters:
        _validate_final_refit_locked_spec(row['family'],spec)
    return {**task, 'parameter_policy':parameter_policy,
        'selection_horizon_months':row['selection_horizon_months'],
        'current_lock_source':deepcopy(row['source']), 'parameters_by_imputation':parameters,
        'parameters_by_imputation_sha256':sha(parameters)}


def current_p2c2t_row(current, diagnostic_parts, center_recipe_set):
    """Build one real current scope, after existing center recipe consumers pass.

    diagnostic_parts come only from registry.center_stress projected onto the
    original OUTER_APPLICATION. No rebuilding all 62 views, no MICE fitting.
    """
    lock=current['lock']; outer=lock['outer_fold']; family=lock['selected_family']
    development=current['development']; selected=lock['selected_parents']
    predictors=k.predictor_contract(Path(k.__file__).parent)
    recipes=k._validate_transform_recipe_set(development['transform_recipes'],predictors,expected_count=16)
    center=k._validate_transform_recipe_set(center_recipe_set,predictors,expected_count=5)
    parts=current['registered']['partitions']
    outer_part,=[v for v in parts if v['kind']=='OUTER']
    inner=sorted([v for v in parts if v['kind']=='INNER' and v['repeat']==1],key=lambda v:v['inner_fold'])
    registered_centers=sorted([v for v in current['frozen']['registry']['center_stress']
        if v['outer_fold']==outer],key=lambda v:v['partition_id'])
    diagnostics=sorted(diagnostic_parts,key=lambda v:v['partition_id'])
    require(len(inner)==len(diagnostics)==len(registered_centers)==5,'A04_CURRENT_DIAGNOSTIC_COVERAGE')
    for actual, frozen in zip(diagnostics,registered_centers,strict=True):
        require(actual['kind']=='CENTER_STRESS' and actual['partition_id']==frozen['partition_id']
            and actual['fit_ids']==frozen['analysis_ids'] and actual['evaluation_ids']==frozen['validation_ids']
            and actual['application_ids']==frozen['application_ids']
            and actual['validation_center']==frozen['validation_center'], 'A04_CURRENT_CENTER_SPLIT_DRIFT')
    def recipe_pin(part, source):
        recipe=k._recipe_by_partition(source,part['partition_id'])
        identity=k._registered_partition_identity_record(part,prediction_only=part['kind']=='OUTER')
        require(recipe['fit_ids_sha256']==identity['fit_ids_sha256']
            and recipe['analysis_view_sha256']==identity['analysis_view_sha256'],
            'A04_CURRENT_RECIPE_SOURCE_DRIFT')
        return {'consumer_partition_id':part['partition_id'],'recipe_partition_id':part['partition_id'],
            **{key:recipe[key] for key in ('recipe_sha256','analysis_view_sha256','analysis_ids_sha256','fit_ids_sha256')}}
    outer_pin=recipe_pin(outer_part,recipes)
    center_pins=[recipe_pin(part,center) for part in diagnostics]
    selector={**deepcopy(development['selector']),'recipe_set':recipes,
        'recipe_set_sha256':recipes['recipe_set_sha256'],'outer_recipe_sha256':outer_pin['recipe_sha256']}
    design={'source_identity_sha256':current['source']['identity_sha256'],
        'family_design_binding_sha256':sha({'kind':SCOPE_KIND,'family':family,
            'recipes':lock['recipe_sha256_by_imputation'],'selected_parents':selected}),
        'selector_evidence_sha256':lock['selector_evidence_sha256'],
        'selected_parent_sha256':lock['selected_parents_sha256'],
        'registered_input_identity':current['registered']['identity'],
        'selector_recipe_set_sha256':recipes['recipe_set_sha256'], 'outer_recipe':outer_pin,
        'local_recipe_bindings':[recipe_pin(part,recipes) for part in inner],
        'center_recipe_scopes':[{'partition_id':part['partition_id'],**{key:k._registered_partition_identity_record(part)[key]
            for key in ('analysis_view_sha256','analysis_ids_sha256','fit_ids_sha256')}} for part in diagnostics],
        'center_recipe_bindings':center_pins,
        'diagnostic_input_identity':sha([k._registered_partition_identity_record(part) for part in diagnostics])}
    search=current['primary_searches'].get(family)
    trace=deepcopy(search['result']['search_trace']) if search is not None else {}
    require(search is not None or family in {'COX_PH','ELASTIC_NET_COX','FPM_TVC_SET_A'},
            'A04_CURRENT_SEARCH_SOURCE_REQUIRED')
    return _sealed({'kind':SCOPE_KIND,'selection_horizon_months':lock['selection_horizon_months'],
        'fold':outer,'family':family,'source':deepcopy(current['source']),
        'development_lock':deepcopy(lock),'selected_spec':deepcopy(lock['selected_spec']),
        'selected_spec_sha256':lock['selected_spec_sha256'],
        'parameters_by_imputation':deepcopy(lock['parameters_by_imputation']),
        'fixed_model_ordinal':fixed_model_ordinal(outer,family),
        'registered_input_identity':current['registered']['identity'],
        'selector_evidence':selector,'search_trace':trace,'design_source':design})

def bind_current_atomic_plan(plan, row, task):
    """Call between existing atomic_job_plan=True and the sole native pool.

    A new caller must require this function; do not submit the unbound plan.
    Leaves native job keys, task order, seeds, representations and response roles unchanged.
    """
    require(task['current_lock_source']==row['source']
        and task['parameters_by_imputation_sha256']==sha(task['parameters_by_imputation'])
        and plan['task_id']==task['task_id'] and plan['engine_threads']==1,
        'A04_CURRENT_ATOMIC_PLAN_SOURCE_DRIFT')
    result=deepcopy(plan)
    family=task['family']; specs=task['parameters_by_imputation']
    require(len(specs)==20,'A04_CURRENT_M20_PARAMETERS_REQUIRED')
    for job in result['jobs']:
        fit=job['fit_task']; imp=fit['imputation']; spec=specs[imp-1]
        _validate_final_refit_locked_spec(family,spec)
        if job['route']=='R':
            if family=='ELASTIC_NET_COX':
                alphas={s['alpha'] for s in specs}
                require(len(alphas)==1,'A04_CURRENT_ELASTIC_ALPHA_DRIFT')
                vector={'family':family,'alpha':spec['alpha'],
                    'ratio_by_imputation':[s['ratio'] for s in specs],
                    'lambda_by_imputation':[s['lambda'] for s in specs],
                    'lambda_upper_bound_by_imputation':[s['lambda_upper_bound'] for s in specs]}
                fit['parameters']=k._locked_family_parameters(family,vector)
            else:
                fit['parameters']=k._locked_family_parameters(family,spec)
        elif job['route']=='XGBOOST_COX':
            fit['parameters']=k._engine_parameters(family,spec['parameters'])
            fit['locked_rounds']=spec['selected_rounds']
        elif job['route']=='COXTIME_SET_A':
            fit['candidate']=deepcopy(spec['parameters']); fit['locked_epoch']=spec['locked_epoch']
        else:
            raise ContractError('A04_CURRENT_NATIVE_ROUTE_INVALID')
    require({job['fit_task']['imputation'] for job in result['jobs']}==set(range(1,21)),
            'A04_CURRENT_ATOMIC_PLAN_M20_INCOMPLETE')
    return result

def load_current_primary(run, unit, root):
    """Read existing admitted carriers, never invoke preparation or native fitting."""
    from padml.bundle import strict_json_bytes
    from padml.carriers import open_carrier
    from padml.integrated import load_raw_binding, same_batch_generations, qualify_primary_request
    from padml.f4 import _f45_optimism_member
    from padml.worker import _f45_file_pins
    root=Path(root)
    receipt=strict_json_bytes((root/'unit.json').read_bytes())
    # Existing qualification cache binds the physical original member closure.
    names=('input.zip','input.compile.json','result.zip')
    _f45_file_pins({name:root/name for name in names}, policy=run['resource_policy'],root=root,
        expected={name:receipt['artifacts'][name] for name in names})
    with open_carrier(root/'postprocess/input.zip') as archive:
        manifest=strict_json_bytes(_f45_optimism_member(archive,'input.json',limit=8*1024**2))
    with open_carrier(root/'result.zip') as archive:
        execution=strict_json_bytes(_f45_optimism_member(archive,'o-fit-execution.json',limit=32*1024**2))
    require(execution['development_lock']==manifest['development_lock']
        and execution['input_archive']==receipt['artifacts']['input.zip']
        and execution['input_identity_sha256']==manifest['request_identity_sha256'],
        'A04_CURRENT_POSTPROCESS_LOCK_DRIFT')
    compiled=strict_json_bytes((root/'input.compile.json').read_bytes())
    with open_carrier(root/'input.zip') as archive:
        def member(name,pin=None):
            return _f45_optimism_member(archive,name,pin,limit=32*1024**2)
        raw_request=member('o-fit-input.json'); request=strict_json_bytes(raw_request)
        qualify_primary_request(request,compiled,root/'input.zip')
        raw_context=member('source/raw-context.json',request['raw_context_member'])
        development=member('source/primary-selector/development-input.json',
            request['primary_selector_members']['development-input.json'])
        response=member('training/response.csv')
        frozen=load_raw_binding(Path(run['run_root'])/'binding',expected_input=run['raw_input'])
        canonical_root=Path(run['run_root'])/'contexts'/unit['context']/'mice'
        canonical_receipts={name:strict_json_bytes((canonical_root/'libraries'/(name+'.json')).read_bytes())
            for name in ('OUTER_ANALYSIS','OUTER_APPLICATION')}
        current=current_primary_context(unit=unit,generations=same_batch_generations(run),receipt=receipt,
            optimism_manifest=manifest,request=request,request_raw=raw_request,
            raw_context=strict_json_bytes(raw_context),raw_context_raw=raw_context,frozen=frozen,
            training_response=response,development=strict_json_bytes(development),development_raw=development,
            canonical_receipts=canonical_receipts)
        templates={}; lock=current['lock']
        for record in request['post_lock_templates']:
            if record['family']!=lock['selected_family']: continue
            i=record['imputation'];name=record['path']
            require(name==f"templates/{lock['selected_family']}/M{i:02d}.zip"
                and record['sha256']==lock['post_lock_template_archive_sha256_by_imputation'][i-1]
                and archive.getinfo(name).file_size==record['size_bytes'],'A04_CURRENT_TEMPLATE_ARCHIVE_DRIFT')
            with archive.open(name) as stream,open_carrier(stream) as template:
                task=strict_json_bytes(_f45_optimism_member(template,'task.json',limit=8*1024**2))
                recipe=strict_json_bytes(_f45_optimism_member(template,'recipe.json',limit=8*1024**2))
            current_parameter_source(current,i,task,recipe)
            require(i not in templates,'A04_CURRENT_TEMPLATE_DUPLICATE')
            templates[i]=(task,recipe)
    require(set(templates)==set(range(1,21)),'A04_CURRENT_TEMPLATE_M20_INCOMPLETE')
    n.validate_selected_prediction(execution['selected_prediction'],current['lock'])
    return {**current,'selected_prediction':execution['selected_prediction'],'canonical_root':canonical_root,'templates':templates,'run':run,'unit':unit,'unit_root':root}

def current_layout(current, outer):
    lock=current['lock'];require(lock['outer_fold']==outer,'A04_CURRENT_OUTER_DRIFT')
    predictors=k.predictor_contract(Path(k.__file__).parent)
    recipes=k._validate_transform_recipe_set(current['development']['transform_recipes'],predictors,expected_count=16)
    recipe=k._recipe_by_partition(recipes,current['row']['partition_id'])
    df=sum(len(r['columns']) for r in k._expected_family_parent_column_map(
        lock['selected_parents'],'ELASTIC_NET_COX',predictors,recipe))
    require(df==lock['common_set_design_df'] and lock['training_event_count']/df>=lock['epv_resolution']['minimum'],
            'A04_CURRENT_EPV_OR_DESIGN_DRIFT')
    identities=[k._registered_partition_identity_record(part,prediction_only=part['kind']=='OUTER')
        for part in current['registered']['partitions']]
    return {'outer_fold':outer,'family':lock['selected_family'],'row':current['row'],
        'selected_parents':lock['selected_parents'],'original_recipe':recipe,'common_set_design_df':df,
        'training_event_count':lock['training_event_count'],'current_primary':current,
        'model':{'kind':'PADML_A04_CURRENT_PRIMARY_MODEL_SOURCE_V1','source':current['source'],
            'selected_spec':lock['selected_spec'],'selected_spec_sha256':lock['selected_spec_sha256'],
            'model_input':{'model_partitions':identities}}}

def _a04_write_input(path, entries):
    from padml.bundle import read_safe_zip,write_deterministic_zip
    if path.exists():
        require(not path.is_symlink() and read_safe_zip(path)==entries,'A04_CURRENT_INPUT_RESUME_DRIFT')
    else:
        write_deterministic_zip(path,entries)

def _a04_current_view_job(job):
    from padml.f5_sensitivity import _run_a12_total_mice_input,_pack_a12_total_mice_view
    from padml.bundle import sha256_file
    source,target=Path(job['input']),Path(job['target'])
    flags={'a04_variant':job['branch']=='variants','a04_negative':job['branch']=='negative'}
    new_chains=0; native_invocations=0
    if not target.exists():
        # The existing R native_chains resumes the original impNN.rds/RNG.
        # Stable root replaces only the legacy wrapper's random mkdtemp path.
        native=source.with_name(source.name+'.native-work');native.mkdir(mode=0o700,exist_ok=True)
        count=20 if job['branch']=='variants' else 2
        already={i for i in range(1,count+1) if (native/'native'/f'imp{i:02d}.rds').is_file()}
        _run_a12_total_mice_input(source,native,**flags);native_invocations=1
        _pack_a12_total_mice_view(source,native,target,**flags)
        from padml.bundle import strict_json_bytes
        from padml.f1_kernel import complete_data_passthrough
        summary=strict_json_bytes((native/'output/summary.json').read_bytes())
        new_chains=0 if complete_data_passthrough(summary) else count-len(already)
    require(target.is_file() and not target.is_symlink(),'A04_CURRENT_VIEW_MISSING')
    # The unchanged _prepare -> materialize consumer validates this archive
    # before any model fitting; existence here is not scientific acceptance.
    return {'sha256':sha256_file(target),'size_bytes':target.stat().st_size,
        'actual_new_chain_starts_this_invocation':new_chains,'native_view_invocations':native_invocations}

def _a04_replay_numbers(job, path):
    from padml.f5_sensitivity import _ablation_component_numbers
    from padml.bundle import strict_json_bytes,validate_sha256
    path=Path(path);require(path.is_file() and not path.is_symlink(),'A04_CURRENT_NUMBERS_REQUIRED')
    raw=path.read_bytes();value=strict_json_bytes(raw)
    require(canonical_json_bytes(value)==raw,'A04_CURRENT_NUMBERS_NONCANONICAL')
    validate_sha256(value['native_archive']['sha256'],'a04.native_archive.sha256')
    require(type(value['native_expanded_bytes']) is int and value['native_expanded_bytes']>0
        and type(value['native_archive']['size_bytes']) is int and value['native_archive']['size_bytes']>0,
        'A04_CURRENT_NATIVE_SOURCE_INVALID')
    if 'retained_bytes_per_component' in job:
        require(value['native_expanded_bytes']+value['native_archive']['size_bytes']+len(raw)
            <=job['retained_bytes_per_component'],'A04_CURRENT_STORAGE_ESTIMATE_EXCEEDED')
    return _ablation_component_numbers(job['entries'],value)

def _a04_retire_fit_members(job, numbers):
    """Resume retirement from consumed numerical identities, never new file pins."""
    from padml.f5_sensitivity import _retire_a12_member_copies
    root=Path(job['root']);numbers_path=root.with_suffix('.numbers.json')
    raw_members={**job['entries'],
        'fit-health.json':canonical_json_bytes(numbers['fit_health']),
        'training-prediction.json':canonical_json_bytes(numbers['training_prediction']['survival']),
        'prediction.json':canonical_json_bytes(numbers['prediction'])}
    pins={root/name:{'sha256':sha256_bytes(raw),'size_bytes':len(raw)}
        for name,raw in raw_members.items()}
    for name,field in (('model.bin','model_sha256'),('baseline.bin','baseline_sha256')):
        path=root/name
        if path.exists() or path.is_symlink():
            require(path.is_file() and not path.is_symlink(),'A04_CURRENT_RETIREMENT_PATH_INVALID')
            pins[path]={'sha256':numbers[field],'size_bytes':path.stat().st_size}
    pins[root.with_suffix('.zip')]=numbers['native_archive']
    return _retire_a12_member_copies(root.parent,pins,protected=(numbers_path,))

def _a04_current_fit_job(job):
    from padml.f5_sensitivity import (_execute_ablation_component,_replay_ablation_component,
        _retire_a12_member_copies)
    from padml.f5 import _validate_retained_model_objects
    from padml.bundle import strict_json_bytes,sha256_file
    root=Path(job['root']);archive=root.with_suffix('.zip');numbers_path=root.with_suffix('.numbers.json')
    def counted(value,new):
        return {'row':value,'actual_new_model_fits_this_invocation':new} if job.get('record_execution') else value
    if numbers_path.exists():
        row=_a04_replay_numbers(job,numbers_path)
        # An interrupted retirement is idempotent; the complete compact reader
        # remains authoritative, not the existence of leftover model members.
        value=strict_json_bytes(numbers_path.read_bytes())
        _a04_retire_fit_members(job,value)
        return counted(row,0)
    names=('model.bin','baseline.bin','fit-health.json')
    present=[(root/name).is_file() for name in names]
    require(archive.is_file() or not any(present) or all(present),'A04_CURRENT_PARTIAL_NATIVE_REQUIRES_RECOVERY')
    require(archive.is_file() or not (root/'native-failure.json').exists() or all(present),
            'A04_CURRENT_FAILED_NATIVE_REQUIRES_RECOVERY')
    new=0
    if not archive.is_file():
        require(not root.exists() or not any(root.iterdir()) or all(present),
            'A04_CURRENT_PARTIAL_NATIVE_REQUIRES_RECOVERY')
        if all(present):
            require(all((root/name).is_file() and not (root/name).is_symlink()
                and (root/name).read_bytes()==raw for name,raw in job['entries'].items()),
                'A04_CURRENT_RETAINED_INPUT_DRIFT')
            task=strict_json_bytes(job['entries']['task.json'])
            _validate_retained_model_objects(task['family'],(root/names[0]).read_bytes(),
                (root/names[1]).read_bytes(),strict_json_bytes((root/names[2]).read_bytes()),task)
        actual=_execute_ablation_component(job);new=0 if all(present) else 1
    else:
        actual=None
    numbers=_replay_ablation_component({**job,'archive':archive,'collect_numbers':True})
    if actual is not None:
        require(actual==numbers['prediction'],'A04_CURRENT_FIRST_NATIVE_REPLAY_DRIFT')
    n._write_exact_once(numbers_path,canonical_json_bytes(numbers),'A04_CURRENT_NUMBERS_PUBLICATION_DRIFT')
    row=_a04_replay_numbers(job,numbers_path)
    # Exact original component names, after native model and numeric consumers.
    # No wildcard traversal; a failed/unknown file remains evidence.
    _a04_retire_fit_members(job,numbers)
    return counted(row,new)

def _read_current_permutation(frozen, outer, index, path):
    from padml.f5_negative_controls import _permutation,_check_permutation
    from padml.bundle import strict_json_bytes
    if not path.exists():
        return _permutation(frozen,outer,index,path)
    files=(path/'source-response.csv',path/'output/permutation.json',
           path/'output/analysis-response.csv',path/'output/evaluation-response.csv')
    require(all(p.is_file() and not p.is_symlink() for p in files),
            'A04_CURRENT_PARTIAL_PERMUTATION_REQUIRES_RECOVERY')
    require(files[0].read_bytes()==frozen['response_csv'],'A04_CURRENT_PERMUTATION_SOURCE_DRIFT')
    value={'evidence':strict_json_bytes(files[1].read_bytes()),
           'analysis_response':files[2].read_bytes(),'evaluation_response':files[3].read_bytes()}
    _check_permutation(frozen,outer,index,value)
    return value

def execute_current_variants_and_negative(current, root):
    """One PRIMARY's appendage. Uses only the existing view/model leaves and pool.

    Caller owns the native unit lock and uses the existing process pool.
    """
    import tempfile,shutil
    from padml import f5_mice_variants as v,f5_negative_controls as neg
    from padml.bundle import strict_json_bytes,sha256_file,write_deterministic_zip
    from padml.carriers import write_carrier,open_carrier,resolve_reference
    from padml.integrated import qualified_file_pins
    from padml.runtime import _ready_ordered,MIN_WORKER_MEMORY_BYTES,admit_stage
    root=Path(root);root.mkdir(mode=0o700,parents=True,exist_ok=True)
    n._write_exact_once(root/'input.json',canonical_json_bytes(current['source']),'A04_CURRENT_SOURCE_DRIFT')
    context={'current_primary':current};outer=current['lock']['outer_fold'];family=current['lock']['selected_family']
    policy=current['run']['resource_policy'];budgets=current['run']['budgets']
    retained_view=budgets['retained_bytes_per_view']; retained_model=budgets['retained_bytes_per_component']
    results={};actual_counts={'model_fits':0,'mice_chain_starts':0,'native_view_invocations':0}
    with tempfile.TemporaryDirectory(prefix='prepare-',dir=root) as name:
        work=Path(name);original_root=work/'original';original=None
        for branch,module,header in [('variants',v,'variant-outer.json'),('negative',neg,'negative-outer.json')]:
            target=root/(branch+'.zip');stage=root/branch;stage.mkdir(mode=0o700,exist_ok=True)
            if target.exists():
                def consume():
                    replay_root=work/(branch+'-replay')
                    (v.replay_variant_outer if branch=='variants' else neg.replay_negative_outer)(target,context,replay_root)
                with open_carrier(target) as carrier:
                    closure={name:resolve_reference(ref,current['run']) for name,ref in carrier.references.items()}
                body,_=v._audit_json(target,header)
                require(set(closure)==set(body['members']),'A04_CURRENT_RESULT_CLOSURE_DRIFT')
                qualified_file_pins({'native':target,**closure},identity=current['source'],
                    record=stage/'read-qualification.json',validate=consume)
                body,_=v._audit_json(target,header)
                require(body['source']==current['source'],'A04_CURRENT_COMPLETED_SOURCE_DRIFT')
                results[branch]=body
                continue
            if original is None:
                admit_stage(policy,root,legal_tasks=1,retained_bytes=retained_view,
                    transient_bytes_per_worker=retained_view,publication_bytes=0,
                    memory_bytes_per_worker=policy['memory_bytes_per_worker'])
                original=v._original_outer(current['frozen'],v._layout(context,outer),original_root)
                n._write_exact_once(original_root/'admission.json',canonical_json_bytes(original),'A04_CURRENT_ORIGINAL_DRIFT')
            views={};view_jobs=[];permutations={}
            if branch=='variants':
                for variant in v.A04_NEW_MICE_VARIANTS:
                    folder=stage/'views'/variant;folder.mkdir(mode=0o700,parents=True,exist_ok=True)
                    for role in ('ANALYSIS','APPLICATION'):
                        leaf='OUTER_'+role;source=folder/(leaf+'-input.zip');result=folder/(leaf+'.zip')
                        _a04_write_input(source,v._a04_variant_view_inputs(current['frozen'],outer,variant,role))
                        views[variant+'/'+leaf]=result
                        view_jobs.append({'input':str(source),'target':str(result),'branch':branch})
            else:
                (stage/'permutations').mkdir(mode=0o700,exist_ok=True)
                (stage/'views').mkdir(mode=0o700,exist_ok=True)
                for index in range(1,4):
                    permutations[index]=_read_current_permutation(current['frozen'],outer,index,
                        stage/f'permutations/P{index}')
                    source=stage/f'views/P{index}-input.zip';result=stage/f'views/P{index}.zip'
                    _a04_write_input(source,neg._analysis_inputs(current['frozen'],outer,index,permutations[index]))
                    views[index]=result;view_jobs.append({'input':str(source),'target':str(result),'branch':branch})
            view_counts=_ready_ordered(_a04_current_view_job,view_jobs,policy=policy,root=stage,
                retained_bytes_per_task=retained_view,transient_bytes_per_worker=3*retained_view,
                publication_bytes=retained_view,memory_bytes_per_worker=MIN_WORKER_MEMORY_BYTES,
                retained_bytes_by_task=[min(retained_view,8*1024**2) if Path(j['target']).is_file()
                    else retained_view for j in view_jobs])
            actual_counts['mice_chain_starts']+=sum(v['actual_new_chain_starts_this_invocation'] for v in view_counts)
            actual_counts['native_view_invocations']+=sum(v['native_view_invocations'] for v in view_counts)
            prepared_root=work/(branch+'-prepared')
            prepared,jobs=(v._prepare(context,outer,views,prepared_root,original_evidence=original) if branch=='variants'
                else neg._prepare(context,outer,views,prepared_root,original_root=original_root,permutations=permutations))
            (stage/'fits').mkdir(mode=0o700,exist_ok=True)
            jobs=[{**job,'root':str(stage/'fits'/job['name']),
                   'retained_bytes_per_component':retained_model,'record_execution':True} for job in jobs]
            # Payload-derived lower bound supplements, never replaces, 1GiB.
            memory=max(MIN_WORKER_MEMORY_BYTES,32*max(sum(map(len,j['entries'].values())) for j in jobs))
            counted_rows=_ready_ordered(_a04_current_fit_job,jobs,policy=policy,root=stage,
                retained_bytes_per_task=retained_model,transient_bytes_per_worker=3*retained_model,
                publication_bytes=retained_model,memory_bytes_per_worker=memory,
                retained_bytes_by_task=[min(retained_model,8*1024**2) if Path(j['root']).with_suffix('.numbers.json').is_file()
                    else retained_model for j in jobs])
            rows=[v['row'] for v in counted_rows]
            actual_counts['model_fits']+=sum(v['actual_new_model_fits_this_invocation'] for v in counted_rows)
            members={name:stage/name for name in module._member_names(family,outer,compact=True)}
            for name in members:
                if name.startswith('recipes/'):
                    _,scope,leaf=name.split('/')
                    path=stage/name;path.parent.mkdir(mode=0o700,parents=True,exist_ok=True)
                    n._write_exact_once(path,(prepared_root/scope/'recipe-native'/leaf).read_bytes(),
                                        'A04_CURRENT_RECIPE_PUBLICATION_DRIFT')
                    members[name]=path
                elif name.startswith('permutations/') and name.rsplit('/',1)[1] in {
                        'permutation.json','analysis-response.csv','evaluation-response.csv','native-session.txt'}:
                    members[name]=members[name].parent/'output'/members[name].name
            body={'kind':'PADML_CURRENT_A04_VARIANT_OUTER_NUMERICAL_V1' if branch=='variants' else 'PADML_CURRENT_A04_NEGATIVE_OUTER_NUMERICAL_V1',
                **prepared,'predictions':module._predictions(prepared,jobs,rows),
                'members':{name:{'sha256':sha256_file(path),'size_bytes':path.stat().st_size}
                           for name,path in sorted(members.items())}}
            write_carrier(target,{header:canonical_json_bytes(body)},references=members,run=current['run'])
            actual,_=v._audit_json(target,header)
            require(actual==body,'A04_CURRENT_PUBLISHED_RESULT_DRIFT')
            # Every view and model was already consumed above; qualification
            # records only that same just-consumed publication. No second fit.
            qualified_file_pins({'native':target,**members},identity=current['source'],
                record=stage/'read-qualification.json',validate=lambda:None)
            results[branch]=actual
            # Exact declared view members only. The compact model worker has
            # retired each model after its direct numerical consumer.
            from padml.f5_sensitivity import _retire_a12_member_copies
            from padml.carriers import open_carrier
            for job in view_jobs:
                native=Path(job['input']).with_name(Path(job['input']).name+'.native-work')
                if not native.exists(): continue
                pins={}
                with open_carrier(Path(job['target'])) as published:
                    for name in published.namelist():
                        for path in (native/name,native/'output'/name):
                            if path.is_file() and not path.is_symlink():
                                pin={'sha256':sha256_file(path),'size_bytes':path.stat().st_size}
                                with published.open(name) as member:
                                    import hashlib
                                    digest=hashlib.sha256();size=0
                                    for chunk in iter(lambda:member.read(1024**2),b''):
                                        digest.update(chunk);size+=len(chunk)
                                require(pin=={'sha256':digest.hexdigest(),'size_bytes':size},
                                    'A04_CURRENT_VIEW_RETIREMENT_DRIFT')
                                pins[path]=pin
                _retire_a12_member_copies(native,pins)
    return {**results,'actual_new_this_invocation':actual_counts}

def prepare_current_inner_assets(current, destination):
    """Rehydrate only five LOCAL pairs from the same canonical views; zero MICE."""
    import zipfile
    from padml.bundle import strict_json_bytes,_validated_zip_infos,sha256_file
    from padml.f1_kernel import _view_seed_rows
    from padml.integrated import same_batch_generations
    from padml.runtime import _ready_ordered,MIN_WORKER_MEMORY_BYTES
    root=Path(destination);root.mkdir(mode=0o700)
    (root/'view-sources').mkdir(mode=0o700);(root/'partitions').mkdir(mode=0o700)
    outer=current['lock']['outer_fold'];frozen=current['frozen'];policy=current['run']['resource_policy']
    fields,response=k._response_rows(frozen['response_csv'])
    rows=sorted([r for r in frozen['registry']['inner'] if r['outer_fold']==outer and r['repeat']==1],
        key=lambda v:v['inner_fold'])
    require(len(rows)==5,'A04_CURRENT_LOCAL_PARTITIONS_INCOMPLETE')
    views={r['view_id']:r for r in frozen['registry']['views'][str(outer)]};jobs=[]
    generations=same_batch_generations(current['run'])
    for row in rows:
        stem=f"INNER_R1_K{row['inner_fold']}";sources=[];expanded=largest=0
        for role in ('ANALYSIS','APPLICATION'):
            name=stem+'_'+role;path=current['canonical_root']/'libraries'/(name+'.zip')
            receipt=strict_json_bytes(path.with_suffix('.json').read_bytes())
            require(receipt['raw_binding_identity']==frozen['receipt']['identity']
                and receipt['source_identity'] in generations.values() and receipt['view']==views[name]
                and receipt['chain_seeds']==_view_seed_rows(frozen['registry'],outer,name)
                and {'sha256':sha256_file(path),'size_bytes':path.stat().st_size}==
                    {key:receipt['library'][key] for key in ('sha256','size_bytes')},
                'A04_CURRENT_LOCAL_CANONICAL_SOURCE_DRIFT')
            with zipfile.ZipFile(path) as archive:
                infos=_validated_zip_infos(archive,None,max_member_bytes=128*1024**2,
                    max_total_bytes=3*1024**3,max_compression_ratio=1000)
                expanded+=sum(v.file_size for v in infos);largest=max(largest,*(v.file_size for v in infos))
            sources.append({'view':views[name],'archive':str(path)})
        fit=k._write_response_subset(fields,response,row['analysis_ids'],None)
        evaluation=k._write_response_subset(fields,response,row['validation_ids'],None)
        jobs.append({'destination':str(root),'policy':policy,'row':row,'kind':'INNER','sources':sources,
            'evaluation_ids':row['validation_ids'],'fit_response':fit,'evaluation_response':evaluation,
            'estimates':{'retained_bytes':2*expanded+fit['size_bytes'],'publication_bytes':0,
                'transient_bytes_per_worker':max(1,expanded),'memory_bytes_per_worker':max(MIN_WORKER_MEMORY_BYTES,
                    64*largest+32*(fit['size_bytes']+evaluation['size_bytes']))}})
    actual=_ready_ordered(k._materialize_registered_pair,jobs,policy=policy,root=root,
        retained_bytes_per_task=max(j['estimates']['retained_bytes'] for j in jobs),
        transient_bytes_per_worker=max(j['estimates']['transient_bytes_per_worker'] for j in jobs),publication_bytes=0,
        memory_bytes_per_worker=max(j['estimates']['memory_bytes_per_worker'] for j in jobs),
        retained_bytes_by_task=[j['estimates']['retained_bytes'] for j in jobs])
    originals={r['partition_id']:r for r in current['registered']['partitions']}
    for part in actual:
        require(k._registered_partition_identity_record(part)==k._registered_partition_identity_record(originals[part['partition_id']]),
            'A04_CURRENT_LOCAL_REHYDRATION_DRIFT')
    return {r['partition_id']:r for r in actual}

def prepare_current_center_assets(current, original_root, destination):
    """Only the five original center-stress scopes; canonical APPLICATION only."""
    destination=Path(destination);destination.mkdir(mode=0o700)
    rows=sorted([v for v in current['frozen']['registry']['center_stress']
        if v['outer_fold']==current['lock']['outer_fold']],key=lambda v:v['partition_id'])
    require(len(rows)==5 and all(v['application_ids']==rows[0]['application_ids'] for v in rows),
            'A04_CURRENT_CENTER_COVERAGE_INVALID')
    covariates=k._materialize_application_subset(Path(original_root)/'views/OUTER_APPLICATION',
        application_ids=rows[0]['application_ids'],destination=destination/'covariates',
        partition_id=f"CENTER_STRESS_F{current['lock']['outer_fold']}")
    fields,response=k._response_rows(current['frozen']['response_csv']);parts=[]
    for row in rows:
        fit=row['analysis_ids'];members=[]
        for i in range(1,21):
            name=f'imp{i:02d}.csv';raw=k._recipe_training_member_bytes(Path(covariates['input_dir'])/name,fit)
            members.append({'name':name,'sha256':sha256_bytes(raw),'size_bytes':len(raw)})
        analysis=sha({'schema_version':'1.0.0','kind':'PADML_F2_CENTER_TRAINING_ANALYSIS_VIEW',
                      'fit_ids_sha256':sha(fit),'members':members})
        binding={**covariates,'partition_id':row['partition_id'],'analysis_view_sha256':analysis,
            'analysis_ids_sha256':sha(fit),'data_identity':sha({'analysis_view_sha256':analysis,
                'application_view_sha256':covariates['application_view_sha256'],
                'analysis_ids_sha256':sha(fit),'application_ids_sha256':covariates['application_ids_sha256']})}
        folder=destination/row['partition_id'];folder.mkdir(mode=0o700)
        parts.append({'kind':'CENTER_STRESS','partition_id':row['partition_id'],'repeat':0,'inner_fold':0,
            'validation_center':row['validation_center'],'selection_effect':'NONE','fit_ids':fit,
            'evaluation_ids':row['validation_ids'],'evaluation_ids_sha256':sha(row['validation_ids']),
            'application_ids':row['application_ids'],'covariates':binding,
            'fit_response':k._write_response_subset(fields,response,fit,folder/'fit-response.csv'),
            'evaluation_response':k._write_response_subset(fields,response,row['validation_ids'],None),
            'fit_covariate_members':k._fit_covariate_member_records(binding,fit)})
    # The already-qualified OUTER merged view is available in this workspace;
    # its original identity remains unchanged. Do not rely on a retired private
    # prepare directory for sample-size diagnostics.
    from padml._science_authority import load_science_authority
    local_families=load_science_authority()['science']['f2_model_development']['p2c2t_contract']['local_registry_families']
    local=(prepare_current_inner_assets(current,destination/'local')
           if current['lock']['selected_family'] in local_families else {})
    original_parts=[]
    for part in current['registered']['partitions']:
        part=local.get(part['partition_id'],part)
        if part['kind']=='OUTER':
            part={**part,'covariates':{**part['covariates'],
                'input_dir':str(Path(original_root)/'partition/covariates')},
                'fit_response':{**part['fit_response'],
                    'path':str(Path(original_root)/'partition/fit-response.csv')}}
        original_parts.append(part)
    registered={**current['registered'],'partitions':original_parts,
        'diagnostic_count':len(parts),'diagnostic_partitions':parts}
    predictors=k.predictor_contract(Path(k.__file__).parent)
    center_recipes=k._compile_transform_recipes({'predictors':predictors},registered,
        [p['partition_id'] for p in parts],destination,Path(k.__file__).parent,expected_count=5)
    return registered,center_recipes,current_p2c2t_row(current,parts,center_recipes)

def _a04_p2_binding(job, source, contract_task):
    # Only original physical input paths and outer scheduler width may change.
    # Scientific patient/member/response/recipe/seed/MI parameters stay bound.
    spec={key:value for key,value in job['spec'].items() if key not in ('pool_workers','threads')}
    fit={key:value for key,value in job['fit_task'].items() if key not in ('spec','registered')}
    part=k._registered_partition_identity_record(job['evaluation_partition'])
    return _sealed({'kind':'PADML_A04_CURRENT_P2_ATOMIC_INPUT_V1','source':source,
        'contract_task_sha256':sha(contract_task),'route':job['route'],
        'top_task_id':job['top_task_id'],'atomic_task_id':job['atomic_task_id'],
        'spec':spec,'fit_task':fit,'partition':part})

def _a04_p2_read(job, binding, path, generations):
    from padml.bundle import strict_json_bytes
    from padml.f4 import _evaluation_check_producer
    raw=Path(path).read_bytes();value=strict_json_bytes(raw)
    require(raw==canonical_json_bytes(value) and value['kind']=='PADML_A04_CURRENT_P2_ATOMIC_NUMBERS_V1'
        and value['input']==binding and value['identity_sha256']==sha({a:b for a,b in value.items() if a!='identity_sha256'}),
        'A04_CURRENT_P2_ATOMIC_NUMBERS_DRIFT')
    _evaluation_check_producer(value,generations)
    k._validate_p2c2t_atomic_result(job,value['row'])
    actual=value['row']['evaluated'];part=job['evaluation_partition'];sealed=actual['sealed_prediction']
    require(sealed==k._seal_prediction_matrix(part['evaluation_ids'],sealed['payload']['survival'],list(range(1,37)))
        and actual['prediction_seal_sha256']==sealed['sha256']
        and actual['evaluation_ids_sha256']==part['evaluation_ids_sha256']
        and actual['evaluation_response_sha256']==part['evaluation_response']['sha256'],
        'A04_CURRENT_P2_ATOMIC_POPULATION_DRIFT')
    # First publication and changed-file qualification use the original metric.
    # A task-level qualified_file_pins receipt below avoids repeating this path.
    import math
    metric=k._evaluate_prediction_seal(k._monthly_prediction_seal(sealed),
        fit_response=part['fit_response'],evaluation_response=part['evaluation_response'])
    require(math.isclose(metric['ibs_0_24'],actual['ibs_0_24'],rel_tol=1e-12,abs_tol=1e-12),
        'A04_CURRENT_P2_ATOMIC_EVALUATION_DRIFT')
    if job['fit_task'].get('family')=='FPM_TVC_SET_A': k._validate_retained_fpm_health(actual,job['spec'])
    return value['row']

def _a04_p2_atomic_job(job, *, source, contract_task, retained_root, provenance):
    from padml.bundle import strict_json_bytes,sha256_file
    from padml.f5_sensitivity import _retire_a12_member_copies
    directory=Path(retained_root);key=sha(job['atomic_task_id'])
    target=directory/(key+'.json');input_path=directory/(key+'-input.json')
    binding=_a04_p2_binding(job,source,contract_task)
    if target.exists(): return _a04_p2_read(job,binding,target,provenance['generations'])
    native=Path(job['scratch'])/f"f2-r-batch-{sha([job['atomic_task_id']])[:16]}"
    legacy=directory/(key+'.zip')
    if legacy.is_file():
        require(job['route']=='R' and job['fit_task']['family']=='FPM_TVC_SET_A',
            'A04_CURRENT_P2_NATIVE_FORMAT_DRIFT')
        row=k._replay_p2c2t_fpm_artifact(job,legacy)
    elif native.exists():
        require(job['route']=='R' and (native/'spec.json').is_file() and (native/'output.json').is_file(),
            'A04_CURRENT_PARTIAL_P2_NATIVE_REQUIRES_RECOVERY')
        if input_path.exists():
            require(strict_json_bytes(input_path.read_bytes())==binding,'A04_CURRENT_P2_INPUT_DRIFT')
        task=job['fit_task'];recipe=task.get('transform_recipe')
        expected={**job['spec'],'action':'MODEL_PREDICTION_BATCH','threads':1,'pool_workers':1,'engine_threads':1,
            'registered_partitions':job['registered'],'transform_recipe':recipe,
            'producer_tasks':[{a:b for a,b in task.items() if a!='transform_recipe'}]}
        require(k._fpm_reuse_spec(strict_json_bytes((native/'spec.json').read_bytes()))==k._fpm_reuse_spec(expected),
                'A04_CURRENT_P2_NATIVE_INPUT_DRIFT')
        evaluated,=k._consume_r_prediction(strict_json_bytes((native/'output.json').read_bytes()),job['spec'],
            job['registered'],[task],native,'IBS',job['evaluation_partition'],cleanup=False)
        body={'top_task_id':job['top_task_id'],'atomic_task_id':job['atomic_task_id'],'evaluated':evaluated}
        row={**body,'task_identity_sha256':sha(body)}
    else:
        require(not input_path.exists(),'A04_CURRENT_PARTIAL_P2_NATIVE_REQUIRES_RECOVERY')
        n._write_exact_once(input_path,canonical_json_bytes(binding),'A04_CURRENT_P2_INPUT_DRIFT')
        if job['route']=='R':
            evaluated,=k._run_r_prediction_partition_batch(job['spec'],job['registered'],[job['fit_task']],
                Path(job['scratch']),Path(job['repo_root']),evaluation_mode='IBS',
                evaluation_partition=job['evaluation_partition'],preserve_native=True)
            body={'top_task_id':job['top_task_id'],'atomic_task_id':job['atomic_task_id'],'evaluated':evaluated}
            row={**body,'task_identity_sha256':sha(body)}
        else:
            row=k._run_p2c2t_atomic_pool_task(job)
    k._validate_p2c2t_atomic_result(job,row)
    numbers=_sealed({'kind':'PADML_A04_CURRENT_P2_ATOMIC_NUMBERS_V1','input':binding,
        'producer':provenance['producer'],'row':row})
    n._write_exact_once(target,canonical_json_bytes(numbers),'A04_CURRENT_P2_ATOMIC_PUBLICATION_DRIFT')
    actual=_a04_p2_read(job,binding,target,provenance['generations'])
    if job['route']=='R' and job['fit_task']['family']!='FPM_TVC_SET_A':
        pins={path:{'sha256':sha256_file(path),'size_bytes':path.stat().st_size}
              for path in (native/'spec.json',native/'output.json') if path.is_file()}
        _retire_a12_member_copies(Path(job['scratch']),pins)
        try: native.rmdir()
        except FileNotFoundError: pass
    return actual

def _a04_p2_consumed_member_pins(plan, folder, retained_root):
    """Original plan's last-consumed physical members, in the existing top header."""
    from padml.bundle import sha256_file
    pins={}
    for job in plan['jobs']:
        key=sha(job['atomic_task_id'])
        paths=[Path(retained_root)/(key+suffix) for suffix in ('.json','-input.json','.zip')]
        if job['route']=='R':
            native=Path(job['scratch'])/f"f2-r-batch-{sha([job['atomic_task_id']])[:16]}"
            paths.extend(native/member for member in ('spec.json','output.json'))
        for path in paths:
            if not path.exists() and not path.is_symlink(): continue
            require(path.is_file() and not path.is_symlink(),'A04_CURRENT_P2_RETIREMENT_PATH_INVALID')
            pins[path.relative_to(folder).as_posix()]={'sha256':sha256_file(path),'size_bytes':path.stat().st_size}
    return pins


def _a04_p2_retire_consumed(folder, saved):
    """Completed top rows resume precise retirement without rebuilding inputs."""
    import errno,re
    from padml.bundle import validate_relative_path,validate_sha256
    from padml.f5_sensitivity import _retire_a12_member_copies
    folder=Path(folder);key=sha(saved['contract_task'])
    # A pre-amendment completed header without residue needs no migration.
    pins=saved.get('consumed_member_pins')
    if pins is None:
        require(all(not p.exists() or p.is_dir() and not p.is_symlink() and not any(p.iterdir())
            for p in (folder/key,folder/(key+'-native'))),'A04_CURRENT_P2_RETIREMENT_PROOF_MISSING')
        return 0
    require(isinstance(pins,dict) and len(pins)<=5*saved['value']['executed_fit_count'],
        'A04_CURRENT_P2_RETIREMENT_SCOPE_INVALID')
    members={}
    for name,pin in pins.items():
        parts=Path(validate_relative_path(name,'a04.p2.retirement')).parts
        legal=(len(parts)==2 and parts[0]==key+'-native'
            and re.fullmatch(r'[0-9a-f]{64}(?:-input)?\.json|[0-9a-f]{64}\.zip',parts[1]) is not None
            or len(parts)==3 and parts[0]==key
            and re.fullmatch(r'f2-r-batch-[0-9a-f]{16}',parts[1]) is not None
            and parts[2] in {'spec.json','output.json'})
        require(legal and isinstance(pin,dict) and set(pin)=={'sha256','size_bytes'}
            and type(pin['size_bytes']) is int and pin['size_bytes']>=0,
            'A04_CURRENT_P2_RETIREMENT_SCOPE_INVALID')
        validate_sha256(pin['sha256'],'a04.p2.retirement.sha256')
        members[folder/name]=pin
    released=_retire_a12_member_copies(folder,members)
    for path in (folder/key,folder/(key+'-native')):
        if path.is_symlink(): raise ContractError('A04_CURRENT_P2_RETIREMENT_PATH_INVALID')
        try: path.rmdir()
        except OSError as error:
            if error.errno not in {errno.ENOENT,errno.ENOTEMPTY}: raise
    return released

def _a04_p2_completed(current, root):
    """Small published top rows first; no CSV/recipe preparation on a hit."""
    from padml.bundle import strict_json_bytes
    from padml.f4 import _evaluation_provenance,_evaluation_check_producer
    provenance=_evaluation_provenance(current['run']);answer={}
    for component in k.F2_COMPONENTS:
        folder=Path(root)/component;path=folder/'registry.json'
        if not path.is_file(): return None
        registry=strict_json_bytes(path.read_bytes())
        require(registry.get('kind')=='PADML_A04_CURRENT_PRIMARY_P2C2T_REGISTRY_V1'
            and registry['source_locks']==[current['source']]
            and registry['registry_sha256']==sha({a:b for a,b in registry.items() if a!='registry_sha256'}),
            'A04_CURRENT_REGISTRY_DRIFT')
        values=[]
        for task in registry['tasks']:
            path=folder/(sha(task)+'.json')
            if not path.is_file(): return None
            saved=strict_json_bytes(path.read_bytes());_evaluation_check_producer(saved,provenance['generations'])
            require(saved['identity_sha256']==sha({a:b for a,b in saved.items() if a!='identity_sha256'})
                and saved['source']==current['source'] and saved['contract_task']==task
                and saved['value']['task_contract_sha256']==sha(task)
                and saved['value']['executed_fit_count']==saved['value']['expected_fit_count']
                and saved['value']['status']=='PASS','A04_CURRENT_P2C2T_RESULT_DRIFT')
            _a04_p2_retire_consumed(folder,saved)
            values.append(saved['value'])
        answer[component]={'registry':registry,'task_results':values,
            'expected_fit_count':sum(v['expected_fit_count'] for v in values),
            'executed_fit_count':sum(v['executed_fit_count'] for v in values)}
    return answer

def execute_current_p2c2t(current, root):
    """One PRIMARY's finite registry -> original native window -> original reducer.

    Complete top rows return before preparation. Completed atomic numerical
    records or original FPM ZIPs replay without fitting; incomplete native
    objects stop unchanged. Only genuinely unstarted coordinates may fit.
    """
    import tempfile,shutil
    from padml._science_authority import load_science_authority
    from padml.bundle import strict_json_bytes
    from padml.f2 import compile_f2_units
    from padml import f5_mice_variants as v
    from padml.runtime import admit_stage,observe_execution_resources,resource_admission
    root=Path(root);root.mkdir(mode=0o700,parents=True,exist_ok=True)
    n._write_exact_once(root/'input.json',canonical_json_bytes(current['source']),'A04_CURRENT_SOURCE_DRIFT')
    run=current['run'];policy=run['resource_policy'];budgets=run['budgets']
    science=load_science_authority()['science'];contract=science['f2_model_development']['p2c2t_contract']
    predictions=k.predictor_contract(Path(k.__file__).parent)
    native_units={component:unit for component,unit in zip(k.F2_COMPONENTS,compile_f2_units()[42:45],strict=True)}
    completed=_a04_p2_completed(current,root)
    if completed is not None: return completed,0
    result={};actual_new_fits=0
    from padml.f4 import _evaluation_provenance,_evaluation_check_producer
    provenance=_evaluation_provenance(run)
    # Reserve preparation before the first completed-view CSV is expanded.
    admit_stage(policy,root,legal_tasks=1,retained_bytes=budgets['retained_bytes_per_view'],
        transient_bytes_per_worker=budgets['retained_bytes_per_view'],publication_bytes=0,
        memory_bytes_per_worker=policy['memory_bytes_per_worker'])
    with tempfile.TemporaryDirectory(prefix='assets-',dir=root) as temporary:
        work=Path(temporary);original_root=work/'original'
        v._original_outer(current['frozen'],current_layout(current,current['lock']['outer_fold']),original_root)
        # Recipe compilation/CSV projection is one already-admitted producer;
        # model fitting remains only in the registered native process pool.
        registered,center_recipes,model=prepare_current_center_assets(current,original_root,work/'centers')
        for component in k.F2_COMPONENTS:
            folder=root/component;folder.mkdir(mode=0o700,exist_ok=True)
            registry=k.compile_p2c2t_registry(component,[model],{'seed':native_units[component]['seed']},
                contract,science['f2_model_development']['coxtime'],current_lock_scope=True)
            n._write_exact_once(folder/'registry.json',canonical_json_bytes(registry),'A04_CURRENT_REGISTRY_DRIFT')
            task_results=[]
            for value in registry['tasks']:
                task={**value,'component':component};key=sha(value);target=folder/(key+'.json')
                scratch=folder/key
                saved=strict_json_bytes(target.read_bytes()) if target.is_file() else None
                if saved is not None:
                    _evaluation_check_producer(saved,provenance['generations'])
                    require(saved.get('identity_sha256')==sha({a:b for a,b in saved.items() if a!='identity_sha256'})
                        and saved['source']==current['source'] and saved['contract_task']==value
                        and saved['value']['task_contract_sha256']==sha(value)
                        and saved['value']['status']=='PASS'
                        and saved['value']['executed_fit_count']==saved['value']['expected_fit_count'],
                        'A04_CURRENT_P2C2T_RESULT_DRIFT')
                    _a04_p2_retire_consumed(folder,saved)
                    task_results.append(saved['value'])
                    continue
                require(not scratch.is_symlink(),'A04_CURRENT_P2_SCRATCH_INVALID')
                scratch.mkdir(mode=0o700,exist_ok=True);execution_root=scratch
                execution_registered=registered
                if component=='LOCKED_MODEL_SAMPLE_SIZE_DIAGNOSTIC':
                    sample,=[r for r in current['frozen']['registry']['sample_size']
                        if r['outer_fold']==task['fold'] and r['seed_ordinal']==task['seed_ordinal']
                        and r['fraction']==task['sample_fraction']]
                    # Original OUTER has prediction-only registration. Supply
                    # only its explicitly held-out evaluation response here.
                    outer,=[p for p in registered['partitions'] if p['kind']=='OUTER']
                    fields,response=k._response_rows(current['frozen']['response_csv'])
                    outer={**outer,'evaluation_response':k._write_response_subset(fields,response,outer['evaluation_ids'],None)}
                    execution_registered=k._p2c2t_sample_registered_partition({**registered,'partitions':[outer]},
                        sample_ids=sample['sample_ids'],response_csv=current['frozen']['response_csv'],
                        task=value,destination=work/(component+'-'+key+'-sample-partition'))
                    # Original sample adapter predates fit-member identity rows.
                    # Compute these once per 20-MI top task, not in each child.
                    for part in execution_registered['partitions']:
                        part['fit_covariate_members']=k._fit_covariate_member_records(part['covariates'],part['fit_ids'])
                slots=(saved['value']['pool_workers'] if saved is not None else
                    resource_admission(policy,observe_execution_resources(root),legal_tasks=100)['admitted_worker_ceiling'])
                profiles=k.selected_route_profiles(pool_workers=slots)
                arguments={'task':task,'contract_task':value,'model':model,'registered':execution_registered,
                    'science':science,'predictors':predictions,'scratch':execution_root,'repo_root':Path(k.__file__).parent,
                    'route_record':profiles[k._FAMILY_ROUTE_KEYS[task['family']]],
                    'center_recipe_set':center_recipes if component=='CENTER_BLOCKED_STRESS' else None,
                    'pool_workers':slots}
                if saved is None:
                    plan=k._p2c2t_registered_task_result(**arguments,atomic_job_plan=True)
                    plan=bind_current_atomic_plan(plan,model,task)
                    estimate=budgets['retained_bytes_per_component']
                    memory=max(policy['memory_bytes_per_worker'],32*max(
                        job['evaluation_partition']['covariates']['members'][job['fit_task']['imputation']-1]['size_bytes']
                        +job['evaluation_partition']['fit_response']['size_bytes']
                        +job['evaluation_partition']['evaluation_response']['size_bytes']
                        for job in plan['jobs']))
                    from padml.runtime import run_ready_families
                    retained_root=folder/(key+'-native');retained_root.mkdir(mode=0o700,exist_ok=True)
                    from functools import partial
                    atom=partial(_a04_p2_atomic_job,source=current['source'],contract_task=value,
                        retained_root=str(retained_root),provenance=provenance)
                    retained_rows={}
                    for job in plan['jobs']:
                        path=retained_root/(sha(job['atomic_task_id'])+'.json')
                        if path.is_file():
                            retained_rows[job['atomic_task_id']]=_a04_p2_read(job,
                                _a04_p2_binding(job,current['source'],value),path,provenance['generations'])
                    def native_window():
                        admit_stage(policy,root,legal_tasks=len(plan['jobs']),
                            retained_bytes=estimate*len(plan['jobs']),publication_bytes=estimate,
                            transient_bytes_per_worker=3*estimate,memory_bytes_per_worker=memory)
                        return k._run_p2c2t_atomic_window([plan],retained_root=retained_root,
                            retained_rows=retained_rows,atomic_worker=atom)
                    # _bounded_ordered_spawn inside the old window uses this
                    # SAME ReadyPool, not a nested scientific pool.
                    retained_atomic=sum(job['atomic_task_id'] in retained_rows or
                        (retained_root/(sha(job['atomic_task_id'])+'.zip')).is_file() or
                        (Path(job['scratch'])/f"f2-r-batch-{sha([job['atomic_task_id']])[:16]}"/'output.json').is_file()
                        for job in plan['jobs'])
                    complete_atomic=all(job['atomic_task_id'] in retained_rows or
                        (retained_root/(sha(job['atomic_task_id'])+'.zip')).exists() or
                        (retained_root/(sha(job['atomic_task_id'])+'.zip')).is_symlink()
                        for job in plan['jobs'])
                    if complete_atomic:
                        # The final atom can be durable before its top-level
                        # reduction. The original consumer still validates all
                        # rows/ZIPs, but there is no missing task to submit.
                        evaluated,=k._run_p2c2t_atomic_window([plan],retained_root=retained_root,
                            retained_rows=retained_rows,atomic_worker=atom)
                    else:
                        evaluated,=run_ready_families([native_window],policy=policy,root=root,workers=slots)[0]
                    actual_new_fits+=len(plan['jobs'])-retained_atomic
                else:
                    raise ContractError('A04_CURRENT_UNREACHABLE_SAVED_TASK')
                reduced=k._p2c2t_registered_task_result(**arguments,evaluated_override=evaluated)
                if saved is not None:
                    require(reduced==saved['value'],'A04_CURRENT_P2C2T_REDUCTION_DRIFT')
                else:
                    saved=_sealed({'kind':'PADML_A04_CURRENT_P2C2T_NUMBERS_V1','source':current['source'],
                        'producer':provenance['producer'],'contract_task':value,'value':reduced,
                        'consumed_member_pins':_a04_p2_consumed_member_pins(plan,folder,retained_root)})
                    n._write_exact_once(target,canonical_json_bytes(saved),'A04_CURRENT_P2C2T_PUBLICATION_DRIFT')
                    actual=strict_json_bytes(target.read_bytes())
                    require(actual==saved,'A04_CURRENT_P2C2T_PUBLISHED_DRIFT')
                    # The same header resumes retirement if publication was
                    # followed by interruption; deleted members are permitted.
                    _a04_p2_retire_consumed(folder,saved)
                task_results.append(reduced)
            require([r['task_id'] for r in task_results]==[r['task_id'] for r in registry['tasks']],
                    'A04_CURRENT_P2C2T_TASK_COVERAGE_INVALID')
            result[component]={'registry':registry,'task_results':task_results,
                'expected_fit_count':sum(r['expected_fit_count'] for r in task_results),
                'executed_fit_count':sum(r['executed_fit_count'] for r in task_results)}
    return result,actual_new_fits

def execute_current_scope(run, unit, unit_root, appendage_root):
    """Call only inside this PRIMARY's existing repair owner; no other units read.

    The enclosing repair receipt must pin these existing component leaves and
    actual executor provenance. This return is not an application/diagnostic gate.
    """
    current=load_current_primary(run,unit,unit_root)
    root=Path(appendage_root)
    predictions=execute_current_variants_and_negative(current,root/'mice-controls')
    p2c2t,p2_new=execute_current_p2c2t(current,root/'p2c2t')
    return {'kind':'PADML_A04_CURRENT_PRIMARY_SCOPE_NUMBERS_V1','source':current['source'],
        'development_lock':current['lock'],'selected_prediction':current['selected_prediction'],
        'variants':predictions['variants'],'negative':predictions['negative'],'p2c2t':p2c2t,
        'execution_status':'REQUIRED_NATIVE_LEAVES_CONSUMED',
        'diagnostic_pass_status':'PENDING_SIX_OUTER_METRIC_REDUCTION',
        'stage_acceptance':False,'resource_policy':run['resource_policy'],
        'budgets':run['budgets'],
        'actual_new_this_invocation':{**predictions['actual_new_this_invocation'],
            'model_fits':predictions['actual_new_this_invocation']['model_fits']+p2_new},
        'logical_upper_bound':{'variant_negative_model_fits':63,'variant_negative_chain_starts':126,
            'p2c2t_model_fits':sum(v['expected_fit_count'] for v in p2c2t.values())},'scope_coverage':{'expected_primary_scopes':24,'present_primary_scopes':1}}


def current_a04_handoffs(scopes, *, horizons=(6,12,24,36)):
    """Final24 coverage from already-qualified small scope results, without fits.

    Return per-line handoffs to existing evaluate_predictions and the original
    A04 native metric validator. Different outer winners remain explicit.
    Neither a global family lock nor old42-model acceptance is manufactured.
    """
    from padml.f5_mice_variants import A04_NEW_MICE_VARIANTS
    from padml.f5_negative_controls import BRANCH
    require(tuple(horizons) in ((6,),(12,),(24,),(36,),(6,12,24,36)), 'A04_CURRENT_HORIZON_SCOPE_INVALID')
    expected={(h,o) for h in horizons for o in range(1,7)}
    require(len(scopes)==len(expected),'A04_CURRENT_24_LOCKS_REQUIRED' if len(horizons)==4 else 'A04_CURRENT_SIX_LOCKS_REQUIRED')
    coordinates=[(r['source']['selection_horizon_months'],r['development_lock']['outer_fold']) for r in scopes]
    require(len(set(coordinates))==len(coordinates) and set(coordinates)==expected,'A04_CURRENT_SCOPE_COVERAGE_INVALID')
    by_coordinate=dict(zip(coordinates,scopes,strict=True));lines={}
    for h in horizons:
        ids=[];centers=[];variants={'LOG_DONOR5':[],**{v:[] for v in A04_NEW_MICE_VARIANTS}}
        negatives=[[] for _ in range(3)];responses=[{} for _ in range(3)];sources=[]
        for outer in range(1,7):
            row=by_coordinate[h,outer];source=row['source'];lock=n.validate_development_lock(row['development_lock'])
            prediction=n.validate_selected_prediction(row['selected_prediction'],lock)
            require(row['kind']=='PADML_A04_CURRENT_PRIMARY_SCOPE_NUMBERS_V1'
                and source['identity_sha256']==sha({a:b for a,b in source.items() if a!='identity_sha256'})
                and source['unit_id']==f'PRIMARY-H{h:02d}-O{outer}'
                and source['development_lock_sha256']==lock['identity_sha256']
                and row['execution_status']=='REQUIRED_NATIVE_LEAVES_CONSUMED'
                and row['variants']['source']==row['negative']['source']==source
                and row['variants']['family']==row['negative']['family']==lock['selected_family']
                and row['variants']['outer_fold']==row['negative']['outer_fold']==outer,
                'A04_CURRENT_SCOPE_NUMBERS_SOURCE_DRIFT')
            v=row['variants']['predictions'];negative=row['negative']
            require(v['patient_ids']==prediction['patient_ids'] and v['centers']==prediction['centers']
                and v['horizons']==prediction['horizons'] and len(negative['predictions'])==len(negative['permutations'])==3
                and not set(ids).intersection(prediction['patient_ids']), 'A04_CURRENT_SCOPE_POPULATION_DRIFT')
            ids.extend(prediction['patient_ids']);centers.extend(prediction['centers'])
            variants['LOG_DONOR5'].extend(prediction['survival'])
            for name in A04_NEW_MICE_VARIANTS: variants[name].extend(v['survival'][name])
            for i,(p,permutation) in enumerate(zip(negative['predictions'],negative['permutations'],strict=True)):
                require(p['patient_ids']==prediction['patient_ids'] and p['centers']==prediction['centers']
                    and p['horizons']==prediction['horizons'] and permutation['permutation_index']==i+1
                    and [v['Patient_ID'] for v in permutation['evaluation_response']]==prediction['patient_ids'],
                    'A04_CURRENT_NEGATIVE_POPULATION_DRIFT')
                negatives[i].extend(p['survival']);responses[i].update({v['Patient_ID']:v for v in permutation['evaluation_response']})
            for component,values in row['p2c2t'].items():
                registry=values['registry'];tasks=values['task_results']
                require(component in k.F2_COMPONENTS and registry['source_locks']==[source]
                    and registry['registry_sha256']==sha({a:b for a,b in registry.items() if a!='registry_sha256'})
                    and [v['task_id'] for v in tasks]==[v['task_id'] for v in registry['tasks']]
                    and all(v['status']=='PASS' and v['task_contract_sha256']==sha(t)
                        and v['executed_fit_count']==v['expected_fit_count']
                        for v,t in zip(tasks,registry['tasks'],strict=True)), 'A04_CURRENT_P2C2T_SCOPE_INCOMPLETE')
            require(set(row['p2c2t'])==set(k.F2_COMPONENTS),'A04_CURRENT_P2C2T_SCOPE_INCOMPLETE')
            sources.append({'source':source,'selected_family':lock['selected_family'],
                'parameters_by_imputation_sha256':sha(lock['parameters_by_imputation'])})
        require(set(centers)=={'36','38','39','48','52','54'},'A04_CURRENT_SIX_CENTERS_REQUIRED')
        for matrix in [*variants.values(),*negatives]: k._seal_prediction_matrix(ids,matrix,list(n.HORIZONS))
        lines[h]={'sources':sources,'variants':{'patient_ids':ids,'centers':centers,
            'horizons':list(n.HORIZONS),'survival':variants},'negative':[
            ({'patient_ids':ids,'centers':centers,'horizons':list(n.HORIZONS),'survival':{BRANCH:matrix}},
             k._write_response_subset(['Patient_ID','All_Cause_Death','Death_Followup_months'],response,ids,None)['private_bytes'])
            for matrix,response in zip(negatives,responses,strict=True)]}
    return lines

def _current_a04_projection(current, predictions, p2c2t):
    # No formal references or native model paths enter this transferable value.
    def common(value):
        return {key:value[key] for key in ('source','family','outer_fold','predictions')}
    negative=common(predictions['negative'])
    negative['permutations']=[{key:r[key] for key in ('permutation_index','evaluation_response')}
                             for r in predictions['negative']['permutations']]
    return {'kind':'PADML_A04_CURRENT_PRIMARY_SCOPE_NUMBERS_V1','source':current['source'],
        'development_lock':current['lock'],'selected_prediction':current['selected_prediction'],
        'variants':common(predictions['variants']),'negative':negative,'p2c2t':p2c2t,
        'execution_status':'REQUIRED_NATIVE_LEAVES_CONSUMED'}

def read_current_a04_evaluation(path, run, unit, *, source_result=None):
    """Original-owner sender may pass its head; remote EVAL consumes only numbers."""
    from padml.bundle import strict_json_bytes,validate_sha256
    from padml.carriers import source_bytes
    from padml.f4 import _evaluation_provenance,_evaluation_check_producer
    raw=source_bytes(Path(path),limit=64*1024**2);value=strict_json_bytes(raw)
    generations=_evaluation_provenance(run)['generations'];_evaluation_check_producer(value,generations)
    require(unit['kind']=='PRIMARY' and canonical_json_bytes(value)==raw
        and set(value)=={'kind','producer','decision_sha256','target_unit','source','source_result_identity',
            'source_result_pin','numeric_projection_sha256','numeric_projection','identity_sha256'}
        and value['kind']=='PADML_CURRENT_PRIMARY_A04_EVALUATION_V1'
        and value['identity_sha256']==sha({a:b for a,b in value.items() if a!='identity_sha256'})
        and value['decision_sha256']==run['post_result_repair']['identity_sha256']
        and value['target_unit']==unit['unit_id'] and value['source']['unit_id']==unit['unit_id'],
        'A04_CURRENT_EVALUATION_SOURCE_DRIFT')
    validate_sha256(value['source_result_identity'],'a04.source_result_identity')
    pin=value['source_result_pin'];validate_sha256(pin['sha256'],'a04.source_result_pin.sha256')
    require(set(pin)=={'sha256','size_bytes'} and type(pin['size_bytes']) is int and 0<pin['size_bytes']<=8*1024**2,
        'A04_CURRENT_EVALUATION_RESULT_PIN_INVALID')
    projection=value['numeric_projection'];source=projection['source']
    lock=n.validate_development_lock(projection['development_lock'])
    n.validate_selected_prediction(projection['selected_prediction'],lock)
    require(set(projection)=={'kind','source','development_lock','selected_prediction','variants','negative',
            'p2c2t','execution_status'} and projection['kind']=='PADML_A04_CURRENT_PRIMARY_SCOPE_NUMBERS_V1'
        and projection['execution_status']=='REQUIRED_NATIVE_LEAVES_CONSUMED'
        and value['numeric_projection_sha256']==sha(projection) and source==value['source']
        and source['identity_sha256']==sha({a:b for a,b in source.items() if a!='identity_sha256'})
        and generations.get(source['producer_run_identity'])==source['producer_source_identity']
        and source['development_lock_sha256']==lock['identity_sha256']
        and (lock['selection_horizon_months'],lock['outer_fold'])==(unit['horizon'],unit['outer_fold'])
        and source['selection_horizon_months']==unit['horizon'], 'A04_CURRENT_EVALUATION_NUMBERS_DRIFT')
    if source_result is not None:
        result=source_result
        require(result['identity_sha256']==sha({a:b for a,b in result.items() if a!='identity_sha256'})
            and result['identity_sha256']==value['source_result_identity']
            and result['producer']==value['producer'] and result['source']==source
            and result['target_unit']==unit['unit_id'] and result['status']=='COMPLETED'
            and result['direct_consumer_completed'] is True
            and result['evaluation_payload_sha256']==value['numeric_projection_sha256']
            and result['decision_sha256']==value['decision_sha256']
            and pin=={'sha256':sha256_bytes(canonical_json_bytes(result)),
                     'size_bytes':len(canonical_json_bytes(result))}, 'A04_CURRENT_EVALUATION_RESULT_DRIFT')
    return projection

def _publish_current_a04(folder, result, projection, run, unit):
    """Two-way identity without a cycle; one existing atomic publication stage."""
    import os
    pending=folder/'.result.json.pending';target=folder/'result.json'
    raw=canonical_json_bytes(result)
    require(result['evaluation_payload_sha256']==sha(projection),'A04_CURRENT_EVALUATION_PAYLOAD_DRIFT')
    n._write_exact_once(pending,raw,'A04_CURRENT_RESULT_PENDING_DRIFT')
    value=_sealed({'kind':'PADML_CURRENT_PRIMARY_A04_EVALUATION_V1','producer':result['producer'],
        'decision_sha256':result['decision_sha256'],'target_unit':result['target_unit'],'source':result['source'],
        'source_result_identity':result['identity_sha256'],
        'source_result_pin':{'sha256':sha256_bytes(raw),'size_bytes':len(raw)},
        'numeric_projection_sha256':sha(projection),'numeric_projection':projection})
    n._write_exact_once(folder/'evaluation.json',canonical_json_bytes(value),'A04_CURRENT_EVALUATION_PUBLICATION_DRIFT')
    read_current_a04_evaluation(folder/'evaluation.json',run,unit,source_result=result)
    if target.exists():
        require(target.read_bytes()==raw,'A04_CURRENT_RESULT_PUBLICATION_DRIFT')
        pending.unlink()
    else:
        os.replace(pending,target)
    descriptor=os.open(folder,os.O_RDONLY)
    try: os.fsync(descriptor)
    finally: os.close(descriptor)
    return result

def run_current_a04(run, unit, root):
    """Existing run_post_result_repair PRIMARY tail; completion != review pass."""
    from padml.f4 import post_result_repair_decision,_evaluation_provenance,_evaluation_check_producer
    from padml.bundle import strict_json_bytes
    from padml.carriers import file_reference,validate_reference
    require(unit['kind']=='PRIMARY' and run.get('post_result_repair')==post_result_repair_decision(),
            'A04_CURRENT_NOT_AUTHORIZED')
    root=Path(root);folder=root/'post-result-repair-20261008/a04'
    folder.mkdir(mode=0o700,parents=True,exist_ok=True);target=folder/'result.json'
    decision=run['post_result_repair']['identity_sha256'];provenance=_evaluation_provenance(run)
    current=load_current_primary(run,unit,root)
    def check_head(value):
        _evaluation_check_producer(value,provenance['generations'])
        require(value.get('kind')=='PADML_CURRENT_PRIMARY_A04_RESULT_V1' and value['status']=='COMPLETED'
            and value['identity_sha256']==sha({a:b for a,b in value.items() if a!='identity_sha256'})
            and value['direct_consumer_completed'] is True and value['source']==current['source']
            and value['target_unit']==unit['unit_id'] and value['decision_sha256']==decision
            and value['review_status']=='PENDING_GLOBAL_24_SCOPE_REVIEW', 'A04_CURRENT_RESULT_DRIFT')
        for reference in value['formal_references']: validate_reference(reference,run)
        return value
    if target.is_file():
        value=check_head(strict_json_bytes(target.read_bytes()))
        read_current_a04_evaluation(folder/'evaluation.json',run,unit,source_result=value)
        return value
    pending=folder/'.result.json.pending'
    if pending.is_file():
        # Publication retry reads only original small consumed numerical leaves.
        from padml.f5_mice_variants import _audit_json
        value=check_head(strict_json_bytes(pending.read_bytes()))
        predictions={branch:_audit_json(folder/'mice-controls'/(branch+'.zip'),header)[0]
            for branch,header in (('variants','variant-outer.json'),('negative','negative-outer.json'))}
        p2=_a04_p2_completed(current,folder/'p2c2t')
        require(p2 is not None,'A04_CURRENT_PENDING_NUMERICAL_CLOSURE_MISSING')
        return _publish_current_a04(folder,value,_current_a04_projection(current,predictions,p2),run,unit)
    predictions=execute_current_variants_and_negative(current,folder/'mice-controls')
    p2c2t,p2_new=execute_current_p2c2t(current,folder/'p2c2t')
    projection=_current_a04_projection(current,predictions,p2c2t)
    references=[file_reference(folder/'mice-controls'/f'{name}.zip','A04_CURRENT_NUMERICAL_COMPONENT',run)
                for name in ('variants','negative')]
    components={}
    for component,body in p2c2t.items():
        parent=folder/'p2c2t'/component
        references.append(file_reference(parent/'registry.json','A04_CURRENT_REGISTERED_SCOPE',run))
        names=[]
        for task in body['registry']['tasks']:
            name=sha(task)+'.json';names.append(name)
            references.append(file_reference(parent/name,'A04_CURRENT_CONSUMED_NUMERICAL_TASK',run))
        components[component]={'registry_identity':body['registry']['registry_sha256'],
            'task_count':len(body['task_results']),'expected_fit_count':body['expected_fit_count'],
            'qualified_fit_coordinate_count':body['executed_fit_count'],'task_members':names}
    value=_sealed({'kind':'PADML_CURRENT_PRIMARY_A04_RESULT_V1','target_unit':unit['unit_id'],
        'decision_sha256':decision,'producer':provenance['producer'],'source':current['source'],
        'status':'COMPLETED','direct_consumer_completed':True,'review_status':'PENDING_GLOBAL_24_SCOPE_REVIEW',
        'stage_acceptance':False,'selection_effect':'NONE','development_lock':current['lock'],
        'selected_prediction':current['selected_prediction'],'p2c2t':components,
        'evaluation_payload_sha256':sha(projection),
        'formal_references':references,'resource_policy':run['resource_policy'],'budgets':run['budgets'],
        'actual_new_this_invocation':{**predictions['actual_new_this_invocation'],
            'model_fits':predictions['actual_new_this_invocation']['model_fits']+p2_new},
        'logical_upper_bound':{'variant_negative_model_fits':63,'variant_negative_chain_starts':126,
            'p2c2t_model_fits':sum(v['expected_fit_count'] for v in p2c2t.values())}})
    return _publish_current_a04(folder,value,projection,run,unit)

def run_current_a04_line(run, unit, root):
    """Consume this line's six current PRIMARY projections; never fit a model.

    A04 keeps its original fixed 24-month metric/NA/negative-control rules.
    The development horizon labels the independently locked source policy;
    it is not a replacement A04 scoring horizon or a global family lock.
    """
    from pathlib import Path
    from padml import nested_loco as nested
    from padml.bundle import canonical_json_bytes, strict_json_bytes, sha256_bytes
    from padml.carriers import file_reference, source_bytes, validate_reference
    from padml.integrated import load_raw_binding, same_batch_generations
    from padml.f4 import (post_result_repair_decision, _evaluation_provenance,
        _evaluation_check_producer, evaluate_predictions, _require)
    from padml.f5_sensitivity import _validate_a12_native_evaluation
    from padml.f5_negative_controls import _negative_evaluation_summary
    from padml.f5_mice_variants import VARIANTS

    base, root = Path(run['run_root']), Path(root)
    _require(unit['kind'] == 'EVALUATION' and unit['horizon'] in (6,12,24,36)
        and unit['unit_id'] == f"EVALUATION-H{unit['horizon']:02d}"
        and root == base/'units'/unit['unit_id']
        and run.get('post_result_repair') == post_result_repair_decision(),
        'A04_CURRENT_LINE_NOT_AUTHORIZED')
    folder = root/'post-result-repair-20261008'
    target, metrics_root = folder/'a04-summary.json', folder/'a04-metrics'
    h = unit['horizon']
    by_id = {u['unit_id']:u for u in run['units']}
    units = [by_id.get(f'PRIMARY-H{h:02d}-O{o}') for o in range(1,7)]
    _require(all(u is not None and u['kind'] == 'PRIMARY' and u['horizon'] == h
        and u['outer_fold'] == o for o,u in enumerate(units,1)), 'A04_CURRENT_SIX_LOCKS_REQUIRED')
    input_paths = [base/'units'/u['unit_id']/'post-result-repair-20261008/a04/evaluation.json' for u in units]
    native_names = ['variants.zip', *[f'negative-P{i}.zip' for i in range(1,4)]]
    native_paths = [metrics_root/name for name in native_names]
    expected_paths = [str(p.relative_to(base)) for p in [*input_paths,*native_paths]]
    binding = {'kind':'PADML_CURRENT_A04_LINE_SUMMARY_V1',
        'decision_sha256':run['post_result_repair']['identity_sha256'],
        'target_unit':unit['unit_id'],'development_horizon':h,'a04_metric_horizon':24,
        'primary_units':[u['unit_id'] for u in units]}
    generations = same_batch_generations(run)
    _require(not any(p.is_symlink() for p in (root,folder,metrics_root,target)),
        'A04_CURRENT_NATIVE_PATH_INVALID')

    if target.is_file():
        raw = source_bytes(target,limit=64*1024**2)
        value = strict_json_bytes(raw)
        _evaluation_check_producer(value,generations)
        _require(canonical_json_bytes(value) == raw
            and nested._sealed({k:v for k,v in value.items() if k != 'identity_sha256'}) == value
            and all(value[k] == v for k,v in binding.items())
            and value['status'] == 'COMPLETED' and value['direct_consumer_completed'] is True
            and value['selection_effect'] == 'NONE' and value['stage_acceptance'] is False
            and value['new_prediction_model_fits'] == value['new_mice_chains'] == value['new_shap_solves'] == 0
            and [r['path'] for r in value['formal_references']] == expected_paths,
            'A04_CURRENT_LINE_RESULT_DRIFT')
        for ref in value['formal_references']: validate_reference(ref,run)
        return value

    # Input/owner/decision checks complete before any native metric call.
    projections = [read_current_a04_evaluation(path,run,u) for path,u in zip(input_paths,units,strict=True)]
    line = current_a04_handoffs(projections,horizons=(h,))[h]
    frozen = load_raw_binding(base/'binding',expected_input=run['raw_input'])
    _require(frozen['receipt']['run_id'] == run['run_id']
        and frozen['receipt']['source_identity'] in generations.values()
        and all(p['source']['raw_binding_identity'] == frozen['receipt']['identity'] for p in projections)
        and all(frozen['centers'][pid] == center for pid,center in zip(
            line['variants']['patient_ids'],line['variants']['centers'],strict=True)),
        'A04_CURRENT_LINE_RAW_BINDING_DRIFT')
    response = frozen['response_csv']
    references = [file_reference(path,'CURRENT_PRIMARY_A04_NUMERICAL_PROJECTION',run) for path in input_paths]
    folder.mkdir(mode=0o700,parents=True,exist_ok=True)
    metrics_root.mkdir(mode=0o700,exist_ok=True)
    evaluations = []
    cases = [(line['variants'],response,True), *[(handoff,raw,False) for handoff,raw in line['negative']]]
    _require(len(cases) == 4,'A04_CURRENT_FOUR_METRIC_CALLS_REQUIRED')
    from padml.runtime import admit_stage, MIN_WORKER_MEMORY_BYTES
    request_sizes = [len(canonical_json_bytes(handoff))+len(raw) for handoff,raw,_ in cases]
    for index,(path,(handoff,raw,variant)) in enumerate(zip(native_paths,cases,strict=True)):
        _require(not path.is_symlink(),'A04_CURRENT_NATIVE_PATH_INVALID')
        # Native R has its own temporary JSON and publication ZIP. Refill uses
        # current free space; existing qualified ZIPs are not reserved twice.
        pending_bytes = sum(8*size+32*1024**2 for target,size in
            zip(native_paths[index+1:],request_sizes[index+1:],strict=True) if not target.exists())
        publication = 0 if path.exists() else 8*request_sizes[index]+32*1024**2
        admit_stage(run['resource_policy'],metrics_root,legal_tasks=1,
            retained_bytes=pending_bytes,publication_bytes=publication,
            transient_bytes_per_worker=max(run['resource_policy']['scratch_bytes_per_worker'],
                16*request_sizes[index]+64*1024**2),
            memory_bytes_per_worker=max(MIN_WORKER_MEMORY_BYTES,64*request_sizes[index]+512*1024**2))
        options = ({'replay_native_archive':path} if path.exists() else
            {'native_archive':path,'evidence_root':metrics_root/path.stem})
        evaluation = evaluate_predictions(handoff,raw,**options)
        _validate_a12_native_evaluation(evaluation,handoff,raw,native_archive=path,
            **({'a04_variants':True} if variant else {'a04_negative':True}))
        evaluations.append(evaluation)
        references.append(file_reference(path,'CURRENT_A04_FIXED_PREDICTION_NATIVE_METRICS',run))
    negative = _negative_evaluation_summary([p['negative'] for p in projections],evaluations[1:],
        [handoff for handoff,_ in line['negative']])
    result = nested._sealed({**binding,'producer':_evaluation_provenance(run)['producer'],
        'status':'COMPLETED','direct_consumer_completed':True,
        'source_policies':line['sources'],'raw_binding_identity':frozen['receipt']['identity'],
        'original_response_sha256':sha256_bytes(response),
        'variants':{'variants':list(VARIANTS),'evaluation':evaluations[0]},'negative_controls':negative,
        'stability_diagnostics':{'estimand':'CONDITIONAL_ON_FROZEN_IMPUTATION_RECIPE_AND_MODEL_LOCK',
            'metric':'ORIGINAL_IBS_0_TO_24','selection_effect':'NONE',
            'original_views':run['post_result_repair']['complete_a04']['stability_views'],
            'scopes':[{'unit_id':u['unit_id'],'source':projection['source'],
                'components':{component:[{'coordinate':coordinate,
                    'original_result_sha256':sha(numbers),
                    'metrics':{key:numbers[key] for key in ('status','finite','mean_ibs','maximum_ibs',
                        'pooled_metric_values','pooled_metric_qc','partition_metrics','warning_count')}}
                    for coordinate,numbers in zip(body['registry']['tasks'],body['task_results'],strict=True)]
                    for component,body in projection['p2c2t'].items()}}
                for u,projection in zip(units,projections,strict=True)]},
        'review_status':negative['gate_status'] if negative['blocking_for_production'] else 'PENDING_FOUR_LINE_A04_REVIEW',
        'selection_effect':'NONE','stage_acceptance':False,
        'new_prediction_model_fits':0,'new_mice_chains':0,'new_shap_solves':0,
        'formal_references':references})
    nested._write_exact_once(target,canonical_json_bytes(result),'A04_CURRENT_LINE_RESULT_DRIFT')
    return result
