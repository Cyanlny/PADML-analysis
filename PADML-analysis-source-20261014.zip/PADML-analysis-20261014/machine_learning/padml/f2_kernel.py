from __future__ import annotations

from .runtime import MIN_WORKER_MEMORY_BYTES

import csv
import hashlib
import io
import json
import math
import mmap
import os
import random
import re
import shutil
import stat
import subprocess
import sys
from array import array
from bisect import bisect_left, bisect_right
from collections import OrderedDict
from dataclasses import dataclass
from decimal import Decimal, ROUND_HALF_UP
from functools import partial
from pathlib import Path
from threading import Lock
from typing import Any, Mapping, Sequence

from .bundle import (
    ContractError,
    canonical_json_bytes,
    execution_contract,
    execution_result_contract,
    extract_safe_zip,
    sha256_bytes,
    sha256_file,
    read_safe_zip,
    strict_json_bytes,
    validate_envelope,
    write_deterministic_zip,
)
from ._science_authority import (
    ACTIVE_ACTIVATION,
    _active_transform_catalog,
    execution_mode,
    load_science_authority,
    selector_sensitivity_contract,
    selector_parent_names,
    selected_route_profiles,
    validate_route_profile_map,
)
from .f1_kernel import compile_binding_contract
from .runtime import RSCRIPT_EXECUTABLE, THREAD_ENV, _bounded_ordered_spawn


F2_FAMILIES = (
    "COX_PH",
    "ELASTIC_NET_COX",
    "RSF",
    "GBM_COX",
    "XGBOOST_COX",
    "FPM_TVC_SET_A",
    "COXTIME_SET_A",
)
F2_COMPONENTS = (
    "CENTER_BLOCKED_STRESS",
    "LOCKED_MODEL_SAMPLE_SIZE_DIAGNOSTIC",
    "LOCAL_PERTURBATION",
)
F2_STAGES = ("S1", "S2", "S3A", "S3B1", "S3B2")
_R_FAMILIES = {"COX_PH", "ELASTIC_NET_COX", "RSF", "GBM_COX", "FPM_TVC_SET_A"}
_FAMILY_ROUTE_KEYS = {
    "COX_PH": "COX_PH",
    "ELASTIC_NET_COX": "F2_ELASTIC",
    "RSF": "RSF",
    "GBM_COX": "GBM_COX",
    "XGBOOST_COX": "XGBOOST_COX",
    "FPM_TVC_SET_A": "FPM_TVC",
    "COXTIME_SET_A": "COXTIME",
}
_HEX64 = re.compile(r"[0-9a-f]{64}")
_RECIPE_PROJECTION_KEYS = {
    "partition_id",
    "fit_ids_sha256",
    "analysis_view_sha256",
    "analysis_ids_sha256",
    "recipe_registry_record",
}
_RECIPE_REGISTRY_RECORD_KEYS = {
    "schema_version",
    "kind",
    "input_dir",
    "fit_ids",
    "members",
    "registry",
    "conflict_map",
}
_RECIPE_FORBIDDEN_ROLE_TOKENS = {
    "all_cause_death",
    "death_followup_months",
    "response",
    "outcome",
    "event",
    "followup",
    "nelson_aalen",
    "evaluation",
    "application",
}


def _require(condition: bool, reason: str) -> None:
    if not condition:
        raise ContractError(reason)


def _finite_number(value: Any) -> bool:
    return (
        isinstance(value, (int, float))
        and not isinstance(value, bool)
        and math.isfinite(value)
    )


def _contains_absolute_path(value: Any) -> bool:
    if isinstance(value, str):
        return Path(value).is_absolute()
    if isinstance(value, dict):
        return any(_contains_absolute_path(item) for item in value.values())
    return isinstance(value, list) and any(
        _contains_absolute_path(item) for item in value
    )


def _sha(value: Any) -> str:
    return sha256_bytes(canonical_json_bytes(value))


def _v20_owner_bytes(value: Any) -> bytes:
    """Canonical bytes used by the frozen v20.2 candidate-sequence owner."""

    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")


def _v20_owner_sha(value: Any) -> str:
    return hashlib.sha256(_v20_owner_bytes(value)).hexdigest()


def _candidate_dimensions(family: str, space: dict[str, Any]) -> list[tuple[str, str, str, str, Any]]:
    """Project the frozen v20.2 catalog rows without renaming their owner keys."""

    dimensions: list[tuple[str, str, str, str, Any]] = []
    if family == "RSF":
        dimensions = [
            ("num.trees", "discrete", "1000;shortlist=1000,1500,2000", "levels", space["num_trees"]["shortlist"]),
            ("mtry_fraction", "continuous", "0.20-1.00", "linear", (float(space["mtry_fraction"]["minimum"]), float(space["mtry_fraction"]["maximum"]))),
            ("min.node.size", "discrete", "10,15,20,30,40,50,60", "levels", space["min_node_size"]["values"]),
            ("max.depth", "discrete", "3,5,7,10,unlimited", "levels", [3, 5, 7, 10, "unlimited"]),
            ("sample.fraction", "discrete", "0.632,0.80,1.00", "levels", [0.632, 0.8, 1]),
            ("splitrule", "fixed", "logrank", "fixed", space["splitrule"]["value"]),
        ]
    elif family == "GBM_COX":
        dimensions = [
            ("interaction.depth", "integer", "1-3", "integer", (space["interaction_depth"]["minimum"], space["interaction_depth"]["maximum"])),
            ("shrinkage", "log_uniform", "0.005-0.10", "log", (space["shrinkage"]["minimum"], space["shrinkage"]["maximum"])),
            ("n.minobsinnode", "integer", "15-80", "integer", (space["min_observations_in_node"]["minimum"], space["min_observations_in_node"]["maximum"])),
            ("bag.fraction", "continuous", "0.60-0.90", "linear", (space["bag_fraction"]["minimum"], space["bag_fraction"]["maximum"])),
            ("n.trees.max", "integer", "5000", "fixed", space["max_trees"]["initial"]),
            ("fit_fraction", "fixed", "0.85", "fixed", space["fit_fraction"]),
            ("stop_fraction", "fixed", "0.15", "fixed", space["stop_fraction"]),
            ("early_stopping_metric", "fixed", "cox_deviance", "fixed", "cox_deviance"),
            ("early_stopping_patience", "fixed", "100", "fixed", space["early_stopping_patience"]),
            ("minimum_improvement", "fixed", "0.0001", "fixed", space["minimum_improvement"]),
            ("post_selection_refit", "fixed", "full_main_training_at_selected_n_trees", "fixed", "full_main_training_at_selected_n_trees"),
            ("locked_iteration_mode", "fixed", "full_main_training_without_reselection", "fixed", "full_main_training_without_reselection"),
        ]
    elif family == "XGBOOST_COX":
        dimensions = [
            ("eta", "log_uniform", "0.005-0.10", "log", (space["eta"]["minimum"], space["eta"]["maximum"])),
            ("max_depth", "integer", "1-3", "integer", (space["max_depth"]["minimum"], space["max_depth"]["maximum"])),
            ("min_child_weight", "log_uniform", "2-50", "log", (space["min_child_weight"]["minimum"], space["min_child_weight"]["maximum"])),
            ("subsample", "continuous", "0.60-0.95", "linear", (space["subsample"]["minimum"], space["subsample"]["maximum"])),
            ("colsample_bytree", "continuous", "0.50-1.00", "linear", (space["colsample_bytree"]["minimum"], space["colsample_bytree"]["maximum"])),
            ("reg_lambda", "log_uniform", "0.1-100", "log", (space["reg_lambda"]["minimum"], space["reg_lambda"]["maximum"])),
            ("reg_alpha", "mixed", "0-10", "linear", (space["reg_alpha"]["minimum"], space["reg_alpha"]["maximum"])),
            ("gamma", "mixed", "0-5", "linear", (space["gamma"]["minimum"], space["gamma"]["maximum"])),
            ("max_nrounds", "integer", "5000", "fixed", space["max_nrounds"]["initial"]),
            ("early_stopping_rounds", "fixed", "75", "fixed", space["early_stopping_rounds"]),
            ("tree_method", "fixed", "hist", "fixed", space["tree_method"]),
            ("max_bin", "fixed", "256", "fixed", space["max_bin"]),
            ("nthread", "fixed", "1", "fixed", 1),
            ("stop_scope", "fixed", "training_only", "fixed", "training_only"),
            ("post_selection_refit", "fixed", "full_main_training_at_best_rounds", "fixed", "full_main_training_at_best_rounds"),
            ("locked_iteration_mode", "fixed", "full_main_training_without_reselection", "fixed", "full_main_training_without_reselection"),
        ]
    return sorted(dimensions, key=lambda row: row[0].encode("utf-8"))


def _map_candidate(dimension: tuple[str, str, str, str, Any], value: float) -> tuple[Any, float]:
    _, _, _, kind, contract = dimension
    if kind == "fixed":
        return contract, 0.5
    if kind == "levels":
        index = min(int(math.floor(value * len(contract))), len(contract) - 1)
        return contract[index], index / max(1, len(contract) - 1)
    lower, upper = float(contract[0]), float(contract[1])
    if kind == "linear":
        return lower + value * (upper - lower), value
    if kind == "integer":
        mapped = min(int(lower) + int(math.floor(value * (int(upper) - int(lower) + 1))), int(upper))
        return mapped, (mapped - lower) / max(1.0, upper - lower)
    if kind == "log":
        return math.exp(math.log(lower) + value * (math.log(upper) - math.log(lower))), value
    raise ContractError("F2_CANDIDATE_DIMENSION_INVALID")


def _centered_l2_discrepancy(matrix: Any, np: Any) -> float:
    count, dimension = matrix.shape
    if count == 0 or dimension == 0:
        return 0.0
    centered = matrix - 0.5
    first = (13.0 / 12.0) ** dimension
    second = (2.0 / count) * float(
        np.sum(np.prod(1.0 + 0.5 * np.abs(centered) - 0.5 * centered**2, axis=1))
    )
    total = 0.0
    for index in range(count):
        left = centered[index]
        total += float(
            np.sum(
                np.prod(
                    1.0
                    + 0.5 * np.abs(left)
                    + 0.5 * np.abs(centered)
                    - 0.5 * np.abs(matrix[index] - matrix),
                    axis=1,
                )
            )
        )
    return float(math.sqrt(max(first - second + total / (count * count), 0.0)))


def _average_ranks(values: Any, np: Any) -> Any:
    order = np.argsort(values, kind="mergesort")
    ranks = np.empty(len(values), dtype=np.float64)
    start = 0
    while start < len(values):
        end = start + 1
        while end < len(values) and values[order[end]] == values[order[start]]:
            end += 1
        ranks[order[start:end]] = (start + end - 1) / 2.0 + 1.0
        start = end
    return ranks


def _maximum_absolute_spearman(matrix: Any, np: Any) -> float:
    if matrix.shape[1] < 2 or matrix.shape[0] < 2:
        return 0.0
    ranked = np.column_stack([_average_ranks(matrix[:, index], np) for index in range(matrix.shape[1])])
    correlations = np.corrcoef(ranked, rowvar=False)
    upper = np.abs(correlations[np.triu_indices(matrix.shape[1], k=1)])
    finite = upper[np.isfinite(upper)]
    return 0.0 if finite.size == 0 else float(np.max(finite))


def _design_candidate(
    *,
    family: str,
    stage_id: str,
    budget: int,
    dimensions: list[tuple[str, str, str, str, Any]],
    search_sha: str,
    seed_id: str,
    design_index: int,
    np: Any,
) -> tuple[float, float, float, str, list[dict[str, Any]]]:
    material = [seed_id, search_sha, family, "SET_A", stage_id, budget, design_index]
    digest = hashlib.sha256(_v20_owner_bytes(material)).hexdigest()
    seed = int(digest[:32], 16)
    variable = [row for row in dimensions if row[3] != "fixed"]
    rng = np.random.Generator(np.random.PCG64DXSM(seed))
    matrix = np.empty((budget, len(variable)), dtype=np.float64)
    for column in range(len(variable)):
        matrix[:, column] = (rng.permutation(budget) + rng.random(budget)) / budget
    rows: list[dict[str, Any]] = []
    normalized: list[list[float]] = []
    identities: set[bytes] = set()

    def add_point(point: Any) -> None:
        parameters: dict[str, Any] = {}
        scaled: list[float] = []
        cursor = 0
        for dimension in dimensions:
            raw = 0.5 if dimension[3] == "fixed" else float(point[cursor])
            if dimension[3] != "fixed":
                cursor += 1
            mapped, normalized_value = _map_candidate(dimension, raw)
            parameters[dimension[0]] = mapped
            if dimension[3] != "fixed":
                scaled.append(normalized_value)
        if family == "RSF":
            parameters["mtry_fraction"] = json.dumps(parameters["mtry_fraction"], allow_nan=False)
        ordered = {key: parameters[key] for key in sorted(parameters, key=lambda value: value.encode("utf-8"))}
        identity = _v20_owner_bytes(ordered)
        if identity not in identities:
            identities.add(identity)
            rows.append(ordered)
            normalized.append(scaled)

    for point in matrix:
        add_point(point)
    if len(rows) < budget:
        supplement = int(
            hashlib.sha256(seed.to_bytes(16, "big", signed=False) + b"P2C1_DETERMINISTIC_SUPPLEMENT").hexdigest()[:32],
            16,
        )
        supplement_rng = np.random.Generator(np.random.PCG64DXSM(supplement))
        for _ in range(max(1000, budget * 1000)):
            if len(rows) == budget:
                break
            add_point(supplement_rng.random(len(variable)))
    _require(len(rows) == budget, "F2_CANDIDATE_SEQUENCE_UNRESOLVED")
    array = np.asarray(normalized, dtype=np.float64)
    minimum = math.inf
    for index in range(budget - 1):
        minimum = min(minimum, float(np.min(np.sqrt(np.sum((array[index + 1 :] - array[index]) ** 2, axis=1)))))
    row_sha = _v20_owner_sha(rows)
    return minimum, _centered_l2_discrepancy(array, np), _maximum_absolute_spearman(array, np), row_sha, rows


def _better_design(left: tuple[float, float, float, str, list[dict[str, Any]]], right: tuple[float, float, float, str, list[dict[str, Any]]] | None) -> bool:
    if right is None:
        return True
    if left[0] != right[0]:
        return left[0] > right[0]
    if left[1] != right[1]:
        return left[1] < right[1]
    if left[2] != right[2]:
        return left[2] < right[2]
    return bytes.fromhex(left[3]) < bytes.fromhex(right[3])


def candidate_trials(
    family: str,
    stage_id: str,
    budget: int,
    space: dict[str, Any],
    policy: dict[str, Any],
    sampler_seed: dict[str, Any],
) -> list[dict[str, Any]]:
    """Exact-policy maximin LHS stream, independent of fold, outcome, and worker order."""

    _require(family in {"RSF", "GBM_COX", "XGBOOST_COX"} and stage_id in {"S1", "S2"} and budget > 0, "F2_CANDIDATE_REQUEST_INVALID")
    _require(policy["method"] == "DETERMINISTIC_MAXIMIN_LHS_V1" and policy["rng_engine"] == "NUMPY_PCG64DXSM", "F2_CANDIDATE_POLICY_INVALID")
    try:
        import numpy as np  # type: ignore
    except ImportError as exc:
        raise ContractError("F2_NUMPY_CAPABILITY_UNAVAILABLE") from exc
    dimensions = _candidate_dimensions(family, space)
    core = [{"name": name, "scale": scale, "expression": expression} for name, scale, expression, _, _ in dimensions]
    search_sha = _v20_owner_sha(core)
    seed_id = f"P2C1_SAMPLER::{_v20_owner_sha(sampler_seed)}"
    checkpoint_best = initial_best = best = None
    for design_index in range(policy["initial_design_pool"]):
        design = _design_candidate(
            family=family,
            stage_id=stage_id,
            budget=budget,
            dimensions=dimensions,
            search_sha=search_sha,
            seed_id=seed_id,
            design_index=design_index,
            np=np,
        )
        if design_index < policy["initial_design_pool"] // 2 and _better_design(design, checkpoint_best):
            checkpoint_best = design
        if _better_design(design, initial_best):
            initial_best = design
        if _better_design(design, best):
            best = design
    _require(checkpoint_best is not None and initial_best is not None and best is not None and checkpoint_best[0] > 0, "F2_CANDIDATE_SEQUENCE_UNRESOLVED")
    relative_gain = (initial_best[0] - checkpoint_best[0]) / checkpoint_best[0]
    if relative_gain > policy["extension_relative_gain_threshold"]:
        for design_index in range(policy["initial_design_pool"], policy["maximum_design_pool"]):
            design = _design_candidate(
                family=family,
                stage_id=stage_id,
                budget=budget,
                dimensions=dimensions,
                search_sha=search_sha,
                seed_id=seed_id,
                design_index=design_index,
                np=np,
            )
            if _better_design(design, best):
                best = design
    _require(best[0] > 0, "F2_CANDIDATE_SEQUENCE_UNRESOLVED")
    return [
        {"trial_id": f"{family}::SET_A::{stage_id}::{index:03d}", "parameters": row, "parameter_sha256": _v20_owner_sha(row)}
        for index, row in enumerate(best[4], start=1)
    ]


_ENGINE_PARAMETER_NAMES = {
    "RSF": {
        "num.trees": "num_trees",
        "min.node.size": "min_node_size",
        "max.depth": "max_depth",
        "sample.fraction": "sample_fraction",
    },
    "GBM_COX": {
        "interaction.depth": "interaction_depth",
        "n.minobsinnode": "min_observations_in_node",
        "bag.fraction": "bag_fraction",
        "n.trees.max": "max_trees",
    },
}


def _engine_parameters(family: str, parameters: dict[str, Any]) -> dict[str, Any]:
    """Translate frozen owner names only at the family engine boundary."""

    mapped = {_ENGINE_PARAMETER_NAMES.get(family, {}).get(key, key): value for key, value in parameters.items()}
    if family == "RSF":
        _require(mapped.get("splitrule") == "logrank", "F2_RSF_FIXED_PARAMETER_DRIFT")
    if family == "GBM_COX":
        expected = {
            "early_stopping_metric": "cox_deviance",
            "post_selection_refit": "full_main_training_at_selected_n_trees",
            "locked_iteration_mode": "full_main_training_without_reselection",
        }
        _require(all(mapped.get(key) == value for key, value in expected.items()), "F2_GBM_FIXED_PARAMETER_DRIFT")
    if family == "XGBOOST_COX":
        expected = {
            "stop_scope": "training_only",
            "post_selection_refit": "full_main_training_at_best_rounds",
            "locked_iteration_mode": "full_main_training_without_reselection",
        }
        _require(all(mapped.get(key) == value for key, value in expected.items()), "F2_XGBOOST_FIXED_PARAMETER_DRIFT")
    return mapped


def _approved_object(capsule: dict[str, Any], unit_id: str) -> dict[str, Any]:
    registry = capsule.get("approved_registry")
    _require(type(registry) is dict, "F2_APPROVED_REGISTRY_NOT_ADMITTED")
    rows = [row for row in registry["direct_objects"] if row["unit_id"] == unit_id]
    _require(len(rows) == 1, f"F2_APPROVED_OBJECT_MISSING:{unit_id}")
    return rows[0]


def _request_from_f1_result(result: dict[str, Any]) -> dict[str, Any]:
    _require(len(result["artifacts"]) == 1, "F2_F1_RESULT_ARTIFACT_COUNT_INVALID")
    artifact = result["artifacts"][0]
    return validate_envelope(
        {
            **result,
            "kind": "request",
            "artifacts": [
                {
                    **artifact,
                    "size_bytes": None,
                    "sha256": None,
                    "status": "EXPECTED",
                }
            ],
            "terminal": None,
        }
    )


def _admit_completed_f1_unit(
    capsule_path: Path,
    capsule: dict[str, Any],
    expected_unit_id: str,
    destination: Path,
    result_paths: Mapping[str, Path] | None = None,
    *, admit_io=None,
) -> tuple[dict[str, Any], dict[str, Any], Path]:
    record = _approved_object(capsule, expected_unit_id)
    path = (
        result_paths[expected_unit_id]
        if result_paths is not None
        else capsule_path.parent / "approved-f1" / f"{expected_unit_id}.zip"
    )
    _require(
        path.is_absolute()
        and path.is_file()
        and not path.is_symlink()
        and path.resolve(strict=True) == path
        and path.stat().st_size == record["result_size_bytes"]
        and sha256_file(path) == record["result_sha256"],
        f"F2_F1_RESULT_IDENTITY_INVALID:{expected_unit_id}",
    )
    relative_path = f"outputs/{expected_unit_id}/payload.zip"
    extract_safe_zip(
        path,
        destination,
        expected_members={"manifest.json", relative_path},
        max_member_bytes=64 * 1024 * 1024 * 1024,
        max_total_bytes=64 * 1024 * 1024 * 1024,
        admit_io=admit_io,
    )
    if admit_io is not None:
        admit_io(memory_bytes=32 * (destination / "manifest.json").stat().st_size)
    raw_manifest = (destination / "manifest.json").read_bytes()
    result = validate_envelope(strict_json_bytes(raw_manifest, "f1-result.manifest"))
    request = _request_from_f1_result(result)
    artifact = result["artifacts"][0]
    artifact_path = destination / relative_path
    _require(
        canonical_json_bytes(result) == raw_manifest
        and result["kind"] == "result"
        and result["run_id"] == record["source_run_id"]
        and result["stage_id"] == "F1"
        and result["unit_id"] == expected_unit_id
        and result["transaction_id"] == record["transaction_id"]
        and result["terminal"]["status"] == "COMPLETED"
        and sha256_bytes(canonical_json_bytes(request)) == record["request_sha256"]
        and artifact["status"] == "OK"
        and artifact["sha256"] == record["artifact_sha256"] == sha256_file(artifact_path)
        and artifact["size_bytes"] == record["artifact_size_bytes"] == artifact_path.stat().st_size,
        f"F2_F1_RESULT_CONTRACT_INVALID:{expected_unit_id}",
    )
    return result, request, artifact_path


def admitted_f1_frozen_data(
    capsule_path: Path,
    capsule: dict[str, Any],
    scratch: Path,
    result_paths: Mapping[str, Path] | None = None,
) -> tuple[dict[str, Any], bytes, dict[str, Any]]:
    """Admit the approved binding object and keep response bytes separate."""
    result_root = scratch / "data-binding-result"
    result, _, payload = _admit_completed_f1_unit(
        capsule_path,
        capsule,
        "data-binding",
        result_root,
        result_paths,
    )
    payload_root = scratch / "data-binding-payload"
    extract_safe_zip(
        payload,
        payload_root,
        expected_members={
            "manifest.json",
            "binding/contract.json",
            "binding/covariates.csv",
            "binding/response-seal.csv",
        },
        max_member_bytes=64 * 1024 * 1024,
        max_total_bytes=128 * 1024 * 1024,
    )
    raw_manifest = (payload_root / "manifest.json").read_bytes()
    raw_contract = (payload_root / "binding/contract.json").read_bytes()
    covariates = (payload_root / "binding/covariates.csv").read_bytes()
    response = (payload_root / "binding/response-seal.csv").read_bytes()
    manifest = strict_json_bytes(raw_manifest, "f1-binding.manifest")
    contract = strict_json_bytes(raw_contract, "f1-binding.contract")
    workbook_sha256 = result.get("identities", {}).get("input")
    predecessor_authority_sha256 = result.get("identities", {}).get(
        "authority"
    )
    expected_workbook_sha256 = capsule.get("base_record", {}).get(
        "input_workbook_sha256"
    )
    _require(
        isinstance(workbook_sha256, str)
        and _HEX64.fullmatch(workbook_sha256) is not None
        and isinstance(predecessor_authority_sha256, str)
        and _HEX64.fullmatch(predecessor_authority_sha256) is not None
        and (
            expected_workbook_sha256 is None
            or expected_workbook_sha256 == workbook_sha256
        ),
        "F2_F1_BINDING_PAYLOAD_INVALID",
    )
    expected_contract = compile_binding_contract(
        covariates, response, workbook_sha256=workbook_sha256
    )
    expected_contract["authority_sha256"] = predecessor_authority_sha256
    expected_registry = dict(expected_contract["registry"])
    expected_registry["authority_sha256"] = predecessor_authority_sha256
    expected_contract["registry"] = expected_registry
    _require(
        canonical_json_bytes(manifest) == raw_manifest
        and canonical_json_bytes(contract) == raw_contract
        and manifest.get("kind") == "PADML_F1_DATA_BINDING_PAYLOAD"
        and manifest.get("status") == "PASS"
        and manifest.get("authority_sha256")
        == predecessor_authority_sha256
        and manifest.get("workbook_sha256") == workbook_sha256
        and contract == expected_contract,
        "F2_F1_BINDING_PAYLOAD_INVALID",
    )
    lineage = {
        "f1_approved_result_sha256": capsule["manifest"]["identity_records"][
            "approved_predecessor"
        ]["manifest_identity"],
        "f1_data_binding_result_sha256": _approved_object(capsule, "data-binding")[
            "result_sha256"
        ],
        "f1_binding_contract_sha256": sha256_bytes(raw_contract),
        "f1_response_seal_sha256": sha256_bytes(response),
    }
    return contract, response, lineage


def _load_f1_view_library(
    path: Path,
    expected_view: dict[str, Any],
    destination: Path,
    *, admit_io=None,
) -> Path:
    configuration_paths = {
        f"configuration/{component}.json"
        for component in (
            "ACTUAL_MICE_METHOD",
            "ACTUAL_PREDICTOR_MATRIX",
            "ACTUAL_BLOT",
            "ACTUAL_CONTINUATION_CONFIG",
        )
    }
    expected = {
        "manifest.json",
        *(f"imputations/imp{index:02d}.csv" for index in range(1, 21)),
        *configuration_paths,
    }
    extract_safe_zip(
        path,
        destination,
        expected_members=expected,
        max_member_bytes=128 * 1024 * 1024,
        max_total_bytes=3 * 1024 * 1024 * 1024,
        admit_io=admit_io,
    )
    if admit_io is not None:
        admit_io(memory_bytes=32 * (destination / "manifest.json").stat().st_size)
    raw_manifest = (destination / "manifest.json").read_bytes()
    manifest = strict_json_bytes(raw_manifest, "f1-view.manifest")
    _require(
        canonical_json_bytes(manifest) == raw_manifest
        and manifest.get("kind") == "PADML_F1_MICE_VIEW"
        and manifest.get("status") == "PASS"
        and manifest.get("view") == expected_view
        and set(manifest.get("members", {})) == expected - {"manifest.json"}
        and all(
            manifest["members"][name]
            == {
                "sha256": sha256_file(destination / name),
                "size_bytes": (destination / name).stat().st_size,
            }
            for name in expected - {"manifest.json"}
        ),
        f"F2_F1_VIEW_LIBRARY_INVALID:{expected_view['view_id']}",
    )
    return destination


def _merge_registered_views(
    analysis: Path,
    application: Path,
    *,
    analysis_ids: list[str],
    application_ids: list[str],
    destination: Path,
    partition_id: str,
    admit_io=None, prepared=None, expected_columns=None, expected_centers=None,
) -> dict[str, Any]:
    if admit_io is not None:
        sizes = [sum((root / f"imputations/imp{index:02d}.csv").stat().st_size
                     for root in (analysis, application)) for index in range(1, 21)]
        admit_io(pending_bytes=2 * sum(sizes), memory_bytes=32 * max(sizes))
    destination.mkdir(mode=0o700)
    member_records: list[dict[str, Any]] = []
    fit_members = []
    centers = []
    for index in range(1, 21):
        name = f"imputations/imp{index:02d}.csv"
        if admit_io is not None:
            admit_io(memory_bytes=32 * sizes[index - 1])
        with (
            (analysis / name).open(encoding="utf-8-sig", newline="") as analysis_handle,
            (application / name).open(encoding="utf-8-sig", newline="") as application_handle,
        ):
            analysis_reader = csv.DictReader(analysis_handle)
            application_reader = csv.DictReader(application_handle)
            analysis_rows = list(analysis_reader)
            _require(
                analysis_reader.fieldnames == application_reader.fieldnames
                and (expected_columns is None or analysis_reader.fieldnames == expected_columns)
                and [row["Patient_ID"] for row in analysis_rows] == analysis_ids,
                "F2_F1_REGISTERED_VIEW_ROW_IDENTITY_INVALID",
            )
            if prepared is not None:
                fit_bytes = _recipe_training_rows_bytes(list(analysis_reader.fieldnames or []),
                    analysis_rows, analysis_ids)
                fit_members.append({"name": f"imp{index:02d}.csv",
                    "sha256": sha256_bytes(fit_bytes), "size_bytes": len(fit_bytes)})
            by_id = {row["Patient_ID"]: row for row in analysis_rows}
            observed: list[str] = []
            target = destination / f"imp{index:02d}.csv"
            with target.open("x", encoding="utf-8", newline="") as output:
                writer = csv.DictWriter(
                    output,
                    fieldnames=application_reader.fieldnames,
                    lineterminator="\n",
                )
                writer.writeheader()
                for row in application_reader:
                    patient_id = row.get("Patient_ID", "")
                    observed.append(patient_id)
                    chosen = by_id.get(patient_id, row)
                    _require(expected_centers is None or chosen['Center'] == expected_centers[patient_id],
                        'F5_A12_TOTAL_CHANNEL_OR_PATIENT_DRIFT')
                    if prepared is not None and index == 1:
                        centers.append(chosen["Center"])
                    writer.writerow(chosen)
            _require(
                observed == application_ids,
                "F2_F1_REGISTERED_VIEW_ROW_IDENTITY_INVALID",
            )
        member_records.append(
            {
                "name": target.name,
                "sha256": sha256_file(target),
                "size_bytes": target.stat().st_size,
            }
        )
    if prepared is not None:
        prepared.update(fit_covariate_members=fit_members,
            positions={patient: index for index, patient in enumerate(application_ids)}, centers=centers)
    return {
        "schema_version": "1.0.0",
        "kind": "PADML_F2_REGISTERED_VIEW_BINDING",
        "status": "PASS",
        "partition_id": partition_id,
        "analysis_view_sha256": sha256_file(analysis / "manifest.json"),
        "application_view_sha256": sha256_file(application / "manifest.json"),
        "analysis_ids_sha256": _sha(analysis_ids),
        "application_ids_sha256": _sha(application_ids),
        "input_dir": str(destination),
        "members": member_records,
        "data_identity": _sha(member_records),
    }


def _response_rows(response_csv: bytes) -> tuple[list[str], dict[str, dict[str, str]]]:
    reader = csv.DictReader(io.StringIO(response_csv.decode("utf-8-sig")))
    rows = list(reader)
    ids = [row.get("Patient_ID", "") for row in rows]
    _require(
        reader.fieldnames
        == ["Patient_ID", "All_Cause_Death", "Death_Followup_months"]
        and ids
        and len(ids) == len(set(ids))
        and all(ids),
        "F2_FROZEN_RESPONSE_SEAL_INVALID",
    )
    return list(reader.fieldnames), {row["Patient_ID"]: row for row in rows}


def _write_response_subset(
    fields: list[str],
    by_id: dict[str, dict[str, str]],
    ids: list[str],
    target: Path | None,
) -> dict[str, Any]:
    _require(ids and len(ids) == len(set(ids)), "F2_RESPONSE_SUBSET_IDENTITY_INVALID")
    _require(
        all(patient_id in by_id for patient_id in ids),
        "F2_RESPONSE_SUBSET_IDENTITY_INVALID",
    )
    events = [by_id[patient_id]["All_Cause_Death"] for patient_id in ids]
    _require(
        all(value in {"0", "1"} for value in events),
        "F2_RESPONSE_SUBSET_EVENT_INVALID",
    )
    output = io.StringIO(newline="")
    writer = csv.DictWriter(output, fieldnames=fields, lineterminator="\n")
    writer.writeheader()
    for patient_id in ids:
        _require(patient_id in by_id, "F2_RESPONSE_SUBSET_IDENTITY_INVALID")
        writer.writerow(by_id[patient_id])
    data = output.getvalue().encode("utf-8")
    if target is not None:
        with target.open("xb") as handle:
            handle.write(data)
    return {
        **({"path": str(target)} if target is not None else {"private_bytes": data}),
        "event_count": sum(int(value) for value in events),
        "row_count": len(ids),
        "row_ids_sha256": _sha(ids),
        "sha256": sha256_bytes(data),
        "size_bytes": len(data),
    }


def _seal_prediction_matrix(
    expected_ids: list[str],
    values: Any,
    horizons: list[int],
) -> dict[str, Any]:
    _require(isinstance(values, (list, tuple)), "F2_PREDICTION_SEAL_INVALID")
    matrix = [list(row) for row in values]
    _require(
        expected_ids
        and len(expected_ids) == len(set(expected_ids))
        and all(isinstance(item, str) and item for item in expected_ids)
        and horizons
        and all(
            isinstance(item, int) and not isinstance(item, bool)
            for item in horizons
        )
        and (
            all(item > 0 for item in horizons)
            or horizons == list(range(37))
        )
        and len(matrix) == len(expected_ids)
        and all(len(row) == len(horizons) for row in matrix)
        and all(
            isinstance(value, (int, float))
            and not isinstance(value, bool)
            and math.isfinite(value)
            and 0 <= value <= 1
            for row in matrix
            for value in row
        )
        and all(
            left + 1e-10 >= right
            for row in matrix
            for left, right in zip(row, row[1:])
        ),
        "F2_PREDICTION_SEAL_INVALID",
    )
    payload = {
        "schema_version": "1.0.0",
        "kind": "PADML_F2_PREDICTION_MATRIX",
        "patient_ids": list(expected_ids),
        "horizons": list(horizons),
        "survival": [
            [float(value) for value in matrix[index]]
            for index in range(len(matrix))
        ],
    }
    return {
        "status": "SEALED",
        "payload": payload,
        "sha256": _sha(payload),
    }


def _selection_horizon_from_spec(spec: Mapping[str, Any]) -> int:
    """Read the original task's explicit window without changing legacy F2 authority."""
    horizon = spec.get("selection_horizon_months", 24)
    _require(type(horizon) is int and horizon in {6, 12, 24, 36}, "F2_SELECTION_HORIZON_INVALID")
    if "trial_scoring" in spec or horizon != 24:
        expected = dict(load_science_authority()["science"]["f2_model_development"]["trial_scoring"])
        expected.update(ibs_grid_months=list(range(horizon + 1)),
                        ibs_integration=f"TRAPEZOID_DIVIDE_BY_{horizon}")
        _require(spec.get("trial_scoring") == expected, "F2_SELECTION_SCORING_CONTRACT_MISMATCH")
    return horizon


def _evaluate_prediction_seal(
    sealed: dict[str, Any],
    *,
    fit_response: dict[str, Any],
    evaluation_response: dict[str, Any],
    evaluation_context: Mapping[str, Any] | None = None,
    selection_horizon_months: int = 24,
) -> dict[str, Any]:
    """The only boundary that reads evaluation response after a prediction seal."""

    _require(type(selection_horizon_months) is int and selection_horizon_months in {6, 12, 24, 36},
             "F2_SELECTION_HORIZON_INVALID")
    _require(
        isinstance(sealed, dict)
        and set(sealed) == {"status", "payload", "sha256"}
        and sealed["status"] == "SEALED"
        and _sha(sealed["payload"]) == sealed["sha256"],
        "F2_EVALUATION_PREDICTION_NOT_SEALED",
    )
    payload = sealed["payload"]
    _require(
        isinstance(payload, dict)
        and set(payload)
        == {"schema_version", "kind", "patient_ids", "horizons", "survival"}
        and payload["schema_version"] == "1.0.0"
        and payload["kind"] == "PADML_F2_PREDICTION_MATRIX"
        and payload["horizons"] == list(range(37))
        and all(row[0] == 1.0 for row in payload["survival"]),
        "F2_EVALUATION_PREDICTION_INVALID",
    )
    context = (
        _prediction_evaluation_context(
            fit_response,
            evaluation_response,
            payload["patient_ids"],
            selection_horizon_months=selection_horizon_months,
        )
        if evaluation_context is None
        else dict(evaluation_context)
    )
    _require(
        context.get("fit_response_sha256") == fit_response["sha256"]
        and context.get("evaluation_response_sha256")
        == evaluation_response["sha256"]
        and context.get("evaluation_ids_sha256")
        == _sha(payload["patient_ids"]),
        "F2_EVALUATION_CONTEXT_IDENTITY_INVALID",
    )
    _require(context.get("selection_horizon_months", 24) == selection_horizon_months,
             "F2_EVALUATION_CONTEXT_HORIZON_MISMATCH")
    weights = context["ipcw_weights"]
    truths = context["evaluation_truth"]
    indices = context.get("evaluation_indices", list(range(len(payload["patient_ids"]))))
    predictions = [payload["survival"][index] for index in indices]
    count = len(indices)
    _require(
        len(weights) == len(truths) == selection_horizon_months + 1
        and all(len(row) == count for row in [*weights, *truths]),
        "F2_EVALUATION_CONTEXT_IDENTITY_INVALID",
    )
    scores = [
        math.fsum(
            weight * (truth - prediction[column]) ** 2
            for weight, truth, prediction in zip(
                weights[column], truths[column], predictions, strict=True
            )
        ) / count
        for column in range(selection_horizon_months + 1)
    ]
    value = math.fsum(
        (left + right) / 2.0 for left, right in zip(scores, scores[1:])
    ) / selection_horizon_months
    _require(math.isfinite(value) and value >= 0, "F2_EVALUATION_METRIC_INVALID")
    return {
        "status": "PASS",
        "prediction_sha256": sealed["sha256"],
        "evaluation_response_sha256": evaluation_response["sha256"],
        "evaluation_count": count,
        f"ibs_0_{selection_horizon_months}": value,
        "ipcw_qc": context["ipcw_qc"],
    }


def _prediction_evaluation_context(
    fit_response: Mapping[str, Any],
    evaluation_response: Mapping[str, Any],
    evaluation_ids: list[str],
    *, selection_horizon_months: int = 24, evaluation_indices: list[int] | None = None,
) -> dict[str, Any]:
    """Parse exact response inputs once for one operation-local evaluator batch."""

    fit_time, fit_event = _response_arrays(fit_response)
    evaluation_time, evaluation_event = _response_arrays(
        evaluation_response, evaluation_ids
    )
    ids = evaluation_ids
    if evaluation_indices is not None:
        ids = [evaluation_ids[i] for i in evaluation_indices]
        evaluation_time = [evaluation_time[i] for i in evaluation_indices]
        evaluation_event = [evaluation_event[i] for i in evaluation_indices]
    context = _ipcw_evaluation_context(
        fit_response,
        evaluation_response,
        ids,
        evaluation_time,
        evaluation_event,
        ["TRAINING"] * len(ids),
        {"TRAINING": _censoring_survival_step(fit_time, fit_event)},
        formal=False,
        selection_horizon_months=selection_horizon_months,
    )
    if evaluation_indices is not None:
        context.update(evaluation_ids_sha256=_sha(evaluation_ids), evaluation_indices=evaluation_indices)
    return context


def _center_stratified_evaluation_context(
    evaluation_response: Mapping[str, Any],
    evaluation_ids: list[str],
    centers: list[str],
    *, selection_horizon_months: int = 24, evaluation_indices: list[int] | None = None,
) -> dict[str, Any]:
    """Use the complete OOF/held-out evaluation population, never fit outcomes."""

    times, events = _response_arrays(evaluation_response, evaluation_ids)
    _require(
        len(centers) == len(evaluation_ids)
        and all(isinstance(center, str) and center for center in centers),
        "F2_EVALUATION_CENTER_IDENTITY_INVALID",
    )
    ids = evaluation_ids
    if evaluation_indices is not None:
        ids = [evaluation_ids[i] for i in evaluation_indices]
        times, events, centers = ([values[i] for i in evaluation_indices] for values in (times, events, centers))
    steps = {
        center: _censoring_survival_step(
            [time for time, value in zip(times, centers, strict=True) if value == center],
            [event for event, value in zip(events, centers, strict=True) if value == center],
        )
        for center in sorted(set(centers))
    }
    context = _ipcw_evaluation_context(
        evaluation_response,
        evaluation_response,
        ids,
        times,
        events,
        centers,
        steps,
        formal=True,
        selection_horizon_months=selection_horizon_months,
    )
    if evaluation_indices is not None:
        context.update(evaluation_ids_sha256=_sha(evaluation_ids), evaluation_indices=evaluation_indices)
    return context


def _ipcw_evaluation_context(
    fit_response: Mapping[str, Any],
    evaluation_response: Mapping[str, Any],
    evaluation_ids: list[str],
    times: list[float],
    events: list[int],
    centers: list[str],
    steps: Mapping[str, list[tuple[float, float]]],
    *,
    formal: bool,
    selection_horizon_months: int = 24,
) -> dict[str, Any]:
    """Cache exact monthly IPCW weights once for all candidates in a population."""

    _require(type(selection_horizon_months) is int and selection_horizon_months in {6, 12, 24, 36},
             "F2_SELECTION_HORIZON_INVALID")
    weights: list[list[float]] = []
    truths: list[list[float]] = []
    support: list[float] = []
    effective_sizes: list[float] = []
    survival_cache: dict[tuple[str, float, str], float] = {}
    _require(len(evaluation_ids) == len(times) == len(events) == len(centers)
             and bool(evaluation_ids) and set(centers) == set(steps),
             "F2_IPCW_CONTEXT_INVALID")
    for horizon in range(selection_horizon_months + 1):
        # A center can lose censoring support even when only earlier deaths
        # retain nonzero individual weights. Check the whole required window.
        for center in sorted(set(centers)):
            key = (center, float(horizon), "RIGHT")
            survival_cache[key] = _censoring_survival_at(
                steps[center], key[1], side=key[2])
            support.append(survival_cache[key])
        row_weights: list[float] = []
        row_truths: list[float] = []
        for time, event, center in zip(times, events, centers, strict=True):
            row_truths.append(float(time > horizon))
            if time <= horizon and event == 1:
                key = (center, float(time), "LEFT")
            elif time > horizon:
                key = (center, float(horizon), "RIGHT")
            else:
                row_weights.append(0.0)
                continue
            if key not in survival_cache:
                survival_cache[key] = _censoring_survival_at(
                    steps[center], key[1], side=key[2]
                )
            g = survival_cache[key]
            support.append(g)
            _require(g > 0, "F2_IPCW_SUPPORT_UNAVAILABLE")
            row_weights.append(1.0 / g)
        total = math.fsum(row_weights)
        squares = math.fsum(weight * weight for weight in row_weights)
        effective_sizes.append(total * total / squares if squares else 0.0)
        weights.append(row_weights)
        truths.append(row_truths)
    positive = sorted(weight for row in weights[1:] for weight in row if weight > 0)
    _require(positive and support, "F2_IPCW_SUPPORT_UNAVAILABLE")
    required_ess = max(30.0, 0.20 * len(evaluation_ids))
    qc = {
        "censoring_model": (
            "EVALUATION_CENTER_STRATIFIED_KM" if formal else "TRAINING_KM"
        ),
        "evaluation_count": len(evaluation_ids),
        "minimum_g": min(support),
        "minimum_effective_sample_size": min(effective_sizes),
        "maximum_weight": positive[-1],
        "positive_weight_quantiles": [
            positive[round((len(positive) - 1) * quantile)]
            for quantile in (0.0, 0.5, 0.9, 0.99, 1.0)
        ],
        "truncation_applied": False,
        "metric_estimable": (
            min(support) >= 0.05 and min(effective_sizes) >= required_ess
        ),
    }
    _require(
        not formal or qc["metric_estimable"],
        "F2_PRIMARY_IBS_NOT_ESTIMABLE",
    )
    return {
        **({"selection_horizon_months": selection_horizon_months} if selection_horizon_months != 24 else {}),
        "fit_response_sha256": fit_response["sha256"],
        "evaluation_response_sha256": evaluation_response["sha256"],
        "evaluation_ids_sha256": _sha(evaluation_ids),
        "evaluation_truth": truths,
        "ipcw_weights": weights,
        "ipcw_qc": qc,
    }


def _censoring_survival_step(
    times: list[float], events: list[int]
) -> list[tuple[float, float]]:
    """Reverse KM: tied observed deaths leave the risk set before censoring."""

    _require(
        len(times) == len(events) and bool(times)
        and all(_finite_number(value) and value >= 0 for value in times)
        and all(type(event) is int and event in {0, 1} for event in events),
        "F2_EVALUATION_RESPONSE_DOMAIN_INVALID",
    )
    current = 1.0
    step: list[tuple[float, float]] = []
    for value in sorted(set(times)):
        at_risk = sum(item >= value for item in times)
        censored = sum(
            item == value and event == 0
            for item, event in zip(times, events, strict=True)
        )
        deaths = sum(item == value and event == 1
                     for item, event in zip(times, events, strict=True))
        # An all-death terminal group has no censoring hazard, not 0/0.
        if censored:
            current *= 1.0 - censored / (at_risk - deaths)
        step.append((value, current))
    return step


def _censoring_survival_at(
    step: list[tuple[float, float]], query: float, *, side: str
) -> float:
    """Evaluate the censoring KM at t or its exact left limit."""

    _require(
        bool(step)
        and side in {"LEFT", "RIGHT"}
        and isinstance(query, (int, float))
        and not isinstance(query, bool)
        and math.isfinite(query)
        and all(
            isinstance(row, tuple)
            and len(row) == 2
            and all(
                isinstance(value, (int, float))
                and not isinstance(value, bool)
                and math.isfinite(value)
                for value in row
            )
            and 0 <= row[1] <= 1
            for row in step
        ),
        "F2_IPCW_CONTEXT_INVALID",
    )
    times = [float(row[0]) for row in step]
    survival = [float(row[1]) for row in step]
    _require(
        all(left < right for left, right in zip(times, times[1:]))
        and all(left >= right for left, right in zip(survival, survival[1:])),
        "F2_IPCW_CONTEXT_INVALID",
    )
    position = (
        bisect_left(times, float(query))
        if side == "LEFT"
        else bisect_right(times, float(query))
    )
    return 1.0 if position == 0 else survival[position - 1]


@dataclass(frozen=True)
class _CoxRiskMatrix:
    """One immutable float64 buffer; only its descriptor enters result JSON."""
    raw: bytes | mmap.mmap
    rows: int
    columns: int
    sha256: str

    def descriptor(self):
        return {"encoding": "FLOAT64_LE_ROW_MAJOR", "rows": self.rows,
            "columns": self.columns, "size_bytes": len(self.raw), "sha256": self.sha256}

    def column(self, index):
        import numpy as np
        return np.frombuffer(self.raw, dtype="<f8").reshape(self.rows, self.columns)[:, index]

    def __reduce__(self):
        # Normal workers reduce losses before returning. The retained public
        # NONE-evaluator/representative-fit interface can still transport an
        # explicit curve across a process boundary using its original bytes.
        return type(self), (bytes(self.raw), self.rows, self.columns, self.sha256)


class _RetainedRRiskValues(dict):
    """Process-local location of already qualified native GBM STOP matrices."""
    def __init__(self, value, root):
        super().__init__(value)
        self.risk_root = root


def _seal_cox_risk_curve(fit_ids, evaluation_ids, fit_eta, evaluation_eta, maximum):
    """Seal one read-only binary entity before the evaluator reads responses."""
    import numpy as np
    _require(type(maximum) is int and maximum > 0 and fit_ids and evaluation_ids
        and all(isinstance(v, str) and v for v in [*fit_ids, *evaluation_ids])
        and len(fit_ids) == len(set(fit_ids)) and len(evaluation_ids) == len(set(evaluation_ids))
        and not set(fit_ids) & set(evaluation_ids), "F2_COX_RISK_CURVE_SEAL_INVALID")
    matrices = []
    for value, ids in ((fit_eta, fit_ids), (evaluation_eta, evaluation_ids)):
        if not isinstance(value, _CoxRiskMatrix):
            try:
                array_value = np.asarray(value, dtype="<f8", order="C")
            except (TypeError, ValueError) as exc:
                raise ContractError("F2_COX_RISK_CURVE_SEAL_INVALID") from exc
            _require(array_value.shape == (len(ids), maximum) and np.isfinite(array_value).all(),
                "F2_COX_RISK_CURVE_SEAL_INVALID")
            raw = array_value.tobytes(order="C")
            value = _CoxRiskMatrix(raw, len(ids), maximum, sha256_bytes(raw))
        _require(value.rows == len(ids) and value.columns == maximum
            and len(value.raw) == len(ids) * maximum * 8, "F2_COX_RISK_CURVE_SEAL_INVALID")
        matrices.append(value)
    payload = {"schema_version": "2.0.0", "kind": "PADML_F2_COX_RISK_CURVE",
        "fit_ids": list(fit_ids), "evaluation_ids": list(evaluation_ids), "maximum": maximum,
        "fit_eta": matrices[0].descriptor(), "evaluation_eta": matrices[1].descriptor()}
    return {"status": "SEALED", "payload": payload, "sha256": _sha(payload), "matrices": tuple(matrices)}


def _validate_cox_risk_seal(sealed):
    _require(isinstance(sealed, dict) and set(sealed) == {"status", "payload", "sha256", "matrices"}
        and sealed["status"] == "SEALED" and _sha(sealed["payload"]) == sealed["sha256"],
        "F2_COX_RISK_CURVE_NOT_SEALED")
    payload = sealed["payload"]
    _require(isinstance(payload, dict) and set(payload) == {"schema_version", "kind", "fit_ids",
        "evaluation_ids", "maximum", "fit_eta", "evaluation_eta"}
        and payload["schema_version"] == "2.0.0" and payload["kind"] == "PADML_F2_COX_RISK_CURVE"
        and isinstance(sealed["matrices"], tuple) and len(sealed["matrices"]) == 2,
        "F2_COX_RISK_CURVE_NOT_SEALED")
    for value, role in zip(sealed["matrices"], ("fit", "evaluation"), strict=True):
        _require(isinstance(value, _CoxRiskMatrix) and isinstance(value.raw, (bytes, mmap.mmap))
            and memoryview(value.raw).readonly
            and value.descriptor() == payload[role + "_eta"]
            and value.rows == len(payload[role + "_ids"]) and value.columns == payload["maximum"],
            "F2_COX_RISK_CURVE_NOT_SEALED")
    return payload


def _read_operation_local_risk_matrix(
    descriptor: Any,
    root: Path,
    *,
    expected_file_name: str,
    expected_rows: int,
    expected_columns: int,
    retained: bool = False,
) -> _CoxRiskMatrix:
    """Read one exact immutable channel; deletion belongs to its last consumer."""
    _require(type(retained) is bool, "F2_R_RISK_MATRIX_FILE_INVALID")
    keys = {
        "schema_version",
        "kind",
        "encoding",
        "byte_order",
        "row_order",
        "file_name",
        "rows",
        "columns",
        "size_bytes",
        "sha256",
    }
    expected_size = expected_rows * expected_columns * 8
    _require(
        isinstance(descriptor, dict)
        and set(descriptor) == keys
        and descriptor.get("schema_version") == "1.0.0"
        and descriptor.get("kind") == "PADML_F2_OPERATION_LOCAL_RISK_MATRIX"
        and descriptor.get("encoding") == "IEEE754_FLOAT64"
        and descriptor.get("byte_order") == "LITTLE_ENDIAN"
        and descriptor.get("row_order") == "ROW_MAJOR"
        and descriptor.get("file_name") == expected_file_name
        and Path(expected_file_name).name == expected_file_name
        and descriptor.get("rows") == expected_rows
        and descriptor.get("columns") == expected_columns
        and descriptor.get("size_bytes") == expected_size
        and isinstance(descriptor.get("sha256"), str)
        and _HEX64.fullmatch(descriptor["sha256"]) is not None,
        "F2_R_RISK_MATRIX_DESCRIPTOR_INVALID",
    )
    path = root / expected_file_name
    try:
        before = path.lstat()
        _require(
            stat.S_ISREG(before.st_mode)
            and (before.st_nlink >= 1 if retained else before.st_nlink == 1)
            and before.st_size == expected_size,
            "F2_R_RISK_MATRIX_FILE_INVALID",
        )
        descriptor_flags = os.O_RDONLY | os.O_NOFOLLOW
        file_descriptor = os.open(path, descriptor_flags)
        try:
            observed = os.fstat(file_descriptor)
            _require(
                stat.S_ISREG(observed.st_mode)
                and observed.st_nlink == before.st_nlink
                and (observed.st_dev, observed.st_ino)
                == (before.st_dev, before.st_ino)
                and observed.st_size == expected_size,
                "F2_R_RISK_MATRIX_FILE_INVALID",
            )
            # The operation producer has finished writing this single-owner
            # file. Keep its one float64 entity mapped through the numerical
            # consumer instead of allocating a second full byte string.
            raw = mmap.mmap(file_descriptor, 0, access=mmap.ACCESS_READ)
            try:
                _require(len(raw) == expected_size
                    and (sha256_file(path) if retained else sha256_bytes(raw)) == descriptor["sha256"],
                    "F2_R_RISK_MATRIX_FILE_INVALID")
                import numpy as np
                finite = True
                values = np.frombuffer(raw, dtype="<f8")
                try:
                    for start in range(0, values.size, 131072):
                        if not np.isfinite(values[start:start + 131072]).all():
                            finite = False
                            break
                finally:
                    del values
                after = os.fstat(file_descriptor)
                named = path.lstat()
                _require(finite and (after.st_size, after.st_mtime_ns, after.st_ctime_ns,
                    after.st_nlink) == (observed.st_size, observed.st_mtime_ns,
                    observed.st_ctime_ns, observed.st_nlink)
                    and (named.st_dev, named.st_ino, named.st_size, named.st_mtime_ns, named.st_ctime_ns,
                         named.st_nlink) == (after.st_dev, after.st_ino, after.st_size,
                         after.st_mtime_ns, after.st_ctime_ns, after.st_nlink), "F2_R_RISK_MATRIX_FILE_INVALID")
            except BaseException:
                raw.close()
                raise
        finally:
            os.close(file_descriptor)
        return _CoxRiskMatrix(raw, expected_rows, expected_columns, descriptor["sha256"])
    except (OSError, ValueError) as exc:
        raise ContractError("F2_R_RISK_MATRIX_FILE_INVALID") from exc


def _consume_operation_local_risk_channel(
    channel: Any,
    root: Path,
    *,
    expected_prefix: str,
    fit_rows: int,
    evaluation_rows: int,
    columns: int,
    retained: bool = False,
) -> tuple[_CoxRiskMatrix, _CoxRiskMatrix]:
    _require(
        isinstance(channel, dict)
        and set(channel) == {"schema_version", "kind", "fit", "evaluation"}
        and channel.get("schema_version") == "1.0.0"
        and channel.get("kind")
        == "PADML_F2_OPERATION_LOCAL_RISK_MATRIX_CHANNEL",
        "F2_R_RISK_MATRIX_DESCRIPTOR_INVALID",
    )
    fit = _read_operation_local_risk_matrix(
        channel["fit"],
        root,
        expected_file_name=f"{expected_prefix}-fit.bin",
        expected_rows=fit_rows,
        expected_columns=columns,
        retained=retained,
    )
    evaluation = _read_operation_local_risk_matrix(
        channel["evaluation"],
        root,
        expected_file_name=f"{expected_prefix}-evaluation.bin",
        expected_rows=evaluation_rows,
        expected_columns=columns,
        retained=retained,
    )
    return fit, evaluation


def _validate_r_risk_scratch_members(
    root: Path, tasks: Sequence[Mapping[str, Any]], *, retained_risk_root: Path | None = None,
) -> None:
    expected = {"spec.json", "output.json"}
    for task_index, task in enumerate(tasks, start=1):
        producer_kind = task.get("producer_kind", "SURVIVAL")
        if producer_kind == "ELASTIC_INNER_PATH":
            expected.update(
                {
                    f"risk-{task_index:03d}-alpha-{path_index:03d}-{role}.bin"
                    for path_index in range(1, len(task.get("alphas", [])) + 1)
                    for role in ("fit", "evaluation")
                }
            )
        elif producer_kind == "GBM_STOP_CURVE":
            expected.update(
                {
                    f"risk-{task_index:03d}-gbm-fit.bin",
                    f"risk-{task_index:03d}-gbm-evaluation.bin",
                }
            )
    members = {path.name: path.lstat() for path in root.iterdir()}
    if retained_risk_root is not None:
        _require(all(task.get("family") == "GBM_COX" and task.get("producer_kind") == "GBM_STOP_CURVE"
                     for task in tasks)
            and retained_risk_root.is_absolute() and retained_risk_root.is_dir()
            and not retained_risk_root.is_symlink()
            and retained_risk_root.resolve(strict=True) == retained_risk_root,
            "F2_R_RISK_MATRIX_MEMBER_SET_INVALID")
        risks = {name for name in expected if name.endswith(".bin")}
        actual = {p.name: p.lstat() for p in retained_risk_root.glob("risk-*.bin")}
        _require(set(actual) == risks and all(stat.S_ISREG(v.st_mode) for v in actual.values()),
            "F2_R_RISK_MATRIX_MEMBER_SET_INVALID")
        expected -= risks
    native_fit = {"fit-input.rds", "fit.rds"}
    if len(tasks) == 1 and tasks[0].get("family") == "FPM_TVC_SET_A" and set(members) & native_fit:
        expected.update(native_fit)
    _require(
        set(members) == expected
        and all(
            stat.S_ISREG(value.st_mode) and value.st_nlink == 1
            for value in members.values()
        ),
        "F2_R_RISK_MATRIX_MEMBER_SET_INVALID",
    )


def _response_arrays(
    response: Mapping[str, Any], expected_ids: list[str] | None = None
) -> tuple[list[float], list[int]]:
    if "private_bytes" in response:
        raw = response["private_bytes"]
        _require(isinstance(raw, bytes), "F2_EVALUATION_RESPONSE_IDENTITY_INVALID")
    else:
        raw = Path(response["path"]).read_bytes()
    _require(
        sha256_bytes(raw) == response["sha256"]
        and len(raw) == response["size_bytes"],
        "F2_EVALUATION_RESPONSE_IDENTITY_INVALID",
    )
    _, by_id = _response_rows(raw)
    observed_ids = list(by_id)
    _require(
        (expected_ids is None or observed_ids == expected_ids)
        and response.get("row_count") == len(observed_ids)
        and _sha(observed_ids) == response["row_ids_sha256"],
        "F2_EVALUATION_RESPONSE_ROW_IDENTITY_INVALID",
    )
    try:
        times = [float(row["Death_Followup_months"]) for row in by_id.values()]
        events = [int(row["All_Cause_Death"]) for row in by_id.values()]
    except (KeyError, TypeError, ValueError) as exc:
        raise ContractError("F2_EVALUATION_RESPONSE_DOMAIN_INVALID") from exc
    _require(
        all(math.isfinite(value) and value > 0 for value in times)
        and set(events) <= {0, 1},
        "F2_EVALUATION_RESPONSE_DOMAIN_INVALID",
    )
    return times, events


@dataclass(frozen=True)
class _CoxRiskSets:
    order: tuple[int, ...]
    starts: tuple[int, ...]
    failures: tuple[tuple[int, ...], ...]


def _cox_breslow_event_groups(times: list[float], events: list[int]) -> _CoxRiskSets:
    """Linear-size fixed ordering and ties; no quadratic patient-pair materialization."""
    order = tuple(sorted(range(len(times)), key=times.__getitem__))
    starts, failures = [], []
    position = 0
    while position < len(order):
        end = position + 1
        while end < len(order) and times[order[end]] == times[order[position]]:
            end += 1
        deaths = tuple(index for index in order[position:end] if events[index] == 1)
        if deaths:
            starts.append(position)
            failures.append(deaths)
        position = end
    return _CoxRiskSets(order, tuple(starts), tuple(failures))


def _cox_breslow_log_likelihood(times, events, eta, *, event_groups=None) -> float:
    _require(len(times) == len(events) == len(eta) and times
        and all(math.isfinite(value) for value in eta), "F2_COX_RISK_CURVE_EVALUATION_INVALID")
    import numpy as np
    groups = _cox_breslow_event_groups(times, events) if event_groups is None else event_groups
    _require(isinstance(groups, _CoxRiskSets) and len(groups.order) == len(eta),
        "F2_COX_RISK_CURVE_EVALUATION_INVALID")
    # Extended-precision log-addition keeps extreme margins finite without
    # re-scanning or expanding each event's risk set. The outer Breslow sum
    # and the original failure order are unchanged.
    ordered = np.asarray(eta, dtype=np.longdouble)[list(groups.order)]
    suffix = np.logaddexp.accumulate(ordered[::-1])[::-1]
    value = 0.0
    for start, failures in zip(groups.starts, groups.failures, strict=True):
        value += math.fsum(eta[index] for index in failures) - len(failures) * float(suffix[start])
    _require(math.isfinite(value), "F2_COX_RISK_CURVE_EVALUATION_INVALID")
    return value


def _grouped_cox_evaluation_context(
    fit_response: Mapping[str, Any],
    evaluation_response: Mapping[str, Any],
    fit_ids: list[str],
    evaluation_ids: list[str],
    *, evaluation_indices: list[int] | None = None,
) -> dict[str, Any]:
    """Parse response arrays and exact risk sets once per child operation."""

    fit_times, fit_events = _response_arrays(fit_response, fit_ids)
    evaluation_times, evaluation_events = _response_arrays(
        evaluation_response, evaluation_ids
    )
    if evaluation_indices is not None:
        evaluation_times = [evaluation_times[i] for i in evaluation_indices]
        evaluation_events = [evaluation_events[i] for i in evaluation_indices]
    combined_times = [*fit_times, *evaluation_times]
    combined_events = [*fit_events, *evaluation_events]
    return {
        **({"evaluation_indices": evaluation_indices} if evaluation_indices is not None else {}),
        "fit_response_sha256": fit_response["sha256"],
        "evaluation_response_sha256": evaluation_response["sha256"],
        "fit_ids_sha256": _sha(fit_ids),
        "evaluation_ids_sha256": _sha(evaluation_ids),
        "fit_times": fit_times,
        "fit_events": fit_events,
        "evaluation_times": evaluation_times,
        "evaluation_events": evaluation_events,
        "fit_event_groups": _cox_breslow_event_groups(
            fit_times, fit_events
        ),
        "combined_event_groups": _cox_breslow_event_groups(
            combined_times, combined_events
        ),
    }


def _evaluate_grouped_cox_risk_curve(
    sealed: Mapping[str, Any],
    *,
    fit_response: Mapping[str, Any],
    evaluation_response: Mapping[str, Any],
    minimum_improvement: float,
    patience: int,
    family: str = "GBM_COX",
    runtime: Mapping[str, Any] | None = None,
    evaluation_context: Mapping[str, Any] | None = None,
    native_evaluation: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Sole response-reading owner for registered tree stopping curves."""

    _require(
        _finite_number(minimum_improvement)
        and minimum_improvement >= 0
        and isinstance(patience, int)
        and not isinstance(patience, bool)
        and patience > 0,
        "F2_COX_RISK_CURVE_NOT_SEALED",
    )
    _require(
        family in {"GBM_COX", "XGBOOST_COX"},
        "F2_COX_STOPPING_FAMILY_INVALID",
    )
    evaluated = _grouped_cox_loss_path(
        sealed,
        fit_response=fit_response,
        evaluation_response=evaluation_response,
        runtime=runtime,
        xgb_patience=patience if family == "XGBOOST_COX" else None,
        minimum_improvement=float(minimum_improvement),
        evaluation_context=evaluation_context,
    )
    losses = evaluated["losses"]
    if native_evaluation is not None:
        native_evaluation.update(evaluated)
    return _tree_stopping_lock_from_losses(
        losses, risk_curve_sha256=sealed["sha256"],
        fit_response_sha256=fit_response["sha256"],
        evaluation_response_sha256=evaluation_response["sha256"],
        minimum_improvement=minimum_improvement, patience=patience, family=family,
    )


def _tree_stopping_lock_from_losses(
    losses: list[float], *, risk_curve_sha256: str, fit_response_sha256: str,
    evaluation_response_sha256: str, minimum_improvement: float, patience: int, family: str,
) -> dict[str, Any]:
    """Original tree-lock arithmetic, shared with retained audited loss numbers."""
    _require(isinstance(losses, list) and losses and all(_finite_number(value) for value in losses)
             and _finite_number(minimum_improvement) and minimum_improvement >= 0
             and type(patience) is int and patience > 0 and family in {"GBM_COX", "XGBOOST_COX"},
             "F2_TREE_STOPPING_SELECTION_INVALID")
    best, selected, stale, evaluated_tree_count = math.inf, 0, 0, 0
    for tree, loss in enumerate(losses, start=1):
        evaluated_tree_count = tree
        improved = loss < best and best - loss >= float(minimum_improvement)
        if improved:
            best, selected, stale = loss, tree, 0
        else:
            stale += 1
            if stale >= patience:
                break
    _require(selected > 0, "F2_TREE_STOPPING_SELECTION_INVALID")
    selected_field = (
        "selected_trees" if family == "GBM_COX" else "selected_rounds"
    )
    lock = {
        "schema_version": "1.0.0",
        "kind": (
            "PADML_F2_GBM_TREE_LOCK"
            if family == "GBM_COX"
            else "PADML_F2_XGBOOST_ROUND_LOCK"
        ),
        "risk_curve_sha256": risk_curve_sha256,
        "fit_response_sha256": fit_response_sha256,
        "evaluation_response_sha256": evaluation_response_sha256,
        selected_field: selected,
        "evaluated_tree_count": evaluated_tree_count,
        "minimum_grouped_cox_deviance": best,
    }
    return {**lock, "identity": _sha(lock)}


def _grouped_cox_loss_path(
    sealed: Mapping[str, Any],
    *,
    fit_response: Mapping[str, Any],
    evaluation_response: Mapping[str, Any],
    runtime: Mapping[str, Any] | None = None,
    xgb_patience: int | None = None,
    minimum_improvement: float = 0.0,
    evaluation_context: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """The one grouped-Breslow response owner shared by GBM and Elastic Net."""

    payload = sealed.get("payload")
    _require(isinstance(payload, dict), "F2_COX_RISK_CURVE_EVALUATION_INVALID")
    kind = payload.get("kind")
    if kind == "PADML_F2_COX_RISK_CURVE":
        _validate_cox_risk_seal(sealed)
    else:
        _require(
            kind == "PADML_F2_XGBOOST_PREDICTION_FUNCTION"
            and set(sealed) == {"status", "payload", "sha256"}
            and sealed["status"] == "SEALED" and _sha(payload) == sealed["sha256"]
            and set(payload)
            == {
                "schema_version",
                "kind",
                "fit_ids",
                "evaluation_ids",
                "maximum",
                "booster_sha256",
                "cox_objective",
                "design_identity",
                "parameter_sha256",
                "fit_input_identity",
                "seed",
            }
            and payload.get("schema_version") == "1.0.0"
            and isinstance(runtime, Mapping)
            and set(runtime) == {
                "booster",
                "fit_matrix",
                "evaluation_matrix",
            },
            "F2_XGBOOST_FUNCTION_SEAL_INVALID",
        )
        _validate_xgb_cox_objective_health(payload["cox_objective"], payload["maximum"], len(payload["fit_ids"]))
    context = (
        _grouped_cox_evaluation_context(
            fit_response,
            evaluation_response,
            payload["fit_ids"],
            payload["evaluation_ids"],
        )
        if evaluation_context is None
        else dict(evaluation_context)
    )
    _require(
        context.get("fit_response_sha256") == fit_response["sha256"]
        and context.get("evaluation_response_sha256")
        == evaluation_response["sha256"]
        and context.get("fit_ids_sha256") == _sha(payload["fit_ids"])
        and context.get("evaluation_ids_sha256")
        == _sha(payload["evaluation_ids"]),
        "F2_COX_EVALUATION_CONTEXT_IDENTITY_INVALID",
    )
    fit_times = list(context["fit_times"])
    fit_events = list(context["fit_events"])
    evaluation_times = list(context["evaluation_times"])
    evaluation_events = list(context["evaluation_events"])
    _require(
        sum(fit_events) > 0 and sum(evaluation_events) > 0,
        "F2_COX_RISK_CURVE_EVALUATION_INVALID",
    )
    _require(
        xgb_patience is None
        or (
            kind == "PADML_F2_XGBOOST_PREDICTION_FUNCTION"
            and type(xgb_patience) is int
            and xgb_patience > 0
            and isinstance(minimum_improvement, (int, float))
            and not isinstance(minimum_improvement, bool)
            and minimum_improvement >= 0
        ),
        "F2_XGBOOST_STOPPING_POLICY_INVALID",
    )
    combined_times = [*fit_times, *evaluation_times]
    combined_events = [*fit_events, *evaluation_events]
    fit_event_groups = context["fit_event_groups"]
    combined_event_groups = context["combined_event_groups"]
    evaluation_matrix = None
    if kind == "PADML_F2_XGBOOST_PREDICTION_FUNCTION":
        evaluation_matrix = runtime["evaluation_matrix"]
        if "evaluation_indices" in context:
            evaluation_matrix = evaluation_matrix.slice(context["evaluation_indices"])
    losses: list[float] = []
    best = math.inf
    stale = 0
    for tree in range(payload["maximum"]):
        if kind == "PADML_F2_COX_RISK_CURVE":
            fit_eta = sealed["matrices"][0].column(tree)
            evaluation_eta = sealed["matrices"][1].column(tree)
        else:
            booster = runtime["booster"]
            fit_eta = [
                float(value)
                for value in booster.predict(
                    runtime["fit_matrix"],
                    output_margin=True,
                    iteration_range=(0, tree + 1),
                )
            ]
            evaluation_eta = [
                float(value)
                for value in booster.predict(
                    evaluation_matrix,
                    output_margin=True,
                    iteration_range=(0, tree + 1),
                )
            ]
        if "evaluation_indices" in context and evaluation_matrix is None:
            evaluation_eta = evaluation_eta[context["evaluation_indices"]]
        if kind == "PADML_F2_COX_RISK_CURVE":
            import numpy as np
            combined_eta = np.concatenate((fit_eta, evaluation_eta))
        else:
            combined_eta = [*fit_eta, *evaluation_eta]
        fit_log_likelihood = _cox_breslow_log_likelihood(
            fit_times,
            fit_events,
            fit_eta,
            event_groups=fit_event_groups,
        )
        combined_log_likelihood = _cox_breslow_log_likelihood(
            combined_times,
            combined_events,
            combined_eta,
            event_groups=combined_event_groups,
        )
        loss = -2.0 * (combined_log_likelihood - fit_log_likelihood) / len(
            evaluation_times
        )
        _require(math.isfinite(loss), "F2_COX_RISK_CURVE_EVALUATION_INVALID")
        losses.append(loss)
        if xgb_patience is not None:
            improved = (
                loss < best
                if minimum_improvement == 0
                else best - loss >= minimum_improvement
            )
            if improved:
                best = loss
                stale = 0
            else:
                stale += 1
                if stale >= xgb_patience:
                    break
    return {
        "schema_version": "1.0.0",
        "kind": "PADML_F2_GROUPED_COX_LOSS_PATH",
        "risk_curve_sha256": sealed["sha256"],
        "fit_response_sha256": fit_response["sha256"],
        "evaluation_response_sha256": evaluation_response["sha256"],
        "validation_n": len(evaluation_times),
        "losses": losses,
    }


def _elastic_ratios(contract: Mapping[str, Any]) -> list[float]:
    path = contract["ratio_path"]
    _require(
        path["length"] == 150
        and path["formula"] == "10^(-4*(j-1)/149),j=1..150"
        and path["maximum"] == 1
        and path["minimum"] == 0.0001,
        "F2_SELECTOR_RATIO_CONTRACT_INVALID",
    )
    return [10 ** (-4 * index / 149) for index in range(150)]


def _validate_elastic_lambda_upper_bound(
    provenance: Any,
    *,
    alpha: float,
    ordered_parent_column_map: Sequence[Mapping[str, Any]],
    a12: bool = False,
    natural_audit: bool = False,
) -> float:
    """Validate one native glmnet Cox upper bound against its exact design."""

    _require(type(a12) is bool, "F5_A12_ELASTIC_SCOPE_INVALID")
    _require(
        isinstance(provenance, Mapping)
        and set(provenance)
        == {
            "alpha",
            "cox_ties",
            "family",
            "glmnet_big",
            "glmnet_version",
            "kind",
            "penalty_factor_identity_sha256",
            "pilot_lambda_head",
            "pilot_requested_nlambda",
            "pilot_returned_nlambda",
            "resolved_lambda_max",
            "schema_version",
            "sentinel_equivalent",
            "standardize",
        },
        "F2_ELASTIC_LAMBDA_UPPER_BOUND_INVALID",
    )
    head = provenance.get("pilot_lambda_head")
    lambda_max = provenance.get("resolved_lambda_max")
    big = provenance.get("glmnet_big")
    returned_nlambda = provenance.get("pilot_returned_nlambda")
    _require(
        provenance.get("schema_version") == "1.0.0"
        and provenance.get("kind")
        == "PADML_F2_ELASTIC_LAMBDA_UPPER_BOUND_V1"
        and provenance.get("glmnet_version") == "5.0"
        and provenance.get("family") == "cox"
        and provenance.get("cox_ties") == "breslow"
        and _finite_number(provenance.get("alpha"))
        and math.isclose(
            float(provenance["alpha"]), alpha, rel_tol=0.0, abs_tol=1e-15
        )
        and provenance.get("standardize") is True
        and provenance.get("pilot_requested_nlambda") == 100
        and isinstance(returned_nlambda, int)
        and not isinstance(returned_nlambda, bool)
        and returned_nlambda >= 3
        and isinstance(head, list)
        and len(head) == 3
        and all(_finite_number(item) and item > 0 for item in head)
        and all(left > right for left, right in zip(head, head[1:]))
        and _finite_number(lambda_max)
        and lambda_max > 0
        and _finite_number(provenance.get("resolved_lambda_max"))
        and float(provenance["resolved_lambda_max"]) == float(lambda_max)
        and float(head[0]) == float(lambda_max)
        and _finite_number(big)
        and big > 1e30
        and provenance.get("sentinel_equivalent") is False
        and not math.isclose(
            float(lambda_max),
            float(big),
            rel_tol=math.sqrt(sys.float_info.epsilon),
            abs_tol=0.0,
        ),
        "F2_ELASTIC_LAMBDA_SENTINEL_INVALID",
    )
    columns: list[str] = []
    penalties: list[float] = []
    for row in ordered_parent_column_map:
        parent = row.get("parent") if isinstance(row, Mapping) else None
        observed_columns = row.get("columns") if isinstance(row, Mapping) else None
        _require(
            isinstance(parent, str)
            and parent
            and isinstance(observed_columns, list)
            and observed_columns
            and all(isinstance(column, str) and column for column in observed_columns),
            "F2_ELASTIC_PENALTY_IDENTITY_INVALID",
        )
        columns.extend(observed_columns)
        penalties.extend(
            [0.0 if parent == "AST_ALT" and not natural_audit else 1.0] * len(observed_columns)
        )
    if len(columns) == 1:
        _require(
            (columns == ["AST_ALT"] and penalties == [0.0] and not a12)
            or (a12 and columns[0] not in {"AST", "ALT", "AST_ALT", "PADML_GLMNET_INERT_ZERO"}
                and penalties == [1.0]),
            "F2_ELASTIC_PENALTY_IDENTITY_INVALID",
        )
        columns.append("PADML_GLMNET_INERT_ZERO")
        penalties.append(1.0)
    _require(
        provenance.get("penalty_factor_identity_sha256")
        == _sha({"design_columns": columns, "penalty_factor": penalties}),
        "F2_ELASTIC_PENALTY_IDENTITY_INVALID",
    )
    return float(lambda_max)


def _validate_elastic_lambda_path_health(
    value: Any,
    *,
    alpha: float,
    ratios: Sequence[float],
    ordered_parent_column_map: Sequence[Mapping[str, Any]],
    a12: bool = False,
    natural_audit: bool = False,
) -> dict[str, Any]:
    """Validate the glmnet-5 Cox search path at the real R/Python boundary."""

    _require(
        isinstance(value, Mapping)
        and set(value)
        == {
            "lambda_max",
            "lambda_path",
            "lambda_upper_bound",
            "penalized_active_count_path",
            "penalized_design_column_count",
            "penalized_entry_covered",
        }
        and len(ratios) == 150,
        "F2_ELASTIC_LAMBDA_PATH_HEALTH_INVALID",
    )
    provenance = value["lambda_upper_bound"]
    lambda_max = _validate_elastic_lambda_upper_bound(
        provenance,
        alpha=alpha,
        ordered_parent_column_map=ordered_parent_column_map,
        a12=a12,
        natural_audit=natural_audit,
    )
    _require(
        _finite_number(value.get("lambda_max"))
        and float(value["lambda_max"]) == lambda_max,
        "F2_ELASTIC_LAMBDA_UPPER_BOUND_INVALID",
    )
    lambda_path = value.get("lambda_path")
    active_path = value.get("penalized_active_count_path")
    penalized_count = value.get("penalized_design_column_count")
    coverage = value.get("penalized_entry_covered")
    _require(
        isinstance(lambda_path, list)
        and len(lambda_path) == 150
        and all(_finite_number(item) and item > 0 for item in lambda_path)
        and all(
            left > right
            for left, right in zip(lambda_path, lambda_path[1:])
        )
        and all(
            math.isclose(
                float(item),
                float(lambda_max) * float(ratio),
                rel_tol=1e-12,
                abs_tol=1e-15,
            )
            for item, ratio in zip(lambda_path, ratios, strict=True)
        )
        and isinstance(penalized_count, int)
        and not isinstance(penalized_count, bool)
        and penalized_count >= 0
        and isinstance(active_path, list)
        and len(active_path) == 150
        and all(
            isinstance(item, int)
            and not isinstance(item, bool)
            and 0 <= item <= penalized_count
            for item in active_path
        )
        and isinstance(coverage, bool)
        and coverage == (penalized_count > 0 and max(active_path) > 0)
        and (penalized_count == 0 or coverage or natural_audit),
        "F2_ELASTIC_PENALIZED_ENTRY_FRONTIER_INVALID",
    )
    return {
        "lambda_max": float(lambda_max),
        "lambda_path_sha256": _sha(lambda_path),
        "lambda_upper_bound": dict(provenance),
        "penalized_design_column_count": penalized_count,
        "penalized_active_count_path": list(active_path),
        "penalized_entry_covered": coverage,
    }


def _validate_elastic_final_lambda_health(
    value: Any,
    *,
    alpha: float,
    ratio: float,
    ordered_parent_column_map: Sequence[Mapping[str, Any]],
    a12: bool = False,
) -> dict[str, Any]:
    """Validate a locked lambda against its original full-candidate design."""

    _require(
        isinstance(value, Mapping)
        and set(value)
        == {
            "alpha",
            "converged",
            "engine",
            "lambda",
            "lambda_max",
            "lambda_upper_bound",
            "ratio",
        }
        and value.get("engine") == "glmnet::glmnet"
        and value.get("converged") is True,
        "F2_ELASTIC_FINAL_REFIT_INVALID",
    )
    lambda_max = _validate_elastic_lambda_upper_bound(
        value.get("lambda_upper_bound"),
        alpha=alpha,
        ordered_parent_column_map=ordered_parent_column_map,
        a12=a12,
    )
    expected_lambda = lambda_max * ratio
    _require(
        _finite_number(value.get("alpha"))
        and math.isclose(float(value["alpha"]), alpha, rel_tol=0.0, abs_tol=1e-15)
        and _finite_number(value.get("ratio"))
        and math.isclose(float(value["ratio"]), ratio, rel_tol=0.0, abs_tol=1e-15)
        and _finite_number(value.get("lambda_max"))
        and float(value["lambda_max"]) == lambda_max
        and _finite_number(value.get("lambda"))
        and math.isclose(
            float(value["lambda"]), expected_lambda, rel_tol=1e-12, abs_tol=1e-15
        ),
        "F2_ELASTIC_FINAL_REFIT_INVALID",
    )
    return dict(value)


def _validate_r_tree_fit_health(
    family: str,
    value: Any,
    *,
    parameters: Mapping[str, Any],
    ordered_parent_column_map: Sequence[Mapping[str, Any]],
    fit_row_count: int,
    stop_curve: bool,
) -> dict[str, Any]:
    """Recheck native ranger/gbm observations at the R/Python boundary."""

    _require(
        family in {"RSF", "GBM_COX"}
        and isinstance(value, Mapping)
        and isinstance(parameters, Mapping)
        and isinstance(fit_row_count, int)
        and not isinstance(fit_row_count, bool)
        and fit_row_count > 0,
        f"F2_{family}_FIT_HEALTH_INVALID",
    )
    design_column_count = sum(
        len(row.get("columns", []))
        for row in ordered_parent_column_map
        if isinstance(row, Mapping)
    )
    _require(
        design_column_count > 0
        and value.get("converged") is True
        and value.get("warning_count") == 0,
        f"F2_{family}_FIT_HEALTH_INVALID",
    )
    if family == "RSF":
        expected_trees = parameters.get("num_trees")
        fraction = parameters.get("mtry_fraction")
        try:
            expected_mtry = min(
                design_column_count,
                max(
                    1,
                    int(
                        (
                            Decimal(str(fraction))
                            * Decimal(design_column_count)
                        ).quantize(Decimal("1"), rounding=ROUND_HALF_UP)
                    ),
                ),
            )
        except Exception as exc:
            raise ContractError("F2_RSF_FIT_HEALTH_INVALID") from exc
        _require(
            not stop_curve
            and set(value)
            == {
                "converged",
                "death_time_count",
                "engine",
                "independent_variable_count",
                "mtry",
                "num_trees",
                "prediction_error",
                "tree_count",
                "warning_count",
            }
            and value.get("engine") == "ranger::ranger"
            and isinstance(expected_trees, int)
            and not isinstance(expected_trees, bool)
            and value.get("num_trees") == expected_trees
            and value.get("tree_count") == expected_trees
            and value.get("independent_variable_count") == design_column_count
            and value.get("mtry") == expected_mtry
            and isinstance(value.get("death_time_count"), int)
            and value["death_time_count"] > 0
            and _finite_number(value.get("prediction_error")),
            "F2_RSF_FIT_HEALTH_INVALID",
        )
        return dict(value)

    expected_trees = (
        parameters.get("max_trees")
        if stop_curve
        else parameters.get("locked_trees")
    )
    base_keys = {
        "cox_objective",
        "converged",
        "engine",
        "independent_variable_count",
        "maximum_training_loss",
        "minimum_training_loss",
        "training_loss_count",
        "training_row_count",
        "tree_count",
        "warning_count",
    }
    mode_keys = (
        {"stopping_reselected"}
        if stop_curve
        else {
            "selected_trees",
            "stopping_reselected",
            "training_only_stop_count",
        }
    )
    _require(
        set(value) == base_keys | mode_keys
        and value.get("engine") == "gbm::gbm"
        and isinstance(expected_trees, int)
        and not isinstance(expected_trees, bool)
        and value.get("tree_count") == expected_trees
        and value.get("training_loss_count") == expected_trees
        and value.get("training_row_count") == fit_row_count
        and value.get("independent_variable_count") == design_column_count
        and _finite_number(value.get("minimum_training_loss"))
        and _finite_number(value.get("maximum_training_loss"))
        and value["minimum_training_loss"] <= value["maximum_training_loss"]
        and value.get("stopping_reselected") is stop_curve
        and (
            stop_curve
            or (
                value.get("selected_trees") == expected_trees
                and value.get("training_only_stop_count") == 0
            )
        ),
        "F2_GBM_FIT_HEALTH_INVALID",
    )
    _validate_gbm_cox_objective_health(value["cox_objective"])
    return dict(value)


def _validate_gbm_cox_objective_health(value: Any) -> None:
    _require(value == {"implementation": "GROUPED_BRESLOW_V1", "engine_version": "2.3.1.9001",
                       "source_correction": "cox-breslow-ties-v1"},
             "F2_GBM_COX_OBJECTIVE_HEALTH_INVALID")


def _validate_xgb_cox_objective_health(value: Any, rounds: int, rows: int) -> None:
    _require(
        isinstance(value, dict)
        and set(value) == {"implementation", "gradient_evaluations", "training_rows", "event_time_groups"}
        and value.get("implementation") == "GROUPED_BRESLOW_FLOAT64_TIME_V1"
        and type(value.get("gradient_evaluations")) is int
        and value["gradient_evaluations"] == rounds
        and type(value.get("training_rows")) is int
        and value["training_rows"] == rows
        and type(value.get("event_time_groups")) is int
        and 1 <= value["event_time_groups"] <= rows,
        "F2_XGBOOST_COX_OBJECTIVE_HEALTH_INVALID",
    )


def _validate_python_fit_health(
    family: str,
    value: Any,
    *,
    locked_value: int,
    training_count: int,
    evaluation_count: int,
) -> dict[str, Any]:
    """Validate observed native Python-engine fit health before sealing."""

    _require(
        family in {"XGBOOST_COX", "COXTIME_SET_A"}
        and isinstance(value, Mapping)
        and isinstance(locked_value, int)
        and not isinstance(locked_value, bool)
        and locked_value > 0
        and isinstance(training_count, int)
        and training_count > 0
        and isinstance(evaluation_count, int)
        and evaluation_count > 0
        and value.get("converged") is True,
        f"F2_{family}_FIT_HEALTH_INVALID",
    )
    if family == "XGBOOST_COX":
        _require(
            set(value)
            == {
                "booster_round_count",
                "converged",
                "engine",
                "evaluation_margin_count",
                "model_binary_sha256",
                "objective",
                "cox_objective",
                "training_margin_count",
            }
            and value.get("engine") == "xgboost survival:cox"
            and value.get("objective") == "survival:cox"
            and value.get("booster_round_count") == locked_value
            and value.get("training_margin_count") == training_count
            and value.get("evaluation_margin_count") == evaluation_count
            and isinstance(value.get("model_binary_sha256"), str)
            and _HEX64.fullmatch(value["model_binary_sha256"]) is not None,
            "F2_XGBOOST_FIT_HEALTH_INVALID",
        )
        _validate_xgb_cox_objective_health(value["cox_objective"], locked_value, training_count)
    else:
        _require(
            set(value)
            == {
                "converged",
                "engine",
                "evaluation_row_count",
                "final_training_loss",
                "model_state_sha256",
                "raw_survival_grid_validated",
                "baseline_numerics",
                "training_epoch_count",
                "training_row_count",
            }
            and value.get("engine") == "pycox.models.CoxTime"
            and value.get("training_epoch_count") == locked_value
            and value.get("training_row_count") == training_count
            and value.get("evaluation_row_count") == evaluation_count
            and _finite_number(value.get("final_training_loss"))
            and value.get("raw_survival_grid_validated") is True
            and isinstance(value.get("model_state_sha256"), str)
            and _HEX64.fullmatch(value["model_state_sha256"]) is not None,
            "F2_COXTIME_FIT_HEALTH_INVALID",
        )
        _validate_coxtime_baseline_health(value["baseline_numerics"], training_count)
    return dict(value)


def _sample_sd(values: list[float]) -> float:
    _require(len(values) >= 2, "F2_SELECTOR_REPEAT_DENOMINATOR_INVALID")
    mean = sum(values) / len(values)
    return math.sqrt(sum((value - mean) ** 2 for value in values) / (len(values) - 1))


def _pairwise_jaccard(sets: list[set[str]]) -> float:
    values: list[float] = []
    for left in range(len(sets)):
        for right in range(left + 1, len(sets)):
            union = sets[left] | sets[right]
            values.append(1.0 if not union else len(sets[left] & sets[right]) / len(union))
    return sum(values) / len(values)


def _validate_sealed_elastic_lambda_path_health(
    value: Any,
    *,
    alpha: float,
    ratios: Sequence[float],
    imputation: int,
    natural_audit: bool = False,
) -> dict[str, Any]:
    _require(
        isinstance(value, Mapping)
        and set(value)
        == {
            "imputation",
            "lambda_max",
            "lambda_path_sha256",
            "lambda_upper_bound",
            "penalized_active_count_path",
            "penalized_design_column_count",
            "penalized_entry_covered",
        }
        and value.get("imputation") == imputation,
        "F2_SELECTOR_LAMBDA_PATH_HEALTH_INVALID",
    )
    provenance = value.get("lambda_upper_bound")
    head = provenance.get("pilot_lambda_head") if isinstance(provenance, Mapping) else None
    lambda_max = value.get("lambda_max")
    big = provenance.get("glmnet_big") if isinstance(provenance, Mapping) else None
    active_path = value.get("penalized_active_count_path")
    penalized_count = value.get("penalized_design_column_count")
    expected_path = (
        [float(lambda_max) * float(ratio) for ratio in ratios]
        if _finite_number(lambda_max)
        else []
    )
    _require(
        isinstance(provenance, Mapping)
        and provenance.get("schema_version") == "1.0.0"
        and provenance.get("kind")
        == "PADML_F2_ELASTIC_LAMBDA_UPPER_BOUND_V1"
        and provenance.get("glmnet_version") == "5.0"
        and provenance.get("family") == "cox"
        and provenance.get("cox_ties") == "breslow"
        and provenance.get("standardize") is True
        and provenance.get("pilot_requested_nlambda") == 100
        and isinstance(provenance.get("pilot_returned_nlambda"), int)
        and not isinstance(provenance.get("pilot_returned_nlambda"), bool)
        and provenance["pilot_returned_nlambda"] >= 3
        and _finite_number(provenance.get("alpha"))
        and math.isclose(
            float(provenance["alpha"]), alpha, rel_tol=0.0, abs_tol=1e-15
        )
        and isinstance(head, list)
        and len(head) == 3
        and all(_finite_number(item) and item > 0 for item in head)
        and all(left > right for left, right in zip(head, head[1:]))
        and _finite_number(lambda_max)
        and lambda_max > 0
        and float(head[0]) == float(lambda_max)
        and _finite_number(provenance.get("resolved_lambda_max"))
        and float(provenance.get("resolved_lambda_max")) == float(lambda_max)
        and _finite_number(big)
        and big > 1e30
        and provenance.get("sentinel_equivalent") is False
        and not math.isclose(
            float(lambda_max),
            float(big),
            rel_tol=math.sqrt(sys.float_info.epsilon),
            abs_tol=0.0,
        )
        and isinstance(provenance.get("penalty_factor_identity_sha256"), str)
        and bool(_HEX64.fullmatch(provenance["penalty_factor_identity_sha256"]))
        and isinstance(value.get("lambda_path_sha256"), str)
        and bool(_HEX64.fullmatch(value["lambda_path_sha256"]))
        and isinstance(penalized_count, int)
        and not isinstance(penalized_count, bool)
        and penalized_count > 0
        and isinstance(active_path, list)
        and len(active_path) == 150
        and all(
            isinstance(item, int)
            and not isinstance(item, bool)
            and 0 <= item <= penalized_count
            for item in active_path
        )
        and value.get("penalized_entry_covered") == (max(active_path) > 0)
        and (max(active_path) > 0 or natural_audit)
        and all(
            left > right
            for left, right in zip(expected_path, expected_path[1:])
        ),
        "F2_SELECTOR_LAMBDA_PATH_HEALTH_INVALID",
    )
    return dict(provenance)


def _elastic_imputation_decisions(
    ratios: list[float], mi_repeat_paths: list[list[list[float]]],
    active_df_paths: list[list[int]], event_counts: list[int], contract: Mapping[str, Any],
    *, fixed_a12: Mapping[str, Any] | None = None,
    no_aar_redevelopment: bool = False,
) -> tuple[list[dict[str, Any]], list[int]]:
    """Original 1SE arithmetic after the caller validates complete native inputs."""
    _require(type(no_aar_redevelopment) is bool and not (fixed_a12 is not None and no_aar_redevelopment),
             "NESTED_NO_AAR_SELECTOR_SCOPE_CONFLICT")
    natural_audit = contract.get("ast_alt_natural_audit", False)
    decisions = []
    selected_indices = []
    for imputation, (repeat_paths, active_df, event_count) in enumerate(
        zip(mi_repeat_paths, active_df_paths, event_counts, strict=True), start=1
    ):
        mean_loss = [sum(values) / 3 for values in zip(*repeat_paths, strict=True)]
        repeat_se = [_sample_sd(list(values)) / math.sqrt(3)
                     for values in zip(*repeat_paths, strict=True)]
        _require(
            all(_finite_number(value) for value in [*mean_loss, *repeat_se]),
            "F2_SELECTOR_LOSS_AGGREGATION_NONFINITE",
        )
        _require(all(type(df) is int and df >= (0 if fixed_a12 is not None or no_aar_redevelopment or natural_audit else 1)
                     for df in active_df), "F2_SELECTOR_ACTIVE_DF_INVALID")
        feasible = [index for index, df in enumerate(active_df)
                    if ((df == 0 or event_count / df >= contract["epv_contract"]["minimum"])
                        if fixed_a12 is None else
                        df * contract["epv_contract"]["minimum"] <= event_count)]
        if natural_audit:
            feasible = [index for index in feasible if active_df[index] > 0]
        decision = {
            "imputation": imputation,
            "repeat_loss_paths": repeat_paths,
            "mean_loss_path": mean_loss,
            "repeat_se_path": repeat_se,
            "active_design_df_path": active_df,
            "feasible_ratio_count": len(feasible),
            "status": ("FEASIBLE" if feasible else "NO_NONZERO_PATH" if natural_audit and not any(active_df)
                       else "EPV_INFEASIBLE"),
        }
        if feasible:
            minimum = min(mean_loss[index] for index in feasible)
            best = min(index for index in feasible if mean_loss[index] == minimum)
            half = min(index for index in feasible
                       if mean_loss[index] <= minimum + 0.5 * repeat_se[best])
            one = min(index for index in feasible
                      if mean_loss[index] <= minimum + repeat_se[best])
            selected_indices.append(one)
            decision.update({
                "r_min": ratios[best], "r_0_5se": ratios[half],
                "r_1se": ratios[one], "selected_mean_loss": mean_loss[one],
                "selected_active_design_df": active_df[one],
                **({"selected_active_epv": event_count / active_df[one] if active_df[one] else None}
                   if fixed_a12 is None else {}),
                **({"zero_active_columns": active_df[one] == 0} if no_aar_redevelopment else {}),
            })
        decisions.append(decision)
    return decisions, selected_indices


def _elastic_alpha_numeric_summary(
    alpha: float, ratios: list[float], decisions: list[dict[str, Any]],
    selected_indices: list[int], event_counts: list[int], parent_columns: Mapping[str, int],
    lambda_maxima: list[float], lambda_upper_bounds: list[dict[str, Any]],
    selected_coefficients: list[dict[str, list[float]]], contract: Mapping[str, Any],
    *, fixed_a12: Mapping[str, Any] | None = None,
    no_aar_redevelopment: bool = False,
    common_set_epv_binding: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Use actual selected-lambda coefficient slices, never proxy coefficients."""
    _require(type(no_aar_redevelopment) is bool and not (fixed_a12 is not None and no_aar_redevelopment),
             "NESTED_NO_AAR_SELECTOR_SCOPE_CONFLICT")
    if common_set_epv_binding is not None:
        from .nested_loco import _validate_outer4_common_set_epv_binding
        common_set_epv_binding = _validate_outer4_common_set_epv_binding(common_set_epv_binding)
        _require(no_aar_redevelopment and fixed_a12 is None and len(event_counts) == 20
                 and all(type(value) is int and value == common_set_epv_binding["exception"]["outer_training_event_count"]
                         for value in event_counts)
                 and contract["epv_contract"]["minimum"] == 15,
                 "NESTED_OUTER4_COMMON_SETA_EPV_SOURCE_INVALID")
    summary = {
        "alpha": float(alpha),
        "ratios": ratios,
        "imputation_decisions": decisions,
        "outer_training_event_count": event_counts[0],
        "status": "EPV_INFEASIBLE",
        "reason_code": "IMPUTATION_HAS_NO_EPV_FEASIBLE_RATIO",
        "diagnostics_selection_effect": "NONE",
        "partition_count": 15,
        "mi_partition_loss_count": 300,
        **({"common_set_epv_binding": dict(common_set_epv_binding)}
           if common_set_epv_binding is not None else {}),
    }
    natural_audit = contract.get("ast_alt_natural_audit", False)
    if natural_audit and any(row["status"] == "NO_NONZERO_PATH" for row in decisions):
        return {**summary, "status": "NOT_ESTIMABLE", "reason_code": "NO_NONZERO_PATH", "common_set_epv": None}
    if len(selected_indices) != 20:
        return summary

    if fixed_a12 is not None:
        if event_counts[0] < fixed_a12["common_set_design_df"] * contract["epv_contract"]["minimum"]:
            return {**summary, "reason_code": "COMMON_SETA_EPV_BELOW_MINIMUM",
                    "common_set_design_df": fixed_a12["common_set_design_df"],
                    "common_set_epv": event_counts[0] / fixed_a12["common_set_design_df"]}
        active = [row["selected_active_design_df"] for row in decisions]
        ordered = sorted(active)
        return {**summary, "status": "FEASIBLE", "reason_code": "OK",
            "r_min_by_imputation": [row["r_min"] for row in decisions],
            "r_0_5se_by_imputation": [row["r_0_5se"] for row in decisions],
            "selected_ratio_by_imputation": [row["r_1se"] for row in decisions],
            "mean_loss_at_selected_parameters": sum(row["selected_mean_loss"] for row in decisions) / 20,
            "active_design_df_by_imputation": active,
            "median_active_design_df": (ordered[9] + ordered[10]) / 2,
            "p90_active_design_df": ordered[17],
            "common_set_design_df": fixed_a12["common_set_design_df"],
            "common_set_epv": event_counts[0] / fixed_a12["common_set_design_df"],
            "selected_parents": list(fixed_a12["selected_parents"]),
            "lambda_by_imputation": [value * ratios[index] for value, index in
                                      zip(lambda_maxima, selected_indices, strict=True)],
            "lambda_upper_bound_by_imputation": lambda_upper_bounds,
            "seta_writeback": "FORBIDDEN", "parent_reselection_count": 0}

    imputation_sets = []
    parent_signs: dict[str, list[int]] = {parent: [] for parent in parent_columns}
    for path in selected_coefficients:
        selected = set()
        for parent, vector in path.items():
            nonzero = [value for value in vector if value != 0]
            if nonzero:
                selected.add(parent)
                parent_signs[parent].append(1 if sum(nonzero) > 0 else -1)
        if not natural_audit:
            selected.discard("AST_ALT")
        imputation_sets.append(selected)
    frequencies = {parent: sum(parent in selected for selected in imputation_sets)
                   for parent in parent_columns if parent != "AST_ALT" or natural_audit}
    frequency = contract.get("frequency_threshold", 12)
    formal_frequency = contract.get("formal_frequency_policy")
    if formal_frequency is not None:
        from .nested_loco import selector_frequency_policy
        _require(formal_frequency == selector_frequency_policy()["identity_sha256"]
                 and type(frequency) is int and frequency in (12, 14, 16, 18, 20)
                 and not natural_audit and fixed_a12 is None,
                 "NESTED_SELECTOR_FREQUENCY_POLICY_INVALID")
    else:
        _require(frequency == 12, "NESTED_SELECTOR_FREQUENCY_POLICY_REQUIRED")
    selected_parents = sorted(
        {*([] if no_aar_redevelopment or natural_audit else ["AST_ALT"]),
         *(parent for parent, count in frequencies.items() if count >= frequency)},
        key=lambda value: value.encode("utf-8"),
    )
    common_df = sum(parent_columns[parent] for parent in selected_parents)
    # An empty fresh SetA cannot be turned into a fixed replacement predictor,
    # baseline-only family or a tuning exclusion disguised as EPV failure.
    if natural_audit and common_df == 0:
        return {**summary, "status": "NOT_ESTIMABLE", "reason_code": "EMPTY_NATURAL_SET",
                "common_set_design_df": 0, "common_set_epv": None, "natural_frequency": frequencies,
                "selected_ratio_by_imputation": [row["r_1se"] for row in decisions],
                "lambda_by_imputation": [value * ratios[index] for value, index in zip(lambda_maxima, selected_indices, strict=True)],
                "ast_alt_coefficients_by_imputation": [p["AST_ALT"] for p in selected_coefficients],
                "ast_alt_nonzero_count": frequencies["AST_ALT"], "primary_writeback": "FORBIDDEN"}
    _require(common_df > 0 or formal_frequency is not None, "NESTED_NO_AAR_SELECTOR_EMPTY_SETA")
    active_dfs = [row["selected_active_design_df"] for row in decisions]
    ordered_dfs = sorted(active_dfs)
    median_df = (ordered_dfs[9] + ordered_dfs[10]) / 2
    p90_df = ordered_dfs[17]
    common_epv = event_counts[0] / common_df if common_df else None
    common_feasible = common_df > 0 and event_counts[0] >= common_df * contract["epv_contract"]["minimum"]
    common_exception = common_set_epv_binding is not None and not common_feasible
    summary.update({
        "status": ("NOT_ESTIMABLE" if common_df == 0 else
                   "FEASIBLE" if common_feasible or common_exception else "EPV_INFEASIBLE"),
        "reason_code": ("EMPTY_FREQUENCY_AGGREGATE" if common_df == 0 else
                        "USER_CONFIRMED_COMMON_SETA_EPV_EXCEPTION" if common_exception else
                        "OK" if common_feasible else "COMMON_SETA_EPV_BELOW_MINIMUM"),
        **({"frequency_threshold": frequency, "frequency_policy_sha256": formal_frequency}
           if formal_frequency is not None else {}),
        **({"common_set_epv_exception_applied": common_exception,
            "original_common_set_epv_minimum": contract["epv_contract"]["minimum"]}
           if common_set_epv_binding is not None else {}),
        "r_min_by_imputation": [row["r_min"] for row in decisions],
        "r_0_5se_by_imputation": [row["r_0_5se"] for row in decisions],
        "selected_ratio_by_imputation": [row["r_1se"] for row in decisions],
        "mean_loss_at_selected_parameters": sum(row["selected_mean_loss"] for row in decisions) / 20,
        "active_design_df_by_imputation": active_dfs,
        "median_active_design_df": median_df,
        "p90_active_design_df": p90_df,
        "median_active_epv": event_counts[0] / median_df if median_df else None,
        "conservative_active_epv": event_counts[0] / p90_df if p90_df else None,
        "common_set_design_df": common_df,
        "common_set_epv": common_epv,
        "selected_parents": selected_parents,
        "natural_frequency": frequencies,
        "jaccard_diagnostic": _pairwise_jaccard([s - {"AST_ALT"} for s in imputation_sets]),
        "jaccard_empty_set_vacuous": all(not (s - {"AST_ALT"}) for s in imputation_sets),
        "direction_diagnostic_flags": {
            parent: (max(signs.count(1), signs.count(-1)) / len(signs)
                     >= contract["diagnostics"]["direction_consistency"]["flag_threshold"]
                     if signs and parent_columns[parent] == 1 else None)
            for parent, signs in parent_signs.items() if parent != "AST_ALT"
        },
        "lambda_by_imputation": [value * ratios[index] for value, index in
                                  zip(lambda_maxima, selected_indices, strict=True)],
        "lambda_upper_bound_by_imputation": lambda_upper_bounds,
        **({"ast_alt_nonzero_count": frequencies["AST_ALT"],
            "ast_alt_coefficients_by_imputation": [p["AST_ALT"] for p in selected_coefficients],
            "primary_writeback": "FORBIDDEN", "natural_audit": True} if natural_audit else {}),
        **({"selector_domain": "FRESH_ALL_LEGAL_NON_AAR_PARENTS",
            "forced_parent": None, "seta_writeback": "FORBIDDEN"}
           if no_aar_redevelopment else {}),
    })
    return summary


def _summarize_elastic_alpha(
    alpha_record: Mapping[str, Any],
    contract: Mapping[str, Any],
    *, fixed_a12: Mapping[str, Any] | None = None,
    no_aar_redevelopment: Mapping[str, Any] | None = None,
    common_set_epv_binding: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    natural_audit = contract.get("ast_alt_natural_audit", False)
    # A12 uses this same original 3-repeat arithmetic, but never its 12/20
    # parent reselection. The caller binds the fixed original-outer domain.
    _require(not (fixed_a12 is not None and no_aar_redevelopment is not None),
             "NESTED_NO_AAR_SELECTOR_SCOPE_CONFLICT")
    _require(common_set_epv_binding is None or no_aar_redevelopment is not None and fixed_a12 is None,
             "NESTED_OUTER4_COMMON_SETA_EPV_SOURCE_INVALID")
    if no_aar_redevelopment is not None:
        columns = no_aar_redevelopment.get("parent_design_columns")
        events = no_aar_redevelopment.get("outer_training_event_count")
        _require(
            set(no_aar_redevelopment) == {"parent_design_columns", "outer_training_event_count"}
            and isinstance(columns, Mapping) and columns
            and not {"AST", "ALT", "AST_ALT"}.intersection(columns)
            and all(isinstance(parent, str) and parent and type(count) is int and count > 0
                    for parent, count in columns.items())
            and type(events) is int and events > 0,
            "NESTED_NO_AAR_SELECTOR_DOMAIN_INVALID",
        )
    if fixed_a12 is not None:
        columns = fixed_a12.get("parent_design_columns")
        events = fixed_a12.get("outer_training_event_count")
        _require(isinstance(columns, Mapping) and columns
                 and not {"AST", "ALT", "AST_ALT"}.intersection(columns)
                 and all(isinstance(parent, str) and parent and type(count) is int and count > 0
                         for parent, count in columns.items())
                 and fixed_a12.get("selected_parents") == list(columns)
                 and type(events) is int and events > 0
                 and fixed_a12.get("common_set_design_df") == sum(columns.values())
                 ,
                 "F5_A12_FIXED_ELASTIC_DOMAIN_INVALID")
    ratios = _elastic_ratios(contract)
    partitions = alpha_record.get("partition_losses")
    outer_paths = alpha_record.get("outer_paths")
    alpha = alpha_record.get("alpha")
    _require(
        isinstance(alpha, (int, float))
        and not isinstance(alpha, bool)
        and 0.01 <= float(alpha) <= 1
        and isinstance(partitions, list)
        and len(partitions) == 15
        and isinstance(outer_paths, list)
        and len(outer_paths) == 20,
        "F2_SELECTOR_ALPHA_INPUT_INVALID",
    )
    partition_by_key: dict[tuple[int, int], Mapping[str, Any]] = {}
    for row in partitions:
        key = (row.get("repeat"), row.get("inner_fold"))
        losses = row.get("mi_losses")
        health = row.get("mi_lambda_path_health")
        _require(
            key[0] in range(1, 4)
            and key[1] in range(1, 6)
            and key not in partition_by_key
            and isinstance(row.get("validation_n"), int)
            and not isinstance(row.get("validation_n"), bool)
            and row["validation_n"] > 0
            and isinstance(losses, list)
            and len(losses) == 20
            and all(
                isinstance(values, list)
                and len(values) == 150
                and all(
                    isinstance(value, (int, float))
                    and not isinstance(value, bool)
                    and math.isfinite(value)
                    for value in values
                )
                for values in losses
            )
            and isinstance(health, list)
            and len(health) == 20,
            "F2_SELECTOR_PARTITION_LOSS_INVALID",
        )
        for imputation, path_health in enumerate(health, start=1):
            _validate_sealed_elastic_lambda_path_health(
                path_health,
                alpha=float(alpha),
                ratios=ratios,
                imputation=imputation, natural_audit=natural_audit,
            )
        partition_by_key[key] = row
    _require(
        set(partition_by_key)
        == {(repeat, inner_fold) for repeat in range(1, 4) for inner_fold in range(1, 6)},
        "F2_SELECTOR_PARTITION_DENOMINATOR_INVALID",
    )
    mi_repeat_paths: list[list[list[float]]] = []
    for imputation in range(20):
        repeat_paths = []
        for repeat in range(1, 4):
            rows = [partition_by_key[(repeat, inner)] for inner in range(1, 6)]
            denominator = sum(row["validation_n"] for row in rows)
            repeat_paths.append([
                sum(row["validation_n"] * row["mi_losses"][imputation][index]
                    for row in rows) / denominator
                for index in range(150)
            ])
        mi_repeat_paths.append(repeat_paths)

    parent_columns: dict[str, int] | None = None
    coefficients: list[dict[str, list[list[float]]]] = []
    lambda_maxima: list[float] = []
    lambda_upper_bounds: list[dict[str, Any]] = []
    event_counts: list[int] = []
    for imputation, row in enumerate(outer_paths, start=1):
        observed_columns = row.get("parent_design_columns")
        observed_coefficients = row.get("parent_coefficients")
        lambda_upper_bound = _validate_sealed_elastic_lambda_path_health(
            {
                "imputation": row.get("imputation"),
                "lambda_max": row.get("lambda_max"),
                "lambda_path_sha256": row.get("lambda_path_sha256"),
                "lambda_upper_bound": row.get("lambda_upper_bound"),
                "penalized_active_count_path": row.get(
                    "penalized_active_count_path"
                ),
                "penalized_design_column_count": row.get(
                    "penalized_design_column_count"
                ),
                "penalized_entry_covered": row.get(
                    "penalized_entry_covered"
                ),
            },
            alpha=float(alpha),
            ratios=ratios,
            imputation=imputation, natural_audit=natural_audit,
        )
        _require(
            row.get("imputation") == imputation
            and isinstance(row.get("lambda_max"), (int, float))
            and not isinstance(row.get("lambda_max"), bool)
            and math.isfinite(row["lambda_max"])
            and row["lambda_max"] > 0
            and isinstance(row.get("event_count"), int)
            and not isinstance(row.get("event_count"), bool)
            and row["event_count"] > 0
            and isinstance(observed_columns, dict)
            and observed_columns
            and all(
                isinstance(name, str)
                and name
                and isinstance(count, int)
                and not isinstance(count, bool)
                and count > 0
                for name, count in observed_columns.items()
            )
            and isinstance(observed_coefficients, dict)
            and set(observed_coefficients) == set(observed_columns)
            and all(
                isinstance(path, list)
                and len(path) == 150
                and all(
                    isinstance(vector, list)
                    and len(vector) == observed_columns[parent]
                    and all(
                        isinstance(value, (int, float))
                        and not isinstance(value, bool)
                        and math.isfinite(value)
                        for value in vector
                    )
                    for vector in path
                )
                for parent, path in observed_coefficients.items()
            ),
            "F2_SELECTOR_OUTER_PATH_INVALID",
        )
        if parent_columns is None:
            parent_columns = dict(observed_columns)
        _require(
            observed_columns == parent_columns,
            "F2_SELECTOR_OUTER_DESIGN_DRIFT",
        )
        coefficients.append(observed_coefficients)
        lambda_maxima.append(float(row["lambda_max"]))
        lambda_upper_bounds.append(lambda_upper_bound)
        event_counts.append(row["event_count"])
    assert parent_columns is not None
    _require(
        len(set(event_counts)) == 1 and (
            (parent_columns == no_aar_redevelopment["parent_design_columns"]
             and event_counts[0] == no_aar_redevelopment["outer_training_event_count"])
            if no_aar_redevelopment is not None else
            "AST_ALT" in parent_columns if fixed_a12 is None else
            parent_columns == fixed_a12["parent_design_columns"]
            and event_counts[0] == fixed_a12["outer_training_event_count"]),
        "F2_SELECTOR_OUTER_DENOMINATOR_INVALID",
    )

    # Check every byte-derived path before classifying scientific infeasibility.
    # Missing or non-finite computation is an error, never a rejected candidate.
    for row, path in zip(outer_paths, coefficients, strict=True):
        active = [
            sum(value != 0 for parent, vectors in path.items()
                if parent != "AST_ALT" or natural_audit for value in vectors[index])
            for index in range(150)
        ]
        _require(
            row.get("penalized_active_count_path") == active
            and row.get("coefficient_path_sha256") == _sha({
                "parent_design_columns": parent_columns,
                "parent_coefficients": path,
            }),
            "F2_SELECTOR_COEFFICIENT_REPLAY_MISMATCH",
        )

    # Forced AST_ALT counts even if its fitted coefficient is exactly zero.
    active_df_paths = [[(0 if natural_audit else parent_columns.get("AST_ALT", 0)) + sum(
        value != 0 for parent, vectors in path.items()
        if parent != "AST_ALT" or natural_audit for value in vectors[index]
    ) for index in range(150)] for path in coefficients]
    decisions, selected_indices = _elastic_imputation_decisions(
        ratios, mi_repeat_paths, active_df_paths, event_counts, contract, fixed_a12=fixed_a12,
        no_aar_redevelopment=no_aar_redevelopment is not None)
    selected_coefficients = ([{parent: vectors[index] for parent, vectors in path.items()}
                              for path, index in zip(coefficients, selected_indices, strict=True)]
                             if len(selected_indices) == 20 else [])
    return _elastic_alpha_numeric_summary(
        float(alpha), ratios, decisions, selected_indices, event_counts, parent_columns,
        lambda_maxima, lambda_upper_bounds, selected_coefficients, contract, fixed_a12=fixed_a12,
        no_aar_redevelopment=no_aar_redevelopment is not None,
        **({"common_set_epv_binding": common_set_epv_binding} if common_set_epv_binding is not None else {}))


def _choose_elastic_coarse_epv_tier(
    alpha_records, expected_alphas, contract, *,
    no_aar_redevelopment=None, summarize=None, choose=None,
    formal_frequency_fallback=False,
):
    """Reduce the same complete coarse paths at 15, then only if necessary 10.

    Raw path production keeps the original contract. Missing or invalid paths
    raise in the original numerical reader before any feasibility decision.
    Legacy F2 never calls this new-program helper.
    """
    coarse = [float(value) for value in contract["alpha_grid"]["coarse"]]
    _require(expected_alphas == coarse and len(alpha_records) == len(coarse)
             and [float(row.get("alpha", -1)) for row in alpha_records] == coarse
             and contract["epv_contract"]["minimum"] == 15,
             "NESTED_EPV_COARSE_GRID_INVALID")
    _require(type(formal_frequency_fallback) is bool and (not formal_frequency_fallback
             or summarize is None and choose is None and not contract.get("ast_alt_natural_audit")),
             "NESTED_SELECTOR_FREQUENCY_SCOPE_INVALID")
    if formal_frequency_fallback:
        from .nested_loco import selector_frequency_policy
        policy = selector_frequency_policy()
    records_sha256 = _sha(alpha_records)
    attempts = []
    ten_summaries = None
    columns = alpha_records[0]["outer_paths"][0]["parent_design_columns"]
    ladder = ((15, 12), (10, 12), (10, 14), (10, 16), (10, 18), (10, 20)) if formal_frequency_fallback else ((15, 12), (10, 12))
    for minimum, frequency in ladder:
        resolved = {
            **contract,
            "epv_contract": {**contract["epv_contract"], "minimum": minimum},
            "ratio_decision": {**contract["ratio_decision"], "epv_minimum": minimum},
            **({"formal_frequency_policy": policy["identity_sha256"], "frequency_threshold": frequency}
               if formal_frequency_fallback else {}),
        }
        summaries = ([
            (_summarize_elastic_alpha(row, resolved,
                no_aar_redevelopment=no_aar_redevelopment)
             if summarize is None else summarize(row, resolved))
            for row in alpha_records
        ] if frequency == 12 else [
            _elastic_frequency_summary(row, columns, frequency,
                no_aar_redevelopment=no_aar_redevelopment is not None) for row in ten_summaries])
        if minimum == 10 and frequency == 12:
            ten_summaries = summaries
        _require(len({row["outer_training_event_count"] for row in summaries}) == 1
                 and len({_sha(row["outer_paths"][0]["parent_design_columns"])
                          for row in alpha_records}) == 1,
                 "F2_SELECTOR_ALPHA_POPULATION_OR_DESIGN_DRIFT")
        _require(all(row["status"] == "FEASIBLE" or (
            row["status"] == "EPV_INFEASIBLE" and row["reason_code"] in {
                "IMPUTATION_HAS_NO_EPV_FEASIBLE_RATIO", "COMMON_SETA_EPV_BELOW_MINIMUM"})
            or (contract.get("ast_alt_natural_audit") and row["status"] == "NOT_ESTIMABLE"
                and row["reason_code"] in {"NO_NONZERO_PATH", "EMPTY_NATURAL_SET"})
            or (formal_frequency_fallback and row["status"] == "NOT_ESTIMABLE"
                and row["reason_code"] == "EMPTY_FREQUENCY_AGGREGATE")
            for row in summaries), "NESTED_EPV_FALLBACK_REASON_INVALID")
        attempts.append({"minimum": minimum,
            **({"frequency_threshold": frequency} if formal_frequency_fallback else {}),
            "alpha_feasibility": [
            {key: row[key] for key in (("alpha", "status", "reason_code", "common_set_design_df", "common_set_epv")
                if formal_frequency_fallback else ("alpha", "status", "reason_code")) if key in row}
            for row in summaries]})
        if any(row["status"] == "FEASIBLE" for row in summaries):
            chosen = (_choose_elastic_summary(summaries) if choose is None else choose(summaries))
            trace = {
                "preferred_minimum": 15, "minimum": minimum,
                "fallback_used": minimum == 10,
                "coarse_records_sha256": records_sha256, "attempts": attempts,
                **({"frequency_threshold": frequency, "frequency_policy_sha256": policy["identity_sha256"]}
                   if formal_frequency_fallback else {}),
            }
            return chosen, summaries, trace, resolved
        if contract.get("ast_alt_natural_audit") and any(row["status"] == "NOT_ESTIMABLE" for row in summaries):
            error = ContractError("NATURAL_SELECTOR_NO_ESTIMABLE_COARSE")
            error.natural_diagnostic = {"status": "NOT_ESTIMABLE", "reason": str(error),
                "attempts": attempts, "summaries": summaries, "coarse_records_sha256": records_sha256}
            raise error
    if formal_frequency_fallback:
        trace = {"preferred_minimum": 15, "minimum": 10, "fallback_used": True,
            "frequency_threshold": 20, "frequency_policy_sha256": policy["identity_sha256"],
            "coarse_records_sha256": records_sha256, "attempts": attempts,
            "status": "NOT_ESTIMABLE", "reason_code": "FREQUENCY_LADDER_EXHAUSTED"}
        return {"status": "NOT_ESTIMABLE", "reason_code": trace["reason_code"],
                "epv_resolution": trace}, summaries, trace, resolved
    error = ContractError("NESTED_SELECTOR_EPV_BELOW_10")
    if contract.get("ast_alt_natural_audit"):
        error.natural_diagnostic = {"status": "NOT_ESTIMABLE", "reason": str(error),
            "attempts": attempts, "summaries": summaries, "coarse_records_sha256": records_sha256}
    raise error


def _elastic_frequency_summary(summary, columns, frequency, *, no_aar_redevelopment):
    """Reaggregate a qualified EPV10 path without reading/refitting any path."""
    if summary["reason_code"] == "IMPUTATION_HAS_NO_EPV_FEASIBLE_RATIO":
        return dict(summary)
    _require(summary.get("frequency_threshold") == 12 and frequency in (14, 16, 18, 20),
             "NESTED_SELECTOR_FREQUENCY_SOURCE_INVALID")
    parents = sorted({*([] if no_aar_redevelopment else ["AST_ALT"]),
        *(name for name, count in summary["natural_frequency"].items() if count >= frequency)},
        key=lambda value: value.encode("utf-8"))
    df = sum(columns[name] for name in parents)
    events = summary["outer_training_event_count"]
    feasible = df > 0 and events >= 10 * df
    return {**summary, "frequency_threshold": frequency, "selected_parents": parents,
        "common_set_design_df": df, "common_set_epv": events / df if df else None,
        "status": "FEASIBLE" if feasible else "EPV_INFEASIBLE" if df else "NOT_ESTIMABLE",
        "reason_code": "OK" if feasible else "COMMON_SETA_EPV_BELOW_MINIMUM" if df else "EMPTY_FREQUENCY_AGGREGATE"}


def _choose_elastic_alpha(
    alpha_records: list[Mapping[str, Any]],
    expected_alphas: list[float],
    contract: Mapping[str, Any],
    *, no_aar_redevelopment: Mapping[str, Any] | None = None,
    common_set_epv_binding: Mapping[str, Any] | None = None,
) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    _require(
        len(alpha_records) == len(expected_alphas)
        and [float(row.get("alpha", -1)) for row in alpha_records] == expected_alphas,
        "F2_SELECTOR_ALPHA_GRID_INVALID",
    )
    # No exception is caught here: only fully validated EPV_INFEASIBLE summaries
    # may be excluded. Numeric, missing-path and identity failures abort the run.
    summaries = [_summarize_elastic_alpha(row, contract, no_aar_redevelopment=no_aar_redevelopment,
                     **({"common_set_epv_binding": common_set_epv_binding} if common_set_epv_binding is not None else {}))
                 for row in alpha_records]
    _require(
        len({row["outer_training_event_count"] for row in summaries}) == 1
        and len({_sha(row["outer_paths"][0]["parent_design_columns"])
                 for row in alpha_records}) == 1,
        "F2_SELECTOR_ALPHA_POPULATION_OR_DESIGN_DRIFT",
    )
    return _choose_elastic_summary(summaries), summaries


def _choose_elastic_summary(summaries: list[dict[str, Any]]) -> dict[str, Any]:
    """The unchanged eligible-summary order, indistinguishability and tie rule."""
    feasible = [row for row in summaries if row["status"] == "FEASIBLE"]
    _require(feasible, "F2_SELECTOR_EPV_UNRESOLVED")
    scientific_identities = {
        _sha([{"loss": item["mean_loss_path"], "df": item["active_design_df_path"]}
              for item in row["imputation_decisions"]])
        for row in summaries
    }
    _require(
        len(summaries) == 1 or len(scientific_identities) > 1,
        "F2_SELECTOR_ALPHA_INDISCRIMINATE_REVIEW_REQUIRED",
    )
    best_loss = min(row["mean_loss_at_selected_parameters"] for row in feasible)
    tolerance = 1e-12 + 1e-10 * max(1.0, abs(best_loss))
    eligible = [row for row in feasible
                if row["mean_loss_at_selected_parameters"] <= best_loss + tolerance]
    chosen = min(eligible, key=lambda row: (row["p90_active_design_df"], row["alpha"]))
    return chosen


def admitted_f1_fold(
    capsule_path: Path,
    capsule: dict[str, Any],
    fold: int,
    scratch: Path,
    binding_contract: dict[str, Any],
    result_paths: Mapping[str, Path] | None = None,
    *, admit_io=None,
) -> tuple[dict[str, Any], dict[str, Any], dict[str, Any]]:
    """Admit one approved fold and expose its exact registered view set."""

    _require(type(fold) is int and 1 <= fold <= 6, "F2_FOLD_INVALID")
    unit_id = f"mice-fold-{fold}"
    result_root = scratch / f"{unit_id}-result"
    result, _, payload = _admit_completed_f1_unit(
        capsule_path,
        capsule,
        unit_id,
        result_root,
        result_paths,
        **({} if admit_io is None else {"admit_io": admit_io}),
    )
    views = binding_contract["registry"]["views"][str(fold)]
    expected = {
        "manifest.json",
        *(f"libraries/{view['view_id']}.zip" for view in views),
    }
    fold_root = scratch / f"{unit_id}-payload"
    extract_safe_zip(
        payload,
        fold_root,
        expected_members=expected,
        max_member_bytes=64 * 1024 * 1024 * 1024,
        max_total_bytes=64 * 1024 * 1024 * 1024,
        admit_io=admit_io,
    )
    if admit_io is not None:
        admit_io(memory_bytes=32 * (fold_root / "manifest.json").stat().st_size)
    raw_manifest = (fold_root / "manifest.json").read_bytes()
    manifest = strict_json_bytes(raw_manifest, "f1-fold.manifest")
    indexed = {
        row["view_id"]: row for row in manifest.get("libraries", []) if type(row) is dict
    }
    _require(
        canonical_json_bytes(manifest) == raw_manifest
        and manifest.get("kind") == "PADML_F1_MICE_FOLD_PAYLOAD"
        and manifest.get("status") == "PASS"
        and manifest.get("outer_fold") == fold
        and manifest.get("binding_contract_sha256") == _sha(binding_contract)
        and manifest.get("library_count") == 62
        and set(indexed) == {view["view_id"] for view in views}
        and all(
            indexed[view["view_id"]]["sha256"]
            == sha256_file(fold_root / f"libraries/{view['view_id']}.zip")
            and indexed[view["view_id"]]["size_bytes"]
            == (fold_root / f"libraries/{view['view_id']}.zip").stat().st_size
            for view in views
        ),
        "F2_F1_FOLD_PAYLOAD_INVALID",
    )
    view_index = {view["view_id"]: view for view in views}
    summary = {
        "schema_version": "1.0.0",
        "kind": "PADML_F2_F1_FOLD_ADMISSION",
        "status": "PASS",
        "fold": fold,
        "library_count": 62,
        "view_set_sha256": _sha(views),
        "fold_manifest_sha256": sha256_bytes(raw_manifest),
    }
    fold_input = {
        "root": fold_root,
        "views": view_index,
        "library_index": indexed,
    }
    lineage = {
        "f1_approved_result_sha256": capsule["manifest"]["identity_records"][
            "approved_predecessor"
        ]["manifest_identity"],
        "f1_fold_result_sha256": sha256_file(
            result_paths[unit_id]
            if result_paths is not None
            else capsule_path.parent / "approved-f1" / f"{unit_id}.zip"
        ),
        "f1_fold_payload_sha256": sha256_file(payload),
        "f1_view_set_sha256": summary["view_set_sha256"],
        "f1_fold_manifest_sha256": summary["fold_manifest_sha256"],
        "f1_source_identity": result["identities"]["source"],
        "f1_runtime_identity": result["identities"]["runtime"],
    }
    return summary, fold_input, lineage


def _registered_partition_identity_record(row: Mapping[str, Any], *, prediction_only: bool = False) -> dict[str, Any]:
    covariates = row.get("covariates")
    fit_response = row.get("fit_response")
    evaluation_response = row.get("evaluation_response")
    _require(
        type(prediction_only) is bool
        and isinstance(covariates, dict)
        and isinstance(fit_response, dict)
        and (isinstance(evaluation_response, dict) if not prediction_only else
             row.get("kind") == "OUTER" and "evaluation_response" not in row
             and isinstance(row.get("evaluation_ids"), list) and bool(row["evaluation_ids"])
             and len(row["evaluation_ids"]) == len(set(row["evaluation_ids"]))
             and set(row.get("fit_ids", [])).isdisjoint(row["evaluation_ids"])
             and row.get("evaluation_ids_sha256") == _sha(row["evaluation_ids"])),
        "F2_REGISTERED_PARTITION_IDENTITY_INVALID",
    )
    record = {
        "kind": row.get("kind"),
        "partition_id": row.get("partition_id"),
        "repeat": row.get("repeat"),
        "inner_fold": row.get("inner_fold"),
        "analysis_view_sha256": covariates.get("analysis_view_sha256"),
        "application_view_sha256": covariates.get("application_view_sha256"),
        "analysis_ids_sha256": covariates.get("analysis_ids_sha256"),
        "application_ids_sha256": covariates.get("application_ids_sha256"),
        "fit_ids_sha256": fit_response.get("row_ids_sha256"),
        "fit_count": fit_response.get("row_count"),
        "fit_event_count": fit_response.get("event_count"),
        "evaluation_ids_sha256": row.get("evaluation_ids_sha256"),
        "evaluation_count": len(row["evaluation_ids"]) if prediction_only else evaluation_response.get("row_count"),
        "data_identity": covariates.get("data_identity"),
        "fit_response_sha256": fit_response.get("sha256"),
        "fit_response_size_bytes": fit_response.get("size_bytes"),
        **({"evaluation_scope": "PREDICTION_ONLY"} if prediction_only else {
            "evaluation_response_sha256": evaluation_response.get("sha256"),
            "evaluation_response_size_bytes": evaluation_response.get("size_bytes")}),
    }
    if row.get("kind") == "STOP":
        record["consumer_set"] = row.get("consumer_set")
    fit_members = row.get("fit_covariate_members")
    _require(
        isinstance(fit_members, list)
        and len(fit_members) == 20
        and all(
            isinstance(member, dict)
            and set(member) == {"name", "sha256", "size_bytes"}
            for member in fit_members
        ),
        "F2_FIT_COVARIATE_MEMBERS_INVALID",
    )
    record["fit_covariate_members"] = [dict(member) for member in fit_members]
    record["fit_covariate_member_set_sha256"] = _sha(fit_members)
    _require(
        [member["name"] for member in fit_members]
        == [f"imp{index:02d}.csv" for index in range(1, 21)]
        and all(
            isinstance(member["sha256"], str)
            and _HEX64.fullmatch(member["sha256"]) is not None
            and type(member["size_bytes"]) is int
            and member["size_bytes"] > 0
            for member in fit_members
        ),
        "F2_FIT_COVARIATE_MEMBERS_INVALID",
    )
    if row.get("kind") == "CENTER_STRESS":
        record["validation_center"] = row.get("validation_center")
        record["selection_effect"] = row.get("selection_effect")
    _require(
        all(
            isinstance(record[key], str) and _HEX64.fullmatch(record[key]) is not None
            for key in (
                "analysis_view_sha256",
                "application_view_sha256",
                "analysis_ids_sha256",
                "application_ids_sha256",
                "fit_ids_sha256",
                "evaluation_ids_sha256",
                "data_identity",
                "fit_response_sha256",
                *([] if prediction_only else ["evaluation_response_sha256"]),
            )
        )
        and all(
            isinstance(record[key], int)
            and not isinstance(record[key], bool)
            and record[key] > 0
            for key in (
                "fit_count",
                "fit_event_count",
                "evaluation_count",
                "fit_response_size_bytes",
                *([] if prediction_only else ["evaluation_response_size_bytes"]),
            )
        ),
        "F2_REGISTERED_PARTITION_IDENTITY_INVALID",
    )
    return record


def validate_expected_model_input(value: Any) -> dict[str, Any]:
    """Validate the one capsule-bound expectation consumed by compute and acceptance."""

    _require(
        isinstance(value, dict)
        and set(value)
        == {
            "schema_version",
            "kind",
            "fold",
            "lineage",
            "fold_summary_sha256",
            "registered_input_identity",
            "model_partitions",
            "diagnostic_partitions",
            "selector_recipe_expectations",
            "center_recipe_expectations",
            "identity",
        }
        and value.get("schema_version") == "1.0.0"
        and value.get("kind") == "PADML_F2_EXPECTED_MODEL_INPUT"
        and isinstance(value.get("fold"), int)
        and not isinstance(value.get("fold"), bool)
        and 1 <= value["fold"] <= 6
        and isinstance(value.get("lineage"), dict)
        and set(value["lineage"])
        == {
            "f1_approved_result_sha256",
            "f1_data_binding_result_sha256",
            "f1_binding_contract_sha256",
            "f1_response_seal_sha256",
            "f1_fold_result_sha256",
            "f1_fold_payload_sha256",
            "f1_view_set_sha256",
            "f1_fold_manifest_sha256",
            "f1_source_identity",
            "f1_runtime_identity",
            "f1_registered_partition_identity",
        }
        and all(
            isinstance(item, str) and _HEX64.fullmatch(item) is not None
            for item in value["lineage"].values()
        )
        and isinstance(value.get("model_partitions"), list)
        and len(value["model_partitions"]) == 31
        and isinstance(value.get("diagnostic_partitions"), list)
        and len(value["diagnostic_partitions"]) == 5
        and all(
            isinstance(item, dict) and not _contains_absolute_path(item)
            for item in [
                *value["model_partitions"],
                *value["diagnostic_partitions"],
            ]
        ),
        "F2_EXPECTED_MODEL_INPUT_INVALID",
    )
    for field in (
        "fold_summary_sha256",
        "registered_input_identity",
        "identity",
    ):
        _require(
            isinstance(value.get(field), str)
            and _HEX64.fullmatch(value[field]) is not None,
            "F2_EXPECTED_MODEL_INPUT_INVALID",
        )
    outer = [
        row for row in value["model_partitions"] if row.get("kind") == "OUTER"
    ]
    inner = {
        (row.get("repeat"), row.get("inner_fold"))
        for row in value["model_partitions"]
        if row.get("kind") == "INNER"
    }
    stopping = [
        row for row in value["model_partitions"] if row.get("kind") == "STOP"
    ]
    diagnostics = value["diagnostic_partitions"]
    _require(
        len(outer) == 1
        and inner
        == {
            (repeat, inner_fold)
            for repeat in range(1, 4)
            for inner_fold in range(1, 6)
        }
        and len(stopping) == 15
        and len({row.get("validation_center") for row in diagnostics}) == 5
        and all(
            row.get("kind") == "CENTER_STRESS"
            and row.get("selection_effect") == "NONE"
            and row.get("analysis_ids_sha256") == row.get("fit_ids_sha256")
            for row in diagnostics
        )
        and all(
            type(row.get(field)) is int and row[field] > 0
            for row in value["model_partitions"]
            for field in ("fit_count", "fit_event_count", "evaluation_count")
        ),
        "F2_EXPECTED_MODEL_INPUT_REGISTERED_FACTS_INVALID",
    )
    _require(
        all(
            isinstance(row.get("fit_covariate_members"), list)
            and len(row["fit_covariate_members"]) == 20
            and [member.get("name") for member in row["fit_covariate_members"]]
            == [f"imp{index:02d}.csv" for index in range(1, 21)]
            and row.get("fit_covariate_member_set_sha256")
            == _sha(row["fit_covariate_members"])
            for row in [*value["model_partitions"], *diagnostics]
        ),
        "F2_EXPECTED_FIT_MEMBER_SET_INVALID",
    )
    selector_expectations = _validate_transform_recipe_set(
        value["selector_recipe_expectations"],
        predictor_contract(Path(__file__).resolve().parent),
        expected_count=16,
    )
    center_expectations = _validate_transform_recipe_set(
        value["center_recipe_expectations"],
        predictor_contract(Path(__file__).resolve().parent),
        expected_count=5,
    )
    expected_selector_partitions = sorted(
        [row for row in value["model_partitions"] if row["kind"] == "INNER"],
        key=lambda row: (row["repeat"], row["inner_fold"]),
    ) + outer
    _require(
        all(
            recipe["partition_id"] == partition["partition_id"]
            and recipe["training_member_set_sha256"]
            == partition["fit_covariate_member_set_sha256"]
            for recipe, partition in zip(
                selector_expectations["recipes"],
                expected_selector_partitions,
                strict=True,
            )
        )
        and all(
            recipe["partition_id"] == partition["partition_id"]
            and recipe["training_member_set_sha256"]
            == partition["fit_covariate_member_set_sha256"]
            for recipe, partition in zip(
                center_expectations["recipes"],
                sorted(diagnostics, key=lambda row: row["validation_center"]),
                strict=True,
            )
        ),
        "F2_EXPECTED_RECIPE_BINDING_INVALID",
    )
    identity_rows = {
        "model_partitions": value["model_partitions"],
        "diagnostic_partitions": value["diagnostic_partitions"],
    }
    _require(
        value["registered_input_identity"] == _sha(identity_rows)
        and value["lineage"]["f1_registered_partition_identity"]
        == value["registered_input_identity"]
        and value["identity"]
        == _sha({key: item for key, item in value.items() if key != "identity"}),
        "F2_EXPECTED_MODEL_INPUT_INVALID",
    )
    return dict(value)


def _expected_model_input(
    summary: Mapping[str, Any],
    lineage: Mapping[str, Any],
    registered: Mapping[str, Any],
    predictors: Mapping[str, Any],
) -> dict[str, Any]:
    selector_rows = sorted(
        [row for row in registered["partitions"] if row["kind"] == "INNER"],
        key=lambda row: (row["repeat"], row["inner_fold"]),
    ) + [row for row in registered["partitions"] if row["kind"] == "OUTER"]
    center_rows = sorted(
        registered["diagnostic_partitions"],
        key=lambda row: row["validation_center"],
    )
    value = {
        "schema_version": "1.0.0",
        "kind": "PADML_F2_EXPECTED_MODEL_INPUT",
        "fold": summary["fold"],
        "lineage": dict(lineage),
        "fold_summary_sha256": _sha(dict(summary)),
        "registered_input_identity": registered["identity"],
        "model_partitions": [
            _registered_partition_identity_record(row)
            for row in registered["partitions"]
        ],
        "diagnostic_partitions": [
            _registered_partition_identity_record(row)
            for row in registered["diagnostic_partitions"]
        ],
        "selector_recipe_expectations": _python_recipe_set_from_registered(
            selector_rows, predictors
        ),
        "center_recipe_expectations": _python_recipe_set_from_registered(
            center_rows, predictors
        ),
    }
    value["identity"] = _sha(value)
    return validate_expected_model_input(value)


def expected_model_inputs_from_approved_f1(
    approved_f1_record: Mapping[str, Any],
    direct_objects: list[dict[str, Any]],
    result_paths: Mapping[str, Path],
    scratch: Path,
    authority: Mapping[str, Any] | None = None,
) -> list[dict[str, Any]]:
    """Locally derive all six F2 model-input expectations from sealed F1 results."""

    from .f2 import validate_approved_f1

    approved = validate_approved_f1(dict(approved_f1_record))
    expected_units = ["data-binding", *(f"mice-fold-{fold}" for fold in range(1, 7))]
    _require(
        [row.get("unit_id") for row in direct_objects] == expected_units
        and set(result_paths) == set(expected_units)
        and scratch.is_absolute()
        and scratch.is_dir()
        and not scratch.is_symlink()
        and scratch.resolve(strict=True) == scratch
        and all(
            path.is_absolute()
            and path.is_file()
            and not path.is_symlink()
            and path.resolve(strict=True) == path
            for path in result_paths.values()
        ),
        "F2_LOCAL_MODEL_INPUT_SOURCE_INVALID",
    )
    capsule: dict[str, Any] = {
        "run_id": approved["identity"],
        "approved_registry": {"direct_objects": [dict(row) for row in direct_objects]},
    }
    capsule["manifest"] = {
        "identity_records": {
            "approved_predecessor": {"manifest_identity": approved["identity"]}
        }
    }
    capsule_path = scratch / "future-f2-capsule.zip"
    binding_root = scratch / "binding-admission"
    binding_root.mkdir(mode=0o700)
    binding_contract, response_csv, binding_lineage = admitted_f1_frozen_data(
        capsule_path,
        capsule,
        binding_root,
        result_paths,
    )
    predictor_value = predictor_contract(
        Path(__file__).resolve().parent,
        dict(authority) if authority is not None else load_science_authority(),
    )
    model_inputs: list[dict[str, Any]] = []
    for fold in range(1, 7):
        fold_root = scratch / f"fold-{fold}"
        fold_root.mkdir(mode=0o700)
        try:
            summary, fold_input, fold_lineage = admitted_f1_fold(
                capsule_path,
                capsule,
                fold,
                fold_root,
                binding_contract,
                result_paths,
            )
            registered = _materialize_registered_partitions(
                fold_input,
                binding_contract,
                response_csv,
                fold,
                fold_root / "registered",
            )
            lineage = {
                **binding_lineage,
                **fold_lineage,
                "f1_registered_partition_identity": registered["identity"],
            }
            model_inputs.append(
                _expected_model_input(summary, lineage, registered, predictor_value)
            )
        finally:
            # Replay retains only the content-addressed expectation.  Removing each
            # expanded fold bounds local R4 scratch without changing science bytes.
            shutil.rmtree(fold_root, ignore_errors=True)
    _require(
        [row["fold"] for row in model_inputs] == list(range(1, 7)),
        "F2_LOCAL_MODEL_INPUT_SET_INVALID",
    )
    return model_inputs


def _recipe_training_member_bytes(path: Path, fit_ids: list[str]) -> bytes:
    _require(
        path.is_absolute()
        and path.is_file()
        and not path.is_symlink()
        and path.resolve(strict=True) == path,
        "F2_RECIPE_TRAINING_MEMBER_INVALID",
    )
    with path.open(encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        rows = list(reader)
    return _recipe_training_rows_bytes(list(reader.fieldnames or []), rows, fit_ids)


def _recipe_training_rows_bytes(fieldnames, rows, fit_ids):
    normalized_fields = {field.lower().replace("-", "_") for field in fieldnames}
    indexed = {row.get("Patient_ID", ""): row for row in rows}
    _require(
        fieldnames
        and "Patient_ID" in fieldnames
        and not any(
            any(token in field for token in _RECIPE_FORBIDDEN_ROLE_TOKENS)
            for field in normalized_fields
        ),
        "F2_RECIPE_RESPONSE_ROLE_REACHABLE",
    )
    _require(
        len(indexed) == len(rows)
        and fit_ids
        and len(fit_ids) == len(set(fit_ids))
        and all(patient_id in indexed for patient_id in fit_ids),
        "F2_RECIPE_TRAINING_ROW_IDENTITY_INVALID",
    )
    output = io.StringIO(newline="")
    writer = csv.DictWriter(output, fieldnames=fieldnames, lineterminator="\n")
    writer.writeheader()
    for patient_id in fit_ids:
        writer.writerow(indexed[patient_id])
    return output.getvalue().encode("utf-8")


_FIT_MEMBER_PINS = OrderedDict()
_FIT_MEMBER_PINS_LOCK = Lock()


def _fit_covariate_member_records(
    binding: Mapping[str, Any], fit_ids: list[str]
) -> list[dict[str, Any]]:
    input_dir = Path(binding["input_dir"])
    key = (tuple(fit_ids), tuple(sha256_file(input_dir / f"imp{i:02d}.csv") for i in range(1, 21)))
    with _FIT_MEMBER_PINS_LOCK:
        if key in _FIT_MEMBER_PINS:
            _FIT_MEMBER_PINS.move_to_end(key)
            return [dict(row) for row in _FIT_MEMBER_PINS[key]]
    records = []
    for imputation in range(1, 21):
        name = f"imp{imputation:02d}.csv"
        member = _recipe_training_member_bytes(input_dir / name, fit_ids)
        records.append(
            {
                "name": name,
                "sha256": sha256_bytes(member),
                "size_bytes": len(member),
            }
        )
    with _FIT_MEMBER_PINS_LOCK:
        _FIT_MEMBER_PINS[key] = tuple(dict(row) for row in records)
        while len(_FIT_MEMBER_PINS) > 128:
            _FIT_MEMBER_PINS.popitem(last=False)
    return records


def _type7_quantile(values: list[float], probability: float) -> float:
    _require(values and 0 <= probability <= 1, "F2_RECIPE_QUANTILE_INPUT_INVALID")
    ordered = sorted(values)
    position = (len(ordered) - 1) * probability
    lower = math.floor(position)
    fraction = position - lower
    if lower + 1 == len(ordered):
        return ordered[lower]
    return ordered[lower] + fraction * (ordered[lower + 1] - ordered[lower])


def _python_recipe_from_registered(
    row: Mapping[str, Any], predictors: Mapping[str, Any]
) -> dict[str, Any]:
    """Independently recompute fit-only recipe values for sole validation."""

    covariates = row["covariates"]
    fit_ids = list(row["fit_ids"])
    input_dir = Path(covariates["input_dir"])
    member_bytes = [
        _recipe_training_member_bytes(input_dir / f"imp{index:02d}.csv", fit_ids)
        for index in range(1, 21)
    ]
    members = [
        {
            "name": f"imp{index:02d}.csv",
            "sha256": sha256_bytes(data),
            "size_bytes": len(data),
        }
        for index, data in enumerate(member_bytes, start=1)
    ]
    _require(
        members == row["fit_covariate_members"],
        "F2_RECIPE_TRAINING_MEMBER_IDENTITY_INVALID",
    )
    frames = [
        list(csv.DictReader(io.StringIO(data.decode("utf-8"))))
        for data in member_bytes
    ]
    registry_rows = [
        item
        for item in predictors["transform_registry"]["rows"]
        if item["parent"] != "eGFR_calc"
    ]
    representations: list[dict[str, Any]] = []
    parent_map: list[dict[str, Any]] = []
    for registry in registry_rows:
        parent = registry["parent"]
        representation = registry["representation"]
        columns = [
            parent + suffix
            for suffix in predictors["representation_contract"][representation][
                "column_suffixes"
            ]
        ]
        per_imputation: list[list[float]] = []
        for frame in frames:
            values: list[float] = []
            for source in frame:
                try:
                    number = float(source[parent])
                except (KeyError, TypeError, ValueError) as exc:
                    raise ContractError("F2_RECIPE_PARENT_DOMAIN_INVALID") from exc
                _require(math.isfinite(number), "F2_RECIPE_PARENT_DOMAIN_INVALID")
                values.append(number)
            _require(values, "F2_RECIPE_PARENT_DOMAIN_INVALID")
            per_imputation.append(values)
        if representation == "IDENTITY":
            parameters: dict[str, Any] = {"identity": True}
        elif representation == "LOG1P":
            _require(
                all(number >= 0 for values in per_imputation for number in values),
                "F2_RECIPE_LOG1P_DOMAIN_INVALID",
            )
            parameters = {"canonical_unit_scale": 1}
        else:
            _require(
                representation == "NATURAL_SPLINE_K3",
                "F2_RECIPE_REPRESENTATION_INVALID",
            )
            pooled = [number for values in per_imputation for number in values]
            q10 = _type7_quantile(pooled, 0.1)
            q50 = _type7_quantile(pooled, 0.5)
            q90 = _type7_quantile(pooled, 0.9)
            _require(q10 < q50 < q90, "F2_RECIPE_SPLINE_PARAMETER_INVALID")
            parameters = {
                "boundary_knots": [q10, q90],
                "interior_knots": [q50],
                "quantile_type": 7,
            }
        representations.append(
            {
                "parent": parent,
                "canonical_unit": registry["canonical_unit"],
                "representation": representation,
                "design_df": predictors["representation_contract"][representation][
                    "design_df"
                ],
                "design_columns": columns,
                "parameters": parameters,
            }
        )
        parent_map.append({"parent": parent, "columns": columns})
    projection = {
        "partition_id": row["partition_id"],
        "fit_ids_sha256": _sha(fit_ids),
        "analysis_view_sha256": covariates["analysis_view_sha256"],
        "analysis_ids_sha256": covariates["analysis_ids_sha256"],
        "recipe_registry_record": {
            "members": members,
            "registry": {
                **predictors["transform_registry"],
                "rows": registry_rows,
            },
        },
    }
    return _validated_recipe_from_r_values(
        projection,
        {
            "partition_id": row["partition_id"],
            "representations": representations,
            "ordered_parent_column_map": parent_map,
        },
        predictors,
    )


def _python_recipe_set_from_registered(
    rows: list[Mapping[str, Any]], predictors: Mapping[str, Any]
) -> dict[str, Any]:
    _require(len(rows) in {5, 16}, "F2_RECIPE_COMPILE_DENOMINATOR_INVALID")
    value = {
        "recipe_schema_version": "1.0.0",
        "kind": "PADML_F2_TRANSFORM_RECIPE_SET",
        "recipe_count": len(rows),
        "recipes": [
            _python_recipe_from_registered(row, predictors) for row in rows
        ],
    }
    value["recipe_set_sha256"] = _sha(value)
    return _validate_transform_recipe_set(
        value, predictors, expected_count=len(rows)
    )


def _materialize_application_subset(
    source: Path,
    *,
    application_ids: list[str],
    destination: Path,
    partition_id: str,
    admit_io=None,
) -> dict[str, Any]:
    if admit_io is not None:
        sizes = [(source / f"imputations/imp{index:02d}.csv").stat().st_size for index in range(1, 21)]
        admit_io(pending_bytes=2 * sum(sizes), memory_bytes=32 * max(sizes))
    destination.mkdir(mode=0o700)
    members: list[dict[str, Any]] = []
    expected = set(application_ids)
    for index in range(1, 21):
        name = f"imputations/imp{index:02d}.csv"
        if admit_io is not None:
            admit_io(memory_bytes=32 * sizes[index - 1])
        with (source / name).open(encoding="utf-8-sig", newline="") as handle:
            reader = csv.DictReader(handle)
            source_rows = list(reader)
            source_ids = [row.get("Patient_ID", "") for row in source_rows]
            rows = {row["Patient_ID"]: row for row in source_rows}
            _require(
                reader.fieldnames is not None
                and source_ids
                and all(source_ids)
                and len(source_ids) == len(set(source_ids))
                and expected.issubset(rows),
                "F2_F1_APPLICATION_VIEW_ROW_IDENTITY_INVALID",
            )
            target = destination / f"imp{index:02d}.csv"
            with target.open("x", encoding="utf-8", newline="") as output:
                writer = csv.DictWriter(
                    output, fieldnames=reader.fieldnames, lineterminator="\n"
                )
                writer.writeheader()
                for patient_id in application_ids:
                    writer.writerow(rows[patient_id])
        members.append(
            {
                "name": target.name,
                "sha256": sha256_file(target),
                "size_bytes": target.stat().st_size,
            }
        )
    manifest_sha = sha256_file(source / "manifest.json")
    return {
        "schema_version": "1.0.0",
        "kind": "PADML_F2_REGISTERED_VIEW_BINDING",
        "status": "PASS",
        "partition_id": partition_id,
        "analysis_view_sha256": manifest_sha,
        "application_view_sha256": manifest_sha,
        "analysis_ids_sha256": _sha(application_ids),
        "application_ids_sha256": _sha(application_ids),
        "input_dir": str(destination),
        "members": members,
        "data_identity": _sha(members),
    }


def _materialize_registered_pair(job):
    """Consume one completed PRIMARY pair in the existing scientific pool."""
    from .runtime import observe_execution_resources, resource_admission
    destination, policy = Path(job["destination"]), job["policy"]
    def admit_io(*, memory_bytes=0, pending_bytes=0):
        observed = observe_execution_resources(destination)
        _require(observed["scratch_available_bytes"] >= pending_bytes,
                 "RAW_CONTEXT_STORAGE_INSUFFICIENT")
        return resource_admission({**policy,
            "memory_reserve_bytes": policy["memory_reserve_bytes"] + memory_bytes},
            observed, legal_tasks=1)
    row, kind = job["row"], job["kind"]
    fit_ids, application_ids, evaluation_ids = row["analysis_ids"], row["application_ids"], job["evaluation_ids"]
    _require(fit_ids and evaluation_ids and set(fit_ids).isdisjoint(evaluation_ids)
        and set(fit_ids) | set(evaluation_ids) == set(application_ids),
        "F2_REGISTERED_PARTITION_ROW_SET_INVALID")
    paths = []
    for source in job["sources"]:
        path = destination / "view-sources" / source["view"]["view_id"]
        paths.append(_load_f1_view_library(Path(source["archive"]), source["view"], path,
                                           admit_io=admit_io))
    root = destination / "partitions" / row["partition_id"]
    root.mkdir(mode=0o700)
    prepared = {}
    binding = _merge_registered_views(paths[0], paths[1], analysis_ids=fit_ids,
        application_ids=application_ids, destination=root / "covariates",
        partition_id=row["partition_id"], admit_io=admit_io, prepared=prepared)
    fit = dict(job["fit_response"])
    raw = fit.pop("private_bytes")
    fit_path = root / "fit-response.csv"
    with fit_path.open("xb") as output:
        output.write(raw)
    fit["path"] = str(fit_path)
    descriptor = {"kind": kind, "partition_id": row["partition_id"],
        "repeat": int(row.get("repeat", 0)), "inner_fold": int(row.get("inner_fold", 0)),
        "fit_ids": list(fit_ids), "application_ids": list(application_ids),
        "evaluation_ids": list(evaluation_ids), "evaluation_ids_sha256": _sha(evaluation_ids),
        "covariates": binding, "fit_response": fit,
        "evaluation_response": dict(job["evaluation_response"]),
        "fit_covariate_members": prepared["fit_covariate_members"],
        "evaluation_centers": {"data_identity": binding["data_identity"],
            "evaluation_ids_sha256": _sha(evaluation_ids),
            "values": [prepared["centers"][prepared["positions"][patient]] for patient in evaluation_ids]}}
    _partition_evaluation_centers(descriptor)
    if kind == "STOP":
        descriptor["consumer_set"] = list(row["consumers"])
    for path in paths:
        _require(path.parent == destination / "view-sources" and path.is_dir()
            and not path.is_symlink(), "RAW_CONTEXT_RETIREMENT_INVALID")
        shutil.rmtree(path)
    return descriptor


def _materialize_registered_pairs(fold_input, binding_contract, response_csv, fold, destination, policy):
    """31 independent pairs; original order/coverage and no new receipt."""
    import zipfile
    from .bundle import _admit_zip_directory, _validated_zip_infos
    from .runtime import admit_stage, run_ready_families, observe_execution_resources, resource_admission
    def admit_metadata(*, memory_bytes=0, pending_bytes=0):
        observed = observe_execution_resources(destination)
        _require(observed["scratch_available_bytes"] >= pending_bytes, "RAW_CONTEXT_STORAGE_INSUFFICIENT")
        return resource_admission({**policy,
            "memory_reserve_bytes": policy["memory_reserve_bytes"] + memory_bytes}, observed, legal_tasks=1)
    destination.mkdir(mode=0o700)
    (destination / "view-sources").mkdir(mode=0o700)
    (destination / "partitions").mkdir(mode=0o700)
    fields, responses = _response_rows(response_csv)
    registry, views = binding_contract["registry"], fold_input["views"]
    rows = {kind: [row for row in registry[table] if row["outer_fold"] == fold]
            for kind, table in (("OUTER", "outer"), ("INNER", "inner"), ("STOP", "stopping"))}
    _require([len(rows[k]) for k in ("OUTER", "INNER", "STOP")] == [1, 15, 15],
             "F2_REGISTERED_PARTITION_DENOMINATOR_INVALID")
    jobs, consumed_view_ids = [], set()
    for kind in ("OUTER", "INNER", "STOP"):
        for row in rows[kind]:
            stem = "OUTER" if kind == "OUTER" else f"{kind}_R{row['repeat']}_K{row['inner_fold']}"
            sources, expanded, largest = [], 0, 0
            for role in ("ANALYSIS", "APPLICATION"):
                view_id = f"{stem}_{role}"
                _require(view_id in views and view_id not in consumed_view_ids,
                         "F2_REGISTERED_VIEW_ID_INVALID")
                path = fold_input["root"] / "libraries" / f"{view_id}.zip"
                _admit_zip_directory(path, admit_metadata)
                with zipfile.ZipFile(path) as archive:
                    infos = _validated_zip_infos(archive, None, max_member_bytes=128 * 1024**2,
                        max_total_bytes=3 * 1024**3, max_compression_ratio=1000)
                    expanded += sum(info.file_size for info in infos)
                    largest = max(largest, *(info.file_size for info in infos))
                sources.append({"view": views[view_id], "archive": str(path)})
                consumed_view_ids.add(view_id)
            evaluation_ids = list(row["stop_ids"] if kind == "STOP" else row["validation_ids"])
            fit = _write_response_subset(fields, responses, row["analysis_ids"], None)
            evaluation = _write_response_subset(fields, responses, evaluation_ids, None)
            jobs.append({"destination": str(destination), "policy": policy, "row": row, "kind": kind,
                "sources": sources, "evaluation_ids": evaluation_ids, "fit_response": fit,
                "evaluation_response": evaluation, "estimates": {
                    "retained_bytes": 2 * expanded + fit["size_bytes"], "publication_bytes": 0,
                    "transient_bytes_per_worker": max(1, expanded),
                    "memory_bytes_per_worker": max(MIN_WORKER_MEMORY_BYTES,
                        64 * largest + 32 * (fit["size_bytes"] + evaluation["size_bytes"]))}})
    _require(len(jobs) == 31 and len(consumed_view_ids) == 62 and consumed_view_ids == set(views),
             "F2_REGISTERED_PARTITION_DENOMINATOR_INVALID")
    def coordinate(job):
        admission = admit_stage(policy, destination, legal_tasks=1, **job["estimates"])
        descriptor, = _bounded_ordered_spawn(_materialize_registered_pair, [job],
            selected_slots=admission["admitted_worker_ceiling"])
        return descriptor
    admission = resource_admission(policy, observe_execution_resources(destination), legal_tasks=len(jobs))
    descriptors = run_ready_families([lambda job=job: coordinate(job) for job in jobs],
        policy=policy, root=destination, workers=admission["admitted_worker_ceiling"])
    _require(len(descriptors) == 31 and len({r["partition_id"] for r in descriptors}) == 31
        and all(r.get("consumer_set") == ["GBM_COX", "XGBOOST_COX", "COXTIME_SET_A"]
                for r in descriptors if r["kind"] == "STOP"),
        "F2_REGISTERED_PARTITION_DENOMINATOR_INVALID")
    return {"schema_version": "1.0.0", "kind": "PADML_F2_REGISTERED_PARTITION_INPUTS",
        "status": "PASS", "fold": fold, "outer_count": 1, "inner_count": 15, "stop_count": 15,
        "diagnostic_count": 0, "view_count": 62, "partitions": descriptors,
        "diagnostic_partitions": [], "identity": _sha({"model_partitions": [
            _registered_partition_identity_record(row) for row in descriptors], "diagnostic_partitions": []})}

def _materialize_registered_partitions(
    fold_input: dict[str, Any],
    binding_contract: dict[str, Any],
    response_csv: bytes,
    fold: int,
    destination: Path,
    *, admit_io=None, retained_model_input: Mapping[str, Any] | None = None,
    include_diagnostics: bool = True, resource_policy=None,
) -> dict[str, Any]:
    """Materialize the one outer, 15 inner and 15 shared STOP view pairs."""
    if retained_model_input is not None:
        # Reopen the original retained materialization through its accepted F2
        # expectation. Never merge views, write CSVs or manufacture a new identity.
        expected = validate_expected_model_input(dict(retained_model_input))
        _require(expected["fold"] == fold and destination.is_absolute()
                 and destination.is_dir() and destination.resolve(strict=True) == destination
                 and not destination.is_symlink(), "F2_RETAINED_REGISTERED_INPUT_INVALID")
        if admit_io is not None:
            admit_io(memory_bytes=32 * len(response_csv))
        fields, responses = _response_rows(response_csv)
        registry = binding_contract["registry"]
        tables = {"OUTER": "outer", "INNER": "inner", "STOP": "stopping", "CENTER_STRESS": "center_stress"}
        registered_rows = {kind: [row for row in registry[table] if row["outer_fold"] == fold]
                           for kind, table in tables.items()}
        _require([len(registered_rows[k]) for k in tables] == [1, 15, 15, 5],
                 "F2_REGISTERED_PARTITION_DENOMINATOR_INVALID")
        centers = registered_rows["CENTER_STRESS"]
        _require(all(row["application_ids"] == centers[0]["application_ids"] for row in centers)
                 and set().union(*(set(row["analysis_ids"]) for row in centers))
                     == set(centers[0]["application_ids"]),
                 "F2_RETAINED_CENTER_ROW_COVERAGE_INVALID")
        descriptors, diagnostics, files = [], [], set()
        for pin in [*expected["model_partitions"], *expected["diagnostic_partitions"]]:
            kind, identifier = pin["kind"], pin["partition_id"]
            candidates = [row for row in registered_rows[kind] if row["partition_id"] == identifier]
            _require(len(candidates) == 1, "F2_RETAINED_REGISTERED_INPUT_INVALID")
            row, = candidates
            fit_ids, application_ids = list(row["analysis_ids"]), list(row["application_ids"])
            evaluation_ids = list(row["stop_ids"] if kind == "STOP" else row["validation_ids"])
            _require(set(fit_ids).isdisjoint(evaluation_ids)
                     and set(fit_ids) | set(evaluation_ids) == set(application_ids),
                     "F2_REGISTERED_PARTITION_ROW_SET_INVALID")
            directory = destination / "partitions" / ("CENTER_STRESS_COVARIATES" if kind == "CENTER_STRESS" else identifier)
            if kind != "CENTER_STRESS": directory = directory / "covariates"
            members = []
            for imp in range(1, 21):
                path = directory / f"imp{imp:02d}.csv"
                _require(path.is_file() and not path.is_symlink() and path.resolve(strict=True) == path,
                         "F2_RETAINED_REGISTERED_INPUT_INVALID")
                if admit_io is not None: admit_io(memory_bytes=32 * path.stat().st_size)
                with path.open(encoding="utf-8-sig", newline="") as handle:
                    reader = csv.DictReader(handle)
                    _require(reader.fieldnames is not None and "Patient_ID" in reader.fieldnames
                             and not {"All_Cause_Death", "Death_Followup_months"}.intersection(reader.fieldnames)
                             and [item["Patient_ID"] for item in reader] == application_ids,
                             "F2_F1_REGISTERED_VIEW_ROW_IDENTITY_INVALID")
                members.append({"name": path.name, "sha256": sha256_file(path), "size_bytes": path.stat().st_size})
                files.add(path)
            covariates = {"schema_version": "1.0.0", "kind": "PADML_F2_REGISTERED_VIEW_BINDING",
                "status": "PASS", "partition_id": identifier, "input_dir": str(directory), "members": members,
                **{key: pin[key] for key in ("analysis_view_sha256", "application_view_sha256",
                    "analysis_ids_sha256", "application_ids_sha256", "data_identity")}}
            _require(pin["analysis_ids_sha256"] == _sha(fit_ids)
                     and pin["application_ids_sha256"] == _sha(application_ids)
                     and (pin["data_identity"] == _sha(members) if kind != "CENTER_STRESS" else
                          pin["data_identity"] == _sha({key: covariates[key] for key in (
                              "analysis_view_sha256", "application_view_sha256", "analysis_ids_sha256", "application_ids_sha256")})),
                     "F2_RETAINED_REGISTERED_INPUT_INVALID")
            fit = _write_response_subset(fields, responses, fit_ids, None)
            fit_path = destination / "partitions" / identifier / "fit-response.csv"
            _require(fit_path.is_file() and not fit_path.is_symlink() and fit_path.resolve(strict=True) == fit_path
                     and fit_path.read_bytes() == fit.pop("private_bytes"), "F2_RETAINED_REGISTERED_INPUT_INVALID")
            fit["path"] = str(fit_path); files.add(fit_path)
            descriptor = {"kind": kind, "partition_id": identifier, "repeat": int(row.get("repeat", 0)),
                "inner_fold": int(row.get("inner_fold", 0)), "fit_ids": fit_ids, "application_ids": application_ids,
                "evaluation_ids": evaluation_ids, "evaluation_ids_sha256": _sha(evaluation_ids),
                "covariates": covariates, "fit_response": fit,
                "evaluation_response": _write_response_subset(fields, responses, evaluation_ids, None),
                "fit_covariate_members": _fit_covariate_member_records(covariates, fit_ids)}
            if kind == "STOP": descriptor["consumer_set"] = list(row["consumers"])
            if kind == "CENTER_STRESS":
                descriptor.update(validation_center=row["validation_center"], selection_effect="NONE")
                _require(covariates["analysis_view_sha256"] == _sha({
                    "schema_version": "1.0.0", "kind": "PADML_F2_CENTER_TRAINING_ANALYSIS_VIEW",
                    "fit_ids_sha256": _sha(fit_ids), "members": descriptor["fit_covariate_members"]}),
                    "F2_RETAINED_REGISTERED_INPUT_INVALID")
            _require(_registered_partition_identity_record(descriptor) == pin,
                     "F2_RETAINED_REGISTERED_INPUT_INVALID")
            (diagnostics if kind == "CENTER_STRESS" else descriptors).append(descriptor)
        _require(not any(path.is_symlink() for path in destination.rglob("*"))
                 and {path for path in destination.rglob("*") if path.is_file()} == files,
                 "F2_RETAINED_REGISTERED_INPUT_INVALID")
        identity = _sha({"model_partitions": [_registered_partition_identity_record(row) for row in descriptors],
                         "diagnostic_partitions": [_registered_partition_identity_record(row) for row in diagnostics]})
        _require(identity == expected["registered_input_identity"], "F2_RETAINED_REGISTERED_INPUT_INVALID")
        return {"schema_version": "1.0.0", "kind": "PADML_F2_REGISTERED_PARTITION_INPUTS", "status": "PASS",
            "fold": fold, "outer_count": 1, "inner_count": 15, "stop_count": 15, "diagnostic_count": len(diagnostics),
            "view_count": 62, "partitions": descriptors, "diagnostic_partitions": diagnostics, "identity": identity}
    if resource_policy is not None and not include_diagnostics:
        return _materialize_registered_pairs(fold_input, binding_contract, response_csv,
            fold, destination, resource_policy)
    destination.mkdir(mode=0o700)
    source_root = destination / "view-sources"
    source_root.mkdir(mode=0o700)
    partition_root = destination / "partitions"
    partition_root.mkdir(mode=0o700)
    views = fold_input["views"]
    library_root = fold_input["root"] / "libraries"
    extracted: dict[str, Path] = {}
    consumed_view_ids: set[str] = set()
    io_options = {} if admit_io is None else {"admit_io": admit_io}
    if admit_io is not None:
        import zipfile
        from .bundle import _admit_zip_directory, _validated_zip_infos

        # All 62 accepted ZIPs are already on disk. Before opening the first
        # view, account for their expansions, 31 merged M20s, the extra center-
        # stress M20 and 36 response subsets. No future cleanup earns credit.
        expanded, outer_application = 0, 0
        for view_id in views:
            path = library_root / f"{view_id}.zip"
            _admit_zip_directory(path, admit_io)
            with zipfile.ZipFile(path) as archive:
                infos = _validated_zip_infos(archive, None, max_member_bytes=128 * 1024 * 1024,
                                             max_total_bytes=3 * 1024 * 1024 * 1024,
                                             max_compression_ratio=1000)
                size = sum(info.file_size for info in infos)
                expanded += size
                if view_id == "OUTER_APPLICATION":
                    outer_application = size
        admit_io(pending_bytes=3 * expanded + 2 * outer_application + 72 * len(response_csv),
                 memory_bytes=32 * len(response_csv))

    def source(view_id: str) -> Path:
        if view_id not in extracted:
            _require(view_id in views, "F2_REGISTERED_VIEW_ID_INVALID")
            target = source_root / view_id
            extracted[view_id] = _load_f1_view_library(
                library_root / f"{view_id}.zip",
                views[view_id],
                target,
                **io_options,
            )
            consumed_view_ids.add(view_id)
        return extracted[view_id]

    response_fields, response_by_id = _response_rows(response_csv)
    registry = binding_contract["registry"]
    outer = [row for row in registry["outer"] if row["outer_fold"] == fold]
    inner = [row for row in registry["inner"] if row["outer_fold"] == fold]
    stopping = [row for row in registry["stopping"] if row["outer_fold"] == fold]
    _require(
        len(outer) == 1
        and len(inner) == 15
        and len(stopping) == 15,
        "F2_REGISTERED_PARTITION_DENOMINATOR_INVALID",
    )
    descriptors: list[dict[str, Any]] = []
    diagnostic_descriptors: list[dict[str, Any]] = []

    def materialize(
        row: dict[str, Any],
        *,
        kind: str,
        analysis_view_id: str,
        application_view_id: str,
        evaluation_ids: list[str],
    ) -> None:
        fit_ids = list(row["analysis_ids"])
        application_ids = list(row["application_ids"])
        _require(
            fit_ids
            and evaluation_ids
            and set(fit_ids).isdisjoint(evaluation_ids)
            and set(fit_ids) | set(evaluation_ids) == set(application_ids),
            "F2_REGISTERED_PARTITION_ROW_SET_INVALID",
        )
        root = partition_root / row["partition_id"]
        covariates = root / "covariates"
        root.mkdir(mode=0o700)
        binding = _merge_registered_views(
            source(analysis_view_id),
            source(application_view_id),
            analysis_ids=fit_ids,
            application_ids=application_ids,
            destination=covariates,
            partition_id=row["partition_id"],
            **io_options,
        )
        if admit_io is not None:
            admit_io(pending_bytes=2 * len(response_csv), memory_bytes=32 * (
                len(response_csv) + max(member["size_bytes"] for member in binding["members"])))
        fit_response = _write_response_subset(
            response_fields,
            response_by_id,
            fit_ids,
            root / "fit-response.csv",
        )
        evaluation_response = _write_response_subset(
            response_fields,
            response_by_id,
            evaluation_ids,
            None,
        )
        descriptor = {
            "kind": kind,
            "partition_id": row["partition_id"],
            "repeat": int(row.get("repeat", 0)),
            "inner_fold": int(row.get("inner_fold", 0)),
            "fit_ids": fit_ids,
            "evaluation_ids": evaluation_ids,
            "evaluation_ids_sha256": _sha(evaluation_ids),
            "application_ids": application_ids,
            "covariates": binding,
            "fit_response": fit_response,
            "evaluation_response": evaluation_response,
            "fit_covariate_members": _fit_covariate_member_records(
                binding, fit_ids
            ),
        }
        if kind == "STOP":
            descriptor["consumer_set"] = list(row["consumers"])
        descriptors.append(descriptor)
        if not include_diagnostics:
            # PRIMARY consumes each ANALYSIS/APPLICATION pair once. The
            # merged M20 and original ZIP remain; no later caller needs these
            # expanded view copies (legacy diagnostics still use OUTER).
            for view_id in (analysis_view_id, application_view_id):
                shutil.rmtree(extracted.pop(view_id))

    materialize(
        outer[0],
        kind="OUTER",
        analysis_view_id="OUTER_ANALYSIS",
        application_view_id="OUTER_APPLICATION",
        evaluation_ids=list(outer[0]["validation_ids"]),
    )
    for row in inner:
        repeat = row["repeat"]
        inner_fold = row["inner_fold"]
        materialize(
            row,
            kind="INNER",
            analysis_view_id=f"INNER_R{repeat}_K{inner_fold}_ANALYSIS",
            application_view_id=f"INNER_R{repeat}_K{inner_fold}_APPLICATION",
            evaluation_ids=list(row["validation_ids"]),
        )
    for row in stopping:
        repeat = row["repeat"]
        inner_fold = row["inner_fold"]
        materialize(
            row,
            kind="STOP",
            analysis_view_id=f"STOP_R{repeat}_K{inner_fold}_ANALYSIS",
            application_view_id=f"STOP_R{repeat}_K{inner_fold}_APPLICATION",
            evaluation_ids=list(row["stop_ids"]),
        )
    if include_diagnostics:
        center_rows = [
            row
            for row in registry.get("center_stress", [])
            if row.get("outer_fold") == fold
        ]
        _require(len(center_rows) == 5, "F2_CENTER_STRESS_REGISTRY_INVALID")
        center_application_ids = list(center_rows[0]["application_ids"])
        _require(
            all(row.get("application_ids") == center_application_ids for row in center_rows),
            "F2_CENTER_STRESS_REGISTRY_INVALID",
        )
        center_covariates = _materialize_application_subset(
            source("OUTER_APPLICATION"),
            application_ids=center_application_ids,
            destination=partition_root / "CENTER_STRESS_COVARIATES",
            partition_id=f"CENTER_STRESS_F{fold}",
            **io_options,
        )
        for row in center_rows:
            if admit_io is not None:
                admit_io(pending_bytes=2 * len(response_csv), memory_bytes=32 * (
                    len(response_csv) + max(member["size_bytes"] for member in center_covariates["members"])))
            fit_ids = list(row["analysis_ids"])
            evaluation_ids = list(row["validation_ids"])
            fit_ids_sha256 = _sha(fit_ids)
            analysis_members = []
            for imputation in range(1, 21):
                member_name = f"imp{imputation:02d}.csv"
                member_bytes = _recipe_training_member_bytes(
                    Path(center_covariates["input_dir"]) / member_name,
                    fit_ids,
                )
                analysis_members.append(
                    {
                        "name": member_name,
                        "sha256": sha256_bytes(member_bytes),
                        "size_bytes": len(member_bytes),
                    }
                )
            analysis_view_sha256 = _sha(
                {
                    "schema_version": "1.0.0",
                    "kind": "PADML_F2_CENTER_TRAINING_ANALYSIS_VIEW",
                    "fit_ids_sha256": fit_ids_sha256,
                    "members": analysis_members,
                }
            )
            center_binding = {
                **center_covariates,
                "partition_id": row["partition_id"],
                "analysis_view_sha256": analysis_view_sha256,
                "analysis_ids_sha256": fit_ids_sha256,
                "data_identity": _sha(
                    {
                        "analysis_view_sha256": analysis_view_sha256,
                        "application_view_sha256": center_covariates[
                            "application_view_sha256"
                        ],
                        "analysis_ids_sha256": fit_ids_sha256,
                        "application_ids_sha256": center_covariates[
                            "application_ids_sha256"
                        ],
                    }
                ),
            }
            root = partition_root / row["partition_id"]
            root.mkdir(mode=0o700)
            fit_response = _write_response_subset(
                response_fields, response_by_id, fit_ids, root / "fit-response.csv"
            )
            evaluation_response = _write_response_subset(
                response_fields,
                response_by_id,
                evaluation_ids,
                None,
            )
            diagnostic_descriptors.append(
                {
                    "kind": "CENTER_STRESS",
                    "partition_id": row["partition_id"],
                    "repeat": 0,
                    "inner_fold": 0,
                    "validation_center": row["validation_center"],
                    "selection_effect": "NONE",
                    "fit_ids": fit_ids,
                    "evaluation_ids": evaluation_ids,
                    "evaluation_ids_sha256": _sha(evaluation_ids),
                    "application_ids": center_application_ids,
                    "covariates": center_binding,
                    "fit_response": fit_response,
                    "evaluation_response": evaluation_response,
                    "fit_covariate_members": _fit_covariate_member_records(
                        center_binding, fit_ids
                    ),
                }
            )
    _require(
        len(descriptors) == 31
        and len(consumed_view_ids) == 62
        and consumed_view_ids == set(views)
        and len({row["partition_id"] for row in descriptors}) == 31
        and all(
            row.get("consumer_set")
            == ["GBM_COX", "XGBOOST_COX", "COXTIME_SET_A"]
            for row in descriptors
            if row["kind"] == "STOP"
        ),
        "F2_REGISTERED_PARTITION_DENOMINATOR_INVALID",
    )
    identity_rows = {
        "model_partitions": [
            _registered_partition_identity_record(row) for row in descriptors
        ],
        "diagnostic_partitions": [
            _registered_partition_identity_record(row)
            for row in diagnostic_descriptors
        ],
    }
    return {
        "schema_version": "1.0.0",
        "kind": "PADML_F2_REGISTERED_PARTITION_INPUTS",
        "status": "PASS",
        "fold": fold,
        "outer_count": 1,
        "inner_count": 15,
        "stop_count": 15,
        "diagnostic_count": len(diagnostic_descriptors),
        "view_count": 62,
        "partitions": descriptors,
        "diagnostic_partitions": diagnostic_descriptors,
        "identity": _sha(identity_rows),
    }


def _engine_registered_partitions(
    registered: dict[str, Any], partition_ids: set[str]
) -> dict[str, Any]:
    """Project only covariates, fit responses and expected prediction IDs."""

    _require(
        registered.get("kind")
        in {
            "PADML_F2_REGISTERED_PARTITION_INPUTS",
            "PADML_F5_REGISTERED_PARTITION_INPUTS",
            "PADML_F4_FULL_PIPELINE_REGISTERED_INPUTS",
            "PADML_F5_A12_REGISTERED_INPUTS",
        }
        and registered.get("status") == "PASS",
        "F2_REGISTERED_PARTITION_INPUT_INVALID",
    )
    _require(
        partition_ids
        and all(isinstance(value, str) and value for value in partition_ids),
        "F2_ENGINE_PARTITION_SCOPE_INVALID",
    )

    def project(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
        partitions: list[dict[str, Any]] = []
        for row in rows:
            if row.get("partition_id") not in partition_ids:
                continue
            _require(
                ("evaluation_response" in row or row.get("kind") == "OUTER"
                 and registered.get("kind") == "PADML_F5_A12_REGISTERED_INPUTS")
                and row.get("evaluation_ids_sha256")
                == _sha(row.get("evaluation_ids")),
                "F2_REGISTERED_PARTITION_IDENTITY_INVALID",
            )
            projected = {
                "kind": row["kind"],
                "partition_id": row["partition_id"],
                "repeat": row["repeat"],
                "inner_fold": row["inner_fold"],
                "fit_ids": row["fit_ids"],
                "evaluation_ids": row["evaluation_ids"],
                "evaluation_ids_sha256": row["evaluation_ids_sha256"],
                "application_ids": row["application_ids"],
                "covariates": row["covariates"],
                "fit_response": row["fit_response"],
            }
            if row["kind"] == "STOP":
                projected["consumer_set"] = row["consumer_set"]
            if row["kind"] == "CENTER_STRESS":
                projected["validation_center"] = row["validation_center"]
                projected["selection_effect"] = row["selection_effect"]
            _require(
                "evaluation_response" not in projected,
                "F2_ENGINE_EVALUATION_RESPONSE_VISIBLE",
            )
            partitions.append(projected)
        return partitions

    partitions = project(registered["partitions"])
    diagnostics = project(registered.get("diagnostic_partitions", []))
    projected = {
        key: value
        for key, value in registered.items()
        if key not in {"partitions", "diagnostic_partitions"}
    } | {
        "partitions": partitions,
        "diagnostic_partitions": diagnostics,
        "projected_partition_ids": sorted(partition_ids),
        "projected_partition_count": len(partition_ids),
    }
    _require(
        len(partitions) + len(diagnostics) == len(partition_ids)
        and {row["partition_id"] for row in [*partitions, *diagnostics]}
        == partition_ids,
        "F2_ENGINE_PARTITION_SCOPE_INVALID",
    )
    return projected


def predictor_contract(
    repo_root: Path,
    authority: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    import csv

    authority_value = (
        load_science_authority(require_activation=ACTIVE_ACTIVATION)
        if authority is None
        else dict(authority)
    )
    compiled_transform = _active_transform_catalog(
        authority_value,
        repo_root / "science/variable.csv",
    )
    transform_contract = authority_value["science"]["f2_model_development"][
        "transform_contract"
    ]
    with (repo_root / "science/variable.csv").open(
        encoding="utf-8",
        newline="",
    ) as handle:
        rows = list(csv.DictReader(handle))
    _require(len(rows) == 53 and len({row["variable"] for row in rows}) == 53, "F2_VARIABLE_CATALOG_INVALID")
    parents = [row["variable"] for row in rows if row["model_parent_eligible"].lower() == "true"]
    selector = [row["variable"] for row in rows if row["selector_eligible"].lower() == "true"]
    forced = [row["variable"] for row in rows if row["forced"].lower() == "true"]
    protected = [row["variable"] for row in rows if row["protected"].lower() == "true"]
    _require(set(parents) == set(selector_parent_names()) and forced == ["AST_ALT"], "F2_PARENT_CATALOG_INVALID")
    _require(set(selector).issubset(parents) and set(protected).issubset(parents), "F2_SELECTOR_CATALOG_INVALID")
    value = {
        "parents": parents,
        "selector_eligible": selector,
        "forced": forced,
        "protected": protected,
        "penalty_factors": {row["variable"]: float(row["penalty_factor"]) for row in rows if row["variable"] in parents},
        "variables": [
            {
                "name": row["variable"],
                "type": row["type"],
                "levels_or_coding": row["levels_or_coding"],
                "set_a_eligible": row["set_a_eligible"].lower() == "true",
                "selector_eligible": row["selector_eligible"].lower() == "true",
                "forced": row["forced"].lower() == "true",
                "selector_representation": row["selector_representation"],
            }
            for row in rows
            if row["variable"] in parents
        ],
        "transform_registry": compiled_transform["registry"],
        "transform_registry_sha256": compiled_transform[
            "transform_registry_sha256"
        ],
        "conflict_map": compiled_transform["conflict_map"],
        "family_policy": transform_contract["family_policy"],
        "representation_contract": transform_contract["representations"],
        "selector_payload_schema_version": transform_contract[
            "selector_payload_schema_version"
        ],
        "sha256": _sha(rows),
    }
    _validate_transform_conflicts(value["selector_eligible"], value)
    return value


def _validate_transform_conflicts(
    selected_parents: list[str],
    predictors: Mapping[str, Any],
) -> None:
    _require(
        selected_parents
        and len(selected_parents) == len(set(selected_parents))
        and all(isinstance(parent, str) and parent for parent in selected_parents),
        "F2_SELECTOR_REPRESENTATION_CONFLICT",
    )
    eligible = set(predictors["selector_eligible"])
    _require(
        set(selected_parents) <= eligible,
        "F2_SELECTOR_REPRESENTATION_CONFLICT",
    )
    for row in predictors["conflict_map"].values():
        members = {
            row["main_parent"],
            *row["excluded_sources"],
        }
        if row["sensitivity_replacement"] is not None:
            members.add(row["sensitivity_replacement"])
        _require(
            len(members & set(selected_parents)) <= 1,
            "F2_SELECTOR_REPRESENTATION_CONFLICT",
        )


def _contains_recipe_forbidden_role(value: Any) -> bool:
    if isinstance(value, Mapping):
        for key, item in value.items():
            normalized = str(key).lower().replace("-", "_")
            if any(token in normalized for token in _RECIPE_FORBIDDEN_ROLE_TOKENS):
                return True
            if _contains_recipe_forbidden_role(item):
                return True
        return False
    if isinstance(value, list):
        return any(_contains_recipe_forbidden_role(item) for item in value)
    return False


def _materialize_recipe_training_member(
    path: Path,
    fit_ids: list[str],
    target: Path,
) -> dict[str, Any]:
    data = _recipe_training_member_bytes(path, fit_ids)
    with target.open("xb") as output:
        output.write(data)
    return {
        "name": target.name,
        "sha256": sha256_bytes(data),
        "size_bytes": len(data),
    }


def _recipe_partition_projection(
    registered: Mapping[str, Any],
    partition_id: str,
    predictors: Mapping[str, Any],
    recipe_input_root: Path,
    *, imputations: Sequence[int] | None = None,
) -> dict[str, Any]:
    rows = [
        *registered.get("partitions", []),
        *registered.get("diagnostic_partitions", []),
    ]
    matches = [row for row in rows if row.get("partition_id") == partition_id]
    _require(len(matches) == 1, "F2_RECIPE_PARTITION_LOOKUP_INVALID")
    row = matches[0]
    fit_ids = list(row.get("fit_ids", []))
    covariates = row.get("covariates")
    _require(
        isinstance(covariates, Mapping) and fit_ids,
        "F2_RECIPE_TRAINING_SCOPE_INVALID",
    )
    input_dir = Path(str(covariates.get("input_dir", "")))
    _require(
        input_dir.is_absolute()
        and input_dir.is_dir()
        and not input_dir.is_symlink()
        and input_dir.resolve(strict=True) == input_dir,
        "F2_RECIPE_INPUT_ROOT_INVALID",
    )
    training_dir = recipe_input_root / _sha(partition_id)[:16]
    training_dir.mkdir(mode=0o700, exist_ok=True)
    requested = set(range(1, 21) if imputations is None else imputations)
    _require(requested <= set(range(1, 21)), "F2_RECIPE_IMPUTATION_SCOPE_INVALID")
    expected = row.get("fit_covariate_members")
    if imputations is not None:
        _require(isinstance(expected, list) and len(expected) == 20
            and [m.get("name") for m in expected] == [f"imp{i:02d}.csv" for i in range(1, 21)],
            "F2_RECIPE_TRAINING_MEMBER_PINS_MISSING")
    members = []
    for imputation in range(1, 21):
        if imputation in requested:
            member = _materialize_recipe_training_member(input_dir / f"imp{imputation:02d}.csv",
                fit_ids, training_dir / f"imp{imputation:02d}.csv")
            if expected is not None:
                _require(member == expected[imputation-1], "F2_RECIPE_TRAINING_MEMBER_DRIFT")
        else:
            member = dict(expected[imputation-1])
        members.append(member)
    fit_ids_sha256 = _sha(fit_ids)
    _require(
        covariates.get("analysis_ids_sha256") == fit_ids_sha256,
        "F2_RECIPE_TRAINING_SCOPE_INVALID",
    )
    analysis_view_sha256 = covariates.get("analysis_view_sha256")
    _require(
        isinstance(analysis_view_sha256, str)
        and _HEX64.fullmatch(analysis_view_sha256) is not None,
        "F2_RECIPE_TRAINING_SCOPE_INVALID",
    )
    main_registry = {
        **predictors["transform_registry"],
        "rows": [
            record
            for record in predictors["transform_registry"]["rows"]
            if record["parent"] != "eGFR_calc"
        ],
    }
    registry_record = {
        "schema_version": "1.0.0",
        "kind": "PADML_F2_RECIPE_REGISTRY_RECORD",
        "input_dir": str(training_dir),
        "fit_ids": fit_ids,
        "members": members,
        "registry": main_registry,
        "conflict_map": predictors["conflict_map"],
    }
    _require(
        set(registry_record) == _RECIPE_REGISTRY_RECORD_KEYS
        and {r['parent'] for r in main_registry['rows']} == {
            r['name'] for r in predictors['variables'] if r['type'] == 'continuous'
            and (r['selector_eligible'] or r['forced'])}
        and "eGFR_calc" not in {record["parent"] for record in main_registry["rows"]},
        "F2_RECIPE_REGISTRY_RECORD_INVALID",
    )
    projection = {
        "partition_id": partition_id,
        "fit_ids_sha256": fit_ids_sha256,
        "analysis_view_sha256": analysis_view_sha256,
        "analysis_ids_sha256": fit_ids_sha256,
        "recipe_registry_record": registry_record,
    }
    _require(
        set(projection) == _RECIPE_PROJECTION_KEYS
        and not _contains_recipe_forbidden_role(projection),
        "F2_RECIPE_RESPONSE_ROLE_REACHABLE",
    )
    return projection


def _validate_recipe_representation_rows(
    representations: Any,
    ordered_parent_column_map: Any,
    predictors: Mapping[str, Any],
    registry_rows: list[dict[str, Any]],
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    expected_by_parent = {row["parent"]: row for row in registry_rows}
    _require(
        isinstance(representations, list)
        and all(isinstance(row, dict) for row in representations)
        and [row.get("parent") for row in representations]
        == [row["parent"] for row in registry_rows],
        "F2_RECIPE_R_VALUES_INVALID",
    )
    expected_map: list[dict[str, Any]] = []
    normalized: list[dict[str, Any]] = []
    representation_contract = predictors["representation_contract"]
    for row in representations:
        _require(
            isinstance(row, dict)
            and set(row)
            == {
                "parent",
                "canonical_unit",
                "representation",
                "design_df",
                "design_columns",
                "parameters",
            },
            "F2_RECIPE_R_VALUES_INVALID",
        )
        expected = expected_by_parent[row["parent"]]
        representation = expected["representation"]
        contract = representation_contract[representation]
        expected_columns = [
            row["parent"] + suffix for suffix in contract["column_suffixes"]
        ]
        _require(
            row["canonical_unit"] == expected["canonical_unit"]
            and row["representation"] == representation
            and row["design_df"] == contract["design_df"]
            and row["design_columns"] == expected_columns,
            "F2_RECIPE_R_VALUES_INVALID",
        )
        parameters = row["parameters"]
        if representation == "IDENTITY":
            _require(
                parameters == {"identity": True},
                "F2_RECIPE_R_VALUES_INVALID",
            )
        elif representation == "LOG1P":
            _require(
                parameters == {"canonical_unit_scale": 1},
                "F2_RECIPE_R_VALUES_INVALID",
            )
        else:
            _require(
                isinstance(parameters, dict)
                and set(parameters)
                == {"boundary_knots", "interior_knots", "quantile_type"}
                and parameters["quantile_type"] == 7
                and isinstance(parameters["boundary_knots"], list)
                and len(parameters["boundary_knots"]) == 2
                and isinstance(parameters["interior_knots"], list)
                and len(parameters["interior_knots"]) == 1,
                "F2_RECIPE_R_VALUES_INVALID",
            )
            q10, q90 = parameters["boundary_knots"]
            q50 = parameters["interior_knots"][0]
            _require(
                all(
                    isinstance(number, (int, float))
                    and not isinstance(number, bool)
                    and math.isfinite(number)
                    for number in (q10, q50, q90)
                )
                and q10 < q50 < q90,
                "F2_RECIPE_SPLINE_PARAMETER_INVALID",
            )
        normalized.append(dict(row))
        expected_map.append(
            {"parent": row["parent"], "columns": expected_columns}
        )
    _require(
        ordered_parent_column_map == expected_map,
        "F2_RECIPE_PARENT_COLUMN_MAP_INVALID",
    )
    return normalized, expected_map


def _validate_transform_recipe(
    recipe: Any,
    predictors: Mapping[str, Any],
) -> dict[str, Any]:
    expected_keys = {
        "recipe_schema_version",
        "kind",
        "partition_id",
        "transform_registry_sha256",
        "analysis_view_sha256",
        "analysis_ids_sha256",
        "fit_ids_sha256",
        "training_member_set_sha256",
        "representations",
        "ordered_parent_column_map",
        "recipe_sha256",
    }
    _require(
        isinstance(recipe, dict)
        and set(recipe) == expected_keys
        and recipe["recipe_schema_version"] == "1.0.0"
        and recipe["kind"] == "PADML_F2_TRANSFORM_RECIPE"
        and isinstance(recipe["partition_id"], str)
        and bool(recipe["partition_id"])
        and recipe["transform_registry_sha256"]
        == predictors["transform_registry_sha256"]
        and recipe["analysis_ids_sha256"] == recipe["fit_ids_sha256"]
        and all(
            isinstance(recipe[field], str)
            and _HEX64.fullmatch(recipe[field]) is not None
            for field in (
                "transform_registry_sha256",
                "analysis_view_sha256",
                "analysis_ids_sha256",
                "fit_ids_sha256",
                "training_member_set_sha256",
                "recipe_sha256",
            )
        )
        and not _contains_recipe_forbidden_role(recipe),
        "F2_TRANSFORM_RECIPE_INVALID",
    )
    registry_rows = [
        row
        for row in predictors["transform_registry"]["rows"]
        if row["parent"] != "eGFR_calc"
    ]
    normalized, expected_map = _validate_recipe_representation_rows(
        recipe["representations"],
        recipe["ordered_parent_column_map"],
        predictors,
        registry_rows,
    )
    _require(
        recipe["representations"] == normalized
        and recipe["ordered_parent_column_map"] == expected_map
        and recipe["recipe_sha256"]
        == _sha({key: value for key, value in recipe.items() if key != "recipe_sha256"}),
        "F2_TRANSFORM_RECIPE_INVALID",
    )
    return dict(recipe)


def _validated_recipe_from_r_values(
    projection: Mapping[str, Any],
    values: Any,
    predictors: Mapping[str, Any],
) -> dict[str, Any]:
    _require(
        isinstance(values, dict)
        and set(values) == {"partition_id", "representations", "ordered_parent_column_map"}
        and values["partition_id"] == projection["partition_id"],
        "F2_RECIPE_R_VALUES_INVALID",
    )
    registry_rows = projection["recipe_registry_record"]["registry"]["rows"]
    normalized, expected_map = _validate_recipe_representation_rows(
        values.get("representations"),
        values.get("ordered_parent_column_map"),
        predictors,
        registry_rows,
    )
    recipe = {
        "recipe_schema_version": "1.0.0",
        "kind": "PADML_F2_TRANSFORM_RECIPE",
        "partition_id": projection["partition_id"],
        "transform_registry_sha256": predictors["transform_registry_sha256"],
        "analysis_view_sha256": projection["analysis_view_sha256"],
        "analysis_ids_sha256": projection["analysis_ids_sha256"],
        "fit_ids_sha256": projection["fit_ids_sha256"],
        "training_member_set_sha256": _sha(
            projection["recipe_registry_record"]["members"]
        ),
        "representations": normalized,
        "ordered_parent_column_map": expected_map,
    }
    recipe["recipe_sha256"] = _sha(recipe)
    return _validate_transform_recipe(recipe, predictors)


def _validate_transform_recipe_set(
    value: Any,
    predictors: Mapping[str, Any],
    *,
    expected_count: int,
) -> dict[str, Any]:
    _require(
        isinstance(value, dict)
        and set(value)
        == {
            "recipe_schema_version",
            "kind",
            "recipe_count",
            "recipes",
            "recipe_set_sha256",
        }
        and value["recipe_schema_version"] == "1.0.0"
        and value["kind"] == "PADML_F2_TRANSFORM_RECIPE_SET"
        and value["recipe_count"] == expected_count
        and isinstance(value["recipes"], list)
        and len(value["recipes"]) == expected_count
        and value["recipe_set_sha256"]
        == _sha(
            {
                key: item
                for key, item in value.items()
                if key != "recipe_set_sha256"
            }
        ),
        "F2_SELECTOR_RECIPE_SET_INVALID",
    )
    recipes = [
        _validate_transform_recipe(recipe, predictors)
        for recipe in value["recipes"]
    ]
    _require(
        len({recipe["partition_id"] for recipe in recipes}) == expected_count,
        "F2_SELECTOR_RECIPE_SET_INVALID",
    )
    return dict(value)


def _compile_transform_recipes(
    spec: Mapping[str, Any],
    registered: Mapping[str, Any],
    partition_ids: list[str],
    scratch: Path,
    repo_root: Path,
    *,
    expected_count: int = 16,
) -> dict[str, Any]:
    _require(
        expected_count in {5, 6, 16}
        and len(partition_ids) == expected_count
        and len(partition_ids) == len(set(partition_ids)),
        "F2_RECIPE_COMPILE_DENOMINATOR_INVALID",
    )
    predictors = spec["predictors"]
    root = scratch / f"f2-recipe-compile-{_sha(partition_ids)[:16]}"
    root.mkdir(mode=0o700)
    try:
        recipe_input_root = root / "training-inputs"
        recipe_input_root.mkdir(mode=0o700)
        projections = [
            _recipe_partition_projection(
                registered,
                partition_id,
                predictors,
                recipe_input_root,
            )
            for partition_id in partition_ids
        ]
        _require(
            all(set(row) == _RECIPE_PROJECTION_KEYS for row in projections)
            and not _contains_recipe_forbidden_role(projections),
            "F2_RECIPE_RESPONSE_ROLE_REACHABLE",
        )
        spec_path = root / "spec.json"
        output_path = root / "output.json"
        compile_spec = {
            "action": "COMPILE_TRANSFORM_RECIPES",
            "expected_count": expected_count,
            "output_path": str(output_path),
            "projections": projections,
        }
        spec_path.write_bytes(canonical_json_bytes(compile_spec))
        environment = dict(os.environ)
        environment.update(THREAD_ENV)
    except BaseException:
        shutil.rmtree(root)
        raise
    try:
        completed = subprocess.run(
            [
                RSCRIPT_EXECUTABLE,
                str(repo_root / "kernels/f2_model_development.R"),
                str(spec_path),
            ],
            cwd=repo_root,
            env=environment,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            check=False,
            timeout=60 * 60,
        )
        if completed.returncode != 0 or not output_path.is_file():
            raise ContractError(
                _r_failure_reason(completed, "F2_RECIPE_COMPILE_FAILED")
            )
        output = strict_json_bytes(
            output_path.read_bytes(),
            "f2-recipe-values.json",
        )
        values = output.get("recipes") if isinstance(output, dict) else None
        _require(
            isinstance(output, dict)
            and output.get("schema_version") == "1.0.0"
            and output.get("kind") == "PADML_F2_R_RECIPE_VALUES"
            and output.get("status") == "PASS"
            and output.get("recipe_count") == expected_count
            and isinstance(values, list)
            and len(values) == expected_count
            and [row.get("partition_id") for row in values if isinstance(row, dict)]
            == partition_ids,
            "F2_RECIPE_COMPILE_DENOMINATOR_INVALID",
        )
        recipes = [
            _validated_recipe_from_r_values(projection, row, predictors)
            for projection, row in zip(projections, values, strict=True)
        ]
    finally:
        shutil.rmtree(root)
    value = {
        "recipe_schema_version": "1.0.0",
        "kind": "PADML_F2_TRANSFORM_RECIPE_SET",
        "recipe_count": expected_count,
        "recipes": recipes,
    }
    value["recipe_set_sha256"] = _sha(value)
    return _validate_transform_recipe_set(
        value,
        predictors,
        expected_count=expected_count,
    )


def _recipe_by_partition(recipe_set: Mapping[str, Any], partition_id: str) -> dict[str, Any]:
    recipes = recipe_set.get("recipes")
    matches = [
        row
        for row in recipes
        if isinstance(row, dict) and row.get("partition_id") == partition_id
    ] if isinstance(recipes, list) else []
    _require(len(matches) == 1, "F2_RECIPE_PARTITION_LOOKUP_INVALID")
    return dict(matches[0])


def _outer_recipe_from_selector(
    selector: Mapping[str, Any],
    predictors: Mapping[str, Any],
) -> dict[str, Any]:
    recipe_set = selector.get("recipe_set")
    recipe_set = _validate_transform_recipe_set(
        recipe_set,
        predictors,
        expected_count=16,
    )
    outer_recipe_sha256 = selector.get("outer_recipe_sha256")
    outer = [
        row
        for row in recipe_set.get("recipes", [])
        if isinstance(row, dict)
        and row.get("recipe_sha256") == outer_recipe_sha256
    ]
    _require(
        isinstance(outer_recipe_sha256, str)
        and _HEX64.fullmatch(outer_recipe_sha256) is not None
        and len(outer) == 1,
        "F2_SELECTOR_OUTER_RECIPE_INVALID",
    )
    return dict(outer[0])


def _selected_design_record(
    selected_parents: list[str],
    predictors: Mapping[str, Any],
    outer_recipe: Mapping[str, Any],
) -> dict[str, Any]:
    parent_columns = _elastic_parent_design_columns(predictors)
    recipe_rows = {
        row["parent"]: row for row in outer_recipe["representations"]
    }
    variables = {row["name"]: row for row in predictors["variables"]}
    ordered = []
    for parent in selected_parents:
        variable = variables[parent]
        representation = (
            recipe_rows[parent]["representation"]
            if variable["type"] == "continuous"
            else "CATEGORICAL_FULL_DUMMY"
        )
        ordered.append(
            {
                "parent": parent,
                "representation": representation,
                "design_df": parent_columns[parent],
                "forced": parent in predictors["forced"],
            }
        )
    return {
        "transform_registry_sha256": predictors["transform_registry_sha256"],
        "outer_recipe_sha256": outer_recipe["recipe_sha256"],
        "ordered_selected_parent_map": ordered,
    }


def compile_model_spec(
    request: dict[str, Any],
    capsule: dict[str, Any],
    lineage: dict[str, Any],
    repo_root: Path,
    selector: dict[str, Any] | None = None,
) -> dict[str, Any]:
    coordinates = {row["axis"]: row["value"] for row in request["plan"]["coordinates"]}
    fold, family = coordinates.get("outer_fold"), coordinates.get("family")
    _require(isinstance(fold, int) and 1 <= fold <= 6 and family in F2_FAMILIES, "F2_MODEL_COORDINATES_INVALID")
    science = capsule["authority_slice"]["science"]
    f2 = science["f2_model_development"]
    route = f2["execution_routes"][family]
    backend = capsule["runtime"]["f2_backend"]
    if route["backend"] == "CPU":
        _require(backend == "CPU", "F2_BACKEND_ROUTE_INVALID")
    _require(family != "XGBOOST_COX" or route.get("r_scientific_dispatch") == "FORBIDDEN", "F2_XGBOOST_ROUTE_INVALID")
    expected_seed = science["modeling_seed_policy"]["model"]["base"] + fold * science["modeling_seed_policy"]["model"]["outer_multiplier"]
    _require(request["seed"] == expected_seed, "F2_MODEL_SEED_INVALID")
    if family == "ELASTIC_NET_COX":
        _require(selector is None, "F2_SELECTOR_DEPENDENCY_UNEXPECTED")
    else:
        _require(
            isinstance(selector, dict)
            and selector.get("artifact_kind") == "F2_MODEL_DEVELOPMENT"
            and selector.get("family") == "ELASTIC_NET_COX"
            and selector.get("fold") == fold
            and selector.get("status") == "PASS",
            "F2_SELECTOR_DEPENDENCY_INVALID",
        )
    validation_centers = science["population"]["validation_centers"]
    heldout_center = validation_centers[fold - 1]
    candidate_sequences: dict[str, list[dict[str, Any]]] = {}
    if family in {"RSF", "GBM_COX", "XGBOOST_COX"}:
        budget = f2["search_budgets"][family]
        space = f2["search_spaces"][family]
        candidate_sequences = {
            "S1": candidate_trials(
                family,
                "S1",
                budget["s1_trials"],
                space,
                f2["candidate_sequence"],
                science["modeling_seed_policy"]["sampler"],
            ),
            "S2": candidate_trials(
                family,
                "S2",
                budget["s2_trials"],
                space,
                f2["candidate_sequence"],
                science["modeling_seed_policy"]["sampler"],
            ),
        }
    elif family == "COXTIME_SET_A":
        candidate_sequences = {"S1": f2["coxtime"]["candidates"], "S2": []}
    execution = execution_contract(request["plan"])
    route_profiles = validate_route_profile_map(
        capsule["manifest"]["identity_records"]["execution_plan"][
            "route_profiles"
        ],
        require_formal=True,
    )
    route_profiles = selected_route_profiles(pool_workers=execution["pool_workers"])
    primary_record = route_profiles[_FAMILY_ROUTE_KEYS[family]]
    primary_profile = primary_record["profile"]
    _require(primary_profile is not None, "F2_PRIMARY_ROUTE_DEFERRED")
    primary_execution = {
        "execution_mode": execution_mode(primary_profile),
        "threads": primary_profile["internal_threads"],
        "pool_workers": primary_profile["pool_workers"],
        "engine_threads": primary_profile["engine_threads"],
    }
    sensitivity_profiles: dict[str, Any] = {}
    for method, route_name in (
        ("MRMRE", "F2_SELECTOR_MRMRE"),
        ("BORUTA", "F2_SELECTOR_BORUTA"),
    ):
        record = route_profiles[route_name]
        profile = record["profile"]
        sensitivity_profiles[method] = {
            "admission_identity": record["admission_identity"],
            "execution": (
                None
                if profile is None
                else {
                    "execution_mode": execution_mode(profile),
                    "threads": profile["internal_threads"],
                    "pool_workers": profile["pool_workers"],
                    "engine_threads": profile["engine_threads"],
                }
            ),
            "selection": record["selection"],
        }
    expected_unit_execution = primary_execution
    if family == "ELASTIC_NET_COX":
        expected_unit_execution = max(
            [
                primary_execution,
                *[
                    row["execution"]
                    for row in sensitivity_profiles.values()
                    if row["execution"] is not None
                ],
            ],
            key=lambda row: row["threads"],
        )
    _require(
        execution == expected_unit_execution,
        "F2_UNIT_ROUTE_EXECUTION_BINDING_INVALID",
    )
    return {
        "schema_version": "1.0.0",
        "action": "MODEL_DEVELOPMENT",
        "fold": fold,
        "family": family,
        "seed": expected_seed,
        "backend": backend,
        **execution,
        "primary_execution": primary_execution,
        "outcome": science["population"]["outcome"],
        "time": science["population"]["time"],
        "horizons": science["horizons_months"],
        "monthly_oof_horizons": f2["f4_monthly_oof_handoff"][
            "horizons_months"
        ],
        "monthly_fit_horizons": f2["f4_monthly_oof_handoff"][
            "horizons_months"
        ][1:],
        "monthly_oof_contract": f2["f4_monthly_oof_handoff"],
        "validation_centers": validation_centers,
        "training_only_center": science["population"]["training_only_centers"][0],
        "heldout_center": heldout_center,
        "primary_metric": science["primary_metric"],
        "inner_repeats": science["resampling"]["inner_repeats"],
        "inner_folds": science["resampling"]["inner_folds"],
        "selector_contract": f2["selector_contract"],
        "selector_sensitivity_contract": selector_sensitivity_contract(
            capsule["authority_slice"]
        ),
        "selector_sensitivity_profiles": sensitivity_profiles,
        "selector_from_dependency": None if selector is None else selector["selector_evidence"],
        "candidate_sequence": f2["candidate_sequence"],
        "candidate_trials": candidate_sequences,
        "multifidelity": f2["multifidelity"],
        "trial_scoring": f2["trial_scoring"],
        "search_space": f2["search_spaces"].get(family),
        "search_budget": f2["search_budgets"].get(family),
        "model_seed_policy": science["modeling_seed_policy"]["model"],
        "coxtime": f2["coxtime"] if family == "COXTIME_SET_A" else None,
        "fpm": science["fpm"] if family == "FPM_TVC_SET_A" else None,
        "predictors": predictor_contract(repo_root, capsule["authority_slice"]),
        "lineage": lineage,
        "identities": request["identities"],
        "unit_id": request["unit_id"],
        "transaction_id": request["transaction_id"],
    }


def _r_failure_reason(completed: subprocess.CompletedProcess[str], fallback: str) -> str:
    detail = completed.stderr or completed.stdout or ""
    tokens = sorted(
        set(
            re.findall(
                r"(?<![A-Z0-9_])((?:F2|LOCKED)_[A-Z0-9_]+)(?![A-Z0-9_])",
                detail,
            )
        )
    )
    return tokens[0] if len(tokens) == 1 else fallback




def _contains_key(value: Any, forbidden: str) -> bool:
    if isinstance(value, dict):
        return forbidden in value or any(
            _contains_key(item, forbidden) for item in value.values()
        )
    if isinstance(value, list):
        return any(_contains_key(item, forbidden) for item in value)
    return False


def _scoped_engine_partition(
    registered: Mapping[str, Any], partition_id: str
) -> Mapping[str, Any]:
    matches = [
        row
        for row in [
            *registered.get("partitions", []),
            *registered.get("diagnostic_partitions", []),
        ]
        if row.get("partition_id") == partition_id
    ]
    _require(len(matches) == 1, "F2_ENGINE_PARTITION_SCOPE_INVALID")
    return matches[0]


def _fpm_reuse_spec(value: Mapping[str, Any]) -> dict[str, Any]:
    """Compare every engine input, allowing only immutable input relocation."""
    answer = json.loads(canonical_json_bytes(dict(value)))
    answer.pop("output_path", None)
    registered = answer["registered_partitions"]
    for row in [*registered["partitions"], *registered.get("diagnostic_partitions", [])]:
        # All member bytes, response bytes, IDs and scientific definitions remain
        # in the comparison; only cache materialization locations are omitted.
        row["covariates"].pop("input_dir", None)
        row["fit_response"].pop("path", None)
    return answer


def _validate_retained_fpm_health(row: Mapping[str, Any], spec: Mapping[str, Any]) -> None:
    from .f2_validation import _validate_fpm_fit_evidence

    stopping = row.get("stopping")
    _require(isinstance(stopping, dict) and stopping.get("converged") is True
             and stopping.get("warning_count") == 0
             and stopping.get("optimizer") == "optim"
             and stopping.get("engine") == "rstpm2::stpm2"
             and [stopping.get("df"), stopping.get("tvc_df")] == spec["fpm"]["set_a_df"]
             and stopping.get("optimizer_convergence") == 0
             and type(stopping.get("coefficient_count")) is int
             and stopping["coefficient_count"] > 0
             and stopping.get("covariance_rank") == stopping["coefficient_count"],
             "F2_FPM_REUSE_HEALTH_INVALID")
    _validate_fpm_fit_evidence(stopping.get("fit_evidence"), spec["fpm"]["set_a_df"],
                               stopping["coefficient_count"])


def _run_r_prediction_partition_batch(
    spec: dict[str, Any],
    registered: dict[str, Any],
    tasks: list[dict[str, Any]],
    scratch: Path,
    repo_root: Path,
    *,
    evaluation_mode: str = "NONE",
    evaluation_partition: Mapping[str, Any] | None = None,
    retained_fpm: Mapping[str, bytes] | None = None,
    preserve_native: bool = False,
) -> list[dict[str, Any]]:
    """Run tasks for one exact partition without exposing response aliases."""

    _require(tasks and len({row.get("task_id") for row in tasks}) == len(tasks), "F2_R_PRODUCER_TASK_SET_INVALID")
    partition_ids = {row.get("partition_id") for row in tasks}
    _require(
        len(partition_ids) == 1
        and None not in partition_ids
        and (
            len(tasks) == 1
            or all(
                row.get("producer_kind")
                not in {
                    "GBM_STOP_CURVE",
                    "ELASTIC_INNER_PATH",
                    "ELASTIC_OUTER_PATH",
                }
                for row in tasks
            )
        ),
        "F2_R_PRODUCER_PARTITION_SCOPE_INVALID",
    )
    scoped_partition = _scoped_engine_partition(
        registered, next(iter(partition_ids))
    )
    _require(
        registered.get("projected_partition_ids") == sorted(partition_ids)
        and registered.get("projected_partition_count") == 1
        and not _contains_key(registered, "evaluation_response"),
        "F2_ENGINE_PARTITION_SCOPE_INVALID",
    )
    producer_kinds = {
        task.get("producer_kind", "SURVIVAL") for task in tasks
    }
    expected_mode = (
        "GROUPED_COX_LOSS"
        if producer_kinds == {"ELASTIC_INNER_PATH"}
        else (
            "GROUPED_COX_LOCK"
            if producer_kinds == {"GBM_STOP_CURVE"}
            else evaluation_mode
        )
    )
    _require(
        evaluation_mode in {
            "NONE",
            "IBS",
            "GROUPED_COX_LOSS",
            "GROUPED_COX_LOCK",
        }
        and (
            (evaluation_mode == "NONE" and evaluation_partition is None)
            or (
                evaluation_mode != "NONE"
                and isinstance(evaluation_partition, Mapping)
                and evaluation_partition.get("partition_id")
                == next(iter(partition_ids))
                and evaluation_partition.get("fit_ids")
                == scoped_partition["fit_ids"]
                and evaluation_partition.get("evaluation_ids")
                == scoped_partition["evaluation_ids"]
                and evaluation_partition.get("evaluation_ids_sha256")
                == scoped_partition["evaluation_ids_sha256"]
                and isinstance(
                    evaluation_partition.get("fit_response"), Mapping
                )
                and isinstance(
                    evaluation_partition.get("evaluation_response"), Mapping
                )
            )
        )
        and (
            evaluation_mode == "NONE"
            or expected_mode == evaluation_mode
            or (
                evaluation_mode == "IBS"
                and producer_kinds == {"SURVIVAL"}
            )
        ),
        "F2_R_CHILD_EVALUATION_SCOPE_INVALID",
    )
    transformed_families = {"ELASTIC_NET_COX", "COX_PH", "FPM_TVC_SET_A"}
    batch_recipe_sha256: set[str] = set()
    batch_recipe: dict[str, Any] | None = None
    for task in tasks:
        recipe = task.get("transform_recipe")
        if task.get("family") in transformed_families:
            validated_recipe = _validate_transform_recipe(
                recipe,
                spec["predictors"],
            )
            batch_recipe_sha256.add(validated_recipe["recipe_sha256"])
            if batch_recipe is None:
                batch_recipe = validated_recipe
            fixed = task.get("fixed_representation_source")
            if validated_recipe["partition_id"] == task["partition_id"]:
                _require(fixed is None, "F2_RECIPE_PARTITION_LOOKUP_INVALID")
            else:
                selector = spec.get("selector_from_dependency")
                _require(
                    fixed
                    == {
                        "kind": "PADML_F2_OUTER_FIXED_REPRESENTATION",
                        "purpose": "LOCKED_MODEL_SAMPLE_SIZE_DIAGNOSTIC",
                        "recipe_partition_id": validated_recipe["partition_id"],
                        "recipe_sha256": validated_recipe["recipe_sha256"],
                    }
                    and isinstance(selector, Mapping)
                    and selector.get("outer_recipe_sha256")
                    == validated_recipe["recipe_sha256"],
                    "F2_RECIPE_PARTITION_LOOKUP_INVALID",
                )
        else:
            _require(
                recipe is None,
                "F2_RAW_FAMILY_TRANSFORM_RECIPE_FORBIDDEN",
            )
    _require(
        len(batch_recipe_sha256) <= 1,
        "F2_RECIPE_BATCH_IDENTITY_MISMATCH",
    )
    engine_registered = registered
    engine_tasks = [
        {key: value for key, value in task.items() if key != "transform_recipe"}
        for task in tasks
    ]
    engine_spec = {
        **spec,
        "action": "MODEL_PREDICTION_BATCH",
        "threads": 1,
        "pool_workers": 1,
        "engine_threads": 1,
        "registered_partitions": engine_registered,
        "transform_recipe": batch_recipe,
        "producer_tasks": engine_tasks,
    }
    _require(
        not _contains_key(engine_spec, "evaluation_response"),
        "F2_ENGINE_EVALUATION_RESPONSE_VISIBLE",
    )
    root = scratch / f"f2-r-batch-{_sha([row['task_id'] for row in tasks])[:16]}"
    root.mkdir()
    spec_path, output_path = root / "spec.json", root / "output.json"
    spec_path.write_bytes(canonical_json_bytes({**engine_spec, "output_path": str(output_path)}))
    from .runtime import activated_environment
    environment = activated_environment()
    if retained_fpm is not None:
        _require(len(tasks) == 1 and tasks[0]["family"] == "FPM_TVC_SET_A"
                 and evaluation_mode == "NONE", "F2_FPM_REUSE_SCOPE_INVALID")
        original_task = strict_json_bytes(retained_fpm["original-task.json"])
        original_spec = strict_json_bytes(retained_fpm["original-spec.json"])
        actual_spec = strict_json_bytes(retained_fpm["spec.json"])
        _require(original_task == tasks[0]
                 and actual_spec == {**original_spec, "output_path": actual_spec["output_path"]}
                 and _fpm_reuse_spec(original_spec) == _fpm_reuse_spec(engine_spec),
                 "F2_FPM_REUSE_INPUT_MISMATCH")
        output_path.write_bytes(retained_fpm["output.json"])
        value = strict_json_bytes(retained_fpm["output.json"])
    elif ("primary_search_source" in spec
          or spec.get("execution_scope") == "F2_OUTER_DEVELOPMENT"
              and {"native_search_root", "native_search_replay", "native_search_numbers"}.intersection(spec)
          or spec.get("execution_scope") == "F4_FULL_PIPELINE_SEARCH"
          or (spec.get("execution_scope") in {"F5_A12_SEARCH", "F5_FULL_DEVELOPMENT_SEARCH"}
              and spec["family"] in {"RSF", "GBM_COX"})):
        from .f4 import _run_full_pipeline_r_search_batch
        value = _run_full_pipeline_r_search_batch(spec_path, output_path, repo_root, environment)
    elif spec.get("execution_scope") == "F5_A12_SEARCH" and spec["family"] == "ELASTIC_NET_COX":
        from .f5_sensitivity import _run_a12_elastic_native_batch
        value = _run_a12_elastic_native_batch(spec_path, output_path, repo_root, environment)
    else:
        value = _execute_r_prediction(spec_path, output_path, repo_root, environment)
    gbm_stop_evaluate = None
    if (("primary_search_source" in spec
             or spec.get("execution_scope") in {"F5_A12_SEARCH", "F5_FULL_DEVELOPMENT_SEARCH"})
            and spec["family"] == "GBM_COX" and evaluation_mode == "GROUPED_COX_LOCK"
            and (not spec.get("native_search_numbers") or "gbm_stop_loss_references" in spec
                 or "gbm_stop_loss_recovery" in spec)):
        from .f4 import _full_pipeline_gbm_stop_evaluate

        def gbm_stop_evaluate(task, sealed, partition, context, evaluate):
            return _full_pipeline_gbm_stop_evaluate(
                engine_spec, task, sealed, partition, context, evaluate)

    return _consume_r_prediction(value, spec, registered, tasks, root,
                                 evaluation_mode, evaluation_partition,
                                 cleanup=not preserve_native, gbm_stop_evaluate=gbm_stop_evaluate)


def _execute_r_prediction(spec_path: Path, output_path: Path,
                          repo_root: Path, environment: Mapping[str, str], *,
                          preserve_logs: bool = False) -> dict[str, Any]:
    completed = subprocess.run(
        [RSCRIPT_EXECUTABLE, str(repo_root / "kernels/f2_model_development.R"), str(spec_path)],
        cwd=repo_root,
        env=environment,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        check=False,
        timeout=6 * 60 * 60,
    )
    if preserve_logs or completed.returncode != 0 or not output_path.is_file():
        (spec_path.parent / "r.stdout.log").write_text(completed.stdout)
        (spec_path.parent / "r.stderr.log").write_text(completed.stderr)
    if completed.returncode != 0 or not output_path.is_file():
        raise ContractError(_r_failure_reason(completed, "F2_R_MODEL_FAILED"))
    return strict_json_bytes(output_path.read_bytes(), "f2-r-prediction-batch.json")


def _consume_r_prediction(value: Any, spec: dict[str, Any], registered: dict[str, Any],
                          tasks: list[dict[str, Any]], root: Path, evaluation_mode: str,
                          evaluation_partition: Mapping[str, Any] | None, *,
                          cleanup: bool = True, gbm_stop_evaluate: Any = None) -> list[dict[str, Any]]:
    """The same native result consumer for fresh and retained prediction bytes."""
    produced = value.get("tasks") if isinstance(value, dict) else None
    _require(
        isinstance(value, dict)
        and value.get("schema_version") == "1.0.0"
        and value.get("kind") == "PADML_F2_R_PREDICTION_BATCH"
        and value.get("status") == "PASS"
        and value.get("task_count") == len(tasks)
        and isinstance(produced, list)
        and [row.get("task_id") for row in produced if isinstance(row, dict)]
        == [row["task_id"] for row in tasks],
        "F2_R_PRODUCER_RESULT_INVALID",
    )
    risk_root = value.risk_root if isinstance(value, _RetainedRRiskValues) else None
    _validate_r_risk_scratch_members(root, tasks, retained_risk_root=risk_root)
    all_partitions = [
        *registered["partitions"],
        *registered.get("diagnostic_partitions", []),
    ]
    by_partition = {row["partition_id"]: row for row in all_partitions}
    evaluation_context = None
    if evaluation_mode == "IBS":
        _require(
            isinstance(evaluation_partition, Mapping),
            "F2_EVALUATION_PARTITION_INVALID",
        )
        evaluation_context = _prediction_evaluation_context(
            evaluation_partition["fit_response"],
            evaluation_partition["evaluation_response"],
            list(evaluation_partition["evaluation_ids"]),
            selection_horizon_months=_selection_horizon_from_spec(spec),
            evaluation_indices=_development_evaluation_indices(evaluation_partition, spec.get("selection_horizon_months", 24)),
        )
    elif evaluation_mode in {"GROUPED_COX_LOSS", "GROUPED_COX_LOCK"}:
        _require(
            isinstance(evaluation_partition, Mapping),
            "F2_EVALUATION_PARTITION_INVALID",
        )
        evaluation_context = _grouped_cox_evaluation_context(
            evaluation_partition["fit_response"],
            evaluation_partition["evaluation_response"],
            list(evaluation_partition["fit_ids"]),
            list(evaluation_partition["evaluation_ids"]),
            evaluation_indices=_development_evaluation_indices(evaluation_partition, spec.get("selection_horizon_months", 24)),
        )
    for task_index, (task, row) in enumerate(
        zip(tasks, produced, strict=True), start=1
    ):
        partition = by_partition.get(task["partition_id"])
        recipe = task.get("transform_recipe")
        expected_recipe_sha256 = (
            recipe.get("recipe_sha256")
            if isinstance(recipe, dict)
            else "RAW_CANONICAL"
        )
        _require(
            isinstance(row, dict)
            and partition is not None
            and row.get("partition_id") == task["partition_id"]
            and row.get("imputation") == task["imputation"]
            and row.get("evaluation_ids") == partition["evaluation_ids"]
            and row.get("transform_recipe_sha256") == expected_recipe_sha256,
            "F2_R_PRODUCER_RESULT_INVALID",
        )
        _validate_r_task_column_map(
            task,
            row.get("ordered_parent_column_map"),
            spec["predictors"],
        )
        if task.get("family") == "FPM_TVC_SET_A":
            _validate_retained_fpm_health(row, spec)
        producer_kind = task.get("producer_kind", "SURVIVAL")
        if task.get("family") in {"RSF", "GBM_COX"} and producer_kind in {
            "SURVIVAL",
            "GBM_STOP_CURVE",
        }:
            row["stopping"] = _validate_r_tree_fit_health(
                task["family"],
                row.get("stopping"),
                parameters=task.get("parameters", {}),
                ordered_parent_column_map=row["ordered_parent_column_map"],
                fit_row_count=len(partition["fit_ids"]),
                stop_curve=producer_kind == "GBM_STOP_CURVE",
            )
        if task.get("family") == "ELASTIC_NET_COX" and producer_kind == "SURVIVAL":
            parameters = task.get("parameters")
            if isinstance(parameters, Mapping) and "ratio_by_imputation" in parameters:
                _require(all(isinstance(parameters.get(key), list) and len(parameters[key]) == 20
                             for key in ("ratio_by_imputation", "lambda_by_imputation", "lambda_upper_bound_by_imputation")),
                         "F2_ELASTIC_FINAL_SPEC_INVALID")
                index = task["imputation"] - 1
                parameters = {
                    "alpha": parameters.get("alpha"),
                    "ratio": parameters["ratio_by_imputation"][index],
                    "lambda": parameters["lambda_by_imputation"][index],
                    "lambda_upper_bound": parameters["lambda_upper_bound_by_imputation"][index],
                }
            _require(
                isinstance(parameters, Mapping)
                and _finite_number(parameters.get("alpha"))
                and _finite_number(parameters.get("ratio"))
                and _finite_number(parameters.get("lambda"))
                and isinstance(recipe, Mapping)
                and isinstance(row.get("stopping"), Mapping)
                and _finite_number(row["stopping"].get("lambda"))
                and math.isclose(
                    float(row["stopping"]["lambda"]),
                    float(parameters["lambda"]),
                    rel_tol=1e-12,
                    abs_tol=1e-15,
                )
                and row["stopping"].get("lambda_upper_bound") == parameters.get("lambda_upper_bound"),
                "F2_ELASTIC_FINAL_SPEC_INVALID",
            )
            row["stopping"] = _validate_elastic_final_lambda_health(
                row.get("stopping"),
                alpha=float(parameters.get("alpha")),
                ratio=float(parameters.get("ratio")),
                ordered_parent_column_map=_expected_family_parent_column_map(
                    _elastic_candidate_parents(spec),
                    "ELASTIC_NET_COX",
                    spec["predictors"],
                    recipe,
                ),
            )
            row["stopping"]["lambda"] = parameters["lambda"]
        if producer_kind in {"ELASTIC_INNER_PATH", "ELASTIC_OUTER_PATH"}:
            _require(
                row.get("fit_ids") == partition["fit_ids"]
                and isinstance(row.get("elastic_paths"), dict),
                "F2_ELASTIC_RATIO_PATH_INVALID",
            )
            paths = row.pop("elastic_paths").get("alphas")
            expected_alphas = task.get("alphas")
            ratios = task.get("ratios")
            _require(
                isinstance(paths, list)
                and isinstance(expected_alphas, list)
                and [path.get("alpha") for path in paths] == expected_alphas
                and isinstance(ratios, list)
                and len(ratios) == 150,
                "F2_ELASTIC_RATIO_PATH_INVALID",
            )
            sealed_paths: list[dict[str, Any]] = []
            actual_event_count = None
            if spec.get("execution_scope") in {"NESTED_FULL_DATA_SELECTOR_M20", "NESTED_NO_AAR_SELECTOR_M20", "NESTED_PRIMARY_SELECTOR_M20"}:
                _, actual_events = _response_arrays(partition["fit_response"], partition["fit_ids"])
                actual_event_count = sum(actual_events)
                _require(actual_event_count == partition["fit_response"]["event_count"] > 0,
                         "NESTED_SELECTOR_EVENT_COUNT_INVALID")
            for path_index, path in enumerate(paths, start=1):
                if actual_event_count is not None:
                    _require(type(path.get("event_count")) is int and path["event_count"] == actual_event_count,
                             "NESTED_SELECTOR_NATIVE_EVENT_COUNT_DRIFT")
                health = _validate_elastic_lambda_path_health(
                    {
                        "lambda_max": path.get("lambda_max"),
                        "lambda_path": path.get("lambda_path"),
                        "lambda_upper_bound": path.get("lambda_upper_bound"),
                        "penalized_active_count_path": path.get(
                            "penalized_active_count_path"
                        ),
                        "penalized_design_column_count": path.get(
                            "penalized_design_column_count"
                        ),
                        "penalized_entry_covered": path.get(
                            "penalized_entry_covered"
                        ),
                    },
                    alpha=float(path["alpha"]),
                    ratios=ratios,
                    ordered_parent_column_map=row["ordered_parent_column_map"],
                    natural_audit=spec.get("ast_alt_natural_audit", False),
                    **({"a12": True} if spec.get("execution_scope") in {
                        "F5_A12_SEARCH", "NESTED_NO_AAR_SELECTOR_M20",
                    } else {}),
                )
                common = {
                    "alpha": float(path["alpha"]),
                    **health,
                    "event_count": path.get("event_count"),
                }
                if producer_kind == "ELASTIC_INNER_PATH":
                    fit_eta, evaluation_eta = (
                        _consume_operation_local_risk_channel(
                            path.pop("risk_matrix_channel", None),
                            root,
                            expected_prefix=(
                                f"risk-{task_index:03d}-alpha-{path_index:03d}"
                            ),
                            fit_rows=len(partition["fit_ids"]),
                            evaluation_rows=len(partition["evaluation_ids"]),
                            columns=150,
                        )
                    )
                    sealed_curve = _seal_cox_risk_curve(
                        partition["fit_ids"],
                        partition["evaluation_ids"],
                        fit_eta,
                        evaluation_eta,
                        150,
                    )
                    if evaluation_mode == "GROUPED_COX_LOSS":
                        assert evaluation_partition is not None
                        loss = _grouped_cox_loss_path(
                            sealed_curve,
                            fit_response=evaluation_partition["fit_response"],
                            evaluation_response=evaluation_partition[
                                "evaluation_response"
                            ],
                            evaluation_context=evaluation_context,
                        )
                        sealed_paths.append(
                            {
                                **common,
                                "risk_curve_sha256": sealed_curve["sha256"],
                                "losses": loss["losses"],
                                **({key: loss[key] for key in (
                                    "fit_response_sha256", "evaluation_response_sha256", "validation_n",
                                )} if spec.get("execution_scope") in {
                                    "NESTED_FULL_DATA_SELECTOR_M20", "NESTED_NO_AAR_SELECTOR_M20", "NESTED_PRIMARY_SELECTOR_M20",
                                } else {}),
                            }
                        )
                    else:
                        sealed_paths.append(
                            {**common, "sealed_risk_curve": sealed_curve}
                        )
                else:
                    parent_columns = path.get("parent_design_columns")
                    parent_coefficients = path.get("parent_coefficients")
                    _require(
                        isinstance(parent_columns, dict)
                        and parent_columns
                        and isinstance(parent_coefficients, dict)
                        and set(parent_columns) == set(parent_coefficients),
                        "F2_ELASTIC_COEFFICIENT_PATH_INVALID",
                    )
                    sealed_paths.append(
                        {
                            **common,
                            "parent_design_columns": parent_columns,
                            "parent_coefficients": parent_coefficients,
                            "coefficient_path_sha256": _sha(
                                {
                                    "parent_design_columns": parent_columns,
                                    "parent_coefficients": parent_coefficients,
                                }
                            ),
                        }
                    )
            row["sealed_elastic_paths"] = sealed_paths
        elif producer_kind == "GBM_STOP_CURVE":
            _require(
                row.get("fit_ids") == partition["fit_ids"]
                and isinstance(row.get("risk_curve"), dict),
                "F2_R_PRODUCER_RESULT_INVALID",
            )
            curve = row.pop("risk_curve")
            _require(
                curve.get("maximum") == task.get("parameters", {}).get("max_trees"),
                "F2_GBM_STOP_CURVE_SPEC_INVALID",
            )
            maximum = curve.get("maximum")
            _require(
                isinstance(maximum, int) and not isinstance(maximum, bool),
                "F2_GBM_STOP_CURVE_SPEC_INVALID",
            )
            fit_eta, evaluation_eta = _consume_operation_local_risk_channel(
                curve.pop("risk_matrix_channel", None),
                risk_root if risk_root is not None else root,
                expected_prefix=f"risk-{task_index:03d}-gbm",
                fit_rows=len(partition["fit_ids"]),
                evaluation_rows=len(partition["evaluation_ids"]),
                columns=maximum,
                retained=risk_root is not None,
            )
            sealed_curve = _seal_cox_risk_curve(
                partition["fit_ids"],
                partition["evaluation_ids"],
                fit_eta,
                evaluation_eta,
                maximum,
            )
            if evaluation_mode == "GROUPED_COX_LOCK":
                assert evaluation_partition is not None
                parameters = task.get("parameters", {})
                def evaluate(*, native_evaluation=None):
                    return _evaluate_grouped_cox_risk_curve(
                        sealed_curve,
                        fit_response=evaluation_partition["fit_response"],
                        evaluation_response=evaluation_partition[
                            "evaluation_response"
                        ],
                        minimum_improvement=float(
                            parameters["minimum_improvement"]
                        ),
                        patience=int(parameters["early_stopping_patience"]),
                        evaluation_context=evaluation_context,
                        native_evaluation=native_evaluation,
                    )

                lock = (evaluate() if gbm_stop_evaluate is None else gbm_stop_evaluate(
                    task, sealed_curve, evaluation_partition, evaluation_context, evaluate))
                row.clear()
                row.update(
                    {
                        "task_id": task["task_id"],
                        "partition_id": task["partition_id"],
                        "imputation": task["imputation"],
                        **lock,
                        "minimum_stopping_loss": lock[
                            "minimum_grouped_cox_deviance"
                        ],
                    }
                )
            else:
                row["sealed_risk_curve"] = sealed_curve
        else:
            prediction_horizons = list(
                task.get("prediction_horizons", spec["horizons"])
            )
            _require(
                prediction_horizons
                in [spec["horizons"], spec.get("monthly_fit_horizons")],
                "F2_R_PRODUCER_HORIZON_SET_INVALID",
            )
            sealed_prediction = _seal_prediction_matrix(
                partition["evaluation_ids"],
                row.get("survival"),
                prediction_horizons,
            )
            if evaluation_mode == "IBS":
                assert evaluation_partition is not None
                horizon = _selection_horizon_from_spec(spec)
                metric = _evaluate_prediction_seal(
                    _monthly_prediction_seal(sealed_prediction),
                    fit_response=evaluation_partition["fit_response"],
                    evaluation_response=evaluation_partition[
                        "evaluation_response"
                    ],
                    evaluation_context=evaluation_context,
                    selection_horizon_months=horizon,
                )
                stopping = row.get("stopping")
                row.clear()
                row.update(
                    {
                        "task_id": task["task_id"],
                        "partition_id": task["partition_id"],
                        "imputation": task["imputation"],
                        "prediction_seal_sha256": sealed_prediction["sha256"],
                        "evaluation_response_sha256": evaluation_partition[
                            "evaluation_response"
                        ]["sha256"],
                        "evaluation_ids_sha256": evaluation_partition[
                            "evaluation_ids_sha256"
                        ],
                        f"ibs_0_{horizon}": metric[f"ibs_0_{horizon}"],
                        "stopping": stopping,
                        "sealed_prediction": sealed_prediction,
                    }
                )
            else:
                row["sealed_prediction"] = sealed_prediction
    if len(tasks) == 1 and tasks[0].get("family") == "FPM_TVC_SET_A":
        for member in ("fit-input.rds", "fit.rds"):
            path = root / member
            if path.exists():
                path.unlink()
    if cleanup:
        shutil.rmtree(root)
    return produced


def _run_r_prediction_pool_task(
    task: tuple[
        dict[str, Any],
        dict[str, Any],
        list[dict[str, Any]],
        str,
        str,
        str,
        Mapping[str, Any] | None,
    ]
) -> list[dict[str, Any]]:
    (
        spec,
        registered,
        tasks,
        scratch,
        repo_root,
        evaluation_mode,
        evaluation_partition,
    ) = task
    return _run_r_prediction_partition_batch(
        spec,
        registered,
        tasks,
        Path(scratch),
        Path(repo_root),
        evaluation_mode=evaluation_mode,
        evaluation_partition=evaluation_partition,
    )


def _r_prediction_child_spec(spec: Mapping[str, Any]) -> dict[str, Any]:
    """Project the exact immutable R prediction contract used by pool children."""

    selector_dependency = spec.get("selector_from_dependency")
    child = {
        "schema_version": spec["schema_version"],
        "fold": spec["fold"],
        "family": spec["family"],
        "seed": spec["seed"],
        "imputation_count": spec.get("imputation_count", 20),
        "outcome": spec["outcome"],
        "time": spec["time"],
        "horizons": spec["horizons"],
        "heldout_center": spec["heldout_center"],
        "predictors": spec["predictors"],
        "fpm": spec["fpm"],
        "selector_from_dependency": (
            {
                "selected_parents": selector_dependency["selected_parents"],
                "outer_recipe_sha256": selector_dependency[
                    "outer_recipe_sha256"
                ],
            }
            if isinstance(selector_dependency, dict)
            else selector_dependency
        ),
    }
    if "seed_audit_candidate" in spec:
        child.update({k: spec[k] for k in ("seed_audit_candidate", "model_seed_policy")})
    if "execution_scope" in spec:
        child["execution_scope"] = spec["execution_scope"]
    if ("primary_search_source" in spec or spec.get("execution_scope") == "F2_OUTER_DEVELOPMENT"
            and {"native_search_root", "native_search_replay", "native_search_numbers"}.intersection(spec)):
        from .f4 import _primary_complex_search_source
        _primary_complex_search_source(spec)
        child.update({key: spec[key] for key in (
            "primary_search_source", "native_search_root", "native_search_replay",
            "registered_inputs_identity_sha256")})
    if "selection_horizon_months" in spec:
        child["selection_horizon_months"] = _selection_horizon_from_spec(spec)
        if "trial_scoring" in spec:
            child["trial_scoring"] = spec["trial_scoring"]
    if spec.get("execution_scope") == "F4_FULL_PIPELINE_SEARCH":
        child.update({key: spec[key] for key in (
            "native_search_root", "native_search_replay", "full_pipeline_source",
            "seta_lock_sha256", "registered_inputs_identity_sha256")})
    if spec.get("execution_scope") == "F5_A12_SEARCH":
        child.update({key: spec[key] for key in (
            "a12_source", "native_search_root", "native_search_replay", "registered_inputs_identity_sha256")})
        if "retained_a12_primary_context_source_bundle" in spec:
            _require(_selection_horizon_from_spec(spec) == 24, "F5_RETAINED_AAR_SOURCE_SCOPE_INVALID")
            child.update({key: spec[key] for key in (
                "retained_a12_primary_context_source_bundle", "a12_executor_source_identity")})
            if "retained_a12_q_executor_source_bundle" in spec:
                child["retained_a12_q_executor_source_bundle"] = spec["retained_a12_q_executor_source_bundle"]
    if spec.get("execution_scope") == "F5_FULL_DEVELOPMENT_SEARCH":
        child.update({key: spec[key] for key in (
            "final_search_source", "native_search_root", "native_search_replay", "registered_inputs_identity_sha256")})
        if "native_audit_evidence_root" in spec:
            child["native_audit_evidence_root"] = spec["native_audit_evidence_root"]
    if "native_search_numbers" in spec:
        from .f4_compact import _full_pipeline_q_numbers_mode
        _require(_full_pipeline_q_numbers_mode(spec), "F4_COMPACT_Q_NUMERICAL_SCOPE_INVALID")
        child["native_search_numbers"] = True
    if "gbm_stop_loss_references" in spec:
        _require(child.get("native_search_numbers") is True and spec["family"] == "GBM_COX",
                 "F4_COMPACT_Q_GBM_LOSS_SCOPE_INVALID")
        child["gbm_stop_loss_references"] = spec["gbm_stop_loss_references"]
    if "retained_gbm_q_source_bundle" in spec:
        _require(child.get("native_search_numbers") is True and spec["family"] == "GBM_COX",
                 "F5_RETAINED_GBM_Q_NUMBERS_ONLY")
        child["retained_gbm_q_source_bundle"] = spec["retained_gbm_q_source_bundle"]
    if "gbm_stop_loss_recovery" in spec:
        _require(child.get("native_search_numbers") is True and spec["family"] == "GBM_COX"
                 and "retained_gbm_q_source_bundle" in child and "gbm_stop_loss_references" not in child,
                 "F5_GBM_LOSS_RECOVERY_SCOPE_INVALID")
        child["gbm_stop_loss_recovery"] = spec["gbm_stop_loss_recovery"]
    if "native_search_complete_missing_values" in spec:
        _require(type(spec["native_search_complete_missing_values"]) is bool
            and spec.get("native_search_replay") is True, "F45_Q_RECOVERY_SCOPE_INVALID")
        child["native_search_complete_missing_values"] = spec["native_search_complete_missing_values"]
    return child


def _r_prediction_task_batches(
    tasks: list[dict[str, Any]], pool_workers: int,
) -> list[list[dict[str, Any]]]:
    """Original R atom geometry, shared by its producer and scoped reader."""
    _require(
        tasks and len({row.get("task_id") for row in tasks}) == len(tasks),
        "F2_R_PRODUCER_TASK_SET_INVALID",
    )
    _require(type(pool_workers) is int and pool_workers >= 1, "F2_EXECUTION_PROFILE_INVALID")
    unbatchable = {
        "GBM_STOP_CURVE",
        "ELASTIC_INNER_PATH",
        "ELASTIC_OUTER_PATH",
    }
    maximum_batch_size = min(
        4,
        max(
            1,
            (len(tasks) - 1) // max(1, pool_workers - 1),
        ),
    )
    batches: list[list[dict[str, Any]]] = []
    open_batches: dict[tuple[str, int, str], int] = {}
    for task in tasks:
        producer_kind = task.get("producer_kind", "SURVIVAL")
        if producer_kind in unbatchable:
            batches.append([task])
            continue
        batch_key = (
            str(task.get("partition_id")),
            int(task.get("imputation")),
            _sha(task.get("transform_recipe")),
        )
        batch_index = open_batches.get(batch_key)
        if (
            batch_index is None
            or len(batches[batch_index]) == maximum_batch_size
        ):
            batches.append([task])
            open_batches[batch_key] = len(batches) - 1
        else:
            batches[batch_index].append(task)
    coalesced: list[list[dict[str, Any]]] = []
    coalesced_open: dict[tuple[str, str], int] = {}
    for batch in batches:
        producer_kind = batch[0].get("producer_kind", "SURVIVAL")
        if producer_kind in unbatchable:
            coalesced.append(batch)
            continue
        coalesced_key = (
            str(batch[0].get("partition_id")),
            _sha(batch[0].get("transform_recipe")),
        )
        coalesced_index = coalesced_open.get(coalesced_key)
        if (
            coalesced_index is None
            or len(coalesced[coalesced_index]) + len(batch)
            > maximum_batch_size
        ):
            coalesced.append(batch)
            coalesced_open[coalesced_key] = len(coalesced) - 1
        else:
            coalesced[coalesced_index].extend(batch)
    batches = coalesced
    for batch in batches:
        _require(
            isinstance(batch[0].get("partition_id"), str)
            and bool(batch[0]["partition_id"]),
            "F2_R_PRODUCER_PARTITION_SCOPE_INVALID",
        )
    return batches


def _run_r_prediction_batch(
    spec: dict[str, Any],
    registered: dict[str, Any],
    tasks: list[dict[str, Any]],
    scratch: Path,
    repo_root: Path,
    *,
    evaluation_mode: str = "NONE",
) -> list[dict[str, Any]]:
    """Preserve task order while each R process sees one partition only."""
    _require(tasks and len({row.get("task_id") for row in tasks}) == len(tasks),
             "F2_R_PRODUCER_TASK_SET_INVALID")
    execution_source = spec["primary_execution"] if spec["family"] == "ELASTIC_NET_COX" else spec
    execution = {key: execution_source[key]
                 for key in ("execution_mode", "threads", "pool_workers", "engine_threads")}
    _require(
        execution["engine_threads"] == 1
        and type(execution["threads"]) is int and execution["threads"] >= 1
        and execution["pool_workers"] == execution["threads"]
        and (execution["execution_mode"] == "PROCESS_POOL"
             or (spec.get("execution_scope") == "F4_FULL_PIPELINE_SEARCH"
                 and execution["execution_mode"] == "INLINE" and execution["pool_workers"] == 1)),
        "F2_EXECUTION_PROFILE_INVALID",
    )
    batches = ([[task] for task in tasks] if "current_q" in spec
               else _r_prediction_task_batches(tasks, execution["pool_workers"]))
    horizon_sets = {
        tuple(row.get("prediction_horizons", spec["horizons"]))
        for row in tasks
    }
    _require(
        len(horizon_sets) == 1,
        "F2_R_PRODUCER_HORIZON_SET_INVALID",
    )
    engine_horizons = list(next(iter(horizon_sets)))
    _require(
        engine_horizons in [spec["horizons"], spec.get("monthly_fit_horizons")],
        "F2_R_PRODUCER_HORIZON_SET_INVALID",
    )
    evaluation_by_partition = {
        row["partition_id"]: row
        for row in [
            *registered["partitions"],
            *registered.get("diagnostic_partitions", []),
        ]
    }
    engine_spec = {
        **_r_prediction_child_spec(spec),
        "horizons": engine_horizons,
    }
    call_args = [
        (
            engine_spec,
            _engine_registered_partitions(
                registered, {str(batch[0]["partition_id"])}
            ),
            batch,
            str(scratch),
            str(repo_root),
            evaluation_mode,
            (
                evaluation_by_partition[str(batch[0]["partition_id"])]
                if evaluation_mode != "NONE"
                else None
            ),
        )
        for batch in batches
    ]
    batch_results = _search_task_batch(
        spec,
        _run_r_prediction_pool_task,
        call_args,
        selected_slots=execution["pool_workers"],
    )
    produced_by_id: dict[str, dict[str, Any]] = {}
    for produced in batch_results:
        for row in produced:
            task_id = row.get("task_id")
            _require(
                isinstance(task_id, str) and task_id not in produced_by_id,
                "F2_R_PRODUCER_RESULT_INVALID",
            )
            produced_by_id[task_id] = row
    _require(
        set(produced_by_id) == {row["task_id"] for row in tasks},
        "F2_R_PRODUCER_RESULT_INVALID",
    )
    return [produced_by_id[row["task_id"]] for row in tasks]


def _evaluate_r_prediction_batch(
    spec: dict[str, Any],
    registered: dict[str, Any],
    tasks: list[dict[str, Any]],
    scratch: Path,
    repo_root: Path,
) -> list[dict[str, Any]]:
    tasks = [
        {**task, "prediction_horizons": spec["monthly_fit_horizons"]}
        for task in tasks
    ]
    produced = _run_r_prediction_batch(
        spec,
        registered,
        tasks,
        scratch,
        repo_root,
        evaluation_mode="IBS",
    )
    expected_keys = {
        "task_id",
        "partition_id",
        "imputation",
        "prediction_seal_sha256",
        "evaluation_response_sha256",
        "evaluation_ids_sha256",
        f"ibs_0_{_selection_horizon_from_spec(spec)}",
        "stopping",
        "sealed_prediction",
    }
    _require(
        all(
            set(row) == expected_keys
            and row["task_id"] == task["task_id"]
            and row["partition_id"] == task["partition_id"]
            and row["imputation"] == task["imputation"]
            for task, row in zip(tasks, produced, strict=True)
        ),
        "F2_R_CHILD_EVALUATION_RESULT_INVALID",
    )
    return produced


def _monthly_prediction_seal(sealed: Mapping[str, Any]) -> dict[str, Any]:
    """Add the defined S(0)=1 without interpolating or replacing fitted values."""

    _require(
        sealed.get("status") == "SEALED"
        and _sha(sealed.get("payload")) == sealed.get("sha256")
        and sealed["payload"]["horizons"] == list(range(1, 37)),
        "F2_MONTHLY_METRIC_GRID_MISSING",
    )
    return _seal_prediction_matrix(
        sealed["payload"]["patient_ids"],
        [[1.0, *row] for row in sealed["payload"]["survival"]],
        list(range(37)),
    )


def _pool_prediction_batch(
    produced: list[dict[str, Any]], horizons: list[int]
) -> dict[str, Any]:
    _require(produced, "F2_PREDICTION_POOL_EMPTY")
    payloads = [row["sealed_prediction"]["payload"] for row in produced]
    patient_ids = payloads[0]["patient_ids"]
    _require(
        all(
            row["patient_ids"] == patient_ids and row["horizons"] == horizons
            for row in payloads
        ),
        "F2_PREDICTION_POOL_IDENTITY_INVALID",
    )
    pooled = [
        [
            math.fsum(row["survival"][patient][column] for row in payloads)
            / len(payloads)
            for column in range(len(horizons))
        ]
        for patient in range(len(patient_ids))
    ]
    return _seal_prediction_matrix(patient_ids, pooled, horizons)


def _partition_evaluation_centers(partition: Mapping[str, Any]) -> list[str]:
    prepared = partition.get("evaluation_centers")
    if prepared is None:
        source = Path(partition["covariates"]["input_dir"]) / "imp01.csv"
        with source.open(newline="", encoding="utf-8-sig") as handle:
            rows = list(csv.DictReader(handle))
        by_id = {row["Patient_ID"]: row["Center"] for row in rows}
        _require(len(by_id) == len(rows), "F2_EVALUATION_CENTER_IDENTITY_INVALID")
    else:
        _require(set(prepared) == {"data_identity", "evaluation_ids_sha256", "values"}
            and prepared["data_identity"] == partition["covariates"]["data_identity"]
            and prepared["evaluation_ids_sha256"] == _sha(partition["evaluation_ids"])
            and len(prepared["values"]) == len(partition["evaluation_ids"]),
            "F2_EVALUATION_CENTER_IDENTITY_INVALID")
        by_id = dict(zip(partition["evaluation_ids"], prepared["values"], strict=True))
    centers: list[str] = []
    for patient_id in partition["evaluation_ids"]:
        try:
            value = Decimal(by_id[patient_id])
            _require(
                value.is_finite() and value == value.to_integral_value(),
                "F2_EVALUATION_CENTER_IDENTITY_INVALID",
            )
            centers.append(str(int(value)))
        except (KeyError, ValueError, ArithmeticError) as exc:
            raise ContractError("F2_EVALUATION_CENTER_IDENTITY_INVALID") from exc
    return centers


def _development_evaluation_indices(partition: Mapping[str, Any], horizon: int) -> list[int] | None:
    """H36 tuning alone excludes center 55 on the validation side.

    Registered rows, full fit data/events and prediction seals retain their
    original identities. External OUTER/CENTER_STRESS consumers are unchanged.
    """
    if horizon != 36 or partition["kind"] not in {"INNER", "STOP"}:
        return None
    indices = [i for i, center in enumerate(_partition_evaluation_centers(partition)) if center != "55"]
    _require(bool(indices), "F45_H36_SCORING_POPULATION_EMPTY")
    return indices


def _trial_scoring_context(partitions: list[dict[str, Any]], *,
                           selection_horizon_months: int = 24) -> dict[str, Any]:
    """Compile one reusable evaluator only after all candidate predictions seal."""

    kinds = {row["kind"] for row in partitions}
    _require(kinds in ({"INNER"}, {"CENTER_STRESS"}, {"OUTER"}), "F2_TRIAL_PARTITIONS_INVALID")
    groups = (
        [
            [row for row in partitions if row["repeat"] == repeat]
            for repeat in sorted({row["repeat"] for row in partitions})
        ]
        if kinds == {"INNER"}
        else [[row] for row in partitions]
    )
    if kinds == {"INNER"}:
        _require(
            all([row["inner_fold"] for row in group] == [1, 2, 3, 4, 5] for group in groups),
            "F2_REPEAT_OOF_INCOMPLETE",
        )
    fold_contexts = {
        row["partition_id"]: _prediction_evaluation_context(
            row["fit_response"], row["evaluation_response"], row["evaluation_ids"],
            selection_horizon_months=selection_horizon_months,
            evaluation_indices=_development_evaluation_indices(row, selection_horizon_months),
        )
        for row in partitions
    }
    ranking_groups = []
    for group in groups:
        ids = [patient_id for row in group for patient_id in row["evaluation_ids"]]
        fields: list[str] = []
        response_rows: dict[str, dict[str, str]] = {}
        centers: list[str] = []
        for partition in group:
            response = partition["evaluation_response"]
            raw = (
                response["private_bytes"]
                if "private_bytes" in response
                else Path(response["path"]).read_bytes()
            )
            current_fields, current_rows = _response_rows(raw)
            _require(
                (not fields or fields == current_fields)
                and not set(response_rows) & set(current_rows),
                "F2_REPEAT_OOF_ROW_OVERLAP",
            )
            fields = current_fields
            response_rows.update(current_rows)
            centers.extend(_partition_evaluation_centers(partition))
        response = _write_response_subset(fields, response_rows, ids, None)
        ranking_groups.append(
            {
                "partition_ids": [row["partition_id"] for row in group],
                "response": response,
                "context": _center_stratified_evaluation_context(response, ids, centers,
                    selection_horizon_months=selection_horizon_months,
                    evaluation_indices=([i for i, center in enumerate(centers) if center != "55"]
                        if selection_horizon_months == 36 and kinds == {"INNER"} else None)),
            }
        )
    return {
        **({"selection_horizon_months": selection_horizon_months} if selection_horizon_months != 24 else {}),
        "partitions": partitions,
        "fold_contexts": fold_contexts,
        "ranking_groups": ranking_groups,
    }


def _trial_evaluation_summary(
    evaluated: list[dict[str, Any]],
    context: Mapping[str, Any],
    imputation_count: int,
) -> dict[str, Any]:
    """Pool MI probabilities first; rank only complete repeat-level OOF metrics."""

    partitions = context["partitions"]
    horizon = context.get("selection_horizon_months", 24)
    _require(type(horizon) is int and horizon in {6, 12, 24, 36}, "F2_SELECTION_HORIZON_INVALID")
    metric_key = f"ibs_0_{horizon}"
    _require(
        len(evaluated) == len(partitions) * imputation_count,
        "F2_TRIAL_MI_DENOMINATOR_INVALID",
    )
    pooled: dict[str, dict[str, Any]] = {}
    for partition in partitions:
        partition_id = partition["partition_id"]
        values = [row for row in evaluated if row["partition_id"] == partition_id]
        _require(all(metric_key in row and not any(f"ibs_0_{h}" in row for h in (6, 12, 24, 36) if h != horizon) for row in values),
                 "F2_TRIAL_EVALUATION_HORIZON_MISMATCH")
        _require(
            [row["imputation"] for row in values] == list(range(1, imputation_count + 1)),
            "F2_TRIAL_MI_DENOMINATOR_INVALID",
        )
        sealed = _pool_prediction_batch(
            [{"sealed_prediction": _monthly_prediction_seal(row["sealed_prediction"])} for row in values],
            list(range(37)),
        )
        _require(
            sealed["payload"]["patient_ids"] == partition["evaluation_ids"],
            "F2_TRIAL_PREDICTION_ROW_IDENTITY_INVALID",
        )
        pooled[partition_id] = sealed
    return _trial_summary_from_pooled(
        pooled, [row[metric_key] for row in evaluated], context, imputation_count,
    )


def _trial_summary_from_pooled(
    pooled: Mapping[str, Mapping[str, Any]], metric_values: list[float],
    context: Mapping[str, Any], imputation_count: int,
) -> dict[str, Any]:
    """The original fold/repeat arithmetic, after partition-local MI pooling.

    Streaming consumers may release each M20 batch after using the original
    _pool_prediction_batch; neither means of metrics nor fold averages enter
    the repeat score here.
    """
    partitions = context["partitions"]
    horizon = context.get("selection_horizon_months", 24)
    _require(type(horizon) is int and horizon in {6, 12, 24, 36}, "F2_SELECTION_HORIZON_INVALID")
    metric_key = f"ibs_0_{horizon}"
    _require(type(imputation_count) is int and imputation_count > 0
             and len(metric_values) == len(partitions) * imputation_count
             and all(_finite_number(value) and value >= 0 for value in metric_values)
             and set(pooled) == {row["partition_id"] for row in partitions},
             "F2_TRIAL_MI_DENOMINATOR_INVALID")
    fold_metrics: list[float] = []
    for partition in partitions:
        partition_id = partition["partition_id"]
        sealed = pooled[partition_id]
        _require(sealed["payload"]["patient_ids"] == partition["evaluation_ids"]
                 and sealed["payload"]["horizons"] == list(range(37)),
                 "F2_TRIAL_PREDICTION_ROW_IDENTITY_INVALID")
        fold_metrics.append(
            _evaluate_prediction_seal(
                sealed,
                fit_response=partition["fit_response"],
                evaluation_response=partition["evaluation_response"],
                evaluation_context=context["fold_contexts"][partition_id],
                selection_horizon_months=horizon,
            )[metric_key]
        )
    ranking: list[dict[str, Any]] = []
    for group in context["ranking_groups"]:
        payloads = [pooled[partition_id]["payload"] for partition_id in group["partition_ids"]]
        sealed = _seal_prediction_matrix(
            [patient_id for payload in payloads for patient_id in payload["patient_ids"]],
            [row for payload in payloads for row in payload["survival"]],
            list(range(37)),
        )
        ranking.append(
            _evaluate_prediction_seal(
                sealed,
                fit_response=group["response"],
                evaluation_response=group["response"],
                evaluation_context=group["context"],
                selection_horizon_months=horizon,
            )
        )
    scores = [row[metric_key] for row in ranking]
    return {
        **({"selection_horizon_months": horizon} if horizon != 24 else {}),
        "metric_values": metric_values,
        "fold_metric_values": fold_metrics,
        "ranking_metric_values": scores,
        "ranking_metric_qc": [row["ipcw_qc"] for row in ranking],
        "ranking_evaluation_count": len(scores),
        "mean_ibs": math.fsum(scores) / len(scores),
        "maximum_ibs": max(scores),
        "evaluation_units": len(metric_values),
    }


def _inline_monthly_oof(
    produced: list[dict[str, Any]],
    monthly_horizons: list[int],
    projection_horizons: list[int],
) -> tuple[dict[str, Any], dict[str, Any]]:
    """Seal the private monthly grid and its exact registered projection."""

    _require(
        monthly_horizons == list(range(37))
        and projection_horizons == [6, 12, 24, 36],
        "F2_MONTHLY_OOF_AUTHORITY_INVALID",
    )
    fitted = _pool_prediction_batch(produced, monthly_horizons[1:])
    patient_ids = fitted["payload"]["patient_ids"]
    matrix = [[1.0, *row] for row in fitted["payload"]["survival"]]
    monthly = _seal_prediction_matrix(patient_ids, matrix, monthly_horizons)
    indices = [monthly_horizons.index(value) for value in projection_horizons]
    projection = _seal_prediction_matrix(
        patient_ids,
        [[row[index] for index in indices] for row in matrix],
        projection_horizons,
    )
    return monthly, projection


def _require_prediction_scientific_variation(matrix: list[list[float]]) -> None:
    """Validate probabilities; identical patient curves can be genuine fits."""

    _require(
        isinstance(matrix, list)
        and len(matrix) >= 1
        and all(isinstance(row, list) and row for row in matrix)
        and len({len(row) for row in matrix}) == 1,
        "F2_PREDICTION_MATRIX_INVALID",
    )
    _require(
        all(all(_finite_number(value) and 0 <= value <= 1 for value in row)
            and all(left + 1e-10 >= right for left, right in zip(row, row[1:]))
            for row in matrix),
        "F2_PREDICTION_MATRIX_INVALID",
    )


def _registered_execution_object(
    spec: Mapping[str, Any],
    registered: Mapping[str, Any],
    rows: list[dict[str, Any]],
) -> dict[str, Any]:
    rank = {"INNER": 0, "STOP": 1, "CENTER_STRESS": 2, "OUTER": 3}
    ordered_rows = sorted(
        rows,
        key=lambda row: (
            rank.get(row.get("kind"), 99),
            row.get("repeat", 0),
            row.get("inner_fold", 0),
            row.get("partition_id", "").encode("utf-8"),
        ),
    )
    _require(
        len({row.get("partition_id") for row in ordered_rows}) == len(ordered_rows),
        "F2_REGISTERED_EXECUTION_PARTITION_SET_INVALID",
    )
    value = {
        "schema_version": "1.0.0",
        "kind": "PADML_F2_REGISTERED_PARTITION_EXECUTION",
        "fold": spec["fold"],
        "family": spec["family"],
        "registered_input_identity": registered["identity"],
        "expected_partition_count": len(ordered_rows),
        "executed_partition_count": len(ordered_rows),
        "partitions": ordered_rows,
    }
    reused = sum(row.get("evidence_kind") == "REUSED_SEARCH_PATHS" for row in ordered_rows)
    if reused:
        _require(spec["family"] == "ELASTIC_NET_COX" and reused == 15 and len(ordered_rows) == 16,
                 "F2_REUSED_SEARCH_EXECUTION_SCOPE_INVALID")
        value.update(schema_version="1.1.0", reused_partition_count=reused,
                     executed_partition_count=len(ordered_rows) - reused)
    value["identity"] = _sha(value)
    return value


def _build_registered_model_result(
    spec: dict[str, Any],
    registered: dict[str, Any],
    produced: list[dict[str, Any]],
    *,
    selector: dict[str, Any],
    search_trace: dict[str, Any],
    search_evaluation_unit_count: int,
    selected_spec: dict[str, Any],
    execution_rows: list[dict[str, Any]],
) -> dict[str, Any]:
    outer_rows = [row for row in registered["partitions"] if row["kind"] == "OUTER"]
    _require(len(outer_rows) == 1, "F2_REGISTERED_OUTER_PARTITION_INVALID")
    outer = outer_rows[0]
    _require(
        len(produced) == 20
        and [row.get("imputation") for row in produced]
        == list(range(1, 21))
        and all(
            row.get("partition_id") == outer["partition_id"]
            and isinstance(row.get("sealed_prediction"), Mapping)
            for row in produced
        ),
        "F2_FINAL_PREDICTION_SEAL_SET_INVALID",
    )
    if spec["family"] in {"XGBOOST_COX", "COXTIME_SET_A"}:
        _require(
            all(
                set(row)
                == {
                    "partition_id",
                    "imputation",
                    "prediction_seal_sha256",
                    "stopping",
                    "sealed_prediction",
                }
                for row in produced
            ),
            "F2_FINAL_RESPONSE_FREE_SEAL_INVALID",
        )
    monthly, pooled = _inline_monthly_oof(
        produced,
        spec["monthly_oof_horizons"],
        spec["horizons"],
    )
    _require_prediction_scientific_variation(
        pooled["payload"]["survival"]
    )
    metric = _evaluate_prediction_seal(
        monthly,
        fit_response=outer["evaluation_response"],
        evaluation_response=outer["evaluation_response"],
        evaluation_context=_center_stratified_evaluation_context(
            outer["evaluation_response"],
            outer["evaluation_ids"],
            [str(spec["heldout_center"])] * len(outer["evaluation_ids"]),
        ),
    )
    execution_rows = [
        *execution_rows,
        {
            "kind": "OUTER",
            "partition_id": outer["partition_id"],
            "repeat": 0,
            "inner_fold": 0,
            "purpose": "FINAL_EVALUATION",
            "input_record_sha256": _sha(
                _registered_partition_identity_record(outer)
            ),
            "prediction_seal_count": len(produced),
            "evaluation_count": 1,
            "evaluation_response_sha256": outer["evaluation_response"]["sha256"],
            "evaluation_ids_sha256": outer["evaluation_ids_sha256"],
            "prediction_seal_set_sha256": _sha(
                [row["sealed_prediction"]["sha256"] for row in produced]
            ),
            "final_prediction_seal_sha256": pooled["sha256"],
            "metric_prediction_seal_sha256": monthly["sha256"],
            "metric_set_sha256": _sha([metric["ibs_0_24"]]),
            "ibs_0_24": metric["ibs_0_24"],
            "metric_qc": metric["ipcw_qc"],
        },
    ]
    matrix = pooled["payload"]["survival"]
    predictions = [
        {"Patient_ID": patient_id, "survival": matrix[index]}
        for index, patient_id in enumerate(pooled["payload"]["patient_ids"])
    ]
    monthly_matrix = monthly["payload"]["survival"]
    monthly_predictions = [
        {"Patient_ID": patient_id, "survival": monthly_matrix[index]}
        for index, patient_id in enumerate(monthly["payload"]["patient_ids"])
    ]
    elastic_binding: dict[str, Any] = {}
    if spec["family"] == "ELASTIC_NET_COX":
        selected_parents = selected_spec["selected_parents"]
        _require(
            selector.get("selected_design_sha256")
            == _sha(
                _selected_design_record(
                    selected_parents,
                    spec["predictors"],
                    _outer_recipe_from_selector(selector, spec["predictors"]),
                )
            ),
            "F2_SELECTOR_SELECTED_DESIGN_INVALID",
        )
        elastic_binding = {
            "selected_design_sha256": selector["selected_design_sha256"],
            "selected_parent_sha256": _sha(selected_parents),
        }
    stopping = [
        {
            **(row.get("stopping") or {}),
            "imputation": row["imputation"],
            **elastic_binding,
            "prediction_seal_sha256": row["sealed_prediction"]["sha256"],
        }
        for row in produced
    ]
    numeric_qc = {
        "prediction_count": len(predictions) * len(spec["horizons"]),
        "finite_count": sum(
            math.isfinite(value) for row in matrix for value in row
        ),
        "minimum_survival": min(value for row in matrix for value in row),
        "maximum_survival": max(value for row in matrix for value in row),
        "monotonic_violation_count": sum(
            any(left + 1e-10 < right for left, right in zip(row, row[1:]))
            for row in matrix
        ),
    }
    return {
        "schema_version": "1.0.0",
        "artifact_kind": "F2_MODEL_DEVELOPMENT",
        "status": "PASS",
        "fold": spec["fold"],
        "heldout_center": spec["heldout_center"],
        "family": spec["family"],
        "backend": spec["backend"],
        "threads": spec["threads"],
        "pool_workers": spec["pool_workers"],
        "engine_threads": spec["engine_threads"],
        "lineage": spec["lineage"],
        "row_universe": {
            "training_count": len(outer["fit_ids"]),
            "heldout_count": len(outer["evaluation_ids"]),
            "training_ids_sha256": _sha(outer["fit_ids"]),
            "heldout_ids_sha256": outer["evaluation_ids_sha256"],
            "overlap_count": 0,
        },
        "selector_evidence": selector,
        "search_trace": search_trace,
        "search_evaluation_unit_count": search_evaluation_unit_count,
        "selected_spec": selected_spec,
        "predictions": predictions,
        "prediction_horizons": spec["horizons"],
        "monthly_oof": {
            "schema_version": "MONTHLY_OOF_V1",
            "classification": "PRIVATE_SCIENCE",
            "horizons": spec["monthly_oof_horizons"],
            "predictions": monthly_predictions,
        },
        "monthly_oof_sha256": monthly["sha256"],
        "stopping_and_convergence": stopping,
        "numeric_qc": numeric_qc,
        "registered_partition_execution": _registered_execution_object(
            spec, registered, execution_rows
        ),
        "retained_model_binary_count": 0,
        "heldout_outcome_read_count_for_selection": 0,
        "typed_terminal": "PASS",
    }


def _run_r_registered_cox_ph(
    spec: dict[str, Any],
    registered: dict[str, Any],
    scratch: Path,
    repo_root: Path,
) -> dict[str, Any]:
    _require(spec["search_budget"] == {"formal_confirmation": "M20_X15"},
             "F2_COX_PH_FORMAL_CONFIRMATION_CONTRACT_INVALID")
    outer_rows = [row for row in registered["partitions"] if row["kind"] == "OUTER"]
    _require(len(outer_rows) == 1, "F2_REGISTERED_OUTER_PARTITION_INVALID")
    outer = outer_rows[0]
    selected = list(spec["selector_from_dependency"]["selected_parents"])
    outer_recipe = _outer_recipe_from_selector(
        spec["selector_from_dependency"],
        spec["predictors"],
    )
    inner = sorted((row for row in registered["partitions"] if row["kind"] == "INNER"),
                   key=lambda row: (row["repeat"], row["inner_fold"]))
    _require([(row["repeat"], row["inner_fold"]) for row in inner]
             == [(repeat, fold) for repeat in range(1, 4) for fold in range(1, 6)],
             "F2_COX_PH_FORMAL_CONFIRMATION_PARTITIONS_INVALID")
    recipes = [_recipe_by_partition(spec["selector_from_dependency"]["recipe_set"], row["partition_id"])
               for row in inner]
    confirmation_tasks = [
        {"task_id": f"CONFIRM_R{partition['repeat']}K{partition['inner_fold']}_M{imputation:02d}",
         "partition_id": partition["partition_id"], "imputation": imputation,
         "family": "COX_PH", "selected_parents": selected, "parameters": {},
         "transform_recipe": recipe,
         "seed": spec["seed"] + partition["repeat"] * spec["model_seed_policy"]["repeat_multiplier"]
         + partition["inner_fold"] * spec["model_seed_policy"]["inner_multiplier"] + imputation}
        for partition, recipe in zip(inner, recipes, strict=True)
        for imputation in range(1, 21)
    ]
    evaluated = _evaluate_r_prediction_batch(spec, registered, confirmation_tasks, scratch, repo_root)
    confirmation = {
        "candidate_id": "COX_PH_FIXED", "parameters": {"ties": "breslow"},
        "parameter_sha256": _sha({"ties": "breslow"}),
        "selected_parent_sha256": _sha(selected), "imputation_count": 20,
        "partition_ids": [row["partition_id"] for row in inner],
        "recipe_sha256s": [row["recipe_sha256"] for row in recipes],
        "prediction_seal_sha256s": [row["prediction_seal_sha256"] for row in evaluated],
        **_trial_evaluation_summary(evaluated, _trial_scoring_context(inner), 20),
    }
    accumulator: dict[str, list[dict[str, Any]]] = {}
    _accumulate_registered_evaluations(accumulator, evaluated)
    execution_rows = [{**row, "purpose": "FORMAL_CONFIRMATION"}
                      for row in _registered_selection_execution_rows(registered, accumulator)]
    tasks = [
        {
            "task_id": f"FINAL_OUTER_M{imputation:02d}",
            "partition_id": outer["partition_id"],
            "imputation": imputation,
            "family": "COX_PH",
            "selected_parents": selected,
            "parameters": {},
            "transform_recipe": outer_recipe,
            "prediction_horizons": spec["monthly_fit_horizons"],
            "seed": spec["seed"] + imputation,
        }
        for imputation in range(1, 21)
    ]
    produced = _run_r_prediction_batch(spec, registered, tasks, scratch, repo_root)
    return _build_registered_model_result(
        spec,
        registered,
        produced,
        selector=spec["selector_from_dependency"],
        search_trace={"FORMAL_CONFIRMATION": [confirmation]},
        search_evaluation_unit_count=320,
        selected_spec={
            "family": "COX_PH",
            "selected_parents": selected,
            "ties": "breslow",
        },
        execution_rows=execution_rows,
    )


def _run_r_registered_fpm(
    spec: dict[str, Any],
    registered: dict[str, Any],
    scratch: Path,
    repo_root: Path,
    *, retained_fpm: Mapping[str, bytes] | None = None,
) -> dict[str, Any]:
    outer = [row for row in registered["partitions"] if row["kind"] == "OUTER"]
    _require(len(outer) == 1, "F2_REGISTERED_OUTER_PARTITION_INVALID")
    selected = list(spec["selector_from_dependency"]["selected_parents"])
    outer_recipe = _outer_recipe_from_selector(
        spec["selector_from_dependency"],
        spec["predictors"],
    )
    tasks = [
        {
            "task_id": f"FINAL_OUTER_M{imputation:02d}",
            "partition_id": outer[0]["partition_id"],
            "imputation": imputation,
            "family": "FPM_TVC_SET_A",
            "selected_parents": selected,
            "parameters": {},
            "transform_recipe": outer_recipe,
            "prediction_horizons": spec["monthly_fit_horizons"],
            "seed": spec["seed"] + imputation,
        }
        for imputation in range(1, 21)
    ]
    retained = []
    if retained_fpm is not None:
        original = strict_json_bytes(retained_fpm["original-task.json"])
        matching = [task for task in tasks if task["task_id"] == original.get("task_id")]
        _require(len(matching) == 1 and matching[0] == original, "F2_FPM_REUSE_TASK_INVALID")
        retained = _run_r_prediction_partition_batch(
            {**_r_prediction_child_spec(spec), "horizons": spec["monthly_fit_horizons"]},
            _engine_registered_partitions(registered, {matching[0]["partition_id"]}),
            matching, scratch, repo_root, retained_fpm=retained_fpm)
    remaining = [task for task in tasks if task["task_id"] not in {row["task_id"] for row in retained}]
    produced = _run_r_prediction_batch(spec, registered, remaining, scratch, repo_root)
    by_task = {row["task_id"]: row for row in [*retained, *produced]}
    _require(len(by_task) == 20, "F2_FPM_REUSE_DENOMINATOR_INVALID")
    produced = [by_task[task["task_id"]] for task in tasks]
    return _build_registered_model_result(
        spec,
        registered,
        produced,
        selector=spec["selector_from_dependency"],
        search_trace={},
        search_evaluation_unit_count=20,
        selected_spec={
            "family": "FPM_TVC_SET_A",
            "selected_parents": selected,
            "df": spec["fpm"]["set_a_df"],
            "tvc_parent": "AST_ALT",
        },
        execution_rows=[],
    )


def _locked_categorical_contract(
    row: Mapping[str, Any],
) -> tuple[list[str], str]:
    fields = [item.strip() for item in row["levels_or_coding"].split(";")]
    level_fields = [item for item in fields if item.startswith("levels=")]
    reference_fields = [item for item in fields if item.startswith("reference=")]
    _require(
        fields
        and all(fields)
        and len(level_fields) == 1
        and len(reference_fields) == 1,
        "F2_PYTHON_CATEGORICAL_CONTRACT_INVALID",
    )
    levels = level_fields[0].removeprefix("levels=").split("|")
    reference_token = reference_fields[0].removeprefix("reference=")
    reference_matches = [
        level
        for level in levels
        if reference_token == level
        or reference_token.startswith(level + " (")
    ]
    _require(
        levels
        and all(levels)
        and len(levels) == len(set(levels))
        and all(level == level.strip() for level in levels)
        and len(reference_matches) == 1,
        "F2_PYTHON_CATEGORICAL_CONTRACT_INVALID",
    )
    return levels, reference_matches[0]


def _locked_categorical_levels(row: Mapping[str, Any]) -> list[str]:
    return _locked_categorical_contract(row)[0]


def _expected_family_parent_column_map(
    selected: Any,
    family: Any,
    predictors: Mapping[str, Any],
    recipe: Any,
) -> list[dict[str, Any]]:
    _require(
        isinstance(selected, list)
        and selected
        and family in F2_FAMILIES,
        "F2_R_DESIGN_COLUMN_MAP_INVALID",
    )
    recipe_by_parent: dict[str, Mapping[str, Any]] = {}
    if isinstance(recipe, dict):
        validated_recipe = _validate_transform_recipe(recipe, predictors)
        recipe_by_parent = {
            row["parent"]: row
            for row in validated_recipe["representations"]
        }
    _require(
        bool(recipe_by_parent)
        == (family in {"ELASTIC_NET_COX", "COX_PH", "FPM_TVC_SET_A"}),
        "F2_R_DESIGN_COLUMN_MAP_INVALID",
    )
    variables = {row["name"]: row for row in predictors["variables"]}
    expected_map: list[dict[str, Any]] = []
    for parent in selected:
        _require(parent in variables, "F2_R_DESIGN_COLUMN_MAP_INVALID")
        variable = variables[parent]
        if variable["type"] == "continuous":
            expected = (
                [parent]
                if family in {"RSF", "GBM_COX", "XGBOOST_COX", "COXTIME_SET_A"}
                else recipe_by_parent[parent]["design_columns"]
            )
        else:
            levels, reference = _locked_categorical_contract(variable)
            if family in {"COX_PH", "FPM_TVC_SET_A"}:
                levels = [level for level in levels if level != reference]
            separator = "_" if family in {"XGBOOST_COX", "COXTIME_SET_A"} else ""
            expected = [parent + separator + level for level in levels]
        expected_map.append({"parent": parent, "columns": expected})
    return expected_map


def _validate_r_task_column_map(
    task: Mapping[str, Any],
    observed: Any,
    predictors: Mapping[str, Any],
) -> None:
    expected = _expected_family_parent_column_map(
        task.get("selected_parents"),
        task.get("family"),
        predictors,
        task.get("transform_recipe"),
    )
    _require(observed == expected, "F2_R_DESIGN_COLUMN_MAP_INVALID")


def _model_family_design_binding(
    family: str,
    selector: Mapping[str, Any],
    predictors: Mapping[str, Any],
) -> dict[str, Any]:
    selected = selector.get("selected_parents")
    _require(
        isinstance(selected, list)
        and selected
        and selector.get("selected_parent_sha256") == _sha(selected),
        "F2_FAMILY_DESIGN_BINDING_INVALID",
    )
    _validate_transform_conflicts(selected, predictors)
    transformed = family in {"ELASTIC_NET_COX", "COX_PH", "FPM_TVC_SET_A"}
    outer_recipe = (
        _outer_recipe_from_selector(selector, predictors) if transformed else None
    )
    policy = predictors["family_policy"][family]
    column_map = _expected_family_parent_column_map(
        selected,
        family,
        predictors,
        outer_recipe,
    )
    return {
        "schema_version": "1.0.0",
        "kind": "PADML_F2_FAMILY_DESIGN_BINDING",
        "family": family,
        "mode": "TRANSFORM_RECIPE" if transformed else "RAW_CANONICAL",
        "transform_registry_sha256": predictors["transform_registry_sha256"],
        "continuous_policy": policy["continuous"],
        "categorical_policy": policy["categorical"],
        "scaling": policy["scaling"],
        "selected_parent_sha256": _sha(selected),
        "ordered_parent_column_map": column_map,
        "ordered_parent_column_map_sha256": _sha(column_map),
        "recipe_partition_id": (
            outer_recipe["partition_id"] if outer_recipe is not None else None
        ),
        "recipe_sha256": (
            outer_recipe["recipe_sha256"] if outer_recipe is not None else None
        ),
    }


def _elastic_parent_design_columns(
    predictors: Mapping[str, Any],
) -> dict[str, int]:
    selected = sorted(
        (
            row
            for row in predictors["variables"]
            if row["selector_eligible"] or row["forced"]
        ),
        key=lambda row: row["name"].encode("utf-8"),
    )
    columns = {
        row["name"]: (
            len(_locked_categorical_levels(row))
            if row["type"] in {"binary", "ordered", "unordered"}
            else (
                2
                if row.get("selector_representation") == "NATURAL_SPLINE_K3"
                else 1
            )
        )
        for row in selected
    }
    _require(
        "AST_ALT" in columns and set(columns) == set(selector_parent_names()),
        "F2_SELECTOR_ELIGIBLE_DENOMINATOR_INVALID",
    )
    _validate_transform_conflicts(list(columns), predictors)
    return columns


def _elastic_candidate_parents(spec: Mapping[str, Any]) -> list[str]:
    parents = list(_elastic_parent_design_columns(spec["predictors"]))
    if spec.get("execution_scope") == "NESTED_NO_AAR_SELECTOR_M20":
        parents = [parent for parent in parents if parent not in {"AST", "ALT", "AST_ALT"}]
        _require(set(parents) == set(selector_parent_names()) - {"AST_ALT"},
                 "NESTED_NO_AAR_SELECTOR_ELIGIBLE_DENOMINATOR_INVALID")
    return parents


def _selector_sensitivity_seed(
    spec: Mapping[str, Any], method: str, imputation: int
) -> int:
    _require(
        method in {"MRMRE", "BORUTA"} and 1 <= imputation <= 20,
        "F2_SELECTOR_SENSITIVITY_SEED_INVALID",
    )
    policy = spec["selector_sensitivity_contract"]["seed_policy"]
    return (
        policy["base"]
        + spec["fold"] * policy["outer_multiplier"]
        + policy["method_offsets"][method]
        + imputation * policy["imputation_multiplier"]
    )


def _selector_sensitivity_task_spec_record(
    *,
    fold: int,
    method: str,
    imputation: int,
    seed: int,
    task_id: str,
    seed_policy: Mapping[str, Any],
    candidate_parents: list[str],
    outer_partition_id: str,
    analysis_view_sha256: str,
    fit_ids_sha256: str,
    fit_covariate_member_set_sha256: str,
    fit_response_sha256: str,
    fit_response_size_bytes: int,
    covariate_member: Mapping[str, Any],
    predictor_catalog_sha256: str,
    transform_registry_sha256: str,
    package_versions: Mapping[str, Any],
) -> dict[str, Any]:
    _require(
        method in {"MRMRE", "BORUTA"}
        and 0 <= fold <= 6
        and 1 <= imputation <= 20
        and seed
        == seed_policy["base"]
        + fold * seed_policy["outer_multiplier"]
        + seed_policy["method_offsets"][method]
        + imputation * seed_policy["imputation_multiplier"]
        and isinstance(task_id, str)
        and bool(task_id)
        and isinstance(outer_partition_id, str)
        and bool(outer_partition_id)
        and candidate_parents
        and len(candidate_parents) == len(set(candidate_parents))
        and isinstance(covariate_member, Mapping)
        and set(covariate_member) == {"name", "sha256", "size_bytes"},
        "F2_SELECTOR_SENSITIVITY_TASK_SPEC_INVALID",
    )
    _require(
        set(package_versions) == {"mRMRe", "Boruta", "ranger"}
        and (
            method == "MRMRE"
            and package_versions["mRMRe"] in {"2.1.2.2.9002", "2.1.2.2.9003"}
            and package_versions["Boruta"] is None and package_versions["ranger"] is None
            or method == "BORUTA"
            and package_versions["mRMRe"] is None and package_versions["Boruta"] == "10.0.0"
            and package_versions["ranger"] in {"0.18.0.9002", "0.18.0.9003"}
        ),
        "F2_SELECTOR_SENSITIVITY_PACKAGE_CONTRACT_INVALID",
    )
    value = {
        "schema_version": "1.0.0",
        "kind": "PADML_F2_SELECTOR_SENSITIVITY_TASK_SPEC",
        "fold": fold,
        "method": method,
        "imputation": imputation,
        "seed": seed,
        "task_id": task_id,
        "outer_partition_id": outer_partition_id,
        "candidate_parent_set_sha256": _sha(candidate_parents),
        "candidate_parent_count": len(candidate_parents),
        "analysis_view_sha256": analysis_view_sha256,
        "fit_ids_sha256": fit_ids_sha256,
        "fit_covariate_member_set_sha256": fit_covariate_member_set_sha256,
        "fit_response_sha256": fit_response_sha256,
        "fit_response_size_bytes": fit_response_size_bytes,
        "covariate_member": dict(covariate_member),
        "predictor_catalog_sha256": predictor_catalog_sha256,
        "transform_registry_sha256": transform_registry_sha256,
        "seed_policy_sha256": _sha(dict(seed_policy)),
        "package_versions": dict(package_versions),
        "thread_capability": {
            "environment": {key: THREAD_ENV[key] for key in sorted(THREAD_ENV)},
            "library_threads": 1,
            "method_internal_threads": 1,
        },
    }
    _require(
        all(
            isinstance(value[field], str)
            and _HEX64.fullmatch(value[field]) is not None
            for field in (
                "candidate_parent_set_sha256",
                "analysis_view_sha256",
                "fit_ids_sha256",
                "fit_covariate_member_set_sha256",
                "fit_response_sha256",
                "predictor_catalog_sha256",
                "transform_registry_sha256",
                "seed_policy_sha256",
            )
        )
        and value["candidate_parent_count"] == len(candidate_parents)
        and type(value["fit_response_size_bytes"]) is int
        and value["fit_response_size_bytes"] > 0
        and isinstance(value["covariate_member"]["name"], str)
        and bool(value["covariate_member"]["name"])
        and isinstance(value["covariate_member"]["sha256"], str)
        and _HEX64.fullmatch(value["covariate_member"]["sha256"]) is not None
        and type(value["covariate_member"]["size_bytes"]) is int
        and value["covariate_member"]["size_bytes"] > 0,
        "F2_SELECTOR_SENSITIVITY_TASK_SPEC_INVALID",
    )
    return value


def _validate_selector_sensitivity_numerics(method: str, health: Any, *, package_version=None) -> dict[str, Any]:
    common = {"schema_version", "implementation", "warning_count", "warnings"}
    method_keys = {
        "MRMRE": {"association_count", "finite_association_count", "finite_mi_count", "reference_count",
                  "max_abs_reference_delta", "score_count", "finite_score_count"},
        "BORUTA": {"importance_calls", "checked_value_count", "length_checks", "name_checks",
                   "finite_checks", "nonfinite_count"},
    }
    _require(method in method_keys and isinstance(health, dict)
             and set(health) == common | method_keys[method]
             and health["schema_version"] == "1.0.0"
             and type(health["warning_count"]) is int and health["warning_count"] == 0
             and health["warnings"] == [], "F2_SELECTOR_SENSITIVITY_NUMERICAL_HEALTH_INVALID")
    counters = method_keys[method] - {"max_abs_reference_delta"}
    _require(all(type(health[field]) is int for field in counters),
             "F2_SELECTOR_SENSITIVITY_NUMERICAL_HEALTH_INVALID")
    if method == "MRMRE":
        if package_version is not None:
            _require(health["implementation"] == f"mRMRe-{package_version}/association-ties-v1",
                     "F2_MRMRE_NUMERICAL_HEALTH_VERSION_DRIFT")
        count = len(set(selector_parent_names()) - set(
            selector_sensitivity_contract()['mrmre']['excluded_parents']))
        _require(health["implementation"] in {"mRMRe-2.1.2.2.9002/association-ties-v1",
                 "mRMRe-2.1.2.2.9003/association-ties-v1"}
                 and health["association_count"] == health["finite_association_count"]
                 == health["finite_mi_count"] == (count + 1) * count
                 and health["reference_count"] == health["score_count"] == health["finite_score_count"] == count
                 and _finite_number(health["max_abs_reference_delta"])
                 and 0 <= health["max_abs_reference_delta"] <= 1e-12,
                 "F2_MRMRE_NUMERICAL_HEALTH_INVALID")
    else:
        calls = health["importance_calls"]
        _require(health["implementation"] == "Boruta-getImpRfZ-pre-substitution-v1"
                 and 1 <= calls <= 99
                 and health["length_checks"] == health["name_checks"] == health["finite_checks"] == calls
                 and 2 * len(selector_parent_names()) + 9 * (calls - 1)
                     <= health["checked_value_count"] <= 2 * len(selector_parent_names()) * calls
                 and health["nonfinite_count"] == 0, "F2_BORUTA_NUMERICAL_HEALTH_INVALID")
    return health


def _run_r_selector_sensitivity_pool_task(
    value: tuple[dict[str, Any], str, str],
) -> dict[str, Any]:
    engine_spec, scratch_value, repo_root_value = value
    scratch = Path(scratch_value)
    repo_root = Path(repo_root_value)
    task = engine_spec["sensitivity_task"]
    root = scratch / f"f2-selector-sensitivity-{_sha(task['task_id'])[:16]}"
    root.mkdir(mode=0o700)
    spec_path = root / "spec.json"
    output_path = root / "output.json"
    spec_path.write_bytes(
        canonical_json_bytes({**engine_spec, "output_path": str(output_path)})
    )
    environment = dict(os.environ)
    environment.update(THREAD_ENV)
    try:
        completed = subprocess.run(
            [
                RSCRIPT_EXECUTABLE,
                str(repo_root / "kernels/f2_model_development.R"),
                str(spec_path),
            ],
            cwd=repo_root,
            env=environment,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            check=False,
            timeout=12 * 60 * 60,
        )
        if completed.returncode != 0 or not output_path.is_file():
            # Keep attributable diagnostics in the existing unit log before scratch cleanup.
            print(f"{task['task_id']}: {completed.stderr[-4000:]}", file=sys.stderr, flush=True)
            raise ContractError(
                _r_failure_reason(
                    completed,
                    f"F2_{task['method']}_SENSITIVITY_FAILED",
                )
            )
        result = strict_json_bytes(
            output_path.read_bytes(),
            "f2-selector-sensitivity-task.json",
        )
    finally:
        shutil.rmtree(root)
    _require(
        isinstance(result, dict)
        and set(result)
        == {
            "schema_version",
            "kind",
            "status",
            "task_id",
            "method",
            "imputation",
            "seed",
            "task_spec_sha256",
            "candidate_parent_count",
            "package_versions",
            "thread_count",
            "numerical_health",
            "result",
        }
        and result["schema_version"] == "1.1.0"
        and result["kind"] == "PADML_F2_SELECTOR_SENSITIVITY_TASK"
        and result["status"] == "PASS"
        and result["task_id"] == task["task_id"]
        and result["method"] == task["method"]
        and result["imputation"] == task["imputation"]
        and result["seed"] == task["seed"]
        and result["task_spec_sha256"] == task["task_spec_sha256"]
        and result["candidate_parent_count"] == len(task["candidate_parents"])
        and result["package_versions"]
        == task["task_spec_record"]["package_versions"]
        and result["thread_count"] == 1,
        "F2_SELECTOR_SENSITIVITY_RESULT_INVALID",
    )
    _validate_selector_sensitivity_numerics(task["method"], result["numerical_health"],
        package_version=result["package_versions"]["mRMRe"])
    task_echo = {
        "task_spec_sha256": result["task_spec_sha256"],
        "method": result["method"],
        "imputation": result["imputation"],
        "seed": result["seed"],
        "candidate_parent_count": result["candidate_parent_count"],
        "package_versions": result["package_versions"],
        "thread_count": result["thread_count"],
        "numerical_health": result["numerical_health"],
    }
    result["task_spec_record"] = task["task_spec_record"]
    result["task_echo"] = task_echo
    result["task_echo_sha256"] = _sha(task_echo)
    return result


def _run_r_selector_sensitivity_shared_pool_task(
    value: tuple[dict[str, Any], str, str],
) -> dict[str, Any]:
    """Keep typed method failures attributable inside the shared 40-task pool."""

    task = value[0]["sensitivity_task"]
    try:
        return _run_r_selector_sensitivity_pool_task(value)
    except ContractError as exc:
        # Numerical/missing/unknown errors terminate the shared pool immediately.
        if str(exc).split(":", 1)[0] not in {"F2_MRMRE_ENGINE_FIT_FAILED", "F2_BORUTA_ENGINE_FIT_FAILED"}:
            raise
        return {
            "kind": "PADML_F2_SELECTOR_SENSITIVITY_SHARED_POOL_FAILURE",
            "method": task["method"],
            "imputation": task["imputation"],
            "reason": str(exc).split(":", 1)[0],
        }


def _sensitivity_method_summary(
    spec: Mapping[str, Any],
    method: str,
    rows: list[dict[str, Any]],
    candidate_parents: list[str],
    event_count: int,
) -> dict[str, Any]:
    contract = spec["selector_sensitivity_contract"]
    parent_df = _elastic_parent_design_columns(spec["predictors"])
    _require(
        len(rows) == 20
        and [row["imputation"] for row in rows] == list(range(1, 21))
        and all(row["method"] == method for row in rows)
        and event_count > 0,
        "F2_SELECTOR_SENSITIVITY_DENOMINATOR_INVALID",
    )
    selected_sets: list[list[str]] = []
    private_records: list[dict[str, Any]] = []
    if method == "MRMRE":
        for row in rows:
            ranking = row["result"].get("ranking")
            _require(
                isinstance(ranking, list)
                and len(ranking) == len(candidate_parents)
                and len(set(ranking)) == len(ranking)
                and set(ranking) == set(candidate_parents),
                "F2_MRMRE_RANK_DENOMINATOR_INVALID",
            )
            natural_ranking = [parent for parent in ranking if parent != "AST_ALT"]
            selected = ["AST_ALT"]
            design_df = parent_df["AST_ALT"]
            for parent in natural_ranking:
                proposed = design_df + parent_df[parent]
                if event_count / proposed < contract["shared_contract"]["epv_minimum"]:
                    break
                selected.append(parent)
                design_df = proposed
            selected_sets.append(selected)
            private_records.append(
                {
                    "imputation": row["imputation"],
                    "task_id": row["task_id"],
                    "seed": row["seed"],
                    "task_spec": row["task_spec_record"],
                    "task_spec_sha256": row["task_spec_sha256"],
                    "task_echo": row["task_echo"],
                    "task_echo_sha256": row["task_echo_sha256"],
                    "ranking": ranking,
                    "selected_prefix": selected,
                    "complete_design_df": design_df,
                    "epv": event_count / design_df,
                    "result_sha256": _sha(row["result"]),
                    "task_identity_sha256": _sha(
                        {
                            "task_spec_sha256": row["task_spec_sha256"],
                            "task_echo_sha256": row["task_echo_sha256"],
                            "result_sha256": _sha(row["result"]),
                        }
                    ),
                }
            )
    else:
        for row in rows:
            decisions = row["result"].get("decisions")
            _require(
                isinstance(decisions, dict)
                and set(decisions) == set(candidate_parents)
                and set(decisions.values())
                <= {"Confirmed", "Tentative", "Rejected"},
                "F2_BORUTA_DECISION_DENOMINATOR_INVALID",
            )
            confirmed = [
                parent
                for parent in candidate_parents
                if decisions[parent] == "Confirmed"
            ]
            selected = list(dict.fromkeys(["AST_ALT", *confirmed]))
            design_df = sum(parent_df[parent] for parent in selected)
            selected_sets.append(selected)
            private_records.append(
                {
                    "imputation": row["imputation"],
                    "task_id": row["task_id"],
                    "seed": row["seed"],
                    "task_spec": row["task_spec_record"],
                    "task_spec_sha256": row["task_spec_sha256"],
                    "task_echo": row["task_echo"],
                    "task_echo_sha256": row["task_echo_sha256"],
                    "decisions": decisions,
                    "algorithm_confirmed": confirmed,
                    "selected_with_forced": selected,
                    "complete_design_df": design_df,
                    "epv": event_count / design_df,
                    "epv_status": (
                        "ELIGIBLE"
                        if event_count / design_df
                        >= contract["shared_contract"]["epv_minimum"]
                        else "EPV_INELIGIBLE"
                    ),
                    "result_sha256": _sha(row["result"]),
                    "task_identity_sha256": _sha(
                        {
                            "task_spec_sha256": row["task_spec_sha256"],
                            "task_echo_sha256": row["task_echo_sha256"],
                            "result_sha256": _sha(row["result"]),
                        }
                    ),
                }
            )
    counts = {
        parent: sum(parent in selected for selected in selected_sets)
        for parent in candidate_parents
        if parent != "AST_ALT"
    }
    tentative_frequency = (
        {
            parent: sum(
                record["decisions"][parent] == "Tentative"
                for record in private_records
            )
            for parent in candidate_parents
            if parent != "AST_ALT"
        }
        if method == "BORUTA"
        else None
    )
    thresholds = {
        f"{threshold}/20": [
            parent
            for parent in candidate_parents
            if parent != "AST_ALT" and counts[parent] >= threshold
        ]
        for threshold in (12, 14, 16)
    }
    threshold_set_diagnostics = {}
    for threshold in (12, 14, 16):
        selected = ["AST_ALT", *thresholds[f"{threshold}/20"]]
        design_df = sum(parent_df[parent] for parent in selected)
        epv = event_count / design_df
        threshold_set_diagnostics[f"{threshold}/20"] = {
            "natural_parent_count": len(selected) - 1,
            "complete_design_df": design_df,
            "event_count": event_count,
            "epv": epv,
            "epv_status": (
                "ELIGIBLE"
                if epv >= contract["shared_contract"]["epv_minimum"]
                else "EPV_INELIGIBLE"
            ),
        }
    if method == "MRMRE":
        natural_rank_domain = [
            parent for parent in candidate_parents if parent != "AST_ALT"
        ]
        rank_correlations = []
        for left in range(len(private_records)):
            left_positions = {
                parent: index
                for index, parent in enumerate(
                    (
                        parent
                        for parent in private_records[left]["ranking"]
                        if parent != "AST_ALT"
                    ),
                    start=1,
                )
            }
            for right in range(left + 1, len(private_records)):
                right_positions = {
                    parent: index
                    for index, parent in enumerate(
                        (
                            parent
                            for parent in private_records[right]["ranking"]
                            if parent != "AST_ALT"
                        ),
                        start=1,
                    )
                }
                denominator = len(natural_rank_domain) * (
                    len(natural_rank_domain) ** 2 - 1
                )
                squared_difference = sum(
                    (left_positions[parent] - right_positions[parent]) ** 2
                    for parent in natural_rank_domain
                )
                rank_correlations.append(
                    1 - 6 * squared_difference / denominator
                )
        stability_summary = {
            "kind": "PAIRWISE_SPEARMAN_NATURAL_RANK_STABILITY",
            "natural_candidate_count": len(natural_rank_domain),
            "comparison_count": len(rank_correlations),
            "mean": math.fsum(rank_correlations) / len(rank_correlations),
            "minimum": min(rank_correlations),
            "maximum": max(rank_correlations),
        }
    else:
        confirmed_counts = [
            len(record["algorithm_confirmed"])
            for record in private_records
        ]
        stability_summary = {
            "kind": "CONFIRMED_COUNT_STABILITY",
            "imputation_count": len(confirmed_counts),
            "mean": math.fsum(confirmed_counts) / len(confirmed_counts),
            "minimum": min(confirmed_counts),
            "maximum": max(confirmed_counts),
        }
    value = {
        "schema_version": "1.0.0",
        "kind": "PADML_F2_SELECTOR_SENSITIVITY_METHOD",
        "status": "PASS",
        "method": method,
        "candidate_parent_count": len(candidate_parents),
        "task_count": 20,
        "event_count": event_count,
        "natural_frequency": counts,
        "tentative_frequency": tentative_frequency,
        "threshold_sets": thresholds,
        "threshold_set_diagnostics": threshold_set_diagnostics,
        "stability_summary": stability_summary,
        "private_records": private_records,
        "task_set_sha256": _sha(
            [record["task_identity_sha256"] for record in private_records]
        ),
    }
    return value


_SELECTOR_SENSITIVITY_METHOD_EXECUTION_KEYS = {
    "admission_identity",
    "execution",
    "execution_identity_sha256",
    "identity_sha256",
}


def _selector_sensitivity_method_science_identity(
    value: Mapping[str, Any],
) -> str:
    return _sha(
        {
            key: item
            for key, item in value.items()
            if key not in _SELECTOR_SENSITIVITY_METHOD_EXECUTION_KEYS
        }
    )


def _selector_sensitivity_method_execution_identity(
    value: Mapping[str, Any],
) -> str:
    return _sha(
        {
            "science_identity_sha256": value["identity_sha256"],
            "admission_identity": value["admission_identity"],
            "execution": value["execution"],
        }
    )


def _bind_selector_sensitivity_method_execution(
    value: dict[str, Any],
    *,
    admission_identity: str,
    execution: Mapping[str, Any] | None,
) -> dict[str, Any]:
    value["identity_sha256"] = (
        _selector_sensitivity_method_science_identity(value)
        if value["status"] == "PASS"
        else None
    )
    value["admission_identity"] = admission_identity
    value["execution"] = None if execution is None else dict(execution)
    value["execution_identity_sha256"] = (
        _selector_sensitivity_method_execution_identity(value)
    )
    return value


def _run_selector_sensitivity_method(
    spec: dict[str, Any],
    outer_scope: Mapping[str, Any],
    method: str,
    training_projection: Mapping[str, Any],
    scratch: Path,
    repo_root: Path,
    *,
    shared_call_args: list[tuple[dict[str, Any], str, str]] | None = None,
    prepared_rows: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    profile_record = spec["selector_sensitivity_profiles"][method]
    sensitivity_contract = spec["selector_sensitivity_contract"]
    failure_semantics = sensitivity_contract["failure_semantics"]
    if profile_record["selection"] == "GLOBAL_DEFERRED":
        return _bind_selector_sensitivity_method_execution({
            "schema_version": "1.0.0",
            "kind": "PADML_F2_SELECTOR_SENSITIVITY_METHOD",
            "status": "GLOBAL_DEFERRED",
            "method": method,
            "reason": failure_semantics["global_deferred_reason"],
            "task_count": 0,
        }, admission_identity=profile_record["admission_identity"], execution=None)
    execution = profile_record["execution"]
    _require(
        isinstance(execution, dict)
        and execution["engine_threads"] == 1
        and type(execution["threads"]) is int and execution["threads"] >= 1
        and execution["pool_workers"] == execution["threads"],
        "F2_SELECTOR_SENSITIVITY_PROFILE_INVALID",
    )
    _require(
        set(outer_scope) == {"partition_id", "fit_ids", "fit_response"}
        and isinstance(outer_scope["fit_ids"], list)
        and outer_scope["fit_ids"]
        and isinstance(outer_scope["fit_response"], Mapping)
        and "private_bytes" not in outer_scope["fit_response"],
        "F2_SELECTOR_SENSITIVITY_OUTER_INVALID",
    )
    candidate_parents = list(spec["predictors"]["parents"])
    if method == "MRMRE":
        candidate_parents = [
            parent for parent in candidate_parents if parent != "Prior_LE_Surgery_cat"
        ]
    expected_count = len(spec["predictors"]["parents"]) - (1 if method == "MRMRE" else 0)
    _require(
        len(candidate_parents) == expected_count
        and "AST_ALT" in candidate_parents
        and "eGFR_calc" not in candidate_parents,
        "F2_SELECTOR_SENSITIVITY_CANDIDATE_SET_INVALID",
    )
    record = training_projection["recipe_registry_record"]
    members = record["members"]
    _require(len(members) == 20, "F2_SELECTOR_SENSITIVITY_DENOMINATOR_INVALID")
    engine_base = {
        "schema_version": "1.0.0",
        "action": "SELECTOR_SENSITIVITY_TASK",
        **({"execution_scope": "INTEGRATED_SELECTOR_DIAGNOSTIC"} if spec.get("integrated_diagnostic") else {}),
        "fold": spec["fold"],
        "family": "ELASTIC_NET_COX",
        "heldout_center": spec["heldout_center"],
        "outcome": spec["outcome"],
        "time": spec["time"],
        "threads": 1,
        "predictors": spec["predictors"],
    }
    call_args = []
    for imputation, member in enumerate(members, start=1):
        seed = _selector_sensitivity_seed(spec, method, imputation)
        task_id = f"{method}_F{spec['fold']}_M{imputation:02d}"
        covariate_member = {
            "name": member["name"],
            "sha256": member["sha256"],
            "size_bytes": member["size_bytes"],
        }
        task_spec_record = _selector_sensitivity_task_spec_record(
            fold=spec["fold"],
            method=method,
            imputation=imputation,
            seed=seed,
            task_id=task_id,
            seed_policy=spec["selector_sensitivity_contract"]["seed_policy"],
            candidate_parents=candidate_parents,
            outer_partition_id=outer_scope["partition_id"],
            analysis_view_sha256=training_projection["analysis_view_sha256"],
            fit_ids_sha256=training_projection["fit_ids_sha256"],
            fit_covariate_member_set_sha256=_sha(members),
            fit_response_sha256=outer_scope["fit_response"]["sha256"],
            fit_response_size_bytes=outer_scope["fit_response"]["size_bytes"],
            covariate_member=covariate_member,
            predictor_catalog_sha256=spec["predictors"]["sha256"],
            transform_registry_sha256=spec["predictors"][
                "transform_registry_sha256"
            ],
            package_versions=(
                {
                    "mRMRe": sensitivity_contract["mrmre"]["version"],
                    "Boruta": None,
                    "ranger": None,
                }
                if method == "MRMRE"
                else {
                    "mRMRe": None,
                    "Boruta": sensitivity_contract["boruta"]["version"],
                    "ranger": sensitivity_contract["boruta"]["ranger_version"],
                }
            ),
        )
        task = {
            "task_id": task_id,
            "method": method,
            "imputation": imputation,
            "seed": seed,
            "task_spec_record": task_spec_record,
            "task_spec_sha256": _sha(task_spec_record),
            "candidate_parents": candidate_parents,
            "fit_ids": record["fit_ids"],
            "fit_ids_sha256": training_projection["fit_ids_sha256"],
            "covariate": {
                "name": member["name"],
                "path": str(Path(record["input_dir"]) / member["name"]),
                "sha256": member["sha256"],
                "size_bytes": member["size_bytes"],
            },
            "fit_response": outer_scope["fit_response"],
        }
        call_args.append(
            ({**engine_base, "sensitivity_task": task}, str(scratch), str(repo_root))
        )
    if shared_call_args is not None:
        _require(
            prepared_rows is None,
            "F2_SELECTOR_SENSITIVITY_SHARED_POOL_STATE_INVALID",
        )
        start = len(shared_call_args)
        shared_call_args.extend(call_args)
        return {
            "kind": "PADML_F2_SELECTOR_SENSITIVITY_SHARED_POOL_PLAN",
            "method": method,
            "start": start,
            "count": len(call_args),
            "pool_workers": execution["pool_workers"],
        }
    if prepared_rows is None:
        try:
            rows = _bounded_ordered_spawn(
                _run_r_selector_sensitivity_pool_task,
                call_args,
                selected_slots=execution["pool_workers"],
            )
        except ContractError as exc:
            reason = str(exc).split(":", 1)[0]
            if reason not in set(
                failure_semantics["typed_deferred_reason_allowlist"][method]
            ):
                raise
            return _bind_selector_sensitivity_method_execution({
                "schema_version": "1.0.0",
                "kind": "PADML_F2_SELECTOR_SENSITIVITY_METHOD",
                "status": "DEFERRED_TYPED",
                "method": method,
                "reason": reason,
                "task_count": 0,
            }, admission_identity=profile_record["admission_identity"], execution=execution)
    else:
        _require(
            len(prepared_rows) == len(call_args),
            "F2_SELECTOR_SENSITIVITY_SHARED_POOL_RESULT_INVALID",
        )
        rows = list(prepared_rows)
        failures = [
            row
            for row in rows
            if row.get("kind")
            == "PADML_F2_SELECTOR_SENSITIVITY_SHARED_POOL_FAILURE"
        ]
        if failures:
            _require(
                all(
                    row.get("method") == method
                    and type(row.get("imputation")) is int
                    and 1 <= row["imputation"] <= 20
                    for row in failures
                ),
                "F2_SELECTOR_SENSITIVITY_SHARED_POOL_RESULT_INVALID",
            )
            failures.sort(key=lambda row: row["imputation"])
            reason = failures[0]["reason"]
            _require(
                all(row["reason"] == reason for row in failures),
                "F2_SELECTOR_SENSITIVITY_SHARED_POOL_RESULT_INVALID",
            )
            if reason not in set(
                failure_semantics["typed_deferred_reason_allowlist"][method]
            ):
                raise ContractError(reason)
            return _bind_selector_sensitivity_method_execution({
                "schema_version": "1.0.0",
                "kind": "PADML_F2_SELECTOR_SENSITIVITY_METHOD",
                "status": "DEFERRED_TYPED",
                "method": method,
                "reason": reason,
                "task_count": 0,
            }, admission_identity=profile_record["admission_identity"], execution=execution)
        _require(
            all(
                row.get("method") == method
                and row.get("imputation") == index
                for index, row in enumerate(rows, start=1)
            ),
            "F2_SELECTOR_SENSITIVITY_SHARED_POOL_RESULT_INVALID",
        )
    fit_time, fit_event = _response_arrays(
        outer_scope["fit_response"], outer_scope["fit_ids"]
    )
    _require(len(fit_time) == len(fit_event), "F2_SELECTOR_SENSITIVITY_RESPONSE_INVALID")
    summary = _sensitivity_method_summary(
        spec,
        method,
        rows,
        candidate_parents,
        sum(value == 1 for value in fit_event),
    )
    return _bind_selector_sensitivity_method_execution(
        summary,
        admission_identity=profile_record["admission_identity"],
        execution=execution,
    )


def _run_selector_sensitivity(
    spec: dict[str, Any],
    registered: dict[str, Any],
    expected_model_input: Mapping[str, Any],
    outer_partition_id: str,
    scratch: Path,
    repo_root: Path,
) -> dict[str, Any]:
    input_root = scratch / "selector-sensitivity-training"
    input_root.mkdir(mode=0o700)
    projection = _recipe_partition_projection(
        registered,
        outer_partition_id,
        spec["predictors"],
        input_root,
    )
    outer_rows = [
        row
        for row in registered["partitions"]
        if row["kind"] == "OUTER" and row["partition_id"] == outer_partition_id
    ]
    _require(len(outer_rows) == 1, "F2_SELECTOR_SENSITIVITY_OUTER_INVALID")
    outer_scope = {
        "partition_id": outer_rows[0]["partition_id"],
        "fit_ids": list(outer_rows[0]["fit_ids"]),
        "fit_response": dict(outer_rows[0]["fit_response"]),
    }
    _require(
        "evaluation_response" not in outer_scope
        and "private_bytes" not in outer_scope["fit_response"],
        "F2_SELECTOR_SENSITIVITY_HELDOUT_RESPONSE_REACHABLE",
    )
    expected_outer = [
        row
        for row in expected_model_input["model_partitions"]
        if row["kind"] == "OUTER"
    ]
    _require(
        len(expected_outer) == 1
        and expected_outer[0]["partition_id"] == outer_partition_id
        and expected_outer[0]["analysis_view_sha256"]
        == projection["analysis_view_sha256"]
        and expected_outer[0]["fit_ids_sha256"]
        == projection["fit_ids_sha256"]
        and expected_outer[0]["fit_covariate_members"]
        == projection["recipe_registry_record"]["members"]
        and expected_outer[0]["fit_covariate_member_set_sha256"]
        == _sha(projection["recipe_registry_record"]["members"]),
        "F2_SELECTOR_SENSITIVITY_CAPSULE_MEMBER_BINDING_INVALID",
    )
    methods: dict[str, dict[str, Any]] = {}
    shared_call_args: list[tuple[dict[str, Any], str, str]] = []
    plans: dict[str, dict[str, Any]] = {}
    for method in ("MRMRE", "BORUTA"):
        plans[method] = _run_selector_sensitivity_method(
            spec,
            outer_scope,
            method,
            projection,
            scratch,
            repo_root,
            shared_call_args=shared_call_args,
        )
    if shared_call_args:
        active_plans = [
            plan
            for plan in plans.values()
            if plan.get("kind")
            == "PADML_F2_SELECTOR_SENSITIVITY_SHARED_POOL_PLAN"
        ]
        _require(
            len(shared_call_args) == 20 * len(active_plans)
            and len(active_plans) in {1, 2}
            and len({plan["pool_workers"] for plan in active_plans}) == 1,
            "F2_SELECTOR_SENSITIVITY_SHARED_POOL_PLAN_INVALID",
        )
        shared_rows = _bounded_ordered_spawn(
            _run_r_selector_sensitivity_shared_pool_task,
            shared_call_args,
            selected_slots=active_plans[0]["pool_workers"],
        )
        for method in ("MRMRE", "BORUTA"):
            plan = plans[method]
            if (
                plan.get("kind")
                != "PADML_F2_SELECTOR_SENSITIVITY_SHARED_POOL_PLAN"
            ):
                methods[method] = plan
                continue
            start = plan["start"]
            methods[method] = _run_selector_sensitivity_method(
                spec,
                outer_scope,
                method,
                projection,
                scratch,
                repo_root,
                prepared_rows=shared_rows[start : start + plan["count"]],
            )
    else:
        methods = plans
    value = {
        "schema_version": "1.0.0",
        "kind": "PADML_F2_SELECTOR_SENSITIVITY",
        "status": "PASS",
        "method_order": ["MRMRE", "BORUTA"],
        "methods": methods,
        "primary_writeback": "FORBIDDEN",
        "heldout_outcome_read_count": 0,
    }
    value["identity_sha256"] = _selector_sensitivity_science_identity(value)
    value["execution_identity_sha256"] = (
        _selector_sensitivity_execution_identity(value)
    )
    return value


def _selector_sensitivity_science_identity(value: Mapping[str, Any]) -> str:
    methods = value["methods"]
    return _sha(
        {
            "schema_version": value["schema_version"],
            "kind": value["kind"],
            "status": value["status"],
            "method_order": value["method_order"],
            "method_science_identities": {
                method: methods[method]["identity_sha256"]
                for method in value["method_order"]
            },
            "primary_writeback": value["primary_writeback"],
            "heldout_outcome_read_count": value["heldout_outcome_read_count"],
        }
    )


def _selector_sensitivity_execution_identity(value: Mapping[str, Any]) -> str:
    methods = value["methods"]
    return _sha(
        {
            "method_execution_identities": {
                method: methods[method]["execution_identity_sha256"]
                for method in value["method_order"]
            }
        }
    )


def _selector_evidence_science_identity(selector: Mapping[str, Any]) -> str:
    return _sha(
        {
            "schema_version": selector["schema_version"],
            "primary_selector_sha256": selector["primary_selector_sha256"],
            "sensitivity_identity_sha256": selector["sensitivity_evidence"][
                "identity_sha256"
            ],
        }
    )


def _selector_evidence_execution_identity(selector: Mapping[str, Any]) -> str:
    return _sha(
        {
            "primary_execution": selector["primary_execution"],
            "sensitivity_execution_identity_sha256": selector[
                "sensitivity_evidence"
            ]["execution_identity_sha256"],
        }
    )


def _evaluate_elastic_alpha_phase(
    spec: dict[str, Any],
    registered: dict[str, Any],
    recipe_set: Mapping[str, Any],
    alphas: list[float],
    scratch: Path,
    repo_root: Path,
    accumulator: dict[str, list[dict[str, Any]]],
    *,
    inner_partitions: list[dict[str, Any]] | None = None,
    full_partition: dict[str, Any] | None = None,
    selected_parents: list[str] | None = None,
    full_path_field: str = "outer_paths",
) -> dict[float, dict[str, Any]]:
    """Run the shared Elastic path kernel on explicit validation/full scopes.

    F2 supplies its registered 3x5 inner folds plus the virtual outer training
    scope. F5 A16 supplies the already-sealed repeat-01 five folds plus the
    complete-development scope. Both consumers therefore execute the same R
    path fitter, grouped-Cox evaluator, and coefficient-path consumer rather
    than maintaining parallel numerical implementations.
    """
    if inner_partitions is None:
        inner = sorted(
            (row for row in registered["partitions"] if row["kind"] == "INNER"),
            key=lambda row: (row["repeat"], row["inner_fold"]),
        )
    else:
        inner = sorted(
            inner_partitions,
            key=lambda row: (row["repeat"], row["inner_fold"]),
        )
    if full_partition is None:
        full = [
            row for row in registered["partitions"] if row["kind"] == "OUTER"
        ]
        _require(
            len(inner) == 15 and len(full) == 1,
            "F2_ELASTIC_REGISTERED_PARTITION_DENOMINATOR_INVALID",
        )
        full_scope = full[0]
    else:
        _require(
            len(inner) in {5, 15}
            and full_partition in registered["partitions"],
            "F2_ELASTIC_REGISTERED_PARTITION_DENOMINATOR_INVALID",
        )
        full_scope = full_partition
    _require(
        full_path_field in {"outer_paths", "full_paths"}
        and alphas == sorted(set(alphas))
        and all(_finite_number(alpha) and 0.01 <= alpha <= 1 for alpha in alphas),
        "F2_ELASTIC_REGISTERED_PARTITION_DENOMINATOR_INVALID",
    )
    records: dict[float, dict[str, Any]] = {
        alpha: {"alpha": alpha, "partition_losses": [], full_path_field: []}
        for alpha in alphas
    }
    ratios = _elastic_ratios(spec["selector_contract"])
    selected = (
        _elastic_candidate_parents(spec)
        if selected_parents is None
        else list(selected_parents)
    )
    _require(
        selected
        and selected == list(dict.fromkeys(selected))
        and ("AST_ALT" in selected if spec.get("execution_scope") != "F5_A12_SEARCH" else
             selected_parents is not None and len(inner) == 15 and full_path_field == "outer_paths"
             and not {"AST", "ALT", "AST_ALT"}.intersection(selected)
             and selected == spec["selector_from_dependency"]["selected_parents"])
        and set(selected) <= set(_elastic_candidate_parents(spec)),
        "F2_SELECTOR_DEPENDENCY_INVALID",
    )
    inner_tasks = [
        {
            "task_id": (
                f"ELASTIC_INNER_PATH_{partition['partition_id']}_"
                f"M{imputation:02d}_{_sha(alphas)[:12]}"
            ),
            "partition_id": partition["partition_id"],
            "imputation": imputation,
            "family": "ELASTIC_NET_COX",
            "selected_parents": selected,
            "parameters": {},
            "producer_kind": "ELASTIC_INNER_PATH",
            "alphas": alphas,
            "ratios": ratios,
            "transform_recipe": _recipe_by_partition(
                recipe_set, partition["partition_id"]
            ),
            "seed": spec["seed"] + imputation,
        }
        for partition in inner
        for imputation in range(1, 21)
    ]
    inner_rows = _run_r_prediction_batch(
        spec,
        registered,
        inner_tasks,
        scratch,
        repo_root,
        evaluation_mode="GROUPED_COX_LOSS",
    )
    inner_values: dict[str, dict[float, list[list[float]]]] = {
        partition["partition_id"]: {alpha: [] for alpha in alphas}
        for partition in inner
    }
    inner_health: dict[str, dict[float, list[dict[str, Any]]]] = {
        partition["partition_id"]: {alpha: [] for alpha in alphas}
        for partition in inner
    }
    inner_by_id = {partition["partition_id"]: partition for partition in inner}
    for task, row in zip(inner_tasks, inner_rows, strict=True):
        partition = inner_by_id[task["partition_id"]]
        paths = row["sealed_elastic_paths"]
        _require(
            [path["alpha"] for path in paths] == alphas,
            "F2_ELASTIC_RATIO_PATH_INVALID",
        )
        for path in paths:
            alpha = path["alpha"]
            inner_values[partition["partition_id"]][alpha].append(
                path["losses"]
            )
            inner_health[partition["partition_id"]][alpha].append(
                {
                    "imputation": task["imputation"],
                    "lambda_max": path["lambda_max"],
                    "lambda_path_sha256": path["lambda_path_sha256"],
                    "lambda_upper_bound": path["lambda_upper_bound"],
                    "penalized_design_column_count": path[
                        "penalized_design_column_count"
                    ],
                    "penalized_active_count_path": path[
                        "penalized_active_count_path"
                    ],
                    "penalized_entry_covered": path[
                        "penalized_entry_covered"
                    ],
                }
            )
            accumulator.setdefault(partition["partition_id"], []).append(
                {
                    "prediction_seal_sha256": path["risk_curve_sha256"],
                    "metric_value": min(path["losses"]),
                }
            )
    for partition in inner:
        for alpha in alphas:
            values = inner_values[partition["partition_id"]][alpha]
            health = inner_health[partition["partition_id"]][alpha]
            _require(
                len(values) == 20
                and [row["imputation"] for row in health]
                == list(range(1, 21)),
                "F2_SELECTOR_PARTITION_LOSS_INVALID",
            )
            records[alpha]["partition_losses"].append(
                {
                    "repeat": partition["repeat"],
                    "inner_fold": partition["inner_fold"],
                    "validation_n": len(_development_evaluation_indices(partition, spec.get("selection_horizon_months", 24)) or partition["evaluation_ids"]),
                    "mi_losses": values,
                    "mi_lambda_path_health": health,
                }
            )

    outer_tasks = [
        {
            "task_id": (
                f"ELASTIC_OUTER_PATH_{full_scope['partition_id']}_"
                f"M{imputation:02d}_{_sha(alphas)[:12]}"
            ),
            "partition_id": full_scope["partition_id"],
            "imputation": imputation,
            "family": "ELASTIC_NET_COX",
            "selected_parents": selected,
            "parameters": {},
            "producer_kind": "ELASTIC_OUTER_PATH",
            "alphas": alphas,
            "ratios": ratios,
            "transform_recipe": _recipe_by_partition(
                recipe_set, full_scope["partition_id"]
            ),
            "seed": spec["seed"] + imputation,
        }
        for imputation in range(1, 21)
    ]
    outer_rows = _run_r_prediction_batch(
        spec, registered, outer_tasks, scratch, repo_root
    )
    for task, row in zip(outer_tasks, outer_rows, strict=True):
        paths = row["sealed_elastic_paths"]
        _require(
            [path["alpha"] for path in paths] == alphas,
            "F2_ELASTIC_RATIO_PATH_INVALID",
        )
        for path in paths:
            records[path["alpha"]][full_path_field].append(
                {
                    "imputation": task["imputation"],
                    "lambda_max": path["lambda_max"],
                    "lambda_path_sha256": path["lambda_path_sha256"],
                    "lambda_upper_bound": path["lambda_upper_bound"],
                    "penalized_design_column_count": path[
                        "penalized_design_column_count"
                    ],
                    "penalized_active_count_path": path[
                        "penalized_active_count_path"
                    ],
                    "penalized_entry_covered": path[
                        "penalized_entry_covered"
                    ],
                    "event_count": path["event_count"],
                    "parent_design_columns": path["parent_design_columns"],
                    "parent_coefficients": path["parent_coefficients"],
                    "coefficient_path_sha256": path[
                        "coefficient_path_sha256"
                    ],
                }
            )
    return records


def _checkpoint_elastic_alpha_phase(
    root: Path,
    spec: Mapping[str, Any],
    phase: str,
    records: Mapping[float, Mapping[str, Any]],
    recipe_set: Mapping[str, Any],
) -> None:
    """Preserve completed scientific paths before any selector decision can fail."""
    _require(phase in {"coarse", "fine"}, "F2_SELECTOR_CHECKPOINT_PHASE_INVALID")
    write_deterministic_zip(
        root / f"{spec['unit_id']}.{phase}-search.zip",
        {"selector-search.json": canonical_json_bytes({
            "schema_version": "1.0.0",
            "kind": "PADML_F2_SELECTOR_SEARCH_EVIDENCE",
            "unit_id": spec["unit_id"],
            "transaction_id": spec["transaction_id"],
            "identities": spec["identities"],
            "selector_contract_sha256": _sha(spec["selector_contract"]),
            "recipe_set_sha256": recipe_set["recipe_set_sha256"],
            "phase": phase,
            "derivation_records": [records[alpha] for alpha in sorted(records)],
            "scientific_acceptance": False,
        })},
    )


def _run_r_registered_elastic(
    spec: dict[str, Any],
    registered: dict[str, Any],
    expected_model_input: Mapping[str, Any],
    scratch: Path,
    repo_root: Path,
    checkpoint_root: Path,
    *,
    search_reuse: tuple[Mapping[str, Any], Mapping[str, Any]] | None = None,
) -> dict[str, Any]:
    _require(spec["family"] == "ELASTIC_NET_COX", "F2_ELASTIC_ROUTE_INVALID")
    contract = spec["selector_contract"]
    inner = sorted(
        (row for row in registered["partitions"] if row["kind"] == "INNER"),
        key=lambda row: (row["repeat"], row["inner_fold"]),
    )
    outer_rows = [
        row for row in registered["partitions"] if row["kind"] == "OUTER"
    ]
    _require(
        len(inner) == 15 and len(outer_rows) == 1,
        "F2_RECIPE_COMPILE_DENOMINATOR_INVALID",
    )
    recipe_set = _compile_transform_recipes(
        spec,
        registered,
        [*[row["partition_id"] for row in inner], outer_rows[0]["partition_id"]],
        scratch,
        repo_root,
    )
    _require(
        recipe_set == expected_model_input["selector_recipe_expectations"],
        "F2_RECIPE_LOCAL_RECOMPUTATION_MISMATCH",
    )
    outer_recipe = _recipe_by_partition(
        recipe_set, outer_rows[0]["partition_id"]
    )
    coarse = [float(value) for value in contract["alpha_grid"]["coarse"]]
    accumulator: dict[str, list[dict[str, Any]]] = {}
    if search_reuse is None:
        cache = _evaluate_elastic_alpha_phase(
            spec, registered, recipe_set, coarse, scratch, repo_root, accumulator
        )
        _checkpoint_elastic_alpha_phase(checkpoint_root, spec, "coarse", cache, recipe_set)
    else:
        source, evidence = search_reuse
        records = evidence.get("derivation_records")
        _require(isinstance(records, list) and records
                 and all(isinstance(row, dict) and _finite_number(row.get("alpha")) for row in records),
                 "F2_REUSED_SEARCH_RECORDS_INVALID")
        alphas = [float(row["alpha"]) for row in records]
        _require(alphas == sorted(set(alphas)) and set(coarse) <= set(alphas)
                 and _sha(records) == source["derivation_records_sha256"],
                 "F2_REUSED_SEARCH_RECORDS_INVALID")
        cache = dict(zip(alphas, records, strict=True))
    coarse_choice, _ = _choose_elastic_alpha(
        [cache[alpha] for alpha in coarse], coarse, contract
    )
    fine_contract = contract["alpha_grid"]["fine"]
    lower, upper = [float(value) for value in fine_contract["clip"]]
    fine = sorted(
        {
            min(
                upper,
                max(
                    lower,
                    round(coarse_choice["alpha"] + float(offset), 3),
                ),
            )
            for offset in fine_contract["offsets"]
        }
    )
    missing = [alpha for alpha in fine if alpha not in cache]
    if search_reuse is not None:
        _require(not missing and set(cache) == set(coarse) | set(fine),
                 "F2_REUSED_SEARCH_GRID_INCOMPLETE")
    elif missing:
        cache.update(
            _evaluate_elastic_alpha_phase(
                spec,
                registered,
                recipe_set,
                missing,
                scratch,
                repo_root,
                accumulator,
            )
        )
    if search_reuse is None:
        _checkpoint_elastic_alpha_phase(checkpoint_root, spec, "fine", cache, recipe_set)
    chosen, _ = _choose_elastic_alpha(
        [cache[alpha] for alpha in fine], fine, contract
    )
    distinct_alphas = sorted(cache)
    search_units = len(distinct_alphas) * 15 * 20
    trace = {
        "coarse_alpha_order": coarse,
        "fine_alpha_order": fine,
        "derivation_records": [cache[alpha] for alpha in distinct_alphas],
        "alpha_feasibility": [
            {key: summary[key] for key in ("alpha", "status", "reason_code")}
            for summary in (_summarize_elastic_alpha(cache[alpha], contract) for alpha in distinct_alphas)
        ],
        "distinct_alpha_count": len(distinct_alphas),
        "outer_coefficient_path_count": len(distinct_alphas) * 20,
        "diagnostics_selection_effect": "NONE",
    }
    if search_reuse is not None:
        from .f2_validation import _validate_elastic_search_trace

        expected_outer = [row for row in expected_model_input["model_partitions"] if row["kind"] == "OUTER"]
        _require(len(expected_outer) == 1, "F2_REUSED_SEARCH_OUTER_INVALID")
        _validate_elastic_search_trace(
            trace,
            {**chosen, "common_alpha": chosen["alpha"], "recipe_set": recipe_set,
             "final_refit_lambda_by_imputation": chosen["lambda_by_imputation"]},
            contract, search_units,
            {(row["repeat"], row["inner_fold"]): row["evaluation_count"]
             for row in expected_model_input["model_partitions"] if row["kind"] == "INNER"},
            expected_outer[0]["fit_event_count"], _elastic_parent_design_columns(spec["predictors"]),
            predictors=spec["predictors"],
            expected_selector_search=search_reuse[0],
        )
        trace["search_reuse"] = dict(search_reuse[0])
    selected = list(chosen["selected_parents"])
    outer = next(row for row in registered["partitions"] if row["kind"] == "OUTER")
    final_tasks = [
        {
            "task_id": f"FINAL_OUTER_M{imputation:02d}",
            "partition_id": outer["partition_id"],
            "imputation": imputation,
            "family": "ELASTIC_NET_COX",
            "selected_parents": selected,
            "parameters": {
                "alpha": chosen["alpha"],
                "ratio": chosen["selected_ratio_by_imputation"][imputation - 1],
                "lambda": chosen["lambda_by_imputation"][imputation - 1],
                "lambda_upper_bound": chosen["lambda_upper_bound_by_imputation"][imputation - 1],
                "imputation_index": imputation,
            },
            "transform_recipe": outer_recipe,
            "prediction_horizons": spec["monthly_fit_horizons"],
            "seed": spec["seed"] + imputation,
        }
        for imputation in range(1, 21)
    ]
    final = _run_r_prediction_batch(
        spec, registered, final_tasks, scratch, repo_root
    )
    final_refit_lambda_by_imputation = [
        row["stopping"]["lambda"] for row in final
    ]
    final_refit_lambda_upper_bound_by_imputation = [
        row["stopping"]["lambda_upper_bound"] for row in final
    ]
    _require(
        final_refit_lambda_by_imputation == chosen["lambda_by_imputation"]
        and final_refit_lambda_upper_bound_by_imputation == chosen["lambda_upper_bound_by_imputation"],
        "F2_ELASTIC_SELECTED_PARAMETER_DRIFT",
    )
    _require(
        set(chosen["natural_frequency"]) == set(selector_parent_names()) - {"AST_ALT"}
        and "AST_ALT" not in chosen["natural_frequency"],
        "F2_SELECTOR_ELIGIBLE_DENOMINATOR_INVALID",
    )
    selected_design = _selected_design_record(
        selected,
        spec["predictors"],
        outer_recipe,
    )
    selector = {
        "schema_version": spec["predictors"]["selector_payload_schema_version"],
        "selector_contract_sha256": _sha(contract),
        "transform_registry_sha256": spec["predictors"][
            "transform_registry_sha256"
        ],
        "recipe_count": recipe_set["recipe_count"],
        "recipe_set_sha256": recipe_set["recipe_set_sha256"],
        "outer_recipe_sha256": outer_recipe["recipe_sha256"],
        "recipe_set": recipe_set,
        "selected_parent_design": selected_design[
            "ordered_selected_parent_map"
        ],
        "selected_design_sha256": _sha(selected_design),
        "common_alpha": chosen["alpha"],
        "selected_ratio_by_imputation": chosen["selected_ratio_by_imputation"],
        "r_min_by_imputation": chosen["r_min_by_imputation"],
        "r_0_5se_by_imputation": chosen["r_0_5se_by_imputation"],
        "final_refit_lambda_by_imputation": final_refit_lambda_by_imputation,
        "lambda_upper_bound_by_imputation": (
            final_refit_lambda_upper_bound_by_imputation
        ),
        "eligible_parent_count": len(selector_parent_names()),
        "forced_parent": "AST_ALT",
        "primary_frequency_threshold": 12,
        "sensitivity_frequency_thresholds": [14, 16],
        "selected_parents": selected,
        "selected_parent_count": len(selected),
        "selected_parent_sha256": _sha(selected),
        "natural_frequency": chosen["natural_frequency"],
        "outer_training_event_count": chosen[
            "outer_training_event_count"
        ],
        "active_design_df_by_imputation": chosen["active_design_df_by_imputation"],
        "median_active_design_df": chosen["median_active_design_df"],
        "p90_active_design_df": chosen["p90_active_design_df"],
        "median_active_epv": chosen["median_active_epv"],
        "conservative_active_epv": chosen["conservative_active_epv"],
        "common_set_design_df": chosen["common_set_design_df"],
        "common_set_epv": chosen["common_set_epv"],
        "jaccard_diagnostic": chosen["jaccard_diagnostic"],
        "jaccard_empty_set_vacuous": chosen["jaccard_empty_set_vacuous"],
        "direction_diagnostic_flags": chosen[
            "direction_diagnostic_flags"
        ],
        "diagnostics_selection_effect": "NONE",
        "primary_execution": spec["primary_execution"],
        "heldout_outcome_read_count": 0,
    }
    selector["primary_selector_sha256"] = _sha(
        {
            key: value
            for key, value in selector.items()
            if key != "primary_execution"
        }
    )
    selector["sensitivity_evidence"] = _run_selector_sensitivity(
        spec,
        registered,
        expected_model_input,
        outer["partition_id"],
        scratch,
        repo_root,
    )
    selector["selector_execution_identity_sha256"] = (
        _selector_evidence_execution_identity(selector)
    )
    return _build_registered_model_result(
        spec,
        registered,
        final,
        selector=selector,
        search_trace=trace,
        search_evaluation_unit_count=search_units,
        selected_spec={
            "family": "ELASTIC_NET_COX",
            "alpha": chosen["alpha"],
            "ratio_by_imputation": chosen["selected_ratio_by_imputation"],
            "lambda_by_imputation": final_refit_lambda_by_imputation,
            "lambda_upper_bound_by_imputation": (
                final_refit_lambda_upper_bound_by_imputation
            ),
            "selected_parents": selected,
            "selection_rule": "LOSS_THEN_P90_ACTIVE_DF_THEN_SMALLER_ALPHA",
        },
        execution_rows=(
            _reused_elastic_execution_rows(expected_model_input, trace, search_reuse[0])
            if search_reuse is not None
            else _registered_selection_execution_rows(registered, accumulator)
        ),
    )


def _reused_elastic_execution_rows(
    model_input: Mapping[str, Any], trace: Mapping[str, Any], source: Mapping[str, Any],
) -> list[dict[str, Any]]:
    rows = []
    for partition in model_input["model_partitions"]:
        if partition["kind"] != "INNER":
            continue
        paths = [
            {"alpha": record["alpha"], "partition_losses": item}
            for record in trace["derivation_records"]
            for item in record["partition_losses"]
            if (item["repeat"], item["inner_fold"]) == (partition["repeat"], partition["inner_fold"])
        ]
        _require(len(paths) == trace["distinct_alpha_count"], "F2_REUSED_SEARCH_PARTITION_INCOMPLETE")
        rows.append({
            "kind": "INNER", "partition_id": partition["partition_id"],
            "repeat": partition["repeat"], "inner_fold": partition["inner_fold"],
            "purpose": "MODEL_SELECTION", "input_record_sha256": _sha(partition),
            "evaluation_response_sha256": partition["evaluation_response_sha256"],
            "evaluation_ids_sha256": partition["evaluation_ids_sha256"],
            "evidence_kind": "REUSED_SEARCH_PATHS", "source_identity": source["identity"],
            "reused_path_count": len(paths) * 20, "current_fit_count": 0,
            "source_partition_sha256": _sha(paths),
        })
    _require(len(rows) == 15, "F2_REUSED_SEARCH_PARTITION_INCOMPLETE")
    return rows


def _accumulate_registered_evaluations(
    accumulator: dict[str, list[dict[str, Any]]],
    evaluated: list[dict[str, Any]],
) -> None:
    for row in evaluated:
        accumulator.setdefault(row["partition_id"], []).append(row)


def _registered_selection_execution_rows(
    registered: dict[str, Any],
    accumulator: dict[str, list[dict[str, Any]]],
) -> list[dict[str, Any]]:
    ordered_partitions = [
        *registered["partitions"],
        *registered.get("diagnostic_partitions", []),
    ]
    by_partition = {row["partition_id"]: row for row in ordered_partitions}
    _require(set(accumulator) <= set(by_partition), "F2_REGISTERED_EXECUTION_PARTITION_SET_INVALID")
    rows: list[dict[str, Any]] = []
    for partition in ordered_partitions:
        partition_id = partition["partition_id"]
        if partition_id not in accumulator:
            continue
        values = accumulator[partition_id]
        rows.append(
            {
                "kind": partition["kind"],
                "partition_id": partition_id,
                "repeat": partition.get("repeat", 0),
                "inner_fold": partition.get("inner_fold", 0),
                "purpose": (
                    "CENTER_STRESS"
                    if partition["kind"] == "CENTER_STRESS"
                    else "MODEL_SELECTION"
                ),
                "input_record_sha256": _sha(
                    _registered_partition_identity_record(partition)
                ),
                "prediction_seal_count": len(values),
                "evaluation_count": len(values),
                "evaluation_response_sha256": partition["evaluation_response"]["sha256"],
                "evaluation_ids_sha256": partition["evaluation_ids_sha256"],
                "prediction_seal_set_sha256": _sha(
                    [row["prediction_seal_sha256"] for row in values]
                ),
                "metric_set_sha256": _sha(
                    [
                        next(row[key] for key in row if key.startswith("ibs_0_"))
                        if any(key.startswith("ibs_0_") for key in row)
                        else row["metric_value"]
                        for row in values
                    ]
                ),
            }
        )
    return rows


def _full_pipeline_search_seed_registry(
    spec: Mapping[str, Any], search_only: bool, replicate: int | None,
) -> dict[str, Any] | None:
    """Predeclare stage/candidate CRN coordinates; never use promotion rank."""
    scope = spec.get("execution_scope") == "F4_FULL_PIPELINE_SEARCH"
    if replicate is None:
        _require(not scope, "F4_FULL_PIPELINE_SEARCH_REPLICATE_REQUIRED")
        return None
    _require(scope and search_only is True and type(replicate) is int
             and replicate in range(1, 201), "F4_FULL_PIPELINE_SEARCH_SCOPE_INVALID")
    family, candidates = spec["family"], spec["candidate_trials"]
    _require(family in {"RSF", "GBM_COX", "XGBOOST_COX", "COXTIME_SET_A"},
             "F4_FULL_PIPELINE_SEARCH_FAMILY_INVALID")
    registry = []
    for stage in F2_STAGES:
        rows = candidates["S1" if stage == "S1" or family == "COXTIME_SET_A" else "S2"]
        _require(isinstance(rows, list) and rows, "F4_FULL_PIPELINE_SEARCH_REGISTRY_INVALID")
        for candidate in rows:
            candidate_id = candidate.get("trial_id", candidate.get("candidate_id"))
            parameters = candidate if family == "COXTIME_SET_A" else candidate["parameters"]
            _require(isinstance(candidate_id, str) and candidate_id and isinstance(parameters, Mapping),
                     "F4_FULL_PIPELINE_SEARCH_REGISTRY_INVALID")
            registry.append({"stage": stage, "candidate_id": candidate_id,
                             "parameters": dict(parameters), "order": len(registry) + 1,
                             "seed": 760_000_000 + replicate * 10_000 + len(registry) + 1})
    _require(len(registry) == {"RSF": 56, "GBM_COX": 68, "XGBOOST_COX": 96, "COXTIME_SET_A": 60}[family]
             and len({(row["stage"], row["candidate_id"]) for row in registry}) == len(registry),
             "F4_FULL_PIPELINE_SEARCH_REGISTRY_INVALID")
    return {"replicate": replicate, "trials": registry,
            "stop_seeds": [750_000_000 + replicate * 100 + imp for imp in range(1, 21)]}


def _full_pipeline_trial_seed(registry: Mapping[str, Any], stage: str, trial: Mapping[str, Any]) -> int:
    candidate_id = trial.get("trial_id", trial.get("candidate_id"))
    matched = [row for row in registry["trials"] if row["stage"] == stage and row["candidate_id"] == candidate_id]
    parameters = trial if "candidate_config_sha256" in trial else trial["parameters"]
    _require(len(matched) == 1 and matched[0]["parameters"] == parameters,
             "F4_FULL_PIPELINE_SEARCH_CANDIDATE_DRIFT")
    return matched[0]["seed"]


def _search_task_batch(spec: Mapping[str, Any], function: Any, tasks: list[Any], *, selected_slots: int,
                       full_pipeline_workers: int = 1) -> list[Any]:
    """Keep the frozen Q spec; host-owned bootstrap capacity is not a model field."""
    if "current_q" in spec:
        from .f5 import _current_q_task_batch
        _require(full_pipeline_workers == 1, "F45_Q_NESTED_POOL_FORBIDDEN")
        slots = min(selected_slots, spec["current_q"]["workers"])
        if function is _run_python_locked_evaluation_pool_task:
            from .runtime import admit_stage
            policy = spec["current_q"]["resource_policy"]
            matrix_bytes = max(len(task["evaluation_partition"]["evaluation_ids"]) * 37 * 8 for task in tasks)
            admission = admit_stage(policy, Path(spec["current_q"]["root"]), legal_tasks=len(tasks),
                retained_bytes=0, publication_bytes=0,
                transient_bytes_per_worker=max(policy["scratch_bytes_per_worker"], 4*matrix_bytes),
                memory_bytes_per_worker=max(MIN_WORKER_MEMORY_BYTES, 32*matrix_bytes))
            return _bounded_ordered_spawn(function, tasks, selected_slots=min(slots, admission["admitted_worker_ceiling"]))
        _require(function in {_run_r_prediction_pool_task, _run_python_stop_pair_pool_task,
            _run_xgb_refit_pool_task, _run_coxtime_refit_pool_task}, "F45_Q_FUNCTION_INVALID")
        return _current_q_task_batch(spec, function, tasks, selected_slots=slots)
    _require(type(full_pipeline_workers) is int and full_pipeline_workers >= 1,
             "F4_FULL_PIPELINE_SEARCH_EXECUTION_INVALID")
    if spec.get("execution_scope") == "F4_FULL_PIPELINE_SEARCH":
        _require(spec.get("execution_mode") == "INLINE" and spec.get("engine_threads") == 1
                 and spec.get("threads") == spec.get("pool_workers") == selected_slots == 1,
                 "F4_FULL_PIPELINE_SEARCH_EXECUTION_INVALID")
        _require(full_pipeline_workers == 1 or spec.get("family") == "XGBOOST_COX",
                 "F4_FULL_PIPELINE_SEARCH_EXECUTION_INVALID")
        return (_bounded_ordered_spawn(function, tasks, selected_slots=full_pipeline_workers)
                if full_pipeline_workers != 1 else [function(task) for task in tasks])
    _require(full_pipeline_workers == 1, "F4_FULL_PIPELINE_SEARCH_EXECUTION_INVALID")
    if "native_search_batch" in spec:
        from .f5 import _q_search_task_batch
        return _q_search_task_batch(spec, function, tasks)
    if (spec.get("execution_scope") in {"F5_A12_SEARCH", "F5_FULL_DEVELOPMENT_SEARCH"}
            and spec["family"] in {"RSF", "GBM_COX", "XGBOOST_COX", "COXTIME_SET_A"}
            and spec.get("native_search_replay") is True):
        # Keep producer threads in the spec for identical R batch geometry;
        # only the no-fit consumer's actual concurrency follows this machine.
        from .runtime import resolve_pool_workers
        selected_slots = resolve_pool_workers(spec.get("replay_pool_workers"))
    if "active_worker_limit" in spec:
        # Physical admission limits this invocation, never historical F2 or
        # the configured CPU ceiling. AAR's XGB handoff uses the same rule.
        _require((spec.get("execution_scope") == "F5_FULL_DEVELOPMENT_SEARCH"
                  and spec.get("final_search_source", {}).get("program_id") == "PADML_F45_REBUILD_20260925"
                  or spec.get("execution_scope") == "F5_A12_SEARCH" and spec.get("family") == "XGBOOST_COX"
                  and "xgb_preparation_policy" in spec
                  and spec.get("a12_source", {}).get("source", {}).get("kind")
                  == "PADML_F5_A12_PROJECTED_OUTER_INPUTS_V1")
                 and type(spec["active_worker_limit"]) is int
                 and 1 <= spec["active_worker_limit"] <= selected_slots,
                 "NESTED_SEARCH_RESOURCE_ADMISSION_INVALID")
        selected_slots = spec["active_worker_limit"]
    return _bounded_ordered_spawn(function, tasks, selected_slots=selected_slots)


def _run_python_stop_pair_pool_task(pair: tuple[dict, dict]) -> dict[str, Any]:
    """Keep one original STOP function and its evaluator in one dispatch unit."""
    task, partition = pair
    family = task["spec"]["family"]
    _require(family in {"XGBOOST_COX", "COXTIME_SET_A"}
             and not _contains_key(task, "evaluation_response")
             and partition.get("partition_id") == task["partition_id"], "F2_STOP_PAIR_TASK_INVALID")
    function = _run_xgb_function_pool_task if family == "XGBOOST_COX" else _run_coxtime_function_pool_task
    evaluator = (_run_xgb_function_evaluator_pool_task if family == "XGBOOST_COX"
                 else _run_coxtime_function_evaluator_pool_task)
    produced = function(task)
    # The evaluator context is deliberately outside the response-free task.
    # Both leaves receive the identical spec, including the STOP-only loan.
    return evaluator({**task, "evaluation_partition": partition, "function_result": produced})


def _search_python_stop_batch(
    spec: Mapping[str, Any], tasks: list[dict], partitions: list[dict], *, selected_slots: int,
    full_pipeline_workers: int = 1,
) -> list[Any]:
    """Preserve the complete STOP barrier and all original leaf consumers."""
    _require(len(tasks) == len(partitions) and spec["family"] in {"XGBOOST_COX", "COXTIME_SET_A"},
             "F2_STOP_PAIR_TASK_INVALID")
    primary = None
    if "primary_search_source" in spec:
        from .f4 import _primary_complex_search_source
        primary = _primary_complex_search_source(spec)
    paired = (primary is not None or spec.get("execution_scope") == "F5_FULL_DEVELOPMENT_SEARCH"
              and spec.get("final_search_source", {}).get("program_id") == "PADML_F45_REBUILD_20260925"
              or spec.get("execution_scope") == "F5_A12_SEARCH"
              and isinstance(spec.get("a12_source", {}).get("source"), Mapping)
              and spec.get("a12_source", {}).get("source", {}).get("kind")
              == "PADML_F5_A12_PROJECTED_OUTER_INPUTS_V1")
    if paired:
        return _search_task_batch(spec, _run_python_stop_pair_pool_task, list(zip(tasks, partitions, strict=True)),
            selected_slots=selected_slots, full_pipeline_workers=full_pipeline_workers)
    function = _run_xgb_function_pool_task if spec["family"] == "XGBOOST_COX" else _run_coxtime_function_pool_task
    evaluator = (_run_xgb_function_evaluator_pool_task if spec["family"] == "XGBOOST_COX"
                 else _run_coxtime_function_evaluator_pool_task)
    produced = _search_task_batch(spec, function, tasks, selected_slots=selected_slots,
                                  full_pipeline_workers=full_pipeline_workers)
    evaluations = [{**task, "evaluation_partition": partition, "function_result": result}
                   for task, partition, result in zip(tasks, partitions, produced, strict=True)]
    return _search_task_batch(spec, evaluator, evaluations, selected_slots=selected_slots,
                              full_pipeline_workers=full_pipeline_workers)


def _shared_full_development_search_result(
    spec: Mapping[str, Any],
    registered: Mapping[str, Any],
    trace: Mapping[str, list[dict[str, Any]]],
    selected_spec: Mapping[str, Any],
    full_pipeline_seeds: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Seal the common F2 numerical funnel before any outer-only diagnostics."""
    family = str(spec["family"])
    horizon = _selection_horizon_from_spec(spec)
    if "source_registered_identity" in registered:
        source_identity = registered["source_registered_identity"]
        _require("identity" not in registered and isinstance(source_identity, str)
                 and _HEX64.fullmatch(source_identity) is not None
                 and source_identity == spec.get("registered_inputs_identity_sha256")
                 and spec.get("primary_search_source", {}).get("channel") == "PRIMARY"
                 and spec["primary_search_source"].get("selection_horizon_months") in {6, 12, 24, 36},
                 "F2_SHARED_SEARCH_SOURCE_IDENTITY_INVALID")
    else:
        source_identity = registered["identity"]
    _require(
        family in {"RSF", "GBM_COX", "XGBOOST_COX", "COXTIME_SET_A"}
        and list(trace) == ["S1", "S2", "S3A", "S3B1", "S3B2"]
        and all(isinstance(rows, list) and rows for rows in trace.values())
        and all(row.get("selection_horizon_months", 24) == horizon
                for rows in trace.values() for row in rows)
        and selected_spec.get("family") == family
        and selected_spec.get("selection_stage") == "S3B2"
        and selected_spec.get("selection_metric") == f"IBS_0_{horizon}",
        "F2_SHARED_SEARCH_RESULT_INVALID",
    )
    evaluation_units = sum(
        int(row["evaluation_units"])
        for rows in trace.values()
        for row in rows
    )
    expected_units = {
        "RSF": 1070,
        "GBM_COX": 1140,
        "XGBOOST_COX": 1300,
        "COXTIME_SET_A": 810,
    }[family]
    stopping_units = 0 if family == "RSF" else evaluation_units
    _require(
        evaluation_units == expected_units,
        "F2_SHARED_SEARCH_BUDGET_INVALID",
    )
    body = {
        "schema_version": "1.0.0",
        "kind": "PADML_SHARED_FULL_DEVELOPMENT_SEARCH_RESULT",
        "status": "PASS",
        "execution_scope": "F5_FULL_DEVELOPMENT_SEARCH",
        "family": family,
        "registered_inputs_identity_sha256": source_identity,
        "candidate_trials_sha256": _sha(spec["candidate_trials"]),
        "selected_parents": list(
            spec["selector_from_dependency"]["selected_parents"]
        ),
        "selected_spec": dict(selected_spec),
        "selected_spec_sha256": _sha(selected_spec),
        "search_trace": dict(trace),
        "search_trace_sha256": _sha(trace),
        "search_evaluation_unit_count": evaluation_units,
        "response_free_stopping_fit_count": stopping_units,
        "locked_training_refit_count": evaluation_units,
        "total_search_fit_count": evaluation_units + stopping_units,
        "seed_base": spec["seed"],
        "stage_seed_offsets": {
            "S1": 10_000,
            "S2": 20_000,
            "S3A": 30_000,
            "S3B1": 40_000,
            "S3B2": 50_000,
        },
        "heldout_or_ooc_read_count": 0,
        "outer_parameter_reuse": False,
        "final_model_fit_count": 0,
    }
    if full_pipeline_seeds is not None:
        body["execution_scope"] = "F4_FULL_PIPELINE_SEARCH"
        del body["stage_seed_offsets"]
        body["seed_registry"] = dict(full_pipeline_seeds)
    elif "primary_search_source" in spec:
        from .f4 import _primary_complex_search_source
        source = _primary_complex_search_source(spec)
        body["execution_scope"] = "F2_OUTER_DEVELOPMENT"
        body["selection_horizon_months"] = horizon
        body["primary_search_source"] = dict(source)
    elif spec.get("execution_scope") == "F5_A12_SEARCH":
        from .f5_sensitivity import _validate_a12_search_source
        source = spec["a12_source"]
        proof = spec.get("retained_a12_primary_context_source_bundle")
        _require((proof is None) == ("a12_executor_source_identity" not in spec),
                 "F5_RETAINED_AAR_SOURCE_SCOPE_INVALID")
        _validate_a12_search_source(source, family=family, outer=spec["fold"],
            **({"retained_primary_source_bundle": Path(proof), "retained_primary_context": True}
               if proof is not None else {}))
        projected = source.get("source")
        if isinstance(projected, Mapping) and projected.get("kind") == "PADML_F5_A12_PROJECTED_OUTER_INPUTS_V1":
            _require(horizon == projected["primary_source"]["primary_development_lock"].get("selection_horizon_months", 24),
                     "F5_A12_Q_SELECTION_HORIZON_MISMATCH")
        if proof is not None:
            from .f4 import _f45_source_member_sha256, _retained_full0_source_members
            q_executor = spec.get("retained_a12_q_executor_source_bundle")
            if q_executor is not None:
                _require(family == "RSF" and spec["fold"] == 4 and horizon == 24
                         and source["branch"] == "OUTER_SELECTED_FAMILY_NO_AAR_REDEVELOPMENT"
                         and source.get("common_set_epv_binding") is not None
                         and spec.get("native_search_replay") is True
                         and spec.get("native_search_numbers") is True
                         and isinstance(q_executor, str), "F5_RETAINED_AAR_Q_EXECUTOR_DRIFT")
                retained = _retained_full0_source_members(Path(q_executor), aar_q_executor=True)
                _require(_sha(retained)
                         == "5c30305f8279acc7407bffc1b9d2d09cb1d100f819f69d4e7486c131c8bee5df",
                         "F5_RETAINED_AAR_Q_EXECUTOR_DRIFT")
            _require(horizon == 24 and spec["a12_executor_source_identity"] == _sha(_f45_source_member_sha256()),
                     "F5_RETAINED_AAR_Q_EXECUTOR_DRIFT")
        body["execution_scope"] = "F5_A12_SEARCH"
        body["a12_source"] = source
    result = {**body, "identity_sha256": _sha(body)}
    if "primary_search_source" in spec:
        from .f5 import _validate_primary_complex_search_result
        return _validate_primary_complex_search_result(spec, result)
    return result


def _winner_seed_coordinate(spec, task, partition=None):
    candidate = spec["seed_audit_candidate"]
    family = spec["family"]
    match = re.fullmatch(r"(SEED_AUDIT_[12])_T001_P(0[1-9]|1[0-5])_M(0[1-5])(_STOP|_REFIT|_FUNCTION|_LOCKED_REFIT)?", task["task_id"])
    _require(match is not None and family in {"RSF", "GBM_COX", "XGBOOST_COX"}
        and candidate["parameter_sha256"] == _v20_owner_sha(candidate["parameters"]), "WINNER_SEED_COORDINATE_INVALID")
    stage, part, imp, suffix = match.groups()
    part, imp = int(part), int(imp)
    policy = spec["model_seed_policy"]
    _require(spec["seed"] == policy["base"] + spec["fold"] * policy["outer_multiplier"]
        and task["seed"] == spec["seed"] + policy["extra_seed_offsets"][int(stage[-1])-1] + imp*100 + part
        and task["imputation"] == imp, "WINNER_SEED_COORDINATE_INVALID")
    expected = _engine_parameters(family, candidate["parameters"])
    actual = {k:v for k,v in task["parameters"].items() if k != "locked_trees"}
    _require(actual == expected and suffix in ({None} if family == "RSF" else
        {"_STOP", "_REFIT"} if family == "GBM_COX" else {"_FUNCTION", "_LOCKED_REFIT"}),
        "WINNER_SEED_PARAMETERS_INVALID")
    if partition is not None:
        _require(part == (partition["repeat"]-1)*5 + partition["inner_fold"]
            and partition["partition_id"] == task["partition_id"] and partition["kind"] == (
                "STOP" if suffix in {"_STOP", "_FUNCTION"} else "INNER"), "WINNER_SEED_PARTITION_INVALID")
    return stage, part, imp


def _winner_seed_python_binding(task, loaded, design, *, stop):
    spec, partition = task["spec"], loaded["partition"]
    stage, part, imp = _winner_seed_coordinate(spec, task, partition)
    registered = task["registered"]
    _require(spec["family"] == "XGBOOST_COX" and spec["backend"] == "CPU" and type(stop) is bool
        and ("primary_search_source" in spec or spec.get("execution_scope") == "F5_FULL_DEVELOPMENT_SEARCH")
        and loaded["imputation_indices"] == [imp]
        and registered.get("source_registered_identity", registered.get("identity")) == spec["registered_inputs_identity_sha256"]
        and not ("source_registered_identity" in registered and "identity" in registered)
        and (stop or task.get("prediction_horizons") == spec["monthly_fit_horizons"] == list(range(1,37))),
        "WINNER_SEED_INPUT_BINDING_INVALID")
    return {"model_seed": task["seed"], "imputation": imp, "coordinates": {
        "source": spec.get("primary_search_source", spec.get("final_search_source")),
        "task_id": task["task_id"], "partition_id": task["partition_id"], "stage": stage,
        "candidate_id": spec["seed_audit_candidate"]["candidate_id"]},
        "consumed_input_sha256": _sha({"parameters": task["parameters"], "stop": stop,
            "locked_value": None if stop else task["locked_rounds"],
            "candidate": spec["seed_audit_candidate"], "selected_parents": spec["selector_from_dependency"]["selected_parents"],
            "registered_identity": spec["registered_inputs_identity_sha256"],
            "patient_ids": loaded["fit_ids"], "design_columns": loaded["columns"],
            "design_dtype": str(design.dtype), "design": design.tolist(),
            "time": loaded["fit_time"].tolist(), "event": loaded["fit_event"].tolist()})}


def _winner_seed_only(spec, candidate, inner, evaluate_trials):
    """The two original extra-seed stages, after family/parameters are locked."""
    _require(spec["family"] in {"RSF", "GBM_COX", "XGBOOST_COX"}
        and isinstance(candidate, Mapping) and candidate.get("parameter_sha256") == _v20_owner_sha(candidate["parameters"])
        and len(inner) == 15, "WINNER_SEED_INPUT_INVALID")
    offsets = spec["model_seed_policy"]["extra_seed_offsets"]
    _require(len(offsets) == 2 and len(set(offsets)) == 2, "WINNER_SEED_POLICY_INVALID")
    trace = {f"SEED_AUDIT_{i}": evaluate_trials(f"SEED_AUDIT_{i}", [candidate], inner, 5, spec["seed"] + offset)
             for i, offset in enumerate(offsets, 1)}
    count = sum(row["evaluation_units"] for rows in trace.values() for row in rows)
    _require(count == 150, "WINNER_SEED_COVERAGE_INVALID")
    stop = 0 if spec["family"] == "RSF" else count
    body = {"kind": "PADML_WINNER_SEED_DIAGNOSTIC_V1", "status": "PASS", "family": spec["family"],
        "registered_inputs_identity_sha256": spec["registered_inputs_identity_sha256"],
        "candidate": dict(candidate), "seed_base": spec["seed"], "extra_seed_offsets": offsets,
        "search_trace": trace, "search_evaluation_unit_count": count,
        "locked_training_refit_count": count, "response_free_stopping_fit_count": stop,
        "total_search_fit_count": count + stop, "primary_writeback": "FORBIDDEN"}
    return _validate_winner_seed_result(spec, {**body, "identity_sha256": _sha(body)})


def _validate_winner_seed_result(spec, result):
    from .f5 import _validate_complex_search_stage
    candidate, family = spec["seed_audit_candidate"], spec["family"]
    count, stop = 150, 0 if family == "RSF" else 150
    _require(result.get("kind") == "PADML_WINNER_SEED_DIAGNOSTIC_V1"
        and result.get("status") == "PASS" and result.get("family") == family
        and family in {"RSF", "GBM_COX", "XGBOOST_COX"}
        and result.get("identity_sha256") == _sha({k:v for k,v in result.items() if k != "identity_sha256"})
        and result.get("candidate") == candidate
        and candidate["parameter_sha256"] == _v20_owner_sha(candidate["parameters"])
        and result.get("registered_inputs_identity_sha256") == spec["registered_inputs_identity_sha256"]
        and result.get("seed_base") == spec["seed"]
        and result.get("extra_seed_offsets") == spec["model_seed_policy"]["extra_seed_offsets"]
        and result.get("primary_writeback") == "FORBIDDEN"
        and result.get("search_evaluation_unit_count") == result.get("locked_training_refit_count") == count
        and result.get("response_free_stopping_fit_count") == stop
        and result.get("total_search_fit_count") == count + stop
        and set(result.get("search_trace", {})) == {"SEED_AUDIT_1", "SEED_AUDIT_2"},
        "WINNER_SEED_RESULT_INVALID")
    original = {candidate.get("candidate_id", candidate.get("trial_id")):
        (canonical_json_bytes(candidate["parameters"]), candidate["parameter_sha256"])}
    for stage, rows in result["search_trace"].items():
        _validate_complex_search_stage(rows, stage=stage, count=1, units=75, partitions=15,
            rankings=3, horizon=spec.get("selection_horizon_months", 24), family=family,
            original_parameters=original)
    return result


def _run_r_registered_rsf(
    spec: dict[str, Any],
    registered: dict[str, Any],
    scratch: Path,
    repo_root: Path,
    *,
    search_only: bool = False,
    seed_audit_candidate: Mapping[str, Any] | None = None,
    full_pipeline_replicate: int | None = None,
    retained_search_prefix: dict[str, Any] | None = None,
) -> dict[str, Any]:
    _require(spec["family"] == "RSF", "F2_RSF_ROUTE_INVALID")
    full_pipeline_seeds = _full_pipeline_search_seed_registry(spec, search_only, full_pipeline_replicate)
    control = spec.get("native_search_batch", {})
    primary_s2 = "primary_rsf_s2_consumption" in control
    primary_s3a = "primary_rsf_s3a_consumption" in control
    primary_s3b1 = "primary_rsf_s3b1_consumption" in control
    primary_s3b2 = "primary_rsf_s3b2_consumption" in control
    primary_prefix = "primary_rsf_retained_prefix" in control
    primary_missing_s1 = False
    if primary_prefix:
        _require(not any((primary_s2, primary_s3a, primary_s3b1, primary_s3b2))
                 and search_only is True and full_pipeline_seeds is None and full_pipeline_replicate is None
                 and "prepared_calls" in control and control.get("prepare_only") is True
                 and control.get("task_ids") is None and not control.get("completed")
                 and spec.get("primary_search_source") is not None
                 and retained_search_prefix is control["primary_rsf_retained_prefix"]
                 and retained_search_prefix.get("primary_search_source") == spec["primary_search_source"]
                 and _sha(retained_search_prefix) == control["primary_rsf_retained_prefix_sha256"],
                 "F5_PRIMARY_RSF_RETAINED_PREFIX_INVALID")
        primary_missing_s1 = "S1" not in retained_search_prefix.get("search_trace", {})
        if primary_missing_s1:
            # Historical S1 was consumed but its summaries were not retained.
            # S2 is an independent candidate stream; its original promotion
            # and subsequent stages do not need S1 scores. Never recreate S1
            # here or pretend the partial trace is a complete Q result.
            history = retained_search_prefix.get("s1_consumed_history")
            trace_keys = list(retained_search_prefix.get("search_trace", {}))
            _require(trace_keys in (["S2"], ["S2", "S3A"], ["S2", "S3A", "S3B1"])
                     and isinstance(history, dict) and set(history) == {
                         "report", "predecessor_execution_sha256", "consumed_model_coordinates", "score_trace_status"}
                     and history["score_trace_status"] == "NOT_RETAINED"
                     and type(history["consumed_model_coordinates"]) is int
                     and history["consumed_model_coordinates"] == 120
                     and isinstance(history["report"], dict)
                     and set(history["report"]) == {"sha256", "size_bytes"}
                     and type(history["report"]["size_bytes"]) is int and history["report"]["size_bytes"] > 0
                     and isinstance(history["predecessor_execution_sha256"], list)
                     and len(history["predecessor_execution_sha256"]) == 7
                     and len(set(history["predecessor_execution_sha256"])) == 7,
                     "F5_PRIMARY_RSF_RETAINED_PREFIX_INVALID")
            for digest in [history["report"]["sha256"], *history["predecessor_execution_sha256"]]:
                _require(isinstance(digest, str) and re.fullmatch(r"[0-9a-f]{64}", digest) is not None,
                         "F5_PRIMARY_RSF_RETAINED_PREFIX_INVALID")
            from .f5 import _a12_q_stop_phase
            terminal_phase = _a12_q_stop_phase("S3B2", refit=True, family="RSF",
                                              rsf_pool_workers=spec["pool_workers"])[0]
            _require(not any(row.get("phase") == terminal_phase for _, row in control.get("batches", [])),
                     "F5_PRIMARY_RSF_S1_SUMMARY_REQUIRED")
    if primary_s3b2:
        from .f4 import _primary_rsf_search_source
        from .f5 import _primary_rsf_prepared_input
        # This historical route reconstructs a missing S1 summary. Completion
        # of S3B2 is not, by itself, authority to spend a recovery call.
        _require(type(control.get("s1_summary_recovery_call_limit")) is int
                 and control["s1_summary_recovery_call_limit"] ==
                     (0 if "primary_rsf_s1_summary" in control else 1),
                 "F5_PRIMARY_RSF_S1_SUMMARY_RECOVERY_AUTHORITY_REQUIRED")
        _require(control["primary_rsf_s3b2_consumption"] is True
                 and not any((primary_s2, primary_s3a, primary_s3b1))
                 and _primary_rsf_search_source(spec) is not None
                 and search_only is True and full_pipeline_replicate is None
                 and full_pipeline_seeds is None and retained_search_prefix is None
                 and control.get("prepare_only") is True and control.get("task_ids") is None
                 and not control.get("completed") and not control.get("q_unit_outputs")
                 and len(control.get("batches", [])) == 14 and not control.get("used_batches")
                 and control.get("confirmed_model_fits") == control.get("confirmed_stop_fits") == 0,
                 "F5_PRIMARY_RSF_S3B2_CONSUMPTION_SCOPE_INVALID")
        root = Path(spec["native_search_root"]).parent
        _primary_rsf_prepared_input((root / "input.json").read_bytes(),
            Path(control["primary_rsf_preparation"]), Path(control["primary_rsf_producer"]),
            **{name + "_evidence": control["primary_rsf_" + name + "_evidence"]
               for name in ("s2", "s3a", "s3b1", "s3b2")})
        retained_primary_s3b1 = json.loads(
            control["primary_rsf_s3b2_evidence"]["primary-s3b2/report.json"].read_bytes()
        )["original_q_boundary"]
        if "primary_rsf_s1_summary" in control:
            from .f5 import _reuse_primary_rsf_s1_summary
            _reuse_primary_rsf_s1_summary(spec, root, control)
    if primary_s3b1:
        from .f4 import _primary_rsf_search_source
        from .f5 import _primary_rsf_prepared_input
        _require(control["primary_rsf_s3b1_consumption"] is True and not primary_s2 and not primary_s3a
                 and _primary_rsf_search_source(spec) is not None
                 and search_only is True and full_pipeline_replicate is None
                 and full_pipeline_seeds is None and retained_search_prefix is None
                 and control.get("prepare_only") is True and control.get("task_ids") is None
                 and not control.get("completed") and not control.get("q_unit_outputs")
                 and len(control.get("batches", [])) == 7 and not control.get("used_batches")
                 and control.get("confirmed_model_fits") == control.get("confirmed_stop_fits") == 0,
                 "F5_PRIMARY_RSF_S3B1_CONSUMPTION_SCOPE_INVALID")
        root = Path(spec["native_search_root"]).parent
        _primary_rsf_prepared_input((root / "input.json").read_bytes(),
            Path(control["primary_rsf_preparation"]), Path(control["primary_rsf_producer"]),
            s2_evidence=control["primary_rsf_s2_evidence"],
            s3a_evidence=control["primary_rsf_s3a_evidence"],
            s3b1_evidence=control["primary_rsf_s3b1_evidence"])
        retained_primary_s3a = json.loads(
            control["primary_rsf_s3b1_evidence"]["primary-s3b1/report.json"].read_bytes()
        )
        retained_primary_s3a = retained_primary_s3a.get("original_q_boundary", retained_primary_s3a)
    if primary_s3a:
        from .f4 import _primary_rsf_search_source
        from .f5 import _primary_rsf_prepared_input
        _require(control["primary_rsf_s3a_consumption"] is True and not primary_s2
                 and _primary_rsf_search_source(spec) is not None
                 and search_only is True and full_pipeline_replicate is None
                 and full_pipeline_seeds is None and retained_search_prefix is None
                 and control.get("prepare_only") is True and control.get("task_ids") is None
                 and not control.get("completed") and not control.get("q_unit_outputs")
                 and len(control.get("batches", [])) == 7 and not control.get("used_batches")
                 and control.get("confirmed_model_fits") == control.get("confirmed_stop_fits") == 0,
                 "F5_PRIMARY_RSF_S3A_CONSUMPTION_SCOPE_INVALID")
        root = Path(spec["native_search_root"]).parent
        _primary_rsf_prepared_input((root / "input.json").read_bytes(),
            Path(control["primary_rsf_preparation"]), Path(control["primary_rsf_producer"]),
            s2_evidence=control["primary_rsf_s2_evidence"],
            s3a_evidence=control["primary_rsf_s3a_evidence"])
        s3a_evidence = control["primary_rsf_s3a_evidence"]
        publication = "source/primary-compilation.json" in s3a_evidence
        retained_primary_s2 = json.loads(s3a_evidence[
            "source/primary-compilation.json" if publication else "primary-s3a/report.json"].read_bytes())
        if not publication:
            retained_primary_s2 = retained_primary_s2["original_q_boundary"]
    if primary_s2:
        from .f4 import _primary_rsf_search_source
        _require(control["primary_rsf_s2_consumption"] is True
                 and _primary_rsf_search_source(spec) is not None
                 and search_only is True and full_pipeline_replicate is None
                 and full_pipeline_seeds is None and retained_search_prefix is None
                 and control.get("prepare_only") is True and control.get("task_ids") is None
                 and not control.get("completed") and not control.get("q_unit_outputs")
                 and control.get("primary_rsf_s2_evidence") is not None
                 and len(control.get("batches", [])) == 7 and not control.get("used_batches")
                 and control.get("confirmed_model_fits") == control.get("confirmed_stop_fits") == 0,
                 "F5_PRIMARY_RSF_S2_CONSUMPTION_SCOPE_INVALID")
    if retained_search_prefix is not None and not primary_prefix:
        control = spec.get("native_search_batch", {})
        _require(search_only and full_pipeline_replicate is None and full_pipeline_seeds is None
                 and spec.get("execution_scope") == "F5_FULL_DEVELOPMENT_SEARCH"
                 and _selection_horizon_from_spec(spec) == 12 and "full0_rsf_s1s2_rescore" in control
                 and retained_search_prefix is control.get("retained_rsf_search_prefix")
                 and retained_search_prefix.get("status") == "PREPARED_Q_BATCH"
                 and retained_search_prefix.get("stage_acceptance") is False
                 and list(retained_search_prefix.get("search_trace", {})) == ["S1", "S2", "S3A", "S3B1"]
                 and control.get("retained_rsf_prefix_result_sha256")
                     == "556821c6675669b45a21a8b16d590453158c55705ef43f1696a278ba111f05bd"
                 and _sha({key: value for key, value in retained_search_prefix.items()
                           if key != "execution_report"}) == control["retained_rsf_prefix_result_sha256"],
                 "F5_FULL0_RSF_RETAINED_PREFIX_INVALID")
    selected = list(spec["selector_from_dependency"]["selected_parents"])
    inner = sorted(
        (row for row in registered["partitions"] if row["kind"] == "INNER"),
        key=lambda row: (row["repeat"], row["inner_fold"]),
    )
    centers = sorted(
        registered.get("diagnostic_partitions", []),
        key=lambda row: row["validation_center"],
    )
    outer = [row for row in registered["partitions"] if row["kind"] == "OUTER"]
    _require(
        type(search_only) is bool
        and len(inner) == 15
        and (search_only or (len(centers) == 5 and len(outer) == 1)),
        "F2_RSF_REGISTERED_PARTITION_DENOMINATOR_INVALID",
    )
    accumulator: dict[str, list[dict[str, Any]]] = {}

    def evaluate_trials(
        stage: str,
        trials: list[dict[str, Any]],
        partitions: list[dict[str, Any]],
        imputation_count: int,
        stage_seed: int,
    ) -> list[dict[str, Any]]:
        if retained_search_prefix is not None and stage in retained_search_prefix["search_trace"]:
            # The original completed numerical call owns this immutable prefix.
            # Keep promotion below in its original place; do not evaluate its
            # models, candidate RNG or metrics a second time to reach S3B2.
            retained = retained_search_prefix["search_trace"][stage]
            if primary_prefix:
                from .f5 import _validate_complex_search_stage
                _validate_complex_search_stage(retained, stage=stage, count=len(trials),
                    units=len(partitions) * imputation_count, partitions=len(partitions),
                    rankings=len({row["repeat"] for row in partitions}), horizon=12, family="RSF",
                    original_parameters={trial.get("trial_id", trial.get("candidate_id")):
                        (canonical_json_bytes(trial["parameters"]), trial["parameter_sha256"]) for trial in trials})
            _require(len(retained) == len(trials)
                     and all(row["candidate_id"] == trial.get("trial_id", trial.get("candidate_id"))
                         and row["parameter_sha256"] == trial["parameter_sha256"]
                         and canonical_json_bytes(row["parameters"]) == canonical_json_bytes(trial["parameters"])
                         and row["evaluation_units"] == len(partitions) * imputation_count
                         and row.get("selection_horizon_months") == 12
                         and row["stage_id"] == stage and row["trial_index"] == index
                         for index, (row, trial) in enumerate(zip(retained, trials, strict=True), 1)),
                     "F5_FULL0_RSF_RETAINED_PREFIX_INVALID")
            return json.loads(canonical_json_bytes(retained))
        tasks: list[dict[str, Any]] = []
        owners: list[int] = []
        for trial_index, trial in enumerate(trials, start=1):
            parameters = _engine_parameters("RSF", trial["parameters"])
            for partition_index, partition in enumerate(partitions, start=1):
                for imputation in range(1, imputation_count + 1):
                    tasks.append(
                        {
                            "task_id": (
                                f"{stage}_T{trial_index:03d}_P{partition_index:02d}_"
                                f"M{imputation:02d}"
                            ),
                            "partition_id": partition["partition_id"],
                            "imputation": imputation,
                            "family": "RSF",
                            "selected_parents": selected,
                            "parameters": parameters,
                            "seed": (_full_pipeline_trial_seed(full_pipeline_seeds, stage, trial)
                                     if full_pipeline_seeds else stage_seed + imputation * 100 + partition_index),
                        }
                    )
                    owners.append(trial_index - 1)
        evaluated = _evaluate_r_prediction_batch(
            spec, registered, tasks, scratch, repo_root
        )
        _accumulate_registered_evaluations(accumulator, evaluated)
        scoring_context = _trial_scoring_context(partitions,
            selection_horizon_months=_selection_horizon_from_spec(spec))
        grouped: list[list[dict[str, Any]]] = [[] for _ in trials]
        for owner, row in zip(owners, evaluated, strict=True):
            grouped[owner].append(row)
        result: list[dict[str, Any]] = []
        for trial_index, (trial, values) in enumerate(
            zip(trials, grouped, strict=True), start=1
        ):
            result.append(
                {
                    "stage_id": stage,
                    "trial_index": trial_index,
                    "candidate_id": trial.get("trial_id", trial.get("candidate_id")),
                    "parameters": trial["parameters"],
                    "parameter_sha256": trial["parameter_sha256"],
                    **_trial_evaluation_summary(values, scoring_context, imputation_count),
                }
            )
        if "prepared_calls" in control and spec.get("primary_search_source") is not None:
            control.setdefault("primary_rsf_search_trace", {})[stage] = json.loads(canonical_json_bytes(result))
        return result

    if seed_audit_candidate is not None:
        _require(search_only and full_pipeline_replicate is None, "WINNER_SEED_SCOPE_INVALID")
        return _winner_seed_only(spec, seed_audit_candidate, inner, evaluate_trials)

    trace: dict[str, list[dict[str, Any]]] = {}
    if not primary_s2 and not primary_s3a and not primary_s3b1 and not primary_missing_s1:
        trace["S1"] = (json.loads(canonical_json_bytes(control["primary_rsf_s1_trace"]))
                       if primary_s3b2 and "primary_rsf_s1_summary" in control else evaluate_trials(
            "S1",
            spec["candidate_trials"]["S1"],
            [row for row in inner if row["repeat"] == 1],
            1,
            spec["seed"] + 10_000,
        ))
        if spec.get("primary_search_source") is not None:
            # S2's original boundary interrupts this owner before it returns
            # the final Q. Preserve the summaries already computed here;
            # never force a future consumer to regenerate them from models.
            control["primary_rsf_s1_trace"] = json.loads(canonical_json_bytes(trace["S1"]))
    trace["S2"] = (json.loads(canonical_json_bytes(retained_primary_s3b1["search_trace"]["S2"]))
                   if primary_s3b2 else
                   json.loads(canonical_json_bytes(retained_primary_s2["search_trace"]["S2"]))
                   if primary_s3a else
                   json.loads(canonical_json_bytes(retained_primary_s3a["search_trace"]["S2"]))
                   if primary_s3b1 else evaluate_trials(
        "S2",
        spec["candidate_trials"]["S2"],
        [row for row in inner if row["repeat"] == 2],
        5,
        spec["seed"] + 20_000,
    ))
    top3 = _tree_s3a_candidates(trace)
    if primary_s3a:
        _require(canonical_json_bytes(top3) == canonical_json_bytes(retained_primary_s2["s3a_candidates"]),
                 "F5_PRIMARY_RSF_RETAINED_S2_PROMOTION_DRIFT")
    if primary_s3b1:
        _require(canonical_json_bytes(top3) == canonical_json_bytes(retained_primary_s3a["s3a_candidates"]),
                 "F5_PRIMARY_RSF_RETAINED_S2_PROMOTION_DRIFT")
    if primary_s3b2:
        _require(canonical_json_bytes(top3) == canonical_json_bytes(retained_primary_s3b1["s3a_candidates"]),
                 "F5_PRIMARY_RSF_RETAINED_S2_PROMOTION_DRIFT")
    if primary_s2:
        # The original S1 consumer did not retain trial summaries. Its byte-
        # bound history is separate; never invent an S1 trace or replay it.
        control["primary_rsf_s2_trace"] = {"search_trace": dict(trace), "s3a_candidates": top3}
    if retained_search_prefix is not None and not primary_prefix:
        _require(canonical_json_bytes(top3) == canonical_json_bytes(retained_search_prefix["s3a_candidates"]),
                 "F5_FULL0_RSF_RETAINED_PREFIX_PROMOTION_DRIFT")
    control = spec.get("native_search_batch", {})
    if "full0_rsf_s1s2_rescore" in control:
        _require(search_only and full_pipeline_seeds is None
                 and spec.get("execution_scope") == "F5_FULL_DEVELOPMENT_SEARCH"
                 and _selection_horizon_from_spec(spec) == 12, "F5_FULL0_RSF_S1S2_NUMBERS_ONLY")
        # These are the actual original IBS/MI/repeat results and promotion,
        # not a second chooser or an ID-only reconstruction after the fact.
        control["s1s2_trace"] = {"search_trace": dict(trace), "s3a_candidates": top3}
    trace["S3A"] = (json.loads(canonical_json_bytes(retained_primary_s3b1["search_trace"]["S3A"]))
                     if primary_s3b2 else
                     json.loads(canonical_json_bytes(retained_primary_s3a["search_trace"]["S3A"]))
                     if primary_s3b1 else evaluate_trials(
        "S3A", top3, [row for row in inner if row["repeat"] == 3], 20, spec["seed"] + 30_000
    ))
    _require(not primary_s2, "F5_PRIMARY_RSF_S3A_PREPARATION_BOUNDARY_REQUIRED")
    top2 = _rank_trials(trace["S3A"], retain=2)[:2]
    if primary_s3a:
        control["primary_rsf_s3a_trace"] = {"search_trace": dict(trace),
            "s3a_candidates": top3, "s3b1_candidates": top2}
    if primary_s3b1:
        _require(canonical_json_bytes(top2) == canonical_json_bytes(retained_primary_s3a["s3b1_candidates"]),
                 "F5_PRIMARY_RSF_RETAINED_S3A_PROMOTION_DRIFT")
    if primary_s3b2:
        _require(canonical_json_bytes(top2) == canonical_json_bytes(retained_primary_s3b1["s3b1_candidates"]),
                 "F5_PRIMARY_RSF_RETAINED_S3A_PROMOTION_DRIFT")
    if retained_search_prefix is not None and not primary_prefix:
        _require(canonical_json_bytes(top2) == canonical_json_bytes(retained_search_prefix["s3b1_candidates"]),
                 "F5_FULL0_RSF_RETAINED_PREFIX_PROMOTION_DRIFT")
    if "full0_rsf_s1s2_rescore" in control:
        control["s1s2_trace"].update(search_trace=dict(trace), s3b1_candidates=top2)
    trace["S3B1"] = (json.loads(canonical_json_bytes(retained_primary_s3b1["search_trace"]["S3B1"]))
                     if primary_s3b2 else evaluate_trials(
        "S3B1", top2, inner, 5, spec["seed"] + 40_000
    ))
    provisional = _rank_trials(trace["S3B1"], retain=1)[0]
    if primary_s3b2:
        _require(canonical_json_bytes(provisional) == canonical_json_bytes(retained_primary_s3b1["s3b2_candidate"]),
                 "F5_PRIMARY_RSF_RETAINED_S3B1_PROMOTION_DRIFT")
    if primary_s3b1:
        control["primary_rsf_s3b1_trace"] = {"search_trace": dict(trace),
            "s3a_candidates": top3, "s3b1_candidates": top2, "s3b2_candidate": provisional}
    if retained_search_prefix is not None and not primary_prefix:
        _require(canonical_json_bytes(provisional) == canonical_json_bytes(retained_search_prefix["s3b2_candidate"]),
                 "F5_FULL0_RSF_RETAINED_PREFIX_PROMOTION_DRIFT")
    if "full0_rsf_s1s2_rescore" in control:
        control["s1s2_trace"].update(search_trace=dict(trace), s3b2_candidate=provisional)
    trace["S3B2"] = evaluate_trials(
        "S3B2", [provisional], inner, 20, spec["seed"] + 50_000
    )
    winner = trace["S3B2"][0]
    if search_only:
        return _shared_full_development_search_result(
            spec,
            registered,
            trace,
            {
                "family": "RSF",
                "candidate_id": winner["candidate_id"],
                "parameters": winner["parameters"],
                "selection_metric": f"IBS_0_{_selection_horizon_from_spec(spec)}",
                "selection_stage": "S3B2",
            },
            full_pipeline_seeds,
        )
    trace["SEED_AUDIT"] = []
    for audit_index, offset in enumerate(
        spec["model_seed_policy"]["extra_seed_offsets"], start=1
    ):
        row = evaluate_trials(
            f"SEED_AUDIT_{audit_index}",
            [winner],
            inner,
            5,
            spec["seed"] + offset,
        )[0]
        trace["SEED_AUDIT"].append({"seed_offset": offset, **row})
    trace["CENTER_STRESS"] = evaluate_trials(
        "CENTER_STRESS", _rank_trials(trace["S3B1"], retain=2)[:2], centers, 5, spec["seed"] + 80_000
    )
    selected_parameters = _engine_parameters("RSF", winner["parameters"])
    final_tasks = [
        {
            "task_id": f"FINAL_OUTER_M{imputation:02d}",
            "partition_id": outer[0]["partition_id"],
            "imputation": imputation,
            "family": "RSF",
            "selected_parents": selected,
            "parameters": selected_parameters,
            "prediction_horizons": spec["monthly_fit_horizons"],
            "seed": spec["seed"] + imputation,
        }
        for imputation in range(1, 21)
    ]
    final = _run_r_prediction_batch(
        spec, registered, final_tasks, scratch, repo_root
    )
    evaluation_units = sum(
        row["evaluation_units"] for rows in trace.values() for row in rows
    ) + 20
    _require(
        evaluation_units == spec["search_budget"]["standard_outer_units"],
        "F2_RSF_STANDARD_OUTER_BUDGET_INVALID",
    )
    return _build_registered_model_result(
        spec,
        registered,
        final,
        selector=spec["selector_from_dependency"],
        search_trace=trace,
        search_evaluation_unit_count=evaluation_units,
        selected_spec={
            "family": "RSF",
            "candidate_id": winner["candidate_id"],
            "parameters": winner["parameters"],
            "selection_metric": "IBS_0_24",
            "selection_stage": "S3B2",
        },
        execution_rows=_registered_selection_execution_rows(
            registered, accumulator
        ),
    )


def _run_r_gbm_stop_batch(
    spec: dict[str, Any],
    registered: dict[str, Any],
    tasks: list[dict[str, Any]],
    scratch: Path,
    repo_root: Path,
) -> list[dict[str, Any]]:
    produced = _run_r_prediction_batch(
        spec,
        registered,
        tasks,
        scratch,
        repo_root,
        evaluation_mode="GROUPED_COX_LOCK",
    )
    _require(
        all(
            row.get("task_id") == task["task_id"]
            and row.get("partition_id") == task["partition_id"]
            and row.get("imputation") == task["imputation"]
            and isinstance(row.get("selected_trees"), int)
            and isinstance(row.get("identity"), str)
            and isinstance(row.get("minimum_stopping_loss"), (int, float))
            for task, row in zip(tasks, produced, strict=True)
        ),
        "F2_GBM_CHILD_STOP_RESULT_INVALID",
    )
    return produced


def _integer_median(values: list[int]) -> int:
    _require(
        values
        and all(
            isinstance(value, int) and not isinstance(value, bool) and value > 0
            for value in values
        ),
        "F2_STOPPING_LOCK_SET_INVALID",
    )
    ordered = sorted(values)
    middle = len(ordered) // 2
    return (
        ordered[middle]
        if len(ordered) % 2
        else (ordered[middle - 1] + ordered[middle]) // 2
    )


def _registered_stopping_execution_rows(
    registered: dict[str, Any],
    inner_accumulator: dict[str, list[dict[str, Any]]],
    stop_accumulator: dict[str, list[dict[str, Any]]],
) -> list[dict[str, Any]]:
    by_partition = {
        row["partition_id"]: row for row in registered["partitions"]
    }
    rows = _registered_selection_execution_rows(registered, inner_accumulator)
    inner_by_coordinates = {
        (row["repeat"], row["inner_fold"]): row
        for row in rows
        if row["kind"] == "INNER"
    }
    for partition_id, locks in stop_accumulator.items():
        partition = by_partition[partition_id]
        key = (partition["repeat"], partition["inner_fold"])
        inner_row = inner_by_coordinates.get(key)
        inner_partition = next(
            (
                row
                for row in registered["partitions"]
                if row["kind"] == "INNER"
                and (row["repeat"], row["inner_fold"]) == key
            ),
            None,
        )
        inner_values = (
            inner_accumulator.get(inner_partition["partition_id"], [])
            if inner_partition is not None
            else []
        )
        lock_identities = [row["identity"] for row in locks]
        _require(
            inner_row is not None
            and locks
            and len(inner_values) == len(locks)
            and [row.get("lock_identity_sha256") for row in inner_values]
            == lock_identities,
            "F2_STOPPING_REFIT_LINK_INVALID",
        )
        lock_set_sha256 = _sha(lock_identities)
        inner_row["lock_identity_sha256"] = lock_set_sha256
        inner_row["refit_scope"] = "FULL_INNER_ANALYSIS"
        rows.append(
            {
                "kind": "STOP",
                "partition_id": partition_id,
                "repeat": partition["repeat"],
                "inner_fold": partition["inner_fold"],
                "purpose": "EARLY_STOPPING_LOCK",
                "input_record_sha256": _sha(
                    _registered_partition_identity_record(partition)
                ),
                "prediction_seal_count": len(locks),
                "evaluation_count": len(locks),
                "evaluation_response_sha256": partition["evaluation_response"]["sha256"],
                "evaluation_ids_sha256": partition["evaluation_ids_sha256"],
                "prediction_seal_set_sha256": _sha(
                    [row["risk_curve_sha256"] for row in locks]
                ),
                "metric_set_sha256": _sha(
                    [row["minimum_stopping_loss"] for row in locks]
                ),
                "lock_identity_sha256": lock_set_sha256,
            }
        )
    return rows


def _run_r_registered_gbm(
    spec: dict[str, Any],
    registered: dict[str, Any],
    scratch: Path,
    repo_root: Path,
    *,
    search_only: bool = False,
    seed_audit_candidate: Mapping[str, Any] | None = None,
    full_pipeline_replicate: int | None = None,
) -> dict[str, Any]:
    _require(spec["family"] == "GBM_COX", "F2_GBM_ROUTE_INVALID")
    full_pipeline_seeds = _full_pipeline_search_seed_registry(spec, search_only, full_pipeline_replicate)
    selected = list(spec["selector_from_dependency"]["selected_parents"])
    inner = sorted(
        (row for row in registered["partitions"] if row["kind"] == "INNER"),
        key=lambda row: (row["repeat"], row["inner_fold"]),
    )
    stops = {
        (row["repeat"], row["inner_fold"]): row
        for row in registered["partitions"]
        if row["kind"] == "STOP"
    }
    centers = sorted(
        registered.get("diagnostic_partitions", []),
        key=lambda row: row["validation_center"],
    )
    outer = [row for row in registered["partitions"] if row["kind"] == "OUTER"]
    _require(
        type(search_only) is bool
        and len(inner) == 15
        and len(stops) == 15
        and (search_only or (len(centers) == 5 and len(outer) == 1)),
        "F2_GBM_REGISTERED_PARTITION_DENOMINATOR_INVALID",
    )
    for partition in inner:
        stop = stops[(partition["repeat"], partition["inner_fold"])]
        _require(
            stop.get("consumer_set")
            == ["GBM_COX", "XGBOOST_COX", "COXTIME_SET_A"]
            and stop["application_ids"] == partition["fit_ids"]
            and set(stop["fit_ids"]).isdisjoint(stop["evaluation_ids"])
            and set(stop["fit_ids"]) | set(stop["evaluation_ids"])
            == set(stop["application_ids"]),
            "F2_GBM_STOP_REFIT_LINK_INVALID",
        )
    inner_accumulator: dict[str, list[dict[str, Any]]] = {}
    stop_accumulator: dict[str, list[dict[str, Any]]] = {}

    def evaluate_trials(
        stage: str,
        trials: list[dict[str, Any]],
        partitions: list[dict[str, Any]],
        imputation_count: int,
        stage_seed: int,
    ) -> list[dict[str, Any]]:
        stop_tasks: list[dict[str, Any]] = []
        owners: list[int] = []
        full_partitions: list[dict[str, Any]] = []
        for trial_index, trial in enumerate(trials):
            parameters = _engine_parameters("GBM_COX", trial["parameters"])
            for partition_index, partition in enumerate(partitions, start=1):
                stop = stops[(partition["repeat"], partition["inner_fold"])]
                for imputation in range(1, imputation_count + 1):
                    stop_tasks.append(
                        {
                            "task_id": f"{stage}_T{trial_index + 1:03d}_P{partition_index:02d}_M{imputation:02d}_STOP",
                            "partition_id": stop["partition_id"],
                            "imputation": imputation,
                            "family": "GBM_COX",
                            "selected_parents": selected,
                            "parameters": parameters,
                            "producer_kind": "GBM_STOP_CURVE",
                            "seed": (full_pipeline_seeds["stop_seeds"][imputation - 1]
                                     if full_pipeline_seeds else stage_seed + imputation * 100 + partition_index),
                        }
                    )
                    owners.append(trial_index)
                    full_partitions.append(partition)
        locks = _run_r_gbm_stop_batch(
            spec, registered, stop_tasks, scratch, repo_root
        )
        full_tasks: list[dict[str, Any]] = []
        for stop_task, lock, partition, owner in zip(
            stop_tasks, locks, full_partitions, owners, strict=True
        ):
            full_tasks.append(
                {
                    **stop_task,
                    "task_id": stop_task["task_id"].removesuffix("_STOP") + "_REFIT",
                    "partition_id": partition["partition_id"],
                    "producer_kind": "SURVIVAL",
                    "seed": (_full_pipeline_trial_seed(full_pipeline_seeds, stage, trials[owner])
                             if full_pipeline_seeds else stop_task["seed"]),
                    "parameters": {
                        **stop_task["parameters"],
                        "locked_trees": lock["selected_trees"],
                    },
                }
            )
            stop_accumulator.setdefault(lock["partition_id"], []).append(lock)
        evaluated = _evaluate_r_prediction_batch(
            spec, registered, full_tasks, scratch, repo_root
        )
        for row, lock in zip(evaluated, locks, strict=True):
            row["lock_identity_sha256"] = lock["identity"]
        _accumulate_registered_evaluations(inner_accumulator, evaluated)
        scoring_context = _trial_scoring_context(partitions,
            selection_horizon_months=_selection_horizon_from_spec(spec))
        grouped: list[list[tuple[dict[str, Any], dict[str, Any]]]] = [
            [] for _ in trials
        ]
        for owner, row, lock in zip(owners, evaluated, locks, strict=True):
            grouped[owner].append((row, lock))
        results: list[dict[str, Any]] = []
        for trial_index, (trial, values) in enumerate(
            zip(trials, grouped, strict=True), start=1
        ):
            locked = [lock["selected_trees"] for _, lock in values]
            results.append(
                {
                    "stage_id": stage,
                    "trial_index": trial_index,
                    "candidate_id": trial.get("trial_id", trial.get("candidate_id")),
                    "parameters": trial["parameters"],
                    "parameter_sha256": trial["parameter_sha256"],
                    **_trial_evaluation_summary(
                        [row for row, _ in values], scoring_context, imputation_count
                    ),
                    "selected_trees_median": _integer_median(locked),
                }
            )
        return results

    if seed_audit_candidate is not None:
        _require(search_only and full_pipeline_replicate is None, "WINNER_SEED_SCOPE_INVALID")
        return _winner_seed_only(spec, seed_audit_candidate, inner, evaluate_trials)

    trace: dict[str, list[dict[str, Any]]] = {}
    trace["S1"] = evaluate_trials(
        "S1", spec["candidate_trials"]["S1"],
        [row for row in inner if row["repeat"] == 1], 1, spec["seed"] + 10_000
    )
    trace["S2"] = evaluate_trials(
        "S2", spec["candidate_trials"]["S2"],
        [row for row in inner if row["repeat"] == 2], 5, spec["seed"] + 20_000
    )
    top3 = _tree_s3a_candidates(trace)
    trace["S3A"] = evaluate_trials(
        "S3A", top3, [row for row in inner if row["repeat"] == 3], 20, spec["seed"] + 30_000
    )
    top2 = _rank_trials(trace["S3A"], retain=2)[:2]
    trace["S3B1"] = evaluate_trials(
        "S3B1", top2, inner, 5, spec["seed"] + 40_000
    )
    provisional = _rank_trials(trace["S3B1"], retain=1)[0]
    trace["S3B2"] = evaluate_trials(
        "S3B2", [provisional], inner, 20, spec["seed"] + 50_000
    )
    winner = trace["S3B2"][0]
    if search_only:
        return _shared_full_development_search_result(
            spec,
            registered,
            trace,
            {
                "family": "GBM_COX",
                "candidate_id": winner["candidate_id"],
                "parameters": winner["parameters"],
                "selected_trees": winner["selected_trees_median"],
                "selection_metric": f"IBS_0_{_selection_horizon_from_spec(spec)}",
                "selection_stage": "S3B2",
            },
            full_pipeline_seeds,
        )
    trace["SEED_AUDIT"] = [
        {
            "seed_offset": offset,
            **evaluate_trials(
                f"SEED_AUDIT_{index}", [winner], inner, 5, spec["seed"] + offset
            )[0],
        }
        for index, offset in enumerate(
            spec["model_seed_policy"]["extra_seed_offsets"], start=1
        )
    ]
    # Center stress is a fixed locked-spec diagnostic and does not select trees.
    center_candidates = _rank_trials(trace["S3B1"], retain=2)[:2]
    center_tasks = [
        {
            "task_id": f"CENTER_STRESS_T{trial_index:02d}_C{center_index:02d}_M{imputation:02d}",
            "partition_id": partition["partition_id"],
            "imputation": imputation,
            "family": "GBM_COX",
            "selected_parents": selected,
            "parameters": {
                **_engine_parameters("GBM_COX", candidate["parameters"]),
                "locked_trees": candidate["selected_trees_median"],
            },
            "seed": spec["seed"] + 80_000 + trial_index * 1_000 + center_index * 100 + imputation,
        }
        for trial_index, candidate in enumerate(center_candidates, start=1)
        for center_index, partition in enumerate(centers, start=1)
        for imputation in range(1, 6)
    ]
    center_evaluated = _evaluate_r_prediction_batch(
        spec, registered, center_tasks, scratch, repo_root
    )
    _accumulate_registered_evaluations(inner_accumulator, center_evaluated)
    center_scoring_context = _trial_scoring_context(centers)
    trace["CENTER_STRESS"] = []
    for trial_index, candidate in enumerate(center_candidates):
        values = center_evaluated[trial_index * 25 : (trial_index + 1) * 25]
        trace["CENTER_STRESS"].append(
            {
                **candidate,
                "stage_id": "CENTER_STRESS",
                **_trial_evaluation_summary(values, center_scoring_context, 5),
            }
        )
    final_parameters = {
        **_engine_parameters("GBM_COX", winner["parameters"]),
        "locked_trees": winner["selected_trees_median"],
    }
    final_tasks = [
        {
            "task_id": f"FINAL_OUTER_M{imputation:02d}",
            "partition_id": outer[0]["partition_id"],
            "imputation": imputation,
            "family": "GBM_COX",
            "selected_parents": selected,
            "parameters": final_parameters,
            "prediction_horizons": spec["monthly_fit_horizons"],
            "seed": spec["seed"] + imputation,
        }
        for imputation in range(1, 21)
    ]
    final = _run_r_prediction_batch(
        spec, registered, final_tasks, scratch, repo_root
    )
    evaluation_units = sum(
        row["evaluation_units"] for rows in trace.values() for row in rows
    ) + 20
    _require(
        evaluation_units == spec["search_budget"]["standard_outer_units"],
        "F2_GBM_STANDARD_OUTER_BUDGET_INVALID",
    )
    return _build_registered_model_result(
        spec,
        registered,
        final,
        selector=spec["selector_from_dependency"],
        search_trace=trace,
        search_evaluation_unit_count=evaluation_units,
        selected_spec={
            "family": "GBM_COX",
            "candidate_id": winner["candidate_id"],
            "parameters": winner["parameters"],
            "selected_trees": winner["selected_trees_median"],
            "selection_metric": "IBS_0_24",
            "selection_stage": "S3B2",
        },
        execution_rows=_registered_stopping_execution_rows(
            registered, inner_accumulator, stop_accumulator
        ),
    )


def _finite_tree(value: Any) -> bool:
    if isinstance(value, bool) or value is None or isinstance(value, (str, int)):
        return True
    if isinstance(value, float):
        return math.isfinite(value)
    if isinstance(value, list):
        return all(_finite_tree(item) for item in value)
    if isinstance(value, dict):
        return all(isinstance(key, str) and _finite_tree(item) for key, item in value.items())
    return False


def _finalize_model_result(result: dict[str, Any], spec: dict[str, Any]) -> dict[str, Any]:
    _require(_finite_tree(result), "F2_MODEL_RESULT_NONFINITE")
    model_input = validate_expected_model_input(result.get("model_input"))
    _require(
        result.get("artifact_kind") == "F2_MODEL_DEVELOPMENT"
        and result.get("status") == "PASS"
        and result.get("fold") == spec["fold"]
        and result.get("heldout_center") == spec["heldout_center"]
        and result.get("family") == spec["family"]
        and result.get("backend") == spec["backend"]
        and result.get("threads") == spec["threads"]
        and result.get("pool_workers") == spec["pool_workers"]
        and result.get("engine_threads") == spec["engine_threads"]
        and result.get("retained_model_binary_count") == 0
        and result.get("heldout_outcome_read_count_for_selection") == 0
        and result.get("typed_terminal") == "PASS",
        "F2_MODEL_RESULT_CONTRACT_INVALID",
    )
    _require(
        model_input["fold"] == spec["fold"]
        and model_input["lineage"] == result.get("lineage"),
        "F2_MODEL_INPUT_RESULT_BINDING_INVALID",
    )
    row_universe = result.get("row_universe")
    _require(
        isinstance(row_universe, dict)
        and row_universe.get("training_count", 0) > 0
        and row_universe.get("heldout_count", 0) > 0
        and row_universe.get("overlap_count") == 0
        and _HEX64.fullmatch(str(row_universe.get("training_ids_sha256", ""))) is not None
        and _HEX64.fullmatch(str(row_universe.get("heldout_ids_sha256", ""))) is not None,
        "F2_MODEL_ROW_UNIVERSE_INVALID",
    )
    predictions = result.get("predictions")
    horizons = result.get("prediction_horizons")
    _require(
        isinstance(predictions, list)
        and len(predictions) == row_universe["heldout_count"]
        and isinstance(horizons, list)
        and horizons == spec["horizons"],
        "F2_MODEL_PREDICTION_DENOMINATOR_INVALID",
    )
    patient_ids: list[str] = []
    for row in predictions:
        _require(
            isinstance(row, dict)
            and set(row) == {"Patient_ID", "survival"}
            and isinstance(row["Patient_ID"], str)
            and row["Patient_ID"]
            and isinstance(row["survival"], list)
            and len(row["survival"]) == len(horizons)
            and all(isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value) and 0 <= value <= 1 for value in row["survival"])
            and all(left + 1e-10 >= right for left, right in zip(row["survival"], row["survival"][1:])),
            "F2_MODEL_PREDICTION_INVALID",
        )
        patient_ids.append(row["Patient_ID"])
    _require(len(set(patient_ids)) == len(patient_ids) and _sha(patient_ids) == row_universe["heldout_ids_sha256"], "F2_MODEL_PREDICTION_ROW_IDENTITY_INVALID")
    monthly_oof = result.get("monthly_oof")
    _require(
        isinstance(monthly_oof, dict)
        and set(monthly_oof)
        == {"schema_version", "classification", "horizons", "predictions"}
        and monthly_oof.get("schema_version") == "MONTHLY_OOF_V1"
        and monthly_oof.get("classification") == "PRIVATE_SCIENCE"
        and monthly_oof.get("horizons") == spec["monthly_oof_horizons"]
        and isinstance(monthly_oof.get("predictions"), list)
        and len(monthly_oof["predictions"]) == len(predictions),
        "F2_MONTHLY_OOF_CONTRACT_INVALID",
    )
    monthly_matrix: list[list[float]] = []
    projection_indices = [
        spec["monthly_oof_horizons"].index(value) for value in horizons
    ]
    for monthly_row, registered_row in zip(
        monthly_oof["predictions"], predictions, strict=True
    ):
        _require(
            isinstance(monthly_row, dict)
            and set(monthly_row) == {"Patient_ID", "survival"}
            and monthly_row.get("Patient_ID") == registered_row["Patient_ID"]
            and isinstance(monthly_row.get("survival"), list)
            and len(monthly_row["survival"]) == 37
            and monthly_row["survival"][0] == 1.0
            and all(
                isinstance(value, (int, float))
                and not isinstance(value, bool)
                and math.isfinite(value)
                and 0 <= value <= 1
                for value in monthly_row["survival"]
            )
            and all(
                left + 1e-10 >= right
                for left, right in zip(
                    monthly_row["survival"], monthly_row["survival"][1:]
                )
            )
            and [monthly_row["survival"][index] for index in projection_indices]
            == registered_row["survival"],
            "F2_MONTHLY_OOF_PROJECTION_MISMATCH",
        )
        monthly_matrix.append(monthly_row["survival"])
    _require(
        result.get("monthly_oof_sha256")
        == _seal_prediction_matrix(
            patient_ids, monthly_matrix, spec["monthly_oof_horizons"]
        )["sha256"],
        "F2_MONTHLY_OOF_IDENTITY_INVALID",
    )
    selector = result.get("selector_evidence")
    _require(
        isinstance(selector, dict)
        and selector.get("selector_contract_sha256") == _sha(spec["selector_contract"])
        and selector.get("selected_parent_count") == len(selector.get("selected_parents", []))
        and selector.get("selected_parent_sha256") == _sha(selector.get("selected_parents"))
        and "AST_ALT" in selector.get("selected_parents", [])
        and selector.get("heldout_outcome_read_count") == 0,
        "F2_SELECTOR_EVIDENCE_INVALID",
    )
    result["row_universe_sha256"] = _sha(row_universe)
    result["selector_evidence_sha256"] = _selector_evidence_science_identity(selector)
    result["search_trace_sha256"] = _sha(result.get("search_trace"))
    result["selected_spec_sha256"] = _sha(result.get("selected_spec"))
    result["prediction_sha256"] = _seal_prediction_matrix(
        patient_ids,
        [row["survival"] for row in predictions],
        horizons,
    )["sha256"]
    result["stopping_and_convergence_sha256"] = _sha(result.get("stopping_and_convergence"))
    result["numeric_qc_sha256"] = _sha(result.get("numeric_qc"))
    if spec["family"] in {"XGBOOST_COX", "COXTIME_SET_A"}:
        _require(
            isinstance(result.get("execution_graph"), dict),
            "F2_PYTHON_EXECUTION_GRAPH_MISSING",
        )
        result["execution_graph_sha256"] = _sha(result["execution_graph"])
    else:
        _require(
            "execution_graph" not in result,
            "F2_PYTHON_EXECUTION_GRAPH_SCOPE_INVALID",
        )
    family_design_binding = _model_family_design_binding(
        spec["family"],
        selector,
        spec["predictors"],
    )
    result["family_design_binding"] = family_design_binding
    result["science_contract_sha256"] = _sha(
        {
            "selector": spec["selector_contract"],
            "selector_sensitivity": (
                spec["selector_sensitivity_contract"]
                if spec["family"] == "ELASTIC_NET_COX"
                else None
            ),
            "candidate_sequence": spec["candidate_sequence"],
            "multifidelity": spec["multifidelity"],
            "trial_scoring": spec["trial_scoring"],
            "model_seed_policy": spec["model_seed_policy"],
            "search_space": spec["search_space"],
            "search_budget": spec["search_budget"],
            "coxtime": spec["coxtime"],
            "fpm": spec["fpm"],
            "family_design_binding": family_design_binding,
            "monthly_oof": spec["monthly_oof_contract"],
        }
    )
    return result


def _fold_cache_tree_identity(root: Path) -> str:
    """Reuse verified bytes while the complete no-follow file identity is unchanged."""

    records = []
    for path in sorted(root.rglob("*")):
        if path == root / "cache.json":
            continue
        metadata = path.lstat()
        relative = path.relative_to(root).as_posix()
        if stat.S_ISDIR(metadata.st_mode):
            records.append([relative, "DIRECTORY"])
        else:
            _require(
                stat.S_ISREG(metadata.st_mode)
                and metadata.st_nlink == 1
                and not metadata.st_mode & 0o222,
                "F2_SPLIT_CACHE_MEMBER_INVALID",
            )
            records.append([
                relative, metadata.st_dev, metadata.st_ino, metadata.st_size,
                metadata.st_mtime_ns, metadata.st_ctime_ns,
            ])
    return _sha(records)


def _cached_fold_assets(
    capsule_path: Path,
    capsule: dict[str, Any],
    request: Mapping[str, Any],
    fold: int,
    binding_contract: dict[str, Any],
    frozen_csv: bytes,
    cache_root: Path,
) -> tuple[dict[str, Any], dict[str, Any], dict[str, Any], dict[str, Any]]:
    """One immutable materialized F1 split library per fold and source/input pair."""

    binding_sha256 = _sha(binding_contract)
    response_sha256 = sha256_bytes(frozen_csv)
    identity = _sha({
        "source": request["identities"]["source"],
        "input": request["identities"]["input"],
        "fold": fold,
        "binding_contract_sha256": binding_sha256,
        "response_sha256": response_sha256,
    })
    cache_root.mkdir(mode=0o700, parents=True, exist_ok=True)
    root = cache_root / identity
    if not root.exists():
        staging = cache_root / f".{identity}.staging"
        _require(not staging.exists(), "F2_SPLIT_CACHE_PREPARATION_INCOMPLETE")
        staging.mkdir(mode=0o700)
        summary, fold_input, lineage = admitted_f1_fold(
            capsule_path, capsule, fold, staging, binding_contract
        )
        registered = _materialize_registered_partitions(
            fold_input, binding_contract, frozen_csv, fold,
            staging / "registered-inputs",
        )
        projected = {**registered, "partitions": [], "diagnostic_partitions": []}
        for field in ("partitions", "diagnostic_partitions"):
            for partition in registered[field]:
                response = {key: value for key, value in partition["evaluation_response"].items() if key != "private_bytes"}
                projected[field].append({
                    **partition,
                    "covariates": {
                        **partition["covariates"],
                        "input_dir": Path(partition["covariates"]["input_dir"]).relative_to(staging).as_posix(),
                    },
                    "fit_response": {
                        **partition["fit_response"],
                        "path": Path(partition["fit_response"]["path"]).relative_to(staging).as_posix(),
                    },
                    "evaluation_response": response,
                })
        # These are newly extracted temporary copies, not input/result artifacts.
        for redundant in (
            staging / f"mice-fold-{fold}-result",
            staging / f"mice-fold-{fold}-payload",
            staging / "registered-inputs/view-sources",
        ):
            shutil.rmtree(redundant)
        for path in staging.rglob("*"):
            if path.is_file():
                path.chmod(0o400)
                with path.open("rb") as source:
                    os.fsync(source.fileno())
        for path in [*sorted((item for item in staging.rglob("*") if item.is_dir()), reverse=True), staging]:
            descriptor = os.open(path, os.O_RDONLY | os.O_DIRECTORY)
            try:
                os.fsync(descriptor)
            finally:
                os.close(descriptor)
        manifest = {
            "kind": "PADML_F2_IMMUTABLE_SPLIT_CACHE",
            "identity": identity,
            "binding_contract_sha256": binding_sha256,
            "response_sha256": response_sha256,
            "tree_identity": _fold_cache_tree_identity(staging),
            "summary": summary,
            "lineage": lineage,
            "registered": projected,
            "library_index": fold_input["library_index"],
        }
        manifest["manifest_sha256"] = _sha(manifest)
        with (staging / "cache.json").open("xb") as output:
            output.write(canonical_json_bytes(manifest))
            output.flush()
            os.fsync(output.fileno())
        (staging / "cache.json").chmod(0o400)
        os.rename(staging, root)
        descriptor = os.open(cache_root, os.O_RDONLY | os.O_DIRECTORY)
        try:
            os.fsync(descriptor)
        finally:
            os.close(descriptor)
    _require(root.is_dir() and not root.is_symlink(), "F2_SPLIT_CACHE_ROOT_INVALID")
    manifest_path = root / "cache.json"
    _require(manifest_path.is_file() and not manifest_path.is_symlink(), "F2_SPLIT_CACHE_MANIFEST_INVALID")
    raw = manifest_path.read_bytes()
    manifest = strict_json_bytes(raw, "F2_SPLIT_CACHE")
    _require(
        canonical_json_bytes(manifest) == raw
        and manifest.get("kind") == "PADML_F2_IMMUTABLE_SPLIT_CACHE"
        and manifest.get("identity") == identity
        and manifest.get("binding_contract_sha256") == binding_sha256
        and manifest.get("response_sha256") == response_sha256
        and manifest.get("manifest_sha256")
        == _sha({key: value for key, value in manifest.items() if key != "manifest_sha256"})
        and manifest.get("tree_identity") == _fold_cache_tree_identity(root),
        "F2_SPLIT_CACHE_IDENTITY_CHANGED",
    )
    registered = manifest["registered"]
    fields, by_id = _response_rows(frozen_csv)
    for partition in [*registered["partitions"], *registered["diagnostic_partitions"]]:
        response = _write_response_subset(fields, by_id, partition["evaluation_ids"], None)
        _require(
            {key: value for key, value in response.items() if key != "private_bytes"}
            == partition["evaluation_response"],
            "F2_SPLIT_CACHE_RESPONSE_IDENTITY_CHANGED",
        )
        partition["evaluation_response"] = response
        for owner, field in ((partition["covariates"], "input_dir"), (partition["fit_response"], "path")):
            relative = Path(owner[field])
            _require(
                not relative.is_absolute() and ".." not in relative.parts,
                "F2_SPLIT_CACHE_PATH_INVALID",
            )
            owner[field] = str(root / relative)
    return manifest["summary"], registered, manifest["lineage"], manifest["library_index"]


def _run_sensitivity_from_primary(spec: dict[str, Any], registered: dict[str, Any],
                                  model_input: Mapping[str, Any], primary: dict[str, Any],
                                  source: Mapping[str, Any], scratch: Path, repo_root: Path) -> dict[str, Any]:
    from .capsule import primary_reuse_receipt, selector_primary_projection

    _require(spec["family"] == "ELASTIC_NET_COX" and _sha(primary) == source["primary_sha256"]
             and primary == selector_primary_projection(primary), "F2_SENSITIVITY_ONLY_PRIMARY_INVALID")
    outer = [row for row in registered["partitions"] if row["kind"] == "OUTER"]
    _require(len(outer) == 1, "F2_SELECTOR_SENSITIVITY_OUTER_INVALID")
    selector = dict(primary["selector_evidence"])
    selector["sensitivity_evidence"] = _run_selector_sensitivity(
        spec, registered, model_input, outer[0]["partition_id"], scratch, repo_root,
    )
    selector["selector_execution_identity_sha256"] = _selector_evidence_execution_identity(selector)
    result = {**primary, "selector_evidence": selector, "primary_reuse": primary_reuse_receipt(source)}
    _require(selector_primary_projection(result) == primary, "F2_SENSITIVITY_PRIMARY_WRITEBACK_FORBIDDEN")
    return result


def execute_model(
    capsule_path: Path,
    capsule: dict[str, Any],
    request: dict[str, Any],
    scratch: Path,
    selector: dict[str, Any] | None = None,
    *,
    cache_root: Path,
    checkpoint_root: Path,
    retained_fpm: Mapping[str, bytes] | None = None,
) -> dict[str, Any]:
    repo_root = Path(__file__).resolve().parent
    coordinates = {row["axis"]: row["value"] for row in request["plan"]["coordinates"]}
    fold = coordinates.get("outer_fold")
    primary_source = capsule["manifest"].get("selector_primary_reuse", {}).get(request["unit_id"])
    primary = None
    if primary_source is not None:
        from .capsule import load_selector_primary

        primary = load_selector_primary(capsule_path.parent / "selector-primary" / f"{request['unit_id']}.zip",
                                        primary_source, request, capsule["approved_registry"]["model_inputs"][fold - 1])
    search_reuse = None
    source = capsule["manifest"].get("selector_search_reuse", {}).get(request["unit_id"])
    _require(primary_source is None or source is None, "F2_SELECTOR_REUSE_MODE_CONFLICT")
    if source is not None:
        from .capsule import load_selector_search

        search_reuse = (source, load_selector_search(
            capsule_path.parent / "selector-search" / f"{request['unit_id']}.zip",
            source, request, capsule["approved_registry"]["model_inputs"][fold - 1],
        ))
    binding_contract, frozen_csv, frozen_lineage = admitted_f1_frozen_data(
        capsule_path, capsule, scratch
    )
    summary, registered, lineage, _ = _cached_fold_assets(
        capsule_path, capsule, request, fold, binding_contract, frozen_csv, cache_root
    )
    lineage = {
        **lineage,
        **frozen_lineage,
        "f1_registered_partition_identity": registered["identity"],
    }
    predictors = predictor_contract(repo_root, capsule["authority_slice"])
    model_input = _expected_model_input(summary, lineage, registered, predictors)
    approved_registry = capsule.get("approved_registry")
    expected_inputs = (
        approved_registry.get("model_inputs")
        if isinstance(approved_registry, dict)
        else None
    )
    _require(
        isinstance(expected_inputs, list)
        and len(expected_inputs) == 6
        and expected_inputs[fold - 1] == model_input,
        "F2_MODEL_INPUT_CAPSULE_BINDING_INVALID",
    )
    spec = compile_model_spec(request, capsule, lineage, repo_root, selector)
    if primary is not None:
        result = _run_sensitivity_from_primary(spec, registered, model_input, primary, primary_source, scratch, repo_root)
    elif spec["family"] == "ELASTIC_NET_COX":
        result = _run_r_registered_elastic(
            spec, registered, model_input, scratch, repo_root, checkpoint_root,
            search_reuse=search_reuse,
        )
    elif spec["family"] == "COX_PH":
        result = _run_r_registered_cox_ph(spec, registered, scratch, repo_root)
    elif spec["family"] == "FPM_TVC_SET_A":
        result = _run_r_registered_fpm(spec, registered, scratch, repo_root, retained_fpm=retained_fpm)
    elif spec["family"] == "RSF":
        result = _run_r_registered_rsf(spec, registered, scratch, repo_root)
    elif spec["family"] == "GBM_COX":
        result = _run_r_registered_gbm(spec, registered, scratch, repo_root)
    else:
        result = _run_python_model(spec, registered, scratch)
    result["model_input"] = model_input
    result = _finalize_model_result(result, spec)
    result["f1_library_summary_sha256"] = _sha(summary)
    if primary_source is not None:
        from .capsule import selector_primary_projection

        _require(_sha(selector_primary_projection(result)) == primary_source["primary_sha256"],
                 "F2_SENSITIVITY_PRIMARY_WRITEBACK_FORBIDDEN")
    return result


def _run_python_model(
    spec: dict[str, Any], registered: dict[str, Any], scratch: Path
) -> dict[str, Any]:
    # Imports are intentionally scoped to the Python-family execution boundary.
    try:
        import numpy as np  # type: ignore
        import pandas as pd  # type: ignore
    except ImportError as exc:
        raise ContractError("F2_PYTHON_MODEL_CAPABILITY_UNAVAILABLE") from exc
    _require(spec["family"] in {"XGBOOST_COX", "COXTIME_SET_A"}, "F2_PYTHON_FAMILY_INVALID")
    if spec["family"] == "XGBOOST_COX":
        try:
            import xgboost as xgb  # type: ignore
        except ImportError as exc:
            raise ContractError("F2_XGBOOST_CAPABILITY_UNAVAILABLE") from exc
        return _run_python_registered_xgboost(
            spec, registered, scratch, xgb, np, pd
        )
    try:
        models, torch, tt = _coxtime_native()
    except ImportError as exc:
        raise ContractError("F2_COXTIME_CAPABILITY_UNAVAILABLE") from exc
    return _run_python_registered_coxtime(
        spec, registered, scratch, (models, torch, tt), np, pd
    )






def _prepare_python_design(spec: dict[str, Any], frames: list[Any], pd: Any) -> tuple[list[Any], list[str]]:
    selected = spec["selector_from_dependency"]["selected_parents"]
    metadata = {row["name"]: row for row in spec["predictors"]["variables"]}
    designs: list[Any] = []
    for source in frames:
        data = source.copy()
        _require(
            spec["outcome"] not in data.columns
            and spec["time"] not in data.columns,
            "F2_PYTHON_APPLICATION_RESPONSE_VISIBLE",
        )
        for name in selected:
            _require(name in data.columns and name in metadata, f"F2_PYTHON_PREDICTOR_MISSING:{name}")
            row = metadata[name]
            if row["type"] in {"binary", "ordered", "unordered"}:
                levels = _locked_categorical_levels(row)
                _require(data[name].notna().all(), "F2_PYTHON_FACTOR_LEVEL_INVALID")
                observed = data[name].astype(str)
                _require(
                    set(observed.unique()).issubset(levels),
                    "F2_PYTHON_FACTOR_LEVEL_INVALID",
                )
                data[name] = pd.Categorical(observed, categories=levels, ordered=row["type"] == "ordered")
            else:
                data[name] = pd.to_numeric(data[name], errors="raise")
        designs.append(pd.get_dummies(data[selected], columns=[name for name in selected if metadata[name]["type"] in {"binary", "ordered", "unordered"}], drop_first=False, dtype=float))
    columns = sorted({column for design in designs for column in design.columns}, key=lambda value: value.encode("utf-8"))
    aligned = [design.reindex(columns=columns, fill_value=0.0).astype(float) for design in designs]
    expected_map = _expected_family_parent_column_map(
        selected,
        spec["family"],
        spec["predictors"],
        None,
    )
    expected_columns = sorted(
        [column for row in expected_map for column in row["columns"]],
        key=lambda value: value.encode("utf-8"),
    )
    _require(
        columns == expected_columns
        and all(
            design.shape[1] == aligned[0].shape[1]
            and np_isfinite(design.to_numpy())
            for design in aligned
        ),
        "F2_PYTHON_DESIGN_INVALID",
    )
    return aligned, columns


def np_isfinite(values: Any) -> bool:
    try:
        import numpy as np  # type: ignore
    except ImportError:
        return False
    return bool(np.isfinite(values).all())


_PYTHON_PREPARED = OrderedDict()
_PYTHON_PREPARED_BYTES = 0
_PYTHON_PREPARED_LIMIT = 64 * 1024**2


def _release_python_prepared(live_scopes):
    """Drop ended shared-pool stages; retain every still-active family's LRU."""
    global _PYTHON_PREPARED_BYTES
    removed = 0
    for key in list(_PYTHON_PREPARED):
        if key[0] not in live_scopes:
            _, size = _PYTHON_PREPARED.pop(key)
            _PYTHON_PREPARED_BYTES -= size
            removed += size
    return removed


def _load_python_registered_partition(
    spec: dict[str, Any],
    registered: dict[str, Any],
    partition_id: str,
    pd: Any,
    np: Any,
    imputation_indices: list[int] | None = None,
) -> dict[str, Any]:
    if "projected_partition_ids" in registered:
        _require(
            registered.get("projected_partition_ids") == [partition_id]
            and registered.get("projected_partition_count") == 1
            and not _contains_key(registered, "evaluation_response"),
            "F2_ENGINE_PARTITION_SCOPE_INVALID",
        )
        projected = registered
    else:
        projected = _engine_registered_partitions(registered, {partition_id})
    rows = [*projected["partitions"], *projected["diagnostic_partitions"]]
    _require(len(rows) == 1, "F2_PYTHON_REGISTERED_PARTITION_INVALID")
    partition = rows[0]
    application_ids = list(partition["application_ids"])
    indices = list(range(1, 21)) if imputation_indices is None else list(imputation_indices)
    _require(
        indices
        and len(indices) == len(set(indices))
        and all(type(index) is int and 1 <= index <= 20 for index in indices),
        "F2_PYTHON_IMPUTATION_SET_INVALID",
    )
    global _PYTHON_PREPARED_BYTES
    selected = spec["selector_from_dependency"]["selected_parents"]
    # Source byte qualification belongs to admission. Stamps invalidate this
    # short-lived worker cache without another full SHA at every candidate.
    paths = [Path(partition["covariates"]["input_dir"]) / f"imp{i:02d}.csv" for i in indices]
    response = partition["fit_response"]
    if "path" in response:
        paths.append(Path(response["path"]))
    stamps = [(str(p), p.stat().st_dev, p.stat().st_ino, p.stat().st_size,
               p.stat().st_mtime_ns, p.stat().st_ctime_ns) for p in paths]
    members = [m for m in partition["covariates"]["members"] if m["name"] in {f"imp{i:02d}.csv" for i in indices}]
    cache_key = _sha({"application_ids": application_ids, "fit_ids": partition["fit_ids"],
        "evaluation_ids": partition["evaluation_ids"], "members": members,
        "response": {k: v for k, v in response.items() if k not in {"path", "private_bytes"}},
        "variables": selected, "predictors": spec["predictors"]["sha256"],
        "family": spec["family"], "indices": indices, "stamps": stamps})
    from .runtime import _READY_PREPARATION_SCOPE
    cache_key = (_READY_PREPARATION_SCOPE, cache_key)
    cached = _PYTHON_PREPARED.get(cache_key)
    if cached is not None:
        _PYTHON_PREPARED.move_to_end(cache_key)
        return {**cached[0], "partition": partition}
    frames = [
        pd.read_csv(
            Path(partition["covariates"]["input_dir"]) / f"imp{index:02d}.csv",
            dtype={"Patient_ID": str},
            # "None" is a locked factor level, not a missing-value token.
            # Empty fields remain missing; downstream validation rejects them.
            keep_default_na=False,
            na_values=[""],
        )
        for index in indices
    ]
    _require(
        all(
            frame["Patient_ID"].astype(str).tolist() == application_ids
            for frame in frames
        ),
        "F2_PYTHON_REGISTERED_ROW_ORDER_DRIFT",
    )
    designs, columns = _prepare_python_design(spec, frames, pd)
    positions = {patient_id: index for index, patient_id in enumerate(application_ids)}
    fit_ids = list(partition["fit_ids"])
    evaluation_ids = list(partition["evaluation_ids"])
    _require(
        len(positions) == len(application_ids)
        and all(patient_id in positions for patient_id in [*fit_ids, *evaluation_ids]),
        "F2_PYTHON_REGISTERED_ROW_SET_INVALID",
    )
    fit_index = np.asarray([positions[patient_id] for patient_id in fit_ids], dtype=int)
    evaluation_index = np.asarray(
        [positions[patient_id] for patient_id in evaluation_ids], dtype=int
    )
    fit_time, fit_event = _response_arrays(partition["fit_response"], fit_ids)
    prepared = {
        "partition": partition,
        "columns": columns,
        "fit_ids": fit_ids,
        "evaluation_ids": evaluation_ids,
        "fit_time": np.asarray(fit_time, dtype=float),
        "fit_event": np.asarray(fit_event, dtype=int),
        "imputation_indices": indices,
        "fit_designs": [
            design.to_numpy(dtype=float)[fit_index] for design in designs
        ],
        "evaluation_designs": [
            design.to_numpy(dtype=float)[evaluation_index] for design in designs
        ],
    }

    arrays = [prepared["fit_time"], prepared["fit_event"], *prepared["fit_designs"], *prepared["evaluation_designs"]]
    for array_value in arrays:
        array_value.setflags(write=False)
    size = sum(v.nbytes for v in arrays)
    while _PYTHON_PREPARED and _PYTHON_PREPARED_BYTES + size > _PYTHON_PREPARED_LIMIT:
        _, (_, removed) = _PYTHON_PREPARED.popitem(last=False)
        _PYTHON_PREPARED_BYTES -= removed
    if size <= _PYTHON_PREPARED_LIMIT:
        _PYTHON_PREPARED[cache_key] = (prepared, size)
        _PYTHON_PREPARED_BYTES += size
    return prepared


def _breslow(time: Any, event: Any, risk: Any, np: Any) -> tuple[Any, Any]:
    time, event, risk = np.asarray(time), np.asarray(event), np.asarray(risk)
    if np.issubdtype(risk.dtype, np.floating) and risk.dtype.itemsize < 8:
        # XGBoost returns float32 margins/risks. A wider reverse cumulative sum
        # changes its original np.sum rounding beyond the frozen tolerance.
        # Keep that native reduction; only float64 inputs use the qualified fast path.
        event_times = np.unique(time[event == 1])
        increments = np.asarray([np.sum((time == value) & (event == 1)) /
            np.sum(risk[time >= value]) for value in event_times], dtype=float)
        _require(bool(np.isfinite(increments).all() and (increments >= 0).all()),
                 "F2_BRESLOW_BASELINE_INVALID")
        return event_times, np.cumsum(increments)
    risk = np.asarray(risk, dtype=float)
    order = np.argsort(time, kind="stable")
    ordered_time = time[order]
    starts = np.r_[0, np.flatnonzero(ordered_time[1:] != ordered_time[:-1]) + 1]
    deaths = np.add.reduceat((event[order] == 1).astype(int), starts)
    has_events = deaths > 0
    denominators = np.cumsum(risk[order][::-1], dtype=np.longdouble)[::-1][starts][has_events]
    increments = np.asarray(deaths[has_events] / denominators, dtype=float)
    _require(bool(np.isfinite(increments).all() and (increments >= 0).all()), "F2_BRESLOW_BASELINE_INVALID")
    return ordered_time[starts][has_events], np.cumsum(increments)


def _survival_from_risk(event_times: Any, cumulative: Any, risk: Any, horizons: list[int], np: Any) -> Any:
    hazards = []
    for horizon in horizons:
        index = np.searchsorted(event_times, horizon, side="right") - 1
        hazards.append(0.0 if index < 0 else float(cumulative[index]))
    return np.exp(-np.outer(risk, np.asarray(hazards, dtype=float)))


def _xgb_grouped_breslow_objective(
    dtrain: Any, np: Any, *, time: Any, event: Any,
) -> tuple[Any, dict[str, Any]]:
    """Unnormalised Cox loss derivatives; cache only the fixed time grouping.

    A shared shift of all margins cancels from the partial likelihood. Tiny
    Hessian cancellation cases are evaluated as a sum of nonnegative terms,
    never clipped, and every numerical failure remains an error.
    """
    original_time = np.asarray(time, dtype="float64").copy()
    original_event = np.asarray(event).copy()
    labels = np.asarray(dtrain.get_label())
    weights = np.asarray(dtrain.get_weight(), dtype="float64")
    _require(
        original_time.ndim == 1 and len(original_time) > 0
        and original_time.shape == original_event.shape == labels.shape
        and bool(np.isfinite(original_time).all() and (original_time > 0).all())
        and bool(np.isin(original_event, [0, 1]).all() and (original_event == 1).any())
        and bool(np.array_equal(labels, np.where(original_event == 1, original_time,
                                                 -original_time).astype(labels.dtype)))
        and (weights.size == 0 or weights.shape == labels.shape and bool((weights == 1).all())),
        "F2_XGBOOST_COX_OBJECTIVE_INPUT_INVALID",
    )
    # DMatrix labels are float32. Never reconstruct event-time groups from them.
    order = np.argsort(original_time, kind="stable")
    times = original_time[order]
    events = original_event[order].astype("float64")
    starts = np.r_[0, np.flatnonzero(times[1:] != times[:-1]) + 1]
    lengths = np.diff(np.r_[starts, len(labels)])
    groups = np.repeat(np.arange(len(starts)), lengths)
    deaths = np.add.reduceat(events, starts)
    health = {"implementation": "GROUPED_BRESLOW_FLOAT64_TIME_V1", "gradient_evaluations": 0,
              "training_rows": len(labels), "event_time_groups": int(np.count_nonzero(deaths))}

    def objective(raw_margin: Any, matrix: Any) -> tuple[Any, Any]:
        margin = np.asarray(raw_margin, dtype="float64")
        _require(matrix is dtrain and margin.shape == labels.shape
                 and bool(np.isfinite(margin).all()), "F2_XGBOOST_COX_RAW_MARGIN_INVALID")
        try:
            with np.errstate(over="raise", invalid="raise", divide="raise"):
                risk = np.exp(margin[order] - np.max(margin))
                _require(bool(np.isfinite(risk).all() and (risk > 0).all()),
                         "F2_XGBOOST_COX_RISK_INVALID")
                denominator = np.cumsum(risk[::-1], dtype="float64")[::-1][starts]
                _require(bool(np.isfinite(denominator).all() and (denominator > 0).all()),
                         "F2_XGBOOST_COX_RISK_SET_INVALID")
                terms = deaths / denominator
                first = np.cumsum(terms, dtype="float64")[groups]
                second = np.cumsum(terms / denominator, dtype="float64")[groups]
                gradient_sorted = risk * first - events
                hessian_sorted = risk * (first - risk * second)
                uncertain = (first > 0) & (
                    hessian_sorted <= 64 * np.finfo("float64").eps * np.abs(risk * first))
                for index in np.flatnonzero(uncertain):
                    probability = risk[index] / denominator[:groups[index] + 1]
                    _require(bool(((probability >= 0) & (probability <= 1)).all()),
                             "F2_XGBOOST_COX_RISK_SET_INVALID")
                    hessian_sorted[index] = math.fsum(
                        (deaths[:groups[index] + 1] * probability * (1 - probability)).tolist())
        except FloatingPointError as exc:
            raise ContractError("F2_XGBOOST_COX_OBJECTIVE_NONFINITE") from exc
        _require(bool(np.isfinite(gradient_sorted).all() and np.isfinite(hessian_sorted).all()
                      and (hessian_sorted >= 0).all()), "F2_XGBOOST_COX_DERIVATIVE_INVALID")
        gradient = np.empty_like(margin)
        hessian = np.empty_like(margin)
        gradient[order], hessian[order] = gradient_sorted, hessian_sorted
        health["gradient_evaluations"] += 1
        return gradient, hessian

    return objective, health


def _xgb_prepared_dmatrix(engine, design, np, *, time=None, event=None):
    """Lend only an already-qualified worker preparation's immutable matrix.

    The existing stage LRU owns lifetime and budget; no disk cache or model,
    objective state, STOP result, seed, or parameter is shared here.
    """
    global _PYTHON_PREPARED_BYTES
    owner = key = slot = None
    if not design.flags.writeable:
        for candidate, (prepared, _) in reversed(_PYTHON_PREPARED.items()):
            if time is not None and event is not None:
                if prepared.get("fit_time") is not time or prepared.get("fit_event") is not event:
                    continue
                arrays, role = prepared.get("fit_designs", []), "fit"
            else:
                arrays, role = prepared.get("evaluation_designs", []), "evaluation"
            index = next((i for i, value in enumerate(arrays) if value is design), None)
            if index is not None:
                key, owner = candidate, prepared
                slot = (role, index, id(engine.DMatrix))
                break
    if owner is not None:
        cached = owner.get("_xgb_dmatrices", {}).get(slot)
        if cached is not None:
            _PYTHON_PREPARED.move_to_end(key)
            return cached
    labels = None if time is None else np.where(event == 1, time, -time)
    matrix = engine.DMatrix(design, **({} if labels is None else {"label": labels}))
    if owner is not None:
        # Conservative retained-input charge: CSR plus CPU quantized/index
        # representations and row metadata. Fit workspaces remain stage-owned.
        charge = 4 * design.nbytes + 32 * (len(design) + 1)
        old_size = _PYTHON_PREPARED[key][1]
        if old_size + charge <= _PYTHON_PREPARED_LIMIT:
            _PYTHON_PREPARED.move_to_end(key)
            while _PYTHON_PREPARED_BYTES + charge > _PYTHON_PREPARED_LIMIT:
                _, (_, removed) = _PYTHON_PREPARED.popitem(last=False)
                _PYTHON_PREPARED_BYTES -= removed
            owner.setdefault("_xgb_dmatrices", {})[slot] = matrix
            _PYTHON_PREPARED[key] = (owner, old_size + charge)
            _PYTHON_PREPARED_BYTES += charge
    return matrix


def _xgb_refit_predict(
    engine: Any,
    parameters: dict[str, Any],
    x_train: Any,
    train_time: Any,
    train_event: Any,
    x_test: Any,
    locked_rounds: int,
    seed: int,
    backend: str,
    horizons: list[int],
    np: Any,
    *, native_capture: Any = None,
) -> dict[str, Any]:
    """Fit the sealed XGBoost specification without another stopping decision."""

    _require(
        backend == "CPU"
        and len(x_train) > 10
        and len(x_test) > 0
        and 1 <= locked_rounds <= int(parameters["max_nrounds"]),
        "F2_XGBOOST_LOCKED_REFIT_INVALID",
    )
    params = {
        "objective": "survival:cox",
        "eval_metric": "cox-nloglik",
        "eta": float(parameters["eta"]),
        "max_depth": int(parameters["max_depth"]),
        "min_child_weight": float(parameters["min_child_weight"]),
        "subsample": float(parameters["subsample"]),
        "colsample_bytree": float(parameters["colsample_bytree"]),
        "lambda": float(parameters["reg_lambda"]),
        "alpha": float(parameters["reg_alpha"]),
        "gamma": float(parameters["gamma"]),
        "tree_method": parameters["tree_method"],
        "max_bin": int(parameters["max_bin"]),
        "nthread": 1,
        "seed": seed,
        "verbosity": 0,
    }
    dfull = _xgb_prepared_dmatrix(engine, x_train, np, time=train_time, event=train_event)
    objective, objective_health = _xgb_grouped_breslow_objective(
        dfull, np, time=train_time, event=train_event)
    model = engine.train(params, dfull, num_boost_round=locked_rounds, verbose_eval=False, obj=objective)
    if native_capture is not None:
        native_capture("model", model=model, objective_health=objective_health)
    _validate_xgb_cox_objective_health(objective_health, locked_rounds, len(x_train))
    evaluation_matrix = _xgb_prepared_dmatrix(engine, x_test, np)
    train_margin = model.predict(dfull, output_margin=True)
    evaluation_margin = model.predict(evaluation_matrix, output_margin=True)
    _require(
        int(model.num_boosted_rounds()) == locked_rounds
        and len(train_margin) == len(x_train)
        and len(evaluation_margin) == len(x_test)
        and bool(np.isfinite(train_margin).all())
        and bool(np.isfinite(evaluation_margin).all()),
        "F2_XGBOOST_FIT_HEALTH_INVALID",
    )
    train_risk = np.exp(train_margin)
    test_risk = np.exp(evaluation_margin)
    _require(
        bool(
            np.isfinite(train_risk).all()
            and np.isfinite(test_risk).all()
            and (train_risk > 0).all()
            and (test_risk > 0).all()
        ),
        "F2_XGBOOST_FIT_HEALTH_INVALID",
    )
    event_times, cumulative = _breslow(train_time, train_event, train_risk, np)
    if native_capture is not None:
        native_capture("baseline", event_times=event_times, cumulative=cumulative)
    survival = _survival_from_risk(event_times, cumulative, test_risk, horizons, np)
    fit_health = _validate_python_fit_health(
        "XGBOOST_COX",
        {
            "engine": "xgboost survival:cox",
            "converged": True,
            "objective": "survival:cox",
            "cox_objective": objective_health,
            "booster_round_count": int(model.num_boosted_rounds()),
            "model_binary_sha256": sha256_bytes(
                bytes(model.save_raw(raw_format="ubj"))
            ),
            "training_margin_count": len(train_margin),
            "evaluation_margin_count": len(evaluation_margin),
        },
        locked_value=locked_rounds,
        training_count=len(x_train),
        evaluation_count=len(x_test),
    )
    return {"survival": survival, "fit_health": fit_health}


def _xgb_prediction_function_seal(
    engine: Any,
    parameters: dict[str, Any],
    partition: Mapping[str, Any],
    fit_design: Any,
    evaluation_design: Any,
    fit_time: Any,
    fit_event: Any,
    seed: int,
    backend: str,
    np: Any,
    handoff_path: Path,
) -> tuple[dict[str, Any], dict[str, Any]]:
    """Fit every round without STOP response and seal the prediction function."""

    _require(
        len(fit_design) > 10
        and len(evaluation_design) > 0
        and backend == "CPU",
        "F2_XGBOOST_REGISTERED_PARTITION_INVALID",
    )
    fit_matrix = _xgb_prepared_dmatrix(engine, fit_design, np, time=fit_time, event=fit_event)
    params = {
        "objective": "survival:cox",
        "eval_metric": "cox-nloglik",
        "eta": float(parameters["eta"]),
        "max_depth": int(parameters["max_depth"]),
        "min_child_weight": float(parameters["min_child_weight"]),
        "subsample": float(parameters["subsample"]),
        "colsample_bytree": float(parameters["colsample_bytree"]),
        "lambda": float(parameters["reg_lambda"]),
        "alpha": float(parameters["reg_alpha"]),
        "gamma": float(parameters["gamma"]),
        "tree_method": parameters["tree_method"],
        "max_bin": int(parameters["max_bin"]),
        "nthread": 1,
        "seed": seed,
        "verbosity": 0,
    }
    maximum = int(parameters["max_nrounds"])
    _require(maximum > 0, "F2_XGBOOST_ROUND_DENOMINATOR_INVALID")
    objective, objective_health = _xgb_grouped_breslow_objective(
        fit_matrix, np, time=fit_time, event=fit_event)
    booster = engine.train(
        params,
        fit_matrix,
        num_boost_round=maximum,
        verbose_eval=False,
        obj=objective,
    )
    _validate_xgb_cox_objective_health(objective_health, maximum, len(fit_design))
    raw = bytes(booster.save_raw(raw_format="ubj"))
    fit_margin = booster.predict(
        fit_matrix,
        output_margin=True,
        iteration_range=(0, maximum),
    )
    _require(
        int(booster.num_boosted_rounds()) == maximum
        and bool(raw)
        and len(fit_margin) == len(fit_design)
        and bool(np.isfinite(fit_margin).all()),
        "F2_XGBOOST_FIT_HEALTH_INVALID",
    )
    fit_bytes = np.ascontiguousarray(fit_design, dtype="float64").tobytes()
    evaluation_bytes = np.ascontiguousarray(
        evaluation_design, dtype="float64"
    ).tobytes()
    payload = {
        "schema_version": "1.0.0",
        "kind": "PADML_F2_XGBOOST_PREDICTION_FUNCTION",
        "fit_ids": list(partition["fit_ids"]),
        "evaluation_ids": list(partition["evaluation_ids"]),
        "maximum": maximum,
        "booster_sha256": sha256_bytes(raw),
        "cox_objective": objective_health,
        "design_identity": sha256_bytes(
            canonical_json_bytes(
                {
                    "fit_shape": list(fit_design.shape),
                    "fit_sha256": sha256_bytes(fit_bytes),
                    "evaluation_shape": list(evaluation_design.shape),
                    "evaluation_sha256": sha256_bytes(evaluation_bytes),
                }
            )
        ),
        "parameter_sha256": _sha(parameters),
        "fit_input_identity": _sha(
            {
                "fit_ids_sha256": _sha(list(partition["fit_ids"])),
                "fit_design_shape": list(fit_design.shape),
                "fit_design_sha256": sha256_bytes(fit_bytes),
                "fit_time_sha256": _sha(
                    [float(value) for value in fit_time]
                ),
                "fit_event_sha256": _sha(
                    [int(value) for value in fit_event]
                ),
            }
        ),
        "seed": seed,
    }
    sealed = {"status": "SEALED", "payload": payload, "sha256": _sha(payload)}
    handoff_path.parent.mkdir(mode=0o700, parents=True, exist_ok=False)
    handoff_path.write_bytes(raw)
    handoff_path.chmod(0o600)
    runtime = {
        "kind": "PADML_F2_XGBOOST_QUARANTINE_HANDOFF",
        "path": str(handoff_path),
        "sha256": sha256_file(handoff_path),
        "size_bytes": handoff_path.stat().st_size,
    }
    return sealed, runtime


def _xgb_runtime_from_handoff(
    engine: Any,
    sealed: Mapping[str, Any],
    handoff: Mapping[str, Any],
    fit_design: Any,
    evaluation_design: Any,
    fit_time: Any,
    fit_event: Any,
    np: Any,
    *,
    expected_path: Path,
    expected_parameters: Mapping[str, Any],
    expected_seed: int,
    expected_partition: Mapping[str, Any],
) -> dict[str, Any]:
    payload = sealed.get("payload") if isinstance(sealed, Mapping) else None
    path = Path(str(handoff.get("path", "")))
    metadata = os.lstat(expected_path)
    fit_bytes = np.ascontiguousarray(fit_design, dtype="float64").tobytes()
    evaluation_bytes = np.ascontiguousarray(
        evaluation_design, dtype="float64"
    ).tobytes()
    expected_design_identity = _sha(
        {
            "fit_shape": list(fit_design.shape),
            "fit_sha256": sha256_bytes(fit_bytes),
            "evaluation_shape": list(evaluation_design.shape),
            "evaluation_sha256": sha256_bytes(evaluation_bytes),
        }
    )
    expected_fit_input_identity = _sha(
        {
            "fit_ids_sha256": _sha(list(expected_partition["fit_ids"])),
            "fit_design_shape": list(fit_design.shape),
            "fit_design_sha256": sha256_bytes(fit_bytes),
            "fit_time_sha256": _sha([float(value) for value in fit_time]),
            "fit_event_sha256": _sha([int(value) for value in fit_event]),
        }
    )
    _require(
        isinstance(payload, dict)
        and payload.get("kind") == "PADML_F2_XGBOOST_PREDICTION_FUNCTION"
        and sealed.get("status") == "SEALED"
        and sealed.get("sha256") == _sha(payload)
        and handoff.get("kind") == "PADML_F2_XGBOOST_QUARANTINE_HANDOFF"
        and path == expected_path
        and path.is_absolute()
        and path.resolve(strict=True) == expected_path.resolve(strict=True)
        and stat.S_ISREG(metadata.st_mode)
        and metadata.st_nlink == 1
        and type(handoff.get("size_bytes")) is int
        and metadata.st_size == handoff["size_bytes"]
        and sha256_file(path) == handoff.get("sha256") == payload.get("booster_sha256"),
        "F2_XGBOOST_HANDOFF_IDENTITY_INVALID",
    )
    _require(
        payload.get("fit_ids") == expected_partition["fit_ids"]
        and payload.get("evaluation_ids")
        == expected_partition["evaluation_ids"]
        and payload.get("maximum") == int(expected_parameters["max_nrounds"])
        and payload.get("parameter_sha256") == _sha(expected_parameters)
        and payload.get("seed") == expected_seed
        and payload.get("design_identity") == expected_design_identity
        and payload.get("fit_input_identity")
        == expected_fit_input_identity,
        "F2_XGBOOST_HANDOFF_TASK_BINDING_INVALID",
    )
    fit_matrix = _xgb_prepared_dmatrix(engine, fit_design, np, time=fit_time, event=fit_event)
    evaluation_matrix = _xgb_prepared_dmatrix(engine, evaluation_design, np)
    _validate_xgb_cox_objective_health(payload.get("cox_objective"), payload["maximum"], len(fit_design))
    booster = engine.Booster()
    booster.load_model(str(path))
    return {
        "booster": booster,
        "fit_matrix": fit_matrix,
        "evaluation_matrix": evaluation_matrix,
    }


def _response_free_stop_partition(
    partition: Mapping[str, Any],
) -> dict[str, list[str]]:
    """Project the only STOP identity fields visible to a prediction-function fit."""

    fit_ids = partition.get("fit_ids")
    evaluation_ids = partition.get("evaluation_ids")
    _require(
        isinstance(fit_ids, list)
        and isinstance(evaluation_ids, list)
        and fit_ids
        and evaluation_ids
        and all(isinstance(value, str) and value for value in fit_ids + evaluation_ids)
        and set(fit_ids).isdisjoint(evaluation_ids),
        "F2_STOP_RESPONSE_FREE_IDENTITY_INVALID",
    )
    return {"fit_ids": list(fit_ids), "evaluation_ids": list(evaluation_ids)}


def _xgb_stop_preparation_layout(task: Mapping[str, Any]) -> tuple[dict, list[str], list[tuple]]:
    """Exact response-free STOP array sizes, before any CSV read/allocation."""
    spec, registered = task["spec"], task["registered"]
    _require(spec.get("family") == "XGBOOST_COX" and "xgb_preparation_policy" in spec
             and (spec.get("execution_scope") == "F5_FULL_DEVELOPMENT_SEARCH"
                  and spec.get("final_search_source", {}).get("program_id") == "PADML_F45_REBUILD_20260925"
                  or spec.get("execution_scope") == "F5_A12_SEARCH"
                  and spec.get("a12_source", {}).get("source", {}).get("kind")
                  == "PADML_F5_A12_PROJECTED_OUTER_INPUTS_V1")
             and registered.get("projected_partition_ids") == [task["partition_id"]]
             and registered.get("projected_partition_count") == 1
             and len(registered.get("partitions", [])) == 1 and registered.get("diagnostic_partitions") == []
             and not _contains_key(registered, "evaluation_response"), "F2_XGBOOST_PREPARATION_SCOPE_INVALID")
    partition, = registered["partitions"]
    _require(partition["kind"] == "STOP" and partition["partition_id"] == task["partition_id"]
             and type(task["imputation"]) is int and task["imputation"] in range(1, 21),
             "F2_XGBOOST_PREPARATION_SCOPE_INVALID")
    _response_free_stop_partition(partition)
    columns = sorted([column for row in _expected_family_parent_column_map(
        spec["selector_from_dependency"]["selected_parents"], "XGBOOST_COX", spec["predictors"], None)
        for column in row["columns"]], key=lambda value: value.encode("utf-8"))
    _require(columns and len(columns) == len(set(columns)), "F2_XGBOOST_PREPARATION_LAYOUT_INVALID")
    fit, evaluation, width = len(partition["fit_ids"]), len(partition["evaluation_ids"]), len(columns)
    return partition, columns, [("<f8", (fit, width)), ("<f8", (evaluation, width)),
                                ("<f8", (fit,)), ("<i8", (fit,))]


def _xgb_stop_preparation_source(task: Mapping[str, Any], partition: Mapping[str, Any], columns: list[str]) -> str:
    """Recheck immutable member/response bytes without parsing/design conversion."""
    name = f"imp{task['imputation']:02d}.csv"
    members = [row for row in partition["covariates"]["members"] if row["name"] == name]
    path = Path(partition["covariates"]["input_dir"]) / name
    _require(len(members) == 1 and path.is_absolute() and path.is_file() and not path.is_symlink()
             and path.parent.resolve(strict=True) == path.parent
             and path.stat().st_size == members[0]["size_bytes"]
             and sha256_file(path) == members[0]["sha256"], "F2_XGBOOST_PREPARATION_SOURCE_DRIFT")
    response = partition["fit_response"]
    raw = response["private_bytes"] if "private_bytes" in response else Path(response["path"]).read_bytes()
    _require(isinstance(raw, bytes) and len(raw) == response["size_bytes"] and sha256_bytes(raw) == response["sha256"],
             "F2_XGBOOST_PREPARATION_SOURCE_DRIFT")
    projected = {**partition, "fit_response": {k: v for k, v in response.items() if k != "private_bytes"}}
    return _sha({**{k: v for k, v in task.items() if k not in {"evaluation_partition", "function_result", "registered"}},
                 "registered": {**task["registered"], "partitions": [projected]}, "design_columns": columns})


def _write_xgb_stop_preparation(task: Mapping[str, Any], loaded: Mapping[str, Any], np: Any) -> dict:
    """Lend the original loader's four arrays to this function's sole evaluator."""
    partition, columns, layout = _xgb_stop_preparation_layout(task)
    binding = _xgb_stop_preparation_source(task, partition, columns)
    arrays = [loaded["fit_designs"][0], loaded["evaluation_designs"][0], loaded["fit_time"], loaded["fit_event"]]
    _require(loaded["columns"] == columns and loaded["imputation_indices"] == [task["imputation"]]
             and all(loaded[key] == partition[key] for key in ("fit_ids", "evaluation_ids"))
             and all(values.dtype == np.dtype(dtype) and values.shape == shape
                     for values, (dtype, shape) in zip(arrays, layout, strict=True)),
             "F2_XGBOOST_PREPARATION_LAYOUT_INVALID")
    path = Path(task["handoff_path"]).with_name("preparation.bin")
    if "native_search_numbers" in task["spec"]:
        path.parent.mkdir(mode=0o700, parents=True, exist_ok=False)
    with path.open("xb") as handle:
        for values in arrays:
            values.tofile(handle)
    path.chmod(0o600)
    size = sum(8 * math.prod(shape) for _, shape in layout)
    _require(path.stat().st_size == size, "F2_XGBOOST_PREPARATION_LAYOUT_INVALID")
    return {"path": str(path), "size_bytes": size, "sha256": sha256_file(path), "input_identity_sha256": binding}


def _read_xgb_stop_preparation(task: Mapping[str, Any], np: Any) -> dict:
    """Bounded byte read; original STOP/object/numerical validators still follow."""
    partition, columns, layout = _xgb_stop_preparation_layout(task)
    binding = _xgb_stop_preparation_source(task, partition, columns)
    value = task["function_result"].get("preparation")
    path = Path(task["handoff_path"]).with_name("preparation.bin")
    size = sum(8 * math.prod(shape) for _, shape in layout)
    names = {path.name} | (set() if "native_search_numbers" in task["spec"] else {Path(task["handoff_path"]).name})
    _require(isinstance(value, Mapping) and set(value) == {"path", "size_bytes", "sha256", "input_identity_sha256"}
             and value["path"] == str(path) and type(value["size_bytes"]) is int
             and value["size_bytes"] == size and value["input_identity_sha256"] == binding
             and path.parent.is_dir() and not path.parent.is_symlink()
             and {p.name for p in path.parent.iterdir()} == names
             and stat.S_ISREG(path.lstat().st_mode) and path.lstat().st_nlink == 1 and path.stat().st_size == size,
             "F2_XGBOOST_PREPARATION_HANDOFF_INVALID")
    with path.open("rb") as handle:
        arrays = [np.fromfile(handle, dtype=dtype, count=math.prod(shape)).reshape(shape) for dtype, shape in layout]
        _require(handle.read(1) == b"", "F2_XGBOOST_PREPARATION_HANDOFF_INVALID")
    digest = hashlib.sha256()
    for values in arrays:
        digest.update(memoryview(values).cast("B"))
    _require(digest.hexdigest() == value["sha256"] and all(bool(np.isfinite(values).all()) for values in arrays)
             and bool((arrays[2] > 0).all()) and bool(np.isin(arrays[3], [0, 1]).all()),
             "F2_XGBOOST_PREPARATION_HANDOFF_INVALID")
    return {"partition": partition, "columns": columns, "fit_ids": partition["fit_ids"],
            "evaluation_ids": partition["evaluation_ids"], "imputation_indices": [task["imputation"]],
            "fit_designs": [arrays[0]], "evaluation_designs": [arrays[1]], "fit_time": arrays[2], "fit_event": arrays[3]}


def _xgb_stop_preparation_batch_spec(spec: Mapping[str, Any], tasks: list[dict], scratch: Path) -> dict:
    """Reserve the whole function batch, which precedes the evaluator batch."""
    from .runtime import observe_execution_resources, resource_admission, validate_resource_policy, resolve_pool_workers
    policy = validate_resource_policy(spec["xgb_preparation_policy"])
    sizes = [sum(8 * math.prod(shape) for _, shape in _xgb_stop_preparation_layout(task)[2]) for task in tasks]
    effective = {**policy, "scratch_reserve_bytes": policy["scratch_reserve_bytes"] + sum(sizes),
                 "memory_bytes_per_worker": MIN_WORKER_MEMORY_BYTES}
    admission = resource_admission(effective, observe_execution_resources(scratch), legal_tasks=len(tasks))
    ceiling = (resolve_pool_workers(spec.get("replay_pool_workers")) if spec.get("native_search_replay") is True
               else spec["pool_workers"])
    return {**spec, "active_worker_limit": min(ceiling, spec.get("active_worker_limit", ceiling),
                                               admission["admitted_worker_ceiling"])}


def _run_xgb_function_pool_task(task: dict[str, Any]) -> dict[str, Any]:
    """Fit one response-free XGBoost stopping function into quarantine."""

    _require(
        set(task)
        == {
            "task_id",
            "spec",
            "registered",
            "partition_id",
            "imputation",
            "parameters",
            "seed",
            "handoff_path",
        }
        and not _contains_key(task, "evaluation_response"),
        "F2_XGBOOST_POOL_TASK_INVALID",
    )
    for key, value in THREAD_ENV.items():
        os.environ[key] = value
    try:
        import numpy as np  # type: ignore
        import pandas as pd  # type: ignore
        import xgboost as xgb  # type: ignore
    except ImportError as exc:
        raise ContractError("F2_XGBOOST_CAPABILITY_UNAVAILABLE") from exc
    imputation = int(task["imputation"])
    loaded = _load_python_registered_partition(
        task["spec"],
        task["registered"],
        task["partition_id"],
        pd,
        np,
        [imputation],
    )
    fit = partial(_xgb_prediction_function_seal,
        xgb,
        task["parameters"],
        _response_free_stop_partition(loaded["partition"]),
        loaded["fit_designs"][0],
        loaded["evaluation_designs"][0],
        loaded["fit_time"],
        loaded["fit_event"],
        int(task["seed"]),
        task["spec"]["backend"],
        np,
        Path(task["handoff_path"]),
    )
    if (task["spec"].get("execution_scope") in {"F4_FULL_PIPELINE_SEARCH", "F5_A12_SEARCH", "F5_FULL_DEVELOPMENT_SEARCH"}
            or "primary_search_source" in task["spec"]):
        from .f4 import _full_pipeline_python_stop_function
        sealed, handoff = _full_pipeline_python_stop_function(task, loaded, fit, np)
    else:
        sealed, handoff = fit()
    result = {
        "task_id": task["task_id"],
        "imputation": imputation,
        "partition_id": task["partition_id"],
        "sealed": sealed,
        "handoff": handoff,
    }
    if "xgb_preparation_policy" in task["spec"]:
        result["preparation"] = _write_xgb_stop_preparation(task, loaded, np)
    return {**result, "task_identity_sha256": _sha(result)}


def _run_xgb_function_evaluator_pool_task(
    task: dict[str, Any],
) -> dict[str, Any]:
    """Validate and score one sealed XGBoost function in the evaluator pool."""

    _require(
        set(task)
        == {
            "task_id",
            "spec",
            "registered",
            "evaluation_partition",
            "partition_id",
            "imputation",
            "parameters",
            "seed",
            "handoff_path",
            "function_result",
        },
        "F2_XGBOOST_EVALUATOR_TASK_INVALID",
    )
    for key, value in THREAD_ENV.items():
        os.environ[key] = value
    try:
        import numpy as np  # type: ignore
        import pandas as pd  # type: ignore
        import xgboost as xgb  # type: ignore
    except ImportError as exc:
        raise ContractError("F2_XGBOOST_CAPABILITY_UNAVAILABLE") from exc
    imputation = int(task["imputation"])
    produced = task["function_result"]
    body = {
        key: value
        for key, value in produced.items()
        if key != "task_identity_sha256"
    }
    evaluation_partition = task["evaluation_partition"]
    _require(
        isinstance(produced, dict)
        and produced.get("task_id") == task["task_id"]
        and produced.get("partition_id") == task["partition_id"]
        and produced.get("imputation") == imputation
        and produced.get("task_identity_sha256") == _sha(body)
        and isinstance(evaluation_partition, Mapping)
        and evaluation_partition.get("partition_id") == task["partition_id"]
        and isinstance(evaluation_partition.get("fit_response"), Mapping)
        and isinstance(
            evaluation_partition.get("evaluation_response"), Mapping
        ),
        "F2_XGBOOST_EVALUATOR_TASK_INVALID",
    )
    loaded = (_read_xgb_stop_preparation(task, np) if "xgb_preparation_policy" in task["spec"] else
              _load_python_registered_partition(task["spec"], task["registered"], task["partition_id"], pd, np, [imputation]))
    _require(
        loaded["partition"]["fit_ids"]
        == evaluation_partition["fit_ids"]
        and loaded["partition"]["evaluation_ids"]
        == evaluation_partition["evaluation_ids"],
        "F2_XGBOOST_EVALUATOR_PARTITION_INVALID",
    )
    if "native_search_numbers" in task["spec"]:
        from .f4_compact import _full_pipeline_python_stop_evaluate_numbers
        lock = _full_pipeline_python_stop_evaluate_numbers(task, loaded, np)
    else:
        runtime = _xgb_runtime_from_handoff(
            xgb,
            produced["sealed"],
            produced["handoff"],
            loaded["fit_designs"][0],
            loaded["evaluation_designs"][0],
            loaded["fit_time"],
            loaded["fit_event"],
            np,
            expected_path=Path(task["handoff_path"]),
            expected_parameters=task["parameters"],
            expected_seed=int(task["seed"]),
            expected_partition=evaluation_partition,
        )
        evaluate = partial(_evaluate_grouped_cox_risk_curve,
            produced["sealed"],
            fit_response=evaluation_partition["fit_response"],
            evaluation_response=evaluation_partition["evaluation_response"],
            minimum_improvement=0.0,
            patience=int(task["parameters"]["early_stopping_rounds"]),
            family="XGBOOST_COX",
            runtime=runtime,
            evaluation_context=_grouped_cox_evaluation_context(evaluation_partition["fit_response"],
                evaluation_partition["evaluation_response"], evaluation_partition["fit_ids"],
                evaluation_partition["evaluation_ids"], evaluation_indices=_development_evaluation_indices(
                    evaluation_partition, _selection_horizon_from_spec(task["spec"]))),
        )
        if (task["spec"].get("execution_scope") in {"F4_FULL_PIPELINE_SEARCH", "F5_A12_SEARCH", "F5_FULL_DEVELOPMENT_SEARCH"}
            or "primary_search_source" in task["spec"]):
            from .f4 import _full_pipeline_python_stop_evaluate
            lock = _full_pipeline_python_stop_evaluate(task, evaluate, np)
        else:
            lock = evaluate()
        handoff_path = Path(task["handoff_path"])
        handoff_path.unlink()
        if "xgb_preparation_policy" not in task["spec"]:
            handoff_path.parent.rmdir()
    if "xgb_preparation_policy" in task["spec"]:
        preparation_path = Path(task["handoff_path"]).with_name("preparation.bin")
        preparation_path.unlink()
        preparation_path.parent.rmdir()
    result = {
        "task_id": task["task_id"],
        "imputation": imputation,
        "partition_id": task["partition_id"],
        "lock": lock,
    }
    return {**result, "task_identity_sha256": _sha(result)}


def _run_xgb_refit_pool_task(task: dict[str, Any]) -> dict[str, Any]:
    """Refit one locked XGBoost model without any evaluation response."""

    task_keys = {
            "task_id",
            "spec",
            "registered",
            "partition_id",
            "imputation",
            "parameters",
            "locked_rounds",
            "seed",
        }
    _require(
        set(task)
        in {frozenset(task_keys), frozenset({*task_keys, "prediction_horizons"})}
        and not _contains_key(task, "evaluation_response"),
        "F2_XGBOOST_POOL_TASK_INVALID",
    )
    for key, value in THREAD_ENV.items():
        os.environ[key] = value
    try:
        import numpy as np  # type: ignore
        import pandas as pd  # type: ignore
        import xgboost as xgb  # type: ignore
    except ImportError as exc:
        raise ContractError("F2_XGBOOST_CAPABILITY_UNAVAILABLE") from exc
    imputation = int(task["imputation"])
    loaded = _load_python_registered_partition(
        task["spec"],
        task["registered"],
        task["partition_id"],
        pd,
        np,
        [imputation],
    )
    prediction_horizons = list(
        task.get("prediction_horizons", task["spec"]["horizons"])
    )
    _require(
        prediction_horizons
        in [
            task["spec"]["horizons"],
            task["spec"].get("monthly_fit_horizons"),
        ],
        "F2_XGBOOST_HORIZON_SET_INVALID",
    )
    fit = partial(_xgb_refit_predict,
        xgb,
        task["parameters"],
        loaded["fit_designs"][0],
        loaded["fit_time"],
        loaded["fit_event"],
        loaded["evaluation_designs"][0],
        int(task["locked_rounds"]),
        int(task["seed"]),
        task["spec"]["backend"],
        prediction_horizons,
        np,
    )
    if (task["spec"].get("execution_scope") in {"F4_FULL_PIPELINE_SEARCH", "F5_A12_SEARCH", "F5_FULL_DEVELOPMENT_SEARCH"}
            or "primary_search_source" in task["spec"]):
        from .f4 import _full_pipeline_python_search_refit
        fitted = _full_pipeline_python_search_refit(task, loaded, fit, np, pd)
    else:
        fitted = fit()
    sealed = _seal_prediction_matrix(
        loaded["evaluation_ids"],
        fitted["survival"].tolist(),
        prediction_horizons,
    )
    result = {
        "task_id": task["task_id"],
        "imputation": imputation,
        "partition_id": task["partition_id"],
        "sealed_prediction": sealed,
        "fit_health": fitted["fit_health"],
    }
    return {**result, "task_identity_sha256": _sha(result)}


def _xgb_locked_seal_record(
    partition: Mapping[str, Any],
    imputation: int,
    locked_rounds: int,
    sealed: Mapping[str, Any],
    fit_health: Mapping[str, Any],
) -> dict[str, Any]:
    observed_health = _validate_python_fit_health(
        "XGBOOST_COX",
        fit_health,
        locked_value=locked_rounds,
        training_count=len(partition["fit_ids"]),
        evaluation_count=len(sealed["payload"]["patient_ids"]),
    )
    return {
        "partition_id": partition["partition_id"],
        "imputation": imputation,
        "prediction_seal_sha256": sealed["sha256"],
        "stopping": {
            **observed_health,
            "locked_rounds": locked_rounds,
            "stopping_reselected": False,
        },
        "sealed_prediction": dict(sealed),
    }


def _xgb_evaluate_locked_seal(
    spec: Mapping[str, Any],
    partition: Mapping[str, Any],
    imputation: int,
    locked_rounds: int,
    sealed: Mapping[str, Any],
    fit_health: Mapping[str, Any],
) -> dict[str, Any]:
    record = _xgb_locked_seal_record(
        partition, imputation, locked_rounds, sealed, fit_health
    )
    horizon = _selection_horizon_from_spec(spec)
    metric = _evaluate_prediction_seal(
        _monthly_prediction_seal(sealed),
        fit_response=partition["fit_response"],
        evaluation_response=partition["evaluation_response"],
        selection_horizon_months=horizon,
        evaluation_context=_prediction_evaluation_context(partition["fit_response"],
            partition["evaluation_response"], partition["evaluation_ids"],
            selection_horizon_months=horizon,
            evaluation_indices=_development_evaluation_indices(partition, horizon)),
    )
    return {
        **record,
        "evaluation_response_sha256": partition["evaluation_response"][
            "sha256"
        ],
        "evaluation_ids_sha256": partition["evaluation_ids_sha256"],
        f"ibs_0_{horizon}": metric[f"ibs_0_{horizon}"],
    }


def _run_xgb_locked_batch(
    spec: dict[str, Any],
    registered: dict[str, Any],
    descriptors: list[dict[str, Any]],
    *,
    evaluate_response: bool = True,
) -> list[dict[str, Any]]:
    _require(type(evaluate_response) is bool, "F2_XGBOOST_EVALUATION_MODE_INVALID")
    tasks = [
        {
            "task_id": descriptor["task_id"],
            "spec": spec,
            "registered": _engine_registered_partitions(
                registered, {descriptor["partition"]["partition_id"]}
            ),
            "partition_id": descriptor["partition"]["partition_id"],
            "imputation": descriptor["imputation"],
            "parameters": descriptor["parameters"],
            "locked_rounds": descriptor["locked_rounds"],
            "seed": descriptor["seed"],
            "prediction_horizons": descriptor.get(
                "prediction_horizons", spec["monthly_fit_horizons"]
            ),
        }
        for descriptor in descriptors
    ]
    produced = _bounded_ordered_spawn(
        _run_xgb_refit_pool_task,
        tasks,
        selected_slots=spec["pool_workers"],
    )
    for descriptor, task, row in zip(
        descriptors, tasks, produced, strict=True
    ):
        body = {
            key: value
            for key, value in row.items()
            if key != "task_identity_sha256"
        }
        _require(
            row.get("task_id") == task["task_id"]
            and row.get("partition_id") == task["partition_id"]
            and row.get("imputation") == task["imputation"]
            and row.get("task_identity_sha256") == _sha(body),
            "F2_XGBOOST_POOL_RESULT_INVALID",
        )
    if not evaluate_response:
        return [
            _xgb_locked_seal_record(
                descriptor["partition"],
                task["imputation"],
                task["locked_rounds"],
                row["sealed_prediction"],
                row["fit_health"],
            )
            for descriptor, task, row in zip(
                descriptors, tasks, produced, strict=True
            )
        ]
    evaluator_tasks = [
        {
            "task_id": task["task_id"],
            "family": "XGBOOST_COX",
            "spec": spec,
            "evaluation_partition": descriptor["partition"],
            "partition_id": task["partition_id"],
            "imputation": task["imputation"],
            "locked_value": task["locked_rounds"],
            "sealed_prediction": row["sealed_prediction"],
            "fit_health": row["fit_health"],
        }
        for descriptor, task, row in zip(
            descriptors, tasks, produced, strict=True
        )
    ]
    evaluator_results = _bounded_ordered_spawn(
        _run_python_locked_evaluation_pool_task,
        evaluator_tasks,
        selected_slots=spec["pool_workers"],
    )
    evaluated: list[dict[str, Any]] = []
    for task, row in zip(evaluator_tasks, evaluator_results, strict=True):
        body = {
            key: value
            for key, value in row.items()
            if key != "task_identity_sha256"
        }
        _require(
            row.get("task_id") == task["task_id"]
            and row.get("partition_id") == task["partition_id"]
            and row.get("imputation") == task["imputation"]
            and row.get("task_identity_sha256") == _sha(body)
            and isinstance(row.get("evaluated"), dict),
            "F2_XGBOOST_POOL_RESULT_INVALID",
        )
        evaluated.append(row["evaluated"])
    return evaluated


def _run_python_registered_xgboost(
    spec: dict[str, Any],
    registered: dict[str, Any],
    scratch: Path,
    engine: Any,
    np: Any,
    pd: Any,
    *,
    search_only: bool = False,
    seed_audit_candidate: Mapping[str, Any] | None = None,
    full_pipeline_replicate: int | None = None,
    full_pipeline_workers: int = 1,
) -> dict[str, Any]:
    _require(spec["family"] == "XGBOOST_COX", "F2_XGBOOST_ROUTE_INVALID")
    full_pipeline_seeds = _full_pipeline_search_seed_registry(spec, search_only, full_pipeline_replicate)
    inner = sorted(
        (row for row in registered["partitions"] if row["kind"] == "INNER"),
        key=lambda row: (row["repeat"], row["inner_fold"]),
    )
    stops = {
        (row["repeat"], row["inner_fold"]): row
        for row in registered["partitions"]
        if row["kind"] == "STOP"
    }
    centers = sorted(
        registered.get("diagnostic_partitions", []),
        key=lambda row: row["validation_center"],
    )
    outer = [row for row in registered["partitions"] if row["kind"] == "OUTER"]
    _require(
        type(search_only) is bool
        and len(inner) == len(stops) == 15
        and (search_only or (len(centers) == 5 and len(outer) == 1)),
        "F2_XGBOOST_REGISTERED_PARTITION_DENOMINATOR_INVALID",
    )
    for partition in inner:
        stop = stops[(partition["repeat"], partition["inner_fold"])]
        _require(
            stop.get("consumer_set")
            == ["GBM_COX", "XGBOOST_COX", "COXTIME_SET_A"]
            and stop["application_ids"] == partition["fit_ids"]
            and set(stop["fit_ids"]).isdisjoint(stop["evaluation_ids"])
            and set(stop["fit_ids"]) | set(stop["evaluation_ids"])
            == set(stop["application_ids"]),
            "F2_XGBOOST_STOP_REFIT_LINK_INVALID",
        )
    inner_accumulator: dict[str, list[dict[str, Any]]] = {}
    stop_accumulator: dict[str, list[dict[str, Any]]] = {}

    def evaluate_trials(
        stage: str,
        trials: list[dict[str, Any]],
        partitions: list[dict[str, Any]],
        imputation_count: int,
        stage_seed: int,
    ) -> list[dict[str, Any]]:
        grouped: list[list[tuple[dict[str, Any], dict[str, Any]]]] = [
            [] for _ in trials
        ]
        function_tasks: list[dict[str, Any]] = []
        owners: list[int] = []
        full_partitions: list[dict[str, Any]] = []
        raw_stops: list[dict[str, Any]] = []
        for trial_index, trial in enumerate(trials):
            for partition_index, partition in enumerate(partitions, start=1):
                stop = stops[(partition["repeat"], partition["inner_fold"])]
                parameters = _engine_parameters(
                    "XGBOOST_COX", trial["parameters"]
                )
                for imputation in range(1, imputation_count + 1):
                    task_seed = (full_pipeline_seeds["stop_seeds"][imputation - 1]
                                 if full_pipeline_seeds else stage_seed + imputation * 100 + partition_index)
                    task_id = (
                        f"{stage}_T{trial_index + 1:03d}_"
                        f"P{partition_index:02d}_M{imputation:02d}_FUNCTION"
                    )
                    function_tasks.append(
                        {
                            "task_id": task_id,
                            "spec": spec,
                            "registered": _engine_registered_partitions(
                                registered, {stop["partition_id"]}
                            ),
                            "partition_id": stop["partition_id"],
                            "imputation": imputation,
                            "parameters": parameters,
                            "seed": task_seed,
                            "handoff_path": str(
                                scratch
                                / "xgb-quarantine"
                                / _sha({"task_id": task_id, "seed": task_seed})[:24]
                                / "function.ubj"
                            ),
                        }
                    )
                    owners.append(trial_index)
                    full_partitions.append(partition)
                    raw_stops.append(stop)
        preparation_spec = (_xgb_stop_preparation_batch_spec(spec, function_tasks, scratch)
                            if "xgb_preparation_policy" in spec and "native_search_batch" not in spec else spec)
        evaluator_results = _search_python_stop_batch(
            preparation_spec,
            function_tasks,
            raw_stops,
            selected_slots=spec["pool_workers"],
            full_pipeline_workers=full_pipeline_workers,
        )
        locks: list[dict[str, Any]] = []
        refit_tasks: list[dict[str, Any]] = []
        for task, partition, stop, produced, owner in zip(
            function_tasks,
            full_partitions,
            raw_stops,
            evaluator_results,
            owners,
            strict=True,
        ):
            body = {
                key: value
                for key, value in produced.items()
                if key != "task_identity_sha256"
            }
            _require(
                produced.get("task_id") == task["task_id"]
                and produced.get("partition_id") == task["partition_id"]
                and produced.get("imputation") == task["imputation"]
                and produced.get("task_identity_sha256") == _sha(body),
                "F2_XGBOOST_POOL_RESULT_INVALID",
            )
            lock = produced.get("lock")
            _require(
                isinstance(lock, dict)
                and isinstance(lock.get("selected_rounds"), int)
                and isinstance(lock.get("identity"), str),
                "F2_XGBOOST_POOL_RESULT_INVALID",
            )
            refit_task = {
                "task_id": task["task_id"].removesuffix("_FUNCTION")
                + "_LOCKED_REFIT",
                "spec": spec,
                "registered": _engine_registered_partitions(
                    registered, {partition["partition_id"]}
                ),
                "partition_id": partition["partition_id"],
                "imputation": task["imputation"],
                "parameters": task["parameters"],
                "locked_rounds": lock["selected_rounds"],
                "prediction_horizons": spec["monthly_fit_horizons"],
                "seed": (_full_pipeline_trial_seed(full_pipeline_seeds, stage, trials[owner])
                         if full_pipeline_seeds else task["seed"]),
            }
            stop_record = {
                "identity": lock["identity"],
                "risk_curve_sha256": lock["risk_curve_sha256"],
                "minimum_stopping_loss": lock[
                    "minimum_grouped_cox_deviance"
                ],
            }
            locks.append(lock)
            refit_tasks.append(refit_task)
            stop_accumulator.setdefault(stop["partition_id"], []).append(
                {
                    **stop_record,
                }
            )
        refit_results = _search_task_batch(
            spec,
            _run_xgb_refit_pool_task,
            refit_tasks,
            selected_slots=spec["pool_workers"],
            full_pipeline_workers=full_pipeline_workers,
        )
        for task, produced in zip(refit_tasks, refit_results, strict=True):
            body = {
                key: value
                for key, value in produced.items()
                if key != "task_identity_sha256"
            }
            _require(
                produced.get("task_id") == task["task_id"]
                and produced.get("partition_id") == task["partition_id"]
                and produced.get("imputation") == task["imputation"]
                and produced.get("task_identity_sha256") == _sha(body),
                "F2_XGBOOST_POOL_RESULT_INVALID",
            )
        locked_evaluator_tasks = [
            {
                "task_id": task["task_id"],
                "family": "XGBOOST_COX",
                "spec": spec,
                "evaluation_partition": partition,
                "partition_id": task["partition_id"],
                "imputation": task["imputation"],
                "locked_value": task["locked_rounds"],
                "sealed_prediction": produced["sealed_prediction"],
                "fit_health": produced["fit_health"],
            }
            for task, produced, partition in zip(
                refit_tasks, refit_results, full_partitions, strict=True
            )
        ]
        locked_evaluator_results = _search_task_batch(
            spec,
            _run_python_locked_evaluation_pool_task,
            locked_evaluator_tasks,
            selected_slots=spec["pool_workers"],
            full_pipeline_workers=full_pipeline_workers,
        )
        for owner, task, produced, partition, lock in zip(
            owners,
            locked_evaluator_tasks,
            locked_evaluator_results,
            full_partitions,
            locks,
            strict=True,
        ):
            body = {
                key: value
                for key, value in produced.items()
                if key != "task_identity_sha256"
            }
            _require(
                produced.get("task_id") == task["task_id"]
                and produced.get("partition_id") == task["partition_id"]
                and produced.get("imputation") == task["imputation"]
                and produced.get("task_identity_sha256") == _sha(body)
                and isinstance(produced.get("evaluated"), dict),
                "F2_XGBOOST_POOL_RESULT_INVALID",
            )
            evaluated = produced["evaluated"]
            evaluated["lock_identity_sha256"] = lock["identity"]
            inner_accumulator.setdefault(partition["partition_id"], []).append(
                evaluated
            )
            grouped[owner].append((evaluated, lock))
        scoring_context = _trial_scoring_context(partitions,
            selection_horizon_months=_selection_horizon_from_spec(spec))
        results: list[dict[str, Any]] = []
        for trial_index, (trial, values) in enumerate(
            zip(trials, grouped, strict=True), start=1
        ):
            rounds = [lock["selected_rounds"] for _, lock in values]
            results.append(
                {
                    "stage_id": stage,
                    "trial_index": trial_index,
                    "candidate_id": trial.get(
                        "trial_id", trial.get("candidate_id")
                    ),
                    "parameters": trial["parameters"],
                    "parameter_sha256": trial["parameter_sha256"],
                    **_trial_evaluation_summary(
                        [row for row, _ in values], scoring_context, imputation_count
                    ),
                    "selected_rounds_median": _integer_median(rounds),
                }
            )
        return results

    if seed_audit_candidate is not None:
        _require(search_only and full_pipeline_replicate is None, "WINNER_SEED_SCOPE_INVALID")
        return _winner_seed_only(spec, seed_audit_candidate, inner, evaluate_trials)

    trace: dict[str, list[dict[str, Any]]] = {}
    trace["S1"] = evaluate_trials(
        "S1",
        spec["candidate_trials"]["S1"],
        [row for row in inner if row["repeat"] == 1],
        1,
        spec["seed"] + 10_000,
    )
    trace["S2"] = evaluate_trials(
        "S2",
        spec["candidate_trials"]["S2"],
        [row for row in inner if row["repeat"] == 2],
        5,
        spec["seed"] + 20_000,
    )
    top3 = _tree_s3a_candidates(trace)
    trace["S3A"] = evaluate_trials(
        "S3A",
        top3,
        [row for row in inner if row["repeat"] == 3],
        20,
        spec["seed"] + 30_000,
    )
    top2 = _rank_trials(trace["S3A"], retain=2)[:2]
    trace["S3B1"] = evaluate_trials(
        "S3B1", top2, inner, 5, spec["seed"] + 40_000
    )
    provisional = _rank_trials(trace["S3B1"], retain=1)[0]
    trace["S3B2"] = evaluate_trials(
        "S3B2", [provisional], inner, 20, spec["seed"] + 50_000
    )
    winner = trace["S3B2"][0]
    if search_only:
        return _shared_full_development_search_result(
            spec,
            registered,
            trace,
            {
                "family": "XGBOOST_COX",
                "candidate_id": winner["candidate_id"],
                "parameters": winner["parameters"],
                "selected_rounds": winner["selected_rounds_median"],
                "selection_metric": f"IBS_0_{_selection_horizon_from_spec(spec)}",
                "selection_stage": "S3B2",
            },
            full_pipeline_seeds,
        )
    trace["SEED_AUDIT"] = [
        {
            "seed_offset": offset,
            **evaluate_trials(
                f"SEED_AUDIT_{index}",
                [winner],
                inner,
                5,
                spec["seed"] + offset,
            )[0],
            "stage_id": "SEED_AUDIT",
        }
        for index, offset in enumerate(
            spec["model_seed_policy"]["extra_seed_offsets"], start=1
        )
    ]
    center_candidates = _rank_trials(trace["S3B1"], retain=2)[:2]
    trace["CENTER_STRESS"] = []
    center_descriptors = [
        {
            "task_id": (
                f"CENTER_STRESS_T{candidate_rank:02d}_"
                f"C{center_index:02d}_M{imputation:02d}"
            ),
            "candidate_rank": candidate_rank,
            "partition": partition,
            "imputation": imputation,
            "parameters": _engine_parameters(
                "XGBOOST_COX", candidate["parameters"]
            ),
            "locked_rounds": candidate["selected_rounds_median"],
            "seed": (
                spec["seed"]
                + 80_000
                + candidate_rank * 1_000
                + center_index * 100
                + imputation
            ),
        }
        for candidate_rank, candidate in enumerate(center_candidates, start=1)
        for center_index, partition in enumerate(centers, start=1)
        for imputation in range(1, 6)
    ]
    center_results = _run_xgb_locked_batch(
        spec, registered, center_descriptors
    )
    center_scoring_context = _trial_scoring_context(centers)
    for descriptor, evaluated in zip(
        center_descriptors, center_results, strict=True
    ):
        inner_accumulator.setdefault(
            descriptor["partition"]["partition_id"], []
        ).append(evaluated)
    for candidate_rank, candidate in enumerate(center_candidates, start=1):
        values = [
            row
            for descriptor, row in zip(
                center_descriptors, center_results, strict=True
            )
            if descriptor["candidate_rank"] == candidate_rank
        ]
        trace["CENTER_STRESS"].append(
            {
                **candidate,
                "stage_id": "CENTER_STRESS",
                **_trial_evaluation_summary(values, center_scoring_context, 5),
            }
        )
    selected_parameters = _engine_parameters(
        "XGBOOST_COX", winner["parameters"]
    )
    final_descriptors = [
        {
            "task_id": f"FINAL_OUTER_M{imputation:02d}",
            "partition": outer[0],
            "imputation": imputation,
            "parameters": selected_parameters,
            "locked_rounds": winner["selected_rounds_median"],
            "prediction_horizons": spec["monthly_fit_horizons"],
            "seed": spec["seed"] + imputation,
        }
        for imputation in range(1, 21)
    ]
    final = _run_xgb_locked_batch(
        spec,
        registered,
        final_descriptors,
        evaluate_response=False,
    )
    evaluation_units = sum(
        row["evaluation_units"] for rows in trace.values() for row in rows
    ) + 20
    _require(
        evaluation_units == spec["search_budget"]["standard_outer_units"],
        "F2_XGBOOST_STANDARD_OUTER_BUDGET_INVALID",
    )
    result = _build_registered_model_result(
        spec,
        registered,
        final,
        selector=spec["selector_from_dependency"],
        search_trace=trace,
        search_evaluation_unit_count=evaluation_units,
        selected_spec={
            "family": "XGBOOST_COX",
            "candidate_id": winner["candidate_id"],
            "parameters": winner["parameters"],
            "selected_rounds": winner["selected_rounds_median"],
            "selection_metric": "IBS_0_24",
            "selection_stage": "S3B2",
        },
        execution_rows=_registered_stopping_execution_rows(
            registered, inner_accumulator, stop_accumulator
        ),
    )
    _require(evaluation_units == 1520, "F2_XGBOOST_GRAPH_DENOMINATOR_INVALID")
    parent_response_evaluations = sum(
        row["evaluation_count"]
        for row in result["registered_partition_execution"]["partitions"]
    ) + sum(
        len(row["fold_metric_values"]) + row["ranking_evaluation_count"]
        for values in trace.values() for row in values
    )
    _require(
        parent_response_evaluations == 3403,
        "F2_XGBOOST_PARENT_EVALUATION_DENOMINATOR_INVALID",
    )
    result["execution_graph"] = {
        "schema_version": "1.0.0",
        "family": "XGBOOST_COX",
        "search_budget_evaluation_unit_count": 1520,
        "parent_response_evaluation_count": parent_response_evaluations,
        "response_free_function_fit_count": 1450,
        "locked_refit_fit_count": 1520,
        "total_fit_count": 2970,
        "parent_evaluation_owner": "UNIQUE_LOCAL_PARENT",
    }
    return result


def _rank_trials(
    rows: list[dict[str, Any]], *, retain: int | None = None
) -> list[dict[str, Any]]:
    horizons = [row.get("selection_horizon_months", 24) for row in rows]
    _require(all(type(value) is int and value in {6, 12, 24, 36} for value in horizons)
             and len(set(horizons)) <= 1, "F2_TRIAL_RANKING_HORIZON_MISMATCH")
    ranked = sorted(
        rows,
        key=lambda row: (
            row["mean_ibs"],
            row["maximum_ibs"],
            row["parameter_sha256"],
        ),
    )
    if retain is not None:
        _require(
            isinstance(retain, int)
            and not isinstance(retain, bool)
            and 1 <= retain <= len(ranked),
            "F2_MODEL_SELECTION_RANK_BOUNDARY_INVALID",
        )
        if retain < len(ranked):
            selected_boundary = ranked[retain - 1]
            excluded_boundary = ranked[retain]
            _require(
                (
                    selected_boundary["mean_ibs"],
                    selected_boundary["maximum_ibs"],
                )
                != (
                    excluded_boundary["mean_ibs"],
                    excluded_boundary["maximum_ibs"],
                ),
                "F2_MODEL_SELECTION_INDISTINGUISHABLE",
            )
    return ranked




def _tree_s3a_candidates(trace: Mapping[str, Any]) -> list[dict[str, Any]]:
    """Different fidelities/repeats never compete in one promotion ranking."""

    return _rank_trials(trace["S2"], retain=3)[:3]


def _coxtime_native():
    """Bind Torch to its own BLAS in both standalone and embedded Python.

    R exports BLAS symbols globally. Without local dependency preference its
    GEMM can interpose on Torch's final linear layer and invalidate a retained
    baseline. Restore loader flags immediately; no RNG or model is changed.
    """
    import sys
    flags = sys.getdlopenflags() if hasattr(sys, "getdlopenflags") else None
    try:
        if flags is not None and hasattr(os, "RTLD_DEEPBIND"):
            sys.setdlopenflags(flags | os.RTLD_DEEPBIND)
        import torch
    finally:
        if flags is not None:
            sys.setdlopenflags(flags)
    from pycox import models
    import torchtuples as tt
    return models, torch, tt


def _coxtime_runtime(torch: Any) -> None:
    """Fit and fresh replay processes use identical arithmetic without reseeding."""
    torch.use_deterministic_algorithms(True)
    try:
        torch.set_num_threads(1)
        torch.set_num_interop_threads(1)
    except RuntimeError:
        pass
    _require(
        torch.get_num_threads() == 1
        and torch.get_num_interop_threads() == 1,
        "F2_COXTIME_THREAD_POLICY_INVALID",
    )


def _coxtime_seed(torch: Any, seed: int, backend: str) -> Any:
    _require(backend == "CPU", "F2_COXTIME_BACKEND_INVALID")
    random.seed(seed)
    try:
        import numpy as np  # type: ignore
    except ImportError as exc:  # pragma: no cover - guarded by the caller
        raise ContractError("F2_NUMPY_CAPABILITY_UNAVAILABLE") from exc
    np.random.seed(seed)
    torch.manual_seed(seed)
    _coxtime_runtime(torch)
    return torch.device("cpu")


def _coxtime_architecture(value: str) -> list[int]:
    try:
        widths = [int(item) for item in value.split("x")]
    except ValueError as exc:
        raise ContractError("F2_COXTIME_ARCHITECTURE_INVALID") from exc
    _require(widths and all(1 <= width <= 4096 for width in widths), "F2_COXTIME_ARCHITECTURE_INVALID")
    return widths


def _coxtime_model(
    native: tuple[Any, Any, Any],
    candidate: dict[str, Any],
    input_width: int,
    labtrans: Any,
    epochs: int,
    device: Any,
) -> Any:
    models, torch, tt = native
    _coxtime_runtime(torch)

    class ExplicitCoxTimeMLP(torch.nn.Module):
        def __init__(self) -> None:
            super().__init__()
            layers: list[Any] = []
            width = input_width + 1
            for hidden in _coxtime_architecture(candidate["network_architecture"]):
                linear = torch.nn.Linear(width, hidden, bias=True)
                torch.nn.init.kaiming_uniform_(linear.weight, a=math.sqrt(5.0))
                bound = 1.0 / math.sqrt(float(linear.weight.shape[1]))
                torch.nn.init.uniform_(linear.bias, -bound, bound)
                layers.extend((linear, torch.nn.ReLU()))
                batch_norm = torch.nn.BatchNorm1d(
                    hidden,
                    eps=1e-5,
                    momentum=0.1,
                    affine=True,
                    track_running_stats=True,
                )
                torch.nn.init.constant_(batch_norm.weight, 1.0)
                torch.nn.init.constant_(batch_norm.bias, 0.0)
                layers.append(batch_norm)
                if float(candidate["dropout"]) > 0:
                    layers.append(torch.nn.Dropout(float(candidate["dropout"])))
                width = hidden
            output = torch.nn.Linear(width, 1, bias=False)
            torch.nn.init.kaiming_uniform_(output.weight, a=math.sqrt(5.0))
            layers.append(output)
            self.network = torch.nn.Sequential(*layers)

        def forward(self, features: Any, transformed_time: Any) -> Any:
            scores = self.network(torch.cat((features, transformed_time), dim=1))
            _require(bool(torch.isfinite(scores).all()), "F2_COXTIME_RAW_SCORE_NONFINITE")
            return scores

    class CheckedCoxCCLoss(models.loss.CoxCCLoss):
        def forward(self, g_case: Any, g_control: Any) -> Any:
            controls = (g_control,) if torch.is_tensor(g_control) else g_control
            _require(bool(torch.isfinite(g_case).all()), "F2_COXTIME_RAW_SCORE_NONFINITE")
            for control in controls:
                _require(bool(torch.isfinite(control).all()), "F2_COXTIME_RAW_SCORE_NONFINITE")
                _require(bool(torch.isfinite(control - g_case).all()), "F2_COXTIME_SCORE_DIFFERENCE_NONFINITE")
            loss = super().forward(g_case, g_control)
            _require(bool(torch.isfinite(loss).all()), "F2_COXTIME_TRAINING_LOSS_NONFINITE")
            return loss

    optimizer = tt.optim.AdamW(
        lr=float(candidate["learning_rate"]),
        betas=(0.9, 0.99),
        eps=1e-8,
        decoupled_weight_decay=float(candidate["weight_decay"]),
        dwd_normalize=False,
        nb_epochs=epochs,
    )
    optimizer.init_args["amsgrad"] = False
    return models.CoxTime(
        ExplicitCoxTimeMLP(),
        optimizer=optimizer,
        device=device,
        shrink=float(candidate["coxtime_shrink"]),
        labtrans=labtrans,
        loss=CheckedCoxCCLoss(float(candidate["coxtime_shrink"])),
    )


def _coxtime_labtrans(models: Any, candidate: dict[str, Any], durations: Any, events: Any, np: Any) -> Any:
    labtrans = models.CoxTime.label_transform(
        log_duration=candidate["time_transform"] == "LOG1P_STANDARDIZED",
        with_mean=True,
        with_std=True,
    )
    labtrans.fit(np.asarray(durations, dtype="float32"), np.asarray(events, dtype="float32"))
    return labtrans


def _coxtime_target(labtrans: Any, durations: Any, events: Any, np: Any) -> tuple[Any, Any]:
    return labtrans.transform(np.asarray(durations, dtype="float32"), np.asarray(events, dtype="float32"))


def _coxtime_standardize(fit: Any, *others: Any, np: Any, native_scaler: Any = None) -> tuple[Any, ...]:
    fit = np.asarray(fit, dtype="float32")
    mean = fit.mean(axis=0, dtype="float64").astype("float32")
    scale = fit.std(axis=0, dtype="float64").astype("float32")
    scale[~np.isfinite(scale) | (scale <= 0)] = 1.0
    if native_scaler is not None:
        native_scaler.update(mean=mean.copy(), scale=scale.copy())
    transformed = tuple((np.asarray(value, dtype="float32") - mean) / scale for value in (fit, *others))
    _require(all(np.isfinite(value).all() for value in transformed), "F2_COXTIME_STANDARDIZATION_INVALID")
    return transformed




def _coxtime_state_sha256(state: Mapping[str, Any], torch: Any) -> str:
    digest = hashlib.sha256()
    for key in sorted(state, key=lambda value: value.encode("utf-8")):
        tensor = state[key].detach().cpu().contiguous()
        digest.update(key.encode("utf-8"))
        digest.update(str(tensor.dtype).encode("ascii"))
        digest.update(canonical_json_bytes(list(tensor.shape)))
        digest.update(tensor.numpy().tobytes())
    return digest.hexdigest()


def _coxtime_prediction_function_seal(
    native: tuple[Any, Any, Any],
    candidate: dict[str, Any],
    partition: Mapping[str, Any],
    x_fit: Any,
    fit_time: Any,
    fit_event: Any,
    x_evaluation: Any,
    seed: int,
    backend: str,
    np: Any,
    handoff_path: Path,
) -> tuple[dict[str, Any], dict[str, Any]]:
    """Train 300 fit-only epochs and freeze every response-free function state."""

    models, torch, tt = native
    device = _coxtime_seed(torch, seed, backend)
    x_fit = np.asarray(x_fit, dtype="float32")
    x_evaluation = np.asarray(x_evaluation, dtype="float32")
    fit_input_identity = _sha(
        {
            "fit_ids_sha256": _sha(list(partition["fit_ids"])),
            "fit_design_shape": list(x_fit.shape),
            "fit_design_sha256": sha256_bytes(
                np.ascontiguousarray(x_fit).tobytes()
            ),
            "fit_time_sha256": _sha([float(value) for value in fit_time]),
            "fit_event_sha256": _sha([int(value) for value in fit_event]),
            "evaluation_design_shape": list(x_evaluation.shape),
            "evaluation_design_sha256": sha256_bytes(
                np.ascontiguousarray(x_evaluation).tobytes()
            ),
        }
    )
    mean = x_fit.mean(axis=0, dtype="float64").astype("float32")
    scale = x_fit.std(axis=0, dtype="float64").astype("float32")
    scale[~np.isfinite(scale) | (scale <= 0)] = 1.0
    x_fit = (x_fit - mean) / scale
    x_evaluation = (x_evaluation - mean) / scale
    _require(
        np.isfinite(x_fit).all() and np.isfinite(x_evaluation).all(),
        "F2_COXTIME_STANDARDIZATION_INVALID",
    )
    labtrans = _coxtime_labtrans(models, candidate, fit_time, fit_event, np)
    target_fit = _coxtime_target(labtrans, fit_time, fit_event, np)
    maximum = 300
    model = _coxtime_model(
        native, candidate, x_fit.shape[1], labtrans, maximum, device
    )
    checkpoints: list[dict[str, Any]] = []
    checkpoint_hashes: list[str] = []

    class ClipAndCheckpoint(tt.callbacks.Callback):
        def before_step(self) -> bool:
            torch.nn.utils.clip_grad_norm_(
                model.net.parameters(),
                max_norm=5.0,
                norm_type=2.0,
                error_if_nonfinite=True,
            )
            return False

        def on_epoch_end(self) -> bool:
            state = {
                key: value.detach().cpu().clone()
                for key, value in model.net.state_dict().items()
            }
            checkpoints.append(state)
            checkpoint_hashes.append(_coxtime_state_sha256(state, torch))
            return False

    training_log = model.fit(
        x_fit,
        target_fit,
        batch_size=int(candidate["batch_size"]),
        epochs=maximum,
        callbacks=[ClipAndCheckpoint()],
        verbose=False,
        num_workers=0,
        shuffle=True,
        val_data=None,
        n_control=5,
    )
    training_losses = np.asarray(training_log.to_pandas()["train_loss"], dtype=float)
    _require(len(training_losses) == maximum and bool(np.isfinite(training_losses).all()),
             "F2_COXTIME_TRAINING_LOSS_NONFINITE")
    _require(
        len(checkpoints) == len(checkpoint_hashes) == maximum,
        "F2_COXTIME_CHECKPOINT_DENOMINATOR_INVALID",
    )
    scaler = {
        "mean": [float(value) for value in mean],
        "scale": [float(value) for value in scale],
    }
    duration_scaler = labtrans.duration_scaler
    labtrans_record = {
        "log_duration": bool(labtrans.log_duration),
        "mean": [float(value) for value in duration_scaler.mean_],
        "scale": [float(value) for value in duration_scaler.scale_],
    }
    payload = {
        "schema_version": "1.0.0",
        "kind": "PADML_F2_COXTIME_PREDICTION_FUNCTION",
        "fit_ids": list(partition["fit_ids"]),
        "evaluation_ids": list(partition["evaluation_ids"]),
        "maximum": maximum,
        "checkpoint_sha256s": checkpoint_hashes,
        "candidate_sha256": _sha(candidate),
        "scaler_sha256": _sha(scaler),
        "labtrans_sha256": _sha(labtrans_record),
        "evaluation_design_sha256": sha256_bytes(
            np.ascontiguousarray(x_evaluation).tobytes()
        ),
        "fit_input_identity": fit_input_identity,
        "seed": seed,
    }
    sealed = {"status": "SEALED", "payload": payload, "sha256": _sha(payload)}
    handoff_path.parent.mkdir(mode=0o700, parents=True, exist_ok=False)
    torch.save(checkpoints, handoff_path)
    handoff_path.chmod(0o600)
    runtime = {
        "kind": "PADML_F2_COXTIME_QUARANTINE_HANDOFF",
        "path": str(handoff_path),
        "sha256": sha256_file(handoff_path),
        "size_bytes": handoff_path.stat().st_size,
    }
    return sealed, runtime


def _coxtime_runtime_from_handoff(
    native: tuple[Any, Any, Any],
    sealed: Mapping[str, Any],
    handoff: Mapping[str, Any],
    candidate: dict[str, Any],
    x_fit: Any,
    fit_time: Any,
    fit_event: Any,
    x_evaluation: Any,
    seed: int,
    backend: str,
    np: Any,
    *,
    expected_path: Path,
    expected_partition: Mapping[str, Any],
) -> dict[str, Any]:
    models, torch, _ = native
    payload = sealed.get("payload") if isinstance(sealed, Mapping) else None
    path = Path(str(handoff.get("path", "")))
    metadata = os.lstat(expected_path)
    _require(
        isinstance(payload, dict)
        and payload.get("kind") == "PADML_F2_COXTIME_PREDICTION_FUNCTION"
        and sealed.get("status") == "SEALED"
        and sealed.get("sha256") == _sha(payload)
        and handoff.get("kind") == "PADML_F2_COXTIME_QUARANTINE_HANDOFF"
        and path == expected_path
        and path.is_absolute()
        and path.resolve(strict=True) == expected_path.resolve(strict=True)
        and stat.S_ISREG(metadata.st_mode)
        and metadata.st_nlink == 1
        and type(handoff.get("size_bytes")) is int
        and metadata.st_size == handoff["size_bytes"]
        and sha256_file(path) == handoff.get("sha256"),
        "F2_COXTIME_HANDOFF_IDENTITY_INVALID",
    )
    _require(
        payload.get("fit_ids") == expected_partition["fit_ids"]
        and payload.get("evaluation_ids")
        == expected_partition["evaluation_ids"]
        and payload.get("seed") == seed,
        "F2_COXTIME_HANDOFF_TASK_BINDING_INVALID",
    )
    device = _coxtime_seed(torch, seed, backend)
    x_fit = np.asarray(x_fit, dtype="float32")
    x_evaluation = np.asarray(x_evaluation, dtype="float32")
    expected_fit_input_identity = _sha(
        {
            "fit_ids_sha256": _sha(list(expected_partition["fit_ids"])),
            "fit_design_shape": list(x_fit.shape),
            "fit_design_sha256": sha256_bytes(
                np.ascontiguousarray(x_fit).tobytes()
            ),
            "fit_time_sha256": _sha([float(value) for value in fit_time]),
            "fit_event_sha256": _sha([int(value) for value in fit_event]),
            "evaluation_design_shape": list(x_evaluation.shape),
            "evaluation_design_sha256": sha256_bytes(
                np.ascontiguousarray(x_evaluation).tobytes()
            ),
        }
    )
    mean = x_fit.mean(axis=0, dtype="float64").astype("float32")
    scale = x_fit.std(axis=0, dtype="float64").astype("float32")
    scale[~np.isfinite(scale) | (scale <= 0)] = 1.0
    x_evaluation = (x_evaluation - mean) / scale
    _require(
        np.isfinite(x_evaluation).all()
        and sha256_bytes(np.ascontiguousarray(x_evaluation).tobytes())
        == payload.get("evaluation_design_sha256"),
        "F2_COXTIME_HANDOFF_DESIGN_INVALID",
    )
    labtrans = _coxtime_labtrans(models, candidate, fit_time, fit_event, np)
    scaler = {
        "mean": [float(value) for value in mean],
        "scale": [float(value) for value in scale],
    }
    duration_scaler = labtrans.duration_scaler
    labtrans_record = {
        "log_duration": bool(labtrans.log_duration),
        "mean": [float(value) for value in duration_scaler.mean_],
        "scale": [float(value) for value in duration_scaler.scale_],
    }
    _require(
        _sha(candidate) == payload.get("candidate_sha256")
        and _sha(scaler) == payload.get("scaler_sha256")
        and _sha(labtrans_record) == payload.get("labtrans_sha256")
        and payload.get("fit_input_identity")
        == expected_fit_input_identity,
        "F2_COXTIME_HANDOFF_RECIPE_INVALID",
    )
    checkpoints = torch.load(path, map_location="cpu", weights_only=True)
    _require(
        isinstance(checkpoints, list)
        and len(checkpoints) == 300
        and [
            _coxtime_state_sha256(state, torch) for state in checkpoints
        ]
        == payload.get("checkpoint_sha256s"),
        "F2_COXTIME_HANDOFF_CHECKPOINT_INVALID",
    )
    model = _coxtime_model(
        native,
        candidate,
        x_fit.shape[1],
        labtrans,
        300,
        device,
    )
    return {
        "model": model,
        "checkpoints": checkpoints,
        "checkpoint_identity_verified": True,
        "x_evaluation": x_evaluation,
        "labtrans": labtrans,
        "candidate": candidate,
        "device": device,
        "seed": seed,
    }


def _evaluate_coxtime_function_seal(
    sealed: Mapping[str, Any],
    runtime: Mapping[str, Any],
    evaluation_response: Mapping[str, Any],
    validation_contract: Mapping[str, Any],
    np: Any,
    *, evaluation_indices: list[int] | None = None,
) -> dict[str, Any]:
    """The only CoxTime STOP response owner; training is already terminal."""

    _require(
        isinstance(sealed, Mapping)
        and set(sealed) == {"status", "payload", "sha256"}
        and sealed["status"] == "SEALED"
        and _sha(sealed["payload"]) == sealed["sha256"],
        "F2_COXTIME_FUNCTION_SEAL_INVALID",
    )
    _require(
        validation_contract.get("n_control") == 5
        and validation_contract.get("validation_repeat") == 5
        and validation_contract.get("validation_control_seed_offset") == 70_000
        and validation_contract.get("validation_control_seed_rule")
        == "TASK_SEED_PLUS_OFFSET_PLUS_ONE_BASED_REPEAT",
        "F2_COXTIME_VALIDATION_CONTROL_CONTRACT_INVALID",
    )
    payload = sealed["payload"]
    _require(
        isinstance(payload, dict)
        and payload.get("kind") == "PADML_F2_COXTIME_PREDICTION_FUNCTION"
        and payload.get("maximum") == 300
        and len(payload.get("checkpoint_sha256s", [])) == 300
        and set(runtime)
        == {
            "model",
            "checkpoints",
            "checkpoint_identity_verified",
            "x_evaluation",
            "labtrans",
            "candidate",
            "device",
            "seed",
        },
        "F2_COXTIME_FUNCTION_SEAL_INVALID",
    )
    _require(
        runtime["checkpoint_identity_verified"] is True,
        "F2_COXTIME_CHECKPOINT_IDENTITY_INVALID",
    )
    times, events = _response_arrays(
        evaluation_response, list(payload["evaluation_ids"])
    )
    indices = list(range(len(times))) if evaluation_indices is None else evaluation_indices
    times_array = np.asarray(times, dtype="float32")[indices]
    events_array = np.asarray(events, dtype="int32")[indices]
    order = np.argsort(times_array, kind="stable")
    times_array = times_array[order]
    events_array = events_array[order]
    features = np.asarray(runtime["x_evaluation"], dtype="float32")[indices][order]
    transformed_time, _ = runtime["labtrans"].transform(
        times_array, events_array.astype("float32")
    )
    case_indices = np.flatnonzero(events_array == 1)
    _require(
        len(case_indices) > 0 and len(features) == len(times_array),
        "F2_COXTIME_VALIDATION_ROW_SET_INVALID",
    )
    control_sets: list[Any] = []
    for repeat in range(1, 6):
        rng = np.random.RandomState(
            int(runtime["seed"])
            + validation_contract["validation_control_seed_offset"]
            + repeat
        )
        controls = np.empty((len(case_indices), 5), dtype=int)
        for offset, case_index in enumerate(case_indices):
            at_risk = np.flatnonzero(times_array >= times_array[case_index])
            draws = (rng.uniform(size=5) * len(at_risk)).astype(int)
            controls[offset, :] = at_risk[draws]
        control_sets.append(controls)
    model = runtime["model"]
    torch = next(model.net.parameters()).__class__.__module__.split(".")[0]
    _require(torch == "torch", "F2_COXTIME_RUNTIME_INVALID")
    import torch as torch_module  # type: ignore

    case_t = torch_module.as_tensor(
        transformed_time[case_indices].reshape(-1, 1),
        dtype=torch_module.float32,
        device=runtime["device"],
    )
    inference_indices = np.concatenate([case_indices,
        *(controls[:, column] for controls in control_sets for column in range(5))])
    inference_x = torch_module.as_tensor(features[inference_indices],
        dtype=torch_module.float32, device=runtime["device"])
    inference_t = case_t.repeat(26, 1)
    case_count = len(case_indices)
    class GroupedInference(torch_module.nn.Module):
        def __init__(self, network):
            super().__init__()
            self.network = network

        def forward(self, features, times):
            # Preserve each original GEMM's row geometry. Concatenating every
            # control before GEMM changes float32 losses beyond the locked
            # epoch tie tolerance; tracing removes Python dispatch instead.
            return torch_module.cat([self.network(torch_module.cat((features[lo:lo+case_count],
                times[lo:lo+case_count]), dim=1)) for lo in range(0, len(inference_indices), case_count)], dim=0)

    model.net.eval()
    with torch_module.no_grad():
        model.net.load_state_dict(runtime["checkpoints"][0], strict=True)
        probe = model.net(inference_x[:case_count], inference_t[:case_count])
        _require(bool(torch_module.isfinite(probe).all()), "F2_COXTIME_RAW_SCORE_NONFINITE")
        inference = torch_module.jit.trace(GroupedInference(model.net.network),
            (inference_x, inference_t), check_trace=False)
    losses: list[float] = []
    for checkpoint in runtime["checkpoints"]:
        model.net.load_state_dict(checkpoint, strict=True)
        model.net.eval()
        repeat_losses: list[float] = []
        with torch_module.no_grad():
            scores = inference(inference_x, inference_t)
            _require(bool(torch_module.isfinite(scores).all()), "F2_COXTIME_RAW_SCORE_NONFINITE")
            grouped = scores.split(case_count)
            g_case = grouped[0]
            for repeat in range(5):
                control_sum = torch_module.zeros_like(g_case)
                shrink_control = torch_module.zeros((), device=runtime["device"])
                for column in range(5):
                    g_control = grouped[1 + repeat * 5 + column]
                    difference = g_control - g_case
                    _require(bool(torch_module.isfinite(difference).all()), "F2_COXTIME_SCORE_DIFFERENCE_NONFINITE")
                    shrink_control = shrink_control + g_control.abs().mean()
                    control_sum = control_sum + torch_module.exp(
                        torch_module.clamp(difference, -3e38, 80.0)
                    )
                    _require(bool(torch_module.isfinite(shrink_control).all())
                             and bool(torch_module.isfinite(control_sum).all()),
                             "F2_COXTIME_VALIDATION_SUM_NONFINITE")
                loss = torch_module.log1p(control_sum).mean()
                shrink = float(runtime["candidate"]["coxtime_shrink"])
                if shrink:
                    loss = loss + (
                        shrink * (g_case.abs().mean() + shrink_control) / 5
                    ).abs()
                _require(bool(torch_module.isfinite(loss).all()), "F2_COXTIME_VALIDATION_LOSS_INVALID")
                repeat_losses.append(float(loss.detach().cpu()))
        value = math.fsum(repeat_losses) / 5
        _require(
            math.isfinite(value) and value >= 0,
            "F2_COXTIME_VALIDATION_LOSS_INVALID",
        )
        losses.append(value)
    return {
        "schema_version": "1.0.0",
        "kind": "PADML_F2_COXTIME_VALIDATION_CURVE",
        "function_sha256": sealed["sha256"],
        "evaluation_response_sha256": evaluation_response["sha256"],
        "validation_repeat": 5,
        "n_control": 5,
        "validation_control_seed_offset": 70_000,
        "validation_control_seed_rule": "TASK_SEED_PLUS_OFFSET_PLUS_ONE_BASED_REPEAT",
        "losses": losses,
    }


def _run_coxtime_function_pool_task(task: dict[str, Any]) -> dict[str, Any]:
    """Fit one response-free CoxTime curve and persist its checkpoints."""

    _require(
        set(task)
        == {
            "task_id",
            "spec",
            "registered",
            "partition_id",
            "imputation",
            "candidate",
            "seed",
            "handoff_path",
        }
        and not _contains_key(task, "evaluation_response"),
        "F2_COXTIME_POOL_TASK_INVALID",
    )
    for key, value in THREAD_ENV.items():
        os.environ[key] = value
    try:
        import numpy as np  # type: ignore
        import pandas as pd  # type: ignore
        models, torch, tt = _coxtime_native()
    except ImportError as exc:
        raise ContractError("F2_COXTIME_CAPABILITY_UNAVAILABLE") from exc
    imputation = int(task["imputation"])
    loaded = _load_python_registered_partition(
        task["spec"],
        task["registered"],
        task["partition_id"],
        pd,
        np,
        [imputation],
    )
    fit = partial(_coxtime_prediction_function_seal,
        (models, torch, tt),
        task["candidate"],
        _response_free_stop_partition(loaded["partition"]),
        loaded["fit_designs"][0],
        loaded["fit_time"],
        loaded["fit_event"],
        loaded["evaluation_designs"][0],
        int(task["seed"]),
        task["spec"]["backend"],
        np,
        Path(task["handoff_path"]),
    )
    if (task["spec"].get("execution_scope") in {"F4_FULL_PIPELINE_SEARCH", "F5_A12_SEARCH", "F5_FULL_DEVELOPMENT_SEARCH"}
            or "primary_search_source" in task["spec"]):
        from .f4 import _full_pipeline_python_stop_function
        sealed, handoff = _full_pipeline_python_stop_function(task, loaded, fit, np)
    else:
        sealed, handoff = fit()
    result = {
        "task_id": task["task_id"],
        "imputation": imputation,
        "partition_id": task["partition_id"],
        "sealed": sealed,
        "handoff": handoff,
    }
    return {**result, "task_identity_sha256": _sha(result)}


def _run_coxtime_function_evaluator_pool_task(
    task: dict[str, Any],
) -> dict[str, Any]:
    """Validate and score one sealed CoxTime function in the evaluator pool."""

    _require(
        set(task)
        == {
            "task_id",
            "spec",
            "registered",
            "evaluation_partition",
            "partition_id",
            "imputation",
            "candidate",
            "seed",
            "handoff_path",
            "function_result",
        },
        "F2_COXTIME_EVALUATOR_TASK_INVALID",
    )
    for key, value in THREAD_ENV.items():
        os.environ[key] = value
    try:
        import numpy as np  # type: ignore
        import pandas as pd  # type: ignore
        models, torch, tt = _coxtime_native()
    except ImportError as exc:
        raise ContractError("F2_COXTIME_CAPABILITY_UNAVAILABLE") from exc
    imputation = int(task["imputation"])
    produced = task["function_result"]
    body = {
        key: value
        for key, value in produced.items()
        if key != "task_identity_sha256"
    }
    evaluation_partition = task["evaluation_partition"]
    _require(
        isinstance(produced, dict)
        and produced.get("task_id") == task["task_id"]
        and produced.get("partition_id") == task["partition_id"]
        and produced.get("imputation") == imputation
        and produced.get("task_identity_sha256") == _sha(body)
        and isinstance(evaluation_partition, Mapping)
        and evaluation_partition.get("partition_id") == task["partition_id"]
        and isinstance(evaluation_partition.get("fit_response"), Mapping)
        and isinstance(
            evaluation_partition.get("evaluation_response"), Mapping
        ),
        "F2_COXTIME_EVALUATOR_TASK_INVALID",
    )
    loaded = _load_python_registered_partition(
        task["spec"],
        task["registered"],
        task["partition_id"],
        pd,
        np,
        [imputation],
    )
    _require(
        loaded["partition"]["fit_ids"]
        == evaluation_partition["fit_ids"]
        and loaded["partition"]["evaluation_ids"]
        == evaluation_partition["evaluation_ids"],
        "F2_COXTIME_EVALUATOR_PARTITION_INVALID",
    )
    if "native_search_numbers" in task["spec"]:
        from .f4_compact import _full_pipeline_python_stop_evaluate_numbers
        curve = _full_pipeline_python_stop_evaluate_numbers(task, loaded, np)
    else:
        runtime = _coxtime_runtime_from_handoff(
            (models, torch, tt),
            produced["sealed"],
            produced["handoff"],
            task["candidate"],
            loaded["fit_designs"][0],
            loaded["fit_time"],
            loaded["fit_event"],
            loaded["evaluation_designs"][0],
            int(task["seed"]),
            task["spec"]["backend"],
            np,
            expected_path=Path(task["handoff_path"]),
            expected_partition=evaluation_partition,
        )
        evaluate = partial(_evaluate_coxtime_function_seal,
            produced["sealed"],
            runtime,
            evaluation_partition["evaluation_response"],
            task["spec"]["coxtime"]["shared_candidate_parameters"],
            np, evaluation_indices=_development_evaluation_indices(evaluation_partition,
                _selection_horizon_from_spec(task["spec"])),
        )
        if (task["spec"].get("execution_scope") in {"F4_FULL_PIPELINE_SEARCH", "F5_A12_SEARCH", "F5_FULL_DEVELOPMENT_SEARCH"}
            or "primary_search_source" in task["spec"]):
            from .f4 import _full_pipeline_python_stop_evaluate
            curve = _full_pipeline_python_stop_evaluate(task, evaluate, np)
        else:
            curve = evaluate()
        handoff_path = Path(task["handoff_path"])
        handoff_path.unlink()
        handoff_path.parent.rmdir()
    result = {
        "task_id": task["task_id"],
        "imputation": imputation,
        "partition_id": task["partition_id"],
        "function_sha256": produced["sealed"]["sha256"],
        "curve": curve,
    }
    return {**result, "task_identity_sha256": _sha(result)}


def _run_coxtime_refit_pool_task(task: dict[str, Any]) -> dict[str, Any]:
    """Refit one locked CoxTime model without any evaluation response."""

    task_keys = {
            "task_id",
            "spec",
            "registered",
            "partition_id",
            "imputation",
            "candidate",
            "locked_epoch",
            "seed",
        }
    _require(
        set(task)
        in {frozenset(task_keys), frozenset({*task_keys, "prediction_horizons"})}
        and not _contains_key(task, "evaluation_response"),
        "F2_COXTIME_POOL_TASK_INVALID",
    )
    for key, value in THREAD_ENV.items():
        os.environ[key] = value
    try:
        import numpy as np  # type: ignore
        import pandas as pd  # type: ignore
        models, torch, tt = _coxtime_native()
    except ImportError as exc:
        raise ContractError("F2_COXTIME_CAPABILITY_UNAVAILABLE") from exc
    imputation = int(task["imputation"])
    loaded = _load_python_registered_partition(
        task["spec"],
        task["registered"],
        task["partition_id"],
        pd,
        np,
        [imputation],
    )
    prediction_horizons = list(
        task.get("prediction_horizons", task["spec"]["horizons"])
    )
    _require(
        prediction_horizons
        in [
            task["spec"]["horizons"],
            task["spec"].get("monthly_fit_horizons"),
        ],
        "F2_COXTIME_HORIZON_SET_INVALID",
    )
    fit = partial(_coxtime_refit_predict,
        (models, torch, tt),
        task["candidate"],
        loaded["fit_designs"][0],
        loaded["fit_time"],
        loaded["fit_event"],
        loaded["evaluation_designs"][0],
        int(task["locked_epoch"]),
        int(task["seed"]),
        task["spec"]["backend"],
        prediction_horizons,
        np,
    )
    if (task["spec"].get("execution_scope") in {"F4_FULL_PIPELINE_SEARCH", "F5_A12_SEARCH", "F5_FULL_DEVELOPMENT_SEARCH"}
            or "primary_search_source" in task["spec"]):
        from .f4 import _full_pipeline_python_search_refit
        fitted = _full_pipeline_python_search_refit(task, loaded, fit, np, pd)
    else:
        fitted = fit()
    sealed = _seal_prediction_matrix(
        loaded["evaluation_ids"],
        fitted["survival"].tolist(),
        prediction_horizons,
    )
    result = {
        "task_id": task["task_id"],
        "imputation": imputation,
        "partition_id": task["partition_id"],
        "sealed_prediction": sealed,
        "fit_health": fitted["fit_health"],
    }
    return {**result, "task_identity_sha256": _sha(result)}


def _coxtime_locked_seal_record(
    partition: Mapping[str, Any],
    imputation: int,
    locked_epoch: int,
    sealed: Mapping[str, Any],
    fit_health: Mapping[str, Any],
) -> dict[str, Any]:
    observed_health = _validate_python_fit_health(
        "COXTIME_SET_A",
        fit_health,
        locked_value=locked_epoch,
        training_count=len(partition["fit_ids"]),
        evaluation_count=len(sealed["payload"]["patient_ids"]),
    )
    return {
        "partition_id": partition["partition_id"],
        "imputation": imputation,
        "prediction_seal_sha256": sealed["sha256"],
        "stopping": {
            **observed_health,
            "locked_epoch": locked_epoch,
            "stopping_reselected": False,
        },
        "sealed_prediction": dict(sealed),
    }


def _coxtime_evaluate_locked_seal(
    partition: Mapping[str, Any],
    imputation: int,
    locked_epoch: int,
    sealed: Mapping[str, Any],
    fit_health: Mapping[str, Any],
    *, selection_horizon_months: int = 24,
) -> dict[str, Any]:
    record = _coxtime_locked_seal_record(
        partition, imputation, locked_epoch, sealed, fit_health
    )
    metric = _evaluate_prediction_seal(
        _monthly_prediction_seal(sealed),
        fit_response=partition["fit_response"],
        evaluation_response=partition["evaluation_response"],
        selection_horizon_months=selection_horizon_months,
        evaluation_context=_prediction_evaluation_context(partition["fit_response"],
            partition["evaluation_response"], partition["evaluation_ids"],
            selection_horizon_months=selection_horizon_months,
            evaluation_indices=_development_evaluation_indices(partition, selection_horizon_months)),
    )
    return {
        **record,
        "evaluation_response_sha256": partition["evaluation_response"][
            "sha256"
        ],
        "evaluation_ids_sha256": partition["evaluation_ids_sha256"],
        f"ibs_0_{selection_horizon_months}": metric[f"ibs_0_{selection_horizon_months}"],
    }


def _run_python_locked_evaluation_pool_task(
    task: dict[str, Any],
) -> dict[str, Any]:
    """Evaluate one sealed refit; retain its probabilities for MI/OOF pooling."""

    _require(
        set(task)
        == {
            "task_id",
            "family",
            "spec",
            "evaluation_partition",
            "partition_id",
            "imputation",
            "locked_value",
            "sealed_prediction",
            "fit_health",
        }
        and task["family"] in {"XGBOOST_COX", "COXTIME_SET_A"},
        "F2_PYTHON_LOCKED_EVALUATOR_TASK_INVALID",
    )
    for key, value in THREAD_ENV.items():
        os.environ[key] = value
    partition = task["evaluation_partition"]
    _require(
        isinstance(partition, Mapping)
        and partition.get("partition_id") == task["partition_id"]
        and partition.get("evaluation_ids_sha256")
        == _sha(partition.get("evaluation_ids"))
        and isinstance(partition.get("fit_response"), Mapping)
        and isinstance(partition.get("evaluation_response"), Mapping),
        "F2_PYTHON_LOCKED_EVALUATOR_PARTITION_INVALID",
    )
    if task["family"] == "XGBOOST_COX":
        evaluated = _xgb_evaluate_locked_seal(
            task["spec"],
            partition,
            int(task["imputation"]),
            int(task["locked_value"]),
            task["sealed_prediction"],
            task["fit_health"],
        )
    else:
        evaluated = _coxtime_evaluate_locked_seal(
            partition,
            int(task["imputation"]),
            int(task["locked_value"]),
            task["sealed_prediction"],
            task["fit_health"],
            selection_horizon_months=_selection_horizon_from_spec(task["spec"]),
        )
    result = {
        "task_id": task["task_id"],
        "partition_id": task["partition_id"],
        "imputation": int(task["imputation"]),
        "evaluated": evaluated,
    }
    return {**result, "task_identity_sha256": _sha(result)}


def _coxtime_curve_optimum(losses: list[float]) -> int:
    _require(
        len(losses) == 300 and all(math.isfinite(value) for value in losses),
        "F2_COXTIME_VALIDATION_CURVE_INVALID",
    )
    eligible = losses[29:]
    minimum = min(eligible)
    tolerance = 1e-12 + 1e-10 * max(1.0, abs(minimum))
    return next(
        index
        for index, value in enumerate(losses, start=1)
        if index >= 30 and value <= minimum + tolerance
    )


def _coxtime_global_epoch_lock(curves: list[list[list[float]]]) -> dict[str, Any]:
    _require(
        len(curves) == 15
        and all(
            len(partition) == 20
            and all(len(curve) == 300 for curve in partition)
            for partition in curves
        ),
        "F2_COXTIME_EPOCH_LOCK_DENOMINATOR_INVALID",
    )
    averaged = [
        [
            math.fsum(curve[epoch] for curve in partition) / 20
            for epoch in range(300)
        ]
        for partition in curves
    ]
    optima = [_coxtime_curve_optimum(curve) for curve in averaged]
    locked_epoch = sorted(optima)[7]
    lock = {
        "schema_version": "1.0.0",
        "kind": "PADML_F2_COXTIME_GLOBAL_EPOCH_LOCK",
        "partition_count": 15,
        "imputation_count": 20,
        "epoch_count": 300,
        "partition_optima": optima,
        "averaged_curve_sha256s": [_sha(curve) for curve in averaged],
        "locked_epoch": locked_epoch,
    }
    return {**lock, "identity": _sha(lock)}


def _run_python_registered_coxtime(
    spec: dict[str, Any],
    registered: dict[str, Any],
    scratch: Path,
    native: tuple[Any, Any, Any],
    np: Any,
    pd: Any,
    *,
    search_only: bool = False,
    full_pipeline_replicate: int | None = None,
) -> dict[str, Any]:
    _require(spec["family"] == "COXTIME_SET_A", "F2_COXTIME_ROUTE_INVALID")
    full_pipeline_seeds = _full_pipeline_search_seed_registry(spec, search_only, full_pipeline_replicate)
    inner = sorted(
        (row for row in registered["partitions"] if row["kind"] == "INNER"),
        key=lambda row: (row["repeat"], row["inner_fold"]),
    )
    stops = {
        (row["repeat"], row["inner_fold"]): row
        for row in registered["partitions"]
        if row["kind"] == "STOP"
    }
    outer = [row for row in registered["partitions"] if row["kind"] == "OUTER"]
    candidates = spec["candidate_trials"]["S1"]
    _require(
        type(search_only) is bool
        and len(inner) == len(stops) == 15
        and (search_only or len(outer) == 1)
        and len(candidates) == 12
        and [row["candidate_id"] for row in candidates]
        == [f"CT{index:03d}" for index in range(1, 13)],
        "F2_COXTIME_REGISTERED_DENOMINATOR_INVALID",
    )
    for partition in inner:
        stop = stops[(partition["repeat"], partition["inner_fold"])]
        _require(
            stop.get("consumer_set")
            == ["GBM_COX", "XGBOOST_COX", "COXTIME_SET_A"]
            and stop["application_ids"] == partition["fit_ids"],
            "F2_COXTIME_STOP_REFIT_LINK_INVALID",
        )
    inner_accumulator: dict[str, list[dict[str, Any]]] = {}
    stop_accumulator: dict[str, list[dict[str, Any]]] = {}

    def local_lock(
        sealed: Mapping[str, Any],
        curve: Mapping[str, Any],
    ) -> dict[str, Any]:
        selected_epoch = _coxtime_curve_optimum(curve["losses"])
        lock = {
            "schema_version": "1.0.0",
            "kind": "PADML_F2_COXTIME_EPOCH_LOCK",
            "function_sha256": sealed["sha256"],
            "evaluation_response_sha256": curve[
                "evaluation_response_sha256"
            ],
            "selected_epoch": selected_epoch,
            "minimum_validation_loss": min(curve["losses"][29:]),
        }
        return {**lock, "identity": _sha(lock)}

    def evaluate_trials(
        stage: str,
        trial_candidates: list[dict[str, Any]],
        partitions: list[dict[str, Any]],
        imputation_count: int,
        stage_seed: int,
    ) -> list[dict[str, Any]]:
        grouped: list[list[tuple[dict[str, Any], dict[str, Any]]]] = [
            [] for _ in trial_candidates
        ]
        function_tasks: list[dict[str, Any]] = []
        owners: list[int] = []
        full_partitions: list[dict[str, Any]] = []
        raw_stops: list[dict[str, Any]] = []
        for trial_index, candidate in enumerate(trial_candidates):
            for partition_index, partition in enumerate(partitions, start=1):
                stop = stops[(partition["repeat"], partition["inner_fold"])]
                for imputation in range(1, imputation_count + 1):
                    task_seed = (full_pipeline_seeds["stop_seeds"][imputation - 1]
                                 if full_pipeline_seeds else stage_seed + imputation * 100 + partition_index)
                    task_id = (
                        f"{stage}_T{trial_index + 1:03d}_"
                        f"P{partition_index:02d}_M{imputation:02d}_FUNCTION"
                    )
                    function_tasks.append(
                        {
                            "task_id": task_id,
                            "spec": spec,
                            "registered": _engine_registered_partitions(
                                registered, {stop["partition_id"]}
                            ),
                            "partition_id": stop["partition_id"],
                            "imputation": imputation,
                            "candidate": candidate,
                            "seed": task_seed,
                            "handoff_path": str(
                                scratch
                                / "coxtime-quarantine"
                                / _sha({"task_id": task_id, "seed": task_seed})[:24]
                                / "checkpoints.pt"
                            ),
                        }
                    )
                    owners.append(trial_index)
                    full_partitions.append(partition)
                    raw_stops.append(stop)
        evaluator_results = _search_python_stop_batch(
            spec,
            function_tasks,
            raw_stops,
            selected_slots=spec["pool_workers"],
        )
        locks: list[dict[str, Any]] = []
        refit_tasks: list[dict[str, Any]] = []
        for task, partition, stop, produced in zip(
            function_tasks,
            full_partitions,
            raw_stops,
            evaluator_results,
            strict=True,
        ):
            body = {
                key: value
                for key, value in produced.items()
                if key != "task_identity_sha256"
            }
            _require(
                produced.get("task_id") == task["task_id"]
                and produced.get("partition_id") == task["partition_id"]
                and produced.get("imputation") == task["imputation"]
                and produced.get("task_identity_sha256") == _sha(body),
                "F2_COXTIME_POOL_RESULT_INVALID",
            )
            curve = produced.get("curve")
            _require(
                isinstance(curve, dict)
                and isinstance(curve.get("losses"), list)
                and len(curve["losses"]) == 300
                and produced.get("function_sha256")
                == curve.get("function_sha256"),
                "F2_COXTIME_POOL_RESULT_INVALID",
            )
            lock = local_lock(
                {"sha256": produced["function_sha256"]}, curve
            )
            refit_task = {
                "task_id": task["task_id"].removesuffix("_FUNCTION")
                + "_LOCKED_REFIT",
                "spec": spec,
                "registered": _engine_registered_partitions(
                    registered, {partition["partition_id"]}
                ),
                "partition_id": partition["partition_id"],
                "imputation": task["imputation"],
                "candidate": task["candidate"],
                "locked_epoch": lock["selected_epoch"],
                "prediction_horizons": spec["monthly_fit_horizons"],
                "seed": (_full_pipeline_trial_seed(full_pipeline_seeds, stage, task["candidate"])
                         if full_pipeline_seeds else task["seed"]),
            }
            stop_record = {
                "identity": lock["identity"],
                "risk_curve_sha256": produced["function_sha256"],
                "minimum_stopping_loss": lock["minimum_validation_loss"],
            }
            locks.append(lock)
            refit_tasks.append(refit_task)
            stop_accumulator.setdefault(stop["partition_id"], []).append(
                stop_record
            )
        refit_results = _search_task_batch(
            spec,
            _run_coxtime_refit_pool_task,
            refit_tasks,
            selected_slots=spec["pool_workers"],
        )
        for task, produced in zip(refit_tasks, refit_results, strict=True):
            body = {
                key: value
                for key, value in produced.items()
                if key != "task_identity_sha256"
            }
            _require(
                produced.get("task_id") == task["task_id"]
                and produced.get("partition_id") == task["partition_id"]
                and produced.get("imputation") == task["imputation"]
                and produced.get("task_identity_sha256") == _sha(body),
                "F2_COXTIME_POOL_RESULT_INVALID",
            )
        locked_evaluator_tasks = [
            {
                "task_id": task["task_id"],
                "family": "COXTIME_SET_A",
                "spec": spec,
                "evaluation_partition": partition,
                "partition_id": task["partition_id"],
                "imputation": task["imputation"],
                "locked_value": task["locked_epoch"],
                "sealed_prediction": produced["sealed_prediction"],
                "fit_health": produced["fit_health"],
            }
            for task, produced, partition in zip(
                refit_tasks, refit_results, full_partitions, strict=True
            )
        ]
        locked_evaluator_results = _search_task_batch(
            spec,
            _run_python_locked_evaluation_pool_task,
            locked_evaluator_tasks,
            selected_slots=spec["pool_workers"],
        )
        for owner, task, produced, partition, lock in zip(
            owners,
            locked_evaluator_tasks,
            locked_evaluator_results,
            full_partitions,
            locks,
            strict=True,
        ):
            body = {
                key: value
                for key, value in produced.items()
                if key != "task_identity_sha256"
            }
            _require(
                produced.get("task_id") == task["task_id"]
                and produced.get("partition_id") == task["partition_id"]
                and produced.get("imputation") == task["imputation"]
                and produced.get("task_identity_sha256") == _sha(body)
                and isinstance(produced.get("evaluated"), dict),
                "F2_COXTIME_POOL_RESULT_INVALID",
            )
            evaluated = produced["evaluated"]
            evaluated["lock_identity_sha256"] = lock["identity"]
            inner_accumulator.setdefault(partition["partition_id"], []).append(
                evaluated
            )
            grouped[owner].append((evaluated, lock))
        results: list[dict[str, Any]] = []
        scoring_context = _trial_scoring_context(partitions,
            selection_horizon_months=_selection_horizon_from_spec(spec))
        for candidate, values in zip(trial_candidates, grouped, strict=True):
            epochs = [lock["selected_epoch"] for _, lock in values]
            results.append(
                {
                    "stage_id": stage,
                    "candidate_id": candidate["candidate_id"],
                    "candidate_config_sha256": candidate[
                        "candidate_config_sha256"
                    ],
                    "parameters": candidate,
                    "parameter_sha256": _sha(candidate),
                    **_trial_evaluation_summary(
                        [row for row, _ in values], scoring_context, imputation_count
                    ),
                    "selected_epoch_median": _integer_median(epochs),
                }
            )
        return results

    trace: dict[str, list[dict[str, Any]]] = {}
    trace["S1"] = evaluate_trials(
        "S1",
        candidates,
        [row for row in inner if row["repeat"] == 1],
        1,
        spec["seed"] + 10_000,
    )
    top4 = [
        row["parameters"]
        for row in _rank_trials(trace["S1"], retain=4)[:4]
    ]
    trace["S2"] = evaluate_trials(
        "S2",
        top4,
        [row for row in inner if row["repeat"] == 2],
        5,
        spec["seed"] + 20_000,
    )
    top2 = [
        row["parameters"]
        for row in _rank_trials(trace["S2"], retain=2)[:2]
    ]
    trace["S3A"] = evaluate_trials(
        "S3A",
        top2,
        [row for row in inner if row["repeat"] == 3],
        20,
        spec["seed"] + 30_000,
    )
    top2 = [
        row["parameters"]
        for row in _rank_trials(trace["S3A"], retain=2)[:2]
    ]
    trace["S3B1"] = evaluate_trials(
        "S3B1", top2, inner, 5, spec["seed"] + 40_000
    )
    provisional = _rank_trials(trace["S3B1"], retain=1)[0]["parameters"]

    s3b2_function_tasks: list[dict[str, Any]] = []
    s3b2_partitions: list[dict[str, Any]] = []
    s3b2_stops: list[dict[str, Any]] = []
    for partition_index, partition in enumerate(inner, start=1):
        stop = stops[(partition["repeat"], partition["inner_fold"])]
        for imputation in range(1, 21):
            task_seed = (full_pipeline_seeds["stop_seeds"][imputation - 1] if full_pipeline_seeds
                         else spec["seed"] + 50_000 + imputation * 100 + partition_index)
            task_id = f"S3B2_P{partition_index:02d}_M{imputation:02d}_FUNCTION"
            s3b2_function_tasks.append(
                {
                    "task_id": task_id,
                    "spec": spec,
                    "registered": _engine_registered_partitions(
                        registered, {stop["partition_id"]}
                    ),
                    "partition_id": stop["partition_id"],
                    "imputation": imputation,
                    "candidate": provisional,
                    "seed": task_seed,
                    "handoff_path": str(
                        scratch
                        / "coxtime-quarantine"
                        / _sha({"task_id": task_id, "seed": task_seed})[:24]
                        / "checkpoints.pt"
                    ),
                }
            )
            s3b2_partitions.append(partition)
            s3b2_stops.append(stop)
    s3b2_evaluator_results = _search_python_stop_batch(
        spec,
        s3b2_function_tasks,
        s3b2_stops,
        selected_slots=spec["pool_workers"],
    )
    s3b2_curves: list[dict[str, Any]] = []
    for task, produced in zip(
        s3b2_function_tasks, s3b2_evaluator_results, strict=True
    ):
        body = {
            key: value
            for key, value in produced.items()
            if key != "task_identity_sha256"
        }
        _require(
            produced.get("task_id") == task["task_id"]
            and produced.get("partition_id") == task["partition_id"]
            and produced.get("imputation") == task["imputation"]
            and produced.get("task_identity_sha256") == _sha(body),
            "F2_COXTIME_POOL_RESULT_INVALID",
        )
        curve = produced.get("curve")
        _require(
            isinstance(curve, dict)
            and isinstance(curve.get("losses"), list)
            and len(curve["losses"]) == 300
            and produced.get("function_sha256")
            == curve.get("function_sha256"),
            "F2_COXTIME_POOL_RESULT_INVALID",
        )
        s3b2_curves.append(
            {
            "sealed_sha256": produced["function_sha256"],
            "losses": curve["losses"],
            }
        )
    _require(
        len(s3b2_curves) == 300
        and all(len(row["losses"]) == 300 for row in s3b2_curves),
        "F2_COXTIME_GLOBAL_LOCK_DENOMINATOR_INVALID",
    )
    canonical_s3b2_curves = s3b2_curves
    partition_curves = [
        [
            canonical_s3b2_curves[
                partition_index * 20 + imputation
            ]["losses"]
            for imputation in range(20)
        ]
        for partition_index in range(15)
    ]
    global_lock = _coxtime_global_epoch_lock(partition_curves)
    s3b2_refit_tasks = [
        {
            "task_id": task["task_id"].removesuffix("_FUNCTION")
            + "_LOCKED_REFIT",
            "spec": spec,
            "registered": _engine_registered_partitions(
                registered, {partition["partition_id"]}
            ),
            "partition_id": partition["partition_id"],
            "imputation": task["imputation"],
            "candidate": provisional,
            "locked_epoch": global_lock["locked_epoch"],
            "prediction_horizons": spec["monthly_fit_horizons"],
            "seed": (_full_pipeline_trial_seed(full_pipeline_seeds, "S3B2", provisional)
                     if full_pipeline_seeds else task["seed"]),
        }
        for task, partition in zip(
            s3b2_function_tasks, s3b2_partitions, strict=True
        )
    ]
    s3b2_refit_results = _search_task_batch(
            spec,
        _run_coxtime_refit_pool_task,
        s3b2_refit_tasks,
        selected_slots=spec["pool_workers"],
    )
    for task, produced in zip(
        s3b2_refit_tasks, s3b2_refit_results, strict=True
    ):
        body = {
            key: value
            for key, value in produced.items()
            if key != "task_identity_sha256"
        }
        _require(
            produced.get("task_id") == task["task_id"]
            and produced.get("partition_id") == task["partition_id"]
            and produced.get("imputation") == task["imputation"]
            and produced.get("task_identity_sha256") == _sha(body),
            "F2_COXTIME_POOL_RESULT_INVALID",
        )
    s3b2_locked_evaluator_tasks = [
        {
            "task_id": task["task_id"],
            "family": "COXTIME_SET_A",
            "spec": spec,
            "evaluation_partition": partition,
            "partition_id": task["partition_id"],
            "imputation": task["imputation"],
            "locked_value": task["locked_epoch"],
            "sealed_prediction": produced["sealed_prediction"],
            "fit_health": produced["fit_health"],
        }
        for task, produced, partition in zip(
            s3b2_refit_tasks,
            s3b2_refit_results,
            s3b2_partitions,
            strict=True,
        )
    ]
    s3b2_locked_evaluator_results = _search_task_batch(
            spec,
        _run_python_locked_evaluation_pool_task,
        s3b2_locked_evaluator_tasks,
        selected_slots=spec["pool_workers"],
    )
    s3b2_evaluated: list[dict[str, Any]] = []
    for task, produced, partition, stop, curve in zip(
        s3b2_locked_evaluator_tasks,
        s3b2_locked_evaluator_results,
        s3b2_partitions,
        s3b2_stops,
        s3b2_curves,
        strict=True,
    ):
        body = {
            key: value
            for key, value in produced.items()
            if key != "task_identity_sha256"
        }
        _require(
            produced.get("task_id") == task["task_id"]
            and produced.get("partition_id") == task["partition_id"]
            and produced.get("imputation") == task["imputation"]
            and produced.get("task_identity_sha256") == _sha(body)
            and isinstance(produced.get("evaluated"), dict),
            "F2_COXTIME_POOL_RESULT_INVALID",
        )
        evaluated = produced["evaluated"]
        evaluated["lock_identity_sha256"] = global_lock["identity"]
        inner_accumulator.setdefault(partition["partition_id"], []).append(
            evaluated
        )
        stop_accumulator.setdefault(stop["partition_id"], []).append(
            {
                "identity": global_lock["identity"],
                "risk_curve_sha256": curve["sealed_sha256"],
                "minimum_stopping_loss": min(curve["losses"][29:]),
            }
        )
        s3b2_evaluated.append(evaluated)
    s3b2_scoring_context = _trial_scoring_context(inner,
        selection_horizon_months=_selection_horizon_from_spec(spec))
    trace["S3B2"] = [
        {
            "stage_id": "S3B2",
            "candidate_id": provisional["candidate_id"],
            "candidate_config_sha256": provisional["candidate_config_sha256"],
            "parameters": provisional,
            "parameter_sha256": _sha(provisional),
            **_trial_evaluation_summary(s3b2_evaluated, s3b2_scoring_context, 20),
            "validation_curve_count": len(s3b2_curves),
            "locked_refit_dispatch_count": len(s3b2_refit_tasks),
            "global_lock_identity_sha256": global_lock["identity"],
            "locked_epoch": global_lock["locked_epoch"],
            "partition_optima": global_lock["partition_optima"],
            "mi_averaged_curve_sha256_by_partition": global_lock[
                "averaged_curve_sha256s"
            ],
        }
    ]
    if search_only:
        return _shared_full_development_search_result(
            spec,
            registered,
            trace,
            {
                "family": "COXTIME_SET_A",
                "candidate_id": provisional["candidate_id"],
                "parameters": provisional,
                "locked_epoch": global_lock["locked_epoch"],
                "selection_metric": f"IBS_0_{_selection_horizon_from_spec(spec)}",
                "selection_stage": "S3B2",
            },
            full_pipeline_seeds,
        )
    final_tasks = [
        {
            "task_id": f"FINAL_OUTER_M{imputation:02d}",
            "spec": spec,
            "registered": _engine_registered_partitions(
                registered, {outer[0]["partition_id"]}
            ),
            "partition_id": outer[0]["partition_id"],
            "imputation": imputation,
            "candidate": provisional,
            "locked_epoch": global_lock["locked_epoch"],
            "prediction_horizons": spec["monthly_fit_horizons"],
            "seed": spec["seed"] + imputation,
        }
        for imputation in range(1, 21)
    ]
    final_produced = _search_task_batch(
            spec,
        _run_coxtime_refit_pool_task,
        final_tasks,
        selected_slots=spec["pool_workers"],
    )
    final: list[dict[str, Any]] = []
    for task, produced in zip(final_tasks, final_produced, strict=True):
        body = {
            key: value
            for key, value in produced.items()
            if key != "task_identity_sha256"
        }
        _require(
            produced.get("task_id") == task["task_id"]
            and produced.get("partition_id") == task["partition_id"]
            and produced.get("imputation") == task["imputation"]
            and produced.get("task_identity_sha256") == _sha(body),
            "F2_COXTIME_POOL_RESULT_INVALID",
        )
        final.append(
            _coxtime_locked_seal_record(
                outer[0],
                task["imputation"],
                task["locked_epoch"],
                produced["sealed_prediction"],
                produced["fit_health"],
            )
        )
    evaluation_units = sum(
        row["evaluation_units"] for rows in trace.values() for row in rows
    ) + 20
    _require(evaluation_units == 830, "F2_COXTIME_GRAPH_DENOMINATOR_INVALID")
    result = _build_registered_model_result(
        spec,
        registered,
        final,
        selector=spec["selector_from_dependency"],
        search_trace=trace,
        search_evaluation_unit_count=evaluation_units,
        selected_spec={
            "family": "COXTIME_SET_A",
            "candidate_id": provisional["candidate_id"],
            "parameters": provisional,
            "locked_epoch": global_lock["locked_epoch"],
            "selection_metric": "IBS_0_24",
            "selection_stage": "S3B2",
        },
        execution_rows=_registered_stopping_execution_rows(
            registered, inner_accumulator, stop_accumulator
        ),
    )
    parent_response_evaluations = sum(
        row["evaluation_count"]
        for row in result["registered_partition_execution"]["partitions"]
    ) + sum(
        len(row["fold_metric_values"]) + row["ranking_evaluation_count"]
        for values in trace.values() for row in values
    )
    _require(
        parent_response_evaluations == 1783,
        "F2_COXTIME_PARENT_EVALUATION_DENOMINATOR_INVALID",
    )
    result["execution_graph"] = {
        "schema_version": "1.0.0",
        "family": "COXTIME_SET_A",
        "search_budget_evaluation_unit_count": 830,
        "parent_response_evaluation_count": parent_response_evaluations,
        "response_free_function_fit_count": 810,
        "locked_refit_fit_count": 830,
        "total_fit_count": 1640,
        "parent_evaluation_owner": "UNIQUE_LOCAL_PARENT",
        "s3b2_validation_curve_count": 300,
        "s3b2_global_lock_identity_sha256": global_lock["identity"],
    }
    return result


def _validate_coxtime_raw_survival_grid(
    event_times: Sequence[Any],
    values: Sequence[Sequence[Any]],
) -> None:
    """Validate native pycox survival output without repairing its values."""

    times = [float(value) for value in event_times]
    _require(
        times
        and all(math.isfinite(value) for value in times)
        and all(left < right for left, right in zip(times, times[1:])),
        "F2_COXTIME_RAW_SURVIVAL_GRID_INVALID",
    )
    _require(
        len(values) == len(times),
        "F2_COXTIME_RAW_SURVIVAL_GRID_INVALID",
    )
    width: int | None = None
    previous: list[float] | None = None
    for raw_row in values:
        row = [float(value) for value in raw_row]
        if width is None:
            width = len(row)
        _require(
            width > 0
            and len(row) == width
            and all(
                math.isfinite(value) and 0.0 <= value <= 1.0
                for value in row
            )
            and (
                previous is None
                or all(
                    prior + 1e-10 >= current
                    for prior, current in zip(previous, row, strict=True)
                )
            ),
            "F2_COXTIME_RAW_SURVIVAL_GRID_INVALID",
        )
        previous = row


def _coxtime_complete_baseline(model: Any, inputs: Any, target: Any, np: Any) -> tuple[Any, dict[str, Any]]:
    """Full T>=t risk sets, retaining native pycox time scale and float arithmetic."""
    import pandas as pd  # type: ignore

    frame = model.target_to_df(target).reset_index(drop=True)
    times = frame[model.duration_col].to_numpy()
    event = frame[model.event_col].to_numpy()
    _require(len(times) == len(inputs) > 0 and bool(np.isfinite(times).all())
             and bool(np.isfinite(event).all() and np.isin(event, [0, 1]).all())
             and bool((event == 1).any()) and bool((times[1:] >= times[:-1]).all()),
             "F2_COXTIME_BASELINE_INPUT_INVALID")
    event_times = frame.loc[frame[model.event_col] != 0, model.duration_col].drop_duplicates()
    denominators = []
    score_count = 0
    for time in event_times:
        first = int(np.searchsorted(times, time, side="left"))
        sub = inputs[first:]
        time_column = np.repeat(time, len(sub)).reshape(-1, 1).astype("float32")
        scores = np.asarray(model.predict((sub, time_column), 8224, True, True, num_workers=0))
        _require(scores.shape in {(len(sub),), (len(sub), 1)} and bool(np.isfinite(scores).all()),
                 "F2_COXTIME_RAW_SCORE_NONFINITE")
        try:
            with np.errstate(over="raise", invalid="raise", divide="raise"):
                risks = np.exp(scores).flatten()
                denominator = risks.sum()
        except FloatingPointError as exc:
            raise ContractError("F2_COXTIME_RISK_SET_NONFINITE") from exc
        _require(bool(np.isfinite(risks).all() and (risks > 0).all())
                 and bool(np.isfinite(denominator)) and denominator > 0,
                 "F2_COXTIME_RISK_SET_NONFINITE")
        denominators.append(denominator)
        score_count += len(sub)
    risk_sum = pd.Series(denominators, index=event_times.to_numpy())
    events_by_time = frame.groupby(model.duration_col)[model.event_col].sum()
    # Censor-only times have a defined zero increment, not repaired missing data.
    baseline = events_by_time * 0
    baseline.loc[risk_sum.index] = events_by_time.loc[risk_sum.index] / risk_sum
    baseline = baseline.rename("baseline_hazards")
    _require(bool(np.isfinite(baseline.to_numpy()).all() and (baseline >= 0).all()),
             "F2_COXTIME_BASELINE_INVALID")
    model.compute_baseline_cumulative_hazards(set_hazards=True, baseline_hazards_=baseline)
    _require(bool(np.isfinite(model.baseline_cumulative_hazards_.to_numpy()).all()),
             "F2_COXTIME_BASELINE_INVALID")
    return baseline, {"implementation": "FULL_T_GE_T_RISK_SET_V1", "training_rows": len(times),
                      "event_time_groups": len(event_times), "checked_raw_scores": score_count}


def _validate_coxtime_baseline_health(value: Any, training_rows: int) -> None:
    _require(isinstance(value, dict) and set(value) == {
        "implementation", "training_rows", "event_time_groups", "checked_raw_scores"}
        and value.get("implementation") == "FULL_T_GE_T_RISK_SET_V1"
        and type(value.get("training_rows")) is int and value["training_rows"] == training_rows
        and type(value.get("event_time_groups")) is int
        and 1 <= value["event_time_groups"] <= training_rows
        and type(value.get("checked_raw_scores")) is int
        and value["event_time_groups"] <= value["checked_raw_scores"] <= training_rows * value["event_time_groups"],
        "F2_COXTIME_BASELINE_HEALTH_INVALID")


def _coxtime_refit_predict(
    native: tuple[Any, Any, Any],
    candidate: dict[str, Any],
    x_train: Any,
    train_time: Any,
    train_event: Any,
    x_test: Any,
    locked_epoch: int,
    seed: int,
    backend: str,
    horizons: list[int],
    np: Any,
    *, native_capture: Any = None,
) -> dict[str, Any]:
    models, torch, tt = native
    _require(30 <= locked_epoch <= 300, "F2_COXTIME_LOCKED_EPOCH_INVALID")
    device = _coxtime_seed(torch, seed, backend)
    native_scaler = {} if native_capture is not None else None
    x_train, x_test = _coxtime_standardize(x_train, x_test, np=np, native_scaler=native_scaler)
    labtrans = _coxtime_labtrans(models, candidate, train_time, train_event, np)
    target = _coxtime_target(labtrans, train_time, train_event, np)
    model = _coxtime_model(native, candidate, x_train.shape[1], labtrans, locked_epoch, device)

    class Clip(tt.callbacks.Callback):
        def before_step(self) -> bool:
            torch.nn.utils.clip_grad_norm_(model.net.parameters(), max_norm=5.0, norm_type=2.0, error_if_nonfinite=True)
            return False

    training_log = model.fit(
        x_train,
        target,
        batch_size=int(candidate["batch_size"]),
        epochs=locked_epoch,
        callbacks=[Clip()],
        verbose=False,
        num_workers=0,
        shuffle=True,
        val_data=None,
        n_control=5,
    )
    if native_capture is not None:
        native_capture("model", model=model, design=x_train, scaler=native_scaler,
                       labtrans=labtrans, torch=torch)
    training_frame = training_log.to_pandas()
    if native_capture is not None:
        native_capture("training_log", frame=training_frame)
    _require(
        "train_loss" in training_frame.columns,
        "F2_COXTIME_FIT_HEALTH_INVALID",
    )
    training_losses = np.asarray(
        training_frame["train_loss"], dtype=float
    )
    _require(
        len(training_losses) == locked_epoch
        and np.isfinite(training_losses).all(),
        "F2_COXTIME_FIT_HEALTH_INVALID",
    )
    order = np.argsort(np.asarray(target[0]), kind="stable")
    baseline, baseline_health = _coxtime_complete_baseline(
        model, x_train[order], tuple(np.asarray(value)[order] for value in target), np)
    if native_capture is not None:
        native_capture("baseline", baseline=baseline)
    _require(len(baseline) > 0 and np.isfinite(baseline.to_numpy(dtype=float)).all(), "F2_COXTIME_BASELINE_INVALID")
    try:
        with np.errstate(over="raise", invalid="raise", divide="raise"):
            frame = model.predict_surv_df(x_test, baseline_hazards_=baseline, eval_=True, num_workers=0)
    except FloatingPointError as exc:
        raise ContractError("F2_COXTIME_PREDICTION_NONFINITE") from exc
    event_times = np.asarray(frame.index, dtype=float)
    values = frame.to_numpy(dtype=float)
    _validate_coxtime_raw_survival_grid(event_times, values)
    output = np.ones((values.shape[1], len(horizons)), dtype=float)
    for column, horizon in enumerate(horizons):
        index = int(np.searchsorted(event_times, horizon, side="right") - 1)
        if index >= 0:
            output[:, column] = values[index, :]
    _require(
        np.isfinite(output).all()
        and ((0.0 <= output) & (output <= 1.0)).all()
        and (np.diff(output, axis=1) <= 1e-10).all(),
        "F2_COXTIME_PREDICTION_INVALID",
    )
    fit_health = _validate_python_fit_health(
        "COXTIME_SET_A",
        {
            "engine": "pycox.models.CoxTime",
            "converged": True,
            "training_epoch_count": len(training_losses),
            "final_training_loss": float(training_losses[-1]),
            "model_state_sha256": _coxtime_state_sha256(
                model.net.state_dict(), torch
            ),
            "raw_survival_grid_validated": True,
            "baseline_numerics": baseline_health,
            "training_row_count": len(x_train),
            "evaluation_row_count": len(x_test),
        },
        locked_value=locked_epoch,
        training_count=len(x_train),
        evaluation_count=len(x_test),
    )
    return {"survival": output, "fit_health": fit_health}










def _locked_family_parameters(family: str, locked_spec: Mapping[str, Any]) -> dict[str, Any]:
    """Project a sealed family specification onto the existing engine ABI."""
    _require(
        isinstance(locked_spec, Mapping) and locked_spec.get("family") == family,
        "LOCKED_FAMILY_SPEC_INVALID",
    )
    if family == "COX_PH":
        _require(locked_spec.get("ties") == "breslow", "LOCKED_COX_SPEC_INVALID")
        return {}
    if family == "ELASTIC_NET_COX":
        alpha = locked_spec.get("alpha")
        ratios = locked_spec.get("ratio_by_imputation")
        lambdas = locked_spec.get("lambda_by_imputation")
        upper_bounds = locked_spec.get("lambda_upper_bound_by_imputation")
        _require(
            _finite_number(alpha) and 0.01 <= alpha <= 1
            and isinstance(ratios, list) and len(ratios) == 20
            and all(_finite_number(ratio) and 0.0001 <= ratio <= 1 for ratio in ratios),
            "LOCKED_ELASTIC_SPEC_INVALID",
        )
        _require(
            isinstance(lambdas, list)
            and len(lambdas) == 20
            and all(_finite_number(value) and value > 0 for value in lambdas)
            and isinstance(upper_bounds, list)
            and len(upper_bounds) == 20,
            "LOCKED_ELASTIC_SPEC_INVALID",
        )
        _require(
            all(
                isinstance(provenance, Mapping)
                and _finite_number(provenance.get("resolved_lambda_max"))
                and provenance["resolved_lambda_max"] > 0
                and math.isclose(
                    float(lambda_value),
                    float(provenance["resolved_lambda_max"]) * float(ratio),
                    rel_tol=1e-10,
                    abs_tol=1e-12,
                )
                for lambda_value, provenance, ratio in zip(
                    lambdas, upper_bounds, ratios, strict=True
                )
            ),
            "LOCKED_ELASTIC_SPEC_INVALID",
        )
        return {
            "alpha": float(alpha),
            "ratio_by_imputation": list(ratios),
            "lambda_by_imputation": list(lambdas),
            "lambda_upper_bound_by_imputation": list(upper_bounds),
        }
    if family in {"RSF", "GBM_COX", "XGBOOST_COX"}:
        parameters = locked_spec.get("parameters")
        _require(isinstance(parameters, dict) and parameters, "LOCKED_TREE_SPEC_INVALID")
        projected = _engine_parameters(family, dict(parameters))
        if family == "GBM_COX":
            locked_trees = locked_spec.get("selected_trees")
            _require(
                isinstance(locked_trees, int) and not isinstance(locked_trees, bool)
                and locked_trees > 0,
                "LOCKED_GBM_TREE_COUNT_INVALID",
            )
            projected["locked_trees"] = locked_trees
        return projected
    if family == "FPM_TVC_SET_A":
        _require(
            locked_spec.get("df") == [3, 1]
            and locked_spec.get("tvc_parent") == "AST_ALT",
            "LOCKED_FPM_SPEC_INVALID",
        )
        return {}
    if family == "COXTIME_SET_A":
        parameters = locked_spec.get("parameters")
        _require(isinstance(parameters, dict) and parameters, "LOCKED_COXTIME_SPEC_INVALID")
        return dict(parameters)
    raise ContractError("LOCKED_FAMILY_SPEC_INVALID")


def _locked_family_frame_contract(
    *,
    imputation_set: Sequence[Mapping[str, Any]],
    evaluation_rows: Sequence[Mapping[str, Any]],
    selected_parents: Sequence[str],
    time_col: str,
    event_col: str,
) -> tuple[list[Any], Any, list[str]]:
    try:
        import pandas as pd  # type: ignore
    except ImportError as exc:
        raise ContractError("LOCKED_FAMILY_PANDAS_CAPABILITY_UNAVAILABLE") from exc
    selected = list(selected_parents)
    _require(
        bool(imputation_set) and len(imputation_set) in {1, 5, 20}
        and selected and len(selected) == len(set(selected)) and "AST_ALT" in selected
        and bool(evaluation_rows),
        "LOCKED_FAMILY_DATA_INPUT_INVALID",
    )
    frames: list[Any] = []
    fit_ids: list[str] | None = None
    fit_response: list[tuple[float, int]] | None = None
    for raw in imputation_set:
        _require(
            isinstance(raw, Mapping) and set(raw) == {"frame"},
            "LOCKED_FAMILY_IMPUTATION_SCHEMA_INVALID",
        )
        frame = raw["frame"]
        _require(
            isinstance(frame, pd.DataFrame)
            and {"Patient_ID", "Center", time_col, event_col, *selected}.issubset(frame.columns)
            and not frame.empty,
            "LOCKED_FAMILY_TRAINING_FRAME_INVALID",
        )
        current_ids = frame["Patient_ID"].astype(str).tolist()
        current_response = [
            (float(time), int(event))
            for time, event in frame[[time_col, event_col]].itertuples(index=False, name=None)
        ]
        _require(
            len(current_ids) == len(set(current_ids)) and all(current_ids)
            and all(math.isfinite(time) and time > 0 and event in {0, 1} for time, event in current_response)
            and (fit_ids is None or current_ids == fit_ids)
            and (fit_response is None or current_response == fit_response),
            "LOCKED_FAMILY_TRAINING_IDENTITY_DRIFT",
        )
        fit_ids = current_ids if fit_ids is None else fit_ids
        fit_response = current_response if fit_response is None else fit_response
        frames.append(frame.copy())
    evaluation = pd.DataFrame([dict(row) for row in evaluation_rows])
    _require(
        {"row_key", "center", *selected}.issubset(evaluation.columns)
        and time_col not in evaluation.columns and event_col not in evaluation.columns,
        "LOCKED_FAMILY_EVALUATION_FRAME_INVALID",
    )
    row_keys = evaluation["row_key"].astype(str).tolist()
    _require(
        len(row_keys) == len(set(row_keys)) and all(row_keys),
        "LOCKED_FAMILY_ROW_UNIVERSE_INVALID",
    )
    return frames, evaluation, row_keys


def _execute_locked_r_family(
    *,
    family: str,
    locked_spec: Mapping[str, Any],
    imputation_set: Sequence[Mapping[str, Any]],
    evaluation_rows: Sequence[Mapping[str, Any]],
    selected_parents: Sequence[str],
    predictors: Mapping[str, Any],
    transform_recipe: Mapping[str, Any] | None,
    horizons: Sequence[int],
    seeds: Sequence[int],
    time_col: str,
    event_col: str,
    fpm_contract: Mapping[str, Any] | None,
    scratch: Path,
) -> dict[str, Any]:
    """Run an already-selected R family through the C2 recipe-aware owner."""
    try:
        import pandas as pd  # type: ignore
    except ImportError as exc:
        raise ContractError("LOCKED_R_PANDAS_CAPABILITY_UNAVAILABLE") from exc
    frames, evaluation, row_keys = _locked_family_frame_contract(
        imputation_set=imputation_set, evaluation_rows=evaluation_rows,
        selected_parents=selected_parents, time_col=time_col, event_col=event_col,
    )
    transformed = family in {"COX_PH", "ELASTIC_NET_COX", "FPM_TVC_SET_A"}
    recipe = (
        _validate_transform_recipe(dict(transform_recipe), predictors)
        if transformed and isinstance(transform_recipe, Mapping) else None
    )
    _require(
        family in _R_FAMILIES
        and ((transformed and recipe is not None) or (not transformed and transform_recipe is None))
        and len(frames) == len(seeds),
        "LOCKED_R_OWNER_INPUT_INVALID",
    )
    parameters = _locked_family_parameters(family, locked_spec)
    token = _sha({
        "family": family, "selected_spec": dict(locked_spec),
        "selected_parents": list(selected_parents), "horizons": list(horizons),
        "seeds": list(seeds), "row_keys": row_keys,
    })[:20]
    root = scratch / f"locked-r-{token}"
    root.mkdir(mode=0o700, parents=True)
    try:
        covariate_root = root / "covariates"
        covariate_root.mkdir(mode=0o700)
        fit_ids = [f"FIT::{index:06d}" for index in range(len(frames[0]))]
        evaluation_ids = [f"EVAL::{index:06d}" for index in range(len(evaluation))]
        selected_columns = [column for column in frames[0].columns if column not in {time_col, event_col}]
        _require(
            {"Patient_ID", "Center", *selected_parents}.issubset(selected_columns),
            "LOCKED_R_OWNER_COLUMN_SET_INVALID",
        )
        for index, frame in enumerate(frames, start=1):
            _require(
                [column for column in frame.columns if column not in {time_col, event_col}] == selected_columns,
                "LOCKED_R_OWNER_COLUMN_ORDER_DRIFT",
            )
            training = frame[selected_columns].copy()
            training["Patient_ID"] = fit_ids
            application = evaluation.rename(columns={"row_key": "Patient_ID", "center": "Center"}).reindex(columns=selected_columns)
            _require(not application.isna().any().any(), "LOCKED_R_OWNER_EVALUATION_COLUMN_MISSING")
            application = application.copy()
            application["Patient_ID"] = evaluation_ids
            pd.concat([training, application], ignore_index=True).to_csv(
                covariate_root / f"imp{index:02d}.csv", index=False
            )
        response_path = root / "fit-response.csv"
        response_frame = pd.DataFrame({
            "Patient_ID": fit_ids,
            "All_Cause_Death": frames[0][event_col].astype(int).tolist(),
            "Death_Followup_months": frames[0][time_col].astype(float).tolist(),
        })
        response_frame.to_csv(response_path, index=False, lineterminator="\n")
        response_record = {
            "path": str(response_path), "event_count": int(response_frame["All_Cause_Death"].sum()),
            "row_count": len(fit_ids), "row_ids_sha256": _sha(fit_ids),
            "sha256": sha256_file(response_path), "size_bytes": response_path.stat().st_size,
        }
        partition_id = f"LOCKED::{token}"
        descriptor = {
            "kind": "OUTER", "partition_id": partition_id, "repeat": 0, "inner_fold": 0,
            "fit_ids": fit_ids, "evaluation_ids": evaluation_ids,
            "evaluation_ids_sha256": _sha(evaluation_ids),
            "application_ids": [*fit_ids, *evaluation_ids],
            "covariates": {"input_dir": str(covariate_root)},
            "fit_response": response_record,
        }
        registered = {
            "schema_version": "1.0.0", "kind": "PADML_F2_REGISTERED_PARTITION_INPUTS",
            "status": "PASS", "fold": 1, "outer_count": 1, "inner_count": 15,
            "stop_count": 15, "diagnostic_count": 5, "view_count": 62,
            "partitions": [descriptor], "diagnostic_partitions": [],
            "projected_partition_ids": [partition_id], "projected_partition_count": 1,
        }
        output_path = root / "result.json"
        spec = {
            "action": "LOCKED_FAMILY_EXECUTION", "output_path": str(output_path),
            "fold": 1, "family": family, "heldout_center": 0,
            "time": time_col, "outcome": event_col, "seed": int(seeds[0]),
            "threads": 1, "imputation_count": len(frames), "predictors": dict(predictors),
            "registered_partitions": registered, "selected_parents": list(selected_parents),
            "selector_from_dependency": {"selected_parents": list(selected_parents)},
            "locked_parameters": parameters, "locked_seeds": list(seeds),
            "horizons": list(horizons), "transform_recipe": recipe,
            "fpm": dict(fpm_contract) if fpm_contract is not None else None,
        }
        spec_path = root / "spec.json"
        spec_path.write_bytes(canonical_json_bytes(spec))
        environment = dict(os.environ)
        environment.update(THREAD_ENV)
        completed = subprocess.run(
            [RSCRIPT_EXECUTABLE, str(Path(__file__).resolve().parent / "kernels/f2_model_development.R"), str(spec_path)],
            cwd=Path(__file__).resolve().parent, env=environment,
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
            check=False, timeout=6 * 60 * 60,
        )
        if completed.returncode != 0 or not output_path.is_file():
            raise ContractError(_r_failure_reason(completed, "LOCKED_R_OWNER_EXECUTION_FAILED"))
        produced = strict_json_bytes(output_path.read_bytes(), "locked-r-result.json")
        _require(
            isinstance(produced, dict) and produced.get("kind") == "PADML_LOCKED_FAMILY_EXECUTION"
            and produced.get("status") == "PASS" and produced.get("family") == family
            and produced.get("patient_ids") == evaluation_ids
            and produced.get("horizons") == list(horizons),
            "LOCKED_R_OWNER_RESULT_INVALID",
        )
        survival = produced.get("survival")
        _require(isinstance(survival, list) and len(survival) == len(row_keys), "LOCKED_R_OWNER_RESULT_INVALID")
        return {
            "backend": "R", "family": family, "fit_count": produced["fit_count"],
            "model_search_performed": False,
            "predictions": [
                {"row_key": row_key, "survival": values}
                for row_key, values in zip(row_keys, survival, strict=True)
            ],
            "retained_model_binary_count": 0,
            "stopping_and_convergence": produced["stopping_and_convergence"], "threads": 1,
        }
    finally:
        shutil.rmtree(root, ignore_errors=True)


def _execute_locked_python_family(
    *,
    family: str,
    locked_spec: Mapping[str, Any],
    imputation_set: Sequence[Mapping[str, Any]],
    evaluation_rows: Sequence[Mapping[str, Any]],
    selected_parents: Sequence[str],
    predictors: Mapping[str, Any],
    horizons: Sequence[int],
    seeds: Sequence[int],
    time_col: str,
    event_col: str,
) -> dict[str, Any]:
    try:
        import numpy as np  # type: ignore
        import pandas as pd  # type: ignore
    except ImportError as exc:
        raise ContractError("LOCKED_PYTHON_BASE_CAPABILITY_UNAVAILABLE") from exc
    frames, evaluation, row_keys = _locked_family_frame_contract(
        imputation_set=imputation_set, evaluation_rows=evaluation_rows,
        selected_parents=selected_parents, time_col=time_col, event_col=event_col,
    )
    _require(
        family in {"XGBOOST_COX", "COXTIME_SET_A"} and len(frames) == len(seeds),
        "LOCKED_PYTHON_OWNER_INPUT_INVALID",
    )
    spec = {
        "family": family, "selector_from_dependency": {"selected_parents": list(selected_parents)},
        "predictors": dict(predictors), "outcome": event_col, "time": time_col,
    }
    evaluation_frame = evaluation.rename(columns={"row_key": "Patient_ID", "center": "Center"})
    pooled = np.zeros((len(evaluation_frame), len(horizons)), dtype=float)
    stopping: list[dict[str, Any]] = []
    parameters = _locked_family_parameters(family, locked_spec)
    for index, (frame, seed) in enumerate(zip(frames, seeds, strict=True), start=1):
        designs, _ = _prepare_python_design(
            spec, [frame.drop(columns=[time_col, event_col]), evaluation_frame], pd
        )
        x_train, x_test = (design.to_numpy(dtype=float) for design in designs)
        train_time = frame[time_col].to_numpy(dtype=float)
        train_event = frame[event_col].to_numpy(dtype=int)
        if family == "XGBOOST_COX":
            try:
                import xgboost as xgb  # type: ignore
            except ImportError as exc:
                raise ContractError("LOCKED_XGBOOST_CAPABILITY_UNAVAILABLE") from exc
            locked = locked_spec.get("selected_rounds")
            _require(isinstance(locked, int) and locked > 0, "LOCKED_XGBOOST_ROUNDS_INVALID")
            fitted = _xgb_refit_predict(
                xgb, parameters, x_train, train_time, train_event, x_test,
                locked, int(seed), "CPU", list(horizons), np,
            )
            stopping.append({
                **fitted["fit_health"],
                "imputation": index,
                "locked_rounds": locked,
                "seed": int(seed),
                "search_performed": False,
            })
        else:
            try:
                models, torch, tt = _coxtime_native()
            except ImportError as exc:
                raise ContractError("LOCKED_COXTIME_CAPABILITY_UNAVAILABLE") from exc
            locked = locked_spec.get("locked_epoch")
            _require(isinstance(locked, int) and locked >= 30, "LOCKED_COXTIME_EPOCH_INVALID")
            fitted = _coxtime_refit_predict(
                (models, torch, tt), parameters, x_train, train_time, train_event,
                x_test, locked, int(seed), "CPU", list(horizons), np,
            )
            stopping.append({
                **fitted["fit_health"],
                "imputation": index,
                "locked_epoch": locked,
                "seed": int(seed),
                "search_performed": False,
            })
        pooled += np.asarray(fitted["survival"], dtype=float)
    pooled /= len(frames)
    return {
        "backend": "PYTHON", "family": family, "fit_count": len(frames),
        "model_search_performed": False,
        "predictions": [
            {"row_key": row_key, "survival": pooled[index].tolist()}
            for index, row_key in enumerate(row_keys)
        ],
        "retained_model_binary_count": 0,
        "stopping_and_convergence": stopping, "threads": 1,
    }


def _execute_locked_family(
    *,
    family: str,
    locked_spec: Mapping[str, Any],
    imputation_set: Sequence[Mapping[str, Any]],
    evaluation_rows: Sequence[Mapping[str, Any]],
    selected_parents: Sequence[str],
    predictors: Mapping[str, Any],
    transform_recipe: Mapping[str, Any] | None,
    horizons: Sequence[int],
    seed_namespace: Mapping[str, Any],
    time_col: str,
    event_col: str,
    scratch: Path,
    fpm_contract: Mapping[str, Any] | None = None,
    threads: int = 1,
) -> dict[str, Any]:
    """Execute one sealed family specification without search or fallback."""
    _require(
        family in F2_FAMILIES and locked_spec.get("family") == family and threads == 1
        and list(horizons) == sorted(set(horizons))
        and all(isinstance(value, int) and not isinstance(value, bool) and value >= 0 for value in horizons)
        and isinstance(seed_namespace, Mapping) and set(seed_namespace) == {"namespace", "seeds"}
        and isinstance(seed_namespace["namespace"], str) and bool(seed_namespace["namespace"])
        and isinstance(seed_namespace["seeds"], list)
        and len(seed_namespace["seeds"]) == len(imputation_set)
        and all(isinstance(seed, int) and not isinstance(seed, bool) and seed > 0 for seed in seed_namespace["seeds"]),
        "LOCKED_FAMILY_EXECUTION_CONTRACT_INVALID",
    )
    if family in _R_FAMILIES:
        produced = _execute_locked_r_family(
            family=family, locked_spec=locked_spec, imputation_set=imputation_set,
            evaluation_rows=evaluation_rows, selected_parents=selected_parents,
            predictors=predictors, transform_recipe=transform_recipe, horizons=horizons,
            seeds=seed_namespace["seeds"], time_col=time_col, event_col=event_col,
            fpm_contract=fpm_contract, scratch=scratch,
        )
    else:
        _require(transform_recipe is None, "LOCKED_RAW_FAMILY_RECIPE_FORBIDDEN")
        produced = _execute_locked_python_family(
            family=family, locked_spec=locked_spec, imputation_set=imputation_set,
            evaluation_rows=evaluation_rows, selected_parents=selected_parents,
            predictors=predictors, horizons=horizons, seeds=seed_namespace["seeds"],
            time_col=time_col, event_col=event_col,
        )
    row_keys = [str(row["row_key"]) for row in evaluation_rows]
    _require(
        set(produced) == {
            "backend", "family", "fit_count", "model_search_performed", "predictions",
            "retained_model_binary_count", "stopping_and_convergence", "threads",
        }
        and produced["family"] == family and produced["fit_count"] == len(imputation_set)
        and produced["model_search_performed"] is False
        and produced["retained_model_binary_count"] == 0 and produced["threads"] == 1
        and [row.get("row_key") for row in produced["predictions"]] == row_keys,
        "LOCKED_FAMILY_OWNER_RESULT_INVALID",
    )
    finite_count = 0
    for row in produced["predictions"]:
        values = row.get("survival")
        _require(
            isinstance(values, list) and len(values) == len(horizons)
            and all(
                isinstance(value, (int, float)) and not isinstance(value, bool)
                and math.isfinite(float(value)) and 0.0 <= float(value) <= 1.0
                for value in values
            )
            and all(float(left) + 1e-10 >= float(right) for left, right in zip(values, values[1:])),
            "LOCKED_FAMILY_PREDICTION_INVALID",
        )
        finite_count += len(values)
    selected_spec_sha256 = _sha(dict(locked_spec))
    row_universe_sha256 = _sha(row_keys)
    projection = {
        "family": family, "selected_spec_sha256": selected_spec_sha256,
        "row_universe_sha256": row_universe_sha256, "horizons": list(horizons),
        "predictions": produced["predictions"],
    }
    return {
        **produced, "horizons": list(horizons),
        "numeric_qc": {"finite_count": finite_count, "prediction_count": finite_count},
        "prediction_sha256": _sha(projection), "row_universe_sha256": row_universe_sha256,
        "seed_namespace": dict(seed_namespace), "selected_spec_sha256": selected_spec_sha256,
        "selected_parent_sha256": _sha(list(selected_parents)),
        "transform_recipe_sha256": (
            transform_recipe["recipe_sha256"] if isinstance(transform_recipe, Mapping) else "RAW_CANONICAL"
        ),
        "backend_fallback": False,
    }


_LOCAL_PARAMETER_ORDER = {
    "RSF": ("num.trees", "mtry_fraction", "min.node.size", "max.depth", "sample.fraction"),
    "GBM_COX": ("interaction.depth", "shrinkage", "n.minobsinnode", "bag.fraction", "n.trees.max"),
    "XGBOOST_COX": ("eta", "max_depth", "min_child_weight", "subsample", "colsample_bytree", "reg_lambda", "reg_alpha", "gamma", "max_nrounds"),
}


def _p2c2t_model_grid(model_values: list[dict[str, Any]]) -> list[dict[str, Any]]:
    _require(len(model_values) == 42, "F2_P2C2T_DENOMINATOR_INVALID")
    expected = {(fold, family) for fold in range(1, 7) for family in F2_FAMILIES}
    keys = [(row.get("fold"), row.get("family")) for row in model_values]
    _require(set(keys) == expected and len(keys) == len(set(keys)), "F2_P2C2T_MODEL_SET_INVALID")
    for row in model_values:
        _require(
            row.get("artifact_kind") == "F2_MODEL_DEVELOPMENT"
            and row.get("status") == "PASS"
            and isinstance(row.get("selected_spec"), dict)
            and row.get("selected_spec_sha256") == _sha(row["selected_spec"])
            and row.get("heldout_outcome_read_count_for_selection") == 0,
            "F2_P2C2T_MODEL_RESULT_INVALID",
        )
    return sorted(model_values, key=lambda row: (row["fold"], F2_FAMILIES.index(row["family"])))


def _trace_stage(row: dict[str, Any], stage: str, count: int | None = None) -> list[dict[str, Any]]:
    trace = row.get("search_trace")
    values = trace.get(stage) if isinstance(trace, dict) else None
    _require(isinstance(values, list) and (count is None or len(values) == count), f"F2_P2C2T_TRACE_INVALID:{row['fold']}:{row['family']}:{stage}")
    for value in values:
        _require(isinstance(value, dict) and isinstance(value.get("parameters"), dict), f"F2_P2C2T_TRACE_INVALID:{row['fold']}:{row['family']}:{stage}")
    return values


def _center_candidates(row: dict[str, Any], contract: dict[str, Any]) -> list[dict[str, Any]]:
    family = row["family"]
    if family in contract["fixed_formal_families"]:
        return [{"candidate_rank": 1, "selected_spec": row["selected_spec"], "selected_spec_sha256": row["selected_spec_sha256"]}]
    _require(family in contract["complex_s3b1_families"], "F2_P2C2T_CENTER_FAMILY_SCOPE_INVALID")
    values = _trace_stage(row, "S3B1", 2)
    result = []
    for index, value in enumerate(values, start=1):
        selected_spec = {
            "family": family,
            "candidate_id": value.get("candidate_id", value.get("trial_id")),
            "parameters": value["parameters"],
            "selection_stage": "S3B1",
        }
        _require(isinstance(selected_spec["candidate_id"], str) and selected_spec["candidate_id"], f"F2_P2C2T_CENTER_CANDIDATE_ID_MISSING:{row['fold']}:{family}")
        if family == "GBM_COX":
            selected_spec["selected_trees"] = value.get("selected_trees_median")
        elif family == "XGBOOST_COX":
            selected_spec["selected_rounds"] = value.get("selected_rounds_median")
        elif family == "COXTIME_SET_A":
            selected_spec["locked_epoch"] = value.get("selected_epoch_median")
        _require(
            (family == "GBM_COX" and isinstance(selected_spec.get("selected_trees"), int))
            or (family == "XGBOOST_COX" and isinstance(selected_spec.get("selected_rounds"), int))
            or (family == "COXTIME_SET_A" and isinstance(selected_spec.get("locked_epoch"), int))
            or family == "RSF",
            f"F2_P2C2T_CENTER_STOPPING_LOCK_MISSING:{row['fold']}:{family}",
        )
        result.append({
            "candidate_rank": index,
            "selected_spec": selected_spec,
            "selected_spec_sha256": _sha(selected_spec),
        })
    return result


def _formal_candidate_registry(row: dict[str, Any]) -> list[dict[str, Any]]:
    """Project the ordered S1/S2 candidate registry consumed by A04 adjacency."""

    trace = row.get("search_trace")
    _require(isinstance(trace, dict), f"F2_P2C2T_LOCAL_TRACE_INVALID:{row['fold']}:{row['family']}")
    registry: list[dict[str, Any]] = []
    for stage in ("S1", "S2"):
        values = trace.get(stage)
        _require(isinstance(values, list) and values, f"F2_P2C2T_LOCAL_TRACE_INVALID:{row['fold']}:{row['family']}:{stage}")
        for value in values:
            candidate_id = value.get("candidate_id", value.get("trial_id")) if isinstance(value, dict) else None
            parameters = value.get("parameters") if isinstance(value, dict) else None
            _require(
                isinstance(candidate_id, str) and candidate_id and isinstance(parameters, dict) and parameters,
                f"F2_P2C2T_LOCAL_CANDIDATE_INVALID:{row['fold']}:{row['family']}:{stage}",
            )
            registry.append({
                "candidate_id": candidate_id,
                "parameters": parameters,
                "registry_order_index": len(registry) + 1,
            })
    candidate_ids = [value["candidate_id"] for value in registry]
    _require(len(candidate_ids) == len(set(candidate_ids)), f"F2_P2C2T_LOCAL_CANDIDATE_DUPLICATE:{row['fold']}:{row['family']}")
    locked_id = row["selected_spec"].get("candidate_id")
    _require(candidate_ids.count(locked_id) == 1, f"F2_P2C2T_LOCAL_LOCK_NOT_REGISTERED:{row['fold']}:{row['family']}:candidate_id")
    return registry


def _next_distinct_candidate(
    registry: list[dict[str, Any]],
    *,
    locked_index: int,
    parameter: str,
    step: int,
) -> dict[str, Any] | None:
    locked_value = registry[locked_index]["parameters"].get(parameter)
    position = locked_index + step
    if not 0 <= position < len(registry):
        return None
    candidate = registry[position]
    if parameter not in candidate["parameters"] or candidate["parameters"][parameter] == locked_value:
        return None
    return candidate


def _p2c2t_model_design_source(model: Mapping[str, Any]) -> dict[str, Any]:
    selector = model.get("selector_evidence")
    model_input = model.get("model_input")
    family_design_binding = model.get("family_design_binding")
    _require(
        isinstance(selector, Mapping)
        and isinstance(model_input, Mapping)
        and isinstance(family_design_binding, Mapping)
        and selector.get("selected_parent_sha256")
        == _sha(selector.get("selected_parents"))
        and model_input.get("registered_input_identity")
        == model.get("lineage", {}).get("f1_registered_partition_identity"),
        "F2_P2C2T_MODEL_DESIGN_SOURCE_INVALID",
    )
    recipes = selector.get("recipe_set", {}).get("recipes")
    _require(
        isinstance(recipes, list)
        and len(recipes) == 16
        and selector.get("recipe_set_sha256")
        == selector.get("recipe_set", {}).get("recipe_set_sha256"),
        "F2_P2C2T_MODEL_DESIGN_SOURCE_INVALID",
    )
    recipe_by_partition = {
        row.get("partition_id"): row for row in recipes if isinstance(row, dict)
    }

    def source_recipe(partition_id: str) -> dict[str, Any]:
        recipe = recipe_by_partition.get(partition_id)
        _require(isinstance(recipe, dict), "F2_P2C2T_MODEL_DESIGN_SOURCE_INVALID")
        return {
            "consumer_partition_id": partition_id,
            "recipe_partition_id": recipe["partition_id"],
            "recipe_sha256": recipe["recipe_sha256"],
            "analysis_view_sha256": recipe["analysis_view_sha256"],
            "analysis_ids_sha256": recipe["analysis_ids_sha256"],
            "fit_ids_sha256": recipe["fit_ids_sha256"],
        }

    model_partitions = model_input.get("model_partitions")
    diagnostic_partitions = model_input.get("diagnostic_partitions")
    _require(
        isinstance(model_partitions, list)
        and isinstance(diagnostic_partitions, list),
        "F2_P2C2T_MODEL_DESIGN_SOURCE_INVALID",
    )
    local_partitions = sorted(
        (
            row
            for row in model_partitions
            if row.get("kind") == "INNER" and row.get("repeat") == 1
        ),
        key=lambda row: row["inner_fold"],
    )
    outer = [row for row in model_partitions if row.get("kind") == "OUTER"]
    center_scopes = sorted(
        (
            {
                "partition_id": row["partition_id"],
                "analysis_view_sha256": row["analysis_view_sha256"],
                "analysis_ids_sha256": row["analysis_ids_sha256"],
                "fit_ids_sha256": row["fit_ids_sha256"],
            }
            for row in diagnostic_partitions
        ),
        key=lambda row: row["partition_id"].encode("utf-8"),
    )
    center_expectations = model_input.get("center_recipe_expectations", {}).get(
        "recipes"
    )
    _require(
        len(local_partitions) == 5
        and len(outer) == 1
        and len(center_scopes) == 5,
        "F2_P2C2T_MODEL_DESIGN_SOURCE_INVALID",
    )
    _require(
        isinstance(center_expectations, list)
        and len(center_expectations) == 5
        and [row.get("partition_id") for row in center_expectations]
        == [row["partition_id"] for row in center_scopes],
        "F2_P2C2T_MODEL_DESIGN_SOURCE_INVALID",
    )
    outer_recipe = source_recipe(outer[0]["partition_id"])
    _require(
        outer_recipe["recipe_sha256"] == selector.get("outer_recipe_sha256"),
        "F2_P2C2T_MODEL_DESIGN_SOURCE_INVALID",
    )
    return {
        "family_design_binding_sha256": _sha(dict(family_design_binding)),
        "selector_evidence_sha256": _selector_evidence_science_identity(selector),
        "selected_parent_sha256": selector["selected_parent_sha256"],
        "registered_input_identity": model_input["registered_input_identity"],
        "selector_recipe_set_sha256": selector["recipe_set_sha256"],
        "outer_recipe": outer_recipe,
        "local_recipe_bindings": [
            source_recipe(row["partition_id"]) for row in local_partitions
        ],
        "center_recipe_scopes": center_scopes,
        "center_recipe_bindings": [
            {
                "consumer_partition_id": recipe["partition_id"],
                "recipe_partition_id": recipe["partition_id"],
                "recipe_sha256": recipe["recipe_sha256"],
                "analysis_view_sha256": recipe["analysis_view_sha256"],
                "analysis_ids_sha256": recipe["analysis_ids_sha256"],
                "fit_ids_sha256": recipe["fit_ids_sha256"],
            }
            for recipe in center_expectations
        ],
    }


def compile_p2c2t_registry(
    component: str,
    model_values: list[dict[str, Any]],
    request: dict[str, Any],
    contract: dict[str, Any],
    coxtime: dict[str, Any],
    *, current_lock_scope: bool = False,
) -> dict[str, Any]:
    """Compile the finite result-dependent registry before any diagnostic fit."""

    _require(component in F2_COMPONENTS, "F2_P2C2T_COMPONENT_INVALID")
    _require(type(current_lock_scope) is bool, "F2_P2C2T_SCOPE_MODE_INVALID")
    if current_lock_scope:
        from .f5_a04_current import (validate_current_scope_rows,
            current_scope_id, bind_current_registry_task)
        models = validate_current_scope_rows(model_values)
    else:
        models = _p2c2t_model_grid(model_values)
    def scope_name(row):
        return current_scope_id(row) if current_lock_scope else f"F{row['fold']}::{row['family']}"
    indexed_models = [(row['fixed_model_ordinal'] if current_lock_scope else index, row)
                      for index, row in enumerate(models, start=1)]
    scoped_models = models if component != "LOCAL_PERTURBATION" else [row for row in models if row["family"] in contract["local_registry_families"]]
    scopes = [
        {
            "scope_id": scope_name(row),
            "fold": row["fold"],
            "family": row["family"],
            "selected_spec_sha256": row["selected_spec_sha256"],
            "design_source": row["design_source"] if current_lock_scope else _p2c2t_model_design_source(row),
        }
        for row in scoped_models
    ]
    tasks: list[dict[str, Any]] = []
    if component == "CENTER_BLOCKED_STRESS":
        owner = contract["components"][component]
        _require(
            owner
            == {
                "covariate_source": "OUTER_APPLICATION_M20",
                "estimand_id": "F2_P2C2T_CENTER_BLOCKED_STRESS",
                "family_change": False,
                "imputations": 20,
                "locked": [
                    "MICE",
                    "PREPROCESSING",
                    "SELECTOR",
                    "TUNING",
                    "TREE_ROUND_EPOCH",
                ],
                "retuning": False,
                "selection_effect": "NONE",
            },
            "F2_P2C2T_CENTER_OWNER_INVALID",
        )
        for model_index, row in indexed_models:
            scope_id = scope_name(row)
            for candidate in _center_candidates(row, contract):
                tasks.append({
                    "task_id": f"CENTER::{scope_id}::RANK_{candidate['candidate_rank']}::M20",
                    "scope_id": scope_id,
                    "fold": row["fold"],
                    "family": row["family"],
                    "candidate_rank": candidate["candidate_rank"],
                    "imputations": owner["imputations"],
                    "seed": request["seed"] + model_index * 1000 + candidate["candidate_rank"] * 100,
                    "selected_spec": candidate["selected_spec"],
                    "selected_spec_sha256": candidate["selected_spec_sha256"],
                    "selection_effect": "NONE",
                })
    elif component == "LOCKED_MODEL_SAMPLE_SIZE_DIAGNOSTIC":
        owner = contract["components"][component]
        fractions = owner["sample_fractions"]
        _require(
            owner["seed_count"] == 3
            and fractions == [0.40, 0.60, 0.80, 1.00]
            and owner["nesting_strata"] == "PRE_REGISTERED_PRIVATE_ID_REGISTRY"
            and owner["imputations"] == 20
            and owner["refit"] == "LOCKED_SPECIFICATION_ON_PRE_REGISTERED_SAMPLE",
            "F2_P2C2T_SAMPLE_SIZE_OWNER_INVALID",
        )
        for model_index, row in indexed_models:
            scope_id = scope_name(row)
            for seed_ordinal in range(1, 4):
                for fraction in fractions:
                    seed = request["seed"] + model_index * 1000 + seed_ordinal * 100
                    tasks.append({
                        "task_id": f"SAMPLE_SIZE::{scope_id}::SEED_{seed_ordinal}::FRACTION_{fraction:.2f}",
                        "scope_id": scope_id,
                        "fold": row["fold"],
                        "family": row["family"],
                        "seed_ordinal": seed_ordinal,
                        "seed": seed,
                        "sample_fraction": fraction,
                        "imputations": 20,
                        "nesting_strata": "PRE_REGISTERED_PRIVATE_ID_REGISTRY",
                        "forbidden_rerun": owner["forbidden_rerun"],
                        "selected_spec": row["selected_spec"],
                        "selected_spec_sha256": row["selected_spec_sha256"],
                        "selection_effect": "NONE",
                    })
    else:
        owner = contract["components"][component]
        maximum = owner["maximum_configurations_per_model"]
        _require(
            owner.get("candidate_rule") == "ADJACENT_REGISTERED_VALUES_ONLY"
            and owner.get("parameter_order") == "REGISTRY_ORDER"
            and owner.get("deduplicate") is True
            and owner.get("percentage_perturbation") == "FORBIDDEN"
            and owner.get("boundary_expansion") == "FORBIDDEN"
            and owner.get("retuning") is False,
            "F2_P2C2T_LOCAL_OWNER_INVALID",
        )
        for model_index, row in indexed_models:
            family = row["family"]
            if family not in contract["local_registry_families"]:
                continue
            scope_id = scope_name(row)
            locked = row["selected_spec"]
            candidates: list[dict[str, Any]] = []
            if family == "COXTIME_SET_A":
                candidate_ids = coxtime["set_a_candidate_ids"]
                locked_id = locked.get("candidate_id")
                _require(locked_id in candidate_ids, f"F2_P2C2T_LOCAL_LOCK_NOT_REGISTERED:{scope_id}:candidate_id")
                position = candidate_ids.index(locked_id)
                for candidate_position in (position - 1, position + 1):
                    if 0 <= candidate_position < len(candidate_ids):
                        candidate = next(value for value in coxtime["candidates"] if value["candidate_id"] == candidate_ids[candidate_position])
                        candidates.append({
                            "parameter_name": "candidate_id",
                            "locked_registry_order_index": position + 1,
                            "candidate_registry_order_index": candidate_position + 1,
                            "candidate_registry_candidate_id": candidate["candidate_id"],
                            "candidate_value": candidate["candidate_id"],
                            "selected_spec": {**locked, "candidate_id": candidate["candidate_id"], "parameters": candidate},
                        })
            else:
                registry = _formal_candidate_registry(row)
                locked_id = locked.get("candidate_id")
                locked_position = next(index for index, value in enumerate(registry) if value["candidate_id"] == locked_id)
                for parameter in _LOCAL_PARAMETER_ORDER[family]:
                    locked_value = locked["parameters"][parameter]
                    _require(registry[locked_position]["parameters"].get(parameter) == locked_value, f"F2_P2C2T_LOCAL_LOCK_VALUE_DRIFT:{scope_id}:{parameter}")
                    for step in (-1, 1):
                        adjacent = _next_distinct_candidate(registry, locked_index=locked_position, parameter=parameter, step=step)
                        if adjacent is not None:
                            candidate_value = adjacent["parameters"][parameter]
                            parameters = {**locked["parameters"], parameter: candidate_value}
                            candidates.append({
                                "parameter_name": parameter,
                                "locked_registry_order_index": locked_position + 1,
                                "candidate_registry_order_index": adjacent["registry_order_index"],
                                "candidate_registry_candidate_id": adjacent["candidate_id"],
                                "candidate_value": candidate_value,
                                "selected_spec": {**locked, "parameters": parameters},
                            })
            deduplicated: list[dict[str, Any]] = []
            seen: set[str] = set()
            for candidate in candidates:
                identity = _sha(candidate["selected_spec"])
                if identity not in seen:
                    seen.add(identity)
                    deduplicated.append({**candidate, "selected_spec_sha256": identity})
            selected_candidates = deduplicated[:maximum]
            _require(selected_candidates and len(selected_candidates) <= maximum, f"F2_P2C2T_LOCAL_CARDINALITY_INVALID:{scope_id}")
            for candidate in selected_candidates:
                tasks.append({
                    "task_id": f"LOCAL::{scope_id}::{candidate['parameter_name']}::ORDER_{candidate['candidate_registry_order_index']}",
                    "scope_id": scope_id,
                    "fold": row["fold"],
                    "family": family,
                    "parameter_name": candidate["parameter_name"],
                    "locked_registry_order_index": candidate["locked_registry_order_index"],
                    "candidate_registry_order_index": candidate["candidate_registry_order_index"],
                    "candidate_registry_candidate_id": candidate["candidate_registry_candidate_id"],
                    "candidate_value": candidate["candidate_value"],
                    "imputations": 20,
                    "seed": request["seed"] + model_index * 1000 + candidate["candidate_registry_order_index"] * 10,
                    "selected_spec": candidate["selected_spec"],
                    "selected_spec_sha256": candidate["selected_spec_sha256"],
                    "selection_effect": "NONE",
                })
    if current_lock_scope:
        sources = {scope_name(row): row for row in models}
        tasks = [bind_current_registry_task(sources[task['scope_id']], task) for task in tasks]
    task_ids = [row["task_id"] for row in tasks]
    _require(len(task_ids) == len(set(task_ids)) and all(row["selection_effect"] == "NONE" for row in tasks), "F2_P2C2T_TASK_REGISTRY_INVALID")
    if component == "LOCKED_MODEL_SAMPLE_SIZE_DIAGNOSTIC":
        _require(len(tasks) == len(models) * 3 * 4 and all(sum(row["scope_id"] == scope["scope_id"] for row in tasks) == 12 for scope in scopes), "F2_P2C2T_SAMPLE_SIZE_DENOMINATOR_INVALID")
    registry = {"component": component, "population_scope": "OUTER_APPLICATION_RESPONSE_SEALED", "scope_count": len(scopes), "scopes": scopes, "task_count": len(tasks), "tasks": tasks}
    if component == "LOCAL_PERTURBATION":
        owner = contract["components"][component]
        registry.update({
            "candidate_rule": owner["candidate_rule"],
            "parameter_order": owner["parameter_order"],
            "deduplicate": owner["deduplicate"],
            "percentage_perturbation": owner["percentage_perturbation"],
            "boundary_expansion": owner["boundary_expansion"],
            "retuning": owner["retuning"],
        })
    if current_lock_scope:
        registry.update(kind='PADML_A04_CURRENT_PRIMARY_P2C2T_REGISTRY_V1',
            scope_policy='FOUR_HORIZONS_SIX_ORIGINAL_PRIMARY_LOCKS',
            source_locks=[row['source'] for row in models],
            complete_24_scope_coverage=(len(models)==24))
    registry["registry_sha256"] = _sha(registry)
    return registry


def _p2c2t_sample_registered_partition(
    registered: dict[str, Any],
    *,
    sample_ids: list[str],
    response_csv: bytes,
    task: Mapping[str, Any],
    destination: Path,
) -> dict[str, Any]:
    """Project one pre-registered sample onto the immutable OUTER application view."""

    outer_rows = [row for row in registered["partitions"] if row["kind"] == "OUTER"]
    _require(len(outer_rows) == 1, "F2_P2C2T_SAMPLE_OUTER_INVALID")
    outer = outer_rows[0]
    evaluation_ids = list(outer["evaluation_ids"])
    application_ids = [*sample_ids, *evaluation_ids]
    _require(
        sample_ids
        and len(sample_ids) == len(set(sample_ids))
        and set(sample_ids).issubset(outer["fit_ids"])
        and set(sample_ids).isdisjoint(evaluation_ids)
        and len(application_ids) == len(set(application_ids)),
        "F2_P2C2T_SAMPLE_REGISTRY_INVALID",
    )
    destination.mkdir(mode=0o700)
    covariates = destination / "covariates"
    covariates.mkdir(mode=0o700)
    source = Path(outer["covariates"]["input_dir"])
    _require(
        source.is_absolute() and source.is_dir() and source.resolve(strict=True) == source,
        "F2_P2C2T_SAMPLE_SOURCE_INVALID",
    )
    members: list[dict[str, Any]] = []
    for imputation in range(1, 21):
        source_path = source / f"imp{imputation:02d}.csv"
        with source_path.open(encoding="utf-8-sig", newline="") as handle:
            reader = csv.DictReader(handle)
            rows = list(reader)
            by_id = {row.get("Patient_ID", ""): row for row in rows}
            _require(
                reader.fieldnames is not None
                and len(by_id) == len(rows)
                and all(patient_id in by_id for patient_id in application_ids)
                and "All_Cause_Death" not in reader.fieldnames
                and "Death_Followup_months" not in reader.fieldnames,
                "F2_P2C2T_SAMPLE_SOURCE_INVALID",
            )
            target = covariates / f"imp{imputation:02d}.csv"
            with target.open("x", encoding="utf-8", newline="") as output:
                writer = csv.DictWriter(
                    output, fieldnames=reader.fieldnames, lineterminator="\n"
                )
                writer.writeheader()
                for patient_id in application_ids:
                    writer.writerow(by_id[patient_id])
        members.append(
            {
                "name": target.name,
                "sha256": sha256_file(target),
                "size_bytes": target.stat().st_size,
            }
        )
    fields, response_by_id = _response_rows(response_csv)
    partition_id = f"P2C2T_SAMPLE_{_sha(dict(task))[:24]}"
    fit_response = _write_response_subset(
        fields,
        response_by_id,
        sample_ids,
        destination / "fit-response.csv",
    )
    descriptor = {
        "kind": "OUTER",
        "partition_id": partition_id,
        "repeat": 0,
        "inner_fold": 0,
        "fit_ids": list(sample_ids),
        "evaluation_ids": evaluation_ids,
        "evaluation_ids_sha256": _sha(evaluation_ids),
        "application_ids": application_ids,
        "covariates": {
            "schema_version": "1.0.0",
            "kind": "PADML_F2_REGISTERED_VIEW_BINDING",
            "status": "PASS",
            "partition_id": partition_id,
            "analysis_view_sha256": outer["covariates"]["analysis_view_sha256"],
            "application_view_sha256": outer["covariates"]["application_view_sha256"],
            "analysis_ids_sha256": _sha(sample_ids),
            "application_ids_sha256": _sha(application_ids),
            "input_dir": str(covariates),
            "members": members,
            "data_identity": _sha(members),
        },
        "fit_response": fit_response,
        "evaluation_response": dict(outer["evaluation_response"]),
    }
    return {
        **registered,
        "partitions": [descriptor],
        "diagnostic_partitions": [],
    }


def _run_p2c2t_atomic_pool_task(job: dict[str, Any]) -> dict[str, Any]:
    """Run one P2C2T atomic fit and evaluation inside the sole 24-pool."""

    _require(
        set(job)
        == {
            "route",
            "top_task_id",
            "atomic_task_id",
            "spec",
            "registered",
            "evaluation_partition",
            "fit_task",
            "scratch",
            "repo_root",
        }
        and job["route"] in {"R", "XGBOOST_COX", "COXTIME_SET_A"}
        and job["fit_task"].get("task_id") == job["atomic_task_id"],
        "F2_P2C2T_ATOMIC_TASK_INVALID",
    )
    route = job["route"]
    if route == "R":
        rows = _run_r_prediction_partition_batch(
            job["spec"],
            job["registered"],
            [job["fit_task"]],
            Path(job["scratch"]),
            Path(job["repo_root"]),
            evaluation_mode="IBS",
            evaluation_partition=job["evaluation_partition"],
            preserve_native=job["fit_task"]["family"] == "FPM_TVC_SET_A",
        )
        _require(len(rows) == 1, "F2_P2C2T_ATOMIC_RESULT_INVALID")
        evaluated = rows[0]
    else:
        fit = (
            _run_xgb_refit_pool_task(job["fit_task"])
            if route == "XGBOOST_COX"
            else _run_coxtime_refit_pool_task(job["fit_task"])
        )
        fit_body = {
            key: value
            for key, value in fit.items()
            if key != "task_identity_sha256"
        }
        _require(
            fit.get("task_id") == job["atomic_task_id"]
            and fit.get("partition_id")
            == job["evaluation_partition"]["partition_id"]
            and fit.get("imputation") == job["fit_task"]["imputation"]
            and fit.get("task_identity_sha256") == _sha(fit_body),
            "F2_P2C2T_ATOMIC_RESULT_INVALID",
        )
        locked_field = (
            "locked_rounds" if route == "XGBOOST_COX" else "locked_epoch"
        )
        evaluated_row = _run_python_locked_evaluation_pool_task(
            {
                "task_id": job["atomic_task_id"],
                "family": route,
                "spec": job["spec"],
                "evaluation_partition": job["evaluation_partition"],
                "partition_id": job["evaluation_partition"]["partition_id"],
                "imputation": job["fit_task"]["imputation"],
                "locked_value": job["fit_task"][locked_field],
                "sealed_prediction": fit["sealed_prediction"],
                "fit_health": fit["fit_health"],
            }
        )
        evaluated_body = {
            key: value
            for key, value in evaluated_row.items()
            if key != "task_identity_sha256"
        }
        _require(
            evaluated_row.get("task_id") == job["atomic_task_id"]
            and evaluated_row.get("task_identity_sha256")
            == _sha(evaluated_body)
            and isinstance(evaluated_row.get("evaluated"), dict),
            "F2_P2C2T_ATOMIC_RESULT_INVALID",
        )
        evaluated = evaluated_row["evaluated"]
    result = {
        "top_task_id": job["top_task_id"],
        "atomic_task_id": job["atomic_task_id"],
        "evaluated": evaluated,
    }
    return {**result, "task_identity_sha256": _sha(result)}


def _run_p2c2t_atomic_window(
    plans: list[dict[str, Any]],
    *, retained_rows: Mapping[str, dict[str, Any]] | None = None,
    retained_root: Path | None = None,
    atomic_worker=None,
) -> list[list[dict[str, Any]]]:
    """Flatten one bounded canonical P2C2T window into its sole process pool."""

    _require(
        1 <= len(plans) <= 8
        and all(
            plan.get("kind") == "PADML_F2_P2C2T_ATOMIC_JOB_PLAN"
            and type(plan.get("pool_workers")) is int
            and plan["pool_workers"] >= 1
            and plan.get("engine_threads") == 1
            and isinstance(plan.get("jobs"), list)
            and len(plan["jobs"]) == plan.get("expected_fit_count")
            for plan in plans
        )
        and len({plan["task_id"] for plan in plans}) == len(plans)
        and len({plan["pool_workers"] for plan in plans}) == 1,
        "F2_P2C2T_ATOMIC_WINDOW_INVALID",
    )
    jobs = [job for plan in plans for job in plan["jobs"]]
    _require(
        jobs
        and len({job["atomic_task_id"] for job in jobs}) == len(jobs)
        and all(
            job.get("top_task_id") == plan["task_id"]
            for plan in plans
            for job in plan["jobs"]
        ),
        "F2_P2C2T_ATOMIC_WINDOW_INVALID",
    )
    retained_rows = dict(retained_rows or {})
    if retained_root is not None:
        _require(retained_root.is_absolute() and retained_root.is_dir()
                 and retained_root.resolve(strict=True) == retained_root
                 and not retained_root.is_symlink(), "F2_FPM_RETAINED_PATH_INVALID")
        for job in jobs:
            path = retained_root / f"{_sha(job['atomic_task_id'])}.zip"
            if path.exists() or path.is_symlink():
                row = _replay_p2c2t_fpm_artifact(job, path)
                old = retained_rows.get(job["atomic_task_id"])
                _require(old is None or old == row, "F2_FPM_RETAINED_RESULT_CONFLICT")
                retained_rows[job["atomic_task_id"]] = row
    missing_jobs = [job for job in jobs if job["atomic_task_id"] not in retained_rows]

    def accept(index: int, row: dict[str, Any]) -> None:
        job = missing_jobs[index]
        _validate_p2c2t_atomic_result(job, row)
        if job.get("route") == "R" and job["fit_task"]["family"] == "FPM_TVC_SET_A":
            native_root = Path(job["scratch"]) / f"f2-r-batch-{_sha([job['atomic_task_id']])[:16]}"
            entries = {
                "fixed-task.json": canonical_json_bytes(job["fit_task"]),
                "engine-spec.json": (native_root / "spec.json").read_bytes(),
                "consumer-result.json": canonical_json_bytes(row),
                "output.json": (native_root / "output.json").read_bytes(),
            }
            _require(_retained_p2c2t_fpm(job, entries) == row, "F2_FPM_RETAINED_RESULT_CONFLICT")
            if retained_root is not None:
                # Existing native ZIP publication fsyncs data and parent before
                # this callback acknowledges completion or destroys scratch.
                write_deterministic_zip(retained_root / f"{_sha(job['atomic_task_id'])}.zip", entries)
            shutil.rmtree(native_root)

    fresh_rows = _bounded_ordered_spawn(
        _run_p2c2t_atomic_pool_task if atomic_worker is None else atomic_worker,
        missing_jobs,
        selected_slots=plans[0]["pool_workers"],
        on_result=accept,
    ) if missing_jobs else []
    by_id = {**retained_rows, **{row["atomic_task_id"]: row for row in fresh_rows}}
    rows = [by_id[job["atomic_task_id"]] for job in jobs]
    _require(
        len(rows) == len(jobs),
        "F2_P2C2T_ATOMIC_WINDOW_RESULT_INVALID",
    )
    by_top_task = {plan["task_id"]: [] for plan in plans}
    for job, row in zip(jobs, rows, strict=True):
        _validate_p2c2t_atomic_result(job, row)
        by_top_task[job["top_task_id"]].append(row["evaluated"])
    _require(
        all(
            len(by_top_task[plan["task_id"]])
            == plan["expected_fit_count"]
            for plan in plans
        ),
        "F2_P2C2T_ATOMIC_WINDOW_RESULT_INVALID",
    )
    return [by_top_task[plan["task_id"]] for plan in plans]


def _validate_p2c2t_atomic_result(job: Mapping[str, Any], row: Mapping[str, Any]) -> None:
    body = {key: value for key, value in row.items() if key != "task_identity_sha256"}
    _require(row.get("top_task_id") == job["top_task_id"]
             and row.get("atomic_task_id") == job["atomic_task_id"]
             and row.get("task_identity_sha256") == _sha(body)
             and isinstance(row.get("evaluated"), dict), "F2_P2C2T_ATOMIC_WINDOW_RESULT_INVALID")


def _replay_p2c2t_fpm_artifact(job: Mapping[str, Any], path: Path) -> dict[str, Any]:
    """Replay durable raw bytes through the existing consumer, without fitting."""
    _require(path.is_file() and not path.is_symlink()
             and path.resolve(strict=True) == path, "F2_FPM_RETAINED_PATH_INVALID")
    entries = read_safe_zip(path)
    _require(set(entries) == {"fixed-task.json", "engine-spec.json", "consumer-result.json", "output.json"},
             "F2_FPM_RETAINED_NATIVE_OUTPUT_REQUIRED")
    row = _retained_p2c2t_fpm(job, entries)
    root = Path(job["scratch"]) / f"replay-fpm-{_sha(job['atomic_task_id'])[:16]}"
    root.mkdir(mode=0o700)
    (root / "spec.json").write_bytes(entries["engine-spec.json"])
    (root / "output.json").write_bytes(entries["output.json"])
    evaluated = _consume_r_prediction(strict_json_bytes(entries["output.json"]), job["spec"],
                                     job["registered"], [job["fit_task"]], root, "IBS",
                                     job["evaluation_partition"])
    _require(evaluated == [row["evaluated"]], "F2_FPM_RETAINED_NATIVE_RESULT_MISMATCH")
    return row


def _p2c2t_registered_task_result(
    *,
    task: dict[str, Any],
    contract_task: dict[str, Any],
    model: dict[str, Any],
    registered: dict[str, Any],
    science: dict[str, Any],
    predictors: dict[str, Any],
    scratch: Path,
    repo_root: Path,
    route_record: Mapping[str, Any],
    center_recipe_set: Mapping[str, Any] | None = None,
    atomic_job_plan: bool = False,
    evaluated_override: list[dict[str, Any]] | None = None,
    pool_workers: int,
) -> dict[str, Any]:
    """Evaluate one locked diagnostic task on canonical registered partitions."""

    _require(
        type(atomic_job_plan) is bool
        and atomic_job_plan == (evaluated_override is None),
        "F2_P2C2T_ATOMIC_PLAN_STATE_INVALID",
    )

    family = task["family"]
    selector = model["selector_evidence"]
    selected = task["selected_spec"]
    if task["component"] == "CENTER_BLOCKED_STRESS":
        partitions = sorted(
            registered["diagnostic_partitions"],
            key=lambda row: row["validation_center"],
        )
    elif task["component"] == "LOCAL_PERTURBATION":
        partitions = sorted(
            (
                row
                for row in registered["partitions"]
                if row["kind"] == "INNER" and row["repeat"] == 1
            ),
            key=lambda row: row["inner_fold"],
        )
    else:
        partitions = list(registered["partitions"])
    expected_partition_count = (
        1
        if task["component"] == "LOCKED_MODEL_SAMPLE_SIZE_DIAGNOSTIC"
        else 5
    )
    _require(
        len(partitions) == expected_partition_count,
        "F2_P2C2T_REGISTERED_PARTITION_DENOMINATOR_INVALID",
    )
    profile = route_record.get("profile")
    _require(
        isinstance(profile, dict),
        "F2_P2C2T_ROUTE_PROFILE_DEFERRED",
    )
    task_execution = execution_contract({
        "action": "P2C2T",
        "coordinates": [{"axis": "execution_mode", "value": execution_mode(profile)}],
        "internal_threads": pool_workers,
    })
    spec = {
        "schema_version": "1.0.0",
        "family": family,
        "fold": task["fold"],
        "seed": task["seed"],
        "backend": "CPU",
        **task_execution,
        "outcome": science["population"]["outcome"],
        "time": science["population"]["time"],
        "horizons": list(range(1, 37)),
        "monthly_fit_horizons": list(range(1, 37)),
        "heldout_center": science["population"]["validation_centers"][
            task["fold"] - 1
        ],
        "selector_from_dependency": selector,
        "selector_contract": science["f2_model_development"]["selector_contract"],
        "predictors": predictors,
        "fpm": science["fpm"] if family == "FPM_TVC_SET_A" else None,
        "coxtime": (
            science["f2_model_development"]["coxtime"]
            if family == "COXTIME_SET_A"
            else None
        ),
    }
    atomic_jobs: list[dict[str, Any]] = []
    if family in _R_FAMILIES:
        transform_recipe_by_partition: dict[str, dict[str, Any]] = {}
        if family in {"ELASTIC_NET_COX", "COX_PH", "FPM_TVC_SET_A"}:
            main_recipe_set = _validate_transform_recipe_set(
                selector.get("recipe_set"),
                predictors,
                expected_count=16,
            )
            if task["component"] == "CENTER_BLOCKED_STRESS":
                center_recipe_set = _validate_transform_recipe_set(
                    center_recipe_set,
                    predictors,
                    expected_count=5,
                )
                transform_recipe_by_partition = {
                    partition["partition_id"]: _recipe_by_partition(
                        center_recipe_set,
                        partition["partition_id"],
                    )
                    for partition in partitions
                }
            elif task["component"] == "LOCAL_PERTURBATION":
                transform_recipe_by_partition = {
                    partition["partition_id"]: _recipe_by_partition(
                        main_recipe_set,
                        partition["partition_id"],
                    )
                    for partition in partitions
                }
            else:
                outer_recipe = _outer_recipe_from_selector(selector, predictors)
                transform_recipe_by_partition = {
                    partition["partition_id"]: outer_recipe
                    for partition in partitions
                }
        if atomic_job_plan:
            if family in {"RSF", "GBM_COX", "ELASTIC_NET_COX"}:
                parameters = _locked_family_parameters(family, selected)
            else:
                parameters = {}
            producer_tasks: list[dict[str, Any]] = []
            for partition_index, partition in enumerate(partitions, start=1):
                for imputation in range(1, task["imputations"] + 1):
                    producer_task = {
                        "task_id": (
                            f"{task['task_id']}::P{partition_index:02d}::"
                            f"M{imputation:02d}"
                        ),
                        "partition_id": partition["partition_id"],
                        "imputation": imputation,
                        "family": family,
                        "selected_parents": selector["selected_parents"],
                        "parameters": parameters,
                        "seed": task["seed"] + partition_index * 1000 + imputation,
                    }
                    if partition["partition_id"] in transform_recipe_by_partition:
                        recipe = transform_recipe_by_partition[
                            partition["partition_id"]
                        ]
                        producer_task["transform_recipe"] = recipe
                        if (
                            task["component"]
                            == "LOCKED_MODEL_SAMPLE_SIZE_DIAGNOSTIC"
                        ):
                            producer_task["fixed_representation_source"] = {
                                "kind": "PADML_F2_OUTER_FIXED_REPRESENTATION",
                                "purpose": (
                                    "LOCKED_MODEL_SAMPLE_SIZE_DIAGNOSTIC"
                                ),
                                "recipe_partition_id": recipe["partition_id"],
                                "recipe_sha256": recipe["recipe_sha256"],
                            }
                    producer_tasks.append(producer_task)
            partition_by_id = {
                row["partition_id"]: row for row in partitions
            }
            child_spec = _r_prediction_child_spec(spec)
            atomic_jobs = [
                {
                    "route": "R",
                    "top_task_id": task["task_id"],
                    "atomic_task_id": producer_task["task_id"],
                    "spec": child_spec,
                    "registered": _engine_registered_partitions(
                        registered, {producer_task["partition_id"]}
                    ),
                    "evaluation_partition": partition_by_id[
                        producer_task["partition_id"]
                    ],
                    "fit_task": producer_task,
                    "scratch": str(scratch),
                    "repo_root": str(repo_root),
                }
                for producer_task in producer_tasks
            ]
    elif atomic_job_plan:
        if family == "XGBOOST_COX":
            parameters = _engine_parameters(family, selected["parameters"])
            locked = selected["selected_rounds"]
        else:
            parameters = selected["parameters"]
            locked = selected["locked_epoch"]
        descriptors = [
            {
                "task_id": (
                    f"{task['task_id']}::P{partition_index:02d}::"
                    f"M{imputation:02d}"
                ),
                "partition": partition,
                "imputation": imputation,
                "seed": task["seed"] + partition_index * 1000 + imputation,
            }
            for partition_index, partition in enumerate(partitions, start=1)
            for imputation in range(1, task["imputations"] + 1)
        ]
        fit_tasks = (
            [
                {
                    "task_id": descriptor["task_id"],
                    "spec": spec,
                    "registered": _engine_registered_partitions(
                        registered,
                        {descriptor["partition"]["partition_id"]},
                    ),
                    "partition_id": descriptor["partition"]["partition_id"],
                    "imputation": descriptor["imputation"],
                    "parameters": parameters,
                    "locked_rounds": locked,
                    "seed": descriptor["seed"],
                }
                for descriptor in descriptors
            ]
            if family == "XGBOOST_COX"
            else [
                {
                    "task_id": descriptor["task_id"],
                    "spec": spec,
                    "registered": _engine_registered_partitions(
                        registered,
                        {descriptor["partition"]["partition_id"]},
                    ),
                    "partition_id": descriptor["partition"]["partition_id"],
                    "imputation": descriptor["imputation"],
                    "candidate": parameters,
                    "locked_epoch": locked,
                    "seed": descriptor["seed"],
                }
                for descriptor in descriptors
            ]
        )
        atomic_jobs = [
            {
                "route": family,
                "top_task_id": task["task_id"],
                "atomic_task_id": fit_task["task_id"],
                "spec": spec,
                "registered": fit_task["registered"],
                "evaluation_partition": descriptor["partition"],
                "fit_task": fit_task,
                "scratch": str(scratch),
                "repo_root": str(repo_root),
            }
            for descriptor, fit_task in zip(descriptors, fit_tasks, strict=True)
        ]
    expected = task["imputations"] * expected_partition_count
    if atomic_job_plan:
        _require(
            len(atomic_jobs) == expected
            and [row["atomic_task_id"] for row in atomic_jobs]
            == [row["fit_task"]["task_id"] for row in atomic_jobs]
            and task_execution["pool_workers"] >= 1
            and task_execution["engine_threads"] == 1,
            "F2_P2C2T_ATOMIC_PLAN_INVALID",
        )
        return {
            "kind": "PADML_F2_P2C2T_ATOMIC_JOB_PLAN",
            "task_id": task["task_id"],
            "expected_fit_count": expected,
            "pool_workers": task_execution["pool_workers"],
            "engine_threads": task_execution["engine_threads"],
            "jobs": atomic_jobs,
        }
    _require(
        isinstance(evaluated_override, list),
        "F2_P2C2T_ATOMIC_PLAN_STATE_INVALID",
    )
    evaluated = list(evaluated_override)
    scores = [row["ibs_0_24"] for row in evaluated]
    _require(
        len(scores) == expected and all(math.isfinite(value) for value in scores),
        "F2_P2C2T_REGISTERED_EVALUATION_INVALID",
    )
    pooled_metrics = _trial_evaluation_summary(
        evaluated, _trial_scoring_context(partitions), task["imputations"]
    )
    metrics = [
        {
            "partition_id": row["partition_id"],
            "imputation": row["imputation"],
            "prediction_seal_sha256": row["prediction_seal_sha256"],
            "evaluation_response_sha256": row["evaluation_response_sha256"],
            "ibs_0_24": row["ibs_0_24"],
            **({"stopping": row["stopping"]} if family == "FPM_TVC_SET_A" else {}),
        }
        for row in evaluated
    ]
    transformed = family in {"ELASTIC_NET_COX", "COX_PH", "FPM_TVC_SET_A"}
    design_source = (model['design_source'] if model.get('kind') == 'PADML_A04_CURRENT_PRIMARY_LOCK_SCOPE_V1'
                     else _p2c2t_model_design_source(model))
    recipe_bindings = (
        [
            {
                "consumer_partition_id": partition["partition_id"],
                "recipe_partition_id": transform_recipe_by_partition[
                    partition["partition_id"]
                ]["partition_id"],
                "recipe_sha256": transform_recipe_by_partition[
                    partition["partition_id"]
                ]["recipe_sha256"],
                "analysis_view_sha256": transform_recipe_by_partition[
                    partition["partition_id"]
                ]["analysis_view_sha256"],
                "analysis_ids_sha256": transform_recipe_by_partition[
                    partition["partition_id"]
                ]["analysis_ids_sha256"],
                "fit_ids_sha256": transform_recipe_by_partition[
                    partition["partition_id"]
                ]["fit_ids_sha256"],
            }
            for partition in partitions
        ]
        if transformed
        else []
    )
    family_design_binding = {
        "mode": "TRANSFORM_RECIPE" if transformed else "RAW_CANONICAL",
        "transform_registry_sha256": predictors["transform_registry_sha256"],
        "continuous_policy": predictors["family_policy"][family]["continuous"],
        "categorical_policy": predictors["family_policy"][family]["categorical"],
        "scaling": predictors["family_policy"][family]["scaling"],
        "recipe_count": len(recipe_bindings),
        "recipes": recipe_bindings,
        "recipe_set_sha256": _sha(recipe_bindings),
        "fixed_representation": (
            transformed
            and task["component"] == "LOCKED_MODEL_SAMPLE_SIZE_DIAGNOSTIC"
        ),
        "source_family_design_binding_sha256": design_source[
            "family_design_binding_sha256"
        ],
        "source_selector_evidence_sha256": design_source[
            "selector_evidence_sha256"
        ],
        "source_selected_parent_sha256": design_source[
            "selected_parent_sha256"
        ],
        "source_registered_input_identity": design_source[
            "registered_input_identity"
        ],
        "source_selector_recipe_set_sha256": design_source[
            "selector_recipe_set_sha256"
        ],
        "source_outer_recipe_sha256": design_source["outer_recipe"][
            "recipe_sha256"
        ],
    }
    return {
        "status": "PASS",
        "component": task["component"],
        "task_id": task["task_id"],
        "scope_id": task["scope_id"],
        "family": family,
        "fold": task["fold"],
        "imputation_count": task["imputations"],
        "expected_fit_count": expected,
        "executed_fit_count": expected,
        "mean_ibs": pooled_metrics["mean_ibs"],
        "maximum_ibs": pooled_metrics["maximum_ibs"],
        "pooled_metric_values": pooled_metrics["ranking_metric_values"],
        "pooled_metric_qc": pooled_metrics["ranking_metric_qc"],
        "partition_metrics": metrics,
        "partition_metrics_sha256": _sha(metrics),
        "selected_spec_sha256": task["selected_spec_sha256"],
        "selected_parent_sha256": _sha(selector["selected_parents"]),
        "family_design_binding": family_design_binding,
        "warning_count": 0,
        "warning_set_sha256": _sha([]),
        "stopping_sha256": _sha([row.get("stopping") for row in evaluated]),
        "outer_heldout_outcome_read_count_for_selection": 0,
        "model_selected_spec_sha256": model["selected_spec_sha256"],
        "mice_rerun_summary_sha256": None,
        "selector_evidence_sha256": (model["development_lock"]["selector_evidence_sha256"]
            if model.get("kind") == "PADML_A04_CURRENT_PRIMARY_LOCK_SCOPE_V1"
            else _selector_evidence_science_identity(selector)),
        "task_contract_sha256": _sha(contract_task),
        "selection_effect": "NONE",
        "execution_mode": task_execution["execution_mode"],
        "threads": task_execution["threads"],
        "pool_workers": task_execution["pool_workers"],
        "engine_threads": task_execution["engine_threads"],
        "admission_identity": route_record["admission_identity"],
        "finite": True,
        "typed_terminal": "PASS",
    }


def _p2c2t_retained_non_fpm(
    previous_result: Mapping[str, Any], registry: Mapping[str, Any],
    contract_sha256: str, response_sha256: str,
) -> dict[str, dict[str, Any]]:
    previous = previous_result.get("task_results")
    _require(
        previous_result.get("artifact_kind") == "F2_P2C2T"
        and previous_result.get("status") == "PASS"
        and previous_result.get("component") == registry["component"]
        and previous_result.get("contract_sha256") == contract_sha256
        and previous_result.get("task_registry") == registry
        and previous_result.get("f1_response_seal_sha256") == response_sha256
        and isinstance(previous, list)
        and previous_result.get("task_result_set_sha256") == _sha(previous)
        and len(previous) == registry["task_count"]
        and [row["task_id"] for row in previous] == [row["task_id"] for row in registry["tasks"]]
        and all(row["task_contract_sha256"] == _sha(task)
                and row["family"] == task["family"]
                for row, task in zip(previous, registry["tasks"], strict=True)),
        "F2_P2C2T_REUSE_SCIENTIFIC_INPUT_CHANGED",
    )
    # Only FPM changed. The caller keeps every other task byte-for-byte; the
    # assembled artifact still traverses the same full scientific validator.
    return {row["task_id"]: row for row in previous if row["family"] != "FPM_TVC_SET_A"}


def _retained_p2c2t_fpm_components(entries: Mapping[str, bytes]) -> list[Mapping[str, bytes]]:
    """Read native component records from one capsule-bound reuse archive."""
    fields = {"fixed-task.json", "engine-spec.json", "consumer-result.json"}
    prefixes = sorted({name.rsplit("/", 1)[0] + "/" for name in entries
                       if name.startswith("retained/") and name.endswith("/fixed-task.json")})
    _require(fields <= set(entries)
             and {name for name in entries if name.startswith("retained/")}
             == {prefix + field for prefix in prefixes for field in fields},
             "F2_FPM_REUSE_COMPONENT_SET_INVALID")
    records = [entries, *[{field: entries[prefix + field] for field in fields}
                         for prefix in prefixes]]
    task_ids = [strict_json_bytes(record["fixed-task.json"]).get("task_id") for record in records]
    _require(all(isinstance(task_id, str) and task_id for task_id in task_ids)
             and len(set(task_ids)) == len(task_ids), "F2_FPM_REUSE_TASK_INVALID")
    return records


def _retained_p2c2t_fpm(job: Mapping[str, Any], entries: Mapping[str, bytes]) -> dict[str, Any]:
    """Re-admit an atomic native fit against the current job and response seal."""
    task = job["fit_task"]
    _require(job["route"] == "R" and task["family"] == "FPM_TVC_SET_A"
             and task == strict_json_bytes(entries["fixed-task.json"]),
             "F2_FPM_REUSE_TASK_INVALID")
    recipe = _validate_transform_recipe(task["transform_recipe"], job["spec"]["predictors"])
    expected = {**job["spec"], "action": "MODEL_PREDICTION_BATCH", "threads": 1,
                "pool_workers": 1, "engine_threads": 1,
                "registered_partitions": job["registered"], "transform_recipe": recipe,
                "producer_tasks": [{key: value for key, value in task.items() if key != "transform_recipe"}]}
    _require(_fpm_reuse_spec(strict_json_bytes(entries["engine-spec.json"])) == _fpm_reuse_spec(expected),
             "F2_FPM_REUSE_INPUT_MISMATCH")
    value = strict_json_bytes(entries["consumer-result.json"])
    _require(value.get("atomic_task_id") == job["atomic_task_id"]
             and value.get("top_task_id") == job["top_task_id"]
             and value.get("task_identity_sha256") == _sha({key: row for key, row in value.items()
                                                           if key != "task_identity_sha256"}),
             "F2_FPM_REUSE_RESULT_INVALID")
    row = value["evaluated"]
    _validate_retained_fpm_health(row, job["spec"])
    partition = job["evaluation_partition"]
    sealed = row["sealed_prediction"]
    _require(sealed == _seal_prediction_matrix(partition["evaluation_ids"],
                         sealed["payload"]["survival"], job["spec"]["horizons"])
             and row["prediction_seal_sha256"] == sealed["sha256"]
             and row["task_id"] == task["task_id"] and row["imputation"] == task["imputation"]
             and row["partition_id"] == task["partition_id"]
             and row["evaluation_ids_sha256"] == partition["evaluation_ids_sha256"]
             and row["evaluation_response_sha256"] == partition["evaluation_response"]["sha256"],
             "F2_FPM_REUSE_PREDICTION_INVALID")
    metric = _evaluate_prediction_seal(_monthly_prediction_seal(sealed),
                                       fit_response=partition["fit_response"],
                                       evaluation_response=partition["evaluation_response"])
    _require(math.isclose(row["ibs_0_24"], metric["ibs_0_24"], rel_tol=1e-12, abs_tol=1e-12),
             "F2_FPM_REUSE_EVALUATION_INVALID")
    return value


def execute_p2c2t(
    capsule_path: Path,
    capsule: dict[str, Any],
    component: str,
    model_values: list[dict[str, Any]],
    request: dict[str, Any],
    scratch: Path,
    *,
    cache_root: Path,
    reuse_non_fpm: Mapping[str, Any] | None = None,
    retained_fpm: Mapping[str, bytes] | None = None,
    checkpoint_root: Path | None = None,
) -> dict[str, Any]:
    """Compile every P2C2T task before executing the private training-only frontier."""

    _require(component in F2_COMPONENTS, "F2_P2C2T_COMPONENT_INVALID")
    pool_workers = execution_contract(request["plan"])["pool_workers"]
    science = capsule["authority_slice"]["science"]
    route_profiles = validate_route_profile_map(
        capsule["manifest"]["identity_records"]["execution_plan"][
            "route_profiles"
        ],
        require_formal=True,
    )
    contract = science["f2_model_development"]["p2c2t_contract"]
    _require(
        contract["source_decision_sha256"]
        == capsule["authority_slice"]["provenance"]["science_authority_sources"]["members"]["scientific/approved_decisions/production_operationalization_and_portability_closure_a04.yml"]
        and contract["hyperparameter_catalog_sha256"]
        == capsule["authority_slice"]["provenance"]["science_authority_sources"]["members"]["scientific/catalogs/hyperparameter_catalog.csv"],
        "F2_P2C2T_SOURCE_AUTHORITY_INVALID",
    )
    models = _p2c2t_model_grid(model_values)
    by_scope = {(row["fold"], row["family"]): row for row in models}
    registry = compile_p2c2t_registry(component, models, request, contract, science["f2_model_development"]["coxtime"])
    binding_contract, frozen_csv, frozen_lineage = admitted_f1_frozen_data(
        capsule_path, capsule, scratch
    )
    repo_root = Path(__file__).resolve().parent
    predictors = predictor_contract(repo_root, capsule["authority_slice"])
    fold_assets: dict[int, tuple[dict[str, Any], dict[str, Any]]] = {}
    center_recipe_sets: dict[int, dict[str, Any]] = {}
    prepared_reuse: dict[str, dict[str, Any]] = {}
    retained_atomic: dict[str, dict[str, Any]] = {}
    retained_root = None
    if checkpoint_root is not None:
        retained_root = checkpoint_root / f".{request['unit_id']}-retained-fpm"
        retained_root.mkdir(mode=0o700, exist_ok=True)
        _require(not retained_root.is_symlink() and retained_root.resolve(strict=True) == retained_root
                 and all(path.is_file() and not path.is_symlink()
                         and re.fullmatch(r"[0-9a-f]{64}\.zip", path.name)
                         for path in retained_root.iterdir()), "F2_FPM_RETAINED_PATH_INVALID")

    def assets(fold: int) -> tuple[dict[str, Any], dict[str, Any]]:
        if fold not in fold_assets:
            _, registered, lineage, library_index = _cached_fold_assets(
                capsule_path, capsule, request, fold, binding_contract, frozen_csv, cache_root
            )
            expected_inputs = {
                row["model_input"]["registered_input_identity"]
                for row in models
                if row["fold"] == fold
            }
            _require(
                expected_inputs == {registered["identity"]},
                "F2_P2C2T_MODEL_INPUT_IDENTITY_MISMATCH",
            )
            lineage = {
                **lineage,
                "f1_outer_analysis_sha256": library_index[
                    "OUTER_ANALYSIS"
                ]["sha256"],
                "f1_outer_application_sha256": library_index[
                    "OUTER_APPLICATION"
                ]["sha256"],
            }
            fold_assets[fold] = registered, lineage
        return fold_assets[fold]

    def prepare(task_value: dict[str, Any]) -> dict[str, Any]:
        task = {**task_value, "component": component}
        model = by_scope[(task["fold"], task["family"])]
        registered, lineage = assets(task["fold"])
        center_recipe_set = None
        if (
            component == "CENTER_BLOCKED_STRESS"
            and task["family"] in {"ELASTIC_NET_COX", "COX_PH", "FPM_TVC_SET_A"}
        ):
            if task["fold"] not in center_recipe_sets:
                center_partitions = sorted(
                    registered["diagnostic_partitions"],
                    key=lambda row: row["validation_center"],
                )
                center_recipe_sets[task["fold"]] = _compile_transform_recipes(
                    {"predictors": predictors},
                    registered,
                    [row["partition_id"] for row in center_partitions],
                    scratch,
                    repo_root,
                    expected_count=5,
                )
            center_recipe_set = center_recipe_sets[task["fold"]]
        execution_registered = registered
        evaluation_root = scratch / (
            f"eval-{_sha([task['task_id'], task['imputations']])[:16]}"
        )
        evaluation_root.mkdir(mode=0o700)
        if component == "LOCKED_MODEL_SAMPLE_SIZE_DIAGNOSTIC":
            matches = [
                row
                for row in binding_contract["registry"]["sample_size"]
                if row["outer_fold"] == task["fold"]
                and row["seed_ordinal"] == task["seed_ordinal"]
                and row["fraction"] == task["sample_fraction"]
            ]
            _require(len(matches) == 1, "F2_P2C2T_SAMPLE_REGISTRY_INVALID")
            execution_registered = _p2c2t_sample_registered_partition(
                registered,
                sample_ids=list(matches[0]["sample_ids"]),
                response_csv=frozen_csv,
                task=task_value,
                destination=evaluation_root / "sample-partition",
            )
        plan = _p2c2t_registered_task_result(
            task=task,
            contract_task=task_value,
            model=model,
            registered=execution_registered,
            science=science,
            predictors=predictors,
            scratch=evaluation_root,
            repo_root=repo_root,
            route_record=route_profiles[_FAMILY_ROUTE_KEYS[task["family"]]],
            center_recipe_set=center_recipe_set,
            atomic_job_plan=True,
            pool_workers=pool_workers,
        )
        return {
            "task": task,
            "contract_task": task_value,
            "model": model,
            "registered": execution_registered,
            "lineage": lineage,
            "evaluation_root": evaluation_root,
            "center_recipe_set": center_recipe_set,
            "plan": plan,
        }

    def finalize(
        prepared: dict[str, Any],
        evaluated: list[dict[str, Any]],
    ) -> dict[str, Any]:
        value = _p2c2t_registered_task_result(
            task=prepared["task"],
            contract_task=prepared["contract_task"],
            model=prepared["model"],
            registered=prepared["registered"],
            science=science,
            predictors=predictors,
            scratch=prepared["evaluation_root"],
            repo_root=repo_root,
            route_record=route_profiles[
                _FAMILY_ROUTE_KEYS[prepared["task"]["family"]]
            ],
            center_recipe_set=prepared["center_recipe_set"],
            evaluated_override=evaluated,
            pool_workers=pool_workers,
        )
        lineage = prepared["lineage"]
        value.update(
            {
                "f1_outer_analysis_sha256": lineage["f1_outer_analysis_sha256"],
                "f1_outer_application_sha256": lineage["f1_outer_application_sha256"],
            }
        )
        _require(_finite_tree(value), "F2_P2C2T_TASK_NONFINITE")
        shutil.rmtree(prepared["evaluation_root"])
        return value

    def evaluate_requests(requests: list[dict[str, Any]]) -> list[dict[str, Any]]:
        values: list[dict[str, Any]] = []
        for start in range(0, len(requests), 4):
            window = requests[start : start + 4]
            prepared = [prepared_reuse.pop(task["task_id"]) if task["task_id"] in prepared_reuse
                        else prepare(task) for task in window]
            evaluated = _run_p2c2t_atomic_window(
                [value["plan"] for value in prepared], retained_rows=retained_atomic,
                retained_root=retained_root,
            )
            values.extend(
                finalize(value, rows)
                for value, rows in zip(prepared, evaluated, strict=True)
            )
        return values

    retained: dict[str, dict[str, Any]] = {}
    if reuse_non_fpm is not None:
        retained = _p2c2t_retained_non_fpm(reuse_non_fpm, registry, _sha(contract),
                                          frozen_lineage["f1_response_seal_sha256"])
        for fold in sorted({task["fold"] for task in registry["tasks"]}):
            assets(fold)
    if retained_fpm is not None:
        _require(component in {"CENTER_BLOCKED_STRESS", "LOCKED_MODEL_SAMPLE_SIZE_DIAGNOSTIC"},
                 "F2_FPM_REUSE_SCOPE_INVALID")
        for record in _retained_p2c2t_fpm_components(retained_fpm):
            old = strict_json_bytes(record["consumer-result.json"])
            matches = [task for task in registry["tasks"] if task["task_id"] == old["top_task_id"]]
            _require(len(matches) == 1 and matches[0]["family"] == "FPM_TVC_SET_A",
                     "F2_FPM_REUSE_TASK_INVALID")
            if old["top_task_id"] not in prepared_reuse:
                prepared_reuse[old["top_task_id"]] = prepare(matches[0])
            prepared = prepared_reuse[old["top_task_id"]]
            jobs = [job for job in prepared["plan"]["jobs"] if job["atomic_task_id"] == old["atomic_task_id"]]
            _require(len(jobs) == 1 and old["atomic_task_id"] not in retained_atomic,
                     "F2_FPM_REUSE_TASK_INVALID")
            retained_atomic[old["atomic_task_id"]] = _retained_p2c2t_fpm(jobs[0], record)
    fresh = evaluate_requests([task for task in registry["tasks"] if task["task_id"] not in retained])
    by_task_id = {**retained, **{row["task_id"]: row for row in fresh}}
    task_results = [by_task_id[task["task_id"]] for task in registry["tasks"]]

    _require(
        len(task_results) == registry["task_count"]
        and {row["task_id"] for row in task_results} == {row["task_id"] for row in registry["tasks"]}
        and all(row["status"] == "PASS" and row["finite"] is True and row["selection_effect"] == "NONE" for row in task_results),
        "F2_P2C2T_TASK_DENOMINATOR_INVALID",
    )
    expected_fits = sum(row["expected_fit_count"] for row in task_results)
    executed_fits = sum(row["executed_fit_count"] for row in task_results)
    _require(expected_fits > 0 and executed_fits == expected_fits, "F2_P2C2T_FIT_DENOMINATOR_INVALID")
    config_index = [
        {
            "fold": fold,
            "f1_outer_analysis_sha256": value[1]["f1_outer_analysis_sha256"],
            "f1_outer_application_sha256": value[1]["f1_outer_application_sha256"],
        }
        for fold, value in sorted(fold_assets.items())
    ]
    model_set = [
        {key: row[key] for key in ("fold", "family", "selected_spec_sha256", "numeric_qc_sha256")}
        for row in models
    ]
    execution = execution_result_contract(request["plan"])
    result = {
        "schema_version": "1.0.0",
        "artifact_kind": "F2_P2C2T",
        "status": "PASS",
        "component": component,
        "selection_effect": "NONE",
        "population_scope": "OUTER_APPLICATION_RESPONSE_SEALED",
        "contract": contract["components"][component],
        "contract_sha256": _sha(contract),
        "model_result_count": 42,
        "model_result_set_sha256": _sha(model_set),
        "task_registry": registry,
        "task_registry_sha256": _sha(registry),
        "expected_scope_count": registry["scope_count"],
        "executed_scope_count": len({row["scope_id"] for row in task_results}),
        "expected_task_count": registry["task_count"],
        "executed_task_count": len(task_results),
        "expected_fit_count": expected_fits,
        "executed_fit_count": executed_fits,
        "task_results": task_results,
        "task_result_set_sha256": _sha(task_results),
        "f1_configuration_index": config_index,
        "f1_configuration_index_sha256": _sha(config_index),
        "f1_response_seal_sha256": frozen_lineage["f1_response_seal_sha256"],
        "outer_heldout_outcome_read_count_for_selection": 0,
        "warning_count": sum(row["warning_count"] for row in task_results),
        "seed": request["seed"],
        **execution,
        "typed_terminal": "PASS",
    }
    result["result_identity_sha256"] = _sha(result)
    return result


def aggregate_confirmation(
    model_values: list[dict[str, Any]],
    diagnostic_values: list[dict[str, Any]],
    consumed_sources: list[dict[str, Any]],
) -> dict[str, Any]:
    _require(len(model_values) == 42 and len(diagnostic_values) == 3, "F2_CONFIRMATION_DENOMINATOR_INVALID")
    _require(len(consumed_sources) == 45, "F2_CONFIRMATION_SOURCE_DENOMINATOR_INVALID")
    diagnostic_sources = {row["unit_id"]: row for row in consumed_sources[42:]}
    _require(
        set(diagnostic_sources)
        == {
            "p2c2t-center-blocked-stress",
            "p2c2t-locked-model-sample-size-diagnostic",
            "p2c2t-local-perturbation",
        },
        "F2_CONFIRMATION_DIAGNOSTIC_SOURCE_SET_INVALID",
    )
    components = {row.get("component") for row in diagnostic_values}
    _require(
        components == set(F2_COMPONENTS)
        and all(
            row.get("status") == "PASS"
            and row.get("expected_task_count") == row.get("executed_task_count")
            and row.get("expected_fit_count") == row.get("executed_fit_count")
            and row.get("typed_terminal") == "PASS"
            for row in diagnostic_values
        ),
        "F2_CONFIRMATION_DIAGNOSTIC_RESULT_INVALID",
    )
    family_specs: dict[str, list[dict[str, Any]]] = {family: [] for family in F2_FAMILIES}
    for row in model_values:
        family_specs[row["family"]].append({"fold": row["fold"], "selected_spec": row["selected_spec"], "selected_spec_sha256": row["selected_spec_sha256"]})
    _require(all(len(rows) == 6 for rows in family_specs.values()), "F2_CONFIRMATION_FOLD_SET_INVALID")
    canonical = {family: sorted(rows, key=lambda row: row["fold"]) for family, rows in family_specs.items()}
    diagnostic_index = []
    for value in sorted(diagnostic_values, key=lambda row: row["component"]):
        unit_id = f"p2c2t-{value['component'].lower().replace('_', '-')}"
        source = diagnostic_sources[unit_id]
        diagnostic_index.append(
            {
                "component": value["component"],
                "unit_id": unit_id,
                "result_sha256": source["result_sha256"],
                "artifact_sha256": source["artifact_sha256"],
                "task_count": value["executed_task_count"],
                "fit_count": value["executed_fit_count"],
                "task_result_set_sha256": value["task_result_set_sha256"],
            }
        )
    return {
        "artifact_kind": "F2_MODEL_CONFIRMATION",
        "status": "PASS",
        "model_result_count": 42,
        "diagnostic_result_count": 3,
        "family_spec_count": 7,
        "seven_canonical_family_specs": canonical,
        "seven_canonical_family_specs_sha256": _sha(canonical),
        "diagnostic_set_sha256": _sha(diagnostic_values),
        "diagnostic_artifact_index": diagnostic_index,
        "diagnostic_artifact_index_sha256": _sha(diagnostic_index),
        "result_dependent_winner_status": "PENDING_LOCAL_VALIDATION_AND_HUMAN_REVIEW",
    }


__all__ = [
    "F2_COMPONENTS",
    "F2_FAMILIES",
    "F2_STAGES",
    "admitted_f1_fold",
    "aggregate_confirmation",
    "compile_p2c2t_registry",
    "compile_model_spec",
    "execute_model",
    "execute_p2c2t",
    "predictor_contract",
]
