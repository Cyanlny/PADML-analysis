from __future__ import annotations

import copy
import csv
from pathlib import Path
from typing import Any, Mapping

from .bundle import ContractError, canonical_json_bytes, sha256_bytes, strict_json_bytes


AUTHORITY_PATH = Path(__file__).resolve().parent / "science/authority.json"
VARIABLE_CATALOG_PATH = Path(__file__).resolve().parent / "science/variable.csv"
ACTIVE_ACTIVATION = "ACTIVATED"
ACTIVE_TRANSFORM_ACTIVATION = "ACTIVATED"
EXECUTION_ROUTE_KEYS = (
    "F1_MICE",
    "F2_ELASTIC",
    "F2_SELECTOR_MRMRE",
    "F2_SELECTOR_BORUTA",
    "COX_PH",
    "RSF",
    "GBM_COX",
    "XGBOOST_COX",
    "FPM_TVC",
    "COXTIME",
)
_VARIABLE_CATALOG_COLUMNS = (
    "variable", "label_cn", "label_en", "definition", "type", "unit",
    "levels_or_coding", "clinical_domain", "source_role", "measurement_time",
    "mice_role", "mice_method", "mice_auxiliary", "model_parent_eligible",
    "selector_eligible", "forced", "protected", "penalty_factor",
    "set_a_eligible", "set_b_eligible", "sensitivity_only",
    "representation_group", "simultaneous_representation_rule",
    "selection_effect_from_domain_metadata", "notes", "selector_representation",
)


def _require(condition: bool, reason: str) -> None:
    if not condition:
        raise ContractError(reason)


def _exact(value: Any, keys: set[str], reason: str) -> dict[str, Any]:
    _require(type(value) is dict and set(value) == keys, reason)
    return value


def load_science_authority(
    path: Path = AUTHORITY_PATH,
    *,
    require_activation: str | None = ACTIVE_ACTIVATION,
) -> dict[str, Any]:
    _require(
        path.is_absolute()
        and path == AUTHORITY_PATH
        and path.is_file()
        and not path.is_symlink()
        and path.resolve(strict=True) == path,
        "SCIENCE_AUTHORITY_PATH_INVALID",
    )
    raw = path.read_bytes()
    value = strict_json_bytes(raw, "SCIENCE_AUTHORITY")
    _require(
        type(value) is dict
        and canonical_json_bytes(value) == raw
        and set(value)
        == {"activation", "execution", "kind", "provenance", "schema_version", "science"}
        and value["schema_version"] == "1.0.0"
        and value["kind"] == "PADML_F2_V1_SCIENCE_AUTHORITY"
        and (require_activation is None or value["activation"] == require_activation),
        "SCIENCE_AUTHORITY_INVALID",
    )
    science = value["science"]
    _require(
        type(science) is dict
        and set(science)
        == {
            "families", "f2_model_development", "fpm", "horizons_months",
            "mice", "modeling_seed_policy", "p2c2t", "population",
            "primary_metric", "resampling",
        }
        and science["families"]
        == [
            "COX_PH", "ELASTIC_NET_COX", "RSF", "GBM_COX",
            "XGBOOST_COX", "FPM_TVC_SET_A", "COXTIME_SET_A",
        ]
        and science["p2c2t"]
        == [
            "CENTER_BLOCKED_STRESS",
            "LOCKED_MODEL_SAMPLE_SIZE_DIAGNOSTIC",
            "LOCAL_PERTURBATION",
        ],
        "SCIENCE_F2_SCOPE_INVALID",
    )
    _require(
        science["f2_model_development"].get("trial_scoring") == {
            "censoring_model": "EVALUATION_POPULATION_CENTER_STRATIFIED_KM",
            "fold_metric_role": "DESCRIPTIVE_ONLY",
            "ibs_grid_months": list(range(25)),
            "ibs_integration": "TRAPEZOID_DIVIDE_BY_24",
            "imputation_pooling": "EQUAL_PROBABILITY_AVERAGE_BEFORE_METRIC",
            "minimum_effective_sample_size": "MAX_30_OR_0.20_TIMES_EVALUATION_N",
            "minimum_ipcw_survival": 0.05,
            "ranking_unit": "COMPLETE_REPEAT_CONCATENATED_OOF",
            "s1_s2_cross_fidelity_ranking": "FORBIDDEN",
            "s3a_promotion_source": "S2_ONLY",
            "weight_truncation": "FORBIDDEN",
        },
        "SCIENCE_F2_SCORING_CONTRACT_INVALID",
    )
    selector = science["f2_model_development"]["selector_contract"]
    _require(
        selector["epv_contract"] == {
            "all_imputations_required": True,
            "ast_alt_counted_in_design_df": True,
            "common_set_design_df": "LOCKED_ELASTIC_DESIGN_COMPLETE_COLUMN_COUNT",
            "common_set_policy": "SAME_MINIMUM_WITHOUT_POSTHOC_VARIABLE_REMOVAL",
            "design_df": "IMPUTATION_NONZERO_DESIGN_COLUMNS_PLUS_FORCED_AST_ALT",
            "event_denominator": "OUTER_TRAINING_EVENT_COUNT",
            "minimum": 15,
        }
        and selector["imputation_specific_ratio"] is True
        and selector["ratio_decision"]["primary"]
        == "PER_IMPUTATION_LARGEST_EPV_FEASIBLE_RATIO_IN_FEASIBLE_MINIMUM_1SE_BAND"
        and selector["final_refit_parameters"]
        == "LOCK_OUTER_SELECTOR_ALPHA_AND_IMPUTATION_SPECIFIC_LAMBDA_WITHOUT_RETUNING"
        and selector["infeasible_candidate_policy"]
        == "EXCLUDE_ONLY_COMPLETE_VALIDATED_EPV_INFEASIBLE_CANDIDATES_OTHER_ERRORS_ABORT",
        "SCIENCE_F2_SELECTOR_CONTRACT_INVALID",
    )
    _active_transform_catalog(value, VARIABLE_CATALOG_PATH)
    return value


def execution_profile(pool_workers: int = 24) -> dict[str, Any]:
    # Default reconstructs historical receipts. New dispatch binds each request
    # to the executing host's observed C−8 via padml.runtime.
    _require(type(pool_workers) is int and pool_workers >= 1, "F2_EXECUTION_PROFILE_INVALID")
    return {
        "mode": f"PROCESS_POOL_{pool_workers}",
        "internal_threads": pool_workers,
        "pool_workers": pool_workers,
        "engine_threads": 1,
    }


def selected_route_profiles(
    authority: Mapping[str, Any] | None = None,
    *, pool_workers: int = 24,
) -> dict[str, dict[str, Any]]:
    if authority is not None:
        _require(dict(authority) == load_science_authority(), "SCIENCE_AUTHORITY_DRIFT")
    return {
        route: {
            "admission_identity": sha256_bytes(
                canonical_json_bytes(
                    {"route": route, "profile": execution_profile(pool_workers),
                     "policy": "F2_V1_POOL24" if pool_workers == 24 else "F2_EXECUTION_HOST_CAPACITY"}
                )
            ),
            "profile": execution_profile(pool_workers),
            "selection": "USER_LOCKED_POOL24" if pool_workers == 24 else "USER_LOCKED_CPU_MINUS_8",
        }
        for route in EXECUTION_ROUTE_KEYS
    }


def validate_route_profile_map(
    value: Any,
    *,
    require_formal: bool,
    admission_records: Mapping[str, Any] | None = None,
) -> dict[str, dict[str, Any]]:
    del admission_records
    _require(require_formal is True, "F2_ROUTE_PROFILE_SCOPE_INVALID")
    _require(isinstance(value, Mapping) and isinstance(value.get("F2_ELASTIC"), Mapping)
             and isinstance(value["F2_ELASTIC"].get("profile"), Mapping),
             "F2_ROUTE_PROFILE_MAP_INVALID")
    profile = value["F2_ELASTIC"]["profile"]
    expected = selected_route_profiles(pool_workers=profile.get("pool_workers"))
    _require(value == expected, "F2_ROUTE_PROFILE_MAP_INVALID")
    return copy.deepcopy(expected)


def route_execution_profile(profiles: Mapping[str, Any], route: str) -> dict[str, Any]:
    return dict(validate_route_profile_map(dict(profiles), require_formal=True)[route]["profile"])


def execution_mode(profile: Mapping[str, Any]) -> str:
    _require(dict(profile) == execution_profile(profile.get("pool_workers")), "F2_EXECUTION_PROFILE_INVALID")
    return "PROCESS_POOL"


def selector_sensitivity_contract(
    authority: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    value = dict(authority) if authority is not None else load_science_authority()
    contract = value["science"]["f2_model_development"]["selector_sensitivity"]
    _require(
        type(contract) is dict
        and contract.get("schema_version") == "1.0.0"
        and contract.get("methods") == ["MRMRE", "BORUTA"]
        and contract.get("execution", {}).get("outer_fold_units") == 6
        and contract.get("execution", {}).get("mi_tasks_per_method_fold") == 20
        and contract.get("execution", {}).get("authoritative_unit_parallelism") == 1
        and contract.get("execution", {}).get("nested_parallelism") == "FORBIDDEN"
        and contract.get("shared_contract", {}).get("eligible_parent_count") == len(selector_parent_names())
        and contract.get("seed_policy", {}).get("required_unique_count") == 240
        and contract.get("seed_policy", {}).get("schedule_independent") is True,
        "SELECTOR_SENSITIVITY_CONTRACT_INVALID",
    )
    return copy.deepcopy(contract)


def _catalog_boolean(row: Mapping[str, str], field: str) -> bool:
    _require(row.get(field) in {"true", "false"}, f"VARIABLE_CATALOG_{field.upper()}_INVALID")
    return row[field] == "true"


def selector_parent_names():
    return [row['variable'] for row in _load_variable_catalog(VARIABLE_CATALOG_PATH)
            if _catalog_boolean(row, 'selector_eligible') or _catalog_boolean(row, 'forced')]


def _load_variable_catalog(path: Path) -> list[dict[str, str]]:
    _require(
        path.is_absolute() and path.is_file() and not path.is_symlink()
        and path.resolve(strict=True) == path,
        "VARIABLE_CATALOG_PATH_INVALID",
    )
    with path.open(encoding="utf-8", newline="") as handle:
        reader = csv.DictReader(handle)
        _require(tuple(reader.fieldnames or ()) == _VARIABLE_CATALOG_COLUMNS, "VARIABLE_CATALOG_COLUMNS_INVALID")
        rows = [dict(row) for row in reader]
    _require(len(rows) == 53 and len({row["variable"] for row in rows}) == 53, "VARIABLE_CATALOG_DENOMINATOR_INVALID")
    return rows


def _compile_transform_catalog(
    authority: Mapping[str, Any], path: Path = VARIABLE_CATALOG_PATH
) -> dict[str, Any]:
    transform = authority["science"]["f2_model_development"]["transform_contract"]
    rows = _load_variable_catalog(path)
    registry_rows: list[dict[str, str]] = []
    selector_continuous: list[str] = []
    for row in rows:
        selector = _catalog_boolean(row, "selector_eligible")
        sensitivity_only = _catalog_boolean(row, "sensitivity_only")
        included = row["type"] == "continuous" and (selector or sensitivity_only)
        representation = row["selector_representation"]
        if included:
            _require(representation in {"IDENTITY", "LOG1P", "NATURAL_SPLINE_K3"}, "TRANSFORM_REPRESENTATION_INVALID")
            registry_rows.append(
                {
                    "canonical_unit": row["unit"],
                    "parent": row["variable"],
                    "representation": representation,
                }
            )
            if selector:
                selector_continuous.append(row["variable"])
        else:
            _require(representation in {"", "IDENTITY", "LOG1P", "NATURAL_SPLINE_K3"},
                     "TRANSFORM_NONREGISTRY_ROW_INVALID")
    registry_rows.sort(key=lambda row: row["parent"].encode("utf-8"))
    registry = {
        "schema_version": "1.0.0",
        "kind": "PADML_F2_TRANSFORM_REGISTRY",
        "rows": registry_rows,
    }
    digest = sha256_bytes(canonical_json_bytes(registry))
    _require(
        len(registry_rows) == transform['registry']['row_count']
        and len(selector_continuous) == transform['registry']['selector_continuous_count']
        and len(selector_parent_names()) == transform['registry']['selector_total_parent_count']
        and transform["activation"] == ACTIVE_TRANSFORM_ACTIVATION
        and transform["registry"]["registry_sha256"] == digest
        and transform["selector_payload_schema_version"] == "1.3.0",
        "TRANSFORM_REGISTRY_IDENTITY_INVALID",
    )
    return {
        "conflict_map": copy.deepcopy(transform["conflict_groups"]),
        "registry": registry,
        "selector_continuous": selector_continuous,
        "transform_registry_sha256": digest,
    }


def _active_transform_catalog(
    authority: Mapping[str, Any], path: Path = VARIABLE_CATALOG_PATH
) -> dict[str, Any]:
    return _compile_transform_catalog(authority, path)
