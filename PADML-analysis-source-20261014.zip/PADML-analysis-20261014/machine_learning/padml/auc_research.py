"""Fixed-prediction AUC research; no model, MICE, SHAP or selection fitting.

The weighted derivative is with respect to empirical case mass, including the
estimated center-specific censoring KM. A multiplier draw defines a new
empirical distribution; its variance uses linear mass, not squared mass.
"""
from __future__ import annotations

import math
from collections import Counter
from functools import lru_cache
from pathlib import Path

import numpy as np

from .bundle import ContractError

MONTHS = (6, 12, 24, 36)
BRANCHES = ('APPARENT', 'OOF-R1', 'OOF-R2', 'OOF-R3')


def need(ok, reason):
    if not ok:
        raise ContractError('AUC_RESEARCH_' + reason)


def retire_private_publication_members(folder,names):
    """Only after the final numerical consumer has accepted its immutable result.

    These are the original atomic writers' exact private temporary-name forms,
    including power-loss remnants for the declared members. Unknown objects
    and links are rejected; no recursive directory-name cleanup is permitted.
    """
    import re
    folder=Path(folder)
    if not folder.exists() and not folder.is_symlink():return
    need(folder.is_dir() and not folder.is_symlink() and folder.resolve()==folder.absolute(),
        'PARTIAL_PATH_INVALID')
    patterns=[re.compile(r'\.'+re.escape(name)+(r'\.tmp-[1-9][0-9]*-[0-9a-f]{16}'
        if name.endswith('.zip') else r'\.pending-[A-Za-z0-9_-]{8}')+r'\Z') for name in names]
    members=list(folder.iterdir())
    need(all(p.is_file() and not p.is_symlink() and
        (p.name in names or any(pattern.fullmatch(p.name) for pattern in patterns)) for p in members),
        'PARTIAL_UNEXPECTED_MEMBER')
    for p in members:p.unlink()
    folder.rmdir()


def retire_accepted_publication_temps(target):
    """Retire only one accepted target's interrupted atomic publications."""
    import re
    target=Path(target)
    need(target.is_file() and not target.is_symlink() and target.parent.resolve()==target.parent.absolute(),
        'ACCEPTED_PUBLICATION_PATH_INVALID')
    suffix=r'\.tmp-[1-9][0-9]*-[0-9a-f]{16}' if target.suffix=='.zip' else r'\.pending-[A-Za-z0-9_-]{8}'
    pattern=re.compile(r'\.'+re.escape(target.name)+suffix+r'\Z')
    for member in target.parent.glob('.'+target.name+('.tmp-*' if target.suffix=='.zip' else '.pending-*')):
        need(pattern.fullmatch(member.name) is not None and member.is_file() and not member.is_symlink(),
            'ACCEPTED_PUBLICATION_TEMP_INVALID')
        member.unlink()


def weighted_auc_if(plan, risks, horizon, mass, *, steps=None, endpoint=None, rank=None):
    """B draws, N rows. Return AUC and dA/dmass, centered within strata.

    H(u) is the sum of log-role gradients downstream of a censoring hazard.
    dA/da_k = direct_k/a_k + sum H(u)(d_ku-h_u*r_ku)/(Y_u-D_u).
    Deaths precede censoring at ties, exactly as in the original evaluator.
    Preparation/suffix scans avoid an N-by-N comparison/derivative matrix.
    """
    from .f4 import (_evaluation_perturbation_weighted_km_block,
        _evaluation_perturbation_endpoint_block, _evaluation_perturbation_prepare_risk,
        _evaluation_perturbation_auc_block)
    a = np.asarray(mass, dtype=float)
    r = np.asarray(risks, dtype=float)
    need(a.ndim == 2 and a.shape[1] == len(plan['ids']) and np.isfinite(a).all()
        and (a > 0).all(), 'WEIGHTS_INVALID')
    steps = _evaluation_perturbation_weighted_km_block(plan, a) if steps is None else steps
    ep = _evaluation_perturbation_endpoint_block(plan, a, steps, horizon) if endpoint is None else endpoint
    ci, cj, role = ep['cases'], ep['controls'], ep['role']
    rank = _evaluation_perturbation_prepare_risk(ep, r) if rank is None else rank
    theta, valid = _evaluation_perturbation_auc_block(ep, rank)
    b = np.full_like(a, np.nan)
    if not len(ci) or not len(cj):
        return theta, b, ep
    total_case, total_control = role[:, ci].sum(1), role[:, cj].sum(1)
    denom = total_case * total_control
    safe = np.where(valid, denom, 1.)
    direct = np.zeros_like(a)
    order, starts, lower, equal = rank
    masses = np.add.reduceat(role[:, order], starts, axis=1)
    prefix = np.column_stack((np.zeros(len(a)), np.cumsum(masses, axis=1)))
    concordant = prefix[:, lower].copy()
    if equal.any():
        concordant[:, equal] += .5 * masses[:, lower[equal]]
    direct[:, ci] = role[:, ci] * (concordant - theta[:, None]*total_control[:, None]) / safe[:, None]
    order = ci[np.argsort(r[ci], kind='stable')]
    unique, starts = np.unique(r[order], return_index=True)
    masses = np.add.reduceat(role[:, order], starts, axis=1)
    prefix = np.column_stack((np.zeros(len(a)), np.cumsum(masses, axis=1)))
    lower = np.searchsorted(unique, r[cj], side='left')
    upper = np.searchsorted(unique, r[cj], side='right')
    greater = prefix[:, -1, None] - .5*(prefix[:, lower]+prefix[:, upper])
    direct[:, cj] = role[:, cj] * (greater-theta[:, None]*total_case[:, None]) / safe[:, None]
    b = direct/a
    for _, members, order, points, starts in plan['groups']:
        count = int(np.searchsorted(points, horizon, side='right'))
        if not count:
            continue
        ordered = a[:, order]
        totals = np.add.reduceat(ordered, starts, axis=1)
        censored = np.add.reduceat(ordered*(plan['e'][order] == 0), starts, axis=1)
        later = np.zeros_like(totals)
        later[:, :-1] = np.cumsum(totals[:, :0:-1], axis=1)[:, ::-1]
        risk = (later+censored)[:, :count]
        deaths = censored[:, :count]
        # Cases after u use G(T-); every endpoint control uses G(h).
        cases = direct[:, order] * ((plan['e'][order] == 1) & (plan['t'][order] <= horizon))
        grouped = np.add.reduceat(cases, starts, axis=1)
        suffix = np.zeros_like(grouped)
        suffix[:, :-1] = np.cumsum(grouped[:, :0:-1], axis=1)[:, ::-1]
        control = direct[:, members[plan['t'][members] > horizon]].sum(1)
        downstream = suffix[:, :count] + control[:, None]
        active = deaths > 0
        bad = active & (risk <= deaths)
        valid &= ~bad.any(1)
        coefficient = np.divide(downstream, risk-deaths, out=np.zeros_like(downstream),
            where=active & (risk > deaths))
        hazard = np.divide(deaths, risk, out=np.zeros_like(deaths), where=risk > 0)
        cumulative = np.column_stack((np.zeros(len(a)), np.cumsum(-coefficient*hazard, axis=1)))
        t, e = plan['t'][members], plan['e'][members]
        stops = np.where(e == 0, np.searchsorted(points[:count], t, side='right'),
            np.searchsorted(points[:count], t, side='left'))
        b[:, members] += cumulative[:, stops]
        cens = members[(e == 0) & (t <= horizon)]
        if len(cens):
            b[:, cens] += coefficient[:, np.searchsorted(points[:count], plan['t'][cens])]
    for _, members, *_ in plan['groups']:
        b[:, members] -= np.sum(a[:, members]*b[:, members], axis=1)[:, None]/a[:, members].sum(1)[:, None]
    valid &= np.isfinite(b).all(1)
    theta[~valid] = np.nan
    b[~valid] = np.nan
    return theta, b, ep


def covariance(plan, mass, left, right=None):
    """Empirical-distribution covariance, not a second multiplier variance."""
    right = left if right is None else right
    output = np.zeros(len(mass))
    for _, members, *_ in plan['groups']:
        nc = len(members)
        if nc < 2:
            return np.full(len(mass), np.nan)
        output += nc/(nc-1)*np.sum(mass[:, members]*left[:, members]*right[:, members], axis=1)
    return output


def prepare(patient_ids, times, events, centers, risks, *, scopes=None):
    """One aligned population; risk keys are (report_month, base branch).

    These primitive coordinates, not their means/contrasts, enter the joint
    likelihood. Fixed-center macros retain every required center.
    """
    from .f4 import (_evaluation_perturbation_prepare_population, _evaluation_perturbation_prepare_risk, censoring_context,
        _response_rows, _write_response_subset, _evaluation_metric)
    ids, cc = list(patient_ids), list(centers)
    t, e = np.asarray(times), np.asarray(events)
    whole = _evaluation_perturbation_prepare_population(ids, t, e, cc)
    groups = [('MICRO', np.arange(len(ids)))] + [(c, np.flatnonzero(np.asarray(cc) == c))
        for c in dict.fromkeys(cc)]
    if scopes is not None:
        groups = [(s,i) for s,i in groups if s in scopes]
    prepared = {'whole':whole, 'populations':[], 'entries':{}, 'derived':[], 'original':{}, 'influence':{}}
    for scope, indices in groups:
        sid, scc = [ids[i] for i in indices], [cc[i] for i in indices]
        pop = _evaluation_perturbation_prepare_population(sid, t[indices], e[indices], scc)
        raw = ('Patient_ID,All_Cause_Death,Death_Followup_months\n'+''.join(
            f'{pid},{int(ev)},{float(ti)!r}\n' for pid,ev,ti in zip(sid,e[indices],t[indices],strict=True))).encode()
        fields, rows = _response_rows(raw)
        context = censoring_context(sid, scc, _write_response_subset(fields, rows, sid, None))
        pop.update(indices=indices, entries=[])
        for (h, name), risk in risks.items():
            key = (scope, h, name)
            selected = np.asarray(risk)[indices]
            point, grad, ep = weighted_auc_if(pop, selected, h, np.ones((1,len(indices))))
            reasons = list(context['rows'][h]['reasons'])
            if not len(ep['cases']): reasons.append('ZERO_EVENTS')
            if not len(ep['controls']): reasons.append('ZERO_TERMINAL_CONTROLS')
            if not reasons:
                need(np.isfinite(point[0]), 'SUPPORTED_POINT_NUMERICAL_FAILURE')
            source = _evaluation_metric(None if reasons else float(point[0]), reasons)
            prepared['original'][key] = source
            if reasons:
                continue
            row = {'population':len(prepared['populations']), 'horizon':h, 'risk':selected,
                'rank':_evaluation_perturbation_prepare_risk(ep,selected)}
            prepared['entries'][key] = row
            pop['entries'].append(key)
            full = np.zeros(len(ids)); full[indices] = grad[0]
            prepared['influence'][key] = full
        prepared['populations'].append(pop)
    counts = Counter(cc)
    for method in ('EQUAL_CENTER', 'PATIENT_WEIGHTED_CENTER'):
        weights = {c:1 if method == 'EQUAL_CENTER' else nc for c,nc in counts.items()}
        for h,name in risks:
            keys = [(c,h,name) for c in weights]
            if all(k in prepared['original'] for k in keys):
                _derive(prepared, (method,h,name), keys, [weights[c]/sum(weights.values()) for c in weights])
    names = {name for _,name in risks}
    combinations = []
    if {'OOF-R1','OOF-R2','OOF-R3'} <= names:
        combinations += [('OOF-MEAN',['OOF-R1','OOF-R2','OOF-R3'],[1/3]*3),
            ('OOF-R1_MINUS_OOF-R2',['OOF-R1','OOF-R2'],[1,-1])]
        if 'APPARENT' in names:
            combinations += [('APPARENT_MINUS_OOF_MEAN',list(BRANCHES),[1,-1/3,-1/3,-1/3])]
    if 'PRIMARY' in names:
        combinations += [(name+'_MINUS_PRIMARY',[name,'PRIMARY'],[1,-1]) for name in sorted(names-{'PRIMARY'})]
    for scope,h in dict.fromkeys((scope,h) for scope,h,_ in prepared['original']):
        for name, components, coefficients in combinations:
            _derive(prepared,(scope,h,name),[(scope,h,v) for v in components],coefficients)
    prepared['keys'] = list(prepared['original'])
    return prepared


def _derive(prepared, key, sources, coefficients):
    from .f4 import _evaluation_metric
    values = [prepared['original'][k] for k in sources]
    reasons = sorted({r for v in values for r in v['reasons']})
    point = None if any(v['value'] is None for v in values) else math.fsum(
        a*v['value'] for a,v in zip(coefficients,values,strict=True))
    prepared['original'][key] = _evaluation_metric(point,reasons)
    prepared['derived'].append((key,sources,coefficients))
    if all(k in prepared['influence'] for k in sources):
        prepared['influence'][key] = sum(a*prepared['influence'][k] for a,k in zip(coefficients,sources,strict=True))


def studentized(prepared, generator, *, replicates=1999, block_size=32, progress=None, binding=None):
    """Joint stream, weighted-KM derivative, and bootstrap-t inversion."""
    from .f4 import (_evaluation_perturbation_normalize_center_weights,
        _evaluation_perturbation_weighted_km_block, _evaluation_perturbation_endpoint_block)
    from scipy.special import expit, logit
    need(replicates == 1999 and block_size in (32,64), 'REGISTERED_P_BUDGET')
    whole, keys = prepared['whole'], prepared['keys']
    n = len(whole['ids'])
    baseline = {k:float(covariance(whole,np.ones((1,n)),g[None,:])[0])
        for k,g in prepared['influence'].items()}
    statistics = {k:np.full(replicates,np.nan) for k in baseline}
    failures = {k:np.zeros(replicates,dtype=np.uint8) for k in baseline}
    if progress is not None:
        from . import nested_loco as nseal
        from .bundle import canonical_json_bytes,strict_json_bytes
        from .carriers import open_carrier
        from .f4 import write_deterministic_zip
        import hashlib
        progress=Path(progress);progress.mkdir(parents=True,exist_ok=True)
        authority={'binding':binding,'keys':[list(k) for k in baseline],
            'patient_order':whole['ids'],'block_size':block_size,'replicates':replicates}
        stamp=nseal._sha(authority)
    for start in range(0,replicates,block_size):
        count = min(block_size,replicates-start)
        if progress is not None:
            checkpoint=progress/f'P{start+1:04d}.zip'
            before=nseal._sha(generator.bit_generator.state)
            if checkpoint.is_file():
                with open_carrier(checkpoint) as carrier:
                    meta=strict_json_bytes(carrier.read('state.json'))
                    raw=carrier.read('statistics.f64');flags=carrier.read('failures.u8')
                need(meta['binding']==stamp and meta['start']==start and meta['count']==count
                    and meta['state_before_sha256']==before
                    and meta['statistics_sha256']==hashlib.sha256(raw).hexdigest()
                    and meta['failures_sha256']==hashlib.sha256(flags).hexdigest()
                    and nseal._sealed({k:v for k,v in meta.items() if k!='identity_sha256'})==meta,
                    'P_CHECKPOINT_DRIFT')
                values=np.frombuffer(raw,dtype='<f8').reshape(len(baseline),count)
                codes=np.frombuffer(flags,dtype='u1').reshape(len(baseline),count)
                for i,key in enumerate(baseline):
                    statistics[key][start:start+count]=values[i]
                    failures[key][start:start+count]=codes[i]
                generator.bit_generator.state=meta['state_after']
                continue
        raw = generator.exponential(size=(count,n))
        weights, valid = _evaluation_perturbation_normalize_center_weights(whole,raw)
        need(valid.all(), 'RNG_WEIGHT_INVALID')
        values, gradients = {}, {}
        for pop in prepared['populations']:
            ix = pop['indices']
            selected_weights = weights[:,ix]
            steps = _evaluation_perturbation_weighted_km_block(pop,selected_weights)
            endpoints = {h:_evaluation_perturbation_endpoint_block(pop,selected_weights,steps,h)
                for h in {prepared['entries'][key]['horizon'] for key in pop['entries']}}
            for key in pop['entries']:
                entry = prepared['entries'][key]
                value, gradient, _ = weighted_auc_if(pop,entry['risk'],entry['horizon'],selected_weights,
                    steps=steps,endpoint=endpoints[entry['horizon']],rank=entry['rank'])
                full = np.zeros((count,n)); full[:,ix] = gradient
                values[key], gradients[key] = value, full
        for key,sources,coefs in prepared['derived']:
            if key in baseline:
                values[key] = sum(a*values[k] for a,k in zip(coefs,sources,strict=True))
                gradients[key] = sum(a*gradients[k] for a,k in zip(coefs,sources,strict=True))
        for key in baseline:
            theta = prepared['original'][key]['value']
            value, gradient = values[key], gradients[key]
            variance = covariance(whole,weights,gradient)
            good = np.isfinite(variance) & (variance > 0) & np.isfinite(value)
            codes=(~np.isfinite(variance)).astype('u1')|((variance<=0).astype('u1')<<1)|((~np.isfinite(value)).astype('u1')<<2)
            paired = '_MINUS_' in key[2]
            if not paired:
                good &= (value > 0) & (value < 1) & (0 < theta < 1)
                codes|=(((value<=0)|(value>=1)|(not (0 < theta < 1))).astype('u1')<<3)
            with np.errstate(divide='ignore',invalid='ignore'):
                t = (value-theta)/np.sqrt(variance) if paired else (
                    (logit(value)-logit(theta))*value*(1-value)/np.sqrt(variance))
            statistics[key][start:start+count] = np.where(good,t,np.nan)
            failures[key][start:start+count]=codes
        if progress is not None:
            packed=np.array([statistics[k][start:start+count] for k in baseline],dtype='<f8').tobytes()
            flags=np.array([failures[k][start:start+count] for k in baseline],dtype='u1').tobytes()
            meta=nseal._sealed({'binding':stamp,'start':start,'count':count,
                'state_before_sha256':before,'state_after':generator.bit_generator.state,
                'statistics_sha256':hashlib.sha256(packed).hexdigest(),'failures_sha256':hashlib.sha256(flags).hexdigest()})
            write_deterministic_zip(checkpoint,{'state.json':canonical_json_bytes(meta),
                'statistics.f64':packed,'failures.u8':flags})
        del gradients, values
    output = {}
    for key in keys:
        point = prepared['original'][key]
        record = {'point':point['value'], 'interval':None, 'status':'UNRELIABLE',
            'reasons':list(point['reasons']), 'P_count':replicates, 'valid_P_count':0,
            'invalid_P_ids':[], 'method':'CENTER_EXP1_STUDENTIZED_WEIGHTED_KM_IF'}
        if key not in baseline:
            record['status'] = 'NOT_ESTIMABLE'
        else:
            t, theta = statistics[key], point['value']
            good = np.isfinite(t)
            record['valid_P_count'] = int(good.sum())
            record['invalid_P_ids'] = (np.flatnonzero(~good)+1).tolist()
            record['failure_P_ids']={name:(np.flatnonzero(failures[key]&bit)+1).tolist()
                for bit,name in ((1,'NONFINITE_KM_IF_VARIANCE'),(2,'NONPOSITIVE_WEIGHTED_VARIANCE'),
                    (4,'NONFINITE_WEIGHTED_AUC'),(8,'BOUNDARY_LOGIT_INPUT')) if (failures[key]&bit).any()}
            paired = '_MINUS_' in key[2]
            if not paired and not 0 < theta < 1: record['reasons'].append('BOUNDARY_AUC')
            elif not math.isfinite(baseline[key]) or baseline[key] <= 0: record['reasons'].append('DEGENERATE_VARIANCE')
            elif not good.all(): record['reasons'].append('INVALID_STUDENTIZED_P')
            else:
                quantiles = np.quantile(t,[.975,.025],method='linear')
                se = math.sqrt(baseline[key])
                interval = theta-quantiles*se if paired else expit(logit(theta)-quantiles*se/(theta*(1-theta)))
                record.update(interval=interval.tolist(),status='RESEARCH_CANDIDATE',reasons=[])
        output[key] = record
    return output


def _psd_root(matrix):
    values, vectors = np.linalg.eigh((matrix+matrix.T)/2)
    tolerance = 128*np.finfo(float).eps*max(1.,float(np.linalg.norm(matrix,ord=2)))*len(matrix)
    need(values.min(initial=0) >= -tolerance, 'COVARIANCE_NOT_PSD')
    return vectors*np.sqrt(np.maximum(values,0))[None,:]


def hierarchical_input(prepared):
    """Full aligned covariance across branches, times and OOF repeats."""
    from scipy.special import logit
    keys = [k for k in prepared['entries'] if k[0] != 'MICRO'
        and 0 < prepared['original'][k]['value'] < 1]
    coordinates = sorted(set((h,name) for _,h,name in keys))
    ix = {k:i for i,k in enumerate(coordinates)}
    groups = []
    for center, members, *_ in prepared['whole']['groups']:
        selected = sorted([k for k in keys if k[0] == center],key=lambda k:ix[k[1:]])
        selected = [k for k in selected if np.dot(prepared['influence'][k],prepared['influence'][k]) > 0]
        if not selected:
            continue
        point = np.array([prepared['original'][k]['value'] for k in selected])
        gradient = np.array([prepared['influence'][k][members] for k in selected])
        gradient /= (point*(1-point))[:,None]
        cov = len(members)/(len(members)-1)*(gradient@gradient.T)
        _psd_root(cov)
        groups.append({'center':center,'keys':selected,'index':np.array([ix[k[1:]] for k in selected]),
            'z':logit(point),'covariance':cov})
    return {'coordinates':coordinates,'groups':groups}


def _conditional_posterior(data, tau_b, tau_e, *, mu_sd=2.5, moments=False):
    """K-dimensional mu solve; PSD measurement covariance needs no ridge."""
    k = len(data['coordinates'])
    precision, score = np.eye(k)/mu_sd**2, np.zeros(k)
    logdet, quadratic, total = 0.,0.,0
    prepared = []
    for group in data['groups']:
        v,z,ix = group['covariance'],group['z'],group['index']
        q = np.eye(len(z))*tau_e**2 + tau_b**2
        w = v+q
        chol = np.linalg.cholesky(w)
        inv = np.linalg.solve(chol.T,np.linalg.solve(chol,np.eye(len(z))))
        precision[np.ix_(ix,ix)] += inv
        score[ix] += inv@z
        logdet += 2*float(np.log(np.diag(chol)).sum())
        quadratic += float(z@inv@z); total += len(z)
        if moments:
            a = v@inv
            conditional = v-v@inv@v
            prepared.append((group,a,z-a@z,_psd_root(conditional)))
    chol = np.linalg.cholesky(precision)
    covariance_mu = np.linalg.solve(chol.T,np.linalg.solve(chol,np.eye(k)))
    mean_mu = covariance_mu@score
    log_evidence = -.5*(total*math.log(2*math.pi)+logdet+k*math.log(mu_sd**2)
        +2*float(np.log(np.diag(chol)).sum())+quadratic-float(score@mean_mu))
    return (log_evidence,mean_mu,_psd_root(covariance_mu),prepared) if moments else log_evidence


def _improper_zero_scale(data):
    """Detect unresolved singular boundaries, without turning tolerance into proof.

    After integrating the common mean, redundant noiseless constraints give
    tau_e**(-r) at a boundary, or radius**(-r) at the two-scale corner. Equal
    estimated AUCs at different scientific coordinates are not aliases.
    """
    k,c=len(data['coordinates']),len(data['groups'])
    design,means=[],[]
    for i,g in enumerate(data['groups']):
        try:
            np.linalg.cholesky(g['covariance'])
        except np.linalg.LinAlgError:
            pass
        else:
            continue  # Even a very small positive variance is not a zero constraint.
        values,vectors=np.linalg.eigh(g['covariance'])
        tolerance=128*np.finfo(float).eps*max(1.,float(np.linalg.norm(g['covariance'],ord=2)))*len(values)
        null=vectors[:,values<=tolerance].T
        if not len(null):continue
        x=np.zeros((len(g['z']),k+c));x[np.arange(len(g['z'])),g['index']]=1;x[:,k+i]=1
        design.append(null@x);means.append(null@g['z'])
    if not design:return None
    x=np.vstack(design);y=np.concatenate(means)
    for name,xx,minimum in [('TAU_E_BOUNDARY',x,1),('TWO_SCALE_CORNER',x[:,:k],2)]:
        solution,_,rank,_=np.linalg.lstsq(xx,y,rcond=128*np.finfo(float).eps*max(xx.shape))
        residual=float(np.linalg.norm(xx@solution-y))
        tolerance=512*np.finfo(float).eps*max(1.,float(np.linalg.norm(y)),float(np.linalg.norm(xx)))*max(xx.shape)
        deficit=len(y)-rank
        if deficit>=minimum and residual<=tolerance:
            return {'status':'SINGULAR_LIKELIHOOD_UNRESOLVED','boundary':name,'constraint_dimension':len(y),
                'supported_rank':int(rank),'singularity_order':int(deficit),'constraint_residual':residual}
    return None


def _hierarchical_quadrature(data, scale, order):
    from scipy.special import roots_genlaguerre, logsumexp
    nodes, weights = roots_genlaguerre(order,-.5)
    tau = scale*np.sqrt(2*nodes)
    pairs = [(float(b),float(e)) for b in tau for e in tau]
    logs = np.array([_conditional_posterior(data,b,e) for b,e in pairs])
    logs += (np.log(weights)[:,None]+np.log(weights)[None,:]-math.log(math.pi)).ravel()
    normalizer = float(logsumexp(logs))
    probability = np.exp(logs-normalizer)
    need(np.isfinite(probability).all() and abs(float(probability.sum())-1) < 1e-10,
        'POSTERIOR_QUADRATURE_INVALID')
    return pairs,probability,normalizer


def _posterior_samples(prepared, data, quadrature, uniforms):
    from scipy.special import ndtri, expit
    pairs, probability, _ = quadrature
    draws = np.searchsorted(np.cumsum(probability),uniforms[:,0],side='right')
    draws = np.minimum(draws,len(pairs)-1)
    k = len(data['coordinates'])
    normal = ndtri(np.clip(uniforms[:,1:],np.finfo(float).eps,1-np.finfo(float).eps))
    output = {key:np.empty(len(uniforms)) for g in data['groups'] for key in g['keys']}
    for node in np.unique(draws):
        selected = np.flatnonzero(draws == node)
        _,mean,root,groups = _conditional_posterior(data,*pairs[node],moments=True)
        mu = mean[None,:] + normal[selected,:k]@root.T
        offset = k
        for group,a,intercept,conditional_root in groups:
            count = len(group['z'])
            theta = expit(intercept[None,:] + mu[:,group['index']]@a.T
                +normal[selected,offset:offset+count]@conditional_root.T)
            offset += count
            for j,key in enumerate(group['keys']):
                output[key][selected] = theta[:,j]
    for key,sources,coefs in prepared['derived']:
        if key[0] != 'MICRO' and all(s in output for s in sources):
            output[key] = sum(a*output[s] for a,s in zip(coefs,sources,strict=True))
    return output


def _posterior_summary(samples):
    return {key:np.array([float(v.mean()),*np.quantile(v,[.025,.975],method='linear')])
        for key,v in samples.items()}


def hierarchical(prepared, *, scale, numerical_seed):
    """Conditional Gaussian, positive-scale integration, shared nonlinear draws.

    Separate grid and Sobol refinements diagnose both errors. Two independent
    scrambles are fixed numeric streams, not clinical resampling. Exhaustion
    publishes a numerical failure, never an apparently reliable interval.
    """
    from scipy.stats import qmc
    from .evaluation_extension import decision
    contract = decision()['hierarchical']
    need(scale in (.25,.5,1.), 'PRIOR_NOT_REGISTERED')
    data = hierarchical_input(prepared)
    keys = [k for k in prepared['keys'] if k[0] != 'MICRO']
    output = {key:{'point':None,'interval':None,'status':'NOT_ESTIMABLE',
        'reasons':list(prepared['original'][key]['reasons']) or ['BOUNDARY_OR_DEGENERATE_OBSERVATION'],
        'method':'HIERARCHICAL_LOGIT_AUC','prior_scale':scale} for key in keys}
    if not data['groups']:
        return output, {'status':'NO_SUPPORTED_LIKELIHOOD','prior_scale':scale}
    improper=_improper_zero_scale(data)
    if improper is not None:
        for key,row in output.items():
            if prepared['original'][key]['status']=='ESTIMABLE':
                row.update(status='NOT_ESTIMABLE',reasons=[improper['status']])
        return output,{**improper,'prior_scale':scale}
    dimension = 1+len(data['coordinates'])+sum(len(g['z']) for g in data['groups'])
    streams = [qmc.Sobol(d=dimension,scramble=True,seed=int(s)).random_base2(14)
        for s in np.random.SeedSequence(numerical_seed).generate_state(2)]
    previous = _hierarchical_quadrature(data,scale,12)
    last, errors, passed = {}, {}, False
    for order,power in ((24,13),(48,14)):
        current = _hierarchical_quadrature(data,scale,order)
        big = [_posterior_summary(_posterior_samples(prepared,data,current,u[:2**power])) for u in streams]
        low_grid = _posterior_summary(_posterior_samples(prepared,data,previous,streams[0][:2**power]))
        low_sobol = _posterior_summary(_posterior_samples(prepared,data,current,streams[0][:2**(power-1)]))
        last = big[0]
        errors = {key:np.maximum.reduce([abs(last[key]-comparison[key])
            for comparison in (big[1],low_grid,low_sobol)]) for key in last}
        evidence_error=float(abs(np.expm1(np.clip(current[2]-previous[2],-700,700))))
        evidence_pass=evidence_error<=contract['numerical_normalizer_relative_tolerance']
        passed = evidence_pass and all(v[0] <= contract['numerical_mean_absolute_tolerance']
            and max(v[1:]) <= contract['numerical_endpoint_absolute_tolerance'] for v in errors.values())
        if passed:
            break
        previous = current
    coordinate_pass = {key:bool(evidence_pass and v[0] <= contract['numerical_mean_absolute_tolerance']
        and max(v[1:]) <= contract['numerical_endpoint_absolute_tolerance']) for key,v in errors.items()}
    for key, summary in last.items():
        accepted = coordinate_pass[key]
        output[key] = {'point':float(summary[0]),'interval':summary[1:].tolist() if passed else None,
            'diagnostic_interval':summary[1:].tolist(),'status':'RESEARCH_CANDIDATE' if accepted else 'NUMERICAL_FAILURE',
            'reasons':[] if accepted else ['INTEGRATION_NOT_CONVERGED'], 'method':'HIERARCHICAL_LOGIT_AUC',
            'prior_scale':scale,'numerical_error':errors[key].tolist()}
        output[key]['interval'] = summary[1:].tolist() if accepted else None
    diagnostics = {'status':'CONVERGED' if passed else 'INTEGRATION_NOT_CONVERGED',
        'scale':scale,'laguerre_order':order,'sobol_power':power,'scrambles':2,
        'base_coordinates':[list(k) for g in data['groups'] for k in g['keys']],
        'covariance_blocks':[{ 'center':g['center'],'keys':[list(k) for k in g['keys']],
            'values':g['covariance'].tolist()} for g in data['groups']],
        'log_evidence':current[2], 'normalizer_relative_error':evidence_error,'ridge':0,
        'coordinates_converged':sum(coordinate_pass.values()),'coordinates_attempted':len(coordinate_pass)}
    return output, diagnostics


@lru_cache(maxsize=8)
def scenario(ordinal):
    from .f4 import _evaluation_perturbation_simulation_decision, _evaluation_perturbation_simulation_calibrate
    from .evaluation_extension import decision
    from . import nested_loco as n
    need(type(ordinal) is int and 1 <= ordinal <= 8, 'SCENARIO_INVALID')
    old = _evaluation_perturbation_simulation_decision()['scenarios']
    source = old[ordinal-1 if ordinal <= 6 else 4]
    centers = []
    for i,c in enumerate(source['centers']):
        gamma = -math.log1p(-c['latent_censor_probability'])/12
        lam = _evaluation_perturbation_simulation_calibrate(c['n'],c['expected_observed_events'],gamma,12)
        beta = decision()['research']['risk_signal_heterogeneity'][i] if ordinal == 7 else 1.
        centers.append({**c,'gamma':gamma,'lambda':lam,'beta':beta})
    value = {'ordinal':ordinal,'centers':centers,'decision_sha256':decision()['identity_sha256']}
    lower, higher = _truth(value,128), _truth(value,256)
    need(set(lower) == set(higher) and max(abs(lower[k]-higher[k]) for k in lower) < 2e-10,
        'TRUTH_INTEGRATION_NOT_CONVERGED')
    value['truth'] = higher
    value['identity_sha256'] = n._sha({**value,'truth':[
        {'coordinate':list(k),'value':v} for k,v in higher.items()]})
    return value


def _truth(spec, order):
    from scipy.special import ndtr
    z,w = np.polynomial.legendre.leggauss(order)
    cs = spec['centers']; count = len(cs)
    lam = np.array([c['lambda'] for c in cs]); pi = np.array([c['n'] for c in cs],float); pi /= pi.sum()
    result = {}
    for h in MONTHS:
        case = -np.expm1(-h*lam[:,None]*np.exp(z))
        survival = np.exp(-h*lam[:,None]*np.exp(z))
        pc, pn = case@(w/2), survival@(w/2)
        cached = {}
        for name in BRANCHES:
            sigma = 0. if name == 'APPARENT' else .5
            beta = np.array([c['beta'] for c in cs])
            if spec['ordinal'] == 8 and name == 'OOF-R1': beta[-1] *= -1
            signature = (sigma,tuple(beta))
            if signature in cached:
                numerators = cached[signature]
            else:
                numerators = np.zeros((count,count))
                for c in range(count):
                    for d in range(count):
                        shift = math.log(lam[c])-math.log(lam[d])
                        if sigma:
                            p = ndtr((shift+beta[c]*z[:,None]-beta[d]*z[None,:])/(math.sqrt(2)*sigma))
                            numerators[c,d] = float((w/2*case[c])@p@(w/2*survival[d]))
                        else:
                            need(beta[c] > 0 and beta[d] > 0,'CLEAN_TRUTH_SLOPE_INVALID')
                            cuts = [-1.,*sorted(x for x in ((-beta[d]-shift)/beta[c],
                                (beta[d]-shift)/beta[c]) if -1 < x < 1),1.]
                            parts = []
                            for left,right in zip(cuts[:-1],cuts[1:],strict=True):
                                x = (right-left)/2*z+(right+left)/2
                                top = np.clip((beta[c]*x+shift)/beta[d],-1,1)
                                v = -1+(top[:,None]+1)*(z[None,:]+1)/2
                                integrated = (top+1)/4*(np.exp(-h*lam[d]*np.exp(v))@w)
                                parts.append(float(((right-left)/4*w*(-np.expm1(-h*lam[c]*np.exp(x))))@integrated))
                            numerators[c,d] = math.fsum(parts)
                cached[signature] = numerators
            within = np.diag(numerators)/(pc*pn)
            result['MICRO',h,name] = float(pi@numerators@pi/((pi@pc)*(pi@pn)))
            result['EQUAL_CENTER',h,name] = float(within.mean())
            result['PATIENT_WEIGHTED_CENTER',h,name] = float(pi@within)
            for c,v in zip(cs,within,strict=True): result[c['name'],h,name] = float(v)
        for scope in ('MICRO','EQUAL_CENTER','PATIENT_WEIGHTED_CENTER',*[c['name'] for c in cs]):
            mean = math.fsum(result[scope,h,f'OOF-R{r}'] for r in (1,2,3))/3
            result[scope,h,'OOF-MEAN'] = mean
            result[scope,h,'APPARENT_MINUS_OOF_MEAN'] = result[scope,h,'APPARENT']-mean
            result[scope,h,'OOF-R1_MINUS_OOF-R2'] = result[scope,h,'OOF-R1']-result[scope,h,'OOF-R2']
    return result


def _generator(root_seed, ordinal, replication, domain):
    return np.random.Generator(np.random.PCG64(np.random.SeedSequence(root_seed,
        spawn_key=(ordinal,replication,domain))))


def dataset(task, spec):
    rng = _generator(task['seed'],task['scenario'],task['replication'],0)
    ids,centers,times,events,scores = [],[],[],[],[]
    for i,c in enumerate(spec['centers']):
        z = rng.uniform(-1,1,c['n'])
        event = rng.exponential(1/(c['lambda']*np.exp(z)))
        censor = rng.exponential(1/c['gamma'],c['n'])
        through = (event > 36)&(censor > 36)
        times.extend(np.where(through,math.nextafter(36.,math.inf),np.minimum(event,censor)))
        events.extend(((event <= censor)&(event <= 36)).astype(int))
        centers.extend([c['name']]*c['n']); ids.extend(f'S{i+1}-P{j+1:03d}' for j in range(c['n']))
        scores.extend(math.log(c['lambda'])+c['beta']*z)
    scores = np.array(scores)
    noise = _generator(task['seed'],task['scenario'],task['replication'],1).normal(0,.5,(3,len(ids)))
    branch_scores = {'APPARENT':scores, **{f'OOF-R{i+1}':scores+noise[i] for i in range(3)}}
    if spec['ordinal'] == 8:
        ix = np.array(centers) == spec['centers'][-1]['name']
        branch_scores['OOF-R1'][ix] = (2*math.log(spec['centers'][-1]['lambda'])
            -scores[ix]+noise[0,ix])
    risks = {(h,name):-np.expm1(-h*np.exp(score)) for h in MONTHS for name,score in branch_scores.items()}
    return prepare(ids,times,events,centers,risks)


def tasks(owner):
    from .evaluation_extension import RESEARCH_UNITS, decision
    need(owner in RESEARCH_UNITS,'RESEARCH_OWNER_INVALID')
    index, offset = RESEARCH_UNITS.index(owner), 0
    contract = decision()['research']
    rows = []
    for phase,count,seed in [('pilot',100,contract['pilot_seed']),('confirmation',2000,contract['confirmation_seed'])]:
        for s in range(1,9):
            for r in range(1,count+1):
                if (offset+(s-1)*count+r-1)%7 == index:
                    rows.append({'phase':phase,'scenario':s,'replication':r,'seed':seed,
                        'decision_sha256':decision()['identity_sha256']})
        offset += 8*count
    # Fixed coordinates, long multi-center fits first within each phase. The
    # existing ordered ReadyPool refills; completion order cannot change sums.
    return sorted(rows,key=lambda t:(t['phase'] != 'pilot',t['scenario'] <= 4,-t['scenario'],t['replication']))


def task_name(task):
    return f"{task['phase']}-S{task['scenario']}-D{task['replication']:04d}.zip"


def _research_job(task, *, root, provenance):
    from . import nested_loco as n
    from .carriers import open_carrier, source_pin
    from .bundle import canonical_json_bytes, strict_json_bytes
    from .f4 import _evaluation_check_producer, write_deterministic_zip
    from .evaluation_extension import decision
    need(task['decision_sha256'] == decision()['identity_sha256'],'TASK_AUTHORITY_DRIFT')
    path = Path(root)/'datasets'/task_name(task)
    partial=Path(root)/'partial'/task_name(task).removesuffix('.zip')
    def retire_partial():
        if not partial.exists() and not partial.is_symlink():return
        need(partial.is_dir() and not partial.is_symlink() and partial.resolve()==partial.absolute(),
            'PARTIAL_PATH_INVALID')
        expected={'STUDENTIZED.json','HIERARCHICAL_0.5.json','HIERARCHICAL_0.25.json','HIERARCHICAL_1.0.json'}
        retire_private_publication_members(partial/'P',{f'P{i:04d}.zip' for i in range(1,2000,32)})
        retire_private_publication_members(partial,expected)
    if path.is_file():
        with open_carrier(path) as carrier:
            saved = strict_json_bytes(carrier.read('result.json'))
        _evaluation_check_producer(saved,provenance['generations'])
        need(saved['task'] == task and saved['status'] == 'COMPLETED'
            and n._sealed({k:v for k,v in saved.items() if k != 'identity_sha256'}) == saved,'TASK_RESULT_DRIFT')
        reduce_records([saved])
        retire_accepted_publication_temps(path)
        retire_partial()
        return {'task':task,'pin':source_pin(path)}
    spec = scenario(task['scenario']); prepared = dataset(task,spec)
    partial.mkdir(parents=True,exist_ok=True)
    def method(name,compute):
        target=partial/(name+'.json')
        if target.is_file():
            value=strict_json_bytes(target.read_bytes())
            _evaluation_check_producer(value,provenance['generations'])
            need(value['task']==task and value['method']==name
                and n._sealed({k:v for k,v in value.items() if k!='identity_sha256'})==value,'METHOD_CHECKPOINT_DRIFT')
        else:
            result,info=compute()
            value=n._sealed({'task':task,'method':name,'producer':provenance['producer'],
                'rows':[{'coordinate':list(k),'value':v} for k,v in result.items()],'diagnostics':info})
            n._write_exact_once(target,canonical_json_bytes(value),'METHOD_CHECKPOINT_PUBLICATION_DRIFT')
        return {tuple(r['coordinate']):r['value'] for r in value['rows']},value['diagnostics']
    student,_=method('STUDENTIZED',lambda:(studentized(prepared,
        _generator(task['seed'],task['scenario'],task['replication'],2),progress=partial/'P',binding=task),{}))
    results = [('STUDENTIZED',student)]
    diagnostics = {}
    if len(spec['centers']) == 6:
        numerical_seed = np.random.SeedSequence(task['seed'],spawn_key=(task['scenario'],task['replication'],3))
        # The same numerical substreams across priors make sensitivity paired;
        # no data/weight random generator is consumed by integration.
        numeric_root = numerical_seed.generate_state(4).tolist()
        for scale in (.5,.25,1.):
            result, info = method(f'HIERARCHICAL_{scale}',lambda:hierarchical(prepared,scale=scale,numerical_seed=numeric_root))
            results.append((f'HIERARCHICAL_{scale}',result))
            diagnostics[str(scale)] = info
        for scale in ('0.25','1.0'):
            if scale in diagnostics:
                diagnostics[scale].pop('covariance_blocks',None)
    records = []
    for method,result in results:
        for key,row in result.items():
            truth = spec['truth'][key]
            original = prepared['original'][key]
            interval = row['interval']
            point_estimable = original['status'] == 'ESTIMABLE'
            published = interval is not None and row['status'] == 'RESEARCH_CANDIDATE'
            records.append({'method':method,'coordinate':list(key),'truth':truth,
                'original_point':original,'result':row,'original_estimable':point_estimable,
                'published':published,'covered':bool(published and interval[0] <= truth <= interval[1]),
                'null_difference':key[2].endswith('MINUS_OOF-R2') and abs(truth) < 1e-14,
                'rejects_zero':bool(published and (interval[0] > 0 or interval[1] < 0)),
                'width':interval[1]-interval[0] if published else None})
    value = n._sealed({'kind':'PADML_AUC_RESEARCH_DATASET_V1','task':task,'producer':provenance['producer'],
        'scenario_identity':spec['identity_sha256'],'status':'COMPLETED','records':records,
        'integration':diagnostics,'P_count':1999,'hierarchical_inferences':3 if len(spec['centers']) == 6 else 0,
        'new_training_mice':0,'new_prediction_model_fits':0})
    write_deterministic_zip(path,{'result.json':canonical_json_bytes(value)})
    reduce_records([value])
    retire_accepted_publication_temps(path)
    retire_partial()
    return {'task':task,'pin':source_pin(path)}


def reduce_records(records):
    """Streaming sufficient counts; no deletion of failed draws/datasets."""
    summary, seen = {}, set()
    for value in records:
        task = value['task']
        coordinate = (task['phase'],task['scenario'],task['replication'])
        need(coordinate not in seen and value['status'] == 'COMPLETED'
            and value['P_count'] == 1999 and value['new_training_mice'] == value['new_prediction_model_fits'] == 0,
            'DATASET_DUPLICATE_OR_INVALID')
        seen.add(coordinate)
        truth = scenario(task['scenario'])['truth']
        expected = {('STUDENTIZED',*key) for key in truth}
        if task['scenario'] > 4:
            expected |= {(f'HIERARCHICAL_{scale}',*key) for scale in (.5,.25,1.) for key in truth if key[0] != 'MICRO'}
        need(len(value['records']) == len(expected) and {
            (r['method'],*r['coordinate']) for r in value['records']} == expected,
            'DATASET_METHOD_COORDINATE_COVERAGE')
        for r in value['records']:
            need(r['truth'] == truth[tuple(r['coordinate'])], 'DATASET_TRUTH_DRIFT')
            key = (task['phase'],task['scenario'],r['method'],*r['coordinate'])
            row = summary.setdefault(key,{'datasets':0,'original_estimable':0,'published':0,'covered':0,
                'null_estimable':0,'false_rejections':0,'width_sum':0.,'failure_reasons':Counter()})
            row['datasets'] += 1
            row['original_estimable'] += int(r['original_estimable'])
            if r['original_estimable']:
                row['published'] += int(r['published']); row['covered'] += int(r['covered'])
                row['width_sum'] += r['width'] or 0.
                row['null_estimable'] += int(r['null_difference'])
                row['false_rejections'] += int(r['null_difference'] and r['rejects_zero'])
                row['failure_reasons'].update(r['result']['reasons'])
    return [{'key':list(key),**{k:(dict(v) if isinstance(v,Counter) else v) for k,v in row.items()}}
        for key,row in sorted(summary.items())]


def run_research(run, unit):
    from functools import partial
    from . import nested_loco as n
    from .bundle import canonical_json_bytes, strict_json_bytes
    from .carriers import open_carrier, file_reference, validate_reference
    from .f4 import _evaluation_provenance, _evaluation_check_producer
    from .runtime import _ready_ordered, MIN_WORKER_MEMORY_BYTES
    from .evaluation_extension import decision, PREFIX
    need(run.get('evaluation_extension') == decision(),'RUN_AUTHORITY_DRIFT')
    root = Path(run['run_root'])/'units'/unit['unit_id']/PREFIX/'research'
    target = root/'result.json'
    provenance = _evaluation_provenance(run)
    if target.is_file():
        value = strict_json_bytes(target.read_bytes())
        _evaluation_check_producer(value,provenance['generations'])
        need(value['decision_sha256'] == decision()['identity_sha256'] and value['owner_unit'] == unit['unit_id']
            and value['status'] == 'COMPLETED' and n._sealed({k:v for k,v in value.items()
                if k != 'identity_sha256'}) == value,'RESEARCH_RESULT_DRIFT')
        for ref in value['formal_references']: validate_reference(ref,run)
        return value
    (root/'datasets').mkdir(parents=True,exist_ok=True)
    coordinates = tasks(unit['unit_id'])
    job = partial(_research_job,root=root,provenance=provenance)
    job.reuse_worker_function = True
    completed = _ready_ordered(job,coordinates,policy=run['resource_policy'],root=root,
        retained_bytes_per_task=1024*1024,publication_bytes=16*1024**2,
        transient_bytes_per_worker=16*1024**2,memory_bytes_per_worker=max(MIN_WORKER_MEMORY_BYTES,768*1024**2),
        task_write_paths=[(root/'datasets'/task_name(t),) for t in coordinates])
    need([r['task'] for r in completed] == coordinates,'RESEARCH_COORDINATE_COVERAGE')
    def records():
        for r in sorted(completed,key=lambda r:(r['task']['phase'],r['task']['scenario'],r['task']['replication'])):
            with open_carrier(root/'datasets'/task_name(r['task'])) as archive:
                yield strict_json_bytes(archive.read('result.json'))
    summary = reduce_records(records())
    value = n._sealed({'kind':'PADML_AUC_RESEARCH_OWNER_V1','decision_sha256':decision()['identity_sha256'],
        'owner_unit':unit['unit_id'],'producer':provenance['producer'],'status':'COMPLETED',
        'dataset_count':len(coordinates),'P_count':len(coordinates)*1999,
        'hierarchical_inferences':sum(t['scenario'] > 4 for t in coordinates)*3,
        'summary':summary,'direct_consumer_completed':True,
        'formal_references':[file_reference(root/'datasets'/task_name(r['task']),'AUC_RESEARCH_DATASET',run)
            for r in completed], 'reliability':'PENDING_COMPLETE_INDEPENDENT_CONFIRMATION_REDUCTION'})
    n._write_exact_once(target,canonical_json_bytes(value),'AUC_RESEARCH_OWNER_PUBLICATION_DRIFT')
    return value


def complete_summary(owners):
    from .evaluation_extension import decision, RESEARCH_UNITS
    need(set(owners) == set(RESEARCH_UNITS),'SEVEN_OWNER_COVERAGE')
    combined = {}
    p_count = inference_count = dataset_count = 0
    for uid,record in owners.items():
        need(record['owner_unit'] == uid and record['decision_sha256'] == decision()['identity_sha256']
            and record['status'] == 'COMPLETED' and record['dataset_count'] == len(tasks(uid)),
            'OWNER_RESULT_DRIFT')
        p_count += record['P_count']; inference_count += record['hierarchical_inferences']
        dataset_count += record['dataset_count']
        for row in record['summary']:
            key = tuple(row['key'])
            target = combined.setdefault(key,{'datasets':0,'original_estimable':0,'published':0,'covered':0,
                'null_estimable':0,'false_rejections':0,'width_sum':0.,'failure_reasons':Counter()})
            for name,value in row.items():
                if name == 'failure_reasons': target[name].update(value)
                elif name != 'key': target[name] += value
    need((dataset_count,p_count,inference_count) == (16800,33583200,25200),'REGISTERED_BUDGET_INCOMPLETE')
    expected = set()
    for s in range(1,9):
        truth = scenario(s)['truth']
        for phase in ('pilot','confirmation'):
            expected.update((phase,s,'STUDENTIZED',*key) for key in truth)
            if s > 4:
                expected.update((phase,s,f'HIERARCHICAL_{scale}',*key)
                    for scale in (.5,.25,1.) for key in truth if key[0] != 'MICRO')
    need(set(combined) == expected, 'REGISTERED_SUMMARY_COORDINATE_COVERAGE')
    rows = []
    gates = decision()['research']['gates']
    for key,row in sorted(combined.items()):
        phase,scenario_id,method,scope,horizon,branch = key
        need(row['datasets'] == (100 if phase == 'pilot' else 2000),'DATASET_DENOMINATOR_INCOMPLETE')
        denominator = row['original_estimable']
        need(0 <= row['covered'] <= row['published'] <= denominator <= row['datasets'], 'SUMMARY_COUNT_DRIFT')
        coverage = row['covered']/denominator if denominator else None
        rate = row['published']/denominator if denominator else None
        coverage_ci = _wilson(row['covered'],denominator) if denominator else None
        rejection_ci = _wilson(row['false_rejections'],row['null_estimable']) if row['null_estimable'] else None
        reasons = []
        if denominator == 0: reasons.append('NO_ESTIMABLE_ORIGINAL_POINTS')
        else:
            if coverage < gates['coverage_min']: reasons.append('COVERAGE_BELOW_REGISTERED_MINIMUM')
            if coverage_ci[0] < gates['wilson95_coverage_lower_min']: reasons.append('WILSON_COVERAGE_LOWER_BELOW_MINIMUM')
            if rate < gates['publication_rate_min']: reasons.append('PUBLICATION_RATE_BELOW_REGISTERED_MINIMUM')
        if rejection_ci is not None and rejection_ci[1] > gates['wilson95_zero_difference_rejection_upper_max']:
            reasons.append('NULL_FALSE_REJECTION_UPPER_ABOVE_MAXIMUM')
        rows.append({'coordinate':list(key), **{k:dict(v) if isinstance(v,Counter) else v for k,v in row.items()},
            'coverage':coverage,'coverage_mc95_wilson':coverage_ci,'publication_rate':rate,
            'null_rejection_mc95_wilson':rejection_ci,
            'mean_published_width':row['width_sum']/row['published'] if row['published'] else None,
            'status':('PRETRIAL_ONLY' if phase == 'pilot' else 'VALIDATED_REGISTERED_SCOPE' if not reasons
                else 'FAILED_REGISTERED_SCOPE'), 'gate_failures':reasons})
    return {'dataset_count':dataset_count,'joint_perturbations':p_count,'hierarchical_inferences':inference_count,
        'coordinates':rows,'status':'FIXED_RESEARCH_BUDGET_COMPLETED',
        'inference_scope':'CONDITIONAL_FIXED_PREDICTIONS_NOT_SELECTION_OR_FULL_MODEL_UNCERTAINTY',
        'clinical_coverage_claim':'SIMULATION_RESULTS_ARE_NOT_PATIENT_CENTER_COVERAGE_RATES'}


def _wilson(successes, total):
    need(type(successes) is int and type(total) is int and 0 <= successes <= total and total > 0,
        'MONTE_CARLO_DENOMINATOR_INVALID')
    z = 1.959963984540054
    p = successes / total
    denominator = 1 + z*z/total
    center = (p + z*z/(2*total))/denominator
    radius = z * math.sqrt(p*(1-p)/total + z*z/(4*total*total))/denominator
    return [max(0.,center-radius),min(1.,center+radius)]
