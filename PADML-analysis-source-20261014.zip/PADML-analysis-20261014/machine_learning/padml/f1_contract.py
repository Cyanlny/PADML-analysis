from __future__ import annotations

from pathlib import Path
from typing import Any, Mapping

from .bundle import (
    ContractError,
    canonical_json_bytes,
    sha256_bytes,
    strict_json_bytes,
    validate_sha256,
)


DIRECT_UNIT_IDS = ("data-binding", *(f"mice-fold-{fold}" for fold in range(1, 7)))
F1_INPUT_MANIFEST_IDENTITY = (
    "1e4971ee04610af54d45d79f7ad91b321b2fae8b4fa0ecb1a737bf17116dd458"
)


def _require(condition: bool, reason: str) -> None:
    if not condition:
        raise ContractError(reason)


def validate_f1_input_manifest(value: Any) -> dict[str, Any]:
    _require(type(value) is dict, "F1_INPUT_MANIFEST_NOT_OBJECT")
    manifest = dict(value)
    _require(
        set(manifest)
        == {
            "aggregate_evidence",
            "binding_contract_sha256",
            "direct_objects",
            "identity",
            "kind",
            "schema_version",
            "science_equivalence",
            "status",
            "training_universe",
        }
        and manifest["schema_version"] == "1.0.0"
        and manifest["kind"] == "PADML_F1_INPUT_MANIFEST"
        and manifest["status"] == "LOCALLY_REPLAYED"
        and manifest["identity"] == F1_INPUT_MANIFEST_IDENTITY
        and manifest["identity"]
        == sha256_bytes(
            canonical_json_bytes(
                {key: item for key, item in manifest.items() if key != "identity"}
            )
        )
        and type(manifest["direct_objects"]) is list
        and [row.get("unit_id") for row in manifest["direct_objects"]]
        == list(DIRECT_UNIT_IDS)
        and manifest["science_equivalence"]
        == {
            "direct_unit_count": 7,
            "f1_unit_count": 8,
            "imputation_dataset_count": 7440,
            "library_count": 372,
        },
        "F1_INPUT_MANIFEST_INVALID",
    )
    validate_sha256(manifest["binding_contract_sha256"], "f1.binding_contract")
    for row in manifest["direct_objects"]:
        _require(
            type(row) is dict
            and set(row)
            == {
                "artifact_sha256",
                "artifact_size_bytes",
                "object_key",
                "request_sha256",
                "result_sha256",
                "result_size_bytes",
                "source_object_key",
                "source_run_id",
                "transaction_id",
                "unit_id",
            }
            and type(row["artifact_size_bytes"]) is int
            and row["artifact_size_bytes"] > 0
            and type(row["result_size_bytes"]) is int
            and row["result_size_bytes"] > 0,
            f"F1_INPUT_OBJECT_INVALID:{row.get('unit_id') if isinstance(row, Mapping) else 'UNKNOWN'}",
        )
        for field in ("artifact_sha256", "request_sha256", "result_sha256"):
            validate_sha256(row[field], f"f1.{row['unit_id']}.{field}")
    return manifest


def load_f1_input_manifest(path: Path) -> dict[str, Any]:
    _require(
        path.is_absolute() and path.is_file() and not path.is_symlink(),
        "F1_INPUT_MANIFEST_PATH_INVALID",
    )
    raw = path.read_bytes()
    value = validate_f1_input_manifest(strict_json_bytes(raw, "F1_INPUT_MANIFEST"))
    _require(canonical_json_bytes(value) == raw, "F1_INPUT_MANIFEST_NONCANONICAL")
    return value
