#!/usr/bin/env python3
"""REAL_M01_COXTIME_FIXED_KERNEL_VALIDATION.

For main-process review, then H01's qualified padml-env Python only:
  python -B validation/native-coxtime-fixed-kernel-check.py \
      --package /opt/padml/candidate

Use the existing 2124-person FULL0 ANALYSIS imp01.csv and its original response
seal. Fixed parents: AST_ALT, Age, RBC, HGB, MCV, INR. Fit authority candidate 1
for ALL 300 epochs through _execute_final_refit_engine; save original model,
baseline and the first all-patient/all-month prediction once. This is a fixed
native-kernel check, not a selected winner, a development lock, M20 acceptance,
external validation, or full SHAP. No new MICE or patient sampling is performed.

Then consume retained objects: all 2124 patients in one batch, 12 original
training rows (two per validation center) in batch and separately, and the same
real rows appended as a prediction-only tail. R-reticulate uses the production
_FinalShapPythonPredictor (the actual factory in current f5_shap.R), with the
production R parent-design preparation. Compare its 6/12/24/36-month outputs
EXACTLY against Python; do not relax native replay/application equality.

A fit-start marker is published BEFORE training. An interrupted or partial fit
never triggers another fit automatically; preserve the original native failure
evidence and stop for main-process recovery. A complete saved fit is read only.
No formal lineage, owner, unit receipt, queue, or deployment is created.
"""

from __future__ import annotations

import argparse
import csv
import fcntl
import hashlib
import io
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import traceback

SCOPE = "REAL_M01_COXTIME_FIXED_KERNEL_VALIDATION"
FAMILY = "COXTIME_SET_A"
SELECTED = ["AST_ALT", "Age", "RBC", "HGB", "MCV", "INR"]
N = 2124
EPOCHS = 300
GIB = 1024**3


def need(condition, reason):
    if not condition:
        raise RuntimeError(reason)


def encoded(value):
    from padml.bundle import canonical_json_bytes
    return canonical_json_bytes(value)


def sha(value):
    return hashlib.sha256(encoded(value)).hexdigest()


def document(path):
    return json.loads(Path(path).read_bytes())


def pin(path):
    from padml.bundle import sha256_file
    path = Path(path)
    need(path.is_file() and not path.is_symlink(), "SOURCE_FILE_INVALID:" + str(path))
    return {"sha256": sha256_file(path), "size_bytes": path.stat().st_size}


def publish(path, raw):
    """One small publication, preserving an interrupted file for diagnosis."""
    pending = path.with_name(path.name + ".pending")
    need(not path.exists() and not pending.exists(), "PUBLICATION_ALREADY_PRESENT:" + str(path))
    with pending.open("xb") as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(pending, path)


def exact_document(path, value):
    if path.exists():
        need(path.read_bytes() == encoded(value), "VALIDATION_BINDING_DRIFT:" + str(path))
    else:
        publish(path, encoded(value))


def configure(package, output, rscript):
    need(sys.platform == "linux", "H01_LINUX_REQUIRED")
    need(not any(os.environ.get(k) for k in ("PADML_F45_RUN_PATH", "PADML_ARCHIVE_INDEX")),
         "USE_ISOLATED_VALIDATION_WITHOUT_FORMAL_RUN_CONTEXT")
    sys.path.insert(0, str(package))
    os.environ["PYTHONPATH"] = os.pathsep.join(filter(None, (str(package), os.environ.get("PYTHONPATH"))))
    os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
    os.environ["PADML_PYTHON"] = os.environ["RETICULATE_PYTHON"] = sys.executable
    if rscript:
        os.environ["PADML_RSCRIPT"] = rscript
    for key in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "VECLIB_MAXIMUM_THREADS", "NUMEXPR_NUM_THREADS"):
        os.environ[key] = "1"
    temporary = output / "tmp"
    temporary.mkdir(mode=0o700, exist_ok=True)
    for key in ("TMPDIR", "TMP", "TEMP"):
        os.environ[key] = str(temporary)
    tempfile.tempdir = str(temporary)
    os.environ["XDG_CACHE_HOME"] = str(output / "cache")
    os.environ["MPLCONFIGDIR"] = str(output / "cache/matplotlib")


def checked_inputs(base, science):
    from padml.f1_kernel import mice_terminal_valid
    from padml.f2_kernel import _response_rows
    folder = base / "full0-analysis"
    covariates = folder / "output/imputations/imp01.csv"
    response_path = base / "raw/response-seal.csv"
    spec, summary = document(folder / "spec.json"), document(folder / "output/summary.json")
    with covariates.open(encoding="utf-8-sig", newline="") as stream:
        reader = csv.DictReader(stream)
        rows = list(reader)
        fields = reader.fieldnames or []
    ids = [r["Patient_ID"] for r in rows]
    need(len(ids) == len(set(ids)) == N and all(ids), "REAL_FULL0_PATIENT_SCOPE_INVALID")
    need({"Patient_ID", "Center", *SELECTED} <= set(fields)
         and not {"All_Cause_Death", "Death_Followup_months"}.intersection(fields),
         "REAL_COVARIATE_CHANNEL_INVALID")
    need(spec["view"]["role"] == summary["role"] == "ANALYSIS"
         and spec["view"]["row_ids"] == spec["view"]["analysis_ids"] == ids
         and summary["status"] == "PASS" and summary["formal_m"] == 20
         and summary["active_target_count"] == 33 and summary["row_count"] == N
         and summary["row_ids_sha256"] == sha(ids) and mice_terminal_valid(summary),
         "EXISTING_REAL_MICE_NOT_ACCEPTED")
    _, responses = _response_rows(response_path.read_bytes())
    need(list(responses) == ids, "ORIGINAL_RESPONSE_ORDER_OR_SCOPE_DRIFT")
    centers = [str(c) for c in science["population"]["validation_centers"]]
    positions = []
    for center in centers:
        found = [i for i, r in enumerate(rows) if r["Center"] == center][:2]
        need(len(found) == 2, "TWO_ORIGINAL_ROWS_PER_VALIDATION_CENTER_REQUIRED")
        positions.extend(found)
    need(len(centers) == 6 and "55" not in centers and len(set(positions)) == 12,
         "ORIGINAL_12_ROW_SCOPE_INVALID")
    sources = {str(p): pin(p) for p in (covariates, response_path, folder / "spec.json", folder / "output/summary.json")}
    return rows, responses, positions, covariates, response_path, sources


def fit_or_resume(output, binding, task, rows, responses, recipe):
    import numpy as np
    from padml import f5
    names = ("model.bin", "baseline.bin", "fit-survival.npy", "refit.json")
    files = [output / name for name in names]
    started = output / "fit-started.json"
    if any(path.exists() for path in files) or started.exists():
        need(all(path.is_file() and not path.is_symlink() for path in files),
             "PARTIAL_FIT_REQUIRES_ORIGINAL_EVIDENCE_RECOVERY_NO_RETRAIN")
        record = document(files[3])
        need(record["binding_sha256"] == sha(binding), "RETAINED_REFIT_BINDING_DRIFT")
        for path in files[:3]:
            need(pin(path) == record["members"][path.name], "RETAINED_REFIT_BYTES_DRIFT")
        original = np.load(files[2], allow_pickle=False)
        trained = False
    else:
        need(not list(output.glob("*.pending")), "PARTIAL_FIT_PUBLICATION_REQUIRES_RECOVERY")
        publish(started, encoded({"scope": SCOPE, "binding_sha256": sha(binding), "epochs": EPOCHS}))
        # Exactly one native fit, using the original full training rows/response.
        fit = f5._execute_final_refit_engine(FAMILY, task, rows, responses, recipe)
        original = np.asarray(fit["survival"], dtype="float64")
        f5._seal_prediction_matrix([r["Patient_ID"] for r in rows], original.tolist(), f5.HORIZONS)
        need(fit["fit_health"]["training_epoch_count"] == EPOCHS, "FULL_300_EPOCHS_REQUIRED")
        publish(files[0], fit["model"])
        publish(files[1], fit["baseline"])
        buffer = io.BytesIO()
        np.save(buffer, original, allow_pickle=False)
        publish(files[2], buffer.getvalue())
        record = {"scope": SCOPE, "binding_sha256": sha(binding), "model_fit_count": 1,
                  "fixed_budget_epochs": EPOCHS, "fit_health": fit["fit_health"],
                  "members": {p.name: pin(p) for p in files[:3]}}
        publish(files[3], encoded(record))
        trained = True
    need(record["model_fit_count"] == 1 and record["fixed_budget_epochs"] == EPOCHS
         and record["fit_health"]["training_epoch_count"] == EPOCHS, "RETAINED_EPOCH_EVIDENCE_DRIFT")
    f5._seal_prediction_matrix([r["Patient_ID"] for r in rows], original.tolist(), f5.HORIZONS)
    return (files[0].read_bytes(), files[1].read_bytes()), original, record, trained


def equal_matrix(actual, expected, label):
    import numpy as np
    left, right = np.asarray(actual, dtype="float64"), np.asarray(expected, dtype="float64")
    need(left.shape == right.shape and bool(np.isfinite(left).all() and np.isfinite(right).all()),
         label + ":SHAPE_OR_FINITE")
    difference = float(np.max(np.abs(left - right)))
    need(bool(np.array_equal(left, right)), label + ":NONEXACT:max_abs=" + repr(difference))
    return {"shape": list(left.shape), "exact": True, "max_abs_error": difference}


R_BRIDGE = r'''
suppressPackageStartupMessages({library(jsonlite); library(reticulate)})
args <- commandArgs(TRUE)
stopifnot(length(args) == 1L)
spec_path <- normalizePath(args[[1L]], mustWork=TRUE)
spec <- fromJSON(spec_path, simplifyVector=FALSE)
scalar <- function(x) unname(unlist(x, use.names=FALSE)[[1L]])
need <- function(ok, code) if (!isTRUE(ok)) stop(code, call.=FALSE)
selected <- as.character(unlist(spec$selected_parents, use.names=FALSE))
patient <- read.csv(scalar(spec$covariate_path), check.names=FALSE,
                    stringsAsFactors=FALSE, colClasses="character")
source(scalar(spec$design_script), local=TRUE)
prepared <- padml_prepare_final_r_design(patient, selected, spec$recipe$predictor_rows,
  spec$recipe$transform_recipe, scalar(spec$family), scalar, need)
parents <- prepared$covariates[, selected, drop=FALSE]
idx <- as.integer(unlist(spec$check_indices_one_based, use.names=FALSE))
need(nrow(parents) == 2124L && length(idx) == 12L, "REAL_R_ROW_SCOPE_INVALID")
# Materialize R BLAS before embedding Python; Torch must still import through
# production _coxtime_native's temporary DEEPBIND flags, in this fresh process.
invisible(crossprod(matrix(seq_len(16L), nrow=4L)))
use_python(as.character(scalar(spec$python_executable)), required=TRUE)
py_run_string("import sys")
need(!py_eval("'torch' in sys.modules"), "TORCH_IMPORTED_BEFORE_DEEPBIND_CHECK")
module <- import("padml.f5", convert=FALSE)
need(!py_eval("'torch' in sys.modules"), "TORCH_IMPORTED_BEFORE_PRODUCTION_FACTORY")
flags_before <- py_eval("sys.getdlopenflags()")
predictor <- module$`_FinalShapPythonPredictor`(spec_path)
need(identical(flags_before, py_eval("sys.getdlopenflags()")), "DLOPEN_FLAGS_NOT_RESTORED")
predict <- function(x) {
  ans <- as.matrix(py_to_r(predictor$predict_survival(r_to_py(x))))
  need(identical(dim(ans), c(nrow(x), 4L)) && all(is.finite(ans)) &&
       all(ans >= 0 & ans <= 1), "REAL_R_SURVIVAL_INVALID")
  ans
}
values <- list(full=predict(parents), batch12=predict(parents[idx,,drop=FALSE]),
  single12=do.call(rbind,lapply(idx,function(i) predict(parents[i,,drop=FALSE]))),
  tail=predict(rbind(parents,parents[idx,,drop=FALSE])))
for (name in names(values)) {
  con <- file(file.path(dirname(spec_path),paste0(name,".f64")), "wb")
  tryCatch(writeBin(as.double(t(values[[name]])),con,size=8L,endian="little"),finally=close(con))
}
need(py_eval("sys.modules['torch'].get_num_threads() == 1 and sys.modules['torch'].get_num_interop_threads() == 1"),
     "R_EMBEDDED_TORCH_THREAD_DRIFT")
metadata <- list(status="PREDICTED",factory="padml.f5._FinalShapPythonPredictor",
  python=py_config()$python,reticulate=as.character(packageVersion("reticulate")),
  torch=py_eval("sys.modules['torch'].__version__"),torch_imported_before_factory=FALSE,
  dlopen_flags_restored=TRUE,engine_threads=1L,rows=2124L,check_rows=12L,horizons=c(6L,12L,24L,36L))
writeLines(toJSON(metadata,auto_unbox=TRUE,digits=NA),file.path(dirname(spec_path),"r-result.json"),useBytes=TRUE)
'''


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--package", type=Path, default=Path("/opt/padml/candidate"))
    parser.add_argument("--validation-root", type=Path, default=Path("/root/autodl-tmp/padml/validation/integrated-mice"))
    parser.add_argument("--output", type=Path)
    parser.add_argument("--rscript", default=os.environ.get("PADML_RSCRIPT"))
    args = parser.parse_args()
    package, base = args.package.resolve(strict=True), args.validation_root.resolve(strict=True)
    output = (args.output or base / "real-m01-coxtime-fixed-kernel").absolute()
    need(output.parent.is_dir() and output.parent.resolve(strict=True) == output.parent
         and not output.is_symlink() and not output.is_relative_to(package), "VALIDATION_OUTPUT_INVALID")
    output.mkdir(mode=0o700, exist_ok=True)
    configure(package, output, args.rscript)
    from padml import f4, f5, runtime
    from padml._science_authority import load_science_authority
    import numpy as np
    import pandas as pd
    descriptor = os.open(output, os.O_RDONLY)
    try:
        fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
        science = load_science_authority()["science"]
        contract = science["f2_model_development"]["coxtime"]
        candidate = contract["candidates"][0]
        need(contract["shared_candidate_parameters"]["maximum_epochs"] == EPOCHS,
             "AUTHORITY_COMPLETE_EPOCH_BUDGET_CHANGED")
        rows, responses, positions, covariates, response_path, input_pins = checked_inputs(base, science)
        recipe = f5._compile_partition_design_recipe(FAMILY, SELECTED,
            {"partition_id": SCOPE, "fit_ids": [r["Patient_ID"] for r in rows]}, output / "tmp")
        # Use the original FULL0 seed numerically, but do not manufacture the
        # formal NESTED_FULL_FINAL task/selected lock required by that route.
        seed = f4._f4_model_seed(FAMILY, {"purpose":"NESTED_FULL_FINAL","outer_fold":0,
            "repeat":0,"inner_fold":0,"imputation":1})
        task = {"family": FAMILY, "imputation": 1, "selected_parents": SELECTED,
            "parameters": {"family": FAMILY, "candidate_id": candidate["candidate_id"],
                           "parameters": candidate, "locked_epoch": EPOCHS}, "model_seed": seed}
        f5._validate_final_refit_locked_spec(FAMILY, task["parameters"])
        binding = {"scope": SCOPE, "formal_winner": False, "formal_lineage": False,
            "input_pins": input_pins, "patient_count": N, "imputation": 1,
            "task": task, "recipe": recipe, "source_members": f4._f45_source_member_sha256(),
            "dependency_lock": pin(package / "dependency-lock.json"), "script": pin(Path(__file__).resolve()),
            "python": sys.executable, "rscript": runtime.RSCRIPT_EXECUTABLE, "r_library": runtime.R_LIBRARY,
            "check_patient_ids": [rows[i]["Patient_ID"] for i in positions],
            "check_indices_zero_based": positions, "comparison": "EXACT_NO_RELAXED_TOLERANCE"}
        exact_document(output / "binding.json", binding)
        policy = {"configured_worker_ceiling": runtime.CPU_MINUS_8,"memory_bytes_per_worker":2*GIB,
            "memory_reserve_bytes":GIB,"scratch_bytes_per_worker":2*GIB,"scratch_reserve_bytes":0,
            "transfer_archive_worker_ceiling":2147483647}
        runtime.resource_admission(policy, runtime.observe_execution_resources(output), legal_tasks=1)
        objects, original, refit, trained = fit_or_resume(output,binding,task,rows,responses,recipe)
        result_path = output / "result.json"
        if result_path.is_file():
            result = document(result_path)
            need(result["binding_sha256"] == sha(binding) and result["status"] == "PASS_FIXED_KERNEL_ONLY",
                 "COMPLETED_VALIDATION_DRIFT")
            print(json.dumps({"scope":SCOPE,"status":"REUSED_COMPLETE_VALIDATION","new_fits":0,
                              "result":str(result_path)}),flush=True)
            return
        checks = {}
        full = f5._execute_final_refit_engine(FAMILY,task,rows,responses,recipe,
            retained_objects=objects,prediction_rows=rows)["survival"]
        checks["python_all2124_native_replay"] = equal_matrix(full,original,"FULL_RETAINED_REPLAY")
        selected_rows = [rows[i] for i in positions]
        selected = f5._execute_final_refit_engine(FAMILY,task,rows,responses,recipe,
            retained_objects=objects,prediction_rows=selected_rows,single_parity=True)
        checks["python_original12_batch"] = equal_matrix(selected["survival"],original[positions],"ORIGINAL12_BATCH")
        checks["python_original12_single"] = equal_matrix(selected["single_survival"],original[positions],"ORIGINAL12_SINGLE")
        bridge = output / "bridge-work"
        bridge.mkdir(mode=0o700,exist_ok=True)
        spec = {"scope":SCOPE,"family":FAMILY,"task":task,"recipe":recipe,"selected_parents":SELECTED,
            "covariate_path":str(covariates),"response_path":str(response_path),
            "model_path":str(output/"model.bin"),"baseline_path":str(output/"baseline.bin"),
            "model_sha256":refit["members"]["model.bin"]["sha256"],"python_executable":sys.executable,
            "design_script":str(package/"padml/kernels/f5_design.R"),
            "check_indices_one_based":[i+1 for i in positions]}
        exact_document(bridge/"spec.json",spec)
        driver = bridge/"bridge.R"
        if driver.exists():
            need(driver.read_text()==R_BRIDGE,"R_DRIVER_DRIFT")
        else:
            publish(driver,R_BRIDGE.encode())
        # The requested predictor factory is a class in the current production API.
        predictor = f5._FinalShapPythonPredictor(str(bridge/"spec.json"))
        frame = pd.DataFrame(rows).loc[:,SELECTED]
        horizon_indices = [f5.HORIZONS.index(h) for h in f5.REPORT_HORIZONS]
        expected_four = original[:,horizon_indices]
        checks["python_shap_predictor_full"] = equal_matrix(predictor.predict_survival(frame),expected_four,"PYTHON_FOUR_OUTPUTS")
        extended = pd.concat([frame,frame.iloc[positions]],ignore_index=True)
        expected_tail = np.concatenate([expected_four,expected_four[positions]],axis=0)
        checks["python_shap_predictor_2124_plus12_tail"] = equal_matrix(predictor.predict_survival(extended),expected_tail,"PYTHON_TAIL_BLOCK")
        del predictor
        env = {**os.environ,**runtime.THREAD_ENV}
        env["R_LIBS_USER"] = os.pathsep.join(filter(None,(getattr(f5,"_SHAP_R_LIBRARY",""),runtime.R_LIBRARY)))
        with (bridge/"stdout.log").open("wb") as stdout,(bridge/"stderr.log").open("wb") as stderr:
            child = subprocess.run([runtime.RSCRIPT_EXECUTABLE,"--vanilla",str(driver),str(bridge/"spec.json")],
                cwd=package,env=env,stdout=stdout,stderr=stderr,timeout=3600,check=False)
        need(child.returncode==0 and (bridge/"r-result.json").is_file(),"REAL_R_RETICULATE_FAILED:"+str(bridge))
        expected = {"full":expected_four,"batch12":expected_four[positions],
                    "single12":expected_four[positions],"tail":expected_tail}
        for name,matrix in expected.items():
            path=bridge/(name+".f64")
            need(path.stat().st_size==matrix.size*8,"R_BRIDGE_OUTPUT_SIZE_INVALID:"+name)
            value=np.fromfile(path,dtype="<f8").reshape(matrix.shape)
            checks["R_reticulate_"+name]=equal_matrix(value,matrix,"R_VS_PYTHON_"+name)
        metadata=document(bridge/"r-result.json")
        need(Path(metadata["python"]).resolve()==Path(sys.executable).resolve(),"R_RETICULATE_PYTHON_DRIFT")
        result={"scope":SCOPE,"status":"PASS_FIXED_KERNEL_ONLY","binding_sha256":sha(binding),
            "candidate_id":candidate["candidate_id"],"epochs":EPOCHS,"model_fit_count":1,
            "patient_count":N,"check_rows":12,"horizons":list(f5.REPORT_HORIZONS),
            "model":refit["members"]["model.bin"],"baseline":refit["members"]["baseline.bin"],
            "checks":checks,"R_bridge":metadata,"formal_winner":False,"full_shap_performed":False,
            "interpretation":"M01 fixed-candidate full-budget native/retained/embedded predictor check only"}
        publish(result_path,encoded(result))
        # Keep sole fitted objects/first predictions and compact successful proof.
        # Failed runs retain bridge inputs, numerical outputs and diagnostic logs.
        shutil.rmtree(bridge)
        print(json.dumps({"scope":SCOPE,"status":result["status"],"new_fits":int(trained),
                          "result":str(result_path)}),flush=True)
    except BaseException:
        with (output/"failure.log").open("a",encoding="utf-8") as stream:
            stream.write(traceback.format_exc())
        raise
    finally:
        os.close(descriptor)


if __name__ == "__main__":
    main()
