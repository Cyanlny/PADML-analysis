#!/usr/bin/env Rscript
# Full real M01 population/background, bounded two-parent Cox kernel comparison.
# This validates the explanation/transport, not a formal family/variable search.
suppressPackageStartupMessages({library(survival);library(kernelshap);library(jsonlite);library(digest)})
source("/opt/padml/candidate/padml/kernels/f5_design.R")
source("/opt/padml/candidate/padml/kernels/f5_shap.R")
root <- "/root/autodl-tmp/padml/validation/integrated-mice"
target <- file.path(root,"shap-real-m01");dir.create(target,showWarnings=FALSE)
need <- function(x, code) if (!isTRUE(x)) stop(code,call.=FALSE)
scalar <- function(x) unlist(x,use.names=FALSE)[[1L]]
data <- read.csv(file.path(root,"full0-analysis/output/imputations/imp01.csv"),check.names=FALSE)
y <- read.csv(file.path(root,"raw/response-seal.csv"),check.names=FALSE)
stopifnot(identical(data$Patient_ID,y$Patient_ID))
parents <- c("AST_ALT","Age")
x <- data[,parents,drop=FALSE]
fit <- coxph(Surv(y$Death_Followup_months,y$All_Cause_Death)~AST_ALT+Age,
  data=x,ties="breslow",x=TRUE,y=TRUE,singular.ok=FALSE)
base <- basehaz(fit,centered=TRUE)
pred <- function(object,newdata) {
  z <- padml_coxph_survival(fit,as.matrix(newdata),c(6,12,24,36),need,base)
  colnames(z) <- c("t6","t12","t24","t36");z
}
RNGkind("Mersenne-Twister","Inversion","Rejection")
set.seed(780000001L)
saved_reference <- file.path(target,"reference.rds")
if (file.exists(saved_reference)) {
  retained <- readRDS(saved_reference)
  stopifnot(identical(retained$input_sha,digest(list(x,y),algo="sha256")))
  reference <- retained$result;reference_time <- retained$elapsed
} else {
  reference_time <- system.time(reference <- kernelshap(NULL,X=x,bg_X=x,pred_fun=pred,
    feature_names=parents,exact=TRUE,verbose=FALSE))[["elapsed"]]
  saveRDS(list(input_sha=digest(list(x,y),algo="sha256"),result=reference,elapsed=reference_time),saved_reference)
}
reference_rng <- .Random.seed
spec <- charToRaw(paste0("REAL_M01_FULL_BACKGROUND_TRANSPORT:",digest(x,algo="sha256")))
model_sha <- digest(fit,algo="sha256")
candidate_mode <- if (dir.exists(file.path(target,"patients"))) "RETAINED_PATIENT_RECOVERY" else "FRESH"
candidate_time <- system.time(value <- padml_kernelshap_component("COX_PH",1L,model_sha,
  parents,data$Patient_ID,x,function(z) pred(NULL,z),780000001L,need,
  target,spec))[["elapsed"]]
stopifnot(identical(reference_rng,.Random.seed),value$kind=="PADML_SHAP_FLOAT64_COMPONENT_V1")
deltas <- list()
for (field in names(value$tensors)) {
  tensor <- value$tensors[[field]]
  bytes <- readBin(file.path(target,tensor$member),"double",n=prod(unlist(tensor$shape)),
    size=8L,endian="little")
  expected <- if (field=="predicted_risk") as.numeric(t(1-reference$predictions)) else
    unlist(lapply(seq_len(nrow(x)),function(i) unlist(lapply(seq_len(4L),function(j)
      if (field=="risk_contributions") -reference$S[[j]][i,] else rep(0,length(parents))),use.names=FALSE)),use.names=FALSE)
  cat(field,"max_abs_delta",max(abs(bytes-expected)),"identical",identical(bytes,expected),"\n")
  # Native full-X prediction and the registered per-patient producer can differ
  # by one rounding unit. Keep the existing scientific comparison tolerance.
  stopifnot(all(abs(bytes-expected) <= 1e-12+1e-10*pmax(abs(bytes),abs(expected))))
  deltas[[field]] <- max(abs(bytes-expected))
  if (field=="risk_contributions") {
    original <- unlist(lapply(seq_len(nrow(x)),function(i) {
      patient <- readRDS(file.path(target,"patients",sprintf("P%05d.rds",i)))$result
      unlist(lapply(patient$S,function(v) -as.numeric(v)),use.names=FALSE)
    }),use.names=FALSE)
    stopifnot(identical(unname(bytes),unname(original)))
  }
}
write_json(value,file.path(target,"shap.json"),auto_unbox=TRUE,null="null",digits=NA)
checkpoints <- list.files(file.path(target,"patients"),full.names=TRUE)
pins <- vapply(checkpoints,digest,character(1),algo="sha256",file=TRUE,serialize=FALSE)
restored <- padml_kernelshap_component("COX_PH",1L,model_sha,parents,data$Patient_ID,x,
  function(z) pred(NULL,z),780000001L,need,target,spec)
stopifnot(identical(restored,value),identical(reference_rng,.Random.seed),
  identical(pins,vapply(checkpoints,digest,character(1),algo="sha256",file=TRUE,serialize=FALSE)),
  !file.exists(file.path(target,"kernelshap-return.rds")))
result <- list(status="PASS",scope="REAL_M01_KERNEL_NOT_FORMAL_SELECTION",patients=nrow(x),
  background_rows=nrow(x),parents=parents,reference_seconds=reference_time,candidate_seconds=candidate_time,
  candidate_mode=candidate_mode,performance_comparison=candidate_mode=="FRESH",
  native_max_abs_delta=deltas,patient_transport_bitwise=TRUE,rng_exact=TRUE,
  recovery_exact=TRUE,whole_mi_rds_copies=0L,float64_entities=3L)
write_json(result,file.path(root,"shap-real-comparison.json"),auto_unbox=TRUE,pretty=TRUE,digits=NA)
cat(toJSON(result,auto_unbox=TRUE),"\n")
