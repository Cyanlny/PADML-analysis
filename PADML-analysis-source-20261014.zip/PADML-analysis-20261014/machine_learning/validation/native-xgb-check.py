"""Real M01 fixed-candidate native STOP/refit/replay; not formal selection."""
import csv
import json
from pathlib import Path
import sys
import time

sys.path.insert(0, '/opt/padml/candidate')
import numpy as np
import pandas as pd
import xgboost as xgb
from padml import f2_kernel as k, f5
from padml.bundle import canonical_json_bytes, sha256_bytes, sha256_file

root = Path('/root/autodl-tmp/padml/validation/integrated-mice')
work = root/'xgb-real'
work.mkdir(exist_ok=True)
rows = list(csv.DictReader((root/'full0-analysis/output/imputations/imp01.csv').open()))
responses = {r['Patient_ID']:r for r in csv.DictReader((root/'raw/response-seal.csv').open())}
selected = ['AST_ALT', 'Age', 'RBC', 'MCV', 'INR', 'BMI']
design = np.asarray([[float(row[c]) for c in selected] for row in rows])
times = np.asarray([float(responses[r['Patient_ID']]['Death_Followup_months']) for r in rows])
events = np.asarray([int(responses[r['Patient_ID']]['All_Cause_Death']) for r in rows])
indices = np.arange(len(rows))
fit, evaluation = indices[indices % 5 != 0], indices[indices % 5 == 0]
ids = [r['Patient_ID'] for r in rows]
partition = {'fit_ids':[ids[i] for i in fit], 'evaluation_ids':[ids[i] for i in evaluation]}
parameters = {'eta':.05,'max_depth':2,'min_child_weight':2.,'subsample':.8,
    'colsample_bytree':.8,'reg_lambda':1.,'reg_alpha':0.,'gamma':0.,
    'tree_method':'hist','max_bin':256,'max_nrounds':5000,'early_stopping_rounds':75,
    'stop_scope':'training_only','post_selection_refit':'full_main_training_at_best_rounds',
    'locked_iteration_mode':'full_main_training_without_reselection'}
seed = 310101
handoff = work/'handoff/booster.ubj'
seal_path = work/'seal.json'
if seal_path.is_file():
    sealed, handoff_record = json.loads(seal_path.read_text())
else:
    sealed, handoff_record = k._xgb_prediction_function_seal(xgb, parameters, partition,
        design[fit],design[evaluation],times[fit],events[fit],seed,'CPU',np,handoff)
    seal_path.write_bytes(canonical_json_bytes([sealed,handoff_record]))
runtime = k._xgb_runtime_from_handoff(xgb,sealed,handoff_record,design[fit],design[evaluation],
    times[fit],events[fit],np,expected_path=handoff,expected_parameters=parameters,
    expected_seed=seed,expected_partition=partition)

def response(indices):
    frame = pd.DataFrame([responses[ids[i]] for i in indices])
    raw = frame.to_csv(index=False,lineterminator='\n').encode()
    return {'private_bytes':raw,'sha256':sha256_bytes(raw),'size_bytes':len(raw),
        'row_count':len(indices),'row_ids_sha256':k._sha([ids[i] for i in indices])}

fit_response, evaluation_response = response(fit), response(evaluation)
old = dict(k.__dict__)
exec((work/'reference-cox.py').read_text(),old)
report = {'status':'RUNNING','scope':'REAL_M01_FIXED_XGB_NATIVE_NOT_FORMAL_SEARCH',
    'patients':len(rows),'maximum_rounds':5000,'checks':{}}
for label, subset in [('ALL',None),('H36',[i for i,j in enumerate(evaluation) if rows[j]['Center']!='55'])]:
    arguments = dict(fit_response=fit_response,evaluation_response=evaluation_response,
        runtime=runtime,xgb_patience=75)
    old_context = old['_grouped_cox_evaluation_context'](fit_response,evaluation_response,
        partition['fit_ids'],partition['evaluation_ids'],evaluation_indices=subset)
    new_context = k._grouped_cox_evaluation_context(fit_response,evaluation_response,
        partition['fit_ids'],partition['evaluation_ids'],evaluation_indices=subset)
    t = time.perf_counter()
    reference = old['_grouped_cox_loss_path'](sealed,**arguments,evaluation_context=old_context)
    t1 = time.perf_counter()
    observed = k._grouped_cox_loss_path(sealed,**arguments,evaluation_context=new_context)
    t2 = time.perf_counter()
    a,b = np.asarray(reference['losses']),np.asarray(observed['losses'])
    assert a.shape==b.shape and np.allclose(a,b,rtol=1e-10,atol=1e-12)
    assert int(a.argmin())==int(b.argmin())
    report['checks'][label] = {'loss_count':len(a),'best_round':int(a.argmin())+1,
        'max_abs_delta':float(abs(a-b).max()),'reference_seconds':t1-t,'candidate_seconds':t2-t1,
        'validation_n':observed['validation_n']}

predictors = k.predictor_contract(Path(k.__file__).parent)
recipe = {'schema_version':'1.0.0','kind':'PADML_F5_FINAL_DESIGN_RECIPE_V1',
    'family':'XGBOOST_COX','selected_parents':selected,
    'preprocessing_mode':'F2_RAW_CANONICAL_AUTHORITY_LEVELS',
    'predictor_contract_sha256':k._sha(predictors),
    'predictor_rows':[r for r in predictors['variables'] if r['name'] in selected],
    'transform_recipe':None,'coxtime_standardization':None}
task = {'family':'XGBOOST_COX','imputation':1,'selected_parents':selected,'model_seed':300001,
    'parameters':{'family':'XGBOOST_COX','candidate_id':'FIXED_KERNEL_VALIDATION',
      'parameters':parameters,'selected_rounds':report['checks']['ALL']['best_round']}}
model,baseline,numbers = work/'model.bin',work/'baseline.bin',work/'numbers.json'
if numbers.is_file():
    value=json.loads(numbers.read_text())
    assert value['task']==task and value['recipe']==recipe
    assert sha256_file(model)==value['model_sha256'] and sha256_file(baseline)==value['baseline_sha256']
    fitted=value['result']
else:
    fitted=f5._execute_final_refit_engine('XGBOOST_COX',task,rows,responses,recipe)
    model.write_bytes(fitted.pop('model'));baseline.write_bytes(fitted.pop('baseline'))
    numbers.write_bytes(canonical_json_bytes({'task':task,'recipe':recipe,'result':fitted,
        'model_sha256':sha256_file(model),'baseline_sha256':sha256_file(baseline)}))
objects=(model.read_bytes(),baseline.read_bytes())
replay=f5._execute_final_refit_engine('XGBOOST_COX',task,rows,responses,recipe,retained_objects=objects)
assert replay['survival']==fitted['survival']
base=json.loads(objects[1]);risk=runtime['booster'].predict(xgb.DMatrix(design[fit]),output_margin=True)
reference_breslow=old['_breslow'](times[fit],events[fit],np.exp(risk),np)
current_breslow=k._breslow(times[fit],events[fit],np.exp(risk),np)
assert np.array_equal(reference_breslow[0],current_breslow[0])
assert np.allclose(reference_breslow[1],current_breslow[1],rtol=1e-10,atol=1e-12)
application=[dict(row) for row in rows[:12]]
applied=f5._execute_final_refit_engine('XGBOOST_COX',task,rows,responses,recipe,
    retained_objects=objects,prediction_rows=application,single_parity=True)
assert np.allclose(applied['survival'],np.asarray(fitted['survival'])[:12],rtol=1e-10,atol=1e-12)
assert np.allclose(applied['survival'],applied['single_survival'],rtol=1e-10,atol=1e-12)
report.update(status='PASS',retained_replay_exact=True,application_rows=12,
    application_scope='RESPONSE_FREE_COMPLETE_TRAINING_ROWS_BATCH_SINGLE_PREDICTION',
    breslow_max_abs_delta=float(abs(reference_breslow[1]-current_breslow[1]).max()),
    model_sha256=sha256_file(model),baseline_sha256=sha256_file(baseline))
(root/'xgb-real-comparison.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
