#!/usr/bin/env Rscript
# Compare changed prediction/preparation kernels on the real M01, not a formal search.
suppressPackageStartupMessages({library(survival);library(glmnet);library(jsonlite);library(digest);library(ranger);library(gbm);library(rstpm2)})
root <- "/root/autodl-tmp/padml/validation/integrated-mice"
load_functions <- function(path) {
  scope <- new.env(parent=globalenv())
  for (expr in parse(path)) if (is.call(expr) && identical(expr[[1L]], as.name("<-")) &&
      is.call(expr[[3L]]) && identical(expr[[3L]][[1L]], as.name("function"))) eval(expr,scope)
  scope
}
current <- load_functions("/opt/padml/candidate/padml/kernels/f2_model_development.R")
reference <- load_functions("/opt/padml/build/performance/reference-model.R")
source("/opt/padml/candidate/padml/kernels/f5_design.R")
old_design <- load_functions("/opt/padml/build/performance/reference-design.R")
data <- read.csv(file.path(root,"full0-analysis/output/imputations/imp01.csv"),check.names=FALSE)
response <- read.csv(file.path(root,"raw/response-seal.csv"),check.names=FALSE)
stopifnot(identical(data$Patient_ID,response$Patient_ID))
x <- as.matrix(data[,c("AST_ALT","Age","RBC","MCV","INR","BMI")])
time <- response$Death_Followup_months; event <- response$All_Cause_Death
result <- list(scope="REAL_M01_KERNEL_EQUIVALENCE_NOT_FORMAL_SEARCH",patients=nrow(x))
check <- function(name,observed,expected) {
  stopifnot(identical(dim(observed),dim(expected)),all(is.finite(observed)),all(is.finite(expected)))
  delta <- max(abs(observed-expected))
  stopifnot(all(abs(observed-expected) <= 1e-12+1e-10*pmax(1,abs(expected))))
  result[[name]] <<- list(max_abs_delta=delta,values=length(observed))
}
save_result <- function() write_json(result,file.path(root,"prediction-comparison.json"),auto_unbox=TRUE,pretty=TRUE,digits=NA)
counter <- 0L
current$glmnet <- function(...) {counter <<- counter+1L; glmnet::glmnet(...)}
penalty <- c(0,rep(1,ncol(x)-1L))
for (alpha in c(.01,.5,1)) {
  upper_old <- reference$data_driven_cox_lambda_upper_bound(x,time,event,alpha,penalty)
  upper_new <- current$data_driven_cox_lambda_upper_bound(x,time,event,alpha,penalty)
  stopifnot(identical(upper_old,upper_new),identical(upper_new,
    current$data_driven_cox_lambda_upper_bound(x,time,event,alpha,penalty)))
  lambda <- upper_new$resolved_lambda_max*10^seq(0,-4,length.out=150L)
  old <- glmnet(x,Surv(time,event),family="cox",cox.ties="breslow",alpha=alpha,
    lambda=lambda,penalty.factor=penalty,standardize=TRUE)
  new <- glmnet(x,Surv(time,event),family="cox",cox.ties="breslow",alpha=alpha,
    lambda=upper_old$resolved_lambda_max*10^seq(0,-4,length.out=150L),penalty.factor=penalty,standardize=TRUE)
  stopifnot(identical(coef(old),coef(new)),identical(old$lambda,new$lambda),
    identical(old$dev.ratio,new$dev.ratio),length(old$lambda)==150L)
  risk <- exp(predict(new,x,type="link"))
  for (j in seq_len(150L)) {
    a <- reference$breslow(time,event,risk[,j]); b <- current$breslow(time,event,risk[,j])
    check(paste0("elastic_baseline_",alpha,"_",j),b$cumulative,a$cumulative)
    check(paste0("elastic_prediction_",alpha,"_",j),
      current$survival_from_risk(b,risk[,j],0:36),reference$survival_from_risk(a,risk[,j],0:36))
  }
}
stopifnot(counter==3L)
result$elastic <- list(pilot_executions=counter,pilot_requests=6L,lambda_count=150L,alphas=c(.01,.5,1),full_coefficients_and_deviance_identical=TRUE)
save_result()
frame <- data.frame(.time=time,.event=event,x)
fit <- coxph(Surv(.time,.event)~.,data=frame,ties="breslow",x=TRUE,y=TRUE,
  singular.ok=FALSE,control=coxph.control(eps=1e-11,iter.max=100L))
current$validate_coxph_fit_health(fit,0L,ncol(x))
native <- survfit(fit,newdata=as.data.frame(x),se.fit=FALSE)
positions <- findInterval(0:36,native$time)
expected <- matrix(1,nrow(x),37L)
expected[,positions>0L] <- t(as.matrix(native$surv)[positions[positions>0L],,drop=FALSE])
check("coxph_monthly",padml_coxph_survival(fit,x,0:36,current$need),expected)
rm(native);gc(FALSE)
save_result()
set.seed(70300001L,kind="L'Ecuyer-CMRG")
forest <- ranger(x=x,y=Surv(time,event),num.trees=500L,mtry=3L,min.node.size=3L,
  splitrule="logrank",seed=70300001L,num.threads=1L,write.forest=TRUE)
current$validate_rsf_fit_health(forest,0L,500L,colnames(x),3L)
native <- predict(forest,data=x,num.threads=1L)$survival
positions <- findInterval(0:36,forest$unique.death.times)
expected <- matrix(1,nrow(x),37L); expected[,positions>0L] <- native[,positions[positions>0L],drop=FALSE]
check("rsf_monthly",padml_rsf_survival(forest,x,0:36,current$need),expected)
check("rsf_single",padml_rsf_survival(forest,x[1,,drop=FALSE],0:36,current$need),expected[1,,drop=FALSE])
rm(forest,native);gc(FALSE);save_result()
set.seed(70300001L,kind="L'Ecuyer-CMRG")
boost <- gbm.fit(x=x,y=Surv(time,event),distribution="coxph",n.trees=3000L,
  interaction.depth=2L,n.minobsinnode=10L,shrinkage=.01,bag.fraction=.75,verbose=FALSE)
current$validate_gbm_fit_health(boost,0L,3000L,colnames(x),nrow(x))
risk <- exp(predict(boost,x,n.trees=3000L,type="link"))
a <- reference$breslow(time,event,risk);b <- current$breslow(time,event,risk)
check("gbm_baseline",b$cumulative,a$cumulative)
check("gbm_monthly",current$survival_from_risk(b,risk,0:36),reference$survival_from_risk(a,risk,0:36))
rm(boost);gc(FALSE);save_result()
frame <- frame[,c(".time",".event","AST_ALT","Age")]
fit <- stpm2(Surv(.time,.event)~AST_ALT+Age,data=frame,df=3L,tvc=list(AST_ALT=1L),padml.fpm.domain=c(0,15))
current$validate_fpm_fit_health(fit,0L,c(3L,1L))
design <- x[,c("AST_ALT","Age"),drop=FALSE]
check("fpm_monthly",padml_predict_final_fpm_survival(fit,design,1:36),
  old_design$padml_predict_final_fpm_survival(fit,design,1:36))
check("fpm_four_single",padml_predict_final_fpm_survival(fit,design[1,,drop=FALSE],c(6,12,24,36)),
  old_design$padml_predict_final_fpm_survival(fit,design[1,,drop=FALSE],c(6,12,24,36)))
result$status <- "PASS";save_result()
cat("PASS",nrow(x),"patients; pilot 3/6; 450 lambda paths; five R families\n")
