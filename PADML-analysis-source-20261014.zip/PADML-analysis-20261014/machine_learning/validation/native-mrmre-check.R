#!/usr/bin/env Rscript
mode <- commandArgs(TRUE)[[1L]]
stopifnot(mode %in% c("reference", "candidate"))
if (mode == "candidate") .libPaths(c("/opt/padml/build/performance/library-mrmre",.libPaths()))
if (mode == "reference" && nzchar(Sys.getenv("PADML_MRMRE_REFERENCE_LIBRARY")))
  .libPaths(c(Sys.getenv("PADML_MRMRE_REFERENCE_LIBRARY"),.libPaths()))
suppressPackageStartupMessages({library(mRMRe);library(survival);library(jsonlite)})
stopifnot(as.character(packageVersion("mRMRe")) ==
  if (mode == "reference") "2.1.2.2.9001" else "2.1.2.2.9002")
root <- "/root/autodl-tmp/padml/validation/integrated-mice"
mRMRe::set.thread.count(1L)
for (expr in parse("/opt/padml/candidate/padml/kernels/f2_model_development.R")) {
  if (is.call(expr) && identical(expr[[1L]], as.name("<-")) && is.call(expr[[3L]]) &&
      identical(expr[[3L]][[1L]], as.name("function"))) eval(expr)
}
vars <- read.csv("/opt/padml/candidate/padml/science/variable.csv",colClasses="character",check.names=FALSE)
vars <- vars[(vars$selector_eligible=="true" | vars$forced=="true") & vars$variable!="Prior_LE_Surgery_cat",]
df <- read.csv(file.path(root,"full0-analysis/output/imputations/imp01.csv"),check.names=FALSE)
response <- read.csv(file.path(root,"raw/response-seal.csv"),check.names=FALSE)
stopifnot(identical(df$Patient_ID,response$Patient_ID),nrow(vars)==43L)
x <- df[,vars$variable,drop=FALSE]
for (i in seq_len(nrow(vars))) {
  row <- as.list(vars[i,,drop=FALSE]); name <- row$variable
  if (row$type %in% c("binary","ordered","unordered"))
    x[[name]] <- factor(as.character(x[[name]]),levels=locked_levels(row),ordered=row$type!="unordered")
  else {
    x[[name]] <- as.numeric(x[[name]])
    if (row$selector_representation == "LOG1P") x[[name]] <- log1p(x[[name]])
  }
}
y <- Surv(response$Death_Followup_months,response$All_Cause_Death)
set.seed(70200001L,kind="L'Ecuyer-CMRG")
data <- mRMRe::mRMR.data(data=data.frame(.SURV=y,x,check.names=FALSE))
elapsed <- system.time(fit <- mRMRe::mRMR.classic(data=data,target_indices=1L,
  feature_count=ncol(x),method="exhaustive",continuous_estimator="spearman",
  fixed_feature_count=0L,outX=FALSE,bootstrap_count=0L))[["elapsed"]]
health <- checked_mrmre_numerics(fit,data,x,y)
result <- list(ranking=mRMRe::solutions(fit),scores=mRMRe::scores(fit),
  associations=mRMRe::mim(data,continuous_estimator="spearman",outX=FALSE),rng=.Random.seed,
  elapsed=elapsed,package=as.character(packageVersion("mRMRe")),cases=list(),health=health)
for (case in seq_len(160L)) {
  set.seed(case)
  n <- 80L+case%%31L
  a <- round(rnorm(n),1); b <- round(rnorm(n),1); c <- rnorm(n)
  if (case %% 4L == 0L) {a[1:3]<-NA_real_;b[4:6]<-NA_real_}
  event <- as.numeric(sample(0:1,n,replace=TRUE));time <- as.numeric(sample(1:20,n,replace=TRUE))
  d <- data.frame(.SURV=Surv(time,event),a=a,b=b,c=c,o=ordered(sample(0:2,n,replace=TRUE)))
  weights <- if (case%%5L==0L) runif(n,.1,2) else rep(1,n)
  strata <- factor(if (case%%3L==0L) rep(1:3,length.out=n) else rep(1,n))
  obj <- mRMRe::mRMR.data(data=d,weights=weights,strata=strata)
  result$cases[[case]] <- mRMRe::mim(obj,continuous_estimator="spearman",outX=case%%2L==0L)
}
saveRDS(result,file.path(root,paste0("mrmre-",mode,".rds")))
cat(mode,elapsed,"seconds; real full ranking + 160 tied/missing/stratified/weighted cases\n")
