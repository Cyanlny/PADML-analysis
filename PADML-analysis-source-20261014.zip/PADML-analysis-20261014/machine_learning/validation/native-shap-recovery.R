#!/usr/bin/env Rscript
# Numerical/RNG counterexample; synthetic covariates, no clinical completion claim.
suppressPackageStartupMessages({library(kernelshap);library(jsonlite);library(digest)})
candidate <- Sys.getenv('PADML_CANDIDATE_ROOT', '/opt/padml/candidate')
source(file.path(candidate,'padml/kernels/f5_shap.R'))
root <- Sys.getenv('PADML_SHAP_TEST_ROOT', '/root/autodl-tmp/padml/validation/integrated-mice/shap-longtail')
dir.create(root,showWarnings=FALSE)
need <- function(x,code) if (!isTRUE(x)) stop(code,call.=FALSE)
set.seed(714001L);p <- 17L
background <- as.data.frame(matrix(rnorm(24L*p),24L,p));names(background) <- paste0('v',1:p)
patients <- background[1:3,,drop=FALSE];ids <- c('TEST1','TEST2','TEST3')
w <- seq(.7,3.9,length.out=p)
pred <- function(object,z) {
  score <- 3*sin(as.numeric(as.matrix(z)%*%w)*2)
  out <- exp(-outer(exp(score),c(.1,.2,.4,.7)))
  colnames(out) <- paste0('t',c(6,12,24,36));out
}
reference <- vector('list',3L);before <- after <- vector('list',3L)
set.seed(780000001L);state <- .Random.seed
for (i in 1:3) {
  before[[i]] <- state;.Random.seed <- state
  original <- kernelshap(NULL,X=patients[i,,drop=FALSE],bg_X=background,pred_fun=pred,
    exact=FALSE,hybrid_degree=1L,max_iter=500L,tol=.005,verbose=FALSE)
  after[[i]] <- .Random.seed;state <- .Random.seed
  if (!original$converged) {
    .Random.seed <- before[[i]]
    original <- kernelshap(NULL,X=patients[i,,drop=FALSE],bg_X=background,pred_fun=pred,
      exact=FALSE,hybrid_degree=1L,max_iter=2000L,tol=.005,verbose=FALSE)
  }
  reference[[i]] <- original
}
runner <- padml_kernelshap_runner(background,pred,names(background),FALSE,1L,need)
calls <- 0L
interrupt <- function(z, ...) {
  calls <<- calls+1L
  if (identical(rownames(z),rownames(patients)[[2L]])) stop('EXPECTED_INTERRUPTION')
  runner(z, ...)
}
binding <- charToRaw('synthetic-longtail-original-500-state-v1')
expected <- pred(NULL,patients)
args <- list(data=patients,ids=ids,selected=names(background),seed=780000001L,
  exact=FALSE,degree=1L,need=need,root=root,spec=binding,recovery=NULL,pilot=NULL,
  family='COX_PH',imputation=1L,model_sha256=paste(rep('a',64),collapse=''),expected=expected)
if (!file.exists(file.path(root,'patients/P00001.rds'))) {
  error <- tryCatch(do.call(padml_shap_patients,c(list(run=interrupt),args)),error=identity)
  stopifnot(inherits(error,'error'),conditionMessage(error)=='EXPECTED_INTERRUPTION')
}
calls <- 0L
resume <- function(z, ...) {calls <<- calls+1L;runner(z, ...)}
value <- do.call(padml_shap_patients,c(list(run=resume),args))
stopifnot(identical(.Random.seed,after[[3L]]))
deltas <- list()
for (i in 1:3) {
  record <- readRDS(file.path(root,'patients',sprintf('P%05d.rds',i)))
  stopifnot(identical(record$rng_before,before[[i]]),identical(record$rng_after_original,after[[i]]),
    identical(record$result$n_iter,reference[[i]]$n_iter),
    identical(record$result$converged,reference[[i]]$converged))
  for (field in c('S','SE','baseline','predictions')) {
    a <- unlist(record$result[[field]],use.names=FALSE);b <- unlist(reference[[i]][[field]],use.names=FALSE)
    stopifnot(length(a)==length(b),all(abs(a-b)<=1e-12+1e-10*pmax(abs(a),abs(b))))
    deltas[[paste(i,field)]] <- max(abs(a-b))
  }
}
report <- list(status='PASS',scope='SYNTHETIC_RNG_AND_SOLVER_ONLY',resumed_predictions=calls,
  n_iter=vapply(reference,function(x)x$n_iter,integer(1)),
  converged=vapply(reference,function(x)x$converged,logical(1)),
  longtail_exercised=any(vapply(reference,function(x)x$n_iter>500L,logical(1))),
  original_budget_rng_exact=TRUE,convergence_exact=TRUE,max_abs_delta=max(unlist(deltas)))
write_json(report,file.path(dirname(root),'shap-longtail-comparison.json'),auto_unbox=TRUE,pretty=TRUE)
cat(toJSON(report,auto_unbox=TRUE),'\n')

# Recovery-only extension: reuse this script's already validated synthetic
# checkpoint bytes. No additional model fit, prediction or SHAP solve is allowed.
local({
  chain_root <- tempfile('shap-two-generation-', tmpdir=dirname(root))
  dir.create(chain_root)
  on.exit(unlink(chain_root, recursive=TRUE), add=TRUE)
  fixture_kernel_sha <- digest(file.path(candidate,'padml/kernels/f5_shap.R'),
    algo='sha256', file=TRUE, serialize=FALSE)
  generation <- function(name, indices, upstream=NULL, original_solver=FALSE) {
    here <- file.path(chain_root, name); dir.create(here); dir.create(file.path(here, 'patients'))
    spec <- charToRaw(paste0('SYNTHETIC_RECOVERY_ONLY_', name))
    spec_path <- file.path(here, 'spec.json'); writeBin(spec, spec_path)
    spec_sha <- digest(spec, algo='sha256', serialize=FALSE)
    pins <- lapply(indices, function(i) {
      record <- readRDS(file.path(root, 'patients', sprintf('P%05d.rds', i)))
      stopifnot(identical(record$producer$max_iter, 2000L))
      # These are isolated provenance fixtures over the validated synthetic
      # numbers/RNG; the original checkpoint itself is never modified.
      record$spec_sha256 <- spec_sha
      record$producer$source_sha256 <- spec_sha
      path <- file.path(here, 'patients', sprintf('P%05d.rds', i)); saveRDS(record, path)
      list(patient_index=as.integer(i), path=path, size_bytes=file.info(path)$size,
        sha256=digest(path, algo='sha256', file=TRUE, serialize=FALSE))
    })
    list(kind='PATIENT_CHECKPOINTS', spec_path=spec_path, spec_sha256=spec_sha,
      source_member_sha256=setNames(list(fixture_kernel_sha), 'padml/kernels/f5_shap.R'),
      patients=pins, upstream=upstream, original_solver=original_solver)
  }
  ancestor <- generation('A', c(1L, 3L))
  latest <- generation('B', 2L, upstream=ancestor)
  current_root <- file.path(chain_root, 'C'); dir.create(current_root)
  recovery_args <- args
  recovery_args$root <- current_root
  recovery_args$spec <- charToRaw('SYNTHETIC_RECOVERY_ONLY_C')
  recovery_args$recovery <- latest
  no_compute <- function(...) stop('UNEXPECTED_NATIVE_EXECUTION', call.=FALSE)
  first <- readRDS(ancestor$patients[[1L]]$path)
  stopifnot(!isTRUE(first$result$converged[[1L]]) || isTRUE(first$first_patient_replay_exact))
  restored <- do.call(padml_shap_patients, c(list(run=no_compute), recovery_args))
  stopifnot(identical(.Random.seed, after[[3L]]), identical(restored$result, value$result),
    length(list.files(file.path(current_root, 'patients'))) == 0L)
  expected_source <- c(ancestor$spec_sha256, latest$spec_sha256, ancestor$spec_sha256)
  for (i in 1:3) {
    row <- restored$patient_execution$rows[[i]]
    stopifnot(identical(row$producer$source_sha256, expected_source[[i]]),
      identical(row$rng_before_sha256, digest(before[[i]], algo='sha256')),
      identical(row$rng_after_original_sha256, digest(after[[i]], algo='sha256')))
  }
  for (pin in c(ancestor$patients, latest$patients))
    stopifnot(identical(digest(pin$path, algo='sha256', file=TRUE, serialize=FALSE), pin$sha256))
  # A freshly pinned RDS still must not bypass its original patient RNG guard.
  wrong <- latest
  path <- wrong$patients[[1L]]$path; saved <- readRDS(path)
  altered <- saved; altered$rng_before[[2L]] <- bitwXor(altered$rng_before[[2L]], 1L)
  saveRDS(altered, path)
  wrong$patients[[1L]]$sha256 <- digest(path, algo='sha256', file=TRUE, serialize=FALSE)
  wrong$patients[[1L]]$size_bytes <- file.info(path)$size
  recovery_args$recovery <- wrong
  failure <- tryCatch(do.call(padml_shap_patients, c(list(run=no_compute), recovery_args)), error=identity)
  stopifnot(inherits(failure, 'error'), conditionMessage(failure)=='F5_SHAP_PATIENT_BINDING_INVALID')
  saveRDS(saved, path)
  cat(toJSON(list(status='PASS', scope='SYNTHETIC_EXISTING_CHECKPOINT_RECOVERY_ONLY',
    generations=2L, additional_model_fits=0L, additional_shap_solves=0L,
    patient_source_exact=TRUE, original_budget_rng_exact=TRUE,
    rng_drift_rejected=TRUE), auto_unbox=TRUE), '\n')
})


# Boundary-only engineering regression: no model/prediction/SHAP solver is run.
local({
  fixture_root <- tempfile('rng-boundary-', tmpdir=tempdir()); dir.create(fixture_root)
  on.exit(unlink(fixture_root, recursive=TRUE), add=TRUE)
  selected <- paste0('v', seq_len(12L)); ids <- c('UNFITTED1', 'UNFITTED2')
  expected <- matrix(.5, 2L, 4L, dimnames=list(NULL, paste0('t', c(6L,12L,24L,36L))))
  result <- function(i) structure(list(
    S=setNames(rep(list(matrix(0, 1L, 12L)), 4L), colnames(expected)),
    baseline=rep(.5, 4L), predictions=expected[i,,drop=FALSE], algorithm='kernelshap',
    SE=setNames(rep(list(matrix(0, 1L, 12L)), 4L), colnames(expected)),
    n_iter=2L, converged=TRUE), class='kernelshap')
  sample_step <- getFromNamespace('input_sampling', 'kernelshap')
  before <- after <- vector('list', 2L)
  set.seed(780000001L)
  for (i in 1:2) {
    before[[i]] <- .Random.seed
    for (j in 1:2) sample_step(p=12L, m=24L, deg=1L, feature_names=selected)
    after[[i]] <- .Random.seed
  }
  generation <- function(i, upstream=NULL) {
    here <- file.path(fixture_root, LETTERS[i]); dir.create(here)
    spec <- charToRaw(paste0('UNFITTED_RETAINED_SPEC_', i))
    spec_path <- file.path(here, 'spec.json'); writeBin(spec, spec_path)
    spec_sha <- digest(spec, algo='sha256', serialize=FALSE)
    record <- list(spec_sha256=spec_sha, patient_index=as.integer(i), patient_id=ids[i],
      rng_before=before[[i]], rng_after_original=after[[i]], original_stream_n_iter=2L,
      rng_kind=RNGkind(), r_version=as.character(getRversion()), first_patient_replay_exact=TRUE,
      producer=list(max_iter=2000L, source_sha256=spec_sha), result=result(i))
    path <- file.path(here, sprintf('P%05d.rds', i)); saveRDS(record, path)
    list(kind='PATIENT_CHECKPOINTS', spec_path=spec_path, spec_sha256=spec_sha, upstream=upstream,
      patients=list(list(patient_index=as.integer(i), path=path, size_bytes=file.info(path)$size,
        sha256=digest(path, algo='sha256', file=TRUE, serialize=FALSE))))
  }
  ancestor <- generation(1L); latest <- generation(2L, ancestor)
  saved <- lapply(c(ancestor$patients, latest$patients), function(x) readRDS(x$path))
  repin <- function(source) {
    for (i in seq_along(source$patients)) {
      path <- source$patients[[i]]$path
      source$patients[[i]]$size_bytes <- file.info(path)$size
      source$patients[[i]]$sha256 <- digest(path, algo='sha256', file=TRUE, serialize=FALSE)
    }
    if (!is.null(source$upstream)) source$upstream <- repin(source$upstream)
    source
  }
  # Only count the production function's sampling calls; never change a namespace.
  samples <- solves <- 0L
  observed <- padml_shap_patients
  observer_env <- new.env(parent=environment(observed))
  observer_env$getFromNamespace <- function(x, ns) {
    original <- utils::getFromNamespace(x, ns)
    if (!identical(x, 'input_sampling') || !identical(ns, 'kernelshap')) return(original)
    function(...) { samples <<- samples + 1L; original(...) }
  }
  environment(observed) <- observer_env
  args <- list(run=function(...) { solves <<- solves + 1L; stop('UNEXPECTED_SHAP_SOLVE', call.=FALSE) },
    data=as.data.frame(matrix(1, 2L, 12L)), ids=ids, selected=selected, seed=780000001L,
    exact=FALSE, degree=1L, need=need, root=NULL, spec=charToRaw('UNFITTED_CURRENT'), recovery=latest,
    pilot=NULL, family='COX_PH', imputation=1L, model_sha256=paste(rep('a',64L),collapse=''), expected=expected)
  failure <- function(source, code) {
    samples <<- solves <<- 0L
    args$recovery <- source
    value <- tryCatch(do.call(observed, args), error=identity)
    stopifnot(inherits(value,'error'), identical(conditionMessage(value),code), solves == 0L)
  }
  baseline <- do.call(observed, args)
  stopifnot(identical(.Random.seed, after[[2L]]), samples == 2L, solves == 0L)
  # First admission of old terminal RDS: altered after-state plus a fresh outer
  # file pin still must fail the state transition. No numeric values are changed.
  altered <- saved[[2L]]; altered$rng_after_original[[3L]] <- bitwXor(altered$rng_after_original[[3L]],1L)
  saveRDS(altered, latest$patients[[1L]]$path)
  failure(repin(latest), 'F5_SHAP_ORIGINAL_RNG_INVALID'); stopifnot(samples == 2L)
  saveRDS(saved[[2L]], latest$patients[[1L]]$path)
  # An old retained prefix must fail before the next missing patient's run.
  altered <- saved[[1L]]; altered$rng_after_original[[3L]] <- bitwXor(altered$rng_after_original[[3L]],1L)
  saveRDS(altered, ancestor$patients[[1L]]$path)
  failure(repin(ancestor), 'F5_SHAP_ORIGINAL_RNG_INVALID'); stopifnot(samples == 2L)
  # Within a retained segment the next record's original before-state is the
  # anchor: reject without sampling, predicting or solving either patient.
  failure(repin(latest), 'F5_SHAP_PATIENT_BINDING_INVALID'); stopifnot(samples == 0L)
  saveRDS(saved[[1L]], ancestor$patients[[1L]]$path)
  # New write-time checksum records recover with exactly zero sampling calls.
  for (i in 1:2) {
    record <- saved[[i]]; record$rng_after_original_sha256 <- digest(record$rng_after_original,algo='sha256')
    saveRDS(record, c(ancestor$patients,latest$patients)[[i]]$path)
  }
  checked <- repin(latest)
  args$recovery <- checked; samples <- solves <- 0L
  restored <- do.call(observed,args)
  stopifnot(identical(restored$result,baseline$result), identical(.Random.seed,after[[2L]]),
    samples == 0L, solves == 0L)
  for (pin in c(checked$patients,checked$upstream$patients))
    stopifnot(identical(digest(pin$path,algo='sha256',file=TRUE,serialize=FALSE),pin$sha256))
  altered <- readRDS(latest$patients[[1L]]$path)
  altered$rng_after_original[[3L]] <- bitwXor(altered$rng_after_original[[3L]],1L)
  saveRDS(altered,latest$patients[[1L]]$path)
  failure(repin(latest),'F5_SHAP_ORIGINAL_RNG_INVALID'); stopifnot(samples == 0L)
  cat(toJSON(list(status='PASS',scope='SYNTHETIC_RETAINED_RNG_BOUNDARY_ONLY',
    old_terminal_drift_rejected=TRUE,old_prefix_drift_rejected_before_next_run=TRUE,
    old_interior_drift_rejected_without_sampling=TRUE,new_checksum_resume_samples=0L,
    new_checksum_drift_rejected_without_sampling=TRUE,additional_model_fits=0L,additional_shap_solves=0L),
    auto_unbox=TRUE),'\n')
})


# First-patient sentinel routing only. Return retained synthetic values; never fit
# a model, predict a population or run kernelshap_one.
local({
  here <- tempfile('shap-solver-routing-',tmpdir=tempdir());dir.create(here)
  on.exit(unlink(here,recursive=TRUE),add=TRUE)
  current <- digest(file.path(candidate,'padml/kernels/f5_shap.R'),algo='sha256',file=TRUE,serialize=FALSE)
  same <- '5164d47ba5a663734086ab034e51f41a5c3f3939a8467e01875d601a9f1e64dc'
  old <- 'f696acc0b81c3c95586de35f774ece0ac1a0863fbab24574e9c31c4b7f0806a2'
  selected <- paste0('v',1:12);ids <- 'UNFITTED_SENTINEL'
  expected <- matrix(.5,1L,4L,dimnames=list(NULL,paste0('t',c(6L,12L,24L,36L))))
  value <- structure(list(S=setNames(rep(list(matrix(0,1L,12L)),4L),colnames(expected)),
    baseline=rep(.5,4L),predictions=expected,algorithm='kernelshap',
    SE=setNames(rep(list(matrix(0,1L,12L)),4L),colnames(expected)),n_iter=2L,converged=TRUE),class='kernelshap')
  set.seed(780000001L);before <- .Random.seed
  for(j in 1:2) getFromNamespace('input_sampling','kernelshap')(p=12L,m=24L,deg=1L,feature_names=selected)
  after <- .Random.seed
  check <- function(label,kernel,cap,original,verified=FALSE) {
    root <- file.path(here,label);dir.create(root)
    write_json(list(source_member_sha256=setNames(list(current),'padml/kernels/f5_shap.R')),
      file.path(root,'binding.json'),auto_unbox=TRUE)
    spec <- charToRaw(paste0('UNFITTED_SOLVER_',label));spec_path <- file.path(root,'donor-spec.json')
    writeBin(spec,spec_path);spec_sha <- digest(spec,algo='sha256',serialize=FALSE)
    upstream <- NULL;producer_sha <- spec_sha
    if(cap==500L) {
      old_spec <- file.path(root,'raw-spec.json');writeBin(charToRaw('UNFITTED_RAW500'),old_spec)
      raw <- file.path(root,'raw.rds');writeBin(charToRaw('UNFITTED_RAW500_PIN_ONLY'),raw)
      producer_sha <- digest(raw,algo='sha256',file=TRUE,serialize=FALSE)
      upstream <- list(spec_path=old_spec,spec_sha256=digest(old_spec,algo='sha256',file=TRUE,serialize=FALSE),
        raw_path=raw,raw_sha256=producer_sha)
    }
    record <- list(spec_sha256=spec_sha,patient_index=1L,patient_id=ids,
      rng_before=before,rng_after_original=after,rng_after_original_sha256=digest(after,algo='sha256'),
      original_stream_n_iter=2L,rng_kind=RNGkind(),r_version=as.character(getRversion()),
      producer=list(max_iter=cap,source_sha256=producer_sha),result=value)
    if(verified) record$first_patient_replay_exact <- TRUE
    path <- file.path(root,'P00001.rds');saveRDS(record,path)
    pin <- digest(path,algo='sha256',file=TRUE,serialize=FALSE)
    donor <- list(kind='PATIENT_CHECKPOINTS',spec_path=spec_path,spec_sha256=spec_sha,
      source_member_sha256=setNames(list(kernel),'padml/kernels/f5_shap.R'),
      # Historical consumer flags are not authoritative over the exact kernel.
      original_solver=identical(kernel,same),upstream=upstream,
      patients=list(list(patient_index=1L,path=path,size_bytes=file.info(path)$size,sha256=pin)))
    calls <- list()
    run <- function(row,...) {calls[[length(calls)+1L]] <<- list(...);value}
    answer <- padml_shap_patients(run,as.data.frame(matrix(1,1L,12L)),ids,selected,780000001L,
      FALSE,1L,need,root,charToRaw('UNFITTED_CURRENT'),donor,NULL,'COX_PH',1L,
      paste(rep('a',64L),collapse=''),expected)
    stopifnot(length(calls)==if(verified)0L else 1L,identical(.Random.seed,after),
      identical(digest(path,algo='sha256',file=TRUE,serialize=FALSE),pin))
    if(!verified) stopifnot(identical(calls[[1L]],if(original)
      list(original_budget=TRUE,original_max_iter=cap) else list()))
    list(case=label,sentinel_calls=length(calls),original_budget=original,max_iter=cap)
  }
  rows <- list(check('same5164',same,2000L,FALSE),check('current',current,2000L,FALSE),
    check('oldf696',old,2000L,TRUE),check('inherited_raw500',same,500L,TRUE),
    check('already_verified',same,2000L,FALSE,TRUE))
  cat(toJSON(list(status='PASS',scope='SYNTHETIC_FIRST_PATIENT_REPLAY_ROUTING_ONLY',cases=rows,
    model_fits=0L,shap_solves=0L,original_patient_files_unchanged=TRUE),auto_unbox=TRUE),'\n')
})
