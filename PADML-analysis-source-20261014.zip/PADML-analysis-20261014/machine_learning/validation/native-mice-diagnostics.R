# Read existing real M20 trajectories; this check never runs another chain.
suppressPackageStartupMessages({library(mice);library(jsonlite);library(rstan);library(dplyr)})
root <- "/root/autodl-tmp/padml/validation/integrated-mice"
for (expr in parse("/opt/padml/candidate/padml/kernels/f1_nested_mice.R")) {
  if (is.call(expr) && identical(expr[[1L]],as.name("<-")) && is.call(expr[[3L]]) &&
      identical(expr[[3L]][[1L]],as.name("function"))) eval(expr)
}
paths <- list(`30`=file.path(root,"application/native"),
              `40`=file.path(root,"recovery-check/checkpoint40"),
              `50`=file.path(root,"recovery-check/baseline/native"))
reports <- lapply(names(paths),function(checkpoint) {
  fits <- lapply(file.path(paths[[checkpoint]],sprintf("imp%02d.rds",1:20)),readRDS)
  stopifnot(all(vapply(fits,function(x)as.integer(x$iteration),integer(1))==as.integer(checkpoint)))
  active <- names(fits[[1L]]$method)[fits[[1L]]$method!=""]
  set.seed(314159);initial_rng <- .Random.seed
  combined <- Reduce(mice::ibind,fits)
  reference <- do.call(rbind,lapply(c("mean","sd"),function(parameter) {
    value <- mice::convergence(combined,parameter=parameter)
    value$vrb <- as.character(value$vrb);value$parameter <- parameter;value
  }))
  reference <- active_terminal_convergence(reference,active,as.integer(checkpoint),5L)
  candidate <- chain_convergence(fits,active,as.integer(checkpoint),5L)
  align <- function(x) {
    x <- x[order(x$parameter,x$vrb,x$.it),c(".it","vrb","parameter","psrf","ac")]
    rownames(x) <- NULL;x
  }
  stopifnot(identical(align(reference),align(candidate)),identical(.Random.seed,initial_rng))
  list(iteration=as.integer(checkpoint),chains=20L,active=length(active),
       diagnostic_rows=nrow(candidate),checked_window_iterations=5L,
       production_terminal_window_iterations=3L,production_terminal_rows=length(active)*2L*3L,
       psrf_ac_bitwise=TRUE,rng_unchanged=TRUE)
})
result <- list(status="PASS",scope="REAL_APPLICATION_M20_DIAGNOSTICS_NO_REFIT",
    reference="mice 3.19.0 convergence of ibind M20",checkpoints=reports)
write_json(result,file.path(root,"mice-diagnostics-comparison.json"),auto_unbox=TRUE,pretty=TRUE)
cat(toJSON(result,auto_unbox=TRUE),"\n")
