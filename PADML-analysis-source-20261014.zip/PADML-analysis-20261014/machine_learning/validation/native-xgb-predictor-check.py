#!/usr/bin/env python3
"""Real retained XGBoost M01 Python/R predictor interface check.

Run after main-process review on H01 through the qualified padml-env Python:
  python -B validation/native-xgb-predictor-check.py --package /opt/padml/candidate

Read xgb-real/{model.bin,baseline.bin,numbers.json} and the existing real M01.
Never train, run STOP, reconstruct a winner/lineage, or run the SHAP solver.
Use numbers.json's unchanged task/recipe and compare exactly with its original
training predictions: 2124 rows, 12 original rows batch/single, and 2124+12 tail.
Reuse only input/environment/publication helpers from the validated CoxTime
check; the R driver has no Torch-specific import, BLAS, or loader assertions.
"""
from __future__ import annotations

import argparse
import fcntl
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

SCOPE = "REAL_M01_XGBOOST_RETAINED_PREDICTOR_VALIDATION"
R_DRIVER = r'''
suppressPackageStartupMessages({library(jsonlite); library(reticulate)})
args <- commandArgs(TRUE); stopifnot(length(args) == 1L)
spec_path <- normalizePath(args[[1L]],mustWork=TRUE)
spec <- fromJSON(spec_path,simplifyVector=FALSE)
scalar <- function(x) unname(unlist(x,use.names=FALSE)[[1L]])
need <- function(ok,why) if(!isTRUE(ok)) stop(why,call.=FALSE)
selected <- as.character(unlist(spec$selected_parents,use.names=FALSE))
raw <- read.csv(scalar(spec$covariate_path),check.names=FALSE,
                stringsAsFactors=FALSE,colClasses="character")
source(scalar(spec$design_script),local=TRUE)
prepared <- padml_prepare_final_r_design(raw,selected,spec$recipe$predictor_rows,
  spec$recipe$transform_recipe,scalar(spec$family),scalar,need)
parents <- prepared$covariates[,selected,drop=FALSE]
idx <- as.integer(unlist(spec$check_indices_one_based,use.names=FALSE))
need(nrow(parents)==2124L && length(unique(idx))==12L,"R_PATIENT_SCOPE_INVALID")
use_python(as.character(scalar(spec$python_executable)),required=TRUE)
module <- import("padml.f5",convert=FALSE)
predictor <- module$`_FinalShapPythonPredictor`(spec_path)
predict <- function(x) {
  ans <- as.matrix(py_to_r(predictor$predict_survival(r_to_py(x))))
  need(identical(dim(ans),c(nrow(x),4L)) && all(is.finite(ans)) &&
       all(ans>=0 & ans<=1),"R_SURVIVAL_INVALID")
  ans
}
values <- list(full=predict(parents),batch12=predict(parents[idx,,drop=FALSE]),
  single12=do.call(rbind,lapply(idx,function(i) predict(parents[i,,drop=FALSE]))),
  tail=predict(rbind(parents,parents[idx,,drop=FALSE])))
for(name in names(values)) {
  con <- file(file.path(dirname(spec_path),paste0(name,".f64")),"wb")
  tryCatch(writeBin(as.double(t(values[[name]])),con,size=8L,endian="little"),finally=close(con))
}
result <- list(status="PREDICTED",python=py_config()$python,
  reticulate=as.character(packageVersion("reticulate")),
  xgboost=py_eval("__import__('xgboost').__version__"),
  factory="padml.f5._FinalShapPythonPredictor",rows=2124L,check_rows=12L,
  horizons=c(6L,12L,24L,36L),new_fits=0L,new_stop_tasks=0L)
writeLines(toJSON(result,auto_unbox=TRUE,digits=NA),file.path(dirname(spec_path),"r-result.json"),useBytes=TRUE)
'''


def main():
    parser=argparse.ArgumentParser(description=__doc__,formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--package",type=Path,default=Path("/opt/padml/candidate"))
    parser.add_argument("--validation-root",type=Path,default=Path("/root/autodl-tmp/padml/validation/integrated-mice"))
    parser.add_argument("--output",type=Path)
    parser.add_argument("--rscript",default=os.environ.get("PADML_RSCRIPT"))
    args=parser.parse_args()
    package,base=args.package.resolve(strict=True),args.validation_root.resolve(strict=True)
    helper=package/"validation/native-coxtime-fixed-kernel-check.py"
    module_spec=importlib.util.spec_from_file_location("retained_validation_helpers",helper)
    h=importlib.util.module_from_spec(module_spec);module_spec.loader.exec_module(h)
    output=(args.output or base/"xgb-predictor-interface").absolute()
    h.need(output.parent.is_dir() and output.parent.resolve(strict=True)==output.parent
           and not output.is_symlink() and not output.is_relative_to(package),"OUTPUT_INVALID")
    output.mkdir(mode=0o700,exist_ok=True)
    h.configure(package,output,args.rscript)
    from padml import f4,f5,runtime
    from padml._science_authority import load_science_authority
    import numpy as np
    import pandas as pd
    descriptor=os.open(output,os.O_RDONLY)
    try:
        fcntl.flock(descriptor,fcntl.LOCK_EX|fcntl.LOCK_NB)
        rows,responses,positions,covariates,response_path,input_pins=h.checked_inputs(base,load_science_authority()["science"])
        source=base/"xgb-real"
        paths={name:source/name for name in ("model.bin","baseline.bin","numbers.json")}
        pins={name:h.pin(path) for name,path in paths.items()}
        numbers=h.document(paths["numbers.json"])
        task,recipe=numbers["task"],numbers["recipe"]
        h.need(task["family"]=="XGBOOST_COX" and task["imputation"]==1
               and pins["model.bin"]["sha256"]==numbers["model_sha256"]
               and pins["baseline.bin"]["sha256"]==numbers["baseline_sha256"],"ORIGINAL_XGB_OBJECT_BINDING_DRIFT")
        f5._validate_final_design_recipe(recipe,family="XGBOOST_COX",selected_parents=task["selected_parents"])
        original=np.asarray(numbers["result"]["survival"],dtype="float64")
        f5._seal_prediction_matrix([row["Patient_ID"] for row in rows],original.tolist(),f5.HORIZONS)
        h.need(original.shape==(2124,len(f5.HORIZONS)),"ORIGINAL_TRAINING_PREDICTION_SCOPE_INVALID")
        columns=[f5.HORIZONS.index(month) for month in f5.REPORT_HORIZONS]
        four=original[:,columns]
        expected={"full":four,"batch12":four[positions],"single12":four[positions],
                  "tail":np.concatenate([four,four[positions]],axis=0)}
        binding={"scope":SCOPE,"original_objects":pins,"inputs":input_pins,
            "task":task,"recipe":recipe,"check_patient_ids":[rows[i]["Patient_ID"] for i in positions],
            "source_members":f4._f45_source_member_sha256(),"helper":h.pin(helper),
            "script":h.pin(Path(__file__).resolve()),"python":sys.executable,
            "rscript":runtime.RSCRIPT_EXECUTABLE,"r_library":runtime.R_LIBRARY,
            "comparison":"EXACT_NO_TOLERANCE_CHANGE","new_fits":0,"new_stop_tasks":0}
        h.exact_document(output/"binding.json",binding)
        bridge=output/"bridge-work";bridge.mkdir(mode=0o700,exist_ok=True)
        spec={"family":"XGBOOST_COX","task":task,"recipe":recipe,"selected_parents":task["selected_parents"],
            "covariate_path":str(covariates),"response_path":str(response_path),
            "model_path":str(paths["model.bin"]),"baseline_path":str(paths["baseline.bin"]),
            "model_sha256":numbers["model_sha256"],"python_executable":sys.executable,
            "design_script":str(package/"padml/kernels/f5_design.R"),"check_indices_one_based":[i+1 for i in positions]}
        h.exact_document(bridge/"spec.json",spec)
        predictor=f5._FinalShapPythonPredictor(str(bridge/"spec.json"))
        frame=pd.DataFrame(rows).loc[:,task["selected_parents"]]
        values={"full":predictor.predict_survival(frame),"batch12":predictor.predict_survival(frame.iloc[positions]),
            "single12":np.vstack([predictor.predict_survival(frame.iloc[[i]]) for i in positions]),
            "tail":predictor.predict_survival(pd.concat([frame,frame.iloc[positions]],ignore_index=True))}
        checks={"python_"+name:h.equal_matrix(values[name],matrix,"PYTHON_"+name) for name,matrix in expected.items()}
        del predictor,values
        driver=bridge/"bridge.R"
        if driver.exists():h.need(driver.read_text()==R_DRIVER,"R_DRIVER_DRIFT")
        else:h.publish(driver,R_DRIVER.encode())
        env={**os.environ,**runtime.THREAD_ENV}
        env["R_LIBS_USER"]=os.pathsep.join(filter(None,(getattr(f5,"_SHAP_R_LIBRARY",""),runtime.R_LIBRARY)))
        with (bridge/"stdout.log").open("wb") as stdout,(bridge/"stderr.log").open("wb") as stderr:
            result=subprocess.run([runtime.RSCRIPT_EXECUTABLE,"--vanilla",str(driver),str(bridge/"spec.json")],
                cwd=package,env=env,stdout=stdout,stderr=stderr,timeout=3600,check=False)
        h.need(result.returncode==0 and (bridge/"r-result.json").is_file(),"R_RETICULATE_FAILED:"+str(bridge))
        metadata=h.document(bridge/"r-result.json")
        h.need(Path(metadata["python"]).resolve()==Path(sys.executable).resolve(),"RETICULATE_PYTHON_DRIFT")
        for name,matrix in expected.items():
            path=bridge/(name+".f64")
            h.need(path.stat().st_size==matrix.size*8,"R_OUTPUT_SIZE_INVALID:"+name)
            checks["R_"+name]=h.equal_matrix(np.fromfile(path,dtype="<f8").reshape(matrix.shape),matrix,"R_"+name)
        # Inputs and retained objects stay in place; no model/source copies.
        h.need(all(h.pin(path)==pins[name] for name,path in paths.items()),"ORIGINAL_OBJECT_CHANGED_DURING_CHECK")
        report={"scope":SCOPE,"status":"PASS_RETAINED_INTERFACE_ONLY","binding_sha256":h.sha(binding),
            "checks":checks,"R_bridge":metadata,"new_fits":0,"new_stop_tasks":0,"full_shap_performed":False,
            "interpretation":"Exact real retained-M01 predictor interface check; not formal model selection or M20 acceptance"}
        h.exact_document(output/"result.json",report)
        shutil.rmtree(bridge)
        print(json.dumps({"scope":SCOPE,"status":report["status"],"result":str(output/"result.json")}),flush=True)
    finally:
        os.close(descriptor)


if __name__=="__main__":
    main()
