#!/usr/bin/env python3
"""REAL_M20_IMPUTED_COX_KERNEL_VALIDATION.

Run on H01 through its already qualified padml-env Python, after main-agent review:
  python validation/native-m20-fixed-kernel-check.py --package /opt/padml/candidate

This is a fixed AST_ALT + Age + RBC / COX_PH native-kernel check using the existing
2124-person FULL0 ANALYSIS M20. It does not select a model, invent a development
lock/lineage, rerun MICE, or establish clinical/full-pipeline completion.
SHAP retains all patients/backgrounds, M20, four outputs, tol=.005, max_iter=2000
and ORIGINAL_500_PATIENT_START. With three parents the production method is exact;
this check does not establish approximate-SHAP long-tail convergence.

APPLICATION checks at most two existing completed rows per validation center.
It calls the same retained-object engine as predict_completed_application, with
independent batch/single predictions, without fabricating application lineage or
claiming that an appended-patient MICE transaction was tested. Selection uses
rows missing any current candidate in the original APPLICATION covariates.

One existing ordered pool owns the M20 jobs. A complete saved refit is never
trained again. Partial saved models require explicit recovery, not automatic
refitting. An incomplete SHAP resumes its original persistent patient state.

"""

from __future__ import annotations

import argparse
import csv
import fcntl
import hashlib
import json
import math
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile


SCOPE = "REAL_M20_IMPUTED_COX_KERNEL_VALIDATION"
SELECTED = ["AST_ALT", "Age", "RBC"]
N = 2124
GIB = 1024**3
RESPONSE_COLUMNS = {"All_Cause_Death", "Death_Followup_months"}


def need(condition, message):
    if not condition:
        raise RuntimeError(message)


def raw_json(value):
    from padml.bundle import canonical_json_bytes
    return canonical_json_bytes(value)


def digest(value):
    return hashlib.sha256(raw_json(value)).hexdigest()


def read_json(path):
    with Path(path).open(encoding="utf-8") as handle:
        return json.load(handle)


def atomic_bytes(path, data):
    path = Path(path)
    pending = path.with_name(path.name + ".pending")
    need(not path.exists() and not pending.exists(), "PUBLICATION_ALREADY_PRESENT:" + str(path))
    with pending.open("xb") as handle:
        handle.write(data)
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(pending, path)


def exact_json(path, value):
    if path.exists():
        need(path.read_bytes() == raw_json(value), "VALIDATION_BINDING_DRIFT:" + str(path))
    else:
        atomic_bytes(path, raw_json(value))


def pin(path):
    from padml.bundle import sha256_file
    path = Path(path)
    need(path.is_file() and not path.is_symlink(), "SOURCE_FILE_INVALID:" + str(path))
    return {"path": str(path), "sha256": sha256_file(path), "size_bytes": path.stat().st_size}


def csv_rows(path):
    with Path(path).open(encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        rows = list(reader)
    need(rows and len(rows) == len({r.get("Patient_ID") for r in rows}), "ROW_IDENTITY_INVALID")
    need({"Patient_ID", "Center", *SELECTED}.issubset(reader.fieldnames or []), "COVARIATE_COLUMNS_INVALID")
    need(not RESPONSE_COLUMNS.intersection(reader.fieldnames or []), "COVARIATE_RESPONSE_CHANNEL_PRESENT")
    return rows


def prepare_environment(package, output, rscript):
    need(sys.platform == "linux", "THIS_CHECK_IS_FOR_LINUX_ONLY")
    need(package.is_dir() and (package / "padml/f5.py").is_file(), "PACKAGE_PATH_INVALID")
    need(not any(os.environ.get(k) for k in ("PADML_F45_RUN_PATH", "PADML_INTEGRATED_RUN", "PADML_ARCHIVE_INDEX")),
         "USE_ISOLATED_VALIDATION_ENV_WITHOUT_FORMAL_RUN_CONTEXT")
    sys.path.insert(0, str(package))
    os.environ["PYTHONPATH"] = os.pathsep.join(filter(None, (str(package), os.environ.get("PYTHONPATH"))))
    os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
    os.environ["PADML_PYTHON"] = sys.executable
    if rscript:
        os.environ["PADML_RSCRIPT"] = rscript
    for name in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "VECLIB_MAXIMUM_THREADS", "NUMEXPR_NUM_THREADS"):
        os.environ[name] = "1"
    temporary = output / "tmp"
    temporary.mkdir(mode=0o700, parents=True, exist_ok=True)
    for name in ("TMPDIR", "TMP", "TEMP"):
        os.environ[name] = str(temporary)
    tempfile.tempdir = str(temporary)
    os.environ.setdefault("XDG_CACHE_HOME", str(output / "cache"))
    os.environ.setdefault("MPLCONFIGDIR", str(output / "cache/matplotlib"))


def view_input(folder, role):
    from padml.f1_kernel import mice_terminal_valid
    spec = read_json(folder / "spec.json")
    summary = read_json(folder / "output/summary.json")
    view = spec["view"]
    need(view["role"] == role and summary["role"] == role and summary["status"] == "PASS"
         and summary["formal_m"] == 20 and summary["active_target_count"] == 33
         and summary["row_count"] == N and mice_terminal_valid(summary), "EXISTING_MICE_SCOPE_INVALID:" + role)
    need(summary["application_response_columns"] == 0
         and summary["application_predictor_matrix_response_edges"] == 0, "APPLICATION_OUTCOME_CHANNEL")
    if role == "APPLICATION":
        need("response_path" not in spec and summary["analysis_auxiliary_predictor_edges"] == 0,
             "APPLICATION_SPEC_OUTCOME_CHANNEL")
    else:
        need(summary["analysis_auxiliary_predictor_edges"] > 0, "ANALYSIS_AUXILIARY_SCOPE_INVALID")
    members = [pin(folder / "output/imputations" / f"imp{i:02d}.csv") for i in range(1, 21)]
    first = csv_rows(Path(members[0]["path"]))
    ids = [r["Patient_ID"] for r in first]
    need(len(ids) == N and ids == view["row_ids"], "EXISTING_MICE_ROW_SCOPE_INVALID:" + role)
    need(summary["row_ids_sha256"] == digest(ids), "EXISTING_MICE_ROW_PIN_INVALID")
    if role == "ANALYSIS":
        need(view["analysis_ids"] == ids, "FULL0_ANALYSIS_TRAINING_SCOPE_INVALID")
    record = {"spec": pin(folder / "spec.json"), "summary": pin(folder / "output/summary.json"),
              "continuation": pin(folder / "output/configuration/ACTUAL_CONTINUATION_CONFIG.json"),
              "members": members, "row_ids_sha256": digest(ids)}
    return spec, first, record


def application_ids(spec, completed, candidates, centers):
    original_path = Path(spec["covariates_path"])
    original = {r["Patient_ID"]: r for r in csv_rows(original_path)}
    need(set(original) == {r["Patient_ID"] for r in completed}, "APPLICATION_ORIGINAL_COMPLETED_SCOPE_DRIFT")
    selected, counts = [], {}
    training_ids = set(spec["view"]["analysis_ids"])
    application_scope = set(spec["view"]["row_ids"]) - training_ids
    need(application_scope, "NO_PREPARED_APPLICATION_POPULATION")
    missing_tokens = {"", "NA", "NaN", "nan"}
    for center in centers:
        eligible = [r["Patient_ID"] for r in completed if r["Center"] == center
                    and r["Patient_ID"] in application_scope
                    and any(original[r["Patient_ID"]].get(v, "") in missing_tokens for v in candidates)]
        # Fixed source order; no synthetic values, extra patients, or outcome access.
        chosen = eligible[:2]
        selected.extend(chosen)
        counts[center] = len(chosen)
    need(selected and len(selected) <= 12, "NO_ELIGIBLE_PREPARED_APPLICATION_ROWS")
    return selected, counts, pin(original_path)


def fit_or_read(job, rows, response, recipe, folder):
    from padml import f5
    from padml.bundle import sha256_bytes
    files = [folder / name for name in ("model.bin", "baseline.bin", "refit.json")]
    present = [p.exists() for p in files]
    fit_binding = {"scope": SCOPE, "input_identity": job["input_identity"], "task": job["task"],
                   "recipe_sha256": digest(recipe)}
    if any(present):
        need(all(present), "PARTIAL_REFIT_REQUIRES_RECOVERY_NO_RETRAIN:" + str(folder))
        record = read_json(files[2])
        model, baseline = files[0].read_bytes(), files[1].read_bytes()
        need(record["binding"] == fit_binding and record["model_sha256"] == sha256_bytes(model)
             and record["baseline_sha256"] == sha256_bytes(baseline), "RETAINED_REFIT_DRIFT")
    else:
        need(not any(folder.glob("*.pending")), "PARTIAL_REFIT_PUBLICATION_REQUIRES_RECOVERY")
        fit = f5._execute_final_refit_engine("COX_PH", job["task"], rows, response, recipe)
        model, baseline = fit["model"], fit["baseline"]
        f5._seal_prediction_matrix([r["Patient_ID"] for r in rows], fit["survival"], f5.HORIZONS)
        record = {"binding": fit_binding, "model_sha256": sha256_bytes(model),
                  "baseline_sha256": sha256_bytes(baseline), "fit_health": fit["fit_health"],
                  "survival": fit["survival"]}
        atomic_bytes(files[0], model)
        atomic_bytes(files[1], baseline)
        atomic_bytes(files[2], raw_json(record))
    f5._seal_prediction_matrix([r["Patient_ID"] for r in rows], record["survival"], f5.HORIZONS)
    return model, baseline, record


def shap_or_read(job, recipe, record, folder, prediction):
    from padml import f5, runtime
    checkpoint = folder / "shap.zip"
    work = folder / "shap-work"
    component_binding = {"scope": SCOPE, "input_identity": job["input_identity"], "imputation": job["task"]["imputation"],
                         "model_sha256": record["model_sha256"], "baseline_sha256": record["baseline_sha256"],
                         "recipe_sha256": digest(recipe)}
    if checkpoint.exists():
        binding_raw, component = f5._read_shap_checkpoint(checkpoint)
        need(binding_raw == raw_json(component_binding), "SHAP_VALIDATION_BINDING_DRIFT")
        f5._validate_final_shap_component(component, task=job["task"], prediction=prediction,
                                          model_sha256=record["model_sha256"])
    else:
        work.mkdir(mode=0o700, exist_ok=True)
        native_output = work / "shap.json"
        spec = {"action": "FINAL_SHAP", "family": "COX_PH", "imputation": job["task"]["imputation"],
                "model_sha256": record["model_sha256"], "selected_parents": SELECTED,
                "seed": 780_000_000 + job["task"]["imputation"], "model_path": str(folder / "model.bin"),
                "baseline_path": str(folder / "baseline.bin"), "covariate_path": job["analysis_path"],
                "response_path": job["response_path"], "recipe": recipe, "task": job["task"],
                "horizons": list(f5.REPORT_HORIZONS), "output_path": str(native_output),
                "python_executable": sys.executable,
                "shap_contract": {"max_iter": 2000, "original_stream_max_iter": 500,
                                  "rng_policy": "ORIGINAL_500_PATIENT_START", "tol": 0.005},
                "recovery_source": None}
        exact_json(work / "spec.json", spec)
        if not native_output.exists():
            env = {**os.environ, **runtime.THREAD_ENV}
            env["R_LIBS_USER"] = os.pathsep.join(filter(None, (getattr(f5, "_SHAP_R_LIBRARY", ""), runtime.R_LIBRARY)))
            timeout = 24 * 60 * 60
            if runtime._ACTIVE_TASK_DEADLINE is not None:
                timeout = min(timeout, runtime._ACTIVE_TASK_DEADLINE - runtime.monotonic())
            need(timeout > 0, "BOUNDED_SPAWN_TASK_DEADLINE_EXCEEDED")
            with (work / "stdout.log").open("ab") as stdout, (work / "stderr.log").open("ab") as stderr:
                result = subprocess.run([runtime.RSCRIPT_EXECUTABLE, "--vanilla",
                    str(Path(job["package"]) / "padml/kernels/f5_shap.R"), str(work / "spec.json")],
                    cwd=Path(job["package"]) / "padml", env=env, stdout=stdout, stderr=stderr,
                    check=False, timeout=timeout)
            need(result.returncode == 0 and native_output.is_file(), "REAL_SHAP_NATIVE_FAILED:" + str(work))
        component = f5._read_native_shap_component(native_output)
        f5._validate_final_shap_component(component, task=job["task"], prediction=prediction,
                                          model_sha256=record["model_sha256"])
        need(component["engine"]["max_iter"] == 2000, "SHAP_BUDGET_DRIFT")
        temporary = checkpoint.with_name("shap.pending.zip")
        need(not temporary.exists(), "INCOMPLETE_SHAP_PUBLICATION_REQUIRES_RECOVERY")
        f5._write_shap_checkpoint(temporary, component_binding, component)
        # This is the original published-number consumer, not a second fit.
        binding_raw, published = f5._read_shap_checkpoint(temporary)
        need(binding_raw == raw_json(component_binding), "SHAP_PUBLICATION_BINDING_DRIFT")
        f5._validate_final_shap_component(published, task=job["task"], prediction=prediction,
                                          model_sha256=record["model_sha256"])
        os.replace(temporary, checkpoint)
        del component
        component = published
    need(component["engine"]["max_iter"] == 2000, "SHAP_BUDGET_DRIFT")
    reference_path = folder / "shap.reference.zip"
    comparison_path = folder / "shap-comparison.json"
    if reference_path.exists():
        import numpy as np
        _, reference = f5._read_shap_checkpoint(reference_path)
        need(reference["engine"] == component["engine"] and
             reference["background"] == component["background"], "SHAP_REFERENCE_SCOPE_DRIFT")
        differences = {}
        for field in ("base_risk", "predicted_risk", "risk_contributions", "standard_errors"):
            old = np.asarray(reference[field], dtype="float64")
            new = np.asarray(component[field], dtype="float64")
            need(old.shape == new.shape and bool(np.allclose(old, new, rtol=1e-10, atol=1e-12)),
                 "SHAP_REFERENCE_DIFFERENT:" + field)
            differences[field] = float(np.max(np.abs(old - new)))
        rng_fields = ("patient_id", "patient_index", "n_iter", "original_stream_n_iter",
                      "rng_before_sha256", "rng_after_original_sha256")
        need([{k: row[k] for k in rng_fields} for row in reference["patient_execution"]["rows"]] ==
             [{k: row[k] for k in rng_fields} for row in component["patient_execution"]["rows"]],
             "SHAP_REFERENCE_ITERATION_OR_RNG_DIFFERENT")
        exact_json(comparison_path, {"scope": "RETAINED_MODEL_COX_PREDICTION_REVISION",
                   "reference_component_sha256": f5._shap_component_sha(reference),
                   "current_component_sha256": f5._shap_component_sha(component),
                   "max_abs_difference": differences, "iterations_and_rng_exact": True})
        del reference
        reference_path.unlink()
    # Native patient checkpoints are needed for recovery only until publication.
    # The final checkpoint is now the sole float64 entity; retained models stay.
    if work.exists():
        shutil.rmtree(work)
    return {"component_sha256": f5._shap_component_sha(component), "engine": component["engine"],
            "patient_count": len(component["patient_ids"]), "background_count": component["background"]["patient_count"],
            "convergence": component["convergence"], "local_accuracy": component["local_accuracy"],
            **({"reference_comparison": read_json(comparison_path)} if comparison_path.exists() else {})}


def run_mi(job):
    prepare_environment(Path(job["package"]), Path(job["output"]), job["rscript"])
    from padml import f5
    from padml.f2_kernel import _response_rows
    rows = csv_rows(job["analysis_path"])
    app_all = csv_rows(job["application_path"])
    need([r["Patient_ID"] for r in rows] == job["analysis_ids"], "M20_TRAINING_SCOPE_DRIFT")
    need([r["Patient_ID"] for r in app_all] == job["application_all_ids"], "M20_APPLICATION_SCOPE_DRIFT")
    need({r["Patient_ID"]: r["Center"] for r in rows} == job["training_centers"], "M20_CENTER_DRIFT")
    _, response = _response_rows(Path(job["response_path"]).read_bytes())
    need(list(response) == job["analysis_ids"], "SHAP_RAW_RESPONSE_ORDER_OR_SCOPE_DRIFT")
    app_by_id = {r["Patient_ID"]: r for r in app_all}
    application = [app_by_id[pid] for pid in job["application_ids"]]
    recipe = read_json(Path(job["output"]) / "recipe.json")
    folder = Path(job["output"]) / f"M{job['task']['imputation']:02d}"
    folder.mkdir(mode=0o700, exist_ok=True)
    model, baseline, record = fit_or_read(job, rows, response, recipe, folder)
    prediction = {"family": "COX_PH", "patient_ids": job["analysis_ids"], "survival": record["survival"]}
    shap = shap_or_read(job, recipe, record, folder, prediction)
    app_path = folder / "application.json"
    app_binding = {"scope": "EXISTING_COMPLETED_APPLICATION_ROWS_BATCH_SINGLE", "input_identity": job["input_identity"],
                   "model_sha256": record["model_sha256"], "recipe_sha256": digest(recipe),
                   "patient_ids_sha256": digest(job["application_ids"])}
    if app_path.exists():
        app = read_json(app_path)
        need(app["binding"] == app_binding and app["batch_single_exact"] is True
             and app["retained_training_exact"] is True, "APPLICATION_RESULT_DRIFT")
    else:
        # The production APPLICATION engine independently checks the retained
        # model/baseline against ANALYSIS training evidence. Completed app rows
        # do not replace that evidence or carry response columns.
        replay = f5._execute_final_refit_engine("COX_PH", job["task"], rows, response, recipe,
            retained_objects=(model, baseline), prediction_rows=application,
            replay_training=True, single_parity=True)
        need(replay["training_survival"] == record["survival"], "RETAINED_TRAINING_PREDICTION_DRIFT")
        need(replay["survival"] == replay["single_survival"], "APPLICATION_BATCH_SINGLE_NOT_EXACT")
        app = {"binding": app_binding, "batch_single_exact": True, "retained_training_exact": True,
               "horizons": f5.HORIZONS, "survival": replay["survival"]}
        atomic_bytes(app_path, raw_json(app))
    f5._seal_prediction_matrix(job["application_ids"], app["survival"], f5.HORIZONS)
    return {"imputation": job["task"]["imputation"], "status": "PASS", "model_sha256": record["model_sha256"],
            "baseline_sha256": record["baseline_sha256"], "shap": shap, "application_survival": app["survival"],
            "application_batch_single_exact": True, "retained_training_exact": True}


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--package", type=Path, default=Path("/opt/padml/candidate"))
    parser.add_argument("--validation-root", type=Path, default=Path("/root/autodl-tmp/padml/validation/integrated-mice"))
    parser.add_argument("--output", type=Path)
    parser.add_argument("--rscript", default=os.environ.get("PADML_RSCRIPT"))
    args = parser.parse_args()
    package, base = args.package.resolve(strict=True), args.validation_root.resolve(strict=True)
    output = (args.output or base / "real-m20-imputed-kernel").absolute()
    need(output.parent.is_dir() and not output.is_symlink() and not output.is_relative_to(package), "VALIDATION_OUTPUT_INVALID")
    need(sys.platform == "linux", "THIS_CHECK_IS_FOR_LINUX_ONLY")
    output.mkdir(mode=0o700, exist_ok=True)
    prepare_environment(package, output, args.rscript)
    from padml import f5, runtime
    from padml._science_authority import load_science_authority
    from padml.f2_kernel import _response_rows, predictor_contract
    # An advisory lock on this directory adds no control-plane file.
    descriptor = os.open(output, os.O_RDONLY)
    try:
        fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
        need(output.stat().st_dev == base.stat().st_dev and output.stat().st_dev != package.stat().st_dev,
             "VALIDATION_AND_TEMP_MUST_USE_DATA_DISK")
        need(shutil.disk_usage(package).free >= 4 * GIB, "SYSTEM_DISK_BELOW_4_GIB")
        analysis_spec, first, analysis = view_input(base / "full0-analysis", "ANALYSIS")
        app_spec, app_first, app_input = view_input(base / "application", "APPLICATION")
        ids = [r["Patient_ID"] for r in first]
        response_path = base / "raw/response-seal.csv"
        _, response = _response_rows(response_path.read_bytes())
        need(list(response) == ids, "ORIGINAL_RESPONSE_MUST_MATCH_FULL0_ORDER_WITHOUT_RENAMING")
        science = load_science_authority()["science"]
        centers = [str(c) for c in science["population"]["validation_centers"]]
        need(len(centers) == 6 and "55" not in centers, "VALIDATION_CENTER_CONTRACT_INVALID")
        candidates = predictor_contract(package / "padml")["parents"]
        app_ids, center_counts, original_app = application_ids(app_spec, app_first, candidates, centers)
        # One qualification per invocation; no source/MICE rehash inside workers.
        sources = {p.relative_to(package).as_posix(): pin(p) for p in sorted((package / "padml").rglob("*"))
                   if p.is_file() and p.suffix in {".py", ".R", ".json", ".csv"} and "__pycache__" not in p.parts}
        sources["dependency-lock.json"] = pin(package / "dependency-lock.json")
        binding = {"scope": SCOPE, "family": "COX_PH", "selected_parents": SELECTED,
                   "patient_count": N, "imputations": 20, "source": sources,
                   "analysis": analysis, "application": app_input, "original_application": original_app,
                   "response": pin(response_path), "application_ids": app_ids,
                   "python": sys.executable, "rscript": runtime.RSCRIPT_EXECUTABLE, "r_library": runtime.R_LIBRARY}
        exact_json(output / "binding.json", binding)
        identity = digest(binding)
        recipe_path = output / "recipe.json"
        if recipe_path.exists():
            recipe = f5._validate_final_design_recipe(read_json(recipe_path), family="COX_PH", selected_parents=SELECTED)
        else:
            partition = {"partition_id": SCOPE, "fit_ids": ids, "covariates": {
                "input_dir": str((base / "full0-analysis/output/imputations").resolve(strict=True)),
                "analysis_ids_sha256": digest(ids), "analysis_view_sha256": digest(analysis)}}
            recipe = f5._compile_partition_design_recipe("COX_PH", SELECTED, partition, output / "tmp")
            atomic_bytes(recipe_path, raw_json(recipe))
        common = {"package": str(package), "output": str(output), "rscript": runtime.RSCRIPT_EXECUTABLE,
                  "input_identity": identity, "response_path": str(response_path), "analysis_ids": ids,
                  "application_all_ids": [r["Patient_ID"] for r in app_first], "application_ids": app_ids,
                  "training_centers": {r["Patient_ID"]: r["Center"] for r in first}}
        jobs = [{**common, "task": {"family": "COX_PH", "imputation": i, "selected_parents": SELECTED,
                 "parameters": {"family": "COX_PH", "ties": "breslow"}, "model_seed": None},
                 "analysis_path": analysis["members"][i - 1]["path"],
                 "application_path": app_input["members"][i - 1]["path"]} for i in range(1, 21)]
        # Same policy as current run.py; actual cgroups/headroom can lower C-8.
        policy = {"configured_worker_ceiling": runtime.CPU_MINUS_8, "memory_bytes_per_worker": 2 * GIB,
                  "memory_reserve_bytes": GIB, "scratch_bytes_per_worker": 2 * GIB,
                  "scratch_reserve_bytes": 0, "transfer_archive_worker_ceiling": 2147483647}
        admission = runtime.admit_stage(policy, output, legal_tasks=20, retained_bytes=GIB,
                    publication_bytes=GIB, transient_bytes_per_worker=2 * GIB)
        pool = {}
        results = runtime._bounded_ordered_spawn(run_mi, jobs, selected_slots=admission["admitted_worker_ceiling"],
                    execution_report=pool, task_timeout_seconds=24 * 60 * 60)
        need([r["imputation"] for r in results] == list(range(1, 21))
             and all(r["status"] == "PASS" for r in results), "M20_FIXED_KERNEL_INCOMPLETE")
        # The final numerical consumer reads the sole MI checkpoints, including
        # a predictor whose completed values differ across imputations.
        components, predictions = [], []
        for i in range(1, 21):
            directory = output / f"M{i:02d}"
            record = read_json(directory / "refit.json")
            checkpoint = directory / "shap.zip"
            _, component = f5._read_shap_checkpoint(checkpoint)
            source_pin = f5._shap_path_pin(checkpoint)
            components.append(f5._shap_collection_result(component,
                {"archive_sha256": source_pin["sha256"], "archive_size_bytes": source_pin["size_bytes"],
                 "component_sha256": f5._shap_component_sha(component)}, checkpoint, i)["component"])
            predictions.append({"family": "COX_PH", "patient_ids": ids, "survival": record["survival"],
                                "model_sha256": record["model_sha256"]})
        mean_survival = [[math.fsum(row["survival"][i][h] for row in predictions) / 20
                          for h in f5.HORIZONS] for i in range(N)]
        aggregation = f5.aggregate_final_shap(components, {"family": "COX_PH", "patient_ids": ids,
            "imputation_count": 20, "per_imputation_predictions": predictions,
            "mean_survival": mean_survival})
        varying = sum(parent["standard_deviation"] > 0 for patient in aggregation["patient_contributions"]
            for horizon in patient["horizons"] for parent in horizon["parent_contributions"])
        need(varying > 0 and all("signed_contributions" not in parent
            for patient in aggregation["patient_contributions"] for horizon in patient["horizons"]
            for parent in horizon["parent_contributions"]), "REAL_MI_UNCERTAINTY_OR_COMPACT_OUTPUT_INVALID")
        aggregation_proof = {"status": "PASS", "patient_count": aggregation["patient_count"],
            "raw_contributions": aggregation["raw_contributions"], "varying_contribution_cells": varying,
            "global_importance_reduction": aggregation["global_importance_reduction"],
            "global_importance": aggregation["global_importance"],
            "component_sha256_by_imputation": aggregation["component_sha256_by_imputation"]}
        del aggregation, predictions, components, mean_survival
        pooled = [[math.fsum(r["application_survival"][j][h] for r in results) / 20
                   for h in f5.HORIZONS] for j in range(len(app_ids))]
        f5._seal_prediction_matrix(app_ids, pooled, f5.HORIZONS)
        for row in results:
            del row["application_survival"]
        final = {"scope": SCOPE, "status": "PASS", "input_identity": identity, "recipe_sha256": digest(recipe),
                 "family": "COX_PH", "selected_parents": SELECTED, "imputations": 20,
                 "training_patient_count": N, "shap_patient_count_per_mi": N, "shap_background_count_per_mi": N,
                 "report_horizons": list(f5.REPORT_HORIZONS), "resource_admission": admission, "pool": pool,
                 "application_scope": "EXISTING_COMPLETED_ROWS_NO_NEW_MICE", "application_per_center": center_counts,
                 "application_patient_ids_sha256": digest(app_ids), "pooled_application_horizons": f5.HORIZONS,
                 "pooled_application_survival": pooled, "results": results,
                 "shap_aggregation": aggregation_proof,
                 "formal_selection_or_lineage_created": False, "new_patient_mice_validated": False,
                 "seven_family_workflow_validated": False, "approximate_shap_longtail_convergence_validated": False}
        need(shutil.disk_usage(package).free >= 4 * GIB, "SYSTEM_DISK_BELOW_4_GIB")
        # Preserve the first complete validation report; a resumed pool can have
        # different wall-clock/resource observations without changing science.
        target = output / "summary.json"
        if target.exists():
            previous = read_json(target)
            for key in ("input_identity", "recipe_sha256", "results", "pooled_application_survival"):
                need(previous[key] == final[key], "RESUMED_VALIDATION_NUMBERS_DRIFT:" + key)
        else:
            atomic_bytes(target, raw_json(final))
        print(json.dumps({"scope": SCOPE, "status": "PASS", "imputations": 20, "patients": N,
                          "application_rows": len(app_ids), "summary": str(target)}, separators=(",", ":")))
    finally:
        os.close(descriptor)


if __name__ == "__main__":
    main()
