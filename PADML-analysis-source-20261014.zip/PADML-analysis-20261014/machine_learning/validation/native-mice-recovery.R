# Focused real-input continuation comparison; not a production entry point.
library(jsonlite)
library(digest)
options(warn = 1)
validation_root <- "/root/autodl-tmp/padml/validation/integrated-mice"
candidate <- "/opt/padml/candidate/padml/kernels/f5_application_mice.R"
reference <- file.path(validation_root, "application")
base <- file.path(validation_root, "recovery-check")
dir.create(base, showWarnings=FALSE)
source_spec <- fromJSON(file.path(reference, "spec.json"), simplifyVector=FALSE)
setup <- function(name) {
  folder <- file.path(base, name)
  dir.create(folder, showWarnings=FALSE)
  dir.create(file.path(folder, "native"), showWarnings=FALSE)
  value <- source_spec
  value$output_dir <- file.path(folder, "output")
  write_json(value, file.path(folder, "spec.json"), auto_unbox=TRUE, null="null", digits=NA)
  folder
}
baseline <- setup("baseline")
resume <- setup("resume")
checkpoint <- file.path(base, "checkpoint40")
dir.create(checkpoint, showWarnings=FALSE)
names <- sprintf("imp%02d.rds", seq_len(20L))
stopifnot(all(file.copy(file.path(reference, "native", names), file.path(baseline, "native", names))))
run_adapter <- function(folder, capture=FALSE) {
  environment <- .GlobalEnv
  environment$commandArgs <- function(trailingOnly=FALSE) if (trailingOnly)
    c("FIT", file.path(folder, "spec.json")) else paste0("--file=", candidate)
  program <- as.list(parse(candidate))
  entry <- which(vapply(program, function(x) identical(x, quote(impute_view(spec, authority))), logical(1)))
  stopifnot(length(entry)==1L)
  for (expr in program[seq_len(entry-1L)]) eval(expr, environment)
  saved_originals <- environment$original_functions
  on.exit(for (name in names(saved_originals)) assignInNamespace(name, saved_originals[[name]], ns="mice"), add=TRUE)
  if (capture) {
    # Force the two permitted continuation checkpoints for this check only.
    # No imputation parameter, donor, value or random draw is changed.
    environment$authority$science$mice$convergence$psrf_standard_max <- 0.5
    replace <- function(expr) {
      if (identical(expr, quote(saveRDS(fit, pending, version = 3L))))
        return(bquote({saveRDS(fit, pending, version=3L)
          if (fit$iteration == 40L) stopifnot(file.copy(pending, file.path(.(checkpoint), basename(path))))}))
      if (is.call(expr)) for (i in seq_along(expr))
        if (!is.null(expr[[i]]) && !identical(expr[[i]], quote(expr=))) expr[[i]] <- replace(expr[[i]])
      expr
    }
    body(environment$native_chains) <- replace(body(environment$native_chains))
  }
  eval(program[[entry]], environment)
}
started <- proc.time()[[3L]]
run_adapter(baseline, TRUE)
origins <- vapply(seq_along(names), function(i) if (i %% 3L == 0L) file.path(baseline,"native",names[[i]])
  else if (i %% 3L == 1L) file.path(reference,"native",names[[i]]) else file.path(checkpoint,names[[i]]), character(1))
stopifnot(all(file.copy(origins, file.path(resume,"native",names))))
before <- vapply(file.path(resume,"native",names), function(p) digest(file=p, algo="sha256"), character(1))
run_adapter(resume)
fields <- c("imp","chainMean","chainVar","lastSeedValue","iteration","data","method","predictorMatrix","ignore","where")
for (i in seq_along(names)) {
  x <- readRDS(file.path(baseline,"native",names[[i]]))
  y <- readRDS(file.path(resume,"native",names[[i]]))
  stopifnot(x$iteration == 50L, y$iteration == 50L,
    all(vapply(fields, function(n) identical(x[[n]], y[[n]]), logical(1))),
    identical(attr(x,"padml_application"), attr(y,"padml_application")))
  if (i %% 3L == 0L) stopifnot(before[[i]] == digest(file=file.path(resume,"native",names[[i]]),algo="sha256"))
  stopifnot(identical(readBin(file.path(baseline,"output/imputations", sub("rds$","csv",names[[i]])),"raw",n=1e8),
    readBin(file.path(resume,"output/imputations", sub("rds$","csv",names[[i]])),"raw",n=1e8)))
}
result <- list(status="PASS", input="a.xlsx", patients=length(source_spec$view$row_ids), imputations=20L,
  initial_iterations=list(30L,40L,50L), terminal_iteration=50L,
  equal_fields=as.list(fields), donor_trace_identical=TRUE, already_complete_bytes_unchanged=TRUE,
  completed_csv_identical=TRUE, elapsed_seconds=proc.time()[[3L]]-started)
write_json(result,file.path(base,"comparison.json"), auto_unbox=TRUE,digits=NA,pretty=TRUE)
cat(toJSON(result,auto_unbox=TRUE),"\n")
