"""Bounded H01 -> actual ExFAT -> offline consumer check; no clinical records."""
import io
import json
import os
from pathlib import Path
import shlex
import shutil
import subprocess
import sys
from threading import BoundedSemaphore

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from padml import reports, nested_loco as n
from padml.bundle import canonical_json_bytes
from padml.carriers import open_carrier, pooled_matrix

ssh = ['ssh', '-p', '24501', '-i', '/Users/liuningyuan/.ssh/pad_ml_autodl_ed25519',
       '-o', 'UserKnownHostsFile=/Users/liuningyuan/.ssh/padml-instances-h05-31044-known_hosts',
       '-o', 'StrictHostKeyChecking=yes', 'root@connect.westb.seetacloud.com']


def remote(script):
    return ssh + ['/opt/padml/bin/padml-env python -c ' + shlex.quote(
        'import sys;sys.path.insert(0,"/opt/padml/candidate");' + script)]


prepared = subprocess.run(remote('import json,runpy,tempfile;from pathlib import Path;import pytest;'
    't=Path(tempfile.mkdtemp(prefix="archive-native-",dir="/root/autodl-tmp/padml/validation"));'
    'f=runpy.run_path("/opt/padml/candidate/tests/test_window_archive.py");'
    'r,s,a,i=f["fixture"](t,pytest.MonkeyPatch());r["run_id"]="PADML_NATIVE_ARCHIVE_CHECK";'
    'print(json.dumps({"run":r,"inventory":i}))'), capture_output=True, check=True, timeout=60)
value = json.loads(prepared.stdout)
run, inventory = value['run'], value['inventory']
root = Path('/Volumes/My Passport/Machine Learning 2')
target = reports.prepare_archive(run, root)
os.environ['PADML_F45_RUN_PATH'] = str(target/'run.json')


def command(host, operation, **kwargs):
    assert operation == 'archive_send'
    return remote('import json;from padml.reports import archive_send;'
        f'r,p=json.loads({json.dumps([run,kwargs])!r});'
        'archive_send(r,p["horizon"],p["inventory_identity"],p["members"],p["offset"],sys.stdout.buffer)')


members = {}
small = [name for name,row in inventory['members'].items() if not row['native_file']]
groups = [[name] for name in inventory['members'] if name not in small]+[small]
for names in groups:
    if not names:
        continue
    pins = {name:{k:inventory['members'][name][k] for k in ('sha256','size_bytes')} for name in names}
    spec = {'host':'H0','horizon':6,'inventory_identity':inventory['identity_sha256'],
        'members':names,'pins':pins,'volume_device':target.stat().st_dev}
    if names == ['shared/model.f64']:
        import struct
        (target/'objects'/(pins[names[0]]['sha256']+'.part')).write_bytes(struct.pack('<d',.8)[:4])
    members.update(reports.receive_archive(run,target,spec,command=command,slots=BoundedSemaphore(3)))
index = n._sealed({'kind':'PADML_WINDOW_ARCHIVE_INDEX_V1','run_identity':run['identity'],
    'source_identity':run['source_identity'],'members':members,'windows':{'6':{}}})
(target/'index.json').write_bytes(canonical_json_bytes(index))
os.environ['PADML_ARCHIVE_INDEX'] = str(target/'index.json')
# Remove the complete disposable remote producer before opening the archive.
subprocess.run(remote(f'import shutil;shutil.rmtree({str(Path(run["run_root"]).parent)!r})'),
               capture_output=True, check=True, timeout=30)
with open_carrier(Path(run['run_root'])/'units/EVALUATION-H06/result.zip') as outer:
    with open_carrier(io.BytesIO(outer.read('producer.zip'))) as inner:
        assert pooled_matrix(json.loads(inner.read('number.json'))) == [[.8]*37]
        assert json.loads(inner.read('note.json')) == {'note':'unique'}
assert not list(target.rglob('*.part'))
result = {'status':'PASS','volume':reports._archive_volume(root),'transport':'SSH',
    'source_removed_before_consumer':True,'resumed_partial_bytes':4,
    'declared_members':len(members),'physical_streams':len([g for g in groups if g]),
    'physical_bytes':sum(p.stat().st_size for p in target.rglob('*') if p.is_file()),
    'allocated_bytes':sum(p.stat().st_blocks*512 for p in target.rglob('*') if p.is_file())}
def already_removed(function, path, error):
    # ExFAT AppleDouble entries disappear when their owning file is removed.
    if not isinstance(error, FileNotFoundError):
        raise error
shutil.rmtree(target, onexc=already_removed)
print(json.dumps(result, ensure_ascii=False))
