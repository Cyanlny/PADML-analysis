#!/usr/bin/env Rscript
# Real retained M20: shape-independent prediction, no fitting or MICE.
suppressPackageStartupMessages({library(survival);library(jsonlite)})
source('/opt/padml/candidate/padml/kernels/f5_design.R')
root <- '/root/autodl-tmp/padml/validation/integrated-mice/real-m20-fixed-kernel'
need <- function(ok, code) if (!isTRUE(ok)) stop(code, call.=FALSE)
reports <- vector('list',20L)
for (i in seq_len(20L)) {
  folder <- file.path(root,sprintf('M%02d',i))
  model <- readRDS(file.path(folder,'model.bin')); fit <- model$fit
  base <- readRDS(file.path(folder,'baseline.bin'))$baseline
  options(matprod='blas'); before <- getOption('matprod')
  value <- padml_coxph_survival(fit,fit$x,0:36,need,base)
  need(identical(before,getOption('matprod')),'COX_PREDICT_CHANGED_CALLER_MATPROD')
  idx <- unique(c(seq_len(12L),nrow(fit$x)-1L,nrow(fit$x)))
  singles <- do.call(rbind,lapply(idx,function(j)
    padml_coxph_survival(fit,fit$x[j,,drop=FALSE],0:36,need,base)))
  need(identical(unname(value[idx,,drop=FALSE]),unname(singles)), 'COX_BATCH_SINGLE_DIFFERENT')
  reordered <- rev(seq_len(nrow(fit$x)))
  need(identical(unname(value[reordered,,drop=FALSE]),unname(
    padml_coxph_survival(fit,fit$x[reordered,,drop=FALSE],0:36,need,base))), 'COX_ROW_ORDER_DIFFERENT')
  native <- survfit(fit,newdata=as.data.frame(fit$x),se.fit=FALSE)
  pos <- findInterval(0:36,native$time); reference <- matrix(1,nrow(fit$x),37L)
  reference[,pos>0L] <- t(native$surv[pos[pos>0L],,drop=FALSE])
  need(all(abs(value-reference) <= 1e-12+1e-10*pmax(1,abs(reference))), 'COX_NATIVE_SURVFIT_DIFFERENT')
  reports[[i]] <- list(imputation=i,patients=nrow(fit$x),batch_single_exact=TRUE,
    reorder_exact=TRUE,matprod_restored=TRUE,native_max_abs=max(abs(value-reference)))
}
write_json(list(scope='REAL_RETAINED_M20_COX_PREDICTION_ONLY',status='PASS',fits=0L,results=reports),
  file.path(root,'coxph-parity.json'),auto_unbox=TRUE,pretty=TRUE,digits=NA)
cat('REAL_RETAINED_M20_COX_PREDICTION_ONLY PASS\n')
