"""Real M01, original R entry, four independent atoms and retained replay.

This exercises fit/transport/recovery; it is not a formal candidate search.
"""
import copy
import csv
import json
import os
from pathlib import Path
import subprocess
import sys
import time

sys.path.insert(0, '/opt/padml/candidate')
from padml import f2_kernel as k, f4
from padml.bundle import canonical_json_bytes, sha256_file

base = Path('/root/autodl-tmp/padml/validation/integrated-mice')
root = base / 'r-small-batch'
root.mkdir(exist_ok=True)
package = Path('/opt/padml/candidate/padml')
input_dir = base / 'full0-analysis/output/imputations'
with (input_dir/'imp01.csv').open() as stream:
    rows = list(csv.DictReader(stream))
with (base/'raw/response-seal.csv').open() as stream:
    responses = list(csv.DictReader(stream))
ids = [row['Patient_ID'] for row in rows]
assert ids == [row['Patient_ID'] for row in responses]
fit_ids = [x for i,x in enumerate(ids) if i % 5 != 0]
test_ids = [x for i,x in enumerate(ids) if i % 5 == 0]
response = root/'fit-response.csv'
with response.open('w',newline='') as stream:
    writer=csv.DictWriter(stream,fieldnames=list(responses[0]))
    writer.writeheader(); writer.writerows(row for row in responses if row['Patient_ID'] in set(fit_ids))
pin={'sha256':sha256_file(input_dir/'imp01.csv'),'size_bytes':(input_dir/'imp01.csv').stat().st_size}
partition={'kind':'INNER','partition_id':'INNER_R1_K1','repeat':1,'inner_fold':1,
    'application_ids':ids,'fit_ids':fit_ids,'evaluation_ids':test_ids,
    'evaluation_ids_sha256':k._sha(test_ids),
    'covariates':{'input_dir':str(input_dir),'members':[pin]},
    'fit_response':{'path':str(response),'sha256':sha256_file(response),
      'size_bytes':response.stat().st_size,'row_count':len(fit_ids),'row_ids_sha256':k._sha(fit_ids)}}
parents=['AST_ALT','Age','RBC','MCV','INR','BMI']
summary={'scope':'REAL_M01_NATIVE_ENTRY_NOT_FORMAL_SEARCH','patients':len(ids),'families':{}}
for family in ('RSF','GBM_COX'):
    parameters=({'num_trees':500,'max_depth':'UNLIMITED','mtry_fraction':.5,
      'min_node_size':3,'sample_fraction':.632,'splitrule':'logrank'} if family=='RSF' else
      {'max_trees':3000,'locked_trees':3000,'interaction_depth':2,'shrinkage':.01,
       'min_observations_in_node':10,'bag_fraction':.75})
    source={'program_id':'PADML_F45_REBUILD_20260925','family':family}
    registered={'kind':'PADML_F5_REGISTERED_PARTITION_INPUTS','status':'PASS','fold':0,
      'outer_count':0,'diagnostic_count':0,'full_count':0,'inner_count':15,
      'stop_count':0 if family=='RSF' else 15,'view_count':15 if family=='RSF' else 30,
      'projected_partition_count':1,'partitions':[partition],'diagnostic_partitions':[],
      'projected_partition_ids':[partition['partition_id']]}
    template={'action':'MODEL_PREDICTION_BATCH','execution_scope':'F5_FULL_DEVELOPMENT_SEARCH',
      'fold':0,'heldout_center':0,'family':family,'threads':1,'seed':300000,
      'outcome':'All_Cause_Death','time':'Death_Followup_months','imputation_count':20,
      'horizons':list(range(37)),'predictors':k.predictor_contract(package),
      'selector_from_dependency':{'selected_parents':parents},'transform_recipe':None,
      'final_search_source':source,'registered_inputs_identity_sha256':k._sha(registered),
      'registered_partitions':registered}
    collected={};timings={}
    for mode in ('single','batch'):
        native=root/family/mode/'native';native.mkdir(parents=True,exist_ok=True)
        child=f4._NativeRSmallBatch() if mode=='batch' else None
        start=time.perf_counter();values=[]
        try:
            for i in range(1,5):
                task={'task_id':f'S1_T{i:03d}_P01_M01','partition_id':partition['partition_id'],
                  'imputation':1,'family':family,'selected_parents':parents,'producer_kind':'SURVIVAL',
                  'parameters':parameters,'seed':300100+i}
                initial=None
                for replay in (False,True):
                    work=root/family/mode/f'{i}-{int(replay)}';work.mkdir(exist_ok=True)
                    spec={**template,'native_search_root':str(native),'native_search_replay':replay,
                      'producer_tasks':[task],'output_path':str(work/'output.json')}
                    path=work/'spec.json';path.write_bytes(canonical_json_bytes(spec))
                    # Retain completed native producers if a later transport request failed.
                    # Every existing producer still receives the original native replay below.
                    if replay or not (work/'output.json').is_file():
                        with (work/'stdout.log').open('wb') as out,(work/'stderr.log').open('wb') as err:
                            if child is None:
                                answer=subprocess.run(['/opt/padml/runtime/r-env/bin/Rscript','--vanilla',
                                  str(package/'kernels/f4_gbm_stop.R'),str(path)],cwd=work,
                                  env=os.environ,stdout=out,stderr=err)
                            else:
                                answer=child.run('/opt/padml/runtime/r-env/bin/Rscript',
                                  package/'kernels/f4_gbm_stop.R',path,work,os.environ,out,err)
                        assert answer.returncode==0,(work,(work/'stderr.log').read_text()[-2000:])
                    observed=(work/'output.json').read_bytes()
                    hashes={p.name:sha256_file(p) for p in (native/task['task_id']).iterdir()}
                    if not replay:
                        initial=(observed,hashes)
                    else:
                        assert (observed,hashes)==initial
                values.append(initial)
        finally:
            if child is not None:child.close()
        timings[mode]=time.perf_counter()-start;collected[mode]=values
    assert [x[0] for x in collected['single']]==[x[0] for x in collected['batch']]
    summary['families'][family]={'tasks':4,'native_calls':8,'predictions_and_health_bitwise':True,
      'retained_model_replay_unchanged':True,'seconds':timings}
summary['status']='PASS'
(base/'r-small-batch-comparison.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary))
