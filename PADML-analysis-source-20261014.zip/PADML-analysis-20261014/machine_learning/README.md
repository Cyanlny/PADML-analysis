# PADML 原始数据至最终报告统一计算包

用于下一批新原始数据。原始工作簿直接进入嵌套LOCO；F1插补和F2筛选/七家族成为内部函数。新运行无需旧F1/F2结果目录。科学定义见[NESTED_LOCO_PROTOCOL.md](NESTED_LOCO_PROTOCOL.md)，实际验证边界见[COMPILE_REPORT.md](COMPILE_REPORT.md)。

保留56个科学整单、28个O_fit/选择后B1000上下文，四线独立锁定和四时点报告；三AAR分支、FULL0、SHAP和应用材料均保留。六中心等权与按本批原始验证人数固定加权macro同时输出，区间沿全部1000个配对抽样编号。

## 准备

在七机相同绝对路径部署同一冻结源码与依赖，使用新的运行目录。环境由`config/environment.example.json`指定：Python、Rscript及完整有序R库路径；`dependency-lock.json`记录实际依赖和修正包身份。SHAP库与reticulate必须包含在库路径中。安装阶段核对全部来源制品，部署生成`runtime_manifest`（`path`、`root`、`sha256`、`size_bytes`），列出实际安装的文件、目录和链接。首个worker依据冻结清单完整核验安装字节、R/Python实际加载及桥接；随后复用未变化安装的持久资格，安装压缩包可清理。未提供安装清单时，仍要求`artifact_paths`中全部来源文件存在并通过完整校验。加载路径、运行文件或目录结构漂移均拒绝；版本字符串不能代替字节验收。模板的锁SHA、清单及主机地址须绑定实际部署，凭证保留在既有SSH配置中。

在解包目录执行（`/data/padml/new-batch`、工作簿名、ID按实际替换）：

```sh
python3 -m padml.run f45-prepare /data/padml/new-batch/run.json \
  --run-root /data/padml/new-batch \
  --workbook /data/padml/input/new-data.xlsx \
  --run-id new-batch \
  --hosts /data/padml/config/hosts.json \
  --environment /data/padml/config/environment.json \
  --source-bundle-sha256 ACTUAL_RELEASE_ZIP_SHA256
```

准备只绑定清单，不启动正式科学任务。将同一workbook/run.json/源码部署到相同路径；每台只有一个活动整单。原始数据首次绑定自动执行。新原始数据必须符合原变量、编码、结局和FPM定义域；人数不固定为旧批次。

## 执行与恢复

```sh
/opt/padml/bin/padml-env python -m padml.worker f45 \
  /data/padml/new-batch/run.json PRIMARY-H06-O1
```

同一命令再次运行即恢复。`run.json`允许存放在独立配置目录；运行材料、资格和资源观测始终使用其`run_root`。其余单名来自run.json；每个整单自动贯穿内部计算和直接消费者。已有完成单追加诊断仍用原入口：

```sh
/opt/padml/bin/padml-env python -m padml.worker f45 \
  /data/padml/new-batch/run.json PRIMARY-H06-O1 --mode postprocess
/opt/padml/bin/padml-env python -m padml.worker f45 \
  /data/padml/new-batch/run.json EVALUATION-H06 --mode selection --source-unit PRIMARY-H06-O1
```

在持有七机SSH访问配置的执行端，使用同一个`next`入口自动观察、传输并动态补位。执行端保持该命令运行，源码在七机均部署到`--code-root`指定位置，工作簿、依赖和run.json在清单指定的相同绝对路径：

```sh
python3 -m padml.run f45-next /local/padml/new-batch/run.json \
  --dispatch --follow --code-root /opt/padml/code --poll-seconds 30 \
  --remote-run-path /root/autodl-tmp/padml/runs/new-batch/run.json \
  --archive-root '/Volumes/My Passport/Machine Learning 2'
```

本地清单、Linux清单路径和外盘归档位置分别指定；科学`run_root`继续采用Linux数据盘路径。只派发当前就绪的一批可去掉`--follow`；控制端中断不会终止远端worker，重新执行同一命令会观察原owner再接续，不重复启动。持续派发保留未完成的传输状态，独立实例无需等待本轮所有传输结束。SSH由本机OpenSSH配置提供私钥、known_hosts；程序不接受未知主机密钥、不存凭证。首条paired评价在自身owner内生成一次共享抽样，其余三线看到原抽样回执后立即接续，无需等第一条评价完成。

仅查看人工采集的状态与分配建议（不会执行SSH或启动任务）：

```sh
python3 -m padml.run f45-next /data/padml/new-batch/run.json /data/padml/observations.json
```

派发器只传：EVALUATION所需12个来源的`unit.json`和`evaluation-input.zip`、两份共享抽样材料；selection传该来源的小型`postprocess/input.zip`及其中精确引用的OOF、表观/响应和draw闭包，相同目标pin只留一份。引用ZIP不能当成脱离run_root的自包含文件搬运。直接SSH流式传输，目的端同目录临时文件核SHA后一次发布；相同pin直接跳过，漂移和连接未知均停止，不降格为缺失。科学完成与UNKNOWN缓存诊断分开处理。失败owner需查看`active.log`并核实原进程组，修复后用上面的原worker命令续缺项；不自动重试计算错误。

原outer/FULL0上下文保持本机；空闲机动态补位。四线评价可占四机，selection在自身输入就绪后执行，无AAR或其他线全完屏障。UNKNOWN进程状态必须核实，不能另启同单。

## 复用与体积

| 材料 | 新批内复用与保留 |
|---|---|
| 原始数据/MICE | 一份绑定；同分区/规则/seed共用。原子链与view恢复；无缺失时20逻辑槽、实际链0，不消耗RNG |
| selector | 全部loss/lambda/df/健康及outer系数路径；首次数值消费后退役大风险输出 |
| Q候选 | 实际相同拟合只保留一份0–36曲线，四线独立评分；不同SetA/STOP等独立算 |
| STOP | 尚有另一个实际人口消费者时保留唯一共享函数；各Q不复制大原生树；本context四线与AAR全部消费后按原pin退役 |
| 七家族OOF | 每家族15折M20池化曲线唯一f64，评分/O_fit/selection直接引用；退役已消费候选模型副本 |
| 最终M20/SHAP | 正式模型保留；原子患者检查点，只续缺项，完整患者/背景和精度不变 |
| 评价 | 紧凑OOC和原来源；B1000首验后保留统计量/支持/绑定，退役重复患者及原生输入 |

EVALUATION写出正式result及unit回执后退役其私有工作目录与已嵌入的旁置紧凑输入；完成单恢复也会完成该退役。selection及源模型不在删除范围。

unit.json引用实际模型/数值；新轮不生成外层unit.zip。下游传输优先使用evaluation-input.zip或postprocess紧凑材料；不搬完整候选开发档案。不要整根删除`.work`或contexts：其中仍可能有最终模型、唯一MICE或STOP依赖。

资源保持单层池、实测C−8、线程1、每worker最低1GiB（任务自身的更高内存估计仍参与准入，旧回执保留原2GiB预算）。实际磁盘预算独立考虑保留结果、并发临时输出及发布空间；新paired坐标保留上限256KiB，原生临时峰值另算，磁盘限制可减少worker。

每窗正式结果及引用闭包就绪后，原派发器后台归档；同一大实体只传一次，小文件合包，ExFAT不使用硬链接。最多三路大文件传输，其中后台归档最多两路，为计算输入保留一个槽位。挂载失效、传输停顿或确认失败保留源文件及可续传的`.part`，不会重训。只有实际selection、EVALUATION、后续窗口消费者及归档均完成，源材料才可退役。离线读取通过`PADML_ARCHIVE_INDEX`解析实际位置，保留原科学路径与pin。

## 自动报告及字段

28个PRIMARY/FULL0后处理同时完成mRMRe/Boruta敏感性、独立AST_ALT惩罚因子1审计，以及入选RSF/GBM/XGBoost的两个额外种子。主SetA、家族和参数锁不变；AAR不添加这些诊断。FULL0还执行每验证中心最多2名相关缺失患者的批量/逐例M20四时点工程应用自检，55只作供体，不等同完整A04。

`next --dispatch --follow`在原56单、28组O_fit/selection及上述尾部完成、owner退出后，自动汇集212份小型报告/回执。控制端中断后重跑原命令，仅补缺项。结果位于：

| 路径 | 内容/关键字段 |
|---|---|
| `reports/index.html`、`report.md`、`index.json` | 静态索引、逐文件pin、来源host/run_root、原正式模型/数值位置；不另复制模型 |
| `reports/o-fit-all.csv` | source_unit、development_horizon、report_month、selected_family、表观/三重复OOF/均值/optimism、status/reasons/support；FULL0单列 |
| `reports/selection-all.csv` | 固定OOF条件下各时点乐观偏移及type7区间、有效次数/失败原因；每上下文result.json另列1000编号身份与家族频率 |
| `reports/units/EVALUATION-H*/report-*.csv` | PRIMARY/AAR四时点、六中心等权/固定人数加权、95%区间与AAR−PRIMARY；保留不可估计状态 |
| `reports/units/*/postprocess/diagnostics/result.json` | mRMRe/Boruta频率/集合/EPV/稳定性/重叠、AST_ALT系数和非零/20、赢家额外种子阶段及实际计数 |
| `reports/units/FULL0-H*/application.json`、`report-summary.json` | 工程自检真实差值、患者数和状态；FULL0模型身份与SHAP全局摘要 |

计算完成、指标不可估计、应用自检状态分别报告。原始SHAP患者贡献、OOF、bootstrap逐编号数值和最终模型保留在来源机正式载体；汇总只携带位置和pin。

当前原生验收的输入、范围、数值对照与待完成项见`COMPILE_REPORT.md`。代表性检查、正式56单及28组尾部的完成状态分别记录，不能相互替代。
