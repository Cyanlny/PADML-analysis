from __future__ import annotations

import csv
import io
import shutil
from pathlib import Path
from unittest.mock import patch

import pytest

from test_retained_full0_source import retained_source_bundle  # noqa: F401

from padml._science_authority import load_science_authority
from padml.bundle import ContractError, canonical_json_bytes, sha256_bytes, sha256_file, write_deterministic_zip
from padml.f2_kernel import _response_rows, _write_response_subset
from padml.nested_loco import (
    HORIZONS,
    M,
    _component_execution_receipt,
    _recompute_fresh_score_from_evidence,
    _score_fresh_family,
    _score_component_evidence,
    _sealed,
    _sha,
    _write_component_archive,
    _write_exact_once,
    compile_training_context,
)


FAMILY = "FPM_TVC_SET_A"
PARAMETERS = {"family": FAMILY, "df": 3, "tvc_df": 1}
NATIVE_BYTES = b"fixture-native-archive-no-model-execution\n"


@pytest.fixture
def outer_fixed12_pair(tmp_path, monkeypatch):
    """Original 300-component numerical reader; all model leaves UNFITTED.

    The six other families are input-coordinate metadata only: this fixture
    makes no seven-family science or complete-owner acceptance claim.
    """
    from copy import deepcopy
    from padml import f2_kernel, f4, f5, nested_loco as nested
    request, request_root, components, outputs = build_fixture(tmp_path / "producer")
    for row in request["component_records"]:
        row["size_bytes"] = (request_root / row["path"]).stat().st_size
    original_records = deepcopy(request["component_records"])
    request["component_records"] = [
        {**row, "family": family, "path": row["path"].replace(FAMILY, family)}
        for family in nested._families() for row in original_records]
    decision = nested._read_canonical(Path(__file__).resolve().parents[1] / "science-decision.json", "DECISION")
    request.update(kind="PADML_F4_O_FIT_INPUT_V1", reused_training_scores=[], science_decision={
        "identity_sha256": decision["twelve_month_development"]["original_24_month_decision_sha256"]})
    request = _sealed(request)
    target_root = tmp_path / "target-request"
    shutil.copytree(request_root, target_root)
    context = _sealed({**{k: v for k, v in request["training_context"].items() if k != "identity_sha256"},
                       "modeling_program_sha256": "f" * 64})
    target = _sealed({**{k: deepcopy(v) for k, v in request.items() if k != "identity_sha256"},
                      "training_context": context, "selection_horizon_months": 12, "science_decision": decision})
    def read_component(path):
        relative = path.relative_to(request_root if path.is_relative_to(request_root) else target_root)
        return components[relative.as_posix()]
    monkeypatch.setattr(nested, "_read_component", read_component)
    monkeypatch.setattr(f2_kernel, "_expected_family_parent_column_map", lambda *_a, **_k: [{"columns": ["AST_ALT", "Age"]}])
    monkeypatch.setattr(f2_kernel, "predictor_contract", lambda *_a, **_k: {})
    monkeypatch.setattr(f5, "_validate_final_r_fit_health", lambda *_a, **_k: None)
    monkeypatch.setattr(f5, "_validate_retained_r_audit_numbers", lambda *_a, **_k: None)
    monkeypatch.setattr(f5, "_score_archive_expanded_limit", lambda *_a, **_k: None)
    def forbidden(*_a, **_k):
        pytest.fail("UNFITTED fixture must not fit, replay a model, or create a lock")
    for module, names in ((f4, ("_replay_f4_model_component",)),
                          (f5, ("_execute_and_verify_score_archive_job", "_replay_component_job")),
                          (nested, ("_component_execution_receipt", "select_training_family", "seal_development_lock"))):
        for name in names:
            monkeypatch.setattr(module, name, forbidden)
    score, execution = _score_fresh_family(family=FAMILY, request=request, root=request_root.parent, outputs=outputs)
    result_root = stage_result(tmp_path / "result", request_root.parent, execution)
    arguments = dict(execution=execution, score=score, request=request, request_root=request_root,
                     result_root=result_root, expanded_bytes_per_component=1024**2,
                     retained_bytes_per_component=1024**2, rescore_science_decision=decision,
                     outer_fixed12_target_request=target, outer_fixed12_target_root=target_root)
    return arguments, target, target_root


def test_outer_fixed12_original_consumer_then_original_readback(outer_fixed12_pair):
    arguments, target, target_root = outer_fixed12_pair
    original = canonical_json_bytes([arguments["request"], arguments["score"], arguments["execution"]])
    consumed = _recompute_fresh_score_from_evidence(**arguments)
    execution, score = consumed["fresh_score_execution"], consumed["training_score"]
    assert execution["training_context_sha256"] == score["training_context_sha256"] == target["training_context"]["identity_sha256"]
    assert execution["retained_score_request_sha256"] == arguments["request"]["identity_sha256"]
    assert execution["component_evidence_records"] == arguments["execution"]["component_evidence_records"]
    assert all(execution[name] == 0 for name in ("new_model_fit_count", "new_first_native_audit_count", "new_native_replay_count"))
    assert execution["model_fit_count"] == 300
    readback = _recompute_fresh_score_from_evidence(execution=execution, score=score,
        request=target, request_root=target_root, result_root=arguments["result_root"],
        retained_request=arguments["request"], retained_request_root=arguments["request_root"],
        expanded_bytes_per_component=1024**2, retained_bytes_per_component=1024**2)
    assert readback == score
    assert canonical_json_bytes([arguments["request"], arguments["score"], arguments["execution"]]) == original


def test_outer_fixed12_completed_summary_is_verified_not_relabelled(outer_fixed12_pair):
    from copy import deepcopy
    arguments, _, _ = outer_fixed12_pair
    old_arguments = {k: v for k, v in arguments.items() if not k.startswith("outer_fixed12_")}
    retained = _recompute_fresh_score_from_evidence(**old_arguments)
    original = canonical_json_bytes(retained)
    consumed = _recompute_fresh_score_from_evidence(**arguments, outer_fixed12_retained_result=retained)
    assert consumed["retained_result"] == retained
    assert consumed["fresh_score_execution"]["retained_score_request_sha256"] == arguments["request"]["identity_sha256"]
    assert canonical_json_bytes(retained) == original
    changed = deepcopy(retained)
    changed["training_score"]["mean_ibs"] += 0.01
    with pytest.raises(ContractError, match="NESTED_OUTER_FIXED12_RETAINED_RESULT_DRIFT"):
        _recompute_fresh_score_from_evidence(**arguments, outer_fixed12_retained_result=changed)


@pytest.mark.parametrize("defect", ["partition", "selector", "mice", "parameter", "missing_coordinate", "bytes", "replay"])
def test_outer_fixed12_pair_rejects_before_first_new_metric(outer_fixed12_pair, monkeypatch, defect):
    from copy import deepcopy
    from padml import f2_kernel
    arguments, target, target_root = outer_fixed12_pair
    changed = deepcopy(target)
    if defect == "partition":
        changed["score_partitions"] = changed["score_partitions"][::-1]
    elif defect == "selector":
        changed["selector_evidence_sha256"] = "f" * 64
    elif defect == "mice":
        changed["training_context"]["mice_member_set_sha256"] = "f" * 64
        changed["training_context"] = _sealed({k: v for k, v in changed["training_context"].items() if k != "identity_sha256"})
    elif defect == "parameter":
        next(row for row in changed["component_records"] if row["family"] == FAMILY)["parameter_sha256"] = "f" * 64
    elif defect == "missing_coordinate":
        changed["component_records"].pop()
    elif defect == "bytes":
        path = target_root / next(row for row in changed["component_records"] if row["family"] == FAMILY)["path"]
        raw = path.read_bytes()
        path.write_bytes(b"X" + raw[1:])
    elif defect == "replay":
        arguments["replay_models"] = True
    changed = _sealed({k: v for k, v in changed.items() if k != "identity_sha256"})
    arguments["outer_fixed12_target_request"] = changed
    def forbidden(*_a, **_k):
        pytest.fail("bad pair must be rejected before computing a new metric")
    monkeypatch.setattr(f2_kernel, "_evaluate_prediction_seal", forbidden)
    with pytest.raises(ContractError):
        _recompute_fresh_score_from_evidence(**arguments)


def test_exact_once_rejects_oversized_existing_bytes_before_read(tmp_path, monkeypatch):
    target = tmp_path / "imp01.csv"
    target.write_bytes(b"UNFITTED oversized original context")
    def forbidden(*args, **kwargs):
        pytest.fail("An oversized existing context must be rejected before reading")
    monkeypatch.setattr(Path, "read_bytes", forbidden)
    with pytest.raises(ContractError, match="NESTED_SCORE_CONTEXT_RESUME_DRIFT"):
        _write_exact_once(target, b"short", "NESTED_SCORE_CONTEXT_RESUME_DRIFT")


def response_csv(patient_ids: list[str]) -> bytes:
    stream = io.StringIO(newline="")
    writer = csv.DictWriter(
        stream,
        fieldnames=["Patient_ID", "All_Cause_Death", "Death_Followup_months"],
        lineterminator="\n",
    )
    writer.writeheader()
    for patient_id in patient_ids:
        writer.writerow(
            {
                "Patient_ID": patient_id,
                "All_Cause_Death": 1,
                "Death_Followup_months": 50,
            }
        )
    return stream.getvalue().encode()


def build_fixture(root: Path, *, full_score=False, science_decision=None):
    from padml import f4, f5
    parameters = {"family": FAMILY, "df": [3, 1], "tvc_parent": "AST_ALT"} if full_score else PARAMETERS
    request_root = root / "request"
    (request_root / "training").mkdir(parents=True)
    patient_ids = [f"p{index:02d}" for index in range(40)]
    response = response_csv(patient_ids)
    (request_root / "training" / "response.csv").write_bytes(response)
    centers = {patient_id: "38" for patient_id in patient_ids}
    if not full_score:
        centers["heldout"] = "36"
    context = compile_training_context(
        scope="FULL_DATA" if full_score else "OUTER",
        outer_fold=0 if full_score else 1,
        heldout_center=None if full_score else 36,
        training_ids=patient_ids,
        heldout_ids=[] if full_score else ["heldout"],
        centers_by_patient=centers,
        training_response_csv=response,
        mice_member_set_sha256="a" * 64,
        preprocessing_program_sha256="b" * 64,
        modeling_program_sha256="c" * 64,
        seed_program_sha256="d" * 64,
    )
    fields, response_rows = _response_rows(response)
    if full_score:
        development = _sealed({"training_context": context,
            **({"selection_horizon_months": 12, "science_decision": science_decision}
               if science_decision is not None else {}),
            "selector_development": {"identity_sha256": "e" * 64,
                "selector": {"selected_parents": ["AST_ALT", "Age"]},
                "transform_recipes": {"recipe_set_sha256": "f" * 64}},
            "complex_search_evidence": [], "locked_specs": {FAMILY: parameters}})
        family_source = f5._full_score_family_source(development, FAMILY)
    partitions: list[dict] = []
    records: list[dict] = []
    components: dict[str, tuple[dict, dict, dict[str, bytes]]] = {}
    outputs: dict[str, dict] = {}
    native_sha256 = sha256_bytes(NATIVE_BYTES)
    counter = 0
    for repeat in range(1, 4):
        for inner in range(1, 6):
            evaluation_ids = patient_ids[(inner - 1) * 8 : inner * 8]
            fit_ids = [patient_id for patient_id in patient_ids if patient_id not in evaluation_ids]
            partition = {
                "partition_id": f"R{repeat}K{inner}",
                "repeat": repeat,
                "inner_fold": inner,
                "fit_ids": fit_ids,
                "evaluation_ids": evaluation_ids,
            }
            partitions.append(partition)
            fit_response = _write_response_subset(fields, response_rows, fit_ids, None)[
                "private_bytes"
            ]
            prediction_covariates = (
                "Patient_ID,Center\n"
                + "".join(f"{patient_id},38\n" for patient_id in evaluation_ids)
            ).encode()
            for imputation in range(1, M + 1):
                counter += 1
                relative = (
                    f"components/score/{FAMILY}/"
                    f"R{repeat}_K{inner}_M{imputation:02d}.zip"
                )
                component_path = request_root / relative
                component_path.parent.mkdir(parents=True, exist_ok=True)
                component_path.write_bytes(
                    canonical_json_bytes(
                        {
                            "fixture": counter,
                            "repeat": repeat,
                            "inner_fold": inner,
                            "imputation": imputation,
                        }
                    )
                )
                seed = 900_000 + counter
                task = {
                    "family": FAMILY,
                    "selected_parents": ["AST_ALT", "Age"],
                    "parameters": parameters,
                    "imputation": imputation,
                    "f4_coordinates": {
                        "purpose": "NESTED_FULL_SCORE" if full_score else "O_FIT",
                        "outer_fold": 0 if full_score else 1,
                        "repeat": repeat,
                        "inner_fold": inner,
                        "imputation": imputation,
                    },
                    "registered_model_seed": seed,
                    "family_design_column_count": 2,
                }
                if full_score:
                    seed = f4._f4_model_seed(FAMILY, task["f4_coordinates"])
                    task.update(registered_model_seed=seed, model_seed=None, row_count=len(fit_ids),
                                nested_full_score_source=family_source)
                recipe = {"transform_recipe": {"fixture": True}}
                input_entries = {
                    "task.json": canonical_json_bytes(task),
                    "recipe.json": canonical_json_bytes(recipe),
                    "fit-covariates.csv": b"fixture-fit-covariates\n",
                    "fit-response.csv": fit_response,
                    "prediction-covariates.csv": prediction_covariates,
                }
                curve = [1.0] + [0.6 if imputation <= 10 else 1.0] * 36
                prediction = {
                    "f4_coordinates": task["f4_coordinates"],
                    "patient_ids": evaluation_ids,
                    "centers": ["38"] * len(evaluation_ids),
                    "horizons": list(HORIZONS),
                    "survival": {FAMILY: [curve] * len(evaluation_ids)},
                }
                health = {"fixture": counter}
                record = {
                    "role": "FRESH_SCORE",
                    "path": relative,
                    "sha256": sha256_file(component_path),
                    "family": FAMILY,
                    "repeat": repeat,
                    "inner_fold": inner,
                    "imputation": imputation,
                    "registered_model_seed": seed,
                    "selected_parents_sha256": _sha(task["selected_parents"]),
                    "parameter_sha256": _sha(parameters),
                    "task_sha256": _sha(task),
                    "recipe_sha256": _sha(recipe),
                    "family_design_column_count": 2,
                    "fit_ids_sha256": _sha(fit_ids),
                    "prediction_ids_sha256": _sha(evaluation_ids),
                    "fit_response_sha256": sha256_bytes(fit_response),
                    "development_spec_sha256": _sha(parameters),
                }
                receipt = _sealed(
                    {
                        "component_role": "FRESH_SCORE",
                        "family": FAMILY,
                        "repeat": repeat,
                        "inner_fold": inner,
                        "imputation": imputation,
                        "development_lock_sha256": None,
                        "training_context_sha256": context["identity_sha256"],
                        "task_sha256": record["task_sha256"],
                        "input_sha256": _sha(
                            {
                                name: sha256_bytes(value)
                                for name, value in sorted(input_entries.items())
                            }
                        ),
                        "mice_member_sha256": sha256_bytes(
                            input_entries["fit-covariates.csv"]
                        ),
                        "recipe_sha256": record["recipe_sha256"],
                        "parameter_sha256": record["parameter_sha256"],
                        "training_ids_sha256": record["fit_ids_sha256"],
                        "application_ids_sha256": record["prediction_ids_sha256"],
                        "training_response_sha256": record["fit_response_sha256"],
                        "model_sha256": "5" * 64,
                        "baseline_sha256": "6" * 64,
                        "prediction_sha256": _sha(prediction),
                        "fit_health_sha256": _sha(health),
                        "archive_sha256": native_sha256,
                        "model_fit_count": 1,
                        "engine_threads": 1,
                        "seed": seed,
                    }
                )
                records.append(record)
                components[relative] = (task, recipe, input_entries)
                outputs[relative] = _score_component_evidence(record=record, context=context,
                    partition_id=partition["partition_id"], prediction=prediction, receipt=receipt, fit_health=health,
                    object_audit={"UNFITTED_NUMERICAL_FIXTURE": True, "design_columns": ["AST_ALT", "Age"]})
    request = {
        "training_context": context,
        "score_partitions": partitions,
        "component_records": records,
        "reused_training_scores": [{"selector_evidence_sha256": "e" * 64}],
        "selector_evidence_sha256": "e" * 64,
    }
    if full_score:
        request.update(kind="PADML_NESTED_FULL_SCORE_INPUT_V1", development=development,
                       reused_training_scores=[], selector_development_sha256="e" * 64)
        if science_decision is not None:
            request.update(selection_horizon_months=12, science_decision=science_decision)
    return request, request_root, components, outputs


def stage_result(root: Path, producer_root: Path, execution: dict, native_by_coordinate: dict | None = None) -> Path:
    result_root = root
    for index, record in enumerate(execution["component_evidence_records"]):
        # The producer writes score-evidence/FAMILY/...; the result archive nests
        # that directory under components/.
        evidence_source = (
            producer_root
            / "score-evidence"
            / FAMILY
            / Path(record["path"]).name
        )
        evidence_target = result_root / record["path"]
        evidence_target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(evidence_source, evidence_target)
        native_target = result_root / record["native_archive_path"]
        native_target.parent.mkdir(parents=True, exist_ok=True)
        if native_by_coordinate is None:
            native_target.write_bytes(NATIVE_BYTES)
        else:
            coordinate = index // 100 + 1, index % 100 // 20 + 1, index % 20 + 1
            shutil.copyfile(native_by_coordinate[coordinate], native_target)
    return result_root


def test_fresh_score_rejects_response_changed_after_request_before_reading_curves(tmp_path: Path) -> None:
    request, request_root, _, _ = build_fixture(tmp_path / "producer")
    response = request_root / "training/response.csv"
    response.write_bytes(response.read_bytes().replace(b",50\n", b",49\n"))
    # Empty outputs ensures no altered outcome can be used to read/rank curves.
    with pytest.raises(ContractError, match="NESTED_TRAINING_(RESPONSE|CONTEXT)"):
        _score_fresh_family(family=FAMILY, request=request, root=request_root.parent, outputs={})


@pytest.mark.parametrize("full_score", [False, True])
def test_outer_fixed12_rescores_old_numbers_without_native_or_score_relabel(tmp_path, monkeypatch, full_score):
    from padml import f2_kernel, f4, f5, nested_loco as nested
    request, request_root, components, outputs = build_fixture(tmp_path / "producer", full_score=full_score)
    for record in request["component_records"]:
        record["size_bytes"] = (request_root / record["path"]).stat().st_size
    decision = nested._read_canonical(Path(__file__).resolve().parents[1] / "science-decision.json", "DECISION")
    if not full_score:
        request.update(kind="PADML_F4_O_FIT_INPUT_V1", science_decision={
            "identity_sha256": decision["twelve_month_development"]["original_24_month_decision_sha256"]})
    monkeypatch.setattr(nested, "_read_component", lambda path: components[path.relative_to(request_root).as_posix()])
    monkeypatch.setattr(f2_kernel, "_expected_family_parent_column_map", lambda *_a, **_k: [{"columns": ["AST_ALT", "Age"]}])
    monkeypatch.setattr(f2_kernel, "predictor_contract", lambda *_a, **_k: {})
    monkeypatch.setattr(f5, "_validate_final_r_fit_health", lambda *_a, **_k: None)
    monkeypatch.setattr(f5, "_validate_retained_r_audit_numbers", lambda *_a, **_k: None)
    monkeypatch.setattr(f5, "_score_archive_expanded_limit", lambda *_a, **_k: None)
    def forbidden(*_a, **_k):
        pytest.fail("RESCORING_MUST_NOT_FIT_REPLAY_OR_SELECT")
    for module, names in ((f4, ("_replay_f4_model_component",)),
                          (f5, ("_execute_and_verify_score_archive_job", "_replay_component_job")),
                          (nested, ("_component_execution_receipt", "select_training_family", "seal_development_lock"))):
        for name in names:
            monkeypatch.setattr(module, name, forbidden)
    score, execution = _score_fresh_family(family=FAMILY, request=request, root=request_root.parent, outputs=outputs)
    result_root = stage_result(tmp_path / "result", request_root.parent, execution)
    originals = canonical_json_bytes([request, score, execution])
    arguments = dict(execution=execution, score=score, request=request, request_root=request_root,
                     result_root=result_root, expanded_bytes_per_component=1024**2,
                     retained_bytes_per_component=1024**2, rescore_science_decision=decision)
    values = _recompute_fresh_score_from_evidence(**arguments)
    assert canonical_json_bytes([request, score, execution]) == originals
    new_score, new_execution = values["training_score"], values["fresh_score_execution"]
    assert new_score["selection_horizon_months"] == new_execution["selection_horizon_months"] == 12
    assert new_score["source_result_sha256"] == new_execution["identity_sha256"] != execution["identity_sha256"]
    assert new_score["science_decision_sha256"] == decision["identity_sha256"]
    assert new_execution["pooled_partitions"] == execution["pooled_partitions"]
    assert new_execution["component_evidence_records"] == execution["component_evidence_records"]
    assert len(new_score["metric_values"]) == 300 and len(new_score["ranking_metric_values"]) == 3
    with pytest.raises(ContractError, match="NESTED_OUTER_FIXED_RESCORE_SCOPE_INVALID"):
        _recompute_fresh_score_from_evidence(**{**arguments, "replay_models": True})
    bad_context = _sealed({**{key: value for key, value in score.items() if key != "identity_sha256"},
                           "training_context_sha256": "f" * 64})
    with pytest.raises(ContractError, match="NESTED_OUTER_FIXED_RESCORE_SCOPE_INVALID"):
        _recompute_fresh_score_from_evidence(**{**arguments, "score": bad_context})
    drifted = ({**request, "development": {**request["development"], "identity_sha256": "f" * 64}}
               if full_score else {**request, "science_decision": {"identity_sha256": "f" * 64}})
    with pytest.raises(ContractError):
        _recompute_fresh_score_from_evidence(**{**arguments, "request": drifted})


@pytest.mark.parametrize("outer", range(1, 7))
def test_outer_fixed12_entry_stops_at_numerical_reader(tmp_path, monkeypatch, outer):
    from padml import f4
    calls = []
    def reader(path, **kwargs):
        calls.append((path, kwargs))
        return {"status": "NUMERICAL_READER_ONLY"}
    monkeypatch.setattr(f4, "_load_o_fit_execution_archive", reader)
    def forbidden(*_a, **_k):
        pytest.fail("RESCORING_ENTERED_FIT_OR_POST_LOCK")
    monkeypatch.setattr(f4, "_execute_o_fit_training_bundle", forbidden)
    kwargs = dict(outer_fold=outer, input_bundle=tmp_path / 'input.zip',
                  rescore_fixed12_decision={"fixture": "NO_SCIENCE_EXECUTED"},
                  retained_score_numbers=tmp_path / 'old-numbers.zip', compiled_input_record={"outer_fold": outer},
                  retained_primary_source_bundle=tmp_path / 'old-source.zip')
    result = f4.execute_o_fit_bundle(tmp_path / 'accepted', None, tmp_path / 'new.zip', **kwargs)
    assert result == {"status": "NUMERICAL_READER_ONLY"}
    assert len(calls) == 1 and calls[0][1]["rescore_target"] == tmp_path / 'new.zip'
    with pytest.raises(ContractError, match="F4_O_FIT_FIXED12_RESCORE_SCOPE_INVALID"):
        f4.execute_o_fit_bundle(tmp_path / 'accepted', None, tmp_path / 'new.zip', **kwargs, prepare_final=True)


def test_outer_fixed12_proves_retained_source_without_other_scope(retained_source_bundle):
    from padml.f4 import _retained_full0_source_members
    source = retained_source_bundle
    assert len(_retained_full0_source_members(source, outer_fixed12_rescore=True)) == 49
    with pytest.raises(ContractError, match='F5_RETAINED_AAR_SOURCE_SCOPE_INVALID'):
        _retained_full0_source_members(source, outer_fixed12_rescore=True, aar_primary_context=True)


@pytest.mark.parametrize("mutation", ("count_leaf", "module_rebinding"))
def test_outer_fixed12_rejects_unproved_f5_counter_or_module_scope(monkeypatch, mutation, retained_source_bundle):
    import ast
    from padml import f4
    source = retained_source_bundle
    target = Path(f4.__file__).resolve().parent / 'f5.py'
    original_reader = Path.read_bytes
    raw = original_reader(target)
    if mutation == 'count_leaf':
        lines = raw.splitlines(keepends=True)
        node = next(node for node in ast.parse(raw).body
                    if isinstance(node, ast.FunctionDef) and node.name == '_retained_tree_bytes')
        changed = b''.join(lines[:node.lineno - 1]) + b'def _retained_tree_bytes(root):\n    return 0\n' + b''.join(lines[node.end_lineno:])
        error = 'F4_O_FIT_FIXED12_NUMERICAL_DEPENDENCY_DRIFT'
    else:
        changed = raw + b'\n_retained_tree_bytes = lambda root: 0\n'
        error = 'F4_O_FIT_FIXED12_NUMERICAL_MODULE_SCOPE_DRIFT'
    monkeypatch.setattr(Path, 'read_bytes', lambda path: changed if path == target else original_reader(path))
    with pytest.raises(ContractError, match=error):
        f4._retained_full0_source_members(source, outer_fixed12_rescore=True)


@pytest.mark.parametrize("horizon", [24, 12])
def test_fresh_score_local_replay_rejects_changed_metric(tmp_path: Path, horizon: int) -> None:
    fixture_root = tmp_path
    request, request_root, components, outputs = build_fixture(fixture_root)
    if horizon == 12:
        from padml import nested_loco as nested
        decision = nested._read_canonical(Path(__file__).resolve().parents[1] / "science-decision.json", "DECISION")
        request.update(selection_horizon_months=12, science_decision=decision)

    def fake_read_component(path: Path):
        return components[path.relative_to(request_root).as_posix()]

    def fake_execution_receipt(*, record, **_kwargs):
        pytest.fail("NUMERICAL_REDUCTION_MUST_NOT_REOPEN_NATIVE_ARCHIVE")

    with (
        patch("padml.nested_loco._read_component", fake_read_component),
        patch("padml.nested_loco._component_execution_receipt", fake_execution_receipt),
        patch("padml.f2_kernel._expected_family_parent_column_map", lambda *_a, **_k: [{"columns": ["AST_ALT", "Age"]}]),
        patch("padml.f2_kernel.predictor_contract", lambda *_a, **_k: {}),
        patch("padml.f5._validate_final_r_fit_health", lambda *_a, **_k: None),
        patch("padml.f5._validate_retained_r_audit_numbers", lambda *_a, **_k: None),
    ):
        score, execution = _score_fresh_family(
            family=FAMILY,
            request=request,
            root=fixture_root,
            outputs=outputs,
        )
        exact_root = stage_result(fixture_root / "result-exact", fixture_root, execution)
        replayed = _recompute_fresh_score_from_evidence(
            execution=execution,
            score=score,
            request=request,
            request_root=request_root,
            result_root=exact_root,
            replay_models=False,
        )
        assert replayed == score
        assert len(score["metric_values"]) == 300
        assert len(score["fold_metric_values"]) == 15
        assert len(score["ranking_metric_values"]) == 3
        print(
            "RECOMPUTE_EXACT_OK",
            len(score["metric_values"]),
            len(score["fold_metric_values"]),
            len(score["ranking_metric_values"]),
            score["mean_ibs"],
        )

        changed = {key: value for key, value in score.items() if key != "identity_sha256"}
        changed["metric_values"] = list(changed["metric_values"])
        changed["metric_values"][0] += 1e-6
        changed_score = _sealed(changed)
        changed_root = stage_result(fixture_root / "result-mutated", fixture_root, execution)
        try:
            _recompute_fresh_score_from_evidence(
                execution=execution,
                score=changed_score,
                request=request,
                request_root=request_root,
                result_root=changed_root,
                replay_models=False,
            )
        except ContractError as error:
            assert str(error) == "NESTED_FRESH_SCORE_LOCAL_REPLAY_MISMATCH"
            print("MUTATED_METRIC_REJECTED", error)
        else:
            raise AssertionError("mutated metric_values unexpectedly accepted")
    print("FIXTURE_ROOT", fixture_root)


def test_fresh_score_reopens_actual_archives_and_receipts(tmp_path):
    """Actual 300 input/output ZIP reads; model bytes remain explicit UNFITTED fixtures."""
    request, request_root, components, _ = build_fixture(tmp_path)
    definitions = {(row["repeat"], row["inner_fold"]): row for row in request["score_partitions"]}
    native_root = tmp_path / "actual-native"
    native_root.mkdir()
    outputs, native_by_coordinate = {}, {}

    def covariates(ids):
        fields = load_science_authority()["science"]["mice"]["private_handoff"]["columns"]
        stream = io.StringIO(newline="")
        writer = csv.DictWriter(stream, fieldnames=fields, lineterminator="\n")
        writer.writeheader()
        for patient in ids:
            writer.writerow({**{field: "0" for field in fields}, "Patient_ID": patient, "Center": "38"})
        return stream.getvalue().encode()

    for index, record in enumerate(request["component_records"], 1):
        coordinate = record["repeat"], record["inner_fold"], record["imputation"]
        part = definitions[coordinate[:2]]
        task, _, original = components[record["path"]]
        entries = {**original, "fit-covariates.csv": covariates(part["fit_ids"]),
                   "prediction-covariates.csv": covariates(part["evaluation_ids"])}
        component_path = request_root / record["path"]
        component_path.unlink()  # Replace only this test's explicitly fabricated placeholder.
        _write_component_archive(component_path, entries)
        record["sha256"] = sha256_file(component_path)
        record["size_bytes"] = component_path.stat().st_size
        prediction = {"f4_coordinates": task["f4_coordinates"], "patient_ids": part["evaluation_ids"],
                      "centers": ["38"] * len(part["evaluation_ids"]), "horizons": list(HORIZONS),
                      "survival": {FAMILY: [[1.0] + [0.6 if coordinate[2] <= 10 else 1.0] * 36
                                             for _ in part["evaluation_ids"]]}}
        health = {"UNFITTED_FIXTURE": index}
        native = native_root / f"C{index:03d}.zip"
        write_deterministic_zip(native, {
            **entries, "model.bin": f"UNFITTED model {index}".encode(),
            "baseline.bin": f"UNFITTED baseline {index}".encode(),
            "fit-health.json": canonical_json_bytes(health),
            "training-prediction.json": canonical_json_bytes({"UNFITTED_FIXTURE": index}),
            "prediction.json": canonical_json_bytes(prediction),
        })
        receipt, observed_prediction, observed_health = _component_execution_receipt(
            component_path=component_path, output_root=native.with_suffix(""), record=record,
            context=request["training_context"], development_lock_sha256=None,
        )
        assert observed_prediction == prediction and observed_health == health
        outputs[record["path"]] = _score_component_evidence(record=record, context=request["training_context"],
            partition_id=part["partition_id"], prediction=prediction, receipt=receipt, fit_health=health,
            object_audit={"UNFITTED_NUMERICAL_FIXTURE": True, "design_columns": ["AST_ALT", "Age"]})
        native_by_coordinate[coordinate] = native

    with (
        patch("padml.f2_kernel._expected_family_parent_column_map", lambda *_a, **_k: [{"columns": ["AST_ALT", "Age"]}]),
        patch("padml.f2_kernel.predictor_contract", lambda *_a, **_k: {}),
        patch("padml.f5._validate_final_r_fit_health", lambda *_a, **_k: None),
        patch("padml.f5._validate_retained_r_audit_numbers", lambda *_a, **_k: None),
    ):
        score, execution = _score_fresh_family(family=FAMILY, request=request, root=tmp_path, outputs=outputs)
        result_root = stage_result(tmp_path / "actual-result", tmp_path, execution, native_by_coordinate)
        budgets = {"expanded_bytes_per_component": 1_000_000, "retained_bytes_per_component": 1_000_000}
        for _ in range(2):
            assert _recompute_fresh_score_from_evidence(
                execution=execution, score=score, request=request, request_root=request_root,
                result_root=result_root, replay_models=False, **budgets,
            ) == score
        assert score["mean_ibs"] == pytest.approx(0.03916666666666665)
        tampered_root = stage_result(tmp_path / "actual-tampered", tmp_path, execution, native_by_coordinate)
        first = tampered_root / execution["component_evidence_records"][0]["native_archive_path"]
        first.write_bytes(first.read_bytes() + b"tamper")
        with pytest.raises(ContractError, match="NESTED_SCORE_NATIVE_ARCHIVE_DRIFT"):
            _recompute_fresh_score_from_evidence(
                execution=execution, score=score, request=request, request_root=request_root,
                result_root=tampered_root, replay_models=True, **budgets,
            )
