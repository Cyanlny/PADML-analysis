"""Only the original S3A numerical route and S3B1 boundary; no engine."""
import copy
from pathlib import Path

import pytest

from padml import f2_kernel as kernel, f4, f5
from padml.bundle import ContractError, canonical_json_bytes
from test_primary_outer12_rsf_inputs import _call


@pytest.mark.parametrize("damage", [None, "fit", "missing", "s3b1-seed"])
@pytest.mark.parametrize("publication", [False, True])
def test_s3a_only_consumption_then_original_s3b1_boundary(tmp_path, monkeypatch, damage, publication):
    base = _call(tmp_path, outer=2)
    spec = copy.deepcopy(base[0])
    spec.pop("action")
    spec.update(threads=56, pool_workers=56, engine_threads=1, execution_mode="PROCESS_POOL",
                monthly_fit_horizons=list(range(1, 37)),
                candidate_trials={"S1": [{"FORBIDDEN": True}], "S2": [{"FORBIDDEN": True}]})
    partitions = []
    for repeat in range(1, 4):
        for part in range(1, 6):
            row = copy.deepcopy(base[6])
            row.update(partition_id=f"INNER_F2_R{repeat}_K{part}", repeat=repeat, inner_fold=part)
            partitions.append(row)
    registered = {**base[1], "partitions": partitions, "diagnostic_partitions": []}
    registered.pop("projected_partition_ids"); registered.pop("projected_partition_count")
    q = tmp_path / "q"; q.mkdir()
    (q / "input.json").write_bytes(canonical_json_bytes({"spec": spec}))
    trace = [{"stage_id": "S2", "trial_index": i, "candidate_id": f"TRIAL-{i}",
        "parameters": {"splitrule": "logrank", "UNFITTED": i}, "parameter_sha256": str(i) * 64,
        "evaluation_units": 25, "selection_horizon_months": 12,
        "mean_ibs": i / 100, "maximum_ibs": i / 100} for i in range(1, 9)]
    candidates = kernel._tree_s3a_candidates({"S2": trace})
    report = q / "retained-s2.json"
    history = {"predecessor_execution_sha256": [],
        "original_q_boundary": {"search_trace": {"S2": trace}, "s3a_candidates": candidates,
                                "s1_consumed_history": {"UNFITTED": True}}}
    if publication:
        history = {"predecessor_execution_sha256": [], "s1_consumed_history": {"UNFITTED": True},
                   "search_trace": {"S2": trace}, "s3a_candidates": candidates}
    report.write_bytes(canonical_json_bytes(history))
    phase, _ = f5._a12_q_stop_phase("S3A", refit=True, family="RSF")
    control = {"primary_rsf_s3a_consumption": True, "prepare_only": True, "task_ids": None,
        "completed": {}, "batches": [(q, {"phase": phase, "UNFITTED_HOST": i}) for i in range(7)],
        "used_batches": [], "confirmed_model_fits": 0, "confirmed_stop_fits": 0,
        "prepared_calls": [],
        "primary_rsf_preparation": q / "UNFITTED.zip", "primary_rsf_producer": q / "UNFITTED-source.zip",
        "retained_primary_rsf_q_source_bundle": q / "UNFITTED-ec3a.zip",
        "primary_rsf_s2_evidence": {}, "primary_rsf_s3a_evidence": {
            ("source/primary-compilation.json" if publication else "primary-s3a/report.json"): report}}
    spec.update(native_search_root=str(q / "native"), native_search_batch=control)
    # Real byte/source readers are exercised independently on retained files.
    monkeypatch.setattr(f5, "_primary_rsf_prepared_input", lambda *a, **k: (None, None))
    consumed, summaries = [], []
    def numeric(_, function, units, batches, observed_phase, input_ref):
        assert function is kernel._run_r_prediction_pool_task and observed_phase == phase
        assert len(units) == 100 and all(len(call[2]) == 3 for call, _ in units.values())
        control["confirmed_model_fits"] = 300
        control["used_batches"] = [kernel._sha(row) for _, row in batches]
        result = []
        for call, _ in units.values():
            consumed.extend(row["task_id"] for row in call[2])
            assert all(row["task_id"].startswith("S3A_") for row in call[2])
            result.append([{**{key: row[key] for key in ("task_id", "partition_id", "imputation")},
                            "prediction_seal_sha256": "a" * 64,
                            "evaluation_response_sha256": "b" * 64,
                            "evaluation_ids_sha256": "c" * 64,
                            "ibs_0_12": 0.1, "stopping": None,
                            "sealed_prediction": {"UNFITTED": True}}
                           for row in call[2]])
        return result
    monkeypatch.setattr(f5, "_consume_q_search_batches", numeric)
    monkeypatch.setattr(kernel, "_accumulate_registered_evaluations", lambda *a: None)
    def context(rows, *, selection_horizon_months):
        assert selection_horizon_months == 12 and [r["repeat"] for r in rows] == [3] * 5
        return {}
    monkeypatch.setattr(kernel, "_trial_scoring_context", context)
    def summary(values, context, m):
        assert m == 20 and len(values) == 100
        summaries.append(values)
        return {"evaluation_units": 100, "selection_horizon_months": 12,
                "mean_ibs": len(summaries) / 100, "maximum_ibs": len(summaries) / 100}
    monkeypatch.setattr(kernel, "_trial_evaluation_summary", summary)
    original = f5._q_search_task_batch
    def boundary(value, function, tasks):
        if damage == "s3b1-seed" and tasks[0][2][0]["task_id"].startswith("S3B1_"):
            tasks[0][2][0]["seed"] += 1
        return original(value, function, tasks)
    monkeypatch.setattr(f5, "_q_search_task_batch", boundary)
    monkeypatch.setattr(f5, "_execute_q_search_batch", lambda *a, **k: pytest.fail("FIT_FORBIDDEN"))
    monkeypatch.setattr(kernel, "_shared_full_development_search_result", lambda *a, **k: pytest.fail("FALSE_FULL_TRACE"))
    if damage == "fit": control["prepare_only"] = False
    elif damage == "missing": control["batches"].pop()
    if damage:
        with pytest.raises(ContractError, match=("F5_PRIMARY_RSF_S3B1_PREPARATION_BOUNDARY_INVALID"
                           if damage == "s3b1-seed" else "F5_PRIMARY_RSF_S3A_CONSUMPTION_SCOPE_INVALID")):
            kernel._run_r_registered_rsf(spec, registered, tmp_path, tmp_path, search_only=True)
        if damage != "s3b1-seed": assert not consumed
    else:
        with pytest.raises(f5._QBatchBoundary) as caught:
            kernel._run_r_registered_rsf(spec, registered, tmp_path, tmp_path, search_only=True)
        result = caught.value.result
        assert len(consumed) == len(set(consumed)) == 300 and len(summaries) == 3
        assert result["confirmed_model_fits"] == 620 and result["new_model_fits"] == 0
        assert result["model_coordinate_count"] == 150 and len(result["next_atomic_units"]) == 75
        assert result["worker_inputs_ready"] is False and result["complete_search_trace"] is False
        assert result["s2_consumed_history"]["s1_consumed_history"] == {"UNFITTED": True}
        assert len(control["prepared_calls"]) == 1
        assert control["prepared_calls"][0][0] is kernel._run_r_prediction_pool_task
        assert list(control["prepared_calls"][0][1]) == result["task_ids"]


@pytest.mark.parametrize("damage", [None, "source", "missing-host", "duplicate-host", "fit-count",
                                  "promotion", "seed", "partial-atom", "foreign-fold", "history"])
@pytest.mark.parametrize("retained_source", [False, True])
@pytest.mark.parametrize("publication_s3a", [False, True])
def test_s3b1_only_consumption_then_original_s3b2_boundary(
        tmp_path, monkeypatch, damage, retained_source, publication_s3a):
    """The final PRIMARY numerical consumer prepares, but never fits, S3B2."""
    base = _call(tmp_path, outer=2)
    spec = copy.deepcopy(base[0])
    spec.pop("action")
    spec.update(threads=56, pool_workers=56, engine_threads=1, execution_mode="PROCESS_POOL",
                monthly_fit_horizons=list(range(1, 37)),
                candidate_trials={"S1": [{"FORBIDDEN": True}], "S2": [{"FORBIDDEN": True}]})
    partitions = []
    for repeat in range(1, 4):
        for part in range(1, 6):
            row = copy.deepcopy(base[6])
            row.update(partition_id=f"INNER_F2_R{repeat}_K{part}", repeat=repeat, inner_fold=part)
            partitions.append(row)
    registered = {**base[1], "partitions": partitions, "diagnostic_partitions": []}
    registered.pop("projected_partition_ids"); registered.pop("projected_partition_count")
    q = tmp_path / "q"; q.mkdir()
    (q / "input.json").write_bytes(canonical_json_bytes({"spec": spec}))
    s2_trace = [{"stage_id": "S2", "trial_index": i, "candidate_id": f"TRIAL-{i}",
        "parameters": {"splitrule": "logrank", "UNFITTED": i}, "parameter_sha256": str(i) * 64,
        "evaluation_units": 25, "selection_horizon_months": 12,
        "mean_ibs": i / 100, "maximum_ibs": i / 100} for i in range(1, 9)]
    s3a_candidates = kernel._tree_s3a_candidates({"S2": s2_trace})
    s3a_trace = [{"stage_id": "S3A", "trial_index": i, "candidate_id": row["candidate_id"],
        "parameters": row["parameters"], "parameter_sha256": row["parameter_sha256"],
        "evaluation_units": 100, "selection_horizon_months": 12,
        "mean_ibs": i / 100, "maximum_ibs": i / 100}
        for i, row in enumerate(s3a_candidates, start=1)]
    s3b1_candidates = kernel._rank_trials(s3a_trace, retain=2)[:2]
    report = q / "retained-s3a.json"
    history = {"predecessor_execution_sha256": [],
        "original_q_boundary": {"search_trace": {"S2": s2_trace, "S3A": s3a_trace},
            "s3a_candidates": s3a_candidates, "s3b1_candidates": s3b1_candidates,
            "s2_consumed_history": {"UNFITTED": True}}}
    if publication_s3a:
        # The standard compiler carries the validated boundary at top level;
        # no legacy wrapper may be fabricated before the original consumer.
        history = {**history['original_q_boundary'], 'predecessor_execution_sha256': []}
    report.write_bytes(canonical_json_bytes(history))
    phase, _ = f5._a12_q_stop_phase("S3B1", refit=True, family="RSF")
    control = {"primary_rsf_s3b1_consumption": True, "prepare_only": True, "task_ids": None,
        "completed": {}, "batches": [(q, {"phase": phase, "UNFITTED_HOST": i}) for i in range(7)],
        "used_batches": [], "confirmed_model_fits": 0, "confirmed_stop_fits": 0,
        "prepared_calls": [],
        "primary_rsf_preparation": q / "UNFITTED.zip", "primary_rsf_producer": q / "UNFITTED-source.zip",
        "retained_primary_rsf_q_source_bundle": q / "UNFITTED-ec3a.zip",
        "primary_rsf_s2_evidence": {}, "primary_rsf_s3a_evidence": {},
        "primary_rsf_s3b1_evidence": {"primary-s3b1/report.json": report}}
    spec.update(native_search_root=str(q / "native"), native_search_batch=control)
    monkeypatch.setattr(f5, "_primary_rsf_prepared_input", lambda *a, **k: (None, None))
    consumed, summaries = [], []
    def numeric(_, function, units, batches, observed_phase, input_ref):
        assert function is kernel._run_r_prediction_pool_task and observed_phase == phase
        assert len(units) == 75 and all(len(call[2]) == 2 for call, _ in units.values())
        control["confirmed_model_fits"] = 150
        control["used_batches"] = [kernel._sha(row) for _, row in batches]
        result = []
        for call, _ in units.values():
            consumed.extend(row["task_id"] for row in call[2])
            result.append([{**{key: row[key] for key in ("task_id", "partition_id", "imputation")},
                            "prediction_seal_sha256": "a" * 64,
                            "evaluation_response_sha256": "b" * 64,
                            "evaluation_ids_sha256": "c" * 64,
                            "ibs_0_12": 0.1, "stopping": None,
                            "sealed_prediction": {"UNFITTED": True}}
                           for row in call[2]])
        return result
    monkeypatch.setattr(f5, "_consume_q_search_batches", numeric)
    monkeypatch.setattr(kernel, "_accumulate_registered_evaluations", lambda *a: None)
    monkeypatch.setattr(kernel, "_trial_scoring_context", lambda *a, **k: {})
    def summary(values, context, m):
        assert m == 5 and len(values) == 75
        summaries.append(values)
        return {"evaluation_units": 75, "selection_horizon_months": 12,
                "mean_ibs": len(summaries) / 100, "maximum_ibs": len(summaries) / 100}
    monkeypatch.setattr(kernel, "_trial_evaluation_summary", summary)
    monkeypatch.setattr(f5, "_execute_q_search_batch", lambda *a, **k: pytest.fail("FIT_FORBIDDEN"))
    monkeypatch.setattr(kernel, "_shared_full_development_search_result", lambda *a, **k: pytest.fail("FALSE_FULL_TRACE"))
    with pytest.raises(f5._QBatchBoundary) as caught:
        kernel._run_r_registered_rsf(spec, registered, tmp_path, tmp_path, search_only=True)
    result = caught.value.result
    assert len(consumed) == len(set(consumed)) == 150 and len(summaries) == 2
    assert result["confirmed_model_fits"] == 770 and result["new_model_fits"] == 0
    assert result["model_coordinate_count"] == 300 and len(result["next_atomic_units"]) == 75
    assert all(len(atom["producer_tasks"]) == 4 for atom in result["next_atomic_units"])
    assert list(result["search_trace"]) == ["S2", "S3A", "S3B1"]
    assert result["worker_inputs_ready"] is False and result["complete_search_trace"] is False
    assert len(control["prepared_calls"]) == 1
    assert control["prepared_calls"][0][0] is kernel._run_r_prediction_pool_task
    assert list(control["prepared_calls"][0][1]) == result["task_ids"]

    # Only the earlier historical reader/numerical leaf was replaced above.
    # Exercise the actual new source loader and S3B2 continuation validator.
    source_zip = tmp_path / "current-source.zip"
    f4.compile_f45_source_bundle(source_zip)
    members = f4._f45_source_member_sha256()
    source_proofs = []
    if retained_source:
        # Source-proof leaf only: the original report/coordinate consumer below
        # must retain the producer identity, not substitute the current executor.
        monkeypatch.setattr(f4, "_f45_source_member_sha256", lambda: {**members, "padml/f5.py": "e" * 64})
        def retained_proof(path, **flags):
            assert path == source_zip and flags == {"primary_rsf_inputs": True}
            source_proofs.append(path)
            return {} if damage == "source" else members
        monkeypatch.setattr(f4, "_retained_full0_source_members", retained_proof)
    hosts = ("H0", "H1", "H4", "H5", "H6", "H7", "H9-2")
    evidence = {"source/primary-s3b2-producer.zip": source_zip}
    old_phase, old_ids = f5._a12_q_stop_phase("S3B1", refit=True, family="RSF")
    previous_tasks = {name: [{}, {}] for name in old_ids}
    raw_input = (q / "input.json").read_bytes()
    received = []
    for index, host in enumerate(hosts):
        ids = old_ids[index::7]
        execution = {"source_identity": "d57c7267da53918822b63c2e955cf00f5d1bcfbea0f46f8af6054710e8512f72",
            "input": {"sha256": f5.sha256_bytes(raw_input), "size_bytes": len(raw_input)},
            "phase": old_phase, "task_ids": ids,
            "pool": {"status": "COMPLETED", "completed_task_count": len(ids)},
            "units": [{"task_id": name} for name in ids],
            "new_model_fit_count": 2 * len(ids), "confirmed_first_native_audit_count": 2 * len(ids)}
        path = q / f"{host}-execution.json"
        path.write_bytes(canonical_json_bytes(execution))
        evidence[f"primary-s3b2/{host}-execution.json"] = path
        received.append({"host": host, "execution_sha256": f5.sha256_file(path)})
    predecessors = [row["execution_sha256"] for row in received]
    result["predecessor_execution_sha256"] = predecessors
    s2 = {"primary-s2/report.json": q / "s1-history.json"}
    s3a = {("source/primary-compilation.json" if publication_s3a else
            "primary-s3a/report.json"): q / "s2-history.json"}
    for path in (*s2.values(), *s3a.values()):
        path.write_bytes(canonical_json_bytes({"SYNTHETIC": path.name}))
    complete = {"status": "ORIGINAL_PRIMARY12_S3B1_CONSUMED_S3B2_PREPARED",
        "source_identity": f5.sha256_bytes(canonical_json_bytes(members)),
        "retained_q_source_identity": "d57c7267da53918822b63c2e955cf00f5d1bcfbea0f46f8af6054710e8512f72",
        "outer_fold": 2, "selection_horizon_months": 12,
        "original_source_identity": spec["primary_search_source"]["producer_source_identity"],
        "original_q_input_sha256": f5.sha256_bytes(raw_input),
        "registered_identity": spec["registered_inputs_identity_sha256"],
        "retained_s1_consumer_sha256": f5.sha256_file(s2["primary-s2/report.json"]),
        "retained_s2_consumer_sha256": f5.sha256_file(next(iter(s3a.values()))),
        "retained_s3a_consumer_sha256": f5.sha256_file(report),
        "original_s3b1_numerical_consumer_calls": 1, "consumed_s3b1_model_coordinates": 150,
        "consumed_s3b1_atomic_units": 75, "model_coordinate_count": 300, "original_atomic_units": 75,
        "worker_inputs_ready": False, "received": received, "predecessor_execution_sha256": predecessors,
        "original_q_boundary": result,
        **{key: 0 for key in ("original_s1_numerical_consumer_calls", "original_s2_numerical_consumer_calls",
            "original_s3a_numerical_consumer_calls", "new_model_fits", "new_stop_fits", "new_mice_chains",
            "new_elastic_paths", "new_glmnet_calls", "new_native_audits", "native_replays",
            "mice_archives_reopened", "csv_write_count", "candidate_rng_calls")}}
    if damage == "source":
        monkeypatch.setattr(f4, "_f45_source_member_sha256", lambda: {**members, "padml/f5.py": "f" * 64})
    elif damage == "missing-host":
        evidence.pop("primary-s3b2/H7-execution.json")
    elif damage == "duplicate-host":
        complete["received"][-1] = complete["received"][0]
    elif damage == "fit-count":
        complete["new_model_fits"] = True
    elif damage == "promotion":
        result["s3b2_candidate"] = result["search_trace"]["S3B1"][1]
    elif damage == "seed":
        result["next_atomic_units"][0]["producer_tasks"][0]["seed"] += 1
    elif damage == "partial-atom":
        result["next_atomic_units"][0]["producer_tasks"].pop()
    elif damage == "foreign-fold":
        complete["outer_fold"] = 5
    elif damage == "history":
        complete["retained_s3a_consumer_sha256"] = "f" * 64
    closed = q / "s3b1-closed.json"
    closed.write_bytes(canonical_json_bytes(complete))
    evidence["primary-s3b2/report.json"] = closed
    args = (raw_input, f5.strict_json_bytes(report.read_bytes()), previous_tasks)
    kwargs = dict(s2_evidence=s2, s3a_evidence=s3a,
                  s3b1_evidence=control["primary_rsf_s3b1_evidence"], evidence=evidence)
    if damage:
        reason = ("F5_RETAINED_PRIMARY_RSF_INPUT_SOURCE_DRIFT" if damage == "source" and not retained_source
                  else "F5_PRIMARY_RSF_S3B2_PREPARED_SOURCE_INVALID")
        with pytest.raises(ContractError, match=reason):
            f5._primary_rsf_s3b2_prepared_tasks(*args, **kwargs)
    else:
        prepared = f5._primary_rsf_s3b2_prepared_tasks(*args, **kwargs)
        assert list(prepared) == f5._a12_q_stop_phase("S3B2", refit=True, family="RSF")[1]
        assert prepared == {row["task_id"]: row["producer_tasks"] for row in result["next_atomic_units"]}
        assert len(prepared) == 75 and sum(map(len, prepared.values())) == 300
    if retained_source:
        assert source_proofs == ([] if damage == "missing-host" else [source_zip])


@pytest.mark.parametrize("source_role,accepted", [
    ("current", True),
    ("d57c7267da53918822b63c2e955cf00f5d1bcfbea0f46f8af6054710e8512f72", True),
    ("9ce61d9f806693255d92f20f264bb96653cf8d147eab7436a3d7f9842deab71a", True),
    ("f" * 64, False),
])
@pytest.mark.parametrize("stage", ["S3A", "S3B1"])
def test_real_s3b1_consumer_gate_binds_all_closed_histories_before_numbers(
        tmp_path, monkeypatch, source_role, accepted, stage):
    """Only source/stage admission; not proof of actual historical numerical reads."""
    root = tmp_path / "q"
    root.mkdir()
    (root / "input.json").write_bytes(b"{}")
    phase, ids = f5._a12_q_stop_phase(stage, refit=True, family="RSF")
    control = {
        "prepare_only": True,
        "task_ids": None,
        "completed": False,
        "resource_policy": {},
        "retained_primary_rsf_q_source_bundle": tmp_path / "retained.zip",
        "primary_rsf_" + stage.lower() + "_consumption": True,
        "primary_rsf_s2_evidence": {"s2": tmp_path / "s2"},
        "primary_rsf_s3a_evidence": {"s3a": tmp_path / "s3a"},
        "primary_rsf_s3b1_evidence": {"s3b1": tmp_path / "s3b1"},
        "primary_rsf_preparation": tmp_path / "preparation.zip",
        "primary_rsf_producer": tmp_path / "producer.zip",
    }
    spec = {"family": "RSF", "native_search_root": str(root / "native"),
            "native_search_batch": control}
    units = {name: ((None, None, [], None, None, "IBS", None), None) for name in ids}
    original_hash = f5.sha256_bytes
    retained_members = {} if source_role == "current" else {"retained": "a" * 64}
    retained_raw = canonical_json_bytes(retained_members)
    source_identity = (original_hash(retained_raw) if source_role == "current" else source_role)
    # This gate checks filesystem presence and exact used-executor coverage
    # before the mocked source-proof leaf; keep that real boundary in scope.
    control["retained_primary_rsf_q_source_bundle"].write_bytes(b"UNFITTED_SOURCE_FIXTURE")
    batches = [(root, {"source_identity": source_identity})]
    monkeypatch.setattr(f4, "_primary_rsf_search_source", lambda value: {"PRIMARY": value["family"]})
    monkeypatch.setattr(f4, "load_f45_source_bundle", lambda path: {
        "members": [{"path": name, "sha256": digest} for name, digest in retained_members.items()]})
    monkeypatch.setattr(f4, "_f45_source_member_sha256", lambda: {})
    monkeypatch.setattr(f4, "_retained_full0_source_members", lambda *args, **kwargs: retained_members)
    monkeypatch.setattr(f5, "sha256_bytes", lambda raw: source_identity if raw == retained_raw else original_hash(raw))
    seen = {}

    class ClosedHistoryReached(Exception):
        pass

    def prepared(*args, **kwargs):
        seen.update(kwargs)
        raise ClosedHistoryReached

    monkeypatch.setattr(f5, "_primary_rsf_prepared_input", prepared)
    if stage == "S3A" and source_role == "d57c7267da53918822b63c2e955cf00f5d1bcfbea0f46f8af6054710e8512f72":
        accepted = False  # Its existing S3B1 role does not authorize an S3A producer.
    if accepted:
        with pytest.raises(ClosedHistoryReached):
            f5._consume_q_search_batches(spec, kernel._run_r_prediction_pool_task, units, batches, phase,
                                         {"sha256": "a" * 64, "size_bytes": 2})
        assert seen == {"s2_evidence": control["primary_rsf_s2_evidence"],
                        "s3a_evidence": control["primary_rsf_s3a_evidence"],
                        **({"s3b1_evidence": control["primary_rsf_s3b1_evidence"]} if stage == "S3B1" else {})}
    else:
        with pytest.raises(ContractError, match="F5_PRIMARY_RSF_NUMERICAL_SOURCE_INVALID"):
            f5._consume_q_search_batches(spec, kernel._run_r_prediction_pool_task, units, batches, phase,
                                         {"sha256": "a" * 64, "size_bytes": 2})
        assert not seen
