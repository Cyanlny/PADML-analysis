"""Real code-only producers through the original scoped source consumer."""
import os
from pathlib import Path
from zipfile import ZipFile

import pytest

from padml import f4
from padml.bundle import ContractError, canonical_json_bytes, sha256_bytes


@pytest.fixture
def coxtwo(tmp_path):
    old = os.environ.get("PADML_COX24_SCORE_SOURCE")
    prepared = os.environ.get("PADML_COX12_PREPARED_EVIDENCE")
    if old is None or prepared is None:
        pytest.skip("Exact original COX code-only sources are required")
    with ZipFile(prepared) as packet:
        raw = packet.read("source.zip")  # No numerical/clinical member read.
    assert len(raw) == 1031361
    assert sha256_bytes(raw) == "db9200ac5ea94ddc055832a2bc7f376083e6e1f007c9f5d6612b192d8bc915f9"
    path = tmp_path / "d511-source.zip"
    path.write_bytes(raw)
    return Path(old), path


def test_real_cox_producers_remain_distinct_and_other_scopes_are_not_granted(coxtwo, tmp_path):
    current = f4._f45_source_member_sha256()
    for path, identity in zip(coxtwo, (
        "add079ae25498023cac1054a44c3a41444a51b0cf72dc8b5ed5ae3bc8648ac43",
        "d511d23894ef9d1a69da1adeb8328ad4c72944f5c42e95d8ede7465d151992e3"), strict=True):
        result = f4._retained_full0_source_members(path, full0_cox_score_reuse=True)
        assert sha256_bytes(canonical_json_bytes(result)) == identity
        assert result != current and f4._f45_source_member_sha256() == current
        with pytest.raises(ContractError, match="SOURCE_SCOPE_INVALID"):
            f4._retained_full0_source_members(path, full0_cox_score_reuse=True, full0_preparation=True)
    unknown = tmp_path / "current.zip"
    f4.compile_f45_source_bundle(unknown)
    with pytest.raises(ContractError, match="FULL0_COX_SCORE_SOURCE_DRIFT"):
        f4._retained_full0_source_members(unknown, full0_cox_score_reuse=True)


@pytest.mark.parametrize("module,old,new", [
    ("padml/f2_kernel.py", b"def _r_prediction_task_batches(", b"def _wrong_atom_geometry("),
    ("padml/f2_kernel.py", b"def _run_r_prediction_batch(", b"def _wrong_r_batch_entry("),
    ("padml/f2_kernel.py", b"def _search_python_stop_batch(", b"def _wrong_stop_entry("),
    ("padml/f2_kernel.py", b"def _evaluate_prediction_seal(", b"def _wrong_evaluate_prediction_seal("),
    ("padml/f5.py", b"def _validate_retained_r_audit_numbers(", b"def _wrong_retained_r_audit_numbers("),
    ("padml/nested_loco.py", b"def _validate_fresh_score_component_numbers(", b"def _wrong_score_component_numbers("),
    ("padml/f4.py", b"def _f4_model_seed(", b"def _wrong_f4_model_seed("),
    ("padml/f2_kernel.py", b"", b"\n_pool_prediction_batch = None\n"),
    ("padml/kernels/f5_final_refit.R", b"", b"\n# CHANGED_UNPROVED_KERNEL\n"),
])
def test_current_scientific_drift_and_rebinding_rejected(coxtwo, monkeypatch, module, old, new):
    base = Path(f4.__file__).resolve().parent.parent
    target = base / module
    read_bytes = Path.read_bytes
    original = read_bytes(target)
    assert not old or original.count(old) == 1
    changed = original.replace(old, new, 1) if old else original + new
    current = f4._f45_source_member_sha256()
    monkeypatch.setattr(Path, "read_bytes", lambda path: changed if path == target else read_bytes(path))
    monkeypatch.setattr(f4, "_f45_source_member_sha256", lambda: {**current, module: sha256_bytes(changed)})
    with pytest.raises(ContractError, match="FULL0_COX_SCORE_SOURCE_DRIFT"):
        f4._retained_full0_source_members(coxtwo[0], full0_cox_score_reuse=True)
