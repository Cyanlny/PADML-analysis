"""Non-numerical forwarding tests for the original FULL0 execution entry."""
from contextlib import contextmanager
from pathlib import Path

import pytest

from padml import f5, runtime
from padml.bundle import canonical_json_bytes
from padml.run import HOSTS


def test_full0_owner_cli_keeps_context_locators_not_manual_phase_coordinates(tmp_path, monkeypatch, capsys):
    import sys
    document = {"q": {name: {"target": str(tmp_path / (name + ".zip")), "batch_roots": [],
        "continuous_batch_root": str(tmp_path / (name + "-suffix")), "retained_bytes_per_task": 1024,
        "producer_source_bundle": None} for name in ("RSF", "GBM_COX", "XGBOOST_COX", "COXTIME_SET_A")},
        **{name: str(tmp_path / name) for name in (
            "final_input_root", "final_result_root", "non_ph_result", "aggregate_target")}}
    path = tmp_path / "context.json"
    path.write_bytes(canonical_json_bytes(document))
    observed = []
    monkeypatch.setattr(f5, "execute_full_data_locked_scores", lambda *a, **kw: observed.append(kw) or {})
    monkeypatch.setattr(sys, "argv", ["padml-f5", "full-score", str(tmp_path / "full-development.json"),
        "--full0-execution-context", str(path)])
    f5.main()
    actual = observed[0]["full0_execution_context"]
    assert actual["final_input_root"] == tmp_path / "final_input_root"
    assert actual["q"]["GBM_COX"]["target"] == tmp_path / "GBM_COX.zip"
    assert all("task_ids" not in row and "phase_task_ids" not in row for row in actual["q"].values())


@pytest.mark.parametrize("invalid", [None, "horizon", "family", "executor", "retention", "unknown_role"])
def test_full0_rsf24_numbers_cli_is_evidence_only(tmp_path, monkeypatch, invalid):
    import sys
    evidence = {role: str(tmp_path / role) for role in (
        "prepared", "tail", "producer_source", "restoration_source", "last_four_source")}
    family = "GBM_COX" if invalid == "family" else "RSF"
    row = {"target": str(tmp_path / "q.zip"), "batch_roots": [],
        "continuous_batch_root": str(tmp_path / "executor") if invalid == "executor" else None,
        "retained_bytes_per_task": 1024 if invalid == "retention" else None, "producer_source_bundle": None,
        "full0_rsf24_numbers_only": evidence}
    if invalid == "unknown_role":
        evidence["accepted_prefix"] = str(tmp_path / "not-authority")
    document = {"q": {family: row}, **{name: str(tmp_path / name) for name in (
        "final_input_root", "final_result_root", "non_ph_result", "aggregate_target")}}
    path = tmp_path / "context.json"
    path.write_bytes(canonical_json_bytes(document))
    observed = []
    monkeypatch.setattr(f5, "execute_full_data_locked_scores", lambda *a, **kw: observed.append(kw) or {})
    monkeypatch.setattr(sys, "argv", ["padml-f5", "full-score", str(tmp_path / "full-development.json"),
        "--full0-execution-context", str(path), "--selection-horizon-months", "12" if invalid == "horizon" else "24"])
    if invalid is not None:
        with pytest.raises(f5.ContractError, match="NESTED_FULL0_EXECUTION_CONTEXT_INVALID"):
            f5.main()
        assert observed == []
    else:
        f5.main()
        actual = observed[0]["full0_execution_context"]["q"]["RSF"]
        assert actual["full0_rsf24_numbers_only"] == {role: Path(path) for role, path in evidence.items()}
        assert actual["continuous_batch_root"] is None and actual["producer_source_bundle"] is None


@pytest.mark.parametrize("invalid", [None, "executor", "producer", "retention", "missing_role", "symlink", "file_as_directory"])
def test_full0_rsf24_owner_forwards_once_without_model_executor(tmp_path, monkeypatch, invalid):
    source = tmp_path / "full-development.json"
    sources = {"plan": {}, "resource_policy": {"memory_reserve_bytes": 0},
        "selector_root": str(tmp_path / "selector"), "rscript": "UNFITTED", "search_roots": {}}
    context = {"q": {}, **{name: tmp_path / name for name in (
        "final_input_root", "final_result_root", "non_ph_result", "aggregate_target")}}
    for family in ("RSF", "GBM_COX", "XGBOOST_COX", "COXTIME_SET_A"):
        root = tmp_path / family
        root.mkdir()
        sources["search_roots"][family] = str(root)
        if family != "RSF":
            for name in ("result.json", "numbers.json", "execution.json"):
                (root / name).write_bytes(b"UNFITTED")
        context["q"][family] = {"target": tmp_path / (family + ".zip"), "batch_roots": [],
            "continuous_batch_root": None, "retained_bytes_per_task": 1024, "producer_source_bundle": None}
    evidence = {role: tmp_path / role for role in (
        "prepared", "tail", "producer_source", "restoration_source", "last_four_source")}
    for role, path in evidence.items():
        if role in {"prepared", "tail"}:
            path.mkdir()
        else:
            path.write_bytes(b"UNFITTED_SOURCE_READER_NOT_REPLACED_BY_THIS_FORWARDING_TEST")
    context["q"]["RSF"]["full0_rsf24_numbers_only"] = evidence
    context["q"]["RSF"]["retained_bytes_per_task"] = None
    if invalid == "executor":
        context["q"]["RSF"]["continuous_batch_root"] = tmp_path
    elif invalid == "producer":
        context["q"]["RSF"]["producer_source_bundle"] = evidence["producer_source"]
    elif invalid == "retention":
        context["q"]["RSF"]["retained_bytes_per_task"] = 1024
    elif invalid == "missing_role":
        evidence.pop("last_four_source")
    elif invalid == "symlink":
        alias = tmp_path / "source-alias"
        alias.symlink_to(evidence["producer_source"])
        evidence["producer_source"] = alias
    elif invalid == "file_as_directory":
        evidence["tail"] = evidence["restoration_source"]
    monkeypatch.setattr(f5, "_read_final_lineage", lambda *a, **kw: sources)
    @contextmanager
    def materialize(*a, **kw):
        yield sources, [], {}
    monkeypatch.setattr(f5, "_materialized_full_data_development_sources", materialize)
    monkeypatch.setattr(f5, "_nested_full_selector_program", lambda *a, **kw: None)
    class AtOriginalQ(Exception):
        pass
    observed = []
    def consume(**kw):
        observed.append(kw)
        raise AtOriginalQ
    monkeypatch.setattr(f5, "execute_final_complex_search", consume)
    if invalid is not None:
        with pytest.raises(f5.ContractError, match="NESTED_FULL0_EXECUTION_CONTEXT_INVALID"):
            f5.execute_full_data_locked_scores(source, full0_execution_context=context,
                retained_full0_source_bundle=evidence["producer_source"])
        assert observed == []
        return
    with pytest.raises(AtOriginalQ):
        f5.execute_full_data_locked_scores(source, full0_execution_context=context,
            retained_full0_source_bundle=evidence["producer_source"])
    assert len(observed) == 1
    assert observed[0]["full0_rsf24_numbers_only"] == evidence
    assert observed[0]["continuous_batch_root"] is None
    assert observed[0]["retained_bytes_per_task"] is None
    assert "full0_continuous_phase_task_ids" not in observed[0]
    assert "task_ids" not in observed[0] and "batch_root" not in observed[0]


@pytest.mark.parametrize("horizon", [12, 24])
@pytest.mark.parametrize("pending_q", [False, True])
def test_full0_original_entry_owns_seven_scores_and_unchanged_six_final_groups(tmp_path, monkeypatch, horizon, pending_q):
    source = tmp_path / "full-development.json"
    score_root = tmp_path / "score"
    sources = {"plan": {}, "science_decision": {}, "rscript": "UNFITTED", "selector_root": str(tmp_path / "selector"),
        "score_root": str(score_root), "search_roots": {}, "response_path": str(tmp_path / "response.csv"),
        "resource_policy": {"memory_reserve_bytes": 0}, "retained_bytes_per_component": 1,
        "expanded_bytes_per_component": 1, "shared_storage_bytes": 1024**2}
    context = {"q": {}, "final_input_root": tmp_path / "final-input", "final_result_root": tmp_path / "final-results",
        "non_ph_result": tmp_path / "non-ph.zip", "aggregate_target": tmp_path / "aggregate.zip"}
    for name in ("RSF", "GBM_COX", "XGBOOST_COX", "COXTIME_SET_A"):
        root = tmp_path / name
        root.mkdir()
        for member in ("result.json", "numbers.json", "execution.json"):
            (root / member).write_bytes(b"UNFITTED_ORIGINAL_CONSUMER_VALIDATES")
        sources["search_roots"][name] = str(root)
        context["q"][name] = {"target": None, "batch_roots": [], "continuous_batch_root": None,
            "retained_bytes_per_task": None, "producer_source_bundle": None}
    source.write_bytes(canonical_json_bytes(sources))
    monkeypatch.setattr(f5, "_read_final_lineage", lambda *a, **kw: sources)
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda root: {})
    monkeypatch.setattr(runtime, "resource_admission", lambda *a, **kw: {})
    @contextmanager
    def materialize(*a, **kw):
        yield sources, [], {}
    monkeypatch.setattr(f5, "_materialized_full_data_development_sources", materialize)
    events = []
    monkeypatch.setattr(f5, "_nested_full_selector_program", lambda *a, **kw: events.append(("selector", kw)))
    q_calls = []
    if pending_q:
        root = Path(sources["search_roots"]["GBM_COX"])
        for member in ("result.json", "numbers.json", "execution.json"):
            (root / member).unlink()
        batches, suffix = tmp_path / "q-batches", tmp_path / "q-suffix"
        batches.mkdir()
        suffix.mkdir()
        phase, ids = f5._a12_q_stop_phase("S3A", family="GBM_COX")
        batch = batches / "retained-prefix"
        batch.mkdir()
        (batch / "execution.json").write_bytes(canonical_json_bytes({"phase": phase, "task_ids": ids}))
        (batches / "published-input.zip").write_bytes(b"UNFITTED_PUBLICATION_NOT_A_BATCH")
        context["q"]["GBM_COX"] = {"target": tmp_path / "q.zip", "batch_roots": [batch] if horizon == 24 else [batches],
            "continuous_batch_root": suffix, "retained_bytes_per_task": 1024,
            "producer_source_bundle": tmp_path / "common-q-source.zip" if horizon == 12 else None}
        def control(root, policy, options, **kw):
            assert options["q_batches"] == [batch] and "full0_continuous_phase_task_ids" not in kw
            return {"batches": [(batch, {"phase": phase, "task_ids": ids})]}
        monkeypatch.setattr(f5, "_q_search_batch_control", control)
    def search(**kw):
        assert pending_q and kw["candidate_family"] == "GBM_COX"
        if horizon == 12:
            assert kw["full0_continuous_phase_task_ids"] == {}
        q_calls.append(kw)
        return {"UNFITTED_Q": True}
    monkeypatch.setattr(f5, "execute_final_complex_search", search)
    owner = f5.execute_full_data_locked_scores
    common_root = score_root.with_name("score.all")
    def scores(path, **kw):
        assert path == source
        events.append(("score", kw))
        if kw.get("prepare_only"):
            common_root.mkdir()
            (common_root / "request").mkdir()
        return {"UNFITTED_SCORES": True}
    monkeypatch.setattr(f5, "execute_full_data_locked_scores", scores)
    def inputs(*a, family, **kw):
        assert kw["resume"] is True and kw["selection_horizon_months"] == 12
        return {"component_records": [{"path": f"components/score/{family}/M{n}.zip"} for n in range(300)],
            "identity_sha256": "a" * 64}
    monkeypatch.setattr(f5, "_compile_full_score_inputs", inputs)
    compiled = {"status": "COMPILED_NOT_EXECUTED", "UNFITTED_ORIGINAL_RETURN": True}
    shards = [{"host": host, "imputations": list(range(i + 1, 21, len(HOSTS)))} for i, host in enumerate(HOSTS)]
    def compile_final(**kw):
        events.append(("compile", kw))
        root = kw["target_root"]
        root.mkdir()
        (root / "dispatch-index.json").write_bytes(canonical_json_bytes({"host_parallelism": len(HOSTS), "host_shards": shards}))
        return compiled
    monkeypatch.setattr(f5, "compile_final_refit_bundles", compile_final)
    def refit(inputs, outputs, **kw):
        assert kw["compiled_input_record"] is compiled
        assert kw["parameter_source_path"] == source
        assert kw["selection_horizon_months"] == horizon
        events.append(("refit", kw))
        return {"imputations": kw["imputations"]}
    monkeypatch.setattr(f5, "execute_final_refit_batch", refit)
    def nonph(*args, **kw):
        assert kw["compiled_input_record"] is compiled
        events.append(("nonph", kw))
        args[3].write_bytes(b"UNFITTED_NONPH")
    monkeypatch.setattr(f5, "execute_non_ph_action", nonph)
    def aggregate(*args, **kw):
        assert kw["compiled_input_record"] is compiled and kw["replay"] is False
        assert args[3] == context["non_ph_result"]
        events.append(("aggregate", kw))
        return {"stage_acceptance": False}
    monkeypatch.setattr(f5, "execute_final_aggregate", aggregate)
    options = {}
    if horizon == 12:
        retained = tmp_path / "retained-scores"
        (retained / "request").mkdir(parents=True)
        (retained / "score-batches").mkdir()
        for name in ("COX_PH", "ELASTIC_NET_COX", "FPM_TVC_SET_A"):
            ids = [f"components/score/{name}/M{n}.zip" for n in range(300)]
            (retained / "request" / f"full-score-input.{name}.json").write_bytes(
                canonical_json_bytes({"component_records": [{"path": value} for value in ids]}))
            root = retained / "score-batches" / name
            root.mkdir()
            (root / "execution.json").write_bytes(canonical_json_bytes({"task_ids": ids}))
        options = {"retained_full0_source_bundle": tmp_path / "mice-source.zip",
            "retained_q_archive": tmp_path / "rsf-q.zip", "retained_q_producer_source_bundle": tmp_path / "rsf-source.zip",
            "retained_score_root": retained, "retained_score_producer_source_bundle": tmp_path / "score-source.zip",
            "prepared_score_source_bundle": tmp_path / "current-source.zip"}
    if pending_q and horizon == 12:
        partial = batches / "partly-started"
        partial.mkdir()
        (partial / "stdout.txt").write_bytes(b"UNFITTED_INFLIGHT_NO_RECEIPT")
        with pytest.raises(f5.ContractError, match="NESTED_FULL0_EXECUTION_CONTEXT_INVALID"):
            owner(source, selection_horizon_months=horizon, full0_execution_context=context, **options)
        assert not q_calls and not context["final_input_root"].exists()
        partial.rename(tmp_path / "retained-inflight-evidence")
    result = owner(source, selection_horizon_months=horizon, full0_execution_context=context, **options)
    assert result["compiled_input_record"] is compiled and result["stage_acceptance"] is False
    assert len(q_calls) == int(pending_q)
    assert [kw["imputations"] for stage, kw in events if stage == "refit"] == [row["imputations"] for row in shards]
    assert [stage for stage, _ in events][-8:] == ["refit"] * 6 + ["nonph", "aggregate"]
    assert context["final_input_root"].with_name("final-input.compile-record.json").read_bytes() == canonical_json_bytes(compiled)
    if horizon == 12:
        scored = [kw for stage, kw in events if stage == "score"]
        assert [kw["family"] for kw in scored if "family" in kw] == [
            "COX_PH", "ELASTIC_NET_COX", "FPM_TVC_SET_A", "RSF", "GBM_COX", "XGBOOST_COX", "COXTIME_SET_A"]
        for kw in scored:
            if kw.get("family") in f5._STOP_CONSUMERS:
                assert len(kw["task_ids"]) == 300 and kw["score_batches"] == []
                assert kw["continuous_request_sha256"] == "a" * 64
        assert scored[-1]["prepared_score_root"] == common_root
