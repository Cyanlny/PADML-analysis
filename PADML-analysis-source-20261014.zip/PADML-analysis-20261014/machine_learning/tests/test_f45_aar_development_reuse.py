"""UNFITTED C boundaries: original recipe/path consumers and whole provenance.

Whole completion metadata and unrelated M20 models are synthetic fixtures.
The tests prove engineering reuse only, never a clinical AAR or future lock.
"""
import copy
import io
import shutil
import zipfile
from pathlib import Path
from types import SimpleNamespace

import pytest

from padml import f4, f5, f2_kernel as kernel, f5_sensitivity as a, nested_loco as n
from padml.bundle import ContractError, canonical_json_bytes as encode, sha256_bytes, sha256_file, strict_json_bytes, write_deterministic_zip
import test_nested_aar_mice as original
from test_f45_aar_reuse import _horizon


def pin(path):
    return {"sha256": sha256_file(path), "size_bytes": path.stat().st_size}


def inputs(tmp_path, monkeypatch, family):
    science = strict_json_bytes((Path(a.__file__).parents[1] / "science-decision.json").read_bytes())
    monkeypatch.setattr(original, "_unfitted_confirmed_decision", lambda: science)
    prepared = original.unfitted_selector_shard_inputs.__wrapped__(
        tmp_path, monkeypatch, SimpleNamespace(param=family))
    calls = original.unfitted_selector_engines.__wrapped__(monkeypatch)
    members = f4._f45_source_member_sha256()
    # A frozen executor has one source identity for the entire computation.
    monkeypatch.setattr(f4, "_f45_source_member_sha256", lambda: members)
    monkeypatch.setattr(f5, "_f45_score_reuse_authorities", lambda: ({"e" * 64: n._sha(members)}, {n._sha(members): members}))
    return prepared, calls


def whole(tmp_path, prepared, native_root):
    horizon = prepared["source"]["primary_source"]["primary_development_lock"]["selection_horizon_months"]
    owner = tmp_path / f"AAR-H{horizon:02d}-O1"
    owner.mkdir()
    payload = {path.relative_to(native_root).as_posix(): path for path in native_root.rglob("*")
               if path.is_file() and "training-inputs" not in path.parts}
    payload["execution.json"] = encode({"executor_source_identity": prepared["source"]["primary_source"]["primary_training_context"]["modeling_program_sha256"]})
    native = {}
    for branch in n.AAR_ESTIMANDS:
        for imp in range(1, 21):
            name = f"fits/O1_{branch}_M{imp:02d}"
            payload[name + ".numbers.json"] = b'{"UNFITTED_UNRELATED_FINAL_BOUNDARY":true}'
            native[name + ".zip"] = {"sha256": "f" * 64, "size_bytes": 100}
    members = {name: pin(value) if isinstance(value, Path) else
               {"sha256": sha256_bytes(value), "size_bytes": len(value)} for name, value in payload.items()}
    metadata = n._sealed({"kind": "PADML_F5_A12_OUTER_NATIVE_V2", "source": prepared["source"],
        "family": prepared["family"], "outer_fold": 1, "members": members,
        "native_members": native, "predictions": {"UNFITTED": True}})
    write_deterministic_zip(owner / "result.zip", {"a12-outer.json": encode(metadata), **payload})
    write_deterministic_zip(owner / "input.zip", {"UNFITTED.json": b"{}"})
    (owner / "input.compile.json").write_bytes(b"{}")
    receipt = {"unit_id": owner.name, "selection_horizon_months": horizon, "report_horizons_months": [6, 12, 24, 36],
        "status": "COMPLETED", "direct_consumer_completed": True, "run_identity": "e" * 64,
        "artifacts": {name: pin(owner / name) for name in ("input.zip", "input.compile.json", "result.zip")}}
    (owner / "unit.json").write_bytes(encode(receipt))
    return {"root": str(owner), "receipt": receipt}


def current_line(prepared, candidate):
    current = copy.deepcopy(prepared)
    source = current["source"]
    source["primary_source"] = _horizon(source["primary_source"], 6)
    current["source"] = n._sealed({k: v for k, v in source.items() if k != "identity_sha256"})
    current["completed_aar_units"] = [candidate]
    current.pop("branch_development", None)
    current.pop("source_input_record", None)
    return current


def test_fixed_seta_outer_path_has_no_heldout_response(tmp_path, monkeypatch):
    prepared, calls = inputs(tmp_path, monkeypatch, "ELASTIC_NET_COX")
    branch = n.A12_TOTAL_AAR
    prepared = a._a12_projected_development_inputs(prepared, tmp_path / "development", replay=False, branch=branch)
    configuration = a._a12_elastic_configuration(prepared, branch, workers=1)
    outer = configuration["outer"]
    assert "evaluation_response" not in outer
    projected = kernel._engine_registered_partitions(configuration["registered"], {outer["partition_id"]})
    assert not kernel._contains_key(projected, "evaluation_response")
    assert projected["partitions"][0]["fit_ids"] == outer["fit_ids"]
    inner = copy.deepcopy(configuration["registered"])
    partition = next(row for row in inner["partitions"] if row["kind"] == "INNER")
    partition.pop("evaluation_response")
    with pytest.raises(ContractError, match="REGISTERED_PARTITION_IDENTITY_INVALID"):
        kernel._engine_registered_partitions(inner, {partition["partition_id"]})


@pytest.mark.parametrize("changed", [False, True])
def test_total_recipes_use_actual_m20_and_original_native_consumer(tmp_path, monkeypatch, changed):
    prepared, calls = inputs(tmp_path, monkeypatch, "COX_PH")
    branch = n.A12_TOTAL_AAR
    root = tmp_path / "producer"
    root.mkdir()
    first = a._a12_projected_development_inputs(prepared, root / "development", replay=False, branch=branch)
    count = len(prepared["branches"][branch]["partitions"])
    assert calls["recipe"] == count and calls["path"] == 0
    candidate = whole(tmp_path, prepared, root)
    original_bytes = {path: path.read_bytes() for path in root.rglob("*") if path.is_file()}
    current = current_line(prepared, candidate)
    if changed:
        partition = current["branches"][branch]["partitions"][0]
        own = tmp_path / "different-M20"
        shutil.copytree(partition["covariates"]["input_dir"], own)
        path = own / "imp01.csv"
        lines = path.read_text().splitlines()
        fields, row = lines[0].split(","), lines[1].split(",")
        row[fields.index("Age")] = str(float(row[fields.index("Age")]) + 1)
        lines[1] = ",".join(row)
        path.write_text("\n".join(lines) + "\n")
        covariates = partition["covariates"]
        covariates["input_dir"] = str(own)
        covariates["members"] = [{"name": f"imp{i:02d}.csv", **pin(own / f"imp{i:02d}.csv")} for i in range(1, 21)]
        covariates["data_identity"] = n._sha(covariates["members"])
        partition["fit_covariate_members"] = kernel._fit_covariate_member_records(covariates, partition["fit_ids"])
        current["branches"][branch]["identity"] = n._sha([
            kernel._registered_partition_identity_record(p, prediction_only=p["kind"] == "OUTER")
            for p in current["branches"][branch]["partitions"]])
    target = tmp_path / "consumer"
    target.mkdir()
    second = a._a12_projected_development_inputs(current, target / "development", replay=False, branch=branch)
    assert calls["recipe"] == count + int(changed) and calls["path"] == 0
    references = list((target / "development/recipes" / branch).glob("*/reuse.json"))
    assert len(references) == count - int(changed)
    if not changed:
        assert second["branch_development"][branch]["recipes"] == first["branch_development"][branch]["recipes"]
    with monkeypatch.context() as no_r:
        no_r.setattr(f5.subprocess, "run", lambda *a, **k: pytest.fail("NO_RECIPE_REPLAY_OR_FIT"))
        reopened = a._a12_projected_development_inputs(current, target / "development", replay=True, branch=branch)
    assert reopened["branch_development"] == second["branch_development"]
    assert all(path.read_bytes() == raw for path, raw in original_bytes.items())
    # A DIRECT recipe already has an original primary consumer and needs no C fitter.
    direct = a._a12_projected_development_inputs(current, target / "direct", replay=False, branch=n.A12_DIRECT_AAR)
    assert direct["branches"][n.A12_DIRECT_AAR]["recipes"] and calls["recipe"] == count + int(changed)
    if not references:
        return
    reference = references[0]
    saved = reference.read_bytes()
    damaged = strict_json_bytes(saved)
    damaged["consumer_source"] = "0" * 64
    reference.write_bytes(encode(damaged))
    with pytest.raises(ContractError, match="RECIPE_REUSE_INVALID"):
        a._a12_projected_development_inputs(current, target / "development", replay=True, branch=branch)
    reference.write_bytes(saved)


def elastic_leaves(monkeypatch):
    """Synthetic native leaves; real fixed-domain path health/EPV reducers remain."""
    from test_nested_full_development import _unfitted_selector_path_values
    counts = {"native": 0, "read": 0}
    def engine(spec_path, output_path, repo_root, environment, *, preserve_logs):
        spec = strict_json_bytes(spec_path.read_bytes())
        task = {**spec["producer_tasks"][0], "transform_recipe": spec["transform_recipe"]}
        partition = spec["registered_partitions"]["partitions"][0]
        assert task["selected_parents"] == ["Age"] and not {"AST", "ALT", "AST_ALT"}.intersection(task["selected_parents"])
        value = _unfitted_selector_path_values(spec, partition, task)
        for path in value["sealed_elastic_paths"]:
            path["lambda_path"] = [path["lambda_max"] * ratio for ratio in task["ratios"]]
            path["lambda_path_sha256"] = n._sha(path["lambda_path"])
            path["risk_curve_sha256"] = n._sha({"UNFITTED": task["task_id"], "alpha": path["alpha"]})
        output_path.write_bytes(encode(value))
        (spec_path.parent / "r.stdout.log").write_bytes(b"UNFITTED retained native leaf\n")
        (spec_path.parent / "r.stderr.log").write_bytes(b"")
        counts["native"] += 1
    def batches(spec, registered, tasks, scratch, repo_root, *, evaluation_mode="NONE"):
        child = kernel._r_prediction_child_spec(spec)
        result = []
        for task in tasks:
            directory = scratch / ("f2-r-batch-" + n._sha([task["task_id"]])[:16])
            directory.mkdir()
            projected = kernel._engine_registered_partitions(registered, {task["partition_id"]})
            value = {**child, "action": "MODEL_PREDICTION_BATCH", "threads": 1, "pool_workers": 1,
                "engine_threads": 1, "registered_partitions": projected, "transform_recipe": task["transform_recipe"],
                "producer_tasks": [{k: v for k, v in task.items() if k != "transform_recipe"}],
                "output_path": str(directory / "output.json")}
            (directory / "spec.json").write_bytes(encode(value))
            result.append(a._run_a12_elastic_native_batch(directory / "spec.json", directory / "output.json", repo_root, {}))
            counts["read"] += 1
        return result
    monkeypatch.setattr(kernel, "_execute_r_prediction", engine)
    monkeypatch.setattr(kernel, "_run_r_prediction_batch", batches)
    return counts


def test_fixed_seta_complete_paths_reuse_and_reopen_with_current_branch(tmp_path, monkeypatch):
    prepared, recipes = inputs(tmp_path, monkeypatch, "ELASTIC_NET_COX")
    branch = n.A12_TOTAL_AAR
    root = tmp_path / "producer"
    root.mkdir()
    first_inputs = a._a12_projected_development_inputs(prepared, root / "development", replay=False, branch=branch)
    assert recipes["recipe"] == 16
    counts = elastic_leaves(monkeypatch)
    (root / "search").mkdir()
    original_search = a._a12_elastic_search_program(first_inputs, branch, root / "search" / branch, replay=False, workers=1)
    original_calls = counts["native"]
    assert original_calls == original_search["native_batch_count"] == 640
    candidate = whole(tmp_path, prepared, root)
    old_files = {path: pin(path) for path in (root / "search").rglob("*") if path.is_file()}
    current = current_line(prepared, candidate)
    target = tmp_path / "consumer"
    target.mkdir()
    current = a._a12_projected_development_inputs(current, target / "development", replay=False, branch=branch)
    assert recipes["recipe"] == 16
    (target / "search").mkdir()
    current_root = target / "search" / branch
    retain = f5._f45_retain_final_object
    copies = []
    def interrupted(stream, path, record):
        copies.append(path)
        if len(copies) == 3:
            raise OSError("UNFITTED_COPY_INTERRUPTED")
        return retain(stream, path, record)
    with monkeypatch.context() as interrupt:
        interrupt.setattr(f5, "_f45_retain_final_object", interrupted)
        with pytest.raises(OSError, match="UNFITTED_COPY_INTERRUPTED"):
            a._a12_elastic_search_program(current, branch, current_root, replay=False, workers=1)
    binding = (current_root / "reuse.json").read_bytes()
    unavailable = {**current, "completed_aar_units": []}
    with pytest.raises(ContractError, match="PENDING_ORIGINAL_REQUIRED"):
        a._a12_elastic_search_program(unavailable, branch, current_root, replay=False, workers=1)
    assert (current_root / "reuse.json").read_bytes() == binding
    assert counts["native"] == original_calls
    result = a._a12_elastic_search_program(current, branch, current_root, replay=False, workers=1)
    assert counts["native"] == original_calls
    assert result["parameters_by_imputation"] == original_search["parameters_by_imputation"]
    assert result["source"] != original_search["source"]
    assert result["epv_resolution"] == original_search["epv_resolution"]
    assert result["reused_search"]["new_glmnet_calls"] == result["reused_search"]["new_elastic_paths"] == 0
    assert result["reused_search"]["shared_elastic_paths"] == original_search["path_execution_count"]
    assert all(pin(path) == old for path, old in old_files.items())
    configuration = a._a12_elastic_configuration(current, branch, workers=1)
    for damage in ("seed", "M20", "recipe"):
        changed = copy.deepcopy(configuration)
        if damage == "seed":
            changed["spec"]["seed"] += 1
        elif damage == "M20":
            changed["registered"]["partitions"][0]["covariates"]["members"][0]["sha256"] = "0" * 64
        else:
            changed["recipe_set"]["recipe_set_sha256"] = "0" * 64
        missed = target / ("miss-" + damage)
        assert a._a12_elastic_reuse(current, branch, changed, missed) is None
        assert not missed.exists()
    # Reopen solely from the retained original native bytes and the new consumer proof.
    portable = tmp_path / "portable-elastic"
    archive = tmp_path / "UNFITTED-elastic-boundary.zip"
    # Select files with the production whole-archive projection, not rglob.
    # MICE numerical inputs were consumed above; this placeholder is only for
    # the projection's existence contract, not acceptance of an input archive.
    (target / "inputs.zip").write_bytes(b"UNFITTED member projection only")
    retained = a._a12_outer_retained_members(target, "ELASTIC_NET_COX", 1, target / "inputs.zip",
        prepared=current, before_final=True, assigned_branches=(branch,))
    prefix = f"search/{branch}/"
    write_deterministic_zip(archive, {name[len(prefix):]: path for name, path in retained.items()
        if name.startswith(prefix)})
    portable.mkdir()
    for name, raw in a.read_safe_zip(archive, max_total_bytes=2 * 1024**3).items():
        path = portable / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(raw)
    reopened = a._a12_elastic_search_program(current, branch, portable, replay=True, workers=1)
    assert reopened == result and counts["native"] == original_calls
    # A changed retained byte fails before any new producer; no blind fallback.
    member = next((portable / "native").glob("*/output.json"))
    saved = member.read_bytes()
    member.write_bytes(saved + b" ")
    with pytest.raises(ContractError, match="ELASTIC_REUSE_INVALID"):
        a._a12_elastic_search_program(current, branch, portable, replay=True, workers=1)
    assert counts["native"] == original_calls


def test_development_and_final_reuse_counts_add_without_changing_logical_budget(tmp_path):
    """Consume whole counters; these synthetic metadata do not accept a scientific whole."""
    science = strict_json_bytes((Path(a.__file__).parents[1] / "science-decision.json").read_bytes())
    source = dict(kind="PADML_F5_A12_PROJECTED_OUTER_INPUTS_V1", mice_inputs=[{}] * 64,
        primary_source=dict(science_decision=science))
    mice = tmp_path / "mice.zip"
    write_deterministic_zip(mice, {"a12-inputs.json": encode({"mice_reuse": {str(i): {} for i in range(64)}})})
    members = {"inputs.zip": mice,
        "development/selector/development-input.json": encode(dict(selector_path_count=3840, glmnet_call_count=7680)),
        "development/selector/reuse.json": encode({"execution": {"reused_selector_paths": 3840}})}
    for index, branch in enumerate(n.AAR_ESTIMANDS):
        value = dict(path_execution_count=3840, glmnet_pilot_and_path_call_count=7680)
        if index < 2:
            value["reused_search"] = dict(shared_elastic_paths=3840, shared_glmnet_calls=7680,
                new_elastic_paths=0, new_glmnet_calls=0)
        members[f"search/{branch}/search.json"] = encode(value)
        for imp in range(1, 21):
            members[f"fits/O1_{branch}_M{imp:02d}.numbers.json"] = encode({"reused_final": {"UNFITTED": True}})
    recipes = {f"partition-{i}": {} for i in range(16)}
    members[f"development/{n.A12_TOTAL_AAR}.json"] = encode({"recipes": recipes})
    for pid in recipes:
        members[f"development/recipes/{n.A12_TOTAL_AAR}/{pid}/reuse.json"] = b"{}"
    path = tmp_path / "whole-counter-boundary.zip"
    write_deterministic_zip(path, members)
    record = a._a12_outer_archive_record(dict(family="ELASTIC_NET_COX", outer_fold=1,
        identity_sha256="a" * 64, source=source, members=members), path)
    assert record["logical_execution_ledger"]["elastic_path_executions"] == 15360
    assert record["reused_execution_ledger"]["elastic_path_executions"] == 11520
    assert record["execution_ledger"]["elastic_path_executions"] == 3840
    assert record["execution_ledger"]["glmnet_pilot_and_path_calls"] == 7680
    assert record["execution_ledger"]["post_lock_fits"] == record["execution_ledger"]["mice_chains"] == 0
    assert record["total_recipe_execution"] == dict(logical=16, shared=16, physical=0)


def test_actual_outer_retention_keeps_elastic_reuse_provenance(tmp_path):
    root = tmp_path / "consumer"
    branch = n.A12_TOTAL_AAR
    native = root / "search" / branch / "native" / "f2-r-batch-unfitted"
    native.mkdir(parents=True)
    development = root / "development"
    development.mkdir()
    (development / (branch + ".json")).write_bytes(encode({"UNFITTED": True}))
    archive = root / "inputs.zip"
    archive.write_bytes(b"UNFITTED existence only; no numerical reader")
    search = native.parent.parent
    for name in ("search.json", "reuse.json", "producer-search.json"):
        (search / name).write_bytes(encode({"UNFITTED": name}))
    for name in ("spec.json", "output.json", "r.stdout.log", "r.stderr.log"):
        (native / name).write_bytes(b"UNFITTED existence only")
    prepared = {"source": {"kind": "PADML_F5_A12_PROJECTED_OUTER_INPUTS_V1"}}
    retained = a._a12_outer_retained_members(
        root, "ELASTIC_NET_COX", 1, archive, prepared=prepared,
        before_final=True, assigned_branches=(branch,))
    assert f"search/{branch}/search.json" in retained
    assert f"search/{branch}/native/f2-r-batch-unfitted/spec.json" in retained
    required = {f"search/{branch}/{name}" for name in ("reuse.json", "producer-search.json")}
    assert required <= set(retained), f"Production archive omits {sorted(required - set(retained))}"


def test_total_recipe_pending_requires_original_and_recovers_without_new_leaf(tmp_path, monkeypatch):
    prepared, calls = inputs(tmp_path, monkeypatch, "COX_PH")
    branch = n.A12_TOTAL_AAR
    selected = prepared["source"]["fixed_selected_parents"]
    partition = prepared["branches"][branch]["partitions"][0]
    producer = tmp_path / "producer"
    directory = producer / "development" / "recipes" / branch
    directory.mkdir(parents=True)
    f5._compile_partition_design_recipe("COX_PH", selected, partition, directory,
        a12=True, native_evidence=directory / partition["partition_id"])
    assert calls["recipe"] == 1
    candidate = whole(tmp_path, prepared, producer)
    current = current_line(prepared, candidate)
    target = tmp_path / "consumer-recipes"
    target.mkdir()
    predictors = kernel.predictor_contract(Path(a.__file__).parent)
    keep = f5._f45_retain_final_object
    copies = []
    def interrupted(stream, path, record):
        copies.append(path)
        if len(copies) == 3:
            raise OSError("UNFITTED_RECIPE_COPY_INTERRUPTED")
        return keep(stream, path, record)
    with monkeypatch.context() as broken:
        broken.setattr(f5, "_f45_retain_final_object", interrupted)
        with pytest.raises(OSError, match="UNFITTED_RECIPE_COPY_INTERRUPTED"):
            a._a12_recipe_reuse(current, branch, [partition], selected, target, predictors, replay=False)
    ref = target / partition["partition_id"] / "reuse.json"
    marker = ref.read_bytes()
    with pytest.raises(ContractError, match="PENDING_ORIGINAL_REQUIRED"):
        a._a12_recipe_reuse({**current, "completed_aar_units": []}, branch, [partition],
            selected, target, predictors, replay=False)
    assert ref.read_bytes() == marker
    with monkeypatch.context() as no_native:
        no_native.setattr(f5.subprocess, "run", lambda *args, **kwargs: pytest.fail("NO_NEW_RECIPE_OR_R"))
        assert a._a12_recipe_reuse(current, branch, [partition], selected, target, predictors,
            replay=False) == {partition["partition_id"]}
        assert a._a12_recipe_reuse({**current, "completed_aar_units": []}, branch, [partition],
            selected, target, predictors, replay=True) == {partition["partition_id"]}
    assert calls["recipe"] == 1 and ref.read_bytes() == marker


def test_original_f2_outer_still_requires_response_before_projection():
    row = {"kind": "OUTER", "partition_id": "OUTER1", "repeat": 0, "inner_fold": 0,
        "fit_ids": ["fit"], "evaluation_ids": ["heldout"],
        "evaluation_ids_sha256": n._sha(["heldout"]), "application_ids": ["heldout"],
        "covariates": {}, "fit_response": {}}
    registered = {"kind": "PADML_F2_REGISTERED_PARTITION_INPUTS", "status": "PASS",
        "partitions": [row], "diagnostic_partitions": []}
    with pytest.raises(ContractError, match="REGISTERED_PARTITION_IDENTITY_INVALID"):
        kernel._engine_registered_partitions(registered, {"OUTER1"})
    row["evaluation_response"] = {"UNFITTED": True}
    projected = kernel._engine_registered_partitions(registered, {"OUTER1"})
    assert "evaluation_response" not in projected["partitions"][0]
