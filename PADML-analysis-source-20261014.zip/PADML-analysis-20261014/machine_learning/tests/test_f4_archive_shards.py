"""Unfitted storage fixtures: real ZIP/index/consumer wiring, no scientific fits."""
import copy
import struct
import sys
from pathlib import Path

import pytest

from padml import f4
from padml.bundle import (ContractError, canonical_json_bytes, extract_safe_zip, read_safe_zip,
                         sha256_bytes, strict_json_bytes, write_deterministic_zip)
from test_learning_native import native_rows, unsupported


RISK = struct.pack("<6d", -0.0, 1.0000000000000002, 1e-300, -7.125, 0.12345678901234567, 1e200)
LEARNING_CELL_READER = f4.load_learning_curve_cell_archive


@pytest.fixture(autouse=True)
def no_science(monkeypatch):
    def forbidden(*args, **kwargs):
        raise AssertionError("UNFITTED_STORAGE_TEST_NO_SCIENTIFIC_CALL")
    monkeypatch.setattr(f4.subprocess, "run", forbidden)
    for name in ("_bounded_ordered_spawn", "_execute_learning_curve_cell", "_execute_full_pipeline_replicate",
                 "_load_full_pipeline_replicate_archive", "load_learning_curve_cell_archive",
                 "native_metrics", "validate_full_pipeline_bootstrap_plan"):
        monkeypatch.setattr(f4, name, forbidden)


def indexed(path, member, body, extra=None):
    body = {key: value for key, value in body.items() if key != "identity_sha256"}
    value = {**body, "identity_sha256": sha256_bytes(canonical_json_bytes(body))}
    write_deterministic_zip(path, {member: canonical_json_bytes(value), **(extra or {})})
    return value


@pytest.fixture
def learning(tmp_path, monkeypatch):
    rows = native_rows()
    unsupported(rows[0])  # The original complete denominator and support survive storage changes.
    cells = [{**{key: row[key] for key in ("outer_fold", "seed_ordinal", "sample_fraction", "inner_fold", "family")},
              "repeat": 2, "imputations": 5, "analysis_ids": ["UNFITTED"] * round(10 * row["sample_fraction"])} for row in rows]
    by_key = {f4._learning_cell_key(cell): (cell, row) for cell, row in zip(cells, rows, strict=True)}
    source = {"binding_contract": {}, "covariates_csv": b"UNFITTED", "response_csv": b"UNFITTED",
              "f1_manifest": {"identity": "a" * 64}, "models": {(fold, "RSF"): {"UNFITTED": fold} for fold in range(1, 7)}}
    monkeypatch.setattr(f4, "_registered_learning_curve_cells", lambda *a, **k: copy.deepcopy(cells))
    monkeypatch.setattr(f4, "load_f4_inputs", lambda *a, **k: {"o_fit_source": source})
    monkeypatch.setattr(f4, "_load_o_fit_selection", lambda *a, **k: {"locked_family": "RSF"})
    monkeypatch.setattr(f4, "resolve_pool_workers", lambda value: 2)

    def produce(job):
        cell = job["cell"]
        assert set(job["source"]["models"]) == {(cell["outer_fold"], "RSF")}
        key = f4._learning_cell_key(cell)
        row = by_key[key][1]
        write_deterministic_zip(Path(job["root"]).with_suffix(".zip"), {
            "UNFITTED.json": canonical_json_bytes({"cell": cell, "row": row}), "full-precision-risk.bin": RISK})
        return row

    def pool(fn, jobs, *, selected_slots):
        assert len(jobs) == 60 and selected_slots == 2
        assert [len(job["cell"]["analysis_ids"]) for job in jobs] == sorted(
            [len(job["cell"]["analysis_ids"]) for job in jobs], reverse=True)
        return [fn(job) for job in reversed(jobs)]

    monkeypatch.setattr(f4, "_execute_learning_curve_cell", produce)
    monkeypatch.setattr(f4, "_bounded_ordered_spawn", pool)
    opened = []

    def consume(path, *, frozen_source, replay_evidence=None):
        entries = read_safe_zip(path, expected_members={"UNFITTED.json", "full-precision-risk.bin"})
        assert entries["full-precision-risk.bin"] == RISK
        result = strict_json_bytes(entries["UNFITTED.json"])
        if frozen_source is not source:
            coordinate = result["cell"]["outer_fold"], result["cell"]["family"]
            assert frozen_source == {**source, "models": {coordinate: source["models"][coordinate]}}
        assert (result["cell"], result["row"]) == by_key[f4._learning_cell_key(result["cell"])]
        opened.append(path)
        if replay_evidence is not None:
            replay_evidence.mkdir()
            (replay_evidence / "UNFITTED_REPLAY.json").write_bytes(entries["UNFITTED.json"])
        return result

    monkeypatch.setattr(f4, "load_learning_curve_cell_archive", consume)
    paths = []
    for fold in range(1, 7):
        directory = tmp_path / f"host-{fold}"
        directory.mkdir()
        path = directory / f"learning-o{fold:02d}.zip"
        f4.execute_learning_curve_bundle(tmp_path, tmp_path / "UNFITTED_SELECTION", path, outer_fold=fold, workers=2)
        paths.append(path)
    return source, rows, paths, opened, consume


def test_learning_indexes_read_original_cells_without_mother_copies(tmp_path, learning):
    source, rows, paths, opened, _ = learning
    before = {path: path.read_bytes() for path in tmp_path.rglob("*.zip")}
    target = tmp_path / "learning-aggregate.zip"
    value = f4.aggregate_learning_curve_archives(list(reversed(paths)), target, locked_family="RSF", frozen_source=source)
    assert len(opened) == len(set(opened)) == 360
    assert value["rows"] == rows and value["reduction"] == f4._reduce_native_learning_curve(rows, locked_family="RSF")
    assert set(read_safe_zip(target)) == {"learning-aggregate.json"}
    assert all(set(read_safe_zip(path)) == {"learning-outer.json"} for path in paths)
    assert all(path.read_bytes() == raw for path, raw in before.items())
    # A result embeds only this small index, and resolves original shards under its own root.
    embedded_dir = tmp_path / "UNFITTED_EXTRACTION"
    embedded_dir.mkdir()
    embedded = embedded_dir / "learning-aggregate.zip"
    embedded.write_bytes(target.read_bytes())
    opened.clear()
    assert f4.load_learning_curve_aggregate_archive(embedded, frozen_source=source, shard_root=tmp_path) == value
    assert len(opened) == len(set(opened)) == 360 and set(opened) <= set(before)
    assert all(path.read_bytes() == raw for path, raw in before.items())


def test_learning_replay_pool_uses_single_family_and_preserves_canonical_rows(tmp_path, learning, monkeypatch):
    source, rows, paths, opened, _ = learning
    before = {path: path.read_bytes() for path in tmp_path.rglob("*.zip")}
    batches = []

    def pool(worker, jobs, *, selected_slots):
        assert worker is f4._replay_learning_curve_cell and selected_slots == 2
        assert len(jobs) == 60
        assert [len(job["cell"]["analysis_ids"]) for job in jobs] == sorted(
            [len(job["cell"]["analysis_ids"]) for job in jobs], reverse=True)
        assert len({job["replay_evidence"] for job in jobs}) == 60
        assert all(len(job["source"]["models"]) == 1 for job in jobs)
        batches.append(jobs)
        # Deliberately violate completion order, without fitting any object.
        return [worker(job) for job in reversed(jobs)]

    monkeypatch.setattr(f4, "_bounded_ordered_spawn", pool)
    target = tmp_path / "parallel-aggregate.zip"
    value = f4.aggregate_learning_curve_archives(list(reversed(paths)), target, locked_family="RSF",
        frozen_source=source, replay_workers=2)
    assert len(batches) == 6 and len(opened) == len(set(opened)) == 360
    assert value["rows"] == rows
    assert value["reduction"] == f4._reduce_native_learning_curve(rows, locked_family="RSF")
    opened.clear()
    assert f4.load_learning_curve_aggregate_archive(target, frozen_source=source,
        replay_evidence=tmp_path / "second-reader", replay_workers=2) == value
    assert len(batches) == 12 and len(opened) == len(set(opened)) == 360
    assert all(path.read_bytes() == raw for path, raw in before.items())


@pytest.mark.parametrize("failure", ["native_error", "wrong_coordinate"])
def test_learning_replay_pool_failure_cannot_publish_and_keeps_evidence(tmp_path, learning, monkeypatch, failure):
    source, _, paths, _, consume = learning
    before = {path: path.read_bytes() for path in tmp_path.rglob("*.zip")}
    calls = []

    def fail(path, **kwargs):
        calls.append(path)
        if len(calls) == 3 and failure == "native_error":
            raise ContractError("UNFITTED_NATIVE_FAILURE")
        value = consume(path, **kwargs)
        if len(calls) == 3:
            value["cell"]["inner_fold"] = 6
        return value

    monkeypatch.setattr(f4, "load_learning_curve_cell_archive", fail)
    target = tmp_path / "failed-parallel.zip"
    with pytest.raises(ContractError, match="UNFITTED_NATIVE_FAILURE|CELL_SOURCE_MISMATCH"):
        f4.aggregate_learning_curve_archives(paths, target, locked_family="RSF",
            frozen_source=source, replay_workers=2)
    assert len(calls) == 3 and not target.exists()
    assert len(list(tmp_path.rglob("UNFITTED_REPLAY.json"))) == (2 if failure == "native_error" else 3)
    assert all(path.read_bytes() == raw for path, raw in before.items())


@pytest.mark.parametrize("damage", ["missing", "changed_bytes", "escape", "symlink_parent", "duplicate", "legacy_mother"])
def test_learning_shard_damage_cannot_be_resealed_as_native(tmp_path, learning, damage):
    source, _, paths, opened, _ = learning
    path = paths[0]
    value = strict_json_bytes(read_safe_zip(path)["learning-outer.json"])
    names = list(value["members"])
    record = value["members"][names[0]]
    original = path.parent / record["relative_path"]
    if damage == "missing":
        original.rename(original.with_suffix(".retained"))
    elif damage == "changed_bytes":
        original.write_bytes(b"UNFITTED_TAMPER")
    elif damage == "escape":
        record["relative_path"] = "../outside.zip"
    elif damage == "symlink_parent":
        link = path.parent / "linked"
        link.symlink_to(original.parent, target_is_directory=True)
        record["relative_path"] = "linked/" + original.name
    elif damage == "duplicate":
        value["members"][names[1]] = dict(record)
    else:
        value["kind"] = "PADML_F4_LEARNING_OUTER_NATIVE_V1"
    changed = path.parent / "changed-index.zip"
    indexed(changed, "learning-outer.json", value)
    with pytest.raises(ContractError):
        f4.load_learning_curve_outer_archive(changed, frozen_source=source)
    assert len(opened) < 60


def test_learning_native_failure_preserves_originals_and_prior_evidence(tmp_path, learning, monkeypatch):
    source, _, paths, _, consume = learning
    before = {path: path.read_bytes() for path in tmp_path.rglob("*.zip")}
    calls = []
    def fail(path, **kwargs):
        calls.append(path)
        if len(calls) == 4:
            raise ContractError("UNFITTED_NATIVE_FAILURE")
        return consume(path, **kwargs)
    monkeypatch.setattr(f4, "load_learning_curve_cell_archive", fail)
    target = tmp_path / "failed-aggregate.zip"
    with pytest.raises(ContractError, match="UNFITTED_NATIVE_FAILURE"):
        f4.aggregate_learning_curve_archives(paths, target, locked_family="RSF", frozen_source=source)
    assert len(calls) == 4 and not target.exists()
    assert len(list(tmp_path.rglob("UNFITTED_REPLAY.json"))) == 3
    assert all(path.read_bytes() == raw for path, raw in before.items())


@pytest.fixture
def full_pipeline(tmp_path, monkeypatch):
    plan = {"family": "XGBOOST_COX", "identity_sha256": "b" * 64, "UNFITTED": True}
    plan_path = tmp_path / "plan.zip"
    write_deterministic_zip(plan_path, {"full-pipeline-plan.json": canonical_json_bytes(plan)})
    monkeypatch.setattr(f4, "validate_full_pipeline_bootstrap_plan", lambda value, **k: value if value == plan else pytest.fail("PLAN_DRIFT"))
    root = tmp_path / "original-replicates"
    root.mkdir()
    paths, rows = [], []
    for replicate in range(1, 101):
        support = {side: {"status": "ESTIMABLE", "value": number, "support": []}
                   for side, number in (("bootstrap", .1), ("original", .2))}
        row = {"replicate": replicate, "family": plan["family"], "evidence_label": f4.FULL_PIPELINE_EVIDENCE_LABEL,
               "scientific_counts": {"final_model_fits": 20}, "UNFITTED": True,
               "evaluation": {"optimism": {name: {"status": "ESTIMABLE", "value": sign * .1, **support}
                                          for name, sign in (("optimism_ibs", 1), ("optimism_uno_c", -1))}}}
        path = root / f"replicate-b{replicate:03d}.zip"
        indexed(path, "UNFITTED.json", {"row": row}, {"full-precision-risk.bin": RISK})
        paths.append(path)
        rows.append(row)
    opened = []
    def consume(path, *, plan, frozen_source, rscript, replay_evidence=None):
        assert path in paths and frozen_source == {"UNFITTED": True}
        entries = read_safe_zip(path, expected_members={"UNFITTED.json", "full-precision-risk.bin"})
        assert entries["full-precision-risk.bin"] == RISK
        opened.append(path)
        return strict_json_bytes(entries["UNFITTED.json"])
    monkeypatch.setattr(f4, "_load_full_pipeline_replicate_archive", consume)
    return plan_path, paths, rows, opened


def test_b100_index_reads_each_original_once_and_keeps_mcse(tmp_path, full_pipeline):
    plan, paths, rows, opened = full_pipeline
    before = {path: path.read_bytes() for path in paths}
    target = tmp_path / "full-pipeline-aggregate.zip"
    result = f4.aggregate_full_pipeline_execution_archives(list(reversed(paths)), plan, target,
        locked_family="XGBOOST_COX", frozen_source={"UNFITTED": True})
    assert result["replicate_count"] == 100 and len(opened) == 100
    entries = read_safe_zip(target)
    assert set(entries) == {"full-pipeline.json", "full-pipeline-plan.json"}
    value = strict_json_bytes(entries["full-pipeline.json"])
    assert value["rows"] == rows and value["completion"] == f4._reduce_full_pipeline_native_rows(rows, locked_family="XGBOOST_COX")
    assert target.stat().st_size < sum(path.stat().st_size for path in paths)
    opened.clear()
    assert f4.load_full_pipeline_aggregate_archive(target, frozen_source={"UNFITTED": True}) == value
    assert opened == paths and all(path.read_bytes() == raw for path, raw in before.items())
    extracted = tmp_path / "UNFITTED_EXTRACTION"
    extracted.mkdir()
    embedded = extracted / target.name
    embedded.write_bytes(target.read_bytes())
    opened.clear()
    assert f4.load_full_pipeline_aggregate_archive(embedded, frozen_source={"UNFITTED": True}, shard_root=tmp_path) == value
    assert opened == paths
    with pytest.raises(ContractError, match="SHARD_MISSING"):
        f4.load_full_pipeline_aggregate_archive(embedded, frozen_source={"UNFITTED": True})
    missing = paths[-1]
    missing.rename(missing.with_suffix(".retained"))
    with pytest.raises(ContractError, match="SHARD_MISSING"):
        f4.load_full_pipeline_aggregate_archive(target, frozen_source={"UNFITTED": True})


@pytest.mark.parametrize("workers", [None, 2])
def test_trigger_opens_original_learning_shards_from_embedded_index(tmp_path, learning, monkeypatch, workers):
    source, rows, paths, opened, _ = learning
    learning_path = tmp_path / "learning-aggregate.zip"
    learning_value = f4.aggregate_learning_curve_archives(paths, learning_path, locked_family="RSF", frozen_source=source)
    o_fit_path = tmp_path / "o-fit-aggregate.zip"
    write_deterministic_zip(o_fit_path, {"UNFITTED.json": b"UNFITTED"})
    o_fit = {"family": "RSF", "identity_sha256": "e" * 64, "rows": [{"UNFITTED": True}]}
    fixed = {"status": "COMPUTED_AWAITING_REVIEW", "stage_acceptance": False,
             "full_pipeline_bootstrap_result": None, "family_decision": {}, "matrix_loco": {},
             "evaluation": {}, "post_selection_bootstrap": {}, "registered_learning_curve_rows": None,
             "o_fit_rows": None, "full_pipeline_bootstrap": None,
             "source": {"o_fit_aggregate": None, "learning_curve_aggregate": None, "full_pipeline_aggregate": None,
                        "execution_contract_seal_sha256": "d" * 64}}
    suite = copy.deepcopy(fixed)
    suite["source"]["execution_contract_seal_sha256"] = "e" * 64
    status = {"status": "REQUIRED", "requirement": "REQUIRED_DUE_TO_STATISTICAL_SUPPORT", "unevaluated_triggers": []}
    suite.update(registered_learning_curve_rows=rows, o_fit_rows=o_fit["rows"], full_pipeline_bootstrap=status)
    for field, path, value in (("o_fit_aggregate", o_fit_path, o_fit), ("learning_curve_aggregate", learning_path, learning_value)):
        suite["source"][field] = {"member": path.name, "identity_sha256": value["identity_sha256"],
                                  "sha256": f4.sha256_file(path), "size_bytes": path.stat().st_size}
    result = tmp_path / "f4-trigger.zip"
    write_deterministic_zip(result, {"f4-suite.json": canonical_json_bytes(suite),
                                     o_fit_path.name: o_fit_path, learning_path.name: learning_path})
    monkeypatch.setattr(f4, "_reuse_f4_fixed_result", lambda *a: fixed)
    lock = {"locked_family": "RSF", "UNFITTED": True}
    monkeypatch.setattr(f4, "resolve_f4_final_family_lock", lambda *a: lock)
    def read_o_fit(path, *, frozen_source, **kwargs):
        assert frozen_source is source and path.read_bytes() == o_fit_path.read_bytes()
        assert kwargs == ({"replay_workers": workers} if workers is not None else {})
        return o_fit
    monkeypatch.setattr(f4, "load_o_fit_aggregate_archive", read_o_fit)
    def trigger(*args, **kwargs):
        assert args[4] == rows and kwargs["learning_curve_execution"] == learning_value
        return status
    monkeypatch.setattr(f4, "_full_pipeline_bootstrap_status", trigger)
    opened.clear()
    assert f4._load_full_pipeline_trigger_result(result, {"o_fit_source": source},
        fixed_result=tmp_path / "UNFITTED_FIXED", replay_workers=workers) == lock
    assert len(opened) == len(set(opened)) == 360
    original = opened[0]
    original.rename(original.with_suffix(".retained"))
    with pytest.raises(ContractError, match="SHARD_MISSING"):
        f4._load_full_pipeline_trigger_result(result, {"o_fit_source": source},
            fixed_result=tmp_path / "UNFITTED_FIXED", replay_workers=workers)


@pytest.mark.parametrize("failed_reader", [None, "o-fit", "learning", "full-pipeline"])
@pytest.mark.parametrize("workers", [None, 2])
def test_review_uses_result_root_and_never_seals_failed_native_reader(tmp_path, monkeypatch, failed_reader, workers):
    suite = {"UNFITTED": True}
    result = tmp_path / "f4-result.zip"
    write_deterministic_zip(result, {"f4-suite.json": canonical_json_bytes(suite),
        **{name + "-aggregate.zip": b"UNFITTED_INDEX" for name in ("o-fit", "learning", "full-pipeline")}})
    inputs = {"o_fit_source": {"UNFITTED": True}}
    monkeypatch.setattr(f4, "load_f4_inputs", lambda *a, **k: inputs)
    seen = []
    values = {name: {"UNFITTED": name} for name in ("o-fit", "learning", "full-pipeline")}
    def reader(name):
        def load(path, *, frozen_source, **kwargs):
            assert frozen_source is inputs["o_fit_source"] and path.read_bytes() == b"UNFITTED_INDEX"
            assert path.parent != tmp_path
            assert kwargs == {
                **({"shard_root": tmp_path} if name != "o-fit" else {}),
                **({"replay_workers": workers} if name in {"o-fit", "learning"} and workers is not None else {})}
            seen.append(name)
            if name == failed_reader:
                raise ContractError("UNFITTED_NATIVE_FAILURE")
            return values[name]
        return load
    for name, function in (("o-fit", "load_o_fit_aggregate_archive"), ("learning", "load_learning_curve_aggregate_archive"),
                           ("full-pipeline", "load_full_pipeline_aggregate_archive")):
        monkeypatch.setattr(f4, function, reader(name))
    def seal(path, review, raw, value, **kwargs):
        assert path == result and value == suite and raw == canonical_json_bytes(suite)
        assert kwargs["embedded_o_fit"] is values["o-fit"] and kwargs["embedded_learning"] is values["learning"]
        assert kwargs["embedded_full"] is values["full-pipeline"]
        seen.append("sole-seal-consumer")
        return {"UNFITTED_WIRING_ONLY": True}
    monkeypatch.setattr(f4, "_seal_f4_reviewed_result", seal)
    if failed_reader:
        with pytest.raises(ContractError, match="UNFITTED_NATIVE_FAILURE"):
            f4.seal_f4_locked_family_handoff(result, {}, f2_run_root=tmp_path, replay_workers=workers)
        assert "sole-seal-consumer" not in seen
    else:
        assert f4.seal_f4_locked_family_handoff(result, {}, f2_run_root=tmp_path,
            replay_workers=workers) == {"UNFITTED_WIRING_ONLY": True}
        assert seen == ["o-fit", "learning", "full-pipeline", "sole-seal-consumer"]


@pytest.mark.parametrize("which,malformed", [("old", "+" + "1" * 63), ("new", "z" * 64)])
def test_trigger_origin_requires_hex_before_native_diagnostics(tmp_path, monkeypatch, which, malformed):
    fixed = {"status": "COMPUTED_AWAITING_REVIEW", "stage_acceptance": False,
             "full_pipeline_bootstrap_result": None,
             "source": {"execution_contract_seal_sha256": "1" * 64, "full_pipeline_aggregate": None}}
    suite = copy.deepcopy(fixed)
    suite["source"]["execution_contract_seal_sha256"] = "2" * 64
    (fixed if which == "old" else suite)["source"]["execution_contract_seal_sha256"] = malformed
    result = tmp_path / "trigger.zip"
    write_deterministic_zip(result, {"f4-suite.json": canonical_json_bytes(suite),
        "o-fit-aggregate.zip": b"UNFITTED", "learning-aggregate.zip": b"UNFITTED"})
    original = result.read_bytes()
    monkeypatch.setattr(f4, "_reuse_f4_fixed_result", lambda *a: fixed)
    monkeypatch.setattr(f4, "resolve_f4_final_family_lock", lambda *a: pytest.fail("ORIGIN_NOT_VALIDATED"))
    with pytest.raises(ContractError, match="^INVALID_SHA256:f4.original_execution_seal$"):
        f4._load_full_pipeline_trigger_result(result, {}, fixed_result=tmp_path / "UNFITTED_FIXED")
    assert result.read_bytes() == original


def test_evaluate_forwards_workers_before_any_learning_or_fixed_science(tmp_path, monkeypatch):
    paths = {name: tmp_path / (name + ".zip") for name in ("o-fit", "learning", "fixed")}
    for path in paths.values():
        path.write_bytes(b"UNFITTED_INDEX")
    frozen = {"UNFITTED": True}
    monkeypatch.setattr(f4, "validate_f45_execution_contract_seal", lambda value: value)
    monkeypatch.setattr(f4, "load_f4_inputs", lambda *a, **k: {"o_fit_source": frozen})
    def o_fit(path, *, frozen_source, replay_evidence, replay_workers):
        assert path == paths["o-fit"] and frozen_source is frozen and replay_workers == 2
        assert replay_evidence == tmp_path / "result.zip.work/o-fit-native-replay"
        return {"rows": [], "identity_sha256": "a" * 64}
    monkeypatch.setattr(f4, "load_o_fit_aggregate_archive", o_fit)

    def native(path, *, frozen_source, replay_evidence, replay_workers):
        assert path == paths["learning"] and frozen_source is frozen and replay_workers == 2
        assert replay_evidence == tmp_path / "result.zip.work/learning-native-replay"
        raise ContractError("UNFITTED_ENTRY_REACHED_NO_SCIENCE")

    monkeypatch.setattr(f4, "load_learning_curve_aggregate_archive", native)
    monkeypatch.setattr(f4, "_reuse_f4_fixed_result", lambda *a: pytest.fail("UNEXPECTED_B1000_READ"))
    with pytest.raises(ContractError, match="UNFITTED_ENTRY_REACHED_NO_SCIENCE"):
        f4.execute(tmp_path, tmp_path / "result.zip", {}, workers=2,
            o_fit_aggregate=paths["o-fit"], fixed_result=paths["fixed"], learning_curve_aggregate=paths["learning"])
    assert not (tmp_path / "result.zip").exists()


@pytest.mark.parametrize("wrong_index", ["learning", "full-pipeline"])
def test_evaluate_wrong_shard_root_stops_before_inputs_or_native(tmp_path, monkeypatch, wrong_index):
    foreign = tmp_path / "foreign"
    foreign.mkdir()
    indexes = {name: (foreign if name == wrong_index else tmp_path) / (name + ".zip")
               for name in ("learning", "full-pipeline")}
    for path in indexes.values():
        path.write_bytes(b"UNFITTED_INDEX")
    for function in ("load_f4_inputs", "validate_f45_execution_contract_seal", "load_o_fit_aggregate_archive"):
        monkeypatch.setattr(f4, function, lambda *a, **k: pytest.fail("LATE_ROOT_VALIDATION"))
    target = tmp_path / "result.zip"
    with pytest.raises(ContractError, match="^F4_NATIVE_SHARD_ASSEMBLY_ROOT_MISMATCH$"):
        f4.execute(tmp_path, target, {}, o_fit_aggregate=tmp_path / "o-fit.zip", fixed_result=tmp_path / "fixed.zip",
            learning_curve_aggregate=indexes["learning"], full_pipeline_aggregate=indexes["full-pipeline"])
    assert not target.exists() and not target.with_name("result.zip.work").exists()
    assert all(path.read_bytes() == b"UNFITTED_INDEX" for path in indexes.values())


@pytest.mark.parametrize("command", ["o-fit-aggregate", "learning-aggregate", "review"])
def test_learning_replay_workers_reach_real_cli_consumer(tmp_path, monkeypatch, command):
    original = tmp_path / "source.zip"
    original.write_bytes(b"UNFITTED_INDEX")
    target = tmp_path / "result.json"
    seen = []
    if command in {"o-fit-aggregate", "learning-aggregate"}:
        source = {"UNFITTED": True}
        monkeypatch.setattr(f4, "load_f4_inputs", lambda *a, **k: {"o_fit_source": source})
        def aggregate(paths, result, *, locked_family, frozen_source, replay_workers):
            assert paths == [original] * 6 and result == target and locked_family == "RSF"
            assert frozen_source is source and replay_workers == 2
            seen.append(command)
            return {"UNFITTED_WIRING_ONLY": True}
        monkeypatch.setattr(f4, "aggregate_o_fit_execution_archives" if command == "o-fit-aggregate"
                            else "aggregate_learning_curve_archives", aggregate)
        args = [command, "RSF", str(target), *([str(original)] * 6)]
    else:
        review = tmp_path / "review.json"
        review.write_bytes(canonical_json_bytes({"UNFITTED": True}))
        def seal(path, value, *, f2_run_root, f1_runtime_root, replay_evidence, replay_workers):
            assert path == original and value == {"UNFITTED": True} and f2_run_root == tmp_path
            assert f1_runtime_root is None and replay_workers == 2
            assert replay_evidence == tmp_path / "result.json.native-replay"
            seen.append(command)
            return {"locked_family": "RSF", "UNFITTED_WIRING_ONLY": True}
        monkeypatch.setattr(f4, "seal_f4_locked_family_handoff", seal)
        args = [command, str(original), str(review), str(target)]
    monkeypatch.setattr(sys, "argv", ["padml.f4", *args, "--f2-run-root", str(tmp_path), "--workers", "2"])
    f4.main()
    assert seen == [command]


@pytest.mark.parametrize("interrupt_after", [0, 1, 2, None])
def test_extraction_cleanup_crash_recovery_never_deletes_original_or_new_evidence(tmp_path, monkeypatch, interrupt_after):
    original = tmp_path / "original.zip"
    entries = {"native/full-precision-risk.bin": RISK, "native/UNFITTED.json": b"UNFITTED"}
    write_deterministic_zip(original, entries)
    original_bytes, original_stat = original.read_bytes(), original.stat()
    root = tmp_path / "extracted"
    members = extract_safe_zip(original, root, expected_members=set(entries), max_member_bytes=1024, max_total_bytes=2048)
    new_evidence = root / "native/UNFITTED_NEW_REPLAY.json"
    new_evidence.write_bytes(b"NEW_NATIVE_OUTPUT_NOT_AN_EXTRACTED_COPY")
    native_unlink = Path.unlink
    removed = []
    def interrupted(path, *args, **kwargs):
        if path in {root / name for name in entries}:
            if interrupt_after == 0 and not removed:
                raise RuntimeError("INJECTED_BEFORE_UNLINK")
            result = native_unlink(path, *args, **kwargs)
            removed.append(path)
            if len(removed) == interrupt_after:
                raise RuntimeError("INJECTED_AFTER_UNLINK")
            return result
        raise AssertionError("UNOWNED_DELETION")
    with monkeypatch.context() as patch:
        patch.setattr(Path, "unlink", interrupted)
        if interrupt_after is None:
            assert f4._discard_native_extraction_copies(original, original_stat, root, members) == sum(map(len, entries.values()))
        else:
            with pytest.raises(RuntimeError, match="INJECTED_"):
                f4._discard_native_extraction_copies(original, original_stat, root, members)
    assert original.read_bytes() == original_bytes and new_evidence.is_file()
    f4._discard_native_extraction_copies(original, original_stat, root, members)
    assert f4._discard_native_extraction_copies(original, original_stat, root, members) == 0
    assert set(path for path in root.rglob("*") if path.is_file()) == {new_evidence}
    assert read_safe_zip(original) == entries


@pytest.mark.parametrize("damage", ["source", "copy", "symlink"])
def test_extraction_cleanup_rejects_changed_bytes_before_any_deletion(tmp_path, damage):
    original = tmp_path / "original.zip"
    entries = {"first.bin": RISK, "second.bin": RISK}
    write_deterministic_zip(original, entries)
    original_stat = original.stat()
    root = tmp_path / "extracted"
    members = extract_safe_zip(original, root, expected_members=set(entries), max_member_bytes=1024, max_total_bytes=2048)
    if damage == "source":
        original.write_bytes(b"UNFITTED_CHANGED_ORIGINAL")
    elif damage == "copy":
        (root / "second.bin").write_bytes(b"UNFITTED_CHANGED_COPY")
    else:
        (root / "second.bin").unlink()
        (root / "second.bin").symlink_to(original)
    with pytest.raises(ContractError, match="NATIVE_CLEANUP_"):
        f4._discard_native_extraction_copies(original, original_stat, root, members)
    assert (root / "first.bin").read_bytes() == RISK and (root / "second.bin").exists()


@pytest.mark.parametrize("failed_replay", [False, True])
def test_learning_leaf_prunes_only_after_successful_complete_comparison(tmp_path, monkeypatch, failed_replay):
    cell = {"family": "RSF", "outer_fold": 1, "repeat": 2, "inner_fold": 1,
            "imputations": 5, "sample_fraction": .4, "seed_ordinal": 1}
    model = {"UNFITTED": True}
    source = {"models": {(1, "RSF"): model}, "f1_manifest": {"identity": "a" * 64},
              "binding_contract": {}, "covariates_csv": b"UNFITTED", "response_csv": b"UNFITTED"}
    score = {"metric_support": {"status": "ESTIMABLE", "value": .12345678901234567, "support": []}}
    prediction = {"UNFITTED_FULL_PRECISION": [.12345678901234567]}
    entries = {"native-risk.bin": RISK, "prediction.json": canonical_json_bytes(prediction),
               "score.json": canonical_json_bytes(score)}
    path = tmp_path / "cell.zip"
    indexed(path, "learning-cell.json", {"kind": "PADML_F4_LEARNING_CELL_NATIVE_V1", "cell": cell,
        "f1_identity": "a" * 64, "model_sha256": sha256_bytes(canonical_json_bytes(model)),
        "selector_grids": {"coarse": [.1], "fine": []},
        "members": {name: {"sha256": sha256_bytes(raw), "size_bytes": len(raw)} for name, raw in entries.items()}}, entries)
    original = path.read_bytes()
    monkeypatch.setattr(f4, "_learning_native_member_names", lambda *a: set(entries))
    def selector(*args, **kwargs):
        assert kwargs["retain_evidence"] is True
        (args[-1].parent / "new-selector-replay.json").write_bytes(b"UNFITTED_NEW_REPLAY")
        return {"coarse_alpha_order": [.1], "fine_alpha_order": []}, {}
    monkeypatch.setattr(f4, "_replay_learning_curve_selector", selector)
    monkeypatch.setattr(f4, "_learning_native_predictions", lambda *a, **k: prediction)
    actual_score = copy.deepcopy(score)
    if failed_replay:
        actual_score["metric_support"]["value"] = .22345678901234567
    monkeypatch.setattr(f4, "_learning_curve_metric", lambda *a: actual_score)
    # Restore only this production leaf; the autouse guard still forbids all scientific calls.
    # The real function was saved before the guard installed.
    monkeypatch.setattr(f4, "load_learning_curve_cell_archive", LEARNING_CELL_READER)
    evidence = tmp_path / "native-review"
    if failed_replay:
        with pytest.raises(ContractError, match="PREDICTION_REPLAY_MISMATCH"):
            f4.load_learning_curve_cell_archive(path, frozen_source=source, replay_evidence=evidence)
        assert all((evidence / "archive" / name).read_bytes() == raw for name, raw in entries.items())
    else:
        result = f4.load_learning_curve_cell_archive(path, frozen_source=source, replay_evidence=evidence)
        assert result["row"]["ibs_0_24"] == score["metric_support"]["value"]
        assert not any((evidence / "archive" / name).exists() for name in entries)
    assert (evidence / "score.json").read_bytes() == canonical_json_bytes(actual_score)
    assert (evidence / "prediction.json").read_bytes() == canonical_json_bytes(prediction)
    assert (evidence / "archive/new-selector-replay.json").read_bytes() == b"UNFITTED_NEW_REPLAY"
    assert path.read_bytes() == original
