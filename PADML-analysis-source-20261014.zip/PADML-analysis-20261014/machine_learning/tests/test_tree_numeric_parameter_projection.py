"""Actual numeric call boundaries plus strict tree-health checks; synthetic only.

The focused tests execute each production health-call AST, not a copied
parameter expression. End-to-end contracts stay in the original shard tests.
No model is fitted, loaded or replayed here.
"""
import ast
import copy
import inspect

import pytest

from padml import f4_compact, f5, f5_sensitivity, nested_loco
from padml.bundle import ContractError
from padml.f2_kernel import _locked_family_parameters


CONSUMERS = (
    nested_loco._validate_fresh_score_component_numbers,
    f4_compact._o_fit_final_numbers,
    f5._full_final_component_numbers,
    f5_sensitivity._ablation_component_numbers,
)
COLUMN_MAP = [{"parent": "SYNTHETIC", "columns": ["x1", "x2", "x3", "x4"]}]


def _synthetic_tree(family):
    common = {"engine_threads": 1, "final_model_fit_count": 1,
              "converged": True, "warning_count": 0, "independent_variable_count": 4}
    if family == "RSF":
        locked = {"family": family, "parameters": {
            "num.trees": 1000, "mtry_fraction": "0.50", "min.node.size": 5,
            "max.depth": 3, "sample.fraction": 1, "splitrule": "logrank"}}
        health = {**common, "engine": "ranger::ranger", "num_trees": 1000,
                  "tree_count": 1000, "mtry": 2, "death_time_count": 12,
                  "prediction_error": .25}
    else:
        locked = {"family": family, "selected_trees": 7, "parameters": {
            "interaction.depth": 1, "n.minobsinnode": 5, "bag.fraction": .7,
            "n.trees.max": 100, "shrinkage": .05,
            "early_stopping_metric": "cox_deviance",
            "post_selection_refit": "full_main_training_at_selected_n_trees",
            "locked_iteration_mode": "full_main_training_without_reselection"}}
        health = {**common, "engine": "gbm::gbm", "selected_trees": 7,
                  "tree_count": 7, "training_loss_count": 7, "training_row_count": 40,
                  "minimum_training_loss": 1., "maximum_training_loss": 2.,
                  "stopping_reselected": False, "training_only_stop_count": 0,
                  "cox_objective": {"implementation": "GROUPED_BRESLOW_V1",
                      "engine_version": "2.3.1.9001", "source_correction": "cox-breslow-ties-v1"}}
    return locked, health


@pytest.mark.parametrize("family", ["RSF", "GBM_COX"])
def test_original_health_validator_still_rejects_unprojected_owner_spec(family):
    locked, health = _synthetic_tree(family)
    with pytest.raises(ContractError):
        f5._validate_final_r_fit_health(family, health, locked,
            ordered_parent_column_map=COLUMN_MAP, training_count=40)
    assert f5._validate_final_r_fit_health(family, health, _locked_family_parameters(family, locked),
        ordered_parent_column_map=COLUMN_MAP, training_count=40) == health


@pytest.mark.parametrize("consumer", CONSUMERS, ids=lambda value: value.__name__)
@pytest.mark.parametrize("family", ["RSF", "GBM_COX"])
@pytest.mark.parametrize("damage", [None, "health", "warning", "locked"])
def test_production_numeric_call_uses_engine_projection_without_relaxing_health(consumer, family, damage):
    locked, health = _synthetic_tree(family)
    if damage == "health":
        health["mtry" if family == "RSF" else "tree_count"] += 1
    elif damage == "warning":
        health["warning_count"] = 1
    elif damage == "locked":
        locked["family"] = "UNSUPPORTED"
    tree = ast.parse(inspect.getsource(consumer))
    calls = [node for node in ast.walk(tree) if isinstance(node, ast.Call)
             and isinstance(node.func, ast.Name) and node.func.id == "_validate_final_r_fit_health"]
    assert len(calls) == 1
    expression = compile(ast.fix_missing_locations(ast.Expression(copy.deepcopy(calls[0]))),
                         inspect.getfile(consumer), "eval")
    scope = {"family": family, "health": health, "evidence": {"fit_health": health},
             "task": {"parameters": locked}, "column_map": COLUMN_MAP,
             "columns_by_parent": COLUMN_MAP, "training": list(range(40)),
             "definition": {"fit_ids": list(range(40))}, "options": {},
             "lambda_source_column_map": None, "_locked_family_parameters": _locked_family_parameters,
             "_validate_final_r_fit_health": f5._validate_final_r_fit_health}
    if damage is None:
        assert eval(expression, scope) == health
    else:
        with pytest.raises(ContractError):
            eval(expression, scope)
