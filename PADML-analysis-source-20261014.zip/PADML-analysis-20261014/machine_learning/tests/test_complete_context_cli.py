"""Zero-fit original CLI argument forwarding; no scientific acceptance claim."""
import copy
import sys
from pathlib import Path

import pytest

from padml import f4, f5, f5_sensitivity as sensitivity
from padml.bundle import ContractError, canonical_json_bytes


@pytest.mark.parametrize("damage", [None, "mixed", "bad-path", "bad-publication"])
def test_primary_complete_context_cli_paths_and_original_call(tmp_path, monkeypatch, capsys, damage):
    monkeypatch.chdir(tmp_path)
    context = {"science_decision": {"original": True}, "resource_policy": {"original": True},
        "retained_bytes_per_component": 1, "expanded_bytes_per_component": 2, "shared_storage_bytes": 3,
        "search_roots": {"GBM_COX": "completed"}, "search_source_bundles": {"GBM_COX": "source.zip"},
        "pending_searches": {"RSF": {"retained_q_input": "prefix/input.json", "retained_input_producer": None,
            "continuous_batch_root": "batches", "q_batch_options": {
                "prepare_only": True, "task_ids": None, "batch_root": None,
                "q_batches": ["s1-real-batch", "s3b1-real-batch"], "retained_bytes_per_task": 4,
                "primary_rsf_preparation": "base.zip", "primary_rsf_producer": "9ba.zip",
                "retained_primary_rsf_q_source_bundle": "60233.zip",
                "primary_rsf_s1_summary": "summary", "primary_rsf_s1_summary_sha256": "a" * 64,
                "s1_summary_recovery_call_limit": 0,
                **{"primary_rsf_" + stage + "_evidence": {"original-key": stage + ".json"}
                   for stage in ("s2", "s3a", "s3b1")},
                "primary_q_input_publication": [{"path": "publication.json", "sha256": "b" * 64}]}}}}
    if damage == "bad-path": context["pending_searches"]["RSF"]["retained_q_input"] = 123
    if damage == "bad-publication": context["pending_searches"]["RSF"]["q_batch_options"]["primary_q_input_publication"] = [None]
    file = tmp_path / "context.json"; file.write_bytes(canonical_json_bytes(context))
    calls = []
    monkeypatch.setattr(f4, "execute_o_fit_bundle", lambda *a, **kw: (calls.append((a, kw)) or {"status": "FORWARDED"}))
    argv = ["padml-f4", "o-fit-execute", str(tmp_path), str(tmp_path / "output.zip"),
            "--outer-fold", "4", "--primary-development", str(file)]
    if damage == "mixed": argv += ["--prepare-only"]
    monkeypatch.setattr(sys, "argv", argv)
    if damage:
        with pytest.raises(ContractError): f4.main()
        assert calls == []
        return
    f4.main()
    assert len(calls) == 1 and calls[0][0] == (tmp_path, None, tmp_path / "output.zip")
    received = calls[0][1]["primary_development"]
    expected = copy.deepcopy(context)
    expected["search_roots"]["GBM_COX"] = tmp_path / "completed"
    expected["search_source_bundles"]["GBM_COX"] = tmp_path / "source.zip"
    row = expected["pending_searches"]["RSF"]
    row["retained_q_input"] = tmp_path / "prefix/input.json"
    row["continuous_batch_root"] = tmp_path / "batches"
    options = row["q_batch_options"]
    for key in ("primary_rsf_preparation", "primary_rsf_producer", "retained_primary_rsf_q_source_bundle", "primary_rsf_s1_summary"):
        options[key] = tmp_path / options[key]
    options["q_batches"] = [tmp_path / name for name in options["q_batches"]]
    for stage in ("s2", "s3a", "s3b1"):
        options["primary_rsf_" + stage + "_evidence"]["original-key"] = tmp_path / (stage + ".json")
    options["primary_q_input_publication"] = ({"path": tmp_path / "publication.json", "sha256": "b" * 64},)
    assert received == expected  # No field, SHA, permission or coordinate is dropped.
    assert "FORWARDED" in capsys.readouterr().out


@pytest.mark.parametrize("damage", [None, "mixed", "unknown", "bad-batches"])
def test_aar_complete_context_cli_preserves_mixed_branch_roots(tmp_path, monkeypatch, capsys, damage):
    monkeypatch.chdir(tmp_path)
    from padml.nested_loco import AAR_ESTIMANDS
    direct, total, redevelopment = AAR_ESTIMANDS
    context = {"input_bundle": "input.zip", "q_roots": {direct: "complete"},
        "q_batches": {total: ["prefix-batch"], redevelopment: []},
        "continuous_batch_root": "owner", "retained_bytes_per_task": 12,
        "retained_bytes_per_component": 34, "selector_root": "selector",
        "retained_primary_source_bundle": "primary.zip", "retained_selector_source_bundle": "selector.zip",
        "retained_selector_executor_source_bundle": "selector-executor.zip",
        "retained_a12_q_executor_source_bundle": "a12-q-executor.zip",
        "retained_gbm_q_source_bundle": ["q-source.zip"]}
    if damage == "unknown": context["prepare_final"] = True
    if damage == "bad-batches": context["q_batches"][total] = "not-a-list"
    file = tmp_path / "context.json"; file.write_bytes(canonical_json_bytes(context))
    calls = []
    monkeypatch.setattr(sensitivity, "execute_a12_outer_bundle", lambda *a, **kw: (calls.append((a, kw)) or {"status": "FORWARDED"}))
    argv = ["padml-f5", "a12-outer", "native.zip", "output.zip", "--execution-context", str(file)]
    if damage == "mixed": argv += ["--input-bundle", "other.zip"]
    monkeypatch.setattr(sys, "argv", argv)
    if damage:
        with pytest.raises(ContractError): f5.main()
        assert calls == []
        return
    f5.main()
    assert len(calls) == 1 and calls[0][0] == (tmp_path / "native.zip", tmp_path / "output.zip")
    expected = {**context, **{key: tmp_path / context[key] for key in (
        "input_bundle", "continuous_batch_root", "selector_root", "retained_primary_source_bundle",
        "retained_selector_source_bundle", "retained_selector_executor_source_bundle",
        "retained_a12_q_executor_source_bundle")},
        "retained_gbm_q_source_bundle": [tmp_path / "q-source.zip"],
        "q_roots": {direct: tmp_path / "complete"},
        "q_batches": {total: [tmp_path / "prefix-batch"], redevelopment: []}}
    assert calls[0][1] == expected
    assert "FORWARDED" in capsys.readouterr().out


@pytest.mark.parametrize("prepare_final", [False, True])
def test_aar_original_cli_full_or_prepare_call_shape_unchanged(tmp_path, monkeypatch, prepare_final):
    calls = []
    monkeypatch.setattr(sensitivity, "execute_a12_outer_bundle", lambda *a, **kw: (calls.append(kw) or {}))
    argv = ["padml-f5", "a12-outer", str(tmp_path / "native.zip"), str(tmp_path / "output.zip"),
        "--input-bundle", str(tmp_path / "input.zip"), "--retained-bytes-per-component", "4096"]
    if prepare_final:
        argv.append("--prepare-final")
    monkeypatch.setattr(sys, "argv", argv)
    f5.main()
    assert calls == [{"input_bundle": tmp_path / "input.zip", "retained_bytes_per_component": 4096,
                      **({"prepare_final": True} if prepare_final else {})}]


@pytest.mark.parametrize("mode", ["initial", "prepared"])
def test_evaluation_complete_context_cli_forwards_one_original_call(tmp_path, monkeypatch, capsys, mode):
    monkeypatch.chdir(tmp_path)
    context = {"mode": mode, "resource_policy": {"original": True},
               "retained_bytes_per_replicate": 4096,
               "retained_primary_source_bundle": "primary-source.zip"}
    if mode == "initial":
        context.update(f2_run_root="f2", sources=[f"aar-{index}.zip" for index in range(1, 7)],
            primary_input_bundles=[f"primary-{index}.zip" for index in range(1, 7)],
            primary_compiled_input_records=[{"outer": index} for index in range(1, 7)],
            input_bundles=[f"a12-input-{index}.zip" for index in range(1, 7)],
            retained_rng_archive="first-rng.zip",
            retained_rng_preparation_record={"original_first_rng": True})
    else:
        context.update(prepared_input_record={"original_prepare": True},
            point_archive="points.zip", bootstrap_shards=[f"shard-{index}.zip" for index in range(1, 7)],
            retained_rng_archive="first-rng.zip",
            retained_rng_preparation_record={"original_first_rng": True})
    context_file = tmp_path / "evaluation-context.json"
    context_file.write_bytes(canonical_json_bytes(context))
    calls = []
    monkeypatch.setattr(sensitivity, "execute_a12_bundle",
        lambda *args, **kwargs: (calls.append((args, kwargs)) or {"status": "FORWARDED"}))
    monkeypatch.setattr(sys, "argv", ["padml-f5", "a12-evaluate", "input.zip", "result.zip",
                                     "--execution-context", str(context_file)])
    f5.main()
    assert len(calls) == 1
    assert calls[0][0] == (tmp_path / "input.zip", tmp_path / "result.zip")
    options = calls[0][1]
    assert options["complete_evaluation"] is True
    assert options["resource_policy"] == context["resource_policy"]
    assert options["retained_bytes_per_replicate"] == 4096
    assert options["retained_primary_source_bundle"] == tmp_path / "primary-source.zip"
    assert options["retained_rng_archive"] == tmp_path / "first-rng.zip"
    assert options["retained_rng_preparation_record"] == {"original_first_rng": True}
    if mode == "initial":
        assert options["f2_run_root"] == tmp_path / "f2"
        assert options["sources"] == [tmp_path / f"aar-{index}.zip" for index in range(1, 7)]
        assert options["primary_input_bundles"] == {
            index: tmp_path / f"primary-{index}.zip" for index in range(1, 7)}
        assert options["primary_compiled_input_records"] == {
            index: {"outer": index} for index in range(1, 7)}
        assert options["input_bundles"] == {
            index: tmp_path / f"a12-input-{index}.zip" for index in range(1, 7)}
    else:
        assert options["prepared_input_record"] == {"original_prepare": True}
        assert options["point_archive"] == tmp_path / "points.zip"
        assert options["bootstrap_shards"] == [tmp_path / f"shard-{index}.zip" for index in range(1, 7)]
    assert '"FORWARDED"' in capsys.readouterr().out


@pytest.mark.parametrize("damage", ["unknown", "malformed_mode", "missing_shard", "mixed_modes", "rng_pair"])
def test_evaluation_complete_context_cli_rejects_invalid_context_before_call(tmp_path, monkeypatch, damage):
    monkeypatch.chdir(tmp_path)
    context = {"mode": "prepared", "resource_policy": {"original": True},
        "retained_bytes_per_replicate": 4096, "prepared_input_record": {"original_prepare": True},
        "point_archive": "points.zip", "bootstrap_shards": [f"shard-{index}.zip" for index in range(1, 7)],
        "retained_rng_archive": "rng.zip", "retained_rng_preparation_record": {"original_first_rng": True}}
    if damage == "unknown": context["new_science"] = True
    elif damage == "malformed_mode": context["mode"] = []
    elif damage == "missing_shard": context["bootstrap_shards"].pop()
    elif damage == "mixed_modes": context["sources"] = ["aar.zip"] * 6
    else: context.pop("retained_rng_preparation_record")
    context_file = tmp_path / "evaluation-context.json"
    context_file.write_bytes(canonical_json_bytes(context))
    calls = []
    monkeypatch.setattr(sensitivity, "execute_a12_bundle",
        lambda *args, **kwargs: (calls.append((args, kwargs)) or {}))
    monkeypatch.setattr(sys, "argv", ["padml-f5", "a12-evaluate", "input.zip", "result.zip",
                                     "--execution-context", str(context_file)])
    with pytest.raises(ContractError, match="F5_A12_EVALUATION_CONTEXT_INVALID"):
        f5.main()
    assert calls == []
