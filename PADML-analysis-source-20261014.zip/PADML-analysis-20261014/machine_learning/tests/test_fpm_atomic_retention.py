"""Persist/reload actual native FPM predictions; never run a scientific engine."""
import copy
import os
from pathlib import Path

import pytest

from padml import f2_kernel as native
from padml.bundle import ContractError, canonical_json_bytes, read_safe_zip, strict_json_bytes, write_deterministic_zip


@pytest.fixture
def actual(tmp_path, monkeypatch):
    precision = os.environ.get("PADML_TEST_FPM_PRECISION_ARCHIVE")
    center = os.environ.get("PADML_TEST_FPM_CENTER_ARCHIVE")
    if not precision or not center:
        pytest.skip("Immutable precision and response archives required")
    entries = read_safe_zip(Path(precision))
    response = read_safe_zip(Path(center))["data-binding-payload/binding/response-seal.csv"]
    spec = strict_json_bytes(entries["spec.json"])
    task = {**spec["producer_tasks"][0], "transform_recipe": spec["transform_recipe"]}
    partition = copy.deepcopy(spec["registered_partitions"]["diagnostic_partitions"][0])
    fields, by_id = native._response_rows(response)
    partition["fit_response"] = native._write_response_subset(fields, by_id, partition["fit_ids"], tmp_path / "fit.csv")
    partition["evaluation_response"] = native._write_response_subset(fields, by_id, partition["evaluation_ids"], None)
    child = {key: value for key, value in spec.items() if key not in
             {"action", "output_path", "registered_partitions", "transform_recipe", "producer_tasks"}}
    scratch = tmp_path / "atomic"
    scratch.mkdir()
    job = {"route": "R", "atomic_task_id": task["task_id"],
           "top_task_id": task["task_id"].rsplit("::", 2)[0], "spec": child,
           "registered": spec["registered_partitions"], "fit_task": task,
           "evaluation_partition": partition, "scratch": str(scratch),
           "repo_root": str(Path(native.__file__).resolve().parent)}
    root = scratch / f"f2-r-batch-{native._sha([task['task_id']])[:16]}"
    root.mkdir()
    (root / "spec.json").write_bytes(entries["spec.json"])
    (root / "output.json").write_bytes(entries["output.json"])
    evaluated = native._consume_r_prediction(strict_json_bytes(entries["output.json"]),
                child, spec["registered_partitions"], [task], root, "IBS", partition, cleanup=False)
    row = {"top_task_id": job["top_task_id"], "atomic_task_id": job["atomic_task_id"],
           "evaluated": evaluated[0]}
    row["task_identity_sha256"] = native._sha(row)
    destination = tmp_path / "retained"
    destination.mkdir()
    def forbid_fit(*args, **kwargs):
        pytest.fail("Atomic retention/replay must not fit or call a native engine")
    monkeypatch.setattr(native.subprocess, "run", forbid_fit)
    return job, row, root, destination


def plan(jobs):
    return [{"kind": "PADML_F2_P2C2T_ATOMIC_JOB_PLAN", "pool_workers": 24,
             "engine_threads": 1, "jobs": jobs, "expected_fit_count": len(jobs),
             "task_id": jobs[0]["top_task_id"]}]


def complete_first(job, row, monkeypatch):
    def spawn(fn, tasks, *, selected_slots, on_result):
        assert tasks[0] == job
        on_result(0, row)
        if len(tasks) > 1:
            raise ContractError("BOUNDED_SPAWN_CHILD_FAILED:1:fixed failure fixture")
        return [row]
    monkeypatch.setattr(native, "_bounded_ordered_spawn", spawn)


def test_success_survives_later_failure_and_restart_without_refit(actual, monkeypatch):
    job, row, root, destination = actual
    later = copy.deepcopy(job)
    later["atomic_task_id"] += "::UNEXECUTED_FAILURE_FIXTURE"
    complete_first(job, row, monkeypatch)
    with pytest.raises(ContractError, match="BOUNDED_SPAWN_CHILD_FAILED"):
        native._run_p2c2t_atomic_window(plan([job, later]), retained_root=destination)
    path = destination / f"{native._sha(job['atomic_task_id'])}.zip"
    assert path.is_file() and not root.exists()
    assert set(read_safe_zip(path)) == {"fixed-task.json", "engine-spec.json", "consumer-result.json", "output.json"}
    monkeypatch.setattr(native, "_bounded_ordered_spawn", lambda *a, **k: pytest.fail("Unexpected refit"))
    assert native._run_p2c2t_atomic_window(plan([job]), retained_root=destination) == [[row["evaluated"]]]


def test_publication_failure_keeps_original_native_files(actual, monkeypatch):
    job, row, root, destination = actual
    complete_first(job, row, monkeypatch)
    def fail_publish(*args, **kwargs):
        raise OSError("fixture durable publication failure")
    monkeypatch.setattr(native, "write_deterministic_zip", fail_publish)
    with pytest.raises(OSError, match="publication failure"):
        native._run_p2c2t_atomic_window(plan([job]), retained_root=destination)
    assert (root / "spec.json").is_file() and (root / "output.json").is_file()
    assert not list(destination.iterdir())


def test_published_success_survives_cleanup_failure_and_repeated_replay(actual, monkeypatch):
    job, row, root, destination = actual
    complete_first(job, row, monkeypatch)
    remove = native.shutil.rmtree
    def fail_cleanup(path, *args, **kwargs):
        if path == root:
            raise OSError("fixture after publication before cleanup")
        return remove(path, *args, **kwargs)
    monkeypatch.setattr(native.shutil, "rmtree", fail_cleanup)
    with pytest.raises(OSError, match="after publication"):
        native._run_p2c2t_atomic_window(plan([job]), retained_root=destination)
    path = destination / f"{native._sha(job['atomic_task_id'])}.zip"
    assert path.is_file() and root.is_dir()
    assert native._replay_p2c2t_fpm_artifact(job, path) == row
    assert native._replay_p2c2t_fpm_artifact(job, path) == row


def test_failure_keeps_native_rds_success_cleans_it(actual):
    job, row, root, destination = actual
    # Opaque bytes test file ownership only; no synthetic fit is admitted.
    for member in ("fit-input.rds", "fit.rds"):
        (root / member).write_bytes(b"OPAQUE_FAILURE_EVIDENCE_NOT_A_MODEL")
    output = strict_json_bytes((root / "output.json").read_bytes())
    bad = copy.deepcopy(output)
    bad["tasks"][0]["stopping"]["warning_count"] = 1
    with pytest.raises(ContractError):
        native._consume_r_prediction(bad, job["spec"], job["registered"], [job["fit_task"]],
                                     root, "IBS", job["evaluation_partition"], cleanup=False)
    assert (root / "fit.rds").is_file() and (root / "fit-input.rds").is_file()
    native._consume_r_prediction(output, job["spec"], job["registered"], [job["fit_task"]],
                                 root, "IBS", job["evaluation_partition"], cleanup=False)
    assert {p.name for p in root.iterdir()} == {"spec.json", "output.json"}


@pytest.mark.parametrize("fault", ["missing_raw", "raw_health", "metric", "seed", "unknown_member"])
def test_bad_retained_output_is_rejected_before_any_fit(actual, tmp_path, monkeypatch, fault):
    job, row, root, destination = actual
    complete_first(job, row, monkeypatch)
    native._run_p2c2t_atomic_window(plan([job]), retained_root=destination)
    path = destination / f"{native._sha(job['atomic_task_id'])}.zip"
    entries = read_safe_zip(path)
    if fault == "missing_raw":
        entries.pop("output.json")
    elif fault == "unknown_member":
        entries["unbound.json"] = b"{}"
    elif fault == "raw_health":
        output = strict_json_bytes(entries["output.json"])
        output["tasks"][0]["stopping"]["warning_count"] = 1
        entries["output.json"] = canonical_json_bytes(output)
    elif fault == "metric":
        row = copy.deepcopy(row)
        row["evaluated"]["ibs_0_24"] += 0.1
        row["task_identity_sha256"] = native._sha({k: v for k, v in row.items() if k != "task_identity_sha256"})
        entries["consumer-result.json"] = canonical_json_bytes(row)
    else:
        task = strict_json_bytes(entries["fixed-task.json"])
        task["seed"] += 1
        entries["fixed-task.json"] = canonical_json_bytes(task)
    corrupted = tmp_path / "corrupted.zip"
    write_deterministic_zip(corrupted, entries)
    with pytest.raises(ContractError):
        native._replay_p2c2t_fpm_artifact(job, corrupted)
