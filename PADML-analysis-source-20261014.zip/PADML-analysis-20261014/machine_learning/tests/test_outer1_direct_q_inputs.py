"""Original direct-CoxTime prepared transport, UNFITTED only."""
import pytest

from test_outer6_q_resource_evidence import (
    test_original_refit_publisher_and_worker_keep_three_operational_leaves as _transport,
)
from test_nested_aar_mice import aar_source, unfitted_redevelopment_inputs, unfitted_selector_engines  # noqa: F401
from test_outer2_q_source_transport import test_outer2_stop200_original_batch_consumer_feeds_refit200_without_new_leaf as _consume


@pytest.mark.parametrize("stage,refit", [("S1", True), ("S2", False), ("S3A", True)])
@pytest.mark.parametrize("damage", [None, "missing_predecessor", "wrong_count", "changed_input"])
def test_direct_preserves_legacy_primary_role_and_public_branch(tmp_path, monkeypatch, stage, refit, damage):
    _transport(tmp_path, monkeypatch, damage, stage, refit, direct=True)


@pytest.mark.parametrize("unfitted_redevelopment_inputs", ["COXTIME_SET_A"], indirect=True)
def test_direct_original_legacy_stop60_feeds_refit60_without_new_leaf(
        unfitted_redevelopment_inputs, unfitted_selector_engines, aar_source, tmp_path, monkeypatch):
    _consume(unfitted_redevelopment_inputs, unfitted_selector_engines, aar_source,
             tmp_path, monkeypatch, family="COXTIME_SET_A", direct=True)
