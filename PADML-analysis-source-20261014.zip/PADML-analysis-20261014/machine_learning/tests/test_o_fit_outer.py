"""Whole-outer transport/orchestration tests; all predictive leaves are UNFITTED.

These tests never call model/STOP/MICE/selector/R metric engines. Native model
input and object replay are tested separately in test_o_fit_native.py.
"""

import copy
from pathlib import Path

import pytest

from padml import f4
from padml.bundle import ContractError, canonical_json_bytes, read_safe_zip, sha256_bytes, strict_json_bytes, write_deterministic_zip
from test_f4 import o_fit_bundle_fixture, o_fit_evidence_rows, o_fit_source_fixture


def outer_fixture(family="RSF"):
    frozen = o_fit_source_fixture(family)
    frozen["f1_manifest"] = {"identity": sha256_bytes(b"UNFITTED_F1_IDENTITY")}
    for (outer, _), model in frozen["models"].items():
        model.update(fold=outer, family=family)
        if family == "FPM_TVC_SET_A" and outer in {1, 3, 6}:
            model["fpm_fixed_reuse"] = {"task_id": f"FINAL_OUTER_M{ {1: 19, 3: 8, 6: 15}[outer]:02d}",
                                      "sha256": sha256_bytes(b"UNFITTED_ORIGINAL"), "size_bytes": 17}
    registered = {}
    for outer in range(1, 7):
        rows = []
        for kind, section in (("OUTER", "outer"), ("INNER", "inner"), ("STOP", "stopping")):
            for row in frozen["registry"][section]:
                if row["outer_fold"] == outer:
                    rows.append({"kind": kind, "repeat": row.get("repeat", 0), "inner_fold": row.get("inner_fold", 0),
                                 "fit_ids": row["analysis_ids"], "partition_id": row["partition_id"],
                                 "covariates": {"input_dir": "/UNFITTED/NO_REAL_MICE"},
                                 "fit_response": {"path": "/UNFITTED/NO_REAL_RESPONSE"}})
        registered[outer] = {"partitions": rows}
    return frozen, registered


def fixed_rows(outer, family):
    rows = [copy.deepcopy(row) for row in o_fit_evidence_rows() if row["outer_fold"] == outer]
    for row in rows:
        row["family"] = family
        row["producer_evidence_sha256"] = sha256_bytes(canonical_json_bytes({
            key: value for key, value in row.items() if key != "producer_evidence_sha256"}))
    return rows


def install_unfitted_orchestration(monkeypatch, family="RSF", fail_kind=None, duplicate_kind=None):
    frozen, registered = outer_fixture(family)
    calls = {"materialize": [], "batches": [], "completed": [], "original": [], "stop_replayed": []}
    monkeypatch.setattr(f4, "load_f4_inputs", lambda *a, **k: {"o_fit_source": frozen})
    monkeypatch.setattr(f4, "_load_o_fit_selection", lambda *a: {"locked_family": family})
    monkeypatch.setattr(f4, "resolve_pool_workers", lambda workers: 24)
    def materialize(source, outer, root):
        assert source is frozen
        root.mkdir()
        calls["materialize"].append(outer)
        return registered[outer]
    monkeypatch.setattr(f4, "_materialize_o_fit_fold", materialize)
    def prepare(model, part, source, *, stop_evidence=None, replay_workers=None, replayed_stops=None):
        outer, repeat, inner = model["fold"], part["repeat"], part["inner_fold"]
        needs_stop = family in {"GBM_COX", "XGBOOST_COX"} and part["kind"] == "INNER"
        assert (stop_evidence is not None) == needs_stop
        if needs_stop:
            assert replay_workers == 24
            stop, archives = stop_evidence
            assert (stop["kind"], stop["repeat"], stop["inner_fold"]) == ("STOP", repeat, inner)
            assert set(archives) == set(f4._o_fit_component_names(outer, repeat, inner, stop=True))
            assert all(path.is_file() for path in archives.values())
            assert all(read_safe_zip(path) == {"UNFITTED.txt": name.encode()}
                       for name, path in archives.items())
            assert set(replayed_stops) == set(archives)
            for imp, name in enumerate(f4._o_fit_component_names(outer, repeat, inner, stop=True), 1):
                replayed = replayed_stops[name]
                assert replayed["archive"] == archives[name]
                assert strict_json_bytes(replayed["entries"]["task.json"])["imputation"] == imp
                assert replayed["lock"] == {"UNFITTED": True, "imputation": imp}
        names = f4._o_fit_component_names(outer, repeat, inner, stop=part["kind"] == "STOP")
        if part["kind"] == duplicate_kind:
            names[-1] = names[0]
        return [{"name": name, "entries": {"task.json": canonical_json_bytes({"imputation": imp})}}
                for imp, name in enumerate(names, 1)]
    monkeypatch.setattr(f4, "_prepare_o_fit_partition", prepare)
    def unfitted_component(job):
        root = Path(job["root"])
        root.mkdir()
        (root / "UNFITTED.txt").write_bytes(job["name"].encode())
        write_deterministic_zip(root.with_suffix(".zip"), {"UNFITTED.txt": root / "UNFITTED.txt"})
        calls["completed"].append(job["name"])
        return {"UNFITTED": True}
    monkeypatch.setattr(f4, "_execute_f4_model_component", unfitted_component)
    monkeypatch.setattr(f4, "_execute_f4_stop_component", unfitted_component)
    def unfitted_stop_replay(job):
        assert read_safe_zip(job["archive"]) == {"UNFITTED.txt": job["name"].encode()}
        calls["stop_replayed"].append(job["name"])
        return {"UNFITTED": True, "imputation": strict_json_bytes(job["entries"]["task.json"])["imputation"]}
    monkeypatch.setattr(f4, "_replay_f4_stop_component", unfitted_stop_replay)
    def pool(worker, jobs, *, selected_slots):
        assert selected_slots == 24
        kind = ("STOP_REPLAY" if worker is f4._replay_f4_stop_component else
                "STOP" if jobs[0]["name"].endswith("_STOP") else "MODEL")
        calls["batches"].append((kind, len(jobs)))
        results = {}
        for index, job in enumerate(reversed(jobs)):
            if kind == fail_kind and index == 2:
                root = Path(job["root"])
                root.mkdir(exist_ok=True)
                (root / "native-failure.json").write_bytes(b'{"UNFITTED_FAILURE":true}')
                raise ContractError("UNFITTED_ATTRIBUTABLE_CHILD_FAILURE")
            results[job["name"]] = worker(job)
        return [results[job["name"]] for job in jobs]
    monkeypatch.setattr(f4, "_bounded_ordered_spawn", pool)
    monkeypatch.setattr(f4, "_o_fit_rows_from_native", lambda model, *a, **k: fixed_rows(model["fold"], family))
    def original(model, archive, *a, **k):
        assert archive.read_bytes() == b"UNFITTED_ORIGINAL"
        calls["original"].append(model["fold"])
        return {"fit_count": 0, "UNFITTED": True}
    monkeypatch.setattr(f4, "_replay_o_fit_fpm_retained", original)
    return frozen, registered, calls


@pytest.mark.parametrize("family,outer,counts", [
    ("RSF", 1, [("MODEL", 320)]),
    ("GBM_COX", 1, [("STOP", 300), ("STOP_REPLAY", 300), ("MODEL", 320)]),
    ("XGBOOST_COX", 1, [("STOP", 300), ("STOP_REPLAY", 300), ("MODEL", 320)]),
    ("FPM_TVC_SET_A", 1, [("MODEL", 319)]),
    ("FPM_TVC_SET_A", 3, [("MODEL", 319)]),
    ("FPM_TVC_SET_A", 6, [("MODEL", 319)]),
])
def test_outer_exec_exact_coordinates_once_and_native_members(monkeypatch, tmp_path, family, outer, counts):
    frozen, _, calls = install_unfitted_orchestration(monkeypatch, family)
    original = None
    if family == "FPM_TVC_SET_A":
        original = tmp_path / "original.zip"
        original.write_bytes(b"UNFITTED_ORIGINAL")
    target = tmp_path / "outer.zip"
    result = f4.execute_o_fit_bundle(tmp_path, tmp_path / "selection.zip", target,
                                   outer_fold=outer, workers=24, fpm_native_archive=original)
    assert result["outer_fold"] == outer and calls["materialize"] == [outer]
    assert calls["batches"] == counts
    expected = f4._o_fit_native_members(frozen["models"][outer, family])
    entries = read_safe_zip(target)
    assert set(entries) == expected | {"o-fit-execution.json"}
    assert sum("_R0_K0_" in name for name in calls["completed"]) == (19 if original else 20)
    assert len(calls["completed"]) == len(set(calls["completed"]))
    assert len(calls["stop_replayed"]) == len(set(calls["stop_replayed"])) == (300 if family in {"GBM_COX", "XGBOOST_COX"} else 0)
    assert calls["original"] == ([outer] if original else [])
    value = f4.load_o_fit_execution_archive(target, frozen_source=frozen)
    assert value["rows"] == fixed_rows(outer, family)


@pytest.mark.parametrize("kind,family", [("MODEL", "RSF"), ("STOP", "GBM_COX")])
def test_outer_failed_batch_retains_completed_and_failed_native(monkeypatch, tmp_path, kind, family):
    _, _, calls = install_unfitted_orchestration(monkeypatch, family, fail_kind=kind)
    target = tmp_path / "failed.zip"
    with pytest.raises(ContractError, match="UNFITTED_ATTRIBUTABLE"):
        f4.execute_o_fit_bundle(tmp_path, tmp_path / "selection.zip", target, outer_fold=1)
    assert not target.exists() and len(calls["completed"]) == 2
    work = target.with_name(target.name + ".work")
    assert len(list(work.glob("*/*.zip"))) == 2
    assert len(list(work.glob("*/*/native-failure.json"))) == 1
    assert len(calls["batches"]) == 1  # No retry or downstream model batch.


@pytest.mark.parametrize("family", ["GBM_COX", "XGBOOST_COX"])
def test_outer_retained_stops_are_read_only_and_never_refitted(monkeypatch, tmp_path, family):
    _, _, calls = install_unfitted_orchestration(monkeypatch, family)
    first = tmp_path / "first.zip"
    f4.execute_o_fit_bundle(tmp_path, tmp_path / "selection.zip", first, outer_fold=1)
    originals = tmp_path / "first.zip.work/stops"
    snapshots = {p.name: p.read_bytes() for p in originals.glob("*.zip")}
    calls["batches"].clear()
    calls["completed"].clear()
    calls["stop_replayed"].clear()
    monkeypatch.setattr(f4, "_execute_f4_stop_component", lambda *a, **k: pytest.fail("STOP_REFIT_FORBIDDEN"))
    resumed = tmp_path / "resumed.zip"
    f4.execute_o_fit_bundle(tmp_path, tmp_path / "selection.zip", resumed,
                           outer_fold=1, retained_stops=originals)
    assert calls["batches"] == [("STOP_REPLAY", 300), ("MODEL", 320)]
    assert len(calls["stop_replayed"]) == len(set(calls["stop_replayed"])) == 300
    assert len(calls["completed"]) == 320 and not any(n.endswith("_STOP") for n in calls["completed"])
    assert {p.name: p.read_bytes() for p in originals.glob("*.zip")} == snapshots
    assert resumed.read_bytes() == first.read_bytes()


@pytest.mark.parametrize("damage", ["missing", "extra", "symlink", "wrong_native"])
def test_outer_retained_stop_defect_never_starts_models(monkeypatch, tmp_path, damage):
    _, _, calls = install_unfitted_orchestration(monkeypatch, "XGBOOST_COX")
    originals = tmp_path / "retained-stops"
    originals.mkdir()
    names = [name for r in range(1, 4) for k in range(1, 6)
             for name in f4._o_fit_component_names(1, r, k, stop=True)]
    for name in names:
        write_deterministic_zip(originals / (name + ".zip"), {"UNFITTED.txt": name.encode()})
    first = originals / (names[0] + ".zip")
    if damage == "missing":
        first.unlink()
    elif damage == "extra":
        write_deterministic_zip(originals / "UNKNOWN.zip", {"UNFITTED.txt": b"UNKNOWN"})
    elif damage == "symlink":
        first.unlink()
        first.symlink_to(originals / (names[1] + ".zip"))
    else:
        first.write_bytes(b"NOT_AN_ARCHIVE")
    reason = "ZIP_INVALID" if damage == "wrong_native" else "RETAINED_STOPS_"
    with pytest.raises(ContractError, match=reason):
        f4.execute_o_fit_bundle(tmp_path, tmp_path / "selection.zip", tmp_path / "rejected.zip",
                               outer_fold=1, retained_stops=originals)
    assert all(kind == "STOP_REPLAY" for kind, _ in calls["batches"]) and calls["completed"] == []
    assert originals.is_dir() and not (tmp_path / "rejected.zip").exists()


def test_outer_native_stop_replay_failure_never_starts_model_pool(monkeypatch, tmp_path):
    _, _, calls = install_unfitted_orchestration(monkeypatch, "XGBOOST_COX", fail_kind="STOP_REPLAY")
    target = tmp_path / "failed-replay.zip"
    with pytest.raises(ContractError, match="UNFITTED_ATTRIBUTABLE_CHILD_FAILURE"):
        f4.execute_o_fit_bundle(tmp_path, tmp_path / "selection.zip", target, outer_fold=1)
    assert calls["batches"] == [("STOP", 300), ("STOP_REPLAY", 300)]
    assert len(calls["stop_replayed"]) == 2
    assert len(calls["completed"]) == 300 and all(name.endswith("_STOP") for name in calls["completed"])
    assert not target.exists()
    work = target.with_name(target.name + ".work")
    assert len(list((work / "stops").glob("*.zip"))) == 300
    assert len(list((work / "stops").glob("*/native-failure.json"))) == 1


@pytest.mark.parametrize("kind,family", [("OUTER", "RSF"), ("STOP", "GBM_COX")])
def test_outer_duplicate_component_rejected_before_dispatch(monkeypatch, tmp_path, kind, family):
    _, _, calls = install_unfitted_orchestration(monkeypatch, family, duplicate_kind=kind)
    with pytest.raises(ContractError, match="M20_REQUIRED"):
        f4.execute_o_fit_bundle(tmp_path, tmp_path / "selection.zip", tmp_path / "none.zip", outer_fold=1)
    assert calls["batches"] == []


@pytest.mark.parametrize("replay_workers", [None, 2])
def test_native_outer_six_archive_aggregate_canonical_and_resealed_negative(monkeypatch, tmp_path, replay_workers):
    frozen, _, _ = install_unfitted_orchestration(monkeypatch)
    sources = []
    for outer in range(1, 7):
        path = tmp_path / f"outer-{outer}.zip"
        f4.execute_o_fit_bundle(tmp_path, tmp_path / "selection.zip", path, outer_fold=outer)
        sources.append(path)
    original_bytes = [path.read_bytes() for path in sources]
    monkeypatch.setattr(f4.subprocess, "run", lambda *a, **k: pytest.fail("NO_REAL_SCIENTIFIC_CALL"))
    monkeypatch.setattr(f4, "_bounded_ordered_spawn", lambda *a, **k: pytest.fail("NO_ADDITIONAL_OUTER_POOL"))
    monkeypatch.setattr(f4, "resolve_pool_workers", lambda workers: workers)
    seen = []
    def replay(model, *args, **kwargs):
        assert kwargs.get("replay_workers") == replay_workers
        seen.append(model["fold"])
        return fixed_rows(model["fold"], "RSF")
    monkeypatch.setattr(f4, "_o_fit_rows_from_native", replay)
    forward, reverse = tmp_path / "forward.zip", tmp_path / "reverse.zip"
    for paths, target in ((sources, forward), (sources[::-1], reverse)):
        f4.aggregate_o_fit_execution_archives(paths, target, locked_family="RSF", frozen_source=frozen,
                                              replay_workers=replay_workers)
    assert forward.read_bytes() == reverse.read_bytes()
    aggregate = f4.load_o_fit_aggregate_archive(forward, frozen_source=frozen, replay_workers=replay_workers)
    assert seen == [*range(1, 7), *range(6, 0, -1), *range(1, 7)]
    assert [path.read_bytes() for path in sources] == original_bytes
    assert aggregate["rows"] == [row for o in range(1, 7) for row in fixed_rows(o, "RSF")]
    assert len(aggregate["source_archives"]) == 6 and len(aggregate["rows"]) == 18
    entries = read_safe_zip(sources[0])
    meta = strict_json_bytes(entries["o-fit-execution.json"])
    meta["rows"][0]["oof_ibs_0_24"] += 0.001
    meta["rows"][0]["producer_evidence_sha256"] = sha256_bytes(canonical_json_bytes({
        key: value for key, value in meta["rows"][0].items() if key != "producer_evidence_sha256"}))
    meta["identity_sha256"] = sha256_bytes(canonical_json_bytes({k: v for k, v in meta.items() if k != "identity_sha256"}))
    entries["o-fit-execution.json"] = canonical_json_bytes(meta)
    forged = tmp_path / "forged.zip"
    write_deterministic_zip(forged, entries)
    with pytest.raises(ContractError, match="EXECUTION_REPLAY_MISMATCH"):
        f4.load_o_fit_execution_archive(forged, frozen_source=frozen, replay_workers=replay_workers)
    missing = tmp_path / "missing.zip"
    entries.pop("fits/O1_R1_K1_M01.zip")
    write_deterministic_zip(missing, entries)
    with pytest.raises(ContractError):
        f4.load_o_fit_execution_archive(missing, frozen_source=frozen, replay_workers=replay_workers)
    with pytest.raises(ContractError, match="AGGREGATE_INPUT_INVALID"):
        f4.aggregate_o_fit_execution_archives(sources * 3, tmp_path / "old-18.zip", locked_family="RSF", frozen_source=frozen,
                                              replay_workers=replay_workers)


@pytest.mark.parametrize("damage", [None, "origin_mixed", "origin_malformed", "binding", "numeric", "metric_kernel"])
def test_original_o_fit_origin_is_not_current_reader_but_all_native_values_remain_bound(monkeypatch, tmp_path, damage):
    frozen, registered = outer_fixture()
    model = frozen["models"][1, "RSF"]
    current = fixed_rows(1, "RSF")
    original = copy.deepcopy(current)
    for row in original:
        row["producer_source_sha256"] = "e" * 64
    if damage == "origin_mixed":
        original[1]["producer_source_sha256"] = "d" * 64
    elif damage == "origin_malformed":
        for row in original:
            row["producer_source_sha256"] = "UNFITTED_INVALID_ORIGIN"
    elif damage == "numeric":
        original[0]["oof_ibs_0_24"] += .001
    elif damage == "metric_kernel":
        for row in original:
            row["native_metric_engine_sha256"] = "d" * 64
    for row in original:
        row["producer_evidence_sha256"] = sha256_bytes(canonical_json_bytes({
            key: value for key, value in row.items() if key != "producer_evidence_sha256"}))
    if damage == "binding":
        original[0]["producer_evidence_sha256"] = "0" * 64
    entries = {name: ("UNFITTED_" + name).encode() for name in f4._o_fit_native_members(model)}
    body = {"schema_version": "2.0.0", "kind": "PADML_F4_O_FIT_EXECUTION_ARCHIVE_V2", "status": "PASS",
            "outer_fold": 1, "family": "RSF", "f1_identity": frozen["f1_manifest"]["identity"],
            "model_sha256": sha256_bytes(canonical_json_bytes(model)), "rows": original,
            "members": {name: {"sha256": sha256_bytes(raw), "size_bytes": len(raw)} for name, raw in entries.items()}}
    value = {**body, "identity_sha256": sha256_bytes(canonical_json_bytes(body))}
    source = tmp_path / "UNFITTED-original.zip"
    write_deterministic_zip(source, {"o-fit-execution.json": canonical_json_bytes(value), **entries})
    before = source.read_bytes()
    monkeypatch.setattr(f4.subprocess, "run", lambda *a, **k: pytest.fail("NO_REAL_SCIENTIFIC_CALL"))
    monkeypatch.setattr(f4, "_materialize_o_fit_fold", lambda *a: registered[1])
    calls = []
    def replay(observed_model, observed_registered, observed_source, root, **kwargs):
        assert observed_model is model and observed_registered is registered[1] and observed_source is frozen
        assert all((root / name).read_bytes() == raw for name, raw in entries.items())
        calls.append(copy.deepcopy(current))
        return current
    monkeypatch.setattr(f4, "_o_fit_rows_from_native", replay)
    if damage:
        with pytest.raises(ContractError):
            f4.load_o_fit_execution_archive(source, frozen_source=frozen)
    else:
        assert f4.load_o_fit_execution_archive(source, frozen_source=frozen) == value
        assert calls == [current] and current[0]["producer_source_sha256"] != original[0]["producer_source_sha256"]
        # The arithmetic consumer validates original row bindings and all 18 coordinates,
        # not the unrelated current reader file's hash.
        complete = [row for fold in range(1, 7) for row in fixed_rows(fold, "RSF")]
        expected = f4.reduce_o_fit_triggers(complete, locked_family="RSF")
        complete[:3] = original
        assert f4.reduce_o_fit_triggers(complete, locked_family="RSF") == expected
    assert source.read_bytes() == before
    assert len(calls) == (1 if damage in {None, "numeric", "metric_kernel"} else 0)


def test_native_rows_replay_one_apparent_and_fifteen_ordered_folds(monkeypatch, tmp_path):
    frozen, registered = outer_fixture()
    calls, apparent_ids, producer_calls = [], [], []
    def replay(model, part, source, archives, **options):
        repeat, inner = part["repeat"], part["inner_fold"]
        calls.append((repeat, inner))
        assert len(archives) == 20 and source is frozen
        _, apparent, folds, _ = o_fit_bundle_fixture(frozen, repeat=repeat or 1)
        return apparent if repeat == 0 else folds[inner - 1]
    monkeypatch.setattr(f4, "_replay_o_fit_partition", replay)
    def producer(apparent, folds, response, **request):
        apparent_ids.append(id(apparent))
        producer_calls.append(request)
        assert [row["inner_fold"] for row in folds] == [1, 2, 3, 4, 5]
        return fixed_rows(1, "RSF")[request["repeat"] - 1]
    monkeypatch.setattr(f4, "produce_o_fit_row", producer)
    rows = f4._o_fit_rows_from_native(frozen["models"][1, "RSF"], registered[1], frozen, tmp_path)
    assert len(rows) == 3 and len(set(apparent_ids)) == 1
    assert calls == [(0, 0), *[(r, k) for r in range(1, 4) for k in range(1, 6)]]
    assert [row["model_seed"] for row in producer_calls] == [351101, 351106, 351111]


def test_native_outer_cannot_consume_mean_only_archive(monkeypatch, tmp_path):
    frozen, _ = outer_fixture()
    source = tmp_path / "mean-only.zip"
    write_deterministic_zip(source, {"o-fit-execution.json": canonical_json_bytes({
        "kind": "PADML_F4_O_FIT_EXECUTION_ARCHIVE_V1", "status": "PASS"}), "source-bundle.zip": b"UNFITTED_MEANS"})
    with pytest.raises(ContractError, match="EXECUTION_ARCHIVE_INVALID"):
        f4.load_o_fit_execution_archive(source, frozen_source=frozen)
