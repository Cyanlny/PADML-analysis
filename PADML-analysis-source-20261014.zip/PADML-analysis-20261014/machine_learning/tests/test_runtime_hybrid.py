"""Zero-fit CPU parser regression for v1 controllers plus an unmounted v2 record.

Mount roots, paths, quota and affinity reproduce the observed H5-3 layout;
hierarchy/mount IDs are fixture identifiers. All /proc and /sys reads are
in-memory fixtures, never a claim about this test machine's real capacity.
"""

from pathlib import Path
import subprocess

import pytest

from padml import runtime
from padml.bundle import ContractError


GROUP = "/docker/a70cb55bab231a2eb99fd6088c96e9ed329c66ae658477906e9495bf3d095714"
CPU_MOUNT = "/sys/fs/cgroup/cpu,cpuacct"
CPUSET_MOUNT = "/sys/fs/cgroup/cpuset"
QUOTA = CPU_MOUNT + "/cpu.cfs_quota_us"
PERIOD = CPU_MOUNT + "/cpu.cfs_period_us"
CPUSET = CPUSET_MOUNT + "/cpuset.effective_cpus"
CPU_ROW = f"9:cpu,cpuacct:{GROUP}"
CPUSET_ROW = f"4:cpuset:{GROUP}"
UNIFIED_ROW = f"0::{GROUP}"
CPU_MOUNT_ROW = (
    f"31 25 0:28 {GROUP} {CPU_MOUNT} rw,relatime - cgroup cgroup rw,cpu,cpuacct"
)
CPUSET_MOUNT_ROW = (
    f"32 25 0:29 {GROUP} {CPUSET_MOUNT} rw,relatime - cgroup cgroup rw,cpuset"
)


def _forbidden(*args, **kwargs):
    raise AssertionError("ZERO_SCIENCE_GUARD: no fallback/subprocess/pool allowed")


@pytest.fixture(autouse=True)
def _zero_science_guards(monkeypatch):
    monkeypatch.setattr(runtime.os, "cpu_count", _forbidden)
    monkeypatch.setattr(runtime, "get_context", _forbidden)
    monkeypatch.setattr(runtime, "_bounded_ordered_spawn", _forbidden)
    monkeypatch.setattr(subprocess, "run", _forbidden)
    monkeypatch.setattr(subprocess, "Popen", _forbidden)


def _hybrid(monkeypatch, *, rows=None, mounts=None, quota="6400000", period="100000"):
    """Install only supplied in-memory Linux observations; return maps and reads."""
    files = {
        "/proc/self/cgroup": "\n".join(
            rows if rows is not None else [CPU_ROW, CPUSET_ROW, UNIFIED_ROW]
        ) + "\n",
        "/proc/self/mountinfo": "\n".join(
            mounts if mounts is not None else [CPU_MOUNT_ROW, CPUSET_MOUNT_ROW]
        ) + "\n",
        QUOTA: quota + "\n",
        PERIOD: period + "\n",
        CPUSET: "32-95\n",
    }
    unreadable = set()
    reads = []
    original_read_text = Path.read_text
    original_exists = Path.exists

    def controlled(path):
        return str(path) == "/proc" or str(path).startswith("/proc/") or (
            str(path) == "/sys" or str(path).startswith("/sys/")
        )

    def read_text(path, *args, **kwargs):
        if not controlled(path):
            return original_read_text(path, *args, **kwargs)
        name = str(path)
        reads.append(name)
        if name in unreadable:
            raise PermissionError("UNFITTED_RESOURCE_FIXTURE_UNREADABLE: " + name)
        if name not in files:
            raise FileNotFoundError("UNFITTED_RESOURCE_FIXTURE_MISSING: " + name)
        return files[name]

    def exists(path):
        if controlled(path):
            return str(path) in files or str(path) in unreadable
        return original_exists(path)

    def affinity(pid):
        assert pid == 0
        return set(range(32, 96))

    monkeypatch.setattr(Path, "read_text", read_text)
    monkeypatch.setattr(Path, "exists", exists)
    monkeypatch.setattr(runtime.sys, "platform", "linux")
    monkeypatch.setattr(runtime.os, "sched_getaffinity", affinity, raising=False)
    return files, unreadable, reads


def _assert_capacity(reads, expected):
    observed = runtime.effective_cpu_count()
    assert observed == expected
    assert runtime.pool_capacity(observed) == expected - 8
    assert all(path in reads for path in (QUOTA, PERIOD, CPUSET))
    assert reads.count("/proc/self/cgroup") == 1
    assert reads.count("/proc/self/mountinfo") == 1
    assert not any(path.endswith("/cpu.max") for path in reads)


def _assert_rejected_guard(reason):
    # ContractError subclasses ValueError, so the public resource error wraps
    # the precise parser predicate. Inspect both, rather than losing the cause.
    with pytest.raises(ContractError, match="^CPU_RESOURCE_UNDETERMINED$") as caught:
        runtime.effective_cpu_count()
    assert isinstance(caught.value.__cause__, ContractError)
    assert caught.value.__cause__.args == (reason,)


def test_01_h5_hybrid_supplied_order_reads_both_v1_limits(monkeypatch):
    _, _, reads = _hybrid(monkeypatch)
    _assert_capacity(reads, 64)


def test_02_h5_hybrid_unified_first_is_order_independent(monkeypatch):
    _, _, reads = _hybrid(monkeypatch, rows=[UNIFIED_ROW, CPUSET_ROW, CPU_ROW])
    _assert_capacity(reads, 64)


def test_03_smaller_fractional_quota_is_floored(monkeypatch):
    _, _, reads = _hybrid(
        monkeypatch, rows=[UNIFIED_ROW, CPU_ROW, CPUSET_ROW], quota="3299999"
    )
    _assert_capacity(reads, 32)


def test_04_missing_cpu_quota_cannot_be_ignored(monkeypatch):
    files, _, reads = _hybrid(monkeypatch)
    del files[QUOTA]
    with pytest.raises(ContractError, match="^CPU_RESOURCE_UNDETERMINED$"):
        runtime.effective_cpu_count()
    assert QUOTA in reads


def test_05_unreadable_cpu_period_cannot_be_ignored(monkeypatch):
    _, unreadable, reads = _hybrid(monkeypatch)
    unreadable.add(PERIOD)
    with pytest.raises(ContractError, match="^CPU_RESOURCE_UNDETERMINED$"):
        runtime.effective_cpu_count()
    assert QUOTA in reads and PERIOD in reads


def test_06_missing_cpuset_files_cannot_use_affinity_only(monkeypatch):
    files, _, _ = _hybrid(monkeypatch)
    del files[CPUSET]
    _assert_rejected_guard("CPU_RESOURCE_CGROUP_MOUNT_MISSING")


def test_07_unreadable_cpuset_cannot_use_affinity_only(monkeypatch):
    _, unreadable, reads = _hybrid(monkeypatch)
    unreadable.add(CPUSET)
    with pytest.raises(ContractError, match="^CPU_RESOURCE_UNDETERMINED$"):
        runtime.effective_cpu_count()
    assert CPUSET in reads


def test_08_empty_cpuset_does_not_prove_v1_cpuset_consumption(monkeypatch):
    files, _, reads = _hybrid(monkeypatch)
    files[CPUSET] = "  \n"
    _assert_rejected_guard("CPU_RESOURCE_CGROUP_MOUNT_MISSING")
    assert CPUSET in reads


def test_09_illegal_quota_is_a_resource_error(monkeypatch):
    _hybrid(monkeypatch, quota="0")
    _assert_rejected_guard("CPU_RESOURCE_QUOTA_INVALID")


def test_10_missing_relevant_v1_cpu_mount_is_rejected(monkeypatch):
    _hybrid(monkeypatch, mounts=[CPUSET_MOUNT_ROW])
    _assert_rejected_guard("CPU_RESOURCE_CGROUP_MOUNT_MISSING")


def test_11_missing_relevant_v1_cpuset_mount_is_rejected(monkeypatch):
    _hybrid(monkeypatch, mounts=[CPU_MOUNT_ROW])
    _assert_rejected_guard("CPU_RESOURCE_CGROUP_MOUNT_MISSING")


def test_12_existing_v2_mount_with_wrong_root_is_not_ignored(monkeypatch):
    wrong_v2 = (
        "33 25 0:30 /docker/another-container /sys/fs/cgroup/unified "
        "rw,relatime - cgroup2 cgroup rw"
    )
    _, _, reads = _hybrid(
        monkeypatch, mounts=[CPU_MOUNT_ROW, CPUSET_MOUNT_ROW, wrong_v2]
    )
    _assert_rejected_guard("CPU_RESOURCE_CGROUP_MOUNT_MISSING")
    # The complete real-v1-shaped observations cannot excuse an actual bad v2 mount.
    assert all(path in reads for path in (QUOTA, PERIOD, CPUSET))

