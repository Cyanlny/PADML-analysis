"""Original AAR phase lifecycle; synthetic M20 and unfitted native engine only."""
import copy
import json
from pathlib import Path

import pytest

from padml import f4, f5, f5_sensitivity as sensitivity, runtime
from padml.bundle import ContractError, canonical_json_bytes, sha256_bytes, sha256_file, strict_json_bytes
from test_nested_aar_mice import unfitted_selector_shard_inputs  # noqa: F401
from test_nested_full_development import _selector_shard_engines


@pytest.fixture
def phase_case(unfitted_selector_shard_inputs, tmp_path, monkeypatch):
    prepared = unfitted_selector_shard_inputs
    counts = _selector_shard_engines(monkeypatch, f4.subprocess.run)
    source, projected = tmp_path / "UNFITTED-gather.zip", tmp_path / "UNFITTED-projected.zip"
    source.write_bytes(b"UNFITTED materializer boundary; original phase owners stay live")
    def materialize(_source, _lineage, target, *, input_bundle, execution_scratch_reserve_bytes):
        assert _source == source and input_bundle == projected
        assert type(execution_scratch_reserve_bytes) is int and execution_scratch_reserve_bytes == 0
        target.mkdir()
        (target / "reader-complete.json").write_bytes(canonical_json_bytes({"UNFITTED": True}))
        return prepared
    monkeypatch.setattr(sensitivity, "materialize_a12_outer_inputs", materialize)
    owner = tmp_path / "selector"
    ready = sensitivity.execute_a12_outer_bundle(source, owner, input_bundle=projected,
        selector_only=True, prepare_only=True)
    assert len(ready["task_ids"]) == 320 and counts["engine"] == 0
    def run(ids, batch):
        return sensitivity.execute_a12_outer_bundle(source, owner, input_bundle=projected,
            selector_only=True, phase_name="coarse", task_ids=ids, batch_root=batch,
            retained_bytes_per_task=64 * 1024**2)
    return prepared, counts, source, owner, ready, run


def test_phase_release_three_owners_and_original_reader_negatives(phase_case, tmp_path):
    prepared, counts, source, owner, ready, run = phase_case
    retained = {path: sha256_file(path) for path in owner.rglob("*") if path.is_file()}
    batch = tmp_path / "batch-one"
    result = run(ready["task_ids"][:1], batch)
    execution = strict_json_bytes((batch / "execution.json").read_bytes())
    pin = execution["resource_release"]
    release = strict_json_bytes((batch / pin["path"]).read_bytes())
    assert sha256_file(batch / pin["path"]) == pin["sha256"]
    assert result["execution"] == execution and counts["engine"] == counts["native"] == 1
    assert result["selector_path_count"] == 7 and result["glmnet_call_count"] == 14
    assert result["new_mice_chains"] == result["final_model_fits"] == 0
    assert len(release["native_files"]["files"]) == 5 + 2 * 7
    assert all(path.is_file() and sha256_file(path) == digest for path, digest in retained.items())
    assert all(Path(row["path"]).is_file() for row in release["native_files"]["files"])
    for name in ("selector_program", "selector_inputs", "materialized_inputs"):
        row = release["input_lifecycle"][name]
        assert not Path(row["temporary_root"]).exists()
        runtime.validate_resource_release(row["resource_release"])
    partitions = strict_json_bytes((owner / "partitions.json").read_bytes())
    def consume(value):
        f5._validate_selector_phase_release(value, execution=execution,
            expected_partition_sha256=ready["partition_inputs_sha256"], expected_partitions=partitions,
            expected_input_binding={"input_archive_sha256": sha256_file(source),
                "projected_input_identity_sha256": prepared["source"]["identity_sha256"],
                "partition_inputs_sha256": ready["partition_inputs_sha256"]})
    consume(release)
    for damage in ("pool_missing", "owner", "phase", "source", "missing_input_root", "pending_file",
                   "missing_response", "missing_m20", "m20_size", "post_admission_bool", "input_identity", "partition"):
        bad = copy.deepcopy(release)
        inputs = bad["input_lifecycle"]
        if damage == "pool_missing":
            bad["pool"].clear()
        elif damage == "owner":
            bad["native_files"]["owner"] += ":foreign"
        elif damage in ("phase", "source"):
            bad["phase" if damage == "phase" else "source_identity"] = "foreign"
        elif damage == "missing_input_root":
            del inputs["materialized_inputs"]
        elif damage == "pending_file":
            inputs["selector_inputs"]["resource_release"]["files"][0]["path"] = str(owner / "partitions.json")
        elif damage == "missing_response":
            inputs["selector_program"]["resource_release"]["files"].pop()
        elif damage == "missing_m20":
            inputs["selector_inputs"]["resource_release"]["files"].pop()
        elif damage == "m20_size":
            inputs["selector_inputs"]["resource_release"]["files"][0]["size_bytes"] += 1
        elif damage == "post_admission_bool":
            inputs["after_release"]["resource_admission"]["admitted_worker_ceiling"] = True
        else:
            inputs["projected_input_identity_sha256" if damage == "input_identity" else "partition_inputs_sha256"] = "f" * 64
        with pytest.raises(ContractError, match="NESTED_SELECTOR_PHASE_RELEASE_INVALID"):
            consume(bad)
    assert counts["engine"] == counts["native"] == 1


def test_phase_release_failures_preserve_scientific_ok_without_refitting(phase_case, tmp_path, monkeypatch):
    _, counts, _, owner, ready, run = phase_case
    original_release, original_observe = runtime.release_step_resources, runtime.observe_execution_resources
    original_write = Path.write_bytes
    failures = ("native_release", "input_release", "post_admission", "leaf_write",
                "partial_pool_then_leaf_write", "input_release_then_leaf_write")
    for index, failure in enumerate(failures):
        batch = tmp_path / ("failed-" + failure)
        task_id = ready["task_ids"][index]
        previous = {p for pattern in ("a12-selector-*-*", "nested-full-selector-replay-*") for p in tmp_path.glob(pattern)}
        releases = []
        def release(files, **kwargs):
            name = kwargs["owner"]
            releases.append(name)
            if failure == "native_release" and name.startswith("SELECTOR_PHASE_NATIVE:"):
                raise ContractError("UNFITTED_NATIVE_RELEASE_FAILURE")
            if failure in {"input_release", "input_release_then_leaf_write"} and name.startswith("AAR_SELECTOR_PHASE_INPUTS:"):
                raise ContractError("UNFITTED_INPUT_RELEASE_FAILURE")
            return original_release(files, **kwargs)
        def observe(path):
            result = original_observe(path)
            if failure == "post_admission" and sum(name.startswith("AAR_SELECTOR_PHASE_INPUTS:") for name in releases) == 3:
                result["available_memory_bytes"] = 1
            return result
        def write(path, data):
            denied = failure in {"leaf_write", "partial_pool_then_leaf_write"} or (
                failure == "input_release_then_leaf_write" and any(name.startswith("AAR_SELECTOR_PHASE_INPUTS:") for name in releases))
            if denied and path.parent == batch and path.name.startswith("resource-release-"):
                raise OSError("UNFITTED_DIAGNOSTIC_WRITE_FAILURE")
            return original_write(path, data)
        def partial_pool(worker, jobs, *, selected_slots, execution_report, on_result, resource_release_report):
            execution_report.update(configured_worker_ceiling=24, admitted_worker_ceiling=selected_slots,
                runnable_task_count=len(jobs), actual_worker_process_peak=1, completed_task_count=1,
                engine_threads=1, status="FAILED")
            on_result(0, worker(jobs[0]))
            raise ContractError("UNFITTED_POOL_RELEASE_HANDSHAKE_FAILURE")
        before = counts["engine"]
        with monkeypatch.context() as failed:
            failed.setattr(runtime, "release_step_resources", release)
            failed.setattr(runtime, "observe_execution_resources", observe)
            failed.setattr(Path, "write_bytes", write)
            if failure == "partial_pool_then_leaf_write":
                failed.setattr(f4, "_bounded_ordered_spawn", partial_pool)
            with pytest.raises((ContractError, OSError)) as raised:
                run([task_id], batch)
        assert counts["engine"] == before + 1
        assert (owner / "coarse" / task_id / "path-result.json").is_file()
        refs = strict_json_bytes((batch / "path-results.json").read_bytes())
        assert [row["task_id"] for row in refs] == [task_id]
        execution = strict_json_bytes((batch / "execution.json").read_bytes())
        assert execution["pool"]["completed_task_count"] == 1
        if failure == "post_admission":
            release = strict_json_bytes((batch / execution["resource_release"]["path"]).read_bytes())
            assert release["input_lifecycle"]["after_release"]["resource_observation"]["available_memory_bytes"] == 1
            assert release["input_lifecycle"]["after_release"]["resource_admission"] is None
        if failure == "partial_pool_then_leaf_write":
            assert str(raised.value) == "UNFITTED_POOL_RELEASE_HANDSHAKE_FAILURE"
            assert execution["pool"]["status"] == "FAILED" and "resource_release" not in execution
            assert any("DIAGNOSTIC_WRITE_FAILED" in note for note in raised.value.__notes__)
        if failure == "input_release_then_leaf_write":
            assert str(raised.value) == "UNFITTED_INPUT_RELEASE_FAILURE"
            assert any("DIAGNOSTIC_WRITE_FAILED" in note for note in raised.value.__notes__)
        retained = {p for pattern in ("a12-selector-*-*", "nested-full-selector-replay-*") for p in tmp_path.glob(pattern)} - previous
        assert len(retained) == 3 and all(path.is_dir() for path in retained)
        with pytest.raises(ContractError, match="NESTED_SELECTOR_COORDINATE_ALREADY_STARTED"):
            run([task_id], tmp_path / ("must-not-refit-" + failure))
        assert counts["engine"] == before + 1


def test_phase_320_complete_coordinates_keep_original_transport_bounds(phase_case, tmp_path, monkeypatch):
    import shutil
    prepared, counts, source, owner, ready, run = phase_case
    batch = tmp_path / "complete-320-small-payload"
    result = run(ready["task_ids"], batch)
    assert result["task_count"] == counts["native"] == counts["engine"] == 320
    assert result["selector_path_count"] == 320 * 7 and result["glmnet_call_count"] == 2 * 320 * 7
    files = [path for path in batch.rglob("*") if path.is_file()]
    assert len(files) == 2 * 320 + 3
    assert (batch / "execution.json").stat().st_size <= 1024**2
    assert (batch / "path-results.json").stat().st_size <= 1024**2
    pin = result["execution"]["resource_release"]
    assert (batch / pin["path"]).stat().st_size == pin["size_bytes"] <= 32 * 1024**2
    assert sum(path.stat().st_size for path in files) <= 64 * 1024**2
    originals = {path: sha256_file(path) for path in files}
    def gather(name):
        target = tmp_path / name
        for member in ("partitions.json", "recipes/recipes.json", "recipes/native-values.json"):
            destination = target / member
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(owner / member, destination)
        return target
    target = gather("gather-320")
    kwargs = {"input_bundle": tmp_path / "UNFITTED-projected.zip", "selector_only": True,
              "phase_name": "coarse", "phase_batches": [batch]}
    counts["forbid_native"] = True
    envelope = sensitivity.execute_a12_outer_bundle(source, target, **kwargs)
    scientific = envelope["selector_result"]
    report = envelope["execution_report"]
    assert scientific["status"] == "COMPUTED_SELECTOR_PHASE" and scientific["next_phase"] == "fine"
    assert all(sha256_file(path) == digest for path, digest in originals.items())
    assert counts["engine"] == counts["native"] == 320
    expected_source = strict_json_bytes((target / "coarse/execution.json").read_bytes())[0]["execution"]["source"]
    def consume(value):
        sensitivity._validate_a12_selector_gather_execution(value, input_source=prepared["source"],
            source_sha256=sha256_file(source), executor_source_identity=report["source_identity"],
            selector_root=target, expected_phase="coarse", expected_selector_result=scientific,
            expected_selector_source=expected_source,
            expected_partitions=strict_json_bytes((target / "partitions.json").read_bytes()))
    consume(envelope)
    for damage in ("scientific_child", "missing_root", "source", "phase", "result_binding", "selector_root",
                   "admission_bool", "missing_m20", "program_id", "training_ids_sha256",
                   "training_response_sha256", "mice_plan_sha256"):
        value = copy.deepcopy(envelope)
        if damage == "scientific_child":
            value["selector_result"]["next_alphas"] = []
        elif damage == "missing_root":
            del value["execution_report"]["input_lifecycle"]["materialized_inputs"]
        elif damage == "source":
            value["execution_report"]["source_identity"] = "f" * 64
        elif damage == "phase":
            value["execution_report"]["phase"] = "fine"
        elif damage == "result_binding":
            value["execution_report"]["selector_result_sha256"] = "f" * 64
        elif damage == "selector_root":
            value["execution_report"]["selector_root"] = str(target.with_name("another-selector"))
        elif damage in ("program_id", "training_ids_sha256", "training_response_sha256", "mice_plan_sha256"):
            value["execution_report"]["source"][damage] = "f" * 64
        elif damage == "admission_bool":
            value["execution_report"]["input_lifecycle"]["after_release"]["resource_admission"]["admitted_worker_ceiling"] = True
        else:
            value["execution_report"]["input_lifecycle"]["selector_inputs"]["resource_release"]["files"].pop()
        with pytest.raises(ContractError):
            consume(value)
    # The original CLI prints json.dumps plus a newline, not canonical JSON.
    # Exercise its actual wire bound independently of the smaller canonical size.
    large = copy.deepcopy(envelope)
    child = {**scientific, "UNFITTED_wire_boundary": "\u00e9" * (6 * 1024**2)}
    large["selector_result"] = child
    large["execution_report"]["selector_result_sha256"] = sha256_bytes(canonical_json_bytes(child))
    assert len(canonical_json_bytes(large)) < 32 * 1024**2
    assert len((json.dumps(large, sort_keys=True) + "\n").encode()) > 32 * 1024**2
    with pytest.raises(ContractError, match="F5_A12_SELECTOR_GATHER_EXECUTION_INVALID"):
        sensitivity._validate_a12_selector_gather_execution(large, input_source=prepared["source"],
            source_sha256=sha256_file(source), executor_source_identity=report["source_identity"],
            selector_root=target, expected_phase="coarse", expected_selector_result=child,
            expected_selector_source=expected_source,
            expected_partitions=strict_json_bytes((target / "partitions.json").read_bytes()))
    del large, child
    original_release, original_observe = runtime.release_step_resources, runtime.observe_execution_resources
    for failure in ("release", "post_admission"):
        failed_target = gather("failed-gather-" + failure)
        roots_before = {p for pattern in ("a12-selector-*-*", "nested-full-selector-replay-*") for p in tmp_path.glob(pattern)}
        completed_releases = []
        def release(paths, **options):
            if options["owner"].startswith("AAR_SELECTOR_PHASE_INPUTS:"):
                if failure == "release":
                    raise ContractError("UNFITTED_GATHER_RELEASE_FAILURE")
                completed_releases.append(options["owner"])
            return original_release(paths, **options)
        def observe(path):
            value = original_observe(path)
            if len(completed_releases) == 3:
                value["available_memory_bytes"] = 1
            return value
        with monkeypatch.context() as denied:
            denied.setattr(runtime, "release_step_resources", release)
            denied.setattr(runtime, "observe_execution_resources", observe)
            with pytest.raises(ContractError):
                sensitivity.execute_a12_outer_bundle(source, failed_target, **kwargs)
        roots_after = {p for pattern in ("a12-selector-*-*", "nested-full-selector-replay-*") for p in tmp_path.glob(pattern)}
        assert len(roots_after - roots_before) == 3
        assert (failed_target / "coarse-gather-execution.json").is_file()
        failed_report = strict_json_bytes((failed_target / "coarse-gather-execution.json").read_bytes())
        if failure == "post_admission":
            assert failed_report["input_lifecycle"]["after_release"]["resource_observation"]["available_memory_bytes"] == 1
            assert failed_report["input_lifecycle"]["after_release"]["resource_admission"] is None
        assert (failed_target / "coarse/paths.json").is_file()
        assert (failed_target / "coarse/execution.json").is_file()
        assert all(sha256_file(path) == digest for path, digest in originals.items())
        assert counts["engine"] == counts["native"] == 320
