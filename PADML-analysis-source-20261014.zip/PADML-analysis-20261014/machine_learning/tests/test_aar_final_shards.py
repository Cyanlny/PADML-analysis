"""Original AAR final workers/numbers; only fitting and object leaves are UNFITTED."""
import copy
import shutil
import weakref
from pathlib import Path

import pytest

from padml import f5, f5_sensitivity as sensitivity, nested_loco as nested, runtime
from padml.bundle import ContractError, canonical_json_bytes, sha256_bytes, sha256_file, strict_json_bytes
from padml.f2_kernel import _expected_family_parent_column_map, predictor_contract
from test_f5 import _test_final_design_recipe
from test_nested_aar_mice import _unfitted_aar_cox_engines


def _serial_pool(worker, jobs, *, selected_slots, execution_report, on_result=None, resource_release_report=None):
    execution_report.update(configured_worker_ceiling=24, admitted_worker_ceiling=selected_slots,
        runnable_task_count=len(jobs), actual_worker_process_peak=1, completed_task_count=0,
        engine_threads=1, status="RUNNING")
    result = [None] * len(jobs)
    try:
        for index in reversed(range(len(jobs))):
            row = worker(jobs[index])
            if on_result is None:
                result[index] = row
            else:
                on_result(index, row)
            execution_report["completed_task_count"] += 1
            if resource_release_report is not None:
                # This serial UNFITTED adapter exercises the existing stage
                # handoff, not child-process retirement (covered by runtime).
                before = runtime.observe_step_memory()
                del row
                resource_release_report[str(index)] = runtime.release_step_resources([], before=before,
                    owner=f"POOL_TASK_RESULT:{index}",
                    released_references=["serialized_result", "task", "received_message"])
    except BaseException:
        execution_report["status"] = "FAILED"
        raise
    execution_report["status"] = "COMPLETED"
    return result


@pytest.fixture
def final_jobs(tmp_path, monkeypatch):
    """Small valid COX inputs; the separate public test supplies real upstream owners."""
    monkeypatch.setattr(runtime, "effective_cpu_count", lambda: 32)
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda root: {
        "effective_cpus": 32, "available_memory_bytes": 10**12, "scratch_available_bytes": 10**12,
        "scratch_root": str(root)})
    monkeypatch.setattr(sensitivity, "_bounded_ordered_spawn", _serial_pool)
    calls, audits = _unfitted_aar_cox_engines(monkeypatch)
    recipe = _test_final_design_recipe("COX_PH", ["Age"])
    count = sum(len(row["columns"]) for row in _expected_family_parent_column_map(["Age"], "COX_PH",
        predictor_contract(Path(f5.__file__).parent), recipe["transform_recipe"]))
    training_count = 15 * count + 5
    policy = {"configured_worker_ceiling": "EXECUTION_HOST_C_MINUS_8", "memory_bytes_per_worker": 1,
        "scratch_bytes_per_worker": 1, "memory_reserve_bytes": 0, "scratch_reserve_bytes": 0,
        "transfer_archive_worker_ceiling": 1000}
    prepared = {"family": "COX_PH", "outer_fold": 1,
        "source": {"kind": "PADML_F5_A12_PROJECTED_OUTER_INPUTS_V1", "resource_policy": policy, "outer_fold": 1,
            "primary_source": {"primary_training_context": {"heldout_ids": ["H01", "H02"], "heldout_center": 36}}},
        "branch_development": {branch: {"UNFITTED_DEVELOPMENT_BOUNDARY": branch} for branch in nested.AAR_ESTIMANDS}}
    jobs = []
    for branch in nested.AAR_ESTIMANDS:
        for imp in range(1, 21):
            task = {"family": "COX_PH", "selected_parents": ["Age"], "parameters": {"family": "COX_PH", "ties": "breslow"},
                "imputation": imp, "a12_coordinates": {"outer_fold": 1, "branch": branch, "imputation": imp},
                "registered_model_seed": 301000 + imp, "model_seed": None, "row_count": training_count,
                "family_design_column_count": count, "common_set_design_df": count, "training_event_count": training_count,
                "nested_aar_final_source": {"kind": "PADML_NESTED_AAR_FINAL_SOURCE_V1", "program_id": nested.PROGRAM_ID,
                    **dict.fromkeys(("science_decision_sha256", "primary_development_lock_sha256", "training_context_sha256",
                        "inputs_identity_sha256", "development_input_sha256", "parameter_source_sha256"), nested._sha(branch))}}
            entries = {"task.json": canonical_json_bytes(task), "recipe.json": canonical_json_bytes(recipe),
                "fit-covariates.csv": ("Patient_ID,Center,Age\n" + "".join(f"T{i:02d},55,40\n" for i in range(training_count))).encode(),
                "fit-response.csv": ("Patient_ID,All_Cause_Death,Death_Followup_months\n" + "".join(f"T{i:02d},1,12\n" for i in range(training_count))).encode(),
                "prediction-covariates.csv": b"Patient_ID,Center,Age\nH01,36,40\nH02,36,50\n"}
            sensitivity._ablation_component_inputs(entries)
            jobs.append({"name": f"O1_{branch}_M{imp:02d}", "entries": entries})
    shared = tmp_path / "UNFITTED-shared-inputs.zip"
    shared.write_bytes(b"UNFITTED_UPSTREAM_BYTE_BOUNDARY")
    return prepared, jobs, {"inputs.zip": shared}, 2 * 1024**2, calls, audits


def test_aar_final_batch_source_scan_is_current_and_once(final_jobs, tmp_path, monkeypatch):
    """One UNFITTED component supplies valid current-format reader evidence."""
    from padml import f4
    prepared, jobs, shared, retained, calls, audits = final_jobs
    source = f4._f45_source_member_sha256()
    identity = nested._sha(source)
    names = [jobs[0]["name"]]
    sizes = {name: path.stat().st_size for name, path in shared.items()}
    batch = tmp_path / "final-batches" / "one"
    result = sensitivity._a12_final_component_batches(prepared, jobs, tmp_path, shared, retained,
        task_names=names, batch_root=batch)
    executions = [result["execution_report"]]
    path = batch / "fits" / (names[0] + ".numbers.json")
    components = {names[0]: {"sha256": sha256_file(path), "size_bytes": path.stat().st_size}}
    number = strict_json_bytes(path.read_bytes())
    native = {names[0]: {key: number[key] for key in ("native_archive", "native_expanded_bytes")}}
    reports = {executions[0]["resource_release"]["path"]: (batch / "resource-release.json").read_bytes()}
    scans = []
    def current_source():
        scans.append(1)
        return source
    monkeypatch.setattr(f4, "_f45_source_member_sha256", current_source)
    sensitivity._a12_final_batch_execution(executions, components, prepared=prepared, jobs=jobs, shared_sizes=sizes,
        retained=retained, complete=False, release_reports=reports, component_native=native, expected_roots=(tmp_path, batch))
    assert scans == [1] and calls.count("UNFITTED_CREATE") == len(audits) == 1
    source = {**source, "padml/f5_sensitivity.py": "f" * 64}
    with pytest.raises(ContractError, match="F5_A12_FINAL_BATCH_SOURCE_DRIFT"):
        sensitivity._a12_final_batch_execution(executions, components, prepared=prepared, jobs=jobs, shared_sizes=sizes,
            retained=retained, complete=False, release_reports=reports, component_native=native, expected_roots=(tmp_path, batch))
    assert scans == [1, 1] and calls.count("UNFITTED_CREATE") == len(audits) == 1


@pytest.mark.parametrize("damage", ["empty", "duplicate", "reordered", "outer", "zero", "21", "branch"])
def test_aar_final_assignments_preserve_original_grid(damage):
    names = list(sensitivity._a12_final_task_coordinates(2))
    assigned = {"empty": [], "duplicate": [names[6], names[6]], "reordered": [names[7], names[6]],
        "outer": [names[6].replace("O2_", "O1_")], "zero": [names[6][:-2] + "00"],
        "21": [names[6][:-2] + "21"], "branch": ["O2_UNKNOWN_M07"]}[damage]
    with pytest.raises(ContractError, match="FINAL_BATCH_COORDINATES_INVALID"):
        sensitivity._a12_final_task_coordinates(2, assigned)
    assert sensitivity._a12_final_task_coordinates(2, [names[6]]) == {names[6]: (nested.A12_DIRECT_AAR, 7)}


def test_aar_final_scoped_jobs_reserve_same_bytes_as_complete_gather(final_jobs):
    prepared, jobs, shared, retained, calls, audits = final_jobs
    active = [jobs[26]]  # TOTAL M07; never renumber it to M01.
    names = [job["name"] for job in active]
    sizes = {name: path.stat().st_size for name, path in shared.items()}
    sizes.update({f"development/{branch}.json": 100 + index for index, branch in enumerate(nested.AAR_ESTIMANDS)})
    sizes.update({f"search/{branch}/result.json": 1000 + index for index, branch in enumerate(nested.AAR_ESTIMANDS)})
    sizes["development/selector/development-input.json"] = 123456
    projected = sensitivity._a12_final_shared_members(sizes, {nested.A12_TOTAL_AAR})
    worker = sensitivity._a12_final_resource_reservation(prepared["source"], active, projected, retained, task_names=names)
    gather = sensitivity._a12_final_resource_reservation(prepared["source"], jobs, sizes, retained, task_names=names)
    full = sensitivity._a12_final_resource_reservation(prepared["source"], jobs, sizes, retained)
    assert worker == gather and worker["component_count"] == 60
    assert worker["component_retention_reserved_bytes"] == retained
    assert worker["shared_member_bytes"] < full["shared_member_bytes"] and not calls and not audits


def test_three_aar_final_six_disjoint_shards_use_original_numbers(final_jobs, tmp_path, monkeypatch):
    prepared, jobs, shared, retained, calls, audits = final_jobs
    memory = runtime.observe_step_memory
    def capacity_memory():
        value = memory()
        # Capacity fixture only, not a claim about this host's ancestors.
        value["cgroups"] = [{"path": f"/UNFITTED-capacity-cgroup/{index}", "version": 2,
            "total_bytes": 1000, "limit_bytes": 10000, "anon_bytes": 400, "file_bytes": 600,
            "stat_keys": ["anon", "file"], "stat_status": "OBSERVED"} for index in range(64)]
        value["cgroup_status"] = "OBSERVED"
        return value
    monkeypatch.setattr(runtime, "observe_step_memory", capacity_memory)
    names = [job["name"] for job in jobs]
    batches = []
    for index in range(6):
        root = tmp_path / f"worker-{index}"
        root.mkdir()
        batch = root / "final-batches" / "assignment"
        assigned = names[index::6]
        result = sensitivity._a12_final_component_batches(prepared, jobs, root, shared, retained,
            task_names=assigned, batch_root=batch)
        assert result["new_model_fits"] == result["new_model_native_verification_count"] == 10
        assert result["execution_report"]["resource_reservation"]["component_count"] == 60
        assert result["execution_report"]["resource_reservation"]["component_retention_reserved_bytes"] == 10 * retained
        leaf = batch / "resource-release.json"
        assert 128 * 1024 < leaf.stat().st_size <= 10 * 128 * 1024
        assert (batch / "execution.json").stat().st_size <= 128 * 1024
        release = strict_json_bytes(leaf.read_bytes())
        assert len(release["worker_results"]) == 10 and len(release["coordinator"]["files"]) == 130
        with pytest.raises(ContractError, match="FINAL_COORDINATE_ALREADY_STARTED"):
            sensitivity._a12_final_component_batches(prepared, jobs, root, shared, retained,
                task_names=assigned[:1], batch_root=root / "final-batches" / "renamed")
        shutil.move(root / "fits", root / "UNFITTED-execution-owned-native")
        batches.append(batch)
    assert calls.count("UNFITTED_CREATE") == len(audits) == 60
    gather = tmp_path / "gather"
    gather.mkdir()
    def forbidden(*args, **kwargs):
        pytest.fail("Complete AAR numerical gather cannot fit, load or audit native models")
    monkeypatch.setattr(f5, "_execute_final_refit_engine", forbidden)
    monkeypatch.setattr(f5, "_validate_retained_model_objects", forbidden)
    for invalid in (batches[:-1], [*batches, batches[0]]):
        with pytest.raises(ContractError, match="FINAL_BATCH_COMPLETE_SET_REQUIRED|FINAL_BATCHES_INVALID"):
            sensitivity._a12_final_component_batches(prepared, jobs, gather, shared, retained, final_batches=invalid)
    path = batches[0] / "execution.json"
    saved = path.read_bytes()
    negatives = ("source", "development", "count", "pool", "resource", "duplicate", "number")
    for damage in negatives:
        value = strict_json_bytes(saved)
        changed_number = None
        if damage == "source":
            value["source_identity"] = "0" * 64
        elif damage == "development":
            value["development_inputs_sha256"] = "0" * 64
        elif damage == "count":
            value["new_model_native_verification_count"] -= 1
        elif damage == "pool":
            value["final_model_pool"]["completed_task_count"] -= 1
        elif damage == "resource":
            value["resource_admission"]["admitted_worker_ceiling"] += 1
        elif damage == "duplicate":
            value["task_names"][1] = value["task_names"][0]
        else:
            changed_number = batches[0] / "fits" / (names[0] + ".numbers.json")
            saved_number = changed_number.read_bytes()
            number = strict_json_bytes(saved_number)
            number["prediction"]["survival"][0][1] = 1.1
            changed_number.write_bytes(canonical_json_bytes(number))
            value["components_sha256"] = nested._sha({name: {
                "sha256": sha256_file(batches[0] / "fits" / (name + ".numbers.json")),
                "size_bytes": (batches[0] / "fits" / (name + ".numbers.json")).stat().st_size} for name in value["task_names"]})
        path.write_bytes(canonical_json_bytes(value))
        try:
            with pytest.raises(ContractError):
                sensitivity._a12_final_component_batches(prepared, jobs, gather, shared, retained, final_batches=batches)
        finally:
            path.write_bytes(saved)
            if changed_number is not None:
                changed_number.write_bytes(saved_number)
        assert not (gather / "fits").exists()
    result = sensitivity._a12_final_component_batches(prepared, jobs, gather, shared, retained,
                                                      final_batches=list(reversed(batches)))
    predictions = sensitivity._a12_outer_predictions(prepared, jobs, result["rows"])
    for index, branch in enumerate(nested.AAR_ESTIMANDS):
        assert predictions["survival"][branch][0][24] == pytest.approx(.9 - .01 * index - .0105, abs=1e-15)
    assert calls.count("UNFITTED_CREATE") == len(audits) == len(result["native_members"]) == 60
    assert len(list((gather / "fits").iterdir())) == 60 and not list((gather / "fits").glob("*.zip"))
    assert result["execution"]["resource_reservation"]["component_retention_reserved_bytes"] == 0
    assert len(result["execution"]["final_batches"]) == 6
    assert result["execution"]["resource_reservation"]["resource_release_reserved_bytes"] == 60 * 128 * 1024
    for batch in batches:
        pin = strict_json_bytes((batch / "execution.json").read_bytes())["resource_release"]
        assert (gather / pin["path"]).read_bytes() == (batch / "resource-release.json").read_bytes()
    (tmp_path / "aar-final-shards-observation.json").write_bytes(canonical_json_bytes({
        "model_fits": 0, "leaf_adapter": "UNFITTED", "native_first_audits": 60, "shards": 6,
        "gather_native_object_opens": 0, "original_three_m20_reducer": True, "negative_cases": list(negatives)}))


def test_aar_final_release_exact_last_use_and_no_downgrade(final_jobs, tmp_path, monkeypatch):
    prepared, jobs, shared, retained, calls, audits = final_jobs
    names = [job["name"] for job in jobs[:2]]
    batch = tmp_path / "final-batches" / "original"
    original = runtime.release_step_resources
    observed = []
    def release(files, **kwargs):
        if kwargs["owner"].startswith("AAR_FINAL_BATCH_FILES:"):
            assert len(files) == 26 and calls.count("UNFITTED_CREATE") == len(audits) == 2
            assert all((batch / "fits" / (name + ".numbers.json")).is_file() for name in names)
            before = {str(path): sha256_file(path) for path in files}
            result = original(files, **kwargs)
            assert before == {str(path): sha256_file(path) for path in files}
            observed.append(before)
            return result
        return original(files, **kwargs)
    monkeypatch.setattr(runtime, "release_step_resources", release)
    result = sensitivity._a12_final_component_batches(prepared, jobs, tmp_path, shared, retained,
        task_names=names, batch_root=batch)
    assert len(observed) == 1 and shared["inputs.zip"].read_bytes() == b"UNFITTED_UPSTREAM_BYTE_BOUNDARY"
    record = result["execution_report"]
    pin = record["resource_release"]
    raw = (batch / "resource-release.json").read_bytes()
    components, native = {}, {}
    for name in names:
        path = batch / "fits" / (name + ".numbers.json")
        components[name] = {"sha256": sha256_file(path), "size_bytes": path.stat().st_size}
        number = strict_json_bytes(path.read_bytes())
        native[name] = {key: number[key] for key in ("native_archive", "native_expanded_bytes")}
    def read(value, reports):
        sensitivity._a12_final_batch_execution([value], components, prepared=prepared, jobs=jobs,
            shared_sizes={name: path.stat().st_size for name, path in shared.items()}, retained=retained,
            complete=False, release_reports=reports, component_native=native, expected_roots=(tmp_path, batch))
    read(record, {pin["path"]: raw})
    for damage in ("missing_pin_old_reserve", "joint_roots", "missing_file", "wrong_size", "early_copy",
                   "unknown_worker", "boolean_size", "after_admission_bool", "forged_after_zero", "extra_leaf"):
        changed, leaf = copy.deepcopy(record), strict_json_bytes(raw)
        if damage == "missing_pin_old_reserve":
            changed.pop("resource_release")
            reserved = changed["resource_reservation"]
            allowance = reserved.pop("resource_release_reserved_bytes")
            reserved["metadata_reserved_bytes"] -= allowance
            reserved["archive_reserved_bytes"] -= 2 * allowance
            reserved["coordinator_memory_estimate_bytes"] -= 32 * allowance
            if "execution_scratch_reserve_bytes" not in reserved:
                reserved["effective_policy"]["scratch_reserve_bytes"] -= 3 * allowance
            reserved["effective_policy"]["memory_reserve_bytes"] -= 32 * allowance
            changed["resource_admission"] = runtime.resource_admission(reserved["effective_policy"],
                changed["resource_observation"], legal_tasks=2)
        elif damage == "joint_roots":
            new = tmp_path / "UNFITTED-resealed-different-owner"
            changed["resource_observation"]["scratch_root"] = str(new)
            leaf["native_root"], leaf["batch_root"] = str(new), str(new / "final-batches/original")
            leaf["after_release"]["resource_observation"]["scratch_root"] = str(new)
            for file in leaf["coordinator"]["files"]:
                file["path"] = str(new / Path(file["path"]).relative_to(tmp_path))
        elif damage == "missing_file":
            leaf["coordinator"]["files"].pop()
        elif damage == "wrong_size":
            leaf["coordinator"]["files"][0]["size_bytes"] += 1
        elif damage == "early_copy":
            leaf["coordinator"]["before"]["started_ns"] = leaf["coordinator"]["before"]["finished_ns"] = 1
        elif damage == "unknown_worker":
            leaf["worker_results"]["0"] = {"status": "UNKNOWN", "owner": "POOL_TASK_RESULT:0",
                "pid": 1, "reason": "UNFITTED_DIAGNOSTIC_LOSS"}
        elif damage == "after_admission_bool":
            leaf["after_release"]["resource_admission"]["admitted_worker_ceiling"] = True
        elif damage == "forged_after_zero":
            leaf["after_release"]["resource_admission"] = None
            leaf["operational_errors"] = [{"operation": "POST_STEP_ADMISSION", "error": "RESOURCE_ADMISSION_ZERO:{}"}]
        encoded = canonical_json_bytes(leaf)
        reports = {pin["path"]: encoded}
        if "resource_release" in changed:
            changed["resource_release"].update(sha256=sha256_bytes(encoded), size_bytes=len(encoded))
        if damage == "boolean_size":
            changed["resource_release"]["size_bytes"] = True
        if damage == "extra_leaf":
            reports["final-batches/unrequested/resource-release.json"] = encoded
        with pytest.raises(ContractError):
            read(changed, reports)
    assert (batch / "execution.json").read_bytes() == canonical_json_bytes(record)
    assert (batch / "resource-release.json").read_bytes() == raw
    assert calls.count("UNFITTED_CREATE") == len(audits) == 2


@pytest.mark.parametrize("fault", ["open_reader", "post_admission", "post_observation", "scan", "advice", "fsync"])
def test_aar_final_release_failure_keeps_completed_coordinates(final_jobs, tmp_path, monkeypatch, fault):
    prepared, jobs, shared, retained, calls, audits = final_jobs
    names = [job["name"] for job in jobs[:2]]
    batch = tmp_path / "final-batches" / "failure"
    release = runtime.release_step_resources
    observed = []
    def completed_release(files, **kwargs):
        if kwargs["owner"].startswith("AAR_FINAL_BATCH_FILES:"):
            observed.append(1)
            if fault == "open_reader":
                with files[0].open("rb"):
                    return release(files, **kwargs)
            if fault == "scan":
                def scan(keys):
                    raise OSError("UNFITTED_SCAN_DENIED")
                monkeypatch.setattr(runtime, "_visible_open_file_keys", scan)
            elif fault in {"advice", "fsync"}:
                def fail(*args):
                    raise OSError("UNFITTED_" + fault.upper() + "_FAILED")
                with monkeypatch.context() as scoped:
                    scoped.setattr(runtime, "_visible_open_file_keys", lambda keys: (set(), 1))
                    scoped.setattr(runtime.os, "posix_fadvise" if fault == "advice" else "fsync", fail)
                    return release(files, **kwargs)
        return release(files, **kwargs)
    monkeypatch.setattr(runtime, "release_step_resources", completed_release)
    observe = runtime.observe_execution_resources
    def resources(root):
        if observed and fault == "post_observation":
            raise OSError("UNFITTED_POST_STEP_OBSERVATION_UNAVAILABLE")
        value = observe(root)
        if observed and fault == "post_admission":
            value["available_memory_bytes"] = 1
        return value
    monkeypatch.setattr(runtime, "observe_execution_resources", resources)
    if fault == "fsync":
        with pytest.raises(ContractError, match="FINAL_BATCH_RELEASE_INVALID"):
            sensitivity._a12_final_component_batches(prepared, jobs, tmp_path, shared, retained,
                task_names=names, batch_root=batch)
        failure = strict_json_bytes((batch / "failure.json").read_bytes())
        assert failure["execution"]["new_model_fits"] == failure["execution"]["new_model_native_verification_count"] == 2
        assert set(failure["confirmed_native_audits"]) == set(names)
        assert not (batch / "execution.json").exists()
    else:
        result = sensitivity._a12_final_component_batches(prepared, jobs, tmp_path, shared, retained,
            task_names=names, batch_root=batch)
        assert result["new_model_fits"] == result["new_model_native_verification_count"] == 2
        assert (batch / "execution.json").is_file() and not (batch / "failure.json").exists()
        leaf = strict_json_bytes((batch / "resource-release.json").read_bytes())
        if fault == "post_admission":
            assert leaf["after_release"]["resource_admission"] is None
            assert len(leaf["operational_errors"]) == 1
            assert leaf["operational_errors"][0]["operation"] == "POST_STEP_ADMISSION"
            assert leaf["operational_errors"][0]["error"].startswith("RESOURCE_ADMISSION_ZERO:")
            with pytest.raises(ContractError, match="RESOURCE_ADMISSION_ZERO"):
                runtime.resource_admission(result["execution_report"]["resource_reservation"]["effective_policy"],
                    resources(tmp_path), legal_tasks=1)
        elif fault == "scan":
            assert leaf["coordinator"]["reader_scan_status"] == "UNKNOWN"
        elif fault == "advice":
            assert all(row["error"].startswith("RESOURCE_RELEASE_ADVICE_FAILED:") for row in leaf["coordinator"]["files"])
        elif fault == "post_observation":
            assert leaf["after_release"] == {"resource_observation": None, "resource_admission": None}
            assert leaf["operational_errors"][0]["operation"] == "POST_STEP_OBSERVATION"
            with pytest.raises(OSError, match="POST_STEP_OBSERVATION_UNAVAILABLE"):
                resources(tmp_path)
    assert (batch / "resource-release.json").is_file()
    assert all((tmp_path / "fits" / (name + ".zip")).is_file() for name in names)
    assert all((batch / "fits" / (name + ".numbers.json")).is_file() for name in names)
    assert calls.count("UNFITTED_CREATE") == len(audits) == 2
    with pytest.raises(ContractError, match="FINAL_COORDINATE_ALREADY_STARTED"):
        sensitivity._a12_final_component_batches(prepared, jobs, tmp_path, shared, retained,
            task_names=names, batch_root=tmp_path / "final-batches" / "not-a-new-allowance")


def test_aar_final_failed_first_audit_retains_unknown_fit_total_and_native_owner(final_jobs, tmp_path, monkeypatch):
    prepared, jobs, shared, retained, calls, audits = final_jobs
    original = f5._validate_retained_model_objects
    attempts = []
    def audit(*args, **kwargs):
        attempts.append(1)
        if len(attempts) == 2:
            raise ContractError("UNFITTED_SECOND_AUDIT_FAILURE")
        return original(*args, **kwargs)
    monkeypatch.setattr(f5, "_validate_retained_model_objects", audit)
    root = tmp_path / "worker"
    root.mkdir()
    batch = root / "final-batches" / "failure"
    names = [job["name"] for job in jobs[:3]]
    with pytest.raises(ContractError, match="UNFITTED_SECOND_AUDIT_FAILURE"):
        sensitivity._a12_final_component_batches(prepared, jobs, root, shared, retained,
            task_names=names, batch_root=batch)
    value = strict_json_bytes((batch / "failure.json").read_bytes())
    assert value["execution"]["new_model_fits"] is None
    assert value["execution"]["new_model_native_verification_count"] == len(value["confirmed_native_audits"]) == 1
    assert calls.count("UNFITTED_CREATE") == len(list((root / "fits").glob("*.zip"))) == 2
    assert len(audits) == 1 and not (batch / "execution.json").exists()
    with pytest.raises(ContractError, match="FINAL_COORDINATE_ALREADY_STARTED"):
        sensitivity._a12_final_component_batches(prepared, jobs, root, shared, retained,
            task_names=names[-1:], batch_root=root / "final-batches" / "renamed")


@pytest.mark.parametrize("resource", ["memory", "scratch"])
def test_aar_final_shard_admits_before_any_native_start(final_jobs, tmp_path, monkeypatch, resource):
    prepared, jobs, shared, retained, calls, audits = final_jobs
    names = [job["name"] for job in jobs[:3]]
    reservation = sensitivity._a12_final_resource_reservation(prepared["source"], jobs,
        {name: path.stat().st_size for name, path in shared.items()}, retained, task_names=names,
        execution_worker_memory_bytes=2 * 1024**3, execution_scratch_reserve_bytes=0)
    policy = reservation["effective_policy"]
    observation = {"effective_cpus": 32, "available_memory_bytes": 10**12,
                   "scratch_available_bytes": 10**12, "scratch_root": str(tmp_path)}
    observation["available_memory_bytes" if resource == "memory" else "scratch_available_bytes"] = (
        policy[resource + "_reserve_bytes"] + policy[resource + "_bytes_per_worker"] - 1)
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda root: observation)
    batch = tmp_path / "final-batches" / "assignment"
    with pytest.raises(ContractError):
        sensitivity._a12_final_component_batches(prepared, jobs, tmp_path, shared, retained,
            task_names=names, batch_root=batch)
    assert not calls and not audits and not batch.exists() and not (tmp_path / "fits").exists()


def test_aar_final_future_scratch_reaches_original_execution_reader(final_jobs, tmp_path, monkeypatch):
    prepared, jobs, shared, retained, calls, audits = final_jobs
    names = [job["name"] for job in jobs[:2]]
    prepared["source"]["resource_policy"]["scratch_reserve_bytes"] = 1024**3
    sizes = {name: path.stat().st_size for name, path in shared.items()}
    historical = sensitivity._a12_final_resource_reservation(prepared["source"], jobs,
        sizes, retained, task_names=names, execution_worker_memory_bytes=2 * 1024**3)
    observation = {"effective_cpus": 32, "available_memory_bytes": 10**12,
        "scratch_available_bytes": 64 * 1024**2, "scratch_root": str(tmp_path)}
    with pytest.raises(ContractError, match="RESOURCE_ADMISSION_ZERO"):
        runtime.resource_admission(historical["effective_policy"], observation, legal_tasks=2)
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda root: observation)
    batch = tmp_path / "final-batches" / "future-policy"
    result = sensitivity._a12_final_component_batches(prepared, jobs, tmp_path, shared, retained,
        task_names=names, batch_root=batch)
    record = result["execution_report"]
    assert record["resource_reservation"]["execution_scratch_reserve_bytes"] == 0
    assert record["resource_reservation"]["effective_policy"]["scratch_reserve_bytes"] == 0
    assert historical["effective_policy"]["scratch_reserve_bytes"] > 1024**3
    assert calls.count("UNFITTED_CREATE") == len(audits) == 2
    components, native = {}, {}
    for name in names:
        path = batch / "fits" / (name + ".numbers.json")
        components[name] = {"sha256": sha256_file(path), "size_bytes": path.stat().st_size}
        numbers = strict_json_bytes(path.read_bytes())
        native[name] = {key: numbers[key] for key in ("native_archive", "native_expanded_bytes")}
    def read(value):
        sensitivity._a12_final_batch_execution([value], components, prepared=prepared, jobs=jobs,
            shared_sizes=sizes, retained=retained, complete=False,
            release_reports={record["resource_release"]["path"]: (batch / "resource-release.json").read_bytes()},
            component_native=native, expected_roots=(tmp_path, batch))
    read(record)
    for marker in (True, 1, None):
        changed = copy.deepcopy(record)
        if marker is None:
            del changed["resource_reservation"]["execution_scratch_reserve_bytes"]
        else:
            changed["resource_reservation"]["execution_scratch_reserve_bytes"] = marker
        with pytest.raises(ContractError):
            read(changed)
    assert calls.count("UNFITTED_CREATE") == len(audits) == 2


@pytest.mark.parametrize("mode", ["prepare", "worker", "gather"])
def test_original_aar_cli_forwards_final_coordinate_mode(tmp_path, monkeypatch, capsys, mode):
    import sys
    source, target, projected = [tmp_path / name for name in ("inputs.zip", "result.zip", "projected.zip")]
    calls = []
    def execute(*args, **kwargs):
        calls.append((args, kwargs))
        return {"UNFITTED_CLI": True}
    monkeypatch.setattr(sensitivity, "execute_a12_outer_bundle", execute)
    options = {"prepare": ["--prepare-final"],
        "worker": ["--final-task-ids", "O1_A12_WITHOUT_AST_ALT_DIRECT_M01", "--final-batch-root", str(tmp_path / "batch")],
        "gather": ["--final-batches", str(tmp_path / "batch0"), str(tmp_path / "batch1")]}[mode]
    monkeypatch.setattr(sys, "argv", ["padml-f5", "a12-outer", str(source), str(target), "--input-bundle", str(projected),
        "--retained-bytes-per-component", "2097152", *options])
    f5.main()
    assert len(calls) == 1 and "UNFITTED_CLI" in capsys.readouterr().out
    kwargs = calls[0][1]
    assert calls[0][0] == (source, target) and kwargs["input_bundle"] == projected
    if mode == "prepare":
        assert kwargs["prepare_final"] is True
    elif mode == "worker":
        assert kwargs["final_task_ids"] == [options[1]] and kwargs["final_batch_root"] == tmp_path / "batch"
    else:
        assert kwargs["final_batches"] == [tmp_path / "batch0", tmp_path / "batch1"]


def _unfitted_a12_input_release(root, binding, result, policy):
    """A real bounded release leaf for transport tests; no scientific producer."""
    from padml.f4 import _f45_source_member_sha256
    root.mkdir()
    owners, expected = {}, {}
    for name, directory in (("archive", "archive"), ("materialized_inputs", "inputs")):
        owned = root / directory
        owned.mkdir()
        path = owned / "UNFITTED.txt"
        path.write_bytes(b"UNFITTED_RELEASE_TRANSPORT_ONLY")
        owners[name] = {"temporary_root": str(owned)}
        expected[name] = {"root": owned, "files": {str(path): path.stat().st_size}}
    encoded = canonical_json_bytes(result)
    result_pin = {"sha256": sha256_bytes(encoded), "size_bytes": len(encoded)}
    effective = {**policy, "memory_reserve_bytes": policy["memory_reserve_bytes"] + 32 * 32 * 1024**2,
                 "scratch_reserve_bytes": policy["scratch_reserve_bytes"] + 64 * 1024**2}
    current_executor = binding["executor_source_identity"] == sha256_bytes(
        canonical_json_bytes(_f45_source_member_sha256()))
    execution_policy = {}
    if current_executor:
        execution_policy = {"execution_worker_memory_bytes": 2 * 1024**3,
                            "execution_scratch_reserve_bytes": 0, "operational_errors": []}
        effective.update(memory_bytes_per_worker=2 * 1024**3, scratch_reserve_bytes=0)
    observation = runtime.observe_execution_resources(root)
    before = runtime.observe_step_memory()
    report = {**binding, **execution_policy, "result": result_pin, "resource_policy": policy, "effective_policy": effective,
        "resource_observation": observation, "resource_admission": runtime.resource_admission(effective, observation, legal_tasks=1),
        "last_consumer_finished_ns": before["started_ns"], "input_lifecycle": owners}
    for name, row in sorted(owners.items()):
        row["resource_release"] = runtime.release_step_resources([Path(path) for path in expected[name]["files"]],
            owner="AAR_FINAL_INPUTS:" + binding["operation"] + ":" + str(binding["outer_fold"]) + ":" + name
                + ":" + result_pin["sha256"], before=before,
            released_references=["completed_a12_input_callers", "materialized_a12_inputs",
                                 "completed_a12_component_jobs", "completed_a12_prediction_rows"])
        before = runtime.observe_step_memory()
    observation = runtime.observe_execution_resources(root)
    report["after_release"] = {"resource_observation": observation,
        "resource_admission": runtime.resource_admission(effective, observation, legal_tasks=1)}
    raw = canonical_json_bytes(report)
    sensitivity._validate_a12_final_input_execution(raw, binding=binding, result_pin=result_pin,
        policy=policy, expected_owners=expected)
    return raw, result_pin, expected


@pytest.mark.parametrize("damage", ["source", "result", "missing_owner", "missing_file", "wrong_root",
    "early_release", "active_reader", "unknown", "bool_admission", "pin"])
def test_a12_final_input_reader_rejects_changed_native_binding(tmp_path, monkeypatch, damage):
    # This is a diagnostics consumer test; model fitting/input fixtures are
    # unrelated to its byte, owner and release-order contract.
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda root: {
        "effective_cpus": 32, "available_memory_bytes": 10**12,
        "scratch_available_bytes": 10**12, "scratch_root": str(root)})
    monkeypatch.setattr(runtime, "_visible_open_file_keys", lambda keys: (set(), 1))
    # The legacy dialect requires an observed Linux reader scan. Its scanner
    # is replaced above; this tests transport validation, not this Mac's /proc.
    monkeypatch.setattr(runtime.sys, "platform", "linux")
    jobs = [{"name": name} for name in sensitivity._a12_final_task_coordinates(1)]
    root = tmp_path / "report-owner"
    policy = dict(configured_worker_ceiling=runtime.CPU_MINUS_8, memory_bytes_per_worker=2*1024**3,
        scratch_bytes_per_worker=1, memory_reserve_bytes=0, scratch_reserve_bytes=0,
        transfer_archive_worker_ceiling=1000)
    binding = {"executor_source_identity": "a" * 64, "operation": "OUTER_REPLAY", "outer_fold": 1,
        "family": "COX_PH", "task_names": [job["name"] for job in jobs],
        "input_archive": {"sha256": "b" * 64, "size_bytes": 123},
        "projected_input": {"sha256": "c" * 64, "size_bytes": 456},
        "projected_input_identity_sha256": "d" * 64, "work_root": str(root)}
    raw, result_pin, owners = _unfitted_a12_input_release(root, binding, {"UNFITTED": True}, policy)
    value = strict_json_bytes(raw)
    changed = copy.deepcopy(value)
    release = changed["input_lifecycle"]["materialized_inputs"]["resource_release"]
    if damage == "source":
        changed["executor_source_identity"] = "e" * 64
    elif damage == "result":
        changed["result"]["sha256"] = "e" * 64
    elif damage == "missing_owner":
        del changed["input_lifecycle"]["archive"]
    elif damage == "missing_file":
        release["files"] = []
    elif damage == "wrong_root":
        changed["input_lifecycle"]["materialized_inputs"]["temporary_root"] = str(tmp_path)
    elif damage == "early_release":
        changed["last_consumer_finished_ns"] = release["after"]["finished_ns"] + 1
    elif damage == "active_reader":
        release["files"][0]["status"] = "ACTIVE_READER_OR_WRITER"
    elif damage == "unknown":
        release["reader_scan_status"] = "UNKNOWN"
    elif damage == "bool_admission":
        changed["after_release"]["resource_admission"]["admitted_worker_ceiling"] = True
    with pytest.raises(ContractError):
        sensitivity._validate_a12_final_input_execution(canonical_json_bytes(changed), binding=binding,
            result_pin=result_pin, policy=policy, expected_owners=owners,
            **({"expected_pin": {"sha256": "f" * 64, "size_bytes": len(raw)}} if damage == "pin" else {}))
    envelope = canonical_json_bytes({"input_execution": value, "UNFITTED_original_reader": True})
    sensitivity._validate_a12_final_input_execution(envelope, binding=binding, result_pin=result_pin, policy=policy,
        expected_pin={"sha256": sha256_bytes(envelope), "size_bytes": len(envelope)}, loader_report=True)


@pytest.mark.parametrize("fault", [None, "open_reader", "post_admission", "post_observation", "oversized_report"])
def test_a12_final_call_releases_inputs_after_return_or_preserves_completed_result(final_jobs, tmp_path, monkeypatch, fault):
    """Only upstream preparation is stubbed; original two-model unit and tail run."""
    prepared, jobs, shared, retained, calls, audits = final_jobs
    branch = nested.A12_DIRECT_AAR
    prepared = {**prepared, "branches": {branch: {}}, "source": {**prepared["source"], "identity_sha256": "d" * 64}}
    projected, target = tmp_path / "projected.zip", tmp_path / "result.zip"
    projected.write_bytes(b"UNFITTED_PROJECTED_INPUT_BOUNDARY")
    root = target.with_name(target.name + ".work")
    (root / "development").mkdir(parents=True)
    development = root / "development/development.json"
    development.write_bytes(canonical_json_bytes(prepared["branch_development"]))
    preserved = sha256_file(development)
    references, materialized = [], []
    class InputToken:
        pass
    def materialize(source, lineage, destination, **kwargs):
        destination.mkdir(parents=True)
        member = destination / "UNFITTED-input.csv"
        member.write_bytes(b"UNFITTED_DISPOSABLE_INPUT")
        materialized.append(member)
        token = InputToken()
        references.append(weakref.ref(token))
        return {**prepared, "input_expansion_resources": {}, "UNFITTED_owner_token": token}
    def development_reader(value, directory, *, q_input_lifecycle, **kwargs):
        work = directory.parent / "a12-development-replay-UNFITTED"
        work.mkdir()
        q_input_lifecycle["development_inputs"] = {"temporary_root": str(work)}
        return value
    monkeypatch.setattr(sensitivity, "materialize_a12_outer_inputs", materialize)
    monkeypatch.setattr(sensitivity, "_a12_projected_development_inputs", development_reader)
    monkeypatch.setattr(sensitivity, "_a12_outer_searches", lambda *args, **kwargs: {})
    monkeypatch.setattr(sensitivity, "_a12_outer_model_jobs", lambda value, searches, task_names: [
        job for job in jobs if job["name"] in task_names])
    monkeypatch.setattr(sensitivity, "_a12_outer_retained_members", lambda *args, **kwargs: shared)
    release_native, observe_native = runtime.release_step_resources, runtime.observe_execution_resources
    input_releases, handles = [], []
    def release(files, **kwargs):
        if kwargs["owner"].startswith("AAR_FINAL_INPUTS:"):
            assert all(reference() is None for reference in references)
            input_releases.append(kwargs["owner"])
            if fault == "open_reader" and files:
                handles.append(files[0].open("rb"))
        value = release_native(files, **kwargs)
        if fault == "oversized_report" and len(input_releases) == 1 and kwargs["owner"].startswith("AAR_FINAL_INPUTS:"):
            value["owner"] += "X" * (64 * 1024**2)
        return value
    def observe(where):
        if input_releases and fault == "post_observation":
            raise OSError("UNFITTED_POST_STEP_OBSERVATION_UNAVAILABLE")
        value = observe_native(where)
        return {**value, "available_memory_bytes": 1} if input_releases and fault == "post_admission" else value
    monkeypatch.setattr(runtime, "release_step_resources", release)
    monkeypatch.setattr(runtime, "observe_execution_resources", observe)
    names = [job["name"] for job in jobs[:2]]
    batch = root / "final-batches/only-attempt"
    try:
        if fault != "oversized_report":
            result = sensitivity.execute_a12_outer_bundle(shared["inputs.zip"], target, input_bundle=projected,
                retained_bytes_per_component=retained, final_task_ids=names, final_batch_root=batch)
            pin = result["input_execution"]
            assert sha256_file(Path(pin["path"])) == pin["sha256"]
            report = strict_json_bytes(Path(pin["path"]).read_bytes())
            assert report["execution_scratch_reserve_bytes"] == report["effective_policy"]["scratch_reserve_bytes"] == 0
            for row in report["input_lifecycle"].values():
                leaf = row["resource_release"]
                removable = leaf["reader_scan_status"] == "OBSERVED" and all(
                    member["status"] in {"ADVISED", "UNSUPPORTED"} and member["error"] is None for member in leaf["files"])
                assert Path(row["temporary_root"]).exists() != removable
            if fault == "open_reader":
                assert materialized[0].is_file()
            if fault == "post_admission":
                assert report["after_release"]["resource_admission"] is None
                assert report["operational_errors"][0]["operation"] == "POST_STEP_ADMISSION"
                with pytest.raises(ContractError, match="RESOURCE_ADMISSION_ZERO"):
                    runtime.resource_admission(report["effective_policy"], observe(root), legal_tasks=1)
            if fault == "post_observation":
                assert report["after_release"] == {"resource_observation": None, "resource_admission": None}
                assert report["operational_errors"][0]["operation"] == "POST_STEP_OBSERVATION"
                with pytest.raises(OSError, match="POST_STEP_OBSERVATION_UNAVAILABLE"):
                    observe(root)
                changed = copy.deepcopy(report)
                changed["operational_errors"] = []
                raw = canonical_json_bytes(changed)
                binding = {key: report[key] for key in ("executor_source_identity", "operation", "outer_fold", "family",
                    "task_names", "input_archive", "projected_input", "projected_input_identity_sha256", "work_root")}
                with pytest.raises(ContractError, match="FINAL_INPUT_EXECUTION_INVALID"):
                    sensitivity._validate_a12_final_input_execution(raw, binding=binding, result_pin=report["result"],
                        policy=report["resource_policy"], expected_pin={"sha256": sha256_bytes(raw), "size_bytes": len(raw)})
        else:
            with pytest.raises(ContractError) as error:
                sensitivity.execute_a12_outer_bundle(shared["inputs.zip"], target, input_bundle=projected,
                    retained_bytes_per_component=retained, final_task_ids=names, final_batch_root=batch)
            if fault == "oversized_report":
                assert not list(root.glob("input-execution-failure-*.json"))
                assert any("DIAGNOSTIC_WRITE_FAILED" in note for note in error.value.__notes__)
                execution = strict_json_bytes((batch / "execution.json").read_bytes())
                result = {"execution_report": execution, "new_model_fits": execution["new_model_fits"],
                    "new_model_native_verification_count": execution["new_model_native_verification_count"]}
            else:
                failure, = root.glob("input-execution-failure-*.json")
                assert failure.stat().st_size <= 64 * 1024**2
                result = strict_json_bytes(failure.read_bytes())["result"]
            assert materialized[0].is_file() and (root / "a12-development-replay-UNFITTED").is_dir()
        assert result["new_model_fits"] == result["new_model_native_verification_count"] == 2
        assert (batch / "execution.json").read_bytes() == canonical_json_bytes(result["execution_report"])
        assert all((root / "fits" / (name + ".zip")).is_file() for name in names)
        assert sha256_file(development) == preserved and calls.count("UNFITTED_CREATE") == len(audits) == 2
    finally:
        for handle in handles:
            handle.close()


def test_a12_original_v1_call_keeps_outer_capacity_binding(final_jobs, tmp_path, monkeypatch):
    """Original non-projected owner/tail; no worker or scientific preparation."""
    prepared, jobs, shared, retained, calls, audits = final_jobs
    target = tmp_path / "UNFITTED-v1.zip"
    monkeypatch.setattr(sensitivity, "materialize_a12_outer_inputs", lambda *args, **kwargs: prepared)
    monkeypatch.setattr(sensitivity, "_a12_outer_searches", lambda *args, **kwargs: {})
    monkeypatch.setattr(sensitivity, "_a12_outer_model_jobs", lambda *args, **kwargs: jobs[:1])
    monkeypatch.setattr(sensitivity, "_a12_outer_predictions", lambda *args: {"UNFITTED_V1_RETURN": True})
    monkeypatch.setattr(sensitivity, "_a12_outer_retained_members", lambda *args, **kwargs: shared)
    def pool(worker, assigned, *, selected_slots):
        assert selected_slots == 1 and len(assigned) == 1
        return [{"UNFITTED_POOL_RETURN": True}]
    monkeypatch.setattr(sensitivity, "_bounded_ordered_spawn", pool)
    result = sensitivity.execute_a12_outer_bundle(shared["inputs.zip"], target, lineage={}, f2_run_root=tmp_path, workers=1)
    assert result["pool_workers"] == result["outer_model_fit_count"] == 1
    assert "input_execution" not in result and not target.with_name(target.name + ".work").exists()
    value = strict_json_bytes(sensitivity.read_safe_zip(target)["a12-outer.json"])
    assert value["kind"] == "PADML_F5_A12_OUTER_NATIVE_V1" and value["predictions"] == {"UNFITTED_V1_RETURN": True}
    assert not calls and not audits
