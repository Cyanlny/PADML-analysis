"""One real1513 complete UNFITTED chain; negatives reuse its prepared target."""
import copy
import pytest
from padml import f4, f5, nested_loco as nested, runtime
from padml.bundle import ContractError, read_safe_zip, write_deterministic_zip
from test_primary1513_outer_fixture import real_primary1513_outer  # noqa: F401
from test_nested_aar_mice import aar_source  # noqa: F401
from test_primary1513_outer_fixture import (
    test_actual1513_fixed900_complete_primary_owner_and_archive_reader as complete_owner)


@pytest.mark.parametrize("real_primary1513_outer", [True], indirect=True, ids=["scoped-same-source"])
def test_computed_fixed900_without_custody_then_original_public_reader(
        real_primary1513_outer, aar_source, tmp_path, monkeypatch):
    original, reader = f4._execute_o_fit_training_bundle, f4._load_o_fit_execution_archive
    calls, captured, current_inputs = [], [], []
    def observe(path, **options):
        if options.get("outer_fixed12_target_request") is not None and options.get("f2_run_root") is None:
            captured.append((path, copy.deepcopy(options)))
        return reader(path, **options)
    monkeypatch.setattr(f4, "_load_o_fit_execution_archive", observe)
    def forbidden(*args, **kwargs):
        pytest.fail("COMPUTATION_MUST_NOT_OPEN_CUSTODY_OR_START_NUMBERS")
    def computed(input_bundle, target, **options):
        if options.get("retained_native") is not None:
            calls.append("custody")
            assert options.get("f2_run_root") is not None
            return original(input_bundle, target, **options)
        calls.append("compute")
        current_inputs.append(input_bundle)
        with monkeypatch.context() as local:
            local.setattr(f4, "_load_f4_source_records", forbidden)
            return original(input_bundle, target, **{**options, "f2_run_root": None, "f1_runtime_root": None})
    monkeypatch.setattr(f4, "_execute_o_fit_training_bundle", computed)
    complete_owner(real_primary1513_outer, tmp_path, monkeypatch, actual_source=aar_source)
    assert calls == ["compute", "custody"] and len(captured) == 1
    path, valid = captured[0]
    # This record is not sealed on its own; its original ZIP/request binding
    # and the four validated target Q source bindings are the direct checks.
    with monkeypatch.context() as negative:
        negative.setattr(f4, "_load_f4_source_records", forbidden)
        negative.setattr(nested, "_recompute_fresh_score_from_evidence", forbidden)
        negative.setattr(f5, "_execute_final_refit_engine", forbidden)
        for index, field in enumerate(("f1_identity", "f2_acceptance_sha256", "identity_sha256", "sha256")):
            options = copy.deepcopy(valid)
            options["compiled_input_record"][field] = "f" * 64
            options["replay_evidence"] = tmp_path / f"negative-{field}"
            expected = "F4_O_FIT_ACCEPTED_INPUT_DRIFT" if field == "sha256" else "F4_O_FIT_COMPILED_INPUT_RECORD_INVALID"
            with pytest.raises(ContractError, match=expected):
                reader(path, **options)
        options = copy.deepcopy(valid)
        options.update(input_bundle=current_inputs[0], replay_evidence=tmp_path / "negative-input")
        with pytest.raises(ContractError, match="F4_O_FIT_COMPILED_INPUT_RECORD_INVALID"):
            reader(path, **options)
        entries = read_safe_zip(valid["retained_primary_source_bundle"])
        entries["padml/f2_kernel.py"] += b"\n# UNFITTED tampered source bytes\n"
        wrong_source = tmp_path / "tampered-source.zip"
        write_deterministic_zip(wrong_source, entries)
        options = copy.deepcopy(valid)
        options.update(retained_primary_source_bundle=wrong_source, replay_evidence=tmp_path / "negative-source")
        with pytest.raises(ContractError, match="F45_SOURCE_BUNDLE_INVALID"):
            reader(path, **options)
        for damage in ("missing-search", "cross-fold", "cross-line"):
            options = copy.deepcopy(valid)
            changed = options["outer_fixed12_target_request"]
            if damage == "missing-search":
                changed["primary_searches"].pop("RSF")
                expected = "NESTED_PRIMARY12_COMPLETE_SEARCHES_REQUIRED"
            else:
                # Keep the outer request canonical after changing the actual
                # source. The original Q consumer must reject its binding.
                q = changed["primary_searches"]["RSF"]["input"]
                source = q["spec"]["primary_search_source"]
                source["outer_fold" if damage == "cross-fold" else "selection_horizon_months"] = 2 if damage == "cross-fold" else 24
                expected = "F4_PRIMARY_RSF_SEARCH_SOURCE_INVALID"
            options["outer_fixed12_target_request"] = nested._sealed({k: v for k, v in changed.items() if k != "identity_sha256"})
            with pytest.raises(ContractError, match=expected):
                reader(path, **options)
        # First current-policy admission must run before any four-family
        # source or summary read, including the retained code bundles.
        class AdmissionDenied(Exception):
            pass
        negative.setattr(runtime, "resource_admission", lambda *a, **k: (_ for _ in ()).throw(AdmissionDenied()))
        negative.setattr(nested, "_validate_outer_primary_searches", forbidden)
        with pytest.raises(AdmissionDenied):
            reader(path, **valid)


def test_public_reader_cannot_select_compute_mode_without_private_owner(tmp_path):
    with pytest.raises(ContractError, match="F4_RETAINED_PRIMARY_SOURCE_SCOPE_INVALID"):
        f4.load_o_fit_execution_archive(tmp_path / "UNREAD.zip", input_bundle=tmp_path / "input.zip",
            compiled_input_record={}, retained_primary_source_bundle=tmp_path / "source.zip", f2_run_root=None)
    with pytest.raises(ContractError, match="F4_O_FIT_FIXED12_RESCORE_SCOPE_INVALID"):
        f4._load_o_fit_execution_archive(tmp_path / "UNREAD.zip", f2_run_root=None,
            outer_fixed12_target_request={}, outer_fixed12_target_root=tmp_path)
