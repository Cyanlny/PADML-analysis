"""Finite code/context/selector provenance for fresh Q; synthetic boundaries only."""
import copy
import os
from pathlib import Path
import shutil
from types import SimpleNamespace

import pytest

from padml import f2_kernel, f4, f5_sensitivity as sensitivity, nested_loco as nested, runtime
from padml.bundle import (ContractError, canonical_json_bytes, sha256_bytes, sha256_file,
                          strict_json_bytes, write_deterministic_zip)
from test_nested_aar_mice import aar_source, unfitted_selector_engines  # noqa: F401
from test_nested_full_development import _unfitted_confirmed_decision
from test_retained_full0_source import retained_source_bundle, retained_gbm_q_bundle  # noqa: F401


@pytest.fixture
def retained_selector_bundle():
    path = Path(os.environ["PADML_RETAINED_SELECTOR_SOURCE_BUNDLE"])
    assert path.is_absolute() and path.is_file() and not path.is_symlink()
    return path


@pytest.fixture
def old_primary_q_source(retained_source_bundle, monkeypatch):
    retained = f4._retained_full0_source_members(retained_source_bundle, aar_primary_context=True)
    with monkeypatch.context() as producer:
        producer.setattr(f4, "_f45_source_member_sha256", lambda: retained)
        primary = aar_source.__wrapped__(monkeypatch)[3]
    science = _unfitted_confirmed_decision(fixed_bootstrap=True)
    lock = {key: value for key, value in primary["primary_development_lock"].items() if key != "identity_sha256"}
    lock["science_decision_binding"] = nested._outer_science_decision_binding(science)
    primary = {**primary, "science_decision": science, "primary_development_lock": nested._sealed(lock)}
    projected = nested._sealed({"kind": "PADML_F5_A12_PROJECTED_OUTER_INPUTS_V1",
        "family": "GBM_COX", "outer_fold": 1, "primary_source": primary})
    return {"source": projected, "family": "GBM_COX", "outer_fold": 1,
        "branch": nested.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT,
        "inputs_identity_sha256": "a" * 64, "development_input_sha256": "b" * 64}


def test_primary_context_proof_never_admits_old_q_or_twelve_month_scope(
        old_primary_q_source, retained_source_bundle, retained_selector_bundle):
    source = old_primary_q_source
    options = {"family": "GBM_COX", "outer": 1, "retained_primary_source_bundle": retained_source_bundle,
               "retained_primary_context": True}
    for branch in nested.AAR_ESTIMANDS:
        sensitivity._validate_a12_search_source({**source, "branch": branch}, **options)
    for path in (retained_source_bundle, retained_selector_bundle):
        with pytest.raises(ContractError, match="F5_RETAINED_FULL0_SOURCE_INCOMPATIBLE"):
            f4._retained_full0_source_members(path)
    with pytest.raises(ContractError):
        sensitivity._validate_a12_search_source(source, **{**options, "retained_primary_context": False})
    with pytest.raises(ContractError):
        sensitivity._validate_a12_search_source(source, **{**options, "retained_primary_source_bundle": None})
    for damage in ("branch", "family", "outer", "lock", "twelve"):
        bad, arguments = copy.deepcopy(source), dict(options)
        if damage == "branch":
            bad["branch"] = "WITHOUT_AST_ALT_TOTAL"
        elif damage == "family":
            bad["family"] = arguments["family"] = "RSF"
        elif damage == "outer":
            arguments["outer"] = 2
        elif damage == "lock":
            bad["source"]["primary_source"]["primary_development_lock"]["training_ids_sha256"] = "f" * 64
        else:
            decision = bad["source"]["primary_source"]["science_decision"]
            bad["source"]["primary_source"]["science_decision"] = nested._sealed({
                **{key: value for key, value in decision.items() if key != "identity_sha256"},
                "twelve_month_development": nested._twelve_month_development_contract()})
        with pytest.raises(ContractError):
            sensitivity._validate_a12_search_source(bad, **arguments)


def test_source73_q_native_spec_pair_is_numbers_only_and_keeps_original_bytes(
        old_primary_q_source, retained_source_bundle, retained_gbm_q_bundle, tmp_path, monkeypatch):
    """Synthetic old transport bytes; no claim of fitted or historical models."""
    from padml import f5, f4_compact as compact
    old_identity = sha256_bytes(canonical_json_bytes(
        f4._retained_gbm_q_source_members(retained_gbm_q_bundle, retained_source_bundle)))
    current = sha256_bytes(canonical_json_bytes(f4._f45_source_member_sha256()))
    original_native = tmp_path / "original/native"
    transported = tmp_path / "transport/native"
    original_native.mkdir(parents=True)
    transported.mkdir(parents=True)
    producer = {"task_id": "UNFITTED_STOP", "family": "GBM_COX", "producer_kind": "GBM_STOP_CURVE",
                "seed": 301101, "parameters": {"max_trees": 5000}}
    base = {"schema_version": "1.0.0", "execution_scope": "F5_A12_SEARCH", "fold": 1,
        "family": "GBM_COX", "seed": 301000, "outcome": "All_Cause_Death", "time": "Death_Followup_months",
        "horizons": list(range(37)), "heldout_center": 36, "predictors": {}, "fpm": None,
        "selector_from_dependency": {"selected_parents": ["Age"], "outer_recipe_sha256": "RAW_CANONICAL"},
        "a12_source": old_primary_q_source, "registered_inputs_identity_sha256": "c" * 64,
        "retained_a12_primary_context_source_bundle": str(retained_source_bundle),
        "a12_executor_source_identity": current, "native_search_root": str(transported),
        "native_search_replay": True, "native_search_numbers": True}
    parent = {**base, "retained_gbm_q_source_bundle": str(retained_gbm_q_bundle)}
    child = f2_kernel._r_prediction_child_spec(parent)
    assert child["retained_gbm_q_source_bundle"] == str(retained_gbm_q_bundle)
    assert child["a12_executor_source_identity"] == current
    actual = {**child, "action": "MODEL_PREDICTION_BATCH", "producer_tasks": [producer],
        "registered_partitions": {"view_count": 1, "partitions": [{
            "covariates": {"input_dir": "/UNFITTED/input"}, "fit_response": {"path": "/UNFITTED/response"}}]}}
    name = "batch-" + sha256_bytes(canonical_json_bytes([producer["task_id"]]))[:24]
    batch = transported / name
    batch.mkdir()
    saved = {key: value for key, value in actual.items()
             if key not in {"retained_gbm_q_source_bundle", "native_search_numbers"}}
    saved.update(native_search_root=str(original_native), native_search_replay=False,
                 a12_executor_source_identity=old_identity, output_path="/UNFITTED/original/output.json",
                 retained_a12_primary_context_source_bundle="/UNFITTED/original/primary-proof.zip")
    saved_raw = canonical_json_bytes(saved)
    (batch / "spec.json").write_bytes(saved_raw)
    (batch / "output.json").write_bytes(canonical_json_bytes({"UNFITTED": "source73 transport"}))
    calls = []
    def object_boundary(root, spec, members):
        assert spec["native_search_numbers"] is True and members == {"model.rds"}
        calls.append(root.name)
    monkeypatch.setattr(compact, "_full_pipeline_q_object_numbers", object_boundary)
    monkeypatch.setattr(f4.subprocess, "run", lambda *a, **k: pytest.fail("NO_FIT_OR_NATIVE_AUDIT"))
    def consume(value, label):
        work = tmp_path / label
        work.mkdir()
        spec = work / "spec.json"
        output = work / "output.json"
        spec.write_bytes(canonical_json_bytes({**value, "output_path": str(output)}))
        return f4._run_full_pipeline_r_search_batch(spec, output, tmp_path, {})
    assert consume(actual, "numbers") == {"UNFITTED": "source73 transport"}
    assert calls == [producer["task_id"]] and (batch / "spec.json").read_bytes() == saved_raw
    for damage in ("missing-q-proof", "missing-primary", "old-as-current", "current-as-old",
                   "seed", "view-count", "locked-trees", "order", "native-audit", "produce", "twelve", "family",
                   "total-q73", "direct-q73"):
        value = copy.deepcopy(actual)
        if damage == "missing-q-proof":
            del value["retained_gbm_q_source_bundle"]
        elif damage == "missing-primary":
            del value["retained_a12_primary_context_source_bundle"]
        elif damage == "old-as-current":
            value["a12_executor_source_identity"] = old_identity
        elif damage == "current-as-old":
            (batch / "spec.json").write_bytes(canonical_json_bytes({**saved, "a12_executor_source_identity": current}))
        elif damage == "seed":
            value["producer_tasks"][0]["seed"] += 1
        elif damage == "view-count":
            value["registered_partitions"]["view_count"] = 2
        elif damage == "locked-trees":
            value["producer_tasks"][0]["parameters"]["max_trees"] -= 1
        elif damage == "order":
            value["producer_tasks"].insert(0, {**producer, "task_id": "UNFITTED_OTHER"})
        elif damage == "native-audit":
            del value["native_search_numbers"]
        elif damage == "produce":
            value["native_search_replay"] = False
        elif damage == "twelve":
            value["selection_horizon_months"] = 12
        elif damage in {"total-q73", "direct-q73"}:
            value["a12_source"]["branch"] = (nested.A12_TOTAL_AAR if damage == "total-q73"
                                               else nested.A12_DIRECT_AAR)
        else:
            value["family"] = "RSF"
        with pytest.raises(ContractError, match="F5_RETAINED_GBM_Q_NUMBERS_ONLY"
                           if damage in {"total-q73", "direct-q73"} else None):
            consume(value, damage)
        (batch / "spec.json").write_bytes(saved_raw)
    assert calls == [producer["task_id"]] and (batch / "spec.json").read_bytes() == saved_raw
    leaf = (base, {}, [producer], "UNFITTED", "UNFITTED", "GROUPED_COX_LOCK", {})
    for mode in ("produce", "audit"):
        with pytest.raises(ContractError, match="F5_RETAINED_GBM_Q_NUMBERS_ONLY"):
            f5._q_search_unit_call(f2_kernel._run_r_prediction_pool_task, leaf, transported.parent, tmp_path,
                mode=mode, retained_gbm_q_source_bundle=str(retained_gbm_q_bundle))


def test_primary_context_reaches_original_direct_total_development_and_final_jobs(
        old_primary_q_source, retained_source_bundle, tmp_path, monkeypatch, request):
    """Actual recipe/M20/task consumers; synthetic inputs and no fitted Q leaf."""
    import test_nested_aar_mice as fixtures
    from test_nested_aar_mice import unfitted_redevelopment_inputs
    retained = f4._retained_full0_source_members(retained_source_bundle, aar_primary_context=True)
    inputs = list(aar_source.__wrapped__(monkeypatch))
    inputs[3] = old_primary_q_source["source"]["primary_source"]
    # Construct one explicitly UNFITTED old-context fixture. The current
    # consumers below must prove the actual retained ZIP, never this override.
    with monkeypatch.context() as producer:
        producer.setattr(f4, "_f45_source_member_sha256", lambda: retained)
        original_lock = fixtures._lock
        def fixed_decision_lock(context, scores):
            lock, templates = original_lock(context, scores)
            return nested._sealed({**{key: value for key, value in lock.items() if key != "identity_sha256"},
                "science_decision_binding": nested._outer_science_decision_binding(inputs[3]["science_decision"])}), templates
        producer.setattr(fixtures, "_lock", fixed_decision_lock)
        prepared = unfitted_redevelopment_inputs.__wrapped__(tuple(inputs), tmp_path, monkeypatch,
            SimpleNamespace(param="GBM_COX"))
    calls = request.getfixturevalue("unfitted_selector_engines")
    prepared = {**prepared, "retained_primary_source_bundle": retained_source_bundle}
    original_inputs = canonical_json_bytes(sensitivity._a12_outer_input_record(prepared))
    original_archive = sha256_file(tmp_path / "projected.zip")
    development = tmp_path / "development"
    compiled = {}
    for branch in (nested.A12_DIRECT_AAR, nested.A12_TOTAL_AAR):
        # There is no selector locator on either of these actual consumers.
        assert "retained_selector_source_bundle" not in prepared
        prepared = sensitivity._a12_projected_development_inputs(prepared, development, replay=False, branch=branch)
        source = sensitivity._a12_search_source(prepared, branch)
        search = {"a12_source": source, "selected_spec": {"family": "GBM_COX", "UNFITTED_Q_LEAF": branch}}
        jobs = sensitivity._a12_outer_model_jobs(prepared, {branch: search}, branch=branch)
        assert len(jobs) == 20
        compiled[branch] = jobs
        for imp, job in enumerate(jobs, 1):
            task, recipe, training, response, application = sensitivity._ablation_component_inputs(job["entries"])
            assert task["registered_model_seed"] == task["model_seed"] == 301000 + imp
            assert task["selected_parents"] == ["Age"] and task["parameters"] == search["selected_spec"]
            assert task["nested_aar_final_source"]["training_context_sha256"] == (
                prepared["source"]["primary_source"]["primary_training_context"]["identity_sha256"])
            assert task["nested_aar_final_source"]["development_input_sha256"] == source["development_input_sha256"]
            assert recipe == prepared["branches"][branch]["recipes"]["OUTER_F1"]
            assert {row["Patient_ID"] for row in training} == set(response)
            assert not set(response).intersection(row["Patient_ID"] for row in application)
        replayed = sensitivity._a12_projected_development_inputs(prepared, development, replay=True, branch=branch)
        assert sensitivity._a12_outer_model_jobs(replayed, {branch: search}, branch=branch) == jobs
        name = jobs[6]["name"]
        scoped = {**replayed, "branches": {branch: replayed["branches"][branch]}}
        assert sensitivity._a12_outer_model_jobs(scoped, {branch: search}, task_names=[name]) == [jobs[6]]
        without = {key: value for key, value in prepared.items() if key != "retained_primary_source_bundle"}
        with pytest.raises(ContractError):
            sensitivity._a12_outer_model_jobs(without, {branch: search}, branch=branch)
        damaged = copy.deepcopy(search)
        damaged["a12_source"]["branch"] = (nested.A12_TOTAL_AAR if branch == nested.A12_DIRECT_AAR else nested.A12_DIRECT_AAR)
        with pytest.raises(ContractError, match="OUTER_SEARCH_SOURCE_MISMATCH"):
            sensitivity._a12_outer_model_jobs(prepared, {branch: damaged}, branch=branch)
    assert calls["path"] == calls["replay"] == 0
    assert canonical_json_bytes(prepared["source_input_record"]) == original_inputs
    assert sha256_file(tmp_path / "projected.zip") == original_archive
    assert compiled[nested.A12_DIRECT_AAR][0]["entries"]["task.json"] != compiled[nested.A12_TOTAL_AAR][0]["entries"]["task.json"]


def test_original_final_owners_restore_carried_primary_and_selector_before_consumers(
        old_primary_q_source, retained_source_bundle, retained_selector_bundle, retained_gbm_q_bundle,
        tmp_path, monkeypatch):
    """Original entry/archive handoffs, with actual source ZIPs, not whole-Q acceptance.

    Stop at the next original development/materialization boundary: this
    deliberately small carrier has no complete phase or fitted final result.
    The original full shard/gather/number reducers have independent fixtures.
    """
    from padml import f5
    policy = {"configured_worker_ceiling": "EXECUTION_HOST_C_MINUS_8", "memory_bytes_per_worker": 1,
        "scratch_bytes_per_worker": 1, "memory_reserve_bytes": 0, "scratch_reserve_bytes": 0,
        "transfer_archive_worker_ceiling": 1000}
    source = nested._sealed({**{key: value for key, value in old_primary_q_source["source"].items()
        if key != "identity_sha256"}, "resource_policy": policy})
    q_source = {**old_primary_q_source, "source": source}
    q = tmp_path / "original-q"
    q.mkdir()
    retained_dir = q / "execution-evidence/retained-sources"
    retained_dir.mkdir(parents=True)
    for name, path in (("primary1513.zip", retained_source_bundle), ("selector1ae.zip", retained_selector_bundle),
                       ("q73.zip", retained_gbm_q_bundle)):
        shutil.copyfile(path, retained_dir / name)
    refs = {path.relative_to(q).as_posix(): {"sha256": sha256_file(path), "size_bytes": path.stat().st_size}
            for path in retained_dir.iterdir()}
    (q / "input.json").write_bytes(canonical_json_bytes({"kind": "PADML_F5_A12_Q_INPUT_V1",
        "spec": {"execution_scope": "F5_A12_SEARCH", "family": "GBM_COX", "fold": 1, "a12_source": q_source}}))
    (q / "execution.json").write_bytes(canonical_json_bytes({"gbm_retained_sources": refs}))
    assert f5._q_gbm_source_evidence(q, policy)[1] == refs
    projected, inputs = tmp_path / "projected.zip", tmp_path / "inputs.zip"
    write_deterministic_zip(projected, {"a12-inputs.json": canonical_json_bytes(source)})
    write_deterministic_zip(inputs, {"UNFITTED_MATERIALIZER_BOUNDARY": b"{}"})
    class ReachedConsumer(Exception):
        pass
    seen = []
    def materialize(*args, **kwargs):
        primary = kwargs["retained_primary_source_bundle"]
        assert sha256_file(primary) == sha256_file(retained_source_bundle)
        branches = (tuple({coordinate[0] for coordinate in sensitivity._a12_final_task_coordinates(
            1, kwargs["final_task_ids"]).values()}) if kwargs.get("final_task_ids") else nested.AAR_ESTIMANDS)
        return {"source": source, "family": "GBM_COX", "outer_fold": 1,
            "branches": {branch: {} for branch in branches}, "input_expansion_resources": {},
            "retained_primary_source_bundle": primary}
    def development(prepared, root, *, replay, **kwargs):
        assert "retained_gbm_q_source_bundle" not in prepared
        branch = kwargs.get("branch")
        if branch in {nested.A12_DIRECT_AAR, nested.A12_TOTAL_AAR} and replay:
            assert "retained_selector_source_bundle" not in prepared
        else:
            assert sha256_file(prepared["retained_selector_source_bundle"]) == sha256_file(retained_selector_bundle)
        seen.append((branch, replay))
        raise ReachedConsumer
    monkeypatch.setattr(sensitivity, "materialize_a12_outer_inputs", materialize)
    monkeypatch.setattr(sensitivity, "_a12_projected_development_inputs", development)
    monkeypatch.setattr(sensitivity, "_a12_outer_retained_members", lambda *args, **kwargs: {})
    monkeypatch.setattr(sensitivity, "_bounded_ordered_spawn", lambda *args, **kwargs: pytest.fail("NO_FINAL_FIT"))
    no_aar = nested.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT
    q_roots = {branch: q if branch == no_aar else tmp_path / branch for branch in nested.AAR_ESTIMANDS}
    for mode in ("prepare", *nested.AAR_ESTIMANDS, "gather"):
        target = tmp_path / (mode + ".zip")
        root = target.with_name(target.name + ".work")
        options = {"retained_bytes_per_component": 2 * 1024**2,
                   "retained_primary_source_bundle": retained_source_bundle}
        if mode == "prepare":
            options.update(prepare_final=True, selector_root=tmp_path / "selector", q_roots=q_roots)
        else:
            (root / "development").mkdir(parents=True)
            (root / "development/development.json").write_bytes(canonical_json_bytes({branch: {} for branch in nested.AAR_ESTIMANDS}))
            if mode in {no_aar, "gather"}:
                shutil.copytree(q, root / "search" / no_aar)
            if mode == "gather":
                options["final_batches"] = [tmp_path / "UNFITTED-not-consumed-batch"]
            else:
                options.update(final_task_ids=[f"O1_{mode}_M07"], final_batch_root=root / "batch")
        with pytest.raises(ReachedConsumer):
            sensitivity.execute_a12_outer_bundle(inputs, target, input_bundle=projected, **options)
        assert not target.exists()
    assert len(seen) == 5
    # Reopen an exact, sealed byte archive through the real original reader.
    # Its carried primary must be ready BEFORE the materializer is entered.
    members = {"inputs.zip": inputs, **{f"search/{no_aar}/{path.relative_to(q).as_posix()}": path
        for path in q.rglob("*") if path.is_file()}}
    body = {"kind": "PADML_F5_A12_OUTER_NATIVE_V2", "source": source, "family": "GBM_COX", "outer_fold": 1,
        "predictions": {}, "native_members": {}, "members": {name: {"sha256": sha256_file(path),
            "size_bytes": path.stat().st_size} for name, path in members.items()}}
    archive = tmp_path / "outer-boundary.zip"
    write_deterministic_zip(archive, {"a12-outer.json": canonical_json_bytes(nested._sealed(body)), **members},
                            stored_members={name for name in members if name.endswith(".zip")})
    def archive_materializer(*args, **kwargs):
        path = kwargs["retained_primary_source_bundle"]
        assert path.is_relative_to(tmp_path / "archive-reader/archive/search" / no_aar)
        assert sha256_file(path) == sha256_file(retained_source_bundle)
        raise ReachedConsumer
    monkeypatch.setattr(sensitivity, "materialize_a12_outer_inputs", archive_materializer)
    with pytest.raises(ReachedConsumer):
        sensitivity._load_a12_outer_archive(archive, input_bundle=projected, replay_evidence=tmp_path / "archive-reader")
    with pytest.raises(ContractError, match="F5_GBM_Q_SOURCE_EVIDENCE_INVALID"):
        sensitivity._load_a12_outer_archive(archive, input_bundle=projected,
            retained_primary_source_bundle=retained_selector_bundle, replay_evidence=tmp_path / "wrong-primary")
    assert len(seen) == 5


@pytest.mark.parametrize("damage", [None, "old-native-executor", "current-native-executor"])
def test_source73_and_current_gbm_batches_reach_original_numbers_readers(
        old_primary_q_source, retained_source_bundle, retained_gbm_q_bundle, tmp_path, monkeypatch, damage):
    """Original F5 transport -> F2 child -> both F4 readers, not fitted values.

    Only the pool/metric leaf is replaced. The source proofs, original batch
    and object-reference readers, saved-spec comparison and copying are real.
    """
    from padml import f5, f4_compact as compact
    from padml.bundle import sha256_file
    old = sha256_bytes(canonical_json_bytes(
        f4._retained_gbm_q_source_members(retained_gbm_q_bundle, retained_source_bundle)))
    current = sha256_bytes(canonical_json_bytes(f4._f45_source_member_sha256()))
    owner = tmp_path / "owner"
    (owner / "native").mkdir(parents=True)
    policy = {"configured_worker_ceiling": runtime.CPU_MINUS_8, "memory_bytes_per_worker": 1,
        "scratch_bytes_per_worker": 1, "memory_reserve_bytes": 0, "scratch_reserve_bytes": 0,
        "transfer_archive_worker_ceiling": 1}
    observation = {"effective_cpus": 32, "available_memory_bytes": 64 * 1024**3,
        "scratch_available_bytes": 64 * 1024**3, "scratch_root": str(owner)}
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda root: {**observation, "scratch_root": str(root)})
    parent = {"schema_version": "1.0.0", "execution_scope": "F5_A12_SEARCH", "fold": 1,
        "family": "GBM_COX", "seed": 301000, "outcome": "All_Cause_Death", "time": "Death_Followup_months",
        "horizons": list(range(37)), "heldout_center": 36, "predictors": {}, "fpm": None,
        "selector_from_dependency": {"selected_parents": ["Age"], "outer_recipe_sha256": "RAW_CANONICAL"},
        "a12_source": old_primary_q_source, "registered_inputs_identity_sha256": "c" * 64,
        "retained_a12_primary_context_source_bundle": str(retained_source_bundle),
        "a12_executor_source_identity": current, "native_search_root": str(owner / "native"),
        "native_search_replay": False}
    registered = {"view_count": 1, "partitions": [{"covariates": {"input_dir": "/UNFITTED/input"},
        "fit_response": {"path": "/UNFITTED/response"}}]}
    input_raw = canonical_json_bytes({"UNFITTED_MIXED_Q_SOURCE_TEST": True})
    input_ref = {"sha256": sha256_bytes(input_raw), "size_bytes": len(input_raw)}
    units, batches, originals = {}, [], {}
    for index, identity in enumerate((old, current)):
        batch = tmp_path / ("old-batch" if index == 0 else "current-batch")
        (batch / "native").mkdir(parents=True)
        producer = {"task_id": f"UNFITTED_PREDICTION_{index}", "family": "GBM_COX",
            "producer_kind": "PREDICTION", "seed": 301101 + index, "parameters": {"n_trees": 7}}
        task = (parent, registered, [producer], "UNFITTED", "UNFITTED", "IBS", {})
        name, (_, native) = next(iter(f5._q_search_units(f2_kernel._run_r_prediction_pool_task, [task]).items()))
        units[name] = (task, native)
        for item in native:
            (batch / "native" / item).mkdir()
        saved = {**f2_kernel._r_prediction_child_spec(parent), "action": "MODEL_PREDICTION_BATCH",
            "producer_tasks": [producer], "registered_partitions": registered,
            "a12_executor_source_identity": identity, "output_path": "/UNFITTED/producer/output.json",
            "native_search_root": "/UNFITTED/producer/native",
            "retained_a12_primary_context_source_bundle": "/UNFITTED/producer/primary-proof.zip"}
        if damage == "old-native-executor" and index == 0:
            saved["a12_executor_source_identity"] = current
        elif damage == "current-native-executor" and index == 1:
            saved["a12_executor_source_identity"] = old
        files = {"input.json": input_raw, f"native/{name}/spec.json": canonical_json_bytes(saved),
            f"native/{name}/output.json": canonical_json_bytes({"UNFITTED": index})}
        for member, raw in files.items():
            (batch / member).write_bytes(raw)
        model_pin = {"sha256": sha256_bytes(b"UNFITTED_MODEL_REFERENCE"), "size_bytes": len(b"UNFITTED_MODEL_REFERENCE")}
        (batch / "native" / producer["task_id"] / "object-audit.json").write_bytes(
            canonical_json_bytes({"model.rds": model_pin}))
        refs = {member: {"sha256": sha256_bytes(raw), "size_bytes": len(raw)} for member, raw in files.items()}
        refs[f"native/{producer['task_id']}/model.rds"] = model_pin
        projection, _ = compact._full_pipeline_q_numerical_members(batch, native_units=native, transported_refs=refs)
        row = {"task_id": name, "native_units": list(native), "members": refs, "retained_bytes": 100,
            "first_native_audit_count": 1,
            "numerical_members": {key: {"sha256": sha256_file(path), "size_bytes": path.stat().st_size}
                for key, path in projection.items()}}
        effective = f5._q_batch_resource_policy(policy, len(input_raw), 1, 4 * 1024**2)
        admission = runtime.resource_admission(effective, observation, legal_tasks=1)
        record = {"phase": "UNFITTED_MIXED", "input": input_ref, "task_ids": [name],
            "source_identity": identity, "operational_identity": runtime.OPERATIONAL_IDENTITY,
            "resource_policy": policy, "effective_policy": effective, "resource_observation": observation,
            "resource_admission": admission, "retained_bytes_per_task": 4 * 1024**2, "units": [row],
            "confirmed_first_native_audit_count": 1, "new_model_fit_count": 1,
            "pool": {"configured_worker_ceiling": 24, "admitted_worker_ceiling": 1,
                "runnable_task_count": 1, "actual_worker_process_peak": 1, "completed_task_count": 1,
                "engine_threads": 1, "status": "COMPLETED"},
            "resource_release": {"units": {name: runtime.release_step_resources([], owner="Q_UNIT:" + name,
                before=runtime.observe_step_memory(), released_references=[])},
                "worker_results": {"0": runtime.release_step_resources([], owner="POOL_TASK_RESULT:0",
                    before=runtime.observe_step_memory(), released_references=[])}}}
        (batch / "execution.json").write_bytes(canonical_json_bytes(record))
        batches.append((batch, record))
        originals.update({path: path.read_bytes() for path in batch.rglob("*") if path.is_file()})
    options = {"prepare_only": True, "task_ids": None, "batch_root": None,
        "q_batches": [batch for batch, _ in batches], "retained_bytes_per_task": None}
    control = f5._q_search_batch_control(owner, policy, options,
        retained_primary_source_bundle=retained_source_bundle, retained_gbm_q_source_bundle=retained_gbm_q_bundle)
    parent["native_search_batch"] = control
    assert "retained_primary_source_identity" not in control
    calls = []
    def numbers_pool(function, tasks, *, selected_slots):
        assert function is f2_kernel._run_r_prediction_pool_task and selected_slots == 1
        values = []
        for index, task in enumerate(tasks):
            spec, work = task[0], Path(task[3])
            assert "native_search_batch" not in spec and spec["native_search_numbers"] is True
            assert spec.get("retained_gbm_q_source_bundle") == (str(retained_gbm_q_bundle) if index == 0 else None)
            child = {**f2_kernel._r_prediction_child_spec(spec), "action": "MODEL_PREDICTION_BATCH",
                "producer_tasks": task[2], "registered_partitions": task[1], "output_path": str(work / "output.json")}
            (work / "spec.json").write_bytes(canonical_json_bytes(child))
            values.append(f4._run_full_pipeline_r_search_batch(work / "spec.json", work / "output.json", tmp_path, {}))
            calls.append(index)
        return values
    monkeypatch.setattr(f5, "_bounded_ordered_spawn", numbers_pool)
    monkeypatch.setattr(f4.subprocess, "run", lambda *a, **k: pytest.fail("NO_FIT_OR_NATIVE_AUDIT"))
    if damage is None:
        assert f5._consume_q_search_batches(parent, f2_kernel._run_r_prediction_pool_task, units,
            batches, "UNFITTED_MIXED", input_ref) == [{"UNFITTED": 0}, {"UNFITTED": 1}]
        assert calls == [0, 1] and control["confirmed_model_fits"] == 2 and control["confirmed_stop_fits"] == 0
    else:
        with pytest.raises(ContractError, match="F5_RETAINED_AAR_Q_EXECUTOR_DRIFT"):
            f5._consume_q_search_batches(parent, f2_kernel._run_r_prediction_pool_task, units,
                batches, "UNFITTED_MIXED", input_ref)
        assert calls == ([] if damage == "old-native-executor" else [0])
    assert all(path.read_bytes() == raw for path, raw in originals.items())
    for mode in ("produce", "audit"):
        with pytest.raises(ContractError, match="F5_RETAINED_GBM_Q_NUMBERS_ONLY"):
            f5._q_search_unit_call(f2_kernel._run_r_prediction_pool_task, next(iter(units.values()))[0],
                owner, tmp_path, mode=mode, retained_gbm_q_source_bundle=str(retained_gbm_q_bundle))


@pytest.fixture
def source73_gbm_loss_recovery(old_primary_q_source, retained_source_bundle, retained_gbm_q_bundle,
                              retained_selector_bundle, aar_source, tmp_path, monkeypatch):
    """Keep a separate, explicitly UNFITTED old snapshot; run real loss readers."""
    from padml import f5, f4_compact as compact
    from padml.bundle import sha256_file
    from test_a12_q_native import _unfitted_gbm_loss_unit
    q, job, r_calls, _, _ = _unfitted_gbm_loss_unit(aar_source, tmp_path, monkeypatch, "AAR")
    parent = job["task"][0]
    current = sha256_bytes(canonical_json_bytes(f4._f45_source_member_sha256()))
    old = sha256_bytes(canonical_json_bytes(
        f4._retained_gbm_q_source_members(retained_gbm_q_bundle, retained_source_bundle)))
    parent.update(a12_source=old_primary_q_source, a12_executor_source_identity=current,
        retained_a12_primary_context_source_bundle=str(retained_source_bundle))
    public_spec = {key: value for key, value in parent.items() if key not in {
        "native_search_root", "native_search_replay", "a12_executor_source_identity",
        "retained_a12_primary_context_source_bundle"}}
    public_spec.update(execution_mode="PROCESS_POOL", engine_threads=1, threads=1, pool_workers=1)
    parent.update(execution_mode="PROCESS_POOL", engine_threads=1, threads=1, pool_workers=1)
    # Seal the public input shape before producing the UNFITTED old snapshot.
    # The later original CLI must reproduce these same bytes, not repin it.
    public_record = {"kind": "PADML_F5_A12_Q_INPUT_V1", "spec": public_spec,
        "registered_identity": parent["registered_inputs_identity_sha256"], "inputs": {"UNFITTED": True}}
    (q / "input.json").write_bytes(canonical_json_bytes(public_record))
    job["task"] = (f2_kernel._r_prediction_child_spec(parent), *job["task"][1:])
    unit = f5._execute_and_verify_q_search_unit(job)
    assert r_calls == [False, True]
    name = job["task_id"]
    expected = (q / "native" / name / "evaluation.json").read_bytes()
    loss_member = f"native/{name}/evaluation.json"
    projection, _ = compact._full_pipeline_q_numerical_members(q,
        native_units=tuple(job["native_units"]), transported_refs=unit["members"])
    batch = tmp_path / "UNFITTED-source73-snapshot"
    batch.mkdir()
    for member, path in projection.items():
        if member != loss_member:
            target = batch / member
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(path, target)
    old_origin = tmp_path / "UNFITTED-old-origin"
    slot = old_origin / "batch-work" / name / "numbers"
    slot.parent.mkdir(parents=True)
    saved_path = batch / "native" / name / "spec.json"
    saved = strict_json_bytes(saved_path.read_bytes())
    saved.update(a12_executor_source_identity=old, native_search_root=str(old_origin / "native"))
    saved_path.write_bytes(canonical_json_bytes(saved))
    refs = {member: pin for member, pin in unit["members"].items() if member != loss_member}
    refs[f"native/{name}/spec.json"] = {"sha256": sha256_file(saved_path), "size_bytes": saved_path.stat().st_size}
    projection, _ = compact._full_pipeline_q_numerical_members(batch,
        native_units=tuple(job["native_units"]), transported_refs=refs)
    row = {key: value for key, value in unit.items() if key != "resource_release"}
    row.update(members=refs, numerical_members={member: {
        "sha256": sha256_file(path), "size_bytes": path.stat().st_size} for member, path in projection.items()})
    policy = {"configured_worker_ceiling": runtime.CPU_MINUS_8, "memory_bytes_per_worker": 1,
        "scratch_bytes_per_worker": 1, "memory_reserve_bytes": 0, "scratch_reserve_bytes": 0,
        "transfer_archive_worker_ceiling": 1}
    observation = {"effective_cpus": 32, "available_memory_bytes": 64 * 1024**3,
        "scratch_available_bytes": 64 * 1024**3, "scratch_root": str(q)}
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda root: {**observation, "scratch_root": str(root)})
    input_ref = {"sha256": sha256_file(batch / "input.json"), "size_bytes": (batch / "input.json").stat().st_size}
    other = (*job["task"][:2], [{**job["task"][2][0], "task_id": "S1_T001_P01_M02_STOP", "imputation": 2}],
             *job["task"][3:])
    tasks = [job["task"], other]
    units = f5._q_search_units(f2_kernel._run_r_prediction_pool_task, tasks)
    phase = "_run_r_prediction_pool_task-" + sha256_bytes(canonical_json_bytes(list(units)))[:24]
    effective = f5._q_batch_resource_policy(policy, input_ref["size_bytes"], 1, job["retained_bytes_per_task"])
    admission = runtime.resource_admission(effective, observation, legal_tasks=1)
    def release(owner):
        return runtime.release_step_resources([], owner=owner, before=runtime.observe_step_memory(), released_references=[])
    execution = {"phase": phase, "input": input_ref, "task_ids": [name], "source_identity": old,
        "operational_identity": runtime.OPERATIONAL_IDENTITY, "resource_policy": policy,
        "effective_policy": effective, "resource_observation": observation, "resource_admission": admission,
        "retained_bytes_per_task": job["retained_bytes_per_task"], "units": [row],
        "confirmed_first_native_audit_count": 1, "new_model_fit_count": 1,
        "pool": {"configured_worker_ceiling": 24, "admitted_worker_ceiling": 1, "runnable_task_count": 1,
            "actual_worker_process_peak": 1, "completed_task_count": 1, "engine_threads": 1, "status": "COMPLETED"},
        "resource_release": {"units": {name: unit["resource_release"]}, "worker_results": {"0": release("POOL_TASK_RESULT:0")}}}
    (batch / "execution.json").write_bytes(canonical_json_bytes(execution))
    originals = {path: path.read_bytes() for base in (q, batch) for path in base.rglob("*") if path.is_file()}
    def prepare(label, *, recover=True, source=batch):
        owner = tmp_path / (label + "-owner")
        (owner / "native").mkdir(parents=True)
        shutil.copyfile(batch / "input.json", owner / "input.json")
        destination = tmp_path / (label + "-derived")
        spec = {**parent, "native_search_root": str(owner / "native")}
        options = {"prepare_only": not recover, "task_ids": [name] if recover else None,
            "batch_root": destination if recover else None, "q_batches": [source],
            "retained_bytes_per_task": 4 * 1024**2 if recover else None}
        spec["native_search_batch"] = f5._q_search_batch_control(owner, policy, options,
            retained_primary_source_bundle=retained_source_bundle,
            retained_selector_source_bundle=retained_selector_bundle,
            retained_gbm_q_source_bundle=retained_gbm_q_bundle, recover_gbm_losses=recover)
        return spec, [(f2_kernel._r_prediction_child_spec(spec), *task[1:]) for task in tasks], destination
    def serial(function, jobs, *, selected_slots, execution_report=None, on_result=None, resource_release_report=None):
        assert selected_slots == 1
        if execution_report is not None:
            execution_report.update(configured_worker_ceiling=24, admitted_worker_ceiling=1,
                runnable_task_count=len(jobs), actual_worker_process_peak=1, completed_task_count=0,
                engine_threads=1, status="RUNNING")
        values = []
        try:
            for index, task in enumerate(jobs):
                value = function(task)
                if on_result is not None:
                    on_result(index, value)
                values.append(value)
                if resource_release_report is not None:
                    resource_release_report[str(index)] = release("POOL_TASK_RESULT:" + str(index))
                if execution_report is not None:
                    execution_report["completed_task_count"] += 1
        except BaseException:
            if execution_report is not None:
                execution_report["status"] = "FAILED"
            raise
        if execution_report is not None:
            execution_report["status"] = "COMPLETED"
        return values
    monkeypatch.setattr(f5, "_bounded_ordered_spawn", serial)
    monkeypatch.setattr(f4.subprocess, "run", lambda *a, **k: pytest.fail("NO_NEW_FIT_OR_NATIVE_AUDIT"))
    return SimpleNamespace(prepare=prepare, batch=batch, execution=execution, slot=slot, expected=expected,
        originals=originals, name=name, phase=phase, input_ref=input_ref, r_calls=r_calls, policy=policy,
        public_spec=public_spec, tasks=tasks, tmp_path=tmp_path, primary=retained_source_bundle,
        gbm_source=retained_gbm_q_bundle)


def test_source73_missing_loss_once_then_original_pinned_consumer(source73_gbm_loss_recovery,
        retained_selector_bundle, monkeypatch, capsys):
    import sys
    import tempfile
    from padml import f5, f4_compact as compact
    from padml.bundle import sha256_file
    state = source73_gbm_loss_recovery
    evaluated, original = [], f2_kernel._grouped_cox_loss_path
    def count(*args, **kwargs):
        evaluated.append(1)
        return original(*args, **kwargs)
    monkeypatch.setattr(f2_kernel, "_grouped_cox_loss_path", count)
    q_root, selector, packet = (state.tmp_path / name for name in ("public-q", "selector", "original-packet"))
    selector.mkdir()
    packet.mkdir()
    source, projected = (state.tmp_path / name for name in ("UNFITTED-gather.zip", "UNFITTED-projected.zip"))
    source.write_bytes(b"UNFITTED original materializer boundary")
    projected.write_bytes(b"UNFITTED projected materializer boundary")
    destination = packet / "batch"
    partitions = [{"evaluation_response": {"size_bytes": 4}} for _ in range(15)] + [
        {"covariates": {"members": [{"name": f"imp{i:02d}.csv", "size_bytes": 4} for i in range(1, 21)]}}]
    for name, value in (("partitions.json", partitions), ("selector.json", {"UNFITTED": "selector"}),
                        ("development-input.json", {"UNFITTED": "development"})):
        (selector / name).write_bytes(canonical_json_bytes(value))
    q_source = state.public_spec["a12_source"]
    input_source = {**q_source["source"], "resource_policy": state.policy}
    def materialize(received, lineage, directory, *, input_bundle, retained_primary_source_bundle):
        assert received == source and lineage is None and input_bundle == projected
        assert retained_primary_source_bundle == state.primary
        directory.mkdir()
        (directory / "UNFITTED-input.bin").write_bytes(b"owned private input")
        return {"source": input_source, "family": "GBM_COX", "outer_fold": 1,
            "branch_development": {}, "retained_primary_source_bundle": state.primary}
    def development(prepared, directory, *, replay, branch, selector_root, q_input_lifecycle):
        assert not replay and selector_root == selector and branch == q_source["branch"]
        directory.mkdir()
        for name, prefix, subdirectory, count, filename in (
            ("selector_program", "nested-full-selector-replay-", "validation-responses", 15, "inner-{:02d}.csv"),
            ("selector_inputs", "a12-selector-inputs-", "outer-training", 20, "imp{:02d}.csv")):
            owned = Path(tempfile.mkdtemp(prefix=prefix, dir=selector.parent))
            (owned / subdirectory).mkdir()
            for index in range(1, count + 1):
                (owned / subdirectory / filename.format(index)).write_bytes(b"data")
            q_input_lifecycle[name] = {"temporary_root": str(owned)}
        return prepared
    def original_phase(spec, registered, scratch):
        # Only the candidate list is synthetic. The real original batch owner,
        # once-only loss worker, public CLI and persisted report all execute.
        assert registered["identity"] == state.public_spec["registered_inputs_identity_sha256"]
        return f5._q_search_task_batch(spec, f2_kernel._run_r_prediction_pool_task,
            [(f2_kernel._r_prediction_child_spec(spec), *task[1:]) for task in state.tasks])
    monkeypatch.setattr(sensitivity, "materialize_a12_outer_inputs", materialize)
    monkeypatch.setattr(sensitivity, "_a12_projected_development_inputs", development)
    monkeypatch.setattr(sensitivity, "_a12_complex_configuration", lambda *a, **k: {
        "spec": dict(state.public_spec), "registered": {"identity": state.public_spec["registered_inputs_identity_sha256"]}})
    monkeypatch.setattr(sensitivity, "_a12_outer_input_record", lambda *a, **k: {"UNFITTED": True})
    monkeypatch.setattr(sensitivity, "_run_a12_complex_search", original_phase)
    argv = ["padml-f5", "a12-outer", str(source), str(q_root), "--input-bundle", str(projected),
        "--search-only", "--search-branch", q_source["branch"], "--selector-root", str(selector),
        "--retained-primary-source-bundle", str(state.primary), "--retained-selector-source-bundle", str(retained_selector_bundle),
        "--retained-gbm-q-source-bundle", str(state.gbm_source), "--recover-gbm-losses",
        "--q-batches", str(state.batch), "--task-ids", state.name, "--batch-root", str(destination),
        "--retained-bytes-per-task", str(4 * 1024**2)]
    monkeypatch.setattr(sys, "argv", argv)
    f5.main()
    captured = capsys.readouterr()
    stdout, stderr = captured.out.encode(), captured.err.encode()
    result = strict_json_bytes(stdout)
    report_path = Path(result["execution_report"]["report_path"])
    assert report_path.read_bytes() == canonical_json_bytes(result)
    assert (q_root / "input.json").read_bytes() == (state.batch / "input.json").read_bytes()
    # The original collector roles contain the actual completed CLI bytes.
    # No _QBatchBoundary result is promoted into a fictitious CLI success.
    wrapper = {"command": [sys.executable, "-B", "-c", "from padml.f5 import main; main()", *argv[1:]],
        "source_identity": result["execution_report"]["source_identity"], "exit_code": 0,
        "original_cli_output_matches_persisted_report": True, "source_sha256": sha256_file(source),
        "search_result_sha256": result["execution_report"]["result_sha256"],
        "prior": [{"path": str(state.batch), "execution_sha256": sha256_file(state.batch / "execution.json"),
                   "execution_size_bytes": (state.batch / "execution.json").stat().st_size}],
        **{kind + suffix: value for kind, raw in (("stdout", stdout), ("stderr", stderr))
           for suffix, value in (("_sha256", sha256_bytes(raw)), ("_size_bytes", len(raw)))}}
    for name, raw in {"cli/original.stdout": stdout, "cli/original.stderr": stderr,
        "cli/original-execution.json": canonical_json_bytes(wrapper),
        "execution-evidence/input-execution.json": report_path.read_bytes()}.items():
        path = packet / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(raw)
    members = {path.relative_to(packet).as_posix(): {"sha256": sha256_file(path), "size_bytes": path.stat().st_size}
               for path in packet.rglob("*") if path.is_file()}
    (packet / "collection.json").write_bytes(canonical_json_bytes({"source_identity": wrapper["source_identity"],
        "input_sha256": state.input_ref["sha256"], "members": members,
        "q_input_execution_report": members["execution-evidence/input-execution.json"]}))
    assert result["status"] == "COMPUTED_Q_NUMERICAL_BATCH" and result["stage_acceptance"] is False
    assert (result["new_model_fits"], result["new_first_native_audits"], result["new_loss_evaluations"]) == (0, 0, 1)
    execution = strict_json_bytes((destination / "execution.json").read_bytes())
    assert canonical_json_bytes({k: v for k, v in execution.items() if k != "numerical_consumption"}) == canonical_json_bytes(state.execution)
    assert (state.slot / "evaluation.json").read_bytes() == state.expected
    assert evaluated == [1] and state.r_calls == [False, True]
    monkeypatch.setattr(f2_kernel, "_grouped_cox_loss_path", lambda *a, **k: pytest.fail("NO_REPEATED_LOSS_EVALUATION"))
    spec, tasks, _ = state.prepare("consume", recover=False, source=destination)
    unit = {state.name: f5._q_search_units(f2_kernel._run_r_prediction_pool_task, tasks)[state.name]}
    observed, = f5._consume_q_search_batches(spec, f2_kernel._run_r_prediction_pool_task, unit,
        spec["native_search_batch"]["batches"], state.phase, state.input_ref)
    assert len(observed) == 1
    expected = strict_json_bytes(state.expected)["result"]
    assert all(observed[0][key] == value for key, value in expected.items())
    original_pool = f5._bounded_ordered_spawn
    monkeypatch.setattr(f5, "_bounded_ordered_spawn", lambda *a, **k: pytest.fail("REJECT_BEFORE_NUMBERS_POOL"))
    for damage in ("new-executor", "spec-pin", "attempt-path", "loss-pin", "fit-count", "loss-count", "release", "old-loss",
                   "release-empty-files", "release-other-coordinate", "release-transfer-empty", "release-transfer-missing-source",
                   "release-transfer-wrong-size", "release-transfer-active-reader", "joint-root-files"):
        bad = copy.deepcopy(execution)
        child = bad["numerical_consumption"]
        if damage == "new-executor": child["executor_source_identity"] = bad["source_identity"]
        elif damage == "spec-pin": child["units"][0]["native_spec"]["sha256"] = "f" * 64
        elif damage == "attempt-path": child["units"][0]["attempt_root"] += "-alternate"
        elif damage == "loss-pin": child["units"][0]["evaluation"]["sha256"] = "f" * 64
        elif damage == "fit-count": child["new_model_fit_count"] = 1
        elif damage == "loss-count": child["new_loss_evaluation_count"] = 0
        elif damage == "release": child["resource_release"]["units"] = {}
        elif damage == "release-empty-files": child["resource_release"]["units"][state.name]["files"] = []
        elif damage == "release-other-coordinate":
            child["resource_release"]["units"][state.name]["files"][0]["path"] = str(state.slot.parent / "OTHER" / "evaluation.json")
        elif damage == "joint-root-files":
            coordinator = child["resource_release"]["coordinator"]
            original_roots = [coordinator[key] for key in ("source_root", "destination_root")]
            for key in ("source_root", "destination_root"):
                coordinator[key] += "-foreign"
            for member in coordinator["resource_release"]["files"]:
                for old_root in original_roots:
                    if Path(member["path"]).is_relative_to(old_root):
                        member["path"] = str(Path(old_root + "-foreign") / Path(member["path"]).relative_to(old_root))
        elif damage.startswith("release-transfer"):
            files = child["resource_release"]["coordinator"]["resource_release"]["files"]
            if damage == "release-transfer-empty": files.clear()
            elif damage == "release-transfer-missing-source":
                files[:] = [row for row in files if not Path(row["path"]).is_relative_to(state.batch)]
            elif damage == "release-transfer-wrong-size": files[0]["size_bytes"] += 1
            else: files[0]["status"] = "ACTIVE_READER_OR_WRITER"
        else:
            bad["units"][0]["members"][f"native/{state.name}/evaluation.json"] = child["units"][0]["evaluation"]
            raw = canonical_json_bytes({k: v for k, v in bad.items() if k != "numerical_consumption"})
            child["producer_execution"] = {"sha256": sha256_bytes(raw), "size_bytes": len(raw)}
        bad_spec, bad_tasks, _ = state.prepare("damaged-" + damage, recover=False, source=destination)
        bad_units = {state.name: f5._q_search_units(f2_kernel._run_r_prediction_pool_task, bad_tasks)[state.name]}
        with pytest.raises(ContractError, match="F5_GBM_LOSS_CONSUMPTION_INVALID"):
            f5._consume_q_search_batches(bad_spec, f2_kernel._run_r_prediction_pool_task, bad_units,
                [(destination, bad)], state.phase, state.input_ref)
    monkeypatch.setattr(f5, "_bounded_ordered_spawn", original_pool)
    relocated = state.tmp_path / "relocated-packet"
    shutil.copytree(packet, relocated)
    spec, tasks, _ = state.prepare("relocated", recover=False, source=relocated / "batch")
    unit = {state.name: f5._q_search_units(f2_kernel._run_r_prediction_pool_task, tasks)[state.name]}
    assert f5._consume_q_search_batches(spec, f2_kernel._run_r_prediction_pool_task, unit,
        spec["native_search_batch"]["batches"], state.phase, state.input_ref) == [observed]
    # Exercise complete-Q operational projection/relocation without claiming
    # that this one-unit UNFITTED fixture completes the two-unit science phase.
    owner = Path(spec["native_search_root"]).parent
    synthetic_result = {"UNFITTED": True, "total_search_fit_count": 1, "response_free_stopping_fit_count": 1,
        "execution_scope": "F5_A12_SEARCH", "a12_source": state.public_spec["a12_source"]}
    (owner / "result.json").write_bytes(canonical_json_bytes(synthetic_result))
    f5._q_search_batch_completion(owner, spec["native_search_batch"], synthetic_result)
    projected_members, _ = compact._full_pipeline_q_numerical_members(owner, publish=True,
        transported_refs=spec["native_search_batch"]["references"])
    assert len([name for name in projected_members if name.startswith("execution-evidence/")]) == 8
    complete_execution = strict_json_bytes((owner / "execution.json").read_bytes())
    assert complete_execution["batches"] == [execution]
    assert len(complete_execution["gbm_retained_sources"]) == 3
    assert all(len(row) == 5 for row in complete_execution["gbm_loss_call_evidence"].values())
    completed_copy = state.tmp_path / "relocated-completed-carrier"
    for name, path in projected_members.items():
        output = completed_copy / name
        output.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, output)
    control = f5._q_search_batch_control(completed_copy, state.policy, None,
        retained_primary_source_bundle=state.primary, retained_gbm_q_source_bundle=state.gbm_source,
        retained_selector_source_bundle=retained_selector_bundle)
    replay_spec = {**spec, "native_search_root": str(completed_copy / "native"), "native_search_batch": control}
    replay_unit = {state.name: ((f2_kernel._r_prediction_child_spec(replay_spec), *state.tasks[0][1:]), unit[state.name][1])}
    assert f5._consume_q_search_batches(replay_spec, f2_kernel._run_r_prediction_pool_task, replay_unit,
        control["batches"], state.phase, state.input_ref) == [observed]
    f5._q_search_batch_completion(completed_copy, control, synthetic_result)
    with pytest.raises(ContractError, match="F5_Q_BATCH_COMPLETE_COORDINATES_REQUIRED"):
        f5._q_search_task_batch(replay_spec, f2_kernel._run_r_prediction_pool_task,
            [(f2_kernel._r_prediction_child_spec(replay_spec), *task[1:]) for task in state.tasks])
    # The original completed-Q caller restores only the pinned local paths.
    # This explicitly one-unit carrier still does not certify a whole Q.
    program_calls = []
    def completed_phase(spec, registered, scratch):
        assert spec["native_search_numbers"] and spec["native_search_replay"]
        assert "recover_gbm_losses" not in spec["native_search_batch"]
        assert Path(spec["retained_a12_primary_context_source_bundle"]).is_relative_to(completed_copy)
        calls = [(f2_kernel._r_prediction_child_spec(spec), *task[1:]) for task in state.tasks]
        units = {state.name: f5._q_search_units(f2_kernel._run_r_prediction_pool_task, calls)[state.name]}
        assert f5._consume_q_search_batches(spec, f2_kernel._run_r_prediction_pool_task, units,
            spec["native_search_batch"]["batches"], state.phase, state.input_ref) == [observed]
        program_calls.append(1)
        return synthetic_result
    monkeypatch.setattr(sensitivity, "_run_a12_complex_search", completed_phase)
    fresh_prepared = {"source": input_source, "family": "GBM_COX", "outer_fold": 1, "branch_development": {}}
    before_complete = {path: path.read_bytes() for path in completed_copy.rglob("*") if path.is_file()}
    assert sensitivity._a12_complex_search_program(fresh_prepared, q_source["branch"], completed_copy,
        replay=True) == synthetic_result
    assert program_calls == [1] and not any(key.startswith("retained_") for key in fresh_prepared)
    assert all(path.read_bytes() == raw for path, raw in before_complete.items())
    # Existing search/<branch>/ ownership filters the exact three ZIP leaves
    # on both final worker and gather; no extra final-level source table.
    shared = {f"search/{q_source['branch']}/{name}": path for name, path in projected_members.items()}
    assert sensitivity._a12_final_shared_members(shared, {nested.A12_TOTAL_AAR}) == {}
    assert sensitivity._a12_final_shared_members(shared, {q_source["branch"]}) == shared
    for damage in ("missing-zip", "relabel-selector", "extra-role", "missing-role", "changed-pin", "other-branch"):
        damaged = state.tmp_path / ("completed-source-" + damage)
        shutil.copytree(completed_copy, damaged)
        path = damaged / "execution.json"
        original_execution = strict_json_bytes(path.read_bytes())
        table = original_execution["gbm_retained_sources"]
        name = "execution-evidence/retained-sources/selector1ae.zip"
        if damage == "missing-zip":
            (damaged / name).rename(damaged / "preserved-selector1ae.zip")
        elif damage == "relabel-selector":
            shutil.copyfile(state.primary, damaged / name)
            table[name] = {"sha256": sha256_file(damaged / name), "size_bytes": (damaged / name).stat().st_size}
        elif damage == "extra-role":
            table[name + ".extra"] = dict(table[name])
        elif damage == "missing-role":
            del table[name]
        elif damage == "changed-pin":
            table[name]["sha256"] = "f" * 64
        else:
            input_path = damaged / "input.json"
            input_value = strict_json_bytes(input_path.read_bytes())
            input_value["spec"]["a12_source"]["branch"] = nested.A12_TOTAL_AAR
            input_path.write_bytes(canonical_json_bytes(input_value))
        path.write_bytes(canonical_json_bytes(original_execution))
        with pytest.raises(ContractError):
            f5._q_gbm_source_evidence(damaged, state.policy)
        assert program_calls == [1] and evaluated == [1]
    # Growth after the size check must still use the original fixed read
    # bound, not another stat or an unbounded read of the changed record.
    damaged = state.tmp_path / "completed-source-metadata-growth"
    shutil.copytree(completed_copy, damaged)
    metadata = damaged / "execution.json"
    size, reads, original_open = metadata.stat().st_size, [], Path.open
    class GrowingRecord:
        def __init__(self, handle): self.handle = handle
        def __enter__(self): return self
        def __exit__(self, *args): self.handle.close()
        def read(self, amount=-1):
            reads.append(amount)
            assert amount == size + 1
            return self.handle.read(amount)
    def growing_open(path, mode="r", *args, **kwargs):
        if path == metadata and mode == "rb":
            with original_open(path, "ab") as output:
                output.write(b"x" * 64)
            return GrowingRecord(original_open(path, mode, *args, **kwargs))
        return original_open(path, mode, *args, **kwargs)
    with monkeypatch.context() as patch:
        patch.setattr(Path, "open", growing_open)
        with pytest.raises(ContractError, match="F5_GBM_Q_SOURCE_EVIDENCE_INVALID"):
            f5._q_gbm_source_evidence(damaged, state.policy)
    assert reads == [size + 1] and metadata.stat().st_size == size + 64
    # Publication must bound the total copy and independently re-prove its
    # actual targets. A stale external proof is not proof of carried bytes.
    original_proof = f5._q_gbm_source_evidence
    for damage in ("copy-growth", "copy-proof"):
        partial = state.tmp_path / ("unpublished-" + damage)
        partial.mkdir()
        shutil.copyfile(owner / "input.json", partial / "input.json")
        source_root = state.tmp_path / ("source-" + damage)
        source_root.mkdir()
        source_paths = {}
        for key, original_path in spec["native_search_batch"]["gbm_retained_source_paths"].items():
            path = source_root / Path(original_path).name
            shutil.copyfile(original_path, path)
            source_paths[key] = path
        candidate = copy.deepcopy(spec["native_search_batch"])
        candidate["gbm_retained_source_paths"] = {key: str(path) for key, path in source_paths.items()}
        copied = partial / "execution-evidence/retained-sources"
        if damage == "copy-growth":
            source_path = source_paths["retained_primary_source_bundle"]
            target = copied / "primary1513.zip"
            bound = source_path.stat().st_size
            def copy_open(path, mode="r", *args, **kwargs):
                if path == target and mode == "xb":
                    with original_open(source_path, "ab") as output:
                        output.write(b"x" * 64)
                return original_open(path, mode, *args, **kwargs)
        else:
            shutil.copyfile(source_paths["retained_primary_source_bundle"],
                            source_paths["retained_selector_source_bundle"])
            key = "execution-evidence/retained-sources/selector1ae.zip"
            candidate["gbm_retained_sources"][key] = {
                "sha256": sha256_file(source_paths["retained_selector_source_bundle"]),
                "size_bytes": source_paths["retained_selector_source_bundle"].stat().st_size}
            proof_paths = []
            def stale_external_proof(root, policy, *, sources=None):
                proof_paths.append(dict(sources))
                if sources == source_paths:
                    # Explicit TOCTOU seam: only the earlier external proof
                    # is stale; the actual target proof is the real reader.
                    return dict(sources), candidate["gbm_retained_sources"]
                return original_proof(root, policy, sources=sources)
        with monkeypatch.context() as patch:
            if damage == "copy-growth": patch.setattr(Path, "open", copy_open)
            else: patch.setattr(f5, "_q_gbm_source_evidence", stale_external_proof)
            with pytest.raises(ContractError):
                f5._q_search_batch_completion(partial, candidate, synthetic_result)
        assert not (partial / "execution.json").exists()
        if damage == "copy-growth":
            assert target.stat().st_size == bound and source_path.stat().st_size == bound + 64
        else:
            assert len(proof_paths) == 2 and all(path.parent == copied for path in proof_paths[1].values())
            assert len(list(copied.iterdir())) == 3
        assert program_calls == [1] and evaluated == [1]
    spec, tasks, retry = state.prepare("different-path")
    with pytest.raises(ContractError, match="F5_GBM_LOSS_RECOVERY_ALREADY_STARTED"):
        f5._q_search_task_batch(spec, f2_kernel._run_r_prediction_pool_task, tasks)
    assert not retry.exists() and all(path.read_bytes() == raw for path, raw in state.originals.items())


def test_source73_loss_failure_keeps_original_slot_and_unknown_attempt_count(source73_gbm_loss_recovery, monkeypatch):
    from padml import f5
    state, calls = source73_gbm_loss_recovery, []
    def fail(*args, **kwargs):
        calls.append(1)
        raise ContractError("UNFITTED_NUMERICAL_FAILURE")
    monkeypatch.setattr(f2_kernel, "_grouped_cox_loss_path", fail)
    spec, tasks, destination = state.prepare("failed")
    with pytest.raises(ContractError, match="UNFITTED_NUMERICAL_FAILURE"):
        f5._q_search_task_batch(spec, f2_kernel._run_r_prediction_pool_task, tasks)
    execution = strict_json_bytes((destination / "execution.json").read_bytes())
    assert execution["numerical_consumption"]["new_loss_evaluation_count"] is None
    assert state.slot.is_dir() and list(state.slot.rglob("*"))
    spec, tasks, retry = state.prepare("failed-new-path")
    with pytest.raises(ContractError, match="F5_GBM_LOSS_RECOVERY_ALREADY_STARTED"):
        f5._q_search_task_batch(spec, f2_kernel._run_r_prediction_pool_task, tasks)
    assert calls == [1] and not retry.exists()
    assert all(path.read_bytes() == raw for path, raw in state.originals.items())


@pytest.mark.parametrize("damage", ["different-device", "wrong-phase", "partial-batch", "missing-batch"])
def test_source73_loss_recovery_rejects_before_slot_or_computation(source73_gbm_loss_recovery, monkeypatch, damage):
    from padml import f5
    state = source73_gbm_loss_recovery
    spec, tasks, destination = state.prepare(damage)
    control = spec["native_search_batch"]
    if damage == "different-device":
        original = Path.stat
        def other_device(path, *args, **kwargs):
            value = original(path, *args, **kwargs)
            if path == state.slot.parent:
                fields = list(value)
                fields[2] += 1
                return os.stat_result(fields)
            return value
        monkeypatch.setattr(Path, "stat", other_device)
    elif damage == "wrong-phase":
        tasks = tasks[:1]  # The old record belongs to the complete two-unit phase.
    elif damage == "partial-batch":
        control["batches"][0][1]["task_ids"].append(next(name for name in
            f5._q_search_units(f2_kernel._run_r_prediction_pool_task, tasks) if name != state.name))
    else:
        control["batches"] = []
    monkeypatch.setattr(f5, "_recover_q_gbm_loss_unit", lambda *a, **k: pytest.fail("NO_NUMERICAL_START"))
    monkeypatch.setattr(f5, "_execute_and_verify_q_search_unit", lambda *a, **k: pytest.fail("NO_FIT_FALLTHROUGH"))
    with pytest.raises(ContractError, match="F5_GBM_LOSS_RECOVERY_(ALREADY_STARTED|TARGET_INVALID)"):
        f5._q_search_task_batch(spec, f2_kernel._run_r_prediction_pool_task, tasks)
    assert not state.slot.exists() and not destination.exists()
    assert all(path.read_bytes() == raw for path, raw in state.originals.items())


@pytest.mark.parametrize("damage", ["modern_missing_report", "modern_omitted_pin", "unknown_source"])
def test_retained_modern_selector_still_requires_its_original_release_reader(
        retained_selector_bundle, tmp_path, monkeypatch, damage):
    retained = f4._retained_full0_source_members(retained_selector_bundle, aar_no_aar_selector=True)
    identity = sha256_bytes(canonical_json_bytes(retained))
    assert identity == "1ae061a1a6b270cffbaddcc9687e314685fa16231558859c8ffeeb98babf94b0"
    assert identity != sha256_bytes(canonical_json_bytes(f4._f45_source_member_sha256()))
    target = tmp_path / "coarse"
    target.mkdir()
    source = {"kind": "PADML_NESTED_NO_AAR_SELECTOR_SOURCE_V1", "context": 1}
    tasks = [{"task_id": f"UNFITTED_{i:03d}", "alphas": [0.1]} for i in range(320)]
    calls = [({"nested_source": source}, {}, task, "UNFITTED", "UNFITTED") for task in tasks]
    policy = {"configured_worker_ceiling": runtime.CPU_MINUS_8, "memory_bytes_per_worker": 1,
        "scratch_bytes_per_worker": 1, "memory_reserve_bytes": 0, "scratch_reserve_bytes": 0,
        "transfer_archive_worker_ceiling": 1}
    observation = runtime.observe_execution_resources(tmp_path)
    admission = runtime.resource_admission(policy, observation, legal_tasks=1)
    ids = [tasks[0]["task_id"]]
    pin = {"path": "resource-release-" + sha256_bytes(canonical_json_bytes(ids)) + ".json",
           "sha256": "c" * 64, "size_bytes": 1}
    execution = {"source": source, "source_identity": identity, "operational_identity": runtime.OPERATIONAL_IDENTITY,
        "phase": "coarse", "alphas": [0.1], "task_ids": ids, "resource_policy": policy, "effective_policy": policy,
        "resource_observation": observation, "resource_admission": admission, "retained_bytes_per_task": 1,
        "resource_release": pin, "pool": {"configured_worker_ceiling": admission["limits"]["configured"],
            "admitted_worker_ceiling": admission["admitted_worker_ceiling"], "runnable_task_count": 1,
            "actual_worker_process_peak": 1, "completed_task_count": 1, "engine_threads": 1, "status": "COMPLETED"}}
    if damage == "modern_omitted_pin":
        del execution["resource_release"]
    elif damage == "unknown_source":
        execution["source_identity"] = "e" * 64
    (target / "execution.json").write_bytes(canonical_json_bytes([{"execution": execution, "path_results": [{
        "task_id": ids[0], "path": ids[0] + "/path-result.json", "sha256": "d" * 64, "size_bytes": 1}]}]))
    monkeypatch.setattr(f4, "_selector_phase_resource_policy", lambda *args: policy)
    # Stop at the exact changed schema/reader boundary; no path/kernel work.
    reason = {"modern_missing_report": "NESTED_SELECTOR_PHASE_RELEASE_MISSING",
        "modern_omitted_pin": "NESTED_SELECTOR_PHASE_EXECUTION_INVALID",
        "unknown_source": "NESTED_SELECTOR_PHASE_SOURCE_OR_ADMISSION_DRIFT"}[damage]
    with pytest.raises(ContractError, match=reason):
        f4._consume_full_pipeline_selector_phase_batches(calls, target, resource_policy=policy,
            retained_aar_source_bundle=retained_selector_bundle)


def test_r_child_and_original_bridge_preserve_new_executor_and_reject_old_native_alias(
        old_primary_q_source, retained_source_bundle, tmp_path, monkeypatch):
    identity = sha256_bytes(canonical_json_bytes(f4._f45_source_member_sha256()))
    native = tmp_path / "native"
    native.mkdir()
    parent = {"schema_version": "1.0.0", "execution_scope": "F5_A12_SEARCH", "fold": 1,
        "family": "GBM_COX", "seed": 301000, "outcome": "All_Cause_Death", "time": "Death_Followup_months",
        "horizons": list(range(37)), "heldout_center": 36, "predictors": {}, "fpm": None,
        "selector_from_dependency": {"selected_parents": ["Age"], "outer_recipe_sha256": "RAW_CANONICAL"},
        "a12_source": old_primary_q_source, "native_search_root": str(native), "native_search_replay": False,
        "registered_inputs_identity_sha256": "c" * 64}
    ordinary = f2_kernel._r_prediction_child_spec(parent)
    producer_proof, consumer_proof = tmp_path / "producer-proof.zip", tmp_path / "consumer-proof.zip"
    shutil.copyfile(retained_source_bundle, producer_proof)
    proof = {"retained_a12_primary_context_source_bundle": str(producer_proof),
             "a12_executor_source_identity": identity}
    child = f2_kernel._r_prediction_child_spec({**parent, **proof})
    assert child == {**ordinary, **proof} and child["seed"] == parent["seed"]
    calls = []
    def native_boundary(command, **kwargs):
        value = strict_json_bytes(Path(command[-1]).read_bytes())
        calls.append(value["native_search_replay"])
        Path(value["output_path"]).write_bytes(canonical_json_bytes({"UNFITTED": "bridge serialization only"}))
        kwargs["stdout"].write(b"UNFITTED no fitted model\n")
        return SimpleNamespace(returncode=0)
    monkeypatch.setattr(f4.subprocess, "run", native_boundary)
    actual = {**child, "action": "MODEL_PREDICTION_BATCH",
        "producer_tasks": [{"task_id": "UNFITTED_STOP", "family": "GBM_COX", "producer_kind": "GBM_STOP_CURVE"}],
        "registered_partitions": {"partitions": [{"covariates": {"input_dir": "/UNFITTED/input"},
                                                "fit_response": {"path": "/UNFITTED/response"}}]}}
    scoring = dict(f2_kernel.load_science_authority()["science"]["f2_model_development"]["trial_scoring"])
    scoring.update(ibs_grid_months=list(range(13)), ibs_integration="TRAPEZOID_DIVIDE_BY_12")
    mixed = {**parent, **proof, "selection_horizon_months": 12, "trial_scoring": scoring}
    with pytest.raises(ContractError, match="F5_RETAINED_AAR_SOURCE_SCOPE_INVALID"):
        f2_kernel._r_prediction_child_spec(mixed)
    denied = tmp_path / "mixed-twelve"
    denied.mkdir()
    (denied / "spec.json").write_bytes(canonical_json_bytes({**actual,
        "selection_horizon_months": 12, "trial_scoring": scoring, "output_path": str(denied / "output.json")}))
    with pytest.raises(ContractError, match="F5_RETAINED_AAR_Q_EXECUTOR_DRIFT"):
        f4._run_full_pipeline_r_search_batch(denied / "spec.json", denied / "output.json", tmp_path, {})
    assert not calls
    for replay in (False, True):
        work = tmp_path / ("first" if not replay else "first-audit-transport")
        work.mkdir()
        spec = {**actual, "native_search_replay": replay, "output_path": str(work / "output.json")}
        (work / "spec.json").write_bytes(canonical_json_bytes(spec))
        assert f4._run_full_pipeline_r_search_batch(work / "spec.json", work / "output.json", tmp_path, {}) == {
            "UNFITTED": "bridge serialization only"}
        if not replay:
            producer_proof.rename(consumer_proof)
            actual["retained_a12_primary_context_source_bundle"] = str(consumer_proof)
            assert not producer_proof.exists()
    assert calls == [False, True]
    batch, = native.glob("batch-*")
    saved = strict_json_bytes((batch / "spec.json").read_bytes())
    assert saved["a12_executor_source_identity"] == identity
    assert saved["retained_a12_primary_context_source_bundle"] == str(producer_proof)
    (batch / "spec.json").write_bytes(canonical_json_bytes({**saved,
        "selection_horizon_months": 12, "trial_scoring": scoring}))
    with pytest.raises(ContractError, match="F5_RETAINED_AAR_Q_EXECUTOR_DRIFT"):
        f4._run_full_pipeline_r_search_batch(work / "spec.json", work / "output.json", tmp_path, {})
    # Only the shared result boundary runs on UNFITTED trace records. These
    # expected integer totals are not assertions of performed model fits.
    shared_spec = {**parent, **proof, "retained_a12_primary_context_source_bundle": str(consumer_proof),
                   "candidate_trials": {"UNFITTED": True}}
    trace = {stage: [{"evaluation_units": count}] for stage, count in zip(
        ("S1", "S2", "S3A", "S3B1", "S3B2"), (140, 250, 300, 300, 150), strict=True)}
    selected = {"family": "GBM_COX", "selection_stage": "S3B2", "selection_metric": "IBS_0_24"}
    result = f2_kernel._shared_full_development_search_result(shared_spec, {"identity": "c" * 64}, trace, selected)
    assert result["a12_source"] == old_primary_q_source and result["seed_base"] == 301000
    with pytest.raises(ContractError, match="F5_RETAINED_AAR_Q_EXECUTOR_DRIFT"):
        f2_kernel._shared_full_development_search_result({**shared_spec, "selection_horizon_months": 12,
            "trial_scoring": scoring}, {"identity": "c" * 64}, {stage: [
                {**row, "selection_horizon_months": 12} for row in rows] for stage, rows in trace.items()},
            {**selected, "selection_metric": "IBS_0_12"})
    missing_path = {key: value for key, value in saved.items() if key != "retained_a12_primary_context_source_bundle"}
    (batch / "spec.json").write_bytes(canonical_json_bytes(missing_path))
    with pytest.raises(ContractError, match="F5_RETAINED_AAR_SOURCE_SCOPE_INVALID"):
        f4._run_full_pipeline_r_search_batch(work / "spec.json", work / "output.json", tmp_path, {})
    for key in proof:
        saved.pop(key)
    (batch / "spec.json").write_bytes(canonical_json_bytes(saved))
    with pytest.raises(ContractError, match="F4_FULL_PIPELINE_Q_R_SPEC_MISMATCH"):
        f4._run_full_pipeline_r_search_batch(work / "spec.json", work / "output.json", tmp_path, {})
    assert calls == [False, True]
