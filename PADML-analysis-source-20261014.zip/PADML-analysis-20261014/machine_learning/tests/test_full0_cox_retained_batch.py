"""Original batch reader, synthetic 300 records, real retained source proof."""
import copy
import shutil

import pytest

from padml import f4, f5, nested_loco as nested, runtime
from padml.bundle import ContractError, canonical_json_bytes, strict_json_bytes
from test_full0_cox_retained_inputs import pair, reseal
from test_full0_cox_retained_source import coxtwo  # noqa: F401
from test_nested_full_score import operational_budget  # noqa: F401


@pytest.mark.parametrize("future", [False, True])
def test_retained_batch_is_read_only_and_uses_its_original_resource_policy(tmp_path, monkeypatch, coxtwo, operational_budget, future):
    old, _, _, jobs, handles, _ = pair(tmp_path)
    root = tmp_path / "old"
    program = "be7447e86d35926cb38728d2c70a20f2aff1d18166b71effefe88ed82c36aa34"
    old["training_context"] = reseal({**old["training_context"],
        "preprocessing_program_sha256": program, "modeling_program_sha256": program})
    old["development"] = reseal({**old["development"], "training_context": old["training_context"]})
    old = reseal(old)
    batch = root / "score-batches/original"
    batch.mkdir(parents=True)
    for record, job, handle in zip(old["component_records"], jobs, handles, strict=True):
        job["coordinate_identity"] = nested._sha({"training_context_sha256": old["training_context"]["identity_sha256"],
            "record": record})
        job["score_evidence"]["context"]["identity_sha256"] = old["training_context"]["identity_sha256"]
        source = root / "score-evidence/COX_PH" / (record["path"].split("/")[-1].removesuffix(".zip") + ".json")
        evidence = strict_json_bytes(source.read_bytes())
        evidence["receipt"] = reseal({**evidence["receipt"], "training_context_sha256": old["training_context"]["identity_sha256"]})
        raw = canonical_json_bytes(reseal(evidence))
        source.write_bytes(raw)
        handle.update(state="COMPLETE", coordinate_identity=job["coordinate_identity"],
            archive_size_bytes=100, retained_size_bytes=1000, evidence_sha256=nested.sha256_bytes(raw), evidence_size_bytes=len(raw))
        target = batch / source.relative_to(root)
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
    policy = {**operational_budget, "memory_bytes_per_worker": 2 * 1024**3}
    budgets = dict(retained_bytes_per_component=10**6, expanded_bytes_per_component=10**6,
                   shared_storage_bytes=10**8, component_count=2100)
    admission, reservation = f5._full_score_resource_admission(policy, root, **budgets, request=old,
        assigned_component_count=300, verified_retained_credit_bytes=sum(row["size_bytes"] for row in old["component_records"]),
        **({"execution_scratch_reserve_bytes": 0} if future else {}))
    execution = dict(source_identity=(nested._sha(f4._f45_source_member_sha256()) if future else
        "add079ae25498023cac1054a44c3a41444a51b0cf72dc8b5ed5ae3bc8648ac43"),
        operational_identity=runtime.OPERATIONAL_IDENTITY, request_identity_sha256=old["identity_sha256"],
        training_context_sha256=old["training_context"]["identity_sha256"],
        score_partitions_sha256=nested._sha(old["score_partitions"]), task_ids=[row["path"] for row in old["component_records"]],
        archive_handles=handles, resource_policy=policy, resource_admission=admission, resource_reservation=reservation,
        new_model_fits=300, new_model_native_verification_count=300, new_mice_chains=0, new_stop_fits=0,
        pool=dict(configured_worker_ceiling=56, admitted_worker_ceiling=1, runnable_task_count=300,
            actual_worker_process_peak=1, completed_task_count=300, engine_threads=1, status="COMPLETED"))
    (batch / "execution.json").write_bytes(canonical_json_bytes(execution))
    originals = {path: path.read_bytes() for path in root.rglob("*") if path.is_file()}
    def forbidden(*args, **kwargs):
        pytest.fail("Retained batch reader may not write, release, fit, or replay")
    if not future:
        monkeypatch.setattr(nested, "_write_exact_once", forbidden)
    monkeypatch.setattr(runtime, "release_step_resources", forbidden)
    monkeypatch.setattr(runtime, "_bounded_ordered_spawn", forbidden)
    options = dict(resource_policy=(policy if future else {**policy, "scratch_reserve_bytes": 0}), budgets=budgets,
        shared_credit=0, storage_scope={},
        **({} if future else {"retained_score_producer_source_bundle": coxtwo[0]}))
    actual, current_admission, current_reservation = f5._consume_full_score_batches(old, jobs, root, [batch], **options)
    assert actual == handles and current_admission["limits"]["configured"] == 56
    assert current_reservation["verification_only"] is True
    assert current_reservation["effective_policy"]["scratch_reserve_bytes"] == 0
    assert current_reservation["remaining_retention_reserved_bytes"] == 0
    assert all(path.read_bytes() == raw for path, raw in originals.items())
    additional = {root / "score-batches" / (nested.sha256_bytes(canonical_json_bytes(execution)) + ".json")} if future else set()
    assert {path for path in root.rglob("*") if path.is_file()} == set(originals) | additional
    # Ordinary full0 shards may originate from a same-context family subset;
    # the exact old request pin is additionally required only for this reuse.
    for damage in (("source", "policy", "missing") if future else ("request", "source", "policy", "missing")):
        bad = copy.deepcopy(execution)
        if damage == "request":
            bad["request_identity_sha256"] = "9" * 64
        elif damage == "source":
            bad["source_identity"] = "d511d23894ef9d1a69da1adeb8328ad4c72944f5c42e95d8ede7465d151992e3"
        elif damage == "policy":
            bad["resource_policy"]["memory_reserve_bytes"] += 1
        else:
            bad["task_ids"].pop()
            bad["archive_handles"].pop()
        (batch / "execution.json").write_bytes(canonical_json_bytes(bad))
        with pytest.raises(ContractError):
            f5._consume_full_score_batches(old, jobs, root, [batch], **options)
    (batch / "execution.json").write_bytes(originals[batch / "execution.json"])
