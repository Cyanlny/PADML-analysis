"""Execution-owner guard tests; no science or claimed scientific acceptance."""
from pathlib import Path

import pytest

from padml import f4, f5
from padml.bundle import ContractError


def test_compiler_has_no_execution_switch():
    import inspect
    for function in (f4.compile_o_fit_bundle, f4._compile_o_fit_bundle):
        parameters = inspect.signature(function).parameters
        assert "primary_development" not in parameters
        assert "_execution_batch_root" not in parameters


@pytest.mark.parametrize("resume", [False, True])
def test_primary12_complete_scoring_requires_fixed_evidence_before_admission(tmp_path, monkeypatch, resume):
    from padml import nested_loco as nested
    from padml.bundle import canonical_json_bytes, write_deterministic_zip
    source = tmp_path / "input.zip"
    write_deterministic_zip(source, {"o-fit-input.json": canonical_json_bytes({
        "selection_horizon_months": 12, "science_decision": {}})})
    monkeypatch.setattr(nested, "outer_fresh_score_families", lambda _: nested._families())
    def forbidden(*args, **kwargs):
        pytest.fail("missing fixed evidence reached admission or scientific work")
    monkeypatch.setattr(f5, "_full_score_resource_admission", forbidden)
    monkeypatch.setattr(f5, "_execute_and_verify_score_archive_job", forbidden)
    root = tmp_path / "score"
    if resume:
        root.mkdir()
    with pytest.raises(ContractError, match="NESTED_OUTER_FIXED12_SCORE_INPUT_REQUIRED"):
        f5._full_data_locked_score_program(None, None, None, None, None, root,
            rscript="FORBIDDEN", replay=False, resume=resume, resource_policy={},
            retained_bytes_per_component=1024, expanded_bytes_per_component=1024,
            shared_storage_bytes=1024, outer_input=source)


@pytest.mark.parametrize("horizon", [12, 24])
def test_fixed_evidence_guard_preserves_original_admission(tmp_path, monkeypatch, horizon):
    from padml import nested_loco as nested
    from padml.bundle import canonical_json_bytes, write_deterministic_zip
    source = tmp_path / "input.zip"
    write_deterministic_zip(source, {"o-fit-input.json": canonical_json_bytes({
        "selection_horizon_months": horizon, "science_decision": {}})})
    monkeypatch.setattr(nested, "outer_fresh_score_families", lambda _: nested._families())
    class AdmissionReached(Exception):
        pass
    def admission(*args, **kwargs):
        raise AdmissionReached
    def forbidden(*args, **kwargs):
        pytest.fail("guard test reached evidence consumption or scientific work")
    monkeypatch.setattr(f5, "_full_score_resource_admission", admission)
    monkeypatch.setattr(f5, "_execute_and_verify_score_archive_job", forbidden)
    with pytest.raises(AdmissionReached):
        f5._full_data_locked_score_program(None, None, None, None, None, tmp_path / "score",
            rscript="FORBIDDEN", replay=False, resource_policy={},
            retained_bytes_per_component=1024, expanded_bytes_per_component=1024,
            shared_storage_bytes=1024, outer_input=source,
            outer_fixed12_reader=forbidden if horizon == 12 else None)


def test_primary_owner_rejects_score_input_mix_before_any_work(tmp_path, monkeypatch):
    def forbidden(*args, **kwargs):
        pytest.fail("mixed mode reached scientific/input reader")
    monkeypatch.setattr(f4, "load_f4_inputs", forbidden)
    monkeypatch.setattr(f4, "_execute_o_fit_training_bundle", forbidden)
    with pytest.raises(ContractError, match="F4_PRIMARY_DEVELOPMENT_EXECUTION_SCOPE_INVALID"):
        f4.execute_o_fit_bundle(tmp_path, target=tmp_path / "result.zip", outer_fold=1,
            input_bundle=tmp_path / "score.zip", primary_development={})


def test_execution_helper_rejects_historical_recovery_before_loading(tmp_path):
    with pytest.raises(ContractError, match="F5_PRIMARY_CONTINUOUS_EXECUTION_SCOPE_INVALID"):
        f5._prepare_primary_outer_rsf_search({}, tmp_path / "q", {},
            retained_bytes_per_task=1, admit_io=lambda **kwargs: pytest.fail("admission reached"),
            prepared_calls=[], retained_q_input=tmp_path / "input.json",
            batch_options={"primary_rsf_s3b2_consumption": True},
            _execution_batch_root=tmp_path, _execution_phase_task_ids={"S3B2": ["x"]})


def test_primary_validator_accepts_only_a_complete_all_pending_execution_owner(monkeypatch):
    """The first complete owner has no completed Q context to compare yet."""
    from padml import nested_loco as nested

    families = {"RSF", "GBM_COX", "XGBOOST_COX", "COXTIME_SET_A"}
    monkeypatch.setattr(nested, "validate_science_decision", lambda _: {
        "twelve_month_development": nested._twelve_month_development_contract()})
    monkeypatch.setattr(f4, "_f45_source_member_sha256", lambda: {})

    assert nested._validate_outer_primary_searches({}, outer=1, science_decision={}, context={},
        source_bundles={}, _execution_pending_families=set(families)) == {}
    with pytest.raises(ContractError, match="NESTED_PRIMARY12_COMPLETE_SEARCHES_REQUIRED"):
        nested._validate_outer_primary_searches({}, outer=1, science_decision={}, context={},
            source_bundles={}, _execution_pending_families=families - {"RSF"})


@pytest.fixture
def multi_owner(tmp_path, monkeypatch):
    """Exercise the real owner with synthetic original-consumer boundaries."""
    from padml import nested_loco as nested, runtime, f4_compact
    families = ("RSF", "GBM_COX", "XGBOOST_COX", "COXTIME_SET_A")
    events = []
    digest = "a" * 64
    state = {"bad_preparation": None, "bad_execution": None, "partial": None,
             "admissions": [], "execution_reserves": []}
    monkeypatch.setattr(nested, "validate_science_decision", lambda value: value)
    monkeypatch.setattr(runtime, "validate_resource_policy", lambda value: value)
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda root: {"scratch_available_bytes": 10**12})
    monkeypatch.setattr(runtime, "resource_admission",
                        lambda policy, *a, **k: (state["admissions"].append(policy["memory_reserve_bytes"]) or {}))
    monkeypatch.setattr(f5, "_retained_tree_bytes", lambda root: 0)
    monkeypatch.setattr(f4, "load_f4_inputs", lambda *a, **k: {})
    monkeypatch.setattr(nested, "_project_outer_development_from_inputs",
                        lambda *a, **k: {"training_context": {}})
    monkeypatch.setattr(f4, "_f45_source_member_sha256", lambda: {})
    monkeypatch.setattr(f4, "sha256_bytes", lambda raw: digest)
    source = {"producer_source_identity": digest}
    monkeypatch.setattr(f4, "_primary_complex_search_source", lambda spec: source)

    def validate_complete(searches, **kwargs):
        assert set(searches) | kwargs["_execution_pending_families"] == set(families)
        assert not set(searches) & kwargs["_execution_pending_families"]
        events.append("complete-precheck")
    monkeypatch.setattr(nested, "_validate_outer_primary_searches", validate_complete)

    def prepare(projected, root, policy, *, family, _defer_execution, **kwargs):
        assert _defer_execution is True
        events.append("prepare:" + family)
        if state["bad_preparation"] == family:
            raise ContractError("SYNTHETIC_BAD_SOURCE")
        root.mkdir()
        (root / "input.json").write_text('{"spec":{}}')
        calls = []
        def finish():
            assert not calls, "same family was executed twice"
            calls.append(True)
            events.append("execute:" + family)
            kwargs["admit_io"]()
            state["execution_reserves"].append(state["admissions"][-1])
            state["last_admit"] = kwargs["admit_io"]
            if state["bad_execution"] == family:
                (root / "failure.txt").write_text("attributable failure")
                raise ContractError("SYNTHETIC_FIT_FAILURE")
            (root / "result.json").write_text('{"new_model_fits":0,"new_stop_fits":0}')
            return {"status": "PREPARED_Q_BATCH" if state["partial"] == family else "COMPUTED_Q_SEARCH",
                    "primary_search_source": source, "execution_source_identity": digest,
                    "new_model_fits": 3, "new_stop_fits": int(family != "RSF"),
                    "new_first_native_audits": 3}
        finish.retained_memory_bytes = 100
        return finish
    monkeypatch.setattr(f5, "_prepare_primary_outer_rsf_search", prepare)

    def compile_bundle(source_root, target, **kwargs):
        assert set(kwargs["primary_search_roots"]) == set(families)
        events.append("compile")
    monkeypatch.setattr(f4, "compile_o_fit_bundle", compile_bundle)
    monkeypatch.setattr(f4, "_execute_o_fit_training_bundle",
                        lambda *a, **k: (events.append("training") or {"status": "TRAINED"}))
    monkeypatch.setattr(f4_compact, "_full_pipeline_q_numerical_members",
                        lambda path: ({"input.json": path / "input.json", "result.json": path / "result.json"}, {}))
    pending = {}
    for family in families:
        batch = tmp_path / family
        batch.mkdir()
        pending[family] = {"retained_q_input": batch / "input.json", "retained_input_producer": None,
            "q_batch_options": {}, "continuous_batch_root": batch, "phase_task_ids": {"suffix": ["unit"]}}
    parameters = {"science_decision": {}, "resource_policy": {"memory_reserve_bytes": 1},
        "retained_bytes_per_component": 10**6, "expanded_bytes_per_component": 10**6,
        "shared_storage_bytes": 10**10, "search_roots": {}, "search_source_bundles": {},
        "pending_searches": pending}
    def run():
        return f4.execute_o_fit_bundle(tmp_path, target=tmp_path / "result.zip",
                                      outer_fold=1, primary_development=parameters)
    return run, parameters, state, events, families


def test_multi_owner_all_prepared_before_once_each_execution(multi_owner):
    run, _, state, events, families = multi_owner
    result = run()
    assert events == ["complete-precheck"] + ["prepare:" + f for f in sorted(families)] + [
        "execute:" + f for f in sorted(families)] + ["compile", "training"]
    assert result["status"] == "TRAINED"
    assert set(result["primary_search_executions"]) == set(families)
    assert state["execution_reserves"] == [401, 301, 201, 101]
    state["last_admit"]()
    assert state["admissions"][-1] == 1


def test_multi_owner_last_known_bad_source_prevents_every_fit(multi_owner):
    run, _, state, events, families = multi_owner
    state["bad_preparation"] = sorted(families)[-1]
    with pytest.raises(ContractError, match="SYNTHETIC_BAD_SOURCE"):
        run()
    assert not any(item.startswith("execute:") for item in events)
    assert "compile" not in events


@pytest.mark.parametrize("defect", ["overlap", "missing", "unknown"])
def test_multi_owner_coverage_errors_before_loading(multi_owner, defect):
    run, parameters, _, events, families = multi_owner
    if defect == "overlap":
        parameters["search_roots"][families[0]] = Path("/unused")
    elif defect == "missing":
        parameters["pending_searches"].pop(families[0])
    else:
        parameters["pending_searches"]["UNKNOWN"] = parameters["pending_searches"][families[0]]
    with pytest.raises(ContractError, match="F4_PRIMARY_DEVELOPMENT_EXECUTION_SCOPE_INVALID"):
        run()
    assert not events


def test_multi_owner_failure_preserved_without_retry_or_compiler(multi_owner, tmp_path):
    run, _, state, events, families = multi_owner
    family = sorted(families)[0]
    state["bad_execution"] = family
    with pytest.raises(ContractError, match="SYNTHETIC_FIT_FAILURE"):
        run()
    assert [e for e in events if e.startswith("execute:")] == ["execute:" + family]
    assert "compile" not in events
    assert len(list(tmp_path.glob(".result.zip.primary-*/q-*/failure.txt"))) == 1
    assert state["execution_reserves"] == [401]
    state["last_admit"]()
    assert state["admissions"][-1] == 301  # failed active call released; pending remain charged


def test_multi_owner_shared_memory_failure_prevents_first_fit(multi_owner, monkeypatch):
    from padml import runtime
    run, _, state, events, _ = multi_owner
    def admission(policy, *args, **kwargs):
        state["admissions"].append(policy["memory_reserve_bytes"])
        if policy["memory_reserve_bytes"] >= 401:
            raise ContractError("SYNTHETIC_SHARED_MEMORY_EXHAUSTED")
        return {}
    monkeypatch.setattr(runtime, "resource_admission", admission)
    with pytest.raises(ContractError, match="SYNTHETIC_SHARED_MEMORY_EXHAUSTED"):
        run()
    assert not any(item.startswith("execute:") for item in events)
    assert "compile" not in events


def test_multi_owner_partial_reports_actual_execution_but_persists_zero(multi_owner):
    import json
    run, _, state, events, families = multi_owner
    state["partial"] = families[0]
    report = run()
    assert report["status"] == "PREPARED_Q_BATCH"
    assert report["new_model_fits"] == 12
    assert report["new_stop_fits"] == 3
    assert "compile" not in events
    for result in report["primary_search_results"].values():
        stored = json.loads((Path(result["root"]) / "result.json").read_text())
        assert stored == {"new_model_fits": 0, "new_stop_fits": 0}


def test_full_primary_owner_needs_no_manual_phase_ids(multi_owner, monkeypatch):
    run, parameters, _, events, families = multi_owner
    original = f5._prepare_primary_outer_rsf_search
    def prepare(*args, **kwargs):
        assert kwargs["_execution_phase_task_ids"] is None
        return original(*args, **kwargs)
    monkeypatch.setattr(f5, "_prepare_primary_outer_rsf_search", prepare)
    for row in parameters["pending_searches"].values():
        del row["phase_task_ids"]
    report = run()
    assert report["status"] == "TRAINED"
    assert [e for e in events if e.startswith("execute:")] == ["execute:" + f for f in sorted(families)]
    assert events[-2:] == ["compile", "training"]


@pytest.mark.parametrize("family,prefix_length,damage", [
    ("GBM_COX", 1, None),
    ("XGBOOST_COX", 6, None),
    ("COXTIME_SET_A", 9, None),
    *( ("GBM_COX", 2, damage) for damage in
       ("gap", "partial", "duplicate", "started-path", "wrong-source") ),
])
def test_primary_helper_derives_whole_unstarted_suffix_once(tmp_path, monkeypatch, family, prefix_length, damage):
    """Real helper/control metadata boundary, not numerical receipt acceptance.

    With non-None options, original _q_search_batch_control checks receipt path,
    byte bounds and canonical dictionaries, then appends records unchanged.
    These deliberately minimal metadata records exercise suffix derivation;
    _run_final_complex_search is stopped before full receipt/numerical reading.
    """
    from padml import nested_loco as nested
    from padml.bundle import canonical_json_bytes
    from test_primary_outer12_rsf_prepare import _projected, _POLICY
    original_control = f5._q_search_batch_control
    projected = _projected(monkeypatch, 1, 56)
    assert f5._q_search_batch_control is original_control  # fixture does not replace this consumer
    projected["accepted_model_result_sha256"] = "a" * 64
    for partition in projected["registered"]["partitions"]:
        partition["evaluation_response"]["size_bytes"] = len(partition["evaluation_response"]["private_bytes"])
    monkeypatch.setattr(f5, "_final_complex_candidate_trials", lambda family: {"S1": [], "S2": []})
    class NumericalBoundary(Exception):
        pass
    calls = []
    def stop_at_funnel(spec, *args):
        calls.append(spec["native_search_batch"])
        raise NumericalBoundary
    monkeypatch.setattr(f5, "_run_final_complex_search", stop_at_funnel)
    first = tmp_path / "input-only"
    with pytest.raises(NumericalBoundary):
        f5._prepare_primary_outer_rsf_search(projected, first, _POLICY, family=family,
            retained_bytes_per_task=1024**2, admit_io=lambda **kwargs: None, prepared_calls=[])
    calls.clear()
    phases = [f5._a12_q_stop_phase(stage, refit=refit, family=family)
              for stage in ("S1", "S2", "S3A", "S3B1", "S3B2") for refit in (False, True)]
    records = []
    identity = nested._sha(f4._f45_source_member_sha256())
    for index, (phase, ids) in enumerate(phases[:prefix_length]):
        # Complete phase-ID coverage in two metadata shards. These are not
        # fabricated claims of native execution or complete scientific receipts.
        for shard in range(2):
            selected = ids[shard::2]
            if not selected:
                continue
            path = tmp_path / f"prefix-{index}-{shard}"
            path.mkdir()
            record = {"source_identity": identity, "phase": phase, "task_ids": selected}
            records.append((path, record))
    if damage == "gap":
        records = [(path, row) for path, row in records if row["phase"] != phases[0][0]]
        if not records:
            path = tmp_path / "gap"; path.mkdir()
            records = [(path, {"source_identity": identity, "phase": phases[1][0], "task_ids": phases[1][1]})]
    elif damage == "partial":
        records[0][1]["task_ids"] = records[0][1]["task_ids"][1:]
    elif damage == "duplicate":
        records[0][1]["task_ids"] += records[0][1]["task_ids"][:1]
    elif damage == "wrong-source":
        records[-1][1]["source_identity"] = "0" * 64
    for path, row in records:
        (path / "execution.json").write_bytes(canonical_json_bytes(row))
    continuous = tmp_path / "execution"; continuous.mkdir()
    if damage == "started-path":
        (continuous / phases[prefix_length][0]).mkdir()
    options = {"prepare_only": True, "task_ids": None, "batch_root": None,
               "q_batches": [path for path, _ in records], "retained_bytes_per_task": 1024**2}
    kwargs = dict(family=family, retained_bytes_per_task=1024**2, admit_io=lambda **kw: None,
        prepared_calls=[], retained_q_input=first / "input.json", batch_options=options,
        _execution_batch_root=continuous, _defer_execution=True)
    if damage:
        failure = ("F5_PRIMARY_PREPARED_Q_NUMERICAL_SCOPE_INVALID" if damage == "wrong-source" else
                   "F5_PRIMARY_CONTINUOUS_AUTHORIZED_PHASES_INVALID" if damage == "started-path" else
                   "F5_PRIMARY_CONTINUOUS_EXECUTION_PREFIX_REQUIRED")
        with pytest.raises(ContractError, match=failure):
            f5._prepare_primary_outer_rsf_search(projected, tmp_path / "continued", _POLICY, **kwargs)
        assert calls == []
    else:
        finish = f5._prepare_primary_outer_rsf_search(projected, tmp_path / "continued", _POLICY, **kwargs)
        assert calls == []
        with pytest.raises(NumericalBoundary):
            finish()
        assert len(calls) == 1
        assert calls[0]["batches"] == records  # exact original control reader output
        assert calls[0]["primary_continuous_phase_task_ids"] == dict(phases[prefix_length:])
        with pytest.raises(ContractError, match="ALREADY_STARTED"):
            finish()
        assert len(calls) == 1


@pytest.mark.parametrize("outer,reuse_summary,damage", [
    (4, False, None), (6, False, None), (4, True, None),
    (4, False, "missing-s1-root"), (4, False, "partial-s3b1"),
    (4, False, "duplicate-s3b1"), (4, False, "no-authority"),
])
def test_primary_owner_history_s1_before_same_context_suffix(tmp_path, monkeypatch, outer, reuse_summary, damage):
    """Original owner/control/retain/reuse ordering; not real historical acceptance.

    UNFITTED metadata, source/history reader and stage-score validator are
    bounded stubs. The original numerical funnel is stopped at the suffix.
    Real old source proof and original terminal consumption need separate
    Linux fixtures; this test cannot certify them or scientific quantities.
    """
    from padml import f4_compact, nested_loco as nested
    from padml.bundle import canonical_json_bytes, sha256_bytes, sha256_file, strict_json_bytes
    from test_primary_outer12_rsf_prepare import _projected, _POLICY
    projected = _projected(monkeypatch, outer, 56)
    for part in projected["registered"]["partitions"]:
        part["evaluation_response"]["size_bytes"] = len(part["evaluation_response"]["private_bytes"])
    trials = [{"trial_id": f"S1-{i}", "parameters": {}, "parameter_sha256": sha256_bytes(b"{}")}
              for i in range(24)]
    trace = [{"candidate_id": row["trial_id"]} for row in trials]
    monkeypatch.setattr(f5, "_final_complex_candidate_trials", lambda family: {"S1": trials, "S2": []})
    monkeypatch.setattr(f5, "_validate_complex_search_stage", lambda *args, **kw: None)
    class SuffixBoundary(Exception):
        pass
    events, captured = [], []
    def first_funnel(spec, *args):
        captured.append(spec)
        raise SuffixBoundary
    monkeypatch.setattr(f5, "_run_final_complex_search", first_funnel)
    old = tmp_path / "prefix"
    with pytest.raises(SuffixBoundary):
        f5._prepare_primary_outer_rsf_search(projected, old, _POLICY,
            retained_bytes_per_task=1024**2, admit_io=lambda **kw: None, prepared_calls=[])
    raw = (old / "input.json").read_bytes()
    input_ref = {"sha256": sha256_bytes(raw), "size_bytes": len(raw)}
    source = strict_json_bytes(raw)["spec"]["primary_search_source"]
    phases = {stage: f5._a12_q_stop_phase(stage, refit=True, family="RSF")
              for stage in ("S1", "S2", "S3A", "S3B1", "S3B2")}
    identity = nested._sha(f4._f45_source_member_sha256())
    records, evidence = {}, {}
    hosts = ("H0", "H1", "H4", "H5", "H6", "H7", "H9-2")
    for stage, next_stage in (("S1", "s2"), ("S2", "s3a"), ("S3A", "s3b1"), ("S3B1", None)):
        records[stage] = []
        for i, host in enumerate(hosts):
            root = tmp_path / (stage + "-" + host); root.mkdir()
            row = {"phase": phases[stage][0], "task_ids": phases[stage][1][i::7],
                   "input": input_ref, "source_identity": identity}
            if stage == "S3B1" and i == 0:
                if damage == "partial-s3b1": row["task_ids"] = row["task_ids"][1:]
                if damage == "duplicate-s3b1": row["task_ids"] += row["task_ids"][:1]
            (root / "execution.json").write_bytes(canonical_json_bytes(row))
            records[stage].append((root, row))
            if next_stage:
                evidence.setdefault(next_stage, {})[f"primary-{next_stage}/{host}-execution.json"] = root / "execution.json"
    prefix = {"status": "PREPARED_Q_BATCH", "stage_acceptance": False,
        "complete_search_trace": False, "primary_search_source": source, "input": input_ref,
        "input_sha256": input_ref["sha256"], "search_trace": {"S2": [], "S3A": []},
        "s1_consumed_history": {"score_trace_status": "NOT_RETAINED"},
        "phase": phases["S3B1"][0], "task_ids": phases["S3B1"][1],
        "confirmed_model_fits": 620, "confirmed_stop_fits": 0,
        "predecessor_execution_sha256": [sha256_bytes(canonical_json_bytes(row)) for _, row in records["S3A"]]}
    original_prefix_raw = canonical_json_bytes(prefix)
    (old / "result.json").write_bytes(original_prefix_raw)
    (old / "numbers.json").write_bytes(b"{}")
    def compact(root, *, publish=False, transported_refs=None, **kwargs):
        # Transport-only shim: retain/reuse still check original input bytes,
        # summary phase, original source, 7 predecessors and integer counters.
        if publish:
            (root / "numbers.json").write_bytes(canonical_json_bytes(transported_refs))
        files = {str(path.relative_to(root)): path for path in root.rglob("*") if path.is_file()}
        refs = {name: {"sha256": sha256_file(path), "size_bytes": path.stat().st_size}
                for name, path in files.items() if name == "input.json" or name.startswith("native/")}
        return files, refs
    monkeypatch.setattr(f4_compact, "_full_pipeline_q_numerical_members", compact)
    base = tmp_path / "base-preparation.zip"; base.write_bytes(b"UNFITTED")
    producer = tmp_path / "producer.zip"; producer.write_bytes(b"UNFITTED")
    evidence["s2"]["source/primary-q-producer.zip"] = producer
    def prepared_reader(qraw, preparation, supplied_producer, **kwargs):
        assert qraw == raw and preparation == base and supplied_producer == producer
        assert set(kwargs) == {"s2_evidence", "s3a_evidence", "s3b1_evidence"}
        events.append("history-read")
        return {}, {}
    monkeypatch.setattr(f5, "_primary_rsf_prepared_input", prepared_reader)
    monkeypatch.setattr(f4, "_primary_rsf_search_source", lambda spec: source)
    monkeypatch.setattr(f4, "load_f45_source_bundle", lambda path: {
        "members": [{"path": name, "sha256": digest} for name, digest in f4._f45_source_member_sha256().items()]})
    qroots = [path for path, _ in records["S3B1"]]
    if damage != "missing-s1-root": qroots += [path for path, _ in records["S1"]]
    options = {"prepare_only": True, "task_ids": None, "batch_root": None,
        "q_batches": qroots, "retained_bytes_per_task": 1024**2,
        "primary_rsf_preparation": base, "primary_rsf_producer": producer,
        "retained_primary_rsf_q_source_bundle": producer,
        **{"primary_rsf_" + stage + "_evidence": paths for stage, paths in evidence.items()}}
    if damage != "no-authority": options["s1_summary_recovery_call_limit"] = 0 if reuse_summary else 1
    def seed_s1(spec, root, control):
        name = "native/UNFITTED-S1/payload.json"
        path = root / name; path.parent.mkdir(parents=True); path.write_bytes(b"UNFITTED")
        control.update(primary_rsf_s1_trace=trace, used_batches=[sha256_bytes(canonical_json_bytes(row))
            for _, row in records["S1"]], confirmed_model_fits=120, confirmed_stop_fits=0,
            references={"input.json": input_ref, name: {"sha256": sha256_file(path), "size_bytes": 8}})
    if reuse_summary:
        saved = tmp_path / "saved"; saved.mkdir(); (saved / "input.json").write_bytes(raw)
        c = {"resource_policy": _POLICY}; seed_s1(captured[0], saved, c)
        f5._retain_primary_rsf_s1_summary(captured[0], saved, c, input_ref)
        options.update(primary_rsf_s1_summary=saved / "s1-summary",
            primary_rsf_s1_summary_sha256=sha256_file(saved / "s1-summary/numbers.json"))
    def funnel(spec, registered, scratch):
        control = spec["native_search_batch"]
        if "prepared_calls" not in control:
            events.append("recover")
            assert not any("_evidence" in key for key in control)
            assert control["primary_rsf_preparation"] == base and control["primary_rsf_producer"] == producer
            assert len(control["batches"]) == 7 and control["confirmed_model_fits"] == 0
            seed_s1(spec, Path(spec["native_search_root"]).parent, control)
            raise f5._QBatchBoundary({"phase": phases["S2"][0], "task_ids": phases["S2"][1],
                "new_model_fits": 0, "confirmed_model_fits": 120, "confirmed_stop_fits": 0,
                "search_trace": {"S1": trace}})
        events.append("suffix")
        assert control["confirmed_model_fits"] == 620 and len(control["used_batches"]) == 21
        assert control["primary_rsf_retained_prefix"]["predecessor_execution_sha256"] == control["used_batches"]
        assert list(control["primary_rsf_retained_prefix"]["search_trace"]) == ["S1", "S2", "S3A"]
        assert control["primary_continuous_phase_task_ids"] == {phases["S3B2"][0]: phases["S3B2"][1]}
        assert control["s1_summary_recovery_calls"] == int(not reuse_summary)
        assert len(control["primary_rsf_evidence"]) == 6
        assert (old / "result.json").read_bytes() == original_prefix_raw
        raise SuffixBoundary
    monkeypatch.setattr(f5, "_run_final_complex_search", funnel)
    continuous = tmp_path / "continuous"; continuous.mkdir()
    kwargs = dict(retained_bytes_per_task=1024**2, admit_io=lambda **kw: None, prepared_calls=[],
        retained_q_input=old / "input.json", batch_options=options,
        _execution_batch_root=continuous, _defer_execution=True)
    if damage:
        failure = ("S1_NUMERICAL_BATCHES_REQUIRED" if damage == "missing-s1-root" else
                   "RECOVERY_AUTHORITY_REQUIRED" if damage == "no-authority" else "NUMERICAL_SCOPE_INVALID")
        with pytest.raises(ContractError, match=failure):
            f5._prepare_primary_outer_rsf_search(projected, tmp_path / "owner", _POLICY, **kwargs)
        assert events == ["history-read"]
    else:
        finish = f5._prepare_primary_outer_rsf_search(projected, tmp_path / "owner", _POLICY, **kwargs)
        assert events == ["history-read"] and finish.retained_memory_bytes > 0
        with pytest.raises(SuffixBoundary): finish()
        assert events == ["history-read"] + ([] if reuse_summary else ["recover"]) + ["suffix"]
        with pytest.raises(ContractError, match="ALREADY_STARTED"): finish()
