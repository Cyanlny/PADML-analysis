"""Full0 data/spec seams, with explicitly UNFITTED MICE and no native calls."""
import copy
import csv
import io
from pathlib import Path

import pytest

from padml import f4, f5, f2_kernel
from padml.bundle import ContractError, canonical_json_bytes, sha256_bytes
from padml.runtime import RSCRIPT_EXECUTABLE
from test_full_pipeline_mice_native import inputs


@pytest.fixture(autouse=True)
def no_native(monkeypatch):
    def forbidden(*args, **kwargs):
        raise AssertionError("NO_NATIVE_FIT_RNG_OR_POOL")
    monkeypatch.setattr(f4.subprocess, "run", forbidden)
    monkeypatch.setattr(f4, "_bounded_ordered_spawn", forbidden)
    monkeypatch.setattr(f2_kernel, "_bounded_ordered_spawn", forbidden)
    monkeypatch.setattr(f4, "_run_full_pipeline_mice_native", forbidden)
    monkeypatch.setattr(f2_kernel, "candidate_trials", forbidden)


def unfitted_context(inputs, tmp_path, monkeypatch, family):
    plan, source = copy.deepcopy(inputs)
    plan["family"] = family
    # Handwritten grouped 3x5 membership fixture; not a new native split/RNG run.
    def partitions(ids, centers, events, **kwargs):
        return {"splits": [{"repeat": r, "inner_fold": k, "seed": 100000 + r * 100,
                            "training_ids": [v for i, v in enumerate(ids) if i % 5 != k - 1],
                            "validation_ids": [v for i, v in enumerate(ids) if i % 5 == k - 1]}
                           for r in range(1, 4) for k in range(1, 6)]}
    monkeypatch.setattr(f5, "full_data_splits", partitions)
    actual = f4._prepare_full_pipeline_mice_context(plan, 1, 0, source, tmp_path.resolve(), rscript=RSCRIPT_EXECUTABLE)
    reader = csv.DictReader(io.StringIO(actual["covariates_csv"].decode()))
    rows = {row["Patient_ID"]: row for row in reader}
    native = tmp_path.resolve() / "UNFITTED_COMPLETIONS"
    native.mkdir()
    completed = {}
    for name, spec in actual["mice_specs"].items():
        root = native / name
        root.mkdir()
        (root / "view.json").write_bytes(canonical_json_bytes({"UNFITTED": name}))
        completed[name] = []
        offset = (100 if name.startswith("STOP") else 0) + (1000 if spec["view"]["role"] == "APPLICATION" else 0)
        for imp in range(1, 21):
            path = root / f"imp{imp:02d}.csv"
            with path.open("x", newline="") as handle:
                writer = csv.DictWriter(handle, fieldnames=reader.fieldnames, lineterminator="\n")
                writer.writeheader()
                writer.writerows({**rows[patient], "Creatinine": str(offset + imp)} for patient in spec["view"]["row_ids"])
            completed[name].append(path)
    return {**actual, "native_root": native, "completed": completed, "archive_identity_sha256": "a" * 64}


@pytest.mark.parametrize("family", ["RSF", "COXTIME_SET_A"])
def test_full0_search_uses_separate_analysis_application_and_stop(inputs, tmp_path, monkeypatch, family):
    context = unfitted_context(inputs, tmp_path, monkeypatch, family)
    registered = f4._materialize_full_pipeline_search_partitions(context, tmp_path.resolve() / "search")
    assert registered["kind"] == "PADML_F4_FULL_PIPELINE_REGISTERED_INPUTS"
    assert registered["inner_count"] == 15 and registered["stop_count"] == (0 if family == "RSF" else 15)
    assert len(registered["partitions"]) == registered["view_count"] == (15 if family == "RSF" else 30)
    original = set(context["original_evaluation_ids"])
    clones = {row["clone_id"]: row["source_patient_id"] for row in context["clone_mapping"]}
    inners = {(row["repeat"], row["inner_fold"]): row for row in registered["partitions"] if row["kind"] == "INNER"}
    for row in registered["partitions"]:
        fit, valid = set(row["fit_ids"]), set(row["evaluation_ids"])
        assert fit.isdisjoint(valid) and original.isdisjoint(row["application_ids"])
        assert {clones[p] for p in fit}.isdisjoint({clones[p] for p in valid})
        offset = 100 if row["kind"] == "STOP" else 0
        if row["kind"] == "STOP":
            assert row["application_ids"] == inners[(row["repeat"], row["inner_fold"])]["fit_ids"]
        for imp in range(1, 21):
            path = Path(row["covariates"]["input_dir"]) / f"imp{imp:02d}.csv"
            table = list(csv.DictReader(io.StringIO(path.read_text())))
            assert [r["Patient_ID"] for r in table] == row["application_ids"]
            assert all(r["Creatinine"] == str(offset + imp + (0 if r["Patient_ID"] in fit else 1000)) for r in table)
        engine = f2_kernel._engine_registered_partitions(registered, {row["partition_id"]})
        assert engine["projected_partition_count"] == 1
        assert "evaluation_response" not in engine["partitions"][0]
        assert engine["partitions"][0]["fit_response"] == row["fit_response"]
    # Relocation changes no scientific identity and does not run MICE again.
    relocated = f4._materialize_full_pipeline_search_partitions(context, tmp_path.resolve() / "relocated")
    assert relocated["identity"] == registered["identity"]


@pytest.mark.parametrize("damage", ["outer_context", "missing_split", "missing_m20", "stop_inner_alias", "original_in_search"])
def test_full0_search_rejects_incomplete_or_cross_scope_inputs(inputs, tmp_path, monkeypatch, damage):
    context = unfitted_context(inputs, tmp_path, monkeypatch, "COXTIME_SET_A")
    if damage == "outer_context":
        context["source"]["context"] = 1
    elif damage == "missing_split":
        context["inner_partitions"].pop()
    elif damage == "missing_m20":
        context["completed"]["STOP_R1_K1_ANALYSIS"].pop()
    elif damage == "stop_inner_alias":
        context["completed"]["STOP_R1_K1_ANALYSIS"] = context["completed"]["INNER_R1_K1_ANALYSIS"]
    else:
        context["mice_specs"]["FULL_ANALYSIS"]["view"]["analysis_ids"] = context["original_evaluation_ids"]
    with pytest.raises(ContractError, match="FULL_PIPELINE_(SEARCH|SELECTOR)_"):
        f4._materialize_full_pipeline_search_partitions(context, tmp_path.resolve() / "rejected")


def test_full0_spec_uses_original_program_and_explicit_bootstrap_scope(inputs, tmp_path, monkeypatch):
    context = unfitted_context(inputs, tmp_path, monkeypatch, "COXTIME_SET_A")
    registered = f4._materialize_full_pipeline_search_partitions(context, tmp_path.resolve() / "search")
    lock = {"selected_parents": ["AST_ALT"], "common_set_epv": 15}
    seta = {"source": {k: v for k, v in context["source"].items() if k != "context"},
            "lock": lock, "lock_sha256": sha256_bytes(canonical_json_bytes(lock))}
    spec = f4._full_pipeline_complex_search_spec(context, seta, registered)
    science = f4.load_science_authority()["science"]["f2_model_development"]
    assert spec["execution_scope"] == "F4_FULL_PIPELINE_SEARCH" and spec["fold"] == 0
    assert spec["candidate_trials"] == {"S1": science["coxtime"]["candidates"], "S2": []}
    assert spec["multifidelity"] == science["multifidelity"] and spec["trial_scoring"] == science["trial_scoring"]
    assert spec["horizons"] == list(range(37))
    assert spec["monthly_fit_horizons"] == list(range(1, 37))
    assert spec["backend"] == "CPU" and spec["execution_mode"] == "INLINE"
    assert spec["threads"] == spec["pool_workers"] == spec["engine_threads"] == 1
    seeds = f2_kernel._full_pipeline_search_seed_registry(spec, True, 1)
    assert len(seeds["trials"]) == 60 and seeds["trials"][0]["seed"] == 760010001
    seta["source"]["bootstrap_replicate"] = 2
    with pytest.raises(ContractError, match="SEARCH_SETA_SOURCE_INVALID"):
        f4._full_pipeline_complex_search_spec(context, seta, registered)
