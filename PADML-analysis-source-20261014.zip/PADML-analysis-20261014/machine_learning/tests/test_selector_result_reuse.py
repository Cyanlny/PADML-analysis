from __future__ import annotations

import copy
from unittest.mock import Mock

import pytest

from padml import capsule, f2_kernel, f2_validation, run, worker
from padml._science_authority import load_science_authority
from padml.bundle import ContractError, canonical_json_bytes, sha256_bytes
from padml.f2 import materialize_requests


UNIT = "selector-f1-elastic-net-cox"


def digest(value):
    return sha256_bytes(canonical_json_bytes(value))


def seal(value):
    return {**value, "identity": digest({key: item for key, item in value.items() if key != "identity"})}


@pytest.fixture
def result_binding():
    previous = materialize_requests(run_id="f2-result-old", source_identity="1" * 64,
        runtime_identity="2" * 64, worker_identity="3" * 64, input_identity="4" * 64)[UNIT]
    request = materialize_requests(run_id="f2-result-new", source_identity="5" * 64,
        runtime_identity="6" * 64, worker_identity="7" * 64, input_identity="4" * 64)[UNIT]
    model_input = {"identity": "8" * 64, "fold": 1}
    value = {"family": "ELASTIC_NET_COX", "fold": 1, "model_input": model_input,
        "selector_evidence": {"selected_parents": ["AST_ALT", "X"],
                              "sensitivity_evidence": {"mrmre": ["X"], "boruta": ["AST_ALT"]}},
        "search_trace": {"grid": [1, 2, 3]}, "predictions": [[.9, .8]],
        "selected_spec": {"lambda": [.2, .3]}, "stopping_and_convergence": [20],
        "primary_reuse": {"source_identity": "9" * 64, "current_elastic_fit_count": 0},
        "science_contract_sha256": "a" * 64,
        "registered_partition_execution": seal({"partitions": [
            {"kind": "INNER", "ibs_0_24": .15, "metric_qc": {"ok": True}},
            {"kind": "OUTER", "ibs_0_24": .1, "metric_set_sha256": digest([.1]),
             "metric_qc": {"old": True}, "metric_prediction_seal_sha256": "b" * 64}]})}
    source = seal({"schema_version": "1.0.0", "kind": "PADML_F2_SELECTOR_RESULT_REUSE",
        "source_run_identity": "c" * 64, "source_capsule_sha256": "d" * 64,
        "source_request": previous, "model_input_identity": model_input["identity"],
        "source_result": {"object_key": f"v22/padml/science/{previous['run_id']}/F2/"
                                        f"{previous['transaction_id']}/{UNIT}/result.zip",
                          "sha256": "e" * 64, "size_bytes": 100},
        "preserved_value_sha256": digest(capsule.selector_result_projection(value))})
    return source, request, model_input, value


def test_complete_result_source_preserves_science_across_worker_runtime_changes(result_binding):
    source, request, model_input, _ = result_binding
    assert capsule.validate_selector_result_source(source, request, model_input) == source
    assert source["source_request"]["identities"]["runtime"] != request["identities"]["runtime"]


@pytest.mark.parametrize("damage", ["input", "seed", "authority", "model_input", "object_key", "size", "hash"])
def test_result_source_rejects_changed_science_or_ambiguous_object(result_binding, damage):
    source, request, model_input, _ = copy.deepcopy(result_binding)
    if damage in ("input", "authority"):
        source["source_request"]["identities"][damage] = "0" * 64
    elif damage == "seed":
        source["source_request"]["seed"] += 1
    elif damage == "model_input":
        source["model_input_identity"] = "0" * 64
    elif damage == "object_key":
        source["source_result"]["object_key"] = "v22/unrelated.zip"
    elif damage == "size":
        source["source_result"]["size_bytes"] = True
    else:
        source["preserved_value_sha256"] = "not-a-digest"
    source = seal(source)
    with pytest.raises(ContractError):
        capsule.validate_selector_result_source(source, request, model_input)


def test_rescoring_only_changes_outer_metrics_and_never_calls_any_fit(result_binding, monkeypatch):
    source, _, model_input, value = result_binding
    original = copy.deepcopy(value)
    metric = {"ibs_0_24": .2, "prediction_sha256": "b" * 64, "ipcw_qc": {"corrected": True}}
    replay = Mock(return_value=metric)
    monkeypatch.setattr(f2_validation, "_local_outer_metric", replay)
    fits = Mock(side_effect=AssertionError("REUSE_MUST_NOT_FIT"))
    for name in ("_run_r_registered_elastic", "_evaluate_elastic_alpha_phase",
                 "_run_r_prediction_batch", "_run_selector_sensitivity"):
        monkeypatch.setattr(f2_kernel, name, fits)
    actual = run._rescore_selector_result(value, source, model_input, {})
    assert value == original and replay.call_count == 1 and fits.call_count == 0
    assert capsule.selector_result_projection(actual) == capsule.selector_result_projection(value)
    assert actual["registered_partition_execution"]["partitions"][-1]["ibs_0_24"] == .2
    assert actual["registered_partition_execution"] == seal(actual["registered_partition_execution"])
    assert actual["result_reuse"] == capsule.result_reuse_receipt(source)
    assert actual["selector_evidence"]["sensitivity_evidence"] == original["selector_evidence"]["sensitivity_evidence"]
    assert actual["primary_reuse"] == original["primary_reuse"]


@pytest.mark.parametrize("damage", ["prediction", "lambda", "grid", "seta", "sensitivity", "inner_score", "prediction_seal", "receipt"])
def test_sole_validator_forbids_writeback_outside_outer_metric(result_binding, damage):
    source, request, model_input, value = copy.deepcopy(result_binding)
    value["result_reuse"] = capsule.result_reuse_receipt(source)
    if damage == "prediction":
        value["predictions"][0][0] = .5
    elif damage == "lambda":
        value["selected_spec"]["lambda"][0] *= 10
    elif damage == "grid":
        value["search_trace"]["grid"].pop()
    elif damage == "seta":
        value["selector_evidence"]["selected_parents"].pop()
    elif damage == "sensitivity":
        value["selector_evidence"]["sensitivity_evidence"]["mrmre"] = ["AST_ALT"]
    elif damage == "inner_score":
        value["registered_partition_execution"]["partitions"][0]["ibs_0_24"] = .3
    elif damage == "prediction_seal":
        value["registered_partition_execution"]["partitions"][1]["metric_prediction_seal_sha256"] = "0" * 64
    else:
        value["result_reuse"]["current_sensitivity_fit_count"] = False
    with pytest.raises(ContractError, match="REUSED_SELECTOR_WRITEBACK_FORBIDDEN"):
        f2_validation._validate_f2_model(request, value, load_science_authority(), {}, model_input, None,
                                       expected_selector_result=source)


def test_sole_validator_never_silently_normalizes_an_incorrect_outer_score(monkeypatch):
    metric = {"ibs_0_24": .2, "prediction_sha256": "b" * 64, "ipcw_qc": {"corrected": True}}
    monkeypatch.setattr(f2_validation, "_local_outer_metric", lambda *args: metric)
    wrong = {"ibs_0_24": .1, "metric_set_sha256": digest([.1]),
             "metric_prediction_seal_sha256": "b" * 64, "metric_qc": metric["ipcw_qc"]}
    with pytest.raises(ContractError, match="LOCAL_OUTER_METRIC_REPLAY_MISMATCH"):
        f2_validation._replay_local_outer_metric({}, 1, wrong, {}, {})
    assert wrong["ibs_0_24"] == .1


def test_complete_selector_reuse_cannot_fall_back_to_remote_fit(result_binding, monkeypatch, tmp_path):
    source, request, _, _ = result_binding
    cap = {"requests": {UNIT: request}, "manifest": {"selector_result_reuse": {UNIT: source}}}
    monkeypatch.setattr(worker, "load_capsule", lambda *args: cap)
    fit = Mock(side_effect=AssertionError("UNAUTHORIZED_SELECTOR_FIT"))
    monkeypatch.setattr(worker, "execute_model", fit)
    with pytest.raises(ContractError, match="SELECTOR_RESULT_REUSE_MUST_NOT_REFIT"):
        worker.execute(tmp_path / "capsule.zip", tmp_path / "common.zip", UNIT, tmp_path / "result.zip")
    assert fit.call_count == 0


def test_all_reuse_modes_are_mutually_exclusive(tmp_path):
    with pytest.raises(ContractError, match="SELECTOR_REUSE_MODE_CONFLICT"):
        run.prepare(tmp_path, "f2-result-conflict", selector_results_from=tmp_path,
                    selector_primary_from=tmp_path, host_effective_cpus=dict.fromkeys(run.HOSTS,32))
