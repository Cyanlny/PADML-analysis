"""Historical operational receipts through the original reader; no science."""
import copy
import os
from pathlib import Path

import pytest

from padml import f4, f5, runtime
from padml.bundle import ContractError, canonical_json_bytes, sha256_bytes


@pytest.mark.parametrize("budget", [None, 2147483648])
def test_1513_missing_or_recorded_budget_reaches_original_path_consumer(tmp_path, monkeypatch, budget):
    producer = Path(os.environ["PADML_SELECTOR_1513_SOURCE"])
    manifest = f4.load_f45_source_bundle(producer)
    members = {row["path"]: row["sha256"] for row in manifest["members"]}
    identity = sha256_bytes(canonical_json_bytes(members))
    assert identity == "1513ecba963857099c6b99413b8e976393c551a3ec30ed90da1cb14178338bd7"
    # Source proof has its own real-code tests. This counterexample isolates
    # the original historical schema/admission and direct-reader boundary.
    monkeypatch.setattr(f4, "_retained_full0_source_members", lambda *a, **k: members)
    monkeypatch.setattr(f5, "_nested_full_selector_partition_records", lambda rows: [{} for _ in rows])
    observation = {"effective_cpus": 32, "available_memory_bytes": 128 * 1024**3,
        "scratch_available_bytes": 128 * 1024**3, "scratch_root": str(tmp_path)}
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda root: observation)
    policy = {"configured_worker_ceiling": runtime.CPU_MINUS_8,
        "memory_bytes_per_worker": 1024**3, "memory_reserve_bytes": 0,
        "scratch_bytes_per_worker": 1024**2, "scratch_reserve_bytes": 0,
        "transfer_archive_worker_ceiling": 24}
    target = tmp_path / "coarse"
    target.mkdir()
    source = {"kind": "PADML_NESTED_FULL_DATA_SELECTOR_SOURCE_V1", "context": 0}
    partition = {"covariates": {"members": [{"size_bytes": 10}]},
        "fit_response": {"size_bytes": 10}, "evaluation_response": {"size_bytes": 10}}
    calls, refs = [], []
    raw = canonical_json_bytes({"UNFITTED": True})
    for i in range(320):
        task_id = f"UNFITTED-{i:03d}"
        calls.append(({"nested_source": source}, partition,
            {"task_id": task_id, "alphas": [0.1]}, str(target), "UNFITTED"))
        root = target / task_id
        (root / "native").mkdir(parents=True)
        (root / "native/spec.json").write_bytes(raw)
        (root / "path-result.json").write_bytes(raw)
        refs.append({"task_id": task_id, "path": task_id + "/path-result.json",
            "sha256": sha256_bytes(raw), "size_bytes": len(raw)})
    effective = f4._selector_phase_resource_policy(policy, calls, 64 * 1024**2,
        execution_worker_memory_bytes=budget, historical_execution=True)
    admission = runtime.resource_admission(effective, observation, legal_tasks=320)
    record = {"source": source, "source_identity": identity,
        "operational_identity": runtime.OPERATIONAL_IDENTITY, "phase": "coarse",
        "alphas": [0.1], "task_ids": [c[2]["task_id"] for c in calls],
        "resource_policy": policy, "effective_policy": effective,
        "resource_observation": observation, "resource_admission": admission,
        "retained_bytes_per_task": 64 * 1024**2,
        "pool": {"configured_worker_ceiling": admission["limits"]["configured"],
            "admitted_worker_ceiling": admission["admitted_worker_ceiling"],
            "runnable_task_count": 320, "actual_worker_process_peak": 1,
            "completed_task_count": 320, "engine_threads": 1, "status": "COMPLETED"}}
    if budget is not None:
        record["execution_worker_memory_bytes"] = budget
    path = target / "execution.json"
    def save(value):
        path.write_bytes(canonical_json_bytes([{"execution": value, "path_results": refs}]))
    seen = []
    monkeypatch.setattr(f4, "_consume_learning_selector_path",
        lambda call, **kwargs: seen.append(call[2]["task_id"]) or {"UNFITTED": True})
    save(record)
    original = path.read_bytes()
    produced, records = f4._consume_full_pipeline_selector_phase_batches(calls, target,
        resource_policy=policy, retained_full0_source_bundle=producer)
    assert len(produced) == len(set(seen)) == 320 and records[0]["execution"] == record
    assert path.read_bytes() == original
    for damage in ("null", "boolean", "negative", "admission", "source"):
        bad = copy.deepcopy(record)
        if damage in {"null", "boolean", "negative"}:
            bad["execution_worker_memory_bytes"] = {"null": None, "boolean": True, "negative": -1}[damage]
        elif damage == "admission":
            bad["effective_policy"]["memory_bytes_per_worker"] += 1
        else:
            bad["source_identity"] = "0" * 64
        save(bad)
        seen.clear()
        with pytest.raises(ContractError):
            f4._consume_full_pipeline_selector_phase_batches(calls, target,
                resource_policy=policy, retained_full0_source_bundle=producer)
        assert not seen

    # Reuse the same tiny UNFITTED worker files for the current marker and
    # gather-capacity boundary; no recipe, MICE or selector engine is entered.
    save(record)
    assert path.read_bytes() == original
    batch = tmp_path / "future-batch"
    target.rename(batch)
    future_effective = f4._selector_phase_resource_policy(policy, calls, record["retained_bytes_per_task"],
        execution_worker_memory_bytes=2 * 1024**3, execution_scratch_reserve_bytes=0)
    future_admission = runtime.resource_admission(future_effective, observation, legal_tasks=320)
    future = {**record,
        "source_identity": sha256_bytes(canonical_json_bytes(f4._f45_source_member_sha256())),
        "execution_worker_memory_bytes": 2 * 1024**3, "execution_scratch_reserve_bytes": 0,
        "effective_policy": future_effective, "resource_admission": future_admission,
        "pool": {**record["pool"], "admitted_worker_ceiling": future_admission["admitted_worker_ceiling"]}}
    future_records = [{"execution": future, "path_results": refs}]
    encoded = canonical_json_bytes(future_records)
    (batch / "execution.json").write_bytes(canonical_json_bytes(future))
    (batch / "path-results.json").write_bytes(canonical_json_bytes(refs))
    numerical_bytes = sum((batch / row["path"]).stat().st_size
        + (batch / row["task_id"] / "native/spec.json").stat().st_size for row in refs)
    pending = 3 * numerical_bytes + len(encoded) + 128 * 1024**2
    seen.clear()
    with monkeypatch.context() as limited:
        limited.setattr(runtime, "observe_execution_resources", lambda root: {
            **observation, "scratch_available_bytes": pending - 1, "scratch_root": str(root)})
        with pytest.raises(ContractError, match="NESTED_SELECTOR_PHASE_ACTUAL_SPACE_INSUFFICIENT"):
            f4._consume_full_pipeline_selector_phase_batches(calls, target,
                resource_policy=policy, batches=[batch])
    assert not seen and not target.exists()
    with monkeypatch.context() as exact:
        exact.setattr(runtime, "observe_execution_resources", lambda root: {
            **observation, "scratch_available_bytes": pending, "scratch_root": str(root)})
        produced, records = f4._consume_full_pipeline_selector_phase_batches(calls, target,
            resource_policy=policy, batches=[batch])
    assert len(produced) == len(set(seen)) == 320 and records == future_records
    assert (target / "execution.json").read_bytes() == encoded
    assert future["execution_scratch_reserve_bytes"] == future_effective["scratch_reserve_bytes"] == 0
    assert policy["scratch_reserve_bytes"] == 0 and "execution_scratch_reserve_bytes" not in record
