"""One authorized, attributable failed FPM fit; never a formal F2 result.

Uses the original capsule, accepted model values, immutable F1 cache and native
task compiler. The R observer only retains inputs, warnings and any completed
fit. It does not muffle warnings, change numerical controls or retry.
"""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
from time import monotonic

from padml import f2_kernel as kernel
from padml._science_authority import selected_route_profiles
from padml.bundle import canonical_json_bytes, read_safe_zip, sha256_bytes, sha256_file, strict_json_bytes, write_deterministic_zip
from padml.capsule import load_capsule
from padml.f2 import canonical_unit_ids
from padml.runtime import R_LIBRARY, THREAD_ENV


TASK_ID = "CENTER::F2::FPM_TVC_SET_A::RANK_1::M20"
ATOMIC_ID = TASK_ID + "::P04::M01"


def observer_source(source: str) -> str:
    """Add evidence writes to the unchanged FPM warning/fit path only."""
    replacements = {
        '    fit <- withCallingHandlers(\n      stpm2(formula, data = frame,':
        '    saveRDS(list(train_design = train_design, test_design = test_design,\n'
        '      time = time, event = event, formula = formula, spec = spec),\n'
        '      file.path(Sys.getenv("PADML_FPM_EVIDENCE_DIR"), "fit-input.rds"))\n'
        '    fit <- withCallingHandlers(\n      stpm2(formula, data = frame,',
        '        stop("F2_FPM_FIT_WARNING: ", conditionMessage(condition), call. = FALSE)':
        '        saveRDS(list(message = conditionMessage(condition),\n'
        '          class = class(condition), call = conditionCall(condition),\n'
        '          calls = sys.calls(), session = sessionInfo()),\n'
        '          file.path(Sys.getenv("PADML_FPM_EVIDENCE_DIR"), "fit-warning.rds"))\n'
        '        stop("F2_FPM_FIT_WARNING: ", conditionMessage(condition), call. = FALSE)',
        '    health <- validate_fpm_fit_health(fit, 0L, spec$fpm$set_a_df)':
        '    saveRDS(fit, file.path(Sys.getenv("PADML_FPM_EVIDENCE_DIR"), "fit.rds"))\n'
        '    health <- validate_fpm_fit_health(fit, 0L, spec$fpm$set_a_df)',
    }
    for before, after in replacements.items():
        kernel._require(source.count(before) == 1, "FPM_REPRO_OBSERVER_ANCHOR_INVALID")
        source = source.replace(before, after)
    return source


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("run_root", type=Path)
    parser.add_argument("capsule", type=Path)
    parser.add_argument("output_root", type=Path)
    parser.add_argument("--candidate-library", type=Path)
    case = parser.add_mutually_exclusive_group()
    case.add_argument("--sample-size", action="store_true")
    case.add_argument("--center-health", action="store_true")
    case.add_argument("--sample-health", action="store_true")
    parser.add_argument("--failure-log", type=Path)
    args = parser.parse_args()
    sample = args.sample_size or args.sample_health
    component = "LOCKED_MODEL_SAMPLE_SIZE_DIAGNOSTIC" if sample else "CENTER_BLOCKED_STRESS"
    unit = "p2c2t-locked-model-sample-size-diagnostic" if sample else "p2c2t-center-blocked-stress"
    task_id = "SAMPLE_SIZE::F4::FPM_TVC_SET_A::SEED_1::FRACTION_0.80" if args.sample_size else TASK_ID
    atomic_id = task_id + "::P01::M11" if args.sample_size else ATOMIC_ID
    fold, imputation = (4, 11) if args.sample_size else (2, 1)
    registry_index, task_seed, fit_seed = (314, 427102, 428113) if args.sample_size else (19, 413101, 417102)
    center_index, center_id = 3, 52
    sample_seed_ordinal, sample_fraction = 1, .8
    if args.sample_health:
        task_id = "SAMPLE_SIZE::F3::FPM_TVC_SET_A::SEED_2::FRACTION_0.60"
        atomic_id = task_id + "::P01::M09"
        fold, imputation = 3, 9
        registry_index, task_seed, fit_seed = 233, 420202, 421211
        sample_seed_ordinal, sample_fraction = 2, .6
    if args.center_health:
        task_id = "CENTER::F5::FPM_TVC_SET_A::RANK_1::M20"
        atomic_id = task_id + "::P03::M20"
        fold, imputation = 5, 20
        registry_index, task_seed, fit_seed = 52, 434101, 437121
        center_index, center_id = 2, 39
    if sample or args.center_health:
        import re
        kernel._require(args.failure_log is not None, "FPM_REPRO_FAILURE_LOG_REQUIRED")
        failure = args.failure_log.read_text()
        process_ids = [int(value) for value in re.findall(r"SpawnProcess-(\d+)", failure)]
        minimum, maximum, child, reason = (4369, 4424, 50, "F2_FPM_FIT_WARNING") if args.sample_size else (729, 784, 59, "F2_FPM_FIT_HEALTH_INVALID")
        if args.sample_health:
            minimum, maximum, child, reason = 3249, 3304, 28, "F2_FPM_FIT_HEALTH_INVALID"
        kernel._require(
            process_ids and min(process_ids) == minimum and max(process_ids) == maximum
            and f"BOUNDED_SPAWN_CHILD_FAILED:{child}:ContractError:{reason}" in failure,
            "FPM_REPRO_FAILURE_COORDINATE_UNPROVEN",
        )
        # Windows contain four canonical tasks and use 56 persistent workers;
        # each sample task has 20 fits, each center-stress task has 5 x 20.
        fits_per_task = 20 if sample else 100
        kernel._require((minimum - 1) // 56 * 4 + child // fits_per_task == registry_index,
                        "FPM_REPRO_FAILURE_COORDINATE_UNPROVEN")
    root = args.output_root
    kernel._require(root.is_absolute() and root.parent.is_dir() and not root.exists(), "FPM_REPRO_TARGET_INVALID")
    root.mkdir(mode=0o700)
    os.environ.update(THREAD_ENV)
    candidate = args.candidate_library
    kernel._require(candidate is None or (candidate.is_absolute() and candidate.is_dir()), "FPM_VERIFICATION_LIBRARY_INVALID")
    os.environ["R_LIBS_USER"] = (str(candidate) + ":" if candidate else "") + R_LIBRARY
    started = monotonic()
    report = {"kind": "F2_P2C2T_FIXED_FPM_REPRODUCTION", "scientific_acceptance": False,
              "task_id": atomic_id, "fold": fold, "imputation": imputation,
              "component": component,
              "grid_runs": 0, "mice_runs": 0, "model_engine_calls": 0}
    if candidate:
        report["kind"] = "F2_P2C2T_FIXED_FPM_REPAIR_VERIFICATION"
        report["candidate_library"] = str(candidate)
    original_run = kernel.subprocess.run
    observer = Path(__file__).with_name("f2_model_development-observer.R")
    repo_root = Path(kernel.__file__).resolve().parent

    def observed_run(command, *positional, **keywords):
        if isinstance(command, list) and len(command) == 3 and command[1] == str(repo_root / "kernels/f2_model_development.R"):
            spec = strict_json_bytes(Path(command[2]).read_bytes())
            if spec.get("action") == "MODEL_PREDICTION_BATCH":
                kernel._require(report["model_engine_calls"] == 0
                                and len(spec.get("producer_tasks", [])) == 1
                                and spec["producer_tasks"][0]["task_id"] == atomic_id,
                                "FPM_REPRO_ONE_FIXED_FIT_ONLY")
                report["model_engine_calls"] += 1
                (root / "engine-spec.json").write_bytes(canonical_json_bytes(spec))
                command = [command[0], str(observer), command[2]]
                keywords["env"] = {**keywords.get("env", os.environ), "PADML_FPM_EVIDENCE_DIR": str(root)}
                completed = original_run(command, *positional, **keywords)
                (root / "engine.stdout.txt").write_text(completed.stdout)
                (root / "engine.stderr.txt").write_text(completed.stderr)
                report["engine_returncode"] = completed.returncode
                return completed
        return original_run(command, *positional, **keywords)

    try:
        kernel._require(observer.read_text() == observer_source((repo_root / "kernels/f2_model_development.R").read_text()),
                        "FPM_REPRO_OBSERVER_SOURCE_DRIFT")
        report["original_kernel_sha256"] = sha256_file(Path(kernel.__file__))
        report["original_r_sha256"] = sha256_file(repo_root / "kernels/f2_model_development.R")
        report["observer_sha256"] = sha256_file(observer)
        capsule = load_capsule(args.capsule, args.run_root / "common-input.zip")
        request = capsule["requests"][unit]
        binding, response, _ = kernel.admitted_f1_frozen_data(args.capsule, capsule, root)
        cache = args.run_root / "split-cache" / kernel._sha({
            "source": request["identities"]["source"],
            "input": request["identities"]["input"],
            "fold": fold,
            "binding_contract_sha256": kernel._sha(binding),
            "response_sha256": sha256_bytes(response),
        })
        kernel._require((cache / "cache.json").is_file(), "FPM_REPRO_EXISTING_CACHE_REQUIRED")
        values = []
        for unit in canonical_unit_ids()[:42]:
            entries = read_safe_zip(args.run_root / "results-p2c2t-mixed-final" / f"{unit}.zip")
            manifest = strict_json_bytes(entries["manifest.json"])
            values.append(strict_json_bytes(entries[manifest["artifacts"][0]["relative_path"]]))
        science = capsule["authority_slice"]["science"]
        registry = kernel.compile_p2c2t_registry(component, values, request,
            science["f2_model_development"]["p2c2t_contract"], science["f2_model_development"]["coxtime"])
        task = next(row for row in registry["tasks"] if row["task_id"] == task_id)
        kernel._require(registry["tasks"].index(task) == registry_index
                        and task["seed"] == task_seed, "FPM_REPRO_COORDINATE_DRIFT")
        model = next(row for row in values if row["fold"] == fold and row["family"] == "FPM_TVC_SET_A")
        _, registered, _, _ = kernel._cached_fold_assets(args.capsule, capsule, request, fold,
            binding, response, args.run_root / "split-cache")
        predictors = kernel.predictor_contract(repo_root, capsule["authority_slice"])
        kernel.subprocess.run = observed_run
        recipes = None
        if sample:
            matches = [row for row in binding["registry"]["sample_size"]
                       if row["outer_fold"] == fold and row["seed_ordinal"] == sample_seed_ordinal
                       and row["fraction"] == sample_fraction]
            kernel._require(len(matches) == 1, "FPM_REPRO_SAMPLE_REGISTRY_INVALID")
            registered = kernel._p2c2t_sample_registered_partition(
                registered, sample_ids=list(matches[0]["sample_ids"]), response_csv=response,
                task=task, destination=root/"sample-partition")
        else:
            partitions = sorted(registered["diagnostic_partitions"], key=lambda row: row["validation_center"])
            kernel._require(partitions[center_index]["validation_center"] == center_id, "FPM_REPRO_CENTER_DRIFT")
            recipes = kernel._compile_transform_recipes({"predictors": predictors}, registered,
                [row["partition_id"] for row in partitions], root, repo_root, expected_count=5)
        plan = kernel._p2c2t_registered_task_result(task={**task, "component": component},
            contract_task=task, model=model, registered=registered, science=science, predictors=predictors,
            scratch=root, repo_root=repo_root, route_record=selected_route_profiles()[kernel._FAMILY_ROUTE_KEYS["FPM_TVC_SET_A"]],
            center_recipe_set=recipes, atomic_job_plan=True, pool_workers=56)
        job = next(row for row in plan["jobs"] if row["atomic_task_id"] == atomic_id)
        kernel._require(job["fit_task"]["seed"] == fit_seed, "FPM_REPRO_SEED_DRIFT")
        (root / "fixed-task.json").write_bytes(canonical_json_bytes(job["fit_task"]))
        result = kernel._run_p2c2t_atomic_pool_task(job)
        (root / "consumer-result.json").write_bytes(canonical_json_bytes(result))
        report["status"] = "FIXED_FIT_AND_CONSUMER_PASSED"
    except Exception as exc:
        report.update(status="REPRODUCED_FAILURE" if report["model_engine_calls"] else "FAILED_BEFORE_FIT",
                      error_type=type(exc).__name__, reason=str(exc))
    finally:
        kernel.subprocess.run = original_run
    report["elapsed_seconds"] = round(monotonic() - started, 3)
    (root / "report.json").write_bytes(canonical_json_bytes(report))
    archive = root.with_suffix(".zip")
    kernel._require(not archive.exists(), "FPM_REPRO_ARCHIVE_EXISTS")
    write_deterministic_zip(archive, {path.relative_to(root).as_posix(): path.read_bytes()
                                    for path in root.rglob("*") if path.is_file()})
    print(json.dumps({**report, "archive": str(archive), "archive_sha256": sha256_file(archive),
                      "archive_size_bytes": archive.stat().st_size}), flush=True)


if __name__ == "__main__":
    main()
