// Test-only access to the actual compiled gbm Cox implementation.
#include <Rcpp.h>
#include <memory>
#define private public
#include "coxph.h"
#undef private

// [[Rcpp::export]]
Rcpp::List gbm_cox_probe(Rcpp::NumericVector times, Rcpp::NumericVector events,
                       Rcpp::NumericVector eta, Rcpp::NumericVector weights,
                       Rcpp::LogicalVector bag, Rcpp::IntegerVector nodes,
                       Rcpp::NumericVector adjustment, double step) {
    const unsigned long n = times.size();
    if (!n || events.size()!=n || eta.size()!=n || weights.size()!=n ||
        bag.size()!=n || nodes.size()!=n || adjustment.size()!=n)
        Rcpp::stop("probe shape mismatch");
    unsigned long k_count = 0;
    auto included = std::make_unique<bool[]>(n);
    std::vector<unsigned long> assignment(n);
    double out_events = 0.0;
    for (unsigned long i=0; i<n; ++i) {
        if (i && times[i]>times[i-1]) Rcpp::stop("probe times must decrease");
        if (nodes[i]<0) Rcpp::stop("probe node index invalid");
        included[i] = bag[i];
        assignment[i] = nodes[i];
        k_count = std::max(k_count, assignment[i]+1);
        if (!included[i]) out_events += weights[i]*events[i];
    }
    Rcpp::NumericVector z(n, 0.0);
    CCoxPH engine;
    engine.ComputeWorkingResponse(times.begin(), events.begin(), NULL, eta.begin(),
        z.begin(), weights.begin(), included.get(), n, 0);
    const double deviance = engine.Deviance(times.begin(), events.begin(), NULL,
        weights.begin(), eta.begin(), n, 0);
    Rcpp::RObject improvement = R_NilValue;
    if (out_events>0) improvement = Rcpp::wrap(engine.BagImprovement(
        times.begin(), events.begin(), NULL, weights.begin(), eta.begin(),
        adjustment.begin(), included.get(), step, n));
    VEC_P_NODETERMINAL terms(k_count);
    std::vector<std::unique_ptr<CNodeTerminal>> storage;
    for (unsigned long k=0; k<k_count; ++k) {
        storage.emplace_back(new CNodeTerminal());
        terms[k] = storage.back().get();
        terms[k]->cN = 0;
        for (unsigned long i=0; i<n; ++i)
            if (included[i] && assignment[i]==k) terms[k]->cN++;
        if (!terms[k]->cN) Rcpp::stop("probe has empty in-bag node");
    }
    engine.FitBestConstant(times.begin(), events.begin(), NULL, weights.begin(),
        eta.begin(), z.begin(), assignment.data(), n, terms, k_count, 1,
        included.get(), adjustment.begin(), 0);
    Rcpp::NumericVector updates(k_count);
    Rcpp::NumericMatrix inverse(k_count-1, k_count-1);
    for (unsigned long k=0; k<k_count; ++k) updates[k]=terms[k]->dPrediction;
    for (unsigned long k=0; k<k_count-1; ++k)
        for (unsigned long m=0; m<k_count-1; ++m) {
            double value; bool success;
            engine.matH.getvalue(k,m,value,success);
            if (!success) Rcpp::stop("probe Hessian cell missing");
            inverse(k,m)=value;
        }
    return Rcpp::List::create(Rcpp::Named("response")=z,
        Rcpp::Named("deviance")=deviance,
        Rcpp::Named("oob_improvement")=improvement,
        Rcpp::Named("leaf_gradient")=engine.vecdG,
        Rcpp::Named("leaf_hessian_inverse")=inverse,
        Rcpp::Named("leaf_update")=updates);
}
