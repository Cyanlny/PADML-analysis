"""Non-accepting M1 real-data verification; never emits a formal F2 result.

Use one frozen S1 candidate at its fixed upper budget, not a search or a selected
lock. The full production grid, M20 stopping and M20 x 15 confirmation still run
only in the formal model units. Existing selector/F1 bytes are read-only.
"""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import tempfile
from time import monotonic

from padml import f2_kernel as kernel
from padml.bundle import ContractError, canonical_json_bytes, sha256_bytes, sha256_file
from padml.capsule import load_capsule, load_selector_primary
from padml.runtime import R_LIBRARY, THREAD_ENV


def summarize_prediction(matrix, np):
    value = np.asarray(matrix, dtype=float)
    kernel._require(value.ndim == 2 and value.shape[1] == 36 and len(value) > 0
                    and bool(np.isfinite(value).all() and (value >= 0).all() and (value <= 1).all())
                    and bool((np.diff(value, axis=1) <= 1e-10).all()),
                    "F2_REPRESENTATIVE_PREDICTION_INVALID")
    return {"rows": len(value), "horizons": 36, "minimum": float(value.min()),
            "maximum": float(value.max()), "finite": True, "monotone": True}


def verify(run_root: Path, fold: int, scratch: Path, report: dict) -> None:
    os.environ.update(THREAD_ENV)
    os.environ["R_LIBS_USER"] = R_LIBRARY
    import numpy as np
    import pandas as pd
    import xgboost as xgb
    import torch
    import torchtuples as tt
    from pycox import models

    capsule_path = run_root/"capsule.zip"
    capsule = load_capsule(capsule_path, run_root/"common-input.zip")
    selector_id = f"selector-f{fold}-elastic-net-cox"
    primary_source = capsule["manifest"]["selector_primary_reuse"][selector_id]
    primary = load_selector_primary(run_root/"selector-primary"/f"{selector_id}.zip",
        primary_source, capsule["requests"][selector_id], capsule["approved_registry"]["model_inputs"][fold-1])
    selector = primary["selector_evidence"]
    request = capsule["requests"][f"model-f{fold}-cox-ph"]
    binding, response, frozen_lineage = kernel.admitted_f1_frozen_data(capsule_path, capsule, scratch)
    expected_cache = run_root/"split-cache"/kernel._sha({
        "source": request["identities"]["source"],
        "input": request["identities"]["input"],
        "fold": fold,
        "binding_contract_sha256": kernel._sha(binding),
        "response_sha256": sha256_bytes(response),
    })
    kernel._require((expected_cache/"cache.json").is_file(), "F2_REPRESENTATIVE_EXISTING_CACHE_REQUIRED")
    _, registered, lineage, _ = kernel._cached_fold_assets(
        capsule_path, capsule, request, fold, binding, response, run_root/"split-cache")
    lineage = {**lineage, **frozen_lineage, "f1_registered_partition_identity": registered["identity"]}
    kernel._require(registered["identity"] == capsule["approved_registry"]["model_inputs"][fold-1]["registered_input_identity"],
                    "F2_REPRESENTATIVE_INPUT_MISMATCH")
    outer = next(row for row in registered["partitions"] if row["kind"] == "OUTER")
    inner = next(row for row in registered["partitions"] if row["kind"] == "INNER"
                 and row["repeat"] == row["inner_fold"] == 1)
    stop = next(row for row in registered["partitions"] if row["kind"] == "STOP"
                and row["repeat"] == row["inner_fold"] == 1)
    report.update(kernel_sha256=sha256_file(Path(kernel.__file__)),
                  f1_input_identity=request["identities"]["input"],
                  selected_parent_sha256=kernel._sha(selector["selected_parents"]),
                  imputation=1, production_grid_runs=0, production_locks_selected=0)
    repo_root = Path(kernel.__file__).parent
    routes = [("COX_PH", "cox-ph"), ("GBM_COX", "gbm-cox"),
              ("XGBOOST_COX", "xgboost-cox"), ("COXTIME_SET_A", "coxtime-set-a"),
              ("FPM_TVC_SET_A", "fpm-tvc-set-a")]
    for family, slug in routes:
        report["current_family"] = family
        started = monotonic()
        spec = kernel.compile_model_spec(capsule["requests"][f"model-f{fold}-{slug}"],
                                         capsule, lineage, repo_root, primary)
        kernel._require(spec["pool_workers"] == 24 and spec["engine_threads"] == 1,
                        "F2_REPRESENTATIVE_PARALLELISM_DRIFT")
        family_root = scratch/family
        family_root.mkdir()
        row = {"family": family, "imputation": 1, "pool_workers": 24, "engine_threads": 1}
        if family in {"COX_PH", "FPM_TVC_SET_A", "GBM_COX"}:
            parameters = {}
            if family == "GBM_COX":
                candidate = spec["candidate_trials"]["S1"][0]
                parameters = kernel._engine_parameters(family, candidate["parameters"])
                row["candidate_id"] = candidate["trial_id"]
                curve_task = {"task_id": "VERIFY_STOP_M01", "partition_id": stop["partition_id"],
                    "imputation": 1, "family": family, "producer_kind": "GBM_STOP_CURVE",
                    "selected_parents": selector["selected_parents"], "parameters": parameters,
                    "seed": spec["seed"] + 102}
                curve = kernel._run_r_prediction_batch(spec, registered, [curve_task], family_root, repo_root)[0]
                row["stop_curve_sha256"] = curve["sealed_risk_curve"]["sha256"]
                row["verified_tree_cap"] = parameters["max_trees"]
                parameters = {**parameters, "locked_trees": parameters["max_trees"]}
            tasks = []
            for partition in ([inner, outer] if family == "COX_PH" else [outer]):
                tasks.append({"task_id": f"VERIFY_{partition['kind']}_M01", "partition_id": partition["partition_id"],
                    "imputation": 1, "family": family, "selected_parents": selector["selected_parents"],
                    "parameters": parameters, "prediction_horizons": spec["monthly_fit_horizons"],
                    "transform_recipe": None if family == "GBM_COX" else kernel._recipe_by_partition(selector["recipe_set"],partition["partition_id"]),
                    "seed": spec["seed"] + 1 + partition["repeat"]*100 + partition["inner_fold"]})
            produced = kernel._run_r_prediction_batch(spec, registered, tasks, family_root, repo_root)
            row["fits"] = [{"partition_id": item["partition_id"], "fit_health": item["stopping"],
                            **summarize_prediction(item["sealed_prediction"]["payload"]["survival"], np)} for item in produced]
        else:
            fit = kernel._load_python_registered_partition(spec, registered, outer["partition_id"], pd, np, [1])
            stopping = kernel._load_python_registered_partition(spec, registered, stop["partition_id"], pd, np, [1])
            partition = kernel._response_free_stop_partition(stopping["partition"])
            if family == "XGBOOST_COX":
                candidate = spec["candidate_trials"]["S1"][0]
                parameters = kernel._engine_parameters(family, candidate["parameters"])
                seal, _ = kernel._xgb_prediction_function_seal(xgb, parameters, partition,
                    stopping["fit_designs"][0], stopping["evaluation_designs"][0], stopping["fit_time"], stopping["fit_event"],
                    spec["seed"]+102, "CPU", np, family_root/"handoff"/"booster.ubj")
                result = kernel._xgb_refit_predict(xgb, parameters, fit["fit_designs"][0], fit["fit_time"], fit["fit_event"],
                    fit["evaluation_designs"][0], parameters["max_nrounds"], spec["seed"]+1, "CPU", spec["monthly_fit_horizons"], np)
                row.update(candidate_id=candidate["trial_id"], verified_round_cap=parameters["max_nrounds"])
            else:
                candidate = spec["coxtime"]["candidates"][0]
                seal, _ = kernel._coxtime_prediction_function_seal((models, torch, tt), candidate, partition,
                    stopping["fit_designs"][0], stopping["fit_time"], stopping["fit_event"], stopping["evaluation_designs"][0],
                    spec["seed"]+102, "CPU", np, family_root/"handoff"/"network.pt")
                result = kernel._coxtime_refit_predict((models, torch, tt), candidate,
                    fit["fit_designs"][0], fit["fit_time"], fit["fit_event"], fit["evaluation_designs"][0],
                    300, spec["seed"]+1, "CPU", spec["monthly_fit_horizons"], np)
                row.update(candidate_id=candidate["candidate_id"], verified_epoch_cap=300)
            row.update(stop_function_sha256=seal["sha256"], fit_health=result["fit_health"],
                       **summarize_prediction(result["survival"], np))
        row.update(status="NUMERIC_QC_PASSED", seconds=round(monotonic()-started, 3))
        report["families"].append(row)
    report.pop("current_family")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("run_root", type=Path)
    parser.add_argument("fold", type=int, choices=range(1, 7))
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    report = {"kind": "F2_REPRESENTATIVE_NUMERICAL_VERIFICATION", "scientific_acceptance": False,
              "fold": args.fold, "families": [], "status": "STARTED"}
    kernel._require(args.output.is_absolute() and args.output.parent.is_dir() and not args.output.exists(),
                    "F2_REPRESENTATIVE_OUTPUT_INVALID")
    try:
        with tempfile.TemporaryDirectory(prefix="representative-fit-", dir=args.output.parent) as temporary:
            verify(args.run_root.resolve(strict=True), args.fold, Path(temporary), report)
        report["status"] = "NUMERIC_QC_PASSED"
    except Exception as exc:
        report.update(status="NUMERIC_QC_FAILED", error_type=type(exc).__name__,
                      reason=str(exc) if isinstance(exc, ContractError) else "UNCLASSIFIED_EXECUTION_ERROR")
    with args.output.open("xb") as handle:
        handle.write(canonical_json_bytes(report))
    print(json.dumps({key: report[key] for key in ("kind", "status", "fold", "scientific_acceptance")}))
    if report["status"] != "NUMERIC_QC_PASSED":
        raise SystemExit(1)


if __name__ == "__main__":
    main()
