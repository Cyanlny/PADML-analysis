from __future__ import annotations

import math
import json
import os
from pathlib import Path
import shutil
import subprocess

import pytest

from padml.bundle import ContractError, canonical_json_bytes, sha256_bytes
from padml.f2_kernel import (
    _center_stratified_evaluation_context,
    _censoring_survival_step,
    _evaluate_prediction_seal,
    _monthly_prediction_seal,
    _response_rows,
    _r_prediction_child_spec,
    _seal_prediction_matrix,
    _selection_horizon_from_spec,
    _rank_trials,
    _tree_s3a_candidates,
    _trial_evaluation_summary,
    _trial_scoring_context,
    _write_response_subset,
)
from padml.f2_validation import _trial_projection, _validate_p2c2t_partition_metrics


def _response(ids: list[str], times: list[float], events: list[int]) -> dict:
    raw = (
        "Patient_ID,All_Cause_Death,Death_Followup_months\n"
        + "".join(
            f"{patient_id},{event},{time}\n"
            for patient_id, time, event in zip(ids, times, events, strict=True)
        )
    ).encode()
    fields, rows = _response_rows(raw)
    return _write_response_subset(fields, rows, ids, None)


def _constant_prediction(ids: list[str], value: float) -> dict:
    return _seal_prediction_matrix(ids, [[value] * 36 for _ in ids], list(range(1, 37)))


def test_ibs_integrates_monthly_brier_and_rejects_three_point_average() -> None:
    ids = [f"p{i}" for i in range(40)]
    response = _response(ids, [50.0] * 40, [1] * 40)
    sealed = _monthly_prediction_seal(_constant_prediction(ids, 0.5))
    metric = _evaluate_prediction_seal(
        sealed,
        fit_response=response,
        evaluation_response=response,
        evaluation_context=_center_stratified_evaluation_context(response, ids, ["36"] * 40),
    )
    # BS(0)=0 and BS(1..24)=1/4, so the first trapezoid has half weight.
    assert metric["ibs_0_24"] == (0.125 + 23 * 0.25) / 24
    assert metric["ibs_0_24"] != 0.25
    assert metric["ipcw_qc"]["metric_estimable"] is True
    sparse = _seal_prediction_matrix(ids, [[0.5] * 4 for _ in ids], [6, 12, 24, 36])
    with pytest.raises(ContractError, match="F2_EVALUATION_PREDICTION_INVALID"):
        _evaluate_prediction_seal(sparse, fit_response=response, evaluation_response=response)


def test_center_ipcw_cached_weights_match_independent_graf_reference() -> None:
    ids = [f"p{i}" for i in range(100)]
    centers = ["36"] * 50 + ["38"] * 50
    times = [8.0] * 5 + [12.0] * 5 + [40.0] * 40 + [6.0] * 10 + [18.0] * 5 + [50.0] * 35
    events = [0] * 5 + [1] * 5 + [1] * 40 + [0] * 10 + [1] * 5 + [1] * 35
    response = _response(ids, times, events)
    matrix = [[1.0] + [math.exp(-month * (0.008 + index / 20000)) for month in range(1, 37)] for index in range(100)]
    sealed = _seal_prediction_matrix(ids, matrix, list(range(37)))
    context = _center_stratified_evaluation_context(response, ids, centers)

    def g(center: str, query: float, left: bool) -> float:
        subset = [(time, event) for time, event, value in zip(times, events, centers, strict=True) if value == center]
        survival = 1.0
        for point in sorted({time for time, _ in subset}):
            if point > query or (left and point == query):
                break
            risk = sum(time >= point for time, _ in subset)
            deaths = sum(time == point and event == 1 for time, event in subset)
            censored = sum(time == point and event == 0 for time, event in subset)
            if censored:
                survival *= (risk - deaths - censored) / (risk - deaths)
        return survival

    brier = []
    for month in range(25):
        terms = []
        for index, (time, event, center) in enumerate(zip(times, events, centers, strict=True)):
            if time <= month and event:
                weight = 1 / g(center, time, True)
            elif time > month:
                weight = 1 / g(center, month, False)
            else:
                weight = 0.0
            terms.append(weight * (float(time > month) - matrix[index][month]) ** 2)
        brier.append(math.fsum(terms) / len(ids))
    expected = math.fsum((a + b) / 2 for a, b in zip(brier, brier[1:])) / 24
    observed = _evaluate_prediction_seal(sealed, fit_response=response, evaluation_response=response, evaluation_context=context)
    assert observed["ibs_0_24"] == expected
    assert context["ipcw_qc"]["maximum_weight"] == pytest.approx(1.25)


def _repeat_fixture(tmp_path: Path) -> tuple[list[dict], list[dict]]:
    partitions = []
    evaluated = []
    training_ids = [f"fit{i}" for i in range(40)]
    training = _response(training_ids, [50.0] * 40, [1] * 40)
    for fold in range(1, 6):
        ids = [f"k{fold}p{i}" for i in range(8)]
        response = _response(ids, [50.0] * 8, [1] * 8)
        root = tmp_path / f"k{fold}"
        root.mkdir()
        (root / "imp01.csv").write_text("Patient_ID,Center\n" + "".join(f"{patient_id},36\n" for patient_id in ids))
        partition = {
            "kind": "INNER", "partition_id": f"R1K{fold}", "repeat": 1,
            "inner_fold": fold, "fit_response": training,
            "evaluation_response": response, "evaluation_ids": ids,
            "covariates": {"input_dir": str(root)},
        }
        partitions.append(partition)
        for imputation, value in enumerate((0.0, 0.0, 1.0, 1.0, 0.5), start=1):
            sealed = _constant_prediction(ids, value)
            metric = _evaluate_prediction_seal(_monthly_prediction_seal(sealed), fit_response=training, evaluation_response=response)
            evaluated.append({
                "partition_id": partition["partition_id"], "imputation": imputation,
                "sealed_prediction": sealed, "ibs_0_24": metric["ibs_0_24"],
            })
    return partitions, evaluated


def test_trial_ranking_pools_mi_then_complete_repeat_oof(tmp_path: Path) -> None:
    partitions, evaluated = _repeat_fixture(tmp_path)
    context = _trial_scoring_context(partitions)
    summary = _trial_evaluation_summary(evaluated, context, 5)
    expected = (0.125 + 23 * 0.25) / 24
    assert summary["evaluation_units"] == 25
    assert summary["ranking_evaluation_count"] == 1
    assert summary["ranking_metric_values"] == [expected]
    assert summary["fold_metric_values"] == [expected] * 5
    assert summary["mean_ibs"] != math.fsum(summary["metric_values"]) / 25
    row = {"candidate_id": "trial", "parameters": {}, "parameter_sha256": "a" * 64, **summary}
    assert _trial_projection([row])[0]["candidate_id"] == "trial"
    with pytest.raises(ContractError, match="F2_TRIAL_TRACE_INVALID"):
        _trial_projection([{**row, "mean_ibs": math.fsum(summary["metric_values"]) / 25}])
    with pytest.raises(ContractError, match="F2_TRIAL_MI_DENOMINATOR_INVALID"):
        _trial_evaluation_summary(evaluated[:-1], context, 5)
    with pytest.raises(ContractError, match="F2_REPEAT_OOF_INCOMPLETE"):
        _trial_scoring_context(partitions[:-1])


def test_h36_excludes_training_only_center_from_complete_oof_not_fit(tmp_path: Path) -> None:
    from padml import f2_kernel as k
    partitions, _ = _repeat_fixture(tmp_path)
    for p in partitions:
        ids = p["evaluation_ids"]
        p["evaluation_response"] = _response(ids, [32.8] + [50.] * 7, [0] + [1] * 7)
        (Path(p["covariates"]["input_dir"]) / "imp01.csv").write_text(
            "Patient_ID,Center\n" + "".join(f"{pid},{'55' if i == 0 else '36'}\n" for i, pid in enumerate(ids)))
    original_fits = [dict(p["fit_response"]) for p in partitions]
    h36, h24 = _trial_scoring_context(partitions, selection_horizon_months=36), _trial_scoring_context(partitions)
    assert h36["ranking_groups"][0]["context"]["ipcw_qc"]["evaluation_count"] == 35
    assert h24["ranking_groups"][0]["context"]["ipcw_qc"]["evaluation_count"] == 40
    assert [p["fit_response"] for p in partitions] == original_fits
    p = partitions[0]
    assert k._development_evaluation_indices({**p, "kind": "OUTER"}, 36) is None
    ids, fit_ids = p["evaluation_ids"], [f"fit{i}" for i in range(40)]
    sealed = k._seal_cox_risk_curve(fit_ids, ids, [[i * .01] * 3 for i in range(40)],
        [[i * .02] * 3 for i in range(8)], 3)
    context = k._grouped_cox_evaluation_context(p["fit_response"], p["evaluation_response"], fit_ids, ids,
        evaluation_indices=k._development_evaluation_indices(p, 36))
    assert len(context["fit_times"]) == 40 and sum(context["fit_events"]) == 40
    actual = k._grouped_cox_loss_path(sealed, fit_response=p["fit_response"],
        evaluation_response=p["evaluation_response"], evaluation_context=context)
    expected_response = _response(ids[1:], [50.] * 7, [1] * 7)
    expected_seal = k._seal_cox_risk_curve(fit_ids, ids[1:], sealed["matrices"][0],
        [[i * .02] * 3 for i in range(1, 8)], 3)
    expected = k._grouped_cox_loss_path(expected_seal, fit_response=p["fit_response"],
        evaluation_response=expected_response)
    assert actual["validation_n"] == 7 and actual["losses"] == expected["losses"]
    assert sealed["payload"]["evaluation_ids"] == ids


def test_s3a_promotes_only_repeat2_m5_candidates() -> None:
    def row(name: str, score: float) -> dict:
        return {"candidate_id": name, "mean_ibs": score, "maximum_ibs": score, "parameter_sha256": name}
    trace = {
        "S1": [row("misleading-low-fidelity", 0.001)],
        "S2": [row("a", 0.11), row("b", 0.12), row("c", 0.13), row("d", 0.14)],
    }
    assert [item["candidate_id"] for item in _tree_s3a_candidates(trace)] == ["a", "b", "c"]


def test_twelve_month_ibs_has_own_support_grid_and_normalization() -> None:
    ids = [f"p{i}" for i in range(40)]
    response = _response(ids, [20.0] * 40, [0] * 40)
    context = _center_stratified_evaluation_context(response, ids, ["36"] * 40,
        selection_horizon_months=12)
    assert len(context["ipcw_weights"]) == len(context["evaluation_truth"]) == 13
    sealed = _monthly_prediction_seal(_constant_prediction(ids, 0.5))
    metric = _evaluate_prediction_seal(sealed, fit_response=response, evaluation_response=response,
        evaluation_context=context, selection_horizon_months=12)
    assert metric["ibs_0_12"] == (0.125 + 11 * 0.25) / 12
    assert "ibs_0_24" not in metric and metric["ipcw_qc"]["metric_estimable"]
    with pytest.raises(ContractError, match="F2_PRIMARY_IBS_NOT_ESTIMABLE"):
        _center_stratified_evaluation_context(response, ids, ["36"] * 40)
    with pytest.raises(ContractError, match="F2_EVALUATION_CONTEXT_HORIZON_MISMATCH"):
        _evaluate_prediction_seal(sealed, fit_response=response, evaluation_response=response,
            evaluation_context=context)
    altered = _seal_prediction_matrix(ids,
        [[1.0] + [0.5] * 12 + [0.1] * 24 for _ in ids], list(range(37)))
    assert _evaluate_prediction_seal(altered, fit_response=response, evaluation_response=response,
        evaluation_context=context, selection_horizon_months=12)["ibs_0_12"] == metric["ibs_0_12"]


def test_twelve_month_m5_pooled_scoring_changes_original_s3a_promotion(tmp_path: Path) -> None:
    partitions, _ = _repeat_fixture(tmp_path)
    curves = {"a": [0.9] * 12 + [0.1] * 24,
              "b": [0.6] * 36, "c": [0.5] * 36, "d": [0.4] * 36}
    traces = {}
    all_evaluated = {}
    for horizon in (12, 24):
        context = _trial_scoring_context(partitions, selection_horizon_months=horizon)
        traces[horizon] = []
        for name, curve in curves.items():
            evaluated = []
            for partition in partitions:
                sealed = _seal_prediction_matrix(partition["evaluation_ids"],
                    [curve for _ in partition["evaluation_ids"]], list(range(1, 37)))
                metric = _evaluate_prediction_seal(_monthly_prediction_seal(sealed),
                    fit_response=partition["fit_response"], evaluation_response=partition["evaluation_response"],
                    selection_horizon_months=horizon)
                evaluated.extend({"partition_id": partition["partition_id"], "imputation": mi,
                    "sealed_prediction": sealed, f"ibs_0_{horizon}": metric[f"ibs_0_{horizon}"]}
                    for mi in range(1, 6))
            all_evaluated[horizon] = evaluated
            summary = _trial_evaluation_summary(evaluated, context, 5)
            assert summary["evaluation_units"] == 25 and summary["ranking_evaluation_count"] == 1
            traces[horizon].append({"candidate_id": name, "parameter_sha256": name, **summary})
    assert [row["candidate_id"] for row in _tree_s3a_candidates({"S2": traces[12]})] == ["a", "b", "c"]
    assert [row["candidate_id"] for row in _tree_s3a_candidates({"S2": traces[24]})] == ["b", "c", "d"]
    with pytest.raises(ContractError, match="F2_TRIAL_RANKING_HORIZON_MISMATCH"):
        _rank_trials([traces[12][0], traces[24][1]])
    with pytest.raises(ContractError, match="F2_TRIAL_EVALUATION_HORIZON_MISMATCH"):
        _trial_evaluation_summary(all_evaluated[24],
            _trial_scoring_context(partitions, selection_horizon_months=12), 5)


def test_explicit_selection_horizon_requires_matching_original_trial_contract() -> None:
    from padml._science_authority import load_science_authority
    original = load_science_authority()["science"]["f2_model_development"]["trial_scoring"]
    assert _selection_horizon_from_spec({}) == 24
    assert _selection_horizon_from_spec({"trial_scoring": original}) == 24
    twelve = {**original, "ibs_grid_months": list(range(13)), "ibs_integration": "TRAPEZOID_DIVIDE_BY_12"}
    assert _selection_horizon_from_spec({"selection_horizon_months": 12, "trial_scoring": twelve}) == 12
    for spec in ({"trial_scoring": twelve}, {"selection_horizon_months": 12},
                 {"selection_horizon_months": 12, "trial_scoring": original}):
        with pytest.raises(ContractError, match="F2_SELECTION_SCORING_CONTRACT_MISMATCH"):
            _selection_horizon_from_spec(spec)
    with pytest.raises(ContractError, match="F2_SELECTION_HORIZON_INVALID"):
        _selection_horizon_from_spec({"selection_horizon_months": True})


def test_r_child_projection_preserves_legacy_and_explicit_selection_contract() -> None:
    from padml._science_authority import load_science_authority
    base = {"schema_version": "1.0.0", "fold": 0, "family": "RSF", "seed": 300000,
            "outcome": "All_Cause_Death", "time": "Death_Followup_months",
            "horizons": list(range(1, 37)), "heldout_center": None,
            "predictors": {}, "fpm": {}, "selector_from_dependency": None}
    original = _r_prediction_child_spec(base)
    assert "selection_horizon_months" not in original and "trial_scoring" not in original
    explicit = _r_prediction_child_spec({**base, "selection_horizon_months": 24})
    assert explicit == {**original, "selection_horizon_months": 24}
    scoring = load_science_authority()["science"]["f2_model_development"]["trial_scoring"]
    for horizon in (12, 24):
        contract = {**scoring, "ibs_grid_months": list(range(horizon + 1)),
                    "ibs_integration": f"TRAPEZOID_DIVIDE_BY_{horizon}"}
        child = _r_prediction_child_spec({**base, "selection_horizon_months": horizon,
                                         "trial_scoring": contract})
        assert child == {**original, "selection_horizon_months": horizon, "trial_scoring": contract}
        assert _selection_horizon_from_spec(child) == horizon
    with pytest.raises(ContractError, match="F2_SELECTION_SCORING_CONTRACT_MISMATCH"):
        _r_prediction_child_spec({**base, "selection_horizon_months": 12})


def test_formal_ipcw_rejects_nonestimable_population() -> None:
    ids = [f"p{i}" for i in range(20)]
    response = _response(ids, [50.0] * 20, [1] * 20)
    with pytest.raises(ContractError, match="F2_PRIMARY_IBS_NOT_ESTIMABLE"):
        _center_stratified_evaluation_context(response, ids, ["36"] * 20)


@pytest.mark.parametrize("times,events", [
    ([1.0]*40+[50.0]*60, [1]*20+[0]*80),
    ([1.0, 2.0, 3.0, 4.0], [1, 0, 1, 0]),
    ([1.0]*100, [0]*100),
])
def test_reverse_km_ties_match_independent_native_prodlim(times, events):
    rscript = shutil.which("Rscript")
    assert rscript is not None, "Native R reference is required"
    native = subprocess.run([rscript, "-e", r'''
suppressPackageStartupMessages({library(prodlim); library(jsonlite)})
x <- fromJSON(Sys.getenv("PADML_KM_FIXTURE"))
fit <- prodlim(Hist(time,event)~1, data=data.frame(time=x$time,event=x$event), reverse=TRUE)
cat(toJSON(list(time=fit$time, survival=fit$surv), digits=NA))
'''], env={**os.environ, "PADML_KM_FIXTURE": json.dumps({"time": times, "event": events})},
        capture_output=True, text=True, timeout=30)
    assert native.returncode == 0, native.stdout+native.stderr
    reference = json.loads(native.stdout)
    observed = _censoring_survival_step(times, events)
    assert [row[0] for row in observed] == reference["time"]
    assert [row[1] for row in observed] == pytest.approx(reference["survival"], abs=1e-15)


def test_tied_censoring_brier_and_f4_shared_score_are_exact():
    from padml.f4 import censoring_context
    ids = [f"p{i}" for i in range(100)]
    response = _response(ids, [1.0]*40+[50.0]*60, [1]*20+[0]*80)
    context = _center_stratified_evaluation_context(response, ids, ["36"]*100)
    weights = context["ipcw_weights"][1]
    assert weights == [1.0]*20+[0.0]*20+[4/3]*60
    brier = math.fsum(w*(y-.8)**2 for w,y in zip(weights,context["evaluation_truth"][1],strict=True))/100
    assert brier == pytest.approx(.160, abs=1e-15)
    assert brier != pytest.approx(.158, abs=1e-15)
    downstream = censoring_context(ids,["36"]*100,response)
    assert downstream["rows"][1]["ghat_right_by_center"] == {"36": .75}
    assert downstream["rows"][1]["minimum_g"] == context["ipcw_qc"]["minimum_g"] == .75


@pytest.mark.parametrize("center_count", [1, 2])
def test_required_center_month_support_cannot_be_hidden_by_earlier_death_weights(center_count):
    ids = [f"p{i}" for i in range(100*center_count)]
    response = _response(ids, [1.0]*40+[2.0]*60+([50.0]*100 if center_count==2 else []),
                         [1]*40+[0]*60+([1]*100 if center_count==2 else []))
    centers = ["36"]*100+(["38"]*100 if center_count==2 else [])
    with pytest.raises(ContractError, match="F2_PRIMARY_IBS_NOT_ESTIMABLE"):
        _center_stratified_evaluation_context(response, ids, centers)
    from padml.f4 import censoring_context
    rows = censoring_context(ids,centers,response)["rows"]
    assert rows[2]["status"] == "NOT_ESTIMABLE" and rows[2]["minimum_g"] == 0


def test_complete_observed_outcomes_remain_estimable_after_last_death():
    ids = [f"p{i}" for i in range(100)]
    response = _response(ids, [1.0]*100, [1]*100)
    context = _center_stratified_evaluation_context(response, ids, ["36"]*100)
    assert context["ipcw_qc"]["metric_estimable"] is True
    assert context["ipcw_qc"]["minimum_g"] == 1
    assert context["ipcw_weights"][24] == [1.0]*100


@pytest.mark.parametrize("bad", [math.nan, math.inf, -math.inf])
def test_censoring_km_rejects_nonfinite_original_times(bad):
    with pytest.raises(ContractError, match="RESPONSE_DOMAIN_INVALID"):
        _censoring_survival_step([1.0, bad], [1, 0])


@pytest.mark.parametrize("fpm", [False, True])
def test_p2c2t_validator_uses_pooled_metric_not_imputation_mean(tmp_path: Path, monkeypatch, fpm) -> None:
    partitions, evaluated = _repeat_fixture(tmp_path)
    summary = _trial_evaluation_summary(evaluated, _trial_scoring_context(partitions), 5)
    by_partition = {row["partition_id"]: row for row in partitions}
    metrics = [
        {
            "partition_id": row["partition_id"],
            "imputation": row["imputation"],
            "prediction_seal_sha256": row["sealed_prediction"]["sha256"],
            "evaluation_response_sha256": by_partition[row["partition_id"]]["evaluation_response"]["sha256"],
            "ibs_0_24": row["ibs_0_24"],
        }
        for row in evaluated
    ]
    result = {
        "component": "LOCAL_PERTURBATION",
        "partition_metrics": metrics,
        "partition_metrics_sha256": sha256_bytes(canonical_json_bytes(metrics)),
        "pooled_metric_values": summary["ranking_metric_values"],
        "pooled_metric_qc": summary["ranking_metric_qc"],
        "mean_ibs": summary["mean_ibs"],
        "maximum_ibs": summary["maximum_ibs"],
    }
    expected = [
        {"partition_id": row["partition_id"], "evaluation_response_sha256": row["evaluation_response"]["sha256"]}
        for row in partitions
    ]
    kwargs = {"imputation_count": 5, "expected_partitions": expected}
    checked = []
    if fpm:
        # Test only the handoff to the existing mathematical evidence consumer;
        # real retained-fit regressions test that consumer without another fit.
        from padml import f2_validation
        monkeypatch.setattr(f2_validation, "_validate_fpm_fit_evidence",
                            lambda value, df, count: checked.append((value, df, count)))
        stopping = {"coefficient_count": 23, "converged": True, "covariance_rank": 23,
                    "df": 3, "engine": "rstpm2::stpm2", "fit_evidence": {"handoff_fixture": True},
                    "optimizer": "optim", "optimizer_convergence": 0, "tvc_df": 1, "warning_count": 0}
        for metric in metrics:
            metric["stopping"] = stopping
        result["partition_metrics_sha256"] = sha256_bytes(canonical_json_bytes(metrics))
        result["stopping_sha256"] = sha256_bytes(canonical_json_bytes([stopping] * len(metrics)))
        kwargs["fpm_coefficient_count"] = 23
    _validate_p2c2t_partition_metrics(result, **kwargs)
    if fpm:
        assert checked == [(stopping["fit_evidence"], [3, 1], 23)] * len(metrics)
        with pytest.raises(ContractError, match="F2_P2C2T_STOPPING_IDENTITY_INVALID"):
            _validate_p2c2t_partition_metrics({**result, "stopping_sha256": "0" * 64}, **kwargs)
        with pytest.raises(ContractError, match="F2_FPM_FIT_HEALTH_INVALID"):
            _validate_p2c2t_partition_metrics(result, **{**kwargs, "fpm_coefficient_count": 22})
        missing = [{key: value for key, value in metric.items() if key != "stopping"} for metric in metrics]
        with pytest.raises(ContractError, match="F2_P2C2T_PARTITION_METRIC_RECONSTRUCTION_INVALID"):
            _validate_p2c2t_partition_metrics({**result, "partition_metrics": missing,
                "partition_metrics_sha256": sha256_bytes(canonical_json_bytes(missing))}, **kwargs)
    with pytest.raises(ContractError, match="F2_P2C2T_PARTITION_METRIC_RECONSTRUCTION_INVALID"):
        _validate_p2c2t_partition_metrics(
            {**result, "mean_ibs": math.fsum(summary["metric_values"]) / 25},
            **kwargs,
        )
