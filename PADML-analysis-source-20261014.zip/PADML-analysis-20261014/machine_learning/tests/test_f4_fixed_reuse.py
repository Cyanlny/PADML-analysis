"""Retained fixed-F4 wiring: synthetic rows only; no native metrics or fits."""

import copy

import pytest

from padml import f4
from padml.bundle import ContractError, canonical_json_bytes, read_safe_zip, sha256_bytes, strict_json_bytes, write_deterministic_zip
from test_f4 import a15_macro, bootstrap_population, response, selection_capability_evidence


@pytest.fixture(autouse=True)
def forbid_native(monkeypatch):
    def forbidden(*a, **k):
        raise AssertionError("NO_NATIVE_OR_SCIENTIFIC_EXECUTION_IN_THIS_TEST")
    monkeypatch.setattr(f4.subprocess, "run", forbidden)
    monkeypatch.setattr(f4, "_bounded_ordered_spawn", forbidden)
    monkeypatch.setattr(f4, "native_metrics", forbidden)
    monkeypatch.setattr(f4, "evaluate_f4_suite", forbidden)


def inputs_fixture():
    ids, centers = bootstrap_population()
    families = list(f4.FAMILY_COMPLEXITY)
    handoff = {"patient_ids": ids, "centers": centers, "horizons": f4.HORIZONS,
               "survival": {family: [[1.0] + [0.8] * 36 for _ in ids] for family in families}}
    raw = response(ids, [50] * len(ids), [1] * len(ids))["private_bytes"]
    return {"handoff": handoff, "response_csv": raw, "selection_capabilities": selection_capability_evidence(),
            "source": {"f1_identity": sha256_bytes(b"UNFITTED_F1")}}


def supported(value):
    details = [] if value is not None else [{"scope": "36", "horizon": 24,
                                            "ipcw_qc": {"horizon": 24}, "reasons": ["CASES_BELOW_20"]}]
    return {"status": "ESTIMABLE" if value is not None else "NOT_ESTIMABLE", "value": value, "support": details}


@pytest.mark.parametrize("matching,drift", [(6, None), (3, None), (6, "source"), (6, "evaluation"), (6, "matrix_loco")])
def test_o_fit_selection_uses_actual_stability_lock_without_bootstraps(monkeypatch, tmp_path, matching, drift):
    inputs = inputs_fixture()
    macro = a15_macro()
    for family in macro:
        macro[family]["24"]["equal_center_ibs"] = 0.1 if family == "RSF" else 0.2
    evaluation = {"macro": macro}
    capabilities = f4._seal_f4_selection_capabilities(inputs["selection_capabilities"])
    decision = f4.select_a15(macro, {row["family"]: True for row in capabilities})
    matrix = {"stability": {"matching_replicates": matching, "total_replicates": 6,
                            "threshold": 4, "review_required": matching < 4,
                            "status": "PASS" if matching >= 4 else "SELECTION_UNSTABLE_REVIEW_REQUIRED"}}
    suite = {"kind": "PADML_F4_COMPLETE_FIXED_PREDICTION_SUITE_V1", "execution_scope": "FORMAL",
             "prospective_protocol_revision": f4.PROSPECTIVE_PROTOCOL_REVISION,
             "source": inputs["source"], "selection_capability_seals": capabilities,
             "evaluation": evaluation, "family_decision": decision, "matrix_loco": matrix}
    changed = copy.deepcopy(suite)
    if drift == "source":
        changed["source"]["f1_identity"] = "b" * 64
    elif drift == "evaluation":
        changed["evaluation"]["macro"]["RSF"]["24"]["equal_center_ibs"] += 0.01
    elif drift == "matrix_loco":
        changed["matrix_loco"]["stability"]["matching_replicates"] -= 1
    source = tmp_path / "fixed-selection.zip"
    write_deterministic_zip(source, {"f4-suite.json": canonical_json_bytes(changed)})
    calls = []
    def point(handoff, response_csv):
        assert handoff is inputs["handoff"] and response_csv == inputs["response_csv"]
        calls.append("point")
        return evaluation
    def loco(handoff, response_csv, point, status):
        assert point is evaluation and all(status.values())
        calls.append("loco")
        return matrix
    monkeypatch.setattr(f4, "evaluate_predictions", point)
    monkeypatch.setattr(f4, "a15_fixed_ooc_matrix_loco", loco)
    if drift:
        with pytest.raises(ContractError, match="SELECTION_(SOURCE|REPLAY)_MISMATCH"):
            f4._load_o_fit_selection(source, inputs)
    else:
        lock = f4._load_o_fit_selection(source, inputs)
        assert lock["locked_family"] == ("RSF" if matching >= 4 else "ELASTIC_NET_COX")
    assert calls == ([] if drift == "source" else ["point", "loco"])


def retained_row(inputs, domain, replicate, indices):
    handoff, raw = inputs["handoff"], inputs["response_csv"]
    fixed = domain == "FIXED_MODEL_PAIRED"
    label = f"FIXED_MODEL_PAIRED-{replicate:04d}" if fixed else f"POST_SELECTION-{replicate:04d}-INBAG"
    _, _, receipt = f4.materialize_resampled_view(handoff, raw, indices, label)
    if fixed:
        metrics = {family: {"ibs_0_24": 0.1, "brier_24": 0.1, "uno_c_24": 0.7, "auc_24": 0.7}
                   for family in f4.FAMILY_COMPLEXITY}
        evidence = {family: {key: supported(value) for key, value in values.items()} for family, values in metrics.items()}
        return {"replicate": replicate, "receipt": receipt, "metrics": metrics, "metric_support": evidence,
                "descriptive_micro_metrics": copy.deepcopy(metrics), "descriptive_micro_metric_support": copy.deepcopy(evidence)}
    macro = a15_macro()
    decision = f4.select_a15(macro, {family: True for family in f4.FAMILY_COMPLEXITY})
    family = decision["selected_family"]
    oob = sorted(set(range(len(handoff["patient_ids"]))) - set(indices), key=lambda i: handoff["patient_ids"][i])
    base = {"replicate": replicate, "primary_estimand": "EQUAL_CENTER_MACRO", "descriptive_estimand": "POOLED_PATIENT_MICRO",
            "selected_family": family, "decision": decision, "inbag_receipt": receipt, "oob_patient_count": len(oob)}
    if not oob:
        return {**base, "status": "NOT_ESTIMABLE", "reason": "F4_POST_SELECTION_OOB_EMPTY",
                "statistical_support": [{"reason": "EMPTY_REGISTERED_OOB", "patient_count": 0}]}
    selected, _, oob_receipt = f4.materialize_resampled_view(
        {**handoff, "survival": {family: handoff["survival"][family]}}, raw, oob, f"POST_SELECTION-{replicate:04d}-OOB")
    missing = sorted(set(handoff["centers"]) - set(selected["centers"]))
    if missing:
        return {**base, "status": "NOT_ESTIMABLE", "reason": "F4_POST_SELECTION_OOB_CENTER_MISSING", "oob_receipt": oob_receipt,
                "statistical_support": [{"reason": "REGISTERED_OOB_CENTER_EMPTY", "missing_centers": missing}]}
    ibs = macro[family]["24"]["equal_center_ibs"]
    inbag_metrics, oob_metrics = {"ibs_0_24": ibs, "uno_c_24": 0.7}, {"ibs_0_24": ibs + 0.01, "uno_c_24": 0.68}
    return {**base, "status": "ESTIMABLE", "oob_receipt": oob_receipt,
            "inbag_metrics": inbag_metrics, "oob_metrics": oob_metrics,
            "optimism": {"ibs_0_24_oob_minus_inbag": oob_metrics["ibs_0_24"] - ibs,
                         "uno_c_24_inbag_minus_oob": -(oob_metrics["uno_c_24"] - 0.7)},
            "optimism_support": {field: {"inbag": supported(inbag_metrics[metric]), "oob": supported(oob_metrics[metric])}
                                 for metric, field in (("ibs_0_24", "ibs_0_24_oob_minus_inbag"), ("uno_c_24", "uno_c_24_inbag_minus_oob"))}}


def test_fixed_reuse_opens_all_2000_outputs_without_rerun(monkeypatch, tmp_path):
    inputs = inputs_fixture()
    indices = [i for start in range(0, 24, 4) for i in (start, start, start + 1, start + 1)]
    source = tmp_path / "fixed.zip"
    work = source.with_name(source.name + ".work")
    work.mkdir()
    suite = {"status": "COMPUTED_AWAITING_REVIEW", "stage_acceptance": False, "replicate_count": 1000,
             "o_fit_rows": None, "source": {"o_fit_aggregate": None},
             "selection_capability_seals": f4._seal_f4_selection_capabilities(inputs["selection_capabilities"])}
    plans = {}
    original_hash = f4.sha256_file
    monkeypatch.setattr(f4, "sha256_file", lambda path: "e" * 64 if path == f4.Path(f4.__file__) else original_hash(path))
    for field, directory, domain, reducer in (
        ("fixed_model_paired_bootstrap", "fixed-model", "FIXED_MODEL_PAIRED", f4._reduce_fixed_model_bootstrap),
        ("post_selection_bootstrap", "post-selection", "POST_SELECTION_INBAG_OOB", f4._reduce_post_selection_bootstrap),
    ):
        plan = {"domain": domain, "root_seed": f4.BOOTSTRAP_ROOTS[domain], "replicate_count": 1000,
                "rng": "UNFITTED_RNG_FIXTURE", "draws": [indices] * 1000}
        plans[domain] = plan
        capabilities = None if directory == "fixed-model" else {family: True for family in f4.FAMILY_COMPLEXITY}
        retain = f4._retain_bootstrap_results(work / directory, plan, inputs["handoff"], inputs["response_csv"], capabilities)
        rows = []
        for replicate in range(1, 1001):
            row = retained_row(inputs, domain, replicate, indices)
            scratch = work / directory / f"replicate-{replicate:04d}"
            scratch.mkdir()
            names = ["metrics.zip"] if directory == "fixed-model" else ["inbag-metrics.zip", "oob-metrics.zip"]
            for name in names:
                write_deterministic_zip(scratch / name, {"UNFITTED.json": canonical_json_bytes({
                    "domain": domain, "replicate": replicate, "member": name})})
            retain(replicate - 1, row)
            rows.append(row)
        suite[field] = reducer(plan, rows)
    monkeypatch.setattr(f4, "sha256_file", original_hash)
    write_deterministic_zip(source, {"f4-suite.json": canonical_json_bytes(suite)})
    monkeypatch.setattr(f4, "_load_o_fit_selection", lambda *a: {"locked_family": "RSF"})
    calls = []
    def plan_only(ids, centers, domain, **kwargs):
        assert ids == inputs["handoff"]["patient_ids"] and centers == inputs["handoff"]["centers"]
        assert kwargs["replicate_count"] == 1000
        calls.append(domain)
        return plans[domain]
    monkeypatch.setattr(f4, "bootstrap_draws", plan_only)
    native_calls = []
    def replay(item, *, handoff, response_csv, replay_metrics, capability_status=None, patient_count=None):
        replicate, draws = item
        domain = "FIXED_MODEL_PAIRED" if capability_status is None else "POST_SELECTION_INBAG_OOB"
        assert handoff is inputs["handoff"] and response_csv == inputs["response_csv"] and draws == indices
        expected = {"metrics.zip"} if capability_status is None else {"inbag-metrics.zip", "oob-metrics.zip"}
        assert set(replay_metrics) == expected
        for member, raw in replay_metrics.items():
            assert read_safe_zip(raw) == {"UNFITTED.json": canonical_json_bytes({
                "domain": domain, "replicate": replicate, "member": member})}
        native_calls.append((domain, replicate))
        return retained_row(inputs, domain, replicate, draws)
    monkeypatch.setattr(f4, "_fixed_model_bootstrap_replicate", replay)
    monkeypatch.setattr(f4, "_post_selection_bootstrap_replicate", replay)
    assert f4._reuse_f4_fixed_result(source, inputs) == suite
    assert calls == ["FIXED_MODEL_PAIRED", "POST_SELECTION_INBAG_OOB"]
    assert len(native_calls) == len(set(native_calls)) == 2000
    # A byte-resealed wrong draw cannot pass merely because the suite is intact.
    path = work / "fixed-model/replicate-0001.zip"
    entries = read_safe_zip(path)
    item = strict_json_bytes(entries["input.json"])
    item["draw_indices"] = list(reversed(item["draw_indices"]))
    forged = tmp_path / "wrong-draw.zip"
    write_deterministic_zip(forged, {**entries, "input.json": canonical_json_bytes(item)})
    forged.replace(path)
    with pytest.raises(ContractError, match="FIXED_REUSE_INPUT_MISMATCH"):
        f4._reuse_f4_fixed_result(source, inputs)
    path.rename(path.with_suffix(".retained-negative"))
    with pytest.raises(ContractError, match="FIXED_REUSE_EVIDENCE_MISSING"):
        f4._reuse_f4_fixed_result(source, inputs)


@pytest.mark.parametrize("variant", ["ESTIMABLE", "EMPTY", "CENTER_MISSING", "A15_NA", "METRIC_NA"])
def test_retained_post_branches_and_support_cannot_hide_numerical_error(variant):
    inputs = inputs_fixture()
    indices = list(range(24)) if variant == "EMPTY" else [i for start in range(0, 24, 4) for i in (start, start, start + 1, start + 1)]
    if variant == "CENTER_MISSING":
        indices[:4] = [0, 1, 2, 3]
    row = retained_row(inputs, "POST_SELECTION_INBAG_OOB", 1, indices)
    if variant == "A15_NA":
        for key in ("decision", "selected_family", "oob_receipt", "optimism", "optimism_support", "inbag_metrics", "oob_metrics"):
            row.pop(key, None)
        row.update(status="NOT_ESTIMABLE", reason="F4_A15_REQUIRED_METRIC_NOT_ESTIMABLE",
                   statistical_support=[{"family": "RSF", "metric": "pooled_uno_c", "support": supported(None)["support"]}])
    if variant == "METRIC_NA":
        row["oob_metrics"]["uno_c_24"] = None
        row["optimism"]["uno_c_24_inbag_minus_oob"] = None
        row["optimism_support"]["uno_c_24_inbag_minus_oob"]["oob"] = supported(None)
        row["status"] = "NOT_ESTIMABLE"
    capability = {family: True for family in f4.FAMILY_COMPLEXITY}
    f4._validate_retained_bootstrap_row(row, indices, inputs, "POST_SELECTION_INBAG_OOB", capability)
    bad = copy.deepcopy(row)
    if variant == "A15_NA":
        bad["statistical_support"][0]["support"][0]["reasons"] = ["NUMERICAL_FAILURE"]
    elif variant == "METRIC_NA":
        bad["optimism_support"]["uno_c_24_inbag_minus_oob"]["oob"]["support"] = []
    elif variant == "ESTIMABLE":
        bad["optimism"]["ibs_0_24_oob_minus_inbag"] *= -1
    else:
        bad["statistical_support"] = []
    with pytest.raises(ContractError):
        f4._validate_retained_bootstrap_row(bad, indices, inputs, "POST_SELECTION_INBAG_OOB", capability)


def test_retained_fixed_missing_value_requires_original_support():
    inputs = inputs_fixture()
    indices = list(range(24))
    row = retained_row(inputs, "FIXED_MODEL_PAIRED", 1, indices)
    row["metrics"]["RSF"]["ibs_0_24"] = None
    row["metric_support"]["RSF"]["ibs_0_24"] = supported(None)
    f4._validate_retained_bootstrap_row(row, indices, inputs, "FIXED_MODEL_PAIRED", None)
    row["metric_support"]["RSF"]["ibs_0_24"]["support"] = []
    with pytest.raises(ContractError, match="SUPPORT_INVALID"):
        f4._validate_retained_bootstrap_row(row, indices, inputs, "FIXED_MODEL_PAIRED", None)


def test_attach_o_fit_uses_retained_result_and_never_evaluates_again(monkeypatch, tmp_path):
    inputs = {"o_fit_source": {"UNFITTED": True}, "source": {"UNFITTED_SOURCE": True}}
    monkeypatch.setattr(f4, "load_f4_inputs", lambda *a, **k: inputs)
    aggregate = tmp_path / "aggregate.zip"
    aggregate.write_bytes(b"UNFITTED_AGGREGATE")
    rows = [{"UNFITTED_ROW": True}]
    monkeypatch.setattr(f4, "load_o_fit_aggregate_archive", lambda *a, **k: {"rows": rows, "identity_sha256": "a" * 64})
    fixed = tmp_path / "fixed.zip"
    suite = {"status": "COMPUTED_AWAITING_REVIEW", "stage_acceptance": False,
             "evaluation": {}, "family_decision": {}, "matrix_loco": {}, "post_selection_bootstrap": {"retained": 1000},
             "registered_learning_curve_rows": None, "full_pipeline_bootstrap_result": None}
    calls = []
    def reuse(path, actual):
        assert path == fixed and actual is inputs
        calls.append("retained")
        return copy.deepcopy(suite)
    monkeypatch.setattr(f4, "_reuse_f4_fixed_result", reuse)
    monkeypatch.setattr(f4, "_full_pipeline_bootstrap_status", lambda *a, **k: {"status": "BLOCKED", "missing": "LEARNING"})
    result = tmp_path / "attached.zip"
    observed = f4.execute(tmp_path, result, f4.compile_f45_execution_contract_seal(), fixed_result=fixed, o_fit_aggregate=aggregate)
    assert calls == ["retained"] and observed["stage_acceptance"] is False
    attached = strict_json_bytes(read_safe_zip(result)["f4-suite.json"])
    assert attached["post_selection_bootstrap"] == suite["post_selection_bootstrap"]
    assert attached["o_fit_rows"] == rows and attached["full_pipeline_bootstrap"]["status"] == "BLOCKED"
    with pytest.raises(ContractError, match="REQUIRES_FIXED_RESULT"):
        f4.execute(tmp_path, tmp_path / "forbidden.zip", f4.compile_f45_execution_contract_seal(), o_fit_aggregate=aggregate)


def test_attach_learning_forwards_native_execution_and_never_repeats_b1000(monkeypatch, tmp_path):
    """UNFITTED native leaves; real assembly/ZIP bytes and source binding."""
    inputs = {"o_fit_source": {"UNFITTED": True}, "source": {"UNFITTED_SOURCE": True}}
    calls = []
    def load(path, **kwargs):
        assert path == tmp_path and kwargs == {"include_o_fit_source": True, "f1_runtime_root": None}
        calls.append("source")
        return inputs
    monkeypatch.setattr(f4, "load_f4_inputs", load)
    aggregate, learning = tmp_path / "o-fit.zip", tmp_path / "learning.zip"
    aggregate.write_bytes(b"UNFITTED_O_FIT")
    learning.write_bytes(b"UNFITTED_LEARNING")
    o_fit = {"rows": [{"UNFITTED_O_FIT_ROW": True}], "identity_sha256": "a" * 64}
    native = {"kind": "PADML_F4_LEARNING_AGGREGATE_NATIVE_SHARDS_V2", "rows": [{"UNFITTED_LEARNING_ROW": True}],
              "identity_sha256": "b" * 64}
    def o_fit_load(path, **kwargs):
        assert path == aggregate.resolve() and kwargs["frozen_source"] is inputs["o_fit_source"]
        calls.append("o-fit-native")
        return o_fit
    def learning_load(path, **kwargs):
        assert path == learning.resolve() and kwargs["frozen_source"] is inputs["o_fit_source"]
        calls.append("learning-native")
        return native
    monkeypatch.setattr(f4, "load_o_fit_aggregate_archive", o_fit_load)
    monkeypatch.setattr(f4, "load_learning_curve_aggregate_archive", learning_load)
    fixed = tmp_path / "fixed.zip"
    suite = {"status": "COMPUTED_AWAITING_REVIEW", "stage_acceptance": False,
             "evaluation": {}, "family_decision": {}, "matrix_loco": {},
             "fixed_model_paired_bootstrap": {"UNFITTED_RETAINED": 1000},
             "post_selection_bootstrap": {"UNFITTED_RETAINED": 1000},
             "registered_learning_curve_rows": None, "full_pipeline_bootstrap_result": None}
    def reuse(path, actual):
        assert path == fixed and actual is inputs
        calls.append("retained-fixed")
        return copy.deepcopy(suite)
    def status(*args, **kwargs):
        assert args[4] is native["rows"] and args[5] is o_fit["rows"]
        assert args[6] is None and kwargs == {"learning_curve_execution": native, "full_pipeline_execution": None}
        calls.append("trigger-consumer")
        return {"status": "BLOCKED", "missing": "UNFITTED_OTHER_DIAGNOSTICS"}
    monkeypatch.setattr(f4, "_reuse_f4_fixed_result", reuse)
    monkeypatch.setattr(f4, "_full_pipeline_bootstrap_status", status)
    target = tmp_path / "attached-learning.zip"
    result = f4.execute(tmp_path, target, f4.compile_f45_execution_contract_seal(),
                        fixed_result=fixed, o_fit_aggregate=aggregate, learning_curve_aggregate=learning)
    assert calls == ["source", "o-fit-native", "learning-native", "retained-fixed", "trigger-consumer"]
    assert result["stage_acceptance"] is False
    members = read_safe_zip(target)
    assert set(members) == {"f4-suite.json", "o-fit-aggregate.zip", "learning-aggregate.zip"}
    assert members["learning-aggregate.zip"] == learning.read_bytes()
    assert members["o-fit-aggregate.zip"] == aggregate.read_bytes()
    attached = strict_json_bytes(members["f4-suite.json"])
    assert attached["registered_learning_curve_rows"] == native["rows"]
    for field in ("fixed_model_paired_bootstrap", "post_selection_bootstrap"):
        assert attached[field] == suite[field]
    assert attached["source"]["learning_curve_aggregate"] == {
        "member": "learning-aggregate.zip", "identity_sha256": native["identity_sha256"],
        "sha256": sha256_bytes(learning.read_bytes()), "size_bytes": learning.stat().st_size}
    with pytest.raises(ContractError, match="REQUIRES_FIXED_RESULT"):
        f4.execute(tmp_path, tmp_path / "forbidden-learning.zip", f4.compile_f45_execution_contract_seal(),
                   learning_curve_aggregate=learning)
    assert calls == ["source", "o-fit-native", "learning-native", "retained-fixed", "trigger-consumer"]
