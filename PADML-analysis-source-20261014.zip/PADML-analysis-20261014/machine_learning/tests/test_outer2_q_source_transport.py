"""Bounded old-XGB source/transport tests; all payloads are UNFITTED.

The input hash is an explicit synthetic preimage. Source ZIP bytes are real;
neither this seam nor the transport boundary accepts historical STOP science.
"""
import copy
import os
from pathlib import Path

import pytest

from padml import f2_kernel as kernel, f4, f5, runtime
from padml import f5_sensitivity as sensitivity, nested_loco as nested
from padml.bundle import ContractError, canonical_json_bytes, sha256_bytes, sha256_file, strict_json_bytes
from test_nested_aar_mice import aar_source, unfitted_redevelopment_inputs, unfitted_selector_engines  # noqa: F401
from test_outer6_q_resource_evidence import (
    F50, POLICY, _observation, _forbidden,
    test_original_refit_publisher_and_worker_keep_three_operational_leaves as _transport,
)


@pytest.mark.parametrize("damage", [None, "source", "input", "extra", "pin", "memory"])
def test_outer2_original_source_carrier_is_exact_and_read_only(tmp_path, monkeypatch, damage):
    name = "execution-evidence/outer2-resources/producer-f50.zip"
    source = Path(os.environ["PADML_OUTER6_TEST_F50"])
    root = tmp_path / "q"
    root.mkdir()
    raw = b"UNFITTED_INPUT" + b" " * (2025094 - len(b"UNFITTED_INPUT"))
    path = root / "input.json"
    path.write_bytes(raw)
    digest = "2d482fa880fc41baf78bc047ae524019a603b3f2acd5410c1440a54f080f7d4b"
    monkeypatch.setattr(f5, "sha256_file", lambda p: digest if Path(p) == path
                        and path.read_bytes() == raw else sha256_file(p))
    monkeypatch.setattr(runtime, "observe_execution_resources", _observation)
    monkeypatch.setattr(runtime, "release_step_resources", _forbidden)
    refs = {name: {"sha256": sha256_file(source), "size_bytes": source.stat().st_size}}
    sources = {name: source}
    if damage == "source":
        sources[name] = Path(os.environ["PADML_OUTER6_TEST_F244"])
    elif damage == "input":
        path.write_bytes(b"X" + raw[1:])
    elif damage == "extra":
        sources["execution-evidence/outer6-resources/producer-f50.zip"] = source
    elif damage == "pin":
        refs[name]["sha256"] = "0" * 64
    elif damage == "memory":
        monkeypatch.setattr(runtime, "observe_execution_resources", lambda p:
            {**_observation(p), "available_memory_bytes": 1})
    before = {p: sha256_file(p) for p in (source, path)}
    if damage is None:
        paths, pins = f5._q_python_resource_evidence(root, POLICY, sources=sources, expected=refs)
        assert paths == sources and pins == refs
        batches = []
        for index in range(7):
            batch = tmp_path / f"UNFITTED-batch-{index}"
            batch.mkdir()
            (batch / "execution.json").write_bytes(canonical_json_bytes({"UNFITTED": index}))
            batches.append(batch)
        control = f5._q_search_batch_control(root, POLICY, {"prepare_only": True,
            "task_ids": None, "batch_root": None, "q_batches": batches,
            "retained_bytes_per_task": None, "q_resource_supplement": (source,)})
        assert control["q_resource_evidence"] == control["references"] == refs
        assert (root / name).read_bytes() == source.read_bytes()
        assert len(control["batches"]) == 7 and control["used_batches"] == []
        assert f5._q_python_resource_evidence(root, POLICY, expected=refs)[1] == refs
    else:
        with pytest.raises(ContractError):
            f5._q_python_resource_evidence(root, POLICY, sources=sources, expected=refs)
    assert {p: sha256_file(p) for p in before} == before


@pytest.mark.parametrize("damage", [None, "missing", "duplicate", "phase", "source", "fold", "branch", "horizon"])
def test_outer2_original_batch_scope_requires_exact_seven_prefix_groups(tmp_path, monkeypatch, damage):
    phase, ids = f5._a12_q_stop_phase("S1", family="XGBOOST_COX")
    rows = [{"source_identity": F50, "phase": phase, "task_ids": ids[start:end], "prepared_q_input": {}}
            for start, end in ((0, 30), (30, 60), (60, 90), (90, 110), (110, 140), (140, 170), (170, 200))]
    records = [(tmp_path, row) for row in rows]
    control = {"q_resource_evidence": {"execution-evidence/outer2-resources/producer-f50.zip": {}},
               "batches": records, "resource_policy": POLICY, "completed": False}
    spec = {"family": "XGBOOST_COX", "fold": 2, "execution_scope": "F5_A12_SEARCH",
            "selection_horizon_months": 24, "native_search_root": str(tmp_path / "native"),
            "native_search_batch": control, "a12_source": {"outer_fold": 2,
                "branch": "OUTER_SELECTED_FAMILY_NO_AAR_REDEVELOPMENT"}}
    monkeypatch.setattr(f5, "_q_python_resource_evidence", lambda *a, **k: ({}, control["q_resource_evidence"]))
    if damage == "missing": records.pop()
    elif damage == "duplicate": records[-1] = copy.deepcopy(records[0])
    elif damage == "phase": rows[0]["phase"] += "-ALIEN"
    elif damage == "source": rows[0]["source_identity"] = "0" * 64
    elif damage == "fold": spec["fold"] = 6
    elif damage == "branch": spec["a12_source"]["branch"] = "A12_WITHOUT_AST_ALT_DIRECT"
    elif damage == "horizon": spec["selection_horizon_months"] = 12
    # Intentionally no numerical batches: the valid scope must proceed to the
    # original missing-evidence rejection, not be mistaken for scientific PASS.
    expected = ("F5_Q_BATCH_COMPLETE_COORDINATES_REQUIRED" if damage is None else
                "F2_SELECTION_SCORING_CONTRACT_MISMATCH" if damage == "horizon" else
                "F5_A12_PYTHON_Q_RESOURCE_EVIDENCE_INVALID")
    with pytest.raises(ContractError, match=expected):
        f5._consume_q_search_batches(spec, kernel._run_python_stop_pair_pool_task,
            {name: (None, (name,)) for name in ids}, [], phase, {"sha256": "0" * 64, "size_bytes": 1})


@pytest.mark.parametrize("damage", [None, "missing_predecessor", "wrong_count", "missing_member", "changed_input"])
def test_outer2_refit200_original_publisher_worker_and_archive(tmp_path, monkeypatch, damage):
    _transport(tmp_path, monkeypatch, damage, "S1", True, family="XGBOOST_COX")


@pytest.mark.parametrize("unfitted_redevelopment_inputs", ["XGBOOST_COX"], indirect=True)
def test_outer2_stop200_original_batch_consumer_feeds_refit200_without_new_leaf(
        unfitted_redevelopment_inputs, unfitted_selector_engines, aar_source, tmp_path, monkeypatch,
        *, family="XGBOOST_COX", direct=False):
    """Original STOP barrier -> numerical batch reader -> original REFIT tasks.

    Model leaves are the existing UNFITTED adapters. The fixture's AAR source
    is projected to outer2 only for transport; actual source/clinical context
    validation is not replaced or claimed by this synthetic test.
    """
    import shutil
    import test_q_funnel_shards as funnel
    from test_a12_q_native import _q_numbers_python_unit

    if family == "XGBOOST_COX":
        sample, _, _ = _q_numbers_python_unit(aar_source, tmp_path, family, "AAR")
        parameters = {**sample["parameters"], "max_nrounds": 500}
        candidates = {stage: [{"trial_id": f"UNFITTED-{stage}-{index}",
            "parameters": dict(parameters), "parameter_sha256": sha256_bytes(canonical_json_bytes(parameters))}
            for index in range(count)] for stage, count in (("S1", 40), ("S2", 14))}
        monkeypatch.setattr(f5, "_final_complex_candidate_trials", lambda family: copy.deepcopy(candidates))
    branch = nested.A12_DIRECT_AAR if direct else nested.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT
    prepared = sensitivity._a12_projected_development_inputs(
        unfitted_redevelopment_inputs, tmp_path / "development", replay=False, branch=branch)
    monkeypatch.setattr(runtime, "effective_cpu_count", lambda: 32)
    monkeypatch.setattr(runtime, "observe_execution_resources", _observation)
    configuration = sensitivity._a12_complex_configuration(prepared, branch)
    spec, registered = configuration["spec"], configuration["registered"]
    spec.update(fold=1 if direct else 2, seed=301000 if direct else 302000, selection_horizon_months=24)
    spec["a12_source"] = {**spec["a12_source"], "outer_fold": spec["fold"]}
    primary = Path(os.environ["PADML_RETAINED_FULL0_SOURCE_BUNDLE"])
    spec["retained_primary_source_bundle" if direct else "retained_a12_primary_context_source_bundle"] = str(primary)
    owner = tmp_path / "original-owner"
    (owner / "native").mkdir(parents=True)
    raw = canonical_json_bytes({"kind": "PADML_F5_A12_Q_INPUT_V1", "spec": spec, "UNFITTED": True})
    (owner / "input.json").write_bytes(raw)
    pin = {"sha256": sha256_bytes(raw), "size_bytes": len(raw)}
    policy = prepared["source"]["resource_policy"]
    events, _ = funnel._unfitted_leaves(monkeypatch)
    runner = kernel._run_python_registered_coxtime if direct else kernel._run_python_registered_xgboost
    def run(actual, root):
        return runner(actual, registered, root, None, None, None, search_only=True)
    control = f5._q_search_batch_control(owner, policy, funnel._options())
    running = {**spec, "native_search_root": str(owner / "native"),
               "native_search_replay": False, "native_search_batch": control}
    captured = []
    class BeforeStop(Exception):
        pass
    def capture(actual, function, tasks):
        assert function is kernel._run_python_stop_pair_pool_task
        captured.extend(tasks)
        raise BeforeStop
    with monkeypatch.context() as patch:
        patch.setattr(f5, "_q_search_task_batch", capture)
        with pytest.raises(BeforeStop):
            run(running, owner)
    phase, ids = f5._a12_q_stop_phase("S1", family=family)
    groups = [ids] if direct else [ids[start:end] for start, end in (
        (0, 30), (30, 60), (60, 90), (90, 110), (110, 140), (140, 170), (170, 200))]
    units = f5._q_search_units(kernel._run_python_stop_pair_pool_task, captured)
    assert list(units) == ids and not events
    outputs = [[str(tmp_path / f"stop-{i}.zip"), *group] for i, group in enumerate(groups)]
    cap = 4 * 1024**2
    if not direct:
        f5._publish_a12_q_stop_inputs(kernel._run_python_stop_pair_pool_task, units, owner,
            {**control, "q_unit_outputs": outputs, "retained_bytes_per_task": cap}, phase, pin)
    batches = []
    for index, output in enumerate(outputs):
        archive = Path(output[0])
        destination = tmp_path / f"batch-{index}"
        if direct:
            work = tmp_path / f"worker-{index}"
            (work / "native").mkdir(parents=True)
            shutil.copyfile(owner / "input.json", work / "input.json")
            worker_control = f5._q_search_batch_control(work, policy,
                {**funnel._options(ids=output[1:], destination=destination), "retained_bytes_per_task": cap})
            worker_spec = {**running, "native_search_root": str(work / "native"), "native_search_batch": worker_control}
            with pytest.raises(f5._QBatchBoundary) as produced:
                f5._q_search_task_batch(worker_spec, kernel._run_python_stop_pair_pool_task, captured)
            result = produced.value.result
        else:
            result = sensitivity.execute_a12_outer_bundle(archive, tmp_path / f"worker-{index}",
                search_only=True, search_branch=branch, prepared_q_input_sha256=sha256_file(archive),
                task_ids=output[1:], batch_root=destination, retained_bytes_per_task=cap)
        record = copy.deepcopy(result["execution"])
        assert record["new_model_fit_count"] == len(output) - 1
        # Construct an old-shaped UNFITTED receipt, not a forged real result.
        record["source_identity"] = "1513ecba963857099c6b99413b8e976393c551a3ec30ed90da1cb14178338bd7" if direct else F50
        record.pop("execution_scratch_reserve_bytes")
        record.pop("operational_errors", None)
        if direct:
            record.pop("execution_worker_memory_bytes")
            record.pop("resource_release")
        record["effective_policy"] = f5._q_batch_resource_policy(policy, len(raw), len(output) - 1, cap,
            **({} if direct else {"execution_worker_memory_bytes": 2 * 1024**3,
                                 "prepared_input": record["prepared_q_input"]}))
        record["resource_admission"] = runtime.resource_admission(record["effective_policy"],
            record["resource_observation"], legal_tasks=len(output) - 1)
        if not direct:
            record["prepared_q_input"]["after_release"] = None
        (destination / "execution.json").write_bytes(canonical_json_bytes(record))
        batches.append(destination)
    assert sum(mode == "produce" for mode, _, _ in events) == len(ids)
    before_events = list(events)
    before_bytes = {path: sha256_file(path) for root in [owner, *batches]
                    for path in root.rglob("*") if path.is_file()}
    source = primary if direct else Path(os.environ["PADML_OUTER6_TEST_F50"])
    name = "execution-evidence/outer2-resources/producer-f50.zip"
    refs = {name: {"sha256": sha256_file(source), "size_bytes": source.stat().st_size}}
    proof = f4._retained_full0_source_members(source, **({"aar_primary_context": True} if direct else {"aar_python_q": True}))
    assert sha256_bytes(canonical_json_bytes(proof)) == record["source_identity"]
    def fixture_source_reader(directory, actual_policy, *, sources=None, expected=None):
        # Only the fixed historical clinical-input pin is substituted. Source
        # ZIP bytes, all batch/input/payload/resource/numerical checks are real.
        assert (directory / "input.json").read_bytes() == raw and actual_policy["configured_worker_ceiling"] == policy["configured_worker_ceiling"]
        assert expected is None or expected == refs
        paths = {name: directory / name} if sources is None else sources
        assert set(paths) == {name} and all(sha256_file(path) == refs[key]["sha256"] for key, path in paths.items())
        return paths, refs
    if not direct:
        monkeypatch.setattr(f5, "_q_python_resource_evidence", fixture_source_reader)
    current = tmp_path / "consumer"
    (current / "native").mkdir(parents=True)
    shutil.copyfile(owner / "input.json", current / "input.json")
    next_phase, next_ids = f5._a12_q_stop_phase("S1", refit=True, family=family)
    options = {**funnel._options(history=batches), "retained_bytes_per_task": cap,
        **({} if direct else {"q_resource_supplement": (source,)}),
        "q_unit_outputs": [[str(tmp_path / f"refit-{i}.zip"), *next_ids[i::7]] for i in range(7)]}
    consumed = f5._q_search_batch_control(current, policy, options,
        **({"retained_primary_source_bundle": primary} if direct else {}))
    following = {**spec, "native_search_root": str(current / "native"), "native_search_replay": False,
                 "native_search_batch": consumed}
    refitter = "_run_coxtime_refit_pool_task" if direct else "_run_xgb_refit_pool_task"
    monkeypatch.setattr(kernel, refitter, _forbidden)
    # Keep the original callable identity/phase while forbidding its fit body.
    monkeypatch.setattr(_forbidden, "__name__", refitter)
    with pytest.raises(f5._QBatchBoundary) as ready:
        run(following, current)
    assert ready.value.result["phase"] == next_phase and ready.value.result["task_ids"] == next_ids
    assert consumed["confirmed_model_fits"] == consumed["confirmed_stop_fits"] == len(ids)
    assert len(consumed["used_batches"]) == len(groups)
    assert [row for row in events if row[0] != "numbers"] == [row for row in before_events if row[0] != "numbers"]
    assert sum(mode == "numbers" for mode, _, _ in events[len(before_events):]) == len(ids)
    published = strict_json_bytes((current / "prepared-unit-inputs.json").read_bytes())
    assert sum(len(row["task_ids"]) for row in published["outputs"]) == len(ids)
    assert {path: sha256_file(path) for path in before_bytes} == before_bytes
