"""Deterministic A12 recipe I/O tests; no MICE, model, selector or RNG calls."""
import csv
import io
from pathlib import Path

import pytest

from padml import f5
from padml.bundle import ContractError, canonical_json_bytes, sha256_bytes, strict_json_bytes
from padml.f5_sensitivity import _type7_quantile


NATIVE_RUN = f5.subprocess.run


@pytest.fixture
def synthetic_m20(tmp_path):
    predictors = f5.predictor_contract(Path(f5.__file__).parent)
    parents = [row["parent"] for row in predictors["transform_registry"]["rows"]
               if row["parent"] not in {"AST_ALT", "eGFR_calc"}]
    fit_ids = [f"UNFITTED-train-{i:03d}" for i in range(40)]
    root = tmp_path.resolve() / "UNFITTED-M20"
    root.mkdir()
    for imp in range(1, 21):
        stream = io.StringIO(newline="")
        writer = csv.writer(stream, lineterminator="\n")
        writer.writerow(["Patient_ID", "Center", *parents])
        writer.writerows([patient, "36", *([20 + i * 1.1 + imp * .07] * len(parents))]
                         for i, patient in enumerate(fit_ids))
        # Invalid held-out values must never enter a training recipe.
        writer.writerow(["UNFITTED-heldout", "52", *([-999999] * len(parents))])
        (root / f"imp{imp:02d}.csv").write_text(stream.getvalue())
    return {"partition_id": "UNFITTED_A12_OUTER_F1", "fit_ids": fit_ids,
        "covariates": {"input_dir": str(root),
                       "analysis_ids_sha256": sha256_bytes(canonical_json_bytes(fit_ids)),
                       "analysis_view_sha256": sha256_bytes(b"UNFITTED native view substitute")}}


def test_a12_native_recipe_preserves_training_projection_and_success_evidence(synthetic_m20, tmp_path, monkeypatch):
    calls = []
    def recipe_only(command, **kwargs):
        spec = strict_json_bytes(Path(command[2]).read_bytes())
        assert Path(command[1]).name == "f5_final_refit.R" and spec["action"] == "COMPILE_A12_RECIPE"
        calls.append(spec)
        return NATIVE_RUN(command, **kwargs)
    monkeypatch.setattr(f5.subprocess, "run", recipe_only)
    evidence = tmp_path.resolve() / "native-success"
    recipe = f5._compile_partition_design_recipe("COX_PH", ["Age", "HGB"], synthetic_m20,
        tmp_path, a12=True, native_evidence=evidence)
    assert len(calls) == 1
    f5._validate_final_design_recipe(recipe, family="COX_PH", selected_parents=["Age", "HGB"])
    projection = calls[0]["projection"]["recipe_registry_record"]
    for member in projection["members"]:
        path = Path(projection["input_dir"]) / member["name"]
        reader = csv.DictReader(io.StringIO(path.read_text()))
        rows = list(reader)
        assert [row["Patient_ID"] for row in rows] == synthetic_m20["fit_ids"]
        assert not {"AST", "ALT", "AST_ALT", "All_Cause_Death", "Death_Followup_months"}.intersection(reader.fieldnames)
        assert b"heldout" not in path.read_bytes()
    age = next(row for row in recipe["transform_recipe"]["representations"] if row["parent"] == "Age")
    pool = sorted(20 + i * 1.1 + imp * .07 for imp in range(1, 21) for i in range(40))
    quantiles = [_type7_quantile(pool, p) for p in (.1, .5, .9)]
    assert age["parameters"]["boundary_knots"] == [quantiles[0], quantiles[2]]
    assert age["parameters"]["interior_knots"] == [quantiles[1]]
    assert all((evidence / name).is_file() for name in ("spec.json", "recipe.json", "stdout.log", "stderr.log"))
    assert not (evidence / "native-failure.rda").exists()


def test_a12_real_r_admission_failure_keeps_native_frames_without_fit(synthetic_m20, tmp_path, monkeypatch):
    calls = []
    def reject_before_recipe(command, **kwargs):
        path = Path(command[2])
        spec = strict_json_bytes(path.read_bytes())
        assert spec["action"] == "COMPILE_A12_RECIPE"
        # Reject the schema before recipe arithmetic, fitting or RNG.
        spec["UNFITTED_TEST_INVALID_FIELD"] = True
        path.write_bytes(canonical_json_bytes(spec))
        result = NATIVE_RUN(command, **kwargs)
        calls.append(result.returncode)
        return result
    monkeypatch.setattr(f5.subprocess, "run", reject_before_recipe)
    evidence = tmp_path.resolve() / "native-failure"
    # Shared error normalization deliberately retains F5's fallback label;
    # the exact native reason is preserved in stderr, not fabricated here.
    with pytest.raises(ContractError, match="F5_FINAL_RECIPE_FAILED") as error:
        f5._compile_partition_design_recipe("COX_PH", ["Age"], synthetic_m20,
            tmp_path, a12=True, native_evidence=evidence)
    assert calls == [1]
    assert str(evidence) in " ".join(error.value.__notes__)
    assert (evidence / "native-failure.rda").stat().st_size > 0
    assert b"F5_FINAL_RECIPE_INPUT_INVALID" in (evidence / "stderr.log").read_bytes()
    assert len(list((evidence / "training-inputs").glob("*/imp*.csv"))) == 20
    assert not (evidence / "recipe.json").exists()


def test_a12_interrupted_projection_keeps_partial_input_without_native_retry(synthetic_m20, tmp_path, monkeypatch):
    def interrupted(registered, partition_id, predictors, inputs):
        (inputs / "UNFITTED-partial.csv").write_bytes(b"UNFITTED partial input")
        raise RuntimeError("UNFITTED_PROJECTION_INTERRUPTED")
    def forbidden(*args, **kwargs):
        raise AssertionError("NO_NATIVE_PROCESS")
    monkeypatch.setattr(f5, "_recipe_partition_projection", interrupted)
    monkeypatch.setattr(f5.subprocess, "run", forbidden)
    with pytest.raises(RuntimeError, match="UNFITTED_PROJECTION_INTERRUPTED") as error:
        f5._compile_partition_design_recipe("COX_PH", ["Age"], synthetic_m20, tmp_path, a12=True)
    roots = list(tmp_path.glob(".f5-final-recipe-*"))
    assert len(roots) == 1 and str(roots[0]) in " ".join(error.value.__notes__)
    assert (roots[0] / "training-inputs/UNFITTED-partial.csv").read_bytes() == b"UNFITTED partial input"
