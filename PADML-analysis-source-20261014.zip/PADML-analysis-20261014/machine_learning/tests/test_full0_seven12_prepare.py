"""Seven-family original compiler, with explicitly synthetic Q/selector leaves."""
from pathlib import Path
from contextlib import contextmanager

import pytest

from padml import f5, f4_compact, nested_loco as nested, runtime
from padml.bundle import ContractError, canonical_json_bytes
from test_nested_full_development import (
    full_inputs, unfitted_selector_consumers, _physical_full_inputs, _unfitted_confirmed_decision,
)


def test_public_seven_preparation_preserves_family_roots_and_releases_own_inputs(tmp_path, monkeypatch):
    from test_full0_fixed12_rescore import decision
    from test_full0_cox12_prepare import _observe, _policy
    original = tmp_path / "score"
    original.mkdir()
    marker = original / "input-execution.json"
    marker.write_bytes(b"ORIGINAL_RSF_EVIDENCE")
    sources = {"plan": {}, "science_decision": decision(), "score_root": str(original),
        "selector_root": str(tmp_path / "selector"), "search_roots": {}, "rscript": "UNFITTED",
        "resource_policy": _policy(), "retained_bytes_per_component": 1024**2,
        "expanded_bytes_per_component": 1024**2, "shared_storage_bytes": 64 * 1024**2}
    lineage = tmp_path / "lineage.json"
    lineage.write_bytes(canonical_json_bytes(sources))
    original_lineage = lineage.read_bytes()
    monkeypatch.setattr(f5, "_read_final_lineage", lambda *a, **k: sources)
    @contextmanager
    def materialized(*args, **kwargs):
        assert kwargs.get("selector_only", False) is False
        assert kwargs["selection_horizon_months"] == 12 and kwargs["retained_mice_plan"] == sources["plan"]
        yield sources, [], {}
        root = tmp_path / "completed-synthetic-materialization"
        root.mkdir()
        (root / "input.json").write_bytes(b"{}")
        kwargs["q_input_lifecycle"]["materialized_inputs"] = {"temporary_root": str(root)}
    def prepare(*args, **kwargs):
        assert args[5] == tmp_path / "score.all"
        assert kwargs["prepare_only"] is True and kwargs["replay"] is kwargs["resume"] is False
        assert "family" not in kwargs
        assert kwargs["retained_q_archive"] == tmp_path / "q.zip"
        assert kwargs["retained_q_producer_source_bundle"] == tmp_path / "producer.zip"
        readback = args[5] / "retained-q-readback"
        readback.mkdir(parents=True)
        (readback / "input.json").write_bytes(b"{}")
        return {"request": {"identity_sha256": "b" * 64}, "resource_reservation": {"effective_policy": _policy()}}
    monkeypatch.setattr(f5, "_materialized_full_data_development_sources", materialized)
    monkeypatch.setattr(f5, "_full_data_locked_score_program", prepare)
    monkeypatch.setattr(runtime, "observe_execution_resources", _observe)
    released = []
    def release(paths, **kwargs):
        released.append(list(paths))
        return {"reader_scan_status": "UNKNOWN", "files": []}
    monkeypatch.setattr(runtime, "release_step_resources", release)
    result = f5.execute_full_data_locked_scores(lineage, prepare_only=True, selection_horizon_months=12,
        retained_full0_source_bundle=tmp_path / "primary.zip", retained_q_archive=tmp_path / "q.zip",
        retained_q_producer_source_bundle=tmp_path / "producer.zip")
    assert marker.read_bytes() == b"ORIGINAL_RSF_EVIDENCE" and lineage.read_bytes() == original_lineage
    assert len(released) == 2 and all(p.read_bytes() == b"{}" for paths in released for p in paths)
    assert set(result["input_lifecycle"]) == {"materialized_inputs", "retained_q_readback"}
    assert result["input_release_error"] and result["after_input_release"]["resource_admission"]
    assert Path(result["input_execution_report"]) == tmp_path / "score.all/input-execution.json"


@pytest.mark.parametrize("change", [{"resume": True}, {"retained_q_archive": None},
    {"retained_q_producer_source_bundle": None}, {"retained_full0_source_bundle": None}])
def test_seven_family_scope_requires_complete_source_pair_before_io(tmp_path, monkeypatch, change):
    def forbidden(*args, **kwargs):
        raise AssertionError("NO_INPUT_OR_Q_READ_BEFORE_SCOPE_VALIDATION")
    monkeypatch.setattr(f5, "_nested_full_score_development", forbidden)
    options = dict(selection_horizon_months=12, retained_q_archive=tmp_path / "q.zip",
        retained_q_producer_source_bundle=tmp_path / "producer.zip",
        retained_full0_source_bundle=tmp_path / "primary.zip")
    options.update(change)
    with pytest.raises(ContractError, match="NESTED_FULL_SCORE_SELECTION_SCOPE_INVALID"):
        f5._compile_full_score_inputs({}, [], {}, tmp_path / "selector", {}, tmp_path / "request",
            rscript="FORBIDDEN", **options)


def test_seven_family_12_inputs_share_context_and_rebuild_without_fits(
        full_inputs, unfitted_selector_consumers, tmp_path, monkeypatch):
    inputs = _physical_full_inputs(full_inputs, tmp_path / "inputs", complete_covariates=True)
    selector = tmp_path / "selector"
    f5._nested_full_selector_program(*inputs, selector, rscript="UNFITTED", replay=False)
    base = _unfitted_confirmed_decision(fresh_seven=True, fixed_bootstrap=True)
    science = nested._sealed({**{k: v for k, v in base.items() if k != "identity_sha256"},
        "twelve_month_development": nested._twelve_month_development_contract()})
    monkeypatch.setattr(f5, "resolve_pool_workers", lambda workers: 1)
    monkeypatch.setattr(runtime, "effective_cpu_count", lambda: 16)
    policy = {"configured_worker_ceiling": runtime.CPU_MINUS_8,
        "memory_bytes_per_worker": 2 * 1024**3, "memory_reserve_bytes": 0,
        "scratch_bytes_per_worker": 1, "scratch_reserve_bytes": 0,
        "transfer_archive_worker_ceiling": 8}
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda path: {
        "effective_cpus": 16, "available_memory_bytes": 32 * 1024**3,
        "scratch_available_bytes": 32 * 1024**3, "scratch_root": str(path)})
    roots, tasks, results = {}, {}, {}
    for family in ("RSF", "GBM_COX", "XGBOOST_COX", "COXTIME_SET_A"):
        task = f5.compile_nested_full_complex_search_task(*inputs, selector, family=family,
            rscript="UNFITTED", selection_horizon_months=12, science_decision=science)
        registered = f5._complex_runtime_registered_inputs(task, inputs[1])
        spec = f5._complex_search_execution_spec(task, registered)
        spec.update(threads=1, pool_workers=1)
        spec["final_search_source"] = {**spec["final_search_source"], "producer_execution": {
            k: spec[k] for k in ("execution_mode", "threads", "pool_workers", "engine_threads")}}
        candidate = task["candidate_trials"]["S1"][0]
        selected = {"family": family, "candidate_id": candidate.get("candidate_id", candidate.get("trial_id")),
            "parameters": candidate if family == "COXTIME_SET_A" else candidate["parameters"],
            "selection_metric": "IBS_0_12", "selection_stage": "S3B2",
            **({"selected_trees": 100} if family == "GBM_COX" else
               {"selected_rounds": 20} if family == "XGBOOST_COX" else
               {"locked_epoch": 50} if family == "COXTIME_SET_A" else {})}
        result = nested._sealed({"UNFITTED_Q_LEAF": True, "family": family,
            "execution_scope": "F5_FULL_DEVELOPMENT_SEARCH", "registered_inputs_identity_sha256": registered["identity"],
            "selected_parents": task["selected_parents"], "selected_spec": selected,
            "selected_spec_sha256": nested._sha(selected)})
        root = tmp_path / family
        (root / "native").mkdir(parents=True)
        (root / "input.json").write_bytes(canonical_json_bytes({"kind": "PADML_F5_Q_INPUT_V1", "task": task, "spec": spec}))
        (root / "result.json").write_bytes(canonical_json_bytes(result))
        (root / "native/UNFITTED-model.rds").write_bytes(b"SYNTHETIC_NOT_A_MODEL")
        f4_compact._full_pipeline_q_numerical_members(root, publish=True)
        roots[family], tasks[family], results[family] = root, task, result
    calls = []
    def numerical(spec, registered, scratch):
        assert spec["native_search_numbers"] is True and spec["native_search_replay"] is True
        assert spec["selection_horizon_months"] == 12
        calls.append(spec["family"])
        return results[spec["family"]]
    monkeypatch.setattr(f5, "_run_final_complex_search", numerical)
    old_source, q_source = tmp_path / "SYNTHETIC-primary.zip", tmp_path / "SYNTHETIC-q-source.zip"
    q_archive = tmp_path / "SYNTHETIC-rsf-q.zip"
    q_archive.write_bytes(b"SYNTHETIC_RETAINED_Q_BOUNDARY")
    original_selector = f5._nested_full_selector_program
    def current_selector(*args, **kwargs):
        assert kwargs.pop("retained_full0_source_bundle") == old_source
        return original_selector(*args, **kwargs)
    monkeypatch.setattr(f5, "_nested_full_selector_program", current_selector)
    readback = []
    def retained_rsf(source, **kwargs):
        assert source == q_archive and kwargs["retained_full0_source_bundle"] == old_source
        assert kwargs["retained_q_producer_source_bundle"] == q_source
        readback.append(kwargs["replay_evidence"])
        _, refs = f4_compact._full_pipeline_q_numerical_members(roots["RSF"])
        kwargs["on_native_references"]([{"path": name, **row} for name, row in sorted(refs.items())])
        return {"task": tasks["RSF"], "result": results["RSF"], "execution_evidence": {"UNFITTED_SOURCE_PROOF": True}}
    monkeypatch.setattr(f5, "read_final_complex_search", retained_rsf)
    def forbidden(*args, **kwargs):
        raise AssertionError("NO_FIT_STOP_MICE_OR_NATIVE_REPLAY")
    monkeypatch.setattr(runtime, "_bounded_ordered_spawn", forbidden)
    score_root = tmp_path / "score.all"
    destination = score_root / "request"
    options = dict(rscript="UNFITTED", workers=1, resource_policy=policy,
        selection_horizon_months=12, science_decision=science,
        retained_full0_source_bundle=old_source, retained_q_archive=q_archive,
        retained_q_producer_source_bundle=q_source)
    prepared = f5._full_data_locked_score_program(*inputs, selector, roots, score_root,
        replay=False, prepare_only=True, retained_bytes_per_component=1024**2,
        expanded_bytes_per_component=1024**2, shared_storage_bytes=64 * 1024**2, **options)
    request = prepared["request"]
    assert prepared["result"] is None and prepared["pool_execution_reports"] == []
    assert prepared["new_model_fits"] == prepared["new_model_native_verification_count"] == prepared["native_model_replay_count"] == 0
    records = request["component_records"]
    assert len(records) == len({row["path"] for row in records}) == 2100
    assert {family: sum(row["family"] == family for row in records) for family in nested._families()} == {
        family: 300 for family in nested._families()}
    assert request["selection_horizon_months"] == 12 and request["science_decision"] == science
    assert set(request["development"]["locked_specs"]) == set(nested._families())
    originals = {p: p.read_bytes() for p in destination.rglob("*") if p.is_file()}
    assert f5._compile_full_score_inputs(*inputs, selector, roots, destination, replay=True, **options) == request
    assert {p: p.read_bytes() for p in destination.rglob("*") if p.is_file()} == originals
    assert calls == ["GBM_COX", "XGBOOST_COX", "COXTIME_SET_A"] * 2
    assert readback == [score_root / "retained-q-readback", None]
    # The existing per-family shard path must populate this same common root,
    # not create a second set of native coordinates or touch fixed/RSF scores.
    from test_nested_full_score import _unfitted_score_shard_engines
    fits = _unfitted_score_shard_engines(monkeypatch)
    scoped = {key: value for key, value in options.items()
              if key not in {"retained_q_archive", "retained_q_producer_source_bundle"}}
    budgets = dict(retained_bytes_per_component=1024**2,
                   expanded_bytes_per_component=1024**2, shared_storage_bytes=64 * 1024**2)
    batches = {}
    for family in f5._STOP_CONSUMERS:
        ids = [row['path'] for row in records if row['family'] == family]
        batch = score_root / 'score-batches' / family
        produced = f5._full_data_locked_score_program(*inputs, selector, roots, score_root,
            replay=False, resume=True, family=family, task_ids=ids, batch_root=batch, **budgets, **scoped)
        assert produced['new_model_fits'] == produced['new_model_native_verification_count'] == 300
        assert produced['request']['component_records'] == [row for row in records if row['family'] == family]
        assert produced['request']['training_context'] == request['training_context']
        assert produced['new_model_fits'] == produced['execution']['new_model_fits']
        assert produced['execution']['new_stop_fits'] == produced['execution']['new_mice_chains'] == 0
        batches[family] = batch
        with pytest.raises(ContractError, match='ALREADY_STARTED'):
            f5._full_data_locked_score_program(*inputs, selector, roots, score_root,
                replay=False, resume=True, family=family, task_ids=ids,
                batch_root=score_root / 'score-batches' / (family + '-duplicate'), **budgets, **scoped)
    assert len(fits) == 900 and {family for family, _ in fits} == set(f5._STOP_CONSUMERS)
    monkeypatch.setattr(runtime, '_bounded_ordered_spawn', forbidden)
    monkeypatch.setattr(f5, '_execute_final_refit_engine', forbidden)
    for family, batch in batches.items():
        gathered = f5._full_data_locked_score_program(*inputs, selector, roots, score_root,
            replay=False, resume=True, family=family, score_batches=[batch], **budgets, **scoped)
        assert gathered['new_model_fits'] == gathered['new_model_native_verification_count'] == 0
        assert gathered['native_model_replay_count'] == 0 and gathered['score_numerical_component_count'] == 300
        assert gathered['training_scores'][0]['selection_horizon_months'] == 12
        reread = f5._full_data_locked_score_program(*inputs, selector, roots, score_root,
            replay=True, family=family, **budgets, **scoped)
        assert reread['training_scores'] == gathered['training_scores']
        assert reread['fresh_score_execution'] == gathered['fresh_score_execution']
        assert reread['new_model_fits'] == reread['native_model_replay_count'] == 0
    assert all(path.read_bytes() == raw for path, raw in originals.items())
    assert not (score_root / 'full-score-result.json').exists()
    assert len(fits) == 900
