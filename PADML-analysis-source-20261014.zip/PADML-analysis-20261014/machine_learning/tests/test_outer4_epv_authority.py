"""Decision-schema checks only; no selector, model, replay or scientific RNG."""
from copy import deepcopy
from pathlib import Path

import unittest

from padml.bundle import ContractError, canonical_json_bytes, strict_json_bytes
from padml import nested_loco as nested


def _decision():
    return strict_json_bytes((Path(__file__).parents[1] / "science-decision.json").read_bytes())


class Outer4AuthorityTests(unittest.TestCase):
    def test_preserves_complete_original_decision(self):
        current = nested.validate_science_decision(_decision())
        prior = nested._sealed({key: value for key, value in current.items()
                               if key not in {"identity_sha256", "outer4_common_set_epv_exception"}})
        self.assertEqual(nested.validate_science_decision(prior)["identity_sha256"],
                         "8d3489742472c51c868e1829de3edd94272698067b42c7c909ff1c7c895e07cf")
        for key in prior:
            if key != "identity_sha256":
                self.assertEqual(canonical_json_bytes(current[key]), canonical_json_bytes(prior[key]))

    def test_rejects_changed_scope_or_rule(self):
        for key, value in [
            ("outer_fold", 6), ("selection_horizon_months", 12), ("family", "COXTIME_SET_A"),
            ("estimand", nested.A12_DIRECT_AAR), ("per_imputation_epv_minimum", 10),
            ("replacement_minimum", 10), ("protected_34_model_refits", 1),
            ("projected_input_identity_sha256", "0" * 64),
        ]:
            with self.subTest(key=key):
                decision = _decision()
                decision["outer4_common_set_epv_exception"][key] = value
                decision = nested._sealed({key: value for key, value in decision.items() if key != "identity_sha256"})
                with self.assertRaisesRegex(ContractError, "NESTED_OUTER4_COMMON_SETA_EPV_DECISION_INVALID"):
                    nested.validate_science_decision(decision)

    def test_cannot_reset_an_old_budget(self):
        decision = deepcopy(_decision())
        decision["twelve_month_development"]["total_incremental_model_fit_ceiling"] += 1
        decision = nested._sealed({key: value for key, value in decision.items() if key != "identity_sha256"})
        with self.assertRaises(ContractError):
            nested.validate_science_decision(decision)

    def test_requires_unchanged_prior_recovery_accounts(self):
        decision = _decision()
        decision.pop("full0_rsf_tail_restoration")
        decision = nested._sealed({key: value for key, value in decision.items() if key != "identity_sha256"})
        with self.assertRaises(ContractError):
            nested.validate_science_decision(decision)
