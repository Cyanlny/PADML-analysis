"""Linux UNFITTED projection/restore boundary; not scientific acceptance.

Uses the existing R/jsonlite synthetic F1 fixture. No model, MICE or replay is
introduced here. The original projection and INNER component compiler remain
real; only the inherited explicit synthetic source fixture seam is used.
"""
import copy

import pytest

from padml import f4, f2_kernel as kernel, nested_loco as nested
from padml.bundle import ContractError
from test_nested_aar_mice import aar_source  # noqa: F401
from test_primary_rsf_score_compilation import (
    test_primary12_public_archive_preserves_q_through_original_input_reader as original_case,
)


def test_pre_search_scoped_roundtrip_original_inner_consumer(aar_source, tmp_path, monkeypatch):
    original = nested._project_outer_development_from_inputs
    checked = []

    def observe(inputs, **kwargs):
        if not checked and kwargs.get("selection_horizon_months") == 12:
            checked.append(True)
            pre_options = {key: value for key, value in kwargs.items()
                if key not in {"scratch", "selection_horizon_months", "primary_searches", "primary_search_source_bundles"}}
            pre = original(inputs, **pre_options, scratch=tmp_path / "pre-search-only",
                primary_rsf_prepare=True, pre_search=True)
            assert not (tmp_path / "pre-search-only/components").exists()
            value, members, response = pre["pre_search"], pre["members"], pre["training_response_csv"]
            restored = nested._restore_outer_pre_search_projection(value, members, response)
            assert "identity" not in restored["registered"]
            assert restored["source_registered_identity"] == value["source_registered_identity"]
            parts = f4._o_fit_partitions(restored["registered"])
            assert len(parts) == 31 and set(value["models"]) == set(nested._families())
            outer = parts["OUTER", 0, 0]
            assert "evaluation_response" not in outer
            assert kernel._registered_partition_identity_record(outer, prediction_only=True)["evaluation_scope"] == "PREDICTION_ONLY"
            assert all("monthly_oof" not in model and "metrics" not in model for model in value["models"].values())
            original_registered = f4._materialize_o_fit_fold(
                inputs["o_fit_source"], 1, tmp_path / "original-outer-template-input")
            original_outer = f4._o_fit_partitions(original_registered)["OUTER", 0, 0]
            for family in nested._families():
                options = {"locked_scoring_decision": kwargs["science_decision"]}
                if family in kwargs["primary_searches"]:
                    q = kwargs["primary_searches"][family]
                    options["primary_search"] = (q["input"], q["result"])
                frozen = restored["frozen"]
                physical = f4._prepare_o_fit_partition(frozen["models"][1, family], parts["INNER", 1, 1], frozen, **options)
                expected = f4._prepare_o_fit_partition(inputs["o_fit_source"]["models"][1, family],
                    parts["INNER", 1, 1], inputs["o_fit_source"], **options)
                assert physical == expected
                outer_options = {key: item for key, item in options.items()
                                 if key != "locked_scoring_decision"}
                scoped_outer = f4._prepare_o_fit_partition(
                    frozen["models"][1, family], outer, frozen,
                    prediction_only=True, **outer_options)
                original_templates = f4._prepare_o_fit_partition(
                    inputs["o_fit_source"]["models"][1, family], original_outer,
                    inputs["o_fit_source"], **outer_options)
                assert scoped_outer == original_templates
                with pytest.raises(ContractError, match="F2_REGISTERED_PARTITION_IDENTITY_INVALID"):
                    f4._prepare_o_fit_partition(frozen["models"][1, family],
                        outer, frozen, **outer_options)
                with pytest.raises(ContractError, match="F2_REGISTERED_PARTITION_IDENTITY_INVALID"):
                    f4._prepare_o_fit_partition(inputs["o_fit_source"]["models"][1, family],
                        original_outer, inputs["o_fit_source"], prediction_only=True, **outer_options)
                with pytest.raises(ContractError):
                    f4._prepare_o_fit_partition(frozen["models"][1, family],
                        parts["INNER", 1, 1], frozen, prediction_only=True, **options)
            bad = copy.deepcopy(value)
            next(row for row in bad["registered"]["partitions"] if row["kind"] == "OUTER")["evaluation_response"] = {"path": "heldout.csv"}
            with pytest.raises(ContractError):
                nested._restore_outer_pre_search_projection(bad, members, response)
            bad = copy.deepcopy(value)
            bad["models"]["RSF"]["monthly_oof"] = {"predictions": []}
            with pytest.raises(ContractError):
                nested._restore_outer_pre_search_projection(bad, members, response)
            bad = copy.deepcopy(value)
            inner = next(row for row in bad["registered"]["partitions"] if row["kind"] == "INNER")
            inner["fit_ids"][0] = outer["evaluation_ids"][0]
            with pytest.raises(ContractError):
                nested._restore_outer_pre_search_projection(bad, members, response)
            with pytest.raises(ContractError):
                nested._restore_outer_pre_search_projection(value, {**members, "extra-heldout.csv": next(iter(members.values()))}, response)
            bad = copy.deepcopy(value)
            bad["registered"]["partitions"][0]["covariates"]["heldout_outcomes"] = {"unwanted": 1}
            with pytest.raises(ContractError):
                nested._restore_outer_pre_search_projection(bad, members, response)
            bad = copy.deepcopy(value)
            bad["registered"]["partitions"][0]["fit_response"]["extra_payload"] = "unwanted"
            with pytest.raises(ContractError):
                nested._restore_outer_pre_search_projection(bad, members, response)
        return original(inputs, **kwargs)

    monkeypatch.setattr(nested, "_project_outer_development_from_inputs", observe)
    original_case(aar_source, tmp_path, monkeypatch, True, None, False)
    assert checked == [True]
