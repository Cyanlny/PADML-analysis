"""UNFITTED engineering boundaries for the same-run post-lock consumers."""
import copy

import pytest

from padml import f4, f5, nested_loco as nested
from padml.bundle import ContractError, canonical_json_bytes as encode, sha256_bytes
from test_f45_score_component_numerics import inputs
from test_f5 import _test_final_design_recipe


def final_entries(family, scope, horizon=6):
    """Native-ABI inputs only; no clinical request, fit, model, or audit."""
    task, _, entries = inputs(family, 'FULL_DATA' if scope == 'FULL0' else 'OUTER', horizon)
    task['f4_coordinates'].update(purpose='NESTED_FULL_FINAL' if scope == 'FULL0' else 'NESTED_OUTER',
                                  repeat=0, inner_fold=0)
    seed = f4._f4_model_seed(family, task['f4_coordinates'])
    task.update(registered_model_seed=seed, model_seed=seed if family in {
        'RSF', 'GBM_COX', 'XGBOOST_COX', 'COXTIME_SET_A'} else None,
        development_lock_sha256=nested._sha({'UNFITTED_CURRENT_LOCK': horizon}))
    if family == 'ELASTIC_NET_COX':
        if scope == 'FULL0':
            source = task.pop('f4_nested_full_elastic_source')
            task['f4_nested_full_final_elastic_source'] = source
            task['parameters'], _ = f4._nested_full_final_elastic_parameters(source, task['f4_coordinates'])
            recipe = f5.strict_json_bytes(entries['recipe.json'])
            recipe['transform_recipe'] = source['full_transform_recipe']
            entries['recipe.json'] = encode(recipe)
        else:
            task['parameters'], _ = f4._f4_elastic_parameters(task['f4_outer_elastic_source'], task['f4_coordinates'])
    if scope == 'FULL0':
        old = task.pop('nested_full_score_source')
        entries['prediction-covariates.csv'] = entries['fit-covariates.csv']
        names = ('training_context_sha256', 'score_development_sha256', 'full_score_result_sha256',
            'family_decision_sha256', 'selector_development_sha256', 'selector_recipe_set_sha256',
            'selected_parents_sha256', 'selected_spec_sha256', 'recipe_sha256', 'mice_member_sha256',
            'training_ids_sha256', 'training_response_sha256')
        source = {name: old.get(name, 'a'*64) for name in names}
        source.update(kind='PADML_NESTED_FULL_FINAL_SOURCE_V1', program_id=nested.PROGRAM_ID,
            recipe_sha256=sha256_bytes(entries['recipe.json']),
            mice_member_sha256=sha256_bytes(entries['fit-covariates.csv']),
            training_response_sha256=sha256_bytes(entries['fit-response.csv']),
            training_ids_sha256=nested._sha(['p1', 'p2']))
        task['nested_full_final_source'] = source
    if scope == 'AAR':
        task = {k: task[k] for k in ('family', 'parameters', 'imputation', 'registered_model_seed', 'model_seed')}
        task.update(a12_coordinates={'outer_fold': 1, 'branch': nested.A12_DIRECT_AAR, 'imputation': 1},
            selected_parents=['Age'], row_count=20, family_design_column_count=1,
            common_set_design_df=1, training_event_count=20)
        lock = nested._sha({'UNFITTED_CURRENT_PRIMARY_LOCK': horizon})
        epv = {'preferred_minimum': 15, 'minimum': 15, 'fallback_used': False,
            'source': 'FIXED_PRIMARY_NON_AAR_SETA', 'primary_development_lock_sha256': lock,
            'training_event_count': 20, 'common_set_design_df': 1, 'common_set_epv': 20., 'reason_code': 'OK'}
        source = {name: 'a'*64 for name in ('science_decision_sha256', 'training_context_sha256',
            'inputs_identity_sha256', 'development_input_sha256', 'parameter_source_sha256')}
        source.update(kind='PADML_NESTED_AAR_FINAL_SOURCE_V1', program_id=nested.PROGRAM_ID,
            primary_development_lock_sha256=lock, selection_horizon_months=horizon,
            epv_resolution=epv, parameter_epv_resolution=None, epv_band='EPV_GE_15')
        if family == 'ELASTIC_NET_COX':
            # Complete selector context resolution remains native; this is
            # the retained numerical task's own parameter EPV evidence.
            source['parameter_epv_resolution'] = {'preferred_minimum': 15, 'minimum': 15,
                'fallback_used': False, 'coarse_records_sha256': 'b'*64,
                'attempts': [{'minimum': 15, 'alpha_feasibility': [{'alpha': alpha, 'status': 'FEASIBLE'}
                    for alpha in f5.load_science_authority()['science']['f2_model_development'][
                        'selector_contract']['alpha_grid']['coarse']]}],
                'reason_code': 'OK'}
        if family == 'FPM_TVC_SET_A':
            task['parameters'] = {'family': family, 'df': 3, 'tvc_df': 0}
        task['nested_aar_final_source'] = source
        entries = {'recipe.json': encode(_test_final_design_recipe(family, ['Age'])),
            'fit-covariates.csv': b'Patient_ID,Center,Age\n'+b''.join(f'p{i},38,{40+i}\n'.encode() for i in range(20)),
            'prediction-covariates.csv': b'Patient_ID,Center,Age\nh1,36,60\n',
            'fit-response.csv': b'Patient_ID,All_Cause_Death,Death_Followup_months\n'+b''.join(
                f'p{i},1,{i+1}\n'.encode() for i in range(20))}
    entries['task.json'] = encode(task)
    return entries


@pytest.mark.parametrize('scope', ['PRIMARY', 'AAR', 'FULL0'])
@pytest.mark.parametrize('family', nested._families())
def test_final_projection_uses_actual_inputs_and_keeps_both_locks(scope, family):
    first, second = final_entries(family, scope, 6), final_entries(family, scope, 12)
    original = copy.deepcopy((first, second))
    assert first['task.json'] != second['task.json']
    assert f5._f45_final_component_numerics(first) == f5._f45_final_component_numerics(second)
    assert (first, second) == original
    task = f5.strict_json_bytes(second['task.json'])
    task['registered_model_seed'] += 1
    with pytest.raises(ContractError):
        f5._f45_final_component_numerics({**second, 'task.json': encode(task)})


@pytest.mark.parametrize('scope', ['PRIMARY', 'AAR', 'FULL0'])
def test_final_projection_rejects_response_roles_and_distinguishes_patient_order(scope):
    entries = final_entries('RSF', scope)
    expected = f5._f45_final_component_numerics(entries)
    bad = {**entries, 'prediction-covariates.csv': entries['prediction-covariates.csv'].replace(
        b'Patient_ID,Center,', b'Patient_ID,All_Cause_Death,')}
    with pytest.raises(ContractError):
        f5._f45_final_component_numerics(bad)
    changed = copy.deepcopy(entries)
    for name in ('fit-covariates.csv', 'fit-response.csv'):
        lines = changed[name].splitlines(keepends=True)
        changed[name] = b''.join([lines[0], lines[2], lines[1], *lines[3:]])
    if scope == 'FULL0':
        changed['prediction-covariates.csv'] = changed['fit-covariates.csv']
        task = f5.strict_json_bytes(changed['task.json'])
        source = task['nested_full_final_source']
        source.update(mice_member_sha256=sha256_bytes(changed['fit-covariates.csv']),
            training_response_sha256=sha256_bytes(changed['fit-response.csv']),
            training_ids_sha256=nested._sha(['p2', 'p1']))
        changed['task.json'] = encode(task)
    assert f5._f45_final_component_numerics(changed) != expected


@pytest.mark.parametrize('family,field', [('GBM_COX', 'selected_trees'),
    ('XGBOOST_COX', 'selected_rounds'), ('COXTIME_SET_A', 'locked_epoch')])
def test_final_projection_keeps_actual_stop_value(family, field):
    entries = final_entries(family, 'PRIMARY')
    expected = f5._f45_final_component_numerics(entries)
    task = f5.strict_json_bytes(entries['task.json'])
    task['parameters'][field] += 1
    assert f5._f45_final_component_numerics({**entries, 'task.json': encode(task)}) != expected


def test_final_projection_rejects_prelock_and_unbound_tasks():
    for scope in ('PRIMARY', 'FULL0', 'AAR'):
        entries = final_entries('RSF', scope)
        task = f5.strict_json_bytes(entries['task.json'])
        del task['nested_aar_final_source' if scope == 'AAR' else 'development_lock_sha256']
        with pytest.raises(ContractError):
            f5._f45_final_component_numerics({**entries, 'task.json': encode(task)})
    _, _, entries = inputs('RSF', 'OUTER', 6)
    with pytest.raises(ContractError, match='F45_FINAL_REUSE_SCOPE_INVALID'):
        f5._f45_final_component_numerics(entries)


def test_final_projection_separates_outer_branch_and_actual_fit_response():
    entries = final_entries('RSF', 'AAR')
    expected = f5._f45_final_component_numerics(entries)
    task = f5.strict_json_bytes(entries['task.json'])
    task['a12_coordinates']['branch'] = nested.A12_TOTAL_AAR
    assert f5._f45_final_component_numerics({**entries, 'task.json': encode(task)}) != expected
    task = f5.strict_json_bytes(entries['task.json'])
    task['a12_coordinates']['outer_fold'] = 2
    task.update(model_seed=302001, registered_model_seed=302001)
    assert f5._f45_final_component_numerics({**entries, 'task.json': encode(task)}) != expected
    assert f5._f45_final_component_numerics({**entries, 'fit-response.csv':
        entries['fit-response.csv'].replace(b'p0,1,1\n', b'p0,1,1.5\n')}) != expected


def test_final_projection_uses_actual_mi_lambda_and_covariates():
    entries = final_entries('ELASTIC_NET_COX', 'PRIMARY')
    expected = f5._f45_final_component_numerics(entries)
    task = f5.strict_json_bytes(entries['task.json'])
    source = task['f4_outer_elastic_source']
    source['selected_spec']['ratio_by_imputation'][0] = .2
    source['selected_spec']['lambda_by_imputation'][0] = .4
    task['parameters'], _ = f4._f4_elastic_parameters(source, task['f4_coordinates'])
    assert f5._f45_final_component_numerics({**entries, 'task.json': encode(task)}) != expected
    assert f5._f45_final_component_numerics({**entries, 'fit-covariates.csv':
        entries['fit-covariates.csv'].replace(b',1,1', b',2,1', 1)}) != expected
