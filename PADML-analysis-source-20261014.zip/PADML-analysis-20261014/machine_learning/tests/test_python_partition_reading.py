from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd
import pytest

from padml._science_authority import load_science_authority
from padml.bundle import ContractError, canonical_json_bytes, sha256_bytes
import padml.f2_kernel as kernel


@pytest.fixture(params=["COXTIME_SET_A", "XGBOOST_COX"])
def partition_case(tmp_path: Path, request):
    predictors = kernel.predictor_contract(Path(kernel.__file__).resolve().parent, load_science_authority())
    spec = {
        "family": request.param, "outcome": "All_Cause_Death",
        "time": "Death_Followup_months", "predictors": predictors,
        "selector_from_dependency": {
            "selected_parents": ["Prior_LE_Surgery_cat", "CKD_bin", "AST_ALT"]},
    }
    raw = b"Patient_ID,All_Cause_Death,Death_Followup_months\n001,1,12\n"
    partition = {
        "partition_id": "STOP_F2_R1_K1", "application_ids": ["001", "002"],
        "fit_ids": ["001"], "evaluation_ids": ["002"],
        "covariates": {"input_dir": str(tmp_path)},
        "fit_response": {
            "private_bytes": raw, "sha256": sha256_bytes(raw), "size_bytes": len(raw),
            "row_count": 1, "row_ids_sha256": sha256_bytes(canonical_json_bytes(["001"])),
        },
    }
    registered = {
        "projected_partition_ids": [partition["partition_id"]], "projected_partition_count": 1,
        "partitions": [partition], "diagnostic_partitions": [],
    }
    return spec, registered, tmp_path / "imp01.csv"


def load_case(case, category="None", number="1.25"):
    spec, registered, path = case
    path.write_text(
        "Patient_ID,Prior_LE_Surgery_cat,CKD_bin,AST_ALT\n"
        f"001,{category},0,{number}\n002,Procedure,1,2.5\n")
    return kernel._load_python_registered_partition(
        spec, registered, "STOP_F2_R1_K1", pd, np, [1])


def test_dictionary_none_survives_csv_and_matches_literal_design(partition_case):
    spec, _, path = partition_case
    actual = load_case(partition_case)
    assert pd.read_csv(path)["Prior_LE_Surgery_cat"].isna().tolist() == [True, False]
    literal = pd.DataFrame({
        "Patient_ID": ["001", "002"], "Prior_LE_Surgery_cat": ["None", "Procedure"],
        "CKD_bin": [0, 1], "AST_ALT": [1.25, 2.5],
    })
    designs, columns = kernel._prepare_python_design(spec, [literal], pd)
    assert actual["columns"] == columns
    assert actual["fit_ids"] == ["001"] and actual["evaluation_ids"] == ["002"]
    np.testing.assert_array_equal(actual["fit_designs"][0], designs[0].to_numpy()[[0]])
    np.testing.assert_array_equal(actual["evaluation_designs"][0], designs[0].to_numpy()[[1]])
    assert actual["fit_designs"][0][0, columns.index("Prior_LE_Surgery_cat_None")] == 1


@pytest.mark.parametrize("category", ["", '""', "Unknown", "NaN", "NA", "NULL", "nan"])
def test_missing_and_unknown_categories_remain_errors(partition_case, category):
    with pytest.raises(ContractError, match="F2_PYTHON_FACTOR_LEVEL_INVALID"):
        load_case(partition_case, category=category)


@pytest.mark.parametrize("missing", [None, np.nan, pd.NA])
def test_in_memory_missing_is_not_stringified_to_legal_none(partition_case, missing):
    spec, _, _ = partition_case
    frame = pd.DataFrame({"Prior_LE_Surgery_cat": [missing], "CKD_bin": [0], "AST_ALT": [1.25]})
    with pytest.raises(ContractError, match="F2_PYTHON_FACTOR_LEVEL_INVALID"):
        kernel._prepare_python_design(spec, [frame], pd)


@pytest.mark.parametrize("number", ["", "NaN", "NA", "None", "inf", "-inf", "bad"])
def test_missing_nonfinite_and_invalid_numeric_values_remain_errors(partition_case, number):
    with pytest.raises((ContractError, ValueError)):
        load_case(partition_case, number=number)


def test_valid_non_none_reading_is_unchanged(partition_case):
    spec, _, path = partition_case
    actual = load_case(partition_case, category="Other")
    old_design, old_columns = kernel._prepare_python_design(
        spec, [pd.read_csv(path, dtype={"Patient_ID": str})], pd)
    assert actual["columns"] == old_columns
    np.testing.assert_array_equal(actual["fit_designs"][0], old_design[0].to_numpy()[[0]])
    np.testing.assert_array_equal(actual["evaluation_designs"][0], old_design[0].to_numpy()[[1]])
