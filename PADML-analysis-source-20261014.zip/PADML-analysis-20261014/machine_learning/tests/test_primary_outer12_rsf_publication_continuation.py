"""Real retained publication receipts -> original S3A inputs; zero science.

This reader test alone does not prove S3A numerical consumption or S3B1 readiness.
"""
import json
import os
from pathlib import Path

import pytest

from padml import f5
from padml.bundle import ContractError, canonical_json_bytes


HOSTS = ("H0", "H1", "H4", "H5", "H6", "H7", "H9-2")


def _fixture_root(outer: int) -> Path:
    value = os.environ.get(f"PADML_OUTER{outer}_PUBLICATION_FIXTURE")
    if not value:
        pytest.skip(f"private retained outer{outer} publication fixture is not mounted")
    root = Path(value).resolve(strict=True)
    assert root.is_dir()
    return root


@pytest.mark.parametrize("outer", [4, 6])
@pytest.mark.parametrize("damage", [None, "outer", "source", "input", "coordinate", "s1-report", "metadata"])
def test_real_publication_receipt_reopens_original_s3a_inputs(tmp_path, damage, outer):
    root = _fixture_root(outer)
    s2_root = root / "s2/prepared-inputs"
    publication = root / "publication"
    s2 = {name: s2_root / name for name in {
        "source/primary-s2-producer.zip", "source/primary-q-producer.zip", "primary-s2/report.json",
        *(f"primary-s2/{host}-execution.json" for host in HOSTS)}}
    receipt = publication / "source/primary-compilation.json"
    if damage in {"outer", "s1-report", "metadata"}:
        value = json.loads(receipt.read_bytes())
        if damage == "outer":
            value["outer_fold"] = 5
        elif damage == "s1-report":
            value["s1_consumed_history"]["report"]["sha256"] = "0" * 64
        else:
            value["preparation_metadata"]["result.json"]["sha256"] = "0" * 64
        receipt = tmp_path / "primary-compilation.json"
        receipt.write_bytes(canonical_json_bytes(value))
    producer = root / ("v23-source.zip" if outer == 4 else "b1a-source.zip")
    if damage == "source":
        producer = (s2_root / "source/primary-producer.zip" if outer == 4 else
                    publication / "source/primary-compilation-source.zip")
    s3a = {
        "source/primary-s3a-producer.zip": producer,
        "source/primary-compilation.json": receipt,
        "source/primary-compilation-source.zip": publication / "source/primary-compilation-source.zip",
        "source/primary-compilation-preparation.zip": root / (
            "outer4-s3a-prepared-v23.zip" if outer == 4 else "outer6-s3a-prepared-6335.zip"),
        **{f"primary-s3a/{host}-execution.json": root / f"s3a-executions/{host}-execution.json"
           for host in HOSTS}}
    if damage == "coordinate":
        value = json.loads(s3a["primary-s3a/H0-execution.json"].read_bytes())
        value["task_ids"][0] = value["task_ids"][0] + "-DRIFT"
        changed = tmp_path / "H0-execution.json"
        changed.write_bytes(canonical_json_bytes(value))
        s3a["primary-s3a/H0-execution.json"] = changed
    q_raw = (publication / "input.json").read_bytes()
    if damage == "input":
        q_raw += b"\n"
    call = lambda: f5._primary_rsf_prepared_input(q_raw,
        s2_root / "source/primary-preparation.zip", s2_root / "source/primary-producer.zip",
        s2_evidence=s2, s3a_evidence=s3a)
    if damage:
        with pytest.raises(ContractError):
            call()
    else:
        child, tasks = call()
        assert child["family"] == "RSF"
        assert len(tasks) == 100 and sum(map(len, tasks.values())) == 300
        assert all(row["task_id"].startswith("S3A_") for rows in tasks.values() for row in rows)
