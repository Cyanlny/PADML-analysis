from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from threading import Event, Lock

import pytest

from padml.bundle import ContractError, sha256_bytes
from padml.integrated import qualified_file_pins
from padml.run import _f45_launch_assignments, _f45_remote_command


@pytest.mark.parametrize('curve_only', [False, True])
def test_completed_evaluation_curve_skips_old_dependency_transfers(curve_only):
    units = {'EVALUATION-H06': {'kind': 'EVALUATION', 'depends_on': ['P1','P2']},
             'P1': {'kind': 'PRIMARY'}, 'P2': {'kind': 'PRIMARY'}}
    transfers, starts = [], []
    def transfer(*args, **kwargs): transfers.append(args)
    def call(host, operation, **kwargs):
        assert operation == 'start'
        starts.append(kwargs['assignment'])
        return {'status': 'OWNER_REGISTERED'}
    with ThreadPoolExecutor(max_workers=3) as pool:
        _f45_launch_assignments([{'host':'H0','unit_id':'EVALUATION-H06','mode':'appendage'}],
            units, {'P1':'H1','P2':'H4'}, [], pool=pool, call=call, transfer=transfer,
            post_result_repair=True, curve_only_units={'EVALUATION-H06'} if curve_only else ())
    assert len(starts) == 1
    assert len(transfers) == (0 if curve_only else 4)


@pytest.mark.parametrize('change', [None, 'run', 'source', 'kind', 'status', 'fits', 'sha', 'symlink'])
def test_reviewed_storage_migration_reuses_original_receipt_without_scan(tmp_path, monkeypatch, change):
    from padml import integrated
    from padml.bundle import canonical_json_bytes
    run = {'kind': 'PADML_INTEGRATED_RAW_RUN_V1', 'run_root': str(tmp_path),
        'identity': 'a'*64, 'source_identity': 'b'*64}
    old_run, old_source = 'c'*64, 'd'*64
    monkeypatch.setattr(integrated, 'same_batch_generations', lambda value:
        {run['identity']: run['source_identity'], old_run: old_source})
    body = {'kind': 'PADML_COMPACT_STORAGE_COMPLETION_V1', 'status': 'COMPLETED',
        'run_identity': old_run, 'source_identity': old_source,
        'converted_objects': 140, 'released_unique_inode_bytes': 8192, 'new_model_fits': 0}
    field = {'run': 'run_identity', 'source': 'source_identity', 'kind': 'kind',
             'status': 'status', 'fits': 'new_model_fits'}.get(change)
    if field:
        body[field] = 1 if change == 'fits' else 'INVALID'
    receipt = {**body, 'identity_sha256': integrated._sha(body)}
    if change == 'sha':
        receipt['identity_sha256'] = '0'*64
    path = tmp_path / 'shared' / ('compact-storage-' + old_source + '.json')
    path.parent.mkdir()
    raw = canonical_json_bytes(receipt)
    if change == 'symlink':
        other = path.with_suffix('.original'); other.write_bytes(raw); path.symlink_to(other)
    else:
        path.write_bytes(raw)
    def forbidden(*args, **kwargs):
        pytest.fail('COMPLETED_MIGRATION_MUST_NOT_RESCAN_OR_REWRITE')
    monkeypatch.setattr(Path, 'glob', forbidden)
    monkeypatch.setattr(integrated, '_compact_gbm_retained_job', forbidden)
    monkeypatch.setattr(integrated, '_retire_completed_private_copies', forbidden)
    if change is not None:
        with pytest.raises(ContractError, match='RAW_STORAGE_COMPLETION_DRIFT'):
            integrated.compact_retained_storage(run)
    else:
        assert integrated.compact_retained_storage(run) == receipt
        assert path.read_bytes() == raw
        assert list(path.parent.iterdir()) == [path]


def test_byte_qualification_does_not_substitute_for_first_scientific_consumption(tmp_path):
    source, record = tmp_path / 'numbers', tmp_path / 'qualified.json'
    source.write_bytes(b'1,2,3')
    options = dict(identity='science-input', record=record)
    pin = qualified_file_pins({'n':source}, **options)
    consumed = []
    qualified_file_pins({'n':source}, expected=pin, validate=lambda:consumed.append(1), **options)
    qualified_file_pins({'n':source}, expected=pin, validate=lambda:consumed.append(2), **options)
    assert consumed == [1]
    with pytest.raises(ContractError, match='(QUALIFICATION|QUALIFIED_BYTES)_DRIFT'):
        qualified_file_pins({'n':source}, expected={'n':{'sha256':'f'*64,'size_bytes':5}}, **options)
    source.write_bytes(b'1,2,4')
    with pytest.raises(ContractError, match='BYTES_DRIFT'):
        qualified_file_pins({'n':source}, expected=pin, **options)


def test_cross_consumer_byte_pin_reuses_unchanged_bytes_but_invalidates_changes(tmp_path, monkeypatch):
    from padml import integrated
    source = tmp_path / 'shared'
    source.write_bytes(b'original')
    # The frozen file has passed the filesystem's timestamp ambiguity window.
    import time
    time.sleep(2.01)
    original, reads = integrated._file_pin, []
    def read(path):
        reads.append(path)
        return original(path)
    monkeypatch.setattr(integrated, '_file_pin', read)
    for name in ('producer', 'carrier', 'consumer'):
        pin = qualified_file_pins({name:source}, identity=name, record=tmp_path/(name+'.json'))
        assert pin[name]['sha256'] == sha256_bytes(b'original')
    assert len(reads) == 1
    source.write_bytes(b'changed!')
    qualified_file_pins({'producer':source}, identity='producer', record=tmp_path/'producer.json')
    assert len(reads) == 2


def test_recent_same_stamp_publication_never_reuses_unqualified_bytes(tmp_path, monkeypatch):
    from padml import integrated
    source, record = tmp_path/'fresh', tmp_path/'pin.json'
    source.write_bytes(b'original')
    pin = qualified_file_pins({'n':source}, identity='fresh', record=record)
    assert integrated.strict_json_bytes(record.read_bytes())['stable_stamps'] is False
    source.write_bytes(b'changed!')
    with pytest.raises(ContractError, match='BYTES_DRIFT'):
        qualified_file_pins({'n':source}, identity='fresh', record=record, expected=pin)


def test_shared_mice_preparation_reuses_only_qualified_exact_inputs(tmp_path, monkeypatch):
    from padml import f5, run as runs
    from padml.bundle import sha256_file
    manifest = tmp_path/'run.json'
    manifest.write_text('{}')
    run = {'kind':'PADML_INTEGRATED_RAW_RUN_V1', 'run_root':str(tmp_path), 'source_identity':'f'*64,
           'identity':'a'*64}
    monkeypatch.setattr(runs, 'load_f45_run', lambda path: run)
    monkeypatch.setenv('PADML_F45_RUN_PATH', str(manifest))
    source = tmp_path/'source.zip'; source.write_bytes(b'first qualified MICE source')
    builds = []
    def build(target):
        builds.append(target)
        target.mkdir()
        path = target/'M01.csv'; path.write_bytes(b'Patient_ID,variable\n1,42\n')
        return {'covariates':{'input_dir':str(target), 'members':[{
            'name':path.name, 'sha256':sha256_file(path), 'size_bytes':path.stat().st_size}]}}
    identity = {'role':'ANALYSIS', 'patients':['1'], 'response':'actual training outcomes'}
    original = f5._shared_mice_preparation([source], identity, build)
    assert f5._shared_mice_preparation([source], identity, build) == original
    assert len(builds) == 1
    application = f5._shared_mice_preparation([source], {**identity, 'role':'APPLICATION'}, build)
    assert application != original and len(builds) == 2
    source.write_bytes(b'changed qualified MICE source')
    changed = f5._shared_mice_preparation([source], identity, build)
    assert changed != original and len(builds) == 3
    path = Path(changed['covariates']['input_dir'])/'M01.csv'
    path.write_bytes(b'corrupt')
    with pytest.raises(ContractError, match='BYTES_DRIFT'):
        f5._shared_mice_preparation([source], identity, build)
    assert len(builds) == 3  # Corruption is not permission to replace a published result.


@pytest.mark.parametrize('members', [[], ['shared/oof/a', 'shared/oof/b']])
def test_selection_index_precedes_member_admission_and_empty_closure_starts(members):
    received, events = set(), []
    assignments = [{'host':'target', 'unit_id':'E', 'mode':'selection',
                    'source_unit':'P', 'source_host':'source'}]
    def transfer(source, target, member, **kwargs):
        if kwargs:
            assert 'units/P/postprocess/input.zip' in received
        received.add(member)
    def call(host, operation, **kwargs):
        events.append(operation)
        assert 'units/P/postprocess/input.zip' in received
        if operation == 'dependency_inventory':
            return members
        assert set(members) <= received
        return 'started'
    with ThreadPoolExecutor(max_workers=7) as pool:
        result = _f45_launch_assignments(assignments, {'E':{'kind':'EVALUATION'}}, {}, [],
            pool=pool, call=call, transfer=transfer)
    assert result == ['started'] and events == ['dependency_inventory', 'start']


def test_transfers_are_concurrent_bounded_and_do_not_block_unrelated_start():
    release, three_started, control_started, lock = Event(), Event(), Event(), Lock()
    active, peak, done = 0, 0, set()
    assignments = [{'host':'evaluation', 'unit_id':'E'}, {'host':'compute', 'unit_id':'P'}]
    units = {'E':{'kind':'EVALUATION', 'depends_on':['A','B','C']}, 'P':{'kind':'PRIMARY'}}
    def transfer(source, destination, member):
        nonlocal active, peak
        with lock:
            active += 1
            peak = max(peak, active)
            if active == 3:
                three_started.set()
        assert release.wait(5)
        with lock:
            done.add(member)
            active -= 1
    def call(host, operation, **kwargs):
        if host == 'compute':
            control_started.set()
        else:
            assert len(done) == 6
        return host
    with ThreadPoolExecutor(max_workers=7) as pool, ThreadPoolExecutor(max_workers=1) as driver:
        pending = driver.submit(_f45_launch_assignments, assignments, units,
            dict.fromkeys(['A','B','C'], 'source'), [], pool=pool, call=call, transfer=transfer)
        try:
            assert control_started.wait(3) and three_started.wait(3)
        finally:
            release.set()
        assert pending.result(timeout=5) == ['evaluation', 'compute']
    assert peak == 3


def test_remote_start_uses_wrapper_and_linux_manifest_path():
    run = {'host_connections':{'H0':{'ssh_target':'example', 'port':2200}},
           'environment':{'python':'/opt/runtime/python', 'rscript':'/opt/runtime/Rscript',
                          'r_library':'/opt/runtime/lib'}, 'identity':'f'*64}
    cmd = _f45_remote_command(run, 'H0', Path('/opt/code'), {'run':'/data/run.json'})
    assert '/opt/padml/bin/padml-env' in cmd[-1]
    assert cmd[-1].index('/opt/padml/bin/padml-env') < cmd[-1].index('/opt/code')
    assert '/data/run.json' in cmd[-1]


def test_follow_dispatch_refills_other_hosts_while_transfer_is_pending():
    release, entered = Event(), Event()
    state, starts = {}, []
    def transfer(*args,**kw):
        entered.set(); assert release.wait(10)
    def call(host,op,**kw):
        if op=='dependency_inventory':return []
        starts.append(host);return host
    with ThreadPoolExecutor(max_workers=7) as pool:
        try:
            _f45_launch_assignments([{'host':'slow','unit_id':'E','mode':'selection',
                'source_host':'source','source_unit':'P'}],{'E':{'kind':'EVALUATION'}},{},[],
                pool=pool,call=call,transfer=transfer,inflight=state)
            assert entered.wait(2)
            result=_f45_launch_assignments([{'host':'ready','unit_id':'P'}],{'P':{'kind':'PRIMARY'}},{},[],
                pool=pool,call=call,transfer=transfer,inflight=state)
            import time
            deadline=time.monotonic()+3
            while 'ready' not in starts:
                _f45_launch_assignments([],{}, {},[],pool=pool,call=call,transfer=transfer,inflight=state)
                assert time.monotonic()<deadline
                time.sleep(.01)
            assert any(a['host']=='slow' for a in state['assignments'].values())
        finally:release.set()
        deadline=time.monotonic()+3
        while state['assignments']:
            _f45_launch_assignments([],{}, {},[],pool=pool,call=call,transfer=transfer,inflight=state)
            assert time.monotonic()<deadline
            time.sleep(.01)
        assert starts==['ready','slow']


def test_same_disk_native_reuse_retains_one_inode_and_streams_zip_members(tmp_path):
    import io,os
    from padml.f5 import _f45_retain_final_object
    raw=b'unchanged native object'*4096
    source=tmp_path/'native';source.write_bytes(raw)
    pin={'sha256':sha256_bytes(raw),'size_bytes':len(raw)}
    target=tmp_path/'next-window'
    with source.open('rb') as stream:_f45_retain_final_object(stream,target,pin)
    assert os.path.samestat(source.stat(),target.stat())
    fallback=tmp_path/'zip-member'
    _f45_retain_final_object(io.BytesIO(raw),fallback,pin)
    assert fallback.read_bytes()==raw
    source.unlink();assert target.read_bytes()==raw
def test_selector_scientific_hit_skips_projection_and_reduction(tmp_path, monkeypatch):
    from padml import f5, nested_loco as n
    from padml.bundle import ContractError, canonical_json_bytes
    source = {"raw_context_sha256": "a" * 64}
    value = n._sealed({"source": source, "selected": ["Age"], "selector": {"epv_resolution": {
        "source": "ACCEPTED_F2_SELECTOR", "preferred_minimum": 15, "minimum": 15,
        "fallback_used": False, "selector_evidence_sha256": "e" * 64}}})
    path = tmp_path / "development-input.json"
    path.write_bytes(canonical_json_bytes(value))
    member = tmp_path / "values.json"
    member.write_bytes(b"[1,2,3]")
    monkeypatch.setattr(f5, "_nested_selector_numerical_members", lambda root:
                        {"development-input.json": path, "values.json": member})
    calls = []
    def consume():
        calls.append(1)
        assert member.read_bytes() == b"[1,2,3]"
        return value
    assert f5._qualified_selector_result(tmp_path, source, consume) == value
    assert len(calls) == 1
    assert f5._qualified_selector_result(tmp_path, source, consume) == value
    assert len(calls) == 1
    member.write_bytes(b"[1,2,4]")
    import pytest
    with pytest.raises(AssertionError):
        f5._qualified_selector_result(tmp_path, source, consume)


def _negative_selector_unit(tmp_path, monkeypatch):
    """Synthetic full paths exercise the native reducer/terminal interface only."""
    import json
    import test_selector_epv as e
    from padml import integrated, nested_loco as n, f2_kernel as k
    from padml.bundle import canonical_json_bytes as enc, sha256_file
    base = tmp_path / 'run'; base.mkdir()
    units = [dict(unit_id='PRIMARY-H06-O1', kind='PRIMARY', horizon=6, outer_fold=1,
                  context='OUTER-1', depends_on=[]),
             dict(unit_id='AAR-H06-O1', kind='AAR', horizon=6, outer_fold=1,
                  context='OUTER-1', depends_on=['PRIMARY-H06-O1']),
             dict(unit_id='EVALUATION-H06', kind='EVALUATION', horizon=6,
                  context='EVALUATION-H06', depends_on=['PRIMARY-H06-O1', 'AAR-H06-O1'])]
    run = dict(kind=integrated.RUN_KIND, run_root=str(base), run_id='synthetic-terminal',
               source_identity='b'*64, raw_input={'sha256': 'c'*64, 'size_bytes': 1}, units=units)
    run['identity'] = n._sha(run)
    manifest = tmp_path / 'run.json'; manifest.write_bytes(enc(run))
    monkeypatch.setenv('PADML_F45_RUN_PATH', str(manifest))
    monkeypatch.setenv('PADML_INTEGRATED_RUN', run['identity'])
    source = dict(kind='PADML_NESTED_PRIMARY_SELECTOR_SOURCE_V1', origin='CURRENT_RAW_CONTEXT', context=1)
    def builder(alpha):
        record = e._alpha_record(alpha)
        for row in record['outer_paths']: row['event_count'] = 10
        return record
    records, alphas = e._formal_coarse(builder)
    chosen, _, trace, _ = k._choose_elastic_coarse_epv_tier(records, alphas, e._contract(), formal_frequency_fallback=True)
    selector = dict(source=source, selector=chosen, coarse_alpha_order=alphas, fine_alpha_order=[],
        distinct_alpha_count=7, selector_path_count=7*320, new_mice_chains=0, final_model_fits=0)
    development = n._sealed(dict(kind='PADML_NESTED_PRIMARY_SELECTOR_DEVELOPMENT_V1', source=source,
        selector=chosen, selector_result_sha256=n._sha(selector), selected_alpha_evidence_sha256=None))
    directory = base / 'contexts/OUTER-1/selector'
    members = {'development-input.json': development, 'selector.json': selector,
        'partitions.json': [], 'native-members.json': [], 'recipes/native-values.json': [],
        'recipes/recipes.json': [], 'coarse/paths.json': records}
    for name, value in members.items():
        path = directory / name; path.parent.mkdir(parents=True, exist_ok=True); path.write_bytes(enc(value))
    binding = base / 'binding'; binding.mkdir()
    for name in ('binding.json', 'contract.json'): (binding/name).write_bytes(enc({}))
    for name in ('covariates.csv', 'response-seal.csv'): (binding/name).write_bytes(b'synthetic\n')
    def publish(unit, **kwargs):
        root = base / 'units' / unit['unit_id']; root.mkdir(parents=True, exist_ok=True)
        artifacts = integrated.publish_unit_not_estimable(run, unit, root, **kwargs)
        value = integrated.consume_not_estimable_result(run, unit, root/'result.zip')
        receipt = dict(status='NOT_ESTIMABLE', direct_consumer_completed=True, unit_id=unit['unit_id'],
            run_identity=run['identity'], selection_horizon_months=6,
            estimability=integrated._unit_estimability_summary(value),
            artifacts={path.relative_to(root).as_posix(): {'sha256':sha256_file(path), 'size_bytes':path.stat().st_size}
                       for path in artifacts})
        (root/'unit.json').write_bytes(enc(receipt))
        integrated.consume_unit_estimability(run, unit, root, receipt)
        return root, receipt
    root, receipt = publish(units[0], development=development, selector_root=directory)
    return run, units, root, receipt, publish


def test_negative_selector_direct_consumer_and_dependent_units_do_not_fit(tmp_path, monkeypatch):
    from padml import integrated, f4, f5, worker
    from padml.bundle import canonical_json_bytes
    run, units, root, receipt, publish = _negative_selector_unit(tmp_path, monkeypatch)
    raw = (root/'result.zip').read_bytes()
    def forbidden(*args, **kwargs): pytest.fail('negative outcome cannot run a model or bootstrap')
    monkeypatch.setattr(f4, 'execute_o_fit_bundle', forbidden)
    monkeypatch.setattr(f5, 'execute_final_refit_batch', forbidden)
    monkeypatch.setattr(worker, '_f45_evaluation', forbidden)
    aar_root, aar = publish(units[1], dependencies=[units[0]['unit_id']])
    evaluation_root, evaluation = publish(units[2], dependencies=[units[0]['unit_id']])
    assert aar['estimability']['reason_code'] == evaluation['estimability']['reason_code'] == 'UPSTREAM_PRIMARY_NOT_ESTIMABLE'
    assert (root/'result.zip').read_bytes() == raw
    assert not any(root.parent.rglob('input.zip'))
    assert not any(root.parent.rglob('bootstrap.zip'))
    assert set(receipt['artifacts']) == set(aar['artifacts']) == set(evaluation['artifacts']) == {'result.zip'}
    for unit, directory, result in zip(units, (root, aar_root, evaluation_root), (receipt, aar, evaluation), strict=True):
        assert integrated.consume_unit_estimability(run, unit, directory, result)['status'] == 'NOT_ESTIMABLE'


@pytest.mark.parametrize('damage', ['rule', 'coarse', 'unit', 'reason'])
def test_negative_receipt_rejects_drift_without_any_fit(tmp_path, monkeypatch, damage):
    from padml import integrated, nested_loco as n
    from padml.bundle import canonical_json_bytes as enc, write_deterministic_zip, sha256_file
    from padml.carriers import open_carrier
    run, units, root, receipt, _ = _negative_selector_unit(tmp_path, monkeypatch)
    if damage == 'coarse':
        path = Path(run['run_root'])/'contexts/OUTER-1/selector/coarse/paths.json'
        path.write_bytes(b'[]')
    elif damage == 'unit':
        receipt['unit_id'] = 'PRIMARY-H06-O2'
    elif damage == 'reason':
        receipt['estimability']['reason_code'] = 'RUNTIME_ERROR'
    else:
        path = Path(run['run_root'])/'contexts/OUTER-1/selector/development-input.json'
        import json
        value = json.loads(path.read_bytes()); value['selector']['epv_resolution']['frequency_policy_sha256'] = '0'*64
        path.write_bytes(enc(value))
    with pytest.raises(ContractError):
        integrated.consume_unit_estimability(run, units[0], root, receipt)


def test_negative_selector_archive_is_readable_after_source_goes_offline(tmp_path, monkeypatch):
    import json, shutil
    from padml import integrated, nested_loco as n, reports
    from padml.bundle import canonical_json_bytes as enc, sha256_file
    run, units, root, receipt, _ = _negative_selector_unit(tmp_path, monkeypatch)
    inventory = reports.archive_inventory(run, 6, [units[0]['unit_id']], [])
    assert inventory['not_estimable_units'] == [units[0]['unit_id']]
    assert not any('postprocess' in name or 'final' in name for name in inventory['members'])
    archive = tmp_path/'archive'; (archive/'objects').mkdir(parents=True)
    members = {}
    for name, pin in inventory['members'].items():
        storage = 'objects/' + pin['sha256']; target = archive/storage
        if not target.exists(): shutil.copyfile(Path(run['run_root'])/name, target)
        members[name] = {'pin':{key:pin[key] for key in ('sha256','size_bytes')}, 'storage':storage,
            'member':None, 'physical':{'sha256':sha256_file(target),'size_bytes':target.stat().st_size}}
    index = n._sealed({'kind':'PADML_WINDOW_ARCHIVE_INDEX_V1', 'run_identity':run['identity'],
        'source_identity':run['source_identity'], 'windows':{}, 'members':members})
    path = archive/'index.json'; path.write_bytes(enc(index))
    monkeypatch.setenv('PADML_ARCHIVE_INDEX', str(path))
    shutil.rmtree(Path(run['run_root']))
    assert integrated.consume_unit_estimability(run, units[0], root, receipt)['status'] == 'NOT_ESTIMABLE'


@pytest.mark.parametrize('state',['hit','absent','byte_only','binding','stamp','recent'])
def test_cached_only_never_hashes_validates_or_writes_on_miss(tmp_path,monkeypatch,state):
    import time
    from padml import integrated
    from padml.bundle import canonical_json_bytes as enc, strict_json_bytes
    source=tmp_path/'source';record=tmp_path/'qualified.json';source.write_bytes(b'ORIGINAL')
    now=time.time_ns();monkeypatch.setattr(time,'time_ns',lambda:now+3_000_000_000)
    validate=lambda:None
    if state!='absent':
        expected=integrated.qualified_file_pins({'v':source},identity='CURRENT',record=record,
            validate=None if state=='byte_only' else validate)
    identity='OTHER' if state=='binding' else 'CURRENT'
    if state=='stamp':
        import os
        before = source.stat()
        source.write_bytes(b'CHANGED!')
        # A changed-stamp case is separate from real-clock recent writes.
        os.utime(source, ns=(before.st_atime_ns, before.st_mtime_ns + 3_000_000_000))
    if state=='recent':
        value=strict_json_bytes(record.read_bytes());value['stable_stamps']=False;record.write_bytes(enc(value))
    before=record.read_bytes() if record.exists() else None
    def forbidden(*a,**k):pytest.fail('PARENT_MAY_NOT_REHASH_OR_RUN_SCIENTIFIC_READER')
    monkeypatch.setattr(integrated,'_file_pin',forbidden)
    value=integrated.qualified_file_pins({'v':source},identity=identity,record=record,
        validate=forbidden,cached_only=True)
    assert (value==expected if state=='hit' else value is None)
    assert (record.read_bytes() if record.exists() else None)==before


def test_sensitivity_credits_only_remaining_atoms_without_reducing_reservation(tmp_path,monkeypatch):
    from padml import runtime, diagnostics
    from types import SimpleNamespace
    from padml import f2_kernel as k
    policy=dict(configured_worker_ceiling=runtime.CPU_MINUS_8,memory_bytes_per_worker=2*1024**3,
        scratch_bytes_per_worker=1024,memory_reserve_bytes=0,scratch_reserve_bytes=0,transfer_archive_worker_ceiling=1)
    run=dict(run_root=str(tmp_path),source_identity='a'*64,resource_policy=policy)
    # This existing resource-only fixture does not establish numerical validity.
    dependencies={'fixture':'RESOURCE_ONLY_UNFITTED'}
    monkeypatch.setattr(diagnostics,'_sensitivity_sources',lambda run:(dependencies,[run['source_identity']]))
    monkeypatch.setattr(diagnostics,'_sensitivity_validate_native',lambda value,task:value)
    monkeypatch.setattr(runtime,'effective_cpu_count',lambda:32)
    monkeypatch.setattr(runtime,'observe_execution_resources',lambda root:dict(effective_cpus=32,
        available_memory_bytes=10**12,scratch_available_bytes=10**12,scratch_root=str(root)))
    monkeypatch.setattr(k,'selected_route_profiles',lambda **kw:{name:dict(profile={},selection='UNFITTED',admission_identity='a'*64)
        for name in ('F2_SELECTOR_MRMRE','F2_SELECTOR_BORUTA')})
    monkeypatch.setattr(k,'execution_mode',lambda p:'UNFITTED')
    projections=[]
    def projection(*a,imputations,**kw):projections.append(imputations);return {}
    monkeypatch.setattr(k,'_recipe_partition_projection',projection)
    def method(spec,scope,method,projection,scratch,package,shared_call_args=None,prepared_rows=None):
        if shared_call_args is not None:
            start=len(shared_call_args)
            for imp in range(1,21):shared_call_args.append(({'sensitivity_task':{'method':method,'imputation':imp,
                'task_spec_record':{'method':method,'imputation':imp}}},str(scratch),str(package)))
            return {'start':start}
        assert len(prepared_rows)==20 and [x['imputation'] for x in prepared_rows]==list(range(1,21))
        return {'status':'PASS','threshold_sets':{f'{n}/20':[] for n in (12,14,16)}}
    monkeypatch.setattr(k,'_run_selector_sensitivity_method',method)
    monkeypatch.setattr(k,'_run_r_selector_sensitivity_shared_pool_task',lambda call:{'method':call[0]['sensitivity_task']['method'],
        'imputation':call[0]['sensitivity_task']['imputation'],'kind':'UNFITTED'})
    cache=tmp_path/'shared/selector-sensitivity';cache.mkdir(parents=True)
    for method in ('MRMRE','BORUTA'):
        for imp in range(1,20):
            identity=diagnostics._sensitivity_compute_identity({'method':method,'imputation':imp},dependencies)
            diagnostics._save(cache/(identity+'.json'),{'input_identity':identity,'producer':run['source_identity'],'value':{'method':method,'imputation':imp,'kind':'UNFITTED'}})
    admissions=[];original_admit=runtime.admit_stage
    def admit(policy,root,**values):admissions.append(values);return original_admit(policy,root,**values)
    monkeypatch.setattr(runtime,'admit_stage',admit)
    batches=[]
    def pool(worker,jobs,**kw):batches.append(jobs);assert kw['schedule_order']==[1,0];return [worker(j) for j in jobs]
    monkeypatch.setattr(runtime,'_bounded_ordered_spawn',pool)
    training={'partition_id':'FULL','fit_ids':['UNFITTED'],'fit_response':{},'fit_covariate_members':[],
        'covariates':{'members':[{'size_bytes':101}],'analysis_view_sha256':'b'*64}}
    result=diagnostics._sensitivity(run,{'kind':'FULL0'},training,{'selector':{'epv_resolution':{'minimum':15}}},tmp_path)
    assert result['status']=='PASS' and projections==[[],[20]] and len(batches)==1 and len(batches[0])==2
    amount=1024**2
    assert admissions[0]['retained_bytes']==admissions[0]['publication_bytes']==2*amount
    assert admissions[0]['task_disk_bytes']==[(amount,2*amount)]*2
    # Original runtime computes remaining future bytes only after scientific OK;
    # publication stays conservative instead of dividing the global allowance.
    real_pool=runtime._ReadyPool(policy,tmp_path,2,{})
    batch=SimpleNamespace(estimates={**admissions[0],'memory_bytes_per_worker':2*1024**3},results=[runtime._READY_MISSING]*2,pending=[0,1],active=0)
    before=real_pool._admission([batch])['disk_peak']
    batch.results[1]={'status':'SCIENTIFIC_OK'};batch.pending=[0]
    after=real_pool._admission([batch])['disk_peak']
    assert (before['future_retained_bytes'],after['future_retained_bytes'])==(2*amount,amount)
    assert before['publication_bytes']==after['publication_bytes']==2*amount


def test_integrated_reexec_and_child_use_one_data_bytecode_policy(tmp_path, monkeypatch):
    import os
    import sys
    from padml import integrated, runtime
    from padml.bundle import canonical_json_bytes
    environment = {'python':sys.executable,'rscript':sys.executable,'r_library':str(tmp_path/'r-library')}
    run = {'environment':environment,'identity':'a'*64,'run_root':str(tmp_path/'data/runs/current')}
    path = tmp_path/'run.json';path.write_bytes(canonical_json_bytes(run))
    monkeypatch.setattr(integrated,'is_integrated',lambda _:True)
    monkeypatch.delenv('PADML_ENV_REEXEC',raising=False)
    monkeypatch.setenv('PYTHONDONTWRITEBYTECODE','1')
    calls=[]
    monkeypatch.setattr(os,'execve',lambda executable,args,env:calls.append(dict(env)))
    integrated.configure_environment(path)
    assert len(calls)==1
    expected=calls[0]
    assert expected['PYTHONPYCACHEPREFIX']==str(tmp_path/'data/cache/python')
    assert expected['PYTHONDONTWRITEBYTECODE']==''
    for key,value in expected.items():monkeypatch.setenv(key,value)
    integrated.configure_environment(path)
    assert len(calls)==1, 'Already matching worker must not reexec again'
    child=runtime.activated_environment()
    assert child['PYTHONPYCACHEPREFIX']==expected['PYTHONPYCACHEPREFIX']
    assert child['PYTHONDONTWRITEBYTECODE']==expected['PYTHONDONTWRITEBYTECODE']


def test_legacy_without_data_bytecode_prefix_stays_read_only(monkeypatch):
    from padml import runtime
    monkeypatch.delenv('PYTHONPYCACHEPREFIX',raising=False)
    monkeypatch.setitem(runtime.REMOTE_ENV,'PYTHONDONTWRITEBYTECODE','1')
    assert runtime.activated_environment()['PYTHONDONTWRITEBYTECODE']=='1'


"""Contract-only cache recovery: no native process or scientific fit runs."""
import copy
from pathlib import Path
import zipfile
import pytest
from padml import f2_kernel as k, f4, run as runs, runtime
from padml import nested_loco as n
from padml.bundle import ContractError, sha256_bytes, canonical_json_bytes

ROOT = Path(k.__file__).resolve().parents[1]

@pytest.fixture
def d():
    from padml import diagnostics
    return diagnostics

@pytest.fixture
def dependency(d):
    members = {name: sha256_bytes((ROOT/name).read_bytes()) for name in d._SENSITIVITY_NATIVE_MEMBERS}
    raw = (ROOT/'padml/f2_kernel.py').read_bytes()
    members['padml/f2_kernel.py'] = sha256_bytes(raw)
    members['padml/bundle.py'] = sha256_bytes((ROOT/'padml/bundle.py').read_bytes())
    members['README.md'] = 'a'*64
    return members, raw, d._sensitivity_dependencies(members, raw, (ROOT/'padml/bundle.py').read_bytes())


def fixture_calls(tmp_path):
    contract = k.selector_sensitivity_contract()
    versions = __import__('json').loads((ROOT/'dependency-lock.json').read_text())['engine_contract_versions']
    contract['mrmre']['version'] = versions['mRMRe']
    contract['boruta']['ranger_version'] = versions['ranger']
    predictors = k.predictor_contract(ROOT/'padml')
    members = [{'name': f'imp{i:02d}.csv', 'sha256': n._sha({'fixture_mi':i}), 'size_bytes': 101} for i in range(1,21)]
    fit_ids = ['ENGINEERING-FIXTURE']
    response = {'sha256':'r'.replace('r','b')*64, 'size_bytes':100, 'path':str(tmp_path/'response.csv')}
    scope = {'partition_id':'OLD_OUTER_CONTEXT', 'fit_ids':fit_ids, 'fit_response':response}
    projection = {'analysis_view_sha256':'c'*64, 'fit_ids_sha256':n._sha(fit_ids),
        'recipe_registry_record':{'members':members,'fit_ids':fit_ids,'input_dir':str(tmp_path)}}
    spec = {'fold':0,'heldout_center':0,'integrated_diagnostic':True,'predictors':predictors,
        'outcome':'All_Cause_Death','time':'Death_Followup_months','selector_sensitivity_contract':contract,
        'selector_sensitivity_profiles':{method:{'selection':'SELECTED','admission_identity':'d'*64,
            'execution':{'execution_mode':'PROCESS_POOL','threads':24,'pool_workers':24,'engine_threads':1}}
            for method in ('MRMRE','BORUTA')}}
    calls=[]
    for method in ('MRMRE','BORUTA'):
        k._run_selector_sensitivity_method(spec,scope,method,projection,tmp_path,ROOT/'padml',shared_call_args=calls)
    return calls, projection, scope


def native_fixture(call):
    task=call[0]['sensitivity_task']; record=copy.deepcopy(task['task_spec_record'])
    count=record['candidate_parent_count']; method=record['method']
    if method == 'MRMRE':
        health={'schema_version':'1.0.0','implementation':f"mRMRe-{record['package_versions']['mRMRe']}/association-ties-v1",
            'association_count':(count+1)*count,'finite_association_count':(count+1)*count,'finite_mi_count':(count+1)*count,
            'reference_count':count,'score_count':count,'finite_score_count':count,'max_abs_reference_delta':0,
            'warning_count':0,'warnings':[]}
        result={'ranking':list(task['candidate_parents'])}
    else:
        health={'schema_version':'1.0.0','implementation':'Boruta-getImpRfZ-pre-substitution-v1',
            'importance_calls':2,'checked_value_count':4*count,'length_checks':2,'name_checks':2,'finite_checks':2,
            'nonfinite_count':0,'warning_count':0,'warnings':[]}
        result={'decisions':{p:'Rejected' for p in task['candidate_parents']}}
    echo={'task_spec_sha256':n._sha(record),'method':method,'imputation':record['imputation'],'seed':record['seed'],
        'candidate_parent_count':count,'package_versions':record['package_versions'],'thread_count':1,'numerical_health':health}
    return {'schema_version':'1.1.0','kind':'PADML_F2_SELECTOR_SENSITIVITY_TASK','status':'PASS',
        'task_id':record['task_id'],'result':result,'task_spec_record':record, **echo,
        'task_echo':copy.deepcopy(echo),'task_echo_sha256':n._sha(echo)}


def save_old(d, cache, call, producer):
    task=call[0]['sensitivity_task']['task_spec_record']
    identity=n._sha({'task':d._sensitivity_task_input(task),'producer':producer})
    path=cache/(identity+'.json')
    d._save(path,{'input_identity':identity,'value':native_fixture(call)})
    return path


def test_doc_and_unrelated_python_change_preserve_compute_dependencies(d,dependency):
    members, raw, expected=dependency
    members={**members,'README.md':'b'*64}
    # Appending unrelated code or changing one unrelated import cannot invalidate ranks.
    changed=raw+b'\n\ndef not_a_selector_dependency():\n    return 42\n'
    members['padml/f2_kernel.py']=sha256_bytes(changed)
    assert d._sensitivity_dependencies(members,changed,(ROOT/'padml/bundle.py').read_bytes())==expected

@pytest.mark.parametrize('field',['seed_adapter','R_parameters','design_R','dependency_lock','native_patch'])
def test_actual_adapter_kernel_and_lock_drift_invalidate(d,dependency,field):
    members,raw,expected=copy.deepcopy(dependency)
    if field=='seed_adapter':
        raw=raw.replace(b'policy["base"]\n        + spec["fold"]',b'policy["base"] + 1\n        + spec["fold"]')
        assert sha256_bytes(raw)!=members['padml/f2_kernel.py']
        members['padml/f2_kernel.py']=sha256_bytes(raw)
    else:
        member={'R_parameters':'padml/kernels/f2_model_development.R','design_R':'padml/kernels/f5_design.R',
            'dependency_lock':'dependency-lock.json','native_patch':'padml/kernels/native/ranger-performance.patch'}[field]
        members[member]='f'*64
    assert d._sensitivity_dependencies(members,raw,(ROOT/'padml/bundle.py').read_bytes())!=expected


@pytest.mark.parametrize('pin_kind',["unit_predecessor","unit_source_predecessors"])
def test_only_audited_predecessors_with_same_native_dependencies_qualify(d,dependency,tmp_path,monkeypatch,pin_kind):
    import json
    members,raw,expected=dependency
    changed=raw+b'\n\ndef irrelevant_other_model_helper():\n    return None\n'
    old_bundle=(ROOT/'padml/bundle.py').read_bytes().replace(b'def write_deterministic_zip(',b'def unrelated_zip_writer(')
    old_members={**members,'README.md':'b'*64,'padml/f2_kernel.py':sha256_bytes(changed),
        'padml/bundle.py':sha256_bytes(old_bundle)}
    archive=tmp_path/'source.zip'
    with zipfile.ZipFile(archive,'w') as z:
        z.writestr('padml/f2_kernel.py',changed)
        z.writestr('padml/bundle.py',old_bundle)
    previous={'identity':'b'*64,'source_identity':n._sha(old_members),'source_bundle_sha256':sha256_bytes(archive.read_bytes())}
    previous_path=tmp_path/'run.json';previous_path.write_text(json.dumps(previous,indent=2)+'\n')
    pin={'source_sha256':previous['source_bundle_sha256'],'run_sha256':sha256_bytes(previous_path.read_bytes()),
        'source_path':str(archive),'run_path':str(previous_path)}
    assert pin['run_sha256']!=n._sha(previous), 'Physical bytes must not be guessed from parsed JSON'
    run={'kind':'PADML_INTEGRATED_RAW_RUN_V1','source_identity':n._sha(members),
        pin_kind:pin if pin_kind=='unit_predecessor' else [pin]}
    seen=[]
    monkeypatch.setattr(f4,'_f45_source_member_sha256',lambda:members)
    def qualified(run):
        # Only this boundary is mocked: original production predecessor admission
        # remains responsible for exact science/byte/source-pair qualification.
        assert sha256_bytes(previous_path.read_bytes())==pin['run_sha256']
        assert sha256_bytes(archive.read_bytes())==pin['source_sha256']
        seen.append('qualified chain');return [previous]
    monkeypatch.setattr(runs,'f45_unit_predecessors',qualified)
    def manifest(path):
        assert seen and path==archive
        return {'members':[{'path':name,'sha256':sha} for name,sha in old_members.items()]}
    monkeypatch.setattr(f4,'load_f45_source_bundle',manifest)
    dependencies,producers=d._sensitivity_sources(run)
    assert dependencies==expected and producers==[run['source_identity'],previous['source_identity']]
    assert seen==['qualified chain']
    monkeypatch.setattr(runs,'f45_unit_predecessors',lambda run:(_ for _ in ()).throw(ContractError('RAW_PREDECESSOR_SOURCE_DRIFT')))
    with pytest.raises(ContractError,match='PREDECESSOR_SOURCE_DRIFT'):d._sensitivity_sources(run)


def test_old_missing_adapter_helper_is_only_a_miss(d,dependency):
    members,raw,expected=dependency
    changed=raw.replace(b'def _recipe_training_rows_bytes(',b'def old_recipe_rows(')
    members={**members,'padml/f2_kernel.py':sha256_bytes(changed)}
    assert d._sensitivity_dependencies(members,changed,(ROOT/'padml/bundle.py').read_bytes()) is None



def test_39_old_plus_1_calls_original_reducer_without_copying_or_rebinding(d,dependency,tmp_path,monkeypatch):
    calls,projection,scope=fixture_calls(tmp_path)
    cache=tmp_path/'shared/selector-sensitivity';cache.mkdir(parents=True)
    original={path:path.read_bytes() for path in [save_old(d,cache,call,'b'*64) for call in calls[:39]]}
    actual=[]
    def native(call):actual.append(call[0]['sensitivity_task']['task_id']);return native_fixture(call)
    monkeypatch.setattr(k,'_run_r_selector_sensitivity_shared_pool_task',native)
    monkeypatch.setattr(d,'_sensitivity_sources',lambda run:(dependency[2],['a'*64,'b'*64]))
    monkeypatch.setattr(runtime,'resolve_pool_workers',lambda _:24)
    monkeypatch.setattr(runtime,'admit_stage',lambda *a,**kw:{'admitted_worker_ceiling':24})
    batches=[]
    def pool(fn,jobs,**kw):batches.append(len(jobs));return [fn(job) for job in jobs]
    monkeypatch.setattr(runtime,'_bounded_ordered_spawn',pool)
    monkeypatch.setattr(k,'selected_route_profiles',lambda **kw:{name:{'profile':{},'selection':'SELECTED','admission_identity':'d'*64}
        for name in ('F2_SELECTOR_MRMRE','F2_SELECTOR_BORUTA')})
    monkeypatch.setattr(k,'execution_mode',lambda profile:'PROCESS_POOL')
    projection_calls=[]
    def project(*args,imputations,**kw):projection_calls.append(imputations);return projection
    monkeypatch.setattr(k,'_recipe_partition_projection',project)
    monkeypatch.setattr(k,'_response_arrays',lambda *a:([1.0]*400,[1]*400))
    training={'partition_id':'NEW_OUTER_CONTEXT','fit_ids':scope['fit_ids'],'fit_response':scope['fit_response'],
        'fit_covariate_members':projection['recipe_registry_record']['members'],
        'covariates':{'members':projection['recipe_registry_record']['members'],'analysis_view_sha256':projection['analysis_view_sha256']}}
    run={'run_root':str(tmp_path),'source_identity':'a'*64,'resource_policy':{'scratch_bytes_per_worker':1024}}
    result=d._sensitivity(run,{'kind':'FULL0'},training,{'selector':{'epv_resolution':{'minimum':15}}},tmp_path)
    assert actual==['BORUTA_F0_M20'] and batches==[1] and projection_calls==[[],[20]]
    assert all(path.read_bytes()==raw for path,raw in original.items()) and len(list(cache.glob('*.json')))==40
    for method in ('MRMRE','BORUTA'):
        assert result['methods'][method]['task_count']==20
        record=result['methods'][method]['private_records'][0]
        old=original[next(p for p in original if d._read(p)['value']['task_id']==f'{method}_F0_M01')]
        prior=__import__('json').loads(old)['value']
        assert record['task_spec']['outer_partition_id']=='OLD_OUTER_CONTEXT'
        assert record['task_spec']==prior['task_spec_record']
        assert record['task_spec_sha256']==prior['task_spec_sha256']
        assert record['task_echo']==prior['task_echo'] and record['task_echo_sha256']==prior['task_echo_sha256']
    # A second pass consumes the original 39 and new one; no fit or projection bytes.
    again=d._sensitivity(run,{'kind':'FULL0'},training,{'selector':{'epv_resolution':{'minimum':10}}},tmp_path)
    assert actual==['BORUTA_F0_M20'] and batches==[1] and projection_calls==[[],[20],[]]
    assert again['locked_epv_minimum']==10 and len(list(cache.glob('*.json')))==40


def test_single_mi_changes_only_two_method_atoms_and_seed_changes_one(d,dependency,tmp_path):
    calls,_,_=fixture_calls(tmp_path);cache=tmp_path/'cache';cache.mkdir()
    for call in calls:save_old(d,cache,call,'b'*64)
    updated=copy.deepcopy(calls)
    for call in updated:
        record=call[0]['sensitivity_task']['task_spec_record']
        record['fit_covariate_member_set_sha256']='e'*64
        record['analysis_view_sha256']='e'*64
        if record['imputation']==7:record['covariate_member']['sha256']='f'*64
    jobs=[d._sensitivity_job(call,cache,dependency[2],['a'*64,'b'*64]) for call in updated]
    assert [j[0][0]['sensitivity_task']['task_id'] for j in jobs if not Path(j[1]).exists()]==['MRMRE_F0_M07','BORUTA_F0_M07']
    one=copy.deepcopy(calls[0]);one[0]['sensitivity_task']['task_spec_record']['seed']+=1
    assert not Path(d._sensitivity_job(one,cache,dependency[2],['a'*64,'b'*64])[1]).exists()

@pytest.mark.parametrize('damage',['seal','health','ranking','unknown_producer','failed_atom','missing_input'])
def test_bad_cache_is_rejected_without_fit_or_replacement(d,dependency,tmp_path,monkeypatch,damage):
    call=fixture_calls(tmp_path)[0][0];cache=tmp_path/'cache';cache.mkdir()
    path=save_old(d,cache,call,'b'*64)
    job=d._sensitivity_job(call,cache,dependency[2],['a'*64,'b'*64])
    saved=d._read(path)
    if damage=='seal':saved['identity_sha256']='f'*64
    elif damage=='health':
        saved['value']['numerical_health']['finite_mi_count']=0
        saved['value']['task_echo']['numerical_health']=copy.deepcopy(saved['value']['numerical_health'])
        saved['value']['task_echo_sha256']=n._sha(saved['value']['task_echo'])
    elif damage=='ranking':saved['value']['result']['ranking'].pop()
    elif damage=='unknown_producer':job=(*job[:3],['a'*64],job[-1])
    elif damage=='failed_atom':saved['value']={'kind':'PADML_F2_SELECTOR_SENSITIVITY_SHARED_POOL_FAILURE','method':'MRMRE','imputation':1}
    elif damage=='missing_input':saved['value'].pop('task_spec_record')
    if damage not in {'seal','unknown_producer'}:saved=n._sealed({k:v for k,v in saved.items() if k!='identity_sha256'})
    path.write_bytes(canonical_json_bytes(saved));before=path.read_bytes()
    monkeypatch.setattr(k,'_run_r_selector_sensitivity_shared_pool_task',lambda _:pytest.fail('must not fit'))
    with pytest.raises(ContractError):d._sensitivity_atom(job)
    assert path.read_bytes()==before and len(list(cache.glob('*.json')))==1


def test_new_typed_failure_is_not_published_as_completed_atom(d,dependency,tmp_path,monkeypatch):
    call=fixture_calls(tmp_path)[0][0]
    job=d._sensitivity_job(call,tmp_path,dependency[2],['a'*64])
    failure={'kind':'PADML_F2_SELECTOR_SENSITIVITY_SHARED_POOL_FAILURE','method':'MRMRE','imputation':1,
        'reason':'F2_MRMRE_ENGINE_FIT_FAILED'}
    monkeypatch.setattr(k,'_run_r_selector_sensitivity_shared_pool_task',lambda _:failure)
    assert d._sensitivity_atom(job)==failure and not Path(job[1]).exists()


@pytest.mark.parametrize('change',['zip_writer','required_json_reader'])
def test_bundle_writer_is_not_native_dependency_but_json_reader_is(d,dependency,change):
    members,adapter,expected=dependency
    raw=(ROOT/'padml/bundle.py').read_bytes()
    if change=='zip_writer':
        old=b'def write_deterministic_zip('
        new=b'def changed_unrelated_zip_writer('
    else:
        old=b'errors="strict"'
        new=b'errors="ignore"'
    changed=raw.replace(old,new)
    assert changed!=raw
    members={**members,'padml/bundle.py':sha256_bytes(changed)}
    observed=d._sensitivity_dependencies(members,adapter,changed)
    assert (observed==expected)==(change=='zip_writer')


def _natural_recovery_case(tmp_path, monkeypatch):
    from padml import diagnostics, run as runs
    from padml import nested_loco as n
    root = tmp_path.resolve()
    folder = root / 'diagnostics'; folder.mkdir()
    run = {'kind': 'PADML_INTEGRATED_RAW_RUN_V1', 'identity': 'c'*64,
        'source_identity': 'b'*64, 'run_root': str(root),
        'environment': {'rscript': 'FORBIDDEN_RSCRIPT'}, 'resource_policy': {}}
    previous = {'identity': 'd'*64, 'source_identity': 'a'*64}
    monkeypatch.setattr(runs, 'f45_unit_predecessors', lambda value: [previous])
    context = {'source': {'UNFITTED': 'same qualified scientific input'}}
    development = {'transform_recipes': {'recipes': []}}
    def location(producer):
        key = n._sha({'source': context['source'], 'recipes': development['transform_recipes'],
                      'penalty_factor': 1, 'producer': producer})
        return key, root / 'shared/natural-selector' / key
    return diagnostics, run, context, development, folder, location


def test_natural_completed_predecessor_publish_tail_is_zero_fit(tmp_path, monkeypatch):
    d, run, context, development, folder, location = _natural_recovery_case(tmp_path, monkeypatch)
    key, original = location('a'*64); original.mkdir(parents=True)
    current = location(run['source_identity'])[1]; current.mkdir()
    saved = d._save(original / 'diagnostic.json', {'kind': 'PADML_AST_ALT_NATURAL_DIAGNOSTIC_V1',
        'input_identity': key, 'result': {'UNFITTED': True}, 'status': 'PASS',
        'penalty_factor': 1, 'success_threshold': None, 'primary_writeback': 'FORBIDDEN'})
    before = (original / 'diagnostic.json').read_bytes()
    monkeypatch.setattr(f4, '_full_pipeline_selector_search',
        lambda *a, **k: pytest.fail('A completed old diagnostic must not start another search'))
    assert d._natural(run, context, [], development, folder) == saved
    assert (original / 'diagnostic.json').read_bytes() == before
    assert not list(current.iterdir())


@pytest.mark.parametrize('phase', ['coarse', 'fine'])
def test_natural_partial_predecessor_keeps_root_and_publication_identity(tmp_path, monkeypatch, phase):
    d, run, context, development, folder, location = _natural_recovery_case(tmp_path, monkeypatch)
    key, original = location('a'*64)
    atom = original / phase / 'R1_K1_M01/native'; atom.mkdir(parents=True)
    evidence = atom / 'spec.json'; evidence.write_bytes(b'UNFITTED_ORIGINAL_SPEC')
    if phase == 'fine':
        coarse = original / 'coarse'; coarse.mkdir()
        (coarse / 'paths.json').write_bytes(b'UNFITTED_COMPLETED_COARSE')
    current = location(run['source_identity'])[1]; current.mkdir()
    before = {p: p.read_bytes() for p in original.rglob('*') if p.is_file()}
    seen = []
    def resume(source, parts, target, **options):
        seen.append(target)
        assert target == original and source['ast_alt_natural_audit'] is True
        assert options['replay'] is False and options['rscript'] == 'FORBIDDEN_RSCRIPT'
        return {'UNFITTED': 'original phase reader boundary'}, {}
    monkeypatch.setattr(f4, '_full_pipeline_selector_search', resume)
    monkeypatch.setattr(runtime, 'resolve_pool_workers', lambda _: 24)
    value = d._natural(run, context, [], development, folder)
    assert seen == [original] and value['input_identity'] == key
    assert all(p.read_bytes() == raw for p, raw in before.items())
    assert not list(current.iterdir())


@pytest.mark.parametrize('damage', ['result_seal', 'input_identity', 'predecessor_pin'])
def test_natural_old_result_drift_cannot_start_a_replacement(tmp_path, monkeypatch, damage):
    d, run, context, development, folder, location = _natural_recovery_case(tmp_path, monkeypatch)
    key, original = location('a'*64); original.mkdir(parents=True)
    value = n._sealed({'input_identity': key, 'result': {'UNFITTED': True}})
    if damage == 'result_seal': value['identity_sha256'] = 'e'*64
    elif damage == 'input_identity': value = n._sealed({'input_identity': 'e'*64, 'result': {}})
    else:
        def bad_chain(value): raise ContractError('RAW_PREDECESSOR_SOURCE_DRIFT')
        monkeypatch.setattr(runs, 'f45_unit_predecessors', bad_chain)
    path = original / 'diagnostic.json'; path.write_bytes(canonical_json_bytes(value)); before = path.read_bytes()
    monkeypatch.setattr(f4, '_full_pipeline_selector_search', lambda *a, **k: pytest.fail('No replacement fit'))
    with pytest.raises(ContractError, match='DIAGNOSTIC_NATIVE_DRIFT|RAW_PREDECESSOR_SOURCE_DRIFT'):
        d._natural(run, context, [], development, folder)
    assert path.read_bytes() == before and not location(run['source_identity'])[1].exists()


"""Small engineering boundaries; all scientific and remote entry points are stubbed."""
from concurrent.futures import ThreadPoolExecutor, wait
from pathlib import Path
import json
import os
import platform
import re
import subprocess

import pytest

from padml import run as runs
from padml.bundle import ContractError


def _without_launch_attempt(value):
    return {key: item for key, item in value.items() if key != 'attempt_id'}


def _quarantine_case(root):
    units = [
        dict(unit_id='PRIMARY-H06-O5', kind='PRIMARY', horizon=6, context='OUTER-5', depends_on=[]),
        dict(unit_id='PRIMARY-H12-O5', kind='PRIMARY', horizon=12, context='OUTER-5', depends_on=['PRIMARY-H06-O5']),
        dict(unit_id='PRIMARY-H06-O1', kind='PRIMARY', horizon=6, context='OUTER-1', depends_on=[]),
        dict(unit_id='AAR-H06-O1', kind='AAR', horizon=6, context='OUTER-1', depends_on=['PRIMARY-H06-O1']),
        dict(unit_id='EVALUATION-H06', kind='EVALUATION', horizon=6, context='EVALUATION', depends_on=['AAR-H06-O1']),
    ]
    run = dict(kind='PADML_INTEGRATED_RAW_RUN_V1', identity='a'*64,
        source_identity='b'*64, run_root=str(root), units=units,
        host_connections={h: {'ssh_target': 'UNUSED', 'port': 22} for h in runs.F45_HOSTS})
    observed = {h: dict(state='IDLE', active_unit=None, completed_units=[], local_contexts=[],
        evaluation_ready_units=[], postprocess_ready_units=[], selection_completed_units=[])
        for h in runs.F45_HOSTS}
    observed['H7-3'].update(state='UNKNOWN', active_unit='PRIMARY-H06-O5', active_mode='execute',
        active_source_unit=None, local_contexts=['OUTER-5'],
        reason='OWNER_EXIT_OR_REGISTERED_GROUP_REQUIRES_RESOLUTION')
    observed['H1'].update(local_contexts=['OUTER-1'], completed_units=['PRIMARY-H06-O1'],
        evaluation_ready_units=['PRIMARY-H06-O1'])
    return run, observed


@pytest.mark.parametrize('mode', ['execute', 'selection'])
def test_failed_owner_observation_keeps_verified_coordinates(tmp_path, monkeypatch, mode):
    run, _ = _quarantine_case(tmp_path)
    unit = 'EVALUATION-H06' if mode == 'selection' else 'PRIMARY-H06-O5'
    source = 'PRIMARY-H06-O5' if mode == 'selection' else None
    owner = dict(pid=900001, pgid=900001, unit_id=unit, run_identity=run['identity'],
        mode=mode, source_unit=source)
    raw = (json.dumps(owner)+'\n'+json.dumps(dict(pgid=900001, exit_status='FAILED'))+'\n').encode()
    path = tmp_path/'active.lock'; path.write_bytes(raw); inode = path.stat().st_ino
    monkeypatch.setattr(runs, 'f45_unit_predecessors', lambda _: [])
    def ps(command, **kwargs):
        assert command == ['ps', '-eo', 'pid=,pgid=']
        return subprocess.CompletedProcess(command, 0, stdout=f'{os.getpid()} {os.getpgrp()}\n', stderr='')
    monkeypatch.setattr(subprocess, 'run', ps)
    value = runs._f45_host_observation(run)
    assert value['state'] == 'UNKNOWN'
    assert (value.get('active_unit'), value.get('active_mode'), value.get('active_source_unit')) == (unit, mode, source)
    assert path.read_bytes() == raw and path.stat().st_ino == inode


def test_known_unknown_reserves_its_context_but_allows_independent_aar(tmp_path):
    run, observed = _quarantine_case(tmp_path)
    assert runs.f45_ready_assignments(run, observed) == [{'host': 'H1', 'unit_id': 'AAR-H06-O1'}]


def test_anonymous_unknown_still_blocks_new_scientific_dispatch(tmp_path):
    run, observed = _quarantine_case(tmp_path)
    observed['H7-3']['active_unit'] = None
    assert runs.f45_ready_assignments(run, observed) == []


@pytest.mark.parametrize('archive_path', [None, 'UNMOUNTED'])
@pytest.mark.parametrize('completed', [False, True])
def test_archive_pause_skips_all_archive_setup_without_blocking_science(tmp_path, monkeypatch, archive_path, completed):
    from padml import reports
    run, observed = _quarantine_case(tmp_path)
    starts = []
    if completed:
        run['units'] = []
        for row in observed.values():
            row.update(state='IDLE', active_unit=None, completed_units=[], not_estimable_units=[],
                selection_completed_units=[], postprocess_ready_units=[], evaluation_ready_units=[])
    monkeypatch.setattr(runs, 'load_f45_run', lambda _: run)
    monkeypatch.setattr(runs, '_f45_remote_command', lambda r, h, c, p: [h, p['operation'], json.dumps(p)])
    def call(command, **kwargs):
        host, operation, raw = command
        if operation == 'observe':
            value = observed[host]
        else:
            assert operation == 'start' and host == 'H1'
            assignment = json.loads(raw)['assignment']; starts.append(assignment)
            value = dict(status='OWNER_REGISTERED', pid=900002, **assignment)
        return subprocess.CompletedProcess(command, 0, stdout=json.dumps(value).encode(), stderr=b'')
    monkeypatch.setattr(subprocess, 'run', call)
    def forbidden(*args, **kwargs):
        pytest.fail('PAUSED_ARCHIVE_MUST_NOT_CONSTRUCT_SCAN_TRANSFER_ACK_OR_COLLECT')
    monkeypatch.setattr(reports, 'WindowArchive', forbidden)
    monkeypatch.setattr(reports, 'collect', forbidden)
    result = runs.dispatch_f45_next(tmp_path/'run.json', code_root=Path('/opt/UNFITTED-release'),
        remote_run_path=Path('/data/UNFITTED-run.json'),
        archive_root=tmp_path/archive_path if archive_path else None)
    if completed:
        assert result['status'] == 'COMPUTE_COMPLETE_ARCHIVE_PAUSED'
        assert starts == []
    else:
        assert result['status'] == 'OBSERVED_AND_DISPATCHED' and len(starts) == 1


def test_archive_staging_preserves_enabled_gate_and_native_compute_dispatch(tmp_path, monkeypatch):
    from padml import f4, reports
    run, observed = _quarantine_case(tmp_path)
    run['post_result_repair'] = {'purpose':'UNFITTED final gate test'}
    monkeypatch.setattr(runs, 'load_f45_run', lambda _: run)
    monkeypatch.setattr(runs, '_f45_remote_command', lambda r,h,c,p:[h,p['operation'],json.dumps(p)])
    starts, archived = [], []
    def call(command, **kwargs):
        host, operation, raw = command
        if operation == 'observe': value = observed[host]
        else:
            assert operation == 'start' and host == 'H1'
            starts.append(json.loads(raw)['assignment'])
            value = dict(status='OWNER_REGISTERED',pid=900002,**starts[-1])
        return subprocess.CompletedProcess(command,0,stdout=json.dumps(value).encode(),stderr=b'')
    monkeypatch.setattr(subprocess,'run',call)
    def final_gate(*a,**kw): raise ContractError('POST_RESULT_ARCHIVE_REMAINS_PAUSED')
    monkeypatch.setattr(f4,'validate_post_result_archive_acceptance',final_gate)
    class Archive:
        def __init__(self,*a,**kw): assert kw['staging'] is True
        def advance(self,values): archived.append(values); return {'status':'STAGING_ONLY'}
        def complete(self): return False
        def staged(self): return False
    monkeypatch.setattr(reports,'WindowArchive',Archive)
    args = dict(code_root=Path('/opt/UNFITTED-release'),remote_run_path=Path('/data/UNFITTED-run.json'),
        archive_root=tmp_path/'archive',follow=False)
    result = runs.dispatch_f45_next(tmp_path/'run.json',archive_mode='staging',**args)
    assert result['status'] == 'OBSERVED_AND_DISPATCHED' and len(starts) == 1 and len(archived) == 1
    with pytest.raises(ContractError,match='POST_RESULT_ARCHIVE_REMAINS_PAUSED'):
        runs.dispatch_f45_next(tmp_path/'run.json',archive_mode='enabled',**args)


def test_retained_inventory_has_longer_deadline_but_control_probes_do_not(tmp_path, monkeypatch):
    from padml import reports
    run, observed = _quarantine_case(tmp_path)
    run['units'] = []
    for row in observed.values():
        row.update(state='IDLE', active_unit=None, completed_units=[], not_estimable_units=[],
            selection_completed_units=[], postprocess_ready_units=[], evaluation_ready_units=[])
    monkeypatch.setattr(runs, 'load_f45_run', lambda _: run)
    monkeypatch.setattr(runs, '_f45_remote_command', lambda r,h,c,p: [h,p['operation'],json.dumps(p)])
    deadlines = []
    def call(command, **kwargs):
        host, operation, raw = command
        request = json.loads(raw)
        if operation == 'observe':
            assert kwargs['timeout'] == 60
            value = observed[host]
        else:
            deadlines.append((operation, bool(request.get('status_only')), kwargs['timeout']))
            if operation == 'archive_inventory' and not request.get('status_only'):
                if kwargs['timeout'] < 90:
                    raise subprocess.TimeoutExpired(command, kwargs['timeout'])
            value = {'status':'RETURNED'}
        return subprocess.CompletedProcess(command,0,stdout=json.dumps(value).encode(),stderr=b'')
    monkeypatch.setattr(subprocess, 'run', call)
    class Archive:
        def __init__(self,*a,**kwargs): self.call = kwargs['call']
        def advance(self,*a,**kwargs):
            for operation, extra in [('archive_inventory',{}),
                    ('archive_inventory',{'status_only':True}),('archive_confirm',{})]:
                assert self.call('H0',operation,**extra)['status'] == 'RETURNED'
            return {}
        def complete(self): return False
        def staged(self): return False
    monkeypatch.setattr(reports, 'WindowArchive', Archive)
    runs.dispatch_f45_next(tmp_path/'run.json',code_root=Path('/opt/UNFITTED-release'),
        remote_run_path=Path('/data/UNFITTED-run.json'),archive_root=tmp_path/'archive',
        archive_mode='staging',follow=False)
    assert deadlines == [('archive_inventory',False,600),('archive_inventory',True,60),
        ('archive_confirm',False,60)]


@pytest.mark.parametrize('known_owner', [True, False])
def test_dispatcher_isolates_only_identified_unknown(tmp_path, monkeypatch, known_owner):
    from padml import reports
    run, observed = _quarantine_case(tmp_path)
    monkeypatch.setenv('PADML_F45_RUN_PATH', str(tmp_path/'run.json'))
    if not known_owner: observed['H7-3']['active_unit'] = None
    starts, archived = [], []
    monkeypatch.setattr(runs, 'load_f45_run', lambda _: run)
    monkeypatch.setattr(runs, '_f45_remote_command', lambda run, host, code, payload:
        [host, payload['operation'], json.dumps(payload)])
    def call(command, **kwargs):
        host, operation, raw = command
        if operation == 'observe': value = observed[host]
        else:
            assert operation == 'start' and host == 'H1'
            assignment = json.loads(raw)['assignment']; starts.append(assignment)
            value = dict(status='OWNER_REGISTERED', pid=900002, **assignment)
        return subprocess.CompletedProcess(command, 0, stdout=json.dumps(value).encode(), stderr=b'')
    monkeypatch.setattr(subprocess, 'run', call)
    class Archive:
        def __init__(self, *args, **kwargs): pass
        def advance(self, values): archived.append(values); return {}
        def complete(self): return False
    monkeypatch.setattr(reports, 'WindowArchive', Archive)
    result = runs.dispatch_f45_next(tmp_path/'run.json', code_root=Path('/opt/UNFITTED-release'),
        remote_run_path=Path('/data/UNFITTED-run.json'), archive_root=tmp_path/'archive', archive_mode='enabled', follow=False)
    if known_owner:
        assert [_without_launch_attempt(value) for value in starts] == [{'host': 'H1', 'unit_id': 'AAR-H06-O1'}]
        assert re.fullmatch('[0-9a-f]{32}', starts[0]['attempt_id']) and len(archived) == 1
        assert result['status'] != 'ATTENTION_REQUIRED'
    else:
        assert starts == [] and result['status'] == 'ATTENTION_REQUIRED'


def _drain_launch_fixture(state, pool, call, transfer):
    # Every task is immediate; a bounded number of causally ordered future drains
    # catches stale counters without timing-dependent busy loops.
    rows = []
    for _ in range(12):
        if state.get('futures'):
            _, unfinished = wait(tuple(state['futures']), timeout=2)
            assert not unfinished, 'UNFITTED fixture task unexpectedly blocked'
        rows += runs._f45_launch_assignments([], {}, {}, [], pool=pool, call=call,
            transfer=transfer, inflight=state)
        if not state.get('futures') and not state.get('queued'): return rows
    pytest.fail('Launch bookkeeping did not reach a settled or explicit unknown boundary')


def test_start_reply_timeout_keeps_reservation_without_resubmitting_and_refills_peer():
    state, calls = {}, []
    units = {'P': {'kind': 'PRIMARY'}, 'P2': {'kind': 'PRIMARY'}}
    bad, good = {'host': 'uncertain', 'unit_id': 'P'}, {'host': 'ready', 'unit_id': 'P2'}
    def call(host, operation, **kwargs):
        assert operation == 'start'; calls.append(host)
        if host == 'uncertain': raise subprocess.TimeoutExpired('UNFITTED-start', .01)
        return dict(status='OWNER_REGISTERED', pid=900003, **kwargs['assignment'])
    with ThreadPoolExecutor(max_workers=2) as pool:
        runs._f45_launch_assignments([bad], units, {}, [], pool=pool, call=call, transfer=None, inflight=state)
        _drain_launch_fixture(state, pool, call, None)
        saved, = state['assignments'].values()
        assert _without_launch_attempt(saved) == bad and re.fullmatch('[0-9a-f]{32}', saved['attempt_id'])
        assert not any(state['pending'].values()) and state.get('active_transfers', 0) == 0
        runs._f45_launch_assignments([good], units, {}, [], pool=pool, call=call, transfer=None, inflight=state)
        _drain_launch_fixture(state, pool, call, None)
        # Mere absence of a reply cannot authorize the same host/unit again.
        _drain_launch_fixture(state, pool, call, None)
        assert calls == ['uncertain', 'ready'] and list(state['assignments'].values()) == [saved]
        assert good not in [_without_launch_attempt(value) for value in state['assignments'].values()]


def test_transfer_failure_settles_counts_and_does_not_start_partial_closure():
    state, starts, failed = {}, [], [True]
    units = {'E': {'kind': 'EVALUATION', 'depends_on': ['A']}, 'P': {'kind': 'PRIMARY'}}
    bad, good = {'host': 'evaluation', 'unit_id': 'E'}, {'host': 'ready', 'unit_id': 'P'}
    def transfer(*args, **kwargs):
        if failed[0]: raise subprocess.TimeoutExpired('UNFITTED-transfer', .01)
    def call(host, operation, **kwargs):
        assert operation == 'start'; starts.append(host)
        return dict(status='OWNER_REGISTERED', pid=900003, **kwargs['assignment'])
    with ThreadPoolExecutor(max_workers=2) as pool:
        runs._f45_launch_assignments([bad], units, {'A': 'source'}, [], pool=pool,
            call=call, transfer=transfer, inflight=state)
        _drain_launch_fixture(state, pool, call, transfer)
        assert starts == [] and not any(state['pending'].values()) and state.get('active_transfers', 0) == 0
        assert bad not in [_without_launch_attempt(value) for value in state['assignments'].values()]
        runs._f45_launch_assignments([good], units, {}, [], pool=pool, call=call,
            transfer=transfer, inflight=state)
        _drain_launch_fixture(state, pool, call, transfer)
        assert starts == ['ready']
        # Only a fresh explicit choice retries the failed transport closure.
        failed[0] = False
        runs._f45_launch_assignments([bad], units, {'A': 'source'}, [], pool=pool,
            call=call, transfer=transfer, inflight=state)
        _drain_launch_fixture(state, pool, call, transfer)
        assert starts == ['ready', 'evaluation'] and not state['assignments']


def test_dependency_pin_drift_remains_fatal_and_never_starts_worker():
    def transfer(*args, **kwargs): raise ContractError('F45_TRANSFER_DESTINATION_DRIFT')
    def forbidden(*args, **kwargs): pytest.fail('Scientific/source drift must not start a worker')
    with ThreadPoolExecutor(max_workers=2) as pool, pytest.raises(ContractError, match='DESTINATION_DRIFT'):
        runs._f45_launch_assignments([{'host': 'evaluation', 'unit_id': 'E'}],
            {'E': {'kind': 'EVALUATION', 'depends_on': ['A']}}, {'A': 'source'}, [],
            pool=pool, call=forbidden, transfer=transfer)


@pytest.mark.parametrize('evidence', ['empty_idle', 'previous_other_returned',
    'same_coordinate_returned_without_attempt_proof', 'same_coordinate_returned_other_attempt',
    'matching_returned', 'matching_running', 'matching_failed_unknown',
    'different_live_coordinate', 'different_live_attempt'])
def test_uncertain_launch_requires_native_attempt_evidence(evidence):
    assignment = {'host': 'H1', 'unit_id': 'PRIMARY-H06-O1', 'attempt_id': '1'*32}
    state = {'assignments': {0: assignment}, 'pending': {0: 0},
        'uncertain': {0: 'UNFITTED-start reply lost'}}
    owner = dict(run_identity='a'*64, unit_id=assignment['unit_id'], mode='execute',
        source_unit=None, pid=900001, pgid=900001, exit_status='RETURNED')
    if evidence != 'same_coordinate_returned_without_attempt_proof':
        owner['attempt_id'] = '2'*32 if evidence in {
            'same_coordinate_returned_other_attempt', 'different_live_attempt'} else assignment['attempt_id']
    row = dict(state='IDLE', active_unit=None, completed_units=[], local_contexts=['OUTER-1'],
        evaluation_ready_units=[], postprocess_ready_units=[], selection_completed_units=[])
    if evidence != 'empty_idle': row['owner_record'] = owner
    if evidence == 'previous_other_returned': owner['unit_id'] = 'PRIMARY-H12-O1'
    if evidence in {'matching_running', 'matching_failed_unknown', 'different_live_coordinate', 'different_live_attempt'}:
        row.update(state='UNKNOWN' if evidence == 'matching_failed_unknown' else 'RUNNING',
            active_unit=assignment['unit_id'], active_mode='execute', active_source_unit=None)
        owner['exit_status'] = 'FAILED' if evidence == 'matching_failed_unknown' else None
    if evidence == 'different_live_coordinate':
        owner['unit_id'] = row['active_unit'] = 'PRIMARY-H12-O1'
    observations = {'H1': row}
    if evidence in {'different_live_coordinate', 'different_live_attempt'}:
        with pytest.raises(ContractError, match='F45_START_OWNER_IDENTITY_DRIFT'):
            runs._f45_reconcile_launches(state, observations, 'a'*64)
        assert state['assignments'] == {0: assignment}
    else:
        runs._f45_reconcile_launches(state, observations, 'a'*64)
        if evidence in {'matching_returned', 'matching_running', 'matching_failed_unknown'}:
            assert not state['assignments'] and not state['pending'] and not state['uncertain']
            assert observations['H1']['state'] == row['state']
        else:
            # A previous RETURNED record at the same coordinate does not identify
            # the new RPC that is possibly still before owner registration.
            assert state['assignments'] == {0: assignment} and state['uncertain']
            assert observations['H1']['state'] == 'UNKNOWN'
            assert observations['H1']['active_unit'] == assignment['unit_id']


def test_remote_start_passes_same_attempt_to_worker_and_registration(tmp_path, monkeypatch):
    from types import SimpleNamespace
    run, _ = _quarantine_case(tmp_path)
    run['environment'] = {'python': '/UNFITTED/python'}
    assignment = {'host': 'H1', 'unit_id': 'PRIMARY-H06-O1', 'attempt_id': '7'*32}
    seen = []
    monkeypatch.setattr(runs, 'load_f45_run', lambda _: run)
    monkeypatch.setattr(runs, '_f45_host_observation', lambda _: {'state': 'IDLE'})
    def popen(command, **options):
        seen.append(command)
        assert options['start_new_session'] is True
        assert command[command.index('--attempt-id')+1] == assignment['attempt_id']
        header = dict(pid=900003, pgid=900003, unit_id=assignment['unit_id'], mode='execute',
            source_unit=None, run_identity=run['identity'], attempt_id=assignment['attempt_id'])
        (tmp_path/'active.lock').write_text(json.dumps(header)+'\n')
        return SimpleNamespace(pid=900003, poll=lambda: None)
    monkeypatch.setattr(subprocess, 'Popen', popen)
    result = runs._f45_remote_operation({'operation': 'start', 'run': str(tmp_path/'run.json'),
        'identity': run['identity'], 'assignment': assignment})
    assert len(seen) == 1 and result == {'status': 'OWNER_REGISTERED', 'pid': 900003, **assignment}


@pytest.mark.parametrize('case', ['known_failed', 'unknown_failed', 'unterminated',
    'unknown_returned', 'live_group', 'valid_returned', 'empty'])
def test_direct_worker_preserves_unresolved_owner_before_pipeline(tmp_path, monkeypatch, case):
    from padml import worker, runtime, f4
    unit = dict(unit_id='PRIMARY-H06-O5', kind='PRIMARY', horizon=6, context='OUTER-5', depends_on=[])
    current = dict(identity='c'*64, source_identity='d'*64, science_decision={},
        kind='PADML_F45_RUN_V1', run_root=str(tmp_path), units=[unit])
    old = {**current, 'identity': 'a'*64, 'source_identity': 'b'*64}
    header = dict(pid=900001, pgid=900001, unit_id=unit['unit_id'], run_identity=old['identity'],
        mode='execute', source_unit=None)
    if case.startswith('unknown_'): header['run_identity'] = 'f'*64
    status = 'RETURNED' if case in {'unknown_returned', 'valid_returned', 'live_group'} else 'FAILED'
    rows = [header] if case == 'unterminated' else [header, dict(pgid=900001, exit_status=status)]
    raw = b'' if case == 'empty' else (''.join(json.dumps(row)+'\n' for row in rows)).encode()
    lock = tmp_path/'active.lock'; lock.write_bytes(raw); inode = lock.stat().st_ino
    monkeypatch.setattr(platform, 'system', lambda: 'Linux')
    monkeypatch.setattr(runs, 'load_f45_run', lambda _: current)
    monkeypatch.setattr(runs, 'f45_unit_predecessors', lambda _: [old])
    monkeypatch.setenv('PADML_F45_RUN_PATH', str(tmp_path/'run.json'))
    monkeypatch.setenv('PADML_INTEGRATED_RUN', 'UNFITTED-fixture')
    def ps(command, **kwargs):
        assert command[:2] == ['ps', '-eo']
        live = [(os.getpid(), os.getpgrp())] + ([(900002, 900001)] if case == 'live_group' else [])
        columns = command[-1]
        assert columns in {'pgid=', 'pid=,pgid='}
        stdout = ''.join((f'{p} {g}\n' if columns == 'pid=,pgid=' else f'{g}\n') for p, g in live)
        return subprocess.CompletedProcess(command, 0, stdout=stdout, stderr='')
    monkeypatch.setattr(subprocess, 'run', ps)
    entered = []
    class PipelineReached(Exception): pass
    def pipeline(*args, **kwargs): entered.append(True); raise PipelineReached
    monkeypatch.setattr(f4, 'run_f45_postprocess', pipeline)
    monkeypatch.setattr(runtime, 'release_f45_cumulative_files', lambda *a, **k: None)
    if case in {'valid_returned', 'empty'}:
        with pytest.raises(PipelineReached): worker.execute_f45(tmp_path/'run.json', unit['unit_id'], mode='postprocess', attempt_id='7'*32)
        assert entered == [True] and json.loads(lock.read_text().splitlines()[0])['run_identity'] == current['identity']
        assert json.loads(lock.read_text().splitlines()[0])['attempt_id'] == '7'*32
    else:
        with pytest.raises(ContractError): worker.execute_f45(tmp_path/'run.json', unit['unit_id'], mode='postprocess')
        assert entered == [] and lock.read_bytes() == raw
    assert lock.stat().st_ino == inode


"""Append to tests/test_integrated_dispatch.py after the production change.

Engineering carrier/consumer fixtures only. Context schema and RNG are seams;
actual CarrierZip, source pins, f64 decoding, numerical matrix checks, report
reduction, and load_f45_postprocess run unchanged. No scientific engine runs.
"""
from pathlib import Path
import copy
import struct
import time
import pytest


@pytest.fixture
def completed_postprocess_carrier(tmp_path, monkeypatch):
    from padml import f4, carriers, diagnostics, runtime, run as runs, nested_loco as n
    from padml.bundle import canonical_json_bytes as enc, sha256_bytes
    base = tmp_path.resolve()
    unit = {'kind':'PRIMARY', 'unit_id':'PRIMARY-H06-O1', 'horizon':6,
            'outer_fold':1, 'context':'OUTER-1'}
    run = {'kind':'PADML_INTEGRATED_RAW_RUN_V1', 'identity':'a'*64,
           'source_identity':'b'*64, 'run_root':str(base), 'resource_policy':{}}
    root = base/'units'/unit['unit_id']; output = root/'postprocess'
    output.mkdir(parents=True)
    monkeypatch.setattr(carriers, 'run_context', lambda:run)
    monkeypatch.setattr(runs, 'f45_unit_predecessors', lambda value:[])
    monkeypatch.setattr(runtime, 'observe_execution_resources', lambda *a:{})
    monkeypatch.setattr(runtime, 'resource_admission', lambda *a,**k:None)
    # Age only test stamps, without a sleep or changing scientific bytes.
    now = time.time_ns(); monkeypatch.setattr(time, 'time_ns', lambda:now+10_000_000_000)
    ids = [f'UNFITTED-{i}' for i in range(5)]
    centers = dict.fromkeys(ids,'38')
    context = n._sealed({'training_ids':ids, 'centers_by_patient':centers,
                        'channel':'PRIMARY', 'outer_fold':1})
    decision = n._sealed({'test_only':'UNFITTED_FAMILY_DECISION'})
    lock = n._sealed({'selected_family':'COX_PH', 'family_decision_sha256':decision['identity_sha256'],
                     'selection_horizon_months':6})
    monkeypatch.setattr(n, 'validate_training_context', lambda value,*a,**k:value)
    monkeypatch.setattr(n, 'validate_development_lock', lambda value,**k:value)
    draw_plan = {'draws':[list(range(5)) for _ in range(1000)]}
    monkeypatch.setattr(f4, 'bootstrap_draws', lambda *a,**k:copy.deepcopy(draw_plan))
    monkeypatch.setattr(diagnostics, 'run_diagnostics', lambda *a,**k:{'status':'UNFITTED_EXISTING_DIAGNOSTICS'})
    def no_engine(*a,**k):
        pytest.fail('COMPLETED_POSTPROCESS_MUST_NOT_RUN_NATIVE_METRICS')
    monkeypatch.setattr(f4, '_f45_optimism_metrics', no_engine)
    receipt = {'unit_id':unit['unit_id'], 'status':'COMPLETED',
               'direct_consumer_completed':True, 'run_identity':run['identity'], 'artifacts':{}}
    (root/'unit.json').write_bytes(enc(receipt))
    payload = {
        'response.csv':('Patient_ID,All_Cause_Death,Death_Followup_months\n'+''.join(
            f'{pid},{i%2},50\n' for i,pid in enumerate(ids))).encode(),
        'apparent.f64':b''.join(struct.pack('<37d',1.0,*([.9]*36)) for _ in ids),
        'draws.zip':b'UNFITTED_RNG_READ_SEAM_NO_NATIVE_ENGINE',
    }
    refs = {}
    for name,raw in payload.items():
        path = base/'shared'/name; path.parent.mkdir(parents=True,exist_ok=True)
        path.write_bytes(raw); refs[name] = path
    pooled = {}
    for family in n._families():
        pooled[family] = []
        for repeat in range(1,4):
            for inner in range(1,6):
                path = base/'shared/oof'/f'{family}-R{repeat}-K{inner}.f64'
                path.parent.mkdir(parents=True,exist_ok=True)
                path.write_bytes(struct.pack('<37d',1.0,*([.85]*36)))
                pooled[family].append({'repeat':repeat,'inner_fold':inner,
                    'partition_id':f'INNER_R{repeat}_K{inner}', 'patient_ids':[ids[inner-1]],
                    'horizons':f4.HORIZONS,'component_receipt_sha256':['e'*64]*20,
                    'pooled_survival_ref':carriers.file_reference(path,'M20_POOLED_OOF',run)})
    manifest = n._sealed({'kind':'PADML_F45_OPTIMISM_INPUT_V1','contract':f4.f45_optimism_contract(),
        'source_unit':unit['unit_id'],'selection_horizon_months':6,'source_receipt':receipt,
        'source_receipt_sha256':sha256_bytes(enc(receipt)),'training_context':context,
        'training_context_sha256':context['identity_sha256'],'development_lock':lock,
        'family_decision':decision,'patient_ids':ids,'centers':[centers[pid] for pid in ids],
        'draws_sha256':sha256_bytes(enc(draw_plan['draws'])),
        'members':{name:{'sha256':sha256_bytes(raw),'size_bytes':len(raw)} for name,raw in payload.items()},
        'oof_partitions':pooled})
    carriers.write_carrier(output/'input.zip',{'input.json':enc(manifest)},references=refs,run=run)
    numbers = {label:{str(h):{'support':{'test_only':'UNFITTED'},
        **{metric:{'value':.5,'status':'ESTIMABLE','reasons':[]} for metric in ('ibs','uno_c','calibration_slope')}}
        for h in f4.REPORT_HORIZONS} for label in ('TRAINING/APPARENT','TRAINING/OOF-R1','TRAINING/OOF-R2','TRAINING/OOF-R3')}
    rows = f4._f45_o_fit_rows(numbers,manifest)
    csv = f4._f45_optimism_csv(rows)
    result = n._sealed({'kind':'PADML_F45_O_FIT_V1','status':'COMPLETED',
        'contract':f4.f45_optimism_contract(),'source_unit':unit['unit_id'],
        'input_identity_sha256':manifest['identity_sha256'], 'source_receipt_sha256':sha256_bytes(enc(receipt)),
        'numbers':numbers,'report_rows':rows,'numerically_estimable_rows':len(rows),
        'csv_sha256':sha256_bytes(csv),'new_prediction_model_fits':0,
        'native_metrics':{'test_only':'UNFITTED_ALREADY_CONSUMED_RESULT_SEAM'}})
    (output/'result.json').write_bytes(enc(result)); (output/'o-fit.csv').write_bytes(csv)
    originals = {p:p.read_bytes() for p in (root/'unit.json',output/'input.zip',output/'result.json',output/'o-fit.csv')}
    reads = []; original_reader = carriers.pooled_matrix
    def watched(item):
        reads.append(item['pooled_survival_ref']['path'])
        return original_reader(item)
    monkeypatch.setattr(carriers,'pooled_matrix',watched)
    return f4,carriers,run,unit,root,result,reads,originals,watched


def test_postprocess_existing_result_requires_first_scientific_reader(completed_postprocess_carrier):
    f4,_,run,unit,root,result,reads,originals,_ = completed_postprocess_carrier
    assert f4.run_f45_postprocess(run,unit,root)==result
    assert len(reads)==105  # Seven families, three repeats, five distinct folds.
    assert all(path.read_bytes()==raw for path,raw in originals.items())


def test_postprocess_scientific_stable_hit_does_not_read_oof(completed_postprocess_carrier,monkeypatch):
    f4,carriers,run,unit,root,result,reads,originals,_ = completed_postprocess_carrier
    assert f4.run_f45_postprocess(run,unit,root)==result
    assert len(reads)==105
    def forbidden(*a,**k):pytest.fail('QUALIFIED_COMPLETED_POSTPROCESS_MUST_NOT_READ_OOF')
    monkeypatch.setattr(carriers,'pooled_matrix',forbidden)
    assert f4.run_f45_postprocess(run,unit,root)==result
    assert all(path.read_bytes()==raw for path,raw in originals.items())


@pytest.mark.parametrize('changed',['oof','apparent','source_receipt','report_csv'])
def test_postprocess_reference_or_binding_drift_is_not_a_metadata_hit(completed_postprocess_carrier,changed):
    from padml.bundle import ContractError
    f4,_,run,unit,root,_,_,originals,_ = completed_postprocess_carrier
    f4.run_f45_postprocess(run,unit,root)
    target = {'oof':Path(run['run_root'])/'shared/oof/RSF-R3-K5.f64',
        'apparent':Path(run['run_root'])/'shared/apparent.f64',
        'source_receipt':root/'unit.json','report_csv':root/'postprocess/o-fit.csv'}[changed]
    before = target.read_bytes(); target.write_bytes(before[:-1]+bytes([before[-1]^1]))
    altered = target.read_bytes()
    with pytest.raises((ContractError,UnicodeDecodeError)):
        f4.run_f45_postprocess(run,unit,root)
    assert target.read_bytes()==altered  # Never overwrite drift as a cache repair.
    assert all(path==target or path.read_bytes()==raw for path,raw in originals.items())


def test_postprocess_failed_first_reader_never_qualifies(completed_postprocess_carrier,monkeypatch):
    from padml.bundle import ContractError
    f4,carriers,run,unit,root,result,reads,originals,watched = completed_postprocess_carrier
    def failed(*a,**k):raise ContractError('UNFITTED_FIRST_NUMERIC_READER_FAILURE')
    monkeypatch.setattr(carriers,'pooled_matrix',failed)
    with pytest.raises(ContractError,match='FIRST_NUMERIC_READER_FAILURE'):
        f4.run_f45_postprocess(run,unit,root)
    monkeypatch.setattr(carriers,'pooled_matrix',watched)
    assert f4.run_f45_postprocess(run,unit,root)==result
    assert len(reads)==105
    assert all(path.read_bytes()==raw for path,raw in originals.items())


from concurrent.futures import Future
from pathlib import Path
from collections import deque
import json
import os
import subprocess
import io
from types import SimpleNamespace

import pytest

from padml import run as runs
from padml.bundle import ContractError, canonical_json_bytes, sha256_bytes


@pytest.mark.parametrize('scope', ['full0_start', 'selection_transfer'])
def test_pending_launch_reserves_coordinate_before_native_owner_registration(scope):
    source = dict(unit_id='PRIMARY-H06-O1', kind='PRIMARY', horizon=6, context='OUTER-1', depends_on=[])
    evaluation = dict(unit_id='EVALUATION-H06', kind='EVALUATION', horizon=6, context='EVALUATION', depends_on=[])
    full = dict(unit_id='FULL0-H06', kind='FULL0', horizon=6, context='FULL0', depends_on=[])
    run = dict(kind='PADML_INTEGRATED_RAW_RUN_V1', units=[full] if scope == 'full0_start' else [source, evaluation])
    # as_completed may observe any idle peer before the host with the pending RPC.
    order = ['H1', 'H0', *[h for h in runs.F45_HOSTS if h not in {'H1', 'H0'}]]
    observations = {h: dict(state='IDLE', active_unit=None, local_contexts=[], completed_units=[],
        evaluation_ready_units=[], postprocess_ready_units=[], selection_completed_units=[]) for h in order}
    assignment = dict(host='H0', unit_id='FULL0-H06', attempt_id='1'*32)
    kind = 'start'
    if scope == 'selection_transfer':
        assignment.update(unit_id='EVALUATION-H06', mode='selection', source_unit=source['unit_id'], source_host='H9-2')
        observations['H9-2'].update(local_contexts=['OUTER-1'], completed_units=[source['unit_id'], evaluation['unit_id']],
            evaluation_ready_units=[source['unit_id']], postprocess_ready_units=[source['unit_id']])
        kind = 'index'
    future = Future(); future.set_running_or_notify_cancel()
    state = dict(assignments={0: assignment}, pending={0: 1}, uncertain={},
        futures={future: (0, kind)}, queued=deque(), active_transfers=int(kind == 'index'))
    runs._f45_reconcile_launches(state, observations, 'a'*64)
    choices = runs.f45_ready_assignments(run, observations)
    choices = [a for a in choices if a['host'] not in {row['host'] for row in state['assignments'].values()}]
    assert choices == [], 'Filtering only the destination host can duplicate the same scientific coordinate'
    assert observations['H0']['state'] == 'UNKNOWN'
    assert observations['H0']['active_unit'] == assignment['unit_id']
    assert state['pending'] == {0: 1} and future in state['futures']


@pytest.mark.parametrize('failed_endpoint', ['sender', 'receiver', 'local_timeout', 'cleanup_timeout',
    'receive_timeout', 'receive_timeout_sender_unknown'])
def test_real_bulk_ssh_disconnect_is_isolated_not_global_contract_failure(tmp_path, monkeypatch, failed_endpoint):
    from padml import reports
    monkeypatch.setenv('PADML_F45_RUN_PATH', str(tmp_path/'run.json'))
    unit = dict(unit_id='E', kind='EVALUATION', horizon=6, context='EVALUATION', depends_on=['A'])
    run = dict(kind='PADML_INTEGRATED_RAW_RUN_V1', run_root=str(tmp_path), identity='a'*64,
        units=[unit], host_connections={h: {'ssh_target': 'UNUSED'} for h in runs.F45_HOSTS})
    observed = {h: dict(state='IDLE', active_unit=None, completed_units=[], local_contexts=[],
        evaluation_ready_units=[], postprocess_ready_units=[], selection_completed_units=[]) for h in runs.F45_HOSTS}
    observed['H9-2']['evaluation_ready_units'] = ['A']
    monkeypatch.setattr(runs, 'load_f45_run', lambda _: run)
    monkeypatch.setattr(runs, 'f45_ready_assignments', lambda *_: [{'host': 'H1', 'unit_id': 'E'}])
    monkeypatch.setattr(runs, '_f45_remote_command', lambda r, h, c, p: [h, p['operation'], json.dumps(p)])
    pin = {'sha256': sha256_bytes(b'x'), 'size_bytes': 1}
    calls = []
    def call(command, **kwargs):
        host, operation, payload = command; calls.append(operation)
        if operation == 'observe': value, status = observed[host], 0
        elif operation == 'pin': value, status = (pin if host == 'H9-2' else {'status': 'ABSENT'}), 0
        elif operation == 'receive':
            if failed_endpoint in {'local_timeout', 'cleanup_timeout'}:
                raise subprocess.TimeoutExpired('UNFITTED-local-SSH', .01)
            value = (dict(status='TRANSFER_RETRY_REQUIRED', reason='F45_TRANSFER_INPUT_TIMEOUT', pin=pin)
                if failed_endpoint.startswith('receive_timeout') else pin)
            status = 255 if failed_endpoint == 'receiver' else 0
        else: pytest.fail('No worker may start before the transfer closure completes')
        return subprocess.CompletedProcess(command, status, stdout=json.dumps(value).encode(), stderr=b'UNFITTED SSH disconnect')
    monkeypatch.setattr(subprocess, 'run', call)
    def sender(command, **kwargs):
        assert command[1] == 'send'
        code = 255 if failed_endpoint in {'sender', 'receive_timeout_sender_unknown'} else 0
        if failed_endpoint == 'cleanup_timeout':
            killed = []
            def wait(**_):
                if not killed: raise subprocess.TimeoutExpired('UNFITTED-local-sender', .01)
                return -9
            return SimpleNamespace(stdout=io.BytesIO(b'x'), wait=wait, poll=lambda:None,
                terminate=lambda:None, kill=lambda:killed.append(True))
        return SimpleNamespace(stdout=io.BytesIO(b'x'), wait=lambda **_: code, poll=lambda: code)
    monkeypatch.setattr(subprocess, 'Popen', sender)
    class Archive:
        def __init__(self, *a, **k): pass
        def advance(self, *a): return {}
        def complete(self): return False
    monkeypatch.setattr(reports, 'WindowArchive', Archive)
    result = runs.dispatch_f45_next(tmp_path/'run.json', code_root=Path('/opt/UNFITTED-release'),
        remote_run_path=Path('/data/UNFITTED-run.json'), archive_root=tmp_path/'archive')
    assert 'start' not in calls
    expected = 'TRANSFER_RETRY_REQUIRED' if failed_endpoint == 'receive_timeout' else 'TRANSFER_OUTCOME_UNKNOWN'
    assert any(item['status'] == expected for item in result['jobs'])


@pytest.mark.parametrize('case', ['admitted_previous', 'unknown_producer', 'missing_archive'])
def test_shared_bootstrap_preserves_admitted_producer_before_new_scientific_calls(tmp_path, monkeypatch, case):
    from padml import f4, integrated
    archive = tmp_path/'bootstrap.zip'
    archive.write_bytes(b'UNFITTED immutable retained RNG fixture')
    ids, centers = ['p1', 'p2'], ['36', '48']
    draw_plan = {'draws': [[0, 1], [1, 0]]}
    old_members, new_members = {'fixture-source': 'b'*64}, {'fixture-source': 'c'*64}
    old_source = sha256_bytes(canonical_json_bytes(old_members))
    new_source = sha256_bytes(canonical_json_bytes(new_members))
    run = dict(kind='PADML_INTEGRATED_RAW_RUN_V1', identity='d'*64,
        source_identity=new_source, run_root=str(tmp_path))
    old = {**run, 'identity': 'e'*64, 'source_identity': old_source}
    monkeypatch.setattr(runs, 'f45_unit_predecessors', lambda _: [old])
    frozen = {'receipt': {'identity': 'a'*64},
        'registry': {'outer': [{'application_ids': ids}]}, 'centers': dict(zip(ids, centers))}
    monkeypatch.setattr(integrated, 'ensure_raw_binding', lambda _: frozen)
    monkeypatch.setattr(f4, '_f45_source_member_sha256', lambda: new_members)
    native_calls = []
    def replay(*args, **kwargs):
        native_calls.append(kwargs)
        assert kwargs['replay_archive'] == archive and 'retained_archive' not in kwargs
        return draw_plan
    monkeypatch.setattr(f4, 'bootstrap_draws', replay)
    saved = {'status': 'PREPARED_SHARED_F45_DRAWS', 'stage_acceptance': False,
        'shared_rng_invocations': 1, 'new_model_fits': 0, 'bootstrap_replicates_executed': 0,
        'rng_archive': {'sha256': sha256_bytes(archive.read_bytes()), 'size_bytes': archive.stat().st_size},
        'f45_source_sha256': 'f'*64 if case == 'unknown_producer' else old_source,
        'raw_binding_identity': 'a'*64,
        'patient_ids_sha256': sha256_bytes(canonical_json_bytes(ids)),
        'centers_sha256': sha256_bytes(canonical_json_bytes(centers)),
        'draws_sha256': sha256_bytes(canonical_json_bytes(draw_plan['draws']))}
    record = tmp_path/'bootstrap-preparation.json'; record.write_bytes(canonical_json_bytes(saved))
    if case == 'missing_archive': archive.unlink()
    originals = {p: (p.read_bytes(), p.stat().st_ino, p.stat().st_mtime_ns)
        for p in (archive, record) if p.exists()}
    if case == 'admitted_previous':
        assert runs.prepare_f45_bootstrap(run, tmp_path) == saved
        assert len(native_calls) == 1  # One required retained replay, zero new RNG/fits.
    else:
        with pytest.raises(ContractError, match='F45_SHARED_RNG_DRIFT'):
            runs.prepare_f45_bootstrap(run, tmp_path)
        assert native_calls == []
    assert originals == {p: (p.read_bytes(), p.stat().st_ino, p.stat().st_mtime_ns) for p in originals}
    assert archive.exists() == (case != 'missing_archive')


def test_unknown_first_evaluation_keeps_draw_ownership_but_allows_independent_work(tmp_path, monkeypatch):
    from padml import reports
    units = runs.f45_units()
    run = dict(kind='PADML_INTEGRATED_RAW_RUN_V1', identity='a'*64, source_identity='b'*64,
        run_root=str(tmp_path), units=units,
        host_connections={h: {'ssh_target': 'UNUSED', 'port': 22} for h in runs.F45_HOSTS})
    observations = {h: dict(state='IDLE', active_unit=None, local_contexts=[], completed_units=[],
        evaluation_ready_units=[], postprocess_ready_units=[], selection_completed_units=[]) for h in runs.F45_HOSTS}
    observations['H0'].update(state='UNKNOWN', active_unit='EVALUATION-H06', active_mode='execute',
        active_source_unit=None, reason='OWNER_EXIT_OR_REGISTERED_GROUP_REQUIRES_RESOLUTION')
    for row in units:
        if row['kind'] == 'EVALUATION' or row['unit_id'] in {'PRIMARY-H36-O1', 'AAR-H36-O1'}: continue
        h = 'H0' if row['context'] == 'FULL0' else runs.F45_HOSTS[row['outer_fold']]
        o = observations[h]
        if row['context'] not in o['local_contexts']: o['local_contexts'].append(row['context'])
        o['completed_units'].append(row['unit_id'])
        if row['kind'] in {'PRIMARY', 'AAR'}: o['evaluation_ready_units'].append(row['unit_id'])
        if row['kind'] in {'PRIMARY', 'FULL0'}:
            o['postprocess_ready_units'].append(row['unit_id'])
            o['selection_completed_units'].append(row['unit_id'])
    monkeypatch.setattr(runs, 'load_f45_run', lambda _: run)
    monkeypatch.setattr(runs, '_f45_remote_command', lambda r, h, c, p: [h, p['operation'], json.dumps(p)])
    starts = []
    pin = {'sha256': 'c'*64, 'size_bytes': 1}
    def call(command, **kwargs):
        host, operation, raw = command
        if operation == 'observe': value = observations[host]
        elif operation == 'pin': value = pin
        elif operation == 'start':
            a = json.loads(raw)['assignment']; starts.append(a)
            value = {'status': 'OWNER_REGISTERED', 'pid': 900001, **a}
        else: pytest.fail('Unexpected control call: ' + operation)
        return subprocess.CompletedProcess(command, 0, stdout=json.dumps(value).encode(), stderr=b'')
    monkeypatch.setattr(subprocess, 'run', call)
    class Archive:
        def __init__(self, *a, **k): pass
        def advance(self, *a): return {}
        def complete(self): return False
    monkeypatch.setattr(reports, 'WindowArchive', Archive)
    result = runs.dispatch_f45_next(tmp_path/'run.json', code_root=Path('/opt/UNFITTED-release'),
        remote_run_path=Path('/data/UNFITTED-run.json'), archive_root=tmp_path/'archive', archive_mode='enabled', follow=False)
    assert [_without_launch_attempt(a) for a in starts] == [{'host': 'H1', 'unit_id': 'PRIMARY-H36-O1'}]
    assert len(result['jobs']) == 1
    assert 'shared_draws' not in observations['H0']


# Typed negative terminal transport: engineering fixtures do not establish clinical completion.
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from collections import Counter
import json
import subprocess
import pytest
from padml import run as runs, reports, integrated, nested_loco as n
from padml.bundle import ContractError, canonical_json_bytes as enc, sha256_file, write_deterministic_zip
from padml.carriers import write_carrier


def _terminal_io_run_case(tmp_path):
    units=[dict(unit_id='PRIMARY-H06-O1',kind='PRIMARY',horizon=6,outer_fold=1,context='OUTER-1',depends_on=[]),
        dict(unit_id='AAR-H06-O1',kind='AAR',horizon=6,outer_fold=1,context='OUTER-1',depends_on=['PRIMARY-H06-O1']),
        dict(unit_id='FULL0-H06',kind='FULL0',horizon=6,context='FULL0',depends_on=[]),
        dict(unit_id='EVALUATION-H06',kind='EVALUATION',horizon=6,context='EVALUATION',depends_on=['PRIMARY-H06-O1','AAR-H06-O1'])]
    run=dict(kind='PADML_INTEGRATED_RAW_RUN_V1',run_root=str(tmp_path),run_id='unfitted-frequency',
        identity='a'*64,source_identity='b'*64,units=units,raw_input={'sha256':'c'*64},
        resource_policy={},host_connections={h:{'ssh_target':'unused'} for h in runs.F45_HOSTS})
    observed={h:dict(state='IDLE',active_unit=None,completed_units=[],not_estimable_units=[],local_contexts=[],
        evaluation_ready_units=[],postprocess_ready_units=[],selection_completed_units=[]) for h in runs.F45_HOSTS}
    observed['H0']['local_contexts']=['OUTER-1'];observed['H1']['local_contexts']=['FULL0']
    return run,observed


def _terminal_io_negative_root(run, uid):
    root=Path(run['run_root'])/'units'/uid;root.mkdir(parents=True,exist_ok=True)
    write_deterministic_zip(root/'result.zip',{'estimability.json':enc({'UNFITTED_BOUNDARY_ONLY':True})})
    receipt=dict(status='NOT_ESTIMABLE',direct_consumer_completed=True,unit_id=uid,run_identity=run['identity'],
        selection_horizon_months=6,estimability={'status':'NOT_ESTIMABLE','reason_code':'UNFITTED'},
        artifacts={'result.zip':dict(sha256=sha256_file(root/'result.zip'),size_bytes=(root/'result.zip').stat().st_size)})
    (root/'unit.json').write_bytes(enc(receipt));return root,receipt


def test_negative_dependency_runs_once_and_unrelated_full0_continues(tmp_path):
    run,obs=_terminal_io_run_case(tmp_path);p,a='PRIMARY-H06-O1','AAR-H06-O1'
    obs['H0'].update(not_estimable_units=[p],evaluation_ready_units=[p])
    assert runs.f45_ready_assignments(run,obs)==[dict(host='H0',unit_id=a),dict(host='H1',unit_id='FULL0-H06')]
    obs['H0'].update(not_estimable_units=[p,a],evaluation_ready_units=[p,a])
    obs['H1']['not_estimable_units']=['FULL0-H06']
    assert runs.f45_ready_assignments(run,obs)==[dict(host='H0',unit_id='EVALUATION-H06')]
    obs['H0']['not_estimable_units'].append('EVALUATION-H06')
    assert runs.f45_ready_assignments(run,obs)==[]


def test_negative_source_needs_scientific_readiness_and_conflicts_reject(tmp_path):
    run,obs=_terminal_io_run_case(tmp_path);p='PRIMARY-H06-O1'
    obs['H0']['not_estimable_units']=[p]
    assert all(row['unit_id']!='AAR-H06-O1' for row in runs.f45_ready_assignments(run,obs))
    obs['H0']['completed_units']=[p]
    with pytest.raises(ContractError,match='CONFLICTING_UNIT_TERMINALS'):runs.f45_ready_assignments(run,obs)


@pytest.mark.parametrize('bad',[False,True])
def test_observation_reads_typed_negative_without_evaluation_input(tmp_path,monkeypatch,bad):
    run,_=_terminal_io_run_case(tmp_path);uid='PRIMARY-H06-O1';root,receipt=_terminal_io_negative_root(run,uid)
    (tmp_path/'contexts/OUTER-1').mkdir(parents=True)
    (tmp_path/'contexts/OUTER-1/primary-context.json').write_text('{}')
    monkeypatch.setattr(runs,'f45_unit_predecessors',lambda r:[])
    calls=[]
    def consume(r,u,p,s):
        calls.append((u['unit_id'],p,s))
        if bad:raise ContractError('UNFITTED_NEGATIVE_PROOF_INVALID')
    monkeypatch.setattr(integrated,'consume_unit_estimability',consume,raising=False)
    if bad:
        with pytest.raises(ContractError,match='NEGATIVE_PROOF_INVALID'):runs._f45_host_observation(run)
    else:
        observed=runs._f45_host_observation(run)
        assert observed['not_estimable_units']==observed['evaluation_ready_units']==[uid]
        assert observed['completed_units']==observed['postprocess_ready_units']==[]
        assert not (root/'evaluation-input.zip').exists()
    assert calls==[(uid,root,receipt)]


def test_negative_inventory_requires_no_models_and_retains_evidence(tmp_path,monkeypatch):
    run,_=_terminal_io_run_case(tmp_path);uid='PRIMARY-H06-O1';root,receipt=_terminal_io_negative_root(run,uid)
    for name in ('binding.json','contract.json','covariates.csv','response-seal.csv'):
        p=tmp_path/'binding'/name;p.parent.mkdir(exist_ok=True);p.write_bytes(enc({}) if name.endswith('.json') else b'x\n')
    monkeypatch.setattr(reports,'same_batch_generations',lambda r:{run['identity']:run['source_identity']})
    calls=[];monkeypatch.setattr(integrated,'consume_unit_estimability',lambda *args:calls.append(args),raising=False)
    inventory=reports.archive_inventory(run,6,[uid],[])
    assert inventory['not_estimable_units']==[uid]
    assert set(inventory['members'])=={f'units/{uid}/unit.json',f'units/{uid}/result.zip',
        *(f'binding/{name}' for name in ('binding.json','contract.json','covariates.csv','response-seal.csv'))}
    assert calls and reports.report_names(run,[uid],[],receipts={uid:receipt})==[f'units/{uid}/unit.json']


def test_negative_evaluation_retirement_uses_only_existing_members(tmp_path,monkeypatch):
    run,_=_terminal_io_run_case(tmp_path);uid='EVALUATION-H06';root,receipt=_terminal_io_negative_root(run,uid)
    (root/'result.zip.work').mkdir()
    monkeypatch.setattr(integrated,'same_batch_generations',lambda r:{run['identity']:run['source_identity']})
    calls=[];monkeypatch.setattr(integrated,'consume_unit_estimability',lambda *a:calls.append(a),raising=False)
    from padml import worker
    monkeypatch.setattr(worker,'_f45_file_pins',lambda paths,**kw:kw['expected'])
    integrated.retire_completed_outputs(run,run['units'][-1],root)
    assert len(calls)==1 and (root/'result.zip').is_file()


@pytest.mark.parametrize('ancestor_direct',[False,True])
def test_negative_launch_index_barriers_and_shared_primary_are_unique(ancestor_direct):
    p,a='PRIMARY-H06-O1','AAR-H06-O1'
    deps=[p,a] if ancestor_direct else [a]
    units={'E':{'kind':'EVALUATION','depends_on':deps},p:{'kind':'PRIMARY'},a:{'kind':'AAR'}}
    selector='contexts/OUTER-1/selector/coarse/paths.json'
    closures={p:{f'units/{p}/result.zip':{},selector:{}},a:{f'units/{a}/result.zip':{},
        f'units/{p}/unit.json':{},f'units/{p}/result.zip':{},selector:{}}}
    received,counts,events=set(),Counter(),[]
    def transfer(source,target,name,**kwargs):
        uid=kwargs.get('estimability_of')
        if uid:
            assert f'units/{uid}/unit.json' in received
            if name!=f'units/{uid}/result.zip':assert f'units/{uid}/result.zip' in received
            if name==selector:assert f'units/{p}/result.zip' in received
        received.add(name);counts[name]+=1;events.append(('transfer',name))
    def call(host,op,**kw):
        if op=='dependency_inventory':
            assert kw['source_type']=='estimability'
            assert f"units/{kw['source_unit']}/unit.json" in received
            return closures[kw['source_unit']]
        assert op=='start' and selector in received
        expected={f'units/{p}/unit.json',f'units/{p}/result.zip',f'units/{a}/unit.json'}
        if not ancestor_direct:expected.add(f'units/{a}/result.zip')
        assert expected <= received
        events.append(('start',None));return {'status':'OWNER_REGISTERED',**kw['assignment']}
    with ThreadPoolExecutor(max_workers=7) as pool:
        result=runs._f45_launch_assignments([{'host':'target','unit_id':'E'}],units,{u:'source' for u in deps},[],
            pool=pool,call=call,transfer=transfer,not_estimable_units=deps)
    assert result[0]['status']=='OWNER_REGISTERED' and events[-1][0]=='start'
    assert set(counts.values())=={1}
    assert not any('evaluation-input' in name or '/input.zip' in name for name in received)


def test_negative_transfer_failure_never_starts_and_settles_all_counts():
    import time
    state={};started=[];p='PRIMARY-H06-O1';selector='contexts/OUTER-1/selector/coarse/paths.json'
    def transfer(source,target,name,**kwargs):
        if name==selector:raise subprocess.TimeoutExpired('UNFITTED',.01)
    def call(host,op,**kw):
        if op=='dependency_inventory':return {f'units/{p}/result.zip':{},selector:{}}
        started.append(kw);return 'bad'
    with ThreadPoolExecutor(max_workers=3) as pool:
        runs._f45_launch_assignments([{'host':'target','unit_id':'E'}],
            {'E':{'kind':'EVALUATION','depends_on':[p]},p:{'kind':'PRIMARY'}},{p:'source'},[],pool=pool,
            call=call,transfer=transfer,not_estimable_units=[p],inflight=state)
        deadline=time.monotonic()+3
        while state['assignments']:
            assert time.monotonic()<deadline
            runs._f45_launch_assignments([],{}, {},[],pool=pool,call=call,transfer=transfer,inflight=state)
            time.sleep(.001)
    assert not started and not state['pending'] and state['active_transfers']==0


def _terminal_io_closure_fixture(tmp_path,monkeypatch):
    run,_=_terminal_io_run_case(tmp_path)
    monkeypatch.setattr(integrated,'same_batch_generations',lambda r:{r['identity']:r['source_identity']})
    monkeypatch.setattr(reports,'same_batch_generations',lambda r:{r['identity']:r['source_identity']})
    manifest=tmp_path/'run.json';manifest.write_bytes(enc(run));monkeypatch.setenv('PADML_F45_RUN_PATH',str(manifest))
    p,a=run['units'][:2];roots={u['unit_id']:tmp_path/'units'/u['unit_id'] for u in (p,a)}
    for root in roots.values():root.mkdir(parents=True)
    selector=tmp_path/'contexts/OUTER-1/selector/coarse/paths.json';selector.parent.mkdir(parents=True)
    selector.write_bytes(enc({'UNFITTED_TYPED_TRANSFER_TEST':True}))
    common=dict(kind='PADML_UNIT_NOT_ESTIMABLE_V1',status='NOT_ESTIMABLE',run_identity=run['identity'],
        source_identity=run['source_identity'],raw_input=run['raw_input'],selection_horizon_months=6)
    def publish(u,body,refs):
        body=n._sealed(dict(common,unit_id=u['unit_id'],**body));root=roots[u['unit_id']]
        write_carrier(root/'result.zip',{'estimability.json':enc(body)},references=refs,run=run)
        receipt=dict(status='NOT_ESTIMABLE',direct_consumer_completed=True,unit_id=u['unit_id'],run_identity=run['identity'],
            selection_horizon_months=6,estimability=integrated._unit_estimability_summary(body),
            artifacts={'result.zip':dict(sha256=sha256_file(root/'result.zip'),size_bytes=(root/'result.zip').stat().st_size)})
        (root/'unit.json').write_bytes(enc(receipt));return receipt
    pr=publish(p,dict(reason_code='FREQUENCY_LADDER_EXHAUSTED',upstream_units=[]),{'selector/coarse/paths.json':selector})
    ar=publish(a,dict(reason_code='UPSTREAM_PRIMARY_NOT_ESTIMABLE',upstream_units=[p['unit_id']]),
        {f"upstream/{p['unit_id']}/{m}":roots[p['unit_id']]/m for m in ('unit.json','result.zip')})
    return run,p,a,pr,ar,selector


def test_real_carrier_closure_can_be_received_one_pinned_index_at_a_time(tmp_path,monkeypatch):
    run,p,a,pr,ar,selector=_terminal_io_closure_fixture(tmp_path,monkeypatch)
    calls=[]
    def consume(*args):calls.append(args)
    monkeypatch.setattr(integrated,'consume_unit_estimability',consume)
    closed=runs._f45_estimability_dependencies(run,a['unit_id'],complete=True)
    assert len(calls)==1 and set(closed)=={f"units/{a['unit_id']}/result.zip",f"units/{p['unit_id']}/unit.json",
        f"units/{p['unit_id']}/result.zip",'contexts/OUTER-1/selector/coarse/paths.json'}
    destination=tmp_path/'receiver';destination.mkdir();copy=dict(run,run_root=str(destination))
    manifest=destination/'run.json';manifest.write_bytes(enc(copy));monkeypatch.setenv('PADML_F45_RUN_PATH',str(manifest))
    import shutil
    def move(name):
        target=destination/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(tmp_path/name,target)
    move(f"units/{a['unit_id']}/unit.json")
    assert set(runs._f45_estimability_dependencies(copy,a['unit_id']))=={f"units/{a['unit_id']}/result.zip"}
    move(f"units/{a['unit_id']}/result.zip")
    second=runs._f45_estimability_dependencies(copy,a['unit_id'])
    assert set(second)==set(closed)-{'contexts/OUTER-1/selector/coarse/paths.json'}
    move(f"units/{p['unit_id']}/result.zip")
    assert runs._f45_estimability_dependencies(copy,a['unit_id'])==closed
    assert not (destination/selector.relative_to(tmp_path)).exists() and len(calls)==1


def test_ordinary_model_result_cannot_enter_negative_transport(tmp_path,monkeypatch):
    run,p,a,pr,ar,selector=_terminal_io_closure_fixture(tmp_path,monkeypatch)
    root=tmp_path/'units'/p['unit_id'];pr['status']='COMPLETED';(root/'unit.json').write_bytes(enc(pr))
    with pytest.raises(ContractError,match='ESTIMABILITY_RECEIPT_INVALID'):
        runs._f45_estimability_dependencies(run,p['unit_id'])


def test_negative_evaluation_receipt_coverage_never_transfers_positive_matrices_or_draws():
    primaries=[f'PRIMARY-H06-O{i}' for i in range(1,7)]
    aars=[f'AAR-H06-O{i}' for i in range(1,7)]
    p=primaries[0];a=aars[0];deps=primaries+aars
    units={u:{'kind':'PRIMARY' if u in primaries else 'AAR'} for u in deps}
    units['E']={'kind':'EVALUATION','depends_on':deps}
    selector='contexts/OUTER-1/selector/coarse/paths.json'
    received=[];inventories=[]
    def transfer(source,target,name,**kw):
        assert '/evaluation-input.zip' not in name and not name.startswith('shared/')
        assert name!=f'units/{a}/result.zip'
        received.append(name)
    def call(host,operation,**kw):
        if operation=='dependency_inventory':
            assert kw['source_unit']==p and kw['source_type']=='estimability'
            inventories.append(p);return {f'units/{p}/result.zip':{},selector:{}}
        assert operation=='start'
        assert set(received)=={*(f'units/{u}/unit.json' for u in deps),f'units/{p}/result.zip',selector}
        return {'status':'OWNER_REGISTERED',**kw['assignment']}
    with ThreadPoolExecutor(max_workers=7) as pool:
        result=runs._f45_launch_assignments([{'host':'target','unit_id':'E'}],units,
            dict.fromkeys(deps,'source'),['existing-draw-host'],pool=pool,call=call,transfer=transfer,
            not_estimable_units=[p,a])
    assert result[0]['status']=='OWNER_REGISTERED' and inventories==[p]
    assert len(received)==len(set(received))==14


def test_negative_evaluation_does_not_wait_for_positive_compact_views(tmp_path):
    run,obs=_terminal_io_run_case(tmp_path)
    p,a='PRIMARY-H06-O1','AAR-H06-O1'
    for outer in range(2,7):
        for kind in ('PRIMARY','AAR'):
            uid=f'{kind}-H06-O{outer}'
            run['units'].insert(-1,dict(unit_id=uid,kind=kind,horizon=6,outer_fold=outer,
                context=f'OUTER-{outer}',depends_on=[] if kind=='PRIMARY' else [f'PRIMARY-H06-O{outer}']))
            run['units'][-1]['depends_on'].append(uid)
            obs['H0']['completed_units'].append(uid)
    obs['H0'].update(not_estimable_units=[p,a],evaluation_ready_units=[p,a])
    obs['H1']['not_estimable_units']=['FULL0-H06']
    chosen=runs.f45_ready_assignments(run,obs)
    assert any(row['unit_id']=='EVALUATION-H06' for row in chosen)
    assert not any('/evaluation-input.zip' in str(value) for value in obs.values())


def test_negative_launch_unknown_preserves_same_attempt_until_native_evidence():
    import time
    p='PRIMARY-H06-O1';state={};starts=[]
    def transfer(*a,**kw):return None
    def call(host,operation,**kw):
        if operation=='dependency_inventory':return {f'units/{p}/result.zip':{}}
        starts.append(kw['assignment']);raise TimeoutError('UNFITTED start reply lost')
    with ThreadPoolExecutor(max_workers=3) as pool:
        runs._f45_launch_assignments([{'host':'H0','unit_id':'E'}],
            {'E':{'kind':'EVALUATION','depends_on':[p]},p:{'kind':'PRIMARY'}},{p:'source'},[],
            pool=pool,call=call,transfer=transfer,not_estimable_units=[p],inflight=state)
        deadline=time.monotonic()+3
        while state['futures'] or state['queued']:
            assert time.monotonic()<deadline
            runs._f45_launch_assignments([],{}, {},[],pool=pool,call=call,transfer=transfer,inflight=state)
            time.sleep(.001)
        assert len(starts)==1 and state['active_transfers']==0 and state['uncertain']
        saved=next(iter(state['assignments'].values()))
        observations={'H0':{'state':'IDLE','active_unit':None}}
        runs._f45_reconcile_launches(state,observations,'a'*64)
        assert observations['H0']['state']=='UNKNOWN' and state['assignments']
        runs._f45_launch_assignments([],{}, {},[],pool=pool,call=call,transfer=transfer,inflight=state)
        assert starts==[saved]
        observations={'H0':{'state':'RUNNING','active_unit':'E','owner_record':{
            'run_identity':'a'*64,'unit_id':'E','mode':'execute','source_unit':None,
            'attempt_id':saved['attempt_id']}}}
        runs._f45_reconcile_launches(state,observations,'a'*64)
        assert not state['assignments'] and not state['uncertain'] and starts==[saved]


def test_negative_evaluation_owner_does_not_claim_shared_draw_creation(tmp_path,monkeypatch):
    units=runs.f45_units()
    run=dict(kind='PADML_INTEGRATED_RAW_RUN_V1',identity='a'*64,source_identity='b'*64,
        run_root=str(tmp_path),units=units,
        host_connections={h:{'ssh_target':'UNUSED','port':22} for h in runs.F45_HOSTS})
    obs={h:dict(state='IDLE',active_unit=None,local_contexts=[],completed_units=[],not_estimable_units=[],
        evaluation_ready_units=[],postprocess_ready_units=[],selection_completed_units=[]) for h in runs.F45_HOSTS}
    obs['H0'].update(state='UNKNOWN',active_unit='EVALUATION-H06',active_mode='execute',active_source_unit=None)
    negative={'PRIMARY-H06-O1','AAR-H06-O1'}
    for unit in units:
        if unit['kind']=='EVALUATION':continue
        host='H0' if unit['context']=='FULL0' else runs.F45_HOSTS[unit['outer_fold']]
        row=obs[host];uid=unit['unit_id']
        if unit['context'] not in row['local_contexts']:row['local_contexts'].append(unit['context'])
        row['not_estimable_units' if uid in negative else 'completed_units'].append(uid)
        if unit['kind'] in {'PRIMARY','AAR'}:row['evaluation_ready_units'].append(uid)
        if unit['kind'] in {'PRIMARY','FULL0'} and uid not in negative:
            row['postprocess_ready_units'].append(uid);row['selection_completed_units'].append(uid)
    monkeypatch.setattr(runs,'load_f45_run',lambda _:run)
    monkeypatch.setattr(runs,'_f45_remote_command',lambda r,h,c,p:[h,p['operation'],json.dumps(p)])
    starts=[]
    def command(args,**kwargs):
        host,operation,raw=args
        if operation=='observe':value=obs[host]
        elif operation=='pin':value={'sha256':'c'*64,'size_bytes':1}
        elif operation=='start':
            assignment=json.loads(raw)['assignment'];starts.append(assignment)
            value={'status':'OWNER_REGISTERED','pid':900001,**assignment}
        else:pytest.fail('UNFITTED unexpected RPC: '+operation)
        return subprocess.CompletedProcess(args,0,stdout=json.dumps(value).encode(),stderr=b'')
    monkeypatch.setattr(subprocess,'run',command)
    class Archive:
        def __init__(self,*args,**kwargs):pass
        def advance(self,*args):return {}
        def complete(self):return False
    monkeypatch.setattr(reports,'WindowArchive',Archive)
    result=runs.dispatch_f45_next(tmp_path/'run.json',code_root=Path('/opt/UNFITTED-release'),
        remote_run_path=Path('/data/UNFITTED-run.json'),archive_root=tmp_path/'archive', archive_mode='enabled',follow=False)
    assert len(starts)==1 and starts[0]['unit_id']=='EVALUATION-H12'
    assert len(result['jobs'])==1 and 'shared_draws' not in obs['H0']


# Cross-host negative evidence must not acquire context ownership or require model carriers.
import shutil
from padml import worker, runtime, runtime_bundle

def _audit_copied_negative_source(tmp_path,monkeypatch,*,complete):
    run,units,primary,receipt,publish=_negative_selector_unit(tmp_path,monkeypatch)
    aar,ar=publish(units[1],dependencies=[units[0]['unit_id']])
    source=Path(run['run_root'])
    (source/'contexts/OUTER-1/primary-context.json').write_bytes(b'{}')
    dest=tmp_path/'receiver';dest.mkdir()
    closure=runs._f45_estimability_dependencies(run,units[0]['unit_id'],complete=True)
    names=[f"units/{u['unit_id']}/unit.json" for u in units[:2]]+[f"units/{units[0]['unit_id']}/result.zip"]
    names += [name for name in closure if name.startswith('contexts/') and (complete or name.endswith('/coarse/paths.json'))]
    for name in names:
        target=dest/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source/name,target)
    copy={**run,'run_root':str(dest),'science_decision':{},'resource_policy':{}}
    manifest=dest/'run.json';manifest.write_bytes(enc(copy));monkeypatch.setenv('PADML_F45_RUN_PATH',str(manifest))
    return run,copy,units,manifest


def test_partial_reference_import_remains_unowned_and_observable(tmp_path,monkeypatch):
    run,copy,units,manifest=_audit_copied_negative_source(tmp_path,monkeypatch,complete=False)
    observed=runs._f45_host_observation(copy)
    assert observed['state']=='IDLE' and observed['local_contexts']==[]
    assert observed['completed_units']==observed['not_estimable_units']==[]


def test_full_reference_import_does_not_duplicate_context_affinity(tmp_path,monkeypatch):
    run,copy,units,manifest=_audit_copied_negative_source(tmp_path,monkeypatch,complete=True)
    # AAR receipt is only coverage. Omit it here to isolate the context collision itself.
    (Path(copy['run_root'])/'units'/units[1]['unit_id']/'unit.json').unlink()
    receiver=runs._f45_host_observation(copy)
    assert receiver['local_contexts']==[] and receiver['not_estimable_units']==[]
    observations={h:dict(state='IDLE',active_unit=None,completed_units=[],not_estimable_units=[],
        local_contexts=[],evaluation_ready_units=[],postprocess_ready_units=[],selection_completed_units=[]) for h in runs.F45_HOSTS}
    observations['H0']={**receiver}
    observations['H1']={**receiver,'local_contexts':['OUTER-1'],'not_estimable_units':[units[0]['unit_id']],
        'evaluation_ready_units':[units[0]['unit_id']]}
    assert runs.f45_ready_assignments(copy,observations)==[{'host':'H1','unit_id':units[1]['unit_id']}]


def test_negative_evaluation_consumes_twelve_receipts_without_aar_models_or_rng(tmp_path,monkeypatch):
    run,copy,units,manifest=_audit_copied_negative_source(tmp_path,monkeypatch,complete=True)
    copy['units']=runs.f45_units()
    evaluation=next(u for u in copy['units'] if u['unit_id']=='EVALUATION-H06')
    base=Path(copy['run_root'])
    for dependency in evaluation['depends_on']:
        path=base/'units'/dependency/'unit.json'
        if path.is_file():continue
        path.parent.mkdir(parents=True,exist_ok=True)
        path.write_bytes(enc(dict(status='COMPLETED',direct_consumer_completed=True,unit_id=dependency,
            run_identity=copy['identity'],selection_horizon_months=6,artifacts={})))
    shutil.copytree(Path(run['run_root'])/'binding',base/'binding')
    manifest.write_bytes(enc(copy))
    import platform
    monkeypatch.setattr(platform,'system',lambda:'Linux')
    monkeypatch.setattr(runs,'load_f45_run',lambda _:copy)
    monkeypatch.setattr(runs,'f45_unit_predecessors',lambda _:[])
    monkeypatch.setattr(runtime_bundle,'qualify_current_environment',lambda _:None)
    monkeypatch.setattr(integrated,'compact_retained_storage',lambda _:None)
    monkeypatch.setattr(runtime,'release_f45_cumulative_files',lambda *a,**k:None)
    monkeypatch.setattr(runtime,'observe_execution_resources',lambda *a:{})
    monkeypatch.setattr(runtime,'resource_admission',lambda *a,**k:{'admitted_worker_ceiling':1})
    from padml.bundle import sha256_file
    from padml import reports
    monkeypatch.setattr(worker,'_f45_file_pins',lambda paths,**k:{name:{'sha256':sha256_file(path),
        'size_bytes':path.stat().st_size} for name,path in paths.items()})
    def forbidden(*a,**k):pytest.fail('Negative EVAL cannot run science or create draws')
    monkeypatch.setattr(worker,'_f45_evaluation',forbidden)
    monkeypatch.setattr(runs,'prepare_f45_bootstrap',forbidden)
    result=worker.execute_f45(manifest,evaluation['unit_id'],attempt_id='f'*32)
    assert result['status']=='NOT_ESTIMABLE' and result['direct_consumer_completed'] is True
    from padml.carriers import open_carrier
    root=base/'units'/evaluation['unit_id']
    with open_carrier(root/'result.zip') as archive:
        header=json.loads(archive.read('estimability.json'))
        assert len(header['coverage'])==12 and len({r['unit_id'] for r in header['coverage']})==12
    inventory=reports.archive_inventory(copy,6,[evaluation['unit_id']],[])
    assert not any('/evaluation-input.zip' in name or '/bootstrap' in name for name in inventory['members'])
    assert 'units/AAR-H06-O1/result.zip' not in inventory['members']
    assert set(name for name in inventory['members'] if name.startswith('units/') and name.endswith('/unit.json'))=={
        *(f'units/{name}/unit.json' for name in evaluation['depends_on']),f"units/{evaluation['unit_id']}/unit.json"}
    assert json.loads((base/'active.lock').read_text().splitlines()[-1])['exit_status']=='RETURNED'


def test_negative_archive_ack_retires_only_original_context_owners(tmp_path,monkeypatch):
    from padml import nested_loco as n
    units=runs.f45_units();run=dict(kind='PADML_INTEGRATED_RAW_RUN_V1',identity='a'*64,
        source_identity='b'*64,run_root=str(tmp_path),units=units)
    horizon_units=[u for u in units if u['horizon']==6]
    inventory=n._sealed(dict(kind='PADML_WINDOW_ARCHIVE_INVENTORY_V1',run_identity=run['identity'],closure_version=2,
        horizon=6,units=[u['unit_id'] for u in horizon_units],selections=[],members={}))
    folder=tmp_path/'shared/archives';folder.mkdir(parents=True)
    (folder/'H06-inventory.json').write_bytes(enc(inventory))
    receipt=n._sealed(dict(kind='PADML_WINDOW_ARCHIVE_RECEIPT_V1',status='ARCHIVED',run_identity=run['identity'],closure_version=2,
        horizon=6,units=[u['unit_id'] for u in horizon_units],
        selections=[u['unit_id'] for u in horizon_units if u['kind'] in {'PRIMARY','FULL0'}],
        inventories={'H0':inventory['identity_sha256']}))
    # OUTER-1 receipts belong only to the imported evaluation coverage.
    for uid in ['PRIMARY-H06-O1','AAR-H06-O1','PRIMARY-H06-O2','AAR-H06-O2']:
        path=tmp_path/'units'/uid/'unit.json';path.parent.mkdir(parents=True);path.write_bytes(b'{}')
    monkeypatch.setattr(runs,'load_f45_run',lambda _:run)
    monkeypatch.setattr(runs,'_f45_host_observation',lambda _:{'state':'IDLE','local_contexts':['OUTER-2']})
    retired=[]
    monkeypatch.setattr(integrated,'retire_completed_outputs',lambda r,u,p:retired.append((u['unit_id'],u['context'])))
    result=runs._f45_remote_operation(dict(operation='archive_confirm',run=str(tmp_path/'run.json'),
        identity=run['identity'],receipt=receipt))
    assert result=={'horizon':6,'status':'CONFIRMED'}
    assert retired==[('PRIMARY-H06-O2','OUTER-2')]
    assert json.loads((folder/'H06-confirmed.json').read_bytes())==receipt


@pytest.mark.parametrize('case',['admitted','wrong_original_source','raw_drift'])
def test_negative_publication_predecessor_recovery_keeps_original_generation(tmp_path,monkeypatch,case):
    from padml import integrated
    from padml.bundle import ContractError, strict_json_bytes
    run,units,root,receipt,_=_negative_selector_unit(tmp_path,monkeypatch)
    original=(root/'result.zip').read_bytes()
    (root/'unit.json').unlink()  # Actual publication/receipt interruption boundary, fixture only.
    directory=Path(run['run_root'])/'contexts/OUTER-1/selector'
    development=strict_json_bytes((directory/'development-input.json').read_bytes())
    current={**run,'source_identity':'d'*64,'identity':'e'*64}
    generations={run['identity']:run['source_identity'],current['identity']:current['source_identity']}
    if case=='wrong_original_source': generations[run['identity']]='f'*64
    if case=='raw_drift': current['raw_input']={'sha256':'0'*64,'size_bytes':1}
    # Stand in only for the separately tested exact predecessor manifest reader.
    monkeypatch.setattr(integrated,'same_batch_generations',lambda _:generations)
    if case=='admitted':
        assert integrated.publish_unit_not_estimable(current,units[0],root,development=development,selector_root=directory)==[root/'result.zip']
        value=integrated.consume_not_estimable_result(current,units[0],root/'result.zip')
        assert value['run_identity']==run['identity'] and value['source_identity']==run['source_identity']
    else:
        with pytest.raises(ContractError,match='RAW_NOT_ESTIMABLE_IDENTITY_DRIFT|CARRIER_IDENTITY_DRIFT'):
            integrated.publish_unit_not_estimable(current,units[0],root,development=development,selector_root=directory)
    assert (root/'result.zip').read_bytes()==original
    assert not (root/'unit.json').exists()


@pytest.mark.parametrize('scenario', ['complete', 'partial', 'terminal'])
def test_frequency_final_report_keeps_terminal_and_complete_counts_distinct(tmp_path, monkeypatch, scenario):
    from padml import f4, f5
    from padml.bundle import strict_json_bytes, sha256_bytes

    units = runs.f45_units()
    run = dict(run_id='UNFITTED-terminal-report', identity='a'*64, source_identity='b'*64,
        run_root='/UNFITTED-offline', units=units)
    negative = {'PRIMARY-H24-O2', 'AAR-H24-O2', 'EVALUATION-H24'} if scenario == 'terminal' else set()
    partial = {'AAR-H06-O3', 'EVALUATION-H06'} if scenario != 'complete' else set()
    receipts, raw = {}, {}
    for unit in units:
        uid = unit['unit_id']
        receipt = dict(unit_id=uid, run_identity=run['identity'], status='NOT_ESTIMABLE' if uid in negative else 'COMPLETED',
            direct_consumer_completed=True, artifacts={'result.zip': {'sha256':'c'*64,'size_bytes':1}})
        if uid in negative:
            receipt['estimability'] = dict(status='NOT_ESTIMABLE', reason_code='FREQUENCY_LADDER_EXHAUSTED'
                if unit['kind']=='PRIMARY' else 'UPSTREAM_PRIMARY_NOT_ESTIMABLE')
        elif uid in partial:
            receipt['estimability'] = {'UNFITTED_branch_proof_already_qualified': True}
            if unit['kind']=='EVALUATION': receipt['artifacts']['report-estimability.json']={'sha256':'d'*64,'size_bytes':1}
        receipts[uid] = receipt
        raw[f'units/{uid}/unit.json'] = enc(receipt)
    training = {u['unit_id'] for u in units if u['kind'] in {'PRIMARY','FULL0'}}-negative
    names=reports.report_names(run, receipts, training, receipts=receipts)
    for name in names:
        if name in raw: continue
        if name.endswith('/application.json'): value=dict(source='UNFITTED',status='PASS',patient_count=2)
        elif name.endswith('/result.json'): value={'report_rows':[{'status':'ESTIMABLE','scope':'UNFITTED'}]}
        else:value={'UNFITTED':True}
        raw[name]=enc(value)
    index=dict(windows={str(h):{'not_estimable_units':sorted(u['unit_id'] for u in units
        if u['horizon']==h and u['unit_id'] in negative)} for h in (6,12,24,36)},
        members={name:{'pin':{'sha256':sha256_bytes(data),'size_bytes':len(data)},
            'storage':'objects/'+sha256_bytes(data),'member':None} for name,data in raw.items()})
    monkeypatch.setattr(reports,'_archive_index',lambda *args:index)
    monkeypatch.setattr(reports,'archived_bytes',lambda name,*args,**kwargs:raw[name])
    monkeypatch.setattr(reports,'same_batch_generations',lambda run:{run['identity']:run['source_identity']})
    def forbidden(*args,**kwargs):pytest.fail('report cannot call model, SHAP, metrics or RNG')
    monkeypatch.setattr(f4,'native_metrics',forbidden)
    monkeypatch.setattr(f4,'bootstrap_draws',forbidden)
    monkeypatch.setattr(f5,'execute_final_refit_batch',forbidden)
    monkeypatch.setattr(f5,'aggregate_final_shap',forbidden)
    observations={'H0':{'completed_units':sorted(set(receipts)-negative),'not_estimable_units':sorted(negative)}}
    result=reports.collect(run,observations,archive_root=tmp_path,call=forbidden,command=forbidden)
    saved=Path(result['report_index']); content=saved.read_bytes(); final=strict_json_bytes(content)
    expected='NOT_ESTIMABLE' if negative else 'PARTIALLY_NOT_ESTIMABLE' if partial else 'COMPLETED'
    assert result['status']==final['status']==expected
    assert result['terminal_units']==56 and result['scientific_units']==final['scientific_units']==56-len(negative|partial)
    assert final['training_contexts']==len(training)==28-sum(u['unit_id'] in negative for u in units if u['kind'] in {'PRIMARY','FULL0'})
    if scenario!='complete':
        outcomes=final['unit_outcomes']
        assert len(outcomes['completed'])+len(outcomes['partially_not_estimable'])+len(outcomes['not_estimable'])+len(outcomes['upstream_not_executable'])==56
        assert outcomes['partially_not_estimable']==sorted(partial)
        assert outcomes['upstream_not_executable']==sorted(negative-{'PRIMARY-H24-O2'})
        assert 'units/EVALUATION-H06/report-estimability.json' in final['files']
    assert reports.collect(run,observations,archive_root=tmp_path,call=forbidden,command=forbidden)==result
    assert saved.read_bytes()==content
    missing=next(name for name in index['members'] if name.endswith('/report-H06-paired_rows.csv'))
    del index['members'][missing]
    with pytest.raises(ContractError,match='REPORT_COVERAGE_INCOMPLETE'):
        reports.collect(run,observations,archive_root=tmp_path,call=forbidden,command=forbidden)


# FULL0 selection-draw references never acquire ownership of their producer.
def _full0_affinity_run(root, monkeypatch, *, integrated=True):
    monkeypatch.setattr(runs, "f45_unit_predecessors", lambda _: [])
    return {"kind": "PADML_INTEGRATED_RAW_RUN_V1" if integrated else "PADML_F45_RUN_V1",
        "run_root": str(root), "identity": "a"*64, "source_identity": "b"*64,
        "units": runs.f45_units()}


@pytest.mark.parametrize("complete", [False, True])
def test_full0_selection_draw_import_does_not_acquire_context_affinity(tmp_path, monkeypatch, complete):
    root = tmp_path/"receiver"
    marker = root/"contexts/OUTER-1/primary-context.json"
    marker.parent.mkdir(parents=True); marker.write_bytes(b"{}")
    draws = root/"contexts/FULL0/selection-draws"
    draws.mkdir(parents=True)
    # receive creates its parent before publishing any complete member.
    (draws/("draw.bin" if complete else ".transfer-unfinished")).write_bytes(b"one draw")
    run = _full0_affinity_run(root, monkeypatch)
    receiver = runs._f45_host_observation(run)
    assert receiver["local_contexts"] == ["OUTER-1"]
    source = tmp_path/"source"
    source_marker = source/"contexts/FULL0/common/full-development.json"
    source_marker.parent.mkdir(parents=True); source_marker.write_bytes(b"{}")
    producer = runs._f45_host_observation({**run, "run_root": str(source)})
    assert producer["local_contexts"] == ["FULL0"]
    observed = {host: dict(state="IDLE", active_unit=None, completed_units=[], local_contexts=[])
        for host in runs.F45_HOSTS}
    observed["H0"], observed["H5"] = producer, receiver
    assignments = runs.f45_ready_assignments(run, observed)
    assert any(row["host"] == "H0" and row["unit_id"] == "FULL0-H06" for row in assignments)
    assert not any(row["host"] == "H5" and row["unit_id"].startswith("FULL0-") for row in assignments)


@pytest.mark.parametrize("busy", [False, True])
def test_full0_first_owner_keeps_affinity_before_preparation_marker(tmp_path, monkeypatch, busy):
    import fcntl
    import subprocess
    from types import SimpleNamespace
    run = _full0_affinity_run(tmp_path, monkeypatch)
    owner = dict(pid=9001, pgid=9001, unit_id="FULL0-H06", mode="execute",
        source_unit=None, run_identity=run["identity"], attempt_id="1"*32)
    rows = [owner] if busy else [owner, dict(pgid=9001, exit_status="FAILED")]
    path = tmp_path/"active.lock"
    path.write_bytes(b"".join(enc(row)+b"\n" for row in rows))
    monkeypatch.setattr(subprocess, "run", lambda *a, **k: SimpleNamespace(stdout="9001 9001\n" if busy else ""))
    with path.open("a+") as handle:
        if busy: fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
        observed = runs._f45_host_observation(run)
    assert not (tmp_path/"contexts/FULL0/common/full-development.json").exists()
    assert observed["state"] == ("RUNNING" if busy else "UNKNOWN")
    assert observed["active_unit"] == "FULL0-H06" and observed["local_contexts"] == ["FULL0"]


def test_full0_two_real_context_markers_still_reject_relocation(tmp_path, monkeypatch):
    run = _full0_affinity_run(tmp_path, monkeypatch)
    observed = {host: dict(state="IDLE", active_unit=None, completed_units=[], local_contexts=[])
        for host in runs.F45_HOSTS}
    for host in ("H0", "H5"):
        root = tmp_path/host
        marker = root/"contexts/FULL0/common/full-development.json"
        marker.parent.mkdir(parents=True); marker.write_bytes(b"{}")
        observed[host] = runs._f45_host_observation({**run, "run_root": str(root)})
    with pytest.raises(ContractError, match="F45_CONTEXT_RELOCATION_MUST_BE_RESOLVED"):
        runs.f45_ready_assignments(run, observed)


def test_legacy_full0_context_directory_affinity_is_unchanged(tmp_path, monkeypatch):
    (tmp_path/"contexts/FULL0").mkdir(parents=True)
    run = _full0_affinity_run(tmp_path, monkeypatch, integrated=False)
    assert runs._f45_host_observation(run)["local_contexts"] == ["FULL0"]

# Real local flock/process interleavings; all scientific entries are forbidden/seams.
def _native_owner_lock_probe(action, run, channel):
    import fcntl
    import os
    import platform
    import subprocess
    from padml import run as r, worker as w, runtime as rt, f4
    os.setsid()
    r.f45_unit_predecessors = lambda _: []
    lock = Path(run['run_root'])/'active.lock'
    actual_ps, actual_flock = subprocess.run, fcntl.flock
    def command():
        if not channel.poll(8): raise TimeoutError('owned fixture command exceeded 8s')
        return channel.recv()
    try:
        if action.startswith('writer-'):
            with lock.open('a+') as handle:
                actual_flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
                if action != 'writer-old':
                    owner = dict(pid=os.getpid(),pgid=os.getpgrp(),unit_id='FULL0-H06',mode='execute',
                        source_unit=None,run_identity=run['identity'],attempt_id='2'*32)
                    handle.seek(0);handle.truncate()
                    handle.write('{"pid":' if action == 'writer-partial' else json.dumps(owner)+'\n')
                    handle.flush();os.fsync(handle.fileno())
                    if action == 'writer-live-tail':
                        handle.write('{"pgid":');handle.flush();os.fsync(handle.fileno())
                channel.send({'phase':'EX_HELD'})
                request=command()
                if action == 'writer-old' and request == 'PARTIAL':
                    handle.seek(0);handle.truncate();handle.write('{"pid":');handle.flush();os.fsync(handle.fileno())
                    channel.send({'phase':'PARTIAL_WRITTEN'});request=command()
                assert request == 'RELEASE'
                if action == 'writer-live-tail':
                    handle.write(str(os.getpgrp())+'}\n')
                if action in {'writer-live','writer-live-tail'}:
                    handle.write(json.dumps(dict(pgid=os.getpgrp(),exit_status='RETURNED'))+'\n')
                    handle.flush();os.fsync(handle.fileno())
            channel.send({'status':'RETURNED'})
            return
        if action == 'observe-gated':
            gated = [False]
            def ps(*args, **kwargs):
                if not gated[0] and args[0] == ['ps','-eo','pid=,pgid=']:
                    gated[0] = True;channel.send({'phase':'PS'})
                    assert command() == 'RELEASE'
                return actual_ps(*args, **kwargs)
            subprocess.run = ps
        if action.startswith('observe'):
            value = r._f45_host_observation(run)
        else:
            assert action == 'worker'
            contention = [0]
            def flock(handle, mode):
                try: return actual_flock(handle, mode)
                except BlockingIOError:
                    if mode == fcntl.LOCK_EX | fcntl.LOCK_NB:
                        contention[0] += 1
                        if contention[0] == 1:channel.send({'phase':'EX_CONTENDED'})
                    raise
            fcntl.flock = flock
            platform.system = lambda:'Linux'
            r.load_f45_run = lambda _:dict(run,kind='PADML_F45_RUN_V1',science_decision={})
            f4.run_f45_selection = lambda *a,**k:{'UNFITTED_SELECTION_ENTRY':True}
            rt.release_f45_cumulative_files = lambda *a,**k:None
            value = w.execute_f45(Path(run['run_root'])/'run.json','EVALUATION-H06',
                mode='selection',source_unit='FULL0-H06',attempt_id='3'*32)
            value = {'entry':value,'contention':contention[0]}
        channel.send({'status':'RETURNED','value':value})
    except Exception as error:
        channel.send({'status':'ERROR','error':str(error),'error_type':type(error).__name__})
    finally:
        channel.close()


@pytest.fixture
def native_owner_lock_case(tmp_path):
    import multiprocessing as mp
    import sys
    context=mp.get_context('spawn')
    old=subprocess.Popen([sys.executable,'-B','-c','pass'],start_new_session=True)
    assert old.wait(timeout=5)==0
    owner=dict(pid=old.pid,pgid=old.pid,unit_id='FULL0-H06',mode='execute',source_unit=None,
        run_identity='a'*64,attempt_id='1'*32)
    path=tmp_path/'active.lock'
    raw=(json.dumps(owner)+'\n'+json.dumps(dict(pgid=old.pid,exit_status='RETURNED'))+'\n').encode()
    path.write_bytes(raw);inode=path.stat().st_ino
    run=dict(kind='PADML_INTEGRATED_RAW_RUN_V1',identity='a'*64,source_identity='b'*64,
        run_root=str(tmp_path),units=runs.f45_units())
    children=[]
    def start(action):
        parent,child=context.Pipe()
        process=context.Process(target=_native_owner_lock_probe,args=(action,run,child))
        process.start();child.close();children.append((process,parent))
        return process,parent
    def recv(channel):
        assert channel.poll(8),'owned fixture response exceeded 8s'
        return channel.recv()
    try:
        yield run,path,raw,inode,start,recv
    finally:
        for process,channel in children:
            if process.is_alive():
                try:channel.send('RELEASE')
                except (OSError,EOFError):pass
        for process,channel in children:
            process.join(3)
            if process.is_alive():process.kill();process.join(3)
            channel.close()
            assert not process.is_alive()


def test_native_observers_do_not_confuse_each_other_with_worker(native_owner_lock_case):
    run,path,raw,inode,start,recv=native_owner_lock_case
    first,a=start('observe-gated');assert recv(a)=={'phase':'PS'}
    second,b=start('observe');result=recv(b)
    assert result['status']=='RETURNED' and result['value']['state']=='IDLE'
    a.send('RELEASE');assert recv(a)['value']['state']=='IDLE'
    assert path.read_bytes()==raw and path.stat().st_ino==inode


@pytest.mark.parametrize('expired',[False,True])
def test_native_worker_waits_for_short_read_lock_without_new_attempt(native_owner_lock_case,expired):
    run,path,raw,inode,start,recv=native_owner_lock_case
    reader,a=start('observe-gated');assert recv(a)=={'phase':'PS'}
    worker,b=start('worker');assert recv(b)=={'phase':'EX_CONTENDED'}
    if expired:
        result=recv(b)
        assert result=={'status':'ERROR','error':'F45_OWNER_READ_CONTENTION_TIMEOUT','error_type':'ContractError'}
        assert path.read_bytes()==raw and path.stat().st_ino==inode
        a.send('RELEASE');assert recv(a)['value']['state']=='IDLE'
        return
    a.send('RELEASE');assert recv(a)['value']['state']=='IDLE'
    result=recv(b)
    assert result['status']=='RETURNED' and result['value']['entry']=={'UNFITTED_SELECTION_ENTRY':True}
    assert result['value']['contention']>=1
    rows=[json.loads(line) for line in path.read_text().splitlines()]
    assert rows[0]['attempt_id']=='3'*32 and rows[-1]['exit_status']=='RETURNED'
    assert path.stat().st_ino==inode


def test_native_worker_rejects_real_exclusive_owner(native_owner_lock_case):
    run,path,raw,inode,start,recv=native_owner_lock_case
    holder,a=start('writer-live');assert recv(a)=={'phase':'EX_HELD'}
    before=path.read_bytes()
    worker,b=start('worker');assert recv(b)=={'phase':'EX_CONTENDED'}
    result=recv(b)
    assert result=={'status':'ERROR','error':'F45_INSTANCE_ALREADY_RUNNING','error_type':'ContractError'}
    assert path.read_bytes()==before and path.stat().st_ino==inode
    a.send('RELEASE');assert recv(a)['status']=='RETURNED'


def test_native_owner_exit_between_busy_probe_and_ps_is_reobserved(native_owner_lock_case):
    run,path,raw,inode,start,recv=native_owner_lock_case
    holder,a=start('writer-live');assert recv(a)=={'phase':'EX_HELD'}
    observer,b=start('observe-gated');assert recv(b)=={'phase':'PS'}
    a.send('RELEASE');assert recv(a)['status']=='RETURNED';holder.join(3);assert holder.exitcode==0
    b.send('RELEASE');result=recv(b)
    assert result['status']=='RETURNED' and result['value']['state']=='IDLE'
    assert path.stat().st_ino==inode


@pytest.mark.parametrize('writer',['writer-old','writer-partial'])
def test_native_registration_gap_stays_unknown_without_stale_owner(native_owner_lock_case,writer):
    run,path,raw,inode,start,recv=native_owner_lock_case
    holder,a=start(writer);assert recv(a)=={'phase':'EX_HELD'}
    before=path.read_bytes()
    observer,b=start('observe');result=recv(b)
    assert result['status']=='RETURNED' and result['value']['state']=='UNKNOWN'
    assert result['value']['active_unit'] is None
    assert result['value']['reason'] in {'OWNER_LOCKED_WITHOUT_IDENTITY','OWNER_LOCKED_WITHOUT_LIVE_IDENTITY'}
    assert path.read_bytes()==before and path.stat().st_ino==inode
    a.send('RELEASE');assert recv(a)['status']=='RETURNED'


def test_native_observation_does_not_relax_complete_foreign_owner(native_owner_lock_case,monkeypatch):
    run,path,raw,inode,start,recv=native_owner_lock_case
    monkeypatch.setattr(runs,'f45_unit_predecessors',lambda _:[])
    rows=[json.loads(line) for line in raw.splitlines()];rows[0]['run_identity']='f'*64
    changed=b''.join(enc(row)+b'\n' for row in rows);path.write_bytes(changed)
    with pytest.raises(ContractError,match='F45_OWNER_IDENTITY_UNKNOWN'):
        runs._f45_host_observation(run)
    assert path.read_bytes()==changed and path.stat().st_ino==inode


@pytest.mark.parametrize('reason',['OWNER_LOCKED_WITHOUT_IDENTITY','OWNER_LOCKED_WITHOUT_LIVE_IDENTITY','UNRELATED_UNKNOWN'])
def test_registration_gap_uses_only_existing_pending_attempt(reason):
    assignment=dict(host='H0',unit_id='FULL0-H06',attempt_id='1'*32)
    future=Future();future.set_running_or_notify_cancel()
    state=dict(assignments={0:assignment},pending={0:1},uncertain={},futures={future:(0,'start')})
    observations={'H0':dict(state='UNKNOWN',active_unit=None,reason=reason,
        owner_record=dict(run_identity='a'*64,unit_id='FULL0-H36',attempt_id='2'*32,exit_status='RETURNED'))}
    runs._f45_reconcile_launches(state,observations,'a'*64)
    expected=None if reason=='UNRELATED_UNKNOWN' else assignment['unit_id']
    assert observations['H0']['active_unit']==expected and observations['H0']['state']=='UNKNOWN'
    assert state['assignments']=={0:assignment} and state['pending']=={0:1} and future in state['futures']


def test_remote_pre_spawn_denial_does_not_create_child_or_owner(tmp_path,monkeypatch):
    run,_=_quarantine_case(tmp_path)
    run['environment']={'python':'/UNFITTED/python'}
    assignment=dict(host='H0',unit_id='PRIMARY-H06-O1',attempt_id='7'*32)
    monkeypatch.setattr(runs,'load_f45_run',lambda _:run)
    monkeypatch.setattr(runs,'_f45_host_observation',lambda _:dict(state='UNKNOWN',active_unit=None,
        reason='OWNER_LOCKED_WITHOUT_LIVE_IDENTITY'))
    monkeypatch.setattr(subprocess,'Popen',lambda *a,**k:pytest.fail('pre-spawn denial created child'))
    before={p:p.read_bytes() for p in tmp_path.iterdir() if p.is_file()}
    result=runs._f45_remote_operation(dict(operation='start',run=str(tmp_path/'run.json'),
        identity=run['identity'],assignment=assignment))
    assert result['status']=='START_NOT_ADMITTED' and result['attempt_id']==assignment['attempt_id']
    assert {p:p.read_bytes() for p in tmp_path.iterdir() if p.is_file()}==before


def test_pre_spawn_denial_releases_only_that_launch_without_uncertain_attempt():
    assignment=dict(host='H0',unit_id='FULL0-H06',attempt_id='7'*32)
    state={}
    def call(host,operation,**extra):
        assert operation=='start'
        return dict(status='START_NOT_ADMITTED',**extra['assignment'])
    with ThreadPoolExecutor(max_workers=1) as pool:
        result=runs._f45_launch_assignments([assignment],{'FULL0-H06':{'kind':'FULL0'}},{},[],
            pool=pool,call=call,transfer=lambda *a,**k:pytest.fail('unexpected transfer'),inflight=state)
        result+=_drain_launch_fixture(state,pool,call,lambda *a,**k:pytest.fail('unexpected transfer'))
    assert not state['assignments'] and not state['pending'] and not state['uncertain']



def test_second_registration_snapshot_discards_obsolete_owner_header(native_owner_lock_case):
    run,path,raw,inode,start,recv=native_owner_lock_case
    holder,a=start('writer-old');assert recv(a)=={'phase':'EX_HELD'}
    observer,b=start('observe-gated');assert recv(b)=={'phase':'PS'}
    a.send('PARTIAL');assert recv(a)=={'phase':'PARTIAL_WRITTEN'}
    b.send('RELEASE');result=recv(b)
    assert result['status']=='RETURNED'
    value=result['value']
    assert value['state']=='UNKNOWN' and value['active_unit'] is None and 'owner_record' not in value
    assert value['reason']=='OWNER_LOCKED_WITHOUT_IDENTITY'
    assert path.stat().st_ino==inode
    a.send('RELEASE');assert recv(a)['status']=='RETURNED'



def test_live_owner_partial_group_tail_does_not_lose_registered_head(native_owner_lock_case):
    run,path,raw,inode,start,recv=native_owner_lock_case
    holder,a=start('writer-live-tail');assert recv(a)=={'phase':'EX_HELD'}
    before=path.read_bytes();assert before.endswith(b'{"pgid":')
    observer,b=start('observe');result=recv(b)
    assert result['status']=='RETURNED'
    value=result['value']
    assert value['state']=='RUNNING' and value['active_unit']=='FULL0-H06'
    assert value['owner_record']['pid']==holder.pid and value['owner_record']['attempt_id']=='2'*32
    assert path.read_bytes()==before and path.stat().st_ino==inode
    a.send('RELEASE');assert recv(a)['status']=='RETURNED'


@pytest.mark.parametrize('post_result_repair', [False, True])
def test_completed_training_still_dispatches_appendage_and_loco_waits_for_km(post_result_repair):
    p={'unit_id':'PRIMARY-H12-O1','kind':'PRIMARY','context':'OUTER-1','horizon':12,'depends_on':[]}
    e={'unit_id':'EVALUATION-H12','kind':'EVALUATION','context':'EVALUATION','horizon':12,'depends_on':[p['unit_id']]}
    run={'kind':'PADML_INTEGRATED_RAW_RUN_V1','units':[p,e],'evaluation_decision':f4.evaluation_decision()}
    hosts=list(runs.F45_HOSTS)
    obs={h:{'state':'IDLE','active_unit':None,'completed_units':[],'not_estimable_units':[],
            'local_contexts':[],'evaluation_ready_units':[],'postprocess_ready_units':[],
            'selection_completed_units':[],'evaluation_amendment_units':[],'selection_amendment_units':[]} for h in hosts}
    obs[hosts[0]].update(completed_units=[p['unit_id']],local_contexts=['OUTER-1'],
        evaluation_ready_units=[p['unit_id']],postprocess_ready_units=[p['unit_id']])
    obs[hosts[1]].update(completed_units=[e['unit_id']],selection_completed_units=[p['unit_id']])
    if post_result_repair:
        run['post_result_repair'] = f4.post_result_repair_decision()
        blocked = runs.f45_ready_assignments(run, obs)
        assert not any(a['unit_id'] == p['unit_id'] and a.get('mode') == 'appendage' for a in blocked)
        obs[hosts[-1]]['original_application_regression_complete'] = True
    first=runs.f45_ready_assignments(run,obs)
    assert {'host':hosts[0],'unit_id':p['unit_id'],'mode':'appendage'} in first
    assert not any(a['unit_id']==e['unit_id'] and a.get('source_unit') is None for a in first)
    obs[hosts[0]]['evaluation_amendment_units']=[p['unit_id']]
    second=runs.f45_ready_assignments(run,obs)
    assert {'host':hosts[1],'unit_id':e['unit_id'],'mode':'appendage'} in second
    obs[hosts[1]]['evaluation_amendment_units']=[e['unit_id']]
    assert runs.f45_ready_assignments(run,obs)==[
        {'host':hosts[1],'unit_id':e['unit_id'],'mode':'appendage','source_unit':p['unit_id']}]
    obs[hosts[1]]['selection_amendment_units']=[p['unit_id']]
    assert runs.f45_ready_assignments(run,obs)==[]

@pytest.mark.parametrize('case', ['complete', 'held_open', 'truncated', 'oversize', 'wrong_sha', 'existing_drift'])
def test_native_receive_pipe_has_bounded_eof_and_preserves_publication(tmp_path, case):
    data = b'UNFITTED pinned member'
    pin = {'size_bytes': len(data), 'sha256': sha256_bytes(data)}
    target = tmp_path/'member'
    original = b'UNFITTED original protected bytes'
    if case == 'existing_drift': target.write_bytes(original)
    raw = data[:-1] if case == 'truncated' else data+b'x' if case == 'oversize' else data
    if case == 'wrong_sha': pin['sha256'] = '0'*64
    reader, writer = os.pipe()
    try:
        os.write(writer, raw)
        if case != 'held_open': os.close(writer); writer = None
        with os.fdopen(reader, 'rb', buffering=0) as source:
            if case in {'truncated', 'oversize', 'wrong_sha', 'existing_drift'}:
                with pytest.raises(ContractError, match='F45_TRANSFER_'):
                    runs._f45_receive_file(target, pin, source, idle_seconds=.02, total_seconds=.2)
            else:
                result = runs._f45_receive_file(target, pin, source, idle_seconds=.02, total_seconds=.2)
                if case == 'held_open':
                    assert result == dict(status='TRANSFER_RETRY_REQUIRED', reason='F45_TRANSFER_INPUT_TIMEOUT', pin=pin)
                else: assert result == pin and target.read_bytes() == data
        assert not list(tmp_path.glob('.transfer-*'))
        if case == 'existing_drift': assert target.read_bytes() == original
        elif case != 'complete': assert not target.exists()
    finally:
        if writer is not None: os.close(writer)


def test_transfer_unknown_keeps_same_attempt_and_cancels_siblings_but_not_peer():
    from concurrent.futures import Future
    from collections import deque
    state = dict(assignments={0: dict(host='bad', unit_id='E', mode='selection',
        source_unit='P', source_host='source', attempt_id='1'*32)}, pending={0:5}, next_index=1,
        queued=deque([(0,'member','source','bad','UNFITTED-queued',{})]), futures={}, active_transfers=3)
    failed, inventory, member1, member2 = Future(), Future(), Future(), Future()
    failed.set_exception(runs._F45TransferOutcomeUnknown('UNFITTED receive reply lost'))
    state['futures'] = {failed:(0,'member'), member1:(0,'member'), member2:(0,'member'), inventory:(0,'inventory')}
    starts=[]
    def forbidden(*a, **k): pytest.fail('An uncertain transfer cannot prepare/start its closure')
    with ThreadPoolExecutor(max_workers=2) as pool:
        result=runs._f45_launch_assignments([],{}, {},[],pool=pool,call=forbidden,transfer=forbidden,inflight=state)
        assert result[0]['status']=='TRANSFER_OUTCOME_UNKNOWN' and not state['queued']
        saved=state['assignments'][0].copy()
        inventory.set_result({'UNFITTED-new-member': {}})
        member1.set_result(None); member2.set_result(None)
        _drain_launch_fixture(state,pool,forbidden,forbidden)
        assert state['pending']=={0:0} and state['assignments']=={0:saved} and state['active_transfers']==0
        observations={'bad':dict(state='IDLE',active_unit=None,owner_record=dict(
            run_identity='a'*64,unit_id='E',mode='selection',source_unit='P',
            attempt_id='2'*32,exit_status='RETURNED'))}
        runs._f45_reconcile_launches(state, observations,'a'*64)
        assert state['assignments']=={0:saved} and observations['bad']['state']=='UNKNOWN'
        def call(host, operation, **kw):
            starts.append(host);return dict(status='OWNER_REGISTERED',**kw['assignment'])
        runs._f45_launch_assignments([dict(host='good',unit_id='P')],{'P':{'kind':'PRIMARY'}},
            {},[],pool=pool,call=call,transfer=forbidden,inflight=state)
        _drain_launch_fixture(state,pool,call,forbidden)
        assert starts==['good'] and state['assignments']=={0:saved}


def test_follow_observation_outage_preserves_lock_attempt_and_defers_pump(tmp_path, monkeypatch):
    import fcntl, signal
    from padml import reports
    run=dict(kind='PADML_INTEGRATED_RAW_RUN_V1',run_root=str(tmp_path),identity='a'*64,
        units=[dict(unit_id='E',kind='EVALUATION',context='EVALUATION',horizon=6,depends_on=[])],
        host_connections={h:{'ssh_target':'UNUSED'} for h in runs.F45_HOSTS})
    rows={h:dict(state='IDLE',active_unit=None,completed_units=[],local_contexts=[],
        evaluation_ready_units=[],postprocess_ready_units=[],selection_completed_units=[]) for h in runs.F45_HOSTS}
    assignment=dict(host='H1',unit_id='E',mode='selection',source_host='H0',source_unit='P')
    phase=[0]; saved=[None]; states=[]; calls=[]; archived=[]; pumps=[]; starts=[]
    monkeypatch.setattr(runs,'load_f45_run',lambda _:run)
    monkeypatch.setattr(runs,'_f45_remote_command',lambda r,h,c,p:[h,p['operation'],json.dumps(p)])
    monkeypatch.setattr(runs,'f45_ready_assignments',lambda *a:[assignment] if phase[0]==0 else [])
    pin={'sha256':sha256_bytes(b'x'),'size_bytes':1}
    def call(cmd, **kw):
        h,op,raw=cmd;calls.append((phase[0],op))
        if op=='observe':
            if phase[0]==1 and h in ('H0','H4','H5','H6'):
                return subprocess.CompletedProcess(cmd,255,stdout=b'',stderr=b'UNFITTED transient network')
            value=rows[h]
        elif op=='pin':value=pin if h=='H0' else {'status':'ABSENT'}
        elif op=='receive':value=pin
        elif op=='dependency_inventory':value={}
        elif op=='start':
            starts.append(json.loads(raw)['assignment'])
            value=dict(status='OWNER_REGISTERED',**starts[-1])
        else:pytest.fail(op)
        return subprocess.CompletedProcess(cmd,0,stdout=json.dumps(value).encode(),stderr=b'')
    monkeypatch.setattr(subprocess,'run',call)
    monkeypatch.setattr(subprocess,'Popen',lambda *a,**k:SimpleNamespace(
        stdout=io.BytesIO(b'x'),wait=lambda **_:0,poll=lambda:0))
    native=runs._f45_launch_assignments
    def launch(*a, **kw):
        pumps.append(phase[0]);states[:] = [kw['inflight']]
        return native(*a,**kw)
    monkeypatch.setattr(runs,'_f45_launch_assignments',launch)
    class Archive:
        def __init__(self,*a,**k):pass
        def advance(self,*a,**kw):archived.append(phase[0]);return {}
        def drained(self):return True
        def complete(self):return False
    monkeypatch.setattr(reports,'WindowArchive',Archive)
    sleeps=[0]
    def pause(_):
        sleeps[0]+=1;assert sleeps[0]<12
        state=states[0]
        if state['futures']:
            assert not wait(tuple(state['futures']),timeout=2)[1]
        with (tmp_path/'.dispatch.lock').open('a+') as handle:
            with pytest.raises(BlockingIOError):fcntl.flock(handle,fcntl.LOCK_EX|fcntl.LOCK_NB)
        if phase[0]==0:
            saved[0]=dict(next(iter(state['assignments'].values())))
            phase[0]=1
        elif phase[0]==1:
            assert list(state['assignments'].values())==[saved[0]]
            assert 1 not in pumps and 1 not in archived
            assert not any(p==1 and op!='observe' for p,op in calls)
            phase[0]=2
        elif not state['assignments']:
            signal.getsignal(signal.SIGINT)(signal.SIGINT,None)
    monkeypatch.setattr(time,'sleep',pause)
    result=runs.dispatch_f45_next(tmp_path/'run.json',code_root=Path('/opt/UNFITTED'),
        remote_run_path=Path('/data/UNFITTED-run.json'),archive_root=tmp_path/'archive', archive_mode='enabled',follow=True)
    assert result['status']=='DRAINED'
    assert len([x for x in calls if x[1]=='start'])==1 and 1 not in archived
    assert starts == [saved[0]] and sleeps[0]>=3


def test_native_receive_total_deadline_does_not_publish_even_with_input(tmp_path, monkeypatch):
    data=b'UNFITTED complete-but-over-budget member'
    pin=dict(size_bytes=len(data),sha256=sha256_bytes(data))
    target=tmp_path/'member';reader,writer=os.pipe()
    ticks=iter([0.,0.,2.]);monkeypatch.setattr(time,'monotonic',lambda:next(ticks))
    try:
        os.write(writer,data)
        with os.fdopen(reader,'rb',buffering=0) as source:
            result=runs._f45_receive_file(target,pin,source,idle_seconds=.02,total_seconds=1)
        assert result==dict(status='TRANSFER_RETRY_REQUIRED',reason='F45_TRANSFER_TOTAL_TIMEOUT',pin=pin)
        assert not target.exists() and not list(tmp_path.glob('.transfer-*'))
    finally:os.close(writer)
@pytest.mark.parametrize('length',[28,29,128,129])
def test_complete_predecessor_capacity_preserves_each_edge(monkeypatch,length):
    from padml import run as r,integrated
    nodes=[{'identity':str(i),'unit_predecessor':{'next':i+1}} for i in range(length)]+[{'identity':str(length)}]
    checked=[]
    def read(owner):
        checked.append(owner['unit_predecessor']['next'])
        return nodes[owner['unit_predecessor']['next']]
    monkeypatch.setattr(integrated,'is_integrated',lambda _:True)
    monkeypatch.setattr(r,'f45_unit_predecessor',read)
    if length>128:
        with pytest.raises(ContractError,match='CHAIN_INVALID'):r.f45_unit_predecessors(nodes[0])
    else:
        assert [v['identity'] for v in r.f45_unit_predecessors(nodes[0])]==[str(i) for i in range(1,length+1)]
    assert checked==list(range(1,length+1))


def test_predecessor_cycle_and_edge_pin_failure_remain_errors(monkeypatch):
    from padml import run as r,integrated
    monkeypatch.setattr(integrated,'is_integrated',lambda _:True)
    value={'identity':'A','unit_predecessor':{'next':'A'}}
    monkeypatch.setattr(r,'f45_unit_predecessor',lambda _:value)
    with pytest.raises(ContractError,match='CHAIN_INVALID'):r.f45_unit_predecessors(value)
    def drift(_):raise ContractError('F45_UNIT_PREDECESSOR_SOURCE_DRIFT')
    monkeypatch.setattr(r,'f45_unit_predecessor',drift)
    with pytest.raises(ContractError,match='SOURCE_DRIFT'):r.f45_unit_predecessors(value)
