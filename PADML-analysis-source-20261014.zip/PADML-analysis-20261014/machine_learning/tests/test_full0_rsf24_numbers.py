"""Bounded historical metadata tests. No IBS, model fit or native replay.

The real pair tests require the original two ZIPs, not synthetic replacement
pins. They do not establish live RSF24 promotion or full archive acceptance.
"""
import copy
import os
from pathlib import Path
import zipfile

import pytest

from padml import f2_kernel as kernel, f4, f5
from padml.bundle import ContractError, canonical_json_bytes, sha256_bytes, sha256_file, strict_json_bytes, extract_safe_zip


@pytest.fixture
def real_rsf24_pair():
    value = os.environ.get("PADML_RSF24_METADATA_FIXTURES")
    if value is None:
        pytest.skip("requires actual original prepared79fe and last-four8cce archives")
    root = Path(value)
    with zipfile.ZipFile(root / "H1-full0-RSF-restoration-prepared-79fe72c928ca-20260912.zip") as archive:
        original = strict_json_bytes(archive.read("input.json"))
    with zipfile.ZipFile(root / "H7-full0-12-RSF-s3b2-P15-M09-12-numbers-8cce1d0042a8-20260914.zip") as archive:
        producer = strict_json_bytes(archive.read("batch/input.json"))
        child = strict_json_bytes(archive.read("batch/native/batch-61fff41813b64d1c008337ca/spec.json"))
    return original, producer, child["producer_tasks"]


def test_real_rsf24_pair_keeps_producer12_role(real_rsf24_pair):
    original, producer, tasks = real_rsf24_pair
    f5._full0_rsf24_numbers_input_pair(producer, original, tasks, copy.deepcopy(tasks))
    assert producer["task"]["selection_horizon_months"] == 12
    assert original["task"].get("selection_horizon_months", 24) == 24


@pytest.mark.parametrize("field", ["seed", "parameters", "parents", "recipe", "reverse"])
def test_real_rsf24_pair_rejects_drift_without_ibs(real_rsf24_pair, field):
    original, producer, tasks = copy.deepcopy(real_rsf24_pair)
    current = copy.deepcopy(tasks)
    if field == "seed":
        current[0]["seed"] += 1
    elif field == "parameters":
        current[0]["parameters"]["num_trees"] += 1
    elif field == "parents":
        current[0]["selected_parents"] = current[0]["selected_parents"][:-1]
    elif field == "recipe":
        producer["spec"]["selector_from_dependency"]["outer_recipe_sha256"] = "0" * 64
    else:
        original, producer = producer, original
    with pytest.raises(ContractError, match="F5_FULL0_RSF24_NUMBERS_INPUT_PAIR_INVALID"):
        f5._full0_rsf24_numbers_input_pair(producer, original, tasks, current)


@pytest.mark.parametrize("mode", ["produce", "audit"])
def test_rsf24_marker_cannot_enter_scientific_executor(tmp_path, mode):
    with pytest.raises(ContractError, match="F5_FULL0_RSF24_NUMBERS_ONLY"):
        f5._q_search_unit_call(kernel._run_r_prediction_pool_task, (), tmp_path,
            tmp_path / "work", mode=mode, full0_rsf24_numbers_pair={})


@pytest.mark.parametrize("extra", [{"prepare_only": True}, {"task_ids": ["x"]},
    {"retained_bytes_per_task": 1}, {"continuous_batch_root": Path("/not-used")}])
def test_numbers_only_public_entry_rejects_execution_options_before_io(tmp_path, extra):
    with pytest.raises(ContractError, match="F5_FULL0_RSF24_NUMBERS_ONLY"):
        f5.execute_final_complex_search(target=tmp_path / "result.zip",
            full_development_path=tmp_path / "full-development.json", candidate_family="RSF",
            q_batches=[tmp_path / "batch"], retained_full0_source_bundle=tmp_path / "source.zip",
            full0_rsf24_numbers_only={}, **extra)


@pytest.fixture
def real_rsf24_leaf(tmp_path, real_rsf24_pair):
    """Original numeric/object-audit bytes; only consumption copies are new."""
    source = os.environ.get("PADML_RSF24_LAST_FOUR_SOURCE")
    if source is None:
        pytest.skip("requires the real 8cce source ZIP and updated current-side source proof")
    source = Path(source).resolve(strict=True)
    original, producer, _ = real_rsf24_pair
    archive_path = Path(os.environ["PADML_RSF24_METADATA_FIXTURES"]) / (
        "H7-full0-12-RSF-s3b2-P15-M09-12-numbers-8cce1d0042a8-20260914.zip")
    assert sha256_file(archive_path) == "6ae8eb601d033a9873bf064c295c73540900151070bf66c1b1aecac49b371531"
    with zipfile.ZipFile(archive_path) as archive:
        pins = {item.filename: {"sha256": sha256_bytes(archive.read(item.filename)), "size_bytes": item.file_size}
                for item in archive.infolist() if not item.is_dir()}
    expanded = tmp_path / "retained"
    extract_safe_zip(archive_path, expanded, expected_members=pins,
        max_member_bytes=32 * 1024**2, max_total_bytes=64 * 1024**2)
    batch = expanded / "batch"
    original_spec = batch / "native/batch-61fff41813b64d1c008337ca/spec.json"
    spec = strict_json_bytes(original_spec.read_bytes())
    # Same actual original patients/recipe/risk bytes, but a fresh 24-month
    # consumer argument projected by the existing original child compiler.
    # This does NOT claim the 24-month funnel has selected these four tasks.
    spec.pop("selection_horizon_months")
    spec.pop("trial_scoring")
    spec.update(kernel._r_prediction_child_spec({**original["spec"],
        "native_search_root": str(batch / "native"), "native_search_replay": True,
        "native_search_numbers": True}))
    spec["horizons"] = original["spec"]["monthly_fit_horizons"]
    consumer = tmp_path / "consumer-input.json"
    consumer.write_bytes(canonical_json_bytes(original))
    spec["full0_rsf24_numbers_pair"] = {
        "producer_input": {"path": str(batch / "input.json"), "sha256": sha256_file(batch / "input.json"),
            "size_bytes": (batch / "input.json").stat().st_size},
        "consumer_input": {"path": str(consumer), "sha256": sha256_file(consumer),
            "size_bytes": consumer.stat().st_size},
        "retained_source_bundle": str(source),
        "producer_source_identity": "8cce1d0042a87e627324246016a64224db3b23ae818e62eb09840b9d7156eaa1",
        "executor_source_identity": sha256_bytes(canonical_json_bytes(f4._f45_source_member_sha256()))}
    work = tmp_path / "read"
    work.mkdir()
    spec_path, output = work / "spec.json", work / "output.json"
    spec["output_path"] = str(output)
    return spec, spec_path, output, original_spec, consumer


@pytest.mark.parametrize("mutation", [None, "producer_seed", "recipe_input", "source_identity"])
def test_real_rsf24_original_leaf_to_risk_consumer_before_ibs(real_rsf24_leaf, mutation):
    spec, spec_path, output, original_spec, consumer = real_rsf24_leaf
    if mutation == "producer_seed":
        changed = strict_json_bytes(original_spec.read_bytes())
        changed["producer_tasks"][0]["seed"] += 1
        original_spec.write_bytes(canonical_json_bytes(changed))
    elif mutation == "recipe_input":
        changed = strict_json_bytes(consumer.read_bytes())
        changed["spec"]["selector_from_dependency"]["outer_recipe_sha256"] = "0" * 64
        consumer.write_bytes(canonical_json_bytes(changed))
        spec["full0_rsf24_numbers_pair"]["consumer_input"].update(
            sha256=sha256_file(consumer), size_bytes=consumer.stat().st_size)
    elif mutation == "source_identity":
        spec["full0_rsf24_numbers_pair"]["producer_source_identity"] = "0" * 64
    spec_path.write_bytes(canonical_json_bytes(spec))
    if mutation is not None:
        with pytest.raises(ContractError, match="F5_FULL0_RSF24_NUMBERS_(?:INPUT_PAIR|SOURCE)_INVALID"):
            f4._run_full_pipeline_r_search_batch(spec_path, output, Path(f4.__file__).parent, dict(os.environ))
        assert not output.exists()
        assert not list(output.parent.glob("risk-*.bin"))
        return
    value = f4._run_full_pipeline_r_search_batch(spec_path, output, Path(f4.__file__).parent, dict(os.environ))
    assert value["status"] == "PASS" and value["task_count"] == 4
    rows = kernel._consume_r_prediction(value, spec, spec["registered_partitions"],
        spec["producer_tasks"], output.parent, "NONE", None, cleanup=False)
    assert len(rows) == 4
    # Stop here: no original Q chooser, IBS integration, native R replay or FIT.
