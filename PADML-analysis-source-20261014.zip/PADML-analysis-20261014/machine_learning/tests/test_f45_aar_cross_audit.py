"""UNFITTED focused whole-reader/source-report gate tests; prior stages are explicit seams."""
import copy
from pathlib import Path
import pytest
from padml import f4, f5, f5_sensitivity as a, nested_loco as n, runtime
from padml.bundle import ContractError, canonical_json_bytes as encode, read_safe_zip, write_deterministic_zip
from test_f45_final_aar_reuse import fixture
from test_f45_final_primary_reuse import pin, seal

class ReachedPostSourceAdmission(Exception):
    pass


@pytest.mark.parametrize("mode,cache_status,available", [
    ("hit", "ADVISED", 4*1024**3), ("miss", "UNKNOWN", 4*1024**3),
    ("hit", "UNKNOWN", 1024**3), ("miss", "ADVISED", 1024**3),
    ("tamper", "ADVISED", 4*1024**3)])
def test_final_reuse_releases_hashed_artifacts_before_consumers(tmp_path, monkeypatch, mode, cache_status, available):
    # Original unfitted whole-producer fixture and reuse reader; no model work.
    from padml import f4_compact
    original_readback = runtime._readback_ordered
    prepared, root, jobs, calls, _, _ = fixture(tmp_path, monkeypatch,
        n.A12_DIRECT_AAR, changed=20 if mode == "miss" else 0)
    monkeypatch.setattr(runtime, "_readback_ordered", original_readback)
    candidate, = prepared["completed_aar_units"]
    owner = Path(candidate["root"])
    artifacts = [owner / name for name in candidate["receipt"]["artifacts"]]
    originals = {path: path.read_bytes() for path in artifacts}
    if mode == "tamper":
        path = owner / "result.zip"
        damaged = originals[path]
        path.write_bytes(damaged[:-1] + bytes([damaged[-1] ^ 1]))
    events, streams, admissions = [], [], []
    original_hash, original_open = a.sha256_file, Path.open
    original_admission = runtime.resource_admission
    def opened(path, *args, **kwargs):
        stream = original_open(path, *args, **kwargs)
        if path in artifacts and args == ("rb",):
            streams.append(stream)
        return stream
    def hashed(path):
        digest = original_hash(path)
        if path in artifacts:
            events.append("hash:" + path.name)
        return digest
    def release(files, *, owner, report_root, released_references=None):
        if owner == "READBACK:_a12_final_reuse_job":
            assert files == [] and report_root == root
            events.append("readback-release")
            return {"cumulative": {"status": cache_status}}
        assert events == ["hash:" + path.name for path in artifacts]
        assert len(streams) == len(artifacts) and all(stream.closed for stream in streams)
        assert files == artifacts and report_root == root
        assert owner == "AAR_FINAL_REUSE_HASHED_INPUTS"
        assert released_references == ["closed_a12_final_reuse_artifact_hash_streams"]
        events.append("release")
        return {"cumulative": {"status": cache_status}}
    def observe(location):
        memory = available if "release" in events else 1024**3
        events.append("observe")
        return dict(effective_cpus=32, available_memory_bytes=memory,
            scratch_available_bytes=128*1024**3, scratch_root=str(location))
    def admit(policy, observation, *, legal_tasks):
        assert policy["memory_bytes_per_worker"] == 2*1024**3
        assert policy["scratch_reserve_bytes"] == 0
        admissions.append(legal_tasks)
        events.append("admit")
        return original_admission(policy, observation, legal_tasks=legal_tasks)
    def reached(worker, tasks, **kwargs):
        if worker is a._a12_final_reuse_job:
            assert len(tasks) == 20
            events.append("reuse-workers")
            return [worker(task) for task in tasks]
        assert worker is f4_compact._q_coordinate_read_job and len(tasks) == 5202
        events.append("worker-boundary")
        raise ReachedPostSourceAdmission()
    monkeypatch.setattr(Path, "open", opened)
    monkeypatch.setattr(a, "sha256_file", hashed)
    monkeypatch.setattr(runtime, "release_f45_cumulative_files", release)
    monkeypatch.setattr(runtime, "observe_execution_resources", observe)
    monkeypatch.setattr(runtime, "resource_admission", admit)
    monkeypatch.setattr(runtime, "_bounded_ordered_spawn", reached)
    def consume():
        reused = a._prepare_a12_final_reuse(prepared, root, jobs)
        if mode == "miss":
            assert reused == {} and not list((root / "fits").iterdir())
            # Reach the same original Q readback admission, stopping before workers.
            runtime._readback_ordered(f4_compact._q_coordinate_read_job, [{}]*5202,
                policy={**prepared["source"]["resource_policy"], "memory_reserve_bytes": 1024**3},
                retained_bytes=132002656, root=root)
        else:
            assert set(reused) == {job["name"] for job in jobs}
    if mode == "tamper":
        with pytest.raises(ContractError, match="F45_AAR_FINAL_REUSE_SOURCE_DRIFT"):
            consume()
        assert "release" not in events and not admissions
    elif available < 2*1024**3:
        with pytest.raises(ContractError, match="RESOURCE_ADMISSION_ZERO"):
            consume()
    elif mode == "miss":
        with pytest.raises(ReachedPostSourceAdmission):
            consume()
    else:
        consume()
    if mode != "tamper":
        expected = ["hash:" + path.name for path in artifacts] + ["release", "observe", "observe", "admit"]
        if available >= 2*1024**3:
            expected += ["reuse-workers", "readback-release"]
            if mode == "miss":
                expected += ["observe", "admit", "worker-boundary"]
        assert events == expected
        assert admissions == ([20, 5202] if mode == "miss" and available >= 2*1024**3 else [20])
        assert {path: path.read_bytes() for path in artifacts} == originals
    assert calls == dict(fit=0, replay=0, audit=0, pools=[])


@pytest.mark.parametrize("cache_status,available", [
    ("ADVISED", 4*1024**3), ("UNKNOWN", 4*1024**3), ("ADVISED", 2147540992)])
def test_projected_input_releases_extraction_before_readback(tmp_path, monkeypatch, cache_status, available):
    # Unfitted upstream science seams; the original ZIP extraction, readback
    # resource admission and 155-job shape run, then stop before any worker.
    from padml import f2_kernel as k
    policy = dict(configured_worker_ceiling=runtime.CPU_MINUS_8,
        memory_bytes_per_worker=2*1024**3, memory_reserve_bytes=1024**3,
        scratch_bytes_per_worker=2*1024**3, scratch_reserve_bytes=0,
        transfer_archive_worker_ceiling=24)
    train, heldout = list("abcde"), ["heldout"]
    definitions = []
    def definition(kind, repeat, fold, fit, evaluation):
        name = kind if kind == "OUTER" else f"{kind}_R{repeat}_K{fold}"
        return dict(kind=kind, repeat=repeat, inner_fold=fold, partition_id=name,
            fit_ids=fit, evaluation_ids=evaluation, application_ids=fit+evaluation,
            analysis=name+"_ANALYSIS", application=name+"_APPLICATION",
            **({"consumer_set": ["GBM_COX", "XGBOOST_COX", "COXTIME_SET_A"]} if kind == "STOP" else {}))
    definitions.append(definition("OUTER", 0, 0, train, heldout))
    for repeat in range(1, 4):
        for fold, patient in enumerate(train, 1):
            definitions.append(definition("INNER", repeat, fold,
                [p for p in train if p != patient], [patient]))
    for row in list(definitions[1:]):
        definitions.append(definition("STOP", row["repeat"], row["inner_fold"],
            row["fit_ids"][:-1], row["fit_ids"][-1:]))
    views = [dict(estimand=branch, view_id=row[role], member=f"mice-inputs/{branch}/{row[role]}.zip")
        for branch in (n.A12_TOTAL_AAR, n.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT)
        for row in definitions for role in ("analysis", "application")]
    payloads = {"training-response.csv": b"UNFITTED_RESPONSE"}
    payloads.update({f"direct/{row['partition_id']}/imp{imp:02d}.csv": b"UNFITTED_DIRECT"
        for row in definitions for imp in range(1, 21)})
    payloads.update({row["member"]: b"UNFITTED_MICE_VIEW" for row in views})
    lock = dict(selected_family="GBM_COX", selected_parents=["Age", "AST_ALT"],
        common_set_design_df=2, epv_resolution={"UNFITTED": True})
    value = seal(dict(kind="PADML_F5_A12_PROJECTED_OUTER_INPUTS_V1", outer_fold=3, family="GBM_COX",
        primary_source={"primary_development_lock": lock}, primary_input_sha256="a"*64,
        primary_archive_sha256="b"*64, fixed_selected_parents=["Age"], fixed_common_set_design_df=1,
        outer_training_event_count=300, definitions=definitions,
        direct_partitions={row["partition_id"]: {"UNFITTED": True} for row in definitions},
        original_recipes=[], mice_inputs=views, resource_policy=policy,
        members={name: {"sha256": a.sha256_bytes(raw), "size_bytes": len(raw)} for name, raw in payloads.items()}))
    source, target = tmp_path / "projected.zip", tmp_path / "expanded"
    raw = encode(value)
    write_deterministic_zip(source, {"a12-inputs.json": raw, **payloads})
    original_source = source.read_bytes()
    context = dict(outer_fold=3, training_ids=train, heldout_ids=heldout, training_event_count=300)
    monkeypatch.setattr(a, "_a12_nested_mice_source", lambda *args, **kwargs: context)
    monkeypatch.setattr(k, "_validate_transform_recipe_set", lambda *args, **kwargs: [])
    monkeypatch.setattr(k, "_recipe_by_partition", lambda *args: {})
    monkeypatch.setattr(k, "_expected_family_parent_column_map", lambda parents, *args: [{"columns": [p]} for p in parents])
    monkeypatch.setattr(n, "validate_epv_resolution", lambda value: {"minimum": 15})
    monkeypatch.setattr(n, "validate_training_context", lambda *args: None)
    monkeypatch.setattr(a, "_response_rows", lambda response: (["Patient_ID"], {}))
    events = []
    extract, admit = a.extract_safe_zip, runtime.resource_admission
    def extracted(*args, **kwargs):
        result = extract(*args, **kwargs)
        events.append("extraction-closed")
        return result
    def release(files, *, owner, report_root, released_references):
        assert events == ["extraction-closed"] and files == [source]
        assert owner == "AAR_PROJECTED_INPUTS_EXTRACTED" and report_root == target
        assert released_references == ["closed_a12_projected_input_extraction_streams"]
        assert (target / "training-response.csv").read_bytes() == payloads["training-response.csv"]
        events.append("release")
        return {"cumulative": {"status": cache_status}}
    def observe(root):
        memory = available if "release" in events else 2147540992
        events.append("observe")
        return dict(effective_cpus=32, available_memory_bytes=memory,
            scratch_available_bytes=16*1024**3, scratch_root=str(root))
    def admitted(effective, observation, *, legal_tasks):
        assert legal_tasks == 155 and effective["memory_bytes_per_worker"] == 2*1024**3
        assert effective["memory_reserve_bytes"] == policy["memory_reserve_bytes"] + 32*(len(raw)+len(payloads["training-response.csv"]))
        assert effective["scratch_reserve_bytes"] == 0
        events.append("admit")
        return admit(effective, observation, legal_tasks=legal_tasks)
    def reached(worker, jobs, **kwargs):
        assert worker is a._a12_projected_input_read_job and len(jobs) == 155
        events.append("worker-boundary")
        raise ReachedPostSourceAdmission()
    monkeypatch.setattr(a, "extract_safe_zip", extracted)
    monkeypatch.setattr(runtime, "release_f45_cumulative_files", release)
    monkeypatch.setattr(runtime, "observe_execution_resources", observe)
    monkeypatch.setattr(runtime, "resource_admission", admitted)
    monkeypatch.setattr(runtime, "_bounded_ordered_spawn", reached)
    if available < 4*1024**3:
        with pytest.raises(ContractError, match="RESOURCE_ADMISSION_ZERO"):
            a._load_a12_projected_outer_inputs(source, target)
    else:
        with pytest.raises(ReachedPostSourceAdmission):
            a._load_a12_projected_outer_inputs(source, target)
    assert events == ["extraction-closed", "release", "observe", "admit"] + (
        ["worker-boundary"] if available >= 4*1024**3 else [])
    assert source.read_bytes() == original_source


@pytest.mark.parametrize("cache_status,available", [
    ("ADVISED", 4 * 1024**3), ("UNKNOWN", 4 * 1024**3), ("ADVISED", 2258739200)])
def test_outer_reader_hash_release_fresh_admission(tmp_path, monkeypatch, cache_status, available):
    # Minimal unfitted headers exercise the actual reader entry. Stop before
    # extraction/scientific consumption; do not simulate a completed model.
    policy = dict(configured_worker_ceiling=runtime.CPU_MINUS_8,
        memory_bytes_per_worker=2*1024**3, memory_reserve_bytes=1024**3,
        scratch_bytes_per_worker=2*1024**3, scratch_reserve_bytes=0,
        transfer_archive_worker_ceiling=24)
    source = seal(dict(family="COX_PH", resource_policy=policy))
    meta = seal(dict(kind="PADML_F5_A12_OUTER_NATIVE_V2", source=source,
        family="COX_PH", outer_fold=1, predictions={}, members={}, native_members={}))
    projected, archive = tmp_path / "input.zip", tmp_path / "result.zip"
    write_deterministic_zip(projected, {"a12-inputs.json": encode(source)})
    write_deterministic_zip(archive, {"a12-outer.json": encode(meta)})
    originals = {p: p.read_bytes() for p in (archive, projected)}
    events = []
    original_sha, original_admission = a.sha256_file, runtime.resource_admission

    def hashed(path):
        result = original_sha(path)
        events.append("hash:" + path.name)
        return result

    def release(files, *, owner, report_root, released_references):
        assert files == [archive, projected]
        assert owner == "AAR_OUTER_REPLAY_HASHED_INPUTS"
        assert report_root.parent == tmp_path
        assert released_references == ["closed_a12_archive_hash_streams"]
        assert events == ["hash:result.zip", "hash:input.zip"]
        events.append("release")
        return {"cumulative": {"status": cache_status}}

    def observe(root):
        assert events[-1] == "release"
        events.append("observe")
        return dict(effective_cpus=32, available_memory_bytes=available,
            scratch_available_bytes=16*1024**3, scratch_root=str(root))

    def admit(policy, observation, *, legal_tasks):
        assert events[-1] == "observe" and legal_tasks == 1
        assert policy["memory_reserve_bytes"] == policy["memory_bytes_per_worker"] == 2*1024**3
        events.append("admit")
        return original_admission(policy, observation, legal_tasks=legal_tasks)

    def reached(*args, **kwargs):
        events.append("consumer-entry")
        raise ReachedPostSourceAdmission()

    monkeypatch.setattr(a, "sha256_file", hashed)
    monkeypatch.setattr(runtime, "release_f45_cumulative_files", release)
    monkeypatch.setattr(runtime, "observe_execution_resources", observe)
    monkeypatch.setattr(runtime, "resource_admission", admit)
    monkeypatch.setattr(runtime, "observe_step_memory", lambda: {"started_ns": 1})
    from padml import bundle
    monkeypatch.setattr(bundle, "_validated_zip_infos", reached)
    if available < 4*1024**3:
        with pytest.raises(ContractError, match="RESOURCE_ADMISSION_ZERO"):
            a._load_a12_outer_archive(archive, input_bundle=projected)
    else:
        with pytest.raises(ReachedPostSourceAdmission):
            a._load_a12_outer_archive(archive, input_bundle=projected)
    assert events == ["hash:result.zip", "hash:input.zip", "release", "observe", "admit"] + (
        ["consumer-entry"] if available >= 4*1024**3 else [])
    assert all(p.read_bytes() == raw for p, raw in originals.items())


@pytest.mark.parametrize("cache_status,available", [
    ("ADVISED", 4*1024**3), ("UNKNOWN", 4*1024**3), ("ADVISED", 2147532800)])
def test_outer_reader_releases_extraction_before_materialization(tmp_path, monkeypatch, cache_status, available):
    policy = dict(configured_worker_ceiling=runtime.CPU_MINUS_8,
        memory_bytes_per_worker=2*1024**3, memory_reserve_bytes=1024**3,
        scratch_bytes_per_worker=2*1024**3, scratch_reserve_bytes=0,
        transfer_archive_worker_ceiling=24)
    source = seal(dict(kind="PADML_F5_A12_PROJECTED_OUTER_INPUTS_V1", family="COX_PH", resource_policy=policy))
    projected, archive, numerical = (tmp_path / name for name in ("input.zip", "result.zip", "unfitted.zip"))
    marker = encode({"UNFITTED_MATERIALIZATION_BOUNDARY": True})
    write_deterministic_zip(numerical, {"a12-inputs.json": marker})
    numerical_raw = numerical.read_bytes()
    meta = seal(dict(kind="PADML_F5_A12_OUTER_NATIVE_V2", source=source,
        family="COX_PH", outer_fold=1, predictions={}, native_members={},
        members={"inputs.zip": {"sha256": a.sha256_bytes(numerical_raw), "size_bytes": len(numerical_raw)}}))
    write_deterministic_zip(projected, {"a12-inputs.json": encode(source)})
    write_deterministic_zip(archive, {"a12-outer.json": encode(meta), "inputs.zip": numerical_raw})
    originals = {p: p.read_bytes() for p in (archive, projected, numerical)}
    events, releases = [], []
    extract, decode = a.extract_safe_zip, a.strict_json_bytes

    def extracted(*args, **kwargs):
        result = extract(*args, **kwargs)
        events.append("extraction-closed")
        return result

    def release(files, *, owner, report_root, released_references):
        if owner == "AAR_OUTER_REPLAY_EXTRACTED_INPUTS":
            assert events[-1] == "extraction-closed"
            assert files == [archive, projected, report_root / "archive/inputs.zip"]
            assert files[-1].read_bytes() == numerical_raw
            assert released_references == ["closed_a12_outer_archive_extraction_streams"]
        releases.append(owner)
        events.append(owner)
        return {"cumulative": {"status": cache_status}}

    def observe(root):
        events.append("observe:" + str(len(releases)))
        return dict(effective_cpus=32, available_memory_bytes=available if len(releases) == 2 else 20*1024**3,
            scratch_available_bytes=16*1024**3, scratch_root=str(root))

    def decoded(raw):
        if raw == marker:
            events.append("post-materialization-admission")
            raise ReachedPostSourceAdmission()
        return decode(raw)

    monkeypatch.setattr(a, "extract_safe_zip", extracted)
    monkeypatch.setattr(a, "strict_json_bytes", decoded)
    monkeypatch.setattr(runtime, "release_f45_cumulative_files", release)
    monkeypatch.setattr(runtime, "observe_execution_resources", observe)
    if available < 4*1024**3:
        with pytest.raises(ContractError, match="RESOURCE_ADMISSION_ZERO"):
            a._load_a12_outer_archive(archive, input_bundle=projected)
    else:
        with pytest.raises(ReachedPostSourceAdmission):
            a._load_a12_outer_archive(archive, input_bundle=projected)
    assert releases == ["AAR_OUTER_REPLAY_HASHED_INPUTS", "AAR_OUTER_REPLAY_EXTRACTED_INPUTS"]
    assert events[-2:] == (["observe:2", "post-materialization-admission"] if available >= 4*1024**3
        else ["AAR_OUTER_REPLAY_EXTRACTED_INPUTS", "observe:2"])
    assert all(p.read_bytes() == raw for p, raw in originals.items())


def shifted_source(monkeypatch, original_members):
    current = {**original_members, 'padml/f5_sensitivity.py':'1'*64}
    identities = {n._sha(original_members): original_members, n._sha(current): current}
    def qualify(identity):
        if identity not in identities:
            raise ContractError('UNFITTED_UNKNOWN_SOURCE')
        return identities[identity]
    monkeypatch.setattr(f4,'_f45_source_member_sha256',lambda:current)
    monkeypatch.setattr(f4,'_f45_same_run_source',qualify)
    return n._sha(current)


def test_whole_reader_exact_executor_admission(tmp_path, monkeypatch):
    # The sole writer may update protocol/source package bytes concurrently.
    # Keep this imported test process's simulated source identities stable.
    stable_members = f4._f45_source_member_sha256()
    monkeypatch.setattr(f4, '_f45_source_member_sha256', lambda: stable_members)
    # This original H6 producer keeps its own science after the H36 amendment.
    read_canonical = n._read_canonical
    monkeypatch.setattr(n, '_read_canonical', lambda path, reason: n.science_decision_template(6)
        if path == Path(__file__).parents[1] / 'science-decision.json' else read_canonical(path, reason))
    prepared,_,_,calls,old_root,_ = fixture(tmp_path,monkeypatch,n.A12_DIRECT_AAR)
    candidate, = prepared['completed_aar_units']
    owner = Path(candidate['root'])
    payload = read_safe_zip(owner/'result.zip')
    meta = f5.strict_json_bytes(payload.pop('a12-outer.json'))
    projected = tmp_path/'old-projected.zip'
    write_deterministic_zip(projected,{'a12-inputs.json':encode(meta['source'])})
    payload['inputs.zip'] = projected.read_bytes()
    executor = f5.strict_json_bytes(payload['execution.json'])
    executor['resource_reservation'] = {'retained_bytes_per_component':16*1024**2,
                                      'execution_worker_memory_bytes':2*1024**3}
    payload['execution.json'] = encode(executor)
    meta['members'] = {name:{'sha256':n.sha256_bytes(raw),'size_bytes':len(raw)} for name,raw in payload.items()}
    meta = seal(meta)
    target = tmp_path/'original-whole.zip'
    write_deterministic_zip(target,{'a12-outer.json':encode(meta),**payload})
    whole = copy.deepcopy(candidate['receipt'])
    whole['artifacts']['result.zip'] = pin(target)
    proof = seal({'kind':'PADML_F45_AAR_FINAL_REUSE_SOURCE_V1','whole_unit':whole,
                  'result_metadata':meta,'execution':executor})
    assert a._a12_final_reuse_source(proof,prepared['source'],f5._f45_score_reuse_authorities()) == owner.name
    # A repaired whole-unit finisher retains the old numerical producer and
    # one pinned original consumer report. Both executors need run authority.
    resumed = copy.deepcopy(proof)
    resumed['whole_unit']['run_identity'] = 'f'*64
    resumed['whole_unit']['artifacts']['padml-a12-outer-replay-original/execution.json'] = {
        'sha256':'b'*64,'size_bytes':34387159}
    resumed = seal(resumed)
    executors, sources = f5._f45_score_reuse_authorities()
    completed_authorities = ({**executors, 'f'*64:'c'*64}, {**sources, 'c'*64:stable_members})
    assert a._a12_final_reuse_source(resumed,prepared['source'],completed_authorities) == owner.name
    with pytest.raises(ContractError, match='FINAL_REUSE_SOURCE_INVALID'):
        a._a12_final_reuse_source(resumed,prepared['source'],({'f'*64:'c'*64},completed_authorities[1]))
    actual_old = {'source':meta['source'],'family':'COX_PH','outer_fold':1,'input_expansion_resources':{}}
    jobs = []
    for name in sorted(meta['native_members']):
        entries = read_safe_zip(payload[name])
        entries = {key:entries[key] for key in ('task.json','recipe.json','fit-covariates.csv',
                                               'fit-response.csv','prediction-covariates.csv')}
        jobs.append({'name':Path(name).stem,'entries':entries,'consumer_source':meta['source']})
    # These are pre-final MICE/selector seams. The real whole ZIP extraction,
    # metadata/source equality and final source gate remain untouched.
    monkeypatch.setattr(a,'materialize_a12_outer_inputs',lambda *args,**kwargs:actual_old)
    monkeypatch.setattr(a,'_a12_projected_development_inputs',lambda prepared,*args,**kwargs:prepared)
    monkeypatch.setattr(a,'_a12_outer_searches',lambda *args,**kwargs:{})
    monkeypatch.setattr(a,'_a12_outer_model_jobs',lambda *args,**kwargs:jobs)
    monkeypatch.setattr(a,'_a12_outer_retained_members',lambda root,*args,**kwargs:{
        name:root/name for name in meta['members'] if not kwargs.get('before_final')
        or name!='execution.json' and not name.startswith('fits/')})
    monkeypatch.setattr(a,'_a12_final_resource_reservation',lambda *args,**kwargs:
        (_ for _ in ()).throw(ReachedPostSourceAdmission()))
    with pytest.raises(ReachedPostSourceAdmission):
        a._load_a12_outer_archive(target,input_bundle=projected,replay_evidence=tmp_path/'same-source')
    before = pin(target)
    original_members = f4._f45_source_member_sha256()
    current_identity = shifted_source(monkeypatch,original_members)
    assert n._sha(f4._f45_same_run_source(executor['executor_source_identity'])) == executor['executor_source_identity']
    assert a._a12_final_reuse_source(proof,prepared['source'],f5._f45_score_reuse_authorities()) == owner.name
    error = None
    try:
        a._load_a12_outer_archive(target,input_bundle=projected,replay_evidence=tmp_path/'new-source')
    except ContractError as caught:
        error = str(caught)
    except ReachedPostSourceAdmission:
        pass
    assert pin(target) == before and calls == dict(fit=0,replay=0,audit=0,pools=[])
    (tmp_path/'whole-gate-outcome.json').write_bytes(encode({'qualified_old_executor':executor['executor_source_identity'],
        'current_executor':current_identity,'error':error,'native_calls':calls,'original_archive_unchanged':True}))
    assert error is None, error

    # A source dictionary entry authenticates input producer bytes, not a final executor.
    authorities = f5._f45_score_reuse_authorities()
    original_identity = executor['executor_source_identity']
    assert original_identity in authorities[0].values() and original_identity in authorities[1]
    with monkeypatch.context() as rejected:
        rejected.setattr(f5, '_f45_score_reuse_authorities', lambda: ({}, authorities[1]))
        with pytest.raises(ContractError, match='F5_A12_RETAINED_FINAL_EXECUTION_RECEIPT_REQUIRED') as missing_admission:
            a._load_a12_outer_archive(target, input_bundle=projected, replay_evidence=tmp_path/'producer-only')
    # A missing executor field must not inherit either the input producer or reader identity.
    missing_executor = {key:value for key,value in executor.items() if key!='executor_source_identity'}
    missing_payload = {**payload, 'execution.json':encode(missing_executor)}
    missing_meta = copy.deepcopy(meta)
    missing_meta['members']['execution.json'] = {'sha256':n.sha256_bytes(missing_payload['execution.json']),
        'size_bytes':len(missing_payload['execution.json'])}
    missing_meta = seal(missing_meta)
    missing_archive = tmp_path/'missing-executor-whole.zip'
    write_deterministic_zip(missing_archive, {'a12-outer.json':encode(missing_meta), **missing_payload})
    with pytest.raises(ContractError, match='F5_A12_RETAINED_FINAL_EXECUTION_RECEIPT_REQUIRED') as missing_field:
        a._load_a12_outer_archive(missing_archive, input_bundle=projected, replay_evidence=tmp_path/'missing-executor')
    assert str(missing_admission.value) == str(missing_field.value) == 'F5_A12_RETAINED_FINAL_EXECUTION_RECEIPT_REQUIRED'
    assert pin(target)==before and calls==dict(fit=0,replay=0,audit=0,pools=[])
    (tmp_path/'whole-gate-outcome.json').write_bytes(encode({
        'qualified_old_executor':original_identity,'current_executor':current_identity,
        'same_source':'PASS','qualified_previous_executor':'PASS',
        'producer_in_sources_only':str(missing_admission.value),
        'missing_executor_field':str(missing_field.value),
        'native_calls':calls,'original_archive_unchanged':True}))


def independent_unfitted_producer(candidate, tmp_path, horizon):
    old = Path(candidate['root'])
    carried = read_safe_zip(old / 'result.zip')
    meta = f5.strict_json_bytes(carried.pop('a12-outer.json'))
    source = copy.deepcopy(meta['source'])
    lock = source['primary_source']['primary_development_lock']
    lock['selection_horizon_months'] = horizon
    lock['science_decision_binding']['selection_horizon_months'] = horizon
    lock = seal(lock)
    source['primary_source']['primary_development_lock'] = lock
    source = seal(source)
    n.validate_development_lock(lock, context=source['primary_source']['primary_training_context'],
                               science_decision=source['primary_source']['science_decision'])
    owner = tmp_path / f'AAR-H{horizon:02d}-O1'
    owner.mkdir()
    for member in list(carried):
        if member.startswith('fits/') and member.endswith('.zip'):
            objects = read_safe_zip(carried[member])
            task = f5.strict_json_bytes(objects['task.json'])
            binding = task['nested_aar_final_source']
            binding['selection_horizon_months'] = horizon
            binding['primary_development_lock_sha256'] = lock['identity_sha256']
            if 'primary_development_lock_sha256' in binding['epv_resolution']:
                binding['epv_resolution']['primary_development_lock_sha256'] = lock['identity_sha256']
            objects['task.json'] = encode(task)
            path = owner / member
            path.parent.mkdir(exist_ok=True)
            write_deterministic_zip(path, objects)
            carried[member] = path.read_bytes()
            number_member = member.removesuffix('.zip') + '.numbers.json'
            numbers = f5.strict_json_bytes(carried[number_member])
            numbers['input_members']['task.json'] = {'sha256':n.sha256_bytes(objects['task.json']),
                                                     'size_bytes':len(objects['task.json'])}
            numbers['native_archive'] = pin(path)
            numbers['native_expanded_bytes'] = sum(map(len,objects.values()))
            carried[number_member] = encode(numbers)
            meta['native_members'][member] = pin(path)
    meta['source'] = source
    meta['members'] = {name:{'sha256':n.sha256_bytes(raw),'size_bytes':len(raw)} for name,raw in carried.items()}
    meta = seal(meta)
    write_deterministic_zip(owner/'result.zip', {'a12-outer.json':encode(meta), **carried})
    for name in ('input.zip','input.compile.json'):
        (owner/name).write_bytes((old/name).read_bytes())
    receipt = {**candidate['receipt'], 'unit_id':owner.name, 'selection_horizon_months':horizon,
        'artifacts':{name:pin(owner/name) for name in ('input.zip','input.compile.json','result.zip')}}
    (owner/'unit.json').write_bytes(encode(receipt))
    return {'root':str(owner),'receipt':receipt}


def test_pending_original_survives_new_earlier_candidate(tmp_path, monkeypatch):
    prepared,root,jobs,calls,_,_ = fixture(tmp_path, monkeypatch, n.A12_DIRECT_AAR)
    earlier, = prepared['completed_aar_units']
    original = independent_unfitted_producer(earlier,tmp_path,24)
    prepared['completed_aar_units'] = [original]
    with monkeypatch.context() as scoped:
        scoped.setattr(f5,'_f45_retain_final_object',lambda *args: (_ for _ in ()).throw(OSError('UNFITTED copy interrupted')))
        with pytest.raises(OSError, match='copy interrupted'):
            a._prepare_a12_final_reuse(prepared,root,jobs)
    marker, = (root/'fits').glob('*.reuse.json')
    original_marker = marker.read_bytes()
    assert 'AAR-H24-O1' in f5.strict_json_bytes(original_marker)['source']['path']
    # worker._f45_aar_reuse_candidates sorts completed candidates by horizon.
    # H06 finishes while this H12 consumer is interrupted; H24 is still valid.
    prepared['completed_aar_units'] = [earlier,original]
    error = None
    try:
        result = a._prepare_a12_final_reuse(prepared,root,jobs)
    except ContractError as caught:
        error = str(caught)
        result = None
    assert marker.read_bytes() == original_marker
    assert calls == dict(fit=0,replay=0,audit=0,pools=[])
    (tmp_path/'pending-outcome.json').write_bytes(encode({'error':error,'reused_count':None if result is None else len(result),
        'pending_original':'AAR-H24-O1','new_preceding_candidate':'AAR-H06-O1','clinical_fits':0}))
    assert error is None and len(result)==20, error
