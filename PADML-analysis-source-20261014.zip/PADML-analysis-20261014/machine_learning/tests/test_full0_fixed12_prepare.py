"""All three fixed families use the same zero-fit full0 compiler."""
import pytest

from padml import nested_loco as nested
import test_full0_cox12_prepare as original
from test_nested_full_development import full_inputs, unfitted_selector_consumers, _unfitted_confirmed_decision


@pytest.mark.parametrize("family", ["COX_PH", "ELASTIC_NET_COX", "FPM_TVC_SET_A"])
def test_fixed12_original_preparation(full_inputs, unfitted_selector_consumers, tmp_path, monkeypatch, family):
    science = _unfitted_confirmed_decision(fresh_seven=True, fixed_bootstrap=True)
    science = nested._sealed({**{key: value for key, value in science.items() if key != "identity_sha256"},
        "twelve_month_development": nested._twelve_month_development_contract()})
    monkeypatch.setattr(original, "_science", lambda: science)
    monkeypatch.setenv("PADML_COX12_TEST_PRIMARY", str(tmp_path / "UNFITTED-source.zip"))
    original.test_original_compiler_prepares_300_cox12_inputs_without_q_or_fitting(
        full_inputs, unfitted_selector_consumers, tmp_path, monkeypatch, family=family, verify_replay=True)


@pytest.mark.parametrize("family", ["COX_PH", "ELASTIC_NET_COX", "FPM_TVC_SET_A"])
@pytest.mark.parametrize("release_status", ["OBSERVED", "UNKNOWN", "EXCEPTION"])
@pytest.mark.parametrize("admission_failure", [False, True])
def test_fixed12_entry_preserves_original_roots(tmp_path, monkeypatch, family, release_status, admission_failure):
    science = _unfitted_confirmed_decision(fresh_seven=True, fixed_bootstrap=True)
    science = nested._sealed({**{key: value for key, value in science.items() if key != "identity_sha256"},
        "twelve_month_development": nested._twelve_month_development_contract()})
    monkeypatch.setattr(original, "_science", lambda: science)
    original.test_entry_preserves_original_lineage_rsf_root_and_owns_its_release_report(
        tmp_path, monkeypatch, family=family, release_status=release_status, admission_failure=admission_failure)


@pytest.mark.parametrize("family", ["COX_PH", "ELASTIC_NET_COX", "FPM_TVC_SET_A"])
@pytest.mark.parametrize("change", [{"prepare_only": False}, {"resume": True}, {"replay": True}])
def test_fixed12_entry_does_not_grant_fits_or_resume(monkeypatch, family, change):
    original.test_entry_rejects_scientific_execution_and_q_before_reading_inputs(
        {"family": family, **change}, monkeypatch)
