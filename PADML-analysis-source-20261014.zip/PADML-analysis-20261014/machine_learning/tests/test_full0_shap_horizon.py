"""Synthetic retained SHAP values: no model, kernelshap or RNG execution."""
import pytest

from padml import f5, nested_loco as nested
from padml.bundle import ContractError
from test_f5 import paired_predictions, final_shap_components
from test_nested_full_development import (full_inputs, unfitted_selector_consumers,
    unfitted_full_score_sources, test_full0_final_compiler_locks_only_winner_and_replays_twenty_unfitted_objects as _final_chain)


def test_twelve_month_original_final_compiler_m20_application_and_shap(
        unfitted_full_score_sources, tmp_path, monkeypatch):
    _final_chain(unfitted_full_score_sources, tmp_path, monkeypatch, "COX_PH", selection_horizon=12)


@pytest.mark.parametrize("horizon", [12, 24])
def test_original_shap_consumer_marks_own_line_without_changing_risk_values(horizon):
    records, receipts, _, decision, plan, centers = paired_predictions()
    pooled = f5.pool_predictions(records, receipts, decision, plan, centers)
    components = final_shap_components(pooled)
    original = f5.aggregate_final_shap(components, pooled)
    # Isolate the SHAP handoff; the producer/lock gate is tested separately below.
    current = {**pooled, "kind": "PADML_F5_FULL0_APPARENT_M20_SUMMARY", "selection_horizon_months": horizon}
    result = f5.aggregate_final_shap(components, current)
    assert result["primary_horizon_months"] == horizon
    assert [row["time_months"] for row in result["global_importance"] if row["primary"]] == [horizon]
    assert result["patient_contributions"] == original["patient_contributions"]
    assert [row["importance"] for row in result["global_importance"]] == [
        row["importance"] for row in original["global_importance"]]


@pytest.mark.parametrize("horizon", [True, 6, "12"])
def test_shap_rejects_invalid_horizon_before_consumption(horizon):
    with pytest.raises(ContractError, match="F5_SHAP_SELECTION_HORIZON_INVALID"):
        f5.aggregate_final_shap([], {"selection_horizon_months": horizon})


@pytest.mark.parametrize("damage", [None, "plan", "decision"])
def test_full0_pool_binds_horizon_before_original_numerical_reduction(monkeypatch, damage):
    class ReachedOriginalReduction(Exception):
        pass
    context = {"UNFITTED_CONTEXT": True}
    decision = {"selection_horizon_months": 12}
    lock = {"selection_horizon_months": 12}
    plan = {"kind": "PADML_NESTED_FULL_FINAL_INPUT_V1", "training_context": context,
            "family_decision": decision, "development_lock": lock, "selection_horizon_months": 12}
    if damage == "plan":
        del plan["selection_horizon_months"]
    elif damage == "decision":
        del decision["selection_horizon_months"]
    plan = nested._sealed(plan)
    monkeypatch.setattr(nested, "validate_training_context", lambda value: value)
    monkeypatch.setattr(nested, "validate_family_decision", lambda value: value)
    monkeypatch.setattr(nested, "validate_development_lock", lambda value, **kw: value)
    def reduce(**kw):
        raise ReachedOriginalReduction
    monkeypatch.setattr(nested, "_seal_full_final_apparent_prediction", reduce)
    with pytest.raises(ContractError if damage else ReachedOriginalReduction,
                       match="F5_FINAL_LINEAGE_SELECTION_HORIZON_MISMATCH" if damage else None):
        f5.pool_predictions([], [], decision, plan, [])
