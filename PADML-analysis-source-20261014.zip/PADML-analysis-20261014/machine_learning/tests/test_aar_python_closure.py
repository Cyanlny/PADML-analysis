"""Actual old code + synthetic receipt through the original AAR reader.

The report SHA seam is a synthetic preimage, not historical scientific evidence.
No clinical data, fit, native replay or production reclamation belongs here.
"""
import copy
import os
from pathlib import Path

import pytest

from padml import f4, f5_sensitivity as sensitivity, runtime
from padml.bundle import ContractError, canonical_json_bytes, sha256_bytes, sha256_file
from test_a12_q_input_release import q_call  # noqa: F401


@pytest.mark.parametrize("damage", [None, "source", "fit", "input", "result", "memory", "owner", "future-policy"])
def test_original_prepared_reader_uses_actual_cb0_source_without_new_calls(q_call, monkeypatch, damage):
    path = os.environ.get("PADML_OUTER6_TEST_CB0")
    if path is None:
        pytest.skip("Exact code-only cb0 source is required")
    source = Path(path)
    assert sha256_file(source) == "5a02fe67703a9d0cc71a5a4b3a2575be1f0376dcf3b5ecb6fc543d3ec00d1107"
    monkeypatch.setattr(runtime, "effective_cpu_count", lambda: 32)
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda root: {
        "effective_cpus": 32, "available_memory_bytes": 64 * 1024**3,
        "scratch_available_bytes": 128 * 1024**3, "scratch_root": str(root)})
    monkeypatch.setattr(runtime, "_visible_open_file_keys", lambda keys: (set(), 1))
    case = q_call
    case["state"]["empty_q_program"] = True
    value = sensitivity.execute_a12_outer_bundle(case["source"], case["target"], **case["arguments"])
    case["consume"](value)
    candidate = copy.deepcopy(value)
    report = candidate["execution_report"]
    identity = "cb0f1fff3adf46cb2187c5006dd727c8994e3cc7acabd26f20976b8944c4317b"
    report["source_identity"] = identity
    # Construct the old policy formula explicitly; do not relabel the current
    # scratch-free execution as a valid historical resource report.
    report.pop("execution_scratch_reserve_bytes", None)
    report["effective_policy"]["scratch_reserve_bytes"] = (
        report["resource_policy"]["scratch_reserve_bytes"] + 64 * 1024**2)
    for observation in (report, report["after_release"]):
        if observation is not None:
            observation["resource_admission"] = runtime.resource_admission(
                report["effective_policy"], observation["resource_observation"], legal_tasks=1)
    for name in ("selector_inputs", "selector_program"):
        release = report["input_lifecycle"][name]["resource_release"]
        release["reader_scan_status"] = "UNKNOWN"
        for member in release["files"]:
            member.update(status="UNKNOWN", error="UNFITTED_HISTORICAL_SCAN_ERROR")
    if damage == "source":
        source = Path(os.environ["PADML_OUTER6_TEST_F50"])
    elif damage == "fit":
        candidate["new_model_fits"] = 1
        report["result_sha256"] = sha256_bytes(canonical_json_bytes(
            {key: val for key, val in candidate.items() if key != "execution_report"}))
    elif damage == "input":
        report["q_input"]["sha256"] = "0" * 64
    elif damage == "result":
        report["result_sha256"] = "0" * 64
    elif damage == "memory":
        report["effective_policy"]["memory_reserve_bytes"] -= 1
    elif damage == "owner":
        report["input_lifecycle"]["selector_inputs"]["resource_release"]["owner"] = "UNRELATED"
    elif damage == "future-policy":
        report["execution_scratch_reserve_bytes"] = 0
    sealed = canonical_json_bytes(report)
    monkeypatch.setattr(sensitivity, "sha256_bytes", lambda raw:
        "4218a603c608cec9501d939578fdb4a7958dce419d4dcf340a454d776e72b70d"
        if raw == sealed else sha256_bytes(raw))
    original = sensitivity._validate_a12_q_input_execution
    proof = f4._retained_full0_source_members
    proofs = []
    def observe_proof(path, **kwargs):
        actual = proof(path, **kwargs)
        proofs.append((path, kwargs, sha256_bytes(canonical_json_bytes(actual))))
        return actual
    monkeypatch.setattr(f4, "_retained_full0_source_members", observe_proof)
    def consume(value, **kwargs):
        return original(value, **{**kwargs, "executor_source_identity": identity,
            "retained_executor_source_bundle": source, "retained_primary_source_bundle": None})
    monkeypatch.setattr(sensitivity, "_validate_a12_q_input_execution", consume)
    before = {path: sha256_file(path) for path in case["target"].rglob("*") if path.is_file()}
    releases = list(case["state"]["releases"])
    if damage is None:
        case["consume"](candidate)
        assert proofs == [(source, {"aar_python_q": True}, identity)]
    else:
        with pytest.raises(ContractError):
            case["consume"](candidate)
        assert len(proofs) == 1
    assert {path: sha256_file(path) for path in before} == before
    assert case["state"]["releases"] == releases
    assert case["state"]["native_calls"] == 0
