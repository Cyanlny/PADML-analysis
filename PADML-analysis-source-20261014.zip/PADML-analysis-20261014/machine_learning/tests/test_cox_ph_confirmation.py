"""The fixed Cox PH model must execute M20 on all 15 registered inner splits."""
from __future__ import annotations

import copy
from pathlib import Path

import pytest

from padml.bundle import ContractError
from padml import f2_kernel as kernel
from padml.f2_validation import _validate_nonelastic_winner, _validate_registered_partition_execution
from test_f2_scoring import _constant_prediction, _response
from test_science_golden import _registered_outer_fixture


@pytest.fixture
def confirmation(tmp_path, monkeypatch):
    fit_ids = [f"TRAIN_{i}" for i in range(40)]
    fit_response = _response(fit_ids, [50.0]*40, [1]*40)
    inner = []
    for repeat in range(1, 4):
        for fold in range(1, 6):
            ids = [f"K{fold}_{i}" for i in range(8)]
            response = _response(ids, [50.0]*8, [1]*8)
            directory = tmp_path/f"R{repeat}K{fold}"
            directory.mkdir()
            (directory/"imp01.csv").write_text("Patient_ID,Center\n" + "".join(f"{patient_id},36\n" for patient_id in ids))
            inner.append({
                "kind": "INNER", "partition_id": f"R{repeat}K{fold}", "repeat": repeat, "inner_fold": fold,
                "fit_ids": fit_ids, "evaluation_ids": ids, "evaluation_ids_sha256": kernel._sha(ids),
                "fit_response": fit_response, "evaluation_response": response,
                "covariates": {"input_dir": str(directory), **{key: "a"*64 for key in (
                    "analysis_view_sha256", "application_view_sha256", "analysis_ids_sha256", "application_ids_sha256", "data_identity")}},
                "fit_covariate_members": [{"name": f"imp{m:02d}.csv", "sha256": "b"*64, "size_bytes": 120} for m in range(1, 21)],
            })
    outer = {"kind": "OUTER", "partition_id": "OUTER_F1"}
    recipes = [{"partition_id": row["partition_id"], "recipe_sha256": f"{index:064x}"}
               for index, row in enumerate([*inner, outer], start=1)]
    selector = {"selected_parents": ["AST_ALT", "Age"], "recipe_set": {"recipes": recipes}}
    spec = {"family": "COX_PH", "fold": 1, "seed": 301000, "predictors": {},
            "selector_from_dependency": selector, "monthly_fit_horizons": list(range(1, 37)),
            "search_budget": {"formal_confirmation": "M20_X15"},
            "model_seed_policy": {"repeat_multiplier": 100, "inner_multiplier": 1}}
    calls = []
    monkeypatch.setattr(kernel, "_outer_recipe_from_selector", lambda *_: recipes[-1])

    def evaluate(actual_spec, registered, tasks, scratch, repo_root):
        calls.append(("CONFIRMATION", tasks))
        assert len(tasks) == 300
        rows = []
        by_id = {row["partition_id"]: row for row in inner}
        for task in tasks:
            partition = by_id[task["partition_id"]]
            assert task["selected_parents"] == selector["selected_parents"]
            assert task["parameters"] == {} and task["family"] == "COX_PH"
            assert task["transform_recipe"]["partition_id"] == task["partition_id"]
            assert task["seed"] == 301000 + 100*partition["repeat"] + partition["inner_fold"] + task["imputation"]
            sealed = _constant_prediction(partition["evaluation_ids"], task["imputation"]/21)
            metric = kernel._evaluate_prediction_seal(
                kernel._monthly_prediction_seal(sealed), fit_response=fit_response,
                evaluation_response=partition["evaluation_response"])
            rows.append({**{key: task[key] for key in ("task_id", "partition_id", "imputation")},
                         "sealed_prediction": sealed, "prediction_seal_sha256": sealed["sha256"],
                         "ibs_0_24": metric["ibs_0_24"]})
        return rows

    def fit_outer(actual_spec, registered, tasks, scratch, repo_root):
        calls.append(("OUTER", tasks))
        assert len(tasks) == 20
        assert all(task["partition_id"] == "OUTER_F1" and task["seed"] == 301000+task["imputation"] for task in tasks)
        return []

    monkeypatch.setattr(kernel, "_evaluate_r_prediction_batch", evaluate)
    monkeypatch.setattr(kernel, "_run_r_prediction_batch", fit_outer)
    monkeypatch.setattr(kernel, "_build_registered_model_result", lambda *args, **kwargs: kwargs)
    result = kernel._run_r_registered_cox_ph(spec, {"partitions": [*inner, outer]}, tmp_path, Path("unused"))
    return result, selector, inner, calls


def test_cox_ph_confirmation_runs_exactly_300_then_20_without_selection(confirmation):
    result, selector, inner, calls = confirmation
    assert [name for name, _ in calls] == ["CONFIRMATION", "OUTER"]
    assert result["search_evaluation_unit_count"] == 320
    assert len(result["execution_rows"]) == 15
    assert all(row["purpose"] == "FORMAL_CONFIRMATION" and row["prediction_seal_count"] == row["evaluation_count"] == 20
               for row in result["execution_rows"])
    trace = result["search_trace"]["FORMAL_CONFIRMATION"][0]
    assert trace["evaluation_units"] == 300 and trace["ranking_evaluation_count"] == 3
    assert trace["partition_ids"] == [row["partition_id"] for row in inner]
    assert trace["mean_ibs"] == pytest.approx((.125+23*.25)/24)
    _validate_nonelastic_winner("COX_PH", result["search_trace"], result["selected_spec"], selector,
        {"search_budgets": {"COX_PH": {"formal_confirmation": "M20_X15"}}}, {}, 320)


def confirmation_value(confirmation):
    result, _, inner, _ = confirmation
    value, expected_input = _registered_outer_fixture()
    expected_input["model_partitions"] = [*[kernel._registered_partition_identity_record(row) for row in inner],
                                           *expected_input["model_partitions"]]
    execution = value["registered_partition_execution"]
    execution.update(family="COX_PH", expected_partition_count=16, executed_partition_count=16,
                     partitions=[*copy.deepcopy(result["execution_rows"]), *execution["partitions"]])
    execution["identity"] = kernel._sha({key: item for key, item in execution.items() if key != "identity"})
    value["search_trace"] = copy.deepcopy(result["search_trace"])
    return value, expected_input


def test_cox_ph_actual_partition_evidence_links_all_300_metrics_and_predictions(confirmation):
    value, expected = confirmation_value(confirmation)
    final = _validate_registered_partition_execution(value, 1, "COX_PH", expected)
    assert final["kind"] == "OUTER"


@pytest.mark.parametrize("damage", ["empty", "count", "missing_imputation", "missing_partition", "efron", "recipe", "set_a", "mi_pooling"])
def test_cox_ph_confirmation_cannot_be_replaced_by_outer_only_or_relaxed_evidence(confirmation, damage):
    result, selector, _, _ = confirmation
    trace = copy.deepcopy(result["search_trace"])
    row = trace["FORMAL_CONFIRMATION"][0]
    count = 320
    if damage == "empty":
        trace = {}
    elif damage == "count":
        count = 20
    elif damage == "missing_imputation":
        row["prediction_seal_sha256s"].pop()
    elif damage == "missing_partition":
        row["partition_ids"].pop()
    elif damage == "efron":
        row["parameters"]["ties"] = "efron"
    elif damage == "recipe":
        row["recipe_sha256s"].reverse()
    elif damage == "set_a":
        row["selected_parent_sha256"] = kernel._sha(["AST_ALT"])
    elif damage == "mi_pooling":
        row["mean_ibs"] = sum(row["metric_values"])/300
    with pytest.raises(ContractError):
        _validate_nonelastic_winner("COX_PH", trace, result["selected_spec"], selector,
            {"search_budgets": {"COX_PH": {"formal_confirmation": "M20_X15"}}}, {}, count)


@pytest.mark.parametrize("damage", ["count", "metric", "prediction", "purpose"])
def test_cox_ph_confirmation_execution_cannot_claim_unexecuted_or_unlinked_fits(confirmation, damage):
    value, expected = confirmation_value(confirmation)
    execution = value["registered_partition_execution"]
    row = execution["partitions"][0]
    if damage == "count":
        row["prediction_seal_count"] = 19
    elif damage == "metric":
        row["metric_set_sha256"] = "0"*64
    elif damage == "prediction":
        row["prediction_seal_set_sha256"] = "0"*64
    else:
        row["purpose"] = "MODEL_SELECTION"
    execution["identity"] = kernel._sha({key: item for key, item in execution.items() if key != "identity"})
    with pytest.raises(ContractError, match="FORMAL_CONFIRMATION_EXECUTION_INVALID"):
        _validate_registered_partition_execution(value, 1, "COX_PH", expected)
