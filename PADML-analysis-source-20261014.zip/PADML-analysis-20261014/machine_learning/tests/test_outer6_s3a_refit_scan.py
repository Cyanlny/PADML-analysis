"""Synthetic H0 receipt pairing only; no clinical input, fit or page release."""
import copy
from pathlib import Path

import pytest

from padml import f4, f5, runtime
from padml.bundle import ContractError, canonical_json_bytes, sha256_bytes, sha256_file
from test_outer6_q_resource_evidence import (PREFIX, INPUT, POLICY, S3A_PINS, _observation,
    _forbidden, _synthetic_resource_documents, _synthetic_refit_documents, _synthetic_s3a_documents)

CB0 = "cb0f1fff3adf46cb2187c5006dd727c8994e3cc7acabd26f20976b8944c4317b"
PINS = {**S3A_PINS,
    PREFIX + "producer-cb0.zip": {"sha256": "5a02fe67703a9d0cc71a5a4b3a2575be1f0376dcf3b5ecb6fc543d3ec00d1107", "size_bytes": 1044218},
    PREFIX + "H0-s3a-refit-execution.json": {"sha256": "322ed3082b3dc89333c4afb028e3dbe196c88a3108738d60f6c43828d4479463", "size_bytes": 287456},
    PREFIX + "H0-s3a-refit-resource-resolution.json": {"sha256": "579e246d38a926b70a78865e3592dfd853ea033a0ca23dcf09fdc5d0ffdd4da3", "size_bytes": 513258},
    PREFIX + "H0-s3a-refit-scan-admission.json": {"sha256": "c30b87cc4abef2e5b54e7768235554063ef8170efcc411fa4e2c450c9e9790a1", "size_bytes": 30339}}


def _documents(root):
    # Receipt paths are metadata, not real test files. Keep their size stable
    # regardless of the pytest scratch path length, as in a frozen receipt.
    execution, supplement = _synthetic_refit_documents(Path('/UNFITTED'), "H0", 0)
    owned = Path(execution["prepared_q_input"]["input_root"])
    phase, ids = f5._a12_q_stop_phase("S3A", refit=True, family="COXTIME_SET_A")
    execution.update(source_identity=CB0, phase=phase, task_ids=ids[::7],
        new_model_fit_count=29, confirmed_first_native_audit_count=29)
    prepared = execution["prepared_q_input"]
    prepared["members"] = {f"UNFITTED-{i:02d}.bin": {"sha256": "a"*64, "size_bytes": i+1} for i in range(48)}
    exact = {prepared["archive"]["path"]: {k: prepared["archive"][k] for k in ("sha256", "size_bytes")},
        **{str(owned / n): p for n, p in prepared["members"].items()}}
    old = execution["resource_release"]["prepared_inputs"]
    old["files"] = [{"path": n, "size_bytes": p["size_bytes"], "device": 1, "inode": i+1,
        "mtime_ns": 2, "ctime_ns": 3, "status": "UNKNOWN", "error":
        "RESOURCE_READER_SCAN_FAILED:PermissionError:[Errno 13] Permission denied: '/proc/2180/fd/0'\n"
        "RESOURCE_READER_SCAN_PROCESS:/proc/2180;completed_processes:16"} for i, (n, p) in enumerate(exact.items())]
    execution_path = str(owned.parent.parent / "H0-outer6-s3a-refit-batch/execution.json")
    originals = {execution_path: PINS[PREFIX + "H0-s3a-refit-execution.json"],
        **{str(owned.parent.parent / f"UNFITTED-retained-{i}.bin"): {"sha256": None, "size_bytes": i+1} for i in range(451)}}
    release = supplement["resource_release"]
    release.update(owner="OUTER6_FIRST_S3A_REFIT_PRIVATE_RETURN:H0", files=[{
        "path": n, "size_bytes": p["size_bytes"], "device": 1, "inode": i+100,
        "mtime_ns": 2, "ctime_ns": 3, "status": "ADVISED", "error": None} for i, (n,p) in enumerate(originals.items())])
    fields = ("device", "inode", "size_bytes", "mtime_ns", "ctime_ns")
    supplement.update(source_identity=CB0, original_model_fits=29, original_first_native_audits=29,
        original_unknown_cleanup_retries=0, original_members=originals,
        excluded_original_unknown_files={r["path"]: copy.deepcopy(r) for r in old["files"]},
        verified_file_identities={r["path"]: {k:r[k] for k in fields} for r in release["files"]},
        effective_policy={**POLICY, "memory_reserve_bytes": POLICY["memory_reserve_bytes"]+2267232})
    returned = supplement["private_numerical_return"]
    returned.update(source_identity=CB0, status="PRIVATE_POSTFIT_FAILURE_INTEGRITY_CLOSED_NOT_ACCEPTED",
        task_ids=ids[::7], model_fits=29, first_native_audits=29, packet={
            "sha256": "b2cb7bcd2a7d5f249df45b2605dc8665fc1b39e45ad34df2d8fed0d9858e3f66",
            "size_bytes": 12576299, "scientific_acceptance": False})
    for p in ("", "post_release_"):
        supplement[p+"resource_admission"] = runtime.resource_admission(supplement["effective_policy"],
            supplement[p+"resource_observation"], legal_tasks=1)
    scan = {"host": "H0", "source_identity": CB0, "historical_cause": "UNKNOWN", "automatic_retry": False,
        "original_failure_rewritten": False, "status": "ORIGINAL_ONCE_READER_SCAN_ADMISSION_COMPLETE_NO_RELEASE",
        "candidate_files": exact, "verified_file_identities": {r["path"]: {k:r[k] for k in fields} for r in old["files"]},
        "original_execution": {"path": execution_path, **PINS[PREFIX+"H0-s3a-refit-execution.json"]},
        "original_call_sha256": "48059e761a1196a4bb0a9be97dc52f0c09a664437e1d1c685f7ac3f12af5e374",
        "failure_packet_sha256": returned["packet"]["sha256"],
        "post_return_resource_sha256": PINS[PREFIX+"H0-s3a-refit-resource-resolution.json"]["sha256"],
        "original_reader_scan_calls": 1, "original_current_admission_calls": 1, "original_unknown_files_retained": 49,
        "reader_scan": {"candidate_files": 49, "open_candidates": 0, "processes": 14, "status": "OBSERVED"},
        "effective_policy": copy.deepcopy(POLICY), "resource_observation": _observation(owned.parent.parent)}
    scan["resource_admission"] = runtime.resource_admission(POLICY, scan["resource_observation"], legal_tasks=1)
    for k in ("original_result_consumer_calls", "cache_release_calls", "files_deleted", "new_scientific_calls",
        "new_model_fits", "new_stop_fits", "new_mice_chains", "new_mice_fit_calls", "new_elastic_paths",
        "new_glmnet_calls", "new_first_native_audits", "new_native_model_replays", "loss_recovery_calculations"):
        scan[k] = 0
    return execution, supplement, scan


@pytest.mark.parametrize("damage", [None, "cause", "after", "host", "phase", "coordinate", "missing49", "identity",
    "open", "unknown_scan", "bool_scan", "release_retry", "new_fit", "consumer_used", "reserve", "admit29",
    "post_missing", "post_overlap", "wrong_pin", "incomplete_stage"])
def test_h0_scan_is_not_a_release_or_a_new_fit(tmp_path, monkeypatch, damage):
    root = tmp_path / "q"
    root.mkdir()
    documents = {PREFIX+n:v for n,v in zip(("H0-execution.json", "H0-resource-resolution.json"),
        _synthetic_resource_documents(root), strict=True)}
    for i, h in enumerate(("H0", "H1")):
        for suffix, v in zip(("-refit-execution.json", "-refit-resource-resolution.json"),
                _synthetic_refit_documents(root,h,i), strict=True): documents[PREFIX+h+suffix] = v
    for n,v in zip(("H7-s3a-stop-execution.json", "H7-s3a-stop-resource-resolution.json"),
            _synthetic_s3a_documents(root), strict=True): documents[PREFIX+n] = v
    execution, supplement, scan = _documents(root)
    if damage == "cause": execution["resource_release"]["prepared_inputs"]["files"][0]["error"] = "OTHER"
    elif damage == "after": execution["prepared_q_input"]["after_release"] = scan["resource_admission"]
    elif damage == "host": scan["host"] = "H1"
    elif damage == "phase": execution["phase"] = "S2"
    elif damage == "coordinate": execution["task_ids"][0] = "OTHER"
    elif damage == "missing49": scan["candidate_files"].pop(next(iter(scan["candidate_files"])))
    elif damage == "identity": next(iter(scan["verified_file_identities"].values()))["inode"] += 1
    elif damage == "open": scan["reader_scan"]["open_candidates"] = 1
    elif damage == "unknown_scan": scan["reader_scan"]["status"] = "UNKNOWN"
    elif damage == "bool_scan": scan["original_reader_scan_calls"] = True
    elif damage == "release_retry": scan["cache_release_calls"] = 1
    elif damage == "new_fit": scan["new_model_fits"] = 1
    elif damage == "consumer_used": scan["original_result_consumer_calls"] = 1
    elif damage == "reserve": scan["effective_policy"]["memory_reserve_bytes"] -= 1
    elif damage == "admit29": scan["resource_admission"] = runtime.resource_admission(POLICY, scan["resource_observation"], legal_tasks=29)
    elif damage == "post_missing": supplement["resource_release"]["files"].pop()
    elif damage == "post_overlap": supplement["original_members"].update(scan["candidate_files"])
    elif damage == "wrong_pin": scan["original_call_sha256"] = "0"*64
    elif damage == "incomplete_stage": execution["task_ids"].pop()
    for n,v in zip(("H0-s3a-refit-execution.json", "H0-s3a-refit-resource-resolution.json", "H0-s3a-refit-scan-admission.json"),
            (execution,supplement,scan), strict=True): documents[PREFIX+n] = v
    aliases = {}
    for n,p in {**PINS, "input.json": INPUT}.items():
        value = {"UNFITTED_INPUT": True} if n == "input.json" else documents.get(n)
        if value is None: raw = b"X"*p["size_bytes"]
        else:
            value = {**value, "UNFITTED_PADDING": ""}
            padding = p["size_bytes"] - len(canonical_json_bytes(value))
            assert padding >= 0
            value["UNFITTED_PADDING"] = "x"*padding
            raw = canonical_json_bytes(value)
        target = root / n
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(raw)
        aliases[sha256_bytes(raw)] = p["sha256"]
    monkeypatch.setattr(f5,"sha256_file",lambda p: aliases.get(sha256_file(p),sha256_file(p)))
    monkeypatch.setattr(f4,"_retained_full0_source_members",lambda *a,**k: {"UNFITTED":True})
    monkeypatch.setattr(runtime,"observe_execution_resources",_observation)
    monkeypatch.setattr(runtime,"release_step_resources",_forbidden)
    monkeypatch.setattr(runtime,"_visible_open_file_keys",_forbidden)
    monkeypatch.setattr(f5,"_execute_q_search_batch",_forbidden)
    if damage:
        with pytest.raises(ContractError): f5._q_python_resource_evidence(root,POLICY,expected=PINS)
    else:
        before = {n:(root/n).read_bytes() for n in PINS}
        assert f5._q_python_resource_evidence(root,POLICY,expected=PINS)[1] == PINS
        assert before == {n:(root/n).read_bytes() for n in PINS}
