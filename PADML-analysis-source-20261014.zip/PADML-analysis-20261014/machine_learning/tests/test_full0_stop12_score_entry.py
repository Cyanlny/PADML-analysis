"""Original full0 score routing; synthetic boundaries and zero model fitting."""
from contextlib import contextmanager

import pytest

from padml import f5
from padml.bundle import ContractError
from test_full0_fixed12_rescore import decision


@pytest.mark.parametrize('family', ['GBM_COX', 'XGBOOST_COX', 'COXTIME_SET_A'])
@pytest.mark.parametrize('mode', ['worker', 'gather', 'replay'])
def test_stop12_scores_use_common_prepared_root(tmp_path, monkeypatch, family, mode):
    lineage = dict(plan={}, science_decision=decision(), score_root=str(tmp_path / 'score'),
        selector_root=str(tmp_path / 'selector'), search_roots={}, rscript='UNFITTED',
        resource_policy={}, retained_bytes_per_component=1, expanded_bytes_per_component=1, shared_storage_bytes=1)
    monkeypatch.setattr(f5, '_read_final_lineage', lambda *a, **k: lineage)
    @contextmanager
    def materialized(*args, **kwargs):
        assert kwargs['selection_horizon_months'] == 12 and kwargs['retained_mice_plan'] == lineage['plan']
        assert 'selector_only' not in kwargs and 'q_input_lifecycle' not in kwargs
        yield lineage, [], {}
    observed = []
    def stage(*args, **kwargs):
        assert args[5] == tmp_path / 'score.all'
        assert kwargs['family'] == family and kwargs['selection_horizon_months'] == 12
        assert kwargs['replay'] == (mode == 'replay') and kwargs['resume'] == (mode != 'replay')
        observed.append(kwargs)
        return {'UNFITTED_BOUNDARY': True}
    monkeypatch.setattr(f5, '_materialized_full_data_development_sources', materialized)
    monkeypatch.setattr(f5, '_full_data_locked_score_program', stage)
    options = ({'task_ids': ['original-coordinate'], 'batch_root': tmp_path / 'batch'} if mode == 'worker'
               else {'score_batches': [tmp_path / 'batch']} if mode == 'gather' else {})
    assert f5.execute_full_data_locked_scores(tmp_path / 'lineage.json', family=family,
        selection_horizon_months=12, retained_full0_source_bundle=tmp_path / 'old.zip',
        replay=mode == 'replay', resume=mode != 'replay', **options) == {'UNFITTED_BOUNDARY': True}
    assert len(observed) == 1 and all(observed[0][key] == value for key, value in options.items())


@pytest.mark.parametrize('change', [{}, {'prepare_only': True}, {'resume': True},
    {'resume': True, 'task_ids': ['x'], 'batch_root': 'batch', 'score_batches': ['batch']},
    {'replay': True, 'task_ids': ['x'], 'batch_root': 'batch'}])
def test_stop12_cannot_enter_unbounded_fit_or_reprepare(tmp_path, monkeypatch, change):
    def forbidden(*args, **kwargs):
        pytest.fail('NO_MATERIALIZATION_BEFORE_SCOPE_CHECK')
    monkeypatch.setattr(f5, '_materialized_full_data_development_sources', forbidden)
    with pytest.raises(ContractError, match='SELECTION_SCOPE_INVALID'):
        f5.execute_full_data_locked_scores(tmp_path / 'lineage.json', family='GBM_COX',
            selection_horizon_months=12, retained_full0_source_bundle=tmp_path / 'old.zip', **change)


@pytest.mark.parametrize('retained', ['full-score-result.json',
    'score-evidence/GBM_COX/training-score.json', 'score-evidence/GBM_COX/execution.json'])
def test_completed_score_receipt_blocks_refit_without_native_copies(tmp_path, monkeypatch, retained):
    root = tmp_path / 'score.all'
    (root / 'request').mkdir(parents=True)
    (root / 'request/full-score-input.json').write_bytes(b'UNFITTED_PREPARED_INPUT')
    original = root / retained
    original.parent.mkdir(parents=True, exist_ok=True)
    original.write_bytes(b'RETAINED_COMPLETION_OR_PARTIAL_EVIDENCE')
    def forbidden(*args, **kwargs):
        pytest.fail('NO_COMPILATION_OR_FIT_FOR_COMPLETED_FAMILY')
    monkeypatch.setattr(f5, '_compile_full_score_inputs', forbidden)
    monkeypatch.setattr(f5, '_full_score_resource_admission', forbidden)
    with pytest.raises(ContractError, match='F4_NATIVE_MODEL_TARGET_ALREADY_STARTED'):
        f5._full_data_locked_score_program({}, [], {}, tmp_path / 'selector', {}, root,
            rscript='FORBIDDEN', replay=False, resume=True, family='GBM_COX',
            selection_horizon_months=12, retained_full0_source_bundle=tmp_path / 'old.zip',
            task_ids=['original-coordinate'], batch_root=root / 'score-batches/new-name',
            resource_policy={}, retained_bytes_per_component=1,
            expanded_bytes_per_component=1, shared_storage_bytes=1)
    assert original.read_bytes() == b'RETAINED_COMPLETION_OR_PARTIAL_EVIDENCE'
    assert not (root / 'components').exists()
