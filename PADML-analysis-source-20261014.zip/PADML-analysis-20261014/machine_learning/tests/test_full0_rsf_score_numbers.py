"""Synthetic Q-row to actual score-input binding and original M20 readback.

Q archive/source and R fit-health are separate leaves, not asserted here.
"""
import copy
import shutil

import pytest

from padml import f2_kernel as kernel, f4, f5, nested_loco as nested
from padml.bundle import ContractError, canonical_json_bytes, write_deterministic_zip
from test_full0_fixed12_rescore import decision, forbidden
from test_nested_score_replay import build_fixture


def test_rsf_q_numbers_bind_complete_common_inputs_and_original_score_readback(tmp_path, monkeypatch):
    request, request_root, components, old_outputs = build_fixture(tmp_path, full_score=True, science_decision=decision())
    spec = {"family": "RSF", "parameters": {"num.trees": 1000, "mtry_fraction": 1.0,
        "min.node.size": 5, "max.depth": 0, "sample.fraction": 0.632, "splitrule": "logrank"}}
    q_pin = {"sha256": "a" * 64, "size_bytes": 100}
    request["development"] = nested._sealed({**{key: value for key, value in request["development"].items()
        if key != "identity_sha256"}, "locked_specs": {"RSF": spec},
        "complex_search_evidence": [{"family": "RSF", "task": {"selection_horizon_months": 12,
            "science_decision": request["science_decision"]}, "retained_q_archive": q_pin}]})
    family_source = f5._full_score_family_source(request["development"], "RSF")
    column_map = [{"parent": "AST_ALT", "columns": ["AST_ALT"]}, {"parent": "Age", "columns": ["Age"]}]
    monkeypatch.setattr(kernel, "_expected_family_parent_column_map", lambda *a, **k: column_map)
    monkeypatch.setattr(kernel, "predictor_contract", lambda *a, **k: {})
    monkeypatch.setattr(kernel, "_validate_r_tree_fit_health", lambda *a, **k: None)
    monkeypatch.setattr(f5, "_execute_and_verify_score_archive_job", forbidden)
    monkeypatch.setattr(f4, "_replay_f4_model_component", forbidden)
    rows, pending = [], []
    for record in request["component_records"]:
        task, recipe, entries = copy.deepcopy(components[record["path"]])
        definition = next(part for part in request["score_partitions"]
            if (part["repeat"], part["inner_fold"]) == (record["repeat"], record["inner_fold"]))
        csv_path = tmp_path / "retained-q-readback/inputs" / definition["partition_id"] / "covariates" / f"imp{record['imputation']:02d}.csv"
        csv_path.parent.mkdir(parents=True, exist_ok=True)
        csv_path.write_text("Patient_ID,Center,AST_ALT,Age\n" + "".join(
            f"{patient},38,1,50\n" for patient in request["training_context"]["training_ids"]))
        seed = f4._f4_model_seed("RSF", task["f4_coordinates"])
        task.update(family="RSF", parameters=spec, registered_model_seed=seed, model_seed=seed,
                    nested_full_score_source=family_source)
        recipe.update(preprocessing_mode="F2_RAW_CANONICAL_AUTHORITY_LEVELS", transform_recipe=None)
        entries.update({"task.json": canonical_json_bytes(task), "recipe.json": canonical_json_bytes(recipe),
            "fit-covariates.csv": kernel._recipe_training_member_bytes(csv_path, definition["fit_ids"]),
            "prediction-covariates.csv": kernel._recipe_training_member_bytes(csv_path, definition["evaluation_ids"])})
        relative = record["path"].replace("FPM_TVC_SET_A", "RSF")
        path = request_root / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        write_deterministic_zip(path, entries)
        updated = {**record, "family": "RSF", "path": relative, "registered_model_seed": seed,
            "sha256": nested.sha256_file(path), "size_bytes": path.stat().st_size,
            "task_sha256": nested._sha(task), "recipe_sha256": nested._sha(recipe),
            "parameter_sha256": nested._sha(spec), "development_spec_sha256": nested._sha(spec)}
        rows.append(updated)
        partition = {**definition, "fit_response": {"sha256": nested.sha256_bytes(entries["fit-response.csv"])},
            "evaluation_ids_sha256": nested._sha(definition["evaluation_ids"]), "covariates": {"members": [{
                "name": csv_path.name, "sha256": nested.sha256_file(csv_path), "size_bytes": csv_path.stat().st_size}]}}
        producer = {"family": "RSF", "imputation": record["imputation"],
            "parameters": kernel._locked_family_parameters("RSF", spec), "partition_id": definition["partition_id"],
            "prediction_horizons": list(range(1, 37)), "seed": seed, "selected_parents": task["selected_parents"],
            "task_id": f"S3B2_T001_P{5*(record['repeat']-1)+record['inner_fold']:02d}_M{record['imputation']:02d}"}
        curve = old_outputs[record["path"]]["prediction"]["survival"]["FPM_TVC_SET_A"]
        row = {"transform_recipe_sha256": "RAW_CANONICAL", "ordered_parent_column_map": column_map,
            "stopping": {"UNFITTED_HEALTH_LEAF": True}, "sealed_prediction": kernel._seal_prediction_matrix(
                definition["evaluation_ids"], [values[1:] for values in curve], list(range(1, 37)))}
        pending.append((updated, {"registered_partitions": {"partitions": [partition]}}, producer, row))
    # Other families are unconsumed coordinate metadata only.
    request["component_records"] = [{**row, "family": family, "path": row["path"].replace("RSF", family)}
        for family in nested._families() for row in rows]
    request = nested._sealed({key: value for key, value in request.items() if key != "identity_sha256"})
    provenance = {name: "b" * 64 for name in ("input_execution_sha256", "q_source_identity_sha256",
        "q_manifest_sha256", "q_task_sha256", "registered_inputs_identity_sha256", "batch_spec_sha256", "batch_output_sha256")}
    provenance.update(kind="PADML_FULL0_RSF_Q_SCORE_SOURCE_V1", selection_horizon_months=12,
        science_decision_sha256=request["science_decision"]["identity_sha256"], request_identity_sha256=request["identity_sha256"],
        q_archive_sha256=q_pin["sha256"], q_archive_size_bytes=q_pin["size_bytes"], unit_id="batch-" + "b"*24,
        first_native_audit={"kind": "ORIGINAL_BATCH_EXECUTION", "member": "original.json", "sha256": "b"*64,
            "size_bytes": 1, "replay_output_sha256": None}, historical_model_fit_count=1,
        new_model_fit_count=0, new_first_native_audit_count=0, new_native_replay_count=0)
    object_raw = canonical_json_bytes({"model.rds": {"sha256": "c"*64, "size_bytes": 1}})
    outputs = {}
    for record, source_spec, producer, row in pending:
        evidence, _ = f5._full0_rsf_q_score_component(request=request, root=tmp_path, record=record,
            spec=source_spec, producer=producer, row=row, object_raw=object_raw, provenance=provenance)
        outputs[record["path"]] = evidence
    score, execution = nested._score_fresh_family(family="RSF", request=request, root=tmp_path, outputs=outputs)
    assert execution["new_model_fit_count"] == execution["new_first_native_audit_count"] == execution["new_native_replay_count"] == 0
    for record in execution["component_evidence_records"]:
        target = tmp_path / record["path"]
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(tmp_path / "score-evidence/RSF" / target.name, target)
    assert nested._recompute_fresh_score_from_evidence(execution=execution, score=score, request=request,
        request_root=request_root, result_root=tmp_path, expanded_bytes_per_component=10**6,
        retained_bytes_per_component=10**6) == score
    record, source_spec, producer, row = pending[0]
    with pytest.raises(ContractError):
        f5._full0_rsf_q_score_component(request=request, root=tmp_path, record=record, spec=source_spec,
            producer={**producer, "seed": producer["seed"] + 1}, row=row, object_raw=object_raw, provenance=provenance)
    altered = copy.deepcopy(row)
    payload = altered["sealed_prediction"]["payload"]
    payload["patient_ids"] = list(reversed(payload["patient_ids"]))
    altered["sealed_prediction"]["sha256"] = nested._sha(payload)
    with pytest.raises(ContractError):
        f5._full0_rsf_q_score_component(request=request, root=tmp_path, record=record, spec=source_spec,
            producer=producer, row=altered, object_raw=object_raw, provenance=provenance)
    partition = source_spec["registered_partitions"]["partitions"][0]
    source = tmp_path / "retained-q-readback/inputs" / partition["partition_id"] / "covariates/imp01.csv"
    saved = source.read_bytes()
    source.write_bytes(saved.replace(b",1,50", b",2,50"))
    partition["covariates"]["members"][0]["sha256"] = nested.sha256_file(source)
    with pytest.raises(ContractError):
        f5._full0_rsf_q_score_component(request=request, root=tmp_path, record=record, spec=source_spec,
            producer=producer, row=row, object_raw=object_raw, provenance=provenance)
    source.write_bytes(saved)
