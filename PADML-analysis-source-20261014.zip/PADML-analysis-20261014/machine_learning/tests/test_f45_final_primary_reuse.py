"""UNFITTED final-M20 orchestration, byte custody and archive-read boundaries.

Model bytes and health leaves are deliberately synthetic. Real task, context,
lock, receipt, original-byte, pooling and consumer-binding checks remain active.
These tests establish no clinical fit or scientific whole-unit acceptance.
"""
import copy
import io
import shutil
import zipfile
from pathlib import Path

import pytest

from padml import f2_kernel, f4, f4_compact, f5, nested_loco as n
from padml.bundle import ContractError, canonical_json_bytes as encode, read_safe_zip, write_deterministic_zip
from test_f45_final_reuse import final_entries
from test_nested_loco import _summary


def seal(value):
    return n._sealed({k: v for k, v in value.items() if k != "identity_sha256"})


def pin(path):
    return {"sha256": n.sha256_file(path), "size_bytes": path.stat().st_size}


def fixture(root, monkeypatch, changed=0):

    # New independent reads use the original pool seam; native leaves stay UNFITTED.
    # Pickle each task exactly as spawn transport; results keep canonical order.
    from padml import runtime
    import pickle
    def readback(function, items, **kwargs):
        result = [None] * len(items)
        for index in range(len(items)):
            fn, item = pickle.loads(pickle.dumps((function, items[index])))
            result[index] = fn(item)
        return result
    monkeypatch.setattr(runtime, "_readback_ordered", readback)
    science = n.science_decision_template(6)  # This fixture covers the unchanged H06/H12 population.
    members = f4._f45_source_member_sha256()
    identity = n._sha(members)
    monkeypatch.setattr(f5, "_f45_score_reuse_authorities", lambda: ({"e"*64: identity}, {identity: members}))
    monkeypatch.setattr(f5, "_validate_final_r_fit_health", lambda *a, **k: None)
    monkeypatch.setattr(f5, "_validate_retained_r_audit_numbers", lambda *a, **k: None)
    monkeypatch.setattr(f4, "resolve_pool_workers", lambda x: 2)
    monkeypatch.setattr(f5, "_score_archive_handle", lambda *a, **k: None)
    ids = [f"p{i:02d}" for i in range(40)]
    response = ("Patient_ID,All_Cause_Death,Death_Followup_months\n"
                + "".join(f"{p},1,50\n" for p in ids)).encode()
    context = n.compile_training_context(scope="OUTER", outer_fold=1, heldout_center=36,
        training_ids=ids, heldout_ids=["h1"], centers_by_patient={**{p:"38" for p in ids}, "h1":"36"},
        training_response_csv=response, mice_member_set_sha256="a"*64,
        preprocessing_program_sha256=identity, modeling_program_sha256=identity,
        seed_program_sha256="d"*64)
    base = final_entries("COX_PH", "PRIMARY")
    header = base["fit-covariates.csv"].decode().splitlines()[0]
    fields = header.split(",")
    def covariates(patient_ids):
        return (header+"\n"+"".join(",".join(p if name=="Patient_ID" else
            "36" if p=="h1" and name=="Center" else "38" if name=="Center" else "1"
            for name in fields)+"\n" for p in patient_ids)).encode()
    base.update({"fit-response.csv":response, "fit-covariates.csv":covariates(ids),
                 "prediction-covariates.csv":covariates(["h1"])})
    partitions = [{"partition_id":f"R{r}K{k}", "repeat":r, "inner_fold":k,
        "fit_ids":[p for p in ids if p not in ids[(k-1)*8:k*8]], "evaluation_ids":ids[(k-1)*8:k*8]}
        for r in range(1,4) for k in range(1,6)]
    all_records = [{"family":fam,"repeat":r,"inner_fold":k,"imputation":i,
        "path":f"components/score/{fam}/R{r}_K{k}_M{i:02d}.zip"}
        for fam in n._families() for r in range(1,4) for k in range(1,6) for i in range(1,21)]
    owners=[]
    for h in (6,12):
        work=root/("original" if h==6 else "consumer")
        (work/"request").mkdir(parents=True)
        template_entries, templates, records=[],[],[]
        scores=[n.seal_fresh_training_score(family=fam, outer_fold=1,
            training_context_sha256=context["identity_sha256"],
            selected_spec={"family":fam,"UNFITTED":True}, selector_evidence_sha256="a"*64,
            summary={**_summary(.1+j*.01),"selection_horizon_months":h},
            execution_evidence_sha256="f"*64,selection_horizon_months=h,
            science_decision_sha256=science["identity_sha256"]) for j,fam in enumerate(n._families())]
        decision=n.select_training_family(scores)
        for imp in range(1,21):
            entries=copy.deepcopy(base)
            task=f5.strict_json_bytes(entries["task.json"])
            task.pop("development_lock_sha256")
            task.update(imputation=imp,row_count=40)
            task["f4_coordinates"]["imputation"]=imp
            task["registered_model_seed"]=f4._f4_model_seed("COX_PH",task["f4_coordinates"])
            entries["task.json"]=encode(task)
            if h==12 and imp>20-changed:
                entries["fit-covariates.csv"]=entries["fit-covariates.csv"].replace(b"p00,38,1",b"p00,38,2",1)
            name=f"components/post-lock/COX_PH/M{imp:02d}.zip"
            path=work/"request"/name
            path.parent.mkdir(parents=True,exist_ok=True)
            write_deterministic_zip(path,entries)
            record={**n._validate_outer_component(path,role="POST_LOCK_TEMPLATE",family="COX_PH",context=context),
                "path":name,**pin(path),"role":"POST_LOCK_TEMPLATE",
                "development_spec_sha256":decision["selected_spec_sha256"]}
            records.append(record)
            templates.append(task)
            template_entries.append(entries)
        metadata=dict(selected_parents=["AST_ALT"],common_set_design_df=1,training_event_count=40,
            baseline_policy_sha256="b"*64,seed_policy_sha256="d"*64)
        lock=n.seal_development_lock(context=context,decision=decision,science_decision=science,**metadata,
            parameters_by_imputation=[x["parameters"] for x in templates],
            recipe_sha256_by_imputation=[x["recipe_sha256"] for x in records],
            post_lock_template_sha256_by_imputation=[x["task_sha256"] for x in records],
            post_lock_template_archive_sha256_by_imputation=[x["sha256"] for x in records])
        request=seal(dict(kind="PADML_F4_O_FIT_INPUT_V1",training_context=context,
            science_decision=science,selection_horizon_months=h,post_lock_templates=records,
            component_records=all_records,score_partitions=partitions,selector_evidence_sha256="a"*64,
            development_metadata=metadata,retained_bytes_per_component=16*1024**2,
            expanded_bytes_per_component=16*1024**2,shared_storage_bytes=256*1024**2,
            resource_policy={"scratch_reserve_bytes":0}))
        bound=[{**entries,"task.json":encode(n.bind_post_lock_task(task,lock))}
            for task,entries in zip(templates,template_entries)]
        owners.append((request,work,lock,dict(family_decision=decision,training_scores=scores),bound))
    def native(job, include_execution=False):
        entries=job["entries"]
        directory=Path(job["root"])
        directory.mkdir(parents=True,exist_ok=True)
        task,_,training,_,application,_=f4._f4_native_component_inputs(entries)
        curve=[1.]+[1-month*.01 for month in range(1,37)]
        prediction=f4._f4_native_prediction(task,application,[curve]*len(application))
        result={**entries,"model.bin":b"UNFITTED_MODEL","baseline.bin":b"UNFITTED_BASELINE",
            "fit-health.json":encode({"UNFITTED":True}),"prediction.json":encode(prediction),
            "training-prediction.json":encode([curve]*len(training))}
        for name,raw in result.items():
            (directory/name).write_bytes(raw)
        write_deterministic_zip(directory.with_suffix(".zip"),result)
        return {"new_model_fits":1} if include_execution else prediction
    counts={"fit":0,"audit":0,"pools":[]}
    def fit(job,include_execution=False,retained_only=False):
        assert retained_only is False, "this fixture only produces fresh UNFITTED models"
        counts["fit"]+=1
        return native(job,include_execution=include_execution)
    def audit(job,include_audit=False):
        counts["audit"]+=1
        raw=read_safe_zip(Path(job["archive"]))
        assert all(raw[k]==v for k,v in job["entries"].items())
        return {"prediction":f5.strict_json_bytes(raw["prediction.json"]),
            "fit_health":f5.strict_json_bytes(raw["fit-health.json"]),
            "retained_audit":{"design_columns":["AST_ALT"],"UNFITTED":True}}
    def pool(function,jobs,*,selected_slots,execution_report,on_result=None,**kwargs):
        assert jobs, "all-hit must never open an empty pool"
        counts["pools"].append(len(jobs))
        values=[]
        for index,job in enumerate(jobs):
            row=function(job)
            values.append(row)
            if on_result is not None: on_result(index,row)
        execution_report.update(runnable_task_count=len(jobs),completed_task_count=len(jobs),
            actual_worker_process_peak=1,engine_threads=1,status="COMPLETED",
            configured_worker_ceiling=2,admitted_worker_ceiling=selected_slots)
        return values
    monkeypatch.setattr(f4,"_execute_f4_model_component",fit)
    monkeypatch.setattr(f4,"_replay_f4_model_component",audit)
    monkeypatch.setattr(f4,"_bounded_ordered_spawn",pool)
    original,old,lock,_,bound=owners[0]
    numbers=[]
    for imp,entries in enumerate(bound,1):
        directory=old/"fits"/f"M{imp:02d}"
        prediction=native({"entries":entries,"root":str(directory)})
        receipt=f5._f45_final_consumer_receipt(entries,context=context,lock=lock,
            model_sha256=n.sha256_bytes(b"UNFITTED_MODEL"),baseline_sha256=n.sha256_bytes(b"UNFITTED_BASELINE"),
            prediction=prediction,health={"UNFITTED":True})
        numbers.append(dict(receipt=receipt,prediction=prediction,fit_health={"UNFITTED":True},
            object_audit={"design_columns":["AST_ALT"],"UNFITTED":True},
            native_archive={"member":f"fits/M{imp:02d}.zip",**pin(directory.with_suffix(".zip"))}))
    pooled=f2_kernel._pool_prediction_batch([{"sealed_prediction":f2_kernel._seal_prediction_matrix(
        row["prediction"]["patient_ids"],row["prediction"]["survival"]["COX_PH"],list(n.HORIZONS))}
        for row in numbers],list(n.HORIZONS))
    selected=n.seal_selected_prediction(lock=lock,patient_ids=["h1"],centers=["36"],
        survival=pooled["payload"]["survival"],component_receipts=[x["receipt"] for x in numbers])
    f4_compact.write_o_fit_final_numbers(old,request=original,lock=lock,components=numbers,selected=selected,
        native_members={x["native_archive"]["member"]:{k:x["native_archive"][k] for k in ("sha256","size_bytes")} for x in numbers})
    unit=root/"PRIMARY-H06-O1"
    unit.mkdir()
    shutil.move(str(old),unit/"result.zip.work")
    old=unit/"result.zip.work"
    write_deterministic_zip(unit/"input.zip",{"o-fit-input.json":encode(original)})
    (unit/"input.compile.json").write_bytes(b"{}")
    meta=seal(dict(kind="PADML_F4_O_FIT_EXECUTION_ARCHIVE_V3",outer_fold=1,
        input_identity_sha256=original["identity_sha256"],input_archive=pin(unit/"input.zip"),
        development_lock=lock,component_receipts=[x["receipt"] for x in numbers],
        native_members={x["native_archive"]["member"]:{k:x["native_archive"][k] for k in ("sha256","size_bytes")} for x in numbers},
        members={"final-numbers.zip":pin(old/"final-numbers.zip")}))
    write_deterministic_zip(unit/"result.zip",{"o-fit-execution.json":encode(meta),"final-numbers.zip":old/"final-numbers.zip"})
    receipt=dict(status="COMPLETED",direct_consumer_completed=True,unit_id=unit.name,
        selection_horizon_months=6,report_horizons_months=[6,12,24,36],run_identity="e"*64,
        artifacts={name:pin(unit/name) for name in ("input.zip","input.compile.json","result.zip")})
    (unit/"unit.json").write_bytes(encode(receipt))
    return owners[1],dict(root=str(unit),receipt=receipt),counts,encode(numbers),old


@pytest.mark.parametrize("changed",[0,1,20])
def test_primary_final_reuse_runs_only_missing_mi(tmp_path,monkeypatch,changed):
    (request,root,lock,scores,_),candidate,counts,original,old=fixture(tmp_path,monkeypatch,changed)
    result=f4._o_fit_post_lock_m20(request,scores,root,workers=2,replay=False,completed_final_units=[candidate])
    assert counts["fit"]==counts["audit"]==result["new_model_fits"]==changed
    assert result["reused_final_model_count"]==20-changed
    assert counts["pools"]==([] if changed==0 else [changed,changed])
    first=read_safe_zip(old/"final-numbers.zip")
    assert encode(f5.strict_json_bytes(first["final.json"])["components"])==original
    members=result["native_members"]
    replay=f4_compact.read_o_fit_final_numbers(root/"final-numbers.zip",request=request,
        request_root=root/"request",lock=lock,native_members=members)
    assert replay["selected_prediction"]==result["selected_prediction"]
    assert counts["fit"]==counts["audit"]==changed
    # The whole's native boundary carries the original models and source
    # audit bytes. Reopen without the execution tree or its reuse markers.
    payload={name:root/name for name in {"final-numbers.zip",*members,*f5._f45_primary_final_reuse_members(root)}}
    archive=tmp_path/"whole-final-boundary.zip"
    write_deterministic_zip(archive,payload,stored_members=set(payload))
    consumer=tmp_path/"archive-consumer"
    consumer.mkdir()
    for name,raw in read_safe_zip(archive).items():
        path=consumer/name
        path.parent.mkdir(parents=True,exist_ok=True)
        path.write_bytes(raw)
    shutil.copytree(root/"request",consumer/"request")
    reopened=f4_compact.read_o_fit_final_numbers(consumer/"final-numbers.zip",request=request,
        request_root=consumer/"request",lock=lock,native_members=members)
    assert reopened==replay
    assert counts["fit"]==counts["audit"]==changed


def test_primary_reuse_interruption_and_source_or_native_tampering(tmp_path,monkeypatch):
    (request,root,lock,scores,entries),candidate,counts,original,old=fixture(tmp_path,monkeypatch)
    retain=f5._f45_retain_final_object
    def interrupted(*args,**kwargs):
        raise OSError("UNFITTED interruption before pinned model publication")
    with monkeypatch.context() as fail:
        fail.setattr(f5,"_f45_retain_final_object",interrupted)
        with pytest.raises(OSError,match="interruption"):
            f4._o_fit_post_lock_m20(request,scores,root,workers=2,replay=False,completed_final_units=[candidate])
    assert len(list((root/"fits").glob("*.reuse.json")))==1
    assert not list((root/"fits").glob("*.zip"))
    assert counts=={"fit":0,"audit":0,"pools":[]}
    result=f4._o_fit_post_lock_m20(request,scores,root,workers=2,replay=False,completed_final_units=[candidate])
    assert result["new_model_fits"]==0 and result["reused_final_model_count"]==20
    binding=f5.strict_json_bytes((root/"fits/M01.reuse.json").read_bytes())
    native=root/"fits/M01.zip"
    with monkeypatch.context() as fail:
        fail.setattr(f5,"_f45_score_reuse_authorities",lambda:({},{"a"*64:{}}))
        with pytest.raises(ContractError,match="SOURCE"):
            f5._f45_primary_final_reuse_read(request,lock,root,entries[0],binding,native)
    wrong=copy.deepcopy(binding)
    wrong["source"]["sha256"]="0"*64
    with pytest.raises(ContractError,match="SOURCE"):
        f5._f45_primary_final_reuse_read(request,lock,root,entries[0],wrong,native)
    original_raw=native.read_bytes()
    native.write_bytes(original_raw+b"UNFITTED_TAMPER")
    with pytest.raises(ContractError,match="NATIVE_OBJECT_DRIFT"):
        f5._f45_primary_final_reuse_read(request,lock,root,entries[0],binding,native)
    native.write_bytes(original_raw)
    assert encode(f5.strict_json_bytes(read_safe_zip(old/"final-numbers.zip")["final.json"])["components"])==original
    assert counts=={"fit":0,"audit":0,"pools":[]}
