"""Synthetic original prepare lifecycle; no clinical MICE or predictive fits."""
import copy
from pathlib import Path
import sys

import pytest

from padml import f4, f5, f5_sensitivity as sensitivity, runtime
from padml.bundle import ContractError, canonical_json_bytes, sha256_file, strict_json_bytes
from test_nested_aar_mice import unfitted_selector_shard_inputs  # noqa: F401


def test_original_prepare_cli_releases_only_completed_inputs_and_reads_its_report(
        unfitted_selector_shard_inputs, tmp_path, monkeypatch, capsys):
    prepared = unfitted_selector_shard_inputs
    source = tmp_path / "UNFITTED-gather.zip"
    source.write_bytes(b"UNFITTED: materialization is independently tested")
    projected = tmp_path / "projected.zip"
    target = tmp_path / "selector"
    source_hash = sha256_file(source)
    current = f4._f45_source_member_sha256()
    executor = sensitivity.sha256_bytes(canonical_json_bytes(current))
    events, persistent = [], {}

    def materialize(_source, _lineage, directory, *, input_bundle, execution_scratch_reserve_bytes):
        assert _source == source and input_bundle == projected
        assert type(execution_scratch_reserve_bytes) is int and execution_scratch_reserve_bytes == 0
        directory.mkdir()
        # Stand-ins only for the completed reader's private expansions. Actual
        # training-only projection, recipe/path preparation and CLI stay live.
        (directory / "reader-complete.json").write_bytes(canonical_json_bytes({"UNFITTED": True}))
        events.append("materialized")
        return prepared

    original_selector = f5._nested_selector_program
    def selector(*args, **kwargs):
        result = original_selector(*args, **kwargs)
        assert result["status"] == "PREPARED_SELECTOR_INPUTS"
        events.append("selector_completed")
        persistent.update({path: sha256_file(path) for path in target.rglob("*") if path.is_file()})
        return result

    original_release = runtime.release_step_resources
    def release(files, **kwargs):
        assert "selector_completed" in events
        assert files and all(target not in path.parents and path not in {source, projected} for path in files)
        assert all(path.stat().st_nlink == 1 for path in files)
        value = original_release(files, **kwargs)
        events.append(kwargs["owner"].split(":")[0])
        return value

    monkeypatch.setattr(sensitivity, "materialize_a12_outer_inputs", materialize)
    monkeypatch.setattr(f5, "_nested_selector_program", selector)
    monkeypatch.setattr(runtime, "release_step_resources", release)
    monkeypatch.setattr(sys, "argv", ["padml-f5", "a12-outer", str(source), str(target),
        "--input-bundle", str(projected), "--selector-only", "--prepare-only"])
    f5.main()
    raw = capsys.readouterr().out.encode()
    result = strict_json_bytes(raw)
    assert result["status"] == "PREPARED_SELECTOR_INPUTS" and len(result["task_ids"]) == 320
    assert events == ["materialized", "selector_completed", "AAR_SELECTOR_PREPARE_INPUTS", "AAR_SELECTOR_PREPARE_SOURCE"]
    assert persistent and all(path.is_file() and sha256_file(path) == digest for path, digest in persistent.items())
    assert sha256_file(target / "partitions.json") == result["partition_inputs_sha256"]
    assert not any((target / name).exists() for name in ("coarse", "fine", "selector.json", "development-input.json"))
    assert not list(tmp_path.glob("a12-selector-inputs-*")) and not list(tmp_path.glob("a12-selector-source-*"))
    assert sha256_file(source) == source_hash and f4._f45_source_member_sha256() == current

    def consume(value, **kwargs):
        return sensitivity._validate_a12_selector_prepare_execution(value,
            input_source=prepared["source"], source_sha256=source_hash,
            executor_source_identity=kwargs.get("executor", executor))
    consume(result)
    report = result["execution_report"]
    assert set(report["resource_release"]) == {"selector_inputs", "materialized_inputs"}
    for row in report["resource_release"].values():
        runtime.validate_resource_release(row["resource_release"])
        assert not Path(row["temporary_root"]).exists()
        assert row["resource_release"]["claim"] == "ADVISORY_ONLY_NONATOMIC_OBSERVATIONS_NOT_ATTRIBUTION"

    missing = copy.deepcopy(result)
    del missing["execution_report"]
    with pytest.raises(ContractError, match="F5_A12_SELECTOR_PREPARE_EXECUTION_INVALID"):
        consume(missing)
    for changed in ("owner", "pending_file", "missing_release", "admission_bool", "input_identity", "source"):
        bad = copy.deepcopy(result)
        execution = bad["execution_report"]
        if changed == "owner":
            execution["resource_release"]["selector_inputs"]["resource_release"]["owner"] = "AAR_SELECTOR_PREPARE_INPUTS:2:wrong"
        elif changed == "pending_file":
            execution["resource_release"]["selector_inputs"]["resource_release"]["files"][0]["path"] = str(target / "partitions.json")
        elif changed == "missing_release":
            del execution["resource_release"]["selector_inputs"]
        elif changed == "admission_bool":
            execution["after_release"]["resource_admission"]["admitted_worker_ceiling"] = True
        elif changed == "input_identity":
            execution["projected_input_identity_sha256"] = "f" * 64
        else:
            execution["source_identity"] = "f" * 64
        with pytest.raises(ContractError, match="F5_A12_SELECTOR_PREPARE_EXECUTION_INVALID"):
            consume(bad)
    oversized = {**result, "UNFITTED_padding": "x" * (32 * 1024**2 + 1)}
    with pytest.raises(ContractError, match="F5_A12_SELECTOR_PREPARE_EXECUTION_INVALID"):
        consume(oversized)
    del oversized

    # A failed release is not a successful prepare; the existing exception
    # evidence paths, persistent recipes and both input works remain available.
    original_observe = runtime.observe_execution_resources
    for failure in ("inner_release", "outer_release", "post_admission"):
        previous = set(tmp_path.glob("a12-selector-*-*"))
        releases = []
        def denied(files, **kwargs):
            releases.append(kwargs["owner"])
            if len(releases) == {"inner_release": 1, "outer_release": 2}.get(failure):
                raise ContractError("UNFITTED_RELEASE_FAILURE")
            return original_release(files, **kwargs)
        def shortfall(directory):
            observation = original_observe(directory)
            if failure == "post_admission" and len(releases) == 2:
                observation["available_memory_bytes"] = 1
            return observation
        failed_target = tmp_path / ("failed-selector-" + failure)
        with monkeypatch.context() as failed:
            failed.setattr(runtime, "release_step_resources", denied)
            failed.setattr(runtime, "observe_execution_resources", shortfall)
            reason = "RESOURCE_ADMISSION_ZERO" if failure == "post_admission" else "UNFITTED_RELEASE_FAILURE"
            with pytest.raises(ContractError, match=reason) as raised:
                sensitivity.execute_a12_outer_bundle(source, failed_target,
                    input_bundle=projected, selector_only=True, prepare_only=True)
        assert any("F5_A12_SELECTOR_INPUT_EVIDENCE:" in value for value in raised.value.__notes__)
        retained = set(tmp_path.glob("a12-selector-*-*")) - previous
        assert len(retained) == 2
        assert any(path.name.startswith("a12-selector-inputs-") for path in retained)
        assert any(path.name.startswith("a12-selector-source-") for path in retained)
        assert (failed_target / "partitions.json").is_file()
    assert sha256_file(source) == source_hash
