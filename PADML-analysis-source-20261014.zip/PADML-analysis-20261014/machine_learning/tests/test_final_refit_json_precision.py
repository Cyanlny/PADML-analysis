"""Exercise the fit, replay and audit writers without any fit or replay."""
import json
import math
import os
import subprocess
from pathlib import Path

import pytest

from padml import f5
from padml.bundle import ContractError
from padml.f2_validation import _fpm_piece_arithmetic
from padml.runtime import R_LIBRARY, RSCRIPT_EXECUTABLE, THREAD_ENV


def test_final_refit_and_replay_writers_preserve_binary64(tmp_path):
    kernel = Path(__file__).resolve().parents[1] / "padml/kernels/f5_final_refit.R"
    audit = tmp_path / "retained-object-audit.R"
    audit.write_text(f5._R_RETAINED_OBJECT_AUDIT)
    script = r'''
    suppressPackageStartupMessages(library(jsonlite))
    writers <- list()
    visit <- function(value) {
      if (missing(value)) return(invisible(NULL))
      if (is.call(value)) {
        if (identical(value[[1L]], as.name("toJSON")) &&
            identical(value[[2L]], as.name("result"))) {
          writers[[length(writers) + 1L]] <<- value
        }
        for (child in as.list(value)[-1L]) visit(child)
      } else if (is.expression(value) || is.list(value)) {
        for (child in value) visit(child)
      }
    }
    visit(parse(commandArgs(TRUE)[[1L]]))
    stopifnot(length(writers) == 2L)
    visit(parse(commandArgs(TRUE)[[2L]]))
    stopifnot(length(writers) == 3L)
    result <- list(
      positive = as.list(c(1 + 2^-52, -1)),
      negative = as.list(c(1 - 2^-52, -1)),
      matrix = list(as.list(c(1, 1)), as.list(c(0, 0)), as.list(c(0, 0))),
      adjacent_probabilities = as.list(c(0.5, 0.5 + 2^-53)),
      optimizer_rounds = 3L, native_feasible = TRUE,
      missing = NULL, label = "synthetic-only",
      selected_parents = list("AST_ALT"), design_columns = list("AST_ALT"),
      alpha = 0.3, ratio = 0.5 + 2^-53, lambda = 0.2 + 2^-54,
      coefficient_ids = list("AST_ALT"), coefficient_scale = list(2),
      raw_coefficients = list(0.125), standardized_coefficients = list(0.25)
    )
    for (writer in writers) cat(as.character(eval(writer)), "\n", sep = "")
    '''
    completed = subprocess.run(
        [RSCRIPT_EXECUTABLE, "--vanilla", "-e", script, str(kernel), str(audit)],
        env={**os.environ, **THREAD_ENV, "R_LIBS_USER": R_LIBRARY},
        text=True, capture_output=True, check=False, timeout=30,
    )
    assert completed.returncode == 0, completed.stderr
    rows = [json.loads(line) for line in completed.stdout.splitlines()]
    assert len(rows) == 3
    for value in rows:
        assert value["positive"] == [1 + 2**-52, -1]
        assert value["negative"] == [1 - 2**-52, -1]
        assert value["adjacent_probabilities"] == [0.5, 0.5 + 2**-53]
        assert _fpm_piece_arithmetic(value["matrix"], value["positive"])["minimum"] == 2**-52
        assert _fpm_piece_arithmetic(value["matrix"], value["negative"])["minimum"] == -(2**-52)
        assert type(value["optimizer_rounds"]) is int and value["optimizer_rounds"] == 3
        assert value["native_feasible"] is True and value["missing"] is None
        assert value["label"] == "synthetic-only"
        health = {"alpha": .3, "ratio": .5 + 2**-53, "lambda": .2 + 2**-54}
        task = {"selected_parents": ["AST_ALT"], "family_design_column_count": 1, "row_count": 100}
        assert f5._validate_retained_r_audit_numbers("ELASTIC_NET_COX", value, health, task) == value
        for field in health:
            changed = {**health, field: math.nextafter(health[field], math.inf)}
            with pytest.raises(ContractError, match="F5_FINAL_REFIT_RETAINED_OBJECT_HEALTH_DRIFT"):
                f5._validate_retained_r_audit_numbers("ELASTIC_NET_COX", value, changed, task)
