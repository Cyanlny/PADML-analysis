"""Original A12 raw/native boundaries; synthetic data and UNFITTED mids only."""
import copy
import csv
import io
import json
import os
import shutil
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path
from types import SimpleNamespace

import pytest

from padml import f4, f5, f5_sensitivity as sensitivity, nested_loco as nested, runtime
from padml.bundle import ContractError, canonical_json_bytes, sha256_bytes, sha256_file, strict_json_bytes, write_deterministic_zip
from padml.f1_kernel import compile_binding_contract
from test_f5 import fake_mice_run, native_mice_fixture
from test_nested_full_development import (
    _unfitted_confirmed_decision, _unfitted_selector_path_values, _write_unfitted_selector_native,
    _selector_shard_engines, _exercise_selector_shards,
)
from test_nested_loco import _lock, _scores


@pytest.fixture
def aar_source(monkeypatch):
    monkeypatch.setattr(runtime, "effective_cpu_count", lambda: 64)
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda root: {
        "effective_cpus": 64, "available_memory_bytes": 10**10,
        "scratch_available_bytes": 10**10, "scratch_root": str(root)})
    _, covariates, response = native_mice_fixture()
    contract = compile_binding_contract(covariates, response, workbook_sha256="a" * 64,
                                        enforce_formal_denominator=False)
    outer = next(row for row in contract["registry"]["outer"] if row["outer_fold"] == 1)
    centers = {row["Patient_ID"]: row["Center"] for row in csv.DictReader(io.StringIO(covariates.decode()))}
    fields, responses = f5._response_rows(response)
    training = f5._write_response_subset(fields, responses, outer["analysis_ids"], None)["private_bytes"]
    context = nested.compile_training_context(scope="OUTER", outer_fold=1, heldout_center=36,
        training_ids=outer["analysis_ids"], heldout_ids=outer["validation_ids"], centers_by_patient=centers,
        training_response_csv=training, mice_member_set_sha256="b" * 64,
        preprocessing_program_sha256="c" * 64, modeling_program_sha256=nested._sha(f4._f45_source_member_sha256()),
        seed_program_sha256="d" * 64)
    lock, _ = _lock(context, _scores(context, {
        family: .01 if family == "GBM_COX" else .2 for family in nested._families()}))
    source = {"program_id": nested.PROGRAM_ID, "primary_training_context": context,
              "primary_development_lock": lock, "science_decision": nested.science_decision_template(24)}
    policy = {"configured_worker_ceiling": "EXECUTION_HOST_C_MINUS_8", "memory_bytes_per_worker": 1,
              "scratch_bytes_per_worker": 1, "memory_reserve_bytes": 0, "scratch_reserve_bytes": 0,
              "transfer_archive_worker_ceiling": 1000}
    return contract, covariates, response, source, policy


@pytest.mark.parametrize("damage", ["none", "different_valid_decision", "missing_binding", "different_valid_budget", "boolean_budget"])
def test_nested_aar_consumer_requires_primary_lock_from_same_confirmed_batch(aar_source, damage):
    source = copy.deepcopy(aar_source[3])
    science = _unfitted_confirmed_decision(fixed_bootstrap=True)
    source["science_decision"] = science
    source["estimand"] = nested.A12_TOTAL_AAR
    lock = source["primary_development_lock"]
    lock["science_decision_binding"] = nested._outer_science_decision_binding(science)
    if damage == "different_valid_decision":
        source["science_decision"] = _unfitted_confirmed_decision(fresh_seven=True)
    elif damage == "missing_binding":
        del lock["science_decision_binding"]
    elif damage == "different_valid_budget":
        lock["science_decision_binding"] = nested._outer_science_decision_binding(_unfitted_confirmed_decision())
    elif damage == "boolean_budget":
        lock["science_decision_binding"]["per_outer_fit_budget"]["stop_fits"] = False
    source["primary_development_lock"] = nested._sealed({key: value for key, value in lock.items() if key != "identity_sha256"})
    if damage == "none":
        assert sensitivity._a12_nested_mice_source(source) == source["primary_training_context"]
    else:
        with pytest.raises(ContractError, match="NESTED_DEVELOPMENT_LOCK_(SCIENCE_DECISION_MISMATCH|BUDGET_DRIFT)"):
            sensitivity._a12_nested_mice_source(source)


def _projected_outer_fixture(aar_source, tmp_path, monkeypatch, family):
    """Original layout/identity code, with explicit UNFITTED primary/F1 leaves."""
    from padml import f2_kernel
    from test_f5 import _full_test_transform_recipe
    contract, covariates, response, primary_source, policy = aar_source
    context = primary_source["primary_training_context"]
    lock, _ = _lock(context, _scores(context, {name: .01 if name == family else .2 for name in nested._families()}))
    fields, responses = f5._response_rows(response)
    reader = csv.DictReader(io.StringIO(covariates.decode()))
    columns = reader.fieldnames
    source_rows = {row["Patient_ID"]: {name: value or "100" for name, value in row.items()} for row in reader}
    predictors = f2_kernel.predictor_contract(Path(f5.__file__).parent)
    partitions, recipes = [], []
    matrix_root = tmp_path / "UNFITTED-F1-matrices"
    matrix_root.mkdir()
    for registry_name, kind in (("outer", "OUTER"), ("inner", "INNER"), ("stopping", "STOP")):
        for definition in [row for row in contract["registry"][registry_name] if row["outer_fold"] == 1]:
            partition_id, fit_ids = definition["partition_id"], definition["analysis_ids"]
            application_ids = definition["application_ids"]
            evaluation_ids = definition["stop_ids" if kind == "STOP" else "validation_ids"]
            root = matrix_root / partition_id
            root.mkdir()
            stream = io.StringIO(newline="")
            writer = csv.DictWriter(stream, fieldnames=columns, lineterminator="\n")
            writer.writeheader()
            writer.writerows(source_rows[patient] for patient in application_ids)
            raw = stream.getvalue().encode()
            (root / "imp01.csv").write_bytes(raw)
            for imp in range(2, 21):
                (root / f"imp{imp:02d}.csv").hardlink_to(root / "imp01.csv")
            members = [{"name": f"imp{imp:02d}.csv", "sha256": sha256_bytes(raw), "size_bytes": len(raw)} for imp in range(1, 21)]
            binding = {"schema_version": "1.0.0", "kind": "PADML_F2_REGISTERED_VIEW_BINDING", "status": "PASS",
                "partition_id": partition_id, "analysis_view_sha256": nested._sha({"UNFITTED_ANALYSIS": partition_id}),
                "application_view_sha256": nested._sha({"UNFITTED_APPLICATION": partition_id}),
                "analysis_ids_sha256": nested._sha(fit_ids), "application_ids_sha256": nested._sha(application_ids),
                "input_dir": str(root), "members": members, "data_identity": nested._sha(members)}
            partition = {"kind": kind, "partition_id": partition_id, "repeat": definition.get("repeat", 0),
                "inner_fold": definition.get("inner_fold", 0), "fit_ids": fit_ids, "evaluation_ids": evaluation_ids,
                "application_ids": application_ids, "covariates": binding,
                "evaluation_ids_sha256": nested._sha(evaluation_ids),
                "fit_response": f5._write_response_subset(fields, responses, fit_ids, root / "fit-response.csv"),
                "evaluation_response": f5._write_response_subset(fields, responses, evaluation_ids, None),
                "fit_covariate_members": f2_kernel._fit_covariate_member_records(binding, fit_ids),
                **({"consumer_set": list(definition["consumers"])} if kind == "STOP" else {})}
            partitions.append(partition)
            if kind != "STOP":
                recipe = _full_test_transform_recipe(predictors)
                recipe.update(partition_id=partition_id, analysis_view_sha256=binding["analysis_view_sha256"],
                    analysis_ids_sha256=nested._sha(fit_ids), fit_ids_sha256=nested._sha(fit_ids),
                    training_member_set_sha256=nested._sha(partition["fit_covariate_members"]))
                recipe["recipe_sha256"] = nested._sha({key: value for key, value in recipe.items() if key != "recipe_sha256"})
                recipes.append(recipe)
    design_df = sum(len(row["columns"]) for row in f2_kernel._expected_family_parent_column_map(
        lock["selected_parents"], "ELASTIC_NET_COX", predictors, recipes[0]))
    lock.update(common_set_design_df=design_df, common_set_epv=context["training_event_count"] / design_df)
    lock = nested._sealed({key: value for key, value in lock.items() if key != "identity_sha256"})
    recipe_set = {"recipe_schema_version": "1.0.0", "kind": "PADML_F2_TRANSFORM_RECIPE_SET", "recipe_count": 16, "recipes": recipes}
    recipe_set["recipe_set_sha256"] = nested._sha(recipe_set)
    model = {"family": family, "fold": 1, "status": "PASS", "selector_evidence_sha256": lock["selector_evidence_sha256"],
        "selector_evidence": {"selected_parents": lock["selected_parents"], "recipe_set": recipe_set,
            "common_set_design_df": design_df, "outer_training_event_count": context["training_event_count"]},
        "model_input": {"model_partitions": [f2_kernel._registered_partition_identity_record(row) for row in partitions]}}
    frozen = {"registry": contract["registry"], "models": {(1, family): model}, "response_csv": response,
              "covariates_csv": covariates, "binding_contract": contract}
    primary_input, primary_archive = tmp_path / "UNFITTED-primary-input.zip", tmp_path / "UNFITTED-primary.zip"
    request = {"training_context": context, "science_decision": primary_source["science_decision"], "identity_sha256": "a" * 64}
    write_deterministic_zip(primary_input, {"o-fit-input.json": canonical_json_bytes(request)})
    write_deterministic_zip(primary_archive, {"UNFITTED_PRIMARY_READER_STUB.json": b"{}"})
    calls = []
    def primary_reader(*args, **kwargs):
        calls.append("ORIGINAL_F4_PRIMARY_NATIVE_READER_STUB")
        if "accepted_source_reader" in kwargs:
            snapshot = kwargs["accepted_source_reader"](admit_io=lambda **options: None)
            assert snapshot["o_fit_source"] is frozen
        if "on_materialized_fold" in kwargs:
            kwargs["on_materialized_fold"](frozen, 1, materialize(frozen, 1, None))
        return {"kind": "PADML_F4_O_FIT_EXECUTION_ARCHIVE_V3", "outer_fold": 1, "family": family,
            "input_identity_sha256": request["identity_sha256"], "science_decision_sha256": request["science_decision"]["identity_sha256"],
            "development_lock": lock, "input_archive": {"sha256": sha256_file(primary_input),
                                                         "size_bytes": primary_input.stat().st_size}}
    def materialize(*args, **kwargs):
        calls.append("ORIGINAL_F1_M20_READER_STUB")
        assert args[0] == frozen and args[1] == 1
        return {"partitions": partitions}
    def accepted_source(*args, **kwargs):
        calls.append("ORIGINAL_ACCEPTED_F4_SOURCE_READER_STUB")
        assert callable(kwargs["admit_io"])
        return {"o_fit_source": frozen}
    monkeypatch.setattr(f4, "load_o_fit_execution_archive", primary_reader)
    monkeypatch.setattr(f4, "_load_o_fit_execution_archive", primary_reader)
    monkeypatch.setattr(f4, "load_f4_inputs", accepted_source)
    monkeypatch.setattr(f4, "_materialize_o_fit_fold", materialize)
    monkeypatch.setattr(sensitivity, "_a12_context", lambda *args, **kwargs: pytest.fail("NO_GLOBAL_FAMILY_HANDOFF"))
    monkeypatch.setattr(sensitivity.subprocess, "run", lambda *args, **kwargs: pytest.fail("NO_NATIVE_COMPUTE_AUTHORIZED"))
    return primary_input, primary_archive, policy, calls, frozen, lock


@pytest.mark.parametrize("family", ["GBM_COX", "XGBOOST_COX", "COXTIME_SET_A"])
def test_original_outer_compiler_fresh7_consumes_accepted_stop_lock_without_new_stop(aar_source, tmp_path, monkeypatch, family):
    _, _, _, _, frozen, _ = _projected_outer_fixture(aar_source, tmp_path, monkeypatch, family)
    fields = {"GBM_COX": "selected_trees", "XGBOOST_COX": "selected_rounds", "COXTIME_SET_A": "locked_epoch"}
    if family == "GBM_COX":
        spec = {"family": family, "selected_trees": 20, "parameters": {
            "interaction.depth": 2, "shrinkage": .05, "n.minobsinnode": 20, "bag.fraction": .8,
            "n.trees.max": 5000, "early_stopping_metric": "cox_deviance",
            "post_selection_refit": "full_main_training_at_selected_n_trees",
            "locked_iteration_mode": "full_main_training_without_reselection"}}
    elif family == "XGBOOST_COX":
        spec = {"family": family, "selected_rounds": 5, "parameters": {
            "eta": .05, "max_depth": 2, "min_child_weight": 2., "subsample": .8, "colsample_bytree": .8,
            "reg_lambda": 1., "reg_alpha": 0., "gamma": 0., "tree_method": "hist", "max_bin": 256,
            "max_nrounds": 20, "stop_scope": "training_only",
            "post_selection_refit": "full_main_training_at_best_rounds",
            "locked_iteration_mode": "full_main_training_without_reselection"}}
    else:
        candidate = f5.load_science_authority()["science"]["f2_model_development"]["coxtime"]["candidates"][0]
        spec = {"family": family, "candidate_id": candidate["candidate_id"], "parameters": candidate, "locked_epoch": 30}
    model = frozen["models"][1, family]
    model.update(selected_spec=spec, selected_spec_sha256=nested._sha(spec))
    frozen["centers"] = {row["Patient_ID"]: row["Center"]
                         for row in csv.DictReader(io.StringIO(frozen["covariates_csv"].decode()))}
    registered = f4._materialize_o_fit_fold(frozen, 1, tmp_path / "not-materialized-by-stub")
    part = f4._o_fit_partitions(registered)["INNER", 1, 1]
    monkeypatch.setattr(f4, "_replay_f4_stop_batch", lambda *args, **kwargs: pytest.fail("NO_NEW_OR_REPLAYED_STOP"))
    monkeypatch.setattr(f4, "_execute_f4_model_component", lambda *args, **kwargs: pytest.fail("NO_SCIENTIFIC_FIT"))
    if family in {"GBM_COX", "XGBOOST_COX"}:
        with pytest.raises(ContractError, match="F4_O_FIT_SPLIT_STOP_REQUIRED"):
            f4._prepare_o_fit_partition(model, part, frozen)
    with pytest.raises(ContractError, match="F4_O_FIT_LOCKED_SCORE_SCOPE_INVALID"):
        f4._prepare_o_fit_partition(model, part, frozen, locked_scoring_decision=_unfitted_confirmed_decision())
    decision = _unfitted_confirmed_decision(fixed_bootstrap=True)
    jobs = f4._prepare_o_fit_partition(model, part, frozen, locked_scoring_decision=decision)
    assert len(jobs) == 20
    frozen["model_payload_sizes"] = {(1, family): len(canonical_json_bytes(model))}
    reservations = []
    bounded = f4._prepare_o_fit_partition(model, part, frozen, locked_scoring_decision=decision,
                                          admit_io=lambda **value: reservations.append(value))
    assert bounded == jobs and len(reservations) == 2
    assert reservations[-1]["memory_bytes"] >= 32 * sum(
        len(raw) for job in jobs for raw in job["entries"].values())
    def deny_m20(**value):
        reservations.append(value)
        if len(reservations) == 2:
            raise ContractError("UNFITTED_M20_MEMORY_SHORTFALL")
    original_read = Path.read_bytes
    def bounded_read(path):
        assert not (path.name.startswith("imp") and path.suffix == ".csv"), "M20 CSV read preceded admission"
        return original_read(path)
    with monkeypatch.context() as bounds:
        reservations.clear()
        bounds.setattr(Path, "read_bytes", bounded_read)
        with pytest.raises(ContractError, match="UNFITTED_M20_MEMORY_SHORTFALL"):
            f4._prepare_o_fit_partition(model, part, frozen, locked_scoring_decision=decision, admit_io=deny_m20)
    for imp, job in enumerate(jobs, 1):
        entries = job["entries"]
        task = strict_json_bytes(entries["task.json"])
        assert task["imputation"] == imp and task["parameters"] == spec
        assert task["parameters"][fields[family]] == spec[fields[family]]
        assert "stop-response.csv" not in entries and "stop_parameters" not in task
        assert task["registered_model_seed"] == 300000 + 1000 + 50000 + 100 * imp + 1
        path = tmp_path / f"score-{family}-M{imp:02d}.zip"
        nested._write_component_archive(path, entries)
        contract = nested._validate_outer_component(path, role="FRESH_SCORE", family=family,
            context=aar_source[3]["primary_training_context"])
        assert contract["development_spec_sha256"] == nested._sha(spec)
    drifted = copy.deepcopy(model)
    drifted["selected_spec"][fields[family]] += 1
    drifted["selected_spec_sha256"] = nested._sha(drifted["selected_spec"])
    with pytest.raises(ContractError, match="F4_O_FIT_ACCEPTED_MODEL_REQUIRED"):
        f4._prepare_o_fit_partition(drifted, part, frozen, locked_scoring_decision=decision)


@pytest.fixture
def unfitted_redevelopment_inputs(aar_source, tmp_path, monkeypatch, request):
    """Synthetic completed matrices, not a replacement for the MICE round trip."""
    from padml import f2_kernel
    family = getattr(request, "param", "COX_PH")
    primary_input, primary_archive, policy, _, frozen, _ = _projected_outer_fixture(
        aar_source, tmp_path, monkeypatch, family)
    source = tmp_path / "projected.zip"
    sensitivity.compile_a12_outer_inputs(primary_input, primary_archive, source,
        f2_run_root=tmp_path, outer_fold=1, resource_policy=policy)
    source_record = strict_json_bytes(sensitivity.read_safe_zip(source)["a12-inputs.json"])
    parts = f4._materialize_o_fit_fold(frozen, 1, tmp_path)["partitions"]
    root = tmp_path / "UNFITTED-no-aar-matrices"
    root.mkdir()
    projected = []
    for part in parts:
        if part["partition_id"] not in {row["partition_id"] for row in source_record["definitions"]}:
            continue
        part = copy.deepcopy(part)
        directory = root / part["partition_id"]
        directory.mkdir()
        original = Path(part["covariates"]["input_dir"]) / "imp01.csv"
        rows = list(csv.DictReader(io.StringIO(original.read_text())))
        columns = [name for name in rows[0] if name not in {"AST", "ALT", "AST_ALT"}]
        stream = io.StringIO(newline="")
        writer = csv.DictWriter(stream, fieldnames=columns, lineterminator="\n")
        writer.writeheader()
        writer.writerows({key: row[key] for key in columns} for row in rows)
        raw = stream.getvalue().encode()
        (directory / "imp01.csv").write_bytes(raw)
        for imp in range(2, 21):
            (directory / f"imp{imp:02d}.csv").hardlink_to(directory / "imp01.csv")
        members = [{"name": f"imp{imp:02d}.csv", "sha256": sha256_bytes(raw), "size_bytes": len(raw)} for imp in range(1, 21)]
        part["covariates"].update(input_dir=str(directory), members=members, data_identity=nested._sha(members))
        part["fit_covariate_members"] = f2_kernel._fit_covariate_member_records(part["covariates"], part["fit_ids"])
        if part["kind"] == "OUTER":
            part.pop("evaluation_response")
        projected.append(part)
    branches = {}
    for estimand in nested.AAR_ESTIMANDS:
        is_direct, is_rd = estimand == nested.A12_DIRECT_AAR, estimand == nested.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT
        partitions = copy.deepcopy([part for part in (parts if is_direct else projected)
            if is_rd or part["partition_id"] in source_record["direct_partitions"]])
        for part in partitions:
            if part["kind"] == "OUTER":
                part.pop("evaluation_response", None)
            if not is_direct:
                part["covariates"]["analysis_view_sha256"] = nested._sha({"UNFITTED_VIEW": estimand, "partition": part["partition_id"]})
                part["covariates"]["application_view_sha256"] = nested._sha({"UNFITTED_APPLICATION": estimand, "partition": part["partition_id"]})
        branches[estimand] = {"kind": "PADML_F5_A12_REGISTERED_INPUTS", "fold": 1, "branch": estimand,
            "estimand_contract": nested.aar_estimand_contract(estimand),
            "selected_parents": None if is_rd else source_record["fixed_selected_parents"],
            "status": "MICE_MATERIALIZED_PRE_DEVELOPMENT", "partitions": partitions,
            "inner_count": sum(p["kind"] == "INNER" for p in partitions), "outer_count": 1,
            "stop_count": sum(p["kind"] == "STOP" for p in partitions),
            "identity": nested._sha([f2_kernel._registered_partition_identity_record(p, prediction_only=p["kind"] == "OUTER")
                                    for p in partitions])}
    return {"source": source_record, "family": family, "outer_fold": 1, "branches": branches}


def test_redevelopment_projects_actual_outer_training_m20_before_original_selector(unfitted_redevelopment_inputs, tmp_path):
    prepared = unfitted_redevelopment_inputs
    source, parts = sensitivity._a12_no_aar_selector_inputs(prepared, tmp_path / "projection")
    context = prepared["source"]["primary_source"]["primary_training_context"]
    assert len(parts) == 16 and [row["kind"] for row in parts] == ["INNER"] * 15 + ["OUTER_TRAINING"]
    assert source["source"]["inherited_family"] == "COX_PH" and source["source"]["context"] == 1
    final = parts[-1]
    assert "evaluation_response" not in final
    assert final["fit_ids"] == final["evaluation_ids"] == final["application_ids"] == context["training_ids"]
    for part in parts:
        for member in part["covariates"]["members"]:
            rows = list(csv.DictReader(io.StringIO((Path(part["covariates"]["input_dir"]) / member["name"]).read_text())))
            assert not set(context["heldout_ids"]) & {row["Patient_ID"] for row in rows}
            assert not {"AST", "ALT", "AST_ALT", "All_Cause_Death", "Death_Followup_months"} & set(rows[0])
    projected = f5._nested_full_selector_partition_records(parts)
    assert "evaluation_response" not in projected[-1]
    canonical_json_bytes(projected)  # no private response bytes remain in the transport identity


def test_redevelopment_selector_rejects_primary_seta_and_heldout_response_before_native(unfitted_redevelopment_inputs, tmp_path):
    for damage in ("primary_seta", "heldout_response", "partition_identity", "unconfirmed"):
        prepared = copy.deepcopy(unfitted_redevelopment_inputs)
        branch = prepared["branches"][nested.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT]
        if damage == "primary_seta":
            branch["selected_parents"] = ["Age"]
        elif damage == "heldout_response":
            branch["partitions"][0]["evaluation_response"] = {"FORBIDDEN": True}
        elif damage == "partition_identity":
            branch["identity"] = "d" * 64
        else:
            prepared["source"]["primary_source"]["science_decision"] = nested.science_decision_template()
        root = tmp_path / damage
        with pytest.raises(ContractError):
            sensitivity._a12_no_aar_selector_program(prepared, root, replay=False)
        assert not root.exists()  # global fixture rejects every unmocked native subprocess


def test_redevelopment_selector_rejects_self_rehashed_physical_channel(unfitted_redevelopment_inputs, tmp_path):
    from padml import f2_kernel
    prepared = copy.deepcopy(unfitted_redevelopment_inputs)
    branch = prepared["branches"][nested.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT]
    outer = branch["partitions"][0]
    path = Path(outer["covariates"]["input_dir"]) / "imp01.csv"
    rows = list(csv.DictReader(io.StringIO(path.read_text())))
    stream = io.StringIO(newline="")
    writer = csv.DictWriter(stream, fieldnames=[*rows[0], "AST_ALT"], lineterminator="\n")
    writer.writeheader()
    writer.writerows({**row, "AST_ALT": "1"} for row in rows)
    raw = stream.getvalue().encode()
    path.write_bytes(raw)  # all 20 deliberately UNFITTED fixture files are hardlinks
    members = [{"name": f"imp{i:02d}.csv", "sha256": sha256_bytes(raw), "size_bytes": len(raw)} for i in range(1, 21)]
    outer["covariates"].update(members=members, data_identity=nested._sha(members))
    outer["fit_covariate_members"] = f2_kernel._fit_covariate_member_records(outer["covariates"], outer["fit_ids"])
    branch["identity"] = nested._sha([f2_kernel._registered_partition_identity_record(p, prediction_only=p["kind"] == "OUTER")
                                      for p in branch["partitions"]])
    with pytest.raises(ContractError, match="NESTED_NO_AAR_SELECTOR_CHANNEL_OR_PATIENT_DRIFT"):
        sensitivity._a12_no_aar_selector_program(prepared, tmp_path / "invalid-channel", replay=False)
    assert not (tmp_path / "invalid-channel").exists()


@pytest.fixture
def unfitted_selector_engines(monkeypatch):
    calls = {"recipe": 0, "path": 0, "replay": 0}
    def recipe_native(args, **kwargs):
        spec = strict_json_bytes(Path(args[-1]).read_bytes())
        assert spec["action"] == "COMPILE_A12_RECIPE"
        assert all(kwargs["env"][key] == str(Path(args[-1]).parent) for key in ("TMPDIR", "TMP", "TEMP"))
        projection = spec["projection"]
        registry = projection["recipe_registry_record"]
        for member in registry["members"]:
            rows = list(csv.DictReader(io.StringIO((Path(registry["input_dir"]) / member["name"]).read_text())))
            assert [row["Patient_ID"] for row in rows] == registry["fit_ids"]
            assert not {"AST", "ALT", "AST_ALT", "All_Cause_Death", "Death_Followup_months"} & set(rows[0])
        values = []
        representations = f5.predictor_contract(Path(f5.__file__).parent)["representation_contract"]
        for row in registry["registry"]["rows"]:
            rep = row["representation"]
            parameters = ({"identity": True} if rep == "IDENTITY" else {"canonical_unit_scale": 1} if rep == "LOG1P" else
                          {"boundary_knots": [10.0, 90.0], "interior_knots": [50.0], "quantile_type": 7})
            values.append({"parent": row["parent"], "canonical_unit": row["canonical_unit"], "representation": rep,
                "design_df": representations[rep]["design_df"],
                "design_columns": [row["parent"] + suffix for suffix in representations[rep]["column_suffixes"]], "parameters": parameters})
        Path(spec["output_path"]).write_bytes(canonical_json_bytes({"partition_id": projection["partition_id"],
            "representations": values, "ordered_parent_column_map": [{"parent": row["parent"], "columns": row["design_columns"]} for row in values]}))
        calls["recipe"] += 1
        return SimpleNamespace(returncode=0)
    def path_worker(arguments, *, replay=False):
        spec, part, task, directory, _ = arguments
        assert spec["execution_scope"] == "NESTED_NO_AAR_SELECTOR_M20" and spec["fold"] == 1
        assert task["seed"] == 301000 + task["imputation"]
        from padml.f2_kernel import selector_parent_names
        assert set(task["selected_parents"]) == set(selector_parent_names()) - {"AST_ALT"}
        native = Path(directory) / task["task_id"] / "native"
        encoded = canonical_json_bytes(f4._learning_selector_native_spec(spec, part, task, native))
        assert b"evaluation_response" not in encoded
        if part["kind"] == "OUTER_TRAINING":
            assert part["fit_ids"] == part["application_ids"] == part["evaluation_ids"]
        if not replay:
            _write_unfitted_selector_native(arguments)
        calls["replay" if replay else "path"] += 1
        numbers = {**_unfitted_selector_path_values(spec, part, task),
            "native_members": [{"name": path.name, "sha256": sha256_file(path),
                "size_bytes": path.stat().st_size} for path in sorted(native.iterdir()) if path.is_file()]}
        if not replay:
            (native.parent / "path-result.json").write_bytes(canonical_json_bytes(numbers))
        return numbers
    monkeypatch.setattr(f5.subprocess, "run", recipe_native)
    monkeypatch.setattr(f4, "_run_learning_selector_path", path_worker)
    monkeypatch.setattr(f4, "_consume_learning_selector_path", lambda args: path_worker(args, replay=True))
    monkeypatch.setattr(f4, "_bounded_ordered_spawn", lambda fn, jobs, **kw: [fn(job) for job in jobs])
    return calls


@pytest.fixture
def unfitted_selector_shard_inputs(tmp_path, monkeypatch, request):
    """Same original fixture owners; three legal time groups bound BEFORE hashes.

    The first run's 192 event-time groups cost about 14 seconds per coordinate
    in the unchanged Breslow consumer. Preserve N, M20, all coordinates/grids,
    source validation and original loss arithmetic; only this synthetic input
    uses tied times. The interrupted original fixture and 22 passes remain.
    """
    original_fixture = native_mice_fixture
    def tied_fixture():
        plan, covariates, response = original_fixture()
        reader = csv.DictReader(io.StringIO(response.decode()))
        rows = list(reader)
        stream = io.StringIO(newline="")
        writer = csv.DictWriter(stream, fieldnames=reader.fieldnames, lineterminator="\n")
        writer.writeheader()
        for index, row in enumerate(rows):
            writer.writerow({**row, "Death_Followup_months": str((12, 24, 50)[(index // 3) % 3])})
        return plan, covariates, stream.getvalue().encode()
    with monkeypatch.context() as fixture_input:
        fixture_input.setattr(sys.modules[__name__], "native_mice_fixture", tied_fixture)
        prepared = unfitted_redevelopment_inputs.__wrapped__(
            aar_source.__wrapped__(monkeypatch), tmp_path, monkeypatch, request)
    unfitted_selector_engines.__wrapped__(monkeypatch)
    (tmp_path / "fixture-input-scope.json").write_bytes(canonical_json_bytes({
        "synthetic_time_groups": [12, 24, 50], "original_fixture_patient_count": 420,
        "source_recompiled_before_native_execution": True, "original_loss_consumer_unchanged": True,
        "real_clinical_data": False}))
    return prepared


@pytest.mark.parametrize("retained_fine", [False, True])
def test_no_aar_selector_shards_first_audit_complete_gather_and_branch_consumer(
        unfitted_selector_shard_inputs, tmp_path, monkeypatch, retained_fine):
    prepared = unfitted_selector_shard_inputs
    counts = _selector_shard_engines(monkeypatch, f4.subprocess.run)
    policy = prepared["source"]["resource_policy"]
    source, projected = tmp_path / "UNFITTED-gather.zip", tmp_path / "UNFITTED-projected.zip"
    source.write_bytes(b"UNFITTED materializer boundary; original phase CLI owner")
    def materialize(_source, _lineage, target, *, input_bundle, execution_scratch_reserve_bytes):
        assert _source == source and input_bundle == projected
        assert type(execution_scratch_reserve_bytes) is int and execution_scratch_reserve_bytes == 0
        target.mkdir()
        (target / "reader-complete.json").write_bytes(canonical_json_bytes({"UNFITTED": True}))
        return prepared
    monkeypatch.setattr(sensitivity, "materialize_a12_outer_inputs", materialize)
    if retained_fine:
        executor = Path(os.environ["PADML_PRIMARY_RSF_COMPLETED_EXECUTOR_SOURCE"])
        members = f4._retained_full0_source_members(executor, aar_no_aar_selector=True)
        original_batch = f4._execute_full_pipeline_selector_phase_batch
        original_consume = f4._consume_full_pipeline_selector_phase_batches
        checked_missing_proof = []
        def retained_worker(calls, *args, **kwargs):
            # UNFITTED source preimage only. Keep real original spec/number,
            # first-audit, pool and release writers; do not edit their receipts.
            if Path(calls[0][3]).name == "fine":
                with monkeypatch.context() as old_executor:
                    old_executor.setattr(f4, "_f45_source_member_sha256", lambda: members)
                    return original_batch(calls, *args, **kwargs)
            return original_batch(calls, *args, **kwargs)
        def retained_consume(calls, target, **kwargs):
            # Isolate the absent clinical outer4 exception/old coarse input.
            # Public argument/role wiring is tested separately. The complete
            # fine result consumer and original downstream reducers stay real.
            if target.name == "fine":
                if not checked_missing_proof and kwargs.get("batches") is not None:
                    with pytest.raises(ContractError):
                        original_consume(calls, target, **kwargs)
                    checked_missing_proof.append(True)
                kwargs["retained_selector_executor_source_bundle"] = executor
            return original_consume(calls, target, **kwargs)
        monkeypatch.setattr(f4, "_execute_full_pipeline_selector_phase_batch", retained_worker)
        monkeypatch.setattr(f4, "_consume_full_pipeline_selector_phase_batches", retained_consume)
    gather_reports = {}
    def run(root, **kwargs):
        if kwargs.get("phase_name") is not None:
            assert kwargs.pop("replay") is False
            result = sensitivity.execute_a12_outer_bundle(source, root, input_bundle=projected,
                selector_only=True, **kwargs)
            if kwargs.get("phase_batches") is not None:
                assert result["status"] == "COMPUTED_SELECTOR_GATHER"
                report = result["execution_report"]
                assert strict_json_bytes((root / (kwargs["phase_name"] + "-gather-execution.json")).read_bytes()) == report
                sensitivity._validate_a12_selector_gather_execution(result, input_source=prepared["source"],
                    source_sha256=sha256_file(source), executor_source_identity=nested._sha(f4._f45_source_member_sha256()),
                    selector_root=root, expected_phase=kwargs["phase_name"], expected_selector_result=result["selector_result"],
                    expected_selector_source=strict_json_bytes(
                        (root / kwargs["phase_name"] / "execution.json").read_bytes())[0]["execution"]["source"],
                    expected_partitions=strict_json_bytes((root / "partitions.json").read_bytes()))
                assert all(not Path(report["input_lifecycle"][name]["temporary_root"]).exists()
                           for name in ("selector_program", "selector_inputs", "materialized_inputs"))
                if kwargs["phase_name"] == "fine":
                    assert canonical_json_bytes(result["selector_result"]) == (root / "development-input.json").read_bytes()
                    wrong = {**result, "execution_report": gather_reports["coarse"]}
                    with pytest.raises(ContractError, match="F5_A12_SELECTOR_GATHER_EXECUTION_INVALID"):
                        sensitivity._validate_a12_selector_gather_execution(wrong, input_source=prepared["source"],
                            source_sha256=sha256_file(source), executor_source_identity=report["source_identity"],
                            selector_root=root, expected_phase="fine", expected_selector_result=result["selector_result"],
                            expected_selector_source=strict_json_bytes(
                                (root / "fine/execution.json").read_bytes())[0]["execution"]["source"],
                            expected_partitions=strict_json_bytes((root / "partitions.json").read_bytes()))
                gather_reports[kwargs["phase_name"]] = report
                return result["selector_result"]
            return result
        return sensitivity._a12_no_aar_selector_program(prepared, root, **kwargs)
    result, transported = _exercise_selector_shards(run, tmp_path, policy, counts,
        monkeypatch=monkeypatch, no_aar=True)
    branch = nested.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT
    development = sensitivity._a12_projected_development_inputs(prepared, tmp_path / "branch-development",
        replay=False, branch=branch, selector_root=transported)
    assert development["branch_development"][branch]["selector_development_sha256"] == result["identity_sha256"]
    assert development["branches"][branch]["selected_parents"] == ["Sex"]
    assert counts["engine"] == counts["native"] == 640 and counts["forbid_native"]
    assert (tmp_path / "branch-development/selector/development-input.json").read_bytes() == (
        transported / "development-input.json").read_bytes()


def test_redevelopment_selector_keeps_original_recipe_path_and_replay_consumers(
        unfitted_redevelopment_inputs, tmp_path, unfitted_selector_engines, monkeypatch):
    import shutil
    prepared, calls = unfitted_redevelopment_inputs, unfitted_selector_engines
    root = tmp_path / "UNFITTED-selector"
    first = sensitivity._a12_no_aar_selector_program(prepared, root, replay=False)
    numbers = tmp_path / "numerical-selector"
    for name, path in f5._nested_selector_numerical_members(root).items():
        destination = numbers / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, destination)
    def forbidden(*args, **kwargs):
        raise AssertionError("NO_AAR_SELECTOR_NUMBERS_MUST_NOT_REFIT_OR_REPLAY_NATIVE")
    monkeypatch.setattr(f4.subprocess, "run", forbidden)
    monkeypatch.setattr(f4, "_consume_learning_selector_path", forbidden)
    monkeypatch.setattr(f4, "_run_learning_selector_path", forbidden)
    second = sensitivity._a12_no_aar_selector_program(prepared, numbers, replay=True)
    assert first == second and first["selector"]["selected_parents"] == ["Sex"]
    assert first["kind"] == "PADML_NESTED_NO_AAR_SELECTOR_DEVELOPMENT_V1" and first["outer_fold"] == 1
    assert first["family_selection_performed"] is False and first["final_model_fits"] == first["new_mice_chains"] == 0
    assert "virtual_outer" not in first and "final_full_data_recipe_sha256" not in first
    assert calls == {"recipe": 16, "path": 640, "replay": 0}
    assert not list(numbers.rglob("*.bin")) and not list(numbers.rglob("output.json"))
    assert len(list(numbers.rglob("spec.json"))) == 640
    assert first["transform_recipes"]["recipe_count"] == 16 and first["selector_path_count"] <= 4800
    assert prepared["branches"][nested.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT]["selected_parents"] is None
    # Retained recipes, not just the winning variable list, are source-bound.
    recipe_file = numbers / "recipes/recipes.json"
    raw = recipe_file.read_bytes()
    recipe_file.write_bytes(raw.replace(b'"identity":true', b'"identity":false', 1))
    before = dict(calls)
    with pytest.raises(ContractError, match="RECIPE_REPLAY_MISMATCH"):
        sensitivity._a12_no_aar_selector_program(prepared, numbers, replay=True)
    assert calls["path"] == before["path"] and calls["replay"] == before["replay"]


def test_a12_recipe_numeric_read_reuses_actual_r_values_and_rejects_source_or_value_drift(
    unfitted_redevelopment_inputs, tmp_path, monkeypatch, _native_run=subprocess.run,
):
    """Actual R recipe values on synthetic M20; no MICE or prediction fit."""
    prepared = unfitted_redevelopment_inputs
    partition, = [row for row in prepared["branches"][nested.A12_TOTAL_AAR]["partitions"] if row["kind"] == "OUTER"]
    native = tmp_path / "original-recipe"
    selected = ["Age", "Creatinine", "HGB", "Sex"]
    native_calls = []
    retained = os.environ.get("PADML_A12_RECIPE_NUMERIC_NATIVE")

    def first_recipe_only(command, **kwargs):
        spec = strict_json_bytes(Path(command[-1]).read_bytes())
        assert Path(command[1]).name == "f5_final_refit.R" and spec["action"] == "COMPILE_A12_RECIPE"
        native_calls.append(spec["action"])
        if retained:
            # Reuse only a recipe whose complete scientific projection matches;
            # the two absolute materialization paths are its only relocations.
            saved = strict_json_bytes((Path(retained) / "spec.json").read_bytes())
            current = copy.deepcopy(spec)
            for value in (saved, current):
                value.pop("output_path")
                value["projection"]["recipe_registry_record"].pop("input_dir")
            assert canonical_json_bytes(saved) == canonical_json_bytes(current)
            Path(spec["output_path"]).write_bytes((Path(retained) / "recipe.json").read_bytes())
            return subprocess.CompletedProcess(command, 0)
        return _native_run(command, **kwargs)

    with monkeypatch.context() as first_native:
        first_native.setattr(f5.subprocess, "run", first_recipe_only)
        first = f5._compile_partition_design_recipe("COX_PH", selected, partition, tmp_path,
            a12=True, native_evidence=native)
    assert native_calls == ["COMPILE_A12_RECIPE"]
    spec_raw, values_raw = [(native / name).read_bytes() for name in ("spec.json", "recipe.json")]
    relocated = tmp_path / "relocated-recipe"
    native.rename(relocated)
    projected = copy.deepcopy(partition)
    projected["covariates"]["input_dir"] = str(tmp_path / "M20_NOT_AVAILABLE_TO_RECIPE_READER")
    original_open = Path.open

    def no_tables(path, *args, **kwargs):
        assert path.suffix != ".csv" or path == Path(f5.__file__).parent / "science/variable.csv", \
            "NUMERIC_RECIPE_MUST_NOT_REOPEN_COMPLETED_TABLES"
        return original_open(path, *args, **kwargs)

    with monkeypatch.context() as numeric:
        numeric.setattr(f5.subprocess, "run", lambda *args, **kwargs: pytest.fail("NO_RECIPE_R_REPLAY"))
        numeric.setattr(f5, "_recipe_partition_projection", lambda *args, **kwargs: pytest.fail("NO_RECIPE_M20_RECOPY"))
        numeric.setattr(Path, "open", no_tables)
        for family in ("COX_PH", "ELASTIC_NET_COX", "FPM_TVC_SET_A"):
            replayed = f5._compile_partition_design_recipe(family, selected, projected, tmp_path,
                a12=True, native_evidence=relocated, replay=True)
            assert canonical_json_bytes(replayed) == canonical_json_bytes({**first, "family": family})
        damages = ("action", "fit_order", "member", "missing_mi", "mi_order", "view", "registry",
                   "knots", "columns", "partition", "channel", "missing_values", "boolean_size", "scope")
        for damage in damages:
            part = copy.deepcopy(projected)
            spec, values = strict_json_bytes(spec_raw), strict_json_bytes(values_raw)
            parents, a12 = list(selected), True
            if damage == "action":
                spec["action"] = "COMPILE_FINAL_RECIPE"
            elif damage == "fit_order":
                part["fit_ids"].reverse()
                part["covariates"]["analysis_ids_sha256"] = nested._sha(part["fit_ids"])
            elif damage == "member":
                part["fit_covariate_members"][0]["sha256"] = "e" * 64
            elif damage == "missing_mi":
                part["fit_covariate_members"].pop()
            elif damage == "mi_order":
                part["fit_covariate_members"].reverse()
            elif damage == "view":
                part["covariates"]["analysis_view_sha256"] = "d" * 64
            elif damage == "registry":
                spec["projection"]["recipe_registry_record"]["registry"]["rows"].pop()
            elif damage == "knots":
                row = next(row for row in values["representations"] if "interior_knots" in row["parameters"])
                row["parameters"]["interior_knots"][0] = row["parameters"]["boundary_knots"][-1] + 1
            elif damage == "columns":
                values["ordered_parent_column_map"][0]["columns"] = ["UNBOUND_COLUMN"]
            elif damage == "partition":
                values["partition_id"] = "ANOTHER_PARTITION"
            elif damage == "channel":
                parents.append("AST_ALT")
            elif damage == "boolean_size":
                part["fit_covariate_members"][0]["size_bytes"] = True
            elif damage == "scope":
                a12 = False
            directory = tmp_path / ("changed-" + damage)
            directory.mkdir()
            (directory / "spec.json").write_bytes(canonical_json_bytes(spec))
            if damage != "missing_values":
                (directory / "recipe.json").write_bytes(canonical_json_bytes(values))
            with pytest.raises(ContractError):
                f5._compile_partition_design_recipe("COX_PH", parents, part, tmp_path,
                    a12=a12, native_evidence=directory, replay=True)
    assert not native.exists() and (relocated / "spec.json").read_bytes() == spec_raw
    assert (relocated / "recipe.json").read_bytes() == values_raw
    (tmp_path / "recipe-readback-observation.json").write_bytes(canonical_json_bytes({
        "actual_r_recipe_calls": 0 if retained else 1, "retained_native_recipe_consumptions": 1 if retained else 0,
        "retained_native_values_sha256": sha256_bytes(values_raw),
        "native_replay_calls": 0, "new_model_fits": 0, "new_mice_chains": 0,
        "transformed_families_replayed": 3, "source_and_value_rejections": list(damages),
        "original_values_and_input_spec_unchanged": True, "completed_tables_unavailable_on_numeric_replay": True}))


@pytest.mark.parametrize("unfitted_redevelopment_inputs", nested._families(), indirect=True)
def test_three_aar_development_inputs_replay_with_own_seta_and_original_search_configuration(
        unfitted_redevelopment_inputs, unfitted_selector_engines, tmp_path, monkeypatch,
        _native_run=subprocess.run):
    prepared, calls = unfitted_redevelopment_inputs, unfitted_selector_engines
    root = tmp_path / "UNFITTED-development"
    before = sensitivity._a12_outer_input_record(prepared)
    first, partials = prepared, {}
    for index, branch in enumerate(nested.AAR_ESTIMANDS, 1):
        first = sensitivity._a12_projected_development_inputs(first, root, replay=False, branch=branch)
        partials[branch] = first
        assert set(first["branch_development"]) == set(nested.AAR_ESTIMANDS[:index])
        assert (root / "development.json").exists() == (index == 3)
        assert (root / "selector").exists() == (branch == nested.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT)
        assert calls["path"] == (640 if index == 3 else 0)
        for prior in nested.AAR_ESTIMANDS[:index]:
            assert sensitivity._a12_search_source(partials[prior], prior) == sensitivity._a12_search_source(first, prior)
            assert (root / f"{prior}.json").read_bytes() == canonical_json_bytes(first["branch_development"][prior])
        if index < 3:
            with pytest.raises(ContractError, match="BRANCH_DEVELOPMENT_OR_CPU_INVALID"):
                sensitivity._a12_outer_searches(first, root, replay=False)
            with pytest.raises(ContractError, match="BRANCH_DEVELOPMENT_REQUIRED"):
                sensitivity._a12_branch_search_inputs(first, nested.AAR_ESTIMANDS[index])
    recipe_calls = calls["recipe"]
    with monkeypatch.context() as numeric:
        numeric.setattr(f5.subprocess, "run", lambda *args, **kwargs: pytest.fail("NO_RECIPE_R_REPLAY"))
        numeric.setattr(f5, "_recipe_partition_projection", lambda *args, **kwargs: pytest.fail("NO_RECIPE_M20_RECOPY"))
        second = sensitivity._a12_projected_development_inputs(prepared, root, replay=True)
    assert calls["recipe"] == recipe_calls
    assert first["branch_development"] == second["branch_development"]
    assert first["source_input_record"] == before == sensitivity._a12_outer_input_record(prepared)
    family = first["family"]
    signatures = []
    for branch in nested.AAR_ESTIMANDS:
        view = sensitivity._a12_branch_search_inputs(first, branch)
        assert view["family"] == family and view["outer_fold"] == 1 and view["heldout_center"] == 36
        assert view["selected_parents"] == (["Sex"] if branch == nested.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT else ["Age"])
        assert view["common_set_design_df"] == 2  # original categorical expansion has Sex0 and Sex1
        assert view["branches"][branch]["status"] == "PASS"
        assert view["branches"][branch]["view_count"] == 2 * len(first["branches"][branch]["partitions"])
        assert "view_count" not in first["branches"][branch]
        assert first["branches"][branch]["status"] == "DEVELOPMENT_INPUTS_MATERIALIZED"
        for wrong_count in (view["branches"][branch]["view_count"] + 1, True,
                            float(view["branches"][branch]["view_count"])):
            wrong_views = copy.deepcopy(first)
            wrong_views["branches"][branch]["view_count"] = wrong_count
            with pytest.raises(ContractError, match="BRANCH_VIEW_COUNT_MISMATCH"):
                sensitivity._a12_branch_search_inputs(wrong_views, branch)
        unready = copy.deepcopy(first)
        unready["branches"][branch]["status"] = "MICE_MATERIALIZED_PRE_DEVELOPMENT"
        with pytest.raises(ContractError, match="BRANCH_DEVELOPMENT_MISMATCH"):
            sensitivity._a12_branch_search_inputs(unready, branch)
        source = sensitivity._a12_search_source(first, branch)
        signatures.append(source["development_input_sha256"])
        assert source["inputs_identity_sha256"] == nested._sha({**before, "branches": {branch: before["branches"][branch]}})
        assert source["source"]["primary_source"]["primary_development_lock"]["selected_family"] == family
        if family in sensitivity._A12_TUNED_FAMILIES:
            configuration = (sensitivity._a12_elastic_configuration if family == "ELASTIC_NET_COX" else
                             sensitivity._a12_complex_configuration)(first, branch, workers=3)
            spec = configuration["spec"]
            assert spec["a12_source"] == source and spec["seed"] == 301000
            assert spec["selector_from_dependency"]["selected_parents"] == view["selected_parents"]
            assert spec["heldout_center"] == 36 and spec["engine_threads"] == 1
            assert "full_pipeline_source" not in spec
            if family == "GBM_COX" and branch == nested.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT:
                from padml import f2_kernel
                # Full producer -> original single-STOP projection -> original
                # F4 GBM wrapper -> complete F2 loader. Missing synthetic input
                # deliberately stops all cases before CSV loading or any fit.
                original_input = canonical_json_bytes(sensitivity._a12_outer_input_record(first))
                full = configuration["registered"]
                assert len(full["partitions"]) == 31 and full["view_count"] == 62
                stop = next(p for p in full["partitions"] if p["kind"] == "STOP"
                            and p["repeat"] == p["inner_fold"] == 1)
                task = {"task_id": "S1_T001_P01_M01_STOP", "partition_id": stop["partition_id"],
                    "imputation": 1, "family": family, "selected_parents": view["selected_parents"],
                    "parameters": f2_kernel._engine_parameters(family, spec["candidate_trials"]["S1"][0]["parameters"]),
                    "producer_kind": "GBM_STOP_CURVE", "seed": spec["seed"] + 10_000 + 100 + 1}
                observations = []
                for damage in ("none", "missing", "projected_two"):
                    base = tmp_path / ("registered-denominator-" + damage)
                    base.mkdir(); (base / "native").mkdir(); (base / "work").mkdir()
                    projected = copy.deepcopy(f2_kernel._engine_registered_partitions(full, {stop["partition_id"]}))
                    assert projected["projected_partition_count"] == 1 and projected["view_count"] == 62
                    projected["partitions"][0]["covariates"]["input_dir"] = str(base / "intentionally-absent")
                    if damage == "missing":
                        del projected["view_count"]
                    elif damage == "projected_two":
                        projected["view_count"] = 2
                    child = f2_kernel._r_prediction_child_spec({**spec,
                        "native_search_root": str(base / "native"), "native_search_replay": False})
                    assert child["imputation_count"] == 20
                    with monkeypatch.context() as original_native:
                        original_native.setattr(f4.subprocess, "run", _native_run)
                        with pytest.raises(ContractError, match="F4_FULL_PIPELINE_Q_R_NATIVE_FAILED"):
                            f2_kernel._run_r_prediction_partition_batch(child, projected, [task], base / "work",
                                Path(f2_kernel.__file__).parent, evaluation_mode="GROUPED_COX_LOCK",
                                evaluation_partition=stop)
                    stderr, = (base / "native").glob("*/native.stderr")
                    message = stderr.read_text()
                    expected = "F2_R_IMPUTATION_MISSING" if damage == "none" else "F2_R_REGISTERED_PARTITION_DENOMINATOR_INVALID"
                    assert expected in message
                    if damage != "none":
                        assert "F2_R_IMPUTATION_MISSING" not in message
                    assert not list(base.rglob("*.rds")) and not list(base.rglob("*.bin"))
                    assert not list(base.rglob("output.json"))
                    observations.append({"case": damage, "loader_error": expected,
                        "native_spec_sha256": sha256_file(stderr.parent / "spec.json"), "new_model_fits": 0})
                assert canonical_json_bytes(sensitivity._a12_outer_input_record(first)) == original_input
                (tmp_path / "registered-denominator-loader-evidence.json").write_bytes(canonical_json_bytes(observations))
    assert len(set(signatures)) == 3 and calls["path"] == 640 and calls["replay"] == 0
    if family in sensitivity._A12_FIXED_FAMILIES:
        produced = sensitivity._a12_outer_searches(first, root, replay=False)
        assert produced == {}
        staged_jobs = [job for branch in nested.AAR_ESTIMANDS
                       for job in sensitivity._a12_outer_model_jobs(partials[branch], {}, branch=branch)]
    else:
        # Run the original search/cache/replay orchestration with UNFITTED
        # numerical leaves. This does not stand in for a native Q/path fit.
        from padml import f2_kernel
        search_calls = []
        def native_leaf(spec, selected, label):
            assert all(os.environ[key] == str(root) for key in ("TMPDIR", "TMP", "TEMP"))
            assert tempfile.gettempdir() == str(root) and spec["engine_threads"] == 1
            branch, replay = spec["a12_source"]["branch"], spec["native_search_replay"]
            payload = {"UNFITTED_NUMERICAL_LEAF": True, "branch": branch, "selected_parents": selected,
                "source_sha256": nested._sha(spec["a12_source"]), "label": label}
            path = Path(spec["native_search_root"]) / (nested._sha(label) + ".json")
            if replay:
                assert strict_json_bytes(path.read_bytes()) == payload
            else:
                path.write_bytes(canonical_json_bytes(payload))
            search_calls.append((branch, replay))
            return payload
        def q_leaf(spec, registered, scratch):
            payload = native_leaf(spec, spec["selector_from_dependency"]["selected_parents"], "Q")
            model = Path(spec["native_search_root"]) / ("model.rds" if family in {"RSF", "GBM_COX"} else "model.bin")
            if not spec["native_search_replay"]:
                model.write_bytes(b"UNFITTED_Q_NATIVE_REFERENCE")
            elif not spec.get("native_search_numbers"):
                assert model.read_bytes() == b"UNFITTED_Q_NATIVE_REFERENCE"
            return {"execution_scope": "F5_A12_SEARCH", "a12_source": spec["a12_source"],
                "selected_spec": {"family": spec["family"], "UNFITTED_NUMERICAL_LEAF": True}, **payload}
        def path_leaf(spec, registered, recipes, alphas, scratch, repo, accumulator, **kwargs):
            native_leaf(spec, kwargs["selected_parents"], alphas)
            return {alpha: {"alpha": alpha, "UNFITTED": True} for alpha in alphas}
        def path_summary(configuration, record):
            return {"alpha": record["alpha"], "status": "FEASIBLE", "mean_loss_at_selected_parameters": .2,
                "p90_active_design_df": 2, "selected_ratio_by_imputation": [.1] * 20,
                "lambda_by_imputation": [.3] * 20, "lambda_upper_bound_by_imputation": [{"UNFITTED": True}] * 20}
        monkeypatch.setattr(sensitivity, "_run_a12_complex_search", q_leaf)
        monkeypatch.setattr(f2_kernel, "_evaluate_elastic_alpha_phase", path_leaf)
        monkeypatch.setattr(sensitivity, "_summarize_a12_elastic_alpha", path_summary)
        environment = {name: os.environ.get(name) for name in ("TMPDIR", "TMP", "TEMP")}
        produced, staged_jobs = {}, []
        for branch in nested.AAR_ESTIMANDS:
            own = {**partials[branch],
                "branches": {name: partials[branch]["branches"][name] if name == branch else {"UNREADY": True}
                             for name in nested.AAR_ESTIMANDS},
                "branch_development": {branch: partials[branch]["branch_development"][branch]},
                "source_input_record": {**before, "branches": {branch: before["branches"][branch]}}}
            assert sensitivity._a12_search_source(own, branch) == sensitivity._a12_search_source(first, branch)
            current = sensitivity._a12_outer_searches(own, root, replay=False, branch=branch)
            assert set(current) == {branch}
            staged_jobs.extend(sensitivity._a12_outer_model_jobs(own, current, branch=branch))
            produced.update(current)
            assert {path.name for path in (root / "search").iterdir()
                    if path.is_dir() and path.name in nested.AAR_ESTIMANDS} == set(produced)
            # A later branch is not part of this Q's input record. Neither
            # missing later development nor absent later Q delays its M20.
            if family != "ELASTIC_NET_COX":
                record = strict_json_bytes((root / "search" / branch / "input.json").read_bytes())
                assert set(record["inputs"]["branches"]) == {branch}
        replay_input_owners = {}
        replayed = sensitivity._a12_outer_searches(second, root, replay=True, q_input_lifecycle=replay_input_owners)
        assert produced == replayed and set(produced) == set(nested.AAR_ESTIMANDS)
        assert set(replay_input_owners) == set(nested.AAR_ESTIMANDS)
        assert all(set(owners) == {"q_program"} and Path(owners["q_program"]["temporary_root"]).is_dir()
                   for owners in replay_input_owners.values())
        assert {name: os.environ.get(name) for name in environment} == environment
        assert set(search_calls) == {(branch, replay) for branch in nested.AAR_ESTIMANDS for replay in (False, True)}
        with pytest.raises(ContractError, match="BRANCH_DEVELOPMENT_OR_CPU_INVALID"):
            sensitivity._a12_outer_searches(first, root, replay=True, workers=1)
        damaged_native = root / "search" / nested.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT / (
            "search.json" if family == "ELASTIC_NET_COX" else "result.json")
        damaged_native.write_bytes(b"{}")
        with pytest.raises(ContractError, match="REPLAY_MISMATCH" if family == "ELASTIC_NET_COX" else "VALUE_BYTES_MISMATCH"):
            sensitivity._a12_outer_searches(second, root, replay=True)
    # Actual final-task and probability reducers; still no fitted model leaf.
    jobs = sensitivity._a12_outer_model_jobs(first, produced)
    assert staged_jobs == jobs
    assert len(jobs) == 60 and len({job["name"] for job in jobs}) == 60
    original_open = Path.open
    for branch in nested.AAR_ESTIMANDS:
        assigned = f"O1_{branch}_M07"
        scoped = {**first, "branches": {branch: first["branches"][branch]}}
        own_search = {branch: produced[branch]} if produced else {}
        def only_m07(path, *args, **kwargs):
            if path.name.startswith("imp") and path.suffix == ".csv":
                assert path.name == "imp07.csv"
            return original_open(path, *args, **kwargs)
        with monkeypatch.context() as selected:
            selected.setattr(Path, "open", only_m07)
            actual = sensitivity._a12_outer_model_jobs(scoped, own_search, task_names=[assigned])
        assert actual == [job for job in jobs if job["name"] == assigned]
        assert strict_json_bytes(actual[0]["entries"]["task.json"])["registered_model_seed"] == 301007
    rows = []
    for job in jobs:
        task, recipe, training, response, application = sensitivity._ablation_component_inputs(job["entries"])
        branch, imp = task["a12_coordinates"]["branch"], task["imputation"]
        assert task["selected_parents"] == (["Sex"] if branch == nested.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT else ["Age"])
        assert task["common_set_design_df"] == 2 and recipe == first["branches"][branch]["recipes"]["OUTER_F1"]
        assert task["registered_model_seed"] == 301000 + imp
        assert task["model_seed"] == (301000 + imp if family in {"RSF", "GBM_COX", "XGBOOST_COX", "COXTIME_SET_A"} else None)
        source = task["nested_aar_final_source"]
        assert source["primary_development_lock_sha256"] == first["source"]["primary_source"]["primary_development_lock"]["identity_sha256"]
        assert source["science_decision_sha256"] == first["source"]["primary_source"]["science_decision"]["identity_sha256"]
        assert source["development_input_sha256"] == first["branch_development"][branch]["identity_sha256"]
        assert source["inputs_identity_sha256"] == nested._sha({**before, "branches": {branch: before["branches"][branch]}})
        if family in sensitivity._A12_TUNED_FAMILIES:
            assert source["parameter_source_sha256"] == nested._sha(produced[branch])
            assert task["parameters"] == (produced[branch]["parameters_by_imputation"][imp - 1]
                if family == "ELASTIC_NET_COX" else produced[branch]["selected_spec"])
        assert {row["Patient_ID"] for row in training} == set(response)
        assert not set(response) & {row["Patient_ID"] for row in application}
        survival = [[1.0] + [1.0 - .01 * (nested.AAR_ESTIMANDS.index(branch) + 1) - .001 * imp] * 36
                    for _ in application]
        rows.append(sensitivity._ablation_prediction(task, application, survival))
    predictions = sensitivity._a12_outer_predictions(first, jobs, rows)
    assert set(predictions["survival"]) == set(nested.AAR_ESTIMANDS)
    assert predictions == sensitivity._a12_outer_predictions(first, list(reversed(jobs)), list(reversed(rows)))
    for index, branch in enumerate(nested.AAR_ESTIMANDS):
        assert predictions["survival"][branch][0][24] == pytest.approx(1.0 - .01 * (index + 1) - .0105, abs=1e-15)
    with pytest.raises(ContractError, match="NATIVE_FIT_COVERAGE_INVALID"):
        sensitivity._a12_outer_predictions(first, jobs[:-1], rows[:-1])
    with pytest.raises(ContractError, match="NATIVE_COORDINATE_MISMATCH"):
        sensitivity._a12_outer_predictions(first, jobs, list(reversed(rows)))
    total = jobs[20]["entries"]
    for member in ("fit-covariates.csv", "prediction-covariates.csv"):
        data = list(csv.DictReader(io.StringIO(total[member].decode())))
        stream = io.StringIO(newline="")
        writer = csv.DictWriter(stream, fieldnames=[*data[0], "AST_ALT"], lineterminator="\n")
        writer.writeheader()
        writer.writerows({**row, "AST_ALT": "1"} for row in data)
        with pytest.raises(ContractError, match="INFORMATION_CHANNEL_PRESENT"):
            sensitivity._ablation_component_inputs({**total, member: stream.getvalue().encode()})
    if produced:
        mixed = {**produced, nested.A12_TOTAL_AAR: produced[nested.A12_DIRECT_AAR]}
        with pytest.raises(ContractError, match="OUTER_SEARCH_SOURCE_MISMATCH"):
            sensitivity._a12_outer_model_jobs(first, mixed)
    for mutation in ("legacy_branch", "missing_development", "wrong_family", "unconfirmed"):
        bad = copy.deepcopy(sensitivity._a12_search_source(first, nested.A12_TOTAL_AAR))
        if mutation == "legacy_branch":
            bad["branch"] = "WITHOUT_AST_ALT_TOTAL"
        elif mutation == "missing_development":
            del bad["development_input_sha256"]
        elif mutation == "wrong_family":
            bad["family"] = "OTHER_FAMILY"
        else:
            bad["source"]["primary_source"]["science_decision"] = nested.science_decision_template()
        with pytest.raises(ContractError):
            sensitivity._validate_a12_search_source(bad, family=family, outer=1)
    # A cached or edited variable set is not a fresh conditional selector.
    damaged = copy.deepcopy(first)
    damaged["branches"][nested.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT]["selected_parents"] = ["Age"]
    with pytest.raises(ContractError, match="BRANCH_DEVELOPMENT_MISMATCH"):
        sensitivity._a12_branch_search_inputs(damaged, nested.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT)
    if family == "COX_PH":
        native, = (root / "recipes" / nested.A12_TOTAL_AAR).glob("*/recipe.json")
        values = strict_json_bytes(native.read_bytes())
        spline = next(row for row in values["representations"] if "interior_knots" in row["parameters"])
        spline["parameters"]["interior_knots"][0] += 1.0  # still a valid spline, but not the original development
        native.write_bytes(canonical_json_bytes(values))
        with pytest.raises(ContractError, match="BRANCH_DEVELOPMENT_REPLAY_MISMATCH"):
            sensitivity._a12_projected_development_inputs(prepared, root, replay=True)
        native.write_bytes(b"{}")
        with pytest.raises(ContractError, match="RECIPE_R_VALUES_INVALID"):
            sensitivity._a12_projected_development_inputs(prepared, root, replay=True)


@pytest.mark.parametrize("horizon,minimum", [(24, 15), (36, 15), (36, 10)])
def test_projected_outer_inherits_verified_primary_selector_not_f2(aar_source, tmp_path, monkeypatch, horizon, minimum):
    """Real transport/readback; the accepted PRIMARY/F1 leaves are explicitly unfitted."""
    from padml.f2_kernel import _expected_family_parent_column_map, predictor_contract
    primary_input, primary_archive, policy, calls, frozen, original_lock = _projected_outer_fixture(
        aar_source, tmp_path, monkeypatch, "COX_PH")
    model = frozen["models"][1, "COX_PH"]
    original_model = copy.deepcopy(model)
    recipes = model["selector_evidence"]["recipe_set"]
    predictors = predictor_contract(Path(f5.__file__).parent)
    recipe = recipes["recipes"][0]
    def design_df(parents):
        return sum(len(row["columns"]) for row in _expected_family_parent_column_map(
            parents, "ELASTIC_NET_COX", predictors, recipe))
    parents = ["AST_ALT", "HGB"]
    events = original_lock["training_event_count"]
    if minimum == 10:
        for row in recipe["ordered_parent_column_map"]:
            if row["parent"] not in parents:
                parents.append(row["parent"])
            if events < 15 * design_df([name for name in parents if name != "AST_ALT"]):
                break
        assert 10 * design_df(parents) <= events < 15 * design_df(parents[1:])
    decision = nested.science_decision_template(horizon)
    coarse = f5.load_science_authority()["science"]["f2_model_development"]["selector_contract"]["alpha_grid"]["coarse"]
    epv = {"preferred_minimum": 15, "minimum": minimum, "fallback_used": minimum == 10,
        "coarse_records_sha256": "a" * 64,
        "attempts": [{"minimum": tier, "alpha_feasibility": [
            {"alpha": alpha, "status": "FEASIBLE" if tier == minimum else "EPV_INFEASIBLE",
             **({} if tier == minimum else {"reason_code": "COMMON_SETA_EPV_BELOW_MINIMUM"})}
            for alpha in coarse]} for tier in ([15] if minimum == 15 else [15, 10])]}
    lock = nested._sealed({**{key: value for key, value in original_lock.items() if key != "identity_sha256"},
        "selector_evidence_sha256": "7" * 64, "selected_parents": parents,
        "selected_parents_sha256": nested._sha(parents), "common_set_design_df": design_df(parents),
        "common_set_epv": events / design_df(parents), "epv_resolution": epv,
        "epv_band": "EPV_GE_15" if minimum == 15 else "10_LE_EPV_LT_15",
        "selection_horizon_months": horizon, "science_decision_binding": {
            "science_decision_sha256": decision["identity_sha256"], "selection_horizon_months": horizon}})
    nested.validate_development_lock(lock, context=aar_source[3]["primary_training_context"], science_decision=decision)
    with zipfile.ZipFile(primary_input) as archive:
        request = strict_json_bytes(archive.read("o-fit-input.json"))
    request["science_decision"] = decision
    primary_input.unlink()
    write_deterministic_zip(primary_input, {"o-fit-input.json": canonical_json_bytes(request)})
    original_reader = f4._load_o_fit_execution_archive
    def primary_reader(*args, **kwargs):
        value = original_reader(*args, **kwargs)
        return {**value, "development_lock": lock, "science_decision_sha256": decision["identity_sha256"]}
    monkeypatch.setattr(f4, "_load_o_fit_execution_archive", primary_reader)
    target = tmp_path / "projected.zip"
    if horizon == 24:
        with pytest.raises(ContractError, match="NESTED_AAR_PRIMARY_SELECTOR_SOURCE_MISMATCH"):
            sensitivity.compile_a12_outer_inputs(primary_input, primary_archive, target,
                f2_run_root=tmp_path, outer_fold=1, resource_policy=policy)
    else:
        report = sensitivity.compile_a12_outer_inputs(primary_input, primary_archive, target,
            f2_run_root=tmp_path, outer_fold=1, resource_policy=policy)
        opened = sensitivity._load_a12_projected_outer_inputs(target, tmp_path / "readback")
        value = opened["input"]
        assert value["fixed_selected_parents"] == parents[1:]
        assert value["fixed_common_set_design_df"] == design_df(parents[1:])
        assert value["primary_source"]["primary_development_lock"] == lock
        assert value["original_recipes"] == recipes
        assert report["new_model_fits"] == report["new_mice_chains"] == 0
        assert {row["estimand"] for row in value["mice_inputs"]} == {
            nested.A12_TOTAL_AAR, nested.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT}
        assert "evaluation_response" not in opened["direct_partitions"][0]
    assert frozen["models"][1, "COX_PH"] == original_model
    assert calls == ["ORIGINAL_F4_PRIMARY_NATIVE_READER_STUB", "ORIGINAL_ACCEPTED_F4_SOURCE_READER_STUB",
                     "ORIGINAL_F1_M20_READER_STUB"]


@pytest.mark.parametrize("family", nested._families())
def test_projected_outer_compiler_transports_three_distinct_aar_branches_without_heldout_response(aar_source, tmp_path, monkeypatch, family):
    primary_input, primary_archive, policy, calls, frozen, lock = _projected_outer_fixture(aar_source, tmp_path, monkeypatch, family)
    target = tmp_path / "projected.zip"
    report = sensitivity.compile_a12_outer_inputs(primary_input, primary_archive, target,
        f2_run_root=tmp_path, outer_fold=1, resource_policy=policy)
    assert calls == ["ORIGINAL_F4_PRIMARY_NATIVE_READER_STUB", "ORIGINAL_ACCEPTED_F4_SOURCE_READER_STUB",
                     "ORIGINAL_F1_M20_READER_STUB"]
    assert report["new_model_fits"] == report["new_mice_chains"] == 0
    expected_total = 2 if family in {"COX_PH", "FPM_TVC_SET_A"} else 32 if family in {"ELASTIC_NET_COX", "RSF"} else 62
    expected_redevelopment = 32 if family in {"COX_PH", "FPM_TVC_SET_A", "ELASTIC_NET_COX", "RSF"} else 62
    assert report["planned_mice_chain_count"] == 20 * (expected_total + expected_redevelopment)
    opened = sensitivity._load_a12_projected_outer_inputs(target, tmp_path / "readback")
    value, context = opened["input"], aar_source[3]["primary_training_context"]
    assert value["family"] == family and value["primary_source"]["primary_development_lock"] == lock
    assert value["fixed_selected_parents"] == ["Age"]
    assert len([row for row in value["definitions"] if row["kind"] == "INNER"]) == 15
    assert len(opened["direct_partitions"]) == expected_total // 2
    for partition in opened["direct_partitions"]:
        if partition["kind"] == "OUTER":
            assert "evaluation_response" not in partition
        else:
            assert set(f5._response_rows(partition["evaluation_response"]["private_bytes"])[1]) <= set(context["training_ids"])
        assert set(f5._response_rows(Path(partition["fit_response"]["path"]).read_bytes())[1]) <= set(context["training_ids"])
    assert not any("response" in name and name != "training-response.csv" for name in value["members"])
    for record in value["mice_inputs"]:
        spec, entries = sensitivity._load_a12_total_mice_input(opened["root"] / record["member"])
        assert spec["nested_source"]["estimand"] == record["estimand"]
        assert not {"AST", "ALT", "AST_ALT"}.intersection(next(csv.reader(io.StringIO(entries["covariates.csv"].decode()))))
        if "response.csv" in entries:
            assert set(f5._response_rows(entries["response.csv"])[1]) <= set(context["training_ids"])
    assert len(calls) == 3


@pytest.mark.parametrize("damage", ["source_failure", "native_failure", "unbound_primary", "fold_missing",
                                    "fold_source", "fold_outer", "fold_duplicate", "fold_member"])
def test_shared_aar_source_never_replaces_primary_native_acceptance(aar_source, tmp_path, monkeypatch, damage):
    primary_input, primary_archive, policy, calls, _, _ = _projected_outer_fixture(
        aar_source, tmp_path, monkeypatch, "COX_PH")
    original_reader, original_source = f4._load_o_fit_execution_archive, f4.load_f4_inputs
    def source(*args, **kwargs):
        result = original_source(*args, **kwargs)
        if damage == "source_failure":
            raise ContractError("UNFITTED_ACCEPTED_SOURCE_FAILED")
        return result
    def reader(*args, **kwargs):
        retained = []
        observer = kwargs["on_materialized_fold"]
        def observe(frozen, outer, registered):
            retained.append(registered)
            observer({} if damage == "fold_source" else frozen, 2 if damage == "fold_outer" else outer, registered)
            if damage == "fold_duplicate":
                observer(frozen, outer, registered)
        kwargs = {**kwargs, "on_materialized_fold": observe}
        if damage == "fold_missing":
            del kwargs["on_materialized_fold"]
        result = original_reader(*args, **kwargs)
        if damage == "native_failure":
            raise ContractError("UNFITTED_PRIMARY_NATIVE_REPLAY_FAILED")
        if damage == "unbound_primary":
            result["input_identity_sha256"] = "0" * 64
        if damage == "fold_member":
            first = retained[0]["partitions"][0]
            (Path(first["covariates"]["input_dir"]) / "imp01.csv").write_bytes(b"UNKNOWN_CHANGED_FOLD_MEMBER")
        return result
    monkeypatch.setattr(f4, "load_f4_inputs", source)
    monkeypatch.setattr(f4, "_load_o_fit_execution_archive", reader)
    target = tmp_path / "never.zip"
    with pytest.raises(ContractError):
        sensitivity.compile_a12_outer_inputs(primary_input, primary_archive, target,
            f2_run_root=tmp_path, outer_fold=1, resource_policy=policy)
    assert calls == ["ORIGINAL_F4_PRIMARY_NATIVE_READER_STUB", "ORIGINAL_ACCEPTED_F4_SOURCE_READER_STUB"] + (
        [] if damage in {"source_failure", "fold_missing"} else ["ORIGINAL_F1_M20_READER_STUB"])
    assert not target.exists()
    assert len(list(tmp_path.glob("a12-projected-input-*"))) == 1  # all failure work remains attributable


@pytest.mark.parametrize("failure", [None, "primary", "output"])
def test_aar_owned_primary_work_lives_through_direct_consumer_and_releases_only_on_success(
    aar_source, tmp_path, monkeypatch, failure,
):
    import shutil

    primary_input, primary_archive, policy, _, _, _ = _projected_outer_fixture(
        aar_source, tmp_path, monkeypatch, "COX_PH")
    originals = {path: path.read_bytes() for path in (primary_input, primary_archive)}
    original_primary = f4._load_o_fit_execution_archive
    original_output = sensitivity._load_a12_projected_outer_inputs
    owned = []
    consumed = []

    def primary(*args, **kwargs):
        evidence = kwargs["replay_evidence"]
        assert evidence.name == "primary-replay" and evidence.parent.parent == tmp_path
        assert evidence.parent.name.startswith("a12-projected-input-") and not evidence.exists()
        evidence.mkdir()
        owned.append(evidence)
        matrices = evidence / "borrowed-fold"
        shutil.move(tmp_path / "UNFITTED-F1-matrices", matrices)
        observer = kwargs["on_materialized_fold"]

        def retain(frozen, outer, registered):
            for part in registered["partitions"]:
                part["covariates"]["input_dir"] = str(matrices / part["partition_id"])
                part["fit_response"]["path"] = str(matrices / part["partition_id"] / "fit-response.csv")
            observer(frozen, outer, registered)

        value = original_primary(*args, **{**kwargs, "on_materialized_fold": retain})
        (evidence / "private-reader-copy.bin").write_bytes(b"UNFITTED_OWNED_READER_COPY")
        if failure == "primary":
            raise ContractError("UNFITTED_OWNED_PRIMARY_FAILURE")
        return value

    def output(*args, **kwargs):
        assert owned[0].is_dir() and (owned[0] / "borrowed-fold").is_dir()
        value = original_output(*args, **kwargs)
        consumed.append(True)
        if failure == "output":
            raise ContractError("UNFITTED_OWNED_OUTPUT_FAILURE")
        return value

    monkeypatch.setattr(f4, "_load_o_fit_execution_archive", primary)
    monkeypatch.setattr(sensitivity, "_load_a12_projected_outer_inputs", output)
    target = tmp_path / "projected.zip"
    if failure is None:
        result = sensitivity.compile_a12_outer_inputs(primary_input, primary_archive, target,
            f2_run_root=tmp_path, outer_fold=1, resource_policy=policy)
        assert result["status"] == "COMPILED_NOT_EXECUTED" and consumed == [True]
        assert not owned[0].parent.exists() and target.is_file()
        original_output(target, tmp_path / "independent-output-read")
    else:
        with pytest.raises(ContractError, match="UNFITTED_OWNED_.*_FAILURE") as error:
            sensitivity.compile_a12_outer_inputs(primary_input, primary_archive, target,
                f2_run_root=tmp_path, outer_fold=1, resource_policy=policy)
        assert any(str(owned[0].parent) in note for note in error.value.__notes__)
        assert (owned[0] / "private-reader-copy.bin").read_bytes() == b"UNFITTED_OWNED_READER_COPY"
        assert (owned[0] / "borrowed-fold").is_dir()
        assert consumed == ([True] if failure == "output" else [])
        assert target.exists() is (failure == "output")
    assert {path: path.read_bytes() for path in originals} == originals


@pytest.mark.parametrize("failure", [None, "primary", "output"])
def test_aar_saved_compile_record_materializes_one_owned_fold_after_primary_validation(
    aar_source, tmp_path, monkeypatch, failure,
):
    import shutil
    primary_input, primary_archive, policy, calls, _, _ = _projected_outer_fixture(
        aar_source, tmp_path, monkeypatch, "COX_PH")
    compiled = {"UNFITTED_ORIGINAL_COMPILE_RECORD": 1}
    primary_reader, materializer = f4._load_o_fit_execution_archive, f4._materialize_o_fit_fold
    output_reader = sensitivity._load_a12_projected_outer_inputs
    owned = []
    def primary(*args, **kwargs):
        assert kwargs["compiled_input_record"] is compiled and "on_materialized_fold" not in kwargs
        value = primary_reader(*args, **kwargs)
        if failure == "primary":
            raise ContractError("UNFITTED_COMPILED_PRIMARY_FAILURE")
        return value
    def materialize(frozen, outer, target, *, admit_io):
        assert callable(admit_io) and calls == ["ORIGINAL_F4_PRIMARY_NATIVE_READER_STUB", "ORIGINAL_ACCEPTED_F4_SOURCE_READER_STUB"]
        assert target.name == "primary-mice" and target.parent.name.startswith("a12-projected-input-")
        registered = materializer(frozen, outer, target)
        shutil.move(tmp_path / "UNFITTED-F1-matrices", target)
        for part in registered["partitions"]:
            part["covariates"]["input_dir"] = str(target / part["partition_id"])
            part["fit_response"]["path"] = str(target / part["partition_id"] / "fit-response.csv")
        owned.append(target)
        return registered
    def output(*args, **kwargs):
        assert len(owned) == 1 and owned[0].is_dir()
        result = output_reader(*args, **kwargs)
        if failure == "output":
            raise ContractError("UNFITTED_COMPILED_OUTPUT_FAILURE")
        return result
    monkeypatch.setattr(f4, "_load_o_fit_execution_archive", primary)
    monkeypatch.setattr(f4, "_materialize_o_fit_fold", materialize)
    monkeypatch.setattr(sensitivity, "_load_a12_projected_outer_inputs", output)
    target = tmp_path / "projected.zip"
    if failure is None:
        result = sensitivity.compile_a12_outer_inputs(primary_input, primary_archive, target,
            f2_run_root=tmp_path, outer_fold=1, resource_policy=policy, compiled_input_record=compiled)
        assert result["status"] == "COMPILED_NOT_EXECUTED" and not owned[0].parent.exists()
    else:
        with pytest.raises(ContractError, match="UNFITTED_COMPILED_.*_FAILURE"):
            sensitivity.compile_a12_outer_inputs(primary_input, primary_archive, target,
                f2_run_root=tmp_path, outer_fold=1, resource_policy=policy, compiled_input_record=compiled)
        if failure == "primary":
            assert owned == [] and len(calls) == 2
        else:
            assert len(owned) == 1 and owned[0].is_dir()
    assert calls.count("ORIGINAL_F1_M20_READER_STUB") == int(failure != "primary")


def _write_unfitted_a12_configuration(spec):
    """Complete synthetic configuration values; not native MICE evidence."""
    from padml.f1 import load_f1_authority
    science = load_f1_authority()["science"]["mice"]
    raw = Path(spec["covariates_path"]).read_text()
    reader = csv.DictReader(io.StringIO(raw))
    from padml.f1_kernel import effective_mice_rows, formula_value
    rows = list(effective_mice_rows({row["Patient_ID"]: row for row in reader}, science).values())
    names = [name for name in reader.fieldnames if name != "Patient_ID"]
    active = [row["target"] for row in science["target_rules"] if any(not patient[row["target"]].strip() for patient in rows)]
    assert set(active) <= {"HGB"}
    names += ["event_aux", "nelson_aalen_aux"] if spec["view"]["role"] == "ANALYSIS" else []
    catalog = list(csv.DictReader(Path(spec["variable_path"]).open()))
    levels = {row["variable"]: next(field.strip()[7:] for field in row["levels_or_coding"].split(";")
                                   if field.strip().startswith("levels=")).split("|")
              for row in catalog if row["type"] in {"binary", "ordered", "unordered"}}
    training = [row for row in rows if row["Patient_ID"] in spec["view"]["analysis_ids"]]
    matrix = [[0] * len(names) for _ in names]
    for rule in science["target_rules"]:
        target = rule["target"]
        candidates = set(rule["required_predictors"])
        for group in rule["optional_group_ids"]:
            candidates.update(science["predictor_groups"][group])
        candidates = (candidates & set(names)) - set(rule["forbidden_predictors"]) - set(science["always_forbidden_predictors"]) - {target}
        if "AST_ALT" in names:
            candidates.add("AST_ALT")
        if spec["view"]["role"] == "ANALYSIS":
            candidates.update(("event_aux", "nelson_aalen_aux"))
        for name in candidates:
            if name in levels and (len(levels[name]) < 2 or any(
                sum(row[name].strip() == level and bool(row[target].strip()) for row in training) < 5 for level in levels[name])):
                continue
            matrix[names.index(target)][names.index(name)] = 1
    payloads = {
        "ACTUAL_MICE_METHOD": {"names": names, "values": ["pmm" if name in active else "" for name in names]},
        "ACTUAL_PREDICTOR_MATRIX": {"row_names": names, "column_names": names, "values": matrix},
        "ACTUAL_BLOT": {"rows": [{"target": name, **science["pmm"]} for name in active]},
        "ACTUAL_CONTINUATION_CONFIG": {"initial_iteration": 30, "continuation_iterations": [40, 50],
            "continuation_increment": 10, "chain_seeds": spec["chain_seeds"], "final_iterations": [50] * 20}}
    iteration = 50 if active else 0
    payloads["ACTUAL_CONTINUATION_CONFIG"].update(initial_iteration=30 if active else 0,
        continuation_iterations=[40, 50] if active else [], continuation_increment=10 if active else 0,
        final_iterations=[iteration] * 20,
        terminal_diagnostics=[{".it": i, "vrb": name, "parameter": parameter, "psrf": 1.0, "ac": 0.0}
            for i in range(iteration - science["convergence"]["terminal_window_iterations"] + 1, iteration + 1)
            for name in active for parameter in ("mean", "sd")])
    output = Path(spec["output_dir"])
    for name, payload in payloads.items():
        # Native JSON need not use Python's canonical whitespace/key ordering.
        (output / "configuration" / (name + ".json")).write_text(json.dumps({
            "schema_version": "1.0.0", "component": name, "view_id": spec["view"]["view_id"], "payload": payload}, indent=2) + "\n")
    summary = strict_json_bytes((output / "summary.json").read_bytes())
    summary.update(outer_fold=spec["view"]["outer_fold"], active_target_count=len(active),
                   analysis_auxiliary_predictor_edges=2 * len(active) if spec["view"]["role"] == "ANALYSIS" else 0,
                   final_iteration=iteration, relationship_diagnostics={})
    if not active:
        summary.update(completion_mode="COMPLETE_DATA_PASSTHROUGH", actual_mice_chains=0,
                       rng_consumed=False, convergence_max_psrf=None)
    (output / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    projected = io.StringIO(newline="")
    writer = csv.DictWriter(projected, fieldnames=reader.fieldnames, quoting=csv.QUOTE_ALL, lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
    (output.parent / "covariates-total.csv").write_text(projected.getvalue())
    # The old generic fake writes arbitrary Age and leaves HGB missing. This
    # AAR-only UNFITTED leaf instead respects F1 observed values and passive
    # formulas. Distinct legitimate HGB donors still expose merge precedence.
    donor_rows = [row for row in training if row["HGB"].strip()]
    donor = donor_rows[0 if spec["view"]["role"] == "ANALYSIS" else -1]["HGB"]
    completed = copy.deepcopy(rows)
    for row in completed:
        if not row["HGB"].strip():
            row["HGB"] = donor
        for name in ("HCT", "MCH", "MCHC"):
            row[name] = str(formula_value(row, science["formula_completion"]["derived"][name]))
        female = int(float(row["Sex"]) == 1)
        ratio = float(row["Creatinine"]) / 88.4 / (0.7 if female else 0.9)
        row["BMI"] = str(float(row["Weight_kg"]) / (float(row["Height_cm"]) / 100)**2)
        row["eGFR_calc"] = str(142 * min(ratio, 1)**(-0.241 if female else -0.302)
            * max(ratio, 1)**(-1.200) * 0.9938**float(row["Age"]) * 1.012**female)
        if "AST_ALT" in row:
            row["AST_ALT"] = str(float(row["AST"]) / float(row["ALT"]))
    projected = io.StringIO(newline="")
    writer = csv.DictWriter(projected, fieldnames=reader.fieldnames, quoting=csv.QUOTE_ALL, lineterminator="\n")
    writer.writeheader()
    writer.writerows(completed)
    for imputation in range(1, 21):
        (output / "imputations" / f"imp{imputation:02d}.csv").write_text(projected.getvalue())


def _unfitted_outer_mice_workers(monkeypatch):
    """Real native archives and reducers, explicit MOCK R and serial pool leaves."""
    calls, pools = [], []
    def mice(command, **kwargs):
        spec = strict_json_bytes(Path(command[4]).read_bytes())
        calls.append((command[3], spec["nested_aar_source"]["estimand"], spec["view"]["view_id"]))
        result = fake_mice_run(command, **kwargs)
        _write_unfitted_a12_configuration(spec)
        return result
    def serial_pool(worker, tasks, *, selected_slots, execution_report, resource_release_report=None):
        assert worker is sensitivity._execute_a12_total_view_job
        pools.append((selected_slots, [task["name"] for task in tasks]))
        execution_report.update(configured_worker_ceiling=56, admitted_worker_ceiling=selected_slots,
            runnable_task_count=len(tasks), actual_worker_process_peak=1, completed_task_count=0,
            engine_threads=1, status="RUNNING")
        outputs = []
        try:
            for index, task in enumerate(tasks):
                outputs.append(worker(task))
                if resource_release_report is not None:
                    # Serial fixture only; real post-send lifecycle is tested
                    # through the original runtime pool separately.
                    resource_release_report[str(index)] = runtime.release_step_resources([], owner=f"POOL_TASK_RESULT:{index}",
                        before=runtime.observe_step_memory(), released_references=[])
                execution_report["completed_task_count"] += 1
        except BaseException:
            execution_report["status"] = "FAILED"
            raise
        execution_report["status"] = "COMPLETED"
        return outputs
    monkeypatch.setattr(sensitivity.subprocess, "run", mice)
    monkeypatch.setattr(sensitivity, "_bounded_ordered_spawn", serial_pool)
    monkeypatch.setattr(runtime, '_ready_ordered', lambda worker, tasks, **kwargs: serial_pool(worker, tasks,
        selected_slots=kwargs['selected_slots'], execution_report=kwargs['execution_report']))
    return calls, pools


@pytest.mark.parametrize("phase", ["projected", "native", "index_memory"])
def test_original_three_aar_input_readers_admit_each_expansion_before_write(aar_source, tmp_path, monkeypatch, phase):
    """Actual projected compiler/reader; no MICE, selector or model execution."""
    primary_input, primary_archive, policy, _, _, _ = _projected_outer_fixture(aar_source, tmp_path, monkeypatch, "COX_PH")
    projected = tmp_path / "projected.zip"
    sensitivity.compile_a12_outer_inputs(primary_input, primary_archive, projected,
        f2_run_root=tmp_path, outer_fold=1, resource_policy=policy)
    record = strict_json_bytes(sensitivity.read_safe_zip(projected)["a12-inputs.json"])
    target = tmp_path / "check"
    observations = []
    def disk(path):
        observations.append(path)
        available = 0 if phase == "projected" or len(observations) > 1 else 10**12
        return SimpleNamespace(free=available)
    if phase == "projected":
        monkeypatch.setattr(sensitivity.shutil, "disk_usage", disk)
        with pytest.raises(ContractError, match="INPUT_EXPANSION_SPACE_INSUFFICIENT"):
            sensitivity._load_a12_projected_outer_inputs(projected, target)
        assert not target.exists() and len(observations) == 1
    else:
        # The deliberately UNFITTED view placeholders are never extracted
        # or offered to a native MICE reader: space admission must stop first.
        entries = {"input.zip": projected.read_bytes(), "execution.json": b"UNFITTED"}
        entries.update({f"views/{row['estimand']}/{row['view_id']}.zip": b"UNFITTED"
                        for row in record["mice_inputs"]})
        body = {"kind": "PADML_F5_A12_OUTER_INPUTS_NATIVE_V2", "family": record["family"], "outer_fold": 1,
            "projected_input_identity_sha256": record["identity_sha256"], "stage": "MICE_MATERIALIZED_PRE_DEVELOPMENT",
            "branches": {}, "mice_views": {},
            "members": {name: {"sha256": sha256_bytes(raw), "size_bytes": len(raw)} for name, raw in entries.items()}}
        native = tmp_path / "UNFITTED-native.zip"
        write_deterministic_zip(native, {"a12-inputs.json": canonical_json_bytes(nested._sealed(body)), **entries})
        if phase == "index_memory":
            monkeypatch.setattr(runtime, "observe_execution_resources", lambda root: {
                "effective_cpus": 64, "available_memory_bytes": 32 * 32 * 1024**2 - 1,
                "scratch_available_bytes": 10**10, "scratch_root": str(root)})
            original_read = zipfile.ZipFile.read
            def bounded_read(archive, member, *args, **kwargs):
                assert Path(archive.filename) != native, "NUMERICAL_INDEX_READ_BEFORE_MEMORY_ADMISSION"
                return original_read(archive, member, *args, **kwargs)
            monkeypatch.setattr(zipfile.ZipFile, "read", bounded_read)
            with pytest.raises(ContractError, match="RESOURCE_ADMISSION_ZERO"):
                sensitivity.materialize_a12_outer_inputs(native, None, target, input_bundle=projected)
            assert not target.exists()
            return
        monkeypatch.setattr(sensitivity.shutil, "disk_usage", disk)
        with pytest.raises(ContractError, match="INPUT_EXPANSION_SPACE_INSUFFICIENT"):
            sensitivity.materialize_a12_outer_inputs(native, None, target, input_bundle=projected)
        assert (target / "input").is_dir() and not (target / "archive").exists()
        assert len(observations) == 2


@pytest.mark.parametrize("role", ["ANALYSIS", "APPLICATION"])
def test_a12_mice_numbers_reopen_all_values_without_native_objects(aar_source, tmp_path, monkeypatch, role):
    """Actual original numeric/configuration/CSV readers; MICE leaf UNFITTED."""
    import math
    original_run = subprocess.run
    contract, covariates, response, source, policy = aar_source
    input_path = tmp_path / "input.zip"
    write_deterministic_zip(input_path, sensitivity._a12_total_mice_input_members(contract, covariates, response,
        1, "OUTER_" + role, nested_source={**source, "estimand": nested.A12_TOTAL_AAR}, resource_policy=policy))
    calls, _ = _unfitted_outer_mice_workers(monkeypatch)
    native = tmp_path / "native.zip"
    sensitivity.execute_a12_total_mice_bundle(input_path, native)
    first_root = tmp_path / "first-audit"
    first = sensitivity.materialize_a12_total_mice_view(input_path, native, first_root,
        collect_numbers=True, retain_evidence=True)
    numbers = first["numerical_view"]
    assert [row[0] for row in calls] == ["FIT", "REPLAY"]
    assert set(numbers["configuration"]) == set(f5._MICE_CONFIGURATION_NAMES)
    # Independent original R statements check the fixture's full matrix and
    # passive arithmetic. Stop before PMM/RNG/chain creation: no MICE is run.
    oracle = tmp_path / "original-r-numerical-check"
    oracle.mkdir()
    script = r'''
args <- commandArgs(trailingOnly = TRUE)
spec <- jsonlite::fromJSON(args[[1L]], simplifyVector = FALSE)
spec$nested_aar_source <- NULL
authority <- jsonlite::fromJSON(spec$authority_path, simplifyVector = FALSE)
kernel <- file.path(dirname(dirname(spec$authority_path)), "kernels", "f1_nested_mice.R")
required <- c("fail", "exact_names", "chars", "ints", "numeric_strict", "parse_levels",
              "cast_covariates", "nelson_aalen", "factor_support_ok", "egfr", "impute_view")
definitions <- Filter(function(x) is.call(x) && identical(x[[1L]], as.name("<-")) &&
  is.symbol(x[[2L]]) && as.character(x[[2L]]) %in% required && is.call(x[[3L]]) &&
  identical(x[[3L]][[1L]], as.name("function")), as.list(parse(kernel)))
stopifnot(length(definitions) == length(required))
for (definition in definitions) eval(definition)
bridge <- as.list(parse(file.path(dirname(kernel), "f5_a12_mice.R")))
projection <- Filter(function(x) is.call(x) && identical(x[[1L]], as.name("<-")) &&
  identical(x[[2L]], as.name("without_channel")), bridge)
stopifnot(length(projection) == 1L)
removed <- c(0L, 0L)
eval(projection[[1L]])
body(impute_view) <- without_channel(body(impute_view))
stopifnot(identical(removed, c(1L, 1L)))
expressions <- as.list(body(impute_view))
last <- which(vapply(expressions, function(x) identical(x, quote(diag(matrix) <- 0L)), logical(1)))
stopifnot(length(last) == 1L)
for (expression in expressions[2L:last]) eval(expression)
matrix_value <- list(row_names = rownames(matrix), column_names = colnames(matrix),
  values = unname(lapply(seq_len(nrow(matrix)), function(i) unname(as.integer(matrix[i, ])))))
jsonlite::write_json(matrix_value, file.path(args[[2L]], "matrix.json"), auto_unbox = TRUE)
completed <- cast_covariates(read.csv(file.path(spec$output_dir, "imputations", "imp01.csv"),
  colClasses = "character", check.names = FALSE, na.strings = character()), spec$variable_path)
passive <- list()
collect <- function(x) {
  if (!is.call(x)) return(invisible(NULL))
  if (identical(x[[1L]], as.name("<-")) &&
      (identical(x[[2L]], quote(completed$BMI)) || identical(x[[2L]], quote(completed$eGFR_calc)))) {
    passive[[length(passive) + 1L]] <<- x
    return(invisible(NULL))
  }
  for (i in seq_along(x)) if (!identical(x[[i]], quote(expr = ))) collect(x[[i]])
}
collect(body(impute_view))
stopifnot(length(passive) == 2L)
for (expression in passive) eval(expression)
write.table(completed, file.path(args[[2L]], "completed.csv"), sep = ",", row.names = FALSE,
  col.names = TRUE, quote = TRUE, na = "", fileEncoding = "UTF-8", qmethod = "double")
cat("ORIGINAL_MATRIX_AND_PASSIVE_VALUES_ONLY_NO_MICE_OR_RNG\n")
'''
    (oracle / "program.R").write_text(script)
    checked = original_run(["Rscript", "--vanilla", str(oracle / "program.R"),
        str(first_root / "replay/spec.json"), str(oracle)], capture_output=True, text=True, check=False, timeout=30)
    (oracle / "stdout.txt").write_text(checked.stdout)
    (oracle / "stderr.txt").write_text(checked.stderr)
    assert checked.returncode == 0, checked.stderr
    assert checked.stdout.strip() == "ORIGINAL_MATRIX_AND_PASSIVE_VALUES_ONLY_NO_MICE_OR_RNG"
    assert strict_json_bytes((oracle / "matrix.json").read_bytes()) == numbers["configuration"]["ACTUAL_PREDICTOR_MATRIX"]["payload"]
    r_rows = list(csv.DictReader((oracle / "completed.csv").open()))
    actual_rows = list(csv.DictReader((first_root / "imputations/imp01.csv").open()))
    assert len(r_rows) == len(actual_rows)
    for actual, expected in zip(actual_rows, r_rows, strict=True):
        assert actual["Patient_ID"] == expected["Patient_ID"]
        for name in ("BMI", "eGFR_calc", "HGB", "Weight_kg", "Height_cm", "Creatinine"):
            assert math.isclose(float(actual[name]), float(expected[name]), rel_tol=1e-14, abs_tol=0.0)
    from padml.f4_compact import _full_pipeline_mice_numbers
    value, source_members = sensitivity._load_a12_total_mice_input(input_path)
    # Existing clone-spec callers still require their declared integer
    # substream; this is a primitive contract fixture, not a bootstrap run.
    inherited = {key: copy.deepcopy(numbers[key]) for key in ("spec", "summary", "configuration")}
    inherited["spec"].pop("nested_aar_source")
    inherited["spec"]["chain_rng_substream"] = 1
    context = {"covariates_csv": source_members["covariates.csv"], "mice_specs": {"view": copy.deepcopy(inherited["spec"])}}
    _full_pipeline_mice_numbers({"view": inherited}, context)
    inherited["spec"]["chain_rng_substream"] = True
    with pytest.raises(ContractError, match="MICE_VIEW_INVALID"):
        _full_pipeline_mice_numbers({"view": inherited}, context)
    inherited["spec"].pop("chain_rng_substream")
    with pytest.raises(ContractError, match="MICE_VIEW_INVALID"):
        _full_pipeline_mice_numbers({"view": inherited}, context)
    context["mice_specs"]["view"].pop("chain_rng_substream")
    with pytest.raises(ContractError, match="MICE_VIEW_INVALID"):
        _full_pipeline_mice_numbers({"view": inherited}, context)
    (tmp_path / "numbers.json").write_bytes(canonical_json_bytes(numbers))
    members = {name: (first_root / name).read_bytes() for name in numbers["members"] if not name.startswith("native/")}
    compact = tmp_path / "numbers-and-m20.zip"
    write_deterministic_zip(compact, members, stored_members={"input.zip"})
    native.rename(tmp_path / "retained-native.zip")
    (first_root / "native").rename(tmp_path / "retained-native-objects")
    def forbidden(*args, **kwargs):
        pytest.fail("NUMERICAL_MICE_READER_MUST_NOT_CALL_NATIVE")
    monkeypatch.setattr(sensitivity, "_run_a12_total_mice_input", forbidden)
    reopened_root = tmp_path / "numerical-read"
    reopened = sensitivity.materialize_a12_total_mice_view(input_path, compact, reopened_root, numerical_view=numbers)
    assert reopened["numerical_view"] == numbers and reopened["members"] == first["members"]
    assert reopened["native_archive_sha256"] == first["native_archive_sha256"]
    assert "execution_report" not in reopened and not (reopened_root / "native").exists() and not (reopened_root / "replay").exists()
    for member in first["members"]:
        assert (Path(first["input_dir"]) / member["name"]).read_bytes() == (Path(reopened["input_dir"]) / member["name"]).read_bytes()
    rejected = []
    for damage in ("seed", "branch", "patient_order", "summary_m", "method", "matrix", "blot", "continuation",
                   "configuration_missing", "native_size", "native_member", "substream"):
        changed = copy.deepcopy(numbers)
        if damage == "seed":
            changed["spec"]["chain_seeds"][0] += 1
        elif damage == "branch":
            changed["spec"]["nested_aar_source"]["estimand"] = nested.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT
        elif damage == "patient_order":
            changed["spec"]["view"]["row_ids"].reverse()
        elif damage == "summary_m":
            changed["summary"]["formal_m"] = 19
        elif damage == "method":
            method = changed["configuration"]["ACTUAL_MICE_METHOD"]["payload"]
            method["values"][method["names"].index("HGB")] = "norm"
        elif damage == "matrix":
            changed["configuration"]["ACTUAL_PREDICTOR_MATRIX"]["payload"]["values"][0][0] = 1
        elif damage == "blot":
            changed["configuration"]["ACTUAL_BLOT"]["payload"]["rows"][0]["donors"] += 1
        elif damage == "continuation":
            changed["configuration"]["ACTUAL_CONTINUATION_CONFIG"]["payload"]["final_iterations"][0] = 49
        elif damage == "configuration_missing":
            changed["configuration"].pop("ACTUAL_BLOT")
        elif damage == "native_size":
            changed["native_archive"]["size_bytes"] = True
        elif damage == "native_member":
            changed["members"].pop("native/imp20.rds")
        else:
            changed["spec"]["chain_rng_substream"] = 1
        with pytest.raises(ContractError):
            sensitivity.materialize_a12_total_mice_view(input_path, compact, tmp_path / ("bad-" + damage), numerical_view=changed)
        rejected.append(damage)
    # A changed enclosing ZIP and changed member reference cannot make a
    # channel/patient/center drift valid against the independent source.
    for damage in ("patient", "center", "channel", "raw_source", "missing_mi", "raw_sha",
                   "observed_age", "observed_target", "empty_target", "infinite_target", "invalid_factor",
                   "imputed_non_donor", "bmi", "egfr", "matrix_required", "matrix_extra", "matrix_inactive"):
        changed, altered = copy.deepcopy(numbers), dict(members)
        name = "covariates-total.csv" if damage == "raw_source" else "imputations/imp01.csv"
        if damage.startswith("matrix_"):
            name = "configuration/ACTUAL_PREDICTOR_MATRIX.json"
            matrix = changed["configuration"]["ACTUAL_PREDICTOR_MATRIX"]["payload"]
            target = "HGB" if damage != "matrix_inactive" else "Weight_kg"
            column = "Age" if damage != "matrix_extra" else "Creatinine"
            expected = 1 if damage != "matrix_extra" else 0
            assert matrix["values"][matrix["row_names"].index(target)][matrix["column_names"].index(column)] == expected
            matrix["values"][matrix["row_names"].index(target)][matrix["column_names"].index(column)] = 1 - expected
            altered[name] = canonical_json_bytes(changed["configuration"]["ACTUAL_PREDICTOR_MATRIX"])
            changed["members"][name] = {"sha256": sha256_bytes(altered[name]), "size_bytes": len(altered[name])}
        elif damage == "missing_mi":
            altered.pop("imputations/imp20.csv")
        elif damage == "raw_sha":
            altered[name] += b"\n"
        else:
            reader = csv.DictReader(io.StringIO(altered[name].decode()))
            rows, fields = list(reader), list(reader.fieldnames)
            if damage == "patient":
                rows.reverse()
            elif damage == "center":
                rows[0]["Center"] = "999"
            elif damage == "channel":
                fields.append("AST_ALT")
                for row in rows:
                    row["AST_ALT"] = "1"
            elif damage in {"empty_target", "infinite_target", "observed_target", "imputed_non_donor"}:
                original = {row["Patient_ID"]: row for row in csv.DictReader(io.StringIO(source_members["covariates.csv"].decode()))}
                row = next(row for row in rows if bool(original[row["Patient_ID"]]["HGB"].strip()) == (damage != "imputed_non_donor"))
                row["HGB"] = "" if damage == "empty_target" else "inf" if damage == "infinite_target" else "999"
            elif damage == "invalid_factor":
                rows[0]["Sex"] = "unknown"
            elif damage in {"bmi", "egfr"}:
                rows[0]["BMI" if damage == "bmi" else "eGFR_calc"] = "999"
            else:
                rows[0]["Age"] = "999"
            stream = io.StringIO(newline="")
            writer = csv.DictWriter(stream, fieldnames=fields, lineterminator="\n")
            writer.writeheader()
            writer.writerows(rows)
            altered[name] = stream.getvalue().encode()
            changed["members"][name] = {"sha256": sha256_bytes(altered[name]), "size_bytes": len(altered[name])}
        bad = tmp_path / ("altered-" + damage + ".zip")
        write_deterministic_zip(bad, altered)
        (tmp_path / ("altered-" + damage + "-numbers.json")).write_bytes(canonical_json_bytes(changed))
        with pytest.raises(ContractError):
            sensitivity.materialize_a12_total_mice_view(input_path, bad, tmp_path / ("altered-" + damage), numerical_view=changed)
        rejected.append(damage)
    assert [row[0] for row in calls] == ["FIT", "REPLAY"]
    (tmp_path / "numerical-observation.json").write_bytes(canonical_json_bytes({
        "role": role, "original_native_leaf": "UNFITTED", "retained_actual_configuration_fields": sorted(numbers["configuration"]),
        "identical_m20_members": 20, "negative_cases": rejected, "native_calls_after_first_audit": 0,
        "new_actual_mice_chains": 0, "new_actual_model_fits": 0}))


@pytest.mark.parametrize("family", nested._families())
def test_ablation_component_stores_only_r_object_bytes(tmp_path, monkeypatch, family):
    """Original component packer only; all science leaves explicitly UNFITTED."""
    task = {"family": family, "a12_coordinates": {"UNFITTED_STORAGE_ONLY": True}}
    entries = {"task.json": canonical_json_bytes(task), "UNFITTED-input.csv": b"UNFITTED_INPUT\n" * 100}
    model, baseline = b"UNFITTED_MODEL_BYTES" * 100, b"UNFITTED_BASELINE_BYTES" * 100
    calls = []
    monkeypatch.setattr(sensitivity, "_ablation_component_inputs", lambda value: (task, {}, [], {}, []))
    monkeypatch.setattr(sensitivity, "_ablation_prediction", lambda *args: {"UNFITTED_PREDICTION": True})
    def unfitted_engine(actual_family, *args, retained_objects=None, **kwargs):
        assert actual_family == family
        assert retained_objects is None or retained_objects == (model, baseline)
        calls.append(retained_objects is None)
        return {"model": model, "baseline": baseline, "fit_health": {"UNFITTED_HEALTH": True}, "survival": []}
    monkeypatch.setattr(f5, "_execute_final_refit_engine", unfitted_engine)
    root = tmp_path / "component"
    sensitivity._execute_ablation_component({"entries": entries, "root": str(root), "retained_bytes_per_component": 1024**2})
    assert calls == [True, False]
    with zipfile.ZipFile(root.with_suffix(".zip")) as archive:
        assert set(archive.namelist()) == {path.name for path in root.iterdir()}
        for info in archive.infolist():
            stored = family not in {"XGBOOST_COX", "COXTIME_SET_A"} and info.filename in {"model.bin", "baseline.bin"}
            assert info.compress_type == (zipfile.ZIP_STORED if stored else zipfile.ZIP_DEFLATED)
            assert archive.read(info) == (root / info.filename).read_bytes()
        assert archive.read("model.bin") == model and archive.read("baseline.bin") == baseline


def _unfitted_aar_cox_engines(monkeypatch):
    """Only native fitting/audit leaves are synthetic; number validators stay real."""
    from padml.f2_kernel import _expected_family_parent_column_map, predictor_contract
    model_calls, object_calls = [], []
    def model_leaf(family, task, training, response, recipe, *, retained_objects=None, prediction_rows=None, **kwargs):
        f5._validate_a12_model_task(family, task)
        assert family == "COX_PH"
        model = canonical_json_bytes({"UNFITTED_MODEL": True, "task": task, "recipe": recipe, "training_ids": list(response)})
        baseline = canonical_json_bytes({"UNFITTED_BASELINE": True, "model_sha256": sha256_bytes(model)})
        assert retained_objects is None or retained_objects == (model, baseline)
        model_calls.append("UNFITTED_CREATE" if retained_objects is None else "UNFITTED_REPLAY")
        level = 0.90 - .01 * nested.AAR_ESTIMANDS.index(task["a12_coordinates"]["branch"]) - .001 * task["imputation"]
        count = task["family_design_column_count"]
        health = {"engine_threads": 1, "final_model_fit_count": 1, "engine": "survival::coxph", "ties": "breslow",
            "coefficient_count": count, "warning_count": 0, "converged": True, "covariance_rank": count, "iteration_count": 2}
        return {"model": model, "baseline": baseline, "fit_health": health,
                "survival": [[1.0] + [level] * 36 for _ in (training if prediction_rows is None else prediction_rows)],
                **({"training_survival": [[1.0] + [level] * 36 for _ in training]} if kwargs.get("replay_training") else {})}
    def object_leaf(family, model, baseline, health, task, **kwargs):
        value = strict_json_bytes(model)
        assert value["task"] == task and value["UNFITTED_MODEL"] is True
        assert strict_json_bytes(baseline) == {"UNFITTED_BASELINE": True, "model_sha256": sha256_bytes(model)}
        columns = [column for row in _expected_family_parent_column_map(task["selected_parents"], family,
            predictor_contract(Path(f5.__file__).parent), value["recipe"]["transform_recipe"]) for column in row["columns"]]
        count, events = len(columns), task["training_event_count"]
        object_calls.append(task["a12_coordinates"])
        return {"selected_parents": task["selected_parents"], "design_columns": columns,
            **{key: health[key] for key in ("coefficient_count", "covariance_rank", "iteration_count")},
            "training_event_count": events, "complete_data_degrees_of_freedom": events - count,
            "coefficient_ids": columns, "coefficient_estimates": [.1] * count, "within_standard_errors": [.05] * count,
            "covariance": [[.0025 if i == j else 0. for j in range(count)] for i in range(count)]}
    monkeypatch.setattr(f5, "_execute_final_refit_engine", model_leaf)
    monkeypatch.setattr(f5, "_validate_retained_model_objects", object_leaf)
    return model_calls, object_calls


@pytest.mark.parametrize("audit_failure", [False, True])
def test_nested_aar_first_audit_numbers_survive_without_native_objects(tmp_path, monkeypatch, audit_failure):
    from test_f5 import _test_final_design_recipe
    from padml.f2_kernel import _expected_family_parent_column_map, predictor_contract
    family, branch = "COX_PH", nested.A12_DIRECT_AAR
    recipe = _test_final_design_recipe(family, ["Age"])
    design_count = sum(len(row["columns"]) for row in _expected_family_parent_column_map(["Age"], family,
        predictor_contract(Path(f5.__file__).parent), recipe["transform_recipe"]))
    training_count = 15 * design_count + 5
    task = {"family": family, "selected_parents": ["Age"], "parameters": {"family": family, "ties": "breslow"},
        "imputation": 1, "a12_coordinates": {"outer_fold": 1, "branch": branch, "imputation": 1},
        "registered_model_seed": 301001, "model_seed": None, "row_count": training_count,
        "family_design_column_count": design_count, "common_set_design_df": design_count, "training_event_count": training_count,
        "nested_aar_final_source": {"kind": "PADML_NESTED_AAR_FINAL_SOURCE_V1", "program_id": nested.PROGRAM_ID,
            **dict.fromkeys(("science_decision_sha256", "primary_development_lock_sha256", "training_context_sha256",
                "inputs_identity_sha256", "development_input_sha256", "parameter_source_sha256"), "a" * 64)}}
    entries = {"task.json": canonical_json_bytes(task), "recipe.json": canonical_json_bytes(recipe),
        "fit-covariates.csv": ("Patient_ID,Center,Age\n" + "".join(f"T{i:02d},55,40\n" for i in range(training_count))).encode(),
        "fit-response.csv": ("Patient_ID,All_Cause_Death,Death_Followup_months\n" + "".join(f"T{i:02d},1,12\n" for i in range(training_count))).encode(),
        "prediction-covariates.csv": b"Patient_ID,Center,Age\nH01,36,40\nH02,36,50\n"}
    calls, audits = _unfitted_aar_cox_engines(monkeypatch)
    root, retained = tmp_path / "component", 2 * 1024**2
    if audit_failure:
        def failed(*args, **kwargs):
            raise ContractError("UNFITTED_FIRST_AUDIT_FAILURE")
        monkeypatch.setattr(f5, "_validate_retained_model_objects", failed)
        with pytest.raises(ContractError, match="UNFITTED_FIRST_AUDIT_FAILURE"):
            sensitivity._execute_ablation_component({"entries": entries, "root": str(root), "retained_bytes_per_component": retained})
        assert root.with_suffix(".zip").is_file() and (root / "native-failure.json").is_file()
        assert not root.with_suffix(".numbers.json").exists()
        return
    predicted = sensitivity._execute_ablation_component({"entries": entries, "root": str(root), "retained_bytes_per_component": retained})
    with zipfile.ZipFile(root.with_suffix(".zip")) as archive:
        for info in archive.infolist():
            assert archive.read(info) == (root / info.filename).read_bytes()
            assert info.compress_type == (zipfile.ZIP_STORED if info.filename in {"model.bin", "baseline.bin"} else zipfile.ZIP_DEFLATED)
    numbers_path = root.with_suffix(".numbers.json")
    value = strict_json_bytes(numbers_path.read_bytes())
    assert calls == ["UNFITTED_CREATE", "UNFITTED_REPLAY", "UNFITTED_REPLAY"] and len(audits) == 1
    root.rename(tmp_path / "retained-native-directory")
    root.with_suffix(".zip").rename(tmp_path / "retained-native.zip")
    def forbidden(*args, **kwargs):
        pytest.fail("A normal numerical read must not load or audit native models")
    monkeypatch.setattr(f5, "_execute_final_refit_engine", forbidden)
    monkeypatch.setattr(f5, "_validate_retained_model_objects", forbidden)
    job = {"entries": entries, "numbers_path": numbers_path, "native_archive": value["native_archive"],
           "retained_bytes_per_component": retained}
    assert sensitivity._replay_ablation_component(job) == predicted
    original_input = tmp_path / "prepared-input.zip"
    write_deterministic_zip(original_input, entries)
    prepared = sensitivity._read_a12_prepared_numerical_job({"kind": "aar", "outer_fold": 1,
        "name": f"O1_{branch}_M01", "input": original_input, "numbers": numbers_path,
        "native_archive": value["native_archive"], "retained_bytes_per_component": retained,
        "input_expanded_bytes": sum(map(len, entries.values())),
        "files": {path: {"sha256": sha256_file(path), "size_bytes": path.stat().st_size}
                  for path in (original_input, numbers_path)}})
    assert prepared["prediction"] == predicted and prepared["task"] == task
    for damage in ("input", "patient", "coordinate", "training", "probability", "health", "audit", "denominator", "missing", "native"):
        changed = copy.deepcopy(value)
        if damage == "input":
            changed["input_members"]["task.json"]["sha256"] = "b" * 64
        elif damage in {"patient", "coordinate", "probability"}:
            row = changed["prediction"]
            if damage == "patient":
                row["patient_ids"].reverse()
            elif damage == "coordinate":
                row["a12_coordinates"]["imputation"] = 2
            else:
                row["survival"][0][1] = 1.1
        elif damage == "training":
            changed["training_prediction"]["patient_ids"].reverse()
        elif damage == "health":
            changed["fit_health"]["converged"] = False
        elif damage == "audit":
            changed["object_audit"]["coefficient_estimates"][0] = "NONNUMERIC"
        elif damage == "denominator":
            changed["object_audit"]["training_event_count"] -= 1
            changed["object_audit"]["complete_data_degrees_of_freedom"] -= 1
        elif damage == "missing":
            changed.pop("object_audit")
        else:
            changed["native_archive"]["sha256"] = "b" * 64
        numbers_path.write_bytes(canonical_json_bytes(changed))
        with pytest.raises(ContractError):
            sensitivity._replay_ablation_component(job)
    numbers_path.write_bytes(canonical_json_bytes(value))
    numbers_path.rename(tmp_path / "saved-numbers.json")
    with pytest.raises(ContractError, match="FINAL_NUMBERS_REQUIRED"):
        sensitivity._replay_ablation_component(job)
    assert len(audits) == 1


@pytest.mark.parametrize("final_shards", [False, True])
def test_original_three_aar_outer_executes_and_reopens_native_archive_chain(aar_source, tmp_path, monkeypatch, request, final_shards):
    """Real public owners/MICE and model ZIPs; all fitting leaves are UNFITTED."""
    # This serial fixture declares enough RAM for the explicit 2 GiB budget.
    # Scan outcomes are injected below; no host-wide scan proves fixture ownership.
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda root: {
        "effective_cpus": 64, "available_memory_bytes": 10**12,
        "scratch_available_bytes": 10**10, "scratch_root": str(root)})
    monkeypatch.setattr(runtime, "_visible_open_file_keys", lambda candidates: (set(), 1))
    primary_input, primary_archive, policy, primary_reads, _, _ = _projected_outer_fixture(
        aar_source, tmp_path, monkeypatch, "COX_PH")
    projected, inputs, target = (tmp_path / name for name in ("projected.zip", "inputs.zip", "outer.zip"))
    sensitivity.compile_a12_outer_inputs(primary_input, primary_archive, projected,
        f2_run_root=tmp_path, outer_fold=1, resource_policy=policy)
    mice_calls, _ = _unfitted_outer_mice_workers(monkeypatch)
    sensitivity.execute_a12_outer_inputs(projected, inputs)
    def no_more_mice(*args, **kwargs):
        pytest.fail("OUTER_CONSUMERS_MUST_USE_FIRST_MICE_AUDIT_NUMBERS")
    monkeypatch.setattr(sensitivity, "_run_a12_total_mice_input", no_more_mice)
    mice_native = sensitivity.subprocess.run
    selector_calls = request.getfixturevalue("unfitted_selector_engines")
    recipe_native = sensitivity.subprocess.run
    def native(command, **kwargs):
        return (mice_native if len(command) > 4 and command[3] in {"FIT", "REPLAY"} else recipe_native)(command, **kwargs)
    monkeypatch.setattr(sensitivity.subprocess, "run", native)
    development_owner = sensitivity._a12_projected_development_inputs
    stage_order = []
    verified_inputs, verified_development = [], []
    def development_with_storage_probe(prepared, destination, *, replay, **kwargs):
        if not replay:
            branch = kwargs["branch"]
            index = nested.AAR_ESTIMANDS.index(branch)
            assert stage_order == ([('development', name) for name in nested.AAR_ESTIMANDS[:index]] if final_shards else
                [item for name in nested.AAR_ESTIMANDS[:index] for item in (("development", name), ("final_m20", name))])
            assert model_calls.count("UNFITTED_CREATE") == (0 if final_shards else 20 * index)
            if index < 2:
                assert selector_calls["path"] == 0 and not (destination / "selector").exists()
            stage_order.append(("development", branch))
        value = development_owner(prepared, destination, replay=replay, **kwargs)
        if replay:
            verified_inputs.append(prepared)
            verified_development.append(value)
        probe = destination / "UNFITTED-storage-only"
        # Exercise the outer owner's unchanged wildcard native transport;
        # these byte probes are not Q results and introduce no Q fitting.
        if not replay and not probe.exists():
            probe.mkdir()
            for name in ("model.rds", "risk.bin"):
                (probe / name).write_bytes(("UNFITTED_STORAGE_ONLY:" + name).encode() * 100)
        return value
    monkeypatch.setattr(sensitivity, "_a12_projected_development_inputs", development_with_storage_probe)
    model_jobs_owner = sensitivity._a12_outer_model_jobs
    complete_jobs = {}
    def model_jobs_with_assignment_probe(prepared, searches, **kwargs):
        assigned = kwargs.get("task_names")
        if assigned is not None:
            expected_branches = {branch for branch, imp in sensitivity._a12_final_task_coordinates(
                prepared["outer_fold"], assigned).values()}
            assert set(prepared["branches"]) == expected_branches
            read_bytes = Path.read_bytes
            def assigned_read(path):
                if path.name.startswith("imp") and path.suffix == ".csv":
                    assert any(name.endswith("_M" + path.stem[3:]) for name in assigned)
                return read_bytes(path)
            with monkeypatch.context() as scoped:
                scoped.setattr(Path, "read_bytes", assigned_read)
                result = model_jobs_owner(prepared, searches, **kwargs)
            assert result == [complete_jobs[name] for name in assigned]
            return result
        result = model_jobs_owner(prepared, searches, **kwargs)
        complete_jobs.update({job["name"]: job for job in result})
        return result
    monkeypatch.setattr(sensitivity, "_a12_outer_model_jobs", model_jobs_with_assignment_probe)
    pools = []
    def serial_pool(worker, jobs, *, selected_slots, execution_report, on_result=None, resource_release_report=None):
        assert worker in {sensitivity._execute_ablation_component, sensitivity._replay_ablation_component}
        if worker is sensitivity._execute_ablation_component:
            if final_shards:
                assert len(jobs) == selected_slots == 10 and selector_calls["path"] == 640
                stage_order.append(("final_shard", [job["name"] for job in jobs]))
            else:
                branch, = {strict_json_bytes(job["entries"]["task.json"])["a12_coordinates"]["branch"] for job in jobs}
                assert len(jobs) == selected_slots == 20 and stage_order[-1] == ("development", branch)
                if branch != nested.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT:
                    assert selector_calls["path"] == 0
                stage_order.append(("final_m20", branch))
        else:
            assert len(jobs) == 60 and selected_slots == 56
        execution_report.update(configured_worker_ceiling=56, admitted_worker_ceiling=selected_slots,
            runnable_task_count=len(jobs), actual_worker_process_peak=1, completed_task_count=0,
            engine_threads=1, status="RUNNING")
        pools.append(worker.__name__)
        rows = []
        for index, job in enumerate(jobs):
            row = worker(job)
            if on_result is not None:
                on_result(index, row)
            rows.append(row)
            execution_report["completed_task_count"] += 1
            if resource_release_report is not None:
                from padml import runtime
                before = runtime.observe_step_memory()
                del row
                resource_release_report[str(index)] = runtime.release_step_resources([], before=before,
                    owner=f"POOL_TASK_RESULT:{index}",
                    released_references=["serialized_result", "task", "received_message"])
        execution_report["status"] = "COMPLETED"
        return rows
    monkeypatch.setattr(sensitivity, "_bounded_ordered_spawn", serial_pool)
    model_calls, object_calls = _unfitted_aar_cox_engines(monkeypatch)
    def input_receipt(result, operation):
        pin = result["input_execution"]
        path = Path(pin["path"])
        raw = path.read_bytes()
        assert pin == {"path": str(path), "sha256": sha256_bytes(raw), "size_bytes": len(raw)}
        value = strict_json_bytes(raw)
        completed = canonical_json_bytes({key: item for key, item in result.items() if key != "input_execution"})
        assert value["operation"] == operation
        assert value["result"] == {"sha256": sha256_bytes(completed), "size_bytes": len(completed)}
        assert all(not Path(row["temporary_root"]).exists() for row in value["input_lifecycle"].values())
        assert path.parent.is_dir() and (path.parent / "development/development.json").is_file()
        return value
    if final_shards:
        preparation = sensitivity.execute_a12_outer_bundle(inputs, target, input_bundle=projected,
            retained_bytes_per_component=2 * 1024**2, prepare_final=True)
        assert preparation["new_final_model_fits"] == 0 and not model_calls and not object_calls
        input_receipt(preparation, "PREPARE_FINAL")
        assert len(preparation["task_names"]) == 60 and not target.exists()
        owner = Path(preparation["work_evidence_retained"])
        assert (owner / "development/development.json").is_file() and not (owner / "fits").exists()
        before_development = dict(selector_calls)
        batches = []
        for index in range(6):
            assigned = preparation["task_names"][index * 10:(index + 1) * 10]
            branch = nested.AAR_ESTIMANDS[index // 2]
            worker_target = tmp_path / f"worker-{index}.zip"
            worker = worker_target.with_name(worker_target.name + ".work")
            worker.mkdir()
            for name, record in sensitivity._a12_final_shared_members(preparation["shared_members"], {branch}).items():
                source_path = inputs if name == "inputs.zip" else owner / name
                destination = worker / name
                destination.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(source_path, destination)
                assert record == {"sha256": sha256_file(destination), "size_bytes": destination.stat().st_size}
            batch = worker / "final-batches" / "assignment"
            zip_open = zipfile.ZipFile.open
            def only_assigned_payload(archive, name, *args, **kwargs):
                member = name.filename if isinstance(name, zipfile.ZipInfo) else name
                if member.startswith("direct/"):
                    assert branch == nested.A12_DIRECT_AAR
                elif member.startswith(("mice-inputs/", "views/")):
                    assert member.split("/")[1] == branch
                return zip_open(archive, name, *args, **kwargs)
            with monkeypatch.context() as scoped:
                scoped.setattr(zipfile.ZipFile, "open", only_assigned_payload)
                result = sensitivity.execute_a12_outer_bundle(worker / "inputs.zip", worker_target, input_bundle=projected,
                    retained_bytes_per_component=2 * 1024**2, final_task_ids=assigned, final_batch_root=batch)
            assert result["new_model_fits"] == result["new_model_native_verification_count"] == 10
            input_receipt(result, "FINAL_BATCH")
            assert (batch / "execution.json").read_bytes() == canonical_json_bytes(result["execution_report"])
            assert not worker_target.exists() and selector_calls == before_development
            shutil.move(worker / "fits", worker / "UNFITTED-execution-owned-native")
            batches.append(batch)
        with monkeypatch.context() as gather:
            gather.setattr(f5, "_execute_final_refit_engine", lambda *args, **kwargs: pytest.fail("NO_GATHER_NATIVE_READ"))
            gather.setattr(f5, "_validate_retained_model_objects", lambda *args, **kwargs: pytest.fail("NO_GATHER_NATIVE_AUDIT"))
            report = sensitivity.execute_a12_outer_bundle(inputs, target, input_bundle=projected,
                retained_bytes_per_component=2 * 1024**2, final_batches=list(reversed(batches)))
        assert selector_calls == before_development
    else:
        report = sensitivity.execute_a12_outer_bundle(inputs, target, input_bundle=projected,
            retained_bytes_per_component=2 * 1024**2)
    assert report["outer_model_fit_count"] == (0 if final_shards else 60) and report["outer_stop_fit_count"] == 0
    input_receipt(report, "FINAL_GATHER" if final_shards else "OUTER_EXECUTE")
    assert (Path(report["work_evidence_retained"]) / "execution.json").read_bytes() == canonical_json_bytes(report["execution_report"])
    assert not report["stage_acceptance"] and Path(report["work_evidence_retained"]).is_dir()
    records = (dict(enumerate(report["execution_report"]["final_batches"])) if final_shards else
               report["execution_report"]["branch_final_models"])
    assert "final_model_pool" not in report["execution_report"]
    if final_shards:
        assert len(records) == 6 and "branch_final_models" not in report["execution_report"]
        assert all(record["resource_reservation"]["resource_release_reserved_bytes"] == 10 * 128 * 1024
                   and len(canonical_json_bytes(record)) <= 128 * 1024 for record in records.values())
        assert sum(record["resource_release"]["size_bytes"] for record in records.values()) <= 60 * 128 * 1024
        assert stage_order[:3] == [("development", name) for name in nested.AAR_ESTIMANDS]
        assert len(stage_order) == 9 and all(row[0] == "final_shard" for row in stage_order[3:])
        assert {name for record in records.values() for name in record["task_names"]} == set(preparation["task_names"])
    else:
        assert set(records) == set(nested.AAR_ESTIMANDS)
        assert stage_order == [item for name in nested.AAR_ESTIMANDS
                               for item in (("development", name), ("final_m20", name))]
    assert all(record["final_model_pool"]["actual_worker_process_peak"] == 1 for record in records.values())
    assert all(record["resource_reservation"]["component_retention_reserved_bytes"] == (10 if final_shards else 60) * 2 * 1024**2
               for record in records.values())
    assert all(record["final_model_pool"]["configured_worker_ceiling"] == 56
               and record["resource_admission"]["admitted_worker_ceiling"] == (10 if final_shards else 20) for record in records.values())
    if final_shards:
        sizes = [record["resource_reservation"]["shared_member_bytes"] for record in records.values()]
        assert sizes[0] == sizes[1] < sizes[2] == sizes[3] < sizes[4] == sizes[5]
    else:
        assert [records[name]["resource_reservation"]["shared_member_bytes"] for name in nested.AAR_ESTIMANDS] == sorted(
            {record["resource_reservation"]["shared_member_bytes"] for record in records.values()})
    reservation = report["execution_report"]["resource_reservation"]
    assert reservation["component_retention_reserved_bytes"] == (0 if final_shards else 60 * 2 * 1024**2)
    assert reservation["archive_reserved_bytes"] > reservation["shared_member_bytes"]
    assert model_calls.count("UNFITTED_CREATE") == len(object_calls) == 60
    assert model_calls.count("UNFITTED_REPLAY") == 120
    with zipfile.ZipFile(target) as archive:
        for info in archive.infolist():
            assert not any(part.startswith(("input-execution-", "a12-selector-inputs-", "nested-full-selector-replay-"))
                           for part in Path(info.filename).parts)
            expected = zipfile.ZIP_STORED if info.filename.endswith((".zip", ".rds")) else zipfile.ZIP_DEFLATED
            assert info.compress_type == expected
            if info.filename.startswith("development/UNFITTED-storage-only/"):
                assert archive.read(info) == (Path(report["work_evidence_retained"]) / info.filename).read_bytes()
    def forbidden(*args, **kwargs):
        pytest.fail("Final M20 native objects are not a normal numerical-read dependency")
    monkeypatch.setattr(f5, "_execute_final_refit_engine", forbidden)
    monkeypatch.setattr(f5, "_validate_retained_model_objects", forbidden)
    before_mice = sum(row[0] == "FIT" for row in mice_calls)
    before_selector = selector_calls["path"]
    before_recipe = selector_calls["recipe"]
    captured = {"members": {}, "jobs": [], "records": {}}
    capture_root = tmp_path / "captured-preparation"
    capture_root.mkdir()
    def prepared_consumer(value, jobs, record):
        assert record["execution_ledger"] == report["execution_ledger"]
        assert sensitivity._a12_outer_predictions(value, jobs,
            [sensitivity._replay_ablation_component(job) for job in jobs]) == value["predictions"]
        sensitivity._capture_a12_prepared_outer(value, jobs, record,
            root=capture_root, captured=captured, resource_policy=policy)
    replay_pin = {}
    observed = sensitivity._load_a12_outer_archive(target, input_bundle=projected, replay_evidence=tmp_path / "replay",
        _prepared_consumer=prepared_consumer, execution_report=replay_pin)
    assert len(captured["jobs"]) == 60 and set(captured["records"]) == {1}
    assert len(captured["members"]) == 121
    assert list((tmp_path / "replay/archive/development").glob("a12-selector-inputs-*/outer-training/imp01.csv"))
    assert not any("a12-selector-inputs-" in name for name in observed["members"])
    replay_resources = strict_json_bytes((tmp_path / "replay/execution.json").read_bytes())
    assert replay_pin == {"path": str(tmp_path / "replay/execution.json"),
        "sha256": sha256_file(tmp_path / "replay/execution.json"),
        "size_bytes": (tmp_path / "replay/execution.json").stat().st_size}
    assert replay_resources["input_execution"]["operation"] == "OUTER_REPLAY"
    assert replay_resources["input_execution"]["result"] == {"sha256": sha256_bytes(canonical_json_bytes(observed)),
        "size_bytes": len(canonical_json_bytes(observed))}
    assert all(Path(row["temporary_root"]).is_dir() for row in replay_resources["input_execution"]["input_lifecycle"].values())
    assert replay_resources["archive_expansion"]["expanded_bytes"] > 0
    assert replay_resources["replay_retention_reserved_bytes"] == 0
    assert set(replay_resources["input_expansion"]) == {"projected", "native"}
    assert all(row["scientific_worker_count"] == 0 for row in replay_resources["input_expansion"].values())
    assert observed["kind"] == "PADML_F5_A12_OUTER_NATIVE_V2" and observed["family"] == "COX_PH"
    assert len([name for name in observed["members"] if name.startswith("fits/")]) == 60
    assert all(name.endswith(".numbers.json") for name in observed["members"] if name.startswith("fits/"))
    assert len(observed["native_members"]) == len(object_calls) == 60
    if final_shards:
        assert len([name for name in observed["members"] if name.startswith("final-batches/")]) == 6
        assert observed["members"]["execution.json"]["sha256"] == sha256_file(
            Path(report["work_evidence_retained"]) / "execution.json")
    assert selector_calls["recipe"] == before_recipe
    assert not any(name.startswith("development/recipes/") and "/training-inputs/" in name for name in observed["members"])
    assert list((Path(report["work_evidence_retained"]) / "development/recipes").glob("*/*/training-inputs/*/imp01.csv"))
    assert "development/selector/development-input.json" in observed["members"]
    assert not any(name.startswith("development/selector/") and (name.endswith(".bin") or name.endswith("output.json"))
                   for name in observed["members"])
    assert len([name for name in observed["members"] if name.startswith("development/selector/")
                and name.endswith("/native/spec.json")]) == 640
    assert set(observed["predictions"]["survival"]) == set(nested.AAR_ESTIMANDS)
    ledger = sensitivity._a12_outer_archive_record(observed, target)["execution_ledger"]
    # The native program counts 12 distinct alphas × 16 partitions × M20;
    # the stub's 640 worker calls each group several alpha paths.
    assert ledger == {"mice_chains": 680, "elastic_path_executions": 3840, "glmnet_pilot_and_path_calls": 7680,
        "candidate_prediction_fits": 0, "stop_fits": 0, "inner_scoring_fits": 0, "post_lock_fits": 60, "total_model_fits": 60}
    assert report["execution_ledger"] == ledger
    assert pools == (["_execute_ablation_component"] * 6 + ["_replay_ablation_component"] * 2 if final_shards else
                     ["_execute_ablation_component"] * 3 + ["_replay_ablation_component"])
    assert model_calls.count("UNFITTED_CREATE") == 60 and model_calls.count("UNFITTED_REPLAY") == 120
    assert sum(row[0] == "FIT" for row in mice_calls) == before_mice == 34
    assert selector_calls["path"] == before_selector == 640
    assert primary_reads == ["ORIGINAL_F4_PRIMARY_NATIVE_READER_STUB", "ORIGINAL_ACCEPTED_F4_SOURCE_READER_STUB",
                             "ORIGINAL_F1_M20_READER_STUB"]  # no additional global read during remote replay
    with pytest.raises(ContractError, match="OUTER_ARGUMENT_SCOPE_INVALID"):
        sensitivity.execute_a12_outer_bundle(inputs, tmp_path / "forbidden.zip", input_bundle=projected, workers=1)
    assert not (tmp_path / "forbidden.zip.work").exists()
    entries = sensitivity.read_safe_zip(target)
    changed = copy.deepcopy(observed)
    changed["source"]["family"] = "RSF"
    changed = nested._sealed({key: value for key, value in changed.items() if key != "identity_sha256"})
    bad = tmp_path / "wrong-source.zip"
    write_deterministic_zip(bad, {**entries, "a12-outer.json": canonical_json_bytes(changed)})
    calls_before = list(model_calls)
    with pytest.raises(ContractError, match="OUTER_INDEX_INVALID"):
        sensitivity._load_a12_outer_archive(bad, input_bundle=projected)
    assert model_calls == calls_before
    # Reuse the inputs/development just read by the real consumers above for
    # execution-report negatives. The original archive reader still extracts
    # and validates every outer byte, compiles all 60 tasks, and reconstructs
    # all branch-local resource reservations. No native or numerical fit runs.
    damages = ("missing_branch", "whole60_pool", "early_retention_credit", "incomplete_m20", "fixed_cpu20")
    with monkeypatch.context() as negative:
        negative.setattr(sensitivity, "materialize_a12_outer_inputs", lambda *args, **kwargs: verified_inputs[-1])
        negative.setattr(sensitivity, "_a12_projected_development_inputs", lambda *args, **kwargs: verified_development[-1])
        negative.setattr(sensitivity, "_bounded_ordered_spawn", forbidden)
        for damage in damages:
            execution = strict_json_bytes(entries["execution.json"])
            branch = nested.A12_DIRECT_AAR
            record = execution["final_batches"][0] if final_shards else execution["branch_final_models"][branch]
            if damage == "missing_branch":
                if final_shards:
                    execution["final_batches"].pop()
                else:
                    del execution["branch_final_models"][nested.A12_TOTAL_AAR]
            elif damage == "whole60_pool":
                execution["final_model_pool"] = {**record["final_model_pool"], "runnable_task_count": 60,
                                                  "completed_task_count": 60}
            elif damage == "early_retention_credit":
                record["resource_reservation"]["component_retention_reserved_bytes"] -= (1 if final_shards else 20) * 2 * 1024**2
            elif damage == "incomplete_m20":
                record["final_model_pool"]["completed_task_count"] = 19
            else:
                record["final_model_pool"]["configured_worker_ceiling"] = 20
            changed = copy.deepcopy(observed)
            raw = canonical_json_bytes(execution)
            changed["members"]["execution.json"] = {"sha256": sha256_bytes(raw), "size_bytes": len(raw)}
            changed = nested._sealed({key: value for key, value in changed.items() if key != "identity_sha256"})
            damaged = tmp_path / (damage + ".zip")
            write_deterministic_zip(damaged, {**entries, "execution.json": raw, "a12-outer.json": canonical_json_bytes(changed)})
            reason = ("OUTER_MEMBER_SET_INVALID" if damage == "missing_branch" else
                      "FINAL_BATCH_RESOURCE_DRIFT" if damage == "early_retention_credit" else
                      "PRODUCER_GEOMETRY_INVALID" if damage == "whole60_pool" else "FINAL_BATCH_POOL_INVALID") if final_shards else (
                          "RESOURCE_RESERVATION_DRIFT" if damage == "early_retention_credit" else "PRODUCER_GEOMETRY_INVALID")
            with pytest.raises(ContractError, match=reason):
                sensitivity._load_a12_outer_archive(damaged, input_bundle=projected,
                    replay_evidence=tmp_path / ("negative-" + damage))
    assert model_calls == calls_before and selector_calls["path"] == before_selector
    if not final_shards:
        # Reuse the real, verified upstream preparation above. This bounded
        # tail proof does not claim a second preparation or native model audit.
        # The original ZIP extraction, 60 number reads, release and cleanup run.
        release_native, write_native, remove_native = runtime.release_step_resources, nested._write_exact_once, shutil.rmtree
        sealed_sha = sha256_file(target)
        observe_native = runtime.observe_execution_resources
        for fault in (None, "release", "release_and_write", "cleanup", "unknown", "nested_unknown", "post_observation", "post_admission"):
            roots, pin = [], {}
            tail_state = {"released": False}
            def prepared_reuse(source, lineage, destination, **kwargs):
                roots.append(destination.parent)
                destination.mkdir()
                (destination / "UNFITTED-reused-input").write_bytes(b"UNFITTED_TAIL_ONLY")
                return verified_inputs[-1]
            def release_tail(files, **kwargs):
                if fault in {"release", "release_and_write"} and kwargs["owner"].startswith("AAR_FINAL_INPUTS:"):
                    raise ContractError("UNFITTED_FIRST_RELEASE_FAILURE")
                result = release_native(files, **kwargs)
                if kwargs["owner"].startswith("AAR_FINAL_INPUTS:"):
                    tail_state["released"] = True
                if fault == "unknown" or fault == "nested_unknown" and ":development_inputs:" in kwargs["owner"]:
                    result["reader_scan_status"] = "UNKNOWN"
                    for row in result["files"]:
                        row.update(status="UNKNOWN", error="RESOURCE_READER_SCAN_FAILED:OSError:UNFITTED")
                return result
            def observe_tail(root):
                if tail_state["released"] and fault == "post_observation":
                    raise OSError("UNFITTED_POST_OBSERVATION")
                result = observe_native(root)
                return {**result, "available_memory_bytes": 1} if tail_state["released"] and fault == "post_admission" else result
            def development_reuse(prepared, destination, **kwargs):
                if fault == "nested_unknown":
                    child = roots[-1] / "archive/UNFITTED-owned-child"
                    child.mkdir()
                    (child / "input.txt").write_bytes(b"UNFITTED_NESTED_OWNER")
                    kwargs["q_input_lifecycle"]["development_inputs"] = {"temporary_root": str(child)}
                return verified_development[-1]
            def write_tail(path, raw, reason):
                if fault == "release_and_write" and path.name == "execution.json.input-pending":
                    raise OSError("UNFITTED_SECOND_DIAGNOSTIC_FAILURE")
                return write_native(path, raw, reason)
            def remove_tail(path, *args, **kwargs):
                if fault == "cleanup" and roots and Path(path) == roots[-1] / "inputs":
                    raise OSError("UNFITTED_CLEANUP_FAILURE")
                return remove_native(path, *args, **kwargs)
            with monkeypatch.context() as tail:
                tail.setattr(sensitivity, "materialize_a12_outer_inputs", prepared_reuse)
                tail.setattr(sensitivity, "_a12_projected_development_inputs", development_reuse)
                tail.setattr(runtime, "release_step_resources", release_tail)
                tail.setattr(runtime, "observe_execution_resources", observe_tail)
                tail.setattr(nested, "_write_exact_once", write_tail)
                tail.setattr(shutil, "rmtree", remove_tail)
                if fault not in {"release", "release_and_write"}:
                    assert sensitivity._load_a12_outer_archive(target, input_bundle=projected, execution_report=pin) == observed
                    assert pin["sha256"] == sha256_file(roots[-1] / "execution.json")
                    saved = strict_json_bytes((roots[-1] / "execution.json").read_bytes())["input_execution"]
                    assert saved["execution_scratch_reserve_bytes"] == saved["effective_policy"]["scratch_reserve_bytes"] == 0
                    if fault is None:
                        assert {path.name for path in roots[-1].iterdir()} == {"execution.json"}
                    elif fault in {"cleanup", "unknown"}:
                        assert (roots[-1] / "inputs/UNFITTED-reused-input").is_file()
                        if fault == "cleanup":
                            assert saved["operational_errors"][0]["operation"] == "DISPOSABLE_INPUT_REMOVAL"
                    elif fault == "nested_unknown":
                        assert (roots[-1] / "archive/UNFITTED-owned-child/input.txt").is_file()
                    else:
                        assert saved["after_release"]["resource_admission"] is None
                        assert saved["operational_errors"][0]["operation"] == (
                            "POST_STEP_OBSERVATION" if fault == "post_observation" else "POST_STEP_ADMISSION")
                else:
                    with pytest.raises(ContractError, match="UNFITTED_FIRST_RELEASE_FAILURE") as error:
                        sensitivity._load_a12_outer_archive(target, input_bundle=projected, execution_report=pin)
                    assert not pin and (roots[-1] / "inputs/UNFITTED-reused-input").is_file()
                    saved = strict_json_bytes((roots[-1] / "execution.json").read_bytes())
                    assert saved["numerical_read_pool"]["status"] == "COMPLETED"
                    if fault == "release_and_write":
                        assert "input_execution" not in saved
                        assert any("DIAGNOSTIC_WRITE_FAILED:UNFITTED_SECOND_DIAGNOSTIC_FAILURE" in note for note in error.value.__notes__)
                    else:
                        assert "input_execution" in saved
            assert sha256_file(target) == sealed_sha and model_calls == calls_before
            assert selector_calls["path"] == before_selector and sum(row[0] == "FIT" for row in mice_calls) == before_mice
    (tmp_path / ("aar-final-public-observation.json" if final_shards else "branch-execution-observation.json")).write_bytes(canonical_json_bytes({
        "stage_order": stage_order, "configured_c_minus_8_fixture": 56, "actual_test_process_peak": 1,
        "per_branch_m20": 20, "retention_count_per_branch_admission": 10 if final_shards else 60,
        "first_native_audit_count": len(object_calls), "final_number_members": 60,
        "resource_negatives": list(damages), "new_model_fits": 0, "new_mice_chains": 0,
        "input_release_pins": True, "loader_tail_unfitted_upstream_reuse": not final_shards,
        **({"final_shards": 6, "normal_gather_native_reads": 0, "original_public_owner_and_reader": True} if final_shards else {})}))


@pytest.mark.parametrize("family", ["COX_PH", "RSF", "GBM_COX"])
def test_original_outer_input_producer_and_consumer_replay_both_fresh_branches(aar_source, tmp_path, monkeypatch, family):
    from padml.f2_kernel import _registered_partition_identity_record
    primary_input, primary_archive, policy, primary_reads, _, _ = _projected_outer_fixture(aar_source, tmp_path, monkeypatch, family)
    source = tmp_path / "projected.zip"
    sensitivity.compile_a12_outer_inputs(primary_input, primary_archive, source,
        f2_run_root=tmp_path, outer_fold=1, resource_policy=policy)
    calls, pools = _unfitted_outer_mice_workers(monkeypatch)
    archive = tmp_path / "MOCK-inputs-native.zip"
    result = sensitivity.execute_a12_outer_inputs(source, archive)
    expected = 34 if family == "COX_PH" else 64 if family == "RSF" else 124
    assert result["mice_chain_execution_count"] == expected * 20
    assert result["model_fit_count"] == result["selector_path_count"] == 0
    assert result["stage"] == "MICE_MATERIALIZED_PRE_DEVELOPMENT" and not result["stage_acceptance"]
    assert len(pools) == 1 and pools[0][0] == min(56, expected) and len(pools[0][1]) == expected
    assert not any(nested.A12_DIRECT_AAR in name for name in pools[0][1])
    assert len({name for name in pools[0][1]}) == expected
    assert [row[0] for row in calls] == ["FIT"] * expected + ["REPLAY"] * expected
    assert result["execution_report"]["mice_pool"]["actual_worker_process_peak"] == 1  # MOCK serial pool, not a utilization measurement
    def no_more_mice(*args, **kwargs):
        pytest.fail("NORMAL_INPUT_READER_MUST_NOT_REPLAY_MICE")
    monkeypatch.setattr(sensitivity, "_run_a12_total_mice_input", no_more_mice)
    opened = sensitivity.materialize_a12_outer_inputs(archive, None, tmp_path / "readback", input_bundle=source)
    assert [row[0] for row in calls] == ["FIT"] * expected + ["REPLAY"] * expected
    assert len(opened["mice_views"]) == expected
    assert opened["materialization_resources"]["reservation"]["replay_reserved_bytes"] == 0
    assert all(row["numerical_read"] for row in opened["view_replay_reports"])
    assert len(pools) == 1
    assert primary_reads == ["ORIGINAL_F4_PRIMARY_NATIVE_READER_STUB", "ORIGINAL_ACCEPTED_F4_SOURCE_READER_STUB",
                             "ORIGINAL_F1_M20_READER_STUB"]  # no additional global read during remote replay
    assert set(opened["branches"]) == set(nested.AAR_ESTIMANDS)
    assert opened["branches"][nested.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT]["selected_parents"] is None
    assert opened["branches"][nested.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT]["inner_count"] == 15
    assert opened["branches"][nested.A12_DIRECT_AAR]["selected_parents"] == ["Age"]
    record = sensitivity._a12_outer_input_record(opened)
    if family == "GBM_COX":
        for branch in nested.AAR_ESTIMANDS:
            scoped = sensitivity.materialize_a12_outer_inputs(archive, None, tmp_path / ("scoped-" + branch),
                input_bundle=source, final_task_ids=[f"O1_{branch}_M07"])
            assert set(scoped["branches"]) == {branch} and scoped["source_input_record"] == record
            assert sensitivity._a12_outer_input_record(scoped) == {**record, "branches": {branch: record["branches"][branch]}}
            assert scoped["branches"][branch]["inner_count"] == scoped["branches"][branch]["stop_count"] == 15
            assert all(len(row["covariates"]["members"]) == len(row["fit_covariate_members"]) == 20
                       for row in scoped["branches"][branch]["partitions"])
            assert not (tmp_path / ("scoped-" + branch) / "archive/input.zip").exists()
            assert scoped["input_expansion_resources"]["native"]["expanded_bytes"] < opened["input_expansion_resources"]["native"]["expanded_bytes"]
    training = set(aar_source[3]["primary_training_context"]["training_ids"])
    for estimand, branch in opened["branches"].items():
        assert branch["status"] == "MICE_MATERIALIZED_PRE_DEVELOPMENT"
        outer = next(row for row in branch["partitions"] if row["kind"] == "OUTER")
        assert "evaluation_response" not in outer
        with pytest.raises(ContractError, match="F2_REGISTERED_PARTITION_IDENTITY_INVALID"):
            _registered_partition_identity_record(outer)  # legacy consumers must still require actual evaluation response
        identity = _registered_partition_identity_record(outer, prediction_only=True)
        assert identity["evaluation_scope"] == "PREDICTION_ONLY"
        assert not any(name.startswith("evaluation_response") for name in identity)
        for changed in ({"evaluation_response": {}}, {"kind": "INNER"}):
            with pytest.raises(ContractError, match="F2_REGISTERED_PARTITION_IDENTITY_INVALID"):
                _registered_partition_identity_record({**outer, **changed}, prediction_only=True)
        assert record["branches"][estimand]["partitions"][0] == identity
        for partition in branch["partitions"]:
            assert set(f5._response_rows(Path(partition["fit_response"]["path"]).read_bytes())[1]) <= training
            if partition["kind"] != "OUTER":
                assert set(f5._response_rows(partition["evaluation_response"]["private_bytes"])[1]) <= training
        reader = csv.DictReader(io.StringIO((Path(outer["covariates"]["input_dir"]) / "imp01.csv").read_text()))
        if estimand == nested.A12_DIRECT_AAR:
            assert {"AST", "ALT", "AST_ALT"} <= set(reader.fieldnames)
        else:
            assert not {"AST", "ALT", "AST_ALT"} & set(reader.fieldnames)
            originals = {row["Patient_ID"]: row for row in csv.DictReader(io.StringIO(aar_source[1].decode()))}
            donors = {}
            # The independent source view fixes its own row order; it need
            # not equal the raw cohort's order (F1 orders registry IDs).
            with zipfile.ZipFile(source) as projected:
                for role in ("ANALYSIS", "APPLICATION"):
                    with zipfile.ZipFile(io.BytesIO(projected.read(f"mice-inputs/{estimand}/OUTER_{role}.zip"))) as view:
                        view_rows = list(csv.DictReader(io.StringIO(view.read("covariates.csv").decode())))
                    donor_rows = [row for row in view_rows if row["Patient_ID"] in training and row["HGB"].strip()]
                    donors[role] = donor_rows[0 if role == "ANALYSIS" else -1]["HGB"]
            assert donors["ANALYSIS"] != donors["APPLICATION"]
            for row in reader:
                assert row["Age"] == originals[row["Patient_ID"]]["Age"]
                expected_hgb = originals[row["Patient_ID"]]["HGB"] or donors["ANALYSIS" if row["Patient_ID"] in training else "APPLICATION"]
                assert row["HGB"] == expected_hgb
    entries = sensitivity.read_safe_zip(archive)
    assert entries["input.zip"] == source.read_bytes()
    assert strict_json_bytes(entries["execution.json"]) == result["execution_report"]
    assert Path(result["work_evidence_retained"]).is_dir()
    assert len(list((Path(result["work_evidence_retained"]) / "prepared").glob("*/*/native/imp01.rds"))) == expected
    assert "mice_views" not in sensitivity._a12_outer_input_record(opened)
    for name, raw in entries.items():
        if name.startswith("views/"):
            with zipfile.ZipFile(io.BytesIO(raw)) as view_archive:
                assert not any(member.startswith("native/") for member in view_archive.namelist())
                assert len([member for member in view_archive.namelist() if member.startswith("imputations/")]) == 20
    if family == "COX_PH":
        for damage in (None, {}, {"not-a-view": {}}):
            manifest = strict_json_bytes(entries["a12-inputs.json"])
            manifest["mice_views"] = damage
            path = tmp_path / ("missing-numbers-" + str(len(str(damage))) + ".zip")
            write_deterministic_zip(path, {**entries, "a12-inputs.json": canonical_json_bytes(nested._sealed({
                key: item for key, item in manifest.items() if key != "identity_sha256"}))})
            with pytest.raises(ContractError, match="INPUT_INDEX_INVALID|NUMERICAL_VIEW_COVERAGE_INVALID|INPUT_ARCHIVE_SOURCE_MISMATCH"):
                sensitivity.materialize_a12_outer_inputs(path, None, tmp_path / (path.stem + "-read"), input_bundle=source)
        # Same rows/seeds are not interchangeable: the retained native input
        # must belong to its own estimand, even after an attacker rehashes ZIPs.
        total_name = f"views/{nested.A12_TOTAL_AAR}/OUTER_ANALYSIS.zip"
        replacement = f"views/{nested.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT}/OUTER_ANALYSIS.zip"
        damaged = {**entries, total_name: entries[replacement]}
        manifest = strict_json_bytes(damaged["a12-inputs.json"])
        manifest["members"][total_name] = {"sha256": sha256_bytes(damaged[total_name]), "size_bytes": len(damaged[total_name])}
        manifest["identity_sha256"] = nested._sha({key: value for key, value in manifest.items() if key != "identity_sha256"})
        damaged["a12-inputs.json"] = canonical_json_bytes(manifest)
        bad = tmp_path / "wrong-branch.zip"
        write_deterministic_zip(bad, damaged)
        before = len(calls)
        with pytest.raises(ContractError, match="ZIP_MEMBER_DECLARATION_MISMATCH") as failure:
            sensitivity.materialize_a12_outer_inputs(bad, None, tmp_path / "bad-readback", input_bundle=source)
        assert len(calls) == before
        assert any("F5_A12_INPUT_REPLAY_EVIDENCE" in note for note in failure.value.__notes__)


def test_projected_inputs_reject_heldout_response_in_metadata_and_archive_before_pool(aar_source, tmp_path, monkeypatch):
    primary_input, primary_archive, policy, _, _, _ = _projected_outer_fixture(aar_source, tmp_path, monkeypatch, "COX_PH")
    source = tmp_path / "projected.zip"
    sensitivity.compile_a12_outer_inputs(primary_input, primary_archive, source,
        f2_run_root=tmp_path, outer_fold=1, resource_policy=policy)
    source_entries = sensitivity.read_safe_zip(source)
    monkeypatch.setattr(sensitivity, "_bounded_ordered_spawn", lambda *a, **k: pytest.fail("NO_POOL_START"))
    for damage in ("metadata", "archive", "missing_direct"):
        entries = dict(source_entries)
        value = strict_json_bytes(entries["a12-inputs.json"])
        if damage == "metadata":
            value["definitions"][0]["evaluation_response"] = {"event_count": 1}
        elif damage == "archive":
            entries["heldout-response.csv"] = b"Patient_ID,All_Cause_Death,Death_Followup_months\nUNFITTED,1,20\n"
            value["members"]["heldout-response.csv"] = {"sha256": sha256_bytes(entries["heldout-response.csv"]),
                                                       "size_bytes": len(entries["heldout-response.csv"])}
        else:
            name = next(name for name in entries if name.startswith("direct/"))
            entries.pop(name)
            value["members"].pop(name)
        value["identity_sha256"] = nested._sha({key: item for key, item in value.items() if key != "identity_sha256"})
        entries["a12-inputs.json"] = canonical_json_bytes(value)
        path, output = tmp_path / f"{damage}.zip", tmp_path / f"{damage}-native.zip"
        write_deterministic_zip(path, entries)
        with pytest.raises(ContractError) as failure:
            sensitivity.execute_a12_outer_inputs(path, output)
        assert not output.exists() and any("F5_A12_INPUT_EXECUTION_EVIDENCE" in note for note in failure.value.__notes__)


def test_projected_input_execution_resource_failure_precedes_mice_start(aar_source, tmp_path, monkeypatch):
    primary_input, primary_archive, policy, _, _, _ = _projected_outer_fixture(aar_source, tmp_path, monkeypatch, "COX_PH")
    source = tmp_path / "projected.zip"
    sensitivity.compile_a12_outer_inputs(primary_input, primary_archive, source,
        f2_run_root=tmp_path, outer_fold=1, resource_policy=policy)
    calls, pools = _unfitted_outer_mice_workers(monkeypatch)
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda root: {
        "effective_cpus": 64, "available_memory_bytes": 0, "scratch_available_bytes": 10**10, "scratch_root": str(root)})
    target = tmp_path / "not-admitted.zip"
    with pytest.raises(ContractError):
        sensitivity.execute_a12_outer_inputs(source, target)
    assert not calls and not pools and not target.exists()
    assert (tmp_path / "not-admitted.zip.work/input/a12-inputs.json").is_file()


@pytest.mark.parametrize("option", ["workers", "outer_fold", "f2_run_root", "f1_runtime_root"])
def test_projected_input_execution_rejects_manual_cpu_cap_and_global_authority(tmp_path, monkeypatch, option):
    source, target = tmp_path / "projected.zip", tmp_path / "never.zip"
    write_deterministic_zip(source, {"a12-inputs.json": b"{}"})
    monkeypatch.setattr(sensitivity, "_load_a12_projected_outer_inputs", lambda *a: pytest.fail("NO_INPUT_OPEN"))
    with pytest.raises(ContractError, match="F5_A12_PROJECTED_ARGUMENT_SCOPE_INVALID"):
        sensitivity.execute_a12_outer_inputs(source, target, **{option: 1 if option in {"workers", "outer_fold"} else tmp_path})
    assert not target.exists() and not (tmp_path / "never.zip.work").exists()


def test_projected_input_worker_failure_retains_original_inputs_and_partial_native_logs(aar_source, tmp_path, monkeypatch):
    primary_input, primary_archive, policy, _, _, _ = _projected_outer_fixture(aar_source, tmp_path, monkeypatch, "COX_PH")
    source = tmp_path / "projected.zip"
    sensitivity.compile_a12_outer_inputs(primary_input, primary_archive, source,
        f2_run_root=tmp_path, outer_fold=1, resource_policy=policy)
    calls, pools = _unfitted_outer_mice_workers(monkeypatch)
    def failed_mice(command, **kwargs):
        kwargs["stderr"].write(b"UNFITTED_NATIVE_FAILURE_PARTIAL_LOG")
        return subprocess.CompletedProcess(command, 1)
    monkeypatch.setattr(sensitivity.subprocess, "run", failed_mice)
    target = tmp_path / "failed-native.zip"
    with pytest.raises(ContractError, match="F5_A12_MICE_NATIVE_EXECUTION_FAILED"):
        sensitivity.execute_a12_outer_inputs(source, target)
    root = tmp_path / "failed-native.zip.work"
    assert not calls and len(pools) == 1 and not target.exists()
    assert (root / "input/a12-inputs.json").is_file()
    assert strict_json_bytes((root / "execution.json").read_bytes())["mice_pool"]["status"] == "FAILED"
    logs = list(root.glob(".a12-mice-*/stderr.txt"))
    assert len(logs) == 1 and logs[0].read_bytes() == b"UNFITTED_NATIVE_FAILURE_PARTIAL_LOG"
    with pytest.raises(ContractError, match="F5_A12_INPUT_WORK_EXISTS"):
        sensitivity.execute_a12_outer_inputs(source, target)
    assert len(pools) == 1


def test_nested_aar_worker_keeps_native_temporary_files_on_observed_scratch(aar_source, tmp_path, monkeypatch):
    contract, covariates, response, source, policy = aar_source
    path = tmp_path / "input.zip"
    write_deterministic_zip(path, sensitivity._a12_total_mice_input_members(contract, covariates, response, 1,
        "OUTER_ANALYSIS", nested_source={**source, "estimand": nested.A12_TOTAL_AAR}, resource_policy=policy))
    root = tmp_path / "observed-native-scratch"
    root.mkdir()
    calls = []
    def no_fit(command, **kwargs):
        assert kwargs["cwd"] == root
        assert all(kwargs["env"].get(key) == str(root) for key in ("TMPDIR", "TMP", "TEMP"))
        assert all(kwargs["env"][key] == "1" for key in runtime.THREAD_ENV)
        calls.append(command)
        return subprocess.CompletedProcess(command, 0)
    monkeypatch.setattr(sensitivity.subprocess, "run", no_fit)
    observed = sensitivity._run_a12_total_mice_input(path, root)
    assert len(calls) == 1 and observed["execution_report"]["actual_worker_process_peak"] == 1


def test_aar_native_materialization_reserves_all_views_before_first_replay(tmp_path, monkeypatch):
    path = tmp_path / "UNFITTED-view.zip"
    write_deterministic_zip(path, {"imputations/imp01.csv": b"x" * 1000, "native/imp01.rds": b"UNFITTED"})
    policy = {"configured_worker_ceiling": "EXECUTION_HOST_C_MINUS_8", "memory_bytes_per_worker": 1,
              "scratch_bytes_per_worker": 1, "memory_reserve_bytes": 0, "scratch_reserve_bytes": 0,
              "transfer_archive_worker_ceiling": 1000}
    keys = [(nested.A12_TOTAL_AAR, "OUTER_ANALYSIS"), (nested.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT, "OUTER_ANALYSIS")]
    opened = {"input": {"mice_inputs": [{"estimand": branch, "view_id": view} for branch, view in keys],
                        "resource_policy": policy}}
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda root: {
        "effective_cpus": 64, "available_memory_bytes": 10**10, "scratch_available_bytes": 3000, "scratch_root": str(root)})
    monkeypatch.setattr(sensitivity, "materialize_a12_total_mice_view", lambda *a, **k: pytest.fail("NO_NATIVE_REPLAY"))
    target = tmp_path / "not-admitted"
    with pytest.raises(ContractError, match="RESOURCE_ADMISSION_ZERO"):
        sensitivity._materialize_a12_projected_branches(opened, dict.fromkeys(keys, path), target, retain_evidence=True)
    assert not target.exists()


@pytest.mark.parametrize("role", ["ANALYSIS", "APPLICATION"])
def test_a12_view_worker_publishes_original_first_audit_numbers(aar_source, tmp_path, monkeypatch, role):
    contract, covariates, response, source, policy = aar_source
    input_path, target = tmp_path / "input.zip", tmp_path / "numerical.zip"
    write_deterministic_zip(input_path, sensitivity._a12_total_mice_input_members(contract, covariates, response,
        1, "OUTER_" + role, nested_source={**source, "estimand": nested.A12_TOTAL_AAR}, resource_policy=policy))
    calls, _ = _unfitted_outer_mice_workers(monkeypatch)
    result = sensitivity.execute_a12_total_mice_bundle(input_path, target,
        numerical_output=True, retained_bytes_limit=128 * 1024**2)
    owner = input_path.with_name(input_path.name + ".native-work")
    assert [row[0] for row in calls] == ["FIT", "REPLAY"]
    assert strict_json_bytes(target.with_name(target.name + ".json").read_bytes()) == result
    assert result["numerical_view"]["native_archive"] == {
        "sha256": sha256_file(owner / "native-view.zip"), "size_bytes": (owner / "native-view.zip").stat().st_size}
    assert result["sha256"] == sha256_file(target)
    assert result["resource_release"]["owner"] == "AAR_MICE_VIEW:1:" + nested.A12_TOTAL_AAR + "/OUTER_" + role
    assert result["numerical_view"]["members"]["input.zip"]["sha256"] == sha256_file(input_path)
    assert (owner / "first-audit/replay/spec.json").is_file()
    assert len(list((owner / "native").glob("*.rds"))) == 20
    with pytest.raises(ContractError, match="COORDINATE_ALREADY_STARTED"):
        sensitivity.execute_a12_total_mice_bundle(input_path, tmp_path / "renamed.zip",
            numerical_output=True, retained_bytes_limit=128 * 1024**2)
    assert [row[0] for row in calls] == ["FIT", "REPLAY"]
    owner.rename(tmp_path / "retained-execution-owner")
    monkeypatch.setattr(sensitivity, "_run_a12_total_mice_input", lambda *args, **kwargs: pytest.fail("NO_NATIVE_FALLBACK"))
    reopened = sensitivity.materialize_a12_total_mice_view(input_path, target, tmp_path / "numeric-reader",
        numerical_view=result["numerical_view"])
    assert reopened["numerical_view"] == result["numerical_view"]
    with zipfile.ZipFile(target) as archive:
        assert not any(name.startswith("native/") for name in archive.namelist())
        assert len([name for name in archive.namelist() if name.startswith("imputations/")]) == 20


@pytest.mark.parametrize("failure", ["FIT", "REPLAY", "values", "projection"])
def test_a12_view_first_audit_failure_keeps_original_attempt(aar_source, tmp_path, monkeypatch, failure):
    from padml import f4_compact
    contract, covariates, response, source, policy = aar_source
    input_path, target = tmp_path / "input.zip", tmp_path / "numerical.zip"
    write_deterministic_zip(input_path, sensitivity._a12_total_mice_input_members(contract, covariates, response,
        1, "OUTER_ANALYSIS", nested_source={**source, "estimand": nested.A12_TOTAL_AAR}, resource_policy=policy))
    calls, _ = _unfitted_outer_mice_workers(monkeypatch)
    original = sensitivity._run_a12_total_mice_input
    def run(*args, **kwargs):
        result = original(*args, **kwargs)
        if failure == ("REPLAY" if kwargs.get("native") is not None else "FIT"):
            raise ContractError("UNFITTED_NATIVE_FAILURE")
        return result
    monkeypatch.setattr(sensitivity, "_run_a12_total_mice_input", run)
    if failure == "values":
        def values(*args, **kwargs):
            raise ContractError("UNFITTED_VALUES_FAILURE")
        monkeypatch.setattr(f4_compact, "_full_pipeline_mice_completed_values", values)
    if failure == "projection":
        original_write = sensitivity.write_deterministic_zip
        def write(path, *args, **kwargs):
            if path == target:
                path.write_bytes(b"UNFITTED_PARTIAL_PROJECTION")
                raise ContractError("UNFITTED_PROJECTION_FAILURE")
            return original_write(path, *args, **kwargs)
        monkeypatch.setattr(sensitivity, "write_deterministic_zip", write)
    with pytest.raises(ContractError, match="UNFITTED_.*FAILURE"):
        sensitivity.execute_a12_total_mice_bundle(input_path, target,
            numerical_output=True, retained_bytes_limit=128 * 1024**2)
    owner = input_path.with_name(input_path.name + ".native-work")
    assert owner.is_dir() and (owner / "stdout.txt").is_file() and (owner / "stderr.txt").is_file()
    assert not target.with_name(target.name + ".json").exists()
    assert (owner / "native-view.zip").exists() == (failure != "FIT")
    before = list(calls)
    with pytest.raises(ContractError, match="COORDINATE_ALREADY_STARTED"):
        sensitivity.execute_a12_total_mice_bundle(input_path, tmp_path / "renamed.zip",
            numerical_output=True, retained_bytes_limit=128 * 1024**2)
    assert calls == before


@pytest.mark.parametrize("resource", ["memory", "scratch"])
@pytest.mark.parametrize("short_by", [0, 1])
def test_a12_view_numbers_admit_before_csv_and_fit(aar_source, tmp_path, monkeypatch, resource, short_by):
    contract, covariates, response, source, policy = aar_source
    input_path, target = tmp_path / "input.zip", tmp_path / "numerical.zip"
    write_deterministic_zip(input_path, sensitivity._a12_total_mice_input_members(contract, covariates, response,
        1, "OUTER_ANALYSIS", nested_source={**source, "estimand": nested.A12_TOTAL_AAR}, resource_policy=policy))
    retained = 128 * 1024**2
    effective = sensitivity._a12_mice_numerical_policy(input_path, retained)
    observation = {"effective_cpus": 64, "available_memory_bytes": 10**12,
                   "scratch_available_bytes": 10**12, "scratch_root": str(tmp_path)}
    key = "available_memory_bytes" if resource == "memory" else "scratch_available_bytes"
    observation[key] = effective[resource + "_reserve_bytes"] + effective[resource + "_bytes_per_worker"] - short_by
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda root: observation)
    reads = []
    original_read = zipfile.ZipFile.open
    def read(archive, member, *args, **kwargs):
        name = member.filename if isinstance(member, zipfile.ZipInfo) else member
        if name == "covariates.csv":
            reads.append(name)
        return original_read(archive, member, *args, **kwargs)
    monkeypatch.setattr(zipfile.ZipFile, "open", read)
    def stopped(*args, **kwargs):
        raise ContractError("UNFITTED_ADMITTED_STOP_BEFORE_FIT")
    monkeypatch.setattr(sensitivity, "_run_a12_total_mice_input", stopped)
    with pytest.raises(ContractError, match="RESOURCE_ADMISSION_ZERO" if short_by else "UNFITTED_ADMITTED_STOP_BEFORE_FIT"):
        sensitivity.execute_a12_total_mice_bundle(input_path, target, numerical_output=True, retained_bytes_limit=retained)
    assert bool(reads) == (short_by == 0)
    assert input_path.with_name(input_path.name + ".native-work").exists() == (short_by == 0)


def test_a12_gather_transport_preserves_historical_executor(aar_source, tmp_path, monkeypatch):
    """Original gather reader across executors; all scientific leaves UNFITTED."""
    primary_input, primary_archive, policy, _, _, _ = _projected_outer_fixture(
        aar_source, tmp_path, monkeypatch, "COX_PH")
    source = tmp_path / "projected.zip"
    sensitivity.compile_a12_outer_inputs(primary_input, primary_archive, source,
        f2_run_root=tmp_path, outer_fold=1, resource_policy=policy)
    with zipfile.ZipFile(source) as archive:
        projected = strict_json_bytes(archive.read("a12-inputs.json"))
    names = [f"{row['estimand']}/{row['view_id']}" for row in projected["mice_inputs"]]
    calls, _ = _unfitted_outer_mice_workers(monkeypatch)
    produced = sensitivity.execute_a12_outer_inputs(source, tmp_path / "UNFITTED-views", view_ids=names,
        retained_bytes_per_view=128 * 1024**2)
    before = list(calls)
    def forbidden(*args, **kwargs):
        pytest.fail("GATHER_READER_MUST_NOT_FIT_OR_REPLAY_NATIVE")
    monkeypatch.setattr(sensitivity, "_run_a12_total_mice_input", forbidden)
    monkeypatch.setattr(sensitivity, "_bounded_ordered_spawn", forbidden)
    gathered = tmp_path / "UNFITTED-gather.zip"
    sensitivity.execute_a12_outer_inputs(source, gathered,
        view_results=[Path(path) for path in produced["view_result_paths"]])
    entries = sensitivity.read_safe_zip(gathered)
    execution = strict_json_bytes(entries["execution.json"])
    current = sha256_bytes(canonical_json_bytes(f4._f45_source_member_sha256()))
    historical = "a" * 64
    assert current != historical
    execution["numerical_transport"]["executor_source_identity"] = historical

    def packet(value):
        members = {**entries, "execution.json": canonical_json_bytes(value)}
        index = strict_json_bytes(entries["a12-inputs.json"])
        index["members"]["execution.json"] = {"sha256": sha256_bytes(members["execution.json"]),
                                              "size_bytes": len(members["execution.json"])}
        index["identity_sha256"] = nested._sha({key: row for key, row in index.items()
                                                 if key != "identity_sha256"})
        members["a12-inputs.json"] = canonical_json_bytes(index)
        return members

    historical_path = tmp_path / "UNFITTED-historical-gather.zip"
    write_deterministic_zip(historical_path, packet(execution))
    preserved = sha256_file(historical_path)
    opened = sensitivity.materialize_a12_outer_inputs(historical_path, None, tmp_path / "historical-reader",
        input_bundle=source, execution_scratch_reserve_bytes=0)
    assert set(opened["branches"]) == set(nested.AAR_ESTIMANDS)
    assert set(opened["mice_views"]) == set(names)
    assert all(row["numerical_read"] for row in opened["view_replay_reports"])
    assert opened["input_resource_release"] == execution["resource_release"]
    assert calls == before and sha256_file(historical_path) == preserved
    with zipfile.ZipFile(historical_path) as archive:
        assert archive.read("execution.json") == canonical_json_bytes(execution)
    for damage in ("unbound_executor", "invalid_executor", "worker_bool", "worker_budget"):
        changed = copy.deepcopy(execution)
        transport = changed["numerical_transport"]
        if damage == "unbound_executor":
            transport["executor_source_identity"] = "b" * 64
            members = {**packet(execution), "execution.json": canonical_json_bytes(changed)}
        else:
            if damage == "invalid_executor":
                transport["executor_source_identity"] = "UNFITTED-not-a-sha256"
            elif damage == "worker_bool":
                transport["execution_worker_memory_bytes"] = True
            else:
                transport["execution_worker_memory_bytes"] += 1
            members = packet(changed)
        damaged = tmp_path / (damage + ".zip")
        write_deterministic_zip(damaged, members)
        reason = ("ZIP_MEMBER_DECLARATION_MISMATCH:execution.json" if damage == "unbound_executor" else
                  "INVALID_SHA256:a12.gather_executor" if damage == "invalid_executor" else
                  "F5_A12_GATHER_POST_RELEASE_ADMISSION_INVALID")
        with pytest.raises(ContractError, match=reason):
            sensitivity.materialize_a12_outer_inputs(damaged, None, tmp_path / ("reader-" + damage),
                input_bundle=source, execution_scratch_reserve_bytes=0)
    assert calls == before and sha256_file(historical_path) == preserved
    assert current == sha256_bytes(canonical_json_bytes(f4._f45_source_member_sha256()))


def test_a12_disjoint_view_batches_gather_original_complete_numbers(aar_source, tmp_path, monkeypatch):
    import shutil
    primary_input, primary_archive, policy, primary_reads, _, _ = _projected_outer_fixture(
        aar_source, tmp_path, monkeypatch, "COX_PH")
    source = tmp_path / "projected.zip"
    sensitivity.compile_a12_outer_inputs(primary_input, primary_archive, source,
        f2_run_root=tmp_path, outer_fold=1, resource_policy=policy)
    with zipfile.ZipFile(source) as archive:
        index = strict_json_bytes(archive.read("a12-inputs.json"))
    names = [f"{row['estimand']}/{row['view_id']}" for row in index["mice_inputs"]]
    assert len(names) == 34
    calls, pools = _unfitted_outer_mice_workers(monkeypatch)
    returned = tmp_path / "returned-numbers-only"
    returned.mkdir()
    paths = []
    for shard in range(6):
        assigned = list(reversed(names[shard::6]))
        result = sensitivity.execute_a12_outer_inputs(source, tmp_path / f"shard-{shard}", view_ids=assigned,
            retained_bytes_per_view=128 * 1024**2)
        assert result["mice_chain_execution_count"] == 20 * len(assigned)
        assert set(result["view_ids"]) == set(assigned) and not result["stage_acceptance"]
        reservation = result["execution_report"]["effective_policy"]
        assert reservation["scratch_reserve_bytes"] == (policy["scratch_reserve_bytes"] + len(assigned) * 128 * 1024**2
                                                       + result["execution_report"]["batch_report_reserved_bytes"])
        handles = strict_json_bytes((tmp_path / f"shard-{shard}" / "mice-results.json").read_bytes())
        assert len(handles) == len(assigned) and all("numerical_view" not in item for item in handles)
        assert all(sha256_file(Path(item["result_path"])) == item["result_sha256"] for item in handles)
        assert result["execution_report"]["mice_pool"]["configured_worker_ceiling"] == 56
        for name in result["view_result_paths"]:
            original = Path(name)
            destination = returned / str(len(paths))
            destination.mkdir()
            path = destination / "numerical.zip.json"
            shutil.copyfile(original, path)
            shutil.copyfile(original.with_suffix(""), path.with_suffix(""))
            paths.append(path)
    assert len(pools) == 6 and [row[0] for row in calls] == ["FIT", "REPLAY"] * 34
    with pytest.raises(ContractError, match="COORDINATE_ALREADY_STARTED"):
        sensitivity.execute_a12_outer_inputs(source, tmp_path / "renamed-report", view_ids=[names[0]],
            retained_bytes_per_view=128 * 1024**2)
    source.with_name(source.name + ".mice").rename(tmp_path / "retained-execution-owners")
    before = list(calls)
    def forbidden(*args, **kwargs):
        pytest.fail("GATHER_MUST_NOT_FIT_OR_REPLAY_NATIVE")
    monkeypatch.setattr(sensitivity, "_run_a12_total_mice_input", forbidden)
    monkeypatch.setattr(sensitivity, "_bounded_ordered_spawn", forbidden)
    target = tmp_path / "complete-inputs.zip"
    release_calls = []
    original_release = runtime.release_step_resources
    def release(files, **kwargs):
        assert kwargs["owner"] == "AAR_INPUT_GATHER:1:" + index["identity_sha256"]
        roots = (target.with_name(target.name + ".work") / "input",
                 target.with_name(target.name + ".work") / "prepared")
        assert files and all(any(path.is_relative_to(root) for root in roots) for path in files)
        assert not set(files).intersection({source, target, *paths, *(path.with_suffix("") for path in paths)})
        pins = {path: (sha256_file(path), path.stat().st_size) for path in files}
        result = original_release(files, **kwargs)
        assert all(path.is_file() and (sha256_file(path), path.stat().st_size) == ref for path, ref in pins.items())
        release_calls.append(result)
        return result
    monkeypatch.setattr(runtime, "release_step_resources", release)
    gathered = sensitivity.execute_a12_outer_inputs(source, target, view_results=list(reversed(paths)))
    assert gathered["mice_chain_execution_count"] == 0
    assert gathered["execution_report"]["source_mice_chain_count"] == 680
    assert len(release_calls) == 1 and gathered["execution_report"]["resource_release"] == release_calls[0]
    opened = sensitivity.materialize_a12_outer_inputs(target, None, tmp_path / "complete-reader", input_bundle=source)
    assert opened["input_resource_release"] == release_calls[0]
    assert set(opened["branches"]) == set(nested.AAR_ESTIMANDS) and set(opened["mice_views"]) == set(names)
    assert opened["materialization_resources"]["reservation"]["replay_reserved_bytes"] == 0
    assert all(row["numerical_read"] for row in opened["view_replay_reports"])
    assert opened["branches"][nested.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT]["selected_parents"] is None
    assert primary_reads == ["ORIGINAL_F4_PRIMARY_NATIVE_READER_STUB", "ORIGINAL_ACCEPTED_F4_SOURCE_READER_STUB",
                             "ORIGINAL_F1_M20_READER_STUB"]
    for damage in ("owner", "memory", "post_admission", "admission_bool", "legacy_unknown"):
        entries = sensitivity.read_safe_zip(target)
        execution = strict_json_bytes(entries["execution.json"])
        if damage == "owner":
            execution["resource_release"]["owner"] = "AAR_INPUT_GATHER:2:" + index["identity_sha256"]
        elif damage == "memory":
            execution["resource_release"]["after"]["started_ns"] = execution["resource_release"]["before"]["started_ns"] - 1
        elif damage == "post_admission":
            execution["numerical_transport"]["after_release"]["resource_admission"]["admitted_worker_ceiling"] += 1
        elif damage == "admission_bool":
            execution["numerical_transport"]["after_release"]["resource_admission"]["admitted_worker_ceiling"] = True
        else:
            del execution["resource_release"]
            del execution["numerical_transport"]["after_release"]
        entries["execution.json"] = canonical_json_bytes(execution)
        document = strict_json_bytes(entries["a12-inputs.json"])
        document["members"]["execution.json"] = {"sha256": sha256_bytes(entries["execution.json"]),
                                                "size_bytes": len(entries["execution.json"])}
        document["identity_sha256"] = sha256_bytes(canonical_json_bytes({k: v for k, v in document.items()
                                                                       if k != "identity_sha256"}))
        entries["a12-inputs.json"] = canonical_json_bytes(document)
        damaged = tmp_path / ("gather-" + damage + ".zip")
        write_deterministic_zip(damaged, entries)
        if damage == "legacy_unknown":
            legacy = sensitivity.materialize_a12_outer_inputs(damaged, None, tmp_path / ("reader-" + damage), input_bundle=source)
            assert legacy["input_resource_release"]["status"] == "UNKNOWN"
        else:
            with pytest.raises(ContractError, match="RELEASE|ADMISSION"):
                sensitivity.materialize_a12_outer_inputs(damaged, None, tmp_path / ("reader-" + damage), input_bundle=source)
    damages = ("missing", "duplicate", "missing_numbers", "missing_audit", "size_bool", "admission_bool",
               "unknown_member", "seed", "extra_native", "swapped_release")
    for damage in damages:
        damaged_paths = list(paths)
        if damage == "missing":
            damaged_paths.pop()
        elif damage == "duplicate":
            damaged_paths[-1] = damaged_paths[0]
        else:
            directory = tmp_path / ("damage-" + damage)
            directory.mkdir()
            path = directory / "numerical.zip.json"
            record = strict_json_bytes(paths[0].read_bytes())
            if damage == "missing_numbers":
                del record["numerical_view"]
            elif damage == "missing_audit":
                del record["first_audit_execution_report"]
            elif damage == "size_bool":
                record["size_bytes"] = True
            elif damage == "admission_bool":
                record["resource_admission"]["admitted_worker_ceiling"] = True
            elif damage == "unknown_member":
                record["UNEXPECTED"] = "NOT_AN_ORIGINAL_RESULT_FIELD"
            elif damage == "seed":
                record["numerical_view"]["spec"]["chain_seeds"][0] += 1
            elif damage == "swapped_release":
                record["resource_release"] = strict_json_bytes(paths[1].read_bytes())["resource_release"]
            if damage == "extra_native":
                entries = sensitivity.read_safe_zip(paths[0].with_suffix(""))
                write_deterministic_zip(path.with_suffix(""), {**entries, "native/extra.rds": b"UNFITTED"})
                record.update(sha256=sha256_file(path.with_suffix("")), size_bytes=path.with_suffix("").stat().st_size)
            else:
                shutil.copyfile(paths[0].with_suffix(""), path.with_suffix(""))
            path.write_bytes(canonical_json_bytes(record))
            damaged_paths[0] = path
        failed = tmp_path / ("rejected-" + damage + ".zip")
        with pytest.raises(ContractError):
            sensitivity.execute_a12_outer_inputs(source, failed, view_results=damaged_paths)
        assert not failed.exists() and failed.with_name(failed.name + ".work").is_dir()
    assert calls == before
    # A real post-release admission refusal must preserve its already measured
    # release and fresh low-memory observation, without emitting a final ZIP.
    target = tmp_path / "post-release-zero.zip"
    original_observation = runtime.observe_execution_resources
    release_finished = []
    def mark_release(files, **kwargs):
        result = release(files, **kwargs)
        release_finished.append(True)
        return result
    def refuse_after_release(root):
        observation = original_observation(root)
        return {**observation, "available_memory_bytes": 1} if release_finished else observation
    monkeypatch.setattr(runtime, "release_step_resources", mark_release)
    monkeypatch.setattr(runtime, "observe_execution_resources", refuse_after_release)
    with pytest.raises(ContractError, match="RESOURCE_ADMISSION_ZERO"):
        sensitivity.execute_a12_outer_inputs(source, target, view_results=paths)
    assert release_finished == [True] and not target.exists() and calls == before
    failed_execution = strict_json_bytes((target.with_name(target.name + ".work") / "execution.json").read_bytes())
    assert failed_execution["resource_release"] == release_calls[-1]
    post = failed_execution["numerical_transport"]["after_release"]
    assert post["resource_observation"]["available_memory_bytes"] == 1 and "resource_admission" not in post
    (tmp_path / "disjoint-view-observation.json").write_bytes(canonical_json_bytes({
        "fixture_disjoint_shards": 6, "actual_remote_host_count": 1, "whole_view_count": 34,
        "unfitted_fit_calls": 34, "first_native_audit_calls": 34, "gather_native_calls": 0,
        "new_actual_mice_chains": 0, "new_actual_model_fits": 0, "negative_cases": len(damages),
        "normal_source": sensitivity._a12_outer_input_record(opened)}))


@pytest.mark.parametrize("short_by", [0, 1])
def test_a12_disjoint_view_pool_reserves_whole_shard(aar_source, tmp_path, monkeypatch, short_by):
    primary_input, primary_archive, policy, _, _, _ = _projected_outer_fixture(aar_source, tmp_path, monkeypatch, "COX_PH")
    source = tmp_path / "projected.zip"
    sensitivity.compile_a12_outer_inputs(primary_input, primary_archive, source,
        f2_run_root=tmp_path, outer_fold=1, resource_policy=policy)
    names = [f"{nested.A12_TOTAL_AAR}/OUTER_{role}" for role in ("ANALYSIS", "APPLICATION")]
    retained, dispatched = 128 * 1024**2, []
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda root: {
        "effective_cpus": 64, "available_memory_bytes": 10**12,
        "scratch_available_bytes": policy["scratch_reserve_bytes"] + 2 * retained + 64 * 1024**2
                                   + policy["scratch_bytes_per_worker"] - short_by,
        "scratch_root": str(root)})
    def pool(*args, **kwargs):
        dispatched.append(kwargs["selected_slots"])
        raise ContractError("UNFITTED_ADMITTED_STOP_BEFORE_POOL")
    monkeypatch.setattr(sensitivity, "_bounded_ordered_spawn", pool)
    with pytest.raises(ContractError, match="RESOURCE_ADMISSION_ZERO" if short_by else "UNFITTED_ADMITTED_STOP_BEFORE_POOL"):
        sensitivity.execute_a12_outer_inputs(source, tmp_path / "batch", view_ids=names, retained_bytes_per_view=retained)
    assert bool(dispatched) == (short_by == 0)
    assert source.with_name(source.name + ".mice").exists() == (short_by == 0)


def test_original_f5_cli_forwards_projected_a12_input_compile_and_execute(tmp_path, monkeypatch, capsys):
    paths = [tmp_path / name for name in ("primary-input.zip", "primary.zip", "input.zip", "native.zip", "resource.json")]
    policy = {"UNFITTED_CLI_ARGUMENT": True}
    paths[-1].write_bytes(canonical_json_bytes(policy))
    calls = []
    def compile_inputs(*args, **kwargs):
        calls.append((args, kwargs))
        return {"status": "MOCK_COMPILED"}
    def execute(*args, **kwargs):
        calls.append((args, kwargs))
        return {"status": "MOCK_EXECUTED"}
    monkeypatch.setattr(sensitivity, "compile_a12_outer_inputs", compile_inputs)
    monkeypatch.setattr(sensitivity, "execute_a12_outer_inputs", execute)
    monkeypatch.setattr(sys, "argv", ["padml-f5", "compile-a12-inputs", *map(str, paths[:3]), "--f2-run-root", str(tmp_path),
                                     "--outer-fold", "1", "--resource-policy", str(paths[-1])])
    f5.main()
    assert calls[0] == (tuple(paths[:3]), {"f2_run_root": tmp_path, "outer_fold": 1, "resource_policy": policy, "f1_runtime_root": None})
    monkeypatch.setattr(sys, "argv", ["padml-f5", "a12-inputs", str(paths[2]), str(paths[3])])
    f5.main()
    assert calls[1] == ((paths[2], paths[3]), {})
    assert "MOCK_COMPILED" in capsys.readouterr().out


@pytest.mark.parametrize("mode", ["subset", "gather", "retained-gather", "mixed-retained-gather", "native-first-replay"])
def test_original_f5_cli_forwards_a12_view_coordinates(tmp_path, monkeypatch, capsys, mode):
    source, target = tmp_path / "input.zip", tmp_path / "result"
    calls = []
    def execute(*args, **kwargs):
        calls.append((args, kwargs))
        return {"status": "UNFITTED_CLI_ONLY"}
    monkeypatch.setattr(sensitivity, "execute_a12_outer_inputs", execute)
    if mode in {"subset", "native-first-replay"}:
        selected = [f"{nested.A12_TOTAL_AAR}/OUTER_ANALYSIS"]
        options = ["--view-ids", *selected, "--retained-bytes-per-view", "123456789"]
        expected = {"view_ids": selected, "retained_bytes_per_view": 123456789}
        if mode == "native-first-replay":
            primary = tmp_path / "primary-source.zip"
            options += ["--native-first-replay", "--retained-primary-source-bundle", str(primary)]
            expected.update(native_first_replay=True, retained_primary_source_bundle=primary)
    else:
        results = [tmp_path / "view-1.zip.json", tmp_path / "view-2.zip.json"]
        options = ["--view-results", *map(str, results)]
        expected = {"view_results": results}
        if mode in {"retained-gather", "mixed-retained-gather"}:
            primary, executor, packet = (tmp_path / name for name in ("primary-source.zip", "view-source.zip", "packet.zip"))
            options += ["--retained-primary-source-bundle", str(primary), "--retained-view-source-bundle", str(executor),
                        "--retained-view-batch", str(packet), "UNFITTED/original-oss-ref", "a" * 64, "123"]
            expected.update(retained_primary_source_bundle=primary, retained_view_source_bundle=executor,
                retained_view_batches=[(packet, {"object_key": "UNFITTED/original-oss-ref", "sha256": "a" * 64, "size_bytes": 123})])
            if mode == "mixed-retained-gather":
                restoration = tmp_path / "restoration-source.zip"
                options += ["--retained-view-source-bundle", str(restoration)]
                expected["retained_view_source_bundle"] = [executor, restoration]
    monkeypatch.setattr(sys, "argv", ["padml-f5", "a12-inputs", str(source), str(target), *options])
    f5.main()
    assert calls == [((source, target), expected)]
    assert strict_json_bytes(capsys.readouterr().out.encode())["status"] == "UNFITTED_CLI_ONLY"


@pytest.mark.parametrize("estimand", [nested.A12_TOTAL_AAR, nested.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT])
@pytest.mark.parametrize("view", ["OUTER_ANALYSIS", "OUTER_APPLICATION", "INNER_R2_K1_ANALYSIS", "STOP_R2_K1_APPLICATION"])
def test_nested_aar_original_mice_zip_removes_raw_channel_before_native_start(aar_source, tmp_path, estimand, view):
    contract, covariates, response, source, policy = aar_source
    legacy = sensitivity._a12_total_mice_input_members(contract, covariates, response, 1, view)
    assert {"AST", "ALT", "AST_ALT"} <= set(next(csv.reader(io.StringIO(legacy["covariates.csv"].decode()))))
    members = sensitivity._a12_total_mice_input_members(
        contract, covariates, response, 1, view, nested_source={**source, "estimand": estimand}, resource_policy=policy)
    value = strict_json_bytes(members["input.json"])
    assert value["kind"] == "PADML_NESTED_AAR_MICE_INPUT_V1"
    assert value["chain_seeds"] == strict_json_bytes(legacy["input.json"])["chain_seeds"]
    assert value["view"] == strict_json_bytes(legacy["input.json"])["view"]
    reader = csv.DictReader(io.StringIO(members["covariates.csv"].decode()))
    rows = list(reader)
    assert reader.fieldnames == [column for column in f5.load_science_authority()["science"]["mice"]["private_handoff"]["columns"]
                                if column not in {"AST", "ALT", "AST_ALT"}]
    assert [row["Patient_ID"] for row in rows] == value["view"]["row_ids"]
    assert ("response.csv" in members) == (value["view"]["role"] == "ANALYSIS")
    if "response.csv" in members:
        assert set(f5._response_rows(members["response.csv"])[1]) <= set(source["primary_training_context"]["training_ids"])
    path = tmp_path / "input.zip"
    write_deterministic_zip(path, members)
    assert sensitivity._load_a12_total_mice_input(path) == (value, members)


@pytest.mark.parametrize("damage", ["raw_channel", "heldout_response", "wrong_outer", "pending", "direct_branch"])
def test_nested_aar_mice_consumer_rejects_boundary_drift_before_subprocess(aar_source, tmp_path, monkeypatch, damage):
    contract, covariates, response, source, policy = aar_source
    members = sensitivity._a12_total_mice_input_members(contract, covariates, response, 1, "OUTER_ANALYSIS",
        nested_source={**source, "estimand": nested.A12_TOTAL_AAR}, resource_policy=policy)
    value = strict_json_bytes(members["input.json"])
    if damage == "raw_channel":
        members["covariates.csv"] = sensitivity._a12_total_mice_input_members(
            contract, covariates, response, 1, "OUTER_ANALYSIS")["covariates.csv"]
    elif damage == "heldout_response":
        patient = source["primary_training_context"]["heldout_ids"][0]
        members["response.csv"] += f"{patient},1,50\n".encode()
    elif damage == "wrong_outer":
        value["view"]["outer_fold"] = 2
    elif damage == "pending":
        value["nested_source"]["science_decision"] = nested.science_decision_template()
    else:
        value["nested_source"]["estimand"] = nested.A12_DIRECT_AAR
    members["input.json"] = canonical_json_bytes(value)
    path = tmp_path / "bad-input.zip"
    write_deterministic_zip(path, members)
    monkeypatch.setattr(sensitivity.subprocess, "run", lambda *a, **k: pytest.fail("NO_NATIVE_START"))
    with pytest.raises(ContractError):
        sensitivity.execute_a12_total_mice_bundle(path, tmp_path / "never.zip")
    assert not (tmp_path / "never.zip").exists()


@pytest.mark.parametrize("estimand", [nested.A12_TOTAL_AAR, nested.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT])
@pytest.mark.parametrize("family", nested._families())
def test_original_public_aar_compiler_native_archive_and_reader_use_projected_source(aar_source, tmp_path, monkeypatch, estimand, family):
    """Original public ZIP chain, MOCK MICE leaf, real input/source comparisons."""
    contract, covariates, response, source, policy = aar_source
    lock, _ = _lock(source["primary_training_context"], _scores(source["primary_training_context"], {
        candidate: .01 if candidate == family else .2 for candidate in nested._families()}))
    source = {**source, "primary_development_lock": lock}
    source = {**source, "estimand": estimand}
    primary_input = tmp_path / "UNFITTED-primary-input.zip"
    request = {"training_context": source["primary_training_context"],
        "science_decision": source["science_decision"], "identity_sha256": "a" * 64}
    write_deterministic_zip(primary_input, {"o-fit-input.json": canonical_json_bytes(request)})
    primary_archive = tmp_path / "UNFITTED-primary-result.zip"
    write_deterministic_zip(primary_archive, {"UNFITTED": b"MOCK_PRIMARY_READER_ONLY"})
    verified_primary = {"kind": "PADML_F4_O_FIT_EXECUTION_ARCHIVE_V3", "outer_fold": 1,
        "input_identity_sha256": request["identity_sha256"],
        "science_decision_sha256": source["science_decision"]["identity_sha256"],
        "family": source["primary_development_lock"]["selected_family"],
        "development_lock": source["primary_development_lock"],
        "input_archive": {"sha256": sha256_file(primary_input), "size_bytes": primary_input.stat().st_size}}
    primary_reads = []
    def primary_reader(path, **kwargs):
        assert path == primary_archive and kwargs["input_bundle"] == primary_input
        assert kwargs["f2_run_root"] == tmp_path and kwargs["f1_runtime_root"] is None
        primary_reads.append(path)
        return verified_primary
    monkeypatch.setattr(f4, "load_o_fit_execution_archive", primary_reader)
    binding = tmp_path / "binding.zip"
    write_deterministic_zip(binding, {"manifest.json": b"{}", "binding/contract.json": canonical_json_bytes(contract),
        "binding/covariates.csv": covariates, "binding/response-seal.csv": response})
    approved_binding = tmp_path / "UNFITTED-approved-binding.zip"
    write_deterministic_zip(approved_binding, {"manifest.json": b"{}", "outputs/data-binding/payload.zip": binding})
    approved = {"binding_contract_sha256": sha256_bytes(canonical_json_bytes(contract)),
        "direct_objects": [{"unit_id": "data-binding", "result_size_bytes": approved_binding.stat().st_size,
                            "result_sha256": sha256_file(approved_binding), "artifact_sha256": sha256_file(binding)}]}
    monkeypatch.setattr("padml.f1_contract.load_f1_input_manifest", lambda path: approved)
    input_path = tmp_path / "input.zip"
    compiled = sensitivity.compile_a12_total_mice_input(tmp_path / "UNFITTED-manifest.json", approved_binding,
        1, "OUTER_APPLICATION", input_path, estimand=estimand, primary_input_bundle=primary_input,
        primary_outer_archive=primary_archive, f2_run_root=tmp_path, resource_policy=policy)
    assert primary_reads == [primary_archive]
    assert compiled["stage_acceptance"] is False
    value, members = sensitivity._load_a12_total_mice_input(input_path)
    assert value["nested_source"]["primary_development_lock"]["selected_family"] == family
    assert value["execution_profile"] == {"pool_workers": "EXECUTION_HOST_C_MINUS_8", "engine_threads": 1}
    assert "response.csv" not in members
    calls = []
    def unfitted_mice(command, **kwargs):
        spec = strict_json_bytes(Path(command[4]).read_bytes())
        assert spec["nested_aar_source"] == source
        assert "response_path" not in spec
        raw = Path(spec["covariates_path"]).read_bytes()
        assert not {"AST", "ALT", "AST_ALT"} & set(next(csv.reader(io.StringIO(raw.decode()))))
        calls.append(command[3])
        result = fake_mice_run(command, **kwargs)
        summary_path = Path(spec["output_dir"]) / "summary.json"
        summary = strict_json_bytes(summary_path.read_bytes())
        summary_path.write_bytes(canonical_json_bytes({**summary, "outer_fold": 1}))
        (summary_path.parent.parent / "covariates-total.csv").write_bytes(raw)
        return result
    monkeypatch.setattr(sensitivity.subprocess, "run", unfitted_mice)
    archive = tmp_path / "MOCK-native.zip"
    executed = sensitivity.execute_a12_total_mice_bundle(input_path, archive)
    with zipfile.ZipFile(archive) as payload:
        stored = {info.filename for info in payload.infolist() if info.compress_type == zipfile.ZIP_STORED}
        assert stored == {"input.zip"} | {f"native/imp{imputation:02d}.rds" for imputation in range(1, 21)}
        assert payload.read("input.zip") == input_path.read_bytes()
        assert all(payload.read(name) == b"MOCK_NOT_NATIVE_EXECUTION_PROOF" for name in stored - {"input.zip"})
    manifest = strict_json_bytes(sensitivity.read_safe_zip(archive)["manifest.json"])
    assert manifest["kind"] == "PADML_NESTED_AAR_MICE_NATIVE_V1"
    assert executed["execution_report"]["configured_worker_ceiling"] == 56
    assert executed["execution_report"]["admitted_worker_ceiling"] == 1
    original_read, original_extract, original_sha = sensitivity.read_safe_zip, sensitivity.extract_safe_zip, sensitivity.sha256_file
    expanded = []
    def read_input_only(path, **kwargs):
        assert path != archive, "Native payload must not be read wholesale before extraction"
        return original_read(path, **kwargs)
    def extract_once(path, destination, **kwargs):
        expanded.append(path)
        return original_extract(path, destination, **kwargs)
    def no_completed_rescan(path):
        assert path.parent.name != "imputations", "Use the original extractor's member records"
        return original_sha(path)
    monkeypatch.setattr(sensitivity, "read_safe_zip", read_input_only)
    monkeypatch.setattr(sensitivity, "extract_safe_zip", extract_once)
    monkeypatch.setattr(sensitivity, "sha256_file", no_completed_rescan)
    observed = sensitivity.materialize_a12_total_mice_view(input_path, archive, tmp_path / "read")
    assert expanded == [archive]
    assert all(row["sha256"] == sha256_file(tmp_path / "read/imputations" / row["name"])
               and row["size_bytes"] == (tmp_path / "read/imputations" / row["name"]).stat().st_size
               for row in observed["members"])
    assert calls == ["FIT", "REPLAY"] and len(observed["members"]) == 20
    assert observed["execution_report"]["configured_worker_ceiling"] == 56
    assert observed["execution_report"]["admitted_worker_ceiling"] == 1
    # The original exact input comparison precedes any native replay.
    other = tmp_path / "other-context.zip"
    other_source = {**source, "estimand": next(branch for branch in (nested.A12_TOTAL_AAR,
        nested.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT) if branch != estimand)}
    write_deterministic_zip(other, sensitivity._a12_total_mice_input_members(contract, covariates, response,
        1, "OUTER_APPLICATION", nested_source=other_source, resource_policy=policy))
    with pytest.raises(ContractError, match="F5_A12_MICE_SOURCE_MISMATCH"):
        sensitivity.materialize_a12_total_mice_view(other, archive, tmp_path / "wrong")
    assert calls == ["FIT", "REPLAY"]


def test_public_nested_aar_compiler_requires_native_primary_source_before_binding_read(tmp_path, monkeypatch):
    monkeypatch.setattr("padml.f1_contract.load_f1_input_manifest", lambda *a: pytest.fail("NO_BINDING_READ"))
    with pytest.raises(ContractError, match="NESTED_AAR_NATIVE_PRIMARY_SOURCE_REQUIRED"):
        sensitivity.compile_a12_total_mice_input(tmp_path / "missing.json", tmp_path / "missing.zip", 1,
            "OUTER_ANALYSIS", tmp_path / "never.zip", estimand=nested.A12_TOTAL_AAR)
    assert not (tmp_path / "never.zip").exists()


@pytest.mark.parametrize("damage", ["family", "input_identity", "decision", "archive_input", "outer", "legacy", "native_failure", "pending"])
def test_public_nested_aar_compiler_rejects_unbound_primary_before_f1_read(aar_source, tmp_path, monkeypatch, damage):
    _, _, _, source, policy = aar_source
    request = {"training_context": source["primary_training_context"], "science_decision": source["science_decision"],
               "identity_sha256": "a" * 64}
    if damage == "pending":
        request["science_decision"] = nested.science_decision_template()
    primary_input = tmp_path / "UNFITTED-primary-input.zip"
    write_deterministic_zip(primary_input, {"o-fit-input.json": canonical_json_bytes(request)})
    primary = {"kind": "PADML_F4_O_FIT_EXECUTION_ARCHIVE_V3", "outer_fold": 1,
        "input_identity_sha256": request["identity_sha256"],
        "science_decision_sha256": source["science_decision"]["identity_sha256"],
        "family": source["primary_development_lock"]["selected_family"],
        "development_lock": source["primary_development_lock"],
        "input_archive": {"sha256": sha256_file(primary_input), "size_bytes": primary_input.stat().st_size}}
    if damage == "family":
        primary["family"] = "RSF"
    elif damage == "input_identity":
        primary["input_identity_sha256"] = "0" * 64
    elif damage == "decision":
        primary["science_decision_sha256"] = "0" * 64
    elif damage == "archive_input":
        primary["input_archive"]["sha256"] = "0" * 64
    elif damage == "outer":
        primary["outer_fold"] = 2
    elif damage == "legacy":
        primary["kind"] = "PADML_F4_O_FIT_EXECUTION_ARCHIVE_V2"
    def native_reader(*args, **kwargs):
        if damage == "pending":
            pytest.fail("NO_NATIVE_READ_BEFORE_CONFIRMED_DECISION")
        if damage == "native_failure":
            raise ContractError("UNFITTED_NATIVE_PRIMARY_REPLAY_FAILED")
        return primary
    monkeypatch.setattr(f4, "load_o_fit_execution_archive", native_reader)
    monkeypatch.setattr("padml.f1_contract.load_f1_input_manifest", lambda *a: pytest.fail("NO_BINDING_READ"))
    with pytest.raises(ContractError):
        sensitivity.compile_a12_total_mice_input(tmp_path / "missing.json", tmp_path / "missing.zip", 1,
            "OUTER_ANALYSIS", tmp_path / "never.zip", estimand=nested.A12_TOTAL_AAR,
            primary_input_bundle=primary_input, primary_outer_archive=tmp_path / "UNFITTED-primary.zip",
            f2_run_root=tmp_path, resource_policy=policy)
    assert not (tmp_path / "never.zip").exists()


def test_nested_aar_mice_requires_physical_resource_admission_before_r(aar_source, tmp_path, monkeypatch):
    contract, covariates, response, source, policy = aar_source
    policy = {**policy, "memory_bytes_per_worker": 2}
    source = {**source, "estimand": nested.A12_TOTAL_AAR}
    with pytest.raises(ContractError, match="RESOURCE_POLICY_INVALID"):
        sensitivity._a12_total_mice_input_members(contract, covariates, response, 1, "OUTER_ANALYSIS", nested_source=source)
    members = sensitivity._a12_total_mice_input_members(contract, covariates, response, 1, "OUTER_ANALYSIS",
        nested_source=source, resource_policy=policy)
    path = tmp_path / "input.zip"
    write_deterministic_zip(path, members)
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda root: {
        "effective_cpus": 64, "available_memory_bytes": 1,
        "scratch_available_bytes": 10**10, "scratch_root": str(root)})
    monkeypatch.setattr(sensitivity.subprocess, "run", lambda *a, **k: pytest.fail("NO_NATIVE_START"))
    with pytest.raises(ContractError, match="RESOURCE_ADMISSION_ZERO"):
        sensitivity.execute_a12_total_mice_bundle(path, tmp_path / "never.zip")
    assert not (tmp_path / "never.zip").exists()


@pytest.mark.parametrize("new_channel", [False, True])
def test_original_aar_r_projection_accepts_legacy_or_preprojected_raw_bytes(aar_source, tmp_path, new_channel):
    """Execute only the original raw projection statements, never impute_view."""
    contract, covariates, response, source, policy = aar_source
    options = {"nested_source": {**source, "estimand": nested.A12_TOTAL_AAR}, "resource_policy": policy} if new_channel else {}
    members = sensitivity._a12_total_mice_input_members(contract, covariates, response, 1, "OUTER_APPLICATION", **options)
    input_path = tmp_path / "raw.csv"
    input_path.write_bytes(members["covariates.csv"])
    script = r'''
args <- commandArgs(trailingOnly = TRUE)
root <- args[[4L]]
spec <- list(covariates_path = args[[3L]])
authority <- jsonlite::fromJSON(args[[2L]], simplifyVector = FALSE)
nested_aar_source <- if (identical(args[[5L]], "new")) list(UNFITTED = TRUE) else NULL
chars <- function(x) as.character(unlist(x, use.names = FALSE))
fail <- function(x) stop(x, call. = FALSE)
expressions <- as.list(parse(args[[1L]]))
first <- which(vapply(expressions, function(x) identical(x, quote(excluded <- c("AST", "ALT", "AST_ALT"))), logical(1)))
last <- which(vapply(expressions, function(x) identical(x, quote(authority$science$mice$private_handoff$columns <- as.list(columns))), logical(1)))
stopifnot(length(first) == 1L, length(last) == 1L, first < last)
for (expression in expressions[first:last]) eval(expression)
result <- read.csv(spec$covariates_path, check.names = FALSE, colClasses = "character")
stopifnot(!any(c("AST", "ALT", "AST_ALT") %in% names(result)), identical(names(result), columns))
cat("RAW_PROJECTION_ONLY_NO_MICE\n")
'''
    package = Path(f5.__file__).parent
    completed = subprocess.run(["Rscript", "--vanilla", "-e", script,
        str(package / "kernels/f5_a12_mice.R"), str(package / "science/authority.json"),
        str(input_path), str(tmp_path), "new" if new_channel else "legacy"],
        capture_output=True, text=True, check=False, timeout=30)
    assert completed.returncode == 0, completed.stderr
    assert completed.stdout.strip() == "RAW_PROJECTION_ONLY_NO_MICE"


def test_original_mice_native_iterator_binds_distinct_aar_contexts_without_imputing(tmp_path):
    """Run only the original retaining iterator with an explicit fake mids leaf."""
    script = r'''
args <- commandArgs(trailingOnly = TRUE)
fail <- function(x) stop(x, call. = FALSE)
expressions <- as.list(parse(args[[1L]]))
definition <- Filter(function(x) is.call(x) && identical(x[[1L]], as.name("<-")) &&
  identical(x[[2L]], as.name("native_chains")), expressions)
stopifnot(length(definition) == 1L)
eval(definition[[1L]])
native <- args[[2L]]
dir.create(native)
action <- "FIT"
chain_rng_substream <- NULL
nested_aar_source <- list(program_id = "PADML_NESTED_LOCO_20260908", estimand = "TOTAL_UNFITTED")
mice_data <- data.frame(UNFITTED = 1:3)
method <- c(UNFITTED = "")
matrix <- matrix(0L, 1, 1)
ignore <- rep(FALSE, 3)
blots <- list()
leaf <- function(seed) structure(list(m = 1L, iteration = 50L, data = mice_data,
  method = method, predictorMatrix = matrix, ignore = ignore, blots = blots,
  seed = as.integer(seed), loggedEvents = NULL), class = "mids")
original <- native_chains(1:20, leaf)
stopifnot(all(vapply(original, function(x) identical(attr(x, "padml_nested_aar_source"), nested_aar_source), logical(1))))
action <- "REPLAY"
leaf <- function(seed) stop("NO_MICE_OR_FIT_AUTHORIZED")
stopifnot(identical(original, native_chains(1:20, leaf)))
nested_aar_source$estimand <- "REDEVELOPMENT_UNFITTED"
reason <- tryCatch({native_chains(1:20, leaf); "WRONG_ACCEPT"}, error = conditionMessage)
stopifnot(identical(reason, "F5_MICE_NATIVE_INPUT_BINDING_INVALID"))
nested_aar_source <- NULL
reason <- tryCatch({native_chains(1:20, leaf); "WRONG_ACCEPT"}, error = conditionMessage)
stopifnot(identical(reason, "F5_MICE_NATIVE_INPUT_BINDING_INVALID"))
# Old, untagged objects remain valid only in their original legacy context.
native <- paste0(native, "-legacy")
dir.create(native)
action <- "FIT"
leaf <- function(seed) structure(list(m = 1L, iteration = 50L, data = mice_data,
  method = method, predictorMatrix = matrix, ignore = ignore, blots = blots,
  seed = as.integer(seed), loggedEvents = NULL), class = "mids")
legacy <- native_chains(1:20, leaf)
stopifnot(all(vapply(legacy, function(x) is.null(attr(x, "padml_nested_aar_source")), logical(1))))
action <- "REPLAY"
leaf <- function(seed) stop("NO_MICE_OR_FIT_AUTHORIZED")
stopifnot(identical(legacy, native_chains(1:20, leaf)))
cat("UNFITTED_20_CONTEXT_BOUND_OBJECTS_REPLAYED_NO_MICE\n")
'''
    completed = subprocess.run(["Rscript", "--vanilla", "-e", script,
        str(Path(f5.__file__).with_name("kernels") / "f1_nested_mice.R"), str(tmp_path / "UNFITTED-native")],
        capture_output=True, text=True, check=False, timeout=30)
    assert completed.returncode == 0, completed.stderr
    assert completed.stdout.strip() == "UNFITTED_20_CONTEXT_BOUND_OBJECTS_REPLAYED_NO_MICE"
