"""Bounded COX12 prepare-only regressions; synthetic engineering host only."""
from contextlib import contextmanager
from copy import deepcopy
import os
from pathlib import Path

import pytest

from padml import f4, f5, nested_loco as nested, runtime
from padml.bundle import ContractError, canonical_json_bytes, sha256_bytes, strict_json_bytes
from test_nested_full_development import (
    full_inputs, unfitted_selector_consumers, _physical_full_inputs,
)


def _science():
    current = strict_json_bytes(Path(os.environ['PADML_COX12_TEST_DECISION']).read_bytes())
    previous = nested._sealed({key: value for key, value in current.items()
        if key not in {'identity_sha256', 'outer4_common_set_epv_exception'}})
    assert previous['identity_sha256'] == '8d3489742472c51c868e1829de3edd94272698067b42c7c909ff1c7c895e07cf'
    return nested.validate_science_decision(previous)


def _policy():
    return {'configured_worker_ceiling': runtime.CPU_MINUS_8, 'memory_bytes_per_worker': 2147483648,
        'scratch_bytes_per_worker': 1048576, 'memory_reserve_bytes': 2147483648,
        'scratch_reserve_bytes': 2147483648, 'transfer_archive_worker_ceiling': 64}


def _observe(root):
    return {'effective_cpus': 64, 'available_memory_bytes': 512 * 1024**3,
        'scratch_available_bytes': 512 * 1024**3, 'scratch_root': str(root)}


def _forbidden(*args, **kwargs):
    raise AssertionError('NO_Q_MODEL_STOP_MICE_OR_NATIVE_REPLAY_IN_COX12_PREPARATION')


def test_original_compiler_prepares_300_cox12_inputs_without_q_or_fitting(
    full_inputs, unfitted_selector_consumers, tmp_path, monkeypatch, family='COX_PH',
    verify_replay=False,
):
    inputs = _physical_full_inputs(full_inputs, tmp_path / 'inputs', complete_covariates=True)
    selector = tmp_path / 'selector'
    f5._nested_full_selector_program(*inputs, selector, rscript='UNFITTED', replay=False)
    original = f5._nested_full_selector_program
    retained = Path(os.environ['PADML_COX12_TEST_PRIMARY'])
    calls = []
    def synthetic_current_selector(*args, **kwargs):
        # The fixture's selector is current synthetic data, not an old clinical
        # producer. Source ZIP compatibility is checked separately below.
        assert kwargs.pop('retained_full0_source_bundle') == retained
        assert kwargs['replay'] is True
        calls.append('READ_SYNTHETIC_SELECTOR')
        return original(*args, **kwargs)
    monkeypatch.setattr(f5, '_nested_full_selector_program', synthetic_current_selector)
    monkeypatch.setattr(f5, 'read_final_complex_search', _forbidden)
    monkeypatch.setattr(f5, '_final_complex_search_program', _forbidden)
    monkeypatch.setattr(runtime, '_bounded_ordered_spawn', _forbidden)
    monkeypatch.setattr(runtime, 'observe_execution_resources', _observe)
    original_parts = inputs[1]
    inner_only = [{key: value for key, value in part.items() if key != 'stopping'} for part in original_parts]
    result = f5._full_data_locked_score_program(inputs[0], inner_only, inputs[2], selector, {},
        tmp_path / f'score.{family}', rscript='UNFITTED', replay=False, prepare_only=True, workers=1,
        family=family, selection_horizon_months=12, science_decision=_science(),
        retained_full0_source_bundle=retained, resource_policy=_policy(),
        retained_bytes_per_component=1024**2, expanded_bytes_per_component=1024**2,
        shared_storage_bytes=64 * 1024**2)
    assert calls == ['READ_SYNTHETIC_SELECTOR']
    assert result['result'] is None and result['pool_execution_reports'] == []
    assert result['new_model_fits'] == result['new_model_native_verification_count'] == result['native_model_replay_count'] == 0
    request = result['request']
    assert request['selection_horizon_months'] == 12 and request['science_decision'] == _science()
    assert 'outer4_common_set_epv_exception' not in request['science_decision']
    records = request['component_records']
    assert len(records) == len({row['path'] for row in records}) == 300
    assert {(row['repeat'], row['inner_fold'], row['imputation']) for row in records} == {
        (repeat, fold, mi) for repeat in range(1, 4) for fold in range(1, 6) for mi in range(1, 21)}
    assert {row['family'] for row in records} == {family}
    assert result['task_ids'] == [row['path'] for row in records]
    assert not (tmp_path / f'score.{family}/retained-q-readback').exists()
    assert not list((tmp_path / f'score.{family}').rglob('model.rds'))
    assert (tmp_path / f'score.{family}/request/full-score-input.{family}.json').read_bytes() == canonical_json_bytes(request)
    assert result['resource_reservation']['effective_policy']['memory_bytes_per_worker'] == 2147483648
    if verify_replay:
        request_root = tmp_path / f'score.{family}' / 'request'
        originals = {path: path.read_bytes() for path in request_root.rglob('*') if path.is_file()}
        replay_args = dict(rscript='UNFITTED', replay=True, workers=1, family=family,
            selection_horizon_months=12, science_decision=_science(),
            retained_full0_source_bundle=retained, resource_policy=_policy())
        rebuilt = f5._compile_full_score_inputs(inputs[0], inner_only, inputs[2], selector, {},
            request_root, **replay_args)
        assert rebuilt == request
        assert {path: path.read_bytes() for path in request_root.rglob('*') if path.is_file()} == originals
        # Rebuild checks existing bytes; it must never repair a missing input.
        missing = request_root / records[0]['path']
        missing.unlink()
        with pytest.raises(ContractError, match='NESTED_FULL_SCORE_COMPONENT_REPLAY_DRIFT'):
            f5._compile_full_score_inputs(inputs[0], inner_only, inputs[2], selector, {},
                request_root, **replay_args)
        assert not missing.exists()
        assert {path: path.read_bytes() for path in request_root.rglob('*') if path.is_file()} == {
            path: raw for path, raw in originals.items() if path != missing}


def test_entry_preserves_original_lineage_rsf_root_and_owns_its_release_report(
        tmp_path, monkeypatch, family='COX_PH', release_status='OBSERVED', admission_failure=False):
    old = tmp_path / 'score'
    old.mkdir()
    (old / 'input-execution.json').write_bytes(b'UNCHANGED_RSF_REPORT')
    source = tmp_path / 'full-development.json'
    value = {'plan': {'synthetic': True}, 'score_root': str(old), 'selector_root': str(tmp_path / 'selector'),
        'search_roots': {}, 'rscript': 'UNFITTED', 'science_decision': _science(), 'resource_policy': _policy(),
        'retained_bytes_per_component': 1024**2, 'expanded_bytes_per_component': 1024**2, 'shared_storage_bytes': 64 * 1024**2}
    source.write_bytes(canonical_json_bytes(value))
    original_raw = source.read_bytes()
    monkeypatch.setattr(f5, '_read_final_lineage', lambda *args, **kwargs: deepcopy(value))
    @contextmanager
    def materialized(path, parent, **kwargs):
        assert kwargs['selector_only'] is True and kwargs['selection_horizon_months'] == 12
        assert kwargs['retained_mice_plan'] == value['plan']
        yield deepcopy(value), [], {}
        temporary = tmp_path / 'completed-synthetic-inputs'
        temporary.mkdir()
        (temporary / 'input.json').write_bytes(b'{}')
        kwargs['q_input_lifecycle']['materialized_inputs'] = {'temporary_root': str(temporary)}
    monkeypatch.setattr(f5, '_materialized_full_data_development_sources', materialized)
    def program(plan, parts, full, selector, roots, root, **kwargs):
        assert root == tmp_path / f'score.{family}'
        assert kwargs['family'] == family and kwargs['prepare_only'] is True
        assert kwargs['retained_q_archive'] is kwargs['retained_q_producer_source_bundle'] is None
        root.mkdir()
        return {'request': {'identity_sha256': 'a' * 64}, 'resource_reservation': {'effective_policy': _policy()}}
    monkeypatch.setattr(f5, '_full_data_locked_score_program', program)
    monkeypatch.setattr(runtime, 'observe_execution_resources', _observe)
    releases = []
    def release(files, **kwargs):
        releases.append(list(files))
        if release_status == 'EXCEPTION':
            raise OSError('synthetic advisory failure')
        return {'reader_scan_status': release_status,
            'files': [{'status': 'ADVISED', 'error': None} for _ in files]}
    monkeypatch.setattr(runtime, 'release_step_resources', release)
    admissions = []
    original_admission = runtime.resource_admission
    def admit(*args, **kwargs):
        admissions.append(True)
        if admission_failure:
            raise ContractError('SYNTHETIC_RESOURCE_ADMISSION_FAILURE')
        return original_admission(*args, **kwargs)
    monkeypatch.setattr(runtime, 'resource_admission', admit)
    def execute():
        return f5.execute_full_data_locked_scores(source, family=family, prepare_only=True,
            selection_horizon_months=12, retained_full0_source_bundle=Path('/synthetic/primary.zip'))
    if admission_failure:
        with pytest.raises(ContractError, match='SYNTHETIC_RESOURCE_ADMISSION_FAILURE'):
            execute()
        result = strict_json_bytes((tmp_path / f'score.{family}/input-execution.json').read_bytes())
        assert result['after_input_release']['resource_admission'] is None
        assert 'SYNTHETIC_RESOURCE_ADMISSION_FAILURE' in result['resource_admission_error']
    else:
        result = execute()
        assert result['after_input_release']['resource_admission'] is not None
    assert len(releases) == len(admissions) == 1
    assert all(path.read_bytes() == b'{}' for path in releases[0])
    assert source.read_bytes() == original_raw
    assert (old / 'input-execution.json').read_bytes() == b'UNCHANGED_RSF_REPORT'
    assert set(result['input_lifecycle']) == {'materialized_inputs'}
    assert result['input_execution_report'] == str(tmp_path / f'score.{family}/input-execution.json')
    assert result['after_input_release']['resource_observation']['scratch_root'] == str(tmp_path / f'score.{family}')
    if release_status == 'OBSERVED':
        assert result['input_release_error'] is None
    else:
        assert result['input_release_error']
        assert result['input_lifecycle']['materialized_inputs']['input_release_error']
        if release_status == 'UNKNOWN':
            assert result['input_lifecycle']['materialized_inputs']['resource_release']['reader_scan_status'] == 'UNKNOWN'


@pytest.mark.parametrize('change', [
    {'prepare_only': False}, {'replay': True}, {'resume': True}, {'family': None}, {'family': 'GBM_COX'},
    {'task_ids': ['unstarted'], 'batch_root': Path('/synthetic/batch')}, {'score_batches': []},
    {'retained_q_archive': Path('/synthetic/q.zip')}, {'retained_q_producer_source_bundle': Path('/synthetic/q-source.zip')},
])
def test_entry_rejects_scientific_execution_and_q_before_reading_inputs(change, monkeypatch):
    monkeypatch.setattr(f5, '_read_final_lineage', _forbidden)
    options = {'family': 'COX_PH', 'prepare_only': True, 'selection_horizon_months': 12,
        'retained_full0_source_bundle': Path('/synthetic/primary.zip'), **change}
    with pytest.raises(ContractError, match='NESTED_FULL_SCORE_SELECTION_SCOPE_INVALID'):
        f5.execute_full_data_locked_scores(Path('/synthetic/lineage.json'), **options)


def test_existing_partial_cox_root_is_not_an_implicit_resume(tmp_path, monkeypatch):
    root = tmp_path / 'score.COX_PH'
    root.mkdir()
    (root / 'partial.json').write_bytes(b'PRESERVE')
    monkeypatch.setattr(f5, '_compile_full_score_inputs', _forbidden)
    with pytest.raises(ContractError, match='NESTED_FULL_SCORE_ROOT_INVALID'):
        f5._full_data_locked_score_program({}, [], {}, tmp_path / 'selector', {}, root,
            rscript='UNFITTED', replay=False, prepare_only=True, family='COX_PH', selection_horizon_months=12,
            science_decision=_science(), retained_full0_source_bundle=Path('/synthetic/primary.zip'),
            resource_policy=_policy(), retained_bytes_per_component=1024**2,
            expanded_bytes_per_component=1024**2, shared_storage_bytes=64 * 1024**2)
    assert (root / 'partial.json').read_bytes() == b'PRESERVE'


def test_old_source_is_still_separate_and_twelve_month_decision_is_required(monkeypatch):
    current = f4._f45_source_member_sha256()
    old = f4._retained_full0_source_members(Path(os.environ['PADML_COX12_TEST_PRIMARY']), full0_preparation=True)
    assert sha256_bytes(canonical_json_bytes(old)) == '1513ecba963857099c6b99413b8e976393c551a3ec30ed90da1cb14178338bd7'
    assert old != current and f4._f45_source_member_sha256() == current
    monkeypatch.setattr(f5, '_nested_full_selector_program', _forbidden)
    with pytest.raises(ContractError):
        f5._nested_full_score_development({}, [], {}, Path('/synthetic/selector'), {}, rscript='UNFITTED',
            family='COX_PH', selection_horizon_months=12, science_decision={},
            retained_full0_source_bundle=Path('/synthetic/primary.zip'))
