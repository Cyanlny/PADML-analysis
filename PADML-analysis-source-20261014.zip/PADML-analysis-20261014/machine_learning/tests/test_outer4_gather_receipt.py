"""Exact historical receipt gate, synthetic metadata only; never a gather/fit call."""
import ast
import copy
from pathlib import Path
from types import SimpleNamespace

import pytest

from padml import f5_sensitivity as sensitivity
from padml.bundle import ContractError


OUTER4 = ('f974194f400c018391b5507a3aa3ede1699f96c139b77a0a845d3d7dd6fca3a5', 339620865,
    '995bb522e8eef784b10167a87e9959e7272f17debc514de39c03ae4754e28474',
    '41b247105716d4fcb3ba3be3222138efb35bebe1bc36565abc47da8b9169c4de', 4771639,
    'f8a4211043f102bd166bd6f5362eed1831d0573fb5b509d89aee8aac7245c426')


def receipt_gate():
    # Execute the actual unchanged call expression plus its new exact tuple.
    # No copy of the acceptance condition lives in this fixture and no native
    # reader, response, scientific generator or numerical function is invoked.
    tree = ast.parse(Path(sensitivity.__file__).read_bytes())
    owner, = [n for n in tree.body if isinstance(n, ast.FunctionDef)
              and n.name == 'materialize_a12_outer_inputs']
    calls = [n for n in ast.walk(owner) if isinstance(n, ast.Call)
             and isinstance(n.func, ast.Name) and n.func.id == '_require'
             and len(n.args) == 2 and isinstance(n.args[1], ast.Constant)
             and n.args[1].value == 'F5_A12_RETAINED_GATHER_EXECUTION_RECEIPT_REQUIRED'
             and any(isinstance(child, ast.Set) for child in ast.walk(n.args[0]))]
    call, = calls
    tuples, = [n for n in ast.walk(call.args[0]) if isinstance(n, ast.Set)]
    literal_rows = ast.literal_eval(tuples)
    code = compile(ast.fix_missing_locations(ast.Module(body=[ast.Expr(copy.deepcopy(call))], type_ignores=[])),
                   sensitivity.__file__, 'exec')
    return code, literal_rows


def invoke(row, *, extra_budget=False):
    class Source:
        def stat(self):
            return SimpleNamespace(st_size=row[1])
    source, projected, raw = Source(), object(), b'UNFITTED_RECEIPT'
    def digest(path):
        assert path is source or path is projected
        return row[2] if path is source else row[3]
    code, _ = receipt_gate()
    namespace = {'_require': sensitivity._require, 'value': {'identity_sha256': row[0]},
        'source': source, 'input_bundle': projected, 'execution_raw': raw,
        'sha256_file': digest, 'sha256_bytes': lambda value: row[5] if value is raw else pytest.fail('unexpected bytes'),
        'len': lambda value: row[4] if value is raw else pytest.fail('unexpected length'),
        'transport': {'execution_worker_memory_bytes': 2147483648} if extra_budget else {}}
    exec(code, namespace)


def test_real_outer4_exact_receipt_and_unchanged_outer5_outer6():
    _, rows = receipt_gate()
    assert len(rows) == 3 and OUTER4 in rows
    assert {r[0] for r in rows} == {OUTER4[0],
        '1bf4abbbbe2dab27fdb52d2d95e762b7a61817a654afd64ac2c5a8ec27f1c9df',
        '17aa48672117e1cb65019bab308e6875c514bc7509550841ea81ef42a64ea774'}
    for row in rows:
        invoke(row)


@pytest.mark.parametrize('index', range(6))
def test_each_exact_receipt_axis_rejects_drift(index):
    bad = list(OUTER4)
    bad[index] = bad[index] + 1 if isinstance(bad[index], int) else '0' * 64
    with pytest.raises(ContractError, match='F5_A12_RETAINED_GATHER_EXECUTION_RECEIPT_REQUIRED'):
        invoke(tuple(bad))


def test_historical_receipt_cannot_select_new_worker_arithmetic():
    with pytest.raises(ContractError, match='F5_A12_RETAINED_GATHER_EXECUTION_RECEIPT_REQUIRED'):
        invoke(OUTER4, extra_budget=True)
