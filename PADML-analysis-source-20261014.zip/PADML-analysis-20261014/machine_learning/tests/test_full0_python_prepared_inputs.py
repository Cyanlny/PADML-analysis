"""Full0 Python input transport; synthetic predecessors/models, no science claim."""
import copy
import re

import pytest

from padml import f4, f5, f2_kernel as kernel, nested_loco as nested, runtime
from padml.bundle import (ContractError, canonical_json_bytes, sha256_bytes, sha256_file,
    read_safe_zip, strict_json_bytes, write_deterministic_zip)
from test_a12_q_native import aar_source, _q_numbers_python_unit
from test_nested_full_development import (
    full_inputs, unfitted_selector_consumers, _physical_full_inputs, _unfitted_confirmed_decision,
)
from test_q_funnel_shards import _POLICY, _unfitted_leaves


def _check_prepared_boundary(value, task, selector, root):
    """Synthetic operational envelope around an original scientific handoff."""
    identity = sha256_bytes(canonical_json_bytes(f4._f45_source_member_sha256()))
    inputs = {name: {'temporary_root': str((root if name == 'materialized_inputs' else root.parent) / prefix), 'resource_release': {
        'status': 'UNKNOWN', 'owner': 'FULL0_Q_INPUTS:' + value['consumer_input']['sha256'] + ':' + name,
        'pid': 1, 'reason': 'UNFITTED_OPERATIONAL_ENVELOPE'}} for name, prefix in (
            ('materialized_inputs', 'f5-full-development-inputs-UNFITTED'),
            ('selector_program', 'nested-full-selector-replay-UNFITTED'),
            ('q_program', 'f5-q-consume-UNFITTED'))}
    binding = {name: {'sha256': sha256_file(selector / name), 'size_bytes': (selector / name).stat().st_size}
               for name in ('partitions.json', 'selector.json', 'development-input.json')}
    effective = {**_POLICY, 'memory_bytes_per_worker': 2 * 1024**3,
                 'memory_reserve_bytes': 32 * 32 * 1024**2, 'scratch_reserve_bytes': 0}
    observation = runtime.observe_execution_resources(root.parent)
    admission = runtime.resource_admission(effective, observation, legal_tasks=1)
    report = dict(source_identity=identity, family=task['family'], virtual_outer=0, selection_horizon_months=12,
        pid=1, full_development_sha256=sha256_file(root / 'input.json'), q_root=str(root),
        q_input=value['consumer_input'], task_sha256=task['task_sha256'],
        result_sha256=sha256_bytes(canonical_json_bytes(value)), selector_root=str(selector),
        selector_binding=binding, resource_policy=_POLICY, effective_policy=effective,
        resource_observation=observation, resource_admission=admission, input_lifecycle=inputs,
        after_release={'resource_observation': observation, 'resource_admission': admission},
        report_path=str(root / 'input-execution-f5-full-development-inputs-UNFITTED.json'),
        execution_worker_memory_bytes=2 * 1024**3, execution_scratch_reserve_bytes=0, operational_errors=[])
    observed = {**value, 'execution_report': report}
    def consume(actual):
        expected = sha256_bytes(canonical_json_bytes({k: v for k, v in actual.items() if k != 'execution_report'}))
        actual['execution_report']['result_sha256'] = expected
        f5._validate_full0_q_input_execution(actual, source=root / 'input.json',
            source_sha256=sha256_file(root / 'input.json'), source_identity=identity,
            q_root=root, q_input=value['consumer_input'], task_sha256=task['task_sha256'],
            expected_result_sha256=expected, selector_root=selector, selector_binding=binding,
            selector_partitions=strict_json_bytes((selector / 'partitions.json').read_bytes()),
            policy=_POLICY, selection_horizon_months=12, rescore_task=task,
            retained_q_input=value['producer_input'], retained_source_identity=identity)
    consume(observed)
    for damage in ('count', 'candidate', 'seed', 'coordinate', 'duplicate', 'source', 'horizon', 'lock', 'unexpected'):
        bad = copy.deepcopy(observed)
        row = bad['next_atomic_units'][0]['producer_tasks'][0]
        if damage == 'count': bad['historical_stop_fit_count'] += 1
        elif damage == 'candidate': row['candidate' if task['family'] == 'COXTIME_SET_A' else 'parameters'] = {}
        elif damage == 'seed': row['seed'] += 1
        elif damage == 'coordinate': row['partition_id'] = 'FOREIGN'
        elif damage == 'duplicate': bad['next_atomic_units'][1] = copy.deepcopy(bad['next_atomic_units'][0])
        elif damage == 'source': bad['producer_source_identity'] = '0' * 64
        elif damage == 'horizon': bad['selection_horizon_months'] = 24
        elif damage == 'lock': row['locked_epoch' if task['family'] == 'COXTIME_SET_A' else 'locked_rounds'] = 0
        else: row['evaluation_response'] = {}
        with pytest.raises(ContractError): consume(bad)


def _calls(spec, registered, stage, refit, root):
    family = spec['family']
    phase, names = f5._a12_q_stop_phase(stage, refit=refit, family=family)
    index = ('S1', 'S2', 'S3A', 'S3B1', 'S3B2').index(stage) + 1
    candidates = spec['candidate_trials']['S1' if stage == 'S1' or family == 'COXTIME_SET_A' else 'S2']
    rows = {row['partition_id']: row for row in registered['partitions']}
    calls = []
    for name in names:
        match = re.fullmatch(r'(?:S1|S2|S3A|S3B1|S3B2)_(?:T(\d{3})_)?P(\d{2})_M(\d{2})_(?:FUNCTION|LOCKED_REFIT)', name)
        trial, part, imp = int(match[1] or 1), int(match[2]), int(match[3])
        repeat, fold = (index if index <= 3 else (part - 1) // 5 + 1), (part - 1) % 5 + 1
        identifier = f"F5_{'' if refit else 'STOP_'}R{repeat:02d}_K{fold:02d}"
        candidate = candidates[trial - 1]
        task = {'task_id': name, 'spec': spec,
            'registered': kernel._engine_registered_partitions(registered, {identifier}),
            'partition_id': identifier, 'imputation': imp, 'seed': 300000 + index * 10000 + imp * 100 + part,
            **({'parameters': kernel._engine_parameters(family, candidate['parameters'])}
               if family == 'XGBOOST_COX' else {'candidate': candidate})}
        if refit:
            task.update(prediction_horizons=list(range(1, 37)),
                **({'locked_rounds': 2} if family == 'XGBOOST_COX' else {'locked_epoch': 50}))
            calls.append(task)
        else:
            task['handoff_path'] = str(root / name / 'model')
            calls.append((task, rows[identifier]))
    return phase, calls


@pytest.mark.parametrize('family', ['XGBOOST_COX', 'COXTIME_SET_A'])
@pytest.mark.parametrize('horizon', [24, 12])
def test_original_full0_python_transport_and_public_worker(
        full_inputs, unfitted_selector_consumers, aar_source, tmp_path, monkeypatch, family, horizon):
    sample, _, _ = _q_numbers_python_unit(aar_source, tmp_path, family, 'FULL0')
    if family == 'XGBOOST_COX':
        chosen = sample['spec']['candidate_trials']['S1'][0]['parameters']
        candidates = {stage: [{'trial_id': f'UNFITTED-{stage}-{i}',
            'parameters': {**chosen, 'UNFITTED_TRIAL': i},
            'parameter_sha256': sha256_bytes(canonical_json_bytes({**chosen, 'UNFITTED_TRIAL': i}))}
            for i in range(count)] for stage, count in (('S1', 40), ('S2', 14))}
    else:
        candidates = f5._final_complex_candidate_trials(family)
    monkeypatch.setattr(f5, '_final_complex_candidate_trials', lambda actual: copy.deepcopy(candidates)
                        if actual == family else pytest.fail('foreign family'))
    monkeypatch.setattr(f5, 'candidate_trials', lambda *a, **k: pytest.fail('NO_CANDIDATE_RNG'))
    monkeypatch.setattr(runtime, 'effective_cpu_count', lambda: 9)
    monkeypatch.setattr(runtime, 'observe_execution_resources', lambda root: {
        'effective_cpus': 32, 'available_memory_bytes': 10**12,
        'scratch_available_bytes': 10**12, 'scratch_root': str(root)})
    plan, parts, final = _physical_full_inputs(full_inputs, tmp_path / 'physical', complete_covariates=True)
    selector = tmp_path / 'selector'
    f5._nested_full_selector_program(plan, parts, final, selector, rscript='UNFITTED', replay=False)
    base = _unfitted_confirmed_decision(fixed_bootstrap=True)
    decision = nested._sealed({**{k: v for k, v in base.items() if k != 'identity_sha256'},
        'twelve_month_development': nested._twelve_month_development_contract()})
    task = f5.compile_nested_full_complex_search_task(plan, parts, final, selector, family=family,
        rscript='UNFITTED', resource_policy=_POLICY, **({'selection_horizon_months': 12,
            'science_decision': decision} if horizon == 12 else {}))
    registered = f5._complex_runtime_registered_inputs(task, parts)
    spec = f5._complex_search_execution_spec(task, registered)
    spec.update(threads=1, pool_workers=1)
    spec['final_search_source']['producer_execution'] = {k: spec[k]
        for k in ('execution_mode', 'threads', 'pool_workers', 'engine_threads')}
    events, _ = _unfitted_leaves(monkeypatch)
    original_executor = f5._execute_q_search_batch
    def checked_executor(function, units, *args, **kwargs):
        for call, _ in units.values():
            received = call[0] if function is kernel._run_python_stop_pair_pool_task else call
            assert not {'active_worker_limit', 'replay_pool_workers'}.intersection(received['spec'])
            if family == 'XGBOOST_COX':
                assert received['spec']['xgb_preparation_policy'] == _POLICY
            else:
                assert 'xgb_preparation_policy' not in received['spec']
        return original_executor(function, units, *args, **kwargs)
    monkeypatch.setattr(f5, '_execute_q_search_batch', checked_executor)
    chosen_stage = 'S1' if horizon == 24 else 'S2' if family == 'COXTIME_SET_A' else 'S3A'
    for stage in ('S1', 'S2', 'S3A', 'S3B1', 'S3B2'):
        for refit in (False, True):
            function = (kernel._run_xgb_refit_pool_task if family == 'XGBOOST_COX'
                        else kernel._run_coxtime_refit_pool_task) if refit else kernel._run_python_stop_pair_pool_task
            root = tmp_path / (stage + ('-refit' if refit else '-stop'))
            root.mkdir()
            (root / 'input.json').write_bytes(canonical_json_bytes({'kind': 'PADML_F5_Q_INPUT_V1', 'task': task, 'spec': spec}))
            operational_spec = {**spec, 'active_worker_limit': 1, 'replay_pool_workers': 24,
                **({'xgb_preparation_policy': dict(_POLICY)} if family == 'XGBOOST_COX' else {})}
            phase, calls = _calls(operational_spec, registered, stage, refit, root)
            sample = calls[-1]
            before = copy.deepcopy(sample)
            files = {}
            delivered = f5._a12_q_python_unit_input(function, sample, files=files)
            assert sample == before
            assert f5._a12_q_python_unit_input(function, delivered) == delivered
            assert not any(name.startswith('source/') for name in files)
            training = delivered if refit else delivered[0]
            assert training['spec'] == spec
            assert not kernel._contains_key(training, 'evaluation_response')
            assert not kernel._contains_key(training, 'stopping')
            assert sum(name.endswith('.csv') for name in files) == (2 if refit else 3)
            for damage in ('seed', 'partition', 'aar', 'imputation'):
                bad = copy.deepcopy(sample)
                original = bad if refit else bad[0]
                if damage == 'seed': original['seed'] += 1
                elif damage == 'partition': original['partition_id'] = 'UNFITTED_FOREIGN'
                elif damage == 'aar': original['spec']['a12_source'] = {}
                else: original['imputation'] = 0
                with pytest.raises(ContractError): f5._a12_q_python_unit_input(function, bad)
            common_stage = stage in ({'S1'} if family == 'COXTIME_SET_A' else {'S1', 'S2'})
            if horizon == 12 and not common_stage:
                # Synthetic predecessor counts here exercise every legal handoff;
                # complete real-consumer prefix coverage has its own funnel test.
                pin = {'sha256': sha256_file(root / 'input.json'), 'size_bytes': (root / 'input.json').stat().st_size}
                identity = sha256_bytes(canonical_json_bytes(f4._f45_source_member_sha256()))
                counts = f5._a12_q_prepared_predecessors(stage, refit=refit, family=family, full0=True)
                boundary_control = {'prepare_only': True, 'task_ids': None, 'completed': False,
                    'batches': [], 'used_batches': [], 'confirmed_model_fits': counts['total'],
                    'confirmed_stop_fits': counts['stop'], 'full0_rsf_s1s2_rescore': {
                        'producer_input': {'sha256': '0' * 64, 'size_bytes': 1},
                        'consumer_input': pin, 'producer_source_identity': identity, 'executor_source_identity': identity}}
                with pytest.raises(f5._QBatchBoundary) as boundary:
                    f5._q_search_task_batch({**spec, 'native_search_root': str(root / 'native'),
                        'native_search_batch': boundary_control}, function, calls)
                _check_prepared_boundary(boundary.value.result, task, selector, root)
            if stage != chosen_stage and not (horizon == 12 and common_stage):
                continue
            units = f5._q_search_units(function, calls)
            ids = list(units)
            outputs = [[str(root.with_suffix('.one.zip')), ids[-1]], [str(root.with_suffix('.rest.zip')), *ids[:-1]]]
            counts = f5._a12_q_prepared_predecessors(stage, refit=refit, family=family, full0=True)
            predecessors = [] if counts['total'] == 0 else [(root, {'UNFITTED_PREDECESSOR': phase})]
            control = {'q_unit_outputs': outputs, 'resource_policy': _POLICY, 'task_ids': None,
                'retained_bytes_per_task': 4 * 1024**2, 'completed': False, 'batches': predecessors,
                'used_batches': [sha256_bytes(canonical_json_bytes(row)) for _, row in predecessors],
                'confirmed_model_fits': counts['total'], 'confirmed_stop_fits': counts['stop']}
            pin = {'sha256': sha256_file(root / 'input.json'), 'size_bytes': (root / 'input.json').stat().st_size}
            if horizon == 12 and common_stage:
                with pytest.raises(ContractError): f5._publish_a12_q_stop_inputs(function, units, root, control, phase, pin)
                continue
            f5._publish_a12_q_stop_inputs(function, units, root, control, phase, pin)
            from pathlib import Path
            source = Path(outputs[0][0])
            assert not any(name.startswith('source/') for name in read_safe_zip(source))
            common = dict(candidate_family=family, selection_horizon_months=horizon,
                task_ids=[ids[-1]], batch_root=root.with_name(root.name + '-batch'), retained_bytes_per_task=4 * 1024**2,
                prepared_q_input=source, prepared_q_input_sha256=sha256_file(source))
            event_count = len(events)
            with pytest.raises(ContractError):
                f5.execute_final_complex_search(**{**common, 'candidate_family': 'GBM_COX'},
                    target=root.with_name(root.name + '-wrong-family'))
            assert len(events) == event_count
            for damage in ('candidate', 'view'):
                entries = read_safe_zip(source)
                record = strict_json_bytes(entries['prepared-q.json'])
                position = 3 if damage == 'candidate' else 2
                old_pin = record['units'][ids[-1]][position]
                value = record['arguments'].pop(old_pin)
                if damage == 'candidate':
                    value['parameters' if family == 'XGBOOST_COX' else 'candidate']['UNFITTED_DRIFT'] = True
                else:
                    value['covariates']['analysis_view_sha256'] = '0' * 64
                new_pin = sha256_bytes(canonical_json_bytes(value))
                record['arguments'][new_pin] = value
                record['units'][ids[-1]][position] = new_pin
                entries['prepared-q.json'] = canonical_json_bytes(record)
                damaged = root.with_name(root.name + '-' + damage + '.zip')
                write_deterministic_zip(damaged, entries)
                with pytest.raises(ContractError):
                    f5.execute_final_complex_search(**{**common, 'prepared_q_input': damaged,
                        'prepared_q_input_sha256': sha256_file(damaged)},
                        target=root.with_name(root.name + '-' + damage + '-worker'))
                assert len(events) == event_count
            actual = f5.execute_final_complex_search(**common, target=root.with_name(root.name + '-worker'))
            assert actual['status'] == 'COMPUTED_Q_BATCH' and actual['task_ids'] == [ids[-1]]
            assert actual['execution']['new_model_fit_count'] == actual['execution']['confirmed_first_native_audit_count'] == 1
            assert actual['execution']['execution_worker_memory_bytes'] == 2 * 1024**3
            assert actual['execution']['execution_scratch_reserve_bytes'] == 0
            assert [mode for mode, _, _ in events[event_count:]] == ['produce', 'audit']
            with pytest.raises(ContractError):
                f5.execute_final_complex_search(**common, target=root.with_name(root.name + '-duplicate'))
            assert len(events) == event_count + 2
