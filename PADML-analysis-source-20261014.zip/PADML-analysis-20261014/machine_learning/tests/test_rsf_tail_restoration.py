"""Exact-eight original-entry delta; synthetic identity/native leaves only.

These tests are not clinical-input, R ABI or model-fitting qualification.
The separately closed old/current F2 paired test owns unchanged Q arithmetic.
"""
import copy
import gc
import mmap
import shutil
import sys
import tempfile
from time import monotonic_ns
from types import SimpleNamespace
import weakref
from contextlib import contextmanager
from pathlib import Path

import pytest

from padml import f2_kernel as kernel, f4, f4_compact as compact, f5, nested_loco as nested, runtime
from padml.bundle import ContractError, canonical_json_bytes, sha256_bytes, sha256_file, strict_json_bytes
from test_nested_full_development import _unfitted_confirmed_decision
from test_q_funnel_shards import _serial_pool
from test_retained_full0_source import retained_source_bundle


@pytest.fixture
def interrupted(tmp_path, monkeypatch):
    """Only three pinned clinical byte identities are explicit fixture stubs."""
    decision = _unfitted_confirmed_decision(fixed_bootstrap=True)
    decision.pop("identity_sha256")
    contract = nested._full0_rsf_tail_restoration_contract()
    decision["full0_rsf_tail_restoration"] = contract
    decision["identity_sha256"] = sha256_bytes(canonical_json_bytes(decision))
    original = tmp_path / "lineage" / "search" / "RSF"
    original.mkdir(parents=True)
    task = {"kind": "PADML_NESTED_FULL_DATA_COMPLEX_SEARCH_TASK_V1", "family": "RSF",
            "task_sha256": "a" * 64, "execution_profile": {"pool_workers": runtime.CPU_MINUS_8}, "UNFITTED": ""}
    geometry = {"execution_mode": "PROCESS_POOL", "threads": 56, "pool_workers": 56, "engine_threads": 1}
    spec = {**geometry, "family": "RSF", "execution_scope": "F5_FULL_DEVELOPMENT_SEARCH",
            "final_search_source": {"program_id": nested.PROGRAM_ID, "virtual_outer": 0,
                                    "producer_execution": geometry}}
    value = {"kind": "PADML_F5_Q_INPUT_V1", "task": task, "spec": spec}
    task["UNFITTED"] = "x" * (contract["original_q_input"]["size_bytes"] - len(canonical_json_bytes(value)))
    raw = canonical_json_bytes(value)
    assert len(raw) == contract["original_q_input"]["size_bytes"]
    (original / "input.json").write_bytes(raw)
    identity_leaves = {raw: contract["original_q_input"]["sha256"]}
    for unit, spec_sha in zip(contract["atomic_units"], (
            "08b404b048df0192693e324c3b0878e736fe5c2f473a694abd7ebffed74be415",
            "ceebc6af84317789bcb3db11d0a2485526f653313340fdce2be04176057af5ea"), strict=True):
        directory = original / "native" / unit["unit_id"]
        directory.mkdir(parents=True)
        saved = canonical_json_bytes({"native_search_root": str(original / "native"),
            "native_search_replay": False, "producer_tasks": [{"task_id": name} for name in unit["task_ids"]]})
        saved += b" " * (76205 - len(saved))
        identity_leaves[saved] = spec_sha
        (directory / "spec.json").write_bytes(saved)
        (directory / "native.stdout").write_bytes(b"UNFITTED original interruption\n")
        (directory / "native.stderr").write_bytes(b"")
        for name in unit["existing_incomplete_model_task_ids"]:
            model = original / "native" / name
            model.mkdir()
            (model / "model.rds").write_bytes(b"UNFITTED_NOT_RDS:" + name.encode())
        (original / "native" / unit["task_ids"][2]).mkdir()
        work = original / "batch-work" / unit["unit_id"] / "produce" / ("f2-r-" + unit["unit_id"][:22])
        work.mkdir(parents=True)
        (work / "spec.json").write_bytes(saved)
    def fixture_file_sha(path):
        data = Path(path).read_bytes()
        return identity_leaves.get(data, sha256_bytes(data))
    monkeypatch.setattr(f5, "sha256_file", fixture_file_sha)
    monkeypatch.setattr(f5, "sha256_bytes", lambda data: identity_leaves.get(data, sha256_bytes(data)))
    monkeypatch.setattr(runtime, "effective_cpu_count", lambda: 32)
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda root: {
        "effective_cpus": 32, "available_memory_bytes": 10**12,
        "scratch_available_bytes": 10**12, "scratch_root": str(root)})
    record = f5._full0_rsf_tail_restoration_inputs(decision, original)
    policy = {"configured_worker_ceiling": runtime.CPU_MINUS_8, "memory_bytes_per_worker": 1,
        "scratch_bytes_per_worker": 1, "memory_reserve_bytes": 0, "scratch_reserve_bytes": 0,
        "transfer_archive_worker_ceiling": 24}
    return {"original": original, "decision": decision, "contract": contract, "record": record,
            "raw": raw, "task": task, "spec": spec, "policy": policy,
            "preserved": {p: sha256_file(p) for p in original.rglob("*") if p.is_file()}}


def test_original_snapshot_and_direct_reader_keep_exact_eight(interrupted):
    case = interrupted
    contract, record = case["contract"], case["record"]
    arguments = {"input_ref": contract["original_q_input"], "phase": contract["original_phase"],
                 "task_ids": [row["unit_id"] for row in contract["atomic_units"]]}
    f5._validate_q_rsf_tail_restoration_record(record, **arguments)
    assert record["additional_model_fit_count"] == 8 and record["prior_incomplete_fit_count"] is None
    assert len([name for name in record["original_members"] if name.endswith("model.rds")]) == 4
    for damage in ("four", "boolean", "one_atom", "wrong_phase", "input_float", "spec_pin", "missing_old_directory"):
        bad, kwargs = copy.deepcopy(record), copy.deepcopy(arguments)
        if damage in {"four", "boolean"}:
            bad["additional_model_fit_count"] = 4 if damage == "four" else True
        elif damage == "one_atom":
            kwargs["task_ids"].pop()
        elif damage == "wrong_phase":
            kwargs["phase"] = "wrong"
        elif damage == "input_float":
            kwargs["input_ref"]["size_bytes"] = float(kwargs["input_ref"]["size_bytes"])
        elif damage == "spec_pin":
            bad["original_members"][f"native/{kwargs['task_ids'][0]}/spec.json"]["sha256"] = "b" * 64
        else:
            bad["original_directories"]["native/" + contract["atomic_units"][0]["task_ids"][0]] = False
        with pytest.raises(ContractError):
            f5._validate_q_rsf_tail_restoration_record(bad, **kwargs)


@pytest.mark.parametrize("damage", ["copied_old_root", "input", "model", "replay", "completed", "extra_work"])
def test_original_snapshot_rejects_drift_and_relocated_failure_before_start(interrupted, tmp_path, damage):
    case = interrupted
    original = case["original"]
    unit = case["contract"]["atomic_units"][0]
    if damage == "copied_old_root":
        other = tmp_path / "copied" / "search" / "RSF"
        shutil.copytree(original, other)
        original = other
    elif damage == "input":
        (original / "input.json").write_bytes(case["raw"][:-1] + b" ")
    elif damage == "model":
        (original / "native" / unit["task_ids"][0] / "model.rds").unlink()
    elif damage == "replay":
        (original / "native-replay" / unit["unit_id"]).mkdir(parents=True)
    elif damage == "completed":
        (original / "result.json").write_bytes(b"{}")
    else:
        (original / "batch-work" / unit["unit_id"] / "unexpected.txt").write_bytes(b"changed")
    with pytest.raises(ContractError):
        f5._full0_rsf_tail_restoration_inputs(case["decision"], original)
    assert not list(original.parent.glob("RSF-restoration-*"))


@pytest.fixture
def atomic_call(interrupted, tmp_path, monkeypatch):
    case = interrupted
    root = case["original"].with_name("RSF-restoration-" + sha256_bytes(canonical_json_bytes(case["contract"]))[:12])
    (root / "native").mkdir(parents=True)
    (root / "input.json").write_bytes(case["raw"])
    ids = [row["unit_id"] for row in case["contract"]["atomic_units"]]
    control = {"batches": [], "used_batches": [], "completed": False, "task_ids": ids,
        "batch_root": tmp_path / "returned-eight", "resource_policy": case["policy"],
        "retained_bytes_per_task": 4 * 1024**2, "rsf_tail_restoration": case["record"],
        "retained_full0_source_identity": "c" * 64, "references": {}, "confirmed_model_fits": 0,
        "confirmed_stop_fits": 0}
    spec = {**case["spec"], "native_search_root": str(root / "native"), "native_search_batch": control}
    tasks = [(spec, {}, [{"task_id": f"S3B2_T001_P{p:02d}_M{m:02d}"} for m in range(first, first + 4)],
              str(root), None, "IBS", {}) for p in range(1, 16) for first in range(1, 21, 4)]
    events = []
    def r_batch(call):
        native_spec, _, models, _, _, _, _ = call
        names = [row["task_id"] for row in models]
        batch_id = "batch-" + sha256_bytes(canonical_json_bytes(names))[:24]
        assert len(models) == 4 and batch_id in ids
        actual = Path(native_spec["native_search_root"]).parent
        replay = native_spec["native_search_replay"]
        assert "native_search_batch" not in native_spec
        assert not native_spec.get("native_search_numbers")
        for name in (batch_id, *names):
            data = canonical_json_bytes({"UNFITTED": name})
            if replay:
                assert (actual / "native" / name / "evidence.json").read_bytes() == data
            destination = actual / ("native-replay" if replay else "native") / name
            destination.mkdir(parents=True)
            (destination / "evidence.json").write_bytes(data)
        events.append(("audit" if replay else "produce", names))
        return names
    r_batch.__name__ = "_run_r_prediction_pool_task"
    def projection(directory, *, native_units, **kwargs):
        paths = {"input.json": directory / "input.json", **{
            f"native/{name}/evidence.json": directory / "native" / name / "evidence.json" for name in native_units}}
        refs = {name: {"sha256": f5.sha256_file(path), "size_bytes": path.stat().st_size} for name, path in paths.items()}
        return paths, refs
    monkeypatch.setattr(kernel, "_run_r_prediction_pool_task", r_batch)
    monkeypatch.setattr(compact, "_full_pipeline_q_numerical_members", projection)
    monkeypatch.setattr(f5, "_bounded_ordered_spawn", _serial_pool)
    units = f5._q_search_units(r_batch, tasks)
    assert len(units) == 75 and all(len(native) == 5 for _, native in units.values())
    assert r_batch.__name__ + "-" + sha256_bytes(canonical_json_bytes(list(units)))[:24] == case["contract"]["original_phase"]
    return {**case, "root": root, "control": control, "call_spec": spec,
            "tasks": tasks, "function": r_batch, "events": events, "units": units}


def test_two_original_atomic_producers_first_audits_and_no_partial_phase_acceptance(atomic_call):
    case = atomic_call
    with pytest.raises(f5._QBatchBoundary) as stopped:
        f5._q_search_task_batch(case["call_spec"], case["function"], case["tasks"])
    result = stopped.value.result
    assert result["status"] == "COMPUTED_Q_BATCH" and result["stage_acceptance"] is False
    execution = result["execution"]
    assert execution["new_model_fit_count"] == execution["confirmed_first_native_audit_count"] == 8
    assert [mode for mode, _ in case["events"]] == ["produce", "audit", "produce", "audit"]
    assert [names for mode, names in case["events"] if mode == "produce"] == [
        unit["task_ids"] for unit in case["contract"]["atomic_units"]]
    assert all(sha256_file(path) == digest for path, digest in case["preserved"].items())
    batch = Path(result["batch_root"])
    for damage, expected in ((None, "F5_Q_BATCH_COMPLETE_COORDINATES_REQUIRED"),
                              ("strip_authority", "F5_RSF_TAIL_RESTORATION_RECORD_INVALID")):
        record = copy.deepcopy(execution)
        if damage:
            del record["rsf_tail_restoration"]
        with pytest.raises(ContractError, match=expected):
            f5._consume_q_search_batches(case["call_spec"], case["function"], case["units"], [(batch, record)],
                result["phase"], case["contract"]["original_q_input"])
    case["control"]["batch_root"] = batch.with_name("another-target-does-not-reset-eight")
    with pytest.raises(ContractError, match="F5_Q_COORDINATE_ALREADY_STARTED"):
        f5._q_search_task_batch(case["call_spec"], case["function"], case["tasks"])
    assert len(case["events"]) == 4 and not case["control"]["batch_root"].exists()


@pytest.mark.parametrize("damage", ["one_atom", "two_model_atom", "foreign_unit", "old_output_tree", "old_post_drift"])
def test_atomic_restore_failures_do_not_commit_consumable_success(atomic_call, monkeypatch, damage):
    case = atomic_call
    if damage == "one_atom":
        case["control"]["task_ids"] = case["control"]["task_ids"][:1]
    elif damage == "two_model_atom":
        name = case["contract"]["atomic_units"][0]["task_ids"][0]
        index = next(i for i, task in enumerate(case["tasks"]) if task[2][0]["task_id"] == name)
        task = case["tasks"][index]
        case["tasks"][index] = (*task[:2], task[2][:2], *task[3:])
    elif damage == "foreign_unit":
        case["control"]["task_ids"] = list(case["units"])[:2]
    elif damage == "old_output_tree":
        case["control"]["batch_root"] = case["original"] / "batch-work" / case["control"]["task_ids"][0] / "forbidden"
    else:
        original_pool = f5._bounded_ordered_spawn
        def pool(*args, **kwargs):
            value = original_pool(*args, **kwargs)
            path = next(path for path in case["preserved"] if path.name == "model.rds")
            path.write_bytes(path.read_bytes() + b"UNFITTED_DRIFT")
            return value
        monkeypatch.setattr(f5, "_bounded_ordered_spawn", pool)
    with pytest.raises(ContractError):
        f5._q_search_task_batch(case["call_spec"], case["function"], case["tasks"])
    if damage == "old_post_drift":
        execution = strict_json_bytes((case["control"]["batch_root"] / "execution.json").read_bytes())
        assert execution["confirmed_first_native_audit_count"] == 8 and execution["new_model_fit_count"] is None
        with pytest.raises(ContractError, match="F5_Q_BATCH_ACTUAL_FIT_COUNT_INVALID"):
            f5._consume_q_search_batches(case["call_spec"], case["function"], case["units"],
                [(case["control"]["batch_root"], execution)], case["contract"]["original_phase"],
                case["contract"]["original_q_input"])
    else:
        assert not case["events"] and not case["control"]["batch_root"].exists()


@pytest.fixture
def full0_call(interrupted, retained_source_bundle, tmp_path, monkeypatch):
    """Original outer/Q boundary and release, not raw/selector numerical proof."""
    case = interrupted
    # Synthetic process visibility only; a Mac has no Linux /proc inventory.
    monkeypatch.setattr(runtime, "sys", SimpleNamespace(platform="linux"))
    monkeypatch.setattr(runtime, "_visible_open_file_keys", lambda candidates: (set(), 1))
    source = case["original"].parent.parent / "full-development.json"
    source.write_bytes(b"UNFITTED_LINEAGE_BOUNDARY")
    selector = tmp_path / "selector-owner" / "selector"
    selector.mkdir(parents=True)
    selector_partitions = [{"evaluation_response": {"size_bytes": 4}} for _ in range(15)] + [{"UNFITTED": True}]
    for name, value in (("partitions.json", selector_partitions), ("selector.json", {"UNFITTED": True}),
                        ("development-input.json", {"UNFITTED": True})):
        (selector / name).write_bytes(canonical_json_bytes(value))
    for name in ("response.csv", "final-mice.zip"):
        (source.parent / name).write_bytes(b"UNFITTED_INPUT_NOT_A_SCIENTIFIC_PAYLOAD")
    sources = {"plan": {"UNFITTED": True}, "science_decision": _unfitted_confirmed_decision(fixed_bootstrap=True),
        "search_roots": {"RSF": str(case["original"])}, "selector_root": str(selector),
        "mice_root": str(source.parent), "final_mice_path": str(source.parent / "final-mice.zip"),
        "response_path": str(source.parent / "response.csv"), "resource_policy": case["policy"], "rscript": "FORBIDDEN"}
    previous = tmp_path / "UNFITTED_PRIOR_PHASE"
    previous.mkdir()
    (previous / "execution.json").write_bytes(canonical_json_bytes({"phase": "UNFITTED_PRIOR_COMPLETE"}))
    batch_root = tmp_path / "UNFITTED-full0-returned-batch"
    state = {"references": [], "releases": [], "materializations": 0, "boundaries": 0, "native_calls": 0,
             "computed_batch": False, "write_damage": None}
    class Inputs(dict):
        pass
    class Partitions(list):
        pass
    @contextmanager
    def materialize(path, parent, *, selector_only, retained_full0_source_bundle, q_input_lifecycle):
        assert path == source and parent == source.parent and selector_only and not q_input_lifecycle
        state["materializations"] += 1
        owned = Path(tempfile.mkdtemp(prefix="f5-full-development-inputs-", dir=parent))
        (owned / "UNFITTED-input.bin").write_bytes(b"owned input")
        partitions, full = Partitions([{"UNFITTED": True}]), Inputs(development_input={"UNFITTED": True})
        state["references"].extend((weakref.ref(partitions), weakref.ref(full)))
        yield sources, partitions, full
        q_input_lifecycle["materialized_inputs"] = {"temporary_root": str(owned)}
    def compile_task(plan, partitions, full, selector_root, *, q_input_lifecycle, **kwargs):
        assert not q_input_lifecycle and selector_root == selector and kwargs["family"] == "RSF"
        owned = Path(tempfile.mkdtemp(prefix="nested-full-selector-replay-", dir=selector.parent))
        (owned / "validation-responses").mkdir()
        for index in range(1, 16):
            (owned / "validation-responses" / f"inner-{index:02d}.csv").write_bytes(b"data")
        q_input_lifecycle["selector_program"] = {"temporary_root": str(owned)}
        return copy.deepcopy(case["task"])
    def boundary(spec, registered, scratch):
        state["boundaries"] += 1
        owned = Inputs(UNFITTED=bytearray(65536))
        state["references"].append(weakref.ref(owned))
        assert spec["threads"] == spec["pool_workers"] == 56 and spec["active_worker_limit"] == 24
        control = spec["native_search_batch"]
        assert control["prepare_only"] is not state["computed_batch"]
        assert spec["native_search_batch"]["rsf_tail_restoration"] == case["record"]
        names = [[f"S3B2_T001_P{p:02d}_M{m:02d}" for m in range(first, first + 4)]
                 for p in range(1, 16) for first in range(1, 21, 4)]
        ids = ["batch-" + sha256_bytes(canonical_json_bytes(unit))[:24] for unit in names]
        result = {"status": "PREPARED_Q_BATCH", "stage_acceptance": False,
            "native_search_root": str(Path(spec["native_search_root"]).parent),
            "phase": case["contract"]["original_phase"], "task_ids": ids, "new_model_fits": 0}
        if state["computed_batch"]:
            assert control["batch_root"] == batch_root
            ids = [row["unit_id"] for row in case["contract"]["atomic_units"]]
            assert control["task_ids"] == ids
            execution = {"UNFITTED": "No native model or scientific calculation",
                "input": case["contract"]["original_q_input"],
                "source_identity": sha256_bytes(canonical_json_bytes(f4._f45_source_member_sha256())),
                "phase": result["phase"], "task_ids": ids}
            batch_root.mkdir()
            written = batch_root / "execution.json"
            raw = canonical_json_bytes(execution)
            state["written_bytes"] = raw
            damage = state["write_damage"]
            if damage != "missing":
                if damage == "symlink":
                    original = batch_root / "UNFITTED-original.json"
                    original.write_bytes(raw)
                    written.symlink_to(original)
                else:
                    written.write_bytes(b"x" * (16 * 1024**2 + 1) if damage == "oversized" else
                                        raw + b" " if damage == "different" else raw)
            state["last_write_ns"] = monotonic_ns()
            result.update(status="COMPUTED_Q_BATCH", task_ids=ids, batch_root=str(batch_root), execution=execution)
        raise f5._QBatchBoundary(result)
    original_release = runtime.release_step_resources
    def release(files, **kwargs):
        assert all(not path.is_relative_to(case["original"]) and not path.is_relative_to(selector) for path in files)
        value = original_release(files, **kwargs)
        assert all(reference() is None for reference in state["references"])
        state["releases"].append(kwargs["owner"])
        return value
    def forbidden(*args, **kwargs):
        state["native_calls"] += 1
        pytest.fail("This original-call ownership test must not fit, replay native engines or use RNG")
    monkeypatch.setattr(f5, "_read_final_lineage", lambda *a, **k: sources)
    monkeypatch.setattr(f5, "_full_data_mice_scope", lambda plan: (True, None))
    monkeypatch.setattr(f5, "_final_search_mice_members", lambda *a, **k: {})
    monkeypatch.setattr(f5, "_materialized_full_data_development_sources", materialize)
    monkeypatch.setattr(f5, "compile_nested_full_complex_search_task", compile_task)
    monkeypatch.setattr(f5, "_nested_selector_numerical_members", lambda root: {p.name: p for p in root.iterdir()})
    monkeypatch.setattr(f5, "_complex_runtime_registered_inputs", lambda *a: {"identity": "b" * 64})
    monkeypatch.setattr(f5, "_complex_search_execution_spec", lambda *a: copy.deepcopy(case["spec"]))
    monkeypatch.setattr(f5, "_run_final_complex_search", boundary)
    monkeypatch.setattr(runtime, "release_step_resources", release)
    monkeypatch.setattr(f5.subprocess, "run", forbidden)
    arguments = {"full_development_path": source, "candidate_family": "RSF", "target": tmp_path / "never-archive.zip",
        "prepare_only": True, "q_batches": [previous], "retained_full0_source_bundle": retained_source_bundle,
        "rsf_tail_science_decision": case["decision"]}
    def prepare_computed():
        # A real compute call follows preparation of this exact restoration root.
        # Only the fixture's already-marked UNFITTED input is copied here.
        prepared = case["original"].with_name("RSF-restoration-" + sha256_bytes(
            canonical_json_bytes(case["contract"]))[:12])
        prepared.mkdir()
        (prepared / "native").mkdir()
        (prepared / "input.json").write_bytes(case["raw"])
        case["preserved"][prepared / "input.json"] = sha256_bytes(case["raw"])
        state["computed_batch"] = True
        return {**arguments, "prepare_only": False, "batch_root": batch_root,
            "task_ids": [row["unit_id"] for row in case["contract"]["atomic_units"]], "retained_bytes_per_task": 1048576}
    selector_binding = {p.name: {"sha256": sha256_file(p), "size_bytes": p.stat().st_size} for p in selector.iterdir()}
    def consume(value, expected=None):
        f5._validate_full0_q_input_execution(value, source=source, source_sha256=sha256_file(source),
            source_identity=sha256_bytes(canonical_json_bytes(f4._f45_source_member_sha256())),
            q_root=Path(value["native_search_root"]), q_input=case["contract"]["original_q_input"],
            task_sha256=case["task"]["task_sha256"], expected_result_sha256=expected or value["execution_report"]["result_sha256"],
            selector_root=selector, selector_binding=selector_binding, selector_partitions=selector_partitions,
            policy=case["policy"], expected_batch_root=batch_root)
    return {**case, "source": source, "selector": selector, "arguments": arguments, "state": state,
            "consume": consume, "release": release, "batch_root": batch_root, "prepare_computed": prepare_computed}


def test_full0_post_batch_write_is_bound_before_original_input_release(full0_call, tmp_path, monkeypatch, capsys):
    case = full0_call
    case["prepare_computed"]()
    decision_path = tmp_path / "decision.json"
    decision_path.write_bytes(canonical_json_bytes(case["decision"]))
    options = case["arguments"]
    ids = [row["unit_id"] for row in case["contract"]["atomic_units"]]
    monkeypatch.setattr(sys, "argv", ["padml-f5", "complex-search", "--full-development", str(case["source"]),
        "--candidate-family", "RSF", "--target", str(options["target"]), "--q-batches", str(options["q_batches"][0]),
        "--retained-full0-source-bundle", str(options["retained_full0_source_bundle"]),
        "--rsf-tail-science-decision", str(decision_path), "--batch-root", str(case["batch_root"]),
        "--retained-bytes-per-task", "1048576", "--task-ids", *ids])
    f5.main()
    output = capsys.readouterr()
    assert not output.err
    result = strict_json_bytes(output.out.encode())
    case["consume"](result)
    report, written = result["execution_report"], case["batch_root"] / "execution.json"
    assert written.read_bytes() == case["state"]["written_bytes"] == canonical_json_bytes(result["execution"])
    assert report["post_batch_write"] == {"path": str(written), "sha256": sha256_file(written),
                                           "size_bytes": written.stat().st_size}
    assert Path(report["report_path"]).read_bytes() == canonical_json_bytes(result)
    assert len(report["input_lifecycle"]) == 3
    assert all(row["resource_release"]["before"]["started_ns"] >= case["state"]["last_write_ns"]
               and not Path(row["temporary_root"]).exists() for row in report["input_lifecycle"].values())
    assert result["new_model_fits"] == case["state"]["native_calls"] == 0
    assert all(sha256_file(path) == digest for path, digest in case["preserved"].items())
    for damage in ("path", "digest", "float_size", "bool_size", "relocated_together"):
        bad = copy.deepcopy(result)
        pin = bad["execution_report"]["post_batch_write"]
        if damage == "path":
            pin["path"] += ".different"
        elif damage == "digest":
            pin["sha256"] = "0" * 64
        elif damage in {"float_size", "bool_size"}:
            pin["size_bytes"] = float(pin["size_bytes"]) if damage == "float_size" else True
        else:
            bad["batch_root"] += "-other"
            pin["path"] = str(Path(bad["batch_root"]) / "execution.json")
            bad["execution_report"]["result_sha256"] = sha256_bytes(canonical_json_bytes({
                key: row for key, row in bad.items() if key != "execution_report"}))
        with pytest.raises(ContractError):
            case["consume"](bad, bad["execution_report"]["result_sha256"])
    legacy = copy.deepcopy(result)
    del legacy["execution_report"]["post_batch_write"]
    case["consume"](legacy)  # No retroactive write-boundary evidence for old reports.


@pytest.mark.parametrize("damage", ["missing", "different", "oversized", "symlink"])
def test_full0_unfinished_batch_write_stops_before_releasing_inputs(full0_call, capsys, damage):
    case = full0_call
    options = case["prepare_computed"]()
    case["state"]["write_damage"] = damage
    with pytest.raises(ContractError) as raised:
        f5.execute_final_complex_search(**options)
    assert capsys.readouterr().out == ""
    root = Path(next(note.split(":", 1)[1] for note in raised.value.__notes__
                     if note.startswith("F5_Q_EXECUTION_EVIDENCE_RETAINED:")))
    failure = strict_json_bytes((root / "q-input-execution.json").read_bytes())
    report = failure["execution_report"]
    assert failure["result"]["status"] == "COMPUTED_Q_BATCH" and report["result_sha256"]
    assert "post_batch_write" not in report and len(report["input_lifecycle"]) == 3
    assert not case["state"]["releases"]
    assert all(Path(row["temporary_root"]).is_dir() and "resource_release" not in row
               for row in report["input_lifecycle"].values())
    assert case["state"]["native_calls"] == 0 and case["batch_root"].is_dir()
    assert all(sha256_file(path) == digest for path, digest in case["preserved"].items())


def test_original_full0_cli_preserves_q_bytes_and_releases_only_three_owners(full0_call, tmp_path, monkeypatch, capsys):
    case = full0_call
    decision_path = tmp_path / "decision.json"
    decision_path.write_bytes(canonical_json_bytes(case["decision"]))
    options = case["arguments"]
    monkeypatch.setattr(sys, "argv", ["padml-f5", "complex-search", "--full-development", str(case["source"]),
        "--candidate-family", "RSF", "--target", str(options["target"]), "--prepare-only", "--q-batches",
        str(options["q_batches"][0]), "--retained-full0-source-bundle", str(options["retained_full0_source_bundle"]),
        "--rsf-tail-science-decision", str(decision_path)])
    f5.main()
    output = capsys.readouterr()
    assert not output.err
    result = strict_json_bytes(output.out.encode())
    case["consume"](result)
    report = result["execution_report"]
    assert Path(report["report_path"]).read_bytes() == canonical_json_bytes(result)
    assert (Path(result["native_search_root"]) / "input.json").read_bytes() == case["raw"]
    assert [name.rsplit(":", 1)[1] for name in case["state"]["releases"]] == [
        "selector_program", "q_program", "materialized_inputs"]
    assert all(not Path(row["temporary_root"]).exists() for row in report["input_lifecycle"].values())
    assert all(sha256_file(path) == digest for path, digest in case["preserved"].items())
    assert result["new_model_fits"] == case["state"]["native_calls"] == 0
    assert len(result["task_ids"]) == 75
    # No marker means the original receipt formula, not a retroactive waiver.
    legacy = copy.deepcopy(result)
    old = legacy["execution_report"]
    del old["execution_scratch_reserve_bytes"], old["operational_errors"]
    old["effective_policy"]["scratch_reserve_bytes"] = case["policy"]["scratch_reserve_bytes"] + 64 * 1024**2
    old["resource_admission"] = runtime.resource_admission(
        old["effective_policy"], old["resource_observation"], legal_tasks=1)
    old["after_release"]["resource_admission"] = runtime.resource_admission(
        old["effective_policy"], old["after_release"]["resource_observation"], legal_tasks=1)
    case["consume"](legacy)
    old["effective_policy"]["scratch_reserve_bytes"] = 0
    with pytest.raises(ContractError): case["consume"](legacy)
    expected = report["result_sha256"]
    for damage in ("phase_resealed", "ids_resealed", "input_float", "missing_owner", "foreign_owner",
                   "missing_response", "missing_diagnostics"):
        bad = copy.deepcopy(result)
        inputs = bad["execution_report"]["input_lifecycle"]
        if damage.endswith("resealed"):
            bad["phase" if damage == "phase_resealed" else "task_ids"] = "OTHER" if damage == "phase_resealed" else []
            bad["execution_report"]["result_sha256"] = sha256_bytes(canonical_json_bytes({
                key: value for key, value in bad.items() if key != "execution_report"}))
        elif damage == "input_float":
            bad["execution_report"]["q_input"]["size_bytes"] = float(bad["execution_report"]["q_input"]["size_bytes"])
        elif damage == "missing_owner":
            del inputs["q_program"]
        elif damage == "foreign_owner":
            inputs["q_program"]["temporary_root"] = str(case["original"])
        elif damage == "missing_response":
            inputs["selector_program"]["resource_release"]["files"].pop()
        else:
            del inputs["materialized_inputs"]["resource_release"]["before"]
        with pytest.raises(ContractError):
            case["consume"](bad, expected)


@pytest.mark.parametrize("failure", ["post_admission", "open_reader", "mmap_reader", "delete_second"])
def test_full0_failure_keeps_result_measurements_and_original_files(full0_call, monkeypatch, capsys, failure):
    case, held, deletes = full0_call, [], []
    original_observe, original_remove = runtime.observe_execution_resources, f5.shutil.rmtree
    def observe(root):
        value = original_observe(root)
        if failure == "post_admission" and len(case["state"]["releases"]) == 3:
            value["available_memory_bytes"] = 1
        return value
    def release(files, **kwargs):
        if failure in {"open_reader", "mmap_reader"} and not held:
            handle = files[0].open("rb")
            held.append(handle)
            stat = files[0].stat()
            key = (stat.st_dev, stat.st_ino)
            monkeypatch.setattr(runtime, "_visible_open_file_keys",
                                lambda candidates: (candidates.intersection({key}), 1))
            if failure == "mmap_reader":
                held.append(mmap.mmap(handle.fileno(), 0, access=mmap.ACCESS_READ))
                handle.close()
        return case["release"](files, **kwargs)
    def remove(path, *args, **kwargs):
        deletes.append(Path(path))
        if failure == "delete_second" and len(deletes) == 2:
            raise OSError("UNFITTED_SECOND_DELETE_FAILED")
        return original_remove(path, *args, **kwargs)
    monkeypatch.setattr(runtime, "observe_execution_resources", observe)
    monkeypatch.setattr(runtime, "release_step_resources", release)
    monkeypatch.setattr(f5.shutil, "rmtree", remove)
    try:
        if failure == "post_admission":
            with pytest.raises(ContractError) as raised:
                f5.execute_final_complex_search(**case["arguments"])
        else:
            result = f5.execute_final_complex_search(**case["arguments"])
            case["consume"](result)
    finally:
        for handle in reversed(held):
            handle.close()
    assert capsys.readouterr().out == ""
    if failure == "post_admission":
        root = Path(next(note.split(":", 1)[1] for note in raised.value.__notes__
                         if note.startswith("F5_Q_EXECUTION_EVIDENCE_RETAINED:")))
        failure_report = strict_json_bytes((root / "q-input-execution.json").read_bytes())
        report = failure_report["execution_report"]
        assert failure_report["result"]["phase"] == case["contract"]["original_phase"]
        assert report["operational_errors"][-1]["operation"] == "POST_STEP_ADMISSION"
    else:
        report = result["execution_report"]
        assert Path(report["report_path"]).read_bytes() == canonical_json_bytes(result)
    assert report["result_sha256"] and case["state"]["native_calls"] == 0
    assert all(sha256_file(path) == digest for path, digest in case["preserved"].items())
    if failure == "post_admission":
        assert report["after_release"]["resource_observation"]["available_memory_bytes"] == 1
        assert report["after_release"]["resource_admission"] is None and not deletes
    elif failure == "delete_second":
        saved = strict_json_bytes(Path(report["report_path"]).read_bytes())
        case["consume"](saved)
        assert len(deletes) == 3 and not deletes[0].exists() and deletes[1].is_dir() and not deletes[2].exists()
        assert report["operational_errors"] == [{"operation": "INPUT_DELETE:q_program",
            "error": "OSError:UNFITTED_SECOND_DELETE_FAILED"}]
    else:
        assert len(deletes) == 2
        assert any(member["status"] == "ACTIVE_READER_OR_WRITER"
                   for row in report["input_lifecycle"].values() for member in row["resource_release"]["files"])
    assert sum(Path(row["temporary_root"]).is_dir() for row in report["input_lifecycle"].values()) == (
        3 if failure == "post_admission" else 1)
    gc.collect()
    assert all(reference() is None for reference in case["state"]["references"])


@pytest.mark.parametrize("diagnostic", ["scan", "exception"])
def test_future_full0_release_errors_do_not_veto_science(full0_call, monkeypatch, diagnostic):
    case = full0_call
    def unavailable(*args, **kwargs):
        raise PermissionError("UNFITTED diagnostic unavailable")
    monkeypatch.setattr(runtime, "_visible_open_file_keys" if diagnostic == "scan" else
                        "release_step_resources", unavailable)
    # Deliberately impossible old reserve, without changing real free space.
    case["policy"]["scratch_reserve_bytes"] = 10**15
    result = f5.execute_final_complex_search(**case["arguments"])
    case["consume"](result)
    report = result["execution_report"]
    assert report["execution_scratch_reserve_bytes"] == report["effective_policy"]["scratch_reserve_bytes"] == 0
    assert report["resource_policy"]["scratch_reserve_bytes"] == 10**15
    assert report["effective_policy"]["memory_bytes_per_worker"] == 2147483648
    assert result["new_model_fits"] == case["state"]["native_calls"] == 0
    assert all(Path(row["temporary_root"]).is_dir() for row in report["input_lifecycle"].values())
    assert all(row["resource_release"].get("reader_scan_status", row["resource_release"].get("status")) == "UNKNOWN"
               for row in report["input_lifecycle"].values())
    assert len(report["operational_errors"]) == (3 if diagnostic == "exception" else 0)
    assert all(sha256_file(path) == digest for path, digest in case["preserved"].items())
    for change in ("scratch_bool", "budget", "result", "source", "owner"):
        bad = copy.deepcopy(result)
        if change == "scratch_bool": bad["execution_report"]["execution_scratch_reserve_bytes"] = False
        elif change == "budget": bad["execution_report"]["effective_policy"]["memory_bytes_per_worker"] = 1
        elif change == "result": bad["new_model_fits"] = 1
        elif change == "source": bad["execution_report"]["source_identity"] = "0" * 64
        else: bad["execution_report"]["input_lifecycle"]["q_program"]["resource_release"]["owner"] = "FOREIGN"
        with pytest.raises(ContractError): case["consume"](bad)


def test_future_full0_real_disk_shortfall_still_blocks_before_inputs(full0_call, monkeypatch):
    case = full0_call
    original = runtime.observe_execution_resources
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda root:
        {**original(root), "scratch_available_bytes": 0})
    with pytest.raises(ContractError):
        f5.execute_final_complex_search(**case["arguments"])
    assert case["state"]["materializations"] == case["state"]["boundaries"] == case["state"]["native_calls"] == 0
    assert all(sha256_file(path) == digest for path, digest in case["preserved"].items())


@pytest.mark.parametrize("damage", ["four_only", "other_horizon", "other_family", "old_batch", "old_target", "aliased_target"])
def test_public_restore_scope_rejects_before_materialization(full0_call, tmp_path, damage):
    case = full0_call
    options = dict(case["arguments"])
    if damage == "four_only":
        options.update(prepare_only=False, task_ids=[case["contract"]["atomic_units"][0]["unit_id"]],
                       batch_root=tmp_path / "never-batch")
    elif damage == "other_horizon":
        options["selection_horizon_months"] = 12
    elif damage == "other_family":
        options["candidate_family"] = "GBM_COX"
    elif damage == "old_batch":
        options.update(prepare_only=False, task_ids=[unit["unit_id"] for unit in case["contract"]["atomic_units"]],
                       batch_root=case["original"] / "batch-work" / case["contract"]["atomic_units"][0]["unit_id"] / "forbidden")
    elif damage == "old_target":
        options["target"] = case["original"] / "never-created.zip"
    else:
        alias = tmp_path / "old-root-alias"
        alias.symlink_to(case["original"], target_is_directory=True)
        options["target"] = alias / "never-created.zip"
    with pytest.raises(ContractError):
        f5.execute_final_complex_search(**options)
    assert case["state"]["materializations"] == case["state"]["boundaries"] == case["state"]["native_calls"] == 0
    assert not options["target"].exists() and not list(case["original"].parent.glob("RSF-restoration-*"))
    assert all(sha256_file(path) == digest for path, digest in case["preserved"].items())
