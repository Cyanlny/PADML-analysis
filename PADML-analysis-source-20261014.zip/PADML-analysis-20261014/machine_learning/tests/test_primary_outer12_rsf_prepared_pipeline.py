"""UNFITTED original prepared-Q publisher/worker routing; never invokes an engine."""
import copy
from pathlib import Path

import pytest

from padml import f2_kernel as kernel, f4, f5, runtime
from padml.bundle import (ContractError, canonical_json_bytes, sha256_bytes,
    sha256_file, read_safe_zip, write_deterministic_zip)
from test_primary_outer12_rsf_inputs import _call

POLICY = {"configured_worker_ceiling": runtime.CPU_MINUS_8, "memory_bytes_per_worker": 1,
    "memory_reserve_bytes": 0, "scratch_bytes_per_worker": 1, "scratch_reserve_bytes": 0,
    "transfer_archive_worker_ceiling": 64}


def _published(tmp_path, monkeypatch, outer=1, *, available_scratch=128 * 1024**3):
    base = _call(tmp_path, outer)
    original = copy.deepcopy(base[0])
    original.pop("action")
    original.update(threads=56, pool_workers=56, engine_threads=1, execution_mode="PROCESS_POOL",
                    monthly_fit_horizons=list(range(1, 37)),
                    candidate_trials={"S1": [], "S2": [{"UNFITTED_CANDIDATE": 1}, {"UNFITTED_CANDIDATE": 2}]})
    spec = kernel._r_prediction_child_spec(original)
    spec.pop("native_search_root"); spec.pop("native_search_replay")
    tasks, calls = {}, []
    for first in range(1, 25, 2):
        for part in range(1, 6):
            call = copy.deepcopy(base)
            call = [spec, *call[1:]]
            identifier = f"INNER_F{outer}_R1_K{part}"
            for row in (call[1]["partitions"][0], call[6]):
                row.update(partition_id=identifier, inner_fold=part)
            call[1]["projected_partition_ids"] = [identifier]
            call[2] = [{"task_id": f"S1_T{trial:03d}_P{part:02d}_M01", "partition_id": identifier,
                "family": "RSF", "imputation": 1, "seed": 310100 + 1000 * outer + part,
                "parameters": {"UNFITTED_INTEGER": trial, "UNFITTED_STRING": "0.5"},
                "prediction_horizons": list(range(1, 37))}
                for trial in (first, first + 1)]
            name = "batch-" + sha256_bytes(canonical_json_bytes([row["task_id"] for row in call[2]]))[:24]
            tasks[name] = call[2]
            calls.append(call)
    q = tmp_path / "q"; q.mkdir()
    raw = canonical_json_bytes({"kind": "PADML_F5_Q_INPUT_V1", "spec": original, "task": {"UNFITTED": True}})
    (q / "input.json").write_bytes(raw)
    preparation, producer = tmp_path / "UNFITTED-preparation.zip", tmp_path / "UNFITTED-producer.zip"
    preparation.write_bytes(b"UNFITTED_PREPARATION")
    producer.write_bytes(b"UNFITTED_PRODUCER")
    # This routing fixture substitutes only the separately tested retained
    # historical-source reader; it does not claim a real F1/F2 authorization.
    def binding(value, prepared, source):
        if value != raw or prepared.read_bytes() != b"UNFITTED_PREPARATION" or source.read_bytes() != b"UNFITTED_PRODUCER":
            raise ContractError("UNFITTED_SOURCE_DRIFT")
        return spec, tasks
    monkeypatch.setattr(f5, "_primary_rsf_prepared_input", binding)
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda root: {
        "effective_cpus": 32, "available_memory_bytes": 128 * 1024**3,
        "scratch_available_bytes": available_scratch, "scratch_root": str(root)})
    outputs = [[str(tmp_path / f"host-{i}.zip"), *list(tasks)[i::7]] for i in range(7)]
    control = {"resource_policy": POLICY, "retained_bytes_per_task": 1024**2,
        "prepare_only": True, "task_ids": None, "batches": [], "used_batches": [], "completed": {},
        "confirmed_model_fits": 0, "confirmed_stop_fits": 0, "q_unit_outputs": outputs,
        "primary_rsf_preparation": preparation, "primary_rsf_producer": producer}
    guarded = {**original, "native_search_root": str(q / "native"), "native_search_batch": control}
    with pytest.raises(f5._QBatchBoundary) as boundary:
        f5._q_search_task_batch(guarded, kernel._run_r_prediction_pool_task, calls)
    assert boundary.value.result["new_model_fits"] == 0
    assert boundary.value.result["model_coordinate_count"] == 120
    assert control["confirmed_model_fits"] == control["confirmed_stop_fits"] == 0
    return outputs, spec, tasks


def test_primary_publisher_rejects_insufficient_actual_archive_space(tmp_path, monkeypatch):
    # One byte satisfies the original per-worker scratch term when its
    # reserve is zero, but cannot hold the concrete prepared archive.
    with pytest.raises(ContractError, match="F5_Q_BATCH_NUMERICAL_STORAGE_REQUIRED"):
        _published(tmp_path, monkeypatch, available_scratch=1)
    assert not list(tmp_path.glob("host-*.zip"))
    assert not (tmp_path / "q" / "prepared-unit-inputs.json").exists()


@pytest.mark.parametrize("outer", range(1, 7))
def test_primary_rsf_publisher_to_original_worker_preserves_60_two_model_atoms(tmp_path, monkeypatch, outer):
    seen = []
    def execution(function, units, root, control, phase, input_ref, **kwargs):
        assert function is kernel._run_r_prediction_pool_task
        assert control["execution_worker_memory_bytes"] == 2147483648
        assert control["execution_scratch_reserve_bytes"] == 0
        assert kwargs == {"rsf_boundary": {}, "mixed_s3b1": False, "continuing": None, "restoration": None}
        for name, (call, native) in units.items():
            assert canonical_json_bytes(call[0]) == canonical_json_bytes(expected_spec)
            assert canonical_json_bytes(call[2]) == canonical_json_bytes(expected_tasks[name])
            assert native == (name, *[row["task_id"] for row in call[2]]) and len(call[2]) == 2
            assert not kernel._contains_key(call[1], "evaluation_response")
            assert "a12_source" not in call[0]
            seen.append(name)
        raise f5._QBatchBoundary({"UNFITTED": True})
    monkeypatch.setattr(f5, "_execute_q_search_batch", execution)
    outputs, expected_spec, expected_tasks = _published(tmp_path, monkeypatch, outer)
    for i, output in enumerate(outputs):
        path = Path(output[0])
        value = f5._execute_a12_prepared_q_batch(path, tmp_path / f"worker-{i}",
            expected_sha256=sha256_file(path), task_ids=output[1:], batch_root=tmp_path / f"batch-{i}",
            retained_bytes_per_task=1024**2)
        assert value == {"UNFITTED": True}
    assert len(seen) == len(set(seen)) == 60 and set(seen) == set(expected_tasks)


@pytest.mark.parametrize("damage", ["integer-as-float", "string-as-float", "seed-as-float",
    "horizons", "predecessor", "half", "source-archive", "extra-response",
    "registered-identity", "registered-fold", "registered-count", "registered-projection", "evaluation-fit-ids"])
def test_primary_rsf_prepared_payload_damage_cannot_invoke_worker(tmp_path, monkeypatch, damage):
    outputs, _, _ = _published(tmp_path, monkeypatch)
    entries = read_safe_zip(Path(outputs[0][0]))
    import json
    record = json.loads(entries["prepared-q.json"])
    name = record["task_ids"][0]
    pins = record["units"][name]
    arguments = record["arguments"]
    if damage == "predecessor":
        record["predecessor_execution_sha256"] = ["f" * 64]
    elif damage == "source-archive":
        entries["source/primary-preparation.zip"] = b"TAMPERED_PREPARATION"
        record["members"]["source/primary-preparation.zip"] = {
            "sha256": sha256_bytes(entries["source/primary-preparation.zip"]), "size_bytes": len(entries["source/primary-preparation.zip"])}
    elif damage == "extra-response":
        entries["data/OUTER_response.csv"] = b"UNFITTED_OUTER_RESPONSE"
        record["members"]["data/OUTER_response.csv"] = {
            "sha256": sha256_bytes(entries["data/OUTER_response.csv"]), "size_bytes": len(entries["data/OUTER_response.csv"])}
    else:
        slot = (0 if damage == "horizons" else 1 if damage.startswith("registered-")
                else 6 if damage == "evaluation-fit-ids" else 2)
        old = pins[slot]
        value = copy.deepcopy(arguments[old])
        if damage == "horizons": value["horizons"] = list(range(1, 13))
        elif damage == "registered-identity": value["identity"] = "f" * 64
        elif damage == "registered-fold": value["fold"] = 2
        elif damage == "registered-count": value["inner_count"] = 15.0
        elif damage == "registered-projection": value["projected_partition_ids"] = ["INNER_F1_R1_K5"]
        elif damage == "evaluation-fit-ids": value["fit_ids"] = ["UNFITTED_WRONG_TRAIN"]
        elif damage == "half": value.pop()
        elif damage == "seed-as-float": value[0]["seed"] = float(value[0]["seed"])
        elif damage == "integer-as-float": value[0]["parameters"]["UNFITTED_INTEGER"] = float(value[0]["parameters"]["UNFITTED_INTEGER"])
        else: value[0]["parameters"]["UNFITTED_STRING"] = 0.5
        new = sha256_bytes(canonical_json_bytes(value))
        for unit in record["units"].values():
            if unit[slot] == old: unit[slot] = new
        del arguments[old]; arguments[new] = value
    entries["prepared-q.json"] = canonical_json_bytes(record)
    target = tmp_path / "tampered.zip"; write_deterministic_zip(target, entries)
    monkeypatch.setattr(f5, "_execute_q_search_batch", lambda *a, **k: pytest.fail("invalid payload invoked worker"))
    with pytest.raises(ContractError):
        f5._execute_a12_prepared_q_batch(target, tmp_path / "bad-worker",
            expected_sha256=sha256_file(target), task_ids=record["task_ids"],
            batch_root=tmp_path / "bad-batch", retained_bytes_per_task=1024**2)


def test_historical_primary_preparation_pin_rejects_repacked_result(tmp_path, monkeypatch):
    monkeypatch.setattr(f4, "_retained_full0_source_members", lambda *a, **k: {"UNFITTED": "a" * 64})
    target = tmp_path / "changed.zip"
    target.write_bytes(b"X" * 31442)
    with pytest.raises(ContractError, match="PRIMARY_RSF_PREPARED_SOURCE"):
        f5._primary_rsf_prepared_input(b"Y" * 123818, target, tmp_path / "source.zip")
