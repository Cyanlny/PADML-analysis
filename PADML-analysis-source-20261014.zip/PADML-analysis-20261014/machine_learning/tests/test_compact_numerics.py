import copy
import math
from pathlib import Path

import numpy as np
import pytest


def test_float32_breslow_retains_original_native_reduction():
    import numpy as np
    from padml import f2_kernel as k
    rng = np.random.default_rng(9183)
    times = rng.integers(1, 40, 2124).astype(float)
    events = rng.integers(0, 2, len(times))
    risk = np.exp(rng.normal(0, 4, len(times)).astype('float32'))
    event_times = np.unique(times[events == 1])
    reference = np.cumsum(np.asarray([np.sum((times == t) & (events == 1)) /
        np.sum(risk[times >= t]) for t in event_times], dtype=float))
    actual_times, actual = k._breslow(times, events, risk, np)
    assert np.array_equal(actual_times, event_times)
    assert np.array_equal(actual, reference)
    # The rejected wider sum is mathematically valid but changes this contract.
    _, wider = k._breslow(times, events, risk.astype('float64'), np)
    assert not np.allclose(wider, reference, rtol=1e-10, atol=1e-12)

from padml.bundle import ContractError, canonical_json_bytes
from padml import f2_kernel as k, f5


def reference_loglik(times, events, eta):
    value = 0.0
    for t in sorted({t for t, e in zip(times, events) if e}):
        failures = [i for i, (x, e) in enumerate(zip(times, events)) if x == t and e]
        risks = [i for i, x in enumerate(times) if x >= t]
        maximum = max(eta[i] for i in risks)
        denominator = maximum + math.log(math.fsum(math.exp(eta[i]-maximum) for i in risks))
        value += math.fsum(eta[i] for i in failures) - len(failures)*denominator
    return value


@pytest.mark.parametrize('shift,scale', [(0, 1), (1000, 1), (-1000, 50), (0, 500)])
def test_compact_risk_sets_preserve_breslow_ties_and_extreme_scores(shift, scale):
    rng = np.random.RandomState(735)
    times = rng.randint(1, 80, 900).astype(float).tolist()
    events = rng.binomial(1, .5, 900).tolist()
    eta = (rng.normal(size=900)*scale+shift).tolist()
    groups = k._cox_breslow_event_groups(times, events)
    assert len(groups.order)+len(groups.starts)+sum(map(len, groups.failures)) <= 3*len(times)
    assert k._cox_breslow_log_likelihood(times, events, eta, event_groups=groups) == pytest.approx(
        reference_loglik(times, events, eta), rel=1e-12, abs=1e-10)


def test_grouped_baseline_preserves_all_increments_and_monthly_curve():
    rng = np.random.RandomState(45)
    time = rng.randint(1, 37, 1400).astype(float)
    event = rng.binomial(1, .4, len(time))
    risk = np.exp(rng.normal(size=len(time)))
    ticks = np.unique(time[event == 1])
    original = np.cumsum([np.sum((time == t) & (event == 1))/np.sum(risk[time >= t]) for t in ticks])
    observed_t, observed = k._breslow(time, event, risk, np)
    np.testing.assert_array_equal(observed_t, ticks)
    np.testing.assert_allclose(observed, original, rtol=1e-12, atol=1e-12)
    np.testing.assert_allclose(k._survival_from_risk(ticks, original, risk, list(range(37)), np),
        k._survival_from_risk(ticks, observed, risk, list(range(37)), np), rtol=1e-12, atol=1e-12)


@pytest.mark.parametrize('carrier', [False, True])
def test_shap_tensor_single_entity_and_direct_summary(tmp_path, monkeypatch, carrier):
    from test_f5 import paired_predictions, final_shap_components
    from padml.carriers import open_carrier
    records, receipts, _, decision, plan, centers = paired_predictions()
    pooled = f5.pool_predictions(records, receipts, decision, plan, centers)
    components = final_shap_components(pooled, max_iter=2000)
    reference = f5.aggregate_final_shap(components, pooled)
    if carrier:
        run = tmp_path/'run.json'
        run.write_bytes(canonical_json_bytes({'kind':'PADML_INTEGRATED_RAW_RUN_V1',
            'run_root':str(tmp_path), 'source_identity':'c'*64, 'identity':'d'*64}))
        monkeypatch.setenv('PADML_F45_RUN_PATH', str(run))
    compact = []
    for imp, component in enumerate(components, 1):
        value = copy.deepcopy(component)
        value.update(schema_version='2.0.0', kind='PADML_F5_FINAL_SHAP_COMPONENT_V2',
            standard_errors=np.zeros_like(value['risk_contributions']).tolist())
        path = tmp_path/f'M{imp:02d}.zip'
        f5._write_shap_checkpoint(path, {'imputation':imp}, value)
        binding, reread = f5._read_shap_checkpoint(path)
        assert binding == canonical_json_bytes({'imputation':imp})
        np.testing.assert_array_equal(reread['risk_contributions'], value['risk_contributions'])
        assert not reread['risk_contributions'].flags.writeable
        f5._validate_final_shap_component(reread, task={'family':value['family'],
            'imputation':imp,'selected_parents':value['selected_parent_groups']},
            prediction=records[imp-1], model_sha256=value['model_sha256'])
        if carrier:
            with open_carrier(path) as archive:
                assert len(archive.references) == 3
                assert archive.external_path('risk-contributions.f64') is not None
        pin = f5._shap_path_pin(path)
        compact.append(f5._shap_collection_result(reread, {
            'archive_sha256':pin['sha256'],'archive_size_bytes':pin['size_bytes'],
            'component_sha256':f5._shap_component_sha(reread)},path,imp)['component'])
    summary = f5.aggregate_final_shap(compact, pooled)
    assert summary['global_importance'] == reference['global_importance']
    assert summary['patient_contributions'] == reference['patient_contributions']
    assert 'signed_contributions' not in canonical_json_bytes(summary).decode()
    if carrier:
        path = next((tmp_path/'shared/shap').rglob('risk-contributions.f64'))
        raw = bytearray(path.read_bytes()); raw[0] ^= 1; path.write_bytes(raw)
        with pytest.raises(ContractError, match='DRIFT'):
            f5.aggregate_final_shap(compact, pooled)
