"""Finite producer provenance and direct-reader wiring; clinical inputs forbidden."""
import os
from pathlib import Path
import sys
import zipfile

import pytest

from padml import f4, f5, runtime
from padml.bundle import ContractError, canonical_json_bytes, sha256_bytes, strict_json_bytes, write_deterministic_zip
from test_full0_entry_points import prepared  # noqa: F401
from test_nested_full_development import (  # noqa: F401
    full_inputs, unfitted_selector_consumers, _physical_full_inputs,
    _selector_shard_engines, _exercise_selector_shards,
)


@pytest.fixture
def retained_source_bundle():
    value = os.environ.get("PADML_RETAINED_FULL0_SOURCE_BUNDLE")
    if value is None:
        pytest.skip("The exact retained code-only source bundle is required for this compatibility fixture")
    path = Path(value)
    assert path.is_absolute() and path.is_file() and not path.is_symlink()
    return path


@pytest.fixture
def retained_gbm_q_bundle():
    value = os.environ.get("PADML_RETAINED_GBM_Q_SOURCE_BUNDLE")
    if value is None:
        pytest.skip("The exact source73 code-only Q producer is required")
    path = Path(value)
    assert path.is_absolute() and path.is_file() and not path.is_symlink()
    return path


@pytest.mark.parametrize("source_env,identity", [
    ("PADML_PRIMARY_60233_SOURCE", "60233a59cede0bac06afb501df28c3a5138787e0dea91ed0c4990772fccd7d18"),
    ("PADML_PRIMARY_9CE61_SOURCE", "9ce61d9f806693255d92f20f264bb96653cf8d147eab7436a3d7f9842deab71a"),
    ("PADML_PRIMARY_EE34_SOURCE", "ee34a857a60674c71da1b29465cb263c58ea1a258189d8e47723baf16f7c7d23"),
])
def test_retained_primary_v33_v23_rsf24_delta_is_exact(
        monkeypatch, source_env, identity):
    value = os.environ.get(source_env)
    if value is None:
        pytest.skip("Requires the exact historical code-only source")
    source = Path(value)
    retained = f4._retained_full0_source_members(source, primary_rsf_inputs=True)
    assert sha256_bytes(canonical_json_bytes(retained)) == identity
    current = f4._f45_source_member_sha256()
    target = Path(f4.__file__).resolve().parent.parent / "padml/f4.py"
    original = target.read_bytes()
    marker = b'rsf24_pair = spec.get("full0_rsf24_numbers_pair")'
    assert original.count(marker) == 1
    changed = original.replace(marker,
        b'rsf24_pair = spec.get("full0_rsf24_unreviewed_pair")', 1)
    read_bytes = Path.read_bytes
    monkeypatch.setattr(Path, "read_bytes",
        lambda path: changed if path == target else read_bytes(path))
    monkeypatch.setattr(f4, "_f45_source_member_sha256",
        lambda: {**current, "padml/f4.py": sha256_bytes(changed)})
    with pytest.raises(ContractError, match="F5_RETAINED_PRIMARY_RSF_INPUT_SOURCE_DRIFT"):
        f4._retained_full0_source_members(source, primary_rsf_inputs=True)


@pytest.mark.parametrize("producer_env,producer_identity", [
    ("PADML_RETAINED_FULL0_SOURCE_BUNDLE", "4339c70013406bdfc10ea7679ac4e8a01054c3ffb01a969c6d427b237614075e"),
    ("PADML_PRIMARY_4A221_SOURCE", "4a221cd0f8519dc9c6685fe0b51b0a6fedfe4d31eaf8ffd6e5bdf616e1d294d0"),
    ("PADML_PRIMARY_EE34_SOURCE", "ee34a857a60674c71da1b29465cb263c58ea1a258189d8e47723baf16f7c7d23"),
])
@pytest.mark.parametrize("module,old,new", [
    (None, None, None),
    pytest.param("padml/f2_kernel.py", b"def _r_prediction_task_batches(", b"def _unreviewed_task_geometry(", id="new-rsf-geometry"),
    pytest.param("padml/f5.py", b"def _validate_complex_search_stage(", b"def _unreviewed_stage_contract(", id="new-stage-validator"),
    pytest.param("padml/f5.py", b"def _run_final_complex_search(", b"def _unreviewed_prefix_entry(", id="new-prefix-entry"),
    pytest.param("padml/f5.py", b"def aggregate_final_shap(", b"def _unreviewed_shap_horizon(", id="full0-shap-horizon"),
    pytest.param("padml/f5_application.py", b"def load_application_models(", b"def _unreviewed_application_models(", id="full0-application-models"),
    ("padml/f2_kernel.py", b"def _run_r_registered_rsf(", b"def _unreviewed_rsf("),
    ("padml/f5.py", b"def _primary_rsf_s3b2_prepared_tasks(", b"def _unreviewed_s3b2("),
    ("padml/f5.py", b"def _a12_q_prepared_predecessors(", b"def _unreviewed_predecessors("),
    ("padml/f5.py", b"def _q_search_task_batch(", b"def _unreviewed_task_batch("),
    ("padml/f4_compact.py", b"def _full_pipeline_q_numbers_index(", b"def _unreviewed_numbers_index("),
    ("padml/f2_kernel.py", b"", b"\n_pool_prediction_batch = None\n"),
    ("padml/f4.py", b"This proof admits numerical consumers only.", b"UNREVIEWED proof body."),
    ("padml/f4.py", b"CURRENT_PRIMARY_PROOF_LINK",
     b'"_retained_full0_source_members": "0000000000000000000000000000000000000000000000000000000000000000"'),
    ("padml/kernels/f5_final_refit.R", b"", b"\n# UNREVIEWED_KERNEL\n"),
])
def test_primary_4339_retained_source_proof_rejects_unreviewed_changes(
        monkeypatch, module, old, new, producer_env, producer_identity):
    """Exact code-only archive; never read a clinical or model member."""
    value = os.environ.get(producer_env)
    if value is None:
        pytest.skip("The exact retained code-only executor source is required")
    retained_source_bundle = Path(value)
    assert retained_source_bundle.is_absolute() and retained_source_bundle.is_file()
    current = f4._f45_source_member_sha256()
    if module is not None:
        target = Path(f4.__file__).resolve().parent.parent / module
        read_bytes = Path.read_bytes
        original = read_bytes(target)
        if old == b"CURRENT_PRIMARY_PROOF_LINK":
            import ast
            lines = original.splitlines(keepends=True)
            node = next(node for node in ast.parse(original).body
                        if isinstance(node, ast.FunctionDef) and node.name == "_retained_full0_source_members")
            digest = sha256_bytes(b"".join(lines[node.lineno - 1:node.end_lineno])).encode()
            old = b'"_retained_full0_source_members": "' + digest + b'"'
        assert not old or original.count(old) == (2 if b'"_retained_full0_source_members":' in old else 1)
        changed = original.replace(old, new, 1) if old else original + new
        monkeypatch.setattr(Path, "read_bytes", lambda path: changed if path == target else read_bytes(path))
        monkeypatch.setattr(f4, "_f45_source_member_sha256", lambda: {**current, module: sha256_bytes(changed)})
        with pytest.raises(ContractError):
            f4._retained_full0_source_members(retained_source_bundle, primary_rsf_inputs=True)
    else:
        retained = f4._retained_full0_source_members(retained_source_bundle, primary_rsf_inputs=True)
        assert sha256_bytes(canonical_json_bytes(retained)) == producer_identity
        assert retained != current and f4._f45_source_member_sha256() == current


@pytest.mark.parametrize("role", ["aar_primary_context", "full0_preparation", "aar_no_aar_selector"])
@pytest.mark.parametrize("damage", [None, "advice", "admission", "kernel"])
def test_primary1513_operational_pair_keeps_original_guards(monkeypatch, role, damage):
    value = os.environ.get("PADML_PRIMARY_1513_SOURCE")
    if value is None:
        pytest.skip("requires the exact retained primary1513 code-only archive")
    source = Path(value).resolve(strict=True)
    source_bytes = source.read_bytes()
    current = f4._f45_source_member_sha256()
    if damage is not None:
        module, old, new = {
            "advice": ("padml/runtime.py", b"RESOURCE_RELEASE_ADVICE_FAILED:", b"UNREVIEWED_ADVICE:"),
            "admission": ("padml/runtime.py", b"def resource_admission(", b"def unreviewed_admission("),
            "kernel": ("padml/kernels/f5_final_refit.R", b"", b"\n# UNREVIEWED_KERNEL\n"),
        }[damage]
        target = Path(f4.__file__).resolve().parent.parent / module
        read_bytes = Path.read_bytes
        original = read_bytes(target)
        assert not old or original.count(old) == 1
        changed = original.replace(old, new, 1) if old else original + new
        monkeypatch.setattr(Path, "read_bytes", lambda path: changed if path == target else read_bytes(path))
        monkeypatch.setattr(f4, "_f45_source_member_sha256", lambda: {**current, module: sha256_bytes(changed)})
        with pytest.raises(ContractError):
            f4._retained_full0_source_members(source, **{role: True})
    else:
        retained = f4._retained_full0_source_members(source, **{role: True})
        assert sha256_bytes(canonical_json_bytes(retained)) == (
            "1513ecba963857099c6b99413b8e976393c551a3ec30ed90da1cb14178338bd7")
        assert retained != current and f4._f45_source_member_sha256() == current
    assert source.read_bytes() == source_bytes


def test_retained_gbm_q_proof_keeps_q_primary_and_executor_separate(
        retained_gbm_q_bundle, retained_source_bundle, monkeypatch):
    current = f4._f45_source_member_sha256()
    retained = f4._retained_gbm_q_source_members(retained_gbm_q_bundle, retained_source_bundle)
    assert sha256_bytes(canonical_json_bytes(retained)) == (
        "73c9698680d7e1d054d26a1bf569855d6aac443e8750945736c67d9d09567c47")
    assert retained != current and f4._f45_source_member_sha256() == current
    with pytest.raises(ContractError):
        f4._retained_gbm_q_source_members(retained_source_bundle, retained_gbm_q_bundle)
    with pytest.raises(ContractError):
        f4._retained_gbm_q_source_members(retained_gbm_q_bundle, retained_gbm_q_bundle)
    read_bytes = Path.read_bytes
    for member, suffix in (
            ("f2_kernel.py", b"\n_cox_breslow_log_likelihood = None\n"),
            ("f4.py", b"\nclass _run_full_pipeline_r_search_batch: pass\n"),
            ("runtime.py", b"\nresource_admission = None\n"),
            ("f5.py", b"\n_q_search_units = None\n"),
            ("f5_sensitivity.py", b"\n_validate_a12_search_source = None\n")):
        path = Path(f4.__file__).parent / member
        original = read_bytes(path)
        changed = original + suffix
        with monkeypatch.context() as patch:
            patch.setattr(Path, "read_bytes", lambda value: changed if value == path else read_bytes(value))
            patch.setattr(f4, "_f45_source_member_sha256",
                lambda: {**current, "padml/" + member: sha256_bytes(changed)})
            with pytest.raises(ContractError):
                f4._retained_gbm_q_source_members(retained_gbm_q_bundle, retained_source_bundle)
        assert read_bytes(path) == original


@pytest.mark.parametrize("damage", [False, True, "gbm-source-helper"])
def test_retained_b1a_completion_keeps_summary_reuse_accounting(monkeypatch, damage):
    value = os.environ.get("PADML_PRIMARY_B1A_SOURCE")
    if value is None:
        pytest.skip("Exact code-only b1a executor is required")
    source = Path(value)
    if damage:
        target = Path(f5.__file__).resolve()
        read_bytes = Path.read_bytes
        original = read_bytes(target)
        before = (b"def _q_gbm_source_evidence(" if damage == "gbm-source-helper"
                  else b"def _q_search_batch_completion(")
        assert original.count(before) == 1
        changed = original.replace(before, b"def _unreviewed_completion_accounting(", 1)
        current = f4._f45_source_member_sha256()
        monkeypatch.setattr(Path, "read_bytes", lambda path: changed if path == target else read_bytes(path))
        monkeypatch.setattr(f4, "_f45_source_member_sha256",
                            lambda: {**current, "padml/f5.py": sha256_bytes(changed)})
        with pytest.raises(ContractError):
            f4._retained_full0_source_members(source, primary_rsf_inputs=True)
    else:
        retained = f4._retained_full0_source_members(source, primary_rsf_inputs=True)
        assert sha256_bytes(canonical_json_bytes(retained)) == (
            "b1a67ebc30a563ba798096016e5f735f792b7bfc32150e04f75124eb6eccd836")


@pytest.mark.parametrize("member", [None, "padml/f4.py", "padml/f5.py", "padml/kernels/f5_final_refit.R", "gbm-source-helper"])
def test_retained_6335_compiler_preserves_publication_scope(monkeypatch, member):
    value = os.environ.get("PADML_PRIMARY_6335_SOURCE")
    if value is None:
        pytest.skip("Exact code-only preparation compiler is required")
    source = Path(value)
    current = f4._f45_source_member_sha256()
    if member is not None:
        helper_damage = member == "gbm-source-helper"
        if helper_damage:
            member = "padml/f5.py"
        target = Path(f4.__file__).resolve().parent.parent / member
        read_bytes = Path.read_bytes
        original = read_bytes(target)
        changed = (original.replace(b"def _q_gbm_source_evidence(", b"def _unreviewed_gbm_source(", 1)
                   if helper_damage else original + b"\nUNREVIEWED_PUBLICATION_BINDING = 1\n")
        assert changed != original
        monkeypatch.setattr(Path, "read_bytes", lambda path: changed if path == target else read_bytes(path))
        monkeypatch.setattr(f4, "_f45_source_member_sha256",
                            lambda: {**current, member: sha256_bytes(changed)})
        with pytest.raises(ContractError):
            f4._retained_full0_source_members(source, primary_rsf_inputs=True)
        return
    retained = f4._retained_full0_source_members(source, primary_rsf_inputs=True)
    assert sha256_bytes(canonical_json_bytes(retained)) == (
        "6335b6b30c33ce07a474a20a7426c7e6564feaf7322aa126ad0c3a9a3dd7530e")
    assert retained != current
    for options in ({}, {"aar_no_aar_selector": True}, {"full0_preparation": True}):
        with pytest.raises(ContractError):
            f4._retained_full0_source_members(source, **options)


@pytest.mark.parametrize("member", [None, "padml/f4.py", "padml/f5.py", "padml/runtime.py"])
def test_retained_9ba_primary_producer_reaches_current_publication_consumer(monkeypatch, member):
    value = os.environ.get("PADML_PRIMARY_9BA_SOURCE")
    if value is None:
        pytest.skip("Exact outer6 primary preparation producer is required")
    source = Path(value)
    current = f4._f45_source_member_sha256()
    if member is not None:
        target = Path(f4.__file__).resolve().parent.parent / member
        read_bytes = Path.read_bytes
        changed = read_bytes(target) + b"\nUNREVIEWED_PRIMARY_PUBLICATION_BINDING = 1\n"
        monkeypatch.setattr(Path, "read_bytes", lambda path: changed if path == target else read_bytes(path))
        monkeypatch.setattr(f4, "_f45_source_member_sha256",
                            lambda: {**current, member: sha256_bytes(changed)})
        with pytest.raises(ContractError, match="F5_RETAINED_PRIMARY_RSF_INPUT_SOURCE_DRIFT"):
            f4._retained_full0_source_members(source, primary_rsf_inputs=True)
        return
    retained = f4._retained_full0_source_members(source, primary_rsf_inputs=True)
    assert sha256_bytes(canonical_json_bytes(retained)) == (
        "9ba06335ad25014a4a738e4f24fcff6643f21b1f97a470b53662303a628ce039")
    assert retained != current and f4._f45_source_member_sha256() == current


@pytest.mark.parametrize("member", [None, "padml/f4.py", "padml/f5.py", "padml/runtime.py"])
def test_retained_07add_fine_executor_reaches_current_outer4_consumer(monkeypatch, member):
    value = os.environ.get("PADML_PRIMARY_RSF_COMPLETED_EXECUTOR_SOURCE")
    if value is None:
        pytest.skip("Exact completed outer4 fine executor is required")
    source = Path(value)
    current = f4._f45_source_member_sha256()
    if member is not None:
        target = Path(f4.__file__).resolve().parent.parent / member
        read_bytes = Path.read_bytes
        changed = read_bytes(target) + b"\nUNREVIEWED_OUTER4_CONSUMER_BINDING = 1\n"
        monkeypatch.setattr(Path, "read_bytes", lambda path: changed if path == target else read_bytes(path))
        monkeypatch.setattr(f4, "_f45_source_member_sha256",
                            lambda: {**current, member: sha256_bytes(changed)})
        with pytest.raises(ContractError, match="F5_RETAINED_AAR_SELECTOR_DEPENDENCY_DRIFT"):
            f4._retained_full0_source_members(source, aar_no_aar_selector=True)
        return
    retained = f4._retained_full0_source_members(source, aar_no_aar_selector=True)
    assert sha256_bytes(canonical_json_bytes(retained)) == (
        "07addcbb504f98caed9be64f2f598454bf6eb1df43bd6494e4d143151eb6e9bc")
    assert retained != current and f4._f45_source_member_sha256() == current


@pytest.mark.parametrize("member", [None, "padml/f2_kernel.py", "padml/f4.py", "padml/f5.py", "padml/runtime.py"])
def test_retained_5c303_full0_gbm_partial_recovery_scope(monkeypatch, member):
    value = os.environ.get("PADML_FULL0_GBM_5C303_SOURCE")
    if value is None:
        pytest.skip("Exact failed full0 GBM producer source is required")
    source = Path(value)
    current = f4._f45_source_member_sha256()
    if member is not None:
        target = Path(f4.__file__).resolve().parent.parent / member
        read_bytes = Path.read_bytes
        changed = read_bytes(target) + b"\nUNREVIEWED_GBM_PARTIAL_RECOVERY_BINDING = 1\n"
        monkeypatch.setattr(Path, "read_bytes", lambda path: changed if path == target else read_bytes(path))
        monkeypatch.setattr(f4, "_f45_source_member_sha256",
                            lambda: {**current, member: sha256_bytes(changed)})
        with pytest.raises(ContractError, match="F5_FULL0_GBM_PARTIAL_RECOVERY_SOURCE_DRIFT"):
            f4._retained_full0_source_members(source, full0_gbm_partial_recovery=True)
        return
    retained = f4._retained_full0_source_members(source, full0_gbm_partial_recovery=True)
    assert sha256_bytes(canonical_json_bytes(retained)) == (
        "5c30305f8279acc7407bffc1b9d2d09cb1d100f819f69d4e7486c131c8bee5df")
    for options in ({}, {"primary_rsf_inputs": True}, {"full0_preparation": True}):
        with pytest.raises(ContractError):
            f4._retained_full0_source_members(source, **options)


def test_original_source_loader_rejects_unknown_producer(tmp_path):
    path = tmp_path / "current.zip"
    f4.compile_f45_source_bundle(path)
    with pytest.raises(ContractError, match="F5_RETAINED_FULL0_SOURCE_INCOMPATIBLE"):
        f4._retained_full0_source_members(path)


@pytest.mark.parametrize("scope,member", [
    ("primary", "padml/f5_application.py"),
    ("gbm", "padml/f5.py"), ("gbm", "padml/f5_application.py"),
    ("aar-python", "padml/f5.py"), ("aar-python", "padml/f5_application.py"),
])
def test_full0_application_compatibility_keeps_exact_module_pins(
        retained_source_bundle, retained_gbm_q_bundle, monkeypatch, scope, member):
    """Code-only producers; compatibility must not discard module bindings."""
    if scope == "aar-python":
        value = os.environ.get("PADML_OUTER6_TEST_F50")
        if value is None:
            pytest.skip("Exact code-only f50 source is required")
        consume = lambda: f4._retained_full0_source_members(Path(value), aar_python_q=True)
    elif scope == "gbm":
        consume = lambda: f4._retained_gbm_q_source_members(
            retained_gbm_q_bundle, retained_source_bundle)
    else:
        consume = lambda: f4._retained_full0_source_members(
            retained_source_bundle, aar_primary_context=True)
    assert len(consume()) == 49
    current = f4._f45_source_member_sha256()
    target = Path(f4.__file__).resolve().parent.parent / member
    read_bytes = Path.read_bytes
    changed = read_bytes(target) + b"\nload_application_models = None\n"
    monkeypatch.setattr(Path, "read_bytes", lambda path: changed if path == target else read_bytes(path))
    monkeypatch.setattr(f4, "_f45_source_member_sha256",
                        lambda: {**current, member: sha256_bytes(changed)})
    with pytest.raises(ContractError):
        consume()


@pytest.mark.parametrize("scope", ["outer_fixed12_rescore", "full0_preparation"])
def test_primary_continuation_projection_recovers_exact_old_f2(retained_source_bundle, monkeypatch, scope):
    """Only the F2 projection boundary; downstream source proofs stay separate."""
    original = f4._gbm_complete_loss_source_projection
    calls = []
    class ProjectionReached(Exception):
        pass
    def consume(source, **kwargs):
        assert kwargs == {"primary_continuation": True}
        result = original(source, **kwargs)
        assert sha256_bytes(result) == "a1eb8cd942cf5dfd799371e23fc0fd4480b22db1ea091c26681af62a42f202a6"
        for changed in (source + b"\n_pool_prediction_batch = None\n",
                        source.replace(b"def _run_r_registered_rsf(", b"def _changed_rsf(", 1),
                        source.replace(b'"native_audit_evidence_root" in spec',
                                       b'"changed_native_audit_evidence_root" in spec', 1)):
            with pytest.raises(ContractError, match="F5_RETAINED_PRIMARY_CONTINUATION_PROJECTION_DRIFT"):
                original(changed, **kwargs)
        calls.append(True)
        raise ProjectionReached
    monkeypatch.setattr(f4, "_gbm_complete_loss_source_projection", consume)
    with pytest.raises(ProjectionReached):
        f4._retained_full0_source_members(retained_source_bundle, **{scope: True})
    assert calls == [True]


@pytest.mark.parametrize("member,symbol", [
    ("padml/f4.py", "_materialize_o_fit_input_bundle"),
    ("padml/f4.py", "_load_o_fit_execution_archive"),
    ("padml/f4.py", "main"),
    ("padml/f2_kernel.py", "_cox_breslow_log_likelihood"),
])
def test_fixed12_actual_source_rejects_changed_consumer(
        retained_source_bundle, monkeypatch, member, symbol):
    retained = f4._retained_full0_source_members(retained_source_bundle, outer_fixed12_rescore=True)
    assert sha256_bytes(canonical_json_bytes(retained)) == (
        "1513ecba963857099c6b99413b8e976393c551a3ec30ed90da1cb14178338bd7")
    current = f4._f45_source_member_sha256()
    target = Path(f4.__file__).resolve().parent.parent / member
    read_bytes = Path.read_bytes
    original = read_bytes(target)
    marker = ("def " + symbol + "(").encode()
    assert original.count(marker) == 1
    changed = original.replace(marker, ("def " + symbol + "_damaged(").encode(), 1)
    monkeypatch.setattr(Path, "read_bytes", lambda path: changed if path == target else read_bytes(path))
    monkeypatch.setattr(f4, "_f45_source_member_sha256",
                        lambda: {**current, member: sha256_bytes(changed)})
    with pytest.raises(ContractError):
        f4._retained_full0_source_members(retained_source_bundle, outer_fixed12_rescore=True)


def test_standard_s3a_owner_adapter_restores_exact_v23_bytes():
    """Code-only delta proof, not acceptance of a historical result."""
    import ast
    source = (Path(f4.__file__).resolve().parent / "f2_kernel.py").read_bytes()
    lines = source.splitlines(keepends=True)
    node = next(node for node in ast.parse(source).body
                if isinstance(node, ast.FunctionDef) and node.name == "_run_r_registered_rsf")
    fragment = b"".join(lines[node.lineno - 1:node.end_lineno])
    assert sha256_bytes(fragment) == "829c56e69d7f573564aa44b5541c886e518f27d964c03589a22a3393f9b80528"
    current = (
        b'            control["primary_rsf_s3b1_evidence"]["primary-s3b1/report.json"].read_bytes()\n'
        b'        )\n'
        b'        retained_primary_s3a = retained_primary_s3a.get("original_q_boundary", retained_primary_s3a)\n')
    previous = (
        b'            control["primary_rsf_s3b1_evidence"]["primary-s3b1/report.json"].read_bytes()\n'
        b'        )["original_q_boundary"]\n')
    assert fragment.count(current) == 1
    restored = fragment.replace(current, previous, 1)
    assert sha256_bytes(restored) == "7a42f4cf1b6a938c85f106fa0e4b6ce53bef9f926c34dd68b6d9035fda7b4f3d"
    assert sha256_bytes(source.replace(fragment, restored, 1)) == (
        "84625435b714b7c3d5eaccf768c7ec13b1191c3989eb6fce3a05415096ad62eb")


@pytest.mark.parametrize("member,symbol", [
    ("padml/f4.py", "main"),
    ("padml/f5.py", "main"),
    ("padml/f5.py", "execute_final_complex_search"),
    ("padml/f5.py", "_consume_q_search_batches"),
    ("padml/f5.py", "_q_search_task_batch"),
    ("padml/f5.py", "_primary_rsf_prepared_input"),
    ("padml/f5.py", "_primary_rsf_s3b2_prepared_tasks"),
    ("padml/f5.py", "_execute_a12_prepared_q_batch"),
    ("padml/f2_kernel.py", "_run_r_registered_rsf"),
])
def test_standard_s3b1_source_rejects_changed_adapter(
        retained_source_bundle, monkeypatch, member, symbol):
    retained = f4._retained_full0_source_members(retained_source_bundle, primary_rsf_inputs=True)
    assert sha256_bytes(canonical_json_bytes(retained)) in {
        "ee34a857a60674c71da1b29465cb263c58ea1a258189d8e47723baf16f7c7d23",
        "9ce61d9f806693255d92f20f264bb96653cf8d147eab7436a3d7f9842deab71a"}
    current = f4._f45_source_member_sha256()
    target = Path(f4.__file__).resolve().parent.parent / member
    read_bytes = Path.read_bytes
    original = read_bytes(target)
    marker = ("def " + symbol + "(").encode()
    assert original.count(marker) == 1
    changed = original.replace(marker, ("def " + symbol + "_damaged(").encode(), 1)
    monkeypatch.setattr(Path, "read_bytes", lambda path: changed if path == target else read_bytes(path))
    monkeypatch.setattr(f4, "_f45_source_member_sha256",
                        lambda: {**current, member: sha256_bytes(changed)})
    with pytest.raises(ContractError, match="F5_RETAINED_PRIMARY_RSF_INPUT_SOURCE_DRIFT"):
        f4._retained_full0_source_members(retained_source_bundle, primary_rsf_inputs=True)


def test_full0_preparation_keeps_exact_v23_producer_role(retained_source_bundle):
    manifest = f4.load_f45_source_bundle(retained_source_bundle)
    identity = sha256_bytes(canonical_json_bytes({row["path"]: row["sha256"] for row in manifest["members"]}))
    if identity == "9ce61d9f806693255d92f20f264bb96653cf8d147eab7436a3d7f9842deab71a":
        retained = f4._retained_full0_source_members(retained_source_bundle, full0_preparation=True)
        assert sha256_bytes(canonical_json_bytes(retained)) == identity
        with pytest.raises(ContractError):
            f4._retained_full0_source_members(retained_source_bundle, full0_gbm_partial_recovery=True)
    elif identity == "ee34a857a60674c71da1b29465cb263c58ea1a258189d8e47723baf16f7c7d23":
        with pytest.raises(ContractError):
            f4._retained_full0_source_members(retained_source_bundle, full0_preparation=True)
    else:
        pytest.skip("Requires the actual v23 or ee34 code-only archive")


@pytest.mark.parametrize("scope", [
    "aar_mice_gather", "aar_no_aar_selector", "full0_preparation",
    "aar_primary_context", "full0_rsf_q",
])
def test_gbm_loss_hooks_preserve_exact_old_dependency_proofs(retained_source_bundle, scope, monkeypatch):
    current = f4._f45_source_member_sha256()
    projection = f4._gbm_complete_loss_source_projection
    projected = []
    def observe(source, **kwargs):
        value = projection(source, **kwargs)
        projected.append(sha256_bytes(value))
        return value
    monkeypatch.setattr(f4, "_gbm_complete_loss_source_projection", observe)
    retained = f4._retained_full0_source_members(retained_source_bundle, **{scope: True})
    assert sha256_bytes(canonical_json_bytes(retained)) == (
        "1513ecba963857099c6b99413b8e976393c551a3ec30ed90da1cb14178338bd7")
    # Observe the original consumer after its outer4/PRIMARY projections,
    # not the unrelated raw-module input expected by an older test snapshot.
    assert projected == ["a1eb8cd942cf5dfd799371e23fc0fd4480b22db1ea091c26681af62a42f202a6"]
    assert f4._f45_source_member_sha256() == current and retained != current


@pytest.mark.parametrize("source_env,identity", [
    ("PADML_FULL0_RSF_8CCE_SOURCE", "8cce1d0042a87e627324246016a64224db3b23ae818e62eb09840b9d7156eaa1"),
    ("PADML_FULL0_RSF_79FE_SOURCE", "79fe72c928ca97e77def2c56868c1e9d7d8fd55da9fe0215073bed7c5dbcd8f2"),
])
@pytest.mark.parametrize("damage", [None, "owner", "class", "module", "kernel", "old-bytes"])
def test_actual_full0_rsf_source_routes_keep_exact_proof(
        source_env, identity, damage, tmp_path, monkeypatch):
    value = os.environ.get(source_env)
    if value is None:
        pytest.skip("exact retained code-only RSF source is required")
    source = Path(value).resolve(strict=True)
    original_source = source.read_bytes()
    current = f4._f45_source_member_sha256()
    if damage == "old-bytes":
        with zipfile.ZipFile(source) as archive:
            entries = {name: archive.read(name) for name in archive.namelist()}
        entries["padml/f2_kernel.py"] += b"\n# UNREVIEWED_OLD_SOURCE\n"
        source = tmp_path / "changed-old-source.zip"
        write_deterministic_zip(source, entries)
    elif damage is not None:
        member, before, after = {
            "owner": ("padml/f4.py", b"def execute_o_fit_bundle(", b"def unreviewed_owner("),
            "class": ("padml/f5.py", b"class _FullScoreArchiveOutputs", b"class _UnreviewedScoreArchiveOutputs"),
            "module": ("padml/f5.py", b"", b"\n_FullScoreArchiveOutputs = None\n"),
            "kernel": ("padml/f2_kernel.py", b"", b"\n_cox_breslow_log_likelihood = None\n"),
        }[damage]
        target = Path(f4.__file__).resolve().parent.parent / member
        read_bytes = Path.read_bytes
        original = read_bytes(target)
        assert not before or original.count(before) == 1
        changed = original.replace(before, after, 1) if before else original + after
        monkeypatch.setattr(Path, "read_bytes", lambda path: changed if path == target else read_bytes(path))
        monkeypatch.setattr(f4, "_f45_source_member_sha256", lambda: {**current, member: sha256_bytes(changed)})
    if damage is None:
        retained = f4._retained_full0_source_members(source, full0_rsf_q=True)
        assert sha256_bytes(canonical_json_bytes(retained)) == identity
        assert retained != current and f4._f45_source_member_sha256() == current
    else:
        with pytest.raises(ContractError):
            f4._retained_full0_source_members(source, full0_rsf_q=True)
    assert Path(value).read_bytes() == original_source


def test_gbm_source_projection_cannot_hide_hook_or_scientific_drift(
        retained_source_bundle, monkeypatch):
    path = Path(f4.__file__).parent / "f2_kernel.py"
    original = path.read_bytes()
    # The hook's scope is byte-proved, not an arbitrary discarded branch.
    before = b'and evaluation_mode == "GROUPED_COX_LOCK"\n'
    assert original.count(before) == 1
    # The retained-prefix pin is checked before the later GBM projection;
    # either strict boundary is a required rejection, never a projection pass.
    with pytest.raises(ContractError, match="F5_(FULL0_RSF_RETAINED_PREFIX_SOURCE|RETAINED_GBM_LOSS_DEPENDENCY)_DRIFT"):
        f4._gbm_complete_loss_source_projection(original.replace(before, b'and True\n', 1))
    with pytest.raises(ContractError, match="F5_(FULL0_RSF_RETAINED_PREFIX_SOURCE|RETAINED_GBM_LOSS_DEPENDENCY)_DRIFT"):
        f4._gbm_complete_loss_source_projection(original + original)
    read_bytes = Path.read_bytes
    current = f4._f45_source_member_sha256()
    # Bind altered bytes to their real digest: a self-consistent source hash
    # cannot excuse a changed Cox evaluator or module-scope rebinding.
    for suffix in (b'\n_cox_breslow_log_likelihood = None\n',
                   b'\n# not the finite reviewed F2 pair\n'):
        changed = original + suffix
        with monkeypatch.context() as patch:
            patch.setattr(Path, "read_bytes", lambda value: changed if value == path else read_bytes(value))
            patch.setattr(f4, "_f45_source_member_sha256",
                lambda: {**current, "padml/f2_kernel.py": sha256_bytes(changed)})
            with pytest.raises(ContractError, match="F5_(RETAINED_FULL0_RSF_Q_DEPENDENCY|RETAINED_PRIMARY_CONTINUATION_PROJECTION)_DRIFT"):
                f4._retained_full0_source_members(retained_source_bundle, full0_rsf_q=True)
    assert path.read_bytes() == original and f4._f45_source_member_sha256() == current


def test_retained_source_is_provenance_not_an_executing_identity(retained_source_bundle, monkeypatch, tmp_path):
    current = f4._f45_source_member_sha256()
    with pytest.raises(ContractError, match="F5_RETAINED_FULL0_SOURCE_INCOMPATIBLE"):
        f4._retained_full0_source_members(retained_source_bundle)
    retained = f4._retained_full0_source_members(retained_source_bundle, aar_primary_context=True)
    assert current == f4._f45_source_member_sha256() and retained != current
    assert {name for name in current if current[name] != retained[name]} == {
        "NESTED_LOCO_PROTOCOL.md", "padml/f2_kernel.py", "padml/f4.py", "padml/f4_compact.py",
        "padml/f5.py", "padml/f5_application.py", "padml/f5_sensitivity.py", "padml/kernels/f4_gbm_stop.R",
        "padml/kernels/f4_metrics.R", "padml/kernels/f5_final_refit.R", "padml/nested_loco.py",
        "padml/runtime.py"}
    drifted = {**current, "padml/kernels/f4_gbm_stop.R": "0" * 64}
    monkeypatch.setattr(f4, "_f45_source_member_sha256", lambda: drifted)
    with pytest.raises(ContractError, match="F5_RETAINED_FULL0_SOURCE_INCOMPATIBLE"):
        f4._retained_full0_source_members(retained_source_bundle, aar_primary_context=True)
    for name in ("padml/runtime.py", "NESTED_LOCO_PROTOCOL.md"):
        monkeypatch.setattr(f4, "_f45_source_member_sha256", lambda name=name: {**current, name: "f" * 64})
        with pytest.raises(ContractError, match="F5_RETAINED_FULL0_SOURCE_INCOMPATIBLE"):
            f4._retained_full0_source_members(retained_source_bundle, aar_primary_context=True)
    monkeypatch.setattr(f4, "_f45_source_member_sha256", lambda: current)
    with zipfile.ZipFile(retained_source_bundle) as archive:
        entries = {name: archive.read(name) for name in archive.namelist()}
    entries["padml/f5.py"] += b"\n# tampered\n"
    tampered = tmp_path / "tampered.zip"
    write_deterministic_zip(tampered, entries)
    with pytest.raises(ContractError, match="F45_SOURCE_BUNDLE_INVALID"):
        f4._retained_full0_source_members(tampered)


def test_full0_raw_retained_binding_remains_explicit_and_all_data_checks_live(prepared, retained_source_bundle):
    root, _, _, _ = prepared
    sources = strict_json_bytes((root / "full-development.json").read_bytes())
    expected = f5._full_development_raw_inputs(sources)
    sources["raw_input_binding"]["f45_source_sha256"] = sha256_bytes(canonical_json_bytes(
        f4._retained_full0_source_members(retained_source_bundle, full0_preparation=True)))
    with pytest.raises(ContractError, match="F5_FULL_DEVELOPMENT_RAW_INPUT_DRIFT"):
        f5._full_development_raw_inputs(sources)
    assert f5._full_development_raw_inputs(sources, retained_full0_source_bundle=retained_source_bundle) == expected
    binding = dict(sources["raw_input_binding"])
    for name in binding:
        sources["raw_input_binding"] = {**binding, name: "0" * 64}
        with pytest.raises(ContractError, match="F5_FULL_DEVELOPMENT_RAW_INPUT_DRIFT"):
            f5._full_development_raw_inputs(sources, retained_full0_source_bundle=retained_source_bundle)


def test_twelve_month_lineage_reuses_pinned_raw_plan_without_rng_or_q(
        prepared, retained_source_bundle, monkeypatch):
    from padml import nested_loco as nested
    from padml.bundle import sha256_file

    root, covariates, response, _ = prepared
    original = (root / "full-development.json").read_bytes()
    legacy = strict_json_bytes(original)
    # A separate synthetic legacy binding, never a relabelled formal result.
    legacy["raw_input_binding"]["f45_source_sha256"] = sha256_bytes(canonical_json_bytes(
        f4._retained_full0_source_members(retained_source_bundle, full0_preparation=True)))
    legacy_path = root / "synthetic-legacy-lineage.json"
    legacy_path.write_bytes(canonical_json_bytes(legacy))
    legacy_sha = sha256_file(legacy_path)
    decision = nested._sealed({**{key: value for key, value in legacy["science_decision"].items()
                                  if key != "identity_sha256"},
                               "twelve_month_development": nested._twelve_month_development_contract()})
    def forbidden(*args, **kwargs):
        pytest.fail("Lineage preparation must not run RNG, MICE, selector or Q")
    for name in ("compile_full_data_mice_plan", "_materialized_full_data_development_sources",
                 "_nested_full_selector_program", "_final_complex_search_program"):
        monkeypatch.setattr(f5, name, forbidden)
    target = root.parent / "twelve-prepared"
    result = f5.compile_full_data_development_inputs(covariates, response, target,
        f1_runtime_root=root.parent / "f1", science_decision=decision, resource_policy=legacy["resource_policy"],
        retained_bytes_per_view=1000, retained_bytes_per_component=1000,
        expanded_bytes_per_component=1000, shared_storage_bytes=1000, rscript="UNFITTED",
        selection_horizon_months=12, retained_full_development_path=legacy_path,
        retained_full_development_sha256=legacy_sha, retained_full0_source_bundle=retained_source_bundle)
    actual = f5._read_final_lineage(target / "full-development.json", bounded=True, selection_horizon_months=12)
    assert actual["science_decision"] == decision and actual["selection_horizon_months"] == 12
    names = ("plan", "raw_input_binding", "covariates_path", "source_response_path", "response_path",
             "f1_manifest_path", "f1_binding_path", "mice_root", "final_mice_path", "selector_root")
    assert {name: actual[name] for name in names} == {name: legacy[name] for name in names}
    assert actual["score_root"] == str(target / "score")
    assert actual["search_roots"] == {family: str(target / "search" / family)
                                      for family in legacy["search_roots"]}
    assert f5._full_development_raw_inputs(actual, retained_full0_source_bundle=retained_source_bundle) == (
        f5._full_development_raw_inputs(legacy, retained_full0_source_bundle=retained_source_bundle))
    assert (target / "plan.json").read_bytes() == canonical_json_bytes(legacy["plan"])
    assert (root / "full-development.json").read_bytes() == original and sha256_file(legacy_path) == legacy_sha
    assert {path.name for path in target.iterdir()} == {"plan.json", "full-development.json", "preparation-execution.json", "search"}
    assert not list((target / "search").iterdir())
    assert result["status"] == "COMPILED_NOT_EXECUTED" and result["stage_acceptance"] is False
    assert result["planned_mice_chains"] == result["mice_chain_count"] == result["model_fit_count"] == 0
    reused = result["retained_preparation"]
    assert reused["new_split_rng_calls"] == 0 and reused["referenced_plan_mice_chains"] == 1220
    assert reused["mice_or_selector_completion_claimed"] is False
    assert reused["full_development_sha256"] == legacy_sha
    assert reused["compiler_source_identity"] == sha256_bytes(canonical_json_bytes(f4._f45_source_member_sha256()))
    assert reused["raw_producer_source_identity"] != reused["compiler_source_identity"]
    assert strict_json_bytes((target / "preparation-execution.json").read_bytes())["retained_preparation"] == reused
    with pytest.raises(ContractError, match="F5_FINAL_LINEAGE_SELECTION_HORIZON_MISMATCH"):
        f5._read_final_lineage(target / "full-development.json")
    with pytest.raises(ContractError, match="F5_FULL_DEVELOPMENT_RAW_INPUT_DRIFT"):
        f5._full_development_raw_inputs(actual)


def test_twelve_month_materializer_keeps_physical_checks_without_new_rng(
        prepared, retained_source_bundle, monkeypatch):
    """Real 31-view materialization; synthetic MICE leaves are prepared once."""
    import copy
    from padml import nested_loco as nested
    from padml.bundle import sha256_file
    from test_full0_entry_points import unfitted_full0_mice_run

    root, covariates_path, response_path, _ = prepared
    source = root / "full-development.json"
    sources = strict_json_bytes(source.read_bytes())
    plan = sources["plan"]
    covariates, response, _ = f5._full_development_raw_inputs(sources)
    fields, responses = f5._response_rows(response)
    inner_ids = {pair["split_id"] for pair in plan["split_pairs"]}
    tasks = [task for task in f5.compile_full_data_search_mice_tasks(plan) if task["split_id"] in inner_ids]
    tasks.append(f5.compile_final_full_data_mice_task(plan))
    calls = []
    def unfitted(arguments, **kwargs):
        calls.append("REPLAY" if "REPLAY" in arguments else "FIT")
        return unfitted_full0_mice_run(arguments, **kwargs)
    with monkeypatch.context() as setup:
        setup.setattr(f5.subprocess, "run", unfitted)
        for task in tasks:
            _, fit_ids, _ = f5._mice_view_rows(plan, task)
            path = (root / "final-mice.zip" if task["phase"] == "FINAL_MICE" else
                    root / "mice" / task["split_id"] / (task["role"].lower() + ".zip"))
            path.parent.mkdir(parents=True, exist_ok=True)
            f5.execute_full_data_search_mice_view(plan, task, covariates,
                f5._write_response_subset(fields, responses, fit_ids, None)["private_bytes"]
                if task["role"] == "ANALYSIS" else None, path, rscript="UNFITTED")
    assert len(tasks) == 31 and calls == ["FIT", "REPLAY"] * 31
    legacy = copy.deepcopy(sources)
    legacy["raw_input_binding"]["f45_source_sha256"] = sha256_bytes(canonical_json_bytes(
        f4._retained_full0_source_members(retained_source_bundle, full0_preparation=True)))
    legacy_path = root / "synthetic-legacy-lineage.json"
    legacy_path.write_bytes(canonical_json_bytes(legacy))
    decision = nested._sealed({**{key: value for key, value in legacy["science_decision"].items()
                                  if key != "identity_sha256"},
                               "twelve_month_development": nested._twelve_month_development_contract()})
    target = root.parent / "twelve-materializer"
    before = {str(path): sha256_file(path) for path in root.rglob("*.zip")}
    def forbidden(*args, **kwargs):
        pytest.fail("No new FIT/REPLAY/MICE/path/split-RNG in retained 12-month materialization")
    with monkeypatch.context() as consume:
        for name in ("compile_full_data_mice_plan", "full_data_splits", "_replay_mice_native_view",
                     "execute_full_data_search_mice_view", "_nested_full_selector_program", "_final_complex_search_program"):
            consume.setattr(f5, name, forbidden)
        consume.setattr(f5.subprocess, "run", forbidden)
        f5.compile_full_data_development_inputs(covariates_path, response_path, target,
            f1_runtime_root=root.parent / "f1", science_decision=decision, resource_policy=legacy["resource_policy"],
            retained_bytes_per_view=1000, retained_bytes_per_component=1000,
            expanded_bytes_per_component=1000, shared_storage_bytes=1000, rscript="UNFITTED",
            selection_horizon_months=12, retained_full_development_path=legacy_path,
            retained_full_development_sha256=sha256_file(legacy_path), retained_full0_source_bundle=retained_source_bundle)
        options = {"selector_only": True, "selection_horizon_months": 12,
                   "retained_full0_source_bundle": retained_source_bundle, "retained_mice_plan": legacy["plan"]}
        def open_views(**kwargs):
            return f5._materialized_full_data_development_sources(target / "full-development.json", target, **kwargs)
        with open_views(**options) as (actual, partitions, full):
            assert actual["plan"] == plan and actual["selection_horizon_months"] == 12
            assert len(partitions) == 15 and all(part["stopping"] is None for part in partitions)
            assert full["development_input"]["mice_plan_sha256"] == sha256_bytes(canonical_json_bytes(plan))
            assert len(full["fit_covariate_members"]) == 20
        assert not list(target.glob("f5-full-development-inputs-*"))
        for bad in (None, {**plan, "resampling_input_sha256": "0" * 64}):
            with pytest.raises(ContractError, match="F5_FULL0_RETAINED_MICE_PLAN_INVALID"):
                with open_views(**{**options, "retained_mice_plan": bad}):
                    pytest.fail("Unpinned plan reached materialization")
        # Alter one physical view without changing the independently retained
        # plan/raw source. Its original row check must still reject it.
        members = f5._final_search_mice_members(plan, root / "mice", include_stop=False)
        changed = members[plan["split_pairs"][1]["split_id"] + "/application.zip"]
        original = changed.read_bytes()
        with zipfile.ZipFile(changed) as archive:
            entries = {name: archive.read(name) for name in archive.namelist()}
        rows = entries["inputs/covariates.csv"].decode().splitlines()
        cells = rows[1].split(",")
        cells[rows[0].split(",").index("Age")] = "999"
        rows[1] = ",".join(cells)
        entries["inputs/covariates.csv"] = ("\n".join(rows) + "\n").encode()
        tampered = target / "synthetic-tampered-application.zip"
        write_deterministic_zip(tampered, entries)
        try:
            changed.write_bytes(tampered.read_bytes())
            with pytest.raises(ContractError, match="F5_Q_MIXED_RAW_COVARIATE_SOURCE"):
                with open_views(**options):
                    pytest.fail("Changed raw view reached materialization")
        finally:
            changed.write_bytes(original)
    assert {str(path): sha256_file(path) for path in root.rglob("*.zip")} == before
    assert calls == ["FIT", "REPLAY"] * 31
    # The unmodified default 24-month validator still invokes its registered
    # split compiler (the existing fixture provides hand-written splits).
    split_calls = []
    original_compile = f5.compile_full_data_mice_plan
    def compile_spy(*args, **kwargs):
        split_calls.append(True)
        return original_compile(*args, **kwargs)
    monkeypatch.setattr(f5, "compile_full_data_mice_plan", compile_spy)
    f5._validate_final_search_plan(plan, members, response, include_stop=False)
    assert split_calls == [True]


def test_full0_rsf_twelve_month_original_entry_rescores_complete_retained_stream(
        full_inputs, tmp_path, monkeypatch, retained_source_bundle):
    """Physical inputs and original consumers; only synthetic R leaves/serial pool."""
    import copy
    import json
    import shutil
    from collections import Counter
    from decimal import Decimal, ROUND_HALF_UP
    from types import SimpleNamespace
    from padml import f2_kernel as kernel, nested_loco as nested
    from padml.bundle import sha256_file
    from test_full0_entry_points import unfitted_full0_mice_run
    from test_q_funnel_shards import _six_shard_batches

    # Reuse the existing physical F1 fixture with enough at-risk rows for the
    # unchanged IBS support checks. Its split stub accepts arbitrary IDs.
    synthetic = ([f"p{i:03d}" for i in range(350)],
                 [center for center in (36, 38, 39, 48, 52, 54, 55) for _ in range(50)],
                 [i % 2 for i in range(350)])
    root, covariates_path, response_path, _ = prepared.__wrapped__(synthetic, tmp_path, monkeypatch)
    sources = strict_json_bytes((root / "full-development.json").read_bytes())
    plan, policy = sources["plan"], sources["resource_policy"]
    covariates, response, _ = f5._full_development_raw_inputs(sources)
    fields, responses = f5._response_rows(response)
    inner_ids = {pair["split_id"] for pair in plan["split_pairs"]}
    tasks = [task for task in f5.compile_full_data_search_mice_tasks(plan) if task["split_id"] in inner_ids]
    tasks.append(f5.compile_final_full_data_mice_task(plan))
    mice_calls = []
    def mice_leaf(arguments, **kwargs):
        mice_calls.append("REPLAY" if "REPLAY" in arguments else "FIT")
        return unfitted_full0_mice_run(arguments, **kwargs)
    with monkeypatch.context() as setup:
        setup.setattr(f5.subprocess, "run", mice_leaf)
        for task in tasks:
            _, fit_ids, _ = f5._mice_view_rows(plan, task)
            path = (root / "final-mice.zip" if task["phase"] == "FINAL_MICE" else
                    root / "mice" / task["split_id"] / (task["role"].lower() + ".zip"))
            path.parent.mkdir(parents=True, exist_ok=True)
            f5.execute_full_data_search_mice_view(plan, task, covariates,
                f5._write_response_subset(fields, responses, fit_ids, None)["private_bytes"]
                if task["role"] == "ANALYSIS" else None, path, rscript="UNFITTED")
    assert mice_calls == ["FIT", "REPLAY"] * 31
    retained = f4._retained_full0_source_members(retained_source_bundle, full0_preparation=True)
    producer_identity = sha256_bytes(canonical_json_bytes(retained))
    native_calls, phases, old_traces = [], [], []
    selector = Path(sources["selector_root"])
    with monkeypatch.context() as setup:
        unfitted_selector_consumers.__wrapped__(setup)
        counts = _selector_shard_engines(setup, f4.subprocess.run)
        with f5._materialized_full_data_development_sources(root / "full-development.json", root,
                selector_only=True) as (_, parts, full):
            inputs = (plan, parts, full)
            selector_work = tmp_path / "selector-fixture"
            selector_work.mkdir()
            def run(destination, **kwargs):
                return f5._nested_full_selector_program(*inputs, destination, rscript="UNFITTED",
                    resource_policy=policy, **kwargs)
            development, transported = _exercise_selector_shards(run, selector_work, policy, counts,
                                                                  monkeypatch=setup)
            # Preserve the complete current producer. This separate test-only
            # copy represents the old transport schema, not a formal relabel.
            shutil.copytree(transported, selector, ignore=shutil.ignore_patterns("resource-release-*.json"))
            selected = strict_json_bytes((selector / "selector.json").read_bytes())
            for phase in selected["phase_execution_sha256"]:
                path = selector / phase / "execution.json"
                records = strict_json_bytes(path.read_bytes())
                for record in records:
                    record["execution"]["source_identity"] = producer_identity
                    record["execution"].pop("resource_release")
                raw = canonical_json_bytes(records)
                path.write_bytes(raw)
                selected["phase_execution_sha256"][phase] = sha256_bytes(raw)
            raw = canonical_json_bytes(selected)
            (selector / "selector.json").write_bytes(raw)
            development = {**development, "selector_result_sha256": sha256_bytes(raw)}
            development["identity_sha256"] = sha256_bytes(canonical_json_bytes({
                key: value for key, value in development.items() if key != "identity_sha256"}))
            (selector / "development-input.json").write_bytes(canonical_json_bytes(development))
            original_task = f5.compile_nested_full_complex_search_task(*inputs, selector, family="RSF",
                rscript="UNFITTED", resource_policy=policy, retained_full0_source_bundle=retained_source_bundle)
            assert counts["engine"] == counts["native"] == 640 and counts["forbid_native"]
            def native(command, **kwargs):
                spec = strict_json_bytes(Path(command[-1]).read_bytes())
                assert spec["family"] == "RSF" and "native_search_batch" not in spec
                assert not kernel._contains_key(spec, "evaluation_response")
                assert spec.get("selection_horizon_months", 24) == 24
                partitions = {part["partition_id"]: part for part in spec["registered_partitions"]["partitions"]}
                native_calls.append((spec["native_search_replay"], [task["task_id"] for task in spec["producer_tasks"]]))
                rows = []
                for task in spec["producer_tasks"]:
                    stage, trial = task["task_id"].split("_")[:2]
                    assert stage in {"S1", "S2"}
                    trial = int(trial[1:])
                    part = partitions[task["partition_id"]]
                    directory = Path(spec["native_search_root"]) / task["task_id"]
                    raw = ("UNFITTED:" + task["task_id"]).encode()
                    if spec["native_search_replay"]:
                        assert (directory / "model.rds").read_bytes() == raw
                    else:
                        directory.mkdir()
                        (directory / "model.rds").write_bytes(raw)
                    colmap = kernel._expected_family_parent_column_map(task["selected_parents"], "RSF", spec["predictors"], None)
                    columns = sum(len(row["columns"]) for row in colmap)
                    parameters = task["parameters"]
                    mtry = min(columns, max(1, int((Decimal(str(parameters["mtry_fraction"])) * columns)
                               .quantize(Decimal("1"), rounding=ROUND_HALF_UP))))
                    curve = ([0.9] * 12 + [0.1] * 24 if stage == "S2" and trial == 1 else
                             [0.8 - (trial - 2) * 0.1] * 36 if stage == "S2" else
                             [0.99 - trial * 0.02] * 36)
                    curve = [value + task["imputation"] / 10000 for value in curve]
                    rows.append({"task_id": task["task_id"], "partition_id": task["partition_id"],
                        "imputation": task["imputation"], "evaluation_ids": part["evaluation_ids"],
                        "transform_recipe_sha256": "RAW_CANONICAL", "ordered_parent_column_map": colmap,
                        "stopping": {"converged": True, "warning_count": 0, "engine": "ranger::ranger",
                            "num_trees": parameters["num_trees"], "tree_count": parameters["num_trees"],
                            "mtry": mtry, "independent_variable_count": columns, "death_time_count": 1,
                            "prediction_error": 0.2},
                        "survival": [curve for _ in part["evaluation_ids"]]})
                Path(spec["output_path"]).write_bytes(canonical_json_bytes({"schema_version": "1.0.0",
                    "kind": "PADML_F2_R_PREDICTION_BATCH", "status": "PASS", "task_count": len(rows), "tasks": rows}))
                kwargs["stdout"].write(b"UNFITTED RSF leaf; original R-output and IBS consumers\n")
                return SimpleNamespace(returncode=0)
            def serial(function, jobs, *, selected_slots, execution_report=None, on_result=None,
                       resource_release_report=None):
                # Historical geometry is 56; the physical synthetic executor
                # is one H9 process, never a real 56-process test pool.
                assert 1 <= selected_slots <= 56
                if execution_report is not None:
                    execution_report.update(configured_worker_ceiling=56, admitted_worker_ceiling=selected_slots,
                        runnable_task_count=len(jobs), actual_worker_process_peak=1, completed_task_count=0,
                        engine_threads=1, status="RUNNING")
                results = []
                for index, job in enumerate(jobs):
                    result = function(job)
                    results.append(result)
                    if on_result is not None:
                        on_result(index, result)
                    if resource_release_report is not None:
                        resource_release_report[str(index)] = runtime.release_step_resources([],
                            owner=f"POOL_TASK_RESULT:{index}", before=runtime.observe_step_memory(), released_references=[])
                if execution_report is not None:
                    execution_report.update(completed_task_count=len(jobs), status="COMPLETED")
                return results
            setup.setattr(runtime, "effective_cpu_count", lambda: 64)
            setup.setattr(runtime, "observe_execution_resources", lambda path: {
                "effective_cpus": 64, "available_memory_bytes": 10**12,
                "scratch_available_bytes": 10**12, "scratch_root": str(path)})
            setup.setattr(f4.subprocess, "run", native)
            setup.setattr(f5, "_bounded_ordered_spawn", serial)
            setup.setattr(kernel, "_bounded_ordered_spawn", serial)
            original_choose = kernel._tree_s3a_candidates
            def choose(trace):
                old_traces.append(copy.deepcopy(trace))
                return original_choose(trace)
            setup.setattr(kernel, "_tree_s3a_candidates", choose)
            owner = Path(sources["search_roots"]["RSF"])
            with _six_shard_batches(setup, owner, policy, phases, stop_after=2) as history:
                old_ready = f5._final_complex_search_program(original_task, parts, owner, replay=False,
                    resource_policy=policy, batch_options={"prepare_only": True, "task_ids": None,
                        "batch_root": None, "q_batches": None, "retained_bytes_per_task": None})
            assert old_ready["status"] == "PREPARED_Q_BATCH" and len(history) == 12
            assert [row["unit_count"] for row in phases] == [60, 75]
            assert sum(row["first_audits"] for row in phases) == 320 and len(old_traces) == 1
            geometry = {stage: Counter(len(tasks) for replay, tasks in native_calls
                if not replay and tasks[0].startswith(stage + "_")) for stage in ("S1", "S2")}
            assert geometry == {"S1": {2: 60}, "S2": {3: 50, 2: 25}}
    assert len(native_calls) == 270 and sum(len(tasks) for replay, tasks in native_calls if not replay) == 320
    retained_batches = []
    for index, batch in enumerate(history):
        destination = tmp_path / f"synthetic-legacy-q-batch-{index:02d}"
        shutil.copytree(batch, destination)
        execution = strict_json_bytes((destination / "execution.json").read_bytes())
        execution["source_identity"] = producer_identity
        execution.pop("resource_release")
        (destination / "execution.json").write_bytes(canonical_json_bytes(execution))
        retained_batches.append(destination)
    legacy = copy.deepcopy(sources)
    legacy["raw_input_binding"]["f45_source_sha256"] = producer_identity
    legacy_path = root / "synthetic-legacy-lineage.json"
    legacy_path.write_bytes(canonical_json_bytes(legacy))
    decision = nested._sealed({**{key: value for key, value in legacy["science_decision"].items()
                                  if key != "identity_sha256"},
                               "twelve_month_development": nested._twelve_month_development_contract()})
    twelve = tmp_path / "twelve-original-entry"
    preserved = {str(path): sha256_file(path) for parent in [root, *retained_batches]
                 for path in parent.rglob("*") if path.is_file()}
    def forbidden(*args, **kwargs):
        pytest.fail("No new native FIT/audit, MICE, recipe/path or split RNG in numerical 12-month entry")
    with monkeypatch.context() as consume:
        for name in ("compile_full_data_mice_plan", "full_data_splits", "_replay_mice_native_view",
                     "execute_full_data_search_mice_view", "_execute_and_verify_q_search_unit"):
            consume.setattr(f5, name, forbidden)
        consume.setattr(f5.subprocess, "run", forbidden)
        consume.setattr(f5, "_bounded_ordered_spawn", serial)
        consume.setattr(kernel, "_bounded_ordered_spawn", serial)
        f5.compile_full_data_development_inputs(covariates_path, response_path, twelve,
            f1_runtime_root=tmp_path / "f1", science_decision=decision, resource_policy=policy,
            retained_bytes_per_view=1000, retained_bytes_per_component=1000,
            expanded_bytes_per_component=1000, shared_storage_bytes=1000, rscript="UNFITTED",
            selection_horizon_months=12, retained_full_development_path=legacy_path,
            retained_full_development_sha256=sha256_file(legacy_path), retained_full0_source_bundle=retained_source_bundle)
        result = f5.execute_final_complex_search(full_development_path=twelve / "full-development.json",
            candidate_family="RSF", target=twelve / "not-computed.zip", prepare_only=True,
            q_batches=retained_batches, retained_full0_source_bundle=retained_source_bundle,
            selection_horizon_months=12)
    assert result["status"] == "PREPARED_Q_BATCH" and result["stage_acceptance"] is False
    assert result["historical_model_fit_count"] == result["historical_first_native_audit_count"] == 320
    assert all(result[name] == 0 for name in ("new_model_fits", "new_first_native_audit_count", "new_stop_fits",
        "new_mice_chains", "new_selector_paths", "new_split_rng_calls"))
    assert len(result["next_atomic_units"]) == len(result["task_ids"]) == 100
    assert all(len(atom["producer_tasks"]) == 3 for atom in result["next_atomic_units"])
    assert [row["trial_index"] for row in original_choose(old_traces[0])] == [2, 3, 4]
    assert [row["trial_index"] for row in result["s3a_candidates"]] == [1, 2, 3]
    assert len(result["search_trace"]["S1"]) == 24 and len(result["search_trace"]["S2"]) == 8
    assert len(native_calls) == 270 and mice_calls == ["FIT", "REPLAY"] * 31
    assert all(sha256_file(Path(path)) == digest for path, digest in preserved.items())
    assert not (twelve / "not-computed.zip").exists()
    assert all(not Path(row["temporary_root"]).exists() for row in result["execution_report"]["input_lifecycle"].values())
    qroot = Path(result["native_search_root"])
    new_input = strict_json_bytes((qroot / "input.json").read_bytes())
    old_input = strict_json_bytes((retained_batches[0] / "input.json").read_bytes())
    for field in ("seed", "registered_inputs_identity_sha256"):
        wrong = copy.deepcopy(old_input)
        wrong["spec"][field] = wrong["spec"][field] + 1 if field == "seed" else "0" * 64
        with pytest.raises(ContractError, match="F5_FULL0_RSF_S1S2_INPUT_PAIR_INVALID"):
            f5._full0_rsf_s1s2_input_pair(wrong, new_input)
    reader = {"source": twelve / "full-development.json",
        "source_sha256": sha256_file(twelve / "full-development.json"),
        "source_identity": sha256_bytes(canonical_json_bytes(f4._f45_source_member_sha256())),
        "q_root": qroot, "q_input": result["consumer_input"], "task_sha256": new_input["task"]["task_sha256"],
        "selector_root": selector, "selector_binding": result["execution_report"]["selector_binding"],
        "selector_partitions": strict_json_bytes((selector / "partitions.json").read_bytes()),
        "policy": policy, "selection_horizon_months": 12, "rescore_task": new_input["task"],
        "retained_q_input": result["producer_input"], "retained_source_identity": producer_identity}
    for damage in ("whole-atom-order", "cross-partition-task-swap"):
        wrong = copy.deepcopy(result)
        atoms = wrong["next_atomic_units"]
        if damage == "whole-atom-order":
            atoms.reverse()
        else:
            atoms[0]["producer_tasks"][0], atoms[20]["producer_tasks"][0] = (
                atoms[20]["producer_tasks"][0], atoms[0]["producer_tasks"][0])
            for atom in (atoms[0], atoms[20]):
                atom["task_id"] = "batch-" + sha256_bytes(canonical_json_bytes(
                    [task["task_id"] for task in atom["producer_tasks"]]))[:24]
        # Recompute every superficial seal: the original reader must enforce
        # original atomic geometry/order, not only its set or checksum.
        wrong["task_ids"] = [atom["task_id"] for atom in atoms]
        wrong["phase"] = "_run_r_prediction_pool_task-" + sha256_bytes(canonical_json_bytes(wrong["task_ids"]))[:24]
        digest = sha256_bytes(canonical_json_bytes({key: value for key, value in wrong.items()
                                                   if key != "execution_report"}))
        wrong["execution_report"]["result_sha256"] = digest
        with pytest.raises(ContractError, match="F5_FULL0_Q_INPUT_EXECUTION_INVALID"):
            f5._validate_full0_q_input_execution(wrong, expected_result_sha256=digest, **reader)
    (tmp_path / "full0-rsf12-entry-observation.json").write_bytes(canonical_json_bytes({
        "actual_model_fits": 0, "actual_mice_chains": 0, "native_leaf": "UNFITTED",
        "current_producer_preserved": str(root), "synthetic_old_producer_identity": producer_identity,
        "historical_geometry": {stage: {str(size): count for size, count in counts.items()}
                                for stage, counts in geometry.items()},
        "actual_test_process_peak": 1, "old_24_trace": old_traces[0], "result": result,
        "rejected_counterexamples": ["producer-seed", "producer-input-identity", "whole-atom-order", "cross-partition-task-swap"]}))


@pytest.mark.parametrize("damage", ["missing-path", "missing-sha", "missing-source", "wrong-sha",
                                  "plan-drift", "raw-drift", "f1-drift", "old-decision", "unmarked-twelve", "horizon-bool", "retained-for24", "symlink-parent", "target-old-selector"])
def test_twelve_month_lineage_rejects_wrong_provenance_before_output(
        prepared, retained_source_bundle, monkeypatch, damage):
    from padml import nested_loco as nested
    from padml.bundle import sha256_file

    root, covariates, response, _ = prepared
    legacy = strict_json_bytes((root / "full-development.json").read_bytes())
    legacy["raw_input_binding"]["f45_source_sha256"] = sha256_bytes(canonical_json_bytes(
        f4._retained_full0_source_members(retained_source_bundle, full0_preparation=True)))
    decision = nested._sealed({**{key: value for key, value in legacy["science_decision"].items()
                                  if key != "identity_sha256"},
                               "twelve_month_development": nested._twelve_month_development_contract()})
    legacy_path = root / "synthetic-legacy-lineage.json"
    legacy_path.write_bytes(canonical_json_bytes(legacy))
    expected_sha = sha256_file(legacy_path)
    kwargs = {"selection_horizon_months": 12, "retained_full_development_path": legacy_path,
              "retained_full_development_sha256": expected_sha, "retained_full0_source_bundle": retained_source_bundle}
    if damage.startswith("missing-"):
        kwargs.pop({"missing-path": "retained_full_development_path", "missing-sha": "retained_full_development_sha256",
                    "missing-source": "retained_full0_source_bundle"}[damage])
    elif damage == "wrong-sha":
        kwargs["retained_full_development_sha256"] = "0" * 64
    elif damage == "plan-drift":
        legacy["plan"]["patient_keys"] = list(reversed(legacy["plan"]["patient_keys"]))
        legacy_path.write_bytes(canonical_json_bytes(legacy))  # independent expected SHA is not resealed
    elif damage in {"raw-drift", "f1-drift", "unmarked-twelve"}:
        if damage == "unmarked-twelve":
            legacy["science_decision"] = decision
        else:
            key = "covariates_sha256" if damage == "raw-drift" else "f1_identity"
            legacy["raw_input_binding"][key] = "0" * 64
        legacy_path.write_bytes(canonical_json_bytes(legacy))
        kwargs["retained_full_development_sha256"] = sha256_file(legacy_path)
    elif damage == "old-decision":
        decision = legacy["science_decision"]
    elif damage == "horizon-bool":
        kwargs["selection_horizon_months"] = True
    elif damage == "retained-for24":
        kwargs["selection_horizon_months"] = 24
    monkeypatch.setattr(f5, "compile_full_data_mice_plan", lambda *a, **k: pytest.fail("No RNG on rejected lineage"))
    target = root.parent / "rejected-twelve-prepared"
    if damage == "symlink-parent":
        alias = root.parent / "alias"
        alias.symlink_to(root.parent, target_is_directory=True)
        target = alias / target.name
    elif damage == "target-old-selector":
        target = Path(legacy["selector_root"])
        assert not target.exists()
    with pytest.raises(ContractError):
        f5.compile_full_data_development_inputs(covariates, response, target,
            f1_runtime_root=root.parent / "f1", science_decision=decision, resource_policy=legacy["resource_policy"],
            retained_bytes_per_view=1000, retained_bytes_per_component=1000,
            expanded_bytes_per_component=1000, shared_storage_bytes=1000, rscript="UNFITTED", **kwargs)
    assert not target.exists()


@pytest.mark.parametrize("family", ["RSF", "GBM_COX", "XGBOOST_COX", "COXTIME_SET_A"])
@pytest.mark.parametrize("prepare_only", [False, True])
def test_twelve_month_q_stays_closed_after_lineage_compiler(tmp_path, monkeypatch, family, prepare_only):
    monkeypatch.setattr(f5, "_read_final_lineage", lambda *a, **k: pytest.fail("No Q or lineage read before pending-Q rejection"))
    target = tmp_path / "no-q.zip"
    with pytest.raises(ContractError, match="F5_COMPLEX_SEARCH_TWELVE_MONTH_Q_PENDING"):
        f5.execute_final_complex_search(target=target, full_development_path=tmp_path / "full-development.json",
            candidate_family=family, selection_horizon_months=12, prepare_only=prepare_only,
            retained_full0_source_bundle=tmp_path / "retained.zip")
    assert not target.exists() and not list(tmp_path.iterdir())


@pytest.mark.parametrize("horizon", [12, 24])
def test_twelve_month_lineage_cli_forwards_original_producer_pins(tmp_path, monkeypatch, capsys, horizon):
    calls = []
    decision, policy = tmp_path / "science.json", tmp_path / "policy.json"
    decision.write_bytes(canonical_json_bytes({}))
    policy.write_bytes(canonical_json_bytes({}))
    monkeypatch.setattr(f5, "compile_full_data_development_inputs",
                        lambda *a, **kw: calls.append((a, kw)) or {"UNFITTED": True})
    args = ["padml-f5", "compile-full-development", str(tmp_path / "covariates.csv"),
            str(tmp_path / "response.csv"), str(tmp_path / "new12"),
            "--science-decision", str(decision), "--resource-policy", str(policy), "--f1-runtime-root", str(tmp_path)]
    if horizon == 12:
        args += ["--selection-horizon-months", "12", "--retained-full-development", str(tmp_path / "old24.json"),
                 "--retained-full-development-sha256", "a" * 64, "--retained-full0-source-bundle", str(tmp_path / "old-source.zip")]
    for name in ("retained-bytes-per-view", "retained-bytes-per-component", "expanded-bytes-per-component", "shared-storage-bytes"):
        args += ["--" + name, "1000"]
    monkeypatch.setattr(sys, "argv", args)
    f5.main()
    assert strict_json_bytes(capsys.readouterr().out.encode()) == {"UNFITTED": True}
    assert len(calls) == 1
    kwargs = calls[0][1]
    if horizon == 24:
        assert not {"selection_horizon_months", "retained_full_development_path",
                    "retained_full_development_sha256", "retained_full0_source_bundle"}.intersection(kwargs)
        return
    assert kwargs["selection_horizon_months"] == 12
    assert kwargs["retained_full_development_path"] == tmp_path / "old24.json"
    assert kwargs["retained_full_development_sha256"] == "a" * 64
    assert kwargs["retained_full0_source_bundle"] == tmp_path / "old-source.zip"


def test_retained_source_never_authorizes_new_or_partial_rsf(tmp_path, retained_source_bundle):
    policy = {"configured_worker_ceiling": runtime.CPU_MINUS_8, "memory_bytes_per_worker": 2 * 1024**3,
        "scratch_bytes_per_worker": 1, "memory_reserve_bytes": 0, "scratch_reserve_bytes": 0,
        "transfer_archive_worker_ceiling": 1}
    with pytest.raises(ContractError, match="F5_(RETAINED_FULL0_SOURCE_SCOPE|Q_BATCH_ARGUMENTS)_INVALID"):
        f5._q_search_batch_control(tmp_path, policy, {}, retained_full0_source_bundle=retained_source_bundle)
    with pytest.raises(ContractError, match="F5_RETAINED_FULL0_SOURCE_SCOPE_INVALID"):
        f5.execute_final_complex_search(full_development_path=tmp_path / "full-development.json",
            candidate_family="RSF", target=tmp_path / "never-created.zip",
            retained_full0_source_bundle=retained_source_bundle)
    for context, replay, phase in (
        ({"kind": "PADML_NESTED_FULL_DATA_SELECTOR_SOURCE_V1", "context": 0}, False, None),
        ({"kind": "PADML_NESTED_FULL_DATA_SELECTOR_SOURCE_V1", "context": 0}, True, "coarse"),
        ({"kind": "PADML_NESTED_NO_AAR_SELECTOR_SOURCE_V1", "context": 1}, True, None),
    ):
        with pytest.raises(ContractError, match="F5_RETAINED_FULL0_SOURCE_SCOPE_INVALID"):
            f4._full_pipeline_selector_search({"source": context}, [], tmp_path / "never-selector",
                rscript="FORBIDDEN", replay=replay, numerical=True, phase_name=phase,
                retained_full0_source_bundle=retained_source_bundle)
    assert not (tmp_path / "never-selector").exists()


@pytest.mark.parametrize("command", ["complex-search", "full-score", "compile-final-refit"])
def test_full0_cli_explicit_provenance_forwarding(tmp_path, monkeypatch, capsys, command):
    source, bundle, target = [tmp_path / name for name in ("full-development.json", "old-source.zip", "result")]
    calls = []
    function = {"complex-search": "execute_final_complex_search", "full-score": "execute_full_data_locked_scores",
                "compile-final-refit": "compile_final_refit_bundles"}[command]
    monkeypatch.setattr(f5, function, lambda *a, **kw: calls.append(kw) or {"UNFITTED": True})
    args = ([str(source)] if command == "full-score" else ["--full-development", str(source), "--target", str(target)])
    if command == "complex-search":
        args += ["--candidate-family", "GBM_COX", "--prepare-only"]
    monkeypatch.setattr(sys, "argv", ["padml-f5", command, *args, "--retained-full0-source-bundle", str(bundle)])
    f5.main()
    assert strict_json_bytes(capsys.readouterr().out.encode()) == {"UNFITTED": True}
    assert len(calls) == 1 and calls[0]["retained_full0_source_bundle"] == bundle


def test_completed_selector_old_binding_replays_into_unchanged_q_task(
        full_inputs, tmp_path, unfitted_selector_consumers, monkeypatch, retained_source_bundle):
    inputs = _physical_full_inputs(full_inputs, tmp_path / "inputs")
    counts = _selector_shard_engines(monkeypatch, f4.subprocess.run)
    policy = {"configured_worker_ceiling": runtime.CPU_MINUS_8, "memory_bytes_per_worker": 2 * 1024**3,
        "scratch_bytes_per_worker": 1, "memory_reserve_bytes": 0, "scratch_reserve_bytes": 0,
        "transfer_archive_worker_ceiling": 1000}
    retained = f4._retained_full0_source_members(retained_source_bundle, full0_preparation=True)
    def run(root, **kwargs):
        return f5._nested_full_selector_program(*inputs, root, rscript="UNFITTED", resource_policy=policy, **kwargs)
    # Run the current producer under its own identity, including its current
    # release schema. Calling it 1513 before its own gather is not a valid
    # synthetic old producer: the original reader correctly rejects that mix.
    result, transported = _exercise_selector_shards(run, tmp_path, policy, counts, monkeypatch=monkeypatch)
    with pytest.raises(ContractError, match="NESTED_SELECTOR_PHASE_SOURCE_OR_ADMISSION_DRIFT"):
        run(transported, replay=True, retained_full0_source_bundle=retained_source_bundle)
    import shutil
    current_transport = transported
    transported = tmp_path / "legacy-transported"
    shutil.copytree(current_transport, transported, ignore=shutil.ignore_patterns("resource-release-*.json"))
    selector = strict_json_bytes((transported / "selector.json").read_bytes())
    for phase in selector["phase_execution_sha256"]:
        path = transported / phase / "execution.json"
        records = strict_json_bytes(path.read_bytes())
        for row in records:
            row["execution"]["source_identity"] = sha256_bytes(canonical_json_bytes(retained))
            row["execution"].pop("resource_release")
        raw = canonical_json_bytes(records)
        path.write_bytes(raw)
        selector["phase_execution_sha256"][phase] = sha256_bytes(raw)
    raw = canonical_json_bytes(selector)
    (transported / "selector.json").write_bytes(raw)
    development = {**result, "selector_result_sha256": sha256_bytes(raw)}
    development["identity_sha256"] = sha256_bytes(canonical_json_bytes({
        key: value for key, value in development.items() if key != "identity_sha256"}))
    (transported / "development-input.json").write_bytes(canonical_json_bytes(development))
    assert {key: value for key, value in development.items()
            if key not in {"selector_result_sha256", "identity_sha256"}} == {
        key: value for key, value in result.items() if key not in {"selector_result_sha256", "identity_sha256"}}
    result = development
    with pytest.raises(ContractError, match="NESTED_SELECTOR_PHASE_SOURCE_OR_ADMISSION_DRIFT"):
        run(transported, replay=True)
    assert run(transported, replay=True, retained_full0_source_bundle=retained_source_bundle) == result
    original_task = f5.compile_nested_full_complex_search_task(*inputs, transported, family="GBM_COX",
        rscript="FORBIDDEN", resource_policy=policy, retained_full0_source_bundle=retained_source_bundle)
    actual_task = f5.compile_nested_full_complex_search_task(*inputs, transported, family="GBM_COX",
        rscript="FORBIDDEN", resource_policy=policy, retained_full0_source_bundle=retained_source_bundle)
    assert actual_task == original_task and counts["engine"] == counts["native"] == 640
    # The same completed preparation can compile the explicitly confirmed
    # 12-month consumer task. It is not a replay of an old Q or a new fit.
    from padml import nested_loco as nested
    from test_nested_full_development import _unfitted_confirmed_decision
    decision = _unfitted_confirmed_decision(fixed_bootstrap=True)
    decision = nested._sealed({**{key: item for key, item in decision.items() if key != "identity_sha256"},
                              "twelve_month_development": nested._twelve_month_development_contract()})
    twelve = f5.compile_nested_full_complex_search_task(*inputs, transported,
        family="GBM_COX", rscript="FORBIDDEN", resource_policy=policy,
        retained_full0_source_bundle=retained_source_bundle,
        selection_horizon_months=12, science_decision=decision)
    changed = {"task_sha256", "trial_scoring", "selection_horizon_months", "science_decision"}
    assert {key: value for key, value in twelve.items() if key not in changed} == {
        key: value for key, value in original_task.items() if key not in changed}
    assert twelve["selection_horizon_months"] == 12 and twelve["science_decision"] == decision
    assert twelve["trial_scoring"]["ibs_grid_months"] == list(range(13))
    rsf = f5.compile_nested_full_complex_search_task(*inputs, transported,
        family="RSF", rscript="FORBIDDEN", resource_policy=policy,
        retained_full0_source_bundle=retained_source_bundle,
        selection_horizon_months=12, science_decision=decision)
    assert rsf["family"] == "RSF" and rsf["selection_horizon_months"] == 12
    assert rsf["selected_parents"] == twelve["selected_parents"]
    assert counts["engine"] == counts["native"] == 640
    missing_mi = {**inputs[2], "fit_covariate_members": inputs[2]["fit_covariate_members"][:-1]}
    with pytest.raises(ContractError):
        f5.compile_nested_full_complex_search_task(inputs[0], inputs[1], missing_mi, transported,
            family="RSF", rscript="FORBIDDEN", resource_policy=policy,
            retained_full0_source_bundle=retained_source_bundle,
            selection_horizon_months=12, science_decision=decision)
    assert counts["engine"] == counts["native"] == 640
    with pytest.raises(ContractError, match="F5_RETAINED_FULL0_SOURCE_SCOPE_INVALID"):
        run(transported, replay=False, phase_name="fine", phase_batches=[],
            retained_full0_source_bundle=retained_source_bundle)


def test_completed_old_rsf_full_funnel_and_archive_keep_explicit_provenance(
        full_inputs, unfitted_selector_consumers, tmp_path, monkeypatch, retained_source_bundle):
    from test_q_funnel_shards import (
        test_full0_original_five_stage_funnel_six_shards_and_complete_numeric_owner as exercise,
    )
    retained = f4._retained_full0_source_members(retained_source_bundle, full0_preparation=True)
    current_sources = f5._final_search_sources()
    old_sources = {name: retained[name] for name in current_sources}
    # One synthetic old producer, all five original stages, UNFITTED leaves.
    with monkeypatch.context() as old:
        old.setattr(f4, "_f45_source_member_sha256", lambda: retained)
        old.setattr(f5, "_final_search_sources", lambda: old_sources)
        # The reused original-funnel fixture restores its module-level
        # observation callable before invoking the public owner.  Replace that
        # retained fixture seam, rather than weakening any admission check.
        old.setattr(sys.modules[exercise.__module__], "_OBSERVE", lambda root: {
            "effective_cpus": 32, "available_memory_bytes": 64 * 1024**3,
            "scratch_available_bytes": 64 * 1024**3, "scratch_root": str(root)})
        exercise(full_inputs, unfitted_selector_consumers, tmp_path, monkeypatch, "RSF")
    # The existing synthetic physical MICE/leaf fixtures remain; source
    # identity and every original Q/selector/metric validator are now current.
    archive = tmp_path / "search.zip"
    with pytest.raises(ContractError):
        f5.read_final_complex_search(archive, rscript="UNFITTED")
    with zipfile.ZipFile(archive) as opened:
        value = strict_json_bytes(opened.read("final-search-execution.json"))
    assert f5.read_final_complex_search(archive, rscript="UNFITTED",
        retained_full0_source_bundle=retained_source_bundle) == value
    evidence = value["execution_evidence"]
    evidence["source_members"]["padml/f5.py"] = current_sources["padml/f5.py"]
    evidence["source_members_sha256"] = sha256_bytes(canonical_json_bytes(evidence["source_members"]))
    value["identity_sha256"] = sha256_bytes(canonical_json_bytes({key: item for key, item in value.items() if key != "identity_sha256"}))
    with pytest.raises(ContractError):
        f5._validate_executed_complex_search_archive(value, retained_full0_source_bundle=retained_source_bundle)


def test_retained_primary_m20_reads_original_numbers_without_refit(tmp_path, monkeypatch, retained_source_bundle):
    """Original complete M20 producer/reader; model and first-audit leaves UNFITTED."""
    from types import SimpleNamespace
    from padml import f4_compact, nested_loco as nested
    from padml.bundle import read_safe_zip
    from test_nested_outer_f4 import outer_bundle
    from test_outer_final_shards import _serial_engines, _winner_inputs
    retained = f4._retained_full0_source_members(retained_source_bundle, aar_primary_context=True)
    current = f4._f45_source_member_sha256()
    original = tmp_path / "original"
    original.mkdir()
    original_admission = f4._o_fit_final_batch_admission
    def historical_admission(request, observation, coordinate_count, *, execution_worker_memory_bytes=None):
        # The retained producer predates the future-only 2 GiB override.
        # Recreate its exact evidence shape; the current reader must retain
        # that historical policy rather than rewrite it during validation.
        return original_admission(request, observation, coordinate_count)
    with monkeypatch.context() as old:
        old.setattr(f4, "_f45_source_member_sha256", lambda: retained)
        old.setattr(f4, "_o_fit_final_batch_admission", historical_admission)
        source, _ = outer_bundle.__wrapped__(original, monkeypatch, SimpleNamespace(param=False))
        request_root = tmp_path / "input-material"
        request = f4._materialize_o_fit_input_bundle(source, request_root)
        calls = _serial_engines(monkeypatch)
        root = tmp_path / "final-owner"
        scored = _winner_inputs(request, request_root, root, "COXTIME_SET_A")
        batch = root / "final-batches/whole-m20"
        produced = f4._o_fit_post_lock_m20(request, scored, root, workers=4, replay=False,
            imputations=list(range(1, 21)), batch_root=batch)
        assert produced["new_model_fits"] == produced["new_model_native_verification_count"] == 20
        gathered = f4._o_fit_post_lock_m20(request, scored, root, workers=4, replay=False, final_batches=[batch])
    assert len(calls) == 20 and f4._f45_source_member_sha256() == current
    with pytest.raises(ContractError):
        f4._materialize_o_fit_input_bundle(source, tmp_path / "no-proof-input")
    opened = f4._materialize_o_fit_input_bundle(source, tmp_path / "retained-input",
        retained_primary_source_bundle=retained_source_bundle)
    assert opened == request
    options = {"request": request, "request_root": root / "request", "lock": gathered["development_lock"],
               "native_members": gathered["native_members"]}
    with pytest.raises(ContractError, match="F4_O_FIT_FINAL_BATCH_SOURCE_DRIFT"):
        f4_compact.read_o_fit_final_numbers(root / "final-numbers.zip", **options)
    rebuilt = f4_compact.read_o_fit_final_numbers(root / "final-numbers.zip", **options,
        retained_primary_source_bundle=retained_source_bundle)
    assert rebuilt["selected_prediction"] == gathered["selected_prediction"]
    assert rebuilt["component_receipts"] == gathered["component_receipts"] and len(calls) == 20
    for prepare_only in (False, True):
        with pytest.raises(ContractError, match="F4_RETAINED_PRIMARY_SOURCE_SCOPE_INVALID"):
            f4._o_fit_post_lock_m20(request, scored, root, workers=4, replay=False, prepare_only=prepare_only,
                retained_primary_source_bundle=retained_source_bundle)
    entries = read_safe_zip(root / "final-numbers.zip")
    values = strict_json_bytes(entries["final.json"])
    mean = bytearray(entries["heldout-mean.f64"])
    mean[-1] ^= 1
    with pytest.raises(ContractError, match="F4_O_FIT_FINAL_NUMBERS_MEAN_DRIFT"):
        f4_compact._o_fit_final_numbers(values, bytes(mean), **options,
            retained_primary_source_bundle=retained_source_bundle)
    assert nested._sha(f4._f45_source_member_sha256()) == nested._sha(current) and len(calls) == 20


def test_retained_no_aar_selector_keeps_one_original_producer(tmp_path, monkeypatch, request, retained_source_bundle):
    """Original all-coordinate reduction, with synthetic tied-time UNFITTED path leaves."""
    from padml import f5_sensitivity as sensitivity
    from test_nested_aar_mice import unfitted_selector_shard_inputs
    retained = f4._retained_full0_source_members(retained_source_bundle, aar_no_aar_selector=True)
    with monkeypatch.context() as old:
        old.setattr(f4, "_f45_source_member_sha256", lambda: retained)
        prepared = unfitted_selector_shard_inputs.__wrapped__(tmp_path, monkeypatch, request)
        counts = _selector_shard_engines(monkeypatch, f4.subprocess.run)
        policy = prepared["source"]["resource_policy"]
        def run(root, **kwargs):
            if kwargs.get("phase_name") is not None:
                kwargs["phase_release"] = {}
            return sensitivity._a12_no_aar_selector_program(prepared, root, **kwargs)
        result, transported = _exercise_selector_shards(run, tmp_path, policy, counts,
            monkeypatch=monkeypatch, no_aar=True)
    with pytest.raises(ContractError):
        run(transported, replay=True)
    # This synthetic selector has a deliberately reconstructed decision and
    # cannot be relabelled as the retained producer merely by attaching its
    # source ZIP. The real retained-source path is exercised by the exact
    # source fixtures below.
    prepared = {**prepared, "retained_primary_source_bundle": retained_source_bundle}
    with pytest.raises(ContractError, match="F5_RETAINED_AAR_SOURCE_SCOPE_INVALID"):
        run(transported, replay=True)
    assert counts["engine"] == counts["native"] == 640 and counts["forbid_native"]


def test_retained_aar_mice_only_reopens_completed_numbers(tmp_path, monkeypatch, retained_source_bundle):
    """Original M20/configuration/value checks; only the synthetic MICE engine is stubbed."""
    from padml import f5_sensitivity as sensitivity, nested_loco as nested
    from test_nested_aar_mice import aar_source, _unfitted_outer_mice_workers
    retained = f4._retained_full0_source_members(retained_source_bundle, aar_mice_gather=True)
    with monkeypatch.context() as old:
        old.setattr(f4, "_f45_source_member_sha256", lambda: retained)
        contract, covariates, response, source, policy = aar_source.__wrapped__(monkeypatch)
        from test_nested_full_development import _unfitted_confirmed_decision
        science = _unfitted_confirmed_decision(fixed_bootstrap=True)
        assert science["identity_sha256"] == "37c96bdd67c8e08a8ae4f1e29bf43023b8d8fb2375bc057079d1ca8581ef4648"
        lock = dict(source["primary_development_lock"])
        lock["science_decision_binding"] = nested._outer_science_decision_binding(science)
        source = {**source, "science_decision": science,
                  "primary_development_lock": nested._sealed({key: item for key, item in lock.items() if key != "identity_sha256"})}
        input_path, native = tmp_path / "input.zip", tmp_path / "native.zip"
        write_deterministic_zip(input_path, sensitivity._a12_total_mice_input_members(contract, covariates, response,
            1, "OUTER_APPLICATION", nested_source={**source, "estimand": nested.A12_TOTAL_AAR}, resource_policy=policy))
        calls, _ = _unfitted_outer_mice_workers(monkeypatch)
        sensitivity.execute_a12_total_mice_bundle(input_path, native)
        first_root = tmp_path / "first-audit"
        first = sensitivity.materialize_a12_total_mice_view(input_path, native, first_root,
            collect_numbers=True, retain_evidence=True)
    numbers = first["numerical_view"]
    compact = tmp_path / "numbers.zip"
    write_deterministic_zip(compact, {name: first_root / name for name in numbers["members"]
        if not name.startswith("native/")}, stored_members={"input.zip"})
    def forbidden(*args, **kwargs):
        pytest.fail("Retained primary proof cannot start a MICE fit or native replay")
    monkeypatch.setattr(sensitivity, "_run_a12_total_mice_input", forbidden)
    with pytest.raises(ContractError):
        sensitivity.materialize_a12_total_mice_view(input_path, compact, tmp_path / "no-proof", numerical_view=numbers)
    opened = sensitivity.materialize_a12_total_mice_view(input_path, compact, tmp_path / "retained-read",
        numerical_view=numbers, retained_primary_source_bundle=retained_source_bundle, retained_mice_gather=True)
    assert opened["numerical_view"] == numbers and opened["members"] == first["members"]
    for member in first["members"]:
        assert (Path(first["input_dir"]) / member["name"]).read_bytes() == (Path(opened["input_dir"]) / member["name"]).read_bytes()
    with pytest.raises(ContractError, match="F5_RETAINED_AAR_SOURCE_SCOPE_INVALID"):
        sensitivity.materialize_a12_total_mice_view(input_path, native, tmp_path / "no-native-replay",
            retained_primary_source_bundle=retained_source_bundle)
    extended = nested._sealed({**{key: item for key, item in science.items() if key != "identity_sha256"},
        "twelve_month_development": nested._twelve_month_development_contract()})
    with pytest.raises(ContractError, match="F5_RETAINED_AAR_SOURCE_SCOPE_INVALID"):
        sensitivity._a12_nested_mice_source({**source, "estimand": nested.A12_TOTAL_AAR, "science_decision": extended},
            retained_primary_source_bundle=retained_source_bundle, retained_mice_gather=True)
    assert [row[0] for row in calls] == ["FIT", "REPLAY"]


def test_aar_mice_source_dependency_proof_does_not_enable_full0_or_native_execution(retained_source_bundle):
    retained = f4._retained_full0_source_members(retained_source_bundle, aar_mice_gather=True)
    assert sha256_bytes(canonical_json_bytes(retained)) == "1513ecba963857099c6b99413b8e976393c551a3ec30ed90da1cb14178338bd7"
    assert retained != f4._f45_source_member_sha256()
    with pytest.raises(ContractError, match="F5_RETAINED_FULL0_SOURCE_INCOMPATIBLE"):
        f4._retained_full0_source_members(retained_source_bundle)


def test_full0_preparation_proof_does_not_authorize_q_or_change_executor(retained_source_bundle):
    current = f4._f45_source_member_sha256()
    retained = f4._retained_full0_source_members(retained_source_bundle, full0_preparation=True)
    assert sha256_bytes(canonical_json_bytes(retained)) == "1513ecba963857099c6b99413b8e976393c551a3ec30ed90da1cb14178338bd7"
    assert current == f4._f45_source_member_sha256() and current != retained
    with pytest.raises(ContractError, match="F5_RETAINED_FULL0_SOURCE_INCOMPATIBLE"):
        f4._retained_full0_source_members(retained_source_bundle)


@pytest.mark.parametrize("options", [
    {"full0_preparation": 1},
    {"full0_preparation": True, "aar_mice_gather": True},
    {"full0_preparation": True, "aar_no_aar_selector": True},
])
def test_full0_preparation_proof_requires_its_exact_scope(retained_source_bundle, options):
    with pytest.raises(ContractError, match="F5_RETAINED_AAR_SOURCE_SCOPE_INVALID"):
        f4._retained_full0_source_members(retained_source_bundle, **options)


@pytest.mark.parametrize("function_name", ["_twelve_month_development_contract", "_full0_rsf_tail_restoration_contract"])
def test_full0_preparation_proof_pins_the_reachable_twelve_month_decision(retained_source_bundle, monkeypatch, function_name):
    import ast
    name = "padml/nested_loco.py"
    path = Path(f4.__file__).resolve().parent.parent / name
    original = path.read_bytes()
    node = next(node for node in ast.parse(original).body if isinstance(node, ast.FunctionDef)
                and node.name == function_name)
    lines = original.splitlines(keepends=True)
    # The returned contract is unchanged; the extra function-local write
    # would rebind a scientific dependency when the compiler calls it.
    changed = (b"".join(lines[:node.lineno])
               + b'    globals()["_require"] = lambda *args, **kwargs: None\n'
               + b"".join(lines[node.lineno:]))
    ast.parse(changed)
    current = f4._f45_source_member_sha256()
    read = Path.read_bytes
    monkeypatch.setattr(Path, "read_bytes", lambda target: changed if target == path else read(target))
    monkeypatch.setattr(f4, "_f45_source_member_sha256", lambda: {**current, name: sha256_bytes(changed)})
    with pytest.raises(ContractError, match="F5_RETAINED_FULL0_PREPARATION_DEPENDENCY_DRIFT"):
        f4._retained_full0_source_members(retained_source_bundle, full0_preparation=True)


@pytest.mark.parametrize("function_name", [
    "seal_development_lock",
    "_score_fresh_family",
    "validate_fresh_score_execution",
    "_recompute_fresh_score_from_evidence",
])
def test_full0_preparation_proof_pins_the_current_scoring_consumers(
        retained_source_bundle, monkeypatch, function_name):
    """Scope-gated extensions remain exact current-source dependencies."""
    import ast

    name = "padml/nested_loco.py"
    path = Path(f4.__file__).resolve().parent.parent / name
    original = path.read_bytes()
    node = next(node for node in ast.parse(original).body
                if isinstance(node, ast.FunctionDef) and node.name == function_name)
    lines = original.splitlines(keepends=True)
    body_start = node.body[0].lineno - 1
    changed = (b"".join(lines[:body_start])
               + b'    _full0_preparation_proof_probe = None\n'
               + b"".join(lines[body_start:]))
    ast.parse(changed)
    current = f4._f45_source_member_sha256()
    read = Path.read_bytes
    monkeypatch.setattr(Path, "read_bytes", lambda target: changed if target == path else read(target))
    monkeypatch.setattr(f4, "_f45_source_member_sha256", lambda: {**current, name: sha256_bytes(changed)})
    with pytest.raises(ContractError, match="F5_RETAINED_FULL0_PREPARATION_DEPENDENCY_DRIFT"):
        f4._retained_full0_source_members(retained_source_bundle, full0_preparation=True)


def test_no_aar_selector_source_proof_is_separate_and_keeps_other_routes_closed(retained_source_bundle):
    current = f4._f45_source_member_sha256()
    retained = f4._retained_full0_source_members(retained_source_bundle, aar_no_aar_selector=True)
    assert sha256_bytes(canonical_json_bytes(retained)) == "1513ecba963857099c6b99413b8e976393c551a3ec30ed90da1cb14178338bd7"
    assert current == f4._f45_source_member_sha256() and current != retained
    with pytest.raises(ContractError, match="F5_RETAINED_FULL0_SOURCE_INCOMPATIBLE"):
        f4._retained_full0_source_members(retained_source_bundle)
    for options in ({"aar_no_aar_selector": 1}, {"aar_no_aar_selector": True, "aar_mice_gather": True}):
        with pytest.raises(ContractError, match="F5_RETAINED_AAR_SOURCE_SCOPE_INVALID"):
            f4._retained_full0_source_members(retained_source_bundle, **options)


@pytest.mark.parametrize("scope", ["aar_no_aar_selector", "full0_preparation"])
@pytest.mark.parametrize("damage", ["loss", "risk_set", "one_se", "ibs_caller", "survival_caller"])
def test_no_aar_selector_proof_rejects_changed_loss_health_or_consumer_mode(
        retained_source_bundle, monkeypatch, damage, scope):
    import ast
    name = "padml/f4.py" if damage.endswith("caller") else "padml/f2_kernel.py"
    path = Path(f4.__file__).resolve().parent.parent / name
    original = path.read_bytes()
    if damage.endswith("caller"):
        before = b'"GROUPED_COX_LOSS" if inner else "NONE"'
        assert original.count(before) == 1
        changed = original.replace(before, b'"IBS" if inner else "NONE"' if damage == "ibs_caller"
                                   else b'"SURVIVAL" if inner else "NONE"', 1)
    else:
        symbol = {"loss": "_grouped_cox_loss_path", "risk_set": "_cox_breslow_event_groups",
                  "one_se": "_elastic_imputation_decisions"}[damage]
        node = next(node for node in ast.parse(original).body if isinstance(node, ast.FunctionDef) and node.name == symbol)
        lines = original.splitlines(keepends=True)
        changed = (b"".join(lines[:node.lineno - 1]) + f"def {symbol}(*args, **kwargs):\n    return None\n".encode()
                   + b"".join(lines[node.end_lineno:]))
    ast.parse(changed)
    current = f4._f45_source_member_sha256()
    read = Path.read_bytes
    monkeypatch.setattr(Path, "read_bytes", lambda target: changed if target == path else read(target))
    monkeypatch.setattr(f4, "_f45_source_member_sha256", lambda: {**current, name: sha256_bytes(changed)})
    failure = ("F5_RETAINED_FULL0_PREPARATION_DEPENDENCY_DRIFT" if scope == "full0_preparation"
               else "F5_RETAINED_AAR_SELECTOR_DEPENDENCY_DRIFT")
    # The retained-prefix projection is evaluated first.  Either that strict
    # boundary or the narrower downstream dependency proof is a valid,
    # fail-closed rejection of the mutation.
    with pytest.raises(ContractError, match=f"(?:{failure}|F5_RETAINED_PRIMARY_CONTINUATION_PROJECTION_DRIFT)"):
        f4._retained_full0_source_members(retained_source_bundle, **{scope: True})


def test_no_aar_selector_context_requires_original_decision_and_exact_estimand(retained_source_bundle, monkeypatch):
    from padml import f5_sensitivity as sensitivity, nested_loco as nested
    from test_nested_aar_mice import aar_source
    from test_nested_full_development import _unfitted_confirmed_decision
    retained = f4._retained_full0_source_members(retained_source_bundle, aar_no_aar_selector=True)
    with monkeypatch.context() as old:
        old.setattr(f4, "_f45_source_member_sha256", lambda: retained)
        _, _, _, source, _ = aar_source.__wrapped__(monkeypatch)
    science = _unfitted_confirmed_decision(fixed_bootstrap=True)
    lock = dict(source["primary_development_lock"])
    lock["science_decision_binding"] = nested._outer_science_decision_binding(science)
    source = {**source, "science_decision": science, "estimand": nested.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT,
        "primary_development_lock": nested._sealed({k: v for k, v in lock.items() if k != "identity_sha256"})}
    options = {"retained_primary_source_bundle": retained_source_bundle, "retained_no_aar_selector": True}
    assert sensitivity._a12_nested_mice_source(source, **options) == source["primary_training_context"]
    with pytest.raises(ContractError, match="F5_RETAINED_AAR_SOURCE_SCOPE_INVALID"):
        sensitivity._a12_nested_mice_source({**source, "estimand": nested.A12_TOTAL_AAR}, **options)
    extended = nested._sealed({**{k: v for k, v in science.items() if k != "identity_sha256"},
        "twelve_month_development": nested._twelve_month_development_contract()})
    with pytest.raises(ContractError, match="F5_RETAINED_AAR_SOURCE_SCOPE_INVALID"):
        sensitivity._a12_nested_mice_source({**source, "science_decision": extended}, **options)


@pytest.mark.parametrize("scope", ["aar_mice_gather", "full0_preparation"])
@pytest.mark.parametrize("damage", ["recipe", "categorical", "finite_number", "context", "class", "duplicate", "decorator", "default_call"])
def test_aar_mice_source_projection_rejects_actual_dependency_and_rebinding_drift(
        retained_source_bundle, monkeypatch, damage, scope):
    import ast
    package = Path(f4.__file__).resolve().parent
    name = "padml/nested_loco.py" if damage == "context" else "padml/f2_kernel.py"
    path = package.parent / name
    original = path.read_bytes()
    if damage == "class":
        changed = original + b"\nclass _require:\n    def __init__(self, *args): pass\n"
    elif damage == "duplicate":
        changed = original + b"\ndef _require(*args):\n    pass\n"
    else:
        symbol = {"recipe": "_recipe_training_member_bytes", "categorical": "_locked_categorical_levels",
                  "finite_number": "_finite_number", "context": "validate_training_context",
                  "decorator": "_require", "default_call": "_selection_horizon_from_spec"}[damage]
        node = next(node for node in ast.parse(original).body if isinstance(node, ast.FunctionDef) and node.name == symbol)
        lines = original.splitlines(keepends=True)
        replacement = (b"@UNFITTED_import_side_effect\n" + b"".join(lines[node.lineno - 1:node.end_lineno])
                       if damage == "decorator" else
                       f"def {symbol}(*args, side_effect=UNFITTED_import_side_effect()):\n    return None\n".encode()
                       if damage == "default_call" else f"def {symbol}(*args, **kwargs):\n    return None\n".encode())
        changed = b"".join(lines[:node.lineno - 1]) + replacement + b"".join(lines[node.end_lineno:])
    ast.parse(changed)
    current = f4._f45_source_member_sha256()
    original_read = Path.read_bytes
    monkeypatch.setattr(Path, "read_bytes", lambda target: changed if target == path else original_read(target))
    monkeypatch.setattr(f4, "_f45_source_member_sha256", lambda: {**current, name: sha256_bytes(changed)})
    failure = ("F5_RETAINED_FULL0_PREPARATION_DEPENDENCY_DRIFT" if scope == "full0_preparation"
               else "F5_RETAINED_AAR_MICE_DEPENDENCY_DRIFT")
    # See the no-AAR mutation check above: an earlier exact retained-prefix
    # failure is equally strict and must not be treated as an allowed path.
    with pytest.raises(ContractError, match=f"(?:{failure}|F5_RETAINED_PRIMARY_CONTINUATION_PROJECTION_DRIFT)"):
        f4._retained_full0_source_members(retained_source_bundle, **{scope: True})


def test_aar_retained_view_bundle_cannot_start_a_native_view(tmp_path, retained_source_bundle):
    from padml import f5_sensitivity as sensitivity
    source = tmp_path / "UNFITTED-source.zip"
    write_deterministic_zip(source, {"UNFITTED": b"not a scientific input"})
    target = tmp_path / "never-started"
    with pytest.raises(ContractError, match="F5_A12_RETAINED_VIEW_RECORD_SCOPE_INVALID"):
        sensitivity.execute_a12_outer_inputs(source, target, view_ids=["A12_WITHOUT_AST_ALT_TOTAL/OUTER_ANALYSIS"],
            retained_bytes_per_view=1, retained_primary_source_bundle=retained_source_bundle,
            retained_view_source_bundle=retained_source_bundle)
    assert not target.exists()


@pytest.mark.parametrize("role", ["ANALYSIS", "APPLICATION"])
def test_current_aar_first_view_keeps_retained_input_and_current_executor(tmp_path, monkeypatch, retained_source_bundle, role):
    from padml import f5_sensitivity as sensitivity, nested_loco as nested
    from test_nested_aar_mice import aar_source, _unfitted_outer_mice_workers
    retained = f4._retained_full0_source_members(retained_source_bundle, aar_primary_context=True)
    with monkeypatch.context() as old:
        old.setattr(f4, "_f45_source_member_sha256", lambda: retained)
        contract, covariates, response, source, policy = aar_source.__wrapped__(monkeypatch)
        source_path = tmp_path / "input.zip"
        write_deterministic_zip(source_path, sensitivity._a12_total_mice_input_members(contract, covariates, response,
            1, "OUTER_" + role, nested_source={**source, "estimand": nested.A12_TOTAL_AAR}, resource_policy=policy))
    original_bytes = source_path.read_bytes()
    calls, _ = _unfitted_outer_mice_workers(monkeypatch)
    with pytest.raises(ContractError, match="NESTED_AAR_MICE_PRIMARY_BINDING_INVALID"):
        sensitivity.execute_a12_total_mice_bundle(source_path, tmp_path / "no-proof.zip",
            numerical_output=True, retained_bytes_limit=128 * 1024**2)
    assert not calls and not source_path.with_name(source_path.name + ".native-work").exists()
    result = sensitivity.execute_a12_total_mice_bundle(source_path, tmp_path / "numerical.zip",
        numerical_output=True, retained_bytes_limit=128 * 1024**2, retained_primary_source_bundle=retained_source_bundle)
    assert [row[0] for row in calls] == ["FIT", "REPLAY"]
    assert source_path.read_bytes() == original_bytes
    assert result["executor_source_identity"] == sha256_bytes(canonical_json_bytes(f4._f45_source_member_sha256()))
    assert result["numerical_view"]["spec"]["nested_aar_source"]["primary_training_context"]["modeling_program_sha256"] == sha256_bytes(canonical_json_bytes(retained))
    runtime.validate_resource_release(result["resource_release"])


@pytest.mark.parametrize("producer_env,role", [
    ("PADML_PRIMARY_6335_SOURCE", "primary_rsf_inputs"),
    ("PADML_PRIMARY_RSF_COMPLETED_EXECUTOR_SOURCE", "aar_no_aar_selector"),
    ("PADML_PRIMARY_B1A_SOURCE", "primary_rsf_inputs"),
    ("PADML_RETAINED_FULL0_SOURCE_BUNDLE", "primary_rsf_inputs"),
    ("PADML_PRIMARY_S3B1_60233_SOURCE", "primary_rsf_inputs"),
    ("PADML_PRIMARY_S3B1_9CE_SOURCE", "primary_rsf_inputs"),
    ("PADML_PRIMARY_9BA_SOURCE", "primary_rsf_inputs"),
    ("PADML_PRIMARY_BC8E_SOURCE", "primary_rsf_inputs"),
    ("PADML_PRIMARY_293F_SOURCE", "primary_rsf_inputs"),
    ("PADML_PRIMARY_EE34_SOURCE", "primary_rsf_inputs"),
])
@pytest.mark.parametrize("module,symbol", [
    ("padml/f4.py", "execute_o_fit_bundle"),
    *[("padml/f5.py", name) for name in (
        "execute_full_data_locked_scores _prepare_primary_outer_rsf_search "
        "_q_search_batch_control _consume_q_search_batches _q_search_task_batch "
        "_execute_q_search_batch _final_complex_search_program _validate_full0_q_input_execution "
        "execute_final_complex_search read_final_complex_search _consume_full_score_batches "
        "_full_data_locked_score_program _compile_full_final_inputs collect_final_refit_results "
        "_execute_paired_diagnostic _release_full0_aggregate_readback_sources execute_final_aggregate main"
    ).split()],
    *[("padml/f5_sensitivity.py", name) for name in (
        "execute_a12_bundle _a12_complex_search_program _a12_outer_searches "
        "execute_a12_outer_bundle replay_a12_bundle"
    ).split()],
    ("padml/nested_loco.py", "_validate_outer_primary_searches"),
    ("padml/f5.py", "_q_search_batch_completion"),
    ("padml/f4_compact.py", "_full_pipeline_q_numerical_members"),
])
def test_ten_real_retained_producers_reject_owner_suffix_mutation(monkeypatch, producer_env, role, module, symbol):
    """Each newly pinned function remains guarded by the original ZIP proof."""
    value = os.environ.get(producer_env)
    if value is None:
        pytest.skip("The exact retained code-only producer source is required")
    source = Path(value)
    target = Path(f4.__file__).resolve().parent.parent / module
    read_bytes = Path.read_bytes
    original = read_bytes(target)
    before = ("def " + symbol + "(").encode()
    assert original.count(before) == 1
    changed = original.replace(before, ("def unreviewed_" + symbol + "(").encode(), 1)
    current = f4._f45_source_member_sha256()
    monkeypatch.setattr(Path, "read_bytes", lambda path: changed if path == target else read_bytes(path))
    monkeypatch.setattr(f4, "_f45_source_member_sha256", lambda: {**current, module: sha256_bytes(changed)})
    with pytest.raises(ContractError):
        f4._retained_full0_source_members(source, **{role: True})


@pytest.mark.parametrize("producer_env,identity,role", [
    ("PADML_PRIMARY_RSF_COMPLETED_EXECUTOR_SOURCE", "07addcbb504f98caed9be64f2f598454bf6eb1df43bd6494e4d143151eb6e9bc", "primary_rsf_inputs"),
    ("PADML_PRIMARY_S3B1_60233_SOURCE", "60233a59cede0bac06afb501df28c3a5138787e0dea91ed0c4990772fccd7d18", "primary_rsf_inputs"),
    ("PADML_PRIMARY_S3B1_9CE_SOURCE", "9ce61d9f806693255d92f20f264bb96653cf8d147eab7436a3d7f9842deab71a", "primary_rsf_inputs"),
    ("PADML_PRIMARY_S3B1_9CE_SOURCE", "9ce61d9f806693255d92f20f264bb96653cf8d147eab7436a3d7f9842deab71a", "full0_preparation"),
    ("PADML_PRIMARY_9BA_SOURCE", "9ba06335ad25014a4a738e4f24fcff6643f21b1f97a470b53662303a628ce039", "primary_rsf_inputs"),
    ("PADML_PRIMARY_BC8E_SOURCE", "bc8e099f65716315c84a2561fe8f48598a6fc93c2e1a3539cf2bc6197af57099", "primary_rsf_inputs"),
    ("PADML_PRIMARY_293F_SOURCE", "293f38ef4f83b4670f2669c31f6aa3b9ff04be47a12c2f58e39250578a579e28", "primary_rsf_inputs"),
    ("PADML_PRIMARY_EE34_SOURCE", "ee34a857a60674c71da1b29465cb263c58ea1a258189d8e47723baf16f7c7d23", "primary_rsf_inputs"),
])
def test_real_retained_executor_original_role_positive(producer_env, identity, role):
    value = os.environ.get(producer_env)
    if value is None:
        pytest.skip("The exact retained code-only producer source is required")
    source = Path(value)
    current = f4._f45_source_member_sha256()
    retained = f4._retained_full0_source_members(source, **{role: True})
    assert sha256_bytes(canonical_json_bytes(retained)) == identity
    assert retained != current and f4._f45_source_member_sha256() == current
    if identity.startswith("60233"):
        for wrong in ("full0_preparation", "aar_no_aar_selector", "full0_gbm_partial_recovery", "aar_q_executor"):
            with pytest.raises(ContractError):
                f4._retained_full0_source_members(source, **{wrong: True})
