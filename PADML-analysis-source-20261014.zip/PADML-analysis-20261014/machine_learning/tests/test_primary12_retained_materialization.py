"""UNFITTED byte-reuse tests; no clinical data, MICE, fitting or scoring."""
import copy
from pathlib import Path

import pytest

from padml import f2_kernel as kernel, f4
from padml.bundle import ContractError, sha256_file
from test_o_fit_compile_resources import _f1_fold_fixture


def test_retained_primary12_complete_source_proof(monkeypatch):
    source = Path(__file__).parents[1] / "retained01723.zip"
    observed = f4._retained_full0_source_members(source, primary_rsf_inputs=True)
    assert len(observed) == 49
    for options in ({"primary_rsf_inputs": 1},
                    {"primary_rsf_inputs": True, "aar_primary_context": True}):
        with pytest.raises(ContractError):
            f4._retained_full0_source_members(source, **options)
    actual = f4._f45_source_member_sha256()
    monkeypatch.setattr(f4, "_f45_source_member_sha256",
                        lambda: {**actual, "padml/runtime.py": "0" * 64})
    with pytest.raises(ContractError):
        f4._retained_full0_source_members(source, primary_rsf_inputs=True)


def test_retained_remaining_primary12_complete_source_proof(monkeypatch):
    source = Path(__file__).parents[1] / "retained9ba.zip"
    observed = f4._retained_full0_source_members(source, primary_rsf_inputs=True)
    assert len(observed) == 49
    for options in ({"primary_rsf_inputs": 1},
                    {"primary_rsf_inputs": True, "aar_primary_context": True}):
        with pytest.raises(ContractError):
            f4._retained_full0_source_members(source, **options)
    actual = f4._f45_source_member_sha256()
    monkeypatch.setattr(f4, "_f45_source_member_sha256",
                        lambda: {**actual, "padml/runtime.py": "0" * 64})
    with pytest.raises(ContractError):
        f4._retained_full0_source_members(source, primary_rsf_inputs=True)


def _retained(tmp_path, monkeypatch):
    frozen = _f1_fold_fixture(tmp_path / "UNFITTED-F1")
    # The tiny fixture now covers each application row in a center training
    # subset, as real leave-center-out diagnostics do. No new view is generated.
    centers = frozen["binding_contract"]["registry"]["center_stress"]
    centers[-1]["analysis_ids"], centers[-1]["validation_ids"] = ["b"], ["a"]
    # The fixture's F1 source binds its original contract; only its synthetic
    # admission adapter supplies the adjusted registry to the real materializer.
    original_admit = kernel.admitted_f1_fold
    original_contract = copy.deepcopy(frozen["binding_contract"])
    original_contract["registry"]["center_stress"][-1].update(analysis_ids=["a"], validation_ids=["b"])
    def admitted(*args, **kwargs):
        args = list(args)
        args[4] = original_contract
        return original_admit(*args, **kwargs)
    monkeypatch.setattr(kernel, "admitted_f1_fold", admitted)
    target = tmp_path / "retained"
    registered = f4._materialize_o_fit_fold(frozen, 1, target)
    expected = {"fold": 1, "registered_input_identity": registered["identity"],
        "model_partitions": [kernel._registered_partition_identity_record(row) for row in registered["partitions"]],
        "diagnostic_partitions": [kernel._registered_partition_identity_record(row) for row in registered["diagnostic_partitions"]]}
    # Exercise original byte identities, not the full F2 authorization schema.
    # Production retains the real validate_expected_model_input call unchanged.
    monkeypatch.setattr(kernel, "validate_expected_model_input", lambda value: value)
    frozen["models"] = {(1, "RSF"): {"model_input": expected}}
    def forbidden(*args, **kwargs):
        raise AssertionError("retained read must not reopen or merge F1 views")
    monkeypatch.setattr(kernel, "admitted_f1_fold", forbidden)
    monkeypatch.setattr(kernel, "_load_f1_view_library", forbidden)
    monkeypatch.setattr(kernel, "_materialize_application_subset", forbidden)
    return frozen, target, registered


def test_retained_original_materializer_is_exact_read_only(tmp_path, monkeypatch):
    frozen, target, registered = _retained(tmp_path, monkeypatch)
    before = {str(p.relative_to(target)): (sha256_file(p), p.stat().st_mtime_ns)
              for p in target.rglob("*") if p.is_file()}
    calls = []
    observed = f4._materialize_o_fit_fold(frozen, 1, target, reuse_existing=True,
                                         admit_io=lambda **value: calls.append(value))
    assert observed == registered
    assert len(before) == 676
    assert before == {str(p.relative_to(target)): (sha256_file(p), p.stat().st_mtime_ns)
                      for p in target.rglob("*") if p.is_file()}
    assert calls and all(set(call) == {"memory_bytes"} for call in calls)


@pytest.mark.parametrize("damage", ["covariate", "center-row", "response", "missing", "extra",
                                   "symlink", "identity", "coverage"])
def test_retained_original_materializer_rejects_damage(tmp_path, monkeypatch, damage):
    frozen, target, registered = _retained(tmp_path, monkeypatch)
    part = registered["partitions"][0]
    csv = Path(part["covariates"]["input_dir"]) / "imp01.csv"
    if damage == "covariate": csv.write_bytes(csv.read_bytes().replace(b",50", b",51"))
    elif damage == "center-row":
        path = target / "registered/partitions/CENTER_STRESS_COVARIATES/imp01.csv"
        path.write_bytes(path.read_bytes().replace(b"b,36,99", b"b,36,98"))
    elif damage == "response": Path(part["fit_response"]["path"]).write_bytes(b"invalid\n")
    elif damage == "missing": csv.unlink()
    elif damage == "extra": (target / "registered/extra.csv").write_bytes(b"unexpected\n")
    elif damage == "symlink":
        original = target / "original.csv"
        csv.rename(original)
        csv.symlink_to(original)
    elif damage == "identity": frozen["models"][1, "RSF"]["model_input"]["registered_input_identity"] = "0" * 64
    else: frozen["binding_contract"]["registry"]["center_stress"][-1].update(analysis_ids=["a"], validation_ids=["b"])
    with pytest.raises(ContractError):
        f4._materialize_o_fit_fold(frozen, 1, target, reuse_existing=True)
