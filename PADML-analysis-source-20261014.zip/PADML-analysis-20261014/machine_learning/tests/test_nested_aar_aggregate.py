"""Six-fold pairing/B1000 routing plus one synthetic native point-metric fixture."""
import copy
import math
import json
import io
import pickle
import sys
from pathlib import Path
from types import SimpleNamespace

import pytest

from padml import bundle, f4, f5, f5_sensitivity as sensitivity, nested_loco as nested, runtime
from padml.bundle import ContractError, canonical_json_bytes, read_safe_zip, sha256_bytes, sha256_file, strict_json_bytes, write_deterministic_zip
from test_nested_loco import _response, _six_outer_fixture
from test_nested_full_development import _unfitted_confirmed_decision


def _unfitted_six_aar():
    predictions, registry = _six_outer_fixture()
    primary = nested.assemble_selected_ooc(predictions, population_registry=registry)
    science = _unfitted_confirmed_decision(fixed_bootstrap=True)
    records = [{"outer_fold": i, "sha256": sha256_bytes(f"UNFITTED-primary-{i}".encode())} for i in range(1, 7)]
    input_hashes = {str(i): sha256_bytes(f"UNFITTED-input-{i}".encode()) for i in range(1, 7)}
    context = {"primary": primary, "population_registry": registry, "science_decision": science,
        "family_by_outer": {str(row["outer_fold"]): row["selected_family"] for row in primary["selection_by_outer"]},
        "source": {"primary_source_archives": records, "primary_input_sha256": input_hashes},
        "frozen": {"response_csv": _response(registry["all_patient_ids"])}}
    outers = []
    for selection, partition in zip(primary["selection_by_outer"], registry["outer"], strict=True):
        outer = selection["outer_fold"]
        source = {"kind": "PADML_F5_A12_PROJECTED_OUTER_INPUTS_V1", "primary_archive_sha256": records[outer - 1]["sha256"],
            "primary_input_sha256": input_hashes[str(outer)], "primary_source": {"science_decision": science,
                "primary_development_lock": {"identity_sha256": selection["development_lock_sha256"]},
                "primary_training_context": {name: partition[name] for name in ("training_ids", "heldout_ids", "heldout_center")}}}
        outers.append({"kind": "PADML_F5_A12_OUTER_NATIVE_V2", "outer_fold": outer, "family": selection["selected_family"],
            "identity_sha256": sha256_bytes(f"UNFITTED-AAR-{outer}".encode()), "source": source,
            "predictions": {"patient_ids": partition["heldout_ids"], "centers": [str(partition["heldout_center"])] * 6,
                "horizons": f4.HORIZONS, "survival": {branch: [[1.0] + [.70 + index * .01 + outer * .001] * 36
                    for _ in partition["heldout_ids"]] for index, branch in enumerate(nested.AAR_ESTIMANDS)}},
            "members": {f"fits/O{outer}_{branch}_M{imp:02d}.numbers.json": {"UNFITTED": True, "imputation": imp}
                        for branch in nested.AAR_ESTIMANDS for imp in range(1, 21)},
            "native_members": {f"fits/O{outer}_{branch}_M{imp:02d}.zip": {"UNFITTED": True, "imputation": imp}
                        for branch in nested.AAR_ESTIMANDS for imp in range(1, 21)}})
    fields, responses = f5._response_rows(context["frozen"]["response_csv"])
    evaluation_response = f5._write_response_subset(fields, responses, primary["patient_ids"], None)["private_bytes"]
    selected = {name: primary[name] for name in ("patient_ids", "centers", "horizons")}
    selected["survival"] = {"NESTED_SELECTED_POLICY": primary["survival"]["NESTED_SELECTED_POLICY"]}
    context.update(evaluation_response_csv=evaluation_response,
        primary_point=nested._sealed({"schema_version": nested.SCHEMA_VERSION,
            "kind": "PADML_NESTED_LOCO_SELECTED_POLICY_EVALUATION_V1",
            "status": "COMPUTED_NOT_EXTERNAL_VALIDATION_OF_FULL_DATA_MODEL",
            "selected_ooc_sha256": primary["identity_sha256"], "heldout_response_sha256": sha256_bytes(evaluation_response),
            "outcome_join_location": "H7_ORIGINAL_F4_F5_EVALUATION_NOT_ACCEPTANCE",
            "evaluation": _unfitted_evaluation(selected), "full_data_final_model_external_validation": False}),
        primary_point_native=canonical_json_bytes({"UNFITTED": True,
            "handoff_sha256": sha256_bytes(canonical_json_bytes(selected)), "response_sha256": sha256_bytes(evaluation_response)}))
    return context, outers


@pytest.mark.parametrize("damage", [None, "outer-horizon", "outer-science", "primary-science", "authority"])
def test_twelve_month_aar_handoff_keeps_own_horizon_and_rejects_cross_line(damage):
    context, outers = _unfitted_six_aar()
    science = nested._sealed({**{k: v for k, v in context["science_decision"].items()
                                if k != "identity_sha256"},
                             "twelve_month_development": nested._twelve_month_development_contract()})
    context["science_decision"] = science
    context["primary"] = nested._sealed({**{k: v for k, v in context["primary"].items()
                                           if k != "identity_sha256"},
        "selection_horizon_months": 12,
        "science_decision_sha256": "f" * 64 if damage == "primary-science" else science["identity_sha256"]})
    for row in outers:
        source = row["source"]["primary_source"]
        source["science_decision"] = science
        source["primary_development_lock"].update(selection_horizon_months=12,
            science_decision_binding={"science_decision_sha256": science["identity_sha256"]})
    if damage == "outer-horizon":
        del outers[2]["source"]["primary_source"]["primary_development_lock"]["selection_horizon_months"]
    if damage == "outer-science":
        outers[2]["source"]["primary_source"]["primary_development_lock"]["science_decision_binding"]["science_decision_sha256"] = "e" * 64
    if damage == "authority":
        context["science_decision"] = _unfitted_confirmed_decision(fixed_bootstrap=True)
    if damage:
        with pytest.raises(ContractError):
            sensitivity._a12_handoff_from_outers(context, outers)
        return
    handoff = sensitivity._a12_handoff_from_outers(context, outers)
    opened = sensitivity._validate_a12_handoff(handoff)
    assert opened["selection_horizon_months"] == 12 and opened["science_decision"] == science
    assert opened["patient_ids"] == context["primary"]["patient_ids"]
    assert opened["survival"]["PRIMARY"] == context["primary"]["survival"]["NESTED_SELECTED_POLICY"]
    # The direct reader must reject a different decision even after alignment.
    handoff["science_decision"] = _unfitted_confirmed_decision(fixed_bootstrap=True)
    with pytest.raises(ContractError, match="HORIZON_SOURCE_INVALID"):
        sensitivity._validate_a12_handoff(handoff)


def test_six_aar_pairing_keeps_canonical_patients_local_families_and_three_estimands():
    context, outers = _unfitted_six_aar()
    untouched = copy.deepcopy([context, outers])
    handoff = sensitivity._a12_handoff_from_outers(context, outers)
    opened = sensitivity._validate_a12_handoff(strict_json_bytes(canonical_json_bytes(handoff)))
    assert opened["patient_ids"] == context["population_registry"]["evaluation_patient_ids"]
    assert "55" not in opened["centers"] and len(set(opened["family_by_outer"].values())) == 6
    assert list(opened["survival"]) == ["PRIMARY", *nested.AAR_ESTIMANDS]
    for patient_index, center in enumerate(opened["centers"]):
        outer = nested.OUTER_CENTERS.index(int(center)) + 1
        for index, branch in enumerate(nested.AAR_ESTIMANDS):
            assert opened["survival"][branch][patient_index][24] == .70 + index * .01 + outer * .001
    assert opened["branch_provenance"][-1]["estimand_contract"]["label"] == nested.WITHIN_FAMILY_NO_AAR_LABEL
    assert [context, outers] == untouched


@pytest.mark.parametrize("horizon", [24, 12])
@pytest.mark.parametrize("damage", [None, "horizon", "decision"])
def test_primary_point_reader_preserves_own_evaluation_scope(monkeypatch, horizon, damage):
    context, outers = _unfitted_six_aar()
    handoff = sensitivity._validate_a12_handoff(sensitivity._a12_handoff_from_outers(context, outers))
    point = copy.deepcopy(context["primary_point"])
    options = {}
    if horizon == 12:
        science = nested._sealed({**{k: v for k, v in handoff["science_decision"].items() if k != "identity_sha256"},
            "twelve_month_development": nested._twelve_month_development_contract()})
        handoff.update(selection_horizon_months=12, science_decision=science)
        point.update(selection_horizon_months=12, science_decision_sha256=science["identity_sha256"])
        options = {"selection_horizon_months": 12, "science_decision": science}
    if damage == "horizon":
        point["selection_horizon_months"] = 24 if horizon == 12 else 12
    if damage == "decision":
        point["science_decision_sha256"] = "e" * 64
    point = nested._sealed({k: v for k, v in point.items() if k != "identity_sha256"})
    seen = []
    def read(evaluation, selected, response, **kwargs):
        assert kwargs == {"native_archive": context["primary_point_native"],
            "point_branch_scope": "PRIMARY_ORIGIN", "admit_io": None, **options}
        assert tuple(selected["survival"]) == ("NESTED_SELECTED_POLICY",)
        assert response == context["evaluation_response_csv"]
        seen.append(evaluation)
    monkeypatch.setattr(sensitivity, "_validate_a12_native_evaluation", read)
    if damage:
        with pytest.raises(ContractError, match="PRIMARY_POINT_SOURCE_INVALID"):
            sensitivity._a12_primary_point_origin(handoff, context["evaluation_response_csv"], point,
                context["primary_point_native"])
        assert seen == []
    else:
        assert sensitivity._a12_primary_point_origin(handoff, context["evaluation_response_csv"], point,
            context["primary_point_native"]) == point["evaluation"]
        assert seen == [point["evaluation"]]


@pytest.mark.parametrize("damage", ["missing_outer", "patient", "family", "primary_lock", "primary_archive", "primary_input", "decision"])
def test_six_aar_pairing_rejects_primary_source_and_denominator_drift(damage):
    context, outers = _unfitted_six_aar()
    bad = copy.deepcopy(outers)
    if damage == "missing_outer":
        bad.pop()
    elif damage == "patient":
        bad[0]["predictions"]["patient_ids"] = list(reversed(bad[0]["predictions"]["patient_ids"]))
    elif damage == "family":
        bad[0]["family"] = "RSF"
    elif damage == "primary_lock":
        bad[0]["source"]["primary_source"]["primary_development_lock"]["identity_sha256"] = "f" * 64
    elif damage == "decision":
        bad[0]["source"]["primary_source"]["science_decision"] = _unfitted_confirmed_decision()
    else:
        bad[0]["source"][damage + "_sha256"] = "f" * 64
    with pytest.raises(ContractError):
        sensitivity._a12_handoff_from_outers(context, bad)


def _unfitted_evaluation(selected, *, selection_horizon_months=24, science_decision=None):
    """Metric-shaped values to test routing/reduction, not outcome estimates."""
    def metrics(indices):
        values = {}
        for branch, matrix in selected["survival"].items():
            value = math.fsum(matrix[i][24] for i in indices) / len(indices)
            values[branch] = {"ibs_0_to": {str(h): value for h in f4.REPORT_HORIZONS}, "brier_monthly": [value] * 37,
                "discrimination": {f"uno_c_{selection_horizon_months}": {"value": value}, "auc": {str(h): {"value": value} for h in f4.REPORT_HORIZONS}},
                "calibration": {"horizons": {str(h): {name: value for name in ("slope", "citl", "oe", "ici", "e50", "e90")}
                    for h in f4.REPORT_HORIZONS}}, f"dca_{selection_horizon_months}": {"integrated_raw_nb": value}}
        return values
    scopes = [{"scope": "MICRO", "families": metrics(range(len(selected["patient_ids"])))}]
    scopes.extend({"scope": center, "families": metrics([i for i, current in enumerate(selected["centers"]) if current == center])}
                  for center in sensitivity._VALIDATION_CENTERS)
    macro = {}
    for branch in selected["survival"]:
        value = math.fsum(row["families"][branch]["ibs_0_to"]["24"] for row in scopes[1:]) / 6
        macro[branch] = {str(h): {"equal_center_ibs": value, "equal_center_brier": value, "equal_center_auc": value,
            "mean_absolute_slope_error": abs(value - 1), "mean_absolute_citl": abs(value), "equal_center_oe": value,
            "equal_center_ici": value, "equal_center_e50": value, "equal_center_e90": value,
            **({"equal_center_uno_c": value, "equal_center_raw_dca": value} if h == selection_horizon_months else {})} for h in f4.REPORT_HORIZONS}
    return {"UNFITTED_METRICS": True, "model_refit_count": 0, "scopes": scopes, "macro": macro,
        **({"selection_horizon_months": 12, "science_decision_sha256": science_decision["identity_sha256"]}
           if selection_horizon_months == 12 else {})}


@pytest.mark.parametrize("horizon", [12, 24])
@pytest.mark.parametrize("missing", [False, True])
def test_bootstrap_delta_reader_uses_declared_horizon_without_fallback(horizon, missing):
    context, outers = _unfitted_six_aar()
    opened = sensitivity._validate_a12_handoff(sensitivity._a12_handoff_from_outers(context, outers))
    evaluation = _unfitted_evaluation(opened)
    branches = ("PRIMARY", *nested.AAR_ESTIMANDS)
    if horizon == 12:
        evaluation["selection_horizon_months"] = 12
        for scope in evaluation["scopes"]:
            for index, branch in enumerate(branches):
                scope["families"][branch]["discrimination"]["uno_c_12"] = {"value": .2 + index * .1}
                scope["families"][branch]["dca_12"] = {"integrated_raw_nb": .05 + index * .02}
        for index, branch in enumerate(branches):
            evaluation["macro"][branch]["12"].update(equal_center_uno_c=.2 + index * .1,
                equal_center_raw_dca=.05 + index * .02)
    if missing:
        del evaluation["scopes"][0]["families"]["PRIMARY"]["discrimination"][f"uno_c_{horizon}"]
        with pytest.raises(ContractError, match="METRIC_SCHEMA_INVALID"):
            sensitivity._a12_bootstrap_row(7, {"UNFITTED": True}, evaluation, branches=branches)
        return
    result = sensitivity._a12_bootstrap_row(7, {"UNFITTED": True}, evaluation, branches=branches)
    assert result["replicate"] == 7 and result["receipt"] == {"UNFITTED": True}
    for index, branch in enumerate(branches[1:], 1):
        point = result["scope_deltas"]["MICRO"][branch]
        macro = result["macro_deltas"][branch]
        assert len(point) == len(macro) == len(sensitivity._A12_POINT_METRICS)
        assert f"uno_c_{36 - horizon}" not in point
        assert all(f"ibs_0_{h}" in point for h in f4.REPORT_HORIZONS)
        if horizon == 12:
            assert point["uno_c_12"] == pytest.approx(index * .1)
            assert point["integrated_raw_net_benefit_12"] == pytest.approx(index * .02)
            assert macro["equal_center_uno_c_12"] == point["uno_c_12"]
        else:
            assert set(point) == set(sensitivity._A12_POINT_METRICS)
            assert set(macro) == set(sensitivity._A12_MACRO_METRICS)


@pytest.mark.parametrize("horizon,damage", [(24, None), (12, None), (12, "metric"), (12, "ids"), (12, "point")])
def test_global_bootstrap_reduction_uses_full_own_line_metrics(horizon, damage):
    context, outers = _unfitted_six_aar()
    handoff = sensitivity._validate_a12_handoff(sensitivity._a12_handoff_from_outers(context, outers))
    evaluation = _unfitted_evaluation(handoff)
    branches = ("PRIMARY", *nested.AAR_ESTIMANDS)
    if horizon == 12:
        science = nested._sealed({**{k: v for k, v in handoff["science_decision"].items() if k != "identity_sha256"},
            "twelve_month_development": nested._twelve_month_development_contract()})
        handoff.update(selection_horizon_months=12, science_decision=science)
        evaluation.update(selection_horizon_months=12, science_decision_sha256=science["identity_sha256"])
        for scope in evaluation["scopes"]:
            for row in scope["families"].values():
                row["discrimination"]["uno_c_12"] = row["discrimination"].pop("uno_c_24")
                row["dca_12"] = row.pop("dca_24")
        for row in evaluation["macro"].values():
            row["12"].update({key: row["24"].pop(key) for key in ("equal_center_uno_c", "equal_center_raw_dca")})
    template = sensitivity._a12_bootstrap_row(1, {"UNFITTED": True}, evaluation, branches=branches)
    rows = [dict(template, replicate=rid,
        macro_deltas={branch: {metric: (rid - 1) / 10000 for metric in values}
                      for branch, values in template["macro_deltas"].items()}) for rid in range(1, 1001)]
    if damage == "metric":
        values = rows[-1]["macro_deltas"][branches[1]]
        values["equal_center_uno_c_24"] = values.pop("equal_center_uno_c_12")
    if damage == "ids": rows[-1]["replicate"] = 999
    if damage == "point": evaluation["science_decision_sha256"] = "e" * 64
    plan = {"replicate_count": 1000, "root_seed": 700000001,
            "rng": ["L'Ecuyer-CMRG", "Inversion", "Rejection"], "draws": ["UNFITTED_NO_RNG"] * 1000}
    if damage:
        with pytest.raises(ContractError):
            sensitivity._reduce_a12_incremental_value(handoff, plan, evaluation, rows, formal=False)
        return
    result = sensitivity._reduce_a12_incremental_value(handoff, plan, evaluation, rows, formal=False)
    assert result.get("selection_horizon_months", 24) == horizon
    assert result["model_fit_count"] == 0 and result["stage_acceptance"] is False
    assert f"uno_c_{horizon}" in result["bootstrap"]["metrics"]["scope"]
    assert f"uno_c_{36 - horizon}" not in result["bootstrap"]["metrics"]["scope"]
    target, = [row for row in result["bootstrap"]["paired_rows"]
               if row["branch"] == branches[1] and row["metric"] == f"equal_center_uno_c_{horizon}"]
    assert target["bootstrap"]["total_replicates"] == 1000
    assert target["bootstrap"]["percentile_95_ci"] == pytest.approx([24.975 / 10000, 974.025 / 10000])


def test_original_resampling_applies_one_multiplicity_to_all_four_branches(monkeypatch):
    context, outers = _unfitted_six_aar()
    opened = sensitivity._validate_a12_handoff(sensitivity._a12_handoff_from_outers(context, outers))
    handoff = {name: opened[name] for name in ("patient_ids", "centers", "survival", "horizons")}
    draw = [next(i for i, value in enumerate(handoff["centers"]) if value == center) for center in sensitivity._VALIDATION_CENTERS for _ in range(6)]
    seen = []
    def evaluate(selected, response):
        seen.append(selected)
        assert len(set(selected["patient_ids"])) == 36
        for branch in handoff["survival"]:
            assert selected["survival"][branch] == [handoff["survival"][branch][i] for i in draw]
        return _unfitted_evaluation(selected)
    monkeypatch.setattr(sensitivity, "evaluate_predictions", evaluate)
    row = sensitivity._a12_bootstrap_replicate((1, draw), evaluation_handoff=handoff, response_csv=context["frozen"]["response_csv"])
    assert len(seen) == 1 and row["receipt"]["unique_source_patient_count"] == 6
    assert set(row["macro_deltas"]) == set(nested.AAR_ESTIMANDS)
    for index, branch in enumerate(nested.AAR_ESTIMANDS):
        assert row["scope_deltas"]["36"][branch]["ibs_0_24"] == pytest.approx(.70 + index * .01 + .001 - .75)


@pytest.mark.parametrize("ids", [[], [True], [0], [1001], [2, 2], [2.0], "2", (2, 997)])
def test_b1000_subset_rejects_invalid_ids_before_accessing_draws(ids):
    plan = {"replicate_count": 1000, "draws": [[i] for i in range(1000)]}
    with pytest.raises(ContractError, match="F5_A12_BOOTSTRAP_REPLICATE_IDS_INVALID"):
        sensitivity._a12_replicate_items(plan, ids)


def test_b1000_nonprefix_ids_reopen_actual_rows_without_renumbering_or_new_engines(tmp_path, monkeypatch):
    """Actual resampling/archive/delta consumers; only native metric values are UNFITTED."""
    context, outers = _unfitted_six_aar()
    opened = sensitivity._validate_a12_handoff(sensitivity._a12_handoff_from_outers(context, outers))
    handoff = {name: opened[name] for name in ("patient_ids", "centers", "horizons", "survival")}
    response = context["frozen"]["response_csv"]
    calls, _ = _unfitted_metric_engines(monkeypatch)
    first = [next(i for i, c in enumerate(handoff["centers"]) if c == center)
             for center in sensitivity._VALIDATION_CENTERS for _ in range(6)]
    second = first.copy()
    second[0] = next(i for i, c in enumerate(handoff["centers"]) if c == handoff["centers"][first[0]] and i != first[0])
    plan = {"replicate_count": 1000, "draws": [first.copy() for _ in range(1000)]}
    plan["draws"][996] = second
    items = sensitivity._a12_replicate_items(plan, [997, 2])
    assert items == [(2, first), (997, second)]
    assert items[0][1] is plan["draws"][1] and items[1][1] is plan["draws"][996]
    source = sensitivity._a12_bootstrap_binding(handoff, response, plan)
    rows = [sensitivity._a12_bootstrap_replicate(item, evaluation_handoff=handoff, response_csv=response,
        work_root=tmp_path, source_binding=source, retained_bytes_per_replicate=2 * 1024**2) for item in items]
    before = dict(calls)
    replayed = [sensitivity._replay_a12_bootstrap_replicate(item, root=tmp_path,
        evaluation_handoff=handoff, response_csv=response, source_binding=source) for item in items]
    assert replayed == rows and [row["replicate"] for row in replayed] == [2, 997]
    assert sorted(path.name for path in tmp_path.glob("replicate-*.zip")) == ["replicate-0002.zip", "replicate-0997.zip"]
    assert calls == {**before, "metric_replays": before["metric_replays"] + 2}
    assert calls["UNFITTED_RNG"] == 0 and calls["UNFITTED_METRICS"] == 2
    with pytest.raises(ContractError, match="F5_A12_RETAINED_INPUT_MISMATCH"):
        sensitivity._replay_a12_bootstrap_replicate((997, first), root=tmp_path,
            evaluation_handoff=handoff, response_csv=response, source_binding=source)
    # Renaming a retained coordinate cannot authorize assigning a new draw ID.
    write_deterministic_zip(tmp_path / "replicate-0001.zip", read_safe_zip(tmp_path / "replicate-0997.zip"),
                            stored_members={"metrics.zip"})
    with pytest.raises(ContractError, match="F5_A12_RETAINED_INPUT_MISMATCH"):
        sensitivity._replay_a12_bootstrap_replicate((1, second), root=tmp_path,
            evaluation_handoff=handoff, response_csv=response, source_binding=source)


def _unfitted_metric_engines(monkeypatch):
    calls = {"UNFITTED_RNG": 0, "UNFITTED_METRICS": 0, "metric_replays": 0}
    def rng(command, **options):
        assert Path(command[-1]).name == "f4_bootstrap.R"
        request = strict_json_bytes(options["input"])
        indices = [next(i for i, value in enumerate(request["centers"]) if value == center)
                   for center in request["center_order"] for _ in range(request["centers"].count(center))]
        calls["UNFITTED_RNG"] += 1
        output = canonical_json_bytes({
            "rng": ["L'Ecuyer-CMRG", "Inversion", "Rejection"], "r_version": "UNFITTED",
            "draws": [indices] * request["replicate_count"]})
        options["stdout"].write(output)
        options["stderr"].write(b"UNFITTED RNG transport; no R execution")
        return SimpleNamespace(returncode=0)
    def evaluate(selected, responses, *, evidence_root, native_archive, **scope):
        evidence_root.mkdir(exist_ok=True)
        value = _unfitted_evaluation(selected, **scope)
        native_archive.write_bytes(canonical_json_bytes({"UNFITTED": True,
            "handoff_sha256": sha256_bytes(canonical_json_bytes(selected)), "response_sha256": sha256_bytes(responses)}))
        calls["UNFITTED_METRICS"] += 1
        return value
    def replay(value, selected, responses, *, native_archive, point_branch_scope=None, admit_io=None, **scope):
        assert point_branch_scope in {None, "PRIMARY_ORIGIN", "THREE_AAR"}
        if point_branch_scope is not None:
            assert tuple(selected["survival"]) == (("NESTED_SELECTED_POLICY",) if point_branch_scope == "PRIMARY_ORIGIN"
                                                   else tuple(nested.AAR_ESTIMANDS))
        raw = native_archive.read_bytes() if isinstance(native_archive, Path) else native_archive
        assert strict_json_bytes(raw) == {"UNFITTED": True, "handoff_sha256": sha256_bytes(canonical_json_bytes(selected)),
                                         "response_sha256": sha256_bytes(responses)}
        assert value == _unfitted_evaluation(selected, **scope)
        calls["metric_replays"] += 1
    def serial(worker, jobs, *, selected_slots, execution_report):
        jobs = list(jobs)
        execution_report.update(status="RUNNING", configured_worker_ceiling=56, admitted_worker_ceiling=selected_slots,
            completed_task_count=0, runnable_task_count=len(jobs), engine_threads=1, actual_worker_process_peak=1)
        rows = []
        try:
            for job in jobs:
                rows.append(worker(job))
                execution_report["completed_task_count"] += 1
        except BaseException:
            execution_report["status"] = "FAILED"
            raise
        execution_report["status"] = "COMPLETED"
        return rows
    monkeypatch.setattr(f4.subprocess, "run", rng)
    monkeypatch.setattr(sensitivity, "evaluate_predictions", evaluate)
    monkeypatch.setattr(sensitivity, "_validate_a12_native_evaluation", replay)
    monkeypatch.setattr(sensitivity, "_bounded_ordered_spawn", serial)
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda root: {"effective_cpus": 64,
        "available_memory_bytes": 10**12, "scratch_available_bytes": 10**12, "scratch_root": str(root)})
    policy = {"configured_worker_ceiling": runtime.CPU_MINUS_8, "memory_bytes_per_worker": 1,
        "scratch_bytes_per_worker": 1, "memory_reserve_bytes": 0, "scratch_reserve_bytes": 0, "transfer_archive_worker_ceiling": 1000}
    return calls, policy


@pytest.mark.parametrize("scratch_budget", [None, 0])
def test_original_b1000_four_branch_archive_replay_reuses_first_rng_and_metrics(tmp_path, monkeypatch, scratch_budget):
    context, outers = _unfitted_six_aar()
    handoff = sensitivity._a12_handoff_from_outers(context, outers)
    response = context["evaluation_response_csv"]
    calls, policy = _unfitted_metric_engines(monkeypatch)
    root = tmp_path / "evaluation"
    result = sensitivity.evaluate_a12_incremental_value(handoff, response, formal=True, evidence_root=root,
        resource_policy=policy, retained_bytes_per_replicate=2 * 1024**2,
        retained_primary_point=context["primary_point"], primary_point_native=context["primary_point_native"])
    assert result["bootstrap"]["paired_row_count"] == 912 and result["bootstrap"]["replicate_count"] == 1000
    assert result["model_fit_count"] == result["grid_search_count"] == result["family_reselection_count"] == 0
    assert result["bootstrap"]["full_retraining_bootstrap_replicates"] == 0
    assert set(result["point_deltas"]) == set(nested.AAR_ESTIMANDS) and "final_family" not in result
    execution = result["evaluation_execution"]
    assert execution["execution_scratch_reserve_bytes"] == execution["effective_policy"]["scratch_reserve_bytes"] == 0
    if scratch_budget is None:
        # Synthetic original-policy receipt only, never rewriting a historical run.
        execution.pop("execution_scratch_reserve_bytes")
        execution["effective_policy"]["scratch_reserve_bytes"] = policy["scratch_reserve_bytes"] + (
            execution["resource_reservation"]["shared_draw_storage_reserved_bytes"]
            + execution["resource_reservation"]["metric_retention_reserved_bytes"])
        execution["resource_admission"] = runtime.resource_admission(execution["effective_policy"],
            execution["resource_observation"], legal_tasks=1000)
        (root / "execution.json").write_bytes(canonical_json_bytes(execution))
    assert sensitivity._replay_a12_evaluation(root, strict_json_bytes(canonical_json_bytes(handoff)), response) == result
    assert calls == {"UNFITTED_RNG": 1, "UNFITTED_METRICS": 1001, "metric_replays": 2004}
    assert (root / "primary-point-native.zip").read_bytes() == context["primary_point_native"]
    point_raw = (root / "point-evaluation.json").read_bytes()
    for changed_zero in (False, -0.0):
        altered_point = strict_json_bytes(point_raw)
        altered_point["model_refit_count"] = changed_zero
        (root / "point-evaluation.json").write_bytes(canonical_json_bytes(altered_point))
        with pytest.raises(ContractError, match="F5_A12_POINT_SOURCE_SCOPE_MISMATCH"):
            sensitivity._replay_a12_evaluation(root, handoff, response)
    (root / "point-evaluation.json").write_bytes(point_raw)
    record = strict_json_bytes((root / "plan.json").read_bytes())
    record["plan"]["draws"][0][0] += 6  # same center, different patient; still a valid count-preserving draw
    (root / "plan.json").write_bytes(canonical_json_bytes(record))
    with pytest.raises(ContractError, match="RETAINED_RNG_MISMATCH"):
        sensitivity._replay_a12_evaluation(root, handoff, response)
    assert calls["UNFITTED_RNG"] == 1 and calls["UNFITTED_METRICS"] == 1001


def test_point_reuse_validates_real_native_labels_and_keeps_primary_archive(tmp_path, monkeypatch):
    """Synthetic native metric fixture; no clinical data or prediction-model fits."""
    context, outers = _unfitted_six_aar()
    handoff = sensitivity._validate_a12_handoff(sensitivity._a12_handoff_from_outers(context, outers))
    response = context["evaluation_response_csv"]
    shared = {name: handoff[name] for name in ("patient_ids", "centers", "horizons")}
    primary = {**shared, "survival": {"NESTED_SELECTED_POLICY": handoff["survival"]["PRIMARY"]}}
    aar = {**shared, "survival": {branch: handoff["survival"][branch] for branch in nested.AAR_ESTIMANDS}}
    calls = []
    original_native = f4.native_metrics
    def native(jobs, **kwargs):
        calls.append([job["label"] for job in jobs])
        return original_native(jobs, **kwargs)
    monkeypatch.setattr(f4, "native_metrics", native)
    primary_path, aar_path = tmp_path / "primary-native.zip", tmp_path / "aar-native.zip"
    with f5._full_score_scratch(tmp_path):
        primary_value = f4.evaluate_predictions(primary, response, evidence_root=tmp_path / "primary", native_archive=primary_path)
        aar_value = f4.evaluate_predictions(aar, response, evidence_root=tmp_path / "aar", native_archive=aar_path)
    origin_bytes = primary_path.read_bytes()
    point = nested._sealed({**{key: value for key, value in context["primary_point"].items() if key != "identity_sha256"},
                            "evaluation": primary_value})
    retained = sensitivity._a12_primary_point_origin(handoff, response, point, primary_path)
    sensitivity._validate_a12_native_evaluation(aar_value, aar, response, native_archive=aar_path, point_branch_scope="THREE_AAR")
    merged = sensitivity._merge_a12_point_evaluations(retained, aar_value)
    assert [len(jobs) for jobs in calls] == [7, 21]
    assert all(label.endswith("/NESTED_SELECTED_POLICY") for label in calls[0])
    assert merged["scopes"][0]["families"]["PRIMARY"]["calibration"]["label"] == "MICRO/NESTED_SELECTED_POLICY"
    assert primary_path.read_bytes() == origin_bytes
    entries = read_safe_zip(primary_path)
    renamed = strict_json_bytes(entries["input.json"])
    renamed["jobs"][0]["label"] = "MICRO/PRIMARY"
    bad_primary = tmp_path / "renamed-primary.zip"
    write_deterministic_zip(bad_primary, {**entries, "input.json": canonical_json_bytes(renamed)})
    with pytest.raises(ContractError, match="F5_A12_FIRST_NATIVE_METRICS_MISMATCH"):
        sensitivity._a12_primary_point_origin(handoff, response, point, bad_primary)
    entries = read_safe_zip(aar_path)
    reordered = strict_json_bytes(entries["input.json"])
    reordered["jobs"] = list(reversed(reordered["jobs"]))
    bad_aar = tmp_path / "reordered-aar.zip"
    write_deterministic_zip(bad_aar, {**entries, "input.json": canonical_json_bytes(reordered)})
    with pytest.raises(ContractError, match="F5_A12_FIRST_NATIVE_METRICS_MISMATCH"):
        sensitivity._validate_a12_native_evaluation(aar_value, aar, response, native_archive=bad_aar, point_branch_scope="THREE_AAR")
    assert [len(jobs) for jobs in calls] == [7, 21]  # no R job during any readback


@pytest.mark.parametrize("damage", ["patient-count", "ipcw-qc", "scope-order"])
def test_separate_point_sources_cannot_merge_different_support(damage):
    context, outers = _unfitted_six_aar()
    handoff = sensitivity._validate_a12_handoff(sensitivity._a12_handoff_from_outers(context, outers))
    source = {**handoff, "survival": {branch: handoff["survival"][branch] for branch in nested.AAR_ESTIMANDS}}
    aar = _unfitted_evaluation(source)
    if damage == "scope-order":
        aar["scopes"].reverse()
    else:
        aar["scopes"][0]["patient_count" if damage == "patient-count" else "ipcw_qc"] = 99
    with pytest.raises(ContractError, match="F5_A12_POINT_SOURCE_SCOPE_MISMATCH"):
        sensitivity._merge_a12_point_evaluations(context["primary_point"]["evaluation"], aar)


def test_nested_point_cannot_fall_back_to_recalculating_primary(tmp_path, monkeypatch):
    context, outers = _unfitted_six_aar()
    handoff = sensitivity._a12_handoff_from_outers(context, outers)
    calls, policy = _unfitted_metric_engines(monkeypatch)
    with pytest.raises(ContractError, match="F5_A12_NESTED_BOOTSTRAP_PROFILE_INVALID"):
        sensitivity.evaluate_a12_incremental_value(handoff, context["evaluation_response_csv"], formal=True,
            evidence_root=tmp_path / "not-started", resource_policy=policy, retained_bytes_per_replicate=2 * 1024**2)
    assert calls == {"UNFITTED_RNG": 0, "UNFITTED_METRICS": 0, "metric_replays": 0}
    assert not (tmp_path / "not-started").exists()


def _prepare_unfitted_shared_b1000(tmp_path, monkeypatch, *, horizon=24):
    context, outers = _unfitted_six_aar()
    if horizon == 12:
        science = nested._sealed({**{k: v for k, v in context["science_decision"].items() if k != "identity_sha256"},
            "twelve_month_development": nested._twelve_month_development_contract()})
        context["science_decision"] = science
        context["primary"] = nested._sealed({**{k: v for k, v in context["primary"].items() if k != "identity_sha256"},
            "selection_horizon_months": 12, "science_decision_sha256": science["identity_sha256"]})
        for row in outers:
            source = row["source"]["primary_source"]
            source["science_decision"] = science
            source["primary_development_lock"].update(selection_horizon_months=12,
                science_decision_binding={"science_decision_sha256": science["identity_sha256"]})
        selected = {name: context["primary"][name] for name in ("patient_ids", "centers", "horizons", "survival")}
        context["primary_point"] = nested._sealed({**{k: v for k, v in context["primary_point"].items() if k != "identity_sha256"},
            "selected_ooc_sha256": context["primary"]["identity_sha256"],
            "selection_horizon_months": 12, "science_decision_sha256": science["identity_sha256"],
            "evaluation": _unfitted_evaluation(selected, selection_horizon_months=12, science_decision=science)})
    predictions = sensitivity._a12_handoff_from_outers(context, outers)
    calls, policy = _unfitted_metric_engines(monkeypatch)
    source, point = tmp_path / "shared.zip", tmp_path / "point.zip"
    result = sensitivity.evaluate_a12_incremental_value(predictions, context["evaluation_response_csv"], formal=True,
        evidence_root=tmp_path / "preparation", resource_policy=policy, retained_bytes_per_replicate=2 * 1024**2,
        retained_primary_point=context["primary_point"], primary_point_native=context["primary_point_native"],
        bootstrap_input_target=source, point_archive_target=point)
    assert result["bootstrap_replicates_executed"] == 0 and result["shared_rng_invocations"] == 1
    assert calls == {"UNFITTED_RNG": 1, "UNFITTED_METRICS": 1, "metric_replays": 2}
    return context, predictions, calls, policy, source, point, result


@pytest.mark.parametrize("horizon", [24, 12])
def test_prepared_bootstrap_shard_keeps_evaluation_horizon(tmp_path, monkeypatch, horizon):
    context, predictions, calls, policy, source, point, prepared = _prepare_unfitted_shared_b1000(
        tmp_path, monkeypatch, horizon=horizon)
    opened = sensitivity._load_a12_bootstrap_inputs(source, tmp_path / "opened", policy, prepared_input_record=prepared)
    assert opened["handoff"].get("selection_horizon_months", 24) == horizon
    if horizon == 12:
        assert opened["handoff"]["science_decision"] == context["science_decision"]
    target = tmp_path / "shard.zip"
    result = sensitivity.execute_a12_bootstrap_shard(source, target, replicate_ids=[997, 3], resource_policy=policy,
        retained_bytes_per_replicate=2 * 1024**2, prepared_input_record=prepared)
    assert result["replicate_ids"] == [3, 997]
    execution = strict_json_bytes(read_safe_zip(target)["bootstrap-shard.json"])["execution"]
    assert execution["execution_scratch_reserve_bytes"] == 0
    assert execution["effective_policy"]["scratch_reserve_bytes"] == 0
    replay = sensitivity.replay_a12_bootstrap_shard(target, source, tmp_path / "readback", resource_policy=policy,
        prepared_input_record=prepared)
    assert replay["replicate_ids"] == [3, 997]
    assert calls["UNFITTED_RNG"] == 1 and calls["UNFITTED_METRICS"] == 3


@pytest.mark.parametrize("available, passes", [(4096, True), (2047, False)])
def test_bootstrap_archive_current_admission_keeps_actual_expansion_floor(tmp_path, monkeypatch, available, passes):
    """Real safe ZIP expansion, no predictions, RNG, metric engine or model."""
    source = tmp_path / "input.zip"
    raw = b"a" * 2048
    write_deterministic_zip(source, {"input.txt": raw})
    policy = {"configured_worker_ceiling": runtime.CPU_MINUS_8, "memory_bytes_per_worker": 1,
        "scratch_bytes_per_worker": 1, "memory_reserve_bytes": 0, "scratch_reserve_bytes": 10**12,
        "transfer_archive_worker_ceiling": 24}
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda root: {
        "effective_cpus": 32, "available_memory_bytes": 16 * 1024**3,
        "scratch_available_bytes": available, "scratch_root": str(root)})
    root = tmp_path / "opened"
    if not passes:
        with pytest.raises(ContractError, match="F5_A12_BOOTSTRAP_ARCHIVE_SPACE_INSUFFICIENT"):
            sensitivity._extract_a12_bootstrap_archive(source, root, policy, members={"input.txt"},
                max_member_bytes=4096, max_total_bytes=4096)
        assert not root.exists()
    else:
        report = sensitivity._extract_a12_bootstrap_archive(source, root, policy, members={"input.txt"},
            max_member_bytes=4096, max_total_bytes=4096)
        assert (root / "input.txt").read_bytes() == raw
        assert report["effective_policy"]["scratch_reserve_bytes"] == 0
        assert report["resource_policy"] == policy


def test_second_prediction_binding_reuses_native_rng_without_copying_first_plan(tmp_path, monkeypatch):
    """Unfitted routing fixture, not a completed second-horizon analysis."""
    context, _, calls, policy, first, _, first_prepared = _prepare_unfitted_shared_b1000(tmp_path, monkeypatch)
    _, outers = _unfitted_six_aar()
    for outer in outers:
        matrix = outer["predictions"]["survival"][nested.AAR_ESTIMANDS[0]]
        for curve in matrix:
            curve[1:] = [.65] * 36
    predictions = sensitivity._a12_handoff_from_outers(context, outers)
    original = first.read_bytes()
    retained = tmp_path / "preparation/rng.zip"
    rng_bytes = retained.read_bytes()
    second, point, root = tmp_path / "second.zip", tmp_path / "second.points.zip", tmp_path / "second-preparation"
    prepared = sensitivity.evaluate_a12_incremental_value(predictions, context["evaluation_response_csv"], formal=True,
        evidence_root=root, resource_policy=policy, retained_bytes_per_replicate=2 * 1024**2,
        retained_primary_point=context["primary_point"], primary_point_native=context["primary_point_native"],
        bootstrap_input_target=second, point_archive_target=point, retained_rng_archive=retained,
        retained_rng_preparation_record=first_prepared)
    assert prepared["shared_rng_invocations"] == prepared["bootstrap_replicates_executed"] == prepared["new_model_fits"] == 0
    assert calls == {"UNFITTED_RNG": 1, "UNFITTED_METRICS": 2, "metric_replays": 4}
    before, after = read_safe_zip(first), read_safe_zip(second)
    assert before["rng.zip"] == after["rng.zip"] == rng_bytes == retained.read_bytes()
    first_plan, second_plan = (strict_json_bytes(entries["plan.json"]) for entries in (before, after))
    assert first_plan["plan"] == second_plan["plan"]
    assert first_plan["source"] != second_plan["source"] and before["predictions.json"] != after["predictions.json"]
    sensitivity._load_a12_bootstrap_inputs(second, tmp_path / "second-opened", policy, prepared_input_record=prepared)
    assert calls["UNFITTED_RNG"] == 1 and calls["UNFITTED_METRICS"] == 2 and first.read_bytes() == original
    for field in ("sha256", "size_bytes"):
        wrong_reference = {**prepared["rng_archive"], field: "0" * 64 if field == "sha256" else prepared["rng_archive"][field] + 1}
        with pytest.raises(ContractError, match="F5_A12_PREPARED_INPUT_BYTES_CHANGED"):
            sensitivity._load_a12_bootstrap_inputs(second, tmp_path / ("wrong-member-" + field), policy,
                prepared_input_record={**prepared, "rng_archive": wrong_reference})
    for invalid_count in (False, -1, 2):
        with pytest.raises(ContractError, match="F5_A12_INDEPENDENT_PREPARATION_RECORD_REQUIRED"):
            sensitivity._a12_prepared_input_record({**prepared, "shared_rng_invocations": invalid_count}, second)


@pytest.mark.parametrize("damage", ["patient_order", "seed", "kernel", "engine"])
def test_retained_rng_mismatch_stops_before_new_metrics_or_rng(tmp_path, monkeypatch, damage):
    context, predictions, calls, policy, _, _, first_prepared = _prepare_unfitted_shared_b1000(tmp_path, monkeypatch)
    entries = read_safe_zip(tmp_path / "preparation/rng.zip")
    if damage == "kernel":
        entries["f4_bootstrap.R"] += b"\n"
    elif damage == "engine":
        execution = strict_json_bytes(entries["execution.json"])
        execution["engine_threads"] = {"OMP_NUM_THREADS": "2"}
        entries["execution.json"] = canonical_json_bytes(execution)
    else:
        request = strict_json_bytes(entries["input.json"])
        if damage == "patient_order":
            request["patient_ids"].reverse()
        else:
            request["root_seed"] += 1
        entries["input.json"] = canonical_json_bytes(request)
    retained, root = tmp_path / "damaged-rng.zip", tmp_path / "rejected-preparation"
    write_deterministic_zip(retained, entries)
    # Pin these UNFITTED bytes to exercise the original request/kernel checks,
    # separately from rejecting bytes that differ from the first real receipt.
    pinned = {**first_prepared, "rng_archive": {"sha256": sha256_file(retained), "size_bytes": retained.stat().st_size}}
    with pytest.raises(ContractError, match="F4_BOOTSTRAP_NATIVE_REPLAY_MISMATCH"):
        sensitivity.evaluate_a12_incremental_value(predictions, context["evaluation_response_csv"], formal=True,
            evidence_root=root, resource_policy=policy, retained_bytes_per_replicate=2 * 1024**2,
            retained_primary_point=context["primary_point"], primary_point_native=context["primary_point_native"],
            bootstrap_input_target=tmp_path / "rejected.zip", point_archive_target=tmp_path / "rejected.points.zip",
            retained_rng_archive=retained, retained_rng_preparation_record=pinned)
    assert calls["UNFITTED_RNG"] == calls["UNFITTED_METRICS"] == 1
    assert (root / "rng.zip").read_bytes() == retained.read_bytes()  # preserve attributable failure bytes
    assert not (root / "point-native.zip").exists() and not (tmp_path / "rejected.zip").exists()


def test_retained_rng_rejects_changed_same_center_draw_against_first_receipt(tmp_path, monkeypatch):
    context, predictions, calls, policy, _, _, prepared = _prepare_unfitted_shared_b1000(tmp_path, monkeypatch)
    retained = tmp_path / "same-center-substitution.zip"
    entries = read_safe_zip(tmp_path / "preparation/rng.zip")
    request, output = (strict_json_bytes(entries[name]) for name in ("input.json", "stdout.txt"))
    old = output["draws"][0][0]
    output["draws"][0][0] = next(i for i, center in enumerate(request["centers"])
                                     if center == request["centers"][old] and i != old)
    entries["stdout.txt"] = canonical_json_bytes(output)
    write_deterministic_zip(retained, entries)
    opened = sensitivity._validate_a12_handoff(predictions)
    # Structural replay alone accepts this legal but noncanonical replacement.
    f4.bootstrap_draws(opened["patient_ids"], opened["centers"], "FIXED_MODEL_PAIRED",
        patient_keys=opened["patient_keys"], replay_archive=retained)
    with pytest.raises(ContractError, match="F5_A12_RETAINED_RNG_BYTES_CHANGED"):
        sensitivity.evaluate_a12_incremental_value(predictions, context["evaluation_response_csv"], formal=True,
            evidence_root=tmp_path / "rejected", resource_policy=policy, retained_bytes_per_replicate=2 * 1024**2,
            retained_primary_point=context["primary_point"], primary_point_native=context["primary_point_native"],
            bootstrap_input_target=tmp_path / "rejected.zip", point_archive_target=tmp_path / "rejected.points.zip",
            retained_rng_archive=retained, retained_rng_preparation_record=prepared)
    assert calls["UNFITTED_RNG"] == calls["UNFITTED_METRICS"] == 1
    assert not (tmp_path / "rejected.zip").exists()


def test_retained_rng_unchanged_size_wrong_independent_sha_is_rejected(tmp_path, monkeypatch):
    context, predictions, calls, policy, _, _, prepared = _prepare_unfitted_shared_b1000(tmp_path, monkeypatch)
    retained, root = tmp_path / "preparation/rng.zip", tmp_path / "wrong-sha"
    wrong = {**prepared, "rng_archive": {**prepared["rng_archive"], "sha256": "0" * 64}}
    assert retained.stat().st_size == wrong["rng_archive"]["size_bytes"]
    with pytest.raises(ContractError, match="F5_A12_RETAINED_RNG_BYTES_CHANGED"):
        sensitivity.evaluate_a12_incremental_value(predictions, context["evaluation_response_csv"], formal=True,
            evidence_root=root, resource_policy=policy, retained_bytes_per_replicate=2 * 1024**2,
            retained_primary_point=context["primary_point"], primary_point_native=context["primary_point_native"],
            bootstrap_input_target=tmp_path / "rejected.zip", point_archive_target=tmp_path / "rejected.points.zip",
            retained_rng_archive=retained, retained_rng_preparation_record=wrong)
    assert (root / "rng.zip").read_bytes() == retained.read_bytes()
    assert calls["UNFITTED_RNG"] == calls["UNFITTED_METRICS"] == 1
    assert not (root / "point-native.zip").exists()


@pytest.mark.parametrize("scope", ["missing_record", "missing_archive", "nonprepare"])
def test_retained_rng_scope_rejects_before_evaluation_side_effects(tmp_path, monkeypatch, scope):
    context, predictions, calls, policy, _, _, prepared = _prepare_unfitted_shared_b1000(tmp_path, monkeypatch)
    options = {"retained_rng_archive": tmp_path / "preparation/rng.zip", "retained_rng_preparation_record": prepared,
               "bootstrap_input_target": tmp_path / "rejected.zip", "point_archive_target": tmp_path / "rejected.points.zip"}
    if scope == "missing_record":
        options.pop("retained_rng_preparation_record")
    elif scope == "missing_archive":
        options.pop("retained_rng_archive")
    else:
        options.pop("bootstrap_input_target")
        options.pop("point_archive_target")
    with pytest.raises(ContractError, match="F5_A12_RETAINED_RNG_(SOURCE_REQUIRED|SCOPE_INVALID)"):
        sensitivity.evaluate_a12_incremental_value(predictions, context["evaluation_response_csv"], formal=True,
            evidence_root=tmp_path / "rejected", resource_policy=policy, retained_bytes_per_replicate=2 * 1024**2,
            retained_primary_point=context["primary_point"], primary_point_native=context["primary_point_native"], **options)
    assert calls == {"UNFITTED_RNG": 1, "UNFITTED_METRICS": 1, "metric_replays": 2}
    assert not (tmp_path / "rejected").exists() and not (tmp_path / "rejected.zip").exists()


def test_retained_rng_growth_during_copy_cannot_exceed_pinned_size(tmp_path, monkeypatch):
    context, predictions, calls, policy, _, _, prepared = _prepare_unfitted_shared_b1000(tmp_path, monkeypatch)
    retained, root = tmp_path / "preparation/rng.zip", tmp_path / "bounded-copy"
    original_bytes, original_open = retained.read_bytes(), Path.open
    def grow_on_read(path, mode="r", *args, **kwargs):
        if path == retained and mode == "rb":
            return io.BytesIO(original_bytes + b"UNFITTED concurrent growth")
        return original_open(path, mode, *args, **kwargs)
    monkeypatch.setattr(Path, "open", grow_on_read)
    with pytest.raises(ContractError, match="F5_A12_RETAINED_RNG_BYTES_CHANGED"):
        sensitivity.evaluate_a12_incremental_value(predictions, context["evaluation_response_csv"], formal=True,
            evidence_root=root, resource_policy=policy, retained_bytes_per_replicate=2 * 1024**2,
            retained_primary_point=context["primary_point"], primary_point_native=context["primary_point_native"],
            bootstrap_input_target=tmp_path / "rejected.zip", point_archive_target=tmp_path / "rejected.points.zip",
            retained_rng_archive=retained, retained_rng_preparation_record=prepared)
    assert (root / "rng.zip").stat().st_size == prepared["rng_archive"]["size_bytes"]
    assert (root / "rng.zip").read_bytes() == original_bytes
    assert calls["UNFITTED_RNG"] == calls["UNFITTED_METRICS"] == 1


@pytest.mark.parametrize("scope", ["legacy_prepare", "nonprepare", "aggregate"])
def test_bundle_entry_rejects_rng_reuse_outside_nested_preparation(tmp_path, scope):
    source, target = tmp_path / "source.zip", tmp_path / "never-created.zip"
    source.write_bytes(b"UNFITTED entry scope")
    options = {"bootstrap_inputs_only": True} if scope == "legacy_prepare" else {"primary_input_bundles": {}}
    if scope == "aggregate":
        options.update(bootstrap_input=source, point_archive=tmp_path / "point.zip",
                       bootstrap_shards=[tmp_path / f"shard-{i}.zip" for i in range(6)])
    with pytest.raises(ContractError, match="F5_A12_RETAINED_RNG_SCOPE_INVALID"):
        sensitivity.execute_a12_bundle(source, target, retained_rng_archive=tmp_path / "rng.zip",
            retained_rng_preparation_record={"UNFITTED": "scope rejects before source consumption"}, **options)
    assert not target.exists() and not target.with_name(target.name + ".work").exists()


def test_b1000_shared_input_is_minimal_and_reuses_all_original_draws(tmp_path, monkeypatch):
    context, predictions, calls, policy, source, point, prepared = _prepare_unfitted_shared_b1000(tmp_path, monkeypatch)
    entries = read_safe_zip(source)
    assert set(entries) == {"bootstrap-input.json", "predictions.json", "response.csv", "plan.json", "rng.zip"}
    fixed = strict_json_bytes(entries["predictions.json"])
    assert set(fixed) == {"patient_ids", "patient_keys", "centers", "horizons", "survival"}
    assert set(fixed["centers"]) == set(sensitivity._VALIDATION_CENTERS) and "55" not in fixed["centers"]
    assert entries["response.csv"] == context["evaluation_response_csv"]
    opened = sensitivity._load_a12_bootstrap_inputs(source, tmp_path / "opened", policy, prepared_input_record=prepared)
    assert opened["manifest"]["point_archive"]["sha256"] == sha256_file(point)
    assert len(opened["plan"]["draws"]) == 1000 and calls["UNFITTED_RNG"] == 1
    # Same-center counts and self-rehashed metadata cannot replace the original RNG output.
    changed = strict_json_bytes(entries["plan.json"])
    changed["plan"]["draws"][996][0] += 6
    damaged = {**entries, "plan.json": canonical_json_bytes(changed)}
    manifest = strict_json_bytes(entries["bootstrap-input.json"])
    manifest["members"]["plan.json"] = {"sha256": sha256_bytes(damaged["plan.json"]), "size_bytes": len(damaged["plan.json"])}
    damaged["bootstrap-input.json"] = canonical_json_bytes(nested._sealed({key: value for key, value in manifest.items()
        if key != "identity_sha256"}))
    target = tmp_path / "different-draw.zip"
    write_deterministic_zip(target, damaged)
    with pytest.raises(ContractError, match="F5_A12_PREPARED_INPUT_BYTES_CHANGED"):
        sensitivity._load_a12_bootstrap_inputs(target, tmp_path / "bad-draw", policy, prepared_input_record=prepared)
    # A separately supplied test boundary still exercises the original RNG consumer.
    with pytest.raises(ContractError, match="F5_A12_RETAINED_RNG_MISMATCH"):
        sensitivity._load_a12_bootstrap_inputs(target, tmp_path / "bad-draw-inner", policy,
            prepared_input_record={**prepared, "sha256": sha256_file(target), "size_bytes": target.stat().st_size})
    assert calls["UNFITTED_RNG"] == calls["UNFITTED_METRICS"] == 1


def test_b1000_shared_input_checks_ram_before_first_zip_directory(tmp_path, monkeypatch):
    _, _, calls, policy, source, _, prepared = _prepare_unfitted_shared_b1000(tmp_path, monkeypatch)
    seen = []
    original = sensitivity.zipfile.ZipFile
    def zip_open(*args, **kwargs):
        seen.append(args[0])
        return original(*args, **kwargs)
    monkeypatch.setattr(sensitivity.zipfile, "ZipFile", zip_open)
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda root: {"effective_cpus": 64,
        "available_memory_bytes": 1, "scratch_available_bytes": 10**12, "scratch_root": str(root)})
    with pytest.raises(ContractError):
        sensitivity._load_a12_bootstrap_inputs(source, tmp_path / "not-decoded", policy, prepared_input_record=prepared)
    assert seen == [] and not (tmp_path / "not-decoded").exists()
    assert calls == {"UNFITTED_RNG": 1, "UNFITTED_METRICS": 1, "metric_replays": 2}


def test_b1000_valid_inner_rng_log_is_admitted_before_its_first_member_read(tmp_path, monkeypatch):
    _, _, calls, policy, source, _, prepared = _prepare_unfitted_shared_b1000(tmp_path, monkeypatch)
    entries = read_safe_zip(source)
    rng = read_safe_zip(entries["rng.zip"])
    large_rng = tmp_path / "large-rng.zip"
    write_deterministic_zip(large_rng, {**rng, "stderr.txt": bytes(range(256)) * 32768})
    entries["rng.zip"] = large_rng.read_bytes()
    manifest = strict_json_bytes(entries["bootstrap-input.json"])
    manifest["members"]["rng.zip"] = {"sha256": sha256_file(large_rng), "size_bytes": large_rng.stat().st_size}
    entries["bootstrap-input.json"] = canonical_json_bytes(nested._sealed({key: value for key, value in manifest.items()
        if key != "identity_sha256"}))
    target = tmp_path / "large-shared.zip"
    write_deterministic_zip(target, entries, stored_members={"rng.zip"})
    # Independently pin the changed UNFITTED fixture; request/output/kernel stay intact.
    prepared = {**prepared, "sha256": sha256_file(target), "size_bytes": target.stat().st_size,
                "rng_archive": manifest["members"]["rng.zip"]}
    sensitivity._load_a12_bootstrap_inputs(target, tmp_path / "valid-log", policy, prepared_input_record=prepared)
    seen = []
    original_stream = bundle._stream_zip_member
    def stream(archive, info, output):
        if "f4_bootstrap.R" in archive.namelist():
            seen.append(info.filename)
        return original_stream(archive, info, output)
    monkeypatch.setattr(bundle, "_stream_zip_member", stream)
    available = 128 * 1024**2
    assert 32 * sum(map(len, entries.values())) + 4 * 1024**2 < available < 32 * 8 * 1024**2
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda root: {"effective_cpus": 64,
        "available_memory_bytes": available, "scratch_available_bytes": 10**12, "scratch_root": str(root)})
    with pytest.raises(ContractError):
        sensitivity._load_a12_bootstrap_inputs(target, tmp_path / "blocked-inner-rng", policy, prepared_input_record=prepared)
    assert seen == []  # outer extraction is allowed, inner expansion is not
    assert calls == {"UNFITTED_RNG": 1, "UNFITTED_METRICS": 1, "metric_replays": 2}


@pytest.mark.parametrize("horizon", [24, 12])
def test_b1000_native_replicate_producer_then_reader_runs_one_metric_engine(tmp_path, monkeypatch, horizon):
    """One synthetic non-prefix draw exercises real R metrics, not a new RNG plan."""
    context, outers = _unfitted_six_aar()
    opened = sensitivity._validate_a12_handoff(sensitivity._a12_handoff_from_outers(context, outers))
    handoff = {name: opened[name] for name in ("patient_ids", "centers", "horizons", "survival")}
    scope_options = {}
    if horizon == 12:
        science = nested._sealed({**{k: v for k, v in context["science_decision"].items() if k != "identity_sha256"},
            "twelve_month_development": nested._twelve_month_development_contract()})
        scope_options = {"selection_horizon_months": 12, "science_decision": science}
        handoff.update(scope_options)
    indices = list(range(len(handoff["patient_ids"])))
    indices[6] = indices[0]  # duplicate one source patient within the same center
    response = context["evaluation_response_csv"]
    binding = sensitivity._a12_bootstrap_binding(handoff, response, {"replicate_count": 1000})
    native_calls, km_calls, prepared_predictions = [], [], []
    original_step, original_error, original_dca = f4._censoring_survival_step, f4.prediction_error, f4.decision_curve
    def step(times, events):
        km_calls.append((times, events))
        return original_step(times, events)
    def error(ids, matrix, context):
        prepared_predictions.append(matrix)
        return original_error(ids, matrix, context)
    def dca(ids, matrix, context, **kwargs):
        assert matrix is prepared_predictions[-1]
        return original_dca(ids, matrix, context, **kwargs)
    monkeypatch.setattr(f4, "_censoring_survival_step", step)
    monkeypatch.setattr(f4, "prediction_error", error)
    monkeypatch.setattr(f4, "decision_curve", dca)
    original_native = f4.native_metrics
    def native(jobs, **kwargs):
        native_calls.append([job["label"] for job in jobs])
        return original_native(jobs, **kwargs)
    monkeypatch.setattr(f4, "native_metrics", native)
    with f5._full_score_scratch(tmp_path):
        result = sensitivity._execute_and_replay_a12_bootstrap_replicate((997, indices), root=tmp_path,
            evaluation_handoff=handoff, response_csv=response, source_binding=binding,
            retained_bytes_per_replicate=2 * 1024**2)
        replay = sensitivity._replay_a12_bootstrap_replicate((997, indices), root=tmp_path,
            evaluation_handoff=handoff, response_csv=response, source_binding=binding)
    assert canonical_json_bytes(result["row"]) == canonical_json_bytes(replay)
    assert result["row"]["replicate"] == 997 and result["row"]["receipt"]["unique_source_patient_count"] == 35
    assert len(native_calls) == 1 and len(native_calls[0]) == 28
    # Production, its first audit and two ZIP reads each build six independent
    # center paths; MICRO/center scopes share paths only inside that invocation.
    assert len(km_calls) == 4 * 6 and len(prepared_predictions) == 28
    assert native_calls[0][:4] == [f"MICRO/{branch}" for branch in ("PRIMARY", *nested.AAR_ESTIMANDS)]
    assert not (tmp_path / "replicate-0001.zip").exists()
    entries = read_safe_zip(tmp_path / "replicate-0997.zip")
    metric_entries = read_safe_zip(entries["metrics.zip"])
    selected, sampled_response, _ = f4.materialize_resampled_view(handoff, response, indices, "A12-PAIRED-0997")
    original_context = f4.censoring_context
    def uncached(*args, **kwargs):
        kwargs.pop("_center_step_cache", None)
        return original_context(*args, **kwargs)
    with monkeypatch.context() as independent:
        independent.setattr(f4, "censoring_context", uncached)
        unshared = f4.evaluate_predictions(selected, sampled_response, replay_native_archive=entries["metrics.zip"], **scope_options)
    assert len(km_calls) == 4 * 6 + 12 and len(native_calls) == 1
    assert canonical_json_bytes(unshared) == entries["evaluation.json"]
    if horizon == 12:
        with pytest.raises(ContractError, match="NATIVE_HORIZON_SOURCE_INVALID"):
            sensitivity._validate_a12_native_evaluation(unshared, selected, sampled_response,
                native_archive=entries["metrics.zip"])
        altered = {**unshared, "science_decision_sha256": "f" * 64}
        with pytest.raises(ContractError, match="NATIVE_HORIZON_SOURCE_INVALID"):
            sensitivity._validate_a12_native_evaluation(altered, selected, sampled_response,
                native_archive=entries["metrics.zip"], **scope_options)
        assert len(native_calls) == 1  # rejection is read-only, with no metric rerun
    large_metrics = tmp_path / "large-metrics.zip"
    write_deterministic_zip(large_metrics, {**metric_entries, "stderr.txt": bytes(range(256)) * 32768})
    entries["metrics.zip"] = large_metrics.read_bytes()
    large_root = tmp_path / "large-metric-log"
    large_root.mkdir()
    write_deterministic_zip(large_root / "replicate-0997.zip", entries, stored_members={"metrics.zip"})
    sensitivity._replay_a12_bootstrap_replicate((997, indices), root=large_root,
        evaluation_handoff=handoff, response_csv=response, source_binding=binding)
    seen = []
    original_stream = bundle._stream_zip_member
    def stream(archive, info, output):
        if "f4_metrics.R" in archive.namelist():
            seen.append(info.filename)
        return original_stream(archive, info, output)
    monkeypatch.setattr(bundle, "_stream_zip_member", stream)
    available = 128 * 1024**2
    assert 32 * sum(map(len, entries.values())) + 4 * 1024**2 < available < 32 * 8 * 1024**2
    policy = {"configured_worker_ceiling": runtime.CPU_MINUS_8, "memory_bytes_per_worker": 1,
        "scratch_bytes_per_worker": 1, "memory_reserve_bytes": 0, "scratch_reserve_bytes": 0,
        "transfer_archive_worker_ceiling": 1000}
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda root: {"effective_cpus": 64,
        "available_memory_bytes": available, "scratch_available_bytes": 10**12, "scratch_root": str(root)})
    with pytest.raises(ContractError):
        sensitivity._replay_a12_bootstrap_replicate((997, indices), root=large_root,
            evaluation_handoff=handoff, response_csv=response, source_binding=binding,
            admit_io=lambda **kwargs: sensitivity._admit_a12_bootstrap_io(
                resource_policy=policy, scratch_root=large_root, **kwargs))
    assert seen == [] and len(native_calls) == 1


def test_b1000_reader_failure_keeps_zip_but_never_completes_or_refits_coordinate(tmp_path, monkeypatch):
    _, _, calls, policy, source, _, prepared = _prepare_unfitted_shared_b1000(tmp_path, monkeypatch)
    def fail_reader(*args, **kwargs):
        raise ContractError("UNFITTED_POST_ZIP_NATIVE_READER_FAILURE")
    monkeypatch.setattr(sensitivity, "_replay_a12_bootstrap_replicate", fail_reader)
    target = tmp_path / "failed-shard.zip"
    with pytest.raises(ContractError, match="UNFITTED_POST_ZIP_NATIVE_READER_FAILURE"):
        sensitivity.execute_a12_bootstrap_shard(source, target, replicate_ids=[2, 997],
            resource_policy=policy, retained_bytes_per_replicate=2 * 1024**2, prepared_input_record=prepared)
    assert not target.exists() and (tmp_path / "bootstrap-replicates/replicate-0002.zip").is_file()
    execution = strict_json_bytes((tmp_path / "failed-shard.zip.work/execution.json").read_bytes())
    assert execution["completed_replicate_ids"] == [] and execution["bootstrap_pool"]["status"] == "FAILED"
    assert execution["bootstrap_pool"]["completed_task_count"] == 0
    before = dict(calls)
    with pytest.raises(ContractError, match="F5_A12_BOOTSTRAP_COORDINATE_ALREADY_PRESENT"):
        sensitivity.execute_a12_bootstrap_shard(source, tmp_path / "renamed-output.zip", replicate_ids=[2],
            resource_policy=policy, retained_bytes_per_replicate=2 * 1024**2, prepared_input_record=prepared)
    assert calls == before
    renamed = tmp_path / "renamed-input.zip"
    renamed.write_bytes(source.read_bytes())
    with pytest.raises(ContractError, match="F5_A12_BOOTSTRAP_COORDINATE_ALREADY_PRESENT"):
        sensitivity.execute_a12_bootstrap_shard(renamed, tmp_path / "renamed-both.zip", replicate_ids=[2],
            resource_policy=policy, retained_bytes_per_replicate=2 * 1024**2, prepared_input_record=prepared)
    assert calls == before


def test_b1000_shard_row_cannot_detach_from_actual_evaluation(tmp_path, monkeypatch):
    _, _, calls, policy, source, _, prepared = _prepare_unfitted_shared_b1000(tmp_path, monkeypatch)
    target = tmp_path / "shard.zip"
    sensitivity.execute_a12_bootstrap_shard(source, target, replicate_ids=[997],
        resource_policy=policy, retained_bytes_per_replicate=2 * 1024**2, prepared_input_record=prepared)
    shared = sensitivity._load_a12_bootstrap_inputs(source, tmp_path / "shared-input", policy, prepared_input_record=prepared)
    entries = read_safe_zip(target)
    index = strict_json_bytes(entries["bootstrap-shard.json"])
    record = index["replicate_results"][0]
    replicate = read_safe_zip(entries[record["member"]])
    record["row"]["scope_deltas"]["MICRO"][nested.AAR_ESTIMANDS[0]]["ibs_0_24"] += .1
    changed = tmp_path / "changed-replicate.zip"
    write_deterministic_zip(changed, {**replicate, "result.json": canonical_json_bytes(record["row"])},
        stored_members={"metrics.zip"})
    entries[record["member"]] = changed.read_bytes()
    record.update(sha256=sha256_file(changed), size_bytes=changed.stat().st_size)
    entries["bootstrap-shard.json"] = canonical_json_bytes(nested._sealed({key: value for key, value in index.items()
        if key != "identity_sha256"}))
    bad = tmp_path / "changed-shard.zip"
    write_deterministic_zip(bad, entries, stored_members={record["member"]})
    actual = read_safe_zip(entries[record["member"]])
    assert actual["evaluation.json"] == replicate["evaluation.json"] and actual["metrics.zip"] == replicate["metrics.zip"]
    before = dict(calls)
    with pytest.raises(ContractError, match="F5_A12_RETAINED_REDUCTION_MISMATCH"):
        sensitivity._read_a12_bootstrap_shard(bad, tmp_path / "bad-shard-reader", shared, policy)
    assert calls == before
    original = read_safe_zip(target)
    reserved = {"index_sha256": sha256_bytes(original["bootstrap-shard.json"]),
        "io_memory_bytes": 32 * (len(original["bootstrap-shard.json"]) + 2 * 1024**2) + 4 * 1024**2,
        "expanded_bytes": sum(map(len, original.values()))}
    for field, altered in (("index_sha256", "f" * 64), ("io_memory_bytes", 1), ("expanded_bytes", 1)):
        destination = tmp_path / f"bad-reader-{field}"
        with pytest.raises(ContractError):
            sensitivity._read_a12_bootstrap_shard(target, destination, shared, policy,
                read_reservation={**reserved, field: altered})
        assert not destination.exists()
    assert calls == before and target.is_file()


@pytest.mark.parametrize("horizon", [24, 12])
def test_six_b1000_shards_keep_ids_reopen_rows_then_one_global_ci(tmp_path, monkeypatch, horizon):
    original_observation = runtime.observe_execution_resources
    context, predictions, calls, policy, source, point, prepared = _prepare_unfitted_shared_b1000(tmp_path, monkeypatch, horizon=horizon)
    synthetic_pool = sensitivity._bounded_ordered_spawn
    paths = []
    for index in range(6):
        path = tmp_path / f"shard-{index}.zip"
        ids = list(range(index + 1, 1001, 6))
        result = sensitivity.execute_a12_bootstrap_shard(source, path, replicate_ids=list(reversed(ids)),
            resource_policy=policy, retained_bytes_per_replicate=2 * 1024**2, prepared_input_record=prepared)
        assert result["replicate_ids"] == ids and result["numerically_reopened_replicates"] == len(ids)
        execution = strict_json_bytes(read_safe_zip(path)["bootstrap-shard.json"])["execution"]
        assert execution["assigned_replicate_ids"] == execution["completed_replicate_ids"] == ids
        assert execution["bootstrap_pool"]["configured_worker_ceiling"] == execution["bootstrap_pool"]["admitted_worker_ceiling"] == 56
        paths.append(path)
    assert calls == {"UNFITTED_RNG": 1, "UNFITTED_METRICS": 1001, "metric_replays": 2002}
    # Explicit independent shard review is also partitioned and runs no R.
    replayed = sensitivity.replay_a12_bootstrap_shard(paths[-1], source, tmp_path / "shard-review", resource_policy=policy,
        prepared_input_record=prepared)
    assert replayed["replicate_ids"] == list(range(6, 1001, 6))
    reduction_calls = []
    original_reduce = sensitivity._reduce_a12_incremental_value
    def reduce(handoff, plan, point, rows, **kwargs):
        reduction_calls.append([row["replicate"] for row in rows])
        return original_reduce(handoff, plan, point, rows, **kwargs)
    monkeypatch.setattr(sensitivity, "_reduce_a12_incremental_value", reduce)
    options = {"resource_policy": policy, "retained_primary_point": context["primary_point"],
        "primary_point_native": context["primary_point_native"], "prepared_input_record": prepared}
    borrowed = {"bootstrap-input.zip": source, "point-sources.zip": point,
                **{f"shard-{index}.zip": path for index, path in enumerate(reversed(paths), 1)}}
    def no_archive_copy(*args, **kwargs):
        pytest.fail("Gather must borrow fixed original archive paths")
    response_snapshots = []
    original_shard_reader = sensitivity._read_a12_bootstrap_shard
    def flat_readers(worker, jobs, *, selected_slots, execution_report):
        assert worker.func is sensitivity._read_a12_bootstrap_shard_job and len(jobs) == 6
        assert [job["root"].name for job in jobs] == [f"shard-{i}" for i in range(1, 7)]
        assert 1 <= selected_slots <= 6
        for job in jobs:
            copied_worker, copied_job = pickle.loads(pickle.dumps((worker, job)))
            assert copied_job == job and copied_worker.keywords["shared"] == worker.keywords["shared"]
            response_snapshots.append(copied_worker.keywords["response_rows"])
        # Real H9 spawn, reversed dispatch; the original pool returns canonical
        # jobs. No fixture-only native/metric callback is needed in these leaves.
        if sys.platform != "linux":
            # Local synthetic routing is not evidence for Linux resource/spawn.
            return synthetic_pool(worker, jobs, selected_slots=selected_slots, execution_report=execution_report)
        return runtime._bounded_ordered_spawn(worker, jobs, selected_slots=selected_slots,
            execution_report=execution_report, schedule_order=list(reversed(range(6))))
    with monkeypatch.context() as borrowing:
        borrowing.setattr(sensitivity.shutil, "copyfile", no_archive_copy)
        borrowing.setattr(sensitivity, "_bounded_ordered_spawn", flat_readers)
        if sys.platform == "linux":
            borrowing.setattr(runtime, "observe_execution_resources", original_observation)
        result = sensitivity._gather_a12_bootstrap_evaluation(predictions, context["evaluation_response_csv"],
            evidence_root=tmp_path / "gather", bootstrap_input=source, point_archive=point,
            bootstrap_shards=list(reversed(paths)), **options)
    assert all(path.is_file() and not (tmp_path / "gather" / name).exists() for name, path in borrowed.items())
    assert len(response_snapshots) == 6 and all(row == response_snapshots[0] for row in response_snapshots)
    assert len({id(row) for row in response_snapshots}) == 6
    reader_execution = result["evaluation_execution"]["numerical_reader_execution"]
    assert reader_execution["pool"]["actual_worker_process_peak"] <= 6
    assert reader_execution["pool"]["completed_task_count"] == 6
    reservation = reader_execution["resource_reservation"]
    assert reservation["future_retention_reserved_bytes"] == sum(
        row["expanded_bytes"] for row in reservation["reader_reservations"]) + 2 * sum(
        path.stat().st_size for path in borrowed.values())
    assert reservation["worker_memory_estimate_bytes"] == 32 * reservation["shared_input_bytes"] + max(
        row["io_memory_bytes"] for row in reservation["reader_reservations"])
    assert [row["member"] for row in result["evaluation_execution"]["origin"]["shards"]] == [
        f"shard-{index}.zip" for index in range(1, 7)]
    assert reduction_calls == [list(range(1, 1001))]
    assert result["bootstrap"]["replicate_count"] == 1000 and result["bootstrap"]["paired_row_count"] == 912
    assert result["evaluation_execution"]["global_reduction_count"] == 1
    assert calls["UNFITTED_RNG"] == 1 and calls["UNFITTED_METRICS"] == 1001
    # A real worker floor short by one byte rejects before any reader.
    for resource in ("memory", "scratch"):
        effective = reader_execution["effective_policy"]
        available = effective[f"{resource}_reserve_bytes"] + effective[f"{resource}_bytes_per_worker"] - 1
        with monkeypatch.context() as short:
            short_policy = {**policy, "scratch_bytes_per_worker": 2}
            if resource == "scratch":
                available = 1
            short.setattr(runtime, "observe_execution_resources", lambda root: {
                "effective_cpus": 32, "available_memory_bytes": available if resource == "memory" else 10**12,
                "scratch_available_bytes": available if resource == "scratch" else 10**12, "scratch_root": str(root)})
            short.setattr(sensitivity, "_bounded_ordered_spawn", lambda *a, **k: pytest.fail("NO_READER_BEFORE_ADMISSION"))
            with pytest.raises(ContractError, match="RESOURCE_ADMISSION_ZERO"):
                sensitivity._gather_a12_bootstrap_evaluation(predictions, context["evaluation_response_csv"],
                    evidence_root=tmp_path / f"short-{resource}", bootstrap_input=source, point_archive=point,
                    bootstrap_shards=list(reversed(paths)), **{**options, "resource_policy": short_policy})
        assert reduction_calls == [list(range(1, 1001))]
    before_failure = len(reduction_calls)
    def failed_reader(source, root, *args, **kwargs):
        if root.name == "shard-6":
            root.mkdir()
            (root / "retained-failure.txt").write_text("UNFITTED numerical leaf failure")
            raise ContractError("UNFITTED_LAST_NUMERICAL_READER_FAILED")
        return original_shard_reader(source, root, *args, **kwargs)
    with monkeypatch.context() as failed:
        failed.setattr(sensitivity, "_read_a12_bootstrap_shard", failed_reader)
        with pytest.raises(ContractError, match="UNFITTED_LAST_NUMERICAL_READER_FAILED"):
            sensitivity._gather_a12_bootstrap_evaluation(predictions, context["evaluation_response_csv"],
                evidence_root=tmp_path / "failed-reader", bootstrap_input=source, point_archive=point,
                bootstrap_shards=list(reversed(paths)), **options)
    assert (tmp_path / "failed-reader/shard-6/retained-failure.txt").is_file()
    failed_execution = strict_json_bytes((tmp_path / "failed-reader/execution.json").read_bytes())
    assert failed_execution["global_reduction_count"] == 0
    assert failed_execution["numerical_reader_execution"]["pool"]["status"] == "FAILED"
    assert len(reduction_calls) == before_failure and all(path.is_file() for path in paths)
    # A final original consumer uses the same native rows, not a second metric run.
    retained = tmp_path / "retained"
    retained.mkdir()
    for name in sensitivity._a12_evaluation_member_names(nested=True, sharded=True):
        (retained / name).write_bytes(borrowed.get(name, tmp_path / "gather" / name).read_bytes())
    replay = sensitivity._replay_a12_sharded_evaluation(retained, predictions, context["evaluation_response_csv"], **options)
    assert canonical_json_bytes(replay) == canonical_json_bytes(result)
    assert calls["UNFITTED_RNG"] == 1 and calls["UNFITTED_METRICS"] == 1001
    # Different archive paths cannot hide overlap or an absent replicate.
    duplicate = tmp_path / "duplicate-shard.zip"
    duplicate.write_bytes(paths[0].read_bytes())
    before = len(reduction_calls)
    with pytest.raises(ContractError, match="F5_A12_BOOTSTRAP_COVERAGE_INVALID"):
        sensitivity._gather_a12_bootstrap_evaluation(predictions, context["evaluation_response_csv"],
            evidence_root=tmp_path / "overlap", bootstrap_input=source, point_archive=point,
            bootstrap_shards=[*paths[:5], duplicate], **options)
    assert len(reduction_calls) == before
    original = read_safe_zip(paths[-1])
    index = strict_json_bytes(original["bootstrap-shard.json"])
    removed = index["replicate_results"].pop()
    original.pop(removed["member"])
    index["replicate_ids"].pop()
    execution = index["execution"]
    execution["assigned_replicate_ids"] = execution["completed_replicate_ids"] = index["replicate_ids"]
    count = len(index["replicate_ids"])
    execution["resource_reservation"], execution["effective_policy"] = sensitivity._a12_shard_effective_policy(policy,
        fixed_bytes=execution["resource_reservation"]["fixed_input_bytes"], row_count=count, retained=2 * 1024**2,
        execution_scratch_reserve_bytes=execution.get("execution_scratch_reserve_bytes"))
    execution["resource_admission"] = runtime.resource_admission(execution["effective_policy"],
        execution["resource_observation"], legal_tasks=count)
    execution["bootstrap_pool"].update(completed_task_count=count, runnable_task_count=count)
    index["metric_scope_branch_job_count"] = 28 * count
    original["bootstrap-shard.json"] = canonical_json_bytes(nested._sealed({key: value for key, value in index.items()
        if key != "identity_sha256"}))
    missing = tmp_path / "missing-shard.zip"
    write_deterministic_zip(missing, original, stored_members={name for name in original if name.endswith(".zip")})
    with pytest.raises(ContractError, match="F5_A12_BOOTSTRAP_COVERAGE_INVALID"):
        sensitivity._gather_a12_bootstrap_evaluation(predictions, context["evaluation_response_csv"],
            evidence_root=tmp_path / "missing", bootstrap_input=source, point_archive=point,
            bootstrap_shards=[*paths[:5], missing], **options)
    assert len(reduction_calls) == before
    assert calls["UNFITTED_RNG"] == 1 and calls["UNFITTED_METRICS"] == 1001


@pytest.mark.parametrize("damage", [None, "engine_threads", "completed_task_count", "runnable_task_count",
    "admitted_worker_ceiling", "configured_worker_ceiling", "actual_worker_process_peak",
    "reservation", "effective_policy", "admission"])
@pytest.mark.parametrize("scratch_budget", [None, 0])
def test_sharded_reader_report_rejects_numeric_type_aliases(tmp_path, monkeypatch, damage, scratch_budget):
    """Only the original report boundary; numerical consumption is stubbed here."""
    policy = {"configured_worker_ceiling": runtime.CPU_MINUS_8, "memory_bytes_per_worker": 1,
        "scratch_bytes_per_worker": 1, "memory_reserve_bytes": 0, "scratch_reserve_bytes": 0,
        "transfer_archive_worker_ceiling": 24}
    observation = {"effective_cpus": 32, "available_memory_bytes": 16 * 1024**3,
        "scratch_available_bytes": 10**9, "scratch_root": str(tmp_path)}
    names = {"bootstrap-input.zip", "point-sources.zip", *(f"shard-{i}.zip" for i in range(1, 7))}
    for name in names:
        (tmp_path / name).write_bytes(b"UNFITTED report-boundary stub; not numerical evidence")
    reserved = 2 * sum((tmp_path / name).stat().st_size for name in names)
    reservation = {"worker_memory_estimate_bytes": 1, "coordinator_memory_estimate_bytes": 1,
        "future_retention_reserved_bytes": reserved}
    effective = sensitivity._a12_bootstrap_reader_policy(policy, reservation,
        execution_scratch_reserve_bytes=scratch_budget)
    reader = {"resource_reservation": copy.deepcopy(reservation), "effective_policy": effective,
        "executor_source_identity": sha256_bytes(canonical_json_bytes(f4._f45_source_member_sha256())),
        "execution_worker_memory_bytes": 2 * 1024**3,
        **({"execution_scratch_reserve_bytes": scratch_budget} if scratch_budget is not None else {}),
        "resource_observation": observation,
        "resource_admission": runtime.resource_admission(effective, observation, legal_tasks=6),
        "pool": {"status": "COMPLETED", "engine_threads": 1, "configured_worker_ceiling": 24,
            "admitted_worker_ceiling": 6, "completed_task_count": 6, "runnable_task_count": 6,
            "actual_worker_process_peak": 1}}
    if damage in reader["pool"]:
        reader["pool"][damage] = True if damage in {"engine_threads", "actual_worker_process_peak"} else float(reader["pool"][damage])
    elif damage == "reservation":
        reader["resource_reservation"]["worker_memory_estimate_bytes"] = 1.0
    elif damage == "effective_policy":
        reader["effective_policy"]["memory_bytes_per_worker"] = 1.0
    elif damage == "admission":
        reader["resource_admission"]["admitted_worker_ceiling"] = 6.0
    execution = {"kind": "PADML_F5_A12_FIXED_BOOTSTRAP_GATHER_V1", "resource_policy": policy,
        "executor_source_identity": reader["executor_source_identity"],
        "execution_worker_memory_bytes": 2 * 1024**3,
        **({"execution_scratch_reserve_bytes": scratch_budget} if scratch_budget is not None else {}),
        "resource_observation": observation, "archive_reserved_bytes": reserved,
        "resource_admission": runtime.resource_admission({**policy, "scratch_reserve_bytes": reserved if scratch_budget is None else 0,
            "memory_bytes_per_worker": 2 * 1024**3}, observation, legal_tasks=1),
        "new_rng_invocations": 0, "new_metric_engine_invocations": 0, "global_reduction_count": 1,
        "origin": {}, "numerical_reader_execution": reader}
    (tmp_path / "execution.json").write_bytes(canonical_json_bytes(execution))
    monkeypatch.setattr(sensitivity, "_validate_a12_handoff", lambda value: value)
    seen = []
    def collect(*args, execution_report, **kwargs):
        execution_report["resource_reservation"] = reservation
        seen.append("original-numerical-consumer-stub")
        return {}, {}, [], {}
    def reduce(*args, **kwargs):
        seen.append("reduction")
        return {"UNFITTED_REPORT_BOUNDARY": True}
    monkeypatch.setattr(sensitivity, "_collect_a12_bootstrap_shards", collect)
    monkeypatch.setattr(sensitivity, "_reduce_a12_incremental_value", reduce)
    options = {"resource_policy": policy, "retained_primary_point": {}, "primary_point_native": b"UNFITTED"}
    if damage is None:
        result = sensitivity._replay_a12_sharded_evaluation(tmp_path, {}, b"UNFITTED", **options)
        assert result["UNFITTED_REPORT_BOUNDARY"] is True and seen[-1] == "reduction"
    else:
        with pytest.raises(ContractError, match="F5_A12_BOOTSTRAP_READER_EXECUTION_INVALID"):
            sensitivity._replay_a12_sharded_evaluation(tmp_path, {}, b"UNFITTED", **options)
        assert seen == ["original-numerical-consumer-stub"]


@pytest.mark.parametrize("sharded", [False, True, "continuous", "legacy_resources",
    "initial", "initial_auto", "initial_reuse12", "initial_partial", "initial_duplicate", "continuous_auto",
    "continuous_auto_wrong_group",
    "bool_index", "overlap", "gap", "partial", "partial_dir", "partial_zip", "partial_link",
    "dangling_work"])
def test_original_four_branch_aggregate_zip_context_ledger_and_replay(tmp_path, monkeypatch, sharded):
    """Real aggregate ZIP/context/ledger; native primary and AAR model reads are UNFITTED stubs."""
    retained_options = {}
    if sharded == "initial_reuse12":
        first_root = tmp_path / "first-line"
        first_root.mkdir()
        _, _, first_calls, _, first_input, _, first_record = _prepare_unfitted_shared_b1000(first_root, monkeypatch)
        assert first_calls["UNFITTED_RNG"] == 1
        retained_options = {"retained_rng_archive": first_root / "preparation/rng.zip",
                            "retained_rng_preparation_record": first_record}
    calls, policy = _unfitted_metric_engines(monkeypatch)
    context, outers = _unfitted_six_aar()
    if sharded == "initial_reuse12":
        import test_aar_prepared_sources as prepared_fixtures
        science = nested._sealed({**{k: v for k, v in context["science_decision"].items() if k != "identity_sha256"},
            "twelve_month_development": nested._twelve_month_development_contract()})
        selected, registry = _six_outer_fixture()
        selected = [nested._sealed({**{k: v for k, v in row.items() if k != "identity_sha256"},
            "selection_horizon_months": 12, "science_decision_sha256": science["identity_sha256"]}) for row in selected]
        context["primary"] = nested.assemble_selected_ooc(selected, population_registry=registry)
        context["science_decision"] = science
        monkeypatch.setattr(prepared_fixtures, "_six_outer_fixture", lambda: (selected, registry))
        for row in outers:
            source = row["source"]["primary_source"]
            source["science_decision"] = science
            source["primary_development_lock"].update(selection_horizon_months=12,
                science_decision_binding={"science_decision_sha256": science["identity_sha256"]})
        point_handoff = {name: context["primary"][name] for name in ("patient_ids", "centers", "horizons", "survival")}
        context["primary_point"] = nested._sealed({**{k: v for k, v in context["primary_point"].items() if k != "identity_sha256"},
            "selected_ooc_sha256": context["primary"]["identity_sha256"], "selection_horizon_months": 12,
            "science_decision_sha256": science["identity_sha256"],
            "evaluation": _unfitted_evaluation(point_handoff, selection_horizon_months=12, science_decision=science)})
    science, registry = context["science_decision"], context["population_registry"]
    primary_inputs, aar_inputs, archives = {}, {}, []
    from test_aar_prepared_sources import _unfitted_prepared_aar_jobs, _unfitted_prepared_primary, _unfitted_prepared_numeric
    fixture_jobs = {}
    for outer, row in enumerate(outers, 1):
        primary_inputs[outer] = tmp_path / f"primary-input-{outer}.zip"
        write_deterministic_zip(primary_inputs[outer], {"o-fit-input.json": canonical_json_bytes({"science_decision": science})})
        row["source"]["primary_input_sha256"] = sha256_file(primary_inputs[outer])
        aar_inputs[outer] = tmp_path / f"aar-input-{outer}.zip"
        write_deterministic_zip(aar_inputs[outer], {"UNFITTED.json": canonical_json_bytes({"outer_fold": outer})})
        family = row["family"]
        total = {key: sum(science["fit_budget"][name]["per_outer_by_inherited_family"][family][key]
                    for name in ("a12_direct_total", "outer_selected_family_no_aar_redevelopment"))
                 for key in science["fit_budget"]["a12_direct_total"]["per_outer_by_inherited_family"][family]}
        row["source"]["mice_inputs"] = {f"UNFITTED-{i}": True for i in range(total["mice_chains"] // 20)}
        row["source"]["resource_policy"] = policy
        row["source"]["identity_sha256"] = sha256_bytes(canonical_json_bytes(row["source"]))
        if sharded:
            fixture_jobs[outer] = _unfitted_prepared_aar_jobs(tmp_path / f"UNFITTED-numbers-{outer}", row)
            members = {f"fits/{job['numbers_path'].name}": job["numbers_path"].read_bytes() for job in fixture_jobs[outer]}
        else:
            members = {name: b"UNFITTED model; not native evidence" for name in row["members"]}
        members["development/selector/development-input.json"] = canonical_json_bytes({"selector_path_count": 3840, "glmnet_call_count": 7680})
        if family in sensitivity._A12_TUNED_FAMILIES:
            for branch in nested.AAR_ESTIMANDS:
                name, search = (("search.json", {"path_execution_count": 3840, "glmnet_pilot_and_path_call_count": 7680})
                    if family == "ELASTIC_NET_COX" else ("result.json", {
                        "locked_training_refit_count": total["candidate_prediction_fits"] // 3,
                        "response_free_stopping_fit_count": total["stop_fits"] // 3}))
                members[f"search/{branch}/{name}"] = canonical_json_bytes(search)
        members["a12-outer.json"] = canonical_json_bytes(row)
        archive = tmp_path / f"aar-outer-{outer}.zip"
        write_deterministic_zip(archive, members)
        archives.append(archive)
    primary = tmp_path / "primary.zip"
    primary_record = {"kind": "PADML_F4_O_FIT_AGGREGATE_ARCHIVE_V4", "selected_ooc": context["primary"],
        "science_decision_sha256": science["identity_sha256"], "source_archives": context["source"]["primary_source_archives"],
        "evaluation": context["primary_point"], "native_metric_archive": {"member": "evaluation/metrics.zip",
            "sha256": sha256_bytes(context["primary_point_native"]), "size_bytes": len(context["primary_point_native"])},
        "identity_sha256": sha256_bytes(b"UNFITTED primary native receipt")}
    write_deterministic_zip(primary, {"o-fit-aggregate.json": canonical_json_bytes(primary_record),
                                    "evaluation/metrics.zip": context["primary_point_native"]})
    primary_sha = sha256_file(primary)
    frozen = {"response_csv": context["frozen"]["response_csv"], "centers": registry["centers_by_patient"],
        "registry": {"outer": [{"outer_fold": row["outer_fold"], "heldout_center": row["heldout_center"],
            "application_ids": registry["all_patient_ids"], "analysis_ids": row["training_ids"], "validation_ids": row["heldout_ids"]}
            for row in registry["outer"]]}}
    reads = {"UNFITTED_primary": 0, "UNFITTED_outer": []}
    compiled_inputs = {outer: {"UNFITTED_ORIGINAL_COMPILE_RECORD": outer} for outer in range(1, 7)}
    def primary_reader(path, **kwargs):
        assert sha256_file(path) == primary_sha and kwargs["input_bundles"] == primary_inputs
        assert kwargs["compiled_input_records"] is compiled_inputs
        if path != primary:
            assert all((path.parent / f"outer-o{outer}.zip").is_file() for outer in range(1, 7))
            assert all((path.parent / "evaluation" / name).is_file()
                       for name in sensitivity._a12_evaluation_member_names(nested=True, sharded=sharded))
        reads["UNFITTED_primary"] += 1
        native = kwargs["replay_evidence"] / "archive/evaluation/metrics.zip"
        native.parent.mkdir(parents=True)
        native.write_bytes(context["primary_point_native"])
        if sharded:
            _unfitted_prepared_primary(kwargs["replay_evidence"].parent, context)
        kwargs["_source_consumer"](frozen, registry)
        return primary_record
    def outer_reader(path, *, input_bundle, _prepared_consumer=None, execution_report=None):
        value = strict_json_bytes(read_safe_zip(path)["a12-outer.json"])
        assert input_bundle == aar_inputs[value["outer_fold"]]
        assert value == outers[value["outer_fold"] - 1]
        reads["UNFITTED_outer"].append(value["outer_fold"])
        if _prepared_consumer is not None:
            _prepared_consumer(value, fixture_jobs[value["outer_fold"]], sensitivity._a12_outer_archive_record(value, path))
        from test_aar_final_shards import _unfitted_a12_input_release
        assert execution_report == {}
        owner = path.parent / f"UNFITTED-input-release-{len(reads['UNFITTED_outer'])}-{value['outer_fold']}"
        binding = {"executor_source_identity": sha256_bytes(canonical_json_bytes(f4._f45_source_member_sha256())),
            "operation": "OUTER_REPLAY", "outer_fold": value["outer_fold"], "family": value["family"],
            "task_names": list(sensitivity._a12_final_task_coordinates(value["outer_fold"])),
            "input_archive": {"sha256": sha256_file(path), "size_bytes": path.stat().st_size},
            "projected_input": {"sha256": sha256_file(input_bundle), "size_bytes": input_bundle.stat().st_size},
            "projected_input_identity_sha256": value["source"]["identity_sha256"], "work_root": str(owner)}
        raw, _, _ = _unfitted_a12_input_release(owner, binding, value, policy)
        encoded = canonical_json_bytes({"input_execution": strict_json_bytes(raw), "UNFITTED_original_reader": True})
        report_path = owner / "execution.json"
        report_path.write_bytes(encoded)
        execution_report.update(path=str(report_path), sha256=sha256_bytes(encoded), size_bytes=len(encoded))
        return value
    monkeypatch.setattr(f4, "load_o_fit_aggregate_archive", primary_reader)
    monkeypatch.setattr(f4, "load_f4_inputs", lambda *args, **kwargs: pytest.fail("NO_MODEL_SOURCE_RECONSTRUCTION_AT_AGGREGATE"))
    monkeypatch.setattr(f4, "_load_f4_source_records", lambda *args, **kwargs:
        pytest.fail("A12 context must reuse the original primary consumer's source snapshot"))
    monkeypatch.setattr(f4, "_load_o_fit_frozen_source", lambda *args, **kwargs:
        pytest.fail("A12 context must not reload the primary consumer's frozen source"))
    monkeypatch.setattr(sensitivity, "_load_a12_outer_archive", outer_reader)
    if sharded:
        monkeypatch.setattr(sensitivity, "_read_a12_prepared_numerical_job", _unfitted_prepared_numeric)
    target = tmp_path / "paired.zip"
    common = {"f2_run_root": tmp_path, "primary_input_bundles": primary_inputs,
              "primary_compiled_input_records": compiled_inputs,
              "input_bundles": aar_inputs, "resource_policy": policy}
    shard_options = {}
    initial = isinstance(sharded, str) and sharded.startswith("initial")
    if initial:
        shared, points = tmp_path / "shared-input.zip", tmp_path / "shared-points.zip"
        shards = [tmp_path / f"bootstrap-{index}.zip" for index in range(6)]
        if sharded in {"initial_auto", "initial_reuse12"}:
            shared = target.with_name(target.stem + ".bootstrap-input.zip")
            points = shared.with_name(shared.stem + ".points.zip")
            shards = [shared.with_name(shared.stem + f".shard-{index}.zip") for index in range(1, 7)]
        pending = {index: list(range(index, 1001, 6)) for index in range(1, 7)}
        if sharded == "initial_partial":
            partial = shards[-1].with_name(shards[-1].name + ".work")
            partial.mkdir()
            (partial / "UNFITTED-failure").write_bytes(b"preserve")
        elif sharded == "initial_duplicate":
            pending[6].append(1)
        options = {**common, **retained_options, "sources": list(reversed(archives)),
            "retained_bytes_per_replicate": 2 * 1024**2, "bootstrap_input": shared,
            "point_archive": points, "bootstrap_shards": shards, "unstarted_replicates": pending}
        if sharded in {"initial_auto", "initial_reuse12"}:
            for name in ("bootstrap_input", "point_archive", "bootstrap_shards", "unstarted_replicates"):
                options.pop(name)
            options["complete_evaluation"] = True
        if sharded in {"initial_partial", "initial_duplicate"}:
            before = dict(calls)
            expected = ("F5_A12_BOOTSTRAP_PREPARATION_PATH_INVALID" if sharded == "initial_partial"
                        else "F5_A12_BOOTSTRAP_PROFILE_INVALID")
            with pytest.raises(ContractError, match=expected):
                sensitivity.execute_a12_bundle(primary, target, **options)
            assert calls == before and reads == {"UNFITTED_primary": 0, "UNFITTED_outer": []}
            assert not shared.exists() and not points.exists() and not target.exists()
            assert not target.with_name(target.name + ".work").exists()
            assert all(not path.exists() for path in shards)
            if sharded == "initial_partial":
                assert (partial / "UNFITTED-failure").read_bytes() == b"preserve"
            return
        produced = sensitivity.execute_a12_bundle(primary, target, **options)
        prepared = produced["prepared_input_record"]
        assert prepared["shared_rng_invocations"] == (0 if retained_options else 1)
        assert calls["UNFITTED_RNG"] == (0 if retained_options else 1)
        assert all(path.is_file() for path in shards)
        if retained_options:
            assert read_safe_zip(shared)["rng.zip"] == read_safe_zip(first_input)["rng.zip"]
            assert read_safe_zip(shared)["predictions.json"] != read_safe_zip(first_input)["predictions.json"]
        common = {"resource_policy": policy, "prepared_input_record": prepared}
    elif sharded:
        shared = tmp_path / "shared-input.zip"
        retained_rng = tmp_path / "first-rng.zip"
        # The standalone preparation below precedes the public primary reader,
        # so bind its fixture context to the actual six just-written ZIPs too.
        context["source"]["primary_input_sha256"] = {str(outer): sha256_file(path)
            for outer, path in primary_inputs.items()}
        opened_handoff = sensitivity._validate_a12_handoff(sensitivity._a12_handoff_from_outers(context, outers))
        f4.bootstrap_draws(opened_handoff["patient_ids"], opened_handoff["centers"], "FIXED_MODEL_PAIRED",
            patient_keys=opened_handoff["patient_keys"], retained_archive=retained_rng)
        first_rng_record = {"status": "PREPARED_FIXED_PREDICTIONS_AND_SHARED_DRAWS", "stage_acceptance": False,
            "shared_rng_invocations": 1, "new_model_fits": 0, "bootstrap_replicates_executed": 0,
            "f45_source_sha256": sha256_bytes(b"UNFITTED independently retained first producer"),
            "rng_archive": {"sha256": sha256_file(retained_rng), "size_bytes": retained_rng.stat().st_size}}
        prepared = sensitivity.execute_a12_bundle(primary, shared, sources=list(reversed(archives)),
            retained_bytes_per_replicate=2 * 1024**2, bootstrap_inputs_only=True,
            retained_rng_archive=retained_rng, retained_rng_preparation_record=first_rng_record, **common)
        assert prepared["bootstrap_replicates_executed"] == prepared["shared_rng_invocations"] == 0
        assert set(prepared["outer_input_execution"]) == {str(outer) for outer in range(1, 7)}
        shards = []
        for index in range(6):
            path = tmp_path / f"bootstrap-{index}.zip"
            if sharded is True or index == 0:
                start = 2 if sharded == "continuous_auto_wrong_group" else index + 1
                sensitivity.execute_a12_bootstrap_shard(shared, path, replicate_ids=list(range(start, 1001, 6)),
                    resource_policy=policy, retained_bytes_per_replicate=2 * 1024**2, prepared_input_record=prepared)
            shards.append(path)
        shard_options = {"bootstrap_input": shared, "point_archive": Path(prepared["point_archive"]["path"]),
            "bootstrap_shards": shards, "prepared_input_record": prepared}
        common = {"resource_policy": policy, "prepared_input_record": prepared}
        if isinstance(sharded, str):
            pending = {index: list(range(index, 1001, 6)) for index in range(2, 7)}
            if sharded == "bool_index":
                pending[True] = pending.pop(2)
            elif sharded == "overlap":
                pending[2].append(1)
            elif sharded == "gap":
                pending[2].pop()
            elif sharded == "partial":
                # A preserved partial shard is not an unstarted assignment.
                partial = shards[1].with_name(shards[1].name + ".work")
                partial.mkdir()
                (partial / "UNFITTED-failure").write_bytes(b"preserve")
            elif sharded == "dangling_work":
                # A later shard must reject before the preceding new shard runs.
                partial = shards[2].with_name(shards[2].name + ".work")
                missing_target = tmp_path / "UNFITTED-missing-work"
                partial.symlink_to(missing_target)
            elif sharded in {"partial_dir", "partial_zip", "partial_link"}:
                partial = tmp_path / "bootstrap-replicates" / "replicate-0002"
                if sharded == "partial_dir":
                    partial.mkdir()
                    (partial / "UNFITTED-failure").write_bytes(b"preserve")
                elif sharded == "partial_zip":
                    partial = partial.with_suffix(".zip")
                    partial.write_bytes(b"preserve")
                else:
                    retained = tmp_path / "UNFITTED-retained-partial"
                    retained.write_bytes(b"preserve")
                    partial.symlink_to(retained)
            shard_options.update(unstarted_replicates=pending,
                retained_bytes_per_replicate=2 * 1024**2,
                retained_rng_archive=retained_rng, retained_rng_preparation_record=first_rng_record)
            if sharded in {"continuous_auto", "continuous_auto_wrong_group"}:
                shard_options.pop("unstarted_replicates")
                shard_options["complete_evaluation"] = True
            prior_calls = dict(calls)
            original_shard = shards[0].read_bytes()
            if sharded not in {"continuous", "continuous_auto", "legacy_resources"}:
                expected = {
                    "continuous_auto_wrong_group": "F5_A12_BOOTSTRAP_PROFILE_INVALID",
                    "bool_index": "F5_A12_BOOTSTRAP_PROFILE_INVALID",
                    "gap": "F5_A12_BOOTSTRAP_PROFILE_INVALID",
                    "overlap": "F5_A12_BOOTSTRAP_COORDINATE_ALREADY_PRESENT",
                    "partial": "F5_A12_BOOTSTRAP_SHARD_PATH_INVALID",
                    "partial_dir": "F5_A12_BOOTSTRAP_COORDINATE_ALREADY_PRESENT",
                    "partial_zip": "F5_A12_BOOTSTRAP_COORDINATE_ALREADY_PRESENT",
                    "partial_link": "F5_A12_BOOTSTRAP_COORDINATE_ALREADY_PRESENT",
                    "dangling_work": "F5_A12_BOOTSTRAP_SHARD_PATH_INVALID",
                }[sharded]
                with pytest.raises(ContractError, match=expected):
                    sensitivity.execute_a12_bundle(shared, target, resource_policy=policy, **shard_options)
                assert calls == prior_calls
                assert shards[0].read_bytes() == original_shard
                assert not target.exists() and all(not path.exists() for path in shards[1:])
                if sharded in {"partial", "partial_dir"}:
                    assert (partial / "UNFITTED-failure").read_bytes() == b"preserve"
                elif sharded in {"partial_zip", "partial_link"}:
                    assert partial.read_bytes() == b"preserve"
                    if sharded == "partial_link":
                        assert partial.is_symlink()
                elif sharded == "dangling_work":
                    assert partial.is_symlink() and partial.readlink() == missing_target
                    assert not missing_target.exists()
                return
        produced = sensitivity.execute_a12_bundle(shared, target, resource_policy=policy, **shard_options)
        if isinstance(sharded, str):
            assert shards[0].read_bytes() == original_shard
    else:
        produced = sensitivity.execute_a12_bundle(primary, target, sources=list(reversed(archives)),
            retained_bytes_per_replicate=2 * 1024**2, **common)
    opened = read_safe_zip(target)
    value = strict_json_bytes(opened["a12.json"])
    assert produced["bootstrap_replicates"] == 1000 and produced["new_model_fits"] == 0
    assert set(produced["outer_input_execution"]) == (set() if sharded and not initial else {str(outer) for outer in range(1, 7)})
    assert "outer_input_execution" not in value
    assert value["actual_aar_execution_ledger"]["post_lock_fits"] == 360
    assert value["post_lock_model_fit_execution_count"] == 360 and value["post_lock_additional_stop_fit_execution_count"] == 0
    assert value["actual_aar_execution_ledger"]["stop_fits"] > 0 and value["evaluation_new_model_fit_count"] == 0
    assert not {"model_fit_count", "grid_search_count", "outer_model_fit_execution_count", "outer_stop_fit_execution_count"}.intersection(value)
    assert value["actual_aar_execution_ledger"]["elastic_path_executions"] == 6 * 3840 + 3 * 3840
    assert value["bootstrap"]["paired_row_count"] == 912 and "final_family" not in value
    assert value["metric_calibration_engine_invocations"] == 1001 and value["metric_scope_branch_job_count"] == 28021
    assert value["new_aar_point_metric_job_count"] == 21 and value["reused_primary_point_metric_job_count"] == 7
    assert value["primary_archive_point_metric_reexecution_count"] == 0
    assert value["stage_acceptance"] is False and value["full_data_model_independently_validated"] is False
    if sharded:
        assert "primary.zip" not in opened and not any(name.startswith("outer-o") for name in opened)
        assert "preparation-sources.json" in read_safe_zip(opened["evaluation/point-sources.zip"])
        assert value["replay_scope"].startswith("PREPARED_PRIMARY_AND_AAR_M20_NUMBERS")
    else:
        assert opened["primary.zip"] == primary.read_bytes()
    written = strict_json_bytes(opened["aggregate-execution.json"])
    assert type(written["execution_scratch_reserve_bytes"]) is int
    assert written["execution_scratch_reserve_bytes"] == 0
    if sharded == "legacy_resources":
        # A historical receipt keeps its original admission policy; the reader
        # must not reinterpret it as the current zero-scratch execution policy.
        written.pop("execution_scratch_reserve_bytes")
        written["resource_admission"] = runtime.resource_admission({**policy,
            "memory_bytes_per_worker": written["execution_worker_memory_bytes"],
            "scratch_reserve_bytes": policy["scratch_reserve_bytes"] + written["archive_reserved_bytes"]},
            written["resource_observation"], legal_tasks=1)
        opened = {**opened, "aggregate-execution.json": canonical_json_bytes(written)}
        target = tmp_path / "legacy-resources.zip"
        write_deterministic_zip(target, opened, stored_members={name for name in opened if name.endswith(".zip")})
    replay_execution = {}
    result, stored = sensitivity.replay_a12_bundle(target, replay_evidence=tmp_path / "review",
        execution_report=replay_execution, **common)
    assert set(replay_execution.get("outer_input_execution", {})) == (set() if sharded else {str(outer) for outer in range(1, 7)})
    assert result == stored == value
    assert reads == {"UNFITTED_primary": 1 if sharded else 2,
        "UNFITTED_outer": [6, 5, 4, 3, 2, 1] + ([] if sharded else [1, 2, 3, 4, 5, 6])}
    if sharded == "initial_reuse12":
        assert value["selection_horizon_months"] == 12
        assert stored["selection_horizon_months"] == 12
    expected_calls = {"UNFITTED_RNG": 0 if sharded == "initial_reuse12" else 1,
        "UNFITTED_METRICS": 1001, "metric_replays": 2006 if sharded else 2004}
    assert calls == expected_calls
    bad = tmp_path / "changed-predictions.zip"
    changed = {**opened, "predictions.json": opened["predictions.json"].replace(b'"PRIMARY"', b'"PRIMARX"')}
    assert len(changed["predictions.json"]) == len(opened["predictions.json"])
    write_deterministic_zip(bad, changed, stored_members={name for name in changed if name.endswith(".zip")})
    with pytest.raises(ContractError, match="AGGREGATE_PREDICTION_MISMATCH"):
        sensitivity.replay_a12_bundle(bad, replay_evidence=tmp_path / "failed-review", **common)
    assert calls == expected_calls
    assert (tmp_path / "failed-review/predictions.json").is_file()
    # A self-consistent forged reservation must fail before the first metric
    # archive is decoded, not only at final summary comparison.
    damaged_value = copy.deepcopy(value)
    if sharded:
        damaged_value["evaluation_execution"]["archive_reserved_bytes"] = 0
    else:
        damaged_value["evaluation_execution"]["resource_reservation"]["coordinator_memory_estimate_bytes"] = 0
    changed = {**opened, "a12.json": canonical_json_bytes(damaged_value),
        "evaluation/execution.json": canonical_json_bytes(damaged_value["evaluation_execution"])}
    written = strict_json_bytes(changed["aggregate-execution.json"])
    reserved = 2 * (sum(len(data) for name, data in changed.items()
        if name not in {"a12.json", "aggregate-execution.json"}) + len(changed["a12.json"]) + 1024 * (len(changed) - 2))
    written["archive_reserved_bytes"] = reserved
    written["resource_admission"] = runtime.resource_admission({**policy,
        "memory_bytes_per_worker": written["execution_worker_memory_bytes"],
        "scratch_reserve_bytes": (0 if "execution_scratch_reserve_bytes" in written
            else policy["scratch_reserve_bytes"] + reserved)},
        written["resource_observation"], legal_tasks=1)
    changed["aggregate-execution.json"] = canonical_json_bytes(written)
    bad_memory = tmp_path / "changed-memory.zip"
    write_deterministic_zip(bad_memory, changed, stored_members={name for name in changed if name.endswith(".zip")})
    with pytest.raises(ContractError, match="BOOTSTRAP_GATHER_EXECUTION_INVALID" if sharded else "BOOTSTRAP_EXECUTION_INVALID"):
        sensitivity.replay_a12_bundle(bad_memory, replay_evidence=tmp_path / "failed-memory-review", **common)
    assert calls == expected_calls
    assert (tmp_path / "failed-memory-review/evaluation" / ("bootstrap-input.zip" if sharded else "rng.zip")).is_file()


@pytest.mark.parametrize("damage", ["cpu", "memory", "scratch", "manual_workers", "retained_point_budget"])
def test_four_branch_resource_failures_preserve_boundary_and_evidence(tmp_path, monkeypatch, damage):
    context, outers = _unfitted_six_aar()
    handoff = sensitivity._a12_handoff_from_outers(context, outers)
    calls, policy = _unfitted_metric_engines(monkeypatch)
    root = tmp_path / "evaluation"
    options = {"resource_policy": policy, "retained_bytes_per_replicate": 2 * 1024**2,
        "retained_primary_point": context["primary_point"], "primary_point_native": context["primary_point_native"]}
    if damage in {"cpu", "memory", "scratch"}:
        observation = {"effective_cpus": 64, "available_memory_bytes": 10**12, "scratch_available_bytes": 10**12, "scratch_root": str(tmp_path)}
        observation[{"cpu": "effective_cpus", "memory": "available_memory_bytes", "scratch": "scratch_available_bytes"}[damage]] = 8
        monkeypatch.setattr(runtime, "observe_execution_resources", lambda root: observation)
    elif damage == "manual_workers":
        options["workers"] = 1
    else:
        options["retained_bytes_per_replicate"] = 16384
    with pytest.raises(ContractError):
        sensitivity.evaluate_a12_incremental_value(handoff, context["evaluation_response_csv"], formal=True, evidence_root=root, **options)
    if damage == "retained_point_budget":
        assert calls["UNFITTED_METRICS"] == calls["UNFITTED_RNG"] == 1
        assert (root / "point-native.zip").is_file() and (root / "execution.json").is_file()
        assert not (root / "replicate-0001.zip").exists()
    else:
        assert calls == {"UNFITTED_RNG": 0, "UNFITTED_METRICS": 0, "metric_replays": 0}
        assert not root.exists()


@pytest.mark.parametrize("action", ["a12-bootstrap-inputs", "a12-aggregate", "a12-review"])
@pytest.mark.parametrize("retained", [False, True])
def test_original_f5_public_paired_entries_forward_native_sources(tmp_path, monkeypatch, capsys, action, retained):
    source, target, policy_path = (tmp_path / name for name in ("input.zip", "result.zip", "policy.json"))
    policy = {"UNFITTED": "routing only"}
    policy_path.write_bytes(canonical_json_bytes(policy))
    prepared = {"status": "UNFITTED", "stage_acceptance": False}
    prepared_path = tmp_path / "prepared.json"
    prepared_path.write_bytes(canonical_json_bytes(prepared))
    primaries = [tmp_path / f"primary-{i}.zip" for i in range(1, 7)]
    compiled_paths = [tmp_path / f"compiled-{i}.json" for i in range(1, 7)]
    compiled_records = {outer: {"UNFITTED_ORIGINAL_COMPILE_RECORD": outer} for outer in range(1, 7)}
    for outer, path in enumerate(compiled_paths, 1):
        path.write_bytes(canonical_json_bytes(compiled_records[outer]))
    aar_inputs = [tmp_path / f"aar-input-{i}.zip" for i in range(1, 7)]
    archives = [tmp_path / f"outer-{i}.zip" for i in range(1, 7)]
    seen = []
    def execute(*args, **kwargs):
        seen.append((args, kwargs))
        value = {"status": "UNFITTED", "stage_acceptance": False}
        return (value, value) if action == "a12-review" else value
    monkeypatch.setattr(sensitivity, "replay_a12_bundle" if action == "a12-review" else "execute_a12_bundle", execute)
    argv = ["padml-f5", action, str(source), *([str(target)] if action != "a12-review" else []),
        "--resource-policy", str(policy_path)]
    if retained:
        argv += ["--retained-primary-source-bundle", str(tmp_path / "old-primary-source.zip")]
    if action == "a12-bootstrap-inputs":
        if retained:
            argv += ["--retained-rng-archive", str(tmp_path / "old-rng.zip"),
                     "--retained-rng-preparation-record", str(prepared_path)]
        argv += ["--primary-input-bundles", *map(str, primaries), "--input-bundles", *map(str, aar_inputs),
            "--primary-compiled-input-records", *map(str, compiled_paths), "--f2-run-root", str(tmp_path),
            "--sources", *map(str, archives), "--retained-bytes-per-replicate", "2097152"]
    else:
        argv += ["--prepared-input-record", str(prepared_path)]
        if action == "a12-review":
            argv += ["--replay-evidence", str(tmp_path / "review")]
    if action == "a12-aggregate":
        argv += ["--point-archive", str(tmp_path / "point.zip"),
                 "--bootstrap-shards", *map(str, [tmp_path / f"shard-{i}.zip" for i in range(6)])]
    monkeypatch.setattr(sys, "argv", argv)
    f5.main()
    options = {"resource_policy": policy}
    if retained:
        options["retained_primary_source_bundle"] = tmp_path / "old-primary-source.zip"
    if action == "a12-bootstrap-inputs":
        if retained:
            options["retained_rng_archive"] = tmp_path / "old-rng.zip"
            options["retained_rng_preparation_record"] = prepared
        options.update(f2_run_root=tmp_path, f1_runtime_root=None, primary_input_bundles=dict(enumerate(primaries, 1)),
            primary_compiled_input_records=compiled_records, input_bundles=dict(enumerate(aar_inputs, 1)),
            sources=archives, retained_bytes_per_replicate=2097152, bootstrap_inputs_only=True)
    elif action == "a12-aggregate":
        options.update(bootstrap_input=source, point_archive=tmp_path / "point.zip", prepared_input_record=prepared,
            bootstrap_shards=[tmp_path / f"shard-{i}.zip" for i in range(6)])
    else:
        options.update(replay_evidence=tmp_path / "review", prepared_input_record=prepared, execution_report={})
    assert seen == [((source,) if action == "a12-review" else (source, target), options)]
    stdout = capsys.readouterr().out
    assert json.loads(stdout)["stage_acceptance"] is False
    if action == "a12-bootstrap-inputs":
        assert stdout.encode() == canonical_json_bytes(prepared)
        prepared_path.write_bytes(stdout.encode())
        followup = []
        def shard(*args, **kwargs):
            followup.append(kwargs["prepared_input_record"])
            return {"stage_acceptance": False}
        monkeypatch.setattr(sensitivity, "execute_a12_bootstrap_shard", shard)
        monkeypatch.setattr(sys, "argv", ["padml-f5", "a12-bootstrap-shard", str(source), str(target),
            "--resource-policy", str(policy_path), "--prepared-input-record", str(prepared_path),
            "--replicate-ids", "2", "--retained-bytes-per-replicate", "2097152"])
        f5.main()
        assert followup == [prepared]
        assert json.loads(capsys.readouterr().out)["stage_acceptance"] is False


@pytest.mark.parametrize("action", ["a12-bootstrap-shard", "a12-bootstrap-review"])
def test_original_f5_bootstrap_shard_entries_keep_original_ids(tmp_path, monkeypatch, capsys, action):
    source, target, policy_path = (tmp_path / name for name in ("input.zip", "output.zip", "policy.json"))
    policy = {"UNFITTED": "routing only"}
    policy_path.write_bytes(canonical_json_bytes(policy))
    prepared = {"UNFITTED_ORIGINAL_PREPARATION_RETURN": True}
    prepared_path = tmp_path / "prepared.json"
    prepared_path.write_bytes(canonical_json_bytes(prepared))
    calls = []
    def execute(*args, **kwargs):
        calls.append((args, kwargs))
        return {"stage_acceptance": False, "identity_sha256": "f" * 64, "replicate_ids": [2, 997]}
    monkeypatch.setattr(sensitivity, "execute_a12_bootstrap_shard" if action == "a12-bootstrap-shard"
                        else "replay_a12_bootstrap_shard", execute)
    argv = ["padml-f5", action, str(source), "--resource-policy", str(policy_path), "--prepared-input-record", str(prepared_path)]
    argv += ([str(target), "--replicate-ids", "997", "2", "--retained-bytes-per-replicate", "2097152"]
             if action == "a12-bootstrap-shard" else
             ["--input-bundle", str(tmp_path / "shared.zip"), "--replay-evidence", str(tmp_path / "review")])
    monkeypatch.setattr(sys, "argv", argv)
    f5.main()
    assert calls == ([((source, target), {"replicate_ids": [997, 2], "resource_policy": policy,
        "retained_bytes_per_replicate": 2097152, "prepared_input_record": prepared})] if action == "a12-bootstrap-shard" else
        [((source, tmp_path / "shared.zip", tmp_path / "review"), {"resource_policy": policy, "prepared_input_record": prepared})])
    assert json.loads(capsys.readouterr().out)["stage_acceptance"] is False


@pytest.mark.parametrize("failure", ["interrupt", "nonzero", "invalid_draw"])
def test_first_rng_preserves_input_and_partial_native_output_on_failure(tmp_path, monkeypatch, failure):
    context, outers = _unfitted_six_aar()
    opened = sensitivity._validate_a12_handoff(sensitivity._a12_handoff_from_outers(context, outers))
    calls = []
    def fail(command, **options):
        calls.append(command)
        options["stdout"].write(b'{"partial":true}')
        options["stderr"].write(b"UNFITTED partial RNG diagnostics")
        if failure == "interrupt":
            raise KeyboardInterrupt("UNFITTED interruption")
        return SimpleNamespace(returncode=1 if failure == "nonzero" else 0)
    monkeypatch.setattr(f4.subprocess, "run", fail)
    path = tmp_path / "rng.zip"
    with pytest.raises(KeyboardInterrupt if failure == "interrupt" else ContractError):
        f4.bootstrap_draws(opened["patient_ids"], opened["centers"], "FIXED_MODEL_PAIRED", replicate_count=1000,
            patient_keys=opened["patient_keys"], retained_archive=path)
    roots = list(tmp_path.glob("f4-bootstrap-*"))
    assert len(calls) == len(roots) == 1
    assert (roots[0] / "stdout.txt").read_bytes() == b'{"partial":true}'
    assert (roots[0] / "stderr.txt").read_bytes() == b"UNFITTED partial RNG diagnostics"
    assert strict_json_bytes((roots[0] / "input.json").read_bytes())["root_seed"] == 700000001
    assert (roots[0] / "f4_bootstrap.R").read_bytes() == (Path(f4.__file__).parent / "kernels/f4_bootstrap.R").read_bytes()
    assert path.exists() is (failure != "interrupt")


# Current-lock A04 line transport/reduction fixtures; no scientific engine runs.
@pytest.fixture
def _a04_line_fixture(tmp_path,monkeypatch):
    import copy
    from padml import f5_a04_current as module, f4, f5_sensitivity as sens, integrated, runtime
    from padml.bundle import canonical_json_bytes, strict_json_bytes, write_deterministic_zip, sha256_bytes
    from padml.f5_mice_variants import VARIANTS
    h=12;centers=['36','38','39','48','52','54'];ids=[f'{c}-{i}' for c in centers for i in range(2)]
    unit={'unit_id':f'EVALUATION-H{h:02d}','kind':'EVALUATION','horizon':h}
    units=[{'unit_id':f'PRIMARY-H{h:02d}-O{o}','kind':'PRIMARY','horizon':h,'outer_fold':o} for o in range(1,7)]
    run={'kind':'PADML_INTEGRATED_RAW_RUN_V1','run_root':str(tmp_path),'run_id':'UNFITTED_A04',
        'identity':'a'*64,'source_identity':'b'*64,'units':[unit,*units],
        'raw_input':{'UNFITTED':True},'post_result_repair':f4.post_result_repair_decision(),
        'resource_policy':{'scratch_bytes_per_worker':2*1024**3}}
    def admission(policy,root,**estimates):
        assert policy is run['resource_policy'] and estimates['legal_tasks']==1
        assert estimates['memory_bytes_per_worker'] >= 1024**3
        assert estimates['transient_bytes_per_worker'] >= 2*1024**3
        assert estimates['retained_bytes'] >= 0 and estimates['publication_bytes'] >= 0
        return {'admitted_worker_ceiling':1}
    monkeypatch.setattr(runtime,'admit_stage',admission)
    root=tmp_path/'units'/unit['unit_id'];root.mkdir(parents=True)
    response=('Patient_ID,All_Cause_Death,Death_Followup_months\n'+''.join(f'{p},{i%2},30\n' for i,p in enumerate(ids))).encode()
    matrix=[[1.]+[.9 if i%2==0 else .8]*36 for i in range(12)]
    variants={'patient_ids':ids,'centers':[c for c in centers for _ in range(2)],'horizons':list(range(37)),
              'survival':{v:copy.deepcopy(matrix) for v in VARIANTS}}
    negative=[];outers=[];projections=[]
    families=['COX_PH','RSF','GBM_COX','XGBOOST_COX','COXTIME_SET_A','FPM_TVC_SET_A']
    for o,(u,c,family) in enumerate(zip(units,centers,families),1):
        source={'unit_id':u['unit_id'],'raw_binding_identity':'RAW_ID','selected_family':family}
        predictions=[{'patient_ids':ids[(o-1)*2:o*2],'centers':[c,c],'horizons':list(range(37)),
            'survival':[[1.]+[a]*36,[1.]+[b]*36]} for a,b in ((.9,.8),(.8,.9),(.5,.5))]
        outer={'source':source,'family':family,'outer_fold':o,'predictions':predictions}
        outers.append(outer)
        projection={'source':source,'development_lock':{'selected_family':family},'negative':outer,
            'p2c2t':{'UNFITTED_STABILITY':{'registry':{'tasks':[{'task_id':f'S{o}','sample_fraction':.5}]},
                'task_results':[{'status':'PASS','finite':True,'mean_ibs':.21,'maximum_ibs':.22,
                    'pooled_metric_values':[.21],'pooled_metric_qc':[{'status':'PASS'}],
                    'partition_metrics':[{'mean_ibs':.21}],'warning_count':0}]}}}
        projections.append(projection)
        p=tmp_path/'units'/u['unit_id']/'post-result-repair-20261008/a04/evaluation.json';p.parent.mkdir(parents=True)
        p.write_bytes(canonical_json_bytes({'UNFITTED':u['unit_id']}))
    for i in range(3):
        handoff={'patient_ids':ids,'centers':variants['centers'],'horizons':list(range(37)),
                 'survival':{'NEGATIVE_CONTROL':[r for outer in outers for r in outer['predictions'][i]['survival']]}}
        negative.append((handoff,response))
    handoffs={'sources':[{'source':p['source'],'selected_family':f} for p,f in zip(projections,families)],
              'variants':variants,'negative':negative}
    def metric(v):return {'status':'ESTIMABLE','value':v,'reasons':[]}
    def evaluation(handoff):
        return {'status':'COMPUTED','model_refit_count':0,'selection_horizon_months':24,
            'scopes':[{'scope':c,'patient_count':12 if c=='MICRO' else 2,
                'families':{name:{'discrimination':{'uno_c_24':metric(.5),'auc':{'24':metric(.5)}},
                    'ibs_0_to':{'24':.2}} for name in handoff['survival']}}
                for c in ['MICRO',*centers]]}
    calls=[];checks=[]
    def read(path,r,u,**kw):
        assert r is run and u in units and not kw
        return projections[u['outer_fold']-1]
    def assemble(rows,*,horizons):
        assert rows==projections and horizons==(h,)
        return {h:handoffs}
    monkeypatch.setattr(module,'read_current_a04_evaluation',read)
    monkeypatch.setattr(module,'current_a04_handoffs',assemble)
    monkeypatch.setattr(integrated,'same_batch_generations',lambda r:{r['identity']:r['source_identity']})
    frozen={'receipt':{'run_id':run['run_id'],'source_identity':run['source_identity'],'identity':'RAW_ID'},
        'response_csv':response,'centers':dict(zip(ids,variants['centers']))}
    monkeypatch.setattr(integrated,'load_raw_binding',lambda *a,**kw:frozen)
    def evaluate(handoff,raw,**kwargs):
        # A04 must keep the default 24-month consumer, regardless of line h.
        assert not set(kwargs).intersection({'selection_horizon_months','science_decision'})
        signature=canonical_json_bytes({'handoff':handoff,'response_sha256':sha256_bytes(raw)})
        if 'replay_native_archive' in kwargs:
            path=kwargs['replay_native_archive'];calls.append(('replay',path.name))
            with f4.open_carrier(path) as archive:
                assert archive.read('UNFITTED.json')==signature
        else:
            path=kwargs['native_archive'];calls.append(('new',path.name))
            write_deterministic_zip(path,{'UNFITTED.json':signature})
        return evaluation(handoff)
    def validate(value,handoff,raw,*,native_archive,**kwargs):
        assert kwargs==({'a04_variants':True} if 'LOG_DONOR5' in handoff['survival'] else {'a04_negative':True})
        assert native_archive.is_file() and value==evaluation(handoff)
        checks.append(native_archive.name)
    monkeypatch.setattr(f4,'evaluate_predictions',evaluate)
    monkeypatch.setattr(sens,'_validate_a12_native_evaluation',validate)
    return module,run,unit,root,projections,handoffs,outers,evaluation,calls,checks


def test_current_a04_line_only_missing_native_metrics_then_exact_completion(tmp_path,monkeypatch,_a04_line_fixture):
    from padml import f4
    from padml.bundle import sha256_file
    module,run,unit,root,projections,line,outers,evaluation,calls,checks=_a04_line_fixture
    actual=f4.evaluate_predictions
    def interrupt(handoff,*a,**kw):
        if 'NEGATIVE_CONTROL' in handoff['survival']:raise RuntimeError('UNFITTED_INTERRUPTION')
        return actual(handoff,*a,**kw)
    monkeypatch.setattr(f4,'evaluate_predictions',interrupt)
    with pytest.raises(RuntimeError,match='UNFITTED_INTERRUPTION'):module.run_current_a04_line(run,unit,root)
    first=root/'post-result-repair-20261008/a04-metrics/variants.zip';raw=first.read_bytes();stamp=first.stat()
    assert not (root/'post-result-repair-20261008/a04-summary.json').exists()
    monkeypatch.setattr(f4,'evaluate_predictions',actual);calls.clear();checks.clear()
    result=module.run_current_a04_line(run,unit,root)
    assert calls==[('replay','variants.zip'),*[('new',f'negative-P{i}.zip') for i in range(1,4)]]
    assert len(checks)==4 and first.read_bytes()==raw and first.stat().st_ino==stamp.st_ino and first.stat().st_mtime_ns==stamp.st_mtime_ns
    assert result['a04_metric_horizon']==24 and result['development_horizon']==12
    assert len({r['selected_family'] for r in result['source_policies']})==6 and 'final_family' not in result
    assert result['new_prediction_model_fits']==result['new_mice_chains']==result['new_shap_solves']==0
    assert len(result['formal_references'])==10 and len(result['negative_controls']['risk_correlations_descriptive_only'])==18
    assert result['review_status']=='PENDING_FOUR_LINE_A04_REVIEW' and not result['stage_acceptance']
    assert len(result['stability_diagnostics']['scopes'])==6
    assert all(v['components']['UNFITTED_STABILITY'][0]['metrics']['mean_ibs']==.21
        and v['components']['UNFITTED_STABILITY'][0]['coordinate']['sample_fraction']==.5
        for v in result['stability_diagnostics']['scopes'])
    def forbidden(*a,**kw):pytest.fail('completed numerical consumer cannot compute or load MICE/models')
    monkeypatch.setattr(f4,'evaluate_predictions',forbidden)
    monkeypatch.setattr(module,'read_current_a04_evaluation',forbidden)
    assert module.run_current_a04_line(run,unit,root)==result
    first.write_bytes(raw+b'UNFITTED_DRIFT')
    from padml.bundle import ContractError
    with pytest.raises(ContractError,match='DRIFT'):module.run_current_a04_line(run,unit,root)


@pytest.mark.parametrize('values,center_only,expected',[
    ((.65,.5,.5),False,'PASS'),((.6,.6,.6),False,'PASS'),
    ((.600001,.600001,.600001),False,'HARD_REVIEW_REQUIRED'),
    ((.650001,None,.5),False,'HARD_REVIEW_REQUIRED'),
    ((.5,None,.5),False,'BLOCKED_POOLED_NOT_ESTIMABLE'),
    ((.5,None,.5),True,'PASS')])
def test_current_a04_negative_original_threshold_na_and_correlations(_a04_line_fixture,values,center_only,expected):
    import copy
    from padml.f5_negative_controls import _negative_evaluation_summary
    _,_,_,_,_,line,outers,evaluation,_,_=_a04_line_fixture
    handoffs=[h for h,_ in line['negative']];evaluations=[evaluation(h) for h in handoffs]
    for i,val in enumerate(values):
        row=next(r for r in evaluations[i]['scopes'] if r['scope']==('36' if center_only else 'MICRO'))
        metric={'value':val,'status':'ESTIMABLE' if val is not None else 'NOT_ESTIMABLE',
                'reasons':[] if val is not None else ['CASES_BELOW_20']}
        row['families']['NEGATIVE_CONTROL']['discrimination']['uno_c_24']=metric
        row['families']['NEGATIVE_CONTROL']['discrimination']['auc']['24']=copy.deepcopy(metric)
    result=_negative_evaluation_summary(outers,evaluations,handoffs)
    assert result['gate_status']==expected
    assert result['blocking_for_production']==(expected!='PASS')
    row=result['scopes']['36' if center_only else 'MICRO']['auc_24']
    assert row['denominator']==3 and row['estimable_count']==sum(v is not None for v in values)
    assert (row['arithmetic_mean'] is None)==any(v is None for v in values)
    correlations=result['risk_correlations_descriptive_only']
    assert len(correlations)==18
    assert [c['indices'] for c in correlations[:3]]==[[1,2],[1,3],[2,3]]
    assert sum(c['rho'] is None for c in correlations)==12
    assert all(c['trigger'] is None for c in correlations)


def test_current_a04_negative_common_reducer_keeps_legacy_result_exact(monkeypatch,_a04_line_fixture):
    from padml import f5_negative_controls as negative
    _,_,_,_,_,line,outers,evaluation,_,_=_a04_line_fixture
    handoffs=[h for h,_ in line['negative']];evaluations=[evaluation(h) for h in handoffs]
    expected=negative._negative_evaluation_summary(outers,evaluations,handoffs)
    monkeypatch.setattr(negative,'negative_handoff',lambda context,rows,index:(handoffs[index-1],b'UNFITTED'))
    monkeypatch.setattr(negative,'_source',lambda context:{'UNFITTED_LEGACY_SOURCE':True})
    legacy=negative.negative_result({'lineage':{'final_family':'UNFITTED_LEGACY_LABEL'}},
        [{**row,'original_log_donor5':{'UNFITTED':True}} for row in outers],evaluations)
    for key,value in expected.items():assert legacy[key]==value
    assert legacy['model_fit_count']==18 and legacy['mice_chain_execution_count']==36


@pytest.mark.parametrize('damage',['projection','raw_binding'])
def test_current_a04_line_input_drift_stops_before_native(monkeypatch,_a04_line_fixture,damage):
    from padml.bundle import ContractError
    module,run,unit,root,projections,_,_,_,calls,checks=_a04_line_fixture
    if damage=='projection':
        def drift(*a,**kw):raise ContractError('A04_CURRENT_EVALUATION_NUMBERS_DRIFT')
        monkeypatch.setattr(module,'read_current_a04_evaluation',drift)
    else:projections[-1]['source']['raw_binding_identity']='FOREIGN_RAW_BINDING'
    with pytest.raises(ContractError,match='DRIFT'):module.run_current_a04_line(run,unit,root)
    assert calls==checks==[]
    assert not (root/'post-result-repair-20261008/a04-summary.json').exists()


def test_current_a04_metric_admission_zero_prevents_native_call(monkeypatch,_a04_line_fixture):
    from padml import runtime
    from padml.bundle import ContractError
    module,run,unit,root,_,_,_,_,calls,checks=_a04_line_fixture
    def exhausted(*a,**kw):raise ContractError('RESOURCE_ADMISSION_ZERO:UNFITTED_SPACE')
    monkeypatch.setattr(runtime,'admit_stage',exhausted)
    with pytest.raises(ContractError,match='RESOURCE_ADMISSION_ZERO'):
        module.run_current_a04_line(run,unit,root)
    assert calls==checks==[]
