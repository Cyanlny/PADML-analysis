"""Synthetic direct S2 publisher/worker tests; no model, metric or RNG call."""
import copy
import json
from pathlib import Path

import pytest

from padml import f2_kernel as kernel, f4, f5, runtime
from padml.bundle import ContractError, canonical_json_bytes, sha256_bytes, sha256_file, read_safe_zip, write_deterministic_zip
from test_primary_outer12_rsf_inputs import _call
from test_primary_outer12_rsf_prepared_pipeline import POLICY


def _published(tmp_path, monkeypatch, *, stage="S2", publication_capture=None, outer=2):
    base = _call(tmp_path, outer=outer)
    for imp in range(2, 6 if stage == "S2" else 21):
        (tmp_path / "covariates" / f"imp{imp:02d}.csv").write_bytes((tmp_path / "covariates/imp01.csv").read_bytes())
    original = copy.deepcopy(base[0])
    original.pop("action")
    original.update(threads=56, pool_workers=56, engine_threads=1, execution_mode="PROCESS_POOL",
                    monthly_fit_horizons=list(range(1, 37)))
    child = kernel._r_prediction_child_spec(original)
    child.pop("native_search_root"); child.pop("native_search_replay")
    calls, tasks = [], {}
    for first in ((1, 4, 7) if stage == "S2" else (1,)):
        for part in range(1, 16 if stage in {"S3B1", "S3B2"} else 6):
            for imp in range(1, 6 if stage in {"S2", "S3B1"} else 21, 4 if stage == "S3B2" else 1):
                call = [child, *copy.deepcopy(base[1:])]
                repeat = (part - 1) // 5 + 1 if stage in {"S3B1", "S3B2"} else 2 if stage == "S2" else 3
                inner_fold = (part - 1) % 5 + 1 if stage in {"S3B1", "S3B2"} else part
                identifier = f"INNER_F{outer}_R{repeat}_K{inner_fold}"
                for row in (call[1]["partitions"][0], call[6]):
                    row.update(partition_id=identifier, repeat=repeat, inner_fold=inner_fold)
                call[1]["projected_partition_ids"] = [identifier]
                call[2] = [{"task_id": f"{stage}_T{trial:03d}_P{part:02d}_M{imp:02d}", "family": "RSF",
                    "partition_id": identifier, "imputation": imp, "seed": original["seed"] + (40000 if stage == "S3B1" else repeat * 10000) + 100 * imp + part,
                    "selected_parents": ["AST_ALT"], "parameters": {"UNFITTED": trial},
                    "prediction_horizons": list(range(1, 37))} for trial in ((1, 2) if stage == "S3B1" else range(first, min(first + 3, 9)))]
                if stage == "S3B2":
                    call[2] = [{"task_id": f"S3B2_T001_P{part:02d}_M{mi:02d}", "family": "RSF",
                        "partition_id": identifier, "imputation": mi, "seed": original["seed"] + 50000 + 100 * mi + part,
                        "selected_parents": ["AST_ALT"], "parameters": {"UNFITTED": 1},
                        "prediction_horizons": list(range(1, 37))} for mi in range(imp, imp + 4)]
                name = "batch-" + sha256_bytes(canonical_json_bytes([row["task_id"] for row in call[2]]))[:24]
                tasks[name] = call[2]; calls.append(call)
    q = tmp_path / "q"; q.mkdir()
    raw = canonical_json_bytes({"kind": "PADML_F5_Q_INPUT_V1", "spec": original, "task": {"UNFITTED": True}})
    (q / "input.json").write_bytes(raw)
    prep, producer = tmp_path / "preparation.zip", tmp_path / "producer.zip"
    prep.write_bytes(b"UNFITTED_PREPARATION"); producer.write_bytes(b"UNFITTED_PRODUCER")
    evidence = {}
    for name in ("source/primary-s2-producer.zip", "source/primary-q-producer.zip"):
        p = tmp_path / name; p.parent.mkdir(exist_ok=True); p.write_bytes(b"UNFITTED_SOURCE"); evidence[name] = p
    executions = []
    for host in ("H0", "H1", "H4", "H5", "H6", "H7", "H9-2"):
        name = f"primary-s2/{host}-execution.json"; p = tmp_path / name; p.parent.mkdir(exist_ok=True)
        p.write_bytes(canonical_json_bytes({"UNFITTED": host})); evidence[name] = p
        executions.append(sha256_file(p))
    name = "primary-s2/report.json"; p = tmp_path / name
    p.write_bytes(canonical_json_bytes({"predecessor_execution_sha256": executions,
        "consumed_s1_model_coordinates": 120, "original_q_boundary": {"confirmed_stop_fits": 0}})); evidence[name] = p
    expected = {name: path.read_bytes() for name, path in evidence.items()}
    s3a = None
    if stage in {"S3A", "S3B1", "S3B2"}:
        s3a = {}
        for host in ("H0", "H1", "H4", "H5", "H6", "H7", "H9-2"):
            p = tmp_path / "primary-s3a" / f"{host}-execution.json"; p.parent.mkdir(exist_ok=True)
            p.write_bytes(canonical_json_bytes({"UNFITTED_S2": host})); s3a[f"primary-s3a/{host}-execution.json"] = p
        executions = [sha256_file(p) for p in s3a.values()]
        p = tmp_path / "primary-s3a/report.json"
        p.write_bytes(canonical_json_bytes({"predecessor_execution_sha256": executions,
            "original_q_boundary": {"new_model_fits": 0, "worker_inputs_ready": False,
                                   "model_coordinate_count": 300}})); s3a["primary-s3a/report.json"] = p
        p = tmp_path / "source/primary-s3a-producer.zip"; p.write_bytes(b"UNFITTED_S3A_PRODUCER")
        s3a["source/primary-s3a-producer.zip"] = p
    expected_s3a = {name: path.read_bytes() for name, path in s3a.items()} if s3a is not None else None
    s3b1 = None
    if stage in {"S3B1", "S3B2"}:
        s3b1 = {}
        for host in ("H0", "H1", "H4", "H5", "H6", "H7", "H9-2"):
            p = tmp_path / "primary-s3b1" / f"{host}-execution.json"; p.parent.mkdir(exist_ok=True)
            p.write_bytes(canonical_json_bytes({"UNFITTED_S3A": host})); s3b1[f"primary-s3b1/{host}-execution.json"] = p
        executions = [sha256_file(p) for p in s3b1.values()]
        p = tmp_path / "primary-s3b1/report.json"
        p.write_bytes(canonical_json_bytes({"predecessor_execution_sha256": executions,
            "original_q_boundary": {"new_model_fits": 0, "worker_inputs_ready": False,
                                   "model_coordinate_count": 150}})); s3b1["primary-s3b1/report.json"] = p
        p = tmp_path / "source/primary-s3b1-producer.zip"; p.write_bytes(b"UNFITTED_S3B1_PRODUCER")
        s3b1["source/primary-s3b1-producer.zip"] = p
    expected_s3b1 = {name: path.read_bytes() for name, path in s3b1.items()} if s3b1 is not None else None
    s3b2 = None
    if stage == "S3B2":
        s3b2 = {}
        for host in ("H0", "H1", "H4", "H5", "H6", "H7", "H9-2"):
            p = tmp_path / "primary-s3b2" / f"{host}-execution.json"; p.parent.mkdir(exist_ok=True)
            p.write_bytes(canonical_json_bytes({"UNFITTED_S3B1": host})); s3b2[f"primary-s3b2/{host}-execution.json"] = p
        executions = [sha256_file(p) for p in s3b2.values()]
        p = tmp_path / "primary-s3b2/report.json"
        p.write_bytes(canonical_json_bytes({"predecessor_execution_sha256": executions,
            "original_q_boundary": {"new_model_fits": 0, "worker_inputs_ready": False,
                                   "model_coordinate_count": 300}})); s3b2["primary-s3b2/report.json"] = p
        p = tmp_path / "source/primary-s3b2-producer.zip"; p.write_bytes(b"UNFITTED_S3B2_PRODUCER")
        s3b2["source/primary-s3b2-producer.zip"] = p
    expected_s3b2 = {name: path.read_bytes() for name, path in s3b2.items()} if s3b2 is not None else None
    def binding(value, prepared, source, *, s2_evidence=None, s3a_evidence=None, s3b1_evidence=None, s3b2_evidence=None):
        if (value != raw or prepared.read_bytes() != b"UNFITTED_PREPARATION"
                or source.read_bytes() != b"UNFITTED_PRODUCER" or s2_evidence is None
                or {name: path.read_bytes() for name, path in s2_evidence.items()} != expected
                or ({name: path.read_bytes() for name, path in s3a_evidence.items()}
                    if s3a_evidence is not None else None) != expected_s3a
                or ({name: path.read_bytes() for name, path in s3b1_evidence.items()}
                    if s3b1_evidence is not None else None) != expected_s3b1
                or ({name: path.read_bytes() for name, path in s3b2_evidence.items()}
                    if s3b2_evidence is not None else None) != expected_s3b2):
            raise ContractError("UNFITTED_S2_EVIDENCE_DRIFT")
        return child, tasks
    # Only this synthetic source fixture is substituted; real retained bytes
    # are checked separately on the formal custody host without fitting.
    monkeypatch.setattr(f5, "_primary_rsf_prepared_input", binding)
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda root: {
        "effective_cpus": 32, "available_memory_bytes": 128 * 1024**3,
        "scratch_available_bytes": 128 * 1024**3, "scratch_root": str(root)})
    outputs = [[str(tmp_path / f"host-{i}.zip"), *list(tasks)[i::7]] for i in range(7)]
    control = {"resource_policy": POLICY, "retained_bytes_per_task": 1024**2,
        "prepare_only": True, "task_ids": None, "batches": [], "used_batches": [], "completed": {},
        "confirmed_model_fits": 0, "confirmed_stop_fits": 0, "q_unit_outputs": outputs,
        "primary_rsf_preparation": prep, "primary_rsf_producer": producer, "primary_rsf_s2_evidence": evidence}
    if s3a is not None:
        control["primary_rsf_s3a_evidence"] = s3a
    if s3b1 is not None:
        control["primary_rsf_s3b1_evidence"] = s3b1
    if s3b2 is not None:
        control["primary_rsf_s3b2_evidence"] = s3b2
    spec = {**original, "native_search_root": str(q / "native"), "native_search_batch": control}
    if publication_capture is not None:
        publication_capture.update(spec=spec, calls=calls, outputs=outputs, child=child, tasks=tasks)
        return outputs, child, tasks
    with pytest.raises(f5._QBatchBoundary) as stopped:
        f5._q_search_task_batch(spec, kernel._run_r_prediction_pool_task, calls)
    assert stopped.value.result["new_model_fits"] == 0 and stopped.value.result["worker_inputs_ready"] is True
    assert control["confirmed_model_fits"] == {"S2": 120, "S3A": 320, "S3B1": 620, "S3B2": 770}[stage] and control["confirmed_stop_fits"] == 0
    assert control["used_batches"] == executions
    return outputs, child, tasks


@pytest.mark.parametrize("damage", [None, "no-proof", "wrong-proof", "seed", "half"])
@pytest.mark.parametrize("entry", ["worker", "api", "cli"])
def test_retained_primary_prepared_source_reaches_original_worker_without_republication(
        tmp_path, monkeypatch, capsys, damage, entry):
    outputs, spec, tasks = _published(tmp_path, monkeypatch)
    entries = read_safe_zip(Path(outputs[0][0]))
    record = json.loads(entries["prepared-q.json"])
    # Isolate the already separately verified code-source proof. Scientific
    # input/coordinate reconstruction remains the original synthetic fixture.
    retained_members = {"UNFITTED_CODE_ONLY": "1" * 64}
    retained_identity = sha256_bytes(canonical_json_bytes(retained_members))
    record["source_identity"] = retained_identity
    proof = tmp_path / "retained-code.zip"
    proof.write_bytes(b"UNFITTED_CODE_ONLY")
    def provenance(path, **kwargs):
        assert path == proof and kwargs == {"primary_rsf_inputs": True}
        return retained_members if damage != "wrong-proof" else {"UNFITTED_CODE_ONLY": "2" * 64}
    monkeypatch.setattr(f4, "_retained_full0_source_members", provenance)
    if damage in {"seed", "half"}:
        pins = record["units"][record["task_ids"][0]]
        old = pins[2]
        altered = copy.deepcopy(record["arguments"][old])
        if damage == "seed":
            altered[0]["seed"] += 1
        else:
            altered.pop()
        pin = sha256_bytes(canonical_json_bytes(altered))
        pins[2] = pin
        del record["arguments"][old]
        record["arguments"][pin] = altered
    entries["prepared-q.json"] = canonical_json_bytes(record)
    source = tmp_path / "retained-prepared.zip"
    write_deterministic_zip(source, entries)
    reached = []
    def execute(function, units, root, control, phase, input_ref, **kwargs):
        assert damage is None and function is kernel._run_r_prediction_pool_task
        for name, (call, native) in units.items():
            assert canonical_json_bytes(call[0]) == canonical_json_bytes(spec)
            assert call[2] == tasks[name]
            reached.append(name)
        raise f5._QBatchBoundary({"UNFITTED": True})
    monkeypatch.setattr(f5, "_execute_q_search_batch", execute)
    def run():
        if entry == "cli":
            import sys
            args = ["padml-f5", "complex-search", "--target", str(tmp_path / "retained-worker"),
                    "--primary-outer-prepared", "--selection-horizon-months", "12",
                    "--candidate-family", "RSF", "--prepared-q-input", str(source),
                    "--prepared-q-input-sha256", sha256_file(source),
                    "--batch-root", str(tmp_path / "retained-batch"),
                    "--retained-bytes-per-task", str(1024**2), "--task-ids", *record["task_ids"]]
            if damage != "no-proof":
                args += ["--prepared-source-bundle", str(proof)]
            monkeypatch.setattr(sys, "argv", args)
            f5.main()
            return json.loads(capsys.readouterr().out)
        if entry == "api":
            return f5.execute_final_complex_search(target=tmp_path / "retained-worker",
                prepared_q_input=source, prepared_q_input_sha256=sha256_file(source),
                primary_outer_prepared=True, selection_horizon_months=12, candidate_family="RSF",
                task_ids=record["task_ids"], batch_root=tmp_path / "retained-batch",
                retained_bytes_per_task=1024**2,
                **({"prepared_source_bundle": proof} if damage != "no-proof" else {}))
        return f5._execute_a12_prepared_q_batch(source, tmp_path / "retained-worker",
            expected_sha256=sha256_file(source), task_ids=record["task_ids"],
            batch_root=tmp_path / "retained-batch", retained_bytes_per_task=1024**2,
            **({"prepared_source_bundle": proof} if damage != "no-proof" else {}))
    if damage is None:
        assert run() == {"UNFITTED": True}
        assert reached == record["task_ids"]
    else:
        with pytest.raises(ContractError):
            run()
        assert reached == []


@pytest.mark.parametrize("damage", ["full0", "gbm", "horizon", "no-input"])
def test_retained_primary_public_entry_rejects_other_scopes(tmp_path, monkeypatch, damage):
    options = {"target": tmp_path / "out", "prepared_q_input": tmp_path / "input.zip",
        "prepared_q_input_sha256": "1" * 64, "primary_outer_prepared": True,
        "selection_horizon_months": 12, "candidate_family": "RSF",
        "prepared_source_bundle": tmp_path / "source.zip", "task_ids": ["UNFITTED"],
        "batch_root": tmp_path / "batch", "retained_bytes_per_task": 1024**2}
    if damage == "full0":
        options["primary_outer_prepared"] = False
    elif damage == "gbm":
        options["candidate_family"] = "GBM_COX"
    elif damage == "horizon":
        options["selection_horizon_months"] = 24
    else:
        options["prepared_q_input"] = options["prepared_q_input_sha256"] = None
    monkeypatch.setattr(f5, "_execute_a12_prepared_q_batch",
        lambda *a, **k: pytest.fail("OTHER_SCOPE_REACHED_PREPARED_WORKER"))
    with pytest.raises(ContractError):
        f5.execute_final_complex_search(**options)
    assert not (tmp_path / "out").exists()


def test_s2_original_75_atoms_direct_publication_to_seven_workers(tmp_path, monkeypatch):
    outputs, spec, tasks = _published(tmp_path, monkeypatch)
    phase, ids = f5._a12_q_stop_phase("S2", refit=True, family="RSF")
    assert list(tasks) == ids and len(ids) == 75
    assert sorted(map(len, tasks.values())) == [2] * 25 + [3] * 50
    assert f5._a12_q_prepared_predecessors("S2", refit=True, family="RSF") == {"total": 120, "stop": 0}
    seen = []
    def execution(function, units, root, control, observed_phase, input_ref, **kwargs):
        assert function is kernel._run_r_prediction_pool_task and observed_phase == phase
        assert control["execution_worker_memory_bytes"] == 2147483648 and control["execution_scratch_reserve_bytes"] == 0
        for name, (call, native) in units.items():
            assert canonical_json_bytes(call[0]) == canonical_json_bytes(spec)
            assert canonical_json_bytes(call[2]) == canonical_json_bytes(tasks[name])
            assert native == (name, *[row["task_id"] for row in tasks[name]])
            assert not kernel._contains_key(call[1], "evaluation_response")
            seen.append(name)
        raise f5._QBatchBoundary({"UNFITTED": True})
    monkeypatch.setattr(f5, "_execute_q_search_batch", execution)
    for i, output in enumerate(outputs):
        path = Path(output[0])
        assert f5._execute_a12_prepared_q_batch(path, tmp_path / f"worker-{i}", expected_sha256=sha256_file(path),
            task_ids=output[1:], batch_root=tmp_path / f"batch-{i}", retained_bytes_per_task=1024**2) == {"UNFITTED": True}
    assert len(seen) == len(set(seen)) == 75 and set(seen) == set(tasks)


@pytest.mark.parametrize("occupied", ["root", "batch"])
def test_s2_preexpanded_wrapper_is_rejected_before_input_or_science(tmp_path, monkeypatch, occupied):
    outputs, _, _ = _published(tmp_path, monkeypatch)
    source = Path(outputs[0][0])
    root, batch = tmp_path / "worker", tmp_path / "batch"
    target = root if occupied == "root" else batch
    target.mkdir()
    marker = target / "historical-evidence.txt"
    marker.write_bytes(b"PRESERVE")
    monkeypatch.setattr(f5, "inspect_safe_zip_manifest", lambda *a, **k: pytest.fail("occupied root opened input"))
    monkeypatch.setattr(f5, "_execute_q_search_batch", lambda *a, **k: pytest.fail("occupied root invoked science"))
    with pytest.raises(ContractError, match="F5_A12_PREPARED_STOP_INPUT_INVALID"):
        f5._execute_a12_prepared_q_batch(source, root, expected_sha256=sha256_file(source),
            task_ids=outputs[0][1:], batch_root=batch, retained_bytes_per_task=1024**2)
    assert marker.read_bytes() == b"PRESERVE"
    assert list(target.iterdir()) == [marker]


@pytest.mark.parametrize("damage", ["missing-predecessor", "duplicate-predecessor", "foreign-report", "changed-execution",
    "parameter", "seed", "mi", "parents", "horizons", "half", "reordered"])
def test_s2_damaged_payload_never_enters_executor(tmp_path, monkeypatch, damage):
    outputs, _, _ = _published(tmp_path, monkeypatch)
    entries = read_safe_zip(Path(outputs[0][0])); record = json.loads(entries["prepared-q.json"])
    if damage == "missing-predecessor": record["predecessor_execution_sha256"].pop()
    elif damage == "duplicate-predecessor": record["predecessor_execution_sha256"][-1] = record["predecessor_execution_sha256"][0]
    elif damage in {"foreign-report", "changed-execution"}:
        name = "primary-s2/report.json" if damage == "foreign-report" else "primary-s2/H0-execution.json"
        entries[name] = b'{"UNFITTED":"FOREIGN_OUTER"}'
        record["members"][name] = {"sha256": sha256_bytes(entries[name]), "size_bytes": len(entries[name])}
    else:
        pins = record["units"][record["task_ids"][0]]; old = pins[2]
        value = copy.deepcopy(record["arguments"][old])
        if damage == "parameter": value[0]["parameters"]["UNFITTED"] += 1
        elif damage == "seed": value[0]["seed"] += 1
        elif damage == "mi": value[0]["imputation"] += 1
        elif damage == "parents": value[0]["selected_parents"] = []
        elif damage == "horizons": value[0]["prediction_horizons"] = [12]
        elif damage == "half": value.pop()
        else: value.reverse()
        new = sha256_bytes(canonical_json_bytes(value)); pins[2] = new
        del record["arguments"][old]; record["arguments"][new] = value
    entries["prepared-q.json"] = canonical_json_bytes(record)
    path = tmp_path / "damaged.zip"; write_deterministic_zip(path, entries)
    monkeypatch.setattr(f5, "_execute_q_search_batch", lambda *a, **k: pytest.fail("damaged input reached executor"))
    with pytest.raises(ContractError):
        f5._execute_a12_prepared_q_batch(path, tmp_path / "bad-worker", expected_sha256=sha256_file(path),
            task_ids=record["task_ids"], batch_root=tmp_path / "bad-batch", retained_bytes_per_task=1024**2)


def test_s2_consumer_producer_complete_source_proof():
    path = Path(__file__).parents[1] / "retained293f.zip"
    members = f4._retained_full0_source_members(path, primary_rsf_inputs=True)
    assert sha256_bytes(canonical_json_bytes(members)) == "293f38ef4f83b4670f2669c31f6aa3b9ff04be47a12c2f58e39250578a579e28"


@pytest.mark.parametrize("archive,identity", [
    ("retained01723.zip", "01723d947d4916024ef2e4274c07a87737fe2bc81c9ee33285649faeaeb1e446"),
    ("retained8c31.zip", "8c3100a9b1ab3525488b27cb152131b8a05fdf5d1250168658b03ed034f336f0"),
    ("retaineda6f.zip", "a6f0d038f59df80f4d5fca778467fd263696e499ff12776cce59c24927cafa2e"),
])
def test_s2_outer1_preserves_exact_preparation_fit_consumer_sources(archive, identity):
    source = Path(__file__).parents[1] / archive
    members = f4._retained_full0_source_members(source, primary_rsf_inputs=True)
    assert len(members) == 49 and sha256_bytes(canonical_json_bytes(members)) == identity


@pytest.mark.parametrize("archive", ["retained01723.zip", "retained8c31.zip", "retaineda6f.zip"])
def test_s2_outer1_source_proof_rejects_unpaired_science_member(archive, monkeypatch):
    source = Path(__file__).parents[1] / archive
    member = "padml/nested_loco.py"
    target = Path(f4.__file__).parents[1] / member
    read_bytes = Path.read_bytes
    changed = read_bytes(target) + b"\nUNPAIRED_SCIENTIFIC_MEMBER = True\n"
    current = f4._f45_source_member_sha256()
    current[member] = sha256_bytes(changed)
    monkeypatch.setattr(Path, "read_bytes", lambda path: changed if path == target else read_bytes(path))
    monkeypatch.setattr(f4, "_f45_source_member_sha256", lambda: current)
    with pytest.raises(ContractError, match="F5_RETAINED_PRIMARY_RSF_INPUT_SOURCE_DRIFT"):
        f4._retained_full0_source_members(source, primary_rsf_inputs=True)
