"""Code-only provenance and UNFITTED source transport, never model acceptance."""
import json
import os
from pathlib import Path

import pytest

from padml import f4, f5, f4_compact as compact, f5_sensitivity as sensitivity, nested_loco, runtime
from padml.bundle import ContractError, canonical_json_bytes, sha256_bytes


@pytest.fixture
def sources():
    directory = Path(os.environ["PADML_GBM_S3B1_SOURCE_FIXTURES"])
    roles = {"retained_primary_source_bundle": "primary1513.zip",
             "retained_selector_source_bundle": "selector1ae.zip",
             "retained_gbm_q_source_bundle": "q73.zip",
             "retained_gbm_q_executor_source_bundle": "q0f.zip",
             "retained_gbm_q_worker_source_bundle": "q2cc.zip",
             "retained_gbm_q_prepared_source_bundle": "q3ab.zip",
             "retained_gbm_q_s3b1_source_bundle": "qdf85.zip"}
    return {key: (directory / name).resolve(strict=True) for key, name in roles.items()}


@pytest.mark.parametrize("role", ["retained_gbm_q_source_bundle", "retained_gbm_q_executor_source_bundle",
    "retained_gbm_q_worker_source_bundle", "retained_gbm_q_prepared_source_bundle",
    "retained_gbm_q_s3b1_source_bundle"])
def test_real_code_only_producer_proof_keeps_executor(sources, role):
    current = f4._f45_source_member_sha256()
    actual = f4._retained_gbm_q_source_members(sources[role], sources["retained_primary_source_bundle"])
    assert len(actual) == 49 and actual != current and f4._f45_source_member_sha256() == current


@pytest.mark.parametrize("damage", [None, "kernel", "source-carrier"])
def test_real_5c_gbm_executor_keeps_finite_proof(sources, monkeypatch, damage):
    source = Path(os.environ["PADML_FULL0_GBM_5C303_SOURCE"])
    current = f4._f45_source_member_sha256()
    if damage is not None:
        member = "padml/kernels/f4_gbm_stop.R" if damage == "kernel" else "padml/f5.py"
        path = Path(f4.__file__).resolve().parent.parent / member
        reader = Path.read_bytes
        changed = reader(path) + (b"\n# unreviewed-kernel\n" if damage == "kernel"
                                  else b"\n_UNREVIEWED_SOURCE_CARRIER = True\n")
        monkeypatch.setattr(Path, "read_bytes", lambda p: changed if p == path else reader(p))
        monkeypatch.setattr(f4, "_f45_source_member_sha256",
            lambda: {**current, member: sha256_bytes(changed)})
        with pytest.raises(ContractError):
            f4._retained_gbm_q_source_members(source, sources["retained_primary_source_bundle"])
        return
    retained = f4._retained_gbm_q_source_members(source, sources["retained_primary_source_bundle"])
    assert sha256_bytes(canonical_json_bytes(retained)) == (
        "5c30305f8279acc7407bffc1b9d2d09cb1d100f819f69d4e7486c131c8bee5df")
    assert retained != current and f4._f45_source_member_sha256() == current


@pytest.mark.parametrize("damage", ["reviewed-body", "scientific-body", "new-function", "old-identity"])
def test_shared_old_gbm_proof_rejects_unreviewed_delta(sources, monkeypatch, damage):
    """Real old source; no input, model, numerical or replay consumer."""
    source = sources["retained_gbm_q_executor_source_bundle"]
    primary = sources["retained_primary_source_bundle"]
    if damage == "old-identity":
        with pytest.raises(ContractError):
            f4._retained_gbm_q_source_members(primary, primary)
        return
    current = f4._f45_source_member_sha256()
    path = Path(f5.__file__).resolve()
    original = path.read_bytes()
    if damage == "new-function":
        changed = original + b"\ndef _unreviewed_new_function():\n    return None\n"
    else:
        import ast
        symbol = ("_q_batch_retention_preflight" if damage == "reviewed-body"
                  else "_q_search_units")
        node = next(n for n in ast.parse(original).body
                    if isinstance(n, ast.FunctionDef) and n.name == symbol)
        lines = original.splitlines(keepends=True)
        lines.insert(node.body[0].lineno - 1, b"    raise RuntimeError('unreviewed')\n")
        changed = b"".join(lines)
    reader = Path.read_bytes
    monkeypatch.setattr(Path, "read_bytes", lambda p: changed if p == path else reader(p))
    monkeypatch.setattr(f4, "_f45_source_member_sha256",
                        lambda: {**current, "padml/f5.py": sha256_bytes(changed)})
    with pytest.raises(ContractError):
        f4._retained_gbm_q_source_members(source, primary)


def test_prepared_57400_source_keeps_its_role(monkeypatch):
    source = Path(os.environ["PADML_GBM_PREPARED_SOURCE"])
    current = f4._f45_source_member_sha256()
    actual = f4._retained_full0_source_members(source, aar_gbm_prepared_inputs=True)
    assert sha256_bytes(canonical_json_bytes(actual)) == (
        "57400bb08bba042825aa1c51c7c51f03fa4bedef2c2799e12c1bbdb454b336f4")
    assert actual != current and f4._f45_source_member_sha256() == current
    with pytest.raises(ContractError):
        f4._retained_full0_source_members(source, primary_rsf_inputs=True)
    for member in ("padml/kernels/f4_gbm_stop.R", "padml/science/variable.csv"):
        with monkeypatch.context() as scoped:
            scoped.setattr(f4, "_f45_source_member_sha256", lambda: {**current, member: "0" * 64})
            with pytest.raises(ContractError):
                f4._retained_full0_source_members(source, aar_gbm_prepared_inputs=True)


def test_prepared_gbm_public_cli_keeps_source_separate(tmp_path, monkeypatch, capsys):
    import sys
    seen = []
    monkeypatch.setattr(f5, "_execute_a12_prepared_q_batch",
        lambda *a, **k: seen.append((a, k)) or {"UNFITTED": True})
    monkeypatch.setattr(sys, "argv", ["padml-f5", "a12-outer", str(tmp_path / "old.zip"),
        str(tmp_path / "new-worker"), "--search-only", "--search-branch",
        nested_loco.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT,
        "--prepared-q-input-sha256", "a" * 64, "--prepared-source-bundle", str(tmp_path / "producer.zip"),
        "--task-ids", "UNFITTED-original-atom", "--batch-root", str(tmp_path / "batch"),
        "--retained-bytes-per-task", str(1024**2)])
    f5.main()
    assert len(seen) == 1 and seen[0][1]["prepared_source_bundle"] == tmp_path / "producer.zip"
    assert seen[0][1]["expected_sha256"] == "a" * 64
    assert seen[0][1]["expected_a12_branch"] == nested_loco.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT


def test_prepared_gbm_source_does_not_enable_reprepare(tmp_path):
    with pytest.raises(ContractError, match="F5_A12_PREPARED_STOP_INPUT_INVALID"):
        sensitivity.execute_a12_outer_bundle(tmp_path / "input", tmp_path / "output",
            prepared_source_bundle=tmp_path / "producer.zip", prepare_only=True)


@pytest.mark.parametrize("numerical", [False, True], ids=["transport", "linux-numerical"])
def test_old_stop300_prepared_public_worker_preserves_all_original_calls(tmp_path, monkeypatch, sources, numerical):
    """The real transport/worker boundary, with a separately tested source proof.

    No numerical leaves here: the companion Linux funnel tests own numerical
    consumption. This checks the exact 300-call/fifteen-partition wire format.
    """
    import copy
    from padml import f2_kernel as kernel
    from padml.bundle import sha256_file
    from test_primary_outer12_rsf_inputs import _call
    from test_primary_outer12_rsf_prepared_pipeline import POLICY
    if numerical:
        import sys
        if sys.platform != "linux":
            pytest.skip("Numerical consumer belongs to the Linux engineering role")
        from test_q_funnel_shards import _unfitted_leaves, _options
        events, _ = _unfitted_leaves(monkeypatch, gbm_loss_fixture=True)
    producer = Path(os.environ["PADML_GBM_PREPARED_SOURCE"])
    manifest = f4.load_f45_source_bundle(producer)
    old_members = {row["path"]: row["sha256"] for row in manifest["members"]}
    current_members = f4._f45_source_member_sha256()
    base = list(_call(tmp_path, 5))
    spec = base[0]
    spec.pop("primary_search_source")
    spec.pop("selection_horizon_months")
    spec["trial_scoring"].update(ibs_grid_months=list(range(25)),
        ibs_integration="TRAPEZOID_DIVIDE_BY_24")
    spec.update(family="GBM_COX", execution_scope="F5_A12_SEARCH", horizons=list(range(37)),
        a12_source={"outer_fold": 5, "family": "GBM_COX",
            "source": {"kind": "PADML_F5_A12_PROJECTED_OUTER_INPUTS_V1"},
            "branch": nested_loco.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT},
        retained_a12_primary_context_source_bundle=str(sources["retained_primary_source_bundle"]))
    for mi in range(2, 21):
        (tmp_path / "covariates" / f"imp{mi:02d}.csv").write_bytes(
            (tmp_path / "covariates/imp01.csv").read_bytes())
    calls = []
    for part in range(1, 16):
        for mi in range(1, 21):
            call = copy.deepcopy(base)
            identifier = f"STOP_F5_R{(part - 1) // 5 + 1}_K{(part - 1) % 5 + 1}"
            for row in (call[1]["partitions"][0], call[6]):
                row.update(kind="STOP", partition_id=identifier,
                    repeat=(part - 1) // 5 + 1, inner_fold=(part - 1) % 5 + 1)
            call[1]["projected_partition_ids"] = [identifier]
            call[2] = [{"task_id": f"S3B2_T001_P{part:02d}_M{mi:02d}_STOP",
                "partition_id": identifier, "family": "GBM_COX", "imputation": mi,
                "seed": 355000 + mi * 100 + part, "parameters": {"UNFITTED": 1},
                "producer_kind": "GBM_STOP_CURVE"}]
            call[5] = "GROUPED_COX_LOCK"
            calls.append(call)
    units = f5._q_search_units(kernel._run_r_prediction_pool_task, calls)
    phase, ids = f5._a12_q_stop_phase("S3B2", family="GBM_COX")
    assert list(units) == ids and len(ids) == 300
    q = tmp_path / "publication"
    q.mkdir()
    raw = canonical_json_bytes({"kind": "PADML_F5_A12_Q_INPUT_V1", "spec": spec})
    (q / "input.json").write_bytes(raw)
    outputs = [[str(tmp_path / f"host-{i}.zip"), *ids[i::7]] for i in range(7)]
    prior = {"UNFITTED_ORIGINAL_PREFIX": True}
    counts = f5._a12_q_prepared_predecessors("S3B2", refit=False, family="GBM_COX")
    control = {"resource_policy": POLICY, "retained_bytes_per_task": 1024**2, "task_ids": None,
        "q_unit_outputs": outputs, "confirmed_model_fits": counts["total"],
        "confirmed_stop_fits": counts["stop"], "batches": [(q, prior)],
        "used_batches": [sha256_bytes(canonical_json_bytes(prior))]}
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda root: {
        "effective_cpus": 32, "available_memory_bytes": 128 * 1024**3,
        "scratch_available_bytes": 128 * 1024**3, "scratch_root": str(root)})
    # Manufacture only synthetic old-source transport, never real evidence.
    with monkeypatch.context() as old:
        old.setattr(f4, "_f45_source_member_sha256", lambda: old_members)
        f5._publish_a12_q_stop_inputs(kernel._run_r_prediction_pool_task, units, q, control,
            phase, {"sha256": sha256_bytes(raw), "size_bytes": len(raw)})
    def proof(path, **kwargs):
        if kwargs == {"aar_gbm_prepared_inputs": True}:
            assert sha256_file(path) == sha256_file(producer)
            return old_members
        assert kwargs == {"aar_primary_context": True}
        return {row["path"]: row["sha256"] for row in f4.load_f45_source_bundle(path)["members"]}
    if not numerical:
        monkeypatch.setattr(f4, "_retained_full0_source_members", proof)
    seen = []
    def execute(function, transported, root, active, observed_phase, input_ref, **kwargs):
        assert function is kernel._run_r_prediction_pool_task and observed_phase == phase
        assert active["execution_worker_memory_bytes"] == 2147483648
        assert active["execution_scratch_reserve_bytes"] == 0
        for name, (call, native) in transported.items():
            assert call[2] == units[name][0][2] and call[5] == "GROUPED_COX_LOCK"
            assert call[0]["a12_source"] == spec["a12_source"]
            assert call[0]["a12_executor_source_identity"] == sha256_bytes(canonical_json_bytes(current_members))
            assert not kernel._contains_key(call[1], "evaluation_response")
            assert native == units[name][1]
            seen.append(name)
        raise f5._QBatchBoundary({"UNFITTED": True})
    if not numerical:
        monkeypatch.setattr(f5, "_execute_q_search_batch", execute)
    if numerical:
        source = Path(outputs[0][0])
        for damage in ("source", "input-sha", "duplicate"):
            rejected = tmp_path / ("rejected-" + damage)
            before = list(events)
            with pytest.raises(ContractError):
                sensitivity.execute_a12_outer_bundle(source, rejected,
                    search_only=True, search_branch=nested_loco.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT,
                    prepared_q_input_sha256="0" * 64 if damage == "input-sha" else sha256_file(source),
                    prepared_source_bundle=sources["retained_primary_source_bundle"] if damage == "source" else producer,
                    task_ids=outputs[0][1:] + ([outputs[0][1]] if damage == "duplicate" else []),
                    batch_root=tmp_path / ("rejected-batch-" + damage), retained_bytes_per_task=1024**2)
            assert events == before and not rejected.exists()
    batches = []
    for i, output in enumerate(outputs):
        source = Path(output[0])
        result = sensitivity.execute_a12_outer_bundle(source, tmp_path / f"worker-{i}",
            search_only=True, search_branch=nested_loco.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT,
            prepared_q_input_sha256=sha256_file(source), prepared_source_bundle=producer,
            task_ids=output[1:], batch_root=tmp_path / f"batch-{i}", retained_bytes_per_task=1024**2)
        if numerical:
            assert result["status"] == "COMPUTED_Q_BATCH"
            assert result["execution"]["task_ids"] == output[1:]
            assert result["execution"]["confirmed_first_native_audit_count"] == len(output) - 1
            batches.append(tmp_path / f"batch-{i}")
        else:
            assert result == {"UNFITTED": True}
    if numerical:
        owner = tmp_path / "original-consumer"
        (owner / "native").mkdir(parents=True)
        (owner / "input.json").write_bytes(raw)
        active = f5._q_search_batch_control(owner, POLICY, _options(history=batches))
        consumed = f5._q_search_task_batch({**spec, "native_search_root": str(owner / "native"),
            "native_search_batch": active}, kernel._run_r_prediction_pool_task, calls)
        assert len(consumed) == 300 and len(active["used_batches"]) == 7
        assert active["confirmed_model_fits"] == active["confirmed_stop_fits"] == 300
        assert len([event for event in events if event[0] == "produce"]) == 600
        assert len([event for event in events if event[0] == "audit"]) == 600
        assert len([event for event in events if event[0] == "numbers"]) == 600
        assert [row[0]["task_id"] for row in consumed] == [call[2][0]["task_id"] for call in calls]
    else:
        assert len(seen) == len(set(seen)) == 300 and set(seen) == set(ids)
    assert [len(output) - 1 for output in outputs] == [43] * 6 + [42]


@pytest.mark.parametrize("role", ["retained_gbm_q_source_bundle", "retained_gbm_q_s3b1_source_bundle"])
@pytest.mark.parametrize("module,suffix", [
    ("f2_kernel.py", b"\n_cox_breslow_log_likelihood = None\n"),
    ("f4.py", b"\nclass _run_full_pipeline_r_search_batch: pass\n"),
    ("runtime.py", b"\nresource_admission = None\n"),
    ("f5.py", b"\n_q_search_units = None\n"),
    ("f5_sensitivity.py", b"\n_validate_a12_search_source = None\n")])
def test_proved_hash_does_not_hide_module_rebinding(sources, monkeypatch, role, module, suffix):
    current = f4._f45_source_member_sha256()
    path = Path(f4.__file__).resolve().parent / module
    original = path.read_bytes()
    changed = original + suffix
    reader = Path.read_bytes
    monkeypatch.setattr(Path, "read_bytes", lambda p: changed if p == path else reader(p))
    monkeypatch.setattr(f4, "_f45_source_member_sha256",
        lambda: {**current, "padml/" + module: sha256_bytes(changed)})
    with pytest.raises(ContractError):
        f4._retained_gbm_q_source_members(sources[role], sources["retained_primary_source_bundle"])


@pytest.mark.parametrize("include_s3b2", [False, True], ids=["seven-sources", "eight-sources"])
def test_seven_source_roles_completion_and_index_roundtrip(sources, tmp_path, monkeypatch, include_s3b2):
    # Isolate code/source transport from patient/scientific validation; the
    # original scientific source validator is exercised by the real consumer.
    monkeypatch.setattr(sensitivity, "_validate_a12_search_source", lambda *a, **k: None)
    monkeypatch.setattr(f5, "_bounded_ordered_spawn", lambda *a, **k: pytest.fail("NO_SCIENCE"))
    # This is a synthetic transport fixture, not evidence of host capacity.
    # Keep the original admission arithmetic; Linux /proc is unavailable on Mac.
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda root: {
        "effective_cpus": 32, "available_memory_bytes": 8 * 1024**3,
        "scratch_available_bytes": 8 * 1024**3, "scratch_root": str(root)})
    root = tmp_path / "UNFITTED-Q"
    (root / "native/UNFITTED").mkdir(parents=True)
    (root / "native/UNFITTED/model.bin").write_bytes(b"UNFITTED")
    (root / "input.json").write_bytes(canonical_json_bytes({"kind": "PADML_F5_A12_Q_INPUT_V1",
        "spec": {"execution_scope": "F5_A12_SEARCH", "family": "GBM_COX", "fold": 5,
                 "a12_source": {"branch": nested_loco.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT}}}))
    (root / "result.json").write_bytes(canonical_json_bytes({"UNFITTED": True}))
    policy = {"configured_worker_ceiling": "EXECUTION_HOST_C_MINUS_8", "memory_bytes_per_worker": 2147483648,
              "memory_reserve_bytes": 0, "scratch_bytes_per_worker": 1,
              "scratch_reserve_bytes": 2147483648, "transfer_archive_worker_ceiling": 1}
    if include_s3b2:
        sources = {**sources, "retained_gbm_q_s3b2_source_bundle":
            Path(os.environ["PADML_FULL0_GBM_5C303_SOURCE"]).resolve(strict=True)}
        value = json.loads((root / "input.json").read_bytes())
        value["spec"]["a12_source"]["source"] = {"resource_policy": policy}
        (root / "input.json").write_bytes(canonical_json_bytes(value))
        # Synthetic source transport only: actual input identity and its
        # scientific source are verified separately by the real H7 reader.
        original_sha = f5.sha256_file
        monkeypatch.setattr(f5, "sha256_file", lambda path:
            "be9efb738f1639ce8f5fe422a0f8ec3412426000e75301f2eea8f702f152c225"
            if path == root / "input.json" else original_sha(path))
    original_admission = runtime.resource_admission
    admitted = []
    def admit(policy, observation, **kwargs):
        assert policy["scratch_reserve_bytes"] == 0
        admitted.append(True)
        return original_admission(policy, observation, **kwargs)
    monkeypatch.setattr(runtime, "resource_admission", admit)
    _, refs = f5._q_gbm_source_evidence(root, policy, sources=sources)
    control = {"used_batches": [], "batches": [], "confirmed_model_fits": 0, "confirmed_stop_fits": 0,
        "completed": False, "gbm_retained_sources": refs, "gbm_retained_source_paths": sources,
        "resource_policy": policy, "execution_worker_memory_bytes": 2147483648, "references": {}}
    f5._q_search_batch_completion(root, control, {"total_search_fit_count": 0, "response_free_stopping_fit_count": 0})
    assert f5._q_gbm_source_evidence(root, policy)[1] == refs
    members, index = compact._full_pipeline_q_numerical_members(root, publish=True)
    assert compact._full_pipeline_q_numerical_members(root)[1] == index
    assert set(refs) <= set(members) and len(refs) == (8 if include_s3b2 else 7) and admitted
    original = (root / "execution.json").read_bytes()
    for damage in ("missing-leaf", "wrong-pin", "extra-leaf"):
        value = json.loads(original)
        name = "execution-evidence/retained-sources/qdf85.zip"
        if damage == "missing-leaf": del value["gbm_retained_sources"][name]
        elif damage == "wrong-pin": value["gbm_retained_sources"][name]["sha256"] = "f" * 64
        else: value["gbm_retained_sources"]["execution-evidence/retained-sources/unreviewed.zip"] = value["gbm_retained_sources"][name]
        (root / "execution.json").write_bytes(canonical_json_bytes(value))
        with pytest.raises(ContractError):
            compact._full_pipeline_q_numerical_members(root)
    (root / "execution.json").write_bytes(original)
    wrong = dict(sources)
    wrong["retained_gbm_q_s3b1_source_bundle"] = sources["retained_gbm_q_source_bundle"]
    with pytest.raises(ContractError):
        f5._q_gbm_source_evidence(root, policy, sources=wrong)
