# 独立边界与数值对照，合成数据不用于正式结果。
source(commandArgs(trailingOnly=TRUE)[[1]])
cfg <- list(horizon=24,g_min=.05,ess_min=0,ess_fraction=0,youden_tie_tolerance=1e-12,
  centers=c(36,38,39,48,52,54),training_only_center=55,seed=20261014,
  rng=c("L'Ecuyer-CMRG","Inversion","Rejection"),fixed_cutoff=1.46)
stopifnot(identical(ta_round(c(1.465,1.455,1.005,1.464)),c(1.47,1.46,1.01,1.46)))
stopifnot(ta_round(1.4649999999999996)==1.46,ta_round(1.4650000000000003)==1.47)
d <- data.frame(AST_ALT=c(1.46,1.464,1,2,3,4,1.1,1.8),
  Death_Followup_months=c(24,24,30,30,10,10,20,40),All_Cause_Death=c(1L,0L,0L,1L,1L,0L,0L,1L),Center=36)
m <- c(2L,1L,3L,1L,1L,2L,1L,1L)
w <- ta_weights(d,m,cfg)
stopifnot(w$cases[1],!w$controls[2],!w$cases[2],w$controls[3])
expanded <- d[rep(seq_len(nrow(d)),m),,drop=FALSE]
we <- ta_weights(expanded,rep(1L,nrow(expanded)),cfg)
stopifnot(all.equal(w$ess,we$ess,tolerance=1e-14),
  all.equal(ta_counts(d,m,w,1.46)$counts,ta_counts(expanded,rep(1L,nrow(expanded)),we,1.46)$counts,tolerance=1e-14))
km <- survival::survfit(survival::Surv(Death_Followup_months,1-All_Cause_Death)~1,data=expanded)
mine <- ta_km(d$Death_Followup_months,d$All_Cause_Death,m)
stopifnot(max(abs(ta_km_at(mine,km$time)-km$surv))<1e-14)
sel <- ta_select(d,m,cfg)
u <- sort(unique(d$AST_ALT)); cuts <- head(u,-1)+diff(u)/2
direct <- vapply(cuts,function(c) {z<-ta_metric(ta_counts(d,m,w,c));z$Youden$value},0)
ties <- which(max(direct)-direct<=1e-12)
stopifnot(abs(sel$raw-cuts[ties[floor((length(ties)+1)/2)]])<1e-14)
zero <- d; zero$All_Cause_Death[] <- 0L
wz <- ta_weights(zero,rep(1L,nrow(zero)),cfg)
mz <- ta_metric(ta_counts(zero,rep(1L,nrow(zero)),wz,1.46))
stopifnot(is.na(mz$Se$value),is.finite(mz$Sp$value))
high <- ta_metric(ta_counts(d,m,w,-1))
stopifnot(is.na(high$NPV$value),high$HighFraction$value==1)
for (seed in 1:20) {
  set.seed(seed)
  z <- data.frame(AST_ALT=sample(c(1,1.1,1.46,1.464,2,3),80,TRUE),
    Death_Followup_months=sample(c(6,12,24,25,36),80,TRUE),All_Cause_Death=sample(0:1,80,TRUE),Center=36)
  mt <- sample(0:3,80,TRUE); wt <- ta_weights(z,mt,cfg)
  ss <- ta_select(z,mt,cfg)
  v <- sort(unique(z$AST_ALT[mt>0])); cc <- head(v,-1)+diff(v)/2
  yy <- vapply(cc,function(c) ta_metric(ta_counts(z,mt,wt,c))$Youden$value,0)
  tie <- which(max(yy)-yy<=cfg$youden_tie_tolerance)
  stopifnot(identical(ss$raw,cc[tie[floor((length(tie)+1)/2)]]))
}
dd <- do.call(rbind,lapply(c(cfg$centers,55),function(center) transform(d,Center=center)))
a <- ta_boot_counts(dd,cfg,1); b <- ta_boot_counts(dd,cfg,2); aa <- ta_boot_counts(dd,cfg,1)
stopifnot(identical(a,aa),!identical(a$m,b$m),all(tapply(a$m,dd$Center,sum)==8))
q <- seq(-.3,.3,length.out=20); u <- rep(.2,20); p <- ta_pool(q,u)
stopifnot(abs(p$total-(mean(u)+1.05*var(q)))<1e-14,p$m==20)
failed <- tryCatch({ta_pool(q[-1],u[-1]);FALSE},error=function(e) TRUE)
stopifnot(failed)
# 改变留出中心不会改变该折训练选值；该中心零病例只阻断其Se及宏平均。
dd$Patient_ID <- seq_len(nrow(dd))
ctx <- list(d=dd,cfg=cfg,roc=1.46182283520546)
before <- ta_evaluate(ctx,rep(1L,nrow(dd)))
ctx$d$All_Cause_Death[ctx$d$Center==38] <- 0L
ctx$d$AST_ALT[ctx$d$Center==38] <- ctx$d$AST_ALT[ctx$d$Center==38] + .11
after <- ta_evaluate(ctx,rep(1L,nrow(dd)))
pick <- function(x) x$thresholds[x$thresholds$center==38 & x$thresholds$branch=='LOCO_MAIN',c('raw','rounded')]
stopifnot(identical(pick(before),pick(after)))
se <- after$metrics[after$metrics$branch=='FIXED146' & after$metrics$metric=='Se',]
stopifnot(is.na(se$value[se$scope=='CENTER' & se$center=='38']),
          is.finite(se$value[se$scope=='MICRO6']),is.na(se$value[se$scope=='MACRO6']))
# 固定HR及风险集时间交互与直接计数过程拟合对照，不使用终末时间静态交互。
set.seed(19)
z <- data.frame(Patient_ID=1:120,Center=36,AST_ALT=runif(120,.6,2.8),
  All_Cause_Death=rbinom(120,1,.7),Death_Followup_months=sample(1:36,120,TRUE))
cfg$model_covariates <- list(M1=character())
cx <- list(d=z,mi=rep(list(z),20),cfg=cfg)
fx <- ta_fit(cx,list(kind='FIXED',model='M1',imputation=1L))
tx <- ta_fit(cx,list(kind='TVE',model='M1',imputation=1L))
z$H <- as.integer(z$AST_ALT>1.46)
ref <- survival::coxph(survival::Surv(Death_Followup_months,All_Cause_Death)~H,data=z,ties='efron')
stopifnot(max(abs(fx$coefficients-coef(ref)))<1e-12)
Surv <- survival::Surv
split <- survival::survSplit(Surv(Death_Followup_months,All_Cause_Death)~.,data=z,
  cut=sort(unique(z$Death_Followup_months[z$All_Cause_Death==1])))
split$Hg <- split$H*(log1p(split$Death_Followup_months)-log(13))
reference <- survival::coxph(survival::Surv(tstart,Death_Followup_months,All_Cause_Death)~H+Hg,data=split,ties='efron')
stopifnot(max(abs(tx$coefficients-coef(reference)))<1e-9,
          max(abs(tx$covariance-vcov(reference)))<1e-9)
cat("THRESHOLD_NATIVE_CHECKS_PASS\n")
