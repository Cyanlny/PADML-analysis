"""One original CLI owner with mixed Q prefixes through its native archive reader.

Synthetic primary/F1 custody, MICE/selector and engine leaves are inherited
from existing tests. Original input, Q, final-number, archive and replay
consumers are not replaced. This is not historical-source acceptance.
"""
import json
import os
import sys
import zipfile
from pathlib import Path

import pytest

from padml import f4, f5, f2_kernel as kernel, runtime, nested_loco as nested
from padml import f5_sensitivity as sensitivity
from padml.bundle import canonical_json_bytes, sha256_bytes, sha256_file
from test_nested_aar_mice import (aar_source, unfitted_selector_engines,
    _projected_outer_fixture, _unfitted_outer_mice_workers)
from test_q_funnel_shards import _unfitted_leaves, _six_shard_batches, _options


def test_coxtime_mixed_prefix_single_cli_owner_to_original_archive_reader(
        aar_source, tmp_path, monkeypatch, request, capsys):
    retained_fixture = os.environ.get("PADML_AAR_MIXED_UNSTARTED_OWNER_FIXTURE")
    if retained_fixture is None:
        primary_input, primary_archive, policy, _, _, _ = _projected_outer_fixture(
            aar_source, tmp_path, monkeypatch, "COXTIME_SET_A")
    else:
        tmp_path = Path(retained_fixture)
        assert tmp_path.is_absolute() and not tmp_path.is_symlink()
        assert tmp_path.resolve(strict=True) == tmp_path and tmp_path.is_dir()
        assert not (tmp_path / "outer.zip").exists()
        assert not (tmp_path / "outer.zip.work").exists()
        with zipfile.ZipFile(tmp_path / "UNFITTED-primary.zip") as archive:
            assert archive.namelist() == ["UNFITTED_PRIMARY_READER_STUB.json"]
            assert archive.read("UNFITTED_PRIMARY_READER_STUB.json") == b"{}"
        with zipfile.ZipFile(tmp_path / "projected.zip") as archive:
            header = archive.getinfo("a12-inputs.json")
            assert header.file_size <= 32 * 1024**2
            projected_source = json.loads(archive.read(header))
        assert projected_source["primary_source"]["primary_training_context"]["modeling_program_sha256"] == nested._sha(
            f4._f45_source_member_sha256())
        selector = tmp_path / "prefix-development/selector"
        assert selector.is_dir() and not selector.is_symlink() and selector.resolve(strict=True) == selector
        # These seams belong only to the already-completed compiler. A
        # projected owner/readback must consume its existing native input.
        def no_global_read(*args, **kwargs):
            pytest.fail("REUSED_AAR_OWNER_MUST_NOT_REOPEN_PRIMARY_OR_F1_CUSTODY")
        for name in ("load_o_fit_execution_archive", "_load_o_fit_execution_archive",
                     "load_f4_inputs", "_materialize_o_fit_fold"):
            monkeypatch.setattr(f4, name, no_global_read)
        monkeypatch.setattr(sensitivity, "_a12_context", no_global_read)
    cpus = [64]  # Existing MICE fixture records its original 56-slot ceiling.
    monkeypatch.setattr(runtime, "effective_cpu_count", lambda: cpus[0])
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda root: {
        "effective_cpus": cpus[0], "available_memory_bytes": 10**12,
        "scratch_available_bytes": 10**12, "scratch_root": str(root)})
    monkeypatch.setattr(runtime, "_visible_open_file_keys", lambda candidates: (set(), 1))
    projected, inputs, target = (tmp_path / name for name in ("projected.zip", "inputs.zip", "outer.zip"))
    if retained_fixture is None:
        sensitivity.compile_a12_outer_inputs(primary_input, primary_archive, projected,
            f2_run_root=tmp_path, outer_fold=1, resource_policy=policy)
    mice_calls, _ = _unfitted_outer_mice_workers(monkeypatch)
    if retained_fixture is None:
        sensitivity.execute_a12_outer_inputs(projected, inputs)
    mice_native = sensitivity.subprocess.run
    selector_calls = request.getfixturevalue("unfitted_selector_engines")
    recipe_native = sensitivity.subprocess.run
    monkeypatch.setattr(sensitivity.subprocess, "run", lambda command, **kwargs:
        (mice_native if len(command) > 4 and command[3] in {"FIT", "REPLAY"} else recipe_native)(command, **kwargs))
    if retained_fixture is None:
        prepared = sensitivity.materialize_a12_outer_inputs(inputs, None, tmp_path / "prefix-inputs",
            input_bundle=projected, retain_evidence=True)
        for branch in nested.AAR_ESTIMANDS:
            prepared = sensitivity._a12_projected_development_inputs(prepared,
                tmp_path / "prefix-development", replay=False, branch=branch)
    cpus[0] = 32  # Existing Q fixture records C-8=24, separately from MICE.
    events, _ = _unfitted_leaves(monkeypatch)
    complete_branch, prefix_branch, fresh_branch = nested.AAR_ESTIMANDS
    complete_root, prefix_root = tmp_path / "complete", tmp_path / "prefix"
    if retained_fixture is None:
        with _six_shard_batches(monkeypatch, complete_root, policy, []):
            complete = sensitivity._a12_complex_search_program(prepared, complete_branch,
                complete_root, replay=False, batch_options=_options())
        with _six_shard_batches(monkeypatch, prefix_root, policy, [], stop_after=1) as prefix_batches:
            boundary = sensitivity._a12_complex_search_program(prepared, prefix_branch,
                prefix_root, replay=False, batch_options=_options())
        assert boundary["status"] == "PREPARED_Q_BATCH" and len(prefix_batches) == 6
    else:
        original_context = json.loads((tmp_path / "context.json").read_bytes())
        assert original_context["q_roots"] == {complete_branch: str(complete_root)}
        assert original_context["q_batches"][fresh_branch] == []
        prefix_batches = [Path(path) for path in original_context["q_batches"][prefix_branch]]
        assert len(prefix_batches) == 6 and all(path.is_dir() for path in prefix_batches)
        complete = json.loads((complete_root / "result.json").read_bytes())
    retained = {path: sha256_file(path) for root in (complete_root, *prefix_batches)
                for path in root.rglob("*") if path.is_file()}
    models, audits, order = [], [], []
    def engine(family, task, training, response, recipe, *, retained_objects=None, prediction_rows=None, **kwargs):
        assert family == "COXTIME_SET_A"
        f5._validate_a12_model_task(family, task)
        model = canonical_json_bytes({"UNFITTED_COXTIME": True, "task": task, "recipe": recipe})
        baseline = canonical_json_bytes({"UNFITTED_BASELINE": sha256_bytes(model)})
        if retained_objects is not None:
            assert retained_objects == (model, baseline)
        else:
            models.append((task["a12_coordinates"]["branch"], task["imputation"]))
        prediction = training if prediction_rows is None else prediction_rows
        health = {"converged": True, "engine": "pycox.models.CoxTime",
            "training_epoch_count": task["parameters"]["locked_epoch"],
            "training_row_count": len(training), "evaluation_row_count": len(training),
            "final_training_loss": .2, "raw_survival_grid_validated": True,
            "model_state_sha256": sha256_bytes(model), "baseline_numerics": {
                "implementation": "FULL_T_GE_T_RISK_SET_V1", "training_rows": len(training),
                "event_time_groups": 1, "checked_raw_scores": len(training)}}
        level = .9 - .01 * nested.AAR_ESTIMANDS.index(task["a12_coordinates"]["branch"]) - .001 * task["imputation"]
        return {"model": model, "baseline": baseline, "fit_health": health,
            "survival": [[1.] + [level] * 36 for _ in prediction],
            **({"training_survival": [[1.] + [level] * 36 for _ in training]} if kwargs.get("replay_training") else {})}
    def audit(family, model, baseline, health, task, **kwargs):
        value = json.loads(model)
        assert family == "COXTIME_SET_A" and value["task"] == task and value["UNFITTED_COXTIME"]
        assert json.loads(baseline) == {"UNFITTED_BASELINE": sha256_bytes(model)}
        columns = sorted([column for row in kernel._expected_family_parent_column_map(task["selected_parents"],
            family, kernel.predictor_contract(Path(f5.__file__).parent), value["recipe"]["transform_recipe"])
            for column in row["columns"]], key=lambda text: text.encode())
        audits.append(task["a12_coordinates"])
        return {"input_width": len(columns), "design_columns": columns}
    monkeypatch.setattr(f5, "_execute_final_refit_engine", engine)
    monkeypatch.setattr(f5, "_validate_retained_model_objects", audit)
    def pool(worker, jobs, *, selected_slots, execution_report=None, on_result=None, **kwargs):
        assert 1 <= selected_slots <= 24
        if worker is sensitivity._execute_ablation_component:
            branch, = {json.loads(job["entries"]["task.json"])["a12_coordinates"]["branch"] for job in jobs}
            order.append(branch)
            assert len(jobs) == 20
        if execution_report is not None:
            execution_report.update(configured_worker_ceiling=24, admitted_worker_ceiling=selected_slots,
                runnable_task_count=len(jobs), actual_worker_process_peak=1, completed_task_count=0,
                engine_threads=1, status="RUNNING")
        rows = []
        for index, job in enumerate(jobs):
            row = worker(job)
            rows.append(row)
            if on_result is not None:
                on_result(index, row)
        if execution_report is not None:
            execution_report.update(completed_task_count=len(jobs), status="COMPLETED")
        return rows
    monkeypatch.setattr(sensitivity, "_bounded_ordered_spawn", pool)
    batches = tmp_path / "owned-batches"
    if retained_fixture is None:
        batches.mkdir()
    else:
        assert batches.is_dir() and not list(batches.iterdir())
    context = dict(input_bundle=str(projected), q_roots={complete_branch: str(complete_root)},
        q_batches={prefix_branch: list(map(str, prefix_batches)), fresh_branch: []},
        continuous_batch_root=str(batches), retained_bytes_per_task=4 * 1024**2,
        retained_bytes_per_component=2 * 1024**2,
        selector_root=str(tmp_path / "prefix-development/selector"))
    context_file = tmp_path / "context-owner-suffix.json"
    with context_file.open("xb") as handle:
        handle.write(canonical_json_bytes(context))
    capsys.readouterr()
    monkeypatch.setattr(sys, "argv", ["padml-f5", "a12-outer", str(inputs), str(target),
        "--execution-context", str(context_file)])
    f5.main()  # Exactly one public complete-context owner invocation.
    report = json.loads(capsys.readouterr().out)
    assert order == list(nested.AAR_ESTIMANDS)
    assert len(models) == len(set(models)) == len(audits) == 60
    assert report["outer_model_fit_count"] == 60 and target.is_file()
    assert not (batches / complete_branch).exists()
    assert all(sha256_file(path) == digest for path, digest in retained.items())
    produces = [path for mode, path, _ in events if mode == "produce"]
    assert len(produces) == len(set(produces))
    work = Path(report["work_evidence_retained"])
    assert json.loads((work / "search" / complete_branch / "result.json").read_bytes()) == complete
    before_events, before_mice, before_selector = list(events), list(mice_calls), dict(selector_calls)
    def forbidden(*args, **kwargs):
        pytest.fail("archive numerical reader must not fit or replay native models")
    monkeypatch.setattr(f5, "_execute_final_refit_engine", forbidden)
    monkeypatch.setattr(f5, "_validate_retained_model_objects", forbidden)
    observed = sensitivity._load_a12_outer_archive(target, input_bundle=projected,
        replay_evidence=tmp_path / "replay")
    assert observed["kind"] == "PADML_F5_A12_OUTER_NATIVE_V2"
    assert set(observed["predictions"]["survival"]) == set(nested.AAR_ESTIMANDS)
    assert len(observed["native_members"]) == 60
    assert len([name for name in observed["members"] if name.startswith("fits/") and name.endswith(".numbers.json")]) == 60
    assert sensitivity._a12_outer_archive_record(observed, target)["execution_ledger"] == report["execution_ledger"]
    assert [event for event in events if event[0] != "numbers"] == [event for event in before_events if event[0] != "numbers"]
    assert mice_calls == before_mice and selector_calls == before_selector
