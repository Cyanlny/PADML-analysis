"""Synthetic transport checks; not a prepared-source or dispatch authorization."""
import copy
from contextlib import contextmanager, nullcontext
from pathlib import Path
import sys
import tempfile
import zipfile

import pytest

from padml import f2_kernel as kernel, f5, runtime
from padml.bundle import ContractError, canonical_json_bytes, sha256_bytes, sha256_file, strict_json_bytes, write_deterministic_zip
from test_primary_outer12_rsf_inputs import _call as _primary_call
from test_nested_full_development import full_inputs, unfitted_selector_consumers, _physical_full_inputs, _unfitted_confirmed_decision
from test_a12_q_native import aar_source, _unfitted_gbm_loss_unit


def test_full0_gbm_common_stop_original_numbers_pair(
        full_inputs, unfitted_selector_consumers, aar_source, tmp_path, monkeypatch):
    """Actual paired Q compiler/reader and pinned losses; UNFITTED R leaf only."""
    from padml import f4, f4_compact, nested_loco as nested
    import shutil

    monkeypatch.setattr(runtime, 'effective_cpu_count', lambda: 9)
    plan, parts, final = _physical_full_inputs(full_inputs, tmp_path / 'inputs')
    selector = tmp_path / 'selector'
    f5._nested_full_selector_program(plan, parts, final, selector, rscript='UNFITTED', replay=False)
    base = _unfitted_confirmed_decision(fixed_bootstrap=True)
    decision = nested._sealed({**{k: v for k, v in base.items() if k != 'identity_sha256'},
        'twelve_month_development': nested._twelve_month_development_contract()})
    inputs = []
    for horizon in (24, 12):
        task = f5.compile_nested_full_complex_search_task(plan, parts, final, selector,
            family='GBM_COX', rscript='UNFITTED', **({'selection_horizon_months': horizon,
            'science_decision': decision} if horizon == 12 else {}))
        registered = f5._complex_runtime_registered_inputs(task, parts)
        spec = f5._complex_search_execution_spec(task, registered)
        spec.update(threads=56, pool_workers=56)
        spec['final_search_source']['producer_execution'] = {
            k: spec[k] for k in ('execution_mode', 'threads', 'pool_workers', 'engine_threads')}
        inputs.append({'kind': 'PADML_F5_Q_INPUT_V1', 'task': task, 'spec': spec})
    f5._full0_rsf_s1s2_input_pair(*inputs)
    source = tmp_path / 'source.zip'
    f4.compile_f45_source_bundle(source)
    source_identity = sha256_bytes(canonical_json_bytes(f4._f45_source_member_sha256()))
    q, job, native_calls, _, _ = _unfitted_gbm_loss_unit(aar_source, tmp_path, monkeypatch,
        'FULL0', full0_q_input=inputs[0])
    unit = f5._execute_and_verify_q_search_unit(job)
    assert native_calls == [False, True]
    projection, refs = f4_compact._full_pipeline_q_numerical_members(q,
        native_units=tuple(job['native_units']), transported_refs=unit['members'])
    old = tmp_path / 'retained-numbers'
    old.mkdir()
    for name, path in projection.items():
        target = old / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, target)
    assert not list(old.rglob('*.rds'))
    current = tmp_path / 'consumer-input.json'
    current.write_bytes(canonical_json_bytes(inputs[1]))
    pair = {'producer_input': {'path': str(old / 'input.json'), 'sha256': sha256_file(old / 'input.json'),
        'size_bytes': (old / 'input.json').stat().st_size},
        'consumer_input': {'path': str(current), 'sha256': sha256_file(current), 'size_bytes': current.stat().st_size},
        'retained_source_bundle': str(source), 'producer_source_identity': source_identity,
        'executor_source_identity': source_identity}
    original_bytes = {p: p.read_bytes() for root in (q, old) for p in root.rglob('*') if p.is_file()}
    loss_refs = {name: refs[f"native/{job['task_id']}/{name}"] for name in ('evaluation.json', 'output.json')}
    monkeypatch.setattr(f4.subprocess, 'run', lambda *a, **k: pytest.fail('NO_R_IN_COMMON_PREFIX_READ'))
    monkeypatch.setattr(kernel, '_grouped_cox_loss_path', lambda *a, **k: pytest.fail('NO_LOSS_RECALCULATION'))
    work = tmp_path / 'numbers-work'
    work.mkdir()
    twelve_job = (kernel._r_prediction_child_spec({**inputs[1]['spec'],
        'native_search_root': str(old / 'native'), 'native_search_replay': True}), *job['task'][1:])
    def consume(binding, task=twelve_job, label='success'):
        scratch = work / label
        scratch.mkdir()
        call = f5._q_search_unit_call(kernel._run_r_prediction_pool_task, task, old, scratch,
            mode='numbers', full0_rsf_s1s2_pair=binding, gbm_stop_loss_references=loss_refs)
        return kernel._run_r_prediction_pool_task(call)
    observed, = consume(pair)
    expected = strict_json_bytes((q / 'native' / job['task_id'] / 'evaluation.json').read_bytes())['result']
    assert all(observed[key] == value for key, value in expected.items())
    assert native_calls == [False, True] and not list((work / 'success').iterdir())
    for damage in ('source', 'input-pin', 'seed', 'stage', 'horizons', 'parameters'):
        changed_pair, changed_task = copy.deepcopy(pair), copy.deepcopy(twelve_job)
        if damage == 'source': changed_pair['producer_source_identity'] = 'a' * 64
        elif damage == 'input-pin': changed_pair['consumer_input']['sha256'] = 'a' * 64
        elif damage == 'seed': changed_task[2][0]['seed'] += 1
        elif damage == 'stage': changed_task[2][0]['task_id'] = 'S3A_T001_P01_M01_STOP'
        elif damage == 'horizons': changed_task[0]['horizons'] = list(range(1, 37))
        else: changed_task[2][0]['parameters']['max_trees'] += 1
        with pytest.raises(ContractError): consume(changed_pair, changed_task, damage)
    assert all(path.read_bytes() == raw for path, raw in original_bytes.items())
    assert native_calls == [False, True]
    # A compact completed Q keeps the old input separately while all actual
    # numerical/native-reference bytes retain their original coordinates.
    relocated = tmp_path / 'relocated-complete-q'
    shutil.copytree(old, relocated)
    evidence = relocated / 'execution-evidence/gbm-common'
    evidence.mkdir(parents=True)
    shutil.copyfile(relocated / 'input.json', evidence / 'input.json')
    (relocated / 'input.json').write_bytes(canonical_json_bytes(inputs[1]))
    relocated_pair = copy.deepcopy(pair)
    relocated_pair['producer_input']['path'] = str(evidence / 'input.json')
    relocated_pair['consumer_input']['path'] = str(relocated / 'input.json')
    projection, actual_refs = f4_compact._full_pipeline_q_numerical_members(relocated,
        native_units=tuple(job['native_units']), transported_refs=refs)
    assert actual_refs == refs and projection['input.json'] == evidence / 'input.json'
    relocated_work = work / 'relocated'
    relocated_work.mkdir()
    relocated_call = f5._q_search_unit_call(kernel._run_r_prediction_pool_task, twelve_job,
        relocated, relocated_work, mode='numbers', full0_rsf_s1s2_pair=relocated_pair,
        gbm_stop_loss_references=loss_refs)
    relocated_result, = kernel._run_r_prediction_pool_task(relocated_call)
    assert relocated_result == observed and native_calls == [False, True]
    wrong_input_refs = copy.deepcopy(refs)
    wrong_input_refs['input.json']['sha256'] = '0' * 64
    with pytest.raises(ContractError):
        f4_compact._full_pipeline_q_numerical_members(relocated,
            native_units=tuple(job['native_units']), transported_refs=wrong_input_refs)
    assert all(path.read_bytes() == raw for path, raw in original_bytes.items())


def _call(tmp_path):
    call = list(_primary_call(tmp_path))
    spec = call[0]
    for name in ('primary_search_source', 'selection_horizon_months', 'trial_scoring'):
        spec.pop(name, None)
    spec.update(execution_scope='F5_FULL_DEVELOPMENT_SEARCH', family='GBM_COX', fold=0,
        heldout_center=0, seed=300000, horizons=list(range(37)),
        final_search_source={'family': 'GBM_COX', 'virtual_outer': 0, 'task_sha256': 'd' * 64})
    spec['selector_from_dependency']['outer_recipe_sha256'] = 'RAW_CANONICAL'
    identifier = 'F5_STOP_R01_K01'
    call[1].update(kind='PADML_F5_REGISTERED_PARTITION_INPUTS', fold=0, outer_count=0,
        diagnostic_count=0, full_count=0, view_count=30, projected_partition_ids=[identifier])
    for row in (call[1]['partitions'][0], call[6]):
        row.update(partition_id=identifier, kind='STOP', consumer_set=['GBM_COX', 'XGBOOST_COX', 'COXTIME_SET_A'])
    call[2] = [{'task_id': 'S1_T001_P01_M01_STOP', 'partition_id': identifier,
        'imputation': 1, 'family': 'GBM_COX', 'selected_parents': ['UNFITTED_X'],
        'parameters': {'UNFITTED': True}, 'producer_kind': 'GBM_STOP_CURVE', 'seed': 310101}]
    call[5] = 'GROUPED_COX_LOCK'
    return call


def test_full0_gbm_original_s1_single_model_atoms():
    phase, names = f5._a12_q_stop_phase('S1', family='GBM_COX')
    groups = [[f'S1_T{trial:03d}_P{part:02d}_M01_STOP']
              for trial in range(1, 29) for part in range(1, 6)]
    assert names == ['batch-' + sha256_bytes(canonical_json_bytes(group))[:24] for group in groups]
    assert len(names) == len(set(names)) == 140
    assert phase == '_run_r_prediction_pool_task-8d98c433933427ac099ed3f8'
    assert f5._a12_q_prepared_predecessors('S1', refit=False, family='GBM_COX') == {'total': 0, 'stop': 0}
    assert len(f5._a12_q_stop_phase('S1', refit=True, family='GBM_COX')[1]) == 70
    with pytest.raises(ContractError):
        f5._a12_q_stop_phase('S1', refit=0, family='GBM_COX')


def test_full0_gbm_retention_lower_bound_rejects_before_fit_geometry(tmp_path):
    call = _call(tmp_path)
    call[2][0]['parameters']['max_trees'] = 5000
    call[6]['fit_response'] = {'row_count': 1440}
    call[6]['evaluation_response'] = {'row_count': 254}
    call[6]['fit_ids'] = [f'fit-{i}' for i in range(1440)]
    call[6]['evaluation_ids'] = [f'eval-{i}' for i in range(254)]
    task_id = 'batch-UNFITTED-GBM-STOP'
    job = {'function': '_run_r_prediction_pool_task', 'task_id': task_id,
        'task': call, 'native_units': ['UNFITTED'],
        'retained_bytes_per_task': 64 * 1024**2}
    with pytest.raises(ContractError, match='F5_Q_BATCH_RETENTION_PREFLIGHT_EXCEEDED:') as captured:
        f5._q_batch_retention_preflight([job], 100104)
    detail = strict_json_bytes(str(captured.value).split(':', 1)[1].encode())
    components = detail['tasks'][task_id]
    assert components == {'produce_native_risk_bytes': 67760000,
        'first_native_replay_risk_bytes': 67760000,
        'numerical_projection_risk_bytes': 67760000,
        'model_object_lower_bound_bytes': 1, 'input_projection_bytes': 100104,
        'required_lower_bound_bytes': 203380105}
    assert detail['supplied_retained_bytes_per_task'] == {task_id: 64 * 1024**2}
    job['retained_bytes_per_task'] = 256 * 1024**2
    assert f5._q_batch_retention_preflight([job], 100104) == {task_id: components}


@pytest.mark.parametrize('complete', [False, True])
def test_full0_gbm_partial_atom_recovery_is_zero_fit(tmp_path, monkeypatch, complete):
    from padml import f4_compact
    root = tmp_path / 'recovered-q'
    task_id, model_id = 'batch-UNFITTED', 'S1_T001_P01_M01_STOP'
    for base in (root / 'native' / task_id, root / 'native' / model_id):
        base.mkdir(parents=True, exist_ok=True)
    original = root / 'native' / task_id
    for name, raw in {'output.json': b'{}\n', 'evaluation.json': b'{"loss":1}\n',
                      'risk-001-gbm-fit.bin': b'fit', 'risk-001-gbm-evaluation.bin': b'eval'}.items():
        (original / name).write_bytes(raw)
    (root / 'native' / model_id / 'model.rds').write_bytes(b'MODEL')
    if complete:
        replay = root / 'native-replay' / task_id
        replay.mkdir(parents=True)
        for path in original.iterdir():
            if path.is_file(): (replay / path.name).write_bytes(path.read_bytes())
    projection_file = root / 'UNFITTED-projection.bin'
    projection_file.write_bytes(b'projection')
    refs = {f'native/{task_id}/evaluation.json': {'sha256': sha256_file(original / 'evaluation.json'),
            'size_bytes': (original / 'evaluation.json').stat().st_size},
        f'native/{task_id}/output.json': {'sha256': sha256_file(original / 'output.json'),
            'size_bytes': (original / 'output.json').stat().st_size}}
    monkeypatch.setattr(f4_compact, '_full_pipeline_q_numerical_members',
        lambda *a, **k: ({'projection.bin': projection_file}, refs))
    calls = []
    def unit_call(function, task, owner, scratch, *, mode, native_audit_evidence_root=None, **kwargs):
        calls.append(mode)
        return {'mode': mode, 'evidence': native_audit_evidence_root}
    monkeypatch.setattr(f5, '_q_search_unit_call', unit_call)
    def run(call):
        if call['mode'] == 'audit':
            replay = Path(call['evidence']) / task_id
            replay.mkdir()
            for path in original.iterdir():
                if path.is_file(): (replay / path.name).write_bytes(path.read_bytes())
        return {'UNFITTED_SAME_NUMBERS': True}
    monkeypatch.setattr(kernel, '_run_r_prediction_pool_task', run)
    monkeypatch.setattr(runtime, 'observe_step_memory', lambda: {'rss_bytes': 1, 'cgroup_current_bytes': 1})
    monkeypatch.setattr(runtime, 'release_step_resources', lambda files, *, owner, before, released_references:
        {'status': 'UNKNOWN', 'owner': owner, 'pid': 1, 'reason': 'UNFITTED'})
    call = _call(tmp_path)
    row = f5._recover_and_verify_partial_gbm_q_search_unit({'task_id': task_id, 'task': call,
        'root': str(root), 'work': str(root / 'recovery-work' / task_id),
        'native_units': [task_id, model_id], 'retained_bytes_per_task': 256 * 1024**2,
        'complete_original_audit': complete})
    assert calls == (['numbers'] if complete else ['audit', 'numbers'])
    assert row['partial_recovery'] == {'new_model_fit_count': 0,
        'new_first_native_audit_count': 0 if complete else 1,
        'reused_complete_first_native_audit_count': 1 if complete else 0,
        'audit_evidence_root': str((root / 'native-replay' / task_id) if complete else
                                   (root / 'partial-native-audit' / task_id / task_id))}


@pytest.mark.parametrize('stage,trials,partitions,mis,atoms,total,stops', [
    ('S1', 28, 5, 1, 70, 0, 0), ('S2', 10, 5, 5, 65, 280, 140),
    ('S3A', 3, 5, 20, 100, 780, 390), ('S3B1', 2, 15, 5, 75, 1380, 690),
    ('S3B2', 1, 15, 20, 75, 1680, 840)])
@pytest.mark.parametrize('refit', [False, True])
@pytest.mark.parametrize('horizon', [24, 12])
def test_full0_gbm_all_phases_match_original_r_geometry_and_transport(
        tmp_path, monkeypatch, stage, trials, partitions, mis, atoms, total, stops, refit, horizon):
    call = _call(tmp_path)
    spec = call[0]
    spec.update(execution_mode='PROCESS_POOL', threads=56, pool_workers=56, engine_threads=1,
                monthly_fit_horizons=list(range(1, 37)))
    if horizon == 12:
        scoring = copy.deepcopy(f5.load_science_authority()['science']['f2_model_development']['trial_scoring'])
        scoring.update(ibs_grid_months=list(range(13)), ibs_integration='TRAPEZOID_DIVIDE_BY_12')
        spec.update(selection_horizon_months=12, trial_scoring=scoring)
        spec['final_search_source'].update(selection_horizon_months=12, science_decision_sha256='e' * 64)
    directory = Path(call[6]['covariates']['input_dir'])
    for imp in range(2, 21):
        (directory / f'imp{imp:02d}.csv').write_bytes((directory / 'imp01.csv').read_bytes())
    stage_index = ('S1', 'S2', 'S3A', 'S3B1', 'S3B2').index(stage) + 1
    rows, tasks = [], []
    for part in range(1, partitions + 1):
        repeat = stage_index if stage_index <= 3 else (part - 1) // 5 + 1
        identifier = f"F5_{'' if refit else 'STOP_'}R{repeat:02d}_K{(part - 1) % 5 + 1:02d}"
        rows.append({**copy.deepcopy(call[6]), 'partition_id': identifier,
            'repeat': repeat, 'inner_fold': (part - 1) % 5 + 1, 'kind': 'INNER' if refit else 'STOP'})
    registered = {key: value for key, value in call[1].items()
                  if key not in {'partitions', 'projected_partition_ids', 'projected_partition_count'}}
    registered['partitions'] = rows
    for trial in range(1, trials + 1):
        for part, row in enumerate(rows, 1):
            for imp in range(1, mis + 1):
                tasks.append({**call[2][0], 'task_id': f"{stage}_T{trial:03d}_P{part:02d}_M{imp:02d}_{'REFIT' if refit else 'STOP'}",
                    'partition_id': row['partition_id'], 'imputation': imp,
                    'seed': 300000 + stage_index * 10000 + 100 * imp + part,
                    'producer_kind': 'SURVIVAL' if refit else 'GBM_STOP_CURVE',
                    'parameters': {'UNFITTED': True, **({'locked_trees': 100 + imp} if refit else {})},
                    **({'prediction_horizons': list(range(1, 37))} if refit else {})})
    captured = []
    class NoNative(Exception):
        pass
    def boundary(actual_spec, function, calls, *, selected_slots):
        assert actual_spec is spec and function is kernel._run_r_prediction_pool_task and selected_slots == 56
        captured.extend(calls)
        raise NoNative
    monkeypatch.setattr(kernel, '_search_task_batch', boundary)
    with pytest.raises(NoNative):
        kernel._run_r_prediction_batch(spec, registered, tasks, tmp_path / 'work', tmp_path,
                                      evaluation_mode='IBS' if refit else 'GROUPED_COX_LOCK')
    units = f5._q_search_units(kernel._run_r_prediction_pool_task, captured)
    phase, ids = f5._a12_q_stop_phase(stage, refit=refit, family='GBM_COX')
    assert list(units) == ids and len(ids) == (atoms if refit else trials * partitions * mis)
    assert phase == kernel._run_r_prediction_pool_task.__name__ + '-' + sha256_bytes(canonical_json_bytes(ids))[:24]
    increment = trials * partitions * mis if refit else 0
    assert f5._a12_q_prepared_predecessors(stage, refit=refit, family='GBM_COX', full0=True) == {
        'total': total + increment, 'stop': stops + increment}
    if horizon == 12 and stage in {'S1', 'S2'}:
        with pytest.raises(ContractError): f5._a12_q_stop_unit_input(captured[0])
        return  # Common stages may be consumed, never published for refitting.
    if horizon == 12:
        q = tmp_path / 'boundary-q'
        q.mkdir()
        (q / 'input.json').write_bytes(b'{"UNFITTED":true}')
        control = dict(batches=[], used_batches=[], completed=False, prepare_only=True, task_ids=None,
            confirmed_model_fits=total + increment, confirmed_stop_fits=stops + increment,
            full0_rsf_s1s2_rescore={'producer_input': {'sha256': 'a' * 64, 'size_bytes': 1},
                'producer_source_identity': 'b' * 64, 'executor_source_identity': 'b' * 64})
        with pytest.raises(f5._QBatchBoundary) as prepared:
            f5._q_search_task_batch({**spec, 'native_search_root': str(q / 'native'),
                'native_search_batch': control}, kernel._run_r_prediction_pool_task, captured)
        assert prepared.value.result['phase'] == phase
        assert prepared.value.result['previously_completed_12_month_model_fit_count'] == total + increment - 780
        assert prepared.value.result['previously_completed_12_month_stop_fit_count'] == stops + increment - 390
        control['confirmed_model_fits'] -= 1
        with pytest.raises(ContractError, match='BOUNDARY_INVALID'):
            f5._q_search_task_batch({**spec, 'native_search_root': str(q / 'native'),
                'native_search_batch': control}, kernel._run_r_prediction_pool_task, captured)
    for original in captured:
        before = copy.deepcopy(original)
        files = {}
        value = f5._a12_q_stop_unit_input(original, files=files)
        assert original == before and value[2] == original[2]
        assert canonical_json_bytes(f5._a12_q_stop_unit_input(value)) == canonical_json_bytes(value)
        assert not kernel._contains_key(value[1], 'evaluation_response')
        assert not any(name.startswith('source/') for name in files)
        assert len(files) == len({row['imputation'] for row in original[2]}) + 2
    if refit:
        for damage in ('half', 'reverse', 'lock', 'seed'):
            bad = copy.deepcopy(captured[0])
            if damage == 'half': bad[2].pop()
            elif damage == 'reverse': bad[2].reverse()
            elif damage == 'lock': bad[2][0]['parameters']['locked_trees'] = True
            else: bad[2][0]['seed'] += 1
            with pytest.raises(ContractError): f5._a12_q_stop_unit_input(bad)


def test_full0_gbm_seven_slot_alias_safe_round_trip(tmp_path):
    call = _call(tmp_path)
    original = copy.deepcopy(call)
    files = {}
    value = f5._a12_q_stop_unit_input(call, files=files)
    assert call == original
    assert set(files) == {'data/F5_STOP_R01_K01/' + name for name in
                          ('imp01.csv', 'fit_response.csv', 'evaluation_response.csv')}
    assert len(value) == 7 and value[3:6] == ['work', '.', 'GROUPED_COX_LOCK']
    assert value[0]['final_search_source'] == call[0]['final_search_source']
    assert value[0]['horizons'] == list(range(37)) and value[2] == call[2]
    assert len(value[1]['partitions'][0]['covariates']['members']) == 20
    assert not kernel._contains_key(value[1], 'evaluation_response')
    assert not kernel._contains_key(value, 'private_bytes')
    assert not any(name.startswith('source/') for name in files)
    assert canonical_json_bytes(f5._a12_q_stop_unit_input(value)) == canonical_json_bytes(value)


@pytest.mark.parametrize('damage', ['two-models', 'refit', 's2', 'trial', 'partition', 'seed',
    'imputation', 'bool-imputation', 'bool-fold', 'horizons', 'bool-month', 'aar', 'primary',
    'horizon12', 'header', 'response-leak', 'locked-trees', 'recipe'])
def test_full0_gbm_transport_rejects_context_and_atom_drift(tmp_path, damage):
    call = _call(tmp_path)
    if damage == 'two-models': call[2].extend(copy.deepcopy(call[2]))
    elif damage == 'refit': call[5] = 'IBS'
    elif damage == 's2': call[2][0]['task_id'] = 'S2_T001_P01_M01_STOP'
    elif damage == 'trial': call[2][0]['task_id'] = 'S1_T029_P01_M01_STOP'
    elif damage == 'partition': call[2][0]['partition_id'] = 'F5_STOP_R01_K02'
    elif damage == 'seed': call[2][0]['seed'] += 1
    elif damage == 'imputation': call[2][0]['imputation'] = 2
    elif damage == 'bool-imputation': call[2][0]['imputation'] = True
    elif damage == 'bool-fold': call[0]['fold'] = False
    elif damage == 'horizons': call[0]['horizons'] = list(range(1, 37))
    elif damage == 'bool-month': call[0]['horizons'][0] = False
    elif damage == 'aar': call[0]['a12_source'] = {}
    elif damage == 'primary': call[0]['primary_search_source'] = {}
    elif damage == 'horizon12': call[0]['selection_horizon_months'] = 12
    elif damage == 'header': call[1]['view_count'] = 62
    elif damage == 'response-leak': call[1]['partitions'][0]['evaluation_response'] = call[6]['evaluation_response']
    elif damage == 'locked-trees': call[2][0]['parameters']['locked_trees'] = 100
    else: call[2][0]['transform_recipe'] = {}
    with pytest.raises(ContractError):
        f5._a12_q_stop_unit_input(call, files={})


def test_full0_gbm_original_publication_to_scoped_executor(
        full_inputs, unfitted_selector_consumers, tmp_path, monkeypatch):
    """Real task/ZIP/argument readers; candidate RNG and scientific execution are forbidden."""
    parameters = {"early_stopping_metric": "cox_deviance",
        "post_selection_refit": "full_main_training_at_selected_n_trees",
        "locked_iteration_mode": "full_main_training_without_reselection", "UNFITTED": True}
    candidates = {stage: [{"trial_id": f"UNFITTED-{stage}-{i}", "parameters": {**parameters, "UNFITTED_TRIAL": i},
        "parameter_sha256": sha256_bytes(canonical_json_bytes({**parameters, "UNFITTED_TRIAL": i}))}
        for i in range(count)] for stage, count in (("S1", 28), ("S2", 10))}
    monkeypatch.setattr(f5, "_final_complex_candidate_trials", lambda family: copy.deepcopy(candidates))
    def forbidden(*args, **kwargs):
        pytest.fail("NO_CANDIDATE_RNG_OR_NATIVE_FIT")
    monkeypatch.setattr(f5, "candidate_trials", forbidden)
    plan, parts, full = _physical_full_inputs(full_inputs, tmp_path / "inputs", complete_covariates=True)
    selector = tmp_path / "selector"
    f5._nested_full_selector_program(plan, parts, full, selector, rscript="UNFITTED", replay=False)
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda root: {
        "effective_cpus": 9, "available_memory_bytes": 10**12,
        "scratch_available_bytes": 10**12, "scratch_root": str(root)})
    phase, ids = f5._a12_q_stop_phase("S1", family="GBM_COX")
    root = tmp_path / "search/GBM_COX"
    root.parent.mkdir()
    outputs = [[str(tmp_path / f"shard-{i}.zip"), *ids[i::7]] for i in range(7)]
    policy = {"configured_worker_ceiling": runtime.CPU_MINUS_8, "memory_bytes_per_worker": 2 * 1024**3,
        "memory_reserve_bytes": 0, "scratch_bytes_per_worker": 1, "scratch_reserve_bytes": 0,
        "transfer_archive_worker_ceiling": 64}
    final_mice = tmp_path / "UNFITTED-MICE.zip"
    final_mice.write_bytes(b"NO_MICE_FIT_OR_REPLAY")
    sources = {"plan": plan, "science_decision": _unfitted_confirmed_decision(fixed_bootstrap=True),
        "search_roots": {"GBM_COX": str(root)}, "selector_root": str(selector),
        "mice_root": str(tmp_path / "inputs"), "final_mice_path": str(final_mice),
        "response_path": full["fit_response"]["path"], "resource_policy": policy, "rscript": "UNFITTED"}
    source = tmp_path / "full-development.json"
    source.write_bytes(canonical_json_bytes(sources))
    @contextmanager
    def materialized(*args, **kwargs):
        yield sources, parts, full
    monkeypatch.setattr(f5, "_materialized_full_data_development_sources", materialized)
    monkeypatch.setattr(f5, "_final_search_mice_members", lambda *a, **k: {"UNFITTED.zip": final_mice})
    result = f5.execute_final_complex_search(full_development_path=source, candidate_family="GBM_COX",
        target=tmp_path / "unwritten-result.zip", prepare_only=True,
        retained_bytes_per_task=1024**2, q_unit_outputs=outputs)
    monkeypatch.setattr(f5.subprocess, "run", forbidden)
    assert result["status"] == "PREPARED_Q_BATCH" and result["phase"] == phase
    assert result["new_model_fits"] == 0 and result["task_ids"] == ids
    published = strict_json_bytes((root / "prepared-unit-inputs.json").read_bytes())["outputs"]
    assert [row["task_ids"] for row in published] == [row[1:] for row in outputs]
    assert sum(len(row["task_ids"]) for row in published) == len(set(ids)) == 140
    originals = {p: p.read_bytes() for p in root.rglob("*") if p.is_file()}
    calls = []
    def execution_boundary(function, units, owner, control, actual_phase, input_ref, **kwargs):
        assert function is kernel._run_r_prediction_pool_task and actual_phase == phase
        assert list(units) == control["task_ids"] == ids[::7]
        assert control["execution_worker_memory_bytes"] == 2 * 1024**3
        assert control["execution_scratch_reserve_bytes"] == 0
        for call, native in units.values():
            assert call[5] == "GROUPED_COX_LOCK" and len(call[2]) == 1
            assert Path(call[6]["evaluation_response"]["path"]).is_file()
            assert "evaluation_response" not in call[1]["partitions"][0]
            assert (Path(call[1]["partitions"][0]["covariates"]["input_dir"]) / "imp01.csv").is_file()
        calls.append(owner)
        raise f5._QBatchBoundary({"UNFITTED_EXECUTION_BOUNDARY": True})
    monkeypatch.setattr(f5, "_execute_q_search_batch", execution_boundary)
    payload = Path(outputs[0][0])
    def execute(payload, suffix, **changes):
        return f5.execute_final_complex_search(candidate_family="GBM_COX", target=tmp_path / f"worker-{suffix}",
            task_ids=ids[::7], batch_root=tmp_path / f"batch-{suffix}", retained_bytes_per_task=1024**2,
            prepared_q_input=payload, prepared_q_input_sha256=sha256_file(payload), **changes)
    assert execute(payload, "good") == {"UNFITTED_EXECUTION_BOUNDARY": True}
    assert len(calls) == 1
    with pytest.raises(ContractError): execute(payload, "good")
    for damage in ("parameters", "seed", "selected", "stop-source", "q-spec", "predecessor", "assignment"):
        with zipfile.ZipFile(payload) as archive:
            members = {name: archive.read(name) for name in archive.namelist()}
        record = strict_json_bytes(members["prepared-q.json"])
        first = record["task_ids"][0]
        args = [copy.deepcopy(record["arguments"][pin]) for pin in record["units"][first]]
        if damage == "parameters": args[2][0]["parameters"]["UNFITTED_TRIAL"] = -1
        elif damage == "seed": args[2][0]["seed"] += 1
        elif damage == "selected": args[2][0]["selected_parents"] = ["AST_ALT"]
        elif damage == "stop-source": args[6]["algorithm"] = "UNFITTED_FOREIGN_STOP"
        elif damage == "predecessor": record["predecessor_execution_sha256"] = ["a" * 64]
        elif damage == "assignment": record["task_ids"].reverse()
        else:
            q = strict_json_bytes(members["input.json"])
            q["spec"]["seed"] += 1
            members["input.json"] = canonical_json_bytes(q)
            record["input"] = {"sha256": sha256_bytes(members["input.json"]), "size_bytes": len(members["input.json"])}
        if damage in {"parameters", "seed", "selected", "stop-source"}:
            record["units"][first] = [sha256_bytes(canonical_json_bytes(arg)) for arg in args]
            record["arguments"].update({sha256_bytes(canonical_json_bytes(arg)): arg for arg in args})
            used = {pin for pins in record["units"].values() for pin in pins}
            record["arguments"] = {pin: arg for pin, arg in record["arguments"].items() if pin in used}
        members["prepared-q.json"] = canonical_json_bytes(record)
        changed = tmp_path / f"changed-{damage}.zip"
        write_deterministic_zip(changed, members)
        with pytest.raises(ContractError): execute(changed, damage)
    assert len(calls) == 1
    # Preserve the original private GBM full0 call's omitted-family default;
    # Python workers require their explicit family binding from the public entry.
    assert f5._execute_a12_prepared_q_batch(payload, tmp_path / 'worker-private-gbm',
        expected_sha256=sha256_file(payload), task_ids=ids[::7], batch_root=tmp_path / 'batch-private-gbm',
        retained_bytes_per_task=1024**2, full0_only=True) == {'UNFITTED_EXECUTION_BOUNDARY': True}
    assert len(calls) == 2
    assert {p: p.read_bytes() for p in root.rglob("*") if p.is_file()} == originals


def test_full0_gbm_prepared_public_scope_stops_before_payload_read(tmp_path, monkeypatch):
    monkeypatch.setattr(f5, "_execute_a12_prepared_q_batch", lambda *a, **k: pytest.fail("invalid public scope"))
    base = dict(candidate_family="GBM_COX", target=tmp_path / "q", task_ids=["unit"],
        batch_root=tmp_path / "batch", retained_bytes_per_task=1,
        prepared_q_input=tmp_path / "input.zip", prepared_q_input_sha256="a" * 64)
    for changed in ({"candidate_family": "RSF"}, {"selection_horizon_months": True}, {"prepare_only": True},
                    {"full_development_path": tmp_path / "lineage.json"}, {"q_batches": []},
                    {"prepared_q_input_sha256": None}, {"retained_bytes_per_task": True}):
        with pytest.raises(ContractError): f5.execute_final_complex_search(**{**base, **changed})


def test_full0_gbm_partial_recovery_public_entry_is_one_bounded_call(tmp_path, monkeypatch):
    root = tmp_path / 'preserved-partial-root'
    root.mkdir()
    prepared, source = tmp_path / 'prepared.zip', tmp_path / 'source.zip'
    prepared.write_bytes(b'UNFITTED_PREPARED')
    source.write_bytes(b'UNFITTED_SOURCE')
    captured = []
    monkeypatch.setattr(f5, '_execute_a12_prepared_q_batch',
        lambda *a, **k: captured.append((a, k)) or {'UNFITTED_BOUNDARY': True})
    recovery = {'failed_execution': str(tmp_path / 'failed-execution.json'),
        'failed_execution_sha256': 'a' * 64,
        'remaining_batch_root': str(tmp_path / 'remaining-batch'),
        'complete_coordinate': 'S1_T003_P01_M01_STOP'}
    result = f5.execute_final_complex_search(candidate_family='GBM_COX', target=root,
        task_ids=['UNFITTED_ALL_140'], batch_root=tmp_path / 'recovery-batch',
        retained_bytes_per_task=256 * 1024**2, prepared_q_input=prepared,
        prepared_q_input_sha256='b' * 64, prepared_source_bundle=source,
        partial_gbm_recovery=recovery)
    assert result == {'UNFITTED_BOUNDARY': True} and len(captured) == 1
    assert captured[0][1]['partial_gbm_recovery'] == recovery
    assert captured[0][1]['prepared_source_bundle'] == source
    with pytest.raises(ContractError, match='F5_FULL0_GBM_PARTIAL_RECOVERY_SCOPE_INVALID'):
        f5.execute_final_complex_search(candidate_family='GBM_COX', target=root,
            task_ids=['UNFITTED_ALL_140'], batch_root=tmp_path / 'recovery-batch',
            retained_bytes_per_task=256 * 1024**2, prepared_q_input=prepared,
            prepared_q_input_sha256='b' * 64, partial_gbm_recovery=recovery)


def test_full0_gbm_e751_receipts_reach_original_numerical_consumer(tmp_path, monkeypatch):
    """The exact old executor may carry operations; science and geometry remain current-checked."""
    from padml import f4_compact

    owner = tmp_path / 'owner'
    (owner / 'native').mkdir(parents=True)
    raw_input = b'{}\n'
    (owner / 'input.json').write_bytes(raw_input)
    input_ref = {'sha256': sha256_bytes(raw_input), 'size_bytes': len(raw_input)}
    policy = {'configured_worker_ceiling': runtime.CPU_MINUS_8, 'memory_bytes_per_worker': 1,
        'memory_reserve_bytes': 0, 'scratch_bytes_per_worker': 1, 'scratch_reserve_bytes': 0,
        'transfer_archive_worker_ceiling': 64}
    observation = {'effective_cpus': 32, 'available_memory_bytes': 10**12,
        'scratch_available_bytes': 10**12, 'scratch_root': str(owner)}
    monkeypatch.setattr(runtime, 'observe_execution_resources', lambda root:
        {**observation, 'scratch_root': str(root)})
    monkeypatch.setattr(runtime, 'validate_resource_release', lambda value: value)
    phase, ids = f5._a12_q_stop_phase('S1', family='GBM_COX')
    template = _call(tmp_path)
    units, projections = {}, {}
    for index, name in enumerate(ids):
        leaf = f'S1_T{index // 5 + 1:03d}_P{index % 5 + 1:02d}_M01_STOP'
        task = copy.deepcopy(template)
        task[2][0]['task_id'] = leaf
        native = (name, leaf)
        units[name] = (tuple(task), native)
    records = []
    for batch_index, selected in enumerate((ids[:24], ids[24:])):
        batch = tmp_path / ('recovered-existing24' if batch_index == 0 else 'new116')
        batch.mkdir()
        (batch / 'input.json').write_bytes(raw_input)
        rows = []
        for name in selected:
            native = units[name][1]
            files = {
                'input.json': batch / 'input.json',
                f'native/{name}/evaluation.json': batch / 'native' / name / 'evaluation.json',
                f'native/{name}/output.json': batch / 'native' / name / 'output.json',
                f'native/{name}/risk-001-gbm-fit.bin': batch / 'native' / name / 'risk-001-gbm-fit.bin',
                f'native/{name}/risk-001-gbm-evaluation.bin': batch / 'native' / name / 'risk-001-gbm-evaluation.bin'}
            for relative, path in files.items():
                if relative == 'input.json':
                    continue
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(relative.encode())
            numerical = {relative: {'sha256': sha256_file(path), 'size_bytes': path.stat().st_size}
                         for relative, path in files.items()}
            projections[native] = (files, numerical)
            rows.append({'task_id': name, 'native_units': list(native), 'members': numerical,
                'numerical_members': numerical, 'retained_bytes': 1, 'first_native_audit_count': 1})
        effective = f5._q_batch_resource_policy(policy, len(raw_input), len(selected), 256 * 1024**2,
            execution_worker_memory_bytes=2 * 1024**3, execution_scratch_reserve_bytes=0)
        admission = runtime.resource_admission(effective, observation, legal_tasks=len(selected))
        releases = {'units': {name: {'owner': 'Q_UNIT:' + name} for name in selected},
            'worker_results': {str(index): {'owner': 'POOL_TASK_RESULT:' + str(index)}
                               for index in range(len(selected))}}
        execution = {'phase': phase, 'input': input_ref, 'task_ids': selected,
            'source_identity': 'e751fbe76e69e6310809177573e6eee4a01b5018b859a82dd45be270c9524297',
            'operational_identity': runtime.OPERATIONAL_IDENTITY, 'resource_policy': policy,
            'execution_worker_memory_bytes': 2 * 1024**3, 'execution_scratch_reserve_bytes': 0,
            'effective_policy': effective, 'resource_observation': observation, 'resource_admission': admission,
            'retained_bytes_per_task': 256 * 1024**2,
            'pool': {'configured_worker_ceiling': admission['limits']['configured'],
                'admitted_worker_ceiling': admission['admitted_worker_ceiling'],
                'runnable_task_count': len(selected), 'actual_worker_process_peak': 1,
                'completed_task_count': len(selected), 'engine_threads': 1, 'status': 'COMPLETED'},
            'units': rows, 'confirmed_first_native_audit_count': len(selected),
            'new_model_fit_count': len(selected), 'resource_release': releases}
        (batch / 'execution.json').write_bytes(canonical_json_bytes(execution))
        records.append((batch, execution))
    next_ids = f5._a12_q_stop_phase('S1', refit=True, family='GBM_COX')[1]
    control = {'resource_policy': policy, 'completed': False, 'prepare_only': True,
        'task_ids': None, 'q_unit_outputs': [['UNFITTED', *next_ids]], 'batches': records,
        'used_batches': [], 'confirmed_model_fits': 0, 'confirmed_stop_fits': 0,
        'execution_worker_memory_bytes': 2 * 1024**3, 'execution_scratch_reserve_bytes': 0,
        'retained_full0_gbm_q_source_identity':
            'e751fbe76e69e6310809177573e6eee4a01b5018b859a82dd45be270c9524297'}
    spec = {**template[0], 'native_search_root': str(owner / 'native'), 'native_search_batch': control}
    monkeypatch.setattr(f4_compact, '_full_pipeline_q_numerical_members',
        lambda root, *, native_units, transported_refs: projections[native_units])
    monkeypatch.setattr(f5, '_q_search_unit_call', lambda function, task, root, work, **kwargs: task)
    class ReachedOriginalReader(Exception):
        pass
    monkeypatch.setattr(f5, '_bounded_ordered_spawn',
        lambda *a, **k: (_ for _ in ()).throw(ReachedOriginalReader))
    with pytest.raises(ReachedOriginalReader):
        f5._consume_q_search_batches(spec, kernel._run_r_prediction_pool_task,
            units, records, phase, input_ref)
    bad = copy.deepcopy(control)
    bad['retained_full0_gbm_q_source_identity'] = '0' * 64
    with pytest.raises(ContractError, match='F5_FULL0_GBM_PARTIAL_RECOVERY_SOURCE_DRIFT'):
        f5._consume_q_search_batches({**spec, 'native_search_batch': bad},
            kernel._run_r_prediction_pool_task, units, records, phase, input_ref)


@pytest.mark.parametrize('completed_phases, prior_publication, continuous', [
    (1, False, False), (1, True, False), (2, False, False), (4, False, False), (4, False, True)])
def test_full0_gbm_complete_stop_numbers_feed_original_refit_publication(
        full_inputs, unfitted_selector_consumers, tmp_path, monkeypatch, completed_phases, prior_publication, continuous):
    """Scoped workers→original gather→next phase; all native leaves UNFITTED."""
    from test_q_funnel_shards import _six_shard_batches, _unfitted_leaves, _POLICY, _options
    parameters = {"early_stopping_metric": "cox_deviance",
        "post_selection_refit": "full_main_training_at_selected_n_trees",
        "locked_iteration_mode": "full_main_training_without_reselection", "max_trees": 100, "UNFITTED": True}
    f5._validate_final_refit_locked_spec('GBM_COX', {
        'family': 'GBM_COX', 'selected_trees': 70, 'parameters': parameters})
    candidates = {stage: [{"trial_id": f"UNFITTED-{stage}-{i}", "parameters": {**parameters, "UNFITTED_TRIAL": i},
        "parameter_sha256": sha256_bytes(canonical_json_bytes({**parameters, "UNFITTED_TRIAL": i}))}
        for i in range(count)] for stage, count in (("S1", 28), ("S2", 10))}
    monkeypatch.setattr(f5, '_final_complex_candidate_trials', lambda family: copy.deepcopy(candidates))
    monkeypatch.setattr(f5, 'candidate_trials', lambda *a, **k: pytest.fail('NO_CANDIDATE_RNG'))
    inputs = ([f'p{i:03d}' for i in range(350)],
              [center for center in (36, 38, 39, 48, 52, 54, 55) for _ in range(50)],
              [int(i < 140 and i % 2 == 1) for i in range(350)])
    plan, parts, full = _physical_full_inputs(inputs, tmp_path / 'inputs', complete_covariates=True)
    selector = tmp_path / 'selector'
    f5._nested_full_selector_program(plan, parts, full, selector, rscript='UNFITTED', replay=False)
    task = f5.compile_nested_full_complex_search_task(plan, parts, full, selector, family='GBM_COX',
        rscript='UNFITTED', resource_policy=_POLICY)
    # Producer56 defines historical atomic grouping, not actual concurrency.
    original_spec = f5._complex_search_execution_spec
    def producer_spec(*args, **kwargs):
        spec = original_spec(*args, **kwargs)
        spec.update(threads=56, pool_workers=56)
        return spec
    monkeypatch.setattr(f5, '_complex_search_execution_spec', producer_spec)
    monkeypatch.setattr(runtime, 'effective_cpu_count', lambda: 32)
    monkeypatch.setattr(runtime, 'observe_execution_resources', lambda root: {
        'effective_cpus': 32, 'available_memory_bytes': 10**12,
        'scratch_available_bytes': 10**12, 'scratch_root': str(root)})
    events, _ = _unfitted_leaves(monkeypatch, gbm_loss_fixture=True)
    owner, phases = tmp_path / 'original-owner', []
    with _six_shard_batches(monkeypatch, owner, _POLICY, phases,
                           stop_after=completed_phases, prepared_full0=True) as history:
        prepared = f5._final_complex_search_program(task, parts, owner, replay=False,
            resource_policy=_POLICY, batch_options=_options())
    next_stage, refit = ('S1', True) if completed_phases == 1 else ('S2', False) if completed_phases == 2 else ('S3A', False)
    phase, ids = f5._a12_q_stop_phase(next_stage, refit=refit, family='GBM_COX')
    assert prepared['phase'] == phase and len(history) == 6 * completed_phases
    assert phases[0]['unit_count'] == phases[0]['first_audits'] == 140
    assert all(('REFIT' not in name if completed_phases == 1 else not name.startswith(next_stage + '_'))
               for _, _, name in events)
    if completed_phases == 2:
        assert phases[1]['unit_count'] == 70 and phases[1]['first_audits'] == 140
    produced = [(mode, path) for mode, path, _ in events if mode != 'numbers']
    old_bytes = {p: p.read_bytes() for p in owner.rglob('*') if p.is_file()}
    if completed_phases == 4:
        from padml import f4, nested_loco as nested
        base = _unfitted_confirmed_decision(fixed_bootstrap=True)
        decision = nested._sealed({**{k: v for k, v in base.items() if k != 'identity_sha256'},
            'twelve_month_development': nested._twelve_month_development_contract()})
        with monkeypatch.context() as setup:
            setup.setattr(runtime, 'effective_cpu_count', lambda: 9)
            twelve_task = f5.compile_nested_full_complex_search_task(plan, parts, full, selector,
                family='GBM_COX', rscript='UNFITTED', resource_policy=_POLICY,
                selection_horizon_months=12, science_decision=decision)
        twelve = tmp_path / 'twelve' / 'search' / 'GBM_COX'
        twelve.parent.mkdir(parents=True)
        source = tmp_path / 'common-source.zip'
        f4.compile_f45_source_bundle(source)
        # Only lineage/materialization and the old selector algorithm leaf are
        # synthetic. The public call, Q compiler, full four-phase numerical
        # funnel and final operational reader are the real original entries.
        primary = tmp_path / 'UNFITTED-old-preparation-source.zip'
        primary.write_bytes(b'UNFITTED_OLD_PREPARATION_SOURCE_BOUNDARY')
        final_mice = tmp_path / 'UNFITTED-full-MICE.zip'
        final_mice.write_bytes(b'UNFITTED_NO_MICE_FIT_OR_REPLAY')
        old_lineage = tmp_path / 'original-full-development.json'
        lineage = twelve.parent.parent / 'full-development.json'
        common = dict(plan=plan, selector_root=str(selector), mice_root=str(tmp_path / 'inputs'),
            final_mice_path=str(final_mice), response_path=full['fit_response']['path'],
            resource_policy=_POLICY, rscript='UNFITTED', raw_input_binding={
                'f45_source_sha256': sha256_bytes(canonical_json_bytes({'UNFITTED': 'preparation-source'}))})
        old_sources = dict(common, science_decision=base, search_roots={'GBM_COX': str(owner)})
        sources = dict(common, science_decision=decision, selection_horizon_months=12,
                       search_roots={'GBM_COX': str(twelve)})
        old_lineage.write_bytes(canonical_json_bytes(old_sources))
        lineage.write_bytes(canonical_json_bytes(sources))
        (lineage.parent / 'preparation-execution.json').write_bytes(canonical_json_bytes({
            'retained_preparation': {'full_development_path': str(old_lineage),
                'full_development_sha256': sha256_file(old_lineage),
                'producer_source_bundle_sha256': sha256_file(primary),
                'plan_sha256': sha256_bytes(canonical_json_bytes(plan)), 'new_split_rng_calls': 0,
                'referenced_plan_mice_chains': 1220, 'mice_or_selector_completion_claimed': False}}))
        original_read_lineage = f5._read_final_lineage
        def read_lineage(path, **kwargs):
            return original_read_lineage(path, **kwargs)
        @contextmanager
        def materialized(path, parent, **kwargs):
            assert path == lineage and parent == lineage.parent
            assert kwargs['retained_full0_source_bundle'] == primary
            assert kwargs['retained_mice_plan'] == plan and kwargs['selection_horizon_months'] == 12
            assert 'selector_only' not in kwargs
            owned = Path(tempfile.mkdtemp(prefix='f5-full-development-inputs-', dir=parent))
            (owned / 'UNFITTED-materialized.bin').write_bytes(b'UNFITTED')
            yield sources, parts, full
            kwargs['q_input_lifecycle']['materialized_inputs'] = {'temporary_root': str(owned)}
        original_compile = f5.compile_nested_full_complex_search_task
        def compile_task(*args, **kwargs):
            assert kwargs['retained_full0_source_bundle'].read_bytes() == primary.read_bytes()
            assert 'retained_q_producer_source_bundle' not in kwargs
            with monkeypatch.context() as setup:
                setup.setattr(runtime, 'effective_cpu_count', lambda: 9)
                return original_compile(*args, **{**kwargs, 'workers': None})
        monkeypatch.setattr(f5, '_read_final_lineage', read_lineage)
        monkeypatch.setattr(f5, '_materialized_full_data_development_sources', materialized)
        monkeypatch.setattr(f5, '_final_search_mice_members', lambda *a, **k: {})
        monkeypatch.setattr(f5, 'compile_nested_full_complex_search_task', compile_task)
        outputs = [[str(tmp_path / f'twelve-s3a-{index}.zip'), *ids[index::7]] for index in range(7)]
        def read_prefix(batches):
            return f5.execute_final_complex_search(full_development_path=lineage,
                candidate_family='GBM_COX', target=tmp_path / 'not-a-scientific-archive.zip',
                selection_horizon_months=12, prepare_only=True, q_batches=batches,
                retained_full0_source_bundle=primary, retained_q_producer_source_bundle=source,
                retained_bytes_per_task=4 * 1024**2, q_unit_outputs=outputs)
        before_read = list(events)
        with pytest.raises(ContractError, match='COVERAGE'):
            read_prefix(history[:-1])
        assert events == before_read
        observed = read_prefix(history)
        assert observed['phase'] == phase and observed['task_ids'] == ids
        assert observed['historical_prediction_fit_count'] == observed['historical_stop_fit_count'] == 390
        assert observed['historical_model_fit_count'] == observed['historical_first_native_audit_count'] == 780
        assert observed['new_model_fits'] == observed['new_first_native_audit_count'] == observed['new_stop_fits'] == 0
        assert len(observed['next_atomic_units']) == 300 and observed['selection_horizon_months'] == 12
        assert observed['consumer_input']['sha256'] != observed['producer_input']['sha256']
        report = observed['execution_report']
        assert report['family'] == 'GBM_COX' and report['execution_scratch_reserve_bytes'] == 0
        assert Path(report['report_path']).read_bytes() == canonical_json_bytes(observed)
        def consume(value, expected):
            f5._validate_full0_q_input_execution(value, source=lineage, source_sha256=sha256_file(lineage),
                source_identity=report['source_identity'], q_root=twelve, q_input=observed['consumer_input'],
                task_sha256=twelve_task['task_sha256'], expected_result_sha256=expected,
                selector_root=selector, selector_binding=report['selector_binding'],
                selector_partitions=strict_json_bytes((selector / 'partitions.json').read_bytes()),
                policy=_POLICY, selection_horizon_months=12, rescore_task=twelve_task,
                retained_q_input=observed['producer_input'], retained_source_identity=observed['producer_source_identity'])
        consume(observed, report['result_sha256'])
        for damage in ('count', 'seed', 'parameters', 'coordinate', 'source', 'horizon'):
            bad = copy.deepcopy(observed)
            row = bad['next_atomic_units'][0]['producer_tasks'][0]
            if damage == 'count': bad['new_stop_fits'] = 1
            elif damage == 'seed': row['seed'] += 1
            elif damage == 'parameters': row['parameters'] = {'UNFITTED_FOREIGN': True}
            elif damage == 'coordinate': row['partition_id'] = 'F5_STOP_R02_K01'
            elif damage == 'source': bad['producer_source_identity'] = '0' * 64
            else: bad['selection_horizon_months'] = 24
            expected = sha256_bytes(canonical_json_bytes({k: v for k, v in bad.items() if k != 'execution_report'}))
            bad['execution_report']['result_sha256'] = expected
            with pytest.raises(ContractError): consume(bad, expected)
        assert [(mode, path) for mode, path, _ in events if mode != 'numbers'] == produced
        assert {p: p.read_bytes() for p in owner.rglob('*') if p.is_file()} == old_bytes
        publication = strict_json_bytes((twelve / 'prepared-unit-inputs.json').read_bytes())
        assert publication['input'] == observed['consumer_input'] and publication['phase'] == phase
        assert [row['task_ids'] for row in publication['outputs']] == [row[1:] for row in outputs]
        payload = Path(outputs[0][0])
        with zipfile.ZipFile(payload) as archive:
            record = strict_json_bytes(archive.read('prepared-q.json'))
        assert record['predecessor_fit_counts'] == {'total': 780, 'stop': 390}
        assert len(record['predecessor_execution_sha256']) == 24
        checked = []
        original_execute = f5._execute_q_search_batch
        def no_new_science(function, units, root, control, actual_phase, input_ref, **kwargs):
            assert function is kernel._run_r_prediction_pool_task
            assert actual_phase == phase and list(units) == ids[::7]
            assert input_ref == observed['consumer_input']
            for call, native in units.values():
                assert call[0]['selection_horizon_months'] == 12 and call[5] == 'GROUPED_COX_LOCK'
                assert len(call[2]) == 1 and call[2][0]['task_id'].startswith('S3A_')
                assert call[6]['partition_id'].startswith('F5_STOP_R03_')
            checked.append(True)
            raise f5._QBatchBoundary({'UNFITTED_TWELVE_S3A_BOUNDARY': True})
        monkeypatch.setattr(f5, '_execute_q_search_batch', no_new_science)
        def worker(horizon, name):
            return f5.execute_final_complex_search(candidate_family='GBM_COX', selection_horizon_months=horizon,
                target=tmp_path / name, task_ids=ids[::7], batch_root=tmp_path / (name + '-result'),
                retained_bytes_per_task=4 * 1024**2, prepared_q_input=payload,
                prepared_q_input_sha256=sha256_file(payload))
        with pytest.raises(ContractError): worker(24, 'wrong-window-worker')
        assert not checked
        assert worker(12, 'twelve-worker') == {'UNFITTED_TWELVE_S3A_BOUNDARY': True}
        assert checked == [True]
        assert [(mode, path) for mode, path, _ in events if mode != 'numbers'] == produced
        assert {p: p.read_bytes() for p in owner.rglob('*') if p.is_file()} == old_bytes
        # Produce synthetic S3A STOP evidence through the same public workers,
        # then read the mixed old prefix/new suffix to the independent REFIT
        # boundary. Native leaves remain UNFITTED; the original consumers run.
        monkeypatch.setattr(f5, '_execute_q_search_batch', original_execute)
        tail, tail_fits = [], 0
        for index, output in enumerate(outputs):
            payload = Path(output[0])
            destination = tmp_path / f'twelve-s3a-complete-{index}'
            result = f5.execute_final_complex_search(candidate_family='GBM_COX', selection_horizon_months=12,
                target=tmp_path / f'twelve-s3a-target-{index}', task_ids=output[1:], batch_root=destination,
                retained_bytes_per_task=4 * 1024**2, prepared_q_input=payload,
                prepared_q_input_sha256=sha256_file(payload))
            assert result['status'] == 'COMPUTED_Q_BATCH'
            assert result['execution']['new_model_fit_count'] == result['execution']['confirmed_first_native_audit_count'] == len(output[1:])
            tail_fits += result['execution']['new_model_fit_count']
            tail.append(destination)
        produced_tail = [(mode, path) for mode, path, _ in events if mode != 'numbers']
        assert tail_fits == 300
        assert len(produced_tail) == len(produced) + 1200  # Each synthetic batch and model logs produce + audit.
        twelve = tmp_path / 'twelve-next' / 'search' / 'GBM_COX'
        sources['search_roots']['GBM_COX'] = str(twelve)
        retained_preparation = (lineage.parent / 'preparation-execution.json').read_bytes()
        lineage = twelve.parent.parent / 'full-development.json'
        lineage.parent.mkdir(parents=True)
        twelve.parent.mkdir()
        lineage.write_bytes(canonical_json_bytes(sources))
        (lineage.parent / 'preparation-execution.json').write_bytes(retained_preparation)
        assert twelve == lineage.parent / 'search' / 'GBM_COX'
        assert twelve.parent.is_dir() and twelve.parent.resolve(strict=True) == twelve.parent
        phase, ids = f5._a12_q_stop_phase('S3A', refit=True, family='GBM_COX')
        outputs = [[str(tmp_path / f'twelve-refit-{index}.zip'), *ids[index::7]] for index in range(7)]
        before_read = list(events)
        with pytest.raises(ContractError, match='COVERAGE'):
            read_prefix(history + tail[:-1])
        assert events == before_read
        observed = read_prefix(history + tail)
        report = observed['execution_report']
        assert observed['phase'] == phase and observed['task_ids'] == ids
        assert observed['historical_model_fit_count'] == 780
        assert observed['previously_completed_12_month_model_fit_count'] == 300
        assert observed['previously_completed_12_month_stop_fit_count'] == 300
        assert observed['new_model_fits'] == observed['new_stop_fits'] == 0
        assert len(observed['next_atomic_units']) == 100
        consume(observed, report['result_sha256'])
        assert all(len(atom['producer_tasks']) == 3 for atom in observed['next_atomic_units'])
        assert [(mode, path) for mode, path, _ in events if mode != 'numbers'] == produced_tail
        assert {p: p.read_bytes() for p in owner.rglob('*') if p.is_file()} == old_bytes
        complete_root, remaining = tmp_path / 'twelve-complete' / 'search' / 'GBM_COX', []
        complete_root.parent.mkdir(parents=True)
        lineage = complete_root.parent.parent / 'full-development.json'
        sources['search_roots']['GBM_COX'] = str(complete_root)
        lineage.write_bytes(canonical_json_bytes(sources))
        (lineage.parent / 'preparation-execution.json').write_bytes(retained_preparation)
        archive_path = tmp_path / 'gbm12-complete.zip'
        options = {}
        if continuous:
            suffix_owner = tmp_path / 'one-original-gbm-owner'
            suffix_owner.mkdir()
            approved = dict(f5._a12_q_stop_phase(stage, refit=refit, family='GBM_COX')
                for stage in ('S3A', 'S3B1', 'S3B2') for refit in (False, True)
                if stage != 'S3A' or refit)
            options = {'continuous_batch_root': suffix_owner, 'full0_continuous_phase_task_ids': {},
                'retained_bytes_per_task': 64 * 1024**2}
        with (nullcontext() if continuous else
              _six_shard_batches(monkeypatch, complete_root, _POLICY, remaining, prepared_full0=True)):
            published = f5.execute_final_complex_search(full_development_path=lineage,
                candidate_family='GBM_COX', target=archive_path, selection_horizon_months=12,
                prepare_only=not continuous, q_batches=history + tail,
                retained_full0_source_bundle=primary, retained_q_producer_source_bundle=source, **options)
        assert published['status'] == 'COMPUTED' and published['stage_acceptance'] is False
        completed = published['execution_archive']['result']
        completed_input = published['execution_archive']['execution_evidence']['q_input_execution']
        assert completed_input['status'] == 'COMPUTED_Q_SEARCH'
        assert completed_input['previously_completed_12_month_model_fit_count'] == (300 if continuous else 1500)
        assert completed_input['previously_completed_12_month_stop_fit_count'] == (300 if continuous else 750)
        assert completed_input['new_model_fits'] == completed_input['new_first_native_audit_count'] == (1200 if continuous else 0)
        assert completed_input['new_stop_fits'] == (450 if continuous else 0)
        if continuous:
            remaining = [strict_json_bytes((suffix_owner / phase / 'execution.json').read_bytes()) for phase in approved]
            assert all(row['task_ids'] == approved[row['phase']] for row in remaining)
            assert len(remaining) == 5 and sum(row['confirmed_first_native_audit_count'] for row in remaining) == 1200
            assert completed_input['continuous_phase_task_ids'] == approved
            assert options['full0_continuous_phase_task_ids'] == approved
        else:
            assert len(remaining) == 5 and sum(row['first_audits'] for row in remaining) == 1200
        assert completed['total_search_fit_count'] == 2280
        assert completed['response_free_stopping_fit_count'] == 1140
        assert completed['selected_spec']['selection_metric'] == 'IBS_0_12'
        f5._validate_shared_complex_search_result(completed, twelve_task)
        completed_bytes = {p: p.read_bytes() for p in complete_root.rglob('*') if p.is_file()}
        completed_producers = [(mode, path) for mode, path, _ in events if mode != 'numbers']
        # The downstream full0 score consumer uses this same original replay
        # entry without manually supplying or rebuilding prefix evidence.
        actual = f5._final_complex_search_program(twelve_task, parts, complete_root,
            replay=True, resource_policy=_POLICY)
        assert actual == completed
        assert [(mode, path) for mode, path, _ in events if mode != 'numbers'] == completed_producers
        assert {p: p.read_bytes() for p in complete_root.rglob('*') if p.is_file()} == completed_bytes
        assert {p: p.read_bytes() for p in owner.rglob('*') if p.is_file()} == old_bytes
        # MICE remains an explicit synthetic materialization boundary. The
        # archive, separate source roles, operational receipt, Q numerical
        # replay and final exact result comparison are original consumers.
        def preparation_proof(payload, **kwargs):
            assert kwargs == {'full0_preparation': True}
            assert payload.read_bytes() == primary.read_bytes()
            return {'UNFITTED': 'preparation-source'}
        monkeypatch.setattr(f4, '_retained_full0_source_members', preparation_proof)
        monkeypatch.setattr(f5, '_validate_final_search_plan', lambda actual_plan, mice, response, **kwargs:
            full['development_input'] if actual_plan == kwargs['retained_mice_plan'] == plan else pytest.fail('plan drift'))
        monkeypatch.setattr(f5, '_materialize_final_search_inputs', lambda *a, **k: parts)
        monkeypatch.setattr(f5, 'materialize_final_full_data_mice', lambda *a, **k: full)
        references = []
        reread = f5.read_final_complex_search(archive_path, rscript='UNFITTED', on_native_references=references.extend)
        assert reread == published['execution_archive'] and references
        with zipfile.ZipFile(archive_path) as zipped:
            assert zipped.read('inputs/retained-preparation/source.zip') == primary.read_bytes()
            assert zipped.read('search/execution-evidence/gbm-common/source.zip') == source.read_bytes()
            assert zipped.read('inputs/retained-preparation/full-development.json') == old_lineage.read_bytes()
            assert zipped.read('inputs/full-development.json') == lineage.read_bytes()
        for damage in ('new-fit', 'historical-count', 'suffix-count', 'phase', 'window', 'producer'):
            bad = copy.deepcopy(completed_input)
            if damage == 'new-fit': bad['new_model_fits'] = 1
            elif damage == 'historical-count': bad['historical_stop_fit_count'] -= 1
            elif damage == 'suffix-count': bad['previously_completed_12_month_stop_fit_count'] -= 1
            elif damage == 'phase': bad['phase'] = 'UNFITTED_NEXT_PHASE'
            elif damage == 'window': bad['selection_horizon_months'] = 24
            else: bad['producer_source_identity'] = '0' * 64
            seal = sha256_bytes(canonical_json_bytes({k: v for k, v in bad.items() if k != 'execution_report'}))
            bad['execution_report']['result_sha256'] = seal
            execution = completed_input['execution_report']
            with pytest.raises(ContractError):
                f5._validate_full0_q_input_execution(bad, source=lineage, source_sha256=sha256_file(lineage),
                    source_identity=execution['source_identity'], q_root=complete_root,
                    q_input=completed_input['consumer_input'], task_sha256=twelve_task['task_sha256'],
                    expected_result_sha256=seal, selector_root=selector, selector_binding=execution['selector_binding'],
                    selector_partitions=strict_json_bytes((selector / 'partitions.json').read_bytes()), policy=_POLICY,
                    selection_horizon_months=12, rescore_task=twelve_task,
                    retained_q_input=completed_input['producer_input'],
                    **({'completed_q_execution': strict_json_bytes((complete_root / 'execution.json').read_bytes())}
                       if continuous else {}),
                    retained_source_identity=completed_input['producer_source_identity'])
        assert [(mode, path) for mode, path, _ in events if mode != 'numbers'] == completed_producers
        assert {p: p.read_bytes() for p in complete_root.rglob('*') if p.is_file()} == completed_bytes
        assert {p: p.read_bytes() for p in owner.rglob('*') if p.is_file()} == old_bytes
        for damage in ('source', 'count', 'scientific-result', 'missing-lineage'):
            bad = copy.deepcopy(published['execution_archive'])
            receipt = bad['execution_evidence']['q_input_execution']
            if damage == 'source': receipt['producer_input']['sha256'] = '0' * 64
            elif damage == 'count': receipt['scientific_result']['total_search_fit_count'] = 1070
            elif damage == 'scientific-result': receipt['scientific_result']['selected_spec']['selection_metric'] = 'IBS_0_24'
            else: del bad['members']['inputs/retained-preparation/full-development.json']
            bad['identity_sha256'] = sha256_bytes(canonical_json_bytes({k: v for k, v in bad.items() if k != 'identity_sha256'}))
            with pytest.raises(ContractError): f5._validate_executed_complex_search_archive(bad)
        return
    outputs = [[str(tmp_path / f'refit-{i}.zip'), *ids[i::7]] for i in range(7)]
    retained_index = []
    if prior_publication:
        original_publish = f5._publish_a12_q_stop_inputs
        def publish_after_stop(function, units, root, control, actual_phase, input_ref):
            from padml.f4 import _f45_source_member_sha256
            stop_phase, stop_ids = f5._a12_q_stop_phase('S1', family='GBM_COX')
            old = canonical_json_bytes({'phase': stop_phase, 'input': input_ref,
                'source_identity': sha256_bytes(canonical_json_bytes(_f45_source_member_sha256())),
                'outputs': [{'path': str(tmp_path / 'old-stop.zip'), 'task_ids': stop_ids}]})
            index = root / 'prepared-unit-inputs.json'
            index.write_bytes(old)
            result = original_publish(function, units, root, control, actual_phase, input_ref)
            assert index.read_bytes() == old
            scoped = root / ('prepared-unit-inputs-' + actual_phase + '.json')
            assert strict_json_bytes(scoped.read_bytes()) == result
            with pytest.raises(ContractError, match='F5_A12_PREPARED_STOP_INPUT_INVALID'):
                original_publish(function, units, root, control, actual_phase, input_ref)
            assert index.read_bytes() == old
            retained_index.append(result)
            return result
        monkeypatch.setattr(f5, '_publish_a12_q_stop_inputs', publish_after_stop)
    published = f5._final_complex_search_program(task, parts, tmp_path / 'next-owner', replay=False,
        resource_policy=_POLICY, batch_options={**_options(history=history),
            'retained_bytes_per_task': 4 * 1024**2, 'q_unit_outputs': outputs})
    assert published['phase'] == phase and published['task_ids'] == ids
    if prior_publication:
        assert retained_index == [published['prepared_unit_inputs']]
    assert [(mode, path) for mode, path, _ in events if mode != 'numbers'] == produced
    assert {p: p.read_bytes() for p in owner.rglob('*') if p.is_file()} == old_bytes
    checked = []
    def no_refit(function, units, root, control, actual_phase, input_ref, **kwargs):
        assert actual_phase == phase and list(units) == ids[::7]
        for call, native in units.values():
            assert call[5] == ('IBS' if refit else 'GROUPED_COX_LOCK') and len(call[2]) == (2 if refit else 1)
            assert call[0]['horizons'] == list(range(1 if refit else 0, 37))
            assert all(row['parameters']['locked_trees'] == 51 if refit else 'locked_trees' not in row['parameters']
                       for row in call[2])
            assert call[6]['kind'] == ('INNER' if refit else 'STOP')
            assert call[6]['partition_id'].startswith('F5_R01_' if refit else 'F5_STOP_R02_')
        checked.append(True)
        raise f5._QBatchBoundary({'UNFITTED_REFIT_BOUNDARY': True})
    monkeypatch.setattr(f5, '_execute_q_search_batch', no_refit)
    payload = Path(outputs[0][0])
    assert f5.execute_final_complex_search(candidate_family='GBM_COX', target=tmp_path / 'worker',
        task_ids=ids[::7], batch_root=tmp_path / 'worker-result', retained_bytes_per_task=4 * 1024**2,
        prepared_q_input=payload, prepared_q_input_sha256=sha256_file(payload)) == {'UNFITTED_REFIT_BOUNDARY': True}
    assert checked == [True]
    with zipfile.ZipFile(payload) as archive:
        record = strict_json_bytes(archive.read('prepared-q.json'))
    assert record['predecessor_fit_counts'] == {'total': 140 * completed_phases, 'stop': 140}
    assert len(record['predecessor_execution_sha256']) == 6 * completed_phases


@pytest.mark.parametrize("mode", ["publish", "execute", "retained-execute"])
def test_full0_gbm_original_cli_forwards_scoped_inputs(tmp_path, monkeypatch, capsys, mode):
    calls = []
    monkeypatch.setattr(f5, "execute_final_complex_search", lambda **kwargs: calls.append(kwargs) or {"UNFITTED": True})
    argv = ["complex-search", "--candidate-family", "GBM_COX", "--target", str(tmp_path / "target"),
            "--retained-bytes-per-task", "1024"]
    if mode == "publish":
        argv += ["--full-development", str(tmp_path / "lineage.json"), "--prepare-only",
                 "--q-unit-output", str(tmp_path / "shard.zip"), "unit-1", "unit-2"]
    else:
        argv += ["--prepared-q-input", str(tmp_path / "shard.zip"), "--prepared-q-input-sha256", "a" * 64,
                 "--task-ids", "unit-1", "unit-2", "--batch-root", str(tmp_path / "batch")]
        if mode == "retained-execute":
            argv += ["--prepared-source-bundle", str(tmp_path / "v23-source.zip")]
    monkeypatch.setattr(sys, "argv", ["padml-f5", *argv])
    f5.main()
    capsys.readouterr()
    assert len(calls) == 1 and calls[0]["candidate_family"] == "GBM_COX"
    assert calls[0]["retained_bytes_per_task"] == 1024
    if mode == "publish":
        assert calls[0]["q_unit_outputs"] == [[str(tmp_path / "shard.zip"), "unit-1", "unit-2"]]
        assert calls[0]["prepare_only"] is True and "prepared_q_input" not in calls[0]
    else:
        assert calls[0]["full_development_path"] is None
        assert calls[0]["prepared_q_input"] == tmp_path / "shard.zip"
        assert calls[0]["prepared_q_input_sha256"] == "a" * 64
        assert calls[0]["task_ids"] == ["unit-1", "unit-2"] and "q_unit_outputs" not in calls[0]
        if mode == "retained-execute":
            assert calls[0]["prepared_source_bundle"] == tmp_path / "v23-source.zip"


@pytest.mark.parametrize("change", [{}, {"primary_outer_prepared": True},
    {"candidate_family": "RSF"}, {"prepared_q_input": None, "prepared_q_input_sha256": None}])
def test_full0_retained_preparation_public_scope(tmp_path, monkeypatch, change):
    calls = []
    monkeypatch.setattr(f5, "_execute_a12_prepared_q_batch",
        lambda *args, **kwargs: calls.append((args, kwargs)) or {"UNFITTED": True})
    options = dict(candidate_family="GBM_COX", target=tmp_path / "target",
        prepared_q_input=tmp_path / "inputs.zip", prepared_q_input_sha256="a" * 64,
        prepared_source_bundle=tmp_path / "v23-source.zip", task_ids=["one"],
        batch_root=tmp_path / "batch", retained_bytes_per_task=256 * 1024**2)
    if change:
        with pytest.raises(ContractError):
            f5.execute_final_complex_search(**{**options, **change})
        assert not calls
    else:
        assert f5.execute_final_complex_search(**options) == {"UNFITTED": True}
        assert calls[0][1]["full0_only"] is True
        assert calls[0][1]["prepared_source_bundle"] == options["prepared_source_bundle"]


@pytest.mark.parametrize('change', [
    {'retained_q_producer_source_bundle': None}, {'retained_full0_source_bundle': None},
    {'candidate_family': 'RSF'}, {'selection_horizon_months': 24}, {'prepare_only': False},
    {'task_ids': ['unit-1']}, {'retained_bytes_per_task': 1}, {'q_unit_outputs': []}, {'q_batches': []},
])
def test_full0_gbm_common_public_scope_rejects_before_io(tmp_path, monkeypatch, change):
    options = dict(full_development_path=tmp_path / 'lineage.json', candidate_family='GBM_COX',
        selection_horizon_months=12, target=tmp_path / 'never.zip', prepare_only=True,
        retained_full0_source_bundle=tmp_path / 'old-primary.zip',
        retained_q_producer_source_bundle=tmp_path / 'current-q.zip', q_batches=[tmp_path / 'old-batch'])
    monkeypatch.setattr(f5, '_read_final_lineage', lambda *a, **k: pytest.fail('out-of-scope lineage read'))
    with pytest.raises(ContractError): f5.execute_final_complex_search(**{**options, **change})


def test_full0_gbm_s1_complete_consumer_admits_only_exact_retained_executor_scope(tmp_path, monkeypatch):
    class ReachedLineage(Exception):
        pass

    monkeypatch.setattr(f5, '_read_final_lineage', lambda *a, **k: (_ for _ in ()).throw(ReachedLineage))
    outputs = [[str(tmp_path / 'refit.zip'), *[f'batch-{index}' for index in range(70)]]]
    options = dict(full_development_path=tmp_path / 'full-development.json', candidate_family='GBM_COX',
        selection_horizon_months=24, target=tmp_path / 'never.zip', prepare_only=True,
        retained_full0_source_bundle=tmp_path / 'primary1513.zip',
        retained_q_producer_source_bundle=tmp_path / 'source-e751.zip',
        q_batches=[tmp_path / 'recovered-existing24', tmp_path / 'new116'],
        retained_bytes_per_task=256 * 1024**2, q_unit_outputs=outputs)
    with pytest.raises(ReachedLineage):
        f5.execute_final_complex_search(**options)
    for change in ({'candidate_family': 'RSF'}, {'prepare_only': False},
                   {'q_batches': options['q_batches'][:1]},
                   {'retained_bytes_per_task': 64 * 1024**2}, {'q_unit_outputs': [outputs[0][:-1]]},
                   {'q_unit_outputs': [outputs[0], list(outputs[0])]},
                   {'retained_full0_source_bundle': None}):
        with pytest.raises(ContractError):
            f5.execute_final_complex_search(**{**options, **change})


def test_full0_gbm_common_cli_keeps_two_source_roles(tmp_path, monkeypatch, capsys):
    calls = []
    monkeypatch.setattr(f5, 'execute_final_complex_search', lambda **kwargs:
                        calls.append(kwargs) or {'UNFITTED_ENTRY_ONLY': True})
    monkeypatch.setattr(sys, 'argv', ['padml-f5', 'complex-search', '--candidate-family', 'GBM_COX',
        '--selection-horizon-months', '12', '--prepare-only', '--full-development', str(tmp_path / 'lineage.json'),
        '--target', str(tmp_path / 'never.zip'), '--q-batches', str(tmp_path / 'old-batch'),
        '--retained-full0-source-bundle', str(tmp_path / 'old-primary.zip'),
        '--retained-q-producer-source-bundle', str(tmp_path / 'current-q.zip')])
    f5.main()
    assert strict_json_bytes(capsys.readouterr().out.encode()) == {'UNFITTED_ENTRY_ONLY': True}
    assert len(calls) == 1
    assert calls[0]['retained_full0_source_bundle'] == tmp_path / 'old-primary.zip'
    assert calls[0]['retained_q_producer_source_bundle'] == tmp_path / 'current-q.zip'
    assert calls[0]['selection_horizon_months'] == 12 and calls[0]['prepare_only'] is True
    assert 'task_ids' not in calls[0]
