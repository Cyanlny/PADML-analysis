"""Public original COX continuation: synthetic inputs, never native models."""
import sys
import shutil

import pytest

from padml import f2_kernel, f4, f5, nested_loco as nested, runtime
from padml.bundle import ContractError, canonical_json_bytes, strict_json_bytes
from test_full0_cox_retained_inputs import pair
from test_full0_cox_retained_source import coxtwo  # noqa: F401
from test_full0_fixed12_rescore import forbidden
from test_nested_full_score import operational_budget  # noqa: F401


def options(tmp_path):
    return dict(family="COX_PH", selection_horizon_months=12, resume=True,
        retained_score_root=tmp_path / "old", retained_score_producer_source_bundle=tmp_path / "old.zip",
        prepared_score_source_bundle=tmp_path / "prepared.zip", score_batches=[tmp_path / "old/score-batches/original"])


@pytest.mark.parametrize("change", [{"resume": False}, {"replay": True}, {"prepare_only": True},
    {"family": "RSF"}, {"family": None}, {"selection_horizon_months": 24}, {"score_batches": []},
    {"retained_score_root": None}, {"prepared_score_source_bundle": None}, {"retained_full0_source_bundle": "mixed"}])
def test_public_scope_fails_before_materialization(tmp_path, monkeypatch, change):
    monkeypatch.setattr(f5, "_full0_cox_scores_from_prepared", forbidden)
    monkeypatch.setattr(f5, "_materialized_full_data_development_sources", forbidden)
    with pytest.raises(ContractError):
        f5.execute_full_data_locked_scores(tmp_path / "lineage.json", **{**options(tmp_path), **change})


@pytest.mark.parametrize("common", [False, True])
@pytest.mark.parametrize("family", ["COX_PH", "ELASTIC_NET_COX", "FPM_TVC_SET_A"])
def test_original_cli_passes_the_three_true_source_locations(tmp_path, monkeypatch, capsys, common, family):
    calls = []
    def consume(source, **kwargs):
        calls.append(kwargs)
        return {"ZERO_FIT": True}
    monkeypatch.setattr(f5, "_full0_cox_scores_from_prepared", consume)
    monkeypatch.setattr(sys, "argv", ["padml-f5", "full-score", str(tmp_path / "lineage.json"),
        "--family", family, "--selection-horizon-months", "12", "--resume",
        "--retained-score-root", str(tmp_path / "old"),
        "--retained-score-producer-source-bundle", str(tmp_path / "old.zip"),
        "--prepared-score-source-bundle", str(tmp_path / "prepared.zip"),
        "--score-batches", str(tmp_path / "old/score-batches/original"),
        *(["--prepared-score-root", str(tmp_path / "score.all")] if common else [])])
    f5.main()
    expected = {key: value for key, value in options(tmp_path).items()
        if key not in {"family", "selection_horizon_months", "resume"}}
    if common: expected["prepared_score_root"] = tmp_path / "score.all"
    if family != "COX_PH": expected["family"] = family
    assert len(calls) == 1 and calls[0] == expected
    assert "ZERO_FIT" in capsys.readouterr().out


@pytest.mark.parametrize("failure", [False, True])
@pytest.mark.parametrize("common", [False, True])
def test_public_prepared_outlet_scores_and_replays_without_compilation_or_retry(
        tmp_path, monkeypatch, coxtwo, operational_budget, failure, common):
    members = [f4._retained_full0_source_members(path, full0_cox_score_reuse=True) for path in coxtwo]
    prepared_source = coxtwo[1]
    if common:
        prepared_source = tmp_path / "current-source.zip"
        f4.compile_f45_source_bundle(prepared_source)
        members[1] = f4._f45_source_member_sha256()
    keys = {*f5._final_search_sources(), *("padml/" + name for name in (
        "nested_loco.py", "runtime.py", "f2_validation.py", "kernels/f5_final_refit.R", "kernels/f5_design.R",
        "kernels/f4_learning_selector.R", "kernels/f4_learning_recipe.R"))}
    programs = [nested._sha({key: source[key] for key in keys}) for source in members]
    old, new, request_root, _, handles, originals = pair(tmp_path, old_program=programs[0], new_program=programs[1])
    if common:
        # Other family metadata is not scientific evidence in this COX-only test.
        new["component_records"] = [{**row, "family": family,
            "path": row["path"].replace("COX_PH", family)}
            for family in nested._families() for row in new["component_records"]]
        new = nested._sealed({key: value for key, value in new.items() if key != "identity_sha256"})
    root = tmp_path / ("score.all" if common else "score.COX_PH")
    request_root.parent.rename(root)
    (tmp_path / "old/request/full-score-input.COX_PH.json").write_bytes(canonical_json_bytes(old))
    (root / "request" / ("full-score-input.json" if common else "full-score-input.COX_PH.json")).write_bytes(canonical_json_bytes(new))
    (root / "input-execution.json").write_bytes(canonical_json_bytes(dict(request=new, result=None,
        task_ids=[row["path"] for row in new["component_records"]], input_execution_report=str(root / "input-execution.json"),
        new_model_fits=0, new_model_native_verification_count=0, native_model_replay_count=0,
        input_release_error="RETAINED_UNKNOWN_NOT_RETRIED")))
    policy = {**operational_budget, "memory_bytes_per_worker": 2 * 1024**3}
    batch = tmp_path / "old/score-batches/original"
    for path in originals:
        target = batch / path.relative_to(tmp_path / "old")
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, target)
    monkeypatch.setattr(f5, "_read_final_lineage", lambda *a, **k: dict(score_root=str(tmp_path / "score"),
        science_decision=new["science_decision"], resource_policy=policy,
        retained_bytes_per_component=10**6, expanded_bytes_per_component=10**6, shared_storage_bytes=10**8))
    for name in ("_materialized_full_data_development_sources", "_compile_full_score_inputs",
                 "_execute_and_verify_score_archive_job", "_replay_component_job"):
        monkeypatch.setattr(f5, name, forbidden)
    monkeypatch.setattr(runtime, "_bounded_ordered_spawn", forbidden)
    monkeypatch.setattr(f4, "_replay_f4_model_component", forbidden)
    monkeypatch.setattr(f2_kernel, "_expected_family_parent_column_map", lambda *a, **k: [{"columns": ["AST_ALT", "Age"]}])
    monkeypatch.setattr(f2_kernel, "predictor_contract", lambda *a, **k: {})
    monkeypatch.setattr(f5, "_validate_final_r_fit_health", lambda *a, **k: None)
    monkeypatch.setattr(f5, "_validate_retained_r_audit_numbers", lambda *a, **k: None)
    calls, releases = [], []
    def batches(request, jobs, old_root, paths, **kwargs):
        # Batch metadata/source consumer is tested separately with real old
        # source and complete synthetic reports. No fake fits occur here.
        assert request == old and len(jobs) == 300 and old_root == tmp_path / "old"
        assert kwargs["retained_score_producer_source_bundle"] == coxtwo[0]
        calls.append(True)
        if failure:
            raise ContractError("UNFITTED_BATCH_FAILURE")
        return handles, {}, {}
    monkeypatch.setattr(f5, "_consume_full_score_batches", batches)
    monkeypatch.setattr(runtime, "observe_step_memory", lambda: {})
    def release(paths, **kwargs):
        assert all(root in path.parents for path in paths)
        releases.append(True)
        raise OSError("UNFITTED_RELEASE_FAILURE")
    monkeypatch.setattr(runtime, "release_step_resources", release)
    arguments = {**options(tmp_path), "retained_score_producer_source_bundle": coxtwo[0],
        "prepared_score_source_bundle": prepared_source,
        **({"prepared_score_root": root} if common else {})}
    if failure:
        with pytest.raises(ContractError, match="UNFITTED_BATCH_FAILURE"):
            f5.execute_full_data_locked_scores(tmp_path / "lineage.json", **arguments)
    else:
        result = f5.execute_full_data_locked_scores(tmp_path / "lineage.json", **arguments)
        assert result["status"] == "TRAINING_SCORING_COMPLETE_NOT_FINAL_MODEL"
        assert result["qualified_component_count"] == result["score_numerical_component_count"] == 300
        assert result["new_model_fits"] == result["new_model_native_verification_count"] == result["native_model_replay_count"] == 0
        assert result["training_scores"][0]["training_context_sha256"] == new["training_context"]["identity_sha256"]
        assert result["resource_error"] == "OSError:UNFITTED_RELEASE_FAILURE" and releases == [True]
    report = strict_json_bytes((root / "score-execution.COX_PH.json").read_bytes())
    assert report["error"] == ("ContractError:UNFITTED_BATCH_FAILURE" if failure else None)
    assert calls == [True] and all(path.read_bytes() == raw for path, raw in originals.items())
    saved = {path: path.read_bytes() for path in root.rglob("*") if path.is_file()}
    replay_arguments = {**arguments, "resume": False, "replay": True}
    if failure:
        with pytest.raises(ContractError):
            f5.execute_full_data_locked_scores(tmp_path / "lineage.json", **replay_arguments)
        assert calls == [True]
    else:
        monkeypatch.setattr(nested, "_score_fresh_family", forbidden)
        assert f5.execute_full_data_locked_scores(tmp_path / "lineage.json", **replay_arguments) == report
        assert calls == [True, True] and releases == [True]
        assert all(path.read_bytes() == raw for path, raw in saved.items())
    with pytest.raises(ContractError, match="ALREADY_STARTED"):
        f5.execute_full_data_locked_scores(tmp_path / "lineage.json", **arguments)
    assert calls == ([True] if failure else [True, True])
