"""Synthetic original compiler I/O seam; no clinical input or scientific engine."""
import pytest

from padml import f4, f5, nested_loco as nested, runtime
from padml.bundle import ContractError, canonical_json_bytes


@pytest.mark.parametrize("failure", [None, "space", "memory"])
def test_primary_compiler_future_reserve_does_not_disable_actual_admission(tmp_path, monkeypatch, failure):
    policy = {"configured_worker_ceiling": runtime.CPU_MINUS_8,
        "memory_bytes_per_worker": 4 * 1024**3, "memory_reserve_bytes": 1024**3,
        "scratch_bytes_per_worker": 1024**2, "scratch_reserve_bytes": 512 * 1024**3,
        "transfer_archive_worker_ceiling": 64}
    original = dict(policy)
    calls = []
    observation = {"effective_cpus": 64, "available_memory_bytes": 64 * 1024**3,
        "scratch_available_bytes": 8 * 1024**2, "scratch_root": str(tmp_path)}
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda root: dict(observation))
    actual_admit = runtime.resource_admission
    def admit(value, observed, *, legal_tasks):
        calls.append(dict(value))
        assert value["memory_bytes_per_worker"] == 2 * 1024**3
        assert value["scratch_reserve_bytes"] == 0
        return actual_admit(value, observed, legal_tasks=legal_tasks)
    monkeypatch.setattr(runtime, "resource_admission", admit)
    monkeypatch.setattr(nested, "outer_fresh_score_families", lambda value: [])
    def load(*args, **kwargs):
        if failure == "memory":
            observation["available_memory_bytes"] = 3 * 1024**3
        kwargs["admit_io"](pending_bytes=9 * 1024**2 if failure == "space" else 1024,
                           memory_bytes=1024**2)
        return {}
    monkeypatch.setattr(f4, "load_f4_inputs", load)
    monkeypatch.setattr(nested, "_project_outer_development_from_inputs", lambda *a, **kw: {
        "f1_identity": "a" * 64, "f2_acceptance_sha256": "b" * 64})
    def prepare(projected, root, supplied, **kwargs):
        assert failure is None and supplied == original
        root.mkdir()
        for name in ("input.json", "result.json"):
            (root / name).write_bytes(canonical_json_bytes({"UNFITTED": True}))
        return {"status": "PREPARED_Q_BATCH", "new_model_fits": 0}
    monkeypatch.setattr(f5, "_prepare_primary_outer_rsf_search", prepare)
    arguments = dict(outer_fold=2, science_decision={}, resource_policy=policy,
        retained_bytes_per_component=1024**2, expanded_bytes_per_component=1024**2,
        shared_storage_bytes=64 * 1024**2, primary_rsf_prepare=True)
    target = tmp_path / "unfitted.zip"
    if failure:
        with pytest.raises(ContractError, match="ACTUAL_SPACE_INSUFFICIENT" if failure == "space" else "RESOURCE"):
            f4.compile_o_fit_bundle(tmp_path, target, **arguments)
        assert not target.exists()
    else:
        result = f4.compile_o_fit_bundle(tmp_path, target, **arguments)
        assert result["compilation_resources"]["execution_scratch_reserve_bytes"] == 0
        assert result["compilation_resources"]["execution_worker_memory_bytes"] == 2147483648
        assert result["heldout_response_member_count"] == 0 and result["new_model_fits"] == 0
    assert calls and policy == original
