"""Synthetic-only first Q preparation; no native engine or scientific fit."""
import json

import pytest

from padml import f2_kernel as kernel, f4, f5, nested_loco as nested, runtime
from padml.bundle import ContractError, canonical_json_bytes, sha256_bytes


def _projected(monkeypatch, outer, ceiling):
    context = {"scope": "OUTER", "channel": "PRIMARY", "outer_fold": outer,
        "heldout_center": nested.OUTER_CENTERS[outer - 1], "identity_sha256": str(outer) * 64,
        "modeling_program_sha256": nested._sha(f4._f45_source_member_sha256())}
    decision = {"identity_sha256": "d" * 64, "twelve_month_development": {
        "status": "CONFIRMED", "development_incremental_budget": {
            "old_f2_evidence_recovery_refits_authorized": True}}}
    monkeypatch.setattr(nested, "validate_training_context", lambda value: value)
    monkeypatch.setattr(nested, "validate_science_decision", lambda value: value)
    monkeypatch.setattr(f5, "resolve_pool_workers", lambda workers: ceiling)
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda root: {
        "effective_cpus": ceiling + 8, "available_memory_bytes": 128 * 1024**3,
        "scratch_available_bytes": 128 * 1024**3, "scratch_root": str(root)})
    def no_fit(*args, **kwargs):
        pytest.fail("preparation entered a native engine")
    monkeypatch.setattr(kernel, "_execute_r_prediction", no_fit)
    monkeypatch.setattr(f4, "_run_full_pipeline_r_search_batch", no_fit)
    monkeypatch.setattr(f5, "_execute_q_search_batch", no_fit)
    partitions = []
    for repeat in range(1, 4):
        for inner in range(1, 6):
            evaluation = [f"UNFITTED-R{repeat}-K{inner}"]
            partitions.append({"kind": "INNER", "partition_id": f"INNER_R{repeat}_K{inner}",
                "repeat": repeat, "inner_fold": inner, "fit_ids": ["UNFITTED-TRAIN"],
                "evaluation_ids": evaluation, "evaluation_ids_sha256": kernel._sha(evaluation),
                "application_ids": ["UNFITTED-TRAIN", *evaluation], "covariates": {},
                "fit_response": {}, "evaluation_response": {"private_bytes": b"UNFITTED"}})
    registered = {"kind": "PADML_F2_REGISTERED_PARTITION_INPUTS", "status": "PASS", "fold": outer,
        "outer_count": 1, "inner_count": 15, "stop_count": 15, "diagnostic_count": 5,
        "view_count": 62, "identity": "e" * 64, "partitions": partitions, "diagnostic_partitions": []}
    return {"training_context": context, "science_decision": decision, "registered": registered,
        "selected_parents": ["AST_ALT"], **{key: "a" * 64 for key in (
            "f1_identity", "f2_acceptance_sha256", "accepted_rsf_result_sha256",
            "selector_evidence_sha256", "selector_recipe_set_sha256", "outer_recipe_sha256")}}


_POLICY = {"configured_worker_ceiling": runtime.CPU_MINUS_8, "memory_bytes_per_worker": 1,
    "scratch_bytes_per_worker": 1, "memory_reserve_bytes": 0, "scratch_reserve_bytes": 0,
    "transfer_archive_worker_ceiling": 64}


@pytest.mark.parametrize("damage", [None, "empty-model", "empty-data", "wrong-empty-sha", "bool-size", "negative-size"])
@pytest.mark.parametrize("historical_compiler", [False, True])
def test_prepared_archive_empty_stderr_reaches_original_scientific_checks(tmp_path, monkeypatch, damage, historical_compiler):
    """Actual archive reader; stop before scientific context validation."""
    from padml.bundle import write_deterministic_zip, sha256_file
    producer = tmp_path / "source.zip"
    f4.compile_f45_source_bundle(producer)
    source = {"kind": "PADML_F5_Q_INPUT_V1", "task": {"training_context": {}}, "spec": {"family": "RSF"}}
    result = {"next_atomic_units": [{"producer_tasks": [{"task_id": "S3A_T001_P01_M01"}]}]}
    entries = {"input.json": canonical_json_bytes(source), "result.json": canonical_json_bytes(result),
        "native/batch-UNFITTED/native.stderr": b"", "native/batch-UNFITTED/object-audit.json": b"UNFITTED"}
    refs = {name: {"sha256": sha256_bytes(raw), "size_bytes": len(raw)}
        for name, raw in entries.items() if not name.endswith("object-audit.json")}
    refs["native/batch-UNFITTED/model.rds"] = {"sha256": sha256_bytes(b"UNFITTED"), "size_bytes": 8}
    stderr = refs["native/batch-UNFITTED/native.stderr"]
    if damage == "empty-model":
        refs["native/batch-UNFITTED/model.rds"] = {"sha256": sha256_bytes(b""), "size_bytes": 0}
    elif damage == "empty-data":
        entries["native/batch-UNFITTED/output.json"] = b""
        refs["native/batch-UNFITTED/output.json"] = {"sha256": sha256_bytes(b""), "size_bytes": 0}
    elif damage == "wrong-empty-sha": stderr["sha256"] = "0" * 64
    elif damage == "bool-size": stderr["size_bytes"] = False
    elif damage == "negative-size": stderr["size_bytes"] = -1
    index = {"kind": "PADML_F5_Q_NUMBERS_V1", "input_sha256": refs["input.json"]["sha256"],
        "result_sha256": refs["result.json"]["sha256"], "members": refs}
    index["identity_sha256"] = sha256_bytes(canonical_json_bytes(index))
    entries["numbers.json"] = canonical_json_bytes(index)
    archive = tmp_path / "prepared.zip"
    write_deterministic_zip(archive, entries)
    receipt = {"sha256": sha256_file(archive), "size_bytes": archive.stat().st_size,
        "preparation_metadata": {name: {"sha256": sha256_bytes(entries[name]), "size_bytes": len(entries[name])}
            for name in ("input.json", "result.json", "numbers.json")}}
    compiler_options = {}
    if historical_compiler:
        # Identity plumbing only. The real old compiler ZIP must separately
        # pass the full source proof; the receipt is not relabelled current.
        old = {**f4._f45_source_member_sha256(), "padml/f5.py": "1" * 64}
        compiler = tmp_path / "UNFITTED-old-compiler.zip"
        compiler.write_bytes(b"UNFITTED_SOURCE")
        def source_proof(path, **options):
            assert path == compiler and options == {"primary_rsf_inputs": True}
            return old
        monkeypatch.setattr(f4, "_retained_full0_source_members", source_proof)
        receipt["compilation_source_identity"] = sha256_bytes(canonical_json_bytes(old))
        compiler_options["compilation_source_bundle"] = compiler
    class OriginalScientificBoundary(Exception):
        pass
    reached = []
    monkeypatch.setattr(f4, "_primary_complex_search_source", lambda spec: None)
    def context(value):
        reached.append(True)
        raise OriginalScientificBoundary
    # The subsequent original checks remain mandatory; this sentinel does
    # not return acceptance or allow the fixture to manufacture science.
    monkeypatch.setattr(nested, "validate_training_context", context)
    with pytest.raises(ContractError if damage else OriginalScientificBoundary):
        f5._primary_rsf_prepared_input(entries["input.json"], archive, producer,
            compilation_receipt=receipt, **compiler_options)
    assert bool(reached) is (damage is None)
    if historical_compiler:
        reached.clear()
        receipt["compilation_source_identity"] = sha256_bytes(canonical_json_bytes(f4._f45_source_member_sha256()))
        with pytest.raises(ContractError):
            f5._primary_rsf_prepared_input(entries["input.json"], archive, producer,
                compilation_receipt=receipt, **compiler_options)
        assert not reached


@pytest.mark.parametrize("damage", ["fit", "empty-history", "missing-capture", "mixed-recovery"])
def test_primary_stop_continuation_rejects_nonpreparation_scope(tmp_path, damage):
    prior = tmp_path / "input.json"
    prior.write_bytes(canonical_json_bytes({"UNFITTED": True}))
    options = {"prepare_only": True, "task_ids": None, "batch_root": None,
        "q_batches": [tmp_path / "UNFITTED-batch"], "retained_bytes_per_task": 1024}
    calls = []
    if damage == "fit": options["prepare_only"] = False
    elif damage == "empty-history": options["q_batches"] = []
    elif damage == "missing-capture": calls = None
    else: options["primary_rsf_s3b2_consumption"] = True
    root = tmp_path / "successor"
    with pytest.raises(ContractError, match="F5_PRIMARY_RSF_S3B2_CONSUMPTION_SCOPE_INVALID"):
        f5._prepare_primary_outer_rsf_search({}, root, _POLICY, family="GBM_COX",
            retained_bytes_per_task=1024, admit_io=lambda **kwargs: pytest.fail("IO_FORBIDDEN"),
            prepared_calls=calls, retained_q_input=prior, batch_options=options)
    assert not root.exists()


@pytest.mark.parametrize("family,count", [("GBM_COX", 140), ("XGBOOST_COX", 200), ("COXTIME_SET_A", 60)])
def test_primary_s1_refit_preserves_consumed_stop_predecessor_count(family, count):
    assert f5._a12_q_prepared_predecessors("S1", refit=False, family=family) == {"total": 0, "stop": 0}
    assert f5._a12_q_prepared_predecessors("S1", refit=True, family=family) == {"total": count, "stop": count}
    assert f5._a12_q_prepared_predecessors("S1", refit=True, family=family, full0=True) == {
        "total": count, "stop": count}


@pytest.mark.parametrize("capture", [{"used_batches": ["UNTRUSTED"]}, [], {}])
@pytest.mark.parametrize("family", ["GBM_COX", "RSF"])
def test_primary_publication_capture_cannot_supply_consumed_state(tmp_path, capture, family):
    with pytest.raises(ContractError, match="F5_PRIMARY_RSF_PREPARATION_SCOPE_INVALID"):
        f5._prepare_primary_outer_rsf_search({}, tmp_path / "unstarted", _POLICY,
            family=family, retained_bytes_per_task=1024, prepared_control=capture,
            admit_io=lambda **kwargs: pytest.fail("IO_FORBIDDEN"))
    assert not (tmp_path / "unstarted").exists()


@pytest.mark.parametrize("mixed_prepare_flag", [False, True])
def test_primary_s2_history_public_cli_reaches_original_compiler_without_s1_recovery(tmp_path, monkeypatch, mixed_prepare_flag):
    """Historical preparation and current result provenance remain distinct."""
    import sys
    history = tmp_path / "prepared-inputs"
    history.mkdir()
    decision, policy = tmp_path / "decision.json", tmp_path / "policy.json"
    executor = tmp_path / "executor-source.zip"
    executor.write_bytes(b"UNFITTED_EXECUTOR_SOURCE")
    for path in (decision, policy):
        path.write_bytes(canonical_json_bytes({"UNFITTED": True}))
    batches = [tmp_path / f"batch-{i}" for i in range(7)]
    for path in batches:
        path.mkdir()
    flags = [item for path in batches for item in ("--primary-q-batch", str(path))]
    monkeypatch.setattr(sys, "argv", ["padml-f4", "o-fit-compile", str(tmp_path), str(tmp_path / "result.zip"),
        "--outer-fold", "4", "--science-decision", str(decision), "--resource-policy", str(policy),
        "--retained-bytes-per-component", "100", "--expanded-bytes-per-component", "200",
        "--shared-storage-bytes", "1000", "--consume-primary12-rsf-history", str(history),
        "--primary-rsf-history-stage", "S2", "--primary-executor-source-bundle", str(executor), *flags])
    calls = []
    monkeypatch.setattr(f4, "compile_o_fit_bundle", lambda *a, **k: calls.append(k) or {"UNFITTED": True})
    if mixed_prepare_flag:
        sys.argv.append("--prepare-primary12-rsf")
        with pytest.raises(ContractError, match="F4_PRIMARY_RSF_CONTINUATION_SCOPE_INVALID"):
            f4.main()
        assert not calls
        return
    f4.main()
    assert len(calls) == 1
    call = calls[0]
    assert call["primary_rsf_prepare"] is True
    assert call["outer_fold"] == 4
    assert call["primary_retained_q_input"] == history / "input.json"
    options = call["primary_q_batch_options"]
    assert options["primary_rsf_s2_consumption"] is True
    assert options["q_batches"] == batches
    assert options["retained_primary_rsf_q_source_bundle"] == executor
    assert "primary_rsf_s3b2_consumption" not in options
    assert "s1_summary_recovery_call_limit" not in options
    assert set(options["primary_rsf_s2_evidence"]) == {
        "source/primary-q-producer.zip", "source/primary-s2-producer.zip", "primary-s2/report.json",
        *(f"primary-s2/{host}-execution.json" for host in ("H0", "H1", "H4", "H5", "H6", "H7", "H9-2"))}


@pytest.mark.parametrize("executor_count", [0, 1, 2, 3])
@pytest.mark.parametrize("stage", ["S3A", "S3B1"])
def test_primary_later_history_public_cli_reaches_original_compiler_without_recovery(tmp_path, monkeypatch, stage, executor_count):
    import sys
    history = tmp_path / "prepared-inputs"
    history.mkdir()
    decision, policy = tmp_path / "decision.json", tmp_path / "policy.json"
    for path in (decision, policy):
        path.write_bytes(canonical_json_bytes({"UNFITTED": True}))
    batches = [tmp_path / f"batch-{i}" for i in range(7)]
    for path in batches:
        path.mkdir()
    flags = [item for path in batches for item in ("--primary-q-batch", str(path))]
    monkeypatch.setattr(sys, "argv", ["padml-f4", "o-fit-compile", str(tmp_path), str(tmp_path / "result.zip"),
        "--outer-fold", "6", "--science-decision", str(decision), "--resource-policy", str(policy),
        "--retained-bytes-per-component", "100", "--expanded-bytes-per-component", "200",
        "--shared-storage-bytes", "1000", "--consume-primary12-rsf-history", str(history),
        "--primary-rsf-history-stage", stage, *flags])
    calls = []
    monkeypatch.setattr(f4, "compile_o_fit_bundle", lambda *a, **k: calls.append(k) or {"UNFITTED": True})
    executors = [tmp_path / f"executor-{i}.zip" for i in range(executor_count)]
    for path in executors:
        path.write_bytes(b"UNFITTED_SOURCE")
        sys.argv.extend(["--primary-executor-source-bundle", str(path)])
    if executor_count > 2 or stage == "S3B1" and executor_count > 1:
        with pytest.raises(ContractError, match="F4_PRIMARY_RSF_CONTINUATION_SCOPE_INVALID"):
            f4.main()
        assert not calls
        return
    f4.main()
    options = calls[0]["primary_q_batch_options"]
    key = f"primary_rsf_{stage.lower()}_consumption"
    assert options[key] is True and options["q_batches"] == batches
    assert options["retained_primary_rsf_q_source_bundle"] == (
        tuple(executors) if executor_count == 2 else executors[0] if executor_count == 1
        else history / f"source/primary-{stage.lower()}-producer.zip")
    assert "s1_summary_recovery_call_limit" not in options
    prior = ["s2", "s3a"] if stage == "S3A" else ["s2", "s3a", "s3b1"]
    assert [name for name in prior if f"primary_rsf_{name}_evidence" in options] == prior


@pytest.mark.parametrize("stage", ["S2", "S3A", "S3B1"])
def test_primary_history_cli_can_publish_its_direct_successor_in_same_call(tmp_path, monkeypatch, stage):
    import sys
    history = tmp_path / "prepared-inputs"; history.mkdir()
    decision, policy = tmp_path / "decision.json", tmp_path / "policy.json"
    producer = tmp_path / "original-producer.zip"
    executor = tmp_path / "executor.zip"
    for path in (decision, policy, producer, executor): path.write_bytes(canonical_json_bytes({"UNFITTED": True}))
    batches = [tmp_path / f"batch-{i}" for i in range(7)]
    for path in batches: path.mkdir()
    monkeypatch.setattr(sys, "argv", ["padml-f4", "o-fit-compile", str(tmp_path),
        str(tmp_path / "result.zip"), "--outer-fold", "5", "--science-decision", str(decision),
        "--resource-policy", str(policy), "--retained-bytes-per-component", "100",
        "--expanded-bytes-per-component", "200", "--shared-storage-bytes", "1000",
        "--consume-primary12-rsf-history", str(history), "--primary-rsf-history-stage", stage,
        "--primary-producer-source-bundle", str(producer), "--primary-q-unit-output",
        str(tmp_path / "successor.zip"), "UNFITTED_ATOM",
        *(["--primary-executor-source-bundle", str(executor)] if stage == "S2" else []),
        *[item for path in batches for item in ("--primary-q-batch", str(path))]])
    calls = []
    monkeypatch.setattr(f4, "compile_o_fit_bundle", lambda *a, **k: calls.append(k) or {})
    f4.main()
    assert calls[0]["primary_q_unit_outputs"] == [[str(tmp_path / "successor.zip"), "UNFITTED_ATOM"]]
    assert calls[0]["primary_producer_source_bundle"] == producer
    assert calls[0]["primary_q_batch_options"][f"primary_rsf_{stage.lower()}_consumption"] is True


def test_outer6_publication_receipt_history_cli_uses_exact_existing_files(tmp_path, monkeypatch):
    import sys
    history = tmp_path / "prepared-inputs"
    (history / "source").mkdir(parents=True)
    for name in ("primary-compilation.json", "primary-compilation-source.zip",
                 "primary-compilation-preparation.zip", "primary-s3a-producer.zip"):
        (history / "source" / name).write_bytes(b"UNFITTED")
    decision, policy = tmp_path / "decision.json", tmp_path / "policy.json"
    for path in (decision, policy):
        path.write_bytes(canonical_json_bytes({"UNFITTED": True}))
    batches = [tmp_path / f"batch-{index}" for index in range(7)]
    for path in batches:
        path.mkdir()
    monkeypatch.setattr(sys, "argv", ["padml-f4", "o-fit-compile", str(tmp_path), str(tmp_path / "result.zip"),
        "--outer-fold", "6", "--science-decision", str(decision), "--resource-policy", str(policy),
        "--retained-bytes-per-component", "100", "--expanded-bytes-per-component", "200",
        "--shared-storage-bytes", "1000", "--consume-primary12-rsf-history", str(history),
        "--primary-rsf-history-stage", "S3A",
        *[item for path in batches for item in ("--primary-q-batch", str(path))]])
    calls = []
    monkeypatch.setattr(f4, "compile_o_fit_bundle", lambda *a, **k: calls.append(k) or {})
    f4.main()
    options = calls[0]["primary_q_batch_options"]
    assert options["primary_rsf_preparation"] == history / "source/primary-preparation.zip"
    assert set(options["primary_rsf_s3a_evidence"]) == {
        "source/primary-s3a-producer.zip", "source/primary-compilation.json",
        "source/primary-compilation-source.zip", "source/primary-compilation-preparation.zip",
        *(f"primary-s3a/{host}-execution.json" for host in ("H0", "H1", "H4", "H5", "H6", "H7", "H9-2"))}


@pytest.mark.parametrize("damage", [None, "no-limit", "duplicate", "missing", "prepare-mixed",
                                  "saved", "saved-nonzero", "zero-without-saved", "saved-no-sha", "sha-only"])
def test_primary_terminal_cli_reuses_original_scoped_history(tmp_path, monkeypatch, capsys, damage):
    import sys
    history = tmp_path / "prepared-inputs"
    history.mkdir()
    decision, policy = tmp_path / "decision.json", tmp_path / "policy.json"
    for path in (decision, policy): path.write_bytes(canonical_json_bytes({"UNFITTED": True}))
    paths = [tmp_path / f"batch-{i}" for i in range(14)]
    for path in paths: path.mkdir()
    if damage == "duplicate": paths[-1] = paths[-2]
    if damage == "missing": paths.pop()
    flags = [item for path in paths for item in ("--primary-q-batch", str(path))]
    if damage != "no-limit":
        flags += ["--s1-summary-recovery-call-limit", "0" if damage in {
            "saved", "zero-without-saved", "saved-no-sha", "sha-only"} else "1"]
    if damage in {"saved", "saved-nonzero", "saved-no-sha"}:
        saved = tmp_path / "s1-summary"
        saved.mkdir()
        flags += ["--s1-summary-input", str(saved)]
        if damage != "saved-no-sha": flags += ["--s1-summary-sha256", "a" * 64]
    if damage == "sha-only": flags += ["--s1-summary-sha256", "a" * 64]
    if damage == "prepare-mixed": flags += ["--prepare-primary12-rsf"]
    monkeypatch.setattr(sys, "argv", ["padml-f4", "o-fit-compile", str(tmp_path), str(tmp_path / "result.zip"),
        "--outer-fold", "2", "--science-decision", str(decision), "--resource-policy", str(policy),
        "--retained-bytes-per-component", "100", "--expanded-bytes-per-component", "200",
        "--shared-storage-bytes", "1000", "--consume-primary12-rsf-history", str(history), *flags])
    calls = []
    monkeypatch.setattr(f4, "compile_o_fit_bundle", lambda *a, **k: calls.append(k) or {"UNFITTED": True})
    if damage and damage != "saved":
        with pytest.raises(ContractError, match="F4_PRIMARY_RSF_CONTINUATION_SCOPE_INVALID"): f4.main()
        assert not calls
        return
    f4.main()
    call = calls[0]
    assert call["primary_rsf_prepare"] is True and call["primary_retained_q_input"] == history / "input.json"
    options = call["primary_q_batch_options"]
    assert options["q_batches"] == paths and options["s1_summary_recovery_call_limit"] == (0 if damage == "saved" else 1)
    if damage == "saved":
        assert options["primary_rsf_s1_summary"] == saved
        assert options["primary_rsf_s1_summary_sha256"] == "a" * 64
    assert options["prepare_only"] is True and options["task_ids"] is options["batch_root"] is None
    assert options["retained_primary_rsf_q_source_bundle"] == history / "source/primary-s3b2-producer.zip"
    assert [len(options[f"primary_rsf_{stage}_evidence"]) for stage in ("s2", "s3a", "s3b1", "s3b2")] == [10, 9, 9, 9]
    assert json.loads(capsys.readouterr().out) == {"UNFITTED": True}


@pytest.mark.parametrize("family", ["GBM_COX", "XGBOOST_COX", "COXTIME_SET_A", "RSF"])
@pytest.mark.parametrize("publish", [False, True])
@pytest.mark.parametrize("batch_count", [1, 70, 71])
def test_primary_stop_cli_uses_original_compiler(tmp_path, monkeypatch, family, publish, batch_count):
    import sys
    source, decision, policy = (tmp_path / name for name in ("input.json", "decision.json", "policy.json"))
    for path in (source, decision, policy):
        path.write_bytes(canonical_json_bytes({"UNFITTED": True}))
    batches = [tmp_path / f"batch-{i}" for i in range(batch_count)]
    for batch in batches:
        batch.mkdir()
    seen = []
    monkeypatch.setattr(f4, "compile_o_fit_bundle", lambda *a, **kwargs: seen.append(kwargs) or {"UNFITTED": True})
    monkeypatch.setattr(sys, "argv", ["padml-f4", "o-fit-compile", str(tmp_path), str(tmp_path / "result.zip"),
        "--outer-fold", "1", "--science-decision", str(decision), "--resource-policy", str(policy),
        "--retained-bytes-per-component", "100", "--expanded-bytes-per-component", "200",
        "--shared-storage-bytes", "1000", "--prepare-primary12-family", family,
        "--consume-primary12-q-input" if family == "RSF" else "--consume-primary12-stop-input", str(source),
        *[item for batch in batches for item in ("--primary-q-batch", str(batch))]])
    if publish:
        producer = tmp_path / "producer.zip"
        producer.write_bytes(b"UNFITTED_SOURCE")
        sys.argv.extend(["--primary-producer-source-bundle", str(producer),
                         "--primary-q-unit-output", str(tmp_path / "refit.zip"), "UNFITTED_ATOM"])
    if batch_count > 70:
        with pytest.raises(ContractError, match="F4_PRIMARY_RSF_CONTINUATION_SCOPE_INVALID"):
            f4.main()
        assert not seen
        return
    f4.main()
    assert len(seen) == 1 and seen[0]["primary_prepare_family"] == family
    assert seen[0]["primary_rsf_prepare"] is True and seen[0]["primary_retained_q_input"] == source
    assert seen[0]["primary_q_batch_options"] == {"prepare_only": True, "task_ids": None,
        "batch_root": None, "q_batches": batches, "retained_bytes_per_task": 100}
    if publish:
        assert seen[0]["primary_producer_source_bundle"] == producer
        assert seen[0]["primary_q_unit_outputs"] == [[str(tmp_path / "refit.zip"), "UNFITTED_ATOM"]]


@pytest.mark.parametrize("damage", [None, "seed", "source"])
def test_historical_s2_owner_preserves_input_to_original_control(tmp_path, monkeypatch, damage):
    projected = _projected(monkeypatch, 6, 56)
    first = tmp_path / "first"
    f5._prepare_primary_outer_rsf_search(projected, first, _POLICY,
        retained_bytes_per_task=1024**2, admit_io=lambda **kw: None)
    prior = json.loads((first / "input.json").read_bytes())
    if damage == "seed":
        prior["spec"]["seed"] += 1
    if damage == "source":
        prior["task"]["source"]["f2_acceptance_sha256"] = "b" * 64
    path = tmp_path / "retained-input.json"
    path.write_bytes(canonical_json_bytes(prior))
    options = {"primary_rsf_s2_consumption": True}
    class OriginalControlReached(Exception):
        pass
    def original_control(root, policy, value):
        assert value is options
        assert (root / "input.json").read_bytes() == path.read_bytes()
        raise OriginalControlReached
    monkeypatch.setattr(f5, "_q_search_batch_control", original_control)
    target = tmp_path / "continued"
    expected = ContractError if damage else OriginalControlReached
    with pytest.raises(expected):
        f5._prepare_primary_outer_rsf_search(projected, target, _POLICY,
            retained_bytes_per_task=1024**2, admit_io=lambda **kw: None,
            retained_q_input=path, batch_options=options)
    if damage:
        assert not target.exists()


@pytest.mark.parametrize("damage", [None, "recipe-owner", "training-data"])
def test_retained_owner_compares_proved_preprocessing_identity_without_rewriting(tmp_path, monkeypatch, damage):
    from pathlib import Path
    import os
    producer = Path(os.environ["PADML_RETAINED_FULL0_SOURCE_BUNDLE"])
    retained = f4._retained_full0_source_members(producer, primary_rsf_inputs=True)
    projected = _projected(monkeypatch, 6, 56)
    current = f4._f45_source_member_sha256()
    predictor = kernel.predictor_contract(Path(f4.__file__).parent)
    projected["training_context"].update(preprocessing_program_sha256=nested._sha({
        "predictor_contract": predictor, "recipe_owner": current["padml/f2_kernel.py"]}),
        training_response_sha256="a" * 64)
    first = tmp_path / "first"
    f5._prepare_primary_outer_rsf_search(projected, first, _POLICY,
        retained_bytes_per_task=1024**2, admit_io=lambda **kw: None)
    prior = json.loads((first / "input.json").read_bytes())
    context = prior["task"]["training_context"]
    context.update(modeling_program_sha256=nested._sha(retained),
        preprocessing_program_sha256=nested._sha({"predictor_contract": predictor,
            "recipe_owner": retained["padml/f2_kernel.py"]}))
    context["identity_sha256"] = nested._sha({key: value for key, value in context.items() if key != "identity_sha256"})
    prior["task"]["source"].update(producer_source_identity=nested._sha(retained),
        training_context_sha256=context["identity_sha256"])
    prior["spec"]["primary_search_source"] = prior["task"]["source"]
    if damage == "recipe-owner": context["preprocessing_program_sha256"] = "b" * 64
    elif damage == "training-data": context["training_response_sha256"] = "b" * 64
    retained_input = tmp_path / "retained-input.json"
    raw = canonical_json_bytes(prior)
    retained_input.write_bytes(raw)
    class OriginalControlReached(Exception):
        pass
    def control(root, *args):
        assert (root / "input.json").read_bytes() == raw
        raise OriginalControlReached
    monkeypatch.setattr(f5, "_q_search_batch_control", control)
    with pytest.raises(ContractError if damage else OriginalControlReached):
        f5._prepare_primary_outer_rsf_search(projected, tmp_path / "continued", _POLICY,
            retained_bytes_per_task=1024**2, admit_io=lambda **kw: None, retained_q_input=retained_input,
            batch_options={"primary_rsf_s2_consumption": True, "primary_rsf_producer": producer})


@pytest.mark.parametrize("damage", [None, "history", "count", "phase"])
def test_historical_s2_owner_archives_only_original_s3a_boundary(tmp_path, monkeypatch, damage):
    from padml import f4_compact
    projected = _projected(monkeypatch, 6, 56)
    first = tmp_path / "first"
    f5._prepare_primary_outer_rsf_search(projected, first, _POLICY,
        retained_bytes_per_task=1024**2, admit_io=lambda **kw: None)
    source = json.loads((first / "input.json").read_bytes())["task"]["source"]
    history = {"score_trace_status": "NOT_RETAINED"}
    control = {"used_batches": [str(i) * 64 for i in range(7)],
        "confirmed_model_fits": 320, "confirmed_stop_fits": 0,
        "primary_rsf_s1_history": history, "references": {}}
    result = {"status": "PREPARED_Q_BATCH", "stage_acceptance": False,
        "phase": f5._a12_q_stop_phase("S3A", refit=True, family="RSF")[0],
        "primary_search_source": source, "model_coordinate_count": 300,
        "new_model_fits": 0, "complete_search_trace": False,
        "s1_consumed_history": dict(history), "consumed_s2_model_coordinates": 200,
        "consumed_s2_atomic_units": 75}
    if damage == "history": result["s1_consumed_history"]["score_trace_status"] = "RECOVERED"
    if damage == "count": control["confirmed_model_fits"] = 319
    if damage == "phase": result["phase"] = f5._a12_q_stop_phase("S3B1", refit=True, family="RSF")[0]
    def original_boundary(*args):
        raise f5._QBatchBoundary(result)
    monkeypatch.setattr(f5, "_q_search_batch_control", lambda *args: control)
    monkeypatch.setattr(f5, "_run_final_complex_search", original_boundary)
    archived = []
    monkeypatch.setattr(f4_compact, "_full_pipeline_q_numerical_members",
        lambda root, **kwargs: archived.append((root, kwargs)))
    target = tmp_path / "continued"
    def run():
        return f5._prepare_primary_outer_rsf_search(projected, target, _POLICY,
            retained_bytes_per_task=1024**2, admit_io=lambda **kw: None,
            retained_q_input=first / "input.json", batch_options={"primary_rsf_s2_consumption": True})
    if damage:
        with pytest.raises(ContractError, match="F5_PRIMARY_RSF_PREPARATION_BOUNDARY_INVALID"):
            run()
        assert not archived and not (target / "result.json").exists()
    else:
        actual = run()
        assert actual["worker_inputs_ready"] is False and actual["stage_acceptance"] is False
        assert actual["s1_consumed_history"]["score_trace_status"] == "NOT_RETAINED"
        assert archived == [(target, {"publish": True, "transported_refs": {}})]
        assert (target / "input.json").read_bytes() == (first / "input.json").read_bytes()


def test_primary_continuation_stays_on_original_public_compiler(tmp_path, monkeypatch):
    seen = []
    source = tmp_path / "input.json"
    options = {"UNFITTED_FORWARDING": True}
    monkeypatch.setattr(f4, "_compile_o_fit_bundle", lambda *a, **kw: seen.append(kw) or {})
    f4.compile_o_fit_bundle(tmp_path, tmp_path / "result.zip", outer_fold=2,
        science_decision={}, resource_policy=_POLICY, retained_bytes_per_component=1024**2,
        expanded_bytes_per_component=1024**2, shared_storage_bytes=1024**2,
        primary_rsf_prepare=True, primary_retained_q_input=source, primary_q_batch_options=options)
    assert seen[0]["primary_retained_q_input"] == source
    assert seen[0]["primary_q_batch_options"] is options


@pytest.mark.parametrize("damage", ["no-prepare", "family", "missing-options", "storage"])
def test_primary_continuation_wrong_mode_stops_before_projection(tmp_path, monkeypatch, damage):
    monkeypatch.setattr(f4, "load_f4_inputs", lambda *a, **k: pytest.fail("PROJECTION_FORBIDDEN"))
    with pytest.raises(ContractError, match="F4_PRIMARY_RSF_CONTINUATION_SCOPE_INVALID"):
        f4.compile_o_fit_bundle(tmp_path, tmp_path / "result.zip", outer_fold=2,
            science_decision={}, resource_policy=_POLICY, retained_bytes_per_component=1024**2,
            expanded_bytes_per_component=1024**2, shared_storage_bytes=1024**2,
            primary_rsf_prepare=damage != "no-prepare",
            primary_prepare_family="GBM_COX" if damage == "family" else "RSF",
            primary_retained_q_input=tmp_path / "input.json",
            primary_q_batch_options=None if damage == "missing-options" else {
                "retained_bytes_per_task": 1 if damage == "storage" else 1024**2})


@pytest.mark.parametrize("damage", [None, "seed", "registered", "training", "source"])
@pytest.mark.parametrize("normal", [False, True])
def test_original_preparation_continuation_keeps_scientific_input(tmp_path, monkeypatch, damage, normal):
    from padml import f4_compact
    projected = _projected(monkeypatch, 2, 56)
    first = tmp_path / "first"
    f5._prepare_primary_outer_rsf_search(projected, first, _POLICY,
        retained_bytes_per_task=1024**2, admit_io=lambda **kw: None)
    prior = json.loads((first / "input.json").read_bytes())
    if damage == "seed": prior["spec"]["seed"] += 1
    if damage == "registered": prior["spec"]["registered_inputs_identity_sha256"] = "b" * 64
    if damage == "training": prior["task"]["training_context"]["heldout_center"] = 36
    if damage == "source": prior["task"]["source"]["f2_acceptance_sha256"] = "b" * 64
    path = tmp_path / "retained-input.json"
    raw = canonical_json_bytes(prior)
    path.write_bytes(raw)
    options = ({"prepare_only": True, "task_ids": None, "batch_root": None,
        "q_batches": [tmp_path / "UNFITTED"], "retained_bytes_per_task": 1024**2}
        if normal else {"primary_rsf_s3b2_consumption": True})
    calls = []
    control = {"s1_summary_recovery_calls": 1, "s3b2_numerical_consumer_calls": 1, "references": {}}
    if normal:
        del control["s1_summary_recovery_calls"]
    capture = {"prepared_calls": []} if normal else {}
    result = {"UNFITTED_TERMINAL_BOUNDARY": True}
    # Isolate compiler-to-owner routing. Original control, numerical funnel,
    # source admission and compact publication are exercised independently.
    def bind(root, policy, value):
        assert value is options and (root / "input.json").read_bytes() == raw
        calls.append("control")
        return control
    def consume(spec, registered, scratch):
        assert spec["native_search_batch"] is control
        assert registered is projected["registered"]
        assert spec["registered_inputs_identity_sha256"] == registered["identity"]
        calls.append("original-funnel")
        return result
    monkeypatch.setattr(f5, "_q_search_batch_control", bind)
    monkeypatch.setattr(f5, "_run_final_complex_search", consume)
    monkeypatch.setattr(f5, "_validate_primary_complex_search_result", lambda s, r: calls.append("result-check"))
    monkeypatch.setattr(f5, "_q_search_batch_completion", lambda r, c, v: calls.append("completion"))
    monkeypatch.setattr(f4_compact, "_full_pipeline_q_numerical_members", lambda *a, **k: calls.append("publication"))
    target = tmp_path / "continued"
    if damage:
        with pytest.raises(ContractError, match="F5_PRIMARY_RSF_CONTINUATION_INPUT_DRIFT"):
            f5._prepare_primary_outer_rsf_search(projected, target, _POLICY,
                retained_bytes_per_task=1024**2, admit_io=lambda **kw: None,
                retained_q_input=path, batch_options=options, **capture)
        assert not target.exists() and not calls
        return
    report = f5._prepare_primary_outer_rsf_search(projected, target, _POLICY,
        retained_bytes_per_task=1024**2, admit_io=lambda **kw: None,
        retained_q_input=path, batch_options=options, **capture)
    assert calls == ["control", "original-funnel", "result-check", "completion", "publication"]
    assert (target / "input.json").read_bytes() == path.read_bytes() == raw
    assert report["scientific_result"] == result and report["new_model_fits"] == 0
    assert report["s1_summary_recovery_calls"] == (0 if normal else 1)
    assert report["s3b2_numerical_consumer_calls"] == 1


@pytest.mark.parametrize("capture", [False, True])
@pytest.mark.parametrize("outer,ceiling,atoms", [(1, 24, 30), (2, 56, 60), (6, 56, 60)])
def test_original_rsf_s1_stops_before_fit_and_preserves_outer_seed(tmp_path, monkeypatch, outer, ceiling, atoms, capture):
    projected = _projected(monkeypatch, outer, ceiling)
    observed = []
    calls = [] if capture else None
    result = f5._prepare_primary_outer_rsf_search(projected, tmp_path / "q", _POLICY,
        retained_bytes_per_task=1024**2, admit_io=lambda **kw: observed.append(kw),
        prepared_calls=calls)
    assert result["status"] == "PREPARED_Q_BATCH" and result["stage_acceptance"] is False
    assert result["model_coordinate_count"] == 120 and len(result["next_atomic_units"]) == atoms
    assert result["worker_inputs_ready"] is False
    assert result["primary_search_source"]["outer_fold"] == outer
    assert all(result[key] == 0 for key in ("new_model_fits", "new_stop_fits", "new_mice_chains",
        "new_elastic_paths", "new_glmnet_calls", "new_first_native_audits", "native_replays"))
    tasks = [task for atom in result["next_atomic_units"] for task in atom["producer_tasks"]]
    for task in tasks:
        assert task["seed"] == 300000 + 1000 * outer + 10100 + int(task["task_id"].split("_")[2][1:])
        assert task["prediction_horizons"] == list(range(1, 37))
        assert "transform_recipe" not in task
    value = json.loads((tmp_path / "q/input.json").read_bytes())
    assert value["spec"]["selection_horizon_months"] == 12
    assert value["spec"]["trial_scoring"]["ibs_integration"] == "TRAPEZOID_DIVIDE_BY_12"
    assert value["spec"]["execution_scope"] == "F2_OUTER_DEVELOPMENT"
    assert value["spec"]["selector_from_dependency"]["outer_recipe_sha256"] == "a" * 64
    assert "evaluation_response" not in value["spec"]
    assert result["input_sha256"] == sha256_bytes(canonical_json_bytes(value)) and observed
    if capture:
        assert len(calls) == 1 and calls[0][0] is kernel._run_r_prediction_pool_task
        assert [{"task_id": name, "producer_tasks": call[2]}
                for name, (call, _) in calls[0][1].items()] == result["next_atomic_units"]


@pytest.mark.parametrize("ceiling", [24, 56])
@pytest.mark.parametrize("retained_producer", [False, True])
def test_new_rsf_compilation_receipt_reopens_original_atoms(tmp_path, monkeypatch, ceiling, retained_producer):
    from padml.bundle import write_deterministic_zip, sha256_file
    import copy
    projected = _projected(monkeypatch, 2, ceiling)
    for partition in projected["registered"]["partitions"]:
        partition["partition_id"] = partition["partition_id"].replace("INNER_", "INNER_F2_", 1)
    calls = []
    root = tmp_path / "q"
    result = f5._prepare_primary_outer_rsf_search(projected, root, _POLICY,
        retained_bytes_per_task=1024**2, admit_io=lambda **kw: None, prepared_calls=calls)
    producer = tmp_path / "source.zip"
    f4.compile_f45_source_bundle(producer)
    original_members = f4._f45_source_member_sha256()
    if retained_producer:
        consumer_members = {**original_members, "padml/f5.py": "b" * 64}
        monkeypatch.setattr(f4, "_f45_source_member_sha256", lambda: consumer_members)
        def source_proof(path, **options):
            assert path == producer and options == {"primary_rsf_inputs": True}
            return original_members
        monkeypatch.setattr(f4, "_retained_full0_source_members", source_proof)
    preparation = tmp_path / "preparation.zip"
    entries = {name: (root / name).read_bytes() for name in ("input.json", "result.json")}

    def seal(target, values, boundary):
        write_deterministic_zip(target, values)
        return {**boundary, "sha256": sha256_file(target), "size_bytes": target.stat().st_size,
            "compilation_source_identity": sha256_bytes(canonical_json_bytes(f4._f45_source_member_sha256())),
            "outer_fold": 2, "f1_identity": projected["f1_identity"],
            "f2_acceptance_sha256": projected["f2_acceptance_sha256"],
            "heldout_response_member_count": 0,
            "preparation_metadata": {name: {"sha256": sha256_bytes(raw), "size_bytes": len(raw)}
                for name, raw in values.items()}}

    receipt = seal(preparation, entries, result)
    child, units = f5._primary_rsf_prepared_input(entries["input.json"], preparation, producer,
        compilation_receipt=receipt)
    original_child = dict(next(iter(calls[0][1].values()))[0][0])
    original_child.pop("native_search_root"); original_child.pop("native_search_replay")
    assert child == original_child
    assert units == {name: call[2] for name, (call, _) in calls[0][1].items()}
    for damage in ("seed", "half-atom", "duplicate", "phase", "foreign-outer", "compiler"):
        bad = copy.deepcopy(result)
        if damage == "seed": bad["next_atomic_units"][0]["producer_tasks"][0]["seed"] += 1
        elif damage == "half-atom": bad["next_atomic_units"][0]["producer_tasks"].pop()
        elif damage == "duplicate": bad["next_atomic_units"][1] = bad["next_atomic_units"][0]
        elif damage == "phase": bad["phase"] = "WRONG"
        elif damage == "foreign-outer": bad["primary_search_source"]["outer_fold"] = 1
        target = tmp_path / (damage + ".zip")
        values = {**entries, "result.json": canonical_json_bytes(bad)}
        changed = seal(target, values, bad)
        if damage == "compiler": changed["compilation_source_identity"] = "f" * 64
        with pytest.raises(ContractError):
            f5._primary_rsf_prepared_input(entries["input.json"], target, producer,
                compilation_receipt=changed)


@pytest.mark.parametrize("stage,trials,partitions,imputations", [
    ("S1", 24, 5, 1), ("S2", 8, 5, 5), ("S3A", 3, 5, 20),
    ("S3B1", 2, 15, 5), ("S3B2", 1, 15, 20)])
def test_shared_r_geometry_preserves_original_rsf_atoms(stage, trials, partitions, imputations):
    rows = [{"task_id": f"{stage}_T{trial:03d}_P{part:02d}_M{imp:02d}",
             "partition_id": f"UNFITTED-{part}", "imputation": imp}
            for trial in range(1, trials + 1) for part in range(1, partitions + 1)
            for imp in range(1, imputations + 1)]
    batches = kernel._r_prediction_task_batches(rows, 56)
    names = ["batch-" + sha256_bytes(canonical_json_bytes([row["task_id"] for row in batch]))[:24]
             for batch in batches]
    assert names == f5._a12_q_stop_phase(stage, refit=True, family="RSF")[1]
    assert sorted(row["task_id"] for batch in batches for row in batch) == sorted(row["task_id"] for row in rows)


@pytest.mark.parametrize("family,count", [("GBM_COX", 140), ("XGBOOST_COX", 200), ("COXTIME_SET_A", 60)])
def test_original_preparation_reaches_each_family_stop_barrier(tmp_path, monkeypatch, family, count):
    projected = _projected(monkeypatch, 2, 56)
    projected["accepted_model_result_sha256"] = projected.pop("accepted_rsf_result_sha256")
    partitions = projected["registered"]["partitions"]
    stops = []
    for inner in partitions:
        inner["fit_ids"] = ["UNFITTED-TRAIN", "UNFITTED-STOP"]
        stops.append({**inner, "kind": "STOP", "partition_id": inner["partition_id"].replace("INNER", "STOP"),
            "fit_ids": ["UNFITTED-TRAIN"], "evaluation_ids": ["UNFITTED-STOP"],
            "evaluation_ids_sha256": kernel._sha(["UNFITTED-STOP"]),
            "application_ids": inner["fit_ids"],
            "consumer_set": ["GBM_COX", "XGBOOST_COX", "COXTIME_SET_A"]})
    partitions.extend(stops)
    result = f5._prepare_primary_outer_rsf_search(projected, tmp_path / "q", _POLICY,
        retained_bytes_per_task=1024**2, admit_io=lambda **kw: None, family=family)
    value = json.loads((tmp_path / "q/input.json").read_bytes())
    assert value["spec"]["family"] == result["primary_search_source"]["family"] == family
    assert result["model_coordinate_count"] == len(result["next_atomic_units"]) == count
    assert result["new_model_fits"] == result["new_stop_fits"] == 0
    assert result["worker_inputs_ready"] is False
    assert "accepted_model_result_sha256" in result["primary_search_source"]
    assert "accepted_rsf_result_sha256" not in result["primary_search_source"]


@pytest.mark.parametrize("mutation", ["unconfirmed", "full0", "aar", "false-header"])
def test_primary_preparation_rejects_wrong_authority_or_source(tmp_path, monkeypatch, mutation):
    projected = _projected(monkeypatch, 1, 24)
    if mutation == "unconfirmed":
        projected["science_decision"]["twelve_month_development"]["status"] = "PENDING"
    elif mutation == "full0":
        projected["training_context"]["scope"] = "FULL_DATA"
    elif mutation == "aar":
        projected["training_context"]["channel"] = "AAR"
    else:
        projected["registered"]["kind"] = "PADML_F5_REGISTERED_PARTITION_INPUTS"
    with pytest.raises(ContractError, match="F5_PRIMARY_RSF_PREPARATION_SCOPE_INVALID"):
        f5._prepare_primary_outer_rsf_search(projected, tmp_path / "q", _POLICY,
            retained_bytes_per_task=1024**2, admit_io=lambda **kw: None)
    assert not (tmp_path / "q").exists()


@pytest.mark.parametrize("family", ["RSF", "GBM_COX", "XGBOOST_COX", "COXTIME_SET_A"])
def test_primary_prepare_option_uses_original_compiler(monkeypatch, tmp_path, family):
    received = []
    monkeypatch.setattr(f4, "_compile_o_fit_bundle", lambda *args, **kwargs: received.append((args, kwargs)) or {})
    f4.compile_o_fit_bundle(tmp_path, tmp_path / "input.zip", outer_fold=1,
        science_decision={}, resource_policy=_POLICY, retained_bytes_per_component=1,
        expanded_bytes_per_component=1, shared_storage_bytes=1, primary_rsf_prepare=True,
        primary_prepare_family=family)
    assert received[0][1]["primary_rsf_prepare"] is True
    assert received[0][1]["primary_prepare_family"] == family


@pytest.mark.parametrize("damage", [None, "mixed-consumption", "receipt-ready", "old-batch-drift", "registered-drift"])
def test_publication_only_reuses_boundary_without_preparer(tmp_path, monkeypatch, damage):
    from test_primary_outer12_rsf_inputs import _call
    from padml.bundle import write_deterministic_zip
    call = _call(tmp_path, outer=6)
    tasks = call[2]
    units = f5._q_search_units(kernel._run_r_prediction_pool_task, [call])
    archive = tmp_path / "existing.zip"
    decision = {"UNFITTED": True}
    q_raw = canonical_json_bytes({"spec": {"family": "RSF", "registered_inputs_identity_sha256": "a" * 64},
        "task": {"science_decision": decision}})
    write_deterministic_zip(archive, {"input.json": q_raw})
    before = archive.read_bytes()
    batch = tmp_path / "old-batch"; batch.mkdir()
    record = {"input": {"sha256": sha256_bytes(q_raw), "size_bytes": len(q_raw)}, "UNFITTED": True}
    raw = canonical_json_bytes(record)
    (batch / "execution.json").write_bytes(raw)
    receipt = {"worker_inputs_ready": damage == "receipt-ready", "outer_fold": 6,
        "input": record["input"], "phase": "UNFITTED", "task_ids": list(units),
        "predecessor_execution_sha256": [sha256_bytes(raw)],
        "confirmed_model_fits": 320, "confirmed_stop_fits": 0,
        "f1_identity": "b" * 64, "f2_acceptance_sha256": "c" * 64}
    receipt_path = tmp_path / "receipt.json"
    receipt_path.write_bytes(canonical_json_bytes(receipt))
    compiler = tmp_path / "compiler.zip"; compiler.write_bytes(b"UNFITTED")
    retained = tmp_path / "materialized"; retained.mkdir()
    producer = tmp_path / "producer.zip"; producer.write_bytes(b"UNFITTED")
    if damage == "old-batch-drift": (batch / "execution.json").write_bytes(canonical_json_bytes({**record, "drift": True}))
    seen = []
    monkeypatch.setattr(f5, "_primary_rsf_prepared_input", lambda *a, **k: (call[0], {next(iter(units)): tasks}))
    monkeypatch.setattr(f4, "load_f4_inputs", lambda *a, **k: {
        "source": {key: receipt[key] for key in ("f1_identity", "f2_acceptance_sha256")}, "o_fit_source": {}})
    def retained_fold(frozen, outer, path, **options):
        assert outer == 6 and path == retained and options["reuse_existing"] is True
        return {**call[1], "identity": ("d" if damage == "registered-drift" else "a") * 64}
    monkeypatch.setattr(f4, "_materialize_o_fit_fold", retained_fold)
    # _call already carries an engine-projected fixture, not the original
    # physical registered library; isolate that independently tested reader.
    monkeypatch.setattr(kernel, "_engine_registered_partitions", lambda value, ids: call[1])
    def forbidden(*a, **k): pytest.fail("PREPARATION_OR_SCIENCE_FORBIDDEN")
    monkeypatch.setattr(f5, "_prepare_primary_outer_rsf_search", forbidden)
    monkeypatch.setattr(f5, "_consume_q_search_batches", forbidden)
    monkeypatch.setattr(f5, "_run_final_complex_search", forbidden)
    monkeypatch.setattr(nested, "outer_fresh_score_families", lambda _: [])
    from padml import runtime
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda path: {
        "effective_cpus": 32, "available_memory_bytes": 128 * 1024**3,
        "scratch_available_bytes": 128 * 1024**3, "scratch_root": str(path)})
    def publish(function, actual, root, control, phase, pin):
        assert function is kernel._run_r_prediction_pool_task and list(actual) == list(units)
        assert control["primary_compilation_receipt"] == receipt_path
        assert control["primary_compilation_source_bundle"] == compiler
        assert control["batches"] == [(batch, record)] and pin == record["input"]
        seen.append(True)
        (root / "prepared-unit-inputs.json").write_bytes(b"{}")
    monkeypatch.setattr(f5, "_publish_a12_q_stop_inputs", publish)
    options = dict(outer_fold=6, science_decision=decision, resource_policy=_POLICY,
        retained_bytes_per_component=1024**2, expanded_bytes_per_component=1024**2,
        shared_storage_bytes=1024**3, primary_rsf_prepare=True,
        primary_q_unit_outputs=[[str(tmp_path / "worker.zip"), *units]], primary_producer_source_bundle=producer,
        primary_publication_recovery={"receipt": receipt_path, "compiler_source": compiler,
            "materialized_fold": retained, "batches": [batch]})
    if damage == "mixed-consumption": options["primary_retained_q_input"] = tmp_path / "input.json"
    if damage:
        with pytest.raises(ContractError): f4.compile_o_fit_bundle(tmp_path, archive, **options)
        assert not seen
    else:
        result = f4.compile_o_fit_bundle(tmp_path, archive, **options)
        assert result["publication_only"] is True and result["worker_inputs_ready"] is True and seen == [True]
    assert archive.read_bytes() == before and receipt_path.read_bytes() == canonical_json_bytes(receipt)


@pytest.mark.parametrize("damage", [None, "history-drift", "batch-drift", "registered-drift"])
def test_historical_publication_reuses_closed_s3a_without_numerical_consumer(tmp_path, monkeypatch, damage):
    from test_primary_outer12_rsf_inputs import _call
    from padml.bundle import sha256_file, write_deterministic_zip
    call = _call(tmp_path, outer=5)
    tasks = call[2]
    units = f5._q_search_units(kernel._run_r_prediction_pool_task, [call])
    decision = {"UNFITTED": True}
    source = {"f1_identity": "b" * 64, "f2_acceptance_sha256": "c" * 64}
    q_raw = canonical_json_bytes({"spec": {"family": "RSF",
        "registered_inputs_identity_sha256": "a" * 64, "primary_search_source": source},
        "task": {"science_decision": decision}})
    preparation = tmp_path / "original-preparation.zip"
    write_deterministic_zip(preparation, {"input.json": q_raw})
    producer = tmp_path / "original-producer.zip"; producer.write_bytes(b"ORIGINAL")
    consumer = tmp_path / "consumer-source.zip"; consumer.write_bytes(b"CONSUMER")
    history = []
    for index in range(2):
        path = tmp_path / f"history-{index}.json"
        path.write_bytes(canonical_json_bytes({"HISTORY": index}))
        history.append({f"history-{index}": {"path": str(path), "sha256": sha256_file(path),
                                             "size_bytes": path.stat().st_size}})
    hosts = ("H0", "H1", "H4", "H5", "H6", "H7", "H9-2")
    batches, received, predecessors = [], [], []
    input_ref = {"sha256": sha256_bytes(q_raw), "size_bytes": len(q_raw)}
    for host in hosts:
        batch = tmp_path / host; batch.mkdir()
        record = {"input": input_ref, "host": host}
        raw = canonical_json_bytes(record)
        (batch / "execution.json").write_bytes(raw)
        digest = sha256_bytes(raw)
        batches.append(batch); predecessors.append(digest)
        received.append({"host": host, "batch_root": str(batch), "execution_sha256": digest})
    boundary = {"phase": "UNFITTED", "input": input_ref, "task_ids": list(units),
        "predecessor_execution_sha256": predecessors, "confirmed_model_fits": 620,
        "confirmed_stop_fits": 0}
    report = {"status": "ORIGINAL_PRIMARY12_S3A_CONSUMED_S3B1_PREPARED",
        "outer_fold": 5, "selection_horizon_months": 12, "worker_inputs_ready": False,
        "received": received, "predecessor_execution_sha256": predecessors,
        "s1_history_members": history[0], "s2_history_members": history[1],
        "original_q_boundary": boundary}
    report_path = tmp_path / "report.json"
    report_path.write_bytes(canonical_json_bytes(report))
    retained = tmp_path / "materialized"; retained.mkdir()
    if damage == "history-drift": (tmp_path / "history-0.json").write_bytes(b"{}")
    if damage == "batch-drift": (batches[-1] / "execution.json").write_bytes(b"{}")
    seen = []
    def prepared(raw, actual_preparation, actual_producer, **evidence):
        assert raw == q_raw and actual_preparation == preparation and actual_producer == producer
        assert list(evidence) == ["s2_evidence", "s3a_evidence", "s3b1_evidence"]
        assert evidence["s3b1_evidence"]["source/primary-s3b1-producer.zip"] == consumer
        return call[0], {next(iter(units)): tasks}
    monkeypatch.setattr(f5, "_primary_rsf_prepared_input", prepared)
    monkeypatch.setattr(f4, "load_f4_inputs", lambda *a, **k: {"source": source, "o_fit_source": {}})
    monkeypatch.setattr(f4, "_materialize_o_fit_fold", lambda frozen, outer, path, **options:
        {**call[1], "identity": ("d" if damage == "registered-drift" else "a") * 64})
    monkeypatch.setattr(kernel, "_engine_registered_partitions", lambda value, ids: call[1])
    def forbidden(*a, **k): pytest.fail("PREPARATION_OR_SCIENCE_FORBIDDEN")
    monkeypatch.setattr(f5, "_prepare_primary_outer_rsf_search", forbidden)
    monkeypatch.setattr(f5, "_consume_q_search_batches", forbidden)
    monkeypatch.setattr(f5, "_run_final_complex_search", forbidden)
    monkeypatch.setattr(nested, "outer_fresh_score_families", lambda _: [])
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda path: {
        "effective_cpus": 32, "available_memory_bytes": 128 * 1024**3,
        "scratch_available_bytes": 128 * 1024**3, "scratch_root": str(path)})
    def publish(function, actual, root, control, phase, pin):
        assert function is kernel._run_r_prediction_pool_task and list(actual) == list(units)
        assert phase == boundary["phase"] and pin == input_ref
        assert control["primary_rsf_s3b1_evidence"]["primary-s3b1/report.json"] == report_path
        assert control["confirmed_model_fits"] == 620 and control["batches"] == [
            (path, {"input": input_ref, "host": host}) for host, path in zip(hosts, batches, strict=True)]
        seen.append(True)
        (root / "prepared-unit-inputs.json").write_bytes(b"{}")
    monkeypatch.setattr(f5, "_publish_a12_q_stop_inputs", publish)
    options = dict(outer_fold=5, science_decision=decision, resource_policy=_POLICY,
        retained_bytes_per_component=1024**2, expanded_bytes_per_component=1024**2,
        shared_storage_bytes=1024**3, primary_rsf_prepare=True,
        primary_q_unit_outputs=[[str(tmp_path / "worker.zip"), *units]],
        primary_producer_source_bundle=producer,
        primary_history_publication_recovery={"report": report_path, "consumer_source": consumer,
            "materialized_fold": retained, "batches": batches})
    if damage:
        with pytest.raises(ContractError): f4.compile_o_fit_bundle(tmp_path, preparation, **options)
        assert not seen
    else:
        result = f4.compile_o_fit_bundle(tmp_path, preparation, **options)
        assert result["publication_only"] is True and result["worker_inputs_ready"] is True
        assert seen == [True]


@pytest.mark.parametrize("family", ["RSF", "GBM_COX", "XGBOOST_COX", "COXTIME_SET_A"])
def test_primary_family_cli_uses_original_compiler(tmp_path, monkeypatch, capsys, family):
    import sys
    decision, policy = tmp_path / "decision.json", tmp_path / "policy.json"
    for path in (decision, policy): path.write_bytes(canonical_json_bytes({"SYNTHETIC": True}))
    calls = []
    producer = tmp_path / "producer.zip"
    producer.write_bytes(b"UNFITTED_SOURCE")
    publication = ([] if family == "RSF" else ["--primary-q-unit-output", str(tmp_path / "scoped.zip"),
        "SYNTHETIC_ATOM", "--primary-producer-source-bundle", str(producer)])
    monkeypatch.setattr(f4, "compile_o_fit_bundle", lambda *args, **kw: calls.append(kw) or {})
    monkeypatch.setattr(sys, "argv", ["padml-f4", "o-fit-compile", str(tmp_path), str(tmp_path / "q.zip"),
        "--outer-fold", "2", "--science-decision", str(decision), "--resource-policy", str(policy),
        "--retained-bytes-per-component", "1", "--expanded-bytes-per-component", "1",
        "--shared-storage-bytes", "1", "--prepare-primary12-family", family, *publication])
    f4.main()
    assert calls[0]["primary_prepare_family"] == family and calls[0]["primary_rsf_prepare"] is True
    if publication:
        assert calls[0]["primary_q_unit_outputs"] == [[str(tmp_path / "scoped.zip"), "SYNTHETIC_ATOM"]]
        assert calls[0]["primary_producer_source_bundle"] == producer
    assert json.loads(capsys.readouterr().out) == {}


@pytest.mark.parametrize("damage", [None, "consume", "fit", "no-output"])
def test_publication_only_cli_stays_in_original_compiler(tmp_path, monkeypatch, capsys, damage):
    import sys
    files = {name: tmp_path / name for name in ("decision.json", "policy.json", "receipt.json", "compiler.zip", "producer.zip")}
    for path in files.values(): path.write_bytes(canonical_json_bytes({"UNFITTED": True}))
    materialized = tmp_path / "materialized"; materialized.mkdir()
    batch = tmp_path / "batch"; batch.mkdir()
    calls = []
    monkeypatch.setattr(f4, "compile_o_fit_bundle", lambda *a, **kw: calls.append((a, kw)) or {})
    argv = ["padml-f4", "o-fit-compile", str(tmp_path), str(tmp_path / "existing.zip"),
        "--outer-fold", "6", "--science-decision", str(files["decision.json"]),
        "--resource-policy", str(files["policy.json"]), "--retained-bytes-per-component", "1",
        "--expanded-bytes-per-component", "1", "--shared-storage-bytes", "1",
        "--publish-primary12-preparation", str(files["receipt.json"]), str(files["compiler.zip"]), str(materialized),
        "--primary-producer-source-bundle", str(files["producer.zip"]), "--primary-q-batch", str(batch)]
    if damage != "fit": argv.append("--prepare-primary12-rsf")
    if damage != "no-output": argv += ["--primary-q-unit-output", str(tmp_path / "out.zip"), "UNFITTED_ATOM"]
    if damage == "consume": argv += ["--consume-primary12-rsf-history", str(tmp_path)]
    monkeypatch.setattr(sys, "argv", argv)
    if damage:
        with pytest.raises(ContractError): f4.main()
        assert not calls
    else:
        f4.main()
        assert calls[0][1]["primary_publication_recovery"] == {
            "receipt": files["receipt.json"], "compiler_source": files["compiler.zip"],
            "materialized_fold": materialized, "batches": [batch]}
        assert json.loads(capsys.readouterr().out) == {}


def test_historical_publication_cli_stays_in_original_compiler(tmp_path, monkeypatch, capsys):
    import sys
    files = {name: tmp_path / name for name in (
        "decision.json", "policy.json", "report.json", "consumer.zip", "producer.zip")}
    for path in files.values(): path.write_bytes(canonical_json_bytes({"UNFITTED": True}))
    materialized = tmp_path / "materialized"; materialized.mkdir()
    preparation = tmp_path / "existing.zip"; preparation.write_bytes(b"UNFITTED")
    batches = []
    for index in range(7):
        batch = tmp_path / f"batch-{index}"; batch.mkdir(); batches.append(batch)
    calls = []
    monkeypatch.setattr(f4, "compile_o_fit_bundle", lambda *a, **kw: calls.append((a, kw)) or {})
    monkeypatch.setattr(sys, "argv", ["padml-f4", "o-fit-compile", str(tmp_path), str(preparation),
        "--outer-fold", "5", "--science-decision", str(files["decision.json"]),
        "--resource-policy", str(files["policy.json"]), "--retained-bytes-per-component", "1",
        "--expanded-bytes-per-component", "1", "--shared-storage-bytes", "1",
        "--prepare-primary12-rsf", "--publish-primary12-rsf-history", str(files["report.json"]),
        str(files["consumer.zip"]), str(materialized), "--primary-producer-source-bundle",
        str(files["producer.zip"]), "--primary-q-unit-output", str(tmp_path / "out.zip"),
        "UNFITTED_ATOM", *[item for path in batches for item in ("--primary-q-batch", str(path))]])
    f4.main()
    assert calls[0][1]["primary_history_publication_recovery"] == {
        "report": files["report.json"], "consumer_source": files["consumer.zip"],
        "materialized_fold": materialized, "batches": batches}
    assert json.loads(capsys.readouterr().out) == {}


@pytest.mark.parametrize("damage", ["missing-producer", "missing-outputs", "foreign-family", "not-preparation"])
def test_primary_publication_scope_rejected_before_projection(tmp_path, monkeypatch, damage):
    producer = tmp_path / "producer.zip"
    producer.write_bytes(b"UNFITTED_SOURCE")
    options = {"primary_rsf_prepare": True, "primary_prepare_family": "GBM_COX",
        "primary_q_unit_outputs": [[str(tmp_path / "scoped.zip"), "SYNTHETIC_ATOM"]],
        "primary_producer_source_bundle": producer}
    if damage == "missing-producer": options.pop("primary_producer_source_bundle")
    elif damage == "missing-outputs": options.pop("primary_q_unit_outputs")
    elif damage == "foreign-family": options["primary_prepare_family"] = "COX_PH"
    else: options.update(primary_rsf_prepare=False, primary_prepare_family="RSF")
    monkeypatch.setattr(f4, "load_f4_inputs", lambda *a, **k: pytest.fail("SOURCE_READ_FORBIDDEN"))
    with pytest.raises(ContractError, match="F4_PRIMARY_RSF_PREPARATION_SCOPE_INVALID"):
        f4.compile_o_fit_bundle(tmp_path, tmp_path / "input.zip", outer_fold=1,
            science_decision={}, resource_policy=_POLICY, retained_bytes_per_component=1,
            expanded_bytes_per_component=1, shared_storage_bytes=1, **options)
    assert not (tmp_path / "input.zip").exists()


@pytest.mark.parametrize("family", ["RSF", "GBM_COX", "XGBOOST_COX", "COXTIME_SET_A"])
def test_primary_prepared_public_entry_retains_explicit_role(tmp_path, monkeypatch, family):
    seen = []
    monkeypatch.setattr(f5, "_execute_a12_prepared_q_batch", lambda *a, **k: seen.append(k) or {"UNFITTED": True})
    result = f5.execute_final_complex_search(target=tmp_path / "worker", candidate_family=family,
        prepared_q_input=tmp_path / "shard.zip", prepared_q_input_sha256="a" * 64,
        task_ids=["UNFITTED"], batch_root=tmp_path / "batch", retained_bytes_per_task=1024,
        selection_horizon_months=12, primary_outer_prepared=True)
    assert result == {"UNFITTED": True}
    assert seen[0]["full0_only"] is False and seen[0]["selection_horizon_months"] == 12
    assert seen[0]["expected_family"] == family


@pytest.mark.parametrize("family", ["RSF", "GBM_COX", "XGBOOST_COX", "COXTIME_SET_A"])
def test_primary_prepared_cli_keeps_original_entry(tmp_path, monkeypatch, capsys, family):
    import sys
    seen = []
    monkeypatch.setattr(f5, "execute_final_complex_search", lambda **kw: seen.append(kw) or {})
    monkeypatch.setattr(sys, "argv", ["padml-f5", "complex-search", "--primary-outer-prepared",
        "--selection-horizon-months", "12", "--candidate-family", family,
        "--prepared-q-input", str(tmp_path / "shard.zip"), "--prepared-q-input-sha256", "a" * 64,
        "--target", str(tmp_path / "worker"), "--batch-root", str(tmp_path / "batch"),
        "--task-ids", "UNFITTED", "--retained-bytes-per-task", "1024"])
    f5.main()
    assert json.loads(capsys.readouterr().out) == {}
    assert seen[0]["primary_outer_prepared"] is True and seen[0]["selection_horizon_months"] == 12
    assert seen[0]["candidate_family"] == family and seen[0]["full_development_path"] is None
