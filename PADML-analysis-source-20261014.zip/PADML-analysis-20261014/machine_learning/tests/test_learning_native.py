"""UNFITTED direct wiring and exact arithmetic; no new scientific fits.

Compiler tests combine retained synthetic M5 tables/recipe with accepted F2
parameter records. This deliberately hybrid fixture is NOT a native cell or
scientific acceptance; STOP CSVs below are explicitly unfitted test subsets.
"""
import copy
import csv
import io
import math
import os
from pathlib import Path

import pytest

from padml import f4
from padml.bundle import ContractError, canonical_json_bytes, read_safe_zip, sha256_bytes, strict_json_bytes
from padml.f1_kernel import _subset_csv
from padml.f2_kernel import _expected_family_parent_column_map, predictor_contract
from test_f4 import learning_curve_evidence_rows, response


@pytest.fixture(autouse=True)
def no_native(monkeypatch):
    def forbidden(*args, **kwargs):
        raise AssertionError("UNFITTED_TEST_NO_SUBPROCESS_POOL_RNG_OR_FITTING")
    monkeypatch.setattr(f4.subprocess, "run", forbidden)
    monkeypatch.setattr(f4, "_bounded_ordered_spawn", forbidden)
    for name in ("_execute_f4_model_component", "_execute_f4_stop_component", "_run_learning_curve_mice_native",
                 "_fit_learning_curve_recipe", "_run_learning_selector_path", "native_metrics"):
        monkeypatch.setattr(f4, name, forbidden)


@pytest.fixture(scope="module")
def retained_inputs():
    names = ["PADML_LEARNING_MICE_RETAINED", "PADML_LEARNING_SELECTOR_RETAINED", "PADML_F2_ACCEPTED_RUN"]
    if not all(os.environ.get(name) for name in names):
        pytest.skip("Read-only retained fixtures required; no replacement fits")
    mice, selector, accepted = [Path(os.environ[name]) for name in names]
    contract, cell = [strict_json_bytes((mice / name).read_bytes()) for name in ("binding.json", "cell.json")]
    covariates, responses = [(mice / name).read_bytes() for name in ("covariates.csv", "response.csv")]
    partitions = strict_json_bytes((selector / "native-tests/test_m5_native_fixed_inner_and0/inputs/partitions.json").read_bytes())
    recipe, = [row["transform_recipe"] for row in partitions if row["inner_fold"] == 0]
    models = {}
    for path in sorted((accepted / "results").glob("*f1*.zip")):
        entries = read_safe_zip(path)
        manifest = strict_json_bytes(entries["manifest.json"])
        for artifact in manifest["artifacts"]:
            model = strict_json_bytes(entries[artifact["relative_path"]])
            if model.get("fold") == 1 and model.get("family") in f4.FAMILY_COMPLEXITY:
                models[model["family"]] = model
    assert set(models) == set(f4.FAMILY_COMPLEXITY)
    return mice, contract, cell, covariates, responses, recipe, models


def unfitted_compiler_fixture(tmp_path, retained_inputs, family):
    mice, contract, original, covariates, responses, recipe, models = retained_inputs
    cell = {**copy.deepcopy(original), "family": family,
            "seeds": f4._learning_curve_seeds(family, 1, 1, 1, 1)}
    source_rows = list(csv.DictReader(io.StringIO(covariates.decode("utf-8-sig"))))
    source = {"binding_contract": contract, "registry": contract["registry"], "covariates_csv": covariates,
              "response_csv": responses, "centers": {row["Patient_ID"]: row["Center"] for row in source_rows},
              "models": {(1, family): models[family]}}
    root = tmp_path.resolve() / "UNFITTED_M5"
    root.mkdir()
    specs = f4._learning_curve_mice_specs(contract, covariates, responses, None, cell, root)
    for role, spec in specs.items():
        target = root / role / "output/imputations"
        target.mkdir(parents=True)
        original_role = "ANALYSIS" if role.startswith("STOP_") else role
        for imp in range(1, 6):
            raw = (mice / "fixed-m5" / original_role / f"output/imputations/imp{imp:02d}.csv").read_bytes()
            if role.startswith("STOP_"):
                _subset_csv(raw, spec["view"]["row_ids"], target / f"imp{imp:02d}.csv")
            else:
                (target / f"imp{imp:02d}.csv").write_bytes(raw)
    selected = ["AST_ALT"]  # Deliberately different from the original outer SetA.
    df = sum(len(row["columns"]) for row in _expected_family_parent_column_map(
        selected, "ELASTIC_NET_COX", predictor_contract(Path(f4.__file__).parent), recipe))
    fields, records = f4._response_rows(responses)
    events = f4._write_response_subset(fields, records, cell["analysis_ids"], None)["event_count"]
    selector = {"cell": cell, "sensitivity_selection_effect": "NONE", "selector": {
        "status": "FEASIBLE", "selected_parents": selected, "common_set_design_df": df,
        "training_event_count": events, "common_set_epv": events / df}}
    locks = None
    if family in {"GBM_COX", "XGBOOST_COX", "COXTIME_SET_A"}:
        key = {"GBM_COX": "selected_trees", "XGBOOST_COX": "selected_rounds", "COXTIME_SET_A": "locked_epoch"}[family]
        locks = {imp: {key: 80 if family == "COXTIME_SET_A" else imp + 10} for imp in range(1, 6)}
    return models[family], cell, selector, recipe, source, root, locks


@pytest.mark.parametrize("family", list(f4.FAMILY_COMPLEXITY))
def test_fresh_seta_and_m5_consume_original_outer_parameters(tmp_path, retained_inputs, family):
    model, cell, selector, recipe, source, root, locks = unfitted_compiler_fixture(tmp_path, retained_inputs, family)
    before = canonical_json_bytes(model)
    jobs = f4._prepare_learning_curve_partition(model, cell, selector, recipe, source, root, stop_locks=locks)
    assert [job["name"] for job in jobs] == [f"M{imp:02d}" for imp in range(1, 6)]
    for imp, job in enumerate(jobs, 1):
        task, design, training, outcomes, application, apparent = f4._f4_native_component_inputs(job["entries"])
        assert task["imputation"] == imp and task["selected_parents"] == ["AST_ALT"]
        assert task["registered_model_seed"] == cell["seeds"]["model"] and not apparent
        assert [row["Patient_ID"] for row in training] == cell["analysis_ids"] == list(outcomes)
        assert [row["Patient_ID"] for row in application] == cell["validation_ids"]
        assert design["transform_recipe"] == (recipe if family in {"COX_PH", "ELASTIC_NET_COX", "FPM_TVC_SET_A"} else None)
        if family == "ELASTIC_NET_COX":
            assert task["parameters"]["alpha"] == model["selected_spec"]["alpha"]
            for key, source_key in (("lambda", "lambda_by_imputation"), ("ratio", "ratio_by_imputation"),
                                    ("lambda_upper_bound", "lambda_upper_bound_by_imputation")):
                assert task["parameters"][key] == model["selected_spec"][source_key][imp - 1]
        else:
            expected = copy.deepcopy(model["selected_spec"])
            if "selected_parents" in expected:
                expected["selected_parents"] = ["AST_ALT"]
            if locks is not None:
                expected.update(locks[imp])
            assert task["parameters"] == expected
    assert canonical_json_bytes(model) == before


@pytest.mark.parametrize("family", ["GBM_COX", "XGBOOST_COX", "COXTIME_SET_A"])
def test_learning_stop_seed_and_response_are_separate(tmp_path, retained_inputs, family):
    model, cell, selector, recipe, source, root, _ = unfitted_compiler_fixture(tmp_path, retained_inputs, family)
    jobs = f4._prepare_learning_curve_partition(model, cell, selector, recipe, source, root, stop=True)
    for imp, job in enumerate(jobs, 1):
        task, _, training, outcomes, evaluation, seals = f4._f4_stop_component_inputs(job["entries"])
        assert task["imputation"] == imp
        assert task["model_seed"] == task["registered_stop_seed"] == cell["seeds"]["early_stopping"]
        assert task["registered_model_seed"] == cell["seeds"]["model"] != task["model_seed"]
        train_ids, stop_ids = {row["Patient_ID"] for row in training}, {row["Patient_ID"] for row in evaluation}
        assert train_ids.isdisjoint(stop_ids) and train_ids | stop_ids == set(cell["analysis_ids"])
        assert set(outcomes) == train_ids and all(seal["event_count"] > 0 for seal in seals)
        with pytest.raises(ContractError, match="COORDINATE_INVALID"):
            f4._f4_native_component_inputs({name: raw for name, raw in job["entries"].items() if name != "stop-response.csv"})


@pytest.mark.parametrize("drift", ["M4", "M20", "fraction", "recipe", "epv", "missing_stop"])
def test_learning_compiler_rejects_wrong_completion_or_cell(tmp_path, retained_inputs, drift):
    model, cell, selector, recipe, source, root, locks = unfitted_compiler_fixture(tmp_path, retained_inputs, "GBM_COX")
    recipe = copy.deepcopy(recipe)
    if drift == "M4":
        (root / "ANALYSIS/output/imputations/imp05.csv").rename(root / "retained-M5.csv")
    elif drift == "M20":
        path = root / "ANALYSIS/output/imputations/imp05.csv"
        (path.parent / "imp20.csv").write_bytes(path.read_bytes())
    elif drift == "fraction":
        cell["sample_fraction"] = 1.0
        cell["seeds"] = f4._learning_curve_seeds("GBM_COX", 1, 1, 1, 4)
    elif drift == "recipe":
        recipe["partition_id"] = "OUTER_F1"
        recipe["recipe_sha256"] = sha256_bytes(canonical_json_bytes({key: value for key, value in recipe.items() if key != "recipe_sha256"}))
    elif drift == "epv":
        selector["selector"]["common_set_epv"] = 14.9
    else:
        locks.pop(5)
    with pytest.raises(ContractError):
        f4._prepare_learning_curve_partition(model, cell, selector, recipe, source, root, stop_locks=locks)


def native_rows():
    rows = learning_curve_evidence_rows()
    for row in rows:
        row["metric_support"] = {"status": "ESTIMABLE", "value": row["ibs_0_24"], "support": []}
    return rows


def unsupported(row):
    reason = "EFFECTIVE_SAMPLE_SIZE_INSUFFICIENT"
    row["ibs_0_24"] = None
    row["metric_support"] = {"status": "NOT_ESTIMABLE", "value": None, "support": [{
        "scope": "LEARNING_VALIDATION", "horizon": 24, "reasons": [reason],
        "ipcw_qc": {"horizon": 24, "status": "NOT_ESTIMABLE", "reasons": [reason]}}]}


def test_graf_ibs_above_one_is_not_probability_or_support_failure():
    ids = [f"P{index:03d}" for index in range(80)]
    times, events = [0.5] * 40 + [1] * 20 + [40] * 20, [0] * 40 + [1] * 20 + [0] * 20
    raw = response(ids, times, events)["private_bytes"]
    cell = {"family": "RSF", "outer_fold": 1, "validation_ids": ids[40:]}
    source = {"response_csv": raw, "centers": dict.fromkeys(ids, "36"),
              "registry": {"outer": [{"outer_fold": 1, "analysis_ids": ids}]}}
    prediction = {"patient_ids": ids[40:], "centers": ["36"] * 40, "horizons": f4.HORIZONS,
                  "survival": {"RSF": [[1.0] * 37 for _ in range(20)] + [[1.0] + [0.0] * 36 for _ in range(20)]}}
    score = f4._learning_curve_metric(cell, prediction, source)
    assert score["metric_support"] == {"status": "ESTIMABLE", "value": 47 / 24, "support": []}
    assert score["patient_count"] == 40 and score["censoring_reference"]["patient_count"] == 80
    assert all(qc["effective_sample_size"] == 40 and qc["minimum_g"] == .5 for qc in score["ipcw_qc"][1:25])
    rows = native_rows()
    for row in rows:
        row["ibs_0_24"] = 47 / 24
        row["metric_support"]["value"] = 47 / 24
    result = f4._reduce_native_learning_curve(rows, locked_family="RSF")
    assert result["plateau"] is True and result["trigger"] is False


def test_native_reduction_keeps_360_and_unsupported_coordinates():
    rows = native_rows()
    finite = f4._reduce_native_learning_curve(rows, locked_family="RSF")
    assert finite["status"] == "COMPUTED" and finite["plateau"] is True
    unsupported(rows[0])
    result = f4._reduce_native_learning_curve(rows, locked_family="RSF")
    assert result["status"] == "NOT_ESTIMABLE" and result["observed_row_count"] == 360 and result["estimable_row_count"] == 359
    assert result["plateau"] is result["trigger"] is None
    assert result["seed_curves"][0]["equal_outer_context_mean_ibs_0_24"]["0.40"] is None
    assert len(result["outer_context_means"]) == 72 and result["missing_coordinates"] == []
    assert result["full_pipeline_requirement"] == "REQUIRED_DUE_TO_STATISTICAL_SUPPORT"
    for changed in (rows[:-1], [rows[0], *rows[:-1]]):
        with pytest.raises(ContractError):
            f4._reduce_native_learning_curve(changed, locked_family="RSF")
    rows[0]["metric_support"]["support"] = []
    with pytest.raises(ContractError, match="SUPPORT_EVIDENCE_INVALID"):
        f4._reduce_native_learning_curve(rows, locked_family="RSF")
    for value in (math.nan, -1.0):
        changed = native_rows()
        changed[0]["ibs_0_24"] = changed[0]["metric_support"]["value"] = value
        with pytest.raises(ContractError):
            f4._reduce_native_learning_curve(changed, locked_family="RSF")


def test_statistical_support_trigger_does_not_mask_other_unknowns(monkeypatch):
    rows = native_rows()
    unsupported(rows[0])
    evidence = {"kind": "PADML_F4_LEARNING_AGGREGATE_NATIVE_SHARDS_V2", "family": "RSF", "rows": rows,
                "reduction": f4._reduce_native_learning_curve(rows, locked_family="RSF")}
    monkeypatch.setattr(f4, "resolve_f4_final_family_lock", lambda *a: {"locked_family": "RSF"})
    monkeypatch.setattr(f4, "reduce_post_selection_optimism_trigger", lambda *a: {"trigger": False})
    monkeypatch.setattr(f4, "reduce_o_fit_triggers", lambda *a, **k: {"triggers": {"ibs": False, "uno_c": False, "calibration_slope": False}})
    matrix = {"stability": {"matching_replicates": 6, "total_replicates": 6}}
    missing = f4._full_pipeline_bootstrap_status({}, {}, matrix, {}, rows, learning_curve_execution=evidence)
    assert missing["status"] == "BLOCKED" and len(missing["unevaluated_triggers"]) == 3
    ready = f4._full_pipeline_bootstrap_status({}, {}, matrix, {}, rows, [], learning_curve_execution=evidence)
    assert ready["status"] == "REQUIRED" and ready["unevaluated_triggers"] == [] and not ready["execution_started"]
    assert ready["registered_triggers"]["registered_learning_curve_not_plateaued"] is None
    assert ready["statistical_support_triggers"] == ["registered_learning_curve_not_plateaued"]
    declared = f4._full_pipeline_bootstrap_status({}, {}, matrix, {}, learning_curve_evidence_rows(), [])
    assert declared["status"] == "BLOCKED" and declared["unevaluated_triggers"] == ["registered_learning_curve_not_plateaued"]
