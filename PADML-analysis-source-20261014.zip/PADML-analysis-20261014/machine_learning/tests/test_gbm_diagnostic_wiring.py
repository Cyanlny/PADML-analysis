"""Formal selected_spec must reach all three native diagnostic entry points."""
from __future__ import annotations

import copy
import json
from pathlib import Path

import pytest


@pytest.fixture(autouse=True)
def synthetic_host_capacity(monkeypatch):
    monkeypatch.setattr("padml.runtime.effective_cpu_count", lambda: 128)

from padml import f2_kernel as kernel
from padml._science_authority import execution_profile, load_science_authority
from padml.bundle import ContractError
from test_downstream_r_numerics import run_r


@pytest.fixture
def formal_gbm_result(tmp_path,monkeypatch):
    science=load_science_authority()["science"]
    f2=science["f2_model_development"]
    candidates=kernel.candidate_trials("GBM_COX","S1",3,f2["search_spaces"]["GBM_COX"],
        f2["candidate_sequence"],science["modeling_seed_policy"]["sampler"])
    def partition(kind,repeat,fold):
        return {"kind":kind,"partition_id":f"{kind}_R{repeat}K{fold}","repeat":repeat,"inner_fold":fold,
            "fit_ids":["A","B"],"evaluation_ids":["C"],"evaluation_ids_sha256":kernel._sha(["C"]),
            "application_ids":["C"],"covariates":{},"fit_response":{},"evaluation_response":{}}
    inner=[partition("INNER",r,k) for r in range(1,4) for k in range(1,6)]
    stops=[{**partition("STOP",r,k),"fit_ids":["A"],"evaluation_ids":["B"],
        "application_ids":["A","B"],"consumer_set":["GBM_COX","XGBOOST_COX","COXTIME_SET_A"]}
        for r in range(1,4) for k in range(1,6)]
    centers=[{**partition("CENTER_STRESS",0,k),"validation_center":k,"selection_effect":"NONE"}
             for k in range(1,6)]
    outer=partition("OUTER",0,0)
    registered={"kind":"PADML_F2_REGISTERED_PARTITION_INPUTS","status":"PASS",
                "partitions":[*inner,*stops,outer],"diagnostic_partitions":centers}
    selector={"selected_parents":["X","Z"],"outer_recipe_sha256":"a"*64}
    spec={"family":"GBM_COX","selector_from_dependency":selector,"seed":301000,
        "candidate_trials":{"S1":candidates[:2],"S2":candidates},
        "model_seed_policy":{"extra_seed_offsets":[100000,200000]},
        "search_budget":{"standard_outer_units":1055},"monthly_fit_horizons":list(range(1,37))}
    def stopping(spec,registered,tasks,*_):
        return [{"task_id":t["task_id"],"partition_id":t["partition_id"],"imputation":t["imputation"],
                 "selected_trees":17,"identity":kernel._sha(t)} for t in tasks]
    def summary(rows,context,m):
        score=.1+int(kernel._sha(rows[0]["parameters"])[:8],16)/2**32/100
        return {"mean_ibs":score,"maximum_ibs":score,"evaluation_units":len(rows)}
    monkeypatch.setattr(kernel,"_run_r_gbm_stop_batch",stopping)
    monkeypatch.setattr(kernel,"_evaluate_r_prediction_batch",lambda s,r,t,*_:copy.deepcopy(t))
    monkeypatch.setattr(kernel,"_run_r_prediction_batch",lambda s,r,t,*_:copy.deepcopy(t))
    monkeypatch.setattr(kernel,"_accumulate_registered_evaluations",lambda *_:None)
    def scoring_context(partitions, *, selection_horizon_months=24):
        assert selection_horizon_months == 24
        return partitions
    monkeypatch.setattr(kernel,"_trial_scoring_context",scoring_context)
    monkeypatch.setattr(kernel,"_trial_evaluation_summary",summary)
    monkeypatch.setattr(kernel,"_registered_stopping_execution_rows",lambda *_:[])
    monkeypatch.setattr(kernel,"_build_registered_model_result",lambda *a,**k:k)
    result=kernel._run_r_registered_gbm(spec,registered,tmp_path,Path("unused"))
    assert result["selected_spec"]["selected_trees"]==17
    assert "locked_trees" not in result["selected_spec"]
    return result,registered,selector,science


@pytest.mark.parametrize("component",["CENTER_BLOCKED_STRESS","LOCKED_MODEL_SAMPLE_SIZE_DIAGNOSTIC","LOCAL_PERTURBATION"])
def test_formal_gbm_lock_flows_through_actual_diagnostic_atomic_plan(formal_gbm_result,tmp_path,component):
    result,registered,selector,science=formal_gbm_result
    selected=result["selected_spec"]
    model={"family":"GBM_COX","fold":1,"selected_spec":selected,
           "selected_spec_sha256":kernel._sha(selected),"search_trace":result["search_trace"],"selector_evidence":selector}
    if component=="CENTER_BLOCKED_STRESS":
        selected=kernel._center_candidates(model,{"fixed_formal_families":[],"complex_s3b1_families":["GBM_COX"]})[0]["selected_spec"]
    elif component=="LOCKED_MODEL_SAMPLE_SIZE_DIAGNOSTIC":
        registered={**registered,"partitions":[row for row in registered["partitions"] if row["kind"]=="OUTER"]}
    task={"task_id":"diagnostic","family":"GBM_COX","fold":1,"seed":301000,
          "selected_spec":selected,"component":component,"imputations":1}
    profile=execution_profile()
    plans=[kernel._p2c2t_registered_task_result(task=task,contract_task={},model=model,
        registered=registered,science=science,predictors={},scratch=tmp_path,repo_root=Path("unused"),
        route_record={"profile":profile},atomic_job_plan=True,pool_workers=workers)
        for workers in (24,56)]
    assert [plan["pool_workers"] for plan in plans]==[24,56]
    for old_job,new_job in zip(plans[0]["jobs"],plans[1]["jobs"],strict=True):
        assert old_job["fit_task"]==new_job["fit_task"]
        assert old_job["evaluation_partition"]==new_job["evaluation_partition"]
        assert old_job["atomic_task_id"]==new_job["atomic_task_id"]
    plan=plans[1]
    expected=1 if component=="LOCKED_MODEL_SAMPLE_SIZE_DIAGNOSTIC" else 5
    assert plan["expected_fit_count"]==expected and len(plan["jobs"])==expected
    for job in plan["jobs"]:
        parameters=job["fit_task"]["parameters"]
        assert parameters["locked_trees"]==17 and "selected_trees" not in parameters
        assert parameters==kernel._locked_family_parameters("GBM_COX",selected)
    native=run_r(r'''
suppressPackageStartupMessages(library(gbm))
set.seed(7771L);n<-240L
frame<-data.frame(.time=rexp(n)+.01,.event=rbinom(n,1,.75),X=rnorm(n),Z=rnorm(n))
time_col<-".time";event_col<-".event"
mapping<-function(data) list(x=as.matrix(data[,c("X","Z")]),
             parent_map=data.frame(parent=c("X","Z"),column=c("X","Z")))
prepared<-list(train_mapping=mapping(frame),test_mapping=mapping(frame[1:12,]))
parameters<-fromJSON(Sys.getenv("PADML_GBM_DIAGNOSTIC_PARAMETERS"))
actual<-fit_predict("GBM_COX",frame,frame[1:12,],c("X","Z"),parameters,301001L,c(.1,.5,1),NULL,prepared_design=prepared)
stopifnot(actual$stopping$selected_trees==17L,actual$stopping$tree_count==17L,
          identical(actual$stopping$stopping_reselected,FALSE),all(is.finite(actual$survival)))
cat(toJSON(list(locked_trees=actual$stopping$selected_trees,finite=TRUE,
               objective=actual$stopping$cox_objective),auto_unbox=TRUE),"\n")
''',extra_env={"PADML_GBM_DIAGNOSTIC_PARAMETERS":json.dumps(parameters)})
    assert native["locked_trees"]==17 and native["finite"] is True
    assert native["objective"]["source_correction"]=="cox-breslow-ties-v1"


def test_old_ambiguous_gbm_lock_field_is_not_a_compatibility_fallback(formal_gbm_result):
    from padml.bundle import ContractError
    selected=copy.deepcopy(formal_gbm_result[0]["selected_spec"])
    selected["locked_trees"]=selected.pop("selected_trees")
    with pytest.raises(ContractError,match="LOCKED_GBM_TREE_COUNT_INVALID"):
        kernel._locked_family_parameters("GBM_COX",selected)


def test_center_stress_engine_scope_is_resolved_from_diagnostics():
    center = {
        "partition_id": "CENTER_STRESS_F2_C36",
        "fit_ids": ["A", "B"],
        "evaluation_ids": ["C"],
        "evaluation_ids_sha256": kernel._sha(["C"]),
    }
    registered = {
        "partitions": [],
        "diagnostic_partitions": [center],
    }
    assert kernel._scoped_engine_partition(
        registered, "CENTER_STRESS_F2_C36"
    ) is center

    duplicated = {
        "partitions": [copy.deepcopy(center)],
        "diagnostic_partitions": [center],
    }
    with pytest.raises(ContractError, match="F2_ENGINE_PARTITION_SCOPE_INVALID"):
        kernel._scoped_engine_partition(duplicated, "CENTER_STRESS_F2_C36")


@pytest.mark.parametrize("workers", [24, 56])
def test_atomic_window_uses_one_requested_pool_and_preserves_reduction_order(monkeypatch, workers):
    plans = [{"kind": "PADML_F2_P2C2T_ATOMIC_JOB_PLAN", "task_id": f"top-{top}",
              "pool_workers": workers, "engine_threads": 1, "expected_fit_count": 3,
              "jobs": [{"top_task_id": f"top-{top}", "atomic_task_id": f"{top}-{i}",
                        "seed": top * 100 + i} for i in range(3)]} for top in range(2)]
    observed = []
    def execute(worker, jobs, *, selected_slots, on_result):
        observed.append(selected_slots)
        assert worker is kernel._run_p2c2t_atomic_pool_task
        values = [{"top_task_id": job["top_task_id"], "atomic_task_id": job["atomic_task_id"],
                   "evaluated": {"seed": job["seed"]}} for job in jobs]
        rows = [{**row, "task_identity_sha256": kernel._sha(row)} for row in values]
        for index in reversed(range(len(rows))):
            on_result(index, rows[index])
        return rows
    monkeypatch.setattr(kernel, "_bounded_ordered_spawn", execute)
    result = kernel._run_p2c2t_atomic_window(plans)
    assert observed == [workers]
    assert result == [[{"seed": top * 100 + i} for i in range(3)] for top in range(2)]
    for bad_workers in (61, True, 24 if workers == 56 else 56):
        bad = copy.deepcopy(plans)
        bad[1]["pool_workers"] = bad_workers
        with pytest.raises(ContractError, match="F2_P2C2T_ATOMIC_WINDOW_INVALID"):
            kernel._run_p2c2t_atomic_window(bad)
    assert observed == [workers]


def test_p2c2t_fpm_repair_retains_only_exact_unaffected_tasks():
    tasks = [{"task_id": f"task-{i}", "family": family, "seed": 100 + i}
             for i, family in enumerate(("GBM_COX", "FPM_TVC_SET_A", "COX_PH"))]
    registry = {"component": "CENTER_BLOCKED_STRESS", "tasks": tasks, "task_count": len(tasks)}
    rows = [{"task_id": task["task_id"], "family": task["family"],
             "task_contract_sha256": kernel._sha(task), "unchanged_science": [i, .1]}
            for i, task in enumerate(tasks)]
    previous = {"artifact_kind": "F2_P2C2T", "status": "PASS", "component": registry["component"],
                "contract_sha256": "a" * 64, "task_registry": registry,
                "f1_response_seal_sha256": "b" * 64, "task_results": rows,
                "task_result_set_sha256": kernel._sha(rows)}
    original = copy.deepcopy(previous)
    kept = kernel._p2c2t_retained_non_fpm(previous, registry, "a" * 64, "b" * 64)
    assert list(kept) == ["task-0", "task-2"]
    assert kept["task-0"] is rows[0] and kept["task-2"] is rows[2]
    assert previous == original
    for field in ("task_registry", "task_result_set_sha256", "f1_response_seal_sha256", "contract_sha256"):
        bad = {**previous, field: {"changed": True} if field == "task_registry" else "c" * 64}
        with pytest.raises(ContractError, match="F2_P2C2T_REUSE_SCIENTIFIC_INPUT_CHANGED"):
            kernel._p2c2t_retained_non_fpm(bad, registry, "a" * 64, "b" * 64)
    wrong_family = copy.deepcopy(previous)
    wrong_family["task_results"][1]["family"] = "GBM_COX"
    wrong_family["task_result_set_sha256"] = kernel._sha(wrong_family["task_results"])
    with pytest.raises(ContractError, match="F2_P2C2T_REUSE_SCIENTIFIC_INPUT_CHANGED"):
        kernel._p2c2t_retained_non_fpm(wrong_family, registry, "a" * 64, "b" * 64)
