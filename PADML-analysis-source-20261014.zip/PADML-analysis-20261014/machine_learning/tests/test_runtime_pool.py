from __future__ import annotations
import multiprocessing
import os
import random
from pathlib import Path
import shutil
import signal
import subprocess
import time
import weakref

import pytest

from padml.bundle import ContractError
from padml.runtime import THREAD_ENV, _bounded_ordered_spawn, _spawn_task_entry, effective_cpu_count, pool_capacity


@pytest.mark.parametrize("cpus,memory,scratch,transfer,tasks,expected", [
    (64, 10000, 10000, 100, 600, 56),
    (63, 10000, 10000, 100, 600, 55),
    (64, 350, 10000, 100, 600, 3),
    (64, 10000, 240, 100, 600, 2),
    (64, 10000, 10000, 4, 600, 4),
    (64, 10000, 10000, 100, 1, 1),
])
def test_resource_admission_is_minimum_of_all_host_limits(cpus, memory, scratch, transfer, tasks, expected):
    from padml.runtime import resource_admission
    policy = {"configured_worker_ceiling": "EXECUTION_HOST_C_MINUS_8", "memory_bytes_per_worker": 100,
              "scratch_bytes_per_worker": 100, "memory_reserve_bytes": 0,
              "scratch_reserve_bytes": 0, "transfer_archive_worker_ceiling": transfer}
    observation = {"effective_cpus": cpus, "available_memory_bytes": memory,
                   "scratch_available_bytes": scratch, "scratch_root": "/fixture"}
    assert resource_admission(policy, observation, legal_tasks=tasks)["admitted_worker_ceiling"] == expected


@pytest.mark.parametrize("cpus,tasks,physical,expected", [
    (32, 600, 1000, 24), (64, 600, 1000, 56), (128, 600, 1000, 120),
    (128, 20, 1000, 20), (128, 600, 3, 3),
])
def test_nested_cpu_ceiling_is_host_derived_not_job_count(cpus, tasks, physical, expected):
    from padml.runtime import resource_admission
    policy = {"configured_worker_ceiling": "EXECUTION_HOST_C_MINUS_8",
              "memory_bytes_per_worker": 100, "scratch_bytes_per_worker": 100,
              "memory_reserve_bytes": 0, "scratch_reserve_bytes": 0,
              "transfer_archive_worker_ceiling": physical}
    observation = {"effective_cpus": cpus, "available_memory_bytes": 100_000,
                   "scratch_available_bytes": 100_000, "scratch_root": "/UNFITTED"}
    admitted = resource_admission(policy, observation, legal_tasks=tasks)
    assert admitted["limits"]["configured"] == cpus - 8
    assert admitted["admitted_worker_ceiling"] == expected


@pytest.mark.parametrize("old_limit", [1, 20, 24, 40, 56])
def test_new_resource_policy_cannot_inherit_a_historical_worker_cap(old_limit):
    from padml.runtime import validate_resource_policy
    policy = {"configured_worker_ceiling": old_limit,
              "memory_bytes_per_worker": 100, "scratch_bytes_per_worker": 100,
              "memory_reserve_bytes": 0, "scratch_reserve_bytes": 0,
              "transfer_archive_worker_ceiling": 1000}
    with pytest.raises(ContractError, match="RESOURCE_POLICY_INVALID"):
        validate_resource_policy(policy)


@pytest.fixture(autouse=True)
def synthetic_host_capacity(monkeypatch):
    monkeypatch.setattr("padml.runtime.effective_cpu_count", lambda: 128)


def _cgroup_host(tmp_path, monkeypatch, *, affinity=128, quota="max 100000", cpuset="0-127"):
    from padml import runtime
    mount = tmp_path / "cgroup"
    leaf = mount / "parent" / "leaf"
    leaf.mkdir(parents=True)
    for path in (mount, leaf.parent, leaf):
        (path / "cpu.max").write_text("max 100000")
    (leaf / "cpu.max").write_text(quota)
    (leaf / "cpuset.cpus.effective").write_text(cpuset)
    read_text = Path.read_text
    def read(path, *args, **kwargs):
        if str(path) == "/proc/self/cgroup":
            return "0::/parent/leaf\n"
        if str(path) == "/proc/self/mountinfo":
            return f"1 0 0:1 / {mount} ro - cgroup2 cgroup rw\n"
        return read_text(path, *args, **kwargs)
    monkeypatch.setattr(runtime.sys, "platform", "linux")
    monkeypatch.setattr(runtime.os, "sched_getaffinity", lambda _: set(range(affinity)), raising=False)
    monkeypatch.setattr(Path, "read_text", read)
    return leaf


@pytest.mark.parametrize("cpus,slots", [(32,24),(64,56),(128,120)])
def test_effective_cpu_minus_eight(tmp_path, monkeypatch, cpus, slots):
    _cgroup_host(tmp_path, monkeypatch, affinity=cpus, quota=f"{cpus*100000} 100000")
    assert effective_cpu_count() == cpus
    assert pool_capacity(effective_cpu_count()) == slots


@pytest.mark.parametrize("affinity,quota,cpuset,expected", [
    (128,"3200000 100000","0-127",32), (32,"max 100000","0-127",32),
    (128,"max 100000","0-15,64-79",32), (128,"3299999 100000","0-127",32),
])
def test_cpu_minimum_and_fractional_quota(tmp_path,monkeypatch,affinity,quota,cpuset,expected):
    _cgroup_host(tmp_path,monkeypatch,affinity=affinity,quota=quota,cpuset=cpuset)
    assert effective_cpu_count() == expected


def test_parent_quota_limits_unlimited_leaf(tmp_path,monkeypatch):
    leaf=_cgroup_host(tmp_path,monkeypatch)
    (leaf.parent / "cpu.max").write_text("6400000 100000")
    assert effective_cpu_count() == 64


@pytest.mark.parametrize("leaf_limit,leaf_usage,parent_limit,parent_usage,expected", [
    ("max", 100, "max", 200, 1024 * 1024),
    (1000, 100, "max", 200, 900),
    (10000, 100, 2000, 1800, 200),
    (2000, 1800, 10000, 2000, 200),
    (2000000, 100, "max", 200, 1024 * 1024),
])
def test_available_memory_observes_cgroup_ancestors(
    tmp_path, monkeypatch, leaf_limit, leaf_usage, parent_limit, parent_usage, expected,
):
    from padml.runtime import _available_memory_bytes
    leaf = _cgroup_host(tmp_path, monkeypatch)
    for path, limit, usage in (
        (leaf, leaf_limit, leaf_usage), (leaf.parent, parent_limit, parent_usage),
        (leaf.parent.parent, "max", 500),
    ):
        (path / "memory.max").write_text(str(limit))
        (path / "memory.current").write_text(str(usage))
    read_text = Path.read_text
    def read(path, *args, **kwargs):
        if str(path) == "/proc/meminfo":
            return "MemTotal: 999999 kB\nMemFree: 50 kB\nMemAvailable: 1024 kB\n"
        return read_text(path, *args, **kwargs)
    monkeypatch.setattr(Path, "read_text", read)
    assert _available_memory_bytes() == expected


@pytest.mark.parametrize("limit,usage", [(10, 20), (0, 0), (-1, 0), (10, -1), ("broken", 0)])
def test_bad_or_exhausted_cgroup_ram_never_uses_host_ram(tmp_path, monkeypatch, limit, usage):
    from padml.runtime import _available_memory_bytes
    leaf = _cgroup_host(tmp_path, monkeypatch)
    (leaf / "memory.max").write_text(str(limit))
    (leaf / "memory.current").write_text(str(usage))
    read_text = Path.read_text
    def read(path, *args, **kwargs):
        if str(path) == "/proc/meminfo":
            return "MemAvailable: 1024 kB\n"
        return read_text(path, *args, **kwargs)
    monkeypatch.setattr(Path, "read_text", read)
    with pytest.raises(ContractError, match="MEMORY_RESOURCE"):
        _available_memory_bytes()


@pytest.mark.parametrize("include_unmounted_v2", [False, True])
def test_v1_memory_headroom_includes_sibling_usage(tmp_path, monkeypatch, include_unmounted_v2):
    from padml import runtime
    mount = tmp_path / "memory"
    leaf = mount / "leaf"
    leaf.mkdir(parents=True)
    for path, limit, usage in ((mount, 1000, 800), (leaf, 900, 10)):
        (path / "memory.limit_in_bytes").write_text(str(limit))
        (path / "memory.usage_in_bytes").write_text(str(usage))
    read_text = Path.read_text
    def read(path, *args, **kwargs):
        if str(path) == "/proc/self/cgroup":
            return ("0::/leaf\n" if include_unmounted_v2 else "") + "1:memory:/leaf\n"
        if str(path) == "/proc/self/mountinfo":
            return f"1 0 0:1 / {mount} ro - cgroup cgroup rw,memory\n"
        if str(path) == "/proc/meminfo":
            return "MemAvailable: 1024 kB\n"
        return read_text(path, *args, **kwargs)
    monkeypatch.setattr(runtime.sys, "platform", "linux")
    monkeypatch.setattr(Path, "read_text", read)
    assert runtime._available_memory_bytes() == 200


def test_missing_memory_controller_fails_closed(tmp_path, monkeypatch):
    from padml.runtime import _available_memory_bytes
    _cgroup_host(tmp_path, monkeypatch)
    read_text = Path.read_text
    def read(path, *args, **kwargs):
        if str(path) == "/proc/meminfo":
            return "MemAvailable: 1024 kB\n"
        return read_text(path, *args, **kwargs)
    monkeypatch.setattr(Path, "read_text", read)
    with pytest.raises(ContractError, match="MEMORY_RESOURCE_UNDETERMINED"):
        _available_memory_bytes()


def test_v1_hierarchical_cpu_quota_and_cpuset(tmp_path,monkeypatch):
    from padml import runtime
    cpu=tmp_path / "cpu"
    cpuset=tmp_path / "cpuset"
    for mount in (cpu,cpuset):
        (mount / "leaf").mkdir(parents=True)
    for path,quota in ((cpu,6400000),(cpu / "leaf",-1)):
        (path / "cpu.cfs_quota_us").write_text(str(quota))
        (path / "cpu.cfs_period_us").write_text("100000")
    (cpuset / "cpuset.cpus").write_text("0-127")
    (cpuset / "leaf/cpuset.cpus").write_text("0-31")
    read_text=Path.read_text
    def read(path,*args,**kwargs):
        if str(path)=="/proc/self/cgroup":
            return "1:cpu,cpuacct:/leaf\n2:cpuset:/leaf\n"
        if str(path)=="/proc/self/mountinfo":
            return (f"1 0 0:1 / {cpu} ro - cgroup cgroup rw,cpu,cpuacct\n"
                    f"2 0 0:2 / {cpuset} ro - cgroup cgroup rw,cpuset\n")
        return read_text(path,*args,**kwargs)
    monkeypatch.setattr(runtime.sys,"platform","linux")
    monkeypatch.setattr(runtime.os,"sched_getaffinity",lambda _:set(range(128)),raising=False)
    monkeypatch.setattr(Path,"read_text",read)
    assert effective_cpu_count()==32


def test_missing_cpu_controller_is_not_assumed_unlimited(tmp_path,monkeypatch):
    leaf=_cgroup_host(tmp_path,monkeypatch)
    for path in (leaf,leaf.parent,leaf.parent.parent):
        (path / "cpu.max").unlink()
    with pytest.raises(ContractError,match="CPU_RESOURCE_UNDETERMINED"):
        effective_cpu_count()


@pytest.mark.parametrize("quota", ["0 100000","-1 100000","max 0","broken"])
def test_cpu_invalid_quota_never_falls_back(tmp_path,monkeypatch,quota):
    _cgroup_host(tmp_path,monkeypatch,quota=quota)
    with pytest.raises(ContractError,match="CPU_RESOURCE"):
        effective_cpu_count()


@pytest.mark.parametrize("cpus", [0,1,8,None,True,32.5])
def test_unknown_or_small_cpu_is_resource_error(monkeypatch,cpus):
    monkeypatch.setattr("padml.runtime.effective_cpu_count",lambda:cpus)
    with pytest.raises(ContractError,match="CPU_RESOURCE"):
        pool_capacity()


def test_requested_pool_cannot_exceed_execution_host(monkeypatch):
    monkeypatch.setattr("padml.runtime.effective_cpu_count",lambda:32)
    with pytest.raises(ContractError,match="EXCEED_EXECUTION_HOST"):
        _bounded_ordered_spawn(_seeded_task,[(1,0)],selected_slots=56)
    assert not multiprocessing.active_children()


def test_small_task_count_does_not_fill_capacity():
    results=_bounded_ordered_spawn(_seeded_task,[(1,0),(2,0)])
    assert len(results)==len({row["pid"] for row in results})==2
    assert [row["value"] for row in results]==[random.Random(x).random() for x in (1,2)]


def test_long_tail_schedule_changes_dispatch_not_canonical_reduction():
    arrivals = []
    tasks = [(index, 0) for index in range(4)]
    results = _bounded_ordered_spawn(
        _seeded_task,
        tasks,
        selected_slots=1,
        schedule_order=[3, 1, 2, 0],
        on_result=lambda index, result: arrivals.append(index),
    )
    assert arrivals == [3, 1, 2, 0]
    assert [row["seed"] for row in results] == [0, 1, 2, 3]


@pytest.mark.parametrize("order", [[0, 0], [1], [0, 2]])
def test_long_tail_schedule_must_be_exact_permutation(order):
    with pytest.raises(ContractError, match="SCHEDULE_INVALID"):
        _bounded_ordered_spawn(
            _seeded_task, [(1, 0), (2, 0)], selected_slots=1,
            schedule_order=order,
        )


def test_nested_scientific_pool_is_rejected(monkeypatch):
    monkeypatch.setattr("padml.runtime._IN_SCIENTIFIC_POOL",True)
    with pytest.raises(ContractError,match="NESTED_SCIENTIFIC_POOL_FORBIDDEN"):
        _bounded_ordered_spawn(_seeded_task,[(1,0)],selected_slots=1)


def _seeded_task(task: tuple[int, float]) -> dict:
    from padml import runtime
    seed, delay = task
    time.sleep(delay)
    random.seed(seed)
    return {
        "seed": seed,
        "value": random.random(),
        "pid": os.getpid(),
        "deadline": runtime._ACTIVE_TASK_DEADLINE,
        "threads": {key: os.environ.get(key) for key in THREAD_ENV},
    }


@pytest.mark.parametrize("cpus", [32, 64, 128])
def test_actual_small_pool_does_not_relabel_job_count_as_cpu_ceiling(monkeypatch, cpus):
    monkeypatch.setattr("padml.runtime.effective_cpu_count", lambda: cpus)
    report = {}
    results = _bounded_ordered_spawn(_seeded_task, [(i, .01) for i in range(3)], execution_report=report)
    assert [row["seed"] for row in results] == [0, 1, 2]
    assert report == {"configured_worker_ceiling": cpus - 8,
        "admitted_worker_ceiling": cpus - 8, "runnable_task_count": 3,
        "actual_worker_process_peak": 3, "completed_task_count": 3,
        "engine_threads": 1, "status": "COMPLETED"}
    assert not multiprocessing.active_children()


def test_two_tasks_share_one_pool_and_callback_cannot_take_another_budget():
    report, rejected = {}, []
    def callback(index, result):
        with pytest.raises(ContractError, match="CONCURRENT_SCIENTIFIC_POOL_FORBIDDEN"):
            _bounded_ordered_spawn(_seeded_task, [(100 + index, 0)])
        rejected.append(index)
    # Distinct task coordinates are flattened once, rather than owning pools.
    tasks = [(i, .01) for i in [10, 11, 20, 21]]
    result = _bounded_ordered_spawn(_seeded_task, tasks, selected_slots=3,
                                   on_result=callback, execution_report=report)
    assert [row["seed"] for row in result] == [10, 11, 20, 21]
    assert sorted(rejected) == list(range(4))
    assert report["configured_worker_ceiling"] == 120
    assert report["admitted_worker_ceiling"] == report["actual_worker_process_peak"] == 3
    assert not multiprocessing.active_children()


def _coordinated_start_entry(worker, connection, capture_release=False):
    root = Path(os.environ["PADML_UNFITTED_STARTUP_ROOT"])
    (root / f"{os.getpid()}.started").write_bytes(b"UNFITTED startup only")
    deadline = time.monotonic() + 5
    while len(list(root.glob("*.started"))) != 2 and time.monotonic() < deadline:
        time.sleep(.01)
    assert len(list(root.glob("*.started"))) == 2, "second worker was blocked by first READY"
    if os.getpid() != min(int(path.stem) for path in root.glob("*.started")):
        time.sleep(.3)
    (root / f"{os.getpid()}.ready").write_bytes(b"UNFITTED before READY")
    _spawn_task_entry(worker, connection, capture_release)


def test_pool_starts_admitted_workers_before_waiting_for_individual_ready(tmp_path, monkeypatch):
    from padml import runtime
    monkeypatch.setenv("PADML_UNFITTED_STARTUP_ROOT", str(tmp_path))
    monkeypatch.setattr(runtime, "_spawn_task_entry", _coordinated_start_entry)
    monkeypatch.setattr(runtime, "effective_cpu_count", lambda: 32)
    report = {}
    def callback(index, value):
        assert len(list(tmp_path.glob("*.ready"))) == 2, "callback blocked an unacknowledged startup"
    results = _bounded_ordered_spawn(_seeded_task, [(1, 0), (2, 0)], selected_slots=2,
                                    execution_report=report, on_result=callback)
    assert [row["seed"] for row in results] == [1, 2]
    assert len(list(tmp_path.glob("*.started"))) == report["actual_worker_process_peak"] == 2
    assert report["configured_worker_ceiling"] == 24 and report["status"] == "COMPLETED"
    assert not multiprocessing.active_children()


def _mark_started_task(task):
    index, directory = task
    (Path(directory) / f"{index}.started").write_bytes(b"UNFITTED task only")
    return index


def test_pool_refills_before_serial_retention_callback(tmp_path, monkeypatch):
    monkeypatch.setattr("padml.runtime.effective_cpu_count", lambda: 32)
    arrivals = []
    def callback(index, result):
        assert index == result
        if index < 2:
            next_started = tmp_path / f"{index + 1}.started"
            deadline = time.monotonic() + 5
            while not next_started.is_file() and time.monotonic() < deadline:
                time.sleep(.01)
            assert next_started.is_file(), "callback blocked refilling the completed slot"
        arrivals.append(index)
    result = _bounded_ordered_spawn(_mark_started_task, [(i, str(tmp_path)) for i in range(3)],
                                   selected_slots=1, on_result=callback)
    assert result == arrivals == [0, 1, 2]
    assert not multiprocessing.active_children()


def _unready_start_entry(worker, connection, capture_release=False):
    time.sleep(10)


@pytest.mark.parametrize("timeout", [None, 86400])
def test_pool_carries_exact_deadlines_across_coordinate_phases(monkeypatch, timeout):
    from padml import runtime
    monkeypatch.setattr(runtime, "effective_cpu_count", lambda: 32)
    deadlines = [None, None]
    first = _bounded_ordered_spawn(_seeded_task, [(1, 0), (2, 0)], selected_slots=1,
                                   task_deadlines=deadlines, task_timeout_seconds=timeout)
    original = list(deadlines)
    assert all(time.monotonic() < value <= time.monotonic() + (timeout or runtime._TASK_DEADLINE_SECONDS)
               for value in deadlines)
    assert [row["deadline"] for row in first] == deadlines
    assert deadlines[1] > deadlines[0]
    second = _bounded_ordered_spawn(_seeded_task, [(1, 0), (2, 0)], selected_slots=2,
                                    schedule_order=[1, 0], task_deadlines=deadlines, task_timeout_seconds=timeout)
    assert [row["deadline"] for row in second] == original
    assert deadlines == original
    assert [(row["seed"], row["value"]) for row in first] == [(row["seed"], row["value"]) for row in second]
    assert not multiprocessing.active_children()


@pytest.mark.parametrize("deadlines", [(), [], [None], [None, None, None], [True, None],
    [float("nan"), None], [float("inf"), None], [-1, None], ["invalid", None]])
def test_pool_rejects_invalid_carried_deadlines_before_dispatch(tmp_path, deadlines):
    with pytest.raises(ContractError, match="BOUNDED_SPAWN_DEADLINES_INVALID"):
        _bounded_ordered_spawn(_mark_started_task, [(i, str(tmp_path)) for i in range(2)],
                               selected_slots=1, task_deadlines=deadlines)
    assert not list(tmp_path.iterdir()) and not multiprocessing.active_children()


def test_pool_rejects_expired_inherited_deadline_before_any_new_task(tmp_path):
    from padml import runtime
    report = {}
    with pytest.raises(ContractError, match="BOUNDED_SPAWN_DEADLINES_INVALID"):
        _bounded_ordered_spawn(_mark_started_task, [(i, str(tmp_path)) for i in range(2)],
            selected_slots=1, task_deadlines=[None, time.monotonic() + runtime._TASK_DEADLINE_SECONDS + 1])
    with pytest.raises(ContractError, match="BOUNDED_SPAWN_TASK_DEADLINE_EXCEEDED"):
        _bounded_ordered_spawn(_mark_started_task, [(i, str(tmp_path)) for i in range(2)],
            selected_slots=1, task_deadlines=[None, time.monotonic() - 1], execution_report=report)
    assert report["status"] == "FAILED" and report["actual_worker_process_peak"] == 0
    assert not list(tmp_path.iterdir()) and not multiprocessing.active_children()


@pytest.mark.parametrize("phase", ["READY", "REFILL", "PENDING", "LATE_OK", "LATE_LAST"])
def test_pool_checks_inherited_deadlines_at_dispatch_and_while_pending(tmp_path, monkeypatch, phase):
    from padml import runtime
    original_wait = runtime.wait_connections
    now = time.monotonic()
    deadlines = ([now + 20] if phase == "LATE_LAST" else
                 [now + 20, None] if phase == "LATE_OK" else [None, now + 20])
    advanced = False
    def clock():
        return now + (21 if advanced else 0)
    def advance_after_observation(connections, timeout):
        nonlocal advanced
        ready = original_wait(connections, timeout)
        if (phase == "READY" and ready and deadlines[0] is None
                or phase in {"REFILL", "LATE_OK", "LATE_LAST"} and ready and (tmp_path / "0.started").is_file()
                or phase == "PENDING" and deadlines[0] is not None and (tmp_path / "0.started").is_file()):
            advanced = True
        return [] if phase == "PENDING" and advanced else ready
    monkeypatch.setattr(runtime, "monotonic", clock)
    monkeypatch.setattr(runtime, "wait_connections", advance_after_observation)
    report = {}
    with pytest.raises(ContractError, match="BOUNDED_SPAWN_TASK_DEADLINE_EXCEEDED"):
        _bounded_ordered_spawn(_mark_started_task, [(i, str(tmp_path)) for i in range(len(deadlines))],
            selected_slots=1, task_deadlines=deadlines, execution_report=report)
    assert not (tmp_path / "1.started").exists()
    assert (tmp_path / "0.started").exists() is (phase != "READY")
    assert report["status"] == "FAILED" and report["actual_worker_process_peak"] == 1
    if phase in {"LATE_OK", "LATE_LAST"}:
        assert report["completed_task_count"] == 0
    assert not multiprocessing.active_children()


def _invalid_group_start_entry(worker, connection, capture_release=False):
    connection.send({"status": "READY", "process_group": os.getpid() + 1})
    connection.recv()


@pytest.mark.parametrize("cause", ["timeout", "process_group"])
def test_pool_rejects_unacknowledged_startup_without_sending_tasks(tmp_path, monkeypatch, cause):
    from padml import runtime
    monkeypatch.setattr(runtime, "effective_cpu_count", lambda: 32)
    if cause == "timeout":
        monkeypatch.setattr(runtime, "_spawn_task_entry", _unready_start_entry)
        # Scale only the coordinator's clock, preserving the production
        # thirty-second timeout without making this no-task check wait for it.
        monkeypatch.setattr(runtime, "monotonic", lambda: time.monotonic() * 1000)
        reason = "BOUNDED_SPAWN_STARTUP_TIMEOUT"
    else:
        monkeypatch.setattr(runtime, "_spawn_task_entry", _invalid_group_start_entry)
        reason = "BOUNDED_SPAWN_PROCESS_GROUP_INVALID"
    with pytest.raises(ContractError, match=reason):
        _bounded_ordered_spawn(_mark_started_task, [(i, str(tmp_path)) for i in range(2)], selected_slots=2)
    assert list(tmp_path.iterdir()) == []
    assert not multiprocessing.active_children()


def _paired_completion_task(task):
    index, directory = task
    root = Path(directory)
    (root / f"{index}.started").write_bytes(b"UNFITTED task only")
    deadline = time.monotonic() + 5
    while len(list(root.glob("*.started"))) != 2 and time.monotonic() < deadline:
        time.sleep(.01)
    assert len(list(root.glob("*.started"))) == 2
    if index == 1:
        raise ValueError("UNFITTED later ready failure")
    return index


def test_pool_keeps_earlier_success_callback_when_same_ready_batch_contains_failure(tmp_path, monkeypatch):
    from padml import runtime
    original_wait = runtime.wait_connections
    def both_completed(connections, timeout):
        ready = original_wait(connections, timeout)
        if len(list(tmp_path.glob("*.started"))) == 2 and len(connections) == 2:
            assert all(connection.poll(5) for connection in connections)
            return connections
        return ready
    monkeypatch.setattr(runtime, "wait_connections", both_completed)
    monkeypatch.setattr(runtime, "effective_cpu_count", lambda: 32)
    arrivals = []
    with pytest.raises(ContractError, match="UNFITTED later ready failure"):
        _bounded_ordered_spawn(_paired_completion_task, [(i, str(tmp_path)) for i in range(2)],
                               selected_slots=2, on_result=lambda index, result: arrivals.append(index))
    assert arrivals == [0]
    assert not multiprocessing.active_children()


def _failing_task(task: int) -> int:
    if task == 0:
        raise ValueError("fixture failure")
    time.sleep(0.2)
    return task


def _noted_failure_task(path: str) -> None:
    evidence = Path(path)
    evidence.write_bytes(b"UNFITTED original worker diagnostic")
    error = ContractError("UNFITTED worker failure")
    error.add_note(f"UNFITTED_EVIDENCE_RETAINED:{evidence.parent}")
    error.add_note("UNFITTED second note")
    raise error


def test_pool_preserves_worker_failure_evidence_notes(tmp_path, monkeypatch):
    monkeypatch.setattr("padml.runtime.effective_cpu_count", lambda: 32)
    evidence = tmp_path / "UNFITTED-stderr.txt"
    with pytest.raises(ContractError, match="BOUNDED_SPAWN_CHILD_FAILED") as captured:
        _bounded_ordered_spawn(_noted_failure_task, [str(evidence)], selected_slots=1)
    assert str(captured.value).endswith(
        f"UNFITTED worker failure\nUNFITTED_EVIDENCE_RETAINED:{tmp_path}\nUNFITTED second note")
    assert evidence.read_bytes() == b"UNFITTED original worker diagnostic"
    assert not multiprocessing.active_children()


def _crashing_task(task: int) -> int:
    if task == 0:
        os._exit(9)
    time.sleep(0.2)
    return task


class _WorkerLifetimeResult(dict):
    pass


_previous_worker_result = None


def _worker_result_lifetime_task(index):
    global _previous_worker_result
    assert _previous_worker_result is None or _previous_worker_result() is None, (
        "UNFITTED previous worker result still retained at next task"
    )
    result = _WorkerLifetimeResult(index=index, pid=os.getpid())
    _previous_worker_result = weakref.ref(result)
    return result


def test_reused_worker_releases_previous_result_before_next_task(monkeypatch):
    monkeypatch.setattr("padml.runtime.effective_cpu_count", lambda: 32)
    consumed = []
    results = _bounded_ordered_spawn(
        _worker_result_lifetime_task, list(range(3)), selected_slots=1,
        on_result=lambda index, result: consumed.append((index, result["index"])),
    )
    assert [result["index"] for result in results] == list(range(3))
    assert consumed == [(index, index) for index in range(3)]
    assert len({result["pid"] for result in results}) == 1
    assert not multiprocessing.active_children()


def test_result_release_observation_preserves_callback_and_waits_for_owned_workers(monkeypatch):
    from padml.runtime import validate_resource_release
    monkeypatch.setattr("padml.runtime.effective_cpu_count", lambda: 32)
    releases, pool, consumed = {}, {}, []
    results = _bounded_ordered_spawn(_worker_result_lifetime_task, list(range(3)), selected_slots=1,
        on_result=lambda index, result: consumed.append((index, result["index"])),
        execution_report=pool, resource_release_report=releases)
    assert consumed == [(index, index) for index in range(3)]
    assert [result["index"] for result in results] == list(range(3))
    assert len(pool) == 7 and pool["status"] == "COMPLETED"
    assert set(releases) == {"0", "1", "2"}
    for index, result in enumerate(results):
        report = releases[str(index)]
        validate_resource_release(report)
        assert report["owner"] == f"POOL_TASK_RESULT:{index}"
        assert report["after"]["pid"] == result["pid"] != os.getpid()
        assert report["files"] == []
        assert report["released_references"] == ["serialized_result", "task", "received_message"]
    assert not multiprocessing.active_children()


class _LateEncodingResult(dict):
    def __reduce_ex__(self, protocol):
        from padml.runtime import observe_step_memory
        before = observe_step_memory()
        payload_bytes = max(96 * 1024**2, before["lifetime_maxrss"]["self_bytes"] + 16 * 1024**2)
        assert payload_bytes <= 512 * 1024**2, "Late-encoding fixture exceeds its 512 MiB allocation bound"
        encoded = {**self, "payload_bytes": payload_bytes, "payload": b"x" * payload_bytes}
        encoded["encoding_memory"] = observe_step_memory()
        return dict, (encoded,)


def _late_encoding_task(index):
    from padml.runtime import observe_step_memory
    return _LateEncodingResult(index=index, pid=os.getpid(), task_memory=observe_step_memory())


@pytest.mark.skipif(__import__("sys").platform != "linux", reason="Linux getrusage identity reader")
def test_worker_maxrss_is_after_scientific_result_encoding(monkeypatch):
    from padml.runtime import validate_resource_release
    monkeypatch.setattr("padml.runtime.effective_cpu_count", lambda: 32)
    consumed, releases = [], {}
    results = _bounded_ordered_spawn(_late_encoding_task, [0], selected_slots=1,
        on_result=lambda index, result: consumed.append((index, len(result["payload"]))),
        resource_release_report=releases)
    result, release = results[0], releases["0"]
    assert consumed == [(0, result["payload_bytes"])] and result["index"] == 0
    assert 96 * 1024**2 <= result["payload_bytes"] <= 512 * 1024**2
    validate_resource_release(release)
    task_peak = result["task_memory"]["lifetime_maxrss"]
    encoding_peak = result["encoding_memory"]["lifetime_maxrss"]
    assert encoding_peak["self_bytes"] > task_peak["self_bytes"]
    for side in ("before", "after"):
        snapshot = release[side]
        assert snapshot["pid"] == result["pid"] != os.getpid()
        assert snapshot["started_ns"] > result["encoding_memory"]["finished_ns"]
        assert snapshot["lifetime_maxrss"]["process_start_ticks"] == encoding_peak["process_start_ticks"]
        assert snapshot["lifetime_maxrss"]["self_bytes"] >= encoding_peak["self_bytes"]
    assert not multiprocessing.active_children()


class _ExitAfterScientificResult(dict):
    def __del__(self):
        if self.get("pid") == os.getpid():
            os._exit(17)


class _PartialReleaseConnection:
    def __init__(self, connection):
        self.connection = connection

    def send(self, value):
        if isinstance(value, dict) and value.get("status") == "RELEASED" and value["index"] == 0:
            import struct
            os.write(self.connection.fileno(), struct.pack("!i", 64) + b"x")
            os._exit(18)
        self.connection.send(value)

    def recv(self):
        return self.connection.recv()

    def close(self):
        self.connection.close()


def _partial_release_entry(worker, connection, capture_release=False):
    _spawn_task_entry(worker, _PartialReleaseConnection(connection), capture_release)


class _WaitForPeerCallbackConnection(_PartialReleaseConnection):
    def send(self, value):
        if isinstance(value, dict) and value.get("status") == "RELEASED" and value["index"] == 0:
            marker = Path(os.environ["PADML_UNFITTED_RELEASE_ROOT"]) / "peer-callback"
            end = time.monotonic() + 5
            while not marker.exists() and time.monotonic() < end:
                time.sleep(.01)
            assert marker.exists(), "post-send diagnostics blocked peer callback"
        self.connection.send(value)


def _wait_for_peer_callback_entry(worker, connection, capture_release=False):
    _spawn_task_entry(worker, _WaitForPeerCallbackConnection(connection), capture_release)


def _ordered_callback_task(index):
    if index == 1:
        marker = Path(os.environ["PADML_UNFITTED_RELEASE_ROOT"]) / "first-callback"
        end = time.monotonic() + 5
        while not marker.exists() and time.monotonic() < end:
            time.sleep(.01)
        assert marker.exists()
    return {"index": index}


def test_waiting_release_does_not_block_other_scientific_callbacks(tmp_path, monkeypatch):
    from padml import runtime
    monkeypatch.setenv("PADML_UNFITTED_RELEASE_ROOT", str(tmp_path))
    monkeypatch.setattr(runtime, "effective_cpu_count", lambda: 32)
    monkeypatch.setattr(runtime, "_spawn_task_entry", _wait_for_peer_callback_entry)
    receipts, releases, report = [], {}, {}
    def callback(index, result):
        receipts.append(index)
        (tmp_path / ("first-callback" if index == 0 else "peer-callback")).touch()
    results = _bounded_ordered_spawn(_ordered_callback_task, [0, 1], selected_slots=2,
        on_result=callback, execution_report=report, resource_release_report=releases)
    assert receipts == [0, 1] and results == [{"index": 0}, {"index": 1}]
    assert report["status"] == "COMPLETED" and set(releases) == {"0", "1"}
    for release in releases.values():
        runtime.validate_resource_release(release)
        assert "before" in release
    assert not multiprocessing.active_children()


def _result_then_diagnostic_loss_task(task):
    index, path, loss = task
    if index:
        marker = Path(path).parent / "UNFITTED-release-observed"
        end = time.monotonic() + 10
        while not marker.exists() and time.monotonic() < end:
            time.sleep(.01)
        assert marker.exists(), "parent did not record UNKNOWN before peer completion"
    Path(path).write_text(f"UNFITTED completed once: {index}")
    result = {"index": index, "pid": os.getpid()}
    return _ExitAfterScientificResult(result) if index == 0 and loss == "eof" else result


@pytest.mark.parametrize("count,slots", [(1, 1), (3, 2)])
@pytest.mark.parametrize("loss", ["eof", "partial-frame"])
def test_missing_postsend_diagnostic_keeps_science_and_refills_reaped_slot(tmp_path, monkeypatch, count, slots, loss):
    from padml import runtime
    monkeypatch.setattr("padml.runtime.effective_cpu_count", lambda: 32)
    if loss == "partial-frame":
        monkeypatch.setattr(runtime, "_spawn_task_entry", _partial_release_entry)
    releases, report, receipts = {}, {}, []
    now = time.monotonic()
    deadlines = [now + 100] * count
    # UNKNOWN concerns only cache diagnostics. Completed science is retained;
    # a confirmed exited worker may be replaced within the original ceiling.
    # Every coordinate keeps its original unexpired deadline during recovery.
    def clock():
        unknown = releases.get("0", {}).get("status") == "UNKNOWN"
        if unknown:
            (tmp_path / "UNFITTED-release-observed").touch()
        return now + (21 if unknown else 0)
    monkeypatch.setattr(runtime, "monotonic", clock)
    paths = [tmp_path / f"UNFITTED-{index}.txt" for index in range(count)]
    def run():
        return _bounded_ordered_spawn(_result_then_diagnostic_loss_task,
            [(index, str(path), loss) for index, path in enumerate(paths)], selected_slots=slots,
            on_result=lambda index, row: receipts.append((index, row["index"])),
            execution_report=report, resource_release_report=releases, task_deadlines=deadlines)
    results = run()
    assert [row["index"] for row in results] == list(range(count))
    assert report["status"] == "COMPLETED"
    assert report["completed_task_count"] == count
    assert report["actual_worker_process_peak"] <= slots
    assert sorted(receipts) == [(index, index) for index in range(count)]
    assert releases["0"]["status"] == "UNKNOWN"
    assert all(paths[index].read_text() == f"UNFITTED completed once: {index}" for index in range(count))
    assert not multiprocessing.active_children()


@pytest.mark.parametrize("pool_workers", [24, 56])
def test_pool_reuses_processes_and_preserves_seed_and_result_order(pool_workers) -> None:
    tasks = [(index, 0.003 * (index % 3)) for index in range(72)]
    arrivals = []
    results = _bounded_ordered_spawn(
        _seeded_task, tasks, selected_slots=pool_workers,
        on_result=lambda index, result: arrivals.append((index, result["seed"])),
    )
    assert [row["seed"] for row in results] == list(range(72))
    assert [row["value"] for row in results] == [random.Random(index).random() for index in range(72)]
    assert all(row["threads"] == THREAD_ENV for row in results)
    assert len({row["pid"] for row in results}) == pool_workers
    assert len(results) > len({row["pid"] for row in results})
    assert sorted(arrivals) == [(index, index) for index in range(72)]
    assert not multiprocessing.active_children()


@pytest.mark.parametrize("pool_workers", [0, -1, True, 24.0])
def test_pool_rejects_invalid_capacity_without_spawning(pool_workers) -> None:
    with pytest.raises(ContractError, match="BOUNDED_SPAWN_INPUT_INVALID"):
        _bounded_ordered_spawn(_seeded_task, [(1, 0)], selected_slots=pool_workers)
    assert not multiprocessing.active_children()


@pytest.mark.parametrize("worker", [_failing_task, _crashing_task])
def test_pool_failures_reap_every_child(worker) -> None:
    with pytest.raises(ContractError, match="BOUNDED_SPAWN_CHILD_FAILED"):
        _bounded_ordered_spawn(worker, list(range(30)), selected_slots=24)
    assert not multiprocessing.active_children()


def test_callback_failure_reaps_every_child() -> None:
    def fail_callback(index: int, value: dict) -> None:
        raise RuntimeError("fixture callback failure")
    with pytest.raises(RuntimeError, match="fixture callback failure"):
        _bounded_ordered_spawn(_seeded_task, [(1, 0.01)] * 30, selected_slots=24, on_result=fail_callback)
    assert not multiprocessing.active_children()


def _native_descendant_task(task: tuple[str, str]) -> int:
    mode, path = task
    if mode == "native":
        subprocess.run([shutil.which("Rscript"), "-e",
                        'writeLines(as.character(Sys.getpid()), commandArgs(TRUE)[1L]); Sys.sleep(30)', path],
                       capture_output=True, text=True, check=True, timeout=35)
        return 0
    deadline=time.monotonic()+10
    while not Path(path).is_file() and time.monotonic()<deadline:
        time.sleep(.01)
    assert Path(path).is_file(), "native R child did not start"
    if mode == "error":
        raise ValueError("owned native cancellation fixture")
    return 1


def _pid_exists(pid: int) -> bool:
    try:
        os.kill(pid,0)
        return True
    except ProcessLookupError:
        return False


@pytest.mark.parametrize("cause", ["error","callback","timeout"])
def test_pool_failure_reaps_owned_r_grandchild_but_preserves_unrelated_r(tmp_path,monkeypatch,cause):
    from padml import runtime
    rscript=shutil.which("Rscript")
    assert rscript is not None, "Real R grandchild regression is required"
    path=tmp_path/"native.pid"
    unrelated=subprocess.Popen([rscript,"-e","Sys.sleep(30)"],start_new_session=True,
                               stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    native_pid=None
    try:
        callback=None
        expected=ContractError
        if cause=="timeout":
            monkeypatch.setattr(runtime,"_TASK_DEADLINE_SECONDS",2)
        if cause=="callback":
            expected=RuntimeError
            def callback(index,result):
                raise RuntimeError("owned native callback fixture")
        with pytest.raises(expected):
            _bounded_ordered_spawn(_native_descendant_task,
                [("native",str(path)),("error" if cause=="error" else "complete",str(path))],
                selected_slots=24,on_result=callback)
        native_pid=int(path.read_text().strip())
        assert not multiprocessing.active_children()
        assert not _pid_exists(native_pid), "R grandchild survived or remained unreaped"
        assert unrelated.poll() is None, "Cancellation killed an unrelated R process"
    finally:
        # Only this isolated regression owns these PIDs.
        if native_pid is None and path.is_file():
            native_pid=int(path.read_text().strip())
        if native_pid is not None and _pid_exists(native_pid):
            os.kill(native_pid,signal.SIGKILL)
        if unrelated.poll() is None:
            unrelated.terminate()
        unrelated.wait(timeout=5)


def _native_model_task(task: tuple[str, int]) -> dict:
    import numpy as np
    from padml._science_authority import load_science_authority
    from padml.bundle import canonical_json_bytes, sha256_bytes
    from padml.f2_kernel import _coxtime_refit_predict, _xgb_refit_predict

    family, seed = task
    rng = np.random.default_rng(20260903)
    design = rng.normal(size=(96, 3))
    times = rng.uniform(2, 60, size=80)
    events = (rng.uniform(size=80) > 0.3).astype(int)
    if family == "XGBOOST_COX":
        import xgboost as xgb
        parameters = {
            "eta": 0.05, "max_depth": 2, "min_child_weight": 2.0,
            "subsample": 0.8, "colsample_bytree": 0.8, "reg_lambda": 1.0,
            "reg_alpha": 0.0, "gamma": 0.0, "tree_method": "hist",
            "max_bin": 256, "max_nrounds": 40,
        }
        result = _xgb_refit_predict(xgb, parameters, design[:80], times, events, design[80:], 40, seed, "CPU", list(range(1, 37)), np)
    else:
        from pycox import models
        import torch
        import torchtuples as tt
        candidate = load_science_authority()["science"]["f2_model_development"]["coxtime"]["candidates"][0]
        result = _coxtime_refit_predict((models, torch, tt), candidate, design[:80], times, events, design[80:], 30, seed, "CPU", list(range(1, 37)), np)
    return {
        "prediction_sha256": sha256_bytes(canonical_json_bytes(result["survival"].tolist())),
        "fit_health": result["fit_health"],
    }


def _native_sequence(family: str, seeds: list[int]) -> list[dict]:
    context = multiprocessing.get_context("spawn")
    parent, child = context.Pipe()
    process = context.Process(target=_spawn_task_entry, args=(_native_model_task, child))
    process.start()
    child.close()
    results = []
    try:
        assert parent.poll(30)
        assert parent.recv() == {"status": "READY", "process_group": process.pid}
        for index, seed in enumerate(seeds):
            parent.send((index, (family, seed), time.monotonic() + 60))
            assert parent.poll(60), "native numeric fixture timed out"
            result = parent.recv()
            assert result["status"] == "OK", result
            results.append(result["result"])
        parent.send(None)
        process.join(timeout=5)
        assert process.exitcode == 0
    finally:
        parent.close()
        if process.is_alive():
            process.terminate()
            process.join(timeout=5)
        process.close()
    return results


@pytest.mark.parametrize("family", ["XGBOOST_COX", "COXTIME_SET_A"])
def test_native_model_bytes_match_fresh_and_reused_processes(family: str) -> None:
    reused = _native_sequence(family, [310101, 310102, 310101])
    fresh = _native_sequence(family, [310101])
    assert reused[0] == reused[2] == fresh[0]


def _final_reuse_miss_task(value):
    function, item = value
    return function(item)


def test_original_pool_transports_final_reuse_misses_without_native_objects(tmp_path):
    from padml import f5, f5_sensitivity as a
    from padml.bundle import canonical_json_bytes, sha256_bytes, write_deterministic_zip
    root = tmp_path.resolve()
    raw = canonical_json_bytes({"reused_final": True})
    member = "fits/O1_FIXTURE_M01.numbers.json"
    write_deterministic_zip(root / "result.zip", {member: raw})
    jobs = [
        (f5._f45_primary_final_reuse_job, dict(request={}, lock={}, root=root, job={},
            binding={"imputation": 1}, candidate=root, metadata={}, first={"components": [{"reused_final": True}]})),
        (f5._f45_full_final_reuse_job, dict(plan={}, job=(root / "input.zip", root / "output.zip", {}, {"imputation": 1}, {}),
            binding={}, candidate=root, previous={}, location=root / "source.json", receipt={"artifacts": {
                "final-result/F5_FINAL_FULL_DATA_M01.zip": {"size_bytes": 1, "sha256": "a" * 64}}})),
        (a._a12_final_reuse_job, dict(source={}, root=root, job={"name": "O1_FIXTURE_M01", "root": str(root / "unused")},
            binding={}, candidate=root, location=root / "source.json", result={"members": {
                member: {"size_bytes": len(raw), "sha256": sha256_bytes(raw)}}})),
    ]
    result = _bounded_ordered_spawn(_final_reuse_miss_task, jobs, selected_slots=2, schedule_order=[2, 0, 1])
    assert result == [{"numbers": None}] * 3
    assert list(root.iterdir()) == [root / "result.zip"]
    assert not multiprocessing.active_children()


from threading import Barrier
from unittest.mock import patch
from padml import runtime as _ready_runtime
from padml.runtime import run_ready_families as _run_ready_families


@pytest.fixture
def ready_family_host(monkeypatch):
    # This is a scheduler fixture, not a scientific or host acceptance claim.
    monkeypatch.setattr(_ready_runtime, "effective_cpu_count", lambda: 32)
    monkeypatch.setattr(_ready_runtime, "_available_memory_bytes", lambda: 16*1024**3)


def _ready_family_task(task):
    start=time.monotonic()
    if task.get('nested'):
        try:
            _ready_runtime._bounded_ordered_spawn(_ready_family_task,[{}],selected_slots=1)
        except _ready_runtime.ContractError as error:
            return {'nested':str(error)}
        raise AssertionError('nested pool was allowed')
    time.sleep(task.get('delay',0))
    if task.get('fail'):
        raise ValueError('intentional-draft-_ready_family_task-failure')
    return {'value':task['value']*3,'start':start,'end':time.monotonic(),'pid':os.getpid(),
        'threads':os.environ['OMP_NUM_THREADS'],'in_scientific_pool':_ready_runtime._IN_SCIENTIFIC_POOL}


def _ready_family_policy():
    return {'configured_worker_ceiling':_ready_runtime.CPU_MINUS_8,'memory_bytes_per_worker':2*1024**3,
        'scratch_bytes_per_worker':1024,'memory_reserve_bytes':0,'scratch_reserve_bytes':0,
        'transfer_archive_worker_ceiling':24}


def _ready_family_phase(root,tasks, report=None):
    admitted=_ready_runtime.admit_stage(_ready_family_policy(),root,legal_tasks=len(tasks),retained_bytes=1024,
        publication_bytes=1024,transient_bytes_per_worker=1024)
    return _ready_runtime._bounded_ordered_spawn(_ready_family_task,tasks,selected_slots=min(2,admitted['admitted_worker_ceiling']),
        execution_report=report)


def test_ready_family_refill_preserves_barriers_and_canonical_results(tmp_path, ready_family_host):
    root=tmp_path.resolve()
    reports=[]
    def first():
        r={}; reports.append(r)
        one=_ready_family_phase(root,[{'value':i,'delay':d} for i,d in enumerate([.7,.1,.1])],r)
        two=_ready_family_phase(root,[{'value':i+10,'delay':.01} for i in range(2)])
        return one,two
    def second():
        one=_ready_family_phase(root,[{'value':i+20,'delay':.04} for i in range(8)])
        two=_ready_family_phase(root,[{'value':i+30,'delay':.01} for i in range(2)])
        return one,two
    record={}
    rows=_run_ready_families([first,second],policy=_ready_family_policy(),root=root,workers=2,report=record)
    a1,a2=rows[0]; b1,b2=rows[1]
    assert [r['value'] for r in a1]==[0,3,6]
    assert [r['value'] for r in b1]==[60+i*3 for i in range(8)]
    assert min(r['start'] for r in b1)<max(r['end'] for r in a1)
    assert min(r['start'] for r in a2)>=max(r['end'] for r in a1)
    assert min(r['start'] for r in b2)>=max(r['end'] for r in b1)
    assert record['worker_process_peak']==2
    assert 2 <= len(set(record['worker_pids'])) <= len(a1+a2+b1+b2)
    assert all(r['threads']=='1' and r['in_scientific_pool'] for group in rows for stage in group for r in stage)
    assert reports[0]['completed_task_count']==3 and reports[0]['status']=='COMPLETED'
    print('PASS: cross-family refill, per-family barriers, canonical reductions, persistent two-PID pool, thread=1')


def test_ready_family_failure_reaps_all_owned_workers(tmp_path, ready_family_host):
    root=tmp_path.resolve()
    record={}
    def first(): return _ready_family_phase(root,[{'value':1,'delay':.05,'fail':True}])
    def second(): return _ready_family_phase(root,[{'value':2,'delay':4}])
    started=time.monotonic()
    try:
        _run_ready_families([first,second],policy=_ready_family_policy(),root=root,workers=2,report=record)
    except _ready_runtime.ContractError as error:
        assert 'intentional-draft-_ready_family_task-failure' in str(error)
    else: raise AssertionError('error not propagated')
    assert time.monotonic()-started<3
    assert record['status']=='FAILED'
    for pid in record['worker_pids']:
        try: os.kill(pid,0)
        except ProcessLookupError: pass
        else: raise AssertionError(f'worker survived {pid}')
    print('PASS: any-family error cancels pending/inflight work and reaps all owned PIDs')


def test_ready_family_leaf_cannot_start_another_pool(tmp_path, ready_family_host):
    root=tmp_path.resolve()
    def first(): return _ready_family_phase(root,[{'nested':True}])
    result=_run_ready_families([first],policy=_ready_family_policy(),root=root,workers=1)
    assert result[0][0]['nested']=='NESTED_SCIENTIFIC_POOL_FORBIDDEN'
    print('PASS: scientific children cannot create another pool')


def test_ready_family_budget_defers_unaffordable_peer_stage(tmp_path, ready_family_host):
    root=tmp_path.resolve()
    observations=[]
    base_observe=_ready_runtime.observe_execution_resources
    def observe(path):
        return {**base_observe(path),'scratch_available_bytes':100_000}
    barrier=Barrier(2)
    def call(value):
        barrier.wait()
        admitted=_ready_runtime.admit_stage(_ready_family_policy(),root,legal_tasks=1,retained_bytes=60_000,
            publication_bytes=0,transient_bytes_per_worker=1024)
        results=_ready_runtime._bounded_ordered_spawn(_ready_family_task,[{'value':value,'delay':.15}],selected_slots=2)
        observations.append(admitted)
        return results
    with patch.object(_ready_runtime,'observe_execution_resources',observe):
        rows=_run_ready_families([lambda:call(1),lambda:call(2)],policy=_ready_family_policy(),root=root,workers=2)
    a,b=sorted([rows[0][0],rows[1][0]],key=lambda r:r['start'])
    assert b['start']>=a['end'] and all(o['disk_peak']['future_retained_bytes']==60_000 for o in observations)
    print('PASS: aggregate retained/publication budget defers a second family until the first stage releases')


def test_ready_family_deadline_cancels_owned_pool(tmp_path, ready_family_host):
    root=tmp_path.resolve()
    def call():
        _ready_runtime.admit_stage(_ready_family_policy(),root,legal_tasks=1,retained_bytes=0,publication_bytes=0,
            transient_bytes_per_worker=1024)
        return _ready_runtime._bounded_ordered_spawn(_ready_family_task,[{'value':1,'delay':2}],selected_slots=1,
            task_timeout_seconds=.3)
    started=time.monotonic()
    try: _run_ready_families([call],policy=_ready_family_policy(),root=root,workers=1)
    except _ready_runtime.ContractError as error:
        assert str(error)=='BOUNDED_SPAWN_TASK_DEADLINE_EXCEEDED'
    else: raise AssertionError('deadline did not cancel')
    assert time.monotonic()-started<1.5
    print('PASS: task deadline cancels the one owned pool')


def _ready_family_diagnostic_entry(worker,connection,capture_release):
    _ready_runtime._IN_SCIENTIFIC_POOL=True
    os.setsid(); os.environ.update(_ready_runtime.THREAD_ENV)
    connection.send({'status':'READY','process_group':os.getpgrp()})
    try:
        while True:
            message=connection.recv()
            if message is None:return
            index,task,deadline=message
            result=worker(task)
            connection.send({'status':'OK','index':index,'result':result})
            mode=task[1].get('release_mode')
            if mode=='eof':return
            release={} if mode=='malformed' else {'status':'UNKNOWN',
                'owner':f'POOL_TASK_RESULT:{index}','pid':os.getpid(),'reason':'fixture'}
            connection.send({'status':'RELEASED','index':index,'resource_release':release})
    finally:connection.close()


def test_ready_family_completed_result_survives_lost_release(tmp_path, ready_family_host):
    root=tmp_path.resolve()
    releases={}; record={}
    def call():
        _ready_runtime.admit_stage(_ready_family_policy(),root,legal_tasks=3,retained_bytes=0,publication_bytes=0,
            transient_bytes_per_worker=1024)
        return _ready_runtime._bounded_ordered_spawn(_ready_family_task,[{'value':1,'release_mode':'malformed'},
            {'value':2,'release_mode':'eof'},{'value':3}],selected_slots=1,resource_release_report=releases)
    with patch.object(_ready_runtime,'_spawn_task_entry',_ready_family_diagnostic_entry):
        rows=_run_ready_families([call],policy=_ready_family_policy(),root=root,workers=1,report=record)
    assert [r['value'] for r in rows[0]]==[3,6,9]
    assert releases['0']['status']==releases['1']['status']=='UNKNOWN'
    assert record['worker_process_peak']==1 and len(record['worker_pids'])==2
    print('PASS: retained OK survives bad/EOF release diagnostics; only the exited slot is replaced')



def _ready_family_cache_probe(task):
    from padml import runtime, f2_kernel as kernel
    # Small inert values exercise the actual worker LRU, without fitting.
    scope = runtime._READY_PREPARATION_SCOPE
    key = (scope, task["key"])
    hit = key in kernel._PYTHON_PREPARED
    if not hit:
        kernel._PYTHON_PREPARED[key] = ({"fixture": task["key"]}, 8)
        kernel._PYTHON_PREPARED_BYTES += 8
    time.sleep(.01)
    return {"scope": scope, "hit": hit, "pid": os.getpid(),
        "live": sorted({key[0] for key in kernel._PYTHON_PREPARED}),
        "bytes": kernel._PYTHON_PREPARED_BYTES}


def test_ready_family_stage_cache_keeps_live_peer_and_releases_old_scope(tmp_path, ready_family_host):
    from threading import Barrier
    barrier = Barrier(2)
    def phase(name, count):
        _ready_runtime.admit_stage(_ready_family_policy(), tmp_path, legal_tasks=count,
            retained_bytes=0, publication_bytes=0, transient_bytes_per_worker=1024)
        return _ready_runtime._bounded_ordered_spawn(_ready_family_cache_probe,
            [{"key": name} for _ in range(count)], selected_slots=1)
    def first():
        barrier.wait()
        return phase("a", 3), phase("a", 1)
    def second():
        barrier.wait()
        return phase("b", 8)
    record = {}
    first_result, peer = _run_ready_families([first, second], policy=_ready_family_policy(),
        root=tmp_path, workers=1, report=record)
    old, new = first_result
    assert [r["hit"] for r in old] == [False, True, True]
    assert [r["hit"] for r in peer] == [False] + [True] * 7
    assert new[0]["hit"] is False and new[0]["scope"] != old[0]["scope"]
    assert old[0]["scope"] not in new[0]["live"]
    assert all(r["bytes"] == 8 * len(r["live"]) for r in [*old, *new, *peer])
    assert record["worker_process_peak"] == len(record["worker_pids"]) == 1
    assert not multiprocessing.active_children()


_READY_RELEASE_ENTRY = _ready_runtime._spawn_task_entry

_READY_RELEASE_DELAY = 1.1

_READY_RELEASE_FINISHED = None

def _ready_slow_release_entry(worker, connection, capture_release):
    def release(files, *, owner, **kwargs):
        global _READY_RELEASE_FINISHED
        time.sleep(_READY_RELEASE_DELAY)
        _READY_RELEASE_FINISHED = time.monotonic()
        return {"status": "UNKNOWN", "owner": owner, "pid": os.getpid(),
                "reason": "isolated deliberately delayed release observation"}

    # Cache observation is the only injected operation. OK/RELEASED transport,
    # worker identity, cancellation and task dispatch use production code.
    _ready_runtime.release_step_resources = release
    _READY_RELEASE_ENTRY(worker, connection, capture_release)

def _ready_release_task(task):
    started = time.monotonic()
    time.sleep(task["delay"])
    return {"value": task["value"], "pid": os.getpid(), "start": started,
            "end": time.monotonic(), "deadline": _ready_runtime._ACTIVE_TASK_DEADLINE,
            "previous_release_finished": _READY_RELEASE_FINISHED}

def test_ok_before_deadline_allows_late_release_and_same_slot_refill(tmp_path, monkeypatch, ready_family_host):
    releases, report, arrivals = {}, {}, []
    deadlines = [None, None]
    monkeypatch.setattr(_ready_runtime, "_spawn_task_entry", _ready_slow_release_entry)

    def family():
        _ready_runtime.admit_stage(_ready_family_policy(), tmp_path, legal_tasks=2, retained_bytes=0,
                            publication_bytes=0, transient_bytes_per_worker=1024)
        return _ready_runtime._bounded_ordered_spawn(
            _ready_release_task, [{"value": 1, "delay": .01}, {"value": 2, "delay": .01}],
            selected_slots=1, task_timeout_seconds=.8, task_deadlines=deadlines,
            resource_release_report=releases,
            on_result=lambda index, row: arrivals.append((index, time.monotonic())))

    rows, = _ready_runtime.run_ready_families([family], policy=_ready_family_policy(), root=tmp_path,
                                      workers=1, report=report)
    assert [row["value"] for row in rows] == [1, 2]
    assert [index for index, _ in arrivals] == [0, 1]
    assert all(arrived < deadlines[index] for index, arrived in arrivals)
    assert all(row["end"] < row["deadline"] for row in rows)
    assert rows[1]["previous_release_finished"] > deadlines[0]
    assert rows[1]["start"] >= rows[1]["previous_release_finished"]
    assert rows[0]["pid"] == rows[1]["pid"]
    assert report["worker_process_peak"] == len(report["worker_pids"]) == 1
    assert report["status"] == "COMPLETED"
    assert set(releases) == {"0", "1"}
    assert all(row["status"] == "UNKNOWN" for row in releases.values())
    assert not multiprocessing.active_children()

def test_unfinished_scientific_task_still_expires_and_cancels_pending_refill(tmp_path, ready_family_host):
    arrivals, report = [], {}

    def family():
        _ready_runtime.admit_stage(_ready_family_policy(), tmp_path, legal_tasks=2, retained_bytes=0,
                            publication_bytes=0, transient_bytes_per_worker=1024)
        return _ready_runtime._bounded_ordered_spawn(
            _ready_release_task, [{"value": 1, "delay": 2}, {"value": 2, "delay": 0}],
            selected_slots=1, task_timeout_seconds=.25,
            on_result=lambda index, row: arrivals.append((index, row)))

    with pytest.raises(_ready_runtime.ContractError, match="^BOUNDED_SPAWN_TASK_DEADLINE_EXCEEDED$"):
        _ready_runtime.run_ready_families([family], policy=_ready_family_policy(), root=tmp_path,
                                   workers=1, report=report)
    assert arrivals == []
    assert report["status"] == "FAILED"
    assert report["worker_process_peak"] == len(report["worker_pids"]) == 1
    assert not multiprocessing.active_children()


def _cleanup_fault_owned_task(task):
    index, directory = task
    root = Path(directory)
    (root / str(index)).write_text(str(os.getpid()))
    if index == 0:
        deadline = time.monotonic() + 10
        while not all((root / str(i)).is_file() for i in (1, 2)):
            if time.monotonic() >= deadline:
                raise RuntimeError("fixture peer startup timeout")
            time.sleep(.01)
        return {"index": index, "pid": os.getpid()}
    time.sleep(30)
    return {"index": index, "pid": os.getpid()}


def _cleanup_fault_pid_exists(pid):
    try:
        os.kill(pid, 0)
        return True
    except ProcessLookupError:
        return False


@pytest.mark.parametrize("pool_kind", ["ordered", "ready"])
def test_first_real_group_permission_error_does_not_skip_peer_cleanup(tmp_path, monkeypatch, pool_kind):
    monkeypatch.setattr(_ready_runtime, "effective_cpu_count", lambda: 32)
    monkeypatch.setattr(_ready_runtime, "_available_memory_bytes", lambda: 16 * 1024**3)
    owned, signals, injected = [], [], []
    monkeypatch.setattr(_ready_runtime, "_POOL_GROUP_OBSERVER", owned.append)
    raw_killpg = os.killpg

    def denied_first_group(pgid, signum):
        signals.append((pgid, int(signum)))
        if not injected and pgid in owned:
            # The production helper must not suppress EPERM for this live group.
            assert os.getpgid(pgid) == pgid
            injected.append(pgid)
            raise PermissionError(__import__("errno").EPERM, "isolated first owned-group signal denied")
        return raw_killpg(pgid, signum)

    monkeypatch.setattr(os, "killpg", denied_first_group)
    unrelated = subprocess.Popen([__import__("sys").executable, "-c", "import time; time.sleep(30)"],
                                  start_new_session=True, stdout=subprocess.DEVNULL,
                                  stderr=subprocess.DEVNULL)

    def reject_result(index, result):
        raise RuntimeError("isolated callback triggers pool cleanup")

    def family():
        if pool_kind == "ready":
            _ready_runtime.admit_stage(_ready_family_policy(), tmp_path, legal_tasks=4, retained_bytes=0,
                                publication_bytes=0, transient_bytes_per_worker=1024)
        # One pending task keeps the ordered pool's first slot alive at callback.
        return _ready_runtime._bounded_ordered_spawn(_cleanup_fault_owned_task,
            [(i, str(tmp_path)) for i in range(4)], selected_slots=3,
            on_result=reject_result)

    try:
        with pytest.raises(PermissionError, match="isolated first owned-group signal denied") as caught:
            if pool_kind == "ready":
                _ready_runtime.run_ready_families([family], policy=_ready_family_policy(), root=tmp_path, workers=3)
            else:
                family()
        assert caught.value.errno == __import__("errno").EPERM
        assert len(owned) == len(set(owned)) == 3
        assert len(injected) == 1
        assert all(pid in {p for p, _ in signals} for pid in owned)
        assert all(not _cleanup_fault_pid_exists(pid) for pid in owned)
        assert not multiprocessing.active_children()
        assert unrelated.poll() is None and _cleanup_fault_pid_exists(unrelated.pid)
        assert unrelated.pid not in {p for p, _ in signals}
    finally:
        # Defensive test teardown touches only this fixture's recorded children.
        for child in multiprocessing.active_children():
            if child.pid not in owned:
                continue
            if child.is_alive():
                raw_killpg(child.pid, signal.SIGKILL)
            child.join(timeout=5)
            if not child.is_alive():
                child.close()
        if unrelated.poll() is None:
            unrelated.terminate()
        unrelated.wait(timeout=5)


def _ready_disk_publish_task(task):
    # Scheduler-only retained bytes; there is no numerical engine in this test.
    path = Path(task['path'])
    path.write_bytes(b'x' * task['bytes'])
    return {'path': str(path), 'bytes': path.stat().st_size, 'pid': os.getpid()}


def test_ready_family_only_reserves_unpublished_task_bytes(tmp_path, ready_family_host, monkeypatch):
    root = tmp_path.resolve()
    original = _ready_runtime.observe_execution_resources
    observations, callbacks = [], []
    def observe(path):
        remaining = 100_000 - sum(p.stat().st_size for p in root.glob('retained-*.bin'))
        observations.append(remaining)
        return {**original(path), 'scratch_available_bytes': remaining}
    monkeypatch.setattr(_ready_runtime, 'observe_execution_resources', observe)
    def family():
        _ready_runtime.admit_stage(_ready_family_policy(), root, legal_tasks=2,
            retained_bytes=60_000, publication_bytes=30_000,
            transient_bytes_per_worker=1024, task_disk_bytes=[(30_000, 30_000)] * 2)
        return _ready_runtime._bounded_ordered_spawn(_ready_disk_publish_task,
            [{'path': str(root / f'retained-{i}.bin'), 'bytes': 30_000} for i in range(2)],
            selected_slots=1, on_result=lambda i, row: callbacks.append(i))
    report = {}
    rows, = _run_ready_families([family], policy=_ready_family_policy(), root=root,
        workers=1, report=report)
    assert callbacks == [0, 1] and [row['bytes'] for row in rows] == [30_000, 30_000]
    assert 70_000 in observations and report['worker_process_peak'] == 1
    assert [p.stat().st_size for p in sorted(root.glob('retained-*.bin'))] == [30_000, 30_000]


def test_ready_disk_credit_waits_for_scientific_ok_but_does_not_release_owner(tmp_path, ready_family_host, monkeypatch):
    from types import SimpleNamespace
    runtime = _ready_runtime
    root = tmp_path.resolve()
    policy = _ready_family_policy()
    pool = runtime._ReadyPool(policy, root, 2, {})
    observed = {'effective_cpus': 32, 'available_memory_bytes': 4*1024**3,
        'scratch_available_bytes': 100_000, 'scratch_root': str(root)}
    monkeypatch.setattr(runtime, 'observe_execution_resources', lambda path: dict(observed))
    batch = SimpleNamespace(estimates={'retained_bytes': 60_000, 'publication_bytes': 30_000,
        'transient_bytes_per_worker': 1024, 'memory_bytes_per_worker': 2*1024**3,
        'task_disk_bytes': ((30_000, 30_000), (30_000, 30_000))},
        results=[runtime._READY_MISSING]*2, pending=[1], active=1, report=None,
        on_result=lambda index, result: None)
    class Receiver:
        def recv(self): return {'index': 0, 'status': 'OK', 'result': {'published': True}}
    receiver = Receiver()
    pool.processes[receiver] = SimpleNamespace(pid=12345)
    pool.active[receiver] = [batch, 0, time.monotonic()+10, False]
    assert pool._admission([batch])['disk_peak']['future_retained_bytes'] == 60_000
    # A live free-space change without OK cannot claim that our task published.
    observed['scratch_available_bytes'] = 70_000
    with pytest.raises(runtime.ContractError, match='RESOURCE_ADMISSION_ZERO'):
        pool._admission([batch])
    pool._message(receiver)
    admitted = pool._admission([batch])
    assert admitted['disk_peak']['future_retained_bytes'] == 30_000
    assert admitted['disk_peak']['publication_bytes'] == 30_000
    assert admitted['limits']['legal_independent_tasks'] == 2
    assert batch.active == 1 and receiver in pool.active and pool.active[receiver][3] is True
    # Callback success is the credit boundary, not a speculative free-space delta.
    assert batch.results[0] == {'published': True} and batch.results[1] is runtime._READY_MISSING


@pytest.mark.parametrize('shortage', ['memory', 'scratch'])
def test_task_disk_estimate_keeps_real_memory_and_disk_admission(tmp_path, ready_family_host, monkeypatch, shortage):
    observed = {'effective_cpus': 32, 'available_memory_bytes': 2*1024**3,
        'scratch_available_bytes': 61_024, 'scratch_root': str(tmp_path)}
    if shortage == 'memory': observed['available_memory_bytes'] -= 1
    else: observed['scratch_available_bytes'] -= 1
    monkeypatch.setattr(_ready_runtime, 'observe_execution_resources', lambda path: observed)
    with pytest.raises(_ready_runtime.ContractError, match='RESOURCE_ADMISSION_ZERO'):
        _ready_runtime.admit_stage(_ready_family_policy(), tmp_path, legal_tasks=1,
            retained_bytes=30_000, publication_bytes=30_000,
            transient_bytes_per_worker=1024, task_disk_bytes=[(30_000, 30_000)])


def test_task_disk_estimate_rejects_unaccounted_or_misaligned_bytes(tmp_path):
    for rows in [[(1, 1)], [(30_000, 0)], [(30_000, 30_000), (0, 0)], [(True, 30_000)]]:
        with pytest.raises(_ready_runtime.ContractError, match='RESOURCE_STAGE_TASK_ESTIMATE_INVALID'):
            _ready_runtime.admit_stage(_ready_family_policy(), tmp_path, legal_tasks=1,
                retained_bytes=30_000, publication_bytes=30_000,
                transient_bytes_per_worker=1024, task_disk_bytes=rows)


def test_mice_gather_binds_original_amount_and_chains_keep_view_reserve(tmp_path,monkeypatch):
    from padml import runtime, f1_kernel
    estimates=dict(retained_bytes=12345,publication_bytes=23456,transient_bytes_per_worker=4567,memory_bytes_per_worker=2*1024**3)
    admissions=[]
    class Pool:
        def admit(self,policy,root,**values):
            admissions.append(values);return {'admitted_worker_ceiling':2}
    monkeypatch.setattr(runtime,'current_ready_pool',lambda:Pool())
    returned=iter([{'status':'NEEDS_CHECKPOINT','chain_indices':[2,7],'checkpoint':40},
        {'status':'VIEW_OUTPUT_READY','native_objects_validated':True}])
    def pool(worker,jobs,**kw):
        if jobs[0]['phase']=='GATHER':return [next(returned)]
        assert [j['chain_index'] for j in jobs]==[2,7] and all(j['checkpoint']==40 for j in jobs)
        return [{'chain_index':j['chain_index']} for j in jobs]
    monkeypatch.setattr(f1_kernel,'_bounded_ordered_spawn',pool)
    assert f1_kernel._coordinate_mice_phases({}, {}, tmp_path, estimates, [None])['status']=='VIEW_OUTPUT_READY'
    assert len(admissions)==3
    for index in [0,2]:assert admissions[index]['task_disk_bytes']==((12345,23456),)
    assert admissions[1]['legal_tasks']==2 and admissions[1]['task_disk_bytes'] is None
    assert all(v['retained_bytes']==12345 and v['publication_bytes']==23456 for v in admissions)


_ACKLESS_ENTRY = _ready_runtime._spawn_task_entry
_ACKLESS_JOB = None


def _ackless_task(task):
    global _ACKLESS_JOB
    _ACKLESS_JOB = task
    path = Path(task['root']) / ('coordinate-' + str(task['value']))
    with path.open('x') as handle: handle.write(str(os.getpid()))
    started = time.monotonic()
    if task.get('wait_for_coordinate') is not None:
        dependency = Path(task['root']) / ('coordinate-' + str(task['wait_for_coordinate']))
        deadline = started + 1.8
        while not dependency.is_file():
            if time.monotonic() >= deadline:
                raise AssertionError('Expected replacement coordinate did not start')
            time.sleep(.01)
    time.sleep(task.get('delay',0))
    return {'value':task['value'],'pid':os.getpid(),'start':started,'end':time.monotonic()}


def _ackless_entry(worker, connection, capture_release):
    def release(files, *, owner, **kwargs):
        if _ACKLESS_JOB.get('never_ack'):
            # Force the bounded KILL fallback. This fake cache observer owns
            # no scientific work: the real OK frame was already published.
            signal.signal(signal.SIGTERM,signal.SIG_IGN)
            while True: time.sleep(1)
        return {'status':'UNKNOWN','owner':owner,'pid':os.getpid(),'reason':'UNFITTED fast observer'}
    _ready_runtime.release_step_resources=release
    _ACKLESS_ENTRY(worker,connection,capture_release)


@pytest.mark.parametrize('pool_kind',['ordered','ready'])
def test_never_ack_after_scientific_ok_retires_only_owned_group_and_refills(tmp_path,monkeypatch,ready_family_host,pool_kind):
    monkeypatch.setattr(_ready_runtime,'_spawn_task_entry',_ackless_entry)
    monkeypatch.setattr(_ready_runtime,'_RELEASE_WAIT_SECONDS',.15)
    monkeypatch.setattr(_ready_runtime,'_RELEASE_TERMINATE_GRACE_SECONDS',.4)
    owned,signals,callbacks=[],[],[]
    monkeypatch.setattr(_ready_runtime,'_POOL_GROUP_OBSERVER',owned.append)
    raw_killpg=os.killpg
    def signal_group(pgid,signum):
        signals.append((pgid,signum))
        return raw_killpg(pgid,signum)
    monkeypatch.setattr(os,'killpg',signal_group)
    unrelated=subprocess.Popen([__import__('sys').executable,'-c','import time; time.sleep(30)'],
        start_new_session=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    report,releases={},{}
    jobs=[{'value':i,'root':str(tmp_path),'delay':delay,'never_ack':i==0}
        for i,delay in enumerate([.01,.25,0,.01])]
    # Prove replacement by causal ordering, independent of spawn/import speed.
    jobs[0]['wait_for_coordinate'] = 1
    jobs[2]['wait_for_coordinate'] = 3
    def on_result(index,row):
        callbacks.append(index)
        if index==1:
            first_pid=int((tmp_path/'coordinate-0').read_text())
            assert _pid_exists(first_pid), 'Peer result must progress while the first cleanup is still hung'
    def family():
        if pool_kind=='ready':
            _ready_runtime.admit_stage(_ready_family_policy(),tmp_path,legal_tasks=len(jobs),
                retained_bytes=0,publication_bytes=0,transient_bytes_per_worker=1024)
        return _ready_runtime._bounded_ordered_spawn(_ackless_task,jobs,selected_slots=2,
            on_result=on_result,task_timeout_seconds=2,execution_report=report,resource_release_report=releases)
    try:
        if pool_kind=='ready':
            rows,=_ready_runtime.run_ready_families([family],policy=_ready_family_policy(),root=tmp_path,workers=2)
        else: rows=family()
        assert [r['value'] for r in rows]==[0,1,2,3] and sorted(callbacks)==[0,1,2,3]
        assert len(list(tmp_path.glob('coordinate-*')))==4
        assert len(set(r['pid'] for r in rows))==3 and rows[3]['pid'] not in {rows[0]['pid'],rows[1]['pid']}
        assert report['actual_worker_process_peak']<=2 and report['status']=='COMPLETED'
        assert releases['0']['status']=='UNKNOWN' and releases['0']['reason']=='BOUNDED_SPAWN_RELEASE_ACK_TIMEOUT'
        assert (rows[0]['pid'],signal.SIGTERM) in signals and (rows[0]['pid'],signal.SIGKILL) in signals
        assert all(pgid in owned for pgid,_ in signals) and unrelated.poll() is None
        assert not multiprocessing.active_children() and all(not _pid_exists(pid) for pid in owned)
    finally:
        for child in multiprocessing.active_children():
            if child.pid not in owned:continue
            if child.is_alive():raw_killpg(child.pid,signal.SIGKILL)
            child.join(timeout=5)
        if unrelated.poll() is None:unrelated.terminate()
        unrelated.wait(timeout=5)


@pytest.mark.parametrize('pool_kind',['ordered','ready'])
def test_unconfirmed_release_keeps_scientific_callback_but_never_refills(tmp_path,monkeypatch,ready_family_host,pool_kind):
    monkeypatch.setattr(_ready_runtime,'_spawn_task_entry',_ackless_entry)
    monkeypatch.setattr(_ready_runtime,'_RELEASE_WAIT_SECONDS',.1)
    def unconfirmed(*args,**kwargs):
        raise ContractError('BOUNDED_SPAWN_RELEASE_OWNER_UNKNOWN:UNFITTED process observation failure')
    monkeypatch.setattr(_ready_runtime,'_advance_release_timeout',unconfirmed)
    callbacks,owned=[],[]
    monkeypatch.setattr(_ready_runtime,'_POOL_GROUP_OBSERVER',owned.append)
    report,releases={},{}
    jobs=[{'value':i,'root':str(tmp_path),'never_ack':i==0} for i in range(2)]
    def family():
        if pool_kind=='ready':
            _ready_runtime.admit_stage(_ready_family_policy(),tmp_path,legal_tasks=2,
                retained_bytes=0,publication_bytes=0,transient_bytes_per_worker=1024)
        return _ready_runtime._bounded_ordered_spawn(_ackless_task,jobs,selected_slots=1,
            on_result=lambda i,r:callbacks.append(i),execution_report=report,resource_release_report=releases)
    with pytest.raises(ContractError,match='BOUNDED_SPAWN_RELEASE_OWNER_UNKNOWN'):
        if pool_kind=='ready':
            _ready_runtime.run_ready_families([family],policy=_ready_family_policy(),root=tmp_path,workers=1)
        else:family()
    assert callbacks==[0] and (tmp_path/'coordinate-0').is_file() and not (tmp_path/'coordinate-1').exists()
    assert report['status']=='FAILED' and releases['0']['status']=='UNKNOWN'
    assert not multiprocessing.active_children() and all(not _pid_exists(pid) for pid in owned)


@pytest.mark.parametrize('task_gib,disk_gib,tasks,expected', [
    (None, 200, 40, 24), (4, 200, 40, 6), (None, 4, 40, 3), (None, 200, 2, 2),
])
def test_one_gib_floor_preserves_task_memory_cpu_and_disk_limits(monkeypatch, tmp_path,
                                                                task_gib, disk_gib, tasks, expected):
    from padml import runtime
    gib = 1024**3
    policy = dict(configured_worker_ceiling=runtime.CPU_MINUS_8,
        memory_bytes_per_worker=runtime.MIN_WORKER_MEMORY_BYTES, memory_reserve_bytes=gib,
        scratch_bytes_per_worker=gib, scratch_reserve_bytes=0, transfer_archive_worker_ceiling=1000)
    observation = dict(effective_cpus=32, available_memory_bytes=25*gib,
        scratch_available_bytes=disk_gib*gib, scratch_root=str(tmp_path))
    monkeypatch.setattr(runtime, 'current_ready_pool', lambda: None)
    monkeypatch.setattr(runtime, 'observe_execution_resources', lambda root: observation)
    actual = runtime.admit_stage(policy, tmp_path, legal_tasks=tasks, retained_bytes=gib//2,
        publication_bytes=gib//2, transient_bytes_per_worker=gib,
        **({} if task_gib is None else {'memory_bytes_per_worker': task_gib*gib}))
    assert runtime.MIN_WORKER_MEMORY_BYTES == gib
    assert actual['admitted_worker_ceiling'] == expected
    assert actual['limits']['cpu_c_minus_8'] == 24
    assert actual['disk_peak']['future_retained_bytes'] == gib//2
    assert policy['memory_bytes_per_worker'] == gib


def test_one_gib_run_revision_preserves_other_budgets_and_original_policy():
    from padml import runtime
    from padml.run import _f45_worker_memory_revision
    policy = dict(configured_worker_ceiling=runtime.CPU_MINUS_8,
        memory_bytes_per_worker=2*1024**3, memory_reserve_bytes=1024**3,
        scratch_bytes_per_worker=2*1024**3, scratch_reserve_bytes=0, transfer_archive_worker_ceiling=1000)
    revised = {**policy, 'memory_bytes_per_worker': 1024**3}
    assert _f45_worker_memory_revision(policy, policy)
    assert _f45_worker_memory_revision(policy, revised)
    assert not _f45_worker_memory_revision(revised, policy)
    assert not _f45_worker_memory_revision(policy, {**revised, 'memory_bytes_per_worker': 512*1024**2})
    for key in ('scratch_bytes_per_worker', 'memory_reserve_bytes', 'scratch_reserve_bytes',
                'transfer_archive_worker_ceiling'):
        assert not _f45_worker_memory_revision(policy, {**revised, key: policy[key]+1})
    assert policy['memory_bytes_per_worker'] == 2*1024**3


@pytest.mark.parametrize('change', ['authorized', 'scratch', 'reserve', 'reverse', 'legacy'])
def test_full0_one_gib_resume_keeps_original_preparation_and_new_admission(tmp_path, monkeypatch, change):
    import copy
    from contextlib import contextmanager
    from padml import f5, nested_loco, runtime, worker
    from padml.bundle import ContractError, canonical_json_bytes
    policy = dict(configured_worker_ceiling=runtime.CPU_MINUS_8,
        memory_bytes_per_worker=2*1024**3, memory_reserve_bytes=1024**3,
        scratch_bytes_per_worker=2*1024**3, scratch_reserve_bytes=0, transfer_archive_worker_ceiling=1000)
    current = {**policy, 'memory_bytes_per_worker': 1024**3}
    if change == 'scratch':
        current['scratch_bytes_per_worker'] += 1
    elif change == 'reserve':
        current['memory_reserve_bytes'] += 1
    elif change == 'reverse':
        policy, current = current, policy
    context, root = tmp_path/'context', tmp_path/'unit'
    common = context/'common'
    common.mkdir(parents=True)
    root.mkdir()
    budgets = {'shared_storage_bytes': 10000}
    sources = dict(resource_policy=policy, science_decision=nested_loco.science_decision_template(24),
        plan={}, rscript='/UNFITTED/Rscript', selector_root=str(common/'selector'), score_root=str(root/'score'),
        final_mice_path=str(common/'final-mice.zip'), mice_root=str(common/'mice'),
        search_roots={'RSF': str(root/'search/RSF')}, selection_horizon_months=6, **budgets)
    shared, unit_source = common/'full-development.json', root/'full-development.json'
    raw = canonical_json_bytes(sources)
    shared.write_bytes(raw)
    previous = copy.deepcopy(sources)
    previous['science_decision'] = nested_loco.science_decision_template(6)
    unit_raw = canonical_json_bytes(previous)
    unit_source.write_bytes(unit_raw)
    run = dict(kind='PADML_INTEGRATED_RAW_RUN_V1' if change != 'legacy' else 'PADML_F45_WHOLE_UNIT_RUN_V1',
        resource_policy=current, budgets=budgets)
    calls = []
    monkeypatch.setattr(f5, 'compile_full_data_search_mice_tasks', lambda plan: [])
    monkeypatch.setattr(f5, 'compile_final_full_data_mice_task', lambda plan: {'view_id':'FINAL', 'phase':'FINAL_MICE'})
    monkeypatch.setattr(f5, 'execute_full_data_mice_batch', lambda *a, **k: (calls.append('mice') or {'results': []}))
    monkeypatch.setattr(worker, '_f45_release', lambda *a: None)
    @contextmanager
    def prepared(*args, **kwargs):
        yield previous, [], {}
    monkeypatch.setattr(f5, '_materialized_full_data_development_sources', prepared)
    class AtSelector(Exception): pass
    def selector(*args, **kwargs):
        assert kwargs['resource_policy'] == current
        calls.append('selector')
        raise AtSelector
    monkeypatch.setattr(f5, '_nested_full_selector_program', selector)
    with pytest.raises(AtSelector if change == 'authorized' else ContractError,
                       match=None if change == 'authorized' else 'F45_FULL0_PREPARATION_DRIFT'):
        worker._f45_full0(run, {'horizon':6}, root, context)
    assert calls == (['mice', 'selector'] if change == 'authorized' else [])
    assert shared.read_bytes() == raw and unit_source.read_bytes() == unit_raw
    assert current == run['resource_policy'] and sources['resource_policy'] == policy


def _ready_pressure_leaf(task):
    """Engineering work only: exclusive marker proves each coordinate runs once."""
    root = Path(task['root'])
    with (root / f"task-{task['index']}").open('x') as stream:
        stream.write(str(os.getpid()))
    if task.get('pair'):
        deadline = time.monotonic() + 10
        while not all((root / f'task-{i}').is_file() for i in (0, 1)):
            if time.monotonic() >= deadline:
                raise RuntimeError('PRESSURE_FIXTURE_PAIR_TIMEOUT')
            time.sleep(.005)
    return {'index': task['index'], 'pid': os.getpid()}


def test_ready_memory_pressure_retires_warm_slot_and_resumes_once(tmp_path, ready_family_host, monkeypatch):
    """Real spawn/None exit/group confirmation; measured capacity is synthetic."""
    runtime = _ready_runtime
    policy = {**_ready_family_policy(), 'memory_bytes_per_worker': 1024**3,
              'memory_reserve_bytes': 1024**3}
    pressure, pool_ref, retired, observations = [], [], [], []
    before = {}
    def observed(root):
        available = 8*1024**3
        if pressure:
            pool = pool_ref[0]
            available = 2088419328 + 128*1024**2*len(retired)
            observations.append((len(pool.processes), available))
        return {'effective_cpus': 32, 'available_memory_bytes': available,
            'scratch_available_bytes': 8*1024**3, 'scratch_root': str(root)}
    monkeypatch.setattr(runtime, 'observe_execution_resources', observed)
    original = runtime._advance_release_timeout
    def confirmed(process, state, *, owns_group):
        value = original(process, state, owns_group=owns_group)
        if value: retired.append(process.pid)
        return value
    monkeypatch.setattr(runtime, '_advance_release_timeout', confirmed)
    def family():
        def batch(ids, *, pair=False):
            runtime.admit_stage(policy, tmp_path, legal_tasks=len(ids), retained_bytes=0,
                publication_bytes=0, transient_bytes_per_worker=1024,
                memory_bytes_per_worker=1024**3)
            return runtime._bounded_ordered_spawn(_ready_pressure_leaf,
                [{'root': str(tmp_path), 'index': i, 'pair': pair} for i in ids], selected_slots=2)
        first = batch([0, 1], pair=True)
        assert len({row['pid'] for row in first}) == 2
        before.update({p.name: p.read_bytes() for p in tmp_path.glob('task-*')})
        pool_ref.append(runtime.current_ready_pool()); pressure.append(True)
        last = batch([2])
        return first + last
    report = {}
    result, = runtime.run_ready_families([family], policy=policy, root=tmp_path, workers=2, report=report)
    assert [row['index'] for row in result] == [0, 1, 2]
    assert report['worker_process_peak'] == 2 and 2 <= len(report['worker_pids']) <= 3
    assert set(retired).intersection(row['pid'] for row in result[:2])
    assert {p.name for p in tmp_path.glob('task-*')} == {'task-0', 'task-1', 'task-2'}
    assert all((tmp_path / name).read_bytes() == raw for name, raw in before.items())
    assert observations and max(value for _,value in observations) >= 2222637056
    assert not multiprocessing.active_children()


def _ready_pressure_fixture(tmp_path, monkeypatch, *, workers=2, warm=True):
    """Actual admission and lifecycle methods, with no OS process or signal."""
    from collections import deque
    from types import SimpleNamespace
    from threading import Event
    runtime = _ready_runtime
    clock = [time.monotonic()]
    monkeypatch.setattr(runtime, 'monotonic', lambda: clock[0])
    monkeypatch.setattr(runtime, 'effective_cpu_count', lambda: 32)
    policy = {**_ready_family_policy(), 'memory_bytes_per_worker': 1024**3,
        'memory_reserve_bytes': 1024**3, 'scratch_bytes_per_worker': 2*1024**3}
    pool = runtime._ReadyPool(policy, tmp_path.resolve(), 24,
                              {'worker_process_peak': workers, 'worker_pids': []})
    batch = SimpleNamespace(estimates={'retained_bytes': 0, 'publication_bytes': 0,
        'transient_bytes_per_worker': 2*1024**3, 'memory_bytes_per_worker': 1024**3},
        results=[runtime._READY_MISSING]*(81+workers), pending=deque(range(workers, 81+workers)),
        active=0, remaining=81+workers, maximum=24, admission={'admitted_worker_ceiling': 24},
        report=None, release_report={}, on_result=None, event=Event(), error=None,
        timeout=60, deadlines=None, function=None, tasks=[None]*(81+workers), cache_scope=1)
    pool.batches.append(batch)
    state = {'available': 2088419328, 'released_bytes': 128*1024**2,
        'scratch': 737980757152, 'groups': {}, 'signals': []}
    processes, receivers = [], []
    class Process:
        def __init__(self, pid): self.pid, self.alive, self.closed = pid, True, False
        def join(self, timeout=0): pass
        def is_alive(self): return self.alive
        def close(self): self.closed = True
    class Receiver:
        def __init__(self, process):
            self.process, self.sent, self.messages, self.closed = process, [], deque(), False
            self.group_exit = True
        def send(self, value):
            self.sent.append(value)
            if value is None:
                self.process.alive = False
                if self.group_exit: state['groups'][self.process.pid] = False
        def recv(self): return self.messages.popleft()
        def close(self): self.closed = True
    def killpg(pid, signum):
        assert pid in state['groups'], 'Only fixture-owned groups may be inspected or signalled'
        if signum: state['signals'].append((pid, signum))
        if not state['groups'][pid]: raise ProcessLookupError(pid)
    monkeypatch.setattr(runtime.os, 'killpg', killpg)
    monkeypatch.setattr(runtime, 'wait_connections', lambda readers, timeout: [])
    monkeypatch.setattr(runtime, 'observe_execution_resources', lambda root: {
        'effective_cpus': 32, 'available_memory_bytes': state['available'] +
            state['released_bytes']*sum(p.closed for p in processes),
        'scratch_available_bytes': state['scratch'], 'scratch_root': str(root)})
    monkeypatch.setattr(pool, '_launch', lambda: pytest.fail('Unexpected new process in engineering fixture'))
    for index in range(workers):
        process = Process(9_000_000+index)
        receiver = Receiver(process)
        processes.append(process); receivers.append(receiver)
        state['groups'][process.pid] = True
        pool.processes[receiver] = process
        pool.starting[receiver] = clock[0]+30
        receiver.messages.append({'status': 'READY', 'process_group': process.pid})
        pool._message(receiver)
        if warm:
            pool.idle.remove(receiver)
            pool.active[receiver] = [batch, index, clock[0]+60, False]
            batch.active += 1
            receiver.messages.append({'status': 'OK', 'index': index, 'result': {'completed': index}})
            receiver.messages.append({'status': 'RELEASED', 'index': index, 'resource_release': {
                'status': 'UNKNOWN', 'owner': f'POOL_TASK_RESULT:{index}',
                'pid': process.pid, 'reason': 'engineering cache-advice status only'}})
            pool._message(receiver); pool._message(receiver)
    return pool, batch, state, receivers, processes, clock


@pytest.mark.parametrize('entry', ['_fill', '_accept'])
def test_ready_memory_pressure_both_entries_remeasure_after_owned_exit(tmp_path, monkeypatch, entry):
    pool, batch, state, receivers, processes, clock = _ready_pressure_fixture(tmp_path, monkeypatch)
    if entry == '_accept': pool.batches.clear(); pool.waiting.append(batch)
    original_results = list(batch.results)
    getattr(pool, entry)()
    assert receivers[0].sent == [None] and not receivers[1].sent
    assert receivers[0] in pool.retiring and not processes[0].closed
    pool._fill()
    assert not receivers[1].sent, 'Unconfirmed retirement cannot grant a replacement slot'
    pool.advance()
    assert processes[0].closed and receivers[0].closed and not pool.retiring
    assert processes[0].pid not in pool.owned and processes[1].pid in pool.owned
    assert len(receivers[1].sent) == 1 and receivers[1].sent[0][0] == 2
    assert pool.capacity == 1 and len(batch.pending) == 80 and batch.results == original_results
    assert not state['signals']


@pytest.mark.parametrize('entry', ['_fill', '_accept'])
@pytest.mark.parametrize('condition', ['cold', 'still_short', 'disk_only', 'memory_and_disk'])
def test_ready_pressure_never_weakens_real_limits_or_loops_cold_start(tmp_path, monkeypatch, entry, condition):
    pool, batch, state, receivers, processes, clock = _ready_pressure_fixture(
        tmp_path, monkeypatch, workers=1, warm=condition != 'cold')
    if entry == '_accept': pool.batches.clear(); pool.waiting.append(batch)
    if condition in {'disk_only', 'memory_and_disk'}: state['scratch'] = 1024
    if condition == 'disk_only': state['available'] = 8*1024**3
    if condition == 'still_short':
        state['released_bytes'] = 1
        getattr(pool, entry)()
        with pytest.raises(ContractError, match='RESOURCE_ADMISSION_ZERO'):
            pool.advance()
        assert processes[0].closed and receivers[0].sent == [None]
    else:
        with pytest.raises(ContractError, match='RESOURCE_ADMISSION_ZERO'):
            getattr(pool, entry)()
        assert not receivers[0].sent and not pool.retiring
    assert not state['signals'] and len(batch.pending) == 81


@pytest.mark.parametrize('entry', ['_fill', '_accept'])
@pytest.mark.parametrize('inflight', ['active', 'release', 'starting'])
def test_ready_pressure_preserves_inflight_and_startup_deadline(tmp_path, monkeypatch, entry, inflight):
    pool, batch, state, receivers, processes, clock = _ready_pressure_fixture(tmp_path, monkeypatch)
    receiver = receivers[0]; pool.idle.remove(receiver)
    if entry == '_accept': pool.batches.clear(); pool.waiting.append(batch)
    if inflight == 'starting': pool.starting[receiver] = clock[0]+30
    else:
        pool.active[receiver] = [batch, 0, clock[0]+60, inflight == 'release']
        if inflight == 'release': pool.release_waits[receiver] = [clock[0]+60, 0]
    getattr(pool, entry)()
    assert not receivers[0].sent and all(message is None for message in receivers[1].sent)
    assert set(pool.retiring) <= {receivers[1]} and not processes[1].closed
    if inflight == 'starting':
        clock[0] += 31
        with pytest.raises(ContractError, match='BOUNDED_SPAWN_STARTUP_TIMEOUT'):
            pool.advance()
    assert not state['signals']


def test_ready_pressure_does_not_credit_dead_parent_with_unknown_group(tmp_path, monkeypatch):
    pool, batch, state, receivers, processes, clock = _ready_pressure_fixture(tmp_path, monkeypatch)
    receivers[0].group_exit = False
    pool._fill()
    assert not processes[0].alive and state['groups'][processes[0].pid]
    pool.advance()
    assert not processes[0].closed and not receivers[1].sent
    for expected in (signal.SIGTERM, signal.SIGKILL):
        clock[0] += _ready_runtime._RELEASE_TERMINATE_GRACE_SECONDS + .01
        pool.advance()
        assert state['signals'][-1] == (processes[0].pid, expected)
        assert not processes[0].closed and not receivers[1].sent
    clock[0] += _ready_runtime._RELEASE_TERMINATE_GRACE_SECONDS + .01
    with pytest.raises(ContractError, match='BOUNDED_SPAWN_RELEASE_OWNER_UNKNOWN'):
        pool.advance()
    assert processes[0].pid in pool.owned and receivers[0] in pool.retiring
    assert receivers[1] in pool.idle and not receivers[1].sent and len(batch.pending) == 81


def _ready_pressure_mark_active(pool, batch, receiver, clock):
    """Use one original, unfinished coordinate; never recycle a completed result."""
    index = batch.pending.popleft()
    pool.idle.remove(receiver)
    pool.active[receiver] = [batch, index, clock[0]+60, False]
    batch.active += 1
    return index


@pytest.mark.parametrize('available', [2088419328, 2*1024**3], ids=['zero', 'positive_one'])
def test_ready_pressure_reclaims_only_warm_idle_while_peer_active(tmp_path, monkeypatch, available):
    pool, batch, state, receivers, processes, clock = _ready_pressure_fixture(tmp_path, monkeypatch)
    index = _ready_pressure_mark_active(pool, batch, receivers[0], clock)
    state['available'] = available
    before = list(batch.results)
    pending = list(batch.pending)
    pool._fill()
    assert receivers[1].sent == [None] and receivers[1] in pool.retiring
    assert receivers[0] in pool.active and pool.active[receivers[0]][1] == index
    assert not receivers[0].sent and not state['signals']
    assert batch.results == before and list(batch.pending) == pending
    assert processes[0].pid in pool.owned and not processes[0].closed


def test_ready_idle_retirement_never_grants_disk_credit(tmp_path, monkeypatch):
    pool, batch, state, receivers, processes, clock = _ready_pressure_fixture(tmp_path, monkeypatch)
    _ready_pressure_mark_active(pool, batch, receivers[0], clock)
    state['available'] = 8*1024**3
    state['scratch'] = 1024
    pending = list(batch.pending)
    pool._fill()
    assert len(pool.active) == 1 and list(batch.pending) == pending
    assert not receivers[0].sent and not state['signals']
    assert all(message is None for message in receivers[1].sent)
    # Memory released by idle exit cannot turn the unchanged disk limit positive.
    with pytest.raises(ContractError, match='RESOURCE_ADMISSION_ZERO'):
        pool._admission([batch])


def test_ready_retiring_peer_does_not_block_fresh_safe_slot(tmp_path, monkeypatch):
    pool, batch, state, receivers, processes, clock = _ready_pressure_fixture(tmp_path, monkeypatch)
    pool.ceiling = 2
    state['available'] = 8*1024**3
    pool.idle.remove(receivers[0]); pool.warm.discard(receivers[0])
    pool.retiring[receivers[0]] = [clock[0]+5, 0]
    # This exact group is still alive and consumes one of the two process slots.
    assert state['groups'][processes[0].pid]
    next_index = batch.pending[0]
    pool._fill()
    assert receivers[0] in pool.retiring and not processes[0].closed
    assert len(pool.processes) == 2 and processes[0].pid in pool.owned
    assert len(receivers[1].sent) == 1 and receivers[1].sent[0][0] == next_index
    assert receivers[1] in pool.active and len(pool.active) == 1
    assert not state['signals']


def test_ready_no_resource_rescan_without_dispatch_or_lifecycle_event(tmp_path, monkeypatch):
    pool, batch, state, receivers, processes, clock = _ready_pressure_fixture(tmp_path, monkeypatch)
    pool.ceiling = 2
    state['available'] = 8*1024**3
    for receiver in receivers:
        _ready_pressure_mark_active(pool, batch, receiver, clock)
    calls = []
    observed = _ready_runtime.observe_execution_resources
    def count_observed(root):
        calls.append(root)
        return observed(root)
    monkeypatch.setattr(_ready_runtime, 'observe_execution_resources', count_observed)
    pool.advance()
    initial = len(calls)
    for _ in range(12):
        pool.advance()
    assert len(calls) == initial
    assert len(pool.active) == 2 and not pool.retiring
    assert not any(r.sent for r in receivers) and not state['signals']


def test_ready_fresh_admission_keeps_larger_memory_and_disk_estimates(tmp_path, monkeypatch):
    pool, batch, state, receivers, processes, clock = _ready_pressure_fixture(tmp_path, monkeypatch)
    state['available'] = 6*1024**3
    batch.estimates.update(memory_bytes_per_worker=2*1024**3,
        retained_bytes=2*1024**3, publication_bytes=1024**3,
        transient_bytes_per_worker=2*1024**3)
    state['scratch'] = 9*1024**3
    result = pool._admission([batch])
    assert result['limits']['memory'] == 2
    assert result['limits']['scratch'] == 3
    assert result['admitted_worker_ceiling'] == 2
    assert result['memory_usable_bytes'] == 5*1024**3
    assert result['disk_peak']['future_retained_bytes'] == 2*1024**3
    assert result['disk_peak']['publication_bytes'] == 1024**3
    assert pool.policy['memory_bytes_per_worker'] == 1024**3


def test_ready_ended_scope_retires_without_next_task_and_live_batch_reuses(tmp_path, monkeypatch, ready_family_host):
    from threading import Event
    confirmed = Event()
    retired = []
    original = _ready_runtime._advance_release_timeout
    def observed_exit(process, state, *, owns_group):
        gone = original(process, state, owns_group=owns_group)
        if gone:
            retired.append(process.pid)
            confirmed.set()
        return gone
    monkeypatch.setattr(_ready_runtime, '_advance_release_timeout', observed_exit)
    def phase(count):
        _ready_runtime.admit_stage(_ready_family_policy(), tmp_path, legal_tasks=count,
            retained_bytes=0, publication_bytes=0, transient_bytes_per_worker=1024)
        return _ready_runtime._bounded_ordered_spawn(_ready_family_cache_probe,
            [{'key': 'same-live-stage'} for _ in range(count)], selected_slots=1)
    def family():
        first = phase(4)
        assert confirmed.wait(8), 'Ended scope must not wait for a next scientific task to exit'
        return first, phase(1)
    record = {}
    (first, second), = _ready_runtime.run_ready_families([family],
        policy=_ready_family_policy(), root=tmp_path, workers=1, report=record)
    assert [row['hit'] for row in first] == [False, True, True, True]
    assert len({row['pid'] for row in first}) == 1
    assert first[0]['pid'] in retired and second[0]['pid'] != first[0]['pid']
    assert second[0]['hit'] is False and second[0]['scope'] != first[0]['scope']
    assert record['worker_process_peak'] == 1 and len(record['worker_pids']) == 2
    assert not multiprocessing.active_children()


def test_ready_final_scope_driver_never_bypasses_unknown_retiring_group(tmp_path, monkeypatch):
    pool, batch, state, receivers, processes, clock = _ready_pressure_fixture(
        tmp_path, monkeypatch, workers=1)
    pool.batches.clear()
    receivers[0].group_exit = False
    before = list(batch.results)
    # Complete the coordinator immediately. Its old warm idle group must still
    # pass the exact same bounded retirement check before the driver returns.
    monkeypatch.setattr(_ready_runtime, '_ReadyPool', lambda *args, **kwargs: pool)
    def ticking():
        clock[0] += .1
        return clock[0]
    monkeypatch.setattr(_ready_runtime, 'monotonic', ticking)
    with pytest.raises(ContractError, match='BOUNDED_SPAWN_RELEASE_OWNER_UNKNOWN'):
        _ready_runtime.run_ready_families([lambda: 'completed'], policy=pool.policy,
            root=tmp_path, workers=1)
    assert batch.results == before
    assert all(pid == processes[0].pid for pid, _ in state['signals'])
    assert state['groups'][processes[0].pid], 'An alive descendant must not be declared reaped'


def test_ready_live_peer_preserves_wait_for_nonjson_future_disk_shortage(tmp_path, monkeypatch):
    pool, batch, state, receivers, processes, clock = _ready_pressure_fixture(tmp_path, monkeypatch)
    _ready_pressure_mark_active(pool, batch, receivers[0], clock)
    state['available'] = 8*1024**3
    state['scratch'] = 3*1024**3
    batch.estimates.update(retained_bytes=2*1024**3, publication_bytes=1024**3)
    with pytest.raises(ContractError, match='RESOURCE_ADMISSION_ZERO:FUTURE_RETAINED_AND_PUBLICATION_SPACE'):
        pool._admission([batch])
    pending = list(batch.pending)
    pool._fill()
    assert receivers[0] in pool.active and list(batch.pending) == pending
    assert not receivers[0].sent and all(value is None for value in receivers[1].sent)
    assert not state['signals']


def test_ready_launch_count_uses_actual_family_slots_not_pending_count(tmp_path, monkeypatch):
    pool, batch, state, receivers, processes, clock = _ready_pressure_fixture(
        tmp_path, monkeypatch, workers=0)
    state['available'] = 8*1024**3
    batch.maximum = 1
    launches = []
    def launch():
        receiver = object()
        launches.append(receiver)
        pool.processes[receiver] = object()
        pool.starting[receiver] = clock[0]+30
    monkeypatch.setattr(pool, '_launch', launch)
    pool._fill()
    assert len(launches) == 1 and len(pool.processes) == 1
    assert len(batch.pending) == 81 and batch.active == 0


def test_ready_wait_rechecks_external_memory_relief_without_busy_scans(tmp_path, monkeypatch):
    from collections import deque
    pool, batch, state, receivers, processes, clock = _ready_pressure_fixture(
        tmp_path, monkeypatch, warm=False)
    pool.ceiling = batch.maximum = 2
    batch.pending = deque(range(len(batch.tasks)))
    original_index = _ready_pressure_mark_active(pool, batch, receivers[0], clock)
    original_deadline = pool.active[receivers[0]][2]
    state['available'] = 2*1024**3
    observations = []
    observed = _ready_runtime.observe_execution_resources
    def observe(root):
        observations.append(clock[0])
        return observed(root)
    monkeypatch.setattr(_ready_runtime, 'observe_execution_resources', observe)
    pool.advance()
    assert pool.capacity == 1 and receivers[1] in pool.idle
    before = len(observations)
    # Only outside activity changes. No READY, OK, ACK or pool exit arrives.
    state['available'] = 8*1024**3
    for _ in range(4):
        clock[0] += 1
        pool.advance()
    assert len(observations) == before and not receivers[1].sent
    expected_index = batch.pending[0]
    clock[0] += 1.1
    pool.advance()
    assert len(observations) == before+1
    assert len(receivers[1].sent) == 1 and receivers[1].sent[0][0] == expected_index
    assert pool.active[receivers[0]][1:3] == [original_index, original_deadline]
    assert len(pool.active) == 2 and not receivers[0].sent and not state['signals']


@pytest.mark.parametrize('failed', [False, True])
def test_ready_close_checks_entire_dead_leader_group_and_escalates(tmp_path, monkeypatch, failed):
    pool, batch, state, receivers, processes, clock = _ready_pressure_fixture(
        tmp_path, monkeypatch, workers=1)
    processes[0].alive = False
    receivers[0].group_exit = False
    original = _ready_runtime.os.killpg
    def signal_group(pid, signum):
        original(pid, signum)
        if signum == signal.SIGKILL:
            state['groups'][pid] = False
    monkeypatch.setattr(_ready_runtime.os, 'killpg', signal_group)
    def ticking():
        clock[0] += .2
        return clock[0]
    monkeypatch.setattr(_ready_runtime, 'monotonic', ticking)
    pool.close(failed=failed)
    assert (processes[0].pid, signal.SIGTERM) in state['signals']
    assert (processes[0].pid, signal.SIGKILL) in state['signals']
    assert not state['groups'][processes[0].pid] and processes[0].closed
    assert processes[0].pid not in pool.owned and not pool.processes


def test_ready_close_retains_unknown_group_and_still_reaps_other_peer(tmp_path, monkeypatch):
    pool, batch, state, receivers, processes, clock = _ready_pressure_fixture(tmp_path, monkeypatch)
    for process in processes:
        process.alive = False
    for receiver in receivers:
        receiver.group_exit = False
    original = _ready_runtime.os.killpg
    def signal_group(pid, signum):
        original(pid, signum)
        if signum == signal.SIGTERM and pid == processes[1].pid:
            state['groups'][pid] = False
    monkeypatch.setattr(_ready_runtime.os, 'killpg', signal_group)
    def ticking():
        clock[0] += .2
        return clock[0]
    monkeypatch.setattr(_ready_runtime, 'monotonic', ticking)
    with pytest.raises(ContractError, match='BOUNDED_SPAWN_RELEASE_OWNER_UNKNOWN'):
        pool.close(failed=True)
    assert state['groups'][processes[0].pid] and not processes[0].closed
    assert processes[0].pid in pool.owned and receivers[0] in pool.processes
    assert processes[1].closed and processes[1].pid not in pool.owned
    assert receivers[1] not in pool.processes
    assert all(pid in {p.pid for p in processes} for pid, _ in state['signals'])


def test_ready_waiting_larger_stage_retries_external_relief_with_spare_cpu(tmp_path, monkeypatch):
    from collections import deque
    from types import SimpleNamespace
    from threading import Event
    pool, batch, state, receivers, processes, clock = _ready_pressure_fixture(
        tmp_path, monkeypatch, warm=False)
    pool.ceiling = 2
    pool.cache_generation = 1
    batch.maximum = 1
    batch.pending = deque([0]); batch.remaining = 1
    batch.results = [_ready_runtime._READY_MISSING] + [{'done': i} for i in range(1, len(batch.tasks))]
    _ready_pressure_mark_active(pool, batch, receivers[0], clock)
    waiting = SimpleNamespace(**vars(batch))
    waiting.estimates = {**batch.estimates, 'memory_bytes_per_worker': 2*1024**3}
    waiting.tasks = [None]; waiting.results = [_ready_runtime._READY_MISSING]
    waiting.pending = deque([0]); waiting.active = 0; waiting.remaining = 1
    waiting.admission = {}; waiting.event = Event(); waiting.error = None
    waiting.release_report = {}
    pool.waiting.append(waiting)
    state['available'] = 2*1024**3
    pool.advance()
    assert waiting in pool.waiting and len(pool.active) == 1
    state['available'] = 8*1024**3
    clock[0] += 5.1
    pool.advance()
    assert waiting not in pool.waiting and waiting in pool.batches
    assert receivers[1] in pool.active and pool.active[receivers[1]][0] is waiting
    assert len(receivers[1].sent) == 1 and not receivers[0].sent and not state['signals']


def _ready_reuse_value(task, *, label, ballast):
    from padml import runtime
    return {'value': task, 'label': label, 'size': len(ballast),
            'scope': runtime._READY_PREPARATION_SCOPE, 'pid': os.getpid()}


def _ready_reuse_cache_files(task, *, root):
    # This test-only hook proves metadata crossed the real multiprocessing pipe.
    with (root/'cache-hook.txt').open('a') as stream:
        stream.write(f'{os.getpid()}:{task}\n')
    return ()


def _ready_reuse_wire_probe(monkeypatch):
    """Measure real parent Connection messages without changing worker code."""
    from multiprocessing.reduction import ForkingPickler
    original_context = _ready_runtime.get_context
    original_pool = _ready_runtime._ReadyPool
    messages, pools = [], []
    class RecordedConnection:
        def __init__(self, connection): self.connection = connection
        def fileno(self): return self.connection.fileno()
        def recv(self): return self.connection.recv()
        def close(self): return self.connection.close()
        def send(self, value):
            if value is not None:
                _, call, _ = value
                function, task, scope, _ = call[:4]
                messages.append((self, scope, function is None, len(ForkingPickler.dumps(value))))
            return self.connection.send(value)
    class RecordedContext:
        def __init__(self, context): self.context = context
        def Process(self, *args, **kwargs): return self.context.Process(*args, **kwargs)
        def Pipe(self, **kwargs):
            receiver, sender = self.context.Pipe(**kwargs)
            return RecordedConnection(receiver), sender
    def make_pool(*args, **kwargs):
        pool = original_pool(*args, **kwargs); pools.append(pool)
        return pool
    monkeypatch.setattr(_ready_runtime, 'get_context',
                        lambda name: RecordedContext(original_context(name)))
    monkeypatch.setattr(_ready_runtime, '_ReadyPool', make_pool)
    return messages, pools


@pytest.mark.parametrize('reuse', [False, True])
def test_ready_opt_in_function_serializes_once_per_worker_scope(tmp_path, monkeypatch, ready_family_host, reuse):
    from functools import partial
    messages, pools = _ready_reuse_wire_probe(monkeypatch)
    job = partial(_ready_reuse_value, label='kept', ballast=b'x'*(512*1024))
    job.reuse_worker_function = reuse
    if reuse:
        job.cache_files = partial(_ready_reuse_cache_files, root=tmp_path)
    def call():
        _ready_runtime.admit_stage(_ready_family_policy(), tmp_path, legal_tasks=4,
            retained_bytes=0, publication_bytes=0, transient_bytes_per_worker=1024)
        return _ready_runtime._bounded_ordered_spawn(job, [3, 1, 4, 2], selected_slots=1)
    record = {}
    rows, = _run_ready_families([call], policy=_ready_family_policy(), root=tmp_path,
                               workers=1, report=record)
    assert [r['value'] for r in rows] == [3, 1, 4, 2]
    assert all(r['label'] == 'kept' and r['size'] == 512*1024 for r in rows)
    assert len(messages) == 4 and len({r['pid'] for r in rows}) == 1
    assert messages[0][2] is False and messages[0][3] > 512*1024
    assert all(m[2] is reuse for m in messages[1:])
    assert all((m[3] < 1024) if reuse else (m[3] > 512*1024) for m in messages[1:])
    if reuse:
        assert (tmp_path/'cache-hook.txt').read_text().splitlines() == [
            f'{rows[0]["pid"]}:{value}' for value in [3, 1, 4, 2]]
    assert all(not p.bound_function_scopes and not p.processes for p in pools)
    assert not multiprocessing.active_children()


def test_ready_alternating_scopes_rebind_only_the_current_worker_function(tmp_path, monkeypatch, ready_family_host):
    from functools import partial
    messages, pools = _ready_reuse_wire_probe(monkeypatch)
    barrier = Barrier(2)
    def call(label):
        barrier.wait(timeout=5)
        job = partial(_ready_reuse_value, label=label, ballast=b'x'*1024)
        job.reuse_worker_function = True
        _ready_runtime.admit_stage(_ready_family_policy(), tmp_path, legal_tasks=4,
            retained_bytes=0, publication_bytes=0, transient_bytes_per_worker=1024)
        return _ready_runtime._bounded_ordered_spawn(job, [1, 2, 3, 4], selected_slots=1)
    answers = _run_ready_families([lambda:call('a'), lambda:call('b')],
        policy=_ready_family_policy(), root=tmp_path, workers=1)
    assert [[r['label'] for r in rows] for rows in answers] == [['a']*4, ['b']*4]
    scopes = [{r['scope'] for r in rows} for rows in answers]
    assert all(len(s) == 1 for s in scopes) and not scopes[0].intersection(scopes[1])
    last = {}
    for receiver, scope, omitted, _ in messages:
        assert omitted is (last.get(receiver) == scope)
        last[receiver] = scope
    assert all(not p.bound_function_scopes and not p.processes for p in pools)
    assert not multiprocessing.active_children()


@pytest.mark.parametrize('bad_reference', ['unbound', 'replaced', 'not_live'])
def test_ready_worker_rejects_unknown_or_ended_function_scope(tmp_path, bad_reference):
    from functools import partial
    context = multiprocessing.get_context('spawn')
    receiver, sender = context.Pipe(duplex=True)
    process = context.Process(target=_spawn_task_entry, args=(_ready_runtime._ready_leaf, sender, False))
    process.start(); sender.close()
    try:
        assert receiver.poll(5)
        assert receiver.recv() == {'status':'READY', 'process_group':process.pid}
        def step(function, value, scope, live):
            call = (function, value, scope, live)
            if function is not None:
                call += ({'reuse':True, 'cache_files':None},)
            receiver.send((value, call, time.monotonic()+30))
            assert receiver.poll(5)
            answer = receiver.recv()
            assert answer['status'] == 'OK' and answer['index'] == value
            assert answer['result']['scope'] == scope
            return answer['result']['label']
        if bad_reference != 'unbound':
            a = partial(_ready_reuse_value, label='a', ballast=b'a'*64)
            a.reuse_worker_function = True
            b = partial(_ready_reuse_value, label='b', ballast=b'b'*64)
            b.reuse_worker_function = True
            assert step(a, 0, 11, (11,)) == step(None, 1, 11, (11,)) == 'a'
            assert step(b, 2, 12, (11,12)) == step(None, 3, 12, (11,12)) == 'b'
        scope, live = (12, (11,)) if bad_reference == 'not_live' else (11, (11,12))
        receiver.send((4, (None, 4, scope, live), time.monotonic()+30))
        process.join(timeout=5)
        assert not process.is_alive() and process.exitcode != 0
        assert receiver.poll(1)
        with pytest.raises(EOFError): receiver.recv()
    finally:
        if process.is_alive():
            os.killpg(process.pid, signal.SIGKILL)
            process.join(timeout=5)
        receiver.close(); process.close()
    assert not multiprocessing.active_children()
