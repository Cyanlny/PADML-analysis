"""The original S1 owner must retain its actual summaries at the S2 boundary."""
import copy
import pytest

from padml import f2_kernel as kernel, f5
from padml.bundle import canonical_json_bytes
from test_primary_outer12_rsf_consume import _case


@pytest.mark.parametrize("damage", [None, "history-count", "compiler"])
def test_transported_partial_prefix_reopens_original_successor(tmp_path, monkeypatch, damage):
    import json
    import os
    from pathlib import Path
    from padml import f4
    from padml.bundle import ContractError, sha256_bytes
    location = os.environ.get("PADML_UNFITTED_RSF_SCOPED_SOURCE")
    if not location:
        pytest.skip("requires retained UNFITTED scoped source metadata")
    source = Path(location)
    values = {name: (source / "primary-preparation" / name).read_bytes()
              for name in ("input.json", "result.json", "numbers.json")}
    result = json.loads(values["result.json"])
    assert list(result["search_trace"]) == ["S1", "S2", "S3A", "S3B1"]
    del result["search_trace"]["S1"]
    result["s1_consumed_history"] = {"report": {"sha256": "a" * 64, "size_bytes": 100},
        "predecessor_execution_sha256": [f"{i:064x}" for i in range(7)],
        "consumed_model_coordinates": 119 if damage == "history-count" else 120,
        "score_trace_status": "NOT_RETAINED"}
    values["result.json"] = canonical_json_bytes(result)
    index = json.loads(values["numbers.json"])
    index["result_sha256"] = sha256_bytes(values["result.json"])
    index["members"]["result.json"] = {"sha256": index["result_sha256"], "size_bytes": len(values["result.json"])}
    index["identity_sha256"] = sha256_bytes(canonical_json_bytes({k: v for k, v in index.items() if k != "identity_sha256"}))
    values["numbers.json"] = canonical_json_bytes(index)
    target = tmp_path / "metadata"
    target.mkdir()
    for name, raw in values.items():
        (target / name).write_bytes(raw)
    receipt = {**json.loads((source / "primary-compilation.json").read_bytes()), **result,
        "compilation_source_identity": "f" * 64 if damage == "compiler" else
            sha256_bytes(canonical_json_bytes(f4._f45_source_member_sha256())),
        "preparation_metadata": {name: {"sha256": sha256_bytes(raw), "size_bytes": len(raw)} for name, raw in values.items()}}
    producer = source / "primary-producer.zip"
    manifest = f4.load_f45_source_bundle(producer)
    members = {row["path"]: row["sha256"] for row in manifest["members"]}
    # Finite real-code compatibility has its own fixture tests. All transported
    # metadata, source roles, original task reconstruction and checks stay real.
    def proof(path, **options):
        assert path == producer and options == {"primary_rsf_inputs": True}
        return members
    monkeypatch.setattr(f4, "_retained_full0_source_members", proof)
    if damage:
        with pytest.raises(ContractError):
            f5._primary_rsf_prepared_input(values["input.json"], target, producer, compilation_receipt=receipt)
    else:
        child, units = f5._primary_rsf_prepared_input(values["input.json"], target, producer, compilation_receipt=receipt)
        assert len(units) == 75 and sum(map(len, units.values())) == 300
        assert list(units) == result["task_ids"]
        assert [{"task_id": name, "producer_tasks": tasks} for name, tasks in units.items()] == result["next_atomic_units"]
        assert child["primary_search_source"] == json.loads(values["input.json"])["spec"]["primary_search_source"]


@pytest.mark.parametrize("damage", [None, "candidate", "parameters", "units", "horizon", "order", "mean", "source", "digest"])
@pytest.mark.parametrize("missing_s1", [False, True])
def test_saved_prefix_reaches_only_new_original_stage(tmp_path, monkeypatch, damage, missing_s1):
    import os
    import json
    from pathlib import Path
    from padml.bundle import ContractError
    location = os.environ.get("PADML_UNFITTED_RSF_PREFIX")
    if not location:
        pytest.skip("requires the retained UNFITTED original S3B2 preparation")
    root = Path(location)
    spec = json.loads((root / "input.json").read_bytes())["spec"]
    prefix = json.loads((root / "result.json").read_bytes())
    assert list(prefix["search_trace"]) == ["S1", "S2", "S3A", "S3B1"]
    if missing_s1:
        del prefix["search_trace"]["S1"]
        prefix["s1_consumed_history"] = {"report": {"sha256": "a" * 64, "size_bytes": 100},
            "predecessor_execution_sha256": [f"{i:064x}" for i in range(7)],
            "consumed_model_coordinates": 120, "score_trace_status": "NOT_RETAINED"}
    original_digest = kernel._sha(prefix)
    first_stage = "S2" if missing_s1 else "S1"
    row = prefix["search_trace"][first_stage][0]
    if damage == "candidate": row["candidate_id"] = "WRONG"
    elif damage == "parameters": row["parameters"]["num.trees"] += 1
    elif damage == "units": row["evaluation_units"] -= 1
    elif damage == "horizon": row["selection_horizon_months"] = 24
    elif damage == "order": prefix["search_trace"][first_stage].reverse()
    elif damage == "mean": row["mean_ibs"] += .1
    elif damage == "source": prefix["primary_search_source"]["outer_fold"] = 2
    elif damage == "digest": prefix["model_coordinate_count"] += 1
    control = {"prepared_calls": [], "prepare_only": True, "task_ids": None, "completed": False,
        "primary_rsf_retained_prefix": prefix,
        "primary_rsf_retained_prefix_sha256": original_digest if damage == "digest" else kernel._sha(prefix)}
    if damage == "completion":
        control["batches"] = [(tmp_path, {"phase": f5._a12_q_stop_phase(
            "S3B2", refit=True, family="RSF", rsf_pool_workers=spec["pool_workers"])[0]})]
    spec["native_search_batch"] = control
    registered = {"diagnostic_partitions": [], "partitions": [
        {"kind": "INNER", "repeat": repeat, "inner_fold": part,
         "partition_id": f"INNER_F1_R{repeat}_K{part}"}
        for repeat in range(1, 4) for part in range(1, 6)]}
    reached = []
    def next_stage(actual_spec, actual_registered, tasks, *args):
        assert len(tasks) == 300 and all(task["task_id"].startswith("S3B2_") for task in tasks)
        reached.append(tasks)
        raise RuntimeError("UNFITTED_NEXT_ORIGINAL_STAGE")
    monkeypatch.setattr(kernel, "_evaluate_r_prediction_batch", next_stage)
    monkeypatch.setattr(kernel, "_trial_evaluation_summary", lambda *a, **k: pytest.fail("PREFIX_RESCORING_FORBIDDEN"))
    if damage:
        with pytest.raises(ContractError):
            kernel._run_r_registered_rsf(spec, registered, tmp_path, tmp_path, search_only=True,
                retained_search_prefix=prefix)
        assert not reached
    else:
        with pytest.raises(RuntimeError, match="UNFITTED_NEXT_ORIGINAL_STAGE"):
            kernel._run_r_registered_rsf(spec, registered, tmp_path, tmp_path, search_only=True,
                retained_search_prefix=prefix)
        assert len(reached) == 1


def test_missing_s1_blocks_complete_q_before_terminal_numerical_consumption(tmp_path, monkeypatch):
    test_saved_prefix_reaches_only_new_original_stage(tmp_path, monkeypatch, "completion", True)


def test_s1_summary_survives_original_s2_boundary_without_recomputation(tmp_path, monkeypatch):
    spec, units, control, _ = _case(tmp_path, monkeypatch)
    base = next(iter(units.values()))[0]
    partitions = []
    for repeat in range(1, 4):
        for part in range(1, 6):
            row = copy.deepcopy(base[6])
            row.update(partition_id=f"INNER_F2_R{repeat}_K{part}", repeat=repeat, inner_fold=part)
            partitions.append(row)
    registered = {**base[1], "partitions": partitions, "diagnostic_partitions": []}
    registered.pop("projected_partition_ids"); registered.pop("projected_partition_count")
    spec["candidate_trials"] = {stage: [{"trial_id": f"{stage}-{i}",
        "parameters": {"splitrule": "logrank", "UNFITTED": i},
        "parameter_sha256": f"{i:064x}"} for i in range(1, count + 1)]
        for stage, count in (("S1", 24), ("S2", 8))}
    (tmp_path / "q/input.json").write_bytes(canonical_json_bytes({"spec": {
        k: v for k, v in spec.items() if k != "native_search_batch"}}))
    seen, summaries = [], []

    def numbers(_, function, original_units, batches, phase, input_ref):
        rows = [row for call, _ in original_units.values() for row in call[2]]
        assert len(rows) == 120 and all(row["task_id"].startswith("S1_") for row in rows)
        seen.extend(row["task_id"] for row in rows)
        control["confirmed_model_fits"] = 120
        control["used_batches"] = [kernel._sha(row) for _, row in batches]
        return [[{**{key: row[key] for key in ("task_id", "partition_id", "imputation")},
            "prediction_seal_sha256": "a" * 64, "evaluation_response_sha256": "b" * 64,
            "evaluation_ids_sha256": "c" * 64, "ibs_0_12": .1, "stopping": None,
            "sealed_prediction": {"UNFITTED": True}} for row in call[2]]
            for call, _ in original_units.values()]

    def summary(values, context, m):
        assert m == 1 and len(values) == 5
        summaries.append(values)
        return {"evaluation_units": 5, "selection_horizon_months": 12,
                "mean_ibs": .1, "maximum_ibs": .1}

    monkeypatch.setattr(f5, "_consume_q_search_batches", numbers)
    monkeypatch.setattr(kernel, "_accumulate_registered_evaluations", lambda *a: None)
    monkeypatch.setattr(kernel, "_trial_scoring_context", lambda *a, **k: {})
    monkeypatch.setattr(kernel, "_trial_evaluation_summary", summary)
    monkeypatch.setattr(f5, "_execute_q_search_batch", lambda *a, **k: pytest.fail("FIT_FORBIDDEN"))
    with pytest.raises(f5._QBatchBoundary) as caught:
        kernel._run_r_registered_rsf(spec, registered, tmp_path, tmp_path, search_only=True)
    result = caught.value.result
    assert len(seen) == len(set(seen)) == 120 and len(summaries) == 24
    assert result["search_trace"] == {"S1": control["primary_rsf_s1_trace"]}
    assert len(result["search_trace"]["S1"]) == 24 and result["complete_search_trace"] is False
    assert result["model_coordinate_count"] == 200 and len(result["next_atomic_units"]) == 75
    assert result["new_model_fits"] == 0
