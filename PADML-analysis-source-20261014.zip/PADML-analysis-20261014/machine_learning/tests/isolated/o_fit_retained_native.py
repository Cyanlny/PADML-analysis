"""Finite synthetic O_fit replay tests. Native leaves are UNFITTED, never fit."""
from __future__ import annotations

import ast
import copy
import csv
import hashlib
import importlib.abc
import io
import json
import math
import os
from pathlib import Path
import subprocess
import sys

import pytest

TEST_ROOT = Path(__file__).resolve().parent
GUARD_CALLS = []


def forbidden(*args, **kwargs):
    GUARD_CALLS.append((str(args[:1]), sorted(kwargs)))
    raise AssertionError("REAL_SCIENTIFIC_OR_PROCESS_EXECUTION_FORBIDDEN")


for name in ("run", "Popen", "call", "check_call", "check_output"):
    setattr(subprocess, name, forbidden)
os.system = os.popen = forbidden


class NoScienceImports(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if fullname.split(".")[0] in {"numpy", "scipy", "pandas", "sklearn", "torch", "xgboost", "pycox", "rpy2"}:
            raise AssertionError("SCIENTIFIC_LIBRARY_IMPORT_FORBIDDEN:" + fullname)
        return None


sys.meta_path.insert(0, NoScienceImports())
from padml import f4, f5, f2_kernel, runtime
from padml.bundle import ContractError, canonical_json_bytes, read_safe_zip, sha256_bytes, strict_json_bytes, write_deterministic_zip

CANDIDATE = Path(f4.__file__).resolve().parents[1]
if "PADML_TEST_F4_SHA256" in os.environ:
    assert hashlib.sha256((CANDIDATE / "padml/f4.py").read_bytes()).hexdigest() == os.environ["PADML_TEST_F4_SHA256"]
if "PADML_TEST_SOURCE_ROOT" in os.environ:
    assert CANDIDATE == Path(os.environ["PADML_TEST_SOURCE_ROOT"]).resolve()
SOURCE_BEFORE = {str(p.relative_to(CANDIDATE)): hashlib.sha256(p.read_bytes()).hexdigest()
                 for p in CANDIDATE.rglob("*") if p.is_file()}
TREE = ast.parse((CANDIDATE / "padml/f4.py").read_text())
PREPARE = next(n for n in TREE.body if isinstance(n, ast.FunctionDef) and n.name == "_prepare_o_fit_partition")
STOP_BLOCK = next(n for n in PREPARE.body if isinstance(n, ast.If) and isinstance(n.test, ast.Name) and n.test.id == "needs_stop")
STOP_CODE = compile(ast.fix_missing_locations(ast.Module(body=[STOP_BLOCK], type_ignores=[])), str(CANDIDATE / "padml/f4.py"), "exec")


@pytest.fixture(autouse=True)
def strict_guards(monkeypatch):
    GUARD_CALLS.clear()
    for module, names in ((f4, ("_execute_f4_stop_component", "_execute_f4_model_component", "bootstrap_draws")),
                          (f2_kernel, ("_xgb_refit_predict", "_coxtime_refit_predict", "_xgb_prediction_function_seal",
                                       "_coxtime_prediction_function_seal", "_run_python_registered_xgboost",
                                       "_run_python_registered_coxtime", "_run_r_registered_rsf", "_run_r_registered_gbm"))):
        for name in names:
            if hasattr(module, name):
                monkeypatch.setattr(module, name, forbidden)
    monkeypatch.setattr(runtime, "get_context", forbidden)
    monkeypatch.setattr(runtime, "_bounded_ordered_spawn", forbidden)
    yield
    assert not GUARD_CALLS
    assert {str(p.relative_to(CANDIDATE)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in CANDIDATE.rglob("*") if p.is_file()} == SOURCE_BEFORE


def raw_csv(rows):
    s = io.StringIO(newline="")
    w = csv.DictWriter(s, fieldnames=list(rows[0]), lineterminator="\n")
    w.writeheader()
    w.writerows(rows)
    return s.getvalue().encode()


def tree_snapshot(root):
    return {p.relative_to(root).as_posix(): ("symlink", os.readlink(p)) if p.is_symlink()
            else ("file", p.read_bytes()) for p in root.rglob("*") if p.is_file() or p.is_symlink()}


def fixture_source(family):
    ids = [f"UNFITTED-P{i}" for i in range(1, 6)]
    centers = dict(zip(ids, ["38", "39", "48", "52", "55"], strict=True))
    response = {p: {"Patient_ID": p, "All_Cause_Death": "1", "Death_Followup_months": "30"} for p in ids}
    cov = {p: {"Patient_ID": p, "Center": centers[p], "AST_ALT": str(i)} for i, p in enumerate(ids, 1)}
    outer = {"kind": "OUTER", "outer_fold": 1, "repeat": 0, "inner_fold": 0, "partition_id": "UNFITTED_OUTER",
             "analysis_ids": ids, "fit_ids": ids, "validation_ids": [], "application_ids": ids}
    inner, stops = [], []
    for r in range(1, 4):
        for k in range(1, 6):
            valid = [ids[k - 1]]
            fit_ids = [p for p in ids if p not in valid]
            base = {"outer_fold": 1, "repeat": r, "inner_fold": k}
            inner.append({**base, "kind": "INNER", "partition_id": f"UNFITTED_INNER_{r}_{k}",
                          "analysis_ids": fit_ids, "fit_ids": fit_ids, "validation_ids": valid, "application_ids": ids})
            stops.append({**base, "kind": "STOP", "partition_id": f"UNFITTED_STOP_{r}_{k}",
                          "analysis_ids": fit_ids[1:], "fit_ids": fit_ids[1:], "stop_ids": fit_ids[:1],
                          "validation_ids": fit_ids[:1], "application_ids": fit_ids})
    params = ({"early_stopping_metric": "cox_deviance", "post_selection_refit": "full_main_training_at_selected_n_trees",
               "locked_iteration_mode": "full_main_training_without_reselection"} if family == "GBM_COX" else
              {"stop_scope": "training_only", "post_selection_refit": "full_main_training_at_best_rounds",
               "locked_iteration_mode": "full_main_training_without_reselection"})
    selected_field = "selected_trees" if family == "GBM_COX" else "selected_rounds"
    spec = {"family": family, "selected_parents": ["AST_ALT"], "parameters": params, selected_field: 60}
    members = [{"name": f"imp{i:02d}.csv", "sha256": sha256_bytes(f"UNFITTED-M{i}".encode()), "size_bytes": i} for i in range(1, 21)]
    model = {"family": family, "fold": 1, "selected_spec": spec,
             "selected_spec_sha256": sha256_bytes(canonical_json_bytes(spec)),
             "family_design_binding": {"mode": "RAW_CANONICAL", "selected_parents": ["AST_ALT"]},
             "model_input": {"model_partitions": [{"kind": "OUTER", "fit_covariate_members": members,
                "fit_covariate_member_set_sha256": sha256_bytes(canonical_json_bytes(members)),
                "fit_ids_sha256": sha256_bytes(canonical_json_bytes(ids))}]}}
    frozen = {"models": {(1, family): model}, "registry": {"outer": [outer], "inner": inner, "stopping": stops},
              "response_csv": raw_csv(list(response.values())), "centers": centers,
              "f1_manifest": {"identity": sha256_bytes(b"UNFITTED-F1")}}
    return frozen, {"partitions": [outer, *inner, *stops]}, cov, response


def lock_value(family, imp):
    return {"UNFITTED": True, "selected_trees" if family == "GBM_COX" else "selected_rounds": 20 + imp}


def probability(imp, n):
    return [[1.0] + [1.0 - imp / 100] * 36 for _ in range(n)]


def task_jobs(model, part, cov, response, locks=None):
    family = model["family"]
    jobs = []
    for imp, name in enumerate(f4._o_fit_component_names(1, part["repeat"], part["inner_fold"], stop=part["kind"] == "STOP"), 1):
        coords = {"purpose": "O_FIT", "outer_fold": 1, "repeat": part["repeat"], "inner_fold": part["inner_fold"], "imputation": imp}
        params = copy.deepcopy(model["selected_spec"])
        if part["kind"] == "INNER":
            params.update({key: val for key, val in (locks or {i: lock_value(family, i) for i in range(1, 21)})[imp].items() if key != "UNFITTED"})
        task = {"family": family, "selected_parents": ["AST_ALT"], "parameters": params, "imputation": imp,
                "f4_coordinates": coords, "registered_model_seed": f4._f4_model_seed(family, coords),
                "model_seed": f4._f4_model_seed(family, coords), "row_count": len(part["fit_ids"]), "family_design_column_count": 1}
        entries = {"task.json": canonical_json_bytes(task),
                   "recipe.json": canonical_json_bytes({"preprocessing_mode": "F2_RAW_CANONICAL_AUTHORITY_LEVELS", "UNFITTED": True}),
                   "fit-covariates.csv": raw_csv([cov[p] for p in part["fit_ids"]]),
                   "fit-response.csv": raw_csv([response[p] for p in part["fit_ids"]]),
                   "prediction-covariates.csv": raw_csv([cov[p] for p in (part["fit_ids"] if part["kind"] == "OUTER" else part["validation_ids"])])}
        if part["kind"] == "STOP":
            task["stop_parameters"] = f2_kernel._engine_parameters(family, model["selected_spec"]["parameters"])
            entries["task.json"] = canonical_json_bytes(task)
            entries["stop-response.csv"] = raw_csv([response[p] for p in part["validation_ids"]])
        jobs.append({"name": name, "entries": entries})
    return jobs


def install(monkeypatch, tmp_path, family="XGBOOST_COX", order="reverse", failure=None):
    frozen, registered, cov, response = fixture_source(family)
    model = frozen["models"][1, family]
    native = tmp_path / "retained"
    native.mkdir()
    (native / "fits").mkdir()
    (native / "stops").mkdir()
    for part in registered["partitions"]:
        for job in task_jobs(model, part, cov, response):
            entries = job["entries"]
            task = strict_json_bytes(entries["task.json"])
            if part["kind"] == "STOP":
                value = {"UNFITTED": True, "imputation": task["imputation"]}
                extra = {"model.bin": b"UNFITTED_STOP", "native-function.json": canonical_json_bytes(value),
                         "lock.json": canonical_json_bytes(lock_value(family, task["imputation"]))}
                if family == "GBM_COX":
                    extra.update({"native.stdout": b"UNFITTED", "native.stderr": b""})
                kind = "stops"
            else:
                parsed = f4._f4_native_component_inputs(entries)
                imp = task["imputation"]
                row = f4._f4_native_prediction(task, parsed[4], probability(imp, len(parsed[4])))
                extra = {"model.bin": f"UNFITTED_MODEL_{job['name']}".encode(), "baseline.bin": f"UNFITTED_BASELINE_{job['name']}".encode(),
                         "fit-health.json": b'{"UNFITTED":true}', "training-prediction.json": canonical_json_bytes(probability(imp, len(parsed[2]))),
                         "prediction.json": canonical_json_bytes(row)}
                kind = "fits"
            write_deterministic_zip(native / kind / (job["name"] + ".zip"), {**entries, **extra})
    calls = {"materialize": 0, "pools": [], "depth": 0, "max_depth": 0, "stops": [], "audit": [], "engine": [], "metrics": [], "cache": []}
    monkeypatch.setattr(f4, "resolve_pool_workers", lambda value: 24)
    monkeypatch.setattr(f4, "load_f4_inputs", lambda *a, **k: {"o_fit_source": frozen})
    monkeypatch.setattr(f4, "_load_o_fit_selection", lambda *a: {"locked_family": family})
    def materialize(source, outer, root):
        assert source is frozen and outer == 1
        calls["materialize"] += 1
        root.mkdir()
        (root / "UNFITTED_F1.txt").write_bytes(b"UNFITTED rematerialization")
        return registered
    monkeypatch.setattr(f4, "_materialize_o_fit_fold", materialize)
    def prepare(model_arg, part, source, *, stop_evidence=None, replay_evidence=None, replay_workers=None, replayed_stops=None):
        assert model_arg is model and source is frozen
        needs_stop = part["kind"] == "INNER"
        assert (stop_evidence is not None) == needs_stop
        locks = {}
        if needs_stop:
            scope = {"needs_stop": True, "stop_evidence": stop_evidence, "partition": part, "fit_ids": part["fit_ids"],
                     "model": model, "frozen_source": frozen, "replay_evidence": replay_evidence,
                     "replay_workers": replay_workers, "replayed_stops": replayed_stops, "locks": locks,
                     "_prepare_o_fit_partition": prepare, "_require": f4._require,
                     "_replay_f4_stop_batch": f4._replay_f4_stop_batch, "strict_json_bytes": strict_json_bytes}
            exec(STOP_CODE, scope)
            calls["cache"].append((part["repeat"], part["inner_fold"], copy.deepcopy(locks)))
        return task_jobs(model, part, cov, response, locks)
    monkeypatch.setattr(f4, "_prepare_o_fit_partition", prepare)
    def pool(worker, jobs, *, selected_slots):
        assert selected_slots == 24 and calls["depth"] == 0
        assert worker in (f4._replay_f4_stop_component, f4._replay_f4_model_component)
        kind = "STOP" if worker is f4._replay_f4_stop_component else "MODEL"
        calls["pools"].append((kind, len(jobs)))
        calls["depth"] += 1
        calls["max_depth"] = max(calls["max_depth"], calls["depth"])
        try:
            indices = list(range(len(jobs)))
            if order == "reverse":
                indices.reverse()
            values = {i: worker(jobs[i]) for i in indices}
            return [values[i] for i in range(len(jobs))]
        finally:
            calls["depth"] -= 1
    monkeypatch.setattr(f4, "_bounded_ordered_spawn", pool)
    def stop_native(entries, root, *, replay):
        assert replay is True and (root / "model.bin").read_bytes() == b"UNFITTED_STOP"
        task = strict_json_bytes(entries["task.json"])
        calls["stops"].append(task["f4_coordinates"])
        (root / "UNFITTED_NATIVE_OUTPUT.json").write_bytes(canonical_json_bytes({"UNFITTED": True, "task": task}))
        if failure == "STOP" and len(calls["stops"]) == 3:
            (root / "native-failure.json").write_bytes(b'{"UNFITTED_FAILURE":"STOP"}')
            raise ContractError("UNFITTED_STOP_FAILURE")
        return {"UNFITTED": True, "imputation": task["imputation"]}, {"imp": task["imputation"]}, {"UNFITTED": True}
    monkeypatch.setattr(f4, "_run_f4_stop_native", stop_native)
    def lock(entries, sealed, runtime_value, *, native_evaluation=None):
        assert runtime_value == {"UNFITTED": True}
        if native_evaluation is not None:
            native_evaluation.update(UNFITTED=True, values=[0.3, 0.2], imputation=sealed["imp"])
        return lock_value(family, sealed["imp"])
    monkeypatch.setattr(f4, "_f4_stop_lock", lock)
    def audit(family_arg, model_bytes, baseline, health, task, *, native_evidence):
        assert family_arg == family and health == {"UNFITTED": True}
        assert model_bytes.startswith(b"UNFITTED_MODEL_") and baseline.startswith(b"UNFITTED_BASELINE_")
        native_evidence.mkdir()
        (native_evidence / "UNFITTED_AUDIT.json").write_bytes(canonical_json_bytes(task))
        calls["audit"].append(task["f4_coordinates"])
        return {"UNFITTED": True, "imputation": task["imputation"]}
    monkeypatch.setattr(f5, "_validate_retained_model_objects", audit)
    def engine(family_arg, task, training, fit_response, recipe, *, retained_objects, replay_evidence, prediction_rows=None):
        assert family_arg == family and retained_objects[0].startswith(b"UNFITTED_MODEL_")
        assert retained_objects[1].startswith(b"UNFITTED_BASELINE_") and recipe["UNFITTED"]
        assert [row["Patient_ID"] for row in training] == list(fit_response)
        replay_evidence.mkdir()
        rows = training if prediction_rows is None else prediction_rows
        if prediction_rows is not None:
            assert not set(fit_response).intersection(row["Patient_ID"] for row in prediction_rows)
        result = {"survival": probability(task["imputation"], len(rows))}
        (replay_evidence / "UNFITTED_PREDICTION.json").write_bytes(canonical_json_bytes(result))
        calls["engine"].append((task["f4_coordinates"], "training" if prediction_rows is None else "application"))
        if failure == "MODEL" and len(calls["engine"]) == 3:
            (replay_evidence / "native-failure.json").write_bytes(b'{"UNFITTED_FAILURE":"MODEL"}')
            raise ContractError("UNFITTED_MODEL_FAILURE")
        return result
    monkeypatch.setattr(f5, "_execute_final_refit_engine", engine)
    def metrics(data, raw_response, *, include_center_scopes, native_archive):
        assert include_center_scopes is False and set(data["patient_ids"]) == set(response)
        calls["metrics"].append((data, native_archive))
        write_deterministic_zip(native_archive, {"UNFITTED_INPUT.json": canonical_json_bytes(data), "UNFITTED_METRICS.json": b'{"UNFITTED":true}'})
        if failure == "METRIC":
            raise ContractError("UNFITTED_METRIC_FAILURE")
        row = {"ibs_0_to": {"24": 0.1}, "brier_monthly": [0.0] + [0.1] * 36,
               "discrimination": {"uno_c_24": {"value": 0.7}, "auc": {"24": {"value": 0.7}}},
               "calibration": {"horizons": {"24": {"slope": 1.0}}}}
        return {"scopes": [{"scope": "MICRO", "families": {family: row}}]}
    monkeypatch.setattr(f4, "evaluate_predictions", metrics)
    return frozen, native, calls


def execute(tmp_path, native, **kwargs):
    return f4.execute_o_fit_bundle(tmp_path, tmp_path / "UNFITTED_SELECTION.zip", tmp_path / "result.zip",
                                   outer_fold=1, workers=24, retained_native=native, **kwargs)


@pytest.mark.parametrize("family", ["GBM_COX", "XGBOOST_COX"])
def test_complete_resume_canonical_and_evidence(monkeypatch, tmp_path, family):
    outputs = []
    for order in ("forward", "reverse"):
        root = tmp_path / order
        root.mkdir()
        with monkeypatch.context() as patch:
            frozen, native, calls = install(patch, root, family=family, order=order)
            before = tree_snapshot(native)
            result = execute(root, native)
            evidence = Path(result["native_replay_evidence"])
            assert result["model_fit_count"] == result["stopping_fit_count"] == 0
            assert result["replayed_model_count"] == 320 and result["replayed_stop_count"] == 300
            assert calls["pools"] == [("STOP", 300)] + [("MODEL", 20)] * 16 and calls["max_depth"] == 1
            assert len(calls["stops"]) == 300 and len(calls["audit"]) == 320 and len(calls["engine"]) == 620
            assert len({canonical_json_bytes(v) for v in calls["stops"]}) == 300
            assert len(calls["cache"]) == 15 and all(len(v[2]) == 20 for v in calls["cache"])
            assert len(calls["metrics"]) == 6 and len({id(calls["metrics"][i][0]) for i in (0, 2, 4)}) == 1
            assert len(list((evidence / "stop-replay").glob("*/replayed-evaluation.json"))) == 300
            assert len(list((evidence / "replay").glob("R*_K*/mi-predictions.json"))) == 16
            assert len(list((evidence / "replay").glob("R*_K*/*/object-audit.json"))) == 320
            assert len(list((evidence / "replay").glob("metrics-r*/*.zip"))) == 6
            assert not (evidence / "f1").exists() and tree_snapshot(native) == before
            entries = read_safe_zip(root / "result.zip")
            assert len(entries) == 621 and set(entries) == f4._o_fit_native_members(frozen["models"][1, family]) | {"o-fit-execution.json"}
            assert all(entries[name] == before[name][1] for name in before)
            manifest = strict_json_bytes(entries["o-fit-execution.json"])
            assert manifest["schema_version"] == "2.0.0" and [r["repeat"] for r in manifest["rows"]] == [1, 2, 3]
            assert strict_json_bytes((evidence / "replay/rows.json").read_bytes()) == manifest["rows"]
            expected = math.fsum(1.0 - imp / 100 for imp in range(1, 21)) / 20
            for p in (evidence / "replay").glob("R*_K*/mi-predictions.json"):
                mi = strict_json_bytes(p.read_bytes())
                assert [row["f4_coordinates"]["imputation"] for row in mi["components"]] == list(range(1, 21))
                assert all(row == [1.0] + [expected] * 36 for row in mi["pooled"])
            outputs.append((root / "result.zip").read_bytes())
    assert outputs[0] == outputs[1]


@pytest.mark.parametrize("damage", ["missing_stop", "missing_fit", "extra_stop", "extra_fit", "symlink_file", "symlink_directory", "wrong_outer"])
def test_preflight_damage_stops_before_native(monkeypatch, tmp_path, damage):
    _, native, calls = install(monkeypatch, tmp_path)
    fit, stop = native / "fits/O1_R0_K0_M01.zip", native / "stops/O1_R1_K1_M01_STOP.zip"
    if damage.startswith("missing"):
        (stop if damage == "missing_stop" else fit).unlink()
    elif damage.startswith("extra"):
        (native / ("stops" if damage == "extra_stop" else "fits") / "EXTRA.zip").write_bytes(b"UNFITTED")
    elif damage == "symlink_file":
        fit.unlink()
        fit.symlink_to(native / "fits/O1_R0_K0_M02.zip")
    elif damage == "symlink_directory":
        (native / "fits").rename(tmp_path / "actual-fits")
        (native / "fits").symlink_to(tmp_path / "actual-fits", target_is_directory=True)
    else:
        fit.rename(native / "fits/O2_R0_K0_M01.zip")
    before = tree_snapshot(native)
    with pytest.raises(ContractError, match="F4_O_FIT_RETAINED_NATIVE_"):
        execute(tmp_path, native)
    assert calls["materialize"] == 0 and calls["pools"] == []
    assert tree_snapshot(native) == before and not (tmp_path / "result.zip").exists()


@pytest.mark.parametrize("kind", ["STOP", "MODEL"])
def test_native_coordinate_mismatch_rejected(monkeypatch, tmp_path, kind):
    _, native, calls = install(monkeypatch, tmp_path, order="forward")
    path = native / ("stops/O1_R1_K1_M01_STOP.zip" if kind == "STOP" else "fits/O1_R0_K0_M01.zip")
    entries = read_safe_zip(path)
    task = strict_json_bytes(entries["task.json"])
    task["f4_coordinates"]["outer_fold"] = 2
    entries["task.json"] = canonical_json_bytes(task)
    path.unlink()
    write_deterministic_zip(path, entries)
    before = tree_snapshot(native)
    with pytest.raises(ContractError, match="INPUT_REPLAY_MISMATCH"):
        execute(tmp_path, native)
    assert tree_snapshot(native) == before and not (tmp_path / "result.zip").exists()
    assert len(calls["stops"]) == (0 if kind == "STOP" else 300)
    assert calls["audit"] == [] and calls["metrics"] == []
    assert len(list(tmp_path.glob(".result.zip.replay-*/f1/UNFITTED_F1.txt"))) == 1


@pytest.mark.parametrize("kind", ["STOP", "MODEL", "METRIC"])
def test_leaf_failure_retained_without_retry(monkeypatch, tmp_path, kind):
    _, native, calls = install(monkeypatch, tmp_path, failure=kind)
    before = tree_snapshot(native)
    with pytest.raises(ContractError, match="UNFITTED_" + kind + "_FAILURE") as err:
        execute(tmp_path, native)
    assert any("F4_O_FIT_OUTER_EVIDENCE_RETAINED" in note for note in err.value.__notes__)
    assert tree_snapshot(native) == before and not (tmp_path / "result.zip").exists()
    work, = list(tmp_path.glob(".result.zip.replay-*"))
    assert (work / "f1/UNFITTED_F1.txt").is_file()
    if kind == "STOP":
        assert len(calls["stops"]) == 3 and calls["audit"] == [] and calls["metrics"] == []
        assert len(list(work.glob("stop-replay/*/native-failure.json"))) == 1
    elif kind == "MODEL":
        assert len(calls["stops"]) == 300 and len(calls["engine"]) == 3 and calls["metrics"] == []
        assert len(list(work.glob("replay/R0_K0/*/training/native-failure.json"))) == 1
    else:
        assert len(calls["metrics"]) == 1 and len(calls["audit"]) == 120
        assert (work / "replay/metrics-r1/apparent.zip").is_file()


@pytest.mark.parametrize("option", ["retained_stops", "fpm_native_archive"])
def test_mutually_exclusive_sources_rejected(monkeypatch, tmp_path, option):
    _, native, calls = install(monkeypatch, tmp_path)
    with pytest.raises(ContractError, match="RETAINED_NATIVE_PATH_INVALID"):
        execute(tmp_path, native, **{option: native / "stops"})
    assert calls["materialize"] == 0 and calls["pools"] == [] and not (tmp_path / "result.zip").exists()


@pytest.mark.parametrize("damage", ["entries", "archive", "evidence"])
def test_stop_cache_rejects_identity_or_independent_evidence(monkeypatch, tmp_path, damage):
    monkeypatch.setattr(f4, "_bounded_ordered_spawn", forbidden)
    monkeypatch.setattr(f4, "_replay_f4_stop_component", forbidden)
    jobs = [{"name": "M01", "entries": {"task.json": b"UNFITTED"}, "archive": tmp_path / "M01.zip"}]
    replayed = {"M01": {**jobs[0], "lock": {"selected_rounds": 21}}}
    if damage == "entries":
        jobs[0] = {**jobs[0], "entries": {"task.json": b"DIFFERENT_UNFITTED"}}
    elif damage == "archive":
        jobs[0] = {**jobs[0], "archive": tmp_path / "OTHER.zip"}
    else:
        jobs[0] = {**jobs[0], "replay_evidence": tmp_path / "NEW_EVIDENCE"}
    with pytest.raises(ContractError, match="STOP_REUSE_SOURCE_MISMATCH"):
        f4._replay_f4_stop_batch(jobs, workers=24, replayed=replayed)


def test_cli_passthrough_is_direct():
    calls = [n for n in ast.walk(TREE) if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id == "execute_o_fit_bundle"]
    assert len(calls) == 1
    value, = [kw.value for kw in calls[0].keywords if kw.arg == "retained_native"]
    assert ast.unparse(value) == "None if args.retained_native is None else args.retained_native.resolve(strict=True)"
    assert any(isinstance(n, ast.Constant) and n.value == "--retained-native" for n in ast.walk(TREE))
