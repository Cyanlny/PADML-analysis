"""Host scheduling only: synthetic bytes, no R/MICE/model/search execution."""
import ast
import copy
import hashlib
import inspect
from pathlib import Path

import pytest

from padml import f2_kernel as kernel, f4, f4_compact
from padml.bundle import ContractError, canonical_json_bytes, sha256_file, write_deterministic_zip


@pytest.fixture(autouse=True)
def no_scientific_execution(monkeypatch):
    def forbidden(*args, **kwargs):
        raise AssertionError("NO_REAL_SCIENCE_IN_HOST_POOL_TEST")
    for name in ("run", "Popen"):
        monkeypatch.setattr(f4.subprocess, name, forbidden)
    for name in ("_run_full_pipeline_mice_native", "_run_learning_selector_path",
                 "_execute_f4_model_component", "_replay_f4_model_component",
                 "_run_full_pipeline_complex_search_program", "_bounded_ordered_spawn"):
        monkeypatch.setattr(f4, name, forbidden)
    monkeypatch.setattr(kernel, "_bounded_ordered_spawn", forbidden)
    for name in ("_run_xgb_function_pool_task", "_run_xgb_function_evaluator_pool_task",
                 "_run_xgb_refit_pool_task", "_run_python_locked_evaluation_pool_task"):
        monkeypatch.setattr(kernel, name, forbidden)


def reversed_completion_pool(events):
    active = False
    def pool(worker, tasks, *, selected_slots, on_result=None):
        nonlocal active
        assert not active
        assert type(selected_slots) is int and selected_slots > 0
        events.append((worker.__name__, selected_slots, len(tasks)))
        active = True
        results = [None] * len(tasks)
        try:
            for index in reversed(range(len(tasks))):
                results[index] = worker(tasks[index])
                if on_result:
                    on_result(index, results[index])
        finally:
            active = False
        return results
    return pool


def test_b_q_refit_failure_preserves_original_margin_bits(tmp_path, monkeypatch):
    """Actual exception/capture path; an unfitted engine replaces training only."""
    import json
    from types import SimpleNamespace
    import numpy as np
    from padml import f5

    calls, original_errors = [], []
    x_train, x_test = np.arange(12, dtype=float).reshape(-1, 1), np.array([[.5], [1.5]])
    train_time, train_event = np.arange(1, 13, dtype=float), np.array([1, 0] * 6)
    margins = np.array([0., -0., np.nextafter(1., 2.), np.inf] + [1.] * 8)
    test_margins = np.array([.25, -.5])
    model_bytes = b"UNFITTED_BOOSTER_NO_REAL_TRAINING"
    objective_health = {"UNFITTED_HEALTH_FIXTURE": True}

    class UnfittedBooster:
        def predict(self, matrix, *, output_margin):
            assert output_margin is True
            return margins if matrix is x_train else test_margins

        def num_boosted_rounds(self):
            return 4

    def train(parameters, matrix, **options):
        assert parameters["nthread"] == 1 and matrix is x_train and options["num_boost_round"] == 4
        calls.append("UNFITTED_TRAIN_STUB")
        return UnfittedBooster()

    engine = SimpleNamespace(DMatrix=lambda matrix, **kwargs: matrix, train=train)
    monkeypatch.setattr(kernel, "_xgb_grouped_breslow_objective", lambda *a, **k: (None, objective_health))
    monkeypatch.setattr(kernel, "_validate_xgb_cox_objective_health", lambda value, *a: value)
    monkeypatch.setattr(f4, "_full_pipeline_python_search_binding", lambda *a: {"UNFITTED_BOUNDARY": True})
    monkeypatch.setattr(f5, "_xgb_native_model_bytes", lambda *a: model_bytes)
    task = {"task_id": "UNFITTED_B_Q_REFIT", "spec": {
        "execution_scope": "F4_FULL_PIPELINE_SEARCH", "family": "XGBOOST_COX",
        "native_search_root": str(tmp_path), "native_search_replay": False, "horizons": list(range(1, 37))}}
    loaded = {"fit_designs": [x_train], "evaluation_designs": [x_test],
              "evaluation_ids": ["UNFITTED_1", "UNFITTED_2"], "columns": ["AST_ALT"]}
    parameters = dict(max_nrounds=5000, eta=.1, max_depth=2, min_child_weight=1,
                      subsample=1, colsample_bytree=1, reg_lambda=1, reg_alpha=0,
                      gamma=0, tree_method="hist", max_bin=256)

    def original_refit(*, native_capture):
        try:
            return kernel._xgb_refit_predict(engine, parameters, x_train, train_time, train_event,
                x_test, 4, 760010001, "CPU", list(range(1, 37)), np, native_capture=native_capture)
        except ContractError as exc:
            original_errors.append(exc)
            raise

    with pytest.raises(ContractError, match="F2_XGBOOST_FIT_HEALTH_INVALID") as caught:
        f4._full_pipeline_python_search_refit(task, loaded, original_refit, np, None)
    assert caught.value is original_errors[0] and calls == ["UNFITTED_TRAIN_STUB"]
    root = tmp_path / task["task_id"]
    assert (root / "model.bin").read_bytes() == model_bytes and (root / "input.json").is_file()
    assert not (root / "baseline.bin").exists() and not (root / "prediction.json").exists()
    failure = json.loads((root / "native-failure.json").read_bytes())
    assert failure["capture_errors"] == []
    assert [frame["function"] for frame in failure["frames"]] == ["_xgb_refit_predict"]
    with np.load(root / "failure-00.npz", allow_pickle=False) as retained:
        for name, expected in (("train_margin", margins), ("evaluation_margin", test_margins),
                               ("x_train", x_train), ("train_time", train_time), ("train_event", train_event)):
            assert retained[name].dtype == expected.dtype and retained[name].shape == expected.shape
            assert retained[name].tobytes() == expected.tobytes()
    assert json.loads((root / "failure-00-objective_health.json").read_bytes()) == objective_health


def test_original_xgb_funnel_and_seed_ast_unchanged_except_dispatch():
    # Original dc008e0 function ASTs, observed before this scheduling patch.
    expected = {
        "_full_pipeline_search_seed_registry": "12309c3d24928661ab97f91ce35e0fa5e0d50f874e6ee9a0aad39a5b252a4041",
        "_full_pipeline_trial_seed": "a1da64257d88feac9788ba014ba3e9dc20840ebaa00095c98b839640bcbb1944",
        "_run_python_registered_xgboost": "30472bc7cba630025a1d1e63f6d637009ad01e7ab1b7df4190aa55687f3d0e44",
    }
    for name, digest in expected.items():
        node = ast.parse(inspect.getsource(getattr(kernel, name))).body[0]
        if name == "_run_python_registered_xgboost":
            assert node.args.kwonlyargs[-1].arg == "full_pipeline_workers"
            node.args.kwonlyargs.pop()
            node.args.kw_defaults.pop()
            calls = [n for n in ast.walk(node) if isinstance(n, ast.Call)
                     and isinstance(n.func, ast.Name) and n.func.id == "_search_task_batch"]
            assert len(calls) == 4
            for call in calls:
                assert call.keywords[-1].arg == "full_pipeline_workers"
                assert ast.dump(call.keywords[-1].value) == "Name(id='full_pipeline_workers', ctx=Load())"
                call.keywords.pop()
        assert hashlib.sha256(ast.dump(node, include_attributes=False).encode()).hexdigest() == digest


def test_q_host_capacity_keeps_original_spec_tasks_and_other_scopes(monkeypatch):
    events = []
    monkeypatch.setattr(kernel, "_bounded_ordered_spawn", reversed_completion_pool(events))
    spec = {"execution_scope": "F4_FULL_PIPELINE_SEARCH", "family": "XGBOOST_COX",
            "execution_mode": "INLINE", "engine_threads": 1, "threads": 1, "pool_workers": 1}
    tasks = [{"spec": copy.deepcopy(spec), "coordinate": n, "seed": 750000101 + n} for n in range(40)]
    original = canonical_json_bytes([spec, tasks])
    def worker(task):
        return {"coordinate": task["coordinate"], "value": task["seed"] * 2}
    serial = kernel._search_task_batch(spec, worker, tasks, selected_slots=1)
    parallel = kernel._search_task_batch(spec, worker, tasks, selected_slots=1, full_pipeline_workers=24)
    assert serial == parallel and canonical_json_bytes([spec, tasks]) == original
    assert len(events) == 1 and events[0][1:] == (24, 40)
    f2 = {**spec, "execution_scope": "F2", "pool_workers": 7, "threads": 7}
    assert kernel._search_task_batch(f2, worker, tasks, selected_slots=7) == serial
    assert events[-1][1] == 7
    for damaged, capacity in ((f2, 24), ({**spec, "family": "GBM_COX"}, 24),
                              ({**spec, "threads": 24}, 24), (spec, True), (spec, 0)):
        count = len(events)
        with pytest.raises(ContractError, match="FULL_PIPELINE_SEARCH_EXECUTION_INVALID"):
            kernel._search_task_batch(damaged, worker, tasks, selected_slots=1, full_pipeline_workers=capacity)
        assert len(events) == count


@pytest.mark.parametrize("scope", ["F5_A12_SEARCH", "F5_FULL_DEVELOPMENT_SEARCH"])
def test_f5_native_replay_keeps_its_existing_capacity(monkeypatch, scope):
    from padml import runtime
    events = []
    monkeypatch.setattr(kernel, "_bounded_ordered_spawn", reversed_completion_pool(events))
    monkeypatch.setattr(runtime, "resolve_pool_workers", lambda value: value)
    spec = {"execution_scope": scope, "family": "XGBOOST_COX", "native_search_replay": True,
            "pool_workers": 56, "threads": 56, "engine_threads": 1, "replay_pool_workers": 3}
    before = canonical_json_bytes(spec)
    assert kernel._search_task_batch(spec, lambda task: task + 1, [1, 2, 3], selected_slots=56) == [2, 3, 4]
    assert events[0][1:] == (3, 3) and canonical_json_bytes(spec) == before


@pytest.mark.parametrize("replay", [False, True])
@pytest.mark.parametrize("cpus", [32, 64, 128])
def test_nested_q_cpu_record_and_physical_pool_admission_are_separate(monkeypatch, cpus, replay):
    from padml import runtime
    events = []
    monkeypatch.setattr(runtime, "effective_cpu_count", lambda: cpus)
    monkeypatch.setattr(kernel, "_bounded_ordered_spawn", reversed_completion_pool(events))
    # Replay preserves the producer's 24; this invocation's CPU ceiling is
    # measured afresh, while physical resources permit only two active jobs.
    producer = 24 if replay else cpus - 8
    spec = {"execution_scope": "F5_FULL_DEVELOPMENT_SEARCH", "family": "XGBOOST_COX",
            "native_search_replay": replay, "threads": producer, "pool_workers": producer,
            "engine_threads": 1, "replay_pool_workers": cpus - 8, "active_worker_limit": 2,
            "final_search_source": {"program_id": "PADML_NESTED_LOCO_20260908"}}
    before = canonical_json_bytes(spec)
    result = kernel._search_task_batch(spec, lambda task: task * 2, list(range(5)), selected_slots=producer)
    assert result == [0, 2, 4, 6, 8] and events[0][1:] == (2, 5)
    assert canonical_json_bytes(spec) == before


def test_replicate_forwards_one_host_limit_and_keeps_context_barriers(monkeypatch, tmp_path):
    target = tmp_path.resolve() / "replicate.zip"
    events = []
    def mice(plan, replicate, context, source, path, *, rscript, workers):
        assert workers == 24
        events.append((context, "mice"))
    def load(plan, replicate, context, source, path, destination, *, rscript, workers):
        assert workers == 24
        events.append((context, "read"))
        return {"source": {"context": context, "family": "XGBOOST_COX"},
                "completed": {"UNFITTED": True}, "native_root": destination}
    def selector(context, root, *, rscript, workers):
        assert workers == 24
        events.append((context["source"]["context"], "selector"))
        root.mkdir()
        (root / "selector.json").write_bytes(b'{}')
    def audit(context, root, target, *, rscript, workers):
        assert workers == 24
        events.append((context["source"]["context"], "audit"))
        target.write_bytes(b'{}')
    def compact(context, target, **kwargs):
        events.append((context["source"]["context"], "compact"))
        target.write_bytes(b'{}')
    def values(contexts, root, frozen, *, rscript, replay, workers):
        assert not replay and workers == 24
        assert list(contexts) == [1, 2, 3, 4, 5, 6, 0]
        assert "completed" in contexts[0] and "native_root" in contexts[0]
        assert all("completed" not in contexts[o] and "native_root" not in contexts[o] for o in range(1, 7))
        events.append((0, "Q-final-values"))
        (root / "UNFITTED.json").write_bytes(b'{}')
        return {"replicate": 1, "UNFITTED": True}
    monkeypatch.setattr(f4, "_execute_full_pipeline_mice_context", mice)
    monkeypatch.setattr(f4, "_load_full_pipeline_mice_context", load)
    monkeypatch.setattr(f4, "_execute_full_pipeline_selector", selector)
    monkeypatch.setattr(f4, "_write_full_pipeline_selector_compact", audit)
    monkeypatch.setattr(f4_compact, "write_full_pipeline_mice_compact", compact)
    monkeypatch.setattr(f4, "_full_pipeline_replicate_values", values)
    monkeypatch.setattr(f4, "_full_pipeline_retained_members", lambda root, family: {"UNFITTED.json": root / "UNFITTED.json"})
    result = f4._execute_full_pipeline_replicate({"plan": {"family": "XGBOOST_COX"}, "replicate": 1,
                                               "source": {}, "target": str(target), "workers": 24})
    assert result["replicate"] == 1
    assert events == [(o, stage) for o in range(1, 7) for stage in ("mice", "read", "selector", "audit", "compact")] + [
        (0, stage) for stage in ("mice", "read", "compact", "Q-final-values")]


@pytest.mark.parametrize("fail_after", [None, 2])
def test_shard_calls_replicates_in_host_main_and_stops_without_next(monkeypatch, tmp_path, fail_after):
    tmp_path = tmp_path.resolve()
    plan = {"family": "XGBOOST_COX", "identity_sha256": "UNFITTED_PLAN",
            "replicates": [{"unique_source_patient_count": 3000 - i} for i in range(200)]}
    source = {name: {} for name in ("f1_manifest", "binding_contract", "covariates_csv", "response_csv", "centers")}
    monkeypatch.setattr(f4, "resolve_pool_workers", lambda workers: 24 if workers == 24 else 1)
    monkeypatch.setattr(f4, "load_f4_inputs", lambda *args, **kwargs: {"o_fit_source": source})
    monkeypatch.setattr(f4, "_load_full_pipeline_trigger_result", lambda *args, **kwargs: {"locked_family": plan["family"]})
    monkeypatch.setattr(f4, "validate_full_pipeline_bootstrap_plan", lambda value, **kwargs: value)
    seen = []
    def replicate(job):
        assert job["workers"] == 24 and job["plan"] == plan and job["source"] == source
        seen.append(job["replicate"])
        if fail_after == len(seen):
            raise RuntimeError("ORIGINAL_REPLICATE_FAILURE")
        return {"replicate": job["replicate"], "identity_sha256": "UNFITTED", "sha256": "UNFITTED", "size_bytes": 1}
    monkeypatch.setattr(f4, "_execute_full_pipeline_replicate", replicate)
    plan_path = tmp_path / "plan.zip"
    write_deterministic_zip(plan_path, {"full-pipeline-plan.json": canonical_json_bytes(plan)})
    def run():
        return f4.execute_full_pipeline_bundle(tmp_path, tmp_path / "f4.zip", plan_path, tmp_path / "shard",
                                              shard=1, fixed_result=tmp_path / "fixed.zip", workers=24)
    if fail_after:
        with pytest.raises(RuntimeError, match="ORIGINAL_REPLICATE_FAILURE"):
            run()
        assert seen == [1, 7]
    else:
        result = run()
        assert seen == list(range(1, 101, 6))
        assert [r["replicate"] for r in result["replicates"]] == seen


def test_mice_whole_view_dispatch_and_successful_copy_retirement(monkeypatch, tmp_path):
    tmp_path = tmp_path.resolve()
    context = {"source": {"UNFITTED": True}, "clone_mapping": [], "inner_partitions": [],
               "mice_specs": {name: {"UNFITTED": name, "imputations": 20}
                              for name in ("ANALYSIS_A", "APPLICATION_A", "ANALYSIS_B")}}
    monkeypatch.setattr(f4, "_prepare_full_pipeline_mice_context", lambda *args, **kwargs: copy.deepcopy(context))
    events, produced, consumed = [], [], []
    monkeypatch.setattr(f4, "_bounded_ordered_spawn", reversed_completion_pool(events))
    def execute(inputs, name, target, *, rscript):
        assert inputs == context and rscript == "FORBIDDEN_RSCRIPT"
        target.write_bytes(canonical_json_bytes(inputs["mice_specs"][name]))
        produced.append(name)
        return {"member": target.name, "identity_sha256": "UNFITTED", "sha256": sha256_file(target),
                "size_bytes": target.stat().st_size}
    def read(inputs, name, source, destination, *, rscript, retain_evidence=False):
        assert source.read_bytes() == canonical_json_bytes(context["mice_specs"][name])
        assert inputs == context and retain_evidence
        consumed.append(name)
        destination.mkdir()
        return [destination / f"imp{n:02d}.UNFITTED" for n in range(1, 21)]
    monkeypatch.setattr(f4, "_execute_full_pipeline_mice_view", execute)
    monkeypatch.setattr(f4, "_load_full_pipeline_mice_view", read)
    targets = []
    for workers in (1, 24):
        target = tmp_path / f"context-{workers}.zip"
        result = f4._execute_full_pipeline_mice_context({}, 1, 1, {}, target, rscript="FORBIDDEN_RSCRIPT", workers=workers)
        assert result["mice_chains"] == 60 and result["model_fit_count"] == 0
        destination = tmp_path / f"read-{workers}"
        value = f4._load_full_pipeline_mice_context({}, 1, 1, {}, target, destination,
            rscript="FORBIDDEN_RSCRIPT", retain_evidence=True, workers=workers)
        assert list(value["completed"]) == list(context["mice_specs"])
        assert all(len(paths) == 20 for paths in value["completed"].values())
        assert not (destination / "views").exists() and target.is_file()
        targets.append(target.read_bytes())
    assert targets[0] == targets[1]
    assert produced == consumed == list(context["mice_specs"]) + list(reversed(context["mice_specs"]))
    assert [(e[1], e[2]) for e in events] == [(24, 3), (24, 3)]


@pytest.mark.parametrize("workers", [1, 24])
def test_selector_coarse_fine_and_replay_keep_all_calls(monkeypatch, tmp_path, workers):
    root = tmp_path.resolve()
    events, calls_seen = [], []
    monkeypatch.setattr(f4, "_bounded_ordered_spawn", reversed_completion_pool(events))
    contract = f4.load_science_authority()["science"]["f2_model_development"]["selector_contract"]
    context = {"source": {"bootstrap_replicate": 1, "context": 1}}
    partitions = [{"repeat": r, "inner_fold": k, "partition_id": f"R{r}_K{k}", "transform_recipe": {}}
                  for r, k in [*[(r, k) for r in range(1, 4) for k in range(1, 6)], (0, 0)]]
    def path(call):
        spec, partition, task, target, rscript = call
        assert task["seed"] == spec["seed"] == 740000001 and rscript == "FORBIDDEN_RSCRIPT"
        calls_seen.append((partition["partition_id"], task["imputation"], task["alphas"]))
        folder = Path(target) / task["task_id"]
        if not folder.exists():
            folder.mkdir()
        return {"partition": partition["partition_id"], "imputation": task["imputation"], "alphas": task["alphas"]}
    def reduce(parts, alphas, produced):
        assert [(r["partition"], r["imputation"]) for r in produced] == [
            (p["partition_id"], imp) for p in parts for imp in range(1, 21)]
        assert all(r["alphas"] == alphas for r in produced)
        return {a: {"alpha": a, "UNFITTED": True} for a in alphas}
    monkeypatch.setattr(f4, "_run_learning_selector_path", path)
    monkeypatch.setattr(f4, "_consume_learning_selector_path", path)
    monkeypatch.setattr(f4, "_reduce_full_pipeline_selector_phase", reduce)
    def choose(records, alphas, contract, *, no_aar_redevelopment):
        assert no_aar_redevelopment is None
        return {"alpha": alphas[0]}, None
    monkeypatch.setattr(kernel, "_choose_elastic_alpha", choose)
    original = f4._full_pipeline_selector_search(context, partitions, root, rscript="FORBIDDEN_RSCRIPT", replay=False, workers=workers)
    replay = f4._full_pipeline_selector_search(context, partitions, root, rscript="FORBIDDEN_RSCRIPT", replay=True, workers=workers)
    assert canonical_json_bytes(original) == canonical_json_bytes(replay)
    coarse = list(map(float, contract["alpha_grid"]["coarse"]))
    fine = original[0]["fine_alpha_order"]
    assert original[0]["coarse_alpha_order"] == coarse
    assert original[0]["distinct_alpha_count"] == len(set(coarse + fine))
    assert original[0]["selector_path_count"] == 320 * len(set(coarse + fine))
    assert len(calls_seen) == 640 * (1 + bool(set(fine) - set(coarse)))


@pytest.mark.parametrize("damage", [False, True])
def test_final_twenty_one_fit_two_populations_original_audit_and_order(monkeypatch, tmp_path, damage):
    root = tmp_path.resolve()
    events, fit_names, audited_names, publications = [], [], [], []
    monkeypatch.setattr(f4, "_bounded_ordered_spawn", reversed_completion_pool(events))
    jobs = [{"name": f"M{imp:02d}", "entries": {"task.json": canonical_json_bytes({
        "imputation": imp, "f4_coordinates": {"imputation": imp}})}} for imp in range(1, 21)]
    record = {"bootstrap_ids": ["clone"], "original_ids": ["original"]}
    monkeypatch.setattr(f4, "_full_pipeline_final_tasks", lambda *args, **kwargs: (copy.deepcopy(jobs), record))
    def value(name):
        imp = int(name[1:])
        return {p: {"f4_coordinates": {"imputation": imp}, "patient_ids": record[p + "_ids"],
                    "centers": [36], "horizons": f4.HORIZONS,
                    "survival": {"XGBOOST_COX": [[1 / (1 + imp * h * .0001) for h in f4.HORIZONS]]}}
                for p in ("bootstrap", "original")}
    def fit(job, *, both_populations):
        assert both_populations
        fit_names.append(job["name"])
        return value(job["name"])
    def audit(job, *, both_populations):
        assert both_populations and "replay_evidence" in job
        audited_names.append(job["name"])
        result = value(job["name"])
        if damage:
            result["original"]["survival"]["XGBOOST_COX"][0][1] -= .01
        return {**result, "UNFITTED_AUDIT": True}
    def compact(path, **kwargs):
        assert len(kwargs["components"]) == 20
        publications.append(kwargs["predictions"])
    monkeypatch.setattr(f4, "_execute_f4_model_component", fit)
    monkeypatch.setattr(f4, "_replay_f4_model_component", audit)
    monkeypatch.setattr(f4_compact, "write_full_pipeline_final_compact", compact)
    outputs = []
    for workers in ((24,) if damage else (1, 24)):
        def run():
            return f4._full_pipeline_final_models({"source": {"family": "XGBOOST_COX"}}, {}, None,
                root / f"final-{workers}", rscript="FORBIDDEN_RSCRIPT", replay=False, workers=workers)
        if damage:
            with pytest.raises(ContractError, match="FINAL_NATIVE_AUDIT_MISMATCH"):
                run()
            assert not publications and fit_names == audited_names == ["M20"]
        else:
            outputs.append(run())
    if not damage:
        assert canonical_json_bytes(outputs[0]) == canonical_json_bytes(outputs[1])
        assert fit_names == audited_names == [j["name"] for j in jobs] + [j["name"] for j in reversed(jobs)]
        assert len(publications) == 2 and events[-1][1:] == (24, 20)


@pytest.mark.parametrize('pending_phase', ['coarse', 'fine', 'none'])
@pytest.mark.parametrize('shared', [False, True])
def test_natural_whole_phase_admission_and_original_phase_recovery(tmp_path, monkeypatch, pending_phase, shared):
    """Real task construction/phase routing/admission; no numerical fit or child."""
    from padml import runtime
    from padml.bundle import canonical_json_bytes
    root = tmp_path.resolve()
    context = {'source': {'kind': 'PADML_NESTED_FULL_DATA_SELECTOR_SOURCE_V1',
        'program_id': 'PADML_F45_REBUILD_20260925', 'context': 0,
        'mice_plan_sha256': 'a'*64, 'training_ids_sha256': 'b'*64,
        'training_response_sha256': 'c'*64}, 'ast_alt_natural_audit': True}
    members = [{'name': f'imp{i:02d}.csv', 'size_bytes': 4096, 'sha256': 'd'*64} for i in range(1, 21)]
    parts = [{'partition_id': f'R{repeat}_K{inner}', 'kind': 'INNER' if inner else 'FINAL_FULL_DATA',
        'repeat': repeat, 'inner_fold': inner, 'transform_recipe': {'UNFITTED': True},
        'fit_ids': ['fit1', 'fit2'], 'evaluation_ids': ['eval1', 'eval2'] if inner else ['fit1', 'fit2'],
        'covariates': {'input_dir': str(root/'UNFITTED_INPUTS'), 'members': members},
        'fit_response': {'path': str(root/'UNFITTED_FIT.csv'), 'size_bytes': 30, 'event_count': 2},
        'evaluation_response': {'size_bytes': 30, 'private_bytes': b'UNFITTED_PRIVATE_RESPONSE'}}
        for repeat, inner in [*[(r, k) for r in range(1, 4) for k in range(1, 6)], (0, 0)]]
    contract = f4.load_science_authority()['science']['f2_model_development']['selector_contract']
    coarse = list(map(float, contract['alpha_grid']['coarse']))
    lower, upper = contract['alpha_grid']['fine']['clip']
    fine = sorted({min(upper, max(lower, round(coarse[0]+offset, 3)))
                   for offset in contract['alpha_grid']['fine']['offsets']} - set(coarse))
    assert fine
    columns = kernel._elastic_parent_design_columns(kernel.predictor_contract(Path(kernel.__file__).parent))
    width = sum(columns.values())
    monkeypatch.setattr(kernel, '_response_arrays', lambda *a: ([1., 2.], [1, 1]))
    monkeypatch.setattr(kernel, '_development_evaluation_indices', lambda *a: None)
    monkeypatch.setattr(kernel, '_expected_family_parent_column_map',
        lambda *a: [{'parent': parent, 'columns': list(range(count))} for parent, count in columns.items()])
    monkeypatch.setattr(kernel, '_validate_elastic_lambda_path_health', lambda *a, **k: {})
    monkeypatch.setattr(kernel, '_choose_elastic_coarse_epv_tier',
        lambda records, alphas, value, **k: ({'alpha': coarse[0]}, None, {'UNFITTED': True}, value))
    inspected = []
    monkeypatch.setattr(f4, '_validate_learning_selector_native_spec', lambda call: inspected.append(Path(call[3]).name))
    def completed(phase, alphas):
        rows = []
        health = [{'imputation': i, 'penalized_design_column_count': width} for i in range(1, 21)]
        for alpha in alphas:
            rows.append({'alpha': alpha, 'partition_losses': [
                {'repeat': p['repeat'], 'inner_fold': p['inner_fold'], 'validation_n': len(p['evaluation_ids']),
                 'mi_lambda_path_health': health} for p in parts[:-1]],
                'outer_paths': [{**row, 'event_count': 2, 'parent_design_columns': columns} for row in health],
                'lambda_paths': [[[1.] * 150 for _ in range(20)] for _ in range(16)]})
        directory = root / phase; directory.mkdir()
        (directory / 'paths.json').write_bytes(canonical_json_bytes(rows))
    if pending_phase != 'coarse': completed('coarse', coarse)
    if pending_phase == 'none': completed('fine', fine)
    else:
        atom = root / pending_phase / 'R1_K1_M01'; atom.mkdir(parents=True)
        (atom / 'path-result.json').write_bytes(b'UNFITTED_COMPLETED_ATOM')
    originals = {p: p.read_bytes() for p in root.rglob('*') if p.is_file()}
    monkeypatch.setenv('PADML_INTEGRATED_RUN', '1')
    monkeypatch.setattr(runtime, 'effective_cpu_count', lambda: 32)
    monkeypatch.setattr(runtime, 'observe_execution_resources', lambda path: {
        'effective_cpus': 32, 'available_memory_bytes': 64*1024**3,
        'scratch_available_bytes': 512*1024**3, 'scratch_root': str(path)})
    policy = {'configured_worker_ceiling': runtime.CPU_MINUS_8, 'memory_bytes_per_worker': 1024**3,
        'scratch_bytes_per_worker': 1024, 'memory_reserve_bytes': 0, 'scratch_reserve_bytes': 0,
        'transfer_archive_worker_ceiling': 1000}
    admitted, submitted = [], []
    original_admit = runtime.admit_stage
    def admit(*args, **options):
        admitted.append(options.copy()); return original_admit(*args, **options)
    monkeypatch.setattr(runtime, 'admit_stage', admit)
    def pool(worker, calls, *, selected_slots):
        submitted.append([call[2]['task_id'] for call in calls])
        assert len(calls) == 320 and all(Path(call[3]).name == pending_phase for call in calls)
        assert selected_slots == (1 if shared else 24)
        if shared:
            assert runtime.current_ready_pool() is not None
            assert runtime._READY_FAMILY_LOCAL.stage is not None
            runtime._READY_FAMILY_LOCAL.stage = None
        raise ContractError('ENGINEERING_PHASE_DISPATCH_BOUNDARY')
    monkeypatch.setattr(f4, '_bounded_ordered_spawn', pool)
    def chosen(*args, **options): raise ContractError('ENGINEERING_ALL_PHASES_READ_BOUNDARY')
    monkeypatch.setattr(kernel, '_choose_elastic_alpha', chosen)
    def run():
        return f4._full_pipeline_selector_search(context, parts, root, rscript='FORBIDDEN_RSCRIPT',
            replay=False, workers=1 if shared else 24, resource_policy=policy)
    with pytest.raises(ContractError, match='ENGINEERING_ALL_PHASES_READ_BOUNDARY' if pending_phase == 'none'
                       else 'ENGINEERING_PHASE_DISPATCH_BOUNDARY'):
        if shared: runtime.run_ready_families([run], policy=policy, root=root, workers=24)
        else: run()
    assert all(p.read_bytes() == raw for p, raw in originals.items())
    if pending_phase == 'none':
        assert not admitted and not submitted and set(inspected) == {'coarse', 'fine'}
    else:
        assert len(admitted) == len(submitted) == 1
        estimate = admitted[0]
        assert estimate['legal_tasks'] == 320 and estimate['task_disk_bytes'][0][0] == 0
        assert all(row[0] > 0 for row in estimate['task_disk_bytes'][1:])
        assert estimate['retained_bytes'] == sum(row[0] for row in estimate['task_disk_bytes'])
        assert estimate['publication_bytes'] > max(row[0] for row in estimate['task_disk_bytes'])
        assert all(row[1] == estimate['publication_bytes'] for row in estimate['task_disk_bytes'])
        assert estimate['transient_bytes_per_worker'] > policy['scratch_bytes_per_worker']
        assert estimate['memory_bytes_per_worker'] >= policy['memory_bytes_per_worker']
        assert inspected == ([] if pending_phase == 'coarse' else ['coarse']*320)
