"""Native R vmmin return-pair regression; no scientific model fitting."""
from pathlib import Path
import shutil
import subprocess

import pytest


def test_native_untested_boundary_argument_recovers_only_observed_pair(tmp_path):
    rscript = shutil.which("Rscript")
    if rscript is None:
        pytest.skip("Rscript required for the native optimizer regression")
    patch = (Path(__file__).parents[1] / "padml/kernels/rstpm2-feasible.patch").read_text()
    lines = patch.split("+++ b/R/padml-ph-domain.R\n", 1)[1].splitlines()
    assert len(lines) - 1 == int(lines[0].split("+1,")[1].split()[0])
    source = "\n".join(line[1:] for line in lines[1:]) + "\n"
    script = tmp_path / "native-return.R"
    script.write_text(source + r'''
fn <- function(x) if (x[[1L]] > 1) x[[1L]]-1 else Inf
history <- list()
observe <- function(x) {
    value <- fn(x)
    if (is.finite(value)) history[[length(history)+1L]] <<-
        list(argument=x*1,theta=x*1,value=value)
    value
}
raw <- optim(1+1e-6,observe,function(x) 1,method="BFGS",
             control=list(maxit=100L,reltol=1e-10,parscale=1))
stopifnot(raw$convergence == 0L,is.finite(raw$value),!is.finite(fn(raw$par)))
pair <- padml_ph_return_pair(raw$par,raw$value,history)
stopifnot(pair$theta > 1,identical(fn(pair$theta),raw$value),
          all(10+pair$argument == 10+raw$par),
          any(vapply(history,identical,logical(1),pair)))
for (bad in list(list(),list(list(argument=2,theta=2,value=raw$value)),
                 list(list(argument=pair$argument,theta=pair$theta,value=raw$value+1)))) {
    error <- tryCatch(padml_ph_return_pair(raw$par,raw$value,bad),error=identity)
    stopifnot(inherits(error,"error"),
              identical(conditionMessage(error),"PADML_FPM_NATIVE_PARAMETER_VALUE_UNPROVEN"))
}
cat("NATIVE_RETURN_PAIR_PASS_NO_SCIENTIFIC_FITS\n")
''')
    result = subprocess.run([rscript, str(script)], capture_output=True, text=True, check=False)
    assert result.returncode == 0, result.stdout + result.stderr
    assert "NATIVE_RETURN_PAIR_PASS_NO_SCIENTIFIC_FITS" in result.stdout
