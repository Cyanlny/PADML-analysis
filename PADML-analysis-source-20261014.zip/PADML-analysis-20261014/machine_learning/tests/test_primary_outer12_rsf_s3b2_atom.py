"""Synthetic four-MI transport/native geometry; no native engine or fitting."""
import copy

import pytest

from padml import f4, f5
from padml.bundle import ContractError, canonical_json_bytes
from test_primary_outer12_rsf_inputs import _call


@pytest.mark.parametrize("damage", [None, "missing", "duplicate", "unaligned", "seed", "partition"])
def test_s3b2_four_mi_transport_and_native_gate(tmp_path, monkeypatch, damage):
    call = list(_call(tmp_path, outer=2))
    call[2] = [{"task_id": f"S3B2_T001_P15_M{imp:02d}", "family": "RSF",
                "partition_id": "INNER_F2_R3_K5", "imputation": imp,
                "parameters": {"UNFITTED": 1}, "seed": call[0]["seed"] + 50000 + 100 * imp + 15}
               for imp in range(17, 21)]
    for row in (call[1]["partitions"][0], call[6]):
        row.update(partition_id="INNER_F2_R3_K5", repeat=3, inner_fold=5)
    call[1]["projected_partition_ids"] = ["INNER_F2_R3_K5"]
    if damage == "missing":
        call[2].pop()
    elif damage == "duplicate":
        call[2][-1] = copy.deepcopy(call[2][0])
    elif damage == "unaligned":
        for row in call[2]:
            row["imputation"] -= 1
            row["task_id"] = f"S3B2_T001_P15_M{row['imputation']:02d}"
            row["seed"] -= 100
    elif damage == "seed":
        call[2][-1]["seed"] += 1
    elif damage == "partition":
        call[2][-1]["partition_id"] = "INNER_F2_R3_K4"
    if damage:
        with pytest.raises(ContractError):
            f5._a12_q_stop_unit_input(call)
    else:
        projected = f5._a12_q_stop_unit_input(call)
        assert projected[2] == call[2]
        assert canonical_json_bytes(f5._a12_q_stop_unit_input(projected)) == canonical_json_bytes(projected)
    spec = {**call[0], "producer_tasks": call[2]}
    path = tmp_path / "spec.json"
    path.write_bytes(canonical_json_bytes(spec))
    monkeypatch.setattr(f4.subprocess, "run", lambda *a, **k: pytest.fail("native engine forbidden"))
    # The synthetic native root is absent. A valid atom must pass geometry
    # and stop at that next path check; invalid atoms stop at geometry.
    error = "PRIMARY_RSF_S1_ATOMIC_GEOMETRY_INVALID" if damage else "FULL_PIPELINE_Q_NATIVE_PATH_INVALID"
    with pytest.raises(ContractError, match=error):
        f4._run_full_pipeline_r_search_batch(path, tmp_path / "output.json", tmp_path, {})
