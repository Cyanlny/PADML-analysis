"""Original retained RNG reader; no RNG, model or metric calculation runs."""
from pathlib import Path

import pytest

from padml import f4, f5_sensitivity as sensitivity, nested_loco, runtime
from padml.bundle import ContractError, canonical_json_bytes as cb, sha256_bytes, write_deterministic_zip


@pytest.mark.parametrize("damage", [None, "patient_order", "seed", "kernel", "engine", "draw_bytes"])
def test_original_producer_is_preserved_and_numerical_dependencies_checked(tmp_path, monkeypatch, damage):
    centers = [str(c) for c in sensitivity._VALIDATION_CENTERS for _ in range(2)]
    ids = [f"UNFITTED-{i}" for i in range(len(centers))]
    keys = f4._patient_key_mapping(ids)
    handoff = {"patient_ids": ids, "patient_keys": keys, "centers": centers,
        "horizons": f4.HORIZONS, "selection_horizon_months": 6,
        "science_decision": nested_loco.science_decision_template(),
        "survival": {branch: [[1.0] + [.8] * 36 for _ in ids]
                     for branch in ("PRIMARY", *nested_loco.AAR_ESTIMANDS)}}
    request = {"center_order": list(sensitivity._VALIDATION_CENTERS), "centers": centers,
        "patient_ids": [keys[p] for p in ids], "replicate_count": 1000, "root_seed": 700000001}
    kernel = Path(f4.__file__).with_name("kernels").joinpath("f4_bootstrap.R").read_bytes()
    execution = {"exit_code": 0, "engine_threads": runtime.THREAD_ENV, "kernel_sha256": sha256_bytes(kernel)}
    if damage == "patient_order": request["patient_ids"].reverse()
    if damage == "seed": request["root_seed"] += 1
    if damage == "kernel": kernel += b"\n"
    if damage == "engine": execution["engine_threads"] = {"OMP_NUM_THREADS": "2"}
    archive = tmp_path / "original-rng.zip"
    write_deterministic_zip(archive, {"input.json": cb(request), "f4_bootstrap.R": kernel,
        "execution.json": cb(execution), "stderr.txt": b"UNFITTED_NO_RNG",
        "stdout.txt": cb({"rng": ["L'Ecuyer-CMRG", "Inversion", "Rejection"],
            "r_version": "UNFITTED", "draws": [list(range(len(ids)))] * 1000})})
    original = archive.read_bytes()
    prepared = {"status": "PREPARED_SHARED_F45_DRAWS", "stage_acceptance": False,
        "shared_rng_invocations": 1, "new_model_fits": 0, "bootstrap_replicates_executed": 0,
        "f45_source_sha256": "e" * 64,
        "rng_archive": {"sha256": sha256_bytes(original), "size_bytes": len(original)}}
    if damage == "draw_bytes": prepared["rng_archive"]["sha256"] = "0" * 64
    policy = {"configured_worker_ceiling": runtime.CPU_MINUS_8, "memory_bytes_per_worker": 2 * 1024**3,
        "scratch_bytes_per_worker": 1, "memory_reserve_bytes": 0, "scratch_reserve_bytes": 0,
        "transfer_archive_worker_ceiling": 1000}
    monkeypatch.setattr(sensitivity, "_validate_a12_handoff", lambda value: handoff)
    monkeypatch.setattr(sensitivity, "_a12_primary_point_origin", lambda *args, **kwargs: {})
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda root: {
        "effective_cpus": 32, "available_memory_bytes": 10**12,
        "scratch_available_bytes": 10**12, "scratch_root": str(root)})
    monkeypatch.setattr(f4.subprocess, "run", lambda *a, **k: pytest.fail("RNG or model rerun forbidden"))

    class ReachedMetricBoundary(Exception): pass

    def no_metrics(*args, **kwargs):
        raise ReachedMetricBoundary

    monkeypatch.setattr(sensitivity, "evaluate_predictions", no_metrics)
    expected = ReachedMetricBoundary if damage is None else ContractError
    reason = None if damage is None else (
        "F5_A12_RETAINED_RNG_BYTES_CHANGED" if damage == "draw_bytes" else "F4_BOOTSTRAP_NATIVE_REPLAY_MISMATCH")
    with pytest.raises(expected, match=reason):
        sensitivity.evaluate_a12_incremental_value({}, b"UNFITTED_RESPONSE", formal=True,
            evidence_root=tmp_path / "consumer", resource_policy=policy, retained_bytes_per_replicate=2 * 1024**2,
            retained_primary_point={}, primary_point_native=b"UNFITTED_PRIMARY",
            bootstrap_input_target=tmp_path / "input.zip", point_archive_target=tmp_path / "points.zip",
            retained_rng_archive=archive, retained_rng_preparation_record=prepared)
    assert archive.read_bytes() == original and prepared["f45_source_sha256"] == "e" * 64
