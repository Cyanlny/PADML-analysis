"""UNFITTED regression for chronological AAR final resource reservations."""
from padml import f5, f5_sensitivity as a, nested_loco as n, runtime


def test_later_selector_inputs_do_not_change_prior_branch_reservations(tmp_path, monkeypatch):
    root = tmp_path / "outer"
    development = root / "development"
    (development / "selector").mkdir(parents=True)
    selector = development / "selector/development-input.json"
    selector.write_bytes(b"UNFITTED_SELECTOR")
    (development / "development.json").write_bytes(b"UNFITTED_DEVELOPMENT")
    for branch in n.AAR_ESTIMANDS:
        (development / (branch + ".json")).write_bytes(branch.encode())
    inputs = root / "inputs.zip"
    inputs.write_bytes(b"UNFITTED_INPUTS")
    monkeypatch.setattr(f5, "_nested_selector_numerical_members",
                        lambda _root: {"development-input.json": selector})
    policy = dict(configured_worker_ceiling=runtime.CPU_MINUS_8,
        memory_bytes_per_worker=2 * 1024**3, memory_reserve_bytes=0,
        scratch_bytes_per_worker=1024**2, scratch_reserve_bytes=0,
        transfer_archive_worker_ceiling=20)
    source = dict(kind="PADML_F5_A12_PROJECTED_OUTER_INPUTS_V1", resource_policy=policy,
        primary_source=dict(primary_training_context=dict(heldout_ids=["UNFITTED"])))
    prepared = dict(source=source)
    (development / "selector-inputs-").mkdir()
    lookalike = development / "selector-inputs-/unrelated.json"
    lookalike.write_bytes(b"UNFITTED_UNRELATED")
    jobs = [dict(name=f"O1_{branch}_M{imp:02d}", entries={"UNFITTED": b"no model fit"})
            for branch in n.AAR_ESTIMANDS for imp in range(1, 21)]

    def reservation(count):
        members = a._a12_outer_retained_members(root, "COX_PH", 1, inputs,
            prepared=prepared, before_final=True, completed_branches=n.AAR_ESTIMANDS[:count])
        value = a._a12_final_resource_reservation(source, jobs[:20 * count],
            {name: path.stat().st_size for name, path in members.items()}, 1024**2,
            allow_partial=True, execution_worker_memory_bytes=2 * 1024**3,
            execution_scratch_reserve_bytes=0)
        return members, value

    before = [reservation(count)[1] for count in (1, 2, 3)]
    assert str(lookalike.relative_to(root)) in reservation(1)[0]
    responses = development / "selector-inputs-original/validation-responses"
    responses.mkdir(parents=True)
    for index in range(1, 16):
        (responses / f"inner-{index:02d}.csv").write_bytes(b"UNFITTED_TRAINING_RESPONSE\n")
    for count in (1, 2):
        assert reservation(count)[1] == before[count - 1]
    members, complete = reservation(3)
    assert all(str(path.relative_to(root)) in members for path in responses.iterdir())
    assert complete["shared_member_bytes"] == before[2]["shared_member_bytes"] + sum(
        path.stat().st_size for path in responses.iterdir())
    assert complete["metadata_reserved_bytes"] > before[2]["metadata_reserved_bytes"]
    assert complete["coordinator_memory_estimate_bytes"] == before[2]["coordinator_memory_estimate_bytes"]
    # This is scoped to the later selector: unrelated members still change the budget.
    (development / "other-evidence.json").write_bytes(b"UNFITTED_OTHER")
    assert reservation(1)[1] != before[0]
    assert reservation(3)[1] != complete
