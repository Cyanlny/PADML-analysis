"""Original RSF terminal funnel with synthetic retained numbers, never fits."""
import copy

import pytest

from padml import f2_kernel as kernel, f5
from padml.bundle import ContractError, canonical_json_bytes, sha256_bytes
from test_primary_outer12_rsf_inputs import _call


@pytest.mark.parametrize("source_role", ["current", "4339", "unrelated", "invalid-proof"])
def test_s3b2_numerical_consumer_keeps_proved_historical_executor(tmp_path, monkeypatch, source_role):
    """Source-routing counterexample; full source proof/numbers are separate tests."""
    from pathlib import Path
    import os
    from padml import f4
    producer = Path(os.environ["PADML_PRIMARY_4339_SOURCE"])
    manifest = f4.load_f45_source_bundle(producer)
    historical = {row["path"]: row["sha256"] for row in manifest["members"]}
    assert sha256_bytes(canonical_json_bytes(historical)) == (
        "4339c70013406bdfc10ea7679ac4e8a01054c3ffb01a969c6d427b237614075e")
    current = f4._f45_source_member_sha256()
    members = current if source_role == "current" else historical
    if source_role == "unrelated":
        members = {**historical, "padml/f2_kernel.py": "0" * 64}
    monkeypatch.setattr(f4, "load_f45_source_bundle", lambda _: {
        "members": [{"path": key, "sha256": value} for key, value in members.items()]})
    proof_calls = []
    def proof(path, **options):
        assert path == producer and options == {"primary_rsf_inputs": True}
        proof_calls.append(path)
        if source_role == "invalid-proof":
            raise ContractError("SYNTHETIC_SOURCE_PROOF_REJECTED")
        return members
    monkeypatch.setattr(f4, "_retained_full0_source_members", proof)
    monkeypatch.setattr(f4, "_primary_rsf_search_source", lambda _: {"UNFITTED": True})
    root = tmp_path / "q"; root.mkdir()
    (root / "input.json").write_bytes(b"{}")
    control = {"prepare_only": True, "task_ids": None, "completed": False,
        "resource_policy": {},
        "primary_rsf_s3b2_consumption": True,
        "retained_primary_rsf_q_source_bundle": producer,
        "primary_rsf_preparation": tmp_path / "UNFITTED-preparation.zip",
        "primary_rsf_producer": producer,
        **{"primary_rsf_" + stage + "_evidence": {} for stage in ("s2", "s3a", "s3b1", "s3b2")}}
    spec = {"family": "RSF", "native_search_root": str(root / "native"), "native_search_batch": control}
    phase, ids = f5._a12_q_stop_phase("S3B2", refit=True, family="RSF")
    reached = []
    class ReachedOriginalPreparedReader(Exception):
        pass
    def prepared(*args, **kwargs):
        reached.append(args)
        raise ReachedOriginalPreparedReader
    monkeypatch.setattr(f5, "_primary_rsf_prepared_input", prepared)
    expected = ReachedOriginalPreparedReader if source_role in {"current", "4339"} else ContractError
    with pytest.raises(expected):
        f5._consume_q_search_batches(spec, kernel._run_r_prediction_pool_task,
            {name: (None, None) for name in ids}, [], phase, {})
    assert len(reached) == int(source_role in {"current", "4339"})
    assert len(proof_calls) == int(source_role != "current")


@pytest.mark.parametrize("available", [128 * 1024**3, 1])
def test_retained_full0_completion_uses_actual_space_not_old_reserve(tmp_path, monkeypatch, available):
    from padml import runtime
    from test_primary_outer12_rsf_prepared_pipeline import POLICY
    root, batch = tmp_path / "q", tmp_path / "batch"
    root.mkdir(); batch.mkdir()
    execution = {"UNFITTED": True}
    (batch / "execution.json").write_bytes(canonical_json_bytes(execution))
    control = {"completed": False, "batches": [(batch, execution)],
        "used_batches": [sha256_bytes(canonical_json_bytes(execution))],
        "confirmed_model_fits": 1070, "confirmed_stop_fits": 0, "references": {},
        "resource_policy": {**POLICY, "scratch_reserve_bytes": 10**15},
        "retained_rsf_s3b2": {"evidence": {}, "file_paths": {}, "prefix_result_sha256": "a" * 64}}
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda _: {
        "effective_cpus": 32, "available_memory_bytes": 128 * 1024**3,
        "scratch_available_bytes": available, "scratch_root": str(root)})
    result = {"total_search_fit_count": 1070, "response_free_stopping_fit_count": 0}
    if available == 1:
        with pytest.raises(ContractError, match="F5_Q_BATCH_NUMERICAL_STORAGE_REQUIRED"):
            f5._q_search_batch_completion(root, control, result)
        assert not list(root.iterdir())
    else:
        f5._q_search_batch_completion(root, control, result)
        assert (root / "execution.json").is_file()
        assert control["resource_policy"]["scratch_reserve_bytes"] == 10**15


@pytest.mark.parametrize("damage", [None, "missing-source", "changed-source", "duplicate-batch", "mixed-evidence"])
def test_terminal_history_survives_original_compact_publication(tmp_path, monkeypatch, damage):
    import shutil
    from padml import f4, f4_compact, runtime
    from padml.bundle import strict_json_bytes
    from test_primary_outer12_rsf_prepared_pipeline import POLICY
    root = tmp_path / "q"
    root.mkdir()
    (root / "native" / "UNFITTED").mkdir(parents=True)
    # This is only an archive-member fixture, never a fitted/audited model.
    (root / "native" / "UNFITTED" / "model.rds").write_bytes(b"UNFITTED")
    raw = canonical_json_bytes({"UNFITTED": True})
    (root / "input.json").write_bytes(raw)
    result = {"total_search_fit_count": 1070, "response_free_stopping_fit_count": 0}
    (root / "result.json").write_bytes(canonical_json_bytes(result))
    source = tmp_path / "UNFITTED-source.zip"
    source.write_bytes(b"UNFITTED_SOURCE")
    batches = []
    for stage in ("S1", "S3B2"):
        phase, ids = f5._a12_q_stop_phase(stage, refit=True, family="RSF")
        batches.extend((root, {"phase": phase, "task_ids": ids[i::7],
            "input": {"sha256": sha256_bytes(raw), "size_bytes": len(raw)}}) for i in range(7))
    control = {"batches": batches, "used_batches": [sha256_bytes(canonical_json_bytes(row)) for _, row in batches],
        "confirmed_model_fits": 1070, "confirmed_stop_fits": 0, "completed": False,
        "primary_rsf_s3b2_consumption": True, "s1_summary_recovery_calls": 1,
        "s3b2_numerical_consumer_calls": 1, "references": {}, "resource_policy": POLICY,
        "primary_rsf_preparation": source, "primary_rsf_producer": source,
        "retained_primary_rsf_q_source_bundle": source,
        **{"primary_rsf_" + stage + "_evidence": {"report.json": source}
           for stage in ("s2", "s3a", "s3b1", "s3b2")}}
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda _: {
        "effective_cpus": 32, "available_memory_bytes": 128 * 1024**3,
        "scratch_available_bytes": 128 * 1024**3, "scratch_root": str(root)})
    f5._q_search_batch_completion(root, control, result)
    receipt = strict_json_bytes((root / "execution.json").read_bytes())
    assert len(receipt["primary_rsf_evidence"]) == 7
    assert control["references"] == receipt["primary_rsf_evidence"]
    # Independent source-reader tests cover source acceptance; this test must
    # reach that reader again from transported files without the old paths.
    seen = []
    def original_source(q_raw, preparation, producer, **evidence):
        assert q_raw == raw and preparation.read_bytes() == producer.read_bytes() == b"UNFITTED_SOURCE"
        assert all(path.read_bytes() == b"UNFITTED_SOURCE" for group in evidence.values() for path in group.values())
        seen.append(preparation.parent)
    monkeypatch.setattr(f5, "_primary_rsf_prepared_input", original_source)
    monkeypatch.setattr(f4, "_retained_full0_source_members", lambda *a, **k: {})
    f4_compact._full_pipeline_q_numerical_members(root, publish=True)
    returned = tmp_path / "returned"
    shutil.copytree(root, returned)
    source.unlink()
    if damage == "missing-source": (returned / "execution-evidence/primary-rsf/producer.zip").unlink()
    if damage == "changed-source": (returned / "execution-evidence/primary-rsf/producer.zip").write_bytes(b"DRIFT")
    if damage in {"duplicate-batch", "mixed-evidence"}:
        if damage == "duplicate-batch": receipt["batches"][-1] = receipt["batches"][-2]
        else: receipt["gbm_common_evidence"] = {}
        (returned / "execution.json").write_bytes(canonical_json_bytes(receipt))
    if damage:
        with pytest.raises(ContractError): f4_compact._full_pipeline_q_numerical_members(returned)
    else:
        projection, refs = f4_compact._full_pipeline_q_numerical_members(returned)
        assert set(receipt["primary_rsf_evidence"]) <= set(projection) <= set(refs) | {
            "numbers.json", "native/UNFITTED/object-audit.json"}
        assert seen == [root / "execution-evidence/primary-rsf", returned / "execution-evidence/primary-rsf"]


@pytest.mark.parametrize("stage", ["S3B1", "S3B2"])
def test_complete_owner_routes_retained_source_only_to_original_s3b1(tmp_path, monkeypatch, stage):
    from padml import f4
    source = tmp_path / "source.zip"
    source.write_bytes(b"SOURCE_ONLY")
    root = tmp_path / "q"
    root.mkdir()
    (root / "input.json").write_bytes(b"{}")
    current = f4._f45_source_member_sha256()
    identity = sha256_bytes(canonical_json_bytes(current))
    control = {"prepare_only": True, "task_ids": None, "completed": False, "resource_policy": {},
        "prepared_calls": [], "continuous_batch_root": tmp_path / "continuous",
        "primary_continuous_phase_task_ids": {}, "retained_primary_rsf_q_source_bundle": source,
        "primary_rsf_preparation": source, "primary_rsf_producer": source,
        **{f"primary_rsf_{name}_evidence": {} for name in ("s2", "s3a", "s3b1")}}
    spec = {"family": "RSF", "fold": 4, "selection_horizon_months": 12, "pool_workers": 56,
        "native_search_root": str(root / "native"), "native_search_batch": control}
    phase, ids = f5._a12_q_stop_phase(stage, refit=True, family="RSF", rsf_pool_workers=56)
    loaded = []
    def load(path):
        loaded.append(path)
        return {"members": [{"path": key, "sha256": value} for key, value in current.items()]}
    monkeypatch.setattr(f4, "load_f45_source_bundle", load)
    monkeypatch.setattr(f4, "_primary_rsf_search_source", lambda _: {"UNFITTED": True})
    class OriginalSourceReaderReached(Exception):
        pass
    def prepared(*args, **kwargs):
        assert set(kwargs) == {"s2_evidence", "s3a_evidence", "s3b1_evidence"}
        raise OriginalSourceReaderReached
    monkeypatch.setattr(f5, "_primary_rsf_prepared_input", prepared)
    # Deliberately incomplete execution must fail the unchanged receipt
    # validator for S3B2, never borrow the old S3B1 source allowance.
    with pytest.raises(OriginalSourceReaderReached if stage == "S3B1" else ContractError):
        f5._consume_q_search_batches(spec, kernel._run_r_prediction_pool_task,
            {name: (None, None) for name in ids}, [(root, {"source_identity": identity})], phase, {})
    assert loaded == ([source] if stage == "S3B1" else [])


@pytest.mark.parametrize("damage", [None, "old-source", "prefix-receipt", "current-source", "missing-phase", "duplicate",
                                  "summary-missing", "summary-source", "summary-fold", "native-pin-conflict"])
def test_complete_owner_original_carrier_reads_real_phase_layout(tmp_path, monkeypatch, damage):
    """Transport only: source-reader acceptance is stubbed, not owner acceptance."""
    import shutil
    from padml import f4, f4_compact, runtime
    from padml.bundle import sha256_file, strict_json_bytes
    from test_primary_outer12_rsf_prepared_pipeline import POLICY
    root = tmp_path / "q"
    root.mkdir()
    (root / "native" / "UNFITTED").mkdir(parents=True)
    (root / "native" / "UNFITTED" / "model.rds").write_bytes(b"UNFITTED")
    spec = {"family": "RSF", "fold": 4, "selection_horizon_months": 12, "pool_workers": 56}
    raw = canonical_json_bytes({"spec": spec})
    (root / "input.json").write_bytes(raw)
    pin = {"sha256": sha256_bytes(raw), "size_bytes": len(raw)}
    old_members, current_members = {"old.py": "a" * 64}, {"current.py": "b" * 64}
    old_id, current_id = [sha256_bytes(canonical_json_bytes(value)) for value in (old_members, current_members)]
    original = tmp_path / "original"
    original.mkdir()
    source = original / "source.zip"
    source.write_bytes(b"ORIGINAL_SOURCE")
    batches, evidence = [], {}
    for stage in ("S1", "S2", "S3A", "S3B1", "S3B2"):
        phase, ids = f5._a12_q_stop_phase(stage, refit=True, family="RSF", rsf_pool_workers=56)
        count = 1 if stage == "S3B2" else 7
        rows = [{"phase": phase, "task_ids": ids[index::count], "input": pin,
                 "source_identity": current_id if stage == "S3B2" else old_id} for index in range(count)]
        batches.extend((root, row) for row in rows)
        if stage in {"S1", "S2", "S3A"}:
            group = {"S1": "s2", "S2": "s3a", "S3A": "s3b1"}[stage]
            evidence[group] = {"report.json": source}
            for index, row in enumerate(rows):
                path = original / f"{stage}-{index}.json"
                path.write_bytes(canonical_json_bytes(row))
                evidence[group][f"primary-{group}/H{index}-execution.json"] = path
    result = {"total_search_fit_count": 1070, "response_free_stopping_fit_count": 0,
        "family": "RSF", "selection_horizon_months": 12, "execution_scope": "F2_OUTER_DEVELOPMENT",
        "primary_search_source": {"outer_fold": 4},
        "search_trace": {stage: [] for stage in ("S1", "S2", "S3A", "S3B1", "S3B2")}}
    (root / "result.json").write_bytes(canonical_json_bytes(result))
    retained_metadata = {}
    for group, trace_stages in (("s3b1/source/primary-preparation", ("S2", "S3A")),
                               ("s2/source/primary-s1-summary", ("S1",))):
        directory = original / group
        directory.mkdir(parents=True)
        original_input = raw
        original_result = {"primary_search_source": {"outer_fold": 4},
                           "search_trace": {stage: [] for stage in trace_stages}}
        if group.startswith("s2/") and damage == "summary-source":
            original_result["primary_search_source"]["outer_fold"] = 6
        if group.startswith("s2/") and damage == "summary-fold":
            original_input = canonical_json_bytes({"spec": {**spec, "fold": 6}})
        original_raw = canonical_json_bytes(original_result)
        original_refs = {"input.json": {"sha256": sha256_bytes(original_input), "size_bytes": len(original_input)},
            "result.json": {"sha256": sha256_bytes(original_raw), "size_bytes": len(original_raw)},
            "native/UNFITTED/model.rds": {"sha256": sha256_bytes(b"UNFITTED"), "size_bytes": len(b"UNFITTED")}}
        if group.startswith("s2/") and damage == "native-pin-conflict":
            original_refs["native/UNFITTED/model.rds"]["sha256"] = "d" * 64
        index = {"kind": "PADML_F5_Q_NUMBERS_V1", "input_sha256": sha256_bytes(original_input),
            "result_sha256": sha256_bytes(original_raw), "members": original_refs}
        index["identity_sha256"] = sha256_bytes(canonical_json_bytes(index))
        for name, content in (("input.json", original_input), ("result.json", original_raw),
                              ("numbers.json", canonical_json_bytes(index))):
            path = directory / name
            path.write_bytes(content)
            retained_metadata[group + "/" + name] = path
    control = {"batches": batches, "used_batches": [sha256_bytes(canonical_json_bytes(row)) for _, row in batches],
        "confirmed_model_fits": 1070, "confirmed_stop_fits": 0, "completed": False,
        "prepared_calls": [], "continuous_batch_root": tmp_path / "continuous",
        "primary_continuous_phase_task_ids": {}, "s1_summary_recovery_calls": 1,
        "s1_summary_recovery_call_limit": 1, "primary_rsf_s1_summary": original,
        "primary_rsf_s1_summary_sha256": "c" * 64, "s3b2_numerical_consumer_calls": 1,
        "references": {}, "resource_policy": POLICY, "primary_rsf_preparation": source,
        "primary_rsf_producer": source, "retained_primary_rsf_q_source_bundle": source,
        "primary_rsf_evidence": retained_metadata,
        **{f"primary_rsf_{stage}_evidence": values for stage, values in evidence.items()}}
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda _: {
        "effective_cpus": 32, "available_memory_bytes": 128 * 1024**3,
        "scratch_available_bytes": 128 * 1024**3, "scratch_root": str(root)})
    monkeypatch.setattr(f4, "_retained_full0_source_members", lambda *a, **k: old_members)
    monkeypatch.setattr(f4, "_f45_source_member_sha256", lambda: current_members)
    monkeypatch.setattr(f4, "_primary_rsf_search_source", lambda value: {"outer_fold": value["fold"]})
    seen = []
    def original_source(q_raw, preparation, producer, **groups):
        assert q_raw == raw and preparation.read_bytes() == producer.read_bytes() == b"ORIGINAL_SOURCE"
        assert set(groups) == {"s2_evidence", "s3a_evidence", "s3b1_evidence"}
        seen.append(preparation.parent)
    monkeypatch.setattr(f5, "_primary_rsf_prepared_input", original_source)
    monkeypatch.setattr(kernel, "_run_r_prediction_pool_task", lambda *a, **k: pytest.fail("native producer"))
    f5._q_search_batch_completion(root, control, result)
    if damage in {"summary-source", "summary-fold", "native-pin-conflict"}:
        with pytest.raises(ContractError, match="F4_COMPACT_Q_VALUE_BYTES_MISMATCH"):
            f4_compact._full_pipeline_q_numerical_members(root, publish=True)
        return
    f4_compact._full_pipeline_q_numerical_members(root, publish=True)
    returned = tmp_path / "returned"
    shutil.copytree(root, returned)
    source.unlink()  # The original source location is not needed by the receiver.
    execution = returned / "execution.json"
    receipt = strict_json_bytes(execution.read_bytes())
    if damage == "old-source":
        (returned / "execution-evidence/primary-rsf/q-producer.zip").write_bytes(b"DRIFT")
    elif damage == "summary-missing":
        (returned / "execution-evidence/primary-rsf/s2/source/primary-s1-summary/result.json").unlink()
    elif damage == "prefix-receipt":
        receipt["batches"][0]["source_identity"] = "d" * 64
    elif damage == "current-source":
        receipt["batches"][-1]["source_identity"] = old_id
    elif damage == "missing-phase":
        receipt["batches"].pop()
    elif damage == "duplicate":
        receipt["batches"][0] = receipt["batches"][1]
    if damage:
        execution.write_bytes(canonical_json_bytes(receipt))
        if damage in {"prefix-receipt", "current-source", "missing-phase", "duplicate"}:
            # Reseal the outer transport index so this counterexample tests
            # phase/source semantics, not an obsolete execution-file hash.
            index_path = returned / "numbers.json"
            index = strict_json_bytes(index_path.read_bytes())
            index["members"]["execution.json"] = {
                "sha256": sha256_file(execution), "size_bytes": execution.stat().st_size}
            index["identity_sha256"] = sha256_bytes(canonical_json_bytes({
                key: value for key, value in index.items() if key != "identity_sha256"}))
            index_path.write_bytes(canonical_json_bytes(index))
            assert f4_compact._full_pipeline_q_numbers_index(index_path.read_bytes())[
                "members"]["execution.json"] == {
                    "sha256": sha256_file(execution), "size_bytes": execution.stat().st_size}
        expected = ("F4_COMPACT_Q_VALUE_BYTES_MISMATCH" if damage in {"old-source", "summary-missing"} else
                    "F4_COMPACT_Q_MEMBER_SET_INVALID")
        with pytest.raises(ContractError, match=expected):
            f4_compact._full_pipeline_q_numerical_members(returned)
    else:
        members, _ = f4_compact._full_pipeline_q_numerical_members(returned)
        assert set(receipt["primary_rsf_evidence"]) <= set(members)
        assert seen == [root / "execution-evidence/primary-rsf", returned / "execution-evidence/primary-rsf"]


@pytest.mark.parametrize("damage", [None, "boolean-limit", "missing-history", "duplicate", "input", "publish", "fit"])
@pytest.mark.parametrize("stage_mode", ["S2", "S3B2"])
def test_original_control_admits_only_complete_primary_terminal_evidence(tmp_path, monkeypatch, damage, stage_mode):
    from padml import f4, runtime
    from padml.bundle import sha256_bytes
    from test_primary_outer12_rsf_prepared_pipeline import POLICY
    root = tmp_path / "q"
    root.mkdir()
    raw = canonical_json_bytes({"UNFITTED": True})
    (root / "input.json").write_bytes(raw)
    source = tmp_path / "UNFITTED-source.zip"
    source.write_bytes(b"UNFITTED")
    batches = []
    history_stages = ("s2",) if stage_mode == "S2" else ("s2", "s3a", "s3b1", "s3b2")
    for stage in (("S2",) if stage_mode == "S2" else ("S1", "S3B2")):
        phase, ids = f5._a12_q_stop_phase(stage, refit=True, family="RSF")
        for i in range(7):
            batch = tmp_path / f"{stage}-{i}"
            batch.mkdir()
            names = ids[i::7]
            if damage == "duplicate" and stage == stage_mode and i == 6:
                names = ids[5::7]
            record = {"phase": phase, "task_ids": names,
                "input": {"sha256": "a" * 64 if damage == "input" else sha256_bytes(raw), "size_bytes": len(raw)}}
            (batch / "execution.json").write_bytes(canonical_json_bytes(record))
            batches.append(batch)
    histories = {"primary_rsf_" + stage + "_evidence": {"UNFITTED": source}
                 for stage in history_stages}
    options = {"prepare_only": True, "task_ids": None, "batch_root": None,
        "q_batches": batches, "retained_bytes_per_task": 1024**2,
        **({"primary_rsf_s2_consumption": True} if stage_mode == "S2" else
           {"primary_rsf_s3b2_consumption": True, "s1_summary_recovery_call_limit": 1}),
        "primary_rsf_preparation": source, "primary_rsf_producer": source,
        "retained_primary_rsf_q_source_bundle": source, **histories}
    if damage == "boolean-limit": options["s1_summary_recovery_call_limit"] = True
    if damage == "missing-history": options.pop("primary_rsf_" + history_stages[-1] + "_evidence")
    if damage == "publish": options["q_unit_outputs"] = [["FORBIDDEN"]]
    if damage == "fit": options["prepare_only"] = False
    seen = []
    def source_reader(q_raw, preparation, producer, **evidence):
        assert q_raw == raw and preparation == producer == source
        assert evidence == {stage + "_evidence": histories["primary_rsf_" + stage + "_evidence"]
                            for stage in history_stages}
        seen.append("source")
    # Source acceptance is independently checked against the real archived
    # chain. Here isolate original control wiring, not scientific acceptance.
    monkeypatch.setattr(f5, "_primary_rsf_prepared_input", source_reader)
    monkeypatch.setattr(f4, "_retained_full0_source_members", lambda *a, **k: {})
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda _: {
        "effective_cpus": 32, "available_memory_bytes": 128 * 1024**3,
        "scratch_available_bytes": 128 * 1024**3, "scratch_root": str(root)})
    monkeypatch.setattr(f5, "_run_final_complex_search", lambda *a, **k: pytest.fail("SCIENCE_FORBIDDEN"))
    if damage:
        with pytest.raises(ContractError): f5._q_search_batch_control(root, POLICY, options)
    else:
        result = f5._q_search_batch_control(root, POLICY, options)
        assert seen == ["source"] and len(result["batches"]) == (7 if stage_mode == "S2" else 14)
        assert not result["used_batches"] and result["confirmed_model_fits"] == 0
        assert result["prepare_only"] is True
        if stage_mode == "S2":
            assert "s1_summary_recovery_call_limit" not in result
        else:
            assert result["s1_summary_recovery_call_limit"] == 1


@pytest.mark.parametrize("damage", [None, "missing-batch", "duplicate-batch", "fit-mode", "promotion",
                                  "result-scope", "result-source", "denominator", "mean", "winner",
                                  "no-s1-recovery-authority", "boolean-s1-recovery-limit", "original-control", "original-owner", "original-compiler",
                                  "original-owner-interrupted"])
def test_s3b2_complete_q_recovers_only_missing_s1_summary(tmp_path, monkeypatch, damage):
    base = _call(tmp_path, outer=2)
    spec = copy.deepcopy(base[0]); spec.pop("action")
    spec.update(threads=56, pool_workers=56, engine_threads=1, execution_mode="PROCESS_POOL",
                monthly_fit_horizons=list(range(1, 37)))
    parameters = {"num.trees": 1000, "mtry_fraction": "0.50", "min.node.size": 15,
                  "max.depth": "unlimited", "sample.fraction": 0.632, "splitrule": "logrank"}
    spec["candidate_trials"] = {stage: [{"trial_id": f"{stage}-{i}",
        "parameters": dict(parameters), "parameter_sha256": kernel._sha(parameters)}
        for i in range(1, count + 1)] for stage, count in (("S1", 24), ("S2", 8))}
    partitions = []
    for repeat in range(1, 4):
        for part in range(1, 6):
            row = copy.deepcopy(base[6])
            row.update(partition_id=f"INNER_F2_R{repeat}_K{part}", repeat=repeat, inner_fold=part)
            partitions.append(row)
    registered = {**base[1], "partitions": partitions, "diagnostic_partitions": []}
    registered.pop("projected_partition_ids"); registered.pop("projected_partition_count")
    owner = damage in {"original-owner", "original-compiler", "original-owner-interrupted"}
    if owner:
        from test_primary_outer12_rsf_prepare import _projected
        from padml.bundle import strict_json_bytes
        from test_primary_outer12_rsf_prepared_pipeline import POLICY
        projected = _projected(monkeypatch, 2, 56)
        projected["registered"] = registered
        candidates = copy.deepcopy(spec["candidate_trials"])
        monkeypatch.setattr(f5, "_final_complex_candidate_trials", lambda family: copy.deepcopy(candidates))
        first = tmp_path / "first"
        f5._prepare_primary_outer_rsf_search(projected, first, POLICY,
            retained_bytes_per_task=1024**2, admit_io=lambda **kw: None)
        input_raw = (first / "input.json").read_bytes()
        spec = strict_json_bytes(input_raw)["spec"]
    q = tmp_path / "q"; q.mkdir()
    (q / "input.json").write_bytes(input_raw if owner else canonical_json_bytes({"spec": spec}))
    def rows(stage, candidates, units):
        folds, repeats = (5, 1) if stage in {"S1", "S2", "S3A"} else (15, 3)
        return [{"stage_id": stage, "trial_index": i,
            "candidate_id": c.get("candidate_id", c.get("trial_id")),
            "parameters": c["parameters"], "parameter_sha256": c["parameter_sha256"],
            "evaluation_units": units, "selection_horizon_months": 12,
            "mean_ibs": i / 100, "maximum_ibs": i / 100,
            "metric_values": [i / 100] * units, "fold_metric_values": [i / 100] * folds,
            "ranking_metric_values": [i / 100] * repeats,
            "ranking_metric_qc": [{} for _ in range(repeats)], "ranking_evaluation_count": repeats}
            for i, c in enumerate(candidates, 1)]
    s2 = rows("S2", spec["candidate_trials"]["S2"], 25)
    top3 = kernel._tree_s3a_candidates({"S2": s2})
    s3a = rows("S3A", top3, 100)
    top2 = kernel._rank_trials(s3a, retain=2)[:2]
    s3b1 = rows("S3B1", top2, 75)
    winner = kernel._rank_trials(s3b1, retain=1)[0]
    prefix = {"search_trace": {"S2": s2, "S3A": s3a, "S3B1": s3b1},
              "s3a_candidates": top3, "s3b1_candidates": top2, "s3b2_candidate": winner}
    if damage == "promotion":
        prefix["s3b2_candidate"] = s3b1[1]
    report = q / "s3b1-consumed.json"
    report.write_bytes(canonical_json_bytes({"original_q_boundary": prefix}))
    batches = []
    for stage in ("S1", "S3B2"):
        phase, ids = f5._a12_q_stop_phase(stage, refit=True, family="RSF")
        batches.extend((q, {"phase": phase, "task_ids": ids[i::7]}) for i in range(7))
    control = {"primary_rsf_s3b2_consumption": True, "prepare_only": True,
        "s1_summary_recovery_call_limit": 1,
        "task_ids": None, "completed": {}, "batches": batches, "used_batches": [],
        "confirmed_model_fits": 0, "confirmed_stop_fits": 0,
        "primary_rsf_preparation": q / "SYNTHETIC-preparation.zip",
        "primary_rsf_producer": q / "SYNTHETIC-producer.zip",
        "retained_primary_rsf_q_source_bundle": q / "SYNTHETIC-current.zip",
        "primary_rsf_s2_evidence": {"source/primary-q-producer.zip": q / "SYNTHETIC-S1.zip"},
        "primary_rsf_s3a_evidence": {}, "primary_rsf_s3b1_evidence": {},
        "primary_rsf_s3b2_evidence": {"primary-s3b2/report.json": report}}
    if damage == "missing-batch": control["batches"] = batches[:-1]
    if damage == "duplicate-batch": control["batches"] = [*batches[:-1], batches[-2]]
    if damage == "fit-mode": control["prepare_only"] = False
    if damage == "no-s1-recovery-authority": control.pop("s1_summary_recovery_call_limit")
    if damage == "boolean-s1-recovery-limit": control["s1_summary_recovery_call_limit"] = True
    spec.update(native_search_root=str(q / "native"), native_search_batch=control)
    # Stage-source checks have their own real source-loader tests. This test
    # isolates the original owner, batching, summary and final-result seam.
    monkeypatch.setattr(f5, "_primary_rsf_prepared_input", lambda *a, **k: (None, None))
    if damage == "original-control" or owner:
        from padml import f4, runtime
        from test_primary_outer12_rsf_prepared_pipeline import POLICY
        raw = (q / "input.json").read_bytes()
        paths = []
        for i, (_, record) in enumerate(batches):
            path = tmp_path / f"returned-{i}"
            path.mkdir()
            (path / "execution.json").write_bytes(canonical_json_bytes({**record,
                "input": {"sha256": sha256_bytes(raw), "size_bytes": len(raw)}}))
            paths.append(path)
        for key in ("primary_rsf_preparation", "primary_rsf_producer", "retained_primary_rsf_q_source_bundle"):
            if key == "retained_primary_rsf_q_source_bundle":
                # The original batch controller now reads a real manifest
                # even when its scientific numerical leaves are UNFITTED.
                f4.compile_f45_source_bundle(control[key])
            else:
                control[key].write_bytes(b"UNFITTED_SOURCE")
        monkeypatch.setattr(f4, "_retained_full0_source_members", lambda *a, **k: {})
        monkeypatch.setattr(runtime, "observe_execution_resources", lambda _: {
            "effective_cpus": 32, "available_memory_bytes": 128 * 1024**3,
            "scratch_available_bytes": 128 * 1024**3, "scratch_root": str(q)})
        options = {k: v for k, v in control.items() if k not in {
            "completed", "batches", "used_batches", "confirmed_model_fits", "confirmed_stop_fits"}}
        options.update(batch_root=None, q_batches=paths, retained_bytes_per_task=1024**2)
        if damage == "original-control":
            control = f5._q_search_batch_control(q, POLICY, options)
            spec["native_search_batch"] = control
        else:
            (q / "SYNTHETIC-S1.zip").write_bytes(b"UNFITTED_SOURCE")
    seen = []
    terminal_controls = []
    def numbers(value, function, units, consumed, phase, input_ref):
        assert damage not in {"no-s1-recovery-authority", "boolean-s1-recovery-limit"}
        local = value["native_search_batch"]
        expected_ids = list(units)
        received = [name for _, execution in consumed for name in execution["task_ids"]]
        if len(received) != len(set(received)) or set(received) != set(expected_ids):
            raise ContractError("SYNTHETIC_DUPLICATE_BATCH")
        tasks = [row for call, _ in units.values() for row in call[2]]
        stage = tasks[0]["task_id"].split("_", 1)[0]
        assert stage in {"S1", "S3B2"}
        assert ("primary_rsf_s3b2_consumption" in local) == (stage == "S3B2")
        if damage == "original-owner-interrupted" and stage == "S3B2":
            assert len(local["primary_rsf_s1_trace"]) == 24
            raise ContractError("UNFITTED_S3B2_INTERRUPTED_AFTER_S1_SUMMARY")
        if owner:
            from pathlib import Path
            root = Path(value["native_search_root"]).parent
            leaf = root / ("native/UNFITTED-" + stage)
            leaf.mkdir()
            payload = canonical_json_bytes({"UNFITTED": True})
            (leaf / "prediction.json").write_bytes(payload)
            pins = {"model.rds": {"sha256": sha256_bytes(b"UNFITTED"), "size_bytes": 8},
                    "prediction.json": {"sha256": sha256_bytes(payload), "size_bytes": len(payload)}}
            (leaf / "object-audit.json").write_bytes(canonical_json_bytes(pins))
            local["references"].update({"native/UNFITTED-" + stage + "/" + k: v for k, v in pins.items()})
            local["references"]["input.json"] = {"sha256": sha256_bytes(input_raw), "size_bytes": len(input_raw)}
            if stage == "S3B2":
                terminal_controls.append(local)
        seen.extend(row["task_id"] for row in tasks)
        local["confirmed_model_fits"] += len(tasks)
        local["used_batches"].extend(kernel._sha(row) for _, row in consumed)
        return [[{**{key: row[key] for key in ("task_id", "partition_id", "imputation")},
            "prediction_seal_sha256": "a" * 64, "evaluation_response_sha256": "b" * 64,
            "evaluation_ids_sha256": "c" * 64, "ibs_0_12": .1, "stopping": None,
            "sealed_prediction": {"SYNTHETIC": True}} for row in call[2]] for call, _ in units.values()]
    monkeypatch.setattr(f5, "_consume_q_search_batches", numbers)
    monkeypatch.setattr(kernel, "_accumulate_registered_evaluations", lambda *a: None)
    monkeypatch.setattr(kernel, "_trial_scoring_context", lambda *a, **k: {})
    def summary(values, context, m):
        assert (m, len(values)) in {(1, 5), (20, 300)}
        folds, repeats = (5, 1) if m == 1 else (15, 3)
        return {"evaluation_units": len(values), "selection_horizon_months": 12,
                "mean_ibs": .1, "maximum_ibs": .1,
                "metric_values": [.1] * len(values), "fold_metric_values": [.1] * folds,
                "ranking_metric_values": [.1] * repeats,
                "ranking_metric_qc": [{} for _ in range(repeats)], "ranking_evaluation_count": repeats}
    monkeypatch.setattr(kernel, "_trial_evaluation_summary", summary)
    monkeypatch.setattr(f5, "_execute_q_search_batch", lambda *a, **k: pytest.fail("FIT_FORBIDDEN"))
    if not owner:
        # These cases isolate the funnel, not its physical evidence owner.
        # The owner/interruption cases below exercise the real compact seal.
        monkeypatch.setattr(f5, "_retain_primary_rsf_s1_summary", lambda *a: None)
    terminal_damage = damage in {"result-scope", "result-source", "denominator", "mean", "winner"}
    if damage and not terminal_damage and damage != "original-control" and not owner:
        with pytest.raises(ContractError):
            kernel._run_r_registered_rsf(spec, registered, tmp_path, tmp_path, search_only=True)
        return
    if owner:
        if damage == "original-owner-interrupted":
            from padml.bundle import strict_json_bytes
            from padml.f4_compact import _full_pipeline_q_numerical_members
            with pytest.raises(ContractError, match="UNFITTED_S3B2_INTERRUPTED_AFTER_S1_SUMMARY"):
                f5._prepare_primary_outer_rsf_search(projected, tmp_path / "continued", POLICY,
                    retained_bytes_per_task=1024**2, admit_io=lambda **kw: None,
                    retained_q_input=q / "input.json", batch_options=options)
            assert len(seen) == 120 and all(name.startswith("S1_") for name in seen)
            # A Python dictionary surviving this fixture is not persistence.
            # Reopen only the original compact numerical format left by the
            # failed owner; no synthetic recovery receipt is supplied here.
            recovered = []
            for index in (tmp_path / "continued").rglob("numbers.json"):
                files, _ = _full_pipeline_q_numerical_members(index.parent)
                saved = strict_json_bytes(files["result.json"].read_bytes())
                if "S1" in saved.get("search_trace", {}):
                    recovered.append(saved)
            assert len(recovered) == 1, "S1_SUMMARY_MUST_SURVIVE_LATER_CONSUMER_FAILURE"
            assert len(recovered[0]["search_trace"]["S1"]) == 24
            assert recovered[0]["stage_acceptance"] is False
            assert recovered[0]["primary_search_source"] == spec["primary_search_source"]
            assert recovered[0]["input_sha256"] == sha256_bytes(input_raw)
            saved_root = tmp_path / "continued" / "s1-summary"
            saved_bytes = {p: p.read_bytes() for p in saved_root.rglob("*") if p.is_file()}
            damage = "original-owner-reused"
            seen.clear()
            with pytest.raises(ContractError, match="F5_PRIMARY_RSF_S1_SUMMARY_REUSE_INVALID"):
                f5._prepare_primary_outer_rsf_search(projected, tmp_path / "rejected-external-digest", POLICY,
                    retained_bytes_per_task=1024**2, admit_io=lambda **kw: None,
                    retained_q_input=q / "input.json", batch_options={**options,
                        "primary_rsf_s1_summary": saved_root, "primary_rsf_s1_summary_sha256": "0" * 64,
                        "s1_summary_recovery_call_limit": 0})
            assert not seen
            for corruption in ("source", "phase", "predecessor", "mean"):
                value = copy.deepcopy(recovered[0])
                if corruption == "source": value["primary_search_source"]["outer_fold"] = 5
                elif corruption == "phase": value["phase"] = "WRONG_PHASE"
                elif corruption == "predecessor": value["predecessor_execution_sha256"][0] = "0" * 64
                else: value["search_trace"]["S1"][0]["mean_ibs"] = .2
                encoded = canonical_json_bytes(value)
                index = strict_json_bytes(saved_bytes[saved_root / "numbers.json"])
                index["result_sha256"] = sha256_bytes(encoded)
                index["members"]["result.json"] = {"sha256": sha256_bytes(encoded), "size_bytes": len(encoded)}
                index["identity_sha256"] = kernel._sha({k: v for k, v in index.items() if k != "identity_sha256"})
                (saved_root / "result.json").write_bytes(encoded)
                (saved_root / "numbers.json").write_bytes(canonical_json_bytes(index))
                with pytest.raises(ContractError):
                    f5._prepare_primary_outer_rsf_search(projected, tmp_path / ("rejected-" + corruption), POLICY,
                        retained_bytes_per_task=1024**2, admit_io=lambda **kw: None,
                        retained_q_input=q / "input.json", batch_options={**options,
                            "primary_rsf_s1_summary": saved_root,
                            "primary_rsf_s1_summary_sha256": sha256_bytes(canonical_json_bytes(index)),
                            "s1_summary_recovery_call_limit": 0})
                assert not seen
                for name in ("result.json", "numbers.json"):
                    (saved_root / name).write_bytes(saved_bytes[saved_root / name])
            resumed = f5._prepare_primary_outer_rsf_search(projected, tmp_path / "resumed", POLICY,
                retained_bytes_per_task=1024**2, admit_io=lambda **kw: None,
                retained_q_input=q / "input.json", batch_options={**options,
                    "primary_rsf_s1_summary": saved_root,
                    "primary_rsf_s1_summary_sha256": sha256_bytes(saved_bytes[saved_root / "numbers.json"]),
                    "s1_summary_recovery_call_limit": 0})
            assert resumed["s1_summary_recovery_calls"] == 0
            assert resumed["s3b2_numerical_consumer_calls"] == 1
            assert len(seen) == len(set(seen)) == 300 and all(name.startswith("S3B2_") for name in seen)
            assert [len(rows) for rows in resumed["scientific_result"]["search_trace"].values()] == [24, 8, 3, 2, 1]
            assert {p: p.read_bytes() for p in saved_root.rglob("*") if p.is_file()} == saved_bytes
            _full_pipeline_q_numerical_members(tmp_path / "resumed")
            return
        if damage == "original-compiler":
            from padml import nested_loco as nested
            from padml.bundle import extract_safe_zip, read_safe_zip
            monkeypatch.setattr(f4, "load_f4_inputs", lambda *a, **k: {"UNFITTED_ACCEPTED_SOURCE": True})
            monkeypatch.setattr(nested, "_project_outer_development_from_inputs", lambda *a, **k: projected)
            monkeypatch.setattr(nested, "outer_fresh_score_families", lambda *a: nested._families())
            archive = tmp_path / "completed-q.zip"
            report = f4.compile_o_fit_bundle(tmp_path, archive, outer_fold=2,
                science_decision=projected["science_decision"], resource_policy=POLICY,
                retained_bytes_per_component=1024**2, expanded_bytes_per_component=1024**2,
                shared_storage_bytes=64 * 1024**2, primary_rsf_prepare=True,
                primary_retained_q_input=q / "input.json", primary_q_batch_options=options)
            archive_members = read_safe_zip(archive)
            extract_safe_zip(archive, tmp_path / "continued", expected_members=set(archive_members),
                max_member_bytes=16 * 1024**2, max_total_bytes=64 * 1024**2)
        else:
            report = f5._prepare_primary_outer_rsf_search(projected, tmp_path / "continued", POLICY,
                retained_bytes_per_task=1024**2, admit_io=lambda **kw: None,
                retained_q_input=q / "input.json", batch_options=options)
        result = report["scientific_result"]
        control = terminal_controls[0]
        from padml.f4_compact import _full_pipeline_q_numerical_members
        projection, refs = _full_pipeline_q_numerical_members(tmp_path / "continued")
        assert "numbers.json" in projection and "result.json" in refs
    else:
        result = (f5._run_final_complex_search(spec, registered, tmp_path) if damage == "original-control" else
                  kernel._run_r_registered_rsf(spec, registered, tmp_path, tmp_path, search_only=True))
    assert len(seen) == len(set(seen)) == 420
    assert sum(name.startswith("S1_") for name in seen) == 120
    assert sum(name.startswith("S3B2_") for name in seen) == 300
    assert control["confirmed_model_fits"] == 1070 and control["confirmed_stop_fits"] == 0
    assert control["s1_summary_recovery_calls"] == control["s3b2_numerical_consumer_calls"] == 1
    assert list(result["search_trace"]) == ["S1", "S2", "S3A", "S3B1", "S3B2"]
    assert [len(rows) for rows in result["search_trace"].values()] == [24, 8, 3, 2, 1]
    assert result["search_evaluation_unit_count"] == 1070
    assert result["execution_scope"] == "F2_OUTER_DEVELOPMENT"
    assert result["primary_search_source"] == spec["primary_search_source"]
    assert result["selection_horizon_months"] == 12
    if terminal_damage:
        if damage == "result-scope": result["execution_scope"] = "F5_FULL_DEVELOPMENT_SEARCH"
        elif damage == "result-source":
            result["primary_search_source"] = {**result["primary_search_source"], "outer_fold": 5}
        elif damage == "denominator": result["search_trace"]["S3B2"][0]["metric_values"].pop()
        elif damage == "mean": result["search_trace"]["S3B2"][0]["mean_ibs"] = .2
        else: result["selected_spec"]["candidate_id"] = "S2-8"
        result["search_trace_sha256"] = kernel._sha(result["search_trace"])
        result["selected_spec_sha256"] = kernel._sha(result["selected_spec"])
        result["identity_sha256"] = kernel._sha({key: value for key, value in result.items() if key != "identity_sha256"})
        with pytest.raises(ContractError):
            f5._validate_primary_rsf_search_result(spec, result)
