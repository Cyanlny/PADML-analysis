"""Full0 score identity/seed tests; no model fit, MICE or native RNG."""
import copy
import shutil
import subprocess
from pathlib import Path

import pytest

from padml import f4, f5, nested_loco as nested, runtime
from padml.bundle import ContractError, canonical_json_bytes, strict_json_bytes, write_deterministic_zip


def _unfitted_score_shard_engines(monkeypatch):
    """Real original workers/first audits; only model fitting and spawning stubbed."""
    from test_nested_outer_f4 import _unfitted_engines
    calls = _unfitted_engines(monkeypatch)
    original_pool = runtime._bounded_ordered_spawn
    def pool(worker, jobs, *, selected_slots, execution_report, **kwargs):
        execution_report.update(configured_worker_ceiling=runtime.resolve_pool_workers(None),
            admitted_worker_ceiling=selected_slots, runnable_task_count=len(jobs), actual_worker_process_peak=1,
            completed_task_count=0, engine_threads=1, status="RUNNING")
        original_callback = kwargs.get("on_result")
        def collect(index, value):
            if original_callback is not None:
                original_callback(index, value)
            execution_report["completed_task_count"] += 1
        try:
            result = original_pool(worker, jobs, selected_slots=selected_slots, **{**kwargs, "on_result": collect})
        except BaseException:
            execution_report["status"] = "FAILED"
            raise
        execution_report["status"] = "COMPLETED"
        return result
    monkeypatch.setattr(runtime, "_bounded_ordered_spawn", pool)
    return calls


@pytest.mark.parametrize("entry", ["full0", "outer"])
@pytest.mark.parametrize("mode", ["prepare", "worker", "gather"])
def test_score_shard_original_cli_forwards_only_requested_options(tmp_path, monkeypatch, capsys, entry, mode):
    import sys
    source = tmp_path / "source.zip"
    source.write_bytes(b"UNFITTED CLI path; compiler not invoked")
    batch = tmp_path / "batch"
    calls = []
    options = {"prepare": ["--prepare-only"], "worker": ["--task-ids", "coordinate", "--batch-root", str(batch)],
               "gather": ["--score-batches", str(batch)]}[mode]
    def record(*args, **kwargs):
        calls.append((args, kwargs))
        return {"UNFITTED_CLI": True}
    if entry == "full0":
        monkeypatch.setattr(f5, "execute_full_data_locked_scores", record)
        argv = ["padml-f5", "full-score", str(source), *([] if mode == "prepare" else ["--resume"]), *options]
        main = f5.main
    else:
        monkeypatch.setattr(f4, "execute_o_fit_bundle", record)
        argv = ["padml-f4", "o-fit-execute", str(tmp_path / "outer.zip"), "--input-bundle", str(source),
                "--outer-fold", "1", *options]
        main = f4.main
    monkeypatch.setattr(sys, "argv", argv)
    main()
    assert len(calls) == 1 and "UNFITTED_CLI" in capsys.readouterr().out
    kwargs = calls[0][1]
    expected = {"prepare": {"prepare_only": True}, "worker": {"task_ids": ["coordinate"], "batch_root": batch},
                "gather": {"score_batches": [batch]}}[mode]
    assert {key: kwargs[key] for key in ("prepare_only", "task_ids", "batch_root", "score_batches") if key in kwargs} == expected


@pytest.mark.parametrize("count", [600, 2100])
def test_score_shard_budget_retains_whole_assignment_and_two_incoming_copies(tmp_path, operational_budget, monkeypatch, count):
    root = tmp_path / "score"
    root.mkdir()
    (root / "UNASSIGNED-inputs-and-failure-bytes").write_bytes(b"x" * 5000)
    budgets = {"retained_bytes_per_component": 10000, "expanded_bytes_per_component": 1000,
               "shared_storage_bytes": 100000, "component_count": count}
    _, full = f5._full_score_resource_admission(operational_budget, root, **budgets)
    _, shard = f5._full_score_resource_admission(operational_budget, root, **budgets, assigned_component_count=5)
    assert shard["remaining_retention_reserved_bytes"] == 150000
    assert shard["already_retained_bytes"] == 5000 and shard["verified_retained_credit_bytes"] == 0
    assert shard["coordinator_memory_estimate_bytes"] == full["coordinator_memory_estimate_bytes"]
    _, incoming = f5._full_score_resource_admission(operational_budget, root, **budgets,
        assigned_component_count=0, verification_only=True, incoming_evidence_bytes=2*3000, incoming_metadata_bytes=2000)
    assert incoming["remaining_retention_reserved_bytes"] == 108000
    assert incoming["coordinator_memory_estimate_bytes"] == full["coordinator_memory_estimate_bytes"] + 32*2000
    for resource, worker_name, reserve_name in (("scratch_available_bytes", "scratch_bytes_per_worker", "scratch_reserve_bytes"),
                                               ("available_memory_bytes", "memory_bytes_per_worker", "memory_reserve_bytes")):
        for shortfall in (0, 1):
            observed = {"effective_cpus": 64, "available_memory_bytes": 10**12,
                        "scratch_available_bytes": 10**12, "scratch_root": str(root)}
            observed[resource] = incoming["effective_policy"][reserve_name] + incoming["effective_policy"][worker_name] - shortfall
            monkeypatch.setattr(runtime, "observe_execution_resources", lambda root, value=observed: value)
            if shortfall:
                with pytest.raises(ContractError, match="RESOURCE_ADMISSION_ZERO"):
                    f5._full_score_resource_admission(operational_budget, root, **budgets, assigned_component_count=0,
                        verification_only=True, incoming_evidence_bytes=6000, incoming_metadata_bytes=2000)
            else:
                admitted, _ = f5._full_score_resource_admission(operational_budget, root, **budgets, assigned_component_count=0,
                    verification_only=True, incoming_evidence_bytes=6000, incoming_metadata_bytes=2000)
                assert admitted["admitted_worker_ceiling"] == 1 and admitted["limits"]["configured"] == 56
    with pytest.raises(ContractError, match="RETENTION_CREDIT_INVALID"):
        f5._full_score_resource_admission(operational_budget, root, **budgets,
            assigned_component_count=0, verified_retained_credit_bytes=1)


def _check_score_shard_negatives(root, request, batch, *, monkeypatch):
    """Self-resealed worker values must reach the original rich numeric checks."""
    execution = strict_json_bytes((batch / "execution.json").read_bytes())
    record = next(row for row in request["component_records"] if row["path"] == execution["task_ids"][0])
    handle = execution["archive_handles"][0]
    partition = next(row for row in request["score_partitions"]
                     if (row["repeat"], row["inner_fold"]) == (record["repeat"], record["inner_fold"]))
    name = f"R{record['repeat']}_K{record['inner_fold']}_M{record['imputation']:02d}"
    evidence_path = root / "score-evidence" / record["family"] / (name + ".json")
    saved = evidence_path.read_bytes()
    context = request["training_context"]
    job = {"source": str(root / "request" / record["path"]),
        "root": str(root / "components/score-native" / record["family"] / name),
        "scratch_root": str(root / "scratch"), "expanded_bytes_per_component": 10**6,
        "retained_bytes_per_component": 10**7, "source_sha256": record["sha256"], "source_size_bytes": record["size_bytes"],
        "coordinate_identity": handle["coordinate_identity"], "score_evidence": {"path": str(evidence_path),
            "record": record, "context": {key: context[key] for key in ("scope", "identity_sha256", "outer_fold")},
            "partition_id": partition["partition_id"]}}
    f5._validate_score_archive_handle(handle, job, retained_bytes_per_component=10**7,
                                      require_evidence=True, transported=True)
    assert f5._FullScoreArchiveOutputs([record], [job], [handle], context,
        transported_request=request)[record["path"]] == strict_json_bytes(saved)
    for damage in ("center", "patient", "coordinate", "source", "seed", "health", "design", "missing_audit"):
        evidence = strict_json_bytes(saved)
        if damage == "center":
            evidence["prediction"]["centers"][0] = "55"
        elif damage == "patient":
            evidence["prediction"]["patient_ids"].reverse()
        elif damage == "coordinate":
            evidence["imputation"] = 2 if record["imputation"] == 1 else 1
        elif damage == "source":
            evidence["request_component_sha256"] = "0" * 64
        elif damage == "seed":
            evidence["receipt"]["seed"] += 1
        elif damage == "health":
            evidence["fit_health"]["UNFITTED"] = False
        elif damage == "design":
            evidence["object_audit"]["design_columns"] = ["WRONG"]
        else:
            del evidence["object_audit"]
        evidence["receipt"]["prediction_sha256"] = nested._sha(evidence["prediction"])
        evidence["receipt"]["fit_health_sha256"] = nested._sha(evidence["fit_health"])
        evidence["receipt"] = nested._sealed({key: value for key, value in evidence["receipt"].items() if key != "identity_sha256"})
        evidence = nested._sealed({key: value for key, value in evidence.items() if key != "identity_sha256"})
        raw = canonical_json_bytes(evidence)
        evidence_path.write_bytes(raw)
        altered = {**handle, "evidence_sha256": nested.sha256_bytes(raw), "evidence_size_bytes": len(raw)}
        try:
            # A handle/SHA alone can pass; original patient/source/health values cannot.
            f5._validate_score_archive_handle(altered, job, retained_bytes_per_component=10**7,
                                              require_evidence=True, transported=True)
            outputs = f5._FullScoreArchiveOutputs([record], [job], [altered], context, transported_request=request)
            with pytest.raises(ContractError):
                outputs[record["path"]]
        finally:
            evidence_path.write_bytes(saved)
    source = Path(job["source"])
    original = source.read_bytes()
    source.write_bytes(b"X" + original[1:])
    try:
        with pytest.raises(ContractError, match="NESTED_COMPONENT_SOURCE_REQUEST_DRIFT"):
            f5._FullScoreArchiveOutputs([record], [job], [handle], context, transported_request=request)[record["path"]]
    finally:
        source.write_bytes(original)


def test_nested_native_seeds_agree_for_all_2940_full_score_and_outer_final_coordinates():
    rscript = shutil.which("Rscript")
    if rscript is None:
        pytest.skip("pure native seed-function check requires Rscript, never fits")
    jobs = [
        {"family": family, "coordinates": {"purpose": purpose, "outer_fold": outer,
            "repeat": repeat, "inner_fold": inner, "imputation": imputation}}
        for family in nested._families()
        for purpose, outer, repeat, inner in [
            *[("NESTED_FULL_SCORE", 0, repeat, inner) for repeat in range(1, 4) for inner in range(1, 6)],
            *[("NESTED_OUTER", outer, 0, 0) for outer in range(1, 7)],
        ] for imputation in range(1, 21)
    ]
    expected = [f4._f4_model_seed(job["family"], job["coordinates"]) for job in jobs]
    invalid = []
    for purpose, outer, repeat, inner in [("NESTED_FULL_SCORE", 0, 1, 1), ("NESTED_OUTER", 1, 0, 0)]:
        for change in [{"outer_fold": 7}, {"imputation": True}, {"imputation": 0},
                       {"repeat": 4}, {"inner_fold": 6}, {"bootstrap_replicate": 1},
                       {"repeat": 0 if repeat else 1}, {"outer_fold": 1 if outer == 0 else 0}]:
            coordinates = {"purpose": purpose, "outer_fold": outer, "repeat": repeat,
                           "inner_fold": inner, "imputation": 1, **change}
            with pytest.raises(ContractError, match="F4_MODEL_COORDINATE_INVALID"):
                f4._f4_model_seed("COX_PH", coordinates)
            invalid.append(coordinates)
    completed = subprocess.run([rscript, "--vanilla", "-e", r'''
      suppressPackageStartupMessages(library(jsonlite))
      defs <- Filter(function(x) is.call(x) && identical(x[[1]],as.name("<-")) &&
        is.symbol(x[[2]]) && as.character(x[[2]]) %in% c("fail","need","scalar","f4_model_seed"),
        as.list(parse(commandArgs(TRUE)[[1]])))
      stopifnot(length(defs)==4L)
      for (definition in defs) eval(definition)
      input <- fromJSON(file("stdin"),simplifyVector=FALSE)
      stopifnot(!exists(".Random.seed",envir=.GlobalEnv,inherits=FALSE))
      seeds <- vapply(input$jobs,function(job) f4_model_seed(job$family,job$coordinates),integer(1))
      for (coordinates in input$invalid) stopifnot(inherits(
        tryCatch(f4_model_seed("COX_PH",coordinates),error=function(error) error),"error"))
      stopifnot(!exists(".Random.seed",envir=.GlobalEnv,inherits=FALSE))
      cat(toJSON(as.list(seeds),auto_unbox=TRUE))
    ''', str(Path(f4.__file__).parent / "kernels/f5_final_refit.R")],
        input=canonical_json_bytes({"jobs": jobs, "invalid": invalid}), capture_output=True, timeout=60, check=True)
    assert len(expected) == 2940 and strict_json_bytes(completed.stdout) == expected


def _full_score(family):
    return nested.seal_fresh_training_score(
        family=family, outer_fold=0, training_context_sha256="a" * 64,
        selected_spec={"family": family, "UNFITTED": True}, selector_evidence_sha256="b" * 64,
        summary={"ranking_metric_values": [0.1, 0.1, 0.1], "fold_metric_values": [0.1] * 15,
                 "metric_values": [0.1] * 300, "ranking_metric_qc": [{"fixture": True}] * 3,
                 "ranking_evaluation_count": 3, "evaluation_units": 300,
                 "mean_ibs": 0.1, "maximum_ibs": 0.1}, execution_evidence_sha256="c" * 64,
        source_kind="FRESH_FULL_DATA_M20_INNER_OOF",
    )


def test_full0_all_seven_scores_select_but_cannot_alias_accepted_outer_scores():
    scores = [_full_score(family) for family in nested._families()]
    decision = nested.select_training_family(scores)
    assert decision["selected_family"] == "COX_PH"
    for family, kind, outer in [
        ("COX_PH", "ACCEPTED_F2_TRAINING_ONLY_SCORE_PROJECTION", 0),
        ("ELASTIC_NET_COX", "FRESH_M20_INNER_OOF", 0),
        ("COX_PH", "FRESH_FULL_DATA_M20_INNER_OOF", 1),
    ]:
        score = copy.deepcopy(_full_score(family))
        score.pop("identity_sha256")
        score.update(source_kind=kind, outer_fold=outer, heldout_center=36 if outer else None)
        with pytest.raises(ContractError, match="NESTED_TRAINING_SCORE_INVALID"):
            nested.validate_training_score(nested._sealed(score))
    # Fresh-seven permits a Cox OUTER score, but it cannot join full0's family decision.
    outer_score = {key: value for key, value in _full_score("COX_PH").items() if key != "identity_sha256"}
    outer_score.update(source_kind="FRESH_M20_INNER_OOF", outer_fold=1, heldout_center=36)
    outer_score = nested.validate_training_score(nested._sealed(outer_score))
    with pytest.raises(ContractError, match="NESTED_FAMILY_SELECTION_INPUT_INVALID"):
        nested.select_training_family([outer_score if row["family"] == "COX_PH" else row for row in scores])


@pytest.fixture
def operational_budget(monkeypatch):
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda root: {
        "effective_cpus": 64, "available_memory_bytes": 10**12,
        "scratch_available_bytes": 10**12, "scratch_root": str(root),
    })
    return {"configured_worker_ceiling": "EXECUTION_HOST_C_MINUS_8", "memory_bytes_per_worker": 1000,
            "scratch_bytes_per_worker": 1000, "memory_reserve_bytes": 100,
            "scratch_reserve_bytes": 100, "transfer_archive_worker_ceiling": 56}


def test_full_score_reserves_retention_decode_and_coordinator_without_debris_credit(tmp_path, operational_budget):
    root = tmp_path / "score"
    root.mkdir()
    budget = {"retained_bytes_per_component": 10_000, "expanded_bytes_per_component": 1000,
              "shared_storage_bytes": 100_000}
    _, first = f5._full_score_resource_admission(operational_budget, root, **budget)
    (root / "UNVERIFIED.bin").write_bytes(b"x" * 1000)
    _, second = f5._full_score_resource_admission(operational_budget, root, **budget)
    assert first["remaining_retention_reserved_bytes"] == second["remaining_retention_reserved_bytes"] == 21_100_000
    assert second["already_retained_bytes"] == 1000 and second["verified_retained_credit_bytes"] == 0
    assert second["effective_policy"]["memory_bytes_per_worker"] == 320_000
    assert second["effective_policy"]["memory_reserve_bytes"] > 8_000_000
    _, credited = f5._full_score_resource_admission(
        operational_budget, root, **budget, verified_retained_credit_bytes=200)
    assert credited["remaining_retention_reserved_bytes"] == 21_099_800
    _, verification = f5._full_score_resource_admission(
        operational_budget, root, **budget, verification_only=True)
    assert verification["remaining_retention_reserved_bytes"] == 100_000
    with pytest.raises(ContractError, match="NESTED_FULL_SCORE_RETENTION_CREDIT_INVALID"):
        f5._full_score_resource_admission(operational_budget, root, **budget, verified_shared_credit_bytes=1001)
    for key in budget:
        with pytest.raises(ContractError, match="NESTED_FULL_SCORE_RETENTION_ESTIMATE_REQUIRED"):
            f5._full_score_resource_admission(operational_budget, root, **{**budget, key: True})


@pytest.mark.parametrize("result_name", ["o-fit-scores.json", "full-score-result.json",
    "score-evidence/COX_PH/training-score.json", "score-evidence/RSF/execution.json"])
def test_score_original_json_memory_is_reserved_before_decoding(tmp_path, operational_budget, monkeypatch, result_name):
    budgets = {"retained_bytes_per_component": 10_000, "expanded_bytes_per_component": 1000,
               "shared_storage_bytes": 100_000}
    _, before = f5._full_score_resource_admission(operational_budget, tmp_path, **budgets)
    raw = b"UNFITTED original result bytes; no JSON decoding at admission"
    (tmp_path / result_name).parent.mkdir(parents=True, exist_ok=True)
    (tmp_path / result_name).write_bytes(raw)
    _, after = f5._full_score_resource_admission(operational_budget, tmp_path, **budgets)
    assert before["retained_result_json_bytes"] == 0
    assert after["retained_result_json_bytes"] == len(raw)
    assert after["coordinator_memory_estimate_bytes"] - before["coordinator_memory_estimate_bytes"] == 32 * len(raw)
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda root: {
        "effective_cpus": 64, "available_memory_bytes": after["effective_policy"]["memory_reserve_bytes"]
            + after["effective_policy"]["memory_bytes_per_worker"] - 1,
        "scratch_available_bytes": 10**12, "scratch_root": str(root),
    })
    with pytest.raises(ContractError, match="RESOURCE_ADMISSION_ZERO"):
        f5._full_score_resource_admission(operational_budget, tmp_path, **budgets)


@pytest.mark.parametrize("case,reason", [
    ("missing_replay", "NESTED_FULL_SCORE_NUMERICAL_ORIGINAL_REQUIRED"),
    ("missing_after_lock", "NESTED_FULL_SCORE_NUMERICAL_ORIGINAL_REQUIRED"),
    ("missing_after_final", "NESTED_FULL_SCORE_NUMERICAL_ORIGINAL_REQUIRED"),
    ("invalid_json", "NESTED_FULL_SCORE_NUMERICAL_ORIGINAL"),
    ("invalid_identity", "NESTED_FULL_SCORE_RESULT_REPLAY_DRIFT"),
    ("oversized", "NESTED_FULL_SCORE_NUMERICAL_ORIGINAL_INVALID"),
    ("ram_shortfall", "RESOURCE_ADMISSION_ZERO"),
])
def test_score_original_rejects_before_compilation_or_pool(tmp_path, operational_budget, monkeypatch, case, reason):
    root = tmp_path / "score"
    root.mkdir()
    def forbidden(*args, **kwargs):
        pytest.fail("No input compilation, JSON decoding after failed admission, native replay or pool is allowed")
    monkeypatch.setattr(f5, "_compile_full_score_inputs", forbidden)
    monkeypatch.setattr(runtime, "_bounded_ordered_spawn", forbidden)
    if case == "missing_after_lock":
        (root / "development-lock.json").write_bytes(b"UNFITTED downstream evidence")
    elif case == "missing_after_final":
        (root / "final-numbers.zip").write_bytes(b"UNFITTED downstream evidence")
    elif not case.startswith("missing"):
        (root / "full-score-result.json").write_bytes(
            b"{}" if case == "invalid_identity" else b"x" * 1001 if case == "oversized" else b"{")
    if case == "ram_shortfall":
        monkeypatch.setattr(f5, "strict_json_bytes", forbidden)
        monkeypatch.setattr(runtime, "observe_execution_resources", lambda root: {
            "effective_cpus": 64, "available_memory_bytes": 1,
            "scratch_available_bytes": 10**12, "scratch_root": str(root),
        })
    resume = case in {"missing_after_lock", "missing_after_final"}
    with pytest.raises(ContractError, match=reason):
        f5._full_data_locked_score_program({}, [], {}, tmp_path / "selector", {}, root,
            rscript="UNFITTED", replay=not resume, resume=resume, resource_policy=operational_budget,
            retained_bytes_per_component=10_000, expanded_bytes_per_component=1000,
            shared_storage_bytes=1000)


def test_full_score_refuses_global_storage_shortfall_before_compilation(tmp_path, operational_budget, monkeypatch):
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda root: {
        "effective_cpus": 64, "available_memory_bytes": 10**12,
        "scratch_available_bytes": 2100 * 1000, "scratch_root": str(root),
    })
    def forbidden(*args, **kwargs):
        raise AssertionError("NO_INPUT_COMPILATION_OR_MODEL_ALLOWED")
    monkeypatch.setattr(f5, "_compile_full_score_inputs", forbidden)
    target = tmp_path / "score"
    with pytest.raises(ContractError, match="RESOURCE_ADMISSION_ZERO"):
        f5._full_data_locked_score_program(
            {}, [], {}, tmp_path / "selector", {}, target, rscript="UNFITTED", replay=False,
            resource_policy=operational_budget, retained_bytes_per_component=1000,
            expanded_bytes_per_component=1000, shared_storage_bytes=1000)
    assert not target.exists()


def test_outer_final_pool_reserves_the_actual_heldout_matrix_dimension(tmp_path, operational_budget):
    budgets = {"retained_bytes_per_component": 1000, "expanded_bytes_per_component": 1000,
               "shared_storage_bytes": 100_000}
    request = {"training_context": {"training_ids": ["p1", "p2"],
                                   "heldout_ids": [f"h{i}" for i in range(100)]},
               "score_partitions": [{"evaluation_ids": ["p1"]}]}
    _, reservation = f5._full_score_resource_admission(operational_budget, tmp_path / "score",
        request=request, component_count=600, **budgets)
    expected_cells = (2 * 3 * 2 + (20 + 6) * 100) * len(nested.HORIZONS)
    assert reservation["coordinator_memory_estimate_bytes"] == (
        600 * 4096 + 32 * 1000 + 128 * expected_cells + 32 * len(canonical_json_bytes(request)))


@pytest.mark.parametrize("component_budget", [10_000, 100])
def test_full_score_exact_storage_budget_reaches_pool_without_double_count(tmp_path, operational_budget, monkeypatch, component_budget):
    """UNFITTED compiler/pool stubs, but real three-stage resource accounting."""
    target = tmp_path / "score"
    budgets = {"retained_bytes_per_component": component_budget, "expanded_bytes_per_component": 1000,
               "shared_storage_bytes": 2_000_000}
    policy = {**operational_budget, "transfer_archive_worker_ceiling": 1}
    capacity = 2100 * component_budget + 2_000_000 + policy["scratch_reserve_bytes"] + policy["scratch_bytes_per_worker"]
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda root: {
        "effective_cpus": 64, "available_memory_bytes": 10**12,
        "scratch_available_bytes": capacity - (f5._retained_tree_bytes(target) if target.exists() else 0),
        "scratch_root": str(root),
    })
    def compiler(plan, parts, final, selector, searches, destination, **kwargs):
        destination.mkdir()
        (destination / "training").mkdir()
        (destination / "training/response.csv").write_bytes(b"UNFITTED")
        records = []
        for family in nested._families():
            for repeat in range(1, 4):
                for inner in range(1, 6):
                    for imputation in range(1, 21):
                        path = f"{family}-R{repeat}-K{inner}-M{imputation}.zip"
                        write_deterministic_zip(destination / path, {name: b"{}" for name in nested._COMPONENT_MEMBERS})
                        records.append({"path": path, "size_bytes": (destination / path).stat().st_size,
                            "sha256": nested.sha256_file(destination / path), "family": family,
                            "repeat": repeat, "inner_fold": inner, "imputation": imputation})
        request = {"identity_sha256": "a" * 64, "component_records": records,
                   "training_context": {"scope": "FULL_DATA", "training_ids": ["UNFITTED"]},
                   "score_partitions": [{"evaluation_ids": ["UNFITTED"]}]}
        (destination / "full-score-input.json").write_bytes(canonical_json_bytes(request))
        return request
    def stop_before_fit(worker, jobs, **kwargs):
        assert worker is f5._execute_and_verify_score_archive_job and len(jobs) == 2100
        assert kwargs["selected_slots"] == 1
        raise RuntimeError("UNFITTED_REACHED_POOL_WITH_EXACT_STORAGE_BUDGET")
    monkeypatch.setattr(f5, "_compile_full_score_inputs", compiler)
    monkeypatch.setattr(runtime, "_bounded_ordered_spawn", stop_before_fit)
    expected = (RuntimeError, "UNFITTED_REACHED_POOL_WITH_EXACT_STORAGE_BUDGET") if component_budget == 10_000 else (
        ContractError, "NESTED_FULL_SCORE_COMPONENT_STORAGE_ESTIMATE_EXCEEDED")
    with pytest.raises(expected[0], match=expected[1]):
        f5._full_data_locked_score_program(
            {}, [], {}, tmp_path / "selector", {}, target, rscript="UNFITTED", replay=False,
            resource_policy=policy, **budgets)


@pytest.mark.parametrize("retained_only", [False, True])
@pytest.mark.parametrize("failure", [None, "verification", "drift"])
def test_score_fit_releases_its_first_verification_in_the_same_worker(tmp_path, monkeypatch, failure, retained_only):
    """Control-flow seam only; no model or process-pool substitute is evidence of a fit."""
    job = {"retained_bytes_per_component": 100, "source": str(tmp_path / "input.zip"),
           "root": str(tmp_path / "original")}
    handle = {"UNFITTED": True, "retained_size_bytes": 30}
    events = []
    original = tmp_path / "original.zip"
    def fit(value, **kwargs):
        assert value is job
        assert kwargs == ({"retained_only": True} if retained_only else {})
        assert not original.exists()
        original.write_bytes(b"UNFITTED_RETAINED_ORIGINAL")
        events.append("fit")
        return handle
    def validate(value, request, **kwargs):
        assert value is handle and request is job
        assert kwargs == {"retained_bytes_per_component": 100}
        events.append("storage_and_identity")
        return value
    def verify(value):
        assert value is job and events == ["fit", "storage_and_identity"]
        events.append("first_native_verification")
        if failure == "verification":
            raise ContractError("UNFITTED_NATIVE_VERIFICATION_FAILED")
        return {**handle, "UNFITTED": False} if failure == "drift" else handle
    monkeypatch.setattr(f5, "_execute_score_archive_job", fit)
    monkeypatch.setattr(f5, "_validate_score_archive_handle", validate)
    monkeypatch.setattr(f5, "_replay_component_job", verify)
    if failure:
        with pytest.raises(ContractError, match="UNFITTED_NATIVE_VERIFICATION_FAILED|ARCHIVE_HANDLE_DRIFT"):
            f5._execute_and_verify_score_archive_job(job, retained_only=retained_only)
    else:
        assert f5._execute_and_verify_score_archive_job(job, retained_only=retained_only) == handle
    assert events == ["fit", "storage_and_identity", "first_native_verification"]
    assert original.read_bytes() == b"UNFITTED_RETAINED_ORIGINAL"


def test_full_score_decode_cap_and_scratch_restore(tmp_path):
    import os
    import tempfile
    source = tmp_path / "UNFITTED.zip"
    write_deterministic_zip(source, {"task.json": b"{}", "payload.bin": b"x" * 5000})
    with pytest.raises(ContractError, match="ZIP_.*LIMIT"):
        f5._score_archive_expanded_limit(source, 1000)
    scratch = tmp_path / "scratch"
    scratch.mkdir()
    previous = {key: os.environ.get(key) for key in ("TMPDIR", "TMP", "TEMP")}
    previous_tempdir = tempfile.tempdir
    with f5._full_score_scratch(scratch):
        assert all(os.environ[key] == str(scratch) for key in previous)
        assert tempfile.gettempdir() == str(scratch)
    assert tempfile.tempdir == previous_tempdir
    assert {key: os.environ.get(key) for key in previous} == previous


def test_full_score_existing_native_directory_cannot_restart_an_incomplete_fit(tmp_path, monkeypatch):
    source, output = tmp_path / "input.zip", tmp_path / "native"
    write_deterministic_zip(source, {name: b"{}" for name in nested._COMPONENT_MEMBERS})
    job = {"source": str(source), "root": str(output),
           "coordinate_identity": "a" * 64, "scratch_root": str(tmp_path), "expanded_bytes_per_component": 1000,
           "source_sha256": nested.sha256_file(source), "source_size_bytes": source.stat().st_size,
           "retained_bytes_per_component": 10_000}
    output.mkdir()
    (output / "native-failure.json").write_bytes(b"UNFITTED_STARTED_WITHOUT_ARCHIVE")
    monkeypatch.setattr(f4, "_execute_f4_model_component", lambda *args, **kwargs: pytest.fail("NO_RESTART"))
    with pytest.raises(ContractError, match="F4_NATIVE_MODEL_TARGET_ALREADY_STARTED"):
        f5._execute_score_archive_job(job)
    assert (output / "native-failure.json").read_bytes() == b"UNFITTED_STARTED_WITHOUT_ARCHIVE"
    assert not output.with_suffix(".zip").exists()


def test_full_score_handle_is_small_exact_and_archive_bound(tmp_path):
    source, output = tmp_path / "input.zip", tmp_path / "native"
    write_deterministic_zip(source, {"task.json": b"{}"})
    entries = {name: b"{}" for name in nested._COMPONENT_MEMBERS | {
        "model.bin", "baseline.bin", "fit-health.json", "training-prediction.json", "prediction.json"}}
    write_deterministic_zip(output.with_suffix(".zip"), entries)
    job = {"source": str(source), "root": str(output), "coordinate_identity": "a" * 64}
    handle = f5._score_archive_handle(job, expanded_bytes_per_component=10_000)
    assert len(canonical_json_bytes(handle)) < 512
    assert f5._validate_score_archive_handle(handle, job, retained_bytes_per_component=10_000) == handle
    for change in ({"coordinate_identity": "b" * 64}, {"prediction": []}, {"state": "UNSTARTED"}):
        with pytest.raises(ContractError, match="NESTED_FULL_SCORE_ARCHIVE_HANDLE_INVALID"):
            f5._validate_score_archive_handle({**handle, **change}, job, retained_bytes_per_component=10_000)
    with pytest.raises(ContractError, match="NESTED_FULL_SCORE_COMPONENT_STORAGE_ESTIMATE_EXCEEDED"):
        f5._validate_score_archive_handle(handle, job, retained_bytes_per_component=1)
    with pytest.raises(ContractError, match="NESTED_FULL_SCORE_ARCHIVE_HANDLE_DRIFT"):
        f5._validate_score_archive_handle({**handle, "archive_sha256": "c" * 64}, job, retained_bytes_per_component=10_000)
    output.mkdir()
    for name, raw in entries.items():
        (output / name).write_bytes(raw)
    verified = f5._score_archive_handle(job, expanded_bytes_per_component=10_000)
    assert verified["retained_size_bytes"] == handle["retained_size_bytes"] + sum(map(len, entries.values()))
    (output / "UNVERIFIED.bin").write_bytes(b"MUST_NOT_EARN_CREDIT")
    with pytest.raises(ContractError, match="NESTED_FULL_SCORE_UNPACKED_ARCHIVE_DRIFT"):
        f5._score_archive_handle(job, expanded_bytes_per_component=10_000)


def test_full_score_changed_input_stops_before_fit_and_before_lazy_read(tmp_path, monkeypatch):
    source, output = tmp_path / "input.zip", tmp_path / "native"
    write_deterministic_zip(source, {"task.json": b"{}"})
    job = {"source": str(source), "root": str(output),
           "coordinate_identity": "a" * 64, "scratch_root": str(tmp_path), "expanded_bytes_per_component": 1000,
           "source_sha256": nested.sha256_file(source), "source_size_bytes": source.stat().st_size,
           "retained_bytes_per_component": 10_000}
    def forbidden(*args, **kwargs):
        raise AssertionError("ALTERED_SOURCE_MUST_NOT_REACH_NATIVE_OR_RECEIPT")
    monkeypatch.setattr(f4, "_execute_f4_model_component", forbidden)
    monkeypatch.setattr(nested, "_component_execution_receipt", forbidden)
    source.write_bytes(b"UNFITTED_ALTERED_AFTER_REQUEST_COMPILATION")
    with pytest.raises(ContractError, match="NESTED_COMPONENT_SOURCE_REQUEST_DRIFT"):
        f5._execute_score_archive_job(job)
    outputs = f5._FullScoreArchiveOutputs([{"path": "input.zip"}], [job], [{}], {})
    with pytest.raises(ContractError, match="NESTED_COMPONENT_SOURCE_REQUEST_DRIFT"):
        outputs["input.zip"]
    assert not output.exists()


def test_f5_adapter_passes_the_same_verified_snapshot_to_existing_f4_engine(tmp_path, monkeypatch):
    source, output = tmp_path / "input.zip", tmp_path / "native"
    entries = {name: b"{}" for name in nested._COMPONENT_MEMBERS}
    write_deterministic_zip(source, entries)
    digest, size = nested.sha256_file(source), source.stat().st_size
    read_component = nested._read_component
    def read_verified_snapshot(raw):
        assert isinstance(raw, bytes) and len(raw) == size and nested.sha256_bytes(raw) == digest
        # Changing the path after capture cannot change the already-bound fit input.
        source.write_bytes(b"UNFITTED_PATH_CHANGED_AFTER_SNAPSHOT")
        return read_component(raw)
    def unfitted_engine(job):
        assert job["entries"] == entries
        raise RuntimeError("UNFITTED_VERIFIED_NATIVE_INPUT_RECEIVED")
    monkeypatch.setattr(nested, "_read_component", read_verified_snapshot)
    monkeypatch.setattr(f4, "_execute_f4_model_component", unfitted_engine)
    with pytest.raises(RuntimeError, match="UNFITTED_VERIFIED_NATIVE_INPUT_RECEIVED"):
        f5._execute_score_archive_job({
            "source": str(source), "root": str(output), "coordinate_identity": "a" * 64,
            "source_sha256": digest, "source_size_bytes": size, "scratch_root": str(tmp_path),
            "expanded_bytes_per_component": 10_000, "retained_bytes_per_component": 10_000,
        })
    assert not output.exists() and not (tmp_path / "coordinate-start").exists()


@pytest.mark.parametrize("component_ceiling", [10_000, 1_000_000])
def test_full_score_shared_storage_cannot_borrow_unused_component_headroom(tmp_path, component_ceiling):
    """Storage attribution only; these deliberately are not native objects."""
    root = tmp_path / "score"
    source = root / "request/input.zip"
    native = root / "components/score-native/COX_PH/R1_K1_M01"
    for path in (source.parent, native):
        path.mkdir(parents=True, exist_ok=True)
    source.write_bytes(b"UNFITTED")
    native.with_suffix(".zip").write_bytes(b"UNFITTED")
    (native / "model.bin").write_bytes(b"UNFITTED")
    for prefix in ("score-evidence", "components/score-evidence"):
        path = root / prefix / "COX_PH/R1_K1_M01.json"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(b"UNFITTED")
    job = {"source": str(source), "root": str(native)}
    usage = f5._full_score_storage_usage(
        root, [job], retained_bytes_per_component=component_ceiling, shared_storage_bytes=100)
    assert usage["component_retained_size_bytes"] == 40
    assert usage["shared_retained_size_bytes"] == 0
    (root / "unattributed.bin").write_bytes(b"x" * 100)
    with pytest.raises(ContractError, match="NESTED_FULL_SCORE_SHARED_STORAGE_ESTIMATE_EXCEEDED"):
        f5._full_score_storage_usage(root, [job], retained_bytes_per_component=component_ceiling,
            shared_storage_bytes=100, pending_result_bytes=1)
    with pytest.raises(ContractError, match="NESTED_FULL_SCORE_COMPONENT_STORAGE_ESTIMATE_EXCEEDED"):
        f5._full_score_storage_usage(root, [job], retained_bytes_per_component=39, shared_storage_bytes=100)


@pytest.mark.parametrize("complete", [False, True])
def test_full_score_family_storage_keeps_whole_ownership_and_only_closed_occupancy_credit(
    tmp_path, monkeypatch, complete,
):
    root = tmp_path / "score"
    paths = [root / "request/components/score/COX_PH/R1_K1_M01.zip",
             root / "components/score-native/COX_PH/R1_K1_M01.zip",
             root / "score-evidence/COX_PH/R1_K1_M01.json",
             root / "components/score-evidence/COX_PH/R1_K1_M01.json"]
    for path in paths:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(b"UNFITTED")
    (root / "unknown.bin").write_bytes(b"x" * 100)
    job = {"source": root / "request/components/score/RSF/R1_K1_M01.zip",
           "root": root / "components/score-native/RSF/R1_K1_M01"}
    original_open = Path.open
    def no_native_open(path, *args, **kwargs):
        assert not path.is_relative_to(root / "components/score-native"), "Storage attribution cannot reopen native objects"
        return original_open(path, *args, **kwargs)
    monkeypatch.setattr(Path, "open", no_native_open)
    kwargs = {"retained_bytes_per_component": 1000, "shared_storage_bytes": 100,
              "complete_families": nested._families(), "numerically_complete_families": ("COX_PH",) if complete else ()}
    observed = f5._full_score_storage_usage(root, [job], **kwargs)
    assert observed["component_retained_size_bytes"] == 32
    assert observed["shared_retained_size_bytes"] == 100
    assert observed["numerically_complete_component_retained_size_bytes"] == (32 if complete else 0)
    with pytest.raises(ContractError, match="NESTED_FULL_SCORE_SHARED_STORAGE_ESTIMATE_EXCEEDED"):
        f5._full_score_storage_usage(root, [job], **kwargs, pending_result_bytes=1)
    with pytest.raises(ContractError, match="NESTED_FULL_SCORE_COMPONENT_STORAGE_ESTIMATE_EXCEEDED"):
        f5._full_score_storage_usage(root, [job], **{**kwargs, "retained_bytes_per_component": 31})


def test_full_score_storage_enumerates_batches_once_and_refreshes_next_call(tmp_path, monkeypatch):
    root = tmp_path / "score"
    family, coordinate = "COX_PH", "R1_K1_M01"
    paths = [root / "request/components/score" / family / f"{coordinate}.zip",
             root / "score-batches/first/score-evidence" / family / f"{coordinate}.json",
             root / "score-batches/second/score-evidence" / family / f"{coordinate}.json"]
    for index, path in enumerate(paths, 1):
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(b"x" * index)
    unknown = root / "score-batches/second/score-evidence/UNKNOWN/unknown.json"
    unknown.parent.mkdir(parents=True)
    unknown.write_bytes(b"?")
    job = {"source": paths[0], "root": root / "components/score-native" / family / coordinate}
    original_glob = Path.glob
    enumerations = []
    def count(path, pattern):
        if path == root:
            enumerations.append(pattern)
        return original_glob(path, pattern)
    monkeypatch.setattr(Path, "glob", count)
    kwargs = {"retained_bytes_per_component": 10, "shared_storage_bytes": 1,
              "complete_families": nested._families(), "numerically_complete_families": (family,)}
    observed = f5._full_score_storage_usage(root, [job], **kwargs)
    assert observed == {"retained_size_bytes": 7, "component_retained_size_bytes": 6,
                        "shared_retained_size_bytes": 1, "maximum_component_retained_size_bytes": 6,
                        "numerically_complete_component_retained_size_bytes": 6}
    assert enumerations == ["score-batches/*/score-evidence/*/*.json"]
    extra = root / "score-batches/third/score-evidence" / family / f"{coordinate}.json"
    extra.parent.mkdir(parents=True)
    extra.write_bytes(b"xxxx")
    observed = f5._full_score_storage_usage(root, [job], **kwargs)
    assert observed["component_retained_size_bytes"] == 10 and observed["retained_size_bytes"] == 11
    assert enumerations == ["score-batches/*/score-evidence/*/*.json"] * 2
    unknown.write_bytes(b"??")
    with pytest.raises(ContractError, match="NESTED_FULL_SCORE_SHARED_STORAGE_ESTIMATE_EXCEEDED"):
        f5._full_score_storage_usage(root, [job], **kwargs)


def test_full_score_family_source_reuse_is_only_one_reader_lifecycle(tmp_path, monkeypatch):
    """Reader control-flow, not numerical-source acceptance; validators below are explicit stubs."""
    calls, input_checks, sources = [], [], []
    records, jobs, handles = [], [], []
    for imp in (1, 2):
        source = tmp_path / f"input-{imp}.zip"
        write_deterministic_zip(source, {name: b"{}" for name in nested._COMPONENT_MEMBERS})
        record = {"path": f"input-{imp}.zip", "sha256": nested.sha256_file(source),
                  "family": "COX_PH", "repeat": 1, "inner_fold": 1}
        raw = canonical_json_bytes({"request_component_path": record["path"],
            "request_component_sha256": record["sha256"], "receipt": {"archive_sha256": "a" * 64}})
        evidence = tmp_path / f"evidence-{imp}.json"
        evidence.write_bytes(raw)
        records.append(record)
        jobs.append({"source": source, "score_evidence": {"path": evidence},
            "retained_bytes_per_component": 10000, "expanded_bytes_per_component": 10000})
        handles.append({"evidence_size_bytes": len(raw), "evidence_sha256": nested.sha256_bytes(raw),
                        "archive_sha256": "a" * 64})
    monkeypatch.setattr(nested, "_validate_score_component_evidence", lambda value, **kwargs: value)
    monkeypatch.setattr(f5, "_full_score_job_inputs", lambda job: input_checks.append(job))
    monkeypatch.setattr(f5, "_score_archive_expanded_limit", lambda *args: None)
    def family_source(development, family):
        calls.append((development["generation"], family))
        return {"UNFITTED_CURRENT_FAMILY_SOURCE": development["generation"]}
    monkeypatch.setattr(f5, "_full_score_family_source", family_source)
    monkeypatch.setattr(nested, "_validate_fresh_score_component_numbers",
        lambda **kwargs: sources.append(kwargs["expected_full_source"]))
    request = {"development": {"generation": 1}, "score_partitions": [{"repeat": 1, "inner_fold": 1}]}
    reader = f5._FullScoreArchiveOutputs(records, jobs, handles, {"scope": "FULL_DATA"}, transported_request=request)
    for record in records:
        reader[record["path"]]
    assert calls == [(1, "COX_PH")] and len(input_checks) == 2
    assert sources[0] is sources[1]
    request = {**request, "development": {"generation": 2}}
    current = f5._FullScoreArchiveOutputs(records, jobs, handles, {"scope": "FULL_DATA"}, transported_request=request)
    current[records[0]["path"]]
    assert calls == [(1, "COX_PH"), (2, "COX_PH")] and len(input_checks) == 3
    assert sources[-1] == {"UNFITTED_CURRENT_FAMILY_SOURCE": 2} and sources[-1] is not sources[0]


def test_full_score_storage_does_not_retain_unknown_zero_byte_paths(tmp_path, monkeypatch):
    """Count live path objects, not RSS or an empty-file byte-budget proxy."""
    import weakref

    root = tmp_path / "score"
    unknown = root / "score-batches/first/score-evidence/UNKNOWN"
    unknown.mkdir(parents=True)
    for index in range(512):
        (unknown / f"unknown-{index}.json").touch()
    (unknown / "retained-byte.json").write_bytes(b"?")
    job = {"source": root / "request/components/score/COX_PH/R1_K1_M01.zip",
           "root": root / "components/score-native/COX_PH/R1_K1_M01"}
    original_glob = Path.glob
    live, peaks = weakref.WeakSet(), []

    class ObservedPath(type(root)):
        pass

    def observed_glob(path, pattern):
        for member in original_glob(path, pattern):
            observed = ObservedPath(member)
            live.add(observed)
            peaks.append(len(live))
            yield observed

    monkeypatch.setattr(Path, "glob", observed_glob)
    observed = f5._full_score_storage_usage(root, [job], retained_bytes_per_component=1,
                                            shared_storage_bytes=1)
    assert observed["retained_size_bytes"] == observed["shared_retained_size_bytes"] == 1
    assert observed["component_retained_size_bytes"] == 0
    assert len(peaks) == 513 and max(peaks) <= 2 and not live
    with pytest.raises(ContractError, match="NESTED_FULL_SCORE_SHARED_STORAGE_ESTIMATE_EXCEEDED"):
        f5._full_score_storage_usage(root, [job], retained_bytes_per_component=1, shared_storage_bytes=0)


def _score_repair_fixture(tmp_path, *, whole=False):
    """UNFITTED transport only: no scientific model, recipe or outcome evidence."""
    root = (tmp_path / "PRIMARY-H06-O5/result.zip.work").resolve()
    root.mkdir(parents=True)
    entries = {name: b'{"UNFITTED_TRANSPORT":true}\n' for name in nested._COMPONENT_MEMBERS}
    template = tmp_path / "UNFITTED-input.zip"
    write_deterministic_zip(template, entries)
    records = []
    families = nested._families() if whole else ("RSF",)
    for family in families:
        for repeat in range(1, 4 if whole else 2):
            for fold in range(1, 6 if whole else 2):
                for mi in range(1, 21 if whole else 15):
                    path = f"components/score/{family}/R{repeat}_K{fold}_M{mi:02d}.zip"
                    source = root / "request" / path
                    source.parent.mkdir(parents=True, exist_ok=True)
                    source.hardlink_to(template)
                    records.append({"role": "FRESH_SCORE", "family": family, "repeat": repeat,
                        "inner_fold": fold, "imputation": mi, "path": path,
                        "sha256": nested.sha256_file(template), "size_bytes": template.stat().st_size})
    selected = [row for row in records if row["family"] == "RSF"][:14]
    repair = {"kind": "PADML_F45_SCORE_REPAIR_V1", "run_id": "UNFITTED-RUN",
              "unit_id": "PRIMARY-H06-O5", "source_run_identity": "b" * 64,
              "request_identity_sha256": "a" * 64, "report_sha256": "d" * 64,
              "coordinates": [{"source_record": copy.deepcopy(row), "decision": "REFIT",
                               "reason": "UNFITTED five-input-only failure"} for row in selected]}
    request = {"identity_sha256": "a" * 64, "component_records": records}
    jobs = []
    for row in selected:
        native = root / "components/score-native" / row["family"] / Path(row["path"]).stem
        native.mkdir(parents=True)
        for name, raw in entries.items():
            (native / name).write_bytes(raw)
        jobs.append({"source": str(root / "request" / row["path"]), "root": str(native),
            "expanded_bytes_per_component": 10_000, "source_sha256": row["sha256"],
            "source_size_bytes": row["size_bytes"], "retained_bytes_per_component": 100_000,
            "scratch_root": str(root / "scratch"), "coordinate_identity": "c" * 64,
            "score_evidence": {"record": row,
                "path": str(root / "score-evidence" / row["family"] / (native.name + ".json")),
                "context": {"scope": "OUTER", "identity_sha256": "e" * 64, "outer_fold": 5},
                "partition_id": f'INNER_R{row["repeat"]}_K{row["inner_fold"]}'}})
    return root, request, repair, jobs, entries


def _score_repair_snapshot(root):
    return {p.name: (p.read_bytes(), p.stat().st_ino, p.stat().st_mtime_ns) for p in root.iterdir()}


@pytest.mark.parametrize("damage", [None, "unit", "request", "missing", "duplicate", "extra",
                                    "source_pin", "coordinate", "decision"])
def test_score_repair_requires_exact_report_and_request_scope(tmp_path, damage):
    root, request, repair, jobs, _ = _score_repair_fixture(tmp_path)
    before = [_score_repair_snapshot(Path(job["root"])) for job in jobs]
    if damage == "unit":
        repair["unit_id"] = "PRIMARY-H01-O1"
    elif damage == "request":
        repair["request_identity_sha256"] = "f" * 64
    elif damage == "missing":
        repair["coordinates"].pop()
    elif damage in {"duplicate", "extra"}:
        row = copy.deepcopy(repair["coordinates"][0])
        if damage == "extra":
            row["source_record"]["path"] = "components/score/RSF/R3_K5_M20.zip"
        repair["coordinates"].append(row)
    elif damage == "source_pin":
        repair["coordinates"][0]["source_record"]["sha256"] = "f" * 64
    elif damage == "coordinate":
        repair["coordinates"][0]["source_record"]["imputation"] = 20
    elif damage == "decision":
        repair["coordinates"][0]["decision"] = "RETRY"
    if damage:
        with pytest.raises(ContractError, match="F45_SCORE_REPAIR_(SCOPE|COORDINATE)_DRIFT"):
            f5._score_repair_scope(repair, request, root)
    else:
        assert f5._score_repair_scope(None, request, root) == {}
        assert set(f5._score_repair_scope(repair, request, root)) == {
            row["source_record"]["path"] for row in repair["coordinates"]}
    assert [_score_repair_snapshot(Path(job["root"])) for job in jobs] == before
    assert not (root / "repair-evidence").exists()


@pytest.mark.parametrize("damage", ["same_size_bytes", "missing", "empty", "extra", "partial_pair",
                                    "already_archived", "recovered_decision", "outside_root"])
def test_score_repair_rejects_nonexact_five_input_state_without_mutation(tmp_path, damage):
    root, _, repair, jobs, _ = _score_repair_fixture(tmp_path)
    job = jobs[0]
    native = Path(job["root"])
    if damage == "same_size_bytes":
        path = native / "recipe.json"
        path.write_bytes(b"x" * path.stat().st_size)
    elif damage == "missing":
        (native / "task.json").unlink()
    elif damage == "empty":
        (native / "task.json").write_bytes(b"")
    elif damage == "extra":
        (native / "native-failure.json").write_bytes(b'{"UNFITTED":true}')
    elif damage == "partial_pair":
        (native / "model.bin").write_bytes(b"UNFITTED_PARTIAL_MODEL")
    elif damage == "already_archived":
        native.with_suffix(".zip").write_bytes(b"UNFITTED_PRIOR_PUBLICATION")
    elif damage == "recovered_decision":
        repair["coordinates"][0]["decision"] = "RECOVERED"
    elif damage == "outside_root":
        job = {**job, "root": str(native.parent / "R3_K5_M20")}
    before = _score_repair_snapshot(native)
    with pytest.raises(ContractError, match="F45_SCORE_REPAIR_"):
        f5._score_repair_input_only(job, root, repair, commit=True)
    assert _score_repair_snapshot(native) == before
    assert not (root / "repair-evidence").exists()


@pytest.mark.parametrize("interrupt", ["before_rename", "after_rename"])
def test_score_repair_atomic_move_resumes_without_copy_or_second_move(tmp_path, monkeypatch, interrupt):
    root, _, repair, jobs, _ = _score_repair_fixture(tmp_path)
    job, native = jobs[0], Path(jobs[0]["root"])
    before = _score_repair_snapshot(native)
    evidence = f5._score_repair_input_only(job, root, repair)
    assert not evidence.exists() and _score_repair_snapshot(native) == before
    rename = Path.rename
    def interrupted(source, target):
        assert source == native and target == evidence
        if interrupt == "after_rename":
            rename(source, target)
        raise OSError("INJECTED_RENAME_INTERRUPTION")
    with monkeypatch.context() as patch:
        patch.setattr(Path, "rename", interrupted)
        with pytest.raises(OSError, match="INJECTED_RENAME_INTERRUPTION"):
            f5._score_repair_input_only(job, root, repair, commit=True)
    assert _score_repair_snapshot(evidence if evidence.exists() else native) == before
    assert f5._score_repair_input_only(job, root, repair, commit=True) == evidence
    assert not native.exists() and _score_repair_snapshot(evidence) == before
    def no_second_move(*args, **kwargs):
        pytest.fail("Original evidence cannot be renamed or copied again")
    with monkeypatch.context() as patch:
        patch.setattr(Path, "rename", no_second_move)
        assert f5._score_repair_input_only(job, root, repair, commit=True) == evidence
    assert _score_repair_snapshot(evidence) == before


@pytest.mark.parametrize("partial_pair", [False, True])
def test_score_repair_rejects_a_second_partial_attempt(tmp_path, partial_pair):
    root, _, repair, jobs, entries = _score_repair_fixture(tmp_path)
    job, native = jobs[0], Path(jobs[0]["root"])
    evidence = f5._score_repair_input_only(job, root, repair, commit=True)
    preserved = _score_repair_snapshot(evidence)
    native.mkdir()
    for name, raw in entries.items():
        (native / name).write_bytes(raw)
    if partial_pair:
        (native / "model.bin").write_bytes(b"UNFITTED_INCOMPLETE_SECOND_PAIR")
    attempt = _score_repair_snapshot(native)
    with pytest.raises(ContractError, match="F45_SCORE_REPAIR_ATTEMPT_ALREADY_CONSUMED"):
        f5._score_repair_input_only(job, root, repair, commit=True)
    assert _score_repair_snapshot(evidence) == preserved
    assert _score_repair_snapshot(native) == attempt


@pytest.mark.parametrize("damage", [None, "pin", "source_run", "foreign_unit"])
def test_score_repair_run_reader_keeps_pinned_report_and_unit_boundary(tmp_path, monkeypatch, damage):
    from padml import run
    root, _, repair, _, _ = _score_repair_fixture(tmp_path)
    report = {key: value for key, value in repair.items() if key != "report_sha256"}
    if damage == "source_run":
        report["source_run_identity"] = "f" * 64
    path = root.parent.parent / "repair-report.json"
    path.write_bytes(canonical_json_bytes({"score_repair": report}))
    manifest = {"run_root": str(root.parent.parent), "run_id": report["run_id"],
        "score_repair": {"path": path.name, "sha256": nested.sha256_file(path),
                         "size_bytes": path.stat().st_size}}
    monkeypatch.setattr(run, "f45_unit_predecessors", lambda value: [{"identity": "b" * 64}])
    if damage == "pin":
        path.write_bytes(path.read_bytes().replace(b"UNFITTED-RUN", b"OTHERXXX-RUN"))
    if damage in {"pin", "source_run"}:
        with pytest.raises(ContractError, match="F45_SCORE_REPAIR_REPORT_INVALID"):
            run.f45_score_repair(manifest)
    else:
        unit = {"unit_id": "PRIMARY-H01-O1" if damage == "foreign_unit" else "PRIMARY-H06-O5"}
        accepted = run.f45_score_repair(manifest, unit)
        assert accepted is None if damage else accepted == {**report, "report_sha256": manifest["score_repair"]["sha256"]}


@pytest.mark.parametrize("case", ["success", "last_input_drift", "unauthorized_root", "retained_failure",
                                  "second_partial", "moved_before_first_fit", "paired_after_first_fit"])
def test_score_repair_whole_preflight_and_retained_only_precede_any_new_fit(
        tmp_path, monkeypatch, operational_budget, case):
    """Actual coordinator and validators; compilation/pool are UNFITTED seams."""
    root, request, repair, jobs, entries = _score_repair_fixture(tmp_path, whole=True)
    budgets = {"retained_bytes_per_component": 100_000, "expanded_bytes_per_component": 10_000,
               "shared_storage_bytes": 5_000_000}
    request.update(resource_policy=operational_budget, **budgets,
        training_context={"scope": "OUTER", "identity_sha256": "e" * 64, "outer_fold": 5,
                          "training_ids": ["UNFITTED"], "heldout_ids": ["UNFITTED-HELDOUT"]},
        score_partitions=[{"repeat": r, "inner_fold": k, "partition_id": f"INNER_R{r}_K{k}",
                           "evaluation_ids": ["UNFITTED"]} for r in range(1, 4) for k in range(1, 6)],
        post_lock_templates=[])
    (root / "request/training").mkdir()
    (root / "request/training/response.csv").write_bytes(b"UNFITTED_RESPONSE")
    (root / "request/o-fit-input.json").write_bytes(canonical_json_bytes(request))
    source = tmp_path / "UNFITTED-outer.zip"
    write_deterministic_zip(source, {"o-fit-input.json": canonical_json_bytes({
        "science_decision": nested.science_decision_template()})})
    pair = root / "components/score-native/RSF/R1_K1_M15"
    pair.mkdir(parents=True)
    for name, raw in {**entries, "model.bin": b"UNFITTED_MODEL", "baseline.bin": b"UNFITTED_BASELINE",
                      "fit-health.json": b'{"UNFITTED":true}', "training-prediction.json": b"[1]"}.items():
        (pair / name).write_bytes(raw)
    retained = {pair: _score_repair_snapshot(pair)}
    if case == "last_input_drift":
        (Path(jobs[-1]["root"]) / "recipe.json").write_bytes(b"UNFITTED_CHANGED")
    elif case == "unauthorized_root":
        unlisted = root / "components/score-native/RSF/R1_K1_M16"
        unlisted.mkdir()
        for name, raw in entries.items():
            (unlisted / name).write_bytes(raw)
    elif case in {"second_partial", "moved_before_first_fit", "paired_after_first_fit"}:
        f5._score_repair_input_only(jobs[0], root, repair, commit=True)
        if case in {"second_partial", "paired_after_first_fit"}:
            native = Path(jobs[0]["root"])
            native.mkdir()
            for name, raw in entries.items():
                (native / name).write_bytes(raw)
            if case == "paired_after_first_fit":
                for name, value in retained[pair].items():
                    if name not in entries:
                        (native / name).write_bytes(value[0])
                retained[native] = _score_repair_snapshot(native)
    before = {job["root"]: _score_repair_snapshot(Path(job["root"]))
              for job in jobs if Path(job["root"]).exists()}
    monkeypatch.setattr(f4, "_materialize_o_fit_input_bundle", lambda *a, **k: request)
    calls = []
    def no_native(*args, **kwargs):
        pytest.fail("No scientific/native engine may run in this control-flow fixture")
    monkeypatch.setattr(f5, "_execute_final_refit_engine", no_native)
    def accept_handle(value, job, **kwargs):
        assert value["coordinate_identity"] == job["coordinate_identity"]
        return value
    monkeypatch.setattr(f5, "_validate_score_archive_handle", accept_handle)
    def stopped_pool(worker, tasks, *, on_result, **kwargs):
        if hasattr(worker, "func"):
            assert worker.func is f5._execute_and_verify_score_archive_job
            assert worker.keywords == {"retained_only": True}
            assert set(Path(job["root"]) for job in tasks) == set(retained)
            calls.append("retained_only")
            assert all(_score_repair_snapshot(Path(name)) == value for name, value in before.items())
            if case == "retained_failure":
                raise ContractError("UNFITTED_RETAINED_ACCEPTANCE_FAILED")
            for index, task in enumerate(tasks):
                on_result(index, {"coordinate_identity": task["coordinate_identity"], "retained_size_bytes": 1000})
        else:
            assert worker is f5._execute_and_verify_score_archive_job
            assert calls == ["retained_only"] and len(tasks) == 2100 - len(retained)
            assert not set(retained).intersection(Path(job["root"]) for job in tasks)
            assert all(not Path(job["root"]).exists() for job in jobs if Path(job["root"]) not in retained)
            for job in jobs:
                evidence = root / "repair-evidence" / repair["report_sha256"] / "RSF" / Path(job["root"]).name
                assert {p.name: p.read_bytes() for p in evidence.iterdir()} == entries
            calls.append("authorized_missing_only")
            raise RuntimeError("UNFITTED_STOP_BEFORE_FIRST_FIT")
    monkeypatch.setattr(runtime, "_bounded_ordered_spawn", stopped_pool)
    error = {"success": (RuntimeError, "UNFITTED_STOP_BEFORE_FIRST_FIT"),
             "moved_before_first_fit": (RuntimeError, "UNFITTED_STOP_BEFORE_FIRST_FIT"),
             "paired_after_first_fit": (RuntimeError, "UNFITTED_STOP_BEFORE_FIRST_FIT"),
             "last_input_drift": (ContractError, "F45_SCORE_REPAIR_INPUT_DRIFT"),
             "unauthorized_root": (ContractError, "F4_NATIVE_MODEL_INCOMPLETE_ARCHIVE_REQUIRES_NEW_FIT_AUTHORITY"),
             "retained_failure": (ContractError, "UNFITTED_RETAINED_ACCEPTANCE_FAILED"),
             "second_partial": (ContractError, "F45_SCORE_REPAIR_ATTEMPT_ALREADY_CONSUMED")}[case]
    with pytest.raises(error[0], match=error[1]):
        f5._full_data_locked_score_program(None, None, None, None, None, root,
            rscript="UNFITTED", outer_input=source, replay=False, resume=True,
            resource_policy=operational_budget, workers=1, **budgets, score_repair=repair)
    assert all(_score_repair_snapshot(path) == value for path, value in retained.items())
    if case in {"success", "moved_before_first_fit", "paired_after_first_fit"}:
        assert calls == ["retained_only", "authorized_missing_only"]
    else:
        assert calls == (["retained_only"] if case == "retained_failure" else [])
        assert all(_score_repair_snapshot(Path(name)) == value for name, value in before.items())
        if case != "second_partial":
            assert not (root / "repair-evidence").exists()


def test_score_repair_commit_retries_directory_durability_after_fsync_failure(tmp_path, monkeypatch):
    import os
    root, _, repair, jobs, _ = _score_repair_fixture(tmp_path)
    job, native = jobs[0], Path(jobs[0]['root'])
    original = _score_repair_snapshot(native)
    with monkeypatch.context() as patch:
        def fail(fd):
            raise OSError('INJECTED_REPAIR_DIRECTORY_FSYNC_FAILURE')
        patch.setattr(f5.os, 'fsync', fail)
        with pytest.raises(OSError, match='INJECTED_REPAIR_DIRECTORY_FSYNC_FAILURE'):
            f5._score_repair_input_only(job, root, repair, commit=True)
    evidence = root / 'repair-evidence' / repair['report_sha256'] / 'RSF' / native.name
    assert not native.exists() and _score_repair_snapshot(evidence) == original
    calls, sync = [], os.fsync
    def recorded(fd):
        calls.append(os.fstat(fd).st_ino)
        sync(fd)
    monkeypatch.setattr(f5.os, 'fsync', recorded)
    assert f5._score_repair_input_only(job, root, repair, commit=True) == evidence
    assert calls == [native.parent.stat().st_ino, evidence.parent.stat().st_ino]
    assert _score_repair_snapshot(evidence) == original


def test_preflight_complete_zip_disappearance_never_gains_fit_authority(tmp_path, monkeypatch, operational_budget):
    root, request, _, old_jobs, entries = _score_repair_fixture(tmp_path, whole=True)
    # Remove only our own UNFITTED failed-input fixtures; no partial native tasks.
    for job in old_jobs:
        shutil.rmtree(job['root'])
    budgets = {'retained_bytes_per_component': 100_000, 'expanded_bytes_per_component': 10_000,
               'shared_storage_bytes': 5_000_000}
    request.update(resource_policy=operational_budget, **budgets,
        training_context={'scope': 'OUTER', 'identity_sha256': 'e' * 64, 'outer_fold': 5,
                          'training_ids': ['UNFITTED'], 'heldout_ids': ['UNFITTED-HELDOUT']},
        score_partitions=[{'repeat': r, 'inner_fold': k, 'partition_id': f'INNER_R{r}_K{k}',
                           'evaluation_ids': ['UNFITTED']} for r in range(1, 4) for k in range(1, 6)],
        post_lock_templates=[])
    (root / 'request/training').mkdir()
    (root / 'request/training/response.csv').write_bytes(b'UNFITTED_RESPONSE')
    (root / 'request/o-fit-input.json').write_bytes(canonical_json_bytes(request))
    source = tmp_path / 'UNFITTED-outer.zip'
    write_deterministic_zip(source, {'o-fit-input.json': canonical_json_bytes({
        'science_decision': nested.science_decision_template()})})
    native = root / 'components/score-native/COX_PH/R1_K1_M01'
    archive = native.with_suffix('.zip')
    archive.parent.mkdir(parents=True, exist_ok=True)
    write_deterministic_zip(archive, {**entries, 'model.bin': b'UNFITTED_MODEL',
        'baseline.bin': b'UNFITTED_BASELINE', 'fit-health.json': b'{"UNFITTED":true}',
        'training-prediction.json': b'[1]', 'prediction.json': b'[1]'})
    original = (archive.read_bytes(), archive.stat().st_ino, archive.stat().st_mtime_ns)
    preserved = tmp_path / 'preserved-original.zip'
    original_limit = f5._score_archive_expanded_limit
    calls = []
    def disappear_after_preflight(path, expanded):
        original_limit(path, expanded)
        if isinstance(path, Path) and path == archive and not preserved.exists():
            archive.rename(preserved)
            calls.append('completed_archive_preflight_then_disappeared')
    monkeypatch.setattr(f5, '_score_archive_expanded_limit', disappear_after_preflight)
    monkeypatch.setattr(f4, '_materialize_o_fit_input_bundle', lambda *a, **k: request)
    def forbidden(*args, **kwargs):
        pytest.fail('No native/scientific engine is permitted in this fixture')
    monkeypatch.setattr(f5, '_execute_final_refit_engine', forbidden)
    def stopped_pool(worker, tasks, **kwargs):
        assert calls == ['completed_archive_preflight_then_disappeared']
        assert worker is f5._replay_component_job and len(tasks) == 1
        assert Path(tasks[0]['root']) == native
        calls.append('strict_retained_replay')
        return worker(tasks[0])
    monkeypatch.setattr(runtime, '_bounded_ordered_spawn', stopped_pool)
    with pytest.raises(ContractError, match='NESTED_FULL_SCORE_ARCHIVE_INVALID'):
        f5._full_data_locked_score_program(None, None, None, None, None, root, rscript='UNFITTED', outer_input=source,
            replay=False, resume=True, resource_policy=operational_budget, workers=1, **budgets)
    assert calls == ['completed_archive_preflight_then_disappeared',
        'strict_retained_replay']
    assert (preserved.read_bytes(), preserved.stat().st_ino, preserved.stat().st_mtime_ns) == original
    assert not archive.exists() and not native.exists()
    assert not (root / 'repair-evidence').exists()
