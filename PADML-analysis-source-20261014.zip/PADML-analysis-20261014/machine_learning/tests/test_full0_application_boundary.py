"""UNFITTED application routing; upstream source proof and native leaf are isolated."""
import os
from pathlib import Path
import pytest

from padml import f5
from padml.bundle import ContractError, canonical_json_bytes, sha256_bytes


def test_retained_full0_compiler_context_reaches_original_application_input(monkeypatch):
    from padml import f4, f5_application as application, nested_loco, runtime
    from test_full0_cox12_prepare import _observe
    fixture = os.environ.get("PADML_FULL0_COMPILED_INPUT_FIXTURE")
    if fixture is None:
        pytest.skip("Requires existing UNFITTED compiler artifacts; never regenerate models")
    root = Path(fixture)
    monkeypatch.setattr(runtime, "observe_execution_resources", _observe)
    lineage = f5._read_final_lineage(root / "final-input/lineage.json")
    compiled = f5._read_final_lineage(root / "original-compile-record.json")
    _, _, members = nested_loco._read_component(root / "final-input/bound/M01.zip")
    context = lineage["final_refit_plan"]["training_context"]
    # This fixture has synthetic, fully observed covariates. Only the historical
    # F4 raw-source loading is substituted, never the new full0 source/lock proof.
    columns = application.load_science_authority()["science"]["mice"]["private_handoff"]["columns"]
    import csv
    import io
    rows = [{key: row[key] for key in columns} for row in csv.DictReader(
        io.StringIO(members["fit-covariates.csv"].decode()))]
    raw = application._csv_bytes(columns, rows)
    frozen = {"response_csv": members["fit-response.csv"], "covariates_csv": raw,
        "centers": context["centers_by_patient"],
        "binding_contract": {"covariates_sha256": sha256_bytes(raw)}}
    monkeypatch.setattr(f4, "load_f4_inputs", lambda *a, **kw: {"o_fit_source": frozen})
    actual = application.application_context(root, lineage, input_root=root / "final-input",
        compiled_input_record=compiled)
    inputs = application.application_input_members(actual, context["training_ids"][:2])
    value = application.strict_json_bytes(inputs["input.json"])
    assert value["view"]["analysis_ids"] == context["training_ids"]
    assert value["final_lineage_sha256"] == sha256_bytes(canonical_json_bytes(lineage))
    header = next(csv.reader(io.StringIO(inputs["covariates.csv"].decode())))
    assert not {"All_Cause_Death", "Death_Followup_months"}.intersection(header)
    assert value["view"]["row_ids"][-2:] == [row["application_id"] for row in value["application_rows"]]


@pytest.mark.parametrize("family", ["XGBOOST_COX", "COXTIME_SET_A"])
@pytest.mark.parametrize("damage", [None, "no_objects", "response", "duplicate", "training", "recipe"])
def test_full0_retained_application_uses_original_response_free_consumer(monkeypatch, family, damage):
    training = [{"Patient_ID": "T1", "Center": "36", "Age": "60"}]
    response = {"T1": {"All_Cause_Death": "1", "Death_Followup_months": "12"}}
    application = [{"Patient_ID": "A1", "Center": "38", "Age": "50"}]
    recipe = {"transform_recipe": None, "UNFITTED_RECIPE": True}
    task = {"family": family, "selected_parents": ["Age"], "imputation": 1,
        "registered_model_seed": 300000, "model_seed": 300000,
        "f4_coordinates": {"purpose": "NESTED_FULL_FINAL", "outer_fold": 0,
                           "repeat": 0, "inner_fold": 0, "imputation": 1},
        "family_design_column_count": 1, "row_count": 1,
        "nested_full_final_source": {
            "recipe_sha256": sha256_bytes(canonical_json_bytes(recipe)),
            "training_ids_sha256": sha256_bytes(canonical_json_bytes(["T1"]))}}
    # Separate upstream tests prove full0 lock/source validation. Do not fabricate
    # a native object here or invoke a fitter merely to test this transport gate.
    monkeypatch.setattr(f5, "_validate_final_design_recipe", lambda value, **kw: value)
    monkeypatch.setattr(f5, "_validate_nested_full_final_task", lambda value: None)
    monkeypatch.setattr(f5, "_expected_family_parent_column_map", lambda *a: [{"columns": ["Age"]}])
    calls = []
    objects = (b"UNFITTED_MODEL", b"UNFITTED_BASELINE")
    def predict(actual_family, actual_task, actual_training, actual_response, actual_recipe,
                actual_objects, actual_application, *, single_parity=False):
        assert single_parity is False
        assert (actual_family, actual_task, actual_training, actual_response, actual_recipe,
                actual_objects, actual_application) == (family, task, training, response, recipe, objects, application)
        calls.append(True)
        return {"survival": [[1.0] + [.9] * 36]}
    monkeypatch.setattr(f5, "_predict_retained_final_python", predict)
    if damage == "no_objects":
        objects = None
    elif damage == "response":
        application[0]["All_Cause_Death"] = "1"
    elif damage == "duplicate":
        application *= 2
    elif damage == "training":
        training[0]["Patient_ID"] = "OTHER"
    elif damage == "recipe":
        recipe["UNFITTED_RECIPE"] = False
    if damage:
        with pytest.raises(ContractError, match="NESTED_FULL_FINAL_RECIPE_OR_APPLICATION_INVALID|F5_REPLAY_APPLICATION_INPUT_INVALID"):
            f5._execute_final_refit_engine(family, task, training, response, recipe,
                retained_objects=objects, prediction_rows=application)
        assert calls == []
    else:
        result = f5._execute_final_refit_engine(family, task, training, response, recipe,
            retained_objects=objects, prediction_rows=application)
        assert result == {"survival": [[1.0] + [.9] * 36]} and calls == [True]


def test_full0_application_requires_original_compile_proof_before_models(tmp_path, monkeypatch):
    from padml import f5_application as application
    def forbidden(*a, **kw):
        pytest.fail("NO_MODEL_COLLECTION_BEFORE_ORIGINAL_SOURCE_PROOF")
    monkeypatch.setattr(f5, "collect_final_refit_results", forbidden)
    with pytest.raises(ContractError, match="F5_FULL_FINAL_COMPILED_INPUT_RECORD_INVALID"):
        application.load_application_models(
            {"final_refit_plan": {"kind": "PADML_NESTED_FULL_FINAL_INPUT_V1"}},
            tmp_path, tmp_path, workers=None)


@pytest.mark.parametrize("damage", [None, "response", "center", "raw"])
def test_full0_application_context_binds_own_population_not_old_outer_selectors(tmp_path, monkeypatch, damage):
    from padml import f4, f5_application as application
    raw_response = b"Patient_ID,All_Cause_Death,Death_Followup_months\nT1,1,12\n"
    raw = b"UNFITTED_RAW_COVARIATES"
    context = {"scope": "FULL_DATA", "outer_fold": 0, "training_ids": ["T1"],
        "training_response_sha256": sha256_bytes(raw_response), "centers_by_patient": {"T1": "36"}}
    lineage = {"centers": ["36"], "final_refit_plan": {
        "kind": "PADML_NESTED_FULL_FINAL_INPUT_V1", "training_context": context}}
    compiled = {"UNFITTED_COMPILE_PROOF": True}
    frozen = {"response_csv": raw_response, "covariates_csv": raw, "centers": {"T1": "36"},
        "binding_contract": {"covariates_sha256": sha256_bytes(raw)}}
    def consume(value, source, **kw):
        assert value is lineage and source is None and kw == {
            "input_root": tmp_path, "compiled_input_record": compiled}
        return {}
    monkeypatch.setattr(f5, "_consume_final_parameter_source", consume)
    monkeypatch.setattr(f4, "load_f4_inputs", lambda *a, **kw: {"o_fit_source": frozen})
    monkeypatch.setattr(application, "_csv_rows", lambda value: (
        ["Patient_ID", "Center"], [{"Patient_ID": "T1", "Center": "36"}]))
    if damage == "response":
        context["training_response_sha256"] = "0" * 64
    elif damage == "center":
        context["centers_by_patient"]["T1"] = "38"
    elif damage == "raw":
        frozen["binding_contract"]["covariates_sha256"] = "0" * 64
    if damage:
        with pytest.raises(ContractError, match="F5_APPLICATION_FINAL_POPULATION_MISMATCH|F5_APPLICATION_RAW_SOURCE_MISMATCH"):
            application.application_context(tmp_path, lineage, input_root=tmp_path, compiled_input_record=compiled)
    else:
        value = application.application_context(tmp_path, lineage, input_root=tmp_path, compiled_input_record=compiled)
        assert value["donor_ids"] == ["T1"] and value["lineage"] is lineage
        assert "models" not in frozen and "final_seta_selector_results" not in lineage


@pytest.mark.parametrize("damage", [False, True])
@pytest.mark.parametrize("retain_objects", [False, True])
def test_full0_application_forwards_original_native_consumer_once(tmp_path, monkeypatch, damage, retain_objects):
    from padml import f5_application as application
    lineage = {"family_decision": {}, "final_refit_plan": {
        "kind": "PADML_NESTED_FULL_FINAL_INPUT_V1", "selection_horizon_months": 6}}
    compiled, policy = {"UNFITTED_COMPILE_PROOF": True}, {"UNFITTED_POLICY": True}
    models, calls = [object() for _ in range(20)], []
    def read(path, **kw):
        assert path == tmp_path/'lineage.json'
        assert kw == {'bounded':True,'selection_horizon_months':6}
        return {} if damage else lineage
    def collect(result_root, family, plan, **kw):
        assert result_root == tmp_path and family is lineage['family_decision'] and plan is lineage['final_refit_plan']
        assert kw == {'input_root':tmp_path,'produce_shap':False,'replay_evidence':None,
            'workers':None,'resource_policy':policy,'compiled_input_record':compiled,
            'application_models':retain_objects}
        calls.append(True)
        return {'application_models':models}
    # The collector owns native byte/health/admission checks. This wrapper must
    # consume those qualified objects once, rather than read a second M20 set.
    monkeypatch.setattr(f5,'_read_final_lineage',read)
    monkeypatch.setattr(f5,'collect_final_refit_results',collect)
    if damage:
        with pytest.raises(ContractError,match='F5_APPLICATION_FINAL_MODEL_SOURCE_MISMATCH'):
            application.load_application_models(lineage,tmp_path,tmp_path,workers=None,
                resource_policy=policy,compiled_input_record=compiled,retain_objects=retain_objects)
        assert calls == []
    else:
        result = application.load_application_models(lineage,tmp_path,tmp_path,workers=None,
            resource_policy=policy,compiled_input_record=compiled,retain_objects=retain_objects)
        assert result is models and calls == [True]


@pytest.mark.parametrize('symlink',[False,True])
def test_full_a04_first_cohort_publication_has_real_parent(tmp_path,monkeypatch,symlink):
    # UNFITTED entry-point fixture; no MICE or model prediction runs.
    import copy
    from padml import f5_application as app, carriers
    root=tmp_path.resolve()/'units/FULL0-H06';(root/'application/cohort').mkdir(parents=True)
    (root/'application/cohort/cohort.json').write_bytes(b'{}\n')
    context={'source':{'fixture':'QUALIFIED_CONTEXT_STUB'},'patient_keys':{}}
    cohort={'centers':[{'center':c,'selected_ids':[]} for c in ('36','38','39','48','52','54')],
            'source':context['source'],'patient_count':0}
    monkeypatch.setattr(app,'application_context',lambda *a,**kw:context)
    monkeypatch.setattr(app,'_application_expand_qualified_cohort',lambda *a:copy.deepcopy(cohort))
    monkeypatch.setattr(app,'load_application_models',lambda *a,**kw:pytest.fail('native model unexpectedly reached'))
    monkeypatch.setattr(carriers,'file_reference',lambda path,role,run:{'path':str(path),'role':role})
    monkeypatch.setattr(carriers,'validate_reference',lambda *a,**kw:None)
    regression=[{'binding':{'unit_id':f'FULL0-H{h:02d}'},'regression_status':'PASS',
        'original_failure_closure':'CLOSED','coordinate_count':24,'original_failure_count':count,
        'identity_sha256':str(h)} for h,count in zip((6,12,24,36),(2,2,3,3))]
    run={'run_root':str(tmp_path.resolve())};unit={'kind':'FULL0','unit_id':'FULL0-H06','horizon':6}
    destination=root/'application-repair'/app.application_repair_decision()['identity_sha256']/'full-a04'
    if symlink:
        destination.mkdir(parents=True);outside=tmp_path/'foreign';outside.mkdir()
        (destination/'cohort').symlink_to(outside,target_is_directory=True)
        with pytest.raises(ContractError,match='APPLICATION_A04_COHORT_PATH_INVALID'):
            app.run_full_application_cohort(run,unit,root,{}, {},{'raw_binding_root':str(tmp_path)},original_regressions=regression)
        assert not list(outside.iterdir())
    else:
        result=app.run_full_application_cohort(run,unit,root,{}, {},{'raw_binding_root':str(tmp_path)},original_regressions=regression)
        assert (destination/'cohort/cohort.json').read_bytes()==canonical_json_bytes(cohort)
        assert result['new_model_fits']==result['new_mice_chains']==0
        assert len(result['comparisons'])==24 and {r['status'] for r in result['comparisons']}=={'NOT_APPLICABLE'}
        assert result['application_admission']=='BLOCKED_PENDING_COMPLETE_A04_REVIEW'
        assert app.run_full_application_cohort(run,unit,root,{}, {},{'raw_binding_root':str(tmp_path)},original_regressions=regression)==result


# UNFITTED preparation-space rejection must precede numerical-view or ZIP writes.
@pytest.mark.parametrize('present',[0,1])
def test_full_application_zip_preparation_uses_missing_count_before_writes(tmp_path,monkeypatch,present):
    import copy
    from padml import f5_application as app,runtime
    root=tmp_path/'units/FULL0-H06';(root/'application/cohort').mkdir(parents=True)
    (root/'application/cohort/cohort.json').write_bytes(b'{}\n')
    ctx={'source':{'UNFITTED':True},'patient_keys':{'p1':'1'*64,'p2':'2'*64},
         'columns':['Patient_ID','Age'],'raw_rows':{'p1':{'Patient_ID':'p1','Age':'11'},'p2':{'Patient_ID':'p2','Age':'12345'}}}
    cohort={'source':ctx['source'],'patient_count':2,'centers':[{'center':'36','selected_ids':['p1','p2']}]}
    monkeypatch.setattr(app,'application_context',lambda *a,**kw:ctx)
    monkeypatch.setattr(app,'_application_expand_qualified_cohort',lambda *a:copy.deepcopy(cohort))
    members={'input.json':b'{}\n','covariates.csv':b'UNFITTED donor and patient\n'}
    monkeypatch.setattr(app,'application_input_members',lambda *a,**kw:members)
    monkeypatch.setattr(app,'load_application_models',lambda *a,**kw:pytest.fail('no model load during admission failure'))
    monkeypatch.setattr(app,'write_deterministic_zip',lambda *a,**kw:pytest.fail('patient ZIP written before preparation admission'))
    regs=[{'binding':{'unit_id':f'FULL0-H{h:02d}'},'regression_status':'PASS','original_failure_closure':'CLOSED',
           'coordinate_count':24,'original_failure_count':count,'identity_sha256':str(h)} for h,count in zip((6,12,24,36),(2,2,3,3))]
    folder=root/'application-repair'/app.application_repair_decision()['identity_sha256']/'full-a04'
    if present:
        (folder/'inputs').mkdir(parents=True)
        (folder/'inputs'/('1'*64+'.zip')).write_bytes(b'UNFITTED preserved old input')
    calls=[]
    def blocked(policy,where,**kw):calls.append(kw);raise OSError('UNFITTED_SPACE_REJECTED')
    monkeypatch.setattr(runtime,'admit_stage',blocked)
    run={'run_root':str(tmp_path),'resource_policy':{}}
    unit={'kind':'FULL0','unit_id':'FULL0-H06','horizon':6}
    with pytest.raises(OSError,match='UNFITTED_SPACE_REJECTED'):
        app.run_full_application_cohort(run,unit,root,{}, {},{'raw_binding_root':str(tmp_path)},original_regressions=regs)
    assert len(calls)==1 and calls[0]['retained_bytes']==(2-present)*calls[0]['publication_bytes']
    assert calls[0]['publication_bytes']>=sum(map(len,members.values()))+64*1024
    assert len(list((folder/'inputs').iterdir()))==present
    if present:assert (folder/'inputs'/('1'*64+'.zip')).read_bytes()==b'UNFITTED preserved old input'
