"""One retained synthetic source replay; zero new chains, paths or models."""
import os
from pathlib import Path
import shutil
import subprocess

import pytest

from padml import f4
from padml.bundle import canonical_json_bytes, strict_json_bytes, sha256_file
from padml.runtime import RSCRIPT_EXECUTABLE


def test_retained_learning_recipe_source_rebuild_without_new_fits(tmp_path, monkeypatch):
    if os.environ.get("PADML_LEARNING_RECIPE_REPLAY") != "1":
        pytest.skip("One explicitly selected retained-M5 source replay only")
    mice = Path(os.environ["PADML_LEARNING_MICE_RETAINED"])
    selector = Path(os.environ["PADML_LEARNING_SELECTOR_RETAINED"])
    original = selector / "native-tests/test_m5_native_fixed_inner_and0/inputs"
    original_fingerprints = {str(path): sha256_file(path) for path in original.rglob("*") if path.is_file()}
    contract, cell, keys = [strict_json_bytes((mice / name).read_bytes()) for name in ("binding.json", "cell.json", "patient-keys.json")]
    covariates, responses = [(mice / name).read_bytes() for name in ("covariates.csv", "response.csv")]
    root = tmp_path.resolve()
    native = root / "retained-mids"
    shutil.copytree(mice / "fixed-m5", native)
    run, actions = subprocess.run, []
    def bounded(command, **kwargs):
        kernel = Path(command[2]).name
        assert kernel in {"f4_learning_mice.R", "f4_learning_recipe.R"}
        if kernel == "f4_learning_mice.R":
            assert command[3] == "REPLAY"
        actions.append(kernel)
        return run(command, **kwargs)
    monkeypatch.setattr(f4.subprocess, "run", bounded)
    def forbidden(*args, **kwargs):
        raise AssertionError("NO_NEW_SCIENTIFIC_FITS_IN_SOURCE_REPLAY")
    for name in ("_run_learning_selector_path", "_execute_f4_model_component", "_execute_f4_stop_component", "_bounded_ordered_spawn"):
        monkeypatch.setattr(f4, name, forbidden)
    result = f4._replay_learning_selector_inputs(contract, covariates, responses, keys, cell, native,
                                                original, root / "replayed-inputs", rscript=RSCRIPT_EXECUTABLE)
    assert [row["inner_fold"] for row in result] == [2, 3, 4, 5, 0]
    assert actions == ["f4_learning_mice.R"] * 2 + ["f4_learning_recipe.R"] * 5
    assert {str(path): sha256_file(path) for path in original.rglob("*") if path.is_file()} == original_fingerprints
    (root / "source-replay.json").write_bytes(canonical_json_bytes({
        "data": "RETAINED_SYNTHETIC_M5_NOT_FORMAL_PATIENT_CELL", "actions": actions,
        "new_predictive_fits": 0, "new_stop_fits": 0, "new_mice_chains": 0, "new_selector_paths": 0,
        "deterministic_recipe_recomputations": 5, "fit_rows": len(cell["analysis_ids"]),
        "validation_rows": len(cell["validation_ids"]), "source_fingerprints": original_fingerprints,
    }))
