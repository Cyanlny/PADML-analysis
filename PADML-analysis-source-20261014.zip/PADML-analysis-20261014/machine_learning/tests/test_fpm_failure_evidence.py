"""Zero-fit tests of failure-only evidence, not new scientific criteria."""
import shutil
import subprocess
from pathlib import Path

import pytest


R_CHECK = r'''
args <- commandArgs(trailingOnly=TRUE)
definitions <- as.list(parse(file=args[[1L]]))
for (name in c("fpm_evaluate_checks", "fpm_require_checks", "fpm_preserve_failure")) {
  found <- Filter(function(x) is.call(x) && identical(x[[1L]],as.name("<-")) &&
                    identical(x[[2L]],as.name(name)), definitions)
  stopifnot(length(found)==1L)
  eval(found[[1L]])
}
value <- 2
checks <- fpm_evaluate_checks(alist(
  valid = value == 2, failed = value == 3, missing = NA,
  malformed = stop("native missing evidence"), empty = logical()
))
error <- tryCatch(fpm_require_checks(checks,"F2_FPM_FIT_HEALTH_INVALID"),error=identity)
stopifnot(inherits(error,"padml_fpm_health_error"),
  identical(conditionMessage(error),"F2_FPM_FIT_HEALTH_INVALID"),
  identical(error$failed_predicates,c("failed","missing","malformed","empty")),
  identical(error$checks$malformed$evaluation_error,"native missing evidence"),
  is.null(fpm_require_checks(checks["valid"],"unused")))
output_path <- file.path(args[[2L]],"output.json")
input <- list(task_id="SYNTHETIC_EVIDENCE_TEST_NO_FIT",value=pi)
fpm_preserve_failure(error,NULL,input)
stopifnot(!file.exists(file.path(args[[2L]],"fit.rds")),
  identical(readRDS(file.path(args[[2L]],"fit-input.rds")),input))
saved <- readRDS(file.path(args[[2L]],"fit-error.rds"))
stopifnot(identical(saved$failed_predicates,error$failed_predicates),
  identical(saved$checks,error$checks),identical(saved$fit_present,FALSE))
'''


def test_named_failures_and_absent_fit_are_not_hidden(tmp_path):
    rscript = shutil.which("Rscript")
    if not rscript:
        pytest.skip("Rscript required for native evidence helper test")
    source = Path(__file__).resolve().parents[1] / "padml/kernels/f2_model_development.R"
    result = subprocess.run([rscript, "-e", R_CHECK, str(source), str(tmp_path)],
                            text=True, capture_output=True, timeout=30)
    assert result.returncode == 0, result.stderr


def test_successful_fit_binary_retention_is_atomic_only():
    source = (Path(__file__).resolve().parents[1] / "padml/kernels/f2_model_development.R").read_text()
    assert source.count("if (length(spec$producer_tasks) == 1L) saveRDS(") == 2
