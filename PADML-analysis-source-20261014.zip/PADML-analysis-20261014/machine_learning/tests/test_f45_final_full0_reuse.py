"""UNFITTED whole-source, final-M20, SHAP and application custody boundaries.

The model/native leaves and upstream compiler proof are synthetic. Native
contexts, independent locks, input ABIs, first-number consumers and byte pins
remain active. No clinical fit or completed scientific unit is asserted.
"""
import copy
import os
import shutil
from pathlib import Path

import pytest

from padml import f4, f5, f5_application, runtime, nested_loco as n
from padml.bundle import ContractError, canonical_json_bytes as encode, read_safe_zip, write_deterministic_zip
from test_f45_final_primary_reuse import pin, seal
from test_f45_final_reuse import final_entries
from test_f5 import final_shap_components
from test_nested_loco import _summary
from test_full0_cox12_prepare import _observe, _policy


def fixture(root, monkeypatch, changed=0, *, producer_horizon=6):

    # New independent reads use the original pool seam; native leaves stay UNFITTED.
    # Pickle each task exactly as spawn transport; results keep canonical order.
    from padml import runtime
    import pickle
    def readback(function, items, **kwargs):
        result = [None] * len(items)
        for index in range(len(items)):
            fn, item = pickle.loads(pickle.dumps((function, items[index])))
            result[index] = fn(item)
        return result
    monkeypatch.setattr(runtime, "_readback_ordered", readback)
    members = f4._f45_source_member_sha256()
    identity = n._sha(members)
    keys = {*f5._final_search_sources(), *("padml/" + name for name in (
        "nested_loco.py", "runtime.py", "f2_validation.py", "kernels/f5_final_refit.R",
        "kernels/f5_design.R", "kernels/f4_learning_selector.R", "kernels/f4_learning_recipe.R"))}
    program = n._sha({key: members[key] for key in keys})
    monkeypatch.setattr(f5, "_f45_score_reuse_authorities", lambda: ({"e"*64: identity}, {identity: members}))
    monkeypatch.setattr(f5, "_validate_final_r_fit_health", lambda *a, **k: None)
    monkeypatch.setattr(f5, "_validate_retained_r_audit_numbers", lambda *a, **k: None)
    monkeypatch.setattr(runtime, "observe_execution_resources", _observe)
    monkeypatch.setattr(f5, "resolve_pool_workers", lambda value: 2)
    science = n.science_decision_template(24)
    ids = [f"p{i:02d}" for i in range(40)]
    response = ("Patient_ID,All_Cause_Death,Death_Followup_months\n" + "".join(f"{p},1,50\n" for p in ids)).encode()
    context = n.compile_training_context(scope="FULL_DATA", outer_fold=0, heldout_center=None,
        training_ids=ids, heldout_ids=[], centers_by_patient={p:"38" for p in ids},
        training_response_csv=response, mice_member_set_sha256="a"*64,
        preprocessing_program_sha256=program, modeling_program_sha256=program, seed_program_sha256="d"*64)
    base = final_entries("COX_PH", "FULL0")
    fields = base["fit-covariates.csv"].decode().splitlines()[0].split(",")
    covariates = (",".join(fields) + "\n" + "".join(",".join(p if name=="Patient_ID" else
        "38" if name=="Center" else "1" for name in fields)+"\n" for p in ids)).encode()
    base.update({"fit-response.csv": response, "fit-covariates.csv":covariates,
                 "prediction-covariates.csv":covariates})
    spec = f5.strict_json_bytes(base["task.json"])["parameters"]
    recipe = f5.strict_json_bytes(base["recipe.json"])
    recipe["transform_recipe"]["partition_id"] = "F5_FINAL_FULL_DATA"
    recipe["transform_recipe"]["recipe_sha256"] = n._sha({k:v for k,v in recipe["transform_recipe"].items()
                                                        if k != "recipe_sha256"})
    base["recipe.json"] = encode(recipe)
    owners = []
    for h in (producer_horizon, 12):
        owner = root / f"FULL0-H{h:02d}"
        inputs, outputs = owner / "final-input", owner / "final-result"
        inputs.mkdir(parents=True)
        outputs.mkdir()
        scores = [n.seal_fresh_training_score(family=fam, outer_fold=0,
            training_context_sha256=context["identity_sha256"],
            selected_spec=spec if fam=="COX_PH" else {"family":fam,"UNFITTED":True},
            selector_evidence_sha256="a"*64, summary={**_summary(.1+j*.01),"selection_horizon_months":h},
            execution_evidence_sha256="f"*64, selection_horizon_months=h,
            science_decision_sha256=science["identity_sha256"], source_kind="FRESH_FULL_DATA_M20_INNER_OOF")
            for j, fam in enumerate(n._families())]
        decision = n.select_training_family(scores)
        templates, template_records, entries_by_mi = [], [], []
        for imp in range(1,21):
            entries = copy.deepcopy(base)
            task = f5.strict_json_bytes(entries["task.json"])
            task.pop("development_lock_sha256")
            task.update(imputation=imp,row_count=40)
            task["f4_coordinates"]["imputation"] = imp
            task["registered_model_seed"] = f4._f4_model_seed("COX_PH",task["f4_coordinates"])
            if h==12 and imp>20-changed:
                entries["fit-covariates.csv"] = entries["fit-covariates.csv"].replace(b"p00,38,1",b"p00,38,2",1)
                entries["prediction-covariates.csv"] = entries["fit-covariates.csv"]
            source = task["nested_full_final_source"]
            source.update(training_context_sha256=context["identity_sha256"],
                family_decision_sha256=decision["identity_sha256"], selected_spec_sha256=n._sha(spec),
                selector_development_sha256="a"*64, selected_parents_sha256=n._sha(task["selected_parents"]),
                training_ids_sha256=context["training_ids_sha256"], training_response_sha256=n.sha256_bytes(response),
                recipe_sha256=n._sha(recipe), mice_member_sha256=n.sha256_bytes(entries["fit-covariates.csv"]))
            entries["task.json"] = encode(task)
            path = inputs / f"templates/M{imp:02d}.zip"
            path.parent.mkdir(exist_ok=True)
            write_deterministic_zip(path,entries)
            templates.append(task)
            entries_by_mi.append(entries)
            template_records.append({"path":str(path.relative_to(inputs)), "imputation":imp,
                "task_sha256":n._sha(task),**pin(path)})
        lock = n.seal_development_lock(context=context,decision=decision,science_decision=science,
            selected_parents=["AST_ALT"], common_set_design_df=1, training_event_count=40,
            baseline_policy_sha256="b"*64, seed_policy_sha256="d"*64,
            parameters_by_imputation=[spec]*20, recipe_sha256_by_imputation=[n._sha(recipe)]*20,
            post_lock_template_sha256_by_imputation=[n._sha(task) for task in templates],
            post_lock_template_archive_sha256_by_imputation=[r["sha256"] for r in template_records],
            epv_resolution={"preferred_minimum":15,"minimum":15,"fallback_used":False,
                "coarse_records_sha256":"b"*64,"reason_code":"OK", "attempts":[{"minimum":15,
                    "alpha_feasibility":[{"alpha":alpha,"status":"FEASIBLE"} for alpha in
                        f5.load_science_authority()["science"]["f2_model_development"]["selector_contract"]["alpha_grid"]["coarse"]]}]})
        records, tasks = [], {}
        for imp,(task,entries) in enumerate(zip(templates,entries_by_mi),1):
            task = n.bind_post_lock_task(task,lock)
            entries["task.json"] = encode(task)
            path = inputs / f"bound/M{imp:02d}.zip"
            path.parent.mkdir(exist_ok=True)
            write_deterministic_zip(path,entries)
            record = n._validate_full_final_component(path,context=context,lock=lock)
            records.append({**record,"role":"POST_LOCK_FINAL","path":str(path.relative_to(inputs)),**pin(path)})
            tasks[imp] = task
        plan = seal(dict(schema_version=n.SCHEMA_VERSION,kind="PADML_NESTED_FULL_FINAL_INPUT_V1",
            program_id=n.PROGRAM_ID, selection_horizon_months=h, science_decision=science,
            training_context=context, family_decision=decision, development_lock=lock,
            score_request_identity_sha256="a"*64,score_result_identity_sha256="b"*64,
            component_records=records,template_records=template_records,
            planned_post_lock_model_fits=20,new_stop_fits=0,new_mice_chains=0,external_validation=False))
        lineage = dict(final_refit_plan=plan,family_decision=decision,final_recipe=recipe,selection_horizon_months=h)
        (inputs / "lineage.json").write_bytes(encode(lineage))
        (inputs / "full-final-input.json").write_bytes(encode(plan))
        index = seal(dict(kind="PADML_F5_FINAL_REFIT_BUNDLE_INDEX_V1",status="COMPILED_NOT_EXECUTED",
            bundle_count=20,model_fit_count=0,execution_profile={"pool_workers":f5.CPU_MINUS_8},host_parallelism=1,
            development_lock_sha256=lock["identity_sha256"],training_context_sha256=context["identity_sha256"],
            final_refit_plan_sha256=plan["identity_sha256"],family_decision_sha256=decision["identity_sha256"],
            family="COX_PH",bundles=[dict(imputation=imp,task_id=f"F5_FINAL_FULL_DATA_M{imp:02d}",
                task_sha256=records[imp-1]["task_sha256"],filename=records[imp-1]["path"],
                sha256=records[imp-1]["sha256"],size_bytes=records[imp-1]["size_bytes"]) for imp in range(1,21)]))
        (inputs/"dispatch-index.json").write_bytes(encode(index))
        owners.append((owner,inputs,outputs,lineage,tasks))
    def consume(lineage,*a,**kw):
        # Only the completed upstream compiler is isolated. Every bound task
        # and independent lock is read again by the original final consumers.
        if kw.get("application_readback") is not None:
            plan = lineage["final_refit_plan"]
            values = [f5._full_final_bound_read_job(dict(row=row, input_root=kw["input_root"],
                context=plan["training_context"], lock=plan["development_lock"],
                recipe=lineage["final_recipe"], application=kw["application_readback"]))
                for row in plan["component_records"]]
            return {v[0]:v[1] for v in values}, [v[2] for v in values], [v[3] for v in values]
        return {i:n._read_component(kw["input_root"]/f"bound/M{i:02d}.zip")[0] for i in range(1,21)}
    monkeypatch.setattr(f5,"_consume_final_parameter_source",consume)
    counts = {"fit":0,"audit":0,"shap":0,"pools":[]}
    curve = [1.]+[1-month*.01 for month in range(1,37)]
    def fit(job, include_execution=False, retained_only=False):
        assert retained_only is False, "this fixture only produces fresh UNFITTED models"
        counts["fit"]+=1
        entries,directory = job["entries"],Path(job["root"])
        directory.mkdir(parents=True)
        task,_,training,_,application,_ = f4._f4_native_component_inputs(entries)
        native = {**entries,"model.bin":b"UNFITTED_MODEL","baseline.bin":b"UNFITTED_BASELINE",
            "fit-health.json":encode({"UNFITTED":True}),
            "prediction.json":encode(f4._f4_native_prediction(task,application,[curve]*len(application))),
            "training-prediction.json":encode([curve]*len(training))}
        write_deterministic_zip(directory.with_suffix(".zip"),native)
        return {"new_model_fits":1}
    def audit(job,include_audit=False):
        counts["audit"]+=1
        raw=read_safe_zip(Path(job["archive"]))
        assert all(raw[k]==v for k,v in job["entries"].items())
        return dict(prediction=f5.strict_json_bytes(raw["prediction.json"]),fit_health={"UNFITTED":True},
            retained_audit={"design_columns":["AST_ALT"],"training_event_count":40,"UNFITTED":True,
                "coefficient_ids":["AST_ALT"],"complete_data_degrees_of_freedom":39,
                "covariance":[[.01]],"coefficient_estimates":[.1],"within_standard_errors":[.1]})
    def shap(source,task,model,baseline,prediction,**kw):
        counts["shap"]+=1
        result=final_shap_components({"patient_ids":ids,"family":"COX_PH","per_imputation_predictions":[prediction]*20}, max_iter=2000)
        return result[task["imputation"]-1]
    def pool(function,jobs,*,execution_report,selected_slots,**kw):
        assert jobs,"empty pool is forbidden"
        if function is f5._execute_final_refit_bundle_pair:
            assert kw["task_timeout_seconds"] == 24 * 60 * 60
            assert "task_deadlines" not in kw  # Each MI owns its full audit -> SHAP deadline.
            assert sorted(kw["schedule_order"]) == list(range(len(jobs)))
        counts["pools"].append(len(jobs))
        values=[function(job) for job in jobs]
        execution_report.update(status="COMPLETED",runnable_task_count=len(jobs),completed_task_count=len(jobs),
            configured_worker_ceiling=2,admitted_worker_ceiling=selected_slots,actual_worker_process_peak=1,engine_threads=1)
        return values
    monkeypatch.setattr(f4,"_execute_f4_model_component",fit)
    monkeypatch.setattr(f4,"_replay_f4_model_component",audit)
    monkeypatch.setattr(f5,"_produce_final_shap_component",shap)
    monkeypatch.setattr(f5,"_bounded_ordered_spawn",pool)
    monkeypatch.setattr(runtime, '_ready_ordered', lambda function, items, **kwargs: pool(function, items,
        **{k:v for k,v in kwargs.items() if k not in {'policy', 'root', 'retained_bytes_per_task',
            'transient_bytes_per_worker', 'publication_bytes', 'memory_bytes_per_worker', 'task_write_paths', 'retained_bytes_by_task'}}))
    owner,inputs,outputs,lineage,tasks = owners[0]
    components = []
    for imp in range(1,21):
        result = f5._execute_final_refit_bundle_pair((inputs/f"bound/M{imp:02d}.zip",
            outputs/f"F5_FINAL_FULL_DATA_M{imp:02d}.zip",lineage["final_refit_plan"],tasks[imp],recipe))
        components.append({**result["shap_component_archive"],"member":f"shap-components/M{imp:02d}.zip",
                           "path":Path(result["shap_component_path"])})
    report = {"shap_component_archives":[{k:v for k,v in c.items() if k!="path"} for c in components]}
    write_deterministic_zip(owner/"result.zip",{"final-aggregate.json":encode(report),
        **{c["member"]:c["path"] for c in components}})
    artifacts = {str(p.relative_to(owner)):pin(p) for p in [owner/"result.zip",
        inputs/"full-final-input.json",*sorted((inputs/"bound").glob("*.zip")),
        *sorted(outputs.glob("*.zip")),*sorted(outputs.glob("*.numbers.json"))]}
    receipt = dict(status="COMPLETED",direct_consumer_completed=True,unit_id=owner.name,selection_horizon_months=producer_horizon,
        report_horizons_months=[6,12,24,36],run_identity="e"*64,artifacts=artifacts)
    (owner/"unit.json").write_bytes(encode(receipt))
    counts.update(fit=0,audit=0,shap=0,pools=[])
    return owners[1],dict(root=str(owner),receipt=receipt),counts


@pytest.mark.parametrize("changed",[0,1,20])
def test_full0_batch_reuses_only_exact_model_and_shap(tmp_path,monkeypatch,changed):
    (owner,inputs,outputs,lineage,tasks),candidate,counts=fixture(tmp_path,monkeypatch,changed)
    original={p:pin(p) for p in Path(candidate["root"]).rglob("*") if p.is_file()}
    result=f5.execute_final_refit_batch(inputs,outputs,resource_policy=_policy(),
        compiled_input_record={"UNFITTED_UPSTREAM":True},selection_horizon_months=12,completed_final_units=[candidate])
    assert result["final_model_fit_count"]==result["native_model_replay_count"]==counts["fit"]==counts["audit"]==changed
    assert result["new_shap_component_count"]==counts["shap"]==changed
    assert result["reused_final_model_count"]==20-changed
    assert all(pin(path)==value for path,value in original.items())
    # Native final consumer reopens original objects and current bindings;
    # no engine or first audit may follow publication of the numbers.
    for imp in range(1,21):
        value=f5._collect_final_refit_component((outputs/f"F5_FINAL_FULL_DATA_M{imp:02d}.zip",
            inputs/f"bound/M{imp:02d}.zip",tasks[imp],lineage["final_refit_plan"],lineage["family_decision"],None))
        prediction=f5._full_final_prediction_record(value["prediction"],value["receipt"],"COX_PH")
        job=(outputs/f"F5_FINAL_FULL_DATA_M{imp:02d}.zip",inputs/f"bound/M{imp:02d}.zip",
            value["archive"]["archive_sha256"],tasks[imp],outputs/"shap-components",prediction)
        if "reused_final" in value:
            job+=({"plan":lineage["final_refit_plan"],"numbers":value,"target":job[0]},)
        assert f5._collect_final_shap_component(job)["component"]["imputation"]==imp
    assert counts["fit"]==counts["audit"]==counts["shap"]==changed


def jobs_for(state):
    _,inputs,outputs,lineage,tasks=state
    return [(inputs/f"bound/M{i:02d}.zip",outputs/f"F5_FINAL_FULL_DATA_M{i:02d}.zip",
             lineage["final_refit_plan"],tasks[i],lineage["final_recipe"]) for i in range(1,21)]


def test_full0_model_hit_without_shap_body_computes_only_own_shap(tmp_path,monkeypatch):
    state,candidate,counts=fixture(tmp_path,monkeypatch)
    jobs=jobs_for(state)[:1]
    reused=f5._prepare_f45_full_final_reuse(state[3]["final_refit_plan"],state[2],jobs,[candidate],_policy())
    assert list(reused)==[1]
    original_task=n._read_component(Path(candidate["root"])/"final-input/bound/M01.zip")[0]
    native=f5._produce_final_shap_component
    def own_shap(source,task,*a,**kw):
        assert task==original_task and task!=state[4][1]
        return native(source,task,*a,**kw)
    monkeypatch.setattr(f5,"_produce_final_shap_component",own_shap)
    result=f5._execute_final_refit_bundle_pair(jobs[0])
    assert result["reused_final_model_count"]==1
    assert result["shap_component_archive"]["reuse_status"]=="COMPUTED_MISSING_EXACT_COMPONENT"
    assert counts["fit"]==counts["audit"]==0 and counts["shap"]==1 and counts["pools"]==[]
    repeated=f5._execute_final_refit_bundle_pair(jobs[0])
    assert repeated["shap_component_archive"]["reuse_status"]=="REUSED_EXACT_COMPONENT"
    assert counts["shap"]==1


def test_full0_reuse_interruption_and_original_byte_tampering(tmp_path,monkeypatch):
    state,candidate,counts=fixture(tmp_path,monkeypatch)
    jobs=jobs_for(state)[:1]
    plan,root=state[3]["final_refit_plan"],state[2]
    retain=f5._f45_retain_final_object
    def interrupt(stream,target,pin):
        if target==jobs[0][1]:
            raise RuntimeError("UNFITTED_STOP_BEFORE_NATIVE_PUBLICATION")
        return retain(stream,target,pin)
    with monkeypatch.context() as interrupted:
        interrupted.setattr(f5,"_f45_retain_final_object",interrupt)
        with pytest.raises(RuntimeError,match="STOP_BEFORE_NATIVE_PUBLICATION"):
            f5._prepare_f45_full_final_reuse(plan,root,jobs,[candidate],_policy())
    assert jobs[0][1].with_suffix(".reuse.json").is_file() and not jobs[0][1].exists()
    with pytest.raises(ContractError,match="PENDING_ORIGINAL_OBJECT_REQUIRED"):
        f5._prepare_f45_full_final_reuse(plan,root,jobs,[],_policy())
    result=f5._prepare_f45_full_final_reuse(plan,root,jobs,[candidate],_policy())
    assert list(result)==[1] and counts["fit"]==counts["audit"]==counts["shap"]==0
    source=root/result[1]["reused_final"]["source"]["path"]
    source_raw=source.read_bytes()
    source.write_bytes(source_raw+b" ")
    with pytest.raises(ContractError,match="SOURCE_DRIFT"):
        f5._prepare_f45_full_final_reuse(plan,root,jobs,[candidate],_policy())
    source.write_bytes(source_raw)
    native=jobs[0][1]
    native_raw=native.read_bytes()
    native.write_bytes(native_raw+b" ")
    with pytest.raises(ContractError,match="NATIVE_OBJECT_DRIFT"):
        f5._prepare_f45_full_final_reuse(plan,root,jobs,[candidate],_policy())
    native.write_bytes(native_raw)
    damaged=copy.deepcopy(candidate)
    damaged["receipt"]["run_identity"]="0"*64
    proof=f5.strict_json_bytes(source_raw)
    proof=seal({**proof,"whole_unit":damaged["receipt"]})
    with pytest.raises(ContractError,match="SOURCE_INVALID"):
        f5._f45_full_final_reuse_source(proof,plan,f5._f45_score_reuse_authorities())
    assert counts["fit"]==counts["audit"]==counts["shap"]==0


def test_full0_whole_members_application_and_shap_reopen(tmp_path,monkeypatch):
    state,candidate,counts=fixture(tmp_path,monkeypatch)
    owner,inputs,outputs,lineage,tasks=state
    f5.execute_final_refit_batch(inputs,outputs,resource_policy=_policy(),compiled_input_record={},
        selection_horizon_months=12,completed_final_units=[candidate])
    payload={"final-input/"+str(path.relative_to(inputs)):path for path in inputs.rglob("*") if path.is_file()}
    payload.update({"final-result/"+str(path.relative_to(outputs)):path for path in outputs.glob("*.zip")})
    payload.update({"final-result/"+str(path.relative_to(outputs)):path for path in outputs.glob("*.numbers.json")})
    payload.update({"final-result/"+name:outputs/name for name in f5._f45_full_final_reuse_members(outputs)})
    payload.update({"final-result/"+str(path.relative_to(outputs)):path for path in (outputs/"shap-components").glob("*.zip")})
    archive=tmp_path/"UNFITTED-whole-final-boundary.zip"
    write_deterministic_zip(archive,payload)
    portable=tmp_path/"portable"
    portable.mkdir()
    for name,raw in read_safe_zip(archive).items():
        path=portable/name
        path.parent.mkdir(parents=True,exist_ok=True)
        path.write_bytes(raw)
    # No reuse markers, producer working directories or fitters are required.
    assert not list(portable.rglob("*.reuse.json"))
    new_inputs,new_outputs=portable/"final-input",portable/"final-result"
    loaded=f5.collect_final_refit_results(new_outputs,lineage["family_decision"],lineage["final_refit_plan"],
        input_root=new_inputs,resource_policy=_policy(),compiled_input_record={})
    assert len(loaded["shap_components"])==20
    assert all(row["reuse_mode"]=="COMPLETED_WHOLE_SHAP" for row in loaded["shap_component_archives"])
    models=f5_application.load_application_models(lineage,new_inputs,new_outputs,workers=None,
        resource_policy=_policy(),compiled_input_record={})
    assert len(models)==20 and all(model["task"]!=model["producer_task"] for model in models)
    assert all(model["source"]["selection_horizon_months"]==12 for model in models)
    actual=[]
    def engine(family,task,covariates,response,recipe,*,retained_objects,prediction_rows,**kw):
        assert task==models[task["imputation"]-1]["producer_task"]
        assert task!=models[task["imputation"]-1]["task"]
        assert retained_objects==(b"UNFITTED_MODEL",b"UNFITTED_BASELINE")
        actual.append(task["imputation"])
        result = {"survival":[[1.]+[1-m*.01 for m in range(1,37)] for _ in prediction_rows]}
        if kw.get("single_parity"):
            result["single_survival"] = [[1.]+[1-m*.01 for m in range(1,37)] for _ in prediction_rows]
        return result
    monkeypatch.setattr(f5,"_execute_final_refit_engine",engine)
    donor_ids=lineage["final_refit_plan"]["training_context"]["training_ids"]
    completed=tmp_path/"completed-application"
    completed.mkdir()
    value=dict(kind="PADML_F5_APPLICATION_MICE_INPUT",validation=True,chain_seeds=[1,2],
        final_lineage_sha256=n._sha(lineage),view={"analysis_ids":donor_ids,"row_ids":[*donor_ids,"new"]},
        application_rows=[{"application_id":"new","center":"38","patient_key_hash":"f"*64}])
    raw=n._read_component(new_inputs/"bound/M01.zip")[2]["fit-covariates.csv"]
    appended=raw+b"new,38,"+b",".join(raw.splitlines()[1].split(b",")[2:])+b"\n"
    for imp in (1,2):
        (completed/f"imp{imp:02d}.csv").write_bytes(appended)
    application=f5_application.predict_completed_application(models,value,completed,tmp_path/"application-evidence",
                                                              prepared_parity=True)
    assert actual==[1,2] and application["selection_horizon_months"]==12
    assert application["new_model_fits"]==0 and counts["fit"]==counts["audit"]==counts["shap"]==0


@pytest.mark.parametrize('changed',[0,20])
def test_archived_application_models_consume_without_linux_source_or_copies(tmp_path,monkeypatch,changed):
    logical=tmp_path/'linux-run'
    state,candidate,counts=fixture(logical,monkeypatch,changed=changed)
    owner,inputs,outputs,lineage,tasks=state
    f5.execute_final_refit_batch(inputs,outputs,resource_policy=_policy(),compiled_input_record={},
        selection_horizon_months=12,completed_final_units=[candidate])
    before=f5_application.load_application_models(lineage,inputs,outputs,workers=None,
        resource_policy=_policy(),compiled_input_record={})
    target=tmp_path/'external';target.mkdir();(target/'objects').mkdir()
    small={};members={}
    for path in owner.rglob('*'):
        if not path.is_file() or '.work' in path.parts:continue
        name=path.relative_to(logical).as_posix();stamp=pin(path)
        if path.suffix=='.zip':
            storage='objects/'+stamp['sha256']
            if not (target/storage).exists():shutil.copyfile(path,target/storage)
            members[name]={'pin':stamp,'storage':storage,'physical':stamp,'member':None}
        else:small[name]=path.read_bytes()
    pack=target/'metadata.zip';write_deterministic_zip(pack,small)
    for name,raw in small.items():
        members[name]={'pin':{'sha256':n.sha256_bytes(raw),'size_bytes':len(raw)},
            'storage':pack.name,'physical':pin(pack),'member':name}
    run={'kind':'PADML_INTEGRATED_RAW_RUN_V1','run_root':str(logical),
         'identity':'a'*64,'source_identity':'b'*64}
    (target/'run.json').write_bytes(encode(run))
    (target/'index.json').write_bytes(encode(seal({'kind':'PADML_WINDOW_ARCHIVE_INDEX_V1',
        'run_identity':run['identity'],'source_identity':run['source_identity'],'members':members,'windows':{}})))
    shutil.rmtree(logical)
    monkeypatch.setenv('PADML_F45_RUN_PATH',str(target/'run.json'))
    monkeypatch.setenv('PADML_ARCHIVE_INDEX',str(target/'index.json'))
    expected_files={p.relative_to(target) for p in target.rglob('*') if p.is_file()}
    models=f5_application.load_application_models(lineage,inputs,outputs,workers=None,
        resource_policy=_policy(),compiled_input_record={})
    assert models==before and len(models)==20
    assert not logical.exists()
    assert {p.relative_to(target) for p in target.rglob('*') if p.is_file()}==expected_files


def test_full0_missing_original_model_body_is_a_miss(tmp_path,monkeypatch):
    state,candidate,counts=fixture(tmp_path,monkeypatch)
    owner=Path(candidate["root"])
    body=owner/"final-result/F5_FINAL_FULL_DATA_M01.zip"
    body.rename(body.with_suffix(".unavailable"))
    jobs=jobs_for(state)[:1]
    found=f5._prepare_f45_full_final_reuse(state[3]["final_refit_plan"],state[2],jobs,[candidate],_policy())
    assert found=={} and not jobs[0][1].exists()
    assert counts["fit"]==counts["audit"]==counts["shap"]==0


def test_budget_exhausted_mi_retains_other_explanations_and_original_models(tmp_path, monkeypatch):
    state, _, counts = fixture(tmp_path, monkeypatch)
    _, inputs, outputs, _, _ = state
    def unavailable(*args, **kwargs):
        raise f5._FinalShapBudgetExhausted("UNFITTED_MISSING_EXPLANATION")
    with monkeypatch.context() as patch:
        patch.setattr(f5, "_collect_final_shap_component", unavailable)
        for job in jobs_for(state):
            assert f5._execute_final_refit_bundle_pair(job)["status"] == "SHAP_BUDGET_EXHAUSTED"
    originals = {p: pin(p) for p in [*outputs.glob("F5_FINAL_FULL_DATA_M*.zip"), *outputs.glob("*.numbers.json")]}
    assert len(originals) == 40
    produce, calls = f5._produce_final_shap_component, []
    def shap(source, task, *args, **kwargs):
        calls.append(task["imputation"])
        if task["imputation"] == 5:
            (kwargs["work_root"] / "kernelshap-return.rds").write_bytes(b"UNFITTED_RAW")
            raise f5._FinalShapBudgetExhausted("UNFITTED_VALIDATED_BUDGET_EXHAUSTION")
        return produce(source, task, *args, **kwargs)
    monkeypatch.setattr(f5, "_produce_final_shap_component", shap)
    counts.update(fit=0, audit=0, shap=0, pools=[])
    for _ in range(2):
        with pytest.raises(ContractError, match="^F5_FULL_FINAL_SHAP_INCOMPLETE:5$"):
            f5.execute_final_refit_batch(inputs, outputs, resource_policy=_policy(), selection_horizon_months=12)
        assert len(list((outputs / "shap-components").glob("*.zip"))) == 19
    assert calls == list(range(1, 21)) + [5]
    assert counts["fit"] == counts["audit"] == 0
    assert originals == {p: pin(p) for p in originals}


def test_patient_shap_partial_resume_uses_parent_deadline_and_retained_model(tmp_path, monkeypatch):
    """Original input/spec/log adapter, cancelled R leaf; no actual model or SHAP calculation."""
    produce = f5._produce_final_shap_component
    _, candidate, counts = fixture(tmp_path, monkeypatch)
    owner = Path(candidate["root"])
    source = owner / "final-input/bound/M01.zip"
    target = owner / "final-result/F5_FINAL_FULL_DATA_M01.zip"
    task = n._read_component(source)[0]
    native = read_safe_zip(target)
    numbers = f5.strict_json_bytes(target.with_suffix(".numbers.json").read_bytes())
    prediction = f5._full_final_prediction_record(numbers["prediction"], numbers["receipt"], task["family"])
    before = {path: pin(path) for path in (source, target, target.with_suffix(".numbers.json"))}
    work = tmp_path.resolve() / "patient-work"
    work.mkdir()
    monkeypatch.setattr(runtime, "_ACTIVE_TASK_DEADLINE", 212.)
    monkeypatch.setattr(runtime, "monotonic", lambda: 200.)
    seen = []
    def cancelled(command, **kwargs):
        spec = f5.strict_json_bytes(Path(command[-1]).read_bytes())
        assert spec["shap_contract"] == {"max_iter": 2000, "tol": .005,
            "original_stream_max_iter": 500, "rng_policy": "ORIGINAL_500_PATIENT_START"}
        assert kwargs["timeout"] == 12. and spec["task"] == task
        seen.append(command)
        kwargs["stdout"].write(b"partial-patient-progress")
        kwargs["stdout"].flush()
        raise SystemExit("BOUNDED_SPAWN_CANCELLED")
    monkeypatch.setattr(f5.subprocess, "run", cancelled)
    for attempt in range(2):
        with pytest.raises(SystemExit, match="BOUNDED_SPAWN_CANCELLED"):
            produce(source, task, native["model.bin"], native["baseline.bin"], prediction, work_root=work)
        assert (work / ("resume-stdout.log" if attempt else "stdout.log")).read_bytes() == b"partial-patient-progress"
    monkeypatch.setattr(runtime, "monotonic", lambda: 213.)
    with pytest.raises(ContractError, match="BOUNDED_SPAWN_TASK_DEADLINE_EXCEEDED"):
        produce(source, task, native["model.bin"], native["baseline.bin"], prediction, work_root=work)
    assert len(seen) == 2 and not (work / "shap.json").exists()
    assert before == {path: pin(path) for path in before}
    # A finite pilot preserves a diagnostic BUDGET_EXHAUSTED result; whole-MI
    # production still uses the strict default reader. This is a mocked R leaf.
    monkeypatch.setattr(runtime, "monotonic", lambda: 200.)
    def returned(command, **kwargs):
        assert command[-1] == "1" and kwargs["timeout"] == 12.
        (work / "pilot-diagnostic.json").write_bytes(b"{}")
        from types import SimpleNamespace
        return SimpleNamespace(returncode=0)
    def pilot_reader(root, observed_task, observed_prediction, model_sha, **kwargs):
        assert root == work and observed_task == task
        assert observed_prediction["patient_ids"] == [prediction["patient_ids"][0]]
        assert kwargs == {"filename": "pilot-diagnostic.json", "require_converged": False}
        return {"status": "BUDGET_EXHAUSTED", "max_iter": 2000}
    monkeypatch.setattr(f5.subprocess, "run", returned)
    monkeypatch.setattr(f5, "_read_final_shap_diagnostic", pilot_reader)
    assert produce(source, task, native["model.bin"], native["baseline.bin"], prediction,
        work_root=work, pilot_patient_index=1)["status"] == "BUDGET_EXHAUSTED"
    assert before == {path: pin(path) for path in before}
    assert not (work / "shap.json").exists()
    assert counts["fit"] == counts["audit"] == counts["shap"] == 0


@pytest.mark.parametrize("budget", [100, 500, 2000])
def test_previous_complete_shap_keeps_original_producer_and_budget(tmp_path, monkeypatch, budget):
    _, candidate, _ = fixture(tmp_path, monkeypatch)
    owner = Path(candidate["root"])
    source = owner / "final-input/bound/M01.zip"
    target = owner / "final-result/F5_FINAL_FULL_DATA_M01.zip"
    task = n._read_component(source)[0]
    numbers = f5.strict_json_bytes(target.with_suffix(".numbers.json").read_bytes())
    prediction = f5._full_final_prediction_record(numbers["prediction"], numbers["receipt"], task["family"])
    sources = {"padml/f5.py": "a" * 64, "padml/kernels/f5_shap.R":
        "f696acc0b81c3c95586de35f774ece0ac1a0863fbab24574e9c31c4b7f0806a2" if budget == 2000 else
        "0ac8ff1d23782146798b6349df318f53b25b4fa2e9a553a8b69a116fb13333e7" if budget == 500 else
        "584000e05f81ebbc6cdbb7406e069561be71ef4d32071480168db800a0032fe0"}
    monkeypatch.setattr(f5, "_f45_score_reuse_authorities", lambda: ({}, {"a" * 64: sources}))
    binding = f5._f45_final_shap_binding(source, numbers["archive"]["archive_sha256"], task, prediction, sources)
    root = tmp_path.resolve() / "legacy-shap"
    root.mkdir()
    archive = root / f"F5_FINAL_AGGREGATE_SHAP_M01_{binding['identity_sha256']}.zip"
    component = final_shap_components({"patient_ids": prediction["patient_ids"], "family": task["family"],
        "per_imputation_predictions": [prediction]}, max_iter=budget)[0]
    write_deterministic_zip(archive, {"binding.json": encode(binding), "component.json": encode(component)})
    original = archive.read_bytes()
    value, record, path = f5._load_or_produce_final_shap_checkpoint(root, source,
        numbers["archive"]["archive_sha256"], task, None, None, prediction)
    assert value["engine"]["max_iter"] == budget and path == archive
    assert record["binding_identity_sha256"] == binding["identity_sha256"]
    assert archive.read_bytes() == original
    component = final_shap_components({"patient_ids": prediction["patient_ids"], "family": task["family"],
        "per_imputation_predictions": [prediction]}, max_iter=500 if budget == 100 else 100)[0]
    archive.unlink()
    write_deterministic_zip(archive, {"binding.json": encode(binding), "component.json": encode(component)})
    with pytest.raises(ContractError, match="F5_SHAP_PREVIOUS_PRODUCER_DRIFT"):
        f5._load_or_produce_final_shap_checkpoint(root, source,
            numbers["archive"]["archive_sha256"], task, None, None, prediction)


def test_full0_pending_keeps_original_producer_and_ordered_parallel_returns(tmp_path, monkeypatch):
    state, original, counts = fixture(tmp_path / "original", monkeypatch, producer_horizon=24)
    with monkeypatch.context() as other:
        _, earlier, _ = fixture(tmp_path / "earlier", other)
    owner, inputs, outputs, lineage, tasks = state
    plan = lineage["final_refit_plan"]
    jobs = [(inputs / f"bound/M{i:02d}.zip", outputs / f"F5_FINAL_FULL_DATA_M{i:02d}.zip",
        plan, tasks[i], lineage["final_recipe"]) for i in (1, 2)]
    retain = f5._f45_retain_final_object
    def stop_model(stream, target, pin):
        if target == jobs[0][1]:
            raise OSError("UNFITTED pending original model")
        return retain(stream, target, pin)
    with monkeypatch.context() as interrupted:
        interrupted.setattr(f5, "_f45_retain_final_object", stop_model)
        with pytest.raises(OSError, match="pending original model"):
            f5._prepare_f45_full_final_reuse(plan, outputs, jobs, [original], _policy())
    marker = jobs[0][1].with_suffix(".reuse.json")
    pinned = marker.read_bytes()
    assert "FULL0-H24" in pinned.decode()
    with pytest.raises(ContractError, match="PENDING_ORIGINAL_OBJECT_REQUIRED"):
        f5._prepare_f45_full_final_reuse(plan, outputs, jobs[:1], [earlier], _policy())
    def reversed_readback(fn, items, **kwargs):
        values = [None] * len(items)
        for index in reversed(range(len(items))):
            values[index] = fn(items[index])
        return values
    monkeypatch.setattr(runtime, "_readback_ordered", reversed_readback)
    result = f5._prepare_f45_full_final_reuse(plan, outputs, jobs, [earlier, original], _policy())
    assert set(result) == {1, 2} and marker.read_bytes() == pinned
    assert result[1]["reused_final"]["source"]["path"].startswith("final-reuse/FULL0-H24/")
    assert result[2]["reused_final"]["source"]["path"].startswith("final-reuse/FULL0-H06/")
    assert all("objects" not in row for row in result.values())
    assert counts["fit"] == counts["audit"] == counts["shap"] == 0


def test_finite_patient_pilot_serializes_twenty_original_pins_and_direct_result(tmp_path, monkeypatch):
    """Original unfitted M20 reader -> selection file -> mocked SHAP leaf -> result."""
    import importlib.util
    import sys
    script = Path(__file__).parents[1] / 'execution/patient-recovery-readback-checks/pilot.py'
    spec = importlib.util.spec_from_file_location('_padml_finite_pilot_test', script)
    pilot = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = pilot
    spec.loader.exec_module(pilot)
    _, candidate, counts = fixture(tmp_path, monkeypatch)
    root = Path(candidate['root'])
    results = root / 'final-result'
    original = {p: pin(p) for p in root.rglob('*') if p.is_file()}
    donor_base = tmp_path / 'UNFITTED_OLD_RAW'
    def previous(checkpoints, binding, source, task, prediction):
        return (None, {'raw_path': str(donor_base / f"M{task['imputation']:02d}" / 'kernelshap-return.rds')}
                if task['imputation'] in (1, 2) else None)
    def old_diagnostic(path, task, prediction, model_sha, **kwargs):
        assert kwargs == {'expected_budget': 500, 'require_converged': False}
        count = len(prediction['patient_ids'])
        maximum = .009 if task['imputation'] == 2 else .007
        return {'converged': [i != 1 for i in range(count)],
            'maximum_se': [[.001, .001, .001, maximum if i == 1 else .001] for i in range(count)],
            'shap_range': [[1., 1., 1., 1.] for _ in range(count)],
            'criterion': [[True, True, True, i != 1] for i in range(count)]}
    produced = []
    def native_leaf(source, task, model, baseline, prediction, *, work_root, recovery_source, pilot_patient_index):
        assert task['imputation'] == 2 and pilot_patient_index == 2
        assert model == b'UNFITTED_MODEL' and baseline == b'UNFITTED_BASELINE'
        assert recovery_source['raw_path'] == str(donor_base / 'M02/kernelshap-return.rds')
        diagnostic = {'status': 'CONVERGED', 'n_iter': [601], 'criterion': [[True] * 4],
            'maximum_se': [[.001] * 4], 'shap_range': [[1.] * 4]}
        (work_root / 'pilot-diagnostic.json').write_bytes(encode(diagnostic))
        (work_root / 'patients').mkdir()
        (work_root / 'patients/P00002.rds').write_bytes(b'UNFITTED_PATIENT_RETURN')
        produced.append(str(work_root))
        return diagnostic
    monkeypatch.setattr(f5, '_f45_previous_shap', previous)
    monkeypatch.setattr(f5, '_read_final_shap_diagnostic', old_diagnostic)
    monkeypatch.setattr(f5, '_produce_final_shap_component', native_leaf)
    result = pilot.pilot_job({'root': str(root), 'policy': _policy(), 'run_identity': 'e'*64, 'source_identity': 'f'*64})
    selection_path = results / 'shap-components/pilot-selection.json'
    selection = f5.strict_json_bytes(selection_path.read_bytes())
    assert encode(selection) == selection_path.read_bytes()
    assert selection['original_numbers_sha256'] == {str(i): n.sha256_file(results / f'F5_FINAL_FULL_DATA_M{i:02d}.numbers.json')
        for i in range(1, 21)}
    assert selection['imputation'] == selection['patient_index'] == 2
    assert selection['missing_old_raw_imputations'] == list(range(3, 21))
    assert produced == [selection['work_root']]
    assert f5.strict_json_bytes(encode(result)) == result and result['status'] == 'CONVERGED'
    assert result['whole_unit_completion'] is False and result['model_fits'] == 0
    assert all(pin(p) == value for p, value in original.items())
    assert counts['fit'] == counts['audit'] == counts['shap'] == 0


_SHAP_OLD_2000='f696acc0b81c3c95586de35f774ece0ac1a0863fbab24574e9c31c4b7f0806a2'

_SHAP_OLD_500='0ac8ff1d23782146798b6349df318f53b25b4fa2e9a553a8b69a116fb13333e7'

_SHAP_KERNEL='padml/kernels/f5_shap.R'

def _partial_shap_fixture(root, monkeypatch, inherit):
    root=root.resolve();source=root/'input.zip';entries=final_entries('COX_PH','FULL0')
    write_deterministic_zip(source,entries)
    task,recipe,training,_,application,_=f4._f4_native_component_inputs(entries)
    model,baseline=b'UNFITTED_MODEL',b'UNFITTED_BASELINE'
    prediction=dict(family=task['family'],patient_ids=[r['Patient_ID'] for r in application],
        survival=[[1.]+[1.-m*.01 for m in range(1,37)] for r in application],
        final_refit_receipt_sha256='d'*64,model_sha256=f5.sha256_bytes(model),baseline_sha256=f5.sha256_bytes(baseline))
    pkg=Path(f5.__file__).parent
    current={'padml/f5.py':f5.sha256_file(pkg/'f5.py'),_SHAP_KERNEL:f5.sha256_file(pkg/'kernels/f5_shap.R')}
    versions=[{**current,_SHAP_KERNEL:k} for k in ([_SHAP_OLD_500,_SHAP_OLD_2000] if inherit else [_SHAP_OLD_2000])]
    monkeypatch.setattr(f5,'_f45_score_reuse_authorities',lambda:({},dict(enumerate(versions))))
    # Raw whole-MI diagnostics are a native leaf, covered by the separate R case.
    monkeypatch.setattr(f5,'_read_final_shap_diagnostic',lambda *a,**k: {'UNFITTED':True})
    upstream=None
    for members in versions:
        binding=f5._f45_final_shap_binding(source,'e'*64,task,prediction,members)
        work=root/f"F5_FINAL_AGGREGATE_SHAP_M01_{binding['identity_sha256']}";work.mkdir()
        (work/'binding.json').write_bytes(encode(binding))
        for name,raw in {'model.bin':model,'baseline.bin':baseline,'covariates.csv':entries['fit-covariates.csv'],'response.csv':entries['fit-response.csv']}.items():
            (work/name).write_bytes(raw)
        spec=dict(action='FINAL_SHAP',family=task['family'],imputation=1,model_sha256=prediction['model_sha256'],
            selected_parents=list(task['selected_parents']),seed=780000001,recipe=recipe,task=task,horizons=list(f5.REPORT_HORIZONS),
            output_path=str(work/'shap.json'),python_executable=os.environ.get('PADML_PYTHON',os.environ.get('PYTHON',os.sys.executable)),
            **{k+'_path':str(work/v) for k,v in [('model','model.bin'),('baseline','baseline.bin'),('covariate','covariates.csv'),('response','response.csv')]})
        if members[_SHAP_KERNEL]==_SHAP_OLD_2000:
            spec.update(shap_contract=dict(max_iter=2000,original_stream_max_iter=500,rng_policy='ORIGINAL_500_PATIENT_START',tol=.005),recovery_source=upstream)
        (work/'spec.json').write_bytes(encode(spec))
        common=dict(spec_path=str(work/'spec.json'),spec_sha256=f5.sha256_file(work/'spec.json'),
            binding_path=str(work/'binding.json'),binding_sha256=f5.sha256_file(work/'binding.json'),source_member_sha256=members)
        if members[_SHAP_KERNEL]==_SHAP_OLD_500:
            (work/'kernelshap-return.rds').write_bytes(b'UNFITTED_NATIVE_LEAF')
            upstream=dict(common,raw_path=str(work/'kernelshap-return.rds'),raw_sha256=f5.sha256_file(work/'kernelshap-return.rds'))
        else:
            (work/'patients').mkdir()
            for i in (1,2):(work/'patients'/f'P{i:05d}.rds').write_bytes(f'UNFITTED_PATIENT_{i}'.encode())
            previous=work
    binding=f5._f45_final_shap_binding(source,'e'*64,task,prediction,current)
    return dict(root=root,source=source,task=task,prediction=prediction,binding=binding,old=previous,
        upstream=upstream,model=model,baseline=baseline)

def _partial_shap_qualify(s):return f5._f45_previous_shap(s['root'],s['binding'],s['source'],s['task'],s['prediction'])

@pytest.mark.parametrize('inherit',[False,True])
def test_partial_qualification_exact_inputs_and_upstream(tmp_path,monkeypatch,inherit):
    s=_partial_shap_fixture(tmp_path,monkeypatch,inherit);result,donor=_partial_shap_qualify(s)
    assert result is None and donor['kind']=='PATIENT_CHECKPOINTS' and donor['original_solver'] is True
    assert donor['upstream']==s['upstream'] and len(donor['patients'])==2
    assert all(f5.sha256_file(Path(p['path']))==p['sha256'] for p in donor['patients'])
    if inherit:
        spec=f5.strict_json_bytes((s['old']/'spec.json').read_bytes())
        spec['recovery_source']['raw_sha256']='0'*64
        (s['old']/'spec.json').write_bytes(encode(spec))
        with pytest.raises(ContractError,match='F5_SHAP_PREVIOUS_PRODUCER_DRIFT'):_partial_shap_qualify(s)
    else:
        (s['old']/'model.bin').write_bytes(b'DRIFT')
        with pytest.raises(ContractError,match='F5_SHAP_PREVIOUS_PRODUCER_DRIFT'):_partial_shap_qualify(s)

@pytest.mark.parametrize("interrupt_target",["current","old"])
def test_publication_readback_then_old_partial_retirement_resumes(tmp_path,monkeypatch,interrupt_target):
    s=_partial_shap_fixture(tmp_path,monkeypatch,True);_,donor=_partial_shap_qualify(s)
    value=final_shap_components(dict(patient_ids=s['prediction']['patient_ids'],family='COX_PH',per_imputation_predictions=[s['prediction']]),max_iter=2000)[0]
    value['patient_execution']['recovery_source']=donor
    for i,row in enumerate(value['patient_execution']['rows']):
        row['producer']=dict(max_iter=500 if i==0 else 2000,source_sha256=s['upstream']['raw_sha256'] if i==0 else donor['spec_sha256'])
    calls=[]
    def produce(*a,**kw):
        assert kw['recovery_source']==donor;calls.append(1);return copy.deepcopy(value)
    monkeypatch.setattr(f5,'_produce_final_shap_component',produce)
    native_rmtree=f5.shutil.rmtree
    def interrupted(path,*a,**kw):
        is_old=Path(path).name.startswith(s['old'].name+'.retired-')
        if '.retired-' in Path(path).name and is_old==(interrupt_target=='old'):
            (Path(path)/'binding.json').unlink()
            raise OSError('TEST_INTERRUPTED_DURING_RETIRE')
        return native_rmtree(path,*a,**kw)
    with monkeypatch.context() as crash:
        crash.setattr(f5.shutil,'rmtree',interrupted)
        with pytest.raises(OSError,match='TEST_INTERRUPTED_DURING_RETIRE'):
            f5._load_or_produce_final_shap_checkpoint(s['root'],s['source'],'e'*64,s['task'],s['model'],s['baseline'],s['prediction'])
    assert s['old'].is_dir()==(interrupt_target=='current') and len(calls)==1
    remnants=list(s['root'].glob('*.retired-*'));assert len(remnants)==1 and not (remnants[0]/'binding.json').exists()
    component,record,path=f5._load_or_produce_final_shap_checkpoint(s['root'],s['source'],'e'*64,s['task'],None,None,s['prediction'])
    assert path.is_file() and not s['old'].exists() and len(calls)==1 and not list(s['root'].glob('*.retired-*'))
    assert Path(s['upstream']['raw_path']).is_file() and component['patient_execution']['recovery_source']==donor


# UNFITTED two-generation patient custody. Native solver/RDS parsing remain
# covered by native-shap-recovery.R; these fixtures never call a science engine.
def _partial_shap_saved_files(root):
    return {str(path): (path.read_bytes(), path.stat().st_ino,
        path.stat().st_mtime_ns, path.stat().st_ctime_ns)
        for path in root.rglob('*') if path.is_file()}


def _partial_shap_add_generation(s, monkeypatch, upstream, *, label='B', indices=(2,), authorities=True):
    members = dict(s['binding']['source_member_sha256'])
    members['padml/f5.py'] = f5.sha256_bytes(('UNFITTED_RELEASE_' + label).encode())
    members[_SHAP_KERNEL] = _SHAP_OLD_2000
    binding = f5._f45_final_shap_binding(s['source'], 'e'*64, s['task'], s['prediction'], members)
    root = s['root'] / f"F5_FINAL_AGGREGATE_SHAP_M01_{binding['identity_sha256']}"
    root.mkdir(); (root/'patients').mkdir()
    (root/'binding.json').write_bytes(encode(binding))
    spec = f5.strict_json_bytes((s['old']/'spec.json').read_bytes())
    spec['recovery_source'] = copy.deepcopy(upstream)
    spec['output_path'] = str(root/'shap.json')
    for field, name in [('model', 'model.bin'), ('baseline', 'baseline.bin'),
                        ('covariate', 'covariates.csv'), ('response', 'response.csv')]:
        (root/name).write_bytes((s['old']/name).read_bytes())
        spec[field+'_path'] = str(root/name)
    (root/'spec.json').write_bytes(encode(spec))
    for index in indices:
        (root/'patients'/f'P{index:05d}.rds').write_bytes(f'UNFITTED_{label}_PATIENT_{index}'.encode())
    donor = dict(kind='PATIENT_CHECKPOINTS', spec_path=str(root/'spec.json'),
        spec_sha256=f5.sha256_file(root/'spec.json'), binding_path=str(root/'binding.json'),
        binding_sha256=f5.sha256_file(root/'binding.json'), source_member_sha256=members,
        patients=[dict(patient_index=index, path=str(root/'patients'/f'P{index:05d}.rds'),
            **f5._shap_path_pin(root/'patients'/f'P{index:05d}.rds')) for index in indices],
        upstream=copy.deepcopy(upstream), original_solver=True)
    if authorities:
        versions = dict(f5._f45_score_reuse_authorities()[1]); versions[label] = members
        monkeypatch.setattr(f5, '_f45_score_reuse_authorities', lambda: ({}, versions))
    return root, donor


def _partial_shap_two_generations(root, monkeypatch, *, inherit=False):
    s = _partial_shap_fixture(root, monkeypatch, inherit)
    (s['old']/'patients/P00002.rds').unlink()
    _, ancestor = _partial_shap_qualify(s)
    latest, donor = _partial_shap_add_generation(s, monkeypatch, ancestor)
    s.update(ancestor=ancestor, latest=latest, donor=donor)
    return s


def _partial_shap_chain_component(s):
    value = final_shap_components(dict(patient_ids=s['prediction']['patient_ids'],
        family='COX_PH', per_imputation_predictions=[s['prediction']]), max_iter=2000)[0]
    execution = value['patient_execution']; execution['recovery_source'] = s['donor']
    execution['rows'][0]['producer']['source_sha256'] = s['ancestor']['spec_sha256']
    execution['rows'][1]['producer']['source_sha256'] = s['donor']['spec_sha256']
    return value


@pytest.mark.parametrize('inherit', [False, True])
@pytest.mark.parametrize('reverse_authorities', [False, True])
def test_two_generation_patient_chain_qualifies_without_copying(tmp_path, monkeypatch, inherit, reverse_authorities):
    s = _partial_shap_two_generations(tmp_path, monkeypatch, inherit=inherit)
    if reverse_authorities:
        versions = dict(reversed(list(f5._f45_score_reuse_authorities()[1].items())))
        monkeypatch.setattr(f5, '_f45_score_reuse_authorities', lambda: ({}, versions))
    before = _partial_shap_saved_files(s['root'])
    result, donor = _partial_shap_qualify(s)
    assert result is None and donor == s['donor']
    assert [p['patient_index'] for p in donor['patients']] == [2]
    assert [p['patient_index'] for p in donor['upstream']['patients']] == [1]
    assert donor['upstream']['upstream'] == s['upstream']
    assert _partial_shap_saved_files(s['root']) == before


@pytest.mark.parametrize('fault', ['unrelated_fork', 'conflicting_overlap', 'unadmitted_ancestor', 'ancestor_pin_drift'])
def test_two_generation_patient_chain_rejects_nonchain_or_conflict(tmp_path, monkeypatch, fault):
    s = _partial_shap_fixture(tmp_path, monkeypatch, False)
    (s['old']/'patients/P00002.rds').unlink()
    _, ancestor = _partial_shap_qualify(s)
    upstream = None if fault == 'unrelated_fork' else copy.deepcopy(ancestor)
    if fault == 'ancestor_pin_drift':
        upstream['patients'][0]['sha256'] = '0'*64
    _, donor = _partial_shap_add_generation(s, monkeypatch, upstream,
        indices=(1, 2) if fault == 'conflicting_overlap' else (2,))
    if fault == 'unadmitted_ancestor':
        monkeypatch.setattr(f5, '_f45_score_reuse_authorities',
            lambda: ({}, {'B': donor['source_member_sha256']}))
    before = _partial_shap_saved_files(s['root'])
    with pytest.raises(ContractError, match='F5_SHAP_'):
        _partial_shap_qualify(s)
    assert _partial_shap_saved_files(s['root']) == before


@pytest.mark.parametrize('wrong_patient_source', [False, True])
def test_two_generation_component_uses_each_patient_original_spec(tmp_path, monkeypatch, wrong_patient_source):
    s = _partial_shap_two_generations(tmp_path, monkeypatch)
    value = _partial_shap_chain_component(s)
    if wrong_patient_source:
        # B is an admitted producer, but patient 1 physically belongs to A.
        value['patient_execution']['rows'][0]['producer']['source_sha256'] = s['donor']['spec_sha256']
        with pytest.raises(ContractError, match='F5_SHAP_PATIENT_BINDING_INVALID'):
            f5._validate_final_shap_component(value, task=s['task'], prediction=s['prediction'],
                model_sha256=s['prediction']['model_sha256'])
    else:
        assert f5._validate_final_shap_component(value, task=s['task'], prediction=s['prediction'],
            model_sha256=s['prediction']['model_sha256']) == value


def test_two_generation_publish_failure_keeps_all_original_patients(tmp_path, monkeypatch):
    s = _partial_shap_two_generations(tmp_path, monkeypatch)
    value = _partial_shap_chain_component(s); before = _partial_shap_saved_files(s['root'])
    calls = []
    def produce(*args, **kwargs):
        assert kwargs['recovery_source'] == s['donor']; calls.append(1)
        return copy.deepcopy(value)
    def interrupted(*args, **kwargs):
        raise OSError('TEST_INTERRUPTED_BEFORE_SHAP_PUBLISH')
    monkeypatch.setattr(f5, '_produce_final_shap_component', produce)
    monkeypatch.setattr(f5, '_write_shap_checkpoint', interrupted)
    with pytest.raises(OSError, match='TEST_INTERRUPTED_BEFORE_SHAP_PUBLISH'):
        f5._load_or_produce_final_shap_checkpoint(s['root'], s['source'], 'e'*64,
            s['task'], s['model'], s['baseline'], s['prediction'])
    after = _partial_shap_saved_files(s['root'])
    assert all(after[path] == record for path, record in before.items()) and calls == [1]
    assert s['old'].is_dir() and s['latest'].is_dir()


@pytest.mark.parametrize('interrupt_generation', ['A', 'B'])
def test_two_generation_published_retirement_resumes_without_producing(tmp_path, monkeypatch, interrupt_generation):
    s = _partial_shap_two_generations(tmp_path, monkeypatch, inherit=True)
    value = _partial_shap_chain_component(s); calls = []
    def produce(*args, **kwargs):
        assert kwargs['recovery_source'] == s['donor']; calls.append(1)
        return copy.deepcopy(value)
    monkeypatch.setattr(f5, '_produce_final_shap_component', produce)
    original_rmtree = f5.shutil.rmtree
    victim = s['old'] if interrupt_generation == 'A' else s['latest']
    def interrupted(path, *args, **kwargs):
        if Path(path).name.startswith(victim.name+'.retired-'):
            (Path(path)/'binding.json').unlink()
            raise OSError('TEST_INTERRUPTED_ANCESTOR_RETIREMENT')
        return original_rmtree(path, *args, **kwargs)
    with monkeypatch.context() as crash:
        crash.setattr(f5.shutil, 'rmtree', interrupted)
        with pytest.raises(OSError, match='TEST_INTERRUPTED_ANCESTOR_RETIREMENT'):
            f5._load_or_produce_final_shap_checkpoint(s['root'], s['source'], 'e'*64,
                s['task'], s['model'], s['baseline'], s['prediction'])
    assert calls == [1]
    component, record, path = f5._load_or_produce_final_shap_checkpoint(s['root'], s['source'],
        'e'*64, s['task'], None, None, s['prediction'])
    assert path.is_file() and component['patient_execution']['recovery_source'] == s['donor']
    assert calls == [1] and not s['old'].exists() and not s['latest'].exists()
    assert not list(s['root'].glob('*.retired-*'))
    # Preserve the existing raw500 retention contract; this patch only retires patient roots.
    assert Path(s['upstream']['raw_path']).is_file()


def test_two_generation_historical_solver_flag_is_bound_to_its_original_consumer(tmp_path, monkeypatch):
    s = _partial_shap_fixture(tmp_path, monkeypatch, False)
    (s['old']/'patients/P00002.rds').unlink()
    _, ancestor_now = _partial_shap_qualify(s)
    ancestor_at_b = copy.deepcopy(ancestor_now)
    # A and B used the same old R kernel, so this is the historical value
    # written into B.spec; C's different R kernel must not rewrite B's bytes.
    ancestor_at_b['original_solver'] = False
    latest, donor = _partial_shap_add_generation(s, monkeypatch, ancestor_at_b)
    before = _partial_shap_saved_files(s['root'])
    result, admitted = _partial_shap_qualify(s)
    assert result is None and admitted['binding_sha256'] == donor['binding_sha256']
    assert admitted['upstream']['spec_sha256'] == ancestor_now['spec_sha256']
    assert f5.strict_json_bytes((latest/'spec.json').read_bytes())['recovery_source'] == ancestor_at_b
    assert _partial_shap_saved_files(s['root']) == before


@pytest.mark.parametrize('inherit', [False, True])
@pytest.mark.parametrize('kernel,expected_original', [
    ('5164d47ba5a663734086ab034e51f41a5c3f3939a8467e01875d601a9f1e64dc', False),
    ('f696acc0b81c3c95586de35f774ece0ac1a0863fbab24574e9c31c4b7f0806a2', True),
])
def test_partial_first_patient_solver_uses_reviewed_numerical_kernel(
        tmp_path, monkeypatch, inherit, kernel, expected_original):
    monkeypatch.setitem(_partial_shap_fixture.__globals__, '_SHAP_OLD_2000', kernel)
    state = _partial_shap_fixture(tmp_path, monkeypatch, inherit)
    before = _partial_shap_saved_files(state['root'])
    result, donor = _partial_shap_qualify(state)
    assert result is None and donor['original_solver'] is expected_original
    assert donor['upstream'] == state['upstream']
    assert _partial_shap_saved_files(state['root']) == before
