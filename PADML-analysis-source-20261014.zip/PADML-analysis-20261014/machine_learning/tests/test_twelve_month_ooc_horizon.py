"""Synthetic horizon propagation only; no model engine or native replay."""
from copy import deepcopy

import pytest

from padml import f4, nested_loco as nested
from padml.bundle import ContractError
from test_nested_loco import _six_outer_fixture, _response
from test_twelve_month_development_lock import _science


def _predictions12():
    predictions, registry = _six_outer_fixture()
    science = _science()
    return [nested._sealed({**{k: v for k, v in row.items() if k != "identity_sha256"},
        "selection_horizon_months": 12, "science_decision_sha256": science["identity_sha256"]})
        for row in predictions], registry, science


@pytest.mark.parametrize("damage", [None, "mixed_horizon", "mixed_authority", "missing_authority"])
def test_selected_ooc_preserves_own_horizon_and_authority(monkeypatch, damage):
    predictions, registry, science = _predictions12()
    calls = []
    monkeypatch.setattr(f4, "evaluate_predictions", lambda *args, **kwargs: calls.append(kwargs) or {})
    if damage in {"mixed_horizon", "mixed_authority"}:
        body = deepcopy(predictions[0])
        body.pop("identity_sha256")
        if damage == "mixed_horizon":
            body.pop("selection_horizon_months")
            body.pop("science_decision_sha256")
        else:
            body["science_decision_sha256"] = "f" * 64
        predictions[0] = nested._sealed(body)
        with pytest.raises(ContractError, match="SELECTION_HORIZON_MISMATCH"):
            nested.assemble_selected_ooc(predictions, population_registry=registry)
        assert calls == []
        return
    ooc = nested.assemble_selected_ooc(predictions, population_registry=registry)
    kwargs = {"population_registry": registry,
              "science_decision": None if damage == "missing_authority" else science}
    if damage == "missing_authority":
        with pytest.raises(ContractError):
            nested.evaluate_selected_ooc(ooc, _response(ooc["patient_ids"]), **kwargs)
        assert calls == []
        return
    result = nested.evaluate_selected_ooc(ooc, _response(ooc["patient_ids"]), **kwargs)
    assert result["selection_horizon_months"] == calls[0]["selection_horizon_months"] == 12
    assert calls[0]["science_decision"] == science


def test_dca_uses_explicit_horizon_without_changing_default():
    ids = [f"p{i}" for i in range(100)]
    from test_f4 import response
    outcomes = response(ids, [18.] * 50 + [50.] * 50, [1] * 100)
    context = f4.censoring_context(ids, ["36"] * 100, outcomes)
    survival = [[1.] + [.99] * 12 + [.6 if i < 50 else .98] * 24 for i in range(100)]
    original = f4.decision_curve(ids, survival, context)
    earlier = f4.decision_curve(ids, survival, context, horizon=12)
    assert original == f4.decision_curve(ids, survival, context, horizon=24)
    assert original["prevalence"] == .5
    assert earlier["prevalence"] == 0
    assert earlier["horizon"] == 12
    assert earlier["integrated_raw_nb"] == 0


def test_native_horizon_extension_keeps_exact_retained_24m_arithmetic():
    """Compare code-only retained/current kernels on synthetic tied outcomes."""
    import json
    import os
    from pathlib import Path
    import subprocess
    import zipfile
    from padml.bundle import canonical_json_bytes, sha256_bytes
    from test_f4 import response

    archive = os.environ.get("PADML_RETAINED_METRICS_SOURCE_BUNDLE")
    if archive is None:
        pytest.skip("Exact retained code-only metrics source required")
    with zipfile.ZipFile(archive) as source:
        old = source.read("padml/kernels/f4_metrics.R")
    current = (Path(f4.__file__).parent / "kernels/f4_metrics.R").read_bytes()
    assert sha256_bytes(old) == "3dee99810d5d5c9e601983b267af90893fc78f119527042860364cdc9e5ae191"
    assert sha256_bytes(current) == "919caf647d6dd1d02a310c541ef035781d97596101d6d9e650c53384d4388a12"
    assert f4._metric_kernel_compatible(old, current)
    assert not f4._metric_kernel_compatible(old, current, horizon=12)
    assert not f4._metric_kernel_compatible(old + b"\n# unknown", current)
    assert not f4._metric_kernel_compatible(old, current + b"\n# unreviewed")
    ids = [f"synthetic-{i}" for i in range(80)]
    context = f4.censoring_context(ids, ["36"] * 80,
        response(ids, [6.] * 40 + [24.] * 20 + [40.] * 20, [1] * 20 + [0] * 20 + [1] * 20 + [0] * 20))
    payload = {"old": old.decode(), "current": current.decode(),
        "survival": [[value] * 4 for value in [.2] * 20 + [.1] * 20 + [.6] * 40],
        "times": context["times"], "events": context["events"], "centers": context["centers"],
        "censoring_steps": context["censoring_steps"],
        "ipcw": [context["rows"][h] for h in f4.REPORT_HORIZONS]}
    process = subprocess.run(["Rscript", "--vanilla", "-e", r'''
      library(jsonlite)
      x <- fromJSON(file("stdin"), simplifyVector=FALSE)
      old <- new.env(); current <- new.env()
      source(textConnection(x$old), local=old)
      source(textConnection(x$current), local=current)
      args <- list(do.call(rbind,lapply(x$survival,unlist,use.names=FALSE)),
        unlist(x$times),unlist(x$events),x$ipcw,x$centers,x$censoring_steps)
      a <- do.call(old$discriminate,args)
      b <- do.call(current$discriminate,args)
      explicit <- do.call(current$discriminate,c(args,list(horizon=24L)))
      stopifnot(identical(a,b),identical(a,explicit))
      twelve <- do.call(current$discriminate,c(args,list(horizon=12L)))
      cat(toJSON(twelve,auto_unbox=TRUE,null="null",digits=NA))
    '''], input=canonical_json_bytes(payload), capture_output=True, check=True)
    result = json.loads(process.stdout)
    assert "uno_c_24" not in result
    assert result["uno_c_12"]["value"] == pytest.approx(1.)
    assert result["risk_score_common"] == pytest.approx([.8] * 20 + [.9] * 20 + [.4] * 40)
