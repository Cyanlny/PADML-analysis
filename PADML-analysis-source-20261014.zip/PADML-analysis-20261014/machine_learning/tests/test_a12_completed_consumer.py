"""UNFITTED completed-consumer diagnostics; no model or patient computation."""
import copy
from pathlib import Path

import pytest

from padml import f4, f5, f5_sensitivity as a, runtime
from padml.nested_loco import AAR_ESTIMANDS
from padml.bundle import ContractError, canonical_json_bytes as encode, sha256_bytes, sha256_file, write_deterministic_zip
from test_aar_final_shards import _unfitted_a12_input_release


@pytest.fixture
def completed_reader(tmp_path, monkeypatch):
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda root: {
        "effective_cpus": 32, "available_memory_bytes": 10**12,
        "scratch_available_bytes": 10**12, "scratch_root": str(root)})
    monkeypatch.setattr(runtime, "_visible_open_file_keys", lambda keys: (set(), 1))
    policy = dict(configured_worker_ceiling=runtime.CPU_MINUS_8, memory_bytes_per_worker=2*1024**3,
        scratch_bytes_per_worker=1, memory_reserve_bytes=0, scratch_reserve_bytes=0,
        transfer_archive_worker_ceiling=1000)
    source = dict(family="COX_PH", resource_policy=policy, identity_sha256="d"*64)
    content = b"UNFITTED_RELEASE_TRANSPORT_ONLY"
    search_members = {f"search/{branch}/numbers.json": content for branch in AAR_ESTIMANDS}
    producer_raw = encode({"resource_reservation": {"coordinator_memory_estimate_bytes": 1024}})
    value = dict(kind="PADML_F5_A12_OUTER_NATIVE_V2", source=source, family="COX_PH",
        outer_fold=1, predictions={"UNFITTED": True}, native_members={},
        members={"UNFITTED.txt": dict(sha256=sha256_bytes(content), size_bytes=len(content)),
                 **{name: dict(sha256=sha256_bytes(raw), size_bytes=len(raw)) for name, raw in search_members.items()},
                 "execution.json": dict(sha256=sha256_bytes(producer_raw), size_bytes=len(producer_raw))})
    value["identity_sha256"] = sha256_bytes(encode(value))
    archive, inputs = tmp_path/"result.zip", tmp_path/"input.zip"
    write_deterministic_zip(archive, {"a12-outer.json": encode(value), "UNFITTED.txt": content,
                                    "execution.json": producer_raw, **search_members})
    write_deterministic_zip(inputs, {"a12-inputs.json": encode(source)})
    root = tmp_path/"padml-a12-outer-replay-original"
    executor = sha256_bytes(encode(f4._f45_source_member_sha256()))
    binding = dict(executor_source_identity=executor, operation="OUTER_REPLAY", outer_fold=1,
        family="COX_PH", task_names=list(a._a12_final_task_coordinates(1)), work_root=str(root),
        input_archive=dict(sha256=sha256_file(archive), size_bytes=archive.stat().st_size),
        projected_input=dict(sha256=sha256_file(inputs), size_bytes=inputs.stat().st_size),
        projected_input_identity_sha256=source["identity_sha256"])
    raw, result_pin, owners = _unfitted_a12_input_release(root, binding, value, policy)
    import json
    leaf = json.loads(raw)
    index = root/"archive/a12-outer.json"
    index.write_bytes(encode(value))
    owners["archive"]["files"][str(index)] = index.stat().st_size
    (root/"archive/execution.json").write_bytes(producer_raw)
    owners["archive"]["files"][str(root/"archive/execution.json")] = len(producer_raw)
    for name, raw in search_members.items():
        member = root / "archive" / name
        member.parent.mkdir(parents=True, exist_ok=True)
        member.write_bytes(raw)
        owners["archive"]["files"][str(member)] = len(raw)
        # The real replay writes these diagnostics after each native search,
        # outside the archive members and before the final consumer marker.
        runtime.release_completed_files([member], owner="AAR_SEARCH:" + member.parent.name,
            report_root=member.parent, alias_roots=[root/"archive"],
            released_references=["completed_branch_search"])
    before = runtime.observe_step_memory()
    leaf["last_consumer_finished_ns"] = before["started_ns"]
    for name, row in sorted(leaf["input_lifecycle"].items()):
        row["resource_release"] = runtime.release_step_resources(
            [Path(p) for p in owners[name]["files"]], before=before,
            owner=row["resource_release"]["owner"],
            released_references=row["resource_release"]["released_references"])
        before = runtime.observe_step_memory()
    observation = runtime.observe_execution_resources(root)
    effective = {**policy, "memory_reserve_bytes": 1024}
    admission = runtime.resource_admission(effective, observation, legal_tasks=60)
    report = dict(input_execution=leaf, effective_policy=effective, replay_retention_reserved_bytes=0,
        resource_observation=observation, resource_admission=admission, numerical_read_pool=dict(
            status="COMPLETED", engine_threads=1, configured_worker_ceiling=24,
            admitted_worker_ceiling=24, completed_task_count=60, runnable_task_count=60,
            actual_worker_process_peak=5))
    report_path = root/"execution.json"
    report_path.write_bytes(encode(report))
    monkeypatch.setattr(f5, "_f45_score_reuse_authorities", lambda: ({"UNFITTED_RUN": executor}, {}))
    return archive, inputs, root, value, report, binding, result_pin, owners


@pytest.mark.parametrize("damage", [None, "previous_executor", "missing_marker", "pool", "source", "input", "result",
                                    "file_drift", "missing_owner", "extra_file", "report_bytes", "symlink", "reserve",
                                    "diagnostic_owner", "diagnostic_pid", "diagnostic_time",
                                    "diagnostic_inventory", "diagnostic_identity", "diagnostic_duplicate"])
def test_original_completed_tail_is_reused_without_any_numerical_or_release_call(completed_reader, monkeypatch, damage):
    archive, inputs, root, value, report, binding, result_pin, owners = completed_reader
    def forbidden(*args, **kwargs):
        pytest.fail("NO_REPEAT_CONSUME_MODEL_POOL_RELEASE_OR_REMOVAL")
    for name in ("materialize_a12_outer_inputs", "_a12_projected_development_inputs", "_bounded_ordered_spawn",
                 "_a12_outer_predictions", "_replay_ablation_component"):
        monkeypatch.setattr(a, name, forbidden)
    monkeypatch.setattr(runtime, "release_step_resources", forbidden)
    monkeypatch.setattr(a.shutil, "rmtree", forbidden)
    leaf = report["input_execution"]
    if damage == "previous_executor":
        previous = "a"*64
        assert previous != leaf["executor_source_identity"]
        leaf["executor_source_identity"] = previous
        monkeypatch.setattr(f5, "_f45_score_reuse_authorities", lambda: ({"UNFITTED_PREVIOUS_RUN": previous}, {}))
    elif damage == "missing_marker":
        del leaf["last_consumer_finished_ns"]
    elif damage == "pool":
        report["numerical_read_pool"]["completed_task_count"] = 59
    elif damage == "source":
        leaf["executor_source_identity"] = "e"*64
    elif damage in {"input", "result"}:
        leaf["projected_input" if damage == "input" else "input_archive"]["sha256"] = "e"*64
    elif damage == "file_drift":
        (root/"inputs/UNFITTED.txt").write_bytes(b"CHANGED")
    elif damage == "missing_owner":
        del leaf["input_lifecycle"]["materialized_inputs"]
    elif damage == "extra_file":
        (root/"UNACCOUNTED").write_bytes(b"EXTRA")
    elif damage == "reserve":
        report["effective_policy"]["memory_reserve_bytes"] += 1
    elif isinstance(damage, str) and damage.startswith("diagnostic_"):
        import json
        path = next((root / "archive/search").glob("*/resource-release/*.json"))
        diagnostic = json.loads(path.read_bytes())
        if damage == "diagnostic_owner":
            diagnostic["owner"] = "OTHER"
        elif damage == "diagnostic_pid":
            diagnostic["release"]["before"]["pid"] += 1
            diagnostic["release"]["after"]["pid"] += 1
        elif damage == "diagnostic_time":
            path.rename(path.with_name(path.name.split("-", 1)[0] + "-1.json"))
        elif damage == "diagnostic_inventory":
            diagnostic["release"]["files"][0]["path"] = str(root/"archive/UNFITTED.txt")
        elif damage == "diagnostic_identity":
            diagnostic["release"]["files"][0]["inode"] += 1
        elif damage == "diagnostic_duplicate":
            path.with_name("1-1.json").write_bytes(path.read_bytes())
        if damage != "diagnostic_time":
            path.write_bytes(encode(diagnostic))
    raw = encode(report)
    pin = dict(path=str(root/"execution.json"), sha256=sha256_bytes(raw), size_bytes=len(raw))
    if damage == "report_bytes":
        report["replay_retention_reserved_bytes"] = 1
    elif damage == "symlink":
        other = root.with_name("padml-a12-outer-replay-symlink")
        other.symlink_to(root, target_is_directory=True)
        pin["path"] = str(other/"execution.json")
    raw = encode(report)
    (root/"execution.json").write_bytes(raw)
    if damage in {None, "previous_executor"}:
        assert a._load_a12_outer_archive(archive, input_bundle=inputs, completed_replay=pin) == value
    else:
        with pytest.raises(ContractError):
            a._load_a12_outer_archive(archive, input_bundle=inputs, completed_replay=pin)
    assert (root/"execution.json").read_bytes() == raw


@pytest.mark.parametrize("mode", ["completed", "ordinary", "missing_mice", "null_pin"])
def test_worker_preserves_completed_report_and_never_regenerates_completed_mice(tmp_path, monkeypatch, mode):
    from padml import worker
    root = tmp_path / "AAR-H06-O1"
    root.mkdir()
    source, mice, result = [root / n for n in ("input.zip", "mice.zip", "result.zip")]
    for path in (source, result):
        path.write_bytes(b"UNFITTED")
    if mode != "missing_mice":
        mice.write_bytes(b"UNFITTED")
    report = root / "padml-a12-outer-replay-original/execution.json"
    pin = {"path": str(report), "sha256": "a"*64, "size_bytes": 100}
    monkeypatch.delenv("PADML_F45_COMPLETED_AAR_REPLAY", raising=False)
    if mode != "ordinary":
        monkeypatch.setenv("PADML_F45_COMPLETED_AAR_REPLAY", "null" if mode == "null_pin" else encode(pin).decode())
    monkeypatch.setattr(worker, "_f45_compile_archive", lambda path, callback: None)
    def forbidden(*args, **kwargs):
        pytest.fail("COMPLETED_RESULT_MUST_NOT_REGENERATE_INPUTS_OR_MODELS")
    monkeypatch.setattr(a, "execute_a12_outer_inputs", forbidden)
    monkeypatch.setattr(a, "execute_a12_outer_bundle", forbidden)
    calls = []
    monkeypatch.setattr(a, "_load_a12_outer_archive", lambda *args, **kwargs: calls.append((args, kwargs)))
    releases = []
    monkeypatch.setattr(worker, "_f45_release", lambda *args: releases.append(args))
    run = {"run_root": str(tmp_path)}
    unit = {"depends_on": ["PRIMARY-H06-O1"], "outer_fold": 1}
    if mode in {"missing_mice", "null_pin"}:
        with pytest.raises(ContractError, match="COMPLETED_(MICE|PIN)_REQUIRED"):
            worker._f45_aar(run, unit, root, tmp_path)
        assert calls == releases == []
    else:
        artifacts = worker._f45_aar(run, unit, root, tmp_path)
        assert calls == [((result,), {"input_bundle": source, "completed_replay": pin if mode == "completed" else None})]
        assert artifacts == [source, source.with_suffix(".compile.json"), result] + ([report] if mode == "completed" else [])
        assert releases == [(root, "AAR_THREE_BRANCHES_CONSUMED", source, mice, result)]


def test_outer_replay_large_inventory_keeps_bounded_transport_and_original_identity(completed_reader, monkeypatch):
    archive, inputs, root, value, report, binding, result_pin, owners = completed_reader
    leaf = copy.deepcopy(report["input_execution"])
    release = leaf["input_lifecycle"]["archive"]["resource_release"]
    template = release["files"][0]
    # Realistic cardinality of a sealed archive inventory, without creating
    # scientific files or fitting anything. The transport pin binds its bytes.
    release["files"] = [{**template, "path": str(root/"archive"/(f"file-{i:06d}-"+"x"*160)),
        "inode": i+1, "status": "UNKNOWN",
        "error": "RESOURCE_READER_SCAN_FAILED:PermissionError:UNFITTED"} for i in range(65000)]
    release["reader_scan_status"] = "UNKNOWN"
    raw = encode(leaf)
    assert 32*1024**2 < len(raw) < 64*1024**2
    pin = dict(sha256=sha256_bytes(raw), size_bytes=len(raw))
    a._validate_a12_final_input_execution(raw, binding=binding, result_pin=result_pin,
        policy=value["source"]["resource_policy"], expected_pin=pin)
    wrapped = encode({"input_execution": leaf})
    a._validate_a12_final_input_execution(wrapped, binding=binding, result_pin=result_pin,
        policy=value["source"]["resource_policy"],
        expected_pin=dict(sha256=sha256_bytes(wrapped), size_bytes=len(wrapped)), loader_report=True)
    def no_json(*args, **kwargs):
        pytest.fail("OVER_LIMIT_MUST_FAIL_BEFORE_PARSING")
    monkeypatch.setattr(a, "strict_json_bytes", no_json)
    for operation, limit, envelope in [("OUTER_REPLAY",64,False), ("OUTER_REPLAY",64,True),
                                        ("OUTER_EXECUTE",32,False)]:
        with pytest.raises(ContractError, match="FINAL_INPUT_EXECUTION_INVALID"):
            a._validate_a12_final_input_execution(b"x"*(limit*1024**2+1),
                binding={**binding,"operation":operation}, result_pin=result_pin,
                policy=value["source"]["resource_policy"], expected_pin=pin, loader_report=envelope)
