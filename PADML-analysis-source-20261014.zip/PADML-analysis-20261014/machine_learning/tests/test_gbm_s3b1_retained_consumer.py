"""Synthetic retained-source admission boundary; no numerical/native leaf runs.

This is not a source-proof or scientific acceptance test. Transport payloads
are deliberately UNFITTED; the existing transport/native tests own those
contracts. This suite isolates the newly paired df85 scope and historical
resource fields, stopping at the original resource-policy call.
"""
import copy

import pytest

from padml import f4, f5, f2_kernel as kernel, nested_loco as nested, runtime
from padml.bundle import ContractError, canonical_json_bytes, sha256_bytes


SOURCE = "df85f3afcc1d56a1bc5bdf4f4010c00b52587b4b028e7a7992739f4a1437a30f"
INPUT = {"sha256": "be9efb738f1639ce8f5fe422a0f8ec3412426000e75301f2eea8f702f152c225",
         "size_bytes": 1734756}


class OriginalResourceBoundary(Exception):
    pass


def _case(tmp_path, monkeypatch, refit, shard_index=None):
    phase, ids = f5._a12_q_stop_phase("S3B1", refit=refit)
    units = {}
    for name in ids:
        call = [{"UNFITTED": True}, {}, [{"producer_kind": "GBM_STOP_CURVE"}],
                {}, None, "IBS" if refit else "GROUPED_COX_LOCK", None]
        units[name] = (call, (name,))
    # No claim that these sentinels are legal model inputs: no transport or
    # numerical leaf is reached, and the original function is unchanged.
    monkeypatch.setattr(f5, "_a12_q_stop_unit_input", lambda call, **kwargs: call)
    if shard_index is not None:
        ids = ids[shard_index::6]
    current = sha256_bytes(canonical_json_bytes(f4._f45_source_member_sha256()))
    control = {"completed": False, "resource_policy": {"UNFITTED": True},
               "retained_gbm_q_sources": {SOURCE: "/UNFITTED/df85.zip"}}
    spec = {"family": "GBM_COX", "fold": 5, "execution_scope": "F5_A12_SEARCH",
            "native_search_root": str(tmp_path / "q/native"), "native_search_batch": control,
            "a12_source": {"outer_fold": 5, "branch": nested.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT},
            "a12_executor_source_identity": current,
            "retained_a12_primary_context_source_bundle": "/UNFITTED/primary.zip"}
    members = {"input.json": copy.deepcopy(INPUT),
               "prepared-q.json": {"sha256": "a" * 64, "size_bytes": 1},
               "source/primary.zip": {"sha256": "b" * 64, "size_bytes": 1}}
    prepared = {"archive": {"path": "/UNFITTED/input.zip", "sha256": "c" * 64, "size_bytes": 1},
                "input_root": "/UNFITTED/q/prepared-inputs", "metadata_bytes": 1,
                "expanded_bytes": sum(pin["size_bytes"] for pin in members.values()), "members": members,
                "unit_payload_sha256": {name: sha256_bytes(canonical_json_bytes(units[name][0])) for name in ids},
                "after_release": None}
    def unknown(owner):
        return {"status": "UNKNOWN", "owner": owner, "pid": 1, "reason": "UNFITTED historical diagnostic"}
    execution = {"phase": phase, "input": copy.deepcopy(INPUT), "task_ids": ids,
        "source_identity": SOURCE, "operational_identity": runtime.OPERATIONAL_IDENTITY,
        "resource_policy": {}, "effective_policy": {}, "resource_observation": {}, "resource_admission": {},
        "retained_bytes_per_task": 268435456, "pool": {}, "units": [{} for _ in ids],
        "confirmed_first_native_audit_count": 150, "new_model_fit_count": 150,
        "execution_worker_memory_bytes": 2147483648, "prepared_q_input": prepared,
        "resource_release": {"units": {name: unknown("Q_UNIT:" + name) for name in ids},
            "worker_results": {str(index): unknown("POOL_TASK_RESULT:" + str(index)) for index in range(len(ids))},
            "prepared_inputs": unknown("Q_PREPARED_INPUTS:" + "c" * 64)}}
    reached = []
    def original_resource(policy, input_bytes, count, retained, **kwargs):
        reached.append(kwargs)
        assert count == len(ids)
        assert kwargs["execution_worker_memory_bytes"] == 2147483648
        assert kwargs["execution_scratch_reserve_bytes"] is None
        raise OriginalResourceBoundary()
    monkeypatch.setattr(f5, "_q_batch_resource_policy", original_resource)
    monkeypatch.setattr(f5, "_bounded_ordered_spawn", lambda *a, **k: pytest.fail("NO_SCIENCE_CALL"))
    return spec, units, execution, phase, reached


@pytest.mark.parametrize("refit", [False, True])
@pytest.mark.parametrize("damage", [None, "missing-proof", "wrong-source", "wrong-input", "input-size",
    "outer", "branch", "horizon", "family", "stage", "unprepared", "budget-bool", "budget",
    "rewrite-old-scratch", "payload"])
def test_df85_only_original_s3b1_scope_preserves_old_policy(tmp_path, monkeypatch, refit, damage):
    spec, units, execution, phase, reached = _case(tmp_path, monkeypatch, refit)
    input_ref = copy.deepcopy(INPUT)
    if damage == "missing-proof": spec["native_search_batch"]["retained_gbm_q_sources"].clear()
    elif damage == "wrong-source": execution["source_identity"] = "f" * 64
    elif damage == "wrong-input": input_ref["sha256"] = "e" * 64
    elif damage == "input-size": input_ref["size_bytes"] += 1
    elif damage == "outer": spec["fold"] = spec["a12_source"]["outer_fold"] = 4
    elif damage == "branch": spec["a12_source"]["branch"] = nested.A12_DIRECT_AAR
    elif damage == "horizon": spec["selection_horizon_months"] = 12
    elif damage == "family": spec["family"] = "RSF"
    elif damage == "stage": phase = f5._a12_q_stop_phase("S3B2", refit=refit)[0]
    elif damage == "unprepared": del execution["prepared_q_input"]
    elif damage == "budget-bool": execution["execution_worker_memory_bytes"] = True
    elif damage == "budget": execution["execution_worker_memory_bytes"] = 1073741824
    elif damage == "rewrite-old-scratch": execution["execution_scratch_reserve_bytes"] = 0
    elif damage == "payload": execution["prepared_q_input"]["unit_payload_sha256"][next(iter(units))] = "0" * 64
    with pytest.raises(ContractError if damage else OriginalResourceBoundary):
        f5._consume_q_search_batches(spec, kernel._run_r_prediction_pool_task, units,
            [(tmp_path / "UNFITTED-batch", execution)], phase, input_ref)
    assert bool(reached) is (damage is None)


@pytest.mark.parametrize("refit,shard_index,expected_atoms", [(False, 0, 25), (True, 0, 13), (True, 5, 12)])
def test_df85_admission_uses_actual_original_shard_atoms(tmp_path, monkeypatch, refit, shard_index, expected_atoms):
    spec, units, execution, phase, reached = _case(tmp_path, monkeypatch, refit, shard_index)
    assert len(execution["task_ids"]) == expected_atoms
    with pytest.raises(OriginalResourceBoundary):
        f5._consume_q_search_batches(spec, kernel._run_r_prediction_pool_task, units,
            [(tmp_path / "UNFITTED-batch", execution)], phase, copy.deepcopy(INPUT))
    assert len(reached) == 1
