"""Original byte-only GET success and bounded failure evidence; no real network."""
import json
import subprocess
from pathlib import Path

import pytest

from padml import oss
from padml.bundle import ContractError, sha256_bytes


@pytest.mark.parametrize("damage", ["curl", "http", "size", "sha256", "missing", "timeout", "publish", "stat"])
def test_get_preserves_partial_and_bounded_redacted_failure(tmp_path, monkeypatch, damage):
    target = tmp_path / "result.zip"
    raw = b"UNFITTED_BYTE_ARTIFACT"
    calls = []
    url = "https://example.invalid/object?OSSAccessKeyId=PRIVATE_KEY&Signature=PRIVATE_SIGNATURE&Expires=12345"
    stderr = (url + '\nSignature=BARE_SIGNATURE\nSignature="QUOTED_SIGNATURE"\n'
              + "OSSAccessKeyId = SPACED_KEY\nSignature = 'SINGLE_QUOTED_SIGNATURE'\n"
              + '"Signature": "JSON_SIGNATURE"\n'
              + '"x-oss-credential": "V4_CREDENTIAL"\nx-oss-signature=V4_SIGNATURE\n'
              + 'x-oss-security-token=V4_TOKEN\n' + "x" * 10000)
    monkeypatch.setattr(oss, "signed_get", lambda key: url)
    def curl(method, actual_url, *, target):
        calls.append((method, target))
        assert actual_url == url
        if damage != "missing":
            target.write_bytes(b"partial" if damage in {"curl", "size", "timeout"} else
                               b"X" * len(raw) if damage == "sha256" else raw)
        if damage == "timeout":
            raise subprocess.TimeoutExpired(["curl", "--config", "-"], 7210, stderr=stderr.encode())
        return subprocess.CompletedProcess(["curl"], 18 if damage == "curl" else 0,
            "PADML_STATUS:503\n" if damage == "http" else "PADML_STATUS:200\n", stderr)
    monkeypatch.setattr(oss, "_curl", curl)
    if damage == "stat":
        original_stat = Path.stat
        def failed_stat(path, *args, **kwargs):
            if path.name.startswith(".result.zip."):
                raise OSError("ORIGINAL_SIZE_IO_FAILURE")
            return original_stat(path, *args, **kwargs)
        monkeypatch.setattr(Path, "stat", failed_stat)
    if damage == "publish":
        def interrupted(*args):
            raise OSError("INJECTED_RENAME_FAILURE")
        monkeypatch.setattr(oss.os, "replace", interrupted)
    with pytest.raises((ContractError, OSError, subprocess.TimeoutExpired)) as failure:
        oss.get(target, "private/test.zip", sha256_bytes(raw), len(raw))
    assert len(calls) == 1 and not target.exists()
    note, = failure.value.__notes__
    record = json.loads(note.removeprefix("OSS_GET_EVIDENCE:"))
    assert len(record["stderr_excerpt"]) <= 4096 and record["stderr_truncated"]
    assert all(secret not in note for secret in ("PRIVATE_KEY", "PRIVATE_SIGNATURE", "BARE_SIGNATURE",
        "QUOTED_SIGNATURE", "SPACED_KEY", "SINGLE_QUOTED_SIGNATURE", "JSON_SIGNATURE",
        "V4_CREDENTIAL", "V4_SIGNATURE", "V4_TOKEN", url))
    partial = calls[0][1]
    if damage == "stat":
        assert str(failure.value) == "ORIGINAL_SIZE_IO_FAILURE"
        assert record["evidence_stat_error"] == "OSError" and record["actual_size_bytes"] is None
        assert partial.read_bytes() == raw
        return
    assert Path(record["partial_path"]) == partial and record["partial_retained"] == partial.is_file()
    assert record["actual_size_bytes"] == (partial.stat().st_size if partial.is_file() else None)
    assert record["phase"] == ("size" if damage in {"size", "missing"} else
                               "sha256" if damage == "sha256" else "publish" if damage == "publish" else "download")
    assert record["curl_exit_code"] == (None if damage == "timeout" else 18 if damage == "curl" else 0)
    if damage == "sha256":
        assert record["observed_sha256"] == sha256_bytes(partial.read_bytes())


def test_get_success_keeps_original_return_and_single_download(tmp_path, monkeypatch):
    target = tmp_path / "result.zip"
    raw = b"UNFITTED_COMPLETE_ARTIFACT"
    calls = []
    monkeypatch.setattr(oss, "signed_get", lambda key: "https://example.invalid/signed")
    def curl(method, url, *, target):
        calls.append(target)
        target.write_bytes(raw)
        return subprocess.CompletedProcess(["curl"], 0, "PADML_STATUS:200\n", "")
    monkeypatch.setattr(oss, "_curl", curl)
    expected = {"object_key": "private/test.zip", "sha256": sha256_bytes(raw), "size_bytes": len(raw)}
    assert oss.get(target, expected["object_key"], expected["sha256"], expected["size_bytes"]) == expected
    assert len(calls) == 1 and target.read_bytes() == raw and not calls[0].exists()
    with pytest.raises(ContractError, match="OSS_GET_TARGET_INVALID"):
        oss.get(target, expected["object_key"], expected["sha256"], expected["size_bytes"])
    assert len(calls) == 1 and target.read_bytes() == raw


def test_multipart_lost_initiation_recovers_one_session(tmp_path,monkeypatch):
    calls=[];pin={'sha256':'a'*64,'size_bytes':100};record=tmp_path/'upload.json'
    def lost(*args,**kwargs):
        calls.append(args)
        raise ContractError('OSS_CONTROL_OUTCOME_UNKNOWN')
    monkeypatch.setattr(oss,'request',lost)
    key='padml-relay/run/generation/objects/a'
    with pytest.raises(ContractError,match='UNKNOWN'):oss.begin_multipart(key,pin,record)
    monkeypatch.setattr(oss,'multipart_uploads',lambda prefix:[{'key':key,'upload_id':'same-attempt'}])
    assert oss.begin_multipart(key,pin,record)=='same-attempt'
    assert oss.begin_multipart(key,pin,record)=='same-attempt'
    assert len(calls)==1
    with pytest.raises(ContractError,match='DRIFT'):oss.begin_multipart(key,{**pin,'size_bytes':101},record)


@pytest.mark.parametrize('method,key,query,headers,signature', [
    ('GET','padml-relay/test/数据 a+.zip',{}, {},
     '7de8e66c29c3326c81fdb3f29947e4365f8ba993758d0a38cafe3301e45dc0f7'),
    ('PUT','padml-relay/test/object',{}, {'content-type':'application/zip',
     'x-oss-server-side-encryption':'AES256','x-oss-object-acl':'private'},
     '81c88dda6e4604ee462260ed78a8eed8e14f851f630474c831e8f2d550856643'),
    ('POST','padml-relay/test/object',{'uploads':''},{'content-type':'application/zip'},
     'b139dd40ce0f3963c0bb4cf0aa7273e03c523403f9e3b90cd9f54d3480f975d9'),
    ('GET','',{'prefix':'padml-relay/test/a b/','marker':'a+/=%','max-keys':'1000'},{},
     'd2acd8077bc4949e964abfcb90ebfd0f6d5a5a4519d190d50222a8c280bdb543'),
    ('POST','padml-relay/test/object',{'uploadId':'one+/='},
     {'content-type':'application/xml','x-oss-forbid-overwrite':'true'},
     'd27354528113933fb5d09dae9aebe8e6075273d62f30f1c88112f024b7055074'),
])
def test_v4_matches_official_sdk_vectors(monkeypatch,method,key,query,headers,signature):
    # Independent golden vectors: official alibabacloud-oss-v2 1.3.2 SignerV4,
    # 2026-10-09T00:00:00Z, 900 seconds. Production needs only the stdlib.
    from datetime import datetime,timezone
    from urllib.parse import urlsplit,parse_qs
    now=datetime(2026,10,9,tzinfo=timezone.utc).timestamp()
    monkeypatch.setattr(oss.time,'time',lambda:now)
    monkeypatch.setattr(oss,'_credentials',lambda:oss.Credentials('test-access-key','test-access-secret'))
    url=oss.signed_url(method,key,query=query,headers=headers)
    actual=parse_qs(urlsplit(url).query,keep_blank_values=True)
    assert actual['x-oss-signature']==[signature]
    assert all(actual[k]==[v] for k,v in query.items())
    assert '+' not in url and ('uploads=' not in url)


@pytest.mark.parametrize('damage', ['none','object','duplicate','v1','region','date',
                                   'scope_date','expiry','expired','future','headers'])
def test_v4_object_scope_and_expiry(monkeypatch,damage):
    from urllib.parse import urlsplit,parse_qsl,urlencode,urlunsplit
    monkeypatch.setattr(oss,'_credentials',lambda:oss.Credentials('test','secret'))
    key='padml-relay/test/object'
    url=oss.signed_get(key);parts=urlsplit(url);query=dict(parse_qsl(parts.query))
    if damage=='object':parts=parts._replace(path='/padml-relay/test/other')
    if damage=='v1':query['OSSAccessKeyId']='old-key'
    if damage=='region':query['x-oss-credential']=query['x-oss-credential'].replace('cn-beijing','cn-hangzhou')
    if damage=='date':query['x-oss-date']='20261350T000000Z'
    if damage=='scope_date':query['x-oss-credential']=query['x-oss-credential'].replace(query['x-oss-date'][:8],'20200101')
    if damage=='expiry':query['x-oss-expires']='86401'
    if damage=='headers':query['x-oss-additional-headers']='range;host'
    encoded=urlencode(query)+('&x-oss-expires=900' if damage=='duplicate' else '')
    url=urlunsplit(parts._replace(query=encoded))
    if damage in {'expired','future'}:
        now=oss.time.time()
        monkeypatch.setattr(oss.time,'time',lambda:now+(901 if damage=='expired' else -901))
    if damage=='none':oss._token_scope(url,key,{})
    else:
        with pytest.raises(ContractError,match='OSS_TOKEN_(SCOPE_INVALID|EXPIRED)'):
            oss._token_scope(url,key,{})


def test_scoped_policy_uses_supported_multipart_condition():
    relay='padml-relay/run/generation/';environment='padml-environments/identity/'
    policy=oss.relay_policy('123',relay,environment)
    actions={action:row for row in policy for action in row['Action']}
    assert actions['oss:ListObjects']['Condition']['StringLike']=={
        'oss:Prefix':[relay+'*',environment+'*']}
    assert actions['oss:ListMultipartUploads']['Condition']=={'Bool':{'acs:SecureTransport':['true']}}
    assert actions['oss:ListMultipartUploads']['Resource']==['acs:oss:*:*:'+oss.BUCKET]
    assert all(row['Principal']==['123'] for row in policy)
    assert all('/'+relay in resource for resource in actions['oss:DeleteObject']['Resource'])
    assert all('oss:DeleteObject' not in row['Action'] for row in policy
               if any('/'+environment in resource for resource in row['Resource']))


def test_native_multipart_resumes_parts_and_rejects_wrong_capability(tmp_path,monkeypatch):
    import copy,hashlib,urllib.parse,xml.etree.ElementTree as ET
    raw=b'x'*(150*1024)+b'y'*(100*1024);source=tmp_path/'source';source.write_bytes(raw)
    pin={'sha256':sha256_bytes(raw),'size_bytes':len(raw)};key='padml-relay/run/gen/objects/file'
    monkeypatch.setattr(oss,'_credentials',lambda:oss.Credentials('local-test','local-test-secret'))
    tokens=oss.multipart_tokens(key,'attempt',len(raw),part_size=128*1024)
    parts={1:'"'+hashlib.md5(raw[:128*1024]).hexdigest()+'"'};uploaded=[];complete=[]
    def api(method,url,**kwargs):
        if method=='HEAD':return ((200,{'content-length':str(len(raw)),
            'x-oss-meta-padml-sha256':pin['sha256'],'x-oss-server-side-encryption':'AES256'},b'')
            if complete else (404,{},b''))
        if method=='GET':
            return 200,{},('<ListPartsResult><Key>'+key+'</Key><UploadId>attempt</UploadId><IsTruncated>false</IsTruncated>'+
                ''.join(f'<Part><PartNumber>{n}</PartNumber><Size>{min(128*1024,len(raw)-(n-1)*128*1024)}</Size><ETag>{etag}</ETag></Part>'
                        for n,etag in parts.items())+'</ListPartsResult>').encode()
        root=ET.fromstring(kwargs['body']);assert len(root.findall('Part'))==2;complete.append(True)
        return 200,{},b''
    class Connection:
        def __init__(self,*args,**kw):self.data=b''
        def putrequest(self,method,path):self.number=int(urllib.parse.parse_qs(urllib.parse.urlsplit(path).query)['partNumber'][0])
        def putheader(self,*args):pass
        def endheaders(self):pass
        def send(self,block):self.data+=block
        def getresponse(self):
            uploaded.append(self.number);parts[self.number]='"'+hashlib.md5(self.data).hexdigest()+'"'
            class Response:
                status=200
                def read(self,*args):return b''
                def getheader(inner,name):return parts[self.number]
            return Response()
        def close(self):pass
    monkeypatch.setattr(oss,'_token_request',api)
    monkeypatch.setattr('http.client.HTTPSConnection',Connection)
    wrong=copy.deepcopy(tokens);wrong['parts'][0]=wrong['parts'][0].replace('/objects/file','/objects/other')
    with pytest.raises(ContractError,match='SCOPE_INVALID'):oss.upload_parts(source,pin,wrong)
    assert not uploaded
    oss.upload_parts(source,pin,tokens);assert uploaded==[2]
    oss.upload_parts(source,pin,tokens);assert uploaded==[2]


def test_resume_range_preserves_partial_and_publishes_once(tmp_path,monkeypatch):
    import io
    raw=b'original-byte-stream';target=tmp_path/'blob';part=tmp_path/'blob.part';part.write_bytes(raw[:7])
    pin={'sha256':sha256_bytes(raw),'size_bytes':len(raw)};calls=[]
    monkeypatch.setattr(oss,'signed_get',lambda *a,**k:'https://example.invalid/object')
    class Response(io.BytesIO):
        status=206
        headers={'Content-Range':f'bytes 7-{len(raw)-1}/{len(raw)}'}
    def opened(req,**kwargs):
        calls.append(req.get_header('Range'));return Response(raw[7:])
    monkeypatch.setattr(oss.urllib.request,'urlopen',opened)
    reserve=[]
    oss.download_resume(target,'key',pin,before_write=reserve.append)
    assert calls==['bytes=7-'] and reserve==[len(raw)-7] and target.read_bytes()==raw and not part.exists()
    oss.download_resume(target,'key',pin);assert len(calls)==1


def test_environment_restore_exact_files_links_and_cold_resume(tmp_path):
    import io,tarfile,os
    from padml import runtime_bundle as runtime,nested_loco as n
    raw=b'pinned-runtime';pin={'sha256':sha256_bytes(raw),'size_bytes':len(raw)}
    snapshot=n._sealed({'entries':{'opt':{'kind':'directory','mode':0o755},
        'opt/file':{'kind':'file','mode':0o755,**pin},
        'opt/hard':{'kind':'hardlink','mode':0o755,'target':'opt/file',**pin},
        'opt/link':{'kind':'symlink','mode':0o777,'target':'file'}}})
    source=tmp_path/'layer.tgz'
    with tarfile.open(source,'w:gz') as z:
        for name in runtime.environment_layers(snapshot)[0]['names']:
            row=snapshot['entries'][name];t=tarfile.TarInfo(name);t.mode=row['mode']
            t.type={'directory':tarfile.DIRTYPE,'file':tarfile.REGTYPE,'hardlink':tarfile.LNKTYPE,'symlink':tarfile.SYMTYPE}[row['kind']]
            if row['kind']=='file':t.size=len(raw)
            if 'target' in row:t.linkname=row['target']
            z.addfile(t,io.BytesIO(raw) if row['kind']=='file' else None)
    p={'snapshot_identity':snapshot['identity_sha256'],'layer':0,'sha256':sha256_bytes(source.read_bytes()),'size_bytes':source.stat().st_size}
    target=tmp_path/'isolated';target.mkdir()
    for _ in range(2):assert runtime.restore_environment_layer(snapshot,0,source,p,target)['status']=='RESTORED'
    assert (target/'opt/link').read_bytes()==raw and os.path.samefile(target/'opt/file',target/'opt/hard')
    (target/'opt/file').write_bytes(b'drift')
    with pytest.raises(ContractError,match='EXISTING_DRIFT'):runtime.restore_environment_layer(snapshot,0,source,p,target)


def test_complete_bad_partial_restarts_without_corrupt_copy(tmp_path,monkeypatch):
    import io
    raw=b'valid-original';target=tmp_path/'object';part=tmp_path/'object.part'
    part.write_bytes(b'x'*len(raw));calls=[]
    monkeypatch.setattr(oss,'signed_get',lambda *a,**k:'https://example.invalid/object')
    class Response(io.BytesIO):status=200
    def request(req,**kw):
        calls.append(req.get_header('Range'));return Response(raw)
    monkeypatch.setattr(oss.urllib.request,'urlopen',request)
    oss.download_resume(target,'key',{'sha256':sha256_bytes(raw),'size_bytes':len(raw)})
    assert calls==[None] and target.read_bytes()==raw and not part.exists()
    assert json.loads((tmp_path/'object.part.failed.json').read_bytes())['reason']=='FAILED_UNPUBLISHED_COMPLETE_PARTIAL'


def test_environment_empty_directory_merged_usr_and_zero_write_resume(tmp_path,monkeypatch):
    import io,tarfile,os
    from padml import runtime_bundle as runtime,nested_loco as n
    raw=b'loader';pin={'sha256':sha256_bytes(raw),'size_bytes':len(raw)}
    snapshot=n._sealed({'entries':{
        'usr':{'kind':'directory','mode':0o755},'usr/lib':{'kind':'directory','mode':0o755},
        'usr/lib/empty':{'kind':'directory','mode':0o700},'usr/lib/loader':{'kind':'file','mode':0o755,**pin},
        'usr/lib64':{'kind':'directory','mode':0o755},
        'usr/lib64/loader':{'kind':'symlink','mode':0o777,'target':'/lib/loader'},
        'lib':{'kind':'symlink','mode':0o777,'target':'usr/lib'},
        'lib64':{'kind':'symlink','mode':0o777,'target':'usr/lib64'}}})
    source=tmp_path/'layer.tgz';target=tmp_path/'root';target.mkdir()
    with tarfile.open(source,'w:gz') as archive:
        for name in runtime.environment_layers(snapshot)[0]['names']:
            row=snapshot['entries'][name];item=tarfile.TarInfo(name);item.mode=row['mode']
            item.type={'file':tarfile.REGTYPE,'directory':tarfile.DIRTYPE,'symlink':tarfile.SYMTYPE}[row['kind']]
            if row['kind']=='file':item.size=len(raw)
            if row['kind']=='symlink':item.linkname=row['target']
            archive.addfile(item,io.BytesIO(raw) if item.isfile() else None)
    pin={'sha256':sha256_bytes(source.read_bytes()),'size_bytes':source.stat().st_size,
        'snapshot_identity':snapshot['identity_sha256'],'layer':0}
    assert runtime._environment_link_destination(snapshot,'usr/lib64/loader','/lib/loader')=='usr/lib/loader'
    sync=[];original=os.fsync
    monkeypatch.setattr(os,'fsync',lambda fd:(sync.append(fd),original(fd))[-1])
    assert runtime.restore_environment_layer(snapshot,0,source,pin,target)['status']=='RESTORED'
    assert (target/'usr/lib/empty').is_dir() and os.readlink(target/'usr/lib64/loader')=='/lib/loader' and sync
    from collections import namedtuple
    usage=namedtuple('usage','total used free')
    monkeypatch.setattr('shutil.disk_usage',lambda p:usage(10*1024**3,6*1024**3,4*1024**3))
    assert runtime.restore_environment_layer(snapshot,0,source,pin,target)['status']=='RESTORED'


def test_system_bootstrap_needs_no_old_run_and_cold_resume_does_not_refit(tmp_path,monkeypatch):
    import io,os,tarfile,types
    from padml import runtime_bundle as runtime,nested_loco as n
    from padml.bundle import canonical_json_bytes
    raw=b'original-library';row={'kind':'file','mode':0o644,'sha256':sha256_bytes(raw),'size_bytes':len(raw)}
    snapshot=n._sealed({'entries':{'library':row}});memory={};calls=[];checked=[]
    prefix='padml-environments/'+'a'*64+'/'
    def obj(name,data):
        value={'object_key':prefix+name,'sha256':sha256_bytes(data),'size_bytes':len(data)}
        memory[value['object_key']]=data;return value
    snap=obj('snapshot.json',canonical_json_bytes(snapshot));stream=io.BytesIO()
    with tarfile.open(fileobj=stream,mode='w:gz') as z:
        item=tarfile.TarInfo('library');item.mode=0o644;item.size=len(raw);z.addfile(item,io.BytesIO(raw))
    layer={**obj('layer.tgz',stream.getvalue()),'layer':0,'snapshot_identity':snapshot['identity_sha256']}
    descriptor=n._sealed({'kind':'PADML_OSS_ENVIRONMENT_V1','environment_identity':'a'*64,
        'snapshot':snap,'layers':[layer]})
    definition=obj('environment.json',canonical_json_bytes(descriptor))
    root=tmp_path/'new-system';work=tmp_path/'installer'
    monkeypatch.setattr('platform.system',lambda:'Linux');monkeypatch.setattr('platform.machine',lambda:'x86_64')
    monkeypatch.setattr(os,'geteuid',lambda:0)
    original_text=Path.read_text;original_stat=Path.stat
    monkeypatch.setattr(Path,'read_text',lambda p,*a,**kw:'VERSION_ID="22.04"\n' if str(p)=='/etc/os-release' else original_text(p,*a,**kw))
    monkeypatch.setattr(Path,'stat',lambda p,*a,**kw:types.SimpleNamespace(st_dev=original_stat(tmp_path).st_dev)
        if str(p)=='/' else original_stat(p,*a,**kw))
    def download(path,key,pin,**kwargs):
        assert kwargs['capability']=='bounded:'+key
        assert sha256_bytes(memory[key])==pin['sha256'];calls.append(key);path.write_bytes(memory[key])
    monkeypatch.setattr(oss,'download_resume',download)
    def verify(root,actual,**kwargs):
        checked.append(True);assert (root/'library').read_bytes()==raw
        return n._sealed({'status':'ISOLATED_NATIVE_PASS','snapshot_identity':actual['identity_sha256']})
    monkeypatch.setattr(runtime,'isolated_environment_check',verify)
    envelope={'descriptor':definition,'capabilities':{k:'bounded:'+k for k in memory}}
    first=runtime.restore_oss_environment(root,work,envelope)
    second=runtime.restore_oss_environment(root,work,envelope)
    assert first==second and len(checked)==1 and len(calls)==3
    assert not list(work.glob('layer-*.tgz'))
    (root/'library').write_bytes(b'drift')
    with pytest.raises(ContractError,match='ACCEPTANCE_DRIFT'):runtime.restore_oss_environment(root,work,envelope)


def test_live_restore_preserves_different_host_support_before_any_write(tmp_path):
    import io,os,tarfile
    from padml import runtime_bundle as runtime,nested_loco as n
    original=b'producer-cache';runtime_bytes=b'pinned-runtime'
    entries={'etc':{'kind':'directory','mode':0o755},
        'etc/ld.so.cache':{'kind':'file','mode':0o644,'sha256':sha256_bytes(original),'size_bytes':len(original)},
        'opt/padml/runtime/file':{'kind':'file','mode':0o755,'sha256':sha256_bytes(runtime_bytes),'size_bytes':len(runtime_bytes)}}
    snapshot=n._sealed({'entries':entries});root=tmp_path/'host';(root/'etc').mkdir(parents=True,mode=0o700)
    cache=root/'etc/ld.so.cache';cache.write_bytes(b'different-compatible-host-cache');os.chmod(cache,0o600)
    before=(cache.read_bytes(),cache.stat().st_mode,(root/'etc').stat().st_mode)
    archive=tmp_path/'layer.tgz'
    with tarfile.open(archive,'w:gz') as z:
        for name in runtime.environment_layers(snapshot)[0]['names']:
            row=entries[name];item=tarfile.TarInfo(name);item.mode=row['mode']
            if row['kind']=='directory':item.type=tarfile.DIRTYPE;z.addfile(item)
            else:
                data=original if name.startswith('etc/') else runtime_bytes
                item.size=len(data);z.addfile(item,io.BytesIO(data))
    pin={'snapshot_identity':snapshot['identity_sha256'],'layer':0,
        'sha256':sha256_bytes(archive.read_bytes()),'size_bytes':archive.stat().st_size}
    runtime.restore_environment_layer(snapshot,0,archive,pin,root,installed_root=True)
    assert before==(cache.read_bytes(),cache.stat().st_mode,(root/'etc').stat().st_mode)
    target=root/'opt/padml/runtime/file';assert target.read_bytes()==runtime_bytes
    target.write_bytes(b'corrupt')
    with pytest.raises(ContractError,match='EXISTING_DRIFT'):
        runtime.restore_environment_layer(snapshot,0,archive,pin,root,installed_root=True)


def test_environment_retired_then_lost_completion_only_republishes(tmp_path,monkeypatch):
    from padml import reports as r,run as run_module,runtime_bundle as runtime,nested_loco as n
    from padml.bundle import canonical_json_bytes
    environment='a'*64;prefix='padml-environments/'+environment+'/'
    project=tmp_path/'external';external=project/'run';external.mkdir(parents=True)
    authority=n._sealed({'status':'RELAY_CLEARED','prefix':'padml-relay/run/g/','generation':'g'})
    (external/'relay-cleared.json').write_bytes(canonical_json_bytes(authority))
    manifest=tmp_path/'run.json';source=tmp_path/'source.zip';source.write_bytes(b'frozen-source')
    run={'run_id':'run','identity':'run-pin','source_bundle_sha256':sha256_bytes(source.read_bytes()),'hosts':['H0','H1']}
    cfg={'project_root':str(project),'volume':'volume','rebuild_record':str(tmp_path/'rebuild.json'),
        'generation':'g','relay_prefix':'padml-relay/run/g/',
        'controller_sources':{'source.zip':{'path':str(source)}}}
    snapshot=n._sealed({'entries':{'opt/padml/file':{'kind':'file','mode':0o644,'sha256':'b'*64,'size_bytes':1}}})
    layer={'layer':0,'snapshot_identity':snapshot['identity_sha256'],'sha256':'c'*64,'size_bytes':1}
    accepted=n._sealed({'status':'ISOLATED_NATIVE_PASS','snapshot_identity':snapshot['identity_sha256']})
    calls=[];retired=[];objects={};failed=[]
    monkeypatch.setattr(run_module,'load_f45_run',lambda p:run)
    monkeypatch.setattr(run_module,'_f45_remote_command',lambda run,host,code,payload:[json.dumps(payload)])
    monkeypatch.setattr(r,'validate_archive_transfer',lambda run:cfg)
    monkeypatch.setattr(r,'_archive_volume',lambda root:'volume')
    def remote(args,**kwargs):
        action=json.loads(args[0])['action'];calls.append(action)
        if action=='snapshot':value={'snapshot':snapshot,'pin':{'sha256':'d'*64,'size_bytes':1}}
        elif action=='layer':value=layer
        elif action=='upload':value={'status':'UPLOADED','pin':layer,'key':prefix+'layers/'+layer['sha256']+'.tgz'}
        elif action=='bootstrap':
            assert not retired,'deleted test root must not be reconstructed';value=accepted
        elif action=='retire_test':
            retired.append(True);value={'status':'ISOLATED_TEST_RETIRED'}
        else:raise AssertionError(action)
        return subprocess.CompletedProcess(args,0,canonical_json_bytes(value),b'')
    monkeypatch.setattr(r.subprocess,'run',remote)
    monkeypatch.setattr(oss,'begin_multipart',lambda *a:'upload-id')
    monkeypatch.setattr(oss,'multipart_tokens',lambda *a:{})
    monkeypatch.setattr(oss,'signed_get',lambda *a,**kw:'object-capability')
    def put(path,key):
        pin={'object_key':key,'sha256':sha256_bytes(path.read_bytes()),'size_bytes':path.stat().st_size}
        objects[key]={**pin,'server_side_encryption':'AES256'};return pin
    monkeypatch.setattr(oss,'put',put);monkeypatch.setattr(oss,'head',lambda key:objects[key])
    publish=r._publish
    def interrupted(path,*args,**kwargs):
        if path.name=='completed.json' and not failed:
            failed.append(True);raise OSError('FINAL_PUBLICATION_INTERRUPTED_AFTER_RETIRE')
        return publish(path,*args,**kwargs)
    monkeypatch.setattr(r,'_publish',interrupted)
    with pytest.raises(OSError,match='AFTER_RETIRE'):
        r.preserve_oss_environment(manifest,code_root='/code',remote_run_path='/run',environment_identity=environment)
    value=r.preserve_oss_environment(manifest,code_root='/code',remote_run_path='/run',environment_identity=environment)
    assert value['status']=='OSS_ENVIRONMENT_RESTORED_AND_TEST_RETIRED' and calls.count('bootstrap')==1
    before=list(calls)
    assert r.preserve_oss_environment(manifest,code_root='/code',remote_run_path='/run',environment_identity=environment)==value
    assert calls==before
