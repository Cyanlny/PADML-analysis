"""Original Q-call ownership and failure boundary; all scientific leaves UNFITTED.

The existing funnel/native tests own scientific arithmetic and first audits.
This fixture deliberately supplies no MICE, selector paths or predictive model.
"""
import copy
import gc
import mmap
from pathlib import Path
import sys
import tempfile
from time import monotonic_ns
import weakref

import pytest

from padml import f4, f5, f5_sensitivity as sensitivity, nested_loco as nested, runtime
from padml.bundle import ContractError, canonical_json_bytes, sha256_bytes, sha256_file, strict_json_bytes


@pytest.fixture
def q_call(tmp_path, monkeypatch):
    branch = nested.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT
    source, projected, target, selector = (tmp_path / name for name in (
        "UNFITTED-gather.zip", "UNFITTED-projected.zip", "q", "selector"))
    source.write_bytes(b"UNFITTED materializer boundary")
    projected.write_bytes(b"UNFITTED projected boundary")
    selector.mkdir()
    partitions = [{"evaluation_response": {"size_bytes": 4}} for _ in range(15)] + [
        {"covariates": {"members": [{"name": f"imp{i:02d}.csv", "size_bytes": 4} for i in range(1, 21)]}}]
    for name, value in (("partitions.json", partitions), ("selector.json", {"UNFITTED": "selector"}),
                        ("development-input.json", {"UNFITTED": "development"})):
        (selector / name).write_bytes(canonical_json_bytes(value))
    policy = {"configured_worker_ceiling": runtime.CPU_MINUS_8, "memory_bytes_per_worker": 1,
        "scratch_bytes_per_worker": 1, "memory_reserve_bytes": 0, "scratch_reserve_bytes": 0,
        "transfer_archive_worker_ceiling": 1}
    input_source = {"identity_sha256": "a" * 64, "outer_fold": 1, "family": "GBM_COX", "resource_policy": policy}
    q_source = {"branch": branch, "family": "GBM_COX", "outer_fold": 1, "source": input_source}
    batch_root = tmp_path / "UNFITTED-returned-batch"
    state = {"references": [], "releases": [], "empty_q_program": False, "native_calls": 0,
             "computed_batch": False, "write_damage": None}
    persistent = {path: sha256_file(path) for path in (source, projected, *selector.iterdir())}
    original_tempdir = tempfile.tempdir

    class Inputs(dict):
        pass

    def materialize(received, lineage, directory, *, input_bundle):
        assert received == source and lineage is None and input_bundle == projected
        directory.mkdir()
        (directory / "UNFITTED-input.bin").write_bytes(b"owned private input")
        prepared = Inputs(source=input_source, family="GBM_COX", outer_fold=1, branch_development={})
        state["references"].append(weakref.ref(prepared))
        return prepared

    def development(prepared, directory, *, replay, branch, selector_root, q_input_lifecycle):
        assert not replay and selector_root == selector and branch == q_source["branch"]
        directory.mkdir()
        for name, prefix, subdirectory, count, filename in (
            ("selector_program", "nested-full-selector-replay-", "validation-responses", 15, "inner-{:02d}.csv"),
            ("selector_inputs", "a12-selector-inputs-", "outer-training", 20, "imp{:02d}.csv")):
            owned = Path(tempfile.mkdtemp(prefix=prefix, dir=selector.parent))
            (owned / subdirectory).mkdir()
            for index in range(1, count + 1):
                (owned / subdirectory / filename.format(index)).write_bytes(b"data")
            q_input_lifecycle[name] = {"temporary_root": str(owned)}
        return prepared

    def configuration(prepared, branch, *, workers):
        return {"spec": {"execution_mode": "PROCESS_POOL", "engine_threads": 1, "threads": 1,
            "pool_workers": 1, "family": "GBM_COX", "a12_source": q_source},
            "registered": {"identity": "b" * 64}}

    def unfitted_boundary(spec, registered, scratch):
        control = spec["native_search_batch"]
        assert control["prepare_only"] is not state["computed_batch"]
        assert "retained_primary_source_identity" not in spec["native_search_batch"]
        frame_owned = Inputs(large=bytearray(65536))
        state["references"].append(weakref.ref(frame_owned))
        if not state["empty_q_program"]:
            (scratch / "UNFITTED-reader.bin").write_bytes(b"completed reader")
        result = {"status": "PREPARED_Q_BATCH", "stage_acceptance": False,
            "native_search_root": str(target), "phase": "UNFITTED_STOP_BOUNDARY",
            "task_ids": ["UNFITTED_WHOLE_UNIT"], "new_model_fits": 0}
        if state["computed_batch"]:
            assert control["batch_root"] == batch_root and control["task_ids"] == result["task_ids"]
            raw = (target / "input.json").read_bytes()
            execution = {"UNFITTED": "No native model or scientific calculation",
                "input": {"sha256": sha256_bytes(raw), "size_bytes": len(raw)},
                "source_identity": sha256_bytes(canonical_json_bytes(f4._f45_source_member_sha256())),
                "phase": result["phase"], "task_ids": result["task_ids"]}
            batch_root.mkdir()
            written = batch_root / "execution.json"
            raw = canonical_json_bytes(execution)
            state["written_bytes"] = raw
            damage = state["write_damage"]
            if damage != "missing":
                if damage == "symlink":
                    original = batch_root / "UNFITTED-original.json"
                    original.write_bytes(raw)
                    written.symlink_to(original)
                else:
                    written.write_bytes(b"x" * (16 * 1024**2 + 1) if damage == "oversized" else
                                        raw + b" " if damage == "different" else raw)
            state["last_write_ns"] = monotonic_ns()
            result.update(status="COMPUTED_Q_BATCH", batch_root=str(batch_root), execution=execution)
        raise f5._QBatchBoundary(result)

    original_release = runtime.release_step_resources
    def release(files, **kwargs):
        assert tempfile.tempdir == original_tempdir
        assert all(selector not in path.parents and target not in path.parents for path in files)
        value = original_release(files, **kwargs)
        assert all(reference() is None for reference in state["references"])
        state["releases"].append(kwargs["owner"])
        return value

    def forbid_native(*args, **kwargs):
        state["native_calls"] += 1
        raise AssertionError("No scientific native process belongs to this ownership test")

    monkeypatch.setattr(sensitivity, "materialize_a12_outer_inputs", materialize)
    monkeypatch.setattr(sensitivity, "_a12_projected_development_inputs", development)
    monkeypatch.setattr(sensitivity, "_a12_complex_configuration", configuration)
    monkeypatch.setattr(sensitivity, "_a12_outer_input_record", lambda *args, **kwargs: {"UNFITTED": True})
    monkeypatch.setattr(sensitivity, "_run_a12_complex_search", unfitted_boundary)
    monkeypatch.setattr(runtime, "release_step_resources", release)
    monkeypatch.setattr(f4.subprocess, "run", forbid_native)
    arguments = {"input_bundle": projected, "search_only": True, "search_branch": branch,
                 "selector_root": selector, "prepare_only": True}

    def prepare_computed():
        # The original compute entry consumes an already prepared Q directory.
        # This literal fixture is not a fitted or accepted scientific result.
        target.mkdir()
        (target / "native").mkdir()
        configured = configuration(None, branch, workers=None)
        raw = canonical_json_bytes({"kind": "PADML_F5_A12_Q_INPUT_V1", "spec": configured["spec"],
            "registered_identity": configured["registered"]["identity"], "inputs": {"UNFITTED": True}})
        (target / "input.json").write_bytes(raw)
        persistent[target / "input.json"] = sha256_bytes(raw)
        state["computed_batch"] = True
        return {**arguments, "prepare_only": False, "batch_root": batch_root,
                "task_ids": ["UNFITTED_WHOLE_UNIT"], "retained_bytes_per_task": 1048576}

    def consume(value, *, expected_result=None):
        raw = (target / "input.json").read_bytes()
        original = {key: item for key, item in value.items() if key != "execution_report"}
        sensitivity._validate_a12_q_input_execution(value, input_source=input_source,
            source_sha256=sha256_file(source), executor_source_identity=sha256_bytes(canonical_json_bytes(
                f4._f45_source_member_sha256())), q_root=target,
            q_input={"sha256": sha256_bytes(raw), "size_bytes": len(raw)}, q_source=q_source,
            expected_search_result_sha256=expected_result or sha256_bytes(canonical_json_bytes(original)),
            selector_root=selector, selector_binding={name: {"sha256": sha256_file(selector / name),
                "size_bytes": (selector / name).stat().st_size} for name in (
                    "partitions.json", "selector.json", "development-input.json")}, selector_partitions=partitions,
            expected_batch_root=batch_root)

    return {**state, "state": state, "source": source, "projected": projected, "target": target,
        "selector": selector, "arguments": arguments, "consume": consume, "persistent": persistent,
        "input_source": input_source, "q_source": q_source, "release": release, "batch_root": batch_root,
        "prepare_computed": prepare_computed}


def test_q_post_batch_write_is_bound_before_original_input_release(q_call, monkeypatch, capsys):
    case = q_call
    case["prepare_computed"]()
    monkeypatch.setattr(sys, "argv", ["padml-f5", "a12-outer", str(case["source"]), str(case["target"]),
        "--input-bundle", str(case["projected"]), "--search-only", "--search-branch", case["q_source"]["branch"],
        "--selector-root", str(case["selector"]), "--batch-root", str(case["batch_root"]),
        "--retained-bytes-per-task", "1048576", "--task-ids", "UNFITTED_WHOLE_UNIT"])
    f5.main()
    output = capsys.readouterr()
    assert not output.err
    value = strict_json_bytes(output.out.encode())
    case["consume"](value)
    report, written = value["execution_report"], case["batch_root"] / "execution.json"
    assert written.read_bytes() == case["state"]["written_bytes"] == canonical_json_bytes(value["execution"])
    assert report["post_batch_write"] == {"path": str(written), "sha256": sha256_file(written),
                                           "size_bytes": written.stat().st_size}
    assert Path(report["report_path"]).read_bytes() == canonical_json_bytes(value)
    assert len(report["input_lifecycle"]) == 4
    assert all(row["resource_release"]["before"]["started_ns"] >= case["state"]["last_write_ns"]
               and not Path(row["temporary_root"]).exists() for row in report["input_lifecycle"].values())
    assert value["new_model_fits"] == case["state"]["native_calls"] == 0
    assert all(path.is_file() and sha256_file(path) == digest for path, digest in case["persistent"].items())
    for damage in ("path", "digest", "float_size", "bool_size", "relocated_together"):
        bad = copy.deepcopy(value)
        pin = bad["execution_report"]["post_batch_write"]
        if damage == "path":
            pin["path"] += ".different"
        elif damage == "digest":
            pin["sha256"] = "0" * 64
        elif damage in {"float_size", "bool_size"}:
            pin["size_bytes"] = float(pin["size_bytes"]) if damage == "float_size" else True
        else:
            bad["batch_root"] += "-other"
            pin["path"] = str(Path(bad["batch_root"]) / "execution.json")
            bad["execution_report"]["result_sha256"] = sha256_bytes(canonical_json_bytes({
                key: row for key, row in bad.items() if key != "execution_report"}))
        with pytest.raises(ContractError):
            case["consume"](bad, expected_result=bad["execution_report"]["result_sha256"])
    legacy = copy.deepcopy(value)
    del legacy["execution_report"]["post_batch_write"]
    case["consume"](legacy)  # Old evidence stays valid, but supplies no write-boundary observation.


@pytest.mark.parametrize("damage", [None, "seed"])
def test_prepared_q_keeps_producer56_with_execution_cpu32_before_first_leaf(q_call, monkeypatch, damage):
    """Input-only replay seam; no fitted object or numerical leaf is supplied."""
    case = q_call
    arguments = case["prepare_computed"]()
    monkeypatch.setattr(runtime, "effective_cpu_count", lambda: 32)
    original_configuration = sensitivity._a12_complex_configuration
    original_boundary = sensitivity._run_a12_complex_search
    seen = []

    def configuration(prepared, branch, *, workers):
        value = original_configuration(prepared, branch, workers=workers)
        slots = runtime.resolve_pool_workers(workers)
        assert slots == 24
        value["spec"].update(threads=slots, pool_workers=slots, seed=301000)
        return value

    def boundary(spec, registered, scratch):
        assert spec["threads"] == spec["pool_workers"] == 56
        assert spec["replay_pool_workers"] == 24 and spec["engine_threads"] == 1
        assert spec["seed"] == 301000
        assert spec["native_search_batch"]["task_ids"] == ["UNFITTED_WHOLE_UNIT"]
        seen.append((spec["threads"], spec["replay_pool_workers"]))
        return original_boundary(spec, registered, scratch)

    monkeypatch.setattr(sensitivity, "_a12_complex_configuration", configuration)
    monkeypatch.setattr(sensitivity, "_run_a12_complex_search", boundary)
    path = case["target"] / "input.json"
    record = strict_json_bytes(path.read_bytes())
    record["spec"].update(threads=56, pool_workers=56, seed=301001 if damage else 301000)
    raw = canonical_json_bytes(record)
    path.write_bytes(raw)
    case["persistent"][path] = sha256_bytes(raw)
    if damage:
        with pytest.raises(ContractError, match="F5_A12_Q_INPUT_REPLAY_MISMATCH"):
            sensitivity.execute_a12_outer_bundle(case["source"], case["target"], **arguments)
        assert not seen and not case["batch_root"].exists()
    else:
        value = sensitivity.execute_a12_outer_bundle(case["source"], case["target"], **arguments)
        case["consume"](value)
        assert seen == [(56, 24)]
        assert value["phase"] == "UNFITTED_STOP_BOUNDARY" and value["task_ids"] == ["UNFITTED_WHOLE_UNIT"]
        assert value["execution"]["input"] == {"sha256": sha256_bytes(raw), "size_bytes": len(raw)}
        assert value["execution_report"]["resource_admission"]["limits"]["configured"] == 24
        assert value["new_model_fits"] == 0
    assert path.read_bytes() == raw and case["state"]["native_calls"] == 0


@pytest.mark.parametrize("damage", ["missing", "different", "oversized", "symlink"])
def test_q_unfinished_batch_write_stops_before_releasing_inputs(q_call, capsys, damage):
    case = q_call
    options = case["prepare_computed"]()
    case["state"]["write_damage"] = damage
    with pytest.raises(ContractError):
        try:
            sensitivity.execute_a12_outer_bundle(case["source"], case["target"], **options)
        except ContractError as exc:
            work = Path(next(note.split(":", 1)[1] for note in exc.__notes__
                             if note.startswith("F5_A12_Q_INPUT_EVIDENCE:")))
            report = strict_json_bytes((work / "q-input-execution.json").read_bytes())
            raise
    assert capsys.readouterr().out == ""
    assert report["result_sha256"] and "post_batch_write" not in report
    assert len(report["input_lifecycle"]) == 4 and not case["state"]["releases"]
    assert all(Path(row["temporary_root"]).is_dir() and "resource_release" not in row
               for row in report["input_lifecycle"].values())
    assert case["state"]["native_calls"] == 0 and case["batch_root"].is_dir()
    assert all(path.is_file() and sha256_file(path) == digest for path, digest in case["persistent"].items())


@pytest.mark.parametrize("empty_q_program", [False, True])
def test_original_q_cli_returns_single_report_after_four_owners_finish(q_call, monkeypatch, capsys, empty_q_program):
    case = q_call
    case["state"]["empty_q_program"] = empty_q_program
    monkeypatch.setattr(sys, "argv", ["padml-f5", "a12-outer", str(case["source"]), str(case["target"]),
        "--input-bundle", str(case["projected"]), "--search-only", "--search-branch", case["q_source"]["branch"],
        "--selector-root", str(case["selector"]), "--prepare-only"])
    f5.main()
    raw = capsys.readouterr().out.encode()
    value = strict_json_bytes(raw)
    case["consume"](value)
    report = value["execution_report"]
    assert Path(report["report_path"]).read_bytes() == canonical_json_bytes(value)
    assert [owner.split(":")[3] for owner in case["state"]["releases"]] == [
        "selector_program", "selector_inputs", "q_program", "materialized_inputs"]
    assert {name: len(row["resource_release"]["files"]) for name, row in report["input_lifecycle"].items()} == {
        "selector_program": 15, "selector_inputs": 20, "q_program": 0 if empty_q_program else 1,
        "materialized_inputs": 1}
    for row in report["input_lifecycle"].values():
        release = row["resource_release"]
        removable = release.get("reader_scan_status") == "OBSERVED" and all(
            member["status"] in {"ADVISED", "UNSUPPORTED"} for member in release.get("files", []))
        assert Path(row["temporary_root"]).exists() is (not removable)
    assert all(path.is_file() and sha256_file(path) == digest for path, digest in case["persistent"].items())
    assert value["new_model_fits"] == case["state"]["native_calls"] == 0

    independent_result = report["result_sha256"]
    assert report["input_lifecycle"]["q_program"]["numerical_phase_releases"] == {}
    observed = copy.deepcopy(value)
    phase = f5._a12_q_stop_phase("S1")[0]
    phases = observed["execution_report"]["input_lifecycle"]["q_program"]["numerical_phase_releases"]
    phases[phase] = {"status": "UNKNOWN", "owner": "Q_NUMERICAL_PHASE:" + phase + ":" + report["q_input"]["sha256"],
                     "pid": report["pid"], "reason": "UNFITTED operational observation"}
    case["consume"](observed)
    phases[phase]["owner"] += "-wrong-input"
    with pytest.raises(ContractError, match="Q_INPUT_EXECUTION_INVALID"):
        case["consume"](observed)
    legacy = copy.deepcopy(value)
    del legacy["execution_report"]["input_lifecycle"]["q_program"]["numerical_phase_releases"]
    case["consume"](legacy)
    for damage in ("phase_resealed", "tasks_resealed", "fits_resealed", "float_input_size", "missing_owner",
                   "foreign_owner", "missing_inner_file", "missing_outer_file", "active_reader", "inconsistent_advice"):
        bad = copy.deepcopy(value)
        execution = bad["execution_report"]
        inputs = execution["input_lifecycle"]
        if damage.endswith("resealed"):
            bad[{"phase_resealed": "phase", "tasks_resealed": "task_ids", "fits_resealed": "new_model_fits"}[damage]] = (
                "DIFFERENT" if damage == "phase_resealed" else [] if damage == "tasks_resealed" else 1)
            execution["result_sha256"] = sha256_bytes(canonical_json_bytes({
                key: item for key, item in bad.items() if key != "execution_report"}))
        elif damage == "float_input_size":
            execution["q_input"]["size_bytes"] = float(execution["q_input"]["size_bytes"])
        elif damage == "missing_owner":
            del inputs["q_program"]
        elif damage == "foreign_owner":
            inputs["q_program"]["temporary_root"] = str(case["target"])
        elif damage in {"missing_inner_file", "missing_outer_file"}:
            inputs["selector_program" if damage == "missing_inner_file" else "selector_inputs"]["resource_release"]["files"].pop()
        elif damage == "active_reader":
            inputs["materialized_inputs"]["resource_release"]["files"][0]["status"] = "SKIPPED_ACTIVE_READER"
        else:
            # UNKNOWN is valid operational evidence; claiming successful
            # advice without a completed reader scan is the causal negative.
            release = inputs["materialized_inputs"]["resource_release"]
            release["reader_scan_status"] = "UNKNOWN"
            release["files"][0].update(status="ADVISED", error=None)
        with pytest.raises(ContractError):
            case["consume"](bad, expected_result=independent_result)


@pytest.mark.parametrize("failure", ["post_admission", "open_reader", "mmap_reader", "delete_second"])
def test_q_failure_preserves_original_result_and_attributable_remaining_inputs(
        q_call, tmp_path, monkeypatch, capsys, failure):
    case, held = q_call, []
    original_observe, original_remove = runtime.observe_execution_resources, sensitivity.shutil.rmtree
    deletes = []

    def observe(directory):
        value = original_observe(directory)
        if failure == "post_admission" and len(case["state"]["releases"]) == 4:
            value["available_memory_bytes"] = 1
        return value

    def release(files, **kwargs):
        if failure in {"open_reader", "mmap_reader"} and not held:
            handle = files[0].open("rb")
            held.append(handle)
            if failure == "mmap_reader":
                held.append(mmap.mmap(handle.fileno(), 0, access=mmap.ACCESS_READ))
                handle.close()
        return case["release"](files, **kwargs)

    def remove(directory, *args, **kwargs):
        deletes.append(Path(directory))
        if failure == "delete_second" and len(deletes) == 2:
            raise OSError("UNFITTED_SECOND_DELETE_FAILED")
        return original_remove(directory, *args, **kwargs)

    monkeypatch.setattr(runtime, "observe_execution_resources", observe)
    monkeypatch.setattr(runtime, "release_step_resources", release)
    monkeypatch.setattr(sensitivity.shutil, "rmtree", remove)
    try:
        with pytest.raises((ContractError, OSError)) as raised:
            sensitivity.execute_a12_outer_bundle(case["source"], case["target"], **case["arguments"])
    finally:
        for handle in reversed(held):
            handle.close()
    assert capsys.readouterr().out == ""
    work = Path(next(note.split(":", 1)[1] for note in raised.value.__notes__
                     if note.startswith("F5_A12_Q_INPUT_EVIDENCE:")))
    report = strict_json_bytes((work / "q-input-execution.json").read_bytes())
    assert (case["target"] / "input.json").is_file()
    assert report["result_sha256"] and case["state"]["native_calls"] == 0
    assert all(path.is_file() and sha256_file(path) == digest for path, digest in case["persistent"].items())
    if failure == "post_admission":
        assert report["after_release"]["resource_observation"]["available_memory_bytes"] == 1
        assert report["after_release"]["resource_admission"] is None and not deletes
    elif failure == "delete_second":
        saved = strict_json_bytes(Path(report["report_path"]).read_bytes())
        case["consume"](saved)
        assert len(deletes) == 2 and not deletes[0].exists() and deletes[1].is_dir()
        # Reader PASS alone is deliberately insufficient: this call raised and
        # has no successful CLI stdout. Original collector must bind both.
    else:
        assert not deletes
    remaining = [Path(row["temporary_root"]) for row in report["input_lifecycle"].values()]
    assert sum(path.is_dir() for path in remaining) == (3 if failure == "delete_second" else 4)
    gc.collect()
    assert all(reference() is None for reference in case["state"]["references"])
