from __future__ import annotations

import copy
import csv
import io
import json
import math
import os
import subprocess
import sys
import zipfile
from collections import Counter
from pathlib import Path

import pytest

import padml.f5 as f5_module


@pytest.fixture(autouse=True)
def synthetic_host_capacity(monkeypatch):
    monkeypatch.setattr("padml.runtime.effective_cpu_count", lambda: 64)

from padml.bundle import ContractError, canonical_json_bytes, read_safe_zip, sha256_bytes, sha256_file, strict_json_bytes, write_deterministic_zip
from padml.f4 import HORIZONS, REPORT_HORIZONS
from padml.f5 import (
    _execute_final_coxtime,
    _execute_paired_diagnostic,
    _execute_final_refit_engine,
    _execute_final_xgboost,
    _training_stop_keys,
    _produce_final_shap_component,
    _load_or_produce_final_shap_checkpoint,
    _compile_non_ph_action,
    _compile_final_action_ledger,
    _load_final_sensitivity_action,
    _load_non_ph_action,
    _validate_final_aggregate_lineage,
    _validate_final_mice_archive,
    _validate_retained_model_objects,
    _replay_final_refit_result,
    _summarize_final_a16_alpha,
    aggregate_final_shap,
    compile_final_a16_task,
    compile_final_refit_bundles,
    compile_final_recipe,
    compile_final_refit_tasks, execute_final_refit_batch, _validate_final_refit_plan,
    compile_final_seta,
    compile_final_full_data_mice_task,
    compile_full_data_mice_plan,
    compile_full_data_search_mice_tasks,
    collect_final_refit_results,
    coefficient_mi_diagnostics,
    diagnose_mi,
    evaluate_non_ph,
    execute,
    execute_final_refit_bundle,
    execute_final_aggregate,
    execute_non_ph_action,
    execute_final_a16_search,
    execute_final_full_data_mice_view,
    execute_full_data_search_mice_view,
    full_data_splits,
    materialize_final_full_data_mice,
    materialize_full_data_search_partition,
    lock_final_a16_parameters,
    pool_predictions,
    seal_final_parameter_lock,
)
from padml.f5_sensitivity import (
    A12_BRANCHES,
    A19_SEED_ROLES,
    C10_BRANCHES,
    _A12_POINT_METRICS,
    _a19_warning_rows,
    compute_a19_multi_seed_stability,
    evaluate_a04_batch_single,
    evaluate_a12_incremental_value,
    evaluate_c10_creatinine_egfr_swap,
    execute_a04_bundle,
    execute_a12_bundle,
    execute_a19_bundle,
    execute_c10_bundle,
)
from padml.f2_kernel import (
    _coxtime_refit_predict,
    _response_rows,
    _seal_prediction_matrix,
    _write_response_subset,
    _xgb_refit_predict,
    predictor_contract,
)
from padml._science_authority import load_science_authority
from padml.f4 import select_a15


def selector_result_fixture(
    fold: int, selected_natural: set[str], negative_direction: set[str] | None = None,
    *, nonzero_count: int = 20,
) -> dict:
    negative_direction = negative_direction or set()
    named = {
        "StableOne": 1,
        "StableSpline": 2,
        "DirectionConflict": 1,
    }
    named.update({f"Unused{index:02d}": 1 for index in range(46)})
    design = {"AST_ALT": 1, **named}
    ratio = 1.0
    outer_paths = []
    natural_frequency = {parent: 0 for parent in named}
    signs = {parent: [] for parent in named}
    for imputation in range(1, 21):
        coefficients = {}
        for parent, width in design.items():
            value = 0.0
            if parent in selected_natural and imputation <= nonzero_count:
                value = -0.25 if parent in negative_direction else 0.25
            path = [[0.0] * width for _ in range(150)]
            path[0] = [value] + [0.0] * (width - 1)
            coefficients[parent] = path
            if parent != "AST_ALT" and value:
                natural_frequency[parent] += 1
                if width == 1:
                    signs[parent].append(1 if value > 0 else -1)
        outer_path = {
            "imputation": imputation,
            "parent_design_columns": design,
            "parent_coefficients": coefficients,
        }
        outer_path["coefficient_path_sha256"] = sha256_bytes(
            canonical_json_bytes({
                "parent_design_columns": design,
                "parent_coefficients": coefficients,
            })
        )
        outer_paths.append(outer_path)
    selected = sorted(
        {"AST_ALT", *(parent for parent, count in natural_frequency.items() if count >= 12)},
        key=lambda value: value.encode(),
    )
    selector = {
        "schema_version": "1.3.0",
        "forced_parent": "AST_ALT",
        "primary_frequency_threshold": 12,
        "diagnostics_selection_effect": "NONE",
        "heldout_outcome_read_count": 0,
        "selected_parents": selected,
        "natural_frequency": natural_frequency,
        "direction_diagnostic_flags": {
            parent: (
                max(values.count(1), values.count(-1)) / len(values) >= 0.75
                if values and design[parent] == 1 else None
            )
            for parent, values in signs.items()
        },
        "selected_parent_design": [
            {
                "parent": parent,
                "design_df": design[parent],
                "representation": "FIXTURE",
                "forced": parent == "AST_ALT",
            }
            for parent in selected
        ],
        "selected_ratio_by_imputation": [ratio] * 20,
        "common_alpha": 0.2,
        "selector_contract_sha256": "1" * 64,
        "transform_registry_sha256": "2" * 64,
        "selected_parent_sha256": sha256_bytes(canonical_json_bytes(selected)),
        "primary_selector_sha256": "3" * 64,
        "sensitivity_evidence": {"identity_sha256": "4" * 64},
    }
    trace = {
        "derivation_records": [{
            "alpha": 0.2,
            "outer_paths": outer_paths,
            "partition_losses": [],
        }]
    }
    result = {
        "status": "PASS",
        "artifact_kind": "F2_MODEL_DEVELOPMENT",
        "family": "ELASTIC_NET_COX",
        "fold": fold,
        "heldout_outcome_read_count_for_selection": 0,
        "selector_evidence": selector,
        "search_trace": trace,
        "selected_spec": {
            "family": "ELASTIC_NET_COX",
            "alpha": 0.2,
            "selected_parents": selected,
        },
    }
    result["selector_evidence_sha256"] = sha256_bytes(canonical_json_bytes({
        "schema_version": selector["schema_version"],
        "primary_selector_sha256": selector["primary_selector_sha256"],
        "sensitivity_identity_sha256": selector["sensitivity_evidence"][
            "identity_sha256"
        ],
    }))
    result["search_trace_sha256"] = sha256_bytes(canonical_json_bytes(trace))
    result["selected_spec_sha256"] = sha256_bytes(
        canonical_json_bytes(result["selected_spec"])
    )
    return result


def resampling_input(singleton: bool = False) -> tuple[list[str], list[int], list[int]]:
    ids = [sha256_bytes(f"raw-patient-{i}".encode()) for i in range(48)]
    centers = [36] * 24 + [38] * 24
    events = ([0] * 12 + [1] * 12) * 2
    if singleton:
        ids.append(sha256_bytes(b"raw-patient-48"))
        centers.append(55)
        events.append(1)
    return ids, centers, events


def original_r_assignments(ids: list[str], centers: list[int], events: list[int]) -> list[list[int]]:
    """Literal historical assign_inner_folds arithmetic, including its trap."""
    source = {"patient_ids": ids, "centers": centers, "events": events}
    completed = subprocess.run(["Rscript", "--vanilla", "-e", r'''
      library(jsonlite)
      x <- fromJSON(file("stdin")); o <- order(x$patient_ids,method="radix")
      strata <- interaction(as.character(x$centers[o]),as.character(x$events[o]),drop=TRUE)
      out <- lapply(1:3,function(r) {
        set.seed(100000+r*100,kind="L'Ecuyer-CMRG",normal.kind="Inversion",sample.kind="Rejection")
        fold <- integer(length(o))
        for (level in levels(strata)) {
          index <- which(strata==level)
          index <- sample(index,length(index),replace=FALSE)
          fold[index] <- rep(seq_len(5L),length.out=length(index))
        }
        as.list(fold)
      })
      cat(toJSON(out,auto_unbox=TRUE))
    '''], input=json.dumps(source), text=True, capture_output=True, check=True)
    return json.loads(completed.stdout)


def test_full_data_partitions_match_original_r_on_regular_strata() -> None:
    ids, centers, events = resampling_input()
    result = full_data_splits(ids, centers, events)
    assert full_data_splits(ids[::-1], centers[::-1], events[::-1]) == result
    assert result["split_count"] == 15
    assert result["virtual_outer"] == 0
    assert result["rng"] == ["L'Ecuyer-CMRG", "Inversion", "Rejection"]
    assert result["outer_split_reused"] is False and result["model_fit_count"] == 0
    expected = original_r_assignments(ids, centers, events)
    for repeat in range(1, 4):
        splits = [row for row in result["splits"] if row["repeat"] == repeat]
        assert [row["inner_fold"] for row in splits] == [1, 2, 3, 4, 5]
        assert {row["seed"] for row in splits} == {100000 + repeat * 100}
        assignment = {}
        for row in splits:
            train, validation = set(row["training_ids"]), set(row["validation_ids"])
            assert train.isdisjoint(validation) and train | validation == set(ids)
            assert not set(assignment).intersection(validation)
            assignment.update({pid: row["inner_fold"] for pid in validation})
        assert [assignment[pid] for pid in sorted(ids)] == expected[repeat - 1]
        for center, event in sorted(set(zip(centers, events, strict=True))):
            counts = Counter(assignment[pid] for pid, c, e in zip(ids, centers, events, strict=True) if (c, e) == (center, event))
            assert max(counts.values()) - min(counts.get(f, 0) for f in range(1, 6)) <= 1


def test_full_data_singleton_cannot_sample_or_overwrite_another_patient() -> None:
    ids, centers, events = resampling_input(singleton=True)
    old = original_r_assignments(ids, centers, events)
    assert any(0 in row for row in old)  # Demonstrates the actual old R trap.
    result = full_data_splits(ids, centers, events)
    for repeat in range(1, 4):
        splits = [row for row in result["splits"] if row["repeat"] == repeat]
        validation = [pid for row in splits for pid in row["validation_ids"]]
        assert sorted(validation) == sorted(ids)
        assert len(validation) == len(set(validation))
        assert ids[-1] in splits[0]["validation_ids"]


def test_full_data_and_stop_partitions_require_both_event_strata() -> None:
    ids, centers, events = resampling_input()
    with pytest.raises(
        ContractError, match="F5_RESAMPLING_EVENT_SUFFICIENCY_INVALID"
    ):
        full_data_splits(ids, centers, [1] * len(events))
    with pytest.raises(
        ContractError, match="F5_STOP_PARTITION_EVENT_SUFFICIENCY_INVALID"
    ):
        _training_stop_keys(
            ids[:10],
            {patient: int(index == 0) for index, patient in enumerate(ids[:10])},
            250_101,
        )


@pytest.mark.parametrize("workers", [24, 56, 120])
def test_full_data_mice_plan_materializes_all_coordinates_without_execution(workers) -> None:
    keys, centers, events = resampling_input()
    source_ids = [f"raw-patient-{index}" for index in range(len(keys))]
    plan = compile_full_data_mice_plan(source_ids, keys, centers, events, family="ELASTIC_NET_COX", workers=workers)
    assert plan["status"] == "COMPILED_NOT_EXECUTED"
    assert plan["split_pair_count"] == 15 and plan["view_task_count"] == 30
    assert plan["execution_profile"] == {
        "pool_workers": workers,
        "engine_threads": 1,
        "task_granularity": "ONE_MICE_VIEW",
        "refill": "DYNAMIC_ON_COMPLETION",
        "nested_pool": False,
    }
    assert plan["mice_started"] is False and plan["model_fit_count"] == 0
    assert plan["outer_split_reused"] is False
    assert len(plan["resampling_center_sha256"]) == 64
    assert len(plan["resampling_event_sha256"]) == 64
    assert plan["search_policy"] == {
        "source": "F4_LOCKED_FAMILY_FULL_DEVELOPMENT_TRAINING_ONLY",
        "funnel": "F2_LOCKED_M1_M5_M20",
        "grid": "F2_LOCKED_UNCHANGED",
        "outer_parameter_reuse": False,
        "requires_final_search": True,
        "final_refit_before_parameter_lock": False,
        "sensitivity_after_final_refit": True,
        "scientific_constraints_relaxed": False,
    }

    expected_source_order = [
        source for _, source in sorted(zip(keys, source_ids, strict=True))
    ]
    coordinate_seed_sets = []
    validation_by_repeat = {repeat: [] for repeat in range(1, 4)}
    source_by_key = dict(zip(plan["patient_keys"], plan["source_ids"], strict=True))
    for pair in plan["split_pairs"]:
        repeat = pair["coordinates"]["repeat"]
        inner_fold = pair["coordinates"]["inner_fold"]
        assert pair["coordinates"]["virtual_outer"] == 0
        assert pair["split_seed"] == 100000 + repeat * 100
        assert pair["mice_seed_base"] == 150000000 + repeat * 10000 + inner_fold * 100
        assert pair["chain_seeds"] == [
            pair["mice_seed_base"] + value for value in range(1, 21)
        ]
        assert pair["stopping"] == {
            "partition_id": f"F5_STOP_R{repeat:02d}_K{inner_fold:02d}",
            "algorithm": "EVENT_STRATIFIED_SHA256_LARGEST_REMAINDER_V1",
            "seed": 250000 + repeat * 100 + inner_fold,
            "fit_fraction": 0.85,
            "stop_fraction": 0.15,
            "consumer_set": ["GBM_COX", "XGBOOST_COX", "COXTIME_SET_A"],
        }
        validation = set(pair["validation_patient_keys"])
        training_keys = [key for key in plan["patient_keys"] if key not in validation]
        training_source_ids = [source_by_key[key] for key in training_keys]
        assert "training_patient_keys" not in pair
        assert pair["analysis"]["response_visibility"].endswith("TRANSIENT_ONLY")
        assert pair["application"]["response_visibility"] == "PHYSICALLY_ABSENT"
        assert pair["analysis"]["analysis_row_count"] == len(training_source_ids)
        assert pair["analysis"]["row_count"] == len(training_source_ids)
        assert pair["application"]["analysis_row_count"] == len(training_source_ids)
        assert pair["application"]["row_count"] == len(expected_source_order)
        for view, rows in (
            (pair["analysis"], training_source_ids),
            (pair["application"], expected_source_order),
        ):
            assert view["analysis_source_ids_sha256"] == sha256_bytes(
                canonical_json_bytes(training_source_ids)
            )
            assert view["row_source_ids_sha256"] == sha256_bytes(
                canonical_json_bytes(rows)
            )
        assert set(training_keys).isdisjoint(pair["validation_patient_keys"])
        assert set(training_keys) | validation == set(plan["patient_keys"])
        validation_by_repeat[repeat].extend(pair["validation_patient_keys"])
        coordinate_seed_sets.append(set(pair["chain_seeds"]))
    assert all(sorted(values) == sorted(keys) for values in validation_by_repeat.values())

    final = plan["final_full_data"]
    assert final["requires_completed_action"] == (
        "SELECT_COMPLETE_JOINT_CONFIGURATION"
    )
    assert final["coordinates"] == {"virtual_outer": 0, "repeat": 0, "inner_fold": 0}
    assert final["chain_seeds"] == list(range(150000001, 150000021))
    assert final["analysis"]["analysis_row_count"] == len(expected_source_order)
    assert final["analysis"]["row_count"] == len(expected_source_order)
    assert final["analysis"]["analysis_source_ids_sha256"] == sha256_bytes(
        canonical_json_bytes(expected_source_order)
    )
    assert final["analysis"]["row_source_ids_sha256"] == sha256_bytes(
        canonical_json_bytes(expected_source_order)
    )
    coordinate_seed_sets.append(set(final["chain_seeds"]))
    assert all(
        left.isdisjoint(right)
        for index, left in enumerate(coordinate_seed_sets)
        for right in coordinate_seed_sets[index + 1 :]
    )
    a16 = plan["a16_fold_source"]
    assert a16["state"] == "SEALED"
    assert a16["fold_source"] == "SEALED_P4_FULL_DATA_REPEAT_01_FIVE_FOLD_ASSIGNMENT"
    assert a16["repeat_id"] == 1 and a16["source_split_seed"] == 100100
    assert a16["selector_seed"] == 200000
    assert a16["selector_invocation_count"] == 1
    assert a16["selector_fold_count"] == 5
    assert len(a16["selector_foldid"]) == len(keys)
    assert set(a16["selector_foldid"]) == {1, 2, 3, 4, 5}
    assert a16["lambda_imputation_ids"] == list(range(1, 21))
    assert a16["lambda_averaging_permitted"] is False
    assert a16["new_split_generation_count"] == 0
    assert a16["new_split_seed_count"] == 0
    assert a16["heldout_or_formal_result_read_count"] == 0


def test_full_data_mice_plan_derives_keys_and_rejects_old_mapping() -> None:
    keys, centers, events = resampling_input()
    source_ids = [f"raw-patient-{index}" for index in range(len(keys))]
    assert compile_full_data_mice_plan(source_ids, None, centers, events, family="ELASTIC_NET_COX", workers=24) == (
        compile_full_data_mice_plan(source_ids, keys, centers, events, family="ELASTIC_NET_COX", workers=24))
    with pytest.raises(ContractError, match="F45_PATIENT_KEY_MAPPING_MISMATCH"):
        compile_full_data_mice_plan(source_ids, source_ids, centers, events, family="ELASTIC_NET_COX", workers=24)
    with pytest.raises(ContractError, match="F45_PATIENT_KEY_MAPPING_MISMATCH"):
        compile_full_data_mice_plan(source_ids, [sha256_bytes(key.encode()) for key in keys],
                                    centers, events, family="ELASTIC_NET_COX", workers=24)


def test_full_data_mice_plan_replay_rejects_resealed_wrong_keys_before_native_work(monkeypatch):
    keys, centers, events = resampling_input()
    ids = [f"raw-patient-{index}" for index in range(len(keys))]
    plan = compile_full_data_mice_plan(ids, keys, centers, events, family="ELASTIC_NET_COX", workers=24)
    plan["patient_keys"][0], plan["patient_keys"][1] = plan["patient_keys"][1], plan["patient_keys"][0]
    plan["patient_key_mapping_sha256"] = sha256_bytes(canonical_json_bytes([
        {"patient_key": key, "source_id": patient}
        for key, patient in zip(plan["patient_keys"], plan["source_ids"], strict=True)]))
    monkeypatch.setattr("padml.f5.subprocess.run", lambda *args, **kwargs: pytest.fail("no native work"))
    with pytest.raises(ContractError, match="F45_PATIENT_KEY_MAPPING_MISMATCH"):
        compile_full_data_search_mice_tasks(plan)


def test_full_data_search_mice_tasks_are_complete_and_identity_bound() -> None:
    keys, centers, events = resampling_input()
    source_ids = [f"raw-patient-{index}" for index in range(len(keys))]
    plan = compile_full_data_mice_plan(source_ids, keys, centers, events, family="ELASTIC_NET_COX", workers=24)
    tasks = compile_full_data_search_mice_tasks(plan)
    assert len(tasks) == len({task["task_sha256"] for task in tasks}) == 30
    assert [task["role"] for task in tasks] == [
        role for _ in range(15) for role in ("ANALYSIS", "APPLICATION")
    ]
    assert max(len(canonical_json_bytes(task)) for task in tasks) < 1024
    assert all("view" not in task for task in tasks)
    assert {
        (task["coordinates"]["repeat"], task["coordinates"]["inner_fold"])
        for task in tasks
    } == {(repeat, fold) for repeat in range(1, 4) for fold in range(1, 6)}
    assert all(task["phase"] == "FINAL_SEARCH" for task in tasks)
    damaged = copy.deepcopy(plan)
    damaged["split_pairs"][0]["application"]["row_count"] -= 1
    with pytest.raises(ContractError, match="F5_MICE_VIEW_INVALID"):
        compile_full_data_search_mice_tasks(damaged)
    damaged = copy.deepcopy(plan)
    damaged["split_pairs"][0]["stopping"]["seed"] += 1
    with pytest.raises(ContractError, match="F5_STOP_PARTITION_PLAN_INVALID"):
        compile_full_data_search_mice_tasks(damaged)
    damaged = copy.deepcopy(plan)
    damaged["a16_fold_source"]["selector_foldid"][0] = (
        damaged["a16_fold_source"]["selector_foldid"][0] % 5 + 1)
    with pytest.raises(ContractError, match="F5_A16_FOLD_SOURCE_INVALID"):
        compile_full_data_search_mice_tasks(damaged)


def test_final_full_data_mice_task_is_post_selection_and_pre_lock() -> None:
    keys, centers, events = resampling_input()
    source_ids = [f"raw-patient-{index}" for index in range(len(keys))]
    plan = compile_full_data_mice_plan(source_ids, keys, centers, events, family="ELASTIC_NET_COX", workers=24)
    task = compile_final_full_data_mice_task(plan)
    assert task["phase"] == "FINAL_MICE"
    assert task["split_id"] == "F5_FINAL_FULL_DATA"
    assert task["coordinates"] == {
        "virtual_outer": 0, "repeat": 0, "inner_fold": 0,
    }
    assert task["requires_completed_action"] == (
        "SELECT_COMPLETE_JOINT_CONFIGURATION"
    )
    assert task["chain_seeds"] == list(range(150000001, 150000021))
    assert task["role"] == "ANALYSIS"
    assert task["source_patient_count"] == len(source_ids)
    damaged = copy.deepcopy(plan)
    damaged["final_full_data"]["requires_completed_action"] = (
        "FINAL_PARAMETER_LOCK"
    )
    with pytest.raises(ContractError, match="F5_FINAL_MICE_PLAN_INVALID"):
        compile_final_full_data_mice_task(damaged)


def private_covariates(source_ids: list[str], centers: list[int]) -> bytes:
    authority = json.loads(
        (Path(__file__).resolve().parents[1] / "padml/science/authority.json").read_text()
    )
    columns = authority["science"]["mice"]["private_handoff"]["columns"]
    stream = io.StringIO(newline="")
    writer = csv.DictWriter(stream, fieldnames=columns, lineterminator="\n")
    writer.writeheader()
    for index, (patient_id, center) in enumerate(zip(source_ids, centers, strict=True)):
        row = {column: str(index + 1) for column in columns}
        row["Patient_ID"] = patient_id
        row["Center"] = str(center)
        writer.writerow(row)
    return stream.getvalue().encode()


def private_response(source_ids: list[str], events: list[int]) -> bytes:
    return (
        "Patient_ID,All_Cause_Death,Death_Followup_months\n"
        + "".join(
            f"{patient_id},{event},{index + 1}\n"
            for index, (patient_id, event) in enumerate(
                zip(source_ids, events, strict=True)
            )
        )
    ).encode()


def valid_unfitted_mice_covariates(source_ids: list[str], centers: list[int]) -> bytes:
    """Deterministic valid synthetic cells; HGB alone needs an UNFITTED donor."""
    authority = Path(__file__).resolve().parents[1] / "padml/science"
    columns = json.loads((authority / "authority.json").read_text())["science"]["mice"]["private_handoff"]["columns"]
    catalog = list(csv.DictReader((authority / "variable.csv").open()))
    levels = {row["variable"]: next(value.strip()[7:] for value in row["levels_or_coding"].split(";")
        if value.strip().startswith("levels=")).split("|")
        for row in catalog if row["type"] in {"binary", "ordered", "unordered"}}
    stream = io.StringIO(newline="")
    writer = csv.DictWriter(stream, fieldnames=columns, lineterminator="\n")
    writer.writeheader()
    for index, (patient, center) in enumerate(zip(source_ids, centers, strict=True)):
        row = {name: levels[name][index % len(levels[name])] if name in levels else str(20 + index % 11)
               for name in columns}
        row.update(Patient_ID=patient, Center=str(center), AST="40", ALT="20", AST_ALT="2",
                   Age=str(40 + index % 40), Height_cm="170", Weight_kg="70", Creatinine="88.4",
                   HGB="" if index % 5 == 0 else str(120 + index))
        writer.writerow(row)
    return stream.getvalue().encode()


def search_analysis_response(plan: dict, task: dict, response: bytes) -> bytes:
    from padml.f5 import _mice_view_rows
    _, analysis_ids, _ = _mice_view_rows(plan, task)
    fields, rows = _response_rows(response)
    return _write_response_subset(fields, rows, analysis_ids, None)["private_bytes"]


def fake_mice_run(
    arguments: list[str], **unused: object
) -> subprocess.CompletedProcess[str]:
    replay = "REPLAY" in arguments
    spec = json.loads(Path(arguments[-2] if replay else arguments[-1]).read_text())
    role = spec["view"]["role"]
    assert ("response_path" in spec) == (role == "ANALYSIS")
    output = Path(spec["output_dir"])
    if not replay:
        native = output.parent / "native"
        native.mkdir()
        for imputation in range(1, 21):
            (native / f"imp{imputation:02d}.rds").write_bytes(b"MOCK_NOT_NATIVE_EXECUTION_PROOF")
        (output.parent / "native-session.txt").write_text("MOCK_NOT_NATIVE_EXECUTION_PROOF")
    (output / "configuration").mkdir(parents=True)
    (output / "imputations").mkdir()
    reader = csv.DictReader(
        io.StringIO(Path(spec["covariates_path"]).read_text())
    )
    rows = list(reader)
    for row in rows:
        row["Age"] = "101" if role == "ANALYSIS" else "202"
    for imputation in range(1, 21):
        stream = io.StringIO(newline="")
        writer = csv.DictWriter(
            stream, fieldnames=reader.fieldnames, lineterminator="\n"
        )
        writer.writeheader()
        writer.writerows(rows)
        (output / "imputations" / f"imp{imputation:02d}.csv").write_text(
            stream.getvalue()
        )
    for component in (
        "ACTUAL_MICE_METHOD", "ACTUAL_PREDICTOR_MATRIX", "ACTUAL_BLOT",
        "ACTUAL_CONTINUATION_CONFIG",
    ):
        (output / "configuration" / f"{component}.json").write_bytes(
            canonical_json_bytes({
                "schema_version": "1.0.0", "component": component,
                "view_id": spec["view"]["view_id"], "payload": {},
            })
        )
    (output / "summary.json").write_bytes(canonical_json_bytes({
        "schema_version": "1.0.0", "kind": "PADML_F1_MICE_VIEW_SUMMARY",
        "status": "PASS", "view_id": spec["view"]["view_id"],
        "role": role, "outer_fold": 0,
        "row_count": len(spec["view"]["row_ids"]),
        "analysis_row_count": len(spec["view"]["analysis_ids"]),
        "row_ids_sha256": spec["view"]["row_ids_sha256"],
        "formal_m": 20, "active_target_count": 1, "final_iteration": 50,
        "application_response_columns": 0,
        "application_predictor_matrix_response_edges": 0,
        "analysis_auxiliary_predictor_edges": 2 if role == "ANALYSIS" else 0,
        "convergence_max_psrf": 1.0,
    }))
    return subprocess.CompletedProcess(arguments, 0, "", "")


def materialize_repeat_one_search_partitions(
    plan: dict,
    covariates: bytes,
    response: bytes,
    target: Path,
) -> list[dict]:
    tasks = {
        (task["split_id"], task["role"]): task
        for task in compile_full_data_search_mice_tasks(plan)
        if task["coordinates"]["repeat"] == 1
    }
    partitions = []
    for fold in range(1, 6):
        split_id = f"F5_R01_K{fold:02d}"
        analysis_payload = target / f"{split_id}-analysis.zip"
        application_payload = target / f"{split_id}-application.zip"
        execute_full_data_search_mice_view(
            plan,
            tasks[(split_id, "ANALYSIS")],
            covariates,
            search_analysis_response(
                plan, tasks[(split_id, "ANALYSIS")], response
            ),
            analysis_payload,
        )
        execute_full_data_search_mice_view(
            plan,
            tasks[(split_id, "APPLICATION")],
            covariates,
            None,
            application_payload,
        )
        partitions.append(materialize_full_data_search_partition(
            plan,
            split_id,
            analysis_payload,
            application_payload,
            response,
            target / split_id,
        ))
    return partitions


def test_a12_total_native_mice_patch_changes_only_two_expressions(tmp_path):
    from padml.runtime import RSCRIPT_EXECUTABLE
    repo = Path(__file__).resolve().parents[1]
    script = r'''
    definition <- function(source, name) {
      matches <- Filter(function(x) is.call(x) &&
        identical(x[[1L]], as.name("<-")) && identical(x[[2L]], as.name(name)),
        as.list(parse(source)))
      stopifnot(length(matches) == 1L)
      matches[[1L]]
    }
    eval(definition("padml/kernels/f1_nested_mice.R", "impute_view"))
    for (name in c("removed", "without_channel")) {
      eval(definition("padml/kernels/f5_a12_mice.R", name))
    }
    expected <- body(impute_view)
    actual <- without_channel(expected)
    stopifnot(identical(removed, c(1L, 1L)))
    targets <- list(
      rule = quote(candidates <- unique(c(candidates, "AST_ALT"))),
      index = quote(output$AST_ALT <- completed$AST / completed$ALT)
    )
    for (variable in names(targets)) {
      loops <- which(vapply(as.list(expected), function(x) is.call(x) &&
        identical(x[[1L]], as.name("for")) &&
        identical(x[[2L]], as.name(variable)), logical(1)))
      stopifnot(length(loops) == 1L)
      loop <- loops[[1L]]
      block <- expected[[loop]][[4L]]
      positions <- which(vapply(as.list(block), identical, logical(1),
                                 targets[[variable]]))
      stopifnot(length(positions) == 1L)
      block[[positions[[1L]]]] <- quote(invisible(NULL))
      expected[[loop]][[4L]] <- block
    }
    stopifnot(identical(actual, expected))
    cat("EXACT_TWO_EXPRESSION_DELTA_PASS\n")
    '''
    result = subprocess.run([RSCRIPT_EXECUTABLE, "--vanilla", "-e", script],
                            cwd=repo, capture_output=True, text=True, timeout=30)
    (tmp_path / "stdout.txt").write_text(result.stdout)
    (tmp_path / "stderr.txt").write_text(result.stderr)
    assert result.returncode == 0, result.stderr


@pytest.mark.parametrize("role", ["ANALYSIS", "APPLICATION"])
def test_full_data_search_mice_view_executes_one_direct_unit(
    role: str, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    keys, centers, events = resampling_input()
    source_ids = [f"raw-patient-{index}" for index in range(len(keys))]
    plan = compile_full_data_mice_plan(source_ids, keys, centers, events, family="ELASTIC_NET_COX", workers=24)
    task = next(
        task for task in compile_full_data_search_mice_tasks(plan)
        if task["role"] == role
    )
    covariates = private_covariates(source_ids, centers)
    response = private_response(source_ids, events)

    monkeypatch.setattr("padml.f5.subprocess.run", fake_mice_run)
    target = tmp_path / f"{role.lower()}.zip"
    result = execute_full_data_search_mice_view(
        plan,
        task,
        covariates,
        search_analysis_response(plan, task, response)
        if role == "ANALYSIS" else None,
        target,
    )
    assert result["status"] == "COMPUTED" and result["stage_acceptance"] is False
    entries = read_safe_zip(target)
    assert len(entries) == (51 if role == "ANALYSIS" else 50)
    manifest = strict_json_bytes(entries["manifest.json"])
    assert manifest["role"] == role and manifest["model_fit_count"] == 0
    with zipfile.ZipFile(target) as archive:
        for info in archive.infolist():
            assert info.compress_type == (zipfile.ZIP_STORED if info.filename.endswith(".rds") else zipfile.ZIP_DEFLATED)
            if info.filename in manifest["members"]:
                assert manifest["members"][info.filename] == {
                    "sha256": sha256_bytes(archive.read(info)), "size_bytes": info.file_size}
            if info.filename.endswith(".rds"):
                assert archive.read(info) == b"MOCK_NOT_NATIVE_EXECUTION_PROOF"
    assert (manifest["source_response_sha256"] is not None) == (role == "ANALYSIS")
    assert ("inputs/response.csv" in entries) == (role == "ANALYSIS")
    if role == "ANALYSIS":
        with pytest.raises(ContractError, match="F5_MICE_PRIVATE_RESPONSE_INVALID"):
            execute_full_data_search_mice_view(
                plan,
                task,
                covariates,
                response,
                tmp_path / "analysis-full-response-forbidden.zip",
            )


def test_full_data_mice_inputs_cannot_drift_from_resampling_strata(
    tmp_path: Path,
) -> None:
    keys, centers, events = resampling_input()
    source_ids = [f"raw-patient-{index}" for index in range(len(keys))]
    plan = compile_full_data_mice_plan(source_ids, keys, centers, events, family="ELASTIC_NET_COX", workers=24)
    task = next(
        task for task in compile_full_data_search_mice_tasks(plan)
        if task["role"] == "ANALYSIS"
    )
    drifted_centers = [38, *centers[1:]]
    with pytest.raises(ContractError, match="F5_RESAMPLING_CENTER_BINDING_INVALID"):
        execute_full_data_search_mice_view(
            plan, task, private_covariates(source_ids, drifted_centers),
            search_analysis_response(
                plan, task, private_response(source_ids, events)
            ), tmp_path / "center-drift.zip",
        )
    drifted_events = [1, *events[1:]]
    with pytest.raises(ContractError, match="F5_RESAMPLING_EVENT_BINDING_INVALID"):
        execute_full_data_search_mice_view(
            plan, task, private_covariates(source_ids, centers),
            search_analysis_response(
                plan, task, private_response(source_ids, drifted_events)
            ), tmp_path / "event-drift.zip",
        )


def test_final_full_data_mice_view_executes_before_parameter_lock(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    keys, centers, events = resampling_input()
    source_ids = [f"raw-patient-{index}" for index in range(len(keys))]
    plan = compile_full_data_mice_plan(source_ids, keys, centers, events, family="ELASTIC_NET_COX", workers=24)
    task = compile_final_full_data_mice_task(plan)
    monkeypatch.setattr("padml.f5.subprocess.run", fake_mice_run)
    target = tmp_path / "final-full-data.zip"
    result = execute_final_full_data_mice_view(
        plan,
        task,
        private_covariates(source_ids, centers),
        private_response(source_ids, events),
        target,
    )
    assert result["status"] == "COMPUTED"
    manifest = strict_json_bytes(read_safe_zip(target)["manifest.json"])
    assert manifest["phase"] == "FINAL_MICE"
    assert manifest["split_id"] == "F5_FINAL_FULL_DATA"
    assert manifest["role"] == "ANALYSIS"
    assert manifest["row_count"] == manifest["analysis_row_count"] == len(keys)
    with zipfile.ZipFile(target) as archive:
        stored = {info.filename for info in archive.infolist() if info.compress_type == zipfile.ZIP_STORED}
        assert stored == {f"native/imp{imputation:02d}.rds" for imputation in range(1, 21)}
        assert all(archive.read(name) == b"MOCK_NOT_NATIVE_EXECUTION_PROOF" for name in stored)


def native_mice_fixture() -> tuple[dict, bytes, bytes]:
    """Outcome-free synthetic covariates, not a replacement for frozen F1 data."""
    import numpy as np
    rng = np.random.default_rng(84631)
    count = 420
    ids = [f"mice-fixture-{index:04d}" for index in range(count)]
    keys = [sha256_bytes(patient.encode()) for patient in ids]
    centers = [([36, 38, 39, 48, 52, 54, 55])[index % 7] for index in range(count)]
    events = [int(index % 3 != 0) for index in range(count)]
    plan = compile_full_data_mice_plan(ids, keys, centers, events, family="ELASTIC_NET_COX", workers=24)
    catalog = {row["variable"]: row for row in csv.DictReader(
        (Path(__file__).resolve().parents[1] / "padml/science/variable.csv").open()
    )}
    columns = json.loads((Path(__file__).resolve().parents[1] / "padml/science/authority.json").read_text())["science"]["mice"]["private_handoff"]["columns"]
    stream = io.StringIO(newline="")
    writer = csv.DictWriter(stream, fieldnames=columns, lineterminator="\n")
    writer.writeheader()
    for index, (patient, center) in enumerate(zip(ids, centers)):
        row = {}
        for name in columns:
            entry = catalog.get(name)
            if entry and entry["type"] in {"binary", "ordered", "unordered"}:
                levels = next(value.strip()[7:] for value in entry["levels_or_coding"].split(";") if value.strip().startswith("levels="))
                row[name] = str(rng.choice(levels.split("|")))
            else:
                row[name] = str(float(rng.uniform(20, 100)))
        row.update(Patient_ID=patient, Center=str(center), Age=str(float(rng.uniform(40, 85))),
                   Height_cm=str(float(rng.uniform(155, 190))), Weight_kg=str(float(rng.uniform(45, 110))))
        row["AST_ALT"] = str(float(row["AST"]) / float(row["ALT"]))
        if index % 5 == 0:
            row["HGB"] = ""
        writer.writerow(row)
    return plan, stream.getvalue().encode(), private_response(ids, events)


@pytest.mark.parametrize("scope", ["FINAL_MICE", "ANALYSIS", "APPLICATION"])
def test_native_mice_retains_twenty_objects_and_replays_without_refitting(
    scope: str, tmp_path: Path,
) -> None:
    from padml.f5 import _extract_full_data_mice_view
    from padml.runtime import RSCRIPT_EXECUTABLE
    plan, covariates, response = native_mice_fixture()
    if scope == "FINAL_MICE":
        task = compile_final_full_data_mice_task(plan)
        fitted_response = response
    else:
        task = next(item for item in compile_full_data_search_mice_tasks(plan) if item["role"] == scope)
        fitted_response = search_analysis_response(plan, task, response) if scope == "ANALYSIS" else None
    source = tmp_path / "native-mice.zip"
    (tmp_path / "plan.json").write_bytes(canonical_json_bytes(plan))
    (tmp_path / "task.json").write_bytes(canonical_json_bytes(task))
    execute_full_data_search_mice_view(plan, task, covariates, fitted_response, source)
    entries = read_safe_zip(source)
    assert len([name for name in entries if name.startswith("native/")]) == 20
    destination = tmp_path / "replayed"
    _extract_full_data_mice_view(plan, task, source, destination)
    assert not list(destination.glob(".native-replay-*"))
    assert ("inputs/response.csv" in entries) == (task["role"] == "ANALYSIS")
    if scope == "FINAL_MICE":
        # One fixed original-kernel comparison proves instrumentation did not
        # change any of the 20 CSV/configuration/summary outputs or chain seeds.
        baseline = tmp_path / "original-kernel"
        baseline.mkdir()
        spec = {
            "mode": "IMPUTE_VIEW", "authority_path": str(Path(__file__).resolve().parents[1] / "padml/science/authority.json"),
            "variable_path": str(Path(__file__).resolve().parents[1] / "padml/science/variable.csv"),
            "covariates_path": str(destination / "inputs/covariates.csv"),
            "response_path": str(destination / "inputs/response.csv"),
            "output_dir": str(baseline / "output"), "chain_seeds": task["chain_seeds"],
            "view": {"view_id": task["view_id"], "role": "ANALYSIS", "outer_fold": 0,
                     "analysis_ids": plan["source_ids"], "row_ids": plan["source_ids"],
                     "row_ids_sha256": sha256_bytes(canonical_json_bytes(plan["source_ids"]))},
        }
        spec_path = baseline / "spec.json"
        spec_path.write_bytes(canonical_json_bytes(spec))
        result = subprocess.run(
            [RSCRIPT_EXECUTABLE, "--vanilla", str(Path(__file__).resolve().parents[1] / "padml/kernels/f1_nested_mice.R"), str(spec_path)],
            capture_output=True, text=True, check=False,
        )
        (baseline / "stdout.txt").write_text(result.stdout)
        (baseline / "stderr.txt").write_text(result.stderr)
        assert result.returncode == 0, result.stderr
        for path in (baseline / "output").rglob("*"):
            if path.is_file():
                raw = path.read_bytes()
                if path.suffix == ".json":
                    raw = canonical_json_bytes(strict_json_bytes(raw))
                assert raw == entries[path.relative_to(baseline / "output").as_posix()]
        # A self-consistently rehashed completed CSV is not native evidence.
        altered = dict(entries)
        frame = list(csv.DictReader(io.StringIO(altered["imputations/imp01.csv"].decode())))
        frame[0]["HGB"] = str(float(frame[0]["HGB"]) + 1)
        out = io.StringIO(newline="")
        writer = csv.DictWriter(out, fieldnames=list(frame[0]), lineterminator="\n")
        writer.writeheader(); writer.writerows(frame)
        altered["imputations/imp01.csv"] = out.getvalue().encode()
        manifest = strict_json_bytes(altered["manifest.json"])
        manifest["members"]["imputations/imp01.csv"] = {"sha256": sha256_bytes(altered["imputations/imp01.csv"]), "size_bytes": len(altered["imputations/imp01.csv"])}
        altered["manifest.json"] = canonical_json_bytes(manifest)
        forged = tmp_path / "tampered.zip"
        write_deterministic_zip(forged, altered)
        with pytest.raises(ContractError, match="F5_MICE_NATIVE_REPLAY_MISMATCH"):
            _extract_full_data_mice_view(plan, task, forged, tmp_path / "rejected")


@pytest.mark.parametrize("role", ["ANALYSIS", "APPLICATION"])
def test_a12_total_native_mice_removes_information_channel_and_replays(
    role: str, tmp_path: Path,
) -> None:
    from padml.f1_kernel import (
        _subset_csv, _view_seed_rows, compile_binding_contract, view_row_ids,
    )
    from padml.runtime import RSCRIPT_EXECUTABLE, activated_environment

    _, covariates, response = native_mice_fixture()
    registry = compile_binding_contract(
        covariates, response, workbook_sha256="a" * 64,
        enforce_formal_denominator=False,
    )["registry"]
    view_id = f"INNER_R2_K1_{role}"
    analysis_ids, row_ids = view_row_ids(registry, 1, view_id)
    seeds = [row["seed"] for row in _view_seed_rows(registry, 1, view_id)]
    repo = Path(__file__).resolve().parents[1]
    kernel = repo / "padml/kernels/f5_a12_mice.R"
    original = tmp_path / "original"
    original.mkdir()
    _subset_csv(covariates, row_ids, original / "covariates.csv")
    spec = {
        "mode": "IMPUTE_VIEW",
        "authority_path": str(repo / "padml/science/authority.json"),
        "variable_path": str(repo / "padml/science/variable.csv"),
        "covariates_path": str(original / "covariates.csv"),
        "output_dir": str(original / "output"), "chain_seeds": seeds,
        "view": {"view_id": view_id, "role": role, "outer_fold": 1,
                 "analysis_ids": analysis_ids, "row_ids": row_ids,
                 "row_ids_sha256": sha256_bytes(canonical_json_bytes(row_ids))},
    }
    if role == "ANALYSIS":
        _subset_csv(response, analysis_ids, original / "response.csv")
        spec["response_path"] = str(original / "response.csv")

    def run(root, current_spec, action):
        path = root / "spec.json"
        path.write_bytes(canonical_json_bytes(current_spec))
        command = [RSCRIPT_EXECUTABLE, "--vanilla", str(kernel), action, str(path)]
        if action == "REPLAY":
            command.append(str(original / "native"))
        result = subprocess.run(command, cwd=root, env=activated_environment(),
                                capture_output=True, text=True, timeout=1800)
        (root / "stdout.txt").write_text(result.stdout)
        (root / "stderr.txt").write_text(result.stderr)
        return result

    result = run(original, spec, "FIT")
    assert result.returncode == 0, result.stderr
    assert len(list((original / "native").glob("imp*.rds"))) == 20
    excluded = {"AST", "ALT", "AST_ALT"}
    output = original / "output"
    method = strict_json_bytes((output / "configuration/ACTUAL_MICE_METHOD.json").read_bytes())["payload"]
    matrix = strict_json_bytes((output / "configuration/ACTUAL_PREDICTOR_MATRIX.json").read_bytes())["payload"]
    assert not excluded.intersection(method["names"])
    assert not excluded.intersection(matrix["row_names"] + matrix["column_names"])
    assert ("event_aux" in matrix["column_names"]) == (role == "ANALYSIS")
    continuation = strict_json_bytes((output / "configuration/ACTUAL_CONTINUATION_CONFIG.json").read_bytes())["payload"]
    assert continuation["chain_seeds"] == seeds
    assert continuation["initial_iteration"] == 30
    assert continuation["continuation_iterations"] == [40, 50]
    assert continuation["final_iterations"] == [50] * 20
    for index in range(1, 21):
        rows = list(csv.DictReader((output / f"imputations/imp{index:02d}.csv").open()))
        assert len(rows[0]) == 60 and not excluded.intersection(rows[0])
        assert [row["Patient_ID"] for row in rows] == row_ids

    # Change only removed values, then consume the same 20 mids objects. This
    # cannot create new imputations; any retained-field drift must be rejected.
    for label, changed in (("removed-channel", "AST"), ("retained-field", "Age")):
        replay = tmp_path / label
        replay.mkdir()
        rows = list(csv.DictReader((original / "covariates.csv").open()))
        for row in rows:
            for field in (excluded if changed == "AST" else {changed}):
                row[field] = str(float(row[field]) + 17)
        stream = io.StringIO(newline="")
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]), lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)
        (replay / "covariates.csv").write_text(stream.getvalue())
        replay_spec = {**spec, "covariates_path": str(replay / "covariates.csv"),
                       "output_dir": str(replay / "output")}
        result = run(replay, replay_spec, "REPLAY")
        if label == "retained-field":
            assert result.returncode != 0
            assert "F5_MICE_NATIVE_INPUT_BINDING_INVALID" in result.stderr
            assert (replay / "native-failure.rda").is_file()
        else:
            assert result.returncode == 0, result.stderr
            assert (replay / "covariates-total.csv").read_bytes() == (original / "covariates-total.csv").read_bytes()
            for path in output.rglob("*"):
                if path.is_file():
                    assert path.read_bytes() == (replay / "output" / path.relative_to(output)).read_bytes()
            assert not (replay / "native").exists()
    (tmp_path / "verification.json").write_bytes(canonical_json_bytes({
        "scope": "SYNTHETIC_A12_TOTAL_MICE_COMPONENT", "role": role,
        "outer_fold": 1, "view_id": view_id, "chain_seeds": seeds,
        "mice_chain_count": 20, "model_fit_count": 0,
        "native_replay_exact": True, "removed_channel_invariant": True,
        "retained_input_drift_rejected": True, "stage_acceptance": False,
    }))


def a12_total_mice_source(tmp_path: Path, role: str) -> tuple[Path, dict[str, bytes]]:
    from padml.f1_kernel import compile_binding_contract
    from padml.f5_sensitivity import _a12_total_mice_input_members
    _, covariates, response = native_mice_fixture()
    contract = compile_binding_contract(covariates, response, workbook_sha256="a" * 64,
                                        enforce_formal_denominator=False)
    members = _a12_total_mice_input_members(
        contract, covariates, response, 1, f"INNER_R2_K1_{role}")
    source = tmp_path / "input.zip"
    write_deterministic_zip(source, members)
    return source, members


@pytest.mark.parametrize("role", ["ANALYSIS", "APPLICATION"])
def test_a12_mice_input_preserves_f1_view_and_physical_outcome_boundary(tmp_path, role):
    from padml.f5_sensitivity import _load_a12_total_mice_input
    source, members = a12_total_mice_source(tmp_path, role)
    value, loaded = _load_a12_total_mice_input(source)
    assert loaded == members
    assert value["view"]["outer_fold"] == 1
    assert value["view"]["view_id"] == f"INNER_R2_K1_{role}"
    first = 150000441 if role == "ANALYSIS" else 150000461
    assert value["chain_seeds"] == list(range(first, first + 20))
    assert ("response.csv" in members) == (role == "ANALYSIS")
    if role == "APPLICATION":
        assert set(members) == {"input.json", "covariates.csv"}
        assert "All_Cause_Death" not in next(csv.reader(io.StringIO(members["covariates.csv"].decode())))
        contaminated = tmp_path / "with-response.zip"
        write_deterministic_zip(contaminated, {**members, "response.csv": b"forbidden"})
        with pytest.raises(ContractError, match="F5_A12_MICE_VIEW_ROWS_OR_RESPONSE_INVALID"):
            _load_a12_total_mice_input(contaminated)


def test_a12_mice_failure_preserves_inputs_and_native_stderr(tmp_path, monkeypatch):
    from padml.f5_sensitivity import execute_a12_total_mice_bundle
    source, _ = a12_total_mice_source(tmp_path, "ANALYSIS")

    def fail_before_mice(command, **kwargs):
        assert command[3] == "FIT"
        kwargs["stderr"].write(b"F1_MICE_TEST_PRESTART_FAILURE\n")
        return subprocess.CompletedProcess(command, 1)

    monkeypatch.setattr("padml.f5_sensitivity.subprocess.run", fail_before_mice)
    with pytest.raises(ContractError, match="F1_MICE_TEST_PRESTART_FAILURE") as failure:
        execute_a12_total_mice_bundle(source, tmp_path / "result.zip")
    roots = list(tmp_path.glob(".a12-mice-*"))
    assert len(roots) == 1 and not (tmp_path / "result.zip").exists()
    assert (roots[0] / "inputs/response.csv").is_file()
    assert (roots[0] / "spec.json").is_file()
    assert (roots[0] / "stderr.txt").read_text() == "F1_MICE_TEST_PRESTART_FAILURE\n"
    assert any(str(roots[0]) in note for note in failure.value.__notes__)


@pytest.mark.parametrize("role", ["ANALYSIS", "APPLICATION"])
def test_a12_mice_materializer_reopens_existing_native_objects_without_mice(
    tmp_path, role, monkeypatch,
):
    from padml.f5_sensitivity import _pack_a12_total_mice_view, materialize_a12_total_mice_view
    path = os.environ.get("PADML_A12_NATIVE_EVIDENCE")
    if not path:
        pytest.skip("Requires the separately retained original A12 native M20 evidence; never refit it here")
    baseline = read_safe_zip(Path(path), max_member_bytes=64*1024*1024,
                             max_total_bytes=256*1024*1024)
    old_source = read_safe_zip(baseline["corrected/source-tests.zip"])
    repo = Path(__file__).resolve().parents[1]
    for name in ("f1_nested_mice.R", "f5_mice.R", "f5_a12_mice.R"):
        assert old_source[f"padml/kernels/{name}"] == (repo / "padml/kernels" / name).read_bytes()
    source, members = a12_total_mice_source(tmp_path, role)
    ordinal = 0 if role == "ANALYSIS" else 1
    prefix = f"corrected/test-output/test_a12_total_native_mice_rem{ordinal}/original/"
    retained = tmp_path / "retained"
    retained.mkdir()
    for name, raw in baseline.items():
        if name.startswith(prefix):
            target = retained / name[len(prefix):]
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(raw)
    assert (retained / "covariates.csv").read_bytes() == members["covariates.csv"]
    if role == "ANALYSIS":
        assert (retained / "response.csv").read_bytes() == members["response.csv"]
    payload = tmp_path / "native.zip"
    _pack_a12_total_mice_view(source, retained, payload)
    native_run = subprocess.run
    actions = []

    def replay_only(command, **kwargs):
        assert command[3] == "REPLAY"
        actions.append(command[3])
        return native_run(command, **kwargs)

    monkeypatch.setattr("padml.f5_sensitivity.subprocess.run", replay_only)
    result = materialize_a12_total_mice_view(source, payload, tmp_path / "materialized")
    assert result["view"]["role"] == role and len(result["members"]) == 20
    assert result["stage_acceptance"] is False and actions == ["REPLAY"]
    assert not (tmp_path / "materialized/replay").exists()
    entries = read_safe_zip(payload)
    if role == "ANALYSIS":
        rows = list(csv.DictReader(io.StringIO(entries["imputations/imp01.csv"].decode())))
        rows[0]["HGB"] = str(float(rows[0]["HGB"]) + 1)
        stream = io.StringIO(newline="")
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]), lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)
        for label, changed in (
            ("completed-data", {"imputations/imp01.csv": stream.getvalue().encode()}),
            ("swapped-object", {"native/imp01.rds": entries["native/imp02.rds"]}),
        ):
            damaged = tmp_path / f"{label}.zip"
            write_deterministic_zip(damaged, {**entries, **changed})
            reason = ("F5_A12_MICE_NATIVE_REPLAY_MISMATCH" if label == "completed-data"
                      else "F5_MICE_NATIVE_INPUT_BINDING_INVALID")
            with pytest.raises(ContractError, match=reason):
                materialize_a12_total_mice_view(source, damaged, tmp_path / label)
            assert (tmp_path / label / "replay/spec.json").is_file()
        assert actions == ["REPLAY"] * 3
    (tmp_path / "verification.json").write_bytes(canonical_json_bytes({
        "role": role, "native_mice_objects_reused": 20, "new_mice_chain_count": 0,
        "model_fit_count": 0, "r_actions": actions, "native_replay_passed": True,
        "bad_completed_data_and_chain_rejected": role == "ANALYSIS",
        "stage_acceptance": False,
    }))


@pytest.mark.parametrize("channel", ["AST", "ALT", "AST_ALT"])
def test_a12_recipe_rejects_information_channel_before_native_work(tmp_path, channel):
    from padml.f5 import _compile_partition_design_recipe
    from padml.f5_sensitivity import compile_a12_total_recipe
    with pytest.raises(ContractError, match="F5_A12_DESIGN_CHANNEL_NOT_REMOVED"):
        _compile_partition_design_recipe("COX_PH", ["Age", channel], {}, tmp_path, a12=True)
    with pytest.raises(ContractError, match="F5_A12_DESIGN_CHANNEL_NOT_REMOVED"):
        compile_a12_total_recipe("COX_PH", ["Age", channel],
                                 tmp_path / "absent.zip", tmp_path / "absent-native.zip",
                                 tmp_path / "unused")
    assert not list(tmp_path.iterdir())


def test_a12_native_m20_recipe_and_seven_family_designs_without_refitting(tmp_path, monkeypatch):
    from padml.f2_kernel import F2_FAMILIES, _expected_family_parent_column_map
    from padml.f5 import _compile_partition_design_recipe, _final_python_design
    from padml.f5_sensitivity import compile_a12_total_recipe
    from padml.runtime import RSCRIPT_EXECUTABLE, THREAD_ENV
    import shutil

    path = os.environ.get("PADML_A12_WIRING_EVIDENCE")
    if not path:
        pytest.skip("Requires retained A12 native M20 evidence; never generate new chains here")
    baseline = read_safe_zip(Path(path), max_member_bytes=64*1024*1024,
                             max_total_bytes=256*1024*1024)
    prefix = "test-output/test_a12_mice_materializer_reo0/"
    source, payload = tmp_path / "input.zip", tmp_path / "native.zip"
    source.write_bytes(baseline[prefix + "input.zip"])
    payload.write_bytes(baseline[prefix + "native.zip"])
    selected = ["Age", "Creatinine", "HGB", "Sex"]  # spline, log1p, identity, factor
    calls = []
    native_run = subprocess.run

    def record_native(command, **kwargs):
        kernel = Path(command[2] if command[1] == "--vanilla" else command[1]).name
        if kernel == "f5_a12_mice.R":
            assert command[3] == "REPLAY"
            calls.append({"action": "REPLAY_MICE", "new_chains": 0})
        elif kernel == "f5_final_refit.R":
            spec = strict_json_bytes(Path(command[2]).read_bytes())
            assert spec["action"] in {"COMPILE_A12_RECIPE", "COMPILE_FINAL_RECIPE"}
            evidence = tmp_path / f"recipe-call-{len(calls)}"
            evidence.mkdir()
            (evidence / "spec.json").write_bytes(canonical_json_bytes(spec))
            shutil.copytree(spec["projection"]["recipe_registry_record"]["input_dir"],
                            evidence / "training-inputs")
            result = native_run(command, **kwargs)
            (evidence / "stdout.txt").write_text(
                result.stdout if result.stdout is not None else Path(kwargs["stdout"].name).read_text())
            (evidence / "stderr.txt").write_text(
                result.stderr if result.stderr is not None else Path(kwargs["stderr"].name).read_text())
            calls.append({"action": spec["action"], "exit_code": result.returncode})
            return result
        return native_run(command, **kwargs)

    monkeypatch.setattr("padml.f5.subprocess.run", record_native)
    native, cox = compile_a12_total_recipe(
        "COX_PH", selected, source, payload, tmp_path / "materialized")
    assert native["stage_acceptance"] is False and len(native["members"]) == 20
    view = native["view"]
    partition = {
        "partition_id": f"A12_TOTAL_F{view['outer_fold']}_{view['view_id']}",
        "fit_ids": view["analysis_ids"],
        "covariates": {"input_dir": native["input_dir"],
                       "analysis_ids_sha256": sha256_bytes(canonical_json_bytes(view["analysis_ids"])),
                       "analysis_view_sha256": native["native_archive_sha256"]},
    }
    # Reference-only synthetic comparison: restore observed channel columns to
    # a separate copy. Production total inputs remain physically channel-free.
    raw = read_safe_zip(source)["covariates.csv"]
    observed = {r["Patient_ID"]: r for r in csv.DictReader(io.StringIO(raw.decode()))}
    reference_dir = tmp_path / "synthetic-reference"
    reference_dir.mkdir()
    total_frames, reference_frames = [], []
    for imputation in range(1, 21):
        rows = list(csv.DictReader((Path(native["input_dir"]) / f"imp{imputation:02d}.csv").open()))
        assert len(rows[0]) == 60 and not {"AST", "ALT", "AST_ALT"}.intersection(rows[0])
        assert not {"All_Cause_Death", "Death_Followup_months"}.intersection(rows[0])
        assert [row["Patient_ID"] for row in rows] == view["analysis_ids"]
        restored = [{**row, **{key: observed[row["Patient_ID"]][key]
                              for key in ("AST", "ALT", "AST_ALT")}} for row in rows]
        stream = io.StringIO(newline="")
        writer = csv.DictWriter(stream, fieldnames=list(restored[0]), lineterminator="\n")
        writer.writeheader()
        writer.writerows(restored)
        (reference_dir / f"imp{imputation:02d}.csv").write_text(stream.getvalue())
        total_frames.append(rows)
        reference_frames.append(restored)
    reference_partition = copy.deepcopy(partition)
    reference_partition["covariates"]["input_dir"] = str(reference_dir)
    reference = _compile_partition_design_recipe("COX_PH", selected, reference_partition, tmp_path)
    for field in ("representations", "ordered_parent_column_map"):
        assert cox["transform_recipe"][field] == reference["transform_recipe"][field]
    ast = next(row for row in cox["transform_recipe"]["representations"] if row["parent"] == "AST_ALT")
    assert ast == {"parent": "AST_ALT", "canonical_unit": "ratio", "representation": "IDENTITY",
                   "design_df": 1, "design_columns": ["AST_ALT"], "parameters": {"identity": True}}
    recipes, expected = {}, {}
    predictors = predictor_contract(Path(__file__).resolve().parents[1] / "padml")
    for family in F2_FAMILIES:
        recipe = cox if family == "COX_PH" else _compile_partition_design_recipe(
            family, selected, partition, tmp_path, a12=True)
        recipes[family] = recipe
        columns = _expected_family_parent_column_map(selected, family, predictors, recipe["transform_recipe"])
        expected[family] = [column for row in columns for column in row["columns"]]
        assert not {"AST", "ALT", "AST_ALT"}.intersection(expected[family])
        if recipe["transform_recipe"]:
            assert recipe["transform_recipe"] == cox["transform_recipe"]
        if family in {"XGBOOST_COX", "COXTIME_SET_A"}:
            for rows, restored in zip(total_frames, reference_frames, strict=True):
                design, columns, np, _ = _final_python_design(family, {"selected_parents": selected}, rows, recipe)
                original = _final_python_design(family, {"selected_parents": selected}, restored, recipe)[0]
                assert columns == expected[family] and np.array_equal(design, original)

    design_spec = tmp_path / "design-spec.json"
    design_spec.write_bytes(canonical_json_bytes({"recipes": recipes, "reference": reference,
        "expected": expected, "selected": selected, "input_dir": native["input_dir"],
        "reference_dir": str(reference_dir)}))
    r_code = r'''
args <- commandArgs(trailingOnly=TRUE)
source(args[[1L]])
spec <- jsonlite::fromJSON(args[[2L]], simplifyVector=FALSE)
scalar <- function(value) unname(unlist(value, use.names=FALSE)[[1L]])
need <- function(ok, reason) if (!isTRUE(ok)) stop(reason)
selected <- unlist(spec$selected, use.names=FALSE)
for (family in c("COX_PH", "ELASTIC_NET_COX", "FPM_TVC_SET_A", "RSF", "GBM_COX")) {
  recipe <- spec$recipes[[family]]
  transform <- if (is.null(recipe$transform_recipe)) NULL else spec$reference$transform_recipe
  for (i in seq_len(20L)) {
    rows <- read.csv(file.path(scalar(spec$input_dir), sprintf("imp%02d.csv", i)), check.names=FALSE)
    original <- read.csv(file.path(scalar(spec$reference_dir), sprintf("imp%02d.csv", i)), check.names=FALSE)
    actual <- padml_prepare_final_r_design(rows, selected, recipe$predictor_rows,
                 recipe$transform_recipe, family, scalar, need)$design
    reference <- padml_prepare_final_r_design(original, selected, recipe$predictor_rows,
                 transform, family, scalar, need)$design
    stopifnot(identical(actual, reference),
              identical(colnames(actual), unlist(spec$expected[[family]], use.names=FALSE)),
              !any(c("AST", "ALT", "AST_ALT") %in% colnames(actual)))
  }
}
cat("PASS: five R families x M20; no model fits\n")
'''
    (tmp_path / "verify-design.R").write_text(r_code)
    result = subprocess.run([RSCRIPT_EXECUTABLE, str(tmp_path / "verify-design.R"),
        str(Path(__file__).resolve().parents[1] / "padml/kernels/f5_design.R"), str(design_spec)],
        env={**os.environ, **THREAD_ENV}, capture_output=True, text=True, check=False, timeout=60)
    (tmp_path / "design-stdout.txt").write_text(result.stdout)
    (tmp_path / "design-stderr.txt").write_text(result.stderr)
    assert result.returncode == 0, result.stderr
    # The ordinary final/main branch still rejects a missing required parent.
    with pytest.raises(ContractError, match="F2_RECIPE_PARENT_MISSING"):
        _compile_partition_design_recipe("COX_PH", selected, partition, tmp_path)
    app_prefix = "test-output/test_a12_mice_materializer_reo1/"
    app_source = tmp_path / "application-input.zip"
    app_source.write_bytes(baseline[app_prefix + "input.zip"])
    with pytest.raises(ContractError, match="F5_A12_RECIPE_ANALYSIS_REQUIRED"):
        compile_a12_total_recipe("COX_PH", selected, app_source, tmp_path / "absent.zip", tmp_path / "unused")
    assert not (tmp_path / "unused").exists()
    assert [row["action"] for row in calls].count("REPLAY_MICE") == 1
    (tmp_path / "verification.json").write_bytes(canonical_json_bytes({
        "families": list(F2_FAMILIES), "imputations": 20, "training_rows": len(view["analysis_ids"]),
        "new_mice_chains": 0, "model_fits": 0, "r_calls": calls,
        "channel_free_designs_match_reference": True,
        "main_missing_parent_rejected": True, "application_recipe_rejected": True,
        "recipe_keeps_unused_static_identity_descriptor": True, "stage_acceptance": False,
    }))


def test_a12_model_coordinates_and_spec_stop_before_native_fit(tmp_path, monkeypatch):
    recipe = _test_final_design_recipe("FPM_TVC_SET_A", ["HGB"])
    task = {"selected_parents": ["HGB"], "model_seed": None, "imputation": 1,
            "a12_coordinates": {"outer_fold": 2, "branch": "WITHOUT_AST_ALT_TOTAL", "imputation": 1},
            "parameters": {"family": "FPM_TVC_SET_A", "df": 3, "tvc_df": 0}}
    rows = [{"Patient_ID": "fixture", "Center": "36", "HGB": "120"}]
    def forbidden(*args, **kwargs):
        raise AssertionError("Native fit must not start")
    monkeypatch.setattr("padml.f5.subprocess.run", forbidden)
    for changed, reason in (
        ({"a12_coordinates": {"outer_fold": 0, "branch": "WITHOUT_AST_ALT_TOTAL", "imputation": 1}}, "F5_A12_COORDINATES_INVALID"),
        ({"a12_coordinates": {"outer_fold": 2, "branch": "WITHOUT_AST_ALT_TOTAL", "imputation": 21}}, "F5_A12_COORDINATES_INVALID"),
        ({"a19_coordinates": {}}, "F5_A12_COORDINATES_INVALID"),
        ({"model_seed": 300000}, "F5_A12_MODEL_SEED_INVALID"),
        ({"parameters": {"family": "FPM_TVC_SET_A", "df": 3, "tvc_df": 1}}, "F5_A12_FPM_SPEC_INVALID"),
    ):
        with pytest.raises(ContractError, match=reason):
            _execute_final_refit_engine("FPM_TVC_SET_A", {**task, **changed}, rows, {}, recipe)


@pytest.mark.parametrize("family", ["FPM_TVC_SET_A", "COX_PH"])
def test_a12_native_fixed_fit_without_channel_and_retained_replay(tmp_path, monkeypatch, family):
    from padml.f5 import _validate_a12_fpm_fit_evidence
    from padml.f2_validation import _validate_fpm_fit_evidence
    from padml.runtime import R_FPM_CORRECTION
    if family == "FPM_TVC_SET_A" and not Path(R_FPM_CORRECTION).is_dir():
        pytest.skip("Requires the already installed native continuous-domain runtime")
    np = pytest.importorskip("numpy")
    rng = np.random.default_rng(71239)
    times, events = rng.exponential(10, 400) + .01, rng.binomial(1, .75, 400)
    hgb = rng.uniform(.2, 3, 400)
    rows = [{"Patient_ID": f"a12-fixed-{i:04d}", "Center": "36", "HGB": str(hgb[i])}
            for i in range(400)]
    responses = {row["Patient_ID"]: {"Patient_ID": row["Patient_ID"],
        "All_Cause_Death": str(events[i]), "Death_Followup_months": str(times[i])}
        for i, row in enumerate(rows)}
    task = {"selected_parents": ["HGB"], "model_seed": None, "imputation": 1,
            "a12_coordinates": {"outer_fold": 2, "branch": "WITHOUT_AST_ALT_TOTAL", "imputation": 1},
            "parameters": ({"family": family, "df": 3, "tvc_df": 0} if family == "FPM_TVC_SET_A"
                           else {"family": family, "ties": "breslow"})}
    recipe = _test_final_design_recipe(family, ["HGB"])
    (tmp_path / "input.json").write_bytes(canonical_json_bytes({
        "task": task, "covariates": rows, "response": responses, "recipe": recipe}))
    native_run, actions = subprocess.run, []
    def count_native(command, **kwargs):
        if len(command) > 3 and Path(command[2]).name == "f5_final_refit.R":
            spec = strict_json_bytes(Path(command[3]).read_bytes())
            actions.append(spec["action"])
            assert actions.count("FINAL_REFIT") <= 1
            assert spec["a12_coordinates"] == task["a12_coordinates"]
        return native_run(command, **kwargs)
    monkeypatch.setattr("padml.f5.subprocess.run", count_native)
    fitted = _execute_final_refit_engine(family, task, rows, responses, recipe)
    (tmp_path / "model.rds").write_bytes(fitted["model"])
    (tmp_path / "baseline.rds").write_bytes(fitted["baseline"])
    (tmp_path / "result.json").write_bytes(canonical_json_bytes({
        key: value for key, value in fitted.items() if key not in {"model", "baseline"}}))
    _assert_final_prediction_applications(family, task, rows, responses, recipe, fitted)
    assert actions == ["FINAL_REFIT", "REPLAY", "REPLAY", "REPLAY", "REPLAY"]
    if family == "FPM_TVC_SET_A":
        health = fitted["fit_health"]
        assert health["df"] == 3 and health["tvc_df"] == 0 and health["coefficient_count"] == 5
        evidence = health["fit_evidence"]
        _validate_a12_fpm_fit_evidence(evidence, 5)
        assert len(evidence["spline_bases"]) == 1
        domain = evidence["continuous_domain"]
        assert len(domain["pieces"]) == 3
        assert domain["max_iterations_per_round"] == 100 and domain["max_rounds"] == 10
        assert domain["minimum_log_time_derivative"] > 0
        with pytest.raises(ContractError):
            _validate_fpm_fit_evidence(evidence, [3, 1], 5)
        for damage in ("budget", "minimum", "gradient", "basis"):
            bad = copy.deepcopy(evidence)
            if damage == "budget": bad["continuous_domain"]["max_rounds"] = 11
            elif damage == "minimum": bad["continuous_domain"]["pieces"][0]["minimum"] = -1
            elif damage == "gradient": bad["constrained_optimality"]["gradient"][0] += 1
            else: bad["spline_bases"][0]["df"] = 4
            with pytest.raises(ContractError, match="F5_A12_FPM_FIT_EVIDENCE_INVALID"):
                _validate_a12_fpm_fit_evidence(bad, 5)
    (tmp_path / "verification.json").write_bytes(canonical_json_bytes({
        "family": family, "model_fit_count": 1, "model_refit_count": 0,
        "new_mice_chains": 0, "grid_search_count": 0, "r_actions": actions,
        "predictor_channel_absent": True, "native_retained_prediction_replay_exact": True,
        "stage_acceptance": False,
    }))


def test_a12_extension_preserves_retained_main_fpm_predictions(tmp_path, monkeypatch):
    from padml.f5 import _validate_final_r_fit_health
    from padml.f2_kernel import _expected_family_parent_column_map
    path = os.environ.get("PADML_A19_RETAINED_EVIDENCE")
    if not path:
        pytest.skip("Requires previously retained native FPM; never refit here")
    archive = read_safe_zip(Path(path))
    source = archive["final-pair/test-output/test_a19_native_fit_retains_ob1/component.zip"]
    (tmp_path / "component.zip").write_bytes(source)
    entries = read_safe_zip(source)
    task, recipe, health = (strict_json_bytes(entries[name]) for name in
                            ("task.json", "recipe.json", "fit-health.json"))
    rows = list(csv.DictReader(io.StringIO(entries["fit-covariates.csv"].decode())))
    responses = {row["Patient_ID"]: row for row in csv.DictReader(io.StringIO(entries["fit-response.csv"].decode()))}
    predictors = predictor_contract(Path(__file__).resolve().parents[1] / "padml")
    _validate_final_r_fit_health("FPM_TVC_SET_A", health, {}, training_count=len(rows),
        ordered_parent_column_map=_expected_family_parent_column_map(
            task["selected_parents"], "FPM_TVC_SET_A", predictors, recipe["transform_recipe"]))
    native_run, calls = subprocess.run, []
    def replay_only(command, **kwargs):
        spec = strict_json_bytes(Path(command[3]).read_bytes())
        assert spec["action"] == "REPLAY" and "a12_coordinates" not in spec
        calls.append(spec["action"])
        return native_run(command, **kwargs)
    monkeypatch.setattr("padml.f5.subprocess.run", replay_only)
    replay = _execute_final_refit_engine("FPM_TVC_SET_A", task, rows, responses, recipe,
        retained_objects=(entries["model.bin"], entries["baseline.bin"]))
    assert replay["survival"] == strict_json_bytes(entries["training-prediction.json"])
    assert calls == ["REPLAY"]
    (tmp_path / "verification.json").write_bytes(canonical_json_bytes({
        "retained_main_fpm_prediction_exact": True, "model_fit_count": 0,
        "r_actions": calls, "stage_acceptance": False}))


@pytest.mark.parametrize("case", ["a12_fpm", "a12_cox", "main_fpm"])
def test_a12_native_object_audit_consumes_retained_evidence_without_fits(tmp_path, monkeypatch, case):
    from padml.f5 import _validate_a12_fpm_fit_evidence
    path = os.environ.get("PADML_A12_RETAINED_EVIDENCE")
    if not path:
        pytest.skip("Requires retained A12 models; this test must never refit")
    archive = read_safe_zip(Path(path))
    if case == "main_fpm":
        component = archive["test-output/test_a12_extension_preserves_r0/component.zip"]
        entries = read_safe_zip(component)
        task, recipe, health = (strict_json_bytes(entries[name]) for name in
                                ("task.json", "recipe.json", "fit-health.json"))
        rows = list(csv.DictReader(io.StringIO(entries["fit-covariates.csv"].decode())))
        responses = _response_rows(entries["fit-response.csv"])[1]
        objects = (entries["model.bin"], entries["baseline.bin"])
        expected = strict_json_bytes(entries["training-prediction.json"])
        family = "FPM_TVC_SET_A"
        (tmp_path / "retained-input.zip").write_bytes(component)
    else:
        ordinal = 0 if case == "a12_fpm" else 1
        prefix = f"test-output/test_a12_native_fixed_fit_with{ordinal}/"
        raw = {name: archive[prefix + name] for name in
               ("input.json", "model.rds", "baseline.rds", "result.json")}
        value, result = strict_json_bytes(raw["input.json"]), strict_json_bytes(raw["result.json"])
        task, recipe, rows, responses = (value[key] for key in ("task", "recipe", "covariates", "response"))
        family = "FPM_TVC_SET_A" if case == "a12_fpm" else "COX_PH"
        task = {**task, "family": family, "family_design_column_count": 1, "row_count": len(rows)}
        health, objects, expected = result["fit_health"], (raw["model.rds"], raw["baseline.rds"]), result["survival"]
        write_deterministic_zip(tmp_path / "retained-input.zip", raw)
    native_run, calls = subprocess.run, []
    def no_fit(command, **kwargs):
        kernel = Path(command[2]).name
        if kernel == "f5_final_refit.R":
            spec = strict_json_bytes(Path(command[3]).read_bytes())
            assert spec["action"] == "REPLAY"
            calls.append("REPLAY")
        else:
            assert kernel == "retained-object-audit.R"
            calls.append("NATIVE_OBJECT_AUDIT")
        return native_run(command, **kwargs)
    monkeypatch.setattr("padml.f5.subprocess.run", no_fit)
    audit = _validate_retained_model_objects(family, *objects, health, task)
    (tmp_path / "native-audit.json").write_bytes(canonical_json_bytes(audit))
    assert audit["selected_parents"] == task["selected_parents"]
    if case == "a12_fpm":
        assert "non_ph_contrast" not in audit
        assert audit["coefficient_count"] == 5
        assert audit["fit_evidence"] == health["fit_evidence"]
        _validate_a12_fpm_fit_evidence(audit["fit_evidence"], 5)
        # A numerically plausible declaration must still match the native fit.
        changed = copy.deepcopy(health)
        changed["fit_evidence"]["objective_value"] += 1
        _validate_a12_fpm_fit_evidence(changed["fit_evidence"], 5)
        with pytest.raises(ContractError, match="F5_FINAL_REFIT_RETAINED_OBJECT_HEALTH_DRIFT"):
            _validate_retained_model_objects(family, *objects, changed, task)
        main_task = {key: item for key, item in task.items() if key != "a12_coordinates"}
        with pytest.raises(ContractError, match="F5_FINAL_REFIT_RETAINED_OBJECT_INVALID"):
            _validate_retained_model_objects(family, *objects, health, main_task)
    elif case == "main_fpm":
        assert "non_ph_contrast" in audit
        changed = {key: item for key, item in task.items() if key != "a19_coordinates"}
        changed.update({"a12_coordinates": {"outer_fold": 2, "imputation": 1},
                        "parameters": {"family": family, "df": 3, "tvc_df": 0},
                        "selected_parents": ["HGB"], "family_design_column_count": 1,
                        "model_seed": None})
        with pytest.raises(ContractError, match="F5_FINAL_REFIT_RETAINED_OBJECT_INVALID"):
            _validate_retained_model_objects(family, *objects, health, changed)
    replay = _execute_final_refit_engine(family, task, rows, responses, recipe, retained_objects=objects)
    assert replay["survival"] == expected
    assert calls.count("REPLAY") == 1
    (tmp_path / "verification.json").write_bytes(canonical_json_bytes({
        "case": case, "model_fit_count": 0, "new_mice_chains": 0, "grid_search_count": 0,
        "native_calls": calls, "training_prediction_replay_exact": True,
        "a12_and_main_object_domains_separate": True, "stage_acceptance": False}))


def test_a12_retained_audit_rejects_coordinates_before_r(tmp_path, monkeypatch):
    def forbidden(*args, **kwargs):
        raise AssertionError("Invalid A12 coordinates must not open native objects")
    monkeypatch.setattr("padml.f5.subprocess.run", forbidden)
    task = {"family_design_column_count": 1, "row_count": 400,
            "selected_parents": ["HGB"], "model_seed": None, "imputation": 1,
            "a12_coordinates": {"outer_fold": 2, "branch": "WITHOUT_AST_ALT_TOTAL", "imputation": 1},
            "parameters": {"family": "FPM_TVC_SET_A", "df": 3, "tvc_df": 0}}
    for changed, reason in (
        ({"a12_coordinates": {"outer_fold": 0, "branch": "WITHOUT_AST_ALT_TOTAL", "imputation": 1}}, "F5_A12_COORDINATES_INVALID"),
        ({"a19_coordinates": {}}, "F5_A12_COORDINATES_INVALID"),
        ({"selected_parents": ["AST_ALT"]}, "F5_A12_COORDINATES_INVALID"),
        ({"model_seed": 300000}, "F5_A12_MODEL_SEED_INVALID"),
        ({"parameters": {"family": "FPM_TVC_SET_A", "df": 3, "tvc_df": 1}}, "F5_A12_FPM_SPEC_INVALID"),
    ):
        with pytest.raises(ContractError, match=reason):
            _validate_retained_model_objects("FPM_TVC_SET_A", b"native-model", b"native-baseline", {}, {**task, **changed})


def test_mice_failure_preserves_inputs_output_and_completed_chains(tmp_path, monkeypatch):
    keys, centers, events = resampling_input()
    ids = [f"raw-patient-{index}" for index in range(len(keys))]
    plan = compile_full_data_mice_plan(ids, keys, centers, events, family="ELASTIC_NET_COX", workers=24)
    def fail_native(arguments, **unused):
        root = Path(arguments[-1]).parent
        (root / "native").mkdir()
        (root / "native/imp01.rds").write_bytes(b"FIXTURE_NATIVE_PARTIAL")
        return subprocess.CompletedProcess(arguments, 1, "original stdout", "F1_MICE_CONVERGENCE_FAILED")
    monkeypatch.setattr("padml.f5.subprocess.run", fail_native)
    with pytest.raises(ContractError, match="F1_MICE_CONVERGENCE_FAILED") as captured:
        execute_final_full_data_mice_view(plan, compile_final_full_data_mice_task(plan),
                                         private_covariates(ids, centers), private_response(ids, events), tmp_path / "failed.zip")
    root = next(tmp_path.glob(".f5-mice-*"))
    assert f"F5_MICE_NATIVE_EVIDENCE:{root}" in captured.value.__notes__
    assert (root / "covariates.csv").is_file() and (root / "response.csv").is_file()
    assert (root / "native/imp01.rds").read_bytes() == b"FIXTURE_NATIVE_PARTIAL"
    assert (root / "stdout.txt").read_text() == "original stdout"
    assert (root / "stderr.txt").read_text() == "F1_MICE_CONVERGENCE_FAILED"
    assert not (tmp_path / "failed.zip").exists()


@pytest.mark.parametrize("scope", ["FINAL", "SEARCH"])
def test_mice_materializers_preserve_native_replay_failure(scope, tmp_path, monkeypatch):
    keys, centers, events = resampling_input()
    ids = [f"raw-patient-{index}" for index in range(len(keys))]
    plan = compile_full_data_mice_plan(ids, keys, centers, events, family="ELASTIC_NET_COX", workers=24)
    covariates, response = private_covariates(ids, centers), private_response(ids, events)
    monkeypatch.setattr("padml.f5.subprocess.run", fake_mice_run)
    if scope == "FINAL":
        source = tmp_path / "final.zip"
        execute_final_full_data_mice_view(plan, compile_final_full_data_mice_task(plan),
                                         covariates, response, source)
    else:
        sources = {}
        for task in compile_full_data_search_mice_tasks(plan):
            if task["split_id"] == "F5_R01_K01":
                source = tmp_path / f"{task['role']}.zip"
                execute_full_data_search_mice_view(plan, task, covariates,
                    search_analysis_response(plan, task, response) if task["role"] == "ANALYSIS" else None, source)
                sources[task["role"]] = source
    def fail_replay(arguments, **unused):
        assert "REPLAY" in arguments
        root = Path(arguments[-2]).parent
        (root / "native-failure.rda").write_bytes(b"FIXTURE_NATIVE_FRAMES")
        return subprocess.CompletedProcess(arguments, 1, "native stdout", "F5_MICE_NATIVE_INPUT_BINDING_INVALID")
    monkeypatch.setattr("padml.f5.subprocess.run", fail_replay)
    destination = tmp_path / "failed-materialization"
    with pytest.raises(ContractError, match="F5_MICE_NATIVE_INPUT_BINDING_INVALID") as captured:
        if scope == "FINAL":
            materialize_final_full_data_mice(plan, source, response, destination)
        else:
            materialize_full_data_search_partition(plan, "F5_R01_K01", sources["ANALYSIS"], sources["APPLICATION"], response, destination)
    assert f"F5_MICE_MATERIALIZATION_EVIDENCE:{destination}" in captured.value.__notes__
    frames = list(destination.rglob("native-failure.rda"))
    assert len(frames) == 1 and frames[0].read_bytes() == b"FIXTURE_NATIVE_FRAMES"
    assert (frames[0].parent / "stderr.txt").read_text() == "F5_MICE_NATIVE_INPUT_BINDING_INVALID"


def test_final_full_data_mice_materializes_once_for_a16_and_refit(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    keys, centers, events = resampling_input()
    source_ids = [f"raw-patient-{index}" for index in range(len(keys))]
    plan = compile_full_data_mice_plan(source_ids, keys, centers, events, family="ELASTIC_NET_COX", workers=24)
    task = compile_final_full_data_mice_task(plan)
    monkeypatch.setattr("padml.f5.subprocess.run", fake_mice_run)
    payload = tmp_path / "final-full-data.zip"
    response = private_response(source_ids, events)
    execute_final_full_data_mice_view(
        plan, task, private_covariates(source_ids, centers), response, payload
    )
    materialized = materialize_final_full_data_mice(
        plan, payload, response, tmp_path / "final-full-data"
    )
    assert materialized["kind"] == "FINAL_FULL_DATA"
    assert materialized["fit_ids"] == plan["source_ids"]
    assert materialized["model_fit_count"] == 0
    assert materialized["fit_response"]["row_count"] == len(source_ids)
    assert len(materialized["covariates"]["members"]) == 20
    assert len(materialized["fit_covariate_members"]) == 20
    fold_source = materialized["a16_fold_source"]
    assert fold_source["identity_sha256"] == plan["a16_fold_source"][
        "identity_sha256"
    ]
    assert fold_source["selector_seed"] == 200000
    assert fold_source["selector_fold_count"] == 5
    assert fold_source["selector_foldid"] == plan["a16_fold_source"][
        "selector_foldid"
    ]
    assert fold_source["new_split_generation_count"] == 0
    assert not (tmp_path / "final-full-data/application").exists()


def test_full0_mice_extraction_uses_stream_records_before_native_replay(tmp_path, monkeypatch):
    from padml import f5
    keys, centers, events = resampling_input()
    ids = [f"raw-patient-{index}" for index in range(len(keys))]
    plan = compile_full_data_mice_plan(ids, keys, centers, events, family="ELASTIC_NET_COX", workers=24)
    task = compile_final_full_data_mice_task(plan)
    monkeypatch.setattr(f5.subprocess, "run", fake_mice_run)
    payload = tmp_path / "native.zip"
    execute_final_full_data_mice_view(plan, task, private_covariates(ids, centers), private_response(ids, events), payload)
    original_extract, original_sha, original_replay = f5.extract_safe_zip, f5.sha256_file, f5._replay_mice_native_view
    streams, replays = [], []
    def extract(path, destination, **kwargs):
        assert isinstance(kwargs["expected_members"], dict)
        streams.append(path)
        return original_extract(path, destination, **kwargs)
    def no_native_rescan(path):
        assert not (path.parent.name == "native" and path.suffix == ".rds")
        return original_sha(path)
    def replay(*args, **kwargs):
        replays.append(args[4])
        return original_replay(*args, **kwargs)
    monkeypatch.setattr(f5, "extract_safe_zip", extract)
    monkeypatch.setattr(f5, "sha256_file", no_native_rescan)
    monkeypatch.setattr(f5, "_replay_mice_native_view", replay)
    f5._extract_full_data_mice_view(plan, task, payload, tmp_path / "good")
    assert streams == [payload] and replays == [tmp_path / "good"]
    entries = read_safe_zip(payload)
    for damage in ("sha256", "size_bytes"):
        manifest = strict_json_bytes(entries["manifest.json"])
        record = manifest["members"]["native/imp01.rds"]
        record[damage] = "0" * 64 if damage == "sha256" else record[damage] + 1
        changed = tmp_path / f"bad-{damage}.zip"
        write_deterministic_zip(changed, {**entries, "manifest.json": canonical_json_bytes(manifest)})
        with pytest.raises(ContractError):
            f5._extract_full_data_mice_view(plan, task, changed, tmp_path / f"bad-{damage}")
        assert replays == [tmp_path / "good"]


def test_full0_mice_response_binding_matches_producer_order_not_raw_row_order(tmp_path, monkeypatch):
    """Real producer/materializer bytes with MOCK native MICE, never real imputation."""
    ids = [f"UNFITTED-patient-{index:03d}" for index in range(224)]
    keys = [sha256_bytes(patient.encode()) for patient in ids]
    centers = [center for center in [36, 38, 39, 48, 52, 54, 55] for _ in range(32)]
    events = [index % 2 for index in range(len(ids))]
    plan = compile_full_data_mice_plan(ids, keys, centers, events, family=None)
    assert plan["source_ids"] != ids
    response = private_response(ids, events)
    from test_full0_entry_points import unfitted_full0_mice_run
    monkeypatch.setattr("padml.f5.subprocess.run", unfitted_full0_mice_run)
    payload = tmp_path / "UNFITTED-full-MICE.zip"
    execute_final_full_data_mice_view(plan, compile_final_full_data_mice_task(plan),
        valid_unfitted_mice_covariates(ids, centers), response, payload)
    materialized = materialize_final_full_data_mice(plan, payload, response, tmp_path / "full")
    rows = {row["Patient_ID"]: row for row in csv.DictReader(io.StringIO(response.decode()))}
    header, *lines = response.splitlines(keepends=True)
    reordered = header + b"".join(reversed(lines))
    replayed = materialize_final_full_data_mice(plan, payload, reordered, tmp_path / "reordered")
    assert materialized["development_input"] == replayed["development_input"]
    assert materialized["fit_ids"] == plan["source_ids"]
    assert materialized["fit_response"]["sha256"] == replayed["fit_response"]["sha256"]
    assert set(rows) == set(materialized["fit_ids"])
    changed = response.replace(b",50\n", b",51\n")
    assert changed != response
    with pytest.raises(ContractError, match="F5_FINAL_MICE_SOURCE_DRIFT"):
        materialize_final_full_data_mice(plan, payload, changed, tmp_path / "wrong-followup")


@pytest.mark.parametrize("workers", [24, 56, 120])
def test_final_a16_task_binds_f4_seta_m20_and_fixed_science(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, workers: int,
) -> None:
    keys = [sha256_bytes(f"raw-patient-{index}".encode()) for index in range(384)]
    centers = ([36] * 24 + [38] * 24) * 8
    events = (([0] * 12 + [1] * 12) * 2) * 8
    source_ids = [f"raw-patient-{index}" for index in range(len(keys))]
    plan = compile_full_data_mice_plan(source_ids, keys, centers, events, family="ELASTIC_NET_COX", workers=workers)
    response = private_response(source_ids, events)
    monkeypatch.setattr("padml.f5.subprocess.run", fake_mice_run)
    search_partitions = materialize_repeat_one_search_partitions(
        plan,
        private_covariates(source_ids, centers),
        response,
        tmp_path,
    )
    payload = tmp_path / "final-full-data.zip"
    execute_final_full_data_mice_view(
        plan,
        compile_final_full_data_mice_task(plan),
        private_covariates(source_ids, centers),
        response,
        payload,
    )
    materialized = materialize_final_full_data_mice(
        plan, payload, response, tmp_path / "final-full-data"
    )

    authority = load_science_authority()
    selector = authority["science"]["f2_model_development"][
        "selector_contract"
    ]
    predictors = predictor_contract(
        Path(__file__).resolve().parents[1] / "padml", authority
    )
    parents = [
        "ALB", "AST_ALT", "Age", "CKD_bin", "Creatinine",
        "HGB", "LYMPH", "MCHC", "NEUT", "RDW_CV",
    ]
    widths = {
        "ALB": 1, "AST_ALT": 1, "Age": 2, "CKD_bin": 2,
        "Creatinine": 1, "HGB": 1, "LYMPH": 1, "MCHC": 1,
        "NEUT": 1, "RDW_CV": 1,
    }
    event_count = sum(events)
    lock = {
        "selected_parents": parents,
        "selected_design": [
            {"parent": parent, "design_df": widths[parent]}
            for parent in parents
        ],
        "common_set_design_df": 12,
        "full_data_event_count": event_count,
        "common_set_epv": event_count / 12,
    }
    final_seta = {
        "kind": "PADML_F5_FINAL_SETA_COMPILATION",
        "status": "COMPILED_AWAITING_F4_FAMILY_LOCK",
        "source": "SIX_LOCALLY_VALIDATED_F2_PRIMARY_SELECTORS",
        "selector_contract_sha256": sha256_bytes(
            canonical_json_bytes(selector)
        ),
        "transform_registry_sha256": predictors["transform_registry_sha256"],
        "lock": lock,
        "lock_sha256": sha256_bytes(canonical_json_bytes(lock)),
        "policy": {
            "forced_parent": "AST_ALT",
            "outer_frequency_minimum": "4/6",
            "direction_minimum_when_one_df": 0.75,
            "common_set_epv_minimum": 15,
            "mrmre_boruta_role": "SENSITIVITY_ONLY_NO_PRIMARY_WRITEBACK",
            "heldout_performance_read_count": 0,
            "grid_rerun": False,
            "scientific_constraints_relaxed": False,
        },
    }
    families = authority["science"]["families"]
    macro = {
        family: {
            "24": {
                "equal_center_ibs": 0.1 if family == "ELASTIC_NET_COX" else 0.2,
                "pooled_absolute_slope_error": 0.1,
                "pooled_absolute_citl": 0.1,
                "equal_center_raw_dca": 0.1,
                "worst_center_ibs": 0.1,
                "pooled_uno_c": 0.7,
            }
        }
        for family in families
    }
    family_decision = select_a15(
        macro, {family: True for family in families}
    )
    family_handoff = f4_handoff_fixture(family_decision)
    task = compile_final_a16_task(
        plan, final_seta, search_partitions, materialized, family_decision,
        family_handoff,
    )
    assert task["family"] == "ELASTIC_NET_COX"
    assert task["selected_parents"] == parents
    assert task["common_set_design_df"] == 12
    assert task["selector"]["fold_count"] == 5
    assert task["selector"]["common_alpha_count"] == 1
    assert task["selector"]["lambda_imputation_ids"] == list(range(1, 21))
    assert task["selector"]["lambda_averaging_permitted"] is False
    assert task["selector"]["seta_writeback_permitted"] is False
    assert task["selector"]["mrmre_boruta_execution_count"] == 0
    assert task["selector"]["split_local_mice_required"] is True
    assert task["selector"]["full_data_mice_scope"] == "FULL_PATH_ONLY"
    assert [row["partition_id"] for row in task["repeat01_search_partitions"]] == [
        f"F5_R01_K{fold:02d}" for fold in range(1, 6)
    ]
    assert str(tmp_path) not in canonical_json_bytes(task).decode()
    assert task["execution_profile"] == {
        "pool_workers": workers,
        "maximum_concurrent_imputations": 20,
        "engine_threads": 1,
        "task_granularity": (
            "ONE_IMPUTATION_MULTI_ALPHA_FIVE_FOLD_PLUS_FULL_PATH"
        ),
        "refill": "DYNAMIC_ON_COMPLETION",
        "nested_pool": False,
    }
    assert task["model_fit_count"] == 0

    _, _, rsf_decision, _, _ = final_refit_compilation_inputs("RSF")
    default_handoff = f4_handoff_fixture(
        rsf_decision, locked_family="ELASTIC_NET_COX"
    )
    default_task = compile_final_a16_task(
        plan, final_seta, search_partitions, materialized, rsf_decision,
        default_handoff,
    )
    assert rsf_decision["selected_family"] == "RSF"
    assert default_task["family"] == "ELASTIC_NET_COX"
    assert default_task["f4_locked_family_handoff_sha256"] == (
        default_handoff["identity_sha256"]
    )

    drifted = copy.deepcopy(final_seta)
    drifted["lock"]["selected_design"][0]["design_df"] = 2
    drifted["lock_sha256"] = sha256_bytes(
        canonical_json_bytes(drifted["lock"])
    )
    with pytest.raises(ContractError, match="F5_A16_SETA_LOCK_INVALID"):
        compile_final_a16_task(
            plan, drifted, search_partitions, materialized, family_decision,
            family_handoff,
        )
    with pytest.raises(ContractError, match="F5_A16_SEARCH_PARTITION_INVALID"):
        compile_final_a16_task(
            plan,
            final_seta,
            [materialized] * 5,
            materialized,
            family_decision,
            family_handoff,
        )

    def alpha_record(alpha: float) -> dict:
        ratios = [10 ** (-4 * index / 149) for index in range(150)]
        parent_df = {
            row["parent"]: row["design_df"]
            for row in task["selected_design"]
        }
        full_paths = []
        path_health = []
        for imputation in range(1, 21):
            bound = 1 + imputation / 10
            coefficients = {
                parent: [
                    (
                        [0.0] * width
                        if parent == "AST_ALT" or index < 10
                        else [0.1] * width
                    )
                    for index in range(150)
                ]
                for parent, width in parent_df.items()
            }
            active = [
                sum(
                    value != 0
                    for parent in task["selected_parents"]
                    if parent != "AST_ALT"
                    for value in coefficients[parent][index]
                )
                for index in range(150)
            ]
            provenance = {
                "schema_version": "1.0.0",
                "kind": "PADML_F2_ELASTIC_LAMBDA_UPPER_BOUND_V1",
                "glmnet_version": "5.0",
                "family": "cox",
                "cox_ties": "breslow",
                "alpha": alpha,
                "standardize": True,
                "penalty_factor_identity_sha256": "a" * 64,
                "pilot_requested_nlambda": 100,
                "pilot_returned_nlambda": 100,
                "pilot_lambda_head": [bound, bound * 0.9, bound * 0.8],
                "resolved_lambda_max": bound,
                "glmnet_big": 9.9e35,
                "sentinel_equivalent": False,
            }
            health = {
                "imputation": imputation,
                "lambda_max": bound,
                "lambda_path_sha256": sha256_bytes(canonical_json_bytes([
                    bound * ratio for ratio in ratios
                ])),
                "lambda_upper_bound": provenance,
                "penalized_design_column_count": 11,
                "penalized_active_count_path": active,
                "penalized_entry_covered": True,
            }
            path_health.append(health)
            coefficient_core = {
                "parent_design_columns": parent_df,
                "parent_coefficients": coefficients,
            }
            full_paths.append({
                **health,
                "event_count": task["full_data_event_count"],
                **coefficient_core,
                "coefficient_path_sha256": sha256_bytes(
                    canonical_json_bytes(coefficient_core)
                ),
            })
        shifts = [-4.0, -2.0, 0.0, 2.0, 4.0]
        partitions = []
        for fold, shift in enumerate(shifts, start=1):
            losses = []
            for imputation in range(1, 21):
                best = 8 if imputation % 2 else 16
                losses.append([
                    float((index - best) ** 2 + abs(alpha - 0.225) + shift)
                    for index in range(150)
                ])
            partitions.append({
                "repeat": 1,
                "inner_fold": fold,
                "validation_n": 10,
                "mi_losses": losses,
                "mi_lambda_path_health": copy.deepcopy(path_health),
            })
        return {
            "alpha": alpha,
            "partition_losses": partitions,
            "full_paths": full_paths,
        }

    coarse_alphas = [float(value) for value in task["selector"]["alpha_grid"]["coarse"]]
    coarse_records = [alpha_record(alpha) for alpha in coarse_alphas]
    fine_alphas = [round(0.1 + index * 0.025, 3) for index in range(9)]
    coarse_by_alpha = dict(zip(coarse_alphas, coarse_records, strict=True))
    fine_records = [
        coarse_by_alpha.get(alpha, alpha_record(alpha)) for alpha in fine_alphas
    ]
    alpha_summary = _summarize_final_a16_alpha(task, coarse_by_alpha[0.2])
    assert alpha_summary["imputation_decisions"][0]["fold_se_path"][8] == (
        pytest.approx(math.sqrt(2))
    )
    locked = lock_final_a16_parameters(task, coarse_records, fine_records)
    ratios = [10 ** (-4 * index / 149) for index in range(150)]
    assert locked["common_alpha"] == 0.225
    assert locked["ratio_by_imputation"] == [
        ratios[7] if imputation % 2 else ratios[15]
        for imputation in range(1, 21)
    ]
    assert locked["active_design_df_by_imputation"] == [
        1 if imputation % 2 else 12 for imputation in range(1, 21)
    ]
    assert locked["coarse_selected_alpha"] == 0.2
    assert locked["distinct_alpha_count"] == 14
    assert locked["reused_overlap_alpha_count"] == 2
    assert locked["selector_process_task_count"] == 40
    assert locked["selector_path_fit_count"] == 1680
    assert locked["selector_pilot_fit_count"] == 1680
    assert locked["seta_writeback"] == "FORBIDDEN"
    assert locked["mrmre_boruta_execution_count"] == 0
    assert locked["final_model_fit_count"] == 0
    executed_archive = _executed_a16_archive(
        task, coarse_records, fine_records, locked
    )
    sealed = seal_final_parameter_lock(
        materialized,
        final_seta,
        family_decision,
        family_handoff,
        executed_archive,
    )
    assert sealed["selected_spec"]["source_mode"] == (
        "EXECUTED_A16_PER_IMPUTATION_LAMBDA"
    )
    assert sealed["selected_spec"]["selected_candidate_id"] == (
        "ELASTIC_NET_COX_A16_FULL_DATA"
    )

    invalid = alpha_record(0.2)
    invalid["partition_losses"][0]["mi_losses"][0][0] = math.nan
    with pytest.raises(ContractError, match="F5_A16_FOLD_PATH_INVALID"):
        _summarize_final_a16_alpha(task, invalid)


def _full_test_transform_recipe(predictors: dict) -> dict:
    representations = []
    for row in predictors["transform_registry"]["rows"]:
        if row["parent"] == "eGFR_calc":
            continue
        representation = row["representation"]
        contract = predictors["representation_contract"][representation]
        representations.append({
            "parent": row["parent"],
            "canonical_unit": row["canonical_unit"],
            "representation": representation,
            "design_df": contract["design_df"],
            "design_columns": [
                row["parent"] + suffix
                for suffix in contract["column_suffixes"]
            ],
            "parameters": {
                "IDENTITY": {"identity": True},
                "LOG1P": {"canonical_unit_scale": 1},
                "NATURAL_SPLINE_K3": {
                    "boundary_knots": [0.0, 20.0],
                    "interior_knots": [10.0],
                    "quantile_type": 7,
                },
            }[representation],
        })
    recipe = {
        "recipe_schema_version": "1.0.0",
        "kind": "PADML_F2_TRANSFORM_RECIPE",
        "partition_id": "F5_TEST_FULL_DATA_RECIPE",
        "transform_registry_sha256": predictors["transform_registry_sha256"],
        "analysis_view_sha256": sha256_bytes(b"f5 test analysis view"),
        "analysis_ids_sha256": sha256_bytes(b"f5 test analysis ids"),
        "fit_ids_sha256": sha256_bytes(b"f5 test analysis ids"),
        "training_member_set_sha256": sha256_bytes(b"f5 test member set"),
        "representations": representations,
        "ordered_parent_column_map": [
            {"parent": row["parent"], "columns": row["design_columns"]}
            for row in representations
        ],
    }
    recipe["recipe_sha256"] = sha256_bytes(canonical_json_bytes(recipe))
    return recipe


def _executed_a16_archive(
    task: dict,
    coarse_records: list[dict],
    fine_records: list[dict],
    reduced: dict,
) -> dict:
    predictors = predictor_contract(Path(__file__).resolve().parents[1] / "padml")
    partition_ids = [
        *[row["partition_id"] for row in task["repeat01_search_partitions"]],
        "F5_FINAL_FULL_DATA",
    ]
    recipes = []
    for partition_id in partition_ids:
        recipe = _full_test_transform_recipe(predictors)
        recipe["partition_id"] = partition_id
        recipe["recipe_sha256"] = sha256_bytes(canonical_json_bytes({
            key: value for key, value in recipe.items()
            if key != "recipe_sha256"
        }))
        recipes.append(recipe)
    recipe_set_body = {
        "recipe_schema_version": "1.0.0",
        "kind": "PADML_F2_TRANSFORM_RECIPE_SET",
        "recipe_count": 6,
        "recipes": recipes,
    }
    recipe_set = {
        **recipe_set_body,
        "recipe_set_sha256": sha256_bytes(canonical_json_bytes(recipe_set_body)),
    }
    repo = Path(__file__).resolve().parents[1]
    source_members = {
        "padml/f2_kernel.py": sha256_file(repo / "padml/f2_kernel.py"),
        "padml/f5.py": sha256_file(repo / "padml/f5.py"),
        "padml/kernels/f2_model_development.R": sha256_file(
            repo / "padml/kernels/f2_model_development.R"
        ),
    }
    alphas = sorted({
        *[float(row["alpha"]) for row in coarse_records],
        *[float(row["alpha"]) for row in fine_records],
    })
    evidence = {
        "producer": "SHARED_F2_F5_ELASTIC_PATH_KERNEL_V1",
        "execution_scope": "F5_FULL_DEVELOPMENT_A16",
        "task_sha256": task["task_sha256"],
        "registered_inputs_identity_sha256": "a" * 64,
        "recipe_set_sha256": recipe_set["recipe_set_sha256"],
        "source_members": source_members,
        "source_members_sha256": sha256_bytes(canonical_json_bytes(source_members)),
        "coarse_checkpoint_sha256": "b" * 64,
        "coarse_checkpoint_size_bytes": 1,
        "executed_alpha_order": alphas,
        "executed_alpha_count": len(alphas),
        "path_fit_count": len(alphas) * 20 * 6,
        "selector_seed_rule": "200000_PLUS_IMPUTATION",
        "selector_seed_values": [200_000 + value for value in range(1, 21)],
        "heldout_or_ooc_read_count": 0,
        "final_model_fit_count": 0,
    }
    lock_body = {
        **{
            key: value for key, value in reduced.items()
            if key != "identity_sha256"
        },
        "kind": "PADML_F5_A16_EXECUTED_PARAMETER_LOCK",
        "execution_evidence": evidence,
    }
    lock = {
        **lock_body,
        "identity_sha256": sha256_bytes(canonical_json_bytes(lock_body)),
    }
    archive_body = {
        "schema_version": "1.0.0",
        "kind": "PADML_F5_A16_EXECUTION_ARCHIVE",
        "status": "PASS",
        "task": task,
        "recipe_set": recipe_set,
        "coarse_records": coarse_records,
        "fine_records": fine_records,
        "parameter_lock": lock,
    }
    return {
        **archive_body,
        "identity_sha256": sha256_bytes(canonical_json_bytes(archive_body)),
    }


def _test_final_design_recipe(family: str, selected: list[str]) -> dict:
    predictors = predictor_contract(
        Path(__file__).resolve().parents[1] / "padml"
    )
    transformed = family in {
        "COX_PH", "ELASTIC_NET_COX", "FPM_TVC_SET_A"
    }
    return {
        "schema_version": "1.0.0",
        "kind": "PADML_F5_FINAL_DESIGN_RECIPE_V1",
        "family": family,
        "selected_parents": selected,
        "preprocessing_mode": (
            "F2_LOCKED_TRANSFORM_RECIPE"
            if transformed else "F2_RAW_CANONICAL_AUTHORITY_LEVELS"
        ),
        "predictor_contract_sha256": sha256_bytes(
            canonical_json_bytes(predictors)
        ),
        "predictor_rows": [
            row for row in predictors["variables"]
            if row["name"] in selected
        ],
        "transform_recipe": (
            _full_test_transform_recipe(predictors) if transformed else None
        ),
        "coxtime_standardization": (
            "FIT_IMPUTATION_Z_SCORE" if family == "COXTIME_SET_A" else None
        ),
    }


def final_refit_compilation_inputs(
    family: str,
) -> tuple[dict, dict, dict, dict, dict]:
    families = load_science_authority()["science"]["families"]
    macro = {
        candidate: {
            "24": {
                "equal_center_ibs": 0.1 if candidate == family else 0.2,
                "pooled_absolute_slope_error": 0.1,
                "pooled_absolute_citl": 0.1,
                "equal_center_raw_dca": 0.1,
                "worst_center_ibs": 0.1,
                "pooled_uno_c": 0.7,
            }
        }
        for candidate in families
    }
    family_decision = select_a15(
        macro, {candidate: True for candidate in families}
    )
    selected = ["AST_ALT"]
    seta_lock = {
        "selected_parents": selected,
        "selected_design": [{"parent": "AST_ALT", "design_df": 1}],
        "common_set_design_df": 1,
        "full_data_event_count": 30,
        "common_set_epv": 30.0,
    }
    final_seta = {
        "kind": "PADML_F5_FINAL_SETA_COMPILATION",
        "lock": seta_lock,
        "lock_sha256": sha256_bytes(canonical_json_bytes(seta_lock)),
        "policy": {
            "common_set_epv_minimum": 15,
            "mrmre_boruta_role": "SENSITIVITY_ONLY_NO_PRIMARY_WRITEBACK",
            "grid_rerun": False,
            "scientific_constraints_relaxed": False,
        },
    }
    source_ids = [f"patient-{index:02d}" for index in range(30)]
    members = [
        {
            "name": f"imp{imputation:02d}.csv",
            "sha256": sha256_bytes(f"imputation-{imputation}".encode()),
            "size_bytes": 100 + imputation,
        }
        for imputation in range(1, 21)
    ]
    final_mice = {
        "schema_version": "1.0.0",
        "kind": "FINAL_FULL_DATA",
        "partition_id": "F5_FINAL_FULL_DATA",
        "fit_ids": source_ids,
        "covariates": {
            "kind": "PADML_F5_FINAL_MICE_BINDING",
            "status": "PASS",
            "members": members,
            "data_identity": sha256_bytes(canonical_json_bytes(members)),
        },
        "fit_covariate_members": members,
        "fit_response": {
            "sha256": sha256_bytes(b"final response"),
            "row_count": len(source_ids),
            "row_ids_sha256": sha256_bytes(canonical_json_bytes(source_ids)),
            "event_count": 30,
        },
        "mice_manifest_sha256": sha256_bytes(b"final mice manifest"),
        "model_fit_count": 0,
    }
    selected_spec = {"family": family, "selected_parents": selected}
    if family == "RSF":
        locked_spec = {
            "family": "RSF",
            "parameters": {
                "num.trees": 1000,
                "mtry_fraction": "0.50",
                "min.node.size": 15,
                "max.depth": "UNLIMITED",
                "sample.fraction": 0.632,
                "splitrule": "logrank",
            },
        }
    else:
        locked_spec = {"family": "COX_PH", "ties": "breslow"}
    components = [
        {
            "imputation": imputation,
            "parameters": copy.deepcopy(locked_spec),
            "parameters_sha256": sha256_bytes(
                canonical_json_bytes(locked_spec)
            ),
            "source_evidence_sha256": sha256_bytes(
                f"search-evidence-{imputation}".encode()
            ),
        }
        for imputation in range(1, 21)
    ]
    parameter_lock = {
        "schema_version": "1.0.0",
        "kind": "PADML_F5_FINAL_PARAMETER_LOCK",
        "status": "PASS",
        "phase": "FINAL_PARAMETER_LOCK",
        "family": family,
        "family_decision_sha256": sha256_bytes(
            canonical_json_bytes(family_decision)
        ),
        "f4_locked_family_handoff_sha256": f4_handoff_fixture(
            family_decision
        )["identity_sha256"],
        "final_seta_lock_sha256": final_seta["lock_sha256"],
        "final_mice_manifest_sha256": final_mice["mice_manifest_sha256"],
        "source_search_identity_sha256": sha256_bytes(b"validated search"),
        "selected_spec": selected_spec,
        "selected_spec_sha256": sha256_bytes(
            canonical_json_bytes(selected_spec)
        ),
        "component_parameters": components,
        "grid_rerun": False,
        "outer_parameter_reuse": False,
        "heldout_or_ooc_read_count": 0,
        "scientific_constraints_relaxed": False,
        "final_model_fit_count": 0,
    }
    parameter_lock["identity_sha256"] = sha256_bytes(
        canonical_json_bytes(parameter_lock)
    )
    recipe_value = _test_final_design_recipe(family, selected)
    final_recipe = {
        "schema_version": "1.0.0",
        "kind": "PADML_F5_FINAL_RECIPE",
        "status": "PASS",
        "family": family,
        "selected_parents": selected,
        "source_mice_data_identity": final_mice["covariates"]["data_identity"],
        "response_read_count": 0,
        "recipe": recipe_value,
        "recipe_sha256": sha256_bytes(canonical_json_bytes(recipe_value)),
    }
    final_recipe["identity_sha256"] = sha256_bytes(
        canonical_json_bytes(final_recipe)
    )
    return final_mice, final_seta, family_decision, parameter_lock, final_recipe


def f4_handoff_fixture(
    decision: dict, *, locked_family: str | None = None
) -> dict:
    locked = decision["selected_family"] if locked_family is None else locked_family
    rule = (
        "A15_GLOBAL_SELECTION"
        if locked == decision["selected_family"]
        else "MATRIX_LOCO_UNSTABLE_ELASTIC_NET_DEFAULT"
    )
    assert rule == "A15_GLOBAL_SELECTION" or locked == "ELASTIC_NET_COX"
    body = {
        "schema_version": "2.0.0",
        "kind": "PADML_F4_REVIEW_ACCEPTED_LOCKED_FAMILY_HANDOFF_V2",
        "accepted_f4_result_sha256": sha256_bytes(b"accepted f4 result"),
        "review_acceptance_sha256": sha256_bytes(b"accepted f4 review"),
        "a15_family_decision_sha256": sha256_bytes(canonical_json_bytes(decision)),
        "a15_decision_trace_sha256": decision["decision_trace_sha256"],
        "final_family_lock_sha256": sha256_bytes(b"final family lock"),
        "lock_rule": rule,
        "locked_family": locked,
        "projection_fields": ["locked_family"],
    }
    return {**body, "identity_sha256": sha256_bytes(canonical_json_bytes(body))}


@pytest.mark.parametrize(
    ("family", "expected_seed"),
    [("RSF", 300_000), ("COX_PH", None)],
)
@pytest.mark.parametrize("workers", [24, 56, 120])
def test_compile_final_refit_tasks_binds_twenty_locked_components(
    family: str, expected_seed: int | None, workers
) -> None:
    inputs = final_refit_compilation_inputs(family)
    plan = compile_final_refit_tasks(*inputs, f4_handoff_fixture(inputs[2]), workers=workers)
    baseline = compile_final_refit_tasks(*inputs, f4_handoff_fixture(inputs[2]), workers=24)
    assert plan["tasks"] == baseline["tasks"]
    assert _validate_final_refit_plan(plan, inputs[2]) == _validate_final_refit_plan(baseline, inputs[2])

    assert plan["family"] == family
    assert plan["task_count"] == 20
    assert len({task["task_sha256"] for task in plan["tasks"]}) == 20
    assert [task["imputation"] for task in plan["tasks"]] == list(range(1, 21))
    assert {task["model_seed"] for task in plan["tasks"]} == {expected_seed}
    assert all(task["search_fit_count"] == 0 for task in plan["tasks"])
    assert all(task["stopping_fit_count"] == 0 for task in plan["tasks"])
    assert all(task["final_model_fit_count"] == 1 for task in plan["tasks"])
    assert plan["execution_profile"] == {
        "pool_workers": workers,
        "maximum_concurrent_tasks": 20,
        "engine_threads": 1,
        "task_granularity": "ONE_LOCKED_IMPUTATION_FINAL_REFIT",
        "refill": "DYNAMIC_ON_COMPLETION",
        "nested_pool": False,
    }
    assert plan["search_fit_count"] == 0
    assert plan["family_reselection"] is False
    assert plan["scientific_constraints_relaxed"] is False
    assert plan["total_final_model_fit_count"] == 20

    drifted = copy.deepcopy(inputs[3])
    drifted["component_parameters"][0]["parameters"]["family"] = "GBM_COX"
    drifted["identity_sha256"] = sha256_bytes(
        canonical_json_bytes({
            key: value for key, value in drifted.items()
            if key != "identity_sha256"
        })
    )
    with pytest.raises(ContractError, match="F5_FINAL_PARAMETER_COMPONENTS_INVALID"):
        compile_final_refit_tasks(
            inputs[0], inputs[1], inputs[2], drifted, inputs[4],
            f4_handoff_fixture(inputs[2]), workers=24,
        )


def test_compile_final_refit_tasks_rejects_epv_drift() -> None:
    final_mice, final_seta, decision, parameter_lock, final_recipe = (
        final_refit_compilation_inputs("RSF")
    )
    final_seta["lock"]["common_set_epv"] = 14.99
    final_seta["lock_sha256"] = sha256_bytes(
        canonical_json_bytes(final_seta["lock"])
    )
    parameter_lock["final_seta_lock_sha256"] = final_seta["lock_sha256"]
    parameter_lock["identity_sha256"] = sha256_bytes(
        canonical_json_bytes({
            key: value for key, value in parameter_lock.items()
            if key != "identity_sha256"
        })
    )
    with pytest.raises(ContractError, match="F5_FINAL_REFIT_SETA_INVALID"):
        compile_final_refit_tasks(
            final_mice, final_seta, decision, parameter_lock, final_recipe,
            f4_handoff_fixture(decision), workers=24,
        )


def test_final_aggregate_reconstructs_lock_and_rejects_rehashed_plan(
    monkeypatch,
) -> None:
    final_mice, final_seta, decision, _, final_recipe = (
        final_refit_compilation_inputs("COX_PH")
    )
    handoff = f4_handoff_fixture(decision)
    parameter_lock = seal_final_parameter_lock(
        final_mice, final_seta, decision, handoff, None
    )
    plan = compile_final_refit_tasks(
        final_mice, final_seta, decision, parameter_lock, final_recipe,
        handoff, workers=24,
    )
    monkeypatch.setattr(
        "padml.f5.compile_final_seta",
        lambda selector_results, event_count: copy.deepcopy(final_seta),
    )
    index = {
        "kind": "PADML_F5_FINAL_AGGREGATE_INPUT_V2",
        "family_decision": decision,
        "final_refit_plan": plan,
        "centers": ["36", "38", "39", "48", "52", "54"] * 5,
        "final_family": "COX_PH",
        "final_seta_selector_results": [{"source": "retained"}] * 6,
        "final_seta": final_seta,
        "final_mice": final_mice,
        "final_parameter_lock": parameter_lock,
        "final_recipe": final_recipe,
        "parameter_source": None,
    }
    assert len(_validate_final_aggregate_lineage(index)) == 20

    drifted = copy.deepcopy(index)
    task = drifted["final_refit_plan"]["tasks"][0]
    task["parameter_source_evidence_sha256"] = "f" * 64
    task["task_sha256"] = sha256_bytes(canonical_json_bytes({
        key: value for key, value in task.items() if key != "task_sha256"
    }))
    drifted["final_refit_plan"]["plan_sha256"] = sha256_bytes(
        canonical_json_bytes({
            key: value
            for key, value in drifted["final_refit_plan"].items()
            if key != "plan_sha256"
        })
    )
    with pytest.raises(
        ContractError, match="F5_FINAL_AGGREGATE_REFIT_PLAN_REPLAY_MISMATCH"
    ):
        _validate_final_aggregate_lineage(drifted)


def test_final_aggregate_entry_rejects_missing_lineage_before_results(
    tmp_path: Path,
) -> None:
    index_path = (tmp_path / "index.json").resolve()
    response_path = (tmp_path / "response.csv").resolve()
    result_root = (tmp_path / "results").resolve()
    input_root = (tmp_path / "inputs").resolve()
    result_root.mkdir()
    input_root.mkdir()
    index_path.write_bytes(canonical_json_bytes({
        "kind": "PADML_F5_FINAL_AGGREGATE_INPUT_V2",
        "family_decision": {},
        "final_refit_plan": {},
        "centers": [],
        "final_family": "COX_PH",
    }))
    response_path.write_bytes(
        b"Patient_ID,All_Cause_Death,Death_Followup_months\n"
    )
    with pytest.raises(ContractError, match="F5_FINAL_AGGREGATE_INPUT_INVALID"):
        execute_final_aggregate(
            index_path,
            response_path,
            result_root,
            (tmp_path / "non-ph.zip").resolve(),
            (tmp_path / "result.zip").resolve(),
            input_root=input_root,
            mice_plan_path=tmp_path / "mice-plan.json",
            final_mice_path=tmp_path / "final-mice.zip",
        )


@pytest.mark.parametrize("center_change", [None, "missing_training_only", "unknown"])
def test_final_aggregate_requires_full_development_center_domain(
    tmp_path: Path, monkeypatch, center_change,
) -> None:
    centers = ["36", "38", "39", "48", "52", "54", "55"]
    if center_change is not None:
        centers[-1] = "36" if center_change == "missing_training_only" else "999"
    response = b"Patient_ID,All_Cause_Death,Death_Followup_months\n"
    response_sha = sha256_bytes(response)
    index = {"centers": centers,
             "final_mice": {"fit_response": {"sha256": response_sha}}}
    monkeypatch.setattr("padml.f5._consume_final_parameter_source", lambda *args, **kwargs: {
        1: {"response_sha256": response_sha, "row_count": len(centers)},
    })
    index_path, response_path = tmp_path / "index.json", tmp_path / "response.csv"
    index_path.write_bytes(canonical_json_bytes(index))
    response_path.write_bytes(response)
    for name in ("inputs", "results"):
        (tmp_path / name).mkdir()
    # A valid population reaches the next native input boundary, not acceptance.
    expected = ("F5_NON_PH_ACTION_PATH_INVALID" if center_change is None
                else "F5_FINAL_AGGREGATE_RESPONSE_DRIFT")
    with pytest.raises(ContractError, match=expected):
        execute_final_aggregate(
            index_path, response_path, tmp_path / "results",
            tmp_path / "missing-non-ph.zip", tmp_path / "aggregate.zip",
            input_root=tmp_path / "inputs",
            mice_plan_path=tmp_path / "mice-plan.json",
            final_mice_path=tmp_path / "final-mice.zip",
        )


def test_final_aggregate_cli_rejects_incomplete_v2_lineage(
    tmp_path: Path,
) -> None:
    index_path = (tmp_path / "index.json").resolve()
    response_path = (tmp_path / "response.csv").resolve()
    result_root = (tmp_path / "results").resolve()
    input_root = (tmp_path / "inputs").resolve()
    result_root.mkdir()
    input_root.mkdir()
    index_path.write_bytes(canonical_json_bytes({
        "kind": "PADML_F5_FINAL_AGGREGATE_INPUT_V2",
        "family_decision": {},
        "final_refit_plan": {},
        "centers": [],
        "final_family": "COX_PH",
    }))
    response_path.write_bytes(
        b"Patient_ID,All_Cause_Death,Death_Followup_months\n"
    )
    completed = subprocess.run(
        [
            sys.executable,
            "-m",
            "padml.f5",
            "final-aggregate",
            str(index_path),
            str(response_path),
            str(result_root),
            str((tmp_path / "non-ph.zip").resolve()),
            str((tmp_path / "result.zip").resolve()),
            "--input-root",
            str(input_root),
            "--mice-plan", str(tmp_path / "mice-plan.json"),
            "--final-mice", str(tmp_path / "final-mice.zip"),
        ],
        cwd=Path(__file__).resolve().parents[1],
        capture_output=True,
        text=True,
        check=False,
    )
    assert completed.returncode != 0
    assert "F5_FINAL_AGGREGATE_INPUT_INVALID" in completed.stderr
    assert not (tmp_path / "result.zip").exists()


@pytest.mark.parametrize("action", ["compile", "batch", "single"])
def test_full0_uses_existing_f5_cli_producer_and_workers(tmp_path, monkeypatch, capsys, action):
    """CLI wiring only; never execute a model, materializer or native reader."""
    source = tmp_path / "full-development.json"
    target = tmp_path / "results"
    policy_path = tmp_path / "resource-policy.json"
    policy = {"UNFITTED_CLI_POLICY": True}
    policy_path.write_bytes(canonical_json_bytes(policy))
    compiled_path = tmp_path / "original-compile-record.json"
    compiled = {"UNFITTED_ORIGINAL_COMPILE_RECORD": True}
    compiled_path.write_bytes(canonical_json_bytes(compiled))
    observed = []
    def boundary(*args, **kwargs):
        observed.append((args, kwargs))
        return {"status": "UNFITTED_CLI_ONLY"}
    if action == "compile":
        monkeypatch.setattr(f5_module, "compile_final_refit_bundles", boundary)
        argv = ["padml.f5", "compile-final-refit", "--full-development", str(source),
                "--target", str(target), "--workers", "1"]
    else:
        input_root = tmp_path / "inputs"
        input_root.mkdir()
        if action == "batch":
            function, input_path = "execute_final_refit_batch", input_root
        else:
            function, input_path = "execute_final_refit_bundle", input_root / "bound/M01.zip"
            input_path.parent.mkdir()
            input_path.write_bytes(b"UNFITTED_NOT_OPENED")
        monkeypatch.setattr(f5_module, function, boundary)
        argv = ["padml.f5", "final-refit", str(input_path), str(target),
                "--resource-policy", str(policy_path), "--workers", "1",
                "--compiled-input-record", str(compiled_path)]
    monkeypatch.setattr(sys, "argv", argv)
    f5_module.main()
    args, kwargs = observed.pop()
    assert not observed and kwargs["workers"] == 1 and not target.exists()
    if action == "compile":
        assert capsys.readouterr().out.encode() == canonical_json_bytes({"status": "UNFITTED_CLI_ONLY"})
        assert args == (None, None, None, None, None, target)
        assert kwargs["full_development_path"] == source and kwargs["lineage_path"] is None
    else:
        assert args == (input_path, target) and kwargs["resource_policy"] == policy
        assert kwargs["compiled_input_record"] == compiled
        if action == "single":
            assert kwargs["lineage_path"] == input_root / "lineage.json"


def test_final_aggregate_native_mice_reuses_existing_objects(
    tmp_path: Path, monkeypatch,
) -> None:
    """Integration replay only: never regenerate a MICE or model fit fixture."""
    fixture_name = os.environ.get("PADML_F5_NATIVE_MICE_FIXTURE")
    if not fixture_name:
        pytest.skip("requires a previously computed native synthetic M20 archive")
    fixture = Path(fixture_name).resolve(strict=True)
    payload, plan_path = fixture / "native-mice.zip", fixture / "plan.json"
    entries = read_safe_zip(payload)
    plan = strict_json_bytes(plan_path.read_bytes())
    response = entries["inputs/response.csv"]
    original_run = subprocess.run
    native_calls = []

    def replay_only(arguments, *args, **kwargs):
        script = next((Path(str(value)).name for value in arguments if str(value).endswith(".R")), None)
        if script == "f5_mice.R":
            assert arguments[3] == "REPLAY", "no additional MICE fits authorized"
            native_calls.append("MICE_REPLAY")
        elif script == "f5_final_refit.R":
            spec = strict_json_bytes(Path(arguments[-1]).read_bytes())
            assert spec["action"] == "COMPILE_FINAL_RECIPE", "no model fits authorized"
            native_calls.append("COMPILE_FINAL_RECIPE")
        else:
            assert script == "f5_resampling.R"
            native_calls.append("SPLIT_REPLAY")
        return original_run(arguments, *args, **kwargs)

    monkeypatch.setattr("padml.f5.subprocess.run", replay_only)
    final_mice = materialize_final_full_data_mice(plan, payload, response, tmp_path / "materialized")
    for imputation in range(1, 21):
        original = list(csv.reader(io.StringIO(entries[f"imputations/imp{imputation:02d}.csv"].decode())))
        with (Path(final_mice["covariates"]["input_dir"]) / f"imp{imputation:02d}.csv").open(newline="") as handle:
            assert list(csv.reader(handle)) == original
    assert final_mice["fit_covariate_members"] == final_mice["covariates"]["members"]
    selectors = [selector_result_fixture(fold, set()) for fold in range(1, 7)]
    seta = compile_final_seta(selectors, final_mice["fit_response"]["event_count"])
    decision = final_refit_compilation_inputs("COX_PH")[2]
    handoff = f4_handoff_fixture(decision)
    recipe = compile_final_recipe(final_mice, seta, decision, handoff, tmp_path)
    parameter_lock = seal_final_parameter_lock(final_mice, seta, decision, handoff, None)
    refit_plan = compile_final_refit_tasks(final_mice, seta, decision, parameter_lock, recipe, handoff, workers=24)
    centers = [row["Center"] for row in csv.DictReader(io.StringIO(entries["inputs/covariates.csv"].decode()))]
    index = {
        "kind": "PADML_F5_FINAL_AGGREGATE_INPUT_V2", "family_decision": decision,
        "final_refit_plan": refit_plan, "centers": centers, "final_family": "COX_PH",
        "final_seta_selector_results": selectors, "final_seta": seta,
        "final_mice": final_mice, "final_parameter_lock": parameter_lock,
        "final_recipe": recipe, "parameter_source": None,
    }
    # The terminal consumer must not require the producer's staging directory.
    index["final_mice"]["covariates"]["input_dir"] = "/producer-staging-not-mounted/imputations"
    index["final_mice"]["fit_response"]["path"] = "/producer-staging-not-mounted/response.csv"
    tasks = _validate_final_aggregate_lineage(index)
    assert [tasks[imputation]["input_member"] for imputation in range(1, 21)] == final_mice["covariates"]["members"]
    records = _validate_final_mice_archive(index, plan_path, payload, response, tmp_path)
    assert records == [
        {"member": member, "sha256": sha256_file(path), "size_bytes": path.stat().st_size}
        for member, path in (("mice-plan.json", plan_path), ("final-mice.zip", payload))
    ]
    assert not list(tmp_path.glob(".f5-final-mice-replay-*"))
    negatives = []
    drifted = copy.deepcopy(index)
    drifted["final_mice"]["covariates"]["members"][0]["sha256"] = "f" * 64
    drifted["final_mice"]["fit_covariate_members"] = copy.deepcopy(drifted["final_mice"]["covariates"]["members"])
    drifted["final_mice"]["covariates"]["data_identity"] = sha256_bytes(canonical_json_bytes(drifted["final_mice"]["covariates"]["members"]))
    with pytest.raises(ContractError, match="F5_FINAL_MICE_LINEAGE_REPLAY_MISMATCH"):
        _validate_final_mice_archive(drifted, plan_path, payload, response, tmp_path)
    negatives.append("REHASHED_LINEAGE_MEMBER_REJECTED")
    drifted = copy.deepcopy(index)
    other = next(i for i, center in enumerate(centers) if center != centers[0])
    drifted["centers"][0], drifted["centers"][other] = drifted["centers"][other], drifted["centers"][0]
    with pytest.raises(ContractError, match="F5_FINAL_MICE_PLAN_REPLAY_MISMATCH"):
        _validate_final_mice_archive(drifted, plan_path, payload, response, tmp_path)
    negatives.append("PATIENT_CENTER_SWAP_REJECTED")
    altered = dict(entries)
    altered["native/imp01.rds"] = b"NOT AN R NATIVE OBJECT"
    manifest = strict_json_bytes(altered["manifest.json"])
    manifest["members"]["native/imp01.rds"] = {"sha256": sha256_bytes(altered["native/imp01.rds"]), "size_bytes": len(altered["native/imp01.rds"])}
    altered["manifest.json"] = canonical_json_bytes(manifest)
    forged = tmp_path / "forged.zip"
    write_deterministic_zip(forged, altered)
    with pytest.raises(ContractError, match="F5_MICE_NATIVE_REPLAY_FAILED"):
        _validate_final_mice_archive(index, plan_path, forged, response, tmp_path)
    negatives.append("REHASHED_FAKE_NATIVE_OBJECT_REJECTED")
    failures = list(tmp_path.glob(".f5-final-mice-replay-*"))
    assert len(failures) == 2
    assert any(list(root.rglob("stderr.txt")) for root in failures)

    index_path, response_path = tmp_path / "index.json", tmp_path / "response.csv"
    index_path.write_bytes(canonical_json_bytes(index))
    response_path.write_bytes(response)
    non_ph_path = tmp_path / "non-ph.zip"
    non_ph_path.write_bytes(b"unopened: execution stops at absent native model results")
    for name in ("inputs", "results"):
        (tmp_path / name).mkdir()
    reached = []
    def no_uncomputed_models(*args, **kwargs):
        reached.append("NATIVE_MICE_VALIDATED_BEFORE_MODEL_COLLECTION")
        raise RuntimeError("NO_SYNTHETIC_MODEL_FITS_AUTHORIZED")
    monkeypatch.setattr("padml.f5.collect_final_refit_results", no_uncomputed_models)
    with pytest.raises(RuntimeError, match="NO_SYNTHETIC_MODEL_FITS_AUTHORIZED"):
        execute_final_aggregate(index_path, response_path, tmp_path / "results", non_ph_path,
                                tmp_path / "aggregate.zip", input_root=tmp_path / "inputs",
                                mice_plan_path=plan_path, final_mice_path=payload)
    assert reached == ["NATIVE_MICE_VALIDATED_BEFORE_MODEL_COLLECTION"]
    assert not (tmp_path / "aggregate.zip").exists()
    (tmp_path / "verification.json").write_bytes(canonical_json_bytes({
        "status": "PASS", "scope": "NONFORMAL_NATIVE_MICE_TERMINAL_CONSUMER",
        "mice_fit_count": 0, "model_fit_count": 0, "artifacts": records,
        "native_calls": native_calls, "negative_tests": negatives,
        "terminal_boundary": reached[0], "stage_acceptance": False,
    }))


def test_final_action_ledger_has_exact_order_and_blocks_unverified_actions() -> None:
    index = {"final_family": "RSF", "final_seta": {
        "lock": {"selected_parents": ["AST_ALT", "Creatinine"]},
    }, "parameter_source": {"identity_sha256": "e" * 64}}
    # Ledger projection only, not a claim that this synthetic Q was replayed.
    q_artifact = {"member": "final-search.zip", "identity_sha256": "e" * 64,
                  "sha256": "d" * 64, "size_bytes": 1}
    diagnostic = {"status": "COMPUTED"}
    non_ph = {"status": "NOT_APPLICABLE"}
    refits = [{"imputation": value} for value in range(1, 21)]
    missing = _compile_final_action_ledger(
        index,
        diagnostic,
        non_ph,
        {},
        [{"action": "NON_PH", "archive_sha256": "0" * 64}],
        refits,
        q_artifact,
    )
    assert missing["action_order"] == [
        "FINAL_SEARCH", "FINAL_PARAMETER_LOCK", "FINAL_REFIT", "A12",
        "A19", "A04", "C10", "NON_PH", "FINAL_AGGREGATE",
    ]
    assert [row["action"] for row in missing["actions"]] == missing[
        "action_order"
    ]
    assert missing["evidence_completeness"] == "BLOCKED"
    assert missing["deployment_eligibility"] == "BLOCKED_MISSING_A04"
    assert missing["review_ready"] is False

    actions = {
        action: {
            "status": "REDUCED_DECLARED_EVIDENCE",
            "execution_evidence_status": "NOT_VERIFIED_REFERENCES_ONLY",
            "blocking_for_production": True,
            # The original ledger consumes these producer fields even for
            # unverified evidence. This fixture never claims a native run.
            **(
                {"statistical_status": "UNFITTED_LEDGER_PROJECTION_ONLY",
                 "outer_model_fit_execution_count": 0, "search_execution_totals": {}}
                if action == "A12" else {}
            ),
            **(
                {"any_warning": True, "statistical_status": "ESTIMABLE",
                 "sd_estimable_split_count": 15, "split_count": 15}
                if action == "A19" else {}
            ),
            **(
                {"deployment_gate": {
                    "status": "PASS", "assessed_centers": ["36"]
                }, "application_evidence_status": "UNFITTED_LEDGER_PROJECTION_ONLY",
                 "mice_chain_execution_count": 0, "unaudited_centers": ["38", "39", "48", "52", "54"],
                 "p2c2t": {"status": "UNFITTED_LEDGER_PROJECTION_ONLY"},
                 "temporal": {"status": "NOT_APPLICABLE"}, "unverified_authority_sources": ["UNFITTED_A04"]}
                if action == "A04" else {}
            ),
            **(
                {"statistical_status": "UNFITTED_LEDGER_PROJECTION_ONLY", "fit_execution_count": 0}
                if action == "C10" else {}
            ),
        }
        for action in ("A12", "A19", "A04", "C10")
    }
    archives = [
        {"action": action, "archive_sha256": f"{index + 1:x}" * 64}
        for index, action in enumerate((*actions, "NON_PH"))
    ]
    supplied = _compile_final_action_ledger(
        index, diagnostic, non_ph, actions, archives, refits, q_artifact
    )
    rows = {row["action"]: row for row in supplied["actions"]}
    assert rows["A19"]["status"] == "BLOCKED_UNVERIFIED_PRODUCER"
    assert rows["A19"]["warning_triggered"] is True
    assert rows["A19"]["warning_blocks_review_ready"] is False
    assert supplied["deployment_eligibility"] == (
        "BLOCKED_UNVERIFIED_A04_PRODUCER"
    )

    without_warning = copy.deepcopy(actions)
    without_warning["A19"]["any_warning"] = False
    warning_free = _compile_final_action_ledger(
        index, diagnostic, non_ph, without_warning, archives, refits, q_artifact
    )
    warning_free_rows = {
        row["action"]: row for row in warning_free["actions"]
    }
    assert warning_free_rows["A19"]["status"] == rows["A19"]["status"]
    assert warning_free_rows["A19"]["blocks_review_ready"] is True

    unknown = copy.deepcopy(actions)
    unknown["A19"].update({"any_warning": None,
                           "statistical_status": "PARTIALLY_NOT_ESTIMABLE",
                           "sd_estimable_split_count": 12})
    unknown_ledger = _compile_final_action_ledger(
        index, diagnostic, non_ph, unknown, archives, refits, q_artifact)
    unknown_row = next(row for row in unknown_ledger["actions"] if row["action"] == "A19")
    assert unknown_row["warning_triggered"] is None
    assert unknown_row["statistical_status"] == "PARTIALLY_NOT_ESTIMABLE"
    assert (unknown_row["sd_estimable_split_count"], unknown_row["sd_split_count"]) == (12, 15)
    assert unknown_row["warning_blocks_review_ready"] is False
    assert unknown_row["blocks_review_ready"] is True

    failed = copy.deepcopy(actions)
    failed["A04"]["deployment_gate"]["status"] = "FAIL"
    deployment_failed = _compile_final_action_ledger(
        index, diagnostic, non_ph, failed, archives, refits, q_artifact
    )
    assert deployment_failed["deployment_eligibility"] == "FAIL"


def test_c10_na_uses_reconstructed_seta_not_a_caller_receipt() -> None:
    final_seta = compile_final_seta(
        [selector_result_fixture(fold, set()) for fold in range(1, 7)],
        full_data_event_count=300,
    )
    assert final_seta["lock"]["selected_parents"] == ["AST_ALT"]
    index = {"final_family": "COX_PH", "final_seta": final_seta}
    result = _compile_final_action_ledger(
        index, {"status": "COMPUTED"}, {"status": "NOT_APPLICABLE"}, {},
        [{"action": "NON_PH", "archive_sha256": "0" * 64}],
        [{"imputation": value} for value in range(1, 21)],
    )
    c10 = next(row for row in result["actions"] if row["action"] == "C10")
    assert c10["status"] == "VERIFIED_NOT_APPLICABLE"
    assert c10["final_seta_lock_sha256"] == final_seta["lock_sha256"]
    assert c10["evidence_member"] == "final-lineage.json"
    assert c10["fit_execution_count"] == 0
    assert "C10" not in result["blocking_actions"]
    assert result["blocking_actions"] == ["A12", "A19", "A04"]
    assert result["review_ready"] is False
    assert result["stage_acceptance"] is False


def test_final_sensitivity_archive_binds_a19_to_exact_lock(
    tmp_path: Path,
) -> None:
    decision = {"kind": "TEST_DECISION"}
    parameter_lock = sha256_bytes(b"final parameter lock")
    index = {
        "final_family": "RSF",
        "family_decision": decision,
        "final_parameter_lock": {"identity_sha256": parameter_lock},
        "final_seta": {"lock": {"selected_parents": ["Age"]}},
    }
    result = {
        "kind": "PADML_F5_A19_MULTI_SEED_STABILITY_V1",
        "status": "REDUCED_DECLARED_EVIDENCE",
        "execution_evidence_status": "NOT_VERIFIED_REFERENCES_ONLY",
        "unverified_authority_sources": ["A19_FIT_RECEIPT_ARCHIVES"],
        "final_family": "RSF",
        "final_family_decision_sha256": sha256_bytes(
            canonical_json_bytes(decision)
        ),
        "final_parameter_lock_sha256": parameter_lock,
        "warning_only": True,
        "any_warning": True,
        "source_archive_sha256": sha256_bytes(b"a19 input"),
        "selection_effect": "NONE",
        "blocking_for_production": True,
        "stage_acceptance": False,
    }
    path = (tmp_path / "a19.zip").resolve()
    write_deterministic_zip(
        path, {"a19.json": canonical_json_bytes(result)}
    )
    # A self-consistent scalar receipt cannot replace the 225 native objects.
    with pytest.raises(ContractError, match="F5_A19_NATIVE_EXECUTION_ARCHIVE_REQUIRED"):
        _load_final_sensitivity_action(path, "A19", index)

    drifted = copy.deepcopy(result)
    drifted["final_parameter_lock_sha256"] = "f" * 64
    drifted_path = (tmp_path / "a19-drifted.zip").resolve()
    write_deterministic_zip(
        drifted_path, {"a19.json": canonical_json_bytes(drifted)}
    )
    with pytest.raises(ContractError, match="F5_A19_NATIVE_EXECUTION_ARCHIVE_REQUIRED"):
        _load_final_sensitivity_action(drifted_path, "A19", index)


@pytest.mark.parametrize("mice_change", [None, "missing", "changed_bytes"])
def test_final_aggregate_retains_lineage_shap_and_action_archives(
    tmp_path: Path,
    monkeypatch,
    mice_change,
) -> None:
    monkeypatch.setattr(
        "padml.f5.pool_predictions", lambda *args, **kwargs: {"family": "RSF"}
    )
    monkeypatch.setattr(
        "padml.f5.diagnose_mi",
        lambda *args, **kwargs: {"status": "COMPUTED"},
    )
    component_hashes = [
        sha256_bytes(f"shap-{imputation}".encode())
        for imputation in range(1, 21)
    ]
    monkeypatch.setattr(
        "padml.f5.aggregate_final_shap",
        lambda *args, **kwargs: {
            "component_sha256_by_imputation": component_hashes
        },
    )
    retained = {}
    mice_artifacts = []
    for member in ("mice-plan.json", "final-mice.zip"):
        path = tmp_path / member
        path.write_bytes(b"PACKAGING UNIT FIXTURE ONLY, NOT NATIVE EVIDENCE")
        retained[member] = path
        mice_artifacts.append({"member": member, "sha256": sha256_file(path),
                               "size_bytes": path.stat().st_size})
    shap_archives = []
    for imputation, component_sha256 in enumerate(component_hashes, start=1):
        path = (tmp_path / f"shap-{imputation:02d}.zip").resolve()
        path.write_bytes(f"shap archive {imputation}".encode())
        member = f"shap-components/M{imputation:02d}.zip"
        retained[member] = path
        shap_archives.append({
            "imputation": imputation,
            "component_sha256": component_sha256,
            "member": member,
            "archive_sha256": sha256_file(path),
            "archive_size_bytes": path.stat().st_size,
        })
    a04 = {
        "status": "REDUCED_DECLARED_EVIDENCE",
        "execution_evidence_status": "NOT_VERIFIED_REFERENCES_ONLY",
        "application_evidence_status": "UNFITTED_LEAF_FOR_LEDGER_TEST_ONLY",
        "mice_chain_execution_count": 0,
        "unaudited_centers": ["38", "39", "48", "52", "54"],
        "p2c2t": {"status": "UNFITTED_LEAF_FOR_LEDGER_TEST_ONLY"},
        "temporal": {"status": "NOT_APPLICABLE"},
        "unverified_authority_sources": ["A04_MICE_VARIANTS", "A04_NEGATIVE_CONTROLS"],
        "blocking_for_production": True,
        "deployment_gate": {"status": "PASS", "assessed_centers": ["36"]},
    }
    non_ph = {
        "kind": "PADML_F5_NON_PH_ACTION_V1",
        "family": "RSF",
        "status": "NOT_APPLICABLE",
        "analysis": None,
    }
    action_values = {"A04": a04, "NON_PH": non_ph}
    action_archives = []
    for action, result_member in (("A04", "a04.json"), ("NON_PH", "non-ph.json")):
        path = (tmp_path / f"{action}.zip").resolve()
        write_deterministic_zip(
            path,
            {result_member: canonical_json_bytes(action_values[action])},
        )
        member = f"action-results/{action}.zip"
        retained[member] = path
        action_archives.append({
            "action": action,
            "member": member,
            "result_member": result_member,
            "result_sha256": sha256_bytes(
                canonical_json_bytes(action_values[action])
            ),
            "archive_sha256": sha256_file(path),
            "archive_size_bytes": path.stat().st_size,
        })
    data = {
        "kind": "PADML_F5_PAIRED_M20_PREDICTIONS",
        "predictions": [],
        "final_refit_receipts": [],
        "centers": [],
        "final_family": "RSF",
        "family_decision": {},
        "final_refit_plan": {},
        "shap_components": [{} for _ in range(20)],
    }
    lineage = {
        "kind": "PADML_F5_FINAL_AGGREGATE_INPUT_V2",
        "final_family": "RSF",
        "family_decision": {},
        "final_refit_plan": {},
        "final_seta": compile_final_seta(
            [selector_result_fixture(fold, set()) for fold in range(1, 7)],
            full_data_event_count=300,
        ),
    }
    # Packaging-only fixture: the existing RSF consumer also retains its Q.
    # Native admissibility is tested at the upstream reader, not by these bytes.
    q_path = tmp_path / "final-search.zip"
    q_path.write_bytes(b"UNFITTED_Q_PACKAGING_FIXTURE_NOT_NATIVE_EVIDENCE")
    q_identity = sha256_bytes(b"UNFITTED_Q_IDENTITY")
    lineage["parameter_source"] = {"identity_sha256": q_identity}
    retained["final-search.zip"] = q_path
    parameter_artifact = {"member": "final-search.zip", "sha256": sha256_file(q_path),
                          "size_bytes": q_path.stat().st_size, "identity_sha256": q_identity}
    target = (tmp_path / "final.zip").resolve()
    if mice_change == "missing":
        retained.pop("final-mice.zip")
    elif mice_change == "changed_bytes":
        retained["final-mice.zip"].write_bytes(b"changed archive")
    if mice_change is not None:
        with pytest.raises(ContractError, match="F5_FINAL_MICE_ARCHIVE_BINDING_INVALID"):
            _execute_paired_diagnostic(
                data, b"response", target, source_sha256=sha256_bytes(b"sources"),
                archive_records=[{"imputation": value} for value in range(1, 21)],
                shap_component_archives=shap_archives, retained_members=retained,
                non_ph_action=non_ph, sensitivity_actions={"A04": a04},
                action_archives=action_archives, final_lineage=lineage,
                final_mice_artifacts=mice_artifacts,
                parameter_source_artifact=parameter_artifact,
            )
        assert not target.exists()
        return
    report = _execute_paired_diagnostic(
        data,
        b"response",
        target,
        source_sha256=sha256_bytes(b"sources"),
        archive_records=[
            {"imputation": value} for value in range(1, 21)
        ],
        shap_component_archives=shap_archives,
        retained_members=retained,
        non_ph_action=non_ph,
        sensitivity_actions={"A04": a04},
        action_archives=action_archives,
        final_lineage=lineage,
        final_mice_artifacts=mice_artifacts,
        parameter_source_artifact=parameter_artifact,
    )
    assert report["status"] == "BLOCKED_ACTION_EVIDENCE"
    entries = read_safe_zip(target)
    assert set(entries) == {
        "final-aggregate.json",
        "final-lineage.json",
        *retained,
    }
    result = strict_json_bytes(entries["final-aggregate.json"])
    assert result["kind"] == "PADML_F5_FINAL_AGGREGATE_V1"
    assert result["final_mice_artifacts"] == mice_artifacts
    assert entries["final-mice.zip"] == retained["final-mice.zip"].read_bytes()
    assert result["action_ledger"]["deployment_eligibility"] == (
        "BLOCKED_UNVERIFIED_A04_PRODUCER"
    )
    assert result["review_ready"] is False
    c10 = next(row for row in result["action_ledger"]["actions"] if row["action"] == "C10")
    assert c10["status"] == "VERIFIED_NOT_APPLICABLE"
    assert c10["final_seta_lock_sha256"] == lineage["final_seta"]["lock_sha256"]
    assert entries["final-lineage.json"] == canonical_json_bytes(lineage)
    assert entries["action-results/A04.zip"] == retained[
        "action-results/A04.zip"
    ].read_bytes()


def test_one_locked_final_refit_task_retains_model_baseline_and_receipt(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
) -> None:
    # Native refit-engine fixture only: no MICE or Q is produced here. The public
    # source-consumption frontiers have separate zero-fit tests with real files.
    final_mice, final_seta, decision, parameter_lock, final_recipe = (
        final_refit_compilation_inputs("COX_PH")
    )
    ids = final_mice["fit_ids"]
    covariate_csv = (
        "Patient_ID,Center,AST_ALT\n"
        + "".join(
            f"{patient_id},36,{1 + ((index * 7) % len(ids)) / 100}\n"
            for index, patient_id in enumerate(ids)
        )
    ).encode()
    response_csv = (
        "Patient_ID,All_Cause_Death,Death_Followup_months\n"
        + "".join(
            f"{patient_id},1,{5 + ((index * 11) % len(ids))}\n"
            for index, patient_id in enumerate(ids)
        )
    ).encode()
    members = [
        {
            "name": f"imp{imputation:02d}.csv",
            "sha256": sha256_bytes(covariate_csv),
            "size_bytes": len(covariate_csv),
        }
        for imputation in range(1, 21)
    ]
    final_mice["covariates"]["members"] = members
    final_mice["fit_covariate_members"] = copy.deepcopy(members)
    final_mice["covariates"]["data_identity"] = sha256_bytes(
        canonical_json_bytes(final_mice["covariates"]["members"])
    )
    final_mice["fit_response"]["sha256"] = sha256_bytes(response_csv)
    final_recipe["source_mice_data_identity"] = final_mice["covariates"][
        "data_identity"
    ]
    final_recipe["recipe"] = _test_final_design_recipe(
        "COX_PH", ["AST_ALT"]
    )
    final_recipe["recipe_sha256"] = sha256_bytes(
        canonical_json_bytes(final_recipe["recipe"])
    )
    final_recipe["identity_sha256"] = sha256_bytes(canonical_json_bytes({
        key: value for key, value in final_recipe.items()
        if key != "identity_sha256"
    }))
    plan = compile_final_refit_tasks(
        final_mice, final_seta, decision, parameter_lock, final_recipe,
        f4_handoff_fixture(decision), workers=56,
    )
    task = plan["tasks"][0]
    assert plan["execution_profile"]["pool_workers"] == 56
    m20_root = (tmp_path / "m20").resolve()
    m20_root.mkdir()
    for member in members:
        (m20_root / member["name"]).write_bytes(covariate_csv)
    plan_path = (tmp_path / "plan.json").resolve()
    decision_path = (tmp_path / "family-decision.json").resolve()
    recipe_path = (tmp_path / "recipe.json").resolve()
    response_path = (tmp_path / "response.csv").resolve()
    plan_path.write_bytes(canonical_json_bytes(plan))
    decision_path.write_bytes(canonical_json_bytes(decision))
    recipe_path.write_bytes(canonical_json_bytes(final_recipe))
    response_path.write_bytes(response_csv)
    lineage = {"final_refit_plan": plan, "family_decision": decision,
               "final_recipe": final_recipe}
    lineage_path = (tmp_path / "lineage.json").resolve()
    lineage_path.write_bytes(canonical_json_bytes(lineage))
    mice_plan_path = (tmp_path / "UNFITTED-mice-plan.json").resolve()
    final_mice_path = (tmp_path / "UNFITTED-final-mice.zip").resolve()
    mice_plan_path.write_bytes(b"UNFITTED_REFIT_ENGINE_FIXTURE")
    final_mice_path.write_bytes(b"UNFITTED_REFIT_ENGINE_FIXTURE")

    def unfitted_parameter_frontier(actual, source, **kwargs):
        assert actual == lineage and source is None
        return _validate_final_refit_plan(plan, decision)

    def unfitted_mice_frontier(actual, mice_plan, payload, response, scratch, **kwargs):
        assert actual == lineage and response == response_csv
        assert mice_plan.read_bytes() == payload.read_bytes() == b"UNFITTED_REFIT_ENGINE_FIXTURE"
        return []

    monkeypatch.setattr("padml.f5._consume_final_parameter_source", unfitted_parameter_frontier)
    monkeypatch.setattr("padml.f5._validate_final_mice_archive", unfitted_mice_frontier)
    compiled_root = (tmp_path / "compiled-final-refits").resolve()
    compiled = compile_final_refit_bundles(
        plan_path, decision_path, recipe_path, m20_root, response_path,
        compiled_root, lineage_path=lineage_path, mice_plan_path=mice_plan_path,
        final_mice_path=final_mice_path,
    )
    assert compiled["bundle_count"] == 20
    index = strict_json_bytes(
        (compiled_root / "dispatch-index.json").read_bytes()
    )
    assert index["model_fit_count"] == 0
    assert [row["imputation"] for row in index["bundles"]] == list(
        range(1, 21)
    )
    source = compiled_root / f"{task['task_id']}.zip"
    target = (tmp_path / "final-refit-m01.zip").resolve()
    result = execute_final_refit_bundle(source, target, lineage_path=compiled_root / "lineage.json")
    entries = read_safe_zip(target)
    receipt = strict_json_bytes(entries["receipt.json"])
    prediction = strict_json_bytes(entries["prediction.json"])
    health = strict_json_bytes(entries["fit-health.json"])
    assert result["status"] == "COMPUTED"
    assert len(entries["model.bin"]) > 0
    assert len(entries["baseline.bin"]) > 0
    assert health["engine"] == "survival::coxph"
    assert health["final_model_fit_count"] == 1
    retained_audit = _validate_retained_model_objects(
        "COX_PH",
        entries["model.bin"],
        entries["baseline.bin"],
        health,
        task,
    )
    assert retained_audit["coefficient_count"] == 1
    assert retained_audit["covariance_rank"] == 1
    assert retained_audit["training_event_count"] == len(ids)
    assert retained_audit["complete_data_degrees_of_freedom"] == len(ids) - 1
    _replay_final_refit_result(
        source, task, plan, decision, entries["model.bin"], entries["baseline.bin"], prediction
    )
    changed_prediction = copy.deepcopy(prediction)
    changed_prediction["survival"][0] = [1.0] + [0.5] * 36
    with pytest.raises(ContractError, match="F5_RETAINED_PREDICTION_REPLAY_MISMATCH"):
        _replay_final_refit_result(
            source, task, plan, decision, entries["model.bin"], entries["baseline.bin"], changed_prediction
        )
    assert prediction["patient_ids"] == ids
    assert all(row[0] == 1.0 for row in prediction["survival"])
    assert receipt["final_refit_plan_sha256"] == plan["plan_sha256"]
    assert receipt["producer_task_sha256"] == task["task_sha256"]
    assert receipt["response_sha256"] == sha256_bytes(response_csv)
    assert receipt["patient_ids_sha256"] == task["row_ids_sha256"]
    assert receipt["center_values_sha256"] == sha256_bytes(
        canonical_json_bytes(["36"] * len(ids))
    )
    source = (
        Path(__file__).resolve().parents[1]
        / "padml/kernels/f5_final_refit.R"
    ).read_text()
    assert "control = coxph.control(eps = 1e-11, iter.max = 100L)" in source
    assert 'engine_columns <- sprintf(".padml_x_%04d"' in source

    batch_root = (tmp_path / "batch-results").resolve()
    batch = execute_final_refit_batch(compiled_root, batch_root, imputations=[2, 1])
    assert batch["imputations"] == [1, 2]
    assert batch["pool_workers"] == 56 and batch["active_worker_limit"] == 2
    assert batch["final_model_fit_count"] == 2 and batch["stage_acceptance"] is False
    assert batch["search_fit_count"] == batch["stopping_fit_count"] == 0
    assert len(list(batch_root.glob("*.zip"))) == 2
    for i in (1, 2):
        actual = read_safe_zip(batch_root / f"{plan['tasks'][i - 1]['task_id']}.zip")
        observed = strict_json_bytes(actual["prediction.json"])
        assert observed["survival"] == prediction["survival"]
        assert strict_json_bytes(actual["receipt.json"])["producer_task_sha256"] == plan["tasks"][i - 1]["task_sha256"]
    with pytest.raises(ContractError, match="F5_FINAL_REFIT_BATCH_MEMBER_INVALID"):
        execute_final_refit_batch(compiled_root, batch_root, imputations=[1])
    for selection in ([], [1, 1], [True], [21]):
        with pytest.raises(ContractError, match="F5_FINAL_REFIT_BATCH_IMPUTATIONS_INVALID"):
            execute_final_refit_batch(compiled_root, tmp_path / "invalid-batch", imputations=selection)

    # Complete the same native twenty-component fixture; reuse the first two fits.
    remaining = execute_final_refit_batch(
        compiled_root, batch_root, imputations=list(range(3, 21))
    )
    assert remaining["final_model_fit_count"] == 18
    collected = collect_final_refit_results(batch_root, decision, plan, input_root=compiled_root)
    assert len(collected["archives"]) == len(collected["predictions"]) == 20
    assert len(collected["shap_components"]) == 20
    assert all(
        row["label"] == "FINAL_FULL_DATA_APPARENT_SHAP"
        for row in collected["shap_components"]
    )
    assert all(row["retained_prediction_replay"] == "EXACT_ALL_PATIENTS_ALL_HORIZONS"
               for row in collected["archives"])
    assert collected["coefficient_evidence"]["complete_data_df_by_imputation"] == [len(ids) - 1] * 20



def _raw_final_recipe(family: str) -> tuple[dict, dict]:
    predictors = predictor_contract(
        Path(__file__).resolve().parents[1] / "padml"
    )
    ast_alt = next(
        row for row in predictors["variables"] if row["name"] == "AST_ALT"
    )
    return _test_final_design_recipe(family, ["AST_ALT"]), ast_alt


@pytest.mark.parametrize("family,native_xgb", [
    ("XGBOOST_COX", False), ("COXTIME_SET_A", False), ("XGBOOST_COX", True),
])
def test_final_python_shap_reuses_only_own_validated_conversion(family, native_xgb, tmp_path, monkeypatch):
    """Locked conversion; optionally a real, synthetic XGB prediction leaf."""
    from contextlib import nullcontext
    from types import SimpleNamespace
    import numpy as np
    import pandas as pd

    selected = ["AST_ALT", "Age", "Sex", "Rutherford_cat", "Prior_LE_Surgery_cat"]
    recipe = _test_final_design_recipe(family, selected)
    rows = [{"Patient_ID": f"shap-{index}", "Center": "36", "AST_ALT": str(.5 + index / 8),
        "Age": str(40 + index), "Sex": str(index % 2),
        "Rutherford_cat": ["Grade 0-2", "Grade 3-4", "Grade 5-6"][index % 3],
        "Prior_LE_Surgery_cat": ["None", "Procedure", "Amputation", "Other"][index % 4]}
        for index in range(8)]
    task = {"family": family, "imputation": 1, "selected_parents": selected,
            "parameters": {"family": family, "selected_rounds": 2}}
    if family == "COXTIME_SET_A":
        candidate = load_science_authority()["science"]["f2_model_development"]["coxtime"]["candidates"][0]
        task["parameters"] = {"family": family, "candidate_id": candidate["candidate_id"],
                              "parameters": candidate, "locked_epoch": 30}
    matrix, columns, _, _ = f5_module._final_python_design(family, task, rows, recipe)
    real_xgb = model = None
    model_bytes = b"UNFITTED_RETAINED_MODEL"
    if native_xgb:
        real_xgb = pytest.importorskip("xgboost")
        model = real_xgb.train({"objective": "survival:cox", "nthread": 1,
            "device": "cpu", "max_depth": 2, "seed": 1729},
            real_xgb.DMatrix(matrix, label=[1, -2, 3, -4, 5, -6, 7, -8]),
            num_boost_round=56)
        model_bytes = bytes(model.save_raw())
        task["parameters"]["selected_rounds"] = 56
    baseline = {"design_columns": columns, "event_times": [3, 9, 20, 38],
        "cumulative_baseline_hazard": [.02, .05, .08, .2], "log_duration": False,
        "duration_mean": [0.0], "duration_scale": [1.0],
        "input_mean": [.125] * len(columns), "input_scale": [1.5] * len(columns),
        "baseline_index": [3, 9, 20, 38], "baseline_hazards": [.02, .03, .03, .12]}
    for name, fields, values in (
        ("covariates.csv", list(rows[0]), rows),
        ("response.csv", ["Patient_ID", "All_Cause_Death", "Death_Followup_months"],
         [{"Patient_ID": row["Patient_ID"], "All_Cause_Death": str(index % 2),
           "Death_Followup_months": str(index + 1)} for index, row in enumerate(rows)]),
    ):
        stream = io.StringIO(newline="")
        writer = csv.DictWriter(stream, fieldnames=fields, lineterminator="\n")
        writer.writeheader()
        writer.writerows(values)
        (tmp_path / name).write_text(stream.getvalue())
    (tmp_path / "model.bin").write_bytes(model_bytes)
    (tmp_path / "baseline.json").write_bytes(canonical_json_bytes(baseline))
    spec = {"family": family, "task": task, "recipe": recipe, "selected_parents": selected,
        "covariate_path": str(tmp_path / "covariates.csv"), "response_path": str(tmp_path / "response.csv"),
        "model_path": str(tmp_path / "model.bin"), "baseline_path": str(tmp_path / "baseline.json"),
        "model_sha256": sha256_file(tmp_path / "model.bin")}
    path = tmp_path / "spec.json"
    path.write_bytes(canonical_json_bytes(spec))
    observed, audits = [], []

    class UnfittedModel:
        net = SimpleNamespace(load_state_dict=lambda *args, **kwargs: None)
        def load_model(self, value):
            assert bytes(value) == model_bytes
            if native_xgb:
                model.load_model(value)
        def set_param(self, value):
            assert value == {"nthread": 1, "device": "cpu"}
            if native_xgb:
                model.set_param(value)
        def num_boosted_rounds(self):
            return 56 if native_xgb else 2
        def inplace_predict(self, values, **options):
            assert options["predict_type"] == "margin" and options["iteration_range"] == (0, 0)
            assert np.isnan(options["missing"]) and options["validate_features"] is True
            observed.append(values.copy())
            if native_xgb:
                return model.inplace_predict(values, **options)
            return values.sum(axis=1) * .001
        def predict_surv_df(self, values, **options):
            assert options["eval_"] is True and options["num_workers"] == 0
            observed.append(values.copy())
            return pd.DataFrame(np.exp(-np.outer([.02, .05, .08, .2],
                np.exp(values.sum(axis=1) * .001))), index=[3, 9, 20, 38])

    def audited(*args, **kwargs):
        audits.append("UNFITTED_NATIVE_OBJECT_AUDIT")
        retained = UnfittedModel()
        if family == "XGBOOST_COX":
            retained.load_model(bytearray(model_bytes))
            retained.set_param({"nthread":1, "device":"cpu"})
            kwargs["prepared_sink"].update(model=retained,
                event_times=np.asarray(baseline["event_times"]),
                cumulative=np.asarray(baseline["cumulative_baseline_hazard"]))
        else:
            kwargs["prepared_sink"].update(model=retained,
                input_mean=np.asarray(baseline["input_mean"], dtype="float32"),
                input_scale=np.asarray(baseline["input_scale"], dtype="float32"),
                retained_baseline=pd.Series(baseline["baseline_hazards"], index=baseline["baseline_index"]),
                training_rows=len(rows))
    def forbidden(*args, **kwargs):
        pytest.fail("NO_MODEL_FIT_OR_PER_MASK_AUTHORITY_OR_RECORD_RECONVERSION")
    monkeypatch.setattr(f5_module, "_predict_retained_python_arrays", audited)
    monkeypatch.setattr(f5_module.subprocess, "run", forbidden)
    monkeypatch.setitem(sys.modules, "xgboost", SimpleNamespace(Booster=UnfittedModel, DMatrix=lambda values: values))
    monkeypatch.setitem(sys.modules, "pycox", SimpleNamespace(models=object()))
    monkeypatch.setitem(sys.modules, "torchtuples", SimpleNamespace())
    monkeypatch.setitem(sys.modules, "torch", SimpleNamespace(
        load=lambda *args, **kwargs: {"candidate": candidate, "input_width": matrix.shape[1], "state_dict": {}},
        set_num_threads=lambda count: None, device=lambda name: name,
        random=SimpleNamespace(fork_rng=lambda **kwargs: nullcontext())))
    monkeypatch.setattr(f5_module, "_coxtime_labtrans", lambda *args: SimpleNamespace(log_duration=False,
        duration_scaler=SimpleNamespace(mean_=np.asarray([0.0]), scale_=np.asarray([1.0]))))
    monkeypatch.setattr(f5_module, "_coxtime_model", lambda *args: UnfittedModel())
    predictor = f5_module._FinalShapPythonPredictor(str(path))
    assert audits == ["UNFITTED_NATIVE_OBJECT_AUDIT"]
    assert predictor.columns == columns and predictor.selected == selected
    frame = pd.DataFrame(rows)[selected]
    typed = frame.copy()
    typed["Age"] = typed["Age"].astype("float32")
    typed["AST_ALT"] = typed["AST_ALT"].astype("Float64")
    typed["Sex"] = typed["Sex"].astype("int64")
    for name in ("Rutherford_cat", "Prior_LE_Surgery_cat"):
        typed[name] = pd.Categorical(typed[name], categories=list(reversed(typed[name].unique())))
    batches = [frame, typed, typed.iloc[[6, 2, 6]], frame.iloc[[3]], frame.iloc[::-1]]
    expected = []
    for batch in batches:
        original_rows = [{"Patient_ID": f"SHAP_MASKED_{index:09d}", "Center": "SHAP", **row}
                         for index, row in enumerate(batch.to_dict(orient="records"), 1)]
        design, names, _, _ = f5_module._final_python_design(family, task, original_rows, recipe)
        assert names == columns
        masked_design = design.copy(order="K")
        if family == "XGBOOST_COX":
            margin = (model.predict(real_xgb.DMatrix(design), output_margin=True)
                      if native_xgb else design.astype("float32").sum(axis=1) * .001)
            survival = f5_module._survival_from_risk(np.asarray(baseline["event_times"]),
                np.asarray(baseline["cumulative_baseline_hazard"]), np.exp(margin),
                list(REPORT_HORIZONS), np)
            design = design.astype("float32")
        else:
            design = (np.asarray(design, dtype="float32") - np.asarray(baseline["input_mean"], dtype="float32")) / np.asarray(baseline["input_scale"], dtype="float32")
            native = UnfittedModel().predict_surv_df(design, eval_=True, num_workers=0)
            survival = native.to_numpy(dtype=float)[[0, 1, 2, 2], :].T
        expected.append((masked_design, design, survival))
    observed.clear()
    with monkeypatch.context() as cached:
        cached.setattr(f5_module, "predictor_contract", forbidden)
        cached.setattr(f5_module, "_final_python_design", forbidden)
        cached.setattr(f5_module, "_prepare_python_design", forbidden)
        cached.setattr(pd, "get_dummies", forbidden)
        cached.setattr(pd.DataFrame, "to_dict", forbidden)
        for batch, (masked_design, design, survival) in zip(batches, expected, strict=True):
            before = batch.copy(deep=True)
            converted = predictor._masked_design(batch)
            assert converted.dtype == masked_design.dtype and converted.tobytes() == masked_design.tobytes()
            assert converted.flags.f_contiguous == masked_design.flags.f_contiguous
            actual = predictor.predict_survival(batch)
            assert actual.dtype == survival.dtype and actual.tobytes() == survival.tobytes()
            actual_design = observed[-1]
            assert actual_design.dtype == design.dtype and actual_design[:len(design)].tobytes() == design.tobytes()
            if len(actual_design) > len(design):
                assert family == "COXTIME_SET_A" and np.count_nonzero(actual_design[len(design):]) == 0
            pd.testing.assert_frame_equal(batch, before)
        invalid = [frame.iloc[:0], frame.drop(columns="Sex"), frame[list(reversed(selected))],
            frame.assign(All_Cause_Death="1"), frame.assign(Death_Followup_months="1"),
            frame.assign(Sex="unknown"), frame.assign(Sex=None), frame.assign(Age=float("nan")),
            frame.assign(Age=float("inf")), frame.assign(Age="not-a-number")]
        for batch in invalid:
            with pytest.raises((ContractError, ValueError)):
                predictor.predict_survival(batch)
        if family == "XGBOOST_COX":
            with pytest.raises(FloatingPointError):
                predictor.predict_survival(frame.assign(Age=1e100))
    assert audits == ["UNFITTED_NATIVE_OBJECT_AUDIT"] and len(observed) == len(batches)
    if native_xgb:
        # The application transaction consumes the same prepared native model,
        # but must perform independent real batch and single predictions.
        prepared = dict(model=model, event_times=np.asarray(baseline['event_times']),
            cumulative=np.asarray(baseline['cumulative_baseline_hazard']))
        for masked_design, _, survival in expected:
            observed_batch = f5_module._predict_prepared_python_arrays('XGBOOST_COX', prepared,
                masked_design, list(REPORT_HORIZONS), np)
            observed_single = np.vstack([f5_module._predict_prepared_python_arrays('XGBOOST_COX', prepared,
                masked_design[i:i+1], list(REPORT_HORIZONS), np) for i in range(len(masked_design))])
            assert observed_batch.tobytes() == observed_single.tobytes() == survival.tobytes()
    damaged = copy.deepcopy(spec)
    damaged["recipe"]["predictor_rows"][0]["type"] = "WRONG"
    path.write_bytes(canonical_json_bytes(damaged))
    with pytest.raises(ContractError, match="PYTHON_RECIPE_INVALID"):
        f5_module._FinalShapPythonPredictor(str(path))
    path.write_bytes(canonical_json_bytes(spec))
    second = f5_module._FinalShapPythonPredictor(str(path))
    assert audits == ["UNFITTED_NATIVE_OBJECT_AUDIT"] * 2
    assert second._design_layout is not predictor._design_layout
    assert all(a[2] is not b[2] for a, b in zip(second._design_layout, predictor._design_layout)
               if a[1] is not None)
    (tmp_path / "conversion-observation.json").write_bytes(canonical_json_bytes({
        "family": family, "masked_batches_equal_to_original": len(batches), "negative_batches": len(invalid),
        "matrix_and_survival_byte_equality": True, "original_factor_and_finite_consumer": True,
        "per_mask_recipe_reloads": 0, "per_mask_record_roundtrips": 0, "independent_instance_audits": len(audits),
        "native_model_leaves": "SYNTHETIC_XGB_56_ROUNDS" if native_xgb else "UNFITTED",
        "new_model_fits": int(native_xgb), "new_mice_chains": 0, "new_kernelshap_runs": 0}))


@pytest.mark.parametrize("family", ["COX_PH", "ELASTIC_NET_COX", "FPM_TVC_SET_A"])
def test_compile_final_recipe_reuses_one_response_free_m20_design(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, family: str,
    record_property,
) -> None:
    from time import perf_counter
    final_mice, final_seta, decision, _, _ = (
        final_refit_compilation_inputs(family)
    )
    predictors = predictor_contract(
        Path(__file__).resolve().parents[1] / "padml"
    )
    parents = [
        row["parent"] for row in predictors["transform_registry"]["rows"]
    ]
    ids = final_mice["fit_ids"]
    input_dir = (tmp_path / "final-m20").resolve()
    input_dir.mkdir()
    members = []
    for imputation in range(1, 21):
        output = io.StringIO(newline="")
        fields = ["Patient_ID", "Center", *parents]
        writer = csv.DictWriter(output, fieldnames=fields, lineterminator="\n")
        writer.writeheader()
        for index, patient_id in enumerate(ids):
            row = {
                "Patient_ID": patient_id,
                "Center": "36",
                **{
                    parent: str(
                        1 + ((index * 7 + imputation * 3 + offset) % 29) / 10
                    )
                    for offset, parent in enumerate(parents)
                },
            }
            writer.writerow(row)
        payload = output.getvalue().encode()
        path = input_dir / f"imp{imputation:02d}.csv"
        path.write_bytes(payload)
        members.append({
            "name": path.name,
            "sha256": sha256_bytes(payload),
            "size_bytes": len(payload),
        })
    final_mice["covariates"] = {
        "kind": "PADML_F5_FINAL_MICE_BINDING",
        "status": "PASS",
        "input_dir": str(input_dir),
        "analysis_view_sha256": sha256_bytes(b"analysis view"),
        "analysis_ids_sha256": sha256_bytes(canonical_json_bytes(ids)),
        "members": members,
        "data_identity": sha256_bytes(canonical_json_bytes(members)),
    }
    original_run = subprocess.run
    calls = []

    def record_recipe_call(command, **kwargs):
        if str(command[1]).endswith("/f5_final_refit.R"):
            spec = strict_json_bytes(Path(command[2]).read_bytes())
            assert set(spec) == {"action", "projection", "output_path"}
            assert spec["action"] == "COMPILE_FINAL_RECIPE"
            assert spec["projection"]["recipe_registry_record"]["fit_ids"] == ids
            assert len(spec["projection"]["recipe_registry_record"]["members"]) == 20
            calls.append(spec)
        return original_run(command, **kwargs)

    monkeypatch.setattr("padml.f5.subprocess.run", record_recipe_call)
    family_handoff = f4_handoff_fixture(decision)
    started = perf_counter()
    recipe = compile_final_recipe(
        final_mice, final_seta, decision, family_handoff, tmp_path.resolve()
    )
    record_property("single_recipe_seconds", perf_counter() - started)
    assert len(calls) == 1
    assert recipe["status"] == "PASS"
    assert recipe["response_read_count"] == 0
    assert recipe["recipe"]["family"] == family
    assert recipe["recipe"]["transform_recipe"]["partition_id"] == (
        "F5_FINAL_FULL_DATA_RECIPE"
    )
    assert recipe["recipe"]["selected_parents"] == ["AST_ALT"]

    # Exact full-recipe replay against the unchanged five-alias F2 path.
    from padml.f2_kernel import _compile_transform_recipes
    partition_ids = [f"REFERENCE_FINAL_{index}" for index in range(5)]
    started = perf_counter()
    reference = _compile_transform_recipes(
        {"predictors": predictors},
        {"partitions": [{
            "partition_id": partition_id, "fit_ids": ids,
            "covariates": final_mice["covariates"],
        } for partition_id in partition_ids]},
        partition_ids, tmp_path.resolve(),
        Path(__file__).resolve().parents[1] / "padml", expected_count=5,
    )["recipes"][0]
    record_property("five_alias_reference_seconds", perf_counter() - started)
    reference["partition_id"] = "F5_FINAL_FULL_DATA_RECIPE"
    reference["recipe_sha256"] = sha256_bytes(canonical_json_bytes({
        key: value for key, value in reference.items() if key != "recipe_sha256"
    }))
    assert canonical_json_bytes(recipe["recipe"]["transform_recipe"]) == canonical_json_bytes(reference)
    assert len(calls) == 1
    assert not list(tmp_path.glob(".f5-final-recipe-*"))

    if family == "COX_PH":
        member = input_dir / "imp20.csv"
        original = member.read_bytes()
        member.write_bytes(original + b"\n")
        with pytest.raises(ContractError, match="F5_FINAL_RECIPE_MICE_BYTES_INVALID"):
            compile_final_recipe(
                final_mice, final_seta, decision, family_handoff,
                tmp_path.resolve(),
            )
        # Even self-consistent input metadata cannot admit an outcome column.
        lines = original.decode().splitlines()
        damaged = (lines[0] + ",All_Cause_Death\n" + "\n".join(line + ",1" for line in lines[1:]) + "\n").encode()
        member.write_bytes(damaged)
        final_mice["covariates"]["members"][-1] = {
            "name": member.name, "sha256": sha256_bytes(damaged),
            "size_bytes": len(damaged),
        }
        final_mice["covariates"]["data_identity"] = sha256_bytes(
            canonical_json_bytes(final_mice["covariates"]["members"])
        )
        with pytest.raises(ContractError, match="F2_RECIPE_RESPONSE_ROLE_REACHABLE") as failed_recipe:
            compile_final_recipe(
                final_mice, final_seta, decision, family_handoff,
                tmp_path.resolve(),
            )
        assert len(calls) == 1
        retained = list(tmp_path.glob(".f5-final-recipe-*"))
        assert len(retained) == 1
        assert f"F5_FINAL_RECIPE_EVIDENCE_RETAINED:{retained[0]}" in failed_recipe.value.__notes__


def _python_final_refit_rows() -> tuple[list[dict], dict, list[float], list[int]]:
    ids = [f"python-patient-{index:03d}" for index in range(64)]
    values = [0.7 + ((index * 7) % 31) / 10 for index in range(64)]
    times = [float(2 + ((index * 11) % 55)) for index in range(64)]
    events = [int(index % 4 != 0) for index in range(64)]
    rows = [
        {
            "Patient_ID": patient_id,
            "Center": "36",
            "AST_ALT": str(values[index]),
        }
        for index, patient_id in enumerate(ids)
    ]
    responses = {
        patient_id: {
            "Patient_ID": patient_id,
            "All_Cause_Death": str(events[index]),
            "Death_Followup_months": str(times[index]),
        }
        for index, patient_id in enumerate(ids)
    }
    return rows, responses, times, events


def _assert_final_prediction_applications(family, task, rows, responses, recipe, fitted):
    indices = [2, 0, 1]
    application = [{**rows[index], "Patient_ID": f"new-patient-{index}"}
                   for index in indices]
    assert not set(row["Patient_ID"] for row in application).intersection(responses)
    retained = (fitted["model"], fitted["baseline"])
    batch = _execute_final_refit_engine(
        family, task, rows, responses, recipe, retained_objects=retained,
        prediction_rows=application,
    )
    assert batch["survival"] == [fitted["survival"][index] for index in indices]
    single = [
        _execute_final_refit_engine(
            family, task, rows, responses, recipe, retained_objects=retained,
            prediction_rows=[row],
        )["survival"][0]
        for row in application
    ]
    assert single == batch["survival"]


def test_final_fpm_prediction_arithmetic_is_scoped_and_keeps_domain() -> None:
    kernel = Path(__file__).resolve().parents[1] / "padml/kernels/f5_design.R"
    completed = subprocess.run([
        "Rscript", "--vanilla", "-e", r'''
source(commandArgs(trailingOnly=TRUE)[[1L]])
options(matprod="blas")
calls <- 0L
predict <- function(fit, newdata, type) {
  stopifnot(identical(getOption("matprod"), "internal"), type == "surv")
  calls <<- calls + 1L
  if (isTRUE(fit$error)) stop("native_prediction_error")
  exp(-newdata$.time * newdata$AST_ALT)
}
design <- matrix(c(1.5, 2.8, 1.6), ncol=1L, dimnames=list(NULL, "AST_ALT"))
horizons <- c(0L, 6L, 12L, 24L, 36L)
batch <- padml_predict_final_fpm_survival(list(), design, horizons)
single <- do.call(rbind, lapply(1:3, function(i) {
  padml_predict_final_fpm_survival(list(), design[i, , drop=FALSE], horizons)
}))
stopifnot(identical(batch, single), identical(dim(batch), c(3L, 5L)),
          identical(getOption("matprod"), "blas"), calls == 4L)
failed <- try(padml_predict_final_fpm_survival(list(error=TRUE), design, horizons), silent=TRUE)
stopifnot(inherits(failed, "try-error"), grepl("native_prediction_error", failed),
          identical(getOption("matprod"), "blas"), calls == 5L)
for (invalid in c(0, -1, 15.01, NA, Inf)) {
  invalid_design <- design
  invalid_design[1L, 1L] <- invalid
  failed <- try(padml_predict_final_fpm_survival(list(), invalid_design, horizons), silent=TRUE)
  stopifnot(inherits(failed, "try-error"),
            grepl("F5_FPM_FIXED_COMPUTATIONAL_DOMAIN_INVALID", failed), calls == 5L,
            identical(getOption("matprod"), "blas"))
}
cat("PASS\n")
''', str(kernel),
    ], capture_output=True, text=True, check=False, timeout=30)
    assert completed.returncode == 0, completed.stderr
    assert completed.stdout.strip() == "PASS"


def test_final_cox_new_patients_reuse_training_objects_without_outcomes() -> None:
    rows, responses, _, _ = _python_final_refit_rows()
    recipe, _ = _raw_final_recipe("COX_PH")
    task = {"selected_parents": ["AST_ALT"], "model_seed": None,
            "parameters": {"family": "COX_PH", "ties": "breslow"}}
    fitted = _execute_final_refit_engine("COX_PH", task, rows, responses, recipe)
    _assert_final_prediction_applications("COX_PH", task, rows, responses, recipe, fitted)


@pytest.mark.parametrize("family", ["COX_PH", "ELASTIC_NET_COX", "RSF", "GBM_COX", "FPM_TVC_SET_A"])
def test_retained_r_audit_numbers_consume_existing_native_evidence_without_refits(family, monkeypatch):
    """Reuse five already-fitted synthetic objects' original audit output."""
    from padml import f5
    root = os.environ.get("PADML_SCORE_AUDIT_EVIDENCE_ROOT")
    if root is None:
        pytest.skip("Requires the original five synthetic R audits; never regenerate models here")
    matches = []
    for path in sorted(Path(root).glob("test_paired_r_replay_keeps_ori*/object-audit")):
        task = strict_json_bytes((path / "task.json").read_bytes())
        if task["family"] == family:
            matches.append((path, task))
    assert len(matches) == 1
    path, task = matches[0]
    values = strict_json_bytes((path / "stdout.txt").read_bytes())
    health = strict_json_bytes((path / "fit-health.json").read_bytes())
    def forbidden(*args, **kwargs):
        pytest.fail("NUMERIC_AUDIT_CONSUMER_MAY_NOT_REFIT_OR_LOAD_NATIVE_OBJECTS")
    monkeypatch.setattr(f5.subprocess, "run", forbidden)
    monkeypatch.setattr(f5, "_execute_final_refit_engine", forbidden)
    monkeypatch.setattr(f5, "_validate_retained_model_objects", forbidden)
    assert f5._validate_retained_r_audit_numbers(family, values, health, task) == values
    field = {"COX_PH": "covariance_rank", "ELASTIC_NET_COX": "alpha", "RSF": "tree_count",
             "GBM_COX": "tree_count", "FPM_TVC_SET_A": "covariance_rank"}[family]
    with pytest.raises(ContractError):
        f5._validate_retained_r_audit_numbers(family, {**values, field: values[field] + 1}, health, task)
    with pytest.raises(ContractError):
        f5._validate_retained_r_audit_numbers(family, {}, health, task)
    if family == "COX_PH":
        changed = copy.deepcopy(values)
        index = next(index for index, se in enumerate(values["within_standard_errors"]) if se > 0)
        changed["within_standard_errors"][index] *= 2
        with pytest.raises(ContractError, match="RETAINED_COEFFICIENT_COVARIANCE_DRIFT"):
            f5._validate_retained_r_audit_numbers(family, changed, health, task)


@pytest.mark.parametrize("family", ["COX_PH", "ELASTIC_NET_COX", "RSF", "GBM_COX", "FPM_TVC_SET_A"])
def test_paired_r_replay_keeps_original_populations_and_independent_audit(family, tmp_path, monkeypatch):
    """Synthetic native objects from the frozen pre-change kernel, not clinical fits."""
    baseline_kernel = os.environ.get("PADML_REPLAY_BASELINE_KERNEL")
    if baseline_kernel is None:
        pytest.skip("Requires the verified frozen pre-change R kernel on the engineering host")
    np = pytest.importorskip("numpy")
    rng = np.random.default_rng(71239)
    times, events = rng.exponential(10, 400) + .01, rng.binomial(1, .75, 400)
    values = rng.uniform(.2, 3, 400)
    rows = [{"Patient_ID": f"SYNTHETIC-replay-{index:04d}", "Center": "36", "AST_ALT": str(values[index])}
            for index in range(400)]
    response = {row["Patient_ID"]: {"Patient_ID": row["Patient_ID"], "All_Cause_Death": str(events[index]),
                                  "Death_Followup_months": str(times[index])} for index, row in enumerate(rows)}
    recipe, _ = _raw_final_recipe(family)
    parameters = {"family": family, "ties": "breslow"}
    if family == "FPM_TVC_SET_A":
        parameters = {"family": family, "df": [3, 1], "tvc_parent": "AST_ALT"}
    elif family == "GBM_COX":
        parameters = {"family": family, "selected_trees": 20, "parameters": {
            "interaction.depth": 2, "shrinkage": .05, "n.minobsinnode": 20, "bag.fraction": .8,
            "n.trees.max": 5000, "early_stopping_metric": "cox_deviance",
            "post_selection_refit": "full_main_training_at_selected_n_trees",
            "locked_iteration_mode": "full_main_training_without_reselection"}}
    elif family == "RSF":
        parameters = {"family": family, "candidate_id": "RSF::SYNTHETIC::001", "parameters": {
            "num.trees": 80, "mtry_fraction": "0.50", "min.node.size": 5, "max.depth": 3,
            "sample.fraction": .632, "splitrule": "logrank"}}
    elif family == "ELASTIC_NET_COX":
        parameters = {"family": family, "alpha": .5, "ratio": .5, "lambda": .1, "lambda_upper_bound": {
            "schema_version": "1.0.0", "kind": "PADML_F2_ELASTIC_LAMBDA_UPPER_BOUND_V1", "glmnet_version": "5.0",
            "family": "cox", "cox_ties": "breslow", "alpha": .5, "standardize": True,
            "pilot_requested_nlambda": 100, "pilot_returned_nlambda": 100, "pilot_lambda_head": [.2, .1, .05],
            "resolved_lambda_max": .2, "glmnet_big": 9.9e35, "sentinel_equivalent": False,
            "penalty_factor_identity_sha256": sha256_bytes(canonical_json_bytes({
                "design_columns": ["AST_ALT", "PADML_GLMNET_INERT_ZERO"], "penalty_factor": [0.0, 1.0]}))}}
    task = {"family": family, "selected_parents": ["AST_ALT"], "imputation": 1, "parameters": parameters,
            "family_design_column_count": 1, "row_count": len(rows),
            "model_seed": 300000 if family in {"RSF", "GBM_COX"} else None}
    original_run, calls = subprocess.run, []
    def native(command, **kwargs):
        if Path(command[2]).name == "f5_final_refit.R":
            spec = strict_json_bytes(Path(command[3]).read_bytes())
            calls.append(spec["action"])
            if spec["action"] == "FINAL_REFIT":
                assert calls == ["FINAL_REFIT"]
                command = [*command[:2], baseline_kernel, *command[3:]]
        else:
            assert Path(command[2]).name == "retained-object-audit.R"
            calls.append("INDEPENDENT_OBJECT_AUDIT")
        return original_run(command, **kwargs)
    monkeypatch.setattr("padml.f5.subprocess.run", native)
    fitted = _execute_final_refit_engine(family, task, rows, response, recipe)
    objects = fitted["model"], fitted["baseline"]
    _validate_retained_model_objects(family, *objects, fitted["fit_health"], task,
                                     native_evidence=tmp_path / "object-audit")
    application = [{**rows[index], "Patient_ID": f"SYNTHETIC-new-{index}"} for index in (2, 0, 1)]
    paired = _execute_final_refit_engine(family, task, rows, response, recipe, retained_objects=objects,
        prediction_rows=application, replay_training=True, replay_evidence=tmp_path / "paired")
    assert calls == ["FINAL_REFIT", "INDEPENDENT_OBJECT_AUDIT", "REPLAY"]
    training = _execute_final_refit_engine(family, task, rows, response, recipe, retained_objects=objects)
    predicted = _execute_final_refit_engine(family, task, rows, response, recipe,
        retained_objects=objects, prediction_rows=application)
    assert paired == {"training_survival": training["survival"], "survival": predicted["survival"]}
    assert paired["training_survival"] == fitted["survival"]
    assert paired["survival"] == [fitted["survival"][index] for index in (2, 0, 1)]
    assert calls.count("FINAL_REFIT") == 1 and calls.count("REPLAY") == 3
    bad = [{**application[0], "All_Cause_Death": "1"}]
    with pytest.raises(ContractError, match="F5_REPLAY_APPLICATION_INPUT_INVALID"):
        _execute_final_refit_engine(family, task, rows, response, recipe, retained_objects=objects,
                                   prediction_rows=bad, replay_training=True)
    assert calls.count("REPLAY") == 3


@pytest.mark.parametrize("case", ["fit", "no_application", "python", "non_bool"])
def test_paired_r_replay_rejects_invalid_scope_before_engine(monkeypatch, case):
    monkeypatch.setattr("padml.f5.subprocess.run", lambda *a, **k: pytest.fail("No engine may start"))
    with pytest.raises(ContractError, match="F5_REPLAY_TRAINING_SCOPE_INVALID"):
        _execute_final_refit_engine("XGBOOST_COX" if case == "python" else "COX_PH", {}, [], {}, {},
            retained_objects=None if case == "fit" else (b"model", b"baseline"),
            prediction_rows=None if case == "no_application" else [{}],
            replay_training=1 if case == "non_bool" else True)


@pytest.mark.parametrize("bad_case", [
    "empty", "duplicate", "outcome", "time", "missing_predictor",
    "missing_center", "fit_with_application",
])
def test_final_application_rejects_invalid_rows_before_any_engine(monkeypatch, bad_case) -> None:
    rows, responses, _, _ = _python_final_refit_rows()
    recipe, _ = _raw_final_recipe("COX_PH")
    task = {"selected_parents": ["AST_ALT"], "model_seed": None,
            "parameters": {"family": "COX_PH", "ties": "breslow"}}
    application = [dict(rows[0])]
    if bad_case == "empty":
        application = []
    elif bad_case == "duplicate":
        application *= 2
    elif bad_case in {"outcome", "time"}:
        application[0]["All_Cause_Death" if bad_case == "outcome" else "Death_Followup_months"] = "1"
    elif bad_case == "missing_predictor":
        del application[0]["AST_ALT"]
    elif bad_case == "missing_center":
        del application[0]["Center"]
    def forbid_engine(*args, **kwargs):
        raise AssertionError("Invalid application must not enter a model engine")
    monkeypatch.setattr("padml.f5.subprocess.run", forbid_engine)
    with pytest.raises(ContractError, match="F5_REPLAY_APPLICATION_INPUT_INVALID"):
        _execute_final_refit_engine(
            "COX_PH", task, rows, responses, recipe,
            retained_objects=None if bad_case == "fit_with_application" else (b"model", b"baseline"),
            prediction_rows=application,
        )


def _shap_test_input_bundle(
    root: Path,
    task: dict,
    recipe: dict,
    rows: list[dict],
    responses: dict,
) -> Path:
    covariates = io.StringIO(newline="")
    covariate_writer = csv.DictWriter(
        covariates, fieldnames=list(rows[0]), lineterminator="\n"
    )
    covariate_writer.writeheader()
    covariate_writer.writerows(rows)
    response = io.StringIO(newline="")
    response_writer = csv.DictWriter(
        response,
        fieldnames=[
            "Patient_ID", "All_Cause_Death", "Death_Followup_months"
        ],
        lineterminator="\n",
    )
    response_writer.writeheader()
    response_writer.writerows(
        responses[row["Patient_ID"]] for row in rows
    )
    target = (root / f"{task['family'].lower()}-shap-input.zip").resolve()
    write_deterministic_zip(target, {
        "plan.json": canonical_json_bytes({}),
        "task.json": canonical_json_bytes(task),
        "family-decision.json": canonical_json_bytes({}),
        "recipe.json": canonical_json_bytes({"recipe": recipe}),
        "covariates.csv": covariates.getvalue().encode(),
        "response.csv": response.getvalue().encode(),
    })
    return target


def test_final_xgboost_matches_locked_reference_bitwise(
    monkeypatch, tmp_path: Path,
) -> None:
    np = pytest.importorskip("numpy")
    xgb = pytest.importorskip("xgboost")
    recipe, _ = _raw_final_recipe("XGBOOST_COX")
    rows, responses, times, events = _python_final_refit_rows()
    parameters = {
        "eta": 0.05,
        "max_depth": 2,
        "min_child_weight": 2.0,
        "subsample": 0.8,
        "colsample_bytree": 0.8,
        "reg_lambda": 1.0,
        "reg_alpha": 0.0,
        "gamma": 0.0,
        "tree_method": "hist",
        "max_bin": 256,
        "max_nrounds": 20,
        "stop_scope": "training_only",
        "post_selection_refit": "full_main_training_at_best_rounds",
        "locked_iteration_mode": "full_main_training_without_reselection",
    }
    task = {
        "family": "XGBOOST_COX",
        "imputation": 1,
        "selected_parents": ["AST_ALT"],
        "parameters": {
            "family": "XGBOOST_COX",
            "candidate_id": "XGBOOST_COX::TEST::001",
            "parameters": parameters,
            "selected_rounds": 5,
        },
        "model_seed": 300_000,
    }
    direct = _execute_final_xgboost(task, rows, responses, recipe)
    matrix = np.asarray(
        [[float(row["AST_ALT"])] for row in rows], dtype=float
    )
    reference = _xgb_refit_predict(
        xgb,
        parameters,
        matrix,
        np.asarray(times, dtype=float),
        np.asarray(events, dtype=int),
        matrix,
        5,
        300_000,
        "CPU",
        HORIZONS,
        np,
    )
    assert np.array_equal(
        np.asarray(direct["survival"]), reference["survival"]
    )
    model = xgb.Booster()
    model.load_model(bytearray(direct["model"]))
    assert model.num_boosted_rounds() == 5
    baseline = strict_json_bytes(direct["baseline"])
    assert baseline["kind"] == "PADML_F5_XGBOOST_BRESLOW_BASELINE_V1"
    assert baseline["design_columns"] == ["AST_ALT"]
    def forbid_refit(*args, **kwargs):
        raise AssertionError("Replay must not train XGBoost")
    monkeypatch.setattr(xgb, "train", forbid_refit)
    replayed = _execute_final_refit_engine(
        "XGBOOST_COX", task, rows, responses, recipe,
        retained_objects=(direct["model"], direct["baseline"]),
    )
    assert replayed["survival"] == direct["survival"]
    _assert_final_prediction_applications("XGBOOST_COX", task, rows, responses, recipe, direct)
    invalid_baseline = copy.deepcopy(baseline)
    invalid_baseline["cumulative_baseline_hazard"][-1] = -1.0
    with pytest.raises(ContractError, match="F5_REPLAY_BASELINE_INVALID"):
        _execute_final_refit_engine(
            "XGBOOST_COX", task, rows, responses, recipe,
            retained_objects=(direct["model"], canonical_json_bytes(invalid_baseline)),
        )
    component = _produce_final_shap_component(
        _shap_test_input_bundle(tmp_path, task, recipe, rows, responses),
        task,
        direct["model"],
        direct["baseline"],
        {
            "family": "XGBOOST_COX",
            "imputation": 1,
            "patient_ids": [row["Patient_ID"] for row in rows],
            "survival": direct["survival"],
        },
    )
    assert component["engine"]["version"] == "0.9.1"
    assert component["selected_parent_groups"] == ["AST_ALT"]


def test_final_elastic_single_parent_uses_verified_inert_engine_column(
    tmp_path: Path,
) -> None:
    rows, responses, _, _ = _python_final_refit_rows()
    recipe, _ = _raw_final_recipe("ELASTIC_NET_COX")
    task = {
        "family": "ELASTIC_NET_COX",
        "imputation": 1,
        "selected_parents": ["AST_ALT"],
        "parameters": {
            "family": "ELASTIC_NET_COX",
            "alpha": 0.5,
            "ratio": 0.5,
            "lambda": 0.1,
            "lambda_upper_bound": {
                "schema_version": "1.0.0",
                "kind": "PADML_F2_ELASTIC_LAMBDA_UPPER_BOUND_V1",
                "glmnet_version": "5.0",
                "family": "cox",
                "cox_ties": "breslow",
                "alpha": 0.5,
                "standardize": True,
                "pilot_requested_nlambda": 100,
                "pilot_returned_nlambda": 100,
                "pilot_lambda_head": [0.2, 0.1, 0.05],
                "resolved_lambda_max": 0.2,
                "glmnet_big": 9.9e35,
                "sentinel_equivalent": False,
                "penalty_factor_identity_sha256": sha256_bytes(
                    canonical_json_bytes({
                        "design_columns": [
                            "AST_ALT", "PADML_GLMNET_INERT_ZERO"
                        ],
                        "penalty_factor": [0.0, 1.0],
                    })
                ),
            },
        },
        "model_seed": None,
    }
    fitted = _execute_final_refit_engine(
        "ELASTIC_NET_COX", task, rows, responses, recipe
    )
    assert fitted["fit_health"]["engine"] == "glmnet::glmnet"
    assert fitted["fit_health"]["converged"] is True
    replayed = _execute_final_refit_engine(
        "ELASTIC_NET_COX", task, rows, responses, recipe,
        retained_objects=(fitted["model"], fitted["baseline"]),
    )
    assert replayed["survival"] == fitted["survival"]
    _assert_final_prediction_applications("ELASTIC_NET_COX", task, rows, responses, recipe, fitted)
    assert len(fitted["survival"]) == len(rows)
    assert all(row[0] == 1.0 for row in fitted["survival"])
    component = _produce_final_shap_component(
        _shap_test_input_bundle(tmp_path, task, recipe, rows, responses),
        task,
        fitted["model"],
        fitted["baseline"],
        {
            "family": "ELASTIC_NET_COX",
            "imputation": 1,
            "patient_ids": [row["Patient_ID"] for row in rows],
            "survival": fitted["survival"],
        },
    )
    assert component["estimand"]["risk_contribution"] == (
        "NEGATIVE_SURVIVAL_CONTRIBUTION"
    )


def test_final_rsf_accepts_categorical_design_column_names(
    tmp_path: Path,
) -> None:
    rows, responses, _, _ = _python_final_refit_rows()
    predictors = predictor_contract(
        Path(__file__).resolve().parents[1] / "padml"
    )
    by_name = {row["name"]: row for row in predictors["variables"]}
    selected = ["AST_ALT", "Rutherford_cat"]
    levels = ["Grade 0-2", "Grade 3-4", "Grade 5-6"]
    for index, row in enumerate(rows):
        row["Rutherford_cat"] = levels[index % len(levels)]
    recipe = {
        "schema_version": "1.0.0",
        "kind": "PADML_F5_FINAL_DESIGN_RECIPE_V1",
        "family": "RSF",
        "selected_parents": selected,
        "preprocessing_mode": "F2_RAW_CANONICAL_AUTHORITY_LEVELS",
        "predictor_contract_sha256": sha256_bytes(
            canonical_json_bytes(predictors)
        ),
        "predictor_rows": [
            row for row in predictors["variables"]
            if row["name"] in selected
        ],
        "transform_recipe": None,
        "coxtime_standardization": None,
    }
    task = {
        "family": "RSF",
        "imputation": 1,
        "selected_parents": selected,
        "parameters": {
            "family": "RSF",
            "parameters": {
                "num.trees": 80,
                "mtry_fraction": "0.50",
                "min.node.size": 5,
                "max.depth": 3,
                "sample.fraction": 0.632,
                "splitrule": "logrank",
            },
        },
        "model_seed": 300_000,
    }
    fitted = _execute_final_refit_engine(
        "RSF", task, rows, responses, recipe
    )
    assert set(fitted["fit_health"]) == {
        "engine_threads",
        "final_model_fit_count",
        "engine",
        "num_trees",
        "converged",
        "warning_count",
        "tree_count",
        "independent_variable_count",
        "mtry",
        "death_time_count",
        "prediction_error",
    }
    assert {
        key: fitted["fit_health"][key]
        for key in (
            "engine_threads", "final_model_fit_count", "engine", "num_trees",
            "converged", "warning_count", "tree_count",
            "independent_variable_count", "mtry",
        )
    } == {
        "engine_threads": 1,
        "final_model_fit_count": 1,
        "engine": "ranger::ranger",
        "num_trees": 80,
        "converged": True,
        "warning_count": 0,
        "tree_count": 80,
        "independent_variable_count": 4,
        "mtry": 2,
    }
    assert fitted["fit_health"]["death_time_count"] > 0
    assert math.isfinite(fitted["fit_health"]["prediction_error"])
    replayed = _execute_final_refit_engine(
        "RSF", task, rows, responses, recipe,
        retained_objects=(fitted["model"], fitted["baseline"]),
    )
    assert replayed["survival"] == fitted["survival"]
    _assert_final_prediction_applications("RSF", task, rows, responses, recipe, fitted)
    assert len(fitted["survival"]) == len(rows)
    assert all(
        all(math.isfinite(value) for value in prediction)
        for prediction in fitted["survival"]
    )
    component = _produce_final_shap_component(
        _shap_test_input_bundle(tmp_path, task, recipe, rows, responses),
        task,
        fitted["model"],
        fitted["baseline"],
        {
            "family": "RSF",
            "imputation": 1,
            "patient_ids": [row["Patient_ID"] for row in rows],
            "survival": fitted["survival"],
        },
    )
    assert component["selected_parent_groups"] == [
        "AST_ALT", "Rutherford_cat"
    ]
    assert component["engine"]["exact"] is True


@pytest.mark.parametrize("family", ["GBM_COX", "FPM_TVC_SET_A"])
def test_final_gbm_fpm_saved_objects_replay_without_fitting(family, tmp_path: Path) -> None:
    np = pytest.importorskip("numpy")
    rng = np.random.default_rng(71239)
    times = rng.exponential(10, 400) + .01
    events = rng.binomial(1, .75, 400)
    ast_alt = rng.uniform(.2, 3, 400)
    rows = [{"Patient_ID": f"replay-{i:04d}", "Center": "36", "AST_ALT": str(ast_alt[i])}
            for i in range(400)]
    responses = {row["Patient_ID"]: {
        "Patient_ID": row["Patient_ID"], "All_Cause_Death": str(events[i]),
        "Death_Followup_months": str(times[i]),
    } for i, row in enumerate(rows)}
    recipe, _ = _raw_final_recipe(family)
    parameters = {"family": family, "df": [3, 1], "tvc_parent": "AST_ALT"}
    if family == "GBM_COX":
        parameters = {
            "family": family, "selected_trees": 20,
            "parameters": {"interaction.depth": 2, "shrinkage": .05,
                "n.minobsinnode": 20, "bag.fraction": .8, "n.trees.max": 5000,
                "early_stopping_metric": "cox_deviance",
                "post_selection_refit": "full_main_training_at_selected_n_trees",
                "locked_iteration_mode": "full_main_training_without_reselection"},
        }
    task = {"selected_parents": ["AST_ALT"], "parameters": parameters,
            "model_seed": 300000 if family == "GBM_COX" else None}
    fitted = _execute_final_refit_engine(family, task, rows, responses, recipe)
    (tmp_path / "model.rds").write_bytes(fitted["model"])
    (tmp_path / "baseline.rds").write_bytes(fitted["baseline"])
    (tmp_path / "fit-result.json").write_bytes(canonical_json_bytes({
        "family": family, "fit_health": fitted["fit_health"],
        "survival": fitted["survival"],
    }))
    replayed = _execute_final_refit_engine(
        family, task, rows, responses, recipe,
        retained_objects=(fitted["model"], fitted["baseline"]),
    )
    assert replayed == {"survival": fitted["survival"]}
    assert fitted["fit_health"]["final_model_fit_count"] == 1
    _assert_final_prediction_applications(family, task, rows, responses, recipe, fitted)


@pytest.mark.parametrize("failure_kind", ["native_input", "timeout"])
def test_final_r_failure_preserves_native_evidence(monkeypatch, tmp_path: Path, failure_kind) -> None:
    monkeypatch.setattr("padml.f5.tempfile.tempdir", str(tmp_path))
    recipe, _ = _raw_final_recipe("COX_PH")
    rows = [{"Patient_ID": f"invalid-{i:02d}", "Center": "36", "AST_ALT": "1.5"}
            for i in range(20)]
    responses = {row["Patient_ID"]: {
        "Patient_ID": row["Patient_ID"], "All_Cause_Death": "1",
        "Death_Followup_months": "-1" if i == 0 else str(i + 1),
    } for i, row in enumerate(rows)}
    task = {"selected_parents": ["AST_ALT"], "parameters": {"family": "COX_PH", "ties": "breslow"},
            "model_seed": None}
    if failure_kind == "timeout":
        def timed_out(command, **options):
            options["stdout"].write("partial native stdout")
            options["stderr"].write("partial native stderr")
            (Path(command[-1]).parent / "model.rds").write_bytes(b"partial native object fixture")
            raise subprocess.TimeoutExpired(command, options["timeout"])
        monkeypatch.setattr("padml.f5.subprocess.run", timed_out)
    expected_error = subprocess.TimeoutExpired if failure_kind == "timeout" else ContractError
    with pytest.raises(expected_error) as caught:
        _execute_final_refit_engine("COX_PH", task, rows, responses, recipe)
    roots = list(tmp_path.glob("padml-f5-final-refit-*"))
    assert len(roots) == 1
    root = roots[0]
    assert caught.value.__notes__ == [f"F5_FINAL_REFIT_NATIVE_EVIDENCE_RETAINED:{root}"]
    for name in ("spec.json", "covariates.csv", "response.csv", "stdout.log", "stderr.log"):
        assert (root / name).is_file()
    if failure_kind == "native_input":
        assert "F5_R_RESPONSE_INVALID" in str(caught.value)
        assert (root / "native-failure.rda").stat().st_size > 0
        assert "F5_R_RESPONSE_INVALID" in (root / "stderr.log").read_text()
        assert not (root / "model.rds").exists()
    else:
        assert (root / "stdout.log").read_text() == "partial native stdout"
        assert (root / "stderr.log").read_text() == "partial native stderr"
        assert (root / "model.rds").read_bytes() == b"partial native object fixture"


def test_final_coxtime_retains_reconstructable_state_and_baseline(
    monkeypatch, tmp_path: Path,
) -> None:
    np = pytest.importorskip("numpy")
    torch = pytest.importorskip("torch")
    pytest.importorskip("pycox")
    pytest.importorskip("torchtuples")
    from pycox import models
    import torchtuples as tt

    recipe, _ = _raw_final_recipe("COXTIME_SET_A")
    rows, responses, times, events = _python_final_refit_rows()
    candidate = load_science_authority()["science"][
        "f2_model_development"
    ]["coxtime"]["candidates"][0]
    task = {
        "family": "COXTIME_SET_A",
        "imputation": 1,
        "selected_parents": ["AST_ALT"],
        "parameters": {
            "family": "COXTIME_SET_A",
            "candidate_id": candidate["candidate_id"],
            "parameters": candidate,
            "locked_epoch": 30,
        },
        "model_seed": 300_000,
    }
    fitted = _execute_final_coxtime(task, rows, responses, recipe)
    state = torch.load(io.BytesIO(fitted["model"]), weights_only=True)
    assert state["format"] == "PADML_F5_COXTIME_STATE_DICT_V1"
    assert state["candidate"] == candidate
    assert state["input_width"] == 1
    assert state["state_dict"]
    baseline = strict_json_bytes(fitted["baseline"])
    assert baseline["kind"] == "PADML_F5_COXTIME_BASELINE_V1"
    assert baseline["design_columns"] == ["AST_ALT"]
    assert len(fitted["survival"]) == len(rows)
    assert all(row[0] == 1.0 for row in fitted["survival"])
    assert fitted["fit_health"]["training_epoch_count"] == 30
    matrix = np.asarray(
        [[float(row["AST_ALT"])] for row in rows], dtype=float
    )
    reference = _coxtime_refit_predict(
        (models, torch, tt),
        candidate,
        matrix,
        np.asarray(times, dtype=float),
        np.asarray(events, dtype=int),
        matrix,
        30,
        300_000,
        "CPU",
        HORIZONS,
        np,
    )
    assert np.array_equal(
        np.asarray(fitted["survival"]), reference["survival"]
    )
    def forbid_refit(*args, **kwargs):
        raise AssertionError("Replay must not train CoxTime")
    monkeypatch.setattr(models.CoxTime, "fit", forbid_refit)
    replayed = _execute_final_refit_engine(
        "COXTIME_SET_A", task, rows, responses, recipe,
        retained_objects=(fitted["model"], fitted["baseline"]),
    )
    assert replayed["survival"] == fitted["survival"]
    invalid_baseline = copy.deepcopy(baseline)
    invalid_baseline["input_scale"][0] *= 2
    _assert_final_prediction_applications("COXTIME_SET_A", task, rows, responses, recipe, fitted)
    with pytest.raises(ContractError, match="F5_REPLAY_INPUT_SCALER_DRIFT"):
        _execute_final_refit_engine(
            "COXTIME_SET_A", task, rows, responses, recipe,
            retained_objects=(fitted["model"], canonical_json_bytes(invalid_baseline)),
        )
    component = _produce_final_shap_component(
        _shap_test_input_bundle(tmp_path, task, recipe, rows, responses),
        task,
        fitted["model"],
        fitted["baseline"],
        {
            "family": "COXTIME_SET_A",
            "imputation": 1,
            "patient_ids": [row["Patient_ID"] for row in rows],
            "survival": fitted["survival"],
        },
    )
    assert component["engine"]["package"] == "kernelshap"
    assert component["local_accuracy"]["status"] == "PASS"


def test_seal_final_parameter_lock_uses_fixed_spec_without_search() -> None:
    final_mice, final_seta, decision, _, _ = final_refit_compilation_inputs(
        "COX_PH"
    )
    sealed = seal_final_parameter_lock(
        final_mice, final_seta, decision, f4_handoff_fixture(decision), None
    )
    assert sealed["family"] == "COX_PH"
    assert sealed["selected_spec"]["source_mode"] == "FIXED_FORMAL_SPEC_NO_GRID"
    assert sealed["grid_rerun"] is False
    assert sealed["outer_parameter_reuse"] is False
    assert sealed["component_parameters"] == [
        {
            "imputation": imputation,
            "parameters": {"family": "COX_PH", "ties": "breslow"},
            "parameters_sha256": sha256_bytes(canonical_json_bytes({
                "family": "COX_PH", "ties": "breslow"
            })),
            "source_evidence_sha256": sha256_bytes(canonical_json_bytes({
                "family": "COX_PH", "ties": "breslow"
            })),
        }
        for imputation in range(1, 21)
    ]
    with pytest.raises(ContractError, match="F5_FIXED_FAMILY_SEARCH_FORBIDDEN"):
        seal_final_parameter_lock(
            final_mice, final_seta, decision, f4_handoff_fixture(decision),
            {"search": "forbidden"},
        )


def test_complex_final_parameter_lock_rejects_declarative_search_claim() -> None:
    final_mice, final_seta, decision, _, _ = final_refit_compilation_inputs(
        "GBM_COX"
    )
    declarative_claim = {
        "kind": "PADML_F5_VALIDATED_FINAL_SEARCH",
        "status": "PASS",
        "winning_configuration_actually_executed": True,
    }
    with pytest.raises(
        ContractError, match="F5_FINAL_NATIVE_Q_REQUIRED"
    ):
        seal_final_parameter_lock(
            final_mice, final_seta, decision, f4_handoff_fixture(decision),
            declarative_claim,
        )


def _executed_rsf_search_archive(
    decision: dict, handoff: dict, final_seta: dict
) -> tuple[dict, dict]:
    parameters = {
        "num.trees": 1000,
        "mtry_fraction": "0.50",
        "min.node.size": 15,
        "max.depth": "unlimited",
        "sample.fraction": 0.632,
        "splitrule": "logrank",
    }

    def candidate(stage: str, index: int) -> dict:
        value = copy.deepcopy(parameters)
        identity = sha256_bytes(canonical_json_bytes(value))
        return {
            "trial_id": f"RSF::SET_A::{stage}::{index:03d}",
            "parameters": value,
            "parameter_sha256": identity,
        }

    candidates = {
        "S1": [candidate("S1", index) for index in range(1, 25)],
        "S2": [candidate("S2", index) for index in range(1, 9)],
    }
    authority = load_science_authority()["science"]["f2_model_development"]
    bindings = [
        {
            "partition_id": f"F5_R{repeat:02d}_K{fold:02d}",
            "repeat": repeat,
            "inner_fold": fold,
        }
        for repeat in range(1, 4)
        for fold in range(1, 6)
    ]
    task_body = {
        "schema_version": "1.0.0",
        "kind": "PADML_F5_COMPLEX_FINAL_SEARCH_TASK",
        "status": "COMPILED_NOT_EXECUTED",
        "phase": "FINAL_SEARCH",
        "action": "FULL_DEVELOPMENT_M1_M5_M20_SEARCH",
        "candidate_protocol_amendment": (
            "2026-09-05 candidate protocol amendment"
        ),
        "family": "RSF",
        "family_decision_sha256": sha256_bytes(canonical_json_bytes(decision)),
        "f4_locked_family_handoff_sha256": handoff["identity_sha256"],
        "plan_sha256": sha256_bytes(b"full-development plan"),
        "final_seta_lock_sha256": final_seta["lock_sha256"],
        "selected_parents": ["AST_ALT"],
        "selected_design": [{"parent": "AST_ALT", "design_df": 1}],
        "search_partition_bindings": bindings,
        "search_partition_bindings_sha256": sha256_bytes(
            canonical_json_bytes(bindings)
        ),
        "candidate_trials": candidates,
        "candidate_trials_sha256": sha256_bytes(canonical_json_bytes(candidates)),
        "candidate_sequence": authority["candidate_sequence"],
        "search_space": authority["search_spaces"]["RSF"],
        "search_budget": authority["search_budgets"]["RSF"],
        "multifidelity": authority["multifidelity"],
        "trial_scoring": authority["trial_scoring"],
        "coxtime": None,
        "model_seed_base": 300_000,
        "stage_seed_offsets": {
            "S1": 10_000,
            "S2": 20_000,
            "S3A": 30_000,
            "S3B1": 40_000,
            "S3B2": 50_000,
        },
        "execution_profile": {
            "pool_workers": 20,
            "engine_threads": 1,
            "nested_pool": False,
            "refill": "DYNAMIC_ON_COMPLETION",
        },
        "outer_parameter_reuse": False,
        "heldout_or_ooc_read_count": 0,
        "final_model_fit_count": 0,
    }
    task = {
        **task_body,
        "task_sha256": sha256_bytes(canonical_json_bytes(task_body)),
    }

    def evaluated(
        stage: str,
        source: dict,
        score: float,
        units: int,
        partitions: int,
        rankings: int,
    ) -> dict:
        return {
            "stage_id": stage,
            "candidate_id": source["trial_id"],
            "parameters": copy.deepcopy(source["parameters"]),
            "parameter_sha256": source["parameter_sha256"],
            "metric_values": [score] * units,
            "fold_metric_values": [score] * partitions,
            "ranking_metric_values": [score] * rankings,
            "ranking_metric_qc": [{} for _ in range(rankings)],
            "ranking_evaluation_count": rankings,
            "mean_ibs": score,
            "maximum_ibs": score,
            "evaluation_units": units,
        }

    s1 = [
        evaluated("S1", row, 0.20 + index / 1000, 5, 5, 1)
        for index, row in enumerate(candidates["S1"], start=1)
    ]
    s2 = [
        evaluated("S2", row, 0.10 + index / 1000, 25, 5, 1)
        for index, row in enumerate(candidates["S2"], start=1)
    ]
    s3a = [
        evaluated("S3A", candidates["S2"][index], 0.08 + index / 1000, 100, 5, 1)
        for index in range(3)
    ]
    s3b1 = [
        evaluated("S3B1", candidates["S2"][index], 0.06 + index / 1000, 75, 15, 3)
        for index in range(2)
    ]
    s3b2 = [
        evaluated("S3B2", candidates["S2"][0], 0.05, 300, 15, 3)
    ]
    trace = {"S1": s1, "S2": s2, "S3A": s3a, "S3B1": s3b1, "S3B2": s3b2}
    selected_spec = {
        "family": "RSF",
        "candidate_id": candidates["S2"][0]["trial_id"],
        "parameters": copy.deepcopy(parameters),
        "selection_metric": "IBS_0_24",
        "selection_stage": "S3B2",
    }
    result_body = {
        "schema_version": "1.0.0",
        "kind": "PADML_SHARED_FULL_DEVELOPMENT_SEARCH_RESULT",
        "status": "PASS",
        "execution_scope": "F5_FULL_DEVELOPMENT_SEARCH",
        "family": "RSF",
        "registered_inputs_identity_sha256": "c" * 64,
        "candidate_trials_sha256": task["candidate_trials_sha256"],
        "selected_parents": ["AST_ALT"],
        "selected_spec": selected_spec,
        "selected_spec_sha256": sha256_bytes(canonical_json_bytes(selected_spec)),
        "search_trace": trace,
        "search_trace_sha256": sha256_bytes(canonical_json_bytes(trace)),
        "search_evaluation_unit_count": 1070,
        "response_free_stopping_fit_count": 0,
        "locked_training_refit_count": 1070,
        "total_search_fit_count": 1070,
        "seed_base": 300_000,
        "stage_seed_offsets": task["stage_seed_offsets"],
        "heldout_or_ooc_read_count": 0,
        "outer_parameter_reuse": False,
        "final_model_fit_count": 0,
    }
    result = {
        **result_body,
        "identity_sha256": sha256_bytes(canonical_json_bytes(result_body)),
    }
    from padml.f5 import _final_search_sources
    source_members = _final_search_sources()
    evidence = {
        "producer": "SHARED_F2_COMPLEX_SEARCH_FUNNEL_V1",
        "task_sha256": task["task_sha256"],
        "registered_inputs_identity_sha256": "c" * 64,
        "development_input": {
            "mice_plan_sha256": task["plan_sha256"],
            "raw_covariates_sha256": sha256_bytes(b"UNFITTED raw covariates"),
            "response_sha256": sha256_bytes(b"UNFITTED response"),
        },
        "source_members": source_members,
        "source_members_sha256": sha256_bytes(canonical_json_bytes(source_members)),
        "heldout_or_ooc_read_count": 0,
        "final_model_fit_count": 0,
    }
    archive_body = {
        "schema_version": "1.0.0",
        "kind": "PADML_F5_COMPLEX_FINAL_SEARCH_EXECUTION_ARCHIVE",
        "status": "PASS",
        "task": task,
        "result": result,
        "execution_evidence": evidence,
        "members": {"UNFITTED_FIXTURE_NOT_NATIVE_PROOF": {"sha256": sha256_bytes(b"fixture"), "size_bytes": 7}},
    }
    archive = {
        **archive_body,
        "identity_sha256": sha256_bytes(canonical_json_bytes(archive_body)),
    }
    return archive, candidates


def _reseal_complex_archive(archive: dict) -> None:
    result = archive["result"]
    result["search_trace_sha256"] = sha256_bytes(
        canonical_json_bytes(result["search_trace"])
    )
    result["identity_sha256"] = sha256_bytes(canonical_json_bytes({
        key: value for key, value in result.items() if key != "identity_sha256"
    }))
    archive["identity_sha256"] = sha256_bytes(canonical_json_bytes({
        key: value for key, value in archive.items() if key != "identity_sha256"
    }))


def test_complex_search_archive_replays_candidate_stream_and_promotions(
    monkeypatch,
) -> None:
    # This is only the arithmetic layer; the public lock requires physical Q.
    from padml.f5 import _seal_final_parameter_lock
    final_mice, final_seta, decision, _, _ = final_refit_compilation_inputs("RSF")
    handoff = f4_handoff_fixture(decision)
    archive, candidates = _executed_rsf_search_archive(
        decision, handoff, final_seta
    )
    final_mice["development_input"] = copy.deepcopy(
        archive["execution_evidence"]["development_input"]
    )
    monkeypatch.setattr(
        "padml.f5._final_complex_candidate_trials",
        lambda family: copy.deepcopy(candidates),
    )
    sealed = _seal_final_parameter_lock(
        final_mice, final_seta, decision, handoff, archive
    )
    assert sealed["selected_spec"]["source_mode"] == (
        "EXECUTED_FULL_DEVELOPMENT_M1_M5_M20"
    )
    assert sealed["selected_spec"]["selected_candidate_id"] == (
        "RSF::SET_A::S2::001"
    )
    assert len({
        row["parameters_sha256"] for row in sealed["component_parameters"]
    }) == 1

    drifted = copy.deepcopy(archive)
    drifted["result"]["search_trace"]["S3A"][:2] = reversed(
        drifted["result"]["search_trace"]["S3A"][:2]
    )
    _reseal_complex_archive(drifted)
    with pytest.raises(ContractError, match="F5_COMPLEX_SEARCH_PROMOTION_DRIFT"):
        _seal_final_parameter_lock(
            final_mice, final_seta, decision, handoff, drifted
        )


def test_post_stability_elastic_lock_rejects_reducer_only_source() -> None:
    final_mice, final_seta, decision, _, _ = final_refit_compilation_inputs(
        "ELASTIC_NET_COX"
    )
    _, _, decision, _, _ = final_refit_compilation_inputs("RSF")
    handoff = f4_handoff_fixture(
        decision, locked_family="ELASTIC_NET_COX"
    )
    assert decision["selected_family"] == "RSF"
    provenance = [
        {"resolved_lambda_max": float(imputation + 1)}
        for imputation in range(1, 21)
    ]
    ratios = [0.5] * 20
    lambdas = [
        row["resolved_lambda_max"] * ratio
        for row, ratio in zip(provenance, ratios, strict=True)
    ]
    body = {
        "schema_version": "1.0.0",
        "kind": "PADML_F5_A16_PARAMETER_LOCK",
        "status": "PASS",
        "task_sha256": sha256_bytes(b"a16 task"),
        "family": "ELASTIC_NET_COX",
        "family_decision_sha256": sha256_bytes(
            canonical_json_bytes(decision)
        ),
        "f4_locked_family_handoff_sha256": handoff["identity_sha256"],
        "final_seta_lock_sha256": final_seta["lock_sha256"],
        "final_mice_manifest_sha256": final_mice["mice_manifest_sha256"],
        "common_alpha": 0.5,
        "ratio_by_imputation": ratios,
        "lambda_by_imputation": lambdas,
        "lambda_upper_bound_by_imputation": provenance,
        "selected_parents": final_seta["lock"]["selected_parents"],
        "heldout_or_ooc_read_count": 0,
        "seta_writeback": "FORBIDDEN",
        "scientific_constraints_relaxed": False,
        "final_model_fit_count": 0,
    }
    source = {
        **body,
        "identity_sha256": sha256_bytes(canonical_json_bytes(body)),
    }
    with pytest.raises(
        ContractError, match="F5_A16_EXECUTION_ARCHIVE_INVALID"
    ):
        seal_final_parameter_lock(
            final_mice, final_seta, decision, handoff, source,
        )


def test_full_data_search_partition_pairs_analysis_and_application_views(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    keys, centers, events = resampling_input()
    source_ids = [f"raw-patient-{index}" for index in range(len(keys))]
    plan = compile_full_data_mice_plan(source_ids, keys, centers, events, family="XGBOOST_COX", workers=24)
    tasks = [
        task for task in compile_full_data_search_mice_tasks(plan)
        if task["split_id"] in {"F5_R01_K01", "F5_STOP_R01_K01"}
    ]
    response = private_response(source_ids, events)
    monkeypatch.setattr("padml.f5.subprocess.run", fake_mice_run)
    payloads = {}
    for task in tasks:
        target = tmp_path / f"{task['split_id']}-{task['role'].lower()}.zip"
        execute_full_data_search_mice_view(
            plan,
            task,
            private_covariates(source_ids, centers),
            search_analysis_response(plan, task, response)
            if task["role"] == "ANALYSIS" else None,
            target,
        )
        payloads[(task["split_id"], task["role"])] = target
    partition = materialize_full_data_search_partition(
        plan,
        "F5_R01_K01",
        payloads[("F5_R01_K01", "ANALYSIS")],
        payloads[("F5_R01_K01", "APPLICATION")],
        response,
        tmp_path / "partition",
        stop_analysis_payload=payloads[("F5_STOP_R01_K01", "ANALYSIS")],
        stop_application_payload=payloads[("F5_STOP_R01_K01", "APPLICATION")],
    )
    assert partition["kind"] == "INNER"
    assert partition["repeat"] == partition["inner_fold"] == 1
    assert set(partition["fit_ids"]).isdisjoint(partition["evaluation_ids"])
    assert set(partition["fit_ids"]) | set(partition["evaluation_ids"]) == set(
        source_ids
    )
    with Path(
        partition["covariates"]["input_dir"], "imp01.csv"
    ).open(newline="") as handle:
        combined = {row["Patient_ID"]: row for row in csv.DictReader(handle)}
    assert {combined[patient_id]["Age"] for patient_id in partition["fit_ids"]} == {
        "101"
    }
    assert {
        combined[patient_id]["Age"] for patient_id in partition["evaluation_ids"]
    } == {"202"}
    assert partition["fit_response"]["row_count"] == len(partition["fit_ids"])
    assert partition["evaluation_response"]["row_count"] == len(
        partition["evaluation_ids"]
    )
    stopping = partition["stopping"]
    assert stopping["seed"] == 250101
    assert set(stopping["fit_ids"]).isdisjoint(stopping["evaluation_ids"])
    assert set(stopping["fit_ids"]) | set(stopping["evaluation_ids"]) == set(
        partition["fit_ids"]
    )
    _, full_response_rows = _response_rows(response)
    assert {
        int(full_response_rows[patient]["All_Cause_Death"])
        for patient in stopping["fit_ids"]
    } == {0, 1}
    assert {
        int(full_response_rows[patient]["All_Cause_Death"])
        for patient in stopping["evaluation_ids"]
    } == {0, 1}
    assert set(stopping["application_ids"]).isdisjoint(partition["evaluation_ids"])
    assert stopping["fit_response"]["row_count"] == len(stopping["fit_ids"])
    assert stopping["evaluation_response"]["row_count"] == len(
        stopping["evaluation_ids"]
    )
    assert len(stopping["evaluation_ids"]) == round(0.15 * len(partition["fit_ids"]))
    # This new-key fixture has 18 members per event and STOP size five:
    # the unchanged largest-remainder tie gives event 0 three, event 1 two.
    expected_stop = set()
    for event, count in ((0, 3), (1, 2)):
        members = [patient for patient in partition["fit_ids"]
                   if int(full_response_rows[patient]["All_Cause_Death"]) == event]
        assert len(members) == 18
        expected_stop.update(sorted(members, key=lambda patient: sha256_bytes(
            f"250101|{event}|{sha256_bytes(patient.encode())}".encode()))[:count])
    assert stopping["evaluation_ids"] == [patient for patient in partition["fit_ids"]
                                           if patient in expected_stop]
    assert not (tmp_path / "partition/analysis").exists()
    assert not (tmp_path / "partition/application").exists()


def test_application_mice_view_cannot_receive_response_bytes(tmp_path: Path) -> None:
    keys, centers, events = resampling_input()
    source_ids = [f"raw-patient-{index}" for index in range(len(keys))]
    plan = compile_full_data_mice_plan(source_ids, keys, centers, events, family="ELASTIC_NET_COX", workers=24)
    task = next(
        task
        for task in compile_full_data_search_mice_tasks(plan)
        if task["role"] == "APPLICATION"
    )
    with pytest.raises(ContractError, match="F5_MICE_VIEW_EXECUTION_INPUT_INVALID"):
        execute_full_data_search_mice_view(
            plan,
            task,
            private_covariates(source_ids, centers),
            b"outcome-visible",
            tmp_path / "forbidden.zip",
        )


def final_seta_fixture() -> list[dict]:
    results = []
    for fold in range(1, 7):
        selected = {"StableOne"}
        negative = set()
        if fold <= 4:
            selected.update({"StableSpline", "DirectionConflict"})
            if fold >= 3:
                negative.add("DirectionConflict")
        results.append(selector_result_fixture(fold, selected, negative))
    return results


def test_final_seta_replays_six_primary_paths_and_applies_fixed_rules() -> None:
    results = final_seta_fixture()
    compiled = compile_final_seta(list(reversed(results)), 180)
    assert compiled["status"] == "COMPILED_AWAITING_F4_FAMILY_LOCK"
    assert compiled["lock"]["selected_parents"] == [
        "AST_ALT", "StableOne", "StableSpline",
    ]
    assert compiled["lock"]["common_set_design_df"] == 4
    assert compiled["lock"]["common_set_epv"] == 45
    assert compiled["outer_frequency"]["StableOne"]["selected_folds"] == 6
    assert compiled["outer_frequency"]["StableSpline"]["selected_folds"] == 4
    assert compiled["direction_consistency"]["StableSpline"] == {
        "applicability": "NOT_APPLICABLE_MULTI_DF", "eligible": True,
    }
    conflict = compiled["direction_consistency"]["DirectionConflict"]
    assert conflict["consistency_rate"] == 0.5
    assert conflict["eligible"] is False
    assert compiled["direction_excluded_parents"] == ["DirectionConflict"]
    assert compiled["policy"]["mrmre_boruta_role"] == (
        "SENSITIVITY_ONLY_NO_PRIMARY_WRITEBACK"
    )
    assert compiled["policy"]["heldout_performance_read_count"] == 0
    assert compiled["policy"]["grid_rerun"] is False
    assert compiled["model_fit_count"] == 0


def test_final_seta_missing_or_modified_path_is_error_not_exclusion() -> None:
    missing = final_seta_fixture()
    missing[0]["search_trace"]["derivation_records"][0]["outer_paths"].pop()
    missing[0]["search_trace_sha256"] = sha256_bytes(
        canonical_json_bytes(missing[0]["search_trace"])
    )
    with pytest.raises(ContractError, match="F5_FINAL_SETA_CHOSEN_PATH_INVALID"):
        compile_final_seta(missing, 180)

    modified = final_seta_fixture()
    path = modified[0]["search_trace"]["derivation_records"][0]["outer_paths"][0]
    path["parent_coefficients"]["StableOne"][0][0] = 0.125
    modified[0]["search_trace_sha256"] = sha256_bytes(
        canonical_json_bytes(modified[0]["search_trace"])
    )
    with pytest.raises(ContractError, match="F5_FINAL_SETA_COEFFICIENT_PATH_HASH_INVALID"):
        compile_final_seta(modified, 180)


def test_final_seta_direction_denominator_pools_nonzero_coefficients_not_folds() -> None:
    rows = [selector_result_fixture(
        fold, {"StableOne", "DirectionConflict"} if fold <= 4 else {"StableOne"},
        {"DirectionConflict"} if fold == 4 else set(),
        nonzero_count=12 if fold <= 3 else 20,
    ) for fold in range(1, 7)]
    compiled = compile_final_seta(rows, 180)
    direction = compiled["direction_consistency"]["DirectionConflict"]
    assert compiled["outer_frequency"]["DirectionConflict"]["selected_folds"] == 4
    assert direction["nonzero_coefficient_count"] == 56
    assert direction["positive_count"] == 36 and direction["negative_count"] == 20
    assert direction["consistency_rate"] == pytest.approx(36 / 56)
    assert direction["eligible"] is False
    assert "DirectionConflict" not in compiled["lock"]["selected_parents"]


def test_final_seta_never_relaxes_epv_or_six_fold_coverage() -> None:
    results = final_seta_fixture()
    with pytest.raises(ContractError, match="F5_FINAL_SETA_EPV_INFEASIBLE"):
        compile_final_seta(results, 30)
    duplicate = final_seta_fixture()
    duplicate[-1]["fold"] = 5
    with pytest.raises(ContractError, match="F5_FINAL_SETA_FOLD_COVERAGE_INVALID"):
        compile_final_seta(duplicate, 180)


@pytest.mark.parametrize("mutation", ["duplicate", "event", "center", "missing"])
def test_full_data_partition_input_errors_do_not_generate_partial_splits(mutation: str) -> None:
    ids, centers, events = resampling_input()
    if mutation == "duplicate":
        ids[-1] = ids[0]
    elif mutation == "event":
        events[0] = math.nan
    elif mutation == "center":
        centers[0] = 99
    else:
        centers.pop()
    with pytest.raises(ContractError, match="F5_RESAMPLING_INPUT_INVALID"):
        full_data_splits(ids, centers, events)


def paired_predictions(
    final_family: str = "COX_PH",
) -> tuple[list[dict], list[dict], bytes, dict, dict, list[str]]:
    ids = [f"p{i:03d}" for i in range(40)]
    families = load_science_authority()["science"]["families"]
    macro = {
        family: {
            "24": {
                "equal_center_ibs": 0.1 if family == final_family else 0.2,
                "pooled_absolute_slope_error": 0.1,
                "pooled_absolute_citl": 0.1,
                "equal_center_raw_dca": 0.1,
                "worst_center_ibs": 0.1,
                "pooled_uno_c": 0.7,
            }
        }
        for family in families
    }
    decision = select_a15(macro, {family: True for family in families})
    decision_sha256 = sha256_bytes(canonical_json_bytes(decision))
    family_handoff = f4_handoff_fixture(decision)
    response = ("Patient_ID,All_Cause_Death,Death_Followup_months\n" + "".join(
        f"{patient_id},1,{3 if index % 2 == 0 else 50}\n"
        for index, patient_id in enumerate(ids)
    )).encode()
    centers = ["36"] * len(ids)
    response_sha256 = sha256_bytes(response)
    patient_ids_sha256 = sha256_bytes(canonical_json_bytes(ids))
    center_values_sha256 = sha256_bytes(canonical_json_bytes(centers))
    recipe_sha256 = sha256_bytes(b"recipe")
    final_parameter_lock_sha256 = sha256_bytes(
        f"{final_family}-final-parameter-lock".encode()
    )
    final_recipe_identity_sha256 = sha256_bytes(b"final recipe identity")
    source_search_identity_sha256 = sha256_bytes(b"final search identity")
    final_seta_lock_sha256 = sha256_bytes(b"final seta lock")
    selected_spec_sha256 = sha256_bytes(b"selected spec")
    input_mice_data_identity = sha256_bytes(b"final mice data")
    tasks = []
    for imputation in range(1, 21):
        parameters = (
            {
                "family": "RSF",
                "parameters": {
                    "num.trees": 1000,
                    "mtry_fraction": "0.50",
                    "min.node.size": 15,
                    "max.depth": "UNLIMITED",
                    "sample.fraction": 0.632,
                    "splitrule": "logrank",
                },
            }
            if final_family == "RSF"
            else {
                "family": "ELASTIC_NET_COX",
                "alpha": 0.4,
                "ratio": 0.5,
                "lambda": 0.1,
                "lambda_upper_bound": {
                    "schema_version": "1.0.0",
                    "kind": "PADML_F2_ELASTIC_LAMBDA_UPPER_BOUND_V1",
                    "glmnet_version": "5.0",
                    "family": "cox",
                    "cox_ties": "breslow",
                    "alpha": 0.4,
                    "standardize": True,
                    "pilot_requested_nlambda": 100,
                    "pilot_returned_nlambda": 100,
                    "pilot_lambda_head": [0.2, 0.1, 0.05],
                    "resolved_lambda_max": 0.2,
                    "glmnet_big": 9.9e35,
                    "sentinel_equivalent": False,
                    "penalty_factor_identity_sha256": sha256_bytes(
                        canonical_json_bytes({
                            "design_columns": [
                                "AST_ALT", "PADML_GLMNET_INERT_ZERO"
                            ],
                            "penalty_factor": [0.0, 1.0],
                        })
                    ),
                },
            }
            if final_family == "ELASTIC_NET_COX"
            else {
                "family": "FPM_TVC_SET_A",
                "df": [3, 1],
                "tvc_parent": "AST_ALT",
            }
            if final_family == "FPM_TVC_SET_A"
            else {"family": "COX_PH", "ties": "breslow"}
        )
        body = {
            "schema_version": "1.0.0",
            "kind": "PADML_F5_FINAL_REFIT_TASK",
            "status": "COMPILED_NOT_EXECUTED",
            "phase": "FINAL_REFIT",
            "task_id": f"F5_FINAL_REFIT_{final_family}_M{imputation:02d}",
            "family": final_family,
            "imputation": imputation,
            "family_decision_sha256": decision_sha256,
            "f4_locked_family_handoff_sha256": family_handoff[
                "identity_sha256"
            ],
            "final_parameter_lock_sha256": final_parameter_lock_sha256,
            "source_search_identity_sha256": source_search_identity_sha256,
            "final_seta_lock_sha256": final_seta_lock_sha256,
            "selected_spec_sha256": selected_spec_sha256,
            "selected_parents": ["AST_ALT"],
            "selected_design": [{"parent": "AST_ALT", "design_df": 1}],
            "family_design_column_count": 1,
            "family_parent_column_map_sha256": sha256_bytes(
                canonical_json_bytes([
                    {"parent": "AST_ALT", "columns": ["AST_ALT"]}
                ])
            ),
            "input_member": {
                "name": f"imp{imputation:02d}.csv",
                "sha256": sha256_bytes(f"input-{imputation}".encode()),
                "size_bytes": 100 + imputation,
            },
            "input_mice_data_identity": input_mice_data_identity,
            "response_sha256": response_sha256,
            "row_ids_sha256": patient_ids_sha256,
            "row_count": len(ids),
            "parameters": parameters,
            "parameters_sha256": sha256_bytes(canonical_json_bytes(parameters)),
            "final_recipe_identity_sha256": final_recipe_identity_sha256,
            "recipe_sha256": recipe_sha256,
            "parameter_source_evidence_sha256": sha256_bytes(
                f"parameter-source-{imputation}".encode()
            ),
            "model_seed": 300_000 if final_family == "RSF" else None,
            "model_seed_status": (
                "APPLICABLE_SHARED_VALUE_INDEPENDENT_CONSUMPTION"
                if final_family == "RSF"
                else "NOT_APPLICABLE_DETERMINISTIC_ENGINE"
            ),
            "horizons": HORIZONS.copy(),
            "prediction_scope": "FINAL_FULL_DATA_APPARENT_OBJECT_QC",
            "selection_or_external_validation_use_permitted": False,
            "search_fit_count": 0,
            "stopping_fit_count": 0,
            "stopping_seed_count": 0,
            "final_model_fit_count": 1,
            "engine_threads": 1,
            "runtime_fallback_permitted": False,
        }
        tasks.append({
            **body, "task_sha256": sha256_bytes(canonical_json_bytes(body))
        })
    plan_body = {
        "schema_version": "1.0.0",
        "kind": "PADML_F5_FINAL_REFIT_PLAN",
        "status": "COMPILED_NOT_EXECUTED",
        "family": final_family,
        "family_decision_sha256": decision_sha256,
        "f4_locked_family_handoff": family_handoff,
        "f4_locked_family_handoff_sha256": family_handoff[
            "identity_sha256"
        ],
        "final_parameter_lock_sha256": final_parameter_lock_sha256,
        "final_recipe_identity_sha256": final_recipe_identity_sha256,
        "recipe_sha256": recipe_sha256,
        "task_count": 20,
        "tasks": tasks,
        "execution_profile": {
            "pool_workers": 24,
            "maximum_concurrent_tasks": 20,
            "engine_threads": 1,
            "task_granularity": "ONE_LOCKED_IMPUTATION_FINAL_REFIT",
            "refill": "DYNAMIC_ON_COMPLETION",
            "nested_pool": False,
        },
        "grid_rerun": False,
        "search_fit_count": 0,
        "stopping_fit_count": 0,
        "stopping_seed_count": 0,
        "family_reselection": False,
        "scientific_constraints_relaxed": False,
        "total_final_model_fit_count": 20,
    }
    plan = {
        **plan_body,
        "plan_sha256": sha256_bytes(canonical_json_bytes(plan_body)),
    }
    records, receipts = [], []
    for imputation in range(1, 21):
        task = tasks[imputation - 1]
        shift = 0.004 if imputation % 2 else -0.004
        survival = [
            [1.0] + [0.9 - patient / 100 + shift] * 36
            for patient in range(40)
        ]
        prediction_sha256 = sha256_bytes(canonical_json_bytes({
            "family": final_family,
            "imputation": imputation,
            "patient_ids": ids,
            "horizons": HORIZONS,
            "survival": survival,
        }))
        receipt = {
            "schema_version": "1.0.0",
            "kind": "PADML_F5_FINAL_REFIT_RECEIPT",
            "status": "PASS",
            "phase": "FINAL_REFIT",
            "family": final_family,
            "family_decision_sha256": decision_sha256,
            "f4_locked_family_handoff_sha256": family_handoff[
                "identity_sha256"
            ],
            "final_parameter_lock_sha256": final_parameter_lock_sha256,
            "final_refit_plan_sha256": plan["plan_sha256"],
            "task_id": task["task_id"],
            "imputation": imputation,
            "producer_task_sha256": task["task_sha256"],
            "model_sha256": sha256_bytes(f"model-{imputation}".encode()),
            "input_sha256": task["input_member"]["sha256"],
            "response_sha256": response_sha256,
            "patient_ids_sha256": patient_ids_sha256,
            "center_values_sha256": center_values_sha256,
            "recipe_sha256": recipe_sha256,
            "parameters_sha256": task["parameters_sha256"],
            "baseline_sha256": sha256_bytes(
                f"baseline-{imputation}".encode()
            ),
            "prediction_sha256": prediction_sha256,
            "fit_health_sha256": sha256_bytes(canonical_json_bytes({
                "engine_threads": 1,
                "final_model_fit_count": 1,
                "engine": (
                    "ranger::ranger"
                    if final_family == "RSF"
                    else "glmnet::glmnet"
                    if final_family == "ELASTIC_NET_COX"
                    else "rstpm2::stpm2"
                    if final_family == "FPM_TVC_SET_A"
                    else "survival::coxph"
                ),
            })),
        }
        receipt["identity_sha256"] = sha256_bytes(
            canonical_json_bytes(receipt)
        )
        receipts.append(receipt)
        records.append({
            "imputation": imputation,
            "family": final_family,
            "final_refit_receipt_sha256": receipt["identity_sha256"],
            "input_imputation": imputation,
            "model_imputation": imputation,
            "patient_ids": ids.copy(), "horizons": HORIZONS.copy(),
            "survival": survival,
        })
    return records, receipts, response, decision, plan, centers


def reseal_refit_receipts(records: list[dict], receipts: list[dict]) -> None:
    for record, receipt in zip(records, receipts, strict=True):
        receipt["prediction_sha256"] = sha256_bytes(canonical_json_bytes({
            "family": record["family"],
            "imputation": record["imputation"],
            "patient_ids": record["patient_ids"],
            "horizons": record["horizons"],
            "survival": record["survival"],
        }))
        receipt["identity_sha256"] = sha256_bytes(canonical_json_bytes({
            key: value
            for key, value in receipt.items()
            if key != "identity_sha256"
        }))
        record["final_refit_receipt_sha256"] = receipt["identity_sha256"]


def reseal_refit_plan(
    plan: dict, records: list[dict], receipts: list[dict]
) -> None:
    for task in plan["tasks"]:
        task["task_sha256"] = sha256_bytes(canonical_json_bytes({
            key: value for key, value in task.items() if key != "task_sha256"
        }))
    plan["plan_sha256"] = sha256_bytes(canonical_json_bytes({
        key: value for key, value in plan.items() if key != "plan_sha256"
    }))
    for task, receipt in zip(plan["tasks"], receipts, strict=True):
        receipt.update({
            "final_refit_plan_sha256": plan["plan_sha256"],
            "task_id": task["task_id"],
            "producer_task_sha256": task["task_sha256"],
            "input_sha256": task["input_member"]["sha256"],
            "response_sha256": task["response_sha256"],
            "patient_ids_sha256": task["row_ids_sha256"],
            "recipe_sha256": task["recipe_sha256"],
            "parameters_sha256": task["parameters_sha256"],
        })
    reseal_refit_receipts(records, receipts)


def write_final_refit_result_archives(
    root: Path,
    records: list[dict],
    receipts: list[dict],
    plan: dict,
) -> None:
    root.mkdir()
    for record, receipt, task in zip(
        records, receipts, plan["tasks"], strict=True
    ):
        write_deterministic_zip(root / f"{task['task_id']}.zip", {
            "model.bin": f"model-{record['imputation']}".encode(),
            "baseline.bin": f"baseline-{record['imputation']}".encode(),
            "prediction.json": canonical_json_bytes(record),
            "receipt.json": canonical_json_bytes(receipt),
            "fit-health.json": canonical_json_bytes({
                "engine_threads": 1,
                "final_model_fit_count": 1,
                "engine": "ranger::ranger",
            }),
        })


def coefficient_evidence(pooled: dict) -> tuple[list[str], dict]:
    coefficient_ids = ["Age", "AST_ALT"]
    return coefficient_ids, {
        "schema": "F5_COEFFICIENT_MI_EVIDENCE_V2",
        "family": "COX_PH",
        "complete_data_df_by_imputation": [18] * 20,
        "model_sha256_by_imputation": [
            row["model_sha256"] for row in pooled["per_imputation_predictions"]
        ],
        "within_se_source_sha256_by_imputation": [
            sha256_bytes(f"covariance-{imputation}".encode())
            for imputation in range(1, 21)
        ],
        "coefficients": [
            {
                "coefficient_id": coefficient,
                "estimates": [offset + imputation / 1000 for imputation in range(1, 21)],
                "within_standard_errors": [0.2 + offset] * 20,
            }
            for coefficient, offset in (("Age", 0.0), ("AST_ALT", 0.1))
        ],
    }


def elastic_coefficient_evidence(pooled: dict) -> tuple[list[str], dict]:
    coefficient_ids = ["Age", "AST_ALT"]
    scales = [[2.0, 0.5] for _ in range(20)]
    standardized = [
        [0.0 if imputation <= 5 else imputation / 100, -imputation / 200]
        for imputation in range(1, 21)
    ]
    return coefficient_ids, {
        "schema": "F5_ELASTIC_COEFFICIENT_DESCRIPTIVE_EVIDENCE_V1",
        "family": "ELASTIC_NET_COX",
        "scale": "ONE_WITHIN_IMPUTATION_TRAINING_DESIGN_SD",
        "standardization_sd_denominator": "N",
        "model_sha256_by_imputation": [
            row["model_sha256"] for row in pooled["per_imputation_predictions"]
        ],
        "alpha_by_imputation": [0.4] * 20,
        "ratio_by_imputation": [0.1 + imputation / 1000 for imputation in range(20)],
        "lambda_by_imputation": [0.01 + imputation / 10000 for imputation in range(20)],
        "coefficient_scale_by_imputation": scales,
        "coefficients": [
            {
                "coefficient_id": coefficient_id,
                "standardized_estimates": [row[index] for row in standardized],
                "raw_estimates": [
                    row[index] / scales[imputation][index]
                    for imputation, row in enumerate(standardized)
                ],
            }
            for index, coefficient_id in enumerate(coefficient_ids)
        ],
    }


def non_ph_contrast_evidence(pooled: dict) -> list[dict]:
    mean_log_hr = {6: 0.4, 12: 0.3, 24: 0.2, 36: 0.1}
    evidence = []
    for imputation, prediction in enumerate(
        pooled["per_imputation_predictions"], start=1
    ):
        centered_shift = (imputation - 10.5) / 1000
        rows = []
        for horizon in REPORT_HORIZONS:
            log_hr = mean_log_hr[horizon] + centered_shift
            reference_hazard = 0.01 + horizon / 10000
            native_hr = math.exp(log_hr)
            rows.append({
                "time_months": horizon,
                "reference_hazard": reference_hazard,
                "exposed_hazard": reference_hazard * native_hr,
                "native_hazard_ratio": native_hr,
                "log_hazard_ratio": log_hr,
                "within_variance_log_hazard_ratio": 0.01,
            })
        evidence.append({
            "imputation": imputation,
            "model_sha256": prediction["model_sha256"],
            "contrast": "AST_ALT_ORIGINAL_RATIO_2_VS_1",
            "reference_covariates": (
                "TRAINING_DESIGN_COLUMN_MEANS_OUTCOME_BLIND"
            ),
            "uncertainty": (
                "NATIVE_HR_FULL_MODEL_COVARIANCE_LOG_SCALE_IF_ELIGIBLE"
            ),
            "conditional_interpretation": (
                "CONDITIONAL_ON_SELECTED_FAMILY_VARIABLES_PARAMETERS_"
                "AND_APPARENT_FULL_DATA"
            ),
            "contrast_support": {
                "source": "COMPLETED_IMPUTATION_TRAINING_DESIGN",
                "computational_domain": [0, 15],
                "actual_input_lower_open": True,
                "contrast_values": [1, 2],
                "every_center_supported": True,
                "centers": [{
                    "center": "36",
                    "patient_count": len(pooled["patient_ids"]),
                    "minimum_ast_alt": 0.5,
                    "maximum_ast_alt": 3.0,
                    "reference_supported": True,
                    "exposed_supported": True,
                    "contrast_supported": True,
                }],
            },
            "constraint_diagnostics": {
                "definition": "NORMALIZED_CONTINUOUS_DOMAIN_GAP_V1",
                "active": False,
                "active_count": 0,
                "active_tolerance": 1e-5,
                "minimum_normalized_gap": 0.1,
                "minimum_log_time_derivative": 0.1,
            },
            "covariance_diagnostics": {
                "role": "UNPENALIZED_LIKELIHOOD_CURVATURE_ONLY",
                "finite": True,
                "symmetric": True,
                "rank": 6,
                "coefficient_count": 6,
                "positive_definite": True,
                "valid_for_interior_wald": True,
            },
            "training_event_count": 40,
            "complete_data_degrees_of_freedom": 34,
            "interval_status": "ESTIMABLE_INTERIOR_UNCONSTRAINED_WALD",
            "interval_reasons": [],
            "rows": rows,
        })
    return evidence


def final_shap_components(pooled: dict, *, max_iter=100) -> list[dict]:
    patient_ids = pooled["patient_ids"]
    components = []
    for imputation, prediction in enumerate(
        pooled["per_imputation_predictions"], start=1
    ):
        risks = [
            [1.0 - row[horizon] for horizon in REPORT_HORIZONS]
            for row in prediction["survival"]
        ]
        base = [
            math.fsum(row[column] for row in risks) / len(risks)
            for column in range(4)
        ]
        contributions = [
            [[row[column] - base[column]] for column in range(4)]
            for row in risks
        ]
        global_values = [
            [
                math.fsum(abs(row[column][0]) for row in contributions)
                / len(contributions)
            ]
            for column in range(4)
        ]
        maximum_error = max(
            abs(base[column] + contributions[patient][column][0]
                - risks[patient][column])
            for patient in range(len(patient_ids))
            for column in range(4)
        )
        components.append({
            "schema_version": "1.0.0",
            "kind": "PADML_F5_FINAL_SHAP_COMPONENT_V1",
            "status": "PASS",
            "label": "FINAL_FULL_DATA_APPARENT_SHAP",
            "family": pooled["family"],
            "imputation": imputation,
            "model_sha256": prediction["model_sha256"],
            "patient_ids": patient_ids,
            "horizons": list(REPORT_HORIZONS),
            "primary_horizon_months": 24,
            "selected_parent_groups": ["AST_ALT"],
            "ast_alt_information_channels": 1,
            "raw_ast_or_alt_channels": 0,
            "background": {
                "source": "FULL_CORRESPONDING_IMPUTATION_TRAINING_PATIENTS",
                "patient_count": len(patient_ids),
                "patient_ids": patient_ids,
                "weighting": "EQUAL_PATIENT_WEIGHT",
                "bg_w": None,
                "bg_n": None,
                "subsampling": False,
                "validation_row_count": 0,
                "outcome_column_count": 0,
            },
            "estimand": {
                "survival": "S_T_X",
                "risk": "ONE_MINUS_S_T_X",
                "risk_contribution": "NEGATIVE_SURVIVAL_CONTRIBUTION",
                "base_risk": "ONE_MINUS_BASE_SURVIVAL",
            },
            "engine": {
                "package": "kernelshap",
                "version": "0.9.1",
                "algorithm": "kernelshap",
                "exact": True,
                "hybrid_degree": None,
                "m": None,
                "tol": 0.005,
                "max_iter": max_iter,
                "parallel": False,
                "seed": 780_000_000 + imputation,
            },
            "convergence": {
                "required": True,
                "all_rows_converged": True,
                "maximum_iterations_used": 0,
                "fixed_seed_first_patient_replay_exact": True,
            },
            "base_risk": base,
            "predicted_risk": risks,
            "risk_contributions": contributions,
            "within_imputation_global_mean_absolute_contribution": global_values,
            "local_accuracy": {
                "tolerance": 1e-6,
                "maximum_absolute_error": maximum_error,
                "status": "PASS",
            },
            "selection_effect": "NONE",
        })
        if max_iter == 2000:
            components[-1]["patient_execution"] = {
                "rng_policy": "ORIGINAL_500_PATIENT_START", "original_stream_max_iter": 500,
                "spec_sha256": "e" * 64, "recovery_source": None,
                "rng_kind": ["Mersenne-Twister", "Inversion", "Rejection"], "r_version": "4.6.0",
                "rows": [{"patient_index": i, "patient_id": patient, "n_iter": 0,
                    "original_stream_n_iter": 0, "rng_before_sha256": "f" * 64,
                    "rng_after_original_sha256": "f" * 64,
                    "producer": {"max_iter": 2000, "source_sha256": "e" * 64}}
                    for i, patient in enumerate(patient_ids, 1)]}
    return components


def test_imputation_pairing_order_and_probability_average() -> None:
    records, receipts, _, decision, plan, centers = paired_predictions()
    pooled = pool_predictions(records, receipts, decision, plan, centers)
    assert pool_predictions(
        list(reversed(records)), list(reversed(receipts)), decision, plan, centers
    ) == pooled
    assert pooled["mean_survival"][0][24] == 0.9
    assert pooled["odd_survival"][0][24] == pytest.approx(0.904)
    assert pooled["even_survival"][0][24] == pytest.approx(0.896)
    assert pooled["patient_spread"][0]["horizons"]["24"]["imputation_sd"] == pytest.approx(0.004 * math.sqrt(20 / 19))
    assert pooled["patient_spread"][0]["horizons"]["24"]["imputation_mcse"] == pytest.approx(0.004 / math.sqrt(19))
    assert pooled["patient_spread"][0]["risk_score_common"] == -math.log(0.9)
    assert len(pooled["per_imputation_predictions"]) == 20
    assert len({
        row["producer_task_sha256"]
        for row in pooled["per_imputation_predictions"]
    }) == 20
    assert pooled["spread_interpretation"] == "IMPUTATION_SPREAD_NOT_PERFORMANCE_CONFIDENCE_INTERVAL"


def test_final_shap_pools_signed_components_then_global_absolute_values() -> None:
    records, receipts, _, decision, plan, centers = paired_predictions()
    pooled = pool_predictions(records, receipts, decision, plan, centers)
    components = final_shap_components(pooled)
    result = aggregate_final_shap(components, pooled)
    assert result["label"] == "FINAL_FULL_DATA_APPARENT_SHAP"
    assert result["primary_horizon_months"] == 24
    assert result["selected_parent_groups"] == ["AST_ALT"]
    assert len(result["patient_contributions"]) == len(pooled["patient_ids"])
    expected = math.fsum(
        component["within_imputation_global_mean_absolute_contribution"][2][0]
        for component in components
    ) / 20
    assert result["global_importance"][2]["importance"][0][
        "mean_of_within_imputation_patient_mean_absolute_contribution"
    ] == pytest.approx(expected)


def test_final_shap_rejects_raw_ast_channel_and_additivity_drift() -> None:
    records, receipts, _, decision, plan, centers = paired_predictions()
    pooled = pool_predictions(records, receipts, decision, plan, centers)
    components = final_shap_components(pooled)
    components[0]["raw_ast_or_alt_channels"] = 1
    with pytest.raises(ContractError, match="F5_SHAP_COMPONENT_INVALID"):
        aggregate_final_shap(components, pooled)


def test_final_shap_checkpoint_reuses_only_exact_valid_component(
    tmp_path: Path, monkeypatch,
) -> None:
    records, receipts, _, decision, plan, centers = paired_predictions()
    pooled = pool_predictions(records, receipts, decision, plan, centers)
    component = final_shap_components(pooled, max_iter=2000)[0]
    task = plan["tasks"][0]
    input_bundle = (tmp_path / "input.zip").resolve()
    input_bundle.write_bytes(b"retained-final-refit-input")
    checkpoint_root = (tmp_path / "shap-checkpoints").resolve()
    checkpoint_root.mkdir()
    calls = []

    def produce(*args):
        calls.append(args)
        return copy.deepcopy(component)

    monkeypatch.setattr("padml.f5._produce_final_shap_component", produce)
    arguments = (
        checkpoint_root,
        input_bundle,
        sha256_bytes(b"final-refit-result"),
        task,
        b"model-1",
        b"baseline-1",
        records[0],
    )
    first, first_record, checkpoint = (
        _load_or_produce_final_shap_checkpoint(*arguments)
    )
    second, second_record, second_path = (
        _load_or_produce_final_shap_checkpoint(*arguments)
    )
    assert first == second == component
    assert first_record["reuse_status"] == "COMPUTED_MISSING_EXACT_COMPONENT"
    assert second_record["reuse_status"] == "REUSED_EXACT_COMPONENT"
    assert checkpoint == second_path
    assert len(calls) == 1

    checkpoint.write_bytes(b"corrupt matching checkpoint")
    with pytest.raises(ContractError, match="ZIP_INVALID"):
        _load_or_produce_final_shap_checkpoint(*arguments)
    assert len(calls) == 1
    components = final_shap_components(pooled)
    components[0]["risk_contributions"][0][0][0] += 0.01
    with pytest.raises(ContractError, match="F5_SHAP_LOCAL_ACCURACY_INVALID"):
        aggregate_final_shap(components, pooled)


def test_final_collection_parallelizes_replay_and_both_shap_branches(
    tmp_path: Path, monkeypatch,
) -> None:
    records, receipts, _, decision, plan, centers = paired_predictions("RSF")
    pooled = pool_predictions(records, receipts, decision, plan, centers)
    components = final_shap_components(pooled)
    result_root = (tmp_path / "unfitted-results").resolve()
    input_root = (tmp_path / "unfitted-inputs").resolve()
    result_root.mkdir()
    input_root.mkdir()
    for task in plan["tasks"]:
        for root in (result_root, input_root):
            (root / f"{task['task_id']}.zip").write_bytes(
                b"UNFITTED_PARALLEL_SCHEDULING_FIXTURE"
            )

    completion_order = {"readback": [], "shap": []}

    def fake_readback(job):
        task = job[2]
        imputation = task["imputation"]
        completion_order["readback"].append(imputation)
        receipt = receipts[imputation - 1]
        return {
            "imputation": imputation,
            "prediction": records[imputation - 1],
            "receipt": receipt,
            "retained_audit": {},
            "archive": {
                "imputation": imputation,
                "task_id": task["task_id"],
                "archive_sha256": sha256_bytes(
                    f"unfitted-result-{imputation}".encode()
                ),
                "archive_size_bytes": 1,
                "model_sha256": receipt["model_sha256"],
                "baseline_sha256": receipt["baseline_sha256"],
                "fit_health_sha256": receipt["fit_health_sha256"],
                "retained_prediction_replay": (
                    "EXACT_ALL_PATIENTS_ALL_HORIZONS"
                ),
                "retained_object_audit_sha256": sha256_bytes(
                    f"unfitted-audit-{imputation}".encode()
                ),
            },
        }

    def fake_shap(job):
        task = job[3]
        checkpoint_root = job[4]
        imputation = task["imputation"]
        completion_order["shap"].append(imputation)
        return {
            "imputation": imputation,
            "component": components[imputation - 1],
            "checkpoint_record": (
                None
                if checkpoint_root is None
                else {
                    "imputation": imputation,
                    "binding_identity_sha256": sha256_bytes(
                        f"binding-{imputation}".encode()
                    ),
                    "archive_sha256": sha256_bytes(
                        f"checkpoint-{imputation}".encode()
                    ),
                    "archive_size_bytes": 1,
                    "component_sha256": sha256_bytes(
                        canonical_json_bytes(components[imputation - 1])
                    ),
                    "reuse_status": "REUSED_EXACT_COMPONENT",
                }
            ),
            "checkpoint_path": (
                None
                if checkpoint_root is None
                else checkpoint_root / f"M{imputation:02d}.zip"
            ),
        }

    pool_calls = []

    def reverse_completion_pool(worker, jobs, *, selected_slots=None, on_result=None):
        pool_calls.append((worker, len(jobs), selected_slots))
        results = [None] * len(jobs)
        for index in reversed(range(len(jobs))):
            results[index] = worker(jobs[index])
            if on_result is not None:
                on_result(index, results[index])
        return results

    monkeypatch.setattr(f5_module, "_collect_final_refit_component", fake_readback)
    monkeypatch.setattr(f5_module, "_collect_final_shap_component", fake_shap)
    monkeypatch.setattr(f5_module, "_bounded_ordered_spawn", reverse_completion_pool)

    for checkpoint_root in (
        None,
        (tmp_path / "exact-shap-checkpoints").resolve(),
    ):
        completion_order["readback"].clear()
        completion_order["shap"].clear()
        start = len(pool_calls)
        collected = collect_final_refit_results(
            result_root,
            decision,
            plan,
            input_root=input_root,
            shap_checkpoint_root=checkpoint_root,
            workers=3,
        )
        assert [row["imputation"] for row in collected["predictions"]] == list(
            range(1, 21)
        )
        assert [row["imputation"] for row in collected["shap_components"]] == list(
            range(1, 21)
        )
        assert completion_order == {
            "readback": list(range(20, 0, -1)),
            "shap": list(range(20, 0, -1)),
        }
        assert pool_calls[start:] == [
            (fake_readback, 20, 3),
            (fake_shap, 20, 3),
        ]
        if checkpoint_root is None:
            assert collected["shap_component_archives"] == []
        else:
            assert [
                row["reuse_status"]
                for row in collected["shap_component_archives"]
            ] == ["REUSED_EXACT_COMPONENT"] * 20


def test_final_refit_parallel_failure_preserves_unfitted_counterexample(
    tmp_path: Path,
) -> None:
    records, receipts, _, decision, plan, _ = paired_predictions("RSF")
    task = copy.deepcopy(plan["tasks"][0])
    # This stays before the R/native branch: no model is fitted or opened.
    task["family_design_column_count"] = 0
    result_path = (tmp_path / "unfitted-result.zip").resolve()
    input_path = (tmp_path / "unfitted-input.zip").resolve()
    input_path.write_bytes(b"UNFITTED_INPUT_NOT_REPLAYED")
    health = {
        "engine_threads": 1,
        "final_model_fit_count": 1,
        "engine": "ranger::ranger",
    }
    write_deterministic_zip(result_path, {
        "model.bin": b"UNFITTED_MODEL_BYTES",
        "baseline.bin": b"UNFITTED_BASELINE_BYTES",
        "prediction.json": canonical_json_bytes(records[0]),
        "receipt.json": canonical_json_bytes({
            **receipts[0],
            "model_sha256": sha256_bytes(b"UNFITTED_MODEL_BYTES"),
            "baseline_sha256": sha256_bytes(b"UNFITTED_BASELINE_BYTES"),
            "fit_health_sha256": sha256_bytes(canonical_json_bytes(health)),
        }),
        "fit-health.json": canonical_json_bytes(health),
    })
    job = (result_path, input_path, task, plan, decision, None)
    with pytest.raises(
        ContractError,
        match=(
            "BOUNDED_SPAWN_CHILD_FAILED:0:ContractError:"
            "F5_FINAL_REFIT_RETAINED_OBJECT_INVALID"
        ),
    ):
        f5_module._bounded_ordered_spawn(
            f5_module._collect_final_refit_component,
            [job],
            selected_slots=1,
        )


def test_final_entries_forward_workers_to_native_collection(
    tmp_path: Path, monkeypatch,
) -> None:
    records, receipts, response, decision, plan, centers = paired_predictions(
        "RSF"
    )
    tasks = {task["imputation"]: task for task in plan["tasks"]}
    response_sha256 = sha256_bytes(response)
    index = {
        "family_decision": decision,
        "final_refit_plan": plan,
        "centers": centers,
        "final_family": "RSF",
        "final_mice": {"fit_response": {"sha256": response_sha256}},
    }
    index_path = (tmp_path / "index.json").resolve()
    response_path = (tmp_path / "response.csv").resolve()
    result_root = (tmp_path / "results").resolve()
    input_root = (tmp_path / "inputs").resolve()
    non_ph_path = (tmp_path / "non-ph-input.zip").resolve()
    index_path.write_bytes(canonical_json_bytes(index))
    response_path.write_bytes(response)
    result_root.mkdir()
    input_root.mkdir()
    non_ph_path.write_bytes(b"UNOPENED_ZERO_FIT_ACTION")

    authority = copy.deepcopy(load_science_authority())
    authority["science"]["population"]["validation_centers"] = [36]
    authority["science"]["population"]["training_only_centers"] = []
    monkeypatch.setattr(f5_module, "load_science_authority", lambda: authority)
    observed_workers = {}

    def consume_parameters(*args, **kwargs):
        observed_workers["parameter_source"] = kwargs["workers"]
        return tasks

    def stop_at_collection(*args, **kwargs):
        observed_workers["final_aggregate"] = kwargs["workers"]
        raise RuntimeError("ZERO_FIT_COLLECTION_BOUNDARY")

    monkeypatch.setattr(f5_module, "_consume_final_parameter_source", consume_parameters)
    monkeypatch.setattr(f5_module, "_validate_final_mice_archive", lambda *args, **kwargs: [])
    monkeypatch.setattr(
        f5_module,
        "_load_final_sensitivity_actions",
        lambda *args, **kwargs: ({}, [], {}),
    )
    monkeypatch.setattr(f5_module, "collect_final_refit_results", stop_at_collection)
    with pytest.raises(RuntimeError, match="ZERO_FIT_COLLECTION_BOUNDARY"):
        execute_final_aggregate(
            index_path,
            response_path,
            result_root,
            non_ph_path,
            (tmp_path / "final.zip").resolve(),
            input_root=input_root,
            mice_plan_path=(tmp_path / "mice-plan.json").resolve(),
            final_mice_path=(tmp_path / "final-mice.zip").resolve(),
            workers=7,
        )
    assert observed_workers == {"parameter_source": 7, "final_aggregate": 7}

    def collected_without_native_work(*args, **kwargs):
        observed_workers["non_ph"] = kwargs["workers"]
        return {
            "predictions": records,
            "receipts": receipts,
            "archives": [
                {
                    "imputation": imputation,
                    "archive_sha256": sha256_bytes(
                        f"unfitted-archive-{imputation}".encode()
                    ),
                    "retained_object_audit_sha256": sha256_bytes(
                        f"unfitted-audit-{imputation}".encode()
                    ),
                }
                for imputation in range(1, 21)
            ],
            "non_ph_contrast_evidence": None,
        }

    monkeypatch.setattr(f5_module, "_validate_final_aggregate_lineage", lambda _: tasks)
    monkeypatch.setattr(
        f5_module, "collect_final_refit_results", collected_without_native_work
    )
    result = execute_non_ph_action(
        index_path,
        response_path,
        result_root,
        (tmp_path / "non-ph-result.zip").resolve(),
        input_root=input_root,
        workers=5,
    )
    assert result["status"] == "NOT_APPLICABLE"
    assert observed_workers["non_ph"] == 5


def test_non_ph_pools_native_contrasts_and_quantifies_rank_movement() -> None:
    records, receipts, _, decision, plan, centers = paired_predictions(
        "FPM_TVC_SET_A"
    )
    pooled = pool_predictions(records, receipts, decision, plan, centers)
    result = evaluate_non_ph(non_ph_contrast_evidence(pooled), pooled)
    assert result["status"] == "COMPUTED"
    assert result["feedback"] == "ZERO"
    assert result["model_structure"] == "AST_ALT_ONLY_TVC_NO_RUTHERFORD_TVC"
    assert result["attenuation_ratio_abs_ell36_over_abs_ell6"] == pytest.approx(
        0.25
    )
    assert result["absolute_effect_change_abs_ell36_minus_abs_ell6"] == pytest.approx(
        -0.3
    )
    assert result["endpoint_direction_change"] == "NO_REVERSAL"
    assert result["interval_status"] == "ESTIMABLE"
    assert result["required_interval_horizons_missing"] == []
    assert result["cox_zph_reference"] == {
        "status": "NOT_AVAILABLE",
        "reason": "EXISTING_REFERENCE_NOT_SUPPLIED",
        "new_fit_count": 0,
        "p_value_pooling": False,
    }
    assert all(
        row["pooling"]
        == (
            "RUBIN_FULL_NATIVE_LOG_HR_CONTRAST_BARNARD_RUBIN_"
            "STUDENT_T_NOT_COEFFICIENT_AVERAGE"
        )
        for row in result["pooled_contrasts"]
    )
    assert all(
        row["student_t_critical_975"] > 1.959963984540054
        and row["student_t_95_interval_log_hazard_ratio"] is not None
        and "normal_95_interval_log_hazard_ratio" not in row
        for row in result["pooled_contrasts"]
    )
    rank = result["patient_rank_change"]
    assert rank["status"] == "ESTIMABLE"
    assert rank["adjacent_spearman_status"] == "ESTIMABLE"
    assert rank["top_10_percent"]["k"] == 4
    assert rank["maximum_adjacent_percentile_shift"] == {
        "median": 0.0,
        "p95": 0.0,
        "maximum": 0.0,
    }
    assert set(rank["adjacent_spearman"].values()) == {1.0}
    assert set(rank["top_10_percent"]["adjacent_overlap"].values()) == {1.0}


def test_non_ph_rejects_claimed_hr_not_equal_to_native_hazard_ratio() -> None:
    records, receipts, _, decision, plan, centers = paired_predictions(
        "FPM_TVC_SET_A"
    )
    pooled = pool_predictions(records, receipts, decision, plan, centers)
    evidence = non_ph_contrast_evidence(pooled)
    evidence[0]["rows"][0]["native_hazard_ratio"] += 0.01
    with pytest.raises(ContractError, match="F5_NON_PH_NATIVE_HR_BINDING_INVALID"):
        evaluate_non_ph(evidence, pooled)


def test_non_ph_active_constraint_preserves_points_but_withholds_intervals() -> None:
    records, receipts, _, decision, plan, centers = paired_predictions(
        "FPM_TVC_SET_A"
    )
    pooled = pool_predictions(records, receipts, decision, plan, centers)
    evidence = non_ph_contrast_evidence(pooled)
    for row in evidence:
        row["constraint_diagnostics"].update({
            "active": True,
            "active_count": 1,
            "minimum_normalized_gap": 1e-6,
        })
        row["interval_status"] = "NOT_ESTIMABLE"
        row["interval_reasons"] = [
            "ACTIVE_CONTINUOUS_DOMAIN_CONSTRAINT"
        ]
        for contrast in row["rows"]:
            contrast["within_variance_log_hazard_ratio"] = None
    result = evaluate_non_ph(evidence, pooled)
    assert result["status"] == (
        "DESCRIPTIVE_POINTS_ONLY_INTERVALS_NOT_ESTIMABLE"
    )
    assert result["interval_status"] == "NOT_ESTIMABLE"
    assert result["required_interval_horizons_missing"] == [6, 12, 24, 36]
    assert result["interval_nonestimability_reasons"] == [
        "ACTIVE_CONTINUOUS_DOMAIN_CONSTRAINT"
    ]
    assert all(
        row["pooled_log_hazard_ratio"] is not None
        and row["pooled_hazard_ratio"] is not None
        and row["pooled_standard_error"] is None
        and row["student_t_95_interval_hazard_ratio"] is None
        for row in result["pooled_contrasts"]
    )


def _with_non_ph_interval_failure(
    evidence: list[dict], reason: str, *, all_imputations: bool = True
) -> None:
    selected = evidence if all_imputations else evidence[:1]
    for row in selected:
        row["interval_status"] = "NOT_ESTIMABLE"
        row["interval_reasons"] = [reason]
        for contrast in row["rows"]:
            contrast["within_variance_log_hazard_ratio"] = None


def test_non_ph_rejects_ooc_scope_and_marks_constant_rank_incomplete() -> None:
    records, receipts, _, decision, plan, centers = paired_predictions(
        "FPM_TVC_SET_A"
    )
    pooled = pool_predictions(records, receipts, decision, plan, centers)
    evidence = non_ph_contrast_evidence(pooled)
    with pytest.raises(ContractError, match="F5_NON_PH_INPUT_INVALID"):
        evaluate_non_ph(evidence, pooled, scope_label="SIX_FOLD_OOC_ACCEPTED")
    for prediction in pooled["per_imputation_predictions"]:
        prediction["survival"] = [
            prediction["survival"][0].copy()
            for _ in pooled["patient_ids"]
        ]
    result = evaluate_non_ph(evidence, pooled)
    assert result["status"] == "COMPUTED_RANK_COMPONENT_NOT_ESTIMABLE"
    assert result["patient_rank_change"]["status"] == (
        "INCOMPLETE_ADJACENT_SPEARMAN_NOT_ESTIMABLE"
    )
    assert result["patient_rank_change"]["adjacent_spearman_status"] == (
        "NOT_ESTIMABLE_CONSTANT_RANK_VECTOR"
    )
    assert set(result["patient_rank_change"]["adjacent_spearman"].values()) == {
        None
    }


def test_non_ph_unsupported_contrast_preserves_points_but_bad_covariance_fails() -> None:
    records, receipts, _, decision, plan, centers = paired_predictions(
        "FPM_TVC_SET_A"
    )
    pooled = pool_predictions(records, receipts, decision, plan, centers)
    evidence = non_ph_contrast_evidence(pooled)
    for row in evidence:
        support = row["contrast_support"]
        support["every_center_supported"] = False
        support["centers"][0].update({
            "maximum_ast_alt": 1.5,
            "exposed_supported": False,
            "contrast_supported": False,
        })
    _with_non_ph_interval_failure(
        evidence, "CONTRAST_NOT_SUPPORTED_IN_EVERY_COMPLETED_CENTER"
    )
    result = evaluate_non_ph(evidence, pooled)
    assert result["interval_status"] == "NOT_ESTIMABLE"
    assert result["interval_nonestimability_reasons"] == [
        "CONTRAST_NOT_SUPPORTED_IN_EVERY_COMPLETED_CENTER"
    ]
    assert all(row["pooled_hazard_ratio"] > 0 for row in result["pooled_contrasts"])

    evidence = non_ph_contrast_evidence(pooled)
    for row in evidence:
        row["covariance_diagnostics"].update({
            "positive_definite": False,
            "valid_for_interior_wald": False,
        })
    _with_non_ph_interval_failure(evidence, "INVALID_FULL_MODEL_COVARIANCE")
    with pytest.raises(ContractError, match="F5_NON_PH_FULL_MODEL_COVARIANCE_NUMERICAL_FAILURE"):
        evaluate_non_ph(evidence, pooled)


def test_non_ph_df_binding_and_single_invalid_imputation_fail_closed() -> None:
    records, receipts, _, decision, plan, centers = paired_predictions(
        "FPM_TVC_SET_A"
    )
    pooled = pool_predictions(records, receipts, decision, plan, centers)
    evidence = non_ph_contrast_evidence(pooled)
    evidence[0]["complete_data_degrees_of_freedom"] = 33
    with pytest.raises(ContractError, match="F5_NON_PH_COMPLETE_DATA_DF_INVALID"):
        evaluate_non_ph(evidence, pooled)

    evidence = non_ph_contrast_evidence(pooled)
    for row in evidence:
        row["covariance_diagnostics"].update({
            "rank": 40,
            "coefficient_count": 40,
        })
        row["complete_data_degrees_of_freedom"] = 0
    _with_non_ph_interval_failure(
        evidence, "NONPOSITIVE_COMPLETE_DATA_DEGREES_OF_FREEDOM"
    )
    with pytest.raises(ContractError, match="F5_NON_PH_COMPLETE_DATA_DF_INVALID"):
        evaluate_non_ph(evidence, pooled)

    evidence = non_ph_contrast_evidence(pooled)
    evidence[0]["constraint_diagnostics"].update({
        "active": True,
        "active_count": 1,
        "minimum_normalized_gap": 1e-6,
    })
    _with_non_ph_interval_failure(
        evidence, "ACTIVE_CONTINUOUS_DOMAIN_CONSTRAINT",
        all_imputations=False,
    )
    result = evaluate_non_ph(evidence, pooled)
    assert result["required_interval_horizons_missing"] == [6, 12, 24, 36]
    assert result["interval_nonestimability_by_imputation"] == [{
        "imputation": 1,
        "reasons": ["ACTIVE_CONTINUOUS_DOMAIN_CONSTRAINT"],
    }]


def test_non_ph_is_a_separate_replayable_action_with_derived_applicability(
    tmp_path: Path,
) -> None:
    records, receipts, _, decision, plan, centers = paired_predictions()
    pooled = pool_predictions(records, receipts, decision, plan, centers)
    archives = [
        {
            "imputation": imputation,
            "archive_sha256": sha256_bytes(
                f"refit-{imputation}".encode()
            ),
            "retained_object_audit_sha256": sha256_bytes(
                f"audit-{imputation}".encode()
            ),
        }
        for imputation in range(1, 21)
    ]
    not_applicable = _compile_non_ph_action(pooled, None, plan, archives)
    assert not_applicable["action"] == "NON_PH"
    assert not_applicable["status"] == "NOT_APPLICABLE"
    assert not_applicable["analysis"] is None

    action_path = (tmp_path / "non-ph.zip").resolve()
    write_deterministic_zip(
        action_path,
        {"non-ph.json": canonical_json_bytes(not_applicable)},
    )
    assert _load_non_ph_action(
        action_path, pooled, None, plan, archives
    ) == not_applicable

    fpm_records, fpm_receipts, _, fpm_decision, fpm_plan, fpm_centers = (
        paired_predictions("FPM_TVC_SET_A")
    )
    fpm_pooled = pool_predictions(
        fpm_records, fpm_receipts, fpm_decision, fpm_plan, fpm_centers
    )
    completed = _compile_non_ph_action(
        fpm_pooled,
        non_ph_contrast_evidence(fpm_pooled),
        fpm_plan,
        archives,
    )
    assert completed["status"] == "COMPLETED_ZERO_FEEDBACK"
    assert completed["analysis"]["scope_label"] == (
        "FINAL_FULL_DATA_APPARENT"
    )


def test_final_aggregate_rejects_declared_hashes_with_fake_model_bytes(
    tmp_path: Path,
) -> None:
    records, receipts, response, decision, plan, centers = paired_predictions(
        "RSF"
    )
    result_root = (tmp_path / "final-refit-results").resolve()
    write_final_refit_result_archives(
        result_root, records, receipts, plan
    )
    with pytest.raises(
        ContractError,
        match="F5_FINAL_REFIT_RETAINED_OBJECT_INVALID",
    ):
        collect_final_refit_results(result_root, decision, plan, input_root=result_root)


@pytest.mark.parametrize("mutation", ["missing", "duplicate", "input_m", "model_m", "parameter", "patient", "nonfinite"])
def test_mi_errors_are_hard_failures_not_infeasibility(mutation: str) -> None:
    records, receipts, _, decision, plan, centers = paired_predictions()
    if mutation == "missing":
        records.pop()
    elif mutation == "duplicate":
        records[-1] = copy.deepcopy(records[0])
    elif mutation == "input_m":
        records[0]["input_imputation"] = 2
    elif mutation == "model_m":
        records[0]["model_imputation"] = 2
    elif mutation == "parameter":
        receipts[0]["parameters_sha256"] = "f" * 64
    elif mutation == "patient":
        records[1]["patient_ids"].reverse()
    else:
        records[0]["survival"][0][1] = math.nan
    with pytest.raises(ContractError):
        pool_predictions(records, receipts, decision, plan, centers)


@pytest.mark.parametrize("field", ["model_sha256", "input_sha256"])
def test_m20_allows_equal_object_hashes_with_distinct_producer_receipts(
    field: str,
) -> None:
    records, receipts, _, decision, plan, centers = paired_predictions()
    shared = receipts[0][field]
    if field == "input_sha256":
        for task in plan["tasks"]:
            task["input_member"]["sha256"] = shared
        reseal_refit_plan(plan, records, receipts)
    else:
        for receipt in receipts:
            receipt[field] = shared
        reseal_refit_receipts(records, receipts)
    assert pool_predictions(
        records, receipts, decision, plan, centers
    )["imputation_count"] == 20


def test_m20_rejects_cross_imputation_producer_alias() -> None:
    records, receipts, _, decision, plan, centers = paired_predictions()
    receipts[1]["producer_task_sha256"] = receipts[0]["producer_task_sha256"]
    reseal_refit_receipts(records, receipts)
    with pytest.raises(
        ContractError, match="F5_FINAL_REFIT_PRODUCER_ALIAS_FORBIDDEN"
    ):
        pool_predictions(records, receipts, decision, plan, centers)


@pytest.mark.parametrize(
    ("field", "value"),
    [
        ("producer_task_sha256", "f" * 64),
        ("task_id", "F5_FINAL_REFIT_WRONG_TASK"),
        ("response_sha256", "f" * 64),
        ("center_values_sha256", "f" * 64),
    ],
)
def test_m20_rejects_receipts_not_bound_to_real_task_response_or_center(
    field: str, value: str,
) -> None:
    records, receipts, _, decision, plan, centers = paired_predictions()
    receipts[0][field] = value
    reseal_refit_receipts(records, receipts)
    with pytest.raises(ContractError, match="F5_FINAL_REFIT_TASK_BINDING_INVALID"):
        pool_predictions(records, receipts, decision, plan, centers)


def test_m20_allows_one_locked_parameter_configuration_across_imputations() -> None:
    records, receipts, _, decision, plan, centers = paired_predictions()
    shared = receipts[0]["parameters_sha256"]
    shared_parameters = copy.deepcopy(plan["tasks"][0]["parameters"])
    for task in plan["tasks"]:
        task["parameters"] = copy.deepcopy(shared_parameters)
        task["parameters_sha256"] = shared
    reseal_refit_plan(plan, records, receipts)
    assert pool_predictions(
        records, receipts, decision, plan, centers
    )["imputation_count"] == 20


def test_mi_triggers_are_diagnostic_and_do_not_reopen_f1_or_locks() -> None:
    records, receipts, response, decision, plan, centers = paired_predictions("RSF")
    original = canonical_json_bytes([records, receipts])
    pooled = pool_predictions(records, receipts, decision, plan, centers)
    report = diagnose_mi(pooled, ["36"] * 40, response, final_family="RSF")
    assert report["status"] == "COMPUTED"
    assert report["median_patient_risk_difference"] == pytest.approx(0.008)
    assert report["triggers"]["median_patient_risk_difference"] is True
    assert report["top_10_percent_overlap"] == 1.0
    assert set(report["odd_even_metrics"]) == {"odd", "even", "absolute_difference"}
    assert report["odd_even_metrics"]["absolute_difference"]["ibs_0_24"] == report["odd_even_delta_ibs"]
    assert report["odd_even_metrics"]["absolute_difference"]["ibs_0_24"] > 0
    assert report["odd_even_metrics"]["absolute_difference"]["brier_24"] > 0
    assert report["odd_even_metrics"]["odd"]["uno_c_24"] is not None
    assert report["odd_even_metrics"]["odd"]["auc_24"] is not None
    assert report["odd_even_metrics"]["odd"]["calibration_slope_24"] is not None
    for metric in ("ici", "e50", "e90"):
        key = f"calibration_{metric}_by_horizon"
        assert set(report["odd_even_metrics"]["odd"][key]) == {
            "6", "12", "24", "36",
        }
        assert set(report["odd_even_metrics"]["absolute_difference"][key]) == {
            "6", "12", "24", "36",
        }
    assert "calibration_ici_6_12_24_36" not in report["odd_even_metrics"]["odd"]
    assert report["any_observed_m20_b_trigger"] is True
    assert report["additional_mice_started"] is False
    assert report["selection_effect"] == "NONE"
    assert canonical_json_bytes([records, receipts]) == original


def test_missing_coefficient_evidence_and_top_ties_are_not_false_passes() -> None:
    records, receipts, response, decision, plan, centers = paired_predictions()
    pooled = pool_predictions(records, receipts, decision, plan, centers)
    report = diagnose_mi(pooled, ["36"] * 40, response, final_family="COX_PH")
    assert report["status"] == "INCOMPLETE"
    assert report["missing_checks"] == [
        "COEFFICIENT_LOCK_MISSING", "COEFFICIENT_MCSE_EVIDENCE_MISSING",
    ]
    coefficient_ids, evidence = coefficient_evidence(pooled)
    evidence["coefficients"][0]["estimates"][0] = math.nan
    with pytest.raises(ContractError, match="F5_COEFFICIENT_EVIDENCE_INVALID"):
        diagnose_mi(
            pooled, ["36"] * 40, response, final_family="COX_PH",
            locked_coefficient_ids=coefficient_ids, coefficient_evidence=evidence,
        )
    records, receipts, _, decision, plan, centers = paired_predictions("RSF")
    for record in records:
        record["survival"] = [
            [1.0] + [0.50 + (3 if patient == 4 else patient) / 100] * 36
            for patient in range(40)
        ]
    reseal_refit_receipts(records, receipts)
    tied = diagnose_mi(
        pool_predictions(records, receipts, decision, plan, centers), centers, response,
        final_family="RSF",
    )
    assert tied["status"] == "COMPUTED"
    assert tied["top_10_percent_overlap"] == 1.0
    assert tied["top_risk_support"]["groups"]["odd"]["patient_count"] == 5
    assert tied["top_risk_support"]["groups"]["even"]["patient_count"] == 5
    assert tied["missing_checks"] == []


def test_mi_inclusive_exact_cutoff_uses_max_denominator_and_full_population_na():
    from padml.f5 import _mi_top_risk_overlap
    ids = [f"mi-tie-{index}" for index in range(20)]
    def matrix(risks):
        return [[1.0] + [1.0 - risk] * 36 for risk in risks]
    odd = matrix([0.75, 0.5, 0.5] + [0.125] * 17)
    even = matrix([0.75, 0.25, 0.5] + [0.125] * 17)
    result = _mi_top_risk_overlap(ids, odd, even)
    assert result["k"] == 2
    assert result["groups"]["odd"]["patient_count"] == 3
    assert result["groups"]["even"]["patient_count"] == 2
    assert result["overlap"] == 2 / 3
    # Exact next binary64 value is not an approximate tie.
    odd[2] = [1.0] + [math.nextafter(0.5, 1.0)] * 36
    assert _mi_top_risk_overlap(ids, odd, even)["groups"]["odd"]["patient_count"] == 2
    constant = matrix([0.5] * 20)
    result = _mi_top_risk_overlap(ids, constant, even)
    assert result["status"] == "NOT_ESTIMABLE"
    assert result["overlap"] is None
    assert result["reason"] == "TOP_RISK_SET_EQUALS_FULL_POPULATION"


def test_sensitivity_allows_unbounded_finite_loess_error_but_never_nonfinite():
    from padml.f5_sensitivity import _valid_sensitivity_metric, _sensitivity_summary
    for name in ("ibs_24", "brier_36", "calibration_ici_24", "calibration_e50_36", "calibration_e90_24"):
        assert _valid_sensitivity_metric(name, 1.1, nullable=False)
        assert not _valid_sensitivity_metric(name, -0.1, nullable=False)
        assert not _valid_sensitivity_metric(name, math.nan, nullable=False)
        assert not _valid_sensitivity_metric(name, math.inf, nullable=False)
        assert not _valid_sensitivity_metric(name, True, nullable=False)
        assert not _valid_sensitivity_metric(name, None, nullable=False)
        assert _valid_sensitivity_metric(name, None, nullable=True)
    assert not _valid_sensitivity_metric("uno_c_24", 1.1, nullable=False)
    with pytest.raises(ContractError, match="F5_SENSITIVITY_NUMERICAL_ERROR"):
        _sensitivity_summary([0.1, math.nan])
    assert _sensitivity_summary([0.1, None])["percentile_95_ci"] is None


def test_mi_secondary_36_statistical_support_does_not_block_complete_diagnostic():
    records, receipts, response, decision, plan, centers = paired_predictions("RSF")
    response = response.replace(b",1,50\n", b",0,30\n")
    report = diagnose_mi(pool_predictions(records, receipts, decision, plan, centers),
                         centers, response, final_family="RSF")
    assert report["status"] == "COMPUTED"
    assert report["missing_checks"] == []
    assert report["odd_even_metrics"]["odd"]["calibration_ici_by_horizon"]["36"] is None
    assert report["odd_even_metrics"]["odd"]["calibration_ici_by_horizon"]["24"] is not None
    assert {row["horizon"] for row in report["statistical_not_estimable"]} == {36}


def test_unestimable_odd_even_metrics_are_reported_incomplete() -> None:
    records, receipts, response, decision, plan, centers = paired_predictions("RSF")
    no_early_events = response.replace(b",1,3\n", b",1,50\n")
    report = diagnose_mi(
        pool_predictions(records, receipts, decision, plan, centers), centers,
        no_early_events,
        final_family="RSF",
    )
    assert report["status"] == "INCOMPLETE"
    assert report["odd_even_metrics"]["absolute_difference"]["auc_24"] is None
    assert "ODD_EVEN_AUC_24_NOT_ESTIMABLE" in report["missing_checks"]


def test_named_coefficient_mi_evidence_is_recomputed_and_model_bound() -> None:
    records, receipts, response, decision, plan, centers = paired_predictions()
    pooled = pool_predictions(records, receipts, decision, plan, centers)
    coefficient_ids, evidence = coefficient_evidence(pooled)
    report = diagnose_mi(
        pooled, ["36"] * 40, response, final_family="COX_PH",
        locked_coefficient_ids=coefficient_ids, coefficient_evidence=evidence,
    )
    diagnostic = report["coefficient_mi_diagnostics"]
    assert report["status"] == "COMPUTED"
    assert diagnostic["coefficient_count"] == 2
    age = diagnostic["coefficients"][0]
    expected_between = sum(
        (value - sum(range(1, 21)) / 20 / 1000) ** 2
        for value in [imputation / 1000 for imputation in range(1, 21)]
    ) / 19
    expected_total = 0.2**2 + 1.05 * expected_between
    assert age["between_variance"] == pytest.approx(expected_between)
    assert age["total_variance"] == pytest.approx(expected_total)
    assert age["coefficient_mcse"] == pytest.approx(math.sqrt(expected_between / 20))
    assert age["mcse_to_pooled_se_ratio"] == pytest.approx(
        math.sqrt(expected_between / 20) / math.sqrt(expected_total)
    )
    assert report["coefficient_mcse_applicable"] is True
    evidence["model_sha256_by_imputation"][0] = "f" * 64
    with pytest.raises(ContractError, match="F5_COEFFICIENT_EVIDENCE_MODEL_BINDING_INVALID"):
        diagnose_mi(
            pooled, ["36"] * 40, response, final_family="COX_PH",
            locked_coefficient_ids=coefficient_ids, coefficient_evidence=evidence,
        )
    rsf_records, rsf_receipts, _, rsf_decision, rsf_plan, rsf_centers = (
        paired_predictions("RSF")
    )
    rsf_pooled = pool_predictions(
        rsf_records, rsf_receipts, rsf_decision, rsf_plan, rsf_centers
    )
    with pytest.raises(ContractError, match="F5_COEFFICIENT_EVIDENCE_NOT_APPLICABLE"):
        diagnose_mi(
            rsf_pooled, ["36"] * 40, response, final_family="RSF",
            locked_coefficient_ids=coefficient_ids, coefficient_evidence=evidence,
        )


@pytest.mark.parametrize("complete_df", [18, 500])
@pytest.mark.parametrize("case", ["ordinary", "zero_between", "tiny_between", "near_zero_within"])
def test_cox_fmi_and_degrees_of_freedom_match_native_mice(complete_df, case) -> None:
    pooled = {"per_imputation_predictions": [
        {"model_sha256": f"{i:064x}"} for i in range(1, 21)
    ]}
    ids, evidence = coefficient_evidence(pooled)
    evidence["complete_data_df_by_imputation"] = [complete_df] * 20
    row = evidence["coefficients"][0]
    if case == "zero_between":
        row["estimates"] = [0.2] * 20
    elif case == "tiny_between":
        row["estimates"] = [0.2 + i * 1e-10 for i in range(20)]
    elif case == "near_zero_within":
        row["within_standard_errors"] = [1e-9] * 20
    observed = coefficient_mi_diagnostics(pooled, "COX_PH", ids, evidence)["coefficients"][0]
    reference = subprocess.run(["Rscript", "--vanilla", "-e", r'''
      suppressPackageStartupMessages({library(mice);library(jsonlite)})
      x <- fromJSON(file("stdin"))
      p <- mice::pool.scalar(x$q,x$u,n=x$df+2,k=2)
      cat(toJSON(list(b=p$b,t=p$t,r=p$r,df=p$df,fmi=p$fmi,
                     lambda=(1+1/20)*p$b/p$t),auto_unbox=TRUE,digits=NA))
    '''], input=canonical_json_bytes({"q": row["estimates"],
        "u": [se**2 for se in row["within_standard_errors"]], "df": complete_df}),
        capture_output=True, check=True)
    expected = json.loads(reference.stdout)
    for field, name in {
        "between_variance": "b", "total_variance": "t",
        "relative_increase_in_variance": "r", "barnard_rubin_degrees_of_freedom": "df",
        "fraction_missing_information": "fmi", "missing_variance_fraction": "lambda",
    }.items():
        assert observed[field] == pytest.approx(expected[name], rel=5e-13, abs=1e-12)
    assert observed["relative_efficiency_m20"] == pytest.approx(1 / (1 + expected["fmi"] / 20))
    assert 0 <= observed["missing_variance_fraction"] <= observed["fraction_missing_information"] <= 1
    if case == "ordinary":
        assert observed["fraction_missing_information"] != pytest.approx(
            observed["missing_variance_fraction"], abs=1e-6)


@pytest.mark.parametrize("degrees", [None, [], [0] * 20, [18] * 19,
                                    [18] * 19 + [17], [18.0] * 20])
def test_cox_coefficient_mi_requires_real_complete_data_df(degrees) -> None:
    pooled = {"per_imputation_predictions": [
        {"model_sha256": f"{i:064x}"} for i in range(1, 21)
    ]}
    ids, evidence = coefficient_evidence(pooled)
    evidence["complete_data_df_by_imputation"] = degrees
    with pytest.raises(ContractError, match="F5_COEFFICIENT_COMPLETE_DATA_DF_INVALID"):
        coefficient_mi_diagnostics(pooled, "COX_PH", ids, evidence)


def test_elastic_coefficients_are_descriptive_and_never_pseudo_rubin() -> None:
    records, receipts, _, decision, plan, centers = paired_predictions(
        "ELASTIC_NET_COX"
    )
    pooled = pool_predictions(records, receipts, decision, plan, centers)
    coefficient_ids, evidence = elastic_coefficient_evidence(pooled)
    observed = coefficient_mi_diagnostics(
        pooled, "ELASTIC_NET_COX", coefficient_ids, evidence
    )
    assert observed["inference"] == (
        "NOT_APPLICABLE_ADAPTIVE_PENALIZED_ESTIMATOR"
    )
    assert observed["unpenalized_reference_fit_added"] is False
    assert observed["mean_coefficient_is_deployment_model"] is False
    assert observed["deployment_prediction"] == (
        "EQUAL_MEAN_OF_TWENTY_PROBABILITIES"
    )
    age = observed["coefficients"][0]
    assert age["standardized_estimates"][:5] == [0.0] * 5
    assert age["nonzero_frequency"] == 0.75
    assert age["positive_frequency"] == 0.75
    assert age["negative_frequency"] == 0.0
    assert age["rubin_standard_error"] == "NOT_APPLICABLE"
    assert age["rubin_fraction_missing_information"] == "NOT_APPLICABLE"
    assert age["rubin_degrees_of_freedom"] == "NOT_APPLICABLE"
    assert age["p_value"] == "NOT_APPLICABLE"
    expected_sd = math.sqrt(sum(
        (value - sum(age["standardized_estimates"]) / 20) ** 2
        for value in age["standardized_estimates"]
    ) / 19)
    assert age[
        "descriptive_mcse_mean_independent_imputation_approximation"
    ] == pytest.approx(expected_sd / math.sqrt(20))


def test_native_private_input_to_result_retains_mi_and_no_stage_acceptance(tmp_path: Path) -> None:
    records, receipts, response, decision, plan, centers = paired_predictions("RSF")
    data = {
        "kind": "PADML_F5_PAIRED_M20_PREDICTIONS", "predictions": records,
        "final_refit_receipts": receipts,
        "final_refit_plan": plan,
        "family_decision": decision,
        "centers": centers,
        "final_family": "RSF",
    }
    source, target = tmp_path / "input.zip", tmp_path / "result.zip"
    write_deterministic_zip(source, {"predictions.json": canonical_json_bytes(data), "response.csv": response})
    report = execute(source, target)
    assert report["status"] == "COMPUTED"
    assert report["stage_acceptance"] is False
    result = strict_json_bytes(read_safe_zip(target)["f5-mi.json"])
    assert len(result["pooled"]["per_imputation_predictions"]) == 20
    assert result["full_data_refit"] is False
    assert result["final_refit_artifacts"] is None
    assert result["full_pipeline_bootstrap"] is False
    before = target.read_bytes()
    with pytest.raises(ContractError, match="F5_RESULT_TARGET_INVALID"):
        execute(source, target)
    assert target.read_bytes() == before


def a12_prediction_fixture() -> tuple[dict, bytes]:
    center_ids = ["36", "38", "39", "48", "52", "54"]
    ids = [f"a12-{index:03d}" for index in range(180)]
    centers = [center for center in center_ids for _ in range(30)]
    levels = {
        "PRIMARY_POLICY_A": 0.80,
        "WITHOUT_AST_ALT_DIRECT": 0.81,
        "WITHOUT_AST_ALT_TOTAL": 0.82,
    }
    survival = {
        branch: [[1.0] + [level] * 36 for _ in ids]
        for branch, level in levels.items()
    }
    provenance = []
    for branch in A12_BRANCHES:
        provenance.append(
            {
                "branch": branch,
                "family": "RSF",
                "prediction_sha256": _seal_prediction_matrix(
                    ids, survival[branch], HORIZONS
                )["sha256"],
                "producer_receipt_sha256": sha256_bytes(
                    f"a12-{branch}".encode()
                ),
                "variable_policy": {
                    "PRIMARY_POLICY_A": "AST_ALT_INCLUDED_POLICY_A",
                    "WITHOUT_AST_ALT_DIRECT": (
                        "REMOVE_AST_ALT_KEEP_IMPUTATION_AUXILIARIES"
                    ),
                    "WITHOUT_AST_ALT_TOTAL": (
                        "REMOVE_AST_ALT_AND_AST_ALT_INFORMATION_CHANNEL"
                    ),
                }[branch],
                "mice_policy": {
                    "PRIMARY_POLICY_A": "REUSE_ACCEPTED_POLICY_A_M20",
                    "WITHOUT_AST_ALT_DIRECT": "REUSE_ACCEPTED_POLICY_A_M20",
                    "WITHOUT_AST_ALT_TOTAL": "FRESH_SPLIT_LOCAL_M20",
                }[branch],
                "parameter_policy": (
                    "REUSE_ACCEPTED_POLICY_A_PREDICTIONS"
                    if branch == "PRIMARY_POLICY_A"
                    else "FAIR_WITHIN_FAMILY_UNCHANGED_GRID"
                ),
                "primary_prediction_reused": branch == "PRIMARY_POLICY_A",
                "family_reselection": False,
                "grid_relaxed": False,
                "selection_effect": "NONE",
            }
        )
    handoff = {
        "kind": "PADML_F5_A12_ALIGNED_PREDICTIONS_V1",
        "final_family": "RSF",
        "patient_ids": ids,
        "patient_keys": {patient: sha256_bytes(patient.encode()) for patient in ids},
        "centers": centers,
        "horizons": HORIZONS.copy(),
        "survival": survival,
        "branch_provenance": provenance,
    }
    response = (
        "Patient_ID,All_Cause_Death,Death_Followup_months\n"
        + "".join(f"{patient},1,50\n" for patient in ids)
    ).encode()
    return handoff, response


def test_a12_uses_one_paired_bootstrap_without_fit_or_selection_feedback(
    monkeypatch,
) -> None:
    handoff, response = a12_prediction_fixture()

    def fake_evaluation(selected, response_csv, *, include_center_scopes=True):
        assert response_csv.startswith(b"Patient_ID,")
        def metrics(indices):
            rows = {}
            for branch, matrix in selected["survival"].items():
                value = math.fsum(matrix[index][24] for index in indices) / len(
                    indices
                )
                rows[branch] = {
                    "ibs_0_to": {
                        str(horizon): value for horizon in REPORT_HORIZONS
                    },
                    "brier_monthly": [value] * 37,
                    "discrimination": {
                        "uno_c_24": {"value": value},
                        "auc": {
                            str(horizon): {"value": value}
                            for horizon in REPORT_HORIZONS
                        },
                    },
                    "calibration": {
                        "horizons": {
                            str(horizon): {
                                key: value
                                for key in (
                                    "slope",
                                    "citl",
                                    "oe",
                                    "ici",
                                    "e50",
                                    "e90",
                                )
                            }
                            for horizon in REPORT_HORIZONS
                        }
                    },
                    "dca_24": {"integrated_raw_nb": value},
                }
            return rows

        scopes = [
            {
                "scope": "MICRO",
                "families": metrics(range(len(selected["patient_ids"]))),
            }
        ]
        if include_center_scopes:
            scopes.extend(
                {
                    "scope": center,
                    "families": metrics(
                        [
                            index
                            for index, value in enumerate(selected["centers"])
                            if value == center
                        ]
                    ),
                }
                for center in ("36", "38", "39", "48", "52", "54")
            )
        macro = {}
        for branch in A12_BRANCHES:
            center_values = [
                row["families"][branch]["ibs_0_to"]["24"]
                for row in scopes[1:]
            ]
            value = math.fsum(center_values) / len(center_values)
            macro[branch] = {
                str(horizon): {
                    "equal_center_ibs": value,
                    "equal_center_brier": value,
                    "equal_center_auc": value,
                    "mean_absolute_slope_error": abs(value - 1.0),
                    "mean_absolute_citl": abs(value),
                    "equal_center_oe": value,
                    "equal_center_ici": value,
                    "equal_center_e50": value,
                    "equal_center_e90": value,
                    **({
                        "equal_center_uno_c": value,
                        "equal_center_raw_dca": value,
                    } if horizon == 24 else {}),
                }
                for horizon in REPORT_HORIZONS
            }
        return {"scopes": scopes, "macro": macro}

    monkeypatch.setattr(
        "padml.f5_sensitivity.evaluate_predictions", fake_evaluation
    )
    monkeypatch.setattr(
        "padml.f5_sensitivity.bootstrap_draws",
        lambda ids, centers, domain, replicate_count, patient_keys, rscript: {
            "root_seed": 700000001,
            "replicate_count": replicate_count,
            "rng": ["L'Ecuyer-CMRG", "Inversion", "Rejection"],
            "stratification": "CENTER",
            "draws": [list(range(len(ids)))] * replicate_count,
        },
    )
    monkeypatch.setattr(
        "padml.f5_sensitivity._bounded_ordered_spawn",
        lambda worker, tasks, **unused: [worker(task) for task in tasks],
    )
    result = evaluate_a12_incremental_value(
        handoff, response, replicate_count=2, workers=2
    )
    assert result["status"] == "REDUCED_DECLARED_EVIDENCE"
    assert result["execution_evidence_status"] == (
        "NOT_VERIFIED_REFERENCES_ONLY"
    )
    assert result["blocking_for_production"] is True
    assert result["bootstrap"]["root_seed"] == 700000001
    assert result["point_deltas"]["WITHOUT_AST_ALT_DIRECT"][
        "ibs_0_24"
    ] == pytest.approx(0.01)
    assert result["point_deltas"]["WITHOUT_AST_ALT_TOTAL"][
        "auc_24"
    ] == pytest.approx(0.02)
    assert result["bootstrap"]["paired_row_count"] == 608
    paired = result["bootstrap"]["paired_rows"]
    row = next(
        row
        for row in paired
        if row["branch"] == "WITHOUT_AST_ALT_DIRECT"
        and row["scope"] == "36"
        and row["metric"] == "brier_24"
    )
    assert row["bootstrap"]["percentile_95_ci"] == pytest.approx(
        [0.01, 0.01]
    )
    assert set(result["point_deltas_by_scope"]) == {
        "MICRO", "36", "38", "39", "48", "52", "54"
    }
    assert result["bootstrap"]["primary_estimand"] == "EQUAL_CENTER_MACRO"
    assert set(result["point_macro_deltas"]) == set(A12_BRANCHES[1:])
    assert result["model_fit_count"] == result["grid_search_count"] == 0
    assert result["family_reselection_count"] == 0
    assert result["selection_effect"] == "NONE"
    assert result["stage_acceptance"] is False


def test_a12_mismatched_patient_keys_stop_before_evaluation(monkeypatch) -> None:
    handoff, response = a12_prediction_fixture()
    handoff["patient_keys"] = dict.fromkeys(handoff["patient_ids"], "a" * 64)

    def forbidden(*args, **kwargs):
        pytest.fail("unresolved patient keys must not start RNG or evaluation")

    monkeypatch.setattr("padml.f4.subprocess.run", forbidden)
    monkeypatch.setattr("padml.f5_sensitivity.evaluate_predictions", forbidden)
    with pytest.raises(ContractError, match="F45_PATIENT_KEY_MAPPING_MISMATCH"):
        evaluate_a12_incremental_value(handoff, response, replicate_count=2, workers=1)


def test_a12_fails_closed_on_nonformal_budget_or_prediction_drift() -> None:
    handoff, response = a12_prediction_fixture()
    with pytest.raises(ContractError, match="F5_A12_BOOTSTRAP_PROFILE_INVALID"):
        evaluate_a12_incremental_value(
            handoff, response, replicate_count=2, formal=True
        )
    with pytest.raises(ContractError, match="F5_A12_BOOTSTRAP_PROFILE_INVALID"):
        evaluate_a12_incremental_value(
            handoff, response, replicate_count=1000, workers=0, formal=True
        )
    damaged = copy.deepcopy(handoff)
    damaged["survival"]["WITHOUT_AST_ALT_DIRECT"][0][24] = math.nan
    with pytest.raises(ContractError):
        evaluate_a12_incremental_value(damaged, response, replicate_count=1)
    damaged = copy.deepcopy(handoff)
    damaged["branch_provenance"][1]["grid_relaxed"] = True
    with pytest.raises(ContractError, match="F5_A12_PROVENANCE_INVALID"):
        evaluate_a12_incremental_value(damaged, response, replicate_count=1)
    damaged = copy.deepcopy(handoff)
    damaged["branch_provenance"][1]["producer_receipt_sha256"] = damaged[
        "branch_provenance"
    ][0]["producer_receipt_sha256"]
    with pytest.raises(ContractError, match="F5_A12_PRODUCER_ALIAS_FORBIDDEN"):
        evaluate_a12_incremental_value(damaged, response, replicate_count=1)


def a19_prediction_fixture(count: int = 150) -> tuple[list[dict], dict[str, str], bytes]:
    ids = [f"{index + 1:064x}" for index in range(count)]
    centers = {
        patient: ("36", "38", "39", "48", "52", "54", "55")[index % 7]
        for index, patient in enumerate(ids)
    }
    response = (
        "Patient_ID,All_Cause_Death,Death_Followup_months\n"
        + "".join(f"{patient},1,50\n" for patient in ids)
    ).encode()
    survival_by_role = {
        "BASE": 0.90,
        "EXTRA_OFFSET_10000": 0.89,
        "EXTRA_OFFSET_20000": 0.88,
    }
    family_decision_sha256 = sha256_bytes(b"a19-final-family-decision")
    parameter_lock_sha256 = sha256_bytes(b"a19-final-parameter-lock")
    rows = []
    for repeat in range(1, 4):
        for fold in range(1, 6):
            patients = [
                patient
                for index, patient in enumerate(ids)
                if (index + repeat - 1) % 5 == fold - 1
            ]
            patient_set_sha256 = sha256_bytes(
                canonical_json_bytes(sorted(patients))
            )
            split_seed = 100_000 + repeat * 100
            split_sha256 = sha256_bytes(canonical_json_bytes({
                "coordinates": {
                    "virtual_outer": 0,
                    "repeat": repeat,
                    "inner_fold": fold,
                },
                "split_seed": split_seed,
                "evaluation_patient_keys": sorted(patients),
            }))
            for role in A19_SEED_ROLES:
                model_seed = (
                    300_000 + repeat * 100 + fold + {
                        "BASE": 0,
                        "EXTRA_OFFSET_10000": 10_000,
                        "EXTRA_OFFSET_20000": 20_000,
                    }[role]
                )
                seed_sha256 = sha256_bytes(canonical_json_bytes({
                    "rng_kind": "L'Ecuyer-CMRG",
                    "coordinates": {
                        "virtual_outer": 0,
                        "repeat": repeat,
                        "inner_fold": fold,
                    },
                    "seed_role": role,
                    "model_seed": model_seed,
                }))
                for imputation in range(1, 6):
                    patient_rows = [
                        {
                            "patient_key_hash": patient,
                            "survival_probabilities": [1.0]
                            + [survival_by_role[role]] * 36,
                        }
                        for patient in patients
                    ]
                    rows.append(
                        {
                            "inner_repeat_id": repeat,
                            "inner_fold_id": fold,
                            "split_identity_sha256": split_sha256,
                            "split_seed": split_seed,
                            "seed_role": role,
                            "seed_identity_sha256": seed_sha256,
                            "model_seed": model_seed,
                            "imp_id": imputation,
                            "final_family": "RSF",
                            "final_family_decision_sha256": (
                                family_decision_sha256
                            ),
                            "final_parameter_lock_sha256": (
                                parameter_lock_sha256
                            ),
                            "fit_receipt_sha256": sha256_bytes(
                                f"a19-fit-{repeat}-{fold}-{role}-{imputation}".encode()
                            ),
                            "prediction_sha256": sha256_bytes(
                                canonical_json_bytes(patient_rows)
                            ),
                            "patient_set_sha256": patient_set_sha256,
                            "time_grid_months": HORIZONS.copy(),
                            "patients": patient_rows,
                        }
                    )
    return rows, centers, response


def test_a19_uses_m5_then_max_split_sample_sd_and_type7_patient_range() -> None:
    rows, centers, response = a19_prediction_fixture()
    base_rows = [
        row
        for row in rows
        if row["inner_repeat_id"] == 1
        and row["inner_fold_id"] == 1
        and row["seed_role"] == "BASE"
    ]
    for row, value in zip(base_rows, (0.80, 0.85, 0.90, 0.95, 1.00), strict=True):
        for patient in row["patients"]:
            patient["survival_probabilities"] = [1.0] + [value] * 36
        row["prediction_sha256"] = sha256_bytes(
            canonical_json_bytes(row["patients"])
        )
    result = compute_a19_multi_seed_stability(rows, centers, response)
    assert result["status"] == "REDUCED_DECLARED_EVIDENCE"
    assert result["input_row_count"] == 225
    assert result["split_count"] == 15
    assert result["repeat_patient_range_count"] == 450
    assert result["aggregation_order"] == "M5_SURVIVAL_MEAN_THEN_IBS"
    assert result["split_seed_sd_ddof"] == 1
    assert result["statistics"]["sd_seed_ibs_0_24"] == max(
        row["sd_seed_ibs_0_24"] for row in result["split_statistics"]
    )
    assert result["split_statistics"][0]["ibs_0_24_by_seed_role"][
        "BASE"
    ] == pytest.approx(23.5 * 0.10**2 / 24)
    assert result["statistics"][
        "p95_patient_24m_risk_seed_range"
    ] == pytest.approx(0.02)
    assert result["warnings"][0]["triggered"] is True
    assert result["warnings"][1]["triggered"] is False
    assert result["warning_only"] is True
    assert result["declared_fit_receipt_count"] == 225
    assert result["execution_evidence_status"] == (
        "NOT_VERIFIED_REFERENCES_ONLY"
    )
    assert result["development_centers"] == ["36", "38", "39", "48", "52", "54", "55"]
    assert result["blocking_for_production"] is True
    assert result["model_fit_count"] == result["family_reselection_count"] == 0
    assert result["selection_effect"] == "NONE"


@pytest.mark.parametrize("change,code", [
    ({"imputation": 2}, "F4_MODEL_IMPUTATION_MISMATCH"),
    ({"imputation": True}, "F4_MODEL_IMPUTATION_MISMATCH"),
    ({"registered_model_seed": 301001.0}, "F4_MODEL_SEED_INVALID"),
    ({"model_seed": 301001}, "F4_MODEL_SEED_INVALID"),
])
def test_f4_native_engine_rejects_mixed_imputation_or_rng_before_fit(monkeypatch, change, code):
    task = {"family": "COX_PH", "selected_parents": ["AST_ALT"], "imputation": 1,
            "parameters": {"family": "COX_PH", "ties": "breslow"},
            "f4_coordinates": {"purpose": "O_FIT", "outer_fold": 1, "repeat": 0,
                               "inner_fold": 0, "imputation": 1},
            "registered_model_seed": 301001, "model_seed": None, **change}
    monkeypatch.setattr("padml.f5.subprocess.run", lambda *a, **k: pytest.fail("No native execution permitted"))
    with pytest.raises(ContractError, match=code):
        _execute_final_refit_engine("COX_PH", task, [], {}, _test_final_design_recipe("COX_PH", ["AST_ALT"]))


@pytest.mark.parametrize("save_locale,replay_locale", [("en_US.UTF-8", "C"), ("C", "en_US.UTF-8")])
def test_native_r_training_binding_save_replay_without_model_or_rng(tmp_path, save_locale, replay_locale) -> None:
    kernel = Path(__file__).parents[1] / "padml/kernels/f5_final_refit.R"
    ids = ["00001", "患者02", 'é,e\u0301"03']
    for name, fields, values in (
        ("covariates.csv", ["Patient_ID", "Center", "AST_ALT"],
         [(patient, "36" if i < 2 else "55", i+1) for i, patient in enumerate(ids)]),
        ("response.csv", ["Patient_ID", "All_Cause_Death", "Death_Followup_months"],
         [(patient, int(i != 1), i+1) for i, patient in enumerate(ids)]),
    ):
        stream = io.StringIO(newline="")
        writer = csv.writer(stream, lineterminator="\n")
        writer.writerow(fields)
        writer.writerows(values)
        (tmp_path / name).write_bytes(stream.getvalue().encode())
    code = r'''
      args <- commandArgs(TRUE)
      wanted <- c("fail","need","scalar","native_training_binding",
                  "validate_native_training_binding","write_objects")
      definitions <- Filter(function(x) is.call(x) && identical(x[[1]],as.name("<-")) &&
        is.symbol(x[[2]]) && as.character(x[[2]]) %in% wanted, as.list(parse(args[[1]])))
      stopifnot(length(definitions)==length(wanted))
      for(definition in definitions) eval(definition)
      stopifnot(!exists(".Random.seed",envir=.GlobalEnv,inherits=FALSE))
      spec <- list(family="GBM_COX", model_seed=301001L, imputation=1L,
                   selected_parents=list("AST_ALT"), parameters=list(locked_trees=96L), recipe=list(mode="RAW"),
                   f4_coordinates=list(purpose="O_FIT", outer_fold=1L, "repeat"=0L, inner_fold=0L, imputation=1L),
                   covariate_path=file.path(args[[2]],"covariates.csv"), response_path=file.path(args[[2]],"response.csv"),
                   model_path=file.path(args[[2]],"model.rds"), baseline_path=file.path(args[[2]],"baseline.rds"))
      reads <- Filter(function(x) is.call(x) && identical(x[[1]],as.name("<-")) &&
        is.symbol(x[[2]]) && as.character(x[[2]]) %in% c("covariates","response") &&
        is.call(x[[3]]) && identical(x[[3]][[1]],as.name("read.csv")),as.list(parse(args[[1]])))
      stopifnot(length(reads)==2L)
      for(statement in reads) eval(statement)
      ids <- as.character(covariates$Patient_ID); centers <- as.character(covariates$Center)
      stopifnot(identical(ids,as.character(response$Patient_ID)))
      design <- matrix(as.numeric(covariates$AST_ALT),ncol=1,dimnames=list(NULL,"AST_ALT"))
      time <- as.numeric(response$Death_Followup_months); event <- as.integer(response$All_Cause_Death)
      training_binding <- native_training_binding(spec,ids,centers,design,time,event)
      # Deliberately not a scientific model: this tests native RDS binding I/O only.
      if(args[[3]]=="SAVE") write_objects(list(test_object="UNFITTED"),list(test_baseline="UNFITTED"))
      model <- readRDS(spec$model_path); baseline <- readRDS(spec$baseline_path)
      validate_native_training_binding(model,baseline,training_binding,spec$model_path)
      bad <- function(expected, object=model, base=baseline) {
        error <- tryCatch({validate_native_training_binding(object,base,expected,spec$model_path);NULL},error=identity)
        stopifnot(inherits(error,"error"),conditionMessage(error)=="F5_REPLAY_NATIVE_TRAINING_BINDING_MISMATCH")
      }
      for(field in c("model_seed","imputation")) {
        changed <- spec; changed[[field]] <- changed[[field]]+1L
        bad(native_training_binding(changed,ids,centers,design,time,event))
      }
      changed <- spec; changed$f4_coordinates$outer_fold <- 2L
      bad(native_training_binding(changed,ids,centers,design,time,event))
      changed <- spec; changed$parameters$locked_trees <- 97L
      bad(native_training_binding(changed,ids,centers,design,time,event))
      bad(native_training_binding(spec,rev(ids),centers,design,time,event))
      bad(native_training_binding(spec,ids,rev(centers),design,time,event))
      bad(native_training_binding(spec,ids,centers,design+.1,time,event))
      bad(native_training_binding(spec,ids,centers,design,rev(time),event))
      bad(native_training_binding(spec,ids,centers,design,time,c(0L,1L,1L)))
      bad(training_binding,list(test_object="UNFITTED"))
      changed <- baseline; changed$model_object_sha256 <- paste(rep("0",64),collapse="")
      bad(training_binding,base=changed)
      stopifnot(!exists(".Random.seed",envir=.GlobalEnv,inherits=FALSE))
      cat("PASS:11 mismatches;0 fits;0 RNG\n")
    '''
    for action, locale in (("SAVE", save_locale), ("REPLAY", replay_locale)):
        completed = subprocess.run(["Rscript", "--vanilla", "-e", code, str(kernel), str(tmp_path), action],
                                   env={**os.environ, "LC_ALL": locale, "LANG": locale}, capture_output=True, check=True)
        assert completed.stdout == b"PASS:11 mismatches;0 fits;0 RNG\n"


@pytest.mark.parametrize("family,engine_name", [("XGBOOST_COX", "_execute_final_xgboost"),
                                              ("COXTIME_SET_A", "_execute_final_coxtime")])
def test_python_native_failure_retains_input_and_state_without_fitting(tmp_path, monkeypatch, family, engine_name):
    from padml import f5
    original_mkdtemp = f5.tempfile.mkdtemp
    monkeypatch.setattr(f5.tempfile, "mkdtemp", lambda **kw: original_mkdtemp(dir=tmp_path, **kw))
    task = {"family": family, "selected_parents": ["AST_ALT"], "model_seed": 300000,
            "imputation": 1, "parameters": {"family": family}}
    recipe = _test_final_design_recipe(family, ["AST_ALT"])
    observed = []
    def stub(task, rows, response, recipe, *, native_evidence):
        observed.append(native_evidence)
        assert (native_evidence / "input.json").is_file()
        (native_evidence / "model.bin").write_bytes(b"UNFITTED_UNIT_STUB")
        raise ContractError("INJECTED_POST_TRAIN_FAILURE_WITHOUT_FIT")
    monkeypatch.setattr(f5, engine_name, stub)
    with pytest.raises(ContractError, match="INJECTED_POST_TRAIN_FAILURE_WITHOUT_FIT") as captured:
        f5._execute_final_refit_engine(family, task, [], {}, recipe)
    root, = observed
    assert (root / "model.bin").read_bytes() == b"UNFITTED_UNIT_STUB"
    assert strict_json_bytes((root / "input.json").read_bytes())["task"] == task
    assert captured.value.__notes__ == [f"F5_FINAL_REFIT_NATIVE_EVIDENCE_RETAINED:{root}"]
    assert not (root / "baseline.bin").exists()


def test_native_python_training_binding_rejects_relabelled_inputs_without_fits():
    import numpy as np
    from padml.f5 import _native_python_training_binding, _validate_python_training_binding
    task = {"model_seed": 301001, "imputation": 1, "selected_parents": ["AST_ALT"],
            "parameters": {"selected_rounds": 2}, "f4_coordinates": {"outer_fold": 1}}
    rows = [{"Patient_ID": "a", "Center": "36"}, {"Patient_ID": "b", "Center": "55"}]
    recipe, design = {"mode": "RAW"}, np.array([[1.0], [2.0]], dtype="float32")
    times, events = np.array([1., 2.]), np.array([1, 0])
    def bind(*, current=task, patients=rows, matrix=design, time=times, event=events):
        return _native_python_training_binding("XGBOOST_COX", current, patients, recipe,
                                                matrix, ["AST_ALT"], time, event)
    expected, model = bind(), b"UNFITTED TEST OBJECT"
    baseline = {"training_binding": expected, "model_object_sha256": sha256_bytes(model)}
    _validate_python_training_binding(expected, baseline, expected, model)
    for key, value in (("model_seed", 301002), ("imputation", 2),
                       ("f4_coordinates", {"outer_fold": 2}), ("parameters", {"selected_rounds": 3})):
        with pytest.raises(ContractError, match="F5_REPLAY_NATIVE_TRAINING_BINDING_MISMATCH"):
            _validate_python_training_binding(expected, baseline, bind(current={**task, key:value}), model)
    for changed in (bind(patients=list(reversed(rows))), bind(matrix=design+.1),
                    bind(time=times[::-1]), bind(event=events[::-1])):
        with pytest.raises(ContractError, match="F5_REPLAY_NATIVE_TRAINING_BINDING_MISMATCH"):
            _validate_python_training_binding(expected, baseline, changed, model)
    with pytest.raises(ContractError, match="F5_REPLAY_NATIVE_TRAINING_BINDING_MISMATCH"):
        _validate_python_training_binding(expected, baseline, expected, b"OTHER UNFITTED OBJECT")
    with pytest.raises(ContractError, match="F5_REPLAY_NATIVE_TRAINING_BINDING_MISMATCH"):
        _validate_python_training_binding(None, baseline, expected, model)


def test_a19_strict_threshold_equality_does_not_warn() -> None:
    warnings = _a19_warning_rows(
        {
            "sd_seed_ibs_0_24": 0.002,
            "p95_patient_24m_risk_seed_range": 0.03,
        }
    )
    assert [row["triggered"] for row in warnings] == [False, False]
    assert {row["comparison_operator"] for row in warnings} == {
        "STRICT_GREATER_THAN"
    }


def test_a19_uses_complete_parent_ipcw_without_dropping_split_patients() -> None:
    rows, centers, raw = a19_prediction_fixture(350)
    ids = sorted(centers)
    censored = {patient for index, patient in enumerate(ids)
                if centers[patient] == "55" and index % 5 == 0}
    for patient in censored:
        raw = raw.replace(f"{patient},1,50\n".encode(), f"{patient},0,12\n".encode())
    result = compute_a19_multi_seed_stability(rows, centers, raw)
    assert result["statistical_status"] == "ESTIMABLE"
    assert result["sd_estimable_split_count"] == 15
    split = result["split_statistics"][0]
    assert split["patient_count"] == 70
    assert split["censoring_reference"]["patient_count"] == 350
    assert split["ipcw_qc"][23]["ghat_right_by_center"]["55"] == pytest.approx(0.8)
    assert split["ipcw_qc"][23]["n_censored"] == len(censored) == 10
    assert split["ipcw_qc"][23]["effective_sample_size"] == 60
    # Months 1..11 have 70 controls; from month 12 only 60 remain evaluable.
    expected = (11 * .1**2 + 12.5 * (60 / 70) * .1**2) / 24
    assert split["ibs_0_24_by_seed_role"]["BASE"] == pytest.approx(expected)


def test_a19_keeps_all_support_na_coordinates_but_rejects_numeric_or_missing(monkeypatch) -> None:
    rows, centers, raw = a19_prediction_fixture(155)
    patient = sorted(centers)[0]
    raw = raw.replace(f"{patient},1,50\n".encode(), f"{patient},0,12\n".encode())
    result = compute_a19_multi_seed_stability(rows, centers, raw)
    assert result["statistical_status"] == "PARTIALLY_NOT_ESTIMABLE"
    assert result["sd_estimable_split_count"] == 12
    assert len(result["split_statistics"]) == 15
    assert result["statistics"]["sd_seed_ibs_0_24"] is None
    assert result["warnings"][0]["triggered"] is None
    assert result["statistics"]["p95_patient_24m_risk_seed_range"] == pytest.approx(.02)
    assert result["warnings"][1]["triggered"] is False
    assert result["split_statistics"][0]["ipcw_qc"][23]["reasons"] == ["EFFECTIVE_SAMPLE_SIZE_INSUFFICIENT"]
    assert result["any_warning"] is None
    warning_rows = copy.deepcopy(rows)
    for row in warning_rows:
        if row["seed_role"] == "EXTRA_OFFSET_20000":
            for item in row["patients"]:
                item["survival_probabilities"] = [1.0] + [.8] * 36
            row["prediction_sha256"] = sha256_bytes(canonical_json_bytes(row["patients"]))
    warning_result = compute_a19_multi_seed_stability(warning_rows, centers, raw)
    assert [row["triggered"] for row in warning_result["warnings"]] == [None, True]
    assert warning_result["any_warning"] is True
    equal_rows = copy.deepcopy(rows)
    for row in equal_rows:
        for item in row["patients"]:
            item["survival_probabilities"] = [1.0] + [.9] * 36
        row["prediction_sha256"] = sha256_bytes(canonical_json_bytes(row["patients"]))
    _, _, complete_response = a19_prediction_fixture(155)
    equal_result = compute_a19_multi_seed_stability(equal_rows, centers, complete_response)
    assert [row["triggered"] for row in equal_result["warnings"]] == [False, False]
    assert equal_result["any_warning"] is False
    damaged = raw.replace(f"{patient},0,12\n".encode(), b"")
    with pytest.raises(ContractError, match="F5_A19_PARENT_RESPONSE_COVERAGE_INVALID"):
        compute_a19_multi_seed_stability(rows, centers, damaged)
    from padml import f5_sensitivity
    monkeypatch.setattr(f5_sensitivity, "prediction_error",
                        lambda *args: {"ibs_0_to": {"24": math.nan}})
    with pytest.raises(ContractError, match="F5_A19_IBS_INVALID"):
        compute_a19_multi_seed_stability(rows, centers, raw)
    _, _, supported = a19_prediction_fixture(155)
    monkeypatch.setattr(f5_sensitivity, "prediction_error",
                        lambda *args: {"ibs_0_to": {"24": None}})
    with pytest.raises(ContractError, match="F5_A19_IBS_SUPPORT_EVIDENCE_REQUIRED"):
        compute_a19_multi_seed_stability(rows, centers, supported)


def _a19_native_job(tmp_path: Path, family: str, role: str) -> dict:
    from padml.f5 import _a19_model_seed
    rows, responses, _, _ = _python_final_refit_rows()
    if family == "GBM_COX":
        from padml.runtime import R_GBM_CORRECTION
        if not Path(R_GBM_CORRECTION).is_dir():
            pytest.skip("A19 GBM native proof requires the pinned remote GBM runtime")
    if family in {"GBM_COX", "FPM_TVC_SET_A"}:
        np = pytest.importorskip("numpy")
        rng = np.random.default_rng(71239)
        times, events = rng.exponential(10, 400) + .01, rng.binomial(1, .75, 400)
        ast_alt = rng.uniform(.2, 3, 400)
        rows = [{"Patient_ID": f"a19-gbm-{i:04d}", "Center": "36", "AST_ALT": str(ast_alt[i])}
                for i in range(400)]
        responses = {row["Patient_ID"]: {
            "Patient_ID": row["Patient_ID"], "All_Cause_Death": str(events[i]),
            "Death_Followup_months": str(times[i]),
        } for i, row in enumerate(rows)}
    application = [{**row, "Patient_ID": f"held-out-{index}"}
                   for index, row in enumerate(rows[:7])]
    coordinates = {"virtual_outer": 0, "repeat": 2, "inner_fold": 3, "seed_role": role}
    parameters = final_refit_compilation_inputs(family)[3]["component_parameters"][0]["parameters"]
    if family in {"ELASTIC_NET_COX", "FPM_TVC_SET_A"}:
        parameters = paired_predictions(family)[4]["tasks"][0]["parameters"]
    elif family == "XGBOOST_COX":
        parameters = {
            "family": family, "selected_rounds": 5,
            "parameters": {
                "eta": 0.05, "max_depth": 2, "min_child_weight": 2.0,
                "subsample": 0.8, "colsample_bytree": 0.8,
                "reg_lambda": 1.0, "reg_alpha": 0.0, "gamma": 0.0,
                "tree_method": "hist", "max_bin": 256, "max_nrounds": 20,
                "stop_scope": "training_only",
                "post_selection_refit": "full_main_training_at_best_rounds",
                "locked_iteration_mode": "full_main_training_without_reselection",
            },
        }
    elif family == "COXTIME_SET_A":
        candidate = load_science_authority()["science"]["f2_model_development"]["coxtime"]["candidates"][0]
        parameters = {"family": family, "candidate_id": candidate["candidate_id"],
                      "parameters": candidate, "locked_epoch": 30}
    if family == "GBM_COX":
        parameters = {
            "family": family, "selected_trees": 20,
            "parameters": {"interaction.depth": 2, "shrinkage": .05,
                "n.minobsinnode": 20, "bag.fraction": .8, "n.trees.max": 5000,
                "early_stopping_metric": "cox_deviance",
                "post_selection_refit": "full_main_training_at_selected_n_trees",
                "locked_iteration_mode": "full_main_training_without_reselection"},
        }
    task = {
        "family": family, "selected_parents": ["AST_ALT"], "parameters": parameters,
        "imputation": 1, "a19_coordinates": coordinates,
        "model_seed": _a19_model_seed(coordinates) if family in {
            "RSF", "GBM_COX", "XGBOOST_COX", "COXTIME_SET_A"
        } else None,
        "row_count": len(rows), "family_design_column_count": 1,
        "family_decision_sha256": "1" * 64, "final_parameter_lock_sha256": "2" * 64,
        "evaluation_patient_keys": [sha256_bytes(row["Patient_ID"].encode()) for row in application],
    }
    def csv_bytes(values):
        stream = io.StringIO(newline="")
        writer = csv.DictWriter(stream, fieldnames=list(values[0]), lineterminator="\n")
        writer.writeheader()
        writer.writerows(values)
        return stream.getvalue().encode()
    return {"root": str(tmp_path / "component"), "entries": {
        "task.json": canonical_json_bytes(task),
        "recipe.json": canonical_json_bytes(_test_final_design_recipe(family, ["AST_ALT"])),
        "fit-covariates.csv": csv_bytes(rows),
        "fit-response.csv": csv_bytes(list(responses.values())),
        "prediction-covariates.csv": csv_bytes(application),
    }}


@pytest.mark.parametrize("family,role", [
    (family, role) for role in A19_SEED_ROLES for family in ("COX_PH", "RSF", "GBM_COX")
] + [
    (family, "BASE") for family in (
        "ELASTIC_NET_COX", "XGBOOST_COX", "COXTIME_SET_A", "FPM_TVC_SET_A"
    )
])
def test_a19_native_fit_retains_objects_and_exact_heldout_replay(tmp_path, monkeypatch, family, role):
    from padml.f5_sensitivity import _execute_a19_component, _replay_a19_component, _A19_ROW_FIELDS
    job = _a19_native_job(tmp_path, family, role)
    row = _execute_a19_component(job)
    assert set(row) == _A19_ROW_FIELDS
    assert row["model_seed"] == 300203 + A19_SEED_ROLES.index(role) * 10000
    archive = Path(job["root"]).with_suffix(".zip")
    saved = read_safe_zip(archive)
    assert saved["model.bin"] and saved["baseline.bin"]
    assert len(row["patients"]) == 7
    engine = _execute_final_refit_engine
    def forbid_new_fit(*args, **kwargs):
        assert kwargs.get("retained_objects") is not None
        return engine(*args, **kwargs)
    monkeypatch.setattr("padml.f5._execute_final_refit_engine", forbid_new_fit)
    assert _replay_a19_component({**job, "archive": str(archive)}) == row
    (tmp_path / "verification.json").write_bytes(canonical_json_bytes({
        "family": family, "role": role, "model_seed": row["model_seed"],
        "model_fit_count": 1, "mice_fit_count": 0, "grid_trial_count": 0,
        "native_training_and_heldout_replay": "EXACT_WITHOUT_REFIT",
        "synthetic_input": True, "stage_acceptance": False,
    }))
    if family == "COX_PH" and role == "BASE":
        damaged = dict(saved)
        prediction = strict_json_bytes(damaged["prediction.json"])
        prediction["patients"][0]["survival_probabilities"][24] = 0.123
        damaged["prediction.json"] = canonical_json_bytes(prediction)
        drifted = tmp_path / "drifted.zip"
        write_deterministic_zip(drifted, damaged)
        with pytest.raises(ContractError, match="F5_A19_NATIVE_PREDICTION_REPLAY_MISMATCH"):
            _replay_a19_component({**job, "archive": str(drifted)})
        wrong = copy.deepcopy(job)
        task = strict_json_bytes(wrong["entries"]["task.json"])
        task["final_parameter_lock_sha256"] = "f" * 64
        wrong["entries"]["task.json"] = canonical_json_bytes(task)
        with pytest.raises(ContractError, match="F5_A19_NATIVE_INPUT_REPLAY_MISMATCH"):
            _replay_a19_component({**wrong, "archive": str(archive)})


def test_a19_seed_and_training_application_boundary_stop_before_fit(tmp_path, monkeypatch):
    from padml.f5 import _a19_model_seed
    from padml.f5_sensitivity import _execute_a19_component
    job = _a19_native_job(tmp_path, "RSF", "BASE")
    task = strict_json_bytes(job["entries"]["task.json"])
    for coordinates in ({**task["a19_coordinates"], "repeat": True},
                        {**task["a19_coordinates"], "virtual_outer": 1},
                        {**task["a19_coordinates"], "inner_fold": 6},
                        {**task["a19_coordinates"], "seed_role": "OTHER"}):
        with pytest.raises(ContractError, match="F5_A19_COORDINATES_INVALID"):
            _a19_model_seed(coordinates)
    rows, response, _, _ = _python_final_refit_rows()
    task["model_seed"] = 300000
    with pytest.raises(ContractError, match="F5_A19_MODEL_SEED_BINDING_INVALID"):
        _execute_final_refit_engine("RSF", task, rows, response,
                                   _test_final_design_recipe("RSF", ["AST_ALT"]))
    job["entries"]["prediction-covariates.csv"] = job["entries"]["fit-covariates.csv"]
    monkeypatch.setattr("padml.f5._execute_final_refit_engine",
                        lambda *args, **kwargs: pytest.fail("must stop before a fit"))
    with pytest.raises(ContractError, match="F5_A19_FIT_APPLICATION_ISOLATION_INVALID"):
        _execute_a19_component(job)


def test_a19_prepares_all_225_from_m20_archives_without_fitting(tmp_path, monkeypatch):
    """MICE is a fixture here; recipe, split replay and A19 input isolation are real."""
    from padml.f5_sensitivity import _prepare_a19_models
    monkeypatch.setattr("padml.f5._replay_mice_native_view", lambda *unused, **options: None)
    np = pytest.importorskip("numpy")
    rng = np.random.default_rng(87123)
    centers = [center for center in (36, 38, 39, 48, 52, 54, 55) for _ in range(50)]
    source_ids = [f"a19-patient-{i:04d}" for i in range(len(centers))]
    keys = [sha256_bytes(patient.encode()) for patient in source_ids]
    events = [int(i % 4 != 0) for i in range(len(centers))]
    plan = compile_full_data_mice_plan(source_ids, keys, centers, events, family="COX_PH", workers=24)
    center_map = dict(zip(source_ids, centers))
    event_map = dict(zip(source_ids, events))
    times = dict(zip(source_ids, rng.exponential(25, len(source_ids)) + .01))
    # Keep the synthetic censoring support known before native model execution.
    # The original small fixture with early censoring is retained separately.
    for i, patient in enumerate(source_ids):
        if event_map[patient] == 0:
            times[patient] = 60.0 + i % 10
    reader = csv.DictReader(io.StringIO(private_covariates(source_ids, centers).decode()))
    covariate_rows = list(reader)
    for i, row in enumerate(covariate_rows):
        for name in reader.fieldnames:
            if name not in {"Patient_ID", "Center"}:
                row[name] = str(1 + ((i * 7) % 51) / 10)
        row["AST_ALT"] = str(.2 + rng.uniform(0, 2.8))
    stream = io.StringIO(newline="")
    writer = csv.DictWriter(stream, fieldnames=reader.fieldnames, lineterminator="\n")
    writer.writeheader()
    writer.writerows(covariate_rows)
    covariates = stream.getvalue().encode()
    response = ("Patient_ID,All_Cause_Death,Death_Followup_months\n" + "".join(
        f"{patient},{event_map[patient]},{times[patient]}\n" for patient in plan["source_ids"]
    )).encode()
    ages = {row["Patient_ID"]: row["Age"] for row in covariate_rows}
    def fixture_mice(command, **options):
        completed = fake_mice_run(command, **options)
        spec = strict_json_bytes(Path(command[-1]).read_bytes())
        for path in (Path(spec["output_dir"]) / "imputations").glob("imp*.csv"):
            frame = list(csv.DictReader(io.StringIO(path.read_text())))
            for row in frame:
                row["Age"] = ages[row["Patient_ID"]]
            output = io.StringIO(newline="")
            writer = csv.DictWriter(output, fieldnames=list(frame[0]), lineterminator="\n")
            writer.writeheader()
            writer.writerows(frame)
            path.write_text(output.getvalue())
        return completed
    members = {"response.csv": response}
    with monkeypatch.context() as patch:
        patch.setattr("padml.f5.subprocess.run", fixture_mice)
        for task in compile_full_data_search_mice_tasks(plan):
            name = f"{task['split_id']}/{task['role'].lower()}.zip"
            target = tmp_path / name.replace("/", "-")
            execute_full_data_search_mice_view(
                plan, task, covariates,
                search_analysis_response(plan, task, response) if task["role"] == "ANALYSIS" else None,
                target,
            )
            members[name] = target
        full = tmp_path / "final-mice.zip"
        execute_final_full_data_mice_view(plan, compile_final_full_data_mice_task(plan),
                                         covariates, response, full)
    final_mice = materialize_final_full_data_mice(plan, full, response, tmp_path / "full-data")
    selectors = [selector_result_fixture(fold, set()) for fold in range(1, 7)]
    seta = compile_final_seta(selectors, sum(events))
    decision = final_refit_compilation_inputs("COX_PH")[2]
    handoff = f4_handoff_fixture(decision)
    recipe = compile_final_recipe(final_mice, seta, decision, handoff, tmp_path)
    lock = seal_final_parameter_lock(final_mice, seta, decision, handoff, None)
    refits = compile_final_refit_tasks(final_mice, seta, decision, lock, recipe, handoff, workers=24)
    lineage = {
        "kind": "PADML_F5_FINAL_AGGREGATE_INPUT_V2", "family_decision": decision,
        "final_refit_plan": refits, "centers": [str(center_map[patient]) for patient in plan["source_ids"]],
        "final_family": "COX_PH", "final_seta_selector_results": selectors,
        "final_seta": seta, "final_mice": final_mice, "final_parameter_lock": lock,
        "final_recipe": recipe, "parameter_source": None,
    }
    members["a19-input.json"] = canonical_json_bytes({
        "kind": "PADML_F5_A19_MODEL_INPUT_V1", "final_lineage": lineage, "mice_plan": plan,
    })
    source = tmp_path / "a19-native-input.zip"
    write_deterministic_zip(source, members)
    preparation = tmp_path / "prepare"
    preparation.mkdir()
    monkeypatch.setattr("padml.f5._execute_final_refit_engine",
                        lambda *args, **kwargs: pytest.fail("preparation must not fit"))
    context, jobs, evaluation_response = _prepare_a19_models(source, preparation)
    assert len(jobs) == len({job["name"] for job in jobs}) == 225
    assert context["lineage"] == lineage
    assert set(_response_rows(evaluation_response)[1]) == set(keys)
    for job in jobs:
        task = strict_json_bytes(job["entries"]["task.json"])
        fit = list(csv.DictReader(io.StringIO(job["entries"]["fit-covariates.csv"].decode())))
        application = list(csv.DictReader(io.StringIO(job["entries"]["prediction-covariates.csv"].decode())))
        assert set(row["Patient_ID"] for row in fit).isdisjoint(row["Patient_ID"] for row in application)
        assert "All_Cause_Death" not in application[0]
        assert task["model_seed"] is None
        assert task["parameters"] == {"family": "COX_PH", "ties": "breslow"}
        assert len(strict_json_bytes(job["entries"]["recipe.json"])["selected_parents"]) == 1


def test_a19_preserves_native_failure_location_in_its_input_directory(tmp_path, monkeypatch):
    from padml.f5_sensitivity import _execute_a19_component
    job = _a19_native_job(tmp_path, "COX_PH", "BASE")
    def fail(*args, **kwargs):
        error = ContractError("NATIVE_FIXTURE_FAILURE")
        error.add_note("F5_FINAL_REFIT_NATIVE_EVIDENCE_RETAINED:fixture-native-root")
        raise error
    monkeypatch.setattr("padml.f5._execute_final_refit_engine", fail)
    with pytest.raises(ContractError, match="NATIVE_FIXTURE_FAILURE"):
        _execute_a19_component(job)
    root = Path(job["root"])
    assert strict_json_bytes((root / "native-failure.json").read_bytes()) == {
        "error": "NATIVE_FIXTURE_FAILURE",
        "native_evidence": ["F5_FINAL_REFIT_NATIVE_EVIDENCE_RETAINED:fixture-native-root"],
    }
    assert (root / "task.json").read_bytes() == job["entries"]["task.json"]
    assert not root.with_suffix(".zip").exists()


def test_a19_rejects_invalid_component_curve_before_m5_averaging() -> None:
    rows, centers, response = a19_prediction_fixture()
    target = [
        row for row in rows
        if row["inner_repeat_id"] == 1
        and row["inner_fold_id"] == 1
        and row["seed_role"] == "BASE"
    ]
    for patient in target[0]["patients"]:
        patient["survival_probabilities"][10:12] = [0.8, 0.9]
    for patient in target[1]["patients"]:
        patient["survival_probabilities"][10:12] = [1.0, 0.9]
    for row in target[:2]:
        row["prediction_sha256"] = sha256_bytes(
            canonical_json_bytes(row["patients"])
        )
    with pytest.raises(ContractError, match="F2_PREDICTION_SEAL_INVALID"):
        compute_a19_multi_seed_stability(rows, centers, response)


def test_a19_rejects_center_outside_registered_domain() -> None:
    rows, centers, response = a19_prediction_fixture()
    centers[next(iter(centers))] = "999"
    with pytest.raises(ContractError, match="F5_A19_CENTER_MAP_INVALID"):
        compute_a19_multi_seed_stability(rows, centers, response)


def test_a19_rejects_six_center_ooc_population_as_full_development() -> None:
    rows, centers, response = a19_prediction_fixture()
    centers = {patient: "36" if center == "55" else center
               for patient, center in centers.items()}
    with pytest.raises(ContractError, match="F5_A19_CENTER_MAP_INVALID"):
        compute_a19_multi_seed_stability(rows, centers, response)


@pytest.mark.parametrize(
    "mutation",
    [
        "missing", "duplicate", "nonfinite", "patient_set", "model_seed",
        "prediction_hash", "parameter_lock",
    ],
)
def test_a19_missing_duplicate_and_numeric_errors_fail_hard(mutation: str) -> None:
    rows, centers, response = a19_prediction_fixture()
    if mutation == "missing":
        rows.pop()
    elif mutation == "duplicate":
        rows[-1] = copy.deepcopy(rows[0])
    elif mutation == "nonfinite":
        rows[0]["patients"][0]["survival_probabilities"][24] = math.nan
    elif mutation == "patient_set":
        rows[0]["patient_set_sha256"] = "f" * 64
    elif mutation == "model_seed":
        rows[0]["model_seed"] += 1
    elif mutation == "prediction_hash":
        rows[0]["prediction_sha256"] = "f" * 64
    else:
        rows[0]["final_parameter_lock_sha256"] = "f" * 64
    with pytest.raises(ContractError):
        compute_a19_multi_seed_stability(rows, centers, response)


def a04_rows(count: int = 100) -> tuple[list[dict], list[dict]]:
    batch = []
    single = []
    for index in range(count):
        patient = f"{index + 1:064x}"
        risk = 0.90 - index / 1000
        batch.append(
            {
                "patient_key_hash": patient,
                "center": "36",
                "risk_probability_24": risk,
            }
        )
        single.append(
            {
                "patient_key_hash": patient,
                "center": "36",
                "risk_probability_24": risk,
            }
        )
    return batch, single


def test_a04_uses_exact_k_hash_ties_and_micro_denominator() -> None:
    batch, single = a04_rows()
    single[9]["risk_probability_24"] = 0.889
    single[10]["risk_probability_24"] = 0.891
    result = evaluate_a04_batch_single(batch, single)
    assert result["status"] == "REDUCED_DECLARED_EVIDENCE"
    assert result["execution_evidence_status"] == (
        "NOT_VERIFIED_REFERENCES_ONLY"
    )
    assert result["blocking_for_production"] is True
    assert result["center_results"][0]["top_k_count"] == 10
    assert result["summary"]["intersection_count"] == 9
    assert result["summary"]["denominator_count"] == 10
    assert result["summary"]["top_risk_agreement"] == 0.90
    assert result["deployment_gate"]["top_risk_status"] == "PASS"
    assert result["deployment_gate"]["status"] == "PASS"
    assert result["outcome_read_count"] == result["model_fit_count"] == 0
    tied_batch, tied_single = a04_rows(10)
    for row in tied_batch + tied_single:
        row["risk_probability_24"] = 0.5
    tied = evaluate_a04_batch_single(tied_batch, tied_single)
    assert tied["center_results"][0]["top_risk_agreement"] == 1.0
    assert tied["center_results"][0]["spearman_rho"] is None
    mixed_batch, mixed_single = a04_rows(110)
    for index in range(10, 110):
        mixed_batch[index]["center"] = "38"
        mixed_single[index]["center"] = "38"
    mixed_single[0]["risk_probability_24"] = 0.0
    mixed = evaluate_a04_batch_single(mixed_batch, mixed_single)
    assert [row["top_k_count"] for row in mixed["center_results"]] == [1, 10]
    assert [row["intersection_count"] for row in mixed["center_results"]] == [0, 10]
    assert mixed["summary"]["top_risk_agreement"] == pytest.approx(10 / 11)


def test_a04_p95_equality_passes_and_outcome_or_alignment_errors_fail() -> None:
    batch, single = a04_rows(20)
    for left, right in zip(batch, single, strict=True):
        left["risk_probability_24"] = 0.50
        right["risk_probability_24"] = 0.48
    result = evaluate_a04_batch_single(batch, single)
    assert result["summary"]["p95_absolute_risk_difference"] == 0.02
    assert result["deployment_gate"]["p95_status"] == "PASS"
    exposed = copy.deepcopy(batch)
    exposed[0]["event"] = 1
    with pytest.raises(ContractError, match="F5_A04_OUTCOME_FREE_SCHEMA_INVALID"):
        evaluate_a04_batch_single(exposed, single)
    with pytest.raises(ContractError, match="F5_A04_PATIENT_SET_MISMATCH"):
        evaluate_a04_batch_single(batch[:-1], single)


def test_a04_pooled_pass_does_not_hide_small_center_deployment_failure() -> None:
    batch, single = a04_rows(260)
    centers = ["36", "38", "39", "48", "52", "54"]
    for index, (left, right) in enumerate(zip(batch, single, strict=True)):
        left["center"] = right["center"] = centers[min(index // 50, 5)]
        if index >= 250:
            right["risk_probability_24"] += 0.10
    result = evaluate_a04_batch_single(batch, single)
    assert result["summary"]["p95_absolute_risk_difference"] == 0
    assert result["summary"]["top_risk_agreement"] == 1
    assert result["deployment_gate"]["pooled_status"] == "PASS"
    assert result["deployment_gate"]["status"] == "FAIL"
    assert result["deployment_gate"]["failed_centers"] == ["54"]
    assert result["center_results"][-1]["p95_absolute_risk_difference"] == pytest.approx(.10)
    assert result["center_results"][-1]["deployment_status"] == "FAIL"
    subset = evaluate_a04_batch_single(batch[:250], single[:250])
    assert subset["deployment_gate"]["scope"] == "SUPPLIED_CENTERS_ONLY"
    assert "54" not in subset["deployment_gate"]["assessed_centers"]
    assert subset["stage_acceptance"] is False
    assert result["selection_effect"] == "NONE" and result["patient_drop_count"] == 0

    # A small center's top-risk failure must also survive micro averaging.
    for left, right in zip(batch, single, strict=True):
        right["risk_probability_24"] = left["risk_probability_24"]
    single[250]["risk_probability_24"], single[259]["risk_probability_24"] = (
        single[259]["risk_probability_24"], single[250]["risk_probability_24"]
    )
    top_risk = evaluate_a04_batch_single(batch, single)
    assert top_risk["deployment_gate"]["pooled_status"] == "PASS"
    assert top_risk["deployment_gate"]["p95_status"] == "PASS"
    assert top_risk["deployment_gate"]["top_risk_status"] == "FAIL"
    assert top_risk["deployment_gate"]["failed_centers"] == ["54"]


def c10_evidence_fixture() -> dict:
    selected = ["AST_ALT", "Creatinine", "Age"]
    parameter_lock = sha256_bytes(b"c10-parameter-lock")
    rows = []
    for branch_index, branch in enumerate(C10_BRANCHES):
        branch_parents = [
            "eGFR_calc" if parent == "Creatinine" else parent
            for parent in selected
        ] if branch == "eGFR_calc" else selected
        for fold, center in enumerate(
            ("36", "38", "39", "48", "52", "54"), start=1
        ):
            rows.append(
                {
                    "branch": branch,
                    "outer_fold_id": f"OUTER_{fold:02d}",
                    "center": center,
                    "family": "RSF",
                    "selected_parents": branch_parents,
                    "parameter_lock_sha256": parameter_lock,
                    "fit_receipts": [
                        {
                            "imputation": imputation,
                            "receipt_sha256": sha256_bytes(
                                f"c10-{branch}-{fold}-{imputation}".encode()
                            ),
                        }
                        for imputation in range(1, 21)
                    ],
                    "mi_prediction_sha256": sha256_bytes(
                        f"c10-mi-{branch}-{fold}".encode()
                    ),
                    "metrics": {
                        metric: 0.1 * branch_index
                        + 0.001 * fold
                        + 0.000001 * metric_index
                        for metric_index, metric in enumerate(
                            _A12_POINT_METRICS
                        )
                    },
                }
            )
    for row in rows:
        row["metric_support"] = {
            name: {"status": "ESTIMABLE", "value": value, "support": []}
            for name, value in row["metrics"].items()
        }
    return {
        "kind": "PADML_F5_C10_CENTER_METRICS_V1",
        "analysis_id": "CREATININE_EGFR_REPRESENTATION",
        "final_family": "RSF",
        "final_family_decision_sha256": sha256_bytes(
            b"c10-family-decision"
        ),
        "final_parameter_lock_sha256": parameter_lock,
        "selected_parents": selected,
        "branch_policy": {
            "trigger_parent": "Creatinine",
            "replacement_parent": "eGFR_calc",
            "other_parents_unchanged": True,
            "family_unchanged": True,
            "hyperparameters_unchanged": True,
            "selector_rerun": False,
            "simultaneous_representation": False,
            "egfr_derivation": (
                "PASSIVE_RECOMPUTATION_EXISTING_AUTHORITY_FORMULA"
            ),
            "independent_egfr_imputation": False,
            "formal_imputation_count": 20,
        },
        "branch_rows": rows,
    }


def test_c10_uses_exact_240_fit_coverage_and_equal_center_mean() -> None:
    evidence = c10_evidence_fixture()
    result = evaluate_c10_creatinine_egfr_swap(evidence)
    assert result["status"] == "REDUCED_DECLARED_EVIDENCE"
    assert result["execution_evidence_status"] == (
        "NOT_VERIFIED_REFERENCES_ONLY"
    )
    assert result["declared_fit_receipt_count"] == 240
    assert result["declared_mi_prediction_reference_count"] == 12
    assert result["fit_execution_count"] == 0
    assert result["prediction_execution_count"] == 0
    assert result["mi_aggregate_count"] == result["evaluation_count"] == 0
    assert len(result["center_level_results"]["Creatinine"]) == 6
    assert result["equal_center_macro_results"]["Creatinine"][
        "ibs_0_24"
    ] == pytest.approx(0.003518)
    assert result["paired_difference"]["ibs_0_24"] == pytest.approx(0.1)
    assert result["paired_difference_direction"] == "EGFR_MINUS_CREATININE"
    assert result["center_aggregation"] == (
        "UNWEIGHTED_ARITHMETIC_MEAN_EXACT_SIX"
    )
    assert result["selector_rerun_count"] == 0
    assert result["tuning_trial_count"] == 0
    assert result["family_reselection_count"] == 0
    assert result["selection_effect"] == "NONE"
    assert result["blocking_for_production"] is True
    assert result["stage_acceptance"] is False


def test_c10_not_applicable_and_invalid_evidence_fail_closed() -> None:
    evidence = c10_evidence_fixture()
    not_applicable = copy.deepcopy(evidence)
    not_applicable["selected_parents"] = ["AST_ALT", "Age"]
    not_applicable["branch_rows"] = []
    result = evaluate_c10_creatinine_egfr_swap(not_applicable)
    assert result["status"] == "DECLARED_NOT_APPLICABLE_UNVERIFIED"
    assert result["execution_evidence_status"] == (
        "NOT_VERIFIED_REFERENCES_ONLY"
    )
    assert result["blocking_for_production"] is True
    assert result["fit_execution_count"] == 0

    incomplete = copy.deepcopy(evidence)
    incomplete["branch_rows"].pop()
    with pytest.raises(ContractError, match="F5_C10_COVERAGE_INVALID"):
        evaluate_c10_creatinine_egfr_swap(incomplete)
    aliased = copy.deepcopy(evidence)
    aliased["branch_rows"][1]["fit_receipts"][0][
        "receipt_sha256"
    ] = aliased[
        "branch_rows"
    ][0]["fit_receipts"][0]["receipt_sha256"]
    # Numeric/reference equality alone is not native-object identity proof.
    assert evaluate_c10_creatinine_egfr_swap(aliased)["blocking_for_production"] is True
    drifted = copy.deepcopy(evidence)
    drifted["branch_rows"][6]["selected_parents"] = evidence[
        "selected_parents"
    ]
    with pytest.raises(ContractError, match="F5_C10_COORDINATE_INVALID"):
        evaluate_c10_creatinine_egfr_swap(drifted)
    impossible = copy.deepcopy(evidence)
    impossible["branch_rows"][0]["metrics"]["brier_24"] = float("nan")
    with pytest.raises(ContractError, match="F5_C10_NUMERICAL_ERROR"):
        evaluate_c10_creatinine_egfr_swap(impossible)


@pytest.mark.parametrize("workers", [24, 56, 120])
def test_direct_sensitivity_bundle_interfaces_are_one_input_one_result(
    tmp_path: Path, monkeypatch, workers,
) -> None:
    a12, response = a12_prediction_fixture()
    a12_source = (tmp_path / "a12-input.zip").resolve()
    a12_target = (tmp_path / "a12-result.zip").resolve()
    write_deterministic_zip(
        a12_source,
        {
            "predictions.json": canonical_json_bytes(a12),
            "response.csv": response,
        },
    )

    # Bare prediction declarations no longer form a formal A12 entry point.
    with pytest.raises(ContractError, match="F5_A12_SIX_NATIVE_OUTERS_REQUIRED"):
        execute_a12_bundle(a12_source, a12_target, sources=[], f2_run_root=tmp_path, workers=workers)
    assert not a12_target.exists()

    a19_rows, centers, a19_response = a19_prediction_fixture()
    a19_source = (tmp_path / "a19-input.zip").resolve()
    a19_target = (tmp_path / "a19-result.zip").resolve()
    write_deterministic_zip(
        a19_source,
        {
            "predictions.json": canonical_json_bytes(
                {
                    "kind": "PADML_F5_A19_INPUT_V1",
                    "prediction_rows": a19_rows,
                    "center_by_patient": centers,
                }
            ),
            "response.csv": a19_response,
        },
    )
    with pytest.raises(ContractError, match="F5_A19_NATIVE_MODEL_INPUT_REQUIRED"):
        execute_a19_bundle(a19_source, a19_target)
    assert not a19_target.exists()

    batch, single = a04_rows(20)
    a04_source = (tmp_path / "a04-input.zip").resolve()
    a04_target = (tmp_path / "a04-result.zip").resolve()
    write_deterministic_zip(
        a04_source,
        {
            "predictions.json": canonical_json_bytes(
                {
                    "kind": "PADML_F5_A04_BATCH_SINGLE_INPUT_V1",
                    "batch_rows": batch,
                    "single_rows": single,
                }
            )
        },
    )
    # An old risk-only ZIP is not a final-lineage/native-application input.
    with pytest.raises(ContractError):
        execute_a04_bundle(a04_source, a04_target, sources=[], f2_run_root=tmp_path,
                           input_root=tmp_path / "NO_REFIT_INPUTS", result_root=tmp_path / "NO_REFIT_RESULTS")
    assert not a04_target.exists()

    c10 = c10_evidence_fixture()
    c10_source = (tmp_path / "c10-input.zip").resolve()
    c10_target = (tmp_path / "c10-result.zip").resolve()
    write_deterministic_zip(
        c10_source,
        {"predictions.json": canonical_json_bytes(c10)},
    )
    # The execution entry now requires actual final lineage and original F2,
    # not the retired declared-metric bundle interface.
    with pytest.raises(ContractError):
        execute_c10_bundle(c10_source, c10_target, f2_run_root=tmp_path.resolve(),
                           outer_fold=1, workers=workers)
    assert not c10_target.exists()


def test_shap_checkpoint_science_qualification_precedes_repeated_numeric_scan(tmp_path, monkeypatch):
    from padml import f5
    records, receipts, _, decision, plan, centers = paired_predictions()
    pooled = pool_predictions(records, receipts, decision, plan, centers)
    component = final_shap_components(pooled, max_iter=2000)[0]
    component["schema_version"] = "2.0.0"
    component["kind"] = "PADML_F5_FINAL_SHAP_COMPONENT_V2"
    component["standard_errors"] = [[[0.0] for _ in range(4)] for _ in component["patient_ids"]]
    path = tmp_path / "M01.zip"
    f5._write_shap_checkpoint(path, {"fixture": "UNFITTED_NUMERICAL_CONSUMER"}, component)
    original = f5._validate_final_shap_component
    calls = []
    def validate(value, **kwargs):
        calls.append(1)
        return original(value, **kwargs)
    monkeypatch.setattr(f5, "_validate_final_shap_component", validate)
    def consume(prediction):
        _, value = f5._read_shap_checkpoint(path)
        return f5._qualified_final_shap_component(value, task={"family": component["family"],
            "imputation": 1, "selected_parents": ["AST_ALT"]}, prediction=prediction,
            model_sha256=component["model_sha256"])
    consume(records[0]); consume(records[0])
    assert calls == [1]
    changed = copy.deepcopy(records[0]); changed["survival"][0][6] -= .01
    with pytest.raises(ContractError, match="F5_SHAP_PREDICTION_BINDING_INVALID"):
        consume(changed)
    assert calls == [1, 1]
    consume(records[0])
    assert calls == [1, 1]
    component["risk_contributions"][0][0][0] += .01
    path.unlink(); f5._write_shap_checkpoint(path, {"fixture": "UNFITTED_NUMERICAL_CONSUMER"}, component)
    with pytest.raises(ContractError, match="F5_SHAP_LOCAL_ACCURACY_INVALID"):
        consume(records[0])
    assert calls == [1, 1, 1]


@pytest.mark.parametrize('family,geometry,sink', [
    ('COXTIME_SET_A', 'INVALID', None),
    ('COXTIME_SET_A', None, None),
    ('COXTIME_SET_A', [], None),
    ('XGBOOST_COX', 'NATIVE_BATCH', None),
    ('COXTIME_SET_A', 'NATIVE_BATCH', {}),
])
def test_retained_coxtime_prediction_geometry_rejects_wrong_scope(family, geometry, sink):
    from padml import f5
    from padml.bundle import ContractError
    with pytest.raises(ContractError, match='^F5_REPLAY_PREDICTION_GEOMETRY_INVALID$'):
        f5._predict_retained_python_arrays(family, {}, None, [], None, None, None,
            (b'', b''), lambda _: {}, [], None, None,
            coxtime_prediction_geometry=geometry, prepared_sink=sink)


def test_retained_coxtime_q_geometry_and_application_default_are_distinct(monkeypatch):
    from contextlib import nullcontext
    from types import SimpleNamespace
    import numpy as np
    import pandas as pd
    from padml import f5
    from padml.bundle import canonical_json_bytes
    train=np.arange(4, dtype=float).reshape(-1, 1)
    prediction=np.asarray([[.5], [2.5]])
    raw=train.astype('float32')
    mean=raw.mean(axis=0, dtype='float64').astype('float32')
    scale=raw.std(axis=0, dtype='float64').astype('float32')
    candidate={'fixed_candidate': True}
    baseline={'design_columns':['Age'], 'log_duration':False,
        'duration_mean':[0.0], 'duration_scale':[1.0],
        'input_mean':mean.tolist(), 'input_scale':scale.tolist(),
        'baseline_index':[1., 2.], 'baseline_hazards':[.1, .2]}
    native_baseline=pd.Series([.1, .2], index=[1., 2.])
    calls=[]
    class RetainedModel:
        net=SimpleNamespace(load_state_dict=lambda *args, **kwargs: None)
        def predict_surv_df(self, design, **kwargs):
            assert design.dtype==np.dtype('float32')
            assert kwargs['eval_'] is True and kwargs['num_workers']==0
            calls.append(design.copy())
            # Encode batch geometry so accidentally padding Q is observable.
            return pd.DataFrame(np.tile([[.99-len(design)*.01], [.89-len(design)*.01]],
                (1,len(design))), index=[1.,2.])
    torch=SimpleNamespace(load=lambda *args,**kwargs:{'candidate':candidate,
        'input_width':1,'state_dict':{},'training_binding':{}},
        set_num_threads=lambda _:None, device=lambda _:None,
        random=SimpleNamespace(fork_rng=lambda **kwargs:nullcontext()))
    labtrans=SimpleNamespace(log_duration=False,
        duration_scaler=SimpleNamespace(mean_=np.asarray([0.]),scale_=np.asarray([1.])),
        transform=lambda time,event:(time,event))
    monkeypatch.setattr(f5, '_coxtime_native', lambda:(None,torch,None))
    monkeypatch.setattr(f5, '_coxtime_labtrans', lambda *args:labtrans)
    monkeypatch.setattr(f5, '_coxtime_model', lambda *args:RetainedModel())
    monkeypatch.setattr(f5, '_validate_python_training_binding', lambda *args:None)
    monkeypatch.setattr(f5, '_coxtime_complete_baseline', lambda *args:(native_baseline,{}))
    args=('COXTIME_SET_A', {'family':'COXTIME_SET_A','parameters':candidate,'locked_epoch':30},
        train,['Age'],np.arange(1.,5.),np.asarray([1,0,1,0]),prediction,
        (b'retained',canonical_json_bytes(baseline)),lambda _: {},[1,2],np,pd)
    q=f5._predict_retained_python_arrays(*args,coxtime_prediction_geometry='NATIVE_BATCH')
    assert calls[-1].shape==(2,1)
    assert np.array_equal(np.asarray(q['survival']),np.tile([.97,.87],(2,1)))
    prepared={}
    application=f5._predict_retained_python_arrays(*args,prepared_sink=prepared)
    assert calls[-1].shape==(4,1) and np.array_equal(calls[-1][2:],np.zeros((2,1)))
    assert prepared['training_rows']==4
    assert np.array_equal(np.asarray(application['survival']),np.tile([.95,.85],(2,1)))


@pytest.mark.parametrize('missing_health',[False,True])
def test_q_retained_coxtime_calls_native_geometry_for_health_and_predictions(tmp_path, monkeypatch, missing_health):
    import sys
    from types import SimpleNamespace
    import numpy as np
    import pandas as pd
    from padml import f2_kernel as k,f4,f5
    from padml.bundle import canonical_json_bytes,sha256_bytes
    name='S1_T001_P01_M01_LOCKED_REFIT';native=tmp_path/'native'/name
    native.mkdir(parents=True)
    task={'task_id':name,'locked_epoch':30,'candidate':{'fixed':True},'spec':{
        'family':'COXTIME_SET_A','native_search_root':str(native.parent),
        'native_search_replay':True,'native_search_complete_missing_values':True,'horizons':[1,2]}}
    loaded={'fit_designs':[np.arange(4.).reshape(-1,1)],
        'evaluation_designs':[np.asarray([[.5],[2.5]])],'columns':['Age'],
        'evaluation_ids':['e1','e2'],'fit_time':np.arange(1.,5.),'fit_event':np.asarray([1,0,1,0])}
    binding={'fixed':'native-binding'}
    health={'training_epoch_count':30,'final_training_loss':.25,'model_state_sha256':'fixed-state'}
    survival=[[.8,.6],[.7,.5]]
    record={'task_id':name,'training_binding':binding,'horizons':[1,2],
        'prediction_input_sha256':sha256_bytes(canonical_json_bytes({
            'patient_ids':loaded['evaluation_ids'],'design_columns':['Age'],
            'design_dtype':'float64','design':loaded['evaluation_designs'][0].tolist()}))}
    for filename,value in [('input.json',record),('prediction.json',survival)]:
        (native/filename).write_bytes(canonical_json_bytes(value))
    for filename in ['model.bin','baseline.bin']:(native/filename).write_bytes(b'retained-original')
    if not missing_health:(native/'fit-health.json').write_bytes(canonical_json_bytes(health))
    with (native/'training-log.npz').open('wb') as stream:
        np.savez(stream,columns=np.asarray(['train_loss']),data=np.full((30,1),.25),index=np.arange(30))
    before={p:(p.read_bytes(),p.stat().st_ino,p.stat().st_mtime_ns,p.stat().st_ctime_ns)for p in native.iterdir()}
    monkeypatch.setattr(f4,'_full_pipeline_python_search_binding',lambda *args,**kwargs:binding)
    monkeypatch.setattr(k,'_validate_python_fit_health',lambda family,value,**kwargs:value)
    monkeypatch.setattr(k,'_coxtime_state_sha256',lambda *args:'fixed-state')
    monkeypatch.setitem(sys.modules,'torch',SimpleNamespace(load=lambda *args,**kwargs:{'state_dict':{}}))
    calls=[]
    def predict(*args,**kwargs):
        assert kwargs['coxtime_prediction_geometry']=='NATIVE_BATCH'
        assert kwargs.get('prepared_sink') is None
        calls.append(kwargs.get('health_sink') is not None)
        if kwargs.get('health_sink') is not None:kwargs['health_sink'].update(health)
        return {'survival':survival}
    monkeypatch.setattr(f5,'_predict_retained_python_arrays',predict)
    def forbidden(*args,**kwargs):pytest.fail('retained Q must not train')
    result=f4._full_pipeline_python_search_refit(task,loaded,forbidden,np,pd)
    assert calls==([True,False] if missing_health else [False])
    assert canonical_json_bytes(result['survival'].tolist())==(native/'prediction.json').read_bytes()
    assert (native/'fit-health.json').read_bytes()==canonical_json_bytes(health)
    assert before=={p:(p.read_bytes(),p.stat().st_ino,p.stat().st_mtime_ns,p.stat().st_ctime_ns)for p in before}


@pytest.mark.parametrize('row_count', [1, 31, 32, 67])
def test_coxtime_grid_preparation_matches_native_full_grid_without_training(row_count):
    import numpy as np
    import pandas as pd
    from padml import f2_kernel as kernel
    native = kernel._coxtime_native()
    models, torch, _ = native
    candidate = load_science_authority()['science']['f2_model_development']['coxtime']['candidates'][0]
    training_rows = 32
    durations = np.arange(1, training_rows + 1, dtype='float32')
    events = np.ones(training_rows, dtype='float32')
    labtrans = kernel._coxtime_labtrans(models, candidate, durations, events, np)
    index, _ = labtrans.transform(np.array([1, 3, 6, 9, 12, 18, 24, 32], dtype='float32'),
                                 np.ones(8, dtype='float32'))
    baseline = pd.Series([0, .005, .01, 0, .015, .01, .01, .005], index=index)
    design = np.random.default_rng(881).normal(0, .2, (row_count, 3)).astype('float32')
    horizons = list(range(37))
    caller_state = torch.random.get_rng_state().clone()
    with torch.random.fork_rng(devices=[]):
        torch.manual_seed(1881)
        model = kernel._coxtime_model(native, candidate, 3, labtrans, 300, torch.device('cpu'))
        original_index, original = f5_module._coxtime_final_survival(model, design, baseline,
                                                                  training_rows, np)
        actual_index, actual = f5_module._coxtime_final_survival(model, design, baseline,
                                                               training_rows, np, horizons=horizons)
        positions = np.searchsorted(original_index, horizons, side='right') - 1
        keep = sorted({0, *(int(i) for i in positions if i >= 0)})
        assert actual_index.tobytes() == original_index[keep].tobytes()
        assert actual.tobytes() == original[keep].tobytes()
    assert torch.equal(torch.random.get_rng_state(), caller_state)


# Focused streaming publication and direct-consumer boundary fixtures.
from padml import f5
from padml.carriers import open_carrier


def _stream_json(raw):
    data=io.BytesIO()
    with zipfile.ZipFile(data,'w') as archive:
        archive.writestr('final-aggregate.json',raw)
    data.seek(0)
    return data


@pytest.mark.parametrize('number',[1e-10,-1.5e+100,10,-0.0,123.25])
def test_aggregate_projection_number_token_crosses_64k(number):
    token=canonical_json_bytes(number)[:-1]
    prefix=b'{"a":"';middle=b'","number":'
    for split in range(1,len(token)):
        padding=b'x'*(65536-len(prefix)-len(middle)-split)
        raw=prefix+padding+middle+token+b',"z":[1,2,3]}\n'
        with open_carrier(_stream_json(raw)) as archive:
            assert f5._read_final_aggregate_fields(archive,{'number':None,'z':None})=={'number':number,'z':[1,2,3]}
        with open_carrier(_stream_json(raw)) as archive:
            assert f5._read_final_aggregate_fields(archive,{'z':None})=={'z':[1,2,3]}


@pytest.mark.parametrize('bad',[b'1e',b'1e+',b'1.',b'01',b'-01',b'Infinity',b'NaN',b'nullx',b'{}{}'])
def test_aggregate_projection_rejects_malformed_skipped_scalar(bad):
    raw=b'{"a":"'+b'x'*65521+b'","n":'+bad+b',"z":0}\n'
    with open_carrier(_stream_json(raw)) as archive:
        with pytest.raises(ContractError):
            f5._read_final_aggregate_fields(archive,{'z':None})


def test_actual_execute_paired_diagnostic_stream_reaches_original_member(tmp_path,monkeypatch):
    import test_f5 as original_fixtures
    records,receipts,_,decision,plan,centers=original_fixtures.paired_predictions()
    pooled=f5.pool_predictions(records,receipts,decision,plan,centers)
    components=original_fixtures.final_shap_components(pooled)
    # Only native diagnostics are substituted. The actual pool, SHAP validators,
    # aggregate, main publication function and both writer/reader are real.
    monkeypatch.setattr(f5,'diagnose_mi',lambda *a,**k:{'status':'ISOLATED_PACKAGING_FIXTURE'})
    source={'kind':'PADML_F5_PAIRED_M20_PREDICTIONS','predictions':records,
      'final_refit_receipts':receipts,'centers':centers,'final_family':pooled['family'],
      'family_decision':decision,'final_refit_plan':plan,'shap_components':components}
    target=tmp_path/'result.zip'
    calls=[]
    stream=f5._final_aggregate_json_chunks
    def watched(result):
        assert callable(result['shap']['patient_contributions'])
        calls.append(1)
        yield from stream(result)
    monkeypatch.setattr(f5,'_final_aggregate_json_chunks',watched)
    result=f5._execute_paired_diagnostic(source,b'UNFITTED_DIAGNOSTICS',target,
        source_sha256='a'*64,archive_records=None)
    assert result['status']=='ISOLATED_PACKAGING_FIXTURE' and calls==[1]
    with open_carrier(target) as archive:
        raw=archive.read('f5-mi.json')
        document=f5.strict_json_bytes(raw)
    assert canonical_json_bytes(document)==raw
    assert document['shap']==f5.aggregate_final_shap(components,pooled)


@pytest.mark.parametrize('mice_change',[None,'missing','changed_bytes'])
def test_actual_final_aggregate_packaging_with_legacy_fixture_seam(tmp_path,monkeypatch,mice_change):
    import test_f5 as original_fixtures
    # The preexisting fixture uses synthetic StableOne/Unused parents predating
    # the 44-parent contract. Do not weaken its production validator; substitute
    # only that unrelated compiler result at the packaging fixture seam.
    monkeypatch.setattr(original_fixtures,'compile_final_seta',lambda *a,**k:{
        'lock':{'selected_parents':['AST_ALT']},'lock_sha256':'a'*64})
    original_fixtures.test_final_aggregate_retains_lineage_shap_and_action_archives(
        tmp_path,monkeypatch,mice_change)


def test_actual_full0_optimism_projects_existing_member_before_bootstrap(tmp_path,monkeypatch):
    from padml import f4,runtime,worker,run,nested_loco as nested
    from padml.bundle import write_deterministic_zip,sha256_bytes,sha256_file
    class ReachedOriginalConsumer(Exception):pass
    ids=['engineered-1','engineered-2']
    survival=[[1.0]+[0.9]*36,[1.0]+[0.8]*36]
    context={'training_ids':ids,'centers_by_patient':dict.fromkeys(ids,'38'),
        'channel':'PRIMARY','outer_fold':0,'identity_sha256':'c'*64}
    decision={'identity_sha256':'d'*64}
    lock={'identity_sha256':'b'*64,'family_decision_sha256':'d'*64,'selection_horizon_months':24}
    lineage={'final_refit_plan':{'development_lock':lock}}
    aggregate={'final_lineage_sha256':sha256_bytes(canonical_json_bytes(lineage)),
      'pooled':{'pooled_apparent_prediction':{'development_lock_sha256':'b'*64,'patient_ids':ids,
        'component_count':20,'survival':survival}},
      'shap':{'patient_contributions':[{'large_skip':'x'*70000}]},'shap_component_archives':[]}
    root=tmp_path/'unit';root.mkdir()
    (root/'final-input/bound').mkdir(parents=True)
    write_deterministic_zip(root/'result.zip',{'final-aggregate.json':canonical_json_bytes(aggregate),
        'final-lineage.json':canonical_json_bytes(lineage)})
    request=b'{}\n';scores=b'{}\n'
    score_meta={'members':{name:{'sha256':sha256_bytes(raw),'size_bytes':len(raw)}
        for name,raw in [('request.json',request),('scores.json',scores)]}}
    write_deterministic_zip(root/'score.zip',{'score-archive.json':canonical_json_bytes(score_meta),
        'request.json':request,'scores.json':scores})
    response=b'Patient_ID,All_Cause_Death,Death_Followup_months\nengineered-1,1,50\nengineered-2,0,50\n'
    write_deterministic_zip(root/'final-input/bound/M01.zip',{'fit-response.csv':response})
    names=['score.zip','result.zip','final-input/bound/M01.zip']
    pins={name:{'sha256':sha256_file(root/name),'size_bytes':(root/name).stat().st_size} for name in names}
    receipt={'unit_id':'engineered-full0','status':'COMPLETED','direct_consumer_completed':True,
        'run_identity':'e'*64,'artifacts':pins}
    (root/'unit.json').write_bytes(canonical_json_bytes(receipt))
    manifest={'identity':'e'*64,'resource_policy':{}}
    unit={'kind':'FULL0','unit_id':'engineered-full0','horizon':24,'context':'engineered'}
    monkeypatch.setattr(run,'f45_unit_predecessors',lambda value:[])
    def actual_pins(paths,expected,**kw):
        assert {name:{'sha256':sha256_file(path),'size_bytes':path.stat().st_size}
            for name,path in paths.items()}==expected
    monkeypatch.setattr(worker,'_f45_file_pins',actual_pins)
    monkeypatch.setattr(runtime,'observe_execution_resources',lambda *a:{})
    monkeypatch.setattr(runtime,'resource_admission',lambda *a,**k:None)
    monkeypatch.setattr(f4,'_f45_optimism_oof',lambda *a:(context,decision,{}))
    monkeypatch.setattr(nested,'validate_development_lock',lambda value,**k:value)
    monkeypatch.setattr(nested,'validate_training_context',lambda *a,**k:context)
    original_seal=f4._seal_prediction_matrix
    def consumed(actual_ids,actual_values,horizons):
        assert actual_ids==ids and actual_values==survival and horizons==f4.HORIZONS
        original_seal(actual_ids,actual_values,horizons)
        raise ReachedOriginalConsumer
    monkeypatch.setattr(f4,'_seal_prediction_matrix',consumed)
    with pytest.raises(ReachedOriginalConsumer):
        f4.prepare_f45_optimism_inputs(manifest,unit,root)


@pytest.fixture(params=[False,True],ids=["internal-plan","external-plan"])
def full0_unpublished_aggregate_entry(tmp_path,monkeypatch,request):
    from contextlib import nullcontext
    from padml import runtime
    root=tmp_path.resolve();inputs=root/'input';outputs=root/'output';inputs.mkdir();outputs.mkdir()
    response=root/'response.csv';response.write_bytes(b'Patient_ID,All_Cause_Death,Death_Followup_months\na,1,50\nb,0,50\n')
    nonph=root/'non-ph.zip';nonph.write_bytes(b'UNFITTED_NONPH_SEAM')
    context={'training_ids':['a','b'],'centers_by_patient':{'a':'36','b':'38'},'scope':'FULL_DATA','channel':'PRIMARY'}
    plan={'kind':'PADML_NESTED_FULL_FINAL_INPUT_V1','training_context':context,'identity_sha256':'c'*64}
    sources={'science_decision':f5_module._nested_science.science_decision_template(24),'plan':{'scope':'UNFITTED'}}
    index={'selection_horizon_months':24,'final_refit_plan':plan,'centers':['36','38'],
           'development_sources':sources,'family_decision':{},'final_family':'COX_PH'}
    raw=canonical_json_bytes(index);lineage=inputs/'lineage.json';lineage.write_bytes(raw)
    compiled={'lineage_sha256':sha256_bytes(raw),'final_mice_artifacts':[]}
    explicit_plan=None
    if request.param:
        explicit_plan=root/'explicit-plan.json';explicit_plan.write_bytes(canonical_json_bytes(sources['plan']))
    policy=dict(configured_worker_ceiling=runtime.CPU_MINUS_8,memory_bytes_per_worker=1024**3,
        memory_reserve_bytes=1024**3,scratch_bytes_per_worker=1024**3,scratch_reserve_bytes=0,
        transfer_archive_worker_ceiling=1000)
    monkeypatch.setattr(runtime,'observe_execution_resources',lambda *a:{})
    monkeypatch.setattr(runtime,'resource_admission',lambda *a,**k:None)
    monkeypatch.setattr(f5,'_read_final_lineage',lambda *a,**k:index)
    monkeypatch.setattr(f5_module._nested_science,'validate_training_context',lambda *a,**k:context)
    calls=[]
    def collect(*args,**kwargs):
        assert kwargs['replay_evidence'] is None
        calls.append('existing-objects-collector-seam')
        return dict(configured_worker_ceiling=24,admitted_worker_ceiling=len(calls),pool_execution_reports=[],
            predictions=[],receipts=[],coefficient_evidence=None,non_ph_contrast_evidence=None,
            shap_components=[],pooled={},archives=[],shap_component_paths={},shap_component_archives=[],final_component_numbers=[])
    monkeypatch.setattr(f5,'collect_final_refit_results',collect)
    monkeypatch.setattr(f5,'_reuse_full_final_pool',lambda *a:{})
    monkeypatch.setattr(f5,'_load_non_ph_action',lambda *a:{})
    monkeypatch.setattr(f5,'_final_action_archive_record',lambda *a:{'member':'non-ph.zip','action':'NON_PH','archive_sha256':'d'*64})
    monkeypatch.setattr(f5,'_full_score_scratch',lambda *a:nullcontext())
    def publication(data,response,target,**kwargs):
        calls.append('atomic-stream-publisher')
        def stream():
            yield b'{"done":'
            if calls.count('atomic-stream-publisher')==1:raise RuntimeError('INJECTED_STREAM_INTERRUPTION')
            yield b'true}\n'
        write_deterministic_zip(target,{'final-aggregate.json':stream})
        return {'status':'UNFITTED_PUBLICATION_SEAM'}
    monkeypatch.setattr(f5,'_execute_paired_diagnostic',publication)
    target=root/'result.zip';private=target.with_name(target.name+'.native-replay')
    def execute():
        return f5_module.execute_final_aggregate(lineage,response,outputs,nonph,target,input_root=inputs,
            resource_policy=policy,compiled_input_record=compiled,mice_plan_path=explicit_plan,replay=target.is_file())
    with pytest.raises(RuntimeError,match='INJECTED_STREAM_INTERRUPTION'):execute()
    assert not target.exists() and private.is_dir() and not list(root.glob('.result.zip.tmp-*'))
    assert (private/'mice-plan.json').exists() is (not request.param)
    return execute,root,private,target,calls


def test_full0_resumes_unpublished_result_and_preserves_original_sources(full0_unpublished_aggregate_entry):
    execute,root,private,target,calls=full0_unpublished_aggregate_entry
    before={p.name:(p.read_bytes(),p.stat().st_ino,p.stat().st_mtime_ns) for p in private.iterdir()}
    report=execute()
    assert report['status']=='UNFITTED_PUBLICATION_SEAM' and report['admitted_worker_ceiling']==3
    assert target.is_file() and not (private/'final-models').exists()
    assert before=={p.name:(p.read_bytes(),p.stat().st_ino,p.stat().st_mtime_ns) for p in private.iterdir()}
    assert calls==['existing-objects-collector-seam','atomic-stream-publisher']*2


@pytest.mark.parametrize('damage',['source','unknown_symlink'])
def test_full0_rejects_unqualified_private_resume_before_consumption(full0_unpublished_aggregate_entry,damage):
    execute,root,private,target,calls=full0_unpublished_aggregate_entry
    if damage=='source':
        path=private/'development-sources.json';path.write_bytes(canonical_json_bytes({'foreign':True}))
    else:
        (private/'foreign-link').symlink_to(root/'response.csv')
    with pytest.raises(ContractError,match='F5_FULL_FINAL_AGGREGATE_RESUME_DRIFT'):execute()
    assert not target.exists() and calls==['existing-objects-collector-seam','atomic-stream-publisher']


@pytest.mark.parametrize('damage',[None,'input'])
def test_full0_existing_metrics_use_original_exact_input_reader_without_native(tmp_path,monkeypatch,damage):
    records,receipts,response,decision,plan,centers=paired_predictions('RSF')
    pooled=f5_module.pool_predictions(records,receipts,decision,plan,centers)
    captured=[]
    class Captured(Exception):pass
    class Consumed(Exception):pass
    def capture(jobs,**kwargs):captured.extend(copy.deepcopy(jobs));raise Captured
    monkeypatch.setattr(f5_module,'native_metrics',capture)
    with pytest.raises(Captured):f5_module.diagnose_mi(pooled,centers,response,final_family='RSF')
    assert len(captured)==2
    values=[{'label':j['label'],'horizons':{str(h):dict(slope=1.,citl=0.,oe=1.,ici=.01,e50=.01,e90=.02,status="ESTIMABLE",reasons=[])
        for h in f5_module.REPORT_HORIZONS},'discrimination':{'uno_c_24':{'value':.7},
        'auc':{str(h):{'value':.7} for h in f5_module.REPORT_HORIZONS}}} for j in captured]
    if damage:captured[0]['patient_ids'][0]='FOREIGN_INPUT'
    kernel=(Path(f5_module.__file__).parent/'kernels/f4_metrics.R').read_bytes()
    archive=tmp_path.resolve()/'mi-native-metrics.zip'
    write_deterministic_zip(archive,{'input.json':canonical_json_bytes({'jobs':captured}),
        'stdout.txt':canonical_json_bytes({'results':values}),'stderr.txt':b'','f4_metrics.R':kernel,
        'execution.json':canonical_json_bytes({'exit_code':0,'engine_threads':f5_module.THREAD_ENV,
            'kernel_sha256':sha256_bytes(kernel)})})
    before=archive.read_bytes()
    plan={**plan,'kind':'PADML_NESTED_FULL_FINAL_INPUT_V1'}
    health={};audit={}
    receipts=[{**row,'fit_health_sha256':sha256_bytes(canonical_json_bytes(health))} for row in receipts]
    numbers=[dict(imputation=i,prediction=p,receipt=r,fit_health=health,retained_audit=audit,
        archive={'retained_object_audit_sha256':sha256_bytes(canonical_json_bytes(audit))})
        for i,(p,r) in enumerate(zip(records,receipts,strict=True),1)]
    data=dict(kind='PADML_F5_PAIRED_M20_PREDICTIONS',predictions=records,final_refit_receipts=receipts,
        centers=centers,final_family='RSF',family_decision=decision,final_refit_plan=plan)
    monkeypatch.setattr(f5,'_reuse_full_final_pool',lambda *a:pooled)
    original=f5_module.diagnose_mi;seen=[]
    def read(*args,**kwargs):
        assert kwargs['native_archive'] is None and kwargs['replay_native_archive']==archive
        seen.append('original-reader');original(*args,**kwargs);raise Consumed
    monkeypatch.setattr(f5,'diagnose_mi',read)
    with pytest.raises(ContractError if damage else Consumed,
            match='F5_MI_NATIVE_METRICS_REPLAY_MISMATCH' if damage else None):
        f5_module._execute_paired_diagnostic(data,response,tmp_path.resolve()/'result.zip',source_sha256='a'*64,
            archive_records=None,native_archive=archive,final_component_numbers=numbers,collected_pool=pooled)
    assert len(captured)==2 and seen==['original-reader'] and archive.read_bytes()==before
