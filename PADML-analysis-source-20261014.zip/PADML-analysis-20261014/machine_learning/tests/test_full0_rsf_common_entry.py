"""Bounded RSF entry and native transport checks; no scientific fitting."""
import json
from pathlib import Path
from types import SimpleNamespace

import pytest

from padml import f2_kernel, f4, f5
from padml.bundle import ContractError, canonical_json_bytes


def options(root):
    return dict(family="RSF", selection_horizon_months=12, resume=True,
        retained_full0_source_bundle=root / "primary.zip", retained_q_archive=root / "q.zip",
        retained_q_producer_source_bundle=root / "q-source.zip",
        prepared_score_root=root / "score.all", prepared_score_source_bundle=root / "current.zip")


def test_common_rsf_uses_original_numeric_consumer_before_materialization(tmp_path, monkeypatch):
    calls = []
    def consume(source, **kwargs):
        calls.append((source, kwargs))
        return {"UNFITTED_ENTRY_ONLY": True}
    monkeypatch.setattr(f5, "_full0_rsf_q_scores_from_prepared", consume)
    monkeypatch.setattr(f5, "_materialized_full_data_development_sources",
        lambda *a, **k: pytest.fail("unexpected preparation"))
    supplied = options(tmp_path)
    result = f5.execute_full_data_locked_scores(tmp_path / "lineage.json", **supplied)
    assert result == {"UNFITTED_ENTRY_ONLY": True}
    assert calls == [(tmp_path / "lineage.json", {key: value for key, value in supplied.items()
        if key not in {"family", "selection_horizon_months", "resume"}})]


@pytest.mark.parametrize("change", [{"resume": False}, {"replay": True}, {"prepare_only": True},
    {"prepared_score_source_bundle": None}, {"retained_q_archive": None},
    {"retained_q_producer_source_bundle": None}, {"retained_full0_source_bundle": None},
    {"score_batches": []}, {"retained_score_root": "COX_MIX"}, {"selection_horizon_months": 24}])
def test_common_rsf_rejects_mixed_or_missing_authority_before_io(tmp_path, monkeypatch, change):
    monkeypatch.setattr(f5, "_full0_rsf_q_scores_from_prepared", lambda *a, **k: pytest.fail("unexpected consumer"))
    with pytest.raises(ContractError):
        f5.execute_full_data_locked_scores(tmp_path / "lineage.json", **{**options(tmp_path), **change})


def test_common_rsf_checks_real_preparation_source_before_reading_inputs(tmp_path, monkeypatch):
    source = tmp_path / "current.zip"
    f4.compile_f45_source_bundle(source)
    root = tmp_path / "score.all"
    root.mkdir()
    current = f4._f45_source_member_sha256()
    monkeypatch.setattr(f4, "_f45_source_member_sha256", lambda: {**current, "padml/f5.py": "0" * 64})
    monkeypatch.setattr(f5, "_read_final_lineage", lambda *a, **k: dict(score_root=str(tmp_path / "score"),
        resource_policy={}, retained_bytes_per_component=1, expanded_bytes_per_component=1, shared_storage_bytes=1))
    monkeypatch.setattr(f5, "_full_score_resource_admission", lambda *a, **k: pytest.fail("stale source admitted"))
    with pytest.raises(ContractError, match="PREPARED_DRIFT"):
        f5._full0_rsf_q_scores_from_prepared(tmp_path / "lineage.json",
            **{key: value for key, value in options(tmp_path).items()
               if key not in {"family", "selection_horizon_months", "resume"}})


@pytest.mark.parametrize("scope", ["current", "historical-denied", "historical-tail"])
def test_full0_rsf_current_leaf_keeps_original_native_audit(tmp_path, monkeypatch, scope):
    native = tmp_path / "native"
    native.mkdir()
    tail = scope == "historical-tail"
    task = {"task_id": "S3B1_T002_P01_M01" if tail else "S3A_T003_P01_M01",
        "family": "RSF", "imputation": 1, "partition_id": "F5_R01_K01" if tail else "F5_R03_K01",
        "seed": 340101 if tail else 330101, "parameters": {"UNFITTED": True}}
    source = {"family": "RSF", "virtual_outer": 0, "selection_horizon_months": 12,
        "task_sha256": "a" * 64}
    if scope != "current":
        source["producer_execution"] = {"execution_mode": "PROCESS_POOL", "threads": 56,
            "pool_workers": 56, "engine_threads": 1}
    scoring = dict(f2_kernel.load_science_authority()["science"]["f2_model_development"]["trial_scoring"])
    scoring.update(ibs_grid_months=list(range(13)), ibs_integration="TRAPEZOID_DIVIDE_BY_12")
    spec = {"execution_scope": "F5_FULL_DEVELOPMENT_SEARCH", "action": "MODEL_PREDICTION_BATCH",
        "family": "RSF", "fold": 0, "seed": 300000, "selection_horizon_months": 12,
        "trial_scoring": scoring,
        "native_search_root": str(native), "final_search_source": source, "producer_tasks": [task],
        "registered_partitions": {"partitions": [{"covariates": {
            "input_dir": "/UNFITTED/original", "data_identity": "b" * 64},
            "fit_response": {"path": "/UNFITTED/response", "sha256": "c" * 64}}]}}
    calls = []
    def unfitted_native(command, **kwargs):
        actual = json.loads(Path(command[-1]).read_bytes())
        assert actual["producer_tasks"] == [task] and actual["final_search_source"] == source
        calls.append(actual["native_search_replay"])
        Path(actual["output_path"]).write_bytes(canonical_json_bytes({"UNFITTED_TRANSPORT": True}))
        return SimpleNamespace(returncode=0)
    monkeypatch.setattr(f4.subprocess, "run", unfitted_native)
    original = None
    for replay in (False, True):
        work = tmp_path / ("audit" if replay else "produce")
        work.mkdir()
        actual = {**spec, "native_search_replay": replay, "output_path": str(work / "output.json")}
        path = work / "spec.json"
        path.write_bytes(canonical_json_bytes(actual))
        if scope == "historical-denied":
            with pytest.raises(ContractError, match="F5_FULL0_RSF_S3B1_FRESH_SCOPE_INVALID"):
                f4._run_full_pipeline_r_search_batch(path, work / "output.json", tmp_path, {})
            assert not calls
            return
        assert f4._run_full_pipeline_r_search_batch(path, work / "output.json", tmp_path, {}) == {
            "UNFITTED_TRANSPORT": True}
        batch, = native.glob("batch-*")
        retained = {p.name: p.read_bytes() for p in batch.iterdir()}
        if original is None:
            original = retained
        assert retained == original
    assert calls == [False, True]
    actual["registered_partitions"]["partitions"][0]["covariates"]["data_identity"] = "d" * 64
    path.write_bytes(canonical_json_bytes(actual))
    with pytest.raises(ContractError, match="F4_FULL_PIPELINE_Q_R_SPEC_MISMATCH"):
        f4._run_full_pipeline_r_search_batch(path, work / "output.json", tmp_path, {})
    assert calls == [False, True]
