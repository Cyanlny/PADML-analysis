"""No-fit AAR configuration binding; synthetic source and no candidate RNG."""
from copy import deepcopy

import pytest

from padml import f2_kernel, f5, f5_sensitivity as sensitivity, nested_loco as nested
from padml.bundle import ContractError
from test_nested_loco import _context, _lock, _scores
from test_twelve_month_development_lock import _science


@pytest.mark.parametrize("horizon", [12, 24])
@pytest.mark.parametrize("family", ["RSF", "GBM_COX", "XGBOOST_COX", "COXTIME_SET_A"])
def test_a12_configuration_consumes_own_primary_horizon(monkeypatch, horizon, family):
    context = _context()
    lock, _ = _lock(context, _scores(context, {f: .1 if f == family else .2 for f in nested._families()}))
    science = _science()
    if horizon == 12:
        lock = nested._sealed({**{k: v for k, v in lock.items() if k != "identity_sha256"},
            "selection_horizon_months": 12, "science_decision_binding": {
                "selection_horizon_months": 12, "science_decision_sha256": science["identity_sha256"],
                "development_incremental_budget": science["twelve_month_development"]["development_incremental_budget"]}})
    else:
        lock = nested._sealed({**{k: v for k, v in lock.items() if k != "identity_sha256"},
                              "science_decision_binding": nested._outer_science_decision_binding(science)})
    branch = nested.A12_DIRECT_AAR
    source = {"source": {"kind": "PADML_F5_A12_PROJECTED_OUTER_INPUTS_V1", "primary_source": {
        "science_decision": science, "primary_development_lock": lock, "primary_training_context": context}}}
    parts = [{"kind": kind, "repeat": r, "inner_fold": k}
             for kind in (["INNER"] if family == "RSF" else ["INNER", "STOP"])
             for r in range(1, 4) for k in range(1, 6)] + [{"kind": "OUTER"}]
    prepared = {"source": source["source"], "family": family, "outer_fold": 1,
        "branch_development": {}, "selected_parents": ["Age"], "common_set_design_df": 1,
        "outer_training_event_count": 30, "heldout_center": 36,
        "branches": {branch: {"kind": "PADML_F5_A12_REGISTERED_INPUTS", "branch": branch,
            "fold": 1, "outer_count": 1, "inner_count": 15, "stop_count": 0 if family == "RSF" else 15,
            "diagnostic_count": 0, "partitions": parts, "identity": "a" * 64}}}
    monkeypatch.setattr(sensitivity, "_a12_branch_search_inputs", lambda value, _: value)
    monkeypatch.setattr(sensitivity, "_a12_search_source", lambda *a: source)
    monkeypatch.setattr(sensitivity, "resolve_pool_workers", lambda _: 2)
    monkeypatch.setattr(f5, "_final_complex_candidate_trials", lambda _: {"S1": [], "S2": []})
    spec = sensitivity._a12_complex_configuration(prepared, branch)["spec"]
    assert f2_kernel._selection_horizon_from_spec(spec) == horizon
    assert spec["seed"] == 301000 and spec["monthly_fit_horizons"] == list(range(1, 37))
    assert spec["trial_scoring"]["ibs_grid_months"] == list(range(horizon + 1))
    assert ("selection_horizon_months" in spec) == (horizon == 12)
    broken = deepcopy(source)
    broken["source"]["primary_source"]["primary_development_lock"]["selected_family"] = "FOREIGN"
    monkeypatch.setattr(sensitivity, "_a12_search_source", lambda *a: broken)
    with pytest.raises(ContractError):
        sensitivity._a12_complex_configuration(prepared, branch)
