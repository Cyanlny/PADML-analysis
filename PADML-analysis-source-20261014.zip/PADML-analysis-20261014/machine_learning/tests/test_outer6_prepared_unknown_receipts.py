"""Only the sealed two-receipt compatibility; synthetic, with no native calls."""
import copy
from pathlib import Path

import pytest

from padml import f5_sensitivity as sensitivity, runtime
from padml.bundle import ContractError, canonical_json_bytes, sha256_bytes
from test_a12_q_input_release import q_call


@pytest.mark.parametrize("damage", [None, "unsealed", "different-report", "wrong-error", "third-owner", "missing-file", "outside-owner", "wrong-source", "compact-unknown"])
def test_exact_two_unknown_receipts_leave_other_original_checks(q_call, monkeypatch, damage):
    case = q_call
    # This test owns only fake filesystem inputs. Do not use a real /proc race
    # to manufacture an old receipt or repeat a production reclamation.
    monkeypatch.setattr(runtime, "_visible_open_file_keys", lambda keys: (set(), 1))
    case["state"]["empty_q_program"] = True
    value = sensitivity.execute_a12_outer_bundle(case["source"], case["target"], **case["arguments"])
    case["consume"](value)
    candidate = copy.deepcopy(value)
    report = candidate["execution_report"]
    report["source_identity"] = "cb0f1fff3adf46cb2187c5006dd727c8994e3cc7acabd26f20976b8944c4317b"
    original_consumer = sensitivity._validate_a12_q_input_execution
    retained = Path(__file__).resolve().parents[1] / "retained_cb0.zip"
    if damage == "wrong-source": retained = Path(sensitivity.__file__).resolve().parents[2] / "source.zip"
    def consume_retained(candidate, **kwargs):
        kwargs.update(executor_source_identity=report["source_identity"],
            retained_executor_source_bundle=retained, retained_primary_source_bundle=None)
        return original_consumer(candidate, **kwargs)
    monkeypatch.setattr(sensitivity, "_validate_a12_q_input_execution", consume_retained)
    for name in ("selector_inputs", "selector_program"):
        release = report["input_lifecycle"][name]["resource_release"]
        release["reader_scan_status"] = "UNKNOWN"
        for member in release["files"]:
            member.update(status="UNKNOWN", error=
                "RESOURCE_READER_SCAN_FAILED:PermissionError:[Errno 13] Permission denied: '/proc/5305/fd/0'\n"
                "RESOURCE_READER_SCAN_PROCESS:/proc/5305;completed_processes:16")
    sealed = canonical_json_bytes(report)
    if damage == "different-report": report["pid"] += 1
    elif damage == "wrong-error": report["input_lifecycle"]["selector_inputs"]["resource_release"]["files"][0]["error"] = "OTHER_CAUSE"
    elif damage == "third-owner":
        release = report["input_lifecycle"]["materialized_inputs"]["resource_release"]
        release["reader_scan_status"] = "UNKNOWN"
        for member in release["files"]: member.update(status="UNKNOWN", error="OTHER_CAUSE")
    elif damage == "missing-file": report["input_lifecycle"]["selector_inputs"]["resource_release"]["files"].pop()
    elif damage == "outside-owner": report["input_lifecycle"]["selector_inputs"]["resource_release"]["files"][0]["path"] = "/OUTSIDE/imp01.csv"
    elif damage == "compact-unknown": report["input_lifecycle"]["selector_inputs"]["resource_release"] = {
        "status": "UNKNOWN", "owner": "UNRELATED_SHORT_REPORT", "pid": report["pid"], "reason": "NO_FILE_TABLE"}
    # Synthetic preimage stand-in only. Real report bytes are not sent to H9;
    # H7 must independently satisfy the literal production SHA at recovery.
    if damage not in ("unsealed", "different-report"):
        sealed = canonical_json_bytes(report)
    if damage != "unsealed":
        monkeypatch.setattr(sensitivity, "sha256_bytes", lambda raw:
            "4218a603c608cec9501d939578fdb4a7958dce419d4dcf340a454d776e72b70d"
            if raw == sealed else sha256_bytes(raw))
    if damage is None:
        case["consume"](candidate)
        assert candidate["execution_report"] == report
    else:
        with pytest.raises(ContractError): case["consume"](candidate)
    assert case["state"]["native_calls"] == 0
