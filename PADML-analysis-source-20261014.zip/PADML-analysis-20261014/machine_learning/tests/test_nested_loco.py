from __future__ import annotations

import csv
import io
from copy import deepcopy
from pathlib import Path

import pytest

from padml.bundle import ContractError, canonical_json_bytes, sha256_bytes
from padml.nested_loco import (
    A12_DIRECT_AAR,
    A12_TOTAL_AAR,
    AAR_ESTIMANDS,
    FRESH_SCORE_FAMILIES,
    HORIZONS,
    M,
    OUTER_CENTERS,
    REUSED_SCORE_FAMILIES,
    WITHIN_FAMILY_NO_AAR_LABEL,
    WITHIN_FAMILY_NO_AAR_REDEVELOPMENT,
    _families,
    _covariate_ids,
    _score_fresh_family,
    _score_component_evidence,
    _sealed,
    aar_estimand_contract,
    assemble_selected_ooc,
    bind_post_lock_task,
    compile_training_context,
    exact_fit_budget_contract,
    paired_aar_contrast,
    project_accepted_training_score,
    science_decision_template,
    seal_development_lock,
    seal_fresh_training_score,
    seal_selected_prediction,
    select_training_family,
    validate_science_decision,
    validate_fresh_score_execution,
    validate_training_context,
)


def _response(ids: list[str]) -> bytes:
    stream = io.StringIO(newline="")
    writer = csv.DictWriter(
        stream,
        fieldnames=["Patient_ID", "All_Cause_Death", "Death_Followup_months"],
        lineterminator="\n",
    )
    writer.writeheader()
    for index, patient in enumerate(ids):
        writer.writerow({
            "Patient_ID": patient,
            "All_Cause_Death": 1,
            "Death_Followup_months": 10 + index,
        })
    return stream.getvalue().encode()


def _context() -> dict:
    training = [f"t{index:02d}" for index in range(1, 30)] + ["t55"]
    heldout = ["v1", "v2"]
    centers = {
        patient: str((38, 39, 48, 52, 54)[index % 5])
        for index, patient in enumerate(training[:-1])
    }
    centers.update({"t55": "55", "v1": "36", "v2": "36"})
    return compile_training_context(
        scope="OUTER",
        outer_fold=1,
        heldout_center=36,
        training_ids=training,
        heldout_ids=heldout,
        centers_by_patient=centers,
        training_response_csv=_response(training),
        mice_member_set_sha256="a" * 64,
        preprocessing_program_sha256="b" * 64,
        modeling_program_sha256="c" * 64,
        seed_program_sha256="d" * 64,
    )


def _summary(mean: float, maximum: float | None = None) -> dict:
    values = [mean - 0.0001, mean, mean + 0.0001]
    if maximum is not None:
        values = [mean - 0.0001, mean - 0.0001, maximum]
        mean = sum(values) / 3
    return {
        "ranking_metric_values": values,
        "fold_metric_values": [mean] * 15,
        "metric_values": [mean] * 300,
        "ranking_metric_qc": [{"status": "PASS"} for _ in range(3)],
        "ranking_evaluation_count": 3,
        "evaluation_units": 300,
        "mean_ibs": sum(values) / 3,
        "maximum_ibs": max(values),
    }


def _accepted_model(family: str, mean: float, *, outer_fold: int = 1) -> dict:
    summary = _summary(mean)
    trace = {"FORMAL_CONFIRMATION" if family == "COX_PH" else "S3B2": [summary]}
    spec = {"family": family, "parameters": {"fixed": family}}
    return {
        "status": "PASS",
        "fold": outer_fold,
        "heldout_center": OUTER_CENTERS[outer_fold - 1],
        "family": family,
        "selected_spec": spec,
        "selected_spec_sha256": sha256_bytes(canonical_json_bytes(spec)),
        "selector_evidence_sha256": "e" * 64,
        "search_trace": trace,
        # These fields model the forbidden source material.  Projection must
        # neither copy nor consult them.
        "outer_metric": {"ibs_0_24": -999},
        "monthly_oof": {"predictions": ["heldout"]},
    }


def _scores(context: dict, means: dict[str, float] | None = None) -> list[dict]:
    means = means or {family: 0.10 + index / 100 for index, family in enumerate(_families())}
    scores = []
    outer_fold = context["outer_fold"]
    for family in REUSED_SCORE_FAMILIES:
        scores.append(project_accepted_training_score(
            _accepted_model(family, means[family], outer_fold=outer_fold),
            source_result_sha256=(str(_families().index(family) + 1) * 64)[:64],
            training_context_sha256=context["identity_sha256"],
        ))
    for family in FRESH_SCORE_FAMILIES:
        spec = {"family": family, "parameters": {"fixed": family}}
        scores.append(seal_fresh_training_score(
            family=family,
            outer_fold=outer_fold,
            training_context_sha256=context["identity_sha256"],
            selected_spec=spec,
            selector_evidence_sha256="e" * 64,
            summary=_summary(means[family]),
            execution_evidence_sha256=("f" if family == "ELASTIC_NET_COX" else "a") * 64,
        ))
    return scores


def _lock(context: dict, scores: list[dict]) -> tuple[dict, list[dict]]:
    decision = select_training_family(scores)
    templates = [{
        "family": decision["selected_family"],
        "imputation": imputation,
        "selected_parents": ["AST_ALT", "Age"],
        "parameters": {"imputation": imputation},
    } for imputation in range(1, M + 1)]
    lock = seal_development_lock(
        context=context,
        decision=decision,
        selected_parents=["AST_ALT", "Age"],
        common_set_design_df=2,
        training_event_count=context["training_event_count"],
        parameters_by_imputation=[row["parameters"] for row in templates],
        recipe_sha256_by_imputation=[f"{imputation:064x}" for imputation in range(1, M + 1)],
        baseline_policy_sha256="b" * 64,
        seed_policy_sha256="c" * 64,
        post_lock_template_sha256_by_imputation=[
            sha256_bytes(canonical_json_bytes(row)) for row in templates
        ],
        post_lock_template_archive_sha256_by_imputation=[
            f"{imputation + 100:064x}" for imputation in range(1, M + 1)
        ],
    )
    return lock, templates


def _receipts(lock: dict) -> list[dict]:
    result = []
    for imputation in range(1, M + 1):
        body = {
            "imputation": imputation,
            "development_lock_sha256": lock["identity_sha256"],
            "training_context_sha256": lock["training_context_sha256"],
            "task_sha256": "1" * 64,
            "input_sha256": "2" * 64,
            "mice_member_sha256": "3" * 64,
            "recipe_sha256": lock["recipe_sha256_by_imputation"][imputation - 1],
            "parameter_sha256": sha256_bytes(canonical_json_bytes(
                lock["parameters_by_imputation"][imputation - 1]
            )),
            "training_ids_sha256": lock["training_ids_sha256"],
            "application_ids_sha256": lock["heldout_ids_sha256"],
            "training_response_sha256": "4" * 64,
            "model_sha256": "5" * 64,
            "baseline_sha256": "6" * 64,
            "prediction_sha256": "7" * 64,
            "fit_health_sha256": "8" * 64,
            "model_fit_count": 1,
            "engine_threads": 1,
            "seed": 300000 + imputation,
        }
        result.append(_sealed(body))
    return result


def test_pending_decision_is_not_executable():
    with pytest.raises(ContractError, match="SCIENCE_DECISION_INCOMPLETE"):
        validate_science_decision(science_decision_template())


def test_confirmed_decision_has_one_explicit_machine_readable_surface():
    body = {key: value for key, value in science_decision_template().items()
            if key != "identity_sha256"}
    body["status"] = "CONFIRMED"
    body["training_score_reuse"]["confirmed"] = (
        "REUSE_FIVE_EXACT_ACCEPTED_TRAINING_ONLY_M20_SCORE_SUMMARIES"
    )
    body["fpm"]["confirmed"] = True
    body["aar"]["no_aar_full_data_final_model"] = False
    body["bootstrap"].update(
        definition="NO_BOOTSTRAP_AUTHORIZED_FOR_THIS_RUN",
        b101_b200_trigger=(
            "NOT_APPLICABLE_BECAUSE_BOOTSTRAP_IS_EXPLICITLY_NOT_AUTHORIZED"
        ),
        authorized=False,
    )
    for name in (
        "primary_outer", "full_data_same_program", "a12_direct_total",
        "outer_selected_family_no_aar_redevelopment",
    ):
        body["fit_budget"][name]["authorized"] = True
    body["fit_budget"]["bootstrap_b100_b200"] = {
        "authorized": False,
        "basis": "ZERO_BY_EXPLICIT_NO_BOOTSTRAP_DECISION",
        "ledger": {
            "mice_chains": 0,
            "elastic_path_executions_maximum": 0,
            "glmnet_pilot_and_path_calls_maximum": 0,
            "candidate_prediction_fits": 0,
            "stop_fits": 0,
            "inner_scoring_fits": 0,
            "post_lock_fits": 0,
            "total_model_fits": 0,
        },
    }
    body["fit_budget"]["optional_no_aar_full_data"]["authorized"] = False
    assert validate_science_decision(_sealed(body))["status"] == "CONFIRMED"


@pytest.mark.parametrize("invalid_total", [0, 1])
def test_required_fit_budget_cannot_be_zero_or_unit_placeholder(invalid_total):
    body = {key: value for key, value in science_decision_template().items()
            if key != "identity_sha256"}
    body["status"] = "CONFIRMED"
    body["training_score_reuse"]["confirmed"] = body["training_score_reuse"]["proposal"]
    body["fpm"]["confirmed"] = True
    body["aar"]["no_aar_full_data_final_model"] = False
    body["bootstrap"].update(
        definition="NO_BOOTSTRAP_AUTHORIZED_FOR_THIS_RUN",
        b101_b200_trigger=(
            "NOT_APPLICABLE_BECAUSE_BOOTSTRAP_IS_EXPLICITLY_NOT_AUTHORIZED"
        ),
        authorized=False,
    )
    for name in (
        "primary_outer", "full_data_same_program", "a12_direct_total",
        "outer_selected_family_no_aar_redevelopment",
    ):
        body["fit_budget"][name]["authorized"] = True
    body["fit_budget"]["bootstrap_b100_b200"] = {
        "authorized": False,
        "basis": "ZERO_BY_EXPLICIT_NO_BOOTSTRAP_DECISION",
        "ledger": {
            "mice_chains": 0,
            "elastic_path_executions_maximum": 0,
            "glmnet_pilot_and_path_calls_maximum": 0,
            "candidate_prediction_fits": 0,
            "stop_fits": 0,
            "inner_scoring_fits": 0,
            "post_lock_fits": 0,
            "total_model_fits": 0,
        },
    }
    body["fit_budget"]["optional_no_aar_full_data"]["authorized"] = False
    body["fit_budget"]["full_data_same_program"]["ledger"][
        "total_model_fits"
    ] = invalid_total
    with pytest.raises(ContractError, match="FIT_BUDGET"):
        validate_science_decision(_sealed(body))


def test_exact_fit_budget_contract_is_formula_bound_not_positive_placeholder():
    budget = exact_fit_budget_contract()
    assert budget["primary_outer"]["ledger_options"][
        "REUSE_FIVE_EXACT_ACCEPTED_TRAINING_ONLY_M20_SCORE_SUMMARIES"
    ]["total_model_fits"] == 3720
    full = budget["full_data_same_program"]["ledger"]
    assert full["total_model_fits"] == 9690
    assert full["mice_chains"] == (15 * 2 + 15 * 2 + 1) * 20 == 1220
    assert full["elastic_path_executions_maximum"] == 16 * 20 * 15 == 4800
    assert full["glmnet_pilot_and_path_calls_maximum"] == 9600
    optional = budget["optional_no_aar_full_data"]["by_inherited_family"]
    for family, row in optional.items():
        assert row["mice_chains"] == (1220 if family in {
            "GBM_COX", "XGBOOST_COX", "COXTIME_SET_A"
        } else 620)
        assert row["elastic_path_executions_maximum"] == (
            9600 if family == "ELASTIC_NET_COX" else 4800
        )
        assert row["inner_scoring_fits"] == 0
    assert budget["a12_direct_total"]["per_outer_by_inherited_family"][
        "XGBOOST_COX"
    ]["total_model_fits"] == 5240
    assert budget["outer_selected_family_no_aar_redevelopment"][
        "per_outer_by_inherited_family"
    ]["COX_PH"]["post_lock_fits"] == 20
    assert budget["bootstrap_b100_b200"]["ledger"] is None


def test_confirmed_fresh_seven_batch_separates_fixed_b1000_from_deferred_retraining():
    from test_nested_full_development import _unfitted_confirmed_decision
    decision = _unfitted_confirmed_decision(fixed_bootstrap=True)
    assert decision["training_score_reuse"]["families"] == []
    assert decision["training_score_reuse"]["fresh_families"] == list(_families())
    budget = decision["fit_budget"]
    assert budget["primary_outer"]["ledger_options"]["FRESH_SEVEN_FAMILY_REPLAY"]["total_model_fits"] == 12720
    assert budget["full_data_same_program"]["ledger"]["total_model_fits"] == 9690
    fixed = decision["bootstrap"]["fixed_prediction"]
    assert fixed["root_seed"] == 700000001 and fixed["replicate_count"] == 1000
    assert fixed["branches"] == ["PRIMARY", *AAR_ESTIMANDS]
    assert fixed["contrast"] == "CONTROL_MINUS_PRIMARY"
    assert fixed["new_predictive_model_fits"] == 0
    assert decision["bootstrap"]["full_retraining"]["authorized"] is False
    assert budget["bootstrap_b100_b200"]["ledger"] == budget["fixed_prediction_paired_b1000"]["ledger"]
    assert all(count == 0 for count in budget["bootstrap_b100_b200"]["ledger"].values())
    combined = {
        family: {key: budget["a12_direct_total"]["per_outer_by_inherited_family"][family][key]
                 + budget["outer_selected_family_no_aar_redevelopment"]["per_outer_by_inherited_family"][family][key]
                 for key in budget["full_data_same_program"]["ledger"]}
        for family in decision["training_score_reuse"]["fresh_families"]
    }
    assert [combined[family]["total_model_fits"] for family in decision["training_score_reuse"]["fresh_families"]] == [
        60, 60, 3270, 6900, 7860, 60, 4920]
    assert [combined[family]["mice_chains"] for family in decision["training_score_reuse"]["fresh_families"]] == [
        680, 1280, 1280, 2480, 2480, 680, 2480]


@pytest.mark.parametrize("damage", ["mixed_old_scores", "changed_seed", "changed_replicates", "changed_contrast", "retraining_authorized", "nonzero_fit_budget", "boolean_fit_budget"])
def test_confirmed_batch_rejects_silent_science_or_budget_changes(damage):
    from test_nested_full_development import _unfitted_confirmed_decision
    body = {key: value for key, value in _unfitted_confirmed_decision(fixed_bootstrap=True).items() if key != "identity_sha256"}
    if damage == "mixed_old_scores":
        body["training_score_reuse"]["families"] = list(REUSED_SCORE_FAMILIES)
    elif damage == "retraining_authorized":
        body["bootstrap"]["full_retraining"]["authorized"] = True
    elif damage in {"nonzero_fit_budget", "boolean_fit_budget"}:
        body["fit_budget"]["fixed_prediction_paired_b1000"]["ledger"]["total_model_fits"] = 1 if damage == "nonzero_fit_budget" else False
    else:
        key, value = {"changed_seed": ("root_seed", 700000002), "changed_replicates": ("replicate_count", 100),
                      "changed_contrast": ("contrast", "PRIMARY_MINUS_CONTROL")}[damage]
        body["bootstrap"]["fixed_prediction"][key] = value
    with pytest.raises(ContractError, match="NESTED_(SCIENCE_DECISION_INCOMPLETE|FIT_BUDGET_DRIFT)"):
        validate_science_decision(_sealed(body))


@pytest.mark.parametrize("damage", [None, "double_recovery", "risk_floor", "dca_divisor",
                                   "truncate_followup", "boolean_budget", "other_line_family", "old_24_budget"])
def test_twelve_month_science_extension_preserves_original_authority_and_caps(damage):
    from padml import nested_loco as nested
    from test_nested_full_development import _unfitted_confirmed_decision
    old = _unfitted_confirmed_decision(fixed_bootstrap=True)
    body = {k: v for k, v in deepcopy(old).items() if k != "identity_sha256"}
    twelve = nested._twelve_month_development_contract()
    body["twelve_month_development"] = twelve
    if damage == "double_recovery":
        twelve["development_incremental_budget"]["total_maximum"]["total_model_fits"] += 13920
    elif damage == "risk_floor":
        twelve["uno"]["risk"] = "-log(max(S(12),1e-8))"
    elif damage == "dca_divisor":
        twelve["dca"]["normalization_divisor"] = 0.125
    elif damage == "truncate_followup":
        twelve["ibs"]["followup_truncation"] = True
    elif damage == "boolean_budget":
        twelve["protected_34_model_refits"] = False
    elif damage == "other_line_family":
        twelve["aar_incremental_budget"]["family_source"] = "OTHER_LINE_PRIMARY_OUTER_LOCK"
    elif damage == "old_24_budget":
        body["fit_budget"]["primary_outer"]["authorized"] = False
    if damage is not None:
        with pytest.raises(ContractError, match="NESTED_(TWELVE_MONTH_DECISION_OR_ORIGINAL_AUTHORITY_DRIFT|FIT_BUDGET_DRIFT)"):
            validate_science_decision(_sealed(body))
        return
    actual = validate_science_decision(_sealed(body))
    assert _sealed({k: actual[k] for k in nested._DECISION_FIELDS}) == old
    assert twelve["original_24_month_decision_sha256"] == old["identity_sha256"]
    budget = twelve["development_incremental_budget"]
    assert budget["total_maximum"]["total_model_fits"] == 59210
    assert budget["initial_outer_f2_evidence_recovery_maximum"]["total_model_fits"] == 13920
    assert budget["initial_recovery_is_included_not_additional"] is True
    assert twelve["total_incremental_model_fit_ceiling"] == 106370
    assert twelve["fixed_prediction_evaluation"]["branch_scope_jobs_maximum"] == 28028
    assert twelve["full0_shap"]["maximum_mi_components"] == 20


@pytest.mark.parametrize("include_twelve", [False, True])
@pytest.mark.parametrize("damage", [None, "four_only", "wrong_unit", "other_horizon", "model_overwrite",
                                   "stop_fit", "protected_model", "boolean_budget", "old_24_budget"])
def test_exact_rsf_restoration_extension_preserves_original_and_twelve_budgets(include_twelve, damage):
    from padml import nested_loco as nested
    from test_nested_full_development import _unfitted_confirmed_decision
    old = _unfitted_confirmed_decision(fixed_bootstrap=True)
    body = {key: value for key, value in deepcopy(old).items() if key != "identity_sha256"}
    if include_twelve:
        body["twelve_month_development"] = nested._twelve_month_development_contract()
    restoration = nested._full0_rsf_tail_restoration_contract()
    body["full0_rsf_tail_restoration"] = restoration
    if damage == "four_only":
        restoration["additional_fit_budget"]["candidate_prediction_fits"] = 4
        restoration["additional_fit_budget"]["total_model_fits"] = 4
    elif damage == "wrong_unit":
        restoration["atomic_units"][0]["task_ids"][-1] = "S3B2_T001_P14_M09"
    elif damage == "other_horizon":
        restoration["selection_horizon_months"] = 12
    elif damage == "model_overwrite":
        restoration["existing_model_and_failure_evidence"] = "REPLACE_INCOMPLETE"
    elif damage == "stop_fit":
        restoration["additional_fit_budget"]["stop_fits"] = 1
    elif damage == "protected_model":
        restoration["protected_34_model_refits"] = 1
    elif damage == "boolean_budget":
        restoration["additional_fit_budget"]["mice_chains"] = False
    elif damage == "old_24_budget":
        body["fit_budget"]["primary_outer"]["authorized"] = False
    if damage is not None:
        with pytest.raises(ContractError, match="NESTED_(RSF_RESTORATION_DECISION_OR_ORIGINAL_AUTHORITY_DRIFT|FIT_BUDGET_DRIFT)"):
            validate_science_decision(_sealed(body))
        return
    actual = validate_science_decision(_sealed(body))
    from padml import f5
    assert f5._full_development_science_decision(actual, selection_horizon_months=24) == actual
    if include_twelve:
        assert f5._full_development_science_decision(actual, selection_horizon_months=12) == actual
    else:
        with pytest.raises(ContractError, match="F5_FULL_DEVELOPMENT_SELECTION_HORIZON_NOT_AUTHORIZED"):
            f5._full_development_science_decision(actual, selection_horizon_months=12)
    assert _sealed({key: actual[key] for key in nested._DECISION_FIELDS}) == old
    assert restoration["additional_fit_budget"]["total_model_fits"] == 8
    for unit in restoration["atomic_units"]:
        assert unit["unit_id"] == "batch-" + sha256_bytes(canonical_json_bytes(unit["task_ids"]))[:24]
        assert len(unit["task_ids"]) == 4 and len(unit["existing_incomplete_model_task_ids"]) == 2
    assert sum(len(unit["existing_incomplete_model_task_ids"]) for unit in restoration["atomic_units"]) == 4
    if include_twelve:
        assert actual["twelve_month_development"] == nested._twelve_month_development_contract()


@pytest.mark.parametrize("damage", [None, "missing_chain_credit", "extra_chain", "extra_call",
    "prediction", "stop", "path", "glmnet", "boolean_count", "protected", "horizon",
    "view", "input", "seed", "current_failure_waived", "old_rsf", "old_twelve", "old_24"])
def test_aar3_mice_recovery_is_conditional_exact_and_separately_accounted(damage):
    from padml import nested_loco as nested
    from test_nested_full_development import _unfitted_confirmed_decision
    old = _unfitted_confirmed_decision(fixed_bootstrap=True)
    body = {key: value for key, value in deepcopy(old).items() if key != "identity_sha256"}
    body["twelve_month_development"] = nested._twelve_month_development_contract()
    body["full0_rsf_tail_restoration"] = nested._full0_rsf_tail_restoration_contract()
    prior = _sealed(deepcopy(body))
    assert prior["identity_sha256"] == "7875d1c47e4a2815558acbc7ea0127e47defbc0d28c599ff4669035499583297"
    recovery = nested._aar3_mice_view_restoration_contract()
    body["aar3_mice_view_restoration"] = recovery
    counts = recovery["additional_fit_budget"]
    if damage in {"missing_chain_credit", "extra_chain", "boolean_count"}:
        counts["mice_chains"] = {"missing_chain_credit": 49, "extra_chain": 61, "boolean_count": True}[damage]
    elif damage == "extra_call":
        recovery["mice_fit_invocations_maximum"] = 4
    elif damage in {"prediction", "stop", "path", "glmnet"}:
        field = {"prediction": "candidate_prediction_fits", "stop": "stop_fits",
                 "path": "elastic_path_executions_maximum", "glmnet": "glmnet_pilot_and_path_calls_maximum"}[damage]
        counts[field] = 1
        if damage in {"prediction", "stop"}:
            counts["total_model_fits"] = 1
    elif damage == "protected":
        recovery["protected_34_model_refits"] = 1
    elif damage == "horizon":
        recovery["selection_horizon_months"] = 12
    elif damage == "view":
        recovery["atomic_units"][0]["view_id"] = "OUTER_ANALYSIS"
    elif damage == "input":
        recovery["atomic_units"][0]["original_input"]["sha256"] = "a" * 64
    elif damage == "seed":
        recovery["atomic_units"][0]["chain_seeds"][0] += 20
    elif damage == "current_failure_waived":
        recovery["required_per_unit_admission_evidence"].remove("NO_CURRENT_FAULT_DETECTED")
    elif damage == "old_rsf":
        body["full0_rsf_tail_restoration"]["additional_fit_budget"]["candidate_prediction_fits"] = 16
    elif damage == "old_twelve":
        body["twelve_month_development"]["development_incremental_budget"]["initial_recovery_is_included_not_additional"] = False
    elif damage == "old_24":
        body["fit_budget"]["primary_outer"]["authorized"] = False
    if damage is not None:
        with pytest.raises(ContractError, match="NESTED_(AAR3_MICE_RESTORATION_OR_PRIOR_AUTHORITY_DRIFT|RSF_RESTORATION_DECISION_OR_ORIGINAL_AUTHORITY_DRIFT|TWELVE_MONTH_DECISION_OR_ORIGINAL_AUTHORITY_DRIFT|FIT_BUDGET_DRIFT)"):
            validate_science_decision(_sealed(body))
        return
    actual = validate_science_decision(_sealed(body))
    assert _sealed({key: value for key, value in actual.items()
                    if key not in {"identity_sha256", "aar3_mice_view_restoration"}}) == prior
    assert _sealed({key: actual[key] for key in nested._DECISION_FIELDS}) == old
    assert counts == nested._ledger_counts(mice=60, paths=0, glmnet_calls=0,
        candidate=0, stop=0, scoring=0, final=0)
    assert recovery["mice_fit_invocations_maximum"] == 3
    assert [len(unit["chain_seeds"]) for unit in recovery["atomic_units"]] == [20, 20, 20]
    assert sum(len(unit["preserve_original_partial_rds"]) for unit in recovery["atomic_units"]) == 11
    assert recovery["status"] == "CONFIRMED_CONDITIONAL_EXECUTION"
    assert "NO_CURRENT_FAULT_DETECTED" in recovery["required_per_unit_admission_evidence"]
    assert "ORIGINAL_TASK_STOPPED" in recovery["required_per_unit_admission_evidence"]
    assert recovery["historical_interruption_cause"] == "UNKNOWN"
    assert "cause_removed" not in recovery


def test_context_binds_training_response_and_exposes_no_heldout_response():
    context = _context()
    assert context["heldout_response_member_count"] == 0
    validate_training_context(context, _response(context["training_ids"]))
    changed = _response(list(reversed(context["training_ids"])))
    with pytest.raises(ContractError, match="TRAINING_RESPONSE_DRIFT"):
        validate_training_context(context, changed)
    body = {key: value for key, value in context.items() if key != "identity_sha256"}
    body["centers_by_patient"]["v1"] = "38"
    body["center_binding_sha256"] = sha256_bytes(
        canonical_json_bytes(body["centers_by_patient"])
    )
    with pytest.raises(ContractError, match="OUTER_CONTEXT_ISOLATION"):
        validate_training_context(_sealed(body))


def test_covariate_component_rejects_extra_outcome_smuggling_column():
    raw = b"Patient_ID,Center,SecretHeldoutOutcome\np1,36,1\n"
    with pytest.raises(ContractError, match="COVARIATE_SCHEMA_INVALID"):
        _covariate_ids(raw, "NESTED_SMUGGLING")


def test_accepted_projection_excludes_heldout_fields():
    context = _context()
    model = _accepted_model("COX_PH", 0.1)
    score = project_accepted_training_score(
        model,
        source_result_sha256="1" * 64,
        training_context_sha256=context["identity_sha256"],
    )
    encoded = canonical_json_bytes(score)
    assert b"outer_metric" not in encoded and b"monthly_oof" not in encoded
    assert score["heldout_outcome_read_count"] == 0
    drifted = {**model, "outer_metric": {"ibs_0_24": 123.0},
               "monthly_oof": {"predictions": ["different-heldout"]}}
    second = project_accepted_training_score(
        drifted,
        source_result_sha256="1" * 64,
        training_context_sha256=context["identity_sha256"],
    )
    assert second["source_value_sha256"] == score["source_value_sha256"]


def test_selected_prediction_rejects_nonunit_month_zero():
    context = _context()
    lock, _ = _lock(context, _scores(context))
    invalid = [[0.5] + [0.4] * 36 for _ in context["heldout_ids"]]
    with pytest.raises(ContractError, match="MONTH_ZERO"):
        seal_selected_prediction(
            lock=lock,
            patient_ids=context["heldout_ids"],
            centers=[str(context["heldout_center"])] * len(context["heldout_ids"]),
            survival=invalid,
            component_receipts=_receipts(lock),
        )


def test_family_rule_is_order_invariant_and_uses_max_repeat_before_preferences():
    context = _context()
    means = {family: 0.2 for family in _families()}
    scores = _scores(context, means)
    # Give RSF the uniquely lower worst repeat while leaving means tied.
    updated = []
    for score in scores:
        if score["family"] != "RSF":
            updated.append(score)
            continue
        body = {key: value for key, value in score.items() if key != "identity_sha256"}
        values = [0.1999, 0.2, 0.2001]
        body.update(ranking_metric_values=values, mean_ibs=sum(values) / 3,
                    maximum_ibs=max(values))
        updated.append(_sealed(body))
    # All other summaries also use max 0.2001 in this fixture, so complexity
    # selects COX_PH. Make their maximum larger without changing mean.
    for index, score in enumerate(updated):
        if score["family"] == "RSF":
            continue
        body = {key: value for key, value in score.items() if key != "identity_sha256"}
        values = [0.1998, 0.1998, 0.2004]
        body.update(ranking_metric_values=values, mean_ibs=sum(values) / 3,
                    maximum_ibs=max(values))
        updated[index] = _sealed(body)
    first = select_training_family(updated)
    second = select_training_family(list(reversed(updated)))
    assert first == second
    assert first["selected_family"] == "RSF"
    assert first["layers"][1]["criterion"] == "MAXIMUM_REPEAT_IBS"
    drifted = list(updated)
    body = {key: value for key, value in drifted[0].items() if key != "identity_sha256"}
    body["selector_evidence_sha256"] = "9" * 64
    drifted[0] = _sealed(body)
    with pytest.raises(ContractError, match="FAMILY_SELECTION_INPUT_INVALID"):
        select_training_family(drifted)


def test_fresh_score_reducer_uses_all_300_component_metrics_and_m20_pooling(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
):
    training_ids = [f"p{index:02d}" for index in range(40)]
    stream = io.StringIO(newline="")
    writer = csv.DictWriter(
        stream,
        fieldnames=["Patient_ID", "All_Cause_Death", "Death_Followup_months"],
        lineterminator="\n",
    )
    writer.writeheader()
    for patient in training_ids:
        writer.writerow({
            "Patient_ID": patient,
            "All_Cause_Death": 1,
            "Death_Followup_months": 50,
        })
    response = stream.getvalue().encode()
    centers = {patient: "38" for patient in training_ids}
    centers["heldout"] = "36"
    context = compile_training_context(
        scope="OUTER", outer_fold=1, heldout_center=36,
        training_ids=training_ids, heldout_ids=["heldout"],
        centers_by_patient=centers, training_response_csv=response,
        mice_member_set_sha256="a" * 64,
        preprocessing_program_sha256="b" * 64,
        modeling_program_sha256="c" * 64,
        seed_program_sha256="d" * 64,
    )
    partitions = []
    records = []
    outputs = {}
    record_by_path = {}
    partition_by_coordinate = {}
    counter = 0
    for repeat in range(1, 4):
        for inner in range(1, 6):
            evaluation_ids = training_ids[(inner - 1) * 8:inner * 8]
            fit_ids = [patient for patient in training_ids if patient not in evaluation_ids]
            partition = {
                "partition_id": f"R{repeat}K{inner}",
                "repeat": repeat,
                "inner_fold": inner,
                "fit_ids": fit_ids,
                "evaluation_ids": evaluation_ids,
            }
            partitions.append(partition)
            partition_by_coordinate[repeat, inner] = partition
            for imputation in range(1, 21):
                counter += 1
                path = f"components/score/FPM/R{repeat}_K{inner}_M{imputation:02d}.zip"
                record = {
                    "path": path,
                    "family": "FPM_TVC_SET_A",
                    "repeat": repeat,
                    "inner_fold": inner,
                    "imputation": imputation,
                    "sha256": f"{counter:064x}",
                }
                records.append(record)
                record_by_path[path] = record
                curve = [1.0] + [0.6 if imputation <= 10 else 1.0] * 36
                outputs[path] = ({
                    "patient_ids": evaluation_ids,
                    "centers": ["38"] * len(evaluation_ids),
                    "horizons": list(HORIZONS),
                    "survival": {"FPM_TVC_SET_A": [curve] * len(evaluation_ids)},
                }, {"identity_sha256": f"{counter:064x}", "archive_sha256": f"{counter:064x}",
                    "component_role": "FRESH_SCORE"}, {})
                prediction, receipt, health = outputs[path]
                outputs[path] = _score_component_evidence(record=record, context=context,
                    partition_id=partition["partition_id"], prediction=prediction, receipt=receipt,
                    fit_health=health, object_audit={"UNFITTED_POOLING_UNIT": True})

    def fake_component(path: Path):
        relative = path.relative_to(tmp_path / "request").as_posix()
        record = record_by_path[relative]
        partition = partition_by_coordinate[record["repeat"], record["inner_fold"]]
        covariates = ("Patient_ID,Center\n" + "".join(
            f"{patient},38\n" for patient in partition["evaluation_ids"]
        )).encode()
        return ({
            "family": "FPM_TVC_SET_A",
            "parameters": {"family": "FPM_TVC_SET_A", "df": 3, "tvc_df": 1},
        }, {}, {"prediction-covariates.csv": covariates})

    monkeypatch.setattr("padml.nested_loco._read_component", fake_component)
    # This pre-existing arithmetic unit supplies deliberately abbreviated
    # receipts. The real worker/evidence boundaries have separate tests.
    monkeypatch.setattr("padml.nested_loco._validate_score_component_evidence", lambda value, **kwargs: value)
    request_root = tmp_path / "request" / "training"
    request_root.mkdir(parents=True)
    (request_root / "response.csv").write_bytes(response)
    request = {
        "training_context": context,
        "score_partitions": partitions,
        "component_records": records,
        "reused_training_scores": _scores(context)[:1],
        "selector_evidence_sha256": _scores(context)[0]["selector_evidence_sha256"],
    }
    score, execution = _score_fresh_family(
        family="FPM_TVC_SET_A", request=request, root=tmp_path, outputs=outputs
    )
    assert len(score["metric_values"]) == 300
    assert len(score["fold_metric_values"]) == 15
    assert len(score["ranking_metric_values"]) == 3
    assert score["metric_values"] == pytest.approx(
        [0.1566666666666667 if imputation <= 10 else 0.0
         for _repeat in range(3) for _inner in range(5)
         for imputation in range(1, 21)]
    )
    assert score["fold_metric_values"] == pytest.approx(
        [0.03916666666666667] * 15
    )
    assert score["ranking_metric_values"] == pytest.approx(
        [0.03916666666666667] * 3
    )
    assert validate_fresh_score_execution(execution) == execution


def test_score_xgboost_audit_binds_model_digest_after_consistent_resealing(monkeypatch):
    from padml import nested_loco as nested
    context = _context()
    coordinates = {"purpose": "O_FIT", "outer_fold": 1, "repeat": 1, "inner_fold": 1, "imputation": 1}
    patients = context["training_ids"][:2]
    prediction = {"f4_coordinates": coordinates, "patient_ids": patients,
        "centers": [context["centers_by_patient"][patient] for patient in patients], "horizons": list(HORIZONS),
        "survival": {"XGBOOST_COX": [[1.0] + [0.8] * 36 for _ in patients]}}
    health = {"model_binary_sha256": "a" * 64}
    receipt = {key: "a" * 64 for key in nested._SCORE_RECEIPT_FIELDS}
    receipt.update({"component_role": "FRESH_SCORE", "family": "XGBOOST_COX", "repeat": 1, "inner_fold": 1,
        "imputation": 1, "development_lock_sha256": None, "training_context_sha256": context["identity_sha256"],
        "model_fit_count": 1, "engine_threads": 1, "seed": 100001, "prediction_sha256": nested._sha(prediction),
        "fit_health_sha256": nested._sha(health)})
    record = {"family": "XGBOOST_COX", "repeat": 1, "inner_fold": 1, "imputation": 1,
              "path": "components/score/XGBOOST_COX/R1_K1_M01.zip", "sha256": "a" * 64}
    evidence = _score_component_evidence(record=record, context=context, partition_id="R1K1",
        receipt=_sealed(receipt), prediction=prediction, fit_health=health,
        object_audit={"design_columns": ["AST_ALT"], "booster_round_count": 10})
    def forbidden(*args, **kwargs):
        pytest.fail("SCORE_NUMERIC_BINDING_MUST_NOT_READ_NATIVE_ZIP")
    monkeypatch.setattr(nested, "read_safe_zip", forbidden)
    assert nested._validate_score_component_evidence(evidence, context=context) == evidence
    changed_health = {"model_binary_sha256": "b" * 64}
    changed = _sealed({**{key: value for key, value in evidence.items() if key != "identity_sha256"},
        "fit_health": changed_health, "receipt": _sealed({**receipt, "fit_health_sha256": nested._sha(changed_health)})})
    with pytest.raises(ContractError, match="NESTED_SCORE_OBJECT_AUDIT_MODEL_BINDING_DRIFT"):
        nested._validate_score_component_evidence(changed, context=context)


def test_lock_precedes_executable_task():
    context = _context()
    lock, templates = _lock(context, _scores(context))
    selected = next(row for row in templates if row["imputation"] == 1)
    task = bind_post_lock_task(selected, lock)
    assert task["development_lock_sha256"] == lock["identity_sha256"]
    with pytest.raises(ContractError, match="POST_LOCK_TEMPLATE_INVALID"):
        bind_post_lock_task({**selected, "parameters": {"imputation": 99}}, lock)


def _six_outer_fixture():
    # Interleave centers so assembly must recover frozen order, not fold order.
    all_ids = [f"p{outer}-{index}" for index in range(6) for outer in range(1, 7)] + ["t55"]
    center_map = {f"p{outer}-{index}": str(center)
                  for outer, center in enumerate(OUTER_CENTERS, 1) for index in range(6)}
    center_map["t55"] = "55"
    registry = {
        "all_patient_ids": all_ids,
        "evaluation_patient_ids": all_ids[:-1],
        "centers_by_patient": center_map,
        "outer": [{
            "outer_fold": outer, "heldout_center": center,
            "training_ids": [patient for patient in all_ids if center_map[patient] != str(center)],
            "heldout_ids": [patient for patient in all_ids if center_map[patient] == str(center)],
        } for outer, center in enumerate(OUTER_CENTERS, 1)],
    }
    predictions = []
    for part in registry["outer"]:
        outer, center = part["outer_fold"], part["heldout_center"]
        training, heldout = part["training_ids"], part["heldout_ids"]
        context = compile_training_context(
            scope="OUTER",
            outer_fold=outer,
            heldout_center=center,
            training_ids=training,
            heldout_ids=heldout,
            centers_by_patient=center_map,
            training_response_csv=_response(training),
            mice_member_set_sha256="a" * 64,
            preprocessing_program_sha256="b" * 64,
            modeling_program_sha256="c" * 64,
            seed_program_sha256="d" * 64,
        )
        scores = _scores(context, {
            family: 0.1 if index == outer - 1 else 0.2
            for index, family in enumerate(_families())
        })
        lock, _ = _lock(context, scores)
        receipts = _receipts(lock)
        curve = [1.0] + [0.99 - month / 100 for month in range(1, 37)]
        predictions.append(seal_selected_prediction(
            lock=lock,
            patient_ids=heldout,
            centers=[str(center)] * len(heldout),
            survival=[curve] * len(heldout),
            component_receipts=receipts,
        ))
    return predictions, registry


def test_six_outer_selected_ooc_allows_different_winners_but_no_overlap():
    predictions, registry = _six_outer_fixture()
    ooc = assemble_selected_ooc(list(reversed(predictions)), population_registry=registry)
    assert ooc["patient_ids"] == registry["evaluation_patient_ids"]
    assert len({row["selected_family"] for row in ooc["selection_by_outer"]}) == 6
    assert ooc["outer_family_consensus_required"] is False


def test_ooc_rejects_missing_frozen_patient_even_with_valid_prediction_seal():
    predictions, registry = _six_outer_fixture()
    drift = deepcopy(predictions[0])
    drift.pop("identity_sha256")
    drift["patient_ids"][0] = "foreign-patient"
    drift["patient_ids_sha256"] = sha256_bytes(canonical_json_bytes(drift["patient_ids"]))
    from padml.f2_kernel import _seal_prediction_matrix
    drift["survival_seal_sha256"] = _seal_prediction_matrix(
        drift["patient_ids"], drift["survival"], list(HORIZONS)
    )["sha256"]
    with pytest.raises(ContractError, match="REGISTRY_PATIENT_DRIFT"):
        assemble_selected_ooc([_sealed(drift), *predictions[1:]], population_registry=registry)


@pytest.mark.parametrize("mutation", ["primary_as_ablation", "invalid_probability", "foreign_family", "foreign_lock"])
def test_paired_aar_rejects_invalid_branch_or_inheritance(mutation):
    predictions, registry = _six_outer_fixture()
    primary = assemble_selected_ooc(predictions, population_registry=registry)
    branch = deepcopy(primary)
    branch.pop("identity_sha256")
    branch["variant"] = WITHIN_FAMILY_NO_AAR_REDEVELOPMENT
    for outer, row in enumerate(branch["selection_by_outer"], 1):
        row["development_lock_sha256"] = f"{outer + 1000:064x}"
        row["prediction_identity_sha256"] = f"{outer + 2000:064x}"
    branch = _sealed(branch)
    valid = paired_aar_contrast(primary, branch,
        estimand=WITHIN_FAMILY_NO_AAR_REDEVELOPMENT, population_registry=registry)
    assert all(delta == 0 for row in valid["risk_delta_ablated_minus_primary"] for delta in row)
    changed = deepcopy(branch)
    changed.pop("identity_sha256")
    if mutation == "invalid_probability":
        changed["survival"]["NESTED_SELECTED_POLICY"][0][1] = 2
    elif mutation == "foreign_family":
        changed["selection_by_outer"][0]["selected_family"] = "RSF"
    elif mutation == "foreign_lock":
        changed["selection_by_outer"][0]["primary_development_lock_sha256"] = "f" * 64
    invalid = primary if mutation == "primary_as_ablation" else _sealed(changed)
    with pytest.raises(ContractError):
        paired_aar_contrast(primary, invalid,
            estimand=WITHIN_FAMILY_NO_AAR_REDEVELOPMENT, population_registry=registry)


def test_aar_estimands_remain_distinct_and_paired():
    assert set(AAR_ESTIMANDS) == {
        A12_DIRECT_AAR,
        A12_TOTAL_AAR,
        WITHIN_FAMILY_NO_AAR_REDEVELOPMENT,
    }
    assert all(
        aar_estimand_contract(estimand)["family_reselection"] is False
        for estimand in AAR_ESTIMANDS
    )
    new = aar_estimand_contract(WITHIN_FAMILY_NO_AAR_REDEVELOPMENT)
    assert new["seta_reselection"] is True
    assert new["family_comparison_count"] == 1
    assert new["label"] == WITHIN_FAMILY_NO_AAR_LABEL


@pytest.mark.parametrize("raw", [
    b"Patient_ID,Center\np1,36,extra\n",
    b"Patient_ID,Center\np1\n",
    b"Patient_ID,Center,Center\np1,36,36\n",
])
def test_csv_rejects_ragged_rows_and_duplicate_headers(raw):
    from padml.nested_loco import _csv_rows
    with pytest.raises(ContractError):
        _csv_rows(raw, "FIXTURE")


@pytest.mark.parametrize("consumer", ["canonical_json", "marker"])
def test_run_custody_rejects_symlink_parent_even_when_leaf_is_regular(tmp_path, consumer):
    import padml.nested_loco as nested
    outside = tmp_path / "outside"
    outside.mkdir()
    (outside / "input.json").write_bytes(b"{}")
    root = tmp_path / "run"
    root.mkdir()
    alias = root / "aliased-parent"
    alias.symlink_to(outside, target_is_directory=True)
    leaf = alias / "input.json"
    assert leaf.is_file() and not leaf.is_symlink()
    with pytest.raises(ContractError):
        if consumer == "canonical_json":
            nested._read_canonical(leaf, "FIXTURE")
        else:
            nested._write_exact_once(leaf, b"{}", "FIXTURE")


@pytest.mark.parametrize("fault", ["before_link", "after_link", "file_fsync", "directory_fsync"])
def test_atomic_marker_fault_never_exposes_partial_json(tmp_path, monkeypatch, fault):
    import padml.nested_loco as nested
    target = tmp_path / "marker.json"
    payload = canonical_json_bytes({"coordinate": "frozen"})
    original_link, original_fsync = nested.os.link, nested.os.fsync
    fsync_count = 0

    def fail_link(*args, **kwargs):
        if fault == "after_link":
            original_link(*args, **kwargs)
        raise OSError("injected link interruption")

    def fail_fsync(descriptor):
        nonlocal fsync_count
        fsync_count += 1
        original_fsync(descriptor)
        if fsync_count == (1 if fault == "file_fsync" else 2):
            raise OSError("injected durability interruption")

    with monkeypatch.context() as injected:
        if "link" in fault:
            injected.setattr(nested.os, "link", fail_link)
        else:
            injected.setattr(nested.os, "fsync", fail_fsync)
        with pytest.raises(OSError):
            nested._write_exact_once(target, payload, "MARKER_DRIFT")
    assert not target.exists() or target.read_bytes() == payload
    for _ in range(2):
        nested._write_exact_once(target, payload, "MARKER_DRIFT")
        assert target.read_bytes() == payload
    with pytest.raises(ContractError, match="MARKER_DRIFT"):
        nested._write_exact_once(target, b"different", "MARKER_DRIFT")


# Aggregate-only compatibility; every source producer still binds its own lock.
from padml import nested_loco as n

# Original 402b5fb3 assembler function SHA: 3a3021cc04b64448d1b86a1a9520781467304e6e5ae1c077f16e064f99255ccb
# Golden bytes use the existing synthetic M20 fixture; no native computation.
_FREQUENCY_REFERENCE_OOC_SHA = {'6:base': 'c3aa7f9216a2f1337298645bf34d78845f9e54035f3f31dd4073b292b731e6a9', '6:current': 'd3f5686a842f7982aa93f5c4eabf0fa15116f719f925e20978d1074bb31cf69d', '12:base': '9638754acefdf593e82789a18c20cb705335812cf39ff4dbf828d48eb252e07c', '12:current': '91ccd4b8f48e76b1778ca5095c06a4031c0c4ef026ff0ea3a32acfb9f2ce6595', '24:base': 'ea8c12ac5a1d1aa523d238b7891925fa3fd62206f975618b3fe3532f6546f06b', '24:current': 'ac80e1f05d298677c09cf8b38a69e80fa472b4fc377821698aecfa7e01e3c19a', '36:base': '1e6ea96828c51e3af140b6435847660cfd41b362c1879c7b0e88777adb47b8c7', '36:current': '9cfc99f356f66972745c14bdce58463b426eb012bdf7d121fc4e4c30f3cae957'}

@pytest.fixture(scope='module')
def frequency_six():
    return _six_outer_fixture()


def _frequency_prediction_science(row, science, horizon=24):
    return n._sealed({**{k: v for k, v in row.items() if k != 'identity_sha256'},
        'selection_horizon_months': horizon, 'science_decision_sha256': science['identity_sha256']})


@pytest.mark.parametrize('horizon', [6, 12, 24, 36])
def test_all_base_and_all_current_ooc_bytes_unchanged(frequency_six, horizon):
    original, registry = frequency_six
    for authority, science in [('base', n._base_science_decision_template(horizon)), ('current', n.science_decision_template(horizon))]:
        rows = [_frequency_prediction_science(row, science, horizon) for row in original]
        assert sha256_bytes(canonical_json_bytes(n.assemble_selected_ooc(rows, population_registry=registry))) == (
            _FREQUENCY_REFERENCE_OOC_SHA[str(horizon) + ':' + authority])


def test_mixed_ooc_preserves_constituents_and_uses_exact_amendment(frequency_six):
    original, registry = frequency_six
    base, current = n._base_science_decision_template(24), n.science_decision_template(24)
    rows = [_frequency_prediction_science(row, base if index % 2 else current) for index, row in enumerate(original)]
    before = canonical_json_bytes(rows)
    result = n.assemble_selected_ooc(list(reversed(rows)), population_registry=registry)
    assert result['science_decision_sha256'] == current['identity_sha256']
    assert canonical_json_bytes(rows) == before
    assert [r['prediction_identity_sha256'] for r in result['selection_by_outer']] == [r['identity_sha256'] for r in rows]
    assert [r['development_lock_sha256'] for r in result['selection_by_outer']] == [r['development_lock_sha256'] for r in rows]
    assert result['survival'] == n.assemble_selected_ooc(original, population_registry=registry)['survival']


@pytest.mark.parametrize('damage', ['foreign_identity', 'other_population', 'mixed_horizon', 'missing_outer'])
def test_mixed_ooc_has_no_generic_science_or_partial_admission(frequency_six, damage):
    original, registry = frequency_six
    rows = deepcopy(original)
    if damage == 'missing_outer':
        rows.pop()
    else:
        body = {k: v for k, v in rows[0].items() if k != 'identity_sha256'}
        if damage == 'foreign_identity':
            body['science_decision_sha256'] = 'f' * 64
        elif damage == 'other_population':
            body['science_decision_sha256'] = n.science_decision_template(36)['identity_sha256']
        else:
            body['selection_horizon_months'] = 12
        rows[0] = n._sealed(body)
    with pytest.raises(ContractError):
        n.assemble_selected_ooc(rows, population_registry=registry)


@pytest.fixture(scope='module')
def frequency_one_lock():
    context = _context()
    return _lock(context, _scores(context))[0]


def _frequency_lock_trace(tier, *, terminal=False):
    policy = n.selector_frequency_policy()
    coarse = n.load_science_authority()['science']['f2_model_development']['selector_contract']['alpha_grid']['coarse']
    attempts = []
    for index, stage in enumerate(policy['ladder'][:tier]):
        success = index == tier - 1 and not terminal
        attempts.append({**stage, 'alpha_feasibility': [
            {'alpha': alpha, 'status': 'FEASIBLE' if success else 'EPV_INFEASIBLE',
             'reason_code': 'OK' if success else 'COMMON_SETA_EPV_BELOW_MINIMUM',
             'common_set_design_df': 2 if success else 4, 'common_set_epv': 15 if success else 7.5}
            for alpha in coarse]})
    return {'preferred_minimum': 15, 'minimum': attempts[-1]['minimum'],
        'fallback_used': attempts[-1]['minimum'] == 10, 'frequency_threshold': attempts[-1]['frequency_threshold'],
        'frequency_policy_sha256': policy['identity_sha256'], 'coarse_records_sha256': 'a' * 64,
        'attempts': attempts, **({'status': 'NOT_ESTIMABLE', 'reason_code': 'FREQUENCY_LADDER_EXHAUSTED'} if terminal else {})}


@pytest.mark.parametrize('authority,tier,accept', [('base', None, True), ('base', 1, True),
    ('base', 2, True), ('base', 3, False), ('current', None, True), ('current', 3, True)])
def test_base_lock_is_limited_to_successful_12_prefix(frequency_one_lock, authority, tier, accept):
    science = n._base_science_decision_template(24) if authority == 'base' else n.science_decision_template(24)
    body = {k: deepcopy(v) for k, v in frequency_one_lock.items() if k != 'identity_sha256'}
    body['science_decision_binding']['science_decision_sha256'] = science['identity_sha256']
    if tier is not None:
        body['epv_resolution'] = _frequency_lock_trace(tier)
    lock = n._sealed(body)
    if accept:
        assert n.validate_development_lock(lock, science_decision=science) == lock
    else:
        with pytest.raises(ContractError, match='NESTED_BASE_SCIENCE_FREQUENCY_POLICY_DRIFT'):
            n.validate_development_lock(lock, science_decision=science)


def test_terminal_trace_cannot_become_a_development_lock(frequency_one_lock):
    body = {k: deepcopy(v) for k, v in frequency_one_lock.items() if k != 'identity_sha256'}
    body['epv_resolution'] = _frequency_lock_trace(6, terminal=True)
    assert n.validate_epv_resolution(body['epv_resolution']) == body['epv_resolution']
    with pytest.raises(ContractError, match='NESTED_SELECTOR_NOT_ESTIMABLE_NO_DEVELOPMENT_LOCK'):
        n.validate_development_lock(n._sealed(body))


def test_same_producer_science_lock_prediction_still_exact(frequency_one_lock):
    base, current = n._base_science_decision_template(24), n.science_decision_template(24)
    body = {k: deepcopy(v) for k, v in frequency_one_lock.items() if k != 'identity_sha256'}
    body['science_decision_binding']['science_decision_sha256'] = base['identity_sha256']
    lock = n._sealed(body)
    with pytest.raises(ContractError, match='NESTED_DEVELOPMENT_LOCK_SCIENCE_DECISION_MISMATCH'):
        n.validate_development_lock(lock, science_decision=current)
    context = _context()
    prediction = n.seal_selected_prediction(lock=lock, patient_ids=context['heldout_ids'],
        centers=['36'] * len(context['heldout_ids']), survival=[[1.] + [.9] * 36] * len(context['heldout_ids']),
        component_receipts=_receipts(lock))
    assert n.validate_selected_prediction(prediction, lock) == prediction
    changed = _frequency_prediction_science(prediction, current)
    with pytest.raises(ContractError, match='NESTED_SELECTED_PREDICTION_LOCK_MISMATCH'):
        n.validate_selected_prediction(changed, lock)


@pytest.mark.parametrize('authority', ['base', 'current', 'foreign', 'h36'])
def test_actual_f4_presearch_guard_exact_base_or_current_24(authority):
    import ast
    import inspect
    from padml import f4
    module = ast.parse(inspect.getsource(f4._compile_o_fit_bundle))
    function = next(node for node in module.body if isinstance(node, ast.FunctionDef) and node.name == '_compile_o_fit_bundle')
    call, = [node for node in ast.walk(function) if isinstance(node, ast.Call)
             and len(node.args) >= 2 and isinstance(node.args[1], ast.Constant)
             and node.args[1].value == 'F4_O_FIT_PRE_SEARCH_SCOPE_INVALID'
             and any(isinstance(part, ast.Attribute) and part.attr == 'validate_science_decision'
                     for part in ast.walk(node.args[0]))]
    science = (n._base_science_decision_template(24) if authority == 'base' else
               n.science_decision_template(36 if authority == 'h36' else 24))
    if authority == 'foreign':
        science = n._sealed({**{k: v for k, v in science.items() if k != 'identity_sha256'}, 'program_id': 'FOREIGN'})
    limits = {'resource_policy': {'fixture': True}, 'retained_bytes_per_component': 4,
              'expanded_bytes_per_component': 8, 'shared_storage_bytes': 32}
    environment = {'nested': n, 'context': {'outer_fold': 1}, 'outer_fold': 1,
        'state': {'projection': {'science_decision': science}}, 'science_decision': n.science_decision_template(24),
        'scoped': limits, 'policy': limits['resource_policy'], **{k: v for k, v in limits.items() if k != 'resource_policy'}}
    expression = compile(ast.Expression(body=call.args[0]), '<actual-f4-presearch-guard>', 'eval')
    if authority in {'foreign', 'h36'}:
        with pytest.raises(ContractError):
            eval(expression, environment)
    else:
        assert eval(expression, environment) is True
