"""Original score-task/engine boundary; stop before native IO or fitting."""
import copy
from pathlib import Path

import pytest

from padml import f4, f5
from padml.bundle import ContractError, canonical_json_bytes, sha256_bytes
from test_f5 import _test_final_design_recipe, _full_test_transform_recipe
from test_nested_full_development import _unfitted_full_lambda_upper


def score_task(family, horizon):
    selected = ['AST_ALT']
    if family == 'COX_PH':
        spec = {'family': family, 'ties': 'breslow'}
    elif family == 'FPM_TVC_SET_A':
        spec = {'family': family, 'df': [3, 1], 'tvc_parent': 'AST_ALT'}
    elif family == 'ELASTIC_NET_COX':
        transform = _full_test_transform_recipe(f5.predictor_contract(Path(f5.__file__).parent))
        transform['partition_id'] = 'F5_FINAL_FULL_DATA'
        transform['recipe_sha256'] = sha256_bytes(canonical_json_bytes({
            k: v for k, v in transform.items() if k != 'recipe_sha256'}))
        spec = {'family': family, 'alpha': 0.2, 'ratio_by_imputation': [0.1] * 20,
            'lambda_by_imputation': [0.2] * 20,
            'lambda_upper_bound_by_imputation': [_unfitted_full_lambda_upper(transform)] * 20}
    else:
        candidate = f5._final_complex_candidate_trials(family)['S1'][0]
        spec = {'family': family, 'candidate_id': candidate.get('candidate_id', candidate.get('trial_id')),
            'parameters': candidate if family == 'COXTIME_SET_A' else candidate['parameters'],
            'selection_metric': f'IBS_0_{horizon}', 'selection_stage': 'S3B2',
            **({'selected_trees': 100} if family == 'GBM_COX' else
               {'selected_rounds': 20} if family == 'XGBOOST_COX' else
               {'locked_epoch': 50} if family == 'COXTIME_SET_A' else {})}
    coordinates = dict(purpose='NESTED_FULL_SCORE', outer_fold=0, repeat=1, inner_fold=1, imputation=1)
    seed = f4._f4_model_seed(family, coordinates)
    source = {key: 'a' * 64 for key in ('training_context_sha256', 'score_development_sha256',
        'selector_development_sha256', 'selector_recipe_set_sha256', 'science_decision_sha256')}
    source.update(kind='PADML_NESTED_FULL_SCORE_SOURCE_V1', program_id=f5._nested_science.PROGRAM_ID,
        selection_horizon_months=horizon, selected_parents_sha256=sha256_bytes(canonical_json_bytes(selected)),
        selected_spec_sha256=sha256_bytes(canonical_json_bytes(spec)))
    task = dict(family=family, selected_parents=selected, parameters=spec, imputation=1,
        f4_coordinates=coordinates, registered_model_seed=seed,
        model_seed=seed if family in {'RSF', 'GBM_COX', 'XGBOOST_COX', 'COXTIME_SET_A'} else None,
        row_count=1, family_design_column_count=1,
        nested_full_score_source=source)
    if family == 'ELASTIC_NET_COX':
        elastic = {key: source[key] for key in ('selector_development_sha256', 'selector_recipe_set_sha256')}
        elastic.update(selected_spec=spec, full_transform_recipe=transform)
        task['f4_nested_full_elastic_source'] = elastic
        task['parameters'], _ = f4._nested_full_elastic_parameters(elastic, coordinates)
    recipe = _test_final_design_recipe(family, selected)
    return task, recipe


@pytest.mark.parametrize('horizon', [6, 12, 24, 36])
@pytest.mark.parametrize('family', f5._nested_science._families())
def test_four_horizon_full_score_native_boundary_accepts_all_seven_families(monkeypatch, family, horizon):
    task, recipe = score_task(family, horizon)
    class NativeBoundary(Exception):
        pass
    observed = []
    def stop(**kwargs):
        observed.append(kwargs)
        raise NativeBoundary('NO_NATIVE_IO_OR_FIT')
    monkeypatch.setattr(f5.tempfile, 'mkdtemp', stop)
    with pytest.raises(NativeBoundary):
        f5._execute_final_refit_engine(family, task, [], {}, recipe)
    assert len(observed) == 1
    for damage in ('seed', 'horizon', 'parameter', 'old_program'):
        altered = copy.deepcopy(task)
        if damage == 'seed': altered['registered_model_seed'] += 1
        elif damage == 'horizon': altered['nested_full_score_source']['selection_horizon_months'] = 0
        elif damage == 'parameter': altered['nested_full_score_source']['selected_spec_sha256'] = '0' * 64
        else: altered['nested_full_score_source']['program_id'] = 'PADML_NESTED_LOCO_20260908'
        with pytest.raises(ContractError):
            f5._execute_final_refit_engine(family, altered, [], {}, recipe)
    assert len(observed) == 1
