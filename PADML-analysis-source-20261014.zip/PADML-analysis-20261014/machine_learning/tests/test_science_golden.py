from __future__ import annotations

import json
import shutil
import subprocess
import tempfile
from pathlib import Path

import pytest

import padml
import padml.f2_validation as f2_validation
from padml._science_authority import load_science_authority, selected_route_profiles
from padml.bundle import (
    ContractError,
    canonical_json_bytes,
    execution_result_contract,
    read_safe_zip,
    science_projection_sha256,
    sha256_bytes,
    validate_envelope,
    write_deterministic_zip,
)
from padml.f2 import canonical_unit_ids, materialize_requests
from padml.f2_kernel import aggregate_confirmation
from padml.f2_validation import (
    _validate_model_row_universe,
    _validate_registered_partition_execution,
    validate_f2_unit_result,
)


def _rscript() -> Path:
    executable = shutil.which("Rscript")
    assert executable is not None
    path = Path(executable).resolve(strict=True)
    assert path.is_file() and not path.is_symlink()
    return path


def _r_definition(source: str, name: str) -> str:
    lines = source.splitlines()
    starts = [index for index, line in enumerate(lines) if line.startswith(f"{name} <- function")]
    assert len(starts) == 1
    result = [lines[starts[0]]]
    balance = result[0].count("{") - result[0].count("}")
    for line in lines[starts[0] + 1 :]:
        if balance <= 0:
            break
        result.append(line)
        balance += line.count("{") - line.count("}")
    assert balance == 0
    return "\n".join(result)


def _requests() -> dict[str, dict[str, object]]:
    return materialize_requests(
        run_id="padml-f2-v1-test",
        source_identity="1" * 64,
        runtime_identity="2" * 64,
        worker_identity="3" * 64,
        input_identity="4" * 64,
    )


def _result_zip(request: dict[str, object], value: dict[str, object], path: Path) -> None:
    payload = canonical_json_bytes(value)
    expected = request["artifacts"][0]
    artifact = {
        **expected,
        "size_bytes": len(payload),
        "sha256": sha256_bytes(payload),
        "status": "OK",
    }
    result = validate_envelope(
        {
            **request,
            "kind": "result",
            "artifacts": [artifact],
            "terminal": {"status": "COMPLETED", "reason_code": "OK", "message_sha256": None},
        }
    )
    write_deterministic_zip(
        path,
        {"manifest.json": canonical_json_bytes(result), artifact["relative_path"]: payload},
    )


def _aggregate_fixture() -> tuple[dict[str, object], list[dict[str, object]], list[dict[str, object]], list[dict[str, object]]]:
    request = _requests()["model-confirmation"]
    requests = _requests()
    model_values = []
    for unit_id in canonical_unit_ids()[:42]:
        coordinates = {row["axis"]: row["value"] for row in requests[unit_id]["plan"]["coordinates"]}
        selected = {
            "fold": coordinates["outer_fold"],
            "family": coordinates["family"],
            "parameters": {},
        }
        model_values.append(
            {
                "fold": coordinates["outer_fold"],
                "family": coordinates["family"],
                "selected_spec": selected,
                "selected_spec_sha256": sha256_bytes(canonical_json_bytes(selected)),
            }
        )
    diagnostic_values = []
    for component in load_science_authority()["science"]["p2c2t"]:
        diagnostic_values.append(
            {
                "component": component,
                "status": "PASS",
                "expected_task_count": 1,
                "executed_task_count": 1,
                "expected_fit_count": 1,
                "executed_fit_count": 1,
                "typed_terminal": "PASS",
                "task_result_set_sha256": sha256_bytes(canonical_json_bytes([component])),
            }
        )
    consumed = [
        {
            "unit_id": unit_id,
            "result_sha256": sha256_bytes(unit_id.encode()),
            "artifact_id": f"{unit_id}.unit_result",
            "artifact_sha256": sha256_bytes(f"artifact:{unit_id}".encode()),
        }
        for unit_id in request["plan"]["depends_on"]
    ]
    return request, model_values, diagnostic_values, consumed


def test_r_and_python_canonical_hash_golden_match() -> None:
    source = (Path(padml.__file__).resolve().parent / "kernels/f2_model_development.R").read_text()
    definitions = [_r_definition(source, name) for name in ("canonical_json", "sha_object")]
    selector = load_science_authority()["science"]["f2_model_development"]["selector_contract"]
    fixtures = {"string_list": ["alpha", "beta"], "selector_contract": selector}
    expected = [
        sha256_bytes(canonical_json_bytes(fixtures["string_list"])),
        sha256_bytes(canonical_json_bytes(selector)),
    ]
    assert expected[0] == "b30e0ba36ef12372de4d4385e1795ef8b561daa37e0bd9927fd2c9caaa7561e4"
    with tempfile.TemporaryDirectory() as temporary:
        root = Path(temporary)
        fixture_path = root / "fixtures.json"
        script_path = root / "hash-contract.R"
        fixture_path.write_bytes(canonical_json_bytes(fixtures))
        script_path.write_text(
            "\n".join(
                [
                    "suppressPackageStartupMessages({ library(jsonlite); library(digest) })",
                    *definitions,
                    "args <- commandArgs(trailingOnly = TRUE)",
                    "fixtures <- fromJSON(args[[1L]], simplifyVector = FALSE)",
                    'cat(sha_object(fixtures$string_list), "\\n", sha_object(fixtures$selector_contract), "\\n", sep = "")',
                ]
            )
            + "\n"
        )
        completed = subprocess.run(
            [str(_rscript()), "--vanilla", str(script_path), str(fixture_path)],
            check=False,
            capture_output=True,
            text=True,
        )
    assert completed.returncode == 0, completed.stderr
    assert completed.stderr == ""
    assert completed.stdout.splitlines() == expected


def test_glmnet5_numeric_sentinel_and_data_driven_upper_bound_golden() -> None:
    source = (Path(padml.__file__).resolve().parent / "kernels/f2_model_development.R").read_text()
    assert "pilot$lambda[[2L]]" not in source
    definitions = [
        _r_definition(source, name)
        for name in (
            "fail",
            "need",
            "scalar",
            "canonical_json",
            "sha_object",
            "glmnet_engine_design",
            "validate_cox_lambda_upper_bound",
            "data_driven_cox_lambda_upper_bound",
        )
    ]
    program = "\n".join(
        [
            "suppressPackageStartupMessages({ library(survival); library(glmnet); library(jsonlite); library(digest) })",
            *definitions,
            "n <- 80L",
            "x <- cbind(AST_ALT = seq(-2, 2, length.out = n), X = sin(seq_len(n) / 7))",
            "time <- seq_len(n) + 0.25",
            "event <- as.integer(seq_len(n) %% 3 != 0)",
            "sentinel <- glmnet(x, Surv(time, event), family='cox', cox.ties='breslow', alpha=0.2, nlambda=2L, lambda.min.ratio=0.0001, penalty.factor=c(0,1), standardize=TRUE)",
            "with_unpenalized <- data_driven_cox_lambda_upper_bound(x, time, event, 0.2, c(0, 1))",
            "without_unpenalized <- data_driven_cox_lambda_upper_bound(x, time, event, 0.2, c(1, 1))",
            "single <- matrix(x[, 1], ncol = 1L, dimnames = list(NULL, 'AST_ALT'))",
            "engine <- glmnet_engine_design(single, single, 0)",
            "mechanical <- glmnet(engine$train, Surv(time, event), family='cox', cox.ties='breslow', alpha=0.2, lambda=1, penalty.factor=engine$penalty, standardize=TRUE)",
            "tampered <- with_unpenalized",
            "tampered$resolved_lambda_max <- tampered$pilot_lambda_head[[2L]]",
            "shortcut_error <- tryCatch({ validate_cox_lambda_upper_bound(tampered, 0.2); 'NO_ERROR' }, error=conditionMessage)",
            "cat(toJSON(list(version=as.character(packageVersion('glmnet')), sentinel=as.list(as.numeric(sentinel$lambda)), big=as.numeric(glmnet.control()$big), with_unpenalized=with_unpenalized, without_unpenalized=without_unpenalized, inert_column=engine$inert_column, inert_coefficient=as.numeric(as.matrix(coef(mechanical, s=1))[engine$inert_column,,drop=FALSE]), shortcut_error=shortcut_error), auto_unbox=TRUE, digits=17))",
        ]
    )
    completed = subprocess.run(
        [str(_rscript()), "--vanilla", "-e", program],
        check=False,
        capture_output=True,
        text=True,
    )
    assert completed.returncode == 0, completed.stderr
    observed = json.loads(completed.stdout)
    assert observed["version"] == "5.0"
    assert len(observed["sentinel"]) == 2
    assert observed["sentinel"][0] == observed["big"]
    assert observed["big"] > 1e30
    for key in ("with_unpenalized", "without_unpenalized"):
        row = observed[key]
        assert row["glmnet_version"] == "5.0"
        assert row["pilot_returned_nlambda"] >= 3
        assert row["resolved_lambda_max"] < 1e30
        assert row["sentinel_equivalent"] is False
        assert row["resolved_lambda_max"] == row["pilot_lambda_head"][0]
    assert observed["shortcut_error"] == "F2_ELASTIC_LAMBDA_SENTINEL_INVALID"
    assert observed["inert_column"] == "PADML_GLMNET_INERT_ZERO"
    assert observed["inert_coefficient"] == 0


def test_aggregate_and_sole_validator_accept_golden_and_reject_wrong_bytes() -> None:
    request, model_values, diagnostic_values, consumed = _aggregate_fixture()
    value = aggregate_confirmation(model_values, diagnostic_values, consumed)
    value.update(execution_result_contract(request["plan"]))
    value["consumed_sources"] = consumed
    admitted_values = {
        **{
            unit_id: model_values[index]
            for index, unit_id in enumerate(request["plan"]["depends_on"][:42])
        },
        **{
            unit_id: diagnostic_values[index]
            for index, unit_id in enumerate(request["plan"]["depends_on"][42:])
        },
    }
    with tempfile.TemporaryDirectory() as temporary:
        root = Path(temporary).resolve()
        path = root / "result.zip"
        _result_zip(request, value, path)
        validated = validate_f2_unit_result(
            request,
            path,
            load_science_authority(),
            route_profiles=selected_route_profiles(),
            admitted_sources={row["unit_id"]: row for row in consumed},
            admitted_values=admitted_values,
            authority_mode="LOCAL_SOLE_VALIDATOR",
        )
        entries = read_safe_zip(path.read_bytes())
        wrong = root / "wrong-manifest.zip"
        write_deterministic_zip(wrong, {**entries, "manifest.json": b" " + entries["manifest.json"]})
        with pytest.raises(ContractError, match="F2_UNIT_RESULT_MANIFEST_NONCANONICAL"):
            validate_f2_unit_result(
                request,
                wrong,
                load_science_authority(),
                route_profiles=selected_route_profiles(),
                admitted_sources={row["unit_id"]: row for row in consumed},
                admitted_values=admitted_values,
                authority_mode="LOCAL_SOLE_VALIDATOR",
            )
    assert validated["status"] == "PASS"
    assert validated["science_projection_sha256"] == science_projection_sha256(validated["value"])
    assert validated["value"]["model_result_count"] == 42
    broken_diagnostics = json.loads(json.dumps(diagnostic_values))
    broken_diagnostics[0]["executed_task_count"] = 0
    with pytest.raises(ContractError, match="F2_CONFIRMATION_DIAGNOSTIC_RESULT_INVALID"):
        aggregate_confirmation(model_values, broken_diagnostics, consumed)


def test_completed_model_and_p2c2t_receive_exact_capsule_route_map(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    authority = load_science_authority()
    routes = selected_route_profiles()
    requests = _requests()
    observed: list[tuple[str, dict[str, object]]] = []

    def validate_model(
        request: dict[str, object],
        value: dict[str, object],
        authority_slice: dict[str, object],
        route_profiles: dict[str, object],
        expected_model_input: dict[str, object] | None,
        local_f1_response: dict[str, object] | None,
        expected_selector_search: dict[str, object] | None = None,
        expected_selector_primary: dict[str, object] | None = None,
        expected_selector_result: dict[str, object] | None = None,
    ) -> None:
        del request, value, authority_slice, expected_model_input, local_f1_response
        assert expected_selector_search is None and expected_selector_primary is None and expected_selector_result is None
        observed.append(("MODEL_DEVELOPMENT", route_profiles))

    def validate_p2c2t(
        request: dict[str, object],
        value: dict[str, object],
        component: str,
        authority_slice: dict[str, object],
        route_profiles: dict[str, object],
        admitted_values: dict[str, dict[str, object]],
    ) -> None:
        del request, value, component, authority_slice, admitted_values
        observed.append(("P2C2T", route_profiles))

    monkeypatch.setattr(f2_validation, "_validate_f2_model", validate_model)
    monkeypatch.setattr(f2_validation, "_validate_f2_p2c2t", validate_p2c2t)
    model_request = requests[canonical_unit_ids()[0]]
    p2c2t_request = requests[canonical_unit_ids()[42]]
    sources = {
        unit_id: {
            "unit_id": unit_id,
            "result_sha256": sha256_bytes(f"result:{unit_id}".encode()),
            "artifact_id": f"{unit_id}.unit_result",
            "artifact_sha256": sha256_bytes(f"artifact:{unit_id}".encode()),
        }
        for unit_id in p2c2t_request["plan"]["depends_on"]
    }
    with tempfile.TemporaryDirectory() as temporary:
        root = Path(temporary).resolve()
        model_path = root / "model.zip"
        diagnostic_path = root / "p2c2t.zip"
        _result_zip(model_request, {"consumed_sources": []}, model_path)
        _result_zip(
            p2c2t_request,
            {"consumed_sources": list(sources.values())},
            diagnostic_path,
        )
        assert validate_f2_unit_result(
            model_request,
            model_path,
            authority,
            route_profiles=routes,
            authority_mode="REMOTE_CANDIDATE",
        )["status"] == "CANDIDATE_VALID"
        assert validate_f2_unit_result(
            p2c2t_request,
            diagnostic_path,
            authority,
            route_profiles=routes,
            admitted_sources=sources,
            admitted_values={unit_id: {} for unit_id in sources},
            authority_mode="REMOTE_CANDIDATE",
        )["status"] == "CANDIDATE_VALID"

        altered_routes = json.loads(json.dumps(routes))
        altered_routes["COX_PH"]["profile"]["pool_workers"] = 23
        with pytest.raises(ContractError, match="F2_ROUTE_PROFILE_MAP_INVALID"):
            validate_f2_unit_result(
                model_request,
                model_path,
                authority,
                route_profiles=altered_routes,
                authority_mode="REMOTE_CANDIDATE",
            )

    assert observed == [
        ("MODEL_DEVELOPMENT", routes),
        ("P2C2T", routes),
    ]


def test_noncompleted_candidate_has_no_validator_evidence() -> None:
    request = _requests()[canonical_unit_ids()[0]]
    reason = "CAPABILITY_UNAVAILABLE"
    result = validate_envelope(
        {
            **request,
            "kind": "result",
            "artifacts": [],
            "terminal": {
                "status": "BLOCKED",
                "reason_code": reason,
                "message_sha256": sha256_bytes(reason.encode()),
            },
        }
    )
    with tempfile.TemporaryDirectory() as temporary:
        path = Path(temporary).resolve() / "blocked.zip"
        write_deterministic_zip(path, {"manifest.json": canonical_json_bytes(result)})
        validated = validate_f2_unit_result(
            request,
            path,
            load_science_authority(),
            route_profiles=selected_route_profiles(),
            authority_mode="LOCAL_SOLE_VALIDATOR",
        )
    assert validated["status"] == "NONCOMPLETED"
    assert validated["evidence"] is None


def _registered_outer_fixture() -> tuple[dict[str, object], dict[str, object]]:
    outer = {
        "kind": "OUTER",
        "partition_id": "OUTER_F1",
        "repeat": 0,
        "inner_fold": 0,
        "fit_count": 12,
        "evaluation_count": 40,
        "fit_ids_sha256": "a" * 64,
        "evaluation_ids_sha256": "b" * 64,
    }
    prediction_sha256 = "c" * 64
    metric = 0.125
    partition = {
        "kind": "OUTER",
        "partition_id": "OUTER_F1",
        "repeat": 0,
        "inner_fold": 0,
        "purpose": "FINAL_EVALUATION",
        "input_record_sha256": sha256_bytes(canonical_json_bytes(outer)),
        "prediction_seal_count": 20,
        "evaluation_count": 1,
        "evaluation_response_sha256": "d" * 64,
        "evaluation_ids_sha256": "b" * 64,
        "prediction_seal_set_sha256": "e" * 64,
        "metric_set_sha256": sha256_bytes(canonical_json_bytes([metric])),
        "final_prediction_seal_sha256": prediction_sha256,
        "metric_prediction_seal_sha256": "9" * 64,
        "ibs_0_24": metric,
        "metric_qc": {
            "censoring_model": "EVALUATION_CENTER_STRATIFIED_KM",
            "evaluation_count": 40,
            "minimum_g": 1.0,
            "minimum_effective_sample_size": 40.0,
            "maximum_weight": 1.0,
            "positive_weight_quantiles": [1.0] * 5,
            "truncation_applied": False,
            "metric_estimable": True,
        },
    }
    execution = {
        "schema_version": "1.0.0",
        "kind": "PADML_F2_REGISTERED_PARTITION_EXECUTION",
        "fold": 1,
        "family": "FPM_TVC_SET_A",
        "registered_input_identity": "f" * 64,
        "expected_partition_count": 1,
        "executed_partition_count": 1,
        "partitions": [partition],
    }
    execution["identity"] = sha256_bytes(canonical_json_bytes(execution))
    expected_input = {
        "model_partitions": [outer],
        "diagnostic_partitions": [],
    }
    row_universe = {
        "training_count": 12,
        "heldout_count": 40,
        "training_ids_sha256": "a" * 64,
        "heldout_ids_sha256": "b" * 64,
        "overlap_count": 0,
    }
    value = {
        "lineage": {"f1_registered_partition_identity": "f" * 64},
        "prediction_sha256": prediction_sha256,
        "monthly_oof_sha256": "9" * 64,
        "row_universe": row_universe,
        "row_universe_sha256": sha256_bytes(canonical_json_bytes(row_universe)),
        "registered_partition_execution": execution,
    }
    return value, expected_input


def test_registered_execution_and_row_universe_are_capsule_bound() -> None:
    value, expected_input = _registered_outer_fixture()
    final = _validate_registered_partition_execution(
        value, 1, "FPM_TVC_SET_A", expected_input
    )
    assert final["partition_id"] == "OUTER_F1"
    assert _validate_model_row_universe(value, expected_input) == value["row_universe"]

    tampered_execution = json.loads(json.dumps(value))
    execution = tampered_execution["registered_partition_execution"]
    execution["partitions"][0]["input_record_sha256"] = "0" * 64
    execution["identity"] = sha256_bytes(
        canonical_json_bytes(
            {key: item for key, item in execution.items() if key != "identity"}
        )
    )
    with pytest.raises(
        ContractError, match="F2_REGISTERED_EXECUTION_INPUT_RECORD_MISMATCH"
    ):
        _validate_registered_partition_execution(
            tampered_execution, 1, "FPM_TVC_SET_A", expected_input
        )

    tampered_universe = json.loads(json.dumps(value))
    tampered_universe["row_universe"]["training_ids_sha256"] = "0" * 64
    tampered_universe["row_universe_sha256"] = sha256_bytes(
        canonical_json_bytes(tampered_universe["row_universe"])
    )
    with pytest.raises(ContractError, match="F2_MODEL_ROW_UNIVERSE_INVALID"):
        _validate_model_row_universe(tampered_universe, expected_input)


def test_local_model_validation_requires_f1_response_replay() -> None:
    request = _requests()[canonical_unit_ids()[0]]
    with tempfile.TemporaryDirectory() as temporary:
        path = Path(temporary).resolve() / "model.zip"
        _result_zip(request, {}, path)
        with pytest.raises(
            ContractError, match="F2_LOCAL_MODEL_RESPONSE_REPLAY_REQUIRED"
        ):
            validate_f2_unit_result(
                request,
                path,
                load_science_authority(),
                route_profiles=selected_route_profiles(),
                expected_model_input={},
                authority_mode="LOCAL_SOLE_VALIDATOR",
            )
