"""Review-only proposed addition to test_full0_gbm_history_source_scope.py.

Run on the authorized Linux evidence custodian only. No scientific consumer
worker is executed. All environment paths must already be attributable inputs.
"""
import os
import subprocess
import sys
from pathlib import Path

import pytest

from padml import f4, f5, runtime, f2_kernel as kernel
from padml.bundle import canonical_json_bytes, sha256_bytes, sha256_file, strict_json_bytes

OLD_STOP = "5c30305f8279acc7407bffc1b9d2d09cb1d100f819f69d4e7486c131c8bee5df"


def test_actual_full0_stop_loader_child(tmp_path, monkeypatch):
    destination = os.environ.get("PADML_FULL0_GBM_LOADER_CAPTURE")
    if destination is None:
        pytest.skip("private original-source loader child")
    assert sys.platform.startswith("linux")
    assert sha256_bytes(canonical_json_bytes(f4._f45_source_member_sha256())) == OLD_STOP
    destination = Path(destination)
    assert destination.is_dir() and not (destination / "capture.json").exists()
    class Captured(Exception):
        pass
    def capture(function, units, root, control, phase, input_ref, **kwargs):
        assert function is kernel._run_r_prediction_pool_task and len(units) == 140
        raw = canonical_json_bytes({"source_identity": OLD_STOP, "phase": phase,
            "input": input_ref, "input_path": str(root / "input.json"),
            "resource_policy": control["resource_policy"],
            "calls": [task for task, native in units.values()]})
        with (destination / "capture.json").open("xb") as handle:
            handle.write(raw)
        raise Captured
    monkeypatch.setattr(f5, "_execute_q_search_batch", capture)
    phase, ids = f5._a12_q_stop_phase("S1", family="GBM_COX")
    with pytest.raises(Captured):
        f5._execute_a12_prepared_q_batch(
            Path(os.environ["PADML_FULL0_GBM_READ_STOP_ARCHIVE"]), destination / "loader",
            expected_sha256="861d56cf8ef454425bd5cce0123766325eb278c51347a03d2a22bf1b7f218631",
            task_ids=ids, batch_root=destination / "never-scientific-batch",
            retained_bytes_per_task=256 * 1024**2, full0_only=True,
            selection_horizon_months=24, expected_family="GBM_COX")
    assert not (destination / "never-scientific-batch").exists()


@pytest.mark.parametrize("refit,count,archive_sha", [
    (False, 140, "861d56cf8ef454425bd5cce0123766325eb278c51347a03d2a22bf1b7f218631"),
    (True, 70, "83489f2059338e005f292935846d555036229c1a25b93fbea343ac62077b96cc"),
])
def test_actual_full0_gbm_prefix_reaches_numbers_spawn_without_science(
        tmp_path, monkeypatch, refit, count, archive_sha):
    def supplied(name):
        value = os.environ.get("PADML_FULL0_GBM_READ_" + name)
        if value is None:
            pytest.skip("actual historical input missing: " + name)
        path = Path(value)
        assert path.is_absolute() and path.exists() and not path.is_symlink()
        assert path.resolve(strict=True) == path
        return path

    sources = {role: supplied(role.upper() + "_SOURCE")
               for role in ("stop", "publisher", "refit")}
    # Every host needs only three original execution.json metadata files.
    # Numerical files remain on their phase's custodian: H5 STOP, H0 REFIT.
    metadata = supplied("METADATA")
    batches = [metadata / name for name in ("stop24", "stop116", "refit70")]
    local_batches = ([supplied("REFIT70")] if refit else
                     [supplied("STOP24"), supplied("STOP116")])
    archive = supplied("REFIT_ARCHIVE" if refit else "STOP_ARCHIVE")
    # The STOP input publisher is 5c303, not its e751 model executor.
    input_publisher = sources["publisher"] if refit else supplied("STOP_INPUT_SOURCE")
    assert sha256_file(archive) == archive_sha
    original_receipts = [(batch / "execution.json").read_bytes() for batch in batches]
    phase, ids = f5._a12_q_stop_phase("S1", refit=refit, family="GBM_COX")
    assert len(ids) == count
    suffix = tmp_path / "unused-suffix"
    suffix.mkdir()
    observed = []

    class ReachedNumbersSpawn(Exception):
        pass

    def stop_before_numbers(function, calls, *, selected_slots, **kwargs):
        assert function is kernel._run_r_prediction_pool_task
        assert selected_slots > 0 and len(calls) == count
        assert list(f5._q_search_units(function, calls)) == ids
        assert all(call[5] == ("IBS" if refit else "GROUPED_COX_LOCK")
                   and call[0]["native_search_numbers"] is True
                   and call[0]["native_search_replay"] is True for call in calls)
        assert all(("gbm_stop_loss_references" in call[0]) is (not refit)
                   for call in calls)
        observed.append(len(calls))
        raise ReachedNumbersSpawn

    def read_instead_of_produce(function, units, root, producer_control,
                                actual_phase, input_ref, **kwargs):
        # Sole loader-to-reader test adapter: the production loader has no
        # standalone return of these validated calls. Never run its executor.
        assert function is kernel._run_r_prediction_pool_task
        assert actual_phase == phase and list(units) == ids
        q = strict_json_bytes((root / "input.json").read_bytes())
        phases = {}
        control = f5._q_search_batch_control(root, producer_control["resource_policy"],
            {"prepare_only": True, "task_ids": None, "batch_root": None,
             "q_batches": batches, "retained_bytes_per_task": 256 * 1024**2},
            retained_q_producer_source_bundle=sources,
            continuous_batch_root=suffix, full0_continuous_phase_task_ids=phases)
        assert control["execution_worker_memory_bytes"] == 2 * 1024**3
        assert control["execution_scratch_reserve_bytes"] == 0
        historical = {sha256_bytes(canonical_json_bytes(record)): record
                      for path, record in control["batches"] if record["phase"] == phase}
        assert len(historical) == len(local_batches)
        selected = []
        seen = set()
        for path in local_batches:
            raw = (path / "execution.json").read_bytes()
            digest = sha256_bytes(raw)
            assert digest in historical and digest not in seen
            seen.add(digest)
            record = historical[digest]
            assert raw == canonical_json_bytes(record)
            selected.append((path, record))
        assert seen == set(historical)
        assert sum(len(record["task_ids"]) for _, record in selected) == count
        (root / "native").mkdir(exist_ok=True)
        spec = {**q["spec"], "native_search_root": str(root / "native"),
                "native_search_batch": control}
        before = (list(control["used_batches"]), control["confirmed_model_fits"],
                  control["confirmed_stop_fits"])
        try:
            f5._consume_q_search_batches(spec, function, units, selected, phase, input_ref)
        finally:
            assert (control["used_batches"], control["confirmed_model_fits"],
                    control["confirmed_stop_fits"]) == before

    monkeypatch.setattr(f5, "_execute_q_search_batch", read_instead_of_produce)
    monkeypatch.setattr(f5, "_bounded_ordered_spawn", stop_before_numbers)
    with pytest.raises(ReachedNumbersSpawn):
        if refit:
            f5._execute_a12_prepared_q_batch(archive, tmp_path / "reader",
                expected_sha256=archive_sha, task_ids=ids,
                batch_root=tmp_path / "never-created-scientific-batch",
                retained_bytes_per_task=256 * 1024**2,
                prepared_source_bundle=input_publisher, full0_only=True,
                selection_horizon_months=24, expected_family="GBM_COX")
        else:
            # Current engineering child admission is separate from the old
            # loader's unchanged historical production-policy checks.
            policy = strict_json_bytes(original_receipts[0])["resource_policy"]
            runtime.resource_admission({**policy,
                "configured_worker_ceiling": runtime.CPU_MINUS_8,
                "memory_bytes_per_worker": 2 * 1024**3,
                "scratch_reserve_bytes": 0},
                runtime.observe_execution_resources(tmp_path), legal_tasks=1)
            manifest = f4.load_f45_source_bundle(input_publisher)
            members = {row["path"]: row["sha256"] for row in manifest["members"]}
            assert sha256_bytes(canonical_json_bytes(members)) == OLD_STOP
            old_root = supplied("STOP_SOURCE_ROOT")
            assert all((old_root / name).is_file()
                       and not (old_root / name).is_symlink()
                       and sha256_file(old_root / name) == digest
                       for name, digest in members.items())
            destination = tmp_path / "old-capture"
            destination.mkdir()
            env = dict(os.environ)
            env["PYTHONPATH"] = os.pathsep.join((str(old_root), str(Path(__file__).parent)))
            env["PADML_FULL0_GBM_LOADER_CAPTURE"] = str(destination)
            child = subprocess.run([sys.executable, "-B", "-m", "pytest", "-q",
                str(Path(__file__).resolve()) + "::test_actual_full0_stop_loader_child",
                "--basetemp=" + str(tmp_path / "child-pytest")], cwd=old_root,
                env=env, capture_output=True, text=True, check=False)
            assert child.returncode == 0, child.stdout + child.stderr
            captured = strict_json_bytes((destination / "capture.json").read_bytes())
            assert captured["source_identity"] == OLD_STOP and captured["phase"] == phase
            units = f5._q_search_units(kernel._run_r_prediction_pool_task, captured["calls"])
            read_instead_of_produce(kernel._run_r_prediction_pool_task, units,
                Path(captured["input_path"]).parent,
                {"resource_policy": captured["resource_policy"]}, phase, captured["input"])
    assert observed == [count]
    assert not (tmp_path / "never-created-scientific-batch").exists()
    assert [(batch / "execution.json").read_bytes() for batch in batches] == original_receipts
