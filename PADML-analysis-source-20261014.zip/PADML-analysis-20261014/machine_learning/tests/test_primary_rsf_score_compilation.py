"""Original outer compiler consumes Q parameters without replacing F2 data."""
import copy
import csv
import io
from pathlib import Path

import pytest

from padml import f4, f5, f2_kernel as kernel, nested_loco as nested
from padml.bundle import ContractError, canonical_json_bytes, strict_json_bytes
from test_f5 import _executed_rsf_search_archive
from test_nested_aar_mice import aar_source, _projected_outer_fixture  # noqa: F401
from test_nested_full_development import _unfitted_confirmed_decision


@pytest.mark.parametrize("damage", ["program", "preprocessing", "training-response", "mice", "seed"])
def test_retained_q_rejects_unproved_current_score_context(damage):
    """Keep scientific drift rejection while adding old-producer transport.

    Reuse an explicitly supplied UNFITTED compiled input; no search, component
    compilation or engine execution is needed for this direct-consumer edge.
    """
    import os
    import zipfile
    from pathlib import Path

    location = os.environ.get("PADML_UNFITTED_SCORE_XGBOOST_COX")
    if location is None:
        pytest.skip("requires retained UNFITTED scoring input")
    archive = Path(location)
    original = f4.sha256_file(archive)
    with zipfile.ZipFile(archive) as source:
        info = source.getinfo("o-fit-input.json")
        assert 0 < info.file_size <= 32 * 1024**2
        value = strict_json_bytes(source.read(info))
    context = value["training_context"]
    searches = value["primary_searches"]
    options = dict(outer=context["outer_fold"], science_decision=value["science_decision"])
    assert nested._validate_outer_primary_searches(searches, context=context, **options) == searches
    field = {"program": "modeling_program_sha256", "preprocessing": "preprocessing_program_sha256",
             "training-response": "training_response_sha256", "mice": "mice_member_set_sha256",
             "seed": "seed_program_sha256"}[damage]
    replacement = (nested._sha(f4._f45_source_member_sha256()) if damage == "program" else "0" * 64)
    assert replacement != context[field]
    changed = nested._sealed({**{key: item for key, item in context.items() if key != "identity_sha256"},
                              field: replacement})
    with pytest.raises(ContractError, match="NESTED_PRIMARY12_SEARCH_TRAINING_DRIFT"):
        nested._validate_outer_primary_searches(searches, context=changed, **options)
    assert f4.sha256_file(archive) == original


def test_retained_primary12_templates_reach_original_lock_and_final(tmp_path, monkeypatch):
    """Use retained compiled templates, synthetic scores/engines, real M20 consumer."""
    import os
    import zipfile
    from pathlib import Path
    from padml import runtime
    from test_nested_loco import _summary
    from test_nested_full_score import _unfitted_score_shard_engines

    location = os.environ.get("PADML_UNFITTED_PRIMARY12_POSTLOCK_INPUT")
    if location is None:
        pytest.skip("requires retained UNFITTED PRIMARY12 scoring input")
    source = Path(location)
    original = f4.sha256_file(source)
    root = tmp_path / "UNFITTED-final"
    root.mkdir()
    scores = []
    with zipfile.ZipFile(source) as archive:
        request = strict_json_bytes(archive.read("o-fit-input.json"))
        assert request["selection_horizon_months"] == 12
        for family in nested._families():
            records = [row for row in request["post_lock_templates"] if row["family"] == family]
            assert len(records) == 20
            for row in records:
                raw = archive.read(row["path"])
                assert f4.sha256_bytes(raw) == row["sha256"] and len(raw) == row["size_bytes"]
                if family == "RSF":
                    target = root / "request" / row["path"]
                    target.parent.mkdir(parents=True, exist_ok=True)
                    target.write_bytes(raw)
            with zipfile.ZipFile(io.BytesIO(archive.read(records[0]["path"]))) as component:
                task = strict_json_bytes(component.read("task.json"))
            scores.append(nested.seal_fresh_training_score(family=family, outer_fold=1,
                training_context_sha256=request["training_context"]["identity_sha256"],
                selected_spec=task["parameters"], selector_evidence_sha256=request["selector_evidence_sha256"],
                summary={**_summary(.1 if family == "RSF" else .2), "selection_horizon_months": 12},
                execution_evidence_sha256="e" * 64, selection_horizon_months=12,
                science_decision_sha256=request["science_decision"]["identity_sha256"]))
    evidence = {"training_scores": scores, "family_decision": nested.select_training_family(scores)}
    calls = _unfitted_score_shard_engines(monkeypatch)
    monkeypatch.setattr(f4, "_bounded_ordered_spawn", runtime._bounded_ordered_spawn)
    monkeypatch.setattr(runtime, "effective_cpu_count", lambda: 32)
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda root: {
        "effective_cpus": 32, "available_memory_bytes": 10**12,
        "scratch_available_bytes": 10**12, "scratch_root": str(root)})
    prepared = f4._o_fit_post_lock_m20(request, evidence, root, workers=24, replay=False, prepare_only=True)
    lock = prepared["development_lock"]
    assert not calls and lock["selection_horizon_months"] == 12 and lock["selected_family"] == "RSF"
    assert lock["selected_spec"] == request["primary_searches"]["RSF"]["result"]["selected_spec"]
    final = f4._o_fit_post_lock_m20(request, evidence, root, workers=24, replay=False)
    assert final["development_lock"] == lock and len(final["component_receipts"]) == 20
    assert final["selected_prediction"]["patient_ids"] == request["training_context"]["heldout_ids"]
    assert f4.sha256_file(source) == original


def _unfitted_search(family):
    """Synthetic trace arithmetic only; never native or scientific acceptance."""
    archive, candidates = _executed_rsf_search_archive({}, {"identity_sha256": "a" * 64}, {"lock_sha256": "b" * 64})
    result = archive["result"]
    if family == "RSF":
        return result, candidates
    counts, units = {"GBM_COX": ([28, 10, 3, 2, 1], 1140),
                     "XGBOOST_COX": ([40, 14, 3, 2, 1], 1300),
                     "COXTIME_SET_A": ([12, 4, 2, 2, 1], 810)}[family]
    parameters = {
        "GBM_COX": {"interaction.depth": 2, "shrinkage": .05, "n.minobsinnode": 20,
                    "bag.fraction": .8, "n.trees.max": 5000, "early_stopping_metric": "cox_deviance",
                    "post_selection_refit": "full_main_training_at_selected_n_trees",
                    "locked_iteration_mode": "full_main_training_without_reselection"},
        "XGBOOST_COX": {"eta": .05, "max_depth": 2, "min_child_weight": 2., "subsample": .8,
                        "colsample_bytree": .8, "reg_lambda": 1., "reg_alpha": 0., "gamma": 0.,
                        "tree_method": "hist", "max_bin": 256, "max_nrounds": 20,
                        "stop_scope": "training_only", "post_selection_refit": "full_main_training_at_best_rounds",
                        "locked_iteration_mode": "full_main_training_without_reselection"},
    }
    if family == "COXTIME_SET_A":
        candidates = {"S1": copy.deepcopy(f5.load_science_authority()["science"][
            "f2_model_development"]["coxtime"]["candidates"])}
        stream = [(row["candidate_id"], row) for row in candidates["S1"]]
        streams = [stream, stream[:4], stream[:2], stream[:2], stream[:1]]
        selected_field, trace_field, locked = "locked_epoch", "locked_epoch", 30
    else:
        candidates = {stage: [{"trial_id": f"{family}::SET_A::{stage}::{i:03d}",
            "parameters": copy.deepcopy(parameters[family]), "parameter_sha256": nested._sha(parameters[family])}
            for i in range(1, count + 1)] for stage, count in zip(("S1", "S2"), counts[:2], strict=True)}
        first, second = [[(row["trial_id"], row["parameters"]) for row in candidates[stage]] for stage in ("S1", "S2")]
        streams = [first, second, second[:3], second[:2], second[:1]]
        selected_field, trace_field, locked = (("selected_trees", "selected_trees_median", 20)
            if family == "GBM_COX" else ("selected_rounds", "selected_rounds_median", 5))
    trace = {}
    for stage, stream in zip(result["search_trace"], streams, strict=True):
        prototype = result["search_trace"][stage][0]
        trace[stage] = []
        for i, (candidate_id, params) in enumerate(stream):
            score = .1 + i / 1000
            trace[stage].append({**copy.deepcopy(prototype), "candidate_id": candidate_id,
                "parameters": copy.deepcopy(params), "parameter_sha256": nested._sha(params),
                **{field: [score] * len(prototype[field]) for field in
                   ("metric_values", "fold_metric_values", "ranking_metric_values")},
                "mean_ibs": score, "maximum_ibs": score, trace_field: locked})
    winner = trace["S3B2"][0]
    selected = {**result["selected_spec"], "family": family, "candidate_id": winner["candidate_id"],
                "parameters": copy.deepcopy(winner["parameters"]), selected_field: locked}
    result.update(family=family, candidate_trials_sha256=nested._sha(candidates), selected_spec=selected,
                  search_trace=trace, search_evaluation_unit_count=units,
                  response_free_stopping_fit_count=units, locked_training_refit_count=units,
                  total_search_fit_count=2 * units)
    return result, candidates


@pytest.mark.parametrize("family", ["RSF", "GBM_COX", "XGBOOST_COX", "COXTIME_SET_A"])
@pytest.mark.parametrize("damage", [None, "foreign-family", "foreign-fold", "owner-hash", "owner-hash-parameter", "owner-hash-rehashed"])
def test_original_search_result_producer_reaches_own_primary_consumer(family, damage):
    result, candidates = _unfitted_search(family)
    if damage in {"owner-hash", "owner-hash-parameter", "owner-hash-rehashed"} and family != "COXTIME_SET_A":
        originals = {}
        for rows in candidates.values():
            for row in rows:
                row["parameter_sha256"] = kernel._v20_owner_sha(row["parameters"])
                originals[row["trial_id"]] = row["parameter_sha256"]
        for rows in result["search_trace"].values():
            for row in rows:
                row["parameter_sha256"] = originals[row["candidate_id"]]
    source = {"program_id": nested.PROGRAM_ID, "channel": "PRIMARY", "family": family,
        "outer_fold": 1, "heldout_center": 36, "selection_horizon_months": 12,
        **{key: "a" * 64 for key in ("training_context_sha256", "science_decision_sha256",
            "producer_source_identity", "f1_identity", "f2_acceptance_sha256",
            "accepted_rsf_result_sha256" if family == "RSF" else "accepted_model_result_sha256",
            "selector_evidence_sha256", "selector_recipe_set_sha256")}}
    spec = {"family": family, "fold": 1, "heldout_center": 36,
        "execution_scope": "F2_OUTER_DEVELOPMENT", "selection_horizon_months": 12,
        "primary_search_source": source, "candidate_trials": candidates, "seed": 301000,
        "trial_scoring": {**f5.load_science_authority()["science"]["f2_model_development"]["trial_scoring"],
            "ibs_grid_months": list(range(13)), "ibs_integration": "TRAPEZOID_DIVIDE_BY_12"},
        "registered_inputs_identity_sha256": result["registered_inputs_identity_sha256"],
        "selector_from_dependency": {"selected_parents": result["selected_parents"]}}
    result["selected_spec"]["selection_metric"] = "IBS_0_12"
    for rows in result["search_trace"].values():
        for row in rows:
            row["selection_horizon_months"] = 12
    if damage in {"foreign-family", "foreign-fold"}:
        source["family" if damage == "foreign-family" else "outer_fold"] = (
            "COX_PH" if damage == "foreign-family" else 2)
        with pytest.raises(ContractError, match="F4_PRIMARY_RSF_SEARCH_SOURCE_INVALID"):
            kernel._shared_full_development_search_result(spec,
                {"identity": spec["registered_inputs_identity_sha256"]},
                result["search_trace"], result["selected_spec"])
        return
    if damage in {"owner-hash-parameter", "owner-hash-rehashed"}:
        result["search_trace"]["S3B2"][0]["parameters"] = {
            **result["search_trace"]["S3B2"][0]["parameters"], "UNFITTED_PARAMETER_DRIFT": True}
        if damage == "owner-hash-rehashed":
            result["search_trace"]["S3B2"][0]["parameter_sha256"] = kernel._v20_owner_sha(
                result["search_trace"]["S3B2"][0]["parameters"])
        with pytest.raises(ContractError, match="F5_COMPLEX_SEARCH_STAGE_DENOMINATOR_INVALID"):
            kernel._shared_full_development_search_result(spec,
                {"identity": spec["registered_inputs_identity_sha256"]},
                result["search_trace"], result["selected_spec"])
        return
    produced = kernel._shared_full_development_search_result(spec,
        {"identity": spec["registered_inputs_identity_sha256"]}, result["search_trace"], result["selected_spec"])
    assert produced == f5._validate_primary_complex_search_result(spec, produced)
    assert produced["primary_search_source"] == source
    assert produced["execution_scope"] == "F2_OUTER_DEVELOPMENT"
    assert produced["total_search_fit_count"] == result["total_search_fit_count"]


@pytest.mark.parametrize("stage", ["S3A", "S3B1", "S3B2"])
def test_original_q_consumer_rejects_changed_promoted_parameters(stage):
    archive, _ = _executed_rsf_search_archive({}, {"identity_sha256": "a" * 64}, {"lock_sha256": "b" * 64})
    result, task = archive["result"], archive["task"]
    assert f5._validate_shared_complex_search_result(result, task) == result
    result["search_trace"][stage][0]["parameters"]["num.trees"] = 500
    if stage == "S3B2":
        result["selected_spec"]["parameters"]["num.trees"] = 500
    result["selected_spec_sha256"] = nested._sha(result["selected_spec"])
    result["search_trace_sha256"] = nested._sha(result["search_trace"])
    result = nested._sealed({k: v for k, v in result.items() if k != "identity_sha256"})
    with pytest.raises(ContractError):
        f5._validate_shared_complex_search_result(result, task)


@pytest.mark.parametrize("kind", ["INNER", "OUTER"])
@pytest.mark.parametrize("family,damage", [("RSF", value) for value in
    (None, "f1", "acceptance", "result", "selector", "recipe", "fold", "no-authority")]
    + [(family, None) for family in ("GBM_COX", "XGBOOST_COX", "COXTIME_SET_A")])
def test_original_component_compiler_keeps_data_and_uses_own_q(
        aar_source, tmp_path, monkeypatch, kind, family, damage):
    _, _, _, _, frozen, _ = _projected_outer_fixture(aar_source, tmp_path, monkeypatch, family)
    result, candidates = _unfitted_search(family)
    model = frozen["models"][1, family]
    old_spec = copy.deepcopy(result["selected_spec"])
    if family == "RSF":
        old_spec["parameters"]["num.trees"] = 500
    else:
        old_spec[{"GBM_COX": "selected_trees", "XGBOOST_COX": "selected_rounds",
                  "COXTIME_SET_A": "locked_epoch"}[family]] += 1
    model.update(selected_spec=old_spec, selected_spec_sha256=nested._sha(old_spec))
    original_model = copy.deepcopy(model)
    frozen["centers"] = {row["Patient_ID"]: row["Center"]
                         for row in csv.DictReader(io.StringIO(frozen["covariates_csv"].decode()))}
    frozen["f1_manifest"] = {"identity": "1" * 64}
    frozen["f2_acceptance_sha256"] = "2" * 64
    frozen["accepted_result_sha256"] = {nested._accepted_result_unit_id(1, family): "3" * 64}
    context = aar_source[3]["primary_training_context"]
    decision = _unfitted_confirmed_decision(fixed_bootstrap=True)
    decision = nested._sealed({**{k: v for k, v in decision.items() if k != "identity_sha256"},
        "twelve_month_development": nested._twelve_month_development_contract()})
    accepted_key = "accepted_rsf_result_sha256" if family == "RSF" else "accepted_model_result_sha256"
    source = {"program_id": nested.PROGRAM_ID, "channel": "PRIMARY", "family": family,
        "outer_fold": 1, "heldout_center": 36, "selection_horizon_months": 12,
        "training_context_sha256": context["identity_sha256"],
        "producer_source_identity": context["modeling_program_sha256"],
        "science_decision_sha256": decision["identity_sha256"], "f1_identity": "1" * 64,
        "f2_acceptance_sha256": "2" * 64, accepted_key: "3" * 64,
        "selector_evidence_sha256": model["selector_evidence_sha256"],
        "selector_recipe_set_sha256": model["selector_evidence"]["recipe_set"]["recipe_set_sha256"]}
    if damage in {"f1", "acceptance", "result", "selector", "recipe"}:
        source[{"f1": "f1_identity", "selector": "selector_evidence_sha256",
                "acceptance": "f2_acceptance_sha256", "result": "accepted_rsf_result_sha256",
                "recipe": "selector_recipe_set_sha256"}[damage]] = "f" * 64
    if damage == "fold": source["outer_fold"] = 5
    spec = {"family": family, "fold": 1, "heldout_center": 36, "execution_scope": "F2_OUTER_DEVELOPMENT",
        "selection_horizon_months": 12, "primary_search_source": source,
        "registered_inputs_identity_sha256": result["registered_inputs_identity_sha256"],
        "candidate_trials": candidates, "seed": 301000,
        "selector_from_dependency": {"selected_parents": model["selector_evidence"]["selected_parents"]}}
    result.update(execution_scope="F2_OUTER_DEVELOPMENT", selection_horizon_months=12,
                  primary_search_source=source, seed_base=301000,
                  selected_parents=model["selector_evidence"]["selected_parents"])
    result["selected_spec"]["selection_metric"] = "IBS_0_12"
    for rows in result["search_trace"].values():
        for row in rows: row["selection_horizon_months"] = 12
    result["selected_spec_sha256"] = nested._sha(result["selected_spec"])
    result["search_trace_sha256"] = nested._sha(result["search_trace"])
    result = nested._sealed({key: value for key, value in result.items() if key != "identity_sha256"})
    q_input = {"kind": "PADML_F5_Q_INPUT_V1", "spec": spec,
        "task": {"kind": "PADML_NESTED_PRIMARY_OUTER_COMPLEX_SEARCH_TASK_V1",
                 "source": source, "training_context": context,
                 "science_decision": _unfitted_confirmed_decision() if damage == "no-authority" else decision}}
    registered = f4._materialize_o_fit_fold(frozen, 1, tmp_path / "UNFITTED-materialized")
    part = f4._o_fit_partitions(registered)[kind, 1 if kind == "INNER" else 0, 1 if kind == "INNER" else 0]
    monkeypatch.setattr(f4, "_execute_f4_model_component", lambda *a, **k: pytest.fail("FIT_FORBIDDEN"))
    monkeypatch.setattr(f4, "_replay_f4_stop_batch", lambda *a, **k: pytest.fail("STOP_FORBIDDEN"))
    kwargs = dict(**{("primary_rsf_search" if family == "RSF" else "primary_search"): (q_input, result)},
                  locked_scoring_decision=decision if kind == "INNER" else None)
    if damage:
        with pytest.raises(ContractError):
            f4._prepare_o_fit_partition(model, part, frozen, **kwargs)
    else:
        jobs = f4._prepare_o_fit_partition(model, part, frozen, **kwargs)
        old_jobs = f4._prepare_o_fit_partition(model, part, frozen,
            locked_scoring_decision=decision if kind == "INNER" else None)
        assert len(jobs) == len(old_jobs) == 20
        for new, old in zip(jobs, old_jobs, strict=True):
            assert {k: v for k, v in new["entries"].items() if k != "task.json"} == {
                k: v for k, v in old["entries"].items() if k != "task.json"}
            task, prior = (strict_json_bytes(row["entries"]["task.json"]) for row in (new, old))
            assert task["parameters"] == result["selected_spec"]
            consumed = f4._f4_native_component_inputs(new["entries"])
            assert consumed[0] == task
            assert consumed[-1] is (kind == "OUTER")
            assert {k: v for k, v in task.items() if k != "parameters"} == {
                k: v for k, v in prior.items() if k != "parameters"}
            assert prior["parameters"] == old_spec and new["name"] == old["name"]
    assert canonical_json_bytes(model) == canonical_json_bytes(original_model)


@pytest.mark.parametrize("missing", [None, "RSF", "GBM_COX", "XGBOOST_COX", "COXTIME_SET_A"])
def test_public_primary12_compiler_never_falls_back_for_missing_family(tmp_path, monkeypatch, missing):
    decision = _unfitted_confirmed_decision(fixed_bootstrap=True)
    decision = nested._sealed({**{k: v for k, v in decision.items() if k != "identity_sha256"},
        "twelve_month_development": nested._twelve_month_development_contract()})
    searches = None if missing is None else {family: {} for family in
        ("RSF", "GBM_COX", "XGBOOST_COX", "COXTIME_SET_A") if family != missing}
    def forbidden(*args, **kwargs):
        pytest.fail("INCOMPLETE_SEARCH_MUST_NOT_READ_OLD_SELECTED_SPEC")
    monkeypatch.setattr(f4, "load_f4_inputs", forbidden)
    monkeypatch.setattr(f4, "_materialize_o_fit_fold", forbidden)
    target = tmp_path / "not-created.zip"
    with pytest.raises(ContractError, match="NESTED_PRIMARY12_COMPLETE_SEARCHES_REQUIRED"):
        f4.compile_o_fit_bundle(tmp_path / "unread-source", target, outer_fold=1,
            science_decision=decision, resource_policy={}, retained_bytes_per_component=1,
            expanded_bytes_per_component=1, shared_storage_bytes=1,
            selection_horizon_months=12, primary_searches=searches)
    assert list(tmp_path.iterdir()) == []


@pytest.mark.parametrize("mode", ["mapping", "roots", "duplicate", "mixed", "proof", "duplicate-proof"])
def test_original_cli_passes_primary12_sources_to_compiler(tmp_path, monkeypatch, capsys, mode):
    import sys
    decision = tmp_path / "decision.json"
    policy = tmp_path / "policy.json"
    sources = tmp_path / "sources.json"
    value = {"UNFITTED_FORWARDING_NOT_ACCEPTANCE": True}
    for path in (decision, policy, sources):
        path.write_bytes(canonical_json_bytes(value))
    calls = []
    def compile_inputs(*args, **kwargs):
        calls.append(kwargs)
        return {"UNFITTED_COMPILER_BOUNDARY": True}
    monkeypatch.setattr(f4, "compile_o_fit_bundle", compile_inputs)
    families = ["RSF", "GBM_COX", "XGBOOST_COX", "COXTIME_SET_A"]
    roots = {family: tmp_path / family for family in families}
    for root in roots.values(): root.mkdir()
    options = ["--primary-searches", str(sources)] if mode == "mapping" else [
        item for family, root in roots.items() for item in ("--primary-search-root", family, str(root))]
    if mode == "duplicate": options[-2] = "RSF"
    if mode == "mixed": options += ["--primary-searches", str(sources)]
    if mode in {"proof", "duplicate-proof"}:
        options += ["--primary-search-source-bundle", "RSF", str(sources)]
    if mode == "duplicate-proof":
        options += ["--primary-search-source-bundle", "RSF", str(sources)]
    monkeypatch.setattr(sys, "argv", ["padml-f4", "o-fit-compile", str(tmp_path), str(tmp_path / "output.zip"),
        "--outer-fold", "1", "--science-decision", str(decision), "--resource-policy", str(policy),
        "--retained-bytes-per-component", "10", "--expanded-bytes-per-component", "20",
        "--shared-storage-bytes", "30", "--selection-horizon-months", "12", *options])
    if mode in {"duplicate", "mixed", "duplicate-proof"}:
        message = ("NESTED_PRIMARY12_SEARCH_SOURCE_PROOF_INVALID" if mode == "duplicate-proof"
                   else "F4_PRIMARY_SEARCH_ROOTS_INVALID")
        with pytest.raises(ContractError, match=message): f4.main()
        assert not calls
        return
    f4.main()
    assert calls[0]["selection_horizon_months"] == 12
    assert calls[0]["primary_searches" if mode == "mapping" else "primary_search_roots"] == (
        value if mode == "mapping" else roots)
    if mode == "proof":
        assert calls[0]["primary_search_source_bundles"] == {"RSF": sources}
    assert strict_json_bytes(capsys.readouterr().out.encode()) == {"UNFITTED_COMPILER_BOUNDARY": True}



def _actual_primary_outer_source(aar_source, tmp_path, monkeypatch):
    """Existing synthetic custody preparation, shared across actual code versions."""
    searches = {family: _unfitted_search(family) for family in ("RSF", "GBM_COX", "XGBOOST_COX", "COXTIME_SET_A")}
    from padml import f2_kernel as kernel
    from test_nested_full_development import _unfitted_full_lambda_upper
    _, _, _, _, frozen, _ = _projected_outer_fixture(aar_source, tmp_path, monkeypatch, "RSF")
    model = frozen["models"][1, "RSF"]
    outer_recipe = next(row for row in model["selector_evidence"]["recipe_set"]["recipes"]
                        if row["partition_id"] == "OUTER_F1")
    model["selector_evidence"]["outer_recipe_sha256"] = outer_recipe["recipe_sha256"]
    specs = {family: copy.deepcopy(result["selected_spec"]) for family, (result, _) in searches.items()}
    for family, spec in specs.items():
        spec["selection_metric"] = "IBS_0_24"
        if family == "RSF":
            spec["parameters"]["num.trees"] = 500
        else:
            spec[{"GBM_COX": "selected_trees", "XGBOOST_COX": "selected_rounds",
                  "COXTIME_SET_A": "locked_epoch"}[family]] += 1
    specs.update(COX_PH={"family": "COX_PH", "ties": "breslow"},
        FPM_TVC_SET_A={"family": "FPM_TVC_SET_A", "df": [3, 1], "tvc_parent": "AST_ALT"},
        ELASTIC_NET_COX={"family": "ELASTIC_NET_COX", "alpha": .2,
            "ratio_by_imputation": [.1] * 20, "lambda_by_imputation": [.2] * 20,
            "lambda_upper_bound_by_imputation": [_unfitted_full_lambda_upper(outer_recipe)] * 20})
    frozen["models"] = {(1, family): {**copy.deepcopy(model), "family": family,
        "selected_spec": spec, "selected_spec_sha256": nested._sha(spec)} for family, spec in specs.items()}
    frozen["model_payload_sizes"] = {key: 1024 for key in frozen["models"]}
    frozen["centers"] = {row["Patient_ID"]: row["Center"]
        for row in csv.DictReader(io.StringIO(frozen["covariates_csv"].decode()))}
    frozen["f1_manifest"] = {"identity": "1" * 64}
    results = tmp_path / "results"
    results.mkdir()
    hashes = {}
    for family in nested._families():
        unit = nested._accepted_result_unit_id(1, family)
        raw = ("UNFITTED_ACCEPTED_SOURCE_LEAF_" + family).encode()
        (results / (unit + ".zip")).write_bytes(raw)
        hashes[unit] = f4.sha256_bytes(raw)
    acceptance = canonical_json_bytes({"status": "SCIENTIFICALLY_ACCEPTED", "result_sha256": hashes})
    (tmp_path / "f2-acceptance.json").write_bytes(acceptance)
    frozen.update(f2_acceptance_sha256=f4.sha256_bytes(acceptance), accepted_result_sha256=hashes)
    original_materialize = f4._materialize_o_fit_fold
    registered = original_materialize(frozen, 1, None)
    registered["identity"] = "c" * 64
    # The accepted F1 reader is a synthetic leaf; supply its registered
    # header as well as physical search views. Diagnostics are not consumed
    # by this zero-fit preparation and are deliberately not fabricated.
    registered.update(schema_version="1.0.0", kind="PADML_F2_REGISTERED_PARTITION_INPUTS", status="PASS", fold=1,
        outer_count=1, inner_count=15, stop_count=15, diagnostic_count=5, view_count=62,
        diagnostic_partitions=[])
    monkeypatch.setattr(f4, "_materialize_o_fit_fold", lambda *a, **k: registered)
    monkeypatch.setattr(f4, "load_f4_inputs", lambda *a, **k: {"o_fit_source": frozen,
        "accepted_result_sha256": hashes, "source": {"f2_acceptance_sha256": frozen["f2_acceptance_sha256"]}})
    part = f4._o_fit_partitions(registered)["OUTER", 0, 0]
    fields, responses = kernel._response_rows(frozen["response_csv"])
    response = kernel._write_response_subset(fields, responses, part["fit_ids"], None)["private_bytes"]
    context = nested.compile_training_context(scope="OUTER", outer_fold=1, heldout_center=36,
        training_ids=part["fit_ids"], heldout_ids=part["evaluation_ids"],
        centers_by_patient={p: frozen["centers"][p] for p in [*part["fit_ids"], *part["evaluation_ids"]]},
        training_response_csv=response, mice_member_set_sha256=nested._sha(part["covariates"]["members"]),
        preprocessing_program_sha256=nested._sha({"predictor_contract": kernel.predictor_contract(Path(f4.__file__).parent),
            "recipe_owner": f4.sha256_file(Path(kernel.__file__))}),
        modeling_program_sha256=nested._sha(f4._f45_source_member_sha256()),
        seed_program_sha256=nested._sha(f5.load_science_authority()["science"]["modeling_seed_policy"]))
    projected = {"science_decision": _unfitted_confirmed_decision(fixed_bootstrap=True),
        "training_context": context, "selector_evidence_sha256": model["selector_evidence_sha256"]}
    return frozen, model, context, projected



@pytest.mark.parametrize("actual_projection,prepare_family,transport_only", [(False, None, False), (True, None, False),
    (True, "GBM_COX", False), (True, "XGBOOST_COX", False), (True, "COXTIME_SET_A", False),
    (True, "XGBOOST_COX", True), (True, "RSF", True)],
    ids=["archive-seam", "original-projection", "prepare-gbm", "prepare-xgb", "prepare-coxtime", "transport-xgb", "transport-rsf"])
def test_primary12_public_archive_preserves_q_through_original_input_reader(aar_source, tmp_path, monkeypatch, actual_projection, prepare_family, transport_only, completed_q_archive=None, retained_q_source=None, partial_s1_history=False, historical_s2=False, continuous_terminal=False, continuous_stop_pair=False):
    # F1/F2 custody and numerical Q leaves are synthetic. The original-projection
    # case retains the real whole-fold projection, compiler and input reader;
    # neither case is proof of historical Q custody or scientific acceptance.
    from padml import runtime
    from test_nested_outer_f4 import _projection
    # The original GBM guard includes three full risk matrices. This synthetic
    # fixture needs at least 34,643,586 bytes before its first STOP can start.
    # Keep production guards and all non-GBM fixture budgets unchanged.
    retention_cap = 64 * 1024**2 if prepare_family == "GBM_COX" else 10**7
    mixed_proof_negatives = []
    execution_projections = []
    original_prepare = f5._prepare_primary_outer_rsf_search
    if continuous_terminal or continuous_stop_pair:
        assert actual_projection and not partial_s1_history
        assert prepare_family == "RSF" if continuous_terminal else prepare_family in {"GBM_COX", "XGBOOST_COX", "COXTIME_SET_A"}
        def capture_projection(projection, *args, **kwargs):
            execution_projections.append(projection)
            return original_prepare(projection, *args, **kwargs)
        monkeypatch.setattr(f5, "_prepare_primary_outer_rsf_search", capture_projection)
    families = ("RSF", "GBM_COX", "XGBOOST_COX", "COXTIME_SET_A")
    searches = {family: _unfitted_search(family) for family in families}
    for result, _ in searches.values():
        result["selected_spec"]["selection_metric"] = "IBS_0_12"
    frozen = None
    if actual_projection:
        if prepare_family == "COXTIME_SET_A":
            # Import the original engine before the fixture forbids subprocesses:
            # h5py's platform discovery may invoke uname, not a scientific job.
            from pycox import models
            import torch
            import torchtuples
        frozen, model, context, projected = _actual_primary_outer_source(aar_source, tmp_path, monkeypatch)
    else:
        projected = _projection(tmp_path / "UNFITTED-projection", fresh_seven=True,
            selected_specs={family: result["selected_spec"] for family, (result, _) in searches.items()})
    decision = nested._sealed({**{k: v for k, v in projected["science_decision"].items() if k != "identity_sha256"},
        "twelve_month_development": nested._twelve_month_development_contract()})
    context = projected["training_context"]
    prior_context = context
    if retained_q_source is not None:
        assert actual_projection and prepare_family is None and completed_q_archive is None
        producer = f4._retained_full0_source_members(retained_q_source, primary_rsf_inputs=True)
        prior_context = nested._sealed({**{key: value for key, value in context.items()
                                          if key != "identity_sha256"},
            "modeling_program_sha256": nested._sha(producer),
            "preprocessing_program_sha256": nested._sha({
                "predictor_contract": kernel.predictor_contract(Path(f4.__file__).parent),
                "recipe_owner": producer["padml/f2_kernel.py"]})})
    bound = {}
    for family, (result, candidates) in searches.items():
        search_context = prior_context if family == "RSF" else context
        source = {"program_id": nested.PROGRAM_ID, "channel": "PRIMARY", "family": family,
            "outer_fold": 1, "heldout_center": 36, "selection_horizon_months": 12,
            "training_context_sha256": search_context["identity_sha256"],
            "producer_source_identity": search_context["modeling_program_sha256"],
            "science_decision_sha256": decision["identity_sha256"],
            "f1_identity": "1" * 64, "f2_acceptance_sha256": "2" * 64,
            ("accepted_rsf_result_sha256" if family == "RSF" else "accepted_model_result_sha256"): "3" * 64,
            "selector_evidence_sha256": projected["selector_evidence_sha256"],
            "selector_recipe_set_sha256": "4" * 64}
        if frozen is not None:
            source["f2_acceptance_sha256"] = frozen["f2_acceptance_sha256"]
            source["accepted_rsf_result_sha256" if family == "RSF" else "accepted_model_result_sha256"] = (
                frozen["accepted_result_sha256"][nested._accepted_result_unit_id(1, family)])
            source["selector_recipe_set_sha256"] = model["selector_evidence"]["recipe_set"]["recipe_set_sha256"]
        spec = {"family": family, "fold": 1, "heldout_center": 36, "execution_scope": "F2_OUTER_DEVELOPMENT",
            "selection_horizon_months": 12, "primary_search_source": source,
            "registered_inputs_identity_sha256": result["registered_inputs_identity_sha256"],
            "candidate_trials": candidates, "seed": 301000,
            "selector_from_dependency": {"selected_parents": ["AST_ALT"]}}
        result.update(execution_scope="F2_OUTER_DEVELOPMENT", selection_horizon_months=12,
                      primary_search_source=source, seed_base=301000)
        if frozen is not None:
            selected = list(model["selector_evidence"]["selected_parents"])
            spec["selector_from_dependency"]["selected_parents"] = selected
            result["selected_parents"] = selected
        for rows in result["search_trace"].values():
            for row in rows:
                row["selection_horizon_months"] = 12
        result["selected_spec_sha256"] = nested._sha(result["selected_spec"])
        result["search_trace_sha256"] = nested._sha(result["search_trace"])
        result = nested._sealed({k: v for k, v in result.items() if k != "identity_sha256"})
        bound[family] = {"input": {"kind": "PADML_F5_Q_INPUT_V1", "spec": spec,
            "task": {"kind": "PADML_NESTED_PRIMARY_OUTER_COMPLEX_SEARCH_TASK_V1", "source": source,
                     "training_context": search_context, "science_decision": decision}}, "result": result}
    projected.update(science_decision=decision, selection_horizon_months=12, primary_searches=bound)
    calls = []
    def projection(**kwargs):
        assert kwargs["selection_horizon_months"] == 12 and kwargs["primary_searches"] == bound
        calls.append("UNFITTED_ACCEPTED_PROJECTION")
        return projected
    if not actual_projection:
        monkeypatch.setattr(nested, "project_outer_development_from_accepted", projection)
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda root: {
        "effective_cpus": 64, "available_memory_bytes": 10**12,
        "scratch_available_bytes": 10**12, "scratch_root": str(root)})
    monkeypatch.setattr(f4, "_execute_f4_model_component", lambda *a, **k: pytest.fail("FIT_FORBIDDEN"))
    policy = {"configured_worker_ceiling": runtime.CPU_MINUS_8, "memory_bytes_per_worker": 2 * 1024**3,
        "memory_reserve_bytes": 0, "scratch_bytes_per_worker": 1, "scratch_reserve_bytes": 0,
        "transfer_archive_worker_ceiling": 8}
    target = tmp_path / "input12.zip"
    if prepare_family is not None:
        original_executor = f5._execute_q_search_batch
        # Lower actual capacity must not change GBM's frozen two-model atoms.
        rsf_profile = 56 if historical_s2 or continuous_terminal == "summary-owner" else 24
        monkeypatch.setattr(f5, "resolve_pool_workers", lambda value: rsf_profile)
        monkeypatch.setattr(f5, "_execute_q_search_batch", lambda *a, **k: pytest.fail("FIT_FORBIDDEN"))
        transported = []
        prepared_calls = []
        original_batch = kernel._search_task_batch
        def checked_batch(spec, function, tasks, **kwargs):
            prepared_calls.append((function, tasks))
            if prepare_family == "RSF":
                return original_batch(spec, function, tasks, **kwargs)
            if prepare_family in {"XGBOOST_COX", "COXTIME_SET_A"}:
                sample = tasks[0]
                before = copy.deepcopy(sample)
                files = {}
                call = f5._a12_q_python_unit_input(function, sample, files=files)
                assert sample == before
                assert not kernel._contains_key(call[0], "evaluation_response")
                assert "evaluation_response" in call[1]
                assert len(files) == 3 and all(name.startswith("data/STOP_F1_") for name in files)
                projected_registered = call[0]["registered"]
                encoded = [call[0]["spec"], {k: v for k, v in projected_registered.items()
                    if k not in {"partitions", "projected_partition_ids"}}, projected_registered["partitions"][0],
                    {k: v for k, v in call[0].items() if k not in {"spec", "registered"}}, call[1]]
                assert f5._a12_q_python_prepared_call(encoded, stop=True) == call
                assert f5._a12_q_python_unit_input(function, call) == call
                for damage in ("seed", "source", "header", "response"):
                    bad = copy.deepcopy(sample)
                    if damage == "seed": bad[0]["seed"] += 1
                    elif damage == "source": bad[0]["spec"]["primary_search_source"]["outer_fold"] = 2
                    elif damage == "header": bad[0]["registered"]["fold"] = 2
                    else: bad[0]["evaluation_response"] = bad[1]["evaluation_response"]
                    with pytest.raises(ContractError):
                        f5._a12_q_python_unit_input(function, bad)
                transported.append(call)
                # Independent REFIT uses its original INNER view, never the
                # STOP preparation. The lock below is explicitly synthetic.
                refit = copy.deepcopy(sample[0])
                refit.pop("handoff_path")
                refit["task_id"] = refit["task_id"].replace("FUNCTION", "LOCKED_REFIT")
                refit["partition_id"] = refit["partition_id"].replace("STOP_", "INNER_")
                refit["registered"] = kernel._engine_registered_partitions(registered, {refit["partition_id"]})
                lock_key = "locked_rounds" if prepare_family == "XGBOOST_COX" else "locked_epoch"
                refit.update(prediction_horizons=list(range(1, 37)), **{lock_key: 2})
                refit_function = (kernel._run_xgb_refit_pool_task if prepare_family == "XGBOOST_COX"
                                  else kernel._run_coxtime_refit_pool_task)
                refit_before, refit_files = copy.deepcopy(refit), {}
                delivered = f5._a12_q_python_unit_input(refit_function, refit, files=refit_files)
                assert refit == refit_before and not kernel._contains_key(delivered, "evaluation_response")
                assert len(refit_files) == 2 and all(name.startswith("data/INNER_F1_") for name in refit_files)
                header = delivered["registered"]
                refit_encoded = [delivered["spec"], {k: v for k, v in header.items()
                    if k not in {"partitions", "projected_partition_ids"}}, header["partitions"][0],
                    {k: v for k, v in delivered.items() if k not in {"spec", "registered"}}]
                assert f5._a12_q_python_prepared_call(refit_encoded, stop=False) == delivered
                assert f5._a12_q_python_unit_input(refit_function, delivered) == delivered
                for bad_lock in (0, 2.0):
                    bad = copy.deepcopy(refit)
                    bad[lock_key] = bad_lock
                    with pytest.raises(ContractError):
                        f5._a12_q_python_unit_input(refit_function, bad)
            else:
                sample = tasks[0]
                before, files = copy.deepcopy(sample), {}
                call = f5._a12_q_stop_unit_input(sample, files=files, function=function)
                assert sample == before and not kernel._contains_key(call[1], "evaluation_response")
                assert "evaluation_response" in call[6]
                assert len(files) == 3 and all(name.startswith("data/STOP_F1_") for name in files)
                assert f5._a12_q_stop_unit_input(call, function=function) == call
                refit = list(copy.deepcopy(sample))
                identifier = sample[2][0]["partition_id"].replace("STOP_", "INNER_")
                next_call = next(row for row in tasks if row[2][0]["task_id"] ==
                    sample[2][0]["task_id"].replace("T001", "T002"))
                refit[2] = copy.deepcopy(sample[2] + next_call[2])
                for row in refit[2]:
                    row.update(task_id=row["task_id"].replace("STOP", "REFIT"), partition_id=identifier,
                        producer_kind="SURVIVAL", prediction_horizons=list(range(1, 37)))
                    row["parameters"]["locked_trees"] = 2  # Synthetic STOP lock.
                refit[0]["horizons"] = list(range(1, 37))
                refit[1] = kernel._engine_registered_partitions(registered, {identifier})
                refit[5] = "IBS"
                refit[6] = next(row for row in registered["partitions"] if row["partition_id"] == identifier)
                before_refit, refit_files = copy.deepcopy(refit), {}
                delivered = f5._a12_q_stop_unit_input(refit, files=refit_files, function=function)
                assert refit == before_refit and not kernel._contains_key(delivered[1], "evaluation_response")
                assert len(refit_files) == 3 and all(name.startswith("data/INNER_F1_") for name in refit_files)
                assert f5._a12_q_stop_unit_input(delivered, function=function) == delivered
                for damage in ("seed", "source", "header", "response"):
                    bad = copy.deepcopy(sample)
                    if damage == "seed": bad[2][0]["seed"] += 1
                    elif damage == "source": bad[0]["primary_search_source"]["outer_fold"] = 2
                    elif damage == "header": bad[1]["fold"] = 2
                    else: bad[1]["evaluation_response"] = bad[6]["evaluation_response"]
                    with pytest.raises(ContractError):
                        f5._a12_q_stop_unit_input(bad, function=function)
            return original_batch(spec, function, tasks, **kwargs)
        monkeypatch.setattr(kernel, "_search_task_batch", checked_batch)
        producer = tmp_path / "current-source.zip"
        f4.compile_f45_source_bundle(producer)
        if prepare_family == "RSF":
            rows = [{"task_id": f"S1_T{trial:03d}_P{part:02d}_M01", "partition_id": str(part), "imputation": 1}
                    for trial in range(1, 25) for part in range(1, 6)]
            expected_ids = ["batch-" + kernel._sha([row["task_id"] for row in group])[:24]
                            for group in kernel._r_prediction_task_batches(rows, rsf_profile)]
        else:
            _, expected_ids = f5._a12_q_stop_phase("S1", family=prepare_family)
        initial_shards = 7 if partial_s1_history or continuous_terminal == "summary-owner" else 2
        outputs = [[str(tmp_path / f"scoped-{index}.zip"), *expected_ids[index::initial_shards]] for index in range(initial_shards)]
        compiled = f4.compile_o_fit_bundle(tmp_path, target, outer_fold=1, science_decision=decision,
            resource_policy=policy, retained_bytes_per_component=retention_cap, expanded_bytes_per_component=10**6,
            shared_storage_bytes=10**9, primary_rsf_prepare=True, primary_prepare_family=prepare_family,
            primary_q_unit_outputs=outputs, primary_producer_source_bundle=producer)
        published_index = compiled.pop("prepared_unit_inputs")
        assert [row["path"] for row in published_index["outputs"]] == [row[0] for row in outputs]
        assert len(prepared_calls) == 1  # No second preparation/funnel invocation.
        from padml.bundle import read_safe_zip
        entries = read_safe_zip(target, expected_members={"input.json", "result.json"})
        q_input, boundary = (strict_json_bytes(entries[name]) for name in ("input.json", "result.json"))
        source = f4._primary_complex_search_source(q_input["spec"])
        assert source == boundary["primary_search_source"]
        assert source["family"] == prepare_family
        assert source["accepted_rsf_result_sha256" if prepare_family == "RSF" else "accepted_model_result_sha256"] == hashes[nested._accepted_result_unit_id(1, prepare_family)]
        assert q_input["task"]["training_context"]["heldout_center"] == 36
        assert compiled["heldout_response_member_count"] == boundary["new_model_fits"] == boundary["new_stop_fits"] == 0
        assert len(boundary["next_atomic_units"]) == {"RSF": (60 if rsf_profile == 56 else 30), "GBM_COX": 140, "XGBOOST_COX": 200, "COXTIME_SET_A": 60}[prepare_family]
        assert boundary["worker_inputs_ready"] is False
        assert len(transported) == (0 if prepare_family in {"RSF", "GBM_COX"} else 1)
        child, atoms = f5._primary_rsf_prepared_input(entries["input.json"], target, producer,
            compilation_receipt=compiled)
        assert child["family"] == prepare_family and child["primary_search_source"] == source
        assert atoms == {row["task_id"]: row["producer_tasks"] for row in boundary["next_atomic_units"]}
        from padml.bundle import write_deterministic_zip, sha256_file, sha256_bytes
        stale = {**compiled, "sha256": "0" * 64}
        with pytest.raises(ContractError):
            f5._primary_rsf_prepared_input(entries["input.json"], target, producer, compilation_receipt=stale)
        for damage in ("seed", "count", "phase", "source"):
            bad = copy.deepcopy(boundary)
            if damage == "seed": bad["next_atomic_units"][0]["producer_tasks"][0]["seed"] += 1
            elif damage == "count": bad["new_model_fits"] = False
            elif damage == "phase": bad["phase"] = "S2"
            else: bad["primary_search_source"]["outer_fold"] = 2
            changed = tmp_path / (damage + "-preparation.zip")
            write_deterministic_zip(changed, {"input.json": entries["input.json"], "result.json": canonical_json_bytes(bad)})
            receipt = {**compiled, **bad, "sha256": sha256_file(changed), "size_bytes": changed.stat().st_size}
            with pytest.raises(ContractError):
                f5._primary_rsf_prepared_input(entries["input.json"], changed, producer, compilation_receipt=receipt)
        with pytest.raises(ContractError):
            f5._primary_rsf_prepared_input(entries["input.json"], target, producer,
                compilation_receipt=compiled, s2_evidence={})
        if prepare_family == "RSF":
            # Reach the original executor after the actual public compiler,
            # projection, scoped ZIP, receipt and physical worker reader.
            # Native execution is forbidden at this engineering seam.
            reached = []
            def rsf_executor(function, units, root, control, phase, input_ref, **kwargs):
                assert function is kernel._run_r_prediction_pool_task
                assert phase == boundary["phase"] and input_ref == boundary["input"]
                assert control["execution_worker_memory_bytes"] == 2 * 1024**3
                assert control["execution_scratch_reserve_bytes"] == 0
                for name, (call, _) in units.items():
                    assert call[2] == atoms[name] and call[0]["primary_search_source"] == source
                    assert not kernel._contains_key(call[1], "evaluation_response")
                    reached.append(name)
                raise f5._QBatchBoundary({"UNFITTED_EXECUTOR_BOUNDARY": True})
            monkeypatch.setattr(f5, "_execute_q_search_batch", rsf_executor)
            for index, output in enumerate(outputs):
                delivered = read_safe_zip(Path(output[0]))
                assert "source/primary-preparation.zip" not in delivered
                assert "source/primary-compilation.json" in delivered
                if index == 0:
                    for label, wrong in (("full0", {"primary_outer_prepared": False}),
                                         ("horizon", {"selection_horizon_months": 24}),
                                         ("family", {"candidate_family": "GBM_COX"})):
                        rejected = tmp_path / ("rsf-rejected-" + label)
                        with pytest.raises(ContractError):
                            f5.execute_final_complex_search(prepared_q_input=Path(output[0]), target=rejected,
                                prepared_q_input_sha256=sha256_file(Path(output[0])), task_ids=output[1:],
                                batch_root=tmp_path / ("rejected-batch-" + label), retained_bytes_per_task=retention_cap,
                                **{**{"selection_horizon_months": 12, "candidate_family": "RSF",
                                      "primary_outer_prepared": True}, **wrong})
                        assert not reached and not rejected.exists()
                value = f5.execute_final_complex_search(prepared_q_input=Path(output[0]),
                    target=tmp_path / f"rsf-worker-{index}",
                    prepared_q_input_sha256=sha256_file(Path(output[0])), task_ids=output[1:],
                    batch_root=tmp_path / f"rsf-batch-{index}", retained_bytes_per_task=retention_cap,
                    selection_horizon_months=12, candidate_family="RSF", primary_outer_prepared=True)
                assert value == {"UNFITTED_EXECUTOR_BOUNDARY": True}
            assert len(reached) == len(set(reached)) == len(expected_ids) and set(reached) == set(expected_ids)
            from test_q_funnel_shards import _unfitted_leaves
            monkeypatch.setattr(f5, "_execute_q_search_batch", original_executor)
            events, _ = _unfitted_leaves(monkeypatch)
            monkeypatch.setattr(runtime, "observe_execution_resources", lambda root: {
                "effective_cpus": 32, "available_memory_bytes": 10**12,
                "scratch_available_bytes": 10**12, "scratch_root": str(root)})
            history = []
            for index, output in enumerate(outputs):
                batch = tmp_path / f"rsf-unfitted-batch-{index}"
                value = f5.execute_final_complex_search(prepared_q_input=Path(output[0]),
                    target=tmp_path / f"rsf-unfitted-worker-{index}",
                    prepared_q_input_sha256=sha256_file(Path(output[0])), task_ids=output[1:],
                    batch_root=batch, retained_bytes_per_task=retention_cap,
                    selection_horizon_months=12, candidate_family="RSF", primary_outer_prepared=True)
                assert value["status"] == "COMPUTED_Q_BATCH"
                history.append(batch)
            prior = tmp_path / "rsf-prior"
            prior.mkdir()
            (prior / "input.json").write_bytes(entries["input.json"])
            before = [event for event in events if event[0] != "numbers"]
            next_ids = f5._a12_q_stop_phase("S2", refit=True, family="RSF", rsf_pool_workers=rsf_profile)[1]
            successor = f4.compile_o_fit_bundle(tmp_path, tmp_path / "rsf-s2.zip", outer_fold=1,
                science_decision=decision, resource_policy=policy, retained_bytes_per_component=retention_cap,
                expanded_bytes_per_component=10**6, shared_storage_bytes=10**9,
                primary_rsf_prepare=True, primary_prepare_family="RSF",
                primary_retained_q_input=prior / "input.json",
                primary_q_batch_options={"prepare_only": True, "task_ids": None, "batch_root": None,
                    "q_batches": history, "retained_bytes_per_task": retention_cap},
                primary_q_unit_outputs=[[str(tmp_path / f"rsf-s2-{index}.zip"), *next_ids[index::(7 if historical_s2 or continuous_terminal == "summary-owner" else 2)]]
                    for index in range(7 if historical_s2 or continuous_terminal == "summary-owner" else 2)],
                primary_producer_source_bundle=producer)
            assert successor["model_coordinate_count"] == 200
            assert successor["confirmed_model_fits"] == 120 and successor["confirmed_stop_fits"] == 0
            assert list(successor["search_trace"]) == ["S1"] and len(successor["search_trace"]["S1"]) == 24
            assert before == [event for event in events if event[0] != "numbers"]
            from padml.bundle import extract_safe_zip
            stages = ("S1", "S2", "S3A", "S3B1", "S3B2")
            stage_compilation_receipts = {"S2": {key: value for key, value in successor.items()
                                                if key != "prepared_unit_inputs"}}
            for stage in stages[1:]:
                prefix_archive = tmp_path / ("rsf-" + stage.lower() + ".zip")
                prefix_root = tmp_path / ("rsf-retained-" + stage.lower())
                extract_safe_zip(prefix_archive, prefix_root,
                    expected_members=set(read_safe_zip(prefix_archive)),
                    max_member_bytes=1024**3, max_total_bytes=4 * 1024**3)
                if partial_s1_history and not historical_s2 and stage == "S3A":
                    # Model the historical consumer's lost S1 summaries in
                    # this UNFITTED fixture only. Keep the original S2 values,
                    # source, tasks, numerical members and direct consumers.
                    partial = strict_json_bytes((prefix_root / "result.json").read_bytes())
                    del partial["search_trace"]["S1"]
                    partial["s1_consumed_history"] = {"report": {"sha256": "a" * 64, "size_bytes": 100},
                        "predecessor_execution_sha256": [sha256_file(path / "execution.json") for path in history[:initial_shards]],
                        "consumed_model_coordinates": 120, "score_trace_status": "NOT_RETAINED"}
                    history = history[initial_shards:]
                    partial["predecessor_execution_sha256"] = [sha256_file(path / "execution.json") for path in history]
                    partial_raw = canonical_json_bytes(partial)
                    (prefix_root / "result.json").write_bytes(partial_raw)
                    numbers = strict_json_bytes((prefix_root / "numbers.json").read_bytes())
                    numbers["result_sha256"] = sha256_bytes(partial_raw)
                    numbers["members"]["result.json"] = {"sha256": sha256_bytes(partial_raw), "size_bytes": len(partial_raw)}
                    numbers["identity_sha256"] = sha256_bytes(canonical_json_bytes({k: v for k, v in numbers.items() if k != "identity_sha256"}))
                    (prefix_root / "numbers.json").write_bytes(canonical_json_bytes(numbers))
                prior_trace = strict_json_bytes((prefix_root / "result.json").read_bytes())["search_trace"]
                ids = f5._a12_q_stop_phase(stage, refit=True, family="RSF", rsf_pool_workers=rsf_profile)[1]
                if continuous_terminal and stage == ("S2" if continuous_terminal == "two-stages" else "S3B2"):
                    history_options = {}
                    if continuous_terminal == "summary-owner":
                        # This variant exercises the real owner/funnel/numbers/
                        # terminal readers with a saved S1 summary (zero recovery).
                        # Only the historical source/report preparation seam is
                        # synthetic; real archived provenance is tested separately.
                        import shutil
                        from padml.f4_compact import _full_pipeline_q_numerical_members
                        s1_root = tmp_path / "rsf-retained-s2"
                        _, s1_refs = _full_pipeline_q_numerical_members(s1_root)
                        s1_result = strict_json_bytes((s1_root / "result.json").read_bytes())
                        s1_phase = f5._a12_q_stop_phase("S1", refit=True, family="RSF")[0]
                        s1_batches = [path for path in history if strict_json_bytes(
                            (path / "execution.json").read_bytes())["phase"] == s1_phase]
                        assert len(s1_batches) == 7
                        f5._retain_primary_rsf_s1_summary(q_input["spec"], s1_root,
                            {"primary_rsf_s1_trace": s1_result["search_trace"]["S1"],
                             "references": s1_refs, "resource_policy": policy,
                             "used_batches": [sha256_file(path / "execution.json") for path in s1_batches]},
                            {"sha256": sha256_bytes(entries["input.json"]), "size_bytes": len(entries["input.json"])})
                        saved_summary = s1_root / "s1-summary"
                        saved_prefix = tmp_path / "rsf-retained-s3b1"
                        original_child, original_atoms = f5._primary_rsf_prepared_input(
                            entries["input.json"], tmp_path / "rsf-s3b1.zip", producer,
                            compilation_receipt=stage_compilation_receipts["S3B1"])
                        source_digest = sha256_file(producer)
                        source_members = {row["path"]: row["sha256"] for row in f4.load_f45_source_bundle(producer)["members"]}
                        assert source_members == f4._f45_source_member_sha256()
                        original_source_proof = f4._retained_full0_source_members
                        def source_seam(path, **options):
                            if options == {"primary_rsf_inputs": True} and sha256_file(path) == source_digest:
                                members = {row["path"]: row["sha256"] for row in f4.load_f45_source_bundle(path)["members"]}
                                assert members == source_members == f4._f45_source_member_sha256()
                                return members
                            return original_source_proof(path, **options)
                        monkeypatch.setattr(f4, "_retained_full0_source_members", source_seam)
                        history_evidence = {}
                        for old_stage, group in (("S1", "s2"), ("S2", "s3a"), ("S3A", "s3b1")):
                            old_phase = f5._a12_q_stop_phase(old_stage, refit=True, family="RSF")[0]
                            records = [path for path in history if strict_json_bytes(
                                (path / "execution.json").read_bytes())["phase"] == old_phase]
                            assert len(records) == 7
                            mapping = {}
                            for host, batch in zip(("H0", "H1", "H4", "H5", "H6", "H7", "H9-2"), records, strict=True):
                                name = f"primary-{group}/{host}-execution.json"
                                path = tmp_path / "UNFITTED-owner-history" / group / name
                                path.parent.mkdir(parents=True, exist_ok=True)
                                path.write_bytes((batch / "execution.json").read_bytes())
                                mapping[name] = path
                            report_path = tmp_path / "UNFITTED-owner-history" / group / f"primary-{group}/report.json"
                            report_path.write_bytes(canonical_json_bytes({"UNFITTED_PREPARATION_SEAM": group}))
                            mapping[f"primary-{group}/report.json"] = report_path
                            mapping[f"source/primary-{group}-producer.zip"] = producer
                            if group == "s2": mapping["source/primary-q-producer.zip"] = producer
                            history_evidence[group] = mapping
                        def preparation_seam(raw, preparation, supplied_source, **groups):
                            assert raw == entries["input.json"]
                            assert sha256_file(preparation) == sha256_file(target)
                            assert sha256_file(supplied_source) == source_digest
                            assert set(groups) == {"s2_evidence", "s3a_evidence", "s3b1_evidence"}
                            for group, mapping in history_evidence.items():
                                assert {name: path.read_bytes() for name, path in groups[group + "_evidence"].items()} == {
                                    name: path.read_bytes() for name, path in mapping.items()}
                            return original_child, original_atoms
                        monkeypatch.setattr(f5, "_primary_rsf_prepared_input", preparation_seam)
                        # Model only the historical missing-summary representation;
                        # keep every original S2/S3A numerical byte and S1 cache.
                        prefix_root = tmp_path / "UNFITTED-missing-summary-prefix"
                        prefix_root.mkdir()
                        s1_directories = {str(Path(name).parent) for name in s1_refs if name.startswith("native/")}
                        for path in saved_prefix.rglob("*"):
                            relative = path.relative_to(saved_prefix)
                            if path.is_file() and str(relative.parent) not in s1_directories:
                                destination = prefix_root / relative
                                destination.parent.mkdir(parents=True, exist_ok=True)
                                shutil.copyfile(path, destination)
                        partial = strict_json_bytes((prefix_root / "result.json").read_bytes())
                        del partial["search_trace"]["S1"]
                        partial["s1_consumed_history"] = {"report": {"sha256": "a" * 64, "size_bytes": 100},
                            "predecessor_execution_sha256": [sha256_file(path / "execution.json") for path in s1_batches],
                            "consumed_model_coordinates": 120, "score_trace_status": "NOT_RETAINED"}
                        s3a_phase = f5._a12_q_stop_phase("S3A", refit=True, family="RSF")[0]
                        partial["predecessor_execution_sha256"] = [sha256_file(path / "execution.json") for path in history
                            if strict_json_bytes((path / "execution.json").read_bytes())["phase"] == s3a_phase]
                        partial_raw = canonical_json_bytes(partial)
                        (prefix_root / "result.json").write_bytes(partial_raw)
                        numbers = strict_json_bytes((prefix_root / "numbers.json").read_bytes())
                        numbers["members"] = {name: pin for name, pin in numbers["members"].items()
                            if not name.startswith("native/") or str(Path(name).parent) not in s1_directories}
                        numbers["result_sha256"] = sha256_bytes(partial_raw)
                        numbers["members"]["result.json"] = {"sha256": sha256_bytes(partial_raw), "size_bytes": len(partial_raw)}
                        numbers["identity_sha256"] = sha256_bytes(canonical_json_bytes({key: value for key, value in numbers.items()
                            if key != "identity_sha256"}))
                        (prefix_root / "numbers.json").write_bytes(canonical_json_bytes(numbers))
                        _full_pipeline_q_numerical_members(prefix_root)
                        history_options = {"primary_rsf_preparation": target, "primary_rsf_producer": producer,
                            "retained_primary_rsf_q_source_bundle": producer,
                            **{f"primary_rsf_{name}_evidence": mapping for name, mapping in history_evidence.items()},
                            "s1_summary_recovery_call_limit": 0, "primary_rsf_s1_summary": saved_summary,
                            "primary_rsf_s1_summary_sha256": sha256_file(saved_summary / "numbers.json")}
                    # Reuse the actual UNFITTED prefix produced above.  Only
                    # native science leaves are fixture adapters; the original
                    # executor, persisted execution and numerical consumer run.
                    original_input = (prefix_root / "input.json").read_bytes()
                    pins = {str(path): sha256_file(path) for path in prefix_root.rglob("*") if path.is_file()}
                    phase = f5._a12_q_stop_phase(stage, refit=True, family="RSF", rsf_pool_workers=rsf_profile)[0]
                    authorized = {phase: ids}
                    if continuous_terminal == "two-stages":
                        next_phase, next_ids = f5._a12_q_stop_phase("S3A", refit=True, family="RSF", rsf_pool_workers=rsf_profile)
                        authorized[next_phase] = next_ids
                    owner = tmp_path / "continuous-batches"
                    owner.mkdir()
                    if continuous_terminal == "summary-owner":
                        from padml.f4_compact import _full_pipeline_q_numbers_mode
                        unfitted_leaf = kernel._run_r_prediction_pool_task
                        def no_repeated_prefix(call):
                            leaf_spec, _, leaf_tasks, *_ = call
                            leaf_stages = {row["task_id"].split("_", 1)[0] for row in leaf_tasks}
                            assert leaf_stages in ({"S3B1"}, {"S3B2"})
                            if leaf_stages == {"S3B1"}:
                                assert _full_pipeline_q_numbers_mode(leaf_spec), "PREFIX_NATIVE_REPLAY_FORBIDDEN"
                            return unfitted_leaf(call)
                        # Preserve the original phase function name/identity
                        # expected by the task owner while guarding its leaf.
                        no_repeated_prefix.__name__ = "_run_r_prediction_pool_task"
                        monkeypatch.setattr(kernel, "_run_r_prediction_pool_task", no_repeated_prefix)
                    consumed = []
                    numeric_consumer = f5._consume_q_search_batches
                    def checked_consumer(spec, function, units, batches, actual_phase, input_ref):
                        if continuous_terminal == "summary-owner" and actual_phase not in authorized:
                            assert actual_phase == f5._a12_q_stop_phase("S3B1", refit=True, family="RSF")[0]
                            assert len(batches) == 7
                        else:
                            assert actual_phase in authorized and len(batches) == 1
                        for path, record in batches:
                            assert (path / "execution.json").read_bytes() == canonical_json_bytes(record)
                        value = numeric_consumer(spec, function, units, batches, actual_phase, input_ref)
                        consumed.extend(record for _, record in batches if actual_phase in authorized)
                        return value
                    monkeypatch.setattr(f5, "_consume_q_search_batches", checked_consumer)
                    result_root = tmp_path / "continuous-result"
                    report = original_prepare(execution_projections[-1], result_root, policy,
                        retained_bytes_per_task=retention_cap, admit_io=lambda **kwargs: None,
                        prepared_calls=[], retained_q_input=prefix_root / "input.json",
                        retained_input_producer=producer,
                        batch_options={"prepare_only": True, "task_ids": None, "batch_root": None,
                            "q_batches": history, "retained_bytes_per_task": retention_cap, **history_options},
                        _execution_batch_root=owner, _execution_phase_task_ids=authorized)
                    count = 500 if continuous_terminal == "two-stages" else 300
                    assert report["new_model_fits"] == report["new_first_native_audits"] == count
                    assert len(consumed) == len(authorized)
                    assert [row["phase"] for row in consumed] == list(authorized)
                    assert all(row["task_ids"] == authorized[row["phase"]] for row in consumed)
                    assert all(row["source_identity"] == sha256_bytes(canonical_json_bytes(f4._f45_source_member_sha256())) for row in consumed)
                    assert (result_root / "input.json").read_bytes() == original_input
                    assert pins == {str(path): sha256_file(path) for path in prefix_root.rglob("*") if path.is_file()}
                    from padml.f4_compact import _full_pipeline_q_numerical_members
                    _full_pipeline_q_numerical_members(result_root)
                    if continuous_terminal == "two-stages":
                        assert report["status"] == "PREPARED_Q_BATCH"
                        stop_phase, stop_ids = f5._a12_q_stop_phase("S3B1", refit=True, family="RSF", rsf_pool_workers=rsf_profile)
                        assert report["phase"] == stop_phase and report["task_ids"] == stop_ids
                        assert report["confirmed_model_fits"] == 620 and report["confirmed_stop_fits"] == 0
                        assert list(report["search_trace"]) == ["S1", "S2", "S3A"]
                        assert not (owner / stop_phase).exists()
                        assert set(report["predecessor_execution_sha256"]) == {
                            *[sha256_file(path / "execution.json") for path in history],
                            *[sha256_bytes(canonical_json_bytes(row)) for row in consumed]}
                        saved = strict_json_bytes((result_root / "result.json").read_bytes())
                        assert saved["new_model_fits"] == saved["new_first_native_audits"] == 0
                        assert saved["confirmed_model_fits"] == 620
                        assert "execution_only" not in saved and "execution_source_identity" not in saved
                        # Re-enter only the original zero-fit compiler. It
                        # reuses the accepted prefix, captures S3B1 arguments,
                        # assembles its receipt and calls the original publisher.
                        monkeypatch.setattr(f5, "_consume_q_search_batches", numeric_consumer)
                        monkeypatch.setattr(f5, "_execute_q_search_batch",
                            lambda *args, **kwargs: pytest.fail("S3B1_EXECUTION_FORBIDDEN"))
                        publication_zip = tmp_path / "continuous-s3b1-preparation.zip"
                        worker_zip = tmp_path / "continuous-s3b1-worker.zip"
                        published = f4.compile_o_fit_bundle(tmp_path, publication_zip, outer_fold=1,
                            science_decision=decision, resource_policy=policy,
                            retained_bytes_per_component=retention_cap, expanded_bytes_per_component=10**6,
                            shared_storage_bytes=10**9, primary_rsf_prepare=True,
                            primary_prepare_family="RSF", primary_retained_q_input=result_root / "input.json",
                            primary_q_batch_options={"prepare_only": True, "task_ids": None,
                                "batch_root": None, "q_batches": history + [owner / p for p in authorized],
                                "retained_bytes_per_task": retention_cap},
                            primary_q_unit_outputs=[[str(worker_zip), *stop_ids]],
                            primary_producer_source_bundle=producer)
                        assert worker_zip.is_file() and published["new_model_fits"] == 0
                        child, original_units = f5._primary_rsf_prepared_input(original_input,
                            publication_zip, producer, compilation_receipt=published)
                        # Preserve the source profile's original atomic grouping;
                        # the production historical 75-atom layout is not this
                        # synthetic profile's independently generated geometry.
                        assert list(original_units) == stop_ids and len(original_units) == len(stop_ids)
                        assert sum(map(len, original_units.values())) == 150
                        assert original_units == {row["task_id"]: row["producer_tasks"]
                            for row in saved["next_atomic_units"]}
                        assert child["primary_search_source"] == strict_json_bytes(original_input)["spec"]["primary_search_source"]
                        # Rebuild all ordinary transport pins for a semantic
                        # violation. Rejection must not be a stale ZIP hash.
                        bad_members = read_safe_zip(publication_zip)
                        bad_result = strict_json_bytes(bad_members["result.json"])
                        bad_result["new_model_fits"] = 500
                        bad_result["new_first_native_audits"] = 500
                        bad_members["result.json"] = canonical_json_bytes(bad_result)
                        bad_index = strict_json_bytes(bad_members["numbers.json"])
                        bad_index["result_sha256"] = sha256_bytes(bad_members["result.json"])
                        bad_index["members"]["result.json"] = {"sha256": bad_index["result_sha256"],
                            "size_bytes": len(bad_members["result.json"])}
                        bad_index["identity_sha256"] = sha256_bytes(canonical_json_bytes({
                            k: v for k, v in bad_index.items() if k != "identity_sha256"}))
                        bad_members["numbers.json"] = canonical_json_bytes(bad_index)
                        bad_zip = tmp_path / "nonzero-preparation.zip"
                        write_deterministic_zip(bad_zip, bad_members)
                        bad_receipt = {**published, **bad_result, "sha256": sha256_file(bad_zip),
                            "size_bytes": bad_zip.stat().st_size,
                            "preparation_metadata": {name: {"sha256": sha256_bytes(bad_members[name]),
                                "size_bytes": len(bad_members[name])}
                                for name in ("input.json", "result.json", "numbers.json")}}
                        with pytest.raises(ContractError, match="F5_PRIMARY_RSF_PREPARED_SOURCE_INVALID"):
                            f5._primary_rsf_prepared_input(original_input, bad_zip, producer,
                                compilation_receipt=bad_receipt)
                    else:
                        assert report["status"] == "COMPUTED_Q_SEARCH"
                        assert report["scientific_result"]["search_trace"].keys() == dict.fromkeys(stages).keys()
                        if continuous_terminal == "summary-owner":
                            assert report["s1_summary_recovery_calls"] == 0
                            assert report["s3b2_numerical_consumer_calls"] == 1
                            assert not result_root.with_name(result_root.name + ".s1-recovery").exists()
                            ledger = strict_json_bytes((result_root / "execution.json").read_bytes())
                            assert len(ledger["batches"]) == 29 and "primary_rsf_evidence" in ledger
                            assert report["scientific_result"]["search_trace"]["S1"] == s1_result["search_trace"]["S1"]
                            assert {key: report["scientific_result"]["search_trace"][key] for key in ("S2", "S3A")} == partial["search_trace"]
                    return
                stage_shards = 7 if historical_s2 and stage == "S2" or continuous_terminal == "summary-owner" else 2
                for index in range(stage_shards):
                    scoped = tmp_path / f"rsf-{stage.lower()}-{index}.zip"
                    batch = tmp_path / f"rsf-{stage.lower()}-batch-{index}"
                    f5.execute_final_complex_search(prepared_q_input=scoped,
                        target=tmp_path / f"rsf-{stage.lower()}-worker-{index}",
                        prepared_q_input_sha256=sha256_file(scoped), task_ids=ids[index::stage_shards],
                        batch_root=batch, retained_bytes_per_task=retention_cap,
                        selection_horizon_months=12, candidate_family="RSF", primary_outer_prepared=True)
                    history.append(batch)
                if partial_s1_history and stage == "S3B2":
                    assert list(prior_trace) == ["S2", "S3A", "S3B1"]
                    assert all(event[2].split("_", 1)[0] != "S1" for event in events[partial_event_start:])
                    if historical_s2:
                        assert mixed_proof_negatives == ["missing", "wrong-source"]
                    return  # Missing S1 remains a true complete-Q dependency.
                before_events = len(events)
                next_stage = stages[stages.index(stage) + 1] if stage != "S3B2" else None
                publication = {}
                if next_stage:
                    following = f5._a12_q_stop_phase(next_stage, refit=True, family="RSF", rsf_pool_workers=rsf_profile)[1]
                    next_shards = 7 if continuous_terminal == "summary-owner" else 2
                    publication = {"primary_q_unit_outputs": [[str(tmp_path / f"rsf-{next_stage.lower()}-{index}.zip"),
                        *following[index::next_shards]] for index in range(next_shards)], "primary_producer_source_bundle": producer}
                archive = tmp_path / ("rsf-" + next_stage.lower() + ".zip" if next_stage else "unfitted-complete-primary-q.zip")
                options = {"prepare_only": True, "task_ids": None, "batch_root": None,
                    "q_batches": history, "retained_bytes_per_task": retention_cap}
                if historical_s2 and stage == "S2":
                    # Synthetic historical-receipt preimage only. Keep the
                    # real compiler, owner, original numerical consumer,
                    # promotion, publisher and downstream input reader live.
                    # The real 4339/07add byte proofs have separate fixtures.
                    import os
                    executor = Path(os.environ["PADML_PRIMARY_RSF_COMPLETED_EXECUTOR_SOURCE"])
                    original_members = f4._f45_source_member_sha256()
                    executor_members = f4._retained_full0_source_members(executor, primary_rsf_inputs=True)
                    current_members = {**original_members, "padml/f5.py": "b" * 64}
                    original_proof = f4._retained_full0_source_members
                    producer_sha = sha256_file(producer)
                    executor_sha = sha256_file(executor)
                    def proved_sources(path, **kwargs):
                        digest = sha256_file(path)
                        if kwargs == {"primary_rsf_inputs": True} and digest in (producer_sha, executor_sha):
                            return original_members if digest == producer_sha else executor_members
                        return original_proof(path, **kwargs)
                    # A source-proof seam models a new compatible executor;
                    # real finite source bytes are verified separately. Old
                    # input/records remain untouched and keep their identity.
                    monkeypatch.setattr(f4, "_retained_full0_source_members", proved_sources)
                    old_reader = f5._primary_rsf_prepared_input
                    old_raw = (prefix_root / "input.json").read_bytes()
                    old_child, old_atoms = old_reader(old_raw, prefix_archive, producer,
                        compilation_receipt={k: v for k, v in successor.items() if k != "prepared_unit_inputs"})
                    monkeypatch.setattr(f4, "_f45_source_member_sha256", lambda: current_members)
                    evidence = {}
                    for host, batch in zip(("H0", "H1", "H4", "H5", "H6", "H7", "H9-2"), history[:initial_shards], strict=True):
                        path = tmp_path / "UNFITTED-history" / f"primary-s2/{host}-execution.json"
                        path.parent.mkdir(parents=True, exist_ok=True)
                        path.write_bytes((batch / "execution.json").read_bytes())
                        evidence[f"primary-s2/{host}-execution.json"] = path
                    report = tmp_path / "UNFITTED-history/primary-s2/report.json"
                    report.write_bytes(canonical_json_bytes({"predecessor_execution_sha256":
                        [sha256_file(batch / "execution.json") for batch in history[:initial_shards]],
                        "consumed_s1_model_coordinates": 120, "original_q_boundary": {"confirmed_stop_fits": 0}}))
                    evidence["primary-s2/report.json"] = report
                    evidence.update({name: producer for name in ("source/primary-s2-producer.zip", "source/primary-q-producer.zip")})
                    evidence_bytes = {name: path.read_bytes() for name, path in evidence.items()}
                    def historical_reader(raw, prepared, source, **kwargs):
                        if "s2_evidence" not in kwargs:
                            return old_reader(raw, prepared, source, **kwargs)
                        assert set(kwargs) == {"s2_evidence"} and raw == old_raw
                        assert prepared == prefix_archive and source == producer
                        assert {name: path.read_bytes() for name, path in kwargs["s2_evidence"].items()} == evidence_bytes
                        return old_child, old_atoms
                    monkeypatch.setattr(f5, "_primary_rsf_prepared_input", historical_reader)
                    original_consume = f5._consume_q_search_batches
                    def checked_consume(spec, function, units, batches, phase, input_ref):
                        control = spec["native_search_batch"]
                        if "retained_primary_rsf_input_source_bundle" in control and not mixed_proof_negatives:
                            for damage in ("missing", "wrong-source"):
                                bad = dict(control)
                                if damage == "missing":
                                    del bad["retained_primary_rsf_input_source_bundle"]
                                else:
                                    bad["retained_primary_rsf_input_source_bundle"] = executor
                                before_events = list(events)
                                with pytest.raises(ContractError, match="F5_PRIMARY_PREPARED_Q_NUMERICAL_SCOPE_INVALID"):
                                    original_consume({**spec, "native_search_batch": bad},
                                        function, units, batches, phase, input_ref)
                                assert events == before_events
                                mixed_proof_negatives.append(damage)
                        return original_consume(spec, function, units, batches, phase, input_ref)
                    monkeypatch.setattr(f5, "_consume_q_search_batches", checked_consume)
                    history = history[initial_shards:]
                    assert len(history) == 7
                    # UNFITTED records emulate the old executor's role; these
                    # are not historical model evidence or accepted results.
                    for batch in history:
                        record = strict_json_bytes((batch / "execution.json").read_bytes())
                        record["source_identity"] = "07addcbb504f98caed9be64f2f598454bf6eb1df43bd6494e4d143151eb6e9bc"
                        (batch / "execution.json").write_bytes(canonical_json_bytes(record))
                    options.update(q_batches=history, primary_rsf_s2_consumption=True,
                        primary_rsf_preparation=prefix_archive, primary_rsf_producer=producer,
                        retained_primary_rsf_q_source_bundle=executor, primary_rsf_s2_evidence=evidence)
                successor = f4.compile_o_fit_bundle(tmp_path, archive, outer_fold=1,
                    science_decision=decision, resource_policy=policy, retained_bytes_per_component=retention_cap,
                    expanded_bytes_per_component=10**6, shared_storage_bytes=10**9,
                    primary_rsf_prepare=True, primary_prepare_family="RSF",
                    primary_retained_q_input=prefix_root / "input.json",
                    primary_q_batch_options=options, **publication)
                if next_stage:
                    stage_compilation_receipts[next_stage] = {key: value for key, value in successor.items()
                                                             if key != "prepared_unit_inputs"}
                observed = strict_json_bytes(read_safe_zip(archive)["result.json"])
                trace = observed.get("scientific_result", observed)["search_trace"]
                assert {key: trace[key] for key in prior_trace if not (historical_s2 and stage == "S2" and key == "S1")} == {
                    key: value for key, value in prior_trace.items() if not (historical_s2 and stage == "S2" and key == "S1")}
                assert all(event[0] == "numbers" for event in events[before_events:])
                assert all(not event[2].startswith(tuple(key + "_" for key in prior_trace))
                           for event in events[before_events:])
                if partial_s1_history and stage == "S2":
                    partial_event_start = len(events)
            assert observed["total_search_fit_count"] == 1070
            assert successor["s1_summary_recovery_calls"] == 0 and successor["s3b2_numerical_consumer_calls"] == 1
            assert list(trace) == list(stages)
            return
        q_root = tmp_path / "publish"
        q_root.mkdir()
        (q_root / "input.json").write_bytes(entries["input.json"])
        receipt_path = tmp_path / "original-compile-receipt.json"
        receipt_path.write_bytes(canonical_json_bytes(compiled))
        function, original_tasks = prepared_calls[0]
        units = f5._q_search_units(function, original_tasks)
        # A completed first STOP phase must reach the original numerical
        # consumer rather than being rejected as a second preparation.
        # This sentinel proves routing only, not numerical acceptance.
        with monkeypatch.context() as consume_patch:
            seen = []
            def consume_original(spec, received_function, received_units, batches, phase, input_ref):
                assert received_function is function and list(received_units) == list(units)
                assert phase == boundary["phase"] and input_ref == boundary["input"]
                seen.append(batches)
                raise RuntimeError("UNFITTED_ORIGINAL_NUMERICAL_CONSUMER_BOUNDARY")
            consume_patch.setattr(f5, "_consume_q_search_batches", consume_original)
            completed_stop = {"prepare_only": True, "task_ids": None, "completed": False,
                "batches": [(tmp_path, {"phase": boundary["phase"]})], "used_batches": [],
                "confirmed_model_fits": 0, "confirmed_stop_fits": 0}
            continuation = {**q_input["spec"], "native_search_root": str(q_root / "native"),
                "native_search_replay": False, "native_search_batch": completed_stop}
            with pytest.raises(RuntimeError, match="UNFITTED_ORIGINAL_NUMERICAL_CONSUMER_BOUNDARY"):
                f5._q_search_task_batch(continuation, function, original_tasks)
            assert len(seen) == 1
            for change in ({"batches": [(tmp_path, {"phase": "WRONG_PHASE"})]},
                           {"q_unit_outputs": outputs},
                           {"prepared_calls": [("UNFITTED_ALREADY_CAPTURED", {})]},
                           {"prepare_only": False}, {"confirmed_stop_fits": 1}):
                with pytest.raises(ContractError):
                    f5._q_search_task_batch({**continuation,
                        "native_search_batch": {**completed_stop, **change}}, function, original_tasks)
            assert len(seen) == 1
        publication_options = {
            "q_unit_outputs": outputs, "task_ids": None, "prepare_only": True,
            "retained_bytes_per_task": retention_cap, "batch_root": None, "q_batches": None,
            "primary_rsf_preparation": target, "primary_rsf_producer": producer,
            "primary_compilation_receipt": receipt_path}
        for bad_options in ({key: value for key, value in publication_options.items()
                             if key != "primary_compilation_receipt"},
                            {**publication_options, "prepare_only": False},
                            {**publication_options, "q_batches": [q_root]}):
            with pytest.raises(ContractError):
                f5._q_search_batch_control(q_root, policy, bad_options)
        control = f5._q_search_batch_control(q_root, policy, publication_options)
        continuation = {**q_input["spec"], "native_search_root": str(q_root / "native"),
            "native_search_replay": False, "native_search_batch": control}
        without_receipt = {**continuation, "native_search_batch": {
            key: value for key, value in control.items() if key != "primary_compilation_receipt"}}
        with pytest.raises(ContractError):
            f5._q_search_task_batch(without_receipt, function, original_tasks)
        assert published_index["phase"] == boundary["phase"]
        assert published_index["input"] == boundary["input"]
        pins = [sha256_file(Path(output[0])) for output in outputs]
        with pytest.raises(ContractError):
            f5._q_search_task_batch(continuation, function, original_tasks)
        assert pins == [sha256_file(Path(output[0])) for output in outputs]
        all_names = []
        executed = []
        def no_fit_executor(received_function, received_units, root, control, phase, input_ref, **kwargs):
            assert received_function is function and phase == boundary["phase"] and input_ref == boundary["input"]
            assert control["execution_worker_memory_bytes"] == 2147483648
            assert control["execution_scratch_reserve_bytes"] == 0
            for name, (call, _) in received_units.items():
                spec = call[0] if prepare_family == "GBM_COX" else call[0]["spec"]
                assert spec["primary_search_source"] == source
                assert "a12_source" not in spec and "final_search_source" not in spec
                assert not kernel._contains_key(call[1] if prepare_family == "GBM_COX" else call[0], "evaluation_response")
                executed.append(name)
            raise f5._QBatchBoundary({"UNFITTED_EXECUTOR_BOUNDARY": True})
        monkeypatch.setattr(f5, "_execute_q_search_batch", no_fit_executor)
        for output_index, output in enumerate(outputs):
            delivered = read_safe_zip(Path(output[0]))
            record = strict_json_bytes(delivered["prepared-q.json"])
            assert delivered["source/primary-compilation.json"] == receipt_path.read_bytes()
            assert "source/primary-preparation.zip" not in delivered
            assert {name.removeprefix("source/primary-preparation/"): raw for name, raw in delivered.items()
                if name.startswith("source/primary-preparation/")} == read_safe_zip(target)
            assert delivered["source/primary-producer.zip"] == producer.read_bytes()
            assert record["task_ids"] == output[1:]
            assert record["all_task_ids"] == list(units)
            from padml.bundle import extract_safe_zip
            reopened = tmp_path / f"received-{output_index}"
            extract_safe_zip(Path(output[0]), reopened, expected_members=set(delivered),
                max_member_bytes=1024**3, max_total_bytes=4 * 1024**3)
            received_spec, received_atoms = f5._primary_rsf_prepared_input(delivered["input.json"],
                reopened / "source/primary-preparation", reopened / "source/primary-producer.zip",
                compilation_receipt=strict_json_bytes(delivered["source/primary-compilation.json"]))
            assert received_spec == child and received_atoms == atoms
            if output_index == 0:
                for damage in ("missing", "digest"):
                    changed_receipt = strict_json_bytes(delivered["source/primary-compilation.json"])
                    if damage == "missing":
                        changed_receipt["preparation_metadata"].pop("result.json")
                    else:
                        changed_receipt["preparation_metadata"]["result.json"]["sha256"] = "0" * 64
                    with pytest.raises(ContractError, match="F5_PRIMARY_RSF_PREPARED_SOURCE_INVALID"):
                        f5._primary_rsf_prepared_input(delivered["input.json"],
                            reopened / "source/primary-preparation", reopened / "source/primary-producer.zip",
                            compilation_receipt=changed_receipt)
            for name, pins in record["units"].items():
                arguments = [record["arguments"][pin] for pin in pins]
                call = (arguments if prepare_family == "GBM_COX" else
                        f5._a12_q_python_prepared_call(arguments, stop=True))
                assert canonical_json_bytes(f5._a12_q_stop_unit_input(call, function=function)) == canonical_json_bytes(call)
            all_names.extend(record["task_ids"])
            if output_index == 0:
                for bad_horizon, bad_family in ((24, prepare_family), (12, "RSF")):
                    rejected_root = tmp_path / f"rejected-worker-{bad_horizon}-{bad_family}"
                    with pytest.raises(ContractError):
                        f5._execute_a12_prepared_q_batch(Path(output[0]), rejected_root,
                            expected_sha256=sha256_file(Path(output[0])), task_ids=output[1:],
                            batch_root=tmp_path / "rejected-batch", retained_bytes_per_task=retention_cap,
                            selection_horizon_months=bad_horizon, expected_family=bad_family)
                    assert not rejected_root.exists() and not executed
            value = f5.execute_final_complex_search(prepared_q_input=Path(output[0]), target=tmp_path / f"worker-{output_index}",
                prepared_q_input_sha256=sha256_file(Path(output[0])), task_ids=output[1:],
                batch_root=tmp_path / f"batch-{output_index}", retained_bytes_per_task=retention_cap,
                selection_horizon_months=12, candidate_family=prepare_family, primary_outer_prepared=True)
            assert value == {"UNFITTED_EXECUTOR_BOUNDARY": True}
        assert len(all_names) == len(set(all_names)) == len(units)
        assert len(executed) == len(set(executed)) == len(units)
        assert control["confirmed_model_fits"] == control["confirmed_stop_fits"] == 0
        # Actual original batch execution/report/number consumer with explicit
        # synthetic leaves. No native model or scientific acceptance is claimed.
        from test_q_funnel_shards import _unfitted_leaves
        monkeypatch.setattr(f5, "_execute_q_search_batch", original_executor)
        events, _ = _unfitted_leaves(monkeypatch, gbm_loss_fixture=True)
        monkeypatch.setattr(runtime, "observe_execution_resources", lambda root: {
            "effective_cpus": 32, "available_memory_bytes": 10**12,
            "scratch_available_bytes": 10**12, "scratch_root": str(root)})
        history = []
        for index, output in enumerate(outputs):
            batch = tmp_path / f"unfitted-batch-{index}"
            value = f5.execute_final_complex_search(prepared_q_input=Path(output[0]),
                target=tmp_path / f"unfitted-worker-{index}",
                prepared_q_input_sha256=sha256_file(Path(output[0])), task_ids=output[1:],
                batch_root=batch, retained_bytes_per_task=retention_cap,
                selection_horizon_months=12, candidate_family=prepare_family, primary_outer_prepared=True)
            assert value["status"] == "COMPUTED_Q_BATCH"
            history.append(batch)
        numeric = tmp_path / "unfitted-number-owner"
        (numeric / "native").mkdir(parents=True)
        (numeric / "input.json").write_bytes(entries["input.json"])
        numeric_control = f5._q_search_batch_control(numeric, policy, {
            "prepare_only": True, "task_ids": None, "batch_root": None,
            "q_batches": history, "retained_bytes_per_task": retention_cap})
        numeric_spec = {**q_input["spec"], "native_search_root": str(numeric / "native"),
            "native_search_replay": False, "native_search_batch": numeric_control}
        active_function = getattr(kernel, function.__name__)
        before_native = [row for row in events if row[0] != "numbers"]
        complete_batches = numeric_control["batches"]
        for records in (complete_batches[:-1], [*complete_batches, complete_batches[0]],
                        [(path, {**record, "source_identity": "0" * 64})
                         for path, record in complete_batches]):
            numeric_control["batches"] = records
            with pytest.raises(ContractError):
                f5._q_search_task_batch(numeric_spec, active_function, original_tasks)
            assert not numeric_control["used_batches"] and not numeric_control["references"]
            assert not any(row[0] == "numbers" for row in events)
        numeric_control["batches"] = complete_batches
        monkeypatch.setattr(kernel, "_search_task_batch", original_batch)
        retained_input = numeric / "input.json"
        successor_archive = tmp_path / "unfitted-successor.zip"
        original_control = f5._q_search_batch_control
        owner_controls = []
        def observe_control(*args, **kwargs):
            value = original_control(*args, **kwargs)
            owner_controls.append(value)
            return value
        refit_ids = f5._a12_q_stop_phase("S1", refit=True, family=prepare_family)[1]
        scoped_refit = [[str(tmp_path / f"unfitted-refit-shard-{i}.zip"),
                         *refit_ids[i::2]] for i in range(2)]
        with monkeypatch.context() as owner_patch:
            owner_patch.setattr(f5, "_q_search_batch_control", observe_control)
            successor_receipt = f4.compile_o_fit_bundle(tmp_path, successor_archive, outer_fold=1,
                science_decision=decision, resource_policy=policy,
                retained_bytes_per_component=retention_cap, expanded_bytes_per_component=10**6,
                shared_storage_bytes=10**9, primary_rsf_prepare=True,
                primary_prepare_family=prepare_family, primary_retained_q_input=retained_input,
                primary_q_unit_outputs=scoped_refit, primary_producer_source_bundle=producer,
                primary_q_batch_options={"prepare_only": True, "task_ids": None, "batch_root": None,
                    "q_batches": history, "retained_bytes_per_task": retention_cap})
        assert len(owner_controls) == 1
        numeric_control = owner_controls[0]
        refit_calls = numeric_control["prepared_calls"]
        numeric = Path(successor_receipt["native_search_root"])
        next_value = strict_json_bytes((numeric / "result.json").read_bytes())
        assert all(successor_receipt[key] == value for key, value in next_value.items())
        successor_members = read_safe_zip(successor_archive)
        assert {"input.json", "result.json", "numbers.json"} <= set(successor_members)
        reopened_successor = tmp_path / "unfitted-reopened-successor"
        extract_safe_zip(successor_archive, reopened_successor, expected_members=set(successor_members),
            max_member_bytes=1024**3, max_total_bytes=4 * 1024**3)
        from padml.f4_compact import _full_pipeline_q_numerical_members
        reopened_members, _ = _full_pipeline_q_numerical_members(reopened_successor)
        assert set(reopened_members) == set(successor_members)
        numeric_spec = {**q_input["spec"], "native_search_root": str(numeric / "native"),
            "native_search_replay": False, "native_search_batch": numeric_control}
        scratch = numeric / "work"
        assert strict_json_bytes((numeric / "result.json").read_bytes()) == next_value
        assert next_value["phase"] == f5._a12_q_stop_phase("S1", refit=True, family=prepare_family)[0]
        assert next_value["task_ids"] == f5._a12_q_stop_phase("S1", refit=True, family=prepare_family)[1]
        assert next_value["new_model_fits"] == next_value["new_stop_fits"] == 0
        assert next_value["worker_inputs_ready"] is False
        assert next_value["model_coordinate_count"] == len(units)
        assert len(refit_calls) == 2
        refit_function, refit_units = refit_calls.pop()
        successor_spec, successor_tasks = f5._primary_rsf_prepared_input(
            entries["input.json"], successor_archive, producer, compilation_receipt=successor_receipt)
        assert list(successor_tasks) == list(refit_units)
        for name, (call, _) in refit_units.items():
            normalized = f5._a12_q_stop_unit_input(call, function=refit_function)
            actual_spec = normalized[0] if prepare_family == "GBM_COX" else normalized["spec"]
            actual_tasks = normalized[2] if prepare_family == "GBM_COX" else [{
                key: value for key, value in normalized.items() if key not in {"spec", "registered", "handoff_path"}}]
            assert canonical_json_bytes(actual_spec) == canonical_json_bytes(successor_spec)
            assert canonical_json_bytes(actual_tasks) == canonical_json_bytes(successor_tasks[name])
        for damage in ("seed", "predecessor-count"):
            altered = copy.deepcopy(next_value)
            if damage == "seed":
                altered["next_atomic_units"][0]["producer_tasks"][0]["seed"] += 1
            else:
                altered["confirmed_stop_fits"] -= 1
            altered_members = dict(successor_members)
            altered_members["result.json"] = canonical_json_bytes(altered)
            index = strict_json_bytes(altered_members["numbers.json"])
            index["result_sha256"] = sha256_bytes(altered_members["result.json"])
            index["members"]["result.json"] = {"sha256": index["result_sha256"],
                "size_bytes": len(altered_members["result.json"])}
            index["identity_sha256"] = sha256_bytes(canonical_json_bytes({
                key: value for key, value in index.items() if key != "identity_sha256"}))
            altered_members["numbers.json"] = canonical_json_bytes(index)
            altered_archive = tmp_path / f"unfitted-refit-{damage}.zip"
            write_deterministic_zip(altered_archive, altered_members)
            altered_receipt = {**successor_receipt, **altered, "sha256": sha256_file(altered_archive),
                "size_bytes": altered_archive.stat().st_size,
                "preparation_metadata": {name: {"sha256": sha256_bytes(altered_members[name]),
                    "size_bytes": len(altered_members[name])} for name in successor_receipt["preparation_metadata"]}}
            with pytest.raises(ContractError, match="F5_PRIMARY_RSF_PREPARED_SOURCE_INVALID"):
                f5._primary_rsf_prepared_input(entries["input.json"], altered_archive, producer,
                    compilation_receipt=altered_receipt)
        stop_function, retained_stop_units = refit_calls.pop()
        assert stop_function is active_function and list(retained_stop_units) == list(units)
        for name, (call, _) in retained_stop_units.items():
            assert canonical_json_bytes(f5._a12_q_stop_unit_input(call, function=stop_function)) == (
                canonical_json_bytes(f5._a12_q_stop_unit_input(units[name][0], function=stop_function)))
        refit_tasks = [task for task, _ in refit_units.values()]
        del numeric_control["prepared_calls"]
        # The initial compiler receipt proves STOP candidates, not the locks
        # selected from returned numbers. It cannot authorize REFIT publication
        # on its own, even though the original argument transport is valid.
        refit_outputs = [[str(tmp_path / "unbound-refit.zip"), *next_value["task_ids"]]]
        first_refit = refit_tasks[0]
        changed_refit = copy.deepcopy(first_refit)
        if prepare_family == "GBM_COX":
            changed_refit[2][0]["parameters"]["locked_trees"] += 1
        else:
            changed_refit["locked_rounds" if prepare_family == "XGBOOST_COX" else "locked_epoch"] += 1
        assert f5._a12_q_stop_unit_input(changed_refit, function=refit_function)
        changed_parameters = copy.deepcopy(first_refit)
        if prepare_family == "GBM_COX":
            changed_parameters[2][0]["parameters"]["UNBOUND_PARAMETER"] = 1
        else:
            changed_parameters["candidate" if prepare_family == "COXTIME_SET_A" else "parameters"]["UNBOUND_PARAMETER"] = 1
        with pytest.raises(ContractError, match="F5_PRIMARY_REFIT_PARAMETER_MISMATCH"):
            f5._q_search_task_batch(numeric_spec, refit_function, [changed_parameters, *refit_tasks[1:]])
        with pytest.raises(ContractError, match="F5_PRIMARY_REFIT_STOP_LOCK_MISMATCH"):
            f5._q_search_task_batch(numeric_spec, refit_function, [changed_refit, *refit_tasks[1:]])
        with pytest.raises(ContractError, match="F5_PRIMARY_REFIT_STOP_LOCK_MISMATCH"):
            f5._q_search_task_batch({**numeric_spec,
                "native_search_batch": {**numeric_control, "primary_s1_stop_locks": {}}},
                refit_function, refit_tasks)
        for calls in (refit_tasks, [changed_refit, *refit_tasks[1:]]):
            with pytest.raises(ContractError, match="F5_A12_PREPARED_STOP_INPUT_INVALID"):
                f5._publish_a12_q_stop_inputs(refit_function, f5._q_search_units(refit_function, calls),
                    numeric, {**numeric_control, "q_unit_outputs": refit_outputs,
                        "primary_rsf_preparation": target, "primary_rsf_producer": producer,
                        "primary_compilation_receipt": receipt_path}, next_value["phase"], boundary["input"])
        assert not (tmp_path / "unbound-refit.zip").exists()
        assert successor_receipt["prepared_unit_inputs"]["phase"] == next_value["phase"]
        published_ids = []
        for shard in scoped_refit:
            payload = read_safe_zip(Path(shard[0]))
            record = strict_json_bytes(payload["prepared-q.json"])
            assert record["phase"] == next_value["phase"] and record["task_ids"] == shard[1:]
            assert record["predecessor_execution_sha256"] == next_value["predecessor_execution_sha256"]
            assert record["predecessor_fit_counts"] == {"total": len(units), "stop": len(units)}
            for name, pins in record["units"].items():
                arguments = [record["arguments"][pin] for pin in pins]
                call = arguments if prepare_family == "GBM_COX" else f5._a12_q_python_prepared_call(arguments, stop=False)
                assert canonical_json_bytes(call) == canonical_json_bytes(
                    f5._a12_q_stop_unit_input(refit_units[name][0], function=refit_function))
            published_ids.extend(record["task_ids"])
        assert len(published_ids) == len(set(published_ids)) == len(refit_units)
        assert set(published_ids) == set(refit_units)
        for change in ({"confirmed_stop_fits": 0}, {"used_batches": []},
                       {"prepare_only": False}, {"q_unit_outputs": outputs},
                       {"prepared_calls": []},
                       {"prepared_calls": [("UNFITTED_ALREADY_CAPTURED", {})]}, {"prepared_calls": {}}):
            with pytest.raises(ContractError, match="F5_PRIMARY_REFIT_PREPARATION_SCOPE_INVALID"):
                f5._q_search_task_batch({**numeric_spec,
                    "native_search_batch": {**numeric_control, **change}}, refit_function, refit_tasks)
        assert numeric_control["confirmed_stop_fits"] == len(units)
        assert numeric_control["confirmed_model_fits"] == len(units)
        assert len(numeric_control["used_batches"]) == len(history)
        assert [row for row in events if row[0] != "numbers"] == before_native
        assert len([row for row in events if row[0] == "numbers"]) == len(before_native) // 2
        # Prove the original consumer can read the retained numerical copy
        # after the producer batch locations disappear. This qualifies reuse
        # of its existing evidence, not a scalar-lock-only REFIT transport.
        for batch in history:
            batch.rename(batch.with_name(batch.name + "-UNFITTED-retired"))
        name, (stop_call, _) = next(iter(retained_stop_units.items()))
        loss_references = ({"gbm_stop_loss_references": {
            member: numeric_control["references"][f"native/{name}/{member}"]
            for member in ("evaluation.json", "output.json")}}
            if prepare_family == "GBM_COX" else {})
        retained_call = f5._q_search_unit_call(active_function, stop_call, numeric,
            scratch, mode="numbers", **loss_references)
        previous_numbers = len([row for row in events if row[0] == "numbers"])
        active_function(retained_call)
        # GBM reads both its STOP curve and grouped loss record; Python has
        # one original function/evaluation pair event in this fixture.
        assert len([row for row in events if row[0] == "numbers"]) == previous_numbers + (
            2 if prepare_family == "GBM_COX" else 1)
        assert [row for row in events if row[0] != "numbers"] == before_native
        # Consume the actual published REFIT shards through the public worker
        # and original executor. Only the native leaves remain UNFITTED; this
        # does not fit models or assert scientific acceptance.
        refit_history = []
        for index, shard in enumerate(scoped_refit):
            if index == 0:
                wrong_members = read_safe_zip(Path(shard[0]))
                wrong_record = strict_json_bytes(wrong_members["prepared-q.json"])
                wrong_record["predecessor_execution_sha256"][0] = "0" * 64
                wrong_members["prepared-q.json"] = canonical_json_bytes(wrong_record)
                wrong_archive = tmp_path / "unfitted-wrong-refit-predecessor.zip"
                write_deterministic_zip(wrong_archive, wrong_members)
                with monkeypatch.context() as reject_patch:
                    reject_patch.setattr(f5, "_execute_q_search_batch",
                        lambda *a, **k: pytest.fail("WRONG_PREDECESSOR_REACHED_EXECUTOR"))
                    with pytest.raises(ContractError, match="F5_A12_PREPARED_STOP_INPUT_INVALID"):
                        f5.execute_final_complex_search(prepared_q_input=wrong_archive,
                            target=tmp_path / "unfitted-wrong-refit-worker",
                            prepared_q_input_sha256=sha256_file(wrong_archive), task_ids=shard[1:],
                            batch_root=tmp_path / "unfitted-wrong-refit-batch", retained_bytes_per_task=retention_cap,
                            selection_horizon_months=12, candidate_family=prepare_family, primary_outer_prepared=True)
            value = f5.execute_final_complex_search(prepared_q_input=Path(shard[0]),
                target=tmp_path / f"unfitted-refit-worker-{index}",
                prepared_q_input_sha256=sha256_file(Path(shard[0])), task_ids=shard[1:],
                batch_root=tmp_path / f"unfitted-refit-batch-{index}", retained_bytes_per_task=retention_cap,
                selection_horizon_months=12, candidate_family=prepare_family, primary_outer_prepared=True)
            assert value["status"] == "COMPUTED_Q_BATCH"
            refit_history.append((Path(value["batch_root"]), value["execution"]))
        native_before_refit_consumption = [row for row in events if row[0] != "numbers"]
        complete_s1 = [batch.with_name(batch.name + "-UNFITTED-retired") for batch in history]
        complete_s1.extend(batch for batch, _ in refit_history)
        if continuous_stop_pair:
            owner = tmp_path / "continuous-stop-batches"
            owner.mkdir()
            authorized = dict(f5._a12_q_stop_phase("S2", refit=refit, family=prepare_family)
                              for refit in (False, True))
            original_consumer = f5._consume_q_search_batches
            consumed = []
            def observing_consumer(spec, function, actual_units, batches, phase, input_ref):
                for path, record in batches:
                    assert (path / "execution.json").read_bytes() == canonical_json_bytes(record)
                value = original_consumer(spec, function, actual_units, batches, phase, input_ref)
                if phase in authorized:
                    consumed.extend(record for _, record in batches)
                return value
            monkeypatch.setattr(f5, "_consume_q_search_batches", observing_consumer)
            result_root = tmp_path / "continuous-stop-result"
            report = original_prepare(execution_projections[-1], result_root, policy,
                family=prepare_family, prepared_calls=[], retained_q_input=retained_input,
                retained_input_producer=producer, retained_bytes_per_task=retention_cap,
                admit_io=lambda **kwargs: None,
                batch_options={"prepare_only": True, "task_ids": None, "batch_root": None,
                    "q_batches": complete_s1, "retained_bytes_per_task": retention_cap},
                _execution_batch_root=owner, _execution_phase_task_ids=authorized)
            assert len(consumed) == 2 and [row["phase"] for row in consumed] == list(authorized)
            assert all(row["task_ids"] == authorized[row["phase"]] for row in consumed)
            phase, ids = f5._a12_q_stop_phase("S3A", family=prepare_family)
            counts = f5._a12_q_prepared_predecessors("S3A", refit=False, family=prepare_family, full0=True)
            assert report["status"] == "PREPARED_Q_BATCH" and report["phase"] == phase
            assert report["task_ids"] == ids and report["confirmed_model_fits"] == counts["total"]
            assert report["confirmed_stop_fits"] == counts["stop"]
            assert report["new_model_fits"] == sum(row["new_model_fit_count"] for row in consumed)
            assert report["new_stop_fits"] == consumed[0]["new_model_fit_count"]
            assert not (owner / phase).exists()
            saved = strict_json_bytes((result_root / "result.json").read_bytes())
            assert saved["new_model_fits"] == saved["new_stop_fits"] == 0
            monkeypatch.setattr(f5, "_execute_q_search_batch", lambda *a, **k: pytest.fail("S3A_EXECUTION_FORBIDDEN"))
            published_zip = tmp_path / "continuous-stop-s3a.zip"
            worker_zip = tmp_path / "continuous-stop-s3a-worker.zip"
            receipt = f4.compile_o_fit_bundle(tmp_path, published_zip, outer_fold=1,
                science_decision=decision, resource_policy=policy,
                retained_bytes_per_component=retention_cap, expanded_bytes_per_component=10**6,
                shared_storage_bytes=10**9, primary_rsf_prepare=True, primary_prepare_family=prepare_family,
                primary_retained_q_input=retained_input, primary_producer_source_bundle=producer,
                primary_q_unit_outputs=[[str(worker_zip), *ids]],
                primary_q_batch_options={"prepare_only": True, "task_ids": None, "batch_root": None,
                    "q_batches": complete_s1 + [owner / p for p in authorized], "retained_bytes_per_task": retention_cap})
            _, direct_tasks = f5._primary_rsf_prepared_input(retained_input.read_bytes(), published_zip,
                producer, compilation_receipt=receipt)
            assert worker_zip.is_file() and list(direct_tasks) == ids
            assert direct_tasks == {row["task_id"]: row["producer_tasks"] for row in saved["next_atomic_units"]}
            return
        s2_archive = tmp_path / "unfitted-s2-preparation.zip"
        s2_ids = f5._a12_q_stop_phase("S2", family=prepare_family)[1]
        s2_outputs = [[str(tmp_path / f"unfitted-s2-shard-{i}.zip"), *s2_ids[i::2]] for i in range(2)]
        with monkeypatch.context() as owner_patch:
            owner_patch.setattr(f5, "_q_search_batch_control", observe_control)
            s2_receipt = f4.compile_o_fit_bundle(tmp_path, s2_archive, outer_fold=1,
                science_decision=decision, resource_policy=policy,
                retained_bytes_per_component=retention_cap, expanded_bytes_per_component=10**6,
                shared_storage_bytes=10**9, primary_rsf_prepare=True,
                primary_prepare_family=prepare_family, primary_retained_q_input=retained_input,
                primary_q_unit_outputs=s2_outputs, primary_producer_source_bundle=producer,
                primary_q_batch_options={"prepare_only": True, "task_ids": None, "batch_root": None,
                    "q_batches": complete_s1, "retained_bytes_per_task": retention_cap})
        assert len(owner_controls) == 2
        s2_control = owner_controls[-1]
        s2_function, s2_units = s2_control["prepared_calls"][-1]
        assert s2_receipt["phase"] == f5._a12_q_stop_phase("S2", family=prepare_family)[0]
        assert s2_receipt["confirmed_model_fits"] == 2 * len(units)
        assert s2_receipt["confirmed_stop_fits"] == len(units)
        assert s2_receipt["new_model_fits"] == s2_receipt["new_stop_fits"] == 0
        assert s2_receipt["worker_inputs_ready"] is s2_receipt["stage_acceptance"] is False
        assert len(s2_receipt["predecessor_execution_sha256"]) == len(complete_s1)
        s2_members = read_safe_zip(s2_archive)
        assert {"input.json", "result.json", "numbers.json"} <= set(s2_members)
        assert strict_json_bytes(s2_members["result.json"])["phase"] == s2_receipt["phase"]
        _, s2_tasks = f5._primary_rsf_prepared_input(s2_members["input.json"], s2_archive,
            producer, compilation_receipt=s2_receipt)
        assert list(s2_tasks) == s2_receipt["task_ids"]
        assert [{"task_id": name, "producer_tasks": rows} for name, rows in s2_tasks.items()] == (
            s2_receipt["next_atomic_units"])
        altered_s2 = strict_json_bytes(s2_members["result.json"])
        altered_s2["next_atomic_units"][0]["producer_tasks"][0]["seed"] += 1
        altered_s2_members = dict(s2_members)
        altered_s2_members["result.json"] = canonical_json_bytes(altered_s2)
        index = strict_json_bytes(altered_s2_members["numbers.json"])
        index["result_sha256"] = sha256_bytes(altered_s2_members["result.json"])
        index["members"]["result.json"] = {"sha256": index["result_sha256"],
            "size_bytes": len(altered_s2_members["result.json"])}
        index["identity_sha256"] = sha256_bytes(canonical_json_bytes({
            key: value for key, value in index.items() if key != "identity_sha256"}))
        altered_s2_members["numbers.json"] = canonical_json_bytes(index)
        changed_s2 = tmp_path / "unfitted-s2-wrong-seed.zip"
        write_deterministic_zip(changed_s2, altered_s2_members)
        with pytest.raises(ContractError, match="F5_PRIMARY_RSF_PREPARED_SOURCE_INVALID"):
            f5._primary_rsf_prepared_input(s2_members["input.json"], changed_s2, producer,
                compilation_receipt={**s2_receipt, **altered_s2,
                    "sha256": sha256_file(changed_s2), "size_bytes": changed_s2.stat().st_size,
                    "preparation_metadata": {name: {"sha256": sha256_bytes(altered_s2_members[name]),
                        "size_bytes": len(altered_s2_members[name])} for name in s2_receipt["preparation_metadata"]}})
        assert [row for row in events if row[0] != "numbers"] == native_before_refit_consumption
        if transport_only:
            # The changed transport boundary is already through the real
            # worker, numerical consumer and next preparation. Reuse the
            # independent full-tail evidence rather than repeat every stage.
            for shard in scoped_refit:
                delivered = read_safe_zip(Path(shard[0]))
                assert "source/primary-preparation.zip" not in delivered
                scoped_metadata = {name.removeprefix("source/primary-preparation/"): raw
                    for name, raw in delivered.items() if name.startswith("source/primary-preparation/")}
                assert set(scoped_metadata) == {"input.json", "result.json", "numbers.json"}
                assert scoped_metadata == {name: successor_members[name] for name in scoped_metadata}
            assert any(name.startswith("native/") for name in successor_members)
            return
        s2_history = []
        for index, shard in enumerate(s2_outputs):
            value = f5.execute_final_complex_search(prepared_q_input=Path(shard[0]),
                target=tmp_path / f"unfitted-s2-worker-{index}",
                prepared_q_input_sha256=sha256_file(Path(shard[0])), task_ids=shard[1:],
                batch_root=tmp_path / f"unfitted-s2-batch-{index}", retained_bytes_per_task=retention_cap,
                selection_horizon_months=12, candidate_family=prepare_family, primary_outer_prepared=True)
            assert value["status"] == "COMPUTED_Q_BATCH"
            s2_history.append((Path(value["batch_root"]), value["execution"]))
        s2_control["batches"].extend(s2_history)
        s2_spec = {**q_input["spec"], "native_search_root": str(Path(s2_receipt["native_search_root"]) / "native"),
            "native_search_replay": False, "native_search_batch": s2_control}
        native_before_s2_consumption = [row for row in events if row[0] != "numbers"]
        with pytest.raises(ContractError, match="F5_PRIMARY_PREPARED_Q_NUMERICAL_SCOPE_INVALID"):
            f5._consume_q_search_batches({**s2_spec, "native_search_batch": {
                **s2_control, "confirmed_model_fits": s2_control["confirmed_model_fits"] - 1}},
                s2_function, s2_units, s2_history, s2_receipt["phase"], boundary["input"])
        s2_refit_archive = tmp_path / "unfitted-s2-refit-preparation.zip"
        s2_refit_ids = f5._a12_q_stop_phase("S2", refit=True, family=prepare_family)[1]
        s2_refit_outputs = [[str(tmp_path / f"unfitted-s2-refit-shard-{i}.zip"),
                            *s2_refit_ids[i::2]] for i in range(2)]
        with monkeypatch.context() as owner_patch:
            owner_patch.setattr(f5, "_q_search_batch_control", observe_control)
            s2_refit = f4.compile_o_fit_bundle(tmp_path, s2_refit_archive, outer_fold=1,
                science_decision=decision, resource_policy=policy,
                retained_bytes_per_component=retention_cap, expanded_bytes_per_component=10**6,
                shared_storage_bytes=10**9, primary_rsf_prepare=True,
                primary_prepare_family=prepare_family, primary_retained_q_input=retained_input,
                primary_q_unit_outputs=s2_refit_outputs, primary_producer_source_bundle=producer,
                primary_q_batch_options={"prepare_only": True, "task_ids": None, "batch_root": None,
                    "q_batches": [*complete_s1, *(batch for batch, _ in s2_history)], "retained_bytes_per_task": retention_cap})
        assert (s2_refit["phase"], s2_refit["task_ids"]) == f5._a12_q_stop_phase(
            "S2", refit=True, family=prepare_family)
        assert s2_refit["confirmed_model_fits"] == 2 * len(units) + len(s2_units)
        assert s2_refit["confirmed_stop_fits"] == len(units) + len(s2_units)
        assert s2_refit["worker_inputs_ready"] is s2_refit["stage_acceptance"] is False
        assert s2_refit["new_model_fits"] == s2_refit["new_stop_fits"] == 0
        assert {"input.json", "result.json", "numbers.json"} <= set(read_safe_zip(s2_refit_archive))
        assert [row for row in events if row[0] != "numbers"] == native_before_s2_consumption
        s2_refit_control = owner_controls[-1]
        s2_refit_function, s2_refit_units = s2_refit_control["prepared_calls"][-1]
        assert len(s2_refit_control["prepared_calls"]) == 4
        s2_refit_history = []
        for index, shard in enumerate(s2_refit_outputs):
            value = f5.execute_final_complex_search(prepared_q_input=Path(shard[0]),
                target=tmp_path / f"unfitted-s2-refit-worker-{index}",
                prepared_q_input_sha256=sha256_file(Path(shard[0])), task_ids=shard[1:],
                batch_root=tmp_path / f"unfitted-s2-refit-batch-{index}", retained_bytes_per_task=retention_cap,
                selection_horizon_months=12, candidate_family=prepare_family, primary_outer_prepared=True)
            assert value["status"] == "COMPUTED_Q_BATCH"
            s2_refit_history.append((Path(value["batch_root"]), value["execution"]))
        s2_refit_control["batches"].extend(s2_refit_history)
        s2_refit_spec = {**q_input["spec"],
            "native_search_root": str(Path(s2_refit["native_search_root"]) / "native"),
            "native_search_replay": False, "native_search_batch": s2_refit_control}
        before_s2_refit_consume = [row for row in events if row[0] != "numbers"]
        produced = f5._consume_q_search_batches(s2_refit_spec, s2_refit_function,
            s2_refit_units, s2_refit_history, s2_refit["phase"], boundary["input"])
        assert len(produced) == len(s2_refit_units)
        assert s2_refit_control["confirmed_model_fits"] == 2 * (len(units) + len(s2_units))
        assert s2_refit_control["confirmed_stop_fits"] == len(units) + len(s2_units)
        assert [row for row in events if row[0] != "numbers"] == before_s2_refit_consume
        s3a_archive = tmp_path / "unfitted-s3a-preparation.zip"
        s3a_ids = f5._a12_q_stop_phase("S3A", family=prepare_family)[1]
        s3a_outputs = [[str(tmp_path / f"unfitted-s3a-shard-{i}.zip"), *s3a_ids[i::7]] for i in range(7)]
        with monkeypatch.context() as owner_patch:
            owner_patch.setattr(f5, "_q_search_batch_control", observe_control)
            s3a_receipt = f4.compile_o_fit_bundle(tmp_path, s3a_archive, outer_fold=1,
                science_decision=decision, resource_policy=policy,
                retained_bytes_per_component=retention_cap, expanded_bytes_per_component=10**6,
                shared_storage_bytes=10**9, primary_rsf_prepare=True,
                primary_prepare_family=prepare_family, primary_retained_q_input=retained_input,
                primary_q_unit_outputs=s3a_outputs, primary_producer_source_bundle=producer,
                primary_q_batch_options={"prepare_only": True, "task_ids": None, "batch_root": None,
                    "q_batches": [*complete_s1, *(batch for batch, _ in s2_history),
                                  *(batch for batch, _ in s2_refit_history)], "retained_bytes_per_task": retention_cap})
        assert (s3a_receipt["phase"], s3a_receipt["task_ids"]) == f5._a12_q_stop_phase(
            "S3A", family=prepare_family)
        assert s3a_receipt["confirmed_model_fits"] == 2 * (len(units) + len(s2_units))
        assert s3a_receipt["confirmed_stop_fits"] == len(units) + len(s2_units)
        assert s3a_receipt["new_model_fits"] == s3a_receipt["new_stop_fits"] == 0
        assert s3a_receipt["worker_inputs_ready"] is s3a_receipt["stage_acceptance"] is False
        assert [row for row in events if row[0] != "numbers"] == before_s2_refit_consume
        s3a_control = owner_controls[-1]
        s3a_function, s3a_units = s3a_control["prepared_calls"][-1]
        assert len(s3a_control["prepared_calls"]) == 5
        s3a_history = []
        for index, shard in enumerate(s3a_outputs):
            value = f5.execute_final_complex_search(prepared_q_input=Path(shard[0]),
                target=tmp_path / f"unfitted-s3a-worker-{index}",
                prepared_q_input_sha256=sha256_file(Path(shard[0])), task_ids=shard[1:],
                batch_root=tmp_path / f"unfitted-s3a-batch-{index}", retained_bytes_per_task=retention_cap,
                selection_horizon_months=12, candidate_family=prepare_family, primary_outer_prepared=True)
            assert value["status"] == "COMPUTED_Q_BATCH"
            s3a_history.append((Path(value["batch_root"]), value["execution"]))
        s3a_control["batches"].extend(s3a_history)
        s3a_spec = {**q_input["spec"],
            "native_search_root": str(Path(s3a_receipt["native_search_root"]) / "native"),
            "native_search_replay": False, "native_search_batch": s3a_control}
        before_s3a_consume = [row for row in events if row[0] != "numbers"]
        with pytest.raises(ContractError, match="F5_PRIMARY_PREPARED_Q_NUMERICAL_SCOPE_INVALID"):
            f5._consume_q_search_batches({**s3a_spec, "native_search_batch": {
                **s3a_control, "confirmed_model_fits": s3a_control["confirmed_model_fits"] - 1}},
                s3a_function, s3a_units, s3a_history, s3a_receipt["phase"], boundary["input"])
        produced = f5._consume_q_search_batches(s3a_spec, s3a_function,
            s3a_units, s3a_history, s3a_receipt["phase"], boundary["input"])
        assert len(produced) == len(s3a_units)
        assert s3a_control["confirmed_model_fits"] == 2 * (len(units) + len(s2_units)) + len(s3a_units)
        assert s3a_control["confirmed_stop_fits"] == len(units) + len(s2_units) + len(s3a_units)
        assert [row for row in events if row[0] != "numbers"] == before_s3a_consume
        s3a_refit_archive = tmp_path / "unfitted-s3a-refit-preparation.zip"
        s3a_refit_ids = f5._a12_q_stop_phase("S3A", refit=True, family=prepare_family)[1]
        s3a_refit_outputs = [[str(tmp_path / f"unfitted-s3a-refit-shard-{i}.zip"),
                             *s3a_refit_ids[i::7]] for i in range(7)]
        with monkeypatch.context() as owner_patch:
            owner_patch.setattr(f5, "_q_search_batch_control", observe_control)
            s3a_refit = f4.compile_o_fit_bundle(tmp_path, s3a_refit_archive, outer_fold=1,
                science_decision=decision, resource_policy=policy,
                retained_bytes_per_component=retention_cap, expanded_bytes_per_component=10**6,
                shared_storage_bytes=10**9, primary_rsf_prepare=True,
                primary_prepare_family=prepare_family, primary_retained_q_input=retained_input,
                primary_q_unit_outputs=s3a_refit_outputs, primary_producer_source_bundle=producer,
                primary_q_batch_options={"prepare_only": True, "task_ids": None, "batch_root": None,
                    "q_batches": [*complete_s1, *(batch for batch, _ in s2_history),
                                  *(batch for batch, _ in s2_refit_history), *(batch for batch, _ in s3a_history)],
                    "retained_bytes_per_task": retention_cap})
        assert (s3a_refit["phase"], s3a_refit["task_ids"]) == f5._a12_q_stop_phase(
            "S3A", refit=True, family=prepare_family)
        assert s3a_refit["confirmed_model_fits"] == 2 * (len(units) + len(s2_units)) + len(s3a_units)
        assert s3a_refit["confirmed_stop_fits"] == len(units) + len(s2_units) + len(s3a_units)
        assert s3a_refit["new_model_fits"] == s3a_refit["new_stop_fits"] == 0
        assert s3a_refit["worker_inputs_ready"] is s3a_refit["stage_acceptance"] is False
        assert [row for row in events if row[0] != "numbers"] == before_s3a_consume
        s3a_refit_control = owner_controls[-1]
        s3a_refit_function, s3a_refit_units = s3a_refit_control["prepared_calls"][-1]
        assert len(s3a_refit_control["prepared_calls"]) == 6
        s3a_refit_history = []
        for index, shard in enumerate(s3a_refit_outputs):
            value = f5.execute_final_complex_search(prepared_q_input=Path(shard[0]),
                target=tmp_path / f"unfitted-s3a-refit-worker-{index}",
                prepared_q_input_sha256=sha256_file(Path(shard[0])), task_ids=shard[1:],
                batch_root=tmp_path / f"unfitted-s3a-refit-batch-{index}", retained_bytes_per_task=retention_cap,
                selection_horizon_months=12, candidate_family=prepare_family, primary_outer_prepared=True)
            assert value["status"] == "COMPUTED_Q_BATCH"
            s3a_refit_history.append((Path(value["batch_root"]), value["execution"]))
        s3a_refit_control["batches"].extend(s3a_refit_history)
        s3a_refit_spec = {**q_input["spec"],
            "native_search_root": str(Path(s3a_refit["native_search_root"]) / "native"),
            "native_search_replay": False, "native_search_batch": s3a_refit_control}
        before_s3a_refit_consume = [row for row in events if row[0] != "numbers"]
        produced = f5._consume_q_search_batches(s3a_refit_spec, s3a_refit_function,
            s3a_refit_units, s3a_refit_history, s3a_refit["phase"], boundary["input"])
        assert len(produced) == len(s3a_refit_units)
        assert s3a_refit_control["confirmed_model_fits"] == 2 * (len(units) + len(s2_units) + len(s3a_units))
        assert s3a_refit_control["confirmed_stop_fits"] == len(units) + len(s2_units) + len(s3a_units)
        assert [row for row in events if row[0] != "numbers"] == before_s3a_refit_consume
        complete_prefix = [*complete_s1, *(batch for batch, _ in s2_history),
            *(batch for batch, _ in s2_refit_history), *(batch for batch, _ in s3a_history),
            *(batch for batch, _ in s3a_refit_history)]
        for stage in ("S3B1", "S3B2"):
            for refit in (False, True):
                label = stage.lower() + ("-refit" if refit else "-stop")
                phase, ids = f5._a12_q_stop_phase(stage, refit=refit, family=prepare_family)
                archive = tmp_path / f"unfitted-{label}-preparation.zip"
                outputs = [[str(tmp_path / f"unfitted-{label}-shard-{i}.zip"), *ids[i::7]] for i in range(7)]
                before_prepare = [row for row in events if row[0] != "numbers"]
                receipt = f4.compile_o_fit_bundle(tmp_path, archive, outer_fold=1,
                    science_decision=decision, resource_policy=policy,
                    retained_bytes_per_component=retention_cap, expanded_bytes_per_component=10**6,
                    shared_storage_bytes=10**9, primary_rsf_prepare=True,
                    primary_prepare_family=prepare_family, primary_retained_q_input=retained_input,
                    primary_q_unit_outputs=outputs, primary_producer_source_bundle=producer,
                    primary_q_batch_options={"prepare_only": True, "task_ids": None, "batch_root": None,
                        "q_batches": complete_prefix, "retained_bytes_per_task": retention_cap})
                counts = f5._a12_q_prepared_predecessors(stage, refit=refit, family=prepare_family, full0=True)
                assert receipt["phase"] == phase and receipt["task_ids"] == ids
                assert receipt["confirmed_model_fits"] == counts["total"]
                assert receipt["confirmed_stop_fits"] == counts["stop"]
                assert receipt["new_model_fits"] == receipt["new_stop_fits"] == 0
                assert [row for row in events if row[0] != "numbers"] == before_prepare
                for index, shard in enumerate(outputs):
                    value = f5.execute_final_complex_search(prepared_q_input=Path(shard[0]),
                        target=tmp_path / f"unfitted-{label}-worker-{index}",
                        prepared_q_input_sha256=sha256_file(Path(shard[0])), task_ids=shard[1:],
                        batch_root=tmp_path / f"unfitted-{label}-batch-{index}", retained_bytes_per_task=retention_cap,
                        selection_horizon_months=12, candidate_family=prepare_family, primary_outer_prepared=True)
                    assert value["status"] == "COMPUTED_Q_BATCH"
                    complete_prefix.append(Path(value["batch_root"]))
        before_complete = [row for row in events if row[0] != "numbers"]
        complete_archive = tmp_path / "unfitted-complete-primary-q.zip"
        original_complete_validator = f5._validate_shared_complex_search_result
        def inspect_complete(result, task, **kwargs):
            try:
                return original_complete_validator(result, task, **kwargs)
            except ContractError:
                (tmp_path / "unfitted-rejected-complete-result.json").write_bytes(canonical_json_bytes(result))
                raise
        monkeypatch.setattr(f5, "_validate_shared_complex_search_result", inspect_complete)
        complete = f4.compile_o_fit_bundle(tmp_path, complete_archive, outer_fold=1,
            science_decision=decision, resource_policy=policy,
            retained_bytes_per_component=retention_cap, expanded_bytes_per_component=10**6,
            shared_storage_bytes=10**9, primary_rsf_prepare=True,
            primary_prepare_family=prepare_family, primary_retained_q_input=retained_input,
            primary_q_batch_options={"prepare_only": True, "task_ids": None, "batch_root": None,
                "q_batches": complete_prefix, "retained_bytes_per_task": retention_cap})
        assert complete["status"] == "COMPUTED_Q_SEARCH" and complete["stage_acceptance"] is False
        assert complete["new_model_fits"] == complete["new_stop_fits"] == 0
        assert complete["s1_summary_recovery_calls"] == complete["s3b2_numerical_consumer_calls"] == 0
        assert [row for row in events if row[0] != "numbers"] == before_complete
        stop_count = {"GBM_COX": 1140, "XGBOOST_COX": 1300, "COXTIME_SET_A": 810}[prepare_family]
        assert complete["scientific_result"]["total_search_fit_count"] == 2 * stop_count
        assert complete["scientific_result"]["response_free_stopping_fit_count"] == stop_count
        complete_members = read_safe_zip(complete_archive)
        assert strict_json_bytes(complete_members["result.json"]) == complete["scientific_result"]
        assert {"input.json", "result.json", "execution.json", "numbers.json"} <= set(complete_members)
        assert list(complete["scientific_result"]["search_trace"]) == ["S1", "S2", "S3A", "S3B1", "S3B2"]
        return
    from padml.f4_compact import _full_pipeline_q_numerical_members
    roots = {}
    if completed_q_archive is not None:
        from padml.bundle import extract_safe_zip, inspect_safe_zip_manifest
        retained_root = tmp_path / "UNFITTED-retained-complete-Q"
        _, names = inspect_safe_zip_manifest(completed_q_archive, manifest_name="numbers.json",
            max_manifest_bytes=16 * 1024**2, max_member_bytes=1024**3, max_total_bytes=4 * 1024**3)
        extract_safe_zip(completed_q_archive, retained_root, expected_members=set(names),
            max_member_bytes=1024**3, max_total_bytes=4 * 1024**3)
        retained = {key: strict_json_bytes((retained_root / (key + ".json")).read_bytes())
                    for key in ("input", "result")}
        retained_family = retained["result"]["family"]
        assert retained["input"]["task"]["training_context"] == context
        assert retained["input"]["task"]["science_decision"] == decision
        bound[retained_family] = retained
        roots[retained_family] = retained_root
    for family, search in bound.items():
        if family in roots:
            continue
        root = tmp_path / ("UNFITTED-Q-" + family)
        (root / "native" / "UNFITTED").mkdir(parents=True)
        (root / "native" / "UNFITTED" / "model.rds").write_bytes(b"UNFITTED")
        for key in ("input", "result"):
            (root / (key + ".json")).write_bytes(canonical_json_bytes(search[key]))
        _full_pipeline_q_numerical_members(root, publish=True)
        roots[family] = root
    compiled = f4.compile_o_fit_bundle(tmp_path, target, outer_fold=1, science_decision=decision,
        resource_policy=policy, retained_bytes_per_component=10**7, expanded_bytes_per_component=10**6,
        shared_storage_bytes=10**9 if actual_projection else 10**8,
        selection_horizon_months=12, primary_search_roots=roots,
        **({"primary_search_source_bundles": {"RSF": retained_q_source}}
           if retained_q_source is not None else {}))
    consumed = f4._materialize_o_fit_input_bundle(target, tmp_path / "read")
    assert calls == ([] if actual_projection else ["UNFITTED_ACCEPTED_PROJECTION"])
    assert compiled["model_fit_count"] == compiled["heldout_response_member_count"] == 0
    assert consumed["selection_horizon_months"] == 12 and consumed["primary_searches"] == bound
    assert len(consumed["component_records"]) == 2100 and len(consumed["post_lock_templates"]) == 140
    if retained_q_source is not None:
        pin = consumed["primary_search_sources"]["RSF"]
        assert pin["sha256"] == f4.sha256_file(retained_q_source)
        assert f4.sha256_file(tmp_path / "read" / pin["path"]) == pin["sha256"]
        assert consumed["training_context"] == context
        assert consumed["primary_searches"]["RSF"]["input"]["task"]["training_context"] == prior_context
    # Same physical input with an independently resealed wrong-line binding
    # must fail before extracting any component or starting a native engine.
    from padml.bundle import read_safe_zip, write_deterministic_zip
    entries = read_safe_zip(target)
    wrong = strict_json_bytes(entries["o-fit-input.json"])
    wrong["selection_horizon_months"] = 24
    wrong = nested._sealed({k: v for k, v in wrong.items() if k != "identity_sha256"})
    entries["o-fit-input.json"] = canonical_json_bytes(wrong)
    altered = tmp_path / "wrong-line.zip"
    write_deterministic_zip(altered, entries)
    with pytest.raises(ContractError, match="F4_O_FIT_SELECTION_SCOPE_INVALID"):
        f4._materialize_o_fit_input_bundle(altered, tmp_path / "rejected")
    assert not (tmp_path / "rejected").exists()


def test_partial_primary_rsf_prefix_reaches_original_successor_workers(aar_source, tmp_path, monkeypatch):
    test_primary12_public_archive_preserves_q_through_original_input_reader(
        aar_source, tmp_path, monkeypatch, True, "RSF", True, partial_s1_history=True)


@pytest.mark.parametrize("family", ["GBM_COX", "XGBOOST_COX", "COXTIME_SET_A"])
def test_primary_stop_pair_continuous_original_consumer(aar_source, tmp_path, monkeypatch, family):
    test_primary12_public_archive_preserves_q_through_original_input_reader(
        aar_source, tmp_path, monkeypatch, True, family, True, continuous_stop_pair=True)


def test_primary_rsf_continuous_terminal_persists_then_original_consumer(aar_source, tmp_path, monkeypatch):
    test_primary12_public_archive_preserves_q_through_original_input_reader(
        aar_source, tmp_path, monkeypatch, True, "RSF", True, continuous_terminal=True)


def test_primary_rsf_saved_summary_owner_reaches_original_terminal_reader(aar_source, tmp_path, monkeypatch):
    """UNFITTED complete owner; source/history seam is not historical acceptance."""
    test_primary12_public_archive_preserves_q_through_original_input_reader(
        aar_source, tmp_path, monkeypatch, True, "RSF", True, continuous_terminal="summary-owner")


def test_primary_rsf_two_stages_stop_at_unauthorized_s3b1(aar_source, tmp_path, monkeypatch):
    test_primary12_public_archive_preserves_q_through_original_input_reader(
        aar_source, tmp_path, monkeypatch, True, "RSF", True, continuous_terminal="two-stages")


def test_mixed_producer_q_reaches_original_score_archive(aar_source, tmp_path, monkeypatch):
    """Original source proof, compiler, projection and reader; science leaves UNFITTED."""
    import os
    from pathlib import Path
    source = os.environ.get("PADML_RETAINED_FULL0_SOURCE_BUNDLE")
    if source is None:
        pytest.skip("requires retained original PRIMARY source")
    test_primary12_public_archive_preserves_q_through_original_input_reader(
        aar_source, tmp_path, monkeypatch, True, None, False, retained_q_source=Path(source))


@pytest.mark.parametrize("family", ["RSF", "GBM_COX", "XGBOOST_COX", "COXTIME_SET_A"])
def test_retained_complete_q_archive_reaches_original_score_compiler(aar_source, tmp_path, monkeypatch, family):
    """Reuse a prior UNFITTED complete chain under its exact saved source.

    Other family Q leaves remain explicit fixtures. Never rerun the retained
    search, rewrite its producer identity or interpret this as real science.
    """
    import os
    from pathlib import Path
    archive = os.environ.get("PADML_UNFITTED_COMPLETE_" + family)
    if archive is None:
        pytest.skip("Retained UNFITTED complete-Q archive not supplied")
    path = Path(archive)
    assert path.is_absolute() and path.is_file()
    test_primary12_public_archive_preserves_q_through_original_input_reader(
        aar_source, tmp_path, monkeypatch, True, None, False, completed_q_archive=path)


@pytest.mark.parametrize("family", ["XGBOOST_COX", "COXTIME_SET_A"])
def test_retained_primary_score_input_reaches_original_worker(tmp_path, monkeypatch, family):
    """Continue the retained compiled input with one UNFITTED score atom."""
    import os
    import zipfile
    from pathlib import Path
    from padml import runtime
    from padml.bundle import inspect_safe_zip_manifest, sha256_file
    from test_nested_full_score import _unfitted_score_shard_engines
    archive = os.environ.get("PADML_UNFITTED_SCORE_" + family)
    if archive is None:
        pytest.skip("Retained UNFITTED score-input archive not supplied")
    source = Path(archive)
    original_sha = sha256_file(source)
    raw, _ = inspect_safe_zip_manifest(source, manifest_name="o-fit-input.json",
        max_manifest_bytes=16 * 1024**2)
    inputs = strict_json_bytes(raw)
    selected = inputs["primary_searches"][family]["result"]["selected_spec"]
    calls = _unfitted_score_shard_engines(monkeypatch)
    original_engine = f5._execute_final_refit_engine
    observed = []
    def inspect_engine(received_family, task, *args, **kwargs):
        assert received_family == family and task["parameters"] == selected
        observed.append(task["parameters"])
        return original_engine(received_family, task, *args, **kwargs)
    monkeypatch.setattr(f5, "_execute_final_refit_engine", inspect_engine)
    monkeypatch.setattr(runtime, "effective_cpu_count", lambda: 32)
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda root: {
        "effective_cpus": 32, "available_memory_bytes": 10**12,
        "scratch_available_bytes": 10**12, "scratch_root": str(root)})
    monkeypatch.setattr(f4, "_bounded_ordered_spawn", runtime._bounded_ordered_spawn)
    target = tmp_path / "UNFITTED-outer.zip"
    prepared = f4.execute_o_fit_bundle(target=target, input_bundle=source, outer_fold=1, prepare_only=True)
    assert prepared["new_model_fits"] == 0 and len(prepared["task_ids"]) == 2100 and not calls
    task_id = next(name for name in prepared["task_ids"] if "/" + family + "/" in name)
    root = target.with_name(target.name + ".work")
    value = f4.execute_o_fit_bundle(target=target, input_bundle=source, outer_fold=1,
        task_ids=[task_id], batch_root=root / "score-batches/one-original-atom")
    assert len(calls) == 1 and observed
    assert value["new_model_fits"] == value["new_model_native_verification_count"] == 1
    assert value["execution"]["pool"]["completed_task_count"] == 1 and value["result"] is None
    assert not (root / "development-lock.json").exists() and not target.exists()
    templates = [row for row in inputs["post_lock_templates"] if row["family"] == family]
    assert len(templates) == 20
    with zipfile.ZipFile(source) as outer:
        for row in templates:
            with zipfile.ZipFile(io.BytesIO(outer.read(row["path"]))) as component:
                assert strict_json_bytes(component.read("task.json"))["parameters"] == selected
    assert sha256_file(source) == original_sha


def test_historical_s2_compiler_reaches_original_successor_workers(aar_source, tmp_path, monkeypatch):
    test_primary12_public_archive_preserves_q_through_original_input_reader(
        aar_source, tmp_path, monkeypatch, True, "RSF", True,
        partial_s1_history=True, historical_s2=True)
