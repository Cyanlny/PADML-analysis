import fcntl
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

from padml import threshold_analysis as ta


class ThresholdRecoveryTests(unittest.TestCase):
    def test_source_cache_and_drift(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); source = root / 'source'; source.write_bytes(b'frozen')
            cfg = {'revision': 'test', 'source_sha256': {'input': ta.pin(source)['sha256']}}
            identity, _ = ta.qualify({'input': source}, cfg, root)
            with patch.object(ta, 'pin', side_effect=AssertionError('unnecessary hash')):
                self.assertEqual(ta.qualify({'input': source}, cfg, root)[0], identity)
            source.write_bytes(b'drift')
            with self.assertRaisesRegex(RuntimeError, 'FROZEN_ASSOCIATION_INPUT_DRIFT'):
                ta.qualify({'input': source}, cfg, root)

    def test_receipt_refresh_then_zero_read_and_reject_drift(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); source = root/'B0001.rds'; source.write_bytes(b'numbers')
            receipt = root/'receipt.json'
            ta.write_json(receipt, {'identity':'I','status':'COMPLETED','outputs':{
                str(source):{'stat':ta.stat_id(source),'pin':ta.pin(source)}}})
            os.utime(source, ns=(1_800_000_000_000_000_000,1_800_000_000_000_000_000))
            self.assertIsNotNone(ta.retained_receipt(receipt,'I',[source]))
            with patch.object(ta, 'pin', side_effect=AssertionError('repeated hash')):
                ta.retained_receipt(receipt,'I',[source])
            source.write_bytes(b'changed')
            with self.assertRaisesRegex(RuntimeError,'PUBLISHED_TASK_MEMBER_CHANGED'):
                ta.retained_receipt(receipt,'I',[source])

    def test_live_native_lease_blocks_replacement(self):
        # The production child inherits the shared lease even if its launcher exits.
        with tempfile.TemporaryDirectory() as tmp:
            lock = Path(tmp)/'.compute.lock'; lock.touch()
            with lock.open('r+') as lease:
                fcntl.flock(lease,fcntl.LOCK_SH)
                child = subprocess.Popen([sys.executable,'-c',
                    'import sys; print("ready",flush=True); sys.stdin.read()'],
                    stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True,pass_fds=(lease.fileno(),))
                self.assertEqual(child.stdout.readline().strip(),'ready')
            try:
                with lock.open('r+') as other:
                    with self.assertRaises(BlockingIOError):
                        fcntl.flock(other,fcntl.LOCK_EX|fcntl.LOCK_NB)
                child.communicate('finish',timeout=5)
                with lock.open('r+') as other:
                    fcntl.flock(other,fcntl.LOCK_EX|fcntl.LOCK_NB)
            finally:
                if child.poll() is None: child.kill(); child.wait()

    def test_replaced_attempt_cannot_launch(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            for name in ('receipts','numerical','requests','logs'): (root/name).mkdir()
            (root/'.compute.lock').touch()
            ta.write_json(root/'owner.json',{'attempt_id':'new','status':'RUNNING','pid':os.getpid()})
            with patch.object(ta.subprocess,'Popen',side_effect=AssertionError('launched')):
                with self.assertRaisesRegex(RuntimeError,'TASK_OWNER_REPLACED'):
                    ta.run_task({'id':'old','mode':'point','output':str(root),'identity':'I',
                                 'attempt_id':'old','rscript':'not-called'})

    def test_source_drift_cannot_be_recovered_as_success(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)
            for name in ('receipts','numerical','requests','logs'): (root/name).mkdir()
            (root/'.compute.lock').touch()
            source=root/'source'; source.write_bytes(b'frozen')
            records={'input':{'path':str(source),'stat':ta.stat_id(source),'pin':ta.pin(source)}}
            ta.write_json(root/'owner.json',{'attempt_id':'A','status':'RUNNING','pid':os.getpid()})
            class Child:
                pid=os.getpid()
                def wait(self,**kwargs):
                    source.write_bytes(b'drift'); (root/'point.rds').write_bytes(b'bad-numbers'); return 0
            task={'id':'point','mode':'point','identity':'I','output':str(root),'attempt_id':'A',
                  'rscript':'unused','source_records':records}
            with patch.object(ta.subprocess,'Popen',return_value=Child()):
                with self.assertRaisesRegex(RuntimeError,'TASK_SOURCE_CHANGED'): ta.run_task(task)
            source.write_bytes(b'frozen')
            task['source_records']['input']['stat']=ta.stat_id(source)
            with self.assertRaisesRegex(RuntimeError,'TASK_SOURCE_DRIFT_REQUIRES_CAUSAL_REVIEW'): ta.run_task(task)

    def test_cox_publication_interruption_preserves_result_and_marker(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)
            for name in ('receipts','numerical','requests','logs'): (root/name).mkdir()
            (root/'.compute.lock').touch()
            ta.write_json(root/'owner.json',{'attempt_id':'A','status':'RUNNING','pid':os.getpid()})
            task={'id':'cox-1','mode':'cox','spec':{'task':'cox-1'},'identity':'I','output':str(root),
                  'attempt_id':'A','rscript':'unused','source_records':{}}
            result=root/'numerical/cox-1.rds'; marker=result.with_suffix('.rds.started')
            fits=[]
            class Child:
                pid=os.getpid()
                def wait(self,**kwargs):
                    req=ta.read_json(root/'requests/cox-1.json')
                    if req.get('fit_authorized'):
                        fits.append(1); result.write_bytes(b'accepted-result')
                    return 0
            original=ta.write_json
            def fail_receipt(path,value):
                if path.parent.name=='receipts': raise OSError('publication interrupted')
                return original(path,value)
            with patch.object(ta.subprocess,'Popen',return_value=Child()),patch.object(ta,'write_json',side_effect=fail_receipt):
                with self.assertRaisesRegex(OSError,'publication interrupted'): ta.run_task(task)
            self.assertTrue(result.exists()); self.assertTrue(marker.exists())
            with patch.object(ta.subprocess,'Popen',return_value=Child()): ta.run_task(task)
            self.assertEqual(len(fits),1); self.assertFalse(marker.exists())

    def test_native_registration_failure_reaps_child(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)
            for name in ('receipts','numerical','requests','logs'): (root/name).mkdir()
            (root/'.compute.lock').touch()
            ta.write_json(root/'owner.json',{'attempt_id':'A','status':'RUNNING','pid':os.getpid()})
            task={'id':'point','mode':'point','identity':'I','output':str(root),
                  'attempt_id':'A','rscript':'unused','source_records':{}}
            original=ta.write_json; children=[]
            def register(path,value):
                if value.get('native_pid'): raise OSError('registration fsync failed')
                return original(path,value)
            popen=subprocess.Popen
            def spawn(*args,**kwargs):
                child=popen([sys.executable,'-c','import time; time.sleep(30)'],**kwargs)
                children.append(child); return child
            with patch.object(ta,'write_json',side_effect=register),patch.object(ta.subprocess,'Popen',side_effect=spawn):
                with self.assertRaisesRegex(OSError,'registration fsync failed'): ta.run_task(task)
            self.assertIsNotNone(children[0].poll())
            self.assertFalse((root/'receipts/point.json').exists())
            with (root/'.compute.lock').open('r+') as lock:
                fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)


if __name__ == '__main__':
    unittest.main()
