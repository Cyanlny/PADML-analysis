"""Original pre-search compiler/materializer, Linux synthetic-source fixture.

No model engine or native replay is added. Requires the existing R/jsonlite
fixture setup. This is transport/physical-input verification, not acceptance.
"""
import copy
import zipfile

import pytest

from padml import f4, f5, f2_kernel as kernel, nested_loco as nested, runtime
from padml.bundle import ContractError, read_safe_zip, sha256_file, strict_json_bytes
from test_nested_aar_mice import aar_source  # noqa: F401
from test_primary_rsf_score_compilation import (
    test_primary12_public_archive_preserves_q_through_original_input_reader as original_case,
)


def test_original_pre_search_carrier_roundtrip_and_phase_separation(aar_source, tmp_path, monkeypatch):
    # The source fixture later forbids every subprocess, including h5py's
    # non-scientific platform discovery. Import the real engine first, as in
    # the existing CoxTime preparation case; all fitting leaves stay blocked.
    import pycox  # noqa: F401

    original = nested._project_outer_development_from_inputs
    checked = []

    def observe(inputs, **kwargs):
        if not checked and kwargs.get("selection_horizon_months") == 12:
            checked.append(True)
            policy = {"configured_worker_ceiling": runtime.CPU_MINUS_8, "memory_bytes_per_worker": 2 * 1024**3,
                "memory_reserve_bytes": 0, "scratch_bytes_per_worker": 1, "scratch_reserve_bytes": 0,
                "transfer_archive_worker_ceiling": 8}
            source = tmp_path / "pre-search.zip"
            report = f4.compile_o_fit_bundle(kwargs["accepted_f2_run_root"], source,
                outer_fold=1, science_decision=kwargs["science_decision"], resource_policy=policy,
                retained_bytes_per_component=kwargs["retained_bytes_per_component"],
                expanded_bytes_per_component=kwargs["expanded_bytes_per_component"],
                shared_storage_bytes=10**10, selection_horizon_months=12, pre_search=True)
            assert report["phase"] == "PRIMARY_PRE_SEARCH" and report["model_fit_count"] == 0
            assert report["heldout_response_member_count"] == 0
            with zipfile.ZipFile(source) as archive:
                names = set(archive.namelist())
                declared = strict_json_bytes(archive.read("o-fit-input.json"))
            assert not any(name.startswith("components/") for name in names)
            assert not {"component_records", "post_lock_templates", "primary_searches"} & set(declared)
            assert names == {"o-fit-input.json", *declared["members"]}
            assert declared["identity_sha256"] == report["identity_sha256"]
            restored = f4._materialize_o_fit_input_bundle(source, tmp_path / "pre-search-read", pre_search=True)
            state = restored["materialized_pre_search"]
            assert len(f4._o_fit_partitions(state["registered"])) == 31
            assert "identity" not in state["registered"]
            assert "evaluation_response" not in f4._o_fit_partitions(state["registered"])["OUTER", 0, 0]
            producer = tmp_path / "pre-search-producer.zip"
            f4.compile_f45_source_bundle(producer)
            original_members = f4._f45_source_member_sha256()
            original_context = declared["training_context"]
            # A new documentation identity cannot make the same physical
            # MICE/recipe projection require another compilation. The producer
            # remains explicit, and only the next-stage executor context moves.
            with monkeypatch.context() as changed_source:
                current_members = {**original_members, "NESTED_LOCO_PROTOCOL.md": "f" * 64}
                changed_source.setattr(f4, "_f45_source_member_sha256", lambda: current_members)
                with pytest.raises(ContractError, match="PRE_SEARCH_SCOPE"):
                    f4._materialize_o_fit_input_bundle(source, tmp_path / "unbound-old-producer", pre_search=True)
                retained = f4._materialize_o_fit_input_bundle(source, tmp_path / "retained-pre-search-read",
                    pre_search=True, retained_primary_source_bundle=producer)
                assert retained["training_context"] == original_context
                current_context = retained["materialized_pre_search"]["projection"]["training_context"]
                assert current_context["modeling_program_sha256"] == nested._sha(current_members)
                excluded = {"identity_sha256", "modeling_program_sha256"}
                assert {k: v for k, v in current_context.items() if k not in excluded} == {
                    k: v for k, v in original_context.items() if k not in excluded}
                assert retained["materialized_pre_search"]["source_registered_identity"] == state["source_registered_identity"]
                assert retained["pre_search"] == declared["pre_search"]
                current_members["padml/f2_kernel.py"] = "0" * 64
                with pytest.raises(ContractError, match="PRE_SEARCH_NUMERICAL_SOURCE_DRIFT"):
                    f4._materialize_o_fit_input_bundle(source, tmp_path / "changed-numerical-source",
                        pre_search=True, retained_primary_source_bundle=producer)
                assert not (tmp_path / "changed-numerical-source").exists()
            with pytest.raises(ContractError, match="PRE_SEARCH_SCOPE"):
                f4._materialize_o_fit_input_bundle(source, tmp_path / "not-final-scoring")
            assert not (tmp_path / "not-final-scoring").exists()
            with pytest.raises(ContractError, match="PRE_SEARCH_SCOPE"):
                f4._materialize_o_fit_input_bundle(source, tmp_path / "pre-search-read", pre_search=True)
            # The original zero-fit compiler must consume this physical outer
            # projection without asking the owner to acquire full F1/F2 data.
            # Its published calls then pass the actual worker input reader;
            # only the model-execution leaf is replaced by an UNFITTED boundary.
            family = "COXTIME_SET_A"
            phase, ids = f5._a12_q_stop_phase("S1", family=family)
            preparation, worker_input = tmp_path / "scoped-q.zip", tmp_path / "scoped-q-worker.zip"
            with monkeypatch.context() as scoped_compile:
                def forbidden(*args, **kwargs):
                    pytest.fail("SCOPED_PREPARATION_MUST_NOT_REOPEN_CUSTODY_OR_FIT")
                scoped_compile.setattr(f4, "load_f4_inputs", forbidden)
                scoped_compile.setattr(nested, "_project_outer_development_from_inputs", forbidden)
                scoped_compile.setattr(f5, "_execute_q_search_batch", forbidden)
                compiled = f4.compile_o_fit_bundle(None, preparation, outer_fold=1,
                    science_decision=declared["science_decision"], resource_policy=policy,
                    retained_bytes_per_component=declared["retained_bytes_per_component"],
                    expanded_bytes_per_component=declared["expanded_bytes_per_component"],
                    shared_storage_bytes=declared["shared_storage_bytes"],
                    pre_search_input=source, retained_primary_source_bundle=producer,
                    primary_rsf_prepare=True, primary_prepare_family=family,
                    selection_horizon_months=12,
                    primary_q_unit_outputs=[[str(worker_input), *ids]],
                    primary_producer_source_bundle=producer)
                assert compiled["phase"] == phase and compiled["task_ids"] == ids
                assert compiled["new_model_fits"] == compiled["new_stop_fits"] == 0
                assert compiled["heldout_response_member_count"] == 0
                # This is the pre-publication compilation receipt, which the
                # worker verifies verbatim; publication is a separate field.
                assert compiled["worker_inputs_ready"] is False
                published = compiled.pop("prepared_unit_inputs")
                assert len(published["outputs"]) == 1 and published["outputs"][0]["path"] == str(worker_input)
                q_input = read_safe_zip(preparation)["input.json"]
                child, atoms = f5._primary_rsf_prepared_input(q_input, preparation, producer,
                    compilation_receipt=compiled)
                assert child["family"] == family and set(atoms) == set(ids)
                assert child["registered_inputs_identity_sha256"] == state["source_registered_identity"]
                reached = []
                def input_reader_boundary(function, units, root, control, observed_phase, input_ref, **kwargs):
                    assert function is kernel._run_python_stop_pair_pool_task
                    assert observed_phase == phase and list(units) == ids
                    call = next(iter(units.values()))[0]
                    assert "identity" not in call[0]["registered"]
                    assert call[0]["registered"]["source_registered_identity"] == state["source_registered_identity"]
                    damaged_call = copy.deepcopy(call)
                    damaged_call[0]["registered"]["source_registered_identity"] = "0" * 64
                    with pytest.raises(ContractError, match="PREPARED_STOP_INPUT_INVALID"):
                        f5._a12_q_stop_unit_input(damaged_call, function=function)
                    reached.extend(units)
                    raise f5._QBatchBoundary({"UNFITTED_EXECUTOR_BOUNDARY": True})
                scoped_compile.setattr(f5, "_execute_q_search_batch", input_reader_boundary)
                result = f5.execute_final_complex_search(prepared_q_input=worker_input,
                    target=tmp_path / "scoped-worker-read", prepared_q_input_sha256=sha256_file(worker_input),
                    task_ids=ids, batch_root=tmp_path / "scoped-unstarted-batch",
                    retained_bytes_per_task=declared["retained_bytes_per_component"],
                    selection_horizon_months=12, candidate_family=family, primary_outer_prepared=True)
                assert result == {"UNFITTED_EXECUTOR_BOUNDARY": True} and reached == ids
                assert not (tmp_path / "scoped-unstarted-batch").exists()
                scoped_compile.setattr(f5, "_execute_q_search_batch", forbidden)
                read = f5.execute_final_complex_search(prepared_q_input=worker_input,
                    target=tmp_path / "scoped-worker-prepare-read", prepared_q_input_sha256=sha256_file(worker_input),
                    task_ids=ids, batch_root=tmp_path / "scoped-prepare-unstarted-batch",
                    retained_bytes_per_task=declared["retained_bytes_per_component"],
                    selection_horizon_months=12, candidate_family=family,
                    primary_outer_prepared=True, prepare_only=True)
                assert read["status"] == "PREPARED_Q_BATCH" and read["stage_acceptance"] is False
                assert read["phase"] == phase and read["task_ids"] == ids
                assert read["new_model_fits"] == read["new_stop_fits"] == read["new_first_native_audits"] == 0
                assert set(read["prepared_q_input"]["unit_payload_sha256"]) == set(ids)
                assert not (tmp_path / "scoped-prepare-unstarted-batch").exists()
                assert not list((tmp_path / "scoped-worker-prepare-read/native").iterdir())
            damaged = tmp_path / "pre-search-damaged.zip"
            changed = False
            with zipfile.ZipFile(source) as before, zipfile.ZipFile(damaged, "x", compression=zipfile.ZIP_STORED) as after:
                for entry in before.infolist():
                    payload = before.read(entry.filename)
                    if not changed and entry.filename.endswith("fit_response.csv"):
                        payload = payload[:-1] + bytes([payload[-1] ^ 1])
                        changed = True
                    after.writestr(entry.filename, payload)
            assert changed
            with pytest.raises(ContractError):
                f4._materialize_o_fit_input_bundle(damaged, tmp_path / "damaged-read", pre_search=True)
            observe_resources = runtime.observe_execution_resources
            with monkeypatch.context() as limits:
                limits.setattr(runtime, "observe_execution_resources", lambda root: {
                    **observe_resources(root), "scratch_available_bytes": 0})
                with pytest.raises(ContractError, match="ACTUAL_SPACE_INSUFFICIENT"):
                    f4._materialize_o_fit_input_bundle(source, tmp_path / "no-space", pre_search=True)
                assert not (tmp_path / "no-space").exists()
        return original(inputs, **kwargs)

    monkeypatch.setattr(nested, "_project_outer_development_from_inputs", observe)
    original_case(aar_source, tmp_path, monkeypatch, True, None, False)
    assert checked == [True]
    with pytest.raises(ContractError, match="PRE_SEARCH_SCOPE"):
        f4._materialize_o_fit_input_bundle(tmp_path / "input12.zip", tmp_path / "not-pre-search", pre_search=True)
