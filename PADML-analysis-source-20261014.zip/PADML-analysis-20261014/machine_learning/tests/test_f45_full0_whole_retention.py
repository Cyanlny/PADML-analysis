"""UNFITTED exact worker-payload regression; no clinical whole acceptance."""
import ast
import inspect
from pathlib import Path
import pytest
from padml import f5, f5_application, worker
from padml.bundle import canonical_json_bytes as encode, read_safe_zip, write_deterministic_zip
from test_f45_final_full0_reuse import fixture, jobs_for
from test_full0_cox12_prepare import _policy


def _whole_from_exact_worker_return(tmp_path, monkeypatch, mode):
    state, candidate, counts = fixture(tmp_path, monkeypatch)
    owner, inputs, outputs, lineage, tasks = state
    jobs = jobs_for(state)
    if mode == 'reused-new-shap':
        found = f5._prepare_f45_full_final_reuse(lineage['final_refit_plan'], outputs, jobs, [candidate], _policy())
        assert len(found) == 20
        # Legitimate model-only resume, with no transported old SHAP checkpoint.
        results = [f5._execute_final_refit_bundle_pair(job) for job in jobs]
        assert counts['fit'] == counts['audit'] == 0 and counts['shap'] == 20
        assert all(row['shap_component_archive']['reuse_mode'] == 'CURRENT_MODEL_SHAP' for row in results)
    else:
        # Original, non-reused final model and SHAP delivery.
        results = [f5._execute_final_refit_bundle_pair(job) for job in jobs]
        assert counts['fit'] == counts['audit'] == counts['shap'] == 20
    records = [{**r['shap_component_archive'], 'member': f"shap-components/M{r['imputation']:02d}.zip"} for r in results]
    result = owner / 'result.zip'
    write_deterministic_zip(result, {'final-aggregate.json': encode({'shap_component_archives': records}),
        **{r['member']: Path(s['shap_component_path']) for r, s in zip(records, results)}})
    names = {}
    for name in ('non_ph', 'compiled_path', 'application', 'score_archive'):
        path = owner / (name + '.json')
        path.write_bytes(encode({'UNFITTED': True}))
        names[name] = path
    # Evaluate the exact canonical worker retention expression (read-only).
    parsed = ast.parse(inspect.getsource(worker._f45_full0))
    expression = next(node.value for node in parsed.body[0].body if isinstance(node, ast.Return))
    paths = eval(compile(ast.Expression(expression), '<current-worker-retention>', 'eval'),
                 {'f5': f5, 'sorted': sorted, 'inputs': inputs, 'outputs': outputs, 'result': result, **names})
    payload = {p.relative_to(owner).as_posix(): p for p in paths}
    whole = tmp_path / 'exact-worker-unit.zip'
    write_deterministic_zip(whole, payload)
    portable = tmp_path / 'portable'
    portable.mkdir()
    for name, raw in read_safe_zip(whole).items():
        path = portable / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(raw)
    (tmp_path / 'retained-members.txt').write_text('\n'.join(sorted(payload)) + '\n')
    return portable, lineage, counts


@pytest.mark.parametrize('mode', ['reused-new-shap', 'ordinary'])
def test_exact_worker_whole_reopens_shap(tmp_path, monkeypatch, mode):
    portable, lineage, counts = _whole_from_exact_worker_return(tmp_path, monkeypatch, mode)
    before = dict(counts)
    loaded = f5.collect_final_refit_results(portable / 'final-result', lineage['family_decision'], lineage['final_refit_plan'],
        input_root=portable / 'final-input', resource_policy=_policy(), compiled_input_record={})
    assert len(loaded['shap_components']) == 20 and counts == before
