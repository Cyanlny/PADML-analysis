"""Metadata transport boundaries only; not historical numerical acceptance."""
from pathlib import Path
import os
import sys

import pytest

from padml import f4, f5, runtime
from padml.bundle import ContractError, canonical_json_bytes, strict_json_bytes


@pytest.mark.parametrize("change", ["missing_role", "wrong_family", "wrong_horizon", "not_continuous", "symlink"])
def test_full0_gbm_history_map_rejects_before_source_or_science(tmp_path, monkeypatch, change):
    root, suffix = tmp_path / "q", tmp_path / "suffix"
    root.mkdir()
    suffix.mkdir()
    task = {"kind": "PADML_NESTED_FULL_DATA_COMPLEX_SEARCH_TASK_V1", "family": "GBM_COX",
            "selection_horizon_months": 24}
    if change == "wrong_family":
        task["family"] = "XGBOOST_COX"
    if change == "wrong_horizon":
        task["selection_horizon_months"] = 12
    (root / "input.json").write_bytes(canonical_json_bytes({"task": task}))
    sources = {}
    for role in ("stop", "publisher", "refit"):
        sources[role] = tmp_path / (role + ".zip")
        sources[role].write_bytes(b"UNFITTED_SOURCE_SCOPE_ONLY")
    if change == "missing_role":
        del sources["refit"]
    if change == "symlink":
        link = tmp_path / "stop-link.zip"
        link.symlink_to(sources["stop"])
        sources["stop"] = link
    # Task and policy transport only. The real source proof must not be
    # reached by an invalid role/scope; no source identity is manufactured.
    monkeypatch.setattr(f5, "_validate_final_complex_search_task", lambda value: value)
    monkeypatch.setattr(runtime, "validate_resource_policy", lambda value: value)
    def forbidden(*args, **kwargs):
        pytest.fail("invalid history map reached source/science")
    monkeypatch.setattr(f4, "_retained_full0_source_members", forbidden)
    monkeypatch.setattr(f5, "_execute_q_search_batch", forbidden)
    monkeypatch.setattr(f5, "_consume_q_search_batches", forbidden)
    options = {"prepare_only": True, "task_ids": None, "batch_root": None,
               "q_batches": [], "retained_bytes_per_task": 256 * 1024**2}
    with pytest.raises(ContractError, match="^F5_FULL0_GBM_HISTORY_SOURCE_INVALID$"):
        f5._q_search_batch_control(root, {}, options,
            retained_q_producer_source_bundle=sources,
            continuous_batch_root=None if change == "not_continuous" else suffix,
            full0_continuous_phase_task_ids=None if change == "not_continuous" else {})


@pytest.mark.parametrize("change", [None, "missing_refit", "duplicate_stop", "refit_source", "refit_input"])
def test_full0_gbm_actual_history_metadata_derives_only_suffix(tmp_path, monkeypatch, change):
    # A transport of existing metadata/source bytes, not a synthetic legacy
    # identity. Layout: input.json, {stop24,stop116,refit70}/execution.json,
    # {stop,publisher,refit}.zip. No native object is copied or opened.
    supplied = os.environ.get("PADML_FULL0_GBM_HISTORY_METADATA")
    if supplied is None:
        pytest.skip("actual FULL0 GBM STOP140/REFIT70 metadata/source transport required")
    fixture = Path(supplied)
    root, suffix = tmp_path / "q", tmp_path / "suffix"
    root.mkdir()
    suffix.mkdir()
    (root / "input.json").write_bytes((fixture / "input.json").read_bytes())
    batches = []
    for name in ("stop24", "stop116", "refit70"):
        target = tmp_path / name
        target.mkdir()
        raw = (fixture / name / "execution.json").read_bytes()
        value = strict_json_bytes(raw)
        if name == "refit70" and change in {"refit_source", "refit_input"}:
            if change == "refit_source":
                value["source_identity"] = strict_json_bytes((fixture / "stop24/execution.json").read_bytes())["source_identity"]
            else:
                value["input"] = {**value["input"], "sha256": "0" * 64}
            raw = canonical_json_bytes(value)
        (target / "execution.json").write_bytes(raw)
        batches.append(target)
    policy = strict_json_bytes((batches[0] / "execution.json").read_bytes())["resource_policy"]
    if change == "missing_refit":
        batches.pop()
    if change == "duplicate_stop":
        duplicate = tmp_path / "duplicate"
        duplicate.mkdir()
        (duplicate / "execution.json").write_bytes((batches[0] / "execution.json").read_bytes())
        batches.append(duplicate)
    def forbidden(*args, **kwargs):
        pytest.fail("metadata continuation attempted scientific consumption")
    monkeypatch.setattr(f5, "_execute_q_search_batch", forbidden)
    monkeypatch.setattr(f5, "_consume_q_search_batches", forbidden)
    phases = {}
    options = {"prepare_only": True, "task_ids": None, "batch_root": None,
               "q_batches": batches, "retained_bytes_per_task": 256 * 1024**2}
    def read():
        return f5._q_search_batch_control(root, policy, options,
            retained_q_producer_source_bundle={role: fixture / (role + ".zip")
                for role in ("stop", "publisher", "refit")},
            continuous_batch_root=suffix, full0_continuous_phase_task_ids=phases)
    if change is None:
        control = read()
        assert phases == dict(f5._a12_q_stop_phase(stage, refit=refit)
            for stage in ("S2", "S3A", "S3B1", "S3B2") for refit in (False, True))
        assert len(control["batches"]) == 3 and control["used_batches"] == []
    else:
        code = "F5_FULL0_GBM_HISTORY_PREFIX_INVALID" if change == "duplicate_stop" else "F5_FULL0_GBM_HISTORY_RECEIPT_INVALID"
        with pytest.raises(ContractError, match="^" + code + "$"):
            read()


@pytest.mark.parametrize("mode", ["roles", "legacy", "missing_role", "wrong_family", "wrong_horizon"])
def test_full0_cli_history_source_conversion(tmp_path, monkeypatch, capsys, mode):
    paths = {role: str(tmp_path / (role + ".zip")) for role in ("stop", "publisher", "refit")}
    if mode == "missing_role":
        del paths["refit"]
    family = "XGBOOST_COX" if mode == "wrong_family" else "GBM_COX"
    context = {key: str(tmp_path / key) for key in
        ("final_input_root", "final_result_root", "non_ph_result", "aggregate_target")}
    context["q"] = {family: {"target": str(tmp_path / "target"),
        "continuous_batch_root": str(tmp_path / "suffix"), "batch_roots": [],
        "producer_source_bundle": str(tmp_path / "legacy.zip") if mode == "legacy" else paths}}
    source = tmp_path / "context.json"
    source.write_bytes(canonical_json_bytes(context))
    calls = []
    monkeypatch.setattr(f5, "execute_full_data_locked_scores",
        lambda *args, **kwargs: calls.append(kwargs) or {"TRANSPORT_ONLY": True})
    monkeypatch.setattr(sys, "argv", ["padml-f5", "full-score", str(tmp_path / "full.json"),
        "--full0-execution-context", str(source), "--selection-horizon-months",
        "12" if mode == "wrong_horizon" else "24"])
    if mode in {"missing_role", "wrong_family", "wrong_horizon"}:
        with pytest.raises(ContractError, match="^NESTED_FULL0_EXECUTION_CONTEXT_INVALID$"):
            f5.main()
        assert calls == []
    else:
        f5.main()
        capsys.readouterr()
        observed = calls[0]["full0_execution_context"]["q"][family]["producer_source_bundle"]
        assert observed == (Path(context["q"][family]["producer_source_bundle"])
            if mode == "legacy" else {role: Path(path) for role, path in paths.items()})


def test_actual_full0_refit_receipt_resource_policy_is_historical():
    supplied = os.environ.get("PADML_FULL0_GBM_HISTORY_METADATA")
    if supplied is None:
        pytest.skip("actual FULL0 GBM REFIT70 receipt required")
    execution = strict_json_bytes((Path(supplied) / "refit70/execution.json").read_bytes())
    original = canonical_json_bytes(execution)
    options = {"execution_worker_memory_bytes": execution["execution_worker_memory_bytes"],
        "execution_scratch_reserve_bytes": execution["execution_scratch_reserve_bytes"],
        "prepared_input": execution["prepared_q_input"]}
    def effective(policy):
        return f5._q_batch_resource_policy(policy, execution["input"]["size_bytes"],
            len(execution["task_ids"]), execution["retained_bytes_per_task"], **options)
    policy = effective(execution["resource_policy"])
    assert policy == execution["effective_policy"]
    assert runtime.resource_admission(policy, execution["resource_observation"], legal_tasks=70) == execution["resource_admission"]
    after = execution["prepared_q_input"]["after_release"]
    assert runtime.resource_admission(policy, after["resource_observation"], legal_tasks=70) == after["resource_admission"]
    current = {**execution["resource_policy"], "memory_reserve_bytes": execution["resource_policy"]["memory_reserve_bytes"] + 1}
    assert effective(current) != execution["effective_policy"]
    assert canonical_json_bytes(execution) == original
