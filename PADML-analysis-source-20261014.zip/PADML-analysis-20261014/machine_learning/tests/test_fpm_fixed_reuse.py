"""Native retained-output admission; these tests never invoke a scientific fit."""
import copy
import json
import os
from pathlib import Path

import pytest

from padml import f2_kernel as native
from padml.bundle import ContractError, canonical_json_bytes, read_safe_zip, strict_json_bytes


@pytest.fixture(params=range(3))
def fixed(request):
    paths = os.environ.get("PADML_TEST_FPM_FIXED_ARCHIVES")
    if paths is None:
        pytest.skip("Set PADML_TEST_FPM_FIXED_ARCHIVES to the three immutable native archives")
    entries = read_safe_zip(Path(json.loads(paths)[request.param]))
    spec = strict_json_bytes(entries["original-spec.json"])
    task = strict_json_bytes(entries["original-task.json"])
    child = {key: value for key, value in spec.items() if key not in
             {"action", "output_path", "registered_partitions", "transform_recipe", "producer_tasks"}}
    return entries, spec, task, child


def consume(fixed, scratch):
    entries, spec, task, child = fixed
    return native._run_r_prediction_partition_batch(
        child, spec["registered_partitions"], [task], scratch,
        Path(native.__file__).resolve().parent, retained_fpm=entries)


def forbid_fit(*args, **kwargs):
    pytest.fail("Retained-component admission must not execute a scientific engine")


def test_native_fixed_component_reuse_is_zero_fit(fixed, tmp_path, monkeypatch):
    monkeypatch.setattr(native.subprocess, "run", forbid_fit)
    entries, spec, task, child = fixed
    rows = consume(fixed, tmp_path)
    assert len(rows) == 1 and rows[0]["task_id"] == task["task_id"]
    assert rows[0]["stopping"] == strict_json_bytes(entries["output.json"])["tasks"][0]["stopping"]
    assert rows[0]["sealed_prediction"]["payload"]["patient_ids"] == spec["registered_partitions"]["partitions"][0]["evaluation_ids"]


@pytest.mark.parametrize("field", ["seed", "parameters", "member", "fpm", "selected"])
def test_changed_science_fails_before_fit(fixed, tmp_path, monkeypatch, field):
    monkeypatch.setattr(native.subprocess, "run", forbid_fit)
    entries, spec, task, child = copy.deepcopy(fixed)
    if field == "seed":
        task["seed"] += 1
    elif field == "parameters":
        task["parameters"]["df"] = 4
    elif field == "member":
        spec["registered_partitions"]["partitions"][0]["covariates"]["members"][0]["sha256"] = "0" * 64
    elif field == "fpm":
        child["fpm"]["set_a_df"] = [4, 1]
    else:
        task["selected_parents"] = task["selected_parents"][:-1]
    with pytest.raises(ContractError):
        consume((entries, spec, task, child), tmp_path)


def test_failed_native_kkt_is_not_reusable(fixed, tmp_path, monkeypatch):
    monkeypatch.setattr(native.subprocess, "run", forbid_fit)
    entries, spec, task, child = copy.deepcopy(fixed)
    output = strict_json_bytes(entries["output.json"])
    output["tasks"][0]["stopping"]["fit_evidence"]["maximum_gradient"] += 100
    entries["output.json"] = canonical_json_bytes(output)
    with pytest.raises(ContractError):
        consume((entries, spec, task, child), tmp_path)


def test_input_relocation_preserves_all_content_bindings(fixed):
    _, spec, _, _ = fixed
    other = copy.deepcopy(spec)
    part = other["registered_partitions"]["partitions"][0]
    part["covariates"]["input_dir"] = "/new/immutable/cache"
    part["fit_response"]["path"] = "/new/immutable/response.csv"
    assert native._fpm_reuse_spec(other) == native._fpm_reuse_spec(spec)
    part["fit_response"]["sha256"] = "0" * 64
    assert native._fpm_reuse_spec(other) != native._fpm_reuse_spec(spec)


def test_outer_merges_retained_and_only_nineteen_new_tasks(fixed, tmp_path, monkeypatch):
    entries, original, task, child = fixed
    captured = {}
    selector = {"selected_parents": task["selected_parents"], "outer_recipe_sha256": task["transform_recipe"]["recipe_sha256"]}
    spec = {**child, "seed": task["seed"] - task["imputation"],
            "monthly_fit_horizons": task["prediction_horizons"], "selector_from_dependency": selector}
    registered = copy.deepcopy(original["registered_partitions"])
    registered["partitions"][0]["evaluation_response"] = {"not_exposed_to_engine": True}
    monkeypatch.setattr(native, "_outer_recipe_from_selector", lambda *args: task["transform_recipe"])
    monkeypatch.setattr(native.subprocess, "run", forbid_fit)

    def fresh(spec, registered, tasks, scratch, repo_root):
        captured["new"] = tasks
        return [{"task_id": row["task_id"], "imputation": row["imputation"]} for row in tasks]

    def build(spec, registered, produced, **kwargs):
        captured["produced"] = produced
        return kwargs

    monkeypatch.setattr(native, "_run_r_prediction_batch", fresh)
    monkeypatch.setattr(native, "_build_registered_model_result", build)
    result = native._run_r_registered_fpm(spec, registered, tmp_path,
                         Path(native.__file__).resolve().parent, retained_fpm=entries)
    assert len(captured["new"]) == 19
    assert task["task_id"] not in {row["task_id"] for row in captured["new"]}
    assert [row["imputation"] for row in captured["produced"]] == list(range(1, 21))
    assert result["search_evaluation_unit_count"] == 20


def test_atomic_window_uses_retained_without_refit(monkeypatch):
    jobs = [{"atomic_task_id": f"task-{i}", "top_task_id": "top"} for i in range(3)]
    def result(job):
        row = {**job, "evaluated": {"imputation": int(job["atomic_task_id"][-1])}}
        return {**row, "task_identity_sha256": native._sha(row)}
    called = []
    def spawn(fn, tasks, *, selected_slots, on_result):
        called.extend(tasks)
        rows = [result(job) for job in tasks]
        for index, row in enumerate(rows):
            on_result(index, row)
        return rows
    monkeypatch.setattr(native, "_bounded_ordered_spawn", spawn)
    plans = [{"kind": "PADML_F2_P2C2T_ATOMIC_JOB_PLAN", "pool_workers": 24,
              "engine_threads": 1, "jobs": jobs, "expected_fit_count": 3, "task_id": "top"}]
    rows = native._run_p2c2t_atomic_window(plans, retained_rows={"task-1": result(jobs[1])})
    assert [job["atomic_task_id"] for job in called] == ["task-0", "task-2"]
    assert [row["imputation"] for row in rows[0]] == [0, 1, 2]


def component(task_id):
    return {"fixed-task.json":canonical_json_bytes({"task_id":task_id}),
            "engine-spec.json":b"{}", "consumer-result.json":b"{}"}


def test_multiple_native_components_are_read_once():
    entries = component("first")
    entries.update({"retained/001/" + key:value for key,value in component("second").items()})
    records = native._retained_p2c2t_fpm_components(entries)
    assert [strict_json_bytes(row["fixed-task.json"])["task_id"] for row in records] == ["first","second"]


@pytest.mark.parametrize("fault",["duplicate","missing","unindexed"])
def test_bad_component_sets_are_not_silently_omitted(fault):
    entries = component("first")
    entries.update({"retained/001/" + key:value for key,value in component("second").items()})
    if fault == "duplicate":
        entries["retained/001/fixed-task.json"] = entries["fixed-task.json"]
    elif fault == "missing":
        entries.pop("retained/001/engine-spec.json")
    else:
        entries["retained/unindexed.json"] = b"{}"
    with pytest.raises(ContractError):
        native._retained_p2c2t_fpm_components(entries)


def test_center_atomic_reuse_replays_real_response_without_fit(tmp_path, monkeypatch):
    path = os.environ.get("PADML_TEST_FPM_CENTER_ARCHIVE")
    if not path:
        pytest.skip("Set PADML_TEST_FPM_CENTER_ARCHIVE to the immutable native center archive")
    entries = read_safe_zip(Path(path))
    spec = strict_json_bytes(entries["engine-spec.json"])
    task = strict_json_bytes(entries["fixed-task.json"])
    result = strict_json_bytes(entries["consumer-result.json"])
    partition = spec["registered_partitions"]["diagnostic_partitions"][0]
    fields, by_id = native._response_rows(entries["data-binding-payload/binding/response-seal.csv"])
    current = copy.deepcopy(partition)
    current["fit_response"] = native._write_response_subset(fields, by_id, partition["fit_ids"], tmp_path / "fit.csv")
    current["evaluation_response"] = native._write_response_subset(fields, by_id, partition["evaluation_ids"], None)
    child = {key: value for key, value in spec.items() if key not in
             {"action", "output_path", "registered_partitions", "transform_recipe", "producer_tasks"}}
    job = {"route": "R", "top_task_id": result["top_task_id"], "atomic_task_id": result["atomic_task_id"],
           "spec": child, "registered": spec["registered_partitions"], "fit_task": task,
           "evaluation_partition": current}
    monkeypatch.setattr(native.subprocess, "run", forbid_fit)
    assert native._retained_p2c2t_fpm(job, entries) == result
    job["fit_task"] = {**task, "seed": task["seed"] + 1}
    with pytest.raises(ContractError, match="REUSE_TASK"):
        native._retained_p2c2t_fpm(job, entries)
