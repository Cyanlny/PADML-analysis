"""Fresh full0 input contracts; hand-written splits, no fits/MICE/native RNG."""
import copy
import csv
import io
import zipfile
from contextlib import contextmanager
from pathlib import Path
from types import SimpleNamespace

import pytest

from padml import f4, f5
from padml.bundle import ContractError, canonical_json_bytes, sha256_bytes, strict_json_bytes
from padml.nested_loco import exact_fit_budget_contract


ORIGINAL_SELECTOR_SEARCH = f4._full_pipeline_selector_search
ORIGINAL_SELECTOR_RUN = f4._run_learning_selector_path
ORIGINAL_SELECTOR_CONSUME = f4._consume_learning_selector_path


def _selector_shard_engines(monkeypatch, recipe_engine):
    """Only R fitting/pool concurrency are UNFITTED; native loss readers stay real."""
    import struct
    from padml import f2_kernel, runtime
    counts = {"native": 0, "numerical": 0, "recipe": 0, "engine": 0, "pools": [], "forbid_native": False}
    monkeypatch.setattr(runtime, "effective_cpu_count", lambda: 32)
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda root: {
        "effective_cpus": 32, "available_memory_bytes": 64 * 1024**3,
        "scratch_available_bytes": 512 * 1024**3, "scratch_root": str(root)})
    def engine(args, **kwargs):
        spec = strict_json_bytes(Path(args[-1]).read_bytes())
        assert not counts["forbid_native"]
        if "action" in spec:
            counts["recipe"] += 1
            return recipe_engine(args, **kwargs)
        assert spec["execution_scope"] in {"NESTED_FULL_DATA_SELECTOR_M20", "NESTED_NO_AAR_SELECTOR_M20"}
        task, part = spec["task"], spec["partition"]
        assert "evaluation_response" not in part
        assert all(kwargs["env"][name] == "1" for name in runtime.THREAD_ENV)
        assert Path(kwargs["env"]["TMPDIR"]).stat().st_dev == Path(kwargs["cwd"]).stat().st_dev
        native = Path(spec["output_path"]).parent
        paths = _unfitted_selector_path_values(spec, part, task)["sealed_elastic_paths"]
        for index, row in enumerate(paths, 1):
            row.pop("lambda_path_sha256")
            row.pop("coefficient_path_sha256", None)
            row.pop("losses", None)
            row["event_count"] = part["fit_response"]["event_count"]
            if task["producer_kind"] == "ELASTIC_INNER_PATH":
                channel = {"schema_version": "1.0.0", "kind": "PADML_F2_OPERATION_LOCAL_RISK_MATRIX_CHANNEL"}
                for role in ("fit", "evaluation"):
                    name = f"risk-001-alpha-{index:03d}-{role}.bin"
                    count = len(part[role + "_ids"])
                    # Distinct alpha-specific numerical curves are necessary:
                    # the original selector rejects indistinguishable candidates.
                    # No validation response is exposed to this fake R engine.
                    raw = b"".join(struct.pack("<d", row["alpha"] * (position + 1) / count) * 150
                                   for position in range(count))
                    (native / name).write_bytes(raw)
                    channel[role] = {"schema_version": "1.0.0", "kind": "PADML_F2_OPERATION_LOCAL_RISK_MATRIX",
                        "encoding": "IEEE754_FLOAT64", "byte_order": "LITTLE_ENDIAN", "row_order": "ROW_MAJOR",
                        "file_name": name, "rows": len(part[role + "_ids"]), "columns": 150,
                        "size_bytes": len(raw), "sha256": sha256_bytes(raw)}
                row["risk_matrix_channel"] = channel
        result = {"task_id": task["task_id"], "partition_id": part["partition_id"], "imputation": task["imputation"],
            "fit_ids": part["fit_ids"], "evaluation_ids": part["evaluation_ids"],
            "ordered_parent_column_map": f2_kernel._expected_family_parent_column_map(task["selected_parents"],
                "ELASTIC_NET_COX", spec["predictors"], task["transform_recipe"]),
            "transform_recipe_sha256": task["transform_recipe"]["recipe_sha256"], "elastic_paths": {"alphas": paths}}
        Path(spec["output_path"]).write_bytes(canonical_json_bytes({"schema_version": "1.0.0",
            "kind": "PADML_F2_R_PREDICTION_BATCH", "status": "PASS", "task_count": 1, "tasks": [result]}))
        kwargs["stdout"].write(b"UNFITTED selector engine; original native consumer follows\n")
        counts["engine"] += 1
        return SimpleNamespace(returncode=0)
    def consume(arguments, *, numerical=False):
        assert numerical or not counts["forbid_native"]
        counts["numerical" if numerical else "native"] += 1
        return ORIGINAL_SELECTOR_CONSUME(arguments, numerical=numerical)
    def pool(worker, jobs, *, selected_slots, execution_report, on_result=None, resource_release_report=None):
        execution_report.update(configured_worker_ceiling=24, admitted_worker_ceiling=selected_slots,
            runnable_task_count=len(jobs), actual_worker_process_peak=1, completed_task_count=0,
            engine_threads=1, status="RUNNING")
        counts["pools"].append((len(jobs), selected_slots))
        results = []
        try:
            for index, job in enumerate(jobs):
                results.append(worker(job))
                execution_report["completed_task_count"] += 1
                if on_result is not None:
                    on_result(index, results[-1])
                if resource_release_report is not None:
                    resource_release_report[str(index)] = runtime.release_step_resources([],
                        owner=f"POOL_TASK_RESULT:{index}", before=runtime.observe_step_memory(),
                        released_references=["serialized_result", "task", "received_message"])
        except BaseException:
            execution_report["status"] = "FAILED"
            raise
        execution_report["status"] = "COMPLETED"
        return results
    monkeypatch.setattr(f4.subprocess, "run", engine)
    monkeypatch.setattr(f4, "_full_pipeline_selector_search", ORIGINAL_SELECTOR_SEARCH)
    monkeypatch.setattr(f4, "_run_learning_selector_path", ORIGINAL_SELECTOR_RUN)
    monkeypatch.setattr(f4, "_consume_learning_selector_path", consume)
    monkeypatch.setattr(f4, "_bounded_ordered_spawn", pool)
    return counts


def _exercise_selector_shards(run, root, policy, counts, *, monkeypatch, no_aar=False):
    """Six disjoint assignments on ONE synthetic host; no parallelism claim."""
    import shutil
    from padml import runtime
    owner, gathered = root / "owner", root / "gathered"
    ready = run(owner, replay=False, prepare_only=True)
    assert ready["selector_path_count"] == ready["glmnet_call_count"] == 0
    assert len(ready["task_ids"]) == len(set(ready["task_ids"])) == 320 and counts["engine"] == 0
    assert not (owner / "coarse").exists() and not (owner / "development-input.json").exists()
    recipe_count = counts["recipe"]
    for name in ("partitions.json", "recipes/recipes.json", "recipes/native-values.json"):
        path = gathered / name
        path.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(owner / name, path)
    parts = [ready["task_ids"][offset::6] for offset in range(6)]
    completed_batches = {}
    for phase in ("coarse", "fine"):
        before = counts["engine"]
        batches = []
        for index, ids in enumerate(parts):
            batch = root / f"{phase}-batch-{index}"
            result = run(owner, replay=False, phase_name=phase, task_ids=list(reversed(ids)),
                batch_root=batch, retained_bytes_per_task=64 * 1024**2)
            assert result["status"] == "COMPUTED_SELECTOR_PATHS" and result["task_count"] == len(ids)
            assert result["execution"]["task_ids"] == ids
            assert result["execution"]["pool"]["actual_worker_process_peak"] == 1
            assert result["execution"]["pool"]["configured_worker_ceiling"] == 24
            assert not list(batch.rglob("*.bin")) and not list(batch.rglob("output.json"))
            references = strict_json_bytes((batch / "path-results.json").read_bytes())
            assert all(set(row) == {"task_id", "path", "sha256", "size_bytes"} for row in references)
            batches.append(batch)
        assert counts["engine"] - before == 320 and counts["recipe"] == recipe_count
        with pytest.raises(ContractError, match="NESTED_SELECTOR_COORDINATE_ALREADY_STARTED"):
            run(owner, replay=False, phase_name=phase, task_ids=parts[0],
                batch_root=root / f"{phase}-renamed-report", retained_bytes_per_task=64 * 1024**2)
        assert counts["engine"] - before == 320
        counts["forbid_native"] = True
        # These rejected incomplete/duplicate collections create no phase result.
        with pytest.raises(ContractError, match="NESTED_SELECTOR_PHASE_COMPLETE_320_REQUIRED"):
            run(gathered, replay=False, phase_name=phase, phase_batches=batches[:-1])
        with pytest.raises(ContractError, match="NESTED_SELECTOR_PHASE_BATCHES_INVALID"):
            run(gathered, replay=False, phase_name=phase, phase_batches=[*batches, batches[0]])
        assert not (gathered / phase / "paths.json").exists()
        if phase == "coarse":
            execution_path = batches[0] / "execution.json"
            execution_raw = execution_path.read_bytes()
            original_execution = strict_json_bytes(execution_raw)
            if "resource_release" in original_execution:
                leaf = batches[0] / original_execution["resource_release"]["path"]
                leaf_raw = leaf.read_bytes()
                for damage in ("missing_leaf", "leaf_sha", "missing_leaf_binding", "execution_over_1m"):
                    execution = copy.deepcopy(original_execution)
                    if damage == "missing_leaf":
                        leaf.rename(leaf.with_suffix(".missing"))
                    elif damage == "leaf_sha":
                        leaf.write_bytes(leaf_raw[:-1] + b" ")
                    elif damage == "missing_leaf_binding":
                        execution.pop("resource_release")
                        execution_path.write_bytes(canonical_json_bytes(execution))
                    else:
                        execution_path.write_bytes(b" " * (1024**2 + 1))
                    try:
                        with pytest.raises(ContractError):
                            run(gathered, replay=False, phase_name=phase, phase_batches=batches)
                    finally:
                        if damage == "missing_leaf":
                            leaf.with_suffix(".missing").rename(leaf)
                        else:
                            leaf.write_bytes(leaf_raw)
                        execution_path.write_bytes(execution_raw)
                    assert not (gathered / phase / "paths.json").exists()
        # The original gather requires combined-copy + reducer/header scratch,
        # not just the returned numerical bytes. Short-by-one stops publication.
        source_refs = [strict_json_bytes((batch / "path-results.json").read_bytes()) for batch in batches]
        execution_records = [{"execution": strict_json_bytes((batch / "execution.json").read_bytes()),
            "path_results": rows} for batch, rows in zip(batches, source_refs, strict=True)]
        numerical_bytes = sum((batch / row["path"]).stat().st_size
            + (batch / row["task_id"] / "native/spec.json").stat().st_size
            for batch, rows in zip(batches, source_refs, strict=True) for row in rows)
        required = 3 * numerical_bytes + len(canonical_json_bytes(execution_records))
        required += sum((batch / record["execution"]["resource_release"]["path"]).stat().st_size
                        for batch, record in zip(batches, execution_records, strict=True)
                        if "resource_release" in record["execution"])
        required += 128 * 1024**2
        with monkeypatch.context() as limited:
            limited.setattr(runtime, "observe_execution_resources", lambda path: {"effective_cpus": 32,
                "available_memory_bytes": 64 * 1024**3, "scratch_available_bytes": required - 1, "scratch_root": str(path)})
            with pytest.raises(ContractError, match="NESTED_SELECTOR_PHASE_ACTUAL_SPACE_INSUFFICIENT"):
                run(gathered, replay=False, phase_name=phase, phase_batches=batches)
        assert not (gathered / phase / "paths.json").exists()
        result = run(gathered, replay=False, phase_name=phase, phase_batches=list(reversed(batches)))
        completed_batches[phase] = batches
        assert counts["engine"] - before == counts["native"] - before == 320
        assert not list(gathered.rglob("*.bin")) and not list(gathered.rglob("output.json"))
        if phase == "coarse":
            assert result["status"] == "COMPUTED_SELECTOR_PHASE" and result["next_phase"] == "fine"
            assert result["next_alphas"] and not set(result["next_alphas"]).intersection(ready["next_alphas"])
            assert not (gathered / "development-input.json").exists() and not (owner / "fine").exists()
            for name in ("paths.json", "execution.json"):
                shutil.copyfile(gathered / "coarse" / name, owner / "coarse" / name)
            for record in strict_json_bytes((gathered / "coarse/execution.json").read_bytes()):
                pin = record["execution"].get("resource_release")
                if pin is not None:
                    shutil.copyfile(gathered / "coarse" / pin["path"], owner / "coarse" / pin["path"])
        counts["forbid_native"] = False
    counts["forbid_native"] = True
    assert result["selector"]["selected_parents"] == (["Sex"] if no_aar else ["AST_ALT", "Age"])
    assert result["selector_path_count"] <= 4800 and result["glmnet_call_count"] == 2 * result["selector_path_count"]
    assert run(gathered, replay=True) == result
    transported = root / "transported"
    for name, path in f5._nested_selector_numerical_members(gathered).items():
        destination = transported / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, destination)
    # Owner objects become unreachable; normal reading must use original values.
    owner.rename(root / "retained-native-owner")
    assert run(transported, replay=True) == result
    negative_names = []
    for damage in ("missing_numbers", "response_sha", "validation_n", "seed", "unknown_field", "admission_bool",
                   "non_spec_native_ref", "missing_execution_binding"):
        name = {"seed": "coarse/R1_K1_M01/native/spec.json", "admission_bool": "coarse/execution.json",
            "non_spec_native_ref": "native-members.json", "missing_execution_binding": "selector.json"}.get(
            damage, "coarse/R1_K1_M01/path-result.json")
        path = transported / name
        raw = path.read_bytes()
        value = strict_json_bytes(raw)
        if damage == "missing_numbers":
            path.rename(path.with_suffix(".missing"))
        else:
            if damage == "response_sha":
                value["sealed_elastic_paths"][0]["evaluation_response_sha256"] = "a" * 64
            elif damage == "validation_n":
                value["sealed_elastic_paths"][0]["validation_n"] = True
            elif damage == "seed":
                value["task"]["seed"] += 1
            elif damage == "unknown_field":
                value["untrusted"] = True
            elif damage == "admission_bool":
                value[0]["execution"]["resource_admission"]["admitted_worker_ceiling"] = True
            elif damage == "non_spec_native_ref":
                next(row for row in value if row["name"].endswith("/output.json"))["sha256"] = "b" * 64
            else:
                value.pop("phase_execution_sha256")
            path.write_bytes(canonical_json_bytes(value))
        try:
            with pytest.raises((ContractError, FileNotFoundError)):
                run(transported, replay=True)
        finally:
            if damage == "missing_numbers":
                path.with_suffix(".missing").rename(path)
            else:
                path.write_bytes(raw)
        negative_names.append(damage)
    assert counts["engine"] == counts["native"] == 640 and counts["recipe"] == recipe_count
    (root / "selector-shard-observation.json").write_bytes(canonical_json_bytes({
        "fixture_disjoint_shards": 6, "actual_remote_host_count": 1, "unfitted_engine_calls": 640,
        "original_first_native_reads": counts["native"], "numerical_path_reads": counts["numerical"],
        "new_actual_model_fits": 0, "new_actual_mice_chains": 0, "original_recipe_calls": recipe_count,
        "selector_path_count": result["selector_path_count"], "negative_cases": negative_names,
        "normal_native_calls": 0, "completed_batches": {name: [str(path) for path in paths]
            for name, paths in completed_batches.items()}}))
    return result, transported


def _unfitted_selector_path_values(spec, partition, task):
    """Complete synthetic numbers for the original reducer, never native fits."""
    from padml import f2_kernel
    import math
    column_map = f2_kernel._expected_family_parent_column_map(task["selected_parents"], "ELASTIC_NET_COX",
        spec["predictors"], task["transform_recipe"])
    columns = {row["parent"]: len(row["columns"]) for row in column_map}
    penalty = sha256_bytes(canonical_json_bytes({
        "design_columns": [column for row in column_map for column in row["columns"]],
        "penalty_factor": [0.0 if row["parent"] == "AST_ALT" else 1.0
                           for row in column_map for _ in row["columns"]]}))
    no_aar = spec["execution_scope"] == "NESTED_NO_AAR_SELECTOR_M20"
    selected = "Sex" if no_aar else "Age"
    imp, ratios = task["imputation"], task["ratios"]
    bound, best = 1 + imp / 10, 8 if imp % 2 else 16
    lambdas = [bound * ratio for ratio in ratios]
    lambdas[10] = math.nextafter(lambdas[10], math.inf)  # legal original 1e-12/1e-15 tolerance
    coefficients = {parent: [[float(parent != "AST_ALT" and (parent == selected or index >= 30))] * width
                            for index in range(150)] for parent, width in columns.items()}
    active = [sum(value != 0 for parent, vectors in coefficients.items()
                  if parent != "AST_ALT" for value in vectors[index]) for index in range(150)]
    paths = []
    for alpha in task["alphas"]:
        upper = {"schema_version": "1.0.0", "kind": "PADML_F2_ELASTIC_LAMBDA_UPPER_BOUND_V1",
            "glmnet_version": "5.0", "family": "cox", "cox_ties": "breslow", "alpha": alpha,
            "standardize": True, "penalty_factor_identity_sha256": penalty,
            "pilot_requested_nlambda": 100, "pilot_returned_nlambda": 100,
            "pilot_lambda_head": [bound, bound * .9, bound * .8], "resolved_lambda_max": bound,
            "glmnet_big": 9.9e35, "sentinel_equivalent": False}
        paths.append({"alpha": alpha, "lambda_max": bound, "lambda_upper_bound": upper,
            "lambda_path": lambdas, "lambda_path_sha256": sha256_bytes(canonical_json_bytes(lambdas)),
            "penalized_design_column_count": sum(width for parent, width in columns.items() if parent != "AST_ALT"),
            "penalized_active_count_path": active, "penalized_entry_covered": True,
            **({"losses": [float((index - best) ** 2 + 10 + alpha) if index < 30 else float(alpha)
                           for index in range(150)]} if partition["inner_fold"] else {
                "event_count": partition["fit_response"]["event_count"], "parent_design_columns": columns,
                "parent_coefficients": coefficients,
                "coefficient_path_sha256": sha256_bytes(canonical_json_bytes({
                    "parent_design_columns": columns, "parent_coefficients": coefficients}))})})
    return {"partition_id": partition["partition_id"], "imputation": imp, "sealed_elastic_paths": paths}


def _write_unfitted_selector_native(arguments):
    """Original task specs; explicitly synthetic, unfitted output/risk placeholders."""
    spec, part, task, directory, _ = arguments
    native = Path(directory) / task["task_id"] / "native"
    native.mkdir(parents=True)
    (native / "spec.json").write_bytes(canonical_json_bytes(f4._learning_selector_native_spec(spec, part, task, native)))
    names = {"output.json"}
    if task["producer_kind"] == "ELASTIC_INNER_PATH":
        names.update(f"risk-001-alpha-{index:03d}-{role}.bin"
                     for index in range(1, len(task["alphas"]) + 1) for role in ("fit", "evaluation"))
    for name in names:
        (native / name).write_bytes(b"UNFITTED_NATIVE_PLACEHOLDER")
    return native


@pytest.fixture
def full_inputs(monkeypatch):
    # Heavy plumbing fixtures have one CPU slot; no real engine is executed.
    monkeypatch.setattr("padml.runtime.effective_cpu_count", lambda: 9)
    def forbidden(*args, **kwargs):
        raise AssertionError("NO_NATIVE_RNG_MICE_OR_FIT_AUTHORIZED")
    monkeypatch.setattr(f5.subprocess, "run", forbidden)

    def fixture_splits(keys, centers, events, **kwargs):
        rows = sorted(zip(keys, centers, events, strict=True))
        ordered = [row[0] for row in rows]
        return {
            "patient_ids": ordered,
            "input_sha256": sha256_bytes(canonical_json_bytes(rows)),
            "splits": [
                {"repeat": repeat, "inner_fold": inner, "seed": 100000 + repeat * 100,
                 "training_ids": [key for index, key in enumerate(ordered) if index % 5 != inner - 1],
                 "validation_ids": [key for index, key in enumerate(ordered) if index % 5 == inner - 1]}
                for repeat in range(1, 4) for inner in range(1, 6)
            ],
        }
    monkeypatch.setattr(f5, "full_data_splits", fixture_splits)
    return ([f"p{index:03d}" for index in range(140)],
            [center for center in [36, 38, 39, 48, 52, 54, 55] for _ in range(20)],
            [index % 2 for index in range(140)])


def _plan(inputs, family=None):
    ids, centers, events = inputs
    return f5.compile_full_data_mice_plan(ids, None, centers, events, family=family,
                                          workers=None if family is None else 3)


def _unfitted_confirmed_decision(*, fresh_seven=False, fixed_bootstrap=False):
    """Synthetic test-only authorization; never a user's scientific decision."""
    from padml import nested_loco as nested
    body = {key: value for key, value in nested.science_decision_template().items() if key != "identity_sha256"}
    body["status"] = "CONFIRMED"
    body["training_score_reuse"]["confirmed"] = body["training_score_reuse"]["proposal"]
    body["fpm"]["confirmed"] = True
    body["aar"]["no_aar_full_data_final_model"] = False
    body["bootstrap"].update(definition="NO_BOOTSTRAP_AUTHORIZED_FOR_THIS_RUN", authorized=False,
        b101_b200_trigger="NOT_APPLICABLE_BECAUSE_BOOTSTRAP_IS_EXPLICITLY_NOT_AUTHORIZED")
    for name in ("primary_outer", "full_data_same_program", "a12_direct_total", "outer_selected_family_no_aar_redevelopment"):
        body["fit_budget"][name]["authorized"] = True
    body["fit_budget"]["optional_no_aar_full_data"]["authorized"] = False
    body["fit_budget"]["bootstrap_b100_b200"] = {"authorized": False,
        "basis": "ZERO_BY_EXPLICIT_NO_BOOTSTRAP_DECISION",
        "ledger": {key: 0 for key in nested._LEDGER_COUNT_FIELDS}}
    if fresh_seven or fixed_bootstrap:
        body["training_score_reuse"].update(confirmed="FRESH_SEVEN_FAMILY_REPLAY",
            families=[], fresh_families=list(nested._families()))
    if fixed_bootstrap:
        body["bootstrap"] = nested.fixed_prediction_bootstrap_contract()
        body["fit_budget"]["bootstrap_b100_b200"]["basis"] = "ZERO_CURRENT_BATCH_DEFERRED_REQUIRES_SEPARATE_CONFIRMATION"
        body["fit_budget"]["fixed_prediction_paired_b1000"] = {
            "authorized": True,
            "basis": "SHARED_1000_PATIENT_DRAWS_PRIMARY_AND_THREE_AAR_FIXED_PREDICTIONS",
            "replicate_count": 1000, "ledger": {key: 0 for key in nested._LEDGER_COUNT_FIELDS},
            "metric_and_calibration_cost": "ACCOUNTED_SEPARATELY",
        }
    return nested.validate_science_decision(nested._sealed(body))


def test_full0_has_own_3x5_and_1220_chains_not_six_selectors(full_inputs):
    plan = _plan(full_inputs)
    assert plan["kind"] == "PADML_NESTED_FULL_DATA_MICE_PLAN_V1"
    assert plan["execution_profile"]["pool_workers"] == "EXECUTION_HOST_C_MINUS_8"
    assert plan["family"] is None and len(plan["families"]) == 7
    assert plan["development_scope"] == "FRESH_VIRTUAL_OUTER_ZERO_3X5"
    assert "a16_fold_source" not in plan
    assert plan["search_policy"]["source"] == "NESTED_VIRTUAL_OUTER_ZERO_FRESH_SEVEN_FAMILY_TRAINING_ONLY"
    assert plan["search_policy"]["sensitivity_after_final_refit"] is False
    search = f5.compile_full_data_search_mice_tasks(plan)
    final = f5.compile_final_full_data_mice_task(plan)
    assert len(search) == 60
    assert len({row["task_sha256"] for row in [*search, final]}) == 61
    assert sum(len(row["chain_seeds"]) for row in [*search, final]) == (
        exact_fit_budget_contract()["full_data_same_program"]["ledger"]["mice_chains"]
    ) == 1220
    assert final["role"] == "ANALYSIS"
    assert final["requires_completed_action"] == "COMPILE_TRAINING_ONLY_DEVELOPMENT_INPUTS"
    assert final["chain_seeds"] == list(range(150000001, 150000021))
    _, fit_ids, rows = f5._mice_view_rows(plan, final)
    assert fit_ids == rows == plan["source_ids"]
    for task in search:
        view, fit_ids, rows = f5._mice_view_rows(plan, task)
        assert task["coordinates"]["virtual_outer"] == 0
        assert set(fit_ids) <= set(rows) <= set(plan["source_ids"])
        assert view["response_visibility"] == (
            "PHYSICALLY_ABSENT" if task["role"] == "APPLICATION"
            else "FIT_EVENT_AND_NELSON_AALEN_TRANSIENT_ONLY"
        )
        if "STOP" in task["view_id"]:
            assert task["chain_rng_substream"] == 1
        else:
            assert "chain_rng_substream" not in task


@pytest.mark.parametrize("cpus", [32, 64, 128])
def test_original_full0_dispatch_index_owns_six_disjoint_imputation_shards(tmp_path, monkeypatch, cpus):
    """Original index/CLI-consumer plumbing; no scientific engine or native fit."""
    from padml import runtime
    from padml.run import HOSTS
    monkeypatch.setattr(runtime, "effective_cpu_count", lambda: cpus)
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda root: {
        "effective_cpus": cpus, "available_memory_bytes": 10**12,
        "scratch_available_bytes": 10**12, "scratch_root": str(root)})
    policy = {"configured_worker_ceiling": "EXECUTION_HOST_C_MINUS_8",
              "memory_bytes_per_worker": 1, "scratch_bytes_per_worker": 1,
              "memory_reserve_bytes": 0, "scratch_reserve_bytes": 0,
              "transfer_archive_worker_ceiling": 1000}
    source = tmp_path / "UNFITTED-source.json"
    source.write_bytes(canonical_json_bytes({"science_decision": _unfitted_confirmed_decision(),
        "plan": {}, "selector_root": str(tmp_path), "search_roots": {}, "score_root": str(tmp_path),
        "rscript": "UNFITTED", "resource_policy": policy, "retained_bytes_per_component": 1000,
        "expanded_bytes_per_component": 1000, "shared_storage_bytes": 1000, "mice_root": str(tmp_path),
        "final_mice_path": str(tmp_path / "UNFITTED.zip"), "response_path": str(tmp_path / "UNFITTED.csv")}))
    (tmp_path / "UNFITTED.zip").write_bytes(b"UNFITTED_MICE_COMPILER_LEAF")
    inputs = tmp_path / "inputs"
    model_tasks = {i: {"imputation": i, "UNFITTED": True} for i in range(1, 21)}
    def compile_inputs(*args, **kwargs):
        inputs.mkdir()
        (inputs / "bound").mkdir()
        records = []
        for imp in range(1, 21):
            raw = b"UNFITTED_COMPONENT_PLACEHOLDER"
            (inputs / "bound" / f"M{imp:02d}.zip").write_bytes(raw)
            records.append({"imputation": imp, "path": f"bound/M{imp:02d}.zip",
                "task_sha256": sha256_bytes(canonical_json_bytes(model_tasks[imp])),
                "sha256": sha256_bytes(raw), "size_bytes": len(raw)})
        return {"kind": "PADML_NESTED_FULL_FINAL_INPUT_V1", "identity_sha256": "a" * 64,
            "training_context": {"identity_sha256": "b" * 64, "training_ids": ["UNFITTED"],
                                 "centers_by_patient": {"UNFITTED": "55"}},
            "development_lock": {"identity_sha256": "c" * 64, "selected_family": "COX_PH"},
            "family_decision": {"identity_sha256": "d" * 64, "selected_family": "COX_PH"},
            "component_records": records}
    monkeypatch.setattr(f5, "_compile_full_final_inputs", compile_inputs)
    monkeypatch.setattr(f5._nested_science, "_read_component", lambda path: ({}, {"UNFITTED": True}, {}))
    compiled = f5.compile_final_refit_bundles(full_development_path=source, target_root=inputs)
    index = strict_json_bytes((inputs / "dispatch-index.json").read_bytes())
    expected = [{"host": host, "imputations": list(range(i + 1, 21, 6))} for i, host in enumerate(HOSTS)]
    assert index["host_parallelism"] == 6 and index["host_shards"] == expected
    assert index["execution_profile"]["pool_workers"] == "EXECUTION_HOST_C_MINUS_8"
    seen = []
    source_workers = []
    def consume_source(*args, **kwargs):
        assert kwargs["compiled_input_record"] == compiled
        source_workers.append(kwargs["workers"])
        return model_tasks
    monkeypatch.setattr(f5, "_consume_final_parameter_source", consume_source)
    def unfitted_job(job):
        imp = job[3]["imputation"]
        seen.append(imp)
        return {"imputation": imp, "final_model_fit_count": 0, "native_model_replay_count": 0,
                "final_numerical_component_count": 1,
                "shap_component_archive": {"reuse_status": "REUSED_EXACT_COMPONENT"}}
    monkeypatch.setattr(f5, "_execute_final_refit_bundle_pair", unfitted_job)
    monkeypatch.setattr(f5, "_bounded_ordered_spawn", lambda fn, jobs, **kw: [fn(job) for job in jobs])
    for bad in (None, [1, 2]):
        with pytest.raises(ContractError, match="NESTED_SIX_HOST_IMPUTATION_SHARD_REQUIRED"):
            f5.execute_final_refit_batch(inputs, tmp_path / "bad", imputations=bad, resource_policy=policy)
    assert not seen
    for unavailable in ("scratch_available_bytes", "available_memory_bytes"):
        with monkeypatch.context() as insufficient:
            insufficient.setattr(runtime, "observe_execution_resources", lambda root: {
                "effective_cpus": cpus, "available_memory_bytes": 10**12,
                "scratch_available_bytes": 10**12, "scratch_root": str(root), unavailable: 1})
            with pytest.raises(ContractError, match="RESOURCE_ADMISSION_ZERO"):
                f5.execute_final_refit_batch(inputs, tmp_path / ("insufficient-" + unavailable),
                    imputations=expected[0]["imputations"], resource_policy={**policy, "scratch_bytes_per_worker": 2},
                    compiled_input_record=compiled)
    assert not seen
    with monkeypatch.context() as limited:
        limited.setattr(runtime, "observe_execution_resources", lambda root: {
            "effective_cpus": cpus, "available_memory_bytes": 10**12,
            "scratch_available_bytes": 3, "scratch_root": str(root)})
        result = f5.execute_final_refit_batch(inputs, tmp_path / "low-retention-space",
            imputations=expected[0]["imputations"], resource_policy={**policy, "scratch_reserve_bytes": 1024},
            compiled_input_record=compiled)
        assert result["shard_retention_and_peak_scratch_estimate_bytes"] == 1024 + len(expected[0]["imputations"])
        assert result["execution_scratch_reserve_bytes"] == result["effective_policy"]["scratch_reserve_bytes"] == 0
        assert result["admitted_worker_ceiling"] == 3
        assert sorted(seen) == expected[0]["imputations"]
    seen.clear()
    from os import stat_result
    other_mount = tmp_path / "other-mount"
    other_mount.mkdir()
    original_stat = Path.stat
    def different_device(path, *args, **kwargs):
        observed = original_stat(path, *args, **kwargs)
        if path == other_mount:
            values = list(observed)
            values[2] = observed.st_dev + 1
            return stat_result(values)
        return observed
    with monkeypatch.context() as mounted:
        mounted.setattr(Path, "stat", different_device)
        with pytest.raises(ContractError, match="F5_FULL_FINAL_DIAGNOSTIC_SCRATCH_FILESYSTEM_MISMATCH"):
            f5.execute_final_refit_batch(inputs, other_mount, imputations=[1],
                resource_policy=policy, compiled_input_record=compiled)
    assert not seen
    source_workers.clear()
    reports = [f5.execute_final_refit_batch(inputs, tmp_path / host["host"],
                imputations=host["imputations"], resource_policy=policy, compiled_input_record=compiled) for host in expected]
    assert sorted(seen) == list(range(1, 21)) and len(set(seen)) == 20
    assert source_workers == [cpus - 8] * 6
    for owner, report in zip(expected, reports, strict=True):
        assert report["host_parallelism"] == 6 and report["host"] == owner["host"]
        assert report["pool_workers"] == report["configured_worker_ceiling"] == cpus - 8
        assert report["admitted_worker_ceiling"] == report["active_worker_limit"] == len(owner["imputations"])
        assert report["shard_retention_and_peak_scratch_estimate_bytes"] == len(owner["imputations"])


def test_full0_reuses_exact_mice_math_but_not_old_family_or_a16_identity(full_inputs):
    nested = _plan(full_inputs)
    old = _plan(full_inputs, "COXTIME_SET_A")
    assert nested["split_pairs"] == old["split_pairs"]
    assert nested["final_full_data"]["analysis"] == old["final_full_data"]["analysis"]
    assert nested["final_full_data"]["chain_seeds"] == old["final_full_data"]["chain_seeds"]
    assert f5.compile_final_full_data_mice_task(nested)["task_sha256"] != (
        f5.compile_final_full_data_mice_task(old)["task_sha256"]
    )
    assert _plan(tuple(list(reversed(values)) for values in full_inputs)) == nested


def test_full0_public_search_plan_rebuild_preserves_deferred_cpu_policy(full_inputs, tmp_path):
    """Replay actual raw-view ZIPs, not native MICE, through the original reader."""
    plan = _plan(full_inputs)
    ids, centers, events = full_inputs
    center_by_id = dict(zip(ids, centers, strict=True))
    event_by_id = dict(zip(ids, events, strict=True))

    def csv_bytes(fields, rows):
        buffer = io.StringIO(newline="")
        writer = csv.DictWriter(buffer, fieldnames=fields, lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)
        return buffer.getvalue().encode()

    response = csv_bytes(["Patient_ID", "All_Cause_Death", "Death_Followup_months"], [
        {"Patient_ID": patient, "All_Cause_Death": event_by_id[patient], "Death_Followup_months": "50"}
        for patient in plan["source_ids"]])
    fields, responses = f5._response_rows(response)
    members = {}
    for task in f5.compile_full_data_search_mice_tasks(plan):
        _, fit_ids, row_ids = f5._mice_view_rows(plan, task)
        entries = {"inputs/covariates.csv": csv_bytes(["Patient_ID", "Center"], [
            {"Patient_ID": patient, "Center": center_by_id[patient]} for patient in row_ids])}
        if task["role"] == "ANALYSIS":
            entries["inputs/response.csv"] = csv_bytes(fields, [responses[patient] for patient in fit_ids])
        key = f"{task['split_id']}/{task['role'].lower()}.zip"
        path = tmp_path / key.replace("/", "-")
        f5.write_deterministic_zip(path, entries)
        members[key] = path
    rebuilt = f5._validate_final_search_plan(plan, members, response)
    assert rebuilt["mice_plan_sha256"] == sha256_bytes(canonical_json_bytes(plan))
    assert rebuilt["response_sha256"] == f5._write_response_subset(
        fields, responses, plan["source_ids"], None)["sha256"]


@pytest.mark.parametrize("damage", ["family", "families", "a16", "scope", "stop", "final_barrier", "full_application"])
def test_full0_rejects_legacy_or_incomplete_plan(full_inputs, damage):
    plan = copy.deepcopy(_plan(full_inputs))
    if damage == "family":
        plan["family"] = "GBM_COX"
    elif damage == "families":
        plan["families"].pop()
    elif damage == "a16":
        plan["a16_fold_source"] = {}
    elif damage == "scope":
        plan["development_scope"] = "AGGREGATE_SIX_OLD_SELECTORS"
    elif damage == "stop":
        plan["split_pairs"][-1].pop("stop_mice")
    elif damage == "final_barrier":
        plan["final_full_data"]["requires_completed_action"] = "SELECT_COMPLETE_JOINT_CONFIGURATION"
    else:
        plan["final_full_data"]["application"] = plan["final_full_data"]["analysis"]
    with pytest.raises(ContractError):
        f5.compile_final_full_data_mice_task(plan)


def test_full0_materializer_admits_shared_stop_before_native_read(full_inputs, tmp_path, monkeypatch):
    plan = _plan(full_inputs)
    ids, _, events = full_inputs
    response = ("Patient_ID,All_Cause_Death,Death_Followup_months\n" + "".join(
        f"{patient},{event},50\n" for patient, event in zip(ids, events, strict=True)
    )).encode()
    def reached_native_reader(*args, **kwargs):
        raise RuntimeError("EXPECTED_NATIVE_READER_BOUNDARY_NO_MICE_EXECUTED")
    monkeypatch.setattr(f5, "_extract_full_data_mice_view", reached_native_reader)
    with pytest.raises(RuntimeError, match="EXPECTED_NATIVE_READER_BOUNDARY"):
        f5.materialize_full_data_search_partition(
            plan, plan["split_pairs"][0]["split_id"],
            tmp_path / "analysis.zip", tmp_path / "application.zip", response,
            tmp_path / "materialized", stop_analysis_payload=tmp_path / "stop-analysis.zip",
            stop_application_payload=tmp_path / "stop-application.zip",
        )


def _selector_inputs():
    context = {"source": {
        "kind": "PADML_NESTED_FULL_DATA_SELECTOR_SOURCE_V1",
        "program_id": "PADML_NESTED_LOCO_20260908", "context": 0,
        "mice_plan_sha256": "a" * 64, "training_ids_sha256": "b" * 64,
        "training_response_sha256": "c" * 64,
    }}
    partitions = [
        {"partition_id": f"R{repeat}_K{inner}", "kind": "INNER" if inner else "FINAL_FULL_DATA",
         "repeat": repeat, "inner_fold": inner, "transform_recipe": {"UNFITTED": True}}
        for repeat, inner in [*[(repeat, inner) for repeat in range(1, 4) for inner in range(1, 6)], (0, 0)]
    ]
    return context, partitions


def test_full0_selector_has_320_original_path_coordinates_not_a16_or_bootstrap(tmp_path, monkeypatch):
    def forbidden(*args, **kwargs):
        raise AssertionError("NO_BOOTSTRAP_IDENTITY_OR_SEED")
    monkeypatch.setattr(f4, "_full_pipeline_seed_record", forbidden)
    context, partitions = _selector_inputs()
    calls = f4._full_pipeline_selector_phase_calls(
        context, partitions, [0.05, 0.1], tmp_path / "phase", rscript="NOT_EXECUTED",
    )
    assert len(calls) == 16 * 20 == 320
    for index, (spec, partition, task, _, _) in enumerate(calls):
        assert spec["execution_scope"] == "NESTED_FULL_DATA_SELECTOR_M20"
        assert spec["seed"] == 300000 and spec["fold"] == 0
        assert spec["nested_source"] == context["source"]
        assert "full_pipeline_source" not in spec
        assert task["seed"] == 300000 + index % 20 + 1
        assert len(task["selected_parents"]) == 50 and "AST_ALT" in task["selected_parents"]
        assert task["alphas"] == [0.05, 0.1] and len(task["ratios"]) == 150
        assert task["producer_kind"] == ("ELASTIC_INNER_PATH" if partition["inner_fold"] else "ELASTIC_OUTER_PATH")


@pytest.mark.parametrize("damage", ["old_bootstrap", "outer", "legacy_a16", "one_repeat"])
def test_full0_selector_cannot_alias_other_scope(tmp_path, damage):
    context, partitions = _selector_inputs()
    selected = None
    if damage == "old_bootstrap":
        context["source"]["bootstrap_replicate"] = 1
    elif damage == "outer":
        context["source"]["context"] = 1
    elif damage == "legacy_a16":
        selected = ["AST_ALT", "Age"]
    else:
        partitions = partitions[:5] + partitions[-1:]
    with pytest.raises(ContractError):
        f4._full_pipeline_selector_phase_calls(
            context, partitions, [0.05], tmp_path / "phase", rscript="NOT_EXECUTED", selected_parents=selected,
        )


@pytest.mark.parametrize("outer", [0, 1, 6])
def test_no_aar_selector_has_complete_fresh_domain_and_context_seeds(tmp_path, outer):
    context, partitions = _selector_inputs()
    context["source"].update(
        kind="PADML_NESTED_NO_AAR_SELECTOR_SOURCE_V1", context=outer,
        inherited_family="COX_PH", primary_development_lock_sha256="d" * 64,
    )
    partitions[-1]["kind"] = "OUTER_TRAINING" if outer else "FINAL_FULL_DATA"
    calls = f4._full_pipeline_selector_phase_calls(
        context, partitions, [0.05], tmp_path / "phase", rscript="NOT_EXECUTED",
    )
    expected = [parent for parent in f5._elastic_parent_design_columns(
        f5.predictor_contract(Path(f5.__file__).parent)) if parent not in {"AST", "ALT", "AST_ALT"}]
    assert len(expected) == 49 and len(calls) == 320
    for index, (spec, _, task, _, _) in enumerate(calls):
        assert spec["execution_scope"] == "NESTED_NO_AAR_SELECTOR_M20"
        assert spec["fold"] == outer and spec["nested_source"] == context["source"]
        assert task["selected_parents"] == expected
        assert task["seed"] == 300000 + 1000 * outer + index % 20 + 1


@pytest.mark.parametrize("damage", ["family", "lock", "context", "kind", "stop", "extra", "fixed_set"])
def test_no_aar_selector_rejects_cross_scope_or_fixed_set(tmp_path, damage):
    context, partitions = _selector_inputs()
    context["source"].update(
        kind="PADML_NESTED_NO_AAR_SELECTOR_SOURCE_V1", context=1,
        inherited_family="COX_PH", primary_development_lock_sha256="d" * 64,
    )
    partitions[-1]["kind"] = "OUTER_TRAINING"
    selected = None
    if damage == "family":
        context["source"]["inherited_family"] = "GLOBAL_F5_LOCK"
    elif damage == "lock":
        context["source"]["primary_development_lock_sha256"] = "missing"
    elif damage == "context":
        context["source"]["context"] = True
    elif damage == "kind":
        partitions[-1]["kind"] = "FINAL_FULL_DATA"
    elif damage == "stop":
        partitions[0]["stopping"] = {}
    elif damage == "extra":
        context["source"]["selected_parents"] = ["Age"]
    else:
        selected = ["AST_ALT", "Age"]
    with pytest.raises(ContractError):
        f4._full_pipeline_selector_phase_calls(
            context, partitions, [0.05], tmp_path / "phase", rscript="NOT_EXECUTED", selected_parents=selected,
        )


def _physical_full_inputs(inputs, root, *, complete_covariates=False):
    """Real files/hashes and split/STOP responses; covariates are UNFITTED stubs."""
    plan = _plan(inputs)
    source_ids, _, events = inputs
    event_by_id = dict(zip(source_ids, events, strict=True))
    center_by_id = dict(zip(source_ids, inputs[1], strict=True))
    ordered = plan["source_ids"]
    source_by_key = dict(zip(plan["patient_keys"], ordered, strict=True))
    fields = ["Patient_ID", "All_Cause_Death", "Death_Followup_months"]
    responses = {patient: dict(zip(fields, [patient, str(event_by_id[patient]), "50"], strict=True))
                 for patient in ordered}

    def covariates(target, partition_id, fit_ids, row_ids, *, final=False):
        target.mkdir(parents=True)
        stream = io.StringIO(newline="")
        writer = csv.writer(stream, lineterminator="\n")
        columns = (f5.load_science_authority()["science"]["mice"]["private_handoff"]["columns"]
                   if complete_covariates else ["Patient_ID", "Age"])
        writer.writerow(columns)
        writer.writerows([{"Patient_ID": patient, "Center": center_by_id[patient], "Age": 50}.get(column, 1)
                          for column in columns] for patient in row_ids)
        raw = stream.getvalue().encode()
        members = []
        for imputation in range(1, 21):
            path = target / f"imp{imputation:02d}.csv"
            path.write_bytes(raw)
            members.append({"name": path.name, "sha256": sha256_bytes(raw), "size_bytes": len(raw)})
        return {
            "kind": "PADML_F5_FINAL_MICE_BINDING" if final else "PADML_F2_REGISTERED_VIEW_BINDING",
            "status": "PASS", "partition_id": partition_id, "input_dir": str(target), "members": members,
            "data_identity": sha256_bytes(canonical_json_bytes(members)),
            "analysis_ids_sha256": sha256_bytes(canonical_json_bytes(fit_ids)),
            "analysis_view_sha256": sha256_bytes(f"UNFITTED-ANALYSIS:{partition_id}".encode()),
            **({} if final else {
                "application_ids_sha256": sha256_bytes(canonical_json_bytes(row_ids)),
                "application_view_sha256": sha256_bytes(f"UNFITTED-APPLICATION:{partition_id}".encode()),
            }),
        }

    def partition(partition_id, kind, fit_ids, eval_ids, row_ids, repeat, inner):
        completed = covariates(root / partition_id / "covariates", partition_id, fit_ids, row_ids)
        return {
            "kind": kind, "partition_id": partition_id, "repeat": repeat, "inner_fold": inner,
            "fit_ids": fit_ids, "evaluation_ids": eval_ids, "application_ids": row_ids,
            "evaluation_ids_sha256": sha256_bytes(canonical_json_bytes(eval_ids)),
            "covariates": completed,
            "fit_response": f5._write_response_subset(fields, responses, fit_ids, root / partition_id / "fit.csv"),
            "evaluation_response": f5._write_response_subset(fields, responses, eval_ids, None),
            "fit_covariate_members": f5._fit_covariate_member_records(completed, fit_ids),
        }

    parts = []
    for pair in plan["split_pairs"]:
        validation = set(pair["validation_patient_keys"])
        train_keys = [key for key in plan["patient_keys"] if key not in validation]
        train = [source_by_key[key] for key in train_keys]
        evaluate = [source_by_key[key] for key in plan["patient_keys"] if key in validation]
        repeat, inner = pair["coordinates"]["repeat"], pair["coordinates"]["inner_fold"]
        part = partition(pair["split_id"], "INNER", train, evaluate, ordered, repeat, inner)
        stop_fit_keys, stop_keys = f5._training_stop_keys(
            train_keys, {key: event_by_id[source_by_key[key]] for key in plan["patient_keys"]}, pair["stopping"]["seed"],
        )
        part["stopping"] = {
            **partition(pair["stopping"]["partition_id"], "STOP", [source_by_key[key] for key in stop_fit_keys],
                        [source_by_key[key] for key in stop_keys], train, repeat, inner),
            **pair["stopping"],
        }
        parts.append(part)
    completed = covariates(root / "full" / "covariates", "F5_FINAL_FULL_DATA", ordered, ordered, final=True)
    response = f5._write_response_subset(fields, responses, ordered, root / "full" / "fit.csv")
    final = {
        "kind": "FINAL_FULL_DATA", "partition_id": "F5_FINAL_FULL_DATA", "fit_ids": ordered,
        "covariates": completed, "fit_response": response,
        "fit_covariate_members": f5._fit_covariate_member_records(completed, ordered),
        "development_input": {"mice_plan_sha256": sha256_bytes(canonical_json_bytes(plan)),
                              "raw_covariates_sha256": sha256_bytes(b"UNFITTED_RAW_COHORT_SOURCE"),
                              "response_sha256": response["sha256"]}, "model_fit_count": 0,
    }
    return plan, parts, final


def test_full0_physical_selector_inputs_are_15_inner_plus_full(full_inputs, tmp_path):
    plan, parts, final = _physical_full_inputs(full_inputs, tmp_path)
    before = copy.deepcopy(parts)
    observed = []
    context, projected = f5._nested_full_selector_inputs(plan, parts, final, on_partition_bindings=observed.extend)
    assert len(parts) == 15 and all("stopping" in part for part in parts)
    assert [(part["repeat"], part["inner_fold"]) for part in projected] == [
        *[(repeat, inner) for repeat in range(1, 4) for inner in range(1, 6)], (0, 0),
    ]
    assert all("stopping" not in part for part in projected)
    assert parts == before and context["source"]["training_response_sha256"] == final["fit_response"]["sha256"]
    assert observed == f5._a16_repeat_one_partition_bindings(plan, parts, required_repeats=(1, 2, 3))


def test_full0_selector_projection_does_not_read_stop_files(full_inputs, tmp_path, monkeypatch):
    plan, parts, final = _physical_full_inputs(full_inputs, tmp_path)
    expected = f5._nested_full_selector_inputs(plan, parts, final, on_partition_bindings=lambda rows: None)
    stop_roots = [Path(part["stopping"]["covariates"]["input_dir"]).parent for part in parts]
    original_open = Path.open
    def open_inner_or_full(path, *args, **kwargs):
        assert not any(path.is_relative_to(root) for root in stop_roots), "Selector must not open STOP evidence"
        return original_open(path, *args, **kwargs)
    monkeypatch.setattr(Path, "open", open_inner_or_full)
    assert f5._nested_full_selector_inputs(plan, parts, final) == expected
    inner_only = [{key: value for key, value in part.items() if key != "stopping"} for part in parts]
    assert f5._nested_full_selector_inputs(plan, inner_only, final) == expected
    with pytest.raises(ContractError, match="F5_A16_SEARCH_PARTITION_INVALID"):
        f5._nested_full_selector_inputs(plan, [None, *parts[1:]], final)


@pytest.mark.parametrize("damage", ["inner_member", "stop_member", "full_member", "full_response",
                                    "inner_followup_self_rehash", "stop_followup_self_rehash"])
def test_full0_selector_rejects_physical_or_response_source_drift(full_inputs, tmp_path, damage):
    plan, parts, final = _physical_full_inputs(full_inputs, tmp_path)
    if damage.endswith("_member"):
        part = {"inner_member": parts[0], "stop_member": parts[0]["stopping"], "full_member": final}[damage]
        path = Path(part["covariates"]["input_dir"]) / "imp01.csv"
        path.write_bytes(path.read_bytes() + b"tampered\n")
    elif damage == "full_response":
        path = Path(final["fit_response"]["path"])
        path.write_bytes(path.read_bytes().replace(b",50\n", b",51\n"))
    else:
        part = parts[0] if damage.startswith("inner") else parts[0]["stopping"]
        binding = part["evaluation_response"]
        raw = binding["private_bytes"].replace(b",50\n", b",51\n")
        binding.update(private_bytes=raw, sha256=sha256_bytes(raw), size_bytes=len(raw))
    observed = []
    with pytest.raises(ContractError):
        f5._nested_full_selector_inputs(plan, parts, final, on_partition_bindings=observed.extend)
    assert observed == []


def _unfitted_full_lambda_upper(recipe):
    from padml.f2_kernel import _elastic_candidate_parents, _expected_family_parent_column_map
    predictors = f5.predictor_contract(Path(f5.__file__).parent)
    columns = _expected_family_parent_column_map(
        _elastic_candidate_parents({"predictors": predictors}), "ELASTIC_NET_COX", predictors, recipe,
    )
    return {
        "schema_version": "1.0.0", "kind": "PADML_F2_ELASTIC_LAMBDA_UPPER_BOUND_V1",
        "glmnet_version": "5.0", "family": "cox", "cox_ties": "breslow", "alpha": 0.2,
        "standardize": True, "penalty_factor_identity_sha256": sha256_bytes(canonical_json_bytes({
            "design_columns": [column for row in columns for column in row["columns"]],
            "penalty_factor": [0.0 if row["parent"] == "AST_ALT" else 1.0 for row in columns for _ in row["columns"]],
        })), "pilot_requested_nlambda": 100, "pilot_returned_nlambda": 100,
        "pilot_lambda_head": [2.0, 1.8, 1.6], "resolved_lambda_max": 2.0,
        "glmnet_big": 9.9e35, "sentinel_equivalent": False,
    }


@pytest.fixture
def unfitted_full_score_sources(full_inputs, tmp_path, unfitted_selector_consumers, monkeypatch):
    inputs = _physical_full_inputs(full_inputs, tmp_path / "inputs", complete_covariates=True)
    selector_root = tmp_path / "selector"
    f5._nested_full_selector_program(*inputs, selector_root, rscript="UNFITTED", replay=False)
    modes = []
    def native(spec, registered, scratch):
        from padml.nested_loco import _sealed, _sha
        family = spec["family"]
        modes.append((family, "NUMBERS" if spec.get("native_search_numbers") else spec["native_search_replay"]))
        candidate = spec["candidate_trials"]["S1"][0]
        parameters = candidate if family == "COXTIME_SET_A" else candidate["parameters"]
        selected = {"family": family, "parameters": parameters,
                    "candidate_id": candidate.get("candidate_id", candidate.get("trial_id")),
                    "selection_stage": "S3B2", "selection_metric": "IBS_0_24"}
        if family == "GBM_COX":
            selected["selected_trees"] = 100
        elif family == "XGBOOST_COX":
            selected["selected_rounds"] = 20
        elif family == "COXTIME_SET_A":
            selected["locked_epoch"] = 50
        f5._validate_final_refit_locked_spec(family, selected)
        marker = Path(spec["native_search_root"]) / "UNFITTED-native-source.json"
        raw = canonical_json_bytes(spec["final_search_source"])
        if spec["native_search_replay"]:
            assert marker.read_bytes() == raw
        else:
            marker.write_bytes(raw)
        model = marker.parent / ("UNFITTED-model.rds" if family in {"RSF", "GBM_COX"} else "model.bin")
        if not spec["native_search_replay"]:
            model.write_bytes(b"UNFITTED_SCORE_SOURCE_NATIVE")
        elif not spec.get("native_search_numbers"):
            assert model.read_bytes() == b"UNFITTED_SCORE_SOURCE_NATIVE"
        return _sealed({"UNFITTED_NATIVE_SEARCH": True, "execution_scope": spec["execution_scope"],
            "family": family, "registered_inputs_identity_sha256": registered["identity"],
            "selected_parents": spec["selector_from_dependency"]["selected_parents"],
            "selected_spec": selected, "selected_spec_sha256": _sha(selected)})
    monkeypatch.setattr(f5, "_run_final_complex_search", native)
    monkeypatch.setattr(f5, "resolve_pool_workers", lambda workers: 1 if workers is None else workers)
    roots = {}
    for family in ["RSF", "GBM_COX", "XGBOOST_COX", "COXTIME_SET_A"]:
        task = f5.compile_nested_full_complex_search_task(*inputs, selector_root, family=family, rscript="UNFITTED")
        roots[family] = tmp_path / family
        f5._final_complex_search_program(task, inputs[1], roots[family], replay=False, workers=1)
    return inputs, selector_root, roots, modes


@pytest.mark.parametrize("consumer", ["Q", "SCORES"])
def test_full0_source_bindings_are_reused_only_after_selector_revalidation(
    unfitted_full_score_sources, monkeypatch, consumer,
):
    inputs, selector_root, roots, modes = unfitted_full_score_sources
    inner_only = [{key: value for key, value in part.items() if key != "stopping"} for part in inputs[1]]
    if consumer == "SCORES":
        import shutil
        from padml.f4_compact import _full_pipeline_q_numerical_members
        numeric = {}
        for family, root in roots.items():
            projected, _ = _full_pipeline_q_numerical_members(root)
            destination = selector_root.parent / "numeric-score-sources" / family
            for name, path in projected.items():
                target = destination / name
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(path, target)
            assert not list(destination.rglob("*.rds")) and not list(destination.rglob("model.bin"))
            numeric[family] = destination
        roots = numeric
    original = f5._a16_repeat_one_partition_bindings
    observed = []
    def bind(*args, **kwargs):
        value = original(*args, **kwargs)
        observed.append(value)
        return value
    monkeypatch.setattr(f5, "_a16_repeat_one_partition_bindings", bind)
    if consumer == "Q":
        task = f5.compile_nested_full_complex_search_task(*inputs, selector_root, family="RSF", rscript="UNFITTED")
        bindings = task["search_partition_bindings"]
    else:
        development = f5._nested_full_score_development(*inputs, selector_root, roots, rscript="UNFITTED", workers=1)
        bindings = development["complex_search_evidence"][0]["task"]["search_partition_bindings"]
        for row in development["complex_search_evidence"]:
            expected = original(inputs[0], inner_only if row["family"] == "RSF" else inputs[1], required_repeats=(1, 2, 3),
                                **({"include_stop": False} if row["family"] == "RSF" else {}))
            assert row["task"]["search_partition_bindings"] == expected
        assert [mode for _, mode in modes[-4:]] == ["NUMBERS"] * 4
        assert all(any(member["path"].endswith(("model.bin", ".rds")) for member in row["native_members"])
                   for row in development["complex_search_evidence"])
    assert len(observed) == 2  # source validation before and after the original selector replay
    assert observed[1] == original(inputs[0], inner_only if consumer == "Q" else inputs[1], required_repeats=(1, 2, 3),
                                    **({"include_stop": False} if consumer == "Q" else {}))
    assert bindings == original(inputs[0], inner_only, required_repeats=(1, 2, 3), include_stop=False)
    selector = f5._nested_full_selector_program
    def changed_after_selector(*args, **kwargs):
        value = selector(*args, **kwargs)
        member = Path(inputs[1][0]["covariates"]["input_dir"]) / "imp01.csv"
        member.write_bytes(member.read_bytes() + b"UNFITTED_CHANGED_AFTER_SELECTOR\n")
        return value
    monkeypatch.setattr(f5, "_nested_full_selector_program", changed_after_selector)
    before_modes = list(modes)
    with pytest.raises(ContractError, match="F5_A16_SEARCH_COVARIATE_BYTES_INVALID"):
        if consumer == "Q":
            f5.compile_nested_full_complex_search_task(*inputs, selector_root, family="RSF", rscript="UNFITTED")
        else:
            f5._nested_full_score_development(*inputs, selector_root, roots, rscript="UNFITTED", workers=1)
    assert modes == before_modes  # changed source never reaches a Q native consumer


def test_full0_2100_locked_components_rebuild_from_selector_and_all_qs_without_extra_stop(
    unfitted_full_score_sources, tmp_path, monkeypatch,
):
    from padml.nested_loco import _read_component
    def forbidden(*args, **kwargs):
        raise AssertionError("UNAUTHORIZED_OUTER_SOURCE_STOP_OR_FIT")
    for name in ("_prepare_o_fit_partition", "_full_pipeline_elastic_parameters", "_f4_elastic_parameters",
                 "_execute_f4_stop_component", "_execute_f4_model_component"):
        monkeypatch.setattr(f4, name, forbidden)
    inputs, selector_root, roots, modes = unfitted_full_score_sources
    from collections import Counter
    member_paths = {Path(part["covariates"]["input_dir"]) / member["name"]
                    for part in inputs[1] for member in part["covariates"]["members"]}
    original_open, reads = Path.open, Counter()
    def count_csv_open(path, *args, **kwargs):
        # Count this assembler, not the separate selector/Q source readers;
        # their original validation remains mandatory and is a distinct item.
        import sys
        if (path in member_paths and kwargs.get("encoding") == "utf-8-sig"
                and sys._getframe(1).f_code is f5._compile_full_score_inputs.__code__):
            reads[path] += 1
        return original_open(path, *args, **kwargs)
    monkeypatch.setattr(Path, "open", count_csv_open)
    staged = []
    inner_only = [{key: value for key, value in part.items() if key != "stopping"} for part in inputs[1]]
    for index, family in enumerate(f5._nested_science._families()):
        own_roots = {name: path if name == family else tmp_path / "UNREADY" / name for name, path in roots.items()}
        own_inputs = inputs if family in f5._STOP_CONSUMERS else (inputs[0], inner_only, inputs[2])
        own = f5._compile_full_score_inputs(*own_inputs, selector_root, own_roots, tmp_path / "request",
                                           rscript="UNFITTED", family=family, resume=index > 0)
        assert set(own["development"]["locked_specs"]) == {family}
        assert len(own["component_records"]) == 300 and own["planned_scoring_fits"] == 2100
        assert not (tmp_path / "request/full-score-input.json").exists()
        assert all(row["family"] == family for row in own["development"]["complex_search_evidence"])
        staged.append(own)
    assert reads == {path: 7 for path in member_paths}
    reads.clear()
    request = f5._compile_full_score_inputs(*inputs, selector_root, roots, tmp_path / "request", rscript="UNFITTED", resume=True)
    replayed = f5._compile_full_score_inputs(*inputs, selector_root, roots, tmp_path / "request", rscript="UNFITTED", replay=True)
    assert request == replayed
    assert request["component_records"] == [row for own in staged for row in own["component_records"]]
    assert all(own["training_context"] == request["training_context"] for own in staged)
    for own in staged:
        family = own["component_records"][0]["family"]
        assert f5._full_score_family_source(own["development"], family) == f5._full_score_family_source(request["development"], family)
    assert reads == {path: 2 for path in member_paths}  # once per MI per compile, not per family/population
    monkeypatch.setattr(Path, "open", original_open)
    from padml.f2_kernel import _recipe_training_member_bytes
    expected_subsets = {(part["repeat"], part["inner_fold"], imputation): (
        _recipe_training_member_bytes(Path(part["covariates"]["input_dir"]) / member["name"], part["fit_ids"]),
        _recipe_training_member_bytes(Path(part["covariates"]["input_dir"]) / member["name"], part["evaluation_ids"]))
        for part in inputs[1] for imputation, member in enumerate(part["covariates"]["members"], 1)}
    assert [(row["family"], row["repeat"], row["inner_fold"], row["imputation"]) for row in request["component_records"]] == [
        (family, repeat, inner, imputation) for family in f5._nested_science._families()
        for repeat in range(1, 4) for inner in range(1, 6) for imputation in range(1, 21)]
    assert len(request["component_records"]) == request["planned_scoring_fits"] == 2100
    assert request["new_stop_fits"] == request["post_lock_fits"] == 0 and request["reused_training_scores"] == []
    assert request["training_context"]["scope"] == "FULL_DATA" and request["training_context"]["heldout_ids"] == []
    assert len(modes) == 20 and [mode for _, mode in modes[:8]] == [False, True] * 4
    assert all(mode == "NUMBERS" for _, mode in modes[8:])
    samples = {}
    family_sources = {family: f5._full_score_family_source(request["development"], family) for family in f5._nested_science._families()}
    for record in request["component_records"]:
        task, recipe, entries = _read_component(tmp_path / "request" / record["path"])
        assert (entries["fit-covariates.csv"], entries["prediction-covariates.csv"]) == expected_subsets[
            record["repeat"], record["inner_fold"], record["imputation"]]
        f4._f4_native_component_inputs(entries)
        family = record["family"]
        samples.setdefault(family, task)
        assert task["f4_coordinates"]["purpose"] == "NESTED_FULL_SCORE"
        assert "stop-response.csv" not in entries and "stop_parameters" not in task
        assert task["nested_full_score_source"] == family_sources[family]
        if family in {"GBM_COX", "XGBOOST_COX", "COXTIME_SET_A"}:
            assert task["parameters"] == request["development"]["locked_specs"][family]
        if family == "ELASTIC_NET_COX":
            source = task["f4_nested_full_elastic_source"]
            parameters, columns = f4._nested_full_elastic_parameters(source, task["f4_coordinates"])
            assert task["parameters"] == parameters and len(columns) == 50
            assert source["full_transform_recipe"]["partition_id"] == "F5_FINAL_FULL_DATA"
            assert recipe["transform_recipe"]["partition_id"] != "F5_FINAL_FULL_DATA"
    for damage in ["source", "stop", "outer", "bootstrap", "parameters", "inner_lambda", "seta_lambda"]:
        task = copy.deepcopy(samples["ELASTIC_NET_COX" if damage in {"inner_lambda", "seta_lambda"} else "GBM_COX"])
        if damage == "source":
            del task["nested_full_score_source"]
        elif damage == "stop":
            task["stop_parameters"] = task["parameters"]
        elif damage == "outer":
            task["f4_coordinates"]["outer_fold"] = 1
        elif damage == "bootstrap":
            task["f4_coordinates"]["bootstrap_replicate"] = 1
        elif damage == "parameters":
            task["parameters"]["selected_trees"] += 1
        elif damage == "inner_lambda":
            task["f4_nested_full_elastic_source"]["full_transform_recipe"] = request["development"]["selector_development"]["transform_recipes"]["recipes"][0]
        else:
            upper = task["f4_nested_full_elastic_source"]["selected_spec"]["lambda_upper_bound_by_imputation"][0]
            upper["penalty_factor_identity_sha256"] = "0" * 64
        with pytest.raises(ContractError):
            f5._validate_nested_full_score_task(task)


@pytest.mark.parametrize("winner", ["COX_PH", "ELASTIC_NET_COX", "RSF", "GBM_COX", "XGBOOST_COX", "FPM_TVC_SET_A", "COXTIME_SET_A"])
def test_full0_final_compiler_locks_only_winner_and_replays_twenty_unfitted_objects(
    unfitted_full_score_sources, tmp_path, monkeypatch, winner, selection_horizon=24,
):
    """Real final inputs/lock/native archive plumbing; score proof/engines are UNFITTED stubs."""
    from padml import nested_loco as nested, runtime
    science = _unfitted_confirmed_decision(fresh_seven=True, fixed_bootstrap=True) if selection_horizon == 12 else _unfitted_confirmed_decision()
    if selection_horizon == 12:
        from functools import partial
        science = nested._sealed({**{k: v for k, v in science.items() if k != "identity_sha256"},
            "twelve_month_development": nested._twelve_month_development_contract()})
        # Bind the test's public calls to this line. Explicit internal arguments
        # still override partial defaults, so a stale internal 24 remains visible.
        for name in ("compile_final_refit_bundles", "execute_final_refit_batch",
                     "execute_final_aggregate"):
            monkeypatch.setattr(f5, name, partial(getattr(f5, name), selection_horizon_months=12))
    inputs, selector_root, roots, _ = unfitted_full_score_sources
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda path: {
        "effective_cpus": 16, "available_memory_bytes": 8 * 1024**3,
        "scratch_available_bytes": 10**9, "scratch_root": str(path)})
    replay_calls = []
    # This test isolates the F5 dispatcher/native-final consumer; the separate
    # 2100-archive integration test exercises the real scoring proof each time.
    development = f5._nested_full_score_development(*inputs, selector_root, roots, rscript="UNFITTED", workers=1)
    def score_replay(*args, **kwargs):
        assert args[:3] == inputs and args[3:5] == (selector_root, roots)
        assert kwargs["replay"] is True and kwargs.get("resume", False) is False
        replay_calls.append(True)
        context, selector = development["training_context"], development["selector_development"]
        request = nested._sealed({"UNFITTED_SCORE_PROOF_STUB": True, "development": development})
        scores = []
        for family in nested._families():
            value = 0.1 if family == winner else 0.2
            scores.append(nested.seal_fresh_training_score(
                family=family, outer_fold=0, training_context_sha256=context["identity_sha256"],
                selected_spec=development["locked_specs"][family], selector_evidence_sha256=selector["identity_sha256"],
                summary={"ranking_metric_values": [value] * 3, "fold_metric_values": [value] * 15,
                    "metric_values": [value] * 300, "ranking_metric_qc": [{"UNFITTED": True}] * 3,
                    "ranking_evaluation_count": 3, "evaluation_units": 300,
                    "mean_ibs": value, "maximum_ibs": value,
                    **({"selection_horizon_months": 12} if selection_horizon == 12 else {})},
                execution_evidence_sha256="a" * 64, source_kind="FRESH_FULL_DATA_M20_INNER_OOF",
                **({"selection_horizon_months": 12, "science_decision_sha256": science["identity_sha256"]}
                   if selection_horizon == 12 else {})))
        result = nested._sealed({"UNFITTED_SCORE_PROOF_STUB": True, "request_identity_sha256": request["identity_sha256"],
                                 "family_decision": nested.select_training_family(scores), "training_scores": scores})
        return {"request": request, "result": result, "new_model_fits": 0, "native_model_replay_count": 0,
                "score_numerical_component_count": 2100}
    monkeypatch.setattr(f5, "_full_data_locked_score_program", score_replay)
    for name in ("compile_final_recipe", "compile_final_refit_tasks", "_execute_final_refit_task"):
        monkeypatch.setattr(f5, name, lambda *a, **kw: pytest.fail("OLD_GLOBAL_OR_A16_AUTHORITY_FORBIDDEN"))
    for name in ("_f4_elastic_parameters", "_full_pipeline_elastic_parameters", "_nested_full_elastic_parameters"):
        monkeypatch.setattr(f4, name, lambda *a, **kw: pytest.fail("WRONG_SCOPE_ELASTIC_RESOLVER"))
    destination = tmp_path / "final-input"
    arguments = (*inputs, selector_root, roots, tmp_path / "UNFITTED-score-root", destination)
    budgets = {"rscript": "UNFITTED", "resource_policy": {
                   "configured_worker_ceiling": "EXECUTION_HOST_C_MINUS_8", "transfer_archive_worker_ceiling": 1,
                   "memory_bytes_per_worker": 1, "scratch_bytes_per_worker": 1,
                   "memory_reserve_bytes": 0, "scratch_reserve_bytes": 0},
               "retained_bytes_per_component": 1, "expanded_bytes_per_component": 1, "shared_storage_bytes": 1}
    source_description = tmp_path / "full-development.json"
    materializations = []
    def search_mice(plan, mice_root, response, destination, **kwargs):
        assert plan == inputs[0] and response == Path(inputs[2]["fit_response"]["path"]).read_bytes()
        materializations.append("INNER_AND_STOP_NATIVE_READER_STUB")
        return inputs[1]
    def final_mice(plan, payload, response, destination, **kwargs):
        assert plan == inputs[0] and response == Path(inputs[2]["fit_response"]["path"]).read_bytes()
        materializations.append("FULL_NATIVE_READER_STUB")
        return inputs[2]
    monkeypatch.setattr(f5, "_materialize_final_search_inputs", search_mice)
    monkeypatch.setattr(f5, "materialize_final_full_data_mice", final_mice)
    monkeypatch.setattr(f5, "_final_search_mice_members", lambda *args: {"UNFITTED_NATIVE_MICE_MEMBERS": True})
    monkeypatch.setattr(f5, "_validate_final_search_plan", lambda *args: inputs[2]["development_input"])
    source_description.write_bytes(canonical_json_bytes({
        "plan": inputs[0], "mice_root": str(tmp_path / "UNFITTED-MICE"),
        "final_mice_path": str(tmp_path / "UNFITTED-final-MICE.zip"), "response_path": inputs[2]["fit_response"]["path"],
        "selector_root": str(selector_root), "search_roots": {key: str(path) for key, path in roots.items()},
        "score_root": str(arguments[-2]), "science_decision": science,
        **({"selection_horizon_months": 12} if selection_horizon == 12 else {}), **budgets}))
    # The native MICE reader above is a separate stub; these explicit UNFITTED
    # bytes exercise artifact retention only, never native admissibility.
    f5.write_deterministic_zip(tmp_path / "UNFITTED-final-MICE.zip", {
        "UNFITTED.json": canonical_json_bytes({"MICE_NATIVE_READER_IS_MOCK": True})})
    pending_path = tmp_path / "pending-development.json"
    pending_path.write_bytes(canonical_json_bytes({**strict_json_bytes(source_description.read_bytes()),
                                                 "science_decision": nested.science_decision_template()}))
    with pytest.raises(ContractError, match="NESTED_SCIENCE_DECISION_INCOMPLETE"):
        f5.compile_final_refit_bundles(full_development_path=pending_path, target_root=destination, workers=1)
    assert not destination.exists() and not materializations
    # Existing per-view native reads are not enough: FULL and INNER/STOP must
    # come from the identical raw covariate cohort. No new validator is needed.
    with monkeypatch.context() as changed_source:
        changed_source.setattr(f5, "_validate_final_search_plan", lambda *args: {
            **inputs[2]["development_input"], "raw_covariates_sha256": "f" * 64})
        with pytest.raises(ContractError, match="F5_Q_DEVELOPMENT_SOURCE_MISMATCH"):
            f5.compile_final_refit_bundles(full_development_path=source_description, target_root=destination, workers=1)
    assert not destination.exists() and not replay_calls
    assert materializations == ["INNER_AND_STOP_NATIVE_READER_STUB", "FULL_NATIVE_READER_STUB"]
    materializations.clear()
    compiled = f5.compile_final_refit_bundles(full_development_path=source_description,
                                            target_root=destination, workers=1)
    assert compiled["status"] == "COMPILED_NOT_EXECUTED" and compiled["bundle_count"] == 20
    (tmp_path / "original-compile-record.json").write_bytes(canonical_json_bytes(compiled))
    assert materializations == ["INNER_AND_STOP_NATIVE_READER_STUB", "FULL_NATIVE_READER_STUB"]
    request = strict_json_bytes((destination / "full-final-input.json").read_bytes())
    if winner == "COX_PH":
        lineage = f5._read_final_lineage(destination / "lineage.json", selection_horizon_months=selection_horizon)
        original_read, opened = nested._read_component, []
        def one_snapshot(raw):
            assert isinstance(raw, bytes), "Parameter validation must bind one bounded source snapshot"
            parsed = original_read(raw)
            opened.append(parsed[0]["imputation"])
            return parsed
        with monkeypatch.context() as parsed_once:
            parsed_once.setattr(nested, "_read_component", one_snapshot)
            tasks = f5._consume_final_parameter_source(lineage, None, input_root=destination,
                compiled_input_record=compiled, selected_imputations=[1, 7])
        assert list(tasks) == opened == [1, 7]
        for invalid in ([], [1, 1], [True], [21]):
            with pytest.raises(ContractError, match="F5_FINAL_REFIT_BATCH_IMPUTATIONS_INVALID"):
                f5._consume_final_parameter_source(lineage, None, input_root=destination,
                    compiled_input_record=compiled, selected_imputations=invalid)
        untouched = destination / "bound/M02.zip"
        retained_untouched = destination / "retained-M02.zip"
        untouched.rename(retained_untouched)
        try:
            assert list(f5._consume_final_parameter_source(lineage, None, input_root=destination,
                compiled_input_record=compiled, selected_imputations=[1])) == [1]
            with pytest.raises(ContractError, match="F5_FULL_FINAL_COMPILED_COMPONENT_DRIFT"):
                f5._consume_final_parameter_source(lineage, None, input_root=destination, compiled_input_record=compiled)
        finally:
            retained_untouched.rename(untouched)
    assert f5._compile_full_final_inputs(*arguments, **budgets, replay=True,
        **({"selection_horizon_months": 12, "science_decision": science}
           if selection_horizon == 12 else {})) == request
    assert len(replay_calls) == 2 and request["external_validation"] is False
    assert request["planned_post_lock_model_fits"] == len(request["component_records"]) == 20
    lock, context = request["development_lock"], request["training_context"]
    assert lock["selected_family"] == winner and lock["outer_fold"] == 0 and lock["heldout_ids_sha256"] == nested._sha([])
    assert lock["common_set_design_df"] == 3 and lock["common_set_epv"] == 70 / 3
    calls = {"new_unfitted_objects": 0, "retained_reads": 0}
    def unfitted_health(family, task, binary):
        if family == "COX_PH":
            count = task["family_design_column_count"]
            return {"engine_threads": 1, "final_model_fit_count": 1, "engine": "survival::coxph", "ties": "breslow",
                "coefficient_count": count, "warning_count": 0, "converged": True,
                "covariance_rank": count, "iteration_count": 2}
        return {"UNFITTED": True,
                **({"model_binary_sha256": nested.sha256_bytes(binary)} if family == "XGBOOST_COX" else {})}
    def engine(family, task, training, response, recipe, *, retained_objects=None, prediction_rows=None, **kwargs):
        assert family == winner and prediction_rows is None
        f5._validate_nested_full_final_task(task)
        binary = canonical_json_bytes({"UNFITTED": True, "task": task, "recipe": recipe})
        if retained_objects is None:
            calls["new_unfitted_objects"] += 1
        else:
            assert retained_objects == (binary, binary)
            calls["retained_reads"] += 1
        return {"model": binary, "baseline": binary, "fit_health": unfitted_health(family, task, binary),
                "survival": [[1.0] + [0.6 if task["imputation"] <= 10 else 1.0] * 36 for _ in training]}
    def audit(family, model, baseline, health, task, **kwargs):
        assert strict_json_bytes(model)["task"] == task and model == baseline and health == unfitted_health(family, task, model)
        recipe = strict_json_bytes(model)["recipe"]
        columns = [column for row in f5._expected_family_parent_column_map(task["selected_parents"], family,
            f5.predictor_contract(Path(f5.__file__).parent), recipe["transform_recipe"]) for column in row["columns"]]
        if family in {"XGBOOST_COX", "COXTIME_SET_A"}:
            columns.sort(key=lambda text: text.encode())
            return {"design_columns": columns, **({"booster_round_count": task["parameters"]["selected_rounds"]}
                if family == "XGBOOST_COX" else {"input_width": len(columns)})}
        values = {"selected_parents": task["selected_parents"], "design_columns": columns}
        width, imp = task["family_design_column_count"], task["imputation"]
        if family in {"COX_PH", "ELASTIC_NET_COX"}:
            values["coefficient_ids"] = columns
            estimates = [imp / 100 + index / 50 for index in range(width)]
            if family == "COX_PH":
                values.update(complete_data_degrees_of_freedom=70 - width, training_event_count=70,
                    **{key: health[key] for key in ("coefficient_count", "covariance_rank", "iteration_count")},
                    covariance=[[.01 if left == right else 0. for right in range(width)] for left in range(width)],
                    coefficient_estimates=estimates, within_standard_errors=[.1] * width)
            else:
                values.update(alpha=task["parameters"]["alpha"], ratio=task["parameters"]["ratio"],
                    **{"lambda": task["parameters"]["lambda"]}, coefficient_scale=[1.] * width,
                    standardized_coefficients=estimates, raw_coefficients=estimates)
        elif family == "FPM_TVC_SET_A":
            from test_f5 import non_ph_contrast_evidence
            contrast = non_ph_contrast_evidence({"patient_ids": context["training_ids"],
                "per_imputation_predictions": [{"model_sha256": nested._sha({"UNFITTED": index})}
                                                for index in range(20)]})[imp - 1]
            values["non_ph_contrast"] = {key: value for key, value in contrast.items()
                                          if key not in {"imputation", "model_sha256"}}
            values["training_event_count"] = 70
        return values
    original_engine = f5._execute_final_refit_engine
    monkeypatch.setattr(f5, "_execute_final_refit_engine", engine)
    monkeypatch.setattr(f5, "_validate_retained_model_objects", audit)
    # Cox health/audit numerical validation is real. The other six families'
    # numerical-engine health leaves remain explicitly UNFITTED, as their
    # earlier native-engine evidence is separate from this transport test.
    from padml import f2_kernel
    original_r_health = f5._validate_final_r_fit_health
    original_python_health = f2_kernel._validate_python_fit_health
    original_audit_numbers = f5._validate_retained_r_audit_numbers
    monkeypatch.setattr(f5, "_validate_final_r_fit_health", lambda family, health, *a, **kw:
        health if health == {"UNFITTED": True} else original_r_health(family, health, *a, **kw))
    monkeypatch.setattr(f2_kernel, "_validate_python_fit_health", lambda family, health, *a, **kw:
        health if health.get("UNFITTED") is True else original_python_health(family, health, *a, **kw))
    monkeypatch.setattr(f5, "_validate_retained_r_audit_numbers", lambda family, values, health, task:
        values if health == {"UNFITTED": True} else original_audit_numbers(family, values, health, task))
    monkeypatch.setattr(f5, "_bounded_ordered_spawn", lambda fn, jobs, **kw: [fn(job) for job in jobs])
    original_shap = f5._produce_final_shap_component
    shap_calls = []
    def unfitted_shap(input_bundle, task, model, baseline, prediction, **kwargs):
        from test_f5 import final_shap_components
        assert strict_json_bytes(model)["task"] == task and model == baseline
        assert nested._read_component(input_bundle)[0] == task
        if kwargs.get("work_root") is not None:
            work_root = kwargs["work_root"]
            assert work_root.is_dir() and not any(work_root.iterdir())
            assert work_root.parent.parent.joinpath(f"F5_FINAL_FULL_DATA_M{task['imputation']:02d}.numbers.json").is_file()
            assert f5.tempfile.gettempdir() == str(work_root.parent.parent.parent)
        if not shap_calls:
            # M1 is explainable before M7 (same shard) or other models exist.
            assert task["imputation"] == 1 and calls == {"new_unfitted_objects": 1, "retained_reads": 1}
            assert not (output / "F5_FINAL_FULL_DATA_M07.zip").exists()
        shap_calls.append(task["imputation"])
        value = final_shap_components({"family": winner, "patient_ids": prediction["patient_ids"],
            "per_imputation_predictions": [prediction]})[0]
        value.update(imputation=task["imputation"], selected_parent_groups=task["selected_parents"])
        value["engine"]["seed"] = 780_000_000 + task["imputation"]
        padding = [0.] * (len(task["selected_parents"]) - 1)
        value["risk_contributions"] = [[row + padding for row in patient] for patient in value["risk_contributions"]]
        value["within_imputation_global_mean_absolute_contribution"] = [
            row + padding for row in value["within_imputation_global_mean_absolute_contribution"]]
        return value
    monkeypatch.setattr(f5, "_produce_final_shap_component", unfitted_shap)
    policy = {"configured_worker_ceiling": "EXECUTION_HOST_C_MINUS_8", "transfer_archive_worker_ceiling": 1,
              "memory_bytes_per_worker": 1, "scratch_bytes_per_worker": 1,
              "memory_reserve_bytes": 0, "scratch_reserve_bytes": 0}
    output = tmp_path / "unfitted-output"
    with pytest.raises(ContractError, match="RESOURCE_POLICY_INVALID"):
        f5.execute_final_refit_batch(destination, output, imputations=[1], workers=1)
    assert not output.exists() and calls["new_unfitted_objects"] == 0
    index = strict_json_bytes((destination / "dispatch-index.json").read_bytes())
    executed = [f5.execute_final_refit_batch(destination, output, imputations=row["imputations"],
                workers=1, resource_policy=policy, compiled_input_record=compiled) for row in index["host_shards"]]
    shap_order = [imp for row in index["host_shards"] for imp in row["imputations"]]
    assert shap_calls == shap_order
    assert sum(row["shap_component_count"] for row in executed) == 20
    assert sum(row["new_shap_component_count"] for row in executed) == 20
    assert sum(row["final_model_fit_count"] for row in executed) == 20
    assert sum(row["native_model_replay_count"] for row in executed) == 20
    assert sum(row["final_numerical_component_count"] for row in executed) == 20
    assert all(row["search_fit_count"] == row["stopping_fit_count"] == 0 for row in executed)
    assert calls == {"new_unfitted_objects": 20, "retained_reads": 20}
    final_predictions, final_receipts = [], []
    for record in request["component_records"]:
        task, recipe, entries = nested._read_component(destination / record["path"])
        assert task["registered_model_seed"] == 300000
        assert task["model_seed"] == (300000 if winner in {"RSF", "GBM_COX", "XGBOOST_COX", "COXTIME_SET_A"} else None)
        assert task["parameters"] == lock["parameters_by_imputation"][task["imputation"] - 1]
        assert "development_lock_sha256" not in task["nested_full_final_source"]
        if winner == "ELASTIC_NET_COX":
            parameters, columns = f4._nested_full_final_elastic_parameters(task["f4_nested_full_final_elastic_source"], task["f4_coordinates"])
            assert task["parameters"] == parameters and len(columns) == 50
        template = nested._read_component(destination / request["template_records"][task["imputation"] - 1]["path"])[2]
        with pytest.raises(ContractError, match="NESTED_FULL_FINAL_TASK_INVALID"):
            f4._f4_native_component_inputs(template)
        root = output / f"F5_FINAL_FULL_DATA_M{task['imputation']:02d}"
        predicted = strict_json_bytes((root / "prediction.json").read_bytes())
        replayed = f4._replay_f4_model_component({"entries": entries, "archive": root.with_suffix(".zip")})
        assert predicted == replayed and predicted["patient_ids"] == context["training_ids"]
        execution_receipt, observed, _ = nested._component_execution_receipt(
            component_path=destination / record["path"], output_root=root, record=record,
            context=context, development_lock_sha256=lock["identity_sha256"])
        assert observed == replayed
        final_predictions.append(replayed)
        final_receipts.append(nested._final_receipt(execution_receipt, lock=lock))
    assert calls == {"new_unfitted_objects": 20, "retained_reads": 40}
    apparent = nested._seal_full_final_apparent_prediction(
        context=context, lock=lock, predictions=final_predictions, component_receipts=final_receipts)
    assert apparent["survival"] == [[1.0] + [0.8] * 36 for _ in context["training_ids"]]
    assert apparent["interpretation"]["independent_external_validation"] is False
    checkpoint_root, replay_root = output / "shap-components", tmp_path / "UNFITTED-model-replay"
    def forbidden_native(*args, **kwargs):
        pytest.fail("The original collector must consume first-audit numbers without native replay")
    with monkeypatch.context() as numerical_reader:
        numerical_reader.setattr(f4, "_replay_f4_model_component", forbidden_native)
        numerical_reader.setattr(nested, "_component_execution_receipt", forbidden_native)
        numerical_reader.setattr(f5, "_validate_retained_model_objects", forbidden_native)
        collected = f5.collect_final_refit_results(output, request["family_decision"], request,
            input_root=destination, shap_checkpoint_root=checkpoint_root, replay_evidence=replay_root,
            workers=1, resource_policy=policy, compiled_input_record=compiled)
    assert collected["pooled_apparent_prediction"] == apparent
    assert all(row["retained_object_audit_sha256"] for row in collected["archives"])
    pooled = collected["pooled"]
    if winner == "COX_PH":
        from padml.f5_application import load_application_models
        before_application = dict(calls)
        with monkeypatch.context() as application_reader:
            application_reader.setattr(f4, "_replay_f4_model_component", forbidden_native)
            application_reader.setattr(f5, "_execute_final_refit_engine", forbidden_native)
            application_models = load_application_models(
                f5._read_final_lineage(destination / "lineage.json", selection_horizon_months=selection_horizon), destination, output,
                workers=1, resource_policy=policy, compiled_input_record=compiled)
        assert calls == before_application and len(application_models) == 20
        for imp, model in enumerate(application_models, 1):
            task, recipe, native_input = nested._read_component(destination / f"bound/M{imp:02d}.zip")
            _, expected_recipe, training, response, _, _ = f4._f4_native_component_inputs(native_input)
            assert model["task"] == task and model["recipe"] == expected_recipe
            assert model["covariates"] == training and model["response"] == response
            assert strict_json_bytes(model["objects"][0])["task"] == task
    assert f5._reuse_full_final_pool(pooled, collected["predictions"], collected["receipts"],
        request["family_decision"], request, pooled["pooled_apparent_prediction"]["centers"]) is pooled
    if winner == "COX_PH":
        for damage in ("centers", "receipt", "prediction", "plan"):
            changed_records, changed_receipts, changed_plan = [copy.deepcopy(value) for value in (
                collected["predictions"], collected["receipts"], request)]
            changed_centers = list(pooled["pooled_apparent_prediction"]["centers"])
            if damage == "centers":
                changed_centers.reverse()
            elif damage == "receipt":
                changed_receipts[0]["identity_sha256"] = "f" * 64
            elif damage == "prediction":
                changed_records[0]["survival"][winner][0][24] -= .01
            else:
                changed_plan["new_stop_fits"] = 1
            with pytest.raises(ContractError, match="F5_FULL_FINAL_POOLED_HANDOFF_DRIFT"):
                f5._reuse_full_final_pool(pooled, changed_records, changed_receipts,
                    request["family_decision"], changed_plan, changed_centers)
    assert all(len(list(output.glob(f".F5_FINAL_FULL_DATA_M{imp:02d}-audit-*/replay/object-audit.json"))) == 1
               for imp in range(1, 21))
    assert not list(replay_root.iterdir())
    assert len(collected["final_component_numbers"]) == 20
    assert all(row["fit_health"] and row["retained_audit"] for row in collected["final_component_numbers"])
    if winner == "COX_PH":
        # The original public collector must work with no final native
        # archives when SHAP is not requested. Original upstream compilation
        # used UNFITTED source leaves; it must not execute again here.
        only_numbers = tmp_path / "numerical-only-output"
        only_numbers.mkdir()
        for imp in range(1, 21):
            name = f"F5_FINAL_FULL_DATA_M{imp:02d}.numbers.json"
            (only_numbers / name).write_bytes((output / name).read_bytes())
        with monkeypatch.context() as numerical_reader:
            numerical_reader.setattr(f4, "_replay_f4_model_component", forbidden_native)
            numerical_reader.setattr(nested, "_component_execution_receipt", forbidden_native)
            numerical_reader.setattr(f5, "_validate_retained_model_objects", forbidden_native)
            numbers_collected = f5.collect_final_refit_results(only_numbers, request["family_decision"], request,
                input_root=destination, produce_shap=False, workers=1, resource_policy=policy, compiled_input_record=compiled)
            assert numbers_collected["pooled"] == collected["pooled"]
            assert numbers_collected["final_component_numbers"] == collected["final_component_numbers"]
            import shutil
            shutil.copytree(checkpoint_root, only_numbers / "shap-components")
            numerical_reader.setattr(f5, "_produce_final_shap_component", forbidden_native)
            shap_collected = f5.collect_final_refit_results(only_numbers, request["family_decision"], request,
                input_root=destination, workers=1, resource_policy=policy, compiled_input_record=compiled)
            assert shap_collected["pooled"] == collected["pooled"]
            assert shap_collected["shap_components"] == collected["shap_components"]
            assert shap_collected["shap_component_archives"] == collected["shap_component_archives"]
            assert not list(only_numbers.glob("*.zip"))
            missing = only_numbers / "F5_FINAL_FULL_DATA_M01.numbers.json"
            missing.rename(only_numbers / "retained-original-numbers.json")
            with pytest.raises(ContractError, match="F5_FINAL_REFIT_RESULT_MISSING"):
                f5.collect_final_refit_results(only_numbers, request["family_decision"], request,
                    input_root=destination, produce_shap=False, workers=1, resource_policy=policy, compiled_input_record=compiled)
        # These values pass the real Cox numerical validators. Each altered
        # object is self-rehashed so digest-only rejection cannot pass this
        # denominator/health/patient/design test accidentally.
        for damage in ("receipt", "patient", "probability", "health", "coefficient", "events", "archive", "design", "se"):
            changed = copy.deepcopy(collected["final_component_numbers"][0])
            if damage == "receipt":
                changed["receipt"]["task_sha256"] = "f" * 64
            elif damage == "patient":
                changed["prediction"]["patient_ids"].reverse()
            elif damage == "probability":
                changed["prediction"]["survival"][winner][0][1] = 1.1
            elif damage == "health":
                changed["fit_health"]["converged"] = False
            elif damage == "coefficient":
                changed["retained_audit"]["coefficient_estimates"][0] = "not a coefficient"
            elif damage == "events":
                changed["retained_audit"]["training_event_count"] -= 1
                changed["retained_audit"]["complete_data_degrees_of_freedom"] -= 1
            elif damage == "archive":
                changed["archive"]["archive_size_bytes"] = 0
            elif damage == "se":
                changed["retained_audit"]["within_standard_errors"][0] *= 2
            else:
                changed["retained_audit"]["design_columns"].reverse()
            changed["receipt"]["prediction_sha256"] = nested._sha(changed["prediction"])
            changed["receipt"]["fit_health_sha256"] = nested._sha(changed["fit_health"])
            changed["receipt"] = nested._sealed({key: value for key, value in changed["receipt"].items()
                                                 if key != "identity_sha256"})
            changed["archive"]["fit_health_sha256"] = changed["receipt"]["fit_health_sha256"]
            changed["archive"]["retained_object_audit_sha256"] = nested._sha(changed["retained_audit"])
            with pytest.raises(ContractError):
                f5._full_final_component_numbers(changed, input_bundle=destination / "bound/M01.zip",
                    task=nested._read_component(destination / "bound/M01.zip")[0], plan=request)
        failed_audit_output = tmp_path / "unfitted-first-audit-failure"
        failed_audit_output.mkdir()
        preserved = failed_audit_output / "F5_FINAL_FULL_DATA_M01.zip"
        original_native = (output / preserved.name).read_bytes()
        preserved.write_bytes(original_native)
        def failed_first_audit(*args, **kwargs):
            raise ContractError("UNFITTED_FIRST_AUDIT_FAILURE")
        with monkeypatch.context() as failed_audit:
            failed_audit.setattr(f5, "_validate_retained_model_objects", failed_first_audit)
            with pytest.raises(ContractError, match="UNFITTED_FIRST_AUDIT_FAILURE") as failure:
                f5.execute_final_refit_batch(destination, failed_audit_output, imputations=[1],
                    workers=1, resource_policy=policy, compiled_input_record=compiled)
        assert preserved.read_bytes() == original_native
        assert len(list(failed_audit_output.glob(".F5_FINAL_FULL_DATA_M01-audit-*/replay"))) == 1
        assert not preserved.with_suffix(".numbers.json").exists()
        assert f"F5_FULL_FINAL_NATIVE_EVIDENCE_RETAINED:{preserved}" in failure.value.__notes__
        assert calls == {"new_unfitted_objects": 20, "retained_reads": 40}
    assert shap_calls == shap_order
    assert len(collected["shap_component_archives"]) == len(collected["shap_component_paths"]) == 20
    assert f5.aggregate_final_shap(collected["shap_components"], pooled)["label"] == "FINAL_FULL_DATA_APPARENT_SHAP"
    assert f5.aggregate_final_shap(collected["shap_components"], pooled)["primary_horizon_months"] == selection_horizon
    first_task = nested._read_component(destination / "bound/M01.zip")[0]
    shap_job = (output / "F5_FINAL_FULL_DATA_M01.zip", destination / "bound/M01.zip",
                collected["archives"][0]["archive_sha256"], first_task, checkpoint_root,
                pooled["per_imputation_predictions"][0])
    reused_shap = f5._collect_final_shap_component(shap_job)
    assert reused_shap["checkpoint_record"]["reuse_status"] == "REUSED_EXACT_COMPONENT"
    with monkeypatch.context() as checkpoint_first:
        original_zip_reader = f5.read_safe_zip
        def without_native(path, **kwargs):
            assert path != shap_job[0], "An existing SHAP checkpoint must precede full native ZIP loading"
            return original_zip_reader(path, **kwargs)
        checkpoint_first.setattr(f5, "read_safe_zip", without_native)
        assert f5._collect_final_shap_component(shap_job, native=True) == reused_shap
    assert shap_calls == shap_order
    drifted = copy.deepcopy(shap_job[-1])
    drifted["survival"][0][24] -= .01
    with pytest.raises(ContractError, match="F5_SHAP_CHECKPOINT_MISSING"):
        f5._collect_final_shap_component((*shap_job[:-1], drifted))
    assert shap_calls == shap_order
    # Exercise the actual original SHAP input adapter with a MOCK R leaf. No
    # kernelshap, native fitter or imputation engine is invoked by this check.
    native_entries = f5.read_safe_zip(shap_job[0])
    def mock_shap_r(command, **kwargs):
        assert Path(command[2]).name == "f5_shap.R"
        spec = strict_json_bytes(Path(command[-1]).read_bytes())
        assert spec["task"] == first_task and spec["recipe"] == nested._read_component(shap_job[1])[1]
        assert Path(spec["covariate_path"]).read_bytes() == native_entries["fit-covariates.csv"]
        assert Path(spec["response_path"]).read_bytes() == native_entries["fit-response.csv"]
        Path(spec["output_path"]).write_bytes(canonical_json_bytes(collected["shap_components"][0]))
        return f5.subprocess.CompletedProcess(command, 0, "MOCK_SHAP_ONLY", "")
    with monkeypatch.context() as shap_bridge:
        shap_bridge.setattr(f5.subprocess, "run", mock_shap_r)
        assert original_shap(shap_job[1], first_task, native_entries["model.bin"], native_entries["baseline.bin"],
                             shap_job[-1]) == collected["shap_components"][0]
    if winner == "COX_PH":
        def failed_shap_r(command, **kwargs):
            raise f5.subprocess.TimeoutExpired(command, 1, output=b"MOCK_PARTIAL_STDOUT", stderr=b"MOCK_PARTIAL_STDERR")
        with monkeypatch.context() as failed_bridge:
            failed_bridge.setattr(f5.subprocess, "run", failed_shap_r)
            with pytest.raises(f5.subprocess.TimeoutExpired) as failure:
                original_shap(shap_job[1], first_task, native_entries["model.bin"], native_entries["baseline.bin"], shap_job[-1])
        evidence, = [Path(note.split(":", 1)[1]) for note in failure.value.__notes__
                     if note.startswith("F5_SHAP_NATIVE_EVIDENCE_RETAINED:")]
        assert (evidence / "stdout.log").read_bytes() == b"MOCK_PARTIAL_STDOUT"
        assert (evidence / "stderr.log").read_bytes() == b"MOCK_PARTIAL_STDERR"
        assert (evidence / "response.csv").read_bytes() == native_entries["fit-response.csv"]
    if winner in {"COX_PH", "ELASTIC_NET_COX"}:
        diagnostic = f5.coefficient_mi_diagnostics(pooled, winner, collected["locked_coefficient_ids"],
                                                  collected["coefficient_evidence"])
        assert diagnostic["status"] == "COMPUTED"
        assert diagnostic["model_sha256_by_imputation"] == [row["model_sha256"] for row in final_receipts]
        if winner == "ELASTIC_NET_COX":
            assert diagnostic["inference"] == "NOT_APPLICABLE_ADAPTIVE_PENALIZED_ESTIMATOR"
            assert diagnostic["unpenalized_reference_fit_added"] is False
    else:
        assert collected["locked_coefficient_ids"] is collected["coefficient_evidence"] is None
    if winner == "FPM_TVC_SET_A":
        non_ph = f5.evaluate_non_ph(collected["non_ph_contrast_evidence"], pooled,
                                    scope_label="FINAL_FULL_DATA_APPARENT")
        assert non_ph["selection_effect"] == "NONE"
    else:
        assert collected["non_ph_contrast_evidence"] is None
    non_ph_action = f5._compile_non_ph_action(pooled, collected["non_ph_contrast_evidence"], request, collected["archives"])
    assert non_ph_action["development_lock_sha256"] == lock["identity_sha256"]
    assert non_ph_action["training_context_sha256"] == context["identity_sha256"]
    assert non_ph_action["interpretation"]["independent_external_validation"] is False
    assert pooled["mean_survival"] == pooled["odd_survival"] == pooled["even_survival"] == apparent["survival"]
    assert pooled["kind"] == "PADML_F5_FULL0_APPARENT_M20_SUMMARY"
    assert pooled["interpretation"]["independent_external_validation"] is False
    assert pooled["patient_spread"][0]["horizons"]["24"]["imputation_sd"] == pytest.approx((0.8 / 19) ** 0.5)
    assert pooled["patient_spread"][0]["horizons"]["24"]["imputation_mcse"] == pytest.approx((0.04 / 19) ** 0.5)
    with pytest.raises(ContractError, match="F5_FINAL_REFIT_CENTER_BINDING_INVALID"):
        f5.pool_predictions(final_predictions, final_receipts, request["family_decision"], request,
                            list(reversed(apparent["centers"])))
    wrong_receipts = copy.deepcopy(final_receipts)
    wrong_receipts[0]["task_sha256"] = "f" * 64
    wrong_receipts[0] = nested._sealed({key: value for key, value in wrong_receipts[0].items() if key != "identity_sha256"})
    with pytest.raises(ContractError, match="F5_FINAL_REFIT_TASK_BINDING_INVALID"):
        f5.pool_predictions(final_predictions, wrong_receipts, request["family_decision"], request, apparent["centers"])
    alias_plan, alias_receipts = copy.deepcopy(request), copy.deepcopy(final_receipts)
    alias_plan["component_records"][1]["task_sha256"] = alias_plan["component_records"][0]["task_sha256"]
    alias_plan = nested._sealed({key: value for key, value in alias_plan.items() if key != "identity_sha256"})
    alias_receipts[1]["task_sha256"] = alias_receipts[0]["task_sha256"]
    alias_receipts[1] = nested._sealed({key: value for key, value in alias_receipts[1].items() if key != "identity_sha256"})
    with pytest.raises(ContractError, match="F5_FINAL_REFIT_PRODUCER_ALIAS_FORBIDDEN"):
        f5.pool_predictions(final_predictions, alias_receipts, alias_plan["family_decision"], alias_plan, apparent["centers"])
    assert calls == {"new_unfitted_objects": 20, "retained_reads": 40}
    replayed = f5.execute_final_refit_batch(destination, output, imputations=[1], workers=1, resource_policy=policy, compiled_input_record=compiled)
    assert replayed["final_model_fit_count"] == replayed["native_model_replay_count"] == 0
    assert replayed["final_numerical_component_count"] == 1
    assert replayed["new_shap_component_count"] == 0 and shap_calls == shap_order
    assert calls == {"new_unfitted_objects": 20, "retained_reads": 40}
    failed_output = tmp_path / "unfitted-interrupted"
    failed_native = failed_output / "F5_FINAL_FULL_DATA_M01"
    failed_native.mkdir(parents=True)
    (failed_native / "native-failure.json").write_bytes(b"UNFITTED_PRESERVE_FAILURE_EVIDENCE")
    with pytest.raises(ContractError, match="F4_NATIVE_MODEL_INCOMPLETE_ARCHIVE_REQUIRES_NEW_FIT_AUTHORITY"):
        f5.execute_final_refit_batch(destination, failed_output, imputations=[1], workers=1, resource_policy=policy, compiled_input_record=compiled)
    assert calls == {"new_unfitted_objects": 20, "retained_reads": 40}
    assert (failed_native / "native-failure.json").read_bytes() == b"UNFITTED_PRESERVE_FAILURE_EVIDENCE"
    # The existing batch consumer must reject a self-resealed wrong local lock.
    dispatch_path = destination / "dispatch-index.json"
    dispatch_bytes = dispatch_path.read_bytes()
    damaged_dispatch = strict_json_bytes(dispatch_bytes)
    damaged_dispatch["development_lock_sha256"] = "f" * 64
    damaged_dispatch = nested._sealed({key: value for key, value in damaged_dispatch.items() if key != "identity_sha256"})
    dispatch_path.write_bytes(canonical_json_bytes(damaged_dispatch))
    with pytest.raises(ContractError, match="F5_FULL_FINAL_COMPILED_INPUT_RECORD_INVALID"):
        f5.execute_final_refit_batch(destination, output, imputations=[1], workers=1, resource_policy=policy, compiled_input_record=compiled)
    dispatch_path.write_bytes(dispatch_bytes)
    assert calls == {"new_unfitted_objects": 20, "retained_reads": 40}
    if winner == "COX_PH":
        # A corrupt retained M7 must fail before an unstarted M1 can fit. This
        # counterexample exercises the existing batch recovery consumer.
        mixed_output = tmp_path / "unfitted-mixed-recovery"
        mixed_output.mkdir()
        (mixed_output / "F5_FINAL_FULL_DATA_M07.zip").write_bytes(b"UNFITTED_INVALID_ARCHIVE")
        with pytest.raises(ContractError):
            f5.execute_final_refit_batch(destination, mixed_output, imputations=[1, 7],
                                        workers=1, resource_policy=policy, compiled_input_record=compiled)
        assert calls == {"new_unfitted_objects": 20, "retained_reads": 40}
        assert not (mixed_output / "F5_FINAL_FULL_DATA_M01").exists()
        valid_mixed_output = tmp_path / "unfitted-valid-mixed-recovery"
        valid_mixed_output.mkdir()
        (valid_mixed_output / "F5_FINAL_FULL_DATA_M07.zip").write_bytes(
            (output / "F5_FINAL_FULL_DATA_M07.zip").read_bytes())
        interrupted_audit = valid_mixed_output / "F5_FINAL_FULL_DATA_M07.audit"
        interrupted_audit.mkdir()
        (interrupted_audit / "partial.log").write_bytes(b"UNFITTED interrupted first audit; preserve")
        phases, inherited = [], {}
        shap_before = list(shap_calls)
        def ordered_pool(worker, jobs, **kwargs):
            from time import monotonic
            include_shap = getattr(worker, "keywords", {}).get("include_shap", True)
            order = kwargs.get("schedule_order", range(len(jobs)))
            phases.append((include_shap, [jobs[i][3]["imputation"] for i in order]))
            deadlines = kwargs["task_deadlines"]
            values = [None] * len(jobs)
            for i in order:
                imp = jobs[i][3]["imputation"]
                if imp in inherited:
                    assert deadlines[i] == inherited[imp], "The retained MI cannot receive a fresh 12 h"
                if deadlines[i] is None:
                    deadlines[i] = monotonic() + runtime._TASK_DEADLINE_SECONDS
                if include_shap:
                    assert (valid_mixed_output / "F5_FINAL_FULL_DATA_M07.numbers.json").is_file()
                values[i] = worker(jobs[i])
                if not include_shap:
                    assert values[i]["status"] == "NUMERICAL_READY"
                    assert values[i]["final_model_fit_count"] == 0 and shap_calls == shap_before
                    inherited[imp] = deadlines[i]
            return values
        with monkeypatch.context() as mixed:
            mixed.setattr(f5, "_bounded_ordered_spawn", ordered_pool)
            resumed = f5.execute_final_refit_batch(destination, valid_mixed_output, imputations=[7, 1],
                                                  workers=1, resource_policy=policy, compiled_input_record=compiled)
        assert phases == [(False, [7]), (True, [1, 7])]
        assert shap_calls == [*shap_before, 1, 7]
        assert resumed["final_model_fit_count"] == 1 and resumed["native_model_replay_count"] == 2
        assert resumed["final_numerical_component_count"] == resumed["shap_component_count"] == 2
        assert resumed["active_worker_limit"] == 1
        assert [row["imputation"] for row in resumed["results"]] == [1, 7]
        assert calls == {"new_unfitted_objects": 21, "retained_reads": 42}
        assert (interrupted_audit / "partial.log").read_bytes() == b"UNFITTED interrupted first audit; preserve"
    with pytest.raises(ContractError, match="NESTED_SELECTED_PREDICTION_INVALID"):
        nested.validate_selected_prediction(apparent)
    with pytest.raises(ContractError, match="NESTED_SELECTED_PREDICTION_REQUIRES_OUTER_LOCK"):
        nested.seal_selected_prediction(lock=lock, patient_ids=context["training_ids"], centers=apparent["centers"],
            survival=apparent["survival"], component_receipts=final_receipts)
    assert len({nested._read_component(destination / row["path"])[0]["family"] for row in request["component_records"]}) == 1
    task, recipe, entries = nested._read_component(destination / request["component_records"][0]["path"])
    _, _, training, response, _, _ = f4._f4_native_component_inputs(entries)
    for field in ("family_design_column_count", "row_count"):
        with pytest.raises(ContractError, match="NESTED_FULL_FINAL_RECIPE_OR_APPLICATION_INVALID"):
            original_engine(winner, {**task, field: 999}, training, response, recipe)
    if winner == "ELASTIC_NET_COX":
        damaged = copy.deepcopy(task)
        transform = damaged["f4_nested_full_final_elastic_source"]["full_transform_recipe"]
        spline = next(row for row in transform["representations"] if row["representation"] == "NATURAL_SPLINE_K3")
        spline["parameters"]["interior_knots"][0] += 1
        transform["recipe_sha256"] = nested._sha({key: value for key, value in transform.items() if key != "recipe_sha256"})
        # Both recipes remain valid and use the same full50 column domain;
        # final-M20 nonetheless requires the *same* full recipe at both uses.
        f5._validate_nested_full_final_task(damaged)
        with pytest.raises(ContractError, match="NESTED_FULL_FINAL_ELASTIC_RECIPE_DRIFT"):
            original_engine(winner, damaged, training, response, recipe)
    for field, value in (("seed", 300001), ("application_ids_sha256", nested._sha([])),
                         ("parameter_sha256", "f" * 64), ("development_lock_sha256", "f" * 64)):
        damaged = nested._sealed({key: item for key, item in {**final_receipts[0], field: value}.items()
                                  if key != "identity_sha256"})
        with pytest.raises(ContractError, match="NESTED_COMPONENT_RECEIPT_INVALID"):
            nested.validate_component_receipt(damaged, lock)
    with pytest.raises(ContractError, match="NESTED_FULL_FINAL_PREDICTION_COMPONENT_DRIFT"):
        nested._seal_full_final_apparent_prediction(context=context, lock=lock,
            predictions=list(reversed(final_predictions)), component_receipts=final_receipts)
    for field in ("a12_coordinates", "a19_coordinates", "c10_coordinates", "a04_coordinates", "stop_parameters",
                  "registered_stop_seed", "f4_locked_family_handoff_sha256", "final_seta_lock_sha256",
                  "final_parameter_lock_sha256", "f4_outer_elastic_source", "f4_full_elastic_source",
                  "nested_full_score_source", "f4_nested_full_elastic_source"):
        with pytest.raises(ContractError):
            f5._validate_nested_full_final_task({**task, field: "FORBIDDEN"})
    for member in ("fit-covariates.csv", "fit-response.csv", "recipe.json", "prediction-covariates.csv"):
        damaged = {**entries, member: entries[member] + b"\n"}
        with pytest.raises(ContractError):
            f4._f4_native_component_inputs(damaged)
    for changed in ({**task, "model_seed": 300001}, {**task, "registered_model_seed": 300001},
                    {**task, "f4_coordinates": {**task["f4_coordinates"], "purpose": "NESTED_FULL_SCORE", "repeat": 1, "inner_fold": 1}}):
        with pytest.raises(ContractError):
            f5._validate_nested_full_final_task(changed)
    # Replay must fail on an incomplete/extra-member input, before reopening
    # the costly score proof, and cannot repair an absent bound component.
    bound = destination / request["component_records"][0]["path"]
    saved = bound.read_bytes()
    bound.unlink()
    replay_count = len(replay_calls)
    with pytest.raises(ContractError, match="NESTED_FULL_FINAL_REQUEST_MEMBER_SET_INVALID"):
        f5._compile_full_final_inputs(*arguments, **budgets, replay=True)
    assert not bound.exists() and len(replay_calls) == replay_count
    bound.write_bytes(saved)
    extra = destination / "UNRECOGNIZED.json"
    extra.write_bytes(b"UNFITTED")
    with pytest.raises(ContractError, match="NESTED_FULL_FINAL_REQUEST_MEMBER_SET_INVALID"):
        f5._compile_full_final_inputs(*arguments, **budgets, replay=True)
    assert len(replay_calls) == replay_count
    extra.unlink()
    if winner in {"COX_PH", "FPM_TVC_SET_A"}:
        before = dict(calls)
        before_shap = list(shap_calls)
        action_path = tmp_path / "UNFITTED-non-ph.zip"
        original_pool, pool_calls = f5.pool_predictions, []
        def count_pool(*args, **kwargs):
            pool_calls.append(1)
            return original_pool(*args, **kwargs)
        with monkeypatch.context() as pooled_once:
            pooled_once.setattr(f5, "pool_predictions", count_pool)
            report = f5.execute_non_ph_action(destination / "lineage.json", Path(inputs[2]["fit_response"]["path"]),
                output, action_path, input_root=destination, workers=1, resource_policy=policy, compiled_input_record=compiled)
        assert pool_calls == [1]
        assert report["stage_acceptance"] is False
        assert calls == before
        assert f5._load_non_ph_action(action_path, pooled, collected["non_ph_contrast_evidence"], request,
                                      collected["archives"]) == non_ph_action
        assert shap_calls == before_shap

    action_path = tmp_path / "UNFITTED-non-ph.zip"
    if not action_path.exists():
        f5.write_deterministic_zip(action_path, {"non-ph.json": canonical_json_bytes(non_ph_action)})
    native_metric_calls = []
    def mock_native_metrics(jobs, **kwargs):
        import tempfile
        assert tempfile.gettempdir() == str(output.parent)
        assert [job["label"] for job in jobs] == ["MI_ODD", "MI_EVEN"]
        native_metric_calls.append(jobs)
        values = [{"label": job["label"], "UNFITTED_NATIVE_METRICS_MOCK": True,
            "horizons": {str(h): {"status": "COMPUTED", "reasons": [], "slope": 1., "citl": 0.,
                "oe": 1., "ici": .1, "e50": .1, "e90": .1} for h in f5.REPORT_HORIZONS},
            "discrimination": {"uno_c_24": {"value": .5},
                "auc": {str(h): {"value": .5} for h in f5.REPORT_HORIZONS}}} for job in jobs]
        if kwargs.get("retained_archive") is not None:
            f5.write_deterministic_zip(kwargs["retained_archive"], {
                "input.json": canonical_json_bytes({"jobs": jobs}), "stdout.txt": canonical_json_bytes({"results": values}),
                "stderr.txt": b"UNFITTED_METRICS_MOCK_ONLY", "f4_metrics.R": Path(f4.__file__).with_name("kernels") / "f4_metrics.R",
                "execution.json": canonical_json_bytes({"exit_code": 0, "rscript": "MOCK",
                    "engine_threads": f4.THREAD_ENV,
                    "kernel_sha256": f5.sha256_file(Path(f4.__file__).with_name("kernels") / "f4_metrics.R")})})
        return values
    monkeypatch.setattr(f5, "native_metrics", mock_native_metrics)
    for name in ("_validate_final_aggregate_lineage", "_validate_final_mice_archive", "_load_final_sensitivity_actions"):
        monkeypatch.setattr(f5, name, lambda *args, **kwargs: pytest.fail("OLD_GLOBAL_FINAL_AGGREGATE_SOURCE_FORBIDDEN"))
    aggregate_path = tmp_path / "UNFITTED-final-aggregate.zip"
    before = dict(calls)
    score_replay_count, materialization_count = len(replay_calls), len(materializations)
    aggregate_response = Path(inputs[2]["fit_response"]["path"])
    if winner == "COX_PH":
        wrong_plan, wrong_mice = tmp_path / "wrong-plan.json", tmp_path / "wrong-mice.zip"
        wrong_plan.write_bytes(canonical_json_bytes({"UNFITTED_OTHER_PLAN": True}))
        wrong_mice.write_bytes(b"UNFITTED_OTHER_MICE_NOT_CONSUMED")
        negative_options = [
            ({"resource_policy": None}, "RESOURCE_POLICY_INVALID"),
            ({"workers": 2}, "NESTED_CONFIGURED_CEILING_MUST_BE_EXECUTION_HOST_C_MINUS_8"),
            ({"sensitivity_results": {"A12": action_path}}, "F5_FULL_FINAL_LEGACY_ACTION_AUTHORITY_FORBIDDEN"),
            ({"f2_run_root": tmp_path}, "F5_FULL_FINAL_LEGACY_ACTION_AUTHORITY_FORBIDDEN"),
            ({"mice_plan_path": wrong_plan}, "F5_FINAL_MICE_PLAN_REPLAY_MISMATCH"),
            ({"final_mice_path": wrong_mice}, "F5_FINAL_MICE_ARCHIVE_BINDING_INVALID"),
            ({"parameter_source_path": pending_path}, "NESTED_SCIENCE_DECISION_INCOMPLETE"),
        ]
        for number, (kwargs, error) in enumerate(negative_options):
            target = tmp_path / f"UNFITTED-negative-aggregate-{number}.zip"
            with pytest.raises(ContractError, match=error):
                f5.execute_final_aggregate(destination / "lineage.json", aggregate_response, output, action_path,
                    target, **{"input_root": destination, "resource_policy": policy, "workers": 1, "compiled_input_record": compiled, **kwargs})
            assert not target.exists() and not target.with_name(target.name + ".native-replay").exists()
        bad_response = tmp_path / "changed-response.csv"
        response_fields, response_rows = f5._response_rows(aggregate_response.read_bytes())
        response_rows[context["training_ids"][0]]["Death_Followup_months"] = "999"
        bad_response.write_bytes(f5._write_response_subset(response_fields, response_rows, context["training_ids"], None)["private_bytes"])
        with pytest.raises(ContractError, match="NESTED_TRAINING_RESPONSE"):
            f5.execute_final_aggregate(destination / "lineage.json", bad_response, output, action_path,
                tmp_path / "UNFITTED-changed-response.zip", input_root=destination, resource_policy=policy, workers=1,
                compiled_input_record=compiled)
        assert calls == before and len(replay_calls) == score_replay_count and not native_metric_calls
        failed_target = tmp_path / "UNFITTED-compile-record-rejected.zip"
        with pytest.raises(ContractError, match="F5_FULL_FINAL_COMPILED_INPUT_RECORD_INVALID"):
            f5.execute_final_aggregate(destination / "lineage.json", aggregate_response, output, action_path,
                failed_target, input_root=destination, resource_policy=policy, workers=1,
                compiled_input_record={**compiled, "lineage_sha256": "f" * 64})
        assert calls == before and not native_metric_calls and not failed_target.exists()
        assert not failed_target.with_name(failed_target.name + ".native-replay").exists()
        lines = aggregate_response.read_bytes().splitlines()
        aggregate_response = tmp_path / "reordered-response.csv"
        aggregate_response.write_bytes(b"\n".join([lines[0], *reversed(lines[1:])]) + b"\n")
    for name in ("_compile_full_final_inputs", "_full_data_locked_score_program",
                 "_materialize_final_search_inputs", "materialize_final_full_data_mice"):
        monkeypatch.setattr(f5, name, forbidden_native)
    # A relocated numerical consumer has no original full MICE archive.
    (tmp_path / "UNFITTED-final-MICE.zip").rename(tmp_path / "retained-original-MICE.zip")
    original_pool, pool_calls = f5.pool_predictions, []
    def count_pool(*args, **kwargs):
        pool_calls.append(1)
        return original_pool(*args, **kwargs)
    with monkeypatch.context() as pooled_once:
        pooled_once.setattr(f5, "pool_predictions", count_pool)
        report = f5.execute_final_aggregate(destination / "lineage.json", aggregate_response,
            output, action_path, aggregate_path, input_root=destination, resource_policy=policy, workers=1,
            compiled_input_record=compiled)
    assert pool_calls == [1]
    assert report["stage_acceptance"] is False
    operational = strict_json_bytes(aggregate_path.with_name(aggregate_path.name + ".native-replay").joinpath("collection-execution.json").read_bytes())
    assert operational == {key: report[key] for key in
        ("configured_worker_ceiling", "admitted_worker_ceiling", "pool_execution_reports")}
    assert len(operational["pool_execution_reports"]) == 2
    assert calls == before
    assert len(replay_calls) == score_replay_count and len(materializations) == materialization_count
    assert len(native_metric_calls) == 1
    entries = f5.read_safe_zip(aggregate_path)
    result = strict_json_bytes(entries["final-aggregate.json"])
    assert result["kind"] == "PADML_F5_FINAL_AGGREGATE_V1" and result["scope"] == "FULL_DATA_APPARENT_ONLY"
    assert result["stage_acceptance"] is result["review_ready"] is result["full_pipeline_bootstrap"] is False
    assert result["interpretation"] == nested.full_data_interpretation()
    assert result["pooled"] == pooled and result["non_ph_action"] == non_ph_action
    assert result["final_component_numbers"] == collected["final_component_numbers"]
    assert result["action_ledger"]["action_order"] == ["FINAL_SEARCH", "FINAL_PARAMETER_LOCK", "FINAL_REFIT", "NON_PH", "FINAL_AGGREGATE"]
    assert result["action_ledger"]["scope"] == "FULL_DATA_APPARENT_ONLY"
    assert result["action_ledger"]["deployment_eligibility"] == "NOT_ASSESSED_FULL_DATA_ONLY"
    assert result["action_ledger"]["review_ready"] is False
    assert entries["mice-plan.json"] == canonical_json_bytes(inputs[0])
    assert "final-mice.zip" not in entries
    assert result["final_mice_artifacts"] == compiled["final_mice_artifacts"]
    assert result["compiled_input_record"] == compiled
    assert entries["development-sources.json"] == source_description.read_bytes()
    assert "final-search.zip" not in entries
    assert entries["mi-native-metrics.zip"] == aggregate_path.with_name(aggregate_path.name + ".native-replay").joinpath("mi-native-metrics.zip").read_bytes()
    assert result["parameter_source_artifact"]["identity_sha256"] == request["identity_sha256"]
    assert result["final_lineage_sha256"] == f5.sha256_file(destination / "lineage.json")
    assert len(result["shap_component_archives"]) == 20
    assert result["diagnostic"]["additional_mice_started"] is False
    # Re-enter the original aggregate consumer: no diagnostic native execution,
    # refit, selector, MICE or SHAP production may follow a completed artifact.
    original_aggregate = aggregate_path.read_bytes()
    evidence_root = aggregate_path.with_name(aggregate_path.name + ".native-replay")
    retained_evidence = {path: path.read_bytes() for path in evidence_root.rglob("*") if path.is_file()}
    moved_evidence = evidence_root.with_name(evidence_root.name + ".retained-elsewhere")
    evidence_root.rename(moved_evidence)
    with monkeypatch.context() as readback:
        readback.setattr(f5, "native_metrics", forbidden_native)
        repeated = f5.execute_final_aggregate(destination / "lineage.json", aggregate_response,
            output, action_path, aggregate_path, input_root=destination, resource_policy=policy, workers=1,
            compiled_input_record=compiled, replay=True)
        assert repeated["sha256"] == report["sha256"] and repeated["size_bytes"] == report["size_bytes"]
        assert repeated["stage_acceptance"] is False and aggregate_path.read_bytes() == original_aggregate
        assert not evidence_root.exists()
        assert all((moved_evidence / path.relative_to(evidence_root)).read_bytes() == raw
                   for path, raw in retained_evidence.items())
        assert calls == before and len(native_metric_calls) == 1
        damaged = dict(entries)
        damaged["final-aggregate.json"] = canonical_json_bytes({**result, "selection_effect": "CHANGED"})
        changed = tmp_path / "UNFITTED-changed-aggregate.zip"
        f5.write_deterministic_zip(changed, damaged)
        changed.replace(aggregate_path)
        with pytest.raises(ContractError, match="F5_FULL_FINAL_AGGREGATE_REPLAY_DRIFT"):
            f5.execute_final_aggregate(destination / "lineage.json", aggregate_response,
                output, action_path, aggregate_path, input_root=destination, resource_policy=policy, workers=1,
                compiled_input_record=compiled, replay=True)
        aggregate_path.write_bytes(original_aggregate)
    incomplete = f5._compile_final_action_ledger(strict_json_bytes(entries["final-lineage.json"]),
        {**result["diagnostic"], "status": "INCOMPLETE"}, non_ph_action, {}, result["action_result_archives"],
        collected["archives"], result["parameter_source_artifact"])
    assert incomplete["evidence_completeness"] == "INCOMPLETE" and incomplete["blocking_actions"] == ["FINAL_AGGREGATE"]
    assert incomplete["review_ready"] is incomplete["stage_acceptance"] is False
    if winner == "COX_PH":
        # Reuse this test's real compiler return and completed M20 artifacts.
        # The original native MICE archive has already been relocated above;
        # no upstream recreation or producer fallback may be attempted.
        execution_context = {"q": {name: {} for name in roots},
            "final_input_root": destination, "final_result_root": output,
            "non_ph_result": action_path, "aggregate_target": aggregate_path,
            "compiled_input_record": compiled}
        before_owner = {path: path.read_bytes() for path in output.rglob("*") if path.is_file()}
        with monkeypatch.context() as complete_owner:
            for name in ("native_metrics", "compile_final_refit_bundles", "execute_final_complex_search",
                         "execute_non_ph_action", "_nested_full_selector_program",
                         "_materialized_full_data_development_sources"):
                complete_owner.setattr(f5, name, forbidden_native)
            with monkeypatch.context() as wrong_record:
                wrong_record.setattr(f5, "execute_final_refit_batch", forbidden_native)
                with pytest.raises(ContractError, match="F5_FULL_FINAL_COMPILED_INPUT_RECORD_INVALID"):
                    f5.execute_full_data_locked_scores(source_description,
                        selection_horizon_months=selection_horizon,
                        full0_execution_context={**execution_context,
                            "compiled_input_record": {**compiled, "model_fit_count": 1}})
            owned = f5.execute_full_data_locked_scores(source_description,
                selection_horizon_months=selection_horizon, full0_execution_context=execution_context)
        assert owned["compiled_input_record"] is compiled and owned["stage_acceptance"] is False
        assert owned["aggregate"]["sha256"] == report["sha256"]
        assert owned["q_execution"] == {} and owned["scores"] is None
        assert len(owned["final_refit"]) == 6
        assert sorted(imp for row in owned["final_refit"] for imp in row["imputations"]) == list(range(1, 21))
        assert all(row["final_model_fit_count"] == row["native_model_replay_count"] == 0
                   for row in owned["final_refit"])
        assert all(path.read_bytes() == raw for path, raw in before_owner.items())
        assert aggregate_path.read_bytes() == original_aggregate and len(native_metric_calls) == 1


def test_full0_aggregate_readback_cleanup_error_is_operational_only(tmp_path, monkeypatch):
    root = tmp_path / "owned-readback"
    root.mkdir()
    blocked, other = root / "mice-plan.json", root / "development-sources.json"
    blocked.write_bytes(b"UNFITTED_SOURCE")
    other.write_bytes(b"UNFITTED_SOURCE")
    original_unlink = Path.unlink
    def unlink(path, *args, **kwargs):
        if path == blocked:
            raise PermissionError("UNFITTED_CLEANUP_FAILURE")
        return original_unlink(path, *args, **kwargs)
    monkeypatch.setattr(Path, "unlink", unlink)
    errors = f5._release_full0_aggregate_readback_sources(root)
    assert blocked.read_bytes() == b"UNFITTED_SOURCE" and not other.exists()
    assert len(errors) == 2 and all(set(row) == {"operation", "error"} for row in errors)
    assert errors[0] == {"operation": "INPUT_DELETE:" + str(blocked),
                         "error": "PermissionError:UNFITTED_CLEANUP_FAILURE"}
    assert errors[1]["operation"] == "INPUT_DELETE:" + str(root)


def test_full0_shap_reader_uses_exact_values_without_native_fallback(tmp_path, monkeypatch):
    """Reopen the original worker's checkpoint, without another fit, audit or SHAP call."""
    import os
    fixture = os.environ.get("PADML_FULL0_COMPILED_INPUT_FIXTURE")
    if fixture is None:
        pytest.skip("Requires the retained H9 original full0 fixture; no additional fits")
    fixture = Path(fixture)
    source = fixture / "final-input/bound/M01.zip"
    plan = strict_json_bytes((fixture / "final-input/full-final-input.json").read_bytes())
    task = f5._nested_science._read_component(source)[0]
    numbers = f5._full_final_component_numbers(strict_json_bytes(
        (fixture / "unfitted-output/F5_FINAL_FULL_DATA_M01.numbers.json").read_bytes()),
        input_bundle=source, task=task, plan=plan)
    prediction = f5._full_final_prediction_record(numbers["prediction"], numbers["receipt"], task["family"])
    originals = list((fixture / "unfitted-output/shap-components").glob("F5_FINAL_AGGREGATE_SHAP_M01_*.zip"))
    assert len(originals) == 1
    checkpoint_root = tmp_path / "shap-components"
    checkpoint_root.mkdir()
    checkpoint = checkpoint_root / originals[0].name
    original_bytes = originals[0].read_bytes()
    checkpoint.write_bytes(original_bytes)
    absent_native = tmp_path / "F5_FINAL_FULL_DATA_M01.zip"
    job = (absent_native, source, numbers["archive"]["archive_sha256"], task, checkpoint_root, prediction)
    def forbidden(*args, **kwargs):
        pytest.fail("Normal SHAP consumption cannot open native objects or execute")
    original_zip_reader = f5.read_safe_zip
    def only_checkpoint(path, *args, **kwargs):
        assert path == checkpoint
        return original_zip_reader(path, *args, **kwargs)
    monkeypatch.setattr(f5, "read_safe_zip", only_checkpoint)
    monkeypatch.setattr(f5, "_produce_final_shap_component", forbidden)
    monkeypatch.setattr(f5, "_validate_retained_model_objects", forbidden)
    monkeypatch.setattr(f4, "_replay_f4_model_component", forbidden)
    observed = f5._collect_final_shap_component(job)
    assert observed["checkpoint_record"]["reuse_status"] == "REUSED_EXACT_COMPONENT"
    assert not absent_native.exists()
    entries = original_zip_reader(checkpoint)
    component = strict_json_bytes(entries["component.json"])
    assert observed["component"] == component
    saved = tmp_path / "retained-original-checkpoint.zip"
    checkpoint.rename(saved)
    with pytest.raises(ContractError, match="F5_SHAP_CHECKPOINT_MISSING"):
        f5._collect_final_shap_component(job)
    assert list(checkpoint_root.iterdir()) == []
    saved.rename(checkpoint)
    for field, changed in (("model_sha256", "f" * 64), ("baseline_sha256", "f" * 64),
                           ("final_refit_receipt_sha256", "f" * 64), ("imputation", 2)):
        altered = {**prediction, field: changed}
        with pytest.raises(ContractError):
            f5._collect_final_shap_component((*job[:-1], altered))
    for damage in ("binding", "imputation", "patient", "seed", "local", "global", "missing"):
        altered = copy.deepcopy(component)
        binding = strict_json_bytes(entries["binding.json"])
        if damage == "binding":
            binding["source_member_sha256"]["padml/f5.py"] = "f" * 64
        elif damage == "imputation":
            altered["imputation"] = 2
        elif damage == "patient":
            altered["patient_ids"].reverse()
        elif damage == "seed":
            altered["engine"]["seed"] += 1
        elif damage == "local":
            altered["risk_contributions"][0][0][0] += .01
        elif damage == "global":
            altered["within_imputation_global_mean_absolute_contribution"][0][0] += .01
        else:
            del altered["risk_contributions"]
        changed_zip = tmp_path / (damage + ".zip")
        f5.write_deterministic_zip(changed_zip, {"binding.json": canonical_json_bytes(binding),
                                               "component.json": canonical_json_bytes(altered)})
        checkpoint.write_bytes(changed_zip.read_bytes())
        with pytest.raises(ContractError):
            f5._collect_final_shap_component(job)
        checkpoint.write_bytes(original_bytes)
    assert checkpoint.read_bytes() == original_bytes
    assert not list(checkpoint_root.glob("*/"))


def test_full0_shap_cancel_retains_numbers_and_native_logs_without_automatic_restart(tmp_path, monkeypatch):
    """Use one already audited UNFITTED model; the original R adapter is cancelled, never fitted."""
    import os
    fixture = os.environ.get("PADML_FULL0_COMPILED_INPUT_FIXTURE")
    if fixture is None:
        pytest.skip("Requires the retained H9 original full0 fixture; no additional fits")
    fixture = Path(fixture)
    source = fixture / "final-input/bound/M01.zip"
    lineage = strict_json_bytes((fixture / "final-input/lineage.json").read_bytes())
    task = f5._nested_science._read_component(source)[0]
    output = tmp_path / "original-worker"
    output.mkdir()
    target = output / "F5_FINAL_FULL_DATA_M01.zip"
    number_path = target.with_suffix(".numbers.json")
    original_model = (fixture / "unfitted-output" / target.name).read_bytes()
    original_numbers = (fixture / "unfitted-output" / number_path.name).read_bytes()
    target.write_bytes(original_model)
    number_path.write_bytes(original_numbers)
    calls = []
    def forbidden(*args, **kwargs):
        pytest.fail("A complete first-audit model cannot fit, replay, audit or pool again")
    for owner, name in ((f4, "_execute_f4_model_component"), (f4, "_replay_f4_model_component"),
                        (f5, "_validate_retained_model_objects"), (f5, "pool_predictions")):
        monkeypatch.setattr(owner, name, forbidden)
    def cancelled_r(command, **kwargs):
        calls.append(command)
        spec = strict_json_bytes(Path(command[-1]).read_bytes())
        assert spec["task"] == task and spec["seed"] == 780_000_001
        assert number_path.read_bytes() == original_numbers
        assert not (output / "F5_FINAL_FULL_DATA_M02.numbers.json").exists()
        kwargs["stdout"].write(b"UNFITTED_PARTIAL_STDOUT_BEFORE_CANCEL")
        kwargs["stdout"].flush()
        kwargs["stderr"].write(b"UNFITTED_PARTIAL_STDERR_BEFORE_CANCEL")
        kwargs["stderr"].flush()
        raise SystemExit("BOUNDED_SPAWN_CANCELLED")
    monkeypatch.setattr(f5.subprocess, "run", cancelled_r)
    job = (source, target, lineage["final_refit_plan"], task, lineage["final_recipe"])
    with f5._full_score_scratch(tmp_path):
        ready = f5._execute_final_refit_bundle_pair(job, include_shap=False)
        assert ready["status"] == "NUMERICAL_READY" and ready["final_numerical_component_count"] == 1
        assert ready["final_model_fit_count"] == ready["native_model_replay_count"] == 0
        assert not calls and not (output / "shap-components").exists()
        absent = output / "F5_FINAL_FULL_DATA_M02.zip"
        with pytest.raises(ContractError, match="F5_FULL_FINAL_RETAINED_MODEL_REQUIRED"):
            f5._execute_final_refit_bundle_pair((source, absent, *job[2:]), include_shap=False)
        assert not absent.exists() and not absent.with_suffix("").exists()
        with pytest.raises(SystemExit, match="BOUNDED_SPAWN_CANCELLED") as failure:
            f5._execute_final_refit_bundle_pair(job)
        work, = [path for path in (output / "shap-components").iterdir() if path.is_dir()]
        assert (work / "stdout.log").read_bytes() == b"UNFITTED_PARTIAL_STDOUT_BEFORE_CANCEL"
        assert (work / "stderr.log").read_bytes() == b"UNFITTED_PARTIAL_STDERR_BEFORE_CANCEL"
        assert (work / "model.bin").is_file() and (work / "response.csv").is_file()
        assert f"F5_SHAP_NATIVE_EVIDENCE_RETAINED:{work}" in failure.value.__notes__
        assert not list((output / "shap-components").glob("*.zip"))
        original_read = f5.read_safe_zip
        def no_native_fallback(path, *args, **kwargs):
            assert path != target, "An incomplete SHAP must reject before opening the native model ZIP"
            return original_read(path, *args, **kwargs)
        with monkeypatch.context() as retry:
            retry.setattr(f5, "read_safe_zip", no_native_fallback)
            with pytest.raises(ContractError, match="F5_SHAP_INCOMPLETE_COMPONENT_REQUIRES_NEW_AUTHORITY"):
                f5._execute_final_refit_bundle_pair(job)
    assert len(calls) == 1 and number_path.read_bytes() == original_numbers
    assert target.read_bytes() == original_model and (work / "stdout.log").is_file()


def test_full0_numerical_reader_requires_independent_original_compile_record(tmp_path, monkeypatch):
    """Consume the preceding original compiler output; never rebuild its fixture."""
    import os
    import shutil
    fixture = os.environ.get("PADML_FULL0_COMPILED_INPUT_FIXTURE")
    if fixture is None:
        pytest.skip("Requires the retained H9 full0 compiler fixture; no additional fits")
    source = Path(fixture)
    compiled = f5._read_final_lineage(source / "original-compile-record.json")
    inputs = tmp_path / "copied-final-input"
    shutil.copytree(source / "final-input", inputs)
    lineage = f5._read_final_lineage(inputs / "lineage.json")
    original_lineage = copy.deepcopy(lineage)
    def forbidden(*args, **kwargs):
        pytest.fail("NO_UPSTREAM_RECOMPILATION_OR_NATIVE_OBJECT_AT_NUMERICAL_BOUNDARY")
    for name in ("_compile_full_final_inputs", "_full_data_locked_score_program",
                 "_materialize_final_search_inputs", "materialize_final_full_data_mice",
                 "_validate_retained_model_objects", "_execute_final_refit_engine"):
        monkeypatch.setattr(f5, name, forbidden)
    monkeypatch.setattr(f4, "_replay_f4_model_component", forbidden)
    tasks = f5._consume_final_parameter_source(lineage, None, input_root=inputs, compiled_input_record=compiled)
    assert list(tasks) == list(range(1, 21)) and {task["family"] for task in tasks.values()} == {"COX_PH"}
    for damage in ("missing", "status", "family", "bundle_count", "model_fit_count", "lineage_sha256",
                   "index_sha256", "source_identity_sha256", "total_size_bytes", "interpretation", "mice_plan"):
        changed = copy.deepcopy(compiled)
        if damage == "missing":
            changed = None
        elif damage.endswith("sha256"):
            changed[damage] = "f" * 64
        elif damage in {"bundle_count", "model_fit_count", "total_size_bytes"}:
            changed[damage] += 1
        elif damage == "mice_plan":
            changed["final_mice_artifacts"][0]["sha256"] = "f" * 64
        else:
            changed[damage] = "UNFITTED_CHANGED_ORIGINAL_RECORD"
        with pytest.raises(ContractError):
            f5._consume_final_parameter_source(lineage, None, input_root=inputs, compiled_input_record=changed)
    bound = inputs / "bound/M01.zip"
    raw = bound.read_bytes()
    bound.write_bytes(raw + b"UNFITTED_SELF_REHASHED_INPUT")
    with pytest.raises(ContractError, match="F5_FULL_FINAL_COMPILED_COMPONENT_DRIFT"):
        f5._consume_final_parameter_source(lineage, None, input_root=inputs, compiled_input_record=compiled)
    # Resealing the received plan and all its local pointers cannot replace
    # the independently retained original compiler return value.
    plan = copy.deepcopy(lineage["final_refit_plan"])
    plan["component_records"][0].update(sha256=f5.sha256_file(bound), size_bytes=bound.stat().st_size)
    plan = f5._nested_science._sealed({key: value for key, value in plan.items() if key != "identity_sha256"})
    changed_lineage = {**lineage, "final_refit_plan": plan}
    (inputs / "lineage.json").write_bytes(canonical_json_bytes(changed_lineage))
    (inputs / "full-final-input.json").write_bytes(canonical_json_bytes(plan))
    with pytest.raises(ContractError, match="F5_FULL_FINAL_COMPILED_INPUT_RECORD_INVALID"):
        f5._consume_final_parameter_source(changed_lineage, None, input_root=inputs, compiled_input_record=compiled)
    bound.write_bytes(raw)
    (inputs / "lineage.json").write_bytes(canonical_json_bytes(original_lineage))
    (inputs / "full-final-input.json").write_bytes(canonical_json_bytes(original_lineage["final_refit_plan"]))
    bound.rename(inputs / "retained-original-M01.zip")
    with pytest.raises(ContractError, match="F5_FULL_FINAL_COMPILED_COMPONENT_DRIFT"):
        f5._consume_final_parameter_source(lineage, None, input_root=inputs, compiled_input_record=compiled)
    (inputs / "retained-original-M01.zip").rename(bound)
    numbers = tmp_path / "only-numbers"
    numbers.mkdir()
    for path in sorted((source / "unfitted-output").glob("*.numbers.json")):
        shutil.copyfile(path, numbers / path.name)
    policy = {"configured_worker_ceiling": "EXECUTION_HOST_C_MINUS_8", "memory_bytes_per_worker": 8 * 1024**3,
              "scratch_bytes_per_worker": 8 * 1024**3, "memory_reserve_bytes": 2 * 1024**3,
              "scratch_reserve_bytes": 2 * 1024**3, "transfer_archive_worker_ceiling": 24}
    monkeypatch.setattr(f5, "_bounded_ordered_spawn", lambda fn, jobs, **kwargs: [fn(job) for job in jobs])
    result = f5.collect_final_refit_results(numbers, lineage["family_decision"], lineage["final_refit_plan"],
        input_root=inputs, produce_shap=False, resource_policy=policy, compiled_input_record=compiled)
    assert len(result["final_component_numbers"]) == 20
    assert result["pooled"]["mean_survival"] == [[1.] + [.8] * 36 for _ in lineage["centers"]]
    assert not list(numbers.glob("*.zip"))
    assert f5._read_final_lineage(source / "original-compile-record.json") == compiled
    assert f5._read_final_lineage(source / "final-input/lineage.json") == original_lineage


@pytest.mark.parametrize("horizon", [12, 24])
@pytest.mark.parametrize("shortage", [None, "scratch", "memory"])
def test_full0_collection_current_admission_preserves_historical_policy(tmp_path, monkeypatch, horizon, shortage):
    """Only original admission runs; stop before lineage, models or numbers."""
    from padml import runtime
    policy = {"configured_worker_ceiling": runtime.CPU_MINUS_8,
        "memory_bytes_per_worker": 9 * 1024**3, "scratch_bytes_per_worker": 1024,
        "memory_reserve_bytes": 4096, "scratch_reserve_bytes": 10**12,
        "transfer_archive_worker_ceiling": 1000}
    original = dict(policy)
    observation = {"effective_cpus": 32,
        "available_memory_bytes": 2 * 1024**3 + policy["memory_reserve_bytes"],
        "scratch_available_bytes": 1024, "scratch_root": str(tmp_path)}
    if shortage == "scratch":
        observation["scratch_available_bytes"] -= 1
    if shortage == "memory":
        observation["available_memory_bytes"] -= 1
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda root: observation)
    monkeypatch.setattr(runtime, "effective_cpu_count", lambda: 32)
    calls, reached = [], []
    original_admission = runtime.resource_admission
    def admit(effective, observed, **kwargs):
        calls.append(dict(effective))
        return original_admission(effective, observed, **kwargs)
    monkeypatch.setattr(runtime, "resource_admission", admit)
    class AdmittedBeforeLineage(Exception):
        pass
    def lineage(*args, **kwargs):
        reached.append(True)
        raise AdmittedBeforeLineage
    monkeypatch.setattr(f5, "_read_final_lineage", lineage)
    options = {"input_root": tmp_path, "produce_shap": False, "resource_policy": policy}
    plan = {"kind": "PADML_NESTED_FULL_FINAL_INPUT_V1", "selection_horizon_months": horizon}
    if shortage is None:
        with pytest.raises(AdmittedBeforeLineage):
            f5.collect_final_refit_results(tmp_path, {}, plan, **options)
    else:
        with pytest.raises(ContractError, match="RESOURCE_ADMISSION_ZERO"):
            f5.collect_final_refit_results(tmp_path, {}, plan, **options)
    assert calls == [{**original, "memory_bytes_per_worker": 2 * 1024**3, "scratch_reserve_bytes": 0}]
    assert reached == ([True] if shortage is None else [])
    assert policy == original


def test_full0_original_diagnostic_retains_first_audit_values_from_existing_fixture(tmp_path, monkeypatch):
    """Reuse the earlier UNFITTED M20; only the metric leaf is stubbed here."""
    import os
    fixture = os.environ.get("PADML_FULL0_FINAL_NUMBERS_FIXTURE")
    if fixture is None:
        pytest.skip("Requires the preserved H9 UNFITTED final fixture; do not recreate fits")
    source = Path(fixture)
    lineage = f5._read_final_lineage(source / "final-input/lineage.json")
    plan = lineage["final_refit_plan"]
    assert plan["development_lock"]["selected_family"] == "COX_PH"
    def forbidden(*args, **kwargs):
        pytest.fail("The numerical handoff must not load a model or rerun its native audit")
    monkeypatch.setattr(f4, "_replay_f4_model_component", forbidden)
    monkeypatch.setattr(f5, "_validate_retained_model_objects", forbidden)
    monkeypatch.setattr(f5, "_execute_final_refit_engine", forbidden)
    numbers = []
    for record in plan["component_records"]:
        component = source / "final-input" / record["path"]
        task = f5._nested_science._read_component(component)[0]
        numbers.append(f5._collect_final_refit_component((
            source / "unfitted-output" / f"F5_FINAL_FULL_DATA_M{task['imputation']:02d}.zip",
            component, task, plan, lineage["family_decision"], None)))
    data = {"kind": "PADML_F5_PAIRED_M20_PREDICTIONS", "predictions": [row["prediction"] for row in numbers],
            "final_refit_receipts": [row["receipt"] for row in numbers], "centers": lineage["centers"],
            "final_family": lineage["final_family"], "family_decision": lineage["family_decision"],
            "final_refit_plan": plan}
    metric_calls = []
    def metric_leaf(*args, **kwargs):
        metric_calls.append(True)
        return {"status": "COMPUTED", "UNFITTED_METRIC_LEAF": True}
    monkeypatch.setattr(f5, "diagnose_mi", metric_leaf)
    target = tmp_path / "original-diagnostic.zip"
    report = f5._execute_paired_diagnostic(data, b"UNFITTED_METRIC_INPUT", target,
        source_sha256=sha256_bytes(canonical_json_bytes(data)), archive_records=None, final_component_numbers=numbers)
    assert report["stage_acceptance"] is False and metric_calls == [True]
    result = strict_json_bytes(f5.read_safe_zip(target)["f5-mi.json"])
    assert result["final_component_numbers"] == numbers
    assert result["scope"] == "FULL_DATA_APPARENT_ONLY" and result["stage_acceptance"] is False
    assert result["pooled"]["mean_survival"] == [[1.] + [.8] * 36 for _ in lineage["centers"]]
    for damage in ("missing", "incomplete", "prediction", "receipt", "health", "audit", "archive"):
        changed = copy.deepcopy(numbers)
        if damage == "missing":
            changed = None
        elif damage == "incomplete":
            changed.pop()
        elif damage == "prediction":
            changed[0]["prediction"]["patient_ids"].reverse()
        elif damage == "receipt":
            changed[0]["receipt"]["task_sha256"] = "a" * 64
        elif damage == "health":
            changed[0]["fit_health"]["converged"] = False
        elif damage == "audit":
            changed[0]["retained_audit"]["training_event_count"] -= 1
        else:
            changed[0]["archive"]["archive_sha256"] = "a" * 64
        with pytest.raises(ContractError, match="F5_FULL_FINAL_NUMERICAL_HANDOFF_DRIFT"):
            f5._execute_paired_diagnostic(data, b"UNFITTED_METRIC_INPUT", tmp_path / (damage + ".zip"),
                source_sha256=sha256_bytes(canonical_json_bytes(data)), final_component_numbers=changed,
                archive_records=[row["archive"] for row in numbers] if damage == "archive" else None)
        assert metric_calls == [True] and not (tmp_path / (damage + ".zip")).exists()


@pytest.mark.parametrize("nested_mode", [False, True])
def test_non_ph_cli_preserves_legacy_or_forwards_full0_native_source_and_resources(tmp_path, monkeypatch, capsys, nested_mode):
    import sys
    index, response, results, target, inputs = [tmp_path / name for name in
        ("lineage.json", "response.csv", "results", "non-ph.zip", "inputs")]
    inputs.mkdir()
    policy = {"configured_worker_ceiling": "EXECUTION_HOST_C_MINUS_8", "memory_bytes_per_worker": 1,
        "scratch_bytes_per_worker": 1, "memory_reserve_bytes": 0, "scratch_reserve_bytes": 0,
        "transfer_archive_worker_ceiling": 1000}
    policy_path, source_path = tmp_path / "resources.json", tmp_path / "source.json"
    policy_path.write_bytes(canonical_json_bytes(policy))
    compiled, compiled_path = {"UNFITTED_COMPILE_RECORD": True}, tmp_path / "original-compile.json"
    compiled_path.write_bytes(canonical_json_bytes(compiled))
    observed = []
    def consumer(*args, **kwargs):
        observed.append((args, kwargs))
        return {"UNFITTED_CLI_ONLY": True}
    monkeypatch.setattr(f5, "execute_non_ph_action", consumer)
    monkeypatch.setattr(sys, "argv", ["padml-f5", "non-ph", *map(str, (index, response, results, target)),
        "--input-root", str(inputs), *(["--resource-policy", str(policy_path), "--parameter-source", str(source_path),
                                       "--compiled-input-record", str(compiled_path)]
                                      if nested_mode else [])])
    f5.main()
    assert strict_json_bytes(capsys.readouterr().out.encode()) == {"UNFITTED_CLI_ONLY": True}
    assert observed == [((index, response, results, target), {"input_root": inputs, "workers": None,
        **({"parameter_source_path": source_path, "resource_policy": policy,
            "compiled_input_record": compiled} if nested_mode else {})})]


@pytest.mark.parametrize("nested_mode", [False, True])
def test_final_aggregate_cli_selects_full0_sources_without_requiring_legacy_mice_flags(tmp_path, monkeypatch, capsys, nested_mode):
    import sys
    index, response, results, action, target, inputs = [tmp_path / name for name in
        ("lineage.json", "response.csv", "results", "non-ph.zip", "aggregate.zip", "inputs")]
    inputs.mkdir()
    policy, policy_path = {"UNFITTED_RESOURCE_ROUTING_ONLY": True}, tmp_path / "resource.json"
    policy_path.write_bytes(canonical_json_bytes(policy))
    compiled, compiled_path = {"UNFITTED_COMPILE_RECORD": True}, tmp_path / "original-compile.json"
    compiled_path.write_bytes(canonical_json_bytes(compiled))
    source, mice_plan, mice_archive = [tmp_path / name for name in ("source.json", "mice.json", "mice.zip")]
    observed = []
    monkeypatch.setattr(f5, "execute_final_aggregate", lambda *args, **kwargs: observed.append((args, kwargs)) or {"UNFITTED_CLI": True})
    monkeypatch.setattr(sys, "argv", ["padml-f5", "final-aggregate", *map(str, (index, response, results, action, target)),
        "--input-root", str(inputs), "--parameter-source", str(source),
        *(["--resource-policy", str(policy_path), "--compiled-input-record", str(compiled_path)] if nested_mode
          else ["--mice-plan", str(mice_plan), "--final-mice", str(mice_archive)])])
    f5.main()
    assert strict_json_bytes(capsys.readouterr().out.encode()) == {"UNFITTED_CLI": True}
    assert observed == [((index, response, results, action, target), {"input_root": inputs,
        "mice_plan_path": None if nested_mode else mice_plan, "final_mice_path": None if nested_mode else mice_archive,
        "parameter_source_path": source, "workers": None, "sensitivity_results": {},
        **({"resource_policy": policy, "compiled_input_record": compiled} if nested_mode else {})})]


@pytest.mark.parametrize("damage", [None, "request", "source", "duplicate", "missing", "partial", "default_subset"])
def test_stop12_continuous_explicit_complement_reaches_original_family_consumer(
    unfitted_full_score_sources, tmp_path, monkeypatch, damage,
):
    from padml import nested_loco as nested, runtime
    from test_nested_full_score import _unfitted_score_shard_engines
    from test_full0_fixed12_rescore import decision
    inputs, selector, roots, _ = unfitted_full_score_sources
    monkeypatch.setattr(runtime, "effective_cpu_count", lambda: 64)
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda root: {
        "effective_cpus": 64, "available_memory_bytes": 10**12,
        "scratch_available_bytes": 10**12, "scratch_root": str(root)})
    calls = _unfitted_score_shard_engines(monkeypatch)
    root = tmp_path / "score"
    root.mkdir()
    policy = dict(configured_worker_ceiling=runtime.CPU_MINUS_8, memory_bytes_per_worker=10**6,
        scratch_bytes_per_worker=10**6, memory_reserve_bytes=100, scratch_reserve_bytes=100,
        transfer_archive_worker_ceiling=1)
    budgets = dict(retained_bytes_per_component=10**7, expanded_bytes_per_component=10**6,
                   shared_storage_bytes=10**8)
    # Synthetic prepared compiler boundary only; no historical compatibility claim.
    request = f5._compile_full_score_inputs(*inputs, selector, roots, root / "request",
        rscript="UNFITTED", family="GBM_COX", resource_policy=policy)
    request = nested._sealed({**{k: v for k, v in request.items() if k != "identity_sha256"},
        "selection_horizon_months": 12, "science_decision": decision()})
    for name in ("full-score-input.json", "full-score-input.GBM_COX.json"):
        (root / "request" / name).write_bytes(canonical_json_bytes(request))
    monkeypatch.setattr(f5, "_compile_full_score_inputs", lambda *a, **k: request)
    ids = [row["path"] for row in request["component_records"]]
    def run(**options):
        return f5._full_data_locked_score_program(*inputs, selector, roots, root,
            rscript="UNFITTED", replay=False, resume=True, family="GBM_COX",
            selection_horizon_months=12, science_decision=decision(),
            retained_full0_source_bundle=tmp_path / "UNFITTED-source.zip",
            resource_policy=policy, **budgets, **options)
    old = root / "score-batches" / "old"
    run(task_ids=ids[:150], batch_root=old)
    assert len(calls) == 150
    remaining = ids[150:]
    expected = request["identity_sha256"]
    if damage == "request": expected = "0" * 64
    if damage == "source":
        path = old / "execution.json"
        value = strict_json_bytes(path.read_bytes())
        value["source_identity"] = "0" * 64
        path.write_bytes(canonical_json_bytes(value))
    if damage == "duplicate": remaining = [ids[0], *remaining]
    if damage == "missing": remaining = remaining[1:]
    if damage == "partial":
        record = request["component_records"][150]
        native = root / "components/score-native/GBM_COX" / f"R{record['repeat']}_K{record['inner_fold']}_M{record['imputation']:02d}"
        native.mkdir()
    if damage:
        expected_error = {
            "request": "NESTED_FULL_SCORE_CONTINUOUS_REQUEST_DRIFT",
            "source": "NESTED_FULL_SCORE_BATCH_SOURCE_DRIFT",
            "duplicate": "NESTED_FULL_SCORE_BATCH_COMPLETE_SET_REQUIRED",
            "missing": "NESTED_FULL_SCORE_BATCH_COMPLETE_SET_REQUIRED",
            "partial": "F4_NATIVE_MODEL_TARGET_ALREADY_STARTED",
            "default_subset": "NESTED_FULL_SCORE_BATCH_COMPLETE_SET_REQUIRED",
        }[damage]
        with pytest.raises(ContractError, match=expected_error):
            if damage == "default_subset":
                run(score_batches=[old])
            else:
                run(task_ids=remaining, score_batches=[old], batch_root=root / "score-batches/new",
                    continuous_request_sha256=expected)
        assert len(calls) == 150
        assert not (root / "score-batches/new").exists()
        assert (old / "execution.json").is_file()
        if damage == "partial":
            assert native.is_dir()
        return
    result = run(task_ids=remaining, score_batches=[old], batch_root=root / "score-batches/new",
                 continuous_request_sha256=expected)
    assert len(calls) == 300
    assert result["new_model_fits"] == result["new_model_native_verification_count"] == 150
    assert result["native_model_replay_count"] == 0
    assert len(result["training_scores"]) == len(result["fresh_score_execution"]) == 1
    assert result["training_scores"][0]["family"] == "GBM_COX"
    assert (root / "score-evidence/GBM_COX/training-score.json").is_file()


def test_full0_prepared_coxtime_score_reopens_inputs_without_recompilation(
    unfitted_full_score_sources, tmp_path, monkeypatch,
):
    """Real score-input readers and original worker boundary; every fit stays UNFITTED."""
    from padml import nested_loco as nested, runtime
    inputs, selector, searches, _ = unfitted_full_score_sources
    root = tmp_path / "prepared-coxtime-score"
    root.mkdir()
    budgets = dict(retained_bytes_per_component=10**7, expanded_bytes_per_component=10**6,
                   shared_storage_bytes=10**8)
    request = f5._compile_full_score_inputs(*inputs, selector, searches, root / "request",
        family="COXTIME_SET_A", rscript="UNFITTED", workers=1)
    source = tmp_path / "original-score-producer.zip"
    f4.compile_f45_source_bundle(source)
    options = dict(source_bundle=source, shared_storage_bytes=budgets["shared_storage_bytes"],
                   expanded_bytes_per_component=budgets["expanded_bytes_per_component"])
    assert f5._read_prepared_full_score_inputs(inputs[0], root / "request", **options) == request
    original_bytes = (root / "request/full-score-input.COXTIME_SET_A.json").read_bytes()
    policy = dict(configured_worker_ceiling=runtime.CPU_MINUS_8, memory_bytes_per_worker=2 * 1024**3,
        scratch_bytes_per_worker=10**6, memory_reserve_bytes=0, scratch_reserve_bytes=0,
        transfer_archive_worker_ceiling=1)
    monkeypatch.setattr(runtime, "effective_cpu_count", lambda: 32)
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda path: {
        "effective_cpus": 32, "available_memory_bytes": 10**12,
        "scratch_available_bytes": 10**12, "scratch_root": str(path)})
    lineage = {"plan": inputs[0], "selector_root": str(selector),
        "search_roots": {key: str(path) for key, path in searches.items()}, "score_root": str(root),
        "rscript": "UNFITTED", "resource_policy": policy,
        "science_decision": _unfitted_confirmed_decision(fixed_bootstrap=True), **budgets}
    monkeypatch.setattr(f5, "_read_final_lineage", lambda *a, **k: lineage)
    def forbidden(*args, **kwargs):
        pytest.fail("Prepared scores cannot rebuild MICE, selector or Q")
    monkeypatch.setattr(f5, "_materialized_full_data_development_sources", forbidden)
    monkeypatch.setattr(f5, "_compile_full_score_inputs", forbidden)
    seen = []
    def before_fit(worker, jobs, **kwargs):
        assert worker is f5._execute_and_verify_score_archive_job and len(jobs) == 300
        assert [job["source_sha256"] for job in jobs] == [row["sha256"] for row in request["component_records"]]
        seen.extend(jobs)
        raise RuntimeError("UNFITTED_ORIGINAL_SCORE_WORKER_BOUNDARY")
    monkeypatch.setattr(runtime, "_bounded_ordered_spawn", before_fit)
    def execute():
        return f5.execute_full_data_locked_scores(tmp_path / "lineage.json", resume=True,
            family="COXTIME_SET_A", prepared_score_root=root, prepared_score_source_bundle=source)
    with pytest.raises(RuntimeError, match="UNFITTED_ORIGINAL_SCORE_WORKER_BOUNDARY"):
        execute()
    assert len(seen) == 300 and (root / "request/full-score-input.COXTIME_SET_A.json").read_bytes() == original_bytes
    # The original coordinate, not a new batch name, still owns a partial fit.
    Path(seen[0]["root"]).mkdir()
    with pytest.raises(ContractError, match="INCOMPLETE_ARCHIVE_REQUIRES_NEW_FIT_AUTHORITY"):
        execute()
    assert len(seen) == 300
    # Even a self-resealed input cannot change the registered model seed.
    record = request["component_records"][0]
    component = root / "request" / record["path"]
    task, _, entries = nested._read_component(component)
    task["registered_model_seed"] += 1
    task["model_seed"] += 1
    entries["task.json"] = canonical_json_bytes(task)
    component.rename(component.with_suffix(".original.zip"))
    nested._write_component_archive(component, entries)
    record.update(sha256=f5.sha256_file(component), size_bytes=component.stat().st_size,
                  task_sha256=nested._sha(task), registered_model_seed=task["registered_model_seed"])
    request = nested._sealed({key: value for key, value in request.items() if key != "identity_sha256"})
    (root / "request/full-score-input.COXTIME_SET_A.json").write_bytes(canonical_json_bytes(request))
    with pytest.raises(ContractError, match="NESTED_FULL_SCORE_SOURCE_INVALID"):
        f5._read_prepared_full_score_inputs(inputs[0], root / "request", **options)


def test_full0_score_shards_family_inputs_gather_and_original_final_compiler(
    unfitted_full_score_sources, tmp_path, monkeypatch,
):
    from padml import nested_loco as nested, runtime
    from test_nested_full_score import _unfitted_score_shard_engines
    inputs, selector_root, roots, _ = unfitted_full_score_sources
    monkeypatch.setattr(runtime, "effective_cpu_count", lambda: 64)
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda root: {
        "effective_cpus": 64, "available_memory_bytes": 10**12, "scratch_available_bytes": 10**12, "scratch_root": str(root)})
    calls = _unfitted_score_shard_engines(monkeypatch)
    root = tmp_path / "score"
    policy = {"configured_worker_ceiling": "EXECUTION_HOST_C_MINUS_8", "memory_bytes_per_worker": 10**6,
        "scratch_bytes_per_worker": 10**6, "memory_reserve_bytes": 100, "scratch_reserve_bytes": 100,
        "transfer_archive_worker_ceiling": 1}
    budgets = {"retained_bytes_per_component": 10**7, "expanded_bytes_per_component": 10**6,
               "shared_storage_bytes": 10**8}
    def run(**options):
        return f5._full_data_locked_score_program(*inputs, selector_root, roots, root,
            rscript="UNFITTED", replay=False, resource_policy=policy, **budgets, **options)
    prepared = run(prepare_only=True)
    assert calls == [] and len(prepared["task_ids"]) == 2100 and prepared["new_model_fits"] == 0
    batches = []
    for family in nested._families():
        ids = [row["path"] for row in prepared["request"]["component_records"] if row["family"] == family]
        batch = root / "score-batches" / family
        produced = run(resume=True, family=family, task_ids=ids, batch_root=batch)
        assert produced["new_model_fits"] == produced["new_model_native_verification_count"] == 300
        assert len(produced["request"]["component_records"]) == 300 and produced["result"] is None
        batches.append(batch)
    assert len(calls) == 2100 and not (root / "full-score-result.json").exists()
    shutil = __import__("shutil")
    shutil.move(root / "components/score-native", tmp_path / "retained-execution-owned-native")
    def forbidden(*args, **kwargs):
        pytest.fail("Full0 gather and final compilation must not load native score models or refit")
    monkeypatch.setattr(runtime, "_bounded_ordered_spawn", forbidden)
    monkeypatch.setattr(f4, "_replay_f4_model_component", forbidden)
    monkeypatch.setattr(f5, "_execute_final_refit_engine", forbidden)
    gathered = run(resume=True, score_batches=batches)
    assert gathered["new_model_fits"] == gathered["native_model_replay_count"] == 0
    assert gathered["score_numerical_component_count"] == 2100 and gathered["pool_execution_reports"] == []
    result = gathered["result"]
    assert result["family_decision"]["selected_family"] == "COX_PH"
    assert result["model_fit_count"] == 2100 and result["new_stop_fits"] == result["new_mice_chains"] == 0
    assert result["external_validation"] is False
    for score in result["training_scores"]:
        assert score["ranking_metric_values"] == pytest.approx([0.039166666666666655]*3)
        assert sum(score["metric_values"]) / 300 == pytest.approx(2*score["mean_ibs"])
    final = f5._compile_full_final_inputs(*inputs, selector_root, roots, root, tmp_path / "final-input",
        rscript="UNFITTED", resource_policy=policy, **budgets)
    assert final["family_decision"] == result["family_decision"]
    assert final["planned_post_lock_model_fits"] == len(final["component_records"]) == 20
    assert len(calls) == 2100


def test_full0_score_program_replays_2100_unfitted_archives_and_selects_after_real_pooling(
    unfitted_full_score_sources, tmp_path, monkeypatch,
):
    """Real stage/archives/IBS math; only numerical models and pool are stubs."""
    from padml import f2_kernel, nested_loco as nested, runtime
    inputs, selector_root, roots, _ = unfitted_full_score_sources
    calls = {"new_unfitted_objects": 0, "retained_object_reads": 0, "pools": [], "batches": [], "handles": {}}
    def engine(family, task, training, response, recipe, *, retained_objects=None, prediction_rows=None, **kwargs):
        import os
        import tempfile
        assert os.environ["TMPDIR"] == tempfile.gettempdir() == str(root / "scratch")
        f5._validate_nested_full_score_task(task)
        binary = canonical_json_bytes({"UNFITTED": True, "task": task, "recipe": recipe})
        if retained_objects is None:
            calls["new_unfitted_objects"] += 1
        else:
            assert retained_objects == (binary, binary)
            calls["retained_object_reads"] += 1
        rows = training if prediction_rows is None else prediction_rows
        curve = [1.0] + [0.6 if task["imputation"] <= 10 else 1.0] * 36
        return {"model": binary, "baseline": binary, "fit_health": {"UNFITTED": True,
                    **({"model_binary_sha256": sha256_bytes(binary)} if family == "XGBOOST_COX" else {})},
                "survival": [curve for _ in rows],
                **({"training_survival": [curve for _ in training]} if kwargs.get("replay_training") else {})}
    def audit(family, model, baseline, health, task, **kwargs):
        assert model == baseline and health == {"UNFITTED": True,
            **({"model_binary_sha256": sha256_bytes(model)} if family == "XGBOOST_COX" else {})}
        assert strict_json_bytes(model)["task"] == task
        recipe = strict_json_bytes(model)["recipe"]
        column_map = f2_kernel._expected_family_parent_column_map(task["selected_parents"], family,
            f5.predictor_contract(Path(f5.__file__).parent), recipe["transform_recipe"])
        columns = [column for row in column_map for column in row["columns"]]
        if family in {"XGBOOST_COX", "COXTIME_SET_A"}:
            columns.sort(key=lambda text: text.encode())
            return {"design_columns": columns, **({"booster_round_count": task["parameters"]["selected_rounds"]}
                    if family == "XGBOOST_COX" else {"input_width": len(columns)})}
        return {"UNFITTED_OBJECT_READBACK": True, "selected_parents": task["selected_parents"], "design_columns": columns}
    def pool(worker, jobs, *, selected_slots, schedule_order=None, on_result=None, execution_report=None):
        calls["pools"].append((worker.__name__, len(jobs), selected_slots))
        assert selected_slots == 1 and len(jobs) in {300, 298, 2, 1500}
        if len(jobs) == 1500:
            assert {job["score_evidence"]["record"]["family"] for job in jobs}.isdisjoint({"COX_PH", "RSF"})
            assert len(calls["batches"]) == 75  # Cox 15+15, RSF 15, then both complete families' numerical checks
        assert schedule_order is None or sorted(schedule_order) == list(range(len(jobs)))
        values = []
        for index, job in enumerate(jobs):
            # Interrupt before the third coordinate starts, not during a fit.
            if len(calls["pools"]) == 1 and index == 2:
                raise RuntimeError("UNFITTED_INTERRUPTION_BEFORE_THIRD_START")
            value = worker(job)
            assert isinstance(value, dict) and value["state"] == "COMPLETE"
            assert not {"prediction", "survival", "receipt", "fit_health"}.intersection(value)
            assert len(canonical_json_bytes(value)) < 512
            assert on_result is not None
            on_result(index, value)
            calls["handles"][job["source_sha256"]] = dict(value)
            values.append(value)
        return values
    original_pool = f2_kernel._pool_prediction_batch
    def pooled(batch, horizons):
        calls["batches"].append(len(batch))
        assert len(batch) == 20
        return original_pool(batch, horizons)
    monkeypatch.setattr(f5, "_execute_final_refit_engine", engine)
    monkeypatch.setattr(f5, "_validate_retained_model_objects", audit)
    monkeypatch.setattr(runtime, "_bounded_ordered_spawn", pool)
    monkeypatch.setattr(f2_kernel, "_pool_prediction_batch", pooled)
    def unfitted_health(*args, **kwargs):
        assert args[1].get("UNFITTED") is True
    monkeypatch.setattr(f5, "_validate_final_r_fit_health", unfitted_health)
    monkeypatch.setattr(f2_kernel, "_validate_python_fit_health", unfitted_health)
    def unfitted_audit_numbers(family, values, health, task):
        assert values["UNFITTED_OBJECT_READBACK"] is True and health == {"UNFITTED": True}
        assert values["selected_parents"] == task["selected_parents"]
        return values
    monkeypatch.setattr(f5, "_validate_retained_r_audit_numbers", unfitted_audit_numbers)
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda root: {
        "effective_cpus": 64, "available_memory_bytes": 10**12,
        "scratch_available_bytes": 10**12, "scratch_root": str(root),
    })
    def forbidden(*args, **kwargs):
        raise AssertionError("UNAUTHORIZED_NEW_STOP_OR_OUTER_SOURCE")
    monkeypatch.setattr(f4, "_prepare_o_fit_partition", forbidden)
    monkeypatch.setattr(f4, "_execute_f4_stop_component", forbidden)
    policy = {"configured_worker_ceiling": "EXECUTION_HOST_C_MINUS_8", "memory_bytes_per_worker": 1,
              "scratch_bytes_per_worker": 1, "memory_reserve_bytes": 0,
              "scratch_reserve_bytes": 0, "transfer_archive_worker_ceiling": 1}
    root = tmp_path / "score"
    budgets = {"retained_bytes_per_component": 5_000_000,
               "expanded_bytes_per_component": 1_000_000, "shared_storage_bytes": 100_000_000}
    inner_only = [{key: value for key, value in part.items() if key != "stopping"} for part in inputs[1]]
    own_inputs = (inputs[0], inner_only, inputs[2])
    unready = {family: tmp_path / "UNREADY" / family for family in roots}
    with pytest.raises(RuntimeError, match="UNFITTED_INTERRUPTION_BEFORE_THIRD_START"):
        f5._full_data_locked_score_program(
            *own_inputs, selector_root, unready, root, rscript="UNFITTED", replay=False, family="COX_PH",
            resource_policy=policy, **budgets,
        )
    assert calls["new_unfitted_objects"] == 2 and calls["retained_object_reads"] == 4
    first = f5._full_data_locked_score_program(
        *own_inputs, selector_root, unready, root, rscript="UNFITTED", replay=False, resume=True, family="COX_PH",
        resource_policy=policy, **budgets,
    )
    assert first["result"] is None and first["new_model_fits"] == first["new_model_native_verification_count"] == 298
    assert first["native_model_replay_count"] == 2 and first["score_numerical_component_count"] == 0
    assert first["resource_reservation"]["retained_byte_ceiling"] == 2100 * budgets["retained_bytes_per_component"] + budgets["shared_storage_bytes"]
    assert first["configured_worker_ceiling"] == 56 and not (root / "full-score-result.json").exists()
    first_values = {name: (root / "score-evidence/COX_PH" / name).read_bytes()
                    for name in ("training-score.json", "execution.json")}
    def no_complete_native(*args, **kwargs):
        pytest.fail("COMPLETE_FAMILY_MUST_REPLAY_NUMBERS_WITHOUT_GLOBAL_RESULT")
    with monkeypatch.context() as numbers:
        numbers.setattr(f4, "_replay_f4_model_component", no_complete_native)
        numbers.setattr(f5, "_score_archive_handle", no_complete_native)
        numbers.setattr(runtime, "_bounded_ordered_spawn", no_complete_native)
        first_replay = f5._full_data_locked_score_program(
            *own_inputs, selector_root, unready, root, rscript="UNFITTED", replay=True, family="COX_PH",
            resource_policy=policy, **budgets)
    assert first_replay["training_scores"] == first["training_scores"]
    assert first_replay["new_model_fits"] == first_replay["native_model_replay_count"] == 0
    assert first_replay["score_numerical_component_count"] == 300
    with pytest.raises(ContractError, match="NESTED_FAMILY_SELECTION_INPUT_INVALID"):
        nested.select_training_family(first["training_scores"])
    with pytest.raises(ContractError, match="NESTED_FULL_SCORE_NUMERICAL_ORIGINAL_REQUIRED"):
        f5._compile_full_final_inputs(*inputs, selector_root, roots, root, tmp_path / "unready-final",
                                     rscript="UNFITTED", resource_policy=policy, **budgets)
    second = f5._full_data_locked_score_program(
        *own_inputs, selector_root, {**unready, "RSF": roots["RSF"]}, root, rscript="UNFITTED",
        replay=False, resume=True, family="RSF", resource_policy=policy, **budgets)
    assert second["new_model_fits"] == 300 and second["result"] is None
    assert not (root / "request/full-score-input.json").exists()
    produced = f5._full_data_locked_score_program(
        *inputs, selector_root, roots, root, rscript="UNFITTED", replay=False, resume=True,
        resource_policy=policy, **budgets)
    assert calls["new_unfitted_objects"] == 2100 and calls["retained_object_reads"] == 4802
    assert produced["new_model_fits"] == produced["new_model_native_verification_count"] == 1500
    assert produced["native_model_replay_count"] == 0 and produced["score_numerical_component_count"] == 600
    assert all((root / "score-evidence/COX_PH" / name).read_bytes() == raw for name, raw in first_values.items())
    # First production and incomplete-coordinate recovery above really used
    # the original native reader. Completed numerical consumption may not.
    def no_native_after_scores(*args, **kwargs):
        pytest.fail("COMPLETE_SCORE_CONSUMER_MUST_USE_RETAINED_NUMBERS")
    monkeypatch.setattr(f4, "_replay_f4_model_component", no_native_after_scores)
    monkeypatch.setattr(nested, "_component_execution_receipt", no_native_after_scores)
    monkeypatch.setattr(f5, "_score_archive_handle", no_native_after_scores)
    original_safe_read = f4.read_safe_zip
    def no_native_zip(source, *args, **kwargs):
        assert not isinstance(source, Path) or "score-native" not in source.parts
        return original_safe_read(source, *args, **kwargs)
    for module in (f4, f5, nested):
        monkeypatch.setattr(module, "read_safe_zip", no_native_zip)
    replayed = f5._full_data_locked_score_program(
        *inputs, selector_root, roots, root, rscript="UNFITTED", replay=True, resource_policy=policy, **budgets,
    )
    assert calls["new_unfitted_objects"] == 2100 and calls["retained_object_reads"] == 4802
    assert produced["result"] == replayed["result"] and replayed["new_model_fits"] == 0
    assert replayed["native_model_replay_count"] == 0 and replayed["score_numerical_component_count"] == 2100
    assert calls["pools"] == [("_execute_and_verify_score_archive_job", 300, 1),
        ("_replay_component_job", 2, 1), ("_execute_and_verify_score_archive_job", 298, 1),
        ("_execute_and_verify_score_archive_job", 300, 1), ("_execute_and_verify_score_archive_job", 1500, 1)]
    assert produced["retained_size_bytes"] <= produced["resource_reservation"]["retained_byte_ceiling"]
    assert len(list((root / "components/score-native").glob("*/*.zip"))) == 2100
    assert not any(path.is_dir() for path in (root / "components/score-native").glob("*/*"))
    result = produced["result"]
    assert result["family_decision"]["selected_family"] == "COX_PH"
    assert result["post_lock_model_fits"] == result["new_stop_fits"] == result["new_mice_chains"] == 0
    assert result["external_validation"] is False
    request = strict_json_bytes((root / "request/full-score-input.json").read_bytes())
    for score, execution in zip(result["training_scores"], result["fresh_score_execution"], strict=True):
        assert score["source_kind"] == "FRESH_FULL_DATA_M20_INNER_OOF" and score["outer_fold"] == 0
        assert score["ranking_metric_values"] == pytest.approx([0.039166666666666655] * 3)
        # Mean component metric is 0.07833...; averaging metrics instead of
        # pooling M20 probabilities first would be twice the declared score.
        assert sum(score["metric_values"]) / 300 == pytest.approx(2 * score["mean_ibs"])
        assert execution["component_count"] == 300 and len(execution["component_evidence_records"]) == 300
        assert nested._recompute_fresh_score_from_evidence(
            execution=execution, score=score, request=request, request_root=root / "request", result_root=root,
            expanded_bytes_per_component=budgets["expanded_bytes_per_component"],
            retained_bytes_per_component=budgets["retained_bytes_per_component"],
        ) == score
    assert len(calls["batches"]) == 360 and set(calls["batches"]) == {20}
    # This final-input call uses the *real* retained-score replay owner above,
    # not the score-proof stub used in the seven-family ABI test. All 2100
    # numerical components must revalidate; compiling the final lock fits nothing.
    final_root = tmp_path / "final-input"
    final_request = f5._compile_full_final_inputs(
        *inputs, selector_root, roots, root, final_root, rscript="UNFITTED",
        resource_policy=policy, **budgets,
    )
    assert final_request["family_decision"] == result["family_decision"]
    assert final_request["score_result_identity_sha256"] == result["identity_sha256"]
    assert final_request["development_lock"]["family_decision_sha256"] == result["family_decision"]["identity_sha256"]
    assert final_request["planned_post_lock_model_fits"] == len(final_request["component_records"]) == 20
    assert final_request["new_stop_fits"] == final_request["new_mice_chains"] == 0
    assert calls["new_unfitted_objects"] == 2100 and calls["retained_object_reads"] == 4802
    assert len(calls["batches"]) == 465 and set(calls["batches"]) == {20}
    assert calls["pools"][-1] == ("_execute_and_verify_score_archive_job", 1500, 1)
    for record in final_request["component_records"]:
        task, recipe, entries = nested._read_component(final_root / record["path"])
        assert task["family"] == "COX_PH" and task["registered_model_seed"] == 300000 and task["model_seed"] is None
        assert recipe["transform_recipe"]["partition_id"] == "F5_FINAL_FULL_DATA"
        assert f4._f4_native_component_inputs(entries)[-1] is True
        assert task["nested_full_final_source"]["full_score_result_sha256"] == result["identity_sha256"]

    # Same already-verified native bytes, copied only for these two retained
    # failure cases. The original scalar/pooling/copy owner is not substituted.
    # The native leaf reuses exact earlier handles after independent byte SHA
    # checks; an unstarted-family fit is forbidden even when a half is stale.
    import shutil
    half_failures = []
    for retained_name, missing_name in [("training-score.json", "execution.json"),
                                         ("execution.json", "training-score.json")]:
        failed = tmp_path / ("half-" + retained_name.removesuffix(".json"))
        failed.mkdir()
        shutil.copytree(root / "request", failed / "request")
        for prefix in ("components/score-native", "score-evidence", "components/score-evidence"):
            shutil.copytree(root / prefix / "COX_PH", failed / prefix / "COX_PH")
        missing_path = failed / "score-evidence/COX_PH" / missing_name
        missing_path.rename(tmp_path / (failed.name + "-preserved-" + missing_name))
        retained_path = failed / "score-evidence/COX_PH" / retained_name
        retained_path.write_bytes(retained_path.read_bytes() + b" ")
        def exact_prior_native_handles(worker, jobs, *, on_result, **kwargs):
            assert worker is f5._replay_component_job and len(jobs) == 300
            for index, job in enumerate(jobs):
                assert job["score_evidence"]["record"]["family"] == "COX_PH"
                handle = calls["handles"][job["source_sha256"]]
                assert f5.sha256_file(Path(job["source"])) == job["source_sha256"]
                assert f5.sha256_file(Path(job["root"]).with_suffix(".zip")) == handle["archive_sha256"]
                on_result(index, handle)
            return []
        with monkeypatch.context() as recovery:
            recovery.setattr(runtime, "_bounded_ordered_spawn", exact_prior_native_handles)
            with pytest.raises(ContractError, match="NESTED_FULL_SCORE_EVIDENCE_REPLAY_DRIFT"):
                f5._full_data_locked_score_program(*inputs, selector_root, roots, failed,
                    rscript="UNFITTED", replay=False, resume=True, resource_policy=policy, **budgets)
        assert not missing_path.exists() and retained_path.read_bytes().endswith(b" ")
        assert not (failed / "full-score-result.json").exists()
        half_failures.append(str(failed))
    assert calls["new_unfitted_objects"] == 2100 and calls["retained_object_reads"] == 4802
    assert len(calls["batches"]) == 495 and set(calls["batches"]) == {20}
    (tmp_path / "family-execution-observation.json").write_bytes(canonical_json_bytes({
        "new_actual_model_fits": 0, "new_mice_chains": 0, "unfitted_model_objects": 2100,
        "unfitted_native_reads": 4802, "complete_family_numbers_without_global_result": 300,
        "complete_family_numbers_before_missing_fits": 600, "whole_score_components": 2100,
        "retained_half_publication_failures": half_failures, "actual_test_pool_process_peak": 1,
        "configured_fixture_workers": 56, "final_lock_components": 20}))


@pytest.fixture
def unfitted_selector_consumers(monkeypatch):
    """Only the native recipe math and path search are stubs, never executed."""
    modes = []
    def recipe_native(args, **kwargs):
        spec = strict_json_bytes(Path(args[-1]).read_bytes())
        assert spec["action"] == "COMPILE_TRANSFORM_RECIPES" and spec["expected_count"] == 16
        values = []
        contract = f5.predictor_contract(Path(f5.__file__).parent)["representation_contract"]
        for projection in spec["projections"]:
            assert set(projection) == {"partition_id", "fit_ids_sha256", "analysis_view_sha256",
                                       "analysis_ids_sha256", "recipe_registry_record"}
            rows = []
            for row in projection["recipe_registry_record"]["registry"]["rows"]:
                representation = row["representation"]
                parameters = ({"identity": True} if representation == "IDENTITY" else
                              {"canonical_unit_scale": 1} if representation == "LOG1P" else
                              {"boundary_knots": [10.0, 90.0], "interior_knots": [50.0], "quantile_type": 7})
                rows.append({"parent": row["parent"], "canonical_unit": row["canonical_unit"],
                             "representation": representation, "design_df": contract[representation]["design_df"],
                             "design_columns": [row["parent"] + suffix for suffix in contract[representation]["column_suffixes"]],
                             "parameters": parameters})
            values.append({"partition_id": projection["partition_id"], "representations": rows,
                           "ordered_parent_column_map": [{"parent": row["parent"], "columns": row["design_columns"]}
                                                         for row in rows]})
        Path(spec["output_path"]).write_bytes(canonical_json_bytes({
            "schema_version": "1.0.0", "kind": "PADML_F2_R_RECIPE_VALUES", "status": "PASS",
            "recipe_count": 16, "recipes": values,
        }))
        return SimpleNamespace(returncode=0)

    def search(context, partitions, root, *, rscript, replay, workers, numerical=False,
               retained_full0_source_bundle=None):
        modes.append(replay)
        assert numerical is replay
        # A retained bundle is provenance for the original numerical reader;
        # it never converts this unfitted native-search stand-in into a writer.
        assert retained_full0_source_bundle is None or replay
        calls = f4._full_pipeline_selector_phase_calls(context, partitions, [0.2], root / "coarse", rscript=rscript)
        assert len(calls) == 320 and workers == 1
        for spec, part, task, directory, _ in calls:
            assert "evaluation_response" not in f4._learning_selector_native_spec(spec, part, task, Path(directory))["partition"]
            assert Path(part["evaluation_response"]["path"]).is_file()
            assert part["transform_recipe"]["partition_id"] == part["partition_id"]
        result = {"source": context["source"], "selector": {
            "alpha": 0.2, "selected_parents": ["AST_ALT", "Age"],
            "selected_ratio_by_imputation": [0.1] * 20, "lambda_by_imputation": [0.2] * 20,
            "lambda_upper_bound_by_imputation": [_unfitted_full_lambda_upper(partitions[-1]["transform_recipe"])] * 20,
            "status": "FEASIBLE", "outer_training_event_count": 70,
            "common_set_design_df": 3, "common_set_epv": 70 / 3,
            # This unfitted search stand-in keeps the same successful legacy
            # EPV15/12 prefix required of real pre-amendment producers.
            "epv_resolution": {"preferred_minimum": 15, "minimum": 15, "fallback_used": False,
                "coarse_records_sha256": sha256_bytes(canonical_json_bytes({"UNFITTED_SEARCH_STUB": True})),
                "attempts": [{"minimum": 15, "alpha_feasibility": [
                    {"alpha": alpha, "status": "FEASIBLE", "reason_code": "OK"}
                    for alpha in f5.load_science_authority()["science"]["f2_model_development"]
                        ["selector_contract"]["alpha_grid"]["coarse"]]}]},
        }, "selector_path_count": 320, "distinct_alpha_count": 1,
            "coarse_alpha_order": [0.2], "fine_alpha_order": [0.2],
            "candidate_records_sha256": sha256_bytes(b"UNFITTED-CANDIDATE-RECORDS"),
            "native_member_set_sha256": sha256_bytes(b"UNFITTED-NATIVE-MEMBERS")}
        raw = canonical_json_bytes(result)
        if replay:
            assert (root / "selector.json").read_bytes() == raw
        else:
            (root / "selector.json").write_bytes(raw)
            (root / "coarse").mkdir()
            (root / "coarse/paths.json").write_bytes(canonical_json_bytes({"UNFITTED_SEARCH_STUB": True}))
            (root / "native-members.json").write_bytes(canonical_json_bytes([]))
        return result, {"UNFITTED_SELECTED_ALPHA_RECORD": True}
    monkeypatch.setattr(f4.subprocess, "run", recipe_native)
    monkeypatch.setattr(f4, "_full_pipeline_selector_search", search)
    return modes


def test_full0_selector_consumer_and_replay_bind_all_recipes_and_mi_parameters(
    full_inputs, tmp_path, unfitted_selector_consumers,
):
    inputs = _physical_full_inputs(full_inputs, tmp_path / "inputs")
    root = tmp_path / "selector"
    result = f5._nested_full_selector_program(*inputs, root, rscript="UNFITTED_STUB", replay=False)
    inner_only = [{key: value for key, value in part.items() if key != "stopping"} for part in inputs[1]]
    replayed = f5._nested_full_selector_program(inputs[0], inner_only, inputs[2], root,
                                               rscript="UNFITTED_STUB", replay=True)
    assert result == replayed and unfitted_selector_consumers == [False, True]
    recipes = result["transform_recipes"]
    assert recipes["recipe_count"] == len(recipes["recipes"]) == 16
    assert recipes["recipes"][-1]["partition_id"] == "F5_FINAL_FULL_DATA"
    assert result["final_full_data_recipe_sha256"] == recipes["recipes"][-1]["recipe_sha256"]
    assert result["selector"]["lambda_by_imputation"] == [0.2] * 20
    assert result["selector"]["selected_ratio_by_imputation"] == [0.1] * 20
    assert result["final_model_fits"] == result["new_mice_chains"] == 0
    assert result["family_selection_performed"] is False
    assert result["identity_sha256"] == sha256_bytes(canonical_json_bytes({
        key: value for key, value in result.items() if key != "identity_sha256"
    }))


def test_full0_selector_shards_first_audit_complete_gather_and_direct_q_consumer(
    full_inputs, tmp_path, unfitted_selector_consumers, monkeypatch,
):
    inputs = _physical_full_inputs(full_inputs, tmp_path / "inputs")
    counts = _selector_shard_engines(monkeypatch, f4.subprocess.run)
    policy = {"configured_worker_ceiling": "EXECUTION_HOST_C_MINUS_8", "memory_bytes_per_worker": 1,
        "scratch_bytes_per_worker": 1, "memory_reserve_bytes": 0, "scratch_reserve_bytes": 0,
        "transfer_archive_worker_ceiling": 1000}
    def run(root, **kwargs):
        return f5._nested_full_selector_program(*inputs, root, rscript="UNFITTED",
            resource_policy=policy, **kwargs)
    result, transported = _exercise_selector_shards(run, tmp_path, policy, counts, monkeypatch=monkeypatch)
    task = f5.compile_nested_full_complex_search_task(*inputs, transported, family="RSF",
        rscript="FORBIDDEN", resource_policy=policy)
    assert task["selector_development_sha256"] == result["identity_sha256"]
    assert f5._validate_final_complex_search_task(task) == task
    assert counts["engine"] == counts["native"] == 640 and counts["forbid_native"]


@pytest.mark.parametrize("dimension,short", [("memory", False), ("memory", True), ("scratch", False), ("scratch", True)])
def test_selector_phase_whole_retention_admission_and_original_number_bindings(
    full_inputs, tmp_path, unfitted_selector_consumers, monkeypatch, dimension, short,
):
    from padml import runtime
    inputs = _physical_full_inputs(full_inputs, tmp_path / "inputs")
    counts = _selector_shard_engines(monkeypatch, f4.subprocess.run)
    context, parts = f5._nested_full_selector_inputs(*inputs)
    # The owner, not the R fitter, binds this training-only validation response.
    for index, part in enumerate(parts[:-1]):
        raw = part["evaluation_response"].pop("private_bytes")
        path = tmp_path / f"evaluation-{index:02d}.csv"
        path.write_bytes(raw)
        part["evaluation_response"]["path"] = str(path)
    parts = f4._compile_full_pipeline_selector_recipes(parts, tmp_path / "recipes", rscript="UNFITTED")
    owner = tmp_path / "selector"
    owner.mkdir()
    all_calls = f4._full_pipeline_selector_phase_calls(context, parts, [.2], owner / "coarse", rscript="UNFITTED")
    calls = [all_calls[0], all_calls[-20]]
    policy = {"configured_worker_ceiling": "EXECUTION_HOST_C_MINUS_8", "memory_bytes_per_worker": 1,
        "scratch_bytes_per_worker": 2, "memory_reserve_bytes": 0, "scratch_reserve_bytes": 0,
        "transfer_archive_worker_ceiling": 1000}
    retained = 32 * 1024**2
    effective = f4._selector_phase_resource_policy(policy, calls, retained)
    assert effective["scratch_reserve_bytes"] == 2 * retained + 64 * 1024**2
    effective = f4._selector_phase_resource_policy(policy, calls, retained,
        execution_worker_memory_bytes=2 * 1024**3, execution_scratch_reserve_bytes=0)
    observation = {"effective_cpus": 32, "available_memory_bytes": 64 * 1024**3,
        "scratch_available_bytes": 512 * 1024**3, "scratch_root": str(owner)}
    key = "available_memory_bytes" if dimension == "memory" else "scratch_available_bytes"
    observation[key] = effective[dimension + "_reserve_bytes"] + effective[dimension + "_bytes_per_worker"] - int(short)
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda root: {**observation, "scratch_root": str(root)})
    batch = tmp_path / "batch"
    if short:
        with pytest.raises(ContractError, match="RESOURCE_ADMISSION_ZERO"):
            f4._execute_full_pipeline_selector_phase_batch(calls, batch, resource_policy=policy,
                retained_bytes_per_task=retained)
        assert not batch.exists() and not (owner / "coarse").exists() and counts["engine"] == 0
        return
    result = f4._execute_full_pipeline_selector_phase_batch(calls, batch, resource_policy=policy,
        retained_bytes_per_task=retained)
    assert result["execution"]["pool"]["admitted_worker_ceiling"] == 1
    assert result["execution"]["pool"]["configured_worker_ceiling"] == 24
    assert counts["native"] == counts["engine"] == 2
    counts["forbid_native"] = True
    call = (*calls[0][:3], str(batch), calls[0][4])
    number_file = batch / call[2]["task_id"] / "path-result.json"
    raw = number_file.read_bytes()
    original = ORIGINAL_SELECTOR_CONSUME(call, numerical=True)
    path = original["sealed_elastic_paths"][0]
    assert path["fit_response_sha256"] == call[1]["fit_response"]["sha256"]
    assert path["evaluation_response_sha256"] == call[1]["evaluation_response"]["sha256"]
    assert path["validation_n"] == len(call[1]["evaluation_ids"]) and len(path["losses"]) == 150
    # Direct original reader: no outer file-SHA can mask these semantic checks.
    for damage in ("response", "validation_bool", "extra_key", "lambda", "patient_order", "spec_reference"):
        changed = copy.deepcopy(original)
        if damage == "response":
            changed["sealed_elastic_paths"][0]["evaluation_response_sha256"] = "a" * 64
        elif damage == "validation_bool":
            changed["sealed_elastic_paths"][0]["validation_n"] = True
        elif damage == "extra_key":
            changed["untrusted"] = True
        elif damage == "lambda":
            changed["sealed_elastic_paths"][0]["lambda_path"][10] *= 1.01
        elif damage == "patient_order":
            changed["evaluation_ids"].reverse()
        else:
            next(row for row in changed["native_members"] if row["name"] == "spec.json")["sha256"] = "b" * 64
        number_file.write_bytes(canonical_json_bytes(changed))
        try:
            with pytest.raises(ContractError):
                ORIGINAL_SELECTOR_CONSUME(call, numerical=True)
        finally:
            number_file.write_bytes(raw)
    assert ORIGINAL_SELECTOR_CONSUME(call, numerical=True) == original


@pytest.mark.parametrize("failure", ["coordinate_batch_root", "fine_batch_root", "engine_exit", "first_native_audit"])
def test_selector_phase_fixed_owner_and_failed_native_evidence(
    full_inputs, tmp_path, unfitted_selector_consumers, monkeypatch, failure,
):
    inputs = _physical_full_inputs(full_inputs, tmp_path / "inputs")
    counts = _selector_shard_engines(monkeypatch, f4.subprocess.run)
    context, parts = f5._nested_full_selector_inputs(*inputs)
    parts = f4._compile_full_pipeline_selector_recipes(parts, tmp_path / "recipes", rscript="UNFITTED")
    owner = tmp_path / "selector"
    owner.mkdir()
    # Full training task needs no validation response materialization.
    call = f4._full_pipeline_selector_phase_calls(context, parts, [.2], owner / "coarse", rscript="UNFITTED")[-20]
    policy = {"configured_worker_ceiling": "EXECUTION_HOST_C_MINUS_8", "memory_bytes_per_worker": 1,
        "scratch_bytes_per_worker": 1, "memory_reserve_bytes": 0, "scratch_reserve_bytes": 0,
        "transfer_archive_worker_ceiling": 1000}
    if failure.endswith("batch_root"):
        batch = owner / (call[2]["task_id"] if failure == "coordinate_batch_root" else "fine")
        with pytest.raises(ContractError, match="NESTED_SELECTOR_PHASE_BATCH_ALREADY_STARTED"):
            f4._execute_full_pipeline_selector_phase_batch([call], batch, resource_policy=policy,
                retained_bytes_per_task=32 * 1024**2)
        assert not batch.exists() and not (owner / "coarse").exists() and counts["engine"] == 0
        return
    batch = tmp_path / "failed-batch"
    if failure == "engine_exit":
        engine = f4.subprocess.run
        def failed_engine(args, **kwargs):
            engine(args, **kwargs)
            kwargs["stderr"].write(b"UNFITTED_ENGINE_FAILURE\n")
            return SimpleNamespace(returncode=17)
        monkeypatch.setattr(f4.subprocess, "run", failed_engine)
    else:
        def rejected(*args, **kwargs):
            raise ContractError("UNFITTED_FIRST_NATIVE_AUDIT_FAILURE")
        monkeypatch.setattr(f4, "_consume_learning_selector_path", rejected)
    with pytest.raises(ContractError):
        f4._execute_full_pipeline_selector_phase_batch([call], batch, resource_policy=policy,
            retained_bytes_per_task=32 * 1024**2)
    execution = strict_json_bytes((batch / "execution.json").read_bytes())
    assert execution["pool"]["status"] == "FAILED" and execution["pool"]["completed_task_count"] == 0
    native = owner / "coarse" / call[2]["task_id"] / "native"
    assert (native / "spec.json").is_file() and (native / "output.json").is_file()
    assert not (batch / "path-results.json").exists() and not (native.parent / "path-result.json").exists()
    assert counts["engine"] == 1
    with pytest.raises(ContractError, match="NESTED_SELECTOR_COORDINATE_ALREADY_STARTED"):
        f4._execute_full_pipeline_selector_phase_batch([call], tmp_path / "renamed-failed-report",
            resource_policy=policy, retained_bytes_per_task=32 * 1024**2)
    assert counts["engine"] == 1


def test_full0_selector_numbers_use_original_math_without_native_fallback(
    full_inputs, tmp_path, unfitted_selector_consumers, monkeypatch,
):
    """Original phase, reduction, recipes and reader; only native fits are UNFITTED."""
    import shutil
    from padml import f2_kernel
    inputs = _physical_full_inputs(full_inputs, tmp_path / "inputs")
    root, transported = tmp_path / "owner-selector", tmp_path / "numerical-selector"
    calls = []
    def produce(arguments):
        spec, part, task, directory, _ = arguments
        _write_unfitted_selector_native(arguments)
        calls.append((part["partition_id"], task["imputation"], task["alphas"]))
        return _unfitted_selector_path_values(spec, part, task)
    monkeypatch.setattr(f4, "_full_pipeline_selector_search", ORIGINAL_SELECTOR_SEARCH)
    monkeypatch.setattr(f4, "_run_learning_selector_path", produce)
    first = f5._nested_full_selector_program(*inputs, root, rscript="UNFITTED", replay=False)
    assert first["selector"]["selected_parents"] == ["AST_ALT", "Age"]
    assert first["selector"]["selected_ratio_by_imputation"][0] != first["selector"]["selected_ratio_by_imputation"][1]
    assert first["selector"]["common_set_design_df"] == 3
    assert len(calls) == 640 and first["selector_path_count"] <= 4800
    for name, path in f5._nested_selector_numerical_members(root).items():
        destination = transported / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, destination)
    assert not list(transported.rglob("*.bin")) and not list(transported.rglob("output.json"))
    assert len(list(transported.rglob("spec.json"))) == 640
    def forbidden(*args, **kwargs):
        raise AssertionError("NUMERICAL_SELECTOR_MUST_NOT_REPLAY_OR_REFIT_NATIVE")
    monkeypatch.setattr(f4, "_run_learning_selector_path", forbidden)
    monkeypatch.setattr(f4, "_consume_learning_selector_path", forbidden)
    monkeypatch.setattr(f4.subprocess, "run", forbidden)
    assert f5._nested_full_selector_program(*inputs, transported, rscript="FORBIDDEN", replay=True) == first
    # Independently consume the saved full candidates through the original
    # scientific reducer: per-MI feasible lambda and common SetA remain exact.
    coarse = strict_json_bytes((transported / "coarse/paths.json").read_bytes())
    selector = strict_json_bytes((transported / "selector.json").read_bytes())
    records = {row["alpha"]: row for row in coarse}
    records.update({row["alpha"]: row for row in strict_json_bytes((transported / "fine/paths.json").read_bytes())})
    contract = f4.load_science_authority()["science"]["f2_model_development"]["selector_contract"]
    chosen, _ = f2_kernel._choose_elastic_alpha([records[alpha] for alpha in selector["fine_alpha_order"]],
                                              selector["fine_alpha_order"], contract)
    assert chosen == first["selector"]
    actual = coarse[0]["lambda_paths"][0][0]
    expected = [coarse[0]["partition_losses"][0]["mi_lambda_path_health"][0]["lambda_max"] * ratio
                for ratio in f2_kernel._elastic_ratios(contract)]
    assert actual[10] != expected[10]
    for damage in ("missing_mi", "loss", "coefficient", "rehashed_coefficient", "lambda_path", "lambda_tolerance", "penalty",
                   "denominator", "event", "source", "native_coordinate", "native_size", "native_output",
                   "spec_seed", "spec_member", "recipe", "patient"):
        name = {"source": "selector.json", "native_coordinate": "native-members.json",
                "native_size": "native-members.json", "native_output": "native-members.json",
                "spec_seed": "coarse/R0_K0_M01/native/spec.json", "spec_member": "coarse/R0_K0_M01/native/spec.json",
                "recipe": "recipes/native-values.json",
                "patient": "partitions.json"}.get(damage, "coarse/paths.json")
        path = transported / name
        original = path.read_bytes()
        value = strict_json_bytes(original)
        if damage == "missing_mi":
            value[0]["outer_paths"].pop()
        elif damage == "loss":
            value[0]["partition_losses"][0]["mi_losses"][0].pop()
        elif damage in {"coefficient", "rehashed_coefficient"}:
            item = value[0]["outer_paths"][0]
            item["parent_coefficients"]["Age"][149][0] = .5  # not the chosen lambda
            if damage == "rehashed_coefficient":
                item["coefficient_path_sha256"] = sha256_bytes(canonical_json_bytes({
                    "parent_design_columns": item["parent_design_columns"], "parent_coefficients": item["parent_coefficients"]}))
        elif damage == "lambda_path":
            value[0]["partition_losses"][0]["mi_lambda_path_health"][0]["lambda_path_sha256"] = "b" * 64
        elif damage == "lambda_tolerance":
            value[0]["lambda_paths"][0][0][10] *= 1.000001
            value[0]["partition_losses"][0]["mi_lambda_path_health"][0]["lambda_path_sha256"] = sha256_bytes(
                canonical_json_bytes(value[0]["lambda_paths"][0][0]))
        elif damage == "penalty":
            value[0]["outer_paths"][0]["lambda_upper_bound"]["penalty_factor_identity_sha256"] = "b" * 64
        elif damage == "denominator":
            value[0]["partition_losses"][0]["validation_n"] += 1
        elif damage == "event":
            value[0]["outer_paths"][0]["event_count"] += 1
        elif damage == "source":
            value["source"]["context"] = 1
        elif damage == "native_coordinate":
            prefix = value[0]["name"].rsplit("/", 1)[0]
            value = [row for row in value if row["name"].rsplit("/", 1)[0] != prefix]
        elif damage == "native_size":
            value[0]["size_bytes"] = True
        elif damage == "native_output":
            value = [row for row in value if row["name"] != "coarse/R0_K0_M01/native/output.json"]
        elif damage == "spec_seed":
            value["task"]["seed"] += 1
        elif damage == "spec_member":
            value["partition"]["covariates"]["members"][0]["sha256"] = "b" * 64
        elif damage == "recipe":
            row = next(row for row in value["recipes"][0]["representations"] if "boundary_knots" in row["parameters"])
            row["parameters"]["interior_knots"] = [row["parameters"]["boundary_knots"][1]]
        else:
            value[0]["fit_ids"].reverse()
        path.write_bytes(canonical_json_bytes(value))
        try:
            with pytest.raises(ContractError):
                f5._nested_full_selector_program(*inputs, transported, rscript="FORBIDDEN", replay=True)
        finally:
            path.write_bytes(original)
    missing = transported / "fine/paths.json"
    missing.rename(transported / "fine/missing-paths.json")
    with pytest.raises((ContractError, FileNotFoundError)):
        f5._nested_full_selector_program(*inputs, transported, rscript="FORBIDDEN", replay=True)
    assert len(calls) == 640 and list(root.rglob("*.bin"))


def test_nested_selector_first_native_reader_retains_actual_lambda_after_original_audit(
    full_inputs, tmp_path, unfitted_selector_consumers,
):
    """Actual original JSON/coefficient consumer; no R/path/model fitting."""
    from padml import f2_kernel
    inputs = _physical_full_inputs(full_inputs, tmp_path / "inputs")
    context, parts = f5._nested_full_selector_inputs(*inputs)
    parts = f4._compile_full_pipeline_selector_recipes(parts, tmp_path / "recipes", rscript="UNFITTED")
    directory = tmp_path / "phase"
    calls = f4._full_pipeline_selector_phase_calls(context, parts, [.2], directory, rscript="FORBIDDEN")
    call = calls[-20]  # one full0 training M1, no evaluation loss or native binary channel
    spec, part, task, _, _ = call
    native = _write_unfitted_selector_native(call)
    numbers = _unfitted_selector_path_values(spec, part, task)
    columns = f2_kernel._expected_family_parent_column_map(task["selected_parents"], "ELASTIC_NET_COX",
        spec["predictors"], task["transform_recipe"])
    output = {"schema_version": "1.0.0", "kind": "PADML_F2_R_PREDICTION_BATCH", "status": "PASS", "task_count": 1,
        "tasks": [{"task_id": task["task_id"], "partition_id": part["partition_id"], "imputation": task["imputation"],
            "fit_ids": part["fit_ids"], "evaluation_ids": part["evaluation_ids"],
            "transform_recipe_sha256": task["transform_recipe"]["recipe_sha256"],
            "ordered_parent_column_map": columns, "elastic_paths": {"alphas": numbers["sealed_elastic_paths"]}}]}
    path = native / "output.json"
    path.write_bytes(canonical_json_bytes(output))
    first = f4._consume_learning_selector_path(call)
    observed = first["sealed_elastic_paths"][0]
    assert observed["lambda_path"] == output["tasks"][0]["elastic_paths"]["alphas"][0]["lambda_path"]
    assert observed["lambda_path_sha256"] == sha256_bytes(canonical_json_bytes(observed["lambda_path"]))
    assert observed["lambda_path"][10] != observed["lambda_max"] * task["ratios"][10]
    output["tasks"][0]["elastic_paths"]["alphas"][0]["lambda_path"][10] *= 1.000001
    path.write_bytes(canonical_json_bytes(output))
    with pytest.raises(ContractError, match="F2_ELASTIC_PENALIZED_ENTRY_FRONTIER_INVALID"):
        f4._consume_learning_selector_path(call)
    assert path.is_file() and not list(native.parent.glob("consume-*"))


@pytest.mark.parametrize("damage", ["full_recipe", "recipe_bytes", "retained_lambda"])
def test_full0_selector_replay_rejects_recipe_or_lambda_drift(
    full_inputs, tmp_path, unfitted_selector_consumers, damage,
):
    inputs = _physical_full_inputs(full_inputs, tmp_path / "inputs")
    root = tmp_path / "selector"
    f5._nested_full_selector_program(*inputs, root, rscript="UNFITTED_STUB", replay=False)
    if damage == "full_recipe":
        path = root / "partitions.json"
        value = strict_json_bytes(path.read_bytes())
        value[-1]["transform_recipe"]["recipe_sha256"] = "0" * 64
    elif damage == "retained_lambda":
        path = root / "development-input.json"
        value = strict_json_bytes(path.read_bytes())
        value["selector"]["lambda_by_imputation"][0] = 0.9
        value["identity_sha256"] = sha256_bytes(canonical_json_bytes({
            key: row for key, row in value.items() if key != "identity_sha256"
        }))
    else:
        path = root / "recipes" / "recipes.json"
        value = []
    path.write_bytes(canonical_json_bytes(value))
    with pytest.raises(ContractError, match="NESTED_FULL_SELECTOR_.*REPLAY_MISMATCH"):
        f5._nested_full_selector_program(*inputs, root, rscript="UNFITTED_STUB", replay=True)


@pytest.mark.parametrize("family", ["RSF", "GBM_COX", "XGBOOST_COX", "COXTIME_SET_A"])
def test_full0_complex_search_consumes_fresh_selector_not_global_family_lock(
    full_inputs, tmp_path, unfitted_selector_consumers, family,
):
    plan, parts, final = _physical_full_inputs(full_inputs, tmp_path / "inputs")
    development = f5._nested_full_selector_program(plan, parts, final, tmp_path / "selector", rscript="UNFITTED", replay=False)
    task = f5.compile_nested_full_complex_search_task(plan, parts, final, tmp_path / "selector", family=family, rscript="UNFITTED")
    assert f5._validate_final_complex_search_task(task) == task
    assert task["kind"] == "PADML_NESTED_FULL_DATA_COMPLEX_SEARCH_TASK_V1"
    assert task["selector_development_sha256"] == development["identity_sha256"]
    assert task["selector_recipe_set_sha256"] == development["transform_recipes"]["recipe_set_sha256"]
    assert not {"family_decision_sha256", "f4_locked_family_handoff_sha256", "final_seta_lock_sha256"}.intersection(task)
    assert len(task["search_partition_bindings"]) == 15
    assert all((row["stopping_identity_sha256"] == sha256_bytes(canonical_json_bytes(None))) == (family == "RSF")
               for row in task["search_partition_bindings"])
    before = copy.deepcopy(parts)
    registered = f5._complex_runtime_registered_inputs(task, parts)
    assert registered["inner_count"] == 15
    assert (registered["stop_count"], registered["view_count"]) == ((0, 15) if family == "RSF" else (15, 30))
    assert parts == before
    if family == "RSF":
        from padml.f2_kernel import _engine_registered_partitions
        projected = _engine_registered_partitions(registered, {parts[0]["partition_id"]})
        assert projected["stop_count"] == 0 and projected["view_count"] == 15
        assert projected["projected_partition_count"] == 1
        assert all(row["kind"] == "INNER" for row in projected["partitions"])
    spec = f5._complex_search_execution_spec(task, registered)
    assert spec["final_search_source"]["selector_development_sha256"] == development["identity_sha256"]
    assert spec["selector_from_dependency"]["selected_parents"] == ["AST_ALT", "Age"]
    assert spec["execution_scope"] == "F5_FULL_DEVELOPMENT_SEARCH"  # original numerical owner
    assert spec["seed"] == 300000 and spec["fold"] == 0 and spec["engine_threads"] == 1
    assert task["candidate_trials"] == f5._final_complex_candidate_trials(family)
    assert task["stage_seed_offsets"] == {"S1": 10000, "S2": 20000, "S3A": 30000, "S3B1": 40000, "S3B2": 50000}
    assert task["final_model_fit_count"] == task["heldout_or_ooc_read_count"] == 0
    legacy_plan = {**plan, "execution_profile": {**plan["execution_profile"], "pool_workers": 3}}
    old = f5._compile_full_complex_search_task_body(legacy_plan, family, task["selected_parents"], task["search_partition_bindings"], {
        "family_decision_sha256": "a" * 64, "f4_locked_family_handoff_sha256": "b" * 64, "final_seta_lock_sha256": "c" * 64,
    })
    assert f5._validate_final_complex_search_task(old) == old
    for key in ("candidate_trials", "candidate_sequence", "search_space", "search_budget", "multifidelity",
                "trial_scoring", "coxtime", "model_seed_base", "stage_seed_offsets", "selected_design"):
        assert task[key] == old[key]


@pytest.mark.parametrize("family", ["RSF", "GBM_COX", "XGBOOST_COX", "COXTIME_SET_A"])
def test_full0_twelve_month_q_binds_decision_without_changing_fit_coordinates(
    full_inputs, tmp_path, unfitted_selector_consumers, family,
):
    from padml import nested_loco as nested
    plan, parts, final = _physical_full_inputs(full_inputs, tmp_path / "inputs")
    selector = tmp_path / "selector"
    f5._nested_full_selector_program(plan, parts, final, selector, rscript="UNFITTED", replay=False)
    old = f5.compile_nested_full_complex_search_task(plan, parts, final, selector, family=family, rscript="UNFITTED")
    decision = _unfitted_confirmed_decision(fixed_bootstrap=True)
    decision = nested._sealed({**{k: v for k, v in decision.items() if k != "identity_sha256"},
                              "twelve_month_development": nested._twelve_month_development_contract()})
    task = f5.compile_nested_full_complex_search_task(plan, parts, final, selector, family=family,
        rscript="UNFITTED", selection_horizon_months=12, science_decision=decision)
    assert f5._validate_final_complex_search_task(task) == task
    assert task["science_decision"] == decision and task["selection_horizon_months"] == 12
    assert task["trial_scoring"]["ibs_grid_months"] == list(range(13))
    assert task["trial_scoring"]["ibs_integration"] == "TRAPEZOID_DIVIDE_BY_12"
    changed = {"task_sha256", "trial_scoring", "selection_horizon_months", "science_decision"}
    assert {k: v for k, v in task.items() if k not in changed} == {k: v for k, v in old.items() if k not in changed}
    registered = f5._complex_runtime_registered_inputs(task, parts)
    assert registered == f5._complex_runtime_registered_inputs(old, parts)
    spec = f5._complex_search_execution_spec(task, registered)
    assert spec["selection_horizon_months"] == 12 and spec["trial_scoring"] == task["trial_scoring"]
    assert spec["final_search_source"]["science_decision_sha256"] == decision["identity_sha256"]
    assert spec["final_search_source"]["selection_horizon_months"] == 12
    assert spec["monthly_fit_horizons"] == list(range(1, 37))
    assert spec["seed"] == 300000 and spec["engine_threads"] == 1
    assert "selection_horizon_months" not in f5._complex_search_execution_spec(old, registered)
    for supplied in (None, _unfitted_confirmed_decision(fixed_bootstrap=True)):
        with pytest.raises(ContractError):
            f5.compile_nested_full_complex_search_task(plan, parts, final, selector, family=family,
                rscript="UNFITTED", selection_horizon_months=12, science_decision=supplied)
    damaged = {**task, "trial_scoring": old["trial_scoring"]}
    damaged["task_sha256"] = sha256_bytes(canonical_json_bytes({k: v for k, v in damaged.items() if k != "task_sha256"}))
    with pytest.raises(ContractError, match="F5_COMPLEX_SEARCH_TASK_INVALID"):
        f5._validate_final_complex_search_task(damaged)


def test_full0_twelve_month_lineage_rejects_an_unmigrated_consumer(tmp_path):
    from padml import nested_loco as nested
    old = _unfitted_confirmed_decision(fixed_bootstrap=True)
    science = nested._sealed({**{k: v for k, v in old.items() if k != "identity_sha256"},
                             "twelve_month_development": nested._twelve_month_development_contract()})
    source = tmp_path / "full-development.json"
    value = {"selection_horizon_months": 12, "science_decision": science}
    source.write_bytes(canonical_json_bytes(value))
    with pytest.raises(ContractError, match="F5_FINAL_LINEAGE_SELECTION_HORIZON_MISMATCH"):
        f5._read_final_lineage(source)
    assert f5._read_final_lineage(source, selection_horizon_months=12) == value
    value["science_decision"] = old
    source.write_bytes(canonical_json_bytes(value))
    with pytest.raises(ContractError, match="F5_FULL_DEVELOPMENT_SELECTION_HORIZON_NOT_AUTHORIZED"):
        f5._read_final_lineage(source, selection_horizon_months=12)


def test_full0_complex_search_program_uses_existing_replay_owner(
    full_inputs, tmp_path, unfitted_selector_consumers, monkeypatch,
):
    plan, parts, final = _physical_full_inputs(full_inputs, tmp_path / "inputs")
    development = f5._nested_full_selector_program(plan, parts, final, tmp_path / "selector", rscript="UNFITTED", replay=False)
    task = f5.compile_nested_full_complex_search_task(plan, parts, final, tmp_path / "selector", family="RSF", rscript="UNFITTED")
    lifecycle = {}
    unchanged = f5.compile_nested_full_complex_search_task(plan, parts, final, tmp_path / "selector",
        family="RSF", rscript="UNFITTED", q_input_lifecycle=lifecycle)
    assert unchanged == task and set(lifecycle) == {"selector_program"}
    selector_inputs = Path(lifecycle["selector_program"]["temporary_root"])
    assert selector_inputs.parent == tmp_path and selector_inputs.name.startswith("nested-full-selector-replay-")
    assert {p.relative_to(selector_inputs).as_posix() for p in selector_inputs.rglob("*") if p.is_file()} == {
        f"validation-responses/inner-{index:02d}.csv" for index in range(1, 16)}
    modes, failure = [], None
    def unfitted_native(spec, registered, scratch):
        modes.append("NUMBERS" if spec.get("native_search_numbers") else spec["native_search_replay"])
        assert spec["final_search_source"]["selector_development_sha256"] == development["identity_sha256"]
        assert spec["pool_workers"] == spec["engine_threads"] == 1
        assert registered["stop_count"] == 0
        native = Path(spec["native_search_root"]) / "UNFITTED-model.rds"
        if not spec["native_search_replay"]:
            native.write_bytes(b"UNFITTED_NATIVE_OWNER")
        elif not spec.get("native_search_numbers"):
            assert native.read_bytes() == b"UNFITTED_NATIVE_OWNER"
            if failure == "native-audit":
                raise ContractError("UNFITTED_NATIVE_AUDIT_FAILURE")
        return {"UNFITTED_NATIVE_SEARCH": True, "execution_scope": spec["execution_scope"], "family": "RSF",
                "registered_inputs_identity_sha256": registered["identity"]}
    monkeypatch.setattr(f5, "_run_final_complex_search", unfitted_native)
    monkeypatch.setattr(f5, "resolve_pool_workers", lambda workers: 1 if workers is None else workers)
    result = f5._final_complex_search_program(task, parts, tmp_path / "q", replay=False, workers=1)
    replayed = f5._final_complex_search_program(task, parts, tmp_path / "q", replay=True, workers=1)
    assert result == replayed and modes == [False, True, "NUMBERS"]
    for failure in ("native-audit", "publication"):
        root = tmp_path / ("q-" + failure)
        original_open = Path.open
        def interrupted_publication(path, *args, **kwargs):
            if path == root / "numbers.json":
                raise OSError("UNFITTED_PUBLICATION_INTERRUPTION")
            return original_open(path, *args, **kwargs)
        with monkeypatch.context() as interrupted:
            if failure == "publication":
                interrupted.setattr(Path, "open", interrupted_publication)
            with pytest.raises((ContractError, OSError), match="UNFITTED_.*(?:FAILURE|INTERRUPTION)"):
                f5._final_complex_search_program(task, parts, root, replay=False, workers=1)
        assert modes[-2:] == [False, True]
        assert (root / "native/UNFITTED-model.rds").read_bytes() == b"UNFITTED_NATIVE_OWNER"
        assert (root / "input.json").is_file() and (root / "result.json").is_file()
        assert not (root / "numbers.json").exists()
        if failure == "publication":
            assert (root / "native/object-audit.json").is_file()
        before = list(modes)
        with pytest.raises(ContractError, match="F5_Q_SEARCH_PATH_INVALID"):
            f5._final_complex_search_program(task, parts, root, replay=False, workers=1)
        assert modes == before


@pytest.mark.parametrize("cpus", [32, 64, 128])
def test_full0_task_cpu_ceiling_resolves_on_executor_not_compiler(
    full_inputs, tmp_path, unfitted_selector_consumers, monkeypatch, cpus,
):
    plan, parts, final = _physical_full_inputs(full_inputs, tmp_path / "inputs")
    f5._nested_full_selector_program(plan, parts, final, tmp_path / "selector", rscript="UNFITTED", replay=False)
    task = f5.compile_nested_full_complex_search_task(plan, parts, final, tmp_path / "selector",
                                                    family="RSF", rscript="UNFITTED")
    assert plan["execution_profile"]["pool_workers"] == task["execution_profile"]["pool_workers"] == "EXECUTION_HOST_C_MINUS_8"
    frozen = canonical_json_bytes(task)
    monkeypatch.setattr("padml.runtime.effective_cpu_count", lambda: cpus)
    spec = f5._complex_search_execution_spec(task, f5._complex_runtime_registered_inputs(task, parts))
    assert spec["threads"] == spec["pool_workers"] == cpus - 8
    assert spec["engine_threads"] == 1 and canonical_json_bytes(task) == frozen


@pytest.mark.parametrize("family", ["RSF", "GBM_COX", "XGBOOST_COX", "COXTIME_SET_A"])
@pytest.mark.parametrize("selection_horizon_months", [24, 12])
def test_full0_public_complex_archive_reopens_full_selector_and_original_q(
    full_inputs, tmp_path, unfitted_selector_consumers, monkeypatch, family, selection_horizon_months,
):
    """Actual F5 archive/task/reduction readers; MICE and native Q are UNFITTED stubs."""
    from padml import nested_loco as nested, runtime
    from padml.bundle import read_safe_zip, write_deterministic_zip

    line = {"selection_horizon_months": 12} if selection_horizon_months == 12 else {}
    inputs = _physical_full_inputs(full_inputs, tmp_path / "physical")
    plan, parts, final = inputs
    selector = tmp_path / "selector"
    f5._nested_full_selector_program(*inputs, selector, rscript="UNFITTED", replay=False)
    mice = tmp_path / "mice"
    mice.mkdir()
    (mice / "UNFITTED.zip").write_bytes(b"UNFITTED_MICE_NATIVE_READER_BOUNDARY")
    full_path = tmp_path / "UNFITTED-full.zip"
    full_path.write_bytes(b"UNFITTED_FULL_MICE_NATIVE_READER_BOUNDARY")
    response = Path(final["fit_response"]["path"]).read_bytes()
    reads, modes = [], []
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda path: {
        "effective_cpus": 16, "available_memory_bytes": 10**9,
        "scratch_available_bytes": 10**9, "scratch_root": str(path)})
    monkeypatch.setattr(f5, "resolve_pool_workers", lambda workers: 1 if workers is None else workers)
    monkeypatch.setattr(f5, "_locked_f5_family", lambda *args: pytest.fail("OLD_GLOBAL_FAMILY_FORBIDDEN"))
    mice_scope = {"include_stop": False} if family == "RSF" else {}
    def mice_members(plan_value, root, **kwargs):
        assert kwargs == mice_scope
        return {"UNFITTED.zip": root / "UNFITTED.zip"}
    monkeypatch.setattr(f5, "_final_search_mice_members", mice_members)

    def cohort(plan_value, members, response_value, **kwargs):
        assert kwargs == mice_scope
        assert plan_value == plan and response_value == response
        assert members["UNFITTED.zip"].read_bytes() == b"UNFITTED_MICE_NATIVE_READER_BOUNDARY"
        return final["development_input"]

    def materialize_search(plan_value, root, response_value, destination, *, retain_evidence=False, **kwargs):
        assert plan_value == plan and response_value == response
        assert retain_evidence is False and kwargs == mice_scope
        reads.append("INNER_STOP_UNFITTED_READER")
        return ([{key: value for key, value in part.items() if key != "stopping"} for part in parts]
                if family == "RSF" else parts)

    def materialize_full(plan_value, source, response_value, destination, **kwargs):
        assert plan_value == plan and response_value == response
        assert source.read_bytes() == b"UNFITTED_FULL_MICE_NATIVE_READER_BOUNDARY"
        reads.append("FULL_UNFITTED_READER")
        return final

    monkeypatch.setattr(f5, "_validate_final_search_plan", cohort)
    monkeypatch.setattr(f5, "_materialize_final_search_inputs", materialize_search)
    monkeypatch.setattr(f5, "materialize_final_full_data_mice", materialize_full)

    @contextmanager
    def admitted_sources(path, scratch_parent, **kwargs):
        # This test keeps its pre-existing UNFITTED MICE boundary. Raw F1 and
        # read-before-allocation checks are exercised by full0 entry tests.
        actual = strict_json_bytes(path.read_bytes())
        assert scratch_parent == path.parent
        assert kwargs == {**({"selector_only": True} if family == "RSF" else {}), **line}
        bound = cohort(actual["plan"], {"UNFITTED.zip": mice / "UNFITTED.zip"}, response, **mice_scope)
        projected = materialize_search(actual["plan"], mice, response, tmp_path / "UNFITTED-inner", **mice_scope)
        whole = f5.materialize_final_full_data_mice(actual["plan"], full_path, response, tmp_path / "UNFITTED-whole")
        if whole["development_input"] != bound:
            raise ContractError("F5_Q_DEVELOPMENT_SOURCE_MISMATCH")
        yield actual, projected, whole

    monkeypatch.setattr(f5, "_materialized_full_data_development_sources", admitted_sources)

    def native(spec, registered, scratch):
        """Synthetic score vectors follow real candidates and promotion arithmetic, not real fits."""
        root = Path(spec["native_search_root"])
        task = strict_json_bytes((root.parent / "input.json").read_bytes())["task"]
        assert task["kind"] == "PADML_NESTED_FULL_DATA_COMPLEX_SEARCH_TASK_V1"
        assert spec.get("selection_horizon_months", 24) == selection_horizon_months
        modes.append("NUMBERS" if spec.get("native_search_numbers") else spec["native_search_replay"])
        marker, raw = root / "UNFITTED-native.json", canonical_json_bytes(spec["final_search_source"])
        if spec["native_search_replay"]:
            assert marker.read_bytes() == raw
        else:
            marker.write_bytes(raw)

        # Storage-only leaves: real archive/native readers must preserve every
        # byte. Raw risk arrays keep outer compression; these are not models.
        binary_name = "UNFITTED-model.rds" if family in {"RSF", "GBM_COX"} else "model.bin"
        for name in (binary_name, "UNFITTED-risk.bin"):
            data = ("UNFITTED_STORAGE_ONLY:" + name).encode() * 100
            if spec.get("native_search_numbers") and name == binary_name:
                continue
            if spec["native_search_replay"]:
                assert (root / name).read_bytes() == data
            else:
                (root / name).write_bytes(data)

        def evaluated(stage, rows):
            units, folds, repeats = {"S1": (5, 5, 1), "S2": (25, 5, 1), "S3A": (100, 5, 1),
                                    "S3B1": (75, 15, 3), "S3B2": (300, 15, 3)}[stage]
            return [{**row, **line, "stage_id": stage, "metric_values": [0.1 + index / 1000] * units,
                     "fold_metric_values": [0.1 + index / 1000] * folds,
                     "ranking_metric_values": [0.1 + index / 1000] * repeats,
                     "ranking_metric_qc": [{} for _ in range(repeats)], "ranking_evaluation_count": repeats,
                     "mean_ibs": 0.1 + index / 1000, "maximum_ibs": 0.1 + index / 1000, "evaluation_units": units,
                     **({"selected_trees_median": 100} if family == "GBM_COX" else
                        {"selected_rounds_median": 20} if family == "XGBOOST_COX" else
                        {"locked_epoch": 50} if family == "COXTIME_SET_A" else {})} for index, row in enumerate(rows)]

        def candidates(stage):
            return [{"candidate_id": row["candidate_id"] if family == "COXTIME_SET_A" else row["trial_id"],
                     "parameters": row if family == "COXTIME_SET_A" else row["parameters"],
                     "parameter_sha256": nested._sha(row) if family == "COXTIME_SET_A" else row["parameter_sha256"]}
                    for row in task["candidate_trials"][stage]]

        trace = {"S1": evaluated("S1", candidates("S1"))}
        trace["S2"] = evaluated("S2", f5._rank_trials(trace["S1"], retain=4)[:4]
                                if family == "COXTIME_SET_A" else candidates("S2"))
        for stage, previous, keep in (("S3A", "S2", 2 if family == "COXTIME_SET_A" else 3),
                                      ("S3B1", "S3A", 2), ("S3B2", "S3B1", 1)):
            trace[stage] = evaluated(stage, f5._rank_trials(trace[previous], retain=keep)[:keep])
        winner = trace["S3B2"][0]
        selected = {"family": family, "candidate_id": winner["candidate_id"], "parameters": winner["parameters"],
                    "selection_metric": f"IBS_0_{selection_horizon_months}", "selection_stage": "S3B2",
                    **({"selected_trees": 100} if family == "GBM_COX" else
                       {"selected_rounds": 20} if family == "XGBOOST_COX" else
                       {"locked_epoch": 50} if family == "COXTIME_SET_A" else {})}
        count = {"RSF": 1070, "GBM_COX": 1140, "XGBOOST_COX": 1300, "COXTIME_SET_A": 810}[family]
        stops = 0 if family == "RSF" else count
        return nested._sealed({"schema_version": "1.0.0", "kind": "PADML_SHARED_FULL_DEVELOPMENT_SEARCH_RESULT",
            "status": "PASS", "execution_scope": "F5_FULL_DEVELOPMENT_SEARCH", "family": family,
            "registered_inputs_identity_sha256": registered["identity"],
            "candidate_trials_sha256": task["candidate_trials_sha256"], "selected_parents": task["selected_parents"],
            "selected_spec": selected, "selected_spec_sha256": nested._sha(selected),
            "search_trace": trace, "search_trace_sha256": nested._sha(trace),
            "search_evaluation_unit_count": count, "response_free_stopping_fit_count": stops,
            "locked_training_refit_count": count, "total_search_fit_count": count + stops,
            "seed_base": task["model_seed_base"], "stage_seed_offsets": task["stage_seed_offsets"],
            "heldout_or_ooc_read_count": 0, "outer_parameter_reuse": False, "final_model_fit_count": 0})

    monkeypatch.setattr(f5, "_run_final_complex_search", native)
    sources = {**line, "plan": plan, "mice_root": str(mice), "final_mice_path": str(full_path),
               "response_path": final["fit_response"]["path"], "selector_root": str(selector),
               "search_roots": {name: str(tmp_path / "search" / name) for name in
                   ("RSF", "GBM_COX", "XGBOOST_COX", "COXTIME_SET_A")},
               "science_decision": _unfitted_confirmed_decision(fixed_bootstrap=True), "rscript": "UNFITTED",
               "resource_policy": {"configured_worker_ceiling": "EXECUTION_HOST_C_MINUS_8", "transfer_archive_worker_ceiling": 1,
                   "memory_bytes_per_worker": 1, "scratch_bytes_per_worker": 1,
                   "memory_reserve_bytes": 0, "scratch_reserve_bytes": 0}}
    if selection_horizon_months == 12:
        sources["science_decision"] = nested._sealed({
            **{k: v for k, v in sources["science_decision"].items() if k != "identity_sha256"},
            "twelve_month_development": nested._twelve_month_development_contract()})
    source, target = tmp_path / "development.json", tmp_path / "search.zip"
    (tmp_path / "search").mkdir()
    source.write_bytes(canonical_json_bytes({**sources, "science_decision": nested.science_decision_template()}))
    with pytest.raises(ContractError, match="NESTED_SCIENCE_DECISION_INCOMPLETE"):
        f5.execute_final_complex_search(full_development_path=source, candidate_family=family, target=target, workers=1, **line)
    assert not modes and not reads and not target.exists()
    source.write_bytes(canonical_json_bytes(sources))
    with monkeypatch.context() as mismatch:
        mismatch.setattr(f5, "materialize_final_full_data_mice", lambda *a, **kw: {
            **final, "development_input": {**final["development_input"], "raw_covariates_sha256": "f" * 64}})
        with pytest.raises(ContractError, match="F5_Q_DEVELOPMENT_SOURCE_MISMATCH"):
            f5.execute_final_complex_search(full_development_path=source, candidate_family=family, target=target, workers=1, **line)
    assert not modes and not target.exists()
    reads.clear()
    computed = f5.execute_final_complex_search(full_development_path=source, candidate_family=family,
                                              target=target, workers=1, **line)
    archive = computed["execution_archive"]
    native_root = Path(sources["search_roots"][family])
    with zipfile.ZipFile(target) as payload:
        for info in payload.infolist():
            expected = zipfile.ZIP_STORED if info.filename.endswith((".zip", ".rds")) else zipfile.ZIP_DEFLATED
            assert info.compress_type == expected
            if info.filename.startswith("search/native/"):
                assert payload.read(info) == (native_root / info.filename.removeprefix("search/")).read_bytes()
    assert computed["native_search_root"] == str(native_root) and (native_root / "result.json").is_file()
    # The exact root consumed by locked scoring is now the producer's original.
    assert f5._final_complex_search_program(archive["task"], parts, native_root,
        replay=True, workers=1) == archive["result"]
    before = (list(modes), list(reads))
    with pytest.raises(ContractError, match="F5_COMPLEX_SEARCH_COORDINATE_ALREADY_STARTED"):
        f5.execute_final_complex_search(full_development_path=source, candidate_family=family,
            target=tmp_path / "renamed-output.zip", workers=1, **line)
    assert (modes, reads) == before
    assert archive["kind"] == "PADML_F5_COMPLEX_FINAL_SEARCH_EXECUTION_ARCHIVE"
    assert not {"inputs/final-seta.json", "inputs/family-decision.json", "inputs/family-handoff.json"}.intersection(archive["members"])
    assert {name for name in archive["members"] if name.startswith("inputs/selector/")} == {
        "inputs/selector/" + name for name in f5._nested_selector_numerical_members(selector)}
    assert not any(name.startswith("inputs/selector/") and (name.endswith(".bin") or name.endswith("output.json"))
                   for name in archive["members"])
    assert f5.read_final_complex_search(target, workers=1, rscript="UNFITTED") == archive
    assert modes == [False, True, "NUMBERS", "NUMBERS"]
    assert reads == ["INNER_STOP_UNFITTED_READER", "FULL_UNFITTED_READER"] * 2

    if selection_horizon_months == 12:
        wrong_decision = read_safe_zip(target)
        name = "inputs/science-decision.json"
        wrong_decision[name] = canonical_json_bytes(_unfitted_confirmed_decision(fixed_bootstrap=True))
        damaged = copy.deepcopy(archive)
        damaged["members"][name] = {"sha256": sha256_bytes(wrong_decision[name]), "size_bytes": len(wrong_decision[name])}
        wrong_decision["final-search-execution.json"] = canonical_json_bytes(nested._sealed({
            k: v for k, v in damaged.items() if k != "identity_sha256"}))
        path = tmp_path / "wrong-line-decision.zip"
        write_deterministic_zip(path, wrong_decision)
        before = list(modes)
        with pytest.raises(ContractError, match="F5_FULL_DEVELOPMENT_SELECTION_HORIZON_NOT_AUTHORIZED"):
            f5.read_final_complex_search(path, workers=1, rscript="UNFITTED")
        assert modes == before

    for damage in ("trace_mixed", "trace_missing", "winner"):
        if damage == "trace_missing" and selection_horizon_months == 24:
            continue  # Missing is the legacy 24-month contract.
        changed = copy.deepcopy(archive)
        result = changed["result"]
        other = 24 if selection_horizon_months == 12 else 12
        if damage == "winner":
            result["selected_spec"]["selection_metric"] = f"IBS_0_{other}"
        elif damage == "trace_missing":
            result["search_trace"]["S1"][0].pop("selection_horizon_months")
        else:
            result["search_trace"]["S1"][0]["selection_horizon_months"] = other
        result["selected_spec_sha256"] = nested._sha(result["selected_spec"])
        result["search_trace_sha256"] = nested._sha(result["search_trace"])
        changed["result"] = nested._sealed({k: v for k, v in result.items() if k != "identity_sha256"})
        changed = nested._sealed({k: v for k, v in changed.items() if k != "identity_sha256"})
        with pytest.raises(ContractError, match="F5_COMPLEX_SEARCH_(STAGE_DENOMINATOR_INVALID|WINNER_REPLAY_MISMATCH)"):
            f5._validate_executed_complex_search_archive(changed)

    # Rehashing the enclosing original archive cannot turn a changed selector
    # into evidence. The real selector consumer must reject before Q replay.
    entries = read_safe_zip(target)
    name = "inputs/selector/development-input.json"
    changed = strict_json_bytes(entries[name])
    changed["selector"]["selected_parents"] = ["AST_ALT"]
    changed = nested._sealed({key: value for key, value in changed.items() if key != "identity_sha256"})
    entries[name] = canonical_json_bytes(changed)
    damaged = copy.deepcopy(archive)
    damaged["members"][name] = {"sha256": sha256_bytes(entries[name]), "size_bytes": len(entries[name])}
    entries["final-search-execution.json"] = canonical_json_bytes(nested._sealed({
        key: value for key, value in damaged.items() if key != "identity_sha256"}))
    damaged_path = tmp_path / "changed-selector.zip"
    write_deterministic_zip(damaged_path, entries)
    with pytest.raises(ContractError, match="NESTED_FULL_SELECTOR_DEVELOPMENT_REPLAY_MISMATCH"):
        f5.read_final_complex_search(damaged_path, workers=1, rscript="UNFITTED")
    assert modes == [False, True, "NUMBERS", "NUMBERS"]


def test_full0_complex_cli_forwards_only_local_development(tmp_path, monkeypatch, capsys):
    import sys

    source, target = tmp_path / "development.json", tmp_path / "q.zip"
    calls = []
    def execute(**kwargs):
        calls.append(kwargs)
        return {"UNFITTED_CLI_BOUNDARY_ONLY": True}
    monkeypatch.setattr(f5, "execute_final_complex_search", execute)
    monkeypatch.setattr(sys, "argv", ["padml-f5", "complex-search", "--full-development", str(source),
        "--candidate-family", "RSF", "--target", str(target), "--workers", "2"])
    f5.main()
    assert calls == [{"full_development_path": source, "candidate_family": "RSF", "target": target, "workers": 2}]
    assert "UNFITTED_CLI_BOUNDARY_ONLY" in capsys.readouterr().out
    original_argv = list(sys.argv)
    monkeypatch.setattr(sys, "argv", [*original_argv, "--selection-horizon-months", "12"])
    f5.main()
    assert calls[-1] == {**calls[0], "selection_horizon_months": 12}
    assert "UNFITTED_CLI_BOUNDARY_ONLY" in capsys.readouterr().out
    monkeypatch.setattr(sys, "argv", [*original_argv, str(tmp_path / "legacy-family-lock.json")])
    with pytest.raises(ContractError, match="F5_COMPLEX_SEARCH_MIXED_DEVELOPMENT_AUTHORITY"):
        f5.main()
    assert len(calls) == 2
    legacy_paths = {tmp_path / (name + ".json") for name in
                    ("plan", "seta", "mice", "response", "decision", "handoff", "result")}
    monkeypatch.setattr(sys, "argv", ["padml-f5", "complex-search",
        *[str(tmp_path / (name + ".json")) for name in
          ("plan", "seta", "mice", "response", "decision", "handoff", "result")],
        "--selection-horizon-months", "12"])
    read_bytes = Path.read_bytes
    def forbid_legacy_input_read(path):
        if path in legacy_paths:
            pytest.fail("LEGACY12_MUST_FAIL_BEFORE_INPUT_READ")
        return read_bytes(path)
    monkeypatch.setattr(Path, "read_bytes", forbid_legacy_input_read)
    with pytest.raises(ContractError, match="F5_COMPLEX_SEARCH_INPUT_INVALID"):
        f5.main()
    assert len(calls) == 2


@pytest.mark.parametrize("damage", ["global_source", "incomplete_recipes", "seta_df", "recipe_hash", "physical_input", "rehashed_seta"])
def test_full0_complex_task_rejects_stale_or_cross_program_selector(
    full_inputs, tmp_path, unfitted_selector_consumers, damage,
):
    plan, parts, final = _physical_full_inputs(full_inputs, tmp_path / "inputs")
    development = f5._nested_full_selector_program(plan, parts, final, tmp_path / "selector", rscript="UNFITTED", replay=False)
    if damage == "global_source":
        development["source"]["kind"] = "SIX_LOCALLY_VALIDATED_F2_PRIMARY_SELECTORS"
    elif damage == "incomplete_recipes":
        development["transform_recipes"]["recipes"].pop()
    elif damage == "seta_df":
        development["selector"]["common_set_design_df"] = 1
    elif damage == "recipe_hash":
        development["final_full_data_recipe_sha256"] = "0" * 64
    elif damage == "rehashed_seta":
        columns = f5._elastic_parent_design_columns(f5.predictor_contract(Path(f5.__file__).parent))
        selected = ["ALB", "AST_ALT"]
        df = sum(columns[parent] for parent in selected)
        development["selector"].update(selected_parents=selected, common_set_design_df=df, common_set_epv=70 / df)
    else:
        covariates = parts[0]["covariates"]
        member = covariates["members"][0]
        path = Path(covariates["input_dir"]) / member["name"]
        raw = path.read_bytes().replace(b",50\n", b",51\n")
        path.write_bytes(raw)
        member.update(sha256=sha256_bytes(raw), size_bytes=len(raw))
        covariates["data_identity"] = sha256_bytes(canonical_json_bytes(covariates["members"]))
        parts[0]["fit_covariate_members"] = f5._fit_covariate_member_records(covariates, parts[0]["fit_ids"])
    development["identity_sha256"] = sha256_bytes(canonical_json_bytes({
        key: value for key, value in development.items() if key != "identity_sha256"
    }))
    (tmp_path / "selector" / "development-input.json").write_bytes(canonical_json_bytes(development))
    with pytest.raises(ContractError):
        f5.compile_nested_full_complex_search_task(plan, parts, final, tmp_path / "selector", family="RSF", rscript="UNFITTED")


def test_full0_r_registry_admission_requires_only_own_stops_without_fitting():
    """Evaluate only two original R Boolean assignments, not the kernel entry."""
    import shutil
    if shutil.which("Rscript") is None:
        pytest.skip("Rscript unavailable for no-fit native contract check")
    script = r'''
    scalar <- function(value) unname(unlist(value, use.names=FALSE)[[1L]])
    code <- as.list(parse(commandArgs(trailingOnly=TRUE)[[1L]]))
    definitions <- Filter(function(x) is.call(x) && identical(x[[1L]], as.name("<-")) &&
      is.symbol(x[[2L]]) && as.character(x[[2L]]) %in%
      c("common_registered_valid", "f5_registered_valid"), code)
    stopifnot(length(definitions) == 2L)
    registered <- list(status="PASS", fold=0L, projected_partition_count=1L,
      partitions=list(list(kind="INNER")), diagnostic_partitions=list(), outer_count=0L,
      diagnostic_count=0L, inner_count=15L, stop_count=15L, full_count=0L, view_count=30L)
    registered_kind <- "PADML_F5_REGISTERED_PARTITION_INPUTS"
    execution_scope <- "F5_FULL_DEVELOPMENT_SEARCH"
    fold <- 0L
    family <- "GBM_COX"
    spec <- list(final_search_source=list(program_id="PADML_NESTED_LOCO_20260908"))
    for (definition in definitions) eval(definition)
    stopifnot(common_registered_valid, f5_registered_valid)
    registered[["stop_count"]] <- 0L
    registered[["view_count"]] <- 15L
    for (definition in definitions) eval(definition)
    stopifnot(common_registered_valid, !f5_registered_valid)
    family <- "RSF"
    for (definition in definitions) eval(definition)
    stopifnot(common_registered_valid, f5_registered_valid)
    spec$final_search_source$program_id <- "UNAUTHORIZED_LEGACY_SOURCE"
    for (definition in definitions) eval(definition)
    stopifnot(common_registered_valid, !f5_registered_valid)
    spec$final_search_source$program_id <- "PADML_NESTED_LOCO_20260908"
    registered$inner_count <- 14L
    for (definition in definitions) eval(definition)
    stopifnot(common_registered_valid, !f5_registered_valid)
    '''
    completed = f5.subprocess.run([
        "Rscript", "--vanilla", "-e", script,
        str(Path(f5.__file__).parent / "kernels/f2_model_development.R"),
    ], capture_output=True, text=True, check=False, timeout=30)
    assert completed.returncode == 0, completed.stderr


@pytest.mark.parametrize("damage", ["stop_seed", "stop_ids", "stop_response", "stop_members",
                                    "stop_bytes", "inner_view", "inner_members", "inner_application_order"])
def test_full0_complex_runtime_reopens_compiled_inner_and_stop_identity(
    full_inputs, tmp_path, unfitted_selector_consumers, damage,
):
    plan, parts, final = _physical_full_inputs(full_inputs, tmp_path / "inputs")
    f5._nested_full_selector_program(plan, parts, final, tmp_path / "selector", rscript="UNFITTED", replay=False)
    task = f5.compile_nested_full_complex_search_task(plan, parts, final, tmp_path / "selector", family="GBM_COX", rscript="UNFITTED")
    task_sha = task["task_sha256"]
    part = parts[0]["stopping"] if damage.startswith("stop") else parts[0]
    if damage == "stop_seed":
        part["seed"] += 1
    elif damage == "stop_ids":
        part["fit_ids"].reverse()
    elif damage == "inner_view":
        part["covariates"]["analysis_view_sha256"] = "0" * 64
    elif damage == "inner_application_order":
        part["application_ids"] = list(reversed(part["application_ids"]))
        part["covariates"]["application_ids_sha256"] = sha256_bytes(canonical_json_bytes(part["application_ids"]))
    elif damage == "stop_response":
        binding = part["fit_response"]
        path = Path(binding["path"])
        raw = path.read_bytes().replace(b",50\n", b",51\n")
        path.write_bytes(raw)
        binding.update(sha256=sha256_bytes(raw), size_bytes=len(raw))
    else:
        covariates = part["covariates"]
        member = covariates["members"][0]
        path = Path(covariates["input_dir"]) / member["name"]
        raw = path.read_bytes().replace(b",50\n", b",51\n")
        path.write_bytes(raw)
        if damage != "stop_bytes":
            member.update(sha256=sha256_bytes(raw), size_bytes=len(raw))
            covariates["data_identity"] = sha256_bytes(canonical_json_bytes(covariates["members"]))
            part["fit_covariate_members"] = f5._fit_covariate_member_records(covariates, part["fit_ids"])
    with pytest.raises(ContractError, match="NESTED_FULL_COMPLEX_RUNTIME"):
        f5._complex_runtime_registered_inputs(task, parts)
    assert task["task_sha256"] == task_sha


@pytest.mark.parametrize("no_aar", [False, True])
@pytest.mark.parametrize("damage", ["event", "domain", "metadata"])
def test_nested_selector_binds_epv_to_actual_response_and_complete_domain(
    full_inputs, tmp_path, monkeypatch, no_aar, damage,
):
    from padml import f2_kernel
    plan, parts, final = _physical_full_inputs(full_inputs, tmp_path / "inputs")
    context, partitions = f5._nested_full_selector_inputs(plan, parts, final)
    if no_aar:
        context["source"].update(kind="PADML_NESTED_NO_AAR_SELECTOR_SOURCE_V1",
                                 inherited_family="COX_PH", primary_development_lock_sha256="d" * 64)
    for part in partitions:
        part["transform_recipe"] = {"UNFITTED": True}
    columns = {parent: width for parent, width in f5._elastic_parent_design_columns(
        f5.predictor_contract(Path(f5.__file__).parent)).items() if not no_aar or parent != "AST_ALT"}
    if damage == "domain":
        columns.pop("Age")
    if damage == "metadata":
        partitions[-1]["fit_response"]["event_count"] = 71  # actual bytes contain 70
    def reduced(_partitions, alphas, produced, **kwargs):
        return {alpha: {"outer_paths": [{"event_count": 71 if damage == "event" else 70,
                                        "parent_design_columns": columns} for _ in range(20)]} for alpha in alphas}
    def never_select(*args, **kwargs):
        raise AssertionError("INVALID_DOMAIN_MUST_FAIL_BEFORE_SELECTION")
    monkeypatch.setattr(f4, "_run_learning_selector_path", lambda arguments: {"UNFITTED": True})
    monkeypatch.setattr(f4, "_reduce_full_pipeline_selector_phase", reduced)
    monkeypatch.setattr(f2_kernel, "_choose_elastic_alpha", never_select)
    root = tmp_path / "search"
    root.mkdir()
    with pytest.raises(ContractError, match="NESTED_SELECTOR_(NATIVE_DOMAIN_DRIFT|EVENT_COUNT_INVALID)"):
        f4._full_pipeline_selector_search(context, partitions, root, rscript="UNFITTED", replay=False)


def test_full0_search_evidence_binds_all_candidates_and_retained_native_members(
    full_inputs, tmp_path, monkeypatch,
):
    """Real phase/manifest replay; candidate math and native fits are UNFITTED stubs."""
    from padml import f2_kernel
    plan, parts, final = _physical_full_inputs(full_inputs, tmp_path / "inputs")
    context, partitions = f5._nested_full_selector_inputs(plan, parts, final)
    for part in partitions:
        part["transform_recipe"] = {"UNFITTED": True}
    columns = f5._elastic_parent_design_columns(f5.predictor_contract(Path(f5.__file__).parent))
    def reduced(_partitions, alphas, produced, **kwargs):
        return {alpha: {"alpha": alpha, "outer_paths": [{"event_count": 70, "parent_design_columns": columns}
                                                        for _ in range(20)]} for alpha in alphas}
    def producer(arguments):
        _, _, task, directory, _ = arguments
        root = Path(directory) / task["task_id"] / "native"
        root.mkdir(parents=True)
        (root / "UNFITTED.bin").write_bytes(b"NOT_A_MODEL_OR_A_FITTED_PATH")
        return {"UNFITTED": True}
    monkeypatch.setattr(f4, "_run_learning_selector_path", producer)
    monkeypatch.setattr(f4, "_consume_learning_selector_path", lambda arguments: {"UNFITTED": True})
    monkeypatch.setattr(f4, "_reduce_full_pipeline_selector_phase", reduced)
    monkeypatch.setattr(f2_kernel, "_choose_elastic_alpha", lambda records, order, contract, **kwargs: ({"alpha": order[0]}, []))
    root = tmp_path / "search"
    root.mkdir()
    first = f4._full_pipeline_selector_search(context, partitions, root, rscript="UNFITTED", replay=False)
    second = f4._full_pipeline_selector_search(context, partitions, root, rscript="UNFITTED", replay=True)
    assert first == second
    result = first[0]
    records = []
    for phase in ("coarse", "fine"):
        if (root / phase / "paths.json").is_file():
            records.extend(strict_json_bytes((root / phase / "paths.json").read_bytes()))
    records.sort(key=lambda row: row["alpha"])
    assert result["candidate_records_sha256"] == sha256_bytes(canonical_json_bytes(records))
    assert result["distinct_alpha_count"] == len(records) <= 15
    assert result["selector_path_count"] == len(records) * 320
    manifest_raw = (root / "native-members.json").read_bytes()
    assert result["native_member_set_sha256"] == sha256_bytes(manifest_raw)
    members = strict_json_bytes(manifest_raw)
    assert len(members) == 640  # 320 retained UNFITTED tasks in each of coarse/fine
    path = root / members[-1]["name"]
    path.write_bytes(b"ALTERED_NATIVE_BYTES")
    with pytest.raises(ContractError, match="NESTED_SELECTOR_NATIVE_MEMBER_REPLAY_MISMATCH"):
        f4._full_pipeline_selector_search(context, partitions, root, rscript="UNFITTED", replay=True)
