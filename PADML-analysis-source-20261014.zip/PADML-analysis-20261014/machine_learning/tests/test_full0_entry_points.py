"""Original full0 entry wiring; native split/MICE/selector/model leaves UNFITTED."""
import copy
import csv
import io
import os
import sys
import tempfile
import zipfile
from pathlib import Path
from contextlib import contextmanager
from subprocess import run as native_statement_run

import pytest

from padml import f1_contract, f5, runtime
from padml.bundle import ContractError, canonical_json_bytes, sha256_bytes, sha256_file, strict_json_bytes, write_deterministic_zip
from test_nested_full_development import full_inputs, _unfitted_confirmed_decision
from test_f5 import fake_mice_run, valid_unfitted_mice_covariates


def unfitted_full0_mice_run(arguments, **kwargs):
    """Original FIT/REPLAY plumbing; no actual MICE or random-number calls."""
    from test_nested_aar_mice import _write_unfitted_a12_configuration
    completed = fake_mice_run(arguments, **kwargs)
    spec = strict_json_bytes(Path(arguments[-2] if "REPLAY" in arguments else arguments[-1]).read_bytes())
    _write_unfitted_a12_configuration(spec)
    return completed


@pytest.fixture
def prepared(full_inputs, tmp_path, monkeypatch):
    ids, centers, events = full_inputs
    covariates, response = tmp_path / "raw-covariates.csv", tmp_path / "raw-response.csv"
    covariates.write_bytes(valid_unfitted_mice_covariates(list(reversed(ids)), list(reversed(centers))))
    response.write_text("Patient_ID,All_Cause_Death,Death_Followup_months\n" +
                        "".join(f"{patient},{event},50\n" for patient, event in reversed(list(zip(ids, events, strict=True)))))
    # Synthetic F1 manifests cannot carry the pinned clinical identity. Only
    # that leaf is a stub; original replay/data-binding ZIP readers remain live.
    frozen = tmp_path / "f1"
    (frozen / "input/f1/objects").mkdir(parents=True)
    (frozen / "build").mkdir()
    binding = {"covariates_sha256": sha256_file(covariates), "response_seal_sha256": sha256_file(response),
        "registry": {"outer": [{"application_ids": ids, "heldout_center": center,
            "validation_ids": [patient for patient, value in zip(ids, centers, strict=True) if value == center]}
            for center in (36, 38, 39, 48, 52, 54)]}}
    payload = tmp_path / "unfitted-binding.zip"
    write_deterministic_zip(payload, {"binding/contract.json": canonical_json_bytes(binding),
        "binding/covariates.csv": covariates, "binding/response-seal.csv": response})
    result_path = frozen / "input/f1/objects/data-binding.zip"
    write_deterministic_zip(result_path, {"manifest.json": b'{"UNFITTED":true}',
        "outputs/data-binding/payload.zip": payload})
    manifest = {"identity": "UNFITTED_SYNTHETIC_F1", "binding_contract_sha256": sha256_bytes(canonical_json_bytes(binding)),
        "direct_objects": [{"unit_id": "data-binding", "result_size_bytes": result_path.stat().st_size,
                            "result_sha256": sha256_file(result_path)}]}
    (frozen / "input/f1/input-manifest.json").write_bytes(canonical_json_bytes(manifest))
    common = frozen / "build/common-input.zip"
    write_deterministic_zip(common, {"UNFITTED.txt": b"NO_CLINICAL_INPUT"})
    seal = {"f1_input_manifest_identity": manifest["identity"], "common_input_sha256": sha256_file(common),
        "binding_contract_sha256": manifest["binding_contract_sha256"], "response_seal_sha256": sha256_file(response),
        "response_size_bytes": response.stat().st_size, "lineage": {"UNFITTED": "1" * 64}}
    seal["identity"] = sha256_bytes(canonical_json_bytes(seal))
    write_deterministic_zip(frozen / "build/f1-replay-seal.zip", {"manifest.json": canonical_json_bytes(seal),
        "binding-contract.json": canonical_json_bytes(binding), "response-seal.csv": response})
    def synthetic_manifest(path):
        assert path.read_bytes() == canonical_json_bytes(manifest)
        return manifest
    monkeypatch.setattr(f1_contract, "load_f1_input_manifest", synthetic_manifest)
    monkeypatch.setattr(runtime, "effective_cpu_count", lambda: 32)
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda root: {
        "effective_cpus": 32, "available_memory_bytes": 10**12,
        "scratch_available_bytes": 10**12, "scratch_root": str(root)})
    policy = {"configured_worker_ceiling": runtime.CPU_MINUS_8, "memory_bytes_per_worker": 2 * 1024**3,
        "scratch_bytes_per_worker": 1, "memory_reserve_bytes": 0,
        "scratch_reserve_bytes": 0, "transfer_archive_worker_ceiling": 1000}
    root = tmp_path / "prepared"
    result = f5.compile_full_data_development_inputs(covariates, response, root,
        science_decision=_unfitted_confirmed_decision(fixed_bootstrap=True), resource_policy=policy, f1_runtime_root=frozen,
        retained_bytes_per_view=1000, retained_bytes_per_component=1000,
        expanded_bytes_per_component=1000, shared_storage_bytes=1000, rscript="UNFITTED")
    return root, covariates, response, result


def test_raw_preparation_retains_producer_but_rejects_changed_f1_bytes(prepared):
    root, _, _, _ = prepared
    sources = strict_json_bytes((root / "full-development.json").read_bytes())
    expected = f5._full_development_raw_inputs(sources)
    sources["raw_input_binding"]["f45_source_sha256"] = "e" * 64
    assert f5._full_development_raw_inputs(sources) == expected
    assert sources["raw_input_binding"]["f45_source_sha256"] == "e" * 64
    covariates = root / "covariates.csv"
    covariates.write_bytes(covariates.read_bytes() + b"\n")
    with pytest.raises(ContractError, match="F5_FULL_DEVELOPMENT_RAW_INPUT_DRIFT"):
        f5._full_development_raw_inputs(sources)



@pytest.mark.parametrize("scope", ["FINAL", "INNER_ANALYSIS", "INNER_APPLICATION", "STOP_ANALYSIS", "STOP_APPLICATION"])
def test_full0_mice_first_audit_then_complete_numbers_without_native(prepared, monkeypatch, scope):
    """Original producer, first native audit and numeric reader; mids UNFITTED."""
    root, _, _, _ = prepared
    plan = strict_json_bytes((root / "full-development.json").read_bytes())["plan"]
    tasks = f5.compile_full_data_search_mice_tasks(plan)
    task = (f5.compile_final_full_data_mice_task(plan) if scope == "FINAL" else next(
        row for row in tasks if row["role"] == scope.split("_")[1]
        and ("STOP" in row["view_id"]) == scope.startswith("STOP")))
    covariates, response = (root / "covariates.csv").read_bytes(), (root / "response.csv").read_bytes()
    fields, responses = f5._response_rows(response)
    _, fit_ids, _ = f5._mice_view_rows(plan, task)
    fit_response = (f5._write_response_subset(fields, responses, fit_ids, None)["private_bytes"]
                    if task["role"] == "ANALYSIS" else None)
    calls = []
    def native(command, **kwargs):
        calls.append("REPLAY" if "REPLAY" in command else "FIT")
        return unfitted_full0_mice_run(command, **kwargs)
    monkeypatch.setattr(f5.subprocess, "run", native)
    target = root / "view.zip"
    owner = target.with_suffix("")
    result = f5.execute_full_data_search_mice_view(plan, task, covariates, fit_response, target,
        work_root=owner, rscript="UNFITTED", retained_bytes_limit=128 * 1024**2)
    assert calls == ["FIT", "REPLAY"]
    assert result["retained_bytes"] > result["size_bytes"] + result["native_archive"]["size_bytes"]
    assert result["native_archive_path"] == str(owner / "native-view.zip")
    assert len(list((owner / "native").glob("*.rds"))) == 20
    with zipfile.ZipFile(owner / "native-view.zip") as archive:
        native_manifest = archive.read("manifest.json")
        original = {name: archive.read(name) for name in archive.namelist() if not name.startswith("native/")}
    with zipfile.ZipFile(target) as archive:
        entries = {name: archive.read(name) for name in archive.namelist()}
    assert not any(name.startswith("native/") for name in entries)
    assert entries["manifest.json"] == native_manifest
    assert {name: raw for name, raw in entries.items() if name != "mice-numbers.json"} == original
    numbers = strict_json_bytes(entries["mice-numbers.json"])
    assert ("chain_rng_substream" in numbers["spec"]) == scope.startswith("STOP")
    if scope.startswith("STOP"):
        assert numbers["spec"]["chain_rng_substream"] == 1
    assert numbers["spec"]["chain_seeds"] == task["chain_seeds"]
    assert numbers["native_archive"] == result["native_archive"]
    assert len(list(owner.glob(".native-replay-*/spec.json"))) == 1
    if scope in {"INNER_ANALYSIS", "STOP_APPLICATION"}:
        _check_full0_original_r_statements(owner, numbers)
    retained = root / "retained-first-owner"
    owner.rename(retained)
    monkeypatch.setattr(f5, "_replay_mice_native_view",
        lambda *a, **k: pytest.fail("Normal full0 reader must not enter native replay"))
    replay = root / "numeric"
    manifest = f5._extract_full_data_mice_view(plan, task, target, replay)
    assert manifest == strict_json_bytes(native_manifest)
    assert not (replay / "native").exists() and not list(replay.glob(".native-replay-*"))
    assert all((replay / name).read_bytes() == data for name, data in original.items())
    rejected = []
    for damage in ("missing_numbers", "seed", "substream", "summary_m", "method", "matrix_required",
                   "native_boolean", "native_member", "missing_m20", "observed_age", "empty_hgb",
                   "nondonor_hgb", "ratio", "raw_source", "role", "substream_manifest"):
        changed = dict(entries)
        record = copy.deepcopy(numbers)
        header = strict_json_bytes(changed["manifest.json"])
        if damage == "missing_numbers":
            del changed["mice-numbers.json"]
        elif damage == "seed":
            record["spec"]["chain_seeds"][0] += 1
        elif damage == "substream":
            record["spec"]["chain_rng_substream"] = True if scope.startswith("STOP") else 1
        elif damage == "native_boolean":
            record["native_archive"]["size_bytes"] = True
        elif damage == "native_member":
            del record["members"]["native/imp01.rds"]
        elif damage == "missing_m20":
            del changed["imputations/imp20.csv"]
        elif damage == "role":
            record["spec"]["view"]["role"] = "APPLICATION" if task["role"] == "ANALYSIS" else "ANALYSIS"
        elif damage == "substream_manifest":
            header["chain_rng_substream"] = True
        else:
            member = "imputations/imp01.csv"
            if damage == "summary_m":
                record["summary"]["formal_m"] = 19
                member = "summary.json"
                changed[member] = canonical_json_bytes(record["summary"])
            elif damage in {"method", "matrix_required"}:
                name = "ACTUAL_MICE_METHOD" if damage == "method" else "ACTUAL_PREDICTOR_MATRIX"
                payload = record["configuration"][name]["payload"]
                if damage == "method":
                    payload["values"][payload["names"].index("HGB")] = ""
                else:
                    payload["values"][payload["row_names"].index("HGB")][payload["column_names"].index("AST_ALT")] = 0
                member = "configuration/" + name + ".json"
                changed[member] = canonical_json_bytes(record["configuration"][name])
            else:
                if damage == "raw_source":
                    member = "inputs/covariates.csv"
                reader = csv.DictReader(io.StringIO(changed[member].decode()))
                rows = list(reader)
                if damage in {"observed_age", "raw_source"}:
                    rows[0]["Age"] = "999"
                elif damage == "ratio":
                    rows[0]["AST_ALT"] = "999"
                else:
                    raw = {row["Patient_ID"]: row for row in csv.DictReader(io.StringIO(covariates.decode()))}
                    row = next(row for row in rows if not raw[row["Patient_ID"]]["HGB"])
                    row["HGB"] = "" if damage == "empty_hgb" else "99999"
                stream = io.StringIO(newline="")
                writer = csv.DictWriter(stream, fieldnames=reader.fieldnames, lineterminator="\n")
                writer.writeheader()
                writer.writerows(rows)
                changed[member] = stream.getvalue().encode()
            header["members"][member] = {"sha256": sha256_bytes(changed[member]), "size_bytes": len(changed[member])}
            record["members"] = copy.deepcopy(header["members"])
        changed["manifest.json"] = canonical_json_bytes(header)
        if damage != "missing_numbers":
            changed["mice-numbers.json"] = canonical_json_bytes(record)
        damaged = root / ("bad-" + damage + ".zip")
        write_deterministic_zip(damaged, changed)
        with pytest.raises(ContractError):
            f5._extract_full_data_mice_view(plan, task, damaged, root / ("bad-" + damage))
        rejected.append(damage)
    assert calls == ["FIT", "REPLAY"]
    (root / "full0-numerical-observation.json").write_bytes(canonical_json_bytes({
        "scope": scope, "source_task": task, "native_calls": calls, "native_calls_after_first_audit": 0,
        "native_leaf": "UNFITTED", "actual_model_fits": 0, "actual_mice_chains": 0,
        "retained_owner": str(retained), "native_archive": result["native_archive"],
        "identical_m20_members": 20, "rejected": rejected}))


def _check_full0_original_r_statements(owner, numbers):
    """Actual original matrix/passive statements only, before MICE or RNG."""
    import math
    oracle = owner / "original-r-numerical-check"
    oracle.mkdir()
    script = r'''
args <- commandArgs(trailingOnly = TRUE)
spec <- jsonlite::fromJSON(args[[1L]], simplifyVector = FALSE)
spec$chain_rng_substream <- NULL
authority <- jsonlite::fromJSON(spec$authority_path, simplifyVector = FALSE)
kernel <- file.path(dirname(dirname(spec$authority_path)), "kernels", "f1_nested_mice.R")
required <- c("fail", "exact_names", "chars", "ints", "numeric_strict", "parse_levels",
              "cast_covariates", "nelson_aalen", "factor_support_ok", "egfr", "impute_view")
definitions <- Filter(function(x) is.call(x) && identical(x[[1L]], as.name("<-")) &&
  is.symbol(x[[2L]]) && as.character(x[[2L]]) %in% required && is.call(x[[3L]]) &&
  identical(x[[3L]][[1L]], as.name("function")), as.list(parse(kernel)))
stopifnot(length(definitions) == length(required))
for (definition in definitions) eval(definition)
expressions <- as.list(body(impute_view))
last <- which(vapply(expressions, function(x) identical(x, quote(diag(matrix) <- 0L)), logical(1)))
stopifnot(length(last) == 1L)
for (expression in expressions[2L:last]) eval(expression)
jsonlite::write_json(list(row_names = rownames(matrix), column_names = colnames(matrix),
  values = unname(lapply(seq_len(nrow(matrix)), function(i) unname(as.integer(matrix[i, ]))))),
  file.path(args[[2L]], "matrix.json"), auto_unbox = TRUE)
completed <- cast_covariates(read.csv(file.path(spec$output_dir, "imputations", "imp01.csv"),
  colClasses = "character", check.names = FALSE, na.strings = character()), spec$variable_path)
passive <- list()
collect <- function(x) {
  if (!is.call(x)) return(invisible(NULL))
  if (identical(x[[1L]], as.name("<-")) &&
      (identical(x[[2L]], quote(completed$BMI)) || identical(x[[2L]], quote(completed$eGFR_calc)) ||
       identical(x[[2L]], quote(output$AST_ALT)))) {
    passive[[length(passive) + 1L]] <<- x
    return(invisible(NULL))
  }
  for (i in seq_along(x)) if (!identical(x[[i]], quote(expr = ))) collect(x[[i]])
}
collect(body(impute_view))
stopifnot(length(passive) == 3L)
output <- completed
for (expression in passive) eval(expression)
completed$AST_ALT <- output$AST_ALT
write.table(completed, file.path(args[[2L]], "completed.csv"), sep = ",", row.names = FALSE,
  col.names = TRUE, quote = TRUE, na = "", fileEncoding = "UTF-8", qmethod = "double")
cat("ORIGINAL_FULL0_MATRIX_AND_PASSIVE_ONLY_NO_MICE_OR_RNG\n")
'''
    (oracle / "program.R").write_text(script)
    checked = native_statement_run(["Rscript", "--vanilla", str(oracle / "program.R"),
        str(owner / "spec.json"), str(oracle)], capture_output=True, text=True, check=False, timeout=30)
    (oracle / "stdout.txt").write_text(checked.stdout)
    (oracle / "stderr.txt").write_text(checked.stderr)
    assert checked.returncode == 0, checked.stderr
    assert checked.stdout.strip() == "ORIGINAL_FULL0_MATRIX_AND_PASSIVE_ONLY_NO_MICE_OR_RNG"
    assert strict_json_bytes((oracle / "matrix.json").read_bytes()) == numbers["configuration"]["ACTUAL_PREDICTOR_MATRIX"]["payload"]
    actual = list(csv.DictReader((owner / "output/imputations/imp01.csv").open()))
    expected = list(csv.DictReader((oracle / "completed.csv").open()))
    for left, right in zip(actual, expected, strict=True):
        assert left["Patient_ID"] == right["Patient_ID"]
        for name in ("HGB", "BMI", "eGFR_calc", "AST_ALT"):
            assert math.isclose(float(left[name]), float(right[name]), rel_tol=1e-14, abs_tol=0.0)


@pytest.mark.parametrize("phase", ["retention", "interrupt_audit", "audit", "values", "publication"])
def test_full0_mice_failed_handoff_retains_first_owner_and_refuses_refit(prepared, monkeypatch, phase):
    root, _, _, _ = prepared
    plan = strict_json_bytes((root / "full-development.json").read_bytes())["plan"]
    task = f5.compile_final_full_data_mice_task(plan)
    target, owner = root / "failure.zip", root / "failure"
    calls = []
    def native(command, **kwargs):
        replay = "REPLAY" in command
        calls.append("REPLAY" if replay else "FIT")
        if phase == "interrupt_audit" and replay:
            kwargs["stdout"].write("UNFITTED_FIRST_AUDIT_STDOUT\n")
            kwargs["stderr"].write("UNFITTED_FIRST_AUDIT_STDERR\n")
            raise TimeoutError("UNFITTED_FIRST_AUDIT_INTERRUPTION")
        result = unfitted_full0_mice_run(command, **kwargs)
        if phase == "values" or phase == "audit" and replay:
            spec = strict_json_bytes(Path(command[-2] if replay else command[-1]).read_bytes())
            path = Path(spec["output_dir"]) / "imputations/imp01.csv"
            path.write_bytes(path.read_bytes().replace(b'"2.0"', b'"999.0"', 1))
        return result
    monkeypatch.setattr(f5.subprocess, "run", native)
    original_write = f5.write_deterministic_zip
    def writer(path, *args, **kwargs):
        if phase == "publication" and path == target:
            raise OSError("UNFITTED_PUBLICATION_FAILURE")
        return original_write(path, *args, **kwargs)
    monkeypatch.setattr(f5, "write_deterministic_zip", writer)
    def produce():
        return f5.execute_full_data_search_mice_view(plan, task, (root / "covariates.csv").read_bytes(),
            (root / "response.csv").read_bytes(), target, work_root=owner, rscript="UNFITTED",
            retained_bytes_limit=1024**2 if phase == "retention" else 128 * 1024**2)
    with pytest.raises((ContractError, OSError)):
        produce()
    assert calls == (["FIT"] if phase == "retention" else ["FIT", "REPLAY"])
    assert not target.exists() and (owner / "native-view.zip").is_file()
    assert (owner / "spec.json").is_file() and len(list((owner / "native").glob("*.rds"))) == 20
    if phase == "interrupt_audit":
        audit = next(owner.glob(".native-replay-*"))
        assert (audit / "spec.json").is_file()
        assert (audit / "stdout.txt").read_text() == "UNFITTED_FIRST_AUDIT_STDOUT\n"
        assert (audit / "stderr.txt").read_text() == "UNFITTED_FIRST_AUDIT_STDERR\n"
    with pytest.raises(ContractError, match="COORDINATE_ALREADY_STARTED"):
        produce()
    assert len(calls) == (1 if phase == "retention" else 2)

def test_full0_preparation_retains_raw_bytes_and_original_61_view_plan(prepared):
    root, covariates, response, result = prepared
    sources = strict_json_bytes((root / "full-development.json").read_bytes())
    assert (root / "covariates.csv").read_bytes() == covariates.read_bytes()
    assert (root / "source-response.csv").read_bytes() == response.read_bytes()
    assert sources["raw_input_binding"]["response_sha256"] == sha256_file(root / "response.csv")
    assert list(f5._response_rows((root / "response.csv").read_bytes())[1]) == sources["plan"]["source_ids"]
    tasks = [*f5.compile_full_data_search_mice_tasks(sources["plan"]), f5.compile_final_full_data_mice_task(sources["plan"])]
    assert len(tasks) == 61 and sum(len(task["chain_seeds"]) for task in tasks) == 1220
    assert result["mice_chain_count"] == result["model_fit_count"] == 0
    assert sources["plan"]["family"] is None and sources["resource_policy"]["configured_worker_ceiling"] == runtime.CPU_MINUS_8
    assert (root / "search").is_dir() and not any((root / "search").iterdir())


def test_full0_view_subset_forwards_whole_m20_and_never_application_response(prepared, tmp_path, monkeypatch):
    root, _, _, _ = prepared
    source = root / "full-development.json"
    plan = strict_json_bytes(source.read_bytes())["plan"]
    tasks = f5.compile_full_data_search_mice_tasks(plan)
    selected = [tasks[0], tasks[1], f5.compile_final_full_data_mice_task(plan)]
    calls, pools = [], []
    def view(observed_plan, task, covariates, response, target, *, rscript, work_root, retained_bytes_limit):
        assert observed_plan == plan and len(task["chain_seeds"]) == 20 and rscript == "UNFITTED"
        assert work_root == target.with_suffix("")
        assert retained_bytes_limit == 1000
        assert os.environ["TMPDIR"] == tempfile.gettempdir() == str(target.parent)
        _, ids, _ = f5._mice_view_rows(plan, task)
        assert response is None if task["role"] == "APPLICATION" else list(f5._response_rows(response)[1]) == ids
        assert covariates == (root / "covariates.csv").read_bytes()
        target.write_bytes(b"UNFITTED_M20_VIEW")
        calls.append((task, target))
        return {"status": "UNFITTED", "sha256": sha256_file(target), "size_bytes": target.stat().st_size}
    def pool(worker, jobs, *, selected_slots, execution_report):
        pools.append((worker, len(jobs), selected_slots))
        assert worker is f5._execute_full_data_mice_job
        execution_report["UNFITTED_POOL"] = True
        return [worker(job) for job in jobs]
    monkeypatch.setattr(f5, "execute_full_data_search_mice_view", view)
    monkeypatch.setattr(f5, "_bounded_ordered_spawn", pool)
    target = root / "batch-report"
    result = f5.execute_full_data_mice_batch(source, target, view_ids=[task["view_id"] for task in reversed(selected)])
    assert [task for task, _ in calls] == selected
    assert pools == [(f5._execute_full_data_mice_job, 3, 3)]
    assert result["mice_chains"] == 60 and result["model_fit_count"] == 0
    assert calls[0][1] == root / "mice" / tasks[0]["split_id"] / "analysis.zip"
    assert calls[1][1] == root / "mice" / tasks[1]["split_id"] / "application.zip"
    assert calls[-1][1] == root / "final-mice.zip"
    with pytest.raises(ContractError, match="F5_FULL_MICE_BATCH_ALREADY_STARTED"):
        f5.execute_full_data_mice_batch(source, target, view_ids=[selected[0]["view_id"]])
    assert len(calls) == 3
    with pytest.raises(ContractError, match="F5_FULL_MICE_COORDINATE_ALREADY_STARTED"):
        f5.execute_full_data_mice_batch(source, root / "different-report", view_ids=[selected[0]["view_id"]])
    assert len(calls) == 3 and not (root / "different-report").exists()


@pytest.mark.parametrize("damage", ["duplicate", "unknown", "covariates", "source-response", "response",
    "missing-original", "f45-source", "canonical-response", "incomplete", "scratch"])
def test_full0_view_batch_rejects_before_pool(prepared, tmp_path, monkeypatch, damage):
    root, _, _, _ = prepared
    source = root / "full-development.json"
    task = f5.compile_final_full_data_mice_task(strict_json_bytes(source.read_bytes())["plan"])
    ids = [task["view_id"]]
    if damage == "duplicate":
        ids *= 2
    elif damage == "unknown":
        ids = ["UNAUTHORIZED_VIEW"]
    elif damage in {"covariates", "source-response", "response"}:
        path = root / (damage + ".csv")
        original = path.read_bytes()
        changed = original[:-2] + (b"8\n" if original[-2:] == b"7\n" else b"7\n")
        assert changed != original and len(changed) == len(original)
        path.write_bytes(changed)
    elif damage == "missing-original":
        (root / "source-response.csv").rename(root / "preserved-source-response.csv")
    elif damage == "incomplete":
        (root / "final-mice").mkdir()
    elif damage in {"f45-source", "canonical-response"}:
        sources = strict_json_bytes(source.read_bytes())
        if damage == "f45-source":
            sources["raw_input_binding"]["f45_source_sha256"] = "0" * 64
        else:
            path = root / "response.csv"
            original = path.read_bytes()
            path.write_bytes(original[:-2] + b"7\n")
            sources["raw_input_binding"]["response_sha256"] = sha256_file(path)
        source.write_bytes(canonical_json_bytes(sources))
    else:
        monkeypatch.setattr(runtime, "observe_execution_resources", lambda path: {
            "effective_cpus": 32, "available_memory_bytes": 10**12, "scratch_available_bytes": 1, "scratch_root": str(path)})
    monkeypatch.setattr(f5, "_bounded_ordered_spawn", lambda *a, **k: pytest.fail("No MICE pool after rejected input"))
    with pytest.raises(ContractError):
        f5.execute_full_data_mice_batch(source, root / "absent", view_ids=ids)
    assert not (root / "absent").exists()


@pytest.mark.parametrize("command,mode", [("full-selector", []), ("full-selector", ["--replay"]),
    ("full-score", []), ("full-score", ["--resume"]), ("full-score", ["--replay"]),
    ("full-score", ["--family", "RSF", "--resume"])])
def test_full0_cli_forwards_native_stage_mode(tmp_path, monkeypatch, capsys, command, mode):
    source = tmp_path / "full-development.json"
    calls = []
    name = "execute_full_data_selector" if command == "full-selector" else "execute_full_data_locked_scores"
    monkeypatch.setattr(f5, name, lambda *args, **kwargs: calls.append((args, kwargs)) or {"UNFITTED": True})
    monkeypatch.setattr(sys, "argv", ["padml-f5", command, str(source), *mode])
    f5.main()
    assert strict_json_bytes(capsys.readouterr().out.encode()) == {"UNFITTED": True}
    assert calls == [((source,), {"replay": "--replay" in mode,
        **({"resume": "--resume" in mode} if command == "full-score" else {}),
        **({"family": "RSF"} if "--family" in mode else {})})]


def test_full0_cli_continuous_score_forwards_exact_request_and_complement(tmp_path, monkeypatch, capsys):
    source, batch, retained, producer = (tmp_path / name for name in ("source.json", "new", "old", "producer.zip"))
    digest = "a" * 64
    calls = []
    monkeypatch.setattr(f5, "execute_full_data_locked_scores",
        lambda *args, **kwargs: calls.append((args, kwargs)) or {"UNFITTED": True})
    monkeypatch.setattr(sys, "argv", ["padml-f5", "full-score", str(source), "--resume",
        "--selection-horizon-months", "12", "--family", "GBM_COX",
        "--task-ids", "coordinate", "--batch-root", str(batch),
        "--score-batches", str(retained), "--retained-full0-source-bundle", str(producer),
        "--continuous-request-sha256", digest])
    f5.main()
    assert strict_json_bytes(capsys.readouterr().out.encode()) == {"UNFITTED": True}
    assert calls == [((source,), {"replay": False, "resume": True,
        "selection_horizon_months": 12, "family": "GBM_COX", "task_ids": ["coordinate"],
        "batch_root": batch, "score_batches": [retained], "retained_full0_source_bundle": producer,
        "continuous_request_sha256": digest})]


def test_full0_cli_keeps_default_score_modes_exclusive(tmp_path, monkeypatch):
    monkeypatch.setattr(f5, "execute_full_data_locked_scores",
        lambda *a, **k: pytest.fail("mixed default modes reached the executor"))
    monkeypatch.setattr(sys, "argv", ["padml-f5", "full-score", str(tmp_path / "source.json"),
        "--task-ids", "coordinate", "--score-batches", str(tmp_path / "old")])
    with pytest.raises(SystemExit) as caught:
        f5.main()
    assert caught.value.code == 2


@pytest.mark.parametrize("command,mode", [
    ("full-selector", "prepare"), ("full-selector", "subset"), ("full-selector", "gather"),
    ("a12-outer", "prepare"), ("a12-outer", "subset"), ("a12-outer", "gather"),
    ("a12-outer", "replay"), ("a12-outer", "borrowed"),
])
def test_original_selector_cli_forwards_phase_coordinates(tmp_path, monkeypatch, capsys, command, mode):
    from padml import f5_sensitivity as sensitivity
    source, result, bundle = tmp_path / "source.json", tmp_path / "selector", tmp_path / "input.zip"
    batch, first, second = tmp_path / "batch", tmp_path / "first", tmp_path / "second"
    args = ["padml-f5", command, str(source)]
    expected = {"replay": False}
    calls = []
    if command == "a12-outer":
        args.extend([str(result), "--input-bundle", str(bundle)])
        expected = {"input_bundle": bundle, "retained_bytes_per_component": None}
        if mode != "borrowed":
            args.append("--selector-only")
            expected["selector_only"] = True
        owner, name = sensitivity, "execute_a12_outer_bundle"
    else:
        owner, name = f5, "execute_full_data_selector"
    if mode == "prepare":
        args.append("--prepare-only")
        expected["prepare_only"] = True
    elif mode == "subset":
        args.extend(["--phase", "fine", "--task-ids", "R1_K1_M01", "R1_K1_M02",
            "--batch-root", str(batch), "--retained-bytes-per-task", "33554432"])
        expected.update(phase_name="fine", task_ids=["R1_K1_M01", "R1_K1_M02"],
            batch_root=batch, retained_bytes_per_task=33554432)
    elif mode == "gather":
        args.extend(["--phase", "coarse", "--phase-batches", str(first), str(second)])
        expected.update(phase_name="coarse", phase_batches=[first, second])
    elif mode == "replay":
        args.append("--selector-replay")
        expected["selector_replay"] = True
    else:
        args.extend(["--selector-root", str(first), "--retained-bytes-per-component", "100000000"])
        expected.update(selector_root=first, retained_bytes_per_component=100000000)
    monkeypatch.setattr(owner, name, lambda *args, **kwargs: calls.append((args, kwargs)) or {"UNFITTED": True})
    monkeypatch.setattr(sys, "argv", args)
    f5.main()
    assert strict_json_bytes(capsys.readouterr().out.encode()) == {"UNFITTED": True}
    assert calls == [((source, result) if command == "a12-outer" else (source,), expected)]


def test_full0_stage_admission_does_not_inherit_final_shard_limit(prepared, monkeypatch):
    root, _, _, _ = prepared
    source = root / "full-development.json"
    sources = strict_json_bytes(source.read_bytes())
    parts, full, calls, scopes = ["UNFITTED_PARTITIONS"], {"UNFITTED_M20": True}, [], []
    @contextmanager
    def materialized(*args, **kwargs):
        assert args == (source, source.parent)
        scopes.append(kwargs)
        yield sources, parts, full
    def selector(*args, **kwargs):
        calls.append((args, kwargs))
        return {"UNFITTED_SELECTOR": True}
    def scores(*args, **kwargs):
        calls.append((args, kwargs))
        return {"UNFITTED_SCORES": True}
    monkeypatch.setattr(f5, "_materialized_full_data_development_sources", materialized)
    monkeypatch.setattr(f5, "_nested_full_selector_program", selector)
    monkeypatch.setattr(f5, "_full_data_locked_score_program", scores)
    assert f5.execute_full_data_selector(source) == {"UNFITTED_SELECTOR": True}
    assert calls[-1][1]["workers"] == 24
    assert f5.execute_full_data_locked_scores(source, resume=True) == {"UNFITTED_SCORES": True}
    assert "workers" not in calls[-1][1] and calls[-1][1]["resume"] is True
    assert calls[-1][0][:3] == (sources["plan"], parts, full)
    assert scopes == [{"selector_only": True}, {}]
    for family in f5._nested_science._families():
        assert f5.execute_full_data_locked_scores(source, resume=True, family=family) == {"UNFITTED_SCORES": True}
        assert calls[-1][1]["family"] == family and calls[-1][1]["resume"] is True
        assert scopes[-1] == ({} if family in f5._STOP_CONSUMERS else {"selector_only": True})


def test_full0_public_selector_opens_only_31_required_mice_views(prepared, monkeypatch):
    """Original M20 ZIP producers/readers/merge; all MICE/selector fits UNFITTED."""
    root, _, _, _ = prepared
    source = root / "full-development.json"
    sources = strict_json_bytes(source.read_bytes())
    plan = sources["plan"]
    all_tasks = [*f5.compile_full_data_search_mice_tasks(plan), f5.compile_final_full_data_mice_task(plan)]
    inner_ids = {pair["split_id"] for pair in plan["split_pairs"]}
    tasks = [task for task in all_tasks if task["split_id"] in inner_ids or task["phase"] == "FINAL_MICE"]
    assert len(all_tasks) == 61 and sum(len(task["chain_seeds"]) for task in all_tasks) == 1220
    assert len(tasks) == 31
    calls, selected, paths = [], [], []
    def native(arguments, **kwargs):
        replay = "REPLAY" in arguments
        spec = strict_json_bytes(Path(arguments[-2] if replay else arguments[-1]).read_bytes())
        calls.append((replay, spec["view"]["view_id"]))
        return unfitted_full0_mice_run(arguments, **kwargs)
    monkeypatch.setattr(f5.subprocess, "run", native)
    covariates, response, _ = f5._full_development_raw_inputs(sources)
    fields, responses = f5._response_rows(response)
    for task in tasks:
        _, fit_ids, _ = f5._mice_view_rows(plan, task)
        path = (root / "final-mice.zip" if task["phase"] == "FINAL_MICE" else
                root / "mice" / task["split_id"] / (task["role"].lower() + ".zip"))
        path.parent.mkdir(parents=True, exist_ok=True)
        f5.execute_full_data_search_mice_view(plan, task, covariates,
            f5._write_response_subset(fields, responses, fit_ids, None)["private_bytes"]
            if task["role"] == "ANALYSIS" else None, path, rscript="UNFITTED")
        paths.append(path)

    monkeypatch.setattr(f5, "_replay_mice_native_view",
                        lambda *a, **k: pytest.fail("No native MICE after the producer's first audit"))
    raw_rows = {row["Patient_ID"]: row for row in csv.DictReader(io.StringIO(covariates.decode()))}

    def selector(observed_plan, parts, full, target, **kwargs):
        assert observed_plan == plan and kwargs["workers"] == 24 and not kwargs["replay"]
        assert target == Path(sources["selector_root"])
        assert len(parts) == 15 and all(part["stopping"] is None for part in parts)
        context, projected = f5._nested_full_selector_inputs(plan, parts, full)
        assert len(projected) == 16 and all("stopping" not in part for part in projected)
        for part in projected:
            directory = Path(part["covariates"]["input_dir"])
            for member in part["covariates"]["members"]:
                rows = {row["Patient_ID"]: row for row in csv.DictReader(
                    io.StringIO((directory / member["name"]).read_text()))}
                assert all(rows[patient]["Age"] == raw_rows[patient]["Age"] for patient in part["fit_ids"])
                if part["kind"] == "INNER":
                    assert all(rows[patient]["Age"] == raw_rows[patient]["Age"] for patient in part["evaluation_ids"])
                assert all(row["HGB"] for row in rows.values())
        observed = []
        with pytest.raises(ContractError, match="F5_A16_STOP_PARTITION_INVALID"):
            f5._nested_full_selector_inputs(plan, parts, full, on_partition_bindings=observed.extend)
        assert observed == []
        result = {"UNFITTED_SELECTOR": True, "view_count": 31, "context": context,
                  "partition_ids": [part["partition_id"] for part in projected]}
        selected.append(result)
        return result
    monkeypatch.setattr(f5, "_nested_full_selector_program", selector)
    result = f5.execute_full_data_selector(source)
    assert result == selected[0] and len(selected) == 1
    expected_views = [task["view_id"] for task in tasks]
    assert calls == [(replay, view) for view in expected_views for replay in (False, True)]
    assert all(path.is_file() for path in paths)
    assert not any((root / "mice" / pair["stopping"]["partition_id"]).exists() for pair in plan["split_pairs"])
    assert len(f5._final_search_mice_members(plan, root / "mice", include_stop=False)) == 30
    with pytest.raises(ContractError, match="F5_Q_MICE_MEMBER_MISSING"):
        f5.execute_full_data_locked_scores(source)
    for required in (paths[0], paths[-1]):
        retained = required.with_suffix(".unavailable")
        required.rename(retained)
        try:
            with pytest.raises(ContractError):
                f5.execute_full_data_selector(source)
        finally:
            retained.rename(required)
    assert len(selected) == 1 and len(calls) == 62
    (root / "selector-31-view-observation.json").write_bytes(canonical_json_bytes({
        **result, "unfitted_native_calls": calls, "model_fit_count": 0, "mice_chain_count": 0,
        "complete_plan_views": len(all_tasks), "complete_plan_chains": 1220,
        "required_inner_and_full_rejections": 2, "stop_consumer_rejections": 2}))


@pytest.mark.parametrize("damage", ["frozen-covariates", "frozen-response", "old-decision"])
def test_full0_preparation_rejects_before_first_split(prepared, monkeypatch, damage):
    root, covariates, response, _ = prepared
    sources = strict_json_bytes((root / "full-development.json").read_bytes())
    decision = sources["science_decision"]
    if damage == "old-decision":
        decision = _unfitted_confirmed_decision(fresh_seven=True)
    else:
        path = covariates if damage == "frozen-covariates" else response
        raw = path.read_bytes()
        changed = raw[:-2] + (b"8\n" if raw[-2:] == b"7\n" else b"7\n")
        assert changed != raw and len(changed) == len(raw)
        path.write_bytes(changed)
    monkeypatch.setattr(f5, "compile_full_data_mice_plan", lambda *a, **k: pytest.fail("No split on another cohort/decision"))
    target = root.parent / "rejected-preparation"
    with pytest.raises(ContractError):
        f5.compile_full_data_development_inputs(covariates, response, target,
            f1_runtime_root=root.parent / "f1", science_decision=decision, resource_policy=sources["resource_policy"],
            retained_bytes_per_view=1000, retained_bytes_per_component=1000,
            expanded_bytes_per_component=1000, shared_storage_bytes=1000, rscript="UNFITTED")
    assert not target.exists()


@pytest.mark.parametrize("damage", ["too-large", "memory-one-byte-short"])
def test_full0_description_rejects_before_json_read(tmp_path, monkeypatch, damage):
    path = tmp_path / "full-development.json"
    path.write_bytes(b"{}" if damage == "memory-one-byte-short" else b" " * (16 * 1024**2 + 1))
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda root: {
        "available_memory_bytes": 32 * path.stat().st_size + 4 * 1024**2 - 1})
    monkeypatch.setattr(Path, "open", lambda *a, **k: pytest.fail("Rejected before reading complete JSON"))
    with pytest.raises(ContractError):
        f5._read_final_lineage(path, bounded=True)


def test_full0_mice_interrupt_retains_native_streams_and_forbids_coordinate_retry(prepared, monkeypatch):
    root, _, _, _ = prepared
    source = root / "full-development.json"
    sources = strict_json_bytes(source.read_bytes())
    task = f5.compile_final_full_data_mice_task(sources["plan"])
    calls = []
    def native(command, **kwargs):
        assert command[-2] == "FIT" and kwargs["cwd"] == root / "final-mice"
        assert kwargs["env"]["TMPDIR"] == str(root) == tempfile.gettempdir()
        kwargs["stdout"].write("UNFITTED_PARTIAL_STDOUT\n")
        kwargs["stderr"].write("UNFITTED_PARTIAL_STDERR\n")
        calls.append(command)
        raise TimeoutError("UNFITTED_MICE_INTERRUPTION")
    monkeypatch.setattr(f5.subprocess, "run", native)
    monkeypatch.setattr(f5, "_bounded_ordered_spawn", lambda worker, jobs, **kwargs: [worker(job) for job in jobs])
    previous = {name: os.environ.get(name) for name in ("TMPDIR", "TMP", "TEMP")}
    previous_tempdir = tempfile.tempdir
    with pytest.raises(TimeoutError, match="UNFITTED_MICE_INTERRUPTION"):
        f5.execute_full_data_mice_batch(source, root / "failed-report", view_ids=[task["view_id"]])
    native_root = root / "final-mice"
    assert (native_root / "spec.json").is_file() and (native_root / "covariates.csv").is_file()
    assert (native_root / "stdout.txt").read_text() == "UNFITTED_PARTIAL_STDOUT\n"
    assert (native_root / "stderr.txt").read_text() == "UNFITTED_PARTIAL_STDERR\n"
    assert {name: os.environ.get(name) for name in previous} == previous and tempfile.tempdir == previous_tempdir
    with pytest.raises(ContractError, match="F5_FULL_MICE_COORDINATE_ALREADY_STARTED"):
        f5.execute_full_data_mice_batch(source, root / "another-report", view_ids=[task["view_id"]])
    assert len(calls) == 1 and not (root / "another-report").exists()


def test_full0_mice_rechecks_completed_archive_after_acquiring_native_directory(prepared, monkeypatch):
    root, _, _, _ = prepared
    sources = strict_json_bytes((root / "full-development.json").read_bytes())
    task = f5.compile_final_full_data_mice_task(sources["plan"])
    target, native_root = root / "final-mice.zip", root / "final-mice"
    mkdir = Path.mkdir
    def acquired(path, *args, **kwargs):
        result = mkdir(path, *args, **kwargs)
        if path == native_root:
            target.write_bytes(b"UNFITTED_ALREADY_COMPLETED_BY_OTHER_CALL")
        return result
    monkeypatch.setattr(Path, "mkdir", acquired)
    monkeypatch.setattr(f5.subprocess, "run", lambda *a, **k: pytest.fail("No R call after archive completion"))
    with pytest.raises(ContractError, match="F5_FULL_MICE_COORDINATE_ALREADY_STARTED"):
        f5.execute_full_data_search_mice_view(sources["plan"], task, (root / "covariates.csv").read_bytes(),
            (root / "response.csv").read_bytes(), target, work_root=native_root, rscript="UNFITTED")
    assert target.read_bytes() == b"UNFITTED_ALREADY_COMPLETED_BY_OTHER_CALL" and native_root.is_dir()


def _unfitted_mice_views(root, *, covariates=None):
    sources = strict_json_bytes((root / "full-development.json").read_bytes())
    plan = sources["plan"]
    original = (root / "covariates.csv").read_bytes()
    raw = original if covariates is None else covariates
    columns = f5.load_science_authority()["science"]["mice"]["private_handoff"]["columns"]
    fields, responses = f5._response_rows((root / "response.csv").read_bytes())
    tasks = [*f5.compile_full_data_search_mice_tasks(plan), f5.compile_final_full_data_mice_task(plan)]
    for task in tasks:
        _, fit_ids, row_ids = f5._mice_view_rows(plan, task)
        path = (root / "final-mice.zip" if task["phase"] == "FINAL_MICE" else
                root / "mice" / task["split_id"] / (task["role"].lower() + ".zip"))
        path.parent.mkdir(parents=True, exist_ok=True)
        members = {"manifest.json": canonical_json_bytes({"UNFITTED": True, "source_covariates_sha256": sha256_bytes(original)}),
            "inputs/covariates.csv": f5._subset_private_csv(raw, row_ids, columns, task["source_id_set_sha256"], None)}
        if task["role"] == "ANALYSIS":
            members["inputs/response.csv"] = f5._write_response_subset(fields, responses, fit_ids, None)["private_bytes"]
        write_deterministic_zip(path, members)
    return sources


@pytest.mark.parametrize("changed_cohort", [False, True])
@pytest.mark.parametrize("horizon", [24, 12])
def test_full0_materializer_binds_canonical_views_to_original_raw_bytes(prepared, monkeypatch, changed_cohort, horizon):
    root, _, _, _ = prepared
    raw = (root / "covariates.csv").read_bytes()
    changed = raw[:-2] + (b"8\n" if raw[-2:] == b"7\n" else b"7\n") if changed_cohort else raw
    assert (changed != raw) is changed_cohort and len(changed) == len(raw)
    sources = _unfitted_mice_views(root, covariates=changed)
    options, lifecycle = {}, {}
    if horizon == 12:
        from test_full0_fixed12_rescore import decision
        sources.update(selection_horizon_months=12, science_decision=decision())
        (root / "full-development.json").write_bytes(canonical_json_bytes(sources))
        options = {"selection_horizon_months": 12, "retained_mice_plan": sources["plan"],
            "retained_full0_source_bundle": root / "UNFITTED-primary.zip", "q_input_lifecycle": lifecycle}
        original_raw_inputs = f5._full_development_raw_inputs
        def current_raw_inputs(*args, **kwargs):
            # Current synthetic producer: isolate only the historical code
            # proof, retaining the actual raw/view identity checks below.
            kwargs.pop("retained_full0_source_bundle", None)
            return original_raw_inputs(*args, **kwargs)
        monkeypatch.setattr(f5, "_full_development_raw_inputs", current_raw_inputs)
        monkeypatch.setattr(f5, "compile_full_data_mice_plan", lambda *a, **k: pytest.fail("NO_NEW_SPLIT_OR_STOP_DRAW"))
    calls, scratch_roots = [], []
    expected = {"mice_plan_sha256": sha256_bytes(canonical_json_bytes(sources["plan"])),
        "raw_covariates_sha256": f5._full_development_raw_inputs(sources)[2],
        "response_sha256": sha256_file(root / "response.csv")}
    def search(*args):
        calls.append("search")
        scratch_roots.append(Path(tempfile.gettempdir()))
        assert os.environ["TMPDIR"] == str(args[-1].parent) == tempfile.gettempdir()
        return ["UNFITTED_NATIVE_SEARCH_MICE"]
    def final(*args):
        calls.append("full")
        assert os.environ["TMPDIR"] == str(args[-1].parent) == tempfile.gettempdir()
        return {"development_input": expected, "UNFITTED_NATIVE_FULL_MICE": True}
    monkeypatch.setattr(f5, "_materialize_final_search_inputs", search)
    monkeypatch.setattr(f5, "materialize_final_full_data_mice", final)
    if changed_cohort:
        with pytest.raises(ContractError, match="F5_FULL_DEVELOPMENT_RAW_INPUT_DRIFT"):
            with f5._materialized_full_data_development_sources(root / "full-development.json", root, **options):
                pytest.fail("Self-consistent replacement MICE views must not pass frozen raw binding")
        assert calls == []
    else:
        with f5._materialized_full_data_development_sources(root / "full-development.json", root, **options) as (observed, parts, full):
            assert observed == sources and parts == ["UNFITTED_NATIVE_SEARCH_MICE"] and full["development_input"] == expected
        assert calls == ["search", "full"]
        if horizon == 12:
            assert set(lifecycle) == {"materialized_inputs"}
            assert all(path.is_dir() for path in scratch_roots)
            assert lifecycle["materialized_inputs"]["temporary_root"] == str(scratch_roots[0])
        else:
            assert all(not path.exists() for path in scratch_roots)


def test_full0_materializer_rejects_before_zip_directory_allocation(prepared, monkeypatch):
    root, _, _, _ = prepared
    sources = _unfitted_mice_views(root)
    raw_bytes = sum(path.stat().st_size for path in f5._full_development_raw_paths(sources).values())
    raw_bytes += (root / "full-development.json").stat().st_size
    available = 32 * raw_bytes + 1024**2  # exact initial directory allowance minus the one worker byte
    observations = []
    def observe(path):
        observations.append(path)
        return {"effective_cpus": 32, "available_memory_bytes": 10**12 if len(observations) == 1 else available,
                "scratch_available_bytes": 10**12, "scratch_root": str(path)}
    monkeypatch.setattr(runtime, "observe_execution_resources", observe)
    monkeypatch.setattr(f5.zipfile, "ZipFile", lambda *a, **k: pytest.fail("Directory allocation preceded admission"))
    with pytest.raises(ContractError):
        with f5._materialized_full_data_development_sources(root / "full-development.json", root):
            pytest.fail("Expected memory rejection")
    # The future-only 2 GiB worker admission now rejects while reopening the
    # retained input, before the former ZIP-directory allocation check.
    assert len(observations) == 2


@pytest.mark.parametrize("shortage", [None, "worker-disk", "disk", "memory"])
def test_full0_materializer_future_reserves_do_not_replace_physical_admission(prepared, monkeypatch, shortage):
    root, _, _, _ = prepared
    sources = _unfitted_mice_views(root)
    sources["resource_policy"]["scratch_reserve_bytes"] = 10**12
    sources["resource_policy"]["scratch_bytes_per_worker"] = 1024
    source = root / "full-development.json"
    source.write_bytes(canonical_json_bytes(sources))
    original = source.read_bytes()
    demand = sources["resource_policy"]["scratch_bytes_per_worker"]
    observation = {"effective_cpus": 32, "available_memory_bytes": 10**12,
        "scratch_available_bytes": demand if shortage is None else demand - 1,
        "scratch_root": str(root)}
    if shortage == "disk": observation["scratch_available_bytes"] = 0
    if shortage == "memory": observation["available_memory_bytes"] = 1
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda path: {**observation, "scratch_root": str(path)})
    admissions, calls = [], []
    original_admission = runtime.resource_admission
    def admit(policy, *args, **kwargs):
        admissions.append(dict(policy))
        return original_admission(policy, *args, **kwargs)
    monkeypatch.setattr(runtime, "resource_admission", admit)
    expected = {"mice_plan_sha256": sha256_bytes(canonical_json_bytes(sources["plan"])),
        "raw_covariates_sha256": f5._full_development_raw_inputs(sources)[2],
        "response_sha256": sha256_file(root / "response.csv")}
    def search(*args):
        calls.append("search")
        return ["UNFITTED"]
    def final(*args):
        calls.append("full")
        return {"development_input": expected}
    monkeypatch.setattr(f5, "_materialize_final_search_inputs", search)
    monkeypatch.setattr(f5, "materialize_final_full_data_mice", final)
    if shortage is None:
        with f5._materialized_full_data_development_sources(source, root) as (observed, parts, full):
            assert observed == sources and parts == ["UNFITTED"] and full["development_input"] == expected
        assert calls == ["search", "full"]
        assert admissions[-1]["scratch_bytes_per_worker"] == demand
    else:
        reason = ("RESOURCE_OBSERVATION_INVALID" if shortage == "disk" else
                  "F5_FINAL_LINEAGE_MEMORY_NOT_ADMITTED" if shortage == "memory" else "RESOURCE_ADMISSION_ZERO")
        with pytest.raises(ContractError, match=reason):
            with f5._materialized_full_data_development_sources(source, root):
                pytest.fail("Physical shortfall must reject before native materialization")
        assert calls == []
    assert all(row["scratch_reserve_bytes"] == 0 and row["memory_bytes_per_worker"] == 2 * 1024**3
               for row in admissions)
    assert source.read_bytes() == original and sources["resource_policy"]["scratch_reserve_bytes"] == 10**12


@pytest.fixture
def failed_materializer_inputs(request, monkeypatch):
    # Reuse the bounded old I/O fixture with the current, actually validated
    # scientific decision; this test changes no scientific validation leaf.
    import test_full0_entry_points as entry
    monkeypatch.setattr(entry, '_unfitted_confirmed_decision',
        lambda **kwargs: f5._nested_science.science_decision_template(24))
    return request.getfixturevalue('prepared')


@pytest.mark.parametrize('retained_owner', [None, 'pool', 'child', 'lifecycle', 'survivor'])
def test_full0_failed_consumer_retires_only_completed_private_inputs(failed_materializer_inputs, monkeypatch, retained_owner):
    import multiprocessing
    root, _, _, _ = failed_materializer_inputs
    sources = _unfitted_mice_views(root)
    source = root / 'full-development.json'
    originals = {p: p.read_bytes() for p in (source, root / 'covariates.csv', root / 'final-mice.zip')}
    shared = root / 'mice-preparation/qualified/values'
    shared.mkdir(parents=True)
    (shared / 'imp01.csv').write_bytes(b'UNFITTED_CANONICAL_SHARED_INPUT\n')
    expected = {'mice_plan_sha256': sha256_bytes(canonical_json_bytes(sources['plan'])),
        'raw_covariates_sha256': f5._full_development_raw_inputs(sources)[2],
        'response_sha256': sha256_file(root / 'response.csv')}
    created = []
    def search(plan, mice_root, response, destination, **kwargs):
        destination.mkdir()
        (destination / 'derived.csv').write_bytes(b'UNFITTED_PRIVATE_INPUT\n')
        created.append(destination.parent)
        return [{'covariates': {'input_dir': str(shared)}}]
    def full(plan, payload, response, destination, **kwargs):
        destination.mkdir()
        (destination / 'derived.csv').write_bytes(b'UNFITTED_PRIVATE_INPUT\n')
        return {'development_input': expected, 'covariates': {'input_dir': str(shared)}}
    monkeypatch.setattr(f5, '_materialize_final_search_inputs', search)
    monkeypatch.setattr(f5, 'materialize_final_full_data_mice', full)
    monkeypatch.setattr(multiprocessing, 'active_children', lambda: [object()] if retained_owner == 'child' else [])
    lifecycle = {} if retained_owner == 'lifecycle' else None
    error = ContractError('BOUNDED_SPAWN_CHILD_SURVIVOR' if retained_owner == 'survivor' else 'UNFITTED_NATIVE_FAILURE')
    if retained_owner == 'pool':
        assert runtime._POOL_MAIN_LOCK.acquire(blocking=False)
    try:
        with pytest.raises(ContractError) as caught:
            with f5._materialized_full_data_development_sources(source, root,
                    q_input_lifecycle=lifecycle) as (_, partitions, full_value):
                work = created[0]
                native = work / 'native-failure'
                native.mkdir()
                (native / 'spec.json').write_bytes(b'{"UNFITTED_DIAGNOSTIC":true}\n')
                assert Path(partitions[0]['covariates']['input_dir']) == shared
                raise error
        assert caught.value is error
    finally:
        if retained_owner == 'pool': runtime._POOL_MAIN_LOCK.release()
    work, = created
    for name in ('search', 'full'):
        assert (work / name).exists() is (retained_owner is not None)
    assert (work / 'native-failure/spec.json').read_bytes() == b'{"UNFITTED_DIAGNOSTIC":true}\n'
    assert (shared / 'imp01.csv').read_bytes() == b'UNFITTED_CANONICAL_SHARED_INPUT\n'
    assert all(path.read_bytes() == raw for path, raw in originals.items())
    assert any(str(work) in note for note in error.__notes__)


def test_full0_partial_preparation_preserves_failed_subtree_but_releases_completed_inputs(failed_materializer_inputs, monkeypatch):
    import multiprocessing
    root, _, _, _ = failed_materializer_inputs
    _unfitted_mice_views(root)
    created = []
    def search(plan, mice_root, response, destination, **kwargs):
        destination.mkdir()
        (destination / 'derived.csv').write_bytes(b'UNFITTED_COMPLETE_INPUT\n')
        created.append(destination.parent)
        return ['UNFITTED']
    def full(plan, payload, response, destination, **kwargs):
        destination.mkdir()
        (destination / 'partial-and-error.txt').write_bytes(b'UNFITTED_UNFINISHED_EVIDENCE\n')
        raise ContractError('UNFITTED_MATERIALIZATION_FAILURE')
    monkeypatch.setattr(f5, '_materialize_final_search_inputs', search)
    monkeypatch.setattr(f5, 'materialize_final_full_data_mice', full)
    monkeypatch.setattr(multiprocessing, 'active_children', lambda: [])
    with pytest.raises(ContractError, match='UNFITTED_MATERIALIZATION_FAILURE'):
        with f5._materialized_full_data_development_sources(root / 'full-development.json', root):
            pytest.fail('Failed preparation must never reach a consumer')
    work, = created
    assert not (work / 'search').exists()
    assert (work / 'full/partial-and-error.txt').read_bytes() == b'UNFITTED_UNFINISHED_EVIDENCE\n'

from padml import diagnostics as d, integrated as it
from padml.bundle import canonical_json_bytes as enc


@pytest.mark.parametrize('scope', ['FINAL', 'APPLICATION'])
@pytest.mark.parametrize('missing', [True, False])
def test_completed_full0_first_science_then_persistent_hit_and_drift(full_inputs,tmp_path,monkeypatch,scope,missing):
    import time
    root=tmp_path;ids,centers,events=full_inputs
    plan=f5.compile_full_data_mice_plan(ids,None,centers,events,family=None,workers=None)
    task=(f5.compile_final_full_data_mice_task(plan) if scope=='FINAL' else next(
        row for row in f5.compile_full_data_search_mice_tasks(plan) if row['role']=='APPLICATION'))
    cov=valid_unfitted_mice_covariates(ids,centers)
    if not missing:
        reader=csv.DictReader(io.StringIO(cov.decode()));rows=list(reader)
        for row in rows:
            if not row['HGB']:row['HGB']='125'
        stream=io.StringIO(newline='');writer=csv.DictWriter(stream,fieldnames=reader.fieldnames,lineterminator='\n')
        writer.writeheader();writer.writerows(rows);cov=stream.getvalue().encode()
    response=("Patient_ID,All_Cause_Death,Death_Followup_months\n"+"".join(f"{p},{e},50\n" for p,e in zip(ids,events))).encode()
    fields,rows=f5._response_rows(response);_,ids,_=f5._mice_view_rows(plan,task)
    response=f5._write_response_subset(fields,rows,ids,None)['private_bytes'] if scope=='FINAL' else None
    calls=[]
    def native(command,**kw):calls.append('REPLAY' if 'REPLAY' in command else 'FIT');return unfitted_full0_mice_run(command,**kw)
    monkeypatch.setattr(f5.subprocess,'run',native)
    target=root/'checked-view.zip'
    f5.execute_full_data_search_mice_view(plan,task,cov,response,target,work_root=target.with_suffix(''),rscript='UNFITTED',retained_bytes_limit=128*1024**2)
    assert calls==['FIT','REPLAY']
    from padml.carriers import open_carrier
    with open_carrier(target) as archive:
        numbers=strict_json_bytes(archive.read('mice-numbers.json'))
        manifest=strict_json_bytes(archive.read('manifest.json'))
    assert (manifest['source_response_sha256'] is None)==(scope=='APPLICATION')
    assert numbers['summary']['active_target_count']==int(missing)
    assert (numbers['summary'].get('completion_mode')=='COMPLETE_DATA_PASSTHROUGH')==(not missing)
    assert numbers['native_archive']['size_bytes']>0
    reads=[];original=f5._extract_full_data_mice_view
    def consume(*a,**kw):reads.append(1);return original(*a,**kw)
    monkeypatch.setattr(f5,'_extract_full_data_mice_view',consume)
    run=f5._execute_full_data_mice_job
    job=dict(plan=plan,task=task,target=str(target),covariates=cov,response=response,rscript='UNFITTED',retained_bytes_per_view=128*1024**2)
    now=time.time_ns();monkeypatch.setattr(time,'time_ns',lambda:now+3_000_000_000)
    first=run(job);record=target.with_suffix('')/'.native.qualified.json';pinned=record.read_bytes()
    assert len(reads)==1 and strict_json_bytes(pinned)['scientifically_validated'] is True
    it._BYTE_PINS.clear()
    import padml.bundle as bundle
    bundle._FILE_DIGESTS.clear()
    second=run(job)
    assert first==second and len(reads)==1 and calls==['FIT','REPLAY']
    assert not list(root.glob('.mice-consume-*'))
    with pytest.raises(ContractError,match='F5_FULL_DEVELOPMENT_RAW_INPUT_DRIFT'):run({**job,'response':(response or b'')+b'\n'})
    assert record.read_bytes()==pinned
    native_path=target.with_suffix('')/'native-view.zip';native_path.write_bytes(native_path.read_bytes()+b'DRIFT')
    with pytest.raises(ContractError,match='RAW_QUALIFIED_BYTES_DRIFT'):run(job)
    assert record.read_bytes()==pinned and calls==['FIT','REPLAY']


def _unfitted_full0_diagnostic_context(tmp_path,monkeypatch,family='COX_PH'):
    run=dict(kind=it.RUN_KIND,run_root=str(tmp_path),source_identity='e'*64,resource_policy={})
    monkeypatch.setattr('padml.runtime.run_ready_families',lambda calls,**kw:[fn() for fn in calls])
    unit=dict(kind='FULL0',unit_id='FULL0-H06',horizon=6)
    manifest=dict(source_receipt_sha256='a'*64,development_lock=dict(selected_family=family))
    monkeypatch.setattr(it,'same_batch_generations',lambda run:{'r':'e'*64})
    folder=tmp_path/'postprocess/diagnostics';folder.mkdir(parents=True)
    source=dict(source_unit=unit['unit_id'],source_receipt_sha256=manifest['source_receipt_sha256'],development_lock=manifest['development_lock'],producer=run['source_identity'])
    identity=d.n._sha(source)
    def save(name):d._save(folder/(name+'.json'),dict(input_identity=identity,value=dict(status='PASS',UNFITTED=name)))
    return run,unit,manifest,folder,save


def test_subresults_hit_before_any_mice_and_nonstochastic_seed(tmp_path,monkeypatch):
    run,unit,manifest,folder,save=_unfitted_full0_diagnostic_context(tmp_path,monkeypatch);save('sensitivity');save('natural')
    def forbidden(*a,**kw):raise AssertionError('NO_MICE_PREPARATION_ON_COMPLETED_DIAGNOSTICS')
    monkeypatch.setattr(f5,'_materialized_full_data_development_sources',forbidden)
    monkeypatch.setattr(f5,'materialize_final_full_data_mice',forbidden)
    original=(folder/'natural.json').read_bytes()
    damaged=strict_json_bytes(original);damaged['value']['status']='CHANGED'
    (folder/'natural.json').write_bytes(enc(damaged))
    with pytest.raises(ContractError,match='DIAGNOSTIC_RESULT_DRIFT'):
        d.run_diagnostics(run,unit,tmp_path,manifest)
    (folder/'natural.json').write_bytes(original)
    value=d.run_diagnostics(run,unit,tmp_path,manifest)
    assert value['results']['seed']['status']=='NOT_APPLICABLE'
    assert value['results']['sensitivity']['UNFITTED']=='sensitivity'


def test_only_sensitivity_materializes_only_full_analysis(tmp_path,monkeypatch):
    run,unit,manifest,folder,save=_unfitted_full0_diagnostic_context(tmp_path,monkeypatch);save('natural');save('seed')
    plan={'UNFITTED':True};raw=b'UNFITTED_RESPONSE'
    policy=dict(configured_worker_ceiling='EXECUTION_HOST_C_MINUS_8',memory_bytes_per_worker=2*1024**3,
        scratch_bytes_per_worker=1,memory_reserve_bytes=0,scratch_reserve_bytes=0,transfer_archive_worker_ceiling=1)
    sources=dict(science_decision={},selection_horizon_months=6,plan=plan,final_mice_path=str(tmp_path/'final.zip'),selector_root=str(tmp_path/'selector'),resource_policy=policy)
    from padml.bundle import write_deterministic_zip
    write_deterministic_zip(tmp_path/'final.zip',{'UNFITTED':b'NO_NATIVE_DATA'})
    raw_path=tmp_path/'UNFITTED-raw.csv';raw_path.write_bytes(b'UNFITTED')
    (tmp_path/'full-development.json').write_bytes(enc(sources))
    monkeypatch.setattr(f5,'_full_development_raw_paths',lambda *a:{'covariates':raw_path})
    import padml.runtime as runtime
    monkeypatch.setattr(runtime,'effective_cpu_count',lambda:32)
    capacity={'memory':1}
    monkeypatch.setattr(runtime,'observe_execution_resources',lambda root:dict(effective_cpus=32,
        available_memory_bytes=capacity['memory'],scratch_available_bytes=100*1024**3,scratch_root=str(root)))
    admitted=[];original_admit=runtime.resource_admission
    def admit(policy,observation,**kw):
        admitted.append(policy);return original_admit(policy,observation,**kw)
    monkeypatch.setattr(runtime,'resource_admission',admit)
    (tmp_path/'selector').mkdir();(tmp_path/'selector/development-input.json').write_bytes(enc({'UNFITTED':True}))
    monkeypatch.setattr(f5,'_read_final_lineage',lambda *a,**k:sources)
    monkeypatch.setattr(f5,'_full_development_science_decision',lambda *a,**k:None)
    raw_reads=[]
    def read_raw(*a,**k):raw_reads.append(1);return b'',raw,'b'*64
    monkeypatch.setattr(f5,'_full_development_raw_inputs',read_raw)
    seen=[]
    def full(*a,**kw):seen.append('FULL_ANALYSIS');return dict(development_input=dict(mice_plan_sha256=d.n._sha(plan),raw_covariates_sha256='b'*64,response_sha256=d.n.sha256_bytes(raw)))
    monkeypatch.setattr(f5,'materialize_final_full_data_mice',full)
    monkeypatch.setattr(f5,'_materialized_full_data_development_sources',lambda *a,**k:pytest.fail('INNER/STOP must stay closed'))
    monkeypatch.setattr(d,'_sensitivity',lambda *a,**k:{'status':'PASS','UNFITTED':'sensitivity'})
    with pytest.raises(ContractError,match='RESOURCE_ADMISSION_ZERO'):
        d.run_diagnostics(run,unit,tmp_path,manifest)
    assert not seen and not raw_reads and not (folder/'result.json').exists()
    capacity['memory']=100*1024**3
    value=d.run_diagnostics(run,unit,tmp_path,manifest)
    assert seen==['FULL_ANALYSIS'] and value['status']=='COMPLETED'
    assert admitted and admitted[0]['memory_reserve_bytes']>0
    assert all(p['memory_bytes_per_worker']==2*1024**3 for p in admitted)


def test_pending_natural_skips_stop_when_seed_is_complete(tmp_path,monkeypatch):
    run,unit,manifest,folder,save=_unfitted_full0_diagnostic_context(tmp_path,monkeypatch,'RSF');save('sensitivity');save('seed')
    selector=tmp_path/'selector';selector.mkdir();(selector/'development-input.json').write_bytes(enc({'UNFITTED':True}))
    seen=[]
    @contextmanager
    def materialize(*a,**kw):
        seen.append(kw);yield dict(plan={},selector_root=str(selector)),[],{}
    monkeypatch.setattr(f5,'_materialized_full_data_development_sources',materialize)
    monkeypatch.setattr(f5,'_nested_full_selector_inputs',lambda *a,**kw:({'source':{}},[]))
    monkeypatch.setattr(f5,'_complex_runtime_registered_inputs',lambda *a:pytest.fail('no pending seed'))
    monkeypatch.setattr(d,'_natural',lambda *a,**k:{'status':'PASS','UNFITTED':'natural'})
    assert d.run_diagnostics(run,unit,tmp_path,manifest)['status']=='COMPLETED'
    assert seen==[dict(selector_only=True,selection_horizon_months=6)]


@pytest.mark.parametrize('state',['all_hit','unqualified','missing'])
def test_full0_batch_dispatches_only_qualification_misses(full_inputs,tmp_path,monkeypatch,state):
    import time
    ids,centers,events=full_inputs
    plan=f5.compile_full_data_mice_plan(ids,None,centers,events,family=None,workers=None)
    application=next(t for t in f5.compile_full_data_search_mice_tasks(plan) if t['role']=='APPLICATION')
    final=f5.compile_final_full_data_mice_task(plan)
    tasks=[application,final]
    cov=valid_unfitted_mice_covariates(ids,centers)
    raw=('Patient_ID,All_Cause_Death,Death_Followup_months\n'+''.join(f'{p},{e},50\n' for p,e in zip(ids,events))).encode()
    fields,rows=f5._response_rows(raw)
    response=f5._write_response_subset(fields,rows,plan['source_ids'],None)['private_bytes']
    calls=[]
    def native(command,**kw):calls.append('REPLAY' if 'REPLAY' in command else 'FIT');return unfitted_full0_mice_run(command,**kw)
    monkeypatch.setattr(f5.subprocess,'run',native)
    jobs=[]
    for task in tasks:
        target=(tmp_path/'final-mice.zip' if task['phase']=='FINAL_MICE' else
            tmp_path/'mice'/task['split_id']/'application.zip')
        target.parent.mkdir(parents=True,exist_ok=True)
        job=dict(plan=plan,task=task,target=str(target),covariates=cov,response=response if task['role']=='ANALYSIS' else None,
            rscript='UNFITTED',retained_bytes_per_view=128*1024**2)
        f5._execute_full_data_mice_job(job)
        jobs.append(job)
    now=time.time_ns();monkeypatch.setattr(time,'time_ns',lambda:now+3_000_000_000)
    expected=[f5._execute_full_data_mice_job(job) for job in jobs]
    final_path=Path(jobs[-1]['target']);record=final_path.with_suffix('')/'.native.qualified.json'
    if state=='unqualified':
        value=strict_json_bytes(record.read_bytes());value['scientifically_validated']=False;record.write_bytes(enc(value))
    if state=='missing':final_path.rename(tmp_path/'retained-reference.zip')
    policy=dict(configured_worker_ceiling=runtime.CPU_MINUS_8,memory_bytes_per_worker=2*1024**3,
        scratch_bytes_per_worker=1024,memory_reserve_bytes=0,scratch_reserve_bytes=0,transfer_archive_worker_ceiling=1)
    sources=dict(plan=plan,resource_policy=policy,science_decision={},retained_bytes_per_view=128*1024**2,
        mice_root=str(tmp_path/'mice'),final_mice_path=str(final_path),rscript='UNFITTED')
    source=tmp_path/'full-development.json';source.write_bytes(enc(sources))
    input_path=tmp_path/'UNFITTED.csv';input_path.write_bytes(cov)
    monkeypatch.setattr(f5,'_read_final_lineage',lambda *a,**k:sources)
    monkeypatch.setattr(f5,'_full_development_science_decision',lambda *a,**k:None)
    monkeypatch.setattr(f5,'_full_development_raw_paths',lambda *a,**k:{'covariates':input_path})
    monkeypatch.setattr(f5,'_full_development_raw_inputs',lambda *a,**k:(cov,response,sha256_bytes(cov)))
    monkeypatch.setattr(runtime,'effective_cpu_count',lambda:9)
    monkeypatch.setattr(runtime,'observe_execution_resources',lambda root:dict(effective_cpus=9,
        available_memory_bytes=10**12,scratch_available_bytes=10**12,scratch_root=str(root)))
    owned={'worker':False};reads=[];original=f5._extract_full_data_mice_view
    def consume(*a,**k):
        assert owned['worker'],'NUMERIC_MISS_MUST_NOT_RUN_IN_PARENT';reads.append(1);return original(*a,**k)
    monkeypatch.setattr(f5,'_extract_full_data_mice_view',consume)
    pools=[]
    class MissingDispatched(Exception):pass
    def pool(worker,pending,**kwargs):
        pools.append([j['task']['view_id'] for j in pending]);assert pending==[jobs[-1]]
        if state=='missing':raise MissingDispatched()
        owned['worker']=True
        try:return [worker(job) for job in pending]
        finally:owned['worker']=False
    monkeypatch.setattr(f5,'_bounded_ordered_spawn',pool)
    monkeypatch.setattr(runtime,'run_ready_families',lambda *a,**k:pytest.fail('No second pool'))
    if state=='missing':
        with pytest.raises(MissingDispatched):
            f5.execute_full_data_mice_batch(source,tmp_path/'batch',view_ids=[t['view_id'] for t in reversed(tasks)])
    else:
        result=f5.execute_full_data_mice_batch(source,tmp_path/'batch',view_ids=[t['view_id'] for t in reversed(tasks)])
        assert result['results']==expected and result['mice_chains']==0
        if state=='all_hit':assert result['execution']['pool']['actual_worker_process_peak']==0
    assert len(pools)==int(state!='all_hit') and len(reads)==int(state=='unqualified')
    assert calls==['FIT','REPLAY']*2

from padml import f4, run as runs, integrated


_OLD_REVIEWED_MICE_PAIR = {'f1_nested_mice.R':'2cd3c7bf474c9416ebca3ade840adfd48a37dedefd49633c3a9cf04ce5bbf411',
    'f5_mice.R':'e53c44c71aa3a12117b74adbd34e4ed6a30a2c11bf8c73780aae927f81818850'}


def _unfitted_reviewed_mice_source(tmp_path,monkeypatch):
    """Only the already-audited whole-source admission is a synthetic leaf."""
    path=tmp_path/'run.json';path.write_bytes(b'{}')
    monkeypatch.setenv('PADML_F45_RUN_PATH',str(path))
    run={'kind':integrated.RUN_KIND,'run_root':str(tmp_path),'identity':'c'*64}
    monkeypatch.setattr(runs,'load_f45_run',lambda p:run)
    monkeypatch.setattr(runs,'f45_unit_predecessors',lambda run:[{'source_identity':'a'*64}])
    calls=[]
    def source(identity):
        assert identity=='a'*64;calls.append(identity)
        return {'padml/kernels/'+k:v for k,v in _OLD_REVIEWED_MICE_PAIR.items()}
    monkeypatch.setattr(f4,'_f45_same_run_source',source)
    return run,calls


@pytest.mark.parametrize('case',['exact','reviewed','no_run','not_integrated','unknown',
    'mixed_current','mixed_predecessors','missing_producer_member','keys','unreviewed'])
def test_mice_predecessor_requires_one_reviewed_complete_pair(tmp_path,monkeypatch,case):
    expected=f5._mice_native_sources();actual=dict(_OLD_REVIEWED_MICE_PAIR)
    run,calls=_unfitted_reviewed_mice_source(tmp_path,monkeypatch)
    if case=='exact':actual=expected
    elif case=='no_run':monkeypatch.delenv('PADML_F45_RUN_PATH')
    elif case=='not_integrated':run['kind']='NOT_CURRENT_RAW_RUN'
    elif case=='unknown':actual['f1_nested_mice.R']='f'*64
    elif case=='mixed_current':actual['f5_mice.R']=expected['f5_mice.R']
    elif case=='mixed_predecessors':
        second={'f1_nested_mice.R':'1'*64,'f5_mice.R':'2'*64}
        monkeypatch.setattr(runs,'f45_unit_predecessors',lambda run:[{'source_identity':'a'*64},{'source_identity':'b'*64}])
        monkeypatch.setattr(f4,'_f45_same_run_source',lambda identity:{'padml/kernels/'+k:v for k,v in
            (_OLD_REVIEWED_MICE_PAIR if identity=='a'*64 else second).items()})
        actual['f5_mice.R']=second['f5_mice.R']
    elif case=='missing_producer_member':
        # A missing old source member cannot authorize a null kernel pin.
        actual['f5_mice.R']=None
        monkeypatch.setattr(f4,'_f45_same_run_source',lambda identity:{
            'padml/kernels/f1_nested_mice.R':_OLD_REVIEWED_MICE_PAIR['f1_nested_mice.R']})
    elif case=='keys':actual.pop('f5_mice.R')
    elif case=='unreviewed':
        def rejected(run):raise ContractError('RAW_PREDECESSOR_SOURCE_DRIFT:padml/kernels/f1_nested_mice.R')
        monkeypatch.setattr(runs,'f45_unit_predecessors',rejected)
        with pytest.raises(ContractError,match='RAW_PREDECESSOR_SOURCE_DRIFT'):
            f5._mice_native_sources_match(actual,expected)
        return
    assert f5._mice_native_sources_match(actual,expected) is (case in {'exact','reviewed'})
    if case in {'exact','no_run','not_integrated','keys'}:assert calls==[]


@pytest.mark.parametrize('role',['ANALYSIS','APPLICATION'])
def test_old_mice_numeric_reader_preserves_producer_and_first_science(full_inputs,tmp_path,monkeypatch,role):
    import time
    # This reproduces the actual failure's exact two-file kernel pin difference.
    # It is a layout/consumer test, not a claim to have refit clinical MICE.
    ids,centers,events=full_inputs
    plan=f5.compile_full_data_mice_plan(ids,None,centers,events,family=None,workers=None)
    task=(f5.compile_final_full_data_mice_task(plan) if role=='ANALYSIS' else next(
        t for t in f5.compile_full_data_search_mice_tasks(plan) if t['role']=='APPLICATION'))
    cov=valid_unfitted_mice_covariates(ids,centers)
    response=('Patient_ID,All_Cause_Death,Death_Followup_months\n'+''.join(f'{p},{e},50\n' for p,e in zip(ids,events))).encode()
    fields,rows=f5._response_rows(response);_,fit_ids,_=f5._mice_view_rows(plan,task)
    response=f5._write_response_subset(fields,rows,fit_ids,None)['private_bytes'] if role=='ANALYSIS' else None
    native_calls=[]
    def native(command,**kw):native_calls.append('REPLAY' if 'REPLAY' in command else 'FIT');return unfitted_full0_mice_run(command,**kw)
    monkeypatch.setattr(f5.subprocess,'run',native)
    target=tmp_path/'old-view.zip'
    job={'plan':plan,'task':task,'covariates':cov,'response':response,'target':str(target),
        'rscript':'UNFITTED','retained_bytes_per_view':128*1024**2}
    with monkeypatch.context() as old:
        old.delenv('PADML_F45_RUN_PATH',raising=False)
        old.setattr(f5,'_mice_native_sources',lambda:dict(_OLD_REVIEWED_MICE_PAIR))
        f5._execute_full_data_mice_job(job)
    assert native_calls==['FIT','REPLAY']
    native_path=target.with_suffix('')/'native-view.zip'
    before={str(p):sha256_file(p) for p in [target,native_path]}
    with zipfile.ZipFile(target) as z:
        members={name:z.read(name) for name in z.namelist()}
    original_manifest=members['manifest.json']
    assert strict_json_bytes(original_manifest)['native_sources']==_OLD_REVIEWED_MICE_PAIR
    _unfitted_reviewed_mice_source(tmp_path,monkeypatch)
    now=time.time_ns();monkeypatch.setattr(time,'time_ns',lambda:now+3_000_000_000)
    binding={'plan':plan,'task':task,'covariates_sha256':sha256_bytes(cov),
        'response_sha256':None if response is None else sha256_bytes(response),
        'consumer_source_sha256':f5._nested_science._sha(f4._f45_source_member_sha256())}
    record=target.with_suffix('')/'.native.qualified.json'
    integrated.qualified_file_pins({'view':target,'native':native_path},identity=binding,record=record)
    assert strict_json_bytes(record.read_bytes())['scientifically_validated'] is False
    assert f5._execute_full_data_mice_job(job,_cached_only=True) is None
    consumed=[];original=f5._extract_full_data_mice_view
    def consume(*a,**kw):consumed.append(1);return original(*a,**kw)
    monkeypatch.setattr(f5,'_extract_full_data_mice_view',consume)
    value=f5._execute_full_data_mice_job(job)
    assert len(consumed)==1 and strict_json_bytes(record.read_bytes())['scientifically_validated'] is True
    assert f5._execute_full_data_mice_job(job,_cached_only=True)==value and len(consumed)==1
    assert {str(p):sha256_file(p) for p in [target,native_path]}==before
    with zipfile.ZipFile(target) as z:assert z.read('manifest.json')==original_manifest
    # Approved old code admits no altered scientific input or incomplete values.
    for damage in ('mixed','task','plan','member','raw','numbers'):
        changed=dict(members);manifest=strict_json_bytes(changed['manifest.json'])
        if damage=='mixed':manifest['native_sources']['f5_mice.R']=f5._mice_native_sources()['f5_mice.R']
        elif damage in {'task','plan'}:manifest[damage+'_sha256']='f'*64
        elif damage=='member':manifest['members']['imputations/imp01.csv']['sha256']='f'*64
        elif damage=='raw':changed['inputs/covariates.csv']+=b'\n'
        else:
            numbers=strict_json_bytes(changed['mice-numbers.json']);numbers['summary']['final_iteration']=20
            changed['mice-numbers.json']=enc(numbers)
        changed['manifest.json']=enc(manifest)
        broken=tmp_path/(damage+'.zip')
        with zipfile.ZipFile(broken,'w',zipfile.ZIP_DEFLATED) as z:
            for name,data in changed.items():z.writestr(name,data)
        with pytest.raises(ContractError):original(plan,task,broken,tmp_path/('rejected-'+damage))
    assert native_calls==['FIT','REPLAY']
