"""Native arithmetic/consumer regressions; no clinical model fits."""
import json
import math
import os
from pathlib import Path
import random
import shutil
import subprocess

import pytest

from padml.f2_validation import _fpm_piece_arithmetic

ROOT = Path(__file__).parents[1]


@pytest.fixture(scope="module")
def arithmetic_runtime(tmp_path_factory):
    rscript, r = shutil.which("Rscript"), shutil.which("R")
    if not rscript or not r:
        pytest.skip("R compiler is required for the native arithmetic regression")
    folder = tmp_path_factory.mktemp("fpm-arithmetic")
    patch = (ROOT/"padml/kernels/rstpm2-feasible.patch").read_text()
    cpp = patch.split("+++ b/src/padml-ph-arithmetic.cpp\n",1)[1].split("--- /dev/null\n",1)[0]
    domain = patch.split("+++ b/R/padml-ph-domain.R\n",1)[1]
    for name, section in (("padml-ph-arithmetic.cpp",cpp),("domain.R",domain)):
        source = "\n".join(line[1:] for line in section.splitlines()[1:] if line.startswith("+"))+"\n"
        (folder/name).write_text(source)
    build = subprocess.run([r,"CMD","SHLIB","padml-ph-arithmetic.cpp"],cwd=folder,
                           capture_output=True,text=True,timeout=120)
    assert build.returncode == 0, build.stdout+build.stderr
    prefix = r'''
suppressPackageStartupMessages(library(jsonlite))
root <- commandArgs(trailingOnly=TRUE)[[1]]
dyn.load(file.path(root,"padml-ph-arithmetic.so"))
source <- gsub('PACKAGE="rstpm2"','PACKAGE="padml-ph-arithmetic"',
               readLines(file.path(root,"domain.R")),fixed=TRUE)
eval(parse(text=source))
'''
    def run(code, *args):
        p = subprocess.run([rscript,"-e",prefix+code,str(folder),*args],
                           capture_output=True,text=True,timeout=120)
        assert p.returncode == 0, p.stdout+p.stderr
        return json.loads(p.stdout.splitlines()[-1])
    return folder, run


def test_native_exact_polynomials_and_numerical_errors(arithmetic_runtime):
    folder, run = arithmetic_runtime
    beta = [1.]*16
    matrices = []
    for exponent in (-100,0,100,500):
        for delta in (-2.**-54,0.,2.**-54):
            matrices.append([[2.**exponent,.25,-2.**exponent,delta]+[0.]*12,
                             [-1.]+[0.]*15,[1.]+[0.]*15])
    rng = random.Random(918274)
    matrices.extend([[[rng.uniform(-10,10) for _ in beta] for _ in range(3)] for _ in range(120)])
    (folder/"input.json").write_text(json.dumps({"matrices":matrices,"beta":beta}))
    answer = run(r'''
x <- fromJSON(file.path(root,"input.json"),simplifyVector=FALSE)
m <- lapply(x$matrices,function(p)do.call(rbind,lapply(p,unlist)))
out <- .Call("padml_ph_arithmetic",m,unlist(x$beta),NULL,PACKAGE="padml-ph-arithmetic")
out <- lapply(out,function(p)list(q=as.list(p$q),minimum=p$minimum,location=p$location,
                                values=as.list(p$values),coordinates=as.list(p$coordinates)))
errors <- lapply(list(c(1e308,1e308),c(1e-300,1e-300)),function(pair) {
  e <- tryCatch(.Call("padml_ph_arithmetic",list(matrix(c(pair[1],0,0),ncol=1)),
                     pair[2],NULL,PACKAGE="padml-ph-arithmetic"),error=identity)
  stopifnot(inherits(e,"error"));conditionMessage(e)
})
stopifnot(identical(errors,list("PADML_FPM_ARITHMETIC_OVERFLOW","PADML_FPM_ARITHMETIC_UNDERFLOW")))
cat(toJSON(out,auto_unbox=TRUE,digits=I(17)),"\n")
''')
    for matrix, actual in zip(matrices, answer, strict=True):
        expected = _fpm_piece_arithmetic(matrix,beta)
        for key, value in actual.items():
            pairs = zip(value,expected[key],strict=True) if isinstance(value,list) else [(value,expected[key])]
            for a,b in pairs:
                assert (a>0)-(a<0) == (b>0)-(b<0)
                assert math.isclose(a,b,rel_tol=4e-15,abs_tol=1e-32)


@pytest.mark.parametrize("anchor", [0,1])
def test_consistent_cuts_preserve_moving_boundary_and_budget(arithmetic_runtime, anchor):
    _, run = arithmetic_runtime
    answer = run(r'''
anchor <- as.numeric(commandArgs(trailingOnly=TRUE)[[2]])
geometry <- list(pieces=list(list(exposure=0,lower=0,upper=1,
  derivative=rbind(c(1,0,0,0),c(0,1,0,0),c(0,0,1,0)))),
  interior_direction=c(1,0,0,anchor))
control <- list(maxit=100L,reltol=1e-10,parscale=rep(1,4),trace=0)
target <- c(.25,-1,1,3)-c(1,.5,.25,0)
f <- function(x)sum((x-target)^2)/2
g <- function(x)x-target
calls <- list()
trace("optim",where=asNamespace("stats"),print=FALSE,tracer=quote({
  calls[[length(calls)+1L]] <<- list(method=method,maxit=control$maxit,reltol=control$reltol)
}))
fit <- padml_ph_constr_optim(c(1,-1,1,-3),f,g,
 rbind(c(1,0,0,0),c(1,1,1,0)),geometry,control,1e-5)
state <- padml_ph_domain_state(geometry,fit$par)
check <- padml_ph_optimality(geometry,fit$par,g(fit$par),f(fit$par))
stopifnot(fit$convergence==0L,check$converged,state$minimum>0,
 max(abs(fit$par-c(.25,-1,1,3)))<1e-4,fit$outer.iterations<=10L,
 length(calls)==fit$outer.iterations,
 identical(state$values,padml_ph_cut_values(geometry,fit$par,state$cuts)),
 all(vapply(calls,function(p)p$method=="BFGS"&&p$maxit==100L&&p$reltol==1e-10,logical(1))))
cat(toJSON(list(rounds=fit$outer.iterations,stationarity=check$stationarity,
                complementarity=check$complementarity),auto_unbox=TRUE,digits=I(17)),"\n")
''', str(anchor))
    assert answer["rounds"] <= 10
    assert answer["stationarity"] <= 1e-5
    assert 0 <= answer["complementarity"] <= 1e-10


def test_retained_false_positive_is_rejected_without_fitting(arithmetic_runtime):
    archive = os.environ.get("PADML_TEST_FPM_ARITHMETIC_ARCHIVE")
    if not archive:
        pytest.skip("Provide the retained failed native fit ZIP for the zero-fit regression")
    _, run = arithmetic_runtime
    answer = run(r'''
suppressPackageStartupMessages(library(rstpm2))
trace("stpm2",where=asNamespace("rstpm2"),print=FALSE,tracer=quote(stop("NO_FITS")))
trace("optim",where=asNamespace("stats"),print=FALSE,tracer=quote(stop("NO_OPTIMIZER")))
con <- gzcon(unz(commandArgs(trailingOnly=TRUE)[[2]],"fit.rds","rb"))
fit <- readRDS(con);close(con)
state <- padml_ph_domain_state(fit@args$padml_domain_geometry,as.numeric(coef(fit)))
stopifnot(state$minimum<0,fit@details$convergence==7L)
cat(toJSON(list(minimum=state$minimum,fit_calls=0L),auto_unbox=TRUE,digits=I(17)),"\n")
''', archive)
    assert answer["fit_calls"] == 0
    assert answer["minimum"] < 0
