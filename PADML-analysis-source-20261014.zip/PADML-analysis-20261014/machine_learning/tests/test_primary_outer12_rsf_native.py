"""Synthetic PRIMARY RSF native routing; original preparation still forbids fits."""
import copy
import json
from pathlib import Path
import shutil
from types import SimpleNamespace

import pytest

from padml import f2_kernel as kernel, f4, f5, f4_compact as compact, nested_loco as nested
from padml.bundle import ContractError, canonical_json_bytes


def _spec(tmp_path, outer=1):
    source = {"program_id": nested.PROGRAM_ID, "channel": "PRIMARY", "family": "RSF",
        "outer_fold": outer, "heldout_center": nested.OUTER_CENTERS[outer - 1],
        "selection_horizon_months": 12, **{name: "a" * 64 for name in (
            "training_context_sha256", "science_decision_sha256", "producer_source_identity",
            "f1_identity", "f2_acceptance_sha256", "accepted_rsf_result_sha256",
            "selector_evidence_sha256", "selector_recipe_set_sha256")}}
    return {"schema_version": "1.0.0", "execution_scope": "F2_OUTER_DEVELOPMENT",
        "action": "MODEL_PREDICTION_BATCH", "primary_search_source": source,
        "family": "RSF", "fold": outer, "heldout_center": source["heldout_center"],
        "seed": 300000 + 1000 * outer, "imputation_count": 20,
        "outcome": "All_Cause_Death", "time": "Death_Followup_months", "predictors": {}, "fpm": None,
        "horizons": list(range(1, 37)), "selection_horizon_months": 12,
        "trial_scoring": {**f4.load_science_authority()["science"]["f2_model_development"]["trial_scoring"],
            "ibs_grid_months": list(range(13)), "ibs_integration": "TRAPEZOID_DIVIDE_BY_12"},
        "selector_from_dependency": {"selected_parents": ["AST_ALT"], "outer_recipe_sha256": "b" * 64},
        "native_search_root": str(tmp_path / "q/native"), "native_search_replay": False,
        "registered_inputs_identity_sha256": "c" * 64,
        "registered_partitions": {"partitions": [{"partition_id": f"INNER_F{outer}_R1_K1",
            "covariates": {"input_dir": "/UNFITTED/input", "data_identity": "b" * 64},
            "fit_response": {"path": "/UNFITTED/response", "sha256": "c" * 64}}]},
        "producer_tasks": [{"task_id": f"S1_T{trial:03d}_P01_M01", "family": "RSF",
            "partition_id": f"INNER_F{outer}_R1_K1", "imputation": 1, "parameters": {"UNFITTED": trial},
            "seed": 310101 + 1000 * outer} for trial in (1, 2)]}


@pytest.mark.parametrize("outer,family", [(outer, "RSF") for outer in range(1, 7)] + [(1, "GBM_COX")])
def test_primary_child_preserves_native_and_source_binding(tmp_path, outer, family):
    spec = _spec(tmp_path, outer)
    if family != "RSF":
        spec["family"] = spec["primary_search_source"]["family"] = family
        spec["primary_search_source"]["accepted_model_result_sha256"] = spec["primary_search_source"].pop("accepted_rsf_result_sha256")
    child = kernel._r_prediction_child_spec(spec)
    assert all(child[name] == spec[name] for name in ("primary_search_source", "native_search_root",
        "native_search_replay", "registered_inputs_identity_sha256", "selection_horizon_months", "trial_scoring"))
    assert not compact._full_pipeline_q_numbers_mode(child)
    assert compact._full_pipeline_q_numbers_mode({**child, "native_search_replay": True, "native_search_numbers": True})
    with pytest.raises(ContractError, match="NUMERICAL_SCOPE_INVALID"):
        compact._full_pipeline_q_numbers_mode({**child, "native_search_numbers": True})


@pytest.mark.parametrize("stop,prepare", [(True, False), (False, False), (True, True),
                                        (True, "fit-mode"), (True, "existing")])
def test_primary_gbm_preserves_original_stop_and_refit_batching(tmp_path, monkeypatch, stop, prepare):
    spec = _spec(tmp_path)
    spec.update(family="GBM_COX", execution_mode="PROCESS_POOL", threads=56,
                pool_workers=56, engine_threads=1)
    spec["primary_search_source"]["family"] = "GBM_COX"
    source = spec["primary_search_source"]
    source["accepted_model_result_sha256"] = source.pop("accepted_rsf_result_sha256")
    suffix = "STOP" if stop else "REFIT"
    tasks = [{"task_id": f"S1_T{trial:03d}_P{part:02d}_M01_{suffix}",
        "partition_id": f"{'STOP' if stop else 'INNER'}_F1_R1_K{part}",
        "imputation": 1, "family": "GBM_COX",
        "producer_kind": "GBM_STOP_CURVE" if stop else "SURVIVAL"}
        for trial in range(1, 29) for part in range(1, 6)]
    # Isolate physical partition materialization; original batching and child
    # source projection remain active. No native or numeric leaf is invoked.
    monkeypatch.setattr(kernel, "_engine_registered_partitions", lambda registered, ids: registered)
    seen = []
    if prepare:
        q = Path(spec["native_search_root"]).parent
        q.mkdir()
        (q / "input.json").write_bytes(canonical_json_bytes({"spec": spec}))
        spec["native_search_batch"] = {"prepare_only": True, "task_ids": None,
            "completed": {}, "batches": [], "used_batches": [],
            "confirmed_model_fits": 0, "confirmed_stop_fits": 0}
        if prepare == "fit-mode": spec["native_search_batch"]["prepare_only"] = False
        if prepare == "existing": spec["native_search_batch"]["batches"] = [(q, {"SYNTHETIC": True})]
    def batches(value, function, calls, *, selected_slots):
        assert selected_slots == 56 and function is kernel._run_r_prediction_pool_task
        assert all(call[0]["primary_search_source"] == source for call in calls)
        seen.extend(call[2] for call in calls)
        if prepare:
            return f5._q_search_task_batch(value, function, calls)
        return [[{"task_id": row["task_id"]} for row in call[2]] for call in calls]
    monkeypatch.setattr(kernel, "_search_task_batch", batches)
    if prepare:
        # Use the original Q boundary, not a stand-in publisher or native leaf.
        registered = {"partitions": [{"partition_id": f"STOP_F1_R1_K{part}"} for part in range(1, 6)]}
        if prepare is not True:
            with pytest.raises(ContractError, match="F5_PRIMARY_GBM_PREPARATION_ONLY"):
                kernel._run_r_prediction_batch(spec, registered, tasks, tmp_path, tmp_path,
                    evaluation_mode="GROUPED_COX_LOCK")
            return
        with pytest.raises(f5._QBatchBoundary) as caught:
            kernel._run_r_prediction_batch(spec, registered, tasks, tmp_path, tmp_path,
                evaluation_mode="GROUPED_COX_LOCK")
        boundary = caught.value.result
        assert boundary["new_model_fits"] == boundary["new_stop_fits"] == 0
        assert boundary["worker_inputs_ready"] is False and len(boundary["next_atomic_units"]) == 140
        assert [atom["producer_tasks"][0] for atom in boundary["next_atomic_units"]] == tasks
        return
    result = kernel._run_r_prediction_batch(spec, {"partitions": []}, tasks, tmp_path, tmp_path)
    assert [row["task_id"] for row in result] == [row["task_id"] for row in tasks]
    assert len(seen) == (140 if stop else 70)
    assert all(len(batch) == (1 if stop else 2) for batch in seen)
    assert all(len({row["partition_id"] for row in batch}) == 1 for batch in seen)


@pytest.mark.parametrize("damage", ["missing-source", "null", "channel", "family", "outer", "center", "horizon", "scope", "alias", "missing-pin"])
def test_primary_source_rejects_other_scientific_roles(tmp_path, damage):
    spec = _spec(tmp_path)
    if damage == "missing-source": del spec["primary_search_source"]
    elif damage == "null": spec["primary_search_source"] = None
    elif damage == "channel": spec["primary_search_source"]["channel"] = "AAR"
    elif damage == "family": spec["family"] = "GBM_COX"
    elif damage == "outer": spec["primary_search_source"]["outer_fold"] = 0
    elif damage == "center": spec["heldout_center"] = 55
    elif damage == "horizon": spec["selection_horizon_months"] = 24
    elif damage == "scope": spec["execution_scope"] = "F5_FULL_DEVELOPMENT_SEARCH"
    elif damage == "alias": spec["a12_source"] = {}
    else: del spec["primary_search_source"]["training_context_sha256"]
    with pytest.raises(ContractError, match="PRIMARY_RSF_SEARCH_SOURCE_INVALID"):
        kernel._r_prediction_child_spec(spec)
    with pytest.raises(ContractError, match="PRIMARY_RSF_SEARCH_SOURCE_INVALID"):
        compact._full_pipeline_q_numbers_mode({**spec, "native_search_replay": True, "native_search_numbers": True})


@pytest.mark.parametrize("stop", [True, False])
@pytest.mark.parametrize("damage", [None, "seed", "partition", "mixed-kind", "trial"])
def test_primary_gbm_native_preserves_original_atomic_scope(tmp_path, monkeypatch, stop, damage):
    spec = _spec(tmp_path)
    spec["output_path"] = str(tmp_path / "output.json")
    spec["family"] = spec["primary_search_source"]["family"] = "GBM_COX"
    source = spec["primary_search_source"]
    source["accepted_model_result_sha256"] = source.pop("accepted_rsf_result_sha256")
    suffix = "STOP" if stop else "REFIT"
    spec["producer_tasks"] = [{"task_id": f"S1_T{trial:03d}_P01_M01_{suffix}",
        "family": "GBM_COX", "partition_id": f"{'STOP' if stop else 'INNER'}_F1_R1_K1",
        "imputation": 1, "parameters": {"UNFITTED": trial}, "seed": 311101,
        "producer_kind": "GBM_STOP_CURVE" if stop else "SURVIVAL"}
        for trial in ([1] if stop else [1, 2])]
    row = spec["producer_tasks"][0]
    if damage == "seed": row["seed"] += 1
    elif damage == "partition": row["partition_id"] = "INNER_F2_R1_K1"
    elif damage == "mixed-kind": row["producer_kind"] = "SURVIVAL" if stop else "GBM_STOP_CURVE"
    elif damage == "trial": row["task_id"] = f"S1_T029_P01_M01_{suffix}"
    (tmp_path / "q/native").mkdir(parents=True)
    path = tmp_path / "spec.json"
    path.write_bytes(canonical_json_bytes(spec))
    called = []
    def native(command, **kwargs):
        assert damage is None
        value = json.loads(Path(command[-1]).read_bytes())
        assert value["producer_tasks"] == spec["producer_tasks"]
        assert value["primary_search_source"] == source
        called.append(value)
        Path(value["output_path"]).write_bytes(canonical_json_bytes({"UNFITTED": True}))
        return SimpleNamespace(returncode=0)
    monkeypatch.setattr(f4.subprocess, "run", native)
    if damage:
        with pytest.raises(ContractError, match="PRIMARY_GBM_ATOMIC_GEOMETRY_INVALID"):
            f4._run_full_pipeline_r_search_batch(path, tmp_path / "output.json", tmp_path, {})
        assert not called
    else:
        assert f4._run_full_pipeline_r_search_batch(path, tmp_path / "output.json", tmp_path, {}) == {"UNFITTED": True}
        assert len(called) == 1


@pytest.mark.parametrize("family,count", [("XGBOOST_COX", 200), ("COXTIME_SET_A", 60)])
@pytest.mark.parametrize("damage", [None, "missing", "fit-mode"])
def test_primary_python_stop_reaches_original_zero_fit_boundary(tmp_path, monkeypatch, family, count, damage):
    spec = _spec(tmp_path)
    spec["family"] = spec["primary_search_source"]["family"] = family
    source = spec["primary_search_source"]
    source["accepted_model_result_sha256"] = source.pop("accepted_rsf_result_sha256")
    q = Path(spec["native_search_root"]).parent
    q.mkdir()
    (q / "input.json").write_bytes(canonical_json_bytes({"spec": spec}))
    spec["native_search_batch"] = {"prepare_only": damage != "fit-mode", "task_ids": None,
        "completed": {}, "batches": [], "used_batches": [], "confirmed_model_fits": 0,
        "confirmed_stop_fits": 0}
    _, ids = f5._a12_q_stop_phase("S1", family=family)
    tasks = [{"task_id": name, "spec": spec, "registered": {"SYNTHETIC": True},
              "parameters": {"SYNTHETIC": True}, "handoff_path": "/UNFITTED/function"} for name in ids]
    if damage == "missing": tasks.pop()
    def boundary(value, function, calls, **kwargs):
        assert function is kernel._run_python_stop_pair_pool_task
        return f5._q_search_task_batch(value, function, calls)
    monkeypatch.setattr(kernel, "_search_task_batch", boundary)
    if damage:
        with pytest.raises(ContractError):
            kernel._search_python_stop_batch(spec, tasks, [{} for _ in tasks], selected_slots=56)
        return
    with pytest.raises(f5._QBatchBoundary) as caught:
        kernel._search_python_stop_batch(spec, tasks, [{} for _ in tasks], selected_slots=56)
    result = caught.value.result
    assert result["task_ids"] == ids and len(result["next_atomic_units"]) == count
    assert result["new_model_fits"] == result["new_stop_fits"] == 0
    assert result["worker_inputs_ready"] is False
    assert all(set(atom["producer_tasks"][0]) == {"task_id", "parameters"}
               for atom in result["next_atomic_units"])


def test_primary_gbm_original_stop_consumer_retains_complete_losses(tmp_path):
    spec = _spec(tmp_path)
    spec["family"] = spec["primary_search_source"]["family"] = "GBM_COX"
    source = spec["primary_search_source"]
    source["accepted_model_result_sha256"] = source.pop("accepted_rsf_result_sha256")
    task = {"task_id": "S1_T001_P01_M01_STOP", "family": "GBM_COX",
            "producer_kind": "GBM_STOP_CURVE"}
    spec["producer_tasks"] = [task]
    root = Path(spec["native_search_root"]) / ("batch-" + kernel._sha([task["task_id"]])[:24])
    root.mkdir(parents=True)
    (root / "output.json").write_bytes(canonical_json_bytes({"SYNTHETIC_NATIVE": True}))
    losses = {"trees": [1, 2, 3], "loss": [3.0, 1.0, 2.0]}
    result = {"selected_trees": 2, "SYNTHETIC": True}
    def evaluate(*, native_evaluation):
        native_evaluation.update(losses)
        return result
    assert f4._full_pipeline_gbm_stop_evaluate(spec, task, {}, {}, {}, evaluate) == result
    saved = json.loads((root / "evaluation.json").read_bytes())
    assert saved["evaluated_path"] == losses and saved["result"] == result
    assert saved["task_sha256"] == kernel._sha(task)


@pytest.mark.parametrize("damage", ["half", "duplicate", "stage", "partition", "imputation", "seed", "producer-kind"])
def test_primary_native_rejects_non_original_s1_atom_before_engine(tmp_path, monkeypatch, damage):
    spec = _spec(tmp_path)
    if damage == "half": spec["producer_tasks"].pop()
    elif damage == "duplicate": spec["producer_tasks"][1] = copy.deepcopy(spec["producer_tasks"][0])
    elif damage == "stage": spec["producer_tasks"][0]["task_id"] = "S2_T001_P01_M01"
    elif damage == "partition": spec["producer_tasks"][1]["partition_id"] = "INNER_R1_K2"
    elif damage == "imputation": spec["producer_tasks"][0]["imputation"] = 2
    elif damage == "seed": spec["producer_tasks"][0]["seed"] += 1
    else: spec["producer_tasks"][0]["producer_kind"] = "SURVIVAL"
    path = tmp_path / "spec.json"
    path.write_bytes(canonical_json_bytes(spec))
    monkeypatch.setattr(f4.subprocess, "run", lambda *a, **k: pytest.fail("invalid atom invoked R"))
    with pytest.raises(ContractError, match="PRIMARY_RSF_S1_ATOMIC_GEOMETRY_INVALID"):
        f4._run_full_pipeline_r_search_batch(path, tmp_path / "output.json", tmp_path, {})
    assert not (tmp_path / "q").exists()


@pytest.mark.parametrize("replay", [False, True])
@pytest.mark.parametrize("gbm_stop", [False, True])
def test_primary_partition_routes_to_retained_native_consumer(tmp_path, monkeypatch, replay, gbm_stop):
    from padml import runtime
    spec = _spec(tmp_path)
    spec["native_search_replay"] = replay
    registered = spec["registered_partitions"]
    registered.update(projected_partition_ids=["INNER_F1_R1_K1"], projected_partition_count=1)
    evaluation = None
    if gbm_stop:
        spec["family"] = spec["primary_search_source"]["family"] = "GBM_COX"
        source = spec["primary_search_source"]
        source["accepted_model_result_sha256"] = source.pop("accepted_rsf_result_sha256")
        spec["producer_tasks"] = [{**spec["producer_tasks"][0], "family": "GBM_COX",
            "task_id": "S1_T001_P01_M01_STOP", "partition_id": "STOP_F1_R1_K1",
            "producer_kind": "GBM_STOP_CURVE"}]
        registered["projected_partition_ids"] = ["STOP_F1_R1_K1"]
        registered["partitions"][0].update(partition_id="STOP_F1_R1_K1", fit_ids=["fit"],
            evaluation_ids=["stop"], evaluation_ids_sha256="d" * 64)
        evaluation = {**registered["partitions"][0], "evaluation_response": {"SYNTHETIC": True}}
    calls, environments = [], []
    monkeypatch.delenv("R_LIBS_USER", raising=False)
    monkeypatch.setenv("OMP_NUM_THREADS", "64")
    def native_boundary(path, output, repo, environment):
        calls.append(json.loads(path.read_bytes()))
        environments.append(environment)
        return {"UNFITTED": True}
    monkeypatch.setattr(kernel, "_execute_r_prediction", lambda *a, **k: pytest.fail("generic R fit fallback"))
    monkeypatch.setattr(f4, "_run_full_pipeline_r_search_batch", native_boundary)
    callbacks = []
    def retain(engine_spec, task, sealed, partition, context, evaluate):
        assert engine_spec["primary_search_source"] == spec["primary_search_source"]
        callbacks.append(task)
        return {"SYNTHETIC_STOP": True}
    monkeypatch.setattr(f4, "_full_pipeline_gbm_stop_evaluate", retain)
    def consume(*args, **kwargs):
        callback = kwargs["gbm_stop_evaluate"]
        if gbm_stop:
            assert callable(callback)
            assert callback(spec["producer_tasks"][0], {}, evaluation, {}, None) == {"SYNTHETIC_STOP": True}
        else:
            assert callback is None
        return []
    monkeypatch.setattr(kernel, "_consume_r_prediction", consume)
    assert kernel._run_r_prediction_partition_batch(spec, registered, spec["producer_tasks"],
        tmp_path, tmp_path, evaluation_mode="GROUPED_COX_LOCK" if gbm_stop else "NONE",
        evaluation_partition=evaluation) == []
    assert callbacks == (spec["producer_tasks"] if gbm_stop else [])
    assert len(calls) == 1 and calls[0]["native_search_replay"] is replay
    assert calls[0]["primary_search_source"] == spec["primary_search_source"]
    assert not kernel._contains_key(calls[0], "evaluation_response")
    assert environments[0]["R_LIBS_USER"] == runtime.R_LIBRARY
    assert all(environments[0][key] == value for key, value in runtime.THREAD_ENV.items())


def test_missing_primary_source_cannot_reach_generic_fit(tmp_path, monkeypatch):
    spec = _spec(tmp_path)
    del spec["primary_search_source"]
    registered = spec["registered_partitions"]
    registered.update(projected_partition_ids=["INNER_F1_R1_K1"], projected_partition_count=1)
    monkeypatch.setattr(kernel, "_execute_r_prediction", lambda *a, **k: pytest.fail("generic R fit fallback"))
    monkeypatch.setattr(f4.subprocess, "run", lambda *a, **k: pytest.fail("missing source invoked R"))
    with pytest.raises(ContractError, match="PRIMARY_RSF_SEARCH_SOURCE_INVALID"):
        kernel._run_r_prediction_partition_batch(spec, registered, spec["producer_tasks"], tmp_path, tmp_path)


@pytest.mark.parametrize("stage,imputation", [("S1", 1), ("S2", 5), ("S3A", 1), ("S3A", 20), ("S3B1", 5), ("S3B2", 17)])
def test_primary_native_first_audit_then_numbers_without_r_or_models(tmp_path, monkeypatch, stage, imputation):
    spec = _spec(tmp_path)
    if stage == "S3B2":
        spec["producer_tasks"] = [{"task_id": f"S3B2_T001_P15_M{imp:02d}",
            "family": "RSF", "partition_id": "INNER_F1_R3_K5", "imputation": imp,
            "parameters": {"UNFITTED": 1}, "seed": spec["seed"] + 50000 + 100 * imp + 15}
            for imp in range(imputation, imputation + 4)]
    elif stage != "S1":
        repeat = 2 if stage == "S2" else 3
        part = 15 if stage == "S3B1" else 1
        spec["producer_tasks"] = [{"task_id": f"{stage}_T{trial:03d}_P{part:02d}_M{imputation:02d}",
            "family": "RSF", "partition_id": f"INNER_F1_R{repeat}_K{5 if stage == 'S3B1' else 1}", "imputation": imputation,
            "parameters": {"UNFITTED": trial}, "seed": spec["seed"] + (40000 if stage == "S3B1" else repeat*10000) + 100*imputation + part}
            for trial in range(1, 3 if stage == "S3B1" else 4)]
    q = tmp_path / "q"
    (q / "native").mkdir(parents=True)
    (q / "input.json").write_bytes(canonical_json_bytes({"spec": spec, "UNFITTED": True}))
    calls = []
    def native(command, **kwargs):
        current = json.loads(Path(command[-1]).read_bytes())
        assert Path(command[-2]).name == "f4_gbm_stop.R"
        calls.append(current["native_search_replay"])
        for task in current["producer_tasks"]:
            owned = Path(current["native_search_root"]) / task["task_id"]
            if not current["native_search_replay"]:
                owned.mkdir()
                (owned / "model.rds").write_bytes(b"UNFITTED_NATIVE_OBJECT")
            else:
                assert (owned / "model.rds").read_bytes() == b"UNFITTED_NATIVE_OBJECT"
        Path(current["output_path"]).write_bytes(canonical_json_bytes({"UNFITTED": True}))
        return SimpleNamespace(returncode=0)
    monkeypatch.setattr(f4.subprocess, "run", native)
    for replay in (False, True):
        work = tmp_path / str(replay)
        work.mkdir()
        current = {**spec, "native_search_replay": replay, "output_path": str(work / "output.json")}
        (work / "spec.json").write_bytes(canonical_json_bytes(current))
        assert f4._run_full_pipeline_r_search_batch(work / "spec.json", work / "output.json", tmp_path, {}) == {"UNFITTED": True}
    (q / "result.json").write_bytes(canonical_json_bytes({"UNFITTED": True}))
    projection, _ = compact._full_pipeline_q_numerical_members(q, publish=True)
    target = tmp_path / "numbers"
    for name, source in projection.items():
        path = target / name
        path.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, path)
    assert not list(target.rglob("*.rds"))
    compact._full_pipeline_q_numerical_members(target)
    monkeypatch.setattr(f4.subprocess, "run", lambda *a, **k: pytest.fail("numbers invoked R"))
    current = {**spec, "native_search_root": str(target / "native"), "native_search_replay": True,
        "native_search_numbers": True, "output_path": str(tmp_path / "numbers-output.json")}
    path = tmp_path / "numbers-spec.json"
    path.write_bytes(canonical_json_bytes(current))
    assert f4._run_full_pipeline_r_search_batch(path, Path(current["output_path"]), tmp_path, {}) == {"UNFITTED": True}
    assert calls == [False, True]


@pytest.mark.parametrize("damage", ["half", "seed", "repeat", "mi", "trial"])
def test_primary_s3a_native_rejects_changed_atom_before_r(tmp_path, monkeypatch, damage):
    spec = _spec(tmp_path)
    spec["producer_tasks"] = [{"task_id": f"S3A_T{trial:03d}_P01_M20", "family": "RSF",
        "partition_id": "INNER_F1_R3_K1", "imputation": 20, "parameters": {"UNFITTED": trial},
        "seed": 333001} for trial in range(1, 4)]
    if damage == "half": spec["producer_tasks"].pop()
    elif damage == "seed": spec["producer_tasks"][0]["seed"] += 1
    elif damage == "repeat": spec["producer_tasks"][0]["partition_id"] = "INNER_F1_R2_K1"
    elif damage == "mi": spec["producer_tasks"][0]["imputation"] = 21
    else: spec["producer_tasks"][0]["task_id"] = "S3A_T004_P01_M20"
    path = tmp_path / "spec.json"; path.write_bytes(canonical_json_bytes(spec))
    monkeypatch.setattr(f4.subprocess, "run", lambda *a, **k: pytest.fail("invalid S3A reached R"))
    with pytest.raises(ContractError, match="ATOMIC_GEOMETRY_INVALID"):
        f4._run_full_pipeline_r_search_batch(path, tmp_path / "output.json", tmp_path, {})
