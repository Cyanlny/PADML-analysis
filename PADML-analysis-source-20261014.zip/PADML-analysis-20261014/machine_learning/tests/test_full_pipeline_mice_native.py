"""Full-pipeline MICE transport tests; native fitting is always prohibited."""
import copy
import csv
import io
from pathlib import Path

import pytest

from padml import f4
from padml.bundle import ContractError, canonical_json_bytes, read_safe_zip, sha256_bytes, strict_json_bytes, write_deterministic_zip
from padml.f1_kernel import _subset_csv
from padml.runtime import RSCRIPT_EXECUTABLE
from test_f4 import learning_curve_binding_fixture


@pytest.fixture
def inputs():
    contract, covariates, response, _ = learning_curve_binding_fixture(multiplier=3)
    rows = list(csv.DictReader(io.StringIO(covariates.decode())))
    rows.sort(key=lambda row: (int(row["Center"]), row["Patient_ID"].encode()))
    ids = [row["Patient_ID"] for row in rows]
    centers = [int(row["Center"]) for row in rows]
    # Explicit UNFITTED draw, not a native bootstrap plan or scientific result.
    indices = []
    for center in f4.FULL_PIPELINE_CENTER_ORDER:
        group = [i for i, value in enumerate(centers) if value == center]
        indices.extend(group[2 * (i // 2)] for i in range(len(group)))
    plan = {"family": "COX_PH", "identity_sha256": "a" * 64,
            "population": {"patient_ids": ids, "centers": centers, "source_identity_sha256": "b" * 64},
            "replicates": [{"replicate": 1, "draw_indices": indices,
                            "seed_registry": f4._full_pipeline_seed_record(1), "replicate_identity_sha256": "c" * 64}]}
    source = {"binding_contract": contract, "covariates_csv": covariates, "response_csv": response,
              "f1_manifest": {"identity": "d" * 64}}
    return plan, source


@pytest.fixture(autouse=True)
def no_native(monkeypatch):
    def forbidden(*args, **kwargs):
        raise AssertionError("NO_NATIVE_FIT_OR_POOL_IN_THIS_TEST")
    monkeypatch.setattr(f4.subprocess, "run", forbidden)
    monkeypatch.setattr(f4, "_run_full_pipeline_mice_native", forbidden)
    monkeypatch.setattr(f4, "_bounded_ordered_spawn", forbidden)


def context(inputs, root):
    plan, source = inputs
    return f4._prepare_full_pipeline_mice_context(plan, 1, 0, source, root, rscript=RSCRIPT_EXECUTABLE)


def unfitted_files(actual, name, root):
    """Only byte/transport fixtures; these are not native mids or completions."""
    root.mkdir()
    spec = copy.deepcopy(actual["mice_specs"][name])
    role = spec["view"]["role"]
    for member in f4._full_pipeline_mice_view_members(role):
        path = root / member
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(b"UNFITTED_NATIVE_LEAF_NOT_SCIENTIFIC_EVIDENCE")
    (root / "spec.json").write_bytes(canonical_json_bytes(spec))
    _subset_csv(actual["covariates_csv"], spec["view"]["row_ids"], root / "covariates.csv")
    if role == "ANALYSIS":
        _subset_csv(actual["response_csv"], spec["view"]["analysis_ids"], root / "response.csv")


@pytest.mark.parametrize("name", ["FULL_ANALYSIS", "ORIGINAL_APPLICATION"])
@pytest.mark.parametrize("retain_evidence", [False, True])
def test_view_producer_archive_consumer_roundtrip_without_native(inputs, tmp_path, monkeypatch, name, retain_evidence):
    tmp_path = tmp_path.resolve()
    actual = context(inputs, tmp_path)
    calls = []
    def unfitted_run(spec, root, action, **kwargs):
        assert action == "FIT" and kwargs == {"rscript": RSCRIPT_EXECUTABLE}
        calls.append(("UNFITTED_FIT_BOUNDARY", name))
        assert (root / "covariates.csv").is_file()
        assert (root / "response.csv").exists() == (spec["view"]["role"] == "ANALYSIS")
        for member in f4._full_pipeline_mice_view_members(spec["view"]["role"]):
            path = root / member
            path.parent.mkdir(parents=True, exist_ok=True)
            if not path.exists():
                path.write_bytes(b"UNFITTED_BYTE_FIXTURE")
        (root / "spec.json").write_bytes(canonical_json_bytes(spec))
    def unfitted_replay(ctx, observed_name, root, **kwargs):
        assert ctx is actual and observed_name == name
        assert (root / "native/imp20.rds").read_bytes() == b"UNFITTED_BYTE_FIXTURE"
        if kwargs.get("retain_evidence"):
            (root / "native/new-replay-evidence.json").write_bytes(b"UNFITTED_NEW_NATIVE_EVIDENCE")
        calls.append(("UNFITTED_REPLAY_BOUNDARY", name))
        return [root / f"output/imputations/imp{i:02d}.csv" for i in range(1, 21)]
    monkeypatch.setattr(f4, "_run_full_pipeline_mice_native", unfitted_run)
    monkeypatch.setattr(f4, "_replay_full_pipeline_mice_view", unfitted_replay)
    archive = tmp_path / f"{name}.zip"
    f4._execute_full_pipeline_mice_view(actual, name, archive, rscript=RSCRIPT_EXECUTABLE)
    assert not archive.with_name(archive.name + ".work").exists()
    before = archive.read_bytes()
    completed = f4._load_full_pipeline_mice_view(actual, name, archive, tmp_path / "relocated", rscript=RSCRIPT_EXECUTABLE,
                                               retain_evidence=retain_evidence)
    assert len(completed) == 20 and all(path.read_bytes() == b"UNFITTED_BYTE_FIXTURE" for path in completed)
    assert not list((tmp_path / "relocated/native").glob("*.rds")) and (tmp_path / "relocated/view.json").is_file()
    if retain_evidence:
        assert (tmp_path / "relocated/native/new-replay-evidence.json").read_bytes() == b"UNFITTED_NEW_NATIVE_EVIDENCE"
    assert archive.read_bytes() == before
    assert calls == [("UNFITTED_FIT_BOUNDARY", name), ("UNFITTED_REPLAY_BOUNDARY", name), ("UNFITTED_REPLAY_BOUNDARY", name)]
    members = read_safe_zip(archive)
    assert set(members) == f4._full_pipeline_mice_view_members(actual["mice_specs"][name]["view"]["role"]) | {"view.json"}
    manifest = strict_json_bytes(members["view.json"])
    assert all(set(record) == {"sha256", "size_bytes"} for record in manifest["members"].values())
    # Rehashing the transport does not allow a different admitted source.
    manifest["source"]["source_response_sha256"] = "e" * 64
    manifest["identity_sha256"] = sha256_bytes(canonical_json_bytes({k: v for k, v in manifest.items() if k != "identity_sha256"}))
    wrong = tmp_path / "wrong-source.zip"
    write_deterministic_zip(wrong, {**members, "view.json": canonical_json_bytes(manifest)})
    with pytest.raises(ContractError, match="ARCHIVE_BINDING_INVALID"):
        f4._load_full_pipeline_mice_view(actual, name, wrong, tmp_path / "rejected", rscript=RSCRIPT_EXECUTABLE)
    assert len(calls) == 3
    def failed_replay(*args, **kwargs):
        raise RuntimeError("UNFITTED_NATIVE_REPLAY_FAILED")
    monkeypatch.setattr(f4, "_replay_full_pipeline_mice_view", failed_replay)
    with pytest.raises(RuntimeError, match="NATIVE_REPLAY_FAILED"):
        f4._load_full_pipeline_mice_view(actual, name, archive, tmp_path / "failed-replay", rscript=RSCRIPT_EXECUTABLE)
    assert (tmp_path / "failed-replay/native/imp20.rds").read_bytes() == b"UNFITTED_BYTE_FIXTURE"
    assert archive.read_bytes() == before


@pytest.mark.parametrize("damage", ["seed", "substream", "row_order", "raw_value", "response_value", "missing_m20", "extra_application_response"])
def test_view_replay_rejects_invalid_native_inputs_before_r(inputs, tmp_path, damage):
    tmp_path = tmp_path.resolve()
    actual = context(inputs, tmp_path)
    name = "ORIGINAL_APPLICATION" if damage == "extra_application_response" else "FULL_ANALYSIS"
    root = tmp_path / "original"
    unfitted_files(actual, name, root)
    spec = strict_json_bytes((root / "spec.json").read_bytes())
    if damage == "seed":
        spec["chain_seeds"][0] += 1
    elif damage == "substream":
        spec["chain_rng_substream"] += 1
    elif damage == "row_order":
        spec["view"]["row_ids"].reverse()
    elif damage in {"raw_value", "response_value"}:
        path = root / ("covariates.csv" if damage == "raw_value" else "response.csv")
        reader = csv.DictReader(io.StringIO(path.read_text()))
        rows = list(reader)
        field = "Creatinine" if damage == "raw_value" else "Death_Followup_months"
        rows[0][field] = "1.125"
        stream = io.StringIO(newline="")
        writer = csv.DictWriter(stream, fieldnames=reader.fieldnames, lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)
        path.write_text(stream.getvalue())
    elif damage == "missing_m20":
        (root / "native/imp20.rds").unlink()
    else:
        (root / "response.csv").write_bytes(b"UNAUTHORIZED_RESPONSE")
    (root / "spec.json").write_bytes(canonical_json_bytes(spec))
    with pytest.raises(ContractError, match="MICE_(SPEC_MISMATCH|MEMBER_SET_INVALID|RAW_INPUT_MISMATCH)"):
        f4._replay_full_pipeline_mice_view(actual, name, root, rscript=RSCRIPT_EXECUTABLE)
    assert root.is_dir()


def test_native_command_failure_retains_original_logs_and_never_retries(inputs, tmp_path, monkeypatch):
    tmp_path = tmp_path.resolve()
    actual = context(inputs, tmp_path)
    # Restore only the actual command wrapper; its subprocess raises, never succeeds.
    wrapper = next(node for node in __import__("ast").parse(Path(f4.__file__).read_text()).body
                   if isinstance(node, __import__("ast").FunctionDef) and node.name == "_run_full_pipeline_mice_native")
    namespace = dict(f4.__dict__)
    exec(compile(__import__("ast").Module(body=[wrapper], type_ignores=[]), f4.__file__, "exec"), namespace)
    monkeypatch.setattr(f4, "_run_full_pipeline_mice_native", namespace[wrapper.name])
    commands = []
    def failed(command, **kwargs):
        commands.append(command)
        assert Path(command[2]).name == "f5_mice.R" and command[3] == "FIT"
        assert kwargs["timeout"] == 12 * 60 * 60
        kwargs["stdout"].write(b"INJECTED_PROCESS_FAILURE_STDOUT")
        kwargs["stderr"].write(b"INJECTED_PROCESS_FAILURE_STDERR")
        raise RuntimeError("INJECTED_PROCESS_FAILURE")
    monkeypatch.setattr(f4.subprocess, "run", failed)
    target = tmp_path / "failed.zip"
    with pytest.raises(RuntimeError, match="INJECTED_PROCESS_FAILURE"):
        f4._execute_full_pipeline_mice_view(actual, "FULL_ANALYSIS", target, rscript=RSCRIPT_EXECUTABLE)
    root = target.with_name(target.name + ".work")
    assert not target.exists() and (root / "spec.json").is_file()
    assert (root / "stdout.txt").read_bytes() == b"INJECTED_PROCESS_FAILURE_STDOUT"
    assert (root / "stderr.txt").read_bytes() == b"INJECTED_PROCESS_FAILURE_STDERR"
    with pytest.raises(ContractError, match="WORK_EXISTS"):
        f4._execute_full_pipeline_mice_view(actual, "FULL_ANALYSIS", target, rscript=RSCRIPT_EXECUTABLE)
    assert len(commands) == 1


def test_context_transport_exact_views_and_failure_retention(inputs, tmp_path, monkeypatch):
    tmp_path = tmp_path.resolve()
    plan, frozen = inputs
    target = tmp_path / "context.zip"
    calls = []
    def unfitted_view(ctx, name, path, **kwargs):
        assert kwargs == {"rscript": RSCRIPT_EXECUTABLE}
        calls.append(name)
        write_deterministic_zip(path, {"UNFITTED.txt": name.encode()})
        return {"member": path.name, "identity_sha256": "f" * 64,
                "sha256": f4.sha256_file(path), "size_bytes": path.stat().st_size}
    monkeypatch.setattr(f4, "_execute_full_pipeline_mice_view", unfitted_view)
    result = f4._execute_full_pipeline_mice_context(plan, 1, 0, frozen, target, rscript=RSCRIPT_EXECUTABLE)
    assert result["mice_chains"] == 40 and result["model_fit_count"] == 0  # UNFITTED requested count, not actual fits.
    assert calls == ["FULL_ANALYSIS", "ORIGINAL_APPLICATION"]
    loaded = []
    def unfitted_load(ctx, name, source, destination, **kwargs):
        assert read_safe_zip(source)["UNFITTED.txt"] == name.encode()
        assert ctx["source"]["bootstrap_replicate"] == 1
        loaded.append(name)
        return [destination / f"UNFITTED-imp{i:02d}.csv" for i in range(1, 21)]
    monkeypatch.setattr(f4, "_load_full_pipeline_mice_view", unfitted_load)
    materialized = f4._load_full_pipeline_mice_context(plan, 1, 0, frozen, target, tmp_path / "materialized", rscript=RSCRIPT_EXECUTABLE)
    assert loaded == calls and set(materialized["completed"]) == set(calls)
    assert not list((tmp_path / "materialized/views").glob("*.zip")) and (tmp_path / "materialized/context.json").is_file()
    members = read_safe_zip(target)
    manifest = strict_json_bytes(members["context.json"])
    manifest["clone_mapping"][0]["occurrence"] += 1
    manifest["identity_sha256"] = sha256_bytes(canonical_json_bytes({k: v for k, v in manifest.items() if k != "identity_sha256"}))
    wrong = tmp_path / "wrong-clones.zip"
    write_deterministic_zip(wrong, {**members, "context.json": canonical_json_bytes(manifest)})
    with pytest.raises(ContractError, match="CONTEXT_BINDING_INVALID"):
        f4._load_full_pipeline_mice_context(plan, 1, 0, frozen, wrong, tmp_path / "rejected-context", rscript=RSCRIPT_EXECUTABLE)
    assert loaded == calls
    original = target.read_bytes()
    def fail_load_second(ctx, name, source, destination, **kwargs):
        if name == "ORIGINAL_APPLICATION":
            raise RuntimeError("UNFITTED_SECOND_REPLAY_FAILURE")
        return unfitted_load(ctx, name, source, destination, **kwargs)
    monkeypatch.setattr(f4, "_load_full_pipeline_mice_view", fail_load_second)
    failed_replay = tmp_path / "failed-replay-context"
    with pytest.raises(RuntimeError, match="SECOND_REPLAY_FAILURE"):
        f4._load_full_pipeline_mice_context(plan, 1, 0, frozen, target, failed_replay, rscript=RSCRIPT_EXECUTABLE)
    assert not (failed_replay / "views/FULL_ANALYSIS.zip").exists()
    assert (failed_replay / "views/ORIGINAL_APPLICATION.zip").is_file() and target.read_bytes() == original
    def fail_second(ctx, name, path, **kwargs):
        if name == "ORIGINAL_APPLICATION":
            raise RuntimeError("UNFITTED_SECOND_VIEW_FAILURE")
        return unfitted_view(ctx, name, path, **kwargs)
    monkeypatch.setattr(f4, "_execute_full_pipeline_mice_view", fail_second)
    failed = tmp_path / "failed-context.zip"
    with pytest.raises(RuntimeError, match="SECOND_VIEW_FAILURE"):
        f4._execute_full_pipeline_mice_context(plan, 1, 0, frozen, failed, rscript=RSCRIPT_EXECUTABLE)
    assert not failed.exists()
    assert (failed.with_name(failed.name + ".work") / "FULL_ANALYSIS.zip").is_file()
