from __future__ import annotations

import copy
import json
import os
from pathlib import Path
import subprocess

import pytest

from padml.bundle import ContractError, canonical_json_bytes, sha256_bytes
from padml.f2_kernel import _seal_prediction_matrix
from padml.f4 import _o_fit_fpm_reuse_binding, _replay_o_fit_fpm_retained


def native_component_fixture(tmp_path, *, apparent):
    """An explicitly unfitted transport fixture, never scientific fit evidence."""
    from padml.f4 import _f4_model_seed
    coordinates = {"purpose": "O_FIT", "outer_fold": 1,
                   "repeat": 0 if apparent else 1, "inner_fold": 0 if apparent else 1,
                   "imputation": 1}
    task = {"family": "COX_PH", "selected_parents": ["AST_ALT"],
            "parameters": {"family": "COX_PH", "ties": "breslow"}, "imputation": 1,
            "f4_coordinates": coordinates, "registered_model_seed": _f4_model_seed("COX_PH", coordinates),
            "model_seed": None, "row_count": 2, "family_design_column_count": 1}
    training = b"Patient_ID,Center,AST_ALT\n001,36,1\n002,38,2\n"
    return {"root": str(tmp_path / "component"), "name": "component", "entries": {
        "task.json": canonical_json_bytes(task), "recipe.json": b'{"test_only":"UNFITTED_STUB"}',
        "fit-covariates.csv": training,
        "fit-response.csv": b"Patient_ID,All_Cause_Death,Death_Followup_months\n001,1,20\n002,0,30\n",
        "prediction-covariates.csv": training if apparent else b"Patient_ID,Center,AST_ALT\n003,55,1.5\n",
    }}


@pytest.mark.parametrize("apparent", [False, True])
def test_f4_component_preserves_native_then_replays_without_fitting(tmp_path, monkeypatch, apparent):
    from padml.f4 import _execute_f4_model_component, _replay_f4_model_component
    from padml.bundle import read_safe_zip
    job = native_component_fixture(tmp_path, apparent=apparent)
    calls = []

    def unfitted_stub(family, task, training, response, recipe, **kwargs):
        assert recipe == {"test_only": "UNFITTED_STUB"}
        calls.append("replay" if "retained_objects" in kwargs else "unfitted_stub")
        rows = kwargs.get("prediction_rows", training)
        if "prediction_rows" in kwargs:
            assert (Path(job["root"]) / "model.bin").read_bytes() == b"UNFITTED_MODEL"
            assert (Path(job["root"]) / "baseline.bin").read_bytes() == b"UNFITTED_BASELINE"
            assert (Path(job["root"]) / "training-prediction.json").is_file()
            assert not set(response).intersection(row["Patient_ID"] for row in rows)
        result = {"model": b"UNFITTED_MODEL", "baseline": b"UNFITTED_BASELINE",
                "fit_health": {"test_only": True}, "survival": [[1.0] * 37 for row in rows],
                **({"training_survival": [[1.0] * 37 for row in training]} if kwargs.get("replay_training") else {})}
        if kwargs.get("native_commit") is not None:
            kwargs["native_commit"](result)
        return result

    monkeypatch.setattr("padml.f5._execute_final_refit_engine", unfitted_stub)
    monkeypatch.setattr("padml.f5._validate_retained_model_objects", lambda *args: None)
    row = _execute_f4_model_component(job)
    archive = Path(job["root"]).with_suffix(".zip")
    entries = read_safe_zip(archive)
    assert entries["model.bin"] == b"UNFITTED_MODEL"
    assert calls == (["unfitted_stub"] if apparent else ["unfitted_stub", "replay"])
    calls.clear()
    replayed = _replay_f4_model_component({**job, "archive": str(archive)})
    assert row == replayed
    assert calls == ["replay"]
    changed = copy.deepcopy(job)
    changed["entries"]["fit-response.csv"] = changed["entries"]["fit-response.csv"].replace(b",1,20", b",1,21")
    with pytest.raises(ContractError, match="INPUT_REPLAY_MISMATCH"):
        _replay_f4_model_component({**changed, "archive": str(archive)})


def test_f4_component_postfit_failure_retains_completed_objects(tmp_path, monkeypatch):
    from padml.f4 import _execute_f4_model_component
    job = native_component_fixture(tmp_path, apparent=False)

    def unfitted_stub(*args, **kwargs):
        if "retained_objects" in kwargs:
            raise ContractError("INJECTED_APPLICATION_NUMERICAL_FAILURE")
        result = {"model": b"UNFITTED_MODEL", "baseline": b"UNFITTED_BASELINE",
                "fit_health": {"test_only": True}, "survival": [[1.0] * 37] * 2}
        kwargs["native_commit"](result)
        return result

    monkeypatch.setattr("padml.f5._execute_final_refit_engine", unfitted_stub)
    with pytest.raises(ContractError, match="INJECTED_APPLICATION_NUMERICAL_FAILURE") as failure:
        _execute_f4_model_component(job)
    root = Path(job["root"])
    assert (root / "model.bin").read_bytes() == b"UNFITTED_MODEL"
    assert (root / "baseline.bin").read_bytes() == b"UNFITTED_BASELINE"
    assert (root / "native-failure.json").is_file()
    assert not root.with_suffix(".zip").exists()
    assert f"F4_NATIVE_MODEL_EVIDENCE_RETAINED:{root}" in failure.value.__notes__


@pytest.mark.parametrize("retained_only", [False, True])
@pytest.mark.parametrize("damage", [None, "native_replay", "expanded_copy", "extra_evidence", "missing_verified_copy"])
def test_verified_score_releases_only_last_used_exact_expansion(tmp_path, monkeypatch, damage, retained_only):
    import csv
    import io
    from padml import f5
    from padml.bundle import sha256_file, write_deterministic_zip
    component = native_component_fixture(tmp_path, apparent=False)
    fields = f5.load_science_authority()["science"]["mice"]["private_handoff"]["columns"]
    for name in ("fit-covariates.csv", "prediction-covariates.csv"):
        rows = list(csv.DictReader(io.StringIO(component["entries"][name].decode())))
        stream = io.StringIO(newline="")
        writer = csv.DictWriter(stream, fieldnames=fields, lineterminator="\n")
        writer.writeheader()
        writer.writerows({**dict.fromkeys(fields, "1"), **row} for row in rows)
        component["entries"][name] = stream.getvalue().encode()
    component["root"] = str(tmp_path / "score/components/score-native/COX_PH/R1_K1_M01")
    Path(component["root"]).parent.mkdir(parents=True)
    source = tmp_path / "input.zip"
    write_deterministic_zip(source, component["entries"])
    scratch = tmp_path / "scratch"
    scratch.mkdir()
    calls = []
    def unfitted(family, task, training, response, recipe, **kwargs):
        calls.append("REPLAY" if "retained_objects" in kwargs else "UNFITTED_CREATE")
        result = {"model": b"UNFITTED_MODEL", "baseline": b"UNFITTED_BASELINE", "fit_health": {"UNFITTED": True},
                "survival": [[1.0]*37 for _ in kwargs.get("prediction_rows", training)],
                **({"training_survival": [[1.0]*37 for _ in training]} if kwargs.get("replay_training") else {})}
        if kwargs.get("native_commit") is not None:
            kwargs["native_commit"](result)
        return result
    def audit(*args, **kwargs):
        if damage == "native_replay":
            raise ContractError("INJECTED_NATIVE_REPLAY_FAILURE")
        return {"UNFITTED_AUDIT": True}
    monkeypatch.setattr(f5, "_execute_final_refit_engine", unfitted)
    monkeypatch.setattr(f5, "_validate_retained_model_objects", audit)
    job = {"source": str(source), "root": component["root"], "coordinate_identity": "SYNTHETIC_SCORE",
           "scratch_root": str(scratch), "expanded_bytes_per_component": 1024**2,
           "retained_bytes_per_component": 2*1024**2, "source_sha256": sha256_file(source),
           "source_size_bytes": source.stat().st_size}
    job["score_evidence"] = {"path": str(tmp_path / "score/score-evidence/COX_PH/R1_K1_M01.json"),
        "record": {"role": "FRESH_SCORE", "family": "COX_PH", "repeat": 1, "inner_fold": 1, "imputation": 1,
                   "path": "components/COX_PH/R1_K1_M01.zip", "sha256": job["source_sha256"],
                   "size_bytes": job["source_size_bytes"]},
        "context": {"scope": "OUTER", "identity_sha256": "1" * 64, "outer_fold": 1}, "partition_id": "INNER_R1_K1"}
    fitted = f5._execute_score_archive_job(job)
    root, archive = Path(job["root"]), Path(job["root"]).with_suffix(".zip")
    if retained_only:
        # Simulate interruption after preserving the object pair, before ZIP
        # publication. Recovery must use that pair, never the new-fit branch.
        archive.unlink()
        (root / "prediction.json").unlink()
        before_pair = {path.name: (path.read_bytes(), path.stat().st_ino, path.stat().st_mtime_ns)
                       for path in root.iterdir()}
        with monkeypatch.context() as recovering:
            recovering.setattr(f5, "_validate_retained_model_objects", lambda *a, **k: {"UNFITTED_AUDIT": True})
            fitted = f5._execute_score_archive_job(job, retained_only=True)
        assert calls.count("UNFITTED_CREATE") == 1
        assert all((root / name).read_bytes() == row[0]
                   and ((root / name).stat().st_ino, (root / name).stat().st_mtime_ns) == row[1:]
                   for name, row in before_pair.items())
    originals = {path: path.read_bytes() for path in (source, archive)}
    if damage == "expanded_copy":
        (root / "model.bin").write_bytes(b"UNKNOWN_CHANGE")
    elif damage == "extra_evidence":
        (root / "native-failure.json").write_bytes(b"UNKNOWN_FAILURE_EVIDENCE")
    elif damage == "missing_verified_copy":
        (root / "model.bin").unlink()
    before = {path: path.read_bytes() for path in root.iterdir()}
    if damage in {"native_replay", "expanded_copy", "extra_evidence"}:
        with pytest.raises(ContractError):
            f5._replay_component_job(job)
        assert before == {path: path.read_bytes() for path in root.iterdir()}
    else:
        verified = f5._replay_component_job(job)
        assert not root.exists()
        evidence = Path(job["score_evidence"]["path"])
        assert verified == {**fitted, "retained_size_bytes": sum(len(raw) for raw in originals.values()),
                            "evidence_sha256": sha256_file(evidence), "evidence_size_bytes": evidence.stat().st_size}
        assert json.loads(evidence.read_bytes())["object_audit"] == {"UNFITTED_AUDIT": True}
        assert verified["retained_size_bytes"] < fitted["retained_size_bytes"]
        assert f5._replay_component_job(job) == verified  # the original ZIP remains directly consumable
        with pytest.raises(ContractError, match="F4_NATIVE_MODEL_TARGET_ALREADY_STARTED"):
            f5._execute_score_archive_job(job)
        assert calls.count("UNFITTED_CREATE") == 1
        # The original fit+first-replay worker also accepts the reduced live
        # byte count without changing any archive or coordinate identity.
        second = {**job, "root": str(tmp_path / "second-UNFITTED/components/score-native/COX_PH/R1_K1_M01"),
                  "score_evidence": {**job["score_evidence"],
                      "path": str(tmp_path / "second-UNFITTED/score-evidence/COX_PH/R1_K1_M01.json")}}
        Path(second["root"]).parent.mkdir(parents=True)
        f5._execute_and_verify_score_archive_job(second)
        assert not Path(second["root"]).exists() and Path(second["root"]).with_suffix(".zip").is_file()
    assert originals == {path: path.read_bytes() for path in originals}


@pytest.mark.parametrize("damage", ["missing_model", "missing_baseline", "missing_training", "missing_health",
    "missing_input", "extra", "native_failure", "inside_tmp", "empty_model", "linked_model", "input_drift"])
def test_retained_only_refuses_incomplete_or_unknown_members_before_engine(tmp_path, monkeypatch, damage):
    from padml import f4, f5
    job = native_component_fixture(tmp_path, apparent=False)
    root = Path(job["root"])
    root.mkdir()
    raw = {**job["entries"], "model.bin": b"UNFITTED_MODEL", "baseline.bin": b"UNFITTED_BASELINE",
           "fit-health.json": b'{"UNFITTED":true}', "training-prediction.json": b'[[1.0]]'}
    for name, value in raw.items():
        (root / name).write_bytes(value)
    missing = {"missing_model": "model.bin", "missing_baseline": "baseline.bin",
        "missing_training": "training-prediction.json", "missing_health": "fit-health.json",
        "missing_input": "fit-response.csv"}
    if damage in missing:
        (root / missing[damage]).unlink()
    elif damage == "linked_model":
        (root / "model.bin").unlink()
        (root / "model.bin").symlink_to(root / "baseline.bin")
    else:
        name = {"extra": "unexpected", "native_failure": "native-failure.json", "inside_tmp": "publication.tmp",
                "empty_model": "model.bin", "input_drift": "fit-response.csv"}[damage]
        (root / name).write_bytes(b"" if damage == "empty_model" else b"UNFITTED_DRIFT")
    before = {path.name: (path.is_symlink(), path.read_bytes(), path.lstat().st_ino) for path in root.iterdir()}
    def forbidden(*args, **kwargs):
        pytest.fail("RETAINED_ONLY_INVALID_MUST_NOT_FIT_AUDIT_OR_DELETE")
    monkeypatch.setattr(f5, "_execute_final_refit_engine", forbidden)
    monkeypatch.setattr(f5, "_validate_retained_model_objects", forbidden)
    monkeypatch.setattr(f4.shutil, "rmtree", forbidden)
    with pytest.raises(ContractError, match="F4_NATIVE_MODEL_(INCOMPLETE_ARCHIVE|INPUT_REPLAY_MISMATCH)"):
        f4._execute_f4_model_component(job, retained_only=True)
    assert before == {path.name: (path.is_symlink(), path.read_bytes(), path.lstat().st_ino) for path in root.iterdir()}
    assert not root.with_suffix(".zip").exists()


@pytest.mark.parametrize("mutation", ["mixed_imputation", "wrong_seed", "application_outcome", "overlap"])
def test_f4_component_rejects_invalid_inputs_before_native(tmp_path, monkeypatch, mutation):
    from padml.f4 import _execute_f4_model_component
    job = native_component_fixture(tmp_path, apparent=False)
    task = json.loads(job["entries"]["task.json"])
    if mutation == "mixed_imputation":
        task["imputation"] = 2
    elif mutation == "wrong_seed":
        task["registered_model_seed"] += 1
    elif mutation == "application_outcome":
        job["entries"]["prediction-covariates.csv"] = b"Patient_ID,Center,AST_ALT,All_Cause_Death\n003,55,1.5,1\n"
    else:
        job["entries"]["prediction-covariates.csv"] = b"Patient_ID,Center,AST_ALT\n001,36,1\n"
    job["entries"]["task.json"] = canonical_json_bytes(task)
    monkeypatch.setattr("padml.f5._execute_final_refit_engine", lambda *a, **kw: pytest.fail("native must not start"))
    with pytest.raises(ContractError, match="F4_NATIVE_MODEL_"):
        _execute_f4_model_component(job)
    assert not Path(job["root"]).exists()


@pytest.mark.parametrize("replay_workers", [None, 24])
def test_o_fit_native_mi_mean_requires_twenty_and_keeps_canonical_order(tmp_path, monkeypatch, replay_workers):
    from fractions import Fraction
    from padml.f4 import _f4_model_seed, _replay_o_fit_partition
    tasks, archives, calls = [], {}, []
    for imp in range(1, 21):
        job = native_component_fixture(tmp_path, apparent=False)
        task = json.loads(job["entries"]["task.json"])
        task["imputation"] = task["f4_coordinates"]["imputation"] = imp
        task["registered_model_seed"] = _f4_model_seed("COX_PH", task["f4_coordinates"])
        job["entries"]["task.json"] = canonical_json_bytes(task)
        job["name"] = f"M{imp:02d}"
        tasks.append(job)
        archives[job["name"]] = tmp_path / f"M{imp:02d}.zip"

    def replay_stub(job):
        imp = json.loads(job["entries"]["task.json"])["imputation"]
        calls.append(imp)
        return {"patient_ids": ["003"], "centers": ["55"], "horizons": list(range(37)),
                "survival": {"COX_PH": [[1.0] + [1.0 - imp / 100] * 36]}}

    monkeypatch.setattr("padml.f4._replay_f4_model_component", replay_stub)
    monkeypatch.setattr("padml.f4._prepare_o_fit_partition", lambda *args, **kwargs: tasks[::-1])
    def pool(worker, jobs, *, selected_slots):
        assert selected_slots == 24 and len(jobs) == 20
        # Existing pool returns submission order despite reverse completion.
        rows = {job["name"]: worker(job) for job in reversed(jobs)}
        return [rows[job["name"]] for job in jobs]
    monkeypatch.setattr("padml.f4._bounded_ordered_spawn", pool)
    model, partition = {"family": "COX_PH"}, {"kind": "INNER"}
    result = _replay_o_fit_partition(model, partition, {}, archives, replay_workers=replay_workers)
    assert calls == (list(range(1, 21)) if replay_workers is None else list(range(20, 0, -1)))
    # Match the original two binary64 operations: rounded fsum, then division.
    # Rounding an exact rational mean just once is a different computation.
    expected = float(sum(Fraction.from_float(1.0 - imp / 100) for imp in range(1, 21))) / 20
    assert result["inner_fold"] == 1 and result["survival"]["COX_PH"] == [[1.0] + [expected] * 36]
    with pytest.raises(ContractError, match="NATIVE_M20_REQUIRED"):
        _replay_o_fit_partition(model, partition, {}, {key: value for key, value in archives.items() if key != "M20"})


def test_o_fit_materializer_calls_original_readers_without_new_capsule(tmp_path, monkeypatch):
    from padml.f4 import _materialize_o_fit_fold
    calls = []
    source = {"f1_manifest": {"identity": "a" * 64, "direct_objects": [{"unit_id": "mice-fold-1"}]},
              "f1_object_root": str(tmp_path / "original-objects"),
              "binding_contract": {"original": True}, "response_csv": b"frozen-response"}

    def original_admission(capsule_path, capsule, outer, target, contract, result_paths):
        calls.append("admit")
        assert outer == 1 and contract is source["binding_contract"]
        assert result_paths == {"mice-fold-1": tmp_path / "original-objects/mice-fold-1.zip"}
        assert capsule["approved_registry"]["direct_objects"] == source["f1_manifest"]["direct_objects"]
        assert not capsule_path.exists()
        (target / "mice-fold-1-result").mkdir()
        (target / "mice-fold-1-payload").mkdir()
        return {}, {"admitted_original": True}, {}

    def original_materializer(fold_input, contract, response, outer, target):
        calls.append("materialize")
        assert fold_input == {"admitted_original": True} and response == b"frozen-response"
        (target / "view-sources").mkdir(parents=True)
        (target / "actual-merged-input.csv").write_bytes(b"UNFITTED_MATERIALIZATION_FIXTURE")
        return {"test_only": "NO_MICE_EXECUTION"}

    monkeypatch.setattr("padml.f2_kernel.admitted_f1_fold", original_admission)
    monkeypatch.setattr("padml.f2_kernel._materialize_registered_partitions", original_materializer)
    assert _materialize_o_fit_fold(source, 1, tmp_path / "work") == {"test_only": "NO_MICE_EXECUTION"}
    assert calls == ["admit", "materialize"]
    assert [p.relative_to(tmp_path / "work").as_posix() for p in (tmp_path / "work").rglob("*")]
    assert (tmp_path / "work/registered/actual-merged-input.csv").read_bytes() == b"UNFITTED_MATERIALIZATION_FIXTURE"
    assert not (tmp_path / "work/mice-fold-1-result").exists()
    assert not (tmp_path / "work/mice-fold-1-payload").exists()
    assert not (tmp_path / "work/registered/view-sources").exists()


@pytest.mark.parametrize("outer,reused_imp", [(1, 19), (3, 8), (6, 15)])
def test_o_fit_m20_uses_original_fpm_apparent_without_new_binding(tmp_path, monkeypatch, outer, reused_imp):
    from padml.f4 import _f4_model_seed, _replay_o_fit_partition
    tasks, archives, native_calls = [], {}, []
    for imp in range(1, 21):
        job = native_component_fixture(tmp_path, apparent=True)
        task = json.loads(job["entries"]["task.json"])
        task.update(family="FPM_TVC_SET_A", imputation=imp,
                    parameters={"family": "FPM_TVC_SET_A", "selected_parents": ["AST_ALT"],
                                "df": [3, 1], "tvc_parent": "AST_ALT"})
        task["f4_coordinates"].update(outer_fold=outer, imputation=imp)
        task["registered_model_seed"] = _f4_model_seed("FPM_TVC_SET_A", task["f4_coordinates"])
        job["entries"]["task.json"] = canonical_json_bytes(task)
        job["entries"]["recipe.json"] = canonical_json_bytes({"transform_recipe": {"recipe_sha256": "a" * 64}})
        job["name"] = f"M{imp:02d}"
        tasks.append(job)
        if imp != reused_imp:
            archives[job["name"]] = tmp_path / f"M{imp:02d}.zip"
    model = {"family": "FPM_TVC_SET_A", "fold": outer,
             "fpm_fixed_reuse": {"task_id": f"FINAL_OUTER_M{reused_imp:02d}"},
             "selector_evidence": {"outer_recipe_sha256": "a" * 64},
             "selected_spec": {"selected_parents": ["AST_ALT"]}}
    covariates = tmp_path / "covariates"
    covariates.mkdir()
    (covariates / f"imp{reused_imp:02d}.csv").write_bytes(tasks[0]["entries"]["fit-covariates.csv"])
    response = tmp_path / "response.csv"
    response.write_bytes(tasks[0]["entries"]["fit-response.csv"])
    partition = {"kind": "OUTER", "fit_ids": ["001", "002"],
                 "covariates": {"input_dir": str(covariates)}, "fit_response": {"path": str(response)}}
    monkeypatch.setattr("padml.f4._prepare_o_fit_partition", lambda *args, **kwargs: tasks)

    def new_format_replay(job):
        imp = json.loads(job["entries"]["task.json"])["imputation"]
        assert imp != reused_imp
        native_calls.append(("new_format_replay", imp))
        return {"patient_ids": ["001", "002"], "centers": ["36", "38"], "horizons": list(range(37)),
                "survival": {"FPM_TVC_SET_A": [[1.0] * 37, [1.0] * 37]}}

    def original_replay(actual_model, native, cov, resp, target, *, rscript):
        assert actual_model is model and native == tmp_path / "original-fpm.zip"
        assert cov == covariates / f"imp{reused_imp:02d}.csv" and resp == response
        native_calls.append(("original_replay", reused_imp))
        return {"fit_count": 0, "outer_fold": outer, "imputation": reused_imp,
                "model_seed": _f4_model_seed("FPM_TVC_SET_A", {
                    "purpose": "O_FIT", "outer_fold": outer, "repeat": 0, "inner_fold": 0,
                    "imputation": reused_imp}),
                "apparent": _seal_prediction_matrix(["001", "002"], [[1.0] * 37] * 2, list(range(37)))}

    monkeypatch.setattr("padml.f4._replay_f4_model_component", new_format_replay)
    monkeypatch.setattr("padml.f4._replay_o_fit_fpm_retained", original_replay)
    monkeypatch.setattr("padml.f5._execute_final_refit_engine", lambda *a, **kw: pytest.fail("no fit allowed"))
    result = _replay_o_fit_partition(model, partition, {}, archives, fpm_native_archive=tmp_path / "original-fpm.zip")
    assert native_calls == [("original_replay", reused_imp)] + [
        ("new_format_replay", imp) for imp in range(1, 21) if imp != reused_imp]
    assert result["survival"]["FPM_TVC_SET_A"] == [[1.0] * 37] * 2
    with pytest.raises(ContractError, match="ORIGINAL_APPARENT_REUSE_REQUIRED"):
        _replay_o_fit_partition(model, partition, {}, archives)
    with pytest.raises(ContractError, match="NATIVE_M20_REQUIRED"):
        _replay_o_fit_partition(model, partition, {}, {**archives, f"M{reused_imp:02d}": tmp_path / "refitted.zip"},
                               fpm_native_archive=tmp_path / "original-fpm.zip")


def binding_fixture():
    sha = lambda value: sha256_bytes(canonical_json_bytes(value))
    recipe = {"recipe_sha256": "a" * 64, "partition_id": "OUTER_F1"}
    task = {"task_id": "FINAL_OUTER_M19", "family": "FPM_TVC_SET_A",
            "partition_id": "OUTER_F1", "imputation": 19, "seed": 301019,
            "parameters": {}, "selected_parents": ["AST_ALT", "Age"],
            "prediction_horizons": list(range(1, 37)), "transform_recipe": recipe}
    cov = {"analysis_ids_sha256": sha(["a", "b"]), "analysis_view_sha256": "c" * 64,
           "application_ids_sha256": sha(["a", "b", "c"]), "application_view_sha256": "d" * 64,
           "data_identity": "e" * 64}
    part = {"partition_id": "OUTER_F1", "kind": "OUTER", "repeat": 0, "inner_fold": 0,
            "fit_ids": ["a", "b"], "evaluation_ids": ["c"], "application_ids": ["a", "b", "c"],
            "covariates": cov, "fit_response": {"sha256": "f" * 64, "size_bytes": 99}}
    spec = {"family": "FPM_TVC_SET_A", "fold": 1, "seed": 301000,
            "fpm": {"set_a_df": [3, 1]}, "horizons": list(range(1, 37)),
            "output_path": "/old/output.json", "transform_recipe": recipe,
            "producer_tasks": [{k: v for k, v in task.items() if k != "transform_recipe"}],
            "registered_partitions": {"partitions": [part]}}
    original = {"task_id": task["task_id"], "partition_id": task["partition_id"], "imputation": 19,
                "evaluation_ids": ["c"], "survival": [[0.99 ** i for i in range(1, 37)]],
                "transform_recipe_sha256": recipe["recipe_sha256"]}
    model = {"artifact_kind": "F2_MODEL_DEVELOPMENT", "status": "PASS", "fold": 1,
             "family": "FPM_TVC_SET_A", "fpm_fixed_reuse": {"task_id": task["task_id"]},
             "selected_spec": {"family": "FPM_TVC_SET_A", "selected_parents": task["selected_parents"],
                               "df": [3, 1], "tvc_parent": "AST_ALT"},
             "model_input": {"model_partitions": [{
                 **cov, "kind": "OUTER", "partition_id": "OUTER_F1", "fit_count": 2,
                 "evaluation_count": 1, "fit_ids_sha256": sha(["a", "b"]),
                 "evaluation_ids_sha256": sha(["c"]), "fit_response_sha256": "f" * 64,
                 "fit_response_size_bytes": 99}]},
             "stopping_and_convergence": [{"imputation": 19, "prediction_seal_sha256":
                 _seal_prediction_matrix(["c"], original["survival"], spec["horizons"])["sha256"]}]}
    entries = {"native-fit.rds": b"not-a-native-object", "native-kernel-candidate.R": b"not-a-kernel",
               "original-task.json": canonical_json_bytes(task),
               "original-spec.json": canonical_json_bytes(spec),
               "spec.json": canonical_json_bytes({**spec, "output_path": "/relocated/output.json"}),
               "output.json": canonical_json_bytes({"kind": "PADML_F2_R_PREDICTION_BATCH",
                   "status": "PASS", "task_count": 1, "tasks": [original]})}
    return model, entries, spec, task


def test_binding_does_not_claim_native_acceptance():
    model, entries, spec, task = binding_fixture()
    observed = _o_fit_fpm_reuse_binding(model, entries)
    assert observed == (spec, task, spec["registered_partitions"]["partitions"][0])
    # Deliberately fake object bytes survive metadata binding only. Actual use
    # must go through readRDS, native training-data binding and prediction replay.
    assert entries["native-fit.rds"] == b"not-a-native-object"


@pytest.mark.parametrize("field,value", [
    ("seed", 300000), ("imputation", 18), ("family", "COX_PH"),
    ("partition_id", "INNER_R1_K1"), ("parameters", {"df": 3}),
    ("selected_parents", ["AST_ALT"]), ("prediction_horizons", [24]),
])
def test_rejects_changed_f2_coordinate(field, value):
    model, entries, _, task = binding_fixture()
    task[field] = value
    entries["original-task.json"] = canonical_json_bytes(task)
    with pytest.raises(ContractError, match="COORDINATE_DRIFT"):
        _o_fit_fpm_reuse_binding(model, entries)


@pytest.mark.parametrize("field", ["fit_ids", "evaluation_ids", "application_ids", "covariates"])
def test_rejects_input_drift_even_with_resealed_spec(field):
    model, entries, spec, _ = binding_fixture()
    spec = copy.deepcopy(spec)
    part = spec["registered_partitions"]["partitions"][0]
    if field == "covariates":
        part[field]["analysis_view_sha256"] = "0" * 64
    else:
        part[field] = list(reversed(part[field])) if len(part[field]) > 1 else ["wrong"]
    entries["original-spec.json"] = canonical_json_bytes(spec)
    entries["spec.json"] = canonical_json_bytes(spec)
    with pytest.raises(ContractError, match="INPUT_DRIFT"):
        _o_fit_fpm_reuse_binding(model, entries)


def test_rejects_original_prediction_not_accepted_by_f2():
    model, entries, _, _ = binding_fixture()
    model["stopping_and_convergence"][0]["prediction_seal_sha256"] = "0" * 64
    with pytest.raises(ContractError, match="PREDICTION_DRIFT"):
        _o_fit_fpm_reuse_binding(model, entries)


def test_missing_native_is_not_an_infeasible_candidate():
    model, entries, _, _ = binding_fixture()
    del entries["native-fit.rds"]
    with pytest.raises(ContractError, match="NATIVE_OBJECT_REQUIRED"):
        _o_fit_fpm_reuse_binding(model, entries)


def test_no_accepted_archive_never_starts_r_or_creates_output(tmp_path, monkeypatch):
    def forbidden(*args, **kwargs):
        pytest.fail("native process must not start")
    monkeypatch.setattr("padml.f4.subprocess.run", forbidden)
    with pytest.raises(ContractError, match="ACCEPTED_NATIVE_ARCHIVE_REQUIRED"):
        _replay_o_fit_fpm_retained({}, tmp_path / "missing.zip", tmp_path / "cov.csv",
                                  tmp_path / "response.csv", tmp_path / "result", rscript="Rscript")
    assert not (tmp_path / "result").exists()


def test_thin_replay_has_no_fitting_action():
    text = (Path(__file__).resolve().parents[1] / "padml/kernels/f4_o_fit_fpm_replay.R").read_text()
    assert "stpm2(" not in text and "fit_predict(" not in text and "set.seed(" not in text
    assert 'fit <- readRDS(' in text and 'original$survival' in text


@pytest.mark.parametrize("changed,reason", [
    ("model_training", "F4_O_FIT_NATIVE_TRAINING_DATA_DRIFT"),
    ("prediction", "F4_O_FIT_ORIGINAL_PREDICTION_REPLAY_MISMATCH"),
])
def test_native_replay_rejects_altered_retained_evidence(tmp_path, changed, reason):
    from padml.runtime import RSCRIPT_EXECUTABLE, activated_environment

    retained = os.environ.get("PADML_O_FIT_FPM_REPLAY")
    if not retained:
        pytest.skip("requires the existing zero-fit native replay, never creates a model fit")
    request = json.loads((Path(retained) / "replay-request.json").read_bytes())
    if changed == "model_training":
        altered = tmp_path / "altered-model.rds"
        code = ('args<-commandArgs(TRUE);f<-readRDS(args[[1L]]);'
                'f@data$AST_ALT[[1L]]<-f@data$AST_ALT[[1L]]+0.125;'
                'saveRDS(f,args[[2L]])')
        mutation = subprocess.run([RSCRIPT_EXECUTABLE, "--vanilla", "-e", code,
                                   request["model_path"], str(altered)],
                                  env=activated_environment(), capture_output=True, timeout=30)
        assert mutation.returncode == 0, mutation.stderr
        request["model_path"] = str(altered)
    else:
        altered = tmp_path / "altered-output.json"
        original = json.loads(Path(request["original_output_path"]).read_bytes())
        row = original["tasks"][0]["survival"][0]
        row[0] = 0.0 if row[0] != 0 else 1.0
        altered.write_bytes(canonical_json_bytes(original))
        request["original_output_path"] = str(altered)
    request["output_path"] = str(tmp_path / "unexpected-result.json")
    request_path = tmp_path / "request.json"
    request_path.write_bytes(canonical_json_bytes(request))
    kernel = Path(__file__).resolve().parents[1] / "padml/kernels/f4_o_fit_fpm_replay.R"
    completed = subprocess.run([RSCRIPT_EXECUTABLE, "--vanilla", str(kernel), str(request_path)],
                               env=activated_environment(), cwd=tmp_path,
                               capture_output=True, timeout=60)
    (tmp_path / "stdout.txt").write_bytes(completed.stdout)
    (tmp_path / "stderr.txt").write_bytes(completed.stderr)
    assert completed.returncode != 0 and reason.encode() in completed.stderr
    assert not Path(request["output_path"]).exists()
    assert (tmp_path / "native-failure.rda").is_file()


@pytest.mark.parametrize('family', ['XGBOOST_COX', 'COX_PH'])
@pytest.mark.parametrize('commit_failure', [False, True])
def test_native_commit_persists_four_members_before_scratch_release(tmp_path, monkeypatch, family, commit_failure):
    """UNFITTED engines; real f4 callback, exact writes/fsync and scratch lifetime."""
    from padml import f4, f5, nested_loco as nested
    from test_f5 import _raw_final_recipe
    job = native_component_fixture(tmp_path, apparent=True)
    native = Path(job['root'])
    task = json.loads(job['entries']['task.json'])
    task.update(family=family, parameters={'family': family, 'ties': 'breslow'})
    task['registered_model_seed'] = f4._f4_model_seed(family, task['f4_coordinates'])
    task['model_seed'] = task['registered_model_seed'] if family == 'XGBOOST_COX' else None
    job['entries']['task.json'] = canonical_json_bytes(task)
    job['entries']['recipe.json'] = canonical_json_bytes(_raw_final_recipe(family)[0])
    result = dict(model=b'UNFITTED_MODEL', baseline=b'UNFITTED_BASELINE',
        fit_health={'UNFITTED': True}, survival=[[1.0]*37 for _ in range(2)])
    required = {'model.bin': result['model'], 'baseline.bin': result['baseline'],
        'fit-health.json': canonical_json_bytes(result['fit_health']),
        'training-prediction.json': canonical_json_bytes(result['survival'])}
    scratches, releases, calls, synced = [], [], [], set()
    native_writes = []
    original_mkdtemp, original_rmtree = f5.tempfile.mkdtemp, f5.shutil.rmtree
    original_write, original_fsync = nested._write_exact_once, os.fsync
    def mkdtemp(*args, **kwargs):
        kwargs['dir'] = tmp_path
        value = original_mkdtemp(*args, **kwargs)
        scratches.append(Path(value)); return value
    def fsync(descriptor):
        result = original_fsync(descriptor)
        stat = os.fstat(descriptor); synced.add((stat.st_dev, stat.st_ino))
        return result
    def exact_write(path, raw, reason):
        if path.parent == native and path.name in required:
            native_writes.append((path.name, path.exists()))
        if commit_failure and path == native/'baseline.bin':
            raise OSError('INJECTED_NATIVE_COMMIT_FAILURE')
        return original_write(path, raw, reason)
    def release(path, *args, **kwargs):
        path = Path(path)
        if path in scratches:
            assert not commit_failure
            assert all((native/name).read_bytes() == raw for name, raw in required.items())
            # Atomic _write_exact_once links the already-fsynced temporary inode.
            for name in required:
                stat = (native/name).stat()
                assert (stat.st_dev, stat.st_ino) in synced
            stat = native.stat(); assert (stat.st_dev, stat.st_ino) in synced
            releases.append(path)
        return original_rmtree(path, *args, **kwargs)
    def python_leaf(task, rows, response, recipe, *, native_evidence):
        calls.append('UNFITTED_PYTHON')
        for name in ('model', 'baseline'):
            (native_evidence/(name+'.bin')).write_bytes(result[name])
        return copy.deepcopy(result)
    def r_leaf(command, **kwargs):
        calls.append('UNFITTED_R')
        spec = json.loads(Path(command[-1]).read_bytes())
        assert spec['action'] == 'FINAL_REFIT'
        Path(spec['model_path']).write_bytes(result['model'])
        Path(spec['baseline_path']).write_bytes(result['baseline'])
        Path(spec['output_path']).write_bytes(canonical_json_bytes(dict(
            schema_version='1.0.0', kind='PADML_F5_FINAL_REFIT_R_RESULT_V1', status='PASS',
            family=family, patient_ids=['001', '002'], horizons=list(range(37)),
            fit_health=result['fit_health'], survival=result['survival'])))
        return subprocess.CompletedProcess(command, 0)
    monkeypatch.setattr(f5.tempfile, 'mkdtemp', mkdtemp)
    monkeypatch.setattr(f5.shutil, 'rmtree', release)
    monkeypatch.setattr(nested, '_write_exact_once', exact_write)
    monkeypatch.setattr(os, 'fsync', fsync)
    monkeypatch.setattr(f5, '_execute_final_xgboost', python_leaf)
    monkeypatch.setattr(f5.subprocess, 'run', r_leaf)
    monkeypatch.setattr(f5, '_validate_final_r_fit_health', lambda family, health, *a, **kw: health)
    # No installed R runtime is required by this transport/lifecycle fixture.
    monkeypatch.setattr(f5, 'RSCRIPT_EXECUTABLE', str(Path(os.sys.executable)))
    if commit_failure:
        with pytest.raises(OSError, match='INJECTED_NATIVE_COMMIT_FAILURE') as failure:
            f4._execute_f4_model_component(job)
        assert not releases and len(scratches) == 1 and scratches[0].is_dir()
        extensions = ('model.bin', 'baseline.bin') if family == 'XGBOOST_COX' else ('model.rds', 'baseline.rds')
        assert [(scratches[0]/name).read_bytes() for name in extensions] == [result['model'], result['baseline']]
        assert not native.with_suffix('.zip').exists()
        assert any(str(scratches[0]) in note for note in failure.value.__notes__)
    else:
        f4._execute_f4_model_component(job)
        assert len(scratches) == 1 and releases == scratches and not scratches[0].exists()
        assert native.with_suffix('.zip').is_file()
        assert all((native/name).read_bytes() == raw for name, raw in required.items())
        assert len(native_writes) == 4 and not any(existed for _, existed in native_writes)
    assert calls == ['UNFITTED_PYTHON' if family == 'XGBOOST_COX' else 'UNFITTED_R']


@pytest.mark.parametrize('scope', ['PRIMARY', 'FULL0'])
def test_final_m20_last_incomplete_coordinate_blocks_every_fit(tmp_path, monkeypatch, scope):
    """Original M20 orchestrators must preflight all members before any pool."""
    from padml import f4, f5
    if scope == 'FULL0':
        from test_f45_final_full0_reuse import fixture, _policy
        (owner, inputs, outputs, lineage, tasks), _, counts = fixture(tmp_path, monkeypatch)
        native = outputs/'F5_FINAL_FULL_DATA_M20'
        entries = f5._nested_science._read_component(inputs/'bound/M20.zip')[2]
        invoke = lambda: f5.execute_final_refit_batch(inputs, outputs, resource_policy=_policy(),
            compiled_input_record={'UNFITTED_UPSTREAM': True}, selection_horizon_months=12)
    else:
        from test_f45_final_primary_reuse import fixture
        (request, root, lock, scores, bound), _, counts, _, _ = fixture(tmp_path, monkeypatch)
        native = root/'fits/M20'; entries = bound[-1]
        invoke = lambda: f4._o_fit_post_lock_m20(request, scores, root, workers=2, replay=False)
    native.mkdir(parents=True)
    for name, raw in entries.items():
        (native/name).write_bytes(raw)
    before = {path.name: (path.read_bytes(), path.stat().st_ino, path.stat().st_mtime_ns,
                         path.stat().st_ctime_ns) for path in native.iterdir()}
    def forbidden(*args, **kwargs):
        pytest.fail('M20_INCOMPLETE_LAST_MEMBER_MUST_STOP_BEFORE_POOL_OR_ENGINE')
    monkeypatch.setattr(f4, '_bounded_ordered_spawn', forbidden)
    monkeypatch.setattr(f5, '_bounded_ordered_spawn', forbidden)
    monkeypatch.setattr(f4, '_execute_f4_model_component', forbidden)
    monkeypatch.setattr(f5, '_execute_final_refit_engine', forbidden)
    with pytest.raises(ContractError, match='F4_NATIVE_MODEL_INCOMPLETE_ARCHIVE_REQUIRES_NEW_FIT_AUTHORITY'):
        invoke()
    assert counts['fit'] == counts['audit'] == 0 and counts['pools'] == []
    assert before == {path.name: (path.read_bytes(), path.stat().st_ino, path.stat().st_mtime_ns,
                                 path.stat().st_ctime_ns) for path in native.iterdir()}
    assert not native.with_suffix('.zip').exists()


@pytest.mark.parametrize('scope', ['PRIMARY', 'FULL0'])
def test_final_m20_preflight_started_target_cannot_become_fresh(tmp_path, monkeypatch, scope):
    """An already admitted pair stays no-fit even if dispatch sees it disappear."""
    from padml import f4, f5
    actual_component = f4._execute_f4_model_component
    if scope == 'FULL0':
        from test_f45_final_full0_reuse import fixture, _policy
        (owner, inputs, outputs, lineage, tasks), _, counts = fixture(tmp_path, monkeypatch)
        native = outputs/'F5_FINAL_FULL_DATA_M20'
        entries = f5._nested_science._read_component(inputs/'bound/M20.zip')[2]
        invoke = lambda: f5.execute_final_refit_batch(inputs, outputs, resource_policy=_policy(),
            compiled_input_record={'UNFITTED_UPSTREAM': True}, selection_horizon_months=12)
    else:
        from test_f45_final_primary_reuse import fixture
        (request, root, lock, scores, bound), _, counts, _, _ = fixture(tmp_path, monkeypatch)
        native = root/'fits/M20'; entries = bound[-1]
        invoke = lambda: f4._o_fit_post_lock_m20(request, scores, root, workers=2, replay=False)
    native.mkdir(parents=True)
    training = f4._f4_native_component_inputs(entries)[2]
    for name, raw in {**entries, 'model.bin': b'UNFITTED_MODEL', 'baseline.bin': b'UNFITTED_BASELINE',
        'fit-health.json': canonical_json_bytes({'UNFITTED': True}),
        'training-prediction.json': canonical_json_bytes([[1.0]*37 for row in training])}.items():
        (native/name).write_bytes(raw)
    original = {p.name: (p.read_bytes(), p.stat().st_ino) for p in native.iterdir()}
    preserved = native.with_name(native.name+'.probe-preserved')
    def forbidden(*args, **kwargs):
        pytest.fail('A_PREFLIGHT_RETAINED_PAIR_MUST_NEVER_REACH_FRESH_FIT_OR_DELETE')
    monkeypatch.setattr(f4, '_execute_f4_model_component', actual_component)
    monkeypatch.setattr(f5, '_execute_final_refit_engine', forbidden)
    monkeypatch.setattr(f5, '_validate_retained_model_objects', forbidden)
    monkeypatch.setattr(f4.shutil, 'rmtree', forbidden)
    if scope == 'FULL0':
        def pool(function, jobs, **kwargs):
            assert getattr(function, 'func', function) is f5._execute_final_refit_bundle_pair
            native.rename(preserved)
            return function(next(job for job in jobs if job[3]['imputation'] == 20))
        monkeypatch.setattr(f5, '_bounded_ordered_spawn', pool)
    else:
        def reuse(*args, **kwargs):
            native.rename(preserved)
            return {}
        monkeypatch.setattr(f5, '_prepare_f45_primary_final_reuse', reuse)
        def pool(function, jobs, **kwargs):
            return function(next(job for job in jobs if Path(job['root']) == native))
        monkeypatch.setattr(f4, '_bounded_ordered_spawn', pool)
    with pytest.raises(ContractError, match='F4_NATIVE_MODEL_INCOMPLETE_ARCHIVE_REQUIRES_NEW_FIT_AUTHORITY'):
        invoke()
    assert not native.exists() and not native.with_suffix('.zip').exists()
    assert original == {p.name: (p.read_bytes(), p.stat().st_ino) for p in preserved.iterdir()}
    assert counts['fit'] == counts['audit'] == 0
