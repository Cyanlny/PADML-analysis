"""Direct A12 outer CLI and actual R coordinate/binding arithmetic; no fits."""
import copy
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

import pytest

from padml.bundle import ContractError, canonical_json_bytes, sha256_bytes, write_deterministic_zip
from padml import f5, f5_sensitivity as sensitivity, nested_loco as nested, runtime


def _unfitted_final_source():
    return {"kind": "PADML_NESTED_AAR_FINAL_SOURCE_V1", "program_id": nested.PROGRAM_ID,
        **{name: "a" * 64 for name in ("science_decision_sha256", "primary_development_lock_sha256",
            "training_context_sha256", "inputs_identity_sha256", "development_input_sha256", "parameter_source_sha256")}}


@pytest.mark.parametrize("family", ["COX_PH", "FPM_TVC_SET_A"])
def test_legacy_a12_low_level_family_argument_needs_no_duplicate_task_field(family):
    task = {"selected_parents": ["Age"], "imputation": 1, "model_seed": None,
        "a12_coordinates": {"outer_fold": 2, "branch": "WITHOUT_AST_ALT_TOTAL", "imputation": 1},
        "parameters": {"family": family, **({"df": 3, "tvc_df": 0} if family == "FPM_TVC_SET_A" else {"ties": "breslow"})}}
    f5._validate_a12_model_task(family, task)


@pytest.mark.parametrize("branch", nested.AAR_ESTIMANDS)
def test_three_aar_native_task_requires_bound_development_and_original_seed(branch):
    task = {"family": "COX_PH", "selected_parents": ["Age"], "imputation": 19,
        "a12_coordinates": {"outer_fold": 1, "branch": branch, "imputation": 19},
        "registered_model_seed": 301019, "model_seed": None, "nested_aar_final_source": _unfitted_final_source()}
    f5._validate_a12_model_task("COX_PH", task)
    for damage in ("missing", "legacy", "seed", "program", "short_hash", "mixed_coordinates"):
        bad = copy.deepcopy(task)
        if damage == "missing":
            del bad["nested_aar_final_source"]
        elif damage == "legacy":
            bad["a12_coordinates"]["branch"] = "WITHOUT_AST_ALT_TOTAL"
        elif damage == "seed":
            bad["registered_model_seed"] += 1
        elif damage == "program":
            bad["nested_aar_final_source"]["program_id"] = "OTHER_PROGRAM"
        elif damage == "short_hash":
            bad["nested_aar_final_source"]["development_input_sha256"] = "a"
        else:
            bad["a04_coordinates"] = {}
        with pytest.raises(ContractError):
            f5._validate_a12_model_task("COX_PH", bad)


def test_three_aar_python_native_binding_includes_primary_and_branch_source():
    import numpy as np
    task = {"family": "XGBOOST_COX", "selected_parents": ["Age"], "parameters": {"UNFITTED": True},
        "imputation": 1, "model_seed": 301001,
        "a12_coordinates": {"outer_fold": 1, "branch": nested.A12_TOTAL_AAR, "imputation": 1},
        "nested_aar_final_source": _unfitted_final_source()}
    def bind(value):
        return f5._native_python_training_binding("XGBOOST_COX", value,
            [{"Patient_ID": "UNFITTED", "Center": "38"}], {"UNFITTED": True},
            np.asarray([[50.0]]), ["Age"], np.asarray([12.0]), np.asarray([1]))
    original = bind(task)
    for field in ("primary_development_lock_sha256", "science_decision_sha256", "development_input_sha256", "parameter_source_sha256"):
        bad = copy.deepcopy(task)
        bad["nested_aar_final_source"][field] = "b" * 64
        changed = bind(bad)
        assert changed != original and changed["consumed_input_sha256"] == original["consumed_input_sha256"]


def _unfitted_final_resource_source():
    return {"kind": "PADML_F5_A12_PROJECTED_OUTER_INPUTS_V1", "family": "COX_PH",
        "primary_source": {"primary_training_context": {"heldout_ids": ["UNFITTED"]}},
        "resource_policy": {"configured_worker_ceiling": runtime.CPU_MINUS_8,
            "memory_bytes_per_worker": 1, "scratch_bytes_per_worker": 1,
            "memory_reserve_bytes": 0, "scratch_reserve_bytes": 0, "transfer_archive_worker_ceiling": 1000}}


def test_three_aar_final_reserves_all_retained_components_and_archive(tmp_path):
    source = _unfitted_final_resource_source()
    jobs = [{"entries": {"UNFITTED": b"not a model"}} for _ in range(60)]
    reserved = sensitivity._a12_final_resource_reservation(source, jobs, {"inputs.zip": 2000}, 1024**2)
    assert reserved["component_retention_reserved_bytes"] == 60 * 1024**2
    assert reserved["archive_reserved_bytes"] > 2 * reserved["component_retention_reserved_bytes"]
    observation = {"effective_cpus": 64, "available_memory_bytes": 10**12,
                   "scratch_available_bytes": 2 * 1024**2, "scratch_root": str(tmp_path)}
    assert runtime.resource_admission(source["resource_policy"], observation, legal_tasks=60)["admitted_worker_ceiling"] == 56
    with pytest.raises(ContractError, match="RESOURCE_ADMISSION_ZERO"):
        runtime.resource_admission(reserved["effective_policy"], observation, legal_tasks=60)
    for invalid in (None, True, 0, 1.5):
        with pytest.raises(ContractError, match="FINAL_RETENTION_ESTIMATE_REQUIRED"):
            sensitivity._a12_final_resource_reservation(source, jobs, {}, invalid)


@pytest.mark.parametrize("phase", ["before_final_pool", "before_archive_write"])
def test_three_aar_outer_refuses_insufficient_cumulative_space_before_effect(tmp_path, monkeypatch, phase):
    """Original owner admission; unrelated development leaves explicitly stubbed."""
    source, target = tmp_path / "UNFITTED-inputs.zip", tmp_path / "outer.zip"
    source.write_bytes(b"UNFITTED resource-boundary fixture")
    prepared = {"source": _unfitted_final_resource_source(), "family": "COX_PH", "outer_fold": 1,
                "input_expansion_resources": {"UNFITTED": True}}
    jobs = [{"name": f"UNFITTED_{i}", "entries": {"UNFITTED": b"not a model"}} for i in range(60)]
    monkeypatch.setattr(sensitivity, "materialize_a12_outer_inputs", lambda *args, **kwargs: prepared)
    monkeypatch.setattr(sensitivity, "_a12_projected_development_inputs", lambda *args, **kwargs: prepared)
    monkeypatch.setattr(sensitivity, "_a12_outer_searches", lambda *args, **kwargs: {})
    monkeypatch.setattr(sensitivity, "_a12_outer_model_jobs", lambda *args: jobs)
    monkeypatch.setattr(sensitivity, "_a12_outer_retained_members", lambda *args, **kwargs: {"inputs.zip": source})
    monkeypatch.setattr(sensitivity, "_a12_outer_predictions", lambda *args: {"UNFITTED": True})
    pools, observations = [], []
    def observe(root):
        observations.append(root)
        scarce = phase == "before_final_pool" or len(observations) > 1
        return {"effective_cpus": 64, "available_memory_bytes": 10**12,
                "scratch_available_bytes": 1 if scarce else 10**12, "scratch_root": str(root)}
    def unfitted_pool(*args, **kwargs):
        pools.append("UNFITTED")
        return []
    monkeypatch.setattr(runtime, "observe_execution_resources", observe)
    monkeypatch.setattr(sensitivity, "_bounded_ordered_spawn", unfitted_pool)
    with pytest.raises(ContractError, match="RESOURCE_ADMISSION_ZERO"):
        sensitivity.execute_a12_outer_bundle(source, target, input_bundle=source,
            retained_bytes_per_component=1024**2)
    assert pools == ([] if phase == "before_final_pool" else ["UNFITTED"])
    assert not target.exists()
    assert (tmp_path / "outer.zip.work/execution.json").is_file()


def test_three_aar_outer_checks_actual_expansion_before_extracting(tmp_path, monkeypatch):
    source = _unfitted_final_resource_source()
    projected, archive = tmp_path / "UNFITTED-projected.zip", tmp_path / "UNFITTED-outer.zip"
    write_deterministic_zip(projected, {"a12-inputs.json": canonical_json_bytes(source)})
    payload = bytes(range(256)) * 8192
    body = {"kind": "PADML_F5_A12_OUTER_NATIVE_V2", "source": source, "family": "COX_PH", "outer_fold": 1,
            "predictions": {"UNFITTED": True}, "members": {"UNFITTED.bin": {"sha256": sha256_bytes(payload), "size_bytes": len(payload)}}}
    write_deterministic_zip(archive, {"a12-outer.json": canonical_json_bytes(nested._sealed(body)), "UNFITTED.bin": payload})
    extracted = []
    monkeypatch.setattr(sensitivity, "extract_safe_zip", lambda *args, **kwargs: extracted.append(args))
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda root: {
        "effective_cpus": 64, "available_memory_bytes": 10**12,
        "scratch_available_bytes": 1024**2, "scratch_root": str(root)})
    with pytest.raises(ContractError, match="RESOURCE_ADMISSION_ZERO"):
        sensitivity._load_a12_outer_archive(archive, input_bundle=projected, replay_evidence=tmp_path / "replay")
    assert not extracted and not (tmp_path / "replay/archive").exists()


@pytest.mark.parametrize("family,mice,candidate,stop,paths,total", [
    ("COX_PH", 680, 0, 0, 640, 60), ("FPM_TVC_SET_A", 680, 0, 0, 640, 60),
    ("ELASTIC_NET_COX", 1280, 0, 0, 2560, 60), ("RSF", 1280, 1070, 0, 640, 3270),
    ("GBM_COX", 2480, 1140, 1140, 640, 6900), ("XGBOOST_COX", 2480, 1300, 1300, 640, 7860),
    ("COXTIME_SET_A", 2480, 810, 810, 640, 4920),
])
def test_three_aar_execution_ledger_uses_actual_counts_below_path_caps(tmp_path, family, mice, candidate, stop, paths, total):
    """Pure counter reducer, not a substitute for native archive validation."""
    from test_nested_full_development import _unfitted_confirmed_decision
    source = {"kind": "PADML_F5_A12_PROJECTED_OUTER_INPUTS_V1", "mice_inputs": [{}] * (mice // 20),
              "primary_source": {"science_decision": _unfitted_confirmed_decision(fixed_bootstrap=True)}}
    row = {"family": family, "outer_fold": 1, "identity_sha256": "b" * 64, "source": source}
    members = {f"fits/O1_{branch}_M{imp:02d}.zip": b"UNFITTED_COMPONENT_PLACEHOLDER"
               for branch in nested.AAR_ESTIMANDS for imp in range(1, 21)}
    selector = {"selector_path_count": 640, "glmnet_call_count": 1280}
    members["development/selector/development-input.json"] = canonical_json_bytes(selector)
    for branch in nested.AAR_ESTIMANDS:
        if family == "ELASTIC_NET_COX":
            members[f"search/{branch}/search.json"] = canonical_json_bytes({
                "path_execution_count": 640, "glmnet_pilot_and_path_call_count": 1280})
        elif family in sensitivity._A12_TUNED_FAMILIES:
            members[f"search/{branch}/result.json"] = canonical_json_bytes({
                "locked_training_refit_count": candidate, "response_free_stopping_fit_count": stop})
    path = tmp_path / "UNFITTED-counts.zip"
    write_deterministic_zip(path, members)
    observed = sensitivity._a12_outer_archive_record(row, path)["execution_ledger"]
    assert observed == {"mice_chains": mice, "elastic_path_executions": paths, "glmnet_pilot_and_path_calls": 2 * paths,
        "candidate_prediction_fits": 3 * candidate, "stop_fits": 3 * stop,
        "inner_scoring_fits": 0, "post_lock_fits": 60, "total_model_fits": total}
    if family == "COX_PH":
        for damage in ("too_many_paths", "wrong_calls", "bool_paths", "missing_final", "missing_mice"):
            bad, changed = copy.deepcopy(members), copy.deepcopy(row)
            values = dict(selector)
            if damage == "too_many_paths":
                values = {"selector_path_count": 4801, "glmnet_call_count": 9602}
            elif damage == "wrong_calls":
                values["glmnet_call_count"] += 1
            elif damage == "bool_paths":
                values = {"selector_path_count": False, "glmnet_call_count": 0}
            elif damage == "missing_final":
                del bad[f"fits/O1_{nested.A12_TOTAL_AAR}_M20.zip"]
            else:
                changed["source"]["mice_inputs"].pop()
            bad["development/selector/development-input.json"] = canonical_json_bytes(values)
            bad_path = tmp_path / (damage + ".zip")
            write_deterministic_zip(bad_path, bad)
            with pytest.raises(ContractError, match="(EXECUTION_BUDGET_DRIFT|OUTER_M20_REQUIRED)"):
                sensitivity._a12_outer_archive_record(changed, bad_path)


def test_a12_outer_cli_uses_original_input_archive_and_lineage(tmp_path, monkeypatch, capsys):
    source, inputs, result = (tmp_path / name for name in ("lineage.json", "inputs.zip", "outer.zip"))
    lineage = {"fixture": "UNFITTED_LINEAGE"}
    source.write_bytes(canonical_json_bytes(lineage))
    calls = []

    def unfitted(input_archive, target, **kwargs):
        calls.append((input_archive, target, kwargs))
        return {"status": "UNFITTED", "stage_acceptance": False}

    monkeypatch.setattr(sensitivity, "execute_a12_outer_bundle", unfitted)
    monkeypatch.setattr(sys, "argv", ["padml.f5_sensitivity", "a12-outer", str(source), str(result),
        "--sources", str(inputs), "--f2-run-root", str(tmp_path), "--workers", "24"])
    sensitivity.main()
    assert calls == [(inputs, result, {"lineage": lineage, "f2_run_root": tmp_path, "workers": 24,
                                     "f1_runtime_root": None})]
    assert json.loads(capsys.readouterr().out)["stage_acceptance"] is False
    assert not result.exists()


def test_f5_public_three_branch_outer_forwards_only_projected_native_inputs(tmp_path, monkeypatch, capsys):
    inputs, projected, target = (tmp_path / name for name in ("mice.zip", "projected.zip", "outer.zip"))
    calls = []
    def unfitted(source, result, **kwargs):
        calls.append((source, result, kwargs))
        return {"status": "UNFITTED", "stage_acceptance": False}
    monkeypatch.setattr(sensitivity, "execute_a12_outer_bundle", unfitted)
    monkeypatch.setattr(sys, "argv", ["padml-f5", "a12-outer", str(inputs), str(target), "--input-bundle", str(projected),
        "--retained-bytes-per-component", "2097152"])
    f5.main()
    assert calls == [(inputs, target, {"input_bundle": projected, "retained_bytes_per_component": 2097152})]
    assert json.loads(capsys.readouterr().out)["stage_acceptance"] is False
    assert not target.exists()


_R_COORDINATES = r'''
args <- commandArgs(trailingOnly=TRUE)
program <- as.list(parse(args[[1L]]))
e <- new.env(parent=baseenv())
e$scalar <- function(value) unname(unlist(value, use.names=FALSE)[[1L]])
e$need <- function(value, code) if (!isTRUE(value)) stop(code, call.=FALSE)
coordinate <- Filter(function(x) is.call(x) && identical(x[[1L]],as.name("if")) &&
                     identical(x[[2L]],as.name("a12")), program)
stopifnot(length(coordinate)==1L)
binding <- Filter(function(x) is.call(x) && identical(x[[1L]],as.name("<-")) &&
                  identical(x[[2L]],as.name("native_training_binding")),program)
stopifnot(length(binding)==1L)
eval(binding[[1L]],e)
e$a12 <- TRUE
e$selected <- "HGB"
e$spec <- list(family="COX_PH", imputation=19L, model_seed=NULL, selected_parents="HGB",
               parameters=list(ties="breslow"), recipe=list(fixture="UNFITTED"),
               a12_coordinates=list(outer_fold=1L,branch="WITHOUT_AST_ALT_DIRECT",imputation=19L))
eval(coordinate[[1L]],e)
stopifnot(e$expected_seed==301019L)
original <- e$native_training_binding(e$spec,c("a","b"),c("36","36"),
                                     matrix(c(1,2),2,1),c(3,4),c(1,0))
e$spec$a12_coordinates$branch <- "WITHOUT_AST_ALT_TOTAL"
eval(coordinate[[1L]],e)
changed <- e$native_training_binding(e$spec,c("a","b"),c("36","36"),
                                    matrix(c(1,2),2,1),c(3,4),c(1,0))
stopifnot(e$expected_seed==301019L, !identical(original,changed),
          identical(original$consumed_input_sha256,changed$consumed_input_sha256))
reject <- function() {
  value <- tryCatch({eval(coordinate[[1L]],e); NULL}, error=identity)
  stopifnot(inherits(value,"error"),grepl("F5_A12_COORDINATES_INVALID",conditionMessage(value),fixed=TRUE))
}
e$spec$imputation <- 18L; reject()
e$spec$imputation <- 19L; e$spec$a12_coordinates$branch <- "PRIMARY_POLICY_A"; reject()
e$spec$a12_coordinates$branch <- "WITHOUT_AST_ALT_TOTAL"
e$spec$c10_coordinates <- list(); reject()
e$spec$c10_coordinates <- NULL
hashes <- c("science_decision_sha256","primary_development_lock_sha256","training_context_sha256",
            "inputs_identity_sha256","development_input_sha256","parameter_source_sha256")
e$spec$nested_aar_final_source <- c(list(kind="PADML_NESTED_AAR_FINAL_SOURCE_V1",program_id="PADML_NESTED_LOCO_20260908"),
                                    setNames(rep(list(paste(rep("a",64),collapse="")),length(hashes)),hashes))
source_original <- e$spec$nested_aar_final_source
for (branch in c("A12_WITHOUT_AST_ALT_DIRECT","A12_WITHOUT_AST_ALT_TOTAL","OUTER_SELECTED_FAMILY_NO_AAR_REDEVELOPMENT")) {
  e$spec$a12_coordinates$branch <- branch
  eval(coordinate[[1L]],e)
  stopifnot(e$expected_seed==301019L)
}
bind <- function() e$native_training_binding(e$spec,c("a","b"),c("36","36"),matrix(c(1,2),2,1),c(3,4),c(1,0))
original <- bind()
for (field in hashes) {
  e$spec$nested_aar_final_source[[field]] <- paste(rep("b",64),collapse="")
  changed <- bind()
  stopifnot(!identical(original,changed),identical(original$consumed_input_sha256,changed$consumed_input_sha256))
  e$spec$nested_aar_final_source <- source_original
}
reject_source <- function() {
  value <- tryCatch({eval(coordinate[[1L]],e); NULL},error=identity)
  stopifnot(inherits(value,"error"),grepl("NESTED_AAR_FINAL_SOURCE_INVALID",conditionMessage(value),fixed=TRUE))
}
e$spec$nested_aar_final_source <- NULL; reject_source()
e$spec$nested_aar_final_source <- source_original
e$spec$nested_aar_final_source$development_input_sha256 <- "a"; reject_source()
e$spec$nested_aar_final_source <- source_original
e$spec$a12_coordinates$branch <- "WITHOUT_AST_ALT_TOTAL"; reject_source()
cat("PASS actual R coordinates and native binding; fits=0 RNG=0\n")
'''


def test_a12_r_coordinates_bind_branch_and_exact_imputation(tmp_path):
    rscript = shutil.which("Rscript")
    if rscript is None:
        pytest.skip("Rscript unavailable; this test performs no fitting")
    script = tmp_path / "coordinates.R"
    script.write_text(_R_COORDINATES, encoding="utf-8")
    kernel = Path(sensitivity.__file__).parent / "kernels/f5_final_refit.R"
    process = subprocess.run([rscript, "--vanilla", str(script), str(kernel)],
        capture_output=True, text=True, timeout=30,
        env={**os.environ, "OMP_NUM_THREADS": "1", "OPENBLAS_NUM_THREADS": "1", "MKL_NUM_THREADS": "1"})
    (tmp_path / "r.stdout.log").write_text(process.stdout, encoding="utf-8")
    (tmp_path / "r.stderr.log").write_text(process.stderr, encoding="utf-8")
    assert process.returncode == 0, process.stdout + process.stderr
    assert "fits=0 RNG=0" in process.stdout


# Unfitted frequency-amendment boundaries; no native fit, metric, or RNG execution.
import copy
import math
from padml import f5_sensitivity as _freq_a, nested_loco as _freq_n
from padml.bundle import sha256_bytes
_FREQUENCY_BRANCH = _freq_n.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT

def _frequency_negative(source, *, selector_identity='3' * 64, pins=None):
    alphas = f5.load_science_authority()['science']['f2_model_development']['selector_contract']['alpha_grid']['coarse']
    epv = {'preferred_minimum': 15, 'minimum': 10, 'fallback_used': True, 'frequency_policy_sha256': _freq_n.selector_frequency_policy()['identity_sha256'], 'coarse_records_sha256': pins['coarse/paths.json']['sha256'] if pins else '4' * 64, 'frequency_threshold': 20, 'status': 'NOT_ESTIMABLE', 'reason_code': 'FREQUENCY_LADDER_EXHAUSTED', 'attempts': [{**tier, 'alpha_feasibility': [{'alpha': x, 'status': 'NOT_ESTIMABLE', 'reason_code': 'EMPTY_FREQUENCY_AGGREGATE', 'common_set_design_df': 0, 'common_set_epv': None} for x in alphas]} for tier in _freq_n.selector_frequency_policy()['ladder']]}
    return _freq_n._sealed({'kind': 'PADML_F5_A12_NONESTIMABLE_BRANCH_V1', 'branch': _FREQUENCY_BRANCH, 'status': 'NOT_ESTIMABLE', 'reason_code': 'FREQUENCY_LADDER_EXHAUSTED', 'outer_fold': source['outer_fold'], 'source_identity_sha256': source['identity_sha256'], 'source_input_identity_sha256': '1' * 64, 'selector_development_sha256': selector_identity, 'epv_resolution': epv, 'selector_members': pins or {name: {'sha256': '4' * 64, 'size_bytes': 1} for name in ('development-input.json', 'selector.json', 'coarse/paths.json')}})

def _frequency_prepared():
    source = {'kind': 'PADML_F5_A12_PROJECTED_OUTER_INPUTS_V1', 'identity_sha256': 'a' * 64, 'outer_fold': 3, 'primary_source': {'primary_training_context': {'heldout_ids': ['h1', 'h2'], 'heldout_center': 38}}}
    proof = _frequency_negative(source)
    return {'family': 'COX_PH', 'outer_fold': 3, 'source': source, 'estimability': {_FREQUENCY_BRANCH: proof}, 'members': {'development/selector/' + name: pin for name, pin in proof['selector_members'].items()}}

@pytest.mark.parametrize('damage', [None, 'missing-tier', 'native-error', 'feasible-alpha', 'wrong-policy', 'wrong-source', 'wrong-pin', 'coarse-trace', 'wrong-branch'])
def test_frequency_terminal_authority_exact(damage):
    p = _frequency_prepared()
    proof = p['estimability'][_FREQUENCY_BRANCH]
    if damage == 'missing-tier':
        proof['epv_resolution']['attempts'].pop()
    elif damage == 'native-error':
        proof['epv_resolution']['attempts'][0]['alpha_feasibility'][0]['reason_code'] = 'NATIVE_FAILED'
    elif damage == 'feasible-alpha':
        proof['epv_resolution']['attempts'][0]['alpha_feasibility'][0].update(status='FEASIBLE', reason_code='OK', common_set_design_df=1, common_set_epv=20)
    elif damage == 'wrong-policy':
        proof['epv_resolution']['frequency_policy_sha256'] = '0' * 64
    elif damage == 'wrong-source':
        proof['source_identity_sha256'] = '0' * 64
    elif damage == 'wrong-pin':
        p['members']['development/selector/coarse/paths.json'] = {'sha256': '0' * 64, 'size_bytes': 1}
    elif damage == 'coarse-trace':
        proof['epv_resolution']['coarse_records_sha256'] = '0' * 64
    elif damage == 'wrong-branch':
        p['estimability'] = {_freq_n.A12_TOTAL_AAR: proof}
    if damage not in (None, 'wrong-branch'):
        p['estimability'][_FREQUENCY_BRANCH] = _freq_n._sealed({k: v for k, v in proof.items() if k != 'identity_sha256'})
    if damage is None:
        assert _freq_a._a12_estimable_branches(p) == _freq_n.AAR_ESTIMANDS[:2]
    else:
        with pytest.raises(ContractError):
            _freq_a._a12_estimable_branches(p)

@pytest.mark.parametrize('damage', [None, 'm19', 'invent-third', 'no-proof'])
def test_frequency_partial_predictions_keep_both_complete_m20(damage):
    p = _frequency_prepared()
    jobs = []
    rows = []
    for branch in _freq_n.AAR_ESTIMANDS[:2]:
        for imp in range(1, 21):
            c = {'outer_fold': 3, 'branch': branch, 'imputation': imp}
            jobs.append({'entries': {'task.json': canonical_json_bytes({'a12_coordinates': c})}})
            rows.append({'a12_coordinates': c, 'family': 'COX_PH', 'patient_ids': ['h1', 'h2'], 'centers': ['38', '38'], 'horizons': _freq_a.HORIZONS, 'survival': [[1.0] + [0.6 + imp / 1000] * 36, [1.0] + [0.7 + imp / 1000] * 36]})
    if damage == 'm19':
        jobs.pop()
        rows.pop()
    elif damage == 'invent-third':
        rows[-1]['a12_coordinates']['branch'] = _FREQUENCY_BRANCH
    elif damage == 'no-proof':
        p.pop('estimability')
    if damage:
        with pytest.raises(ContractError):
            _freq_a._a12_outer_predictions(p, jobs, rows)
    else:
        out = _freq_a._a12_outer_predictions(p, jobs, rows)
        assert tuple(out['survival']) == _freq_n.AAR_ESTIMANDS[:2]
        assert out['patient_ids'] == ['h1', 'h2'] and out['survival'][_freq_n.A12_DIRECT_AAR][0][1] == math.fsum((0.6 + i / 1000 for i in range(1, 21))) / 20

def test_frequency_real_development_entry_terminal_publish_and_reentry(tmp_path, monkeypatch):
    root = tmp_path / 'development'
    (root / 'selector/coarse').mkdir(parents=True)
    source = {'kind': 'PADML_F5_A12_PROJECTED_OUTER_INPUTS_V1', 'identity_sha256': 'a' * 64, 'outer_fold': 3, 'family': 'COX_PH', 'primary_source': {'primary_development_lock': {'selected_family': 'COX_PH'}}}
    negative_proof = _frequency_negative(source)
    selector = {'identity_sha256': '3' * 64, 'selector': {'status': 'NOT_ESTIMABLE', 'selected_parents': [], 'epv_resolution': negative_proof['epv_resolution']}}
    for name, raw in [('development-input.json', canonical_json_bytes(selector)), ('selector.json', canonical_json_bytes(selector['selector'])), ('coarse/paths.json', b'{"UNFITTED_FULL_PATH_FIXTURE":true}\n')]:
        (root / 'selector' / name).write_bytes(raw)
    selector['selector']['epv_resolution']['coarse_records_sha256'] = sha256_bytes((root / 'selector/coarse/paths.json').read_bytes())
    (root / 'selector/development-input.json').write_bytes(canonical_json_bytes(selector))
    (root / 'selector/selector.json').write_bytes(canonical_json_bytes(selector['selector']))
    original = {'branches': {_FREQUENCY_BRANCH: {'partitions': [], 'identity': sha256_bytes(canonical_json_bytes([]))}}}
    old = {branch: {'UNFITTED_FIXED_BRANCH': True} for branch in _freq_n.AAR_ESTIMANDS[:2]}
    for name, value in old.items():
        (root / (name + '.json')).write_bytes(canonical_json_bytes(value))
    p = {'source': source, 'family': 'COX_PH', 'outer_fold': 3, 'branches': {_FREQUENCY_BRANCH: {'partitions': []}}, 'branch_development': old, 'source_input_record': original}
    monkeypatch.setattr(_freq_a, '_a12_nested_mice_source', lambda *args, **kw: {'training_event_count': 40})
    monkeypatch.setattr(_freq_a, '_a12_no_aar_selector_program', lambda *args, **kw: copy.deepcopy(selector))
    monkeypatch.setattr(f5, '_nested_selector_numerical_members', lambda root: {name: root / name for name in negative_proof['selector_members']})
    monkeypatch.setattr(_freq_a, '_a12_outer_input_record', lambda *args, **kw: {'UNFITTED_BRANCH_INPUT': True})
    monkeypatch.setattr(f5, '_compile_partition_design_recipe', lambda *args, **kw: pytest.fail('terminal must not compile a model recipe'))
    first = _freq_a._a12_projected_development_inputs(p, root, replay=False, branch=_FREQUENCY_BRANCH)
    files = {p: p.read_bytes() for p in root.rglob('*') if p.is_file()}
    second = _freq_a._a12_projected_development_inputs(p, root, replay=False, branch=_FREQUENCY_BRANCH)
    assert first['estimability'] == second['estimability'] and first['branch_development'] == second['branch_development']
    assert first['branches'][_FREQUENCY_BRANCH]['status'] == 'NOT_ESTIMABLE' and first['branches'][_FREQUENCY_BRANCH]['recipes'] == {}
    assert files == {p: p.read_bytes() for p in files}
    assert tuple(_freq_a._a12_estimable_branches(first)) == _freq_n.AAR_ESTIMANDS[:2]

def _frequency_partial_outer_files(tmp_path, *, family='COX_PH'):
    from padml.bundle import write_deterministic_zip, sha256_file
    source = _frequency_prepared()['source']
    source.update(family=family)
    science = _freq_n.science_decision_template(24)
    source['primary_source']['science_decision'] = science
    budgets = [science['fit_budget'][name]['per_outer_by_inherited_family'][family] for name in ('a12_direct_total', 'outer_selected_family_no_aar_redevelopment')]
    source['mice_inputs'] = [{} for _ in range(sum((b['mice_chains'] for b in budgets)) // 20)]
    proof = _frequency_negative(source)
    proof['epv_resolution']['coarse_records_sha256'] = sha256_bytes(b'{"UNFITTED_FULL_PATH_FIXTURE":true}\n')
    selector = _freq_n._sealed({'selector': {'status': 'NOT_ESTIMABLE', 'epv_resolution': proof['epv_resolution']}, 'selector_path_count': 320, 'glmnet_call_count': 640})
    rawselector = canonical_json_bytes(selector)
    rawresult = canonical_json_bytes(selector['selector'])
    rawpaths = b'{"UNFITTED_FULL_PATH_FIXTURE":true}\n'
    pins = {name: {'sha256': sha256_bytes(raw), 'size_bytes': len(raw)} for name, raw in (('development-input.json', rawselector), ('selector.json', rawresult), ('coarse/paths.json', rawpaths))}
    proof = _frequency_negative(source, selector_identity=selector['identity_sha256'], pins=pins)
    members = {'development/selector/development-input.json': rawselector, 'development/selector/selector.json': rawresult, 'development/selector/coarse/paths.json': rawpaths, 'development/' + _FREQUENCY_BRANCH + '.json': canonical_json_bytes(proof), 'development/development.json': canonical_json_bytes({_FREQUENCY_BRANCH: proof}), 'execution.json': canonical_json_bytes({'UNFITTED': True})}
    for branch in _freq_n.AAR_ESTIMANDS[:2]:
        members[f'development/{branch}.json'] = canonical_json_bytes({'UNFITTED_FIXED_BRANCH': True})
        for imp in range(1, 21):
            members[f'fits/O3_{branch}_M{imp:02d}.numbers.json'] = canonical_json_bytes({'UNFITTED': True})
            members[f'fits/O3_{branch}_M{imp:02d}.zip'] = b'UNFITTED_MODEL_ARCHIVE'
    for name, raw in members.items():
        dest = tmp_path / name
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(raw)
    input_path = tmp_path / 'inputs.zip'
    write_deterministic_zip(input_path, {'a12-inputs.json': canonical_json_bytes({'mice_views': {}, 'mice_reuse': {}})})
    members['inputs.zip'] = input_path.read_bytes()
    row = {'family': family, 'outer_fold': 3, 'source': source, 'estimability': {_FREQUENCY_BRANCH: proof}, 'members': {name: {'sha256': sha256_bytes(raw), 'size_bytes': len(raw)} for name, raw in members.items()}, 'native_members': {name: {'sha256': sha256_bytes(raw), 'size_bytes': len(raw)} for name, raw in members.items() if name.startswith('fits/') and name.endswith('.zip')}}
    row = _freq_n._sealed(row)
    archive = tmp_path / 'outer.zip'
    write_deterministic_zip(archive, members)
    return (row, archive, members)

@pytest.mark.parametrize('damage', [None, 'missing-m20', 'changed-negative', 'extra-third'])
def test_frequency_partial_archive_ledger_and_member_closure(tmp_path, monkeypatch, damage):
    from padml.bundle import write_deterministic_zip
    row, archive, members = _frequency_partial_outer_files(tmp_path)
    monkeypatch.setattr(f5, '_nested_selector_numerical_members', lambda root: {name: root / name for name in row['estimability'][_FREQUENCY_BRANCH]['selector_members']})
    if damage == 'missing-m20':
        name = f'fits/O3_{_freq_n.A12_DIRECT_AAR}_M20.numbers.json'
        members.pop(name)
        (tmp_path / name).unlink()
    elif damage == 'changed-negative':
        name = 'development/' + _FREQUENCY_BRANCH + '.json'
        members[name] = canonical_json_bytes({'NOT_ORIGINAL_PROOF': True})
        (tmp_path / name).write_bytes(members[name])
    elif damage == 'extra-third':
        members[f'fits/O3_{_FREQUENCY_BRANCH}_M01.numbers.json'] = canonical_json_bytes({'NO_AUTHORIZATION': True})
    if damage:
        archive = tmp_path / (damage + '.zip')
    write_deterministic_zip(archive, members)
    if damage:
        with pytest.raises((ContractError, KeyError)):
            _freq_a._a12_outer_archive_record(row, archive, mice_index={'mice_views': {}, 'mice_reuse': {}})
    else:
        retained = _freq_a._a12_outer_retained_members(tmp_path, 'COX_PH', 3, tmp_path / 'inputs.zip', prepared=row)
        assert set(retained) == set(members)
        record = _freq_a._a12_outer_archive_record(row, archive, mice_index={'mice_views': {}, 'mice_reuse': {}})
        ledger = record['execution_ledger']
        assert ledger['post_lock_fits'] == ledger['total_model_fits'] == 40
        assert ledger['elastic_path_executions'] == 320 and ledger['glmnet_pilot_and_path_calls'] == 640
        assert ledger['mice_chains'] == 20 * len(row['source']['mice_inputs'])
        assert record['estimability'] == row['estimability']
        prefix = _freq_a._a12_outer_retained_members(tmp_path, 'COX_PH', 3, tmp_path / 'inputs.zip', prepared=row, before_final=True, completed_branches=_freq_n.AAR_ESTIMANDS[:2])
        assert not any((name.startswith('development/selector/') for name in prefix))
        assert 'development/' + _FREQUENCY_BRANCH + '.json' not in prefix

@pytest.mark.parametrize('count', [40, 39, 41])
def test_frequency_partial_prepared_capture_uses_only_real_m20_jobs(tmp_path, monkeypatch, count):
    from padml import runtime
    row, archive, members = _frequency_partial_outer_files(tmp_path / 'owner')
    policy = dict(configured_worker_ceiling=runtime.CPU_MINUS_8, memory_bytes_per_worker=runtime.MIN_WORKER_MEMORY_BYTES, memory_reserve_bytes=0, scratch_bytes_per_worker=1, scratch_reserve_bytes=0, transfer_archive_worker_ceiling=20)
    monkeypatch.setattr(runtime, 'observe_execution_resources', lambda root: dict(effective_cpus=32, available_memory_bytes=10 ** 12, scratch_available_bytes=10 ** 12, scratch_root=str(root)))
    jobs = []
    for branch in _freq_n.AAR_ESTIMANDS[:2]:
        for imp in range(1, 21):
            name = f'O3_{branch}_M{imp:02d}'
            jobs.append({'name': name, 'entries': {'UNFITTED.txt': b'NO_MODEL_EXECUTION'}, 'numbers_path': tmp_path / 'owner/fits' / f'{name}.numbers.json', 'native_archive': row['native_members'][f'fits/{name}.zip'], 'retained_bytes_per_component': 1024 ** 2})
    if count == 39:
        jobs.pop()
    if count == 41:
        jobs.append(jobs[0])
    captured = {'records': {}, 'jobs': [], 'members': {}}
    record = {'estimability': row['estimability']}
    target = tmp_path / 'prepared'
    target.mkdir()
    if count != 40:
        with pytest.raises(ContractError):
            _freq_a._capture_a12_prepared_outer(row, jobs, record, root=target, captured=captured, resource_policy=policy)
        assert not list(target.iterdir())
    else:
        _freq_a._capture_a12_prepared_outer(row, jobs, record, root=target, captured=captured, resource_policy=policy)
        assert len(captured['jobs']) == 40 and captured['records'] == {3: record}
