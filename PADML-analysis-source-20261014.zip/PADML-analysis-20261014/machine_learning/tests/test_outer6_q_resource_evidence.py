"""Bounded synthetic operational/transport checks; no scientific leaf executes.

The fixed historical digest seam is explicitly aliased only for synthetic bytes
in the resource-reader test. Real f50 source integrity is tested separately.
Neither seam is a receipt or acceptance of historical scientific results.
"""
import copy
import os
from pathlib import Path
import shutil

import pytest

from padml import f2_kernel as kernel, f4, f4_compact, f5, runtime
from padml.bundle import (ContractError, canonical_json_bytes, read_safe_zip,
    sha256_bytes, sha256_file, strict_json_bytes, write_deterministic_zip)


F50 = "f50a5b6b2cb6e63a30a805142d578b0d415da4095044b5acc4b62a0e701f485d"
F244 = "f244153308e38c5a52fdec20f837569bef9c297b2b5b625785127cdbf1acf186"
H0 = "ac656ea659586c7127db4f6bf4082af7f5ffb00b8dfaf701b665bcff67a24554"
PREFIX = "execution-evidence/outer6-resources/"
PINS = {
    PREFIX + "producer-f50.zip": {"sha256": "a715faf3860f23a07595e4002e17ee8d6da40f892117c5987c17701ae40f2025", "size_bytes": 1022468},
    PREFIX + "H0-execution.json": {"sha256": H0, "size_bytes": 82509},
    PREFIX + "H0-resource-resolution.json": {"sha256": "e4f36d79d00081b6035c4f71d3c1cd0a670499a91cafc8476c2c060af0092baa", "size_bytes": 15022}}
REFIT_PINS = {**PINS,
    PREFIX + "producer-f244.zip": {"sha256": "a9fa4e529120643f3569dc7a695d332daa17c3b37d59686d20be6bdecea57c79", "size_bytes": 1038979},
    PREFIX + "H0-refit-execution.json": {"sha256": "ca693b43d9653c0bb35d85fee13bdc2f751a2778c50995fed93982e0bb14a356", "size_bytes": 92665},
    PREFIX + "H1-refit-execution.json": {"sha256": "ba959698baa8f772419e9fee8894760e1ceec2de8150d468080b2991856dcd05", "size_bytes": 100933},
    PREFIX + "H0-refit-resource-resolution.json": {"sha256": "2a38fdc322ddafc95a89ae602d52e0ff922e0c02f84cad47edf06a9ee5724431", "size_bytes": 232538},
    PREFIX + "H1-refit-resource-resolution.json": {"sha256": "e29b9c2793c2dc2b2c8bf1a29dcce0dca8d1aeafe7347d36d3848e81fff44d59", "size_bytes": 232436}}
INPUT = {"sha256": "3787de08eae6eb5b31c684b8406f1a92aeadea14cea832c9e1c3fb8ddf1c52ff", "size_bytes": 1856132}
ADD079 = "add079ae25498023cac1054a44c3a41444a51b0cf72dc8b5ed5ae3bc8648ac43"
S3A_PINS = {**REFIT_PINS,
    PREFIX + "producer-add079.zip": {"sha256": "51cf61f333b9fbdc614f56c2dbe07d2e45ca0cbcf79f73b94f8fa7e9e7a58d77", "size_bytes": 1042181},
    PREFIX + "H7-s3a-stop-execution.json": {"sha256": "e236b3c2b2509e0d4d567cc7495e3acdf50874ab3bed1b7eaf4549f0abe02f6f", "size_bytes": 262894},
    PREFIX + "H7-s3a-stop-resource-resolution.json": {"sha256": "84a9e11a5e0324ba7e97068806ca0aa1ec55d68d7f5d536c886eabc355469cb6", "size_bytes": 399626}}
POLICY = {"configured_worker_ceiling": runtime.CPU_MINUS_8,
    "memory_bytes_per_worker": 2 * 1024**3, "scratch_bytes_per_worker": 4 * 1024**3,
    "memory_reserve_bytes": 2947981120, "scratch_reserve_bytes": 45144861914,
    "transfer_archive_worker_ceiling": 64}


def _observation(path):
    return {"effective_cpus": 32, "available_memory_bytes": 128 * 1024**3,
        "scratch_available_bytes": 512 * 1024**3, "scratch_root": str(path)}


def _forbidden(*args, **kwargs):
    raise AssertionError("NO_SCIENTIFIC_LEAF_OR_RELEASE_IN_READER_TEST")


@pytest.mark.parametrize("producer,identity", [("f50", F50), ("f244", F244), ("add079", ADD079),
    ("cb0", "cb0f1fff3adf46cb2187c5006dd727c8994e3cc7acabd26f20976b8944c4317b")])
@pytest.mark.parametrize("damage", [None, "seed", "default", "decorator", "module", "wrong_source",
                                    "atom_geometry", "primary_projection"])
def test_f50_whole_source_proof_preserves_function_boundaries(tmp_path, monkeypatch, damage, producer, identity):
    source = Path(os.environ["PADML_OUTER6_TEST_" + producer.upper()])
    assert sha256_file(source) == ("5a02fe67703a9d0cc71a5a4b3a2575be1f0376dcf3b5ecb6fc543d3ec00d1107"
        if producer == "cb0" else S3A_PINS[PREFIX + "producer-" + producer + ".zip"]["sha256"])
    retained = f4._retained_full0_source_members(source, aar_python_q=True)
    assert sha256_bytes(canonical_json_bytes(retained)) == identity
    if damage is None:
        return
    if damage == "wrong_source":
        other = tmp_path / "different-source.zip"
        f4.compile_f45_source_bundle(other)
        with pytest.raises(ContractError):
            f4._retained_full0_source_members(other, aar_python_q=True)
        return
    original = Path(f4.__file__).resolve().parent.parent
    isolated = tmp_path / "isolated-current-source"
    for name in f4.F45_SOURCE_MEMBERS:
        target = isolated / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(original / name, target)
    path = isolated / ("padml/f2_kernel.py" if damage in {"seed", "atom_geometry"}
                       else "padml/f4.py" if damage == "primary_projection" else "padml/f5.py")
    raw = path.read_text()
    if damage == "atom_geometry":
        changed = raw.replace("def _r_prediction_task_batches(", "def _unreviewed_atom_geometry(", 1)
    elif damage == "primary_projection":
        changed = raw.replace("def _primary_complex_search_source(", "def _unreviewed_primary_projection(", 1)
    elif damage == "seed":
        # A scientific module-level binding cannot be hidden by function hashes.
        changed = raw + "\nUNFITTED_SEED_REBINDING = 1\n"
    elif damage == "default":
        changed = raw.replace("recover_gbm_losses: bool = False", "recover_gbm_losses: bool = True", 1)
    elif damage == "decorator":
        changed = raw.replace("@contextmanager\n", "@staticmethod\n", 1)
    else:
        changed = raw + "\n_q_search_batch_control = None\n"
    assert changed != raw
    path.write_text(changed)
    monkeypatch.setattr(f4, "__file__", str(isolated / "padml/f4.py"))
    with pytest.raises(ContractError):
        f4._retained_full0_source_members(source, aar_python_q=True)


def _synthetic_resource_documents(root):
    owned = root / "UNFITTED-original/H0-q/prepared-inputs"
    members = {f"UNFITTED-{index:02d}.bin": {"sha256": "a" * 64, "size_bytes": index + 1}
        for index in range(18)}
    archive = {"path": str(owned.parent.parent / "H0-input.zip"), "sha256": "b" * 64, "size_bytes": 37}
    exact = {archive["path"]: archive["size_bytes"], **{str(owned / name): pin["size_bytes"] for name, pin in members.items()}}
    def snapshot(tick):
        return {"pid": 100, "started_ns": tick, "finished_ns": tick + 1, "clock": "MONOTONIC_NS",
            "rss_bytes": 1000, "rss_source": "/proc/self/smaps_rollup:Rss", "cgroup_status": "UNKNOWN", "cgroups": []}
    release = {"owner": "H0:AUTHORIZED_RESOURCE_RESOLUTION:" + H0,
        "before": snapshot(1), "after": snapshot(3), "released_references": ["UNFITTED_CLOSED_HANDLE"],
        "gc_collected": 0, "reader_scan_status": "OBSERVED", "visible_processes_checked": 1,
        "claim": "ADVISORY_ONLY_NONATOMIC_OBSERVATIONS_NOT_ATTRIBUTION",
        "files": [{"path": name, "size_bytes": size, "device": 1, "inode": index + 1,
            "mtime_ns": 2, "ctime_ns": 3, "status": "ADVISED", "error": None}
            for index, (name, size) in enumerate(exact.items())]}
    old = copy.deepcopy(release)
    old.update(reader_scan_status="UNKNOWN", visible_processes_checked=0)
    for row in old["files"]:
        row.update(status="UNKNOWN", error="UNFITTED historical reader failure")
    execution = {"source_identity": F50, "phase": f5._a12_q_stop_phase("S1", family="COXTIME_SET_A")[0],
        "input": INPUT, "task_ids": f5._a12_q_stop_phase("S1", family="COXTIME_SET_A")[1][::6],
        "effective_policy": POLICY, "resource_policy": POLICY,
        "resource_release": {"prepared_inputs": old},
        "prepared_q_input": {"input_root": str(owned), "archive": archive, "members": members, "after_release": None}}
    observation = _observation(owned.parent.parent)
    supplement = {"source_identity": F50, "host": "H0", "historical_cause": "UNKNOWN",
        "status": "CURRENT_RESOURCE_RELEASE_AND_ORIGINAL_ADMISSION_COMPLETE", "error": None,
        "release_calls": 1, "automatic_retry": False, "original_failure_rewritten": False,
        "original_files_unchanged": True, "original_failure": PINS[PREFIX + "H0-execution.json"],
        "candidate_file_count": 19, "resource_release": release, "effective_policy": copy.deepcopy(POLICY),
        "verified_file_identities": {row["path"]: [row[key] for key in
            ("device", "inode", "size_bytes", "mtime_ns", "ctime_ns")] for row in release["files"]}}
    for name in ("new_scientific_calls", "new_model_fits", "new_stop_fits", "new_mice_chains", "new_mice_fit_calls",
        "new_elastic_paths", "new_glmnet_calls", "new_first_native_audits", "additional_native_model_replays",
        "loss_recovery_calls", "files_deleted", "tests_run"):
        supplement[name] = 0
    for when in ("pre", "post"):
        supplement[when + "_release_observation"] = observation
        supplement[when + "_release_admission"] = runtime.resource_admission(POLICY, observation, legal_tasks=1)
    return execution, supplement


@pytest.mark.parametrize("damage", [None, "old_after_release", "old_observed", "ten_task_supplement",
    "lower_reserve", "worker_budget", "wrong_source", "wrong_input", "wrong_owner", "missing_file",
    "identity", "new_fit", "first_audit", "replay", "loss", "bool_count", "byte_drift", "missing_leaf", "wrong_pin"])
def test_original_resource_reader_separates_unknown_history_and_one_task_supplement(tmp_path, monkeypatch, damage):
    root = tmp_path / "q"
    root.mkdir()
    execution, supplement = _synthetic_resource_documents(root)
    if damage == "old_after_release":
        execution["prepared_q_input"]["after_release"] = supplement["post_release_admission"]
    elif damage == "old_observed":
        execution["resource_release"]["prepared_inputs"]["reader_scan_status"] = "OBSERVED"
    elif damage == "ten_task_supplement":
        supplement["post_release_admission"] = runtime.resource_admission(POLICY, supplement["post_release_observation"], legal_tasks=10)
    elif damage in {"lower_reserve", "worker_budget"}:
        supplement["effective_policy"]["memory_reserve_bytes" if damage == "lower_reserve" else "memory_bytes_per_worker"] -= 1
    elif damage == "wrong_source":
        execution["source_identity"] = "0" * 64
    elif damage == "wrong_input":
        execution["input"] = {**INPUT, "sha256": "0" * 64}
    elif damage == "wrong_owner":
        supplement["resource_release"]["owner"] = "H1:UNFITTED"
    elif damage == "missing_file":
        supplement["resource_release"]["files"].pop()
    elif damage == "identity":
        next(iter(supplement["verified_file_identities"].values()))[1] += 1
    elif damage in {"new_fit", "first_audit", "replay", "loss", "bool_count"}:
        key = {"new_fit": "new_model_fits", "first_audit": "new_first_native_audits", "replay": "additional_native_model_replays",
            "loss": "loss_recovery_calls", "bool_count": "new_model_fits"}[damage]
        supplement[key] = False if damage == "bool_count" else 1
    aliases = {}
    def write(name, value, pin):
        path = root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        if isinstance(value, dict):
            value = {**value, "UNFITTED_PADDING": ""}
            value["UNFITTED_PADDING"] = "x" * (pin["size_bytes"] - len(canonical_json_bytes(value)))
            raw = canonical_json_bytes(value)
        else:
            raw = b"X" * pin["size_bytes"]
        assert len(raw) == pin["size_bytes"]
        path.write_bytes(raw)
        aliases[sha256_bytes(raw)] = pin["sha256"]
    write(PREFIX + "producer-f50.zip", None, PINS[PREFIX + "producer-f50.zip"])
    write(PREFIX + "H0-execution.json", execution, PINS[PREFIX + "H0-execution.json"])
    write(PREFIX + "H0-resource-resolution.json", supplement, PINS[PREFIX + "H0-resource-resolution.json"])
    write("input.json", {"UNFITTED": True}, INPUT)
    original_bytes = {name: (root / name).read_bytes() for name in [*PINS, "input.json"]}
    if damage == "byte_drift":
        path = root / (PREFIX + "producer-f50.zip")
        path.write_bytes(b"Y" + path.read_bytes()[1:])
    elif damage == "missing_leaf":
        (root / (PREFIX + "producer-f50.zip")).rename(root / "UNFITTED-preserved-source")
    monkeypatch.setattr(f5, "sha256_file", lambda path: aliases.get(sha256_file(path), sha256_file(path)))
    monkeypatch.setattr(f4, "_retained_full0_source_members", lambda *args, **kwargs: {"UNFITTED_SOURCE_SEAM": True})
    monkeypatch.setattr(runtime, "observe_execution_resources", _observation)
    monkeypatch.setattr(runtime, "release_step_resources", _forbidden)
    monkeypatch.setattr(f5, "_execute_q_search_batch", _forbidden)
    admissions = []
    original_admission = runtime.resource_admission
    def admission(policy, observed, *, legal_tasks):
        admissions.append((copy.deepcopy(policy), legal_tasks))
        return original_admission(policy, observed, legal_tasks=legal_tasks)
    monkeypatch.setattr(runtime, "resource_admission", admission)
    expected = copy.deepcopy(PINS)
    if damage == "wrong_pin":
        expected[PREFIX + "H0-execution.json"]["sha256"] = "0" * 64
    if damage is not None:
        with pytest.raises(ContractError):
            f5._q_python_resource_evidence(root, POLICY, expected=expected)
    else:
        paths, refs = f5._q_python_resource_evidence(root, POLICY, expected=expected)
        assert refs == PINS and set(paths) == set(PINS)
        assert len(admissions) == 3 and admissions[-2:] == [(POLICY, 1), (POLICY, 1)]
        assert admissions[0][0]["memory_reserve_bytes"] == POLICY["memory_reserve_bytes"] + 32 * sum(pin["size_bytes"] for pin in PINS.values())
        assert {name: (root / name).read_bytes() for name in original_bytes} == original_bytes
        assert execution["prepared_q_input"]["after_release"] is None
        assert execution["resource_release"]["prepared_inputs"]["reader_scan_status"] == "UNKNOWN"


def _synthetic_s3a_documents(root):
    execution, supplement = _synthetic_refit_documents(root, "H1", 1)
    owned = root / "UNFITTED-original/H7-outer6-s3a-stop-q/prepared-inputs"
    phase, ids = f5._a12_q_stop_phase("S3A", family="COXTIME_SET_A")
    archive = {"path": str(owned.parent.parent / "H7-inputs.zip"), "sha256": "b" * 64, "size_bytes": 37}
    members = {f"UNFITTED-{i:02d}.bin": {"sha256": "a" * 64, "size_bytes": i + 1} for i in range(49)}
    execution.update(source_identity=ADD079, phase=phase, task_ids=ids[5::7],
        new_model_fit_count=28, confirmed_first_native_audit_count=28,
        prepared_q_input={"input_root": str(owned), "archive": archive, "members": members, "after_release": None})
    originals = {archive["path"]: {key: archive[key] for key in ("sha256", "size_bytes")},
        **{str(owned / name): pin for name, pin in members.items()},
        str(owned.parent.parent / "H7-outer6-s3a-stop-batch/execution.json"): S3A_PINS[PREFIX + "H7-s3a-stop-execution.json"],
        str(owned.parent.parent / "H7-outer6-s3a-stop-first-execution.json"):
            {"sha256": "756aee94a711765d937abefb02f31ac51cbd85a06f9876a4fac25530ef2c4688", "size_bytes": 8024}}
    originals.update({str(owned.parent.parent / f"UNFITTED-H7-retained-{i:03d}.bin"):
        {"sha256": None if i < 57 else "c" * 64, "size_bytes": i + 1} for i in range(321)})
    rows = [{"path": path, "size_bytes": pin["size_bytes"], "device": 1, "inode": i + 1,
        "mtime_ns": 2, "ctime_ns": 3, "status": "ADVISED", "error": None} for i, (path, pin) in enumerate(originals.items())]
    old = execution["resource_release"]["prepared_inputs"]
    old["files"] = [{**row, "status": "UNKNOWN", "error": "RESOURCE_READER_SCAN_FAILED:PermissionError:UNFITTED"}
                    for row in rows[:50]]
    release = {**copy.deepcopy(old), "owner": "OUTER6_FIRST_S3A_STOP_PRIVATE_RETURN:H7",
        "reader_scan_status": "OBSERVED", "visible_processes_checked": 1, "files": rows}
    effective = {**POLICY, "memory_reserve_bytes": POLICY["memory_reserve_bytes"] + 32 * (48782 + 6903)}
    supplement.update(source_identity=ADD079, host="H7", original_model_fits=28, original_first_native_audits=28,
        resource_release=release, original_members=originals, effective_policy=effective,
        verified_file_identities={row["path"]: {key: row[key] for key in
            ("device", "inode", "size_bytes", "mtime_ns", "ctime_ns")} for row in rows})
    supplement["private_numerical_return"].update(status="PRIVATE_OUTER6_FIRST_S3A_STOP_NUMERICAL_INTEGRITY_CLOSED",
        host="H7", source_identity=ADD079, task_ids=ids[5::7], model_fits=28, first_native_audits=28,
        packet={"sha256": "815791d4d77cfe6c21fff3f7e258bc2da76a873bda47d80eda8393ec5f82230a", "size_bytes": 9737390})
    for prefix in ("", "post_release_"):
        supplement[prefix + "resource_observation"] = _observation(owned.parent.parent)
        supplement[prefix + "resource_admission"] = runtime.resource_admission(effective,
            supplement[prefix + "resource_observation"], legal_tasks=1)
    return execution, supplement


@pytest.mark.parametrize("damage", [None, "host", "phase", "coordinate", "old_after", "old_scan", "cause",
    "file_identity", "original_pin", "missing_file", "new_scan", "new_fit", "bool_call", "first_audit",
    "returned_exit", "returned_pin", "lower_reserve", "batch_admission", "missing_leaf", "source_drift"])
def test_s3a_h7_exact_postfit_pair_without_replaying_science(tmp_path, monkeypatch, damage):
    root = tmp_path / "q"
    root.mkdir()
    documents = {PREFIX + name: value for name, value in zip(("H0-execution.json", "H0-resource-resolution.json"),
        _synthetic_resource_documents(root), strict=True)}
    for index, host in enumerate(("H0", "H1")):
        execution, supplement = _synthetic_refit_documents(root, host, index)
        documents[PREFIX + host + "-refit-execution.json"] = execution
        documents[PREFIX + host + "-refit-resource-resolution.json"] = supplement
    execution, supplement = _synthetic_s3a_documents(root)
    documents[PREFIX + "H7-s3a-stop-execution.json"] = execution
    documents[PREFIX + "H7-s3a-stop-resource-resolution.json"] = supplement
    if damage == "host": supplement["host"] = "H0"
    elif damage == "phase": execution["phase"] = f5._a12_q_stop_phase("S2", family="COXTIME_SET_A")[0]
    elif damage == "coordinate": execution["task_ids"][0] = "UNFITTED_WRONG_COORDINATE"
    elif damage == "old_after": execution["prepared_q_input"]["after_release"] = supplement["resource_admission"]
    elif damage == "old_scan": execution["resource_release"]["prepared_inputs"]["reader_scan_status"] = "OBSERVED"
    elif damage == "cause": execution["resource_release"]["prepared_inputs"]["files"][0]["error"] = "UNFITTED_OTHER_FAILURE"
    elif damage == "file_identity": execution["resource_release"]["prepared_inputs"]["files"][0]["inode"] += 1
    elif damage == "original_pin": supplement["original_members"][execution["prepared_q_input"]["archive"]["path"]]["sha256"] = "0" * 64
    elif damage == "missing_file": supplement["resource_release"]["files"].pop()
    elif damage == "new_scan": supplement["resource_release"]["reader_scan_status"] = "UNKNOWN"
    elif damage == "new_fit": supplement["new_scientific_calls"] = 1
    elif damage == "bool_call": supplement["cache_release_calls"] = True
    elif damage == "first_audit": supplement["original_first_native_audits"] = 27
    elif damage == "returned_exit": supplement["private_numerical_return"]["original_cli_exit_code"] = 0
    elif damage == "returned_pin": supplement["private_numerical_return"]["packet"]["sha256"] = "0" * 64
    elif damage == "lower_reserve": supplement["effective_policy"]["memory_reserve_bytes"] -= 1
    elif damage == "batch_admission": supplement["post_release_resource_admission"] = runtime.resource_admission(
        supplement["effective_policy"], supplement["post_release_resource_observation"], legal_tasks=28)
    aliases = {}
    for name, pin in {**S3A_PINS, "input.json": INPUT}.items():
        value = {"UNFITTED_INPUT": True} if name == "input.json" else documents.get(name)
        if value is None:
            raw = b"X" * pin["size_bytes"]
        else:
            value = {**value, "UNFITTED_PADDING": ""}
            padding = pin["size_bytes"] - len(canonical_json_bytes(value))
            assert padding >= 0
            value["UNFITTED_PADDING"] = "x" * padding
            raw = canonical_json_bytes(value)
        assert len(raw) == pin["size_bytes"]
        path = root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(raw)
        aliases[sha256_bytes(raw)] = pin["sha256"]
    if damage == "missing_leaf": (root / (PREFIX + "H7-s3a-stop-resource-resolution.json")).rename(root / "UNFITTED-preserved")
    elif damage == "source_drift":
        p = root / (PREFIX + "producer-add079.zip")
        p.write_bytes(b"Y" + p.read_bytes()[1:])
    monkeypatch.setattr(f5, "sha256_file", lambda path: aliases.get(sha256_file(path), sha256_file(path)))
    monkeypatch.setattr(f4, "_retained_full0_source_members", lambda *args, **kwargs: {"UNFITTED_SOURCE_SEAM": True})
    monkeypatch.setattr(runtime, "observe_execution_resources", _observation)
    monkeypatch.setattr(runtime, "release_step_resources", _forbidden)
    monkeypatch.setattr(f5, "_execute_q_search_batch", _forbidden)
    if damage is not None:
        with pytest.raises(ContractError): f5._q_python_resource_evidence(root, POLICY, expected=S3A_PINS)
    else:
        before = {name: (root / name).read_bytes() for name in S3A_PINS}
        paths, refs = f5._q_python_resource_evidence(root, POLICY, expected=S3A_PINS)
        assert refs == S3A_PINS and set(paths) == set(S3A_PINS)
        assert {name: (root / name).read_bytes() for name in S3A_PINS} == before
        assert execution["prepared_q_input"]["after_release"] is None


def _synthetic_refit_documents(root, host, index):
    # Original model/input paths are metadata only. No model exists or is read.
    execution, _ = _synthetic_resource_documents(root)
    owned = root / "UNFITTED-original" / (host + "-outer6-s1-refit-q") / "prepared-inputs"
    archive = {"path": str(owned.parent.parent / (host + "-inputs.zip")), "sha256": "b" * 64, "size_bytes": 37}
    members = {f"UNFITTED-{i:02d}.bin": {"sha256": "a" * 64, "size_bytes": i + 1} for i in range(16)}
    phase, ids = f5._a12_q_stop_phase("S1", refit=True, family="COXTIME_SET_A")
    execution.update(source_identity=F244, phase=phase, task_ids=ids[index::7],
        new_model_fit_count=9, confirmed_first_native_audit_count=9,
        prepared_q_input={"input_root": str(owned), "archive": archive, "members": members, "after_release": None})
    original = {archive["path"]: {key: archive[key] for key in ("sha256", "size_bytes")},
        **{str(owned / name): pin for name, pin in members.items()}}
    originals = {**original,
        str(owned.parent.parent / (host + "-outer6-s1-refit-batch/execution.json")): REFIT_PINS[PREFIX + host + "-refit-execution.json"],
        str(owned.parent.parent / (host + "-outer6-s1-refit-first-execution.json")): (
            {"sha256": "797421663e69ea2c8230b9228fd606b314de1b419065291f6b5bf6326e95a17b", "size_bytes": 6410} if host == "H0" else
            {"sha256": "2242f2e05f23f668d3acfaaa17865d21b433d551642ed0d0e952a030e28d3ff7", "size_bytes": 6411})}
    originals.update({str(owned.parent.parent / f"UNFITTED-{host}-retained-{i:03d}.bin"):
        {"sha256": None if i < 82 else "c" * 64, "size_bytes": i + 1} for i in range(202)})
    rows = [{"path": path, "size_bytes": pin["size_bytes"], "device": 1, "inode": i + 1,
        "mtime_ns": 2, "ctime_ns": 3, "status": "ADVISED", "error": None} for i, (path, pin) in enumerate(originals.items())]
    old = execution["resource_release"]["prepared_inputs"]
    old["files"] = [{**row, "status": "UNKNOWN", "error": "UNFITTED reader failure"} for row in rows[:17]]
    release = {**copy.deepcopy(old), "owner": "OUTER6_FIRST_REFIT_PRIVATE_RETURN:" + host,
        "reader_scan_status": "OBSERVED", "visible_processes_checked": 1, "files": rows}
    effective = {**POLICY, "memory_reserve_bytes": POLICY["memory_reserve_bytes"] + 32 * ((22080 + 22059) if host == "H0" else (22081 + 22022))}
    observation = _observation(owned.parent.parent)
    supplement = {"source_identity": F244, "host": host, "status": "COMPLETED_RESOURCE_RELEASE_OBSERVED",
        "post_release_error": None, "cache_release_calls": 1, "automatic_retry": False, "scientific_acceptance": False,
        "original_input_release_failure_preserved": True, "original_prepared_input_after_release_missing": True,
        "original_model_fits": 9, "original_first_native_audits": 9, "new_scientific_calls": 0,
        "files_deleted": 0, "restoration_budget_used": 0, "resource_release": release,
        "original_members": originals, "verified_file_identities": {row["path"]: {key: row[key] for key in
            ("device", "inode", "size_bytes", "mtime_ns", "ctime_ns")} for row in rows}, "effective_policy": effective,
        "private_numerical_return": {"status": "PRIVATE_OUTER6_FIRST_REFIT_NUMERICAL_INTEGRITY_CLOSED",
            "host": host, "source_identity": F244, "task_ids": ids[index::7], "model_fits": 9,
            "first_native_audits": 9, "original_cli_exit_code": 1, "postfit_input_release_failure_preserved": True,
            "mac_scientific_calls": 0, "scientific_acceptance": False, "packet": (
                {"sha256": "11de0c90522105936f19d43296d6c65524b7306f4eeebcdbc86118cec111ca8b", "size_bytes": 5058564} if host == "H0" else
                {"sha256": "1954adc70c127ccef372f918a4724cdc6b3ac7ff696d9761794a40924117cb59", "size_bytes": 5060627})}}
    for prefix in ("", "post_release_"):
        supplement[prefix + "resource_observation"] = observation
        supplement[prefix + "resource_admission"] = runtime.resource_admission(effective, observation, legal_tasks=1)
    return execution, supplement


@pytest.mark.parametrize("damage", [None, "host", "task_ids", "phase", "input", "old_after", "old_scan",
    "old_identity", "original_pin", "missing_file", "new_scan", "new_fit", "bool_call", "first_audit",
    "restoration", "returned_pin", "returned_exit", "nine_task_supplement", "lower_reserve", "missing_leaf"])
def test_exact_refit_resource_pair_preserves_seventeen_old_and_221_returned_files(tmp_path, monkeypatch, damage):
    root = tmp_path / "q"
    root.mkdir()
    documents = {PREFIX + name: value for name, value in zip(("H0-execution.json", "H0-resource-resolution.json"),
        _synthetic_resource_documents(root), strict=True)}
    for index, host in enumerate(("H0", "H1")):
        execution, supplement = _synthetic_refit_documents(root, host, index)
        documents[PREFIX + host + "-refit-execution.json"] = execution
        documents[PREFIX + host + "-refit-resource-resolution.json"] = supplement
    execution = documents[PREFIX + "H1-refit-execution.json"]
    supplement = documents[PREFIX + "H1-refit-resource-resolution.json"]
    if damage == "host":
        supplement["host"] = "H5"
    elif damage == "task_ids":
        execution["task_ids"] = f5._a12_q_stop_phase("S1", refit=True, family="COXTIME_SET_A")[1][0::7]
    elif damage == "phase":
        execution["phase"] = f5._a12_q_stop_phase("S2", family="COXTIME_SET_A")[0]
    elif damage == "input":
        execution["input"] = {**INPUT, "sha256": "0" * 64}
    elif damage == "old_after":
        execution["prepared_q_input"]["after_release"] = supplement["resource_admission"]
    elif damage == "old_scan":
        execution["resource_release"]["prepared_inputs"]["reader_scan_status"] = "OBSERVED"
    elif damage == "old_identity":
        execution["resource_release"]["prepared_inputs"]["files"][0]["inode"] += 1
    elif damage == "original_pin":
        supplement["original_members"][execution["prepared_q_input"]["archive"]["path"]]["sha256"] = "0" * 64
    elif damage == "missing_file":
        supplement["resource_release"]["files"].pop()
    elif damage == "new_scan":
        supplement["resource_release"]["reader_scan_status"] = "UNKNOWN"
    elif damage in {"new_fit", "bool_call", "first_audit", "restoration"}:
        key = {"new_fit": "new_scientific_calls", "bool_call": "cache_release_calls",
            "first_audit": "original_first_native_audits", "restoration": "restoration_budget_used"}[damage]
        supplement[key] = True if damage == "bool_call" else 1
    elif damage == "returned_pin":
        supplement["private_numerical_return"]["packet"]["sha256"] = "0" * 64
    elif damage == "returned_exit":
        supplement["private_numerical_return"]["original_cli_exit_code"] = 0
    elif damage == "nine_task_supplement":
        supplement["post_release_resource_admission"] = runtime.resource_admission(supplement["effective_policy"],
            supplement["post_release_resource_observation"], legal_tasks=9)
    elif damage == "lower_reserve":
        supplement["effective_policy"]["memory_reserve_bytes"] -= 1
    aliases = {}
    for name, pin in {**REFIT_PINS, "input.json": INPUT}.items():
        value = documents.get(name)
        if name == "input.json":
            value = {"UNFITTED_INPUT": True}
        if value is None:
            raw = b"X" * pin["size_bytes"]
        else:
            value = {**value, "UNFITTED_PADDING": ""}
            padding = pin["size_bytes"] - len(canonical_json_bytes(value))
            assert padding >= 0
            value["UNFITTED_PADDING"] = "x" * padding
            raw = canonical_json_bytes(value)
        assert len(raw) == pin["size_bytes"]
        path = root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(raw)
        aliases[sha256_bytes(raw)] = pin["sha256"]
    if damage == "missing_leaf":
        (root / (PREFIX + "H1-refit-resource-resolution.json")).rename(root / "UNFITTED-preserved-report")
    monkeypatch.setattr(f5, "sha256_file", lambda path: aliases.get(sha256_file(path), sha256_file(path)))
    monkeypatch.setattr(f4, "_retained_full0_source_members", lambda *args, **kwargs: {"UNFITTED_SOURCE_SEAM": True})
    monkeypatch.setattr(runtime, "observe_execution_resources", _observation)
    monkeypatch.setattr(runtime, "release_step_resources", _forbidden)
    monkeypatch.setattr(f5, "_execute_q_search_batch", _forbidden)
    if damage is not None:
        with pytest.raises(ContractError):
            f5._q_python_resource_evidence(root, POLICY, expected=REFIT_PINS)
    else:
        before = {name: (root / name).read_bytes() for name in REFIT_PINS}
        paths, refs = f5._q_python_resource_evidence(root, POLICY, expected=REFIT_PINS)
        assert refs == REFIT_PINS and set(paths) == set(REFIT_PINS)
        assert {name: (root / name).read_bytes() for name in REFIT_PINS} == before
        assert execution["prepared_q_input"]["after_release"] is None
        assert sum(pin["sha256"] is None for pin in supplement["original_members"].values()) == 82


@pytest.mark.parametrize("stage,refit", [("S1", True), ("S2", False), ("S3A", True)])
@pytest.mark.parametrize("damage", [None, "missing_predecessor", "wrong_count", "missing_member", "changed_input"])
def test_original_refit_publisher_and_worker_keep_three_operational_leaves(
        tmp_path, monkeypatch, damage, stage, refit, *, family="COXTIME_SET_A", direct=False):
    root = tmp_path / "original-q"
    (root / "native").mkdir(parents=True)
    primary = tmp_path / "UNFITTED-primary.zip"
    primary.write_bytes(b"UNFITTED_SOURCE_BOUNDARY")
    fold = 1 if direct else 2 if family == "XGBOOST_COX" else 6
    branch = "A12_WITHOUT_AST_ALT_DIRECT" if direct else "OUTER_SELECTED_FAMILY_NO_AAR_REDEVELOPMENT"
    primary_key = "retained_primary_source_bundle" if direct else "retained_a12_primary_context_source_bundle"
    spec = {"family": family, "execution_scope": "F5_A12_SEARCH", "fold": fold,
        "selection_horizon_months": 24, "seed": 306000, "engine_threads": 1,
        primary_key: str(primary),
        "a12_source": {"family": family, "outer_fold": fold,
            "branch": branch}}
    raw = canonical_json_bytes({"kind": "PADML_F5_A12_Q_INPUT_V1", "spec": spec, "UNFITTED": True})
    (root / "input.json").write_bytes(raw)
    input_ref = {"sha256": sha256_bytes(raw), "size_bytes": len(raw)}
    paths, refs = {}, {}
    batch_rows = [{"UNFITTED_PREDECESSOR": index, "resource_policy": POLICY}
                  for index in range(34 if stage == "S3A" else 6 if refit else 13)]
    paired = {PREFIX + "H0-execution.json": batch_rows[0]}
    if not refit or stage == "S3A":
        paired.update({PREFIX + "H0-refit-execution.json": batch_rows[6], PREFIX + "H1-refit-execution.json": batch_rows[7]})
    if stage == "S3A":
        paired[PREFIX + "H7-s3a-stop-execution.json"] = batch_rows[-1]
    evidence_names = (set() if direct else {"execution-evidence/outer2-resources/producer-f50.zip"} if family == "XGBOOST_COX"
                      else S3A_PINS if stage == "S3A" else PINS if refit else REFIT_PINS)
    for name in evidence_names:
        path = root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(canonical_json_bytes(paired[name]) if name in paired else ("UNFITTED_OPERATIONAL:" + name).encode())
        paths[name], refs[name] = path, {"sha256": sha256_file(path), "size_bytes": path.stat().st_size}
    seen = []
    def resource_reader(directory, policy, *, expected=None, sources=None):
        assert expected == refs and policy == POLICY and sources is None
        assert (directory / "input.json").read_bytes() == raw
        assert {name: {"sha256": sha256_file(directory / name), "size_bytes": (directory / name).stat().st_size} for name in refs} == refs
        seen.append(directory)
        return {name: directory / name for name in refs}, refs
    monkeypatch.setattr(f5, "_q_python_resource_evidence", resource_reader)
    monkeypatch.setattr(f4, "_retained_full0_source_members", lambda *args, **kwargs: {"UNFITTED_PRIMARY": True})
    monkeypatch.setattr(runtime, "observe_execution_resources", _observation)
    phase, ids = f5._a12_q_stop_phase(stage, refit=refit, family=family)
    refitter = kernel._run_xgb_refit_pool_task if family == "XGBOOST_COX" else kernel._run_coxtime_refit_pool_task
    function = refitter if refit else kernel._run_python_stop_pair_pool_task
    partitions = {}
    for index in range(1, 6):
        directory = tmp_path / f"UNFITTED_INNER_{index}"
        directory.mkdir()
        data = b"UNFITTED_COVARIATES\n"
        for imp in range(1, 21):
            (directory / f"imp{imp:02d}.csv").write_bytes(data)
        response = directory / "fit.csv"
        response.write_bytes(b"UNFITTED_RESPONSE\n")
        partitions[index] = {"partition_id": f"{'INNER' if refit else 'STOP'}_{index:02d}", "kind": "INNER" if refit else "STOP",
            "covariates": {"input_dir": str(directory), "members": [{"name": f"imp{imp:02d}.csv",
                "sha256": sha256_bytes(data), "size_bytes": len(data)} for imp in range(1, 21)]},
            "fit_response": {"path": str(response), "sha256": sha256_file(response), "size_bytes": response.stat().st_size}}
    tasks = []
    for name in ids:
        part = int(name.split("_P")[1][:2])
        identifier = partitions[part]["partition_id"]
        task = {"spec": spec, "task_id": name, "partition_id": identifier, "imputation": int(name.split("_M")[1][:2]),
                "locked_rounds" if family == "XGBOOST_COX" else "locked_epoch": 7, "seed": 306001,
                "registered": {"diagnostic_partitions": [], "projected_partition_count": 1,
                    "projected_partition_ids": [identifier], "partitions": [partitions[part]]}}
        if not refit:
            task["handoff_path"] = str(tmp_path / ("UNFITTED-" + name + ".json"))
        evaluation = {**copy.deepcopy(partitions[part]), "evaluation_response": copy.deepcopy(partitions[part]["fit_response"])}
        tasks.append(task if refit else (task, evaluation))
    units = f5._q_search_units(function, tasks)
    counts = f5._a12_q_prepared_predecessors(stage, refit=refit, family=family)
    control = {"q_unit_outputs": [[str(tmp_path / f"part-{index}.zip"), *ids[index::3]] for index in range(3)],
        "task_ids": None, "resource_policy": POLICY, "retained_bytes_per_task": 32 * 1024**2,
        "confirmed_model_fits": counts["total"], "confirmed_stop_fits": counts["stop"], "completed": False,
        "batches": [(root, row) for row in batch_rows], "q_resource_evidence": refs,
        "used_batches": [f5.sha256_bytes(canonical_json_bytes(row)) for row in batch_rows], "references": dict(refs)}
    if damage == "missing_predecessor":
        control["used_batches"].pop()
    elif damage == "wrong_count":
        control["confirmed_stop_fits"] = 59
    if damage in {"missing_predecessor", "wrong_count"}:
        with pytest.raises(ContractError):
            f5._publish_a12_q_stop_inputs(function, units, root, control, phase, input_ref)
        assert not list(tmp_path.glob("part-*.zip"))
        return
    f5._publish_a12_q_stop_inputs(function, units, root, control, phase, input_ref)
    inputs = strict_json_bytes((root / "prepared-unit-inputs.json").read_bytes())
    assert sum(len(row["task_ids"]) for row in inputs["outputs"]) == len(ids)
    started = []
    def boundary(function, actual_units, directory, actual_control, actual_phase, pin, **kwargs):
        assert function is (refitter if refit else kernel._run_python_stop_pair_pool_task) and actual_phase == phase and pin == input_ref
        assert actual_control["execution_worker_memory_bytes"] == 2 * 1024**3
        assert set(refs) <= set(actual_control["prepared_q_input"]["members"])
        originals = [unit[0] if refit else unit[0][0] for unit in actual_units.values()]
        if direct:
            assert all("retained_primary_source_bundle" in task["spec"]
                       and "retained_a12_primary_context_source_bundle" not in task["spec"]
                       and "a12_executor_source_identity" not in task["spec"] for task in originals)
        assert all(task["locked_rounds" if family == "XGBOOST_COX" else "locked_epoch"] == 7
                   and task["seed"] == 306001 for task in originals)
        started.extend(actual_units)
        raise f5._QBatchBoundary({"UNFITTED_ORIGINAL_EXECUTOR_BOUNDARY": True})
    monkeypatch.setattr(f5, "_execute_q_search_batch", boundary)
    for index, row in enumerate(inputs["outputs"]):
        source = Path(row["path"])
        entries = read_safe_zip(source, max_member_bytes=16 * 1024**2, max_total_bytes=64 * 1024**2)
        record = strict_json_bytes(entries["prepared-q.json"])
        assert record.get("predecessor_resource_evidence", {}) == refs
        assert record["predecessor_fit_counts"] == counts
        assert all(len(pins) == (4 if refit else 5) for pins in record["units"].values())
        if damage is not None:
            if damage == "missing_member":
                entries.pop(next(iter(refs)))
            else:
                entries["input.json"] += b" "
            source = tmp_path / "UNFITTED-damaged.zip"
            write_deterministic_zip(source, entries)
            with pytest.raises(ContractError):
                f5._execute_a12_prepared_q_batch(source, tmp_path / "worker-damaged", expected_sha256=sha256_file(source),
                    task_ids=row["task_ids"], batch_root=tmp_path / "batch-damaged", retained_bytes_per_task=32 * 1024**2)
            assert not started
            return
        if direct:
            from padml import f5_sensitivity as sensitivity
            with pytest.raises(ContractError):
                sensitivity.execute_a12_outer_bundle(source, tmp_path / "wrong-branch-worker",
                    search_only=True, search_branch="OUTER_SELECTED_FAMILY_NO_AAR_REDEVELOPMENT",
                    prepared_q_input_sha256=sha256_file(source), task_ids=row["task_ids"],
                    batch_root=tmp_path / "wrong-branch-batch", retained_bytes_per_task=32 * 1024**2)
            assert not (tmp_path / "wrong-branch-worker").exists()
            result = sensitivity.execute_a12_outer_bundle(source, tmp_path / f"worker-{index}",
                search_only=True, search_branch=branch, prepared_q_input_sha256=sha256_file(source),
                task_ids=row["task_ids"], batch_root=tmp_path / f"batch-{index}", retained_bytes_per_task=32 * 1024**2)
        else:
            result = f5._execute_a12_prepared_q_batch(source, tmp_path / f"worker-{index}", expected_sha256=sha256_file(source),
                task_ids=row["task_ids"], batch_root=tmp_path / f"batch-{index}", retained_bytes_per_task=32 * 1024**2)
        assert result == {"UNFITTED_ORIGINAL_EXECUTOR_BOUNDARY": True}
    assert len(started) == len(set(started)) == len(ids) and set(started) == set(ids)
    result = {"total_search_fit_count": counts["total"], "response_free_stopping_fit_count": counts["stop"], "UNFITTED": True}
    f5._q_search_batch_completion(root, control, result)
    (root / "result.json").write_bytes(canonical_json_bytes(result))
    complete = f5._q_search_batch_control(root, POLICY, None)
    assert complete.get("q_resource_evidence", {}) == refs and complete["batches"][0][1] == batch_rows[0]
    # Compact still requires native references. This explicit unfitted byte
    # marker exercises only that transport, never a fitted/numerical consumer.
    native = root / "native/UNFITTED_REFERENCE"
    native.mkdir()
    (native / "model.bin").write_bytes(b"UNFITTED_NATIVE_REFERENCE_ONLY")
    (native / "numbers.json").write_bytes(b'{"UNFITTED":true}')
    members, _ = f4_compact._full_pipeline_q_numerical_members(root, publish=True)
    assert set(refs) <= set(members)
    reopened, _ = f4_compact._full_pipeline_q_numerical_members(root)
    assert set(reopened) == set(members)
    assert all((root / name).read_bytes() == paths[name].read_bytes() for name in refs)
