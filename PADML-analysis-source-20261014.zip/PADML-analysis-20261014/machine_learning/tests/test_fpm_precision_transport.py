"""Exercise the actual R writer without loading or fitting a scientific model."""
import json
import math
import os
from pathlib import Path
import shutil
import subprocess

import pytest

from padml import f2_kernel as native
from padml.bundle import ContractError, read_safe_zip, strict_json_bytes


R_WRITER = r'''
suppressPackageStartupMessages(library(jsonlite))
args <- commandArgs(trailingOnly=TRUE)
expressions <- as.list(parse(file=args[[1L]]))
definition <- function(name) {
  found <- Filter(function(x) is.call(x) && identical(x[[1L]],as.name("<-")) &&
                    identical(x[[2L]],as.name(name)), expressions)
  stopifnot(length(found)==1L)
  found[[1L]]
}
env <- new.env(parent=globalenv())
eval(definition("canonical_json"),env)
writer <- tail(as.list(definition("run_registered_prediction_batch")[[3L]][[3L]]),1L)[[1L]]
stopifnot(identical(writer[[1L]],as.name("writeLines")))
env$family <- args[[2L]]
env$output_path <- tempfile()
env$result <- if (length(args)==3L) readRDS(args[[3L]]) else fromJSON(file("stdin"),simplifyVector=FALSE)
eval(writer,env)
cat(readLines(env$output_path,warn=FALSE),sep="\n")
unlink(env$output_path)
'''


def encode(family, value=None, rds=None):
    rscript = shutil.which("Rscript")
    if rscript is None:
        pytest.skip("Rscript/jsonlite required for the native zero-fit writer test")
    source = Path(native.__file__).parent / "kernels/f2_model_development.R"
    args = [rscript,"-e",R_WRITER,str(source),family]
    if rds is not None:
        args.append(str(rds))
    result = subprocess.run(args,input=json.dumps(value),capture_output=True,text=True,timeout=30)
    assert result.returncode == 0, result.stderr
    return result.stdout.rstrip("\n")


def test_fpm_binary64_roundtrip():
    value = {"values":[math.pi,math.nextafter(1.0,math.inf),
                       math.nextafter(-10.0,-math.inf),1.2345678901234567e-14],
             "status":"ARITHMETIC_FIXTURE_ONLY","flag":True,"count":3}
    assert json.loads(encode("FPM_TVC_SET_A",value)) == value


def test_other_r_families_keep_the_existing_encoding():
    value = {"value":math.pi,"values":[1.2345678901234567,3.0]}
    outputs = [encode(family,value) for family in ("ELASTIC_NET_COX","COX_PH","RSF","GBM_COX")]
    assert len(set(outputs)) == 1
    assert outputs[0] == '{"value":3.14159265358979,"values":[1.23456789012346,3]}'


def test_actual_fixed_rds_uses_exact_proven_precision(tmp_path):
    path = os.environ.get("PADML_TEST_FPM_PRECISION_ARCHIVE")
    if not path:
        pytest.skip("Set PADML_TEST_FPM_PRECISION_ARCHIVE to the immutable fixed result")
    entries = read_safe_zip(Path(path))
    rds = tmp_path / "native-result.rds"
    rds.write_bytes(entries["native-result.rds"])
    assert encode("FPM_TVC_SET_A",rds=rds) == entries["output.json"].decode().rstrip("\n")
    spec = strict_json_bytes(entries["spec.json"])
    native._validate_retained_fpm_health(strict_json_bytes(entries["output.json"])["tasks"][0],spec)
    for name in ("original-output.json","legacy-output.json"):
        with pytest.raises(ContractError,match="CONSTRAINED_OPTIMALITY_INVALID"):
            native._validate_retained_fpm_health(strict_json_bytes(entries[name])["tasks"][0],spec)
