"""Original-stage orchestration only; scientific family readers are isolated."""
import sys
from contextlib import contextmanager

import pytest

from padml import f5, nested_loco as nested, runtime
from padml.bundle import ContractError, canonical_json_bytes
from padml import f2_kernel, f4
from test_full0_fixed12_rescore import decision, forbidden
from test_full0_cox_retained_inputs import pair, reader
from test_full0_cox_retained_source import coxtwo  # noqa: F401
from test_nested_score_replay import build_fixture


def test_public_seven_consumer_forwards_both_retained_sources_once(tmp_path, monkeypatch):
    decision_value = decision()
    lineage = {"plan": {}, "score_root": str(tmp_path / "score"),
        "selector_root": str(tmp_path / "selector"), "search_roots": {}, "rscript": "FORBIDDEN",
        "resource_policy": {}, "retained_bytes_per_component": 1,
        "expanded_bytes_per_component": 1, "shared_storage_bytes": 1,
        "science_decision": decision_value}
    calls = []
    monkeypatch.setattr(f5, "_read_final_lineage", lambda *a, **k: lineage)
    @contextmanager
    def materialized(source, parent, **scope):
        assert scope == {"retained_full0_source_bundle": tmp_path / "primary.zip",
            "selection_horizon_months": 12, "retained_mice_plan": {}}
        yield lineage, [], {}
    def consume(*args, **kwargs):
        calls.append((args, kwargs))
        return {"ZERO_FIT_CONSUME": True}
    monkeypatch.setattr(f5, "_materialized_full_data_development_sources", materialized)
    monkeypatch.setattr(f5, "_full_data_locked_score_program", consume)
    result = f5.execute_full_data_locked_scores(tmp_path / "lineage.json", resume=True,
        selection_horizon_months=12, retained_full0_source_bundle=tmp_path / "primary.zip",
        retained_q_archive=tmp_path / "q.zip", retained_q_producer_source_bundle=tmp_path / "q-source.zip",
        retained_score_root=tmp_path / "old", retained_score_producer_source_bundle=tmp_path / "old-source.zip",
        prepared_score_source_bundle=tmp_path / "current-source.zip", prepared_score_root=tmp_path / "score.all")
    assert result == {"ZERO_FIT_CONSUME": True} and len(calls) == 1
    _, kwargs = calls[0]
    assert kwargs["resume"] is True and kwargs["replay"] is False
    assert kwargs["retained_score_root"] == tmp_path / "old"
    assert kwargs["retained_score_producer_source_bundle"] == tmp_path / "old-source.zip"
    assert kwargs["prepared_score_source_bundle"] == tmp_path / "current-source.zip"


@pytest.mark.parametrize("change", [{"prepared_score_root": None}, {"retained_score_root": None},
    {"prepared_score_source_bundle": None}, {"retained_q_archive": None}, {"resume": False},
    {"replay": True}, {"family": "COX_PH"}])
def test_public_seven_consumer_rejects_incomplete_source_tuple_before_io(tmp_path, monkeypatch, change):
    monkeypatch.setattr(f5, "_materialized_full_data_development_sources",
        lambda *a, **k: pytest.fail("unexpected materialization"))
    options = dict(resume=True, selection_horizon_months=12,
        retained_full0_source_bundle=tmp_path / "primary.zip", retained_q_archive=tmp_path / "q.zip",
        retained_q_producer_source_bundle=tmp_path / "q-source.zip", retained_score_root=tmp_path / "old",
        retained_score_producer_source_bundle=tmp_path / "old-source.zip",
        prepared_score_source_bundle=tmp_path / "current-source.zip", prepared_score_root=tmp_path / "score.all")
    with pytest.raises(ContractError):
        f5.execute_full_data_locked_scores(tmp_path / "lineage.json", **{**options, **change})


def test_cli_forwards_complete_seven_consumer_tuple(tmp_path, monkeypatch, capsys):
    calls = []
    monkeypatch.setattr(f5, "execute_full_data_locked_scores", lambda source, **kwargs:
        calls.append((source, kwargs)) or {"ZERO_FIT_CONSUME": True})
    monkeypatch.setattr(sys, "argv", ["padml-f5", "full-score", str(tmp_path / "lineage.json"),
        "--resume", "--selection-horizon-months", "12",
        "--retained-full0-source-bundle", str(tmp_path / "primary.zip"),
        "--retained-q-archive", str(tmp_path / "q.zip"),
        "--retained-q-producer-source-bundle", str(tmp_path / "q-source.zip"),
        "--retained-score-root", str(tmp_path / "old"),
        "--retained-score-producer-source-bundle", str(tmp_path / "old-source.zip"),
        "--prepared-score-source-bundle", str(tmp_path / "current-source.zip"),
        "--prepared-score-root", str(tmp_path / "score.all")])
    f5.main()
    assert calls == [(tmp_path / "lineage.json", {
        "replay": False, "resume": True, "selection_horizon_months": 12,
        "retained_full0_source_bundle": tmp_path / "primary.zip",
        "retained_q_archive": tmp_path / "q.zip",
        "retained_q_producer_source_bundle": tmp_path / "q-source.zip",
        "retained_score_root": tmp_path / "old",
        "retained_score_producer_source_bundle": tmp_path / "old-source.zip",
        "prepared_score_source_bundle": tmp_path / "current-source.zip",
        "prepared_score_root": tmp_path / "score.all"})]
    assert "ZERO_FIT_CONSUME" in capsys.readouterr().out


def test_seven_consumer_reopens_cox_through_its_retained_request(
        tmp_path, monkeypatch, coxtwo):
    old_members = f4._retained_full0_source_members(coxtwo[0], full0_cox_score_reuse=True)
    current_bundle = tmp_path / "current.zip"
    f4.compile_f45_source_bundle(current_bundle)
    current_members = f4._f45_source_member_sha256()
    keys = {*f5._final_search_sources(), *("padml/" + name for name in (
        "nested_loco.py", "runtime.py", "f2_validation.py", "kernels/f5_final_refit.R",
        "kernels/f5_design.R", "kernels/f4_learning_selector.R", "kernels/f4_learning_recipe.R"))}
    old_program = nested._sha({key: old_members[key] for key in keys})
    current_program = nested._sha({key: current_members[key] for key in keys})
    old, request, request_root, jobs, handles, _ = pair(tmp_path, old_program=old_program, new_program=current_program)
    request["component_records"] = [{**row, "family": family,
        "path": row["path"].replace("COX_PH", family)}
        for family in nested._families() for row in request["component_records"]]
    request = nested._sealed({key: value for key, value in request.items() if key != "identity_sha256"})
    root = tmp_path / "score.all"
    request_root.parent.rename(root)
    (tmp_path / "old/request/full-score-input.COX_PH.json").write_bytes(canonical_json_bytes(old))
    (root / "request/full-score-input.json").write_bytes(canonical_json_bytes(request))
    monkeypatch.setattr(f2_kernel, "_expected_family_parent_column_map", lambda *a, **k: [{"columns": ["AST_ALT", "Age"]}])
    monkeypatch.setattr(f2_kernel, "predictor_contract", lambda *a, **k: {})
    monkeypatch.setattr(f5, "_validate_final_r_fit_health", lambda *a, **k: None)
    monkeypatch.setattr(f5, "_validate_retained_r_audit_numbers", lambda *a, **k: None)
    outputs = reader(old, request, root / "request", jobs, handles)
    cox_score, cox_execution = nested._score_fresh_family(
        family="COX_PH", request=request, root=root, outputs=outputs, retained_request=old)
    for record in cox_execution["component_evidence_records"]:
        source = root / "score-evidence/COX_PH" / record["path"].split("/")[-1]
        target = root / record["path"]
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(source.read_bytes())
    (root / "score-evidence/COX_PH/training-score.json").write_bytes(canonical_json_bytes(cox_score))
    (root / "score-evidence/COX_PH/execution.json").write_bytes(canonical_json_bytes(cox_execution))
    for family in nested._families()[1:]:
        directory = root / "score-evidence" / family
        directory.mkdir(parents=True)
        (directory / "training-score.json").write_bytes(canonical_json_bytes({"family": family}))
        (directory / "execution.json").write_bytes(canonical_json_bytes({"family": family,
            "component_evidence_records": []}))
        for repeat in range(1, 4):
            for inner in range(1, 6):
                path = root / f"score-context/{family}/R{repeat}_K{inner}/imp01.csv"
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(b"UNFITTED")
    calls = []
    original_recompute = nested._recompute_fresh_score_from_evidence
    def recompute(**kwargs):
        calls.append(kwargs)
        if kwargs["execution"]["family"] == "COX_PH":
            return original_recompute(**kwargs)
        return kwargs["score"]
    monkeypatch.setattr(f5, "_compile_full_score_inputs", lambda *a, **k: request)
    monkeypatch.setattr(nested, "_recompute_fresh_score_from_evidence", recompute)
    monkeypatch.setattr(nested, "validate_fresh_score_execution", lambda value: value)
    monkeypatch.setattr(nested, "select_training_family", lambda scores: {"UNFITTED_SELECTION": True})
    monkeypatch.setattr(f5, "_full_score_storage_usage", lambda *a, **k: {})
    monkeypatch.setattr(f5, "_full_score_resource_admission", lambda *a, **k: (
        {"admitted_worker_ceiling": 1, "limits": {"configured": 24}}, {"retained_result_json_bytes": 10**7}))
    monkeypatch.setattr(f5, "_full_score_job_inputs", lambda *a, **k: None)
    monkeypatch.setattr(f5, "_score_archive_expanded_limit", lambda *a, **k: None)
    monkeypatch.setattr(f5, "_execute_and_verify_score_archive_job", forbidden)
    monkeypatch.setattr(f5, "_replay_component_job", forbidden)
    monkeypatch.setattr(runtime, "_bounded_ordered_spawn", forbidden)
    result = f5._full_data_locked_score_program({}, [], {}, tmp_path / "selector", {}, root,
        rscript="FORBIDDEN", replay=False, resume=True, selection_horizon_months=12,
        science_decision=request["science_decision"], resource_policy={"scratch_reserve_bytes": 0},
        retained_bytes_per_component=10**6, expanded_bytes_per_component=10**6, shared_storage_bytes=10**7,
        retained_full0_source_bundle=tmp_path / "primary.zip", retained_q_archive=tmp_path / "q.zip",
        retained_q_producer_source_bundle=tmp_path / "q-source.zip", retained_score_root=tmp_path / "old",
        retained_score_producer_source_bundle=coxtwo[0], prepared_score_source_bundle=current_bundle)
    cox_call = next(call for call in calls if call["execution"]["family"] == "COX_PH")
    assert cox_call["retained_request"] == old
    assert cox_call["retained_request_root"] == tmp_path / "old/request"
    assert result["new_model_fits"] == result["new_model_native_verification_count"] == result["native_model_replay_count"] == 0
    assert result["score_numerical_component_count"] == 2100


def test_seven_consumer_rejects_reused_cox_without_old_source_pair(tmp_path, monkeypatch):
    root = tmp_path / "score.all"
    request, inputs, _, _ = build_fixture(root, full_score=True, science_decision=decision())
    request["component_records"] = [{**row, "family": family,
        "path": row["path"].replace("FPM_TVC_SET_A", family)}
        for family in nested._families() for row in request["component_records"]]
    for row in request["component_records"]:
        path = inputs / row["path"]
        path.parent.mkdir(parents=True, exist_ok=True)
        if not path.exists(): path.write_bytes(b"UNFITTED")
        row["size_bytes"] = path.stat().st_size
    request = nested._sealed({key: value for key, value in request.items() if key != "identity_sha256"})
    (inputs / "full-score-input.json").write_bytes(canonical_json_bytes(request))
    for family in nested._families():
        directory = root / "score-evidence" / family
        directory.mkdir(parents=True, exist_ok=True)
        execution = {"family": family, "component_evidence_records": []}
        if family == "COX_PH": execution["retained_score_request_sha256"] = "a" * 64
        (directory / "training-score.json").write_bytes(canonical_json_bytes({"family": family}))
        (directory / "execution.json").write_bytes(canonical_json_bytes(execution))
    monkeypatch.setattr(f5, "_compile_full_score_inputs", lambda *a, **k: request)
    monkeypatch.setattr(f5, "_full_score_resource_admission", lambda *a, **k: (
        {"admitted_worker_ceiling": 1, "limits": {"configured": 24}}, {"retained_result_json_bytes": 10**7}))
    monkeypatch.setattr(f5, "_full_score_job_inputs", lambda *a, **k: None)
    monkeypatch.setattr(f5, "_score_archive_expanded_limit", lambda *a, **k: None)
    with pytest.raises(ContractError, match="COX_REUSE_INPUT_REQUIRED"):
        f5._full_data_locked_score_program({}, [], {}, tmp_path / "selector", {}, root,
            rscript="FORBIDDEN", replay=False, resume=True, selection_horizon_months=12,
            science_decision=decision(), resource_policy={"scratch_reserve_bytes": 0},
            retained_bytes_per_component=10**6, expanded_bytes_per_component=10**6, shared_storage_bytes=10**7,
            retained_full0_source_bundle=tmp_path / "primary.zip", retained_q_archive=tmp_path / "q.zip",
            retained_q_producer_source_bundle=tmp_path / "q-source.zip")


@pytest.mark.parametrize("missing", [False, True])
def test_seven_consumer_never_falls_back_to_models(tmp_path, monkeypatch, missing):
    root = tmp_path / "score.all"
    request, inputs, _, _ = build_fixture(root, full_score=True, science_decision=decision())
    request["component_records"] = [{**row, "family": family,
        "path": row["path"].replace("FPM_TVC_SET_A", family)}
        for family in nested._families() for row in request["component_records"]]
    for row in request["component_records"]:
        path = inputs / row["path"]
        path.parent.mkdir(parents=True, exist_ok=True)
        if not path.exists(): path.write_bytes(b"UNFITTED")
        row["size_bytes"] = path.stat().st_size
    request = nested._sealed({key: value for key, value in request.items() if key != "identity_sha256"})
    (inputs / "full-score-input.json").write_bytes(canonical_json_bytes(request))
    for family in nested._families():
        target = root / "score-evidence" / family
        target.mkdir(parents=True, exist_ok=True)
        (target / "training-score.json").write_bytes(canonical_json_bytes({"family": family}))
        if not (missing and family == nested._families()[-1]):
            (target / "execution.json").write_bytes(canonical_json_bytes({"family": family, "component_evidence_records": []}))
        for repeat in range(1, 4):
            for inner in range(1, 6):
                context = root / f"score-context/{family}/R{repeat}_K{inner}/imp01.csv"
                context.parent.mkdir(parents=True, exist_ok=True)
                context.write_bytes(b"UNFITTED")
    checked = []
    def compile_inputs(*args, **kwargs):
        assert kwargs["replay"] is True and kwargs["resume"] is False
        return request
    def numbers(**kwargs):
        checked.append(kwargs["score"]["family"])
        return kwargs["score"]
    monkeypatch.setattr(f5, "_compile_full_score_inputs", compile_inputs)
    monkeypatch.setattr(nested, "_recompute_fresh_score_from_evidence", numbers)
    monkeypatch.setattr(nested, "validate_fresh_score_execution", lambda value: value)
    monkeypatch.setattr(nested, "select_training_family", lambda scores: {"UNFITTED_SELECTION": True})
    monkeypatch.setattr(f5, "_full_score_storage_usage", lambda *a, **k: {})
    monkeypatch.setattr(f5, "_full_score_resource_admission", lambda *a, **k: (
        {"admitted_worker_ceiling": 1, "limits": {"configured": 24}}, {"retained_result_json_bytes": 10**7}))
    monkeypatch.setattr(f5, "_full_score_job_inputs", lambda *a, **k: None)
    monkeypatch.setattr(f5, "_score_archive_expanded_limit", lambda *a, **k: None)
    for name in ("_execute_and_verify_score_archive_job", "_replay_component_job"):
        monkeypatch.setattr(f5, name, forbidden)
    monkeypatch.setattr(nested, "_score_fresh_family", forbidden)
    monkeypatch.setattr(runtime, "_bounded_ordered_spawn", forbidden)
    kwargs = dict(rscript="FORBIDDEN", replay=False, resume=True, selection_horizon_months=12,
        science_decision=decision(), resource_policy={"scratch_reserve_bytes": 0},
        retained_bytes_per_component=10**6, expanded_bytes_per_component=10**6, shared_storage_bytes=10**7,
        retained_full0_source_bundle=tmp_path / "primary.zip", retained_q_archive=tmp_path / "q.zip",
        retained_q_producer_source_bundle=tmp_path / "q-source.zip")
    if missing:
        with pytest.raises(ContractError, match="NUMERICAL_ORIGINAL_REQUIRED"):
            f5._full_data_locked_score_program({}, [], {}, tmp_path / "selector", {}, root, **kwargs)
        assert checked == [] and not (root / "full-score-result.json").exists()
    else:
        result = f5._full_data_locked_score_program({}, [], {}, tmp_path / "selector", {}, root, **kwargs)
        assert checked == list(nested._families())
        assert result["new_model_fits"] == result["new_model_native_verification_count"] == result["native_model_replay_count"] == 0
        assert result["score_numerical_component_count"] == 2100 and result["pool_execution_reports"] == []
        with pytest.raises(ContractError, match="BATCH_ALREADY_COMPLETED"):
            f5._full_data_locked_score_program({}, [], {}, tmp_path / "selector", {}, root, **kwargs)
        assert checked == list(nested._families())
