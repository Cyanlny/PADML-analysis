"""Closed seven-family reuse through the original score entry; UNFITTED only."""
from pathlib import Path

import pytest

from padml import f4, f5, nested_loco as nested
from padml.bundle import ContractError, canonical_json_bytes, read_safe_zip, strict_json_bytes, write_deterministic_zip


def _closed_archive(path, jobs, handles):
    entries, seals = {}, []
    for job, handle in zip(jobs, handles, strict=True):
        native = Path(job["root"]).with_suffix(".zip")
        raw = native.read_bytes()
        values = read_safe_zip(raw)
        coordinate = job["score_evidence"]["record"]["family"] + "/" + native.stem
        seals.append({"coordinate": coordinate, "request_component_sha256": job["source_sha256"],
            "model_sha256": nested.sha256_bytes(values["model.bin"]),
            "baseline_sha256": nested.sha256_bytes(values["baseline.bin"]),
            "native_handle": handle, "saved_engine_action": "REPLAY"})
        entries["recovery/components/score-native/" + coordinate + ".zip"] = raw
    summary = {"status": "RETAINED_MODEL_EVIDENCE_RECOVERED_NOT_OUTER_ACCEPTANCE", "originals_unchanged": True,
        "new_model_fits": 0, "new_mice_chains": 0, "new_stop_fits": 0,
        "pool": {"status": "COMPLETED", "completed_task_count": len(jobs)},
        "coordinates": [row["coordinate"] for row in seals], "component_seals": seals,
        "original_fit_source": "1" * 64, "evidence_recovery_source": "2" * 64,
        "original_failure_archive_sha256": "3" * 64, "request_identity_sha256": "4" * 64}
    entries["collection.json"] = canonical_json_bytes(summary)
    write_deterministic_zip(path, entries)
    return summary


def _old_job(request, root, record, source):
    name = f"R{record['repeat']}_K{record['inner_fold']}_M{record['imputation']:02d}"
    native = root / "components/score-native" / record["family"] / name
    native.parent.mkdir(parents=True, exist_ok=True)
    scratch = root / "scratch"
    scratch.mkdir(exist_ok=True)
    return {"source": str(source), "root": str(native), "scratch_root": str(scratch),
        "expanded_bytes_per_component": request["expanded_bytes_per_component"],
        "retained_bytes_per_component": request["retained_bytes_per_component"],
        "source_sha256": record["sha256"], "source_size_bytes": record["size_bytes"],
        "coordinate_identity": nested._sha({"request_identity_sha256": "4" * 64, "record": record}),
        "score_evidence": {"path": str(root / "score-evidence" / record["family"] / (name + ".json")),
            "record": record, "context": {"scope": "OUTER", "outer_fold": 1, "identity_sha256": "5" * 64},
            "partition_id": next(row["partition_id"] for row in request["score_partitions"]
                if (row["repeat"], row["inner_fold"]) == (record["repeat"], record["inner_fold"]))}}


def retained_score_fixture(request, source_root, destination, ids):
    """Create historical UNFITTED objects once, never in the new coordinate tree."""
    records = [row for row in request["component_records"] if row["path"] in ids]
    jobs = [_old_job(request, destination / "old", row, source_root / row["path"]) for row in records]
    handles = [f5._execute_and_verify_score_archive_job(job) for job in jobs]
    archive = destination / "closed-recovery.zip"
    _closed_archive(archive, jobs, handles)
    return archive


@pytest.fixture(params=list(nested._families()))
def retained_case(tmp_path, request):
    source = tmp_path / "input.zip"
    inputs = {name: b"{}" for name in nested._COMPONENT_MEMBERS}
    write_deterministic_zip(source, inputs)
    record = {"family": request.param, "repeat": 1, "inner_fold": 1, "imputation": 1,
        "sha256": nested.sha256_file(source), "size_bytes": source.stat().st_size}
    request = {"expanded_bytes_per_component": 10000, "retained_bytes_per_component": 100000,
        "score_partitions": [{"repeat": 1, "inner_fold": 1, "partition_id": "F1-R1-K1"}]}
    old = _old_job(request, tmp_path / "old", record, source)
    native = Path(old["root"]).with_suffix(".zip")
    write_deterministic_zip(native, {**inputs, **{name: b"{}" for name in (
        "model.bin", "baseline.bin", "fit-health.json", "training-prediction.json", "prediction.json")}})
    handle = {**f5._score_archive_handle(old, expanded_bytes_per_component=10000),
        "evidence_sha256": "6" * 64, "evidence_size_bytes": 2}
    archive = tmp_path / "closed.zip"
    _closed_archive(archive, [old], [handle])
    current = _old_job(request, tmp_path / "new", record, source)
    current["coordinate_identity"] = "7" * 64
    current["score_evidence"]["context"]["identity_sha256"] = "8" * 64
    return archive, current, native


@pytest.mark.parametrize("damage", [None, "coordinate", "missing_member", "native_bytes", "input_bytes",
    "model_sha", "baseline_sha", "old_record", "new_fit", "bool_count", "archive_changed", "existing_target"])
def test_closed_retained_worker_never_fits_and_binds_original_bytes(retained_case, monkeypatch, damage):
    archive, job, native = retained_case
    original_sha = nested.sha256_file(native)
    entries = read_safe_zip(archive)
    summary = strict_json_bytes(entries["collection.json"])
    row = summary["component_seals"][0]
    if damage == "coordinate":
        summary["coordinates"][0] = "FPM_TVC_SET_A/R1_K1_M02"
    elif damage == "missing_member":
        entries.pop("recovery/components/score-native/" + row["coordinate"] + ".zip")
    elif damage == "native_bytes":
        entries["recovery/components/score-native/" + row["coordinate"] + ".zip"] = b"changed"
    elif damage == "input_bytes":
        inputs = read_safe_zip(Path(job["source"]))
        inputs["recipe.json"] = b'{"changed":true}'
        changed = archive.with_name("changed-input.zip")
        write_deterministic_zip(changed, inputs)
        Path(job["source"]).write_bytes(changed.read_bytes())
    elif damage in {"model_sha", "baseline_sha"}:
        row[damage + "256"] = "9" * 64
    elif damage == "old_record":
        row["native_handle"]["coordinate_identity"] = "9" * 64
    elif damage == "new_fit":
        summary["new_model_fits"] = 1
    elif damage == "bool_count":
        summary["pool"]["completed_task_count"] = True
    entries["collection.json"] = canonical_json_bytes(summary)
    archive = archive.with_name("test-mutated.zip")
    write_deterministic_zip(archive, entries)
    target = Path(job["root"]).with_suffix(".zip")
    if damage == "existing_target":
        target.write_bytes(b"UNFITTED already started; must preserve")
    monkeypatch.setattr(f4, "_execute_f4_model_component", lambda *a, **k: pytest.fail("NO_NEW_FIT"))
    replayed = []
    def replay(value, *, retained_model_source):
        assert value == job and target.read_bytes() == native.read_bytes()
        replayed.append(retained_model_source)
        return {"UNFITTED_ORIGINAL_REPLAY_REACHED": True}
    monkeypatch.setattr(f5, "_replay_component_job", replay)
    def execute():
        selected = f5._retained_score_jobs(archive, [job], shared_storage_bytes=100000)
        if damage == "archive_changed":
            archive.write_bytes(b"changed after selection")
        return f5._replay_retained_score_job(selected[0])
    if damage is None:
        assert execute() == {"UNFITTED_ORIGINAL_REPLAY_REACHED": True}
        assert replayed[0]["historical_model_fit_count"] == 1 and replayed[0]["new_model_fit_count"] == 0
        assert replayed[0]["kind"] == nested._RETAINED_SCORE_SOURCE_KINDS[job["score_evidence"]["record"]["family"]]
    else:
        with pytest.raises(ContractError):
            execute()
        assert replayed == []
        assert not target.exists() or damage == "existing_target"
    assert nested.sha256_file(native) == original_sha


@pytest.mark.parametrize("kind", ["missing", "directory", "symlink", "relative", "full0"])
def test_retained_score_invalid_path_and_scope_fail_before_writes(retained_case, tmp_path, kind):
    archive, _, _ = retained_case
    invalid = tmp_path / "invalid"
    if kind == "directory":
        invalid.mkdir()
    elif kind == "symlink":
        invalid.symlink_to(archive)
    elif kind == "relative":
        invalid = Path("relative.zip")
    elif kind == "full0":
        invalid = archive
    root = tmp_path / "must-not-exist"
    with pytest.raises(ContractError, match="NESTED_RETAINED_SCORE_(SCOPE|ARCHIVE)_INVALID"):
        f5._full_data_locked_score_program(None, None, None, None, None, root,
            rscript="UNFITTED", replay=False, resume=True, resource_policy={},
            retained_bytes_per_component=10000, expanded_bytes_per_component=10000, shared_storage_bytes=100000,
            outer_input=archive if kind != "full0" else None, task_ids=["UNFITTED"],
            batch_root=root / "score-batches/test", retained_score_archive=invalid)
    assert not root.exists()


def test_retained_score_unknown_family_still_rejected(retained_case):
    archive, job, _ = retained_case
    entries = read_safe_zip(archive)
    summary = strict_json_bytes(entries["collection.json"])
    old_coordinate = summary["coordinates"][0]
    coordinate = "UNKNOWN_FAMILY/R1_K1_M01"
    record = {**job["score_evidence"]["record"], "family": "UNKNOWN_FAMILY"}
    job = {**job, "score_evidence": {**job["score_evidence"], "record": record}}
    summary["coordinates"] = [coordinate]
    summary["component_seals"][0]["coordinate"] = coordinate
    summary["component_seals"][0]["native_handle"]["coordinate_identity"] = nested._sha({
        "request_identity_sha256": summary["request_identity_sha256"], "record": record})
    entries["recovery/components/score-native/" + coordinate + ".zip"] = entries.pop(
        "recovery/components/score-native/" + old_coordinate + ".zip")
    entries["collection.json"] = canonical_json_bytes(summary)
    target = archive.with_name("unsupported-family.zip")
    write_deterministic_zip(target, entries)
    with pytest.raises(ContractError, match="NESTED_RETAINED_SCORE_COORDINATES_INVALID"):
        f5._retained_score_jobs(target, [job], shared_storage_bytes=100000)
