"""Original five-stage Q and numerical handoffs; UNFITTED leaf adapters only.

These tests do not qualify native engines: test_a12_q_native covers those
original leaf readers separately. Here the original grids, STOP barriers,
MI/OOF arithmetic, choosers, batch publication and complete-Q owners run.
"""
from contextlib import contextmanager
import json
import math
from pathlib import Path
import shutil

import pytest

from padml import f2_kernel as kernel, f4_compact as compact, f5, runtime
from padml import f5_sensitivity as sensitivity, nested_loco as nested
from padml.bundle import ContractError, canonical_json_bytes, sha256_bytes, sha256_file
from test_nested_full_development import (  # noqa: F401
    full_inputs, unfitted_selector_consumers, _physical_full_inputs, _unfitted_confirmed_decision,
)
from test_nested_aar_mice import (  # noqa: F401
    aar_source, unfitted_redevelopment_inputs, unfitted_selector_engines,
)


_OBSERVE = runtime.observe_execution_resources
_STAGES = ("S1", "S2", "S3A", "S3B1", "S3B2")
_COUNTS = {"RSF": (24, 8, 3, 2, 1), "GBM_COX": (28, 10, 3, 2, 1),
           "XGBOOST_COX": (40, 14, 3, 2, 1), "COXTIME_SET_A": (12, 4, 2, 2, 1)}
_POLICY = {"configured_worker_ceiling": runtime.CPU_MINUS_8, "memory_bytes_per_worker": 1,
           "scratch_bytes_per_worker": 1, "memory_reserve_bytes": 0, "scratch_reserve_bytes": 0,
           "transfer_archive_worker_ceiling": 1}


def test_gbm_stop_readback_charges_whole_unit_to_worker_and_keeps_full_phase_scratch():
    policy = {**_POLICY, "memory_bytes_per_worker": 4 * 1024**3,
              "memory_reserve_bytes": 2 * 1024**3, "scratch_reserve_bytes": 2 * 1024**3}
    # Synthetic byte counts only: the five frozen-shaped partitions and
    # 28 candidate STOP units each. No files, fits, or clinical inputs.
    risks = [n * 5000 * 8 for n in [1694, 1696, 1698, 1702, 1706] for _ in range(28)]
    unit_bytes = [size + 128 * 1024 for size in risks]
    metadata, input_bytes = 2 * 1024**2, 100104
    incoming = sum(unit_bytes) + metadata
    actual = f5._q_batch_numerical_resource_policy(policy, input_bytes, incoming,
        gbm_stop_unit_bytes=unit_bytes, gbm_stop_risk_bytes=sum(risks))
    assert actual["memory_bytes_per_worker"] == policy["memory_bytes_per_worker"] + 32 * max(unit_bytes)
    assert actual["memory_reserve_bytes"] == (policy["memory_reserve_bytes"]
        + 32 * (incoming - sum(risks) + 16 * 1024**2) + 64 * input_bytes)
    assert actual["scratch_reserve_bytes"] == policy["scratch_reserve_bytes"] + 2 * incoming + 32 * 1024**2
    assert actual["configured_worker_ceiling"] == runtime.CPU_MINUS_8
    assert actual["transfer_archive_worker_ceiling"] == policy["transfer_archive_worker_ceiling"]
    original = f5._q_batch_numerical_resource_policy(policy, input_bytes, incoming)
    assert original == {**policy,
        "memory_reserve_bytes": policy["memory_reserve_bytes"] + 32 * incoming + 64 * input_bytes,
        "scratch_reserve_bytes": policy["scratch_reserve_bytes"] + 2 * incoming + 32 * 1024**2}
    assert original["memory_reserve_bytes"] > 120 * 1024**3
    assert actual["memory_reserve_bytes"] + actual["memory_bytes_per_worker"] < 120 * 1024**3


@pytest.mark.parametrize("kwargs", [
    {"gbm_stop_risk_bytes": 1},
    {"gbm_stop_unit_bytes": []},
    {"gbm_stop_unit_bytes": [True]},
    {"gbm_stop_unit_bytes": [10], "gbm_stop_risk_bytes": -1},
    {"gbm_stop_unit_bytes": [10], "gbm_stop_risk_bytes": 101},
])
def test_gbm_stop_readback_rejects_unbound_or_invalid_worker_risk_bytes(kwargs):
    with pytest.raises(ContractError, match="F5_Q_BATCH_NUMERICAL_"):
        f5._q_batch_numerical_resource_policy(_POLICY, 10, 100, **kwargs)


@pytest.mark.parametrize("family,mode,producer,exact,source_mode", [
    ("GBM_COX", "GROUPED_COX_LOCK", "GBM_STOP_CURVE", True, "current"),
    ("GBM_COX", "GROUPED_COX_LOCK", "GBM_STOP_CURVE", False, "current"),
    ("GBM_COX", "GROUPED_COX_LOCK", "OTHER_PRODUCER", True, "current"),
    ("GBM_COX", "IBS", "PREDICTION", True, "current"),
    ("GBM_COX", "SURVIVAL", "PREDICTION", True, "current"),
    ("RSF", "IBS", "PREDICTION", True, "current"),
    ("GBM_COX", "IBS", "PREDICTION", True, "retained-gbm"),
    ("GBM_COX", "IBS", "PREDICTION", True, "retained-gbm-missing-release"),
    ("GBM_COX", "GROUPED_COX_LOCK", "GBM_STOP_CURVE", True, "retained-gbm-forged-loss"),
    ("GBM_COX", "GROUPED_COX_LOCK", "GBM_STOP_CURVE", True, "retained-gbm-missing-loss"),
    ("RSF", "IBS", "PREDICTION", True, "outer4-5c"),
    ("RSF", "IBS", "PREDICTION", True, "outer4-5c-missing-proof"),
    ("RSF", "IBS", "PREDICTION", True, "outer4-5c-wrong-source"),
    *[("RSF", "IBS", "PREDICTION", True, mode) for mode in
      ("mixed", "mixed-no-proof", "mixed-missing-current-release", "mixed-duplicate")],
])
def test_q_reader_callsite_owns_only_exact_gbm_stop_risk_members(
        tmp_path, monkeypatch, family, mode, producer, exact, source_mode):
    """Synthetic bytes/projection; native numerical leaves never execute."""
    from padml import f4
    owner, batch = tmp_path / "owner", tmp_path / "batch"
    (owner / "native").mkdir(parents=True)
    batch.mkdir()
    policy = {**_POLICY, "memory_bytes_per_worker": 4 * 1024**3}
    observation = {"effective_cpus": 32, "available_memory_bytes": 64 * 1024**3,
        "scratch_available_bytes": 64 * 1024**3, "scratch_root": str(owner)}
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda root: {**observation, "scratch_root": str(root)})
    control = {"resource_policy": policy, "completed": False}
    current_operational = ({'execution_worker_memory_bytes': 2 * 1024**3,
                            'execution_scratch_reserve_bytes': 0}
                           if source_mode == 'current' or source_mode.startswith('outer4-5c') else {})
    control.update(current_operational)
    spec = {"family": family, "native_search_root": str(owner / "native"), "native_search_batch": control}
    units, rows, projections, total_risk, unit_sizes = {}, [], {}, 0, []
    for index in range(2):
        name, leaf = f"batch-synthetic-{index}", f"synthetic-{index}"
        task = (spec, {}, [{"task_id": leaf, "producer_kind": producer}], "UNFITTED", "UNFITTED", mode, {})
        native = (name, leaf)
        units[name] = (task, native)
        entries = {"input.json": b"{}", f"native/{name}/spec.json": b"{}"}
        if family == "GBM_COX" and mode == "GROUPED_COX_LOCK" and producer == "GBM_STOP_CURVE":
            members = ("output.json",) if source_mode == "retained-gbm-missing-loss" else ("evaluation.json", "output.json")
            entries.update({f"native/{name}/{member}": b"{}" for member in members})
        for role in ("fit", "evaluation"):
            suffix = "" if exact else ".near"
            entries[f"native/{name}/risk-001-gbm-{role}.bin{suffix}"] = b"UNFITTED" * (index + 1)
            if exact:
                total_risk += len(entries[f"native/{name}/risk-001-gbm-{role}.bin"])
        projection = {}
        for member, raw in entries.items():
            path = batch / member
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(raw)
            projection[member] = path
        numerical = {key: {"sha256": sha256_file(path), "size_bytes": path.stat().st_size}
                     for key, path in projection.items()}
        projections[native] = (projection, numerical)
        unit_sizes.append(sum(row["size_bytes"] for row in numerical.values()))
        rows.append({"task_id": name, "native_units": list(native), "members": numerical,
            "numerical_members": numerical, "retained_bytes": 100, "first_native_audit_count": 1})
    input_ref = {"sha256": sha256_bytes(b"{}"), "size_bytes": 2}
    effective = f5._q_batch_resource_policy(policy, 2, 2, 4 * 1024**2, **current_operational)
    admitted = runtime.resource_admission(effective, observation, legal_tasks=2)
    execution = {"phase": "synthetic", "input": input_ref, "task_ids": list(units), **current_operational,
        "source_identity": sha256_bytes(canonical_json_bytes(f4._f45_source_member_sha256())),
        "operational_identity": runtime.OPERATIONAL_IDENTITY, "resource_policy": policy,
        "effective_policy": effective, "resource_observation": observation, "resource_admission": admitted,
        "retained_bytes_per_task": 4 * 1024**2, "units": rows,
        "confirmed_first_native_audit_count": 2, "new_model_fit_count": 2,
        "pool": {"configured_worker_ceiling": 24, "admitted_worker_ceiling": admitted["admitted_worker_ceiling"],
            "runnable_task_count": 2, "actual_worker_process_peak": 1, "completed_task_count": 2,
            "engine_threads": 1, "status": "COMPLETED"}}
    def diagnostics(ids):
        return {"units": {name: runtime.release_step_resources([], owner="Q_UNIT:" + name,
                    before=runtime.observe_step_memory(), released_references=[]) for name in ids},
                "worker_results": {str(index): runtime.release_step_resources([], owner=f"POOL_TASK_RESULT:{index}",
                    before=runtime.observe_step_memory(), released_references=[]) for index in range(len(ids))}}
    execution["resource_release"] = diagnostics(list(units))
    batches = [(batch, execution)]
    if source_mode.startswith("mixed"):
        import copy
        import os
        source_path = os.environ.get("PADML_RETAINED_FULL0_SOURCE_BUNDLE")
        if source_path is None:
            pytest.skip("exact retained code-only source required")
        retained_identity = sha256_bytes(canonical_json_bytes(f4._retained_full0_source_members(Path(source_path))))
        control["retained_primary_source_identity"] = retained_identity
        spec.update(execution_scope="F5_A12_SEARCH", a12_source={"branch": nested.A12_DIRECT_AAR,
            "outer_fold": 1, "family": family, "source": {"kind": "PADML_F5_A12_PROJECTED_OUTER_INPUTS_V1"}})
        old_batch = tmp_path / "old-batch"
        (old_batch / "native").mkdir(parents=True)
        first_name, first_leaf = rows[0]["native_units"]
        shutil.move(str(batch / "native" / first_name), str(old_batch / "native" / first_name))
        shutil.copyfile(batch / "input.json", old_batch / "input.json")
        projections[(first_name, first_leaf)] = ({name: old_batch / name for name in projections[(first_name, first_leaf)][0]},
                                                 projections[(first_name, first_leaf)][1])
        old_execution = copy.deepcopy(execution)
        batches = [(old_batch, old_execution), (batch, execution)]
        for index, (_, record) in enumerate(batches):
            record.update(task_ids=[rows[index]["task_id"]], units=[rows[index]],
                          confirmed_first_native_audit_count=1, new_model_fit_count=1)
            record["effective_policy"] = f5._q_batch_resource_policy(policy, 2, 1, 4 * 1024**2)
            record["resource_admission"] = runtime.resource_admission(record["effective_policy"], observation, legal_tasks=1)
            record["pool"].update(runnable_task_count=1, completed_task_count=1,
                                  admitted_worker_ceiling=record["resource_admission"]["admitted_worker_ceiling"])
            record["resource_release"] = diagnostics(record["task_ids"])
        old_execution["source_identity"] = retained_identity
        del old_execution["resource_release"]
        if source_mode == "mixed-no-proof":
            del control["retained_primary_source_identity"]
        elif source_mode == "mixed-missing-current-release":
            del execution["resource_release"]
        elif source_mode == "mixed-duplicate":
            execution["task_ids"] = old_execution["task_ids"]
    elif source_mode.startswith("retained-gbm"):
        import os
        primary_path = Path(os.environ["PADML_RETAINED_FULL0_SOURCE_BUNDLE"])
        q_path = Path(os.environ["PADML_RETAINED_GBM_Q_SOURCE_BUNDLE"])
        execution["source_identity"] = sha256_bytes(canonical_json_bytes(
            f4._retained_gbm_q_source_members(q_path, primary_path)))
        spec.update(execution_scope="F5_A12_SEARCH",
            retained_a12_primary_context_source_bundle=str(primary_path),
            a12_executor_source_identity=sha256_bytes(canonical_json_bytes(f4._f45_source_member_sha256())))
        if source_mode == "retained-gbm-missing-release":
            del execution["resource_release"]
    elif source_mode.startswith("outer4-5c"):
        spec.update(execution_scope="F5_A12_SEARCH", fold=4,
            a12_source={"branch": nested.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT,
                "outer_fold": 4, "family": "RSF", "common_set_epv_binding": {"UNFITTED": True}})
        control["gbm_retained_sources"] = {
            "execution-evidence/retained-sources/primary1513.zip": {"sha256": "1" * 64, "size_bytes": 1},
            "execution-evidence/retained-sources/selector1ae.zip": {"sha256": "2" * 64, "size_bytes": 1},
            "execution-evidence/retained-sources/selector-executor.zip": {"sha256": "3" * 64, "size_bytes": 1}}
        execution["source_identity"] = ("0" * 64 if source_mode == "outer4-5c-wrong-source" else
            "5c30305f8279acc7407bffc1b9d2d09cb1d100f819f69d4e7486c131c8bee5df")
        if source_mode == "outer4-5c-missing-proof":
            control["gbm_retained_sources"].pop("execution-evidence/retained-sources/selector-executor.zip")
    for path, record in batches:
        (path / "execution.json").write_bytes(canonical_json_bytes(record))
    if source_mode.startswith("retained-gbm"):
        control.update(f5._q_search_batch_control(owner, policy, _options([batch]),
            retained_primary_source_bundle=primary_path, retained_gbm_q_source_bundle=q_path))
        assert "retained_primary_source_identity" not in control
    monkeypatch.setattr(compact, "_full_pipeline_q_numerical_members",
        lambda root, *, native_units, transported_refs: projections[native_units])
    seen = []
    original_admit = runtime.resource_admission
    def admit(actual_policy, observed, *, legal_tasks):
        seen.append(actual_policy)
        return original_admit(actual_policy, observed, legal_tasks=legal_tasks)
    monkeypatch.setattr(runtime, "resource_admission", admit)
    class BeforeReader(Exception):
        pass
    def no_reader(function, tasks, **kwargs):
        assert all("native_search_batch" not in task[0] for task in tasks)
        assert all(task[0].get("retained_gbm_q_source_bundle") == (
            str(q_path) if source_mode.startswith("retained-gbm") else None) for task in tasks)
        if family == "GBM_COX" and mode == "GROUPED_COX_LOCK" and producer == "GBM_STOP_CURVE":
            assert all(task[0]["gbm_stop_loss_references"] == {
                name: {"sha256": sha256_bytes(b"{}"), "size_bytes": 2}
                for name in ("evaluation.json", "output.json")} for task in tasks)
        raise BeforeReader
    monkeypatch.setattr(f5, "_bounded_ordered_spawn", no_reader)
    if source_mode in {"retained-gbm-missing-release", "retained-gbm-forged-loss", "retained-gbm-missing-loss"}:
        reason = {"retained-gbm-missing-release": "F5_Q_BATCH_SOURCE_MISMATCH",
            "retained-gbm-forged-loss": "F5_RETAINED_GBM_Q_HISTORICAL_LOSS_FORBIDDEN",
            "retained-gbm-missing-loss": "F4_COMPACT_Q_GBM_LOSS_REFERENCE_INVALID"}[source_mode]
        with pytest.raises(ContractError, match=reason):
            f5._consume_q_search_batches(spec, kernel._run_r_prediction_pool_task, units, batches, "synthetic", input_ref)
        return
    if source_mode in {"mixed-no-proof", "mixed-missing-current-release", "mixed-duplicate"}:
        with pytest.raises(ContractError, match="F5_Q_BATCH_(SOURCE_MISMATCH|COORDINATE_COVERAGE_INVALID)"):
            f5._consume_q_search_batches(spec, kernel._run_r_prediction_pool_task, units, batches, "synthetic", input_ref)
        return
    if source_mode in {"outer4-5c-missing-proof", "outer4-5c-wrong-source"}:
        with pytest.raises(ContractError, match="F5_Q_(SCRATCH_RESERVE_OVERRIDE_INVALID|BATCH_SOURCE_MISMATCH)"):
            f5._consume_q_search_batches(spec, kernel._run_r_prediction_pool_task,
                units, batches, "synthetic", input_ref)
        return
    with pytest.raises(BeforeReader):
        f5._consume_q_search_batches(spec, kernel._run_r_prediction_pool_task, units,
            batches, "synthetic", input_ref)
    incoming = sum(path.stat().st_size for batch, _ in batches for path in batch.rglob("*") if path.is_file())
    special = family == "GBM_COX" and mode == "GROUPED_COX_LOCK" and producer == "GBM_STOP_CURVE"
    expected = f5._q_batch_numerical_resource_policy(policy, 2, incoming,
        **({"gbm_stop_unit_bytes": unit_sizes, "gbm_stop_risk_bytes": total_risk} if special else {}),
        **current_operational)
    assert seen[-1] == expected
    assert expected["scratch_reserve_bytes"] == (0 if current_operational else
        policy["scratch_reserve_bytes"] + 2 * incoming + 32 * 1024**2)
    if special and exact and source_mode == "current":
        # Exercise the same phase's copy/close boundary with UNFITTED return
        # sentinels. Only the finite, exact risk members may be advised; the
        # original unit counts, return values and bytes must survive unchanged.
        releases = {}
        control.update(references={}, used_batches=[], confirmed_model_fits=0,
                       confirmed_stop_fits=0, numerical_phase_releases=releases)
        returned = [{"UNFITTED_NUMERICAL_LEAF": name} for name in units]
        monkeypatch.setattr(f5, "_bounded_ordered_spawn", lambda *args, **kwargs: returned)
        original_files = {path: path.read_bytes() for path in batch.rglob("*") if path.is_file()}
        actual = f5._consume_q_search_batches(spec, kernel._run_r_prediction_pool_task,
            units, batches, "synthetic", input_ref)
        assert actual is returned and control["confirmed_model_fits"] == control["confirmed_stop_fits"] == 2
        release = releases["synthetic"]
        runtime.validate_resource_release(release)
        assert {row["path"] for row in release["files"]} == {
            str(root / f"native/{name}/risk-001-gbm-{role}.bin")
            for root in (batch, owner) for name in units for role in ("fit", "evaluation")}
        assert release["owner"] == "Q_NUMERICAL_PHASE:synthetic:" + input_ref["sha256"]
        assert all(path.read_bytes() == raw for path, raw in original_files.items())
        assert all((owner / path.relative_to(batch)).read_bytes() == raw
                   for path, raw in original_files.items() if path.name != "execution.json")


def _options(history=None, ids=None, destination=None, *, retained_bytes=4 * 1024**2):
    return {"prepare_only": ids is None, "task_ids": ids, "batch_root": destination,
            "q_batches": history, "retained_bytes_per_task": retained_bytes if ids else None}


def _serial_pool(function, tasks, *, selected_slots, execution_report=None, on_result=None, resource_release_report=None):
    assert 1 <= selected_slots <= 24
    # Assert at the parent/pool boundary, before any worker normalizes its task.
    for task in tasks:
        item = task["task"] if function is f5._execute_and_verify_q_search_unit else task
        name = task["function"] if function is f5._execute_and_verify_q_search_unit else function.__name__
        spec = (item[0]["spec"] if name == "_run_python_stop_pair_pool_task" else
                item[0] if isinstance(item, (tuple, list)) else item["spec"])
        assert "native_search_batch" not in spec
    if execution_report is not None:
        execution_report.update(configured_worker_ceiling=24, admitted_worker_ceiling=selected_slots,
            runnable_task_count=len(tasks), actual_worker_process_peak=1, completed_task_count=0,
            engine_threads=1, status="RUNNING")
    rows = []
    for index, item in enumerate(tasks):
        row = function(item)
        rows.append(row)
        if on_result is not None:
            on_result(index, row)
        if resource_release_report is not None:
            # Explicit serial fixture, not evidence of production worker RSS.
            resource_release_report[str(index)] = runtime.release_step_resources([], owner=f"POOL_TASK_RESULT:{index}",
                before=runtime.observe_step_memory(), released_references=[])
    if execution_report is not None:
        execution_report.update(completed_task_count=len(tasks), status="COMPLETED")
    return rows


def _leaf_binding(spec, task):
    return {"fixture": "UNFITTED_Q_FUNNEL_LEAF", "task": task,
            "spec": {key: spec[key] for key in ("family", "fold", "seed", "execution_scope",
                "registered_inputs_identity_sha256", "selector_from_dependency")},
            "source": spec.get("primary_search_source", spec.get("final_search_source", spec.get("a12_source")))}


def _unfitted_leaves(monkeypatch, kernel_module=kernel, *, gbm_loss_fixture=False):
    """Leaf bytes bind original coordinates; real metrics consume their arrays."""
    kernel = kernel_module
    events, locks = [], []

    def retained(spec, name, binding, value):
        directory = Path(spec["native_search_root"]) / name
        raw = canonical_json_bytes({"binding": binding, "result": value})
        marker = b"UNFITTED_MODEL_NOT_AN_ENGINE:" + sha256_bytes(canonical_json_bytes(binding)).encode()
        # The current GBM gather transports the independently pinned loss
        # artifacts. These explicit UNFITTED leaves test that transport only;
        # test_a12_q_native owns actual risk/loss arithmetic qualification.
        loss_members = ({"evaluation.json", "output.json"}
                        if gbm_loss_fixture and spec['family'] == 'GBM_COX' and name.startswith('batch-')
                        and binding['task'][0].get('producer_kind') == 'GBM_STOP_CURVE' else set())
        members = {"model.bin", "values.json", *loss_members}
        if compact._full_pipeline_q_numbers_mode(spec):
            compact._full_pipeline_q_object_numbers(directory, spec, members)
            if loss_members:
                assert spec['gbm_stop_loss_references'] == {
                    key: {'sha256': sha256_file(directory / key), 'size_bytes': (directory / key).stat().st_size}
                    for key in loss_members}
            assert (directory / "values.json").read_bytes() == raw
            events.append(("numbers", str(directory), name))
        elif spec["native_search_replay"]:
            assert (directory / "model.bin").read_bytes() == marker
            assert (directory / "values.json").read_bytes() == raw
            events.append(("audit", str(directory), name))
        else:
            directory.mkdir()
            (directory / "model.bin").write_bytes(marker)
            (directory / "values.json").write_bytes(raw)
            for key in loss_members:
                (directory / key).write_bytes(canonical_json_bytes({'UNFITTED_LOSS_TRANSPORT': key, 'binding': binding}))
            events.append(("produce", str(directory), name))
        return json.loads(raw)["result"]

    def prediction(parameters, partition, imp):
        # Distinct, deterministic probabilities, not preassigned trial scores.
        hazard = .002 + int(sha256_bytes(canonical_json_bytes(parameters))[:12], 16) / 16**12 * .02
        hazard += imp * .000001
        matrix = [[math.exp(-hazard * month)] * len(partition["evaluation_ids"]) for month in range(1, 37)]
        return kernel._seal_prediction_matrix(partition["evaluation_ids"], list(map(list, zip(*matrix))), list(range(1, 37)))

    def stop_pair(call):
        task, partition = call
        spec = task["spec"]
        assert "native_search_batch" not in spec and partition["partition_id"] == task["partition_id"]
        assert not kernel._contains_key(task["registered"], "evaluation_response")
        original = {key: value for key, value in task.items() if key not in {"spec", "registered", "handoff_path"}}
        binding = _leaf_binding(spec, original)
        identity = sha256_bytes(canonical_json_bytes(binding))
        p = (partition["repeat"] - 1) * 5 + partition["inner_fold"]
        optimum = 40 + p + task["imputation"] % 3
        losses = [1.0 + (index + 1 - optimum)**2 / 10000 for index in range(300)]
        body = {key: task[key] for key in ("task_id", "partition_id", "imputation")}
        if spec["family"] == "COXTIME_SET_A":
            body.update(function_sha256=identity, curve={"losses": losses, "function_sha256": identity,
                "evaluation_response_sha256": partition["evaluation_response"]["sha256"]})
        else:
            body["lock"] = kernel._tree_stopping_lock_from_losses(losses, risk_curve_sha256=identity,
                fit_response_sha256=partition["fit_response"]["sha256"],
                evaluation_response_sha256=partition["evaluation_response"]["sha256"],
                minimum_improvement=0.0, patience=10, family="XGBOOST_COX")
        return retained(spec, task["task_id"], binding, {**body, "task_identity_sha256": kernel._sha(body)})

    def refit(task):
        spec, family = task["spec"], task["spec"]["family"]
        assert "native_search_batch" not in spec and "handoff_path" not in task
        assert not kernel._contains_key(task["registered"], "evaluation_response")
        partition, = task["registered"]["partitions"]
        assert partition["kind"] == "INNER" and partition["partition_id"] == task["partition_id"]
        original = {key: value for key, value in task.items() if key not in {"spec", "registered"}}
        binding = _leaf_binding(spec, original)
        locked = task["locked_rounds" if family == "XGBOOST_COX" else "locked_epoch"]
        fit_n, eval_n = len(partition["fit_ids"]), len(partition["evaluation_ids"])
        digest = sha256_bytes(canonical_json_bytes(binding))
        if family == "XGBOOST_COX":
            health = {"converged": True, "engine": "xgboost survival:cox", "objective": "survival:cox",
                "booster_round_count": locked, "training_margin_count": fit_n, "evaluation_margin_count": eval_n,
                "model_binary_sha256": digest, "cox_objective": {"implementation": "GROUPED_BRESLOW_FLOAT64_TIME_V1",
                    "gradient_evaluations": locked, "training_rows": fit_n, "event_time_groups": 1}}
        else:
            health = {"converged": True, "engine": "pycox.models.CoxTime", "training_epoch_count": locked,
                "training_row_count": fit_n, "evaluation_row_count": eval_n, "final_training_loss": .2,
                "raw_survival_grid_validated": True, "model_state_sha256": digest,
                "baseline_numerics": {"implementation": "FULL_T_GE_T_RISK_SET_V1", "training_rows": fit_n,
                    "event_time_groups": 1, "checked_raw_scores": fit_n}}
            if task["task_id"].startswith("S3B2_"):
                assert locks and locked == locks[-1]["locked_epoch"]
        parameters = task["parameters" if family == "XGBOOST_COX" else "candidate"]
        body = {**{key: task[key] for key in ("task_id", "partition_id", "imputation")},
                "sealed_prediction": prediction(parameters, partition, task["imputation"]), "fit_health": health}
        return retained(spec, task["task_id"], binding, {**body, "task_identity_sha256": kernel._sha(body)})

    def r_batch(call):
        spec, registered, tasks, _, _, mode, partition = call
        assert not kernel._contains_key(registered, "evaluation_response")
        binding_spec = spec
        if gbm_loss_fixture and 'full0_rsf_s1s2_rescore' in spec:
            # Only this explicit synthetic common-prefix fixture projects
            # its marker binding. The real R pair is tested independently.
            pair = spec['full0_rsf_s1s2_rescore']
            old = json.loads(Path(pair['producer_input']['path']).read_bytes())
            new = json.loads(Path(pair['consumer_input']['path']).read_bytes())
            f5._full0_rsf_s1s2_input_pair(old, new)
            assert spec['family'] == 'GBM_COX' and spec['selection_horizon_months'] == 12
            binding_spec = {**spec, 'final_search_source': old['spec']['final_search_source']}
        name = "batch-" + sha256_bytes(canonical_json_bytes([row["task_id"] for row in tasks]))[:24]
        retained(spec, name, _leaf_binding(binding_spec, tasks), {"ordered_task_ids": [row["task_id"] for row in tasks]})
        results = []
        for task in tasks:
            body = {key: task[key] for key in ("task_id", "partition_id", "imputation")}
            if mode == "GROUPED_COX_LOCK":
                assert task["producer_kind"] == "GBM_STOP_CURVE" and len(tasks) == 1
                body.update(selected_trees=50 + task["imputation"],
                    risk_curve_sha256=kernel._sha(task), minimum_stopping_loss=.2)
                body["identity"] = kernel._sha(body)
            else:
                assert mode == "IBS" and partition["kind"] == "INNER"
                sealed = prediction(task["parameters"], partition, task["imputation"])
                horizon = 24 if binding_spec is not spec else kernel._selection_horizon_from_spec(spec)
                metric = kernel._evaluate_prediction_seal(kernel._monthly_prediction_seal(sealed),
                    fit_response=partition["fit_response"], evaluation_response=partition["evaluation_response"],
                    selection_horizon_months=horizon)
                body.update(prediction_seal_sha256=sealed["sha256"],
                    evaluation_response_sha256=partition["evaluation_response"]["sha256"],
                    evaluation_ids_sha256=partition["evaluation_ids_sha256"],
                    stopping={"UNFITTED": True}, sealed_prediction=sealed)
                body[f'ibs_0_{horizon}'] = metric[f'ibs_0_{horizon}']
            row = retained(spec, task["task_id"], _leaf_binding(binding_spec, task), body)
            if binding_spec is not spec and mode == 'IBS':
                # Read the retained synthetic curve through the original IBS12
                # arithmetic; an IBS24 key relabel is deliberately insufficient.
                metric = kernel._evaluate_prediction_seal(kernel._monthly_prediction_seal(row['sealed_prediction']),
                    fit_response=partition['fit_response'], evaluation_response=partition['evaluation_response'],
                    selection_horizon_months=12)
                row.pop('ibs_0_24')
                row['ibs_0_12'] = metric['ibs_0_12']
            results.append(row)
        return results

    original_lock = kernel._coxtime_global_epoch_lock
    def lock(curves):
        assert len(curves) == 15 and all(len(partition) == 20 for partition in curves)
        value = original_lock(curves)
        assert len(set(value["partition_optima"])) > 1
        locks.append(value)
        return value
    monkeypatch.setattr(kernel, "_coxtime_global_epoch_lock", lock)
    for name, function in (("_run_python_stop_pair_pool_task", stop_pair),
                           ("_run_r_prediction_pool_task", r_batch)):
        function.__name__ = name
        monkeypatch.setattr(kernel, name, function)
    def xgb(task):
        return refit(task)
    def coxtime(task):
        return refit(task)
    for name, function in (("_run_xgb_refit_pool_task", xgb), ("_run_coxtime_refit_pool_task", coxtime)):
        function.__name__ = name
        monkeypatch.setattr(kernel, name, function)
    monkeypatch.setattr(f5, "_bounded_ordered_spawn", _serial_pool)
    monkeypatch.setattr(kernel, "_bounded_ordered_spawn", _serial_pool)
    return events, locks


@contextmanager
def _six_shard_batches(monkeypatch, owner, policy, evidence, *, stop_after=None, prepared_full0=False):
    """Drive exact native batch boundaries; never replace a funnel or chooser."""
    original = f5._q_search_task_batch
    workers = [owner.parent / (owner.name + f"-worker-{i}") for i in range(6)]
    history = []
    def dispatch(spec, function, tasks):
        control = spec["native_search_batch"]
        assert control["task_ids"] is None
        try:
            return original(spec, function, tasks)
        except f5._QBatchBoundary as boundary:
            assert boundary.result["status"] == "PREPARED_Q_BATCH"
            if stop_after is not None and len(evidence) >= stop_after:
                raise
            ids = boundary.result["task_ids"]
        phase = len(evidence)
        current = []
        # The 350-patient GBM fixture retains three 5000-point binary64
        # risk matrices. Its real pre-fit capacity guard must remain active.
        retained_bytes = (64 if spec["family"] == "GBM_COX" else 4) * 1024**2
        immutable = [task[0]["spec"] if function is kernel._run_python_stop_pair_pool_task else
                     task[0] if function is kernel._run_r_prediction_pool_task else task["spec"] for task in tasks]
        before = [dict(item) for item in immutable]
        if prepared_full0:
            assert spec['execution_scope'] == 'F5_FULL_DEVELOPMENT_SEARCH'
            assert spec['family'] in {'GBM_COX', 'XGBOOST_COX', 'COXTIME_SET_A'}
            publication = owner.parent / f'{owner.name}-phase-{phase}-publication'
            publication.mkdir()
            shutil.copyfile(owner / 'input.json', publication / 'input.json')
            outputs = [[str(owner.parent / f'{owner.name}-phase-{phase}-input-{i}.zip'), *ids[i::6]]
                       for i in range(6)]
            f5._publish_a12_q_stop_inputs(function, f5._q_search_units(function, tasks), publication,
                {**control, 'q_unit_outputs': outputs, 'retained_bytes_per_task': retained_bytes},
                boundary_phase(function, ids), {'sha256': sha256_file(owner / 'input.json'),
                                              'size_bytes': (owner / 'input.json').stat().st_size})
        for index, worker in enumerate(workers):
            if not prepared_full0 and not worker.exists():
                (worker / "native").mkdir(parents=True)
                shutil.copyfile(owner / "input.json", worker / "input.json")
            assigned = ids[index::6]
            assert assigned
            destination = owner.parent / f"{owner.name}-phase-{phase}-worker-{index}"
            if prepared_full0:
                payload = Path(outputs[index][0])
                result = f5.execute_final_complex_search(candidate_family=spec['family'],
                    selection_horizon_months=spec.get('selection_horizon_months', 24),
                    target=worker.with_name(worker.name + f'-phase-{phase}'), task_ids=assigned,
                    batch_root=destination, retained_bytes_per_task=retained_bytes,
                    prepared_q_input=payload, prepared_q_input_sha256=sha256_file(payload))
            else:
                own_control = f5._q_search_batch_control(worker, policy,
                    _options(ids=assigned, destination=destination, retained_bytes=retained_bytes))
                own = {**spec, "native_search_root": str(worker / "native"), "native_search_batch": own_control}
                with pytest.raises(f5._QBatchBoundary) as computed:
                    original(own, function, tasks)
                result = computed.value.result
            assert result["status"] == "COMPUTED_Q_BATCH"
            execution = result["execution"]
            assert execution["task_ids"] == assigned and execution["pool"]["actual_worker_process_peak"] == 1
            current.append((destination, execution))
        assert immutable == before  # stripping is a projection, never input mutation
        control["batches"].extend(current[:-1])
        with pytest.raises(ContractError, match="COMPLETE_COORDINATES_REQUIRED|COMMON_PREFIX_COVERAGE_INVALID"):
            original(spec, function, tasks)
        control["batches"].append(current[-1])
        rows = original(spec, function, tasks)
        history.extend(path for path, _ in current)
        evidence.append({"phase": boundary_phase(function, ids), "unit_count": len(ids),
                         "task_ids": ids, "shards": [row["task_ids"] for _, row in current],
                         "first_audits": sum(row["confirmed_first_native_audit_count"] for _, row in current)})
        assert control["used_batches"] and len(rows) == len(tasks)
        return rows
    with monkeypatch.context() as current:
        current.setattr(f5, "_q_search_task_batch", dispatch)
        yield history


def boundary_phase(function, ids):
    return function.__name__ + "-" + sha256_bytes(canonical_json_bytes(ids))[:24]


def _assert_funnel(result, phases, events, locks):
    family = result["family"]
    assert tuple(result["search_trace"]) == _STAGES
    assert tuple(len(result["search_trace"][key]) for key in _STAGES) == _COUNTS[family]
    for stage, units, repeats in zip(_STAGES, (5, 25, 100, 75, 300), (1, 1, 1, 3, 3), strict=True):
        for trial in result["search_trace"][stage]:
            assert trial["evaluation_units"] == units and len(trial["metric_values"]) == units
            assert len(trial["ranking_metric_values"]) == repeats
            assert trial["mean_ibs"] == math.fsum(trial["ranking_metric_values"]) / repeats
    count = sum(n * units for n, units in zip(_COUNTS[family], (5, 25, 100, 75, 300), strict=True))
    assert result["search_evaluation_unit_count"] == result["locked_training_refit_count"] == count
    assert result["total_search_fit_count"] == count * (1 if family == "RSF" else 2)
    assert result["heldout_or_ooc_read_count"] == result["final_model_fit_count"] == 0
    assert len(phases) == (5 if family == "RSF" else 10)
    assert sum(row["first_audits"] for row in phases) == result["total_search_fit_count"]
    if family == "COXTIME_SET_A":
        assert locks and result["selected_spec"]["locked_epoch"] == locks[-1]["locked_epoch"]
        assert phases[-2]["unit_count"] == phases[-1]["unit_count"] == 300
        assert result["search_trace"]["S3B2"][0]["validation_curve_count"] == 300
    produced = [path for mode, path, _ in events if mode == "produce"]
    assert len(produced) == len(set(produced))


@pytest.mark.parametrize("family", list(_COUNTS))
@pytest.mark.parametrize("execution_mode", ["six_shards", "continuous"])
def test_full0_original_five_stage_funnel_six_shards_and_complete_numeric_owner(
        full_inputs, unfitted_selector_consumers, tmp_path, monkeypatch, family, execution_mode):
    # A real fold scorer needs >=30 evaluable patients; the tiny 140-person
    # plumbing fixture has only 28 per fold, so use 350 synthetic patients.
    inputs = ([f"p{i:03d}" for i in range(350)],
              [center for center in (36, 38, 39, 48, 52, 54, 55) for _ in range(50)],
              [int(i < 140 and i % 2 == 1) for i in range(350)])
    plan, parts, full = _physical_full_inputs(inputs, tmp_path / "physical", complete_covariates=True)
    selector = tmp_path / "selector"
    f5._nested_full_selector_program(plan, parts, full, selector, rscript="UNFITTED", replay=False)
    monkeypatch.setattr(runtime, "effective_cpu_count", lambda: 32)
    monkeypatch.setattr(runtime, "observe_execution_resources", _OBSERVE)
    mice, full_path = tmp_path / "mice", tmp_path / "full.zip"
    mice.mkdir()
    (mice / "UNFITTED.zip").write_bytes(b"UNFITTED_MICE_BOUNDARY")
    full_path.write_bytes(b"UNFITTED_FULL_MICE_BOUNDARY")
    response = Path(full["fit_response"]["path"]).read_bytes()
    selected_parts = ([{key: value for key, value in part.items() if key != "stopping"} for part in parts]
                      if family == "RSF" else parts)
    monkeypatch.setattr(f5, "_final_search_mice_members", lambda plan, root, **kwargs: {
        "UNFITTED.zip": root / "UNFITTED.zip"})
    def physical(plan_value, root, response_value, destination, **kwargs):
        assert plan_value == plan and response_value == response
        return selected_parts
    def whole(plan_value, source, response_value, destination, **kwargs):
        assert plan_value == plan and source.read_bytes() == full_path.read_bytes() and response_value == response
        return full
    monkeypatch.setattr(f5, "_materialize_final_search_inputs", physical)
    monkeypatch.setattr(f5, "materialize_final_full_data_mice", whole)
    monkeypatch.setattr(f5, "_validate_final_search_plan", lambda *args, **kwargs: full["development_input"])
    @contextmanager
    def materialized(path, scratch_parent, **kwargs):
        assert scratch_parent == path.parent
        yield json.loads(path.read_bytes()), selected_parts, full
    monkeypatch.setattr(f5, "_materialized_full_data_development_sources", materialized)
    (tmp_path / "search").mkdir()
    sources = {"plan": plan, "mice_root": str(mice), "final_mice_path": str(full_path),
        "response_path": full["fit_response"]["path"], "selector_root": str(selector),
        "search_roots": {name: str(tmp_path / "search" / name) for name in _COUNTS},
        "science_decision": _unfitted_confirmed_decision(fixed_bootstrap=True),
        "rscript": "UNFITTED", "resource_policy": _POLICY}
    source, archive_path = tmp_path / "development.json", tmp_path / "search.zip"
    source.write_bytes(canonical_json_bytes(sources))
    events, locks = _unfitted_leaves(monkeypatch, gbm_loss_fixture=family == "GBM_COX")
    owner, phases = Path(sources["search_roots"][family]), []
    arguments = {"full_development_path": source, "candidate_family": family, "target": archive_path,
                 "prepare_only": True}
    ready = f5.execute_final_complex_search(**arguments)
    assert ready["status"] == "PREPARED_Q_BATCH" and not events and not archive_path.exists()
    # Re-enter the public owner after one actual complete batch, then supply
    # its retained history on the next call. No hand-built trace or resume state.
    with _six_shard_batches(monkeypatch, owner, _POLICY, phases, stop_after=1) as history:
        next_batch = f5.execute_final_complex_search(**arguments)
    assert next_batch["status"] == "PREPARED_Q_BATCH" and next_batch["phase"] != ready["phase"]
    assert len(history) == 6 and not archive_path.exists()
    if execution_mode == "six_shards":
        with _six_shard_batches(monkeypatch, owner, _POLICY, phases):
            computed = f5.execute_final_complex_search(**arguments, q_batches=history)
    else:
        # Keep the public owner, complete original funnel and numerical
        # consumers; only the existing scientific leaf adapters are UNFITTED.
        batch_owner = tmp_path / "continuous-batches"
        batch_owner.mkdir()
        original_control = f5._q_search_batch_control
        controls = []
        def observe_control(*args, **kwargs):
            value = original_control(*args, **kwargs)
            controls.append(value)
            return value
        with monkeypatch.context() as patch:
            patch.setattr(f5, "_q_search_batch_control", observe_control)
            computed = f5.execute_final_complex_search(**{**arguments, "prepare_only": False},
                q_batches=history, continuous_batch_root=batch_owner,
                retained_bytes_per_task=(64 if family == "GBM_COX" else 4) * 1024**2)
        assert len(controls) == 1
        control = controls[0]
        assert control["prepare_only"] is True and control["task_ids"] is control["batch_root"] is None
        for path, row in control["batches"]:
            if path in history:
                continue
            assert path.parent == batch_owner
            assert (path / "execution.json").read_bytes() == canonical_json_bytes(row)
            phases.append({"phase": row["phase"], "unit_count": len(row["task_ids"]),
                "first_audits": row["confirmed_first_native_audit_count"]})
    assert computed["status"] == "COMPUTED"
    archive = computed["execution_archive"]
    result, task = archive["result"], archive["task"]
    _assert_funnel(result, phases, events, locks)
    members, refs = compact._full_pipeline_q_numerical_members(owner)
    assert "execution.json" in members and refs and not any(name.endswith("model.bin") for name in members)
    if execution_mode == "six_shards":
        assert not list(owner.rglob("model.bin"))
    else:
        # A full-context host also owns the native producer. Retaining its
        # objects is legal; the original numerical transport must omit them.
        assert list(owner.rglob("model.bin"))
    native_before = [(mode, path) for mode, path, _ in events if mode != "numbers"]
    assert f5._final_complex_search_program(task, parts, owner, replay=True,
        resource_policy=_POLICY) == result
    assert f5.read_final_complex_search(archive_path, rscript="UNFITTED") == archive
    assert [(mode, path) for mode, path, _ in events if mode != "numbers"] == native_before
    (tmp_path / "q-funnel-observation.json").write_bytes(canonical_json_bytes({
        "family": family, "scope": "FULL0", "phases": phases, "result": result,
        "model_fits": 0, "leaf_adapter": "UNFITTED", "original_five_stage_funnel": True,
        "normal_native_object_opens": 0, "complete_ledger_sha256": sha256_file(owner / "execution.json")}))


def test_retained_rsf24_f2_pair_keeps_entire_funnel_and_four_model_geometry(
        full_inputs, unfitted_selector_consumers, tmp_path, monkeypatch):
    """Original old/new F2 arithmetic; synthetic leaves are not native/R proof."""
    import copy
    import importlib.util
    import os
    import sys
    import zipfile
    from collections import Counter
    from padml import f4

    bundle = os.environ.get("PADML_RETAINED_FULL0_SOURCE_BUNDLE")
    if bundle is None:
        pytest.skip("exact retained code-only source required")
    retained = f4._retained_full0_source_members(Path(bundle), full0_rsf_q=True)
    assert retained["padml/f2_kernel.py"] == "54dac91205d59d10f677d254350921b06a09a1be1a431e6d87c47c273b20eebd"
    assert sha256_file(Path(kernel.__file__)) == "3da5dd96a13b7294087ea53655eca62a096095d782ec9d36cf06c27cdc7a62aa"
    old_path = tmp_path / "retained-f2.py"
    with zipfile.ZipFile(bundle) as archive:
        old_path.write_bytes(archive.read("padml/f2_kernel.py"))
    assert sha256_file(old_path) == retained["padml/f2_kernel.py"]
    module_spec = importlib.util.spec_from_file_location("padml._f2_rsf1513", old_path)
    old = importlib.util.module_from_spec(module_spec)
    monkeypatch.setitem(sys.modules, module_spec.name, old)
    module_spec.loader.exec_module(old)
    assert old._run_r_registered_rsf.__globals__ is vars(old)
    assert kernel._run_r_registered_rsf.__globals__ is vars(kernel)
    assert old._evaluate_prediction_seal is not kernel._evaluate_prediction_seal

    inputs = ([f"p{i:03d}" for i in range(350)],
              [center for center in (36, 38, 39, 48, 52, 54, 55) for _ in range(50)],
              [int(i < 140 and i % 2 == 1) for i in range(350)])
    plan, parts, full = _physical_full_inputs(inputs, tmp_path / "physical", complete_covariates=True)
    selector = tmp_path / "selector"
    f5._nested_full_selector_program(plan, parts, full, selector, rscript="UNFITTED", replay=False)
    parts = [{key: value for key, value in part.items() if key != "stopping"} for part in parts]
    task = f5.compile_nested_full_complex_search_task(plan, parts, full, selector, family="RSF",
        rscript="UNFITTED", resource_policy=_POLICY)
    registered = f5._complex_runtime_registered_inputs(task, parts)
    spec = f5._complex_search_execution_spec(task, registered)
    # The fixture explicitly represents the retained producer's 56 geometry;
    # the actual H9 test is one admitted serial process, not 56 workers.
    spec.update(threads=56, pool_workers=56)
    spec["final_search_source"]["producer_execution"] = {
        key: spec[key] for key in ("execution_mode", "threads", "pool_workers", "engine_threads")}
    input_path = tmp_path / "input.json"
    raw = canonical_json_bytes({"kind": "PADML_F5_Q_INPUT_V1", "task": task, "spec": spec})
    input_path.write_bytes(raw)
    tracked = ("_evaluate_prediction_seal", "_pool_prediction_batch", "_trial_summary_from_pooled",
               "_tree_s3a_candidates", "_rank_trials", "_shared_full_development_search_result")
    outputs, captured, reached = [], [], []
    repo_root = Path(f5.__file__).parent
    def byte_snapshot(value):
        # Preserve raw synthetic response bytes exactly, not merely a digest.
        if isinstance(value, bytes):
            return {"__fixture_bytes_hex__": value.hex()}
        if isinstance(value, dict):
            assert "__fixture_bytes_hex__" not in value
            return {key: byte_snapshot(item) for key, item in value.items()}
        if isinstance(value, (list, tuple)):
            return [byte_snapshot(item) for item in value]
        return value
    for label, module, other in (("retained", old, kernel), ("current", kernel, old)):
        directory = tmp_path / label
        (directory / "native").mkdir(parents=True)
        own_spec = {**copy.deepcopy(spec), "native_search_root": str(directory / "native"),
                    "native_search_replay": False, "active_worker_limit": 24}
        records, counts = [], Counter()
        with monkeypatch.context() as patch:
            events, locks = _unfitted_leaves(patch, kernel_module=module)
            def wrong_module(*args, **kwargs):
                pytest.fail("paired reader crossed into the other F2 module")
            for name in tracked:
                original = getattr(module, name)
                assert original.__globals__ is vars(module)
                def trace(*args, _original=original, _name=name, **kwargs):
                    counts[_name] += 1
                    return _original(*args, **kwargs)
                patch.setattr(module, name, trace)
                patch.setattr(other, name, wrong_module)
            def pool(function, calls, *, selected_slots):
                assert selected_slots == 24 and function is module._run_r_prediction_pool_task
                for call in calls:
                    child, registered_part, tasks, scratch, repo, mode, partition = call
                    assert repo == str(repo_root) and scratch == str(directory)
                    assert child["native_search_root"] == str(directory / "native")
                    assert "native_search_batch" not in child and "a12_source" not in child
                    records.append(byte_snapshot({"spec": {key: value for key, value in child.items() if key != "native_search_root"},
                        "registered": registered_part, "tasks": tasks, "mode": mode, "partition": partition}))
                return _serial_pool(function, calls, selected_slots=selected_slots)
            patch.setattr(module, "_bounded_ordered_spawn", pool)
            outputs.append(module._run_r_registered_rsf(own_spec, copy.deepcopy(registered), directory,
                                                       repo_root, search_only=True))
            assert not locks and all(mode == "produce" for mode, _, _ in events)
        assert set(counts) == set(tracked) and all(counts[name] > 0 for name in tracked)
        captured.append(records)
        reached.append(dict(counts))
    assert input_path.read_bytes() == raw
    assert canonical_json_bytes(outputs[0]) == canonical_json_bytes(outputs[1])
    assert canonical_json_bytes(captured[0]) == canonical_json_bytes(captured[1])
    assert reached[0] == reached[1]
    geometry = {stage: Counter(len(row["tasks"]) for row in captured[0]
        if row["tasks"][0]["task_id"].startswith(stage + "_")) for stage in _STAGES}
    assert geometry == {"S1": {2: 60}, "S2": {3: 50, 2: 25}, "S3A": {3: 100},
                        "S3B1": {2: 75}, "S3B2": {4: 75}}
    result = outputs[1]
    assert tuple(result["search_trace"]) == _STAGES
    assert tuple(len(result["search_trace"][stage]) for stage in _STAGES) == _COUNTS["RSF"]
    assert result["total_search_fit_count"] == result["search_evaluation_unit_count"] == 1070
    assert result["response_free_stopping_fit_count"] == result["final_model_fit_count"] == 0

    # Both negatives stop in S1, not a second five-stage execution.
    class BeforeLeaves(Exception):
        pass
    wrong_geometry = []
    def geometry_only(function, calls, *, selected_slots):
        wrong_geometry.extend([[task["task_id"] for task in call[2]] for call in calls])
        raise BeforeLeaves
    with monkeypatch.context() as patch:
        patch.setattr(kernel, "_bounded_ordered_spawn", geometry_only)
        drift = {**spec, "threads": 24, "pool_workers": 24, "active_worker_limit": 24,
                 "native_search_root": str(tmp_path / "wrong-geometry"), "native_search_replay": False}
        with pytest.raises(BeforeLeaves):
            kernel._run_r_registered_rsf(drift, copy.deepcopy(registered), tmp_path, repo_root, search_only=True)
    original_geometry = [[task["task_id"] for task in row["tasks"]] for row in captured[0]
                         if row["tasks"][0]["task_id"].startswith("S1_")]
    assert wrong_geometry != original_geometry
    directory = tmp_path / "missing-mi"
    (directory / "native").mkdir(parents=True)
    with monkeypatch.context() as patch:
        _unfitted_leaves(patch, kernel_module=kernel)
        def missing(function, calls, *, selected_slots):
            return [function(calls[0])[:-1]]
        patch.setattr(kernel, "_bounded_ordered_spawn", missing)
        missing_spec = {**spec, "active_worker_limit": 24, "native_search_root": str(directory / "native"),
                        "native_search_replay": False}
        with pytest.raises(ContractError, match="F2_R_PRODUCER_RESULT_INVALID"):
            kernel._run_r_registered_rsf(missing_spec, copy.deepcopy(registered), directory, repo_root, search_only=True)
    (tmp_path / "retained-rsf24-f2-pair.json").write_bytes(canonical_json_bytes({
        "fixture": "UNFITTED_SHARED_INPUT_OLD_AND_NEW_F2", "input_sha256": sha256_bytes(raw),
        "old_source_sha256": retained["padml/f2_kernel.py"], "new_source_sha256": sha256_file(Path(kernel.__file__)),
        "old_result": outputs[0], "new_result": outputs[1], "calls": captured[0], "reached": reached,
        "negative_cases": ["other_module_fail_fast", "producer_geometry_24", "missing_mi"],
        "new_model_fits": 0, "native_r_qualification": False}))


@pytest.mark.parametrize("unfitted_redevelopment_inputs", ["COXTIME_SET_A"], indirect=True)
@pytest.mark.parametrize("failure", [None, "source_conflict", "partial_owner"])
def test_aar_owner_mixed_prefixes_reach_original_m20_input_consumer(
        unfitted_redevelopment_inputs, unfitted_selector_engines, tmp_path, monkeypatch, failure):
    prepared = unfitted_redevelopment_inputs
    for branch in nested.AAR_ESTIMANDS:
        prepared = sensitivity._a12_projected_development_inputs(
            prepared, tmp_path / "development", replay=False, branch=branch)
    monkeypatch.setattr(runtime, "effective_cpu_count", lambda: 32)
    monkeypatch.setattr(runtime, "observe_execution_resources", _OBSERVE)
    events, _ = _unfitted_leaves(monkeypatch)
    complete_branch, prefix_branch, fresh_branch = nested.AAR_ESTIMANDS
    complete_root, prefix_root = tmp_path / "complete", tmp_path / "prefix"
    policy = prepared["source"]["resource_policy"]
    with _six_shard_batches(monkeypatch, complete_root, policy, []) as complete_batches:
        complete = sensitivity._a12_complex_search_program(prepared, complete_branch,
            complete_root, replay=False, batch_options=_options())
    with _six_shard_batches(monkeypatch, prefix_root, policy, [], stop_after=1) as prefix_batches:
        boundary = sensitivity._a12_complex_search_program(prepared, prefix_branch,
            prefix_root, replay=False, batch_options=_options())
    assert boundary["status"] == "PREPARED_Q_BATCH" and len(prefix_batches) == 6
    before = [(mode, path) for mode, path, _ in events if mode != "numbers"]
    original = (complete_root / "input.json").read_bytes()
    if failure == "source_conflict":
        changed = json.loads(original)
        changed["spec"]["a12_source"]["outer_fold"] = 6 if prepared["outer_fold"] != 6 else 5
        (complete_root / "input.json").write_bytes(canonical_json_bytes(changed))
    owner, batches = tmp_path / "outer-owner", tmp_path / "owned-batches"
    owner.mkdir()
    batches.mkdir()
    if failure == "partial_owner":
        partial = batches / prefix_branch
        partial.mkdir()
        (partial / "UNFITTED-failure-evidence").write_bytes(b"preserve")
    def consume():
        return sensitivity._a12_outer_searches(prepared, owner, replay=False,
            q_roots={complete_branch: complete_root},
            q_batches={prefix_branch: prefix_batches, fresh_branch: []},
            continuous_batch_root=batches, retained_bytes_per_task=4 * 1024**2)
    if failure:
        with pytest.raises(ContractError):
            consume()
        assert [(mode, path) for mode, path, _ in events if mode != "numbers"] == before
        if failure == "partial_owner":
            assert (batches / prefix_branch / "UNFITTED-failure-evidence").read_bytes() == b"preserve"
        return
    searches = consume()
    assert searches[complete_branch] == complete
    assert not (batches / complete_branch).exists()
    produced = [path for mode, path, _ in events if mode == "produce"]
    assert len(produced) == len(set(produced))
    assert (complete_root / "input.json").read_bytes() == original
    # Original direct M20 input consumer, not fabricated final-model receipts.
    jobs = sensitivity._a12_outer_model_jobs(prepared, searches)
    assert len(jobs) == len({job["name"] for job in jobs}) == 60
    for job in jobs:
        task = json.loads(job["entries"]["task.json"])
        branch = task["a12_coordinates"]["branch"]
        assert task["parameters"] == searches[branch]["selected_spec"]
        assert task["nested_aar_final_source"]["parameter_source_sha256"] == kernel._sha(searches[branch])
    after = [(mode, path) for mode, path, _ in events if mode != "numbers"]
    for branch in nested.AAR_ESTIMANDS:
        assert sensitivity._a12_complex_search_program(prepared, branch, owner / "search" / branch,
            replay=True) == searches[branch]
    assert [(mode, path) for mode, path, _ in events if mode != "numbers"] == after


@pytest.mark.parametrize("unfitted_redevelopment_inputs", ["COXTIME_SET_A"], indirect=True)
@pytest.mark.parametrize("execution_mode", ["six_shards", "continuous"])
def test_three_aar_original_funnels_feed_their_own_m20_jobs(
        unfitted_redevelopment_inputs, unfitted_selector_engines, tmp_path, monkeypatch, execution_mode):
    prepared = unfitted_redevelopment_inputs
    development = tmp_path / "development"
    for branch in nested.AAR_ESTIMANDS:
        prepared = sensitivity._a12_projected_development_inputs(prepared, development, replay=False, branch=branch)
    monkeypatch.setattr(runtime, "effective_cpu_count", lambda: 32)
    monkeypatch.setattr(runtime, "observe_execution_resources", _OBSERVE)
    events, locks = _unfitted_leaves(monkeypatch)
    searches, roots, observations = {}, {}, []
    for index, branch in enumerate(nested.AAR_ESTIMANDS):
        owner, phases = tmp_path / f"q-{index}", []
        policy = prepared["source"]["resource_policy"]
        if execution_mode == "six_shards":
            with _six_shard_batches(monkeypatch, owner, policy, phases):
                result = sensitivity._a12_complex_search_program(prepared, branch, owner, replay=False,
                                                                  batch_options=_options())
        else:
            batches = tmp_path / f"continuous-batches-{index}"
            batches.mkdir()
            original_execute = f5._execute_q_search_batch
            def observe_execute(*args, **kwargs):
                row = original_execute(*args, **kwargs)
                phases.append({"phase": row["phase"], "unit_count": len(row["task_ids"]),
                    "first_audits": row["confirmed_first_native_audit_count"]})
                return row
            with monkeypatch.context() as patch:
                patch.setattr(f5, "_execute_q_search_batch", observe_execute)
                result = sensitivity._a12_complex_search_program(prepared, branch, owner, replay=False,
                    batch_options={**_options(history=[]), "retained_bytes_per_task": 4 * 1024**2},
                    continuous_batch_root=batches)
        _assert_funnel(result, phases, events, locks)
        assert result["a12_source"] == sensitivity._a12_search_source(prepared, branch)
        searches[branch], roots[branch] = result, owner
        observations.append({"branch": branch, "phases": phases, "result": result})
    before = [(mode, path) for mode, path, _ in events if mode != "numbers"]
    destination = tmp_path / "final-owner"
    destination.mkdir()
    consumed = sensitivity._a12_outer_searches(prepared, destination, replay=False, q_roots=roots)
    assert consumed == searches
    assert [(mode, path) for mode, path, _ in events if mode != "numbers"] == before
    jobs = sensitivity._a12_outer_model_jobs(prepared, consumed)
    assert len(jobs) == 60 and len({row["name"] for row in jobs}) == 60
    for job in jobs:
        task = json.loads(job["entries"]["task.json"])
        branch = task["a12_coordinates"]["branch"]
        assert task["parameters"] == searches[branch]["selected_spec"]
        assert task["nested_aar_final_source"]["parameter_source_sha256"] == kernel._sha(searches[branch])
        assert task["selected_parents"] == (["Sex"] if branch == nested.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT else ["Age"])
    (tmp_path / "q-funnel-observation.json").write_bytes(canonical_json_bytes({
        "scope": "THREE_AAR", "observations": observations, "final_job_count": len(jobs),
        "model_fits": 0, "leaf_adapter": "UNFITTED", "original_five_stage_funnel": True,
        "normal_native_object_opens": 0}))
