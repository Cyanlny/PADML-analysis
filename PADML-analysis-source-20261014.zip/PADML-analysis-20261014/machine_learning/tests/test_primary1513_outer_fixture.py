"""Real retained code provenance, synthetic inputs, UNFITTED model leaves.

Only Linux may run this fixture. It is not evidence of clinical F1/F2
acceptance. The existing synthetic accepted-source seam supplies its two
consistent pins; the retained-code and archive/numerical readers stay real.
"""
import os
from pathlib import Path
import subprocess
import sys
import zipfile

import pytest

from padml import f4, f5, nested_loco as nested, runtime
from padml.bundle import canonical_json_bytes, extract_safe_zip, sha256_file, strict_json_bytes
from test_nested_outer_f4 import _projection, _unfitted_engines
from test_nested_aar_mice import aar_source  # noqa: F401


PRIMARY1513 = "1513ecba963857099c6b99413b8e976393c551a3ec30ed90da1cb14178338bd7"


def _capacity(monkeypatch):
    monkeypatch.setattr(runtime, "effective_cpu_count", lambda: 64)
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda root: {
        "effective_cpus": 64, "available_memory_bytes": 10**12,
        "scratch_available_bytes": 10**12, "scratch_root": str(root)})


def test_primary1513_producer_child(tmp_path, monkeypatch, request):
    value = os.environ.get("PADML_UNFITTED_1513_OUTPUT")
    if value is None:
        pytest.skip("private child of the original-code fixture")
    assert sys.platform.startswith("linux")
    # Imported under the actual unpacked source, not a patched identity.
    assert nested._sha(f4._f45_source_member_sha256()) == PRIMARY1513
    root = Path(value)
    assert root.is_absolute() and root.is_dir()
    _capacity(monkeypatch)
    actual_projection = os.environ.get("PADML_UNFITTED_1513_ACTUAL_PROJECTION") == "1"
    if actual_projection:
        from test_primary_rsf_score_compilation import _actual_primary_outer_source
        source_fixture = request.getfixturevalue("aar_source")
        # The lazy fixture installs its own 10 GB synthetic observation.
        # Restore this complete-owner fixture's capacity before compilation;
        # the original 1513 guard reserves all 2100 retained components.
        _capacity(monkeypatch)
        with monkeypatch.context() as prepare:
            frozen, _, _, projection = _actual_primary_outer_source(source_fixture, root, prepare)
            source_loader, materializer = f4.load_f4_inputs, f4._materialize_o_fit_fold
        monkeypatch.setattr(f4, "load_f4_inputs", source_loader)
        monkeypatch.setattr(f4, "_materialize_o_fit_fold", materializer)
    else:
        projection = _projection(root / "UNFITTED-projection", fresh_seven=True)
        monkeypatch.setattr(nested, "project_outer_development_from_accepted", lambda **kwargs: projection)
    assert projection["training_context"]["modeling_program_sha256"] == PRIMARY1513
    policy = {"configured_worker_ceiling": "EXECUTION_HOST_C_MINUS_8", "memory_bytes_per_worker": 1000,
              "scratch_bytes_per_worker": 1000, "memory_reserve_bytes": 100,
              "scratch_reserve_bytes": 100, "transfer_archive_worker_ceiling": 4}
    source = root / "input.zip"
    compiled = f4.compile_o_fit_bundle(root, source, outer_fold=1,
        science_decision=projection["science_decision"], resource_policy=policy,
        retained_bytes_per_component=10**7, expanded_bytes_per_component=10**6,
        shared_storage_bytes=10**9 if actual_projection else 10**8)
    calls = _unfitted_engines(monkeypatch)
    result = root / "result.zip"
    summary = f4.execute_o_fit_bundle(target=result, outer_fold=1, input_bundle=source)
    assert len(calls) == summary["model_fit_count"] == 2120
    assert sum(row[1]["purpose"] == "NESTED_OUTER" for row in calls) == 20
    (root / "fixture.json").write_bytes(canonical_json_bytes({
        "UNFITTED_SYNTHETIC_NOT_SCIENTIFIC_ACCEPTANCE": True,
        **({"actual_projection": True} if actual_projection else {}),
        "producer_source_identity": PRIMARY1513, "compiled": compiled,
        "input_sha256": sha256_file(source), "result_sha256": sha256_file(result)}))


@pytest.fixture
def real_primary1513_outer(tmp_path, monkeypatch, request):
    if not sys.platform.startswith("linux"):
        pytest.skip("original numerical fixture executes only on Linux")
    value = os.environ.get("PADML_PRIMARY_1513_SOURCE")
    if value is None:
        pytest.skip("exact primary1513 code-only ZIP is required")
    source = Path(value).resolve(strict=True)
    # Do not mock either this proof or the materializer's repeated proof.
    retained = f4._retained_full0_source_members(source, outer_fixed12_rescore=True)
    assert nested._sha(retained) == PRIMARY1513
    actual_projection = getattr(request, "param", False)
    assert type(actual_projection) is bool
    reuse = os.environ.get("PADML_UNFITTED_1513_ACTUAL_REUSE_ROOT" if actual_projection
                           else "PADML_UNFITTED_1513_REUSE_ROOT")
    if reuse is not None:
        # Explicit engineering-only exact reuse. A partial fixture fails;
        # it cannot fall through to another 2120-leaf production attempt.
        output = Path(reuse)
        assert output.is_absolute() and output.is_dir() and not output.is_symlink()
        assert output.resolve(strict=True) == output
    else:
        manifest = f4.load_f45_source_bundle(source)
        with zipfile.ZipFile(source) as archive:
            raw_manifest = archive.read("manifest.json")
        members = {row["path"]: {"sha256": row["sha256"], "size_bytes": row["size_bytes"]}
                   for row in manifest["members"]}
        members["manifest.json"] = {"sha256": nested.sha256_bytes(raw_manifest), "size_bytes": len(raw_manifest)}
        old_root = tmp_path / "retained-code"
        extract_safe_zip(source, old_root, expected_members=members,
                         max_member_bytes=8 * 1024**2, max_total_bytes=64 * 1024**2)
        output = tmp_path / "old-production"
        output.mkdir()
        env = dict(os.environ)
        env["PADML_UNFITTED_1513_OUTPUT"] = str(output)
        env["PADML_UNFITTED_1513_ACTUAL_PROJECTION"] = "1" if actual_projection else "0"
        env["PYTHONPATH"] = os.pathsep.join((str(old_root), str(Path(__file__).resolve().parent)))
        # The original pytest entry imports the actual old package. No second
        # scientific runner, implementation copy, or identity monkeypatch exists.
        completed = subprocess.run([sys.executable, "-B", "-m", "pytest", "-q", "-s",
            str(Path(__file__).resolve()) + "::test_primary1513_producer_child"],
            cwd=old_root, env=env, capture_output=True, text=True)
        assert completed.returncode == 0, completed.stdout + completed.stderr
    for name in ("fixture.json", "input.zip", "result.zip"):
        item = output / name
        assert item.is_file() and not item.is_symlink() and item.resolve(strict=True) == item
        assert item.stat().st_size > 0
    assert (output / "fixture.json").stat().st_size <= 32 * 1024**2
    raw = (output / "fixture.json").read_bytes()
    report = strict_json_bytes(raw)
    assert canonical_json_bytes(report) == raw
    assert report["UNFITTED_SYNTHETIC_NOT_SCIENTIFIC_ACCEPTANCE"] is True
    assert report["producer_source_identity"] == PRIMARY1513
    assert report.get("actual_projection", False) is actual_projection
    assert report["input_sha256"] == sha256_file(output / "input.zip")
    assert report["result_sha256"] == sha256_file(output / "result.zip")
    assert report["compiled"]["sha256"] == report["input_sha256"]
    assert report["compiled"]["size_bytes"] == (output / "input.zip").stat().st_size
    with zipfile.ZipFile(output / "input.zip") as archive:
        info = archive.getinfo("o-fit-input.json")
        assert info.file_size <= 32 * 1024**2
        declared = strict_json_bytes(archive.read(info))
    assert declared["training_context"]["modeling_program_sha256"] == PRIMARY1513
    assert declared["identity_sha256"] == report["compiled"]["identity_sha256"]
    _capacity(monkeypatch)
    # Reuse only the explicit clinical preparation seam from the existing
    # test. All producer proof, source ZIP, archive and numerical readers run.
    monkeypatch.setattr(f4, "_load_f4_source_records", lambda *args, **kwargs: {
        "source": {key: report["compiled"][key] for key in ("f1_identity", "f2_acceptance_sha256")}})
    return {"input_bundle": output / "input.zip", "retained_score_numbers": output / "result.zip",
            "compiled_input_record": report["compiled"], "retained_primary_source_bundle": source,
            "f2_run_root": output, "fixture_report": report}


def test_actual1513_fixed900_original_reader(real_primary1513_outer, tmp_path, monkeypatch):
    fixture = real_primary1513_outer
    _unfitted_engines(monkeypatch)
    def forbidden(*args, **kwargs):
        pytest.fail("existing fixed900 may not fit or replay a native model")
    monkeypatch.setattr(f5, "_execute_final_refit_engine", forbidden)
    monkeypatch.setattr(f5, "_validate_retained_model_objects", forbidden)
    monkeypatch.setattr(f4, "_replay_f4_model_component", forbidden)
    decision = nested._read_canonical(Path(__file__).resolve().parents[1] / "science-decision.json", "DECISION")
    result = f4._load_o_fit_execution_archive(fixture["retained_score_numbers"],
        input_bundle=fixture["input_bundle"], compiled_input_record=fixture["compiled_input_record"],
        f2_run_root=fixture["f2_run_root"], retained_primary_source_bundle=fixture["retained_primary_source_bundle"],
        rescore_fixed12_decision=decision, rescore_target=tmp_path / "fixed12.zip",
        replay_evidence=tmp_path / "fixed12-read")
    assert result["score_numerical_component_count"] == 900
    assert result["new_model_fits"] == result["new_model_native_verification_count"] == result["native_model_replay_count"] == 0
    assert sha256_file(fixture["input_bundle"]) == fixture["fixture_report"]["input_sha256"]
    assert sha256_file(fixture["retained_score_numbers"]) == fixture["fixture_report"]["result_sha256"]


def test_actual1513_fixed900_complete_primary_owner_and_archive_reader(
        real_primary1513_outer, tmp_path, monkeypatch, actual_source=None):
    """Real owner/score/archive/readback, synthetic F1/F2 and UNFITTED engines.

    Existing Q fixture uses synthetic complete trace arithmetic, but original
    Q result, parameter binding and compiled input consumers are not mocked.
    This tests the fixed900 suffix, not scientific acceptance of those Q fits.
    """
    from padml.bundle import read_safe_zip
    import test_nested_outer_f4 as outer_fixture
    from test_primary_rsf_score_compilation import (
        test_primary12_public_archive_preserves_q_through_original_input_reader as prepare_current)
    fixture = real_primary1513_outer
    preparation = tmp_path / "current-preparation"
    preparation.mkdir()
    projections = []
    original_projection = outer_fixture._projection
    def capture_projection(*args, **kwargs):
        value = original_projection(*args, **kwargs)
        # The generic OUTER fixture uses a placeholder recipe-owner digest.
        # A PRIMARY owner supplies source_bundles (even when empty), so its
        # original Q source guard requires the actual current producer pin.
        # Bind it before prepare_current constructs any source/Q/input seal;
        # never rewrite the completed old1513 fixture or bypass that guard.
        from padml.f2_kernel import predictor_contract
        producer = f4._f45_source_member_sha256()
        context = value["training_context"]
        value["training_context"] = nested._sealed({
            **{key: item for key, item in context.items() if key != "identity_sha256"},
            "preprocessing_program_sha256": nested._sha({
                "predictor_contract": predictor_contract(Path(f4.__file__).parent),
                "recipe_owner": producer["padml/f2_kernel.py"]})})
        projections.append(value)
        return value
    # The reused test performs the actual public compiler and input reader,
    # including the Q parameter checks and its wrong-horizon counterexample.
    with monkeypatch.context() as prepare:
        prepare.setattr(outer_fixture, "_projection", capture_projection)
        prepare_current(actual_source, preparation, prepare, actual_source is not None, None, False)
        if actual_source is not None:
            custody_loader, custody_materializer = f4.load_f4_inputs, f4._materialize_o_fit_fold
            with zipfile.ZipFile(preparation / "input12.zip") as archive:
                current = strict_json_bytes(archive.read("o-fit-input.json"))
            carrier = preparation / "pre-search.zip"
            f4.compile_o_fit_bundle(preparation, carrier, outer_fold=1,
                selection_horizon_months=12, pre_search=True,
                **{key: current[key] for key in ("science_decision", "resource_policy",
                    "retained_bytes_per_component", "expanded_bytes_per_component", "shared_storage_bytes")})
    with zipfile.ZipFile(preparation / "input12.zip") as archive:
        prepared = strict_json_bytes(archive.read("o-fit-input.json"))
    if actual_source is None:
        assert len(projections) == 1
        projected = projections[0]
        assert prepared["training_context"] == projected["training_context"]
    else:
        assert not projections and fixture["fixture_report"]["actual_projection"] is True
    bound = prepared["primary_searches"]
    roots = {family: preparation / ("UNFITTED-Q-" + family) for family in bound}
    # Explicit clinical preparation seam: never substitute source identity,
    # archive loaders, numerical scorers, parameter or source proof guards.
    if actual_source is None:
        monkeypatch.setattr(f4, "load_f4_inputs", lambda *args, **kwargs: {"UNFITTED_SYNTHETIC_F1_F2": True})
        monkeypatch.setattr(nested, "_project_outer_development_from_inputs", lambda *args, **kwargs: projected)
        monkeypatch.setattr(nested, "project_outer_development_from_accepted", lambda **kwargs: projected)
    else:
        def no_custody(*args, **kwargs):
            pytest.fail("SCOPED_OWNER_MUST_NOT_OPEN_COMPLETE_INPUT_CUSTODY")
        monkeypatch.setattr(f4, "load_f4_inputs", no_custody)
    calls = _unfitted_engines(monkeypatch)
    compiled = []
    original_compile = f4._compile_o_fit_bundle
    def compile_and_record(*args, **kwargs):
        value = original_compile(*args, **kwargs)
        compiled.append((args[1], value))
        return value
    monkeypatch.setattr(f4, "_compile_o_fit_bundle", compile_and_record)
    fixed = {key: fixture[key] for key in ("retained_score_numbers", "input_bundle",
        "compiled_input_record", "retained_primary_source_bundle")}
    fixed["rescore_call_limit"] = 1
    parameters = {key: prepared[key] for key in ("science_decision", "resource_policy",
        "retained_bytes_per_component", "expanded_bytes_per_component", "shared_storage_bytes")}
    parameters.update(search_roots=roots, search_source_bundles={}, pending_searches={}, outer_fixed12_context=fixed)
    target = tmp_path / "current-complete.zip"
    produced = f4.execute_o_fit_bundle(fixture["f2_run_root"] if actual_source is None else None,
        target=target, input_bundle=None if actual_source is None else carrier,
        outer_fold=1, primary_development=parameters)
    assert len(compiled) == 1
    current_input, current_record = compiled[0]
    assert produced["model_fit_count"] == len(calls) == 1220
    fresh = [family for family, coordinate in calls if coordinate["purpose"] == "O_FIT"]
    assert len(fresh) == 1200 and set(fresh) == set(bound)
    assert all(fresh.count(family) == 300 for family in bound)
    assert sum(coordinate["purpose"] == "NESTED_OUTER" for _, coordinate in calls) == 20
    archive = read_safe_zip(target)
    execution = strict_json_bytes(archive["o-fit-execution.json"])
    scores = strict_json_bytes(archive["o-fit-scores.json"])
    assert execution["model_fit_count"] == 2120
    assert len(scores["training_scores"]) == len(scores["fresh_score_execution"]) == 7
    fixed_executions = [row for row in scores["fresh_score_execution"] if row["family"] not in bound]
    assert len(fixed_executions) == 3
    assert all(row["model_fit_count"] == 300 and row["new_model_fit_count"] == 0
               and row["new_first_native_audit_count"] == 0 and row["new_native_replay_count"] == 0
               for row in fixed_executions)
    frozen = {path: sha256_file(path) for path in (target, current_input,
        fixture["input_bundle"], fixture["retained_score_numbers"], fixture["retained_primary_source_bundle"])}
    def forbidden(*args, **kwargs):
        pytest.fail("complete archive consumption cannot fit or replay native models")
    with monkeypatch.context() as read:
        if actual_source is not None:
            read.setattr(f4, "load_f4_inputs", custody_loader)
            read.setattr(f4, "_materialize_o_fit_fold", custody_materializer)
        read.setattr(f5, "_execute_final_refit_engine", forbidden)
        read.setattr(f5, "_validate_retained_model_objects", forbidden)
        read.setattr(f4, "_replay_f4_model_component", forbidden)
        read.setattr(runtime, "_bounded_ordered_spawn", forbidden)
        read.setattr(f4, "_bounded_ordered_spawn", forbidden)
        actual = f4.load_o_fit_execution_archive(target, input_bundle=current_input,
            compiled_input_record=current_record, f2_run_root=fixture["f2_run_root"],
            replay_evidence=tmp_path / "current-complete-read")
    assert actual == execution
    assert all(sha256_file(path) == digest for path, digest in frozen.items())
