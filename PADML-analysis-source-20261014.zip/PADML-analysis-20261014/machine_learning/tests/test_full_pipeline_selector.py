"""Full-pipeline selector input checks; no MICE, path or model is fitted."""
import copy
import csv
import io
from pathlib import Path

import pytest

from padml import f4
from padml.bundle import ContractError, canonical_json_bytes, strict_json_bytes
from padml.runtime import RSCRIPT_EXECUTABLE
from test_full_pipeline_mice_native import inputs


NATIVE_SUBPROCESS_RUN = f4.subprocess.run


@pytest.fixture(autouse=True)
def forbid_native(monkeypatch):
    def forbidden(*args, **kwargs):
        raise AssertionError("NO_NATIVE_FIT_OR_POOL")
    monkeypatch.setattr(f4.subprocess, "run", forbidden)
    monkeypatch.setattr(f4, "_run_learning_selector_path", forbidden)
    monkeypatch.setattr(f4, "_run_full_pipeline_mice_native", forbidden)
    monkeypatch.setattr(f4, "_bounded_ordered_spawn", forbidden)


@pytest.fixture
def materialized_context(inputs, tmp_path):
    tmp_path = tmp_path.resolve()
    plan, frozen = inputs
    context = f4._prepare_full_pipeline_mice_context(plan, 1, 1, frozen, tmp_path, rscript=RSCRIPT_EXECUTABLE)
    reader = csv.DictReader(io.StringIO(context["covariates_csv"].decode()))
    rows = {row["Patient_ID"]: row for row in reader}
    native = tmp_path / "UNFITTED_MICE_COMPLETIONS"
    native.mkdir()
    completed = {}
    for name, spec in context["mice_specs"].items():
        root = native / name
        root.mkdir()
        (root / "view.json").write_bytes(canonical_json_bytes({"UNFITTED": name}))
        completed[name] = []
        for imp in range(1, 21):
            path = root / f"imp{imp:02d}.csv"
            with path.open("x", newline="") as handle:
                writer = csv.DictWriter(handle, fieldnames=reader.fieldnames, lineterminator="\n")
                writer.writeheader()
                writer.writerows({**rows[patient], "Creatinine": str(imp if spec["view"]["role"] == "ANALYSIS" else 1000 + imp)}
                                 for patient in spec["view"]["row_ids"])
            completed[name].append(path)
    return {**context, "native_root": native, "completed": completed}


def test_analysis_training_application_holdout_and_all_twenty_inputs(materialized_context, tmp_path):
    partitions = f4._materialize_full_pipeline_selector_partitions(materialized_context, tmp_path.resolve() / "selector")
    assert len(partitions) == 16
    assert [(p["repeat"], p["inner_fold"]) for p in partitions] == [*[(r, k) for r in range(1, 4) for k in range(1, 6)], (0, 0)]
    clones = {row["clone_id"]: row["source_patient_id"] for row in materialized_context["clone_mapping"]}
    for partition in partitions:
        train = set(partition["fit_ids"])
        evaluation = set(partition["evaluation_ids"])
        if partition["inner_fold"]:
            assert train.isdisjoint(evaluation)
            assert {clones[p] for p in train}.isdisjoint({clones[p] for p in evaluation})
        else:
            assert train == evaluation
        for imp in range(1, 21):
            path = Path(partition["covariates"]["input_dir"]) / f"imp{imp:02d}.csv"
            reader = csv.DictReader(io.StringIO(path.read_text()))
            rows = list(reader)
            assert [row["Patient_ID"] for row in rows] == partition["application_ids"]
            assert not {"All_Cause_Death", "Death_Followup_months"} & set(reader.fieldnames)
            assert all(row["Creatinine"] == str(imp if row["Patient_ID"] in train else imp + 1000) for row in rows)
        for field, ids in [("fit_response", partition["fit_ids"]), ("evaluation_response", partition["evaluation_ids"])]:
            assert [row["Patient_ID"] for row in csv.DictReader(io.StringIO(Path(partition[field]["path"]).read_text()))] == ids


@pytest.mark.parametrize("damage", ["missing_m20", "split_overlap", "outer_context", "row_order"])
def test_selector_input_damage_stops_before_recipe_or_path(materialized_context, tmp_path, damage):
    context = copy.deepcopy(materialized_context)
    if damage == "missing_m20":
        context["completed"]["INNER_R1_K1_ANALYSIS"].pop()
    elif damage == "split_overlap":
        context["inner_partitions"][0]["validation_ids"][0] = context["inner_partitions"][0]["analysis_ids"][0]
    elif damage == "outer_context":
        context["source"]["context"] = 0
    else:
        context["mice_specs"]["INNER_R1_K1_ANALYSIS"]["view"]["row_ids"].reverse()
    with pytest.raises(ContractError, match="FULL_PIPELINE_SELECTOR_(M20_REQUIRED|PATIENT_SCOPE_INVALID|INPUT_INVALID|COMPLETED_ROWS_INVALID)"):
        f4._materialize_full_pipeline_selector_partitions(context, tmp_path.resolve() / "rejected")


def test_original_m20_recipe_projection_before_native_failure_retains_inputs(materialized_context, tmp_path, monkeypatch):
    target = tmp_path.resolve() / "selector"
    partitions = f4._materialize_full_pipeline_selector_partitions(materialized_context, target)
    calls = []
    def native_failure(command, **kwargs):
        calls.append(command)
        assert command[2] == "-e" and "f2_model_development.R" in command[3] and "dump.frames" in command[3]
        spec = strict_json_bytes(Path(command[4]).read_bytes())
        assert spec["action"] == "COMPILE_TRANSFORM_RECIPES" and spec["expected_count"] == 16
        assert len(spec["projections"]) == 16
        for projection, partition in zip(spec["projections"], partitions, strict=True):
            record = projection["recipe_registry_record"]
            assert record["fit_ids"] == partition["fit_ids"] and len(record["members"]) == 20
            for imp in range(1, 21):
                path = Path(record["input_dir"]) / f"imp{imp:02d}.csv"
                reader = csv.DictReader(io.StringIO(path.read_text()))
                rows = list(reader)
                assert [row["Patient_ID"] for row in rows] == partition["fit_ids"]
                assert not {"All_Cause_Death", "Death_Followup_months"} & set(reader.fieldnames)
                assert all(row["Creatinine"] == str(imp) for row in rows)
        kwargs["stdout"].write(b"INJECTED_RECIPE_PROCESS_FAILURE")
        raise RuntimeError("INJECTED_RECIPE_PROCESS_FAILURE")
    monkeypatch.setattr(f4.subprocess, "run", native_failure)
    root = target / "recipes"
    with pytest.raises(RuntimeError, match="INJECTED_RECIPE_PROCESS_FAILURE"):
        f4._compile_full_pipeline_selector_recipes(partitions, root, rscript=RSCRIPT_EXECUTABLE)
    assert len(calls) == 1 and (root / "spec.json").is_file()
    assert (root / "stdout.txt").read_bytes() == b"INJECTED_RECIPE_PROCESS_FAILURE"
    assert not (root / "recipes.json").exists()
    with pytest.raises(ContractError, match="RECIPES_INVALID"):
        f4._compile_full_pipeline_selector_recipes(partitions, root, rscript=RSCRIPT_EXECUTABLE)
    assert len(calls) == 1


def test_actual_r_recipe_admission_error_preserves_native_frames_without_fit(materialized_context, tmp_path, monkeypatch):
    target = tmp_path.resolve() / "selector"
    partitions = f4._materialize_full_pipeline_selector_partitions(materialized_context, target)
    calls = []
    def reject_before_any_recipe(command, **kwargs):
        # A real R process rejects an intentionally empty UNFITTED projection
        # list before lapply(fit_design_recipe), paths, models or RNG can run.
        path = Path(command[4])
        spec = strict_json_bytes(path.read_bytes())
        spec["projections"] = []
        path.write_bytes(canonical_json_bytes(spec))
        process = NATIVE_SUBPROCESS_RUN(command, **kwargs)
        calls.append(process.returncode)
        return process
    monkeypatch.setattr(f4.subprocess, "run", reject_before_any_recipe)
    root = target / "recipes"
    with pytest.raises(ContractError, match="RECIPE_NATIVE_FAILED"):
        f4._compile_full_pipeline_selector_recipes(partitions, root, rscript=RSCRIPT_EXECUTABLE)
    assert calls == [1]
    assert (root / "native-failure.rda").is_file() and (root / "native-failure.rda").stat().st_size > 0
    assert b"F2_RECIPE_COMPILE_DENOMINATOR_INVALID" in (root / "stderr.txt").read_bytes()
    assert not (root / "native-values.json").exists() and not (root / "recipes.json").exists()
