"""Direct six-selector SetA consumption with explicit UNFITTED native leaves."""
import copy
import csv
import io

import pytest

from padml import f4, f5
from padml.bundle import ContractError, canonical_json_bytes, sha256_file
from padml.runtime import RSCRIPT_EXECUTABLE
from test_f5 import final_seta_fixture
from test_full_pipeline_mice_native import inputs


@pytest.fixture(autouse=True)
def no_native(monkeypatch):
    def forbidden(*args, **kwargs):
        raise AssertionError("NO_NATIVE_FIT_OR_POOL")
    monkeypatch.setattr(f4.subprocess, "run", forbidden)
    monkeypatch.setattr(f4, "_replay_full_pipeline_selector", forbidden)
    monkeypatch.setattr(f4, "_run_learning_selector_path", forbidden)
    monkeypatch.setattr(f4, "_run_full_pipeline_mice_native", forbidden)
    monkeypatch.setattr(f4, "_bounded_ordered_spawn", forbidden)


@pytest.fixture
def native_boundary(inputs, tmp_path, monkeypatch):
    plan, frozen = inputs
    tmp_path = tmp_path.resolve()
    originals = final_seta_fixture()
    contexts, roots = {}, {}
    for fold in range(1, 7):
        contexts[fold] = f4._prepare_full_pipeline_mice_context(plan, 1, fold, frozen, tmp_path, rscript=RSCRIPT_EXECUTABLE)
        contexts[fold]["archive_identity_sha256"] = f"{fold:064x}"  # UNFITTED context transport fixture.
        roots[fold] = tmp_path / f"selector{fold}"
        roots[fold].mkdir()
        (roots[fold] / "selector.json").write_bytes(canonical_json_bytes({"UNFITTED": fold}))
    calls = []
    def unfitted_primary(context, root, *, rscript, retain_evidence):
        fold = context["source"]["context"]
        assert root == roots[fold] and rscript == RSCRIPT_EXECUTABLE and retain_evidence is False
        calls.append(fold)
        original = originals[fold - 1]
        primary = original["selector_evidence"]
        numeric = {key: primary[key] for key in (
            "selected_parents", "natural_frequency", "direction_diagnostic_flags", "selected_ratio_by_imputation")}
        numeric["alpha"] = primary["common_alpha"]
        record, = [row for row in original["search_trace"]["derivation_records"] if row["alpha"] == numeric["alpha"]]
        return {"source": context["source"], "selector": numeric}, record
    monkeypatch.setattr(f4, "_replay_full_pipeline_selector", unfitted_primary)
    return contexts, roots, originals, calls


def test_six_native_boundaries_use_original_math_and_clone_event_records(native_boundary):
    contexts, roots, originals, calls = native_boundary
    result = f4._compile_full_pipeline_seta(contexts, roots, rscript=RSCRIPT_EXECUTABLE)
    rows = {row["Patient_ID"]: row for row in csv.DictReader(io.StringIO(contexts[1]["response_csv"].decode()))}
    events = sum(int(row["All_Cause_Death"]) for row in rows.values())
    unique_event_patients = {row["source_patient_id"] for row in contexts[1]["clone_mapping"]
                             if int(rows[row["clone_id"]]["All_Cause_Death"])}
    assert events > len(unique_event_patients)
    original = f5.compile_final_seta(originals, events)
    assert calls == list(range(1, 7))
    assert result["kind"] == "PADML_F4_FULL_PIPELINE_SETA" and "status" not in result
    for key in ("fold_rows", "outer_frequency", "direction_consistency", "direction_excluded_parents", "lock", "lock_sha256"):
        assert result[key] == original[key]
    assert result["lock"]["full_data_event_count"] == events and result["model_fit_count"] == 0
    assert result["source_rows"] == [{"fold": fold, "mice_context_identity_sha256": contexts[fold]["archive_identity_sha256"],
                                       "selector_sha256": sha256_file(roots[fold] / "selector.json")} for fold in range(1, 7)]


@pytest.mark.parametrize("damage", ["missing_fold", "wrong_context", "wrong_replicate", "response_value", "clone_mapping"])
def test_source_drift_stops_before_any_native_primary(native_boundary, damage):
    contexts, roots, _, calls = native_boundary
    contexts = copy.deepcopy(contexts)
    if damage == "missing_fold":
        contexts.pop(6)
    elif damage == "wrong_context":
        contexts[6]["source"]["context"] = 5
    elif damage == "wrong_replicate":
        contexts[6]["source"]["bootstrap_replicate"] = 2
    elif damage == "response_value":
        contexts[6]["response_csv"] += b"\n"
    else:
        contexts[6]["clone_mapping"][0]["occurrence"] += 1
    with pytest.raises(ContractError, match="SETA_(CONTEXT_COVERAGE_INVALID|SOURCE_DRIFT)"):
        f4._compile_full_pipeline_seta(contexts, roots, rscript=RSCRIPT_EXECUTABLE)
    assert calls == []


def test_replayed_selector_must_match_its_actual_context(native_boundary, monkeypatch):
    contexts, roots, _, calls = native_boundary
    original = f4._replay_full_pipeline_selector
    def wrong_source(*args, **kwargs):
        result, record = original(*args, **kwargs)
        return {**result, "source": {**result["source"], "context": 2}}, record
    monkeypatch.setattr(f4, "_replay_full_pipeline_selector", wrong_source)
    with pytest.raises(ContractError, match="SETA_SOURCE_DRIFT"):
        f4._compile_full_pipeline_seta(contexts, roots, rscript=RSCRIPT_EXECUTABLE)
    assert calls == [1]
