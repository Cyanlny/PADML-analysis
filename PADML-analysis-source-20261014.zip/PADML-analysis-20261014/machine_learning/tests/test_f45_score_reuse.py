"""Unfitted inputs exercise mixed reuse, real IBS pooling and native readback.

Only the parameterized family's 300 coordinates have physical synthetic inputs.
The other six families are metadata, and run authority/native model-health leaves
are explicit fixtures. These tests cannot establish whole-unit science acceptance.
"""
import copy
import shutil
import zipfile
from pathlib import Path

import pytest

from padml import f2_kernel, f4, f5, nested_loco as n, runtime, worker
from padml.bundle import ContractError, canonical_json_bytes as encode, write_deterministic_zip
from test_f45_score_component_numerics import inputs
from test_full0_cox12_prepare import _policy


def seal(value):
    return n._sealed({k: v for k, v in value.items() if k != 'identity_sha256'})


def pin(path):
    return {'sha256': n.sha256_file(path), 'size_bytes': path.stat().st_size}


def forbidden(*args, **kwargs):
    pytest.fail('UNFITTED: no model, MICE, native replay, new pool or final lock')


def fixture(root, monkeypatch, scope, family):

    # Preserve original numeric consumers; only the existing pool transport is isolated.
    from padml import runtime
    import pickle
    def readback(function, items, **kwargs):
        result = []
        for item in items:
            fn, job = pickle.loads(pickle.dumps((function, item)))
            result.append(fn(job))
        return result
    monkeypatch.setattr(runtime, "_readback_ordered", readback)
    science = n.science_decision_template(6)
    members = f4._f45_source_member_sha256()
    identity = n._sha(members)
    authority = ({'e' * 64: identity}, {identity: members})
    monkeypatch.setattr(f5, '_f45_score_reuse_authorities', lambda: authority)
    for module, names in ((f5, ['_execute_and_verify_score_archive_job', '_replay_component_job']),
                          (f4, ['_replay_f4_model_component']), (runtime, ['_bounded_ordered_spawn'])):
        for name in names:
            monkeypatch.setattr(module, name, forbidden)
    monkeypatch.setattr(f5, '_validate_final_r_fit_health', lambda *a, **k: None)
    monkeypatch.setattr(f5, '_validate_retained_r_audit_numbers', lambda *a, **k: None)
    # The actual component/task/input/receipt checks and IBS code remain native.
    ids = [f'p{i:02d}' for i in range(40)]
    response = ('Patient_ID,All_Cause_Death,Death_Followup_months\n'
                + ''.join(f'{pid},1,50\n' for pid in ids)).encode()
    first, base_context, entries = inputs(family, scope)
    context_fields = {k: v for k, v in base_context.items() if k != 'identity_sha256'}
    centers = {pid: '38' for pid in ids}
    if scope == 'OUTER':
        centers['h1'] = '36'
    model_identity = identity
    if scope == 'FULL_DATA':
        keys = {*f5._final_search_sources(), *('padml/' + name for name in (
            'nested_loco.py', 'runtime.py', 'f2_validation.py', 'kernels/f5_final_refit.R',
            'kernels/f5_design.R', 'kernels/f4_learning_selector.R', 'kernels/f4_learning_recipe.R'))}
        model_identity = n._sha({key: members[key] for key in keys})
    context = n.compile_training_context(scope=scope, outer_fold=context_fields['outer_fold'],
        heldout_center=context_fields['heldout_center'], training_ids=ids,
        heldout_ids=context_fields['heldout_ids'], centers_by_patient=centers,
        training_response_csv=response, mice_member_set_sha256='a' * 64,
        preprocessing_program_sha256=model_identity, modeling_program_sha256=model_identity,
        seed_program_sha256=context_fields['seed_program_sha256'])
    fields, responses = f2_kernel._response_rows(response)
    columns = f5.load_science_authority()['science']['mice']['private_handoff']['columns']

    def covariates(rows):
        return (','.join(columns) + '\n' + ''.join(','.join(
            pid if col == 'Patient_ID' else '38' if col == 'Center' else '1' for col in columns)
            + '\n' for pid in rows)).encode()

    partitions = []
    for repeat in range(1, 4):
        for inner in range(1, 6):
            evaluation = ids[(inner - 1) * 8:inner * 8]
            partitions.append(dict(partition_id=f'R{repeat}K{inner}', repeat=repeat, inner_fold=inner,
                fit_ids=[pid for pid in ids if pid not in evaluation], evaluation_ids=evaluation))
    owners = []
    for horizon in (6, 12):
        work = root / ('old-work' if horizon == 6 else 'new-work')
        request_root = work / 'request'
        (request_root / 'training').mkdir(parents=True)
        (request_root / 'training/response.csv').write_bytes(response)
        template, _, _ = inputs(family, scope, horizon)
        development = seal(dict(training_context=context, selection_horizon_months=horizon,
            science_decision=science, selector_development=dict(identity_sha256='a' * 64,
                selector=dict(selected_parents=['AST_ALT']), transform_recipes=dict(recipe_set_sha256='b' * 64)),
            complex_search_evidence=[dict(family=family, task=dict(selection_horizon_months=horizon,
                science_decision=science))] if family == 'GBM_COX' else [],
            locked_specs={family: template['parameters']}))
        records, outputs, component_entries = [], {}, {}
        for part in partitions:
            for imp in range(1, 21):
                task, _, component = inputs(family, scope, horizon)
                coords = task['f4_coordinates']
                coords.update(repeat=part['repeat'], inner_fold=part['inner_fold'], imputation=imp)
                seed = f4._f4_model_seed(family, coords)
                task.update(imputation=imp, registered_model_seed=seed,
                    model_seed=seed if family == 'GBM_COX' else None, row_count=len(part['fit_ids']))
                if scope == 'FULL_DATA':
                    task['nested_full_score_source'] = f5._full_score_family_source(development, family)
                component.update({'task.json': encode(task), 'fit-covariates.csv': covariates(part['fit_ids']),
                    'prediction-covariates.csv': covariates(part['evaluation_ids']),
                    'fit-response.csv': f2_kernel._write_response_subset(fields, responses, part['fit_ids'], None)['private_bytes']})
                name = f"components/score/{family}/R{part['repeat']}_K{part['inner_fold']}_M{imp:02d}.zip"
                # One actual array differs. It must remain a fresh coordinate;
                # the 299 unchanged coordinates must still be reused.
                if horizon == 12 and (part['repeat'], part['inner_fold'], imp) == (3, 5, 20):
                    component['fit-covariates.csv'] = component['fit-covariates.csv'].replace(b',1,1', b',2,1', 1)
                path = request_root / name
                path.parent.mkdir(parents=True, exist_ok=True)
                write_deterministic_zip(path, component)
                record = {'path': name, **pin(path), **n._validate_outer_component(path,
                    role='FRESH_SCORE', family=family, context=context)}
                records.append(record)
                component_entries[name] = component
                curve = [1.0] + [1 - month * (0.012 if imp <= 10 else 0.006) for month in range(1, 37)]
                prediction = dict(f4_coordinates=coords, patient_ids=part['evaluation_ids'],
                    centers=['38'] * 8, horizons=list(n.HORIZONS), survival={family: [curve] * 8})
                health = {'UNFITTED': True}
                receipt = seal(dict(component_role='FRESH_SCORE', family=family,
                    repeat=part['repeat'], inner_fold=part['inner_fold'], imputation=imp,
                    development_lock_sha256=None, training_context_sha256=context['identity_sha256'],
                    task_sha256=record['task_sha256'], input_sha256=n._sha({k: n.sha256_bytes(v) for k, v in component.items()}),
                    mice_member_sha256=n.sha256_bytes(component['fit-covariates.csv']), recipe_sha256=record['recipe_sha256'],
                    parameter_sha256=record['parameter_sha256'], training_ids_sha256=record['fit_ids_sha256'],
                    application_ids_sha256=record['prediction_ids_sha256'], training_response_sha256=record['fit_response_sha256'],
                    model_sha256='5' * 64, baseline_sha256='6' * 64, prediction_sha256=n._sha(prediction),
                    fit_health_sha256=n._sha(health), archive_sha256=n._sha([horizon, name]), model_fit_count=1,
                    engine_threads=1, seed=seed))
                outputs[name] = n._score_component_evidence(record=record, context=context,
                    partition_id=part['partition_id'], prediction=prediction, receipt=receipt,
                    fit_health=health, object_audit={'design_columns': ['AST_ALT'], 'UNFITTED': True})
        request = seal(dict(kind='PADML_F4_O_FIT_INPUT_V1' if scope == 'OUTER' else 'PADML_NESTED_FULL_SCORE_INPUT_V1',
            training_context=context, selection_horizon_months=horizon, science_decision=science,
            score_partitions=partitions, component_records=records, reused_training_scores=[],
            selector_evidence_sha256='a' * 64, selector_development_sha256='a' * 64,
            **({'development': development} if scope == 'FULL_DATA' else {})))
        owners.append((request, work, outputs, component_entries))
    old, old_work, old_outputs, old_components = owners[0]
    new, work, fresh_outputs, _ = owners[1]
    # Supply the complete metadata coordinate table to the provenance reader;
    # only this test family's bytes/numbers exist or get consumed.
    old = seal({**old, 'component_records': [{**row, 'family': other,
        'path': row['path'].replace(family, other)} for other in n._families() for row in old['component_records']]})
    score, execution = n._score_fresh_family(family=family, request=old, root=old_work, outputs=old_outputs)
    unit = ('PRIMARY-H06-O1' if scope == 'OUTER' else 'FULL0-H06')
    unit_root = root / unit
    unit_root.mkdir()
    scores = seal(dict(request_identity_sha256=old['identity_sha256'], fresh_score_execution=[execution]))
    values = {'o-fit-scores.json' if scope == 'OUTER' else 'scores.json': encode(scores),
              **{row['path']: old_work / 'score-evidence' / family / Path(row['path']).name
                 for row in execution['component_evidence_records']}}
    if scope == 'OUTER':
        write_deterministic_zip(unit_root / 'input.zip', {'o-fit-input.json': encode(old),
            **{name: old_work / 'request' / name for name in old_components}})
        (unit_root / 'input.compile.json').write_bytes(b'{}')
        metadata = dict(kind='PADML_F4_O_FIT_EXECUTION_ARCHIVE_V3', outer_fold=1,
            input_identity_sha256=old['identity_sha256'], input_archive=pin(unit_root / 'input.zip'))
        archive_name, manifest_name = 'result.zip', 'o-fit-execution.json'
    else:
        values.update({'request.json': encode(old), **{name: old_work / 'request' / name for name in old_components}})
        final_input = seal(dict(kind='PADML_NESTED_FULL_FINAL_INPUT_V1', selection_horizon_months=6,
            score_request_identity_sha256=old['identity_sha256'], score_result_identity_sha256=scores['identity_sha256'],
            UNFITTED=True))
        (unit_root / 'final-input').mkdir()
        (unit_root / 'final-input/full-final-input.json').write_bytes(encode(final_input))
        metadata = dict(kind='PADML_F45_FULL0_SCORE_ARCHIVE_V1', request_identity_sha256=old['identity_sha256'],
            score_result_identity_sha256=scores['identity_sha256'], final_input=final_input, selection_horizon_months=6)
        archive_name, manifest_name = 'score.zip', 'score-archive.json'
    metadata = seal({**metadata, 'members': {name: pin(value) if isinstance(value, Path)
        else {'sha256': n.sha256_bytes(value), 'size_bytes': len(value)} for name, value in values.items()}})
    write_deterministic_zip(unit_root / archive_name, {manifest_name: encode(metadata), **values})
    receipt = dict(status='COMPLETED', direct_consumer_completed=True, run_identity='e' * 64,
        unit_id=unit, selection_horizon_months=6, report_horizons_months=[6, 12, 24, 36],
        artifacts={p.relative_to(unit_root).as_posix(): pin(p) for p in unit_root.rglob('*') if p.is_file()})
    (unit_root / 'unit.json').write_bytes(encode(receipt))
    jobs = []
    for row in new['component_records']:
        coordinate = Path(row['path']).stem
        jobs.append(dict(source=str(work / 'request' / row['path']),
            root=str(work / 'components/score-native' / family / coordinate),
            retained_bytes_per_component=1024**2, score_evidence=dict(record=row,
                path=str(work / 'score-evidence' / family / (coordinate + '.json')))))
    return new, work, fresh_outputs, jobs, dict(root=str(unit_root), receipt=receipt), score


@pytest.mark.parametrize('scope', ['OUTER', 'FULL_DATA'])
@pytest.mark.parametrize('family', ['FPM_TVC_SET_A', 'GBM_COX'])
def test_mixed_original_inputs_rescore_current_horizon_and_roundtrip(tmp_path, monkeypatch, scope, family):
    request, work, fresh, jobs, candidate, old_score = fixture(tmp_path, monkeypatch, scope, family)
    limits = dict(expanded_bytes_per_component=1024**2, retained_bytes_per_component=1024**2,
                  shared_storage_bytes=32 * 1024**2, resource_policy=_policy())
    storage_calls = []
    storage = f5._full_score_storage_usage
    def observe_storage(*args, **kwargs):
        storage_calls.append(kwargs.get('pending_result_bytes', 0))
        return storage(*args, **kwargs)
    monkeypatch.setattr(f5, '_full_score_storage_usage', observe_storage)
    if scope == 'OUTER' and family == 'FPM_TVC_SET_A':
        write_once = n._write_exact_once
        def fail_before_first_audit_copy(path, *args, **kwargs):
            if path.parent.parent.name == 'score-evidence':
                raise OSError('UNFITTED simulated interruption after original input')
            return write_once(path, *args, **kwargs)
        with monkeypatch.context() as failure:
            failure.setattr(n, '_write_exact_once', fail_before_first_audit_copy)
            with pytest.raises(OSError, match='simulated interruption'):
                f5._prepare_f45_score_reuse(request, work, jobs, [candidate], replay=False, **limits)
        assert len(list((work / 'score-reuse').glob('*/components/score/*/*.zip'))) == 1
        assert not list((work / 'score-evidence').glob('*/*.json'))
    reader, bindings, handles = f5._prepare_f45_score_reuse(request, work, jobs, [candidate], replay=False, **limits)
    assert len(storage_calls) <= 5  # Bounded admissions, not one whole-tree scan per coordinate.
    assert len(bindings) == len(handles) == 299
    missing = [row for row in request['component_records'] if row['path'] not in bindings]
    assert len(missing) == 1 and missing[0]['imputation'] == 20 and missing[0]['repeat'] == 3
    last = missing[0]
    source = Path(jobs[-1]['score_evidence']['path'])
    source.write_bytes(encode(fresh[last['path']]))
    handles[last['path']] = dict(evidence_size_bytes=source.stat().st_size, evidence_sha256=n.sha256_file(source),
        archive_sha256=fresh[last['path']]['receipt']['archive_sha256'])
    outputs = f5._FullScoreArchiveOutputs(request['component_records'], jobs,
        [handles[row['path']] for row in request['component_records']], request['training_context'],
        reused_inputs=reader, reused_components=bindings)
    score, execution = n._score_fresh_family(family=family, request=request, root=work, outputs=outputs)
    n.validate_fresh_score_execution(execution)
    assert score['selection_horizon_months'] == 12 and score['mean_ibs'] != old_score['mean_ibs']
    assert execution['reused_component_count'] == 299
    assert execution['new_model_fit_count'] == execution['new_first_native_audit_count'] == 1
    assert execution['new_native_replay_count'] == 0
    for row in execution['component_evidence_records']:
        path = work / row['path']
        path.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(work / 'score-evidence' / family / path.name, path)
    # The receiver has only the current request, numerical records and named
    # original input/provenance members; no source whole unit or native models.
    receiver = tmp_path / 'receiver'
    names = f5._f45_score_reuse_members([execution]) | {row['path'] for row in execution['component_evidence_records']}
    if scope == 'FULL_DATA':
        score_result = seal(dict(request_identity_sha256=request['identity_sha256'], fresh_score_execution=[execution]))
        (work / 'request/full-score-input.json').write_bytes(encode(request))
        (work / 'full-score-result.json').write_bytes(encode(score_result))
        owner = tmp_path / 'full0-archive-owner'
        shutil.copytree(work, owner / 'score')
        (owner / 'final-input').mkdir()
        final = seal(dict(kind='PADML_NESTED_FULL_FINAL_INPUT_V1', selection_horizon_months=12,
            score_request_identity_sha256=request['identity_sha256'],
            score_result_identity_sha256=score_result['identity_sha256'], UNFITTED=True))
        final_path = owner / 'final-input/full-final-input.json'
        final_path.write_bytes(encode(final))
        # Resource APIs are fixture leaves; byte admission/archive readers are real.
        with monkeypatch.context() as admission:
            admission.setattr(runtime, 'observe_execution_resources', lambda _: {'scratch_available_bytes': 10**10})
            admission.setattr(runtime, 'resource_admission', lambda *a, **k: None)
            admission.setattr(runtime, 'effective_cpu_count', lambda: 32)
            archive_path = worker._f45_full0_score_archive(owner, {'resource_policy': {'memory_reserve_bytes': 0}})
        with zipfile.ZipFile(archive_path) as archive:
            assert names <= set(archive.namelist())
            for name in names:
                path = receiver / name
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(archive.read(name))
        final_path.write_bytes(encode(seal({**final, 'score_result_identity_sha256': 'f' * 64})))
        with pytest.raises(ContractError, match='F45_FULL0_SCORE_ARCHIVE_INVALID'):
            worker._f45_full0_score_archive(owner, {'resource_policy': {'memory_reserve_bytes': 0}})
    else:
        for name in names:
            path = receiver / name
            path.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(work / name, path)
    options = dict(execution=execution, score=score, request=request, request_root=work / 'request',
        result_root=receiver, **{k: v for k, v in limits.items() if k not in {'shared_storage_bytes', 'resource_policy'}})
    assert n._recompute_fresh_score_from_evidence(**options) == score
    for key in ('reused_component_count', 'new_model_fit_count', 'new_first_native_audit_count', 'new_native_replay_count'):
        with pytest.raises(ContractError):
            n.validate_fresh_score_execution(seal({**execution, key: execution[key] + 1}))
    with pytest.raises(ContractError):
        n._recompute_fresh_score_from_evidence(**options, replay_models=True)
    original = next(iter(bindings))
    unit = bindings[original]
    proof = copy.deepcopy(reader.sources[unit])
    proof['whole_unit']['run_identity'] = 'f' * 64
    with pytest.raises(ContractError):
        f5._f45_score_reuse_source(seal(proof), request, f5._f45_score_reuse_authorities())
    proof = copy.deepcopy(reader.sources[unit])
    proof['executor_source_identity'] = 'f' * 64
    with pytest.raises(ContractError):
        f5._f45_score_reuse_source(seal(proof), request, f5._f45_score_reuse_authorities())
    damaged = receiver / 'score-reuse' / unit / original
    damaged.write_bytes(damaged.read_bytes() + b'UNFITTED_CORRUPTION')
    with pytest.raises(ContractError):
        n._recompute_fresh_score_from_evidence(**options)
