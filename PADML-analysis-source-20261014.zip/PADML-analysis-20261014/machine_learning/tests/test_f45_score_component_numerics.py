"""Unfitted engineering inputs at the original seven-family native ABI."""
import copy
import io
import zipfile

import pytest

from padml import f4, f5, nested_loco as nested
from padml.bundle import ContractError, canonical_json_bytes
from test_full0_stop12_native_boundary import score_task


def archive(entries):
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, 'w') as target:
        for name, raw in entries.items():
            target.writestr(name, raw)
    return buffer.getvalue()


def inputs(family, scope, horizon=6):
    task, recipe = score_task(family, horizon)
    outer = 0 if scope == 'FULL_DATA' else 1
    response = b'Patient_ID,All_Cause_Death,Death_Followup_months\np1,1,10\np2,0,40\np3,1,20\n'
    context = nested.compile_training_context(scope=scope, outer_fold=outer,
        heldout_center=None if outer == 0 else 36,
        training_ids=['p1', 'p2', 'p3'], heldout_ids=[] if outer == 0 else ['h1'],
        centers_by_patient={'p1': '38', 'p2': '38', 'p3': '38', **({} if outer == 0 else {'h1': '36'})},
        training_response_csv=response, mice_member_set_sha256='a'*64,
        preprocessing_program_sha256='b'*64, modeling_program_sha256='c'*64, seed_program_sha256='d'*64)
    task['row_count'] = 2
    if scope == 'FULL_DATA':
        task['nested_full_score_source']['training_context_sha256'] = context['identity_sha256']
    else:
        del task['nested_full_score_source']
        task['f4_coordinates'].update(purpose='O_FIT', outer_fold=outer)
        seed = f4._f4_model_seed(family, task['f4_coordinates'])
        task.update(registered_model_seed=seed, model_seed=seed if family in {
            'RSF', 'GBM_COX', 'XGBOOST_COX', 'COXTIME_SET_A'} else None)
        if family == 'ELASTIC_NET_COX':
            original = task.pop('f4_nested_full_elastic_source')
            transform = copy.deepcopy(original['full_transform_recipe'])
            transform['partition_id'] = 'OUTER_F1'
            transform['recipe_sha256'] = nested._sha({k: v for k, v in transform.items() if k != 'recipe_sha256'})
            source = dict(outer_fold=1, selected_spec=original['selected_spec'], outer_transform_recipe=transform)
            task['f4_outer_elastic_source'] = source
            task['parameters'], _ = f4._f4_elastic_parameters(source, task['f4_coordinates'])
    columns = f5.load_science_authority()['science']['mice']['private_handoff']['columns']
    def covariates(ids):
        return (','.join(columns)+'\n'+''.join(','.join(pid if c == 'Patient_ID' else '38' if c == 'Center' else '1'
                   for c in columns)+'\n' for pid in ids)).encode()
    entries = {'task.json': canonical_json_bytes(task), 'recipe.json': canonical_json_bytes(recipe),
        'fit-covariates.csv': covariates(['p1', 'p2']), 'prediction-covariates.csv': covariates(['p3']),
        'fit-response.csv': b'Patient_ID,All_Cause_Death,Death_Followup_months\np1,1,10\np2,0,40\n'}
    return task, context, entries


@pytest.mark.parametrize('scope', ['OUTER', 'FULL_DATA'])
@pytest.mark.parametrize('family', nested._families())
def test_horizon_labels_do_not_replace_actual_numerical_dependencies(scope, family):
    task, context, entries = inputs(family, scope)
    before = copy.deepcopy(entries)
    numerical = f5._f45_score_component_numerics(archive(entries), context=context, family=family)
    for horizon in (12, 24, 36):
        _, next_context, next_entries = inputs(family, scope, horizon)
        assert f5._f45_score_component_numerics(archive(next_entries), context=next_context, family=family) == numerical
    assert entries == before
    changed = {**entries, 'fit-response.csv': entries['fit-response.csv'].replace(b'p1,1,10', b'p1,1,11')}
    assert f5._f45_score_component_numerics(archive(changed), context=context, family=family) != numerical
    changed = {**entries, 'fit-covariates.csv': entries['fit-covariates.csv'].replace(b',1,1', b',2,1', 1)}
    assert f5._f45_score_component_numerics(archive(changed), context=context, family=family) != numerical
    altered = copy.deepcopy(task)
    altered['registered_model_seed'] += 1
    with pytest.raises(ContractError):
        f5._f45_score_component_numerics(archive({**entries, 'task.json': canonical_json_bytes(altered)}), context=context, family=family)
    with pytest.raises(ContractError):
        other = nested._sealed({k: ('A12_WITHOUT_AST_ALT_TOTAL' if k == 'channel' else v)
                               for k, v in context.items() if k != 'identity_sha256'})
        f5._f45_score_component_numerics(archive(entries), context=other, family=family)
    lines = entries['fit-covariates.csv'].splitlines(keepends=True)
    responses = entries['fit-response.csv'].splitlines(keepends=True)
    reordered = {**entries, 'fit-covariates.csv': b''.join([lines[0], lines[2], lines[1]]),
                 'fit-response.csv': b''.join([responses[0], responses[2], responses[1]])}
    assert f5._f45_score_component_numerics(archive(reordered), context=context, family=family) != numerical
    with pytest.raises(ContractError):
        f5._f45_score_component_numerics(archive({**entries, 'development-lock.json': b'{}'}),
                                       context=context, family=family)


@pytest.mark.parametrize('family,field', [('GBM_COX', 'selected_trees'), ('XGBOOST_COX', 'selected_rounds'),
                                         ('COXTIME_SET_A', 'locked_epoch')])
def test_stop_lock_is_a_numerical_dependency(family, field):
    task, context, entries = inputs(family, 'FULL_DATA')
    original = f5._f45_score_component_numerics(archive(entries), context=context, family=family)
    task['parameters'][field] += 1
    task['nested_full_score_source']['selected_spec_sha256'] = nested._sha(task['parameters'])
    changed = {**entries, 'task.json': canonical_json_bytes(task)}
    assert f5._f45_score_component_numerics(archive(changed), context=context, family=family) != original


@pytest.mark.parametrize('family', ['RSF', 'ELASTIC_NET_COX'])
def test_selected_parameters_are_numerical_dependencies(family):
    task, context, entries = inputs(family, 'FULL_DATA')
    original = f5._f45_score_component_numerics(archive(entries), context=context, family=family)
    if family == 'RSF':
        candidate = f5._final_complex_candidate_trials(family)['S1'][1]
        task['parameters'].update(candidate_id=candidate.get('candidate_id', candidate.get('trial_id')),
                                  parameters=candidate['parameters'])
        spec = task['parameters']
    else:
        source = task['f4_nested_full_elastic_source']
        spec = source['selected_spec']
        spec['ratio_by_imputation'] = [0.2] * 20
        spec['lambda_by_imputation'] = [0.4] * 20
        task['parameters'], _ = f4._nested_full_elastic_parameters(source, task['f4_coordinates'])
    task['nested_full_score_source']['selected_spec_sha256'] = nested._sha(spec)
    assert f5._f45_score_component_numerics(archive({**entries, 'task.json': canonical_json_bytes(task)}),
                                           context=context, family=family) != original
