"""Numerical roots, using the actual R engines (no selector or grid refits)."""
from __future__ import annotations

import os
import json
from pathlib import Path
import shutil
import subprocess

import pytest

from padml.bundle import ContractError
from padml.f2_kernel import _validate_selector_sensitivity_numerics
from padml._science_authority import selector_parent_names, selector_sensitivity_contract


ROOT = Path(__file__).resolve().parents[1]
R_KERNEL = ROOT / "padml/kernels/f2_model_development.R"
R_FUNCTIONS = r'''
task_library <- Sys.getenv("PADML_TEST_R_LIBRARY")
if (nzchar(task_library)) .libPaths(c(task_library, .libPaths()))
suppressPackageStartupMessages({library(survival); library(jsonlite); library(digest)})
locked <- jsonlite::fromJSON(file.path(dirname(commandArgs(trailingOnly=TRUE)[[1L]]), "..", "..", "dependency-lock.json"))
for (expression in parse(commandArgs(trailingOnly=TRUE)[[1L]])) {
  if (is.call(expression) && identical(expression[[1L]], as.name("<-")) &&
      length(expression) == 3L && is.call(expression[[3L]]) &&
      identical(expression[[3L]][[1L]], as.name("function"))) eval(expression)
}
'''


def run_r(code: str) -> subprocess.CompletedProcess[str]:
    rscript = shutil.which("Rscript")
    if rscript is None:
        pytest.skip("Rscript is required for native numerical regression tests")
    result = subprocess.run(
        [rscript, "-e", R_FUNCTIONS + code, str(R_KERNEL)],
        env={**os.environ, "OMP_NUM_THREADS": "1", "OPENBLAS_NUM_THREADS": "1"},
        capture_output=True, text=True, timeout=120,
    )
    assert result.returncode == 0, result.stdout + result.stderr
    return result


@pytest.mark.parametrize("fixture", ["rare_null", "associated", "tied", "untied", "weighted_strata"])
def test_mrmre_native_relevance_matches_survival_concordance(fixture):
    run_r(r'''
suppressPackageStartupMessages(library(mRMRe))
stopifnot(as.character(packageVersion("mRMRe")) == locked$engine_contract_versions$mRMRe)
set.thread.count(1L); set.seed(20260903L)
n <- 500L; xx <- as.numeric(rbinom(n, 1, .02)); tt <- rexp(n); ee <- rbinom(n, 1, .7)
weights <- rep(1, n); groups <- rep(1L, n)
''' + f'fixture <- "{fixture}"\n' + r'''
if (fixture == "associated") {xx <- as.numeric(rbinom(n, 1, .3)); tt <- rexp(n, exp(2 * xx))}
if (fixture == "tied") {tt <- as.numeric(rep(1:20, 25)); xx <- as.numeric(rep(c(0, 1, 1, 0, 0), 100))}
if (fixture == "untied") xx <- rnorm(n)
if (fixture == "weighted_strata") {weights <- rep(c(.5, 1, 2, 3), 125); groups <- rep(1:4, 125); tt <- floor(tt * 10)}
reference <- survival::concordance(Surv(tt, ee) ~ xx + strata(groups),
                                    weights=weights, reverse=TRUE, timefix=FALSE)
for (ordered_x in c(FALSE, TRUE)) {
  if (ordered_x && fixture == "untied") next
  for (reverse_x in c(FALSE, TRUE)) {
    x <- if (reverse_x) -xx else xx
    if (ordered_x) x <- ordered(x)
    data <- mRMR.data(data=data.frame(.SURV=Surv(tt, ee), X=x),
                     strata=factor(groups), weights=weights)
    for (out_x in c(FALSE, TRUE)) {
      observed <- mim(data, method="cor", continuous_estimator="spearman", outX=out_x)[1, 2]
      counts <- reference$count
      if (is.matrix(counts)) counts <- colSums(counts)
      expected_c <- if (out_x) counts[[1L]] / sum(counts[1:2]) else reference$concordance
      expected <- (2 * expected_c - 1) * if (reverse_x) -1 else 1
      stopifnot(is.finite(observed), abs(observed - expected) < 1e-12)
    }
  }
}
if (fixture == "rare_null") stopifnot(abs(2 * reference$concordance - 1) < .05)
if (fixture == "associated") stopifnot(reference$concordance > .6)
''')


def test_mrmre_direct_type_dispatch_and_unchanged_mrmr_search():
    run_r(r'''
suppressPackageStartupMessages(library(mRMRe)); set.thread.count(1L); set.seed(20260903L)
n <- 300L; xx <- as.numeric(rbinom(n, 1, .3)); zz <- rnorm(n)
tt <- rexp(n, exp(3 * xx)); ee <- rbinom(n, 1, .85)
data <- mRMR.data(data=data.frame(.SURV=Surv(tt, ee), X=ordered(xx), Z=zz))
observed <- mim(data, method="cor", continuous_estimator="spearman", outX=FALSE)
expected <- 2 * concordance(xx ~ zz, timefix=FALSE)$concordance - 1
stopifnot(abs(observed[2, 3] - expected) < 1e-12, abs(observed[3, 2] - expected) < 1e-12)
numeric_data <- mRMR.data(data=data.frame(X=as.numeric(xx), Z=zz))
numeric_cor <- mim(numeric_data, method="cor", continuous_estimator="spearman", outX=FALSE)[1, 2]
stopifnot(abs(numeric_cor - cor(xx, zz, method="spearman")) < 1e-12)
fit <- mRMR.classic(data=data, target_indices=1L, feature_count=2L,
                   method="exhaustive", continuous_estimator="spearman",
                   fixed_feature_count=0L, outX=FALSE, bootstrap_count=0L)
stopifnot(identical(as.integer(solutions(fit)[[1L]][, 1L]), c(2L, 3L)))
''')


def test_mrmre_full_native_association_and_score_health():
    count = len(set(selector_parent_names()) - set(
        selector_sensitivity_contract()["mrmre"]["excluded_parents"]))
    output = run_r(f"candidate_count <- {count}L\n" + r'''
suppressPackageStartupMessages(library(mRMRe)); set.thread.count(1L); set.seed(7321L)
x <- as.data.frame(matrix(rnorm(240L * candidate_count), 240L, candidate_count))
names(x) <- paste0("X", seq_len(ncol(x)))
x[[1L]] <- ordered(rbinom(nrow(x), 1L, .1)); x[[2L]] <- round(x[[2L]])
y <- Surv(rexp(nrow(x)), rbinom(nrow(x), 1L, .7))
data <- mRMR.data(data=data.frame(.SURV=y, x))
fit <- checked_sensitivity_engine(mRMR.classic(data=data, target_indices=1L, feature_count=candidate_count,
          method="exhaustive", continuous_estimator="spearman", fixed_feature_count=0L,
          outX=FALSE, bootstrap_count=0L), "MRMRE")
health <- checked_mrmre_numerics(fit, data, x, y)
cat(canonical_json(health), "\n")
''')
    health = json.loads(output.stdout.splitlines()[-1])
    assert _validate_selector_sensitivity_numerics("MRMRE", health) == health


def test_mrmre_spearman_midrank_is_row_permutation_invariant():
    run_r(r'''
suppressPackageStartupMessages(library(mRMRe)); set.thread.count(1L); set.seed(17L)
x <- as.numeric(rep(c(0, 0, 0, 1), 30)); y <- round(rnorm(length(x)))
for (indices in list(seq_along(x), sample(seq_along(x)))) {
  data <- mRMR.data(data=data.frame(X=x[indices], Y=y[indices]))
  observed <- mim(data, method="cor", continuous_estimator="spearman", outX=FALSE)[1, 2]
  stopifnot(abs(observed - cor(x, y, method="spearman")) < 1e-12)
}
''')


@pytest.mark.parametrize("error", ["warning", "native_error", "guard_error"])
def test_sensitivity_numerical_errors_are_not_remapped_to_deferred(error):
    output = run_r(f'error <- "{error}"\n' + r'''
observed <- tryCatch(checked_sensitivity_engine({
  if (error == "warning") warning("nonfinite operation")
  if (error == "native_error") stop("NA/NaN/Inf in foreign call")
  if (error == "guard_error") fail("F2_BORUTA_IMPORTANCE_NONFINITE")
}, "BORUTA"), error=function(e) conditionMessage(e))
stopifnot(observed %in% c("F2_BORUTA_NUMERICAL_WARNING", "F2_BORUTA_ENGINE_EXECUTION_FAILED",
                          "F2_BORUTA_IMPORTANCE_NONFINITE"))
cat(observed, "\n")
''')
    assert "F2_BORUTA_ENGINE_FIT_FAILED" not in output.stdout


@pytest.mark.parametrize("damage", ["missing", "old_implementation", "nan", "warning", "wrong_count", "boolean_count"])
def test_native_validator_rejects_missing_or_invalid_numerical_health(damage):
    health = {
        "schema_version": "1.0.0", "implementation": "Boruta-getImpRfZ-pre-substitution-v1",
        "importance_calls": 50, "checked_value_count": 2 * len(selector_parent_names()) * 50,
        "length_checks": 50, "name_checks": 50,
        "finite_checks": 50, "nonfinite_count": 0, "warning_count": 0, "warnings": [],
    }
    assert _validate_selector_sensitivity_numerics("BORUTA", health) == health
    if damage == "missing":
        health.pop("finite_checks")
    elif damage == "old_implementation":
        health["implementation"] = "unverified"
    elif damage == "nan":
        health["nonfinite_count"] = 1
    elif damage == "warning":
        health.update(warning_count=1, warnings=["replacing with zero"])
    elif damage == "wrong_count":
        health["checked_value_count"] = 50
    else:
        health["nonfinite_count"] = False
    with pytest.raises(ContractError, match="NUMERICAL_HEALTH_INVALID"):
        _validate_selector_sensitivity_numerics("BORUTA", health)


@pytest.mark.parametrize("failure", ["nan", "inf", "negative_inf", "short", "reordered", "unnamed", "duplicate", "nonnumeric"])
def test_boruta_invalid_raw_importance_fails_before_substitution(failure):
    run_r(r'''
suppressPackageStartupMessages(library(Boruta))
x <- data.frame(a=1:40, b=rep(c(0, 1), 20))
calls <- 0L
get_imp <- function(x, y, ...) {
  calls <<- calls + 1L
  raw <- setNames(rep(.1, ncol(x)), colnames(x))
''' + f'failure <- "{failure}"\n' + r'''
  if (failure == "nan") raw[] <- NaN
  if (failure == "inf") raw[[1L]] <- Inf
  if (failure == "negative_inf") raw[[1L]] <- -Inf
  if (failure == "short") raw <- raw[-1L]
  if (failure == "reordered") raw <- rev(raw)
  if (failure == "unnamed") names(raw) <- NULL
  if (failure == "duplicate") names(raw)[[1L]] <- names(raw)[[2L]]
  if (failure == "nonnumeric") raw <- as.character(raw)
  checked_boruta_importance(raw, x)
}
observed <- tryCatch({Boruta(x, rep(c(0, 1), 20), maxRuns=11L,
                             holdHistory=FALSE, doTrace=0, getImp=get_imp); "unexpected_success"},
                     error=function(e) conditionMessage(e))
stopifnot(startsWith(observed, "F2_BORUTA_IMPORTANCE_"), calls == 1L)
''')


def test_boruta_valid_finite_values_and_tentative_are_not_failures():
    run_r(r'''
suppressPackageStartupMessages(library(Boruta))
x <- data.frame(a=1:40, b=rep(c(0, 1), 20)); calls <- 0L
get_imp <- function(x, y, ...) {
  calls <<- calls + 1L
  raw <- setNames(rep(0, ncol(x)), colnames(x))
  raw[if (calls %% 2L) !startsWith(names(raw), "shadow") else startsWith(names(raw), "shadow")] <- 1
  checked_boruta_importance(raw, x)
}
fit <- Boruta(x, rep(c(0, 1), 20), maxRuns=11L, pValue=.01,
              mcAdj=TRUE, holdHistory=FALSE, doTrace=0, getImp=get_imp)
stopifnot(identical(names(fit$finalDecision), c("a", "b")),
          all(fit$finalDecision == "Tentative"), calls == 10L)
''')
