"""Execution-policy regression only; synthetic tasks, no scientific models."""
import json
import multiprocessing
import time

import pytest

from padml import f5, runtime
from padml.bundle import ContractError
from test_runtime_pool import _partial_release_entry, _result_then_diagnostic_loss_task


@pytest.mark.parametrize("damage", ["missing", "overlap", "unknown", "not_list"])
def test_a12_continuous_partition_rejected_before_materialization(tmp_path, monkeypatch, damage):
    from padml import f5_sensitivity as sensitivity, nested_loco as nested
    history = {branch: [] for branch in nested.AAR_ESTIMANDS}
    roots = {}
    branch = nested.AAR_ESTIMANDS[0]
    if damage == "missing":
        del history[branch]
    elif damage == "overlap":
        roots[branch] = tmp_path
    elif damage == "unknown":
        history["UNKNOWN_BRANCH"] = history.pop(branch)
    else:
        history[branch] = ()
    def forbidden(*args, **kwargs):
        pytest.fail("Invalid branch ownership must not materialize inputs or enter science")
    monkeypatch.setattr(sensitivity, "materialize_a12_outer_inputs", forbidden)
    with pytest.raises(ContractError, match="F5_Q_CONTINUOUS_BATCH_SCOPE_INVALID"):
        sensitivity.execute_a12_outer_bundle(tmp_path / "UNFITTED-source.zip", tmp_path / "result.zip",
            input_bundle=tmp_path / "UNFITTED-input.zip", q_batches=history, q_roots=roots,
            continuous_batch_root=tmp_path, retained_bytes_per_task=1024)
    assert not (tmp_path / "result.zip").exists()


@pytest.mark.parametrize("entry", ["compile", "aggregate"])
@pytest.mark.parametrize("failure", [None, "memory", "space"])
def test_full0_final_current_admission_preserves_historical_policy(tmp_path, monkeypatch, entry, failure):
    """Reach the original next reader; do not run scientific materialization."""
    from padml.bundle import canonical_json_bytes
    policy = {"configured_worker_ceiling": "EXECUTION_HOST_C_MINUS_8",
        "memory_bytes_per_worker": 1, "scratch_bytes_per_worker": 1024,
        "memory_reserve_bytes": 2 * 1024**3, "scratch_reserve_bytes": 10**12,
        "transfer_archive_worker_ceiling": 24}
    original_policy = dict(policy)
    observation = {"effective_cpus": 32, "available_memory_bytes": 10 * 1024**3,
        "scratch_available_bytes": 10**9, "scratch_root": str(tmp_path)}
    if failure == "memory":
        observation["available_memory_bytes"] = 3 * 1024**3
    elif failure == "space":
        observation["scratch_available_bytes"] = 1
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda root: dict(observation))
    calls = []
    def next_reader(*args, **kwargs):
        calls.append("original_reader_boundary")
        raise RuntimeError("UNFITTED_READER_BOUNDARY")
    response = tmp_path / "response.csv"
    response.write_bytes(b"UNFITTED")
    if entry == "compile":
        monkeypatch.setattr(f5, "_final_search_mice_members", next_reader)
        def invoke():
            return f5._compile_full_final_inputs({}, None, None, tmp_path, {}, tmp_path,
                tmp_path / "final", rscript="UNFITTED", resource_policy=policy,
                retained_bytes_per_component=1024, expanded_bytes_per_component=1024,
                shared_storage_bytes=1024, mice_root=tmp_path,
                final_mice_path=tmp_path / "mice.zip", response_path=response)
    else:
        index = tmp_path / "index.json"
        index.write_bytes(canonical_json_bytes({"final_refit_plan": {
            "kind": "PADML_NESTED_FULL_FINAL_INPUT_V1"}}))
        monkeypatch.setattr(f5, "_read_final_lineage", next_reader)
        def invoke():
            return f5.execute_final_aggregate(index, response, tmp_path, tmp_path / "non-ph.zip",
                tmp_path / "aggregate.zip", input_root=tmp_path, resource_policy=policy)
    with pytest.raises(ContractError if failure else RuntimeError,
                       match="RESOURCE_ADMISSION_ZERO" if failure else "UNFITTED_READER_BOUNDARY"):
        invoke()
    assert calls == ([] if failure else ["original_reader_boundary"])
    assert policy == original_policy


@pytest.mark.parametrize("operation", ["observe_step_memory", "release_step_resources"])
@pytest.mark.parametrize("error", [OSError("scan"), ContractError("release"), ValueError("diagnostic")])
def test_completed_q_unit_retains_numbers_when_cleanup_fails(tmp_path, monkeypatch, operation, error):
    from padml import f2_kernel as kernel, f4_compact
    root = tmp_path / "q"
    root.mkdir()
    calls = []
    monkeypatch.setattr(kernel, "_run_r_prediction_pool_task", lambda task: calls.append(task) or ["UNFITTED"])
    monkeypatch.setattr(f5, "_q_search_unit_call", lambda function, task, *args, **kwargs: task)
    monkeypatch.setattr(f4_compact, "_full_pipeline_q_numerical_members", lambda *args, **kwargs: ({}, {}))
    def fail(*args, **kwargs):
        raise error
    monkeypatch.setattr(runtime, operation, fail)
    row = f5._execute_and_verify_q_search_unit({"function": "_run_r_prediction_pool_task",
        "task_id": "UNFITTED", "task": "UNFITTED", "root": str(root), "work": str(root / "work"),
        "native_units": ["UNFITTED", "UNFITTED_MODEL"], "retained_bytes_per_task": 1024})
    assert calls == ["UNFITTED", "UNFITTED"]
    assert row["first_native_audit_count"] == 1 and row["numerical_members"] == {}
    assert row["resource_release"]["status"] == "UNKNOWN"
    assert row["resource_release"]["reason"] == type(error).__name__ + ":" + str(error)
    runtime.validate_resource_release(row["resource_release"])


def test_scientific_q_unit_error_is_not_hidden_as_cleanup_unknown(tmp_path, monkeypatch):
    from padml import f2_kernel as kernel
    root = tmp_path / "q"
    root.mkdir()
    def fail(task):
        raise ContractError("UNFITTED_SCIENTIFIC_FAILURE")
    monkeypatch.setattr(kernel, "_run_r_prediction_pool_task", fail)
    monkeypatch.setattr(f5, "_q_search_unit_call", lambda function, task, *args, **kwargs: task)
    monkeypatch.setattr(runtime, "release_step_resources", lambda *a, **k: pytest.fail("failed science released"))
    with pytest.raises(ContractError, match="UNFITTED_SCIENTIFIC_FAILURE"):
        f5._execute_and_verify_q_search_unit({"function": "_run_r_prediction_pool_task",
            "task_id": "UNFITTED", "task": "UNFITTED", "root": str(root), "work": str(root / "work"),
            "native_units": ["UNFITTED", "UNFITTED_MODEL"], "retained_bytes_per_task": 1024})


def test_future_scratch_override_does_not_rewrite_history_or_remove_capacity_checks():
    gib = 1024**3
    policy = {"configured_worker_ceiling": runtime.CPU_MINUS_8, "memory_bytes_per_worker": 2*gib,
        "scratch_bytes_per_worker": 4*gib, "memory_reserve_bytes": 2*gib,
        "scratch_reserve_bytes": 100*gib, "transfer_archive_worker_ceiling": 64}
    old = f5._q_batch_resource_policy(policy, 100, 3, 1000, execution_worker_memory_bytes=2*gib)
    fresh = f5._q_batch_resource_policy(policy, 100, 3, 1000,
        execution_worker_memory_bytes=2*gib, execution_scratch_reserve_bytes=0)
    assert fresh == {**old, "scratch_reserve_bytes": 0}
    assert policy["scratch_reserve_bytes"] == 100*gib
    observation = {"effective_cpus": 32, "available_memory_bytes": 20*gib,
        "scratch_available_bytes": 8*gib, "scratch_root": "/UNFITTED"}
    with pytest.raises(ContractError, match="RESOURCE_ADMISSION_ZERO"):
        runtime.resource_admission(old, observation, legal_tasks=3)
    assert runtime.resource_admission(fresh, observation, legal_tasks=3)["admitted_worker_ceiling"] == 2
    with pytest.raises(ContractError, match="RESOURCE_ADMISSION_ZERO"):
        runtime.resource_admission(fresh, {**observation,"scratch_available_bytes": 1}, legal_tasks=3)
    with pytest.raises(ContractError, match="RESOURCE_ADMISSION_ZERO"):
        runtime.resource_admission(fresh, {**observation,"available_memory_bytes": 1}, legal_tasks=3)
    for value in (True, 1, -1):
        with pytest.raises(ContractError, match="F5_Q_SCRATCH_RESERVE_OVERRIDE_INVALID"):
            f5._q_batch_resource_policy(policy,100,3,1000,execution_scratch_reserve_bytes=value)
    assert f5._q_batch_numerical_resource_policy(policy,100,1000,
        execution_scratch_reserve_bytes=0)["scratch_reserve_bytes"] == 0


def test_zero_admission_records_each_live_limit_and_observation():
    gib = 1024**3
    policy = {"configured_worker_ceiling": runtime.CPU_MINUS_8,
        "memory_bytes_per_worker": 2*gib, "scratch_bytes_per_worker": 4*gib,
        "memory_reserve_bytes": 2*gib, "scratch_reserve_bytes": 0,
        "transfer_archive_worker_ceiling": 64}
    observation = {"effective_cpus": 32, "available_memory_bytes": 2*gib,
        "scratch_available_bytes": 218*gib, "scratch_root": "/UNFITTED-H7"}
    with pytest.raises(ContractError, match="RESOURCE_ADMISSION_ZERO:") as captured:
        runtime.resource_admission(policy, observation, legal_tasks=75)
    detail = json.loads(str(captured.value).split(":", 1)[1])
    assert detail == {"limits": {"cpu_c_minus_8": 24, "memory": 0, "scratch": 54,
        "transfer_archive": 64, "legal_independent_tasks": 75, "configured": 24},
        "memory_usable_bytes": 0, "scratch_usable_bytes": 218*gib, "legal_tasks": 75,
        "policy": policy, "observation": observation}


def test_full_score_future_reserve_is_zero_but_physical_space_and_ram_still_gate(tmp_path, monkeypatch):
    root = tmp_path / "score"
    root.mkdir()
    gib = 1024**3
    policy = dict(configured_worker_ceiling=runtime.CPU_MINUS_8, memory_bytes_per_worker=2*gib,
        scratch_bytes_per_worker=4*gib, memory_reserve_bytes=2*gib,
        scratch_reserve_bytes=100*gib, transfer_archive_worker_ceiling=64)
    observation = dict(effective_cpus=32, available_memory_bytes=20*gib,
        scratch_available_bytes=8*gib, scratch_root=str(tmp_path))
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda root: observation)
    budgets = dict(retained_bytes_per_component=10000, expanded_bytes_per_component=1000, shared_storage_bytes=100000)
    with pytest.raises(ContractError, match="RESOURCE_ADMISSION_ZERO"):
        f5._full_score_resource_admission(policy, root, **budgets)
    admission, reserved = f5._full_score_resource_admission(policy, root, **budgets, execution_scratch_reserve_bytes=0)
    assert admission["admitted_worker_ceiling"] == 2 and admission["limits"]["configured"] == 24
    assert reserved["execution_scratch_reserve_bytes"] == reserved["remaining_retention_reserved_bytes"] == 0
    assert reserved["remaining_retention_estimate_bytes"] == 21100000
    assert reserved["effective_policy"]["scratch_reserve_bytes"] == 0
    assert reserved["effective_policy"]["memory_bytes_per_worker"] == 2*gib
    assert reserved["effective_policy"]["memory_reserve_bytes"] > policy["memory_reserve_bytes"]
    assert policy["scratch_reserve_bytes"] == 100*gib
    for field in ("available_memory_bytes", "scratch_available_bytes"):
        with monkeypatch.context() as patch:
            patch.setattr(runtime, "observe_execution_resources", lambda root: {**observation, field: 1})
            with pytest.raises(ContractError, match="RESOURCE_ADMISSION_ZERO"):
                f5._full_score_resource_admission(policy, root, **budgets, execution_scratch_reserve_bytes=0)
    for value in (True, 1, -1):
        with pytest.raises(ContractError, match="SCRATCH_RESERVE_OVERRIDE_INVALID"):
            f5._full_score_resource_admission(policy, root, **budgets, execution_scratch_reserve_bytes=value)


@pytest.mark.parametrize("loss", ["eof", "partial-frame"])
def test_operational_diagnostic_loss_keeps_results_and_refills_only_unstarted_tasks(tmp_path,monkeypatch,loss):
    monkeypatch.setattr(runtime,"effective_cpu_count",lambda:32)
    if loss == "partial-frame": monkeypatch.setattr(runtime,"_spawn_task_entry",_partial_release_entry)
    releases, report, received = {}, {}, []
    def clock():
        if releases.get("0",{}).get("status") == "UNKNOWN":
            (tmp_path/"UNFITTED-release-observed").touch()
        return time.monotonic()
    monkeypatch.setattr(runtime,"monotonic",clock)
    paths = [tmp_path/f"UNFITTED-{i}.txt" for i in range(3)]
    results = runtime._bounded_ordered_spawn(_result_then_diagnostic_loss_task,
        [(i,str(p),loss) for i,p in enumerate(paths)],selected_slots=2,
        on_result=lambda i,r:received.append(i),execution_report=report,resource_release_report=releases)
    assert [r["index"] for r in results] == [0,1,2]
    assert sorted(received) == [0,1,2]
    assert report["status"] == "COMPLETED" and report["completed_task_count"] == 3
    assert releases["0"]["status"] == "UNKNOWN"
    assert all(p.read_text() == f"UNFITTED completed once: {i}" for i,p in enumerate(paths))
    assert not multiprocessing.active_children()


@pytest.mark.parametrize("failure", [None, "copy_space", "memory"])
def test_a12_existing_q_copy_uses_current_admission_not_historical_reserve(tmp_path, monkeypatch, failure):
    from contextlib import nullcontext
    from padml import f4_compact, f5_sensitivity as sensitivity
    gib = 1024**3
    branch = "UNFITTED_BRANCH"
    root, retained = tmp_path / "owner", tmp_path / "retained"
    root.mkdir()
    retained.mkdir()
    original = retained / "numbers.json"
    original.write_bytes(b'"UNFITTED numerical-consumer boundary"')
    policy = dict(configured_worker_ceiling=runtime.CPU_MINUS_8, memory_bytes_per_worker=1,
        scratch_bytes_per_worker=1, memory_reserve_bytes=2*gib,
        scratch_reserve_bytes=100*gib, transfer_archive_worker_ceiling=24)
    prepared = dict(family="RSF", source={"resource_policy": policy}, branch_development={branch: {}})
    observation = dict(effective_cpus=32, available_memory_bytes=20*gib,
        scratch_available_bytes=8*gib, scratch_root=str(root))
    calls = []
    def observe(path):
        assert path == root
        if failure == "memory":
            return {**observation, "available_memory_bytes": 1}
        if failure == "copy_space" and calls:
            return {**observation, "scratch_available_bytes": original.stat().st_size - 1}
        return observation
    def consume(actual, name, path, **kwargs):
        assert actual is prepared and name == branch and path == retained and kwargs["replay"] is True
        calls.append("existing_q_consumer")
        return {"UNFITTED": True}
    def members(path):
        assert (path / "numbers.json").read_bytes() == original.read_bytes()
        calls.append("retained_members" if path == retained else "direct_copy_reader")
        return {"numbers.json": path / "numbers.json"}, {}
    monkeypatch.setattr(sensitivity, "_a12_branch_names", lambda prepared: (branch,))
    monkeypatch.setattr(sensitivity, "_a12_branch_search_inputs", lambda *args: None)
    monkeypatch.setattr(sensitivity, "_a12_complex_search_program", consume)
    monkeypatch.setattr(f4_compact, "_full_pipeline_q_numerical_members", members)
    monkeypatch.setattr(f5, "_full_score_scratch", lambda path: nullcontext())
    monkeypatch.setattr(runtime, "observe_execution_resources", observe)
    destination = root / "search" / branch
    if failure:
        with pytest.raises(ContractError, match="RESOURCE_ADMISSION_ZERO" if failure == "memory"
                           else "F5_A12_PREPARATION_SPACE_INSUFFICIENT"):
            sensitivity._a12_outer_searches(prepared, root, replay=False, q_roots={branch: retained})
        assert not destination.exists()
        assert calls == ([] if failure == "memory" else ["existing_q_consumer", "retained_members"])
    else:
        assert sensitivity._a12_outer_searches(prepared, root, replay=False,
            q_roots={branch: retained}) == {branch: {"UNFITTED": True}}
        assert calls == ["existing_q_consumer", "retained_members", "direct_copy_reader"]
        assert (destination / "numbers.json").read_bytes() == original.read_bytes()
    assert policy["scratch_reserve_bytes"] == 100*gib and policy["memory_bytes_per_worker"] == 1


@pytest.mark.parametrize("conflict", ["prepare_only", "retained_full0_source_bundle",
                                     "retained_q_producer_source_bundle"])
def test_continuous_q_rejects_unconsumed_source_or_prepare_only(tmp_path, monkeypatch, conflict):
    target = tmp_path / "result.zip"
    arguments = dict(target=target, full_development_path=tmp_path / "development.zip",
        candidate_family="GBM_COX", q_batches=[], continuous_batch_root=tmp_path / "batches",
        retained_bytes_per_task=4 * 1024**2)
    arguments[conflict] = True if conflict == "prepare_only" else tmp_path / "old-source.zip"
    monkeypatch.setattr(f5, "_final_complex_search_program",
        lambda *args, **kwargs: pytest.fail("unsupported scope entered Q"))
    with pytest.raises(ContractError, match="F5_Q_CONTINUOUS_BATCH_SCOPE_INVALID"):
        f5.execute_final_complex_search(**arguments)
    assert not target.exists() and not arguments["continuous_batch_root"].exists()


@pytest.mark.parametrize("mode", ["continuous", "legacy", "failure", "partial", "wrong_owner", "already_started"])
def test_q_owner_receives_only_persisted_whole_phase_receipt(tmp_path, monkeypatch, mode):
    from padml import f2_kernel as kernel
    from padml.bundle import canonical_json_bytes, sha256_file
    root, owner = tmp_path / "q", tmp_path / "batches"
    root.mkdir()
    owner.mkdir()
    (root / "input.json").write_bytes(b"{}")
    input_ref = {"sha256": sha256_file(root / "input.json"), "size_bytes": 2}
    units = {name: ({"UNFITTED": name}, [name, name + "_MODEL"]) for name in ("A", "B")}
    batch = owner / "UNFITTED_PHASE"
    policy = dict(configured_worker_ceiling=runtime.CPU_MINUS_8, memory_bytes_per_worker=2*1024**3,
        scratch_bytes_per_worker=1, memory_reserve_bytes=0, scratch_reserve_bytes=0,
        transfer_archive_worker_ceiling=2)
    control = dict(task_ids=list(units), batch_root=batch, continuous_batch_root=owner,
        resource_policy=policy, retained_bytes_per_task=1024, execution_worker_memory_bytes=2*1024**3,
        execution_scratch_reserve_bytes=0, completed=False)
    if mode == "partial":
        control["task_ids"] = ["A"]
    if mode == "wrong_owner":
        control["continuous_batch_root"] = root
    if mode == "already_started":
        batch.mkdir()
        (batch / "partial-evidence").write_bytes(b"UNFITTED_INTERRUPTED_ORIGINAL")
    calls = []
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda path: dict(effective_cpus=32,
        available_memory_bytes=16*1024**3, scratch_available_bytes=16*1024**3, scratch_root=str(path)))
    monkeypatch.setattr(f5, "_q_search_unit_call", lambda function, task, *args, **kwargs: task)
    monkeypatch.setattr(f5, "_q_batch_retention_preflight", lambda jobs, size: {})
    def pool(function, jobs, **kwargs):
        calls.append([job["task_id"] for job in jobs])
        if mode == "failure":
            raise ContractError("UNFITTED_POOL_FAILURE")
        rows = []
        for i, job in enumerate(jobs):
            row = dict(task_id=job["task_id"], first_native_audit_count=1,
                numerical_members={"input.json": input_ref}, resource_release={"UNFITTED": True})
            kwargs["on_result"](i, row)
            rows.append(row)
        return rows
    monkeypatch.setattr(f5, "_bounded_ordered_spawn", pool)
    def execute():
        return f5._execute_q_search_batch(kernel._run_r_prediction_pool_task, units, root, control,
            "UNFITTED_PHASE", input_ref, rsf_boundary={}, mixed_s3b1=False,
            continuing=None, restoration=None, return_after_persist=mode != "legacy")
    if mode == "already_started":
        with pytest.raises(ContractError, match="F5_Q_BATCH_ALREADY_STARTED"):
            execute()
        assert calls == [] and (batch / "partial-evidence").read_bytes() == b"UNFITTED_INTERRUPTED_ORIGINAL"
        assert not (batch / "execution.json").exists()
        return
    if mode in {"partial", "wrong_owner"}:
        with pytest.raises(ContractError, match="F5_Q_CONTINUOUS_BATCH_SCOPE_INVALID"):
            execute()
        assert calls == [] and not batch.exists()
        return
    if mode == "failure":
        with pytest.raises(ContractError, match="UNFITTED_POOL_FAILURE"):
            execute()
        receipt = json.loads((batch / "execution.json").read_bytes())
        assert receipt["new_model_fit_count"] is None
    elif mode == "legacy":
        with pytest.raises(f5._QBatchBoundary):
            execute()
    else:
        receipt = execute()
        assert (batch / "execution.json").read_bytes() == canonical_json_bytes(receipt)
        assert receipt["task_ids"] == ["A", "B"] and receipt["new_model_fit_count"] == 2
    assert calls == [["A", "B"]]
    with pytest.raises(ContractError, match="F5_Q_BATCH_ALREADY_STARTED"):
        execute()
    assert calls == [["A", "B"]]
