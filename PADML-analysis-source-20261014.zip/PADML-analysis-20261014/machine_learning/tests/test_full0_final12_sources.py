"""Existing final compiler wiring and fail-closed missing-score boundary."""
from pathlib import Path
import sys

import pytest

from padml import f5, runtime
from padml.bundle import ContractError
from test_full0_fixed12_rescore import decision


class ReachedOriginalConsumer(Exception):
    pass


def source_options(tmp_path):
    return dict(selection_horizon_months=12, retained_full0_source_bundle=tmp_path / "primary.zip",
        retained_q_archive=tmp_path / "q.zip", retained_q_producer_source_bundle=tmp_path / "producer.zip")


def score_source_options(tmp_path):
    return dict(retained_score_root=tmp_path / "score24",
        retained_score_producer_source_bundle=tmp_path / "score24-source.zip",
        prepared_score_source_bundle=tmp_path / "score12-source.zip")


@pytest.mark.parametrize("physical", [False, True])
def test_final_compiler_forwards_q_pair_to_original_complete_score_consumer(tmp_path, monkeypatch, physical):
    options = {**source_options(tmp_path), **score_source_options(tmp_path)}
    calls = []
    parts, full = [], {"covariates": {"input_dir": str(tmp_path / "mice")}}
    policy, physical_options = {}, {}
    if physical:
        from test_full0_cox12_prepare import _observe, _policy
        policy = _policy()
        response = tmp_path / "response.csv"
        response.write_bytes(b"SYNTHETIC_IO_BOUNDARY_ONLY")
        physical_options = dict(mice_root=tmp_path / "mice", final_mice_path=tmp_path / "final-mice.zip",
            response_path=response)
        expected = {"UNFITTED_MICE_SOURCE": True}
        monkeypatch.setattr(runtime, "observe_execution_resources", _observe)
        monkeypatch.setattr(f5, "_final_search_mice_members", lambda *a: {})
        def validate_plan(plan, members, raw, **kwargs):
            assert kwargs == {"retained_mice_plan": plan} and raw == response.read_bytes()
            return expected
        monkeypatch.setattr(f5, "_validate_final_search_plan", validate_plan)
        monkeypatch.setattr(f5, "_materialize_final_search_inputs", lambda *a: [])
        monkeypatch.setattr(f5, "materialize_final_full_data_mice", lambda *a: {
            "development_input": expected, "covariates": {"input_dir": str(a[-1])}})
        parts = full = None
    def consume(*args, **kwargs):
        assert args[5] == tmp_path / "score.all"
        assert kwargs["replay"] is True and kwargs["science_decision"] == decision()
        assert all(kwargs[key] == value for key, value in options.items())
        calls.append(True)
        raise ReachedOriginalConsumer
    monkeypatch.setattr(f5, "_full_data_locked_score_program", consume)
    with pytest.raises(ReachedOriginalConsumer):
        f5._compile_full_final_inputs({}, parts, full,
            tmp_path / "selector", {}, tmp_path / "score.all", tmp_path / "final", rscript="FORBIDDEN",
            resource_policy=policy, retained_bytes_per_component=1, expanded_bytes_per_component=1,
            shared_storage_bytes=1, science_decision=decision(), **options, **physical_options)
    assert calls == [True] and not (tmp_path / "final").exists()


def test_public_final_compiler_uses_complete_root_not_old_rsf_root(tmp_path, monkeypatch):
    options = {**source_options(tmp_path), **score_source_options(tmp_path)}
    mice = tmp_path / "final-mice.zip"
    mice.write_bytes(b"SYNTHETIC_FILE_IDENTITY_ONLY")
    sources = dict(plan={}, science_decision=decision(), final_mice_path=str(mice),
        selector_root=str(tmp_path / "selector"), search_roots={}, score_root=str(tmp_path / "score"),
        rscript="FORBIDDEN", resource_policy={}, retained_bytes_per_component=1,
        expanded_bytes_per_component=1, shared_storage_bytes=1,
        mice_root=str(tmp_path / "mice"), response_path=str(tmp_path / "response.csv"))
    monkeypatch.setattr(f5, "_read_final_lineage", lambda *a, **k: sources)
    calls = []
    def compile_inputs(*args, **kwargs):
        assert args[1] is args[2] is None and args[5] == tmp_path / "score.all"
        assert all(kwargs[key] == value for key, value in options.items())
        calls.append(True)
        raise ReachedOriginalConsumer
    monkeypatch.setattr(f5, "_compile_full_final_inputs", compile_inputs)
    with pytest.raises(ReachedOriginalConsumer):
        f5.compile_final_refit_bundles(full_development_path=tmp_path / "lineage.json",
            target_root=tmp_path / "final", **options)
    assert calls == [True] and not (tmp_path / "final").exists()


@pytest.mark.parametrize("change", [{"retained_q_archive": None}, {"retained_q_producer_source_bundle": None},
    {"retained_full0_source_bundle": None}, {"selection_horizon_months": 24}])
def test_final_q_source_pair_rejects_partial_or_cross_line_before_io(tmp_path, monkeypatch, change):
    def forbidden(*args, **kwargs):
        pytest.fail("NO_LINEAGE_READ_BEFORE_SCOPE_CHECK")
    monkeypatch.setattr(f5, "_read_final_lineage", forbidden)
    with pytest.raises(ContractError, match="NESTED_FULL_FINAL_RETAINED_Q_SCOPE_INVALID"):
        f5.compile_final_refit_bundles(full_development_path=tmp_path / "lineage.json",
            **{**source_options(tmp_path), **change})


@pytest.mark.parametrize("change", [
    {"retained_score_root": None},
    {"retained_score_producer_source_bundle": None},
    {"prepared_score_source_bundle": None},
])
def test_final_score_source_pair_rejects_partial_before_io(tmp_path, monkeypatch, change):
    def forbidden(*args, **kwargs):
        pytest.fail("NO_LINEAGE_READ_BEFORE_SCORE_SOURCE_SCOPE_CHECK")
    monkeypatch.setattr(f5, "_read_final_lineage", forbidden)
    with pytest.raises(ContractError, match="NESTED_FULL_FINAL_RETAINED_SCORE_SCOPE_INVALID"):
        f5.compile_final_refit_bundles(full_development_path=tmp_path / "lineage.json",
            **{**source_options(tmp_path), **score_source_options(tmp_path), **change})


def test_seven_family_replay_cannot_fit_when_complete_score_report_is_missing(tmp_path, monkeypatch):
    root = tmp_path / "score.all"
    root.mkdir()
    def forbidden(*args, **kwargs):
        pytest.fail("NO_COMPILATION_OR_WORKER_FALLBACK")
    monkeypatch.setattr(f5, "_compile_full_score_inputs", forbidden)
    monkeypatch.setattr(f5, "_execute_and_verify_score_archive_job", forbidden)
    with pytest.raises(ContractError, match="NESTED_FULL_SCORE_NUMERICAL_ORIGINAL_REQUIRED"):
        f5._full_data_locked_score_program({}, [], {}, tmp_path / "selector", {}, root,
            rscript="FORBIDDEN", replay=True, resource_policy={}, retained_bytes_per_component=1,
            expanded_bytes_per_component=1, shared_storage_bytes=1, science_decision=decision(),
            **source_options(tmp_path))
    assert not list(root.iterdir())


def test_original_final_cli_passes_q_pair(tmp_path, monkeypatch, capsys):
    options = {**source_options(tmp_path), **score_source_options(tmp_path)}
    calls = []
    def compile_inputs(*args, **kwargs):
        assert all(kwargs[key] == value for key, value in options.items())
        calls.append(True)
        return {"ZERO_FIT_WIRING": True}
    monkeypatch.setattr(f5, "compile_final_refit_bundles", compile_inputs)
    monkeypatch.setattr(sys, "argv", ["padml-f5", "compile-final-refit", "--full-development",
        str(tmp_path / "lineage.json"), "--target", str(tmp_path / "final"), "--selection-horizon-months", "12",
        "--retained-full0-source-bundle", str(options["retained_full0_source_bundle"]),
        "--retained-q-archive", str(options["retained_q_archive"]),
        "--retained-q-producer-source-bundle", str(options["retained_q_producer_source_bundle"]),
        "--retained-score-root", str(options["retained_score_root"]),
        "--retained-score-producer-source-bundle", str(options["retained_score_producer_source_bundle"]),
        "--prepared-score-source-bundle", str(options["prepared_score_source_bundle"])])
    f5.main()
    assert calls == [True] and "ZERO_FIT_WIRING" in capsys.readouterr().out
