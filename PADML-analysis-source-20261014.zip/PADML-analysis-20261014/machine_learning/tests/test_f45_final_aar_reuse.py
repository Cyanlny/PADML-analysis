"""UNFITTED AAR final objects, independent line bindings and native pool boundaries.

The fixture seals synthetic whole metadata. It is not a clinical whole AAR and
does not stand in for branch development or a real cross-horizon validation.
"""
import copy
import shutil
import zipfile
from pathlib import Path

import pytest

from padml import f4, f5, f5_sensitivity as a, nested_loco as n, runtime
from padml.bundle import ContractError, canonical_json_bytes as encode, read_safe_zip, write_deterministic_zip
from test_f45_final_reuse import final_entries
from test_f45_final_primary_reuse import fixture as primary_fixture, pin, seal
from test_f5 import _test_final_design_recipe


def fixture(tmp_path, monkeypatch, branch, changed=0, missing_body=False):

    # Preserve original numeric consumers; only the existing pool transport is isolated.
    from padml import runtime
    import pickle
    def readback(function, items, **kwargs):
        result = []
        for item in items:
            fn, job = pickle.loads(pickle.dumps((function, item)))
            result.append(fn(job))
        return result
    monkeypatch.setattr(runtime, "_readback_ordered", readback)
    (request, _, lock, _, _), candidate, _, _, _ = primary_fixture(tmp_path, monkeypatch)
    with zipfile.ZipFile(Path(candidate['root'])/'result.zip') as archive:
        original_lock = f5.strict_json_bytes(archive.read('o-fit-execution.json'))['development_lock']
    context, science = request['training_context'], request['science_decision']
    policy = dict(configured_worker_ceiling=runtime.CPU_MINUS_8, memory_bytes_per_worker=2*1024**3,
        scratch_bytes_per_worker=16*1024**2, memory_reserve_bytes=0, scratch_reserve_bytes=0,
        transfer_archive_worker_ceiling=20)
    monkeypatch.setattr(runtime, 'observe_execution_resources', lambda root: dict(effective_cpus=32,
        available_memory_bytes=128*1024**3, scratch_available_bytes=128*1024**3, scratch_root=str(root)))
    def source(lock):
        return seal(dict(kind='PADML_F5_A12_PROJECTED_OUTER_INPUTS_V1', family='COX_PH', outer_fold=1,
            resource_policy=policy, primary_source=dict(program_id=n.PROGRAM_ID, estimand=n.A12_TOTAL_AAR,
                primary_training_context=context, primary_development_lock=lock, science_decision=science)))
    old_source, current_source = source(original_lock), source(lock)
    root = tmp_path/'aar-current'
    (root/'fits').mkdir(parents=True)
    owner = tmp_path/'AAR-H06-O1'
    native_root = owner/'result.zip.work'
    (native_root/'fits').mkdir(parents=True)
    curve = [1.] + [1-month*.01 for month in range(1,37)]
    def entries(source, branch, imp):
        result = final_entries('COX_PH','AAR',source['primary_source']['primary_development_lock']['selection_horizon_months'])
        task = f5.strict_json_bytes(result['task.json'])
        task.update(imputation=imp, row_count=40, training_event_count=40, registered_model_seed=301000+imp,
                    selected_parents=['Smoking'])
        task['a12_coordinates'].update(branch=branch, imputation=imp)
        bound = task['nested_aar_final_source']
        bound.update(primary_development_lock_sha256=source['primary_source']['primary_development_lock']['identity_sha256'],
            training_context_sha256=context['identity_sha256'], science_decision_sha256=science['identity_sha256'])
        if branch == n.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT:
            bound['epv_resolution'] = {'preferred_minimum':15,'minimum':15,'fallback_used':False,
                'coarse_records_sha256':'b'*64, 'attempts':[{'minimum':15,'alpha_feasibility':[
                    {'alpha':x,'status':'FEASIBLE'} for x in f5.load_science_authority()['science'][
                        'f2_model_development']['selector_contract']['alpha_grid']['coarse']]}], 'reason_code':'OK'}
        else:
            bound['epv_resolution'].update(primary_development_lock_sha256=bound['primary_development_lock_sha256'],
                training_event_count=40,common_set_epv=40.)
        result.update({'task.json':encode(task), 'fit-response.csv':('Patient_ID,All_Cause_Death,Death_Followup_months\n'
            + ''.join(f'{p},1,50\n' for p in context['training_ids'])).encode(),
            'fit-covariates.csv':('Patient_ID,Center,Smoking\n'+''.join(f'{p},38,0\n' for p in context['training_ids'])).encode(),
            'prediction-covariates.csv':b'Patient_ID,Center,Smoking\nh1,36,0\n',
            'recipe.json':encode(_test_final_design_recipe('COX_PH',['Smoking']))})
        return result
    def native(entry, directory):
        task,_,training,_,application = a._ablation_component_inputs(entry)
        prediction = a._ablation_prediction(task,application,[curve]*len(application))
        training_prediction = a._ablation_prediction(task,training,[curve]*len(training))
        value = {**entry,'model.bin':b'UNFITTED_MODEL','baseline.bin':b'UNFITTED_BASELINE',
            'fit-health.json':encode({'UNFITTED':True}),'prediction.json':encode(prediction),
            'training-prediction.json':encode(training_prediction['survival'])}
        archive = directory.with_suffix('.zip')
        write_deterministic_zip(archive,value)
        numbers = dict(input_members={k:{'sha256':n.sha256_bytes(v),'size_bytes':len(v)} for k,v in sorted(entry.items())},
            prediction=prediction,training_prediction=training_prediction,fit_health={'UNFITTED':True},
            object_audit={'design_columns':['Smoking1'],'training_event_count':40,'UNFITTED':True},
            model_sha256=n.sha256_bytes(value['model.bin']),baseline_sha256=n.sha256_bytes(value['baseline.bin']),
            native_archive=pin(archive),native_expanded_bytes=sum(map(len,value.values())))
        a._ablation_component_numbers(entry,numbers)
        directory.with_suffix('.numbers.json').write_bytes(encode(numbers))
        return numbers
    original_numbers={}
    for original_branch in n.AAR_ESTIMANDS:
        for imp in range(1,21):
            name=f'O1_{original_branch}_M{imp:02d}'
            original_numbers[name]=native(entries(old_source,original_branch,imp),native_root/'fits'/name)
    execution={'executor_source_identity':context['modeling_program_sha256']}
    (native_root/'execution.json').write_bytes(encode(execution))
    members={path.relative_to(native_root).as_posix():path for path in native_root.rglob('*') if path.is_file()}
    native_pins={k:pin(p) for k,p in members.items() if k.endswith('.zip')}
    if missing_body:
        members={name:path for name,path in members.items() if not name.endswith('.zip')}
    metadata=seal(dict(kind='PADML_F5_A12_OUTER_NATIVE_V2',source=old_source,family='COX_PH',outer_fold=1,
        predictions={'UNFITTED':True},native_members=native_pins,members={k:pin(p) for k,p in members.items()}))
    write_deterministic_zip(owner/'result.zip',{'a12-outer.json':encode(metadata),**members})
    if missing_body:
        (native_root/f'fits/O1_{branch}_M20.zip').unlink()  # Owned disposable fixture only.
    write_deterministic_zip(owner/'input.zip',{'UNFITTED.json':b'{}'})
    (owner/'input.compile.json').write_bytes(b'{}')
    receipt=dict(status='COMPLETED',direct_consumer_completed=True,unit_id=owner.name,
        selection_horizon_months=6,report_horizons_months=[6,12,24,36],run_identity='e'*64,
        artifacts={name:pin(owner/name) for name in ('input.zip','input.compile.json','result.zip')})
    (owner/'unit.json').write_bytes(encode(receipt))
    prepared=dict(source=current_source,family='COX_PH',outer_fold=1,
        completed_aar_units=[dict(root=str(owner),receipt=receipt)])
    jobs=[]
    for imp in range(1,21):
        entry=entries(current_source,branch,imp)
        if imp>20-changed:
            entry['fit-covariates.csv']=entry['fit-covariates.csv'].replace(b'p00,38,0',b'p00,38,1')
        name=f'O1_{branch}_M{imp:02d}'
        jobs.append(dict(name=name,entries=entry,root=str(root/'fits'/name),
            consumer_source=current_source,retained_bytes_per_component=16*1024**2))
    calls=dict(fit=0,replay=0,audit=0,pools=[])
    def engine(family,task,covariates,response,recipe,**kwargs):
        calls['replay' if kwargs.get('retained_objects') is not None else 'fit']+=1
        predicted=kwargs.get('prediction_rows') or covariates
        return dict(model=b'UNFITTED_MODEL',baseline=b'UNFITTED_BASELINE',fit_health={'UNFITTED':True},
                    survival=[curve]*len(predicted),training_survival=[curve]*len(covariates))
    def audit(*args,**kwargs):
        calls['audit']+=1
        return {'design_columns':['Smoking1'],'training_event_count':40,'UNFITTED':True}
    def pool(function,jobs,*,selected_slots,execution_report):
        assert jobs
        calls['pools'].append(len(jobs))
        rows=[function(job) for job in jobs]
        execution_report.update(status='COMPLETED',runnable_task_count=len(jobs),completed_task_count=len(jobs),
            configured_worker_ceiling=24,admitted_worker_ceiling=selected_slots,engine_threads=1,actual_worker_process_peak=1)
        return rows
    monkeypatch.setattr(f5,'_execute_final_refit_engine',engine)
    monkeypatch.setattr(f5,'_validate_retained_model_objects',audit)
    monkeypatch.setattr(a,'_bounded_ordered_spawn',pool)
    return prepared,root,jobs,calls,native_root,original_numbers


@pytest.mark.parametrize('branch,changed,missing_body',[(b,0,False) for b in n.AAR_ESTIMANDS]+[
    (n.A12_DIRECT_AAR,1,False),(n.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT,20,False),(n.A12_TOTAL_AAR,0,True)])
def test_aar_final_reuse_native_pool_and_original_archive(tmp_path,monkeypatch,branch,changed,missing_body):
    prepared,root,jobs,calls,original,numbers=fixture(tmp_path,monkeypatch,branch,changed,missing_body)
    hashes={p:pin(p) for p in original.rglob('*') if p.is_file()}
    reused=a._prepare_a12_final_reuse(prepared,root,jobs)
    count=changed+int(missing_body)
    assert len(reused)==20-count
    record={'final_model_pool':{}}
    rows=a._a12_execute_final_pool(jobs,reused,max(1,count),record)
    assert len(rows)==20 and calls['fit']==calls['audit']==count and calls['replay']==2*count
    assert calls['pools']==([] if not count else [count])
    if reused:
        assert record['reused_final_model_count']==20-count and record['physical_final_model_count']==count
    if not count:
        assert record['final_model_pool']=={}
    assert hashes=={p:pin(p) for p in hashes}
    payload={name:root/name for name in a._a12_final_reuse_members(root,1,(branch,))}
    payload.update({p.relative_to(root).as_posix():p for p in (root/'fits').iterdir()
                    if p.name.endswith(('.zip','.numbers.json'))})
    archive=tmp_path/'aar-final-boundary.zip'
    write_deterministic_zip(archive,payload,stored_members=set(payload))
    consumer=tmp_path/'archive-consumer'
    for name,raw in read_safe_zip(archive).items():
        path=consumer/name
        path.parent.mkdir(parents=True,exist_ok=True)
        path.write_bytes(raw)
    before=copy.deepcopy(calls)
    for job,row in zip(jobs,rows,strict=True):
        assert a._replay_ablation_component(dict(entries=job['entries'],
            numbers_path=consumer/'fits'/(job['name']+'.numbers.json'),native_archive=pin(consumer/'fits'/(job['name']+'.zip')),
            retained_bytes_per_component=job['retained_bytes_per_component'],consumer_source=prepared['source']))==row
    assert calls==before


def test_aar_reuse_keeps_pending_owner_and_rejects_drift(tmp_path,monkeypatch):
    branch=n.A12_DIRECT_AAR
    prepared,root,jobs,calls,original,numbers=fixture(tmp_path,monkeypatch,branch)
    with monkeypatch.context() as failed:
        failed.setattr(f5,'_f45_retain_final_object',lambda *args: (_ for _ in ()).throw(OSError('UNFITTED interruption')))
        with pytest.raises(OSError,match='interruption'):
            a._prepare_a12_final_reuse(prepared,root,jobs)
    assert len(list((root/'fits').glob('*.reuse.json')))==1 and not list((root/'fits').glob('*.zip'))
    with pytest.raises(ContractError,match='PENDING_ORIGINAL_OBJECT_REQUIRED'):
        a._prepare_a12_final_reuse({**prepared,'completed_aar_units':[]},root,jobs)
    assert len(a._prepare_a12_final_reuse(prepared,root,jobs))==20
    job=jobs[0]
    binding=f5.strict_json_bytes(Path(job['root']).with_suffix('.reuse.json').read_bytes())
    source=root/binding['source']['path']
    raw=source.read_bytes()
    source.write_bytes(raw+b' ')
    with pytest.raises(ContractError,match='SOURCE_DRIFT'):
        a._a12_final_reuse_read(prepared['source'],root,job['entries'],binding)
    source.write_bytes(raw)
    with monkeypatch.context() as failed:
        failed.setattr(f5,'_f45_score_reuse_authorities',lambda:({},{}))
        with pytest.raises(ContractError,match='SOURCE_INVALID'):
            a._a12_final_reuse_read(prepared['source'],root,job['entries'],binding)
    archive=Path(job['root']).with_suffix('.zip')
    archive.write_bytes(archive.read_bytes()+b'UNFITTED_DAMAGE')
    with pytest.raises(ContractError,match='NATIVE_OBJECT_DRIFT'):
        a._a12_final_reuse_read(prepared['source'],root,job['entries'],binding)
    assert calls==dict(fit=0,replay=0,audit=0,pools=[])


def test_aar_whole_members_carry_models_and_only_prefix_provenance(tmp_path,monkeypatch):
    """Exercise the actual member/reservation boundary; selector leaves are UNFITTED."""
    root=tmp_path/'whole'
    (root/'fits').mkdir(parents=True)
    (root/'development/selector').mkdir(parents=True)
    (root/'development/development.json').write_bytes(b'{}')
    selector=root/'development/selector/development-input.json'
    selector.write_bytes(b'{}')
    monkeypatch.setattr(f5,'_nested_selector_numerical_members',lambda path:{'development-input.json':selector})
    (root/'execution.json').write_bytes(b'{}')
    (root/'inputs.zip').write_bytes(b'UNFITTED_INPUT')
    proof=root/'final-reuse/AAR-H06-O1/source.json'
    (proof.parent/'fits').mkdir(parents=True)
    proof.write_bytes(b'{}')
    jobs=[]
    for branch in n.AAR_ESTIMANDS:
        for imp in range(1,21):
            name=f'O1_{branch}_M{imp:02d}'
            number={'UNFITTED':True,'reused_final':dict(component=name,source=dict(
                path=proof.relative_to(root).as_posix(),**pin(proof)))}
            (root/'fits'/(name+'.numbers.json')).write_bytes(encode(number))
            (root/'fits'/(name+'.zip')).write_bytes(b'UNFITTED_NATIVE')
            (proof.parent/'fits'/(name+'.numbers.json')).write_bytes(b'{}')
            jobs.append(dict(name=name,entries={'UNFITTED':b'not a clinical input'}))
    policy=dict(configured_worker_ceiling=runtime.CPU_MINUS_8,memory_bytes_per_worker=2*1024**3,
        memory_reserve_bytes=0,scratch_bytes_per_worker=1024**2,scratch_reserve_bytes=0,
        transfer_archive_worker_ceiling=20)
    source=dict(kind='PADML_F5_A12_PROJECTED_OUTER_INPUTS_V1',family='COX_PH',outer_fold=1,
        resource_policy=policy,primary_source=dict(primary_training_context=dict(heldout_ids=['UNFITTED'])))
    prepared=dict(source=source)
    full=a._a12_outer_retained_members(root,'COX_PH',1,root/'inputs.zip',prepared=prepared)
    assert len([x for x in full if x.startswith('fits/') and x.endswith('.zip')])==60
    for index in range(1,4):
        shared=a._a12_outer_retained_members(root,'COX_PH',1,root/'inputs.zip',prepared=prepared,
            before_final=True,completed_branches=n.AAR_ESTIMANDS[:index])
        assert len([x for x in shared if x.startswith('final-reuse/') and x.endswith('.numbers.json')])==20*index
        assert not any(x.startswith('fits/') for x in shared)
        reservation=a._a12_final_resource_reservation(source,jobs[:20*index],{k:v.stat().st_size for k,v in shared.items()},
            1024**2,allow_partial=True,execution_worker_memory_bytes=2*1024**3,execution_scratch_reserve_bytes=0)
        assert reservation['archive_reserved_bytes']>=2*sum(p.stat().st_size for p in full.values())
    (root/'fits'/(jobs[-1]['name']+'.zip')).unlink()
    with pytest.raises(ContractError,match='NATIVE_COVERAGE_INVALID'):
        a._a12_outer_retained_members(root,'COX_PH',1,root/'inputs.zip',prepared=prepared)


@pytest.mark.parametrize('shared',[0,19,60])
def test_aar_final_accounting_keeps_logical_and_physical_counts_separate(tmp_path,shared):
    """Pure whole counter consumer, explicitly not scientific archive acceptance."""
    science=f5.strict_json_bytes((Path(__file__).parents[1]/'science-decision.json').read_bytes())
    source=dict(kind='PADML_F5_A12_PROJECTED_OUTER_INPUTS_V1',mice_inputs=[{}]*34,
        primary_source=dict(science_decision=science))
    mice=tmp_path/'mice.zip'
    write_deterministic_zip(mice,{'a12-inputs.json':b'{}'})
    members={'inputs.zip':mice,'development/selector/development-input.json':encode(dict(
        selector_path_count=640,glmnet_call_count=1280))}
    for index,(branch,imp) in enumerate((b,i) for b in n.AAR_ESTIMANDS for i in range(1,21)):
        members[f'fits/O1_{branch}_M{imp:02d}.numbers.json']=encode({'UNFITTED':True,
            **({'reused_final':{'UNFITTED_COUNTER_ONLY':True}} if index<shared else {})})
    path=tmp_path/'whole-counts.zip'
    write_deterministic_zip(path,members)
    result=a._a12_outer_archive_record(dict(family='COX_PH',outer_fold=1,identity_sha256='a'*64,
        source=source,members=members),path)
    assert result['execution_ledger']['post_lock_fits']==60-shared
    assert result['execution_ledger']['total_model_fits']==60-shared
    if shared:
        assert result['logical_execution_ledger']['post_lock_fits']==60
        assert result['reused_execution_ledger']['post_lock_fits']==shared
    else:
        assert 'reused_execution_ledger' not in result
