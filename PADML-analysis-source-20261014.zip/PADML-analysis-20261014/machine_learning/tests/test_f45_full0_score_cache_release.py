"""UNFITTED regression for completed-Q cache pressure before FULL0 scoring."""
import os
from pathlib import Path

import pytest

from padml import f5, f4_compact, nested_loco as n, runtime
from padml.bundle import ContractError, canonical_json_bytes, sha256_file


def test_completed_q_reader_releases_cache_without_changing_science(tmp_path, monkeypatch):
    # Scientific leaves are synthetic; the production coordinator, ownership,
    # file advice and post-read resource admission are the tested boundary.
    run = tmp_path
    context = run / "contexts/FULL0"
    selector = context / "common/selector"
    selector.mkdir(parents=True)
    root = run / "units/FULL0-H06/search/GBM_COX"
    root.mkdir(parents=True)
    model = root / "model.rds"
    model.write_bytes(b"UNFITTED_MODEL_BYTES")
    cache = context / "q-atoms"
    cache.mkdir()
    os.link(model, cache / "original-model.rds")
    foreign = run / "units/FULL0-H12/search/GBM_COX"
    foreign.mkdir(parents=True)
    os.link(model, foreign / "same-original-model.rds")
    untouched = run / "protected"
    untouched.write_bytes(b"UNRELATED")
    cov = context / "imp01.csv"
    cov.write_bytes(b"UNFITTED_COVARIATES")
    response = context / "response.csv"
    response.write_bytes(b"UNFITTED_RESPONSE")
    (run / "run.json").write_bytes(canonical_json_bytes({"run_root": str(run)}))
    monkeypatch.setenv("PADML_F45_RUN_PATH", str(run / "run.json"))
    monkeypatch.setenv("PADML_F45_Q_REUSE_ROOT", str(cache))
    monkeypatch.setattr(f5, "resolve_pool_workers", lambda w: 1)
    monkeypatch.setattr(f5, "_full_development_science_decision", lambda x, **k: x)
    selected = ["UNFITTED"]
    decision = {"UNFITTED": True}
    development = n._sealed({"program_id": "UNFITTED", "selector": {
        "selected_parents": selected, "alpha": .5,
        "selected_ratio_by_imputation": [], "lambda_by_imputation": [],
        "lambda_upper_bound_by_imputation": []}})
    monkeypatch.setattr(f5, "_nested_full_selector_program", lambda *a, **k: development)
    monkeypatch.setattr(f5, "_validate_nested_full_selector_development",
        lambda *a, **k: (selected, {"recipe_set_sha256": "a"*64}))
    monkeypatch.setattr(n, "_covariate_ids", lambda *a: (["p1"], [], {"p1": "38"}))
    monkeypatch.setattr(n, "compile_training_context", lambda **k: {"UNFITTED": True})
    monkeypatch.setattr(f5, "_validate_final_refit_locked_spec", lambda *a: None)
    monkeypatch.setattr(f5, "_compile_full_complex_search_task_body", lambda *a, **k: {"UNFITTED": True})
    spec = {"family": "GBM_COX", "UNFITTED": True}
    result = n._sealed({"selected_parents": selected, "selected_spec": spec,
                       "selected_spec_sha256": n._sha(spec)})
    events = []
    monkeypatch.setattr(f5, "_final_complex_search_program",
        lambda *a, **k: (events.append("reader_returned") or result))
    pins = {"model.rds": {"sha256": sha256_file(model), "size_bytes": model.stat().st_size}}
    def inventory(actual):
        assert actual == root and sha256_file(model) == pins["model.rds"]["sha256"]
        events.append("inventory_returned")
        return {}, pins
    monkeypatch.setattr(f4_compact, "_full_pipeline_q_numerical_members", inventory)
    original = {p: (p.read_bytes(), p.stat().st_ino, p.stat().st_mtime_ns, p.stat().st_ctime_ns)
                for p in (model, cache/"original-model.rds", foreign/"same-original-model.rds", untouched)}
    policy = {"configured_worker_ceiling": runtime.CPU_MINUS_8, "memory_bytes_per_worker": 2*1024**3,
        "memory_reserve_bytes": 4*1024**3, "scratch_bytes_per_worker": 1,
        "scratch_reserve_bytes": 0, "transfer_archive_worker_ceiling": 24}
    state = {"evicted": False}
    def observe(path):
        return {"effective_cpus":32, "available_memory_bytes": (60 if state["evicted"] else 2)*1024**3,
            "scratch_available_bytes": 10**12, "scratch_root":str(path)}
    monkeypatch.setattr(runtime, "observe_execution_resources", observe)
    monkeypatch.setattr(runtime.sys, "platform", "linux")
    def scan(keys):
        raise AssertionError("F45 cache advice must not scan unrelated readers")
    monkeypatch.setattr(runtime, "_visible_open_file_keys", scan)
    monkeypatch.setattr(os, "POSIX_FADV_DONTNEED", 4, raising=False)
    def advise(fd, offset, length, advice):
        assert events == ["reader_returned", "inventory_returned"]
        assert os.fstat(fd).st_ino == model.stat().st_ino
        state["evicted"] = True
    monkeypatch.setattr(os, "posix_fadvise", advise, raising=False)
    plan = {"source_ids":["p1"], "patient_keys":["k1"],
        "resampling_center_sha256": n._sha([{"patient_key":"k1","center":38}])}
    full = {"covariates":{"input_dir":str(context),"members":[{"name":"imp01.csv",
        "sha256":sha256_file(cov), "size_bytes":cov.stat().st_size}]},
        "fit_response":{"path":str(response)}}
    with pytest.raises(ContractError, match="RESOURCE_ADMISSION_ZERO"):
        runtime.resource_admission(policy, observe(root), legal_tasks=2100)
    # A no-advice reference run returns the same scientific result.
    with monkeypatch.context() as no_advice:
        no_advice.setattr(runtime, "release_completed_files", lambda *a, **k: {})
        reference = f5._nested_full_score_development(plan, [], full, selector, {"GBM_COX":root},
            rscript="UNFITTED", workers=1, family="GBM_COX", science_decision=decision)
    events.clear()
    actual = f5._nested_full_score_development(plan, [], full, selector, {"GBM_COX":root},
        rscript="UNFITTED", workers=1, family="GBM_COX", science_decision=decision)
    assert actual == reference and actual["new_stop_fits"] == actual["new_mice_chains"] == 0
    assert original == {p:(p.read_bytes(),p.stat().st_ino,p.stat().st_mtime_ns,p.stat().st_ctime_ns) for p in original}
    reports = list((selector.parent/"resource-release").glob("*.json"))
    assert len(reports) == 1
    report = f5.strict_json_bytes(reports[0].read_bytes())
    assert report["files_deleted"] == 0 and report["error"] is None
    assert len(report["release"]["files"]) == 1 and report["aliases"] == {}
    assert report["release"]["reader_scan_status"] == "WAIVED_BY_USER"
    assert runtime.resource_admission(policy, observe(root), legal_tasks=2100)["admitted_worker_ceiling"] == 24
    assert report["release"]["files"][0]["status"] == "ADVISED"

@pytest.mark.parametrize("change", ["qualified", "unknown_producer", "patient", "parameter", "unsealed"])
def test_score_resume_retains_only_exact_qualified_original_development(tmp_path, monkeypatch, change):
    import copy
    from padml import f4
    current_members = f4._f45_source_member_sha256()
    previous_members = {**current_members, "padml/f5.py": "a"*64}
    keys = {*f5._final_search_sources(), *("padml/"+name for name in (
        "nested_loco.py", "runtime.py", "f2_validation.py", "kernels/f5_final_refit.R",
        "kernels/f5_design.R", "kernels/f4_learning_selector.R", "kernels/f4_learning_recipe.R"))}
    program = lambda members: n._sha({key:members[key] for key in keys})
    ids = [f"p{i:02}" for i in range(40)]
    response = ("Patient_ID,All_Cause_Death,Death_Followup_months\n"
        + "".join(f"{p},1,50\n" for p in ids)).encode()
    old_context = n.compile_training_context(scope="FULL_DATA", outer_fold=0,
        heldout_center=None, training_ids=ids, heldout_ids=[], centers_by_patient={p:"38" for p in ids},
        training_response_csv=response, mice_member_set_sha256="b"*64,
        preprocessing_program_sha256=program(previous_members), modeling_program_sha256=program(previous_members),
        seed_program_sha256="c"*64)
    new_context = n._sealed({**{k:v for k,v in old_context.items() if k!="identity_sha256"},
        "preprocessing_program_sha256": program(current_members), "modeling_program_sha256":program(current_members)})
    old = n._sealed({"training_context":old_context,"selection_horizon_months":6,
        "locked_specs":{"GBM_COX":{"selected_trees":100}},"complex_search_evidence":[{"original_producer":"d"*64}]})
    current = n._sealed({**{k:v for k,v in old.items() if k!="identity_sha256"},
        "training_context":new_context})
    request = n._sealed({"kind":"PADML_NESTED_FULL_SCORE_INPUT_V1","training_context":old_context,
        "development":old})
    if change=="patient":
        current["training_context"]=n._sealed({**{k:v for k,v in new_context.items() if k!="identity_sha256"},
            "training_ids_sha256":"f"*64})
    elif change=="parameter":
        current["locked_specs"]={"GBM_COX":{"selected_trees":101}}
    current=n._sealed({k:v for k,v in current.items() if k!="identity_sha256"})
    if change=="unsealed":request["identity_sha256"]="f"*64
    path=tmp_path/"full-score-input.json"
    raw=canonical_json_bytes(request)
    path.write_bytes(raw)
    before=(path.stat().st_ino,path.stat().st_mtime_ns,path.stat().st_ctime_ns)
    sources={"current":current_members}
    if change!="unknown_producer":sources["previous"]=previous_members
    monkeypatch.setattr(f5,"_f45_score_reuse_authorities",lambda:({},sources))
    if change=="qualified":
        assert f5._full_score_resume_development(current,path)==old
        assert f5._full_score_resume_development(old,path)==old
    else:
        with pytest.raises(ContractError):
            f5._full_score_resume_development(current,path)
    assert path.read_bytes()==raw
    assert before==(path.stat().st_ino,path.stat().st_mtime_ns,path.stat().st_ctime_ns)


def test_full0_canonical_mice_membership_is_scanned_once_and_rejects_changed_sources(tmp_path, monkeypatch):
    # Real CSV schema, row/Center scanner and persistent qualification; selector
    # and model leaves remain explicitly unfitted engineering fixtures.
    import csv
    import io
    import time
    fields = f5.load_science_authority()["science"]["mice"]["private_handoff"]["columns"]
    centers = {"p1": "36", "p2": "38"}
    def csv_bytes(order, altered=False):
        stream = io.StringIO(newline="")
        writer = csv.DictWriter(stream, fieldnames=fields); writer.writeheader()
        for patient in order:
            writer.writerow({**{name: "1" for name in fields}, "Patient_ID": patient,
                "Center": ("38" if altered and patient == "p1" else centers[patient])})
        return stream.getvalue().encode()
    def part(name, order):
        folder = tmp_path / name / "covariates"; folder.mkdir(parents=True)
        members = []
        for i in range(1, 21):
            path = folder / f"imp{i:02}.csv"; path.write_bytes(csv_bytes(order))
            members.append({"name": path.name, "sha256": sha256_file(path), "size_bytes": path.stat().st_size})
        return {"application_ids": order, "covariates": {"input_dir": str(folder), "members": members}}
    full, inner = part("full", ["p1", "p2"]), part("inner", ["p2", "p1"])
    response = tmp_path / "response.csv"; response.write_bytes(b"UNFITTED RESPONSE")
    full["fit_response"] = {"path": str(response)}
    plan = {"source_ids": ["p1", "p2"], "patient_keys": ["k1", "k2"],
        "resampling_center_sha256": n._sha([{"patient_key": "k1", "center": 36}, {"patient_key": "k2", "center": 38}])}
    selector = tmp_path / "selector"; selector.mkdir()
    development = {"program_id": "UNFITTED", "selector": {"selected_parents": ["Age"],
        "alpha": .5, "selected_ratio_by_imputation": [], "lambda_by_imputation": [],
        "lambda_upper_bound_by_imputation": []}}
    monkeypatch.setattr(f5, "resolve_pool_workers", lambda w: 1)
    monkeypatch.setattr(f5, "_full_development_science_decision", lambda x, **k: x)
    monkeypatch.setattr(f5, "_nested_full_selector_program", lambda *a, **k: development)
    monkeypatch.setattr(f5, "_validate_nested_full_selector_development",
        lambda *a, **k: (["Age"], {"recipe_set_sha256": "a" * 64}))
    monkeypatch.setattr(f5, "_validate_final_refit_locked_spec", lambda *a: None)
    monkeypatch.setattr(n, "compile_training_context", lambda **kw: {"UNFITTED": True})
    now = time.time_ns(); monkeypatch.setattr(time, "time_ns", lambda: now + 3_000_000_000)
    csv_reads = []
    original = Path.read_bytes
    def read(path):
        if path.name.startswith("imp") and path.suffix == ".csv": csv_reads.append(path)
        return original(path)
    monkeypatch.setattr(Path, "read_bytes", read)
    def run(family="COX_PH", horizon=6):
        return f5._nested_full_score_development(plan, [inner], full, selector, {}, rscript="UNFITTED",
            workers=1, family=family, selection_horizon_months=horizon, science_decision={"UNFITTED": True})
    run()
    assert len(csv_reads) == 41  # full imp01 plus the first 40-member scientific scan
    records = list(tmp_path.glob("*/covariates-score-membership.qualified.json"))
    assert len(records) == 2
    run("ELASTIC_NET_COX", 12); run("COX_PH", 24)
    assert len(csv_reads) == 43  # subsequent families/windows only read full imp01
    changed = Path(inner["covariates"]["input_dir"]) / "imp02.csv"
    changed.write_bytes(csv_bytes(["p2", "p1"], altered=True))
    with pytest.raises(ContractError, match="RAW_QUALIFIED_BYTES_DRIFT"):
        run()
    # Even a newly supplied byte pin cannot bless changed patient/Center meaning.
    inner["covariates"]["members"][1].update(sha256=sha256_file(changed), size_bytes=changed.stat().st_size)
    with pytest.raises(ContractError, match="NESTED_FULL_SCORE_MICE_CENTER_DRIFT"):
        run()


@pytest.mark.parametrize('fail_second', [False, True])
def test_q_r_child_closed_before_completed_atom_advice(tmp_path, monkeypatch, fail_second):
    from padml import f4
    events, produced = [], []
    class Child:
        def __init__(self):
            self.closed = False
        def close(self):
            self.closed = True
            events.append('child-closed')
    child = Child()
    monkeypatch.setattr(f4, '_NativeRSmallBatch', lambda: child)
    monkeypatch.setattr(f4, '_CURRENT_R_BATCH', None)
    failure = ContractError('ENGINEERING_SECOND_ATOM_FAILED')
    def result(job):
        root = tmp_path / str(job['i'])
        root.mkdir()
        (root / 'values.json').write_bytes(b'unchanged')
        if job['i'] == 2 and fail_second:
            raise failure
        value = {'root':str(root), 'receipt':{'members':{'values.json':{}}},
                 'value':{'scientific-number':job['i']}}
        produced.append(value)
        return value
    monkeypatch.setattr(f5, '_current_q_atom_result', result)
    monkeypatch.setattr(f5, '_current_q_cache_files', lambda job: {tmp_path / str(job['i']) / name
        for name in ('input.json','producer.json','values.json','audit.json','receipt.json')})
    def advice(paths, **kwargs):
        assert child.closed and f4._CURRENT_R_BATCH is None
        assert set(paths) == {tmp_path / str(i) / name
            for i in (1, 2)
            for name in ('input.json','producer.json','values.json','audit.json','receipt.json')}
        events.append('advice')
        return {}
    monkeypatch.setattr(runtime, 'advise_completed_io', advice)
    jobs = [{'i':i,'control':{}} for i in (1,2)]
    if fail_second:
        with pytest.raises(ContractError) as caught:
            f5._current_q_r_small_batch(jobs)
        assert caught.value is failure
    else:
        assert f5._current_q_r_small_batch(jobs) == produced
    assert events == ['child-closed','advice']
    assert all((Path(row['root'])/'values.json').read_bytes() == b'unchanged' for row in produced)


def test_shap_collection_drops_maps_before_advice(tmp_path, monkeypatch):
    import gc, weakref
    import numpy as np
    component = f5._ShapComponent({'scientific-number':7})
    paths, maps, arrays = {}, [], []
    for key in ('risk_contributions','standard_errors','predicted_risk'):
        path = tmp_path / (key + '.f64')
        path.write_bytes(np.arange(8,dtype='<f8').tobytes())
        value = np.memmap(path,dtype='<f8',mode='r',shape=(2,4))
        arrays.append(weakref.ref(value)); maps.append(weakref.ref(value._mmap))
        component[key] = value
        paths[key] = path
    del value
    checkpoint = tmp_path/'checkpoint.zip'
    checkpoint.write_bytes(b'engineering-existing-checkpoint')
    component.qualification_paths = {'checkpoint':checkpoint, **paths}
    record = {'archive_sha256':'a'*64,'archive_size_bytes':checkpoint.stat().st_size,
              'component_sha256':'b'*64}
    seen = []
    def advice(files, **kwargs):
        gc.collect()
        assert all(ref() is None for ref in [*maps,*arrays])
        seen.extend(files)
    monkeypatch.setattr(runtime, 'advise_completed_io', advice)
    result = f5._shap_collection_result(component,record,checkpoint,1)
    assert component == {}
    assert set(seen) == {checkpoint,*paths.values()}
    assert result['component'] == {'kind':'PADML_SHAP_CHECKPOINT_REFERENCE_V1','imputation':1,
        'path':str(checkpoint),**record}
    assert checkpoint.read_bytes() == b'engineering-existing-checkpoint'


def test_shap_mapping_remains_valid_until_last_derived_view_closes(tmp_path, monkeypatch):
    import gc
    import numpy as np
    path = tmp_path / 'shap.f64'; path.write_bytes(np.arange(8,dtype='<f8').tobytes())
    array = np.memmap(path,dtype='<f8',mode='r',shape=(2,4))
    view = np.asarray(array)[1:]
    runtime.track_cache_mapping(array, path)
    rows = []
    monkeypatch.setattr(runtime, 'advise_consumed_stream', lambda *a, **kw: rows.append(kw) or 'ADVISED')
    del array
    gc.collect()
    runtime.advise_completed_io([path], sync=False)
    assert not rows and view.tolist() == [[4.,5.,6.,7.]]
    del view
    gc.collect()
    runtime.drain_completed_io()
    assert rows and path.is_file()
