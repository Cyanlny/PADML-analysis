"""Original public/batch/scoring/replay chain on UNFITTED fixed-family curves."""
import copy
from pathlib import Path

import pytest

from padml import f2_kernel, f4, f5, nested_loco as nested, runtime
from padml.bundle import ContractError, canonical_json_bytes, strict_json_bytes
from test_full0_cox_retained_inputs import pair, reseal
from test_full0_fixed12_rescore import forbidden
from test_nested_full_score import operational_budget  # noqa: F401


ORIGINAL_RECOMPUTE = nested._recompute_fresh_score_from_evidence
ORIGINAL_EXECUTION_VALIDATOR = nested.validate_fresh_score_execution


def assert_original_final_consumer(root, family, monkeypatch):
    """Reopen completed synthetic artifacts through the unchanged final entry."""
    report = strict_json_bytes((root / f"score-execution.{family}.json").read_bytes())
    request = report["request"]
    before = {path: path.read_bytes() for path in root.rglob("*") if path.is_file()}
    calls = []
    def numbers(**kwargs):
        if kwargs["execution"]["family"] != family:
            return kwargs["score"]
        assert kwargs["retained_request_root"] == Path(report["retained_score_root"]) / "request"
        calls.append(family)
        return ORIGINAL_RECOMPUTE(**kwargs)
    class ReachedFinalSelectionBoundary(Exception):
        pass
    def decision(value, *args, **kwargs):
        assert value == {"UNFITTED_OTHER_FAMILIES": True}
        if not args:  # The final compiler, after its complete-score consumer.
            raise ReachedFinalSelectionBoundary
        return value
    monkeypatch.setattr(nested, "_recompute_fresh_score_from_evidence", numbers)
    monkeypatch.setattr(nested, "validate_fresh_score_execution", lambda value:
        ORIGINAL_EXECUTION_VALIDATOR(value) if value["family"] == family else value)
    monkeypatch.setattr(nested, "validate_family_decision", decision)
    monkeypatch.setattr(nested, "select_training_family", lambda scores: {"UNFITTED_OTHER_FAMILIES": True})
    monkeypatch.setattr(f5, "_compile_full_score_inputs", lambda *a, **k: request)
    monkeypatch.setattr(f5, "_full_score_storage_usage", lambda *a, **k: {})
    monkeypatch.setattr(f5, "_full_score_resource_admission", lambda *a, **k: (
        {"admitted_worker_ceiling": 1, "limits": {"configured": 56}}, {"retained_result_json_bytes": 10**7}))
    for name in ("_full_score_job_inputs", "_score_archive_expanded_limit", "_validate_final_r_fit_health",
                 "_validate_retained_r_audit_numbers"):
        monkeypatch.setattr(f5, name, lambda *a, **k: None)
    for name in ("_execute_and_verify_score_archive_job", "_replay_component_job"):
        monkeypatch.setattr(f5, name, forbidden)
    monkeypatch.setattr(runtime, "_bounded_ordered_spawn", forbidden)
    monkeypatch.setattr(nested, "_score_fresh_family", forbidden)
    column_map = f2_kernel._expected_family_parent_column_map
    monkeypatch.setattr(f2_kernel, "_expected_family_parent_column_map", lambda parents, own, predictors, recipe:
        [{"columns": ["AST_ALT", "Age"]}] if recipe.get("fixture") is True
        else column_map(parents, own, predictors, recipe))
    parent = root.parent
    with pytest.raises(ReachedFinalSelectionBoundary):
        f5._compile_full_final_inputs({}, [], {"covariates": {"input_dir": str(parent / "mice")}},
            parent / "selector", {}, root, parent / "final", rscript="FORBIDDEN", resource_policy={},
            retained_bytes_per_component=10**6, expanded_bytes_per_component=10**6, shared_storage_bytes=10**8,
            selection_horizon_months=12, science_decision=request["science_decision"],
            retained_full0_source_bundle=parent / "primary.zip", retained_q_archive=parent / "q.zip",
            retained_q_producer_source_bundle=parent / "q-source.zip")
    assert calls == [family] and not (parent / "final").exists()
    assert {path: path.read_bytes() for path in root.rglob("*") if path.is_file()} == before


@pytest.mark.parametrize("family", ["ELASTIC_NET_COX", "FPM_TVC_SET_A"])
def test_public_fixed_reuse_actual_batches_readback_and_common_consumer(
        tmp_path, monkeypatch, operational_budget, family):
    bundle = tmp_path / "current-source.zip"
    f4.compile_f45_source_bundle(bundle)
    members = f4._f45_source_member_sha256()
    identity = nested._sha(members)
    keys = {*f5._final_search_sources(), *("padml/" + name for name in (
        "nested_loco.py", "runtime.py", "f2_validation.py", "kernels/f5_final_refit.R", "kernels/f5_design.R",
        "kernels/f4_learning_selector.R", "kernels/f4_learning_recipe.R"))}
    program = nested._sha({key: members[key] for key in keys})
    old, request, request_root, jobs, handles, originals = pair(
        tmp_path, old_program=program, new_program=program, family=family)
    # Only this family's actual 300 inputs are exercised. Other records are
    # the common coordinate table, not a claim of seven-family science.
    request["component_records"] = [{**row, "family": other,
        "path": row["path"].replace(family, other)}
        for other in nested._families() for row in request["component_records"]]
    request = reseal(request)
    root = tmp_path / "score.all"
    request_root.parent.rename(root)
    old_root = tmp_path / "old"
    (old_root / "request" / f"full-score-input.{family}.json").write_bytes(canonical_json_bytes(old))
    (root / "request/full-score-input.json").write_bytes(canonical_json_bytes(request))
    prepared = dict(request=request, result=None, task_ids=[row["path"] for row in request["component_records"]],
        input_execution_report=str(root / "input-execution.json"), new_model_fits=0,
        new_model_native_verification_count=0, native_model_replay_count=0,
        input_release_error="UNKNOWN_NOT_RETRIED")
    (root / "input-execution.json").write_bytes(canonical_json_bytes(prepared))
    policy = {**operational_budget, "memory_bytes_per_worker": 2 * 1024**3}
    budgets = dict(retained_bytes_per_component=10**6, expanded_bytes_per_component=10**6, shared_storage_bytes=10**8)
    batches = []
    for index in range(2):
        batch = old_root / f"score-batches/part{index}"
        records = old["component_records"][150 * index:150 * (index + 1)]
        own_handles = handles[150 * index:150 * (index + 1)]
        for record, handle in zip(records, own_handles, strict=True):
            source = old_root / "score-evidence" / family / (Path(record["path"]).stem + ".json")
            target = batch / source.relative_to(old_root)
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(originals[source])
            # Only the synthetic duplicate is removed. The batch is the sole
            # retained numerical original, and its exact bytes are preserved.
            source.unlink()
            handle.update(state="COMPLETE", archive_size_bytes=100, retained_size_bytes=1000,
                coordinate_identity=nested._sha({"training_context_sha256": old["training_context"]["identity_sha256"],
                    "record": record}))
        admission, reserve = f5._full_score_resource_admission(policy, old_root, **budgets,
            component_count=2100, request=old, assigned_component_count=150,
            verified_retained_credit_bytes=sum(row["size_bytes"] for row in records), execution_scratch_reserve_bytes=0)
        execution = dict(source_identity=identity, operational_identity=runtime.OPERATIONAL_IDENTITY,
            request_identity_sha256=old["identity_sha256"], training_context_sha256=old["training_context"]["identity_sha256"],
            score_partitions_sha256=nested._sha(old["score_partitions"]), task_ids=[row["path"] for row in records],
            archive_handles=own_handles, resource_policy=policy, resource_admission=admission, resource_reservation=reserve,
            new_model_fits=150, new_model_native_verification_count=150, new_mice_chains=0, new_stop_fits=0,
            pool=dict(configured_worker_ceiling=admission["limits"]["configured"], admitted_worker_ceiling=1,
                runnable_task_count=150, actual_worker_process_peak=1, completed_task_count=150,
                engine_threads=1, status="COMPLETED"))
        (batch / "execution.json").write_bytes(canonical_json_bytes(execution))
        batches.append(batch)
    before = {path: path.read_bytes() for path in old_root.rglob("*") if path.is_file()}
    lineage = dict(score_root=str(tmp_path / "score"), science_decision=request["science_decision"],
        resource_policy=policy, **budgets)
    monkeypatch.setattr(f5, "_read_final_lineage", lambda *a, **k: lineage)
    for name in ("_materialized_full_data_development_sources", "_compile_full_score_inputs",
                 "_execute_and_verify_score_archive_job", "_replay_component_job"):
        monkeypatch.setattr(f5, name, forbidden)
    monkeypatch.setattr(runtime, "_bounded_ordered_spawn", forbidden)
    monkeypatch.setattr(f4, "_replay_f4_model_component", forbidden)
    column_map = f2_kernel._expected_family_parent_column_map
    monkeypatch.setattr(f2_kernel, "_expected_family_parent_column_map", lambda parents, own, predictors, recipe:
        [{"columns": ["AST_ALT", "Age"]}] if recipe.get("fixture") is True
        else column_map(parents, own, predictors, recipe))
    monkeypatch.setattr(f5, "_validate_final_r_fit_health", lambda *a, **k: None)
    monkeypatch.setattr(f5, "_validate_retained_r_audit_numbers", lambda *a, **k: None)
    releases = []
    monkeypatch.setattr(runtime, "observe_step_memory", lambda: {})
    def release(paths, **kwargs):
        assert all(root in path.parents for path in paths)
        releases.append(True)
        raise OSError("UNFITTED_RELEASE_UNKNOWN")
    monkeypatch.setattr(runtime, "release_step_resources", release)
    options = dict(family=family, selection_horizon_months=12, resume=True,
        retained_score_root=old_root, retained_score_producer_source_bundle=bundle,
        prepared_score_source_bundle=bundle, prepared_score_root=root, score_batches=batches)
    report = f5.execute_full_data_locked_scores(tmp_path / "lineage.json", **options)
    assert report["status"] == "TRAINING_SCORING_COMPLETE_NOT_FINAL_MODEL"
    assert report["retained_score_producer_source_identity"] == identity
    assert report["historical_model_fit_count"] == report["score_numerical_component_count"] == 300
    assert report["new_model_fits"] == report["new_model_native_verification_count"] == report["native_model_replay_count"] == 0
    assert report["resource_error"] == "OSError:UNFITTED_RELEASE_UNKNOWN" and releases == [True]
    assert (root / "input-execution.json").read_bytes() == canonical_json_bytes(prepared)
    assert {path: path.read_bytes() for path in old_root.rglob("*") if path.is_file()} == before
    saved = {path: path.read_bytes() for path in root.rglob("*") if path.is_file()}
    monkeypatch.setattr(nested, "_score_fresh_family", forbidden)
    assert f5.execute_full_data_locked_scores(tmp_path / "lineage.json",
        **{**options, "resume": False, "replay": True}) == report
    assert releases == [True] and all(path.read_bytes() == raw for path, raw in saved.items())
    with pytest.raises(ContractError, match="ALREADY_STARTED"):
        f5.execute_full_data_locked_scores(tmp_path / "lineage.json", **options)
    # Direct terminal consumer must rediscover the old input through the
    # existing family report, not require a new caller-side source map.
    for other in nested._families():
        if other == family:
            continue
        directory = root / "score-evidence" / other
        directory.mkdir(parents=True)
        (directory / "training-score.json").write_bytes(canonical_json_bytes({"family": other}))
        (directory / "execution.json").write_bytes(canonical_json_bytes({"family": other, "component_evidence_records": []}))
        for repeat in range(1, 4):
            for inner in range(1, 6):
                path = root / f"score-context/{other}/R{repeat}_K{inner}/imp01.csv"
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(b"UNFITTED_OTHER_FAMILY")
    original_recompute = nested._recompute_fresh_score_from_evidence
    calls = []
    def recompute(**kwargs):
        if kwargs["execution"]["family"] == family:
            assert kwargs["retained_request"] == old and kwargs["retained_request_root"] == old_root / "request"
            calls.append(family)
            return original_recompute(**kwargs)
        return kwargs["score"]
    monkeypatch.setattr(f5, "_compile_full_score_inputs", lambda *a, **k: request)
    monkeypatch.setattr(nested, "_recompute_fresh_score_from_evidence", recompute)
    monkeypatch.setattr(nested, "validate_fresh_score_execution", lambda value: value)
    monkeypatch.setattr(nested, "select_training_family", lambda scores: {"UNFITTED_OTHER_FAMILIES": True})
    monkeypatch.setattr(f5, "_full_score_storage_usage", lambda *a, **k: {})
    # Six other families are deliberately absent in this interface fixture;
    # the real admission above covered the actual family/batches/public call.
    monkeypatch.setattr(f5, "_full_score_resource_admission", lambda *a, **k: (
        {"admitted_worker_ceiling": 1, "limits": {"configured": 56}}, {"retained_result_json_bytes": 10**7}))
    monkeypatch.setattr(f5, "_full_score_job_inputs", lambda *a, **k: None)
    monkeypatch.setattr(f5, "_score_archive_expanded_limit", lambda *a, **k: None)
    options = dict(rscript="FORBIDDEN", replay=False, resume=True, selection_horizon_months=12,
        science_decision=request["science_decision"], resource_policy=policy, **budgets,
        retained_full0_source_bundle=tmp_path / "primary.zip", retained_q_archive=tmp_path / "q.zip",
        retained_q_producer_source_bundle=tmp_path / "q-source.zip")
    report_path = root / f"score-execution.{family}.json"
    for field, value in (("retained_score_producer_source_identity", "9" * 64),
                         ("retained_score_request_sha256", "9" * 64), ("new_model_fits", 1)):
        changed = copy.deepcopy(report)
        changed[field] = value
        report_path.write_bytes(canonical_json_bytes(changed))
        with pytest.raises(ContractError):
            f5._full_data_locked_score_program({}, [], {}, tmp_path / "selector", {}, root, **options)
        assert calls == [] and not (root / "full-score-result.json").exists()
    report_path.write_bytes(canonical_json_bytes(report))
    result = f5._full_data_locked_score_program({}, [], {}, tmp_path / "selector", {}, root, **options)
    assert calls == [family]
    assert result["new_model_fits"] == result["new_model_native_verification_count"] == result["native_model_replay_count"] == 0
    assert {path: path.read_bytes() for path in old_root.rglob("*") if path.is_file()} == before
    with monkeypatch.context() as patch:
        assert_original_final_consumer(root, family, patch)
