"""Independent Cox mathematics and actual native engine counterexamples."""
from __future__ import annotations

import math

import numpy as np
import pytest
from scipy.special import logsumexp

from padml.bundle import ContractError
from padml.f2_kernel import (
    _coxtime_complete_baseline,
    _coxtime_labtrans,
    _coxtime_model,
    _coxtime_prediction_function_seal,
    _coxtime_refit_predict,
    _evaluate_coxtime_function_seal,
    _sha,
    _validate_coxtime_baseline_health,
    _validate_xgb_cox_objective_health,
    _xgb_grouped_breslow_objective,
    _xgb_prediction_function_seal,
    _xgb_refit_predict,
)


def grouped_loss(time, event, margin, weights=None):
    """Enumerate the risk set anew; no production evaluator or derivative code."""
    weights = np.ones(len(time)) if weights is None else np.asarray(weights)
    terms = []
    for t in np.unique(time[event == 1]):
        at_risk = time >= t
        deaths = (time == t) & (event == 1)
        terms.append(float(weights[deaths].sum()) * float(
            logsumexp(margin[at_risk] + np.log(weights[at_risk]))))
        terms.append(-math.fsum((weights[deaths] * margin[deaths]).tolist()))
    return math.fsum(terms)


def finite_derivatives(function, point, step=2e-4):
    point = np.asarray(point, dtype=float)
    gradient = np.empty(len(point))
    hessian = np.empty((len(point), len(point)))
    value = function(point)
    for i in range(len(point)):
        ei = np.zeros_like(point)
        ei[i] = step
        gradient[i] = (function(point + ei) - function(point - ei)) / (2 * step)
        hessian[i, i] = (function(point + ei) - 2 * value + function(point - ei)) / step**2
        for j in range(i):
            ej = np.zeros_like(point)
            ej[j] = step
            hessian[i, j] = hessian[j, i] = (
                function(point + ei + ej) - function(point + ei - ej)
                - function(point - ei + ej) + function(point - ei - ej)
            ) / (4 * step**2)
    return gradient, hessian


def xgb_parameters():
    return {"eta": .05, "max_depth": 2, "min_child_weight": 2.0,
            "subsample": 1.0, "colsample_bytree": 1.0, "reg_lambda": 1.0,
            "reg_alpha": 0.0, "gamma": 0.0, "tree_method": "hist",
            "max_bin": 256, "max_nrounds": 20}


def native_parameters(parameters):
    return {"objective": "survival:cox", "eval_metric": "cox-nloglik",
            **{k: v for k, v in parameters.items()
               if k not in {"reg_lambda", "reg_alpha", "max_nrounds"}},
            "lambda": parameters["reg_lambda"], "alpha": parameters["reg_alpha"],
            "nthread": 1, "seed": 300101, "verbosity": 0}


@pytest.mark.parametrize("time,event", [
    ([1, 1, 2, 2, 3, 4, 4, 5], [1, 0, 1, 1, 0, 1, 0, 1]),
    ([1, 2, 3, 4, 5, 6, 7, 8], [1, 0, 1, 1, 0, 1, 0, 1]),
    ([1, 2, 3], [0, 0, 1]),
])
def test_xgb_derivatives_match_independent_loss_finite_differences(time, event):
    import xgboost as xgb
    time, event = np.asarray(time, dtype=float), np.asarray(event)
    margin = np.random.default_rng(203).normal(size=len(time))
    data = xgb.DMatrix(np.arange(len(time)).reshape(-1, 1), label=np.where(event, time, -time))
    objective, health = _xgb_grouped_breslow_objective(data, np, time=time, event=event)
    gradient, hessian = objective(margin, data)
    expected_g, expected_h = finite_derivatives(lambda z: grouped_loss(time, event, z), margin)
    np.testing.assert_allclose(gradient, expected_g, atol=3e-8, rtol=1e-7)
    np.testing.assert_allclose(hessian, np.diag(expected_h), atol=8e-7, rtol=2e-6)
    assert abs(math.fsum(gradient.tolist())) < 1e-12
    assert (hessian >= 0).all()
    _validate_xgb_cox_objective_health(health, 1, len(time))


def test_xgb_tied_gradient_is_zero_and_hessian_scale_is_not_normalised():
    import xgboost as xgb
    n = 160
    data = xgb.DMatrix(np.arange(n).reshape(-1, 1), label=np.ones(n))
    objective, _ = _xgb_grouped_breslow_objective(data, np, time=np.ones(n), event=np.ones(n))
    gradient, hessian = objective(np.zeros(n), data)
    np.testing.assert_array_equal(gradient, np.zeros(n))
    np.testing.assert_allclose(hessian, 1 - 1/n, rtol=0, atol=1e-15)


def test_xgb_float32_label_collision_does_not_merge_original_event_times():
    import xgboost as xgb
    time, event = np.array([1, 1.00000001]), np.ones(2, dtype=int)
    data = xgb.DMatrix(np.array([[0.0], [1.0]]), label=time)
    assert data.get_label()[0] == data.get_label()[1]
    objective, health = _xgb_grouped_breslow_objective(data,np,time=time,event=event)
    gradient, hessian = objective(np.zeros(2),data)
    np.testing.assert_array_equal(gradient, [-.5,.5])
    np.testing.assert_array_equal(hessian, [.25,.25])
    assert health["event_time_groups"] == 2
    # The callback owns a fixed copy rather than a mutable caller reference.
    time[1] = 1
    np.testing.assert_array_equal(objective(np.zeros(2),data)[0], [-.5,.5])


def test_both_actual_xgb_call_paths_deliver_original_float64_time_to_callback(tmp_path, monkeypatch):
    import xgboost as xgb
    from padml import f2_kernel as kernel
    original = kernel._xgb_grouped_breslow_objective
    time = 1+np.arange(160,dtype=float)*1e-8
    event = np.ones(160,dtype=int)
    x = np.arange(160,dtype=float).reshape(-1,1)
    calls = []
    def recording(matrix,np,*,time,event):
        assert len(np.unique(matrix.get_label())) < len(np.unique(time))
        objective, health = original(matrix,np,time=time,event=event)
        calls.append(health)
        return objective, health
    monkeypatch.setattr(kernel,"_xgb_grouped_breslow_objective",recording)
    parameters=xgb_parameters()
    _xgb_refit_predict(xgb,parameters,x,time,event,x[:8],20,300101,"CPU",[1,2,3],np)
    partition={"fit_ids":[f"F{i}" for i in range(160)],"evaluation_ids":[f"E{i}" for i in range(8)]}
    _xgb_prediction_function_seal(xgb,parameters,partition,x,x[:8],time,event,300101,"CPU",np,tmp_path/"seal"/"model.ubj")
    assert len(calls)==2 and all(row["event_time_groups"]==160 and row["gradient_evaluations"]==20 for row in calls)


@pytest.mark.parametrize("bad", [math.nan,math.inf,-math.inf])
def test_xgb_original_time_nonfinite_fails_before_native_objective(bad):
    import xgboost as xgb
    data=xgb.DMatrix(np.arange(2).reshape(-1,1),label=np.ones(2))
    with pytest.raises(ContractError,match="OBJECTIVE_INPUT_INVALID"):
        _xgb_grouped_breslow_objective(data,np,time=[1,bad],event=[1,1])


@pytest.mark.parametrize("minimum_improvement", [0.0,1e-4])
def test_flat_finite_native_cox_risk_curve_selects_first_tree(minimum_improvement):
    from padml.f2_kernel import _evaluate_grouped_cox_risk_curve, _seal_cox_risk_curve
    from test_f2_scoring import _response
    fit_ids=[f"F{i}" for i in range(40)]
    stop_ids=[f"S{i}" for i in range(40)]
    sealed=_seal_cox_risk_curve(fit_ids,stop_ids,[[0.0]*20 for _ in fit_ids],
                                [[0.0]*20 for _ in stop_ids],20)
    lock=_evaluate_grouped_cox_risk_curve(sealed,
        fit_response=_response(fit_ids,[1.0]*40,[1]*40),
        evaluation_response=_response(stop_ids,[1.0]*40,[1]*40),
        minimum_improvement=minimum_improvement,patience=5,family="GBM_COX")
    assert lock["selected_trees"]==1 and lock["evaluated_tree_count"]==6


def test_flat_coxtime_curve_keeps_earliest_eligible_epoch():
    from padml.f2_kernel import _coxtime_curve_optimum
    assert _coxtime_curve_optimum([.7]*300)==30
    assert _coxtime_curve_optimum([.1]*29+[.7]*271)==30
    for bad in (math.nan,math.inf,-math.inf):
        curve=[.7]*300
        curve[200]=bad
        with pytest.raises(ContractError,match="VALIDATION_CURVE_INVALID"):
            _coxtime_curve_optimum(curve)


def test_genuine_constant_survival_is_valid_but_illegal_probabilities_are_not():
    from padml.f2_kernel import _require_prediction_scientific_variation
    from padml.f2_validation import _validate_prediction_scientific_variation
    matrix=[[math.exp(-1)]*4 for _ in range(40)]
    _require_prediction_scientific_variation(matrix)
    _validate_prediction_scientific_variation([{"survival":row} for row in matrix])
    for bad in (math.nan,math.inf,-math.inf,-.1,1.1):
        damaged=[row.copy() for row in matrix]
        damaged[0][0]=bad
        with pytest.raises(ContractError,match="PREDICTION_MATRIX_INVALID"):
            _require_prediction_scientific_variation(damaged)
        with pytest.raises(ContractError,match="PREDICTION_MATRIX_INVALID"):
            _validate_prediction_scientific_variation([{"survival":row} for row in damaged])


def test_xgb_tie_permutation_and_common_margin_shift_invariance():
    import xgboost as xgb
    rng = np.random.default_rng(303)
    n = 80
    time = np.repeat(np.arange(1, 21), 4)
    event = rng.integers(0, 2, n)
    margin = rng.normal(size=n)
    data = xgb.DMatrix(np.arange(n).reshape(-1, 1), label=np.where(event, time, -time))
    objective, _ = _xgb_grouped_breslow_objective(data, np, time=time, event=event)
    original = objective(margin, data)
    permutation = rng.permutation(n)
    permuted_data = xgb.DMatrix(permutation.reshape(-1, 1),
                               label=np.where(event, time, -time)[permutation])
    other, _ = _xgb_grouped_breslow_objective(permuted_data, np,
                                            time=time[permutation], event=event[permutation])
    permuted = other(margin[permutation], permuted_data)
    shifted = objective(margin + 50, data)
    for expected, observed, translated in zip(original, permuted, shifted, strict=True):
        np.testing.assert_allclose(expected[permutation], observed, rtol=1e-12, atol=1e-12)
        np.testing.assert_allclose(expected, translated, rtol=1e-12, atol=1e-12)


@pytest.mark.parametrize("bad", [math.nan, math.inf, -math.inf])
def test_xgb_raw_nonfinite_margin_is_an_error(bad):
    import xgboost as xgb
    data = xgb.DMatrix(np.arange(12).reshape(-1, 1), label=np.arange(1, 13))
    objective, _ = _xgb_grouped_breslow_objective(data, np, time=np.arange(1, 13), event=np.ones(12))
    margin = np.zeros(12)
    margin[0] = bad
    with pytest.raises(ContractError, match="RAW_MARGIN_INVALID"):
        objective(margin, data)


@pytest.mark.parametrize("damage", ["missing", "old", "count", "boolean"])
def test_xgb_objective_health_is_not_an_unchecked_fit_flag(damage):
    health = {"implementation": "GROUPED_BRESLOW_FLOAT64_TIME_V1", "gradient_evaluations": 20,
              "training_rows": 160, "event_time_groups": 1}
    if damage == "missing":
        health.pop("implementation")
    elif damage == "old":
        health["implementation"] = "NATIVE_UNGROUPED"
    elif damage == "count":
        health["gradient_evaluations"] = 19
    else:
        health["event_time_groups"] = True
    with pytest.raises(ContractError, match="OBJECTIVE_HEALTH_INVALID"):
        _validate_xgb_cox_objective_health(health, 20, 160)


def test_actual_xgb_refit_and_function_seal_do_not_learn_false_tied_risk(tmp_path):
    import xgboost as xgb
    n = 160
    x = np.arange(n, dtype=float).reshape(-1, 1)
    time, event = np.ones(n), np.ones(n, dtype=int)
    parameters = xgb_parameters()
    fit = _xgb_refit_predict(xgb, parameters, x, time, event, x[:8], 20,
                             300101, "CPU", [1, 2, 3], np)
    np.testing.assert_allclose(fit["survival"], math.exp(-1), rtol=2e-7, atol=2e-8)
    assert fit["fit_health"]["cox_objective"]["gradient_evaluations"] == 20
    partition = {"fit_ids": [f"FIT_{i}" for i in range(n)],
                 "evaluation_ids": [f"EVAL_{i}" for i in range(8)]}
    sealed, handoff = _xgb_prediction_function_seal(
        xgb, parameters, partition, x, x[:8], time, event, 300101, "CPU", np,
        tmp_path/"handoff"/"model.ubj")
    _validate_xgb_cox_objective_health(sealed["payload"]["cox_objective"], 20, n)
    booster = xgb.Booster()
    booster.load_model(handoff["path"])
    margin = booster.predict(xgb.DMatrix(x), output_margin=True)
    assert float(np.ptp(margin)) == 0


def test_actual_xgb_untied_control_matches_original_engine():
    import xgboost as xgb
    rng = np.random.default_rng(3101)
    x = rng.normal(size=(240, 4))
    time = rng.permutation(np.arange(1, 241)).astype(float)
    event = rng.integers(0, 2, len(time))
    data = xgb.DMatrix(x, label=np.where(event, time, -time))
    parameters = native_parameters(xgb_parameters())
    old = xgb.train(parameters, data, num_boost_round=20, verbose_eval=False)
    objective, _ = _xgb_grouped_breslow_objective(data, np, time=time, event=event)
    new = xgb.train(parameters, data, num_boost_round=20, verbose_eval=False, obj=objective)
    old_margin = old.predict(data, output_margin=True).astype(float)
    new_margin = new.predict(data, output_margin=True).astype(float)
    # XGBoost's custom-objective path keeps the default base score instead of
    # estimating a constant. Cox margins are identifiable only up to that shift.
    np.testing.assert_allclose(new_margin - new_margin.mean(), old_margin - old_margin.mean(),
                               rtol=3e-6, atol=3e-6)
    np.testing.assert_allclose(new.predict(data), np.exp(new_margin), rtol=2e-7)
    def survival(margin):
        risk = np.exp(margin)
        baseline = math.fsum(float(((time == t) & (event == 1)).sum())
                            / float(risk[time >= t].sum())
                            for t in np.unique(time[(event == 1) & (time <= 120)]))
        return np.exp(-risk * baseline)
    np.testing.assert_allclose(survival(new_margin), survival(old_margin), rtol=5e-7, atol=5e-7)


def coxtime_native():
    from pycox import models
    import torch
    import torchtuples as tt
    torch.set_num_threads(1)
    return models, torch, tt


def coxtime_candidate():
    from padml._science_authority import load_science_authority
    return load_science_authority()["science"]["f2_model_development"]["coxtime"]["candidates"][0]


def fixed_score_coxtime():
    models, torch, _ = coxtime_native()

    class FixedScore(torch.nn.Module):
        def __init__(self):
            super().__init__()
            self.anchor = torch.nn.Parameter(torch.zeros(()))

        def forward(self, features, time):
            return features[:, :1] + self.anchor * 0

    return models.CoxTime(FixedScore(), device="cpu")


def test_coxtime_tied_censor_before_first_death_has_complete_risk_set():
    model = fixed_score_coxtime()
    x = np.zeros((4, 1), dtype="float32")
    target = (np.asarray([1, 1, 2, 3], dtype="float32"),
              np.asarray([0, 1, 1, 0], dtype="float32"))
    original = model.compute_baseline_hazards(x, target)
    assert original.loc[1] == pytest.approx(1/3)
    corrected, health = _coxtime_complete_baseline(model, x, target, np)
    assert corrected.loc[1] == .25
    assert corrected.loc[2] == .5
    assert corrected.loc[3] == 0
    _validate_coxtime_baseline_health(health, 4)
    survival = model.predict_surv_df(x, baseline_hazards_=corrected)
    np.testing.assert_allclose(survival.loc[1].to_numpy(), math.exp(-.25), atol=1e-8)
    permutation = np.asarray([1, 0, 2, 3])
    permuted, _ = _coxtime_complete_baseline(
        model, x[permutation], tuple(value[permutation] for value in target), np)
    np.testing.assert_array_equal(corrected.to_numpy(), permuted.to_numpy())


def test_coxtime_untied_baseline_retains_native_finite_arithmetic():
    model = fixed_score_coxtime()
    x = np.random.default_rng(9123).normal(size=(70, 1)).astype("float32")
    target = (np.arange(1, 71, dtype="float32"),
              (np.arange(70) % 3 != 0).astype("float32"))
    original = model.compute_baseline_hazards(x, target)
    expected = model.predict_surv_df(x, baseline_hazards_=original)
    corrected, _ = _coxtime_complete_baseline(model, x, target, np)
    actual = model.predict_surv_df(x, baseline_hazards_=corrected)
    np.testing.assert_array_equal(corrected.to_numpy(), original.to_numpy())
    np.testing.assert_array_equal(actual.to_numpy(), expected.to_numpy())


@pytest.mark.parametrize("bad", [math.nan, math.inf, -math.inf, 1000.0, -1000.0])
def test_coxtime_baseline_rejects_nonfinite_or_unrepresentable_risk(bad):
    model = fixed_score_coxtime()
    x = np.zeros((4, 1), dtype="float32")
    x[0] = bad
    target = (np.asarray([1, 1, 2, 3], dtype="float32"),
              np.asarray([0, 1, 1, 0], dtype="float32"))
    with pytest.raises(ContractError, match="RAW_SCORE_NONFINITE|RISK_SET_NONFINITE"):
        _coxtime_complete_baseline(model, x, target, np)


def checked_loss_model(candidate_index=0):
    native = coxtime_native()
    from padml._science_authority import load_science_authority
    candidate = load_science_authority()["science"]["f2_model_development"]["coxtime"]["candidates"][candidate_index]
    target = (np.arange(1, 13, dtype="float32"), np.ones(12, dtype="float32"))
    labtrans = _coxtime_labtrans(native[0], candidate, *target, np)
    return _coxtime_model(native, candidate, 2, labtrans, 30, "cpu"), candidate


@pytest.mark.parametrize("bad", [math.nan, math.inf, -math.inf])
@pytest.mark.parametrize("location", ["case", "control"])
def test_coxtime_training_loss_rejects_raw_nonfinite_before_native_clamp(bad, location):
    _, torch, _ = coxtime_native()
    model, _ = checked_loss_model()
    case = torch.zeros((8, 1))
    controls = [torch.zeros_like(case) for _ in range(5)]
    (case if location == "case" else controls[2])[0, 0] = bad
    with pytest.raises(ContractError, match="RAW_SCORE_NONFINITE"):
        model.loss(case, controls)


def test_coxtime_training_loss_rejects_finite_raw_difference_overflow():
    _, torch, _ = coxtime_native()
    model, _ = checked_loss_model()
    case = torch.full((8, 1), -3e38)
    controls = [torch.full_like(case, 3e38) for _ in range(5)]
    with pytest.raises(ContractError, match="SCORE_DIFFERENCE_NONFINITE"):
        model.loss(case, controls)


@pytest.mark.parametrize("candidate_index", [0, 1, 2])
def test_coxtime_checked_training_loss_and_gradients_match_native(candidate_index):
    models, torch, _ = coxtime_native()
    model, candidate = checked_loss_model(candidate_index)
    raw = np.random.default_rng(7841).normal(size=(6, 8, 1)).astype("float32")
    current = [torch.tensor(value, requires_grad=True) for value in raw]
    prior = [torch.tensor(value, requires_grad=True) for value in raw]
    actual = model.loss(current[0], current[1:])
    expected = models.loss.CoxCCLoss(candidate["coxtime_shrink"])(prior[0], prior[1:])
    actual.backward()
    expected.backward()
    assert torch.equal(actual, expected)
    assert all(torch.equal(left.grad, right.grad) for left, right in zip(current, prior, strict=True))


def test_coxtime_network_rejects_raw_nonfinite_before_loss_or_prediction():
    _, torch, _ = coxtime_native()
    model, _ = checked_loss_model()
    model.net.eval()
    with torch.no_grad():
        model.net.network[-1].weight.fill_(math.inf)
        with pytest.raises(ContractError, match="RAW_SCORE_NONFINITE"):
            model.net(torch.ones((8, 2)), torch.ones((8, 1)))


@pytest.mark.parametrize("damage", ["missing", "old", "count", "boolean"])
def test_coxtime_baseline_health_requires_actual_counts(damage):
    health = {"implementation": "FULL_T_GE_T_RISK_SET_V1", "training_rows": 4,
              "event_time_groups": 2, "checked_raw_scores": 6}
    if damage == "missing":
        health.pop("checked_raw_scores")
    elif damage == "old":
        health["implementation"] = "FIRST_EVENT_INDEX"
    elif damage == "count":
        health["checked_raw_scores"] = 9
    else:
        health["training_rows"] = True
    with pytest.raises(ContractError, match="BASELINE_HEALTH_INVALID"):
        _validate_coxtime_baseline_health(health, 4)


def test_actual_coxtime_refit_and_300_epoch_function_seal(tmp_path):
    native = coxtime_native()
    candidate = coxtime_candidate()
    rng = np.random.default_rng(8179)
    x = rng.normal(size=(96, 3)).astype("float32")
    times = rng.integers(1, 61, size=80).astype("float32")
    events = (rng.uniform(size=80) > .3).astype("float32")
    result = _coxtime_refit_predict(native, candidate, x[:80], times, events, x[80:],
                                    30, 310101, "CPU", list(range(1, 37)), np)
    assert result["fit_health"]["training_epoch_count"] == 30
    _validate_coxtime_baseline_health(result["fit_health"]["baseline_numerics"], 80)
    assert np.isfinite(result["survival"]).all()
    partition = {"fit_ids": [f"FIT_{i}" for i in range(80)],
                 "evaluation_ids": [f"EVAL_{i}" for i in range(16)]}
    sealed, handoff = _coxtime_prediction_function_seal(
        native, candidate, partition, x[:80], times, events, x[80:],
        310101, "CPU", np, tmp_path/"handoff"/"model.pt")
    assert len(sealed["payload"]["checkpoint_sha256s"]) == 300
    assert handoff["size_bytes"] > 0


@pytest.mark.parametrize("bad", [math.nan, math.inf, -math.inf])
def test_coxtime_checkpoint_evaluator_rejects_raw_nonfinite_before_clamp(bad):
    from types import SimpleNamespace
    from test_f2_scoring import _response
    from padml._science_authority import load_science_authority
    models, torch, _ = coxtime_native()

    class BadRawScore(torch.nn.Module):
        def __init__(self):
            super().__init__()
            self.anchor = torch.nn.Parameter(torch.zeros(()))

        def forward(self, features, time):
            return torch.full((len(features), 1), bad) + self.anchor * 0

    net = BadRawScore()
    ids = [f"EVAL_{i}" for i in range(40)]
    times = np.repeat(np.arange(1, 21), 2).astype("float32")
    events = (np.arange(40) % 3 != 0).astype("float32")
    labtrans = _coxtime_labtrans(models, coxtime_candidate(), times, events, np)
    payload = {"kind": "PADML_F2_COXTIME_PREDICTION_FUNCTION", "maximum": 300,
               "checkpoint_sha256s": ["a"*64]*300, "evaluation_ids": ids}
    sealed = {"status": "SEALED", "payload": payload, "sha256": _sha(payload)}
    runtime = {"model": SimpleNamespace(net=net), "checkpoints": [net.state_dict()]*300,
               "checkpoint_identity_verified": True, "x_evaluation": np.zeros((40, 1)),
               "labtrans": labtrans, "candidate": coxtime_candidate(), "device": "cpu", "seed": 300101}
    contract = load_science_authority()["science"]["f2_model_development"]["coxtime"]["shared_candidate_parameters"]
    with pytest.raises(ContractError, match="RAW_SCORE_NONFINITE"):
        _evaluate_coxtime_function_seal(sealed, runtime, _response(ids, times.tolist(), events.astype(int).tolist()),
                                       contract, np)
