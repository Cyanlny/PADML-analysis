from __future__ import annotations

import copy
from pathlib import Path
from unittest.mock import Mock

import pytest

import padml.capsule as capsule_module
import padml.f2_kernel as kernel
import padml.f2_validation as validation
from padml._science_authority import load_science_authority, selected_route_profiles
from padml.bundle import (
    ContractError, canonical_json_bytes, read_safe_zip, sha256_bytes,
    sha256_file, strict_json_bytes, write_deterministic_zip,
)
from padml.f2 import canonical_unit_ids, materialize_requests
from padml.run import load_run
from test_science_golden import _registered_outer_fixture
from test_selector_epv import _alpha_record


RUNTIME = Path("/Users/liuningyuan/Desktop/PAD/PADML_F2_V1_Runtime")
UNIT = "selector-f1-elastic-net-cox"


def _hash(value):
    return sha256_bytes(canonical_json_bytes(value))


def _seal(value):
    value["identity"] = _hash({key: item for key, item in value.items() if key != "identity"})
    return value


def _requests(run_id, *, source="1" * 64, worker="3" * 64, runtime="2" * 64, input_id="4" * 64):
    return materialize_requests(run_id=run_id, source_identity=source, runtime_identity=runtime,
                                worker_identity=worker, input_identity=input_id)


def _source(previous, model_input, evidence, raw, *, run_identity="a" * 64, capsule_sha="b" * 64):
    return _seal({
        "schema_version": "1.0.0", "kind": "PADML_F2_ELASTIC_SEARCH_REUSE",
        "source_run_identity": run_identity, "source_capsule_sha256": capsule_sha,
        "source_request": copy.deepcopy(previous),
        "archive": {
            "object_key": (f"v22/padml/science/{previous['run_id']}/F2/"
                           f"{previous['transaction_id']}/{previous['unit_id']}/fine-search.zip"),
            "sha256": sha256_bytes(raw), "size_bytes": len(raw),
        },
        "model_input_identity": model_input["identity"],
        "derivation_records_sha256": _hash(evidence["derivation_records"]),
    })


@pytest.fixture(scope="module")
def binding():
    previous = _requests("f2-test-search-original")[UNIT]
    request = _requests("f2-test-search-reuse", source="5" * 64, worker="6" * 64)[UNIT]
    model_input = {"identity": "c" * 64, "selector_recipe_expectations": {"recipe_set_sha256": "d" * 64}}
    evidence = {
        "schema_version": "1.0.0", "kind": "PADML_F2_SELECTOR_SEARCH_EVIDENCE",
        "unit_id": UNIT, "transaction_id": previous["transaction_id"],
        "identities": previous["identities"], "phase": "fine", "scientific_acceptance": False,
        "selector_contract_sha256": _hash(load_science_authority()["science"]["f2_model_development"]["selector_contract"]),
        "recipe_set_sha256": model_input["selector_recipe_expectations"]["recipe_set_sha256"],
        # Deliberately only a binding fixture, never a scientifically accepted search.
        "derivation_records": [{"alpha": 0.2}],
    }
    return previous, request, model_input, evidence


def _archive(tmp_path, binding, evidence=None):
    previous, request, model_input, baseline = binding
    evidence = copy.deepcopy(baseline if evidence is None else evidence)
    path = tmp_path.resolve() / "fine.zip"
    write_deterministic_zip(path, {"selector-search.json": canonical_json_bytes(evidence)})
    source = _source(previous, model_input, evidence, path.read_bytes())
    return path, source, request, model_input, evidence


def test_search_archive_exact_binding_and_unchanged_source(tmp_path, binding):
    path, source, request, expected, evidence = _archive(tmp_path, binding)
    before = path.read_bytes()
    assert capsule_module.load_selector_search(path, source, request, expected) == evidence
    assert source["source_request"]["identities"]["worker"] != request["identities"]["worker"]
    assert source["source_request"]["identities"]["source"] != request["identities"]["source"]
    assert evidence["scientific_acceptance"] is False
    assert path.read_bytes() == before


@pytest.mark.parametrize("reuse", [{}, {UNIT: {}}], ids=["empty", "missing_five_units"])
def test_explicit_reuse_capsule_requires_all_six_sources(tmp_path, reuse):
    baseline = tmp_path.resolve() / "baseline.zip"
    capsule_module.build_capsule(run_id="f2-test-current-capsule", source_identity="1" * 64,
                                runtime_identity="2" * 64, worker_identity="3" * 64,
                                common_input_path=RUNTIME / "build/common-input.zip", target=baseline)
    entries = read_safe_zip(baseline)
    manifest = strict_json_bytes(entries["manifest.json"], "capsule-manifest.json")
    manifest["selector_search_reuse"] = reuse
    entries["manifest.json"] = canonical_json_bytes(_seal(manifest))
    path = tmp_path.resolve() / "capsule.zip"
    write_deterministic_zip(path, entries)
    with pytest.raises(ContractError, match="SELECTOR_SEARCH_SOURCE_SET_INVALID"):
        capsule_module.load_capsule(path, RUNTIME / "build/common-input.zip")


@pytest.mark.parametrize("case", [
    "fold", "seed", "input", "runtime", "authority", "transaction", "source", "worker",
    "same_run", "model_input", "object_key", "source_identity", "run_digest", "capsule_digest",
])
def test_search_source_rejects_wrong_binding_even_after_reseal(tmp_path, binding, case):
    path, source, request, expected, _ = _archive(tmp_path, binding)
    old = source["source_request"]
    if case == "fold":
        source["source_request"] = _requests(old["run_id"])[canonical_unit_ids()[1]]
    elif case == "seed":
        old["seed"] += 1
    elif case in {"input", "runtime", "authority", "source", "worker"}:
        old["identities"][case] = "9" * 64
    elif case == "transaction":
        old["transaction_id"] = "0" * 32
    elif case == "same_run":
        old["run_id"] = request["run_id"]
    elif case == "model_input":
        source["model_input_identity"] = "9" * 64
    elif case == "object_key":
        source["archive"]["object_key"] = source["archive"]["object_key"].replace("fine-search.zip", "coarse-search.zip")
    elif case == "run_digest":
        source["source_run_identity"] = "not-a-digest"
    elif case == "capsule_digest":
        source["source_capsule_sha256"] = "not-a-digest"
    _seal(source)
    if case == "source_identity":
        source["identity"] = "9" * 64
    with pytest.raises(ContractError):
        capsule_module.load_selector_search(path, source, request, expected)


@pytest.mark.parametrize("field,value", [
    ("phase", "coarse"), ("scientific_acceptance", True),
    ("recipe_set_sha256", "9" * 64), ("selector_contract_sha256", "9" * 64),
    ("unit_id", "selector-f2-elastic-net-cox"), ("transaction_id", "0" * 32),
])
def test_search_archive_header_cannot_be_relabelled(tmp_path, binding, field, value):
    evidence = copy.deepcopy(binding[-1])
    evidence[field] = value
    path, source, request, expected, _ = _archive(tmp_path, binding, evidence)
    with pytest.raises(ContractError, match="ARCHIVE_BINDING"):
        capsule_module.load_selector_search(path, source, request, expected)


@pytest.mark.parametrize("case", ["missing", "bad_bytes", "symlink", "ancestor_symlink", "wrong_records_digest"])
def test_search_archive_absence_corruption_or_links_do_not_fall_back(tmp_path, binding, monkeypatch, case):
    path, source, request, expected, _ = _archive(tmp_path, binding)
    directory = tmp_path.resolve() / "selector-search"
    directory.mkdir()
    target = directory / f"{UNIT}.zip"
    if case == "bad_bytes":
        target.write_bytes(b"not-the-locked-archive")
    elif case == "symlink":
        target.symlink_to(path)
    elif case == "ancestor_symlink":
        linked = tmp_path.resolve() / "linked"
        linked.symlink_to(tmp_path.resolve(), target_is_directory=True)
        target.write_bytes(path.read_bytes())
        with pytest.raises(ContractError, match="ARCHIVE_PATH"):
            capsule_module.load_selector_search(linked / "selector-search" / f"{UNIT}.zip", source, request, expected)
        return
    elif case == "wrong_records_digest":
        target.write_bytes(path.read_bytes())
        source["derivation_records_sha256"] = "9" * 64
        _seal(source)
    forbidden = {}
    for name in ("_evaluate_elastic_alpha_phase", "_run_r_prediction_batch", "admitted_f1_frozen_data", "_cached_fold_assets"):
        forbidden[name] = Mock(side_effect=AssertionError(f"UNEXPECTED_CALL:{name}"))
        monkeypatch.setattr(kernel, name, forbidden[name])
    capsule = {"manifest": {"selector_search_reuse": {UNIT: source}},
               "approved_registry": {"model_inputs": [expected]}}
    with pytest.raises(ContractError):
        kernel.execute_model(tmp_path.resolve() / "capsule.zip", capsule, request, tmp_path.resolve(),
                             cache_root=tmp_path.resolve(), checkpoint_root=tmp_path.resolve())
    assert all(mock.call_count == 0 for mock in forbidden.values())


@pytest.fixture(scope="module")
def prefit_context():
    # The approved input supplies only immutable recipe/schema context; no F1 or fit is rerun.
    expected = capsule_module.load_common_input(RUNTIME / "build/common-input.zip")["model_inputs"][0]
    request = _requests("f2-test-search-prefit")[UNIT]
    capsule = {"authority_slice": load_science_authority(), "runtime": {"f2_backend": "CPU"},
               "manifest": {"identity_records": {"execution_plan": {"route_profiles": selected_route_profiles()}}}}
    repo_root = Path(kernel.__file__).resolve().parent
    spec = kernel.compile_model_spec(request, capsule, expected["lineage"], repo_root)
    return spec, expected, repo_root


def _prefit_mocks(monkeypatch, expected, final):
    monkeypatch.setattr(kernel, "_compile_transform_recipes", lambda *args: expected["selector_recipe_expectations"])
    search = Mock(side_effect=AssertionError("REUSED_SEARCH_MUST_NOT_RUN"))
    sensitivity = Mock(side_effect=AssertionError("SENSITIVITY_NOT_AUTHORIZED_IN_PREFIT_TEST"))
    monkeypatch.setattr(kernel, "_evaluate_elastic_alpha_phase", search)
    monkeypatch.setattr(kernel, "_run_r_prediction_batch", final)
    monkeypatch.setattr(kernel, "_run_selector_sensitivity", sensitivity)
    return search, sensitivity


@pytest.mark.parametrize("case,reason", [
    ("empty", "REUSED_SEARCH_RECORDS"), ("missing_alpha", "REUSED_SEARCH_RECORDS"),
    ("missing_fine", "REUSED_SEARCH_GRID_INCOMPLETE"),
    ("missing_mi", "SELECTOR_PARTITION_LOSS_INVALID"),
    ("nonfinite", "NONFINITE_JSON_NUMBER"), ("infeasible", "SELECTOR_EPV_UNRESOLVED"),
])
def test_invalid_science_stops_before_final_without_search(tmp_path, monkeypatch, prefit_context, case, reason):
    spec, expected, repo_root = prefit_context
    coarse = spec["selector_contract"]["alpha_grid"]["coarse"]
    records = [_alpha_record(alpha, infeasible=case == "infeasible") for alpha in coarse]
    if case == "empty":
        records = []
    elif case == "missing_alpha":
        records.pop(0)
    elif case == "missing_mi":
        records[0]["partition_losses"][0]["mi_losses"].pop()
    source = {"identity": "a" * 64, "derivation_records_sha256": _hash(records)}
    if case == "nonfinite":
        records[0]["partition_losses"][0]["mi_losses"][0][0] = float("nan")
    final = Mock(side_effect=AssertionError("INVALID_SEARCH_MUST_NOT_FIT"))
    search, sensitivity = _prefit_mocks(monkeypatch, expected, final)
    with pytest.raises(ContractError, match=reason):
        kernel._run_r_registered_elastic(spec, {"partitions": expected["model_partitions"]}, expected,
                                        tmp_path.resolve(), repo_root, tmp_path.resolve(),
                                        search_reuse=(source, {"derivation_records": records}))
    assert search.call_count == final.call_count == sensitivity.call_count == 0
    assert not list(tmp_path.glob("*search.zip"))


def _reused_execution_fixture():
    # Isolated execution-schema fixture, not an accepted model result.
    value, expected = _registered_outer_fixture()
    outer = value["registered_partition_execution"]["partitions"][0]
    inner = [{"kind": "INNER", "partition_id": f"F1_R{repeat}_K{fold}", "repeat": repeat, "inner_fold": fold,
              "evaluation_response_sha256": _hash([repeat, fold, "response"]),
              "evaluation_ids_sha256": _hash([repeat, fold, "ids"])}
             for repeat in range(1, 4) for fold in range(1, 6)]
    expected["model_partitions"] = [*inner, *expected["model_partitions"]]
    trace = {"distinct_alpha_count": 2, "derivation_records": [
        {"alpha": alpha, "partition_losses": [{"repeat": row["repeat"], "inner_fold": row["inner_fold"]} for row in inner]}
        for alpha in (0.1, 0.2)
    ]}
    source = {"identity": "a" * 64}
    rows = kernel._reused_elastic_execution_rows(expected, trace, source)
    value["registered_partition_execution"] = kernel._registered_execution_object(
        {"fold": 1, "family": "ELASTIC_NET_COX"}, {"identity": "f" * 64}, [*rows, outer])
    value["search_trace"] = trace
    return value, expected, source


def test_reused_inner_truthful_counts_and_partition_binding():
    value, expected, source = _reused_execution_fixture()
    execution = value["registered_partition_execution"]
    assert execution["schema_version"] == "1.1.0"
    assert execution["expected_partition_count"] == 16
    assert execution["executed_partition_count"] == 1
    assert execution["reused_partition_count"] == 15
    for row in execution["partitions"][:-1]:
        assert row["current_fit_count"] == 0 and row["reused_path_count"] == 40
        assert "prediction_seal_set_sha256" not in row and "metric_set_sha256" not in row
    assert validation._validate_registered_partition_execution(value, 1, "ELASTIC_NET_COX", expected, source)["prediction_seal_count"] == 20


@pytest.mark.parametrize("case", [
    "fake_prediction_seal", "fake_metric_seal", "new_fit", "boolean_fit", "path_count", "source",
    "partition_digest", "response", "ids", "extra_field", "outer_reuse", "nineteen_final",
    "missing_inner", "duplicate_inner", "schema", "executed_count", "no_expected_source", "wrong_family",
    "boolean_executed_count", "float_reused_count",
])
def test_reused_inner_schema_rejects_forged_execution(case):
    value, expected, source = _reused_execution_fixture()
    execution = value["registered_partition_execution"]
    row, outer = execution["partitions"][0], execution["partitions"][-1]
    changes = {
        "fake_prediction_seal": ("prediction_seal_set_sha256", "9" * 64),
        "fake_metric_seal": ("metric_set_sha256", "9" * 64), "new_fit": ("current_fit_count", 1),
        "boolean_fit": ("current_fit_count", False), "path_count": ("reused_path_count", 20),
        "source": ("source_identity", "9" * 64), "partition_digest": ("source_partition_sha256", "9" * 64),
        "response": ("evaluation_response_sha256", "9" * 64), "ids": ("evaluation_ids_sha256", "9" * 64),
        "extra_field": ("unexpected", "value"),
    }
    family = "ELASTIC_NET_COX"
    if case in changes:
        key, item = changes[case]
        row[key] = item
    elif case == "outer_reuse":
        outer["evidence_kind"] = "REUSED_SEARCH_PATHS"
    elif case == "nineteen_final":
        outer["prediction_seal_count"] = 19
    elif case == "missing_inner":
        execution["partitions"].pop(0)
    elif case == "duplicate_inner":
        execution["partitions"][1] = copy.deepcopy(row)
    elif case == "schema":
        execution["schema_version"] = "1.0.0"
    elif case == "executed_count":
        execution["executed_partition_count"] = 16
    elif case == "boolean_executed_count":
        execution["executed_partition_count"] = True
    elif case == "float_reused_count":
        execution["reused_partition_count"] = 15.0
    elif case == "no_expected_source":
        source = None
    elif case == "wrong_family":
        family = "COX_PH"
    _seal(execution)
    with pytest.raises(ContractError):
        validation._validate_registered_partition_execution(value, 1, family, expected, source)


def test_final_result_builder_refuses_nineteen_imputations():
    produced = [{"imputation": index, "partition_id": "OUTER_F1", "sealed_prediction": {}}
                for index in range(1, 20)]
    with pytest.raises(ContractError, match="FINAL_PREDICTION_SEAL_SET_INVALID"):
        kernel._build_registered_model_result(
            {"family": "ELASTIC_NET_COX"}, {"partitions": [{"kind": "OUTER", "partition_id": "OUTER_F1"}]},
            produced, selector={}, search_trace={}, search_evaluation_unit_count=0,
            selected_spec={}, execution_rows=[],
        )


def test_archived_real_fine_science_is_valid_but_cannot_be_admitted_directly(tmp_path, monkeypatch):
    # Numerical regression only. Retired authority bytes are not current inputs.
    old_root = RUNTIME / "runs/f2-20260903-selector-epv"
    common = RUNTIME / "build/common-input.zip"
    previous_run = load_run(old_root)
    old_capsule_path = Path(previous_run["capsule"]["path"])
    assert sha256_file(old_capsule_path) == previous_run["capsule"]["sha256"]
    with pytest.raises(ContractError, match="F2_CAPSULE_INVALID"):
        capsule_module.load_capsule(old_capsule_path, common)
    old_entries = read_safe_zip(old_capsule_path)
    previous = strict_json_bytes(old_entries[f"requests/{UNIT}.json"], "archived-request.json")
    expected = capsule_module.load_common_input(common)["model_inputs"][0]
    previous_capsule = {"authority_slice": load_science_authority(), "runtime": {"f2_backend": "CPU"},
                        "manifest": strict_json_bytes(old_entries["manifest.json"], "archived-manifest.json")}
    path = old_root / "results" / f"{UNIT}.fine-search.zip"
    raw = path.read_bytes()
    evidence = strict_json_bytes(read_safe_zip(raw, expected_members={"selector-search.json"})["selector-search.json"], "test-fine.json")
    source = _source(previous, expected, evidence, raw, run_identity=previous_run["identity"],
                     capsule_sha=previous_run["capsule"]["sha256"])
    request = _requests("f2-test-real-search-reuse", source="5" * 64, worker="6" * 64,
                        runtime=previous["identities"]["runtime"], input_id=previous["identities"]["input"])[UNIT]
    with pytest.raises(ContractError, match="SOURCE_REQUEST_MISMATCH"):
        capsule_module.load_selector_search(path, source, request, expected)
    repo_root = Path(kernel.__file__).resolve().parent
    spec = kernel.compile_model_spec(request, previous_capsule, expected["lineage"], repo_root)

    class FinalReached(Exception):
        pass

    direct_validator = validation._validate_elastic_search_trace
    validator_spy = Mock(wraps=direct_validator)
    monkeypatch.setattr(validation, "_validate_elastic_search_trace", validator_spy)
    final = Mock(side_effect=FinalReached)
    search, sensitivity = _prefit_mocks(monkeypatch, expected, final)
    with pytest.raises(FinalReached):
        kernel._run_r_registered_elastic(spec, {"partitions": expected["model_partitions"]}, expected,
                                        tmp_path.resolve(), repo_root, tmp_path.resolve(), search_reuse=(source, evidence))
    assert search.call_count == sensitivity.call_count == 0 and final.call_count == 1
    tasks = final.call_args.args[2]
    assert len(tasks) == 20 and [task["imputation"] for task in tasks] == list(range(1, 21))
    assert all(task["seed"] == spec["seed"] + task["imputation"] for task in tasks)
    assert not list(tmp_path.glob("*search.zip"))

    # The real validator ran above. Its reused trace is now source-labelled by
    # the producer; repeat only direct admission checks, never a fit or search.
    assert validator_spy.call_count == 1
    args, kwargs = validator_spy.call_args.args, validator_spy.call_args.kwargs
    assert args[0]["search_reuse"] == kwargs["expected_selector_search"] == source
    science_trace = {key: item for key, item in args[0].items() if key != "search_reuse"}

    changed = dict(science_trace)
    changed["derivation_records"] = list(science_trace["derivation_records"])
    changed["derivation_records"][0] = copy.deepcopy(changed["derivation_records"][0])
    changed["derivation_records"][0]["partition_losses"][0]["mi_lambda_path_health"][0]["lambda_path_sha256"] = "9" * 64
    resigned_result = {"search_trace": changed, "search_trace_sha256": _hash(changed)}
    assert resigned_result["search_trace_sha256"] != _hash(science_trace)
    with pytest.raises(ContractError, match="REUSED_SEARCH_SOURCE_MISMATCH"):
        direct_validator(resigned_result["search_trace"], *args[1:], **kwargs)
    with pytest.raises(ContractError, match="SELECTOR_LAMBDA_PATH_HEALTH_INVALID"):
        direct_validator(science_trace, *args[1:], **{**kwargs, "expected_selector_search": None})
    with pytest.raises(ContractError, match="REUSED_SEARCH_SOURCE_MISMATCH"):
        direct_validator(science_trace, *args[1:], **{
            **kwargs, "expected_selector_search": {**source, "identity": "9" * 64},
        })
