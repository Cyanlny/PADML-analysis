"""Original byte consumers with synthetic data; no MICE/model/R execution."""
import struct
import zipfile
from pathlib import Path

import pytest

from padml import bundle, f2_kernel as kernel, f4, nested_loco as nested, runtime
from padml.bundle import ContractError, canonical_json_bytes, read_safe_zip, sha256_bytes, sha256_file, write_deterministic_zip
from test_nested_full_development import _unfitted_confirmed_decision
import test_nested_outer_f4 as outer_tests

outer_bundle = outer_tests.outer_bundle


POLICY = {"configured_worker_ceiling": "EXECUTION_HOST_C_MINUS_8", "memory_bytes_per_worker": 1000,
          "scratch_bytes_per_worker": 1000, "memory_reserve_bytes": 100, "scratch_reserve_bytes": 100,
          "transfer_archive_worker_ceiling": 4}


def _compile(tmp_path, *, shared=10**8, name="input.zip", decision=None):
    return f4.compile_o_fit_bundle(tmp_path, tmp_path / name, outer_fold=1,
        science_decision=decision or _unfitted_confirmed_decision(fresh_seven=True, fixed_bootstrap=True),
        resource_policy=POLICY, retained_bytes_per_component=10**7,
        expanded_bytes_per_component=10**6, shared_storage_bytes=shared)


def _observation(root, *, memory=10**12, scratch=10**12):
    return {"effective_cpus": 64, "available_memory_bytes": memory,
            "scratch_available_bytes": scratch, "scratch_root": str(root)}


@pytest.mark.parametrize("method", ["read", "extract"])
def test_zip_allocation_hook_precedes_first_member_and_quarantine(tmp_path, monkeypatch, method):
    source = tmp_path / "source.zip"
    write_deterministic_zip(source, {"rows.csv": b"UNFITTED,ROW\n" * 1000})
    calls = []
    def admit_io(**value):
        calls.append(value)
        if (method == "extract" and value.get("pending_bytes")) or len(calls) == 3:
            raise ContractError("UNFITTED_RESOURCE_SHORTFALL")
    monkeypatch.setattr(bundle, "_stream_zip_member", lambda *args: pytest.fail("No member read after denied allocation"))
    with pytest.raises(ContractError, match="UNFITTED_RESOURCE_SHORTFALL"):
        if method == "read":
            read_safe_zip(source, admit_io=admit_io)
        else:
            bundle.extract_safe_zip(source, tmp_path / "extracted", expected_members={"rows.csv"},
                                    max_member_bytes=10**6, max_total_bytes=10**6, admit_io=admit_io)
    assert len(calls) == 3 and list(tmp_path.iterdir()) == [source]


@pytest.mark.parametrize("zip64", [False, True])
def test_zip_directory_admission_before_zipfile_allocation(tmp_path, monkeypatch, zip64):
    source = tmp_path / "source.zip"
    if zip64:
        monkeypatch.setattr(zipfile, "ZIP64_LIMIT", 50)
    write_deterministic_zip(source, {f"member-{index}.txt": b"UNFITTED" * 30 for index in range(20)})
    calls = []
    def admit_io(**value):
        calls.append(value)
        if len(calls) == 2:
            raise ContractError("UNFITTED_DIRECTORY_MEMORY_SHORTFALL")
    monkeypatch.setattr(zipfile, "ZipFile", lambda *a, **kw: pytest.fail("Directory allocation must not start"))
    with pytest.raises(ContractError, match="UNFITTED_DIRECTORY_MEMORY_SHORTFALL"):
        read_safe_zip(source, admit_io=admit_io)
    assert calls[1]["memory_bytes"] > 1024 * 1024


def test_false_eocd_count_cannot_understate_directory_memory(tmp_path):
    source = tmp_path / "source.zip"
    write_deterministic_zip(source, {f"member-{index}.txt": b"x" for index in range(20)})
    raw = bytearray(source.read_bytes())
    offset = raw.rfind(zipfile.stringEndArchive)
    struct.pack_into("<HH", raw, offset + 8, 1, 1)
    calls = []
    result = read_safe_zip(bytes(raw), admit_io=lambda **value: calls.append(value))
    assert len(result) == 20
    assert calls[1]["memory_bytes"] == 1024 * 1024 + 32 * struct.unpack_from("<I", raw, offset + 12)[0]


@pytest.mark.parametrize("durable", [True, False])
@pytest.mark.parametrize("selected", [False, True])
def test_extraction_bad_crc_keeps_source_without_publishing(tmp_path, durable, selected):
    source = tmp_path / "bad-crc.zip"
    write_deterministic_zip(source, {"payload.bin": b"UNFITTED_BYTES_FOR_CRC"}, stored_members={"payload.bin"})
    raw = source.read_bytes()
    assert raw.count(b"UNFITTED_BYTES_FOR_CRC") == 1
    source.write_bytes(raw.replace(b"UNFITTED_BYTES_FOR_CRC", b"XNFITTED_BYTES_FOR_CRC"))
    damaged = source.read_bytes()
    target = tmp_path / "unpacked"
    with pytest.raises(ContractError, match="ZIP_INVALID"):
        bundle.extract_safe_zip(source, target, expected_members={"payload.bin"},
            max_member_bytes=100, max_total_bytes=100, durable=durable,
            selected_members={"payload.bin"} if selected else None)
    assert source.read_bytes() == damaged and not target.exists()
    assert not list(tmp_path.glob(".unpacked.quarantine-*"))


def test_selected_extraction_reads_only_assigned_payload_but_keeps_full_directory(tmp_path, monkeypatch):
    source, target = tmp_path / "original.zip", tmp_path / "selected"
    entries = {"direct/imp07.csv": b"UNFITTED_SELECTED", "other/imp01.csv": b"UNFITTED_OTHER"}
    write_deterministic_zip(source, entries)
    original = source.read_bytes()
    declarations = {name: {"sha256": sha256_bytes(raw), "size_bytes": len(raw)} for name, raw in entries.items()}
    streamed, admitted = [], []
    stream = bundle._stream_zip_member
    def selected_stream(archive, info, handle):
        assert info.filename == "direct/imp07.csv"
        streamed.append(info.filename)
        return stream(archive, info, handle)
    monkeypatch.setattr(bundle, "_stream_zip_member", selected_stream)
    records = bundle.extract_safe_zip(source, target, expected_members=declarations,
        selected_members={"direct/imp07.csv"}, max_member_bytes=1000, max_total_bytes=2000,
        admit_io=lambda **value: admitted.append(value))
    assert streamed == list(records) == ["direct/imp07.csv"]
    assert records[streamed[0]] == {"relative_path": streamed[0], **declarations[streamed[0]]}
    assert not (target / "other").exists() and (target / streamed[0]).read_bytes() == entries[streamed[0]]
    assert admitted[-1]["pending_bytes"] == len(entries[streamed[0]]) and source.read_bytes() == original


@pytest.mark.parametrize("damage", ["empty", "unknown", "extra_member", "unselected_size", "unselected_sha", "selected_sha"])
def test_selected_extraction_rejects_scope_and_declaration_drift(tmp_path, damage):
    source, target = tmp_path / "original.zip", tmp_path / "selected"
    entries = {"selected.bin": b"UNFITTED_SELECTED", "unselected.bin": b"UNFITTED_OTHER"}
    write_deterministic_zip(source, entries)
    declarations = {name: {"sha256": sha256_bytes(raw), "size_bytes": len(raw)} for name, raw in entries.items()}
    selected = {"selected.bin"}
    if damage == "empty":
        selected = set()
    elif damage == "unknown":
        selected = {"absent.bin"}
    elif damage == "extra_member":
        del declarations["unselected.bin"]
    elif damage == "unselected_size":
        declarations["unselected.bin"]["size_bytes"] += 1
    elif damage == "unselected_sha":
        declarations["unselected.bin"]["sha256"] = "not-a-sha"
    else:
        declarations["selected.bin"]["sha256"] = "0" * 64
    original = source.read_bytes()
    with pytest.raises(ContractError):
        bundle.extract_safe_zip(source, target, expected_members=declarations, selected_members=selected,
            max_member_bytes=1000, max_total_bytes=2000)
    assert not target.exists() and source.read_bytes() == original
    assert not list(tmp_path.glob(".selected.quarantine-*"))


def test_reconstructible_extraction_retains_all_byte_checks_without_scratch_fsync(tmp_path, monkeypatch):
    source = tmp_path / "original.zip"
    entries = {"first.bin": b"UNFITTED first", "nested/second.bin": b"UNFITTED second"}
    write_deterministic_zip(source, entries)
    original_bytes = source.read_bytes()
    calls = []
    monkeypatch.setattr(bundle.os, "fsync", lambda fd: calls.append(fd))
    durable = bundle.extract_safe_zip(source, tmp_path / "durable", expected_members=set(entries),
        max_member_bytes=1000, max_total_bytes=2000)
    assert len(calls) == len(entries) + 2
    calls.clear()
    scratch = bundle.extract_safe_zip(source, tmp_path / "scratch", expected_members=set(entries),
        max_member_bytes=1000, max_total_bytes=2000, durable=False)
    assert scratch == durable and calls == []
    assert {name: (tmp_path / "scratch" / name).read_bytes() for name in entries} == entries
    assert source.read_bytes() == original_bytes
    write_deterministic_zip(tmp_path / "formal.zip", entries)
    assert calls, "Formal archive publication must keep its original durability barriers"


@pytest.mark.parametrize("durable", [True, False])
@pytest.mark.parametrize("failure", ["first_member", "later_member", "before_rename", "after_rename", "declared_sha"])
@pytest.mark.parametrize("selected", [False, True])
def test_extraction_failure_keeps_original_and_never_accepts_partial_copy(tmp_path, monkeypatch, durable, failure, selected):
    source, target = tmp_path / "original.zip", tmp_path / "copy"
    entries = {"first.bin": b"UNFITTED first", "second.bin": b"UNFITTED second"}
    write_deterministic_zip(source, entries)
    original_bytes = source.read_bytes()
    original_stream, original_replace = bundle._stream_zip_member, bundle.os.replace
    streamed = []

    def stream(archive, info, output):
        if failure == "first_member" or failure == "later_member" and streamed:
            raise OSError("INJECTED_EXTRACTION_FAILURE")
        result = original_stream(archive, info, output)
        streamed.append(info.filename)
        return result

    def replace(old, new):
        if failure == "before_rename":
            raise OSError("INJECTED_EXTRACTION_FAILURE")
        original_replace(old, new)
        if failure == "after_rename":
            raise OSError("INJECTED_EXTRACTION_FAILURE")

    monkeypatch.setattr(bundle, "_stream_zip_member", stream)
    monkeypatch.setattr(bundle.os, "replace", replace)
    expected = ({name: {"sha256": "0" * 64, "size_bytes": len(raw)} for name, raw in entries.items()}
                if failure == "declared_sha" else set(entries))
    with pytest.raises(ContractError if failure == "declared_sha" else OSError,
                       match="ZIP_MEMBER_DECLARATION_MISMATCH" if failure == "declared_sha" else "INJECTED_EXTRACTION_FAILURE"):
        bundle.extract_safe_zip(source, target, expected_members=expected,
            max_member_bytes=1000, max_total_bytes=2000, durable=durable,
            selected_members=set(entries) if selected else None)
    assert source.read_bytes() == original_bytes and not list(tmp_path.glob(".copy.quarantine-*"))
    if failure == "after_rename":
        assert {name: (target / name).read_bytes() for name in entries} == entries
        # A complete but unacknowledged tree is retained, never overwritten.
        with pytest.raises(ContractError, match="ZIP_DESTINATION_INVALID"):
            bundle.extract_safe_zip(source, target, expected_members=set(entries),
                max_member_bytes=1000, max_total_bytes=2000, durable=durable)
    else:
        assert not target.exists()


@pytest.mark.parametrize("mode", ["bytes", "symlink", "non_boolean"])
def test_reconstructible_extraction_requires_retained_file_source(tmp_path, mode):
    source = tmp_path / "original.zip"
    write_deterministic_zip(source, {"value.bin": b"UNFITTED"})
    candidate, durable = source, False
    if mode == "bytes":
        candidate = source.read_bytes()
    elif mode == "symlink":
        candidate = tmp_path / "source-link.zip"
        candidate.symlink_to(source)
    else:
        durable = 0
    with pytest.raises(ContractError, match="ZIP_DURABILITY_SCOPE_INVALID|ZIP_SOURCE_INVALID"):
        bundle.extract_safe_zip(candidate, tmp_path / "copy", expected_members={"value.bin"},
            max_member_bytes=1000, max_total_bytes=1000, durable=durable)
    assert not (tmp_path / "copy").exists() and source.is_file()


@pytest.mark.parametrize("resource,delta", [("memory", -1), ("memory", 0), ("scratch", -1), ("scratch", 0)])
def test_outer_score_input_io_uses_decoded_cost_once_without_stage_rescan(tmp_path, monkeypatch, resource, delta):
    """Original shared-score entry/admission; stop before any input science or fit."""
    from padml import f5
    source = tmp_path / "input.zip"
    decision = _unfitted_confirmed_decision(fresh_seven=True, fixed_bootstrap=True)
    write_deterministic_zip(source, {"o-fit-input.json": canonical_json_bytes({"science_decision": decision})})
    target = tmp_path / "score"
    phase, scans, observations, admissions = {}, [], [], []
    original_tree, original_admit = f5._retained_tree_bytes, runtime.resource_admission

    def tree(root):
        scans.append(root)
        return original_tree(root)

    def observation(root):
        observations.append(root)
        observed = _observation(root)
        if phase:
            assert root == target
            observed["available_memory_bytes"] = POLICY["memory_reserve_bytes"] + POLICY["memory_bytes_per_worker"] + phase["memory_bytes"]
            observed["scratch_available_bytes"] = POLICY["scratch_reserve_bytes"] + POLICY["scratch_bytes_per_worker"] + phase["pending_bytes"]
            observed["available_memory_bytes" if resource == "memory" else "scratch_available_bytes"] += delta
        return observed

    def admit(policy, observed, *, legal_tasks):
        if phase:
            assert policy["memory_reserve_bytes"] == POLICY["memory_reserve_bytes"] + phase["memory_bytes"]
            assert policy["scratch_reserve_bytes"] == POLICY["scratch_reserve_bytes"] + phase["pending_bytes"]
            assert legal_tasks == 1
            admissions.append(dict(phase))
        return original_admit(policy, observed, legal_tasks=legal_tasks)

    def materialize(path, destination, *, replay, admit_io):
        assert path == source and destination == target / "request" and replay is False
        scans_before = list(scans)
        for memory, pending in ((1024 * 1024, 0), (1024 * 1024 + 32 * 2000, 0), (4 * 1024 * 1024, 9000)):
            phase.update(memory_bytes=memory, pending_bytes=pending)
            admit_io(**phase)
            assert scans == scans_before
        raise ContractError("UNFITTED_INPUT_IO_ADMITTED")

    monkeypatch.setattr(f5, "_retained_tree_bytes", tree)
    monkeypatch.setattr(runtime, "observe_execution_resources", observation)
    monkeypatch.setattr(runtime, "resource_admission", admit)
    monkeypatch.setattr(f4, "_materialize_o_fit_input_bundle", materialize)
    monkeypatch.setattr(runtime, "_bounded_ordered_spawn", lambda *a, **k: pytest.fail("No scientific pool may start"))
    with pytest.raises(ContractError, match="RESOURCE_ADMISSION_ZERO" if delta < 0 else "UNFITTED_INPUT_IO_ADMITTED"):
        f5._full_data_locked_score_program(None, None, None, None, None, target,
            rscript="UNFITTED", replay=False, outer_input=source, resource_policy=POLICY,
            retained_bytes_per_component=10**7, expanded_bytes_per_component=10**6, shared_storage_bytes=10**7)
    assert len(admissions) == (1 if delta < 0 else 3)
    assert len(observations) == 1 + len(admissions)
    assert not (target / "request").exists()


@pytest.mark.parametrize("resource,delta", [("memory", -1), ("memory", 0), ("scratch", -1), ("scratch", 0)])
def test_compiler_incremental_allocation_exact_boundary(tmp_path, monkeypatch, resource, delta):
    live = _observation(tmp_path)
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda root: {**live, "scratch_root": str(root)})
    def project(**kwargs):
        scratch = kwargs["scratch"]
        scratch.mkdir()
        (scratch / "retained.csv").write_bytes(b"x" * 90)
        # Current headroom already reflects those 90 retained bytes.
        live["available_memory_bytes" if resource == "memory" else "scratch_available_bytes"] = (
            3100 if resource == "memory" else 1110) + delta
        kwargs["admit_io"](pending_bytes=10, memory_bytes=2000)
        raise ContractError("UNFITTED_BOUNDARY_ADMITTED")
    monkeypatch.setattr(nested, "project_outer_development_from_accepted", project)
    with pytest.raises(ContractError, match="RESOURCE_ADMISSION_ZERO" if delta < 0 else "UNFITTED_BOUNDARY_ADMITTED"):
        _compile(tmp_path, shared=100)
    assert not (tmp_path / "input.zip").exists()
    assert next(tmp_path.glob(".input.zip.compile-*/source/retained.csv")).read_bytes() == b"x" * 90


@pytest.mark.parametrize("member,accepted", [("score-COX_PH-R1-K1-M01.zip", True),
                                           ("final-COX_PH-M01.zip", False), ("unexpected.zip", False)])
def test_compiler_only_fixed_score_paths_get_component_storage(tmp_path, monkeypatch, member, accepted):
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda root: _observation(root))
    def project(**kwargs):
        root = kwargs["scratch"] / "components"
        root.mkdir(parents=True)
        (root / member).write_bytes(b"UNFITTED_SIZE_ACCOUNTING_ONLY")
        kwargs["admit_io"](pending_bytes=100)
        raise ContractError("UNFITTED_COMPONENT_BUCKET_ADMITTED")
    monkeypatch.setattr(nested, "project_outer_development_from_accepted", project)
    with pytest.raises(ContractError, match="UNFITTED_COMPONENT_BUCKET_ADMITTED" if accepted else "COMPILE_SHARED_STORAGE_EXCEEDED"):
        _compile(tmp_path, shared=100)


@pytest.mark.parametrize("budget", ["retained", "expanded"])
def test_component_limits_precede_first_archive_write(tmp_path, monkeypatch, budget):
    entries = {name: b"UNFITTED" * 100 for name in nested._COMPONENT_MEMBERS}
    monkeypatch.setattr(nested, "write_deterministic_zip", lambda *a, **kw: pytest.fail("No partial component write"))
    with pytest.raises(ContractError, match="COMPILE_COMPONENT_STORAGE_EXCEEDED|ZIP_TOTAL_EXPANDED_LIMIT"):
        nested._write_component_archive(tmp_path / "component.zip", entries,
            retained_bytes_per_component=1 if budget == "retained" else 10**6,
            expanded_bytes_per_component=1 if budget == "expanded" else 10**6)
    assert list(tmp_path.iterdir()) == []


def test_accepted_json_handoff_reserves_only_new_prediction_storage(tmp_path, monkeypatch):
    from test_f4 import models

    source_models = models()
    (tmp_path / "results").mkdir()
    (tmp_path / "run.json").write_bytes(b"{}")
    run = {"identity": "b" * 64, "run_id": "UNFITTED"}
    monkeypatch.setattr(f4, "load_run", lambda root: run)
    hashes = {unit: "c" * 64 for unit in f4.canonical_unit_ids()}
    payload_bytes = 0
    for model in source_models:
        model["UNFITTED_UNUSED_SEARCH_HISTORY"] = "retained-original" * 1000
        unit = nested._accepted_result_unit_id(model["fold"], model["family"])
        raw = canonical_json_bytes(model)
        payload_bytes += len(raw)
        member = "model.json"
        manifest = {"unit_id": unit, "run_id": run["run_id"],
                    "artifacts": [{"relative_path": member, "size_bytes": len(raw), "sha256": sha256_bytes(raw)}]}
        path = tmp_path / "results" / f"{unit}.zip"
        write_deterministic_zip(path, {"manifest.json": canonical_json_bytes(manifest), member: raw})
        hashes[unit] = sha256_file(path)
    acceptance = {"status": "SCIENTIFICALLY_ACCEPTED", "run_identity": run["identity"],
                  "stage_validation": {"outcome": "PASS"}, "unit_count": 46, "result_sha256": hashes}
    acceptance["identity"] = kernel._sha(acceptance)
    (tmp_path / "f2-acceptance.json").write_bytes(canonical_json_bytes(acceptance))
    monkeypatch.setattr(f4, "_load_f4_source_records", lambda *args, **kwargs: {"run": run, "acceptance": acceptance})
    reservations, original_collect = [], f4.collect_predictions
    def collect(values):
        assert reservations[-1]["memory_bytes"] < 32 * payload_bytes
        actual = original_collect(values)
        assert len(actual["patient_ids"]) == 240
        raise ContractError("UNFITTED_ORIGINAL_COLLECTION_REACHED")
    monkeypatch.setattr(f4, "collect_predictions", collect)
    with pytest.raises(ContractError, match="UNFITTED_ORIGINAL_COLLECTION_REACHED"):
        f4.load_f4_inputs(tmp_path, admit_io=lambda **value: reservations.append(value))


@pytest.mark.parametrize("outer_bundle", [True], indirect=True)
def test_full_input_copy_and_observations_do_not_change_sealed_bytes(outer_bundle, tmp_path, monkeypatch):
    source, projected = outer_bundle
    target = tmp_path / "different-host.zip"
    def observe(root):
        if target.exists():
            raise ContractError("UNFITTED_POST_PUBLICATION_OBSERVATION_FAILED")
        return {**_observation(root), "effective_cpus": 32}
    monkeypatch.setattr(runtime, "observe_execution_resources", observe)
    result = _compile(tmp_path, name=target.name, decision=projected["science_decision"])
    assert result["sha256"] == sha256_file(source) == sha256_file(target)
    assert result["compilation_resources"]["scientific_worker_count"] == 0
    assert result["compilation_resources"]["initial_observation"]["effective_cpus"] == 32
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda root: _observation(root))
    monkeypatch.setattr(f4, "write_deterministic_zip", lambda *a, **kw: pytest.fail("The complete copy must fit before writing"))
    original_bytes = sum(row["archive"].stat().st_size for row in projected["score_components"])
    original_bytes += sum(path.stat().st_size for paths in projected["post_lock_templates"].values() for path in paths)
    with pytest.raises(ContractError, match="COMPILE_SHARED_STORAGE_EXCEEDED"):
        _compile(tmp_path, name="shared-too-small.zip", shared=original_bytes - 1, decision=projected["science_decision"])
    assert not (tmp_path / "shared-too-small.zip").exists()


def _f1_fold_fixture(root):
    """62 real M20 view ZIPs in the original nested F1 result ABI, all UNFITTED."""
    root.mkdir()
    objects, libraries = root / "objects", root / "libraries"
    objects.mkdir()
    libraries.mkdir()
    outer = {"outer_fold": 1, "partition_id": "OUTER_F1", "analysis_ids": ["a", "b"],
             "validation_ids": ["c"], "application_ids": ["a", "b", "c"]}
    inner, stopping, views = [], [], []
    for prefix, rows, field in (("INNER", inner, "validation_ids"), ("STOP", stopping, "stop_ids")):
        for repeat in range(1, 4):
            for fold in range(1, 6):
                rows.append({"outer_fold": 1, "partition_id": f"{prefix}_R{repeat}_K{fold}",
                    "repeat": repeat, "inner_fold": fold, "analysis_ids": ["a"], field: ["b"],
                    "application_ids": ["a", "b"], "consumers": ["GBM_COX", "XGBOOST_COX", "COXTIME_SET_A"]})
    centers = [{"outer_fold": 1, "partition_id": f"CENTER_{index}", "analysis_ids": ["a"],
                "validation_ids": ["b"], "application_ids": ["a", "b"], "validation_center": str(index)}
               for index in range(5)]
    library_members, index = {}, []
    for row in [outer, *inner, *stopping]:
        prefix = "OUTER" if row is outer else row["partition_id"]
        for role, ids in (("ANALYSIS", row["analysis_ids"]), ("APPLICATION", row["application_ids"])):
            view = {"view_id": f"{prefix}_{role}", "UNFITTED": True}
            views.append(view)
            # Analysis and application differ so the native merge is exercised.
            age = 50 if role == "ANALYSIS" else 99
            csv = ("Patient_ID,Center,Age\n" + "".join(f"{patient},36,{age}\n" for patient in ids)).encode()
            entries = {f"imputations/imp{imp:02d}.csv": csv for imp in range(1, 21)}
            entries.update({f"configuration/{component}.json": b'{"UNFITTED":true}\n' for component in (
                "ACTUAL_MICE_METHOD", "ACTUAL_PREDICTOR_MATRIX", "ACTUAL_BLOT", "ACTUAL_CONTINUATION_CONFIG")})
            manifest = {"kind": "PADML_F1_MICE_VIEW", "status": "PASS", "view": view,
                        "members": {name: {"sha256": sha256_bytes(raw), "size_bytes": len(raw)}
                                    for name, raw in entries.items()}}
            path = libraries / f"{view['view_id']}.zip"
            write_deterministic_zip(path, {"manifest.json": canonical_json_bytes(manifest), **entries})
            library_members[f"libraries/{path.name}"] = path
            index.append({"view_id": view["view_id"], "sha256": sha256_file(path), "size_bytes": path.stat().st_size})
    contract = {"registry": {"outer": [outer], "inner": inner, "stopping": stopping,
                             "center_stress": centers, "views": {"1": views}}}
    manifest = {"kind": "PADML_F1_MICE_FOLD_PAYLOAD", "status": "PASS", "outer_fold": 1,
                "binding_contract_sha256": kernel._sha(contract), "library_count": 62, "libraries": index}
    payload = root / "payload.zip"
    write_deterministic_zip(payload, {"manifest.json": canonical_json_bytes(manifest), **library_members})
    artifact = {"artifact_id": "fold", "relative_path": "outputs/mice-fold-1/payload.zip",
                "classification": "PRIVATE_SCIENCE", "size_bytes": payload.stat().st_size,
                "sha256": sha256_file(payload), "status": "OK"}
    result = {"schema_version": "1.0.0", "kind": "result", "run_id": "UNFITTED-F1", "stage_id": "F1",
              "unit_id": "mice-fold-1", "transaction_id": "UNFITTED-transaction", "seed": None,
              "identities": {name: "a" * 64 for name in bundle.BASE_IDENTITY_KEYS},
              "plan": {"action": "UNFITTED_BYTE_ADMISSION", "role": "worker", "coordinates": [],
                       "depends_on": [], "internal_threads": 1}, "artifacts": [artifact],
              "terminal": {"status": "COMPLETED", "reason_code": "OK", "message_sha256": None}, "decision": None}
    source = objects / "mice-fold-1.zip"
    write_deterministic_zip(source, {"manifest.json": canonical_json_bytes(result), artifact["relative_path"]: payload})
    record = {"unit_id": "mice-fold-1", "source_run_id": result["run_id"], "transaction_id": result["transaction_id"],
              "result_sha256": sha256_file(source), "result_size_bytes": source.stat().st_size,
              "artifact_sha256": artifact["sha256"], "artifact_size_bytes": artifact["size_bytes"],
              "request_sha256": kernel._sha(kernel._request_from_f1_result(result))}
    return {"f1_manifest": {"identity": "b" * 64, "direct_objects": [record]}, "f1_object_root": str(objects),
            "binding_contract": contract,
            "response_csv": b"Patient_ID,All_Cause_Death,Death_Followup_months\na,1,50\nb,1,50\nc,0,50\n"}


def test_original_full_f1_materialization_preserves_bytes_with_hook(tmp_path):
    frozen = _f1_fold_fixture(tmp_path / "UNFITTED-F1")
    original = Path(frozen["f1_object_root"]) / "mice-fold-1.zip"
    digest, calls = sha256_file(original), []
    legacy = f4._materialize_o_fit_fold(frozen, 1, tmp_path / "legacy")
    bounded = f4._materialize_o_fit_fold(frozen, 1, tmp_path / "bounded", admit_io=lambda **value: calls.append(value))
    assert legacy["identity"] == bounded["identity"]
    assert (bounded["view_count"], bounded["outer_count"], bounded["inner_count"], bounded["stop_count"],
            bounded["diagnostic_count"]) == (62, 1, 15, 15, 5)
    assert len(list((tmp_path / "bounded/registered").rglob("imp*.csv"))) == 640
    for old, new in zip([*legacy["partitions"], *legacy["diagnostic_partitions"]],
                        [*bounded["partitions"], *bounded["diagnostic_partitions"]], strict=True):
        assert old["covariates"]["members"] == new["covariates"]["members"]
        assert old["fit_response"]["sha256"] == new["fit_response"]["sha256"]
        assert old["evaluation_response"] == new["evaluation_response"]
    assert sha256_file(original) == digest and any(row.get("pending_bytes", 0) > 0 for row in calls)
    assert (tmp_path / "bounded/registered/partitions/OUTER_F1/covariates/imp01.csv").read_bytes() == (
        b"Patient_ID,Center,Age\na,36,50\nb,36,50\nc,36,99\n")


def test_original_f1_cumulative_budget_stops_before_first_view(tmp_path, monkeypatch):
    frozen = _f1_fold_fixture(tmp_path / "UNFITTED-F1")
    first_view_calls = []
    monkeypatch.setattr(kernel, "_load_f1_view_library", lambda *a, **kw: first_view_calls.append(True))
    def admit_io(**value):
        # The full-view pending reservation is issued after both native envelope
        # extractions, while all 62 library ZIPs are retained on disk.
        if "pending_bytes" in value and value.get("memory_bytes") == 32 * len(frozen["response_csv"]):
            raise ContractError("UNFITTED_CUMULATIVE_VIEW_BUDGET_EXCEEDED")
    target = tmp_path / "bounded"
    with pytest.raises(ContractError, match="UNFITTED_CUMULATIVE_VIEW_BUDGET_EXCEEDED"):
        f4._materialize_o_fit_fold(frozen, 1, target, admit_io=admit_io)
    assert first_view_calls == []
    assert len(list((target / "mice-fold-1-payload/libraries").glob("*.zip"))) == 62
    assert (target / "mice-fold-1-result/outputs/mice-fold-1/payload.zip").is_file()
    assert list((target / "registered/view-sources").iterdir()) == []


def test_primary_view_retirement_preserves_complete_coverage(tmp_path):
    frozen = _f1_fold_fixture(tmp_path / "UNFITTED-F1")
    views = {v["view_id"]: v for v in frozen["binding_contract"]["registry"]["views"]["1"]}
    fold_input = {"root": tmp_path / "UNFITTED-F1", "views": views}
    compact = kernel._materialize_registered_partitions(fold_input, frozen["binding_contract"],
        frozen["response_csv"], 1, tmp_path / "compact", include_diagnostics=False)
    reference = kernel._materialize_registered_partitions(fold_input, frozen["binding_contract"],
        frozen["response_csv"], 1, tmp_path / "reference", include_diagnostics=True)
    assert compact["view_count"] == 62 and len(compact["partitions"]) == 31
    assert compact["diagnostic_count"] == 0
    assert list((tmp_path / "compact/view-sources").iterdir()) == []
    assert len(list((tmp_path / "compact/partitions").rglob("imp*.csv"))) == 620
    assert [kernel._registered_partition_identity_record(p) for p in compact["partitions"]] == [
        kernel._registered_partition_identity_record(p) for p in reference["partitions"]]
