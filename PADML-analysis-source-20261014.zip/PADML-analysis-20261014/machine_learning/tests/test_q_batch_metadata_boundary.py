"""Q batch-ledger byte boundaries; metadata fixtures only, never model fits."""

from pathlib import Path
import subprocess
import sys

import pytest

from padml import f4_compact as compact, f5, f5_sensitivity as sensitivity, runtime
from padml.bundle import ContractError, canonical_json_bytes, sha256_bytes, sha256_file, strict_json_bytes


POLICY = {
    "configured_worker_ceiling": runtime.CPU_MINUS_8,
    "memory_bytes_per_worker": 1,
    "scratch_bytes_per_worker": 1,
    "memory_reserve_bytes": 4096,
    "scratch_reserve_bytes": 0,
    "transfer_archive_worker_ceiling": 1,
}
MEMBER_MAX = 16 * 1024**2


def test_q_h36_members_publish_and_resume_without_opening_models(tmp_path, monkeypatch):
    # Largest current funnel: 1300 XGB STOP/REFIT pairs, each retaining an
    # H36 STOP donor (11 refs) and REFIT (8), plus input/coordinates/result.
    limit = 1300 * (11 + 8) + 3
    root = tmp_path / "owner"
    unit = root / "native/UNFITTED"
    unit.mkdir(parents=True)
    for path in (root / "input.json", root / "result.json", unit / "evaluation.json"):
        path.write_bytes(b"{}")
    model = unit / "function.ubj"
    model.write_bytes(b"UNFITTED")
    metadata = root / "native/metadata"
    metadata.mkdir()
    for index in range(limit - 4):
        (metadata / f"{index:05d}.json").hardlink_to(unit / "evaluation.json")
    overflow = metadata / "overflow.json"
    overflow.write_bytes(b"{}")
    with pytest.raises(ContractError, match="F4_COMPACT_Q_MEMBER_SET_INVALID"):
        compact._full_pipeline_q_numerical_members(root, publish=True)
    assert not (root / "numbers.json").exists()
    overflow.unlink()

    published, pins = compact._full_pipeline_q_numerical_members(root, publish=True)
    assert len(pins) == limit
    raw = (root / "numbers.json").read_bytes()
    assert len(raw) < MEMBER_MAX
    assert compact._full_pipeline_q_numbers_index(raw)["members"] == pins
    audit = (unit / "object-audit.json").read_bytes()
    (root / "numbers.json").unlink()
    original_open = Path.open
    def no_model_open(path, *args, **kwargs):
        assert path != model, "COMPLETED_Q_MUST_NOT_REOPEN_MODEL"
        return original_open(path, *args, **kwargs)
    monkeypatch.setattr(Path, "open", no_model_open)
    references = {name: pin for name, pin in pins.items() if name != "result.json"}
    with pytest.raises(ContractError, match="F4_COMPACT_Q_MEMBER_SET_INVALID"):
        compact._full_pipeline_q_numerical_members(root, publish=True,
            transported_refs={**references, "native/overflow.json": pins["input.json"]})
    assert compact._full_pipeline_q_numerical_members(
        root, publish=True, transported_refs=references) == (published, pins)
    assert (root / "numbers.json").read_bytes() == raw
    assert compact._full_pipeline_q_numerical_members(root) == (published, pins)
    assert (unit / "object-audit.json").read_bytes() == audit

    leaf = metadata / "00000.json"
    leaf.unlink()
    with pytest.raises(ContractError, match="F4_COMPACT_Q_VALUE_BYTES_MISMATCH"):
        compact._full_pipeline_q_numerical_members(root)
    leaf.write_bytes(b"[]")  # Same length; the original SHA guard still rejects.
    with pytest.raises(ContractError, match="F4_COMPACT_Q_VALUE_BYTES_MISMATCH"):
        compact._full_pipeline_q_numerical_members(root)
    assert (root / "numbers.json").read_bytes() == raw


def test_f5_module_cli_keeps_one_q_boundary_type():
    script = r'''\
import argparse
import runpy
import sys

def parse_args(self, *args, **kwargs):
    import padml.f5 as canonical
    main = sys.modules["__main__"]
    assert canonical is main
    assert canonical._QBatchBoundary is main._QBatchBoundary
    raise SystemExit(0)

argparse.ArgumentParser.parse_args = parse_args
sys.argv = ["padml.f5"]
runpy.run_module("padml.f5", run_name="__main__", alter_sys=True)
'''
    completed = subprocess.run(
        [sys.executable, "-c", script],
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        check=False,
    )
    assert completed.returncode == 0, completed.stderr


def _metadata_batches(parent: Path, count: int) -> tuple[list[Path], list[dict]]:
    # Both 50 and 57 real continuation shapes exceed one member's 16 MiB cap
    # in aggregate while every original execution record remains far below it.
    padding = "x" * 410_000
    paths, rows = [], []
    for index in range(count):
        path = parent / f"batch-{index:03d}"
        path.mkdir(parents=True)
        row = {"batch_index": index, "metadata_fixture": padding}
        (path / "execution.json").write_bytes(canonical_json_bytes(row))
        paths.append(path)
        rows.append(row)
    return paths, rows


def _options(paths: list[Path]) -> dict:
    return {"prepare_only": True, "task_ids": None, "batch_root": None,
            "q_batches": paths, "retained_bytes_per_task": None}


@pytest.mark.parametrize("count", [50, 57])
def test_q_batch_control_charges_real_collection_bytes_not_one_member_limit(
        tmp_path, monkeypatch, count):
    root = tmp_path / "owner"
    root.mkdir()
    batches, rows = _metadata_batches(tmp_path / "history", count)
    total = sum((path / "execution.json").stat().st_size for path in batches)
    assert total > MEMBER_MAX
    assert all((path / "execution.json").stat().st_size <= MEMBER_MAX
               for path in batches)
    observed = {"effective_cpus": 64, "available_memory_bytes": 256 * 1024**3,
                "scratch_available_bytes": 256 * 1024**3, "scratch_root": str(root)}
    admitted = []
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda _: observed)
    monkeypatch.setattr(runtime, "resource_admission", lambda policy, observation, *, legal_tasks: (
        admitted.append((policy, observation, legal_tasks)) or {"admitted_worker_ceiling": 1}))

    control = f5._q_search_batch_control(root, POLICY, _options(batches))

    assert [row for _, row in control["batches"]] == rows
    assert admitted == [({**POLICY, "memory_bytes_per_worker": 2 * 1024**3,
                          "memory_reserve_bytes": POLICY["memory_reserve_bytes"] + 32 * total,
                          "scratch_reserve_bytes": 0}, observed, 1)]
    assert total <= count * MEMBER_MAX


def test_q_batch_completion_and_completed_replay_keep_large_canonical_ledger(
        tmp_path, monkeypatch):
    root = tmp_path / "owner"
    unit = root / "native/UNFITTED"
    unit.mkdir(parents=True)
    (root / "input.json").write_bytes(b"{}")
    (unit / "function.ubj").write_bytes(b"UNFITTED")
    (unit / "evaluation.json").write_bytes(b"{}")
    _, references = compact._full_pipeline_q_numerical_members(
        root, publish=True, native_units=("UNFITTED",))
    batches, rows = _metadata_batches(tmp_path / "history", 57)
    control = {"completed": False, "batches": list(zip(batches, rows, strict=True)),
               "used_batches": [sha256_bytes(canonical_json_bytes(row)) for row in rows],
               "confirmed_model_fits": 0, "confirmed_stop_fits": 0,
               "references": references, "resource_policy": POLICY}
    result = {"total_search_fit_count": 0, "response_free_stopping_fit_count": 0}

    f5._q_search_batch_completion(root, control, result)
    execution = root / "execution.json"
    assert execution.stat().st_size > MEMBER_MAX
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda _: {
        "effective_cpus": 64, "available_memory_bytes": 256 * 1024**3,
        "scratch_available_bytes": 256 * 1024**3, "scratch_root": str(root)})
    monkeypatch.setattr(runtime, "resource_admission",
                        lambda policy, observation, *, legal_tasks: {"admitted_worker_ceiling": 1})

    replay = f5._q_search_batch_control(root, POLICY, None)

    assert replay["completed"] is True
    assert [row for _, row in replay["batches"]] == rows
    assert execution.stat().st_size <= 58 * MEMBER_MAX
    # Exercise the actual publication reader after the existing writer and
    # completed-batch reader, including an already first-audited native unit.
    result_raw = canonical_json_bytes(result)
    (root / "result.json").write_bytes(result_raw)
    execution_raw = execution.read_bytes()
    audit_raw = (unit / "object-audit.json").read_bytes()
    original_open = Path.open
    def no_model_open(path, *args, **kwargs):
        assert path != unit / "function.ubj", "NUMERICAL_PUBLICATION_MUST_NOT_OPEN_MODEL"
        return original_open(path, *args, **kwargs)
    monkeypatch.setattr(Path, "open", no_model_open)
    published, pins = compact._full_pipeline_q_numerical_members(
        root, publish=True, transported_refs=references)
    assert "numbers.json" in published and "execution.json" in published
    assert "native/UNFITTED/function.ubj" in pins
    assert "native/UNFITTED/function.ubj" not in published
    assert compact._full_pipeline_q_numerical_members(root) == (published, pins)
    assert execution.read_bytes() == execution_raw
    assert (root / "result.json").read_bytes() == result_raw
    assert (unit / "object-audit.json").read_bytes() == audit_raw


@pytest.mark.parametrize("damage", ["batch-count", "envelope-size", "oversized-producer"])
def test_q_numerical_publication_keeps_completed_ledger_bounds(tmp_path, monkeypatch, damage):
    root = tmp_path / "owner"
    (root / "native").mkdir(parents=True)
    value = {"batches": ([{}] * 2601 if damage == "batch-count" else
                          [{"padding": "x" * (33 * 1024**2)}] if damage == "envelope-size" else
                          [{"padding": "x" * MEMBER_MAX}, {}])}
    (root / "execution.json").write_bytes(canonical_json_bytes(value))
    with pytest.raises(ContractError, match="F4_COMPACT_Q_MEMBER_INVALID"):
        compact._full_pipeline_q_numerical_members(root, publish=True)
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda _: {
        "effective_cpus": 32, "available_memory_bytes": 256 * 1024**3,
        "scratch_available_bytes": 256 * 1024**3, "scratch_root": str(root)})
    with pytest.raises(ContractError, match="F5_GBM_Q_SOURCE_EVIDENCE_INVALID"):
        f5._q_gbm_source_evidence(root, POLICY)
    assert not (root / "numbers.json").exists()


def test_q_completed_read_admission_charges_large_ledger_before_read(tmp_path, monkeypatch):
    root = tmp_path / "owner"
    (root / "native").mkdir(parents=True)
    for name in ("input.json", "result.json", "numbers.json"):
        (root / name).write_bytes(b"{}")
    execution = root / "execution.json"
    # Admission observes bytes only; the original member reader validates JSON.
    with execution.open("wb") as handle:
        handle.truncate(21_797_787)
    reserve = POLICY["memory_reserve_bytes"] + 64 * 4 + 32 * (2 + execution.stat().st_size)
    observed = {"effective_cpus": 32, "available_memory_bytes": reserve + 2 * 1024**3,
                "scratch_available_bytes": 1024**3, "scratch_root": str(root)}
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda _: dict(observed))
    def forbidden_read(*args, **kwargs):
        pytest.fail("ADMISSION_MUST_PRECEDE_METADATA_READ")
    monkeypatch.setattr(Path, "read_bytes", forbidden_read)
    admitted = compact._full_pipeline_q_read_admission(root, POLICY, native_audit=False)
    assert admitted["admitted_worker_ceiling"] == 1
    assert admitted["effective_policy"]["memory_reserve_bytes"] == reserve
    observed["available_memory_bytes"] -= 1
    with pytest.raises(ContractError, match="RESOURCE_ADMISSION_ZERO"):
        compact._full_pipeline_q_read_admission(root, POLICY, native_audit=False)


def test_q_source_reader_charges_completed_ledger_before_open(tmp_path, monkeypatch):
    root = tmp_path / "owner"
    root.mkdir()
    execution = root / "execution.json"
    execution.write_bytes(canonical_json_bytes({"batches": [
        {"batch_index": i, "metadata_fixture": "x" * 410_000} for i in range(57)]}))
    assert execution.stat().st_size > MEMBER_MAX
    reserve = POLICY["memory_reserve_bytes"] + 32 * (32 * 1024**2 + execution.stat().st_size)
    observed = {"effective_cpus": 32, "available_memory_bytes": reserve + 2 * 1024**3,
                "scratch_available_bytes": 1024**3, "scratch_root": str(root)}
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda _: dict(observed))
    assert f5._q_gbm_source_evidence(root, POLICY) == ({}, {})
    original_open = Path.open
    def no_metadata_open(path, *args, **kwargs):
        assert path != execution, "SOURCE_ADMISSION_MUST_PRECEDE_METADATA_OPEN"
        return original_open(path, *args, **kwargs)
    monkeypatch.setattr(Path, "open", no_metadata_open)
    observed["available_memory_bytes"] -= 1
    with pytest.raises(ContractError, match="RESOURCE_ADMISSION_ZERO"):
        f5._q_gbm_source_evidence(root, POLICY)


def test_q_source_reader_keeps_single_input_record_bound(tmp_path, monkeypatch):
    root = tmp_path / "owner"
    root.mkdir()
    source = root / "UNFITTED.zip"
    source.write_bytes(b"UNFITTED")
    with (root / "input.json").open("wb") as handle:
        handle.truncate(MEMBER_MAX + 1)
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda _: {
        "effective_cpus": 32, "available_memory_bytes": 256 * 1024**3,
        "scratch_available_bytes": 256 * 1024**3, "scratch_root": str(root)})
    with pytest.raises(ContractError, match="F5_GBM_Q_SOURCE_EVIDENCE_INVALID"):
        f5._q_gbm_source_evidence(root, POLICY, sources={
            "retained_primary_source_bundle": source, "retained_selector_source_bundle": source})


def test_q_batch_collection_keeps_individual_and_completed_envelope_bounds(
        tmp_path, monkeypatch):
    root, batch = tmp_path / "owner", tmp_path / "oversized-member"
    root.mkdir()
    batch.mkdir()
    raw = canonical_json_bytes({"padding": "x" * MEMBER_MAX})
    assert len(raw) > MEMBER_MAX
    (batch / "execution.json").write_bytes(raw)
    with pytest.raises(ContractError, match="F5_Q_BATCH_EXECUTION_REQUIRED"):
        f5._q_search_batch_control(root, POLICY, _options([batch]))

    # A completed envelope is sized by the contained batch count plus one
    # wrapper allowance; a single record cannot claim the whole 2600-batch cap.
    completed = canonical_json_bytes({"batches": [{"padding": "x" * (33 * 1024**2)}]})
    (root / "execution.json").write_bytes(completed)
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda _: {
        "effective_cpus": 64, "available_memory_bytes": 2 * 1024**4,
        "scratch_available_bytes": 2 * 1024**4, "scratch_root": str(root)})
    monkeypatch.setattr(runtime, "resource_admission",
                        lambda policy, observation, *, legal_tasks: {"admitted_worker_ceiling": 1})
    with pytest.raises(ContractError, match="F5_Q_BATCH_METADATA_LIMIT_EXCEEDED"):
        f5._q_search_batch_control(root, POLICY, None)


class _UnfittedBoundary(Exception):
    pass


@pytest.mark.parametrize("family,horizon", [("RSF", 24), ("GBM_COX", 24), ("GBM_COX", 12)])
def test_full0_completed_discovery_admits_large_ledger_before_read(tmp_path, monkeypatch, family, horizon):
    root = tmp_path / "owner"
    (root / "native").mkdir(parents=True)
    for name in ("input.json", "result.json", "numbers.json"):
        (root / name).write_bytes(b"{}")
    execution = root / "execution.json"
    raw = canonical_json_bytes({"batches": [
        {"batch_index": i, "metadata_fixture": "x" * 410_000} for i in range(57)]})
    execution.write_bytes(raw)
    assert len(raw) > MEMBER_MAX
    reserve = POLICY["memory_reserve_bytes"] + 64 * 4 + 32 * (2 + len(raw))
    observed = {"effective_cpus": 32, "available_memory_bytes": reserve + 2 * 1024**3,
                "scratch_available_bytes": 1024**3, "scratch_root": str(root)}
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda _: dict(observed))
    monkeypatch.setattr(f5, "_complex_runtime_registered_inputs", lambda *args: {})
    monkeypatch.setattr(f5, "_complex_search_execution_spec", lambda *args: {})
    checked = []
    original_records = f5._q_completed_execution_records
    def records(value, size, *, failure):
        result = original_records(value, size, failure=failure)
        checked.append((size, len(result)))
        return result
    monkeypatch.setattr(f5, "_q_completed_execution_records", records)
    def numerical_boundary(*args, **kwargs):
        raise _UnfittedBoundary("No numerical program or native model in this fixture")
    monkeypatch.setattr(compact, "_full_pipeline_q_numerical_members", numerical_boundary)
    task = {"family": family, "selection_horizon_months": horizon,
            "execution_profile": {"pool_workers": runtime.CPU_MINUS_8}}
    with pytest.raises(_UnfittedBoundary):
        f5._final_complex_search_program(task, [], root, replay=True, resource_policy=POLICY)
    assert checked == [(len(raw), 57)]

    original_open = Path.open
    def no_execution_open(path, *args, **kwargs):
        assert path != execution, "FULL0_ADMISSION_MUST_PRECEDE_LEDGER_OPEN"
        return original_open(path, *args, **kwargs)
    monkeypatch.setattr(Path, "open", no_execution_open)
    observed["available_memory_bytes"] -= 1
    with pytest.raises(ContractError, match="RESOURCE_ADMISSION_ZERO"):
        f5._final_complex_search_program(task, [], root, replay=True, resource_policy=POLICY)
    with pytest.raises(ContractError, match="F5_Q_RESOURCE_SCOPE_INVALID"):
        f5._final_complex_search_program(task, [], root, replay=True, resource_policy=None)
    assert checked == [(len(raw), 57)]


@pytest.mark.parametrize("mode", ["native-audit", "sharded"])
def test_full0_early_admission_preserves_original_partial_shapes(tmp_path, monkeypatch, mode):
    root = tmp_path / "owner"
    root.mkdir()
    if mode == "native-audit":
        for name in ("input.json", "result.json"):
            (root / name).write_bytes(b"{}")
    observed = {"effective_cpus": 32, "available_memory_bytes": 256 * 1024**3,
                "scratch_available_bytes": 256 * 1024**3, "scratch_root": str(root)}
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda _: dict(observed))
    monkeypatch.setattr(f5, "_complex_runtime_registered_inputs", lambda *args: {})
    monkeypatch.setattr(f5, "_complex_search_execution_spec", lambda *args: {})
    admitted = []
    original_admission = compact._full_pipeline_q_read_admission
    def admission(path, policy, *, native_audit):
        admitted.append(native_audit)
        return original_admission(path, policy, native_audit=native_audit)
    monkeypatch.setattr(compact, "_full_pipeline_q_read_admission", admission)
    def stop_before_producer(*args, **kwargs):
        raise _UnfittedBoundary("Stop before any producer or scientific input read")
    monkeypatch.setattr(f5, "resolve_pool_workers", stop_before_producer)
    task = {"family": "RSF", "selection_horizon_months": 24,
            "execution_profile": {"pool_workers": runtime.CPU_MINUS_8}}
    with pytest.raises(_UnfittedBoundary):
        f5._final_complex_search_program(task, [], root, replay=True, resource_policy=POLICY,
            native_audit=mode == "native-audit", batch_options={} if mode == "sharded" else None)
    assert admitted == ([True] if mode == "native-audit" else [])
    assert not (root / "numbers.json").exists() and not (root / "execution.json").exists()


@pytest.mark.parametrize("case", ["aggregate", "oversized-member", "memory-minus-one"])
def test_a12_recovery_collection_keeps_single_bounds_and_admits_before_hash(tmp_path, monkeypatch, case):
    # Exercise only original metadata preparation. No loss recovery is called.
    from padml.nested_loco import WITHIN_FAMILY_NO_AAR_REDEVELOPMENT
    source, projected, target = (tmp_path / name for name in ("UNFITTED.zip", "projected.zip", "q"))
    source.write_bytes(b"UNFITTED")
    projected.write_bytes(b"UNFITTED")
    batches, rows = _metadata_batches(tmp_path / "history", 50)
    if case == "oversized-member":
        with (batches[0] / "execution.json").open("wb") as handle:
            handle.truncate(MEMBER_MAX + 1)
    total = sum((path / "execution.json").stat().st_size for path in batches)
    base_reserve = POLICY["memory_reserve_bytes"] + 32 * 32 * 1024**2
    observed = {"effective_cpus": 32,
                "available_memory_bytes": base_reserve + 32 * total + 2 * 1024**3
                    - (1 if case == "memory-minus-one" else 0),
                "scratch_available_bytes": 1024**3, "scratch_root": str(tmp_path)}
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda _: dict(observed))
    input_source = {"identity_sha256": "a" * 64, "outer_fold": 5, "family": "GBM_COX",
                    "resource_policy": POLICY}
    monkeypatch.setattr(sensitivity, "materialize_a12_outer_inputs", lambda *args, **kwargs: {
        "source": input_source, "family": "GBM_COX", "outer_fold": 5})
    reached = []
    def stop_before_development(*args, **kwargs):
        reached.append(True)
        raise _UnfittedBoundary("No projected development or loss recovery in this fixture")
    monkeypatch.setattr(sensitivity, "_a12_projected_development_inputs", stop_before_development)
    hashed = []
    def hash_file(path):
        if path.name == "execution.json":
            assert case == "aggregate", "A12_ADMISSION_AND_MEMBER_LIMIT_MUST_PRECEDE_HASH"
            hashed.append(path)
        return sha256_file(path)
    monkeypatch.setattr(sensitivity, "sha256_file", hash_file)
    expected_error = _UnfittedBoundary if case == "aggregate" else ContractError
    expected_message = ("No projected" if case == "aggregate" else
                        "F5_Q_BATCH_METADATA_LIMIT_EXCEEDED" if case == "oversized-member" else
                        "RESOURCE_ADMISSION_ZERO")
    with pytest.raises(expected_error, match=expected_message):
        sensitivity.execute_a12_outer_bundle(source, target, input_bundle=projected,
            search_only=True, search_branch=WITHIN_FAMILY_NO_AAR_REDEVELOPMENT,
            selector_root=tmp_path / "selector", recover_gbm_losses=True,
            retained_primary_source_bundle=source, retained_selector_source_bundle=source,
            retained_gbm_q_source_bundle=source, q_batches=batches,
            task_ids=["UNFITTED"], batch_root=tmp_path / "UNFITTED-batch", retained_bytes_per_task=1)
    reports = list(tmp_path.glob("a12-q-source-*/q-input-execution.json"))
    assert len(reports) == 1
    report = strict_json_bytes(reports[0].read_bytes())
    assert report["effective_policy"]["memory_reserve_bytes"] == base_reserve
    assert report["resource_policy"] == POLICY
    if case == "aggregate":
        assert reached == [True] and hashed == [path / "execution.json" for path in batches]
        assert report["q_batches"] == {str(path): {
            "sha256": sha256_bytes(canonical_json_bytes(row)), "size_bytes": len(canonical_json_bytes(row))}
            for path, row in zip(batches, rows, strict=True)}
    else:
        assert not reached and not hashed and "q_batches" not in report
