"""Real Q keys and pinned producer inputs; no numerical engine calls."""
import copy
import os
from pathlib import Path

import pytest

from padml import f5, f2_kernel as k, nested_loco as n
from padml.bundle import ContractError, canonical_json_bytes, sha256_bytes


@pytest.mark.parametrize('function,compact,projection', [
    ('_run_xgb_refit_pool_task', True, False),
    ('_run_r_prediction_pool_task', True, True),
    ('_run_r_prediction_pool_task', True, False),
    ('_run_r_prediction_pool_task', False, True),
])
def test_q_input_aliases_are_complete_before_workers(tmp_path, monkeypatch, function, compact, projection):
    from padml.bundle import sha256_file
    source = tmp_path / "inputs"
    raw = canonical_json_bytes({"actual_input": "unchanged"})
    pin = sha256_bytes(raw)
    (source / pin).mkdir(parents=True)
    original = source / pin / "input.json"
    original.write_bytes(raw)
    donor = tmp_path / "atoms" / ("d" * 64)
    donor.mkdir(parents=True)
    os.link(original, donor / "input.json")
    (donor / 'producer.json').write_bytes(canonical_json_bytes({'task': {'task_id': 'OLD'},
        'native_units': ['OLD'], 'handoff_name': 'original.ubj'}))
    (donor / 'receipt.json').write_bytes(canonical_json_bytes({'members': {'native/OLD/function.ubj': {}}}))
    if projection:
        (donor / 'gbm-losses.json').write_bytes(b'{}')
    monkeypatch.setattr(f5, "_current_q_stop_source", lambda *args:
        {"key": "d" * 64, "input_sha256": pin})
    jobs = [{"function": function, "call": {}, "key": str(i).zfill(64),
        "control": {"cache": str(tmp_path), "root": str(tmp_path / "q"), "input_sha256": pin,
                    "compact": compact}}
        for i in range(24)]
    f5._current_q_prepare_inputs(jobs)
    stamp = original.stat().st_ctime_ns
    for job in jobs:
        key = job["key"]
        aliases = [tmp_path / "atoms" / key / "input.json",
            tmp_path / "q/native/atoms" / key / "input.json",
            tmp_path / "atoms" / key / "native/atoms" / ("d" * 64) / "input.json"]
        nested = tmp_path / 'q/native/atoms' / key / 'native/atoms' / ('d' * 64) / 'input.json'
        if function == '_run_r_prediction_pool_task' and compact and projection:
            aliases.append(nested)
        else:
            assert not nested.exists()
        assert all(os.path.samefile(original, p) and sha256_file(p) == pin for p in aliases)
    assert original.stat().st_ctime_ns == stamp
    f5._current_q_prepare_inputs(jobs)
    assert original.stat().st_ctime_ns == stamp
    original.write_bytes(raw + b"\n")
    with pytest.raises(ContractError, match="F45_Q_PRODUCER_DRIFT"):
        f5._current_q_prepare_inputs(jobs)


def _call(h=6):
    response = {"sha256": "a" * 64, "size_bytes": 100, "row_ids_sha256": "b" * 64,
                "row_count": 2, "event_count": 1}
    part = {"kind": "INNER", "partition_id": "INNER_R1_K1", "repeat": 1, "inner_fold": 1,
            "fit_ids": ["train1", "train2"], "evaluation_ids": ["validation"],
            "evaluation_ids_sha256": "c" * 64, "application_ids": ["train1", "train2", "validation"],
            "covariates": {"members": [{"name": "imp01.csv", "sha256": "d" * 64, "size_bytes": 200}]},
            "fit_response": response}
    spec = {"family": "XGBOOST_COX", "outcome": "All_Cause_Death", "time": "Followup_month",
            "backend": "CPU", "predictors": ["Age"], "selector_from_dependency": {"selected_parents": ["Age"]},
            "horizons": list(range(37)), "selection_horizon_months": h}
    return {"task_id": "S1_T001_P01_M01", "partition_id": part["partition_id"], "imputation": 1,
            "parameters": {"max_depth": 2}, "seed": 123, "locked_rounds": 50,
            "spec": spec, "registered": {"partitions": [part]}}


def _spec(cache, branch=None):
    control = {"cache": str(cache), "source_identity": "e" * 64}
    if branch is not None:
        control["aar_branch"] = branch
    return {"current_q": control}


def _publish(cache, key, branch=None):
    spec = _call()["spec"]
    if branch is not None:
        spec["a12_source"] = {"branch": branch}
    raw = canonical_json_bytes({"spec": spec})
    pin = sha256_bytes(raw)
    source = cache / "inputs" / pin
    source.mkdir(parents=True, exist_ok=True)
    (source / "input.json").write_bytes(raw)
    atom = cache / "atoms" / key
    atom.mkdir(parents=True, exist_ok=True)
    (atom / "producer.json").write_bytes(canonical_json_bytes({"q_input_sha256": pin}))
    (atom / "receipt.json").write_bytes(canonical_json_bytes({"sealed_fixture": True}))
    return source / "input.json"


def test_q_branch_separation_keeps_same_branch_cross_horizon_key(tmp_path):
    fn = k._run_xgb_refit_pool_task
    branches = [n.A12_DIRECT_AAR, n.A12_TOTAL_AAR, n.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT]
    keys = [f5._current_q_key(_spec(tmp_path, branch), fn, _call()) for branch in branches]
    assert len(set(keys)) == 3
    for branch, key in zip(branches, keys):
        for horizon in (12, 24, 36):
            assert f5._current_q_key(_spec(tmp_path, branch), fn, _call(horizon)) == key
    assert f5._current_q_key(_spec(tmp_path), fn, _call()) not in keys
    altered = _call()
    altered["seed"] += 1
    assert f5._current_q_key(_spec(tmp_path, branches[0]), fn, altered) != keys[0]


def test_original_unscoped_atom_only_admitted_for_its_actual_branch(tmp_path):
    fn = k._run_xgb_refit_pool_task
    call = _call()
    old = f5._current_q_key(_spec(tmp_path), fn, call)
    original = _publish(tmp_path, old, n.A12_TOTAL_AAR)
    before = original.read_bytes()
    total = _spec(tmp_path, n.A12_TOTAL_AAR)
    no_aar = _spec(tmp_path, n.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT)
    assert f5._current_q_reuse_key(total, fn, _call(36)) == old
    assert f5._current_q_reuse_key(no_aar, fn, call) == f5._current_q_key(no_aar, fn, call)
    assert f5._current_q_reuse_key(no_aar, fn, call) != old
    assert original.read_bytes() == before
    original.write_bytes(before + b" ")
    with pytest.raises(ContractError, match="PRODUCER_DRIFT"):
        f5._current_q_reuse_key(total, fn, call)


def test_previous_executor_same_branch_and_primary_key_remain_eligible(tmp_path):
    fn = k._run_xgb_refit_pool_task
    call = _call()
    old_spec = _spec(tmp_path)
    old = f5._current_q_key(old_spec, fn, call)
    _publish(tmp_path, old)
    revised = copy.deepcopy(old_spec)
    revised["current_q"].update(source_identity="f" * 64, compatible_source_identity="e" * 64)
    assert f5._current_q_reuse_key(revised, fn, _call(12)) == old
    revised["current_q"].pop("compatible_source_identity")
    revised["current_q"]["compatible_source_identities"] = ["a" * 64, "e" * 64]
    assert f5._current_q_reuse_key(revised, fn, _call(12)) == old
    revised["current_q"]["aar_branch"] = n.A12_TOTAL_AAR
    assert f5._current_q_reuse_key(revised, fn, call) != old
    _publish(tmp_path, old, n.A12_TOTAL_AAR)
    assert f5._current_q_reuse_key(revised, fn, _call(24)) == old
    with pytest.raises(ContractError, match="BRANCH_MISMATCH"):
        f5._current_q_reuse_key(old_spec, fn, call)


def test_completed_q_checks_original_branch_before_reusing_sealed_numbers(tmp_path):
    original = tmp_path / "native/atoms/a/input.json"
    original.parent.mkdir(parents=True)
    original.write_bytes(canonical_json_bytes({"spec": {"a12_source": {"branch": n.A12_TOTAL_AAR}}}))
    (tmp_path / "native/coordinates.json").write_bytes(canonical_json_bytes({
        "original-coordinate": {"key": "a", "root": "native/atoms/a"}}))
    before = original.read_bytes()
    f5._current_q_completed_branch(tmp_path, n.A12_TOTAL_AAR)
    with pytest.raises(ContractError, match="BRANCH_MISMATCH"):
        f5._current_q_completed_branch(tmp_path, n.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT)
    assert original.read_bytes() == before


def test_previous_failed_header_does_not_claim_new_executor_fit(tmp_path, monkeypatch):
    fn = k._run_xgb_refit_pool_task
    old_spec = _spec(tmp_path)
    old = f5._current_q_key(old_spec, fn, _call())
    source = _publish(tmp_path, old)
    atom = tmp_path / 'atoms' / old
    (atom/'receipt.json').unlink()
    before = {p:p.read_bytes() for p in (source,atom/'producer.json')}
    revised = _spec(tmp_path)
    revised['current_q'].update(source_identity='f'*64,compatible_source_identity='e'*64)
    monkeypatch.setattr(f5,'_current_q_native_inventory',lambda *args:{'objects_complete':False})
    assert f5._current_q_reuse_key(revised,fn,_call()) == f5._current_q_key(revised,fn,_call())
    assert all(p.read_bytes()==raw for p,raw in before.items())
    os.link(source, atom / "input.json")
    monkeypatch.setattr(f5,'_current_q_native_inventory',lambda *args:{'objects_complete':True})
    assert f5._current_q_reuse_key(revised,fn,_call()) == old
    monkeypatch.setattr(f5,'_current_q_native_inventory',lambda *args:{'objects_complete':False})
    (atom/'values.json').write_bytes(b'{}')
    with pytest.raises(ContractError,match='SEALED_NATIVE_INCOMPLETE'):
        f5._current_q_reuse_key(revised,fn,_call())


def test_q_json_uses_immutable_private_snapshots_and_rejects_drift(tmp_path, monkeypatch):
    import time
    source = tmp_path / "input.json"
    raw = canonical_json_bytes({"spec": {"family": "RSF", "values": [1, 2]}})
    source.write_bytes(raw)
    alias = tmp_path / "alias.json"
    os.link(source, alias)
    now = time.time_ns()
    monkeypatch.setattr(time, "time_ns", lambda: now + 3_000_000_000)
    f5._Q_JSON_CACHE.clear()
    reads = []
    original = Path.read_bytes
    def read(path):
        if path in {source, alias}: reads.append(path)
        return original(path)
    monkeypatch.setattr(Path, "read_bytes", read)
    first = f5._current_q_json(source, sha256_bytes(raw))
    first["spec"]["values"][0] = 99
    assert f5._current_q_json(alias, sha256_bytes(raw))["spec"]["values"] == [1, 2]
    assert reads == [source]
    before = source.stat()
    source.write_bytes(raw.replace(b'RSF', b'BAD'))
    # The virtual stable clock must not turn a same-tick rewrite into a cache hit.
    os.utime(source, ns=(before.st_atime_ns, before.st_mtime_ns + 3_000_000_000))
    with pytest.raises(ContractError, match="F45_Q_INPUT_DRIFT"):
        f5._current_q_json(alias, sha256_bytes(raw))
    assert len(reads) == 2
    f5._Q_JSON_CACHE.clear()


@pytest.mark.parametrize("engine", ["PYTHON", "R"])
def test_completed_q_atoms_import_in_workers_and_resume_partial_aliases(tmp_path, monkeypatch, engine):
    # Real task coordinator/child/import/receipt readers with synthetic completed
    # values. No numerical engine, model fitting or clinical claim is involved.
    from padml import runtime
    from padml.bundle import sha256_file, strict_json_bytes
    cache, root = tmp_path / "cache", tmp_path / "q"
    root.mkdir()
    control = {"cache": str(cache), "root": str(root), "source_identity": "e" * 64,
        "read_only": False, "workers": 1, "compact": True,
        "resource_policy": {"scratch_bytes_per_worker": 1}}
    original_call = _call(24)
    original_call["registered"]["partitions"][0]["covariates"]["input_dir"] = str(tmp_path / "not-read")
    base_spec = original_call["spec"]
    if engine == "R":
        base_spec.update(family="RSF", schema_version="1.0.0", fold=1, seed=123,
            heldout_center=36, fpm=None)
        base_spec["selector_from_dependency"]["outer_recipe_sha256"] = "f" * 64
    raw = canonical_json_bytes({"spec": base_spec})
    control["input_sha256"] = sha256_bytes(raw)
    source = cache / "inputs" / control["input_sha256"]
    source.mkdir(parents=True)
    (source / "input.json").write_bytes(raw)
    (source / "registered.json").write_bytes(canonical_json_bytes(original_call["registered"]))
    function = k._run_r_prediction_pool_task if engine == "R" else k._run_xgb_refit_pool_task
    calls, atoms = [], []
    for index in range(2):
        task = copy.deepcopy(original_call)
        task.update(task_id=f"S1_T{index + 1:03}_P01_M01", seed=123 + index)
        if engine == "R":
            native = {key: value for key, value in task.items() if key not in {"spec", "registered"}}
            native["selected_parents"] = ["Age"]
            call = (base_spec, task["registered"], [native], "UNFITTED", "UNFITTED", "NONE", None)
        else:
            native = {key: value for key, value in task.items() if key not in {"spec", "registered"}}
            call = task
        key = f5._current_q_key({"current_q": control}, function, call)
        atom = cache / "atoms" / key
        atom.mkdir(parents=True)
        description = {"key": key, "function": function.__name__, "executor_source_identity": "e" * 64,
            "q_input_sha256": control["input_sha256"], "task": native,
            "native_units": ["UNFITTED"], "evaluation_mode": "NONE", "handoff_name": None}
        (atom / "producer.json").write_bytes(canonical_json_bytes(description))
        row = {"task_id": task["task_id"], "partition_id": task["partition_id"],
            "imputation": 1, "synthetic_completed_value": index}
        values = [row] if engine == "R" else row
        (atom / "values.json").write_bytes(canonical_json_bytes(values))
        pin = {"sha256": sha256_file(atom / "values.json"), "size_bytes": (atom / "values.json").stat().st_size}
        audit = {"values_sha256": pin["sha256"], "native_units": ["UNFITTED"]}
        (atom / "audit.json").write_bytes(canonical_json_bytes(audit))
        (atom / "receipt.json").write_bytes(canonical_json_bytes({"key": key, "native_units": ["UNFITTED"],
            "values": pin, "audit": audit, "members": {}, "retention": "CONSUMED_REFIT_VALUES"}))
        (atom / "work").mkdir()
        (atom / "work/transient").write_bytes(b"private obsolete work")
        if index:
            partial = root / "native/atoms" / key
            partial.mkdir(parents=True)
            os.link(atom / "producer.json", partial / "producer.json")
        calls.append(call)
        atoms.append(atom)
    originals = {p: p.read_bytes() for atom in atoms for p in atom.iterdir() if p.is_file()}
    state = {"compact": True, "coordinates": {}, "references": {}}
    monkeypatch.setitem(f5._CURRENT_Q_STATE, str(root), state)
    monkeypatch.setattr(runtime, "effective_cpu_count", lambda: 16)
    monkeypatch.setattr(runtime, "admit_stage", lambda *a, **kw: {"admitted_worker_ceiling": 1})
    monkeypatch.setattr(runtime, "release_completed_files", lambda *a, **kw: {})
    def no_parent_import(*args, **kwargs):
        raise AssertionError("PARENT_SERIAL_IMPORT_FORBIDDEN")
    monkeypatch.setattr(f5, "_current_q_import", no_parent_import)
    # spawn imports unmodified padml.f5 in the worker; parent import is forbidden.
    first = f5._current_q_task_batch({"current_q": control}, function, calls, selected_slots=1)
    assert len(first) == 2
    assert [((row[0] if engine == "R" else row)["synthetic_completed_value"]) for row in first] == [0, 1]
    assert len(state["coordinates"]) == 2 and len(state["references"]) == 10
    for atom in atoms:
        destination = root / "native/atoms" / atom.name
        assert not (atom / "work").exists()
        for name in ("input.json", "producer.json", "receipt.json", "audit.json", "values.json"):
            assert os.path.samefile(atom / name, destination / name)
        # Recover an interrupted import from the retained complete atom.
        (destination / "audit.json").unlink()
    resumed = f5._current_q_task_batch({"current_q": control}, function, calls, selected_slots=1)
    assert resumed == first
    assert originals == {p: p.read_bytes() for p in originals}
    assert all((root / "native/atoms" / atom.name / "audit.json").is_file() for atom in atoms)
    assert strict_json_bytes((root / "batch-resources-S1.json").read_bytes())["pool"]["completed_task_count"] >= 1
    # Presence only avoids reserving an already stored atom a second time.
    # Its original reader still rejects corruption before any new fit/audit.
    damaged = atoms[0] / "receipt.json"
    receipt = strict_json_bytes(damaged.read_bytes())
    receipt["values"]["sha256"] = "0" * 64
    damaged.write_bytes(canonical_json_bytes(receipt))
    with pytest.raises(ContractError, match="F45_Q_RECEIPT_DRIFT"):
        f5._current_q_task_batch({"current_q": control}, function, calls, selected_slots=1)
    assert all(not (atom / "native/UNFITTED").exists() for atom in atoms)


@pytest.mark.parametrize('engine', ['PYTHON', 'R'])
def test_q_future_disk_budget_matches_dispatched_groups_and_ignores_cached_atoms(tmp_path, monkeypatch, engine):
    from padml import runtime
    root, cache = tmp_path / 'q', tmp_path / 'cache'
    root.mkdir()
    control = {'root': str(root), 'cache': str(cache), 'read_only': False, 'workers': 1,
        'resource_policy': {'scratch_bytes_per_worker': 1024}}
    fn = k._run_r_prediction_pool_task if engine == 'R' else k._run_xgb_refit_pool_task
    calls = []
    for index in range(3):
        task = _call()
        task['task_id'] = f'S1_T{index+1:03}_P01_M01'
        if engine == 'R':
            task['selected_parents'] = ['Age']
            spec, registered = task.pop('spec'), task.pop('registered')
            spec['family'] = 'RSF'
            call = (spec, registered, [task], 'UNFITTED', 'UNFITTED', 'NONE', None)
        else:
            call = task
        calls.append(call)
    def task_for(call): return call[2][0] if engine == 'R' else call
    def key_for(call): return task_for(call)['task_id']
    cached = cache / 'atoms' / key_for(calls[0])
    cached.mkdir(parents=True)
    (cached / 'receipt.json').write_bytes(b'{"UNFITTED":true}')
    calls.append(calls[0])  # One logical repeat must not reserve or execute twice.
    monkeypatch.setattr(f5, '_current_q_reuse_key', lambda spec, fn, call: key_for(call))
    monkeypatch.setattr(f5, '_current_q_row', lambda spec, fn, call, value: value)
    monkeypatch.setitem(f5._CURRENT_Q_STATE, str(root), {'coordinates': {}, 'references': {}})
    stages, dispatched, prepared = [], [], []
    def admit(*args, **kw):
        stages.append(kw)
        return {'admitted_worker_ceiling': 1}
    monkeypatch.setattr(runtime, 'admit_stage', admit)
    monkeypatch.setattr(runtime, 'release_completed_files', lambda *args, **kw: {})
    monkeypatch.setattr(f5, '_current_q_prepare_inputs', lambda jobs: prepared.extend(job['key'] for job in jobs))
    def spawn(worker, tasks, **kw):
        assert len(stages) == 1 and len(prepared) == 3
        assert len(tasks) == len(stages[0]['task_disk_bytes']) == stages[0]['legal_tasks']
        dispatched.extend(tasks)
        def result(job):
            assert job['import_in_worker'] is True
            value = {key: task_for(job['call'])[key] for key in ('task_id', 'partition_id', 'imputation')}
            return {'key': job['key'], 'imported_root': 'native/atoms/' + job['key'],
                'imported_references': {}, 'row': [value] if engine == 'R' else value}
        return [[result(job) for job in group] for group in tasks] if engine == 'R' else [result(job) for job in tasks]
    monkeypatch.setattr(k, '_bounded_ordered_spawn', spawn)
    result = f5._current_q_task_batch({'current_q': control}, fn, calls, selected_slots=1)
    atom_bytes = 8*1024**2 + 3*37*48
    assert stages[0]['retained_bytes'] == 2*atom_bytes and stages[0]['publication_bytes'] == atom_bytes
    assert stages[0]['task_disk_bytes'] == ([(2*atom_bytes, atom_bytes)] if engine == 'R'
        else [(0, 0), (atom_bytes, atom_bytes), (atom_bytes, atom_bytes)])
    assert len(result) == 4 and result[0] == result[-1]
    assert len(dispatched) == (1 if engine == 'R' else 3)


@pytest.mark.parametrize('case,expected',[
    ('normal',None),('same_destination',None),('already_moved',None),
    ('other_error','F45_Q_CANCELLED_NATIVE_EVIDENCE_INVALID'),
    ('noncanonical','F45_Q_CANCELLED_NATIVE_EVIDENCE_INVALID'),
    ('full0_structured','F45_Q_CANCELLED_NATIVE_EVIDENCE_INVALID'),
    ('source_symlink','F45_Q_CANCELLED_NATIVE_EVIDENCE_INVALID'),
    ('destination_conflict','F45_Q_CANCELLED_NATIVE_EVIDENCE_DRIFT'),
    ('destination_symlink','F45_Q_CANCELLED_NATIVE_EVIDENCE_DRIFT'),
    ('extra_native_member','F4_FULL_PIPELINE_Q_NATIVE_INPUT_MISMATCH'),
    ('missing_model_with_values','F45_Q_SEALED_NATIVE_INCOMPLETE'),
    ('missing_binding','F45_Q_SEALED_NATIVE_INCOMPLETE'),
])
def test_cancelled_q_diagnostic_recovery_keeps_native_member_contract(tmp_path,monkeypatch,case,expected):
    import sys
    from types import SimpleNamespace
    import numpy as np
    import pandas as pd
    from padml import f4
    cache=tmp_path/'cache';key='a'*64;identity='e'*64;name='S1_T001_P01_M01_LOCKED_REFIT'
    root=cache/'atoms'/key;native=root/'native'/name;native.mkdir(parents=True)
    spec={'family':'COXTIME_SET_A','horizons':[1,2]}
    call={'task_id':name,'candidate':{'fixed':True},'locked_epoch':30,'spec':spec}
    raw=canonical_json_bytes({'spec':spec});pin=sha256_bytes(raw)
    source=cache/'inputs'/pin;source.mkdir(parents=True);(source/'input.json').write_bytes(raw)
    os.link(source/'input.json',root/'input.json')
    desc={'key':key,'function':'_run_coxtime_refit_pool_task','executor_source_identity':identity,
        'q_input_sha256':pin,'task':{n:v for n,v in call.items()if n!='spec'},'native_units':[name]}
    (root/'producer.json').write_bytes(canonical_json_bytes(desc))
    loaded={'fit_designs':[np.arange(4.).reshape(-1,1)],'evaluation_designs':[np.asarray([[.5],[2.5]])],
        'columns':['Age'],'evaluation_ids':['e1','e2'],'fit_time':np.arange(1.,5.),'fit_event':np.asarray([1,0,1,0])}
    binding={'fixed':'training-binding'}
    record={'task_id':name,'training_binding':binding,'horizons':[1,2],
        'prediction_input_sha256':sha256_bytes(canonical_json_bytes({'patient_ids':['e1','e2'],
            'design_columns':['Age'],'design_dtype':'float64','design':[[.5],[2.5]]}))}
    (native/'input.json').write_bytes(canonical_json_bytes(record))
    for filename in ['model.bin','baseline.bin']:(native/filename).write_bytes(b'retained-original')
    with (native/'training-log.npz').open('wb') as stream:
        np.savez(stream,columns=np.asarray(['train_loss']),data=np.full((30,1),.25),index=np.arange(30))
    cancelled=native/'native-failure.json';destination=root/'native-failure.json'
    raw_marker=canonical_json_bytes({'error':'BOUNDED_SPAWN_CANCELLED'});cancelled.write_bytes(raw_marker)
    if case=='same_destination':destination.write_bytes(raw_marker)
    elif case=='already_moved':os.rename(cancelled,destination)
    elif case=='other_error':cancelled.write_bytes(canonical_json_bytes({'error':'SCIENCE_FAILURE'}))
    elif case=='noncanonical':cancelled.write_bytes(raw_marker+b' ')
    elif case=='full0_structured':cancelled.write_bytes(canonical_json_bytes({'error':'BOUNDED_SPAWN_CANCELLED',
        'type':'SystemExit','frames':[],'capture_errors':[]}))
    elif case=='source_symlink':
        outside=root/'outside.json';os.rename(cancelled,outside);cancelled.symlink_to(outside)
    elif case=='destination_conflict':destination.write_bytes(canonical_json_bytes({'error':'OTHER_FAILURE'}))
    elif case=='destination_symlink':destination.symlink_to(cancelled)
    elif case=='extra_native_member':(native/'unexpected.json').write_bytes(b'{}')
    elif case=='missing_model_with_values':
        (native/'model.bin').unlink();(root/'values.json').write_bytes(b'{}')
    elif case=='missing_binding':(native/'input.json').unlink()
    inode=(cancelled if cancelled.exists() else destination).stat().st_ino
    science=[p for p in native.iterdir()if p.name!='native-failure.json']
    def snapshot():return {p:(p.read_bytes(),p.stat().st_ino,p.stat().st_mtime_ns,p.stat().st_ctime_ns)for p in science}
    before=snapshot();engines=[]
    health={'training_epoch_count':30,'final_training_loss':.25,'model_state_sha256':'fixed-state'}
    def predictable(*args,**kwargs):
        assert kwargs['coxtime_prediction_geometry']=='NATIVE_BATCH'
        if kwargs.get('health_sink') is not None:kwargs['health_sink'].update(health)
        return {'survival':[[.8,.6],[.7,.5]]}
    def no_fit(*args,**kwargs):pytest.fail('complete cancelled native objects must not refit')
    def native_audit(task):
        engines.append('audit')
        assert task['spec']['native_search_replay'] is True
        result=f4._full_pipeline_python_search_refit(task,loaded,no_fit,np,pd)
        return {'survival':result['survival'].tolist(),'fit_health':result['fit_health']}
    monkeypatch.setattr(k,'_run_coxtime_refit_pool_task',native_audit)
    monkeypatch.setattr(k,'_validate_python_fit_health',lambda family,value,**kwargs:value)
    monkeypatch.setattr(k,'_coxtime_state_sha256',lambda *args:'fixed-state')
    monkeypatch.setitem(sys.modules,'torch',SimpleNamespace(load=lambda *args,**kwargs:{'state_dict':{}}))
    monkeypatch.setattr(f5,'_current_q_original_call',lambda *args:call)
    monkeypatch.setattr(f5,'_current_q_key',lambda *args,**kwargs:key)
    monkeypatch.setattr(f5,'_predict_retained_python_arrays',predictable)
    monkeypatch.setattr(f4,'_full_pipeline_python_search_binding',lambda *args,**kwargs:binding)
    job={'function':'_run_coxtime_refit_pool_task','key':key,'call':call,
        'control':{'cache':str(cache),'source_identity':identity,'read_only':False,'compact':True}}
    if expected:
        with pytest.raises(ContractError,match='^'+expected+'$'):f5._current_q_atom_result(job)
        assert not (root/'receipt.json').exists() and not (root/'audit.json').exists()
        assert engines==(['audit'] if case=='extra_native_member' else [])
    else:
        result=f5._current_q_atom_result(job)
        assert engines==['audit']
        assert destination.read_bytes()==raw_marker and destination.stat().st_ino==inode and not cancelled.exists()
        assert not any('native-failure' in name for name in result['receipt']['members'])
        assert set(__import__('json').loads((native/'object-audit.json').read_text()))=={
            'input.json','model.bin','baseline.bin','training-log.npz','fit-health.json','prediction.json'}
        numbers=f4._full_pipeline_python_search_refit({**call,'spec':{**spec,'native_search_root':str(native.parent),
            'native_search_replay':True,'native_search_numbers':True,'execution_scope':'F5_FULL_DEVELOPMENT_SEARCH',
            'final_search_source':{'program_id':'PADML_F45_REBUILD_20260925'}}},loaded,no_fit,np,pd)
        assert numbers['survival'].tolist()==result['value']['survival']
        assert f5._current_q_atom_result(job)['value']==result['value'] and engines==['audit']
    assert snapshot()==before


@pytest.mark.parametrize("engine", ["R_STOP", "PYTHON_STOP", "PYTHON_REFIT"])
@pytest.mark.parametrize("member_case", ["selected", "absent", "duplicate", "invalid_size"])
def test_q_atom_storage_budget_uses_only_its_selected_imputation(tmp_path, monkeypatch, engine, member_case):
    from padml import runtime
    root, cache = tmp_path / "q", tmp_path / "cache"
    root.mkdir()
    task = _call()
    task["imputation"] = 7
    task["parameters"] = {"max_trees": 100} if engine == "R_STOP" else {"max_nrounds": 100}
    partition = task["registered"]["partitions"][0]
    selected_size = 1024**2
    members = [{"name": f"imp{i:02d}.csv", "sha256": "d" * 64,
        "size_bytes": selected_size if i == 7 else 100 * 1024**2} for i in range(1, 21)]
    if member_case == "absent":
        members = [row for row in members if row["name"] != "imp07.csv"]
    elif member_case == "duplicate":
        members.append(dict(members[6]))
    elif member_case == "invalid_size":
        members[6]["size_bytes"] = True
    partition["covariates"]["members"] = members
    if engine == "R_STOP":
        task["producer_kind"] = "GBM_STOP_CURVE"
        task["selected_parents"] = ["Age"]
        spec, registered = task.pop("spec"), task.pop("registered")
        spec["family"] = "GBM_COX"
        call = (spec, registered, [task], "UNFITTED", "UNFITTED", "GROUPED_COX_LOCK", partition)
        fn = k._run_r_prediction_pool_task
    elif engine == "PYTHON_STOP":
        call, fn = (task, partition), k._run_python_stop_pair_pool_task
    else:
        call, fn = task, k._run_xgb_refit_pool_task
    policy = {"scratch_bytes_per_worker": 1024, "memory_bytes_per_worker": 1024**3}
    control = {"root": str(root), "cache": str(cache), "read_only": False, "workers": 24,
        "resource_policy": policy}
    monkeypatch.setitem(f5._CURRENT_Q_STATE, str(root), {"coordinates": {}, "references": {}})
    monkeypatch.setattr(f5, "_current_q_reuse_key", lambda *args: "a" * 64)
    stages = []
    class AdmissionObserved(Exception):
        pass
    def admit(passed_policy, *args, **kw):
        assert passed_policy == policy
        stages.append(kw)
        raise AdmissionObserved
    monkeypatch.setattr(runtime, "admit_stage", admit)
    monkeypatch.setattr(f5, "_current_q_prepare_inputs", lambda *args: pytest.fail("NO_DISPATCH"))
    if member_case != "selected":
        with pytest.raises(ContractError, match="F45_Q_STORAGE_GEOMETRY_UNKNOWN"):
            f5._current_q_task_batch({"current_q": control}, fn, [call], selected_slots=24)
        assert stages == []
        return
    with pytest.raises(AdmissionObserved):
        f5._current_q_task_batch({"current_q": control}, fn, [call], selected_slots=24)
    stop = engine != "PYTHON_REFIT"
    curve = 3 * (100 if stop else 37) * 8
    object_budget = max(64 * 1024**2, 8 * selected_size) if stop else 0
    retained = 8 * 1024**2 + 3 * 37 * 48 + (2 * curve + object_budget if stop else 0)
    assert stages[0]["retained_bytes"] == stages[0]["publication_bytes"] == retained
    assert stages[0]["transient_bytes_per_worker"] == max(1024, 3 * curve + 32 * selected_size + object_budget)
    assert stages[0]["task_disk_bytes"] == [(retained, retained)]
    assert not cache.exists()


def test_q_json_recent_real_clock_never_enters_reuse_cache(tmp_path):
    source = tmp_path / "fresh.json"
    raw = canonical_json_bytes({"value": "OLD"})
    f5._Q_JSON_CACHE.clear()
    try:
        source.write_bytes(raw)
        assert f5._current_q_json(source, sha256_bytes(raw)) == {"value": "OLD"}
        assert not f5._Q_JSON_CACHE
        source.write_bytes(raw.replace(b"OLD", b"NEW"))
        with pytest.raises(ContractError, match="F45_Q_INPUT_DRIFT"):
            f5._current_q_json(source, sha256_bytes(raw))
        assert not f5._Q_JSON_CACHE
    finally:
        f5._Q_JSON_CACHE.clear()
