from __future__ import annotations

import copy
import json
from pathlib import Path
import subprocess
import sys
from types import SimpleNamespace

import pytest

from padml.bundle import ContractError, canonical_json_bytes, read_safe_zip, write_deterministic_zip


def stop_job(tmp_path, family="GBM_COX"):
    from padml.f4 import _f4_model_seed
    coordinates = {"purpose": "O_FIT", "outer_fold": 1, "repeat": 1, "inner_fold": 1, "imputation": 1}
    parameters = ({"max_trees": 3, "minimum_improvement": 0.0001, "early_stopping_patience": 2,
                   "early_stopping_metric": "cox_deviance",
                   "post_selection_refit": "full_main_training_at_selected_n_trees",
                   "locked_iteration_mode": "full_main_training_without_reselection"}
                  if family == "GBM_COX" else {
                      "max_nrounds": 3, "early_stopping_rounds": 2, "stop_scope": "training_only",
                      "post_selection_refit": "full_main_training_at_best_rounds",
                      "locked_iteration_mode": "full_main_training_without_reselection"})
    task = {"family": family, "selected_parents": ["AST_ALT"],
            "parameters": {"family": family, "parameters": parameters}, "stop_parameters": parameters,
            "imputation": 1, "f4_coordinates": coordinates, "registered_model_seed": _f4_model_seed(family, coordinates),
            "model_seed": _f4_model_seed(family, coordinates), "row_count": 2, "family_design_column_count": 1}
    return {"root": str(tmp_path / "component"), "entries": {
        "task.json": canonical_json_bytes(task),
        "recipe.json": canonical_json_bytes({"preprocessing_mode": "F2_RAW_CANONICAL_AUTHORITY_LEVELS",
                                               "test_only": "UNFITTED"}),
        "fit-covariates.csv": b"Patient_ID,Center,AST_ALT\n001,36,1\n002,38,2\n",
        "fit-response.csv": b"Patient_ID,All_Cause_Death,Death_Followup_months\n001,1,20\n002,0,30\n",
        "prediction-covariates.csv": b"Patient_ID,Center,AST_ALT\n003,55,1.5\n",
        "stop-response.csv": b"Patient_ID,All_Cause_Death,Death_Followup_months\n003,1,25\n"}}


@pytest.mark.parametrize("family", ["GBM_COX", "XGBOOST_COX"])
def test_stop_component_retains_before_lock_and_replays_without_fit(tmp_path, monkeypatch, family):
    from padml.f4 import _execute_f4_stop_component, _replay_f4_stop_component
    job, calls = stop_job(tmp_path, family), []

    def unfitted_native(entries, root, *, replay):
        calls.append(replay)
        if replay:
            assert (root / "model.bin").read_bytes() == b"UNFITTED_STOP_MODEL"
        else:
            (root / "model.bin").write_bytes(b"UNFITTED_STOP_MODEL")
        if family == "GBM_COX":
            for name in ("native.stdout", "native.stderr"):
                (root / name).write_bytes(b"UNFITTED_TEST_ONLY")
        return {"test_only": "UNFITTED_FUNCTION"}, {"test_only": "UNFITTED_CURVE"}, None

    def original_lock_stub(entries, sealed, runtime):
        assert sealed == {"test_only": "UNFITTED_CURVE"} and runtime is None
        assert (Path(job["root"]) / "model.bin").read_bytes() == b"UNFITTED_STOP_MODEL"
        assert (Path(job["root"]) / "native-function.json").is_file()
        return {"test_only": "UNFITTED_LOCK", "selected": 2}

    monkeypatch.setattr("padml.f4._run_f4_stop_native", unfitted_native)
    monkeypatch.setattr("padml.f4._f4_stop_lock", original_lock_stub)
    lock = _execute_f4_stop_component(job)
    archive = Path(job["root"]).with_suffix(".zip")
    assert _replay_f4_stop_component({**job, "archive": archive}) == lock
    assert calls == [False, True]
    changed = read_safe_zip(archive)
    changed["lock.json"] = canonical_json_bytes({**lock, "selected": 3})
    wrong = tmp_path / "wrong-lock.zip"
    write_deterministic_zip(wrong, changed)
    with pytest.raises(ContractError, match="LOCK_REPLAY_MISMATCH"):
        _replay_f4_stop_component({**job, "archive": wrong})
    mutation = copy.deepcopy(job)
    mutation["entries"]["stop-response.csv"] = mutation["entries"]["stop-response.csv"].replace(b",1,25", b",1,26")
    with pytest.raises(ContractError, match="INPUT_REPLAY_MISMATCH"):
        _replay_f4_stop_component({**mutation, "archive": archive})


def test_stop_evaluation_failure_preserves_native_object_and_function(tmp_path, monkeypatch):
    from padml.f4 import _execute_f4_stop_component
    job = stop_job(tmp_path)

    def unfitted_native(entries, root, *, replay):
        assert not replay
        (root / "model.bin").write_bytes(b"UNFITTED_STOP_MODEL")
        return {"test_only": "UNFITTED_FUNCTION"}, {}, None

    monkeypatch.setattr("padml.f4._run_f4_stop_native", unfitted_native)
    monkeypatch.setattr("padml.f4._f4_stop_lock", lambda *args: (_ for _ in ()).throw(ContractError("INJECTED_LOCK_FAILURE")))
    with pytest.raises(ContractError, match="INJECTED_LOCK_FAILURE") as failure:
        _execute_f4_stop_component(job)
    root = Path(job["root"])
    assert (root / "model.bin").read_bytes() == b"UNFITTED_STOP_MODEL"
    assert (root / "native-function.json").is_file() and (root / "native-failure.json").is_file()
    assert not root.with_suffix(".zip").exists()
    assert f"F4_STOP_NATIVE_EVIDENCE_RETAINED:{root}" in failure.value.__notes__


@pytest.mark.parametrize("family", ["GBM_COX", "XGBOOST_COX"])
def test_stop_replay_batch_preserves_native_locks_and_exact_in_operation_reuse(tmp_path, monkeypatch, family):
    from padml import f4
    calls, jobs = [], []
    for imp in range(1, 21):
        job = stop_job(tmp_path, family)
        task = json.loads(job["entries"]["task.json"])
        task["imputation"] = task["f4_coordinates"]["imputation"] = imp
        task["registered_model_seed"] = task["model_seed"] = f4._f4_model_seed(family, task["f4_coordinates"])
        job["entries"]["task.json"] = canonical_json_bytes(task)
        job["name"] = f"O1_R1_K1_M{imp:02d}_STOP"
        job["archive"] = tmp_path / (job["name"] + ".zip")
        entries = {**job["entries"], "model.bin": b"UNFITTED_STOP_OBJECT",
                   "native-function.json": canonical_json_bytes({"UNFITTED": True}),
                   "lock.json": canonical_json_bytes({"UNFITTED": True, "imputation": imp})}
        if family == "GBM_COX":
            entries.update({"native.stdout": b"", "native.stderr": b""})
        write_deterministic_zip(job["archive"], entries)
        jobs.append(job)
    def native(entries, root, *, replay):
        assert replay is True and (root / "model.bin").read_bytes() == b"UNFITTED_STOP_OBJECT"
        calls.append(json.loads(entries["task.json"])["imputation"])
        return {"UNFITTED": True}, {}, None
    monkeypatch.setattr(f4, "_run_f4_stop_native", native)
    monkeypatch.setattr(f4, "_f4_stop_lock", lambda entries, *a, **k:
        {"UNFITTED": True, "imputation": json.loads(entries["task.json"])["imputation"]})
    expected = f4._replay_f4_stop_batch(jobs)
    assert calls == list(range(1, 21))
    calls.clear()
    def pool(worker, submitted, *, selected_slots):
        assert worker is f4._replay_f4_stop_component and selected_slots == 56
        completed = {job["name"]: worker(job) for job in reversed(submitted)}
        return [completed[job["name"]] for job in submitted]
    monkeypatch.setattr(f4, "_bounded_ordered_spawn", pool)
    actual = f4._replay_f4_stop_batch(jobs, workers=56)
    assert actual == expected and calls == list(range(20, 0, -1))
    calls.clear()
    replayed = {job["name"]: {**job, "lock": lock} for job, lock in zip(jobs, actual, strict=True)}
    assert f4._replay_f4_stop_batch(jobs, workers=56, replayed=replayed) == expected
    assert calls == []
    for damage in ("missing", "entries", "archive", "native_evidence"):
        altered, request = copy.deepcopy(replayed), copy.deepcopy(jobs)
        if damage == "missing":
            altered.pop(jobs[0]["name"])
        elif damage == "entries":
            altered[jobs[0]["name"]]["entries"]["stop-response.csv"] += b"\n"
        elif damage == "archive":
            altered[jobs[0]["name"]]["archive"] = jobs[1]["archive"]
        else:
            request[0]["replay_evidence"] = tmp_path / "must-produce-native-evidence"
        with pytest.raises(ContractError, match="STOP_REUSE_SOURCE_MISMATCH"):
            f4._replay_f4_stop_batch(request, workers=56, replayed=altered)
    assert calls == []


def test_xgb_native_return_is_saved_before_original_postfit_checks(tmp_path, monkeypatch):
    from padml.f4 import _execute_f4_stop_component
    import numpy as np
    job = stop_job(tmp_path, "XGBOOST_COX")
    attributes, train_calls = {}, []

    class UnfittedBooster:
        def set_attr(self, **kwargs):
            attributes.update(kwargs)

        def save_raw(self, **kwargs):
            assert kwargs == {"raw_format": "ubj"}
            return canonical_json_bytes({"test_only": "UNFITTED_BOOSTER", "attributes": attributes})

    def unfitted_train(*args, **kwargs):
        train_calls.append("UNFITTED_STUB")
        return UnfittedBooster()

    def original_helper_stub(engine, *args):
        engine.train("UNFITTED_ARGUMENT")
        assert (Path(job["root"]) / "model.bin").is_file()
        raise ContractError("INJECTED_ORIGINAL_POSTFIT_CHECK_FAILURE")

    monkeypatch.setitem(sys.modules, "xgboost", SimpleNamespace(train=unfitted_train, DMatrix=object))
    monkeypatch.setattr("padml.f5._final_python_design", lambda family, task, rows, recipe:
                        (np.asarray([[float(row["AST_ALT"])] for row in rows]), ["AST_ALT"], np, None))
    monkeypatch.setattr("padml.f2_kernel._xgb_prediction_function_seal", original_helper_stub)
    with pytest.raises(ContractError, match="INJECTED_ORIGINAL_POSTFIT_CHECK_FAILURE"):
        _execute_f4_stop_component(job)
    assert train_calls == ["UNFITTED_STUB"]
    saved = json.loads((Path(job["root"]) / "model.bin").read_bytes())
    assert saved["test_only"] == "UNFITTED_BOOSTER"
    binding = json.loads(saved["attributes"]["padml_f4_stop_training_binding"])
    assert binding["training"]["model_seed"] == 351101
    assert binding["training"]["imputation"] == 1
    assert binding["stop_parameters"]["max_nrounds"] == 3


@pytest.mark.parametrize("damage", [False, True])
def test_gbm_original_binary_consumer_only_removes_copies(tmp_path, monkeypatch, damage):
    """Explicitly unfitted R-output fixture through the real binary/loss readers."""
    import struct
    from padml.bundle import sha256_bytes
    from padml.f4 import _execute_f4_stop_component
    job = stop_job(tmp_path)

    def unfitted_process(command, **kwargs):
        spec = json.loads(Path(command[-1]).read_bytes())
        assert "stop-response.csv" not in json.dumps(spec)
        assert spec["action"] == "FIT" and spec["task"]["model_seed"] == 351101
        root = Path(spec["output_path"]).parent
        Path(spec["model_path"]).write_bytes(b"UNFITTED_R_STOP_MODEL")
        channel = {"schema_version": "1.0.0", "kind": "PADML_F2_OPERATION_LOCAL_RISK_MATRIX_CHANNEL"}
        for role, rows in (("fit", [[0.1, 0.2, 0.3], [0.2, 0.4, 0.6]]),
                           ("evaluation", [[0.3, 0.2, 0.1]])):
            name = f"risk-001-gbm-{role}.bin"
            raw = struct.pack("<" + "d" * (len(rows) * 3), *(x for row in rows for x in row))
            (root / name).write_bytes(raw)
            channel[role] = {"schema_version": "1.0.0", "kind": "PADML_F2_OPERATION_LOCAL_RISK_MATRIX",
                "encoding": "IEEE754_FLOAT64", "byte_order": "LITTLE_ENDIAN", "row_order": "ROW_MAJOR",
                "file_name": name, "rows": len(rows), "columns": 3, "size_bytes": len(raw), "sha256": sha256_bytes(raw)}
        if damage:
            (root / "risk-001-gbm-fit.bin").write_bytes(b"x" * channel["fit"]["size_bytes"])
        health = {"converged": True, "warning_count": 0, "tree_count": 3, "training_row_count": 2,
                  "independent_variable_count": 1, "training_loss_count": 3,
                  "minimum_training_loss": 1.0, "maximum_training_loss": 2.0,
                  "cox_objective": {"implementation": "GROUPED_BRESLOW_V1", "engine_version": "2.3.1.9001",
                                    "source_correction": "cox-breslow-ties-v1"}}
        Path(spec["output_path"]).write_bytes(canonical_json_bytes({"maximum": 3, "risk_matrix_channel": channel,
            "ordered_parent_column_map": [{"parent": "AST_ALT", "columns": ["AST_ALT"]}], "fit_health": health}))
        return SimpleNamespace(returncode=0)

    monkeypatch.setattr(subprocess, "run", unfitted_process)
    if damage:
        with pytest.raises(ContractError, match="RISK_MATRIX_FILE_INVALID"):
            _execute_f4_stop_component(job)
    else:
        lock = _execute_f4_stop_component(job)
        assert 1 <= lock["selected_trees"] <= 3
        assert lock["kind"] == "PADML_F2_GBM_TREE_LOCK"
    root = Path(job["root"])
    assert (root / "model.bin").read_bytes() == b"UNFITTED_R_STOP_MODEL"
    assert (root / "native/risk-001-gbm-fit.bin").is_file()
    assert (root / "native/risk-001-gbm-evaluation.bin").is_file()
    assert not (root / "native/consume/risk-001-gbm-fit.bin").exists()
    if damage:
        assert (root / "native-failure.json").is_file() and not root.with_suffix(".zip").exists()


def test_gbm_adapter_preserves_original_ast_and_replays_only_unfitted_stub(tmp_path):
    """R parse/AST and explicit unfitted objects; never load/run GBM training."""
    from padml.runtime import RSCRIPT_EXECUTABLE
    kernels = Path(__file__).resolve().parents[1] / "padml/kernels"
    script = r'''
args <- commandArgs(trailingOnly=TRUE)
definitions <- function(path) Filter(function(x) is.call(x) && identical(x[[1]],as.name("<-")) &&
  is.symbol(x[[2]]) && is.call(x[[3]]) && identical(x[[3]][[1]],as.name("function")), as.list(parse(path)))
adapter <- definitions(args[[1]])
eval(adapter[[which(vapply(adapter,function(x) identical(x[[2]],as.name("gbm_stop_native_function")),logical(1)))]])
originals <- definitions(args[[2]])
eval(originals[[which(vapply(originals,function(x) identical(x[[2]],as.name("gbm_stop_curve")),logical(1)))]])
original_code <- as.list(body(gbm_stop_curve))
wrapped <- gbm_stop_native_function(gbm_stop_curve,FALSE)
wrapped_code <- as.list(body(wrapped))
extra <- which(vapply(wrapped_code,function(x) is.call(x) && identical(x[[1]],as.name("{")) &&
  grepl("binding <-",paste(deparse(x),collapse=" "),fixed=TRUE),logical(1)))
stopifnot(length(extra)==1L,identical(wrapped_code[-extra],original_code))
replayed <- gbm_stop_native_function(gbm_stop_curve,TRUE)
stopifnot(!"gbm.fit" %in% all.names(body(replayed)),!"set.seed" %in% all.names(body(replayed)))
need <- function(x,code) if (!isTRUE(x)) stop(code,call.=FALSE)
calls <- 0L
gbm.fit <- function(...) {calls <<- calls+1L; list(kind="UNFITTED_STUB")}
original <- function(train,test,selected,parameters,model_seed,recipe,risk_prefix) {
  train_design <- as.matrix(train$x); test_design <- as.matrix(test$x); design_map <- selected
  set.seed(model_seed,kind="L'Ecuyer-CMRG")
  fit_warnings <- character()
  fit <- withCallingHandlers(gbm.fit(x=train_design),warning=function(w) stop(w))
  list(fit=fit,training=train_design,application=test_design)
}
task <- list(test_only="UNFITTED",imputation=1L); replay <- FALSE; model_path <- args[[3]]
train <- data.frame(x=c(1,2)); test <- data.frame(x=3)
f <- gbm_stop_native_function(original,FALSE)
value <- f(train,test,"x",list(max_trees=3L),351101L,NULL,"unused")
stopifnot(calls==1L,file.exists(model_path))
retained <- readRDS(model_path); replay <- TRUE
gbm.fit <- function(...) stop("REPLAY_MUST_NOT_FIT")
f <- gbm_stop_native_function(original,TRUE)
state <- .Random.seed
stopifnot(identical(f(train,test,"x",list(max_trees=3L),351101L,NULL,"unused"),value),
          identical(state,.Random.seed),calls==1L)
bad <- tryCatch(f(transform(train,x=x+1),test,"x",list(max_trees=3L),351101L,NULL,"unused"),error=identity)
stopifnot(inherits(bad,"error"),grepl("NATIVE_INPUT_MISMATCH",conditionMessage(bad)))
cat("AST_AND_UNFITTED_REPLAY_PASS; real_fits=0\n")
'''
    result = subprocess.run([RSCRIPT_EXECUTABLE, "--vanilla", "-e", script,
                             str(kernels / "f4_gbm_stop.R"), str(kernels / "f2_model_development.R"),
                             str(tmp_path / "unfitted.rds")], capture_output=True, text=True, timeout=30)
    assert result.returncode == 0, result.stdout + result.stderr
    assert "AST_AND_UNFITTED_REPLAY_PASS; real_fits=0" in result.stdout


@pytest.mark.parametrize("nonfinite", [False, True])
def test_operation_risk_matrix_maps_one_readonly_entity(tmp_path, nonfinite):
    import mmap
    import struct
    from padml import f2_kernel as f2
    from padml.bundle import sha256_bytes
    raw = struct.pack("<4d", 1, 2, 3, float("nan") if nonfinite else 4)
    path = tmp_path / "risk.bin"
    path.write_bytes(raw)
    descriptor = {"schema_version": "1.0.0", "kind": "PADML_F2_OPERATION_LOCAL_RISK_MATRIX",
        "encoding": "IEEE754_FLOAT64", "byte_order": "LITTLE_ENDIAN", "row_order": "ROW_MAJOR",
        "file_name": path.name, "rows": 2, "columns": 2, "size_bytes": len(raw), "sha256": sha256_bytes(raw)}
    def read():
        return f2._read_operation_local_risk_matrix(descriptor, tmp_path,
            expected_file_name=path.name, expected_rows=2, expected_columns=2)
    if nonfinite:
        with pytest.raises(ContractError, match="F2_R_RISK_MATRIX_FILE_INVALID"):
            read()
        return
    value = read()
    assert isinstance(value.raw, mmap.mmap) and memoryview(value.raw).readonly
    # Last numerical consumer owns the map even when the disposable name retires.
    path.unlink()
    assert value.column(0).tolist() == [1, 3] and value.column(1).tolist() == [2, 4]
    assert not value.column(0).flags.writeable
    seal = f2._seal_cox_risk_curve(["f1", "f2"], ["e1", "e2"], value, value, 2)
    assert f2._validate_cox_risk_seal(seal)["fit_eta"] == value.descriptor()
    import pickle
    transported = pickle.loads(pickle.dumps(seal))
    assert f2._validate_cox_risk_seal(transported) == seal["payload"]
    assert transported["matrices"][0].column(1).tolist() == [2, 4]
    with pytest.raises(TypeError):
        value.raw[0] = 0


@pytest.mark.parametrize('damage', [None, 'bytes', 'symlink', 'nonfinite'])
def test_retained_gbm_risk_reads_original_linked_entity_without_copy(tmp_path, damage):
    import os
    import struct
    from padml import f2_kernel as f2
    from padml.bundle import sha256_bytes
    root = tmp_path/'native'
    root.mkdir()
    original = root/'risk-001-gbm-fit.bin'
    raw = struct.pack('<4d', 1, 2, 3, float('nan') if damage == 'nonfinite' else 4)
    original.write_bytes(raw)
    alias = tmp_path/'existing-producer-link.bin'
    os.link(original, alias)
    descriptor = dict(schema_version='1.0.0', kind='PADML_F2_OPERATION_LOCAL_RISK_MATRIX',
        encoding='IEEE754_FLOAT64', byte_order='LITTLE_ENDIAN', row_order='ROW_MAJOR',
        file_name=original.name, rows=2, columns=2, size_bytes=len(raw), sha256=sha256_bytes(raw))
    if damage == 'bytes':
        original.write_bytes(struct.pack('<4d', 1, 2, 3, 5))
    elif damage == 'symlink':
        original.unlink()
        original.symlink_to(alias)
    before = {p: (p.lstat().st_ino, p.lstat().st_size, p.lstat().st_mtime_ns, p.lstat().st_ctime_ns)
              for p in (original, alias)}
    args = dict(expected_file_name=original.name, expected_rows=2, expected_columns=2)
    with pytest.raises(ContractError, match='F2_R_RISK_MATRIX_FILE_INVALID'):
        f2._read_operation_local_risk_matrix(descriptor, root, **args)
    if damage:
        with pytest.raises(ContractError, match='F2_R_RISK_MATRIX_FILE_INVALID'):
            f2._read_operation_local_risk_matrix(descriptor, root, retained=True, **args)
    else:
        matrix = f2._read_operation_local_risk_matrix(descriptor, root, retained=True, **args)
        assert matrix.column(1).tolist() == [2, 4]
        assert not matrix.column(1).flags.writeable
        matrix.raw.close()
    assert list(root.iterdir()) == [original]
    assert before == {p: (p.lstat().st_ino, p.lstat().st_size, p.lstat().st_mtime_ns, p.lstat().st_ctime_ns)
                      for p in before}
