"""Native evaluator transport retention only: subprocess output is UNFITTED."""
import ast
from pathlib import Path
from types import SimpleNamespace

import pytest


def test_extension_report_consumes_qualified_heads_and_preserves_application_identity(tmp_path,monkeypatch):
    from copy import deepcopy
    import hashlib
    from padml import reports, evaluation_extension as e, auc_research as a, integrated, f4, f5_application, nested_loco as n
    from padml.bundle import canonical_json_bytes, ContractError
    units=[{'unit_id':f'FULL0-H{h:02d}','kind':'FULL0','horizon':h} for h in (6,12,24,36)]
    units += [{'unit_id':f'PRIMARY-H06-O{o}','kind':'PRIMARY','horizon':6} for o in range(1,7)]
    run={'identity':'a'*64,'source_identity':'b'*64,'run_root':str(tmp_path),'units':units,'evaluation_extension':e.decision()}
    monkeypatch.setattr(integrated,'same_batch_generations',lambda _:{'a'*64:'b'*64})
    monkeypatch.setattr(reports,'same_batch_generations',lambda _:{'a'*64:'b'*64})
    study={'status':'UNFITTED_ENGINEERING_FIXTURE','coordinates':[]}
    monkeypatch.setattr(a,'complete_summary',lambda owners:study if set(owners)==set(e.RESEARCH_UNITS) else pytest.fail('owner coverage'))
    producer={'run_identity':'a'*64,'source_identity':'b'*64}
    def mi(uid):
        return n._sealed({'binding':{'source_unit':uid,'decision_sha256':e.decision()['identity_sha256']},
            'coordinates':[{'original_check':'ODD_EVEN_'+k+'_NOT_ESTIMABLE',
                'odd':f4._evaluation_metric(.2),'even':f4._evaluation_metric(.3),
                'absolute_difference':f4._evaluation_metric(abs(.2-.3))} for k in e.MI_LABELS],
            'new_prediction_model_fits':0,'new_mice_chains':0,'new_shap_solves':0,'status':'COMPLETED',
            'unresolved_numerical_failures':0,'statistical_not_estimable':0,'patient_count':2112,
            'patient_order_sha256':'c'*64,'centers':['36','38','39','48','52','54'],'ipcw_population':'SIX_CENTERS'})
    h36=mi('FULL0-H36');h36_name='units/FULL0-H36/post-result-repair-20261008/mi-diagnostic.json'
    app_prefix=f5_application.application_repair_decision()['identity_sha256']
    coverage={'unique_patients_across_four_lines':179,'line_patient_assessments':716,'lines':{
        str(h):{'patient_count':179,'center_counts':{'36':50,'38':2,'39':50,'48':12,'52':50,'54':15},
            'patient_order_sha256':'d'*64,'source':f'units/FULL0-H{h:02d}/application-repair/{app_prefix}/full-a04/cohort/cohort.json'}
        for h in (6,12,24,36)}}
    heads={};children={}
    for unit in units:
        if not e.eligible(run,unit):continue
        uid=unit['unit_id'];prefix=f'units/{uid}/{e.PREFIX}/';components={};values={};sources={}
        if unit['kind']=='FULL0':
            value=mi(uid);values[prefix+'mi-diagnostic.json']=value
            components['mi']={'coordinate_count':10,'new_prediction_model_fits':0,'new_evaluation_calibration_fit_ceiling':6,'source_identity':value['identity_sha256']}
        if uid in e.RESEARCH_UNITS:
            tasks=a.tasks(uid);value=n._sealed({'producer':producer})
            values[prefix+'research/result.json']=value
            components['research']={'dataset_count':len(tasks),'P_count':1999*len(tasks),
                'hierarchical_inferences':3*sum(t['scenario']>4 for t in tasks),'identity_sha256':value['identity_sha256']}
        if uid=='FULL0-H06':
            components.update(application_coverage=coverage,h36_mi_reference={'source':h36_name,'source_identity':h36['identity_sha256']})
            values[h36_name]=h36
            for h in (6,12,24,36):
                for suffix in ('result.json','cohort/cohort.json'):
                    sources[f'units/FULL0-H{h:02d}/application-repair/{app_prefix}/full-a04/'+suffix]={'sha256':'e'*64,'size_bytes':100}
                sources[f'units/FULL0-H{h:02d}/postprocess/post-result-repair-20261008/result.json']={'sha256':'f'*64,'size_bytes':100}
        for name,value in values.items():
            raw=canonical_json_bytes(value);sources[name]={'sha256':hashlib.sha256(raw).hexdigest(),'size_bytes':len(raw)}
        children[uid]=values
        heads[uid]=n._sealed({'kind':'PADML_EVALUATION_EXTENSION_UNIT_V1','producer':producer,'decision_sha256':e.decision()['identity_sha256'],
            'target_unit':uid,'status':'COMPLETED','direct_consumer_completed':True,'components':components,'sources':sources})
    current={'identity_sha256':'f'*64,'full0_h36_legacy_incomplete_resolution':{
        'current_coordinates':h36['coordinates'],'unresolved_numerical_failures':0,'current_source_identity':h36['identity_sha256']},
        'a04_review_required_lines':['12'],'cross_time':{'identity_sha256':'e'*64},'original_application':{'status':'ORIGINAL96_PRESERVED'}}
    result=reports.extension_report(run,heads,children,current)
    assert result['mi_coordinate_count']==40 and result['application_coverage']==coverage
    assert result['research']==study and result['original96_regression']==current['original_application']
    reports.write_extension_report(tmp_path,result)
    assert (tmp_path/'evaluation-extension.json').read_bytes()==canonical_json_bytes(result)
    damaged=deepcopy(heads);row=damaged['FULL0-H06'];row['components']['application_coverage']['lines']['6']['patient_order_sha256']='invalid'
    damaged['FULL0-H06']=n._sealed({k:v for k,v in row.items() if k!='identity_sha256'})
    with pytest.raises(ContractError):reports.extension_report(run,damaged,children,current)


def test_full0_extension_uses_actual_parent_paths_and_keeps_distinct_h36_mi(tmp_path,monkeypatch):
    from copy import deepcopy
    from padml import evaluation_extension as e, f5_application, integrated, auc_research, nested_loco as n
    from padml.bundle import ContractError
    units=[{'unit_id':f'FULL0-H{h:02d}','kind':'FULL0','horizon':h} for h in (6,12,24,36)]
    run={'identity':'a'*64,'source_identity':'b'*64,'run_root':str(tmp_path),
        'units':units,'evaluation_extension':e.decision()}
    monkeypatch.setattr(integrated,'same_batch_generations',lambda _:{'a'*64:'b'*64})
    prefix=f'units/FULL0-H06/{e.PREFIX}/'
    names={prefix+'mi-diagnostic.json',prefix+'research/result.json',
        'units/FULL0-H36/post-result-repair-20261008/mi-diagnostic.json'}
    ident=f5_application.application_repair_decision()['identity_sha256']
    for h in (6,12,24,36):
        names.add(f'units/FULL0-H{h:02d}/postprocess/post-result-repair-20261008/result.json')
        names.update(f'units/FULL0-H{h:02d}/application-repair/{ident}/full-a04/'+s
            for s in ('result.json','cohort/cohort.json'))
    coordinates=auc_research.tasks('FULL0-H06')
    value={'kind':'PADML_EVALUATION_EXTENSION_UNIT_V1','decision_sha256':e.decision()['identity_sha256'],
        'target_unit':'FULL0-H06','status':'COMPLETED','direct_consumer_completed':True,
        'producer':{'run_identity':'a'*64,'source_identity':'b'*64},
        'sources':{name:{'sha256':'c'*64,'size_bytes':100} for name in names},
        'components':{'mi':{'coordinate_count':10,'new_prediction_model_fits':0,'new_evaluation_calibration_fit_ceiling':6},
            'research':{'dataset_count':len(coordinates),'P_count':1999*len(coordinates),
                'hierarchical_inferences':3*sum(t['scenario']>4 for t in coordinates)},
            'application_coverage':{},'h36_mi_reference':{}}}
    sealed=n._sealed(value)
    assert len(names)==15 and e.validate_result(run,units[0],sealed)==sealed
    for case in ('missing','extra','wrong_parent','wrong_mi'):
        wrong=deepcopy(value);sources=wrong['sources']
        if case=='missing':sources.pop(prefix+'mi-diagnostic.json')
        elif case=='extra':sources['unrelated.json']={'sha256':'d'*64,'size_bytes':100}
        else:
            old=('units/FULL0-H06/postprocess/post-result-repair-20261008/result.json' if case=='wrong_parent'
                else 'units/FULL0-H36/post-result-repair-20261008/mi-diagnostic.json')
            new=old.replace('/postprocess/','/') if case=='wrong_parent' else old.replace('/post-result-','/postprocess/post-result-')
            sources[new]=sources.pop(old)
        with pytest.raises(ContractError,match='SOURCE_COVERAGE'):e.validate_result(run,units[0],n._sealed(wrong))


def test_mi_direct_consumer_rejects_duplicate_coordinate_and_hidden_failure():
    from copy import deepcopy
    from padml import evaluation_extension as e,f4
    from padml.bundle import ContractError
    coords=[{'original_check':'ODD_EVEN_'+v+'_NOT_ESTIMABLE',
        'odd':f4._evaluation_metric(.2),'even':f4._evaluation_metric(.3),
        'absolute_difference':f4._evaluation_metric(abs(.2-.3))} for v in e.MI_LABELS]
    result={'coordinates':coords,'unresolved_numerical_failures':0,'statistical_not_estimable':0}
    assert e.validate_mi(result)==result
    wrong=deepcopy(result);wrong['coordinates'][-1]=deepcopy(wrong['coordinates'][0])
    with pytest.raises(ContractError,match='MI_COORDINATE_COVERAGE'):e.validate_mi(wrong)
    wrong=deepcopy(result);wrong['coordinates'][0]['odd']=f4._evaluation_metric(None,['SOLVER_FAILED'],status='NUMERICAL_FAILURE')
    wrong['coordinates'][0]['absolute_difference']=f4._evaluation_metric(None,['SOLVER_FAILED'],status='NUMERICAL_FAILURE')
    with pytest.raises(ContractError,match='MI_COUNTS_DRIFT'):e.validate_mi(wrong)


def test_clinical_small_point_contrasts_keep_original_bytes_and_paired_definition():
    from padml import evaluation_extension as e,f4
    from padml.bundle import canonical_json_bytes
    table={'numbers':{k:{'auc':f4._evaluation_metric(v)} for k,v in
        zip(('APPARENT','OOF-R1','OOF-R2','OOF-R3'),(.8,.6,.7,.8))}}
    before=canonical_json_bytes(table);out=e.clinical_numbers(table)
    assert out['OOF-MEAN']['auc']['value']==pytest.approx(.7)
    assert out['APPARENT_MINUS_OOF_MEAN']['auc']['value']==pytest.approx(.1)
    assert canonical_json_bytes(table)==before


def test_clinical_direct_consumer_rejects_impossible_interval_and_ineligible_population(tmp_path,monkeypatch):
    from copy import deepcopy
    from padml import evaluation_extension as e,f4,nested_loco as n
    from padml.bundle import ContractError
    run={'identity':'a'*64,'source_identity':'b'*64,'evaluation_extension':e.decision(),'run_root':str(tmp_path)}
    unit={'unit_id':'PRIMARY-H06-O1','kind':'PRIMARY','horizon':6}
    key='STUDENTIZED|CENTER|6|APPARENT'
    gate={'identity_sha256':'c'*64,'scope_results':{key:{'confirmed':28,'failed':0}}}
    row={'table':'PRIMARY/H06/38','branch':'APPARENT','method':'STUDENTIZED','original':f4._evaluation_metric(.7),
        'confirmation_key':key,'confirmation':gate['scope_results'][key],'interval':[.5,.9],
        'new_point':.7,'status':'CONDITIONAL_SUPPLEMENT_WITH_REGISTERED_SCOPE_VALIDATION',
        'reasons':[],'P_count':1999,'invalid_P_ids':[],'failure_P_ids':{},'patient_count':91,
        'centers':['38'],'patient_order_sha256':'d'*64,'fixed_center_counts':None}
    value={'kind':'PADML_AUC_CLINICAL_SUPPLEMENT_DISPOSITION_V1','target_unit':unit['unit_id'],
        'producer':{'run_identity':'a'*64,'source_identity':'b'*64},'gate_identity':gate['identity_sha256'],
        'status':'DISPOSITION_COMPLETE','rows':[row],'coordinate_count':1,'new_prediction_model_fits':0,
        'new_training_mice':0,'new_shap_solves':0,'new_resampling':0,
        'formal_references':[{'path':e.GATE},{'path':'units/PRIMARY-H06-O1/postprocess/evaluation-amendment/point.zip'},
            {'path':'binding/binding.json'}],
        'clinical_rng_universe':{'patient_order_sha256':'e'*64,'patient_count':2112,'source_identity':'b'*64,'seed':730000001}}
    monkeypatch.setattr(f4,'_evaluation_provenance',lambda _:{'generations':{'a'*64:'b'*64}})
    assert e.validate_clinical(run,unit,n._sealed(value),gate)
    changes=[({'original':f4._evaluation_metric(None,['ZERO_EVENTS'])},'INELIGIBLE_INTERVAL'),
        ({'invalid_P_ids':[1]},'INTERVAL_NOT_QUALIFIED'),({'failure_P_ids':{'SINGULAR':[1]}},'INTERVAL_NOT_QUALIFIED'),
        ({'P_count':1998},'ESTIMATE_OR_P_DRIFT'),({'new_point':.7+2e-12},'ESTIMATE_OR_P_DRIFT'),
        ({'confirmation_key':'WRONG'},'QUALIFICATION_DRIFT'),({'patient_count':92},'INELIGIBLE_INTERVAL')]
    for delta,reason in changes:
        damaged=deepcopy(value);damaged['rows'][0].update(delta)
        with pytest.raises(ContractError,match=reason):e.validate_clinical(run,unit,n._sealed(damaged),gate)
    for field in ('clinical_rng_universe','formal_references'):
        damaged=deepcopy(value)
        if field=='clinical_rng_universe':damaged[field]=None
        else:damaged[field]=damaged[field][:-1]
        with pytest.raises(ContractError):e.validate_clinical(run,unit,n._sealed(damaged),gate)


def test_curve_metadata_change_requalifies_only_changed_bytes_without_recomputation(tmp_path,monkeypatch):
    import os,time
    from padml import curve_rmse as c,integrated as i,nested_loco as n
    from padml.bundle import canonical_json_bytes,sha256_bytes
    base=tmp_path.resolve();p=base/'input.json';p.write_bytes(b'immutable real input')
    s=p.stat();stamp=[s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns]
    value=n._sealed({'source_stamps':{'input.json':stamp},
        'sources':{'input.json':{'sha256':sha256_bytes(p.read_bytes()),'size_bytes':p.stat().st_size}}})
    target=base/'result.json';target.write_bytes(canonical_json_bytes(value))
    monkeypatch.setattr(c,'relative_result',lambda u:'result.json')
    monkeypatch.setattr(c,'validate_result',lambda run,u,v:v)
    assert c.read_result({'run_root':str(base)},{},observation=True)==value
    os.link(p,base/'isolated-input-link')
    assert c.read_result({'run_root':str(base)},{},observation=True) is None
    now=time.time_ns();monkeypatch.setattr(time,'time_ns',lambda:now+10_000_000_000)
    assert c.read_result({'run_root':str(base)},{})==value
    monkeypatch.setattr(i,'_file_pin',lambda *args:pytest.fail('stable qualification read input again'))
    assert c.read_result({'run_root':str(base)},{},observation=True)==value
    assert target.read_bytes()==canonical_json_bytes(value)


def test_research_gate_requires_complete_confirmation_coordinates():
    from padml import evaluation_extension as e,auc_research as a
    from padml.bundle import ContractError
    sources={u:'a'*64 for u in (*e.RESEARCH_UNITS,'FULL0-H12','FULL0-H24')}
    rows=[]
    for s in range(1,9):
        truth=a.scenario(s)['truth']
        for key in truth:
            for method in (('STUDENTIZED',) if s<=4 or key[0]=='MICRO' else
                    ('STUDENTIZED','HIERARCHICAL_0.5','HIERARCHICAL_0.25','HIERARCHICAL_1.0')):
                rows.append({'coordinate':['confirmation',s,method,*key],'status':'FAILED_REGISTERED_SCOPE'})
    run={'identity':'b'*64,'run_id':'UNFITTED','raw_input':{'sha256':'c'*64}};study={'dataset_count':16800,'coordinates':rows}
    gate=e.research_gate(run,study,sources)
    assert len(gate['scope_results'])==364 and e.validate_gate(run,gate)==gate
    assert e.research_gate({**run,'identity':'d'*64},study,sources)==gate
    study['coordinates'][-1]=study['coordinates'][0]
    with pytest.raises(ContractError,match='CONFIRMATION_COORDINATE_DUPLICATE'):e.research_gate(run,study,sources)


def test_weighted_auc_if_matches_independent_km_pair_sum_and_directional_derivative():
    import numpy as np
    from padml import f4
    from padml.auc_research import weighted_auc_if,covariance
    times=np.array([1,2,2,4,5,7,9,12,1,3,3,4,6,7,9,12.],float)
    events=np.array([1,1,0,0,1,0,1,0]*2)
    centers=['36']*8+['38']*8
    risk=np.array([.8,.7,.7,.3,.6,.5,.2,.1,.9,.6,.6,.2,.5,.4,.1,.1])
    mass=np.array([1.2,.8,1.4,.7,1.1,1.,.9,.9,.8,1.1,1.3,.7,.9,1.2,1.,1.])
    plan=f4._evaluation_perturbation_prepare_population([str(i) for i in range(16)],times,events,centers)
    def independent(a):
        km={}
        for c in set(centers):
            ix=np.array([v==c for v in centers]); g=1.; steps=[]
            for u in sorted(set(times[ix])):
                at=ix & ((times>u)|((times==u)&(events==0)))
                d=a[ix&(times==u)&(events==0)].sum()
                if d:g*=1-d/a[at].sum()
                steps.append((u,g))
            km[c]=steps
        def g(i,t,left):
            value=1.
            for u,gi in km[centers[i]]:
                if u<t or (not left and u==t):value=gi
            return value
        cases=[i for i in range(16) if events[i] and times[i]<=6]
        controls=[i for i in range(16) if times[i]>6]
        numerator=denominator=0.
        for i in cases:
            for j in controls:
                w=a[i]/g(i,times[i],True)*a[j]/g(j,6,False)
                numerator+=w*(float(risk[i]>risk[j])+.5*float(risk[i]==risk[j]));denominator+=w
        return numerator/denominator
    value,gradient,_=weighted_auc_if(plan,risk,6,mass[None,:])
    assert value[0] == pytest.approx(independent(mass),abs=2e-15)
    for i in range(16):
        delta=np.zeros(16);delta[i]=1e-5
        def normalized(a):
            return np.concatenate([a[:8]*8/a[:8].sum(),a[8:]*8/a[8:].sum()])
        numerical=(independent(normalized(mass+delta))-independent(normalized(mass-delta)))/2e-5
        assert gradient[0,i] == pytest.approx(numerical,abs=5e-10)
    centered=np.concatenate([gradient[0,:8],gradient[0,8:]])
    expected=8/7*sum(mass*centered**2)
    assert covariance(plan,mass[None,:],gradient)[0] == pytest.approx(expected,abs=1e-16)
    assert abs(expected-8/7*sum(mass**2*centered**2))>1e-6


def test_hierarchical_conditioning_matches_full_gaussian_without_ridge():
    import numpy as np
    from padml.auc_research import _conditional_posterior
    a=np.array([[.2,.1],[.1,.3]])
    b=np.array([[.1,.1],[.1,.1]])  # Legitimate singular measurement covariance.
    data={'coordinates':[(6,'A'),(12,'A')],'groups':[
        {'index':np.arange(2),'z':np.array([.5,1.]),'covariance':a},
        {'index':np.arange(2),'z':np.array([.8,1.2]),'covariance':b}]}
    tb,te=.3,.4
    logev,mu,root,groups=_conditional_posterior(data,tb,te,moments=True)
    h=np.tile(np.eye(2),(2,1));t=np.eye(2)*te**2+tb**2
    prior=h@(np.eye(2)*6.25)@h.T+np.kron(np.eye(2),t)
    v=np.zeros((4,4));v[:2,:2]=a;v[2:,2:]=b
    z=np.concatenate([g['z'] for g in data['groups']]); w=prior+v
    mean=prior@np.linalg.solve(w,z);cov=prior-prior@np.linalg.solve(w,prior)
    actual=np.concatenate([intercept+aa@mu[g['index']] for g,aa,intercept,_ in groups])
    aa=np.vstack([m[1] for m in groups]);actual_cov=aa@(root@root.T)@aa.T
    for i,(_,_,_,r) in enumerate(groups):actual_cov[2*i:2*i+2,2*i:2*i+2]+=r@r.T
    assert np.allclose(actual,mean,atol=3e-14,rtol=0)
    assert np.allclose(actual_cov,cov,atol=3e-14,rtol=0)
    expected=-.5*(4*np.log(2*np.pi)+np.linalg.slogdet(w)[1]+z@np.linalg.solve(w,z))
    assert logev == pytest.approx(expected,abs=3e-14)


@pytest.mark.parametrize('corner',[False,True])
def test_hierarchical_rejects_nonintegrable_singular_boundary_before_quadrature(corner):
    import numpy as np
    from padml.auc_research import _improper_zero_scale
    matrix=np.array([[1.,-1.],[-1.,1.]]) if corner else np.ones((2,2))
    data={'coordinates':[(6,'A'),(12,'A')],'groups':[
        {'index':np.arange(2),'z':np.array([.4,-.4] if corner else [.4,.4]),'covariance':.2*matrix}
        for _ in range(3 if corner else 2)]}
    result=_improper_zero_scale(data)
    assert result['status']=='SINGULAR_LIKELIHOOD_UNRESOLVED'
    assert result['boundary']==('TWO_SCALE_CORNER' if corner else 'TAU_E_BOUNDARY')
    for g in data['groups']:g['covariance']+=np.eye(2)*.01
    assert _improper_zero_scale(data) is None


def test_nearly_singular_but_positive_covariance_is_not_an_improper_posterior():
    import numpy as np
    from padml.auc_research import _improper_zero_scale
    matrix=.2*np.ones((2,2))+1e-14*np.eye(2)
    data={'coordinates':[(6,'A'),(12,'A')],'groups':[
        {'index':np.arange(2),'z':np.array([.4,.4]),'covariance':matrix} for _ in range(2)]}
    assert _improper_zero_scale(data) is None


def test_research_partition_budget_and_streams_do_not_duplicate_coordinates():
    from padml.auc_research import tasks,_generator
    from padml.evaluation_extension import RESEARCH_UNITS
    import numpy as np
    all_tasks=[t for uid in RESEARCH_UNITS for t in tasks(uid)]
    coords={(t['phase'],t['scenario'],t['replication']) for t in all_tasks}
    assert len(coords)==len(all_tasks)==16800
    assert 1999*len(all_tasks)==33583200
    assert 3*sum(t['scenario']>4 for t in all_tasks)==25200
    for phase,count in [('pilot',100),('confirmation',2000)]:
        for scenario in range(1,9):
            assert {r for p,s,r in coords if p==phase and s==scenario}==set(range(1,count+1))
    assert not np.array_equal(_generator(2026100901,1,1,0).random(10),_generator(2026100901,1,1,2).random(10))


def test_research_real_dataset_publication_and_cold_resume_zero_new_calls(tmp_path,monkeypatch):
    from padml import auc_research as a
    from padml.bundle import strict_json_bytes
    from padml.carriers import open_carrier
    root=tmp_path.resolve();(root/'datasets').mkdir()
    task=next(t for t in a.tasks('FULL0-H06') if t['scenario']==1 and t['phase']=='pilot')
    provenance={'producer':{'run_identity':'a'*64,'source_identity':'b'*64},'generations':{'a'*64:'b'*64}}
    first=a._research_job(task,root=root,provenance=provenance)
    with open_carrier(root/'datasets'/a.task_name(task)) as z:record=strict_json_bytes(z.read('result.json'))
    assert record['P_count']==1999 and record['new_prediction_model_fits']==0
    summary=a.reduce_records([record]);assert all(r['datasets']==1 for r in summary)
    monkeypatch.setattr(a,'dataset',lambda *a,**kw:pytest.fail('cold resume regenerated data'))
    monkeypatch.setattr(a,'studentized',lambda *a,**kw:pytest.fail('cold resume repeated perturbations'))
    assert a._research_job(task,root=root,provenance=provenance)==first
    partial=root/'partial'/a.task_name(task).removesuffix('.zip');(partial/'P').mkdir(parents=True)
    (partial/'P'/'.P0001.zip.tmp-123-0123456789abcdef').write_bytes(b'power-loss-incomplete-bytes')
    (partial/'.STUDENTIZED.json.pending-abcdefgh').write_bytes(b'power-loss-partial-json')
    assert a._research_job(task,root=root,provenance=provenance)==first
    assert not partial.exists()
    external=root/'protected';external.mkdir();(external/'STUDENTIZED.json').write_bytes(b'protected')
    partial.symlink_to(external,target_is_directory=True)
    with pytest.raises(ContractError,match='PARTIAL_PATH_INVALID'):a._research_job(task,root=root,provenance=provenance)
    assert (external/'STUDENTIZED.json').read_bytes()==b'protected'
    with pytest.raises(ContractError,match='DUPLICATE_OR_INVALID'):a.reduce_records([record,record])


def test_research_p_block_recovery_resumes_exact_rng_without_repeating_completed_draws(tmp_path,monkeypatch):
    import numpy as np
    from padml import auc_research as a, f4
    task=next(t for t in a.tasks('FULL0-H06') if t['scenario']==1 and t['phase']=='pilot')
    prepared=a.dataset(task,a.scenario(1));binding={'task':task}
    def generator():return a._generator(task['seed'],1,task['replication'],2)
    original=f4.write_deterministic_zip;writes=[]
    def interrupted(path,members,**kw):
        writes.append(path.name)
        if path.name=='P0065.zip':raise OSError('power loss before third block publication')
        return original(path,members,**kw)
    monkeypatch.setattr(f4,'write_deterministic_zip',interrupted)
    with pytest.raises(OSError,match='power loss'):
        a.studentized(prepared,generator(),progress=tmp_path/'P',binding=binding)
    assert {p.name for p in (tmp_path/'P').iterdir()}=={'P0001.zip','P0033.zip'}
    monkeypatch.setattr(f4,'write_deterministic_zip',original)
    class CounterGenerator:
        def __init__(self):self.raw=generator();self.draws=0
        @property
        def bit_generator(self):return self.raw.bit_generator
        def exponential(self,size):self.draws+=size[0];return self.raw.exponential(size=size)
    resumed_rng=CounterGenerator()
    resumed=a.studentized(prepared,resumed_rng,progress=tmp_path/'P',binding=binding)
    clean_rng=generator();clean=a.studentized(prepared,clean_rng)
    assert resumed==clean and resumed_rng.draws==1999-64
    assert resumed_rng.bit_generator.state==clean_rng.bit_generator.state


def test_curve_km_ties_and_unsupported_tail_are_not_zero_filled():
    from padml.curve_rmse import outcome_km
    result = outcome_km([1.,1.,2.],[1,0,0])
    first = result['monthly'][1]
    assert first['at_risk'] == 3 and first['survival'] == pytest.approx(2/3)
    assert first['lower'] == pytest.approx(.0540734267865166)
    assert first['upper'] == pytest.approx(.9452063872720471)
    assert result['monthly'][3]['survival'] is None
    assert not result['monthly'][3]['supported']
    extinct = outcome_km([1.,2.],[1,1])
    assert extinct['monthly'][36]['supported'] and extinct['monthly'][36]['survival'] == 0
    assert extinct['monthly'][36]['lower'] is None and extinct['monthly'][36]['upper'] is None
    no_events = outcome_km([1.,40.],[0,0])
    assert no_events['zero_event_warning'] and no_events['monthly'][36]['survival'] == 1


def test_curve_monthly_rmse_excludes_zero_and_preserves_population():
    from padml.curve_rmse import summarize,CENTERS
    ids = [f'fixture-{i}' for i in range(6)]
    matrix = [[1.]+[.9]*36 for _ in ids]
    result = summarize(ids,CENTERS,[40.]*6,[0]*6,matrix,6)
    assert result['rmse']['target']['value'] == pytest.approx(.1)
    assert result['rmse']['common36']['percentage_points'] == pytest.approx(10)
    assert result['monthly'][0]['predicted_survival'] == 1
    assert result['monthly'][6]['predicted_risk'] == pytest.approx(.1)
    tail = summarize(ids,CENTERS,[12.]*6,[0]*6,matrix,6)
    assert tail['rmse']['target']['status'] == 'ESTIMABLE'
    assert tail['rmse']['common36']['value'] is None
    with pytest.raises(ContractError,match='POPULATION_DRIFT'):
        summarize(ids,CENTERS[:-1]+['55'],[40.]*6,[0]*6,matrix,6)


def test_curve_admission_precedes_input_and_complete_hit_skips_pool(tmp_path,monkeypatch):
    from padml import curve_rmse as c,runtime
    unit={'unit_id':'FULL0-H06','kind':'FULL0','horizon':6}
    root=tmp_path/'units'/unit['unit_id'];root.mkdir(parents=True)
    run={'run_root':str(tmp_path.resolve()),'curve_rmse':c.decision(),'resource_policy':{
        'configured_worker_ceiling':runtime.CPU_MINUS_8,'memory_bytes_per_worker':1024**3,
        'scratch_bytes_per_worker':1024,'memory_reserve_bytes':0,'scratch_reserve_bytes':0,
        'transfer_archive_worker_ceiling':3}}
    calls=[];real=runtime.admit_stage
    def admit(*a,**kw):
        result=real(*a,**kw,_observation={'effective_cpus':32,'available_memory_bytes':60*1024**3,
            'scratch_available_bytes':100*1024**3,'scratch_root':str(tmp_path)})
        assert result['limits']['cpu_c_minus_8']==24
        assert result['admitted_worker_ceiling']==1
        calls.append('admitted');return result
    def ordered(job,tasks,**kw):
        assert calls==['admitted'] and tasks==[unit] and kw['selected_slots']==1
        assert job.func is c._compute
        raise RuntimeError('ADMITTED_NO_PREDICTION_READ')
    monkeypatch.setattr(c,'read_result',lambda *a,**kw:None)
    monkeypatch.setattr(runtime,'admit_stage',admit)
    monkeypatch.setattr(runtime,'run_ready_families',lambda tasks,**kw:[fn() for fn in tasks])
    monkeypatch.setattr(runtime,'_bounded_ordered_spawn',ordered)
    with pytest.raises(RuntimeError,match='ADMITTED_NO_PREDICTION_READ'):
        c.run_curve(run,unit)
    monkeypatch.setattr(c,'read_result',lambda *a,**kw:{'identity_sha256':'a'*64})
    assert c.run_curve(run,unit)['reused'] is True
    assert calls==['admitted']


def test_curve_report_is_numerical_only_and_cold_hit_needs_no_rpc(tmp_path,monkeypatch):
    """Publication fixture only; source qualification is tested independently."""
    import builtins
    from padml import curve_rmse as c,reports,nested_loco as n
    real_import=builtins.__import__
    def numerical_import(name,*args,**kwargs):
        assert not name.startswith('matplotlib'), 'calculation must not load plotting'
        return real_import(name,*args,**kwargs)
    monkeypatch.setattr(builtins,'__import__',numerical_import)
    units=[{'unit_id':f'{kind}-H{h:02d}','kind':kind,'horizon':h}
        for kind in ('FULL0','EVALUATION') for h in c.HORIZONS]
    run={'curve_rmse':c.decision(),'units':units}
    numbers=c.summarize(list('abcdef'),c.CENTERS,[40.]*6,[0]*6,[[1.]+[.9]*36 for _ in range(6)],6)
    records={u['unit_id']:n._sealed({'target_unit':u['unit_id'],'development_month':u['horizon'],
        'role':'LOCO' if u['kind']=='EVALUATION' else 'FULL0_APPARENT','numbers':numbers}) for u in units}
    monkeypatch.setattr(c,'validate_result',lambda run,unit,value:value)
    assert c.write_report(run,records,tmp_path)['coordinates']==8
    files={p.name:p.read_bytes() for p in tmp_path.iterdir()}
    assert set(files)=={'curve-rmse-results.json','curve-rmse-monthly.csv','curve-rmse-summary.csv'}
    summary=strict_json_bytes(files['curve-rmse-results.json'])
    assert summary['kind']=='PADML_CURVE_RMSE_NUMERICAL_REPORT_V1' and 'figures' not in summary
    observations={'H0':{'evaluation_amendment_units':list(records),
        'curve_result_identities':{k:v['identity_sha256'] for k,v in records.items()}}}
    def forbidden(*args,**kwargs):raise AssertionError('stable numerical hit must not transfer')
    assert reports.collect_curves(run,observations,report_root=tmp_path,
        call=forbidden,command=forbidden,pool=None)['coordinates']==8
    assert {p.name:p.read_bytes() for p in tmp_path.iterdir()}==files
    observations['H0']['curve_result_identities'][units[0]['unit_id']]='f'*64
    with pytest.raises(ContractError,match='REPORT_SOURCE_DRIFT'):
        reports.collect_curves(run,observations,report_root=tmp_path,call=forbidden,command=forbidden,pool=None)

from padml import f4, f5
from padml.bundle import ContractError, canonical_json_bytes, read_safe_zip, strict_json_bytes


def test_closure_csv_cold_json_order_and_missing_csv_resume(tmp_path):
    from padml import reports,nested_loco as n
    metric={'status':'ESTIMABLE','value':.5,'reasons':[]}
    months={str(h):{'auc':metric,'calibration':{'citl':metric,'ici':metric},
        **({'uno':metric} if h==24 else {})} for h in (6,12,24,36)}
    report=n._sealed({'cross_time':{'sources':{'one':'small'}},'a04':{str(h):{'a04':{
        'cases':{'VARIANTS':{'MICRO':{'rows':{'one':months}}}},'fixed_center_macros':{}}}
        for h in (6,12,24,36)}})
    reports.write_effective_report(tmp_path,report)
    before={p.name:p.read_bytes() for p in tmp_path.iterdir()}
    cold=strict_json_bytes((tmp_path/'current-evaluation.json').read_bytes())
    reports.write_effective_report(tmp_path,cold)
    (tmp_path/'a04-current-metrics.csv').unlink()
    reports.write_effective_report(tmp_path,cold)
    assert {p.name:p.read_bytes() for p in tmp_path.iterdir()}==before


@pytest.mark.parametrize('events', [0, 1, 6, 19])
def test_a04_closure_metric_specific_support_and_retained_only_resume(tmp_path,monkeypatch,events):
    from padml import result_closure as c
    ids=[f'P{i}' for i in range(80)]
    response=('Patient_ID,All_Cause_Death,Death_Followup_months\n'+''.join(
        f'{p},{int(i<events)},{2+i%4 if i<events else 40}\n' for i,p in enumerate(ids))).encode()
    matrix=[[1.]+[1-(.02+.7*((i*17)%79)/79)*t/36 for t in range(1,37)] for i in range(80)]
    view={'patient_ids':ids,'centers':['36']*80,'response_csv':response,'matrices':{'TEST':matrix}}
    provenance={'producer':{'run_identity':'a'*64,'source_identity':'b'*64},'generations':{'a'*64:'b'*64}}
    task=({'decision':c.decision()['identity_sha256'],'case':'TEST','development_month':24},view,'36',tmp_path/'leaf.json',provenance)
    result=c._metrics_job(task)
    for h in ('6','12','24','36'):
        row=result['rows']['TEST'][h]
        assert row['auc']['status']==('ESTIMABLE' if events else 'NOT_ESTIMABLE')
        assert all('BELOW_20' not in r for r in row['auc']['reasons'])
        if not events:
            assert 'ZERO_EVENTS' in row['auc']['reasons']
            assert row['calibration']['oe']['value']==0
        assert ('uno' in row)==(h=='24')
    def forbidden(*a,**kw):raise AssertionError('qualified metrics must not be recomputed')
    monkeypatch.setattr(f4,'censoring_context',forbidden)
    assert c._metrics_job(task)==result
    with pytest.raises(ContractError,match='PARTIAL_METRIC_DRIFT'):
        c._metrics_job(({**task[0],'case':'OTHER'},*task[1:]))


@pytest.mark.parametrize('development',[6,12,24,36])
def test_a04_closure_uno_uses_matched_window_and_keeps_24_reference(tmp_path,monkeypatch,development):
    from padml import result_closure as c
    seen=[];actual=f4._evaluation_discrimination
    def traced(matrix,context,report_month,risk_month,**kw):
        seen.append((report_month,risk_month,kw['include_uno']))
        return actual(matrix,context,report_month,risk_month,**kw)
    monkeypatch.setattr(f4,'_evaluation_discrimination',traced)
    ids=[f'P{i}' for i in range(50)]
    raw=('Patient_ID,All_Cause_Death,Death_Followup_months\n'+''.join(f'{p},0,40\n' for p in ids)).encode()
    view={'patient_ids':ids,'centers':['36']*50,'response_csv':raw,
        'matrices':{'TEST':[[1.]+[.8]*36 for _ in ids]}}
    c._metrics_job(({'development_month':development},view,'MICRO',tmp_path/'job.json',
        {'producer':{'run_identity':'a'*64,'source_identity':'b'*64},'generations':{'a'*64:'b'*64}}))
    assert seen==[(h,h,h in {24,development}) for h in (6,12,24,36)]


def test_closure_crossing_common_ids_center_drift_and_no_projection(monkeypatch):
    from padml import result_closure as c,nested_loco as n
    monkeypatch.setattr(c,'validate_result',lambda run,unit,v:v)
    units=[{'unit_id':f'{kind}-H{h:02d}','horizon':h,'kind':kind}
        for kind in ('FULL0','EVALUATION') for h in c.HORIZONS]
    run={'units':units,'result_closure':c.decision()};records={}
    for u in units:
        branches=['FULL0'] if u['kind']=='FULL0' else ['PRIMARY',*n.AAR_ESTIMANDS]
        p={6:.08,12:.20,24:.18,36:.30}[u['horizon']]
        records[u['unit_id']]={'identity_sha256':u['unit_id'],'cross_time':{
            'patient_ids':list('abcdef'),'centers':c.CENTERS,
            'risks':{b:[p]*6 for b in branches},'within_model':{b:{'patient_count':6} for b in branches}}}
    result=c.cross_report(run,records)
    row=result['results']['LOCO']['branches']['PRIMARY']
    assert row['crossing_patients']==row['crossing_adjacent_pairs']==6
    assert row['maximum_risk_drop']==pytest.approx(.02)
    assert result['risk_projection']=='NONE'
    records['FULL0-H24']['cross_time']['centers']=['38','36',*c.CENTERS[2:]]
    with pytest.raises(ContractError,match='CENTER_DRIFT'):c.cross_report(run,records)


def test_closure_complete_hit_never_reenters_input_pool_or_training(monkeypatch,tmp_path):
    from padml import result_closure as c
    monkeypatch.setattr(c,'read_result',lambda *a,**kw:{'identity_sha256':'a'*64})
    monkeypatch.setattr(c,'_a04',lambda *a:pytest.fail('must not prepare input'))
    monkeypatch.setattr(c,'_cross_component',lambda *a:pytest.fail('must not reread predictions'))
    assert c.run_closure({'run_root':str(tmp_path)}, {'unit_id':'EVALUATION-H06'})['reused']


def test_original_native_metric_transport_retains_success_before_cleanup(tmp_path, monkeypatch):
    jobs = [{"label": "MICRO/UNFITTED", "fixture": "NO_SCIENTIFIC_EVALUATION"}]
    value = {"label": jobs[0]["label"], "unfitted_value": 0.125}
    calls = []

    def transport(command, **options):
        calls.append(command)
        assert options["input"] == canonical_json_bytes({"jobs": jobs})
        assert Path(command[-1]).read_bytes() == (Path(f4.__file__).parent / "kernels/f4_metrics.R").read_bytes()
        options["stdout"].write(canonical_json_bytes({"results": [value]}))
        options["stderr"].write(b"UNFITTED transport; no R process\n")
        return SimpleNamespace(returncode=0)

    monkeypatch.setattr(f4.subprocess, "run", transport)
    archive = tmp_path / "metrics.zip"
    assert f4.native_metrics(jobs, evidence_root=tmp_path / "retained", retained_archive=archive) == [value]
    entries = read_safe_zip(archive, expected_members={"input.json", "stdout.txt", "stderr.txt", "f4_metrics.R", "execution.json"})
    assert entries["input.json"] == canonical_json_bytes({"jobs": jobs})
    assert strict_json_bytes(entries["stdout.txt"])["results"] == [value]
    assert strict_json_bytes(entries["execution.json"])["exit_code"] == 0
    assert list((tmp_path / "retained").iterdir()) == []
    # Existing callers that do not request a retained archive keep the same result.
    assert f4.native_metrics(jobs, evidence_root=tmp_path / "default") == [value]
    assert list((tmp_path / "default").iterdir()) == []
    assert len(calls) == 2
    assert read_safe_zip(archive) == entries


def test_native_schema_failure_keeps_first_files_and_a12_only_final_source_is_forwarded(tmp_path, monkeypatch):
    def transport(command, **options):
        options["stdout"].write(canonical_json_bytes({"results": [{"label": "WRONG"}]}))
        options["stderr"].write(b"UNFITTED original stderr")
        return SimpleNamespace(returncode=0)

    monkeypatch.setattr(f4.subprocess, "run", transport)
    with pytest.raises(ContractError, match="F4_NATIVE_METRICS_OUTPUT_ALIGNMENT_INVALID"):
        f4.native_metrics([{"label": "MICRO/UNFITTED"}], evidence_root=tmp_path / "failed",
                          retained_archive=tmp_path / "absent.zip")
    assert not (tmp_path / "absent.zip").exists()
    root, = (tmp_path / "failed").iterdir()
    assert (root / "input.json").is_file() and (root / "f4_metrics.R").is_file()
    assert (root / "stderr.txt").read_bytes() == b"UNFITTED original stderr"
    assert strict_json_bytes((root / "failure.json").read_bytes())["exit_code"] == 0
    # Evaluate the actual highest caller expression without invoking fitting or aggregation.
    tree = ast.parse(Path(f5.__file__).read_text())
    function, = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == "execute_final_aggregate"]
    call, = [node for node in ast.walk(function) if isinstance(node, ast.Call) and
             isinstance(node.func, ast.Name) and node.func.id == "_load_final_sensitivity_actions"]
    calls = []
    index, supplied = {"fixture": "UNFITTED"}, {"A12": tmp_path / "a12.zip"}
    expression = compile(ast.Expression(call), "<actual final aggregate expression>", "eval")
    observed = eval(expression, {"_load_final_sensitivity_actions": lambda *args, **kwargs: calls.append((args, kwargs)),
                                "index": index, "sensitivity_results": supplied, "f2_run_root": tmp_path,
                                "replay_root": tmp_path, "f1_runtime_root": None})
    assert observed is None and calls == [((index, supplied), {"f2_run_root": tmp_path,
        "f1_runtime_root": None, "replay_evidence": tmp_path / "actions"})]


# Unfitted frequency-amendment boundaries; no native fit, metric, or RNG execution.
import copy
import math
from padml import f5_sensitivity as _freq_a, nested_loco as _freq_n
from padml.bundle import sha256_bytes


def test_evaluation_outcome_km_uses_deaths_before_censor_risk_removal():
    raw = b'Patient_ID,All_Cause_Death,Death_Followup_months\nA,1,1\nB,0,1\nC,1,3\nD,0,5\n'
    curve = f4._evaluation_event_km(raw,['A','B','C','D'])
    assert curve[:4] == [1.,.75,.75,.375]
    assert curve[4:] == [.375]*33
    # Altering a row outside the fit population cannot change its prediction.
    assert f4._evaluation_event_km(raw,['C','D'])[:4] == [1.,1.,1.,.5]


def test_evaluation_bootstrap_retains_zero_event_and_original_fixed_knots(monkeypatch):
    context,risks,raw = _evaluation_if_fixture(False,False)
    view = {'patient_ids':context['patient_ids'],'centers':context['centers'],'response_csv':raw,
        'matrices':{'APPARENT':[[1.]+[1-(.1+.4*p)]*36 for p in risks]}}
    point = f4._evaluation_point_tables(view,12,include_centers=False)
    controls = [i for i,t in enumerate(context['times']) if t > 36]
    draw = (controls*60)[:60]
    original = f4._evaluation_calibration
    observed = []
    def checked(*args,**kwargs):
        observed.append(tuple(kwargs['knots']))
        return original(*args,**kwargs)
    monkeypatch.setattr(f4,'_evaluation_calibration',checked)
    values = f4._evaluation_bootstrap_tables(view,point,draw,label='FIXED-ORIGINAL-DRAW')
    assert observed and set(observed) <= {tuple(v['APPARENT']) for v in point['fixed_calibration_knots'].values()}
    for models in values.values():
        assert models['APPARENT']['auc']['value'] is None
        assert 'ZERO_EVENTS' in models['APPARENT']['auc']['reasons']
        assert models['APPARENT']['oe']['value'] == 0
        assert models['APPARENT']['brier']['value'] is not None


def test_evaluation_replicate_restore_is_read_only_and_draw_bound(tmp_path, monkeypatch):
    from padml import nested_loco as n
    from padml.bundle import write_deterministic_zip
    folder = tmp_path/'replicates'; folder.mkdir()
    binding = {'decision_sha256':f4.evaluation_decision()['identity_sha256'],'source_identity':'a'*64}
    draw = [2,2,0]
    provenance = {'producer':{'run_identity':'b'*64,'source_identity':'c'*64},'generations':{'b'*64:'c'*64}}
    value = n._sealed({'kind':'PADML_EVALUATION_REPLICATE_V2','replicate':1,**binding,
        'draw_sha256':n._sha(draw),'tables':{},'status':'COMPLETED','producer':provenance['producer']})
    path = folder/'B0001.zip'
    write_deterministic_zip(path,{'values.json':canonical_json_bytes(value)})
    before = path.read_bytes(),path.stat().st_ino
    monkeypatch.setattr(f4,'_evaluation_bootstrap_tables',lambda *a,**k: pytest.fail('completed coordinate recomputed'))
    result = f4._evaluation_replicate_job(1,view={},point={},draws=[draw],root=tmp_path,binding=binding,provenance=provenance)
    assert result['replicate']==1 and before==(path.read_bytes(),path.stat().st_ino)
    with pytest.raises(ContractError,match='EVALUATION_REPLICATE_DRIFT'):
        f4._evaluation_replicate_job(1,view={},point={},draws=[[2,0,0]],root=tmp_path,binding=binding,provenance=provenance)


def _evaluation_context(times, events, centers=None):
    ids = [f'P{i:04d}' for i in range(len(times))]
    raw = ('Patient_ID,All_Cause_Death,Death_Followup_months\n' + ''.join(
        f'{p},{e},{t}\n' for p,e,t in zip(ids,events,times))).encode()
    fields, rows = f4._response_rows(raw)
    return f4.censoring_context(ids, centers or ['36']*len(ids),
        f4._write_response_subset(fields,rows,ids,None))


def test_evaluation_amendment_metric_specific_zero_and_small_event_support():
    import numpy as np
    times, events = [6.]*19+[40.]*61, [1]*19+[0]*61
    ctx = _evaluation_context(times, events)
    matrix = [[1.] + [1-float(v)]*36 for v in np.linspace(.1,.7,80)]
    result = f4._evaluation_discrimination(matrix,ctx,12,12)
    assert result['auc']['status'] == 'ESTIMABLE'
    assert 'CASES_BELOW_20' not in result['auc']['reasons']
    zero = _evaluation_context([40.]*80,[0]*80)
    result = f4._evaluation_discrimination(matrix,zero,12,12)
    assert result['auc']['reasons'] == result['uno_c']['reasons'] == ['ZERO_EVENTS']
    assert f4.prediction_error(zero['patient_ids'],matrix,zero)['ibs_0_to']['12'] is not None
    calibration = f4._evaluation_calibration([.2]*80,zero['rows'][12])
    assert calibration['oe']['value'] == 0
    assert calibration['citl']['reasons'] == ['POSITIVE_WEIGHT_SINGLE_OUTCOME']
    all_events = _evaluation_context([i/2+.1 for i in range(40)],[1]*40)
    result = f4._evaluation_discrimination(matrix[:40],all_events,24,24)
    assert result['auc']['reasons'] == ['ZERO_TERMINAL_CONTROLS']
    assert result['uno_c']['status'] == 'ESTIMABLE'


def test_evaluation_constant_risk_and_spline_failure_are_metric_local():
    ctx = _evaluation_context([6.]*40+[40.]*40,[1]*40+[0]*40)
    result = f4._evaluation_calibration([.5]*80,ctx['rows'][12])
    assert result['citl']['value'] == pytest.approx(0,abs=1e-9)
    assert result['oe']['value'] == 1
    assert result['calibration_slope']['reasons'] == ['POSITIVE_WEIGHT_DESIGN_RANK_DEFICIENT']
    assert result['ici']['reasons'] == ['COINCIDENT_FIXED_KNOTS']
    separated = f4._evaluation_calibration([.8]*40+[.2]*40,ctx['rows'][12])
    assert separated['calibration_slope']['reasons'] == ['COMPLETE_OR_QUASI_SEPARATION']
    assert separated['citl']['value'] is not None and separated['oe']['value'] is not None
    with pytest.raises(ContractError,match='RISK_INVALID'):
        f4._evaluation_calibration([float('nan')]*80,ctx['rows'][12])


def test_evaluation_natural_spline_matches_native_ns_and_all_patient_ici():
    import json, shutil, subprocess
    import numpy as np
    if not shutil.which('Rscript'): pytest.skip('native R unavailable')
    risk = np.linspace(.02,.65,120)
    times = [5. if i % 5 in (0,1) else 8. if i % 5 == 2 else 40. for i in range(120)]
    events = [int(i%5 in (0,1)) for i in range(120)]
    ctx = _evaluation_context(times,events)
    support = ctx['rows'][12]
    q = f4._evaluation_calibration_knots(risk)
    result = f4._evaluation_calibration(risk,support,knots=q)
    payload = {'p':risk.tolist(),'w':support['weights'],'y':[1-v for v in support['truth']], 'q':q}
    script = '''suppressPackageStartupMessages(library(jsonlite));d<-fromJSON(file("stdin"));
x<-qlogis(pmin(pmax(d$p,1e-6),1-1e-6));b<-splines::ns(x,knots=d$q[2],Boundary.knots=d$q[c(1,3)]);
z<-suppressWarnings(glm(d$y~b,family=binomial(),weights=d$w,control=glm.control(epsilon=1e-12,maxit=150)));
cat(toJSON(as.numeric(predict(z,type="response")),digits=NA))'''
    native = subprocess.run(['Rscript','-e',script],input=json.dumps(payload),text=True,capture_output=True,check=True)
    fitted = np.asarray(json.loads(native.stdout))
    assert np.allclose(result['curve']['calibrated_risk'],fitted,rtol=0,atol=3e-7)
    error = np.abs(fitted-risk)
    assert result['ici']['value'] == pytest.approx(error.mean(),abs=3e-7)
    assert result['e50']['value'] == pytest.approx(np.quantile(error,.5),abs=3e-7)
    assert sum(w==0 for w in support['weights']) == 24


def test_evaluation_report36_projection_is_intersection_and_keeps_original_draw():
    centers = ['36','38','39','48','52','55']
    assert f4._evaluation_population_indices(centers,12,'PRIMARY') == list(range(6))
    for role in ['PRIMARY','SIX_CENTER_SENSITIVITY']:
        assert f4._evaluation_population_indices(centers,36,role) == list(range(5))

_FREQUENCY_BRANCH = _freq_n.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT

from test_a12_outer_native import _frequency_negative, _frequency_prepared

def _frequency_positive_fixture():
    from test_nested_aar_aggregate import _unfitted_six_aar
    context, outers = _unfitted_six_aar()
    science = next((d for d in (_freq_n.science_decision_template(24), _freq_n._base_science_decision_template(24)) if d['identity_sha256'] == context['primary']['science_decision_sha256']))
    context['science_decision'] = science
    for row in outers:
        src = row['source']
        src['outer_fold'] = row['outer_fold']
        src['identity_sha256'] = 'a' * 64
        src['primary_source']['science_decision'] = science
        src['primary_source']['primary_development_lock'].update(selection_horizon_months=24, science_decision_binding={'science_decision_sha256': science['identity_sha256']})
    return (context, outers)

@pytest.mark.parametrize('missing', [[], [3], [1, 3, 6]])
def test_frequency_six_fold_handoff_no_population_subset(missing):
    context, outers = _frequency_positive_fixture()
    for outer in missing:
        row = outers[outer - 1]
        proof = _frequency_negative(row['source'])
        row['estimability'] = {_FREQUENCY_BRANCH: proof}
        row['members'].update({'development/selector/' + name: pin for name, pin in proof['selector_members'].items()})
        del row['predictions']['survival'][_FREQUENCY_BRANCH]
        for imp in range(1, 21):
            del row['native_members'][f'fits/O{outer}_{_FREQUENCY_BRANCH}_M{imp:02d}.zip']
    handoff = _freq_a._a12_handoff_from_outers(context, outers)
    opened = _freq_a._validate_a12_handoff(handoff)
    assert opened['patient_ids'] == context['primary']['patient_ids']
    assert set(opened['survival']) == {'PRIMARY', *(_freq_n.AAR_ESTIMANDS[:2] if missing else _freq_n.AAR_ESTIMANDS)}
    if missing:
        assert [r['outer_fold'] for r in opened['estimability'][_FREQUENCY_BRANCH]['unavailable_outers']] == missing
        bad = copy.deepcopy(handoff)
        del bad['estimability']
        with pytest.raises(ContractError):
            _freq_a._validate_a12_handoff(bad)
    else:
        assert 'estimability' not in opened

@pytest.mark.parametrize('missing', [False, True])
def test_frequency_partial_summary_budget_keeps_b1000_and_real_model_counts(missing):
    context = {'primary': {'kind': 'PADML_NESTED_LOCO_SELECTED_POLICY_OOC_V1', 'identity_sha256': 'b' * 64}, 'family_by_outer': {str(i): 'COX_PH' for i in range(1, 7)}, 'science_decision': _freq_n.science_decision_template(24), 'source': {}}
    records = []
    for i in range(1, 7):
        count = 40 if missing and i == 3 else 60
        records.append({'outer_fold': i, 'identity_sha256': str(i) * 64, 'execution_ledger': {'mice_chains': 1220, 'elastic_path_executions': 320, 'glmnet_pilot_and_path_calls': 640, 'candidate_prediction_fits': 0, 'stop_fits': 0, 'inner_scoring_fits': 0, 'post_lock_fits': count, 'total_model_fits': count}})
    if missing:
        records[2]['estimability'] = _frequency_prepared()['estimability']
    numeric = {'family_by_outer': context['family_by_outer'], 'science_decision_sha256': context['science_decision']['identity_sha256'], 'primary_ooc_sha256': 'b' * 64, 'bootstrap': {'replicate_count': 1000, 'paired_row_count': (2 if missing else 3) * 8, 'metrics': {'macro': ['UNFITTED_METRIC'], 'scope': ['UNFITTED_METRIC']}}}
    if missing:
        numeric['estimability'] = {_FREQUENCY_BRANCH: {'status': 'NOT_ESTIMABLE', 'reason_code': 'FREQUENCY_LADDER_EXHAUSTED', 'unavailable_outers': [{'outer_fold': 3, 'native_outer_identity_sha256': '3' * 64, 'selector': _frequency_prepared()['estimability'][_FREQUENCY_BRANCH]}]}}
    out = _freq_a._a12_native_summary(context, numeric, records)
    assert out['post_lock_model_fit_execution_count'] == (340 if missing else 360)
    assert out['bootstrap_evaluation_execution_count'] == 1000 and out['evaluation_new_model_fit_count'] == 0
    assert out['new_aar_point_metric_job_count'] == (14 if missing else 21)
    assert out['metric_scope_branch_job_count'] == (21014 if missing else 28021)
    assert ('estimability' in out) == missing

def test_frequency_partial_point_merge_requires_negative_proof_and_preserves_primary():
    import json
    from padml.bundle import canonical_json_bytes
    primary = {'status': 'COMPUTED', 'macro': {'NESTED_SELECTED_POLICY': {'UNFITTED_METRIC': 0.5}}, 'scopes': [{'scope': str(i), 'patient_count': 4, 'families': {'NESTED_SELECTED_POLICY': {'UNFITTED_METRIC': 0.5}}} for i in range(7)]}
    aar = {'status': 'COMPUTED', 'macro': {b: {'UNFITTED_METRIC': 0.6} for b in _freq_n.AAR_ESTIMANDS[:2]}, 'scopes': [{'scope': str(i), 'patient_count': 4, 'families': {b: {'UNFITTED_METRIC': 0.6} for b in _freq_n.AAR_ESTIMANDS[:2]}} for i in range(7)]}
    saved = canonical_json_bytes(primary)
    proof = {_FREQUENCY_BRANCH: {'status': 'NOT_ESTIMABLE', 'reason_code': 'FREQUENCY_LADDER_EXHAUSTED', 'unavailable_outers': [{'outer_fold': 3, 'native_outer_identity_sha256': '3' * 64, 'selector': _frequency_prepared()['estimability'][_FREQUENCY_BRANCH]}]}}
    with pytest.raises(ContractError):
        _freq_a._merge_a12_point_evaluations(primary, aar)
    result = _freq_a._merge_a12_point_evaluations(primary, aar, estimability=proof)
    assert set(result['macro']) == {'PRIMARY', *_freq_n.AAR_ESTIMANDS[:2]}
    assert result['macro']['PRIMARY'] == primary['macro']['NESTED_SELECTED_POLICY']
    assert canonical_json_bytes(primary) == saved

@pytest.mark.parametrize('partial', [False, True])
def test_frequency_bootstrap_preparation_reports_actual_point_branch_jobs(tmp_path, monkeypatch, partial):
    from padml import f4
    from padml.bundle import read_safe_zip
    monkeypatch.setattr(f4, '_f45_source_member_sha256', lambda: {'UNFITTED_SOURCE': 'a' * 64})
    branches = ('PRIMARY', *(_freq_n.AAR_ESTIMANDS[:2] if partial else _freq_n.AAR_ESTIMANDS))
    fixed = {'patient_ids': ['h1', 'h2'], 'patient_keys': {'h1': 1, 'h2': 2}, 'centers': ['38', '38'], 'horizons': _freq_a.HORIZONS, 'survival': {b: [[1.0] + [0.6] * 36, [1.0] + [0.7] * 36] for b in branches}, 'science_decision': _freq_n.science_decision_template(24), 'selection_horizon_months': 24, 'primary_ooc_sha256': 'a' * 64}
    if partial:
        fixed['estimability'] = {_FREQUENCY_BRANCH: {'status': 'NOT_ESTIMABLE', 'reason_code': 'FREQUENCY_LADDER_EXHAUSTED', 'unavailable_outers': [{'outer_fold': 3, 'native_outer_identity_sha256': '3' * 64, 'selector': _frequency_prepared()['estimability'][_FREQUENCY_BRANCH]}]}}
    root = tmp_path / 'numbers'
    root.mkdir()
    for name in set(_freq_a._A12_NESTED_POINT_MEMBERS) | _freq_a._A12_BOOTSTRAP_INPUT_MEMBERS:
        (root / name).write_bytes(b'UNFITTED_PREVIOUS_NUMERICAL_ARCHIVE')
    target, point = (tmp_path / 'input.zip', tmp_path / 'point.zip')
    got = _freq_a._write_a12_bootstrap_inputs(target, point, fixed, b'UNFITTED_RESPONSE', root, shared_rng_invocations=0)
    assert got['new_aar_point_metric_jobs'] == (14 if partial else 21)
    assert got['new_model_fits'] == got['bootstrap_replicates_executed'] == got['shared_rng_invocations'] == 0
    raw = read_safe_zip(target)['predictions.json']
    assert ('estimability' in _freq_a.strict_json_bytes(raw)) is partial


@pytest.mark.parametrize("partial", [False, True])
def test_frequency_report_tables_use_complete_reducer_shape(tmp_path, monkeypatch, partial):
    import csv
    from padml import worker
    from padml.bundle import write_deterministic_zip
    from test_nested_aar_aggregate import _unfitted_evaluation

    monkeypatch.setattr(f4, "native_metrics", lambda *args, **kwargs: pytest.fail("No native metrics authorized"))
    monkeypatch.setattr(f4, "bootstrap_draws", lambda *args, **kwargs: pytest.fail("No RNG authorized"))
    context, outers = _frequency_positive_fixture()
    if partial:
        row = outers[2]
        proof = _frequency_negative(row["source"])
        row["estimability"] = {_FREQUENCY_BRANCH: proof}
        row["members"].update({"development/selector/" + name: pin
                               for name, pin in proof["selector_members"].items()})
        del row["predictions"]["survival"][_FREQUENCY_BRANCH]
        for imp in range(1, 21):
            del row["native_members"][f"fits/O3_{_FREQUENCY_BRANCH}_M{imp:02d}.zip"]
    handoff = _freq_a._validate_a12_handoff(_freq_a._a12_handoff_from_outers(context, outers))
    evaluation = _unfitted_evaluation(handoff)
    evaluation.update(selection_horizon_months=24,
                      science_decision_sha256=handoff["science_decision"]["identity_sha256"])
    # Current reporting ABI requires all four DCA outputs, Harrell C and center spread.
    for scope in evaluation["scopes"]:
        for values in scope["families"].values():
            values["discrimination"]["harrell_c"] = {"value": 0.6}
            for t in (6, 12, 24, 36):
                values[f"dca_{t}"] = {"integrated_raw_nb": 0.1}
    for values in evaluation["macro"].values():
        values["all_followup"] = {"equal_center_harrell_c": 0.6}
        for t in (6, 12, 24, 36):
            values[str(t)].update(equal_center_raw_dca=0.1, worst_center_ibs=0.5, center_gap_ibs=0.1)
    template = _freq_a._a12_bootstrap_row(1, {"UNFITTED_METRICS_NO_RNG": True}, evaluation,
                                        branches=tuple(handoff["survival"]))
    rows = [dict(template, replicate=rid) for rid in range(1, 1001)]
    plan = {"replicate_count": 1000, "root_seed": 700000001,
            "rng": ["L'Ecuyer-CMRG", "Inversion", "Rejection"], "draws": ["UNFITTED_NO_RNG"] * 1000}
    numeric = _freq_a._reduce_a12_incremental_value(handoff, plan, evaluation, rows, formal=False)
    result = tmp_path / "result.zip"
    write_deterministic_zip(result, {"a12.json": canonical_json_bytes(numeric)})
    original = result.read_bytes()
    paths = worker._f45_report_tables(result, tmp_path, 24)
    assert paths == worker._f45_report_tables(result, tmp_path, 24)
    assert result.read_bytes() == original
    assert len(paths) == (3 if partial else 2)
    for name, count in (("absolute", (3 if partial else 4) * 386),
                        ("paired", (2 if partial else 3) * 386)):
        with (tmp_path / f"report-H24-{name}_rows.csv").open(newline="") as handle:
            table = list(csv.DictReader(handle))
        assert len(table) == count
        assert {_FREQUENCY_BRANCH} <= {row["branch"] for row in table} if not partial else all(
            row["branch"] != _FREQUENCY_BRANCH for row in table)
        assert all(row["bootstrap_total_replicates"] == "1000" for row in table)
    if partial:
        proof = strict_json_bytes((tmp_path / "report-estimability.json").read_bytes())
        assert proof["status"] == "PARTIALLY_NOT_ESTIMABLE"
        assert len(proof["outer_branch_coverage"]) == 24
        assert [row for row in proof["outer_branch_coverage"] if row["status"] == "NOT_ESTIMABLE"] == [
            {"branch": _FREQUENCY_BRANCH, "outer_fold": 3, "status": "NOT_ESTIMABLE"}]
    damaged = copy.deepcopy(numeric)
    damaged["bootstrap"]["absolute_rows"].pop()
    missing = tmp_path / "missing.zip"
    write_deterministic_zip(missing, {"a12.json": canonical_json_bytes(damaged)})
    with pytest.raises(ContractError, match="REPORT_ROW_COVERAGE_INVALID"):
        worker._f45_report_tables(missing, tmp_path, 24)


# Deterministic numerical evaluation checks; no fitted models or random draws.
def _evaluation_if_rows(ids, times, events, centers):
    raw = ('Patient_ID,All_Cause_Death,Death_Followup_months\n' + ''.join(
        f'{p},{e},{t}\n' for p,e,t in zip(ids,events,times))).encode()
    fields, rows = f4._response_rows(raw)
    response = f4._write_response_subset(fields,rows,ids,None)
    return f4.censoring_context(ids,centers,response), response['private_bytes']


def _evaluation_if_fixture(multicenter=True, censored=True):
    specs = [('36',[4,4,8,8,12,12,18,18,30,30,40,40],[1,0,1,0,1,0,1,1,0,1,1,0]),
             ('38',[2,4,4,8,10,12,12,18,18,30,40,40],[0,1,0,1,0,1,0,1,0,1,1,0])]
    ids, times, events, centers, risks = [], [], [], [], []
    for ci,(c,tt,ee) in enumerate(specs if multicenter else specs[:1]):
        for i in range(60):
            ids.append(f'{c}-{i}'); centers.append(c); times.append(float(tt[i%12]))
            events.append(ee[i%12] if censored else 1); risks.append(((i*7+ci*3)%11)/10)
    context, raw = _evaluation_if_rows(ids,times,events,centers)
    return context, risks, raw


def _evaluation_if_fd(context, risks, gradient):
    args = [context[k] for k in ('times','events','centers')] + [risks,12]
    epsilon, errors = 1e-5, []
    for i in range(len(risks)):
        plus, minus = [1.]*len(risks), [1.]*len(risks)
        plus[i] += epsilon; minus[i] -= epsilon
        numeric = (f4._evaluation_if_weighted_parts(*args,plus)[0]
                   - f4._evaluation_if_weighted_parts(*args,minus)[0])/(2*epsilon)
        errors.append(abs(numeric-gradient[i]))
    return max(errors)


@pytest.mark.parametrize('multicenter,censored', [(False,False),(False,True),(True,True)])
def test_evaluation_auc_if_empirical_derivative_and_point(multicenter, censored):
    ctx, risks, _ = _evaluation_if_fixture(multicenter,censored)
    result = f4._evaluation_if_auc_influence(ctx,risks,12)
    matrix = [[1.] + [1-p]*36 for p in risks]
    point = f4._evaluation_discrimination(matrix,ctx,12,12)['auc']['value']
    assert result['point'] == pytest.approx(point,abs=2e-15)
    assert _evaluation_if_fd(ctx,risks,result['raw_gradient']) < 2e-9
    assert abs(math.fsum(result['raw_gradient'])) < 1e-13
    for c in set(ctx['centers']):
        assert abs(math.fsum(d for d,cc in zip(result['fixed_center_gradient'],ctx['centers']) if cc==c)) < 1e-13
    if not censored:
        assert not any(result['censoring_gradient'])


def test_evaluation_auc_if_zero_endpoint_weights_keep_km_contribution():
    ctx, risks, _ = _evaluation_if_fixture()
    result = f4._evaluation_if_auc_influence(ctx,risks,12)
    zero = [i for i,w in enumerate(ctx['rows'][12]['weights']) if w==0]
    assert len(zero) == 35
    assert all(result['direct_gradient'][i]==0 for i in zero)
    assert all(abs(result['censoring_gradient'][i]) > 1e-8 for i in zero)


def test_evaluation_auc_if_fixed_center_contamination_derivative():
    ctx, risks, _ = _evaluation_if_fixture()
    result = f4._evaluation_if_auc_influence(ctx,risks,12)
    args = [ctx[k] for k in ('times','events','centers')] + [risks,12]
    epsilon = 1e-6
    for i in range(len(risks)):
        members = [j for j,c in enumerate(ctx['centers']) if c==ctx['centers'][i]]
        plus, minus = [1.]*len(risks), [1.]*len(risks)
        for j in members:
            plus[j] -= epsilon; minus[j] += epsilon
        plus[i] += len(members)*epsilon; minus[i] -= len(members)*epsilon
        numeric = (f4._evaluation_if_weighted_parts(*args,plus)[0]
                   -f4._evaluation_if_weighted_parts(*args,minus)[0])/(2*epsilon)
        assert numeric == pytest.approx(len(members)*result['fixed_center_gradient'][i],abs=2e-8)


def test_evaluation_auc_if_paired_and_three_repeat_covariance():
    ctx, risks, _ = _evaluation_if_fixture()
    a = f4._evaluation_if_auc_influence(ctx,risks,12)
    b = f4._evaluation_if_auc_influence(ctx,[1-p for p in risks],12)
    identical = f4._evaluation_if_paired_linear_contrast([a,a],[1.,-1.])
    assert identical['point'] == identical['variance'] == 0
    assert not any(identical['patient_if'])
    assert a['point']+b['point'] == pytest.approx(1.,abs=2e-15)
    assert f4._evaluation_if_covariance(a,b) == pytest.approx(-a['variance'],abs=1e-14)
    models, coefficients = [a,b,a,b], [1.,-1/3,-1/3,-1/3]
    gap = f4._evaluation_if_paired_linear_contrast(models,coefficients)
    expected = math.fsum(x*y*f4._evaluation_if_covariance(m,n)
        for x,m in zip(coefficients,models) for y,n in zip(coefficients,models))
    assert gap['variance'] == pytest.approx(expected,abs=1e-14)
    assert gap['point'] == pytest.approx(a['point']-(b['point']+a['point']+b['point'])/3,abs=2e-15)
    # Covariance across report times is valid when every patient/outcome remains aligned.
    later = f4._evaluation_if_auc_influence(ctx,risks,24)
    assert math.isfinite(f4._evaluation_if_covariance(a,later))


def test_evaluation_auc_if_fixed_original_center_weights():
    ctx, risks, _ = _evaluation_if_fixture()
    by_center = {}
    for c in sorted(set(ctx['centers'])):
        take = [i for i,cc in enumerate(ctx['centers']) if cc==c]
        local,_ = _evaluation_if_rows(*[[ctx[k][i] for i in take]
            for k in ('patient_ids','times','events','centers')])
        rr = [risks[i] for i in take]
        by_center[c] = f4._evaluation_if_auc_influence(local,rr,12)
        assert _evaluation_if_fd(local,rr,by_center[c]['raw_gradient']) < 2e-9
    macro = f4._evaluation_if_fixed_center_average(by_center,{'36':37,'38':63})
    assert macro['point'] == pytest.approx(.37*by_center['36']['point']+.63*by_center['38']['point'],abs=2e-15)
    assert macro['variance'] == pytest.approx(.37**2*by_center['36']['variance']+.63**2*by_center['38']['variance'],abs=1e-15)
    with pytest.raises(ContractError,match='CENTER_COVERAGE_INVALID'):
        f4._evaluation_if_fixed_center_average({'36':by_center['36']},{'36':37,'38':63})


def test_evaluation_auc_if_support_population_and_fixed_parent_guards():
    ctx, risks, _ = _evaluation_if_fixture()
    a = f4._evaluation_if_auc_influence(ctx,risks,12)
    with pytest.raises(ContractError,match='PAIRED_POPULATION_DRIFT'):
        f4._evaluation_if_covariance(a,dict(a,patient_ids=list(reversed(a['patient_ids']))))
    with pytest.raises(ContractError,match='FIXED_PARENT_KM_NOT_IMPLEMENTED'):
        f4._evaluation_if_auc_influence(dict(ctx,censoring_reference={}),risks,12)
    bad = copy.deepcopy(ctx)
    bad['rows'][12].update(status='NOT_ESTIMABLE',reasons=['EFFECTIVE_SAMPLE_SIZE_INSUFFICIENT'])
    with pytest.raises(ContractError,match='IPCW_SUPPORT_NOT_ESTIMABLE'):
        f4._evaluation_if_auc_influence(bad,risks,12)
    bad = copy.deepcopy(ctx)
    bad['censoring_steps']['36'][1][0] *= .99
    with pytest.raises(ContractError,match='LOCAL_KM_CONTEXT_DRIFT'):
        f4._evaluation_if_auc_influence(bad,risks,12)
    constant = f4._evaluation_if_auc_influence(ctx,[.5]*len(risks),12)
    assert constant['point']==.5 and constant['variance']==0
    assert constant['interval_status']=='UNRELIABLE'


def _evaluation_literal_uno(matrix, ctx, report_month, risk_month, *, wrong_left=False):
    import bisect
    risk = [1-row[risk_month] for row in matrix]
    numerator = denominator = 0.
    for i,(time,event) in enumerate(zip(ctx['times'],ctx['events'])):
        if event!=1 or time>report_month: continue
        for j,t in enumerate(ctx['times']):
            if t<=time: continue
            points,values=ctx['censoring_steps'][ctx['centers'][j]]
            k=(bisect.bisect_left if wrong_left else bisect.bisect_right)(points,time)
            g=1. if k==0 else values[k-1]
            pair=ctx['rows'][report_month]['weights'][i]/g
            numerator += pair*(float(risk[i]>risk[j])+.5*(risk[i]==risk[j]))
            denominator += pair
    return None if denominator==0 else numerator/denominator


@pytest.mark.parametrize('scenario',['ties','center55','no_terminal_controls'])
def test_evaluation_uno_cached_pairs_match_original_literal(scenario):
    ctx, risks, _ = _evaluation_if_fixture()
    if scenario=='center55':
        ctx,_ = _evaluation_if_rows(ctx['patient_ids'],ctx['times'],ctx['events'],
            ['55' if c=='38' else c for c in ctx['centers']])
    elif scenario=='no_terminal_controls':
        ctx = _evaluation_context([.1+i*.2 for i in range(80)],[1]*80)
        risks = [(i*7%11)/10 for i in range(80)]
    matrices = [[[1.]+[1-(.1+.2*p)]*12+[1-(.6-.2*p)]*24 for p in rr]
                for rr in (risks,[1-p for p in risks])]
    report = 24 if scenario=='no_terminal_controls' else 12
    saved = None
    for matrix in matrices:
        result=f4._evaluation_discrimination(matrix,ctx,report,24)
        assert result['uno_c']['value'] == pytest.approx(_evaluation_literal_uno(matrix,ctx,report,24),abs=1e-12)
        if saved is not None:
            assert ctx['_evaluation_uno_pairs'] is saved
        saved=ctx['_evaluation_uno_pairs']
        if scenario=='no_terminal_controls':
            assert result['auc']['reasons']==['ZERO_TERMINAL_CONTROLS']
            assert result['uno_c']['status']=='ESTIMABLE'
    if scenario=='ties':
        assert abs(_evaluation_literal_uno(matrices[0],ctx,12,24)
                   -_evaluation_literal_uno(matrices[0],ctx,12,24,wrong_left=True)) > 1e-6
        f4._evaluation_discrimination(matrices[0],ctx,24,24)
        assert ctx['_evaluation_uno_pairs'][0]==24 and ctx['_evaluation_uno_pairs'] is not saved
    if scenario=='center55':
        take=f4._evaluation_population_indices(ctx['centers'],36,'PRIMARY')
        projected,_=_evaluation_if_rows(*[[ctx[k][i] for i in take]
            for k in ('patient_ids','times','events','centers')])
        matrix=[matrices[0][i] for i in take]
        assert set(projected['centers'])=={'36'}
        result=f4._evaluation_discrimination(matrix,projected,36,24)
        assert result['uno_c']['value']==pytest.approx(_evaluation_literal_uno(matrix,projected,36,24),abs=1e-12)


def test_evaluation_auc_interval_quality_does_not_gate_point():
    ctx, risks, _ = _evaluation_if_fixture()
    base = f4._evaluation_if_auc_influence(ctx,risks,12)
    for events in (4,6,19):
        result = f4._evaluation_if_interval(dict(base,case_count=events))
        assert result['point']==base['point'] and result['status']=='UNRELIABLE'
        assert result['interval'] is None and len(result['diagnostic_interval'])==2
        assert result['reasons']==['SPARSE_EVENT_FINITE_SAMPLE_COVERAGE_NOT_VALIDATED']
    result=f4._evaluation_if_interval(dict(base,case_count=20))
    assert result['status']=='ASYMPTOTIC_APPROXIMATION' and result['interval'] is not None
    assert result['reliability']=='ASYMPTOTIC_ONLY_NOT_A_FINITE_SAMPLE_COVERAGE_GUARANTEE'
    assert f4._evaluation_if_interval(dict(base,point=1.))['reasons']==['BOUNDARY_AUC']
    assert f4._evaluation_if_interval(dict(base,variance=0.))['reasons']==['DEGENERATE_INFLUENCE_VARIANCE']
    identical=f4._evaluation_if_paired_linear_contrast([base,base],[1,-1])
    assert f4._evaluation_if_interval(identical,contrast=True)['reasons']==['DEGENERATE_INFLUENCE_VARIANCE']


def test_evaluation_macro_preserves_absolute_calibration_errors():
    values={c:{'calibration_slope':f4._evaluation_metric(slope),'citl':f4._evaluation_metric(citl),
               'auc':f4._evaluation_metric(auc)}
            for c,slope,citl,auc in [('36',.5,-.4,.6),('38',1.5,.4,.8)]}
    result=f4._evaluation_fixed_macro(values,{'36':37,'38':63})
    assert result['calibration_slope']['value']==pytest.approx(.5)
    assert result['citl']['value']==pytest.approx(.4)
    assert result['auc']['value']==pytest.approx(.37*.6+.63*.8)


def test_evaluation_ofit_point_consumer_keeps_repeat_mean_and_paired_macro():
    ctx,risks,raw=_evaluation_if_fixture()
    names=('APPARENT','OOF-R1','OOF-R2','OOF-R3')
    matrices={name:[[1.]+[1-p]*36 for p in rr] for name,rr in
              zip(names,[risks,[1-p for p in risks],risks,[1-p for p in risks]])}
    view={'patient_ids':ctx['patient_ids'],'centers':ctx['centers'],'response_csv':raw,'matrices':matrices}
    result=f4._evaluation_point_tables(view,12,calibration=False)
    for scope in ('MICRO','EQUAL_CENTER','PATIENT_WEIGHTED_CENTER'):
        table=result['tables']['PRIMARY/H12/'+scope]
        values=table['auc_influence']
        expected=sum(values[f'OOF-R{r}']['point'] for r in (1,2,3))/3
        assert values['OOF-MEAN']['point']==pytest.approx(expected,abs=2e-15)
        assert values['APPARENT_MINUS_OOF_MEAN']['point']==pytest.approx(values['APPARENT']['point']-expected,abs=2e-15)
    micro=result['tables']['PRIMARY/H12/MICRO']
    coef=[1.,-1/3,-1/3,-1/3]
    variance=math.fsum(a*b*micro['auc_covariance'][x][y]
        for a,x in zip(coef,names) for b,y in zip(coef,names))
    assert micro['auc_influence']['APPARENT_MINUS_OOF_MEAN']['variance']==pytest.approx(variance,abs=1e-14)


def _evaluation_if_with_center55():
    ctx,rr,_=_evaluation_if_fixture()
    count=60
    ids=ctx['patient_ids']+[f'55-{i}' for i in range(count)]
    centers=ctx['centers']+['55']*count
    times=ctx['times']+[3. if i%3==0 else 40. for i in range(count)]
    events=ctx['events']+[int(i%3==0) for i in range(count)]
    ctx,raw=_evaluation_if_rows(ids,times,events,centers)
    risks=rr+[(i*3%11)/10 for i in range(count)]
    return ctx,risks,raw


def test_same_six_center_population_for_whole_ibs_and_shared_covariance():
    ctx,rr,raw=_evaluation_if_with_center55()
    matrix=[[1.]+[1-(.1+.7*p)]*36 for p in rr]
    view={'patient_ids':ctx['patient_ids'],'centers':ctx['centers'],'response_csv':raw,'matrices':{'PRIMARY':matrix}}
    point=f4._evaluation_point_tables(view,12,include_centers=False,calibration=False)
    take=[i for i,c in enumerate(ctx['centers']) if c!='55']
    six,sixraw=_evaluation_if_rows(*[[ctx[k][i] for i in take] for k in ('patient_ids','times','events','centers')])
    selected=[matrix[i] for i in take]
    expected=f4._prediction_error_values(six['patient_ids'],selected,six)['ibs_0_to']['36']
    assert point['tables']['PRIMARY/H36/MICRO']['numbers']['PRIMARY']['ibs']['value']==expected
    assert point['tables']['PRIMARY/H12/MICRO']['patient_count']==180
    assert point['tables']['PRIMARY/H36/MICRO']['patient_count']==120
    a=f4._evaluation_if_auc_influence(ctx,[1-row[12] for row in matrix],12)
    b=f4._evaluation_if_auc_influence(six,[1-row[36] for row in selected],36)
    byid={p:i for i,p in enumerate(a['patient_ids'])}
    expected_cov=60/59*math.fsum(a['fixed_center_gradient'][byid[p]]*bb for p,bb in zip(b['patient_ids'],b['fixed_center_gradient']))
    assert f4._evaluation_if_covariance(a,b)==pytest.approx(expected_cov,abs=1e-15)
    assert f4._evaluation_if_covariance(b,a)==pytest.approx(expected_cov,abs=1e-15)
    assert point['cross_time_auc_covariance']['PRIMARY/PRIMARY']['12']['36']==pytest.approx(expected_cov,abs=1e-15)
    bad=copy.deepcopy(b);bad['patient_ids'][0]='foreign'
    with pytest.raises(ContractError,match='PAIRED_POPULATION_DRIFT'): f4._evaluation_if_covariance(a,bad)


def test_missing_oob_center_keeps_fixed_macro_na_and_original_counts():
    ctx,rr,raw=_evaluation_if_fixture()
    view={'patient_ids':ctx['patient_ids'],'centers':ctx['centers'],'response_csv':raw,
      'matrices':{'APPARENT':[[1.]+[1-(.1+.7*p)]*36 for p in rr]}}
    point=f4._evaluation_point_tables(view,12,calibration=False,inference=False)
    draw=[i for i,c in enumerate(ctx['centers']) if c=='36']
    numbers=f4._evaluation_bootstrap_tables(view,point,draw,label='original-oob-filter')
    center=numbers['PRIMARY/H12/38']['APPARENT']['ibs']
    macro=numbers['PRIMARY/H12/PATIENT_WEIGHTED_CENTER']['APPARENT']['ibs']
    assert center['value'] is None and macro['value'] is None
    assert center['reasons']==macro['reasons']==['EMPTY_EVALUATION_POPULATION']
    assert point['tables']['PRIMARY/H12/PATIENT_WEIGHTED_CENTER']['fixed_center_counts']=={'36':60,'38':60}


def _evaluation_curve_reduce_fixture(monkeypatch, *, bad_metric=999, bad_curve=1000, drift_knots=None):
    from contextlib import contextmanager
    from padml import nested_loco as n
    key='PRIMARY/H12/MICRO';decision=f4.evaluation_decision()
    curve={'status':'ESTIMABLE','fixed_logit_knots':[-1.,0.,1.], 'coefficients_in_scaled_natural_basis':[0.,.1,.3]}
    point={'decision':decision,'source_identity':'a'*64,'producer':{'run_identity':'b'*64,'source_identity':'c'*64},'tables':{key:{'numbers':{'PRIMARY':{'auc':f4._evaluation_metric(.6)}},'curves':{'PRIMARY':curve}}}}
    calls=[]
    @contextmanager
    def reader(path):
        b=int(path.stem[1:]);calls.append(b)
        metric=f4._evaluation_metric(None,['ZERO_EVENTS']) if b==bad_metric else f4._evaluation_metric(.5+b/10000)
        c=copy.deepcopy(curve)
        if b==bad_curve: c={'status':'NOT_ESTIMABLE','reasons':['COMPLETE_OR_QUASI_SEPARATION']}
        if b==drift_knots: c['fixed_logit_knots'][0]=-.9
        value=n._sealed({'replicate':b,'decision_sha256':decision['identity_sha256'],
           'source_identity':'a'*64,'draw_sha256':n._sha([0,1,1]),'producer':point['producer'],
           'tables':{key:{'PRIMARY':{'auc':metric}}},'curves':{key:{'PRIMARY':c}},'status':'COMPLETED'})
        yield SimpleNamespace(read=lambda name:canonical_json_bytes(value))
    monkeypatch.setattr(f4,'open_carrier',reader)
    return point,calls,key


def test_all_b_ids_and_failed_metric_or_curve_prevent_percentile_publication(monkeypatch):
    point,calls,key=_evaluation_curve_reduce_fixture(monkeypatch)
    values,bands=f4._evaluation_reduce_replicates(Path('/read-only-virtual'),point,[[0,1,1]]*1000,generations={'b'*64:'c'*64})
    assert calls==list(range(1,1001))
    row=values[key+'|PRIMARY|auc'];band=bands[key]['PRIMARY']
    assert row['estimable_replicates']==band['estimable_replicates']==999
    assert row['interval'] is None and band['interval'] is None
    assert row['failure_counts']=={'ZERO_EVENTS':1}
    assert band['failure_counts']=={'COMPLETE_OR_QUASI_SEPARATION':1}
    assert band['simultaneous_band'] is False


def test_curve_complete_b1000_type7_and_fixed_knot_drift(monkeypatch):
    point,calls,key=_evaluation_curve_reduce_fixture(monkeypatch,bad_metric=None,bad_curve=None)
    values,bands=f4._evaluation_reduce_replicates(Path('/read-only-virtual'),point,[[0,1,1]]*1000,generations={'b'*64:'c'*64})
    row=values[key+'|PRIMARY|auc'];band=bands[key]['PRIMARY']
    expected=[f4._type7_quantile([.5+b/10000 for b in range(1,1001)],q) for q in (.025,.975)]
    assert row['interval']==expected and len(band['interval'])==2
    assert len(band['raw_risk'])==len(band['interval'][0])==101
    assert band['interval'][0]==pytest.approx(band['point']) and band['interval'][1]==pytest.approx(band['point'])
    point,calls,key=_evaluation_curve_reduce_fixture(monkeypatch,drift_knots=2)
    with pytest.raises(ContractError,match='EVALUATION_BOOTSTRAP_KNOT_DRIFT'):
        f4._evaluation_reduce_replicates(Path('/read-only-virtual'),point,[[0,1,1]]*1000,generations={'b'*64:'c'*64})
    assert calls==[1,2]


# Exact evaluation-executor admission; engineering fixtures, no model/bootstrap fits.
from contextlib import contextmanager
from padml import integrated, nested_loco as n, runtime
from padml.bundle import write_deterministic_zip

_EVAL_CURRENT_PRODUCER = {'run_identity': '1'*64, 'source_identity': '2'*64}
_EVAL_PREVIOUS_PRODUCER = {'run_identity': '3'*64, 'source_identity': '4'*64}
_EVAL_GENERATIONS = {_EVAL_CURRENT_PRODUCER['run_identity']: _EVAL_CURRENT_PRODUCER['source_identity'],
                _EVAL_PREVIOUS_PRODUCER['run_identity']: _EVAL_PREVIOUS_PRODUCER['source_identity']}


def _evaluation_producer_run_fixture(tmp_path):
    unit = {'unit_id':'FULL0-H12','kind':'FULL0','context':'FULL0','horizon':12,'depends_on':[]}
    run = {'kind':'PADML_INTEGRATED_RAW_RUN_V1','run_root':str(tmp_path),
           'identity':_EVAL_CURRENT_PRODUCER['run_identity'],'source_identity':_EVAL_CURRENT_PRODUCER['source_identity'],
           'evaluation_decision':f4.evaluation_decision(),'resource_policy':{},'units':[unit]}
    return run, unit


@pytest.mark.parametrize('producer, accepted', [
    (_EVAL_CURRENT_PRODUCER,True), (_EVAL_PREVIOUS_PRODUCER,True),
    ({'run_identity':'a'*64,'source_identity':_EVAL_CURRENT_PRODUCER['source_identity']},False),
    ({'run_identity':_EVAL_PREVIOUS_PRODUCER['run_identity'],'source_identity':_EVAL_CURRENT_PRODUCER['source_identity']},False),
    (None,False), ({**_EVAL_CURRENT_PRODUCER,'extra':'not an admitted pair'},False),
])
def test_evaluation_producer_exact_pair_only(producer,accepted):
    if accepted:
        f4._evaluation_check_producer({'producer':producer},_EVAL_GENERATIONS)
    else:
        with pytest.raises(ContractError,match='EVALUATION_PRODUCER_NOT_ADMITTED'):
            f4._evaluation_check_producer({'producer':producer},_EVAL_GENERATIONS)


def test_evaluation_replicate_first_write_and_admitted_old_resume(tmp_path,monkeypatch):
    (tmp_path/'replicates').mkdir()
    binding={'decision_sha256':f4.evaluation_decision()['identity_sha256'],'source_identity':'a'*64}
    provenance={'producer':_EVAL_CURRENT_PRODUCER,'generations':_EVAL_GENERATIONS}
    calls=[]
    def values(*args,**kwargs):
        calls.append(True)
        return {'PRIMARY/H12/MICRO':{'PRIMARY':{'auc':f4._evaluation_metric(.6)}}}
    monkeypatch.setattr(f4,'_evaluation_bootstrap_tables',values)
    kwargs=dict(view={},point={},draws=[[0,1,1]],root=tmp_path,binding=binding,provenance=provenance)
    f4._evaluation_replicate_job(1,**kwargs)
    path=tmp_path/'replicates/B0001.zip'
    with f4.open_carrier(path) as archive: record=f4._f45_optimism_json(archive.read('values.json'))
    assert record['producer']==_EVAL_CURRENT_PRODUCER and len(calls)==1
    # The same scientific component produced by an exact previous generation
    # stays byte-for-byte unchanged and does not invoke numerical computation.
    record=n._sealed({k:v for k,v in record.items() if k!='identity_sha256'}|{'producer':_EVAL_PREVIOUS_PRODUCER})
    path.unlink();write_deterministic_zip(path,{'values.json':canonical_json_bytes(record)})
    original=path.read_bytes()
    f4._evaluation_replicate_job(1,**kwargs)
    assert path.read_bytes()==original and len(calls)==1
    record=n._sealed({k:v for k,v in record.items() if k!='identity_sha256'}|
                    {'producer':{'run_identity':'b'*64,'source_identity':_EVAL_PREVIOUS_PRODUCER['source_identity']}})
    path.unlink();write_deterministic_zip(path,{'values.json':canonical_json_bytes(record)})
    original=path.read_bytes()
    with pytest.raises(ContractError,match='EVALUATION_PRODUCER_NOT_ADMITTED'):
        f4._evaluation_replicate_job(1,**kwargs)
    assert path.read_bytes()==original and len(calls)==1


@pytest.mark.parametrize('producer,accepted',[(_EVAL_PREVIOUS_PRODUCER,True),
    ({'run_identity':'b'*64,'source_identity':_EVAL_PREVIOUS_PRODUCER['source_identity']},False)])
def test_evaluation_partial_point_checks_producer_before_dispatch(tmp_path,monkeypatch,producer,accepted):
    run,unit=_evaluation_producer_run_fixture(tmp_path)
    monkeypatch.setattr(integrated,'same_batch_generations',lambda _:dict(_EVAL_GENERATIONS))
    identity=f4._evaluation_appendix_identity(run,unit,None,{})
    point={'decision':f4.evaluation_decision(),'source_identity':n._sha(identity),
           'producer':producer,'tables':{}}
    write_deterministic_zip(tmp_path/'point.zip',{'point.json':canonical_json_bytes(point)})
    original=(tmp_path/'point.zip').read_bytes()
    class ReachedMissingOnlyDispatch(Exception): pass
    def stop(*args,**kwargs): raise ReachedMissingOnlyDispatch
    def no_recalculate(*args,**kwargs): raise AssertionError('partial point must not be recalculated')
    monkeypatch.setattr(runtime,'run_ready_families',stop)
    monkeypatch.setattr(f4,'_evaluation_point_tables',no_recalculate)
    exception=ReachedMissingOnlyDispatch if accepted else ContractError
    with pytest.raises(exception):
        f4._evaluation_run_fixed(run,unit,None,tmp_path,identity,{},[[0,1,1]]*1000)
    assert (tmp_path/'point.zip').read_bytes()==original and not (tmp_path/'result.json').exists()


@pytest.mark.parametrize('bad_at',[None,420])
def test_evaluation_reducer_old_point_new_b_keeps_science_and_rejects_unknown_producer(monkeypatch,bad_at):
    decision=f4.evaluation_decision();key='PRIMARY/H12/MICRO'
    point={'decision':decision,'source_identity':'a'*64,'producer':_EVAL_PREVIOUS_PRODUCER,
           'tables':{key:{'numbers':{'PRIMARY':{'auc':f4._evaluation_metric(.6)}}}}}
    calls=[]
    @contextmanager
    def reader(path):
        b=int(path.stem[1:]);calls.append(b)
        producer=_EVAL_CURRENT_PRODUCER if b%2 else _EVAL_PREVIOUS_PRODUCER
        if b==bad_at: producer={'run_identity':'b'*64,'source_identity':_EVAL_CURRENT_PRODUCER['source_identity']}
        value=n._sealed({'kind':'PADML_EVALUATION_REPLICATE_V2','replicate':b,
            'decision_sha256':decision['identity_sha256'],'source_identity':point['source_identity'],
            'producer':producer,'draw_sha256':n._sha([0,1,1]),'status':'COMPLETED',
            'tables':{key:{'PRIMARY':{'auc':f4._evaluation_metric(.6)}}},'curves':{}})
        yield SimpleNamespace(read=lambda _:canonical_json_bytes(value))
    monkeypatch.setattr(f4,'open_carrier',reader)
    if bad_at is None:
        values,bands=f4._evaluation_reduce_replicates(Path('/virtual-only'),point,[[0,1,1]]*1000,generations=_EVAL_GENERATIONS)
        assert calls==list(range(1,1001)) and bands=={}
        assert values[key+'|PRIMARY|auc']['interval']==[.6,.6]
    else:
        with pytest.raises(ContractError,match='EVALUATION_PRODUCER_NOT_ADMITTED'):
            f4._evaluation_reduce_replicates(Path('/virtual-only'),point,[[0,1,1]]*1000,generations=_EVAL_GENERATIONS)
        assert calls==list(range(1,bad_at+1))


@pytest.mark.parametrize('wrong_input',[False,True])
def test_evaluation_cold_reader_checks_point_scientific_identity(tmp_path,monkeypatch,wrong_input):
    run,unit=_evaluation_producer_run_fixture(tmp_path)
    monkeypatch.setattr(integrated,'same_batch_generations',lambda _:dict(_EVAL_GENERATIONS))
    identity=f4._evaluation_appendix_identity(run,unit,None,{})
    point={'decision':f4.evaluation_decision(),'producer':_EVAL_PREVIOUS_PRODUCER,
           'source_identity':'f'*64 if wrong_input else n._sha(identity),'tables':{}}
    write_deterministic_zip(tmp_path/'point.zip',{'point.json':canonical_json_bytes(point)})
    pin={'sha256':'9'*64,'size_bytes':1}
    members={'point.zip':dict(pin),**{f'replicates/B{b:04d}.zip':dict(pin) for b in range(1,1001)}}
    record=n._sealed({**identity,'producer':_EVAL_CURRENT_PRODUCER,'members':members,'status':'COMPLETED',
                     'replicate_count':1000,'direct_consumer_completed':True})
    (tmp_path/'result.json').write_bytes(canonical_json_bytes(record))
    calls=[]
    # Isolate the scientific callback; real byte-pin/closure behavior has its
    # existing independent storage tests. No fake record is persisted as proof.
    def first_qualification(paths,*,identity,record,expected,validate,cached_only):
        assert len(paths)==1001 and len(expected)==1001
        calls.append(True);validate();return expected
    monkeypatch.setattr(integrated,'qualified_file_pins',first_qualification)
    if wrong_input:
        with pytest.raises(ContractError,match='EVALUATION_POINT_.*DRIFT'):
            f4._evaluation_appendix_read(tmp_path,run,unit)
    else:
        assert f4._evaluation_appendix_read(tmp_path,run,unit)==record
    assert calls==[True] and not (tmp_path/'result.qualified.json').exists()



"""Bounded engineering reads of prepublished B IDs; never numerical resampling."""
from pathlib import Path
from functools import partial
import pickle
import zipfile

import pytest

from padml import f4, nested_loco as n, runtime
from padml.bundle import ContractError, canonical_json_bytes, sha256_file, write_deterministic_zip


@pytest.mark.parametrize('selection', [False, True])
@pytest.mark.parametrize('damage', [None, 'draw', 'source', 'zip', 'producer'])
def test_evaluation_existing_b_never_recomputes_or_redraws(tmp_path, monkeypatch, selection, damage):
    root=tmp_path/'evaluation-amendment';(root/'replicates').mkdir(parents=True)
    b=421
    draws=[[1,1,0]]*1000
    before=[list(d) for d in draws]
    decision=f4.evaluation_decision()['identity_sha256']
    identity={'decision_sha256':decision,'source_unit':'FULL0-H06','unfitted':'boundary'}
    binding={'decision_sha256':decision,'source_identity':n._sha(identity)}
    provenance={'producer':{'run_identity':'1'*64,'source_identity':'2'*64},
        'generations':{'1'*64:'2'*64,'3'*64:'4'*64}}
    record={'kind':'PADML_EVALUATION_SELECTION_REPLICATE_V2' if selection else 'PADML_EVALUATION_REPLICATE_V2',
        'replicate':b,**binding,'draw_sha256':n._sha(draws[b-1]),'status':'COMPLETED','tables':{},
        'producer':{'run_identity':'3'*64,'source_identity':'4'*64}}
    if selection:record['original_replicate_identity']='b'*64
    if damage=='draw':record['draw_sha256']='d'*64
    if damage=='source':record['source_identity']='e'*64
    if damage=='producer':record['producer']['source_identity']='5'*64
    target=root/f'replicates/B{b:04d}.zip'
    if damage=='zip':target.write_bytes(b'partial-not-a-zip')
    else:write_deterministic_zip(target,{'values.json':canonical_json_bytes(n._sealed(record))})
    saved=target.read_bytes();inode=target.stat().st_ino
    called=[]
    def forbidden(*args,**kwargs):
        called.append(True)
        pytest.fail('existing B may not refit, recalculate or redraw')
    monkeypatch.setattr(f4,'_evaluation_bootstrap_tables',forbidden)
    monkeypatch.setattr(f4,'_evaluation_selection_winner',forbidden)
    monkeypatch.setattr(f4,'bootstrap_draws',forbidden)
    if selection:
        def original(path,loaded,replicate):
            assert path==root.parent/f'replicates/B{b:04d}.json' and replicate==b
            return {'identity_sha256':'b'*64}
        monkeypatch.setattr(f4,'_f45_read_selection_replicate',original)
        job=partial(f4._evaluation_selection_job,loaded={'draws':{'draws':draws}},templates={},views={},
                    root=root,identity=identity,old_root=root.parent,provenance=provenance)
    else:
        job=partial(f4._evaluation_replicate_job,view={},point={},draws=draws,root=root,binding=binding,provenance=provenance)
    job.cache_files=partial(f4._evaluation_replicate_cache_files,root=root)
    copied=pickle.loads(pickle.dumps(job))
    assert runtime._task_cache_files(copied,b)==(target,)
    if damage:
        with pytest.raises((ContractError,zipfile.BadZipFile)):
            job(b)
    else:
        result=job(b)
        assert result=={'replicate':b,'pin':{'sha256':sha256_file(target),'size_bytes':len(saved)}}
    assert not called and draws==before
    assert target.read_bytes()==saved and target.stat().st_ino==inode


# Fixed synthetic evaluation contracts only. These tests never run the
# registered 6x2000 simulations, model fitting, MICE, SHAP, or B1000 draws.
@pytest.fixture
def _perturbation_prepared_view():
    ctx,risks,raw=_evaluation_if_with_center55()
    names=('APPARENT','OOF-R1','OOF-R2','OOF-R3')
    rr=(risks,risks,[1-p for p in risks],[.1+.5*p for p in risks])
    view={'patient_ids':ctx['patient_ids'],'centers':ctx['centers'],'response_csv':raw,
        'matrices':{name:[[1.]+[1-p]*36 for p in values] for name,values in zip(names,rr)}}
    point=f4._evaluation_point_tables(view,12,calibration=False,inference=False)
    universe=['UNFITTED_OUTSIDE_VIEW',*ctx['patient_ids']]
    return ctx,view,point,universe


def test_evaluation_perturbation_shared_weights_all_one_and_km_ties(_perturbation_prepared_view):
    import numpy as np
    ctx,view,point,universe=_perturbation_prepared_view
    saved=canonical_json_bytes(point)
    plan=f4._evaluation_perturbation_prepare(view,point,universe)
    result=f4._evaluation_perturbation_block(plan,[1],np.ones((1,len(universe))))
    for key,original in plan['original'].items():
        if original['value'] is None: assert np.isnan(result['values'][key][0])
        else: assert result['values'][key][0]==pytest.approx(original['value'],abs=1e-12)
    assert canonical_json_bytes(point)==saved
    # Nonuniform supplied weights, shared by repeated predictions/reports.
    weights=np.arange(1.,3*len(universe)+1).reshape(3,len(universe))
    shared=f4._evaluation_perturbation_block(plan,[3,4,5],weights)
    assert np.array_equal(shared['values'][('PRIMARY/H12/MICRO','APPARENT')],
                          shared['values'][('PRIMARY/H12/MICRO','OOF-R1')])
    assert np.array_equal(shared['values'][('PRIMARY/H36/MICRO','APPARENT')],
                          shared['values'][('SIX_CENTER_SENSITIVITY/H36/MICRO','APPARENT')])
    for i in range(3):
        table='PRIMARY/H12/MICRO'
        expected=math.fsum(shared['values'][(table,f'OOF-R{r}')][i]/3 for r in (1,2,3))
        assert shared['values'][(table,'OOF-MEAN')][i]==pytest.approx(expected,abs=1e-15)
        assert shared['values'][(table,'APPARENT_MINUS_OOF_MEAN')][i]==pytest.approx(
            shared['values'][(table,'APPARENT')][i]-expected,abs=1e-15)
    full=next(pop for pop in plan['populations'] if len(pop['ids'])==len(ctx['patient_ids']))
    six=next(pop for pop in plan['populations'] if len(pop['ids'])==len(ctx['patient_ids'])-60)
    full_w,_=f4._evaluation_perturbation_normalize_center_weights(full,weights[:,full['universe_positions']])
    six_w,_=f4._evaluation_perturbation_normalize_center_weights(six,weights[:,six['universe_positions']])
    assert np.array_equal(full_w[:,:len(six['ids'])],six_w)
    for _,members,*_ in full['groups']:
        assert full_w[:,members].sum(axis=1)==pytest.approx([len(members)]*3)
    # Death at4 leaves the censoring risk set first; case G(4-), control G(4).
    pop=f4._evaluation_perturbation_prepare_population(['a','b','c','d'],[4.,4.,8.,10.],
                                                      [1,0,1,0],['36']*4)
    w=np.asarray([[2.,3.,5.,7.]])
    km=f4._evaluation_perturbation_weighted_km_block(pop,w)
    assert km['36'][1][0,0]==1-3/15
    endpoint=f4._evaluation_perturbation_endpoint_block(pop,w,km,4)
    assert endpoint['role'][0].tolist()==[2.,0.,5/.8,7/.8]
    value,valid=f4._evaluation_perturbation_auc_block(endpoint,
        f4._evaluation_perturbation_prepare_risk(endpoint,[.5,.2,.5,.1]))
    scalar=f4._evaluation_if_weighted_parts([4.,4.,8.,10.],[1,0,1,0],['36']*4,
                                          [.5,.2,.5,.1],4,w[0].tolist())[0]
    assert valid.tolist()==[True] and value[0]==pytest.approx(scalar,abs=2e-15)


@pytest.mark.parametrize('damage,match',[
    ('universe','UNIVERSE_INVALID'),('population','POINT_POPULATION_DRIFT'),
    ('point','ALL_ONE_POINT_DRIFT'),('support','ORIGINAL_SUPPORT_INVALID')])
def test_evaluation_perturbation_preparation_rejects_drift(_perturbation_prepared_view,damage,match):
    _,view,point,universe=_perturbation_prepared_view
    if damage=='universe': universe=universe[:-1]
    else:
        row=point['tables']['PRIMARY/H12/MICRO']
        if damage=='population': row['patient_order_sha256']='0'*64
        elif damage=='point': row['numbers']['APPARENT']['auc']['value']+=.01
        else: row['support']['status']='NOT_ESTIMABLE'
    with pytest.raises(ContractError,match=match):
        f4._evaluation_perturbation_prepare(view,point,universe)


def _perturbation_publication_fixture(tmp_path,monkeypatch,fixture):
    from padml import carriers
    _,view,point,universe=fixture
    run,unit=_evaluation_producer_run_fixture(tmp_path)
    run.update(run_id='UNFITTED_P_TEST',raw_input={'fixture':'NO_CLINICAL_INPUT'},
               post_result_repair=f4.post_result_repair_decision())
    old=tmp_path/'original';old.mkdir()
    (old/'result.json').write_bytes(b'{"UNFITTED":true}\n')
    write_deterministic_zip(old/'point.zip',{'point.json':canonical_json_bytes(point)})
    binding=tmp_path/'binding';binding.mkdir()
    (binding/'binding.json').write_bytes(b'{"UNFITTED":true}\n')
    original={'identity_sha256':'9'*64,'sources':{'fixture':'UNFITTED_SOURCES'}}
    identity={'fixture':'UNFITTED_ORIGINAL_IDENTITY'}
    point['source_identity']=n._sha(identity)
    monkeypatch.setattr(f4,'_evaluation_appendix_identity',lambda *a,**kw:identity)
    monkeypatch.setattr(f4,'evaluation_appendix_root',lambda *a:old)
    monkeypatch.setattr(f4,'_evaluation_provenance',lambda *a:{
        'producer':_EVAL_CURRENT_PRODUCER,'generations':_EVAL_GENERATIONS})
    frozen={'centers':dict.fromkeys(universe,'UNFITTED_GROUPING'),
            'receipt':{'run_id':run['run_id'],'source_identity':_EVAL_CURRENT_PRODUCER['source_identity']}}
    monkeypatch.setattr(integrated,'load_raw_binding',lambda *a,**kw:frozen)
    monkeypatch.setattr(integrated,'same_batch_generations',lambda *a:_EVAL_GENERATIONS)
    monkeypatch.setattr(runtime,'admit_stage',lambda *a,**kw:None)
    # Only the outer source carrier ABI is stubbed. Its bytes are still pinned;
    # the actual numerical block writer/reader, seals and producer guards run.
    def reference(path,role,run):
        return {'path':str(path),'role':role,'sha256':sha256_file(path)}
    def validate(reference,run):
        assert sha256_file(Path(reference['path']))==reference['sha256']
    monkeypatch.setattr(carriers,'file_reference',reference)
    monkeypatch.setattr(carriers,'validate_reference',validate)
    def forbidden(*a,**kw): pytest.fail('P inference must not redraw B1000 or fit')
    monkeypatch.setattr(f4,'bootstrap_draws',forbidden)
    monkeypatch.setattr(f4,'_execute_f4_model_component',forbidden)
    root=tmp_path/'units'/unit['unit_id']/'post-result-repair-20261008/auc-exp1'
    return run,unit,view,point,original,root


def _perturbation_interrupt_p32(monkeypatch,args):
    run,unit,view,point,original,root=args
    actual=f4._evaluation_perturbation_blocks
    def interrupt(*a,**kw):
        if kw['start']==33: raise RuntimeError('UNFITTED_INTERRUPT_AFTER_P32')
        yield from actual(*a,**kw)
    monkeypatch.setattr(f4,'_evaluation_perturbation_blocks',interrupt)
    with pytest.raises(RuntimeError,match='UNFITTED_INTERRUPT_AFTER_P32'):
        f4.run_evaluation_perturbation(run,unit,view,point,original_result=original)
    monkeypatch.setattr(f4,'_evaluation_perturbation_blocks',actual)
    path=root/'blocks/P0001-0032.zip'
    assert path.is_file() and not (root/'result.json').exists()
    return path,actual


def test_evaluation_perturbation_formal_blocks_resume_exact_rng(
        tmp_path,monkeypatch,_perturbation_prepared_view):
    import numpy as np
    args=_perturbation_publication_fixture(tmp_path,monkeypatch,_perturbation_prepared_view)
    run,unit,view,point,original,root=args
    first,actual=_perturbation_interrupt_p32(monkeypatch,args)
    original_bytes=first.read_bytes();original_stat=first.stat()
    universe=_perturbation_prepared_view[3]
    prepared=f4._evaluation_perturbation_prepare(view,point,universe)
    expected={k:[] for k in prepared['coordinate_order'] if prepared['original'][k]['value'] is not None}
    generator=np.random.Generator(np.random.PCG64(730000001))
    ids=[]
    for block in actual(prepared,generator,block_size=64):
        ids.extend(block['P'])
        for key in expected: expected[key].extend(block['values'][key].tolist())
    assert ids==list(range(1,2000))
    calls=[]
    def traced(*a,**kw):
        calls.append(kw['start']);yield from actual(*a,**kw)
    monkeypatch.setattr(f4,'_evaluation_perturbation_blocks',traced)
    result=f4.run_evaluation_perturbation(run,unit,view,point,original_result=original)
    assert calls==list(range(33,2000,32))
    assert first.read_bytes()==original_bytes and first.stat().st_ino==original_stat.st_ino
    assert first.stat().st_mtime_ns==original_stat.st_mtime_ns
    observed=[];records=[]
    for path in sorted((root/'blocks').glob('P*.zip')):
        with f4.open_carrier(path) as archive:
            record=strict_json_bytes(archive.read('block.json'))
            observed.append(np.frombuffer(archive.read('values.f64'),dtype='<f8').reshape(len(expected),-1))
            records.append(record)
    assert np.array_equal(np.concatenate(observed,axis=1),np.asarray(list(expected.values()),dtype='<f8'),equal_nan=True)
    assert records[-1]['PCG64_state_after']==generator.bit_generator.state
    assert result['P_ids']==list(range(1,2000))
    assert result['new_prediction_model_fits']==result['new_mice_chains']==result['new_shap_solves']==0
    assert result['reliability_status']=='REQUIRES_REGISTERED_COVERAGE_VALIDATION'
    def forbidden(*a,**kw):pytest.fail('completed P must consume retained evidence')
    monkeypatch.setattr(f4,'_evaluation_perturbation_prepare',forbidden)
    monkeypatch.setattr(f4,'_evaluation_perturbation_blocks',forbidden)
    assert f4.run_evaluation_perturbation(run,unit,view,point,original_result=original)==result


@pytest.mark.parametrize('damage,match',[
    ('request','BLOCK_DRIFT'),('values','BLOCK_DRIFT'),('producer','PRODUCER_NOT_ADMITTED')])
def test_evaluation_perturbation_retained_block_rejects_drift_before_new_p(
        tmp_path,monkeypatch,_perturbation_prepared_view,damage,match):
    args=_perturbation_publication_fixture(tmp_path,monkeypatch,_perturbation_prepared_view)
    path,_=_perturbation_interrupt_p32(monkeypatch,args)
    with f4.open_carrier(path) as archive:
        record=strict_json_bytes(archive.read('block.json'));raw=archive.read('values.f64')
    if damage=='request':record['request']['state_before_sha256']='0'*64
    elif damage=='values':raw=bytes([raw[0]^1])+raw[1:]
    else:record['producer']={'run_identity':'f'*64,'source_identity':'e'*64}
    record=n._sealed({k:v for k,v in record.items() if k!='identity_sha256'})
    path.unlink();write_deterministic_zip(path,{'block.json':canonical_json_bytes(record),'values.f64':raw})
    saved=path.read_bytes();stamp=path.stat()
    def forbidden(*a,**kw):pytest.fail('drift cannot be repaired by a new P')
    monkeypatch.setattr(f4,'_evaluation_perturbation_blocks',forbidden)
    run,unit,view,point,original,_=args
    with pytest.raises(ContractError,match=match):
        f4.run_evaluation_perturbation(run,unit,view,point,original_result=original)
    assert path.read_bytes()==saved and path.stat().st_ino==stamp.st_ino and path.stat().st_mtime_ns==stamp.st_mtime_ns


def test_evaluation_perturbation_simulation_contract_and_publication_rules():
    decision=f4._evaluation_perturbation_simulation_decision()
    registered=f4.post_result_repair_decision()['auc_perturbation']['validation']
    assert [s['data_seed'] for s in decision['scenarios']]==registered['data_seeds']
    assert [[c['n'] for c in s['centers']] for s in decision['scenarios'][4:]]==[registered['multi_center_sizes']]*2
    assert [[c['latent_censor_probability'] for c in s['centers']] for s in decision['scenarios'][4:]]==registered['multi_center_censor_probabilities']
    assert 'OOF-R1_MINUS_OOF-R2' in decision['metrics']
    assert decision['weight_domain'].endswith('(scenario_ordinal,dataset_replication))')
    assert decision['noise_domain'].endswith('(7,scenario_ordinal,dataset_replication))')
    original=f4._evaluation_metric(.6)
    valid={'status':'UNRELIABLE','P_count':1999,'valid_P_count':1999,'interval':None,
        'diagnostic_interval':[.5,.7],'reasons':['FINITE_SAMPLE_COVERAGE_NOT_YET_VALIDATED']}
    call=lambda row:f4._evaluation_perturbation_simulation_interval_record(row,original,
        'EXP1_REESTIMATED_KM',.6,zero_difference=False)
    assert call(valid)['published']
    for reason in ('BOUNDARY_AUC','DEGENERATE_PERTURBATION_DISTRIBUTION',
                   'INCOMPLETE_PERTURBATION_VECTOR','ORIGINAL_POINT_NOT_ESTIMABLE'):
        row=call(dict(valid,reasons=[reason]))
        assert row['diagnostic_field_present'] and not row['available'] and not row['published']
        assert row['covers_truth'] is None and row['width'] is None
    assert not call(dict(valid,valid_P_count=1998))['published']
    assert not call(dict(valid,reasons=valid['reasons']+['UNKNOWN']))['published']


def _perturbation_simulation_gate_records(*,null=False,unavailable=0,rejected=0):
    # 2000 NONSTOCHASTIC row-shaped counterexamples, not simulated datasets.
    for r in range(1,2001):
        point_ok=r>10;published=r>10+unavailable
        reject=published and r<=10+unavailable+rejected
        yield {'scenario_ordinal':1,'dataset_replication':r,'scenario_sha256':'UNFITTED',
            'status':'COMPLETED','P_ids_preserved':1999,'new_prediction_model_fits':0,
            'metrics':[{'scope':'MICRO','metric':'OOF-R1_MINUS_OOF-R2' if null else 'APPARENT',
                'truth':0. if null else .6,'point':(0. if null else .6) if point_ok else None,
                'valid_P':1999 if published else 0,
                'intervals':{m:{'available':published,'published':published,
                    'covers_truth':not reject if published else None,
                    'rejects_zero':reject if null and published else None,
                    'width':.1 if published else None,'reasons':[] if published else ['UNFITTED_UNPUBLISHED']}
                    for m in ('EMPIRICAL_IF','EXP1_REESTIMATED_KM')}}]}


@pytest.mark.parametrize('null,unavailable,rejected,passed',[
    (False,30,30,True),(False,500,0,False),(True,0,80,True),(True,0,180,False),(True,500,0,False)])
def test_evaluation_perturbation_simulation_point_denominator_and_wilson_gates(null,unavailable,rejected,passed):
    gates=f4._evaluation_perturbation_simulation_decision()['validation_gates']
    registered=f4.post_result_repair_decision()['auc_perturbation']['validation']
    assert gates=={k:registered[k] for k in gates}
    name='OOF-R1_MINUS_OOF-R2' if null else 'APPARENT'
    scenario={'ordinal':1,'scenario_sha256':'UNFITTED','validation_gates':gates,
              'truth':{'MICRO':{name:0. if null else .6}}}
    result=f4._evaluation_perturbation_simulation_reduce(
        _perturbation_simulation_gate_records(null=null,unavailable=unavailable,rejected=rejected),scenario=scenario)
    for row in result['metrics']:
        coverage=row['coverage_point_estimable_unpublished_not_covered']
        assert coverage['denominator']==1990 and coverage['numerator']==1990-unavailable-rejected
        assert row['publication_rate_point_estimable']['denominator']==1990
        assert row['publication_rate_point_estimable']['numerator']==1990-unavailable
        assert row['coverage_available']['denominator']==1990-unavailable
        assert row['coverage_all_NA_not_covered']['denominator']==2000
        assert (row['validation_status']=='REGISTERED_SIMULATION_GATES_PASSED')==passed
        if null:
            assert row['zero_difference_rejection']['point_estimable']['numerator']==rejected
            assert row['zero_difference_rejection']['point_estimable']['denominator']==1990
            assert row['zero_difference_rejection']['published_only']['denominator']==1990-unavailable
        if unavailable==500:
            assert row['coverage_available']['estimate']==1. and not passed
            assert 'PUBLICATION_RATE_BELOW_REGISTERED_MINIMUM' in row['validation_failure_reasons']
        if null and rejected==180:
            assert 'WILSON_ZERO_DIFFERENCE_REJECTION_UPPER_ABOVE_REGISTERED_MAXIMUM' in row['validation_failure_reasons']
    assert result['reliability_status']=='NOT_AUTOMATICALLY_ACCEPTED'


@pytest.mark.parametrize('damage,match',[('missing','REPLICATES_INCOMPLETE'),
    ('duplicate','REPLICATE_INVALID_OR_DUPLICATE'),('gate','GATE_CONTRACT_DRIFT')])
def test_evaluation_perturbation_simulation_rejects_incomplete_ids_and_gate_drift(damage,match):
    rows=list(_perturbation_simulation_gate_records())
    gates=f4._evaluation_perturbation_simulation_decision()['validation_gates']
    scenario={'ordinal':1,'scenario_sha256':'UNFITTED','validation_gates':gates,'truth':{'MICRO':{'APPARENT':.6}}}
    if damage=='missing':rows.pop()
    elif damage=='duplicate':rows[-1]=copy.deepcopy(rows[0])
    else:gates['coverage_min']-=.01
    with pytest.raises(ContractError,match=match):
        f4._evaluation_perturbation_simulation_reduce(rows,scenario=scenario)


# Calibration repair: immutable original inputs, sparse leaves and finite-engineering callbacks only.
_CR_METRICS = ('auc','ibs','oe','citl','calibration_slope','ici','e50','e90')
_CR_BASES = ('APPARENT','OOF-R1','OOF-R2','OOF-R3')
_CR_ENV = 'a'*64
_CR_PROVENANCE = {'producer':_EVAL_CURRENT_PRODUCER,'generations':_EVAL_GENERATIONS}
def _cr_ok(value): return f4._evaluation_metric(float(value))

def _cr_fail(): return f4._evaluation_metric(None,['BINOMIAL_MLE_DID_NOT_CONVERGE'],status='NUMERICAL_FAILURE')

def _cr_curve(good=True):
    return ({'status':'ESTIMABLE','method':'BLR_IPCW_NATURAL_SPLINE','fixed_logit_knots':[-3.,-2.,-1.],
        'coefficients_in_scaled_natural_basis':[0.,1.,.2],'new_predictive_calibration':False,
        'positive_weight_count':60,'outside_positive_weight_range_count':0} if good else
        {'status':'NUMERICAL_FAILURE','reasons':['BINOMIAL_MLE_DID_NOT_CONVERGE'],
            'fixed_logit_knots':[-3.,-2.,-1.]})

def _cr_point(*,failed=True,macro=True):
    tables={}
    scopes=['MICRO','36','38'] if macro else ['MICRO']
    for scope in scopes:
        key='PRIMARY/H06/'+scope
        numbers={name:{m:_cr_ok(1.2 if m=='calibration_slope' else .2) for m in _CR_METRICS} for name in _CR_BASES}
        curves={name:_cr_curve() for name in _CR_BASES}
        if failed and scope=='36':
            for m in ('ici','e50','e90'): numbers['APPARENT'][m]=_cr_fail()
            curves['APPARENT']=_cr_curve(False)
            numbers['OOF-R1']['calibration_slope']=_cr_fail()
        if failed and scope=='38':
            for m in ('ici','e50','e90'):
                numbers['APPARENT'][m]=f4._evaluation_metric(None,['POSITIVE_WEIGHT_DESIGN_RANK_DEFICIENT'])
            curves['APPARENT']={'status':'NOT_ESTIMABLE','reasons':['POSITIVE_WEIGHT_DESIGN_RANK_DEFICIENT'],
                'fixed_logit_knots':[-3.,-2.,-1.]}
        tables[key]={'role':'PRIMARY','report_month':6,'scope':scope,'patient_count':60,
            'patient_order_sha256':'order','centers':['36','38'],'numbers':numbers,'curves':curves}
    if macro:
        for mode in ('EQUAL_CENTER','PATIENT_WEIGHTED_CENTER'):
            counts={'36':1,'38':1} if mode=='EQUAL_CENTER' else {'36':30,'38':60}
            tables['PRIMARY/H06/'+mode]={'role':'PRIMARY','report_month':6,'scope':mode,
                'patient_count':90,'centers':['36','38'],'fixed_center_counts':counts,
                'numbers':{name:f4._evaluation_fixed_macro({c:tables['PRIMARY/H06/'+c]['numbers'][name]
                    for c in counts},counts) for name in _CR_BASES}}
    return {'kind':'PADML_EVALUATION_POINT_V2','status':'COMPLETED','decision':f4.evaluation_decision(),
        'calibration':True,'development_horizon':6,'source_identity':'original-sources','producer':_EVAL_PREVIOUS_PRODUCER,
        'tables':tables,'fixed_calibration_knots':{k:{name:[-3.,-2.,-1.] for name in _CR_BASES}
            for k,t in tables.items() if t['scope'] not in {'EQUAL_CENTER','PATIENT_WEIGHTED_CENTER'}}}

def _cr_record(point,b=1):
    return n._sealed({'kind':'PADML_EVALUATION_REPLICATE_V2','replicate':b,'status':'COMPLETED',
        'source_identity':point['source_identity'],'decision_sha256':point['decision']['identity_sha256'],
        'draw_sha256':n._sha([0,1]),'producer':_EVAL_PREVIOUS_PRODUCER,
        'tables':{k:f4._evaluation_contrasts(copy.deepcopy(t['numbers'])) for k,t in point['tables'].items()},
        'curves':{k:copy.deepcopy(t['curves']) for k,t in point['tables'].items() if 'curves' in t}})

def _cr_patch(point,old,b=1,*,shared,damage=None):
    target=f4._evaluation_calibration_repair_targets(point,old,b)
    patches={}
    for key,models in target.items():
        for name,components in models.items():
            for component in components:
                value={'input_sha256':'a'*64,'metrics':{m:_cr_ok(.1 if m!='calibration_slope' else .8)
                    for m in (('ici','e50','e90') if component=='spline' else (component,))},
                    'diagnostics':{'status':'ESTIMABLE'}}
                if component=='spline': value['curve']=_cr_curve()
                if damage is not None: damage(component,value)
                binding=f4._evaluation_calibration_repair_leaf_binding(component,[[1.],[1.]],[0.,1.],[1.,1.],None,[.1,.2],environment_lock_sha256=_CR_ENV,fixed_knots=[-3.,-2.,-1.])
                binding['numeric_input_sha256']=n._sha({'unfitted':value})
                leaf=f4._evaluation_calibration_repair_leaf(shared,binding,lambda:value,provenance=_CR_PROVENANCE)
                patches.setdefault(key,{}).setdefault(name,{})[component]=leaf['reference']
    return n._sealed({**f4._evaluation_calibration_repair_binding(point,old,b),'producer':_EVAL_CURRENT_PRODUCER,
        'status':'COMPLETED','patches':patches,
        'new_prediction_model_fits':0,'new_mice_chains':0,'new_shap_solves':0})


def test_calibration_repair_basic_only_fixed_macro_and_same_B(tmp_path):
    point=_cr_point(); old=_cr_record(point); before=canonical_json_bytes(old)
    shared=tmp_path.resolve()/'shared'
    patch=_cr_patch(point,old,shared=shared)
    assert f4._evaluation_calibration_repair_targets(point,old,1)=={
        'PRIMARY/H06/36':{'APPARENT':['spline'],'OOF-R1':['calibration_slope']}}
    fixed=f4._evaluation_calibration_repair_merge(point,old,patch,generations=_EVAL_GENERATIONS,shared=shared)
    assert canonical_json_bytes(old)==before
    for key,row in old['tables'].items():
        for name,metrics in row.items():
            for metric in ('auc','ibs','oe','citl'):
                assert fixed['tables'][key][name][metric]==metrics[metric]
    row=fixed['tables']['PRIMARY/H06/36']
    assert row['OOF-MEAN']['calibration_slope']['value']==pytest.approx((.8+1.2+1.2)/3)
    assert row['APPARENT_MINUS_OOF_MEAN']['calibration_slope']['value']==pytest.approx(1.2-(.8+1.2+1.2)/3)
    row=fixed['tables']['PRIMARY/H06/PATIENT_WEIGHTED_CENTER']
    assert row['OOF-R1']['calibration_slope']['value']==pytest.approx(.2)
    assert row['APPARENT']['ici']['reasons']==['POSITIVE_WEIGHT_DESIGN_RANK_DEFICIENT']


@pytest.mark.parametrize('damage,reason',[
    ('original','PATCH_BINDING_DRIFT'),('producer','PRODUCER_NOT_ADMITTED'),
    ('normal','PATCH_COVERAGE_DRIFT'),('knots','CURVE_DRIFT'),
    ('partial','METRIC_SCOPE_DRIFT'),('geometry','CURVE_INVALID')])
def test_calibration_repair_drift_rejected(tmp_path,damage,reason):
    point=_cr_point(); old=_cr_record(point); shared=tmp_path.resolve()/'shared'
    def mutate(component,value):
        if component!='spline': return
        if damage=='knots': value['curve']['fixed_logit_knots'][0]-=.1
        elif damage=='partial': value['metrics'].pop('e90')
        elif damage=='geometry': value['curve']['coefficients_in_scaled_natural_basis'].pop()
    patch=_cr_patch(point,old,shared=shared,damage=mutate)
    if damage=='original': old['tables']['PRIMARY/H06/MICRO']['APPARENT']['auc']=_cr_ok(.9)
    elif damage=='producer': patch['producer']={'run_identity':'x'*64,'source_identity':'y'*64}
    elif damage=='normal': patch['patches']['PRIMARY/H06/MICRO']={'APPARENT':{'citl':{}}}
    with pytest.raises(ContractError,match=reason):
        f4._evaluation_calibration_repair_merge(point,old,patch,generations=_EVAL_GENERATIONS,shared=shared)


@pytest.mark.parametrize('failed',[False,True])
def test_calibration_repair_resume_does_not_fit_or_rewrite_original(tmp_path,monkeypatch,failed):
    tmp_path=tmp_path.resolve(); point=_cr_point(failed=failed); old=_cr_record(point)
    original=tmp_path/'original'; root=tmp_path/'repair'; shared=tmp_path/'shared'
    (original/'replicates').mkdir(parents=True); (root/'patches').mkdir(parents=True)
    source=original/'replicates/B0001.zip'
    write_deterministic_zip(source,{'values.json':canonical_json_bytes(old)})
    before=source.read_bytes(),source.stat().st_mtime_ns
    if failed:
        (root/'patches/B0001.json').write_bytes(canonical_json_bytes(_cr_patch(point,old,shared=shared)))
    monkeypatch.setattr(f4,'_evaluation_binomial_fit',lambda *a,**kw:pytest.fail('retained fit repeated'))
    kw=dict(view=None,point=point,draws=[[0,1]],original_root=original,root=root,
        provenance=_CR_PROVENANCE,shared=shared,environment_lock_sha256=_CR_ENV)
    value=f4._evaluation_calibration_repair_job(1,**kw)
    assert value['actual_fit_calls_this_execution']==0
    assert value['member']==('patches/B0001.json' if failed else None)
    assert (source.read_bytes(),source.stat().st_mtime_ns)==before
    with pytest.raises(ContractError,match='DRAW_DRIFT'):
        f4._evaluation_calibration_repair_job(1,**{**kw,'draws':[[1,0]]})


def test_calibration_repair_leaf_single_owner_and_archive_resolution(tmp_path,monkeypatch):
    import io
    from concurrent.futures import ThreadPoolExecutor
    from padml import carriers
    shared=tmp_path.resolve()/'shared'; calls=[]
    args=('citl',[[1.],[1.],[1.]],[0.,1.,0.],[1.,1.,0.],[-2.,-1.,9.],[.1,.2,.999])
    binding=f4._evaluation_calibration_repair_leaf_binding(*args,environment_lock_sha256=_CR_ENV)
    def compute():
        calls.append(True)
        return {'metrics':{'citl':_cr_ok(.3)},'diagnostics':{'status':'ESTIMABLE','fixture':'UNFITTED'}}
    def work(_): return f4._evaluation_calibration_repair_leaf(shared,binding,compute,provenance=_CR_PROVENANCE)
    with ThreadPoolExecutor(max_workers=4) as pool: values=list(pool.map(work,range(12)))
    assert len(calls)==sum(v['actual_fit_calls_this_execution'] for v in values)==1
    ref=values[0]['reference']; assert all(v['reference']==ref for v in values)
    previous={**_CR_PROVENANCE,'producer':_EVAL_PREVIOUS_PRODUCER}
    again=f4._evaluation_calibration_repair_leaf(shared,binding,lambda:pytest.fail('duplicate callback'),provenance=previous)
    assert again['reference']==ref and again['actual_fit_calls_this_execution']==0
    changed=copy.deepcopy(args); changed[4][2]=8.
    assert f4._evaluation_calibration_repair_leaf_binding(*changed,environment_lock_sha256=_CR_ENV)!=binding
    changed=copy.deepcopy(args); changed[2][0],changed[2][1]=changed[2][1],changed[2][0]
    assert f4._evaluation_calibration_repair_leaf_binding(*changed,environment_lock_sha256=_CR_ENV)!=binding
    path=shared/(ref['numeric_leaf']+'.json'); raw=path.read_bytes()
    requested_pins=[]
    monkeypatch.setattr(carriers,'archive_source',lambda _,*,expected:
        requested_pins.append(expected) or io.BytesIO(raw))
    assert f4._evaluation_calibration_repair_leaf_value(ref,shared=shared/'retired',
        generations=_EVAL_GENERATIONS)==values[0]['value']
    assert requested_pins == [{k:ref[k] for k in ('sha256','size_bytes')}]
    assert {'path','producer','sha256','size_bytes'} <= ref.keys()
    monkeypatch.setattr(carriers,'archive_source',lambda _,*,expected:io.BytesIO(raw+b' '))
    with pytest.raises(ContractError,match='LEAF_PIN_DRIFT'):
        f4._evaluation_calibration_repair_leaf_value(ref,shared=shared,generations=_EVAL_GENERATIONS)
    bad=strict_json_bytes(raw); bad['producer']={'run_identity':'x'*64,'source_identity':'y'*64}
    raw=canonical_json_bytes(n._sealed({k:v for k,v in bad.items() if k!='identity_sha256'}))
    monkeypatch.setattr(carriers,'archive_source',lambda _,*,expected:io.BytesIO(raw))
    with pytest.raises(ContractError,match='PRODUCER_NOT_ADMITTED'):
        f4._evaluation_calibration_repair_leaf_value({**ref,'sha256':sha256_bytes(raw),'size_bytes':len(raw)},
            shared=shared,generations=_EVAL_GENERATIONS)


def test_calibration_repair_compute_deduplicates_across_point_units_and_B(tmp_path,monkeypatch):
    import numpy as np
    point=_cr_point(failed=False,macro=False); ids=[f'P{i:03d}' for i in range(60)]
    response=('Patient_ID,All_Cause_Death,Death_Followup_months\n'+''.join(
        f'{pid},{int(i<20)},{3 if i<20 else 40}\n' for i,pid in enumerate(ids))).encode()
    matrices={name:[[1.]+[1-(.1+i*.003)*h/36 for h in range(1,37)] for i in range(60)] for name in _CR_BASES}
    row=point['tables']['PRIMARY/H06/MICRO']; row.update(patient_order_sha256=n._sha(ids),centers=['36'])
    for metric in ('ici','e50','e90'): row['numbers']['APPARENT'][metric]=_cr_fail()
    row['curves']['APPARENT']=_cr_curve(False)
    other=copy.deepcopy(row);other['role']='SIX_CENTER_SENSITIVITY'
    point['tables']['SIX_CENTER_SENSITIVITY/H06/MICRO']=other
    point['fixed_calibration_knots']['SIX_CENTER_SENSITIVITY/H06/MICRO']=copy.deepcopy(
        point['fixed_calibration_knots']['PRIMARY/H06/MICRO'])
    view={'patient_ids':ids,'centers':['36']*60,'response_csv':response,'matrices':matrices}; calls=[]
    def unfitted(x,y,w,**kw):
        calls.append(x.shape)
        return {'status':'ESTIMABLE','coefficients':np.array([0.,1.,.2]),'gradient_max':0.}
    monkeypatch.setattr(f4,'_evaluation_binomial_fit',unfitted)
    monkeypatch.setattr(f4,'_evaluation_values',lambda *a,**kw:pytest.fail('normal metrics recomputed'))
    kw=dict(provenance=_CR_PROVENANCE,shared=tmp_path.resolve()/'shared',environment_lock_sha256=_CR_ENV)
    first=f4._evaluation_calibration_repair_compute(view,point,point,0,None,**kw)
    second=copy.deepcopy(point);second['source_identity']='other-qualified-source'
    reused=f4._evaluation_calibration_repair_compute(view,second,second,0,None,**kw)
    old=_cr_record(point);old['draw_sha256']=n._sha(list(range(60)))
    sampled=f4._evaluation_calibration_repair_compute(view,point,old,1,list(range(60)),**kw)
    assert calls==[(60,3)] and first['actual_fit_calls_at_patch_creation']==1
    assert reused['actual_fit_calls_at_patch_creation']==sampled['actual_fit_calls_at_patch_creation']==0
    assert first['patches']==reused['patches']==sampled['patches']


@pytest.mark.parametrize('interrupt',[False,True])
def test_calibration_repair_publish_resume_one_reduction_and_cold_qualification(tmp_path,monkeypatch,interrupt):
    import time
    from padml.carriers import source_pin
    point=f4._f45_optimism_json(canonical_json_bytes(_cr_point(failed=False,macro=False)))
    normal=_cr_record(point); bad=copy.deepcopy(normal)
    for metric in ('ici','e50','e90'):bad['tables']['PRIMARY/H06/MICRO']['APPARENT'][metric]=_cr_fail()
    bad['curves']['PRIMARY/H06/MICRO']['APPARENT']=_cr_curve(False)
    bad['tables']['PRIMARY/H06/MICRO']=f4._evaluation_contrasts({name:bad['tables']['PRIMARY/H06/MICRO'][name] for name in _CR_BASES})
    bad=n._sealed({k:v for k,v in bad.items() if k!='identity_sha256'})
    run={'run_root':str(tmp_path.resolve()),'post_result_repair':f4.post_result_repair_decision()}
    unit={'unit_id':'PRIMARY-H06-O1','kind':'PRIMARY','horizon':6}
    oldroot=f4.evaluation_appendix_root(run,unit); root=f4.evaluation_calibration_repair_root(run,unit)
    shared=f4._evaluation_calibration_repair_shared_root(run)
    oldroot.mkdir(parents=True);(root/'patches').mkdir(parents=True)
    real_open=f4.open_carrier; reads=[]
    @contextmanager
    def opener(path):
        if path.is_relative_to(oldroot) and path.name!='intervals.zip':
            def read(name):
                reads.append(path.name)
                if path.name=='point.zip':return canonical_json_bytes(point)
                b=int(path.stem[1:]);value=copy.deepcopy(bad if b==1 else normal);value['replicate']=b
                return canonical_json_bytes(n._sealed({k:v for k,v in value.items() if k!='identity_sha256'}))
            yield SimpleNamespace(read=read)
        else:
            with real_open(path) as carrier:yield carrier
    monkeypatch.setattr(f4,'open_carrier',opener)
    intervals,bands=f4._evaluation_reduce_replicates(oldroot,point,[[0,1]]*1000,generations=_EVAL_GENERATIONS)
    write_deterministic_zip(oldroot/'intervals.zip',{'intervals.json':canonical_json_bytes(intervals),
        'calibration-pointwise-bands.json':canonical_json_bytes(bands)})
    original=n._sealed({'kind':'PADML_EVALUATION_APPENDIX_V1','status':'COMPLETED','replicate_count':1000,
        'direct_consumer_completed':True,'development_horizon':6,'target_unit':unit['unit_id'],
        'decision_sha256':point['decision']['identity_sha256'],'producer':_EVAL_PREVIOUS_PRODUCER})
    (oldroot/'result.json').write_bytes(canonical_json_bytes(original));before=(oldroot/'result.json').read_bytes()
    patch=_cr_patch(point,bad,shared=shared);patchpath=root/'patches/B0001.json'
    patchpath.write_bytes(canonical_json_bytes(patch))
    effective=f4._evaluation_calibration_repair_merge(point,bad,patch,generations=_EVAL_GENERATIONS,shared=shared)
    completed=[{'replicate':b,'member':None,'metric_keys':[],'curve_keys':[],
        'leaves':{},'actual_fit_calls_this_execution':0,'propagated_component_coordinates':0} for b in range(1001)]
    completed[1]={'replicate':1,'member':'patches/B0001.json','pin':source_pin(patchpath),
        'metric_keys':effective['metric_keys'],'curve_keys':effective['curve_keys'],'leaves':effective['leaves'],
        'actual_fit_calls_this_execution':1,'propagated_component_coordinates':1}
    monkeypatch.setattr(f4,'_evaluation_appendix_read',lambda *a,**kw:original)
    monkeypatch.setattr(f4,'_evaluation_provenance',lambda *a:_CR_PROVENANCE)
    monkeypatch.setattr(f4,'_evaluation_binomial_fit',lambda *a,**kw:pytest.fail('publication called solver'))
    now=time.time_ns();monkeypatch.setattr(time,'time_ns',lambda:now+10_000_000_000)
    reads.clear()
    if interrupt:
        actual=n._write_exact_once
        def stop(path,raw,reason):
            if path==root/'result.json':raise RuntimeError('INTERRUPT_BEFORE_RESULT')
            return actual(path,raw,reason)
        monkeypatch.setattr(n,'_write_exact_once',stop)
        with pytest.raises(RuntimeError,match='INTERRUPT_BEFORE_RESULT'):
            f4._evaluation_calibration_repair_publish(run,unit,original,point,[[0,1]]*1000,completed)
        assert not (root/'result.json').exists() and not f4.evaluation_calibration_repair_observation(run,unit)
        preserved={name:(root/name).read_bytes() for name in ('metrics.csv','intervals.zip','patches/B0001.json')}
        monkeypatch.setattr(n,'_write_exact_once',actual)
        completed[1]['actual_fit_calls_this_execution']=0
        reads.clear()
    result=f4._evaluation_calibration_repair_publish(run,unit,original,point,[[0,1]]*1000,completed)
    assert reads==[f'B{b:04d}.zip' for b in range(1,1001)]
    assert result['summary']['unique_numeric_inputs']==result['summary']['completed_leaf_fit_calls']==1
    assert result['summary']['actual_fit_calls_this_dispatch']==(0 if interrupt else 1)
    assert result['summary']['propagated_component_coordinates']==1
    assert len(result['shared_members'])==1 and (oldroot/'result.json').read_bytes()==before
    if interrupt:assert all((root/name).read_bytes()==raw for name,raw in preserved.items())
    assert f4._evaluation_calibration_repair_read(run,unit,cached_only=True)==result
    assert len(reads)==1000
    (root/'result.qualified.json').unlink()
    assert f4._evaluation_calibration_repair_read(run,unit)==result and len(reads)==2001
    leaf=shared/(next(iter(effective['leaves']))+'.json');leaf.write_bytes(leaf.read_bytes()+b' ')
    assert f4._evaluation_calibration_repair_read(run,unit,cached_only=True) is None
    with pytest.raises(ContractError,match='RAW_QUALIFIED_BYTES_DRIFT'):
        f4._evaluation_calibration_repair_read(run,unit)
    assert len(reads)==2001


def test_calibration_repair_original_draw_guard_precedes_override(monkeypatch):
    point,reads,_=_evaluation_curve_reduce_fixture(monkeypatch,bad_metric=None,bad_curve=None)
    actual=f4.open_carrier;calls=[]
    @contextmanager
    def reader(path):
        with actual(path) as carrier:
            old=strict_json_bytes(carrier.read('values.json'))
        if int(path.stem[1:])==2:old['draw_sha256']='0'*64
        yield SimpleNamespace(read=lambda _:canonical_json_bytes(n._sealed({k:v for k,v in old.items() if k!='identity_sha256'})))
    monkeypatch.setattr(f4,'open_carrier',reader)
    def override(b,old):calls.append(b);return old['tables'],old['curves']
    with pytest.raises(ContractError,match='BOOTSTRAP_SOURCE_OR_DRAW_DRIFT'):
        f4._evaluation_reduce_replicates(Path('/virtual-only'),point,[[0,1,1]]*1000,
            generations={'b'*64:'c'*64},repair_override=override)
    assert calls==[1] and reads==[1,2]


@pytest.mark.parametrize('failed_draws', [0, 7])
def test_calibration_repair_wrapper_uses_real_lock_field_and_one_admitted_pool(tmp_path,monkeypatch,failed_draws):
    point=f4._f45_optimism_json(canonical_json_bytes(_cr_point(failed=False,macro=False)))
    run,unit=_evaluation_producer_run_fixture(tmp_path.resolve())
    unit.update(unit_id='PRIMARY-H06-O1',kind='PRIMARY',horizon=6)
    run.update(post_result_repair=f4.post_result_repair_decision(),environment={
        'python':'/opt/padml/runtime/py-env/bin/python','rscript':'/opt/padml/runtime/r-env/bin/Rscript',
        'r_library':'/opt/padml/runtime/r-library','artifact_paths':{},'lock_sha256':_CR_ENV})
    run['resource_policy']={'configured_worker_ceiling':runtime.CPU_MINUS_8,
        'memory_bytes_per_worker':1024**3,'scratch_bytes_per_worker':1024,
        'memory_reserve_bytes':0,'scratch_reserve_bytes':0,'transfer_archive_worker_ceiling':3}
    old=f4.evaluation_appendix_root(run,unit);old.mkdir(parents=True)
    original=n._sealed({'kind':'PADML_EVALUATION_APPENDIX_V1','status':'COMPLETED','replicate_count':1000,
        'direct_consumer_completed':True,'development_horizon':6,'target_unit':unit['unit_id'],
        'decision_sha256':point['decision']['identity_sha256'],'producer':_EVAL_PREVIOUS_PRODUCER,
        'members':{'metrics.csv':{'size_bytes':100},'intervals.zip':{'size_bytes':100}}})
    (old/'result.json').write_bytes(canonical_json_bytes(original))
    write_deterministic_zip(old/'point.zip',{'point.json':canonical_json_bytes(point)})
    flat=f4._evaluation_flatten({k:f4._evaluation_contrasts(copy.deepcopy(t['numbers'])) for k,t in point['tables'].items()})
    intervals={k:{'failure_counts':{}} for k in flat}
    failure_key=next(k for k in flat if k.endswith('|citl'))
    intervals[failure_key]['failure_counts']={'BINOMIAL_MLE_DID_NOT_CONVERGE':failed_draws}
    write_deterministic_zip(old/'intervals.zip',{'intervals.json':canonical_json_bytes(intervals)})
    admitted=[];jobs=[]
    real_admit=runtime.admit_stage
    def admit(*a,**kw):
        admitted.append(kw)
        return real_admit(*a,**kw,_observation={'effective_cpus':11,
            'available_memory_bytes':60*1024**3,'scratch_available_bytes':100*1024**3,
            'scratch_root':str(tmp_path)})
    def ordered(job,ids,**kw):
        assert ids==list(range(1001)) and kw['selected_slots']==3
        assert job.func is f4._evaluation_calibration_repair_job and job.reuse_worker_function is True
        assert job.keywords['environment_lock_sha256']==_CR_ENV
        assert job.keywords['shared']==f4._evaluation_calibration_repair_shared_root(run)
        jobs.append(job);return [{'replicate':b} for b in ids]
    monkeypatch.setattr(f4,'_evaluation_appendix_read',lambda *a,**kw:original)
    monkeypatch.setattr(f4,'_evaluation_calibration_repair_read',lambda *a,**kw:None)
    monkeypatch.setattr(f4,'_evaluation_provenance',lambda *a:_CR_PROVENANCE)
    monkeypatch.setattr(runtime,'admit_stage',admit)
    monkeypatch.setattr(runtime,'run_ready_families',lambda families,**kw:[fn() for fn in families])
    monkeypatch.setattr(f4,'_bounded_ordered_spawn',ordered)
    monkeypatch.setattr(f4,'_evaluation_calibration_repair_publish',lambda *a,**kw:{'summary':{'fixture':'UNFITTED'}})
    view={'patient_ids':['p1','p2'],'matrices':{'APPARENT':[]}}
    assert f4.run_evaluation_calibration_repair(run,unit,view,point,[[0,1]]*1000,original)['summary']=={'fixture':'UNFITTED'}
    assert len(admitted)==len(jobs)==1 and admitted[0]['retained_bytes']==1001*1024+failed_draws*16*1024
    assert admitted[0].get('task_disk_bytes') is None
    assert admitted[0]['memory_bytes_per_worker']>=f4.MIN_WORKER_MEMORY_BYTES
    with pytest.raises(ContractError,match='NOT_AUTHORIZED'):
        f4.run_evaluation_calibration_repair({**run,'post_result_repair':None},unit,None,point,[],original)
    assert len(admitted)==1


def test_registered_simulation_uses_real_admission_before_any_dataset(tmp_path,monkeypatch):
    run,unit=_evaluation_producer_run_fixture(tmp_path.resolve())
    unit.update(unit_id='PRIMARY-H06-O1',kind='PRIMARY',horizon=6,outer_fold=1)
    run.update(post_result_repair=f4.post_result_repair_decision(),resource_policy={
        'configured_worker_ceiling':runtime.CPU_MINUS_8,'memory_bytes_per_worker':1024**3,
        'scratch_bytes_per_worker':1024,'memory_reserve_bytes':0,'scratch_reserve_bytes':0,
        'transfer_archive_worker_ceiling':3})
    admitted=[];real_admit=runtime.admit_stage
    def admit(*a,**kw):
        admitted.append(kw)
        return real_admit(*a,**kw,_observation={'effective_cpus':11,
            'available_memory_bytes':60*1024**3,'scratch_available_bytes':100*1024**3,
            'scratch_root':str(tmp_path)})
    def ordered(job,tasks,**kw):
        assert len(tasks)==2000 and kw['selected_slots']==3
        assert job.func is f4._evaluation_simulation_saved_job
        raise RuntimeError('ADMITTED_NO_DATASET_EVALUATED')
    monkeypatch.setattr(f4,'_evaluation_perturbation_simulation_coordinates',
        lambda scenario:({'dataset_replication':b} for b in range(1,2001)))
    monkeypatch.setattr(f4,'_evaluation_provenance',lambda *a:_CR_PROVENANCE)
    monkeypatch.setattr(runtime,'admit_stage',admit)
    monkeypatch.setattr(runtime,'run_ready_families',lambda families,**kw:[fn() for fn in families])
    monkeypatch.setattr(f4,'_bounded_ordered_spawn',ordered)
    with pytest.raises(RuntimeError,match='ADMITTED_NO_DATASET_EVALUATED'):
        f4.run_evaluation_simulation(run,unit)
    assert len(admitted)==1
    assert admitted[0]['publication_bytes']==max(p for _,p in admitted[0]['task_disk_bytes'])==8*1024**2


@pytest.mark.parametrize('damage,reason',[(None,None),('missing','REFERENCE_MISSING'),
    ('pin','RAW_QUALIFIED_BYTES_DRIFT'),('unknown','PRODUCER_NOT_ADMITTED'),
    ('scope','CALIBRATION_SHARED_SCOPE_INVALID')])
def test_calibration_repair_archive_follows_result_patch_leaf_and_summaries(tmp_path,monkeypatch,damage,reason):
    from padml import carriers,reports
    base=tmp_path.resolve(); shared=base/'shared/evaluation-calibration-20261008'
    root=base/'units/PRIMARY-H06-O1/postprocess/post-result-repair-20261008/calibration'
    (root/'patches').mkdir(parents=True)
    run={'kind':'PADML_INTEGRATED_RAW_RUN_V1','run_root':str(base),'units':[],
        'identity':_EVAL_CURRENT_PRODUCER['run_identity'],'source_identity':_EVAL_CURRENT_PRODUCER['source_identity']}
    binding=f4._evaluation_calibration_repair_leaf_binding('citl',[[1.],[1.]],[0.,1.],[1.,1.],
        None,[.1,.2],environment_lock_sha256=_CR_ENV)
    leaf=f4._evaluation_calibration_repair_leaf(shared,binding,
        lambda:{'metrics':{'citl':_cr_ok(.1)},'diagnostics':{'fixture':'UNFITTED'}},provenance=_CR_PROVENANCE)
    patch={'patches':{'PRIMARY/H06/36':{'APPARENT':{'citl':leaf['reference']}}}}
    (root/'patches/B0001.json').write_bytes(canonical_json_bytes(patch))
    (root/'metrics.csv').write_bytes(b'metric,value\ncitl,0.1\n')
    write_deterministic_zip(root/'intervals.zip',{'intervals.json':b'{}\n'})
    members={name:carriers.source_pin(root/name) for name in ('metrics.csv','intervals.zip','patches/B0001.json')}
    ref=leaf['reference'];leaf_pin={k:ref[k] for k in ('sha256','size_bytes')}
    final=n._sealed({'kind':'PADML_CALIBRATION_REPAIR_APPENDIX_20261008_V1','status':'COMPLETED',
        'direct_consumer_completed':True,'replicate_count':1000,'producer':_EVAL_CURRENT_PRODUCER,
        'members':members,'shared_members':{ref['path']:leaf_pin}})
    if damage=='missing':(root/'metrics.csv').unlink()
    elif damage=='pin':(base/ref['path']).write_bytes((base/ref['path']).read_bytes()+b' ')
    elif damage=='unknown':final['producer']={'run_identity':'x'*64,'source_identity':'y'*64}
    elif damage=='scope':final['shared_members']={'shared/unrelated.json':leaf_pin}
    final=n._sealed({k:v for k,v in final.items() if k!='identity_sha256'})
    path=root/'result.json';path.write_bytes(canonical_json_bytes(final))
    monkeypatch.setattr(reports,'same_batch_generations',lambda *_:_EVAL_GENERATIONS)
    monkeypatch.setattr(reports,'_archive_appendix_pins',lambda *a:{path.relative_to(base).as_posix():carriers.source_pin(path)})
    if reason:
        with pytest.raises(ContractError,match=reason):reports.archive_inventory(run,6,[],[])
    else:
        value=reports.archive_inventory(run,6,[],[])
        assert {path.relative_to(base).as_posix(),ref['path'],*(str((root/name).relative_to(base)) for name in members)} <= set(value['members'])
        assert all(not name.endswith('.lock') and 'qualified' not in name for name in value['members'])


# UNFITTED completed-head admission; no native MICE, prediction or P is run.
_COMPLETED_CURRENT={'run_identity':'1'*64,'source_identity':'2'*64}
_COMPLETED_PREVIOUS={'run_identity':'3'*64,'source_identity':'4'*64}
_COMPLETED_UNKNOWN={'run_identity':'f'*64,'source_identity':'e'*64}
_COMPLETED_GENERATIONS={_COMPLETED_CURRENT['run_identity']:_COMPLETED_CURRENT['source_identity'],_COMPLETED_PREVIOUS['run_identity']:_COMPLETED_PREVIOUS['source_identity']}


def _completed_reference_boundary(monkeypatch):
    from padml import f4, f5_application as app, nested_loco as n, integrated, carriers
    from padml.bundle import sha256_file
    monkeypatch.setattr(integrated,'same_batch_generations',lambda *a:_COMPLETED_GENERATIONS)
    monkeypatch.setattr(f4,'_evaluation_provenance',lambda *a:{'producer':_COMPLETED_CURRENT,'generations':_COMPLETED_GENERATIONS})
    monkeypatch.setattr(carriers,'validate_reference',lambda ref,run: (
        None if sha256_file(Path(ref['path']))==ref['sha256'] else pytest.fail('reference drift')))

@pytest.mark.parametrize('producer,accepted',[(_COMPLETED_CURRENT,True),(_COMPLETED_PREVIOUS,True),(_COMPLETED_UNKNOWN,False)])
def test_completed_exp1_exact_producer_is_required_before_reuse(tmp_path,monkeypatch,producer,accepted):
    from padml import f4, f5_application as app, nested_loco as n, integrated, carriers
    from padml.bundle import sha256_file
    _completed_reference_boundary(monkeypatch)
    run={'run_root':str(tmp_path),'identity':_COMPLETED_CURRENT['run_identity'],'source_identity':_COMPLETED_CURRENT['source_identity'],
         'post_result_repair':f4.post_result_repair_decision()}
    unit={'unit_id':'FULL0-H12','kind':'FULL0','horizon':12}
    original={'identity_sha256':'9'*64,'sources':{}}
    identity={'fixture':'QUALIFIED_ORIGINAL_CONTEXT'}
    point={'kind':'PADML_EVALUATION_POINT_V2','source_identity':n._sha(identity)}
    monkeypatch.setattr(f4,'_evaluation_appendix_identity',lambda *a,**k:identity)
    monkeypatch.setattr(f4,'evaluation_appendix_root',lambda *a:tmp_path/'original')
    def forbidden(*a,**kw): pytest.fail('completed head cannot start a new perturbation or universe load')
    monkeypatch.setattr(integrated,'load_raw_binding',forbidden)
    monkeypatch.setattr(f4,'_evaluation_perturbation_prepare',forbidden)
    root=tmp_path/'units'/unit['unit_id']/'post-result-repair-20261008/auc-exp1';root.mkdir(parents=True)
    source=tmp_path/'retained-values';source.write_bytes(b'UNFITTED_RETAINED_FORMAL_REFERENCE\n')
    result=n._sealed({'kind':'PADML_FIXED_PREDICTION_AUC_EXP1_20261008_V1',
        'decision_sha256':run['post_result_repair']['identity_sha256'],
        'source_unit':unit['unit_id'],'original_result_identity':original['identity_sha256'],
        'original_point_sha256':n._sha(point),'producer':producer,'status':'COMPLETED',
        'P_ids':list(range(1,2000)),'coordinate_count':1,'point_estimable_count':1,'complete_vectors':1,
        'reliability_status':'REQUIRES_REGISTERED_COVERAGE_VALIDATION',
        'formal_references':[{'path':str(source),'sha256':sha256_file(source)}]})
    path=root/'result.json';path.write_bytes(canonical_json_bytes(result));saved=path.read_bytes()
    if accepted: assert f4.run_evaluation_perturbation(run,unit,{},point,original_result=original)==result
    else:
        with pytest.raises(ContractError,match='EVALUATION_PRODUCER_NOT_ADMITTED'):
            f4.run_evaluation_perturbation(run,unit,{},point,original_result=original)
    assert path.read_bytes()==saved


# Unfitted storage/recovery boundaries only. No native engine is reachable.
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from padml import f5_a04_current as a04, f5_sensitivity as a04_sensitivity, f4 as a04_f4
from padml.bundle import ContractError, canonical_json_bytes, sha256_bytes


class TestCurrentA04ConsumedRetirement(unittest.TestCase):
    def fit_fixture(self, base):
        root=base/'fit';root.mkdir()
        entries={'task.json':canonical_json_bytes({'UNFITTED':True}), 'application.csv':b'UNFITTED\n'}
        model,baseline=b'original-model',b'original-baseline'
        prediction={'survival':[[.7,.6]], 'UNFITTED':True}
        numbers={'input_members':{name:{'sha256':sha256_bytes(raw),'size_bytes':len(raw)} for name,raw in entries.items()},
            'prediction':prediction,'training_prediction':{'survival':[[.8,.7]]},'fit_health':{'UNFITTED':'health'},
            'model_sha256':sha256_bytes(model),'baseline_sha256':sha256_bytes(baseline),
            'native_archive':{'sha256':sha256_bytes(b'qualified-archive'),'size_bytes':17}}
        raw_members={**entries,'model.bin':model,'baseline.bin':baseline,
            'fit-health.json':canonical_json_bytes(numbers['fit_health']),
            'training-prediction.json':canonical_json_bytes(numbers['training_prediction']['survival']),
            'prediction.json':canonical_json_bytes(prediction)}
        for name,raw in raw_members.items():(root/name).write_bytes(raw)
        archive=root.with_suffix('.zip');archive.write_bytes(b'qualified-archive')
        result=root.with_suffix('.numbers.json');result.write_bytes(canonical_json_bytes(numbers))
        unknown=root/'native-failure.json';unknown.write_bytes(b'protected-original-failure')
        return {'root':str(root),'entries':entries,'record_execution':True},numbers,raw_members,unknown

    def run_fit(self, job, numbers):
        with patch.object(a04,'_a04_replay_numbers',return_value=numbers['prediction']), \
                patch.object(a04_sensitivity,'_execute_ablation_component',side_effect=AssertionError('FIT')), \
                patch.object(a04_sensitivity,'_replay_ablation_component',side_effect=AssertionError('NATIVE_REPLAY')):
            return a04._a04_current_fit_job(job)

    def test_completed_numbers_retire_consumed_members_and_keep_unknown(self):
        with tempfile.TemporaryDirectory() as temp:
            job,numbers,raw_members,unknown=self.fit_fixture(Path(temp).resolve())
            original=Path(job['root']).with_suffix('.numbers.json').read_bytes()
            self.assertEqual(self.run_fit(job,numbers),{'row':numbers['prediction'],'actual_new_model_fits_this_invocation':0})
            self.assertTrue(all(not (Path(job['root'])/name).exists() for name in raw_members))
            self.assertFalse(Path(job['root']).with_suffix('.zip').exists())
            self.assertEqual(unknown.read_bytes(),b'protected-original-failure')
            self.assertEqual(Path(job['root']).with_suffix('.numbers.json').read_bytes(),original)
            self.assertEqual(self.run_fit(job,numbers)['actual_new_model_fits_this_invocation'],0)

    def test_model_retirement_interruption_after_one_unlink_resumes_zero_fit(self):
        with tempfile.TemporaryDirectory() as temp:
            job,numbers,raw_members,unknown=self.fit_fixture(Path(temp).resolve())
            def interrupted(root, members, **kw):
                next(path for path in members if path.is_file()).unlink()
                raise RuntimeError('after-one-unlink')
            with patch.object(a04_sensitivity,'_retire_a12_member_copies',side_effect=interrupted):
                with self.assertRaisesRegex(RuntimeError,'after-one-unlink'):self.run_fit(job,numbers)
            self.assertEqual(self.run_fit(job,numbers)['actual_new_model_fits_this_invocation'],0)
            self.assertTrue(all(not (Path(job['root'])/name).exists() for name in raw_members))
            self.assertEqual(unknown.read_bytes(),b'protected-original-failure')

    def test_changed_model_pin_is_rejected_without_deleting_it(self):
        with tempfile.TemporaryDirectory() as temp:
            job,numbers,_,unknown=self.fit_fixture(Path(temp).resolve())
            model=Path(job['root'])/'model.bin';model.write_bytes(b'changed-model')
            with self.assertRaisesRegex(ContractError,'RETIREMENT_MEMBER_DRIFT'):self.run_fit(job,numbers)
            self.assertEqual(model.read_bytes(),b'changed-model')
            self.assertTrue(Path(job['root']).with_suffix('.numbers.json').is_file())
            self.assertTrue(unknown.is_file())

    def p2_fixture(self, base, *, with_pins=True):
        source={'UNFITTED':'original-source'}
        current={'source':source,'run':{'identity':'a'*64,'source_identity':'b'*64,
            'resource_policy':{},'budgets':{}}}
        producer={'run_identity':'a'*64,'source_identity':'b'*64}
        residues=[];heads=[]
        for component in a04.k.F2_COMPONENTS:
            folder=base/component;folder.mkdir()
            task={'task_id':'unfitted-'+component};key=a04.sha(task)
            native=folder/(key+'-native');native.mkdir()
            atom=a04.sha(task['task_id'])
            paths={native/(atom+'.json'):b'qualified atomic numbers',
                native/(atom+'-input.json'):b'qualified original input'}
            engine=folder/key/('f2-r-batch-'+a04.sha([task['task_id']])[:16]);engine.mkdir(parents=True)
            paths.update({engine/'spec.json':b'qualified original spec',engine/'output.json':b'qualified original output'})
            for path,raw in paths.items():path.write_bytes(raw)
            registry={'kind':'PADML_A04_CURRENT_PRIMARY_P2C2T_REGISTRY_V1','source_locks':[source],'tasks':[task]}
            registry['registry_sha256']=a04.sha(registry)
            (folder/'registry.json').write_bytes(canonical_json_bytes(registry))
            saved={'kind':'PADML_A04_CURRENT_P2C2T_NUMBERS_V1','source':source,'producer':producer,
                'contract_task':task,'value':{'task_contract_sha256':key,'status':'PASS',
                'expected_fit_count':1,'executed_fit_count':1}}
            if with_pins:saved['consumed_member_pins']={p.relative_to(folder).as_posix():
                {'sha256':sha256_bytes(raw),'size_bytes':len(raw)} for p,raw in paths.items()}
            saved=a04._sealed(saved);target=folder/(key+'.json')
            target.write_bytes(canonical_json_bytes(saved));heads.append((folder,target,saved))
            residues.extend(paths)
        return current,residues,heads

    def run_completed(self,current,root):
        with patch.object(a04_f4,'_evaluation_provenance',return_value={
                'producer':{'run_identity':'a'*64,'source_identity':'b'*64},'generations':{'a'*64:'b'*64}}), \
                patch.object(a04,'prepare_current_center_assets',side_effect=AssertionError('PREPARE')), \
                patch.object(a04.k,'_run_p2c2t_atomic_window',side_effect=AssertionError('FIT')):
            return a04.execute_current_p2c2t(current,root)

    def test_completed_p2_top_retirement_before_any_preparation(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp).resolve();current,residues,heads=self.p2_fixture(root)
            before={target:target.read_bytes() for _,target,_ in heads}
            result,count=self.run_completed(current,root)
            self.assertEqual(count,0);self.assertEqual(set(result),set(a04.k.F2_COMPONENTS))
            self.assertTrue(all(not path.exists() for path in residues))
            self.assertEqual({p:p.read_bytes() for p in before},before)
            self.assertEqual(self.run_completed(current,root),(result,0))

    def test_completed_p2_top_partial_retirement_is_idempotent(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp).resolve();current,residues,heads=self.p2_fixture(root)
            original=heads[0][1].read_bytes()
            def interrupted(root,members,**kw):
                next(p for p in members if p.is_file()).unlink()
                raise RuntimeError('after-one-unlink')
            with patch.object(a04_sensitivity,'_retire_a12_member_copies',side_effect=interrupted):
                with self.assertRaisesRegex(RuntimeError,'after-one-unlink'):self.run_completed(current,root)
            self.assertEqual(self.run_completed(current,root)[1],0)
            self.assertTrue(all(not p.exists() for p in residues))
            self.assertEqual(heads[0][1].read_bytes(),original)

    def test_p2_completed_bad_member_stops_without_refit(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp).resolve();current,residues,heads=self.p2_fixture(root)
            changed=residues[0];changed.write_bytes(b'changed original atomic')
            with self.assertRaisesRegex(ContractError,'RETIREMENT_MEMBER_DRIFT'):self.run_completed(current,root)
            self.assertEqual(changed.read_bytes(),b'changed original atomic')
            self.assertTrue(heads[0][1].is_file())

    def test_p2_header_cannot_retire_another_task_or_parent(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp).resolve();current,residues,heads=self.p2_fixture(root)
            folder,target,saved=heads[0]
            protected=root/'outside.json';protected.write_bytes(b'protected')
            saved['consumed_member_pins']={'../outside.json':{'sha256':sha256_bytes(b'protected'),'size_bytes':9}}
            target.write_bytes(canonical_json_bytes(a04._sealed({k:v for k,v in saved.items() if k!='identity_sha256'})))
            with self.assertRaises(ContractError):self.run_completed(current,root)
            self.assertEqual(protected.read_bytes(),b'protected')
            self.assertTrue(all(p.is_file() for p in residues))

    def test_legacy_completed_p2_with_unpinned_residue_is_preserved(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp).resolve();current,residues,_=self.p2_fixture(root,with_pins=False)
            with self.assertRaisesRegex(ContractError,'RETIREMENT_PROOF_MISSING'):self.run_completed(current,root)
            self.assertTrue(all(p.is_file() for p in residues))

    def test_new_top_records_only_actual_plan_members_before_retirement(self):
        with tempfile.TemporaryDirectory() as temp:
            folder=Path(temp).resolve();task={'task_id':'unfitted'};key=a04.sha(task)
            retained=folder/(key+'-native');retained.mkdir()
            atom='unfitted::M01';atomic=retained/(a04.sha(atom)+'.json');atomic.write_bytes(b'qualified numbers')
            native=folder/key/('f2-r-batch-'+a04.sha([atom])[:16]);native.mkdir(parents=True)
            (native/'spec.json').write_bytes(b'qualified spec');(native/'output.json').write_bytes(b'qualified output')
            unknown=native/'original-failure.json';unknown.write_bytes(b'protected')
            plan={'jobs':[{'route':'R','atomic_task_id':atom,'scratch':str(folder/key)}]}
            pins=a04._a04_p2_consumed_member_pins(plan,folder,retained)
            self.assertEqual(set(pins),{p.relative_to(folder).as_posix() for p in (
                atomic,native/'spec.json',native/'output.json')})
            saved={'contract_task':task,'value':{'executed_fit_count':1},'consumed_member_pins':pins}
            a04._a04_p2_retire_consumed(folder,saved)
            self.assertTrue(unknown.is_file());self.assertFalse(atomic.exists())
            self.assertFalse((native/'spec.json').exists());self.assertFalse((native/'output.json').exists())


# UNFITTED preparation-space rejection must precede numerical-view or ZIP writes.
@pytest.mark.parametrize('completed',[False,True])
def test_p2_preparation_is_admitted_before_original_csv_expansion(tmp_path,monkeypatch,completed):
    from padml import f5_a04_current as a,f5_mice_variants as v,runtime,f4,f2,_science_authority
    current={'source':{'UNFITTED':True},'frozen':{},'lock':{'outer_fold':1},
             'run':{'resource_policy':{'memory_bytes_per_worker':1024**3},
                    'budgets':{'retained_bytes_per_view':4*1024**3}}}
    monkeypatch.setattr(_science_authority,'load_science_authority',lambda:{'science':{'f2_model_development':{'p2c2t_contract':{}}}})
    monkeypatch.setattr(a.k,'predictor_contract',lambda *_:{})
    monkeypatch.setattr(f2,'compile_f2_units',lambda:[{'seed':i} for i in range(45)])
    monkeypatch.setattr(a,'_a04_p2_completed',lambda *args:{'UNFITTED_COMPLETE':True} if completed else None)
    monkeypatch.setattr(f4,'_evaluation_provenance',lambda *_:{'producer':{},'generations':{}})
    calls=[]
    def blocked(policy,root,**kw):calls.append(kw);raise OSError('UNFITTED_SPACE_REJECTED')
    monkeypatch.setattr(runtime,'admit_stage',blocked)
    monkeypatch.setattr(v,'_original_outer',lambda *args:pytest.fail('CSV expansion occurred before preparation admission'))
    root=tmp_path/'p2'
    if completed:
        assert a.execute_current_p2c2t(current,root)==({'UNFITTED_COMPLETE':True},0)
        assert calls==[]
    else:
        with pytest.raises(OSError,match='UNFITTED_SPACE_REJECTED'):a.execute_current_p2c2t(current,root)
        assert len(calls)==1 and calls[0]['retained_bytes']==4*1024**3
    assert list(root.iterdir())==[root/'input.json']
