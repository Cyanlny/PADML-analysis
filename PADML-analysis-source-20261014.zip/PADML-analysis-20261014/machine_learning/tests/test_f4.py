from __future__ import annotations

import copy
import json
import math
import shutil
import subprocess
from collections import Counter
from decimal import Decimal
from fractions import Fraction
from pathlib import Path

import pytest


@pytest.fixture(autouse=True)
def synthetic_host_capacity(monkeypatch):
    monkeypatch.setattr("padml.runtime.effective_cpu_count", lambda: 64)

from padml._science_authority import load_science_authority
from padml.bundle import ContractError, canonical_json_bytes, read_safe_zip, sha256_bytes, sha256_file, strict_json_bytes, write_deterministic_zip
from padml.f2 import canonical_unit_ids, materialize_requests
from padml.f2_kernel import (
    _center_stratified_evaluation_context, _evaluate_prediction_seal,
    _response_rows, _seal_prediction_matrix, _write_response_subset,
)
from padml.f4 import (
    BOOTSTRAP_ROOTS, DCA_THRESHOLDS, F45_SOURCE_MEMBERS, HORIZONS,
    PROSPECTIVE_PROTOCOL_REVISION,
    REPORT_HORIZONS, FULL_PIPELINE_CENTER_ORDER, PATIENT_KEY_RULE, _patient_key_mapping,
    bootstrap_draws, censoring_context, collect_predictions, native_metrics,
    a15_fixed_ooc_matrix_loco, decision_curve, evaluate_predictions, execute,
    evaluate_f4_suite, fixed_model_paired_bootstrap, materialize_resampled_view,
    prediction_error, post_selection_bootstrap, seal_f4_selection_capability,
    select_a15, audit_f45_result_blind_replay,
    compile_f45_execution_contract_seal,
    compile_f45_source_bundle, compile_full_pipeline_bootstrap_plan,
    compile_full_pipeline_bootstrap_plan_bundle,
    load_f45_source_bundle, validate_full_pipeline_bootstrap_plan,
    derive_f4_selection_capabilities, seal_f4_locked_family_handoff,
    reduce_full_pipeline_bootstrap_completion, reduce_o_fit_triggers,
    reduce_post_selection_optimism_trigger, reduce_registered_learning_curve,
    resolve_f4_final_family_lock,
    validate_f45_execution_contract_seal,
    _full_pipeline_bootstrap_status,
    _macro_bootstrap_metrics, _micro_metrics,
    f45_candidate_protocol_amendment_20260905,
)


def bootstrap_population() -> tuple[list[str], list[str]]:
    centers = [
        str(value) for value in
        load_science_authority()["science"]["population"]["validation_centers"]
    ]
    return (
        [f"源ID-{index:04d}" for index in range(1, 25)],
        [center for center in centers for _ in range(4)],
    )


def test_retained_prepared_primary_input_uses_original_producer(tmp_path, monkeypatch):
    """Reuse the already-produced synthetic input; never compile it again."""
    import os
    import zipfile
    from padml import f4, f5
    fixture = os.environ.get("PADML_RETAINED_PRIMARY_SYNTHETIC_ROOT")
    if fixture is None:
        pytest.skip("requires the preserved synthetic pre-search fixture")
    fixture = Path(fixture)
    source, producer = fixture / "scoped-q-worker.zip", fixture / "pre-search-producer.zip"
    with zipfile.ZipFile(source) as archive:
        record = strict_json_bytes(archive.read("prepared-q.json"))
    source_members = f4._retained_primary_input_source_members(producer, prepared_q=True)
    assert record["source_identity"] == sha256_bytes(canonical_json_bytes(source_members))
    assert source_members != f4._f45_source_member_sha256()

    entries = read_safe_zip(producer, expected_members={"manifest.json", *f4.F45_SOURCE_MEMBERS})
    def republish(label, updates):
        revised = {**entries, **updates}
        body = strict_json_bytes(revised["manifest.json"])
        body.pop("identity_sha256")
        body["members"] = [{"path": name, "sha256": sha256_bytes(revised[name]),
                            "size_bytes": len(revised[name])} for name in f4.F45_SOURCE_MEMBERS]
        revised["manifest.json"] = canonical_json_bytes({**body,
            "identity_sha256": sha256_bytes(canonical_json_bytes(body))})
        destination = tmp_path / (label + ".zip")
        write_deterministic_zip(destination, revised)
        return destination

    documented = republish("different-producer", {"NESTED_LOCO_PROTOCOL.md":
        entries["NESTED_LOCO_PROTOCOL.md"] + b"\nUnrelated documentation change.\n"})
    f4._retained_primary_input_source_members(documented, prepared_q=True)
    changed = republish("changed-numerical-kernel", {"padml/kernels/f2_model_development.R":
        entries["padml/kernels/f2_model_development.R"].replace(b'"breslow"', b'"efron"', 1)})
    assert sha256_file(changed) != sha256_file(producer)
    with pytest.raises(ContractError, match="NUMERICAL_SOURCE_DRIFT"):
        f4._retained_primary_input_source_members(changed, prepared_q=True)

    def forbidden(*args, **kwargs):
        pytest.fail("RETAINED_PREPARATION_MUST_NOT_COMPILE_OR_FIT")
    monkeypatch.setattr(f4, "compile_o_fit_bundle", forbidden)
    monkeypatch.setattr(f5, "_execute_q_search_batch", forbidden)
    kwargs = dict(prepared_q_input=source, prepared_q_input_sha256=sha256_file(source),
        task_ids=record["task_ids"], retained_bytes_per_task=67108864,
        selection_horizon_months=12, candidate_family="COXTIME_SET_A",
        primary_outer_prepared=True, prepare_only=True)
    with pytest.raises(ContractError, match="PREPARED_STOP_INPUT_INVALID"):
        f5.execute_final_complex_search(**kwargs, prepared_source_bundle=documented,
            target=tmp_path / "wrong-producer", batch_root=tmp_path / "wrong-unstarted-batch")
    assert not (tmp_path / "wrong-producer").exists()
    result = f5.execute_final_complex_search(**kwargs, prepared_source_bundle=producer,
        target=tmp_path / "retained-reader", batch_root=tmp_path / "unstarted-batch")
    assert result["status"] == "PREPARED_Q_BATCH" and result["stage_acceptance"] is False
    assert result["task_ids"] == record["task_ids"] and result["phase"] == record["phase"]
    assert result["new_model_fits"] == result["new_stop_fits"] == result["new_first_native_audits"] == 0
    assert not (tmp_path / "unstarted-batch").exists()
    assert not list((tmp_path / "retained-reader/native").iterdir())


def test_retained_primary1513_mice_gather_scientific_closure(monkeypatch):
    """Original code archive only; MICE/native/clinical readers are not run."""
    import os
    from padml import f4

    location = os.environ.get("PADML_RETAINED_PRIMARY1513_SOURCE")
    if location is None:
        pytest.skip("requires the retained PRIMARY1513 source archive")
    source = Path(location)
    members = f4._retained_full0_source_members(source, aar_mice_gather=True)
    assert sha256_bytes(canonical_json_bytes(members)) == (
        "1513ecba963857099c6b99413b8e976393c551a3ec30ed90da1cb14178338bd7")
    current = f4._f45_source_member_sha256()
    with monkeypatch.context() as documentation:
        documentation.setattr(f4, "_f45_source_member_sha256", lambda: {
            **current, "NESTED_LOCO_PROTOCOL.md": "0" * 64})
        assert f4._retained_full0_source_members(source, aar_mice_gather=True) == members
    with monkeypatch.context() as changed_kernel:
        changed_kernel.setattr(f4, "_f45_source_member_sha256", lambda: {
            **current, "padml/kernels/f5_a12_mice.R": "0" * 64})
        with pytest.raises(ContractError, match="F5_RETAINED_AAR_MICE_DEPENDENCY_DRIFT"):
            f4._retained_full0_source_members(source, aar_mice_gather=True)
    compact = Path(f4.__file__).with_name("f4_compact.py")
    original_read = Path.read_bytes
    def changed_passive_formula(path):
        raw = original_read(path)
        if path == compact:
            assert raw.count(b'"eGFR_calc": 142 *') == 1
            return raw.replace(b'"eGFR_calc": 142 *', b'"eGFR_calc": 143 *', 1)
        return raw
    with monkeypatch.context() as changed_formula:
        changed_formula.setattr(Path, "read_bytes", changed_passive_formula)
        changed_formula.setattr(f4, "_f45_source_member_sha256", lambda: {
            **current, "padml/f4_compact.py": sha256_bytes(changed_passive_formula(compact))})
        with pytest.raises(ContractError, match="F5_RETAINED_AAR_MICE_DEPENDENCY_DRIFT"):
            f4._retained_full0_source_members(source, aar_mice_gather=True)


def test_no_aar_selector_input_keeps_primary_context_role(tmp_path, monkeypatch):
    """Exercise the real source proof at the caller boundary; no clinical input."""
    import os
    from padml import f4, f5_sensitivity as sensitivity, nested_loco as nested

    location = os.environ.get("PADML_RETAINED_PRIMARY1513_SOURCE")
    if location is None:
        pytest.skip("requires the retained PRIMARY1513 source archive")
    source = Path(location)
    branch = nested.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT
    seen = []

    class ContextReadBoundary(Exception):
        pass

    def source_reader(value, **options):
        assert value == {"estimand": branch}
        roles = {"retained_primary_context": "aar_primary_context",
                 "retained_no_aar_selector": "aar_no_aar_selector",
                 "retained_no_aar_selector_input": "aar_no_aar_selector_input"}
        members = f4._retained_full0_source_members(options["retained_primary_source_bundle"],
            **{roles[key]: flag for key, flag in options.items() if key in roles})
        assert sha256_bytes(canonical_json_bytes(members)) == (
            "1513ecba963857099c6b99413b8e976393c551a3ec30ed90da1cb14178338bd7")
        seen.append(options)
        raise ContextReadBoundary

    monkeypatch.setattr(sensitivity, "_a12_nested_mice_source", source_reader)
    prepared = {"outer_fold": 5, "family": "GBM_COX", "retained_primary_source_bundle": source,
        "source": {"kind": "PADML_F5_A12_PROJECTED_OUTER_INPUTS_V1", "primary_source": {},
                   "outer_fold": 5, "family": "GBM_COX"}, "branches": {branch: {}}}
    with pytest.raises(ContextReadBoundary):
        sensitivity._a12_no_aar_selector_inputs(prepared, tmp_path / "unused")
    assert seen[-1] == {"retained_primary_source_bundle": source, "retained_primary_context": True}
    outer3 = {**prepared, "outer_fold": 3, "source": {**prepared["source"], "outer_fold": 3,
        "identity_sha256": "6d93ae98e4425805d8fa22e51caabedc527302d3f9ca278852fac1ab8a4ad5e0"}}
    with pytest.raises(ContextReadBoundary):
        sensitivity._a12_no_aar_selector_inputs(outer3, tmp_path / "unused")
    assert seen[-1] == {"retained_primary_source_bundle": source,
                       "retained_no_aar_selector": True, "retained_no_aar_selector_input": True}
    assert not (tmp_path / "unused").exists()

    module = Path(f4.__file__)
    original_read = Path.read_bytes
    raw = original_read(module)
    before = b'"seed": seed + imp if nested else seed,'
    assert raw.count(before) == 1
    changed = raw.replace(before, b'"seed": seed + imp + 1 if nested else seed,', 1)
    current = f4._f45_source_member_sha256()
    monkeypatch.setattr(Path, "read_bytes", lambda path: changed if path == module else original_read(path))
    monkeypatch.setattr(f4, "_f45_source_member_sha256", lambda: {
        **current, "padml/f4.py": sha256_bytes(changed)})
    with pytest.raises(ContractError, match="F5_RETAINED_AAR_SELECTOR_NUMERICAL_DEPENDENCY_DRIFT"):
        sensitivity._a12_no_aar_selector_inputs(prepared, tmp_path / "unused")
    assert len(seen) == 2 and not (tmp_path / "unused").exists()


def test_retained_primary1513_full0_inputs_reject_changed_stop_split(monkeypatch):
    """Source bytes only; the old FULL0 plan and MICE are never materialized."""
    import os
    from padml import f4

    location = os.environ.get("PADML_RETAINED_PRIMARY1513_SOURCE")
    if location is None:
        pytest.skip("requires the retained PRIMARY1513 source archive")
    source = Path(location)
    members = f4._retained_full0_source_members(source, full0_preparation=True)
    assert sha256_bytes(canonical_json_bytes(members)) == (
        "1513ecba963857099c6b99413b8e976393c551a3ec30ed90da1cb14178338bd7")
    module = Path(f4.__file__).with_name("f5.py")
    original_read = Path.read_bytes
    raw = original_read(module)
    before, after = b"round(0.15 * len(training_keys))", b"round(0.16 * len(training_keys))"
    assert raw.count(before) == 1
    changed = raw.replace(before, after, 1)
    current = f4._f45_source_member_sha256()
    monkeypatch.setattr(Path, "read_bytes", lambda path: changed if path == module else original_read(path))
    monkeypatch.setattr(f4, "_f45_source_member_sha256", lambda: {
        **current, "padml/f5.py": sha256_bytes(changed)})
    with pytest.raises(ContractError, match="F5_RETAINED_FULL0_PREPARATION_DEPENDENCY_DRIFT"):
        f4._retained_full0_source_members(source, full0_preparation=True)


@pytest.mark.parametrize(("source_env", "producer_identity"), [
    ("PADML_RETAINED_RSF8CCE_SOURCE",
     "8cce1d0042a87e627324246016a64224db3b23ae818e62eb09840b9d7156eaa1"),
    ("PADML_RETAINED_RSF79_SOURCE",
     "79fe72c928ca97e77def2c56868c1e9d7d8fd55da9fe0215073bed7c5dbcd8f2"),
])
def test_retained_rsf_q_source_rejects_changed_s3b2_seed(monkeypatch, source_env, producer_identity):
    """Actual source archives only; no Q, native, or clinical payload is read."""
    import os
    from padml import f4

    location = os.environ.get(source_env)
    if location is None:
        pytest.skip(f"requires the retained source archive in {source_env}")
    source = Path(location).resolve(strict=True)
    members = f4._retained_full0_source_members(source, full0_rsf_q=True)
    assert sha256_bytes(canonical_json_bytes(members)) == producer_identity
    current = f4._f45_source_member_sha256()
    assert members != current

    module = Path(f4.__file__).with_name("f2_kernel.py")
    original_read = Path.read_bytes
    raw = original_read(module)
    start = raw.index(b"def _run_r_registered_rsf(")
    stop = raw.index(b"\ndef ", start + 1)
    body = raw[start:stop]
    before = b'"S3B2", [provisional], inner, 20, spec["seed"] + 50_000'
    after = b'"S3B2", [provisional], inner, 20, spec["seed"] + 50_001'
    assert body.count(before) == 1
    changed = raw[:start] + body.replace(before, after, 1) + raw[stop:]
    monkeypatch.setattr(Path, "read_bytes", lambda path: changed if path == module else original_read(path))
    # Keep the simulated executor's byte identity truthful: rejection must
    # come from the causal phase/seed proof, not a stale module digest.
    monkeypatch.setattr(f4, "_f45_source_member_sha256", lambda: {
        **current, "padml/f2_kernel.py": sha256_bytes(changed)})
    with pytest.raises(ContractError, match="F5_RETAINED_FULL0_RSF_Q_DEPENDENCY_DRIFT"):
        f4._retained_full0_source_members(source, full0_rsf_q=True)



@pytest.fixture
def fixed12_code_sources():
    """Real code-only archives; no input, prediction or model fixture."""
    import os

    locations = [os.environ.get(name) for name in (
        "PADML_RETAINED_PRIMARY1513_SOURCE", "PADML_FIXED12_RESCORE_SOURCE")]
    if any(location is None for location in locations):
        pytest.skip("requires the original 1513 input and 244c fixed12 code archives")
    return tuple(Path(location).resolve(strict=True) for location in locations)


def test_fixed12_retained_source_roles_are_distinct(fixed12_code_sources, monkeypatch):
    from padml import f4

    primary, rescorer = fixed12_code_sources
    expected = (
        "1513ecba963857099c6b99413b8e976393c551a3ec30ed90da1cb14178338bd7",
        "244c6758a56e1772c31f2822ada2d97938dfefa52b8884ab0a9a71923751eab9")
    current = f4._f45_source_member_sha256()
    for source, role, identity in zip(fixed12_code_sources,
            ("outer_fixed12_rescore", "outer_fixed12_saved_rescore"), expected, strict=True):
        members = f4._retained_full0_source_members(source, **{role: True})
        assert sha256_bytes(canonical_json_bytes(members)) == identity
        assert members != current
        with monkeypatch.context() as unrelated_documentation:
            unrelated_documentation.setattr(f4, "_f45_source_member_sha256", lambda: {
                **current, "NESTED_LOCO_PROTOCOL.md": "0" * 64})
            assert f4._retained_full0_source_members(source, **{role: True}) == members
    with pytest.raises(ContractError, match="F4_O_FIT_FIXED12_SAVED_SOURCE_DRIFT"):
        f4._retained_full0_source_members(primary, outer_fixed12_saved_rescore=True)
    with pytest.raises(ContractError, match="F4_O_FIT_FIXED12_NUMERICAL_DEPENDENCY_DRIFT"):
        f4._retained_full0_source_members(rescorer, outer_fixed12_rescore=True)
    with pytest.raises(ContractError, match="F5_RETAINED_AAR_SOURCE_SCOPE_INVALID"):
        f4._retained_full0_source_members(rescorer,
            outer_fixed12_rescore=True, outer_fixed12_saved_rescore=True)


@pytest.mark.parametrize("module,symbol,before,after", [
    ("f2_kernel.py", "_pool_prediction_batch", b"/ len(payloads)", b"/ (len(payloads) + 1)"),
    ("f2_kernel.py", "_write_response_subset",
     b'by_id[patient_id]["All_Cause_Death"]', b'by_id[patient_id]["Death_Followup_months"]'),
    ("f4.py", "_f4_model_seed",
     b'return base + repeat * policy["repeat_multiplier"] + inner * policy["inner_multiplier"] + imputation',
     b'return base + repeat * policy["repeat_multiplier"] + inner * policy["inner_multiplier"] + imputation + 1'),
    ("f5.py", "_validate_final_design_recipe", b"if transformed:", b"if not transformed:"),
    ("f5.py", "_validate_final_refit_locked_spec",
     b"_locked_family_parameters(family, locked_spec)", b'_locked_family_parameters("RSF", locked_spec)'),
])
def test_fixed12_source_rejects_numerical_dependency_drift(
        fixed12_code_sources, monkeypatch, module, symbol, before, after):
    from padml import f4

    path = Path(f4.__file__).resolve().with_name(module)
    original_read = Path.read_bytes
    raw = original_read(path)
    start = raw.index(("def " + symbol + "(").encode())
    stop = raw.index(b"\ndef ", start + 1)
    body = raw[start:stop]
    assert body.count(before) == 1
    changed = raw[:start] + body.replace(before, after, 1) + raw[stop:]
    current = f4._f45_source_member_sha256()
    # Change the represented executing code and its map together: a bare
    # hash mismatch cannot stand in for the numerical-closure negative.
    monkeypatch.setattr(Path, "read_bytes",
        lambda candidate: changed if candidate == path else original_read(candidate))
    monkeypatch.setattr(f4, "_f45_source_member_sha256", lambda: {
        **current, "padml/" + module: sha256_bytes(changed)})
    for source, role in zip(fixed12_code_sources,
            ("outer_fixed12_rescore", "outer_fixed12_saved_rescore"), strict=True):
        with pytest.raises(ContractError, match="F4_O_FIT_FIXED12_.*DRIFT"):
            f4._retained_full0_source_members(source, **{role: True})


def test_fixed12_saved_reader_binds_producer_before_clinical_input(
        fixed12_code_sources, tmp_path, monkeypatch):
    from padml import f4, nested_loco, runtime

    primary, rescorer = fixed12_code_sources
    member_map = {row["path"]: row["sha256"] for row in load_f45_source_bundle(rescorer)["members"]}
    producer = sha256_bytes(canonical_json_bytes(member_map))
    # This deliberately incomplete header cannot be a scientific report.
    # The original reader must bind its producer before the absent old input.
    saved = tmp_path / "source-header-only.zip"
    write_deterministic_zip(saved, {"execution.json": canonical_json_bytes({
        "test_only": "SOURCE_IDENTITY_NO_NUMBERS", "source_identity": producer})})
    old_result = tmp_path / "UNOPENED-old-result.zip"
    evidence = tmp_path / "UNSTARTED-reader"
    options = dict(input_bundle=tmp_path / "UNOPENED-old-input.zip",
        compiled_input_record={}, retained_primary_source_bundle=primary,
        rescore_fixed12_decision={}, outer_fixed12_rescored_archive=saved,
        outer_fixed12_rescored_source_bundle=rescorer,
        outer_fixed12_pre_search_input=tmp_path / "UNOPENED-pre-search.zip",
        outer_fixed12_pre_search_source_bundle=tmp_path / "UNOPENED-pre-search-source.zip",
        rescore_call_limit=0, replay_evidence=evidence)
    monkeypatch.setattr(runtime, "observe_execution_resources",
        lambda root: {"available_memory_bytes": 8 * 1024**3})
    def forbidden(*args, **kwargs):
        pytest.fail("source-only proof reached a clinical or numerical consumer")
    monkeypatch.setattr(f4, "_materialize_o_fit_input_bundle", forbidden)
    monkeypatch.setattr(nested_loco, "_recompute_fresh_score_from_evidence", forbidden)
    with pytest.raises(ContractError, match="F4_O_FIT_ARCHIVE_PATH_INVALID"):
        f4._load_o_fit_execution_archive(old_result, **options)
    assert not evidence.exists()
    wrong = tmp_path / "mislabelled-source-header-only.zip"
    write_deterministic_zip(wrong, {"execution.json": canonical_json_bytes({
        "test_only": "SOURCE_IDENTITY_NO_NUMBERS", "source_identity": "0" * 64})})
    with pytest.raises(ContractError, match="F4_O_FIT_FIXED12_RESCORE_PRODUCER_MISMATCH"):
        f4._load_o_fit_execution_archive(old_result,
            **{**options, "outer_fixed12_rescored_archive": wrong})
    with pytest.raises(ContractError, match="F4_O_FIT_FIXED12_RESCORE_SCOPE_INVALID"):
        f4._load_o_fit_execution_archive(old_result,
            **{**options, "outer_fixed12_rescored_source_bundle": None})
    assert not evidence.exists()


def test_cox12_retained_report_source_accepts_original_and_rejects_pooling_drift(tmp_path, monkeypatch):
    """Code-only source proof at the original public entry; no clinical reader."""
    import os
    from padml import f5

    declared = os.environ.get("PADML_COX12_REPORT_SOURCE")
    if declared is None:
        pytest.skip("requires the preserved code-only e55c report producer")
    source = Path(declared).resolve(strict=True)
    lineage = tmp_path / "UNFITTED-full-development.json"
    reached = []

    class SourceProofReachedLineage(Exception):
        pass

    def stop_before_clinical_inputs(path, **kwargs):
        assert path == lineage
        assert kwargs == {"bounded": True, "selection_horizon_months": 12}
        reached.append(path)
        raise SourceProofReachedLineage

    monkeypatch.setattr(f5, "_read_final_lineage", stop_before_clinical_inputs)
    options = dict(family="COX_PH", selection_horizon_months=12, replay=True,
        retained_score_root=tmp_path / "UNFITTED-old-score",
        retained_score_producer_source_bundle=tmp_path / "UNFITTED-native-producer.zip",
        prepared_score_source_bundle=tmp_path / "UNFITTED-prepared-producer.zip",
        score_batches=[tmp_path / "UNFITTED-old-score/score-batches/original"],
        retained_full0_source_bundle=source)
    with pytest.raises(SourceProofReachedLineage):
        f5.execute_full_data_locked_scores(lineage, **options)
    assert reached == [lineage]
    assert not lineage.exists()

    entries = read_safe_zip(source, expected_members={"manifest.json", *F45_SOURCE_MEMBERS})
    raw = entries["padml/f2_kernel.py"]
    start = raw.index(b"def _pool_prediction_batch(")
    stop = raw.index(b"\ndef ", start + 1)
    body = raw[start:stop]
    before, after = b"/ len(payloads)", b"/ (len(payloads) + 1)"
    assert body.count(before) == 1
    entries["padml/f2_kernel.py"] = raw[:start] + body.replace(before, after, 1) + raw[stop:]
    manifest = strict_json_bytes(entries["manifest.json"])
    manifest.pop("identity_sha256")
    manifest["members"] = [{"path": name, "sha256": sha256_bytes(entries[name]),
                            "size_bytes": len(entries[name])} for name in F45_SOURCE_MEMBERS]
    entries["manifest.json"] = canonical_json_bytes({**manifest,
        "identity_sha256": sha256_bytes(canonical_json_bytes(manifest))})
    changed = tmp_path / "wrong-pooling-denominator-source.zip"
    write_deterministic_zip(changed, entries)
    with pytest.raises(ContractError, match="NESTED_FULL0_COX_REPORT_SOURCE_DRIFT"):
        f5.execute_full_data_locked_scores(lineage, **{**options, "retained_full0_source_bundle": changed})
    assert reached == [lineage]
    assert not lineage.exists()


def test_selector_future_reserve_preserves_history_and_actual_capacity(tmp_path, monkeypatch):
    from types import SimpleNamespace
    from padml import f4, f5, f5_sensitivity as sensitivity, runtime

    gib = 1024**3
    policy = {"configured_worker_ceiling": runtime.CPU_MINUS_8,
        "memory_bytes_per_worker": 2 * gib, "memory_reserve_bytes": 2 * gib,
        "scratch_bytes_per_worker": 1024, "scratch_reserve_bytes": 100 * gib,
        "transfer_archive_worker_ceiling": 24}
    original = dict(policy)
    # Only resource arithmetic is under test; no patients or path engine.
    monkeypatch.setattr(f5, "_nested_full_selector_partition_records", lambda rows: rows)
    partition = {"covariates": {"members": [{"size_bytes": 128}]},
                 "fit_response": {"size_bytes": 32}}
    calls = [({"seed": 7}, partition, [.5], str(tmp_path / "coarse"))]
    old = f4._selector_phase_resource_policy(policy, calls, 4096,
        execution_worker_memory_bytes=2 * gib)
    future = f4._selector_phase_resource_policy(policy, calls, 4096,
        execution_worker_memory_bytes=2 * gib, execution_scratch_reserve_bytes=0)
    assert future == {**old, "scratch_reserve_bytes": 0}
    assert future["memory_reserve_bytes"] > policy["memory_reserve_bytes"]
    observed = {"effective_cpus": 32, "available_memory_bytes": 8 * gib,
        "scratch_available_bytes": 8192, "scratch_root": str(tmp_path)}
    with pytest.raises(ContractError, match="RESOURCE_ADMISSION_ZERO"):
        runtime.resource_admission(old, observed, legal_tasks=1)
    assert runtime.resource_admission(future, observed, legal_tasks=1)["admitted_worker_ceiling"] == 1
    for key in ("available_memory_bytes", "scratch_available_bytes"):
        with pytest.raises(ContractError, match="RESOURCE_ADMISSION_ZERO"):
            runtime.resource_admission(future, {**observed, key: 1}, legal_tasks=1)
    with pytest.raises(ContractError, match="NESTED_SELECTOR_SCRATCH_BUDGET_INVALID"):
        f4._selector_phase_resource_policy(policy, calls, 4096, execution_scratch_reserve_bytes=True)

    source = tmp_path / "UNFITTED-input.zip"
    write_deterministic_zip(source, {"input.json": b"{}"})
    monkeypatch.setattr(sensitivity.shutil, "disk_usage", lambda root: SimpleNamespace(free=2))
    options = dict(members={"input.json"}, max_member_bytes=1024, max_total_bytes=1024)
    with pytest.raises(ContractError, match="F5_A12_INPUT_EXPANSION_SPACE_INSUFFICIENT"):
        sensitivity._a12_input_expansion_resources(source, tmp_path / "unused", policy, **options)
    record = sensitivity._a12_input_expansion_resources(source, tmp_path / "unused", policy,
        execution_scratch_reserve_bytes=0, **options)
    assert record["expanded_bytes"] == record["reserved_bytes"] == 2
    assert record["scientific_worker_count"] == record["execution_scratch_reserve_bytes"] == 0
    monkeypatch.setattr(sensitivity.shutil, "disk_usage", lambda root: SimpleNamespace(free=1))
    with pytest.raises(ContractError, match="F5_A12_INPUT_EXPANSION_SPACE_INSUFFICIENT"):
        sensitivity._a12_input_expansion_resources(source, tmp_path / "unused", policy,
            execution_scratch_reserve_bytes=0, **options)
    assert policy == original and not (tmp_path / "unused").exists()


def test_retained_gbm_source_semantics_and_distinct_refit_role(tmp_path, monkeypatch):
    """Real source ZIPs only: no patients, native results or scientific calls."""
    import os
    from padml import f4, f5, runtime
    from padml.bundle import extract_safe_zip

    archive = os.environ.get("PADML_GBM_RETAINED_SOURCE_ARCHIVE")
    refit = os.environ.get("PADML_GBM_REFIT_SOURCE")
    if archive is None or refit is None:
        pytest.skip("requires the preserved code-only producer archives")
    names = ("q73.zip", "q0f.zip", "q2cc.zip", "q3ab.zip", "qdf85.zip", "q5c303.zip")
    root = tmp_path / "sources"
    extract_safe_zip(Path(archive), root,
        expected_members={*names, "primary1513.zip", "selector1ae.zip"},
        max_member_bytes=16 * 1024**2, max_total_bytes=128 * 1024**2)
    primary, selector, refit = root / "primary1513.zip", root / "selector1ae.zip", Path(refit)
    f4._retained_full0_source_members(selector, aar_no_aar_selector=True)
    identities = {}
    for name in names:
        members = f4._retained_gbm_q_source_members(root / name, primary)
        identities[name] = sha256_bytes(canonical_json_bytes(members))
    refit_identity = sha256_bytes(canonical_json_bytes(f4._retained_gbm_q_source_members(refit, primary)))
    assert refit_identity == "60233a59cede0bac06afb501df28c3a5138787e0dea91ed0c4990772fccd7d18"
    assert refit_identity not in identities.values()

    entries = read_safe_zip(root / "q73.zip", expected_members={"manifest.json", *F45_SOURCE_MEMBERS})
    def republish(label, updates):
        revised = {**entries, **updates}
        body = strict_json_bytes(revised["manifest.json"])
        body.pop("identity_sha256")
        body["members"] = [{"path": name, "sha256": sha256_bytes(revised[name]),
                            "size_bytes": len(revised[name])} for name in F45_SOURCE_MEMBERS]
        revised["manifest.json"] = canonical_json_bytes({**body,
            "identity_sha256": sha256_bytes(canonical_json_bytes(body))})
        destination = tmp_path / (label + ".zip")
        write_deterministic_zip(destination, revised)
        return destination

    documented = republish("documentation-only", {
        "NESTED_LOCO_PROTOCOL.md": entries["NESTED_LOCO_PROTOCOL.md"] + b"\nCode-only provenance test.\n"})
    accepted = f4._retained_gbm_q_source_members(documented, primary)
    assert sha256_bytes(canonical_json_bytes(accepted)) != identities["q73.zip"]
    source = entries["padml/f2_kernel.py"]
    start = source.index(b"def _run_r_registered_gbm(")
    stop = source.index(b"\ndef ", start + 1)
    body = source[start:stop]
    before, after = b'spec["seed"] + 10_000', b'spec["seed"] + 10_001'
    assert body.count(before) == 1
    changed = republish("changed-gbm-seed", {"padml/f2_kernel.py":
        source[:start] + body.replace(before, after, 1) + source[stop:]})
    with pytest.raises(ContractError, match="F5_RETAINED_GBM_Q_DEPENDENCY_DRIFT"):
        f4._retained_gbm_q_source_members(changed, primary)

    # The original numerical control keeps REFIT separate from all six old
    # roles. This is a source-only seam, never a completed scientific batch.
    q = tmp_path / "UNFITTED-q"
    q.mkdir()
    (q / "input.json").write_bytes(canonical_json_bytes({"UNFITTED": True}))
    def source_boundary(root, policy, *, sources):
        assert root == q and sources["retained_a12_q_executor_source_bundle"] == refit
        return dict(sources), {}
    monkeypatch.setattr(f5, "_q_gbm_source_evidence", source_boundary)
    policy = {"configured_worker_ceiling": runtime.CPU_MINUS_8, "memory_bytes_per_worker": 2147483648,
        "memory_reserve_bytes": 0, "scratch_bytes_per_worker": 1, "scratch_reserve_bytes": 0,
        "transfer_archive_worker_ceiling": 1}
    options = {"prepare_only": True, "task_ids": None, "batch_root": None,
               "q_batches": [], "retained_bytes_per_task": 67108864}
    control = f5._q_search_batch_control(q, policy, options, retained_primary_source_bundle=primary,
        retained_selector_source_bundle=selector, retained_gbm_q_source_bundle=[root / name for name in names],
        retained_a12_q_executor_source_bundle=refit)
    assert control["retained_a12_q_executor_source_identity"] == refit_identity
    assert control["retained_gbm_q_sources"][refit_identity] == str(refit)
    assert set(control["retained_gbm_q_sources"]) == {*identities.values(), refit_identity}
    assert control["confirmed_model_fits"] == control["confirmed_stop_fits"] == 0
    assert not control["completed"] and not control["batches"]


def selection_capability_evidence() -> list[dict]:
    return [
        {
            "family": family,
            "source_kind": "ACCEPTED_F2_SIX_OUTER_RESULTS",
            "validated_outer_folds": list(range(1, 7)),
            "result_sha256_by_outer": [
                sha256_bytes(f"{family}-{outer}".encode())
                for outer in range(1, 7)
            ],
            "runtime_capability_status": "PASS",
            "monthly_survival_interface_status": "PASS",
            "horizons": HORIZONS.copy(),
            "final_model_object_status": "DEFERRED_UNTIL_POST_SELECTION_F5",
        }
        for family in load_science_authority()["science"]["families"]
    ]


def test_accepted_f2_outputs_derive_seven_preselection_capabilities() -> None:
    values = models()
    hashes = {}
    for row in values:
        family = row["family"]
        unit_id = (
            f"selector-f{row['fold']}-elastic-net-cox"
            if family == "ELASTIC_NET_COX"
            else f"model-f{row['fold']}-{family.lower().replace('_', '-')}"
        )
        hashes[unit_id] = sha256_bytes(unit_id.encode())
    observed = derive_f4_selection_capabilities(values, hashes)
    assert [row["family"] for row in observed] == load_science_authority()[
        "science"
    ]["families"]
    assert all(
        row["final_model_object_status"] == "DEFERRED_UNTIL_POST_SELECTION_F5"
        for row in observed
    )
    assert all(seal_f4_selection_capability(row)["status"] == "PASS" for row in observed)


def test_preselection_capability_cannot_claim_final_model_objects() -> None:
    evidence = selection_capability_evidence()[0]
    evidence["final_model_object_status"] = "PASS"
    with pytest.raises(ContractError, match="F4_SELECTION_CAPABILITY_FAILED"):
        seal_f4_selection_capability(evidence)


def test_bootstrap_draws_use_fixed_independent_continuous_r_streams() -> None:
    ids, centers = bootstrap_population()
    fixed = bootstrap_draws(ids, centers, "FIXED_MODEL_PAIRED", replicate_count=3)
    post = bootstrap_draws(ids, centers, "POST_SELECTION_INBAG_OOB", replicate_count=3)
    assert fixed["root_seed"] == BOOTSTRAP_ROOTS["FIXED_MODEL_PAIRED"] == 700000001
    assert post["root_seed"] == BOOTSTRAP_ROOTS["POST_SELECTION_INBAG_OOB"] == 710000001
    assert fixed["rng"] == ["L'Ecuyer-CMRG", "Inversion", "Rejection"]
    assert fixed["draws"] != post["draws"]
    assert bootstrap_draws(
        ids[::-1], centers[::-1], "FIXED_MODEL_PAIRED", replicate_count=3
    )["draws"] == [
        [len(ids) - 1 - index for index in draw] for draw in fixed["draws"]
    ]
    for draw in fixed["draws"]:
        assert len(draw) == len(ids)
        assert {center: sum(centers[index] == center for index in draw) for center in set(centers)} == {
            center: 4 for center in set(centers)
        }


def test_bootstrap_draw_prefix_is_immutable_and_request_fails_closed() -> None:
    ids, centers = bootstrap_population()
    short = bootstrap_draws(ids, centers, "FIXED_MODEL_PAIRED", replicate_count=2)
    long = bootstrap_draws(ids, centers, "FIXED_MODEL_PAIRED", replicate_count=4)
    assert short["draws"] == long["draws"][:2]
    with pytest.raises(ContractError, match="F4_BOOTSTRAP_REQUEST_INVALID"):
        bootstrap_draws(ids, centers, "UNKNOWN", replicate_count=2)
    with pytest.raises(ContractError, match="F4_BOOTSTRAP_REQUEST_INVALID"):
        bootstrap_draws(ids[:-1], centers, "FIXED_MODEL_PAIRED", replicate_count=2)


@pytest.mark.parametrize("invalid_id", ["", None, 123, ["nested"]])
def test_bootstrap_rejects_invalid_source_ids_before_rng(
    monkeypatch, invalid_id,
) -> None:
    ids, centers = bootstrap_population()
    ids[0] = invalid_id

    def forbidden(*args, **kwargs):
        pytest.fail("invalid source IDs must not start the RNG process")

    monkeypatch.setattr("padml.f4.subprocess.run", forbidden)
    with pytest.raises(ContractError, match="F45_PATIENT_ID_INVALID"):
        bootstrap_draws(ids, centers, "FIXED_MODEL_PAIRED", replicate_count=2)


@pytest.mark.parametrize("analysis", ["fixed", "post_selection"])
def test_bootstrap_consumers_reject_wrong_mapping_before_rng(monkeypatch, analysis) -> None:
    ids, centers = bootstrap_population()
    handoff = {"patient_ids": ids, "centers": centers,
               "patient_keys": dict.fromkeys(ids, "a" * 64)}

    def forbidden(*args, **kwargs):
        pytest.fail("unresolved patient keys must not start RNG or evaluation")

    monkeypatch.setattr("padml.f4.subprocess.run", forbidden)
    monkeypatch.setattr("padml.f4._bounded_ordered_spawn", forbidden)
    with pytest.raises(ContractError, match="F45_PATIENT_KEY_MAPPING_MISMATCH"):
        if analysis == "fixed":
            fixed_model_paired_bootstrap(handoff, b"", replicate_count=2, workers=1)
        else:
            post_selection_bootstrap(handoff, b"", {}, replicate_count=2, workers=1)


def test_patient_key_derivation_preserves_exact_strings_and_rejects_old_maps():
    ids = ["001", "1", " ID ", "ID", "id", "患者", "é", "e\u0301", "a" * 64]
    keys = _patient_key_mapping(ids)
    assert keys == {patient: sha256_bytes(patient.encode("utf-8")) for patient in ids}
    assert len(set(keys.values())) == len(ids)
    assert _patient_key_mapping(ids, keys) == keys
    for invalid in ({}, {**keys, "extra": "b" * 64}, dict(zip(ids, reversed(list(keys.values())))),
                    {patient: sha256_bytes(key.encode()) for patient, key in keys.items()}):
        with pytest.raises(ContractError, match="F45_PATIENT_KEY_MAPPING_MISMATCH"):
            _patient_key_mapping(ids, invalid)
    with pytest.raises(ContractError, match="F45_PATIENT_ID_INVALID"):
        _patient_key_mapping(ids + ids[:1])


def test_bootstrap_derives_once_and_preserves_identity_multiplicity(monkeypatch):
    ids, centers = bootstrap_population()
    keys = _patient_key_mapping(ids)
    native_run = subprocess.run
    observed = []
    def capture(*args, **kwargs):
        request = strict_json_bytes(kwargs["input"])
        observed.append(request["patient_ids"])
        return native_run(*args, **kwargs)
    monkeypatch.setattr("padml.f4.subprocess.run", capture)
    forward = bootstrap_draws(ids, centers, "FIXED_MODEL_PAIRED", replicate_count=3, patient_keys=keys)
    backward = bootstrap_draws(ids[::-1], centers[::-1], "FIXED_MODEL_PAIRED", replicate_count=3,
                               patient_keys=dict(reversed(list(keys.items()))))
    assert observed == [[keys[patient] for patient in ids], [keys[patient] for patient in ids[::-1]]]
    assert forward["patient_key_rule"] == PATIENT_KEY_RULE
    patient_draws = [[ids[index] for index in draw] for draw in forward["draws"]]
    assert patient_draws == [[ids[::-1][index] for index in draw] for draw in backward["draws"]]
    assert any(len(set(draw)) < len(draw) for draw in patient_draws)


def test_bootstrap_native_entry_rejects_raw_ids_without_emitting_draws() -> None:
    ids, centers = bootstrap_population()
    ids[0] = "raw-patient-id"
    request = {
        "center_order": list(dict.fromkeys(centers)), "centers": centers,
        "patient_ids": ids, "replicate_count": 2, "root_seed": 700000001,
    }
    completed = subprocess.run(
        ["Rscript", "--vanilla", str(Path(__file__).parents[1] / "padml/kernels/f4_bootstrap.R")],
        input=canonical_json_bytes(request), capture_output=True, check=False,
    )
    assert completed.returncode != 0
    assert completed.stdout == b""
    assert b"grepl" in completed.stderr


def test_full_pipeline_plan_preseals_all_draws_and_seed_domains(
    tmp_path: Path,
) -> None:
    ids = [
        f"patient-{center}-{index}"
        for center in FULL_PIPELINE_CENTER_ORDER
        for index in range(2)
    ]
    centers = [
        center for center in FULL_PIPELINE_CENTER_ORDER for _ in range(2)
    ]
    plan = compile_full_pipeline_bootstrap_plan(
        ids[::-1], centers[::-1], locked_family="RSF"
    )
    replay = validate_full_pipeline_bootstrap_plan(plan)
    assert replay == plan
    assert plan["candidate_protocol_amendment"] == (
        "2026-09-05 candidate protocol amendment"
    )
    assert len(plan["replicates"]) == 200
    assert plan["seed_audit"] == {
        "status": "PASS",
        "rng_integer_range": "SIGNED_32_BIT_POSITIVE",
        "explicit_point_seed_count": 12400,
        "local_procedure_seed_count": 1999800,
        "total_registered_seed_count": 2012200,
        "global_collision_count": 0,
    }
    first = plan["replicates"][0]
    assert first["seed_registry"]["resample_seed"] == 720000001
    assert first["seed_registry"]["mice_seeds"] == list(
        range(730000101, 730000121)
    )
    assert first["seed_registry"]["selector_seed"] == 740000001
    assert first["seed_registry"]["early_stopping_seeds"] == list(
        range(750000101, 750000121)
    )
    assert first["seed_registry"]["final_model_seeds"] == list(
        range(770000101, 770000121)
    )
    ordered_centers = plan["population"]["centers"]
    for row in plan["replicates"]:
        assert {
            center: sum(
                ordered_centers[index] == center
                for index in row["draw_indices"]
            )
            for center in FULL_PIPELINE_CENTER_ORDER
        } == {center: 2 for center in FULL_PIPELINE_CENTER_ORDER}
    repeated = compile_full_pipeline_bootstrap_plan(
        ids, centers, locked_family="RSF"
    )
    assert repeated == plan
    request_body = {
        "schema_version": "1.0.0",
        "kind": "PADML_F4_FULL_PIPELINE_BOOTSTRAP_PLAN_REQUEST_V1",
        "locked_family": "RSF",
        "patient_ids": ids[::-1],
        "centers": centers[::-1],
    }
    request_path = tmp_path / "request.json"
    request_path.write_bytes(canonical_json_bytes({
        **request_body,
        "identity_sha256": sha256_bytes(canonical_json_bytes(request_body)),
    }))
    target = tmp_path / "plan.zip"
    result = compile_full_pipeline_bootstrap_plan_bundle(request_path, target)
    assert result["status"] == "PRESEALED_NOT_EXECUTED"
    assert target.stat().st_mode & 0o777 == 0o600
    bundled = strict_json_bytes(
        read_safe_zip(
            target, expected_members={"full-pipeline-plan.json"}
        )["full-pipeline-plan.json"]
    )
    assert validate_full_pipeline_bootstrap_plan(bundled) == plan
    damaged = copy.deepcopy(plan)
    damaged["replicates"][100]["seed_registry"]["selector_seed"] += 1
    with pytest.raises(
        ContractError, match="F4_FULL_PIPELINE_SEED_REGISTRY_DRIFT"
    ):
        validate_full_pipeline_bootstrap_plan(damaged)

    forged = copy.deepcopy(plan)
    row = forged["replicates"][0]
    row["draw_indices"][0] = 1 - row["draw_indices"][0]
    counts = Counter(row["draw_indices"])
    patient_ids = forged["population"]["patient_ids"]
    source_identity = forged["population"]["source_identity_sha256"]
    row["unique_source_patient_count"] = len(counts)
    row["draw_membership_sha256"] = sha256_bytes(canonical_json_bytes([
        patient_ids[index] for index in row["draw_indices"]
    ]))
    row["multiplicity_sha256"] = sha256_bytes(canonical_json_bytes([
        [index, counts[index]] for index in sorted(counts)
    ]))
    row["bootstrap_clone_ids_sha256"] = sha256_bytes(canonical_json_bytes([
        sha256_bytes(canonical_json_bytes([
            "F4_FULL_PIPELINE_RESAMPLED_ROW", source_identity, 1, draw,
            patient_ids[index],
        ]))
        for draw, index in enumerate(row["draw_indices"])
    ]))
    row["replicate_identity_sha256"] = sha256_bytes(canonical_json_bytes({
        key: item for key, item in row.items()
        if key != "replicate_identity_sha256"
    }))
    forged["first_100_registry_sha256"] = sha256_bytes(
        canonical_json_bytes([
            item["replicate_identity_sha256"]
            for item in forged["replicates"][:100]
        ])
    )
    forged["all_200_registry_sha256"] = sha256_bytes(
        canonical_json_bytes([
            item["replicate_identity_sha256"]
            for item in forged["replicates"]
        ])
    )
    forged["identity_sha256"] = sha256_bytes(canonical_json_bytes({
        key: item for key, item in forged.items()
        if key != "identity_sha256"
    }))
    with pytest.raises(
        ContractError, match="F4_FULL_PIPELINE_RESAMPLING_REPLAY_DRIFT"
    ):
        validate_full_pipeline_bootstrap_plan(forged)


def test_resampled_view_preserves_repeated_patients_without_duplicate_ids() -> None:
    ids = [f"p{index}" for index in range(6)]
    handoff = {
        "patient_ids": ids, "centers": ["36", "36", "38", "38", "39", "39"],
        "horizons": HORIZONS.copy(),
        "survival": {"COX_PH": [[1.0] + [0.5 + index / 100] * 36 for index in range(6)]},
    }
    raw = response(ids, [10, 20, 30, 40, 50, 60], [1, 0, 1, 0, 1, 0])["private_bytes"]
    selected, selected_response, receipt = materialize_resampled_view(
        handoff, raw, [0, 0, 2, 3, 4, 5], "FIXED-0001",
    )
    assert len(selected["patient_ids"]) == len(set(selected["patient_ids"])) == 6
    assert selected["survival"]["COX_PH"][0] == selected["survival"]["COX_PH"][1]
    assert selected["centers"] == handoff["centers"]
    _, resampled = _response_rows(selected_response)
    assert [resampled[item]["Death_Followup_months"] for item in selected["patient_ids"]] == [
        "10", "10", "30", "40", "50", "60",
    ]
    assert receipt["draw_count"] == 6
    assert receipt["unique_source_patient_count"] == 5


@pytest.mark.parametrize("indices,replicate_id", [([], "R1"), ([True], "R1"), ([2], "R1"), ([0], "")])
def test_resampled_view_rejects_invalid_draw_before_response_parse(monkeypatch, indices, replicate_id):
    from padml import f4
    handoff = {"patient_ids": ["p1"], "centers": ["36"], "survival": {"COX_PH": [[1.0] * 37]}}
    monkeypatch.setattr(f4, "_response_rows", lambda *args: pytest.fail("Invalid draws must precede response parsing"))
    with pytest.raises(ContractError, match="F4_RESAMPLE_INVALID"):
        f4.materialize_resampled_view(handoff, b"invalid response", indices, replicate_id)


def test_resampled_receipt_reuses_current_response_without_reading_prediction_matrices(monkeypatch):
    from collections.abc import Mapping
    from padml import f4
    ids = ["p1", "p2", "p3"]
    handoff = {"patient_ids": ids, "centers": ["36", "38", "39"], "horizons": HORIZONS.copy(),
               "survival": {"COX_PH": [[1.0] + [0.7] * 36 for _ in ids]}}
    raw = response(ids, [10, 20, 30], [1, 0, 1])["private_bytes"]
    draws = [[0, 0, 2], [2, 1, 0]]
    expected = [f4.materialize_resampled_view(handoff, raw, indices, f"R{index}")
                for index, indices in enumerate(draws)]
    parsed = f4._response_rows(raw)

    class UnreadPredictions(Mapping):
        def __getitem__(self, key):
            pytest.fail("Receipt-only consumption must not read a prediction matrix")
        def __iter__(self):
            pytest.fail("Receipt-only consumption must not construct a prediction view")
        def __len__(self):
            return 1

    monkeypatch.setattr(f4, "_response_rows", lambda *args: pytest.fail("The current response was already parsed"))
    receipt_handoff = {**handoff, "survival": UnreadPredictions()}
    for index, indices in enumerate(draws):
        clone_ids, sampled, receipt = f4._resampled_response_receipt(
            receipt_handoff, raw, indices, f"R{index}", response_rows=parsed)
        assert clone_ids == expected[index][0]["patient_ids"]
        assert sampled == expected[index][1] and receipt == expected[index][2]


@pytest.mark.parametrize("workers", [24, 56])
def test_fixed_bootstrap_uses_one_draw_for_all_families_and_never_refits(
    monkeypatch, workers,
) -> None:
    ids, centers = bootstrap_population()
    families = load_science_authority()["science"]["families"]
    handoff = {
        "patient_ids": ids, "centers": centers, "horizons": HORIZONS.copy(),
        "survival": {
            family: [[1.0] + [family_index + patient / 100] * 36 for patient in range(len(ids))]
            for family_index, family in enumerate(families)
        },
    }
    raw = response(ids, [50] * len(ids), [1] * len(ids))["private_bytes"]

    def fake_evaluation(selected, response_csv, *, include_center_scopes=True, evidence_root=None):
        assert include_center_scopes is True
        assert response_csv.startswith(b"Patient_ID,")
        rows = {}
        macro = {}
        for family, matrix in selected["survival"].items():
            value = sum(row[1] for row in matrix) / len(matrix)
            rows[family] = {
                "ibs_0_to": {"24": value}, "brier_monthly": [value] * 25,
                "discrimination": {
                    "uno_c_24": {"value": value + 0.1},
                    "auc": {"24": {"value": value + 0.2}},
                },
            }
            macro[family] = {"24": {
                "equal_center_ibs": value,
                "equal_center_brier": value,
                "equal_center_uno_c": value + 0.1,
                "equal_center_auc": value + 0.2,
            }}
        return {
            "scopes": [
                {"scope": "MICRO", "families": rows},
                *[
                    {"scope": center, "families": rows}
                    for center in sorted(set(selected["centers"]))
                ],
            ],
            "macro": macro,
        }

    def inline_pool(worker, tasks, *, selected_slots, on_result=None):
        assert selected_slots == workers
        assert [item[0] for item in tasks] == [1, 2, 3]
        rows = [worker(item) for item in tasks]
        if on_result is not None:
            for index, row in enumerate(rows):
                on_result(index, row)
        return rows

    monkeypatch.setattr("padml.f4._bounded_ordered_spawn", inline_pool)
    monkeypatch.setattr("padml.f4.evaluate_predictions", fake_evaluation)
    result = fixed_model_paired_bootstrap(
        handoff, raw, replicate_count=3, workers=workers
    )
    assert result["status"] == "COMPUTED"
    assert result["model_refit_count"] == 0
    assert result["plan"]["root_seed"] == 700000001
    assert len(result["replicates"]) == 3
    assert len(result["pairwise"]) == 21
    first_pair = result["pairwise"][0]
    assert first_pair["metrics"]["ibs_0_24"]["percentile_95_ci"] == pytest.approx([-1, -1])


def test_bootstrap_primary_estimand_reverses_micro_ranking_for_unequal_centers() -> None:
    def row(value: float) -> dict:
        return {
            "ibs_0_to": {"24": value},
            "brier_monthly": [value] * 25,
            "discrimination": {
                "uno_c_24": {"value": 0.7},
                "auc": {"24": {"value": 0.7}},
            },
        }

    # The large center favors COX_PH, while the small center strongly favors RSF.
    # Patient pooling and equal-center aggregation therefore rank them oppositely.
    evaluation = {
        "scopes": [
            {
                "scope": "MICRO",
                "families": {"COX_PH": row(0.0584), "RSF": row(0.0604)},
            },
            {"scope": "36", "families": {"COX_PH": row(0.05), "RSF": row(0.06)}},
            {"scope": "38", "families": {"COX_PH": row(0.90), "RSF": row(0.10)}},
        ],
        "macro": {
            "COX_PH": {"24": {
                "equal_center_ibs": 0.475,
                "equal_center_brier": 0.475,
                "equal_center_uno_c": 0.7,
                "equal_center_auc": 0.7,
            }},
            "RSF": {"24": {
                "equal_center_ibs": 0.08,
                "equal_center_brier": 0.08,
                "equal_center_uno_c": 0.7,
                "equal_center_auc": 0.7,
            }},
        },
    }
    micro = _micro_metrics(evaluation)
    macro = _macro_bootstrap_metrics(evaluation, ["36", "38"])
    assert micro["COX_PH"]["ibs_0_24"] < micro["RSF"]["ibs_0_24"]
    assert macro["COX_PH"]["ibs_0_24"] > macro["RSF"]["ibs_0_24"]


@pytest.mark.parametrize("workers", [24, 56])
@pytest.mark.parametrize("uno_missing", [False, True])
def test_post_selection_bootstrap_separates_inbag_selection_from_oob_evaluation(
    monkeypatch, workers, uno_missing,
) -> None:
    center_order = [
        str(value) for value in load_science_authority()["science"][
            "population"
        ]["validation_centers"]
    ]
    centers = [center for center in center_order for _ in range(20)]
    ids = [f"{index + 1:064x}" for index in range(len(centers))]
    families = load_science_authority()["science"]["families"]
    handoff = {
        "patient_ids": ids, "centers": centers, "horizons": HORIZONS.copy(),
        "survival": {
            family: [[1.0] + [0.8 - patient / 1000] * 36 for patient in range(len(ids))]
            for family in families
        },
    }
    raw = response(ids, [12 if index % 2 else 50 for index in range(len(ids))], [1] * len(ids))["private_bytes"]
    calls = []

    def fake_evaluation(selected, response_csv, *, include_center_scopes=True, evidence_root=None):
        calls.append((set(selected["survival"]), include_center_scopes))
        count = len(selected["patient_ids"])
        metrics = {
            family: {
                "ibs_0_to": {"24": 0.10 + count / 100000},
                "brier_monthly": [0.11 + count / 100000] * 25,
                "discrimination": {
                    "uno_c_24": {"value": 0.70 - count / 100000},
                    "auc": {"24": {"value": 0.71 - count / 100000}},
                },
            }
            for family in selected["survival"]
        }
        macro = {
            family: value for family, value in a15_macro().items()
            if family in selected["survival"]
        }
        for family in selected["survival"]:
            macro[family]["24"].update({
                "equal_center_brier": 0.11 + count / 100000,
                "equal_center_auc": 0.71 - count / 100000,
            })
            if uno_missing:
                macro[family]["24"]["equal_center_uno_c"] = None
        center_metrics = copy.deepcopy(metrics)
        if uno_missing:
            for row in center_metrics.values():
                row["discrimination"]["uno_c_24"] = {
                    "value": None, "status": "NOT_ESTIMABLE", "reasons": ["CASES_BELOW_20"],
                }
        return {
            "scopes": [
                {"scope": "MICRO", "families": metrics},
                *[
                    {"scope": center, "families": center_metrics,
                     "ipcw_qc": [{"horizon": 24, "n_events": 10, "n_non_events": 10,
                                  "n_evaluable": 20, "effective_sample_size": 20}]}
                    for center in sorted(set(selected["centers"]))
                ],
            ],
            "macro": macro,
        }

    def inline_pool(worker, tasks, *, selected_slots, on_result=None):
        assert selected_slots == workers
        assert [item[0] for item in tasks] == [1, 2, 3]
        rows = [worker(item) for item in tasks]
        if on_result is not None:
            for index, row in enumerate(rows):
                on_result(index, row)
        return rows

    monkeypatch.setattr("padml.f4._bounded_ordered_spawn", inline_pool)
    monkeypatch.setattr("padml.f4.evaluate_predictions", fake_evaluation)
    result = post_selection_bootstrap(
        handoff, raw, {family: True for family in families},
        replicate_count=3, workers=workers,
    )
    assert result["status"] == "COMPUTED"
    assert result["model_refit_count"] == 0
    assert result["plan"]["root_seed"] == 710000001
    assert result["selection_frequency"]["COX_PH"]["count"] == 3
    assert all(row["selected_family"] == "COX_PH" for row in result["replicates"])
    assert result["optimism"]["ibs_0_24_oob_minus_inbag"]["status"] == "ESTIMABLE"
    if uno_missing:
        assert result["statistical_status"] == "PARTIALLY_NOT_ESTIMABLE"
        assert result["optimism"]["uno_c_24_inbag_minus_oob"]["arithmetic_mean"] is None
        assert all(row["optimism"]["ibs_0_24_oob_minus_inbag"] is not None for row in result["replicates"])
    assert calls.count((set(families), True)) == 3
    assert calls.count(({"COX_PH"}, True)) == 3


@pytest.mark.parametrize("analysis", ["fixed", "post_selection", "a12", "post_selection_prior_overshoot"])
def test_bootstrap_native_pool_matches_serial_science(analysis, monkeypatch) -> None:
    from functools import partial
    from time import perf_counter
    import padml.f4 as f4
    from padml.f5_sensitivity import A12_BRANCHES, _a12_bootstrap_replicate
    from padml.runtime import _bounded_ordered_spawn

    centers = [str(center) for center in (36, 38, 39, 48, 52, 54) for _ in range(160)]
    ids = [f"{index + 1:064x}" for index in range(len(centers))]
    families = load_science_authority()["science"]["families"]
    handoff = {
        "patient_ids": ids, "centers": centers, "horizons": HORIZONS.copy(),
        "survival": {
            family: [
                [math.exp(math.log(1 - (0.05 + 0.90 * ((i % 160) // 2) / 79)
                                    * (0.94 + f / 100)) * month / 24)
                 for month in HORIZONS]
                for i in range(len(ids))
            ]
            for f, family in enumerate(families)
        },
    }
    raw = response(
        ids, [12 if i % 2 else 50 for i in range(len(ids))],
        [i % 2 for i in range(len(ids))],
    )["private_bytes"]
    if analysis == "a12":
        handoff["survival"] = {
            branch: handoff["survival"][families[i]]
            for i, branch in enumerate(A12_BRANCHES)
        }
        draws = bootstrap_draws(ids, centers, "FIXED_MODEL_PAIRED", replicate_count=2)
        tasks = list(enumerate(draws["draws"], start=1))
        worker = partial(_a12_bootstrap_replicate,
                         evaluation_handoff=handoff, response_csv=raw)
        started = perf_counter()
        serial = [worker(task) for task in tasks]
        serial_seconds = perf_counter() - started
        started = perf_counter()
        parallel = _bounded_ordered_spawn(worker, tasks, selected_slots=56)
    else:
        function = f4.fixed_model_paired_bootstrap if analysis == "fixed" else partial(
            f4.post_selection_bootstrap,
            capability_status={family: True for family in families},
        )
        if analysis == "post_selection_prior_overshoot":
            # Keep the original overshoot fixture. It is now valid descriptive
            # LOESS under the approved prospective rule, not a formal new-key draw.
            legacy = subprocess.run([
                "Rscript", "--vanilla", str(Path(__file__).parents[1] / "padml/kernels/f4_bootstrap.R")
            ], input=canonical_json_bytes({"center_order": list(dict.fromkeys(centers)),
                "centers": centers, "patient_ids": ids, "replicate_count": 2,
                "root_seed": BOOTSTRAP_ROOTS["POST_SELECTION_INBAG_OOB"]}),
                capture_output=True, check=True)
            legacy_draws = strict_json_bytes(legacy.stdout)
            monkeypatch.setattr(f4, "bootstrap_draws", lambda *args, **kwargs: legacy_draws)
        started = perf_counter()
        with monkeypatch.context() as patcher:
            patcher.setattr(f4, "_bounded_ordered_spawn",
                            lambda worker, tasks, **options: [worker(task) for task in tasks])
            serial = function(handoff, raw, replicate_count=2, workers=24)
        serial_seconds = perf_counter() - started
        started = perf_counter()
        parallel = function(handoff, raw, replicate_count=2, workers=56)
        assert serial["status"] == "COMPUTED"
        assert len(serial["replicates"]) == 2
        assert parallel["model_refit_count"] == 0
    parallel_seconds = perf_counter() - started
    assert canonical_json_bytes(parallel) == canonical_json_bytes(serial)
    print(json.dumps({"analysis": analysis, "replicates": 2,
                      "selected_slots": 56, "effective_workers": 2,
                      "serial_seconds": serial_seconds,
                      "parallel_seconds": parallel_seconds}, sort_keys=True))


@pytest.mark.parametrize("workers", [0, -1, True, 24.0])
def test_f4_bootstrap_rejects_invalid_pool_before_reading_inputs(workers) -> None:
    with pytest.raises(ContractError, match="F4_BOOTSTRAP_WORKERS_INVALID"):
        fixed_model_paired_bootstrap({}, b"", workers=workers)
    with pytest.raises(ContractError, match="F4_BOOTSTRAP_WORKERS_INVALID"):
        post_selection_bootstrap({}, b"", {}, workers=workers)


def response(ids: list[str], times: list[float], events: list[int]) -> dict:
    raw = ("Patient_ID,All_Cause_Death,Death_Followup_months\n" + "".join(
        f"{patient_id},{event},{time}\n"
        for patient_id, time, event in zip(ids, times, events, strict=True)
    )).encode()
    fields, rows = _response_rows(raw)
    return _write_response_subset(fields, rows, ids, None)


def models() -> list[dict]:
    science = load_science_authority()["science"]
    values = []
    for fold, center in enumerate(science["population"]["validation_centers"], start=1):
        ids = [f"f{fold}p{i}" for i in range(40)]
        matrix = [[1.0] + [0.5] * 36 for _ in ids]
        sealed = _seal_prediction_matrix(ids, matrix, HORIZONS)
        for family in science["families"]:
            values.append({
                "status": "PASS", "fold": fold, "heldout_center": center,
                "family": family, "prediction_horizons": list(REPORT_HORIZONS),
                "selector_evidence_sha256": str(fold) * 64,
                "monthly_oof_sha256": sealed["sha256"],
                "monthly_oof": {
                    "schema_version": "MONTHLY_OOF_V1", "classification": "PRIVATE_SCIENCE",
                    "horizons": HORIZONS.copy(),
                    "predictions": [{"Patient_ID": item, "survival": row.copy()} for item, row in zip(ids, matrix, strict=True)],
                },
                "predictions": [{"Patient_ID": item, "survival": [0.5] * 4} for item in ids],
            })
    return values


def a15_macro() -> dict[str, dict]:
    families = load_science_authority()["science"]["families"]
    return {
        family: {
            "24": {
                "equal_center_ibs": 0.100,
                "mean_absolute_slope_error": 0.100,
                "mean_absolute_citl": 0.100,
                "pooled_absolute_slope_error": 0.100,
                "pooled_absolute_citl": 0.100,
                "equal_center_raw_dca": 0.100,
                "worst_center_ibs": 0.120,
                "equal_center_uno_c": 0.700,
                "pooled_uno_c": 0.700,
            }
        }
        for family in families
    }


def test_a15_fixed_tiers_and_canonical_tie_are_order_invariant() -> None:
    families = load_science_authority()["science"]["families"]
    macro = a15_macro()
    gate = {family: True for family in families}
    result = select_a15(dict(reversed(list(macro.items()))), gate)
    assert result["selected_family"] == "COX_PH"
    assert result["evidence_class"] == "PREFERENCE_SELECTED_NEAR_EQUIVALENT"
    assert result["first_decisive_criterion"] == "COMPLEXITY"
    assert result["fixed_complexity"] == {
        "COX_PH": 1, "ELASTIC_NET_COX": 2, "RSF": 3, "GBM_COX": 3,
        "XGBOOST_COX": 3, "FPM_TVC_SET_A": 2, "COXTIME_SET_A": 4,
    }
    assert result["fixed_interpretability"] == {
        "COX_PH": 4, "ELASTIC_NET_COX": 4, "RSF": 2, "GBM_COX": 2,
        "XGBOOST_COX": 2, "FPM_TVC_SET_A": 3, "COXTIME_SET_A": 1,
    }
    assert select_a15(macro, dict(reversed(list(gate.items())))) == result
    assert len(result["decision_trace_sha256"]) == 64


def test_f45_execution_seal_binds_code_rules_without_timing_claim() -> None:
    seal = compile_f45_execution_contract_seal()
    assert validate_f45_execution_contract_seal(seal) == seal
    assert "padml/science/authority.json" in seal["source_member_sha256"]
    assert "padml/f2_kernel.py" in seal["source_member_sha256"]
    assert audit_f45_result_blind_replay()["audit_sha256"] == seal[
        "replay_audit_sha256"
    ]
    assert seal["seal_timing_evidence"] == "NOT_PROVIDED"
    assert seal["proves_preoutcome_generation"] is False
    assert seal["proves_result_blind_execution"] is False
    damaged = copy.deepcopy(seal)
    damaged["preregistration"]["f4"]["near_optimal_margin"] = 0.003
    with pytest.raises(
        ContractError, match="F45_EXECUTION_CONTRACT_SEAL_INVALID"
    ):
        validate_f45_execution_contract_seal(damaged)


def test_f45_source_bundle_is_complete_minimal_and_tamper_evident(
    tmp_path: Path,
) -> None:
    target = (tmp_path / "f45-source.zip").resolve()
    result = compile_f45_source_bundle(target)
    manifest = load_f45_source_bundle(target)
    assert result["member_count"] == len(F45_SOURCE_MEMBERS)
    assert [row["path"] for row in manifest["members"]] == list(
        F45_SOURCE_MEMBERS
    )
    assert {
        "padml/__init__.py",
        "padml/capsule.py",
        "padml/f1_kernel.py",
        "padml/f2_validation.py",
        "padml/runtime_bundle.py",
        "padml/kernels/f1_nested_mice.R",
        "padml/kernels/f2_model_development.R",
        "padml/kernels/f4_gbm_stop.R",
        "padml/kernels/f5_a12_mice.R",
    }.issubset(F45_SOURCE_MEMBERS)
    entries = read_safe_zip(target)
    entries["padml/f4.py"] += b"\n# drift\n"
    damaged = (tmp_path / "f45-source-damaged.zip").resolve()
    write_deterministic_zip(damaged, entries)
    with pytest.raises(ContractError, match="F45_SOURCE_BUNDLE_INVALID"):
        load_f45_source_bundle(damaged)


def test_f45_predecessor_bundle_preserves_exact_members_before_a04_adapter(tmp_path):
    target = (tmp_path / 'source.zip').resolve()
    compile_f45_source_bundle(target)
    entries = read_safe_zip(target)
    entries.pop('padml/f5_a04_current.py')
    manifest = strict_json_bytes(entries['manifest.json'])
    manifest['members'] = [r for r in manifest['members'] if r['path'] != 'padml/f5_a04_current.py']
    manifest.pop('identity_sha256')
    manifest['identity_sha256'] = sha256_bytes(canonical_json_bytes(manifest))
    entries['manifest.json'] = canonical_json_bytes(manifest)
    predecessor = (tmp_path / 'predecessor.zip').resolve()
    write_deterministic_zip(predecessor, entries)
    original = predecessor.read_bytes()
    assert load_f45_source_bundle(predecessor) == manifest
    assert predecessor.read_bytes() == original
    # Only the exact newly added member may be absent; an unrelated missing
    # module is never admitted even with a self-consistent new manifest.
    entries.pop('padml/f5_application.py')
    manifest['members'] = [r for r in manifest['members'] if r['path'] != 'padml/f5_application.py']
    manifest.pop('identity_sha256')
    manifest['identity_sha256'] = sha256_bytes(canonical_json_bytes(manifest))
    entries['manifest.json'] = canonical_json_bytes(manifest)
    damaged = (tmp_path / 'missing-required.zip').resolve()
    write_deterministic_zip(damaged, entries)
    with pytest.raises(ContractError, match='F45_SOURCE_BUNDLE_INVALID'):
        load_f45_source_bundle(damaged)


def test_f4_review_projects_only_the_explicitly_accepted_family(
    tmp_path: Path, monkeypatch,
) -> None:
    families = load_science_authority()["science"]["families"]
    decision = select_a15(a15_macro(), {family: True for family in families})
    sha = sha256_bytes(b"f4-review-fixture")
    minimal_suite = {
        "kind": "PADML_F4_COMPLETE_FIXED_PREDICTION_SUITE_V1",
        "status": "COMPUTED_AWAITING_REVIEW",
        "stage_acceptance": False,
        "family_decision": decision,
        "evaluation": {"macro": a15_macro()},
        "matrix_loco": {"stability": {"status": "PASS"}},
        "shadow_dca": {"status": "ALIGNED"},
        "full_pipeline_bootstrap": {
            "status": "NOT_RUN", "required_by_observed_trigger": False,
        },
    }
    minimal_source = (tmp_path / "f4-minimal.zip").resolve()
    write_deterministic_zip(
        minimal_source, {"f4-suite.json": canonical_json_bytes(minimal_suite)}
    )
    minimal_review = {
        "schema_version": "1.0.0",
        "kind": "PADML_F4_LOCKED_FAMILY_REVIEW_V1",
        "status": "APPROVED",
        "f4_result_sha256": sha256_file(minimal_source),
        "family_decision_sha256": sha256_bytes(canonical_json_bytes(decision)),
        "selected_family": decision["selected_family"],
        "matrix_loco_stability_review": "NOT_REQUIRED",
        "shadow_dca_review": "NOT_REQUIRED",
        "full_pipeline_bootstrap_status": "NOT_RUN",
    }
    with pytest.raises(ContractError, match="F4_REVIEW_SOURCE_INVALID"):
        seal_f4_locked_family_handoff(
            minimal_source, minimal_review, f2_run_root=tmp_path
        )

    suite = {
        "kind": "PADML_F4_COMPLETE_FIXED_PREDICTION_SUITE_V1",
        "status": "COMPUTED_AWAITING_REVIEW",
        "stage_acceptance": False,
        "stage_acceptance_reason": "REVIEW_AND_FINAL_WINNER_DEPLOYMENT_REQUIRED",
        "model_refit_count": 0,
        "selection_effect": "A15_ONLY",
        "replicate_count": 1000,
        "workers": 24,
        "execution_scope": "FORMAL",
        "candidate_protocol_amendment": f45_candidate_protocol_amendment_20260905(),
        "prospective_protocol_revision": PROSPECTIVE_PROTOCOL_REVISION,
        "selection_capability_seals": [
            {
                "schema_version": "1.0.0",
                "kind": "PADML_F4_SELECTION_CAPABILITY_SEAL_V1",
                "family": family,
                "status": "PASS",
                "evidence_sha256": sha,
            }
            for family in families
        ],
        "family_decision": decision,
        "evaluation": {"macro": a15_macro()},
        "matrix_loco": {
            "kind": "PADML_F4_A15_FIXED_OOC_MATRIX_LOCO_DIAGNOSTIC_V1",
            "evidence_label": "A15_FIXED_OOC_MATRIX_LOCO_DIAGNOSTIC",
            "independent_training_only_evidence": False,
            "model_refit_count": 0,
            "replicate_locks": [{} for _ in range(6)],
            "global_family": decision["selected_family"],
            "stability": {
                "matching_replicates": 6,
                "total_replicates": 6,
                "threshold": 4,
                "status": "PASS",
                "review_required": False,
            },
        },
        "fixed_model_paired_bootstrap": {
            "kind": "PADML_F4_FIXED_MODEL_PAIRED_BOOTSTRAP_V1",
            "status": "COMPUTED",
            "conditional_on_fixed_fitted_models": True,
            "full_pipeline_uncertainty": False,
            "model_refit_count": 0,
            "selection_effect": "NONE",
            "primary_estimand": "EQUAL_CENTER_MACRO",
            "descriptive_estimand": "POOLED_PATIENT_MICRO",
            "plan": {
                "domain": "FIXED_MODEL_PAIRED",
                "root_seed": 700000001,
                "replicate_count": 1000,
            },
            "replicates": [{} for _ in range(1000)],
        },
        "post_selection_bootstrap": {
            "kind": "PADML_F4_POST_SELECTION_INBAG_OOB_BOOTSTRAP_V1",
            "status": "COMPUTED",
            "fixed_ooc_prediction_sensitivity_only": True,
            "full_pipeline_uncertainty": False,
            "model_refit_count": 0,
            "primary_estimand": "EQUAL_CENTER_MACRO",
            "descriptive_estimand": "POOLED_PATIENT_MICRO",
            "plan": {
                "domain": "POST_SELECTION_INBAG_OOB",
                "root_seed": 710000001,
                "replicate_count": 1000,
            },
            "selection_estimable_replicates": 1000,
            "oob_metric_estimable_replicates": 1000,
            "replicates": [{} for _ in range(1000)],
        },
        "registered_learning_curve_rows": None,
        "o_fit_rows": None,
        "full_pipeline_bootstrap_result": None,
        "full_pipeline_bootstrap": {
            "kind": "PADML_F4_FULL_PIPELINE_BOOTSTRAP_STATUS_V1",
            "status": "NOT_RUN",
            "required_by_observed_trigger": False,
            "registered_triggers": {"fixture_trigger": False},
            "unevaluated_triggers": [],
            "execution_started": False,
            "model_fit_count": 0,
            "selection_effect": "NONE",
        },
        "shadow_dca": {"status": "ALIGNED"},
        "source": {
            "patient_key_rule": PATIENT_KEY_RULE,
            "f2_acceptance_sha256": sha,
            "f1_identity": sha,
            "selection_capability_sha256": sha,
            "execution_contract_seal_sha256": sha,
            "o_fit_aggregate": None,
            "learning_curve_aggregate": None,
        },
    }
    source = (tmp_path / "f4.zip").resolve()
    write_deterministic_zip(
        source, {"f4-suite.json": canonical_json_bytes(suite)}
    )
    review = {
        "schema_version": "2.0.0",
        "kind": "PADML_F4_LOCKED_FAMILY_REVIEW_V2",
        "status": "APPROVED",
        "f4_result_sha256": sha256_file(source),
        "family_decision_sha256": sha256_bytes(canonical_json_bytes(decision)),
        "locked_family": decision["selected_family"],
        "final_family_lock_sha256": resolve_f4_final_family_lock(
            decision, suite["matrix_loco"]
        )["identity_sha256"],
        "matrix_loco_stability_review": "NOT_REQUIRED",
        "shadow_dca_review": "NOT_REQUIRED",
        "full_pipeline_bootstrap_status": "NOT_RUN",
    }
    trusted_source = {
        name: suite["source"][name] for name in (
            "patient_key_rule", "f2_acceptance_sha256", "f1_identity",
            "selection_capability_sha256",
        )
    }
    monkeypatch.setattr("padml.f4.load_f4_inputs", lambda root: {"source": trusted_source})
    with pytest.raises(
        ContractError, match="F4_REVIEW_BOOTSTRAP_INCOMPLETE"
    ):
        seal_f4_locked_family_handoff(source, review, f2_run_root=tmp_path)
    trusted_source["f2_acceptance_sha256"] = "0" * 64
    with pytest.raises(ContractError, match="F4_REVIEW_FROZEN_SOURCE_MISMATCH"):
        seal_f4_locked_family_handoff(source, review, f2_run_root=tmp_path)


def test_a15_near_optimal_and_lexicographic_metrics_have_no_extra_tolerance() -> None:
    families = load_science_authority()["science"]["families"]
    macro = a15_macro()
    gate = {family: True for family in families}
    macro["COX_PH"]["24"]["equal_center_ibs"] = 0.101
    macro["RSF"]["24"]["equal_center_ibs"] = 0.100
    macro["RSF"]["24"]["pooled_absolute_slope_error"] = 0.099
    macro["GBM_COX"]["24"]["equal_center_ibs"] = 0.1020000000001
    result = select_a15(macro, gate)
    assert result["selected_family"] == "RSF"
    assert result["evidence_class"] == "OBJECTIVE_METRIC_SELECTED"
    assert result["first_decisive_criterion"] == "CALIBRATION_SLOPE_DISTANCE"
    assert "GBM_COX" not in result["near_optimal_families"]


def test_approved_a15_uses_pooled_secondary_not_sparse_center_means():
    macro = a15_macro()
    for values in macro.values():
        values["24"].update(mean_absolute_slope_error=None, mean_absolute_citl=None,
                            equal_center_uno_c=None)
    macro["RSF"]["24"]["pooled_absolute_slope_error"] = 0.099
    gate = {family: True for family in macro}
    decision = select_a15(macro, gate)
    assert decision["selected_family"] == "RSF"
    assert decision["rule"] == PROSPECTIVE_PROTOCOL_REVISION
    assert decision["proves_result_blind_execution"] is False
    with pytest.raises(ContractError, match="REQUIRED_METRIC_INVALID"):
        invalid = copy.deepcopy(macro)
        del invalid["RSF"]["24"]["pooled_uno_c"]
        select_a15(invalid, gate)
    for invalid_value in [math.nan, math.inf, "0.7"]:
        invalid = copy.deepcopy(macro)
        invalid["RSF"]["24"]["pooled_uno_c"] = invalid_value
        with pytest.raises(ContractError, match="REQUIRED_METRIC_INVALID"):
            select_a15(invalid, gate)


def test_bootstrap_summary_does_not_convert_numerical_or_missing_errors_to_support():
    from padml.f4 import _bootstrap_summary
    for value in [math.nan, math.inf, "missing", True]:
        with pytest.raises(ContractError, match="F4_BOOTSTRAP_NUMERICAL_ERROR"):
            _bootstrap_summary([0.1, value])
    summary = _bootstrap_summary([0.1, None, 0.2])
    assert summary["estimable_replicates"] == 2
    assert summary["total_replicates"] == 3
    assert summary["arithmetic_mean"] is summary["percentile_95_ci"] is None


def test_post_selection_support_reserve_requires_complete_attributed_ibs():
    post = post_selection_trigger_fixture()
    # Uno may be unavailable while every IBS remains usable.
    post["replicates"][0]["status"] = "NOT_ESTIMABLE"
    assert reduce_post_selection_optimism_trigger(post)["trigger"] is False
    row = post["replicates"][0]
    field = "ibs_0_24_oob_minus_inbag"
    row["optimism"][field] = None
    with pytest.raises(ContractError, match="STATISTICAL_SUPPORT_EVIDENCE_INVALID"):
        reduce_post_selection_optimism_trigger(post)
    row.update(inbag_metrics={"ibs_0_24": 0.1}, oob_metrics={"ibs_0_24": None})
    row["optimism_support"] = {field: {
        "inbag": {"value": 0.1, "status": "ESTIMABLE", "support": []},
        "oob": {"value": None, "status": "NOT_ESTIMABLE", "support": [
            {"scope": "38", "horizon": 24, "reasons": ["EFFECTIVE_SAMPLE_SIZE_INSUFFICIENT"]}]},
    }}
    reduced = reduce_post_selection_optimism_trigger(post)
    assert reduced["trigger"] is reduced["arithmetic_mean_ibs_oob_minus_inbag"] is None
    assert reduced["observed_replicates"] == 1000
    assert reduced["estimable_replicates"] == 999
    assert reduced["full_pipeline_requirement"] == "REQUIRED_DUE_TO_STATISTICAL_SUPPORT"
    macro = a15_macro()
    decision = select_a15(macro, {family: True for family in macro})
    matrix = {"stability": {"matching_replicates": 6, "total_replicates": 6,
                           "threshold": 4, "status": "PASS", "review_required": False}}
    status = _full_pipeline_bootstrap_status({}, decision, matrix, post)
    assert status["requirement"] == "REQUIRED_DUE_TO_STATISTICAL_SUPPORT"
    assert status["registered_triggers"]["mean_1000_post_selection_ibs_optimism_gt_0_002"] is None
    assert "mean_1000_post_selection_ibs_optimism_gt_0_002" not in status["unevaluated_triggers"]
    assert status["review_ready"] is False  # Missing O_fit/learning is not excused.
    row["optimism_support"][field]["oob"]["support"][0]["reasons"] = ["NUMERICAL_FAILURE"]
    with pytest.raises(ContractError, match="STATISTICAL_SUPPORT_EVIDENCE_INVALID"):
        reduce_post_selection_optimism_trigger(post)
    row["optimism"][field] = math.nan
    with pytest.raises(ContractError, match="POST_SELECTION_NUMERICAL_ERROR"):
        reduce_post_selection_optimism_trigger(post)


def test_final_family_lock_applies_elastic_default_only_after_unstable_a15() -> None:
    families = load_science_authority()["science"]["families"]
    macro = a15_macro()
    macro["RSF"]["24"]["equal_center_ibs"] = 0.099
    macro["RSF"]["24"]["pooled_absolute_slope_error"] = 0.099
    decision = select_a15(macro, {family: True for family in families})
    assert decision["selected_family"] == "RSF"

    stable = {
        "stability": {
            "matching_replicates": 4, "total_replicates": 6,
            "threshold": 4, "status": "PASS", "review_required": False,
        }
    }
    locked = resolve_f4_final_family_lock(decision, stable)
    assert locked["locked_family"] == "RSF"
    assert locked["lock_rule"] == "A15_GLOBAL_SELECTION"

    unstable = copy.deepcopy(stable)
    unstable["stability"].update({
        "matching_replicates": 3,
        "status": "SELECTION_UNSTABLE_REVIEW_REQUIRED",
        "review_required": True,
    })
    locked = resolve_f4_final_family_lock(decision, unstable)
    assert locked["a15_selected_family"] == "RSF"
    assert locked["locked_family"] == "ELASTIC_NET_COX"
    assert locked["lock_rule"] == (
        "MATRIX_LOCO_UNSTABLE_ELASTIC_NET_DEFAULT"
    )
    assert locked["complex_family_override"] == "DISABLED_BY_PROTOCOL"
    assert locked["locked_family_ineligible_action"] == "STOP_NO_FALLBACK"


def learning_curve_binding_fixture(reverse=False, multiplier=1):
    import csv
    import io
    from padml.f1_kernel import compile_binding_contract
    columns = load_science_authority()["science"]["mice"]["private_handoff"]["columns"]
    covariates, responses = [], []
    for center in FULL_PIPELINE_CENTER_ORDER:
        for index in range((11 if center == 55 else 17) * multiplier):
            patient = f"lc-患者-{center}-{index:02d}"
            covariates.append({**dict.fromkeys(columns, "1"), "Patient_ID": patient, "Center": str(center)})
            responses.append({"Patient_ID": patient, "All_Cause_Death": str(int(index % 3 == 0)),
                              "Death_Followup_months": str(12 + index / 2)})
    def raw(rows):
        stream = io.StringIO(newline="")
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]), lineterminator="\n")
        writer.writeheader()
        writer.writerows(list(reversed(rows)) if reverse else rows)
        return stream.getvalue().encode()
    covariates, responses = raw(covariates), raw(responses)
    contract = compile_binding_contract(covariates, responses, workbook_sha256="a" * 64,
                                        enforce_formal_denominator=False)
    keys = {patient: sha256_bytes(patient.encode("utf-8"))
            for patient in contract["registry"]["outer"][0]["application_ids"]}
    return contract, covariates, responses, keys


def test_learning_curve_seed_domains_are_exact_shared_and_collision_free():
    from padml.f4 import _learning_curve_seeds, FAMILY_COMPLEXITY
    assert list(FAMILY_COMPLEXITY) == load_science_authority()["science"]["families"]
    assert _learning_curve_seeds("COX_PH", 1, 1, 1, 1) == {
        "sampling": 611100100, "mice": list(range(611110201, 611110206)),
        "selector": 611110301, "early_stopping": 611110401, "model": 611110501,
        "preprocessing": None, "baseline_survival": None,
    }
    assert _learning_curve_seeds("COXTIME_SET_A", 6, 3, 5, 4)["model"] == 636540507
    streams = {}
    for rank, family in enumerate(FAMILY_COMPLEXITY, 1):
        for outer in range(1, 7):
            for seed in range(1, 4):
                for inner in range(1, 6):
                    for fraction in range(1, 5):
                        values = _learning_curve_seeds(family, outer, seed, inner, fraction)
                        for component in ("sampling", "mice", "selector", "early_stopping", "model"):
                            native = values[component] if component == "mice" else [values[component]]
                            for imp, number in enumerate(native, 1):
                                identity = ((outer, seed, inner, component) if component == "sampling" else
                                            (outer, seed, inner, fraction, component, imp) if component == "mice" else
                                            (outer, seed, inner, fraction, component, rank))
                                assert type(number) is int and 0 < number < 2**31
                                assert number not in streams or streams[number] == identity
                                streams[number] = identity
    assert len(streams) == 90 + 360 * 5 + 360 * 7 * 3
    for coordinates in (("INVALID", 1, 1, 1, 1), ("COX_PH", True, 1, 1, 1),
                        ("COX_PH", 1, 4, 1, 1), ("COX_PH", 1, 1, 0, 1), ("COX_PH", 1, 1, 1, 0)):
        with pytest.raises(ContractError, match="F4_LEARNING_CURVE_SEED_COORDINATE_INVALID"):
            _learning_curve_seeds(*coordinates)


@pytest.mark.parametrize("fold", range(1, 7))
def test_f4_original_elastic_lambda_uses_native_candidate_not_new_seta(fold):
    import os
    from padml.f4 import _f4_elastic_parameters, _f4_outer_elastic_source
    from padml.f2_kernel import _expected_family_parent_column_map, predictor_contract
    from padml.f5 import _validate_final_r_fit_health
    root = os.environ.get("PADML_F4_RETAINED_F2")
    if not root:
        pytest.skip("requires the existing accepted F2 archives; never produces a fit")
    entries = read_safe_zip(Path(root) / "results" / f"selector-f{fold}-elastic-net-cox.zip")
    record, = strict_json_bytes(entries["manifest.json"])["artifacts"]
    raw = entries[record["relative_path"]]
    assert (len(raw), sha256_bytes(raw)) == (record["size_bytes"], record["sha256"])
    model = strict_json_bytes(raw)
    source = _f4_outer_elastic_source(model)
    before = canonical_json_bytes(source)
    predictors = predictor_contract(Path(__file__).parents[1] / "padml")
    # A legitimate different cell SetA. Its EPV is checked by the model producer,
    # not by rewriting the full-candidate lambda source to this one-column map.
    cell_map = _expected_family_parent_column_map(
        ["AST_ALT"], "ELASTIC_NET_COX", predictors, source["outer_transform_recipe"])
    for imp in range(1, 21):
        coordinates = {"purpose": "O_FIT", "outer_fold": fold, "repeat": 0,
                       "inner_fold": 0, "imputation": imp}
        parameters, full_map = _f4_elastic_parameters(source, coordinates)
        original = model["selected_spec"]
        assert parameters == {"family": "ELASTIC_NET_COX", "alpha": original["alpha"],
                              "ratio": original["ratio_by_imputation"][imp-1],
                              "lambda": original["lambda_by_imputation"][imp-1],
                              "lambda_upper_bound": original["lambda_upper_bound_by_imputation"][imp-1]}
        assert len(full_map) == 50 and full_map != cell_map
        health = {"engine_threads": 1, "final_model_fit_count": 1, "engine": "glmnet::glmnet",
                  "converged": True, **{key: value for key, value in parameters.items() if key != "family"},
                  "lambda_max": parameters["lambda_upper_bound"]["resolved_lambda_max"]}
        assert _validate_final_r_fit_health(
            "ELASTIC_NET_COX", health, parameters, ordered_parent_column_map=cell_map,
            training_count=100, lambda_source_column_map=full_map) == health
        with pytest.raises(ContractError, match="F2_ELASTIC_PENALTY_IDENTITY_INVALID"):
            _validate_final_r_fit_health("ELASTIC_NET_COX", health, parameters,
                                         ordered_parent_column_map=cell_map, training_count=100)
        if imp <= 5:
            learning = {**coordinates, "purpose": "LEARNING_CURVE", "repeat": 2,
                        "inner_fold": 1, "seed_ordinal": 1, "fraction_rank": 1}
            assert _f4_elastic_parameters(source, learning) == (parameters, full_map)
    assert canonical_json_bytes(source) == before
    with pytest.raises(ContractError, match="F4_OUTER_ELASTIC_SOURCE_INVALID"):
        _f4_elastic_parameters({**source, "outer_fold": fold % 6 + 1}, coordinates)
    damaged = copy.deepcopy(source)
    damaged["selected_spec"]["lambda_by_imputation"][0] *= 2
    with pytest.raises(ContractError, match="LOCKED_ELASTIC_SPEC_INVALID"):
        _f4_elastic_parameters(damaged, coordinates)


def test_f4_native_model_seed_coordinates_match_python_without_rng_or_fits():
    from padml.f4 import _f4_model_seed, FAMILY_COMPLEXITY
    jobs = []
    for family in FAMILY_COMPLEXITY:
        for outer in range(1, 7):
            for repeat, inner in [(0, 0), *((repeat, inner) for repeat in range(1, 4) for inner in range(1, 6))]:
                for imp in range(1, 21):
                    jobs.append({"family": family, "coordinates": {
                        "purpose": "O_FIT", "outer_fold": outer, "repeat": repeat,
                        "inner_fold": inner, "imputation": imp}})
            for seed in range(1, 4):
                for fraction in range(1, 5):
                    for inner in range(1, 6):
                        for imp in range(1, 6):
                            jobs.append({"family": family, "coordinates": {
                                "purpose": "LEARNING_CURVE", "outer_fold": outer, "repeat": 2,
                                "inner_fold": inner, "imputation": imp,
                                "seed_ordinal": seed, "fraction_rank": fraction}})
    expected = [_f4_model_seed(job["family"], job["coordinates"]) for job in jobs]
    kernel = Path(__file__).parents[1] / "padml/kernels/f5_final_refit.R"
    completed = subprocess.run(["Rscript", "--vanilla", "-e", r'''
      suppressPackageStartupMessages(library(jsonlite))
      args <- commandArgs(TRUE)
      definitions <- Filter(function(x) is.call(x) && identical(x[[1]],as.name("<-")) &&
        is.symbol(x[[2]]) && as.character(x[[2]]) %in% c("fail","need","scalar","f4_model_seed"),
        as.list(parse(args[[1]])))
      for(definition in definitions) eval(definition)
      stopifnot(!exists(".Random.seed",envir=.GlobalEnv,inherits=FALSE))
      jobs <- fromJSON(file("stdin"),simplifyVector=FALSE)
      seeds <- vapply(jobs,function(job) f4_model_seed(job$family,job$coordinates),integer(1))
      stopifnot(!exists(".Random.seed",envir=.GlobalEnv,inherits=FALSE))
      cat(toJSON(as.list(seeds),auto_unbox=TRUE))
    ''', str(kernel)], input=canonical_json_bytes(jobs), capture_output=True, check=True)
    assert strict_json_bytes(completed.stdout) == expected
    assert len(expected) == 7 * (1920 + 1800)
    assert _f4_model_seed("COX_PH", {"purpose": "O_FIT", "outer_fold": 1,
        "repeat": 2, "inner_fold": 3, "imputation": 4}) == 301207
    assert _f4_model_seed("FPM_TVC_SET_A", {"purpose": "O_FIT", "outer_fold": 1,
        "repeat": 2, "inner_fold": 3, "imputation": 4}) == 301207
    assert _f4_model_seed("GBM_COX", {"purpose": "O_FIT", "outer_fold": 1,
        "repeat": 2, "inner_fold": 3, "imputation": 4}) == 351408


@pytest.mark.parametrize("change", [{"repeat": 1}, {"inner_fold": 1}, {"imputation": 0},
                                   {"imputation": True}, {"worker_offset": 1}, {"outer_fold": 7}])
def test_f4_o_fit_model_rejects_invented_or_mixed_coordinates(change):
    from padml.f4 import _f4_model_seed
    original = {"purpose": "O_FIT", "outer_fold": 1, "repeat": 0, "inner_fold": 0, "imputation": 1}
    with pytest.raises(ContractError, match="F4_MODEL_COORDINATE_INVALID"):
        _f4_model_seed("COX_PH", {**original, **change})


def test_full_pipeline_outer_mice_inputs_preserve_clones_and_grouped_folds(tmp_path):
    import csv
    import io
    from padml.f1_kernel import _inner_assignments, load_f1_authority
    from padml.f4 import _full_pipeline_outer_mice_inputs, compile_full_pipeline_bootstrap_plan
    _, covariates, raw_response, _ = learning_curve_binding_fixture(multiplier=5)
    source_rows = list(csv.DictReader(io.StringIO(covariates.decode())))
    by_id = {row["Patient_ID"]: row for row in source_rows}
    response_rows = _response_rows(raw_response)[1]
    centers = {patient: int(row["Center"]) for patient, row in by_id.items()}
    events = {patient: int(row["All_Cause_Death"]) for patient, row in response_rows.items()}
    plan = compile_full_pipeline_bootstrap_plan(list(by_id), list(centers.values()), locked_family="COX_PH")
    observed = None
    for outer in range(1, 7):
        value = _full_pipeline_outer_mice_inputs(plan, 1, outer, covariates, raw_response, tmp_path)
        mapping = value["clone_mapping"]
        clones = {row["clone_id"]: row["source_patient_id"] for row in mapping}
        assert len(mapping) == len(clones) == len(by_id)
        assert len(set(clones.values())) < len(clones)
        assert mapping == sorted(mapping, key=lambda row: (row["source_patient_id"].encode(), row["occurrence"]))
        assert all(row["source_patient_key"] == sha256_bytes(row["source_patient_id"].encode()) for row in mapping)
        for row in csv.DictReader(io.StringIO(value["covariates_csv"].decode())):
            original = clones[row["Patient_ID"]]
            assert {**row, "Patient_ID": original} == by_id[original]
        for row in csv.DictReader(io.StringIO(value["response_csv"].decode())):
            original = clones[row["Patient_ID"]]
            assert {**row, "Patient_ID": original} == response_rows[original]
        specs = value["mice_specs"]
        assert len(specs) == 31  # 1 outer analysis + 15 paired inner views.
        outer_ids = specs["OUTER_ANALYSIS"]["view"]["row_ids"]
        heldout = (36, 38, 39, 48, 52, 54)[outer - 1]
        assert all(centers[clones[patient]] != heldout for patient in outer_ids)
        policy = load_f1_authority()["science"]["mice"]["seed_policy"]["split"]
        for part in value["inner_partitions"]:
            train, valid = part["analysis_ids"], part["validation_ids"]
            assert set(train).isdisjoint(valid) and set(train + valid) == set(outer_ids)
            assert {clones[patient] for patient in train}.isdisjoint(clones[patient] for patient in valid)
            seed = policy["base"] + outer * policy["outer_multiplier"] + part["repeat"]
            assigned = _inner_assignments(sorted({clones[patient] for patient in outer_ids}), centers, events,
                                          outer_fold=outer, repeat=part["repeat"], seed=seed)
            assert set(valid) == {patient for patient in outer_ids if assigned[clones[patient]] == part["inner_fold"]}
            name = f"INNER_R{part['repeat']}_K{part['inner_fold']}"
            analysis, application = specs[name + "_ANALYSIS"], specs[name + "_APPLICATION"]
            expected_stream = (outer - 1) * 31 + (part["repeat"] - 1) * 5 + part["inner_fold"]
            assert analysis["chain_rng_substream"] == application["chain_rng_substream"] == expected_stream
            assert analysis["chain_seeds"] == application["chain_seeds"] == list(range(730000101, 730000121))
            assert application["view"]["analysis_ids"] == train
            assert application["view"]["row_ids"] == outer_ids
            assert "response_path" not in application and "response_path" in analysis
        assert value["model_fit_count"] == value["mice_chains_fitted"] == 0
        if outer == 1:
            observed = value
    assert not list(tmp_path.iterdir())
    assert _full_pipeline_outer_mice_inputs(plan, 1, 1, covariates, raw_response, tmp_path) == observed
    with pytest.raises(ContractError, match="F4_FULL_PIPELINE_SOURCE_POPULATION_MISMATCH"):
        _full_pipeline_outer_mice_inputs(plan, 1, 1, covariates, raw_response.replace(
            next(iter(response_rows)).encode(), b"unknown-source", 1), tmp_path)
    for replicate, outer in ((0, 1), (201, 1), (1, 0), (1, 7)):
        with pytest.raises(ContractError, match="F4_FULL_PIPELINE_COMPONENT_COORDINATE_INVALID"):
            _full_pipeline_outer_mice_inputs(plan, replicate, outer, covariates, raw_response, tmp_path)


def test_learning_curve_private_cells_use_exact_s2_training_and_nested_floor_counts(monkeypatch):
    import csv
    import hashlib
    import io
    from padml.f4 import _registered_learning_curve_cells
    def forbidden(*args, **kwargs):
        raise AssertionError("Compiling learning-curve membership must never fit, impute or invoke R")
    monkeypatch.setattr("padml.f4.subprocess.run", forbidden)
    binding = learning_curve_binding_fixture()
    contract, covariates, response, keys = binding
    cells = _registered_learning_curve_cells(*binding, family="COX_PH")
    assert len(cells) == 360
    assert [(x["outer_fold"], x["seed_ordinal"], x["sample_fraction"], x["inner_fold"]) for x in cells] == [
        (outer, seed, fraction, inner) for outer in range(1, 7) for seed in range(1, 4)
        for fraction in (.4, .6, .8, 1.) for inner in range(1, 6)]
    raw_rows = {r["Patient_ID"]: r for r in csv.DictReader(io.StringIO(covariates.decode()))}
    outcomes = _response_rows(response)[1]
    partitions = {(p["outer_fold"], p["inner_fold"]): p for p in contract["registry"]["inner"] if p["repeat"] == 2}
    previous = {}
    for cell in cells:
        outer, inner = cell["outer_fold"], cell["inner_fold"]
        partition = partitions[(outer, inner)]
        assert cell["repeat"] == 2 and cell["imputations"] == 5
        assert cell["source_partition_id"] == partition["partition_id"]
        assert cell["validation_ids"] == partition["validation_ids"]
        strata = {}
        for patient in partition["analysis_ids"]:
            strata.setdefault((raw_rows[patient]["Center"], outcomes[patient]["All_Cause_Death"]), []).append(patient)
        expected = set()
        for (center, event), patients in strata.items():
            def ordering(patient):
                key = keys[patient]
                digest = hashlib.sha256("|".join(map(str, (
                    "LEARNING_CURVE_V1", cell["seeds"]["sampling"], outer, inner, center, event, key))).encode()).hexdigest()
                return digest, key
            count = max(1, len(patients) * {0.4: 2, 0.6: 3, 0.8: 4, 1.0: 5}[cell["sample_fraction"]] // 5)
            expected.update(sorted(patients, key=ordering)[:count])
        assert cell["analysis_ids"] == [p for p in partition["analysis_ids"] if p in expected]
        group = (outer, cell["seed_ordinal"], inner)
        assert previous.get(group, set()).issubset(expected)
        previous[group] = expected
        if cell["sample_fraction"] == 1:
            assert cell["analysis_ids"] == partition["analysis_ids"]
        heldout = next(p for p in contract["registry"]["outer"] if p["outer_fold"] == outer)["validation_ids"]
        assert set(cell["analysis_ids"] + cell["validation_ids"]).isdisjoint(heldout)
    assert cells == _registered_learning_curve_cells(*learning_curve_binding_fixture(True), family="COX_PH")
    other = _registered_learning_curve_cells(*binding, family="COXTIME_SET_A")
    for cox, coxtime in zip(cells, other, strict=True):
        assert cox["analysis_ids"] == coxtime["analysis_ids"] and cox["validation_ids"] == coxtime["validation_ids"]
        assert cox["seeds"]["sampling"] == coxtime["seeds"]["sampling"]
        assert cox["seeds"]["mice"] == coxtime["seeds"]["mice"]
        assert cox["seeds"]["model"] + 6 == coxtime["seeds"]["model"]


def test_learning_curve_cells_reject_binding_drift_and_do_not_admit_score_receipts():
    from padml.f4 import _registered_learning_curve_cells
    binding, covariates, response, keys = learning_curve_binding_fixture()
    changed = copy.deepcopy(binding)
    changed["registry"]["inner"][5]["analysis_ids"].pop()
    with pytest.raises(ContractError, match="F4_LEARNING_CURVE_BINDING_REPLAY_MISMATCH"):
        _registered_learning_curve_cells(changed, covariates, response, keys, family="COX_PH")
    with pytest.raises(ContractError, match="F4_LEARNING_CURVE_BINDING_REPLAY_MISMATCH"):
        _registered_learning_curve_cells(binding, covariates + b"\n", response, keys, family="COX_PH")
    for missing in ({}, dict.fromkeys(keys, "a" * 64)):
        with pytest.raises(ContractError, match="F45_PATIENT_KEY_MAPPING_MISMATCH"):
            _registered_learning_curve_cells(binding, covariates, response, missing, family="COX_PH")
    cells = _registered_learning_curve_cells(binding, covariates, response, keys, family="COX_PH")
    assert _registered_learning_curve_cells(binding, covariates, response, None, family="COX_PH") == cells
    old_origin = copy.deepcopy(binding)
    old_origin["authority_sha256"] = old_origin["registry"]["authority_sha256"] = "b" * 64
    assert _registered_learning_curve_cells(old_origin, covariates, response, keys, family="COX_PH") == cells
    old_origin["registry"]["authority_sha256"] = "c" * 64
    with pytest.raises(ContractError, match="F4_LEARNING_CURVE_BINDING_REPLAY_MISMATCH"):
        _registered_learning_curve_cells(old_origin, covariates, response, keys, family="COX_PH")
    with pytest.raises(ContractError, match="F4_LEARNING_CURVE_ROW_INVALID"):
        reduce_registered_learning_curve(cells, locked_family="COX_PH")


def test_learning_curve_sampling_uses_full_digest_and_exact_key_ties(monkeypatch):
    import csv
    import io
    from padml.f4 import _registered_learning_curve_cells
    binding = learning_curve_binding_fixture()
    contract, covariates, response, keys = binding
    raw_rows = {r["Patient_ID"]: r for r in csv.DictReader(io.StringIO(covariates.decode()))}
    outcomes = _response_rows(response)[1]
    partition = next(p for p in contract["registry"]["inner"]
                     if (p["outer_fold"], p["repeat"], p["inner_fold"]) == (1, 2, 1))
    strata = {}
    for patient in partition["analysis_ids"]:
        strata.setdefault((raw_rows[patient]["Center"], outcomes[patient]["All_Cause_Death"]), []).append(patient)
    observed = []
    for shared_prefix_only in (True, False):
        def digest(raw):
            if raw.startswith(b"LEARNING_CURVE_V1|"):
                key = raw.rsplit(b"|", 1)[1].decode()
                return "0" * 32 + key[-32:] if shared_prefix_only else "0" * 64
            return sha256_bytes(raw)
        monkeypatch.setattr("padml.f4.sha256_bytes", digest)
        first = _registered_learning_curve_cells(*binding, family="COX_PH")[0]
        expected = {patient for patients in strata.values() for patient in sorted(
            patients, key=lambda patient: (("0" * 32 + keys[patient][-32:] if shared_prefix_only else "0" * 64), keys[patient]))
            [:max(1, len(patients) * 2 // 5)]}
        assert set(first["analysis_ids"]) == expected
        observed.append(expected)
    assert observed[0] != observed[1]  # A truncated common prefix would pick the wrong patients.


def test_learning_curve_mice_specs_bind_original_cell_and_double_view(tmp_path, monkeypatch):
    from padml.f4 import _registered_learning_curve_cells, _learning_curve_mice_specs, _execute_learning_curve_mice_cell
    binding = learning_curve_binding_fixture()
    cell = _registered_learning_curve_cells(*binding, family="COX_PH")[0]
    target = tmp_path / "m5"
    specs = _learning_curve_mice_specs(*binding, cell, target)
    assert set(specs) == {"ANALYSIS", "APPLICATION"}
    assert specs["ANALYSIS"]["view"]["row_ids"] == cell["analysis_ids"]
    assert set(specs["APPLICATION"]["view"]["row_ids"]) == set(cell["analysis_ids"]) | set(cell["validation_ids"])
    assert "response_path" not in specs["APPLICATION"]
    assert specs["ANALYSIS"]["chain_seeds"] == specs["APPLICATION"]["chain_seeds"] == list(range(611110201, 611110206))
    other = _registered_learning_curve_cells(*binding, family="RSF")[0]
    assert _learning_curve_mice_specs(*binding, other, target) == specs
    assert not target.exists()
    monkeypatch.setattr("padml.f4.subprocess.run", lambda *args, **kw: pytest.fail("invalid cell started native work"))
    for field, value in (("analysis_ids", cell["analysis_ids"][:-1]), ("seeds", {**cell["seeds"], "mice": list(range(1, 6))})):
        with pytest.raises(ContractError, match="F4_LEARNING_MICE_CELL_INVALID"):
            _execute_learning_curve_mice_cell(*binding, {**cell, field: value}, target, rscript="Rscript")
        assert not target.exists()


@pytest.mark.parametrize("family", ["GBM_COX", "XGBOOST_COX", "COXTIME_SET_A"])
def test_learning_stop_m5_views_use_original_strata_and_separate_substream(tmp_path, family):
    import csv
    import io
    from padml.f1_kernel import _stop_ids
    from padml.f4 import _registered_learning_curve_cells, _learning_curve_mice_specs
    binding = learning_curve_binding_fixture(multiplier=5)
    cell = _registered_learning_curve_cells(*binding, family=family)[0]
    specs = _learning_curve_mice_specs(*binding, cell, tmp_path / "m5")
    assert set(specs) == {"ANALYSIS", "APPLICATION", "STOP_ANALYSIS", "STOP_APPLICATION"}
    covariates = list(csv.DictReader(io.StringIO(binding[1].decode())))
    events = {patient: int(row["All_Cause_Death"])
              for patient, row in _response_rows(binding[2])[1].items()}
    centers = {row["Patient_ID"]: int(row["Center"]) for row in covariates}
    stopping = _stop_ids(cell["analysis_ids"], centers, events, outer_fold=1, repeat=2,
                         inner_fold=1, seed=cell["seeds"]["early_stopping"])
    train, application = specs["STOP_ANALYSIS"], specs["STOP_APPLICATION"]
    assert train["view"]["role"] == "ANALYSIS"
    assert application["view"]["role"] == "APPLICATION"
    assert set(train["view"]["analysis_ids"]) == set(cell["analysis_ids"]) - stopping
    assert train["view"]["row_ids"] == train["view"]["analysis_ids"] == application["view"]["analysis_ids"]
    assert set(application["view"]["row_ids"]) == set(cell["analysis_ids"])
    assert not set(application["view"]["row_ids"]).intersection(cell["validation_ids"])
    assert "response_path" in train and "response_path" not in application
    assert train["chain_seeds"] == application["chain_seeds"] == specs["ANALYSIS"]["chain_seeds"]
    assert train["chain_rng_substream"] == application["chain_rng_substream"] == 1
    assert "chain_rng_substream" not in specs["ANALYSIS"]
    assert "chain_rng_substream" not in specs["APPLICATION"]
    sparse = learning_curve_binding_fixture()
    sparse_cell = _registered_learning_curve_cells(*sparse, family=family)[0]
    with pytest.raises(ContractError, match="F1_STOP_EVENT_SUPPORT_INVALID"):
        _learning_curve_mice_specs(*sparse, sparse_cell, tmp_path / "invalid")
    assert not (tmp_path / "invalid").exists()


def test_native_mice_substream_retains_actual_states_and_preserves_default(tmp_path):
    kernel = Path(__file__).parents[1] / "padml/kernels/f1_nested_mice.R"
    completed = subprocess.run(["Rscript", "--vanilla", "-e", r'''
      suppressPackageStartupMessages(library(mice))
      args <- commandArgs(TRUE)
      fail <- function(message) stop(message, call.=FALSE)
      nested_aar_source <- NULL
      definitions <- Filter(function(x) is.call(x) && identical(x[[1]],as.name("<-")) &&
        is.symbol(x[[2]]) && as.character(x[[2]]) %in% c("addressed_mice_chain","native_chains"),
        as.list(parse(args[[1]])))
      for (definition in definitions) eval(definition)
      RNGkind("L'Ecuyer-CMRG","Inversion","Rejection"); set.seed(909L)
      mice_data <- data.frame(x=rnorm(80), y=rnorm(80))
      mice_data$y[seq(1,80,7)] <- NA_real_
      method <- c(x="",y="pmm"); matrix <- mice::make.predictorMatrix(mice_data)
      matrix[,] <- 0L; matrix["y","x"] <- 1L
      ignore <- rep(FALSE,80)
      blots <- list(y=list(donors=5L,matchtype=1L,trim=5L,ridge=1e-5,ls.meth="qr"))
      calls <- 0L
      chain <- function(chain_seed) {
        calls <<- calls+1L
        set.seed(chain_seed)
        fit <- mice::mice(mice_data,m=1L,method=method,predictorMatrix=matrix,
          ignore=ignore,visitSequence="roman",blots=blots,maxit=30L,printFlag=FALSE,
          seed=chain_seed,remove.constant=FALSE,remove.collinear=FALSE)
        for(unused in c(40L,50L)) fit <- mice::mice.mids(fit,maxit=10L,printFlag=FALSE)
        fit
      }
      seeds <- c(101L,102L); outputs <- list()
      for(role in c("DEFAULT","ZERO","STOP")) {
        chain_rng_substream <- switch(role,DEFAULT=NULL,ZERO=0L,STOP=1L)
        action <- "FIT"; native <- file.path(args[[2]],role); dir.create(native)
        outputs[[role]] <- native_chains(seeds,chain)
        count <- calls; action <- "REPLAY"
        replayed <- native_chains(seeds,chain)
        # Formula environments have different addresses after readRDS; their
        # expressions and every numerical/native state must still be exact.
        snapshot <- function(fit) list(
          fields=fit[setdiff(names(fit),"formulas")],
          formulas=lapply(fit$formulas,deparse),rng=attr(fit,"padml_rng"))
        stopifnot(calls==count,
          identical(lapply(replayed,snapshot),lapply(outputs[[role]],snapshot)))
      }
      stopifnot(calls==6L)
      for(i in 1:2) {
        base <- outputs$DEFAULT[[i]]; zero <- outputs$ZERO[[i]]; stopped <- outputs$STOP[[i]]
        stopifnot(identical(base$imp,zero$imp),identical(base$lastSeedValue,zero$lastSeedValue),
          !identical(zero$imp,stopped$imp),is.null(attr(base,"padml_rng")))
        set.seed(seeds[[i]]); expected <- parallel::nextRNGSubStream(.Random.seed)
        record <- attr(stopped,"padml_rng")
        stopifnot(identical(record$initial_state,expected),
          identical(record$final_state,stopped$lastSeedValue),
          identical(record$root_seed,seeds[[i]]),stopped$iteration==50L,is.na(stopped$seed))
      }
      negative <- file.path(args[[2]],"BAD_STOP"); dir.create(negative)
      stopifnot(all(file.copy(list.files(native,full.names=TRUE),negative)))
      native <- negative
      path <- file.path(native,"imp01.rds"); bad <- readRDS(path)
      attr(bad,"padml_rng")$initial_state[[2]] <- 0L; saveRDS(bad,path)
      failure <- tryCatch(native_chains(seeds,chain),error=identity)
      stopifnot(inherits(failure,"error"),
        conditionMessage(failure)=="F5_MICE_NATIVE_INPUT_BINDING_INVALID",calls==6L)
      cat("SIX_SYNTHETIC_CHAINS_DEFAULT_EXACT_STOP_SUBSTREAM_NATIVE_REPLAY_PASS")
    ''', str(kernel), str(tmp_path)], capture_output=True, check=True)
    assert completed.stdout == b"SIX_SYNTHETIC_CHAINS_DEFAULT_EXACT_STOP_SUBSTREAM_NATIVE_REPLAY_PASS"


def test_learning_curve_m5_adapter_changes_only_four_m20_counts():
    kernels = Path(__file__).parents[1] / "padml/kernels"
    completed = subprocess.run(["Rscript", "--vanilla", "-e", r'''
      args <- commandArgs(TRUE)
      keep <- function(path, names) Filter(function(x) {
        is.call(x) && identical(x[[1]],as.name("<-")) && is.symbol(x[[2]]) &&
          as.character(x[[2]]) %in% names
      }, as.list(parse(path)))
      for(x in keep(args[[1]],c("impute_view","fail"))) eval(x)
      for(x in keep(args[[2]],"learning_curve_m5")) eval(x)
      original <- impute_view
      projected <- learning_curve_m5(original)
      replaced <- 0L
      five <- function(x) {
        if(identical(x,20L)) {replaced <<- replaced+1L; return(5L)}
        if(is.call(x)) for(i in seq_along(x)) {
          if(!is.null(x[[i]]) && !identical(x[[i]],quote(expr=))) x[[i]] <- five(x[[i]])
        }
        x
      }
      expected <- five(body(original))
      stopifnot(replaced==4L,identical(body(projected),expected))
      # The per-chain 30 -> 40 -> 50 body is exactly untouched.
      fits <- function(f) Filter(function(x) is.call(x) && identical(x[[1]],as.name("<-")) &&
          identical(x[[2]],as.name("fits")),as.list(body(f)))[[1]]
      stopifnot(identical(fits(original),fits(projected)))
      stopifnot(inherits(tryCatch(learning_curve_m5(projected),error=identity),"error"))
      cat("FOUR_COUNTS_ONLY_CHAIN_BODY_EXACT")
    ''', str(kernels / "f1_nested_mice.R"), str(kernels / "f4_learning_mice.R")], capture_output=True, check=True)
    assert completed.stdout == b"FOUR_COUNTS_ONLY_CHAIN_BODY_EXACT"


def test_learning_curve_m5_native_pair_retains_and_replays_one_fixed_cell(tmp_path, monkeypatch):
    import csv
    import io
    from test_f5 import native_mice_fixture
    from padml.f1_kernel import compile_binding_contract
    from padml.f4 import _registered_learning_curve_cells, _execute_learning_curve_mice_cell, _replay_learning_curve_mice_cell
    from padml.runtime import RSCRIPT_EXECUTABLE
    import padml.f4 as f4

    plan, covariates, responses = native_mice_fixture()
    contract = compile_binding_contract(covariates, responses, workbook_sha256="b" * 64, enforce_formal_denominator=False)
    keys = dict(zip(plan["source_ids"], plan["patient_keys"], strict=True))
    binding = contract, covariates, responses, keys
    cell = _registered_learning_curve_cells(*binding, family="COX_PH")[0]
    assert (cell["outer_fold"], cell["seed_ordinal"], cell["sample_fraction"], cell["inner_fold"]) == (1, 1, 0.4, 1)
    for name, raw in (("binding.json",canonical_json_bytes(contract)),("cell.json",canonical_json_bytes(cell)),
                      ("patient-keys.json",canonical_json_bytes(keys)),("covariates.csv",covariates),("response.csv",responses)):
        (tmp_path / name).write_bytes(raw)
    actions = []
    native = f4._run_learning_curve_mice_native
    def observed(spec, root, action, **kwargs):
        actions.append(action)
        return native(spec, root, action, **kwargs)
    monkeypatch.setattr(f4, "_run_learning_curve_mice_native", observed)
    target = tmp_path / "fixed-m5"
    outputs = _execute_learning_curve_mice_cell(*binding, cell, target, rscript=RSCRIPT_EXECUTABLE)
    assert actions == ["FIT", "FIT", "REPLAY", "REPLAY"]
    assert all(len(paths) == 5 for paths in outputs.values())
    for role in ("ANALYSIS", "APPLICATION"):
        summary = strict_json_bytes((target / role / "output/summary.json").read_bytes())
        assert summary["formal_m"] == 5 and summary["final_iteration"] == 50
        assert summary["application_response_columns"] == summary["application_predictor_matrix_response_edges"] == 0
        assert len(list((target / role / "native").glob("*.rds"))) == 5
        assert (target / role / "response.csv").exists() == (role == "ANALYSIS")
    def replay_only(spec, root, action, **kwargs):
        assert action == "REPLAY", "retained objects must never be fitted again"
        return native(spec, root, action, **kwargs)
    monkeypatch.setattr(f4, "_run_learning_curve_mice_native", replay_only)
    relocated = tmp_path / "relocated"
    shutil.copytree(target, relocated)
    _replay_learning_curve_mice_cell(*binding, cell, relocated, rscript=RSCRIPT_EXECUTABLE)
    damaged = tmp_path / "changed-completion"
    shutil.copytree(target, damaged)
    path = damaged / "ANALYSIS/output/imputations/imp01.csv"
    reader = csv.DictReader(io.StringIO(path.read_text()))
    rows = list(reader); rows[0]["HGB"] = str(float(rows[0]["HGB"]) + 1)
    stream = io.StringIO(newline=""); writer = csv.DictWriter(stream, fieldnames=reader.fieldnames, lineterminator="\n")
    writer.writeheader(); writer.writerows(rows); path.write_text(stream.getvalue())
    with pytest.raises(ContractError, match="F4_LEARNING_MICE_NATIVE_REPLAY_MISMATCH"):
        _replay_learning_curve_mice_cell(*binding, cell, damaged, rscript=RSCRIPT_EXECUTABLE)
    swapped = tmp_path / "swapped-chains"
    shutil.copytree(target, swapped)
    first, second = (swapped / "ANALYSIS/native" / f"imp{imp:02d}.rds" for imp in (1, 2))
    a,b = first.read_bytes(),second.read_bytes(); first.write_bytes(b); second.write_bytes(a)
    with pytest.raises(ContractError, match="F5_MICE_NATIVE_INPUT_BINDING_INVALID"):
        _replay_learning_curve_mice_cell(*binding, cell, swapped, rscript=RSCRIPT_EXECUTABLE)
    (tmp_path / "verification.json").write_bytes(canonical_json_bytes({
        "cell": {key: cell[key] for key in ("outer_fold", "seed_ordinal", "sample_fraction", "inner_fold")},
        "native_mice_chains": 10, "chain_iterations": 50, "model_fits": 0, "grid_searches": 0,
        "analysis_rows": len(cell["analysis_ids"]), "validation_rows": len(cell["validation_ids"]),
        "native_replay_exact": True, "relocation_replay_exact": True,
        "changed_completed_value_rejected": True, "swapped_native_chains_rejected": True,
    }))


def test_learning_curve_recipe_adapter_changes_three_counts_only(tmp_path):
    from padml.runtime import RSCRIPT_EXECUTABLE
    kernels = Path(__file__).resolve().parents[1] / "padml/kernels"
    code = r'''
args <- commandArgs(trailingOnly=TRUE)
keep <- function(path, names) Filter(function(x) is.call(x) && identical(x[[1L]], as.name("<-")) &&
  is.symbol(x[[2L]]) && as.character(x[[2L]]) %in% names, as.list(parse(path)))
for(x in keep(args[[1L]], "fit_design_recipe")) eval(x)
for(x in keep(args[[2L]], c("learning_curve_recipe_m5", "need", "fail"))) eval(x)
original <- fit_design_recipe
projected <- learning_curve_recipe_m5(original)
count <- 0L
five <- function(x) {
  if(identical(x,20L)) {count <<- count+1L; return(5L)}
  if(is.call(x)) for(i in seq_along(x)) {
    if(!is.null(x[[i]]) && !identical(x[[i]],quote(expr=))) x[[i]] <- five(x[[i]])
  }
  x
}
stopifnot(identical(body(projected),five(body(original))), count==3L,
          identical(formals(projected),formals(original)),
          inherits(tryCatch(learning_curve_recipe_m5(projected),error=identity),"error"))
cat("THREE_COUNTS_ONLY_TRANSFORM_BODY_EXACT")
'''
    (tmp_path / "adapter.R").write_text(code)
    result = subprocess.run([RSCRIPT_EXECUTABLE, "--vanilla", str(tmp_path / "adapter.R"),
        str(kernels / "f2_model_development.R"), str(kernels / "f4_learning_recipe.R")],
        capture_output=True, check=True)
    assert result.stdout == b"THREE_COUNTS_ONLY_TRANSFORM_BODY_EXACT"


def test_learning_curve_recipe_rejects_unregistered_cell_before_native_work(tmp_path, monkeypatch):
    from padml.f4 import _registered_learning_curve_cells, _prepare_learning_curve_recipe
    binding = learning_curve_binding_fixture()
    cell = _registered_learning_curve_cells(*binding, family="COX_PH")[0]
    cell["analysis_ids"] = cell["validation_ids"][:1]
    def forbidden(*args, **kwargs):
        raise AssertionError("Invalid membership must fail before native computation")
    monkeypatch.setattr("padml.f4.subprocess.run", forbidden)
    target = tmp_path / "recipe"
    with pytest.raises(ContractError, match="F4_LEARNING_MICE_CELL_INVALID"):
        _prepare_learning_curve_recipe(*binding, cell, tmp_path / "absent", target, rscript="unused")
    assert not target.exists()


def test_learning_curve_recipe_native_retained_m5_without_refitting(tmp_path, monkeypatch):
    import csv
    import io
    import os
    from padml.f2_kernel import predictor_contract, _expected_family_parent_column_map, _prepare_python_design
    from padml.f4 import _prepare_learning_curve_recipe, FAMILY_COMPLEXITY
    from padml.runtime import RSCRIPT_EXECUTABLE, THREAD_ENV

    fixture_path = os.environ.get("PADML_LEARNING_MICE_RETAINED")
    if not fixture_path:
        pytest.skip("Requires retained M5 objects; this test never generates MICE chains")
    fixture = Path(fixture_path)
    source = Path(os.environ.get("PADML_LEARNING_MICE_NATIVE", str(fixture / "fixed-m5")))
    contract, cell, keys = (strict_json_bytes((fixture / name).read_bytes())
                            for name in ("binding.json", "cell.json", "patient-keys.json"))
    covariates, responses = ((fixture / name).read_bytes() for name in ("covariates.csv", "response.csv"))
    native = tmp_path / "retained-m5"
    shutil.copytree(source, native)
    actions = []
    run = subprocess.run
    def observed(command, **kwargs):
        kernel = Path(command[2]).name
        if kernel == "f4_learning_mice.R":
            assert command[3] == "REPLAY", "No new MICE chains are authorized by this test"
            actions.append("REPLAY_MICE")
        elif kernel == "f4_learning_recipe.R":
            actions.append("RECIPE_M5")
        elif kernel == "f5_final_refit.R":
            assert strict_json_bytes(Path(command[3]).read_bytes())["action"] == "COMPILE_FINAL_RECIPE"
            actions.append("M20_CARDINALITY_NEGATIVE")
        else:
            assert kernel == "verify-design.R", "No model/search entry is authorized by this test"
        return run(command, **kwargs)
    monkeypatch.setattr("padml.f4.subprocess.run", observed)
    target = tmp_path / "recipe"
    recipe = _prepare_learning_curve_recipe(contract, covariates, responses, keys, cell,
        native, target, rscript=RSCRIPT_EXECUTABLE)
    assert actions == ["REPLAY_MICE", "REPLAY_MICE", "RECIPE_M5"]
    spec = strict_json_bytes((target / "spec.json").read_bytes())
    record = spec["projection"]["recipe_registry_record"]
    assert record["fit_ids"] == cell["analysis_ids"]
    assert set(record["fit_ids"]).isdisjoint(cell["validation_ids"])
    assert len(record["members"]) == 5 and len(recipe["representations"]) == 32
    assert recipe["partition_id"] == "F4_LC_F1_S1_P40_K1_ANALYSIS"
    for imp in range(1, 6):
        rows = list(csv.DictReader(io.StringIO((target / "training-inputs" / f"imp{imp:02d}.csv").read_text())))
        assert [row["Patient_ID"] for row in rows] == cell["analysis_ids"]
        assert not {"All_Cause_Death", "Death_Followup_months", "Nelson_Aalen"}.intersection(rows[0])
    selected = ["AST_ALT", "Age", "Creatinine", "HGB", "Sex"]
    package = Path(__file__).resolve().parents[1] / "padml"
    predictors = predictor_contract(package)
    design_spec = {"recipe": recipe, "selected": selected,
        "predictor_rows": [row for row in predictors["variables"] if row["name"] in selected],
        "analysis_dir": record["input_dir"], "application_dir": str(native / "APPLICATION/output/imputations"),
        "validation_ids": cell["validation_ids"], "expected": {
            family: [column for row in _expected_family_parent_column_map(selected, family, predictors,
                        recipe if family in {"COX_PH", "ELASTIC_NET_COX", "FPM_TVC_SET_A"} else None)
                     for column in row["columns"]] for family in FAMILY_COMPLEXITY},
        "output_path": str(tmp_path / "native-designs.rds")}
    (tmp_path / "design-spec.json").write_bytes(canonical_json_bytes(design_spec))
    code = r'''
args <- commandArgs(trailingOnly=TRUE)
source(args[[1L]])
spec <- jsonlite::fromJSON(args[[2L]], simplifyVector=FALSE)
scalar <- function(x) unname(unlist(x,use.names=FALSE)[[1L]])
need <- function(ok,reason) if(!isTRUE(ok)) stop(reason)
frames <- lapply(seq_len(5L),function(i) read.csv(file.path(scalar(spec$analysis_dir),sprintf("imp%02d.csv",i)),check.names=FALSE))
# Independently evaluate the frozen type-7 interpolation over exactly M5.
for(row in spec$recipe$representations) {
  if(identical(scalar(row$representation),"NATURAL_SPLINE_K3")) {
    values <- sort(unlist(lapply(frames,function(x) x[[scalar(row$parent)]]),use.names=FALSE))
    q <- vapply(c(.1,.5,.9),function(p) {
      position <- (length(values)-1L)*p; k <- floor(position)
      values[[k+1L]]+(position-k)*(values[[k+2L]]-values[[k+1L]])
    },numeric(1))
    stopifnot(identical(q[c(1L,3L)],unlist(row$parameters$boundary_knots,use.names=FALSE)),
              identical(q[[2L]],unlist(row$parameters$interior_knots,use.names=FALSE)))
  }
}
selected <- unlist(spec$selected,use.names=FALSE)
validation <- unlist(spec$validation_ids,use.names=FALSE)
rng <- get0(".Random.seed",envir=.GlobalEnv,inherits=FALSE)
designs <- list()
for(family in setdiff(names(spec$expected),c("XGBOOST_COX","COXTIME_SET_A"))) {
  pairs <- lapply(seq_len(5L),function(i) {
    application <- read.csv(file.path(scalar(spec$application_dir),sprintf("imp%02d.csv",i)),check.names=FALSE)
    ix <- match(validation,as.character(application$Patient_ID))
    stopifnot(!anyNA(ix))
    rows <- application[ix,,drop=FALSE]
    transform <- if(family %in% c("COX_PH","ELASTIC_NET_COX","FPM_TVC_SET_A")) spec$recipe else NULL
    make <- function(data) padml_prepare_final_r_design(data,selected,spec$predictor_rows,
                      transform,family,scalar,need)$design
    training <- make(frames[[i]]); heldout <- make(rows)
    stopifnot(identical(colnames(training),unlist(spec$expected[[family]],use.names=FALSE)),
              identical(colnames(training),colnames(heldout)),nrow(heldout)==length(validation),
              identical(unname(heldout[1L,,drop=FALSE]),unname(make(rows[1L,,drop=FALSE]))),
              identical(unname(training[,"AST_ALT"]),as.numeric(frames[[i]]$AST_ALT)),
              !any(c("AST","ALT","All_Cause_Death","Death_Followup_months") %in% colnames(training)))
    list(training=training,validation=heldout)
  })
  designs[[family]] <- pairs
}
stopifnot(identical(rng,get0(".Random.seed",envir=.GlobalEnv,inherits=FALSE)))
saveRDS(designs,scalar(spec$output_path))
cat("FIVE_R_FAMILY_M5_DESIGNS_AND_SINGLE_BATCH_EXACT_NO_RNG")
'''
    (tmp_path / "verify-design.R").write_text(code)
    result = subprocess.run([RSCRIPT_EXECUTABLE, "--vanilla", str(tmp_path / "verify-design.R"),
        str(package / "kernels/f5_design.R"), str(tmp_path / "design-spec.json")],
        env={**os.environ, **THREAD_ENV}, capture_output=True, check=False, timeout=60)
    (tmp_path / "design-stdout.txt").write_bytes(result.stdout)
    (tmp_path / "design-stderr.txt").write_bytes(result.stderr)
    assert result.returncode == 0, result.stderr.decode()
    assert result.stdout == b"FIVE_R_FAMILY_M5_DESIGNS_AND_SINGLE_BATCH_EXACT_NO_RNG"
    import numpy as np
    import pandas as pd
    python_designs = {}
    for family in ("XGBOOST_COX", "COXTIME_SET_A"):
        model_input = {"family": family, "predictors": predictors,
            "selector_from_dependency": {"selected_parents": selected},
            "outcome": "All_Cause_Death", "time": "Death_Followup_months"}
        for imp in range(1, 6):
            training = pd.DataFrame(list(csv.DictReader((target / "training-inputs" / f"imp{imp:02d}.csv").open())))
            application = pd.DataFrame(list(csv.DictReader((native / "APPLICATION/output/imputations" / f"imp{imp:02d}.csv").open())))
            validation = application.set_index("Patient_ID", drop=False).loc[cell["validation_ids"]].reset_index(drop=True)
            matrices, columns = _prepare_python_design(model_input, [training, validation, validation.iloc[:1]], pd)
            assert columns == sorted(design_spec["expected"][family], key=lambda x: x.encode())
            assert np.array_equal(matrices[1].to_numpy()[:1], matrices[2].to_numpy())
            assert np.array_equal(matrices[0]["AST_ALT"].to_numpy(), pd.to_numeric(training["AST_ALT"]).to_numpy())
            python_designs[f"{family}_M{imp}_training"] = matrices[0].to_numpy()
            python_designs[f"{family}_M{imp}_validation"] = matrices[1].to_numpy()
        with pytest.raises(ContractError, match="F2_PYTHON_APPLICATION_RESPONSE_VISIBLE"):
            _prepare_python_design(model_input, [training.assign(All_Cause_Death=1)], pd)
    np.savez(tmp_path / "python-designs.npz", **python_designs)
    # The final M20 compiler must not accept the private five-member projection.
    negative = {**spec, "action": "COMPILE_FINAL_RECIPE", "output_path": str(tmp_path / "forbidden-m20.json")}
    (tmp_path / "negative-spec.json").write_bytes(canonical_json_bytes(negative))
    result = subprocess.run([RSCRIPT_EXECUTABLE, "--vanilla", str(package / "kernels/f5_final_refit.R"),
        str(tmp_path / "negative-spec.json")], env={**os.environ, **THREAD_ENV}, capture_output=True, check=False)
    (tmp_path / "m20-negative-stderr.txt").write_bytes(result.stderr)
    assert result.returncode != 0 and b"F2_RECIPE_REGISTRY_RECORD_INVALID" in result.stderr
    assert not (tmp_path / "forbidden-m20.json").exists()
    (tmp_path / "verification.json").write_bytes(canonical_json_bytes({
        "analysis_rows": len(cell["analysis_ids"]), "validation_rows": len(cell["validation_ids"]),
        "imputations": 5, "families": list(FAMILY_COMPLEXITY), "native_calls": actions,
        "new_mice_chains": 0, "model_fits": 0, "grid_searches": 0,
        "recipe_training_only": True, "m20_guard_retained": True, "design_rng_consumed": False,
        "single_batch_designs_exact": True, "native_recipe_sha256": recipe["recipe_sha256"],
        "limitation": "Synthetic preprocessing only; no selector, fitted scaler, model, score or stage acceptance.",
    }))


def test_learning_curve_uses_full_registered_denominator_and_exact_boundary() -> None:
    digest = sha256_bytes(b"learning-curve-producer")

    def rows(delta: float) -> list[dict]:
        return [
            {
                "outer_fold": outer,
                "seed_ordinal": seed,
                "sample_fraction": fraction,
                "inner_fold": inner,
                "family": "RSF",
                "ibs_0_24": (
                    0.125 + (delta if fraction == 0.8 else 0.0)
                ),
                "producer_receipt_sha256": digest,
            }
            for outer in range(1, 7)
            for seed in range(1, 4)
            for fraction in (0.4, 0.6, 0.8, 1.0)
            for inner in range(1, 6)
        ]

    boundary = reduce_registered_learning_curve(
        rows(0.002), locked_family="RSF"
    )
    assert boundary["status"] == "REDUCED_DECLARED_EVIDENCE"
    assert boundary["execution_evidence_status"] == (
        "NOT_VERIFIED_REFERENCES_ONLY"
    )
    assert boundary["declared_plateau"] is True
    assert boundary["declared_trigger"] is False
    assert boundary["plateau"] is None
    assert boundary["trigger"] is None
    assert boundary["blocking_for_production"] is True
    assert len(boundary["outer_context_means"]) == 72
    assert [row["absolute_ibs_80_minus_100"] for row in boundary["seed_curves"]] == pytest.approx([0.002] * 3)

    unstable = reduce_registered_learning_curve(
        rows(0.0020001), locked_family="RSF"
    )
    assert unstable["declared_plateau"] is False
    assert unstable["declared_trigger"] is True
    assert unstable["plateau"] is None
    assert unstable["trigger"] is None

    incomplete = reduce_registered_learning_curve(
        rows(0.002)[:-1], locked_family="RSF"
    )
    assert incomplete["status"] == "NOT_ESTIMABLE"
    assert incomplete["trigger"] is None
    assert incomplete["missing_coordinate_count"] == 1

    invalid = rows(0.002)
    invalid[0]["ibs_0_24"] = math.nan
    with pytest.raises(ContractError, match="F4_LEARNING_CURVE_NUMERICAL_ERROR"):
        reduce_registered_learning_curve(invalid, locked_family="RSF")
    impossible = rows(0.002)
    impossible[0]["ibs_0_24"] = -0.0001
    with pytest.raises(ContractError, match="F4_LEARNING_CURVE_NUMERICAL_ERROR"):
        reduce_registered_learning_curve(impossible, locked_family="RSF")


def o_fit_evidence_rows(
    *, ibs_delta: float = 0.005, uno_delta: float = 0.03,
    slope_by_outer: dict[int, float] | None = None,
) -> list[dict]:
    digest = sha256_bytes(b"o-fit-evidence")
    rows = []
    for outer in range(1, 7):
        for repeat in range(1, 4):
            body = {
                "outer_fold": outer,
                "repeat": repeat,
                "family": "RSF",
                "model_seed": 300000 + outer * 1000 + repeat * 100,
                "patient_count": 25,
                "patient_set_sha256": digest,
                "m20_sha256": digest,
                "recipe_sha256": digest,
                "config_sha256": digest,
                "oof_fold_patient_counts": [5] * 5,
                "oof_fold_prediction_sha256": [digest] * 5,
                "apparent_prediction_sha256": digest,
                "oof_concatenated_prediction_sha256": digest,
                "response_sha256": digest,
                "producer_source_sha256": sha256_file(
                    Path(__file__).resolve().parents[1] / "padml/f4.py"
                ),
                "native_metric_engine_sha256": sha256_file(
                    Path(__file__).resolve().parents[1]
                    / "padml/kernels/f4_metrics.R"
                ),
                "metric_population": "SAME_OUTER_TRAINING_PATIENTS",
                "oof_reduction": (
                    "CONCATENATE_FIVE_PATIENT_LEVEL_FOLDS_THEN_SCORE"
                ),
                "censoring_policy": "TRAINING_ISOLATED_SAME_EVALUATOR",
                "apparent_ibs_0_24": 0.10,
                "oof_ibs_0_24": float(
                    Decimal("0.10") + Decimal(str(ibs_delta))
                ),
                "apparent_uno_c_24": 0.70,
                "oof_uno_c_24": float(
                    Decimal("0.70") - Decimal(str(uno_delta))
                ),
                "pooled_oof_calibration_slope_24": (
                    slope_by_outer or {}
                ).get(outer, 1.0),
            }
            rows.append({
                **body,
                "producer_evidence_sha256": sha256_bytes(
                    canonical_json_bytes(body)
                ),
            })
    return rows


def o_fit_source_fixture(family="RSF"):
    import csv
    import io
    contract, covariates, responses, _ = learning_curve_binding_fixture()
    centers = {row["Patient_ID"]: row["Center"]
               for row in csv.DictReader(io.StringIO(covariates.decode()))}
    models = {}
    for outer in contract["registry"]["outer"]:
        fold = outer["outer_fold"]
        members = [{"name": f"imp{imp:02d}.csv", "size_bytes": 100,
                    "sha256": sha256_bytes(f"fixture-m20-{fold}-{imp}".encode())}
                   for imp in range(1, 21)]
        config = {"family": family, "parameters": {"outer": fold}}
        models[fold, family] = {
            "selected_spec": config,
            "selected_spec_sha256": sha256_bytes(canonical_json_bytes(config)),
            "family_design_binding": {
                "family": family, "selected_parents": ["AST"],
                "mode": "RAW_CANONICAL" if family == "RSF" else "TRANSFORM_RECIPE",
                "recipe_sha256": None if family == "RSF" else sha256_bytes(f"recipe-{fold}".encode()),
            },
            "model_input": {"model_partitions": [{
                "kind": "OUTER", "fit_covariate_members": members,
                "fit_covariate_member_set_sha256": sha256_bytes(canonical_json_bytes(members)),
                "fit_ids_sha256": sha256_bytes(canonical_json_bytes(outer["analysis_ids"])),
            }]},
        }
    return {"registry": contract["registry"], "centers": centers,
            "response_csv": responses, "models": models}


def o_fit_bundle_fixture(frozen_source, outer=1, repeat=1, family="RSF"):
    from padml.f4 import _f4_model_seed
    model = frozen_source["models"][outer, family]
    part, = [row for row in frozen_source["registry"]["outer"] if row["outer_fold"] == outer]
    def predictions(ids):
        return {"patient_ids": ids.copy(),
                "centers": [frozen_source["centers"][patient] for patient in ids],
                "horizons": HORIZONS.copy(),
                "survival": {family: [[math.exp(-0.01 * month) for month in HORIZONS] for _ in ids]}}
    apparent = predictions(part["analysis_ids"])
    folds = [{**predictions(row["validation_ids"]), "inner_fold": row["inner_fold"]}
             for row in frozen_source["registry"]["inner"]
             if (row["outer_fold"], row["repeat"]) == (outer, repeat)]
    fields, by_id = _response_rows(frozen_source["response_csv"])
    response_csv = _write_response_subset(fields, by_id, part["analysis_ids"], None)["private_bytes"]
    request = {
        "schema_version": "1.0.0", "kind": "PADML_F4_O_FIT_DIRECT_REQUEST_V1",
        "outer_fold": outer, "repeat": repeat, "locked_family": family,
        "m20_sha256": model["model_input"]["model_partitions"][0]["fit_covariate_member_set_sha256"],
        "recipe_sha256": sha256_bytes(canonical_json_bytes(model["family_design_binding"])),
        "config_sha256": model["selected_spec_sha256"],
        "model_seed": _f4_model_seed(
            family, {"purpose": "O_FIT", "outer_fold": outer, "repeat": repeat,
                     "inner_fold": 1, "imputation": 1}),
    }
    return request, apparent, folds, response_csv


@pytest.mark.parametrize("family", ["RSF", "FPM_TVC_SET_A"])
@pytest.mark.parametrize("drift,reason", [
    (None, None), ("config_sha256", "CONFIG"), ("m20_sha256", "M20"),
    ("recipe_sha256", "DESIGN"), ("apparent", "APPARENT_MEMBERSHIP"),
    ("inner", "INNER_MEMBERSHIP"), ("center55", "CENTER"),
    ("response", "RESPONSE"), ("model_seed", "SEED"),
])
def test_o_fit_resealed_sources_must_match_frozen_f1_f2(
    monkeypatch, tmp_path, family, drift, reason,
):
    from padml.f4 import _validate_o_fit_frozen_source
    frozen = o_fit_source_fixture(family)
    request, apparent, folds, response_csv = o_fit_bundle_fixture(frozen, family=family)
    if drift and drift.endswith("_sha256"):
        request[drift] = "0" * 64
    elif drift == "model_seed":
        request[drift] += 1
    elif drift == "apparent":
        apparent["patient_ids"][0] = "not-in-original-outer"
    elif drift == "inner":
        # Same center, same full population and fold counts; only the original
        # F1 validation-fold assignment exposes this self-consistent swap.
        left = folds[0]["centers"].index("38")
        right = folds[1]["centers"].index("38")
        folds[0]["patient_ids"][left], folds[1]["patient_ids"][right] = (
            folds[1]["patient_ids"][right], folds[0]["patient_ids"][left]
        )
    elif drift == "center55":
        for value in [apparent, *folds]:
            value["centers"] = ["36" if center == "55" else center for center in value["centers"]]
    elif drift == "response":
        response_csv = response_csv.replace(b",12.0\n", b",12.1\n", 1)
        assert response_csv != o_fit_bundle_fixture(frozen, family=family)[3]
    if drift is None:
        _validate_o_fit_frozen_source(request, apparent, folds, response_csv, frozen)
    else:
        with pytest.raises(ContractError, match=f"F4_O_FIT_FROZEN_{reason}_MISMATCH"):
            _validate_o_fit_frozen_source(request, apparent, folds, response_csv, frozen)


def test_o_fit_formal_execute_review_and_cli_use_frozen_source(monkeypatch, tmp_path):
    import sys
    from padml.f4 import main
    marker = {"engineering_fixture_only": True}
    source = tmp_path / "aggregate.zip"
    source.write_bytes(b"loader-is-replaced-in-this-wiring-test")
    target = tmp_path / "not-produced.zip"
    loads, consumers = [], []
    def frozen(root, *, include_o_fit_source=False):
        assert root == tmp_path and include_o_fit_source is True
        loads.append(root)
        return {"o_fit_source": marker}
    def consume(path, *, frozen_source):
        assert frozen_source is marker
        consumers.append(path)
        raise ContractError("ENGINEERING_CONSUMER_REACHED_NO_EVALUATION")
    monkeypatch.setattr("padml.f4.load_f4_inputs", frozen)
    monkeypatch.setattr("padml.f4.load_o_fit_aggregate_archive", consume)
    with pytest.raises(ContractError, match="ENGINEERING_CONSUMER_REACHED"):
        execute(tmp_path, target, compile_f45_execution_contract_seal(),
                o_fit_aggregate=source, fixed_result=tmp_path / "fixed.zip")
    suite = tmp_path / "suite.zip"
    write_deterministic_zip(suite, {"f4-suite.json": b"{}",
                                   "o-fit-aggregate.zip": source.read_bytes()})
    with pytest.raises(ContractError, match="ENGINEERING_CONSUMER_REACHED"):
        seal_f4_locked_family_handoff(suite, {}, f2_run_root=tmp_path)
    assert len(consumers) == 2
    def aggregate(sources, output, *, locked_family, frozen_source):
        assert frozen_source is marker and locked_family == "RSF"
        assert sources == [source] * 6 and output == target
        raise ContractError("ENGINEERING_AGGREGATE_CLI_REACHED")
    monkeypatch.setattr("padml.f4.aggregate_o_fit_execution_archives", aggregate)
    monkeypatch.setattr(sys, "argv", ["padml.f4", "o-fit-aggregate", "RSF", str(target),
                                     *[str(source)] * 6, "--f2-run-root", str(tmp_path)])
    with pytest.raises(ContractError, match="ENGINEERING_AGGREGATE_CLI_REACHED"):
        main()
    review = tmp_path / "review.json"
    review.write_bytes(canonical_json_bytes({}))
    monkeypatch.setattr(sys, "argv", ["padml.f4", "review", str(suite), str(review),
                                     str(target), "--f2-run-root", str(tmp_path)])
    with pytest.raises(ContractError, match="ENGINEERING_CONSUMER_REACHED"):
        main()
    assert len(loads) == 4 and len(consumers) == 3 and not target.exists()


def post_selection_trigger_fixture(value: float = 0.002) -> dict:
    return {
        "kind": "PADML_F4_POST_SELECTION_INBAG_OOB_BOOTSTRAP_V1",
        "status": "COMPUTED",
        "fixed_ooc_prediction_sensitivity_only": True,
        "full_pipeline_uncertainty": False,
        "model_refit_count": 0,
        "primary_estimand": "EQUAL_CENTER_MACRO",
        "descriptive_estimand": "POOLED_PATIENT_MICRO",
        "plan": {
            "domain": "POST_SELECTION_INBAG_OOB",
            "root_seed": BOOTSTRAP_ROOTS["POST_SELECTION_INBAG_OOB"],
            "replicate_count": 1000,
        },
        "selection_estimable_replicates": 1000,
        "oob_metric_estimable_replicates": 1000,
        "replicates": [
            {
                "replicate": replicate,
                "status": "ESTIMABLE",
                "primary_estimand": "EQUAL_CENTER_MACRO",
                "descriptive_estimand": "POOLED_PATIENT_MICRO",
                "optimism": {"ibs_0_24_oob_minus_inbag": value},
            }
            for replicate in range(1, 1001)
        ],
    }


def full_pipeline_completion_fixture(family: str = "RSF") -> dict:
    digest = sha256_bytes(b"full-pipeline-fit")
    return {
        "kind": "PADML_F4_FULL_PIPELINE_BOOTSTRAP_RESULT_V1",
        "family": family,
        "procedure": (
            "RESAMPLE_THEN_M20_RECIPE_SELECTOR_LOCAL_TUNE_MODEL_BASELINE"
        ),
        "resample_before_development": True,
        "duplicate_draws_preserved_as_weights": True,
        "selection_rebuilt": True,
        "fixed_seta_conditional": False,
        "family_reselection": False,
        "optimism_subtracted_from_ooc": False,
        "replicates": [
            {
                "replicate": replicate,
                "bootstrap_seed": 720000000 + replicate,
                "selector_seed": 740000000 + replicate,
                "development_receipt_sha256": digest,
                "ibs_optimism": 0.001,
                "uno_c_optimism": 0.01,
                "imputations": [
                    {
                        "imputation": imputation,
                        "mice_seed": 730000000 + replicate * 100 + imputation,
                        "early_stopping_seed": (
                            750000000 + replicate * 100 + imputation
                        ),
                        "final_model_seed": (
                            770000000 + replicate * 100 + imputation
                        ),
                        "fit_receipt_sha256": digest,
                    }
                    for imputation in range(1, 21)
                ],
            }
            for replicate in range(1, 101)
        ],
    }


def learning_curve_evidence_rows(family: str = "RSF") -> list[dict]:
    digest = sha256_bytes(b"learning-curve-evidence")
    return [
        {
            "outer_fold": outer,
            "seed_ordinal": seed,
            "sample_fraction": fraction,
            "inner_fold": inner,
            "family": family,
            "ibs_0_24": 0.10,
            "producer_receipt_sha256": digest,
        }
        for outer in range(1, 7)
        for seed in range(1, 4)
        for fraction in (0.4, 0.6, 0.8, 1.0)
        for inner in range(1, 6)
    ]


@pytest.mark.parametrize("field", [
    "patient_count", "patient_set_sha256", "m20_sha256", "recipe_sha256",
    "config_sha256", "apparent_prediction_sha256", "response_sha256",
    "apparent_ibs_0_24", "apparent_uno_c_24",
])
def test_o_fit_rejects_resealed_cross_repeat_apparent_drift(field: str) -> None:
    rows = o_fit_evidence_rows()
    changed = rows[1]
    if field == "patient_count":
        changed[field] += 1
        changed["oof_fold_patient_counts"][0] += 1
    elif field.endswith("_sha256"):
        changed[field] = sha256_bytes(b"different-outer-apparent")
    else:
        changed[field] += 0.001
    changed["producer_evidence_sha256"] = sha256_bytes(canonical_json_bytes({
        key: value for key, value in changed.items()
        if key != "producer_evidence_sha256"
    }))
    # A self-consistent row, even in a partial batch, cannot change the
    # common apparent source. Recomputing its own hash is not a remedy.
    for candidate in (rows, rows[:2]):
        with pytest.raises(ContractError, match="F4_O_FIT_OUTER_APPARENT_REUSE_MISMATCH"):
            reduce_o_fit_triggers(candidate, locked_family="RSF")


def test_o_fit_preserves_repeat_specific_oof_and_seed_coordinates() -> None:
    rows = o_fit_evidence_rows()
    for row in rows:
        row["oof_fold_prediction_sha256"] = [
            sha256_bytes(f"{row['outer_fold']}/{row['repeat']}/{fold}".encode())
            for fold in range(1, 6)
        ]
        row["oof_concatenated_prediction_sha256"] = sha256_bytes(
            canonical_json_bytes(row["oof_fold_prediction_sha256"])
        )
        row["producer_evidence_sha256"] = sha256_bytes(canonical_json_bytes({
            key: value for key, value in row.items()
            if key != "producer_evidence_sha256"
        }))
    expected = reduce_o_fit_triggers(rows, locked_family="RSF")
    assert expected["status"] == "ESTIMABLE"
    assert reduce_o_fit_triggers(list(reversed(rows)), locked_family="RSF") == expected


def test_amended_o_fit_and_post_selection_trigger_boundaries_fail_closed() -> None:
    boundary = reduce_o_fit_triggers(
        o_fit_evidence_rows(), locked_family="RSF"
    )
    assert boundary["triggers"] == {
        "ibs": False, "uno_c": False, "calibration_slope": False,
    }
    observed = reduce_o_fit_triggers(
        o_fit_evidence_rows(
            ibs_delta=0.0050001, uno_delta=0.0300001,
            slope_by_outer={6: 1.200001},
        ),
        locked_family="RSF",
    )
    assert observed["triggers"] == {
        "ibs": True, "uno_c": True, "calibration_slope": True,
    }
    incomplete = reduce_o_fit_triggers(
        o_fit_evidence_rows()[:-1], locked_family="RSF"
    )
    assert incomplete["status"] == "NOT_ESTIMABLE"
    assert all(value is None for value in incomplete["triggers"].values())
    invalid = o_fit_evidence_rows(slope_by_outer={1: 0.0})
    with pytest.raises(ContractError, match="F4_O_FIT_NUMERICAL_ERROR"):
        reduce_o_fit_triggers(invalid, locked_family="RSF")
    impossible = o_fit_evidence_rows()
    impossible[0]["oof_uno_c_24"] = 1.01
    body = {
        key: value for key, value in impossible[0].items()
        if key != "producer_evidence_sha256"
    }
    impossible[0]["producer_evidence_sha256"] = sha256_bytes(
        canonical_json_bytes(body)
    )
    with pytest.raises(ContractError, match="F4_O_FIT_NUMERICAL_ERROR"):
        reduce_o_fit_triggers(impossible, locked_family="RSF")

    post = reduce_post_selection_optimism_trigger(
        post_selection_trigger_fixture()
    )
    assert post["arithmetic_mean_ibs_oob_minus_inbag"] == pytest.approx(0.002)
    assert post["trigger"] is False
    assert reduce_post_selection_optimism_trigger(
        post_selection_trigger_fixture(0.0020001)
    )["trigger"] is True
    shortened = post_selection_trigger_fixture()
    shortened["replicates"].pop()
    assert reduce_post_selection_optimism_trigger(shortened)["trigger"] is None
    micro_labeled = post_selection_trigger_fixture()
    micro_labeled["primary_estimand"] = "POOLED_PATIENT_MICRO"
    assert reduce_post_selection_optimism_trigger(micro_labeled)["status"] == (
        "NOT_ESTIMABLE"
    )
    replicate_drift = post_selection_trigger_fixture()
    replicate_drift["replicates"][0]["primary_estimand"] = (
        "POOLED_PATIENT_MICRO"
    )
    with pytest.raises(ContractError, match="F4_POST_SELECTION_REPLICATE_INVALID"):
        reduce_post_selection_optimism_trigger(replicate_drift)


def test_true_trigger_rejects_receipt_only_full_pipeline_completion() -> None:
    families = load_science_authority()["science"]["families"]
    macro = a15_macro()
    macro["RSF"]["24"]["equal_center_ibs"] = 0.099
    macro["RSF"]["24"]["pooled_absolute_slope_error"] = 0.099
    decision = select_a15(macro, {family: True for family in families})
    matrix = {
        "kind": "PADML_F4_A15_FIXED_OOC_MATRIX_LOCO_DIAGNOSTIC_V1",
        "evidence_label": "A15_FIXED_OOC_MATRIX_LOCO_DIAGNOSTIC",
        "independent_training_only_evidence": False,
        "model_refit_count": 0,
        "replicate_locks": [{} for _ in range(6)],
        "global_family": "RSF",
        "stability": {
            "matching_replicates": 6,
            "total_replicates": 6,
            "threshold": 4,
            "status": "PASS",
            "review_required": False,
        },
    }
    post = post_selection_trigger_fixture()
    learning = learning_curve_evidence_rows()
    o_fit = o_fit_evidence_rows(ibs_delta=0.0050001)
    completion_input = full_pipeline_completion_fixture()
    with pytest.raises(
        ContractError, match="F4_FULL_PIPELINE_EXECUTION_ARCHIVE_REQUIRED"
    ):
        reduce_full_pipeline_bootstrap_completion(
            completion_input, locked_family="RSF"
        )
    status = _full_pipeline_bootstrap_status(
        {}, decision, matrix, post, learning, o_fit, completion_input
    )
    assert status["requirement"] == "REQUIRED"
    assert status["status"] == "BLOCKED"
    assert status["review_ready"] is False
    assert status["reason"] == "F4_FULL_PIPELINE_EXECUTION_ARCHIVE_REQUIRED"
    assert status["completion"]["status"] == "BLOCKED"


def test_a15_capability_and_required_metric_fail_closed() -> None:
    families = load_science_authority()["science"]["families"]
    gate = {family: True for family in families}
    gate["COXTIME_SET_A"] = False
    with pytest.raises(ContractError, match="F4_A15_SELECTION_CAPABILITY_FAILED"):
        select_a15(a15_macro(), gate)
    macro = a15_macro()
    macro["RSF"]["24"]["equal_center_raw_dca"] = None
    with pytest.raises(ContractError, match="F4_A15_REQUIRED_METRIC_NOT_ESTIMABLE"):
        select_a15(macro, {family: True for family in families})


def test_a15_matrix_loco_selects_on_five_centers_then_recomputes_patient_union(
    monkeypatch,
) -> None:
    science = load_science_authority()["science"]
    families = science["families"]
    centers = [str(value) for value in science["population"]["validation_centers"]]
    gate = {family: True for family in families}

    def center_metric() -> dict:
        return {
            "ibs_0_to": {"24": 0.100},
            "calibration": {"horizons": {"24": {"slope": 0.9, "citl": 0.1}}},
            "dca_24": {"integrated_raw_nb": 0.1},
            "discrimination": {"uno_c_24": {"value": 0.7}},
        }

    scopes = [
        {"scope": center, "families": {family: center_metric() for family in families}}
        for center in centers
    ]
    handoff = {
        "patient_ids": [f"p{index}" for index in range(6)],
        "centers": centers.copy(), "horizons": HORIZONS.copy(),
        "survival": {
            family: [[1.0] + [0.50 + family_index / 100] * 36 for _ in centers]
            for family_index, family in enumerate(families)
        },
    }
    observed = {}
    training_reads = []
    raw_response = response(handoff["patient_ids"], [50.0] * 6, [1] * 6)["private_bytes"]

    def pooled(candidate, response_csv, *, include_center_scopes=True, evidence_root=None):
        if not include_center_scopes:
            training_reads.append(set(candidate["centers"]))
            fields, rows = _response_rows(response_csv)
            assert set(rows) == set(candidate["patient_ids"])
            assert len(rows) == 5
            return {"scopes": [{"scope": "MICRO", "families": {
                family: center_metric() for family in families}}]}
        observed.update(candidate)
        assert response_csv == raw_response
        return {"kind": "PATIENT_LEVEL_RECOMPUTED", "scopes": [{"scope": "MICRO"}]}

    monkeypatch.setattr("padml.f4.evaluate_predictions", pooled)
    result = a15_fixed_ooc_matrix_loco(
        handoff, raw_response, {"scopes": scopes, "macro": a15_macro()}, gate
    )
    assert result["global_family"] == "COX_PH"
    assert result["stability"] == {
        "matching_replicates": 6, "total_replicates": 6, "threshold": 4,
        "status": "PASS", "review_required": False,
    }
    assert all(
        row["omitted_center"] not in row["selection_centers"]
        and row["selection_center_count"] == 5
        and row["selected_family"] == "COX_PH"
        for row in result["replicate_locks"]
    )
    assert observed["survival"]["A15_SELECTED"] == handoff["survival"]["COX_PH"]
    assert training_reads == [set(centers) - {omitted} for omitted in centers]
    assert result["selected_family_pooled_ooc"]["kind"] == "PATIENT_LEVEL_RECOMPUTED"


def test_complete_f4_suite_reuses_one_matrix_and_never_claims_acceptance(
    monkeypatch, tmp_path,
) -> None:
    families = load_science_authority()["science"]["families"]
    handoff = {"sealed": "handoff"}
    response_csv = b"sealed-response"
    capability = selection_capability_evidence()
    capability_status = {family: True for family in families}
    macro = a15_macro()
    for index, family in enumerate(families):
        macro[family]["24"]["equal_center_shadow_dca"] = index / 10
    evaluation = {"macro": macro}
    calls = []
    roots = {}

    def record(name, value, root):
        calls.append((name, value))
        roots[name] = root
        return value

    monkeypatch.setattr(
        "padml.f4.evaluate_predictions",
        lambda observed, response, **options: (
            record("evaluate", (observed, response), options["evidence_root"]) and evaluation
        ),
    )
    decision = select_a15(macro, capability_status)
    monkeypatch.setattr(
        "padml.f4.a15_fixed_ooc_matrix_loco",
        lambda observed, response, evaluated, gate, **options: record(
            "loco", {"stability": {
                "status": "SELECTION_UNSTABLE_REVIEW_REQUIRED",
                "matching_replicates": 3,
                "total_replicates": 6,
                "threshold": 4,
                "review_required": True,
            }}, options["evidence_root"]
        ),
    )
    monkeypatch.setattr(
        "padml.f4.fixed_model_paired_bootstrap",
        lambda observed, response, **options: record(
            "fixed", {"status": "COMPUTED", "model_refit_count": 0}, options["work_root"]
        ),
    )
    monkeypatch.setattr(
        "padml.f4.post_selection_bootstrap",
        lambda observed, response, gate, **options: record(
            "post", {"status": "COMPUTED", "model_refit_count": 0}, options["work_root"]
        ),
    )
    result = evaluate_f4_suite(
        handoff, response_csv, capability, replicate_count=3, workers=2, work_root=tmp_path,
    )
    assert result["family_decision"] == decision
    assert result["model_refit_count"] == 0
    assert result["status"] == "TEST_ONLY_COMPUTED"
    assert result["execution_scope"] == "TEST_ONLY"
    assert result["stage_acceptance"] is False
    assert result["full_pipeline_bootstrap"]["status"] == "BLOCKED"
    assert result["full_pipeline_bootstrap"][
        "registered_triggers"
    ]["matrix_loco_stability_below_4_of_6"] is True
    assert result["full_pipeline_bootstrap"]["requirement"] == "REQUIRED"
    assert result["full_pipeline_bootstrap"]["execution_started"] is False
    assert result["shadow_dca"] == {
        "selection_effect": "NONE",
        "winner": families[-1],
        "primary_winner": decision["selected_family"],
        "status": "DCA_RULE_SENSITIVE",
        "equal_center_integrated_shadow_nb": {
            family: index / 10 for index, family in enumerate(families)
        },
    }
    assert [name for name, _ in calls] == ["evaluate", "loco", "fixed", "post"]
    assert roots == {"evaluate": tmp_path / "point", "loco": tmp_path / "matrix-loco",
                     "fixed": tmp_path / "fixed-model", "post": tmp_path / "post-selection"}


def test_complete_f4_suite_rejects_execution_profile_drift() -> None:
    with pytest.raises(ContractError, match="F4_SUITE_EXECUTION_PROFILE_INVALID"):
        evaluate_f4_suite(
            {}, b"", selection_capability_evidence(), workers=0
        )


def test_formal_f4_requires_evidence_rows_and_exact_b1000() -> None:
    families = load_science_authority()["science"]["families"]
    with pytest.raises(ContractError, match="F4_SELECTION_CAPABILITY_INVALID"):
        evaluate_f4_suite({}, b"", {family: True for family in families})
    with pytest.raises(ContractError, match="F4_FORMAL_BOOTSTRAP_COUNT_INVALID"):
        evaluate_f4_suite(
            {}, b"", selection_capability_evidence(), replicate_count=3, formal=True
        )
    broken = selection_capability_evidence()
    broken[0]["runtime_capability_status"] = "FAIL"
    with pytest.raises(ContractError, match="F4_SELECTION_CAPABILITY_FAILED"):
        seal_f4_selection_capability(broken[0])


@pytest.mark.parametrize("mode", ["exit", "json", "alignment", "launch", "success"])
def test_native_metrics_preserves_full_failure_bytes_and_cleans_success(monkeypatch, tmp_path, mode):
    jobs = [{"label": "engine-fixture"}]
    stdout_bytes = (
        b"raw-output-" * 1200 if mode in {"exit", "json"}
        else canonical_json_bytes({"results": [{"label": "wrong" if mode == "alignment" else "engine-fixture"}]})
    )
    stderr_bytes = b"complete-native-stderr-" * 1000
    calls = []
    def run(argv, **kwargs):
        root = kwargs["cwd"]
        calls.append(root)
        assert root.stat().st_mode & 0o777 == 0o700
        assert (root / "input.json").read_bytes() == kwargs["input"] == canonical_json_bytes({"jobs": jobs})
        assert argv == ["fixture-Rscript", "--vanilla", str(root / "f4_metrics.R")]
        if mode == "launch":
            raise FileNotFoundError("fixture-native-engine-unavailable")
        kwargs["stdout"].write(stdout_bytes)
        kwargs["stderr"].write(stderr_bytes)
        return subprocess.CompletedProcess(argv, 7 if mode == "exit" else 0)
    monkeypatch.setattr("padml.f4.subprocess.run", run)
    if mode == "success":
        assert native_metrics(jobs, rscript="fixture-Rscript", evidence_root=tmp_path) == [{"label": "engine-fixture"}]
        assert len(calls) == 1 and not list(tmp_path.iterdir())
    else:
        with pytest.raises(ContractError, match="NATIVE_EVIDENCE=") as failure:
            native_metrics(jobs, rscript="fixture-Rscript", evidence_root=tmp_path)
        root, = list(tmp_path.iterdir())
        assert str(root) in str(failure.value) and calls == [root]
        assert (root / "stdout.txt").read_bytes() == (b"" if mode == "launch" else stdout_bytes)
        assert (root / "stderr.txt").read_bytes() == (b"" if mode == "launch" else stderr_bytes)
        assert (root / "f4_metrics.R").read_bytes() == (Path(__file__).parents[1] / "padml/kernels/f4_metrics.R").read_bytes()
        record = strict_json_bytes((root / "failure.json").read_bytes())
        assert record["exit_code"] == (None if mode == "launch" else 7 if mode == "exit" else 0)


def test_native_metric_schema_failure_retains_real_r_frames_without_fitting(tmp_path):
    rscript = shutil.which("Rscript")
    if rscript is None:
        pytest.skip("native R not available")
    # Invalid shape is rejected before discrimination or calibration fits.
    job = {"label": "fixed-schema-rejection", "patient_ids": [], "survival": []}
    with pytest.raises(ContractError, match="fixed-schema-rejection"):
        native_metrics([job], rscript=rscript, evidence_root=tmp_path)
    root, = list(tmp_path.iterdir())
    assert (root / "native-failure.rda").is_file()
    assert (root / "native-session.txt").is_file()
    assert (root / "native-error.txt").is_file()
    result = subprocess.run([rscript, "--vanilla", "-e", (
        "e <- new.env(); load(commandArgs(TRUE)[[1L]], envir=e); "
        "x <- get('native-failure', envir=e); "
        "stopifnot(inherits(x, 'dump.frames'), any(grepl('evaluate_job', names(x)))); "
        "cat('NATIVE_FRAMES_REOPENED_NO_FIT')"
    ), str(root / "native-failure.rda")], capture_output=True, check=True)
    assert result.stdout == b"NATIVE_FRAMES_REOPENED_NO_FIT"


@pytest.mark.parametrize("domain", ["FIXED_MODEL_PAIRED", "POST_SELECTION_INBAG_OOB"])
def test_bootstrap_keeps_completed_coordinates_when_later_worker_fails(monkeypatch, tmp_path, domain):
    handoff = {"patient_ids": ["p1", "p2"], "centers": ["36", "38"]}
    plan = {"domain": domain, "replicate_count": 3,
            "root_seed": BOOTSTRAP_ROOTS[domain], "draws": [[0, 1], [1, 0], [0, 0]]}
    monkeypatch.setattr("padml.f4.bootstrap_draws", lambda *args, **kwargs: plan)
    returned = [{"replicate": index, "engineering_fixture_only": True} for index in (1, 2)]
    def failing_pool(worker, tasks, *, selected_slots, on_result):
        assert selected_slots == 2 and len(tasks) == 3 and on_result is not None
        assert worker.keywords["work_root"] == tmp_path
        on_result(1, returned[1])
        on_result(0, returned[0])
        raise ContractError("FIXTURE_THIRD_WORKER_FAILED")
    monkeypatch.setattr("padml.f4._bounded_ordered_spawn", failing_pool)
    with pytest.raises(ContractError, match="FIXTURE_THIRD_WORKER_FAILED"):
        if domain == "FIXED_MODEL_PAIRED":
            fixed_model_paired_bootstrap(handoff, b"response", replicate_count=3, workers=2, work_root=tmp_path)
        else:
            post_selection_bootstrap(handoff, b"response", {"RSF": True}, replicate_count=3, workers=2, work_root=tmp_path)
    assert sorted(path.name for path in tmp_path.iterdir()) == ["replicate-0001.zip", "replicate-0002.zip"]
    for row in returned:
        path = tmp_path / f"replicate-{row['replicate']:04d}.zip"
        entries = read_safe_zip(path, expected_members={"input.json", "result.json"})
        source = strict_json_bytes(entries["input.json"])
        assert source["replicate"] == row["replicate"]
        assert source["draw_indices"] == plan["draws"][row["replicate"] - 1]
        assert source["handoff_sha256"] == sha256_bytes(canonical_json_bytes(handoff))
        assert source["response_sha256"] == sha256_bytes(b"response")
        assert strict_json_bytes(entries["result.json"]) == row
        assert path.stat().st_mode & 0o777 == 0o600


def test_formal_f4_preserves_existing_work_and_does_not_retry_failures(monkeypatch, tmp_path):
    target = tmp_path / "result.zip"
    work = tmp_path / "result.zip.work"
    work.mkdir()
    saved = work / "previous-evidence"
    saved.write_bytes(b"preserved")
    monkeypatch.setattr("padml.f4.load_f4_inputs", lambda *args, **kwargs: {
        "handoff": {}, "response_csv": b"fixture", "selection_capabilities": [],
    })
    calls = []
    def failed_suite(*args, **kwargs):
        assert kwargs["work_root"] == work and work.is_dir()
        calls.append(kwargs)
        raise ContractError("FIXTURE_FAILURE_NO_SCIENTIFIC_EXECUTION")
    monkeypatch.setattr("padml.f4.evaluate_f4_suite", failed_suite)
    with pytest.raises(ContractError, match="FIXTURE_FAILURE_NO_SCIENTIFIC_EXECUTION"):
        execute(tmp_path, target, compile_f45_execution_contract_seal())
    assert len(calls) == 1 and saved.read_bytes() == b"preserved" and not target.exists()


def test_full_prediction_handoff_is_exact_and_response_free() -> None:
    values = models()
    handoff = collect_predictions(values)
    assert len(handoff["patient_ids"]) == 240
    assert len(set(handoff["patient_ids"])) == 240
    assert len(handoff["survival"]) == 7
    assert "55" not in handoff["centers"]
    assert "All_Cause_Death" not in canonical_json_bytes(handoff).decode()
    assert collect_predictions(list(reversed(values))) == handoff
    with pytest.raises(ContractError, match="F4_MODEL_GRID_INCOMPLETE"):
        collect_predictions(values[:-1])
    with pytest.raises(ContractError, match="F4_MODEL_GRID_INCOMPLETE"):
        collect_predictions(values[:-1] + values[:1])


def test_handoff_rejects_row_projection_selector_and_month_zero_drift() -> None:
    original = models()
    for field in ("row", "projection", "selector", "anchor"):
        values = copy.deepcopy(original)
        current = values[1]
        if field == "row":
            current["monthly_oof"]["predictions"].reverse()
            current["predictions"].reverse()
        elif field == "projection":
            current["predictions"][0]["survival"][0] = 0.4
        elif field == "selector":
            current["selector_evidence_sha256"] = "a" * 64
        else:
            current["monthly_oof"]["predictions"][0]["survival"][0] = 0.9
        rows = current["monthly_oof"]["predictions"]
        current["monthly_oof_sha256"] = _seal_prediction_matrix(
            [row["Patient_ID"] for row in rows], [row["survival"] for row in rows], HORIZONS
        )["sha256"]
        with pytest.raises(ContractError):
            collect_predictions(values)


def test_monthly_integration_matches_frozen_f2_and_extends_to_36() -> None:
    ids = [f"p{i}" for i in range(40)]
    outcome = response(ids, [50.0] * 40, [1] * 40)
    matrix = [[1.0] + [0.5] * 36 for _ in ids]
    context = censoring_context(ids, ["36"] * 40, outcome)
    metric = prediction_error(ids, matrix, context)
    frozen = _evaluate_prediction_seal(
        _seal_prediction_matrix(ids, matrix, HORIZONS), fit_response=outcome,
        evaluation_response=outcome,
        evaluation_context=_center_stratified_evaluation_context(outcome, ids, ["36"] * 40),
    )
    assert metric["ibs_0_to"]["24"] == frozen["ibs_0_24"]
    for horizon in REPORT_HORIZONS:
        assert metric["ibs_0_to"][str(horizon)] == (horizon - 0.5) * 0.25 / horizon
    assert metric["brier_monthly"][0] == 0
    assert context["rows"][24]["positive_weight_quantiles"] == [1.0] * 4


@pytest.mark.parametrize("change", ["time", "event", "order", "clone", "center", "invalid_time"])
def test_center_km_reuse_keeps_scope_support_and_exact_response_binding(monkeypatch, change):
    from padml import f4

    ids = [f"draw-997-{index}" for index in range(160)]
    centers = ["36"] * 80 + ["38"] * 80
    times = [0.25 if index % 80 == 0 else 12.0 if index % 2 else 50.0 for index in range(160)]
    events = [0 if index % 7 == 0 else 1 for index in range(160)]
    populations = [(ids, centers, response(ids, times, events)),
        (ids[:80], centers[:80], response(ids[:80], times[:80], events[:80])),
        (ids[80:], centers[80:], response(ids[80:], times[80:], events[80:]))]
    expected = [canonical_json_bytes(censoring_context(*population)) for population in populations]
    calls, cache = [], {}
    original = f4._censoring_survival_step
    def step(times, events):
        calls.append((times, events))
        return original(times, events)
    monkeypatch.setattr(f4, "_censoring_survival_step", step)
    observed = [censoring_context(*population, _center_step_cache=cache) for population in populations]
    assert [canonical_json_bytes(row) for row in observed] == expected
    assert len(calls) == len(cache) == 2
    assert observed[0]["rows"][24]["n_evaluable"] == sum(row["rows"][24]["n_evaluable"] for row in observed[1:])
    # Returned mutable contexts cannot poison the per-invocation immutable paths.
    observed[0]["censoring_steps"]["36"][1][0] = -1.0
    assert canonical_json_bytes(censoring_context(*populations[1], _center_step_cache=cache)) == expected[1]
    changed_ids, changed_centers = ids[:80], centers[:80]
    changed_times, changed_events = times[:80], events[:80]
    if change == "time":
        changed_times[1] = math.nextafter(changed_times[1], math.inf)
    elif change == "event":
        changed_events[1] = 0
    elif change == "order":
        changed_ids.reverse()
        changed_times.reverse()
        changed_events.reverse()
    elif change == "clone":
        changed_ids[0] = "draw-998-0"
    elif change == "center":
        changed_centers = ["39"] * 80
    else:
        changed_times[0] = -0.0
    changed = (changed_ids, changed_centers, response(changed_ids, changed_times, changed_events))
    if change == "invalid_time":
        before = len(calls)
        with pytest.raises(ContractError, match="F2_EVALUATION_RESPONSE_DOMAIN_INVALID"):
            censoring_context(*changed, _center_step_cache=cache)
        assert len(calls) == before and len(cache) == 2
        return
    fresh = canonical_json_bytes(censoring_context(*changed))
    before = len(calls)
    assert canonical_json_bytes(censoring_context(*changed, _center_step_cache=cache)) == fresh
    assert len(calls) == before + 1 and len(cache) == 3
    with pytest.raises(ContractError, match="F4_POPULATION_INVALID"):
        censoring_context([ids[0]] * 80, centers[:80], populations[1][2], _center_step_cache=cache)


def test_depleted_horizon_is_not_estimable_without_hiding_missing_or_nan() -> None:
    ids = [f"p{i}" for i in range(100)]
    outcome = response(ids, [1.0] * 60 + [2.0] * 40, [1] * 60 + [0] * 40)
    context = censoring_context(ids, ["36"] * 100, outcome)
    assert context["rows"][24]["ghat_left_by_center"] == {"36": 0.0}
    assert context["rows"][24]["status"] == "NOT_ESTIMABLE"
    assert "CENSORING_SUPPORT_BELOW_0_05" in context["rows"][24]["reasons"]
    matrix = [[1.0] + [0.5] * 36 for _ in ids]
    assert prediction_error(ids, matrix, context)["ibs_0_to"]["24"] is None
    matrix[0][4] = math.nan
    with pytest.raises(ContractError, match="PREDICTION_SEAL_INVALID"):
        prediction_error(ids, matrix, context)
    with pytest.raises(ContractError):
        censoring_context(ids[:-1], ["36"] * 99, outcome)


def test_parent_ipcw_retains_split_denominator_and_actual_support() -> None:
    parent_ids = [f"parent-{index}" for index in range(90)]
    centers = ["36"] * 80 + ["55"] * 10
    times = [12.0] * 40 + [50.0] * 40 + [12.0] * 5 + [50.0] * 5
    events = [1] * 80 + [0] * 10
    ids = parent_ids[:85]
    parent = (parent_ids, centers, response(parent_ids, times, events))
    outcome = response(ids, times[:85], events[:85])
    local = censoring_context(ids, centers[:85], outcome)
    fixed = censoring_context(ids, centers[:85], outcome, reference_population=parent)
    assert local["rows"][24]["ghat_right_by_center"]["55"] == 0.0
    row = fixed["rows"][24]
    assert row["status"] == "ESTIMABLE"
    assert row["ghat_right_by_center"] == {"36": 1.0, "55": 0.5}
    assert (row["n_events"], row["n_non_events"], row["n_censored"]) == (40, 40, 5)
    assert row["n_evaluable"] == row["effective_sample_size"] == 80
    matrix = [[1.0] + [0.5] * 36 for _ in ids]
    assert prediction_error(ids, matrix, local)["ibs_0_to"]["24"] is None
    metrics = prediction_error(ids, matrix, fixed)
    assert metrics["brier_monthly"][24] == 80 * 0.25 / 85
    assert fixed["censoring_reference"]["patient_count"] == 90
    assert fixed["censoring_reference"]["response_sha256"] == parent[2]["sha256"]
    # The actual R consumer receives the same fixed KM, without refitting it.
    evaluation = evaluate_predictions(
        {"horizons": HORIZONS, "patient_ids": ids, "centers": centers[:85],
         "survival": {"COX_PH": matrix}}, outcome["private_bytes"],
        include_center_scopes=False, reference_population=parent,
    )
    scope = evaluation["scopes"][0]
    assert scope["patient_count"] == 85
    assert scope["censoring_reference"] == fixed["censoring_reference"]
    assert scope["ipcw_qc"][24]["ghat_right_by_center"] == row["ghat_right_by_center"]
    assert scope["families"]["COX_PH"]["brier_monthly"] == metrics["brier_monthly"]


def test_parent_ipcw_requires_actual_source_identity_and_preserves_clones() -> None:
    source_ids = [f"source-{index}" for index in range(40)]
    parent = (source_ids, ["36"] * 40, response(source_ids, [50.0] * 40, [1] * 40))
    ids = [f"clone-{index}" for index in range(80)]
    sources = source_ids * 2
    outcome = response(ids, [50.0] * 80, [1] * 80)
    fixed = censoring_context(ids, ["36"] * 80, outcome,
                              reference_population=parent, source_patient_ids=sources)
    assert fixed["rows"][24]["n_evaluable"] == 80
    assert fixed["rows"][24]["effective_sample_size"] == 80
    assert fixed["censoring_reference"]["patient_count"] == 40
    for bad_sources, bad_centers, bad_outcome in (
        (["unknown"] + sources[1:], ["36"] * 80, outcome),
        (sources, ["55"] + ["36"] * 79, outcome),
        (sources, ["36"] * 80, response(ids, [49.0] + [50.0] * 79, [1] * 80)),
    ):
        with pytest.raises(ContractError, match="F4_IPCW_REFERENCE_RESPONSE_OR_CENTER_MISMATCH"):
            censoring_context(ids, bad_centers, bad_outcome,
                              reference_population=parent, source_patient_ids=bad_sources)
    with pytest.raises(ContractError, match="F4_IPCW_REFERENCE_RESPONSE_OR_CENTER_MISMATCH"):
        censoring_context(source_ids, ["36"] * 40, parent[2],
                          reference_population=parent, source_patient_ids=list(reversed(source_ids)))
    with pytest.raises(ContractError, match="F4_IPCW_REFERENCE_POPULATION_REQUIRED"):
        censoring_context(ids, ["36"] * 80, outcome, source_patient_ids=sources)
    with pytest.raises(ContractError, match="F4_IPCW_REFERENCE_RESPONSE_OR_CENTER_MISMATCH"):
        censoring_context(ids, ["36"] * 80, outcome, reference_population=parent)


def test_ipcw_ess_threshold_uses_the_evaluable_population() -> None:
    ids = [f"ess-{index:03d}" for index in range(300)]
    outcome = response(
        ids,
        [6.0] * 100 + [12.0] * 180 + [50.0] * 20,
        [1] * 100 + [0] * 200,
    )
    row = censoring_context(ids, ["36"] * 300, outcome)["rows"][24]
    assert row["n_evaluable"] == 120
    assert row["effective_sample_size"] == pytest.approx(300**2 / 2100)
    assert row["status"] == "ESTIMABLE"
    assert "EFFECTIVE_SAMPLE_SIZE_INSUFFICIENT" not in row["reasons"]


def test_late_nonestimability_does_not_invalidate_primary_horizon() -> None:
    ids = [f"p{i}" for i in range(100)]
    outcome = response(ids, [30.0] * 60 + [32.0] * 40, [1] * 60 + [0] * 40)
    context = censoring_context(ids, ["36"] * 100, outcome)
    metric = prediction_error(ids, [[1.0] + [0.5] * 36 for _ in ids], context)
    assert metric["ibs_0_to"]["24"] == (24 - 0.5) * 0.25 / 24
    assert metric["ibs_0_to"]["36"] is None


def test_dca_raw_integral_dominance_and_signed_shadow() -> None:
    ids = [f"p{i}" for i in range(100)]
    outcome = response(ids, [12.0] * 50 + [50.0] * 50, [1] * 100)
    context = censoring_context(ids, ["36"] * 100, outcome)
    perfect = [[1.0] + [0.6 if i < 50 else 0.98] * 36 for i in range(100)]
    result = decision_curve(ids, perfect, context)
    assert result["thresholds"] == list(DCA_THRESHOLDS)
    assert len(result["curve"]) == 26
    assert result["integrated_raw_nb"] == pytest.approx(0.5)
    assert result["dominance_fraction"] == 1.0
    assert result["shadow_selection_effect"] == "NONE"
    assert all(row["standardized_net_benefit"] == 1.0 for row in result["curve"])

    # Treat-all has positive NB here but never strictly dominates itself.
    all_positive = [[1.0] + [0.6] * 36 for _ in ids]
    equivalent = decision_curve(ids, all_positive, context)
    assert all(row["net_benefit"] > 0 for row in equivalent["curve"])
    assert equivalent["dominance_fraction"] == 0.0
    assert equivalent["integrated_shadow_nb"] == 0.0
    poor = decision_curve(ids, list(reversed(perfect)), context)
    assert poor["integrated_raw_nb"] < 0
    assert poor["integrated_shadow_nb"] < 0  # Never clip the shadow at zero.


def test_dca_censoring_ties_and_threshold_boundary_match_literal_r_formula() -> None:
    rscript = shutil.which("Rscript")
    if rscript is None:
        pytest.skip("Rscript unavailable for independent DCA numerical oracle")
    ids = [f"p{i}" for i in range(80)]
    outcome = response(ids, [6.0] * 40 + [24.0] * 20 + [40.0] * 20, [1] * 20 + [0] * 20 + [1] * 20 + [0] * 20)
    context = censoring_context(ids, ["36"] * 80, outcome)
    matrix = [[1.0] + [value] * 36 for value in [0.75] * 20 + [0.5] * 20 + [0.6] * 20 + [0.9] * 20]
    result = decision_curve(ids, matrix, context)
    assert context["rows"][24]["weights"] == pytest.approx([1.0] * 20 + [0.0] * 20 + [1.5] * 40)
    # Literal historical R arithmetic, with independently specified tied KM
    # weights. No Python DCA helper or generated expected value is reused.
    oracle = subprocess.run([rscript, "--vanilla", "-e", r'''
      # Frozen F2 removes the 20 tied events before the 20 censorings:
      # G(6)=1-20/(80-20), while an event at 6 receives G(6-)=1.
      wg <- 1/(1-20/(80-20))
      w <- rep(c(1, 0, wg, wg), each=20)
      y <- rep(c(1, 0, 1, 0), each=20)
      risk <- 1-rep(c(.75, .5, .6, .9), each=20)
      p <- sum(w*y)/80
      thresholds <- (5:30)/100
      z <- t(vapply(thresholds, function(t) {
        pos <- risk >= t
        nb <- sum(w*pos*y)/80-sum(w*pos*(1-y))/80*t/(1-t)
        all <- p-(1-p)*t/(1-t)
        c(nb, all, nb/p, (nb-all)*(1-t)/t*100,
          (nb-max(all,0))/p, as.numeric(nb>max(all,0)))
      }, numeric(6)))
      cat(sprintf("%.17g", as.vector(t(z))), sep=" ")
    '''], capture_output=True, text=True, check=True)
    expected = [float(value) for value in oracle.stdout.split()]
    observed = [row[key] for row in result["curve"] for key in (
        "net_benefit", "treat_all", "standardized_net_benefit",
        "net_reduction_per_100", "shadow_net_benefit", "dominates",
    )]
    assert observed == pytest.approx(expected, rel=1e-13, abs=1e-13)
    assert result["curve"][20]["threshold"] == 0.25
    assert result["curve"][20]["net_benefit"] > result["curve"][21]["net_benefit"]


def test_dca_support_zero_prevalence_and_numeric_errors_are_distinct() -> None:
    ids = [f"p{i}" for i in range(80)]
    matrix = [[1.0] + [0.5] * 36 for _ in ids]
    zero = censoring_context(ids, ["36"] * 80, response(ids, [50.0] * 80, [1] * 80))
    result = decision_curve(ids, matrix, zero)
    assert result["status"] == "ESTIMABLE"
    assert result["integrated_raw_nb"] < 0
    assert result["standardization_reason"] == "ZERO_IPCW_PREVALENCE"
    assert result["integrated_shadow_nb"] is None
    assert all(row["standardized_net_benefit"] is None for row in result["curve"])
    depleted = censoring_context(ids, ["36"] * 80, response(ids, [1.0] * 40 + [2.0] * 40, [1] * 40 + [0] * 40))
    unsupported = decision_curve(ids, matrix, depleted)
    assert unsupported["status"] == "NOT_ESTIMABLE"
    assert unsupported["integrated_raw_nb"] is None
    assert unsupported["curve"] == []
    matrix[0][24] = math.nan
    with pytest.raises(ContractError, match="PREDICTION_SEAL_INVALID"):
        decision_curve(ids, matrix, depleted)


def calibration_job() -> dict:
    ids = [f"p{i}" for i in range(80)]
    # Each risk has one event and one control: observed calibration is 0.5
    # everywhere, independently of the fitted risk. No patient data are used.
    outcome = response(ids, [2.0 if i % 2 else 50.0 for i in range(80)], [1] * 80)
    context = censoring_context(ids, ["36"] * 80, outcome)
    return {"label": "SYNTHETIC/COX_PH", "patient_ids": ids,
        "times": context["times"], "events": context["events"],
        "centers": context["centers"], "censoring_steps": context["censoring_steps"],
        "survival": [[0.89 - 0.02 * (i // 2)] * 4 for i in range(80)],
        "ipcw": [context["rows"][h] for h in REPORT_HORIZONS]}


def test_native_calibration_matches_symmetric_closed_form_without_feedback() -> None:
    job = calibration_job()
    before = canonical_json_bytes(job)
    result, = native_metrics([job])
    for horizon in REPORT_HORIZONS:
        row = result["horizons"][str(horizon)]
        assert row["status"] == "ESTIMABLE"
        assert row["citl"] == pytest.approx(0, abs=1e-12)
        assert row["slope"] == pytest.approx(0, abs=1e-12)
        assert row["oe"] == pytest.approx(1, abs=1e-12)
        assert row["ici"] == pytest.approx(0.2, abs=1e-12)
        assert row["e50"] == pytest.approx(0.19, abs=1e-12)
        assert row["e90"] == pytest.approx(0.37, abs=1e-12)
        assert row["curve"]["calibrated_risk"] == pytest.approx([0.5] * 80, abs=1e-12)
        assert row["warnings"] == []
    assert result["aggregate"]["ici"] == pytest.approx(0.2, abs=1e-12)
    # Literal R cumsum of 1/320 lies just below 0.5 at row 160 on this
    # runtime; the registered >= rule selects 0.21, without a new tolerance.
    oracle = subprocess.run(["Rscript", "--vanilla", "-e", r'''
      e <- rep(rep(abs(.5-(.11+.02*(0:39))),each=2),4)
      w <- rep(1,320); o <- order(e); z <- cumsum((w/sum(w))[o])
      cat(sprintf("%.17g",e[o][which(z>=.5)[1]]))
    '''], capture_output=True, text=True, check=True)
    assert result["aggregate"]["e50"] == pytest.approx(float(oracle.stdout), abs=1e-12)
    assert result["aggregate"]["e90"] == pytest.approx(0.35, abs=1e-12)
    assert result["aggregate"]["estimable_horizons"] == list(REPORT_HORIZONS)
    assert result["discrimination"]["uno_c_24"]["value"] == 0.5
    assert result["discrimination"]["harrell_c"]["value"] == 0.5
    assert all(row["value"] == 0.5 for row in result["discrimination"]["auc"].values())
    assert canonical_json_bytes(job) == before


def test_native_gaussian_loess_overshoot_is_descriptive_not_illegal_probability():
    ids = [f"overshoot-{i:03d}" for i in range(200)]
    events = [int(i >= 100) for i in range(200)]
    events[40], events[160] = 1, 0
    outcome = response(ids, [2.0 if event else 50.0 for event in events], [1] * 200)
    context = censoring_context(ids, ["36"] * 200, outcome)
    job = {"label": "SYNTHETIC/OVERSHOOT", "patient_ids": ids,
           "times": context["times"], "events": context["events"],
           "centers": context["centers"], "censoring_steps": context["censoring_steps"],
           "survival": [[1 - (0.01 + 0.98 * i / 199)] * 4 for i in range(200)],
           "ipcw": [context["rows"][h] for h in REPORT_HORIZONS]}
    original = canonical_json_bytes(job)
    result, = native_metrics([job])
    for row in result["horizons"].values():
        report = row["smoother"]
        assert report["below_zero_count"] + report["above_one_count"] > 0
        assert report["clipping"] is False
        assert min(row["curve"]["calibrated_risk"]) == report["minimum"]
        assert max(row["curve"]["calibrated_risk"]) == report["maximum"]
        assert math.isfinite(row["ici"])
    assert canonical_json_bytes(job) == original


def test_native_secondary_36_support_does_not_create_partial_four_horizon_summary():
    job = calibration_job()
    job["times"] = [2.0 if i % 2 else 30.0 for i in range(80)]
    job["events"] = [int(i % 2) for i in range(80)]
    context = censoring_context(job["patient_ids"], job["centers"],
                                response(job["patient_ids"], job["times"], job["events"]))
    job["censoring_steps"] = context["censoring_steps"]
    job["ipcw"] = [context["rows"][h] for h in REPORT_HORIZONS]
    result, = native_metrics([job])
    assert result["horizons"]["24"]["status"] == "ESTIMABLE"
    assert result["horizons"]["36"]["status"] == "NOT_ESTIMABLE"
    assert result["aggregate"]["estimable_horizons"] == [6, 12, 24]
    assert result["aggregate"]["status"] == "NOT_ESTIMABLE"
    assert result["aggregate"]["ici"] is result["aggregate"]["e50"] is result["aggregate"]["e90"] is None


def test_native_calibration_keeps_each_horizon_error_distribution_separate() -> None:
    job = calibration_job()
    risks = [
        [0.05 + 0.005 * (index // 2) for index in range(80)],
        [0.15 + 0.005 * (index // 2) for index in range(80)],
        [0.25 + 0.005 * (index // 2) for index in range(80)],
        [0.35 + 0.005 * (index // 2) for index in range(80)],
    ]
    job["survival"] = [
        [1.0 - risks[horizon][patient] for horizon in range(4)]
        for patient in range(80)
    ]

    result, = native_metrics([job])
    observed = []
    for index, horizon in enumerate(REPORT_HORIZONS):
        row = result["horizons"][str(horizon)]
        errors = sorted(abs(0.5 - value) for value in risks[index])
        observed.append(row["ici"])
        assert row["ici"] == pytest.approx(math.fsum(errors) / 80, abs=1e-12)
        assert row["e50"] == pytest.approx(errors[39], abs=1e-12)
        # Literal R cumsum of 1/80 is just below 0.90 at row 72 on
        # this runtime, so the registered >= rule selects row 73.
        assert row["e90"] == pytest.approx(errors[72], abs=1e-12)
    assert len(set(observed)) == 4


def test_calibration_support_is_separate_from_numeric_or_missing_errors() -> None:
    job = calibration_job()
    ids = job["patient_ids"]
    context = censoring_context(ids, ["36"] * 80, response(ids, [50.0] * 80, [1] * 80))
    job["ipcw"] = [context["rows"][h] for h in REPORT_HORIZONS]
    job.update(times=context["times"], events=context["events"],
               censoring_steps=context["censoring_steps"])
    result, = native_metrics([job])
    assert result["aggregate"]["status"] == "NOT_ESTIMABLE"
    for row in result["horizons"].values():
        assert row["reasons"] == ["CASES_BELOW_20"]
        assert all(row[field] is None for field in ("citl", "ici", "e50", "e90"))
        assert row["curve"] is None
    # Invalid curves fail even when case support would otherwise exclude them.
    job["survival"][0][0] = 1.01
    with pytest.raises(ContractError, match="F4_CALIBRATION_INPUT_INVALID"):
        native_metrics([job])
    job = calibration_job()
    job["survival"] = [[0.5] * 4 for _ in ids]
    constant, = native_metrics([job])
    for row in constant["horizons"].values():
        assert row["status"] == "NOT_ESTIMABLE"
        assert row["reasons"] == [
            "CONSTANT_RISK_CALIBRATION_NOT_IDENTIFIABLE"
        ]
        assert all(
            row[field] is None
            for field in ("citl", "oe", "slope", "ici", "e50", "e90")
        )
    assert constant["discrimination"]["harrell_c"]["status"] == "ESTIMABLE"


def test_calibration_only_localizes_the_registered_constant_risk_case() -> None:
    kernel = (
        Path(__file__).resolve().parents[1] / "padml/kernels/f4_metrics.R"
    ).read_text()
    evaluation_body = kernel.split("if (sys.nframe() == 0L)", 1)[0]
    assert "CONSTANT_RISK_CALIBRATION_NOT_IDENTIFIABLE" in evaluation_body
    assert "calibration_failure" not in evaluation_body
    assert "error = function(e)" not in evaluation_body

    job = calibration_job()
    for support in job["ipcw"]:
        support["weights"] = [0.0] * len(job["patient_ids"])
    with pytest.raises(ContractError, match="F4_NATIVE_METRICS_COMPUTATION_ERROR"):
        native_metrics([job])


def test_native_discrimination_uses_exact_weighted_pairs_and_risk_ties() -> None:
    ids = [f"p{i}" for i in range(80)]
    outcome = response(ids, [6.0] * 40 + [24.0] * 20 + [40.0] * 20,
                       [1] * 20 + [0] * 20 + [1] * 20 + [0] * 20)
    context = censoring_context(ids, ["36"] * 80, outcome)
    source = {
        "survival": [[value] * 4 for value in [0.2] * 20 + [0.1] * 20 + [0.6] * 40],
        "times": context["times"], "events": context["events"],
        "centers": context["centers"], "censoring_steps": context["censoring_steps"],
        "ipcw": [context["rows"][h] for h in REPORT_HORIZONS],
    }
    # Run the numerical helper without fitting calibration on this deliberately
    # separated outcome pattern; its pairwise expectations are computed by hand.
    completed = subprocess.run(["Rscript", "--vanilla", "-e", r'''
      source(commandArgs(TRUE)[[1]])
      x <- fromJSON(file("stdin"),simplifyVector=FALSE)
      s <- do.call(rbind,lapply(x$survival,unlist,use.names=FALSE))
      out <- discriminate(s,unlist(x$times),unlist(x$events),x$ipcw,
                          x$centers,x$censoring_steps)
      cat(toJSON(out,auto_unbox=TRUE,null="null",digits=NA))
    ''', str(Path(__file__).resolve().parents[1] / "padml/kernels/f4_metrics.R")],
        input=canonical_json_bytes(source), capture_output=True, check=True)
    result = json.loads(completed.stdout)
    # 20 early cases have weight 1; later cases/controls weight 1.5.
    # Strict Uno pairs use event-left times control-right censoring weights:
    # early pairs weigh 1.5, later tied-risk pairs 2.25. AUC is unchanged.
    assert result["auc"]["24"]["value"] == pytest.approx((600 + 450) / 1500, abs=1e-13)
    assert result["uno_c_24"]["value"] == pytest.approx((1200 + 450) / 2100, abs=1e-13)
    assert result["risk_score_common"][:20] == pytest.approx([-math.log(0.2)] * 20)
    assert result["risk_score_common"][-40:] == pytest.approx([-math.log(0.6)] * 40)


@pytest.mark.parametrize("fixture", ["different_centers", "event_censor_ties", "no_censoring"])
def test_uno_uses_both_subjects_center_censoring_distributions(fixture) -> None:
    if fixture == "different_centers":
        times = [2] * 10 + [6] * 20 + [40] * 30 + [4] * 20 + [10] * 10 + [40] * 30
        events = [0] * 10 + [1] * 70 + [0] * 10 + [1] * 30
        centers = ["36"] * 60 + ["38"] * 60
        survival = [.1] * 10 + [.2] * 20 + [.7] * 30 + [.6] * 20 + [.1] * 10 + [.4] * 30
    else:
        times = [6] * 40 + [24] * 20 + [40] * 20
        events = ([1] * 20 + [0] * 20 + [1] * 20 + [0] * 20
                  if fixture == "event_censor_ties" else [1] * 80)
        centers = ["36"] * 80
        survival = [.2] * 20 + [.1] * 20 + [.6] * 40
    ids = [f"synthetic-{i}" for i in range(len(times))]
    context = censoring_context(ids, centers, response(ids, times, events))
    source = {"times": times, "events": events, "centers": centers,
              "censoring_steps": context["censoring_steps"],
              "survival": [[value] * 4 for value in survival],
              "ipcw": [context["rows"][h] for h in REPORT_HORIZONS]}
    completed = subprocess.run(["Rscript", "--vanilla", "-e", r'''
      source(commandArgs(TRUE)[[1]])
      x <- fromJSON(file("stdin"),simplifyVector=FALSE)
      s <- do.call(rbind,lapply(x$survival,unlist,use.names=FALSE))
      cat(toJSON(discriminate(s,unlist(x$times),unlist(x$events),x$ipcw,
                            x$centers,x$censoring_steps),
                 auto_unbox=TRUE,null="null",digits=NA))
    ''', str(Path(__file__).resolve().parents[1] / "padml/kernels/f4_metrics.R")],
        input=canonical_json_bytes(source), capture_output=True, check=True)
    observed = json.loads(completed.stdout)["uno_c_24"]["value"]

    def literal_g(center, horizon, left):
        indices = [i for i, value in enumerate(centers) if value == center]
        value = Fraction(1)
        for t in sorted({times[i] for i in indices}):
            if t > horizon or (left and t == horizon):
                break
            risk = sum(times[i] >= t for i in indices)
            deaths = sum(times[i] == t and events[i] == 1 for i in indices)
            censored = sum(times[i] == t and events[i] == 0 for i in indices)
            if censored:
                value *= Fraction(risk - deaths - censored, risk - deaths)
        return value

    numerator = denominator = old_numerator = old_denominator = Fraction(0)
    for i in range(len(times)):
        if events[i] != 1 or times[i] > 24:
            continue
        gi = literal_g(centers[i], times[i], True)
        for j in range(len(times)):
            if times[j] <= times[i]:  # Keep the project's strict pair set.
                continue
            weight = 1 / (gi * literal_g(centers[j], times[i], False))
            comparison = Fraction(int(survival[i] < survival[j])) + Fraction(
                int(survival[i] == survival[j]), 2)
            numerator += weight * comparison
            denominator += weight
            old_numerator += comparison / gi**2
            old_denominator += 1 / gi**2
    expected = float(numerator / denominator)
    assert observed == pytest.approx(expected, abs=1e-13)
    if fixture != "no_censoring":
        assert expected != pytest.approx(float(old_numerator / old_denominator), abs=1e-6)


@pytest.mark.parametrize("damage", ["centers", "censoring_steps", "negative_g"])
def test_uno_context_errors_are_not_reported_as_nonestimability(damage) -> None:
    job = calibration_job()
    if damage == "negative_g":
        job["censoring_steps"]["36"][1][0] = -0.1
    else:
        del job[damage]
    with pytest.raises(ContractError, match="F4_UNO_CENSORING_CONTEXT_INVALID"):
        native_metrics([job])


def test_direct_evaluation_has_no_selection_or_stage_acceptance() -> None:
    handoff = collect_predictions(models())
    raw = ("Patient_ID,All_Cause_Death,Death_Followup_months\n" + "".join(
        f"{patient_id},1,50\n" for patient_id in handoff["patient_ids"]
    )).encode()
    result = evaluate_predictions(handoff, raw)
    assert result["selection_effect"] == "NONE"
    assert result["stage_acceptance"] is False
    assert result["model_refit_count"] == 0
    assert len(result["scopes"]) == 7
    assert result["macro"]["COX_PH"]["24"]["total_center_count"] == 6
    assert result["macro"]["COX_PH"]["24"]["equal_center_ibs"] == result["scopes"][0]["families"]["COX_PH"]["ibs_0_to"]["24"]
    assert "DCA_24_RAW_AND_SIGNED_SHADOW" in result["computed_scope"]
    assert result["macro"]["COX_PH"]["24"]["equal_center_raw_dca"] == pytest.approx(result["scopes"][0]["families"]["COX_PH"]["dca_24"]["integrated_raw_nb"])
    assert result["macro"]["COX_PH"]["24"]["equal_center_shadow_dca"] is None
    assert result["scopes"][0]["families"]["COX_PH"]["discrimination"]["uno_c_24"]["value"] is None
    assert result["scopes"][0]["families"]["COX_PH"]["discrimination"]["harrell_c"]["reason"] == "NO_COMPARABLE_PAIRS"


def test_full_native_fixed_family_evaluation_joins_all_six_center_metrics() -> None:
    values = models()
    for model in values:
        ids = [row["Patient_ID"] for row in model["monthly_oof"]["predictions"]]
        matrix = [[1.0] + [0.88 - 0.04 * (i // 2)] * 36 for i in range(40)]
        model["monthly_oof"]["predictions"] = [
            {"Patient_ID": pid, "survival": curve} for pid, curve in zip(ids, matrix, strict=True)]
        model["monthly_oof_sha256"] = _seal_prediction_matrix(ids, matrix, HORIZONS)["sha256"]
        model["predictions"] = [{"Patient_ID": pid, "survival": [curve[h] for h in REPORT_HORIZONS]}
                                for pid, curve in zip(ids, matrix, strict=True)]
    handoff = collect_predictions(values)
    raw = ("Patient_ID,All_Cause_Death,Death_Followup_months\n" + "".join(
        f"{pid},1,{2 if int(pid.split('p')[1]) % 2 else 50}\n" for pid in handoff["patient_ids"])).encode()
    result = evaluate_predictions(handoff, raw)
    assert result["kind"] == "PADML_F4_FIXED_FAMILY_EVALUATION"
    assert result["stage_acceptance"] is False and result["selection_effect"] == "NONE"
    for family in result["macro"]:
        primary = result["macro"][family]["24"]
        assert primary["total_center_count"] == 6
        assert primary["center_gap_ibs"] == 0
        assert primary["equal_center_auc"] == primary["equal_center_uno_c"] == 0.5
        assert primary["mean_absolute_slope_error"] == pytest.approx(1.0, abs=1e-12)
        assert primary["mean_absolute_citl"] < 1e-12
        assert primary["equal_center_oe"] == pytest.approx(1.0, abs=1e-12)
        assert result["macro"][family]["all_followup"]["equal_center_harrell_c"] == 0.5


def test_native_sparse_centers_keep_null_macro_secondary_and_valid_pooled_a15():
    families = load_science_authority()["science"]["families"]
    centers = [str(center) for center in (36, 38, 39, 48, 52, 54) for _ in range(80)]
    ids = [f"synthetic-sparse-{index:04d}" for index in range(480)]
    sparse_events = {"38": 11, "48": 13}
    times = [2.0 if index % 80 % 2 and index % 80 // 2 < sparse_events.get(center, 40)
             else 50.0 for index, center in enumerate(centers)]
    matrix = [[1.0] + [0.89 - 0.02 * (index % 80 // 2)] * 36 for index in range(480)]
    handoff = {"patient_ids": ids, "centers": centers, "horizons": HORIZONS.copy(),
               "survival": {family: matrix for family in families}}
    result = evaluate_predictions(handoff, response(ids, times, [1] * 480)["private_bytes"])
    for values in result["macro"].values():
        assert values["24"]["mean_absolute_slope_error"] is None
        assert values["24"]["equal_center_uno_c"] is None
        assert math.isfinite(values["24"]["pooled_absolute_slope_error"])
        assert math.isfinite(values["24"]["pooled_uno_c"])
    from padml.f4 import _bootstrap_metric_support
    support = _bootstrap_metric_support(result, _macro_bootstrap_metrics(result, sorted(set(centers))))
    deficient = {row["scope"]: row for row in support["COX_PH"]["uno_c_24"]["support"]}
    assert deficient["38"]["ipcw_qc"]["n_events"] == 11
    assert deficient["48"]["ipcw_qc"]["n_events"] == 13
    assert support["COX_PH"]["ibs_0_24"]["status"] == "ESTIMABLE"
    assert select_a15(result["macro"], {family: True for family in families})["selected_family"] == "COX_PH"


def test_native_entry_stops_without_existing_f2_acceptance(tmp_path: Path) -> None:
    run = {"run_id": "not-accepted"}
    run["identity"] = sha256_bytes(canonical_json_bytes(run))
    (tmp_path / "run.json").write_bytes(canonical_json_bytes(run))
    with pytest.raises(ContractError, match="F4_F2_NOT_ACCEPTED"):
        execute(
            tmp_path,
            tmp_path / "result.zip",
            compile_f45_execution_contract_seal(),
        )
    assert not (tmp_path / "result.zip").exists()


def test_mixed_center_censoring_matches_frozen_primary_metric() -> None:
    ids = [f"p{i}" for i in range(240)]
    centers = [str(36 + i // 40) for i in range(240)]
    outcome = response(ids, [float(2 + i % 59) for i in range(240)], [0 if i % 4 == 0 else 1 for i in range(240)])
    matrix = [[math.exp(-0.003 * (i % 9 + 1) * h) for h in HORIZONS] for i in range(240)]
    observed = prediction_error(ids, matrix, censoring_context(ids, centers, outcome))
    frozen = _evaluate_prediction_seal(
        _seal_prediction_matrix(ids, matrix, HORIZONS), fit_response=outcome,
        evaluation_response=outcome,
        evaluation_context=_center_stratified_evaluation_context(outcome, ids, centers),
    )
    assert observed["ibs_0_to"]["24"] == frozen["ibs_0_24"]
    invalid = response(ids, [math.nan] + [40.0] * 239, [1] * 240)
    with pytest.raises(ContractError, match="RESPONSE_DOMAIN_INVALID"):
        censoring_context(ids, centers, invalid)


def native_fixture(root: Path, drift: str | None) -> tuple[Path, Path]:
    """Exercise native ZIP/replay consumers with synthetic prediction/outcome rows.

    Only existing F1 manifest/binding metadata are reused; no real patient
    outcomes or model fits are evaluated. This is not a stage-acceptance test.
    """
    runtime = Path("/Users/liuningyuan/Desktop/PAD/PADML_F2_V1_Runtime")
    if not (runtime / "build/f1-replay-seal.zip").is_file():
        pytest.skip("native F1 metadata unavailable")
    run_root = root / "runs/f4-fixture"
    (run_root / "results").mkdir(parents=True)
    (root / "input/f1").mkdir(parents=True)
    (root / "build").mkdir()
    shutil.copyfile(runtime / "input/f1/input-manifest.json", root / "input/f1/input-manifest.json")
    original = read_safe_zip(runtime / "build/f1-replay-seal.zip")
    original_seal = strict_json_bytes(original["manifest.json"])
    common = runtime / "build/common-input.zip"
    requests = materialize_requests(run_id="f4-fixture", source_identity="1" * 64, runtime_identity="2" * 64, worker_identity="3" * 64, input_identity="4" * 64)
    grid = {(row["fold"], row["family"]): row for row in models()}
    hashes = {unit_id: "a" * 64 for unit_id in canonical_unit_ids()}
    for unit_id in canonical_unit_ids()[:42]:
        request = requests[unit_id]
        coordinate = {row["axis"]: row["value"] for row in request["plan"]["coordinates"]}
        payload = canonical_json_bytes(grid[coordinate["outer_fold"], coordinate["family"]])
        artifact = {**request["artifacts"][0], "sha256": sha256_bytes(payload), "size_bytes": len(payload), "status": "OK"}
        manifest = {**request, "kind": "result", "artifacts": [artifact], "terminal": {"status": "COMPLETED", "reason_code": "OK", "message_sha256": None}}
        target = run_root / "results" / f"{unit_id}.zip"
        write_deterministic_zip(target, {"manifest.json": canonical_json_bytes(manifest), artifact["relative_path"]: payload})
        hashes[unit_id] = sha256_file(target)
    ids = collect_predictions(models())["patient_ids"]
    paths = []
    for suffix, time in (("original", 50.0), ("changed", 12.0)):
        data = response(ids, [time] * len(ids), [1] * len(ids))["private_bytes"]
        seal = {key: value for key, value in original_seal.items() if key != "identity"}
        seal.update(response_seal_sha256=sha256_bytes(data), response_size_bytes=len(data), common_input_sha256=sha256_file(common))
        seal["identity"] = sha256_bytes(canonical_json_bytes(seal))
        path = root / "build" / f"{suffix}.zip"
        write_deterministic_zip(path, {"manifest.json": canonical_json_bytes(seal), "binding-contract.json": original["binding-contract.json"], "response-seal.csv": data})
        paths.append(path)
    expected, changed = paths
    run = {
        "run_id": "f4-fixture", "f1_identity": original_seal["f1_input_manifest_identity"],
        "common_input": {"path": str(common), "sha256": sha256_file(common), "size_bytes": common.stat().st_size},
        "replay_seal": {"path": str(changed if drift == "replay" else expected), "sha256": sha256_file(expected), "size_bytes": expected.stat().st_size},
    }
    if drift == "common":
        run["common_input"]["sha256"] = "0" * 64
    run["identity"] = sha256_bytes(canonical_json_bytes(run))
    (run_root / "run.json").write_bytes(canonical_json_bytes(run))
    acceptance = {"status": "SCIENTIFICALLY_ACCEPTED", "run_identity": run["identity"], "stage_validation": {"outcome": "PASS"}, "unit_count": 46, "result_sha256": hashes}
    acceptance["identity"] = sha256_bytes(canonical_json_bytes(acceptance))
    (run_root / "f2-acceptance.json").write_bytes(canonical_json_bytes(acceptance))
    return run_root, root / "f4-result.zip"


@pytest.mark.parametrize("drift", [None, "replay", "common"])
@pytest.mark.parametrize("workers", [24, 56])
def test_native_accepted_run_rejects_response_or_patient_binding_drift(
    tmp_path: Path, drift: str | None, monkeypatch, workers,
) -> None:
    run_root, target = native_fixture(tmp_path, drift)
    calls = []

    def formal_suite(handoff, response_csv, capabilities, **options):
        calls.append((capabilities, options))
        return {
            **evaluate_predictions(handoff, response_csv),
            "kind": "PADML_F4_COMPLETE_FIXED_PREDICTION_SUITE_V1",
            "status": "COMPUTED_AWAITING_REVIEW",
        }

    monkeypatch.setattr("padml.f4.evaluate_f4_suite", formal_suite)
    if drift is None:
        # Synthetic prediction IDs do not belong to this retained F1 binding;
        # a self-consistent response ZIP alone must not admit that join.
        with pytest.raises(ContractError, match="F4_FROZEN_PATIENT_CENTER_JOIN_MISMATCH"):
            execute(run_root, target, compile_f45_execution_contract_seal(), workers=workers)
        assert not calls and not target.exists()
    else:
        with pytest.raises(ContractError, match="F4_FROZEN_F1_OBJECT_DRIFT"):
            execute(
                run_root, target,
                compile_f45_execution_contract_seal(), workers=workers,
            )
        assert not target.exists()
