"""Real RSF terminal suffix and original numerical consumer, UNFITTED leaves.

The inherited Linux fixture uses R/jsonlite for synthetic input preparation;
all model leaves remain the existing explicit UNFITTED leaves.
"""
import copy

import pytest

from padml import f4, f5, f2_kernel as kernel
from padml.bundle import ContractError, strict_json_bytes
from test_nested_aar_mice import aar_source  # noqa: F401
from test_primary_rsf_score_compilation import (
    test_primary12_public_archive_preserves_q_through_original_input_reader as original_case,
)


def test_scoped_pending_rsf_suffix_reaches_original_terminal_consumer(aar_source, tmp_path, monkeypatch):
    original_prepare = f5._prepare_primary_outer_rsf_search
    reached = []

    def scoped_prepare(projected, root, policy, **kwargs):
        if kwargs.get("_execution_batch_root") is None:
            return original_prepare(projected, root, policy, **kwargs)
        carrier = tmp_path / "whole-outer-pre-search.zip"
        f4.compile_o_fit_bundle(tmp_path, carrier, outer_fold=1,
            science_decision=projected["science_decision"], resource_policy=policy,
            retained_bytes_per_component=kwargs["retained_bytes_per_task"],
            expanded_bytes_per_component=10**6, shared_storage_bytes=10**9,
            selection_horizon_months=12, pre_search=True)
        opened = f4._materialize_o_fit_input_bundle(carrier, tmp_path / "whole-outer-pre-search", pre_search=True)
        state = opened["materialized_pre_search"]
        actual = f4._primary_pre_search_family_projection(state, "RSF")
        assert "identity" not in actual["registered"] and "diagnostic_partitions" not in actual["registered"]
        outer = f4._o_fit_partitions(actual["registered"])["OUTER", 0, 0]
        assert "evaluation_response" not in outer
        deferred = original_prepare(actual, root, policy, **{**kwargs, "_defer_execution": True},
            source_registered_identity=state["source_registered_identity"])
        assert deferred.retained_memory_bytes > 0
        report = deferred()
        assert report["status"] == "COMPUTED_Q_SEARCH"
        assert report["scientific_result"]["registered_inputs_identity_sha256"] == state["source_registered_identity"]
        reached.append((root, state["source_registered_identity"], report))
        return report

    monkeypatch.setattr(f5, "_prepare_primary_outer_rsf_search", scoped_prepare)
    # Existing test asserts the persisted whole S3B2 phase and invokes the real
    # _consume_q_search_batches. Its native leaves, not its consumers, are seams.
    original_case(aar_source, tmp_path, monkeypatch, True, "RSF", False, continuous_terminal=True)
    assert len(reached) == 1
    root, source_identity, report = reached[0]
    spec = strict_json_bytes((root / "input.json").read_bytes())["spec"]
    result = report["scientific_result"]
    for registered, changed_spec in (
        ({"source_registered_identity": "0" * 64}, spec),
        ({"source_registered_identity": source_identity, "identity": source_identity}, spec),
        ({"source_registered_identity": source_identity}, {**spec, "primary_search_source": {}}),
    ):
        with pytest.raises(ContractError, match="SHARED_SEARCH_SOURCE_IDENTITY_INVALID"):
            kernel._shared_full_development_search_result(changed_spec, registered,
                result["search_trace"], result["selected_spec"])
