"""Original Python numerical workers on synthetic common full0 inputs; no fits."""
import copy

import pytest

from padml import f5, nested_loco as nested, runtime
from padml.bundle import canonical_json_bytes, sha256_bytes, ContractError
from test_a12_q_native import aar_source, _q_numbers_python_unit
from test_a12_q_native import test_q_original_python_workers_consume_first_audited_numbers_without_objects as _consume
from test_nested_full_development import full_inputs, unfitted_selector_consumers
from test_nested_full_development import _physical_full_inputs, _unfitted_confirmed_decision


@pytest.mark.parametrize('family,stage,threads', [
    ('XGBOOST_COX', 'S1', 24), ('XGBOOST_COX', 'S2', 56), ('COXTIME_SET_A', 'S1', 24)])
def test_common_python_inputs_keep_original_stop_refit_and_source(
        full_inputs, unfitted_selector_consumers, aar_source, tmp_path, monkeypatch, family, stage, threads):
    # Only model/array-loading/selector leaves are UNFITTED. Full0 task/spec
    # compilation, paired input checks, original STOP/refit numerical workers
    # and first-audit/object/parameter/seed contracts remain original code.
    sample, _, _ = _q_numbers_python_unit(aar_source, tmp_path, family, 'FULL0')
    chosen = sample['spec']['candidate_trials']['S1'][0]
    if family == 'XGBOOST_COX':
        candidates = {name: [{'trial_id': f'X{i + 1:03d}',
            'parameters': {**chosen['parameters'], **({'UNFITTED_TRIAL': i} if i else {})},
            'parameter_sha256': sha256_bytes(canonical_json_bytes({**chosen['parameters'],
                **({'UNFITTED_TRIAL': i} if i else {})}))} for i in range(count)]
            for name, count in (('S1', 40), ('S2', 14))}
    else:
        candidates = {'S1': [{**chosen, 'candidate_id': f'CT{i + 1:03d}'} for i in range(12)]}
    monkeypatch.setattr(f5, '_final_complex_candidate_trials', lambda actual: copy.deepcopy(candidates)
                        if actual == family else pytest.fail('foreign family'))
    monkeypatch.setattr(f5, 'candidate_trials', lambda *a, **k: pytest.fail('NO_NEW_CANDIDATE_RNG'))
    monkeypatch.setattr(runtime, 'effective_cpu_count', lambda: 9)
    plan, parts, full = _physical_full_inputs(full_inputs, tmp_path / 'inputs')
    selector = tmp_path / 'selector'
    f5._nested_full_selector_program(plan, parts, full, selector, rscript='UNFITTED', replay=False)
    base = _unfitted_confirmed_decision(fixed_bootstrap=True)
    decision = nested._sealed({**{key: value for key, value in base.items() if key != 'identity_sha256'},
        'twelve_month_development': nested._twelve_month_development_contract()})
    inputs = []
    for horizon in (24, 12):
        task = f5.compile_nested_full_complex_search_task(plan, parts, full, selector,
            family=family, rscript='UNFITTED', **({'selection_horizon_months': 12,
                'science_decision': decision} if horizon == 12 else {}))
        spec = f5._complex_search_execution_spec(task, f5._complex_runtime_registered_inputs(task, parts))
        spec.update(threads=threads, pool_workers=threads)
        spec['final_search_source']['producer_execution'] = {key: spec[key]
            for key in ('execution_mode', 'threads', 'pool_workers', 'engine_threads')}
        inputs.append({'kind': 'PADML_F5_Q_INPUT_V1', 'task': task, 'spec': spec})
    f5._full0_rsf_s1s2_input_pair(*inputs)
    for key in ('threads', 'pool_workers', 'registered_inputs_identity_sha256'):
        altered = copy.deepcopy(inputs[1])
        altered['spec'][key] = '0' * 64 if key.endswith('sha256') else threads + 1
        with pytest.raises(ContractError): f5._full0_rsf_s1s2_input_pair(inputs[0], altered)
    _consume(aar_source, tmp_path, monkeypatch, family, 'FULL0', full0_pair_inputs=inputs, common_stage=stage)


@pytest.mark.parametrize('family,prefix_phases,next_stage,common_count', [
    ('XGBOOST_COX', 4, 'S3A', 550), ('COXTIME_SET_A', 2, 'S2', 60)])
@pytest.mark.parametrize('continuous', [False, True])
def test_common_python_complete_shards_feed_original_twelve_month_funnel(
        full_inputs, unfitted_selector_consumers, aar_source, tmp_path, monkeypatch,
        family, prefix_phases, next_stage, common_count, continuous):
    """Original public preparation, full Q archive and reader; UNFITTED leaves."""
    import json
    from pathlib import Path
    from padml import f4, f2_kernel as kernel
    from padml.bundle import sha256_file
    import test_q_funnel_shards as funnel

    sample, _, _ = _q_numbers_python_unit(aar_source, tmp_path, family, 'FULL0')
    chosen = sample['spec']['candidate_trials']['S1'][0]
    if family == 'XGBOOST_COX':
        parameters = {**chosen['parameters'], 'max_nrounds': 500}
        candidates = {stage: [{'trial_id': f'UNFITTED-{stage}-{i}',
            'parameters': {**parameters, 'UNFITTED_TRIAL': i},
            'parameter_sha256': sha256_bytes(canonical_json_bytes({**parameters, 'UNFITTED_TRIAL': i}))}
            for i in range(count)] for stage, count in (('S1', 40), ('S2', 14))}
    else:
        # CoxTime uses its frozen explicit grid, not a sampled candidate stream.
        candidates = f5._final_complex_candidate_trials(family)
    monkeypatch.setattr(f5, '_final_complex_candidate_trials', lambda actual: copy.deepcopy(candidates)
                        if actual == family else pytest.fail('foreign family'))
    monkeypatch.setattr(f5, 'candidate_trials', lambda *a, **k: pytest.fail('NO_NEW_CANDIDATE_RNG'))
    synthetic = ([f'p{i:03d}' for i in range(350)],
        [center for center in (36, 38, 39, 48, 52, 54, 55) for _ in range(50)],
        [int(i < 140 and i % 2 == 1) for i in range(350)])
    monkeypatch.setattr(runtime, 'effective_cpu_count', lambda: 9)
    plan, parts, full = _physical_full_inputs(synthetic, tmp_path / 'physical', complete_covariates=True)
    selector = tmp_path / 'selector'
    f5._nested_full_selector_program(plan, parts, full, selector, rscript='UNFITTED', replay=False)
    monkeypatch.setattr(runtime, 'observe_execution_resources', lambda root: {
        'effective_cpus': 32, 'available_memory_bytes': 10**12,
        'scratch_available_bytes': 10**12, 'scratch_root': str(root)})
    old_task = f5.compile_nested_full_complex_search_task(plan, parts, full, selector,
        family=family, rscript='UNFITTED', resource_policy=funnel._POLICY)
    events, _ = funnel._unfitted_leaves(monkeypatch)
    owner, phases = tmp_path / 'original-owner', []
    with funnel._six_shard_batches(monkeypatch, owner, funnel._POLICY, phases,
                                   stop_after=prefix_phases, prepared_full0=True) as history:
        prepared = f5._final_complex_search_program(old_task, parts, owner, replay=False,
            resource_policy=funnel._POLICY, batch_options=funnel._options())
    expected_phase, expected_ids = f5._a12_q_stop_phase(next_stage, family=family)
    assert prepared['phase'] == expected_phase and len(history) == 6 * prefix_phases
    before = list(events)
    old_bytes = {p: p.read_bytes() for path in [owner, *history] for p in path.rglob('*') if p.is_file()}
    base = _unfitted_confirmed_decision(fixed_bootstrap=True)
    decision = nested._sealed({**{k: v for k, v in base.items() if k != 'identity_sha256'},
        'twelve_month_development': nested._twelve_month_development_contract()})
    task = f5.compile_nested_full_complex_search_task(plan, parts, full, selector,
        family=family, rscript='UNFITTED', resource_policy=funnel._POLICY,
        selection_horizon_months=12, science_decision=decision)
    old_input = json.loads((owner / 'input.json').read_bytes())
    registered = f5._complex_runtime_registered_inputs(task, parts)
    spec = f5._complex_search_execution_spec(task, registered)
    spec.update(threads=old_input['spec']['threads'], pool_workers=old_input['spec']['pool_workers'])
    spec['final_search_source']['producer_execution'] = old_input['spec']['final_search_source']['producer_execution']
    current = tmp_path / 'twelve'
    (current / 'native').mkdir(parents=True)
    payload = {'kind': 'PADML_F5_Q_INPUT_V1', 'task': task, 'spec': spec}
    f5._full0_rsf_s1s2_input_pair(old_input, payload)
    (current / 'input.json').write_bytes(canonical_json_bytes(payload))
    source = tmp_path / 'current-source.zip'
    f4.compile_f45_source_bundle(source)
    identity = sha256_bytes(canonical_json_bytes(f4._f45_source_member_sha256()))
    pair = {'producer_input': {'path': str(owner / 'input.json'),
        'sha256': sha256_file(owner / 'input.json'), 'size_bytes': (owner / 'input.json').stat().st_size},
        'consumer_input': {'path': str(current / 'input.json'), 'sha256': sha256_file(current / 'input.json'),
            'size_bytes': (current / 'input.json').stat().st_size},
        'retained_source_bundle': str(source), 'producer_source_identity': identity, 'executor_source_identity': identity}
    control = f5._q_search_batch_control(current, funnel._POLICY, funnel._options(history=history))
    control.update(full0_rsf_s1s2_rescore=pair, retained_q_resource_policy=funnel._POLICY)
    spec = {**spec, 'native_search_root': str(current / 'native'),
            'native_search_replay': False, 'native_search_batch': control}
    binding = funnel._leaf_binding
    def synthetic_binding(actual, row):
        # Only the UNFITTED marker uses this projection; the original Python
        # object/prediction/source reader is covered by the separate leaf test.
        if 'full0_rsf_s1s2_rescore' in actual:
            assert actual['native_search_numbers'] is True and actual['selection_horizon_months'] == 12
            actual = {**actual, 'final_search_source': old_input['spec']['final_search_source']}
        return binding(actual, row)
    monkeypatch.setattr(funnel, '_leaf_binding', synthetic_binding)
    original = f5._q_search_task_batch
    checked = []
    def gather(actual, function, tasks):
        if function is kernel._run_python_locked_evaluation_pool_task:
            return original(actual, function, tasks)
        units = f5._q_search_units(function, tasks)
        phase = funnel.boundary_phase(function, list(units))
        if phase == expected_phase:
            assert list(units) == expected_ids and len(checked) == prefix_phases
            if continuous:
                attempted = list(events)
                for approved in ({phase: expected_ids[:-1]}, {phase: list(reversed(expected_ids))}, {}):
                    control.update(full0_continuous_phase_task_ids=approved,
                        continuous_batch_root=tmp_path / 'UNSTARTED-wrong-owner')
                    with pytest.raises(ContractError, match='FULL0_CONTINUOUS_AUTHORIZED_PHASES_INVALID'):
                        original(actual, function, tasks)
                    assert events == attempted
                del control['full0_continuous_phase_task_ids'], control['continuous_batch_root']
            control.update(prepare_only=True, retained_bytes_per_task=4 * 1024**2,
                q_unit_outputs=[[str(tmp_path / f'twelve-next-{i}.zip'), *expected_ids[i::7]] for i in range(7)])
            return original(actual, function, tasks)
        if not checked:
            records = control['batches']
            for damage in ('missing', 'duplicate', 'old-suffix'):
                altered = list(records)
                if damage == 'missing': altered.pop()
                elif damage == 'duplicate': altered.append(records[-1])
                else:
                    altered.append((owner, {**records[0][1], 'phase': expected_phase, 'task_ids': expected_ids}))
                control['batches'] = altered
                with pytest.raises(ContractError, match='COMMON_PREFIX_COVERAGE_INVALID'):
                    original(actual, function, tasks)
                assert events == before
            control['batches'] = records
        result = original(actual, function, tasks)
        checked.append(phase)
        return result
    monkeypatch.setattr(f5, '_q_search_task_batch', gather)
    scratch = tmp_path / 'funnel-work'
    scratch.mkdir()
    with pytest.raises(f5._QBatchBoundary) as stopped:
        f5._run_final_complex_search(spec, registered, scratch)
    result = stopped.value.result
    assert result['phase'] == expected_phase and result['task_ids'] == expected_ids
    assert result['historical_model_fit_count'] == 2 * common_count
    assert result['historical_prediction_fit_count'] == result['historical_stop_fit_count'] == common_count
    assert result['new_model_fits'] == result['new_stop_fits'] == 0
    assert result['previously_completed_12_month_model_fit_count'] == result['previously_completed_12_month_stop_fit_count'] == 0
    from test_full0_python_prepared_inputs import _check_prepared_boundary
    _check_prepared_boundary(result, task, selector, current)
    publication = json.loads((current / 'prepared-unit-inputs.json').read_bytes())
    assert publication['input'] == result['consumer_input'] and publication['phase'] == expected_phase
    assert control['confirmed_model_fits'] == 2 * common_count
    assert control['confirmed_stop_fits'] == common_count and len(control['used_batches']) == len(history)
    assert all(mode == 'numbers' for mode, _, _ in events[len(before):])
    assert len(events) - len(before) == 2 * common_count
    assert all(p.read_bytes() == raw for p, raw in old_bytes.items())
    assert json.loads((current / 'input.json').read_bytes()) == payload
    monkeypatch.setattr(f5, '_q_search_task_batch', original)
    # Only clinical materialization/selector/model leaves are synthetic. The
    # public lifecycle must consume the old prefix, produce its own IBS12
    # suffix, archive both identities and reopen through the original reader.
    from contextlib import contextmanager, nullcontext
    import tempfile
    import zipfile
    complete_root = tmp_path / 'complete' / 'search' / family
    complete_root.parent.mkdir(parents=True)
    lineage = complete_root.parent.parent / 'full-development.json'
    old_lineage = tmp_path / 'original-full-development.json'
    primary = tmp_path / 'UNFITTED-preparation-source.zip'
    primary.write_bytes(b'UNFITTED_OLD_PREPARATION_SOURCE_BOUNDARY')
    final_mice = tmp_path / 'UNFITTED-final-MICE.zip'
    final_mice.write_bytes(b'UNFITTED_NO_MICE_FIT_OR_REPLAY')
    common = dict(plan=plan, selector_root=str(selector), mice_root=str(tmp_path / 'physical'),
        final_mice_path=str(final_mice), response_path=full['fit_response']['path'],
        resource_policy=funnel._POLICY, rscript='UNFITTED', raw_input_binding={
            'f45_source_sha256': sha256_bytes(canonical_json_bytes({'UNFITTED': 'preparation-source'}))})
    old_sources = dict(common, science_decision=base, search_roots={family: str(owner)})
    sources = dict(common, science_decision=decision, selection_horizon_months=12,
                   search_roots={family: str(complete_root)})
    old_lineage.write_bytes(canonical_json_bytes(old_sources))
    lineage.write_bytes(canonical_json_bytes(sources))
    (lineage.parent / 'preparation-execution.json').write_bytes(canonical_json_bytes({
        'retained_preparation': {'full_development_path': str(old_lineage),
            'full_development_sha256': sha256_file(old_lineage), 'producer_source_bundle_sha256': sha256_file(primary),
            'plan_sha256': sha256_bytes(canonical_json_bytes(plan)), 'new_split_rng_calls': 0,
            'referenced_plan_mice_chains': 1220, 'mice_or_selector_completion_claimed': False}}))
    @contextmanager
    def materialized(path, parent, **kwargs):
        assert path == lineage and parent == lineage.parent
        assert kwargs['retained_full0_source_bundle'] == primary
        assert kwargs['retained_mice_plan'] == plan and kwargs['selection_horizon_months'] == 12
        owned = Path(tempfile.mkdtemp(prefix='f5-full-development-inputs-', dir=parent))
        (owned / 'UNFITTED.bin').write_bytes(b'UNFITTED')
        yield sources, parts, full
        kwargs['q_input_lifecycle']['materialized_inputs'] = {'temporary_root': str(owned)}
    original_compile = f5.compile_nested_full_complex_search_task
    def compile_task(*args, **kwargs):
        assert kwargs['retained_full0_source_bundle'].read_bytes() == primary.read_bytes()
        assert 'retained_q_producer_source_bundle' not in kwargs
        return original_compile(*args, **{**kwargs, 'workers': None})
    monkeypatch.setattr(f5, '_materialized_full_data_development_sources', materialized)
    monkeypatch.setattr(f5, '_final_search_mice_members', lambda *a, **k: {})
    monkeypatch.setattr(f5, 'compile_nested_full_complex_search_task', compile_task)
    archive_path = tmp_path / 'complete-python12.zip'
    suffix = []
    options = {}
    if continuous:
        suffix_owner = tmp_path / 'one-original-owner'
        suffix_owner.mkdir()
        stages = ('S2', 'S3A', 'S3B1', 'S3B2') if family == 'COXTIME_SET_A' else ('S3A', 'S3B1', 'S3B2')
        approved = dict(f5._a12_q_stop_phase(stage, refit=refit, family=family)
                        for stage in stages for refit in (False, True))
        options = {'continuous_batch_root': suffix_owner,
            'full0_continuous_phase_task_ids': {} if family == 'COXTIME_SET_A' else approved,
            'retained_bytes_per_task': 4 * 1024**2}
    with (nullcontext() if continuous else
          funnel._six_shard_batches(monkeypatch, complete_root, funnel._POLICY, suffix, prepared_full0=True)):
        published = f5.execute_final_complex_search(full_development_path=lineage, candidate_family=family,
            target=archive_path, selection_horizon_months=12, prepare_only=not continuous, q_batches=history,
            retained_full0_source_bundle=primary, retained_q_producer_source_bundle=source, **options)
    assert published['status'] == 'COMPUTED' and published['stage_acceptance'] is False
    completed = published['execution_archive']['result']
    receipt = published['execution_archive']['execution_evidence']['q_input_execution']
    assert completed['total_search_fit_count'] == 2 * (common_count + 750)
    assert completed['response_free_stopping_fit_count'] == common_count + 750
    assert completed['selected_spec']['selection_metric'] == 'IBS_0_12'
    if continuous:
        assert options['full0_continuous_phase_task_ids'] == approved
        suffix = [json.loads((suffix_owner / phase / 'execution.json').read_bytes()) for phase in approved]
        assert all(row['task_ids'] == approved[row['phase']] for row in suffix)
        assert len(suffix) == 10 - prefix_phases
        assert sum(row['confirmed_first_native_audit_count'] for row in suffix) == 1500
        assert receipt['continuous_phase_task_ids'] == approved
    else:
        assert len(suffix) == 10 - prefix_phases and sum(row['first_audits'] for row in suffix) == 1500
    assert receipt['historical_model_fit_count'] == 2 * common_count
    assert receipt['previously_completed_12_month_model_fit_count'] == (0 if continuous else 1500)
    assert receipt['previously_completed_12_month_stop_fit_count'] == (0 if continuous else 750)
    assert receipt['new_model_fits'] == receipt['new_first_native_audit_count'] == (1500 if continuous else 0)
    assert receipt['new_stop_fits'] == (750 if continuous else 0)
    assert all(p.read_bytes() == raw for p, raw in old_bytes.items())
    zero_archive = None
    if continuous and family == 'COXTIME_SET_A':
        # Reuse the completed phase receipts above in a fresh original
        # consumer. There is no missing atom and no executor may be entered.
        previous_lineage = lineage
        previous_search_root = sources['search_roots'][family]
        preparation = (lineage.parent / 'preparation-execution.json').read_bytes()
        zero_root = tmp_path / 'zero-fit-publication' / 'search' / family
        zero_root.parent.mkdir(parents=True)
        lineage = zero_root.parent.parent / 'full-development.json'
        sources['search_roots'][family] = str(zero_root)
        lineage.write_bytes(canonical_json_bytes(sources))
        (lineage.parent / 'preparation-execution.json').write_bytes(preparation)
        zero_owner = tmp_path / 'unused-zero-fit-owner'
        zero_owner.mkdir()
        zero_archive = tmp_path / 'complete-python12-zero-fit.zip'
        before_zero = [(mode, path) for mode, path, _ in events if mode != 'numbers']
        try:
            with monkeypatch.context() as zero_only:
                zero_only.setattr(f5, '_execute_q_search_batch',
                    lambda *a, **k: pytest.fail('NO_NEW_Q_EXECUTOR_FOR_COMPLETE_PHASES'))
                zero = f5.execute_final_complex_search(full_development_path=lineage,
                    candidate_family=family, target=zero_archive, selection_horizon_months=12,
                    q_batches=history + [suffix_owner / phase for phase in approved],
                    retained_full0_source_bundle=primary, retained_q_producer_source_bundle=source,
                    continuous_batch_root=zero_owner, full0_continuous_phase_task_ids={},
                    retained_bytes_per_task=4 * 1024**2)
            zero_receipt = zero['execution_archive']['execution_evidence']['q_input_execution']
            assert zero_receipt['continuous_phase_task_ids'] == {}
            assert zero_receipt['new_model_fits'] == zero_receipt['new_first_native_audit_count'] == 0
            assert zero_receipt['new_stop_fits'] == 0
            assert zero_receipt['previously_completed_12_month_model_fit_count'] == 1500
            assert zero_receipt['previously_completed_12_month_stop_fit_count'] == 750
            assert not list(zero_owner.iterdir())
            assert [(mode, path) for mode, path, _ in events if mode != 'numbers'] == before_zero
        finally:
            lineage = previous_lineage
            sources['search_roots'][family] = previous_search_root
    preserved = {p: p.read_bytes() for p in complete_root.rglob('*') if p.is_file()}
    produced = [(mode, path) for mode, path, _ in events if mode != 'numbers']
    # Same-line downstream users discover the retained common-input slot.
    assert f5._final_complex_search_program(task, parts, complete_root, replay=True,
        resource_policy=funnel._POLICY) == completed
    def preparation_proof(path, **kwargs):
        assert kwargs == {'full0_preparation': True} and path.read_bytes() == primary.read_bytes()
        return {'UNFITTED': 'preparation-source'}
    monkeypatch.setattr(f4, '_retained_full0_source_members', preparation_proof)
    monkeypatch.setattr(f5, '_validate_final_search_plan', lambda actual, mice, response, **kwargs:
        full['development_input'] if actual == kwargs['retained_mice_plan'] == plan else pytest.fail('plan drift'))
    monkeypatch.setattr(f5, '_materialize_final_search_inputs', lambda *a, **k: parts)
    monkeypatch.setattr(f5, 'materialize_final_full_data_mice', lambda *a, **k: full)
    references = []
    reread = f5.read_final_complex_search(archive_path, rscript='UNFITTED', on_native_references=references.extend)
    assert reread == published['execution_archive'] and references
    if zero_archive is not None:
        assert f5.read_final_complex_search(zero_archive, rscript='UNFITTED') == zero['execution_archive']
    with zipfile.ZipFile(archive_path) as zipped:
        assert zipped.read('inputs/retained-preparation/source.zip') == primary.read_bytes()
        assert zipped.read('search/execution-evidence/gbm-common/source.zip') == source.read_bytes()
        assert zipped.read('inputs/retained-preparation/full-development.json') == old_lineage.read_bytes()
        assert zipped.read('inputs/full-development.json') == lineage.read_bytes()
    assert [(mode, path) for mode, path, _ in events if mode != 'numbers'] == produced
    assert {p: p.read_bytes() for p in complete_root.rglob('*') if p.is_file()} == preserved
    assert all(p.read_bytes() == raw for p, raw in old_bytes.items())
    for damage in ('source', 'count', 'window', 'missing-lineage'):
        bad = copy.deepcopy(published['execution_archive'])
        row = bad['execution_evidence']['q_input_execution']
        if damage == 'source': row['producer_input']['sha256'] = '0' * 64
        elif damage == 'count': row['scientific_result']['total_search_fit_count'] = 1070
        elif damage == 'window': row['scientific_result']['selected_spec']['selection_metric'] = 'IBS_0_24'
        else: del bad['members']['inputs/retained-preparation/full-development.json']
        bad['identity_sha256'] = sha256_bytes(canonical_json_bytes({k: v for k, v in bad.items() if k != 'identity_sha256'}))
        with pytest.raises(ContractError): f5._validate_executed_complex_search_archive(bad)
