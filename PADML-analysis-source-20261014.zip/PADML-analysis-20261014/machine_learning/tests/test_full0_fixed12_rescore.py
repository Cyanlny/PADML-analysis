"""Original full0 replay entry; synthetic curves only, no native calls."""
from contextlib import contextmanager
from pathlib import Path
import sys

import pytest

from padml import f2_kernel, f5, nested_loco as nested, runtime
from padml.bundle import ContractError, canonical_json_bytes
from test_nested_score_replay import build_fixture, stage_result, FAMILY
from test_nested_full_development import _unfitted_confirmed_decision


def decision():
    value = _unfitted_confirmed_decision(fresh_seven=True, fixed_bootstrap=True)
    return nested._sealed({**{k: v for k, v in value.items() if k != "identity_sha256"},
        "twelve_month_development": nested._twelve_month_development_contract()})


def forbidden(*args, **kwargs):
    pytest.fail("NO_COMPILATION_FIT_OR_NATIVE_REPLAY_FALLBACK")


@pytest.mark.parametrize("change", [{"replay": False}, {"prepare_only": True}, {"resume": True},
    {"family": "RSF"}, {"family": None}, {"selection_horizon_months": 12},
    {"retained_full0_source_bundle": None}])
def test_rescore_scope_rejected_before_materialization(tmp_path, monkeypatch, change):
    monkeypatch.setattr(f5, "_materialized_full_data_development_sources", forbidden)
    options = dict(replay=True, family="COX_PH", retained_full0_source_bundle=tmp_path / "old.zip",
                   rescore_fixed12_decision=decision())
    options.update(change)
    with pytest.raises(ContractError):
        f5.execute_full_data_locked_scores(tmp_path / "lineage.json", **options)


@pytest.mark.parametrize("family", ["COX_PH", "ELASTIC_NET_COX", "FPM_TVC_SET_A"])
def test_public_rescore_preserves_original_lineage_scope(tmp_path, monkeypatch, family):
    science = decision()
    retained = tmp_path / "old.zip"
    calls = []
    @contextmanager
    def materialized(source, parent, **scope):
        assert scope == {"selector_only": True, "retained_full0_source_bundle": retained}
        yield dict(plan={}, score_root=str(tmp_path / "original-score"), selector_root=str(tmp_path / "selector"),
            search_roots={}, rscript="FORBIDDEN", resource_policy={}, retained_bytes_per_component=1,
            expanded_bytes_per_component=1, shared_storage_bytes=1), [], {}
    def consume(*args, **kwargs):
        assert args[5] == tmp_path / "original-score"
        assert kwargs["rescore_fixed12_decision"] == science and kwargs["replay"] is True
        assert "selection_horizon_months" not in kwargs
        calls.append(True)
        return {"NUMERICAL_ONLY": True}
    monkeypatch.setattr(f5, "_materialized_full_data_development_sources", materialized)
    monkeypatch.setattr(f5, "_full_data_locked_score_program", consume)
    assert f5.execute_full_data_locked_scores(tmp_path / "lineage.json", replay=True, family=family,
        retained_full0_source_bundle=retained, rescore_fixed12_decision=science) == {"NUMERICAL_ONLY": True}
    assert calls == [True]


def test_cli_passes_explicit_rescore_decision(tmp_path, monkeypatch, capsys):
    science = decision()
    path = tmp_path / "decision.json"
    path.write_bytes(canonical_json_bytes(science))
    calls = []
    def consume(*args, **kwargs):
        calls.append(kwargs)
        return {"ZERO_FIT_CLI": True}
    monkeypatch.setattr(f5, "execute_full_data_locked_scores", consume)
    monkeypatch.setattr(sys, "argv", ["padml-f5", "full-score", str(tmp_path / "lineage.json"),
        "--replay", "--family", "COX_PH", "--retained-full0-source-bundle", str(tmp_path / "old.zip"),
        "--rescore-fixed12-decision", str(path)])
    f5.main()
    assert calls[0]["rescore_fixed12_decision"] == science
    assert calls[0]["selection_horizon_months"] == 24
    assert "ZERO_FIT_CLI" in capsys.readouterr().out


@pytest.mark.parametrize("missing", [False, True])
@pytest.mark.parametrize("own12", [False, True])
def test_original_stage_rescores_complete_numbers_and_preserves_old_files(tmp_path, monkeypatch, missing, own12):
    root = tmp_path / "score"
    request, request_root, components, outputs = build_fixture(root, full_score=True,
        science_decision=decision() if own12 else None)
    for record in request["component_records"]:
        record["size_bytes"] = (request_root / record["path"]).stat().st_size
    monkeypatch.setattr(nested, "_read_component", lambda path: components[path.relative_to(request_root).as_posix()])
    monkeypatch.setattr(f2_kernel, "_expected_family_parent_column_map", lambda *a, **k: [{"columns": ["AST_ALT", "Age"]}])
    monkeypatch.setattr(f2_kernel, "predictor_contract", lambda *a, **k: {})
    monkeypatch.setattr(f5, "_validate_final_r_fit_health", lambda *a, **k: None)
    monkeypatch.setattr(f5, "_validate_retained_r_audit_numbers", lambda *a, **k: None)
    monkeypatch.setattr(f5, "_score_archive_expanded_limit", lambda *a, **k: None)
    monkeypatch.setattr(f5, "_full_score_job_inputs", lambda *a, **k: None)
    for name in ("_execute_and_verify_score_archive_job", "_replay_component_job"):
        monkeypatch.setattr(f5, name, forbidden)
    monkeypatch.setattr(runtime, "_bounded_ordered_spawn", forbidden)
    monkeypatch.setattr(nested, "select_training_family", forbidden)
    score, execution = nested._score_fresh_family(family=FAMILY, request=request, root=root, outputs=outputs)
    stage_result(root, root, execution)
    score_path = root / "score-evidence" / FAMILY / "training-score.json"
    execution_path = score_path.with_name("execution.json")
    score_path.write_bytes(canonical_json_bytes(score))
    if not missing:
        execution_path.write_bytes(canonical_json_bytes(execution))
    (request_root / f"full-score-input.{FAMILY}.json").write_bytes(canonical_json_bytes(request))
    originals = {p: p.read_bytes() for p in root.rglob("*") if p.is_file()}
    # Isolate source compilation and physical resource observation from this
    # synthetic stage test; the real numerical consumer below is not stubbed.
    monkeypatch.setattr(f5, "_compile_full_score_inputs", lambda *a, **k: request)
    monkeypatch.setattr(f5, "_full_score_storage_usage", lambda *a, **k: {})
    monkeypatch.setattr(f5, "_full_score_resource_admission", lambda *a, **k: (
        {"admitted_worker_ceiling": 1, "limits": {"configured": 56}}, {"retained_result_json_bytes": 64 * 1024**2}))
    # Old frozen policy is evidence, not a future scratch deduction. The
    # physical write check must not restore this now-cancelled reserve.
    monkeypatch.setattr(f5.shutil, "disk_usage", lambda path: type("Usage", (), {"free": 64 * 1024**2})())
    args = dict(rscript="FORBIDDEN", replay=True, family=FAMILY, resource_policy={"scratch_reserve_bytes": 10**15},
        retained_bytes_per_component=1024**2, expanded_bytes_per_component=1024**2, shared_storage_bytes=64 * 1024**2,
        retained_full0_source_bundle=tmp_path / "old.zip", rescore_fixed12_decision=decision())
    if own12:
        args.pop("rescore_fixed12_decision")
        args.update(selection_horizon_months=12, science_decision=decision())
    if missing:
        with pytest.raises(ContractError, match="NESTED_FULL_SCORE_NUMERICAL_ORIGINAL_REQUIRED"):
            f5._full_data_locked_score_program({}, [], {}, tmp_path / "selector", {}, root, **args)
    else:
        result = f5._full_data_locked_score_program({}, [], {}, tmp_path / "selector", {}, root, **args)
        assert result["training_scores"][0]["selection_horizon_months"] == 12
        assert result["fresh_score_execution"][0]["selection_horizon_months"] == 12
        assert result["new_model_fits"] == result["new_model_native_verification_count"] == result["native_model_replay_count"] == 0
        assert result["score_numerical_component_count"] == 300 and result["pool_execution_reports"] == []
        assert result["request"] == request
        if own12:
            assert result["training_scores"] == [score] and result["fresh_score_execution"] == [execution]
        else:
            assert result["selection_horizon_months"] == 12
    assert all(p.read_bytes() == raw for p, raw in originals.items())


@pytest.mark.parametrize("family", ["COX_PH", "ELASTIC_NET_COX", "FPM_TVC_SET_A"])
def test_public_same_line_replay_uses_family_root_without_preparation_release(tmp_path, monkeypatch, family):
    science = decision()
    lineage = dict(plan={}, science_decision=science, score_root=str(tmp_path / "score"),
        selector_root=str(tmp_path / "selector"), search_roots={}, rscript="FORBIDDEN",
        resource_policy={}, retained_bytes_per_component=1, expanded_bytes_per_component=1, shared_storage_bytes=1)
    monkeypatch.setattr(f5, "_read_final_lineage", lambda *a, **k: lineage)
    @contextmanager
    def materialized(*args, **kwargs):
        assert kwargs["selector_only"] is True and kwargs["selection_horizon_months"] == 12
        assert kwargs["retained_mice_plan"] == lineage["plan"]
        assert "q_input_lifecycle" not in kwargs
        yield lineage, [], {}
    calls = []
    def consume(*args, **kwargs):
        assert args[5] == tmp_path / f"score.{family}"
        assert kwargs["replay"] is True and kwargs["resume"] is False
        assert kwargs["selection_horizon_months"] == 12 and kwargs["science_decision"] == science
        assert "prepare_only" not in kwargs and "rescore_fixed12_decision" not in kwargs
        calls.append(family)
        return {"NUMERICAL_ONLY": True}
    monkeypatch.setattr(f5, "_materialized_full_data_development_sources", materialized)
    monkeypatch.setattr(f5, "_full_data_locked_score_program", consume)
    monkeypatch.setattr(runtime, "release_step_resources", forbidden)
    assert f5.execute_full_data_locked_scores(tmp_path / "lineage.json", replay=True, family=family,
        selection_horizon_months=12, retained_full0_source_bundle=tmp_path / "old.zip") == {"NUMERICAL_ONLY": True}
    assert calls == [family]
