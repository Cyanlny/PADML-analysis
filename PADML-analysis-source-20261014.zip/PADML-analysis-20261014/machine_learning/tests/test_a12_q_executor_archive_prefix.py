"""Regression for the historical AAR Q source in complete-owner reservations."""

import pytest

from padml import f4_compact, f5, f5_sensitivity, nested_loco
from padml.bundle import ContractError


def test_historical_q_source_enters_only_the_no_aar_shared_prefix(tmp_path, monkeypatch):
    root = tmp_path / "outer"
    development = root / "development"
    (development / "selector").mkdir(parents=True)
    (development / "development.json").write_bytes(b"{}")
    (development / "selector" / "development-input.json").write_bytes(b"{}")
    source = tmp_path / "5c-source.zip"
    source.write_bytes(b"source bytes are independently proven by the outer reader")
    inputs = tmp_path / "inputs.zip"
    inputs.write_bytes(b"inputs")
    monkeypatch.setattr(f4_compact, "_full_pipeline_q_numerical_members", lambda _root: ({}, {}))
    monkeypatch.setattr(f5, "_nested_selector_numerical_members", lambda _root: {})
    branches = nested_loco.AAR_ESTIMANDS
    prepared = {
        "family": "RSF",
        "outer_fold": 4,
        "source": {
            "kind": "PADML_F5_A12_PROJECTED_OUTER_INPUTS_V1",
            "identity_sha256": "1204c950c4f61b4a30ae3302825cad8720c77bd9c5daff68159c7eaaad88f9af",
            "primary_source": {"primary_development_lock": {"selection_horizon_months": 24}},
        },
        "retained_a12_q_executor_source_bundle": source,
    }
    member = "execution-evidence/retained-sources/a12-q-executor.zip"

    for count in (1, 2, 3):
        members = f5_sensitivity._a12_outer_retained_members(
            root, "RSF", 4, inputs, prepared=prepared,
            before_final=True, completed_branches=branches[:count])
        assert (member in members) == (count == 3)
        if count == 3:
            assert members[member] == source

    with pytest.raises(ContractError, match="F5_RETAINED_AAR_Q_EXECUTOR_DRIFT"):
        f5_sensitivity._a12_outer_retained_members(
            root, "RSF", 4, inputs, prepared=prepared,
            before_final=True, assigned_branches=branches[:1])

    prepared["outer_fold"] = 5
    with pytest.raises(ContractError, match="F5_RETAINED_AAR_Q_EXECUTOR_DRIFT"):
        f5_sensitivity._a12_outer_retained_members(
            root, "RSF", 4, inputs, prepared=prepared,
            before_final=True, completed_branches=branches)
