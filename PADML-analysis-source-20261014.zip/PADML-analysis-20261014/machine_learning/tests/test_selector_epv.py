from __future__ import annotations

import copy
import json
import math
import shutil
import struct
import subprocess
from pathlib import Path

import pytest

from padml._science_authority import load_science_authority
from padml.bundle import ContractError, canonical_json_bytes, sha256_bytes
from padml.f2_kernel import (
    _choose_elastic_alpha,
    _elastic_ratios,
    _locked_family_parameters,
    _summarize_elastic_alpha,
    _validate_elastic_final_lambda_health,
)
import padml.f2_kernel as kernel
import padml.f2_validation as validation


_NATIVE_R_FUNCTIONS = r'''
suppressPackageStartupMessages({library(glmnet); library(survival); library(jsonlite); library(digest)})
for (expression in parse(commandArgs(trailingOnly=TRUE)[[1L]])) {
  if (is.call(expression) && identical(expression[[1L]], as.name("<-")) &&
      length(expression) == 3L && is.call(expression[[3L]]) &&
      identical(expression[[3L]][[1L]], as.name("function"))) eval(expression)
}
'''
_NATIVE_R_RUN = subprocess.run
_F2_PACKAGE_ROOT = Path(kernel.__file__).resolve().parent


def _contract():
    return load_science_authority()["science"]["f2_model_development"]["selector_contract"]


def _hash(value):
    return sha256_bytes(canonical_json_bytes(value))


def _alpha_record(alpha=0.2, *, infeasible=False, common_set_overfull=False):
    ratios = _elastic_ratios(_contract())
    columns = {"AST_ALT": 1, "X": 3, "Y": 1}
    column_map = [{"parent": parent, "columns": [parent] if count == 1 else
                   [f"{parent}_{index}" for index in range(count)]}
                  for parent, count in columns.items()]
    penalty_identity = _hash({
        "design_columns": [column for row in column_map for column in row["columns"]],
        "penalty_factor": [0.0, 1.0, 1.0, 1.0, 1.0],
    })
    outer = []
    health = []
    for imputation in range(1, 21):
        bound = 1 + imputation / 10
        coefficients = {
            "AST_ALT": [[0.0] for _ in ratios],
            "X": [[1.0, 1.0, 1.0] if infeasible or index >= 30 else
                  [1.0, 0.0, 0.0] for index in range(150)],
            "Y": [[1.0] if infeasible or index >= 30 else [0.0] for index in range(150)],
        }
        provenance = {
            "schema_version": "1.0.0", "kind": "PADML_F2_ELASTIC_LAMBDA_UPPER_BOUND_V1",
            "glmnet_version": "5.0", "family": "cox", "cox_ties": "breslow",
            "alpha": alpha, "standardize": True,
            "penalty_factor_identity_sha256": penalty_identity,
            "pilot_requested_nlambda": 100, "pilot_returned_nlambda": 100,
            "pilot_lambda_head": [bound, bound * 0.9, bound * 0.8],
            "resolved_lambda_max": bound, "glmnet_big": 9.9e35,
            "sentinel_equivalent": False,
        }
        active = [sum(value != 0 for parent, vectors in coefficients.items()
                      if parent != "AST_ALT" for value in vectors[index])
                  for index in range(150)]
        item = {
            "imputation": imputation, "lambda_max": bound,
            "lambda_path_sha256": _hash([bound * ratio for ratio in ratios]),
            "lambda_upper_bound": provenance,
            "penalized_design_column_count": 4,
            "penalized_active_count_path": active, "penalized_entry_covered": True,
        }
        health.append(item)
        outer.append({**item, "event_count": 45 if common_set_overfull else 60,
                      "parent_design_columns": columns, "parent_coefficients": coefficients,
                      "coefficient_path_sha256": _hash({"parent_design_columns": columns,
                                                        "parent_coefficients": coefficients})})
    partitions = []
    for repeat in range(1, 4):
        for inner in range(1, 6):
            losses = []
            for imputation in range(1, 21):
                best = 8 if imputation % 2 else 16
                # The unconstrained optimum is deliberately outside EPV>=15.
                losses.append([float((index - best) ** 2 + 10 + alpha)
                               if index < 30 else float(alpha)
                               for index in range(150)])
            partitions.append({"repeat": repeat, "inner_fold": inner,
                               "validation_n": inner + 10,
                               "mi_losses": losses, "mi_lambda_path_health": copy.deepcopy(health)})
    return {"alpha": alpha, "partition_losses": partitions, "outer_paths": outer}


def test_feasible_minimum_is_per_imputation_and_seta_df_is_not_active_df():
    record = _alpha_record()
    result = _summarize_elastic_alpha(record, _contract())
    ratios = _elastic_ratios(_contract())
    assert result["status"] == "FEASIBLE"
    assert result["selected_ratio_by_imputation"] == [ratios[8] if index % 2 else ratios[16]
                                                     for index in range(1, 21)]
    assert result["lambda_by_imputation"] == [row["lambda_max"] * ratio for row, ratio in
                                               zip(record["outer_paths"], result["selected_ratio_by_imputation"], strict=True)]
    assert result["active_design_df_by_imputation"] == [2] * 20
    assert result["p90_active_design_df"] == 2
    assert result["conservative_active_epv"] == 30
    assert result["selected_parents"] == ["AST_ALT", "X"]
    assert result["common_set_design_df"] == 4
    assert result["common_set_epv"] == 15


def test_full_common_set_columns_can_make_an_alpha_infeasible():
    result = _summarize_elastic_alpha(_alpha_record(common_set_overfull=True), _contract())
    assert all(row["status"] == "FEASIBLE" for row in result["imputation_decisions"])
    assert result["status"] == "EPV_INFEASIBLE"
    assert result["reason_code"] == "COMMON_SETA_EPV_BELOW_MINIMUM"
    assert result["conservative_active_epv"] == 22.5
    assert result["common_set_epv"] == 11.25


def test_infeasible_alpha_does_not_hide_later_feasible_alpha():
    bad, good = _alpha_record(0.05, infeasible=True), _alpha_record(0.1)
    chosen, summaries = _choose_elastic_alpha([bad, good], [0.05, 0.1], _contract())
    assert chosen["alpha"] == 0.1
    assert [row["status"] for row in summaries] == ["EPV_INFEASIBLE", "FEASIBLE"]
    assert len(summaries[0]["imputation_decisions"]) == 20
    with pytest.raises(ContractError, match="F2_SELECTOR_EPV_UNRESOLVED"):
        _choose_elastic_alpha([bad], [0.05], _contract())


@pytest.mark.parametrize("corruption", ["nan", "missing", "coefficient_hash", "lambda_sentinel"])
def test_invalid_computation_is_never_classified_as_infeasible(corruption):
    bad, invalid = _alpha_record(0.05, infeasible=True), _alpha_record(0.1, infeasible=True)
    if corruption == "nan":
        invalid["partition_losses"][-1]["mi_losses"][-1][-1] = float("nan")
    elif corruption == "missing":
        invalid["partition_losses"].pop()
    elif corruption == "coefficient_hash":
        invalid["outer_paths"][-1]["coefficient_path_sha256"] = "0" * 64
    else:
        invalid["outer_paths"][-1]["lambda_upper_bound"]["sentinel_equivalent"] = True
    with pytest.raises(ContractError) as error:
        _choose_elastic_alpha([bad, invalid], [0.05, 0.1], _contract())
    assert str(error.value) != "F2_SELECTOR_EPV_UNRESOLVED"


def test_one_se_is_computed_inside_the_feasible_domain_with_repeat_se():
    record = _alpha_record()
    for partition in record["partition_losses"]:
        shift = [-3.0, 0.0, 3.0][partition["repeat"] - 1]
        partition["mi_losses"] = [[value + shift for value in values]
                                   for values in partition["mi_losses"]]
    result = _summarize_elastic_alpha(record, _contract())
    ratios = _elastic_ratios(_contract())
    assert result["selected_ratio_by_imputation"] == [ratios[7] if index % 2 else ratios[15]
                                                     for index in range(1, 21)]
    assert result["r_min_by_imputation"] != result["selected_ratio_by_imputation"]


def test_zero_se_uses_the_actual_feasible_minimum():
    record = _alpha_record()
    for partition in record["partition_losses"]:
        for losses in partition["mi_losses"]:
            losses[7], losses[8] = 1.0 + 1e-12, 1.0
    result = _summarize_elastic_alpha(record, _contract())
    expected = [_elastic_ratios(_contract())[8]] * 20
    assert result["r_min_by_imputation"] == expected
    assert result["r_0_5se_by_imputation"] == expected
    assert result["selected_ratio_by_imputation"] == expected


def test_one_infeasible_imputation_cannot_be_omitted():
    record = _alpha_record()
    record["outer_paths"][-1] = _alpha_record(infeasible=True)["outer_paths"][-1]
    result = _summarize_elastic_alpha(record, _contract())
    assert result["status"] == "EPV_INFEASIBLE"
    assert result["reason_code"] == "IMPUTATION_HAS_NO_EPV_FEASIBLE_RATIO"
    assert [row["status"] for row in result["imputation_decisions"]] == ["FEASIBLE"] * 19 + ["EPV_INFEASIBLE"]


def test_locked_parameters_retain_every_imputation_without_retuning():
    chosen = _summarize_elastic_alpha(_alpha_record(), _contract())
    locked = {"family": "ELASTIC_NET_COX", "alpha": chosen["alpha"],
              "ratio_by_imputation": chosen["selected_ratio_by_imputation"],
              "lambda_by_imputation": chosen["lambda_by_imputation"],
              "lambda_upper_bound_by_imputation": chosen["lambda_upper_bound_by_imputation"]}
    assert _locked_family_parameters("ELASTIC_NET_COX", locked) == {key: value for key, value in locked.items() if key != "family"}
    locked["lambda_by_imputation"] = list(reversed(locked["lambda_by_imputation"]))
    with pytest.raises(ContractError, match="LOCKED_ELASTIC_SPEC_INVALID"):
        _locked_family_parameters("ELASTIC_NET_COX", locked)


def _no_aar_record(*, alternate_count=0, zero_count=0):
    record = _alpha_record(common_set_overfull=True)
    columns = {"X": 3, "Y": 1}
    penalty = _hash({"design_columns": ["X_0", "X_1", "X_2", "Y"],
                     "penalty_factor": [1.0] * 4})
    for row in record["outer_paths"]:
        row["parent_design_columns"] = columns
        row["parent_coefficients"].pop("AST_ALT")
        row["lambda_upper_bound"]["penalty_factor_identity_sha256"] = penalty
        for index in range(30):
            if row["imputation"] <= zero_count:
                row["parent_coefficients"]["X"][index] = [0.0] * 3
                row["parent_coefficients"]["Y"][index] = [0.0]
            elif row["imputation"] <= alternate_count:
                row["parent_coefficients"]["X"][index] = [0.0] * 3
                row["parent_coefficients"]["Y"][index] = [1.0]
        row["penalized_active_count_path"] = [sum(value != 0 for path in row["parent_coefficients"].values()
                                                   for value in path[index]) for index in range(150)]
        row["coefficient_path_sha256"] = _hash({"parent_design_columns": columns,
                                               "parent_coefficients": row["parent_coefficients"]})
    for part in record["partition_losses"]:
        for health in part["mi_lambda_path_health"]:
            health["lambda_upper_bound"]["penalty_factor_identity_sha256"] = penalty
    return record, {"parent_design_columns": columns, "outer_training_event_count": 45}


def test_no_aar_redevelopment_reselects_by_fresh_frequency_not_fixed_seta():
    record, domain = _no_aar_record(alternate_count=12)
    result = _summarize_elastic_alpha(record, _contract(), no_aar_redevelopment=domain)
    assert result["status"] == "FEASIBLE"
    assert result["selected_parents"] == ["Y"]
    assert result["natural_frequency"] == {"X": 8, "Y": 12}
    assert result["forced_parent"] is None
    assert result["seta_writeback"] == "FORBIDDEN"
    assert result["common_set_design_df"] == 1
    assert result["selected_ratio_by_imputation"] == [_elastic_ratios(_contract())[8 if index % 2 else 16]
                                                     for index in range(1, 21)]
    chosen, summaries = _choose_elastic_alpha([record], [0.2], _contract(), no_aar_redevelopment=domain)
    assert chosen == summaries[0] == result


def test_no_aar_zero_active_columns_keep_per_mi_1se_without_forced_replacement():
    record, domain = _no_aar_record(zero_count=7)
    result = _summarize_elastic_alpha(record, _contract(), no_aar_redevelopment=domain)
    assert result["selected_parents"] == ["X"]
    assert result["active_design_df_by_imputation"] == [0] * 7 + [1] * 13
    assert [row["selected_active_epv"] for row in result["imputation_decisions"]] == [None] * 7 + [45] * 13
    assert result["common_set_design_df"] == 3 and result["common_set_epv"] == 15


def test_no_aar_empty_fresh_seta_is_not_epv_infeasible_or_a_replacement_model():
    record, domain = _no_aar_record(zero_count=20)
    with pytest.raises(ContractError, match="NESTED_NO_AAR_SELECTOR_EMPTY_SETA"):
        _summarize_elastic_alpha(record, _contract(), no_aar_redevelopment=domain)
    record["partition_losses"][-1]["mi_losses"][-1][-1] = float("nan")
    with pytest.raises(ContractError, match="F2_SELECTOR_PARTITION_LOSS_INVALID"):
        _summarize_elastic_alpha(record, _contract(), no_aar_redevelopment=domain)


@pytest.mark.parametrize("damage", ["ast_alt", "domain", "mixed_fixed", "no_explicit_scope"])
def test_no_aar_selector_cannot_impersonate_a12_or_primary(damage):
    record, domain = _no_aar_record()
    if damage == "ast_alt":
        domain["parent_design_columns"]["AST_ALT"] = 1
    elif damage == "domain":
        domain["outer_training_event_count"] += 1
    with pytest.raises(ContractError):
        _summarize_elastic_alpha(record, _contract(),
                                 no_aar_redevelopment=None if damage == "no_explicit_scope" else domain,
                                 fixed_a12={} if damage == "mixed_fixed" else None)


def test_native_r_refit_preserves_selected_lambda_on_smaller_seta(tmp_path):
    executable = shutil.which("Rscript")
    assert executable is not None
    kernel_path = Path(__file__).resolve().parents[1] / "padml/kernels/f2_model_development.R"
    script = tmp_path / "native-selector.R"
    script.write_text(_NATIVE_R_FUNCTIONS + r'''
set.seed(203)
time_col <- "time"; event_col <- "event"
x <- matrix(rnorm(420), ncol=3, dimnames=list(NULL,c("AST_ALT","X","Y")))
time <- rexp(120, exp(0.2*x[1:120,1] - 0.4*x[1:120,2])) + 0.01
event <- rep(c(1L,1L,1L,0L),30)
train <- data.frame(time=time,event=event)
test <- data.frame(row=seq_len(20))
upper <- data_driven_cox_lambda_upper_bound(x[1:120,],time,event,0.2,c(0,1,1))
ratios <- as.list(seq(0.05,0.24,by=0.01))
parameters <- list(alpha=0.2,ratio_by_imputation=ratios,
                   lambda_by_imputation=lapply(ratios,function(r) upper$resolved_lambda_max*r),
                   lambda_upper_bound_by_imputation=rep(list(upper),20))
data_driven_cox_lambda_upper_bound <- function(...) stop("UNAUTHORIZED_RETUNE")
stopping <- lapply(seq_len(20),function(imp) {
  selected <- if (imp == 20L) "AST_ALT" else c("AST_ALT","X")
  mapping <- data.frame(parent=selected,column=selected)
  prepared <- list(train_mapping=list(x=x[1:120,selected,drop=FALSE],parent_map=mapping),
                   test_mapping=list(x=x[121:140,selected,drop=FALSE],parent_map=mapping))
  fitted <- fit_predict("ELASTIC_NET_COX",train,test,selected,
                        c(parameters,list(imputation_index=imp)),300000L+imp,c(0,1,2),
                        NULL,prepared_design=prepared)
  stopifnot(identical(fitted$stopping$lambda,parameters$lambda_by_imputation[[imp]]),
            all(is.finite(fitted$survival)),all(fitted$survival[,1] == 1))
  fitted$stopping
})
broken <- parameters; broken$imputation_index <- 1L; broken$lambda_by_imputation[[1]] <- 999
error <- tryCatch({elastic_locked_parameters(broken);"NO_ERROR"},error=conditionMessage)
stopifnot(error != "NO_ERROR")
native_glmnet <- glmnet
glmnet <- function(...) { fit <- native_glmnet(...); fit$jerr <- -1L; fit }
mapping <- data.frame(parent=c("AST_ALT","X"),column=c("AST_ALT","X"))
prepared <- list(train_mapping=list(x=x[1:120,c("AST_ALT","X"),drop=FALSE],parent_map=mapping),
                 test_mapping=list(x=x[121:140,c("AST_ALT","X"),drop=FALSE],parent_map=mapping))
nonconvergence <- tryCatch({
  fit_predict("ELASTIC_NET_COX",train,test,c("AST_ALT","X"),
              c(parameters,list(imputation_index=1L)),300001L,c(0,1,2),
              NULL,prepared_design=prepared)
  "NO_ERROR"
},error=conditionMessage)
stopifnot(nonconvergence == "F2_ELASTIC_FIT_NONCONVERGENCE")
cat(canonical_json(list(stopping=stopping,error=error,nonconvergence=nonconvergence)))
''')
    completed = subprocess.run([executable, "--vanilla", str(script), str(kernel_path)], capture_output=True, text=True, timeout=60)
    assert completed.returncode == 0, completed.stderr
    result = json.loads(completed.stdout)
    assert result["error"] == "F2_ELASTIC_SELECTED_PARAMETER_DRIFT"
    assert result["nonconvergence"] == "F2_ELASTIC_FIT_NONCONVERGENCE"
    source_map = [{"parent": name, "columns": [name]} for name in ("AST_ALT", "X", "Y")]
    for stopping in result["stopping"]:
        assert _validate_elastic_final_lambda_health(stopping, alpha=0.2, ratio=stopping["ratio"], ordered_parent_column_map=source_map) == stopping


@pytest.mark.parametrize("all_infeasible", [False, True])
def test_selector_producer_local_replay_and_failure_evidence(tmp_path, monkeypatch, all_infeasible):
    # F1 is read-only recipe/denominator context. All fit outputs below are
    # explicit synthetic fixtures; this is not scientific result acceptance.
    from padml._science_authority import selected_route_profiles
    from padml.bundle import read_safe_zip
    from padml.capsule import load_common_input
    from padml.f2 import materialize_requests

    authority = load_science_authority()
    common = Path("/Users/liuningyuan/Desktop/PAD/PADML_F2_V1_Runtime/build/common-input.zip")
    expected = load_common_input(common)["model_inputs"][0]
    request = materialize_requests(run_id="f2-selector-fixture", source_identity="1"*64,
                                  runtime_identity="2"*64, worker_identity="3"*64,
                                  input_identity="4"*64)["selector-f1-elastic-net-cox"]
    capsule = {"authority_slice": authority, "runtime": {"f2_backend": "CPU"},
               "manifest": {"identity_records": {"execution_plan": {"route_profiles": selected_route_profiles()}}}}
    repo_root = Path(kernel.__file__).resolve().parent
    spec = kernel.compile_model_spec(request, capsule, expected["lineage"], repo_root)
    recipes = expected["selector_recipe_expectations"]
    registered = {"partitions": expected["model_partitions"]}
    checkpoint = authority["science"]["f2_model_development"]["selector_review_checkpoint"]
    validation_n, events, parent_columns = validation._elastic_registered_facts(expected, checkpoint, spec["predictors"])
    column_map = kernel._expected_family_parent_column_map(
        sorted(kernel._elastic_parent_design_columns(spec["predictors"]), key=lambda value: value.encode("utf-8")),
        "ELASTIC_NET_COX", spec["predictors"], recipes["recipes"][-1],
    )
    source_columns = [column for row in column_map for column in row["columns"]]
    penalty_identity = _hash({"design_columns": source_columns,
                              "penalty_factor": [0.0 if row["parent"] == "AST_ALT" else 1.0
                                                 for row in column_map for _ in row["columns"]]})
    noncore = "Sex"
    assert parent_columns[noncore] == 2
    evaluated = []
    fitted = []

    def evaluate(_spec, _registered, _recipes, alphas, *_args):
        result = {}
        for alpha in alphas:
            assert alpha not in evaluated
            evaluated.append(alpha)
            record = _alpha_record(alpha)
            for path in record["outer_paths"]:
                coefficients = {parent: [[0.0] * count for _ in range(150)]
                                for parent, count in parent_columns.items()}
                for index in range(150):
                    if index >= 30 or all_infeasible or alpha == 0.05:
                        for parent, count in parent_columns.items():
                            if parent != "AST_ALT":
                                coefficients[parent][index] = [1.0] * count
                    else:
                        coefficients[noncore][index] = [1.0] * parent_columns[noncore]
                path.update(event_count=events, parent_design_columns=parent_columns,
                            parent_coefficients=coefficients,
                            coefficient_path_sha256=_hash({"parent_design_columns": parent_columns, "parent_coefficients": coefficients}),
                            penalized_design_column_count=sum(count for parent, count in parent_columns.items() if parent != "AST_ALT"),
                            penalized_active_count_path=[sum(value != 0 for parent, vectors in coefficients.items()
                                                            if parent != "AST_ALT" for value in vectors[index]) for index in range(150)])
                path["lambda_upper_bound"]["penalty_factor_identity_sha256"] = penalty_identity
            for partition in record["partition_losses"]:
                partition["validation_n"] = validation_n[(partition["repeat"], partition["inner_fold"])]
                partition["mi_lambda_path_health"] = [{key: copy.deepcopy(path[key]) for key in (
                    "imputation", "lambda_max", "lambda_path_sha256", "lambda_upper_bound",
                    "penalized_design_column_count", "penalized_active_count_path", "penalized_entry_covered",
                )} for path in record["outer_paths"]]
            result[alpha] = record
        return result

    def refit(_spec, _registered, tasks, *_args):
        fitted.extend(tasks)
        return [{"stopping": {"lambda": task["parameters"]["lambda"],
                              "lambda_upper_bound": task["parameters"]["lambda_upper_bound"]}}
                for task in tasks]

    monkeypatch.setattr(kernel, "_compile_transform_recipes", lambda *args: recipes)
    monkeypatch.setattr(kernel, "_evaluate_elastic_alpha_phase", evaluate)
    monkeypatch.setattr(kernel, "_run_r_prediction_batch", refit)
    monkeypatch.setattr(kernel, "_run_selector_sensitivity", lambda *args: {
        "identity_sha256": "a"*64, "execution_identity_sha256": "b"*64,
        "primary_writeback": "FORBIDDEN",
    })
    monkeypatch.setattr(kernel, "_registered_selection_execution_rows", lambda *args: [])
    monkeypatch.setattr(kernel, "_build_registered_model_result", lambda *args, **kwargs: kwargs)
    monkeypatch.setattr(validation, "_validate_selector_sensitivity_evidence", lambda *args: None)
    if all_infeasible:
        with pytest.raises(ContractError, match="F2_SELECTOR_EPV_UNRESOLVED"):
            kernel._run_r_registered_elastic(spec, registered, expected, tmp_path, repo_root, tmp_path)
        assert fitted == []
        assert len(list(tmp_path.glob("*.coarse-search.zip"))) == 1
        assert not list(tmp_path.glob("*.fine-search.zip"))
    else:
        produced = kernel._run_r_registered_elastic(spec, registered, expected, tmp_path, repo_root, tmp_path)
        selector = produced["selector"]
        assert selector["selected_parents"] == ["AST_ALT", "Sex"]
        assert len(fitted) == 20
        assert [task["parameters"]["lambda"] for task in fitted] == selector["final_refit_lambda_by_imputation"]
        assert validation._validate_selector_evidence(
            selector, spec["selector_contract"], spec["selector_sensitivity_contract"], checkpoint,
            spec["predictors"], expected, spec["primary_execution"], spec["selector_sensitivity_profiles"],
        ) == selector
        validation._validate_elastic_search_trace(produced["search_trace"], selector, _contract(),
                                                 produced["search_evaluation_unit_count"], validation_n, events, parent_columns,
                                                 predictors=spec["predictors"])
        stopping = [{"alpha": selector["common_alpha"], "ratio": ratio, "lambda": value,
                     "lambda_max": upper["resolved_lambda_max"], "lambda_upper_bound": upper,
                     "engine": "glmnet::glmnet", "converged": True, "imputation": index,
                     "selected_parent_sha256": selector["selected_parent_sha256"],
                     "selected_design_sha256": selector["selected_design_sha256"],
                     "prediction_seal_sha256": _hash(index)}
                    for index, (ratio, value, upper) in enumerate(zip(selector["selected_ratio_by_imputation"],
                        selector["final_refit_lambda_by_imputation"], selector["lambda_upper_bound_by_imputation"], strict=True), start=1)]
        binding = kernel._model_family_design_binding("ELASTIC_NET_COX", selector, spec["predictors"])
        prediction_identity = _hash([row["prediction_seal_sha256"] for row in stopping])
        validation._validate_elastic_final_stopping(stopping, selector, binding, prediction_identity,
                                                   predictors=spec["predictors"])
        for corruption in ("truncated", "wrong_column", "wrong_order"):
            broken_map = copy.deepcopy(column_map)
            if corruption == "truncated":
                broken_map = recipes["recipes"][-1]["ordered_parent_column_map"]
            elif corruption == "wrong_column":
                next(row for row in broken_map if row["parent"] == "Sex")["columns"][0] = "WRONG_CATEGORY"
            else:
                broken_map.reverse()
            bad_identity = _hash({
                "design_columns": [column for row in broken_map for column in row["columns"]],
                "penalty_factor": [0.0 if row["parent"] == "AST_ALT" else 1.0
                                   for row in broken_map for _ in row["columns"]],
            })
            assert bad_identity != penalty_identity
            broken_selector, broken_stopping = copy.deepcopy(selector), copy.deepcopy(stopping)
            # Both reports agree, but their identity must still match the trusted full design.
            for bounds in (broken_selector["lambda_upper_bound_by_imputation"],
                           [row["lambda_upper_bound"] for row in broken_stopping]):
                for upper in bounds:
                    upper["penalty_factor_identity_sha256"] = bad_identity
            with pytest.raises(ContractError, match="F2_ELASTIC_FINAL_REFIT_INVALID"):
                validation._validate_elastic_final_stopping(
                    broken_stopping, broken_selector, binding, prediction_identity, predictors=spec["predictors"],
                )
            broken_trace = copy.deepcopy(produced["search_trace"])
            broken_trace["derivation_records"][0]["partition_losses"][0]["mi_lambda_path_health"][0][
                "lambda_upper_bound"]["penalty_factor_identity_sha256"] = bad_identity
            with pytest.raises(ContractError, match="F2_SELECTOR_LAMBDA_PATH_HEALTH_INVALID"):
                validation._validate_elastic_search_trace(
                    broken_trace, selector, _contract(), produced["search_evaluation_unit_count"],
                    validation_n, events, parent_columns, predictors=spec["predictors"],
                )
        stopping[0]["ratio"] *= 0.9
        with pytest.raises(ContractError, match="F2_ELASTIC_FINAL_REFIT_INVALID"):
            validation._validate_elastic_final_stopping(stopping, selector, binding, prediction_identity,
                                                       predictors=spec["predictors"])
        broken_trace = copy.deepcopy(produced["search_trace"])
        broken_trace["alpha_feasibility"][0]["status"] = "EPV_INFEASIBLE"
        with pytest.raises(ContractError, match="F2_SELECTOR_ALPHA_FEASIBILITY_REPLAY_MISMATCH"):
            validation._validate_elastic_search_trace(broken_trace, selector, _contract(),
                                                     produced["search_evaluation_unit_count"], validation_n, events, parent_columns,
                                                     predictors=spec["predictors"])
    evidence = json.loads(read_safe_zip(tmp_path / f"{request['unit_id']}.coarse-search.zip")["selector-search.json"])
    assert evidence["identities"] == request["identities"]
    assert evidence["transaction_id"] == request["transaction_id"]
    assert evidence["scientific_acceptance"] is False
    assert len(evidence["derivation_records"]) == 7


_NATIVE_R_BOUNDARY = r'''
args <- commandArgs(trailingOnly=TRUE)
mode <- args[[2L]]
fixture <- fromJSON(args[[3L]], simplifyVector=FALSE)
source_map <- fixture$full_map
source_columns <- unlist(lapply(source_map, `[[`, "columns"), use.names=FALSE)
n_train <- as.integer(fixture$n_train)
n_test <- as.integer(fixture$n_test)
set.seed(203)
x <- matrix(rnorm((n_train+n_test)*length(source_columns)), ncol=length(source_columns),
            dimnames=list(NULL,source_columns))
x[,"AST_ALT"] <- abs(x[,"AST_ALT"]) + 0.2
for (row in source_map) {
  parent <- as.character(row$parent)
  if (parent %in% unlist(fixture$categorical_parents)) {
    cols <- unlist(row$columns, use.names=FALSE)
    x[,cols] <- 0
    category <- rep(seq_along(cols), length.out=nrow(x))
    x[cbind(seq_len(nrow(x)), match(cols[category],colnames(x)))] <- 1
  }
}
time_col <- "Death_Followup_months"
event_col <- "All_Cause_Death"
time <- rexp(n_train, exp(0.2*x[seq_len(n_train),"AST_ALT"])) * 60 + 0.01
event <- rep(c(1L,1L,1L,0L), length.out=n_train)
train <- data.frame(time=time,event=event)
names(train) <- c(time_col,event_col)
test <- data.frame(row=seq_len(n_test))
penalty <- ifelse(source_columns == "AST_ALT",0,1)
if (mode == "upper") {
  upper <- data_driven_cox_lambda_upper_bound(x[seq_len(n_train),,drop=FALSE],time,event,0.2,penalty)
  cat(canonical_json(upper))
  quit(save="no",status=0L)
}
stopifnot(mode == "fit")
spec <- fromJSON(args[[4L]], simplifyVector=FALSE)
tasks <- spec$producer_tasks
partition <- spec$registered_partitions$partitions[[1L]]
hex_double <- function(value) paste(sprintf("%02x",as.integer(writeBin(as.double(value),raw(),size=8L,endian="little"))),collapse="")
input_bits <- list()
glmnet_bits <- list()
native_glmnet <- glmnet
glmnet <- function(...) {
  values <- list(...)
  stopifnot(length(values$lambda) == 1L)
  glmnet_bits[[length(glmnet_bits)+1L]] <<- hex_double(values$lambda)
  native_glmnet(...)
}
data_driven_cox_lambda_upper_bound <- function(...) stop("UNAUTHORIZED_RETUNE")
rows <- lapply(tasks,function(task) {
  selected <- as.character(unlist(task$selected_parents,use.names=FALSE))
  selected_map <- lapply(selected,function(parent) {
    source_map[[which(vapply(source_map,function(row) identical(as.character(row$parent),parent),logical(1)))]]
  })
  columns <- unlist(lapply(selected_map,`[[`,"columns"),use.names=FALSE)
  mapping <- do.call(rbind,lapply(selected_map,function(row) data.frame(parent=as.character(row$parent),column=unlist(row$columns,use.names=FALSE))))
  prepared <- list(train_mapping=list(x=x[seq_len(n_train),columns,drop=FALSE],parent_map=mapping),
                   test_mapping=list(x=x[n_train+seq_len(n_test),columns,drop=FALSE],parent_map=mapping))
  parameters <- task$parameters
  parameters$imputation_index <- as.integer(task$imputation)
  locked <- elastic_locked_parameters(parameters)
  input_bits[[length(input_bits)+1L]] <<- hex_double(locked$lambda)
  horizons <- as.numeric(unlist(task$prediction_horizons,use.names=FALSE))
  fitted <- fit_predict("ELASTIC_NET_COX",train,test,selected,parameters,as.integer(task$seed),horizons,NULL,prepared_design=prepared)
  stopifnot(identical(fitted$stopping$lambda,locked$lambda))
  list(task_id=task$task_id,partition_id=task$partition_id,imputation=task$imputation,
       evaluation_ids=partition$evaluation_ids,
       transform_recipe_sha256=spec$transform_recipe$recipe_sha256,
       ordered_parent_column_map=fitted$ordered_parent_column_map,
       survival=lapply(seq_len(nrow(fitted$survival)),function(i) as.list(as.numeric(fitted$survival[i,]))),
       stopping=fitted$stopping)
})
result <- list(schema_version="1.0.0",kind="PADML_F2_R_PREDICTION_BATCH",status="PASS",task_count=length(tasks),tasks=rows)
writeLines(canonical_json(result),as.character(spec$output_path),useBytes=TRUE)
cat(canonical_json(list(input_bits=input_bits,glmnet_bits=glmnet_bits,fit_count=length(glmnet_bits))))
'''


@pytest.fixture(scope="module")
def native_setup(tmp_path_factory):
    # Only locked schemas are reused; data, IDs and recipe values are synthetic.
    # This exercises the fit/JSON consumer, not MICE or a scientific search.
    from padml._science_authority import selected_route_profiles
    from padml.f2 import materialize_requests

    root = tmp_path_factory.mktemp("native-elastic-boundary")
    executable = shutil.which("Rscript")
    assert executable is not None
    script = root / "native-boundary.R"
    script.write_text(_NATIVE_R_FUNCTIONS + _NATIVE_R_BOUNDARY)
    request = materialize_requests(
        run_id="elastic-boundary-fixture", source_identity="1"*64,
        runtime_identity="2"*64, worker_identity="3"*64, input_identity="4"*64,
    )["selector-f1-elastic-net-cox"]
    capsule = {
        "authority_slice": load_science_authority(), "runtime": {"f2_backend": "CPU"},
        "manifest": {"identity_records": {"execution_plan": {"route_profiles": selected_route_profiles()}}},
    }
    spec = kernel.compile_model_spec(request, capsule, {}, _F2_PACKAGE_ROOT)
    predictors = spec["predictors"]
    fit_ids = [f"fixture-train-{i}" for i in range(160)]
    eval_ids = [f"fixture-test-{i}" for i in range(24)]
    representations = []
    for row in predictors["transform_registry"]["rows"]:
        if row["parent"] == "eGFR_calc":
            continue
        representation = row["representation"]
        contract = predictors["representation_contract"][representation]
        representations.append({
            "parent": row["parent"], "canonical_unit": row["canonical_unit"],
            "representation": representation, "design_df": contract["design_df"],
            "design_columns": [row["parent"] + suffix for suffix in contract["column_suffixes"]],
            "parameters": {
                "IDENTITY": {"identity": True},
                "LOG1P": {"canonical_unit_scale": 1},
                "NATURAL_SPLINE_K3": {"boundary_knots": [0, 2], "interior_knots": [1], "quantile_type": 7},
            }[representation],
        })
    recipe = {
        "recipe_schema_version": "1.0.0", "kind": "PADML_F2_TRANSFORM_RECIPE",
        "partition_id": "FIXTURE_OUTER", "transform_registry_sha256": predictors["transform_registry_sha256"],
        "analysis_view_sha256": "b"*64, "analysis_ids_sha256": _hash(fit_ids),
        "fit_ids_sha256": _hash(fit_ids), "training_member_set_sha256": "c"*64,
        "representations": representations,
        "ordered_parent_column_map": [
            {"parent": row["parent"], "columns": row["design_columns"]} for row in representations
        ],
    }
    recipe["recipe_sha256"] = _hash(recipe)
    full_map = kernel._expected_family_parent_column_map(
        kernel._elastic_candidate_parents(spec), "ELASTIC_NET_COX", predictors, recipe,
    )
    categorical = [row["name"] for row in predictors["variables"] if row["type"] in {"binary", "ordered", "unordered"}]
    fixture_path = root / "fixture-design.json"
    fixture_path.write_bytes(canonical_json_bytes({
        "full_map": full_map, "categorical_parents": categorical, "n_train": 160, "n_test": 24,
    }))
    completed = _NATIVE_R_RUN(
        [executable, "--vanilla", str(script), str(_F2_PACKAGE_ROOT / "kernels/f2_model_development.R"),
         "upper", str(fixture_path)], capture_output=True, text=True, timeout=60,
    )
    assert completed.returncode == 0, completed.stderr
    upper = json.loads(completed.stdout)
    kernel._validate_elastic_lambda_upper_bound(upper, alpha=.2, ordered_parent_column_map=full_map)
    assert (len(recipe["ordered_parent_column_map"]), len(full_map),
            sum(len(row["columns"]) for row in full_map)) == (26, 44, 70)
    with pytest.raises(ContractError, match="F2_ELASTIC_PENALTY_IDENTITY_INVALID"):
        kernel._validate_elastic_lambda_upper_bound(
            upper, alpha=.2, ordered_parent_column_map=recipe["ordered_parent_column_map"],
        )
    ratios = kernel._elastic_ratios(spec["selector_contract"])[7:27]
    lambdas = [upper["resolved_lambda_max"] * ratio for ratio in ratios]
    registered = {
        "projected_partition_ids": ["FIXTURE_OUTER"], "projected_partition_count": 1,
        "partitions": [{"partition_id": "FIXTURE_OUTER", "fit_ids": fit_ids,
                        "evaluation_ids": eval_ids, "evaluation_ids_sha256": _hash(eval_ids)}],
    }
    return root, spec, recipe, full_map, ["AST_ALT", "Sex"], fixture_path, upper, ratios, lambdas, registered


@pytest.fixture(scope='module',params=['scalar','vector'])
def native_results(native_setup,request):
    root,spec,recipe,full_map,selected,fixture_path,upper,ratios,lambdas,registered = native_setup
    scalar = request.param == 'scalar'
    tasks = []
    for imp in range(1,21):
        params = {'alpha':.2,'imputation_index':imp}
        params.update({'ratio':ratios[imp-1],'lambda':lambdas[imp-1],'lambda_upper_bound':copy.deepcopy(upper)} if scalar else {
            'ratio_by_imputation':ratios.copy(),'lambda_by_imputation':lambdas.copy(),
            'lambda_upper_bound_by_imputation':[copy.deepcopy(upper) for _ in range(20)]})
        tasks.append({'task_id':f'FINAL_OUTER_M{imp:02d}','partition_id':'FIXTURE_OUTER','imputation':imp,
                      'family':'ELASTIC_NET_COX','selected_parents':selected.copy(),'parameters':params,
                      'transform_recipe':recipe,'prediction_horizons':spec['monthly_fit_horizons'],'seed':301000+imp})
    scratch = root/request.param
    scratch.mkdir()
    captured = {}
    # Use the exact pool-child projection from _run_r_prediction_batch,
    # including its monthly horizon override, rather than the richer parent.
    child_spec = {**kernel._r_prediction_child_spec(spec), 'horizons':spec['monthly_fit_horizons']}

    def native_driver(command,**kwargs):
        spec_path = Path(command[-1])
        kwargs['timeout'] = 60
        completed = _NATIVE_R_RUN([shutil.which("Rscript"),'--vanilla',str(root / "native-boundary.R"),str(_F2_PACKAGE_ROOT / "kernels/f2_model_development.R"),'fit',str(fixture_path),str(spec_path)],**kwargs)
        if completed.returncode == 0:
            emitted = json.loads(spec_path.read_bytes())
            captured['payload'] = json.loads(Path(emitted['output_path']).read_bytes())
            captured['witness'] = json.loads(completed.stdout)
        return completed

    with pytest.MonkeyPatch.context() as monkeypatch:
        monkeypatch.setattr(kernel.subprocess,'run',native_driver)
        produced = kernel._run_r_prediction_partition_batch(child_spec,registered,tasks,scratch,_F2_PACKAGE_ROOT)
    return child_spec,registered,tasks,produced,captured,lambdas,upper,full_map,request.param


def test_native_locked_bits_roundtrip_and_posthealth_exact_comparison(native_results):
    spec,registered,tasks,produced,captured,lambdas,upper,full_map,mode = native_results
    witness = captured['witness']
    expected_bits = [struct.pack('<d',value).hex() for value in lambdas]
    assert witness['input_bits'] == witness['glmnet_bits'] == expected_bits
    assert witness['fit_count'] == 20
    raw = [row['stopping']['lambda'] for row in captured['payload']['tasks']]
    assert any(left != right for left,right in zip(raw,lambdas,strict=True))
    assert all(math.isclose(left,right,rel_tol=1e-12,abs_tol=1e-15) for left,right in zip(raw,lambdas,strict=True))
    # The identical 20-MI comparison used in _run_r_registered_elastic remains strict.
    assert [row['stopping']['lambda'] for row in produced] == lambdas
    assert [row['stopping']['lambda_upper_bound'] for row in produced] == [upper]*20
    for row in produced:
        assert row['ordered_parent_column_map'] == kernel._expected_family_parent_column_map(['AST_ALT','Sex'],'ELASTIC_NET_COX',spec['predictors'],tasks[0]['transform_recipe'])
        assert row['sealed_prediction']['payload']['horizons'] == spec['horizons']
    print(json.dumps({'mode':mode,'input_bits_equal':20,'glmnet_bits_equal':20,
                      'rounded_reports':sum(left!=right for left,right in zip(raw,lambdas,strict=True)),
                      'max_relative_rounding':max(abs(left-right)/right for left,right in zip(raw,lambdas,strict=True)),
                      'full_parents':len(full_map),'full_columns':sum(len(row['columns']) for row in full_map),
                      'normalization_after_health':True},sort_keys=True))


@pytest.mark.parametrize('corruption',['wrong_mi','missing_mi','wrong_lambda','missing_lambda','nan_lambda',
                                        'wrong_upper','missing_upper','continuous_only_upper','nonconvergence','wrong_ratio'])
def test_native_consumer_still_rejects_corruption(native_results,tmp_path,monkeypatch,corruption):
    spec,registered,tasks,produced,captured,lambdas,upper,full_map,mode = native_results
    tasks = copy.deepcopy(tasks)
    payload = copy.deepcopy(captured['payload'])
    row = payload['tasks'][5]
    if corruption == 'wrong_mi':
        row['imputation'] = 7
    elif corruption == 'missing_mi':
        payload['tasks'].pop()
    elif corruption == 'wrong_lambda':
        row['stopping']['lambda'] *= 1.01
    elif corruption == 'missing_lambda':
        del row['stopping']['lambda']
    elif corruption == 'nan_lambda':
        row['stopping']['lambda'] = float('nan')
    elif corruption == 'wrong_upper':
        row['stopping']['lambda_upper_bound']['resolved_lambda_max'] *= 1.01
    elif corruption == 'missing_upper':
        del row['stopping']['lambda_upper_bound']
    elif corruption == 'continuous_only_upper':
        mapping = tasks[5]['transform_recipe']['ordered_parent_column_map']
        bad_identity = kernel._sha({'design_columns':[column for item in mapping for column in item['columns']],
                                    'penalty_factor':[0.0 if item['parent']=='AST_ALT' else 1.0 for item in mapping for column in item['columns']]})
        row['stopping']['lambda_upper_bound']['penalty_factor_identity_sha256'] = bad_identity
        params = tasks[5]['parameters']
        item = params['lambda_upper_bound'] if mode == 'scalar' else params['lambda_upper_bound_by_imputation'][5]
        item['penalty_factor_identity_sha256'] = bad_identity
    elif corruption == 'nonconvergence':
        row['stopping']['converged'] = False
    elif corruption == 'wrong_ratio':
        row['stopping']['ratio'] *= .9

    def native_output_fixture(command,**kwargs):
        body = json.loads(Path(command[-1]).read_bytes())
        Path(body['output_path']).write_text(json.dumps(payload,allow_nan=True))
        return subprocess.CompletedProcess(command,0,'','')

    monkeypatch.setattr(kernel.subprocess,'run',native_output_fixture)
    with pytest.raises(ContractError):
        kernel._run_r_prediction_partition_batch(spec,registered,tasks,tmp_path,_F2_PACKAGE_ROOT)


# Complete synthetic native-shaped paths: these tests do not call a scientific engine.
from padml import nested_loco

_FORMAL_FREQUENCY_LADDER = [(15, 12), (10, 12), (10, 14), (10, 16), (10, 18), (10, 20)]
_FORMAL_FREQUENCY_HEALTH = ('imputation', 'lambda_max', 'lambda_path_sha256', 'lambda_upper_bound',
          'penalized_design_column_count', 'penalized_active_count_path', 'penalized_entry_covered')


def _formal_reseal(record, *, natural=False):
    """Rebuild every health/hash field after explicit synthetic coefficients."""
    for row in record['outer_paths']:
        row['penalized_active_count_path'] = [
            sum(v != 0 for p, vectors in row['parent_coefficients'].items()
                if p != 'AST_ALT' or natural for v in vectors[index])
            for index in range(150)]
        row['penalized_entry_covered'] = max(row['penalized_active_count_path']) > 0
        row['coefficient_path_sha256'] = _hash({
            'parent_design_columns': row['parent_design_columns'],
            'parent_coefficients': row['parent_coefficients']})
    for part in record['partition_losses']:
        part['mi_lambda_path_health'] = [{key: copy.deepcopy(row[key]) for key in _FORMAL_FREQUENCY_HEALTH}
                                       for row in record['outer_paths']]
    return record


def _formal_frequency_record(alpha, frequency, *, events=40, natural=False):
    record = _alpha_record(alpha)
    for row in record['outer_paths']:
        row['event_count'] = events
        for index in range(30):
            row['parent_coefficients']['X'][index] = [1., 0., 0.] if row['imputation'] <= frequency else [0., 0., 0.]
            row['parent_coefficients']['Y'][index] = [1.]
        if natural:
            row['parent_coefficients']['AST_ALT'] = [[1.] for _ in range(150)]
            row['penalized_design_column_count'] = 5
            row['lambda_upper_bound']['penalty_factor_identity_sha256'] = _hash({
                'design_columns': ['AST_ALT', 'X_0', 'X_1', 'X_2', 'Y'], 'penalty_factor': [1.] * 5})
    return _formal_reseal(record, natural=natural)


def _formal_no_aar_record(alpha, *, empty=False, pathological=False):
    record, domain = _no_aar_record(zero_count=20 if empty else 0)
    delta = alpha - record['alpha']
    record['alpha'] = alpha
    for row in record['outer_paths']:
        row['lambda_upper_bound']['alpha'] = alpha
        if empty:
            row['event_count'] = 20
        if pathological:
            for parent, vectors in row['parent_coefficients'].items():
                row['parent_coefficients'][parent] = [[0.] * len(vectors[0]) for _ in range(150)]
    for part in record['partition_losses']:
        part['mi_losses'] = [[value + delta for value in path] for path in part['mi_losses']]
    if empty:
        domain['outer_training_event_count'] = 20
    return _formal_reseal(record), domain


def _formal_coarse(builder):
    alphas = list(map(float, _contract()['alpha_grid']['coarse']))
    return [builder(alpha) for alpha in alphas], alphas


def _formal_trace_pairs(trace):
    return [(attempt['minimum'], attempt.get('frequency_threshold', 12)) for attempt in trace['attempts']]


@pytest.mark.parametrize('tier', range(6))
def test_formal_ladder_locks_first_complete_feasible_tier(tier, monkeypatch):
    if tier == 0:
        builder = _alpha_record
    elif tier == 1:
        builder = lambda alpha: _formal_frequency_record(alpha, 20, events=60)
    else:
        builder = lambda alpha: _formal_frequency_record(alpha, _FORMAL_FREQUENCY_LADDER[tier][1] - 1)
    records, alphas = _formal_coarse(builder)
    before = canonical_json_bytes(records)
    calls = []
    original = kernel._summarize_elastic_alpha
    def summarize(record, contract, **kwargs):
        calls.append((record['alpha'], contract['epv_contract']['minimum']))
        return original(record, contract, **kwargs)
    monkeypatch.setattr(kernel, '_summarize_elastic_alpha', summarize)
    chosen, summaries, trace, resolved = kernel._choose_elastic_coarse_epv_tier(
        records, alphas, _contract(), formal_frequency_fallback=True)
    minimum, threshold = _FORMAL_FREQUENCY_LADDER[tier]
    assert chosen['status'] == 'FEASIBLE'
    assert chosen['alpha'] == alphas[0]
    assert resolved['epv_contract']['minimum'] == minimum
    assert resolved['ratio_decision']['epv_minimum'] == minimum
    assert resolved['frequency_threshold'] == threshold
    assert resolved['formal_frequency_policy']
    assert _formal_trace_pairs(trace) == _FORMAL_FREQUENCY_LADDER[:tier + 1]
    assert all(row['status'] != 'FEASIBLE' for attempt in trace['attempts'][:-1]
               for row in attempt['alpha_feasibility'])
    assert calls == [(alpha, stage) for stage in ([15] if tier == 0 else [15, 10]) for alpha in alphas]
    assert canonical_json_bytes(records) == before
    assert chosen['selected_parents'] == (['AST_ALT', 'X'] if tier == 0 else
                                          ['AST_ALT', 'X', 'Y'] if tier == 1 else ['AST_ALT', 'Y'])
    if tier >= 2:
        old10 = copy.deepcopy(_contract())
        old10['epv_contract']['minimum'] = old10['ratio_decision']['epv_minimum'] = 10
        baseline = original(records[0], old10)
        assert baseline['status'] == 'EPV_INFEASIBLE'
        for field in ('imputation_decisions', 'selected_ratio_by_imputation', 'lambda_by_imputation',
                      'mean_loss_at_selected_parameters', 'active_design_df_by_imputation',
                      'median_active_design_df', 'p90_active_design_df', 'natural_frequency'):
            assert chosen[field] == baseline[field], field
        assert chosen['common_set_design_df'] == 2
        assert chosen['common_set_epv'] == 20


def test_formal_complete_coarse_does_not_hide_late_numeric_damage():
    records, alphas = _formal_coarse(_alpha_record)
    records[-1]['outer_paths'][-1]['coefficient_path_sha256'] = '0' * 64
    with pytest.raises(ContractError, match='F2_SELECTOR_COEFFICIENT_REPLAY_MISMATCH'):
        kernel._choose_elastic_coarse_epv_tier(records, alphas, _contract(),
                                              formal_frequency_fallback=True)


def test_formal_empty_frequency_does_not_hide_later_damage():
    records, alphas = _formal_coarse(lambda alpha: _formal_no_aar_record(alpha, empty=True)[0])
    domain = _formal_no_aar_record(alphas[0], empty=True)[1]
    records[-1]['outer_paths'][-1]['coefficient_path_sha256'] = '0' * 64
    with pytest.raises(ContractError, match='F2_SELECTOR_COEFFICIENT_REPLAY_MISMATCH'):
        kernel._choose_elastic_coarse_epv_tier(records, alphas, _contract(),
            no_aar_redevelopment=domain, formal_frequency_fallback=True)


def test_formal_empty_frequency_is_valid_infeasible_not_a_replacement(monkeypatch):
    records, alphas = _formal_coarse(lambda alpha: _formal_no_aar_record(alpha, empty=True)[0])
    domain = _formal_no_aar_record(alphas[0], empty=True)[1]
    outputs = []
    original = kernel._summarize_elastic_alpha
    def summarize(record, contract, **kwargs):
        row = original(record, contract, **kwargs)
        outputs.append((record['alpha'], contract['epv_contract']['minimum'], row))
        return row
    monkeypatch.setattr(kernel, '_summarize_elastic_alpha', summarize)
    chosen, summaries, trace, resolved = kernel._choose_elastic_coarse_epv_tier(
        records, alphas, _contract(), no_aar_redevelopment=domain, formal_frequency_fallback=True)
    assert chosen['status'] == trace['status'] == 'NOT_ESTIMABLE'
    assert chosen['reason_code'] == trace['reason_code'] == 'FREQUENCY_LADDER_EXHAUSTED'
    assert _formal_trace_pairs(trace) == _FORMAL_FREQUENCY_LADDER
    assert nested_loco.validate_epv_resolution(trace) == trace
    assert resolved['frequency_threshold'] == 20
    assert [(a, minimum) for a, minimum, _ in outputs] == [(a, minimum) for minimum in (15, 10) for a in alphas]
    for _, _, summary in outputs:
        assert summary['status'] == 'NOT_ESTIMABLE'
        assert summary['reason_code'] == 'EMPTY_FREQUENCY_AGGREGATE'
        assert summary['common_set_design_df'] == 0 and summary['common_set_epv'] is None
        assert summary['selected_parents'] == []


def test_formal_native_nonentry_path_is_not_frequency_fallback():
    records, alphas = _formal_coarse(lambda alpha: _formal_no_aar_record(alpha, empty=True, pathological=True)[0])
    domain = _formal_no_aar_record(alphas[0], empty=True)[1]
    with pytest.raises(ContractError, match='F2_SELECTOR_LAMBDA_PATH_HEALTH_INVALID'):
        kernel._choose_elastic_coarse_epv_tier(records, alphas, _contract(),
            no_aar_redevelopment=domain, formal_frequency_fallback=True)


def test_formal_fine_uses_locked_pair_and_retains_coarse_candidate():
    records, alphas = _formal_coarse(lambda alpha: _formal_frequency_record(alpha, 15))
    chosen, _, trace, resolved = kernel._choose_elastic_coarse_epv_tier(
        records, alphas, _contract(), formal_frequency_fallback=True)
    assert (resolved['epv_contract']['minimum'], resolved['frequency_threshold']) == (10, 16)
    grid = _contract()['alpha_grid']['fine']
    lower, upper = grid['clip']
    fine = sorted({min(upper, max(lower, round(chosen['alpha'] + offset, 3))) for offset in grid['offsets']})
    assert chosen['alpha'] in fine
    cache = {row['alpha']: row for row in records}
    missing = [alpha for alpha in fine if alpha not in cache]
    cache.update({alpha: _formal_frequency_record(alpha, 15) for alpha in missing})
    before = canonical_json_bytes(trace)
    best, summaries = kernel._choose_elastic_alpha([cache[a] for a in fine], fine, resolved)
    assert next(row for row in summaries if row['alpha'] == chosen['alpha']) == chosen
    assert best['selected_parents'] == ['AST_ALT', 'Y']
    assert all(row['status'] == 'FEASIBLE' for row in summaries)
    assert len(cache) <= 15 and canonical_json_bytes(trace) == before


def test_default_no_aar_empty_contract_is_unchanged():
    record, domain = _formal_no_aar_record(0.2, empty=True)
    with pytest.raises(ContractError, match='NESTED_NO_AAR_SELECTOR_EMPTY_SETA'):
        kernel._summarize_elastic_alpha(record, _contract(), no_aar_redevelopment=domain)


def test_default_fixed_seta_never_reselects_frequency():
    records, alphas = _formal_coarse(lambda alpha: _formal_no_aar_record(alpha)[0])
    domain = _formal_no_aar_record(alphas[0])[1]
    fixed = {**domain, 'selected_parents': list(domain['parent_design_columns']),
             'common_set_design_df': sum(domain['parent_design_columns'].values())}
    seen = []
    def summarize(record, contract):
        assert 'formal_frequency_policy' not in contract and 'frequency_threshold' not in contract
        seen.append((record['alpha'], contract['epv_contract']['minimum']))
        return kernel._summarize_elastic_alpha(record, contract, fixed_a12=fixed)
    chosen, _, trace, resolved = kernel._choose_elastic_coarse_epv_tier(
        records, alphas, _contract(), summarize=summarize)
    assert _formal_trace_pairs(trace) == _FORMAL_FREQUENCY_LADDER[:2]
    assert seen == [(a, minimum) for minimum in (15, 10) for a in alphas]
    assert chosen['selected_parents'] == ['X', 'Y'] and chosen['parent_reselection_count'] == 0
    assert 'natural_frequency' not in chosen and 'formal_frequency_policy' not in resolved


def test_default_natural_diagnostic_keeps_two_tiers(monkeypatch):
    records, alphas = _formal_coarse(lambda alpha: _formal_frequency_record(alpha, 13, natural=True))
    contract = {**_contract(), 'ast_alt_natural_audit': True, 'ast_alt_formal_penalty_factor': 1}
    calls = []
    original = kernel._summarize_elastic_alpha
    def summarize(record, resolved, **kwargs):
        assert 'formal_frequency_policy' not in resolved and 'frequency_threshold' not in resolved
        calls.append((record['alpha'], resolved['epv_contract']['minimum']))
        return original(record, resolved, **kwargs)
    monkeypatch.setattr(kernel, '_summarize_elastic_alpha', summarize)
    with pytest.raises(ContractError, match='NESTED_SELECTOR_EPV_BELOW_10') as error:
        kernel._choose_elastic_coarse_epv_tier(records, alphas, contract)
    assert calls == [(a, minimum) for minimum in (15, 10) for a in alphas]
    assert _formal_trace_pairs(error.value.natural_diagnostic) == _FORMAL_FREQUENCY_LADDER[:2]


@pytest.fixture(scope='module')
def formal_frequency_resolution():
    records, alphas = _formal_coarse(lambda alpha: _formal_frequency_record(alpha, 15))
    chosen, summaries, trace, resolved = kernel._choose_elastic_coarse_epv_tier(
        records, alphas, _contract(), formal_frequency_fallback=True)
    assert nested_loco.validate_epv_resolution(trace) == trace
    return trace


@pytest.mark.parametrize('damage', ['skip_tier', 'tier_order', 'earlier_success', 'foreign_policy',
                                    'lock_threshold', 'common_epv'])
def test_formal_resolution_rejects_changed_ladder_or_feasibility(formal_frequency_resolution, damage):
    trace = copy.deepcopy(formal_frequency_resolution)
    if damage == 'skip_tier':
        trace['attempts'].pop(1)
    elif damage == 'tier_order':
        trace['attempts'][1], trace['attempts'][2] = trace['attempts'][2], trace['attempts'][1]
    elif damage == 'earlier_success':
        first = trace['attempts'][0]['alpha_feasibility'][0]
        first.update(status='FEASIBLE', reason_code='OK', common_set_design_df=1, common_set_epv=40)
    elif damage == 'foreign_policy':
        trace['frequency_policy_sha256'] = '0' * 64
    elif damage == 'lock_threshold':
        trace['frequency_threshold'] = 18
    else:
        trace['attempts'][-1]['alpha_feasibility'][0]['common_set_epv'] = 9.9999
    with pytest.raises(ContractError):
        nested_loco.validate_epv_resolution(trace)


def test_formal_no_epv_ratio_cannot_be_repaired_by_frequency(monkeypatch):
    def builder(alpha):
        record = _alpha_record(alpha)
        for row in record['outer_paths']:
            row['event_count'] = 10
        return record
    records, alphas = _formal_coarse(builder)
    chosen, summaries, trace, resolved = kernel._choose_elastic_coarse_epv_tier(
        records, alphas, _contract(), formal_frequency_fallback=True)
    assert chosen['status'] == 'NOT_ESTIMABLE'
    assert _formal_trace_pairs(trace) == _FORMAL_FREQUENCY_LADDER
    assert all(row['reason_code'] == 'IMPUTATION_HAS_NO_EPV_FEASIBLE_RATIO' for row in summaries)
    assert nested_loco.validate_epv_resolution(trace) == trace


@pytest.mark.parametrize('scope', ['natural', 'fixed_callback'])
def test_formal_flag_rejects_nonformal_scopes(scope):
    records, alphas = _formal_coarse(_alpha_record)
    contract = _contract()
    options = {'formal_frequency_fallback': True}
    if scope == 'natural':
        contract = {**contract, 'ast_alt_natural_audit': True, 'ast_alt_formal_penalty_factor': 1}
    else:
        def forbidden(*args, **kwargs):
            pytest.fail('Formal fallback entered a fixed-SetA callback')
        options['summarize'] = forbidden
    with pytest.raises(ContractError, match='NESTED_SELECTOR_FREQUENCY_SCOPE_INVALID'):
        kernel._choose_elastic_coarse_epv_tier(records, alphas, contract, **options)


def test_actual_selector_terminal_control_flow_keeps_coarse_and_has_no_fine(tmp_path):
    """Run unchanged selector reduction/control-flow AST, no native I/O ABI claim."""
    import ast
    from copy import deepcopy
    from padml import f4
    module = ast.parse(Path(f4.__file__).read_text())
    function = next(node for node in module.body if isinstance(node, ast.FunctionDef) and node.name == '_full_pipeline_selector_search')
    start = next(i for i, node in enumerate(function.body) if isinstance(node, ast.Assign)
                 and any(isinstance(target, ast.Name) and target.id == 'coarse' for target in node.targets))
    stop = next(i for i, node in enumerate(function.body[start:], start) if isinstance(node, ast.Assign)
                and any(isinstance(target, ast.Name) and target.id == 'result' for target in node.targets))
    body = deepcopy(function.body[start:stop + 1])
    body.append(ast.Return(value=ast.Tuple(elts=[ast.Name(id='result', ctx=ast.Load()),
                                               ast.Name(id='cache', ctx=ast.Load())], ctx=ast.Load())))
    probe = ast.FunctionDef(name='probe', args=ast.arguments(posonlyargs=[], args=[], kwonlyargs=[], kw_defaults=[], defaults=[]),
                            body=body, decorator_list=[])
    contract = _contract()
    records = {}
    for alpha in contract['alpha_grid']['coarse']:
        record = _alpha_record(float(alpha))
        for path in record['outer_paths']:
            path['event_count'] = 10
        records[float(alpha)] = record
    before = canonical_json_bytes([records[alpha] for alpha in sorted(records)])
    phases = []
    def phase(alphas, name):
        phases.append(name)
        assert name == 'coarse'
        return {alpha: records[alpha] for alpha in alphas}
    def forbidden_fine(*args, **kwargs):
        pytest.fail('Terminal selector invoked fine selection')
    env = {**f4.__dict__, 'phase': phase, 'contract': contract, 'nested': True, 'natural_audit': False,
        'sharded': False, 'phase_name': None, 'task_ids': None, 'common_set_epv_binding': None,
        'no_aar_domain': None, 'replay': False, 'root': tmp_path, 'context': {'source': {'TEST_ONLY': True}},
        '_choose_elastic_coarse_epv_tier': kernel._choose_elastic_coarse_epv_tier,
        '_choose_elastic_alpha': forbidden_fine}
    exec(compile(ast.fix_missing_locations(ast.Module(body=[probe], type_ignores=[])), '<actual-f4-reduction>', 'exec'), env)
    result, cache = env['probe']()
    assert result['selector']['status'] == 'NOT_ESTIMABLE'
    assert result['fine_alpha_order'] == [] and result['distinct_alpha_count'] == 7
    assert result['selector_path_count'] == 2240 and result['final_model_fits'] == result['new_mice_chains'] == 0
    assert canonical_json_bytes([cache[alpha] for alpha in sorted(cache)]) == before and phases == ['coarse']
    (tmp_path / 'selector.json').write_bytes(canonical_json_bytes(result))
    env['replay'] = True
    replayed, cache = env['probe']()
    assert canonical_json_bytes(replayed) == canonical_json_bytes(result)
    assert canonical_json_bytes([cache[alpha] for alpha in sorted(cache)]) == before and phases == ['coarse', 'coarse']


@pytest.mark.parametrize("member", ["outer-coefficients", "inner-losses"])
def test_formal_full_path_cannot_be_replaced_by_selected_slice(member):
    records, alphas = _formal_coarse(_alpha_record)
    last = records[-1]
    if member == "outer-coefficients":
        row = last["outer_paths"][-1]
        row["parent_coefficients"] = {name: [vectors[0]]
            for name, vectors in row["parent_coefficients"].items()}
        # A freshly sealed compact record is still not a complete 150-point
        # scientific path; rejection must not depend on an obsolete hash.
        row["coefficient_path_sha256"] = _hash({
            "parent_design_columns": row["parent_design_columns"],
            "parent_coefficients": row["parent_coefficients"]})
        failure = "F2_SELECTOR_OUTER_PATH_INVALID"
    else:
        last["partition_losses"][-1]["mi_losses"][-1] = [
            last["partition_losses"][-1]["mi_losses"][-1][0]]
        failure = "F2_SELECTOR_PARTITION_LOSS_INVALID"
    with pytest.raises(ContractError, match=failure):
        kernel._choose_elastic_coarse_epv_tier(records, alphas, _contract(),
            formal_frequency_fallback=True)


def test_formal_fine_cannot_hide_damage_behind_qualified_coarse_winner():
    records, alphas = _formal_coarse(lambda alpha: _formal_frequency_record(alpha, 15))
    chosen, _, trace, resolved = kernel._choose_elastic_coarse_epv_tier(
        records, alphas, _contract(), formal_frequency_fallback=True)
    assert (resolved["epv_contract"]["minimum"], resolved["frequency_threshold"]) == (10, 16)
    grid = _contract()["alpha_grid"]["fine"]
    lower, upper = grid["clip"]
    fine = sorted({min(upper, max(lower, round(chosen["alpha"] + offset, 3)))
                   for offset in grid["offsets"]})
    assert chosen["alpha"] in fine
    cache = {row["alpha"]: row for row in records}
    cache.update({alpha: _formal_frequency_record(alpha, 15) for alpha in fine if alpha not in cache})
    damaged = next(alpha for alpha in reversed(fine) if alpha != chosen["alpha"])
    cache[damaged]["partition_losses"][-1]["mi_losses"][-1][-1] = float("nan")
    before = canonical_json_bytes(trace)
    with pytest.raises(ContractError, match="F2_SELECTOR_PARTITION_LOSS_INVALID"):
        kernel._choose_elastic_alpha([cache[alpha] for alpha in fine], fine, resolved)
    assert canonical_json_bytes(trace) == before
