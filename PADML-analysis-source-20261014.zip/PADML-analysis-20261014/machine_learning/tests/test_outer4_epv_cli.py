"""CLI-only regression: real JSON loader, mocked scientific entry, no computation."""
from contextlib import redirect_stdout
import io
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

from padml import f5, f5_sensitivity as sensitivity
from padml.bundle import ContractError, canonical_json_bytes


def test_fine_executor_source_allows_q_atoms_but_not_new_selector_paths(tmp_path, monkeypatch):
    import pytest
    from padml import nested_loco
    class OriginalMaterializerBoundary(Exception):
        pass
    seen = []
    def materialize(*args, **kwargs):
        seen.append((args, kwargs))
        raise OriginalMaterializerBoundary
    monkeypatch.setattr(sensitivity, "materialize_a12_outer_inputs", materialize)
    source = tmp_path / "UNFITTED-gather.zip"
    source.write_bytes(b"UNFITTED")
    target = tmp_path / "existing-q"
    target.mkdir()
    ids = f5._a12_q_stop_phase("S1", refit=True, family="RSF")[1]
    sources = {"retained_primary_source_bundle": tmp_path / "primary.zip",
        "retained_selector_source_bundle": tmp_path / "coarse-producer.zip",
        "retained_selector_executor_source_bundle": tmp_path / "fine-executor.zip"}
    with pytest.raises(OriginalMaterializerBoundary):
        sensitivity.execute_a12_outer_bundle(source, target, input_bundle=tmp_path / "projected.zip",
            selector_root=tmp_path / "selector", search_only=True,
            search_branch=nested_loco.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT,
            task_ids=ids, batch_root=tmp_path / "batch", retained_bytes_per_task=64 * 1024**2,
            **sources)
    assert len(seen) == 1 and seen[0][1]["retained_primary_source_bundle"] == sources["retained_primary_source_bundle"]
    seen.clear()
    with pytest.raises(ContractError, match="F5_RETAINED_AAR_SOURCE_SCOPE_INVALID"):
        sensitivity.execute_a12_outer_bundle(source, target, input_bundle=tmp_path / "projected.zip",
            selector_only=True, phase_name="fine", task_ids=ids,
            batch_root=tmp_path / "selector-batch", retained_bytes_per_task=64 * 1024**2, **sources)
    assert not seen


class Outer4SelectorCliTests(unittest.TestCase):
    def _invoke(self, path, consumer):
        argv = ["padml-f5", "a12-outer", "/synthetic/gather.zip", "/synthetic/selector",
                "--input-bundle", "/synthetic/projected.zip", "--selector-only", "--phase", "coarse",
                "--phase-batches", "/synthetic/batch-0", "/synthetic/batch-1",
                "--retained-primary-source-bundle", "/synthetic/primary.zip",
                "--retained-selector-source-bundle", "/synthetic/selector-source.zip",
                "--selector-science-decision", str(path)]
        out = io.StringIO()
        with patch.object(sys, "argv", argv), \
             patch.object(sensitivity, "execute_a12_outer_bundle", consumer), redirect_stdout(out):
            f5.main()
        return json.loads(out.getvalue())

    def test_original_entry_receives_loaded_decision_and_unchanged_arguments(self):
        decision = {"synthetic_cli_only": True}
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "decision.json"
            path.write_bytes(canonical_json_bytes(decision))
            with patch.object(sensitivity, "execute_a12_outer_bundle", return_value={"cli_only": True}) as consumer:
                self.assertEqual(self._invoke(path, consumer), {"cli_only": True})
            consumer.assert_called_once_with(Path("/synthetic/gather.zip"), Path("/synthetic/selector"),
                input_bundle=Path("/synthetic/projected.zip"), retained_bytes_per_component=None,
                retained_primary_source_bundle=Path("/synthetic/primary.zip"),
                retained_selector_source_bundle=Path("/synthetic/selector-source.zip"),
                selector_science_decision=decision, selector_only=True, phase_name="coarse",
                phase_batches=[Path("/synthetic/batch-0"), Path("/synthetic/batch-1")])

    def test_noncanonical_json_stops_before_original_entry(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "decision.json"
            path.write_bytes(b'{"synthetic_cli_only": true}\n')
            with patch.object(sensitivity, "execute_a12_outer_bundle") as consumer:
                with self.assertRaisesRegex(ContractError, "F5_CLI_INPUT_NONCANONICAL"):
                    self._invoke(path, consumer)
            consumer.assert_not_called()

    def test_symlink_stops_before_original_entry(self):
        with tempfile.TemporaryDirectory() as tmp:
            target = Path(tmp) / "decision.json"
            target.write_bytes(canonical_json_bytes({"synthetic_cli_only": True}))
            link = Path(tmp) / "link.json"
            link.symlink_to(target)
            with patch.object(sensitivity, "execute_a12_outer_bundle") as consumer:
                with self.assertRaisesRegex(ContractError, "F5_CLI_INPUT_INVALID"):
                    self._invoke(link, consumer)
            consumer.assert_not_called()
