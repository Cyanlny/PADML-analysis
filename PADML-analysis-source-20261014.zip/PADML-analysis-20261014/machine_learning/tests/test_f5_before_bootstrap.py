"""Unfitted boundary fixtures: F5 compute admission is not project acceptance.

Pure review inputs below represent the existing reader boundary, not native
scientific evidence. No subprocess, pool, MICE, RNG or model fit may run.
"""
import copy

import pytest

from padml import f4, f5
from padml.bundle import (
    ContractError, canonical_json_bytes, sha256_bytes, sha256_file,
    write_deterministic_zip,
)
from test_f4 import o_fit_evidence_rows, post_selection_trigger_fixture
from test_f5 import final_refit_compilation_inputs
from test_learning_native import native_rows, unsupported


@pytest.fixture(autouse=True)
def no_science(monkeypatch):
    def forbidden(*args, **kwargs):
        raise AssertionError("ZERO_REAL_FIT_BOUNDARY_NO_NATIVE_PROCESS")
    monkeypatch.setattr(f4.subprocess, "run", forbidden)
    monkeypatch.setattr(f4.subprocess, "Popen", forbidden)
    monkeypatch.setattr(f4, "_bounded_ordered_spawn", forbidden)
    monkeypatch.setattr(f5, "_bounded_ordered_spawn", forbidden)


def recompute(case):
    suite = case["suite"]
    learning = case["embedded_learning"]
    if learning is not None:
        learning["reduction"] = f4._reduce_native_learning_curve(
            learning["rows"], locked_family="RSF")
    suite["full_pipeline_bootstrap"] = f4._full_pipeline_bootstrap_status(
        suite["evaluation"], suite["family_decision"], suite["matrix_loco"],
        suite["post_selection_bootstrap"], suite["registered_learning_curve_rows"],
        suite["o_fit_rows"], suite["full_pipeline_bootstrap_result"],
        learning_curve_execution=learning,
        full_pipeline_execution=case["embedded_full"],
    )


@pytest.fixture
def review_case(tmp_path):
    families = list(f4.FAMILY_COMPLEXITY)
    macro = {family: {"24": {
        "equal_center_ibs": .1 if family == "RSF" else .2,
        "pooled_absolute_slope_error": .1, "pooled_absolute_citl": .1,
        "equal_center_raw_dca": .1, "worst_center_ibs": .1, "pooled_uno_c": .7,
    }} for family in families}
    decision = f4.select_a15(macro, dict.fromkeys(families, True))
    digest = sha256_bytes(b"UNFITTED_READER_BOUNDARY")
    frozen = {name: digest for name in (
        "f2_acceptance_sha256", "f1_identity", "selection_capability_sha256",
        "execution_contract_seal_sha256")}
    frozen["patient_key_rule"] = f4.PATIENT_KEY_RULE
    ofit = {"identity_sha256": digest, "rows": o_fit_evidence_rows(ibs_delta=.006)}
    learning = {"kind": "PADML_F4_LEARNING_AGGREGATE_NATIVE_SHARDS_V2",
                "family": "RSF", "identity_sha256": digest, "rows": native_rows()}
    records = {name: {"sha256": digest, "size_bytes": 1}
               for name in ("o-fit-aggregate.zip", "learning-aggregate.zip")}
    post = post_selection_trigger_fixture()
    for row in post["replicates"]:
        row["selected_family"] = "RSF"
        row["optimism"]["uno_c_24_inbag_minus_oob"] = .01
    post["optimism"] = {field: f4._bootstrap_summary([
        row["optimism"][field] for row in post["replicates"]])
        for field in ("ibs_0_24_oob_minus_inbag", "uno_c_24_inbag_minus_oob")}
    metrics = dict(ibs_0_24=.1, brier_24=.2, uno_c_24=.7, auc_24=.7)
    fixed = {
        "kind": "PADML_F4_FIXED_MODEL_PAIRED_BOOTSTRAP_V1", "status": "COMPUTED",
        "conditional_on_fixed_fitted_models": True, "full_pipeline_uncertainty": False,
        "model_refit_count": 0, "selection_effect": "NONE",
        "primary_estimand": "EQUAL_CENTER_MACRO", "descriptive_estimand": "POOLED_PATIENT_MICRO",
        "plan": {"domain": "FIXED_MODEL_PAIRED", "root_seed": 700000001, "replicate_count": 1000},
        "replicates": [{"replicate": i, "metrics": {f: dict(metrics) for f in families},
                        "metric_support": {f: {name: {"status": "ESTIMABLE", "value": value}
                                               for name, value in metrics.items()} for f in families}}
                       for i in range(1, 1001)],
        "family_summary": {f: {name: f4._bootstrap_summary([value] * 1000)
                               for name, value in metrics.items()} for f in families},
    }
    suite = {
        "kind": "PADML_F4_COMPLETE_FIXED_PREDICTION_SUITE_V1", "status": "COMPUTED_AWAITING_REVIEW",
        "stage_acceptance": False, "stage_acceptance_reason": "REVIEW_AND_FINAL_WINNER_DEPLOYMENT_REQUIRED",
        "model_refit_count": 0, "selection_effect": "A15_ONLY", "replicate_count": 1000,
        "workers": 24, "execution_scope": "FORMAL",
        "candidate_protocol_amendment": f4.f45_candidate_protocol_amendment_20260905(),
        "prospective_protocol_revision": f4.PROSPECTIVE_PROTOCOL_REVISION,
        "selection_capability_seals": [{"schema_version": "1.0.0",
            "kind": "PADML_F4_SELECTION_CAPABILITY_SEAL_V1", "family": family,
            "status": "PASS", "evidence_sha256": digest} for family in families],
        "evaluation": {"macro": macro}, "family_decision": decision,
        "matrix_loco": {"kind": "PADML_F4_A15_FIXED_OOC_MATRIX_LOCO_DIAGNOSTIC_V1",
            "evidence_label": "A15_FIXED_OOC_MATRIX_LOCO_DIAGNOSTIC",
            "independent_training_only_evidence": False, "model_refit_count": 0,
            "replicate_locks": [{"selected_family": "RSF"} for _ in range(6)],
            "global_family": "RSF", "stability": {"matching_replicates": 6, "total_replicates": 6,
                "threshold": 4, "status": "PASS", "review_required": False}},
        "fixed_model_paired_bootstrap": fixed, "post_selection_bootstrap": post,
        "registered_learning_curve_rows": learning["rows"], "o_fit_rows": ofit["rows"],
        "full_pipeline_bootstrap_result": None, "shadow_dca": {"status": "ALIGNED"},
        "source": {**frozen,
            "o_fit_aggregate": {"member": "o-fit-aggregate.zip", "identity_sha256": digest,
                                **records["o-fit-aggregate.zip"]},
            "learning_curve_aggregate": {"member": "learning-aggregate.zip", "identity_sha256": digest,
                                         **records["learning-aggregate.zip"]},
            "full_pipeline_aggregate": None},
    }
    case = {"suite": suite, "inputs": {"source": frozen}, "extracted_records": records,
            "embedded_o_fit": ofit, "embedded_learning": learning, "embedded_full": None,
            "root": tmp_path, "calls": 0}
    recompute(case)
    return case


def seal(case, **review_changes):
    suite = case["suite"]
    raw = canonical_json_bytes(suite)
    source = case["root"] / f"UNFITTED-f4-{case['calls']}.zip"
    case["calls"] += 1
    write_deterministic_zip(source, {"f4-suite.json": raw})
    decision = suite["family_decision"]
    lock = f4.resolve_f4_final_family_lock(decision, suite["matrix_loco"])
    review = {"schema_version": "2.0.0", "kind": "PADML_F4_LOCKED_FAMILY_REVIEW_V2",
              "status": "APPROVED", "f4_result_sha256": sha256_file(source),
              "family_decision_sha256": sha256_bytes(canonical_json_bytes(decision)),
              "locked_family": "RSF", "final_family_lock_sha256": lock["identity_sha256"],
              "matrix_loco_stability_review": "NOT_REQUIRED", "shadow_dca_review": "NOT_REQUIRED",
              "full_pipeline_bootstrap_status": suite["full_pipeline_bootstrap"]["status"],
              **review_changes}
    return f4._seal_f4_reviewed_result(source, review, raw, suite,
        **{name: case[name] for name in ("inputs", "extracted_records", "embedded_o_fit",
                                       "embedded_learning", "embedded_full")})


@pytest.mark.parametrize("support_required", [False, True])
def test_resolved_unstarted_b_admits_f5_but_not_project_acceptance(review_case, support_required):
    if support_required:
        unsupported(review_case["embedded_learning"]["rows"][0])
        recompute(review_case)
    status = review_case["suite"]["full_pipeline_bootstrap"]
    assert status["status"] == "REQUIRED" and status["unevaluated_triggers"] == []
    assert status["review_ready"] is False and status["execution_started"] is False
    handoff = seal(review_case)
    assert f5._locked_f5_family(review_case["suite"]["family_decision"], handoff)[2] == "RSF"
    assert status["review_ready"] is False and review_case["suite"]["stage_acceptance"] is False


@pytest.mark.parametrize("missing", ["o_fit", "learning"])
def test_missing_prerequisite_remains_blocked(review_case, missing):
    suite = review_case["suite"]
    review_case[f"embedded_{missing}"] = None
    suite["source"]["o_fit_aggregate" if missing == "o_fit" else "learning_curve_aggregate"] = None
    suite["o_fit_rows" if missing == "o_fit" else "registered_learning_curve_rows"] = None
    recompute(review_case)
    assert suite["full_pipeline_bootstrap"]["status"] == "BLOCKED"
    with pytest.raises(ContractError, match="F4_REVIEW_ACCEPTANCE_INVALID"):
        seal(review_case)


@pytest.mark.parametrize("drift,error", [
    ("source", "FROZEN_SOURCE_MISMATCH"), ("patient", "O_FIT_BINDING_INVALID"),
    ("numeric", "BOOTSTRAP_SUPPORT_INVALID"), ("family", "ACCEPTANCE_INVALID"),
    ("false_b_complete", "ACCEPTANCE_INVALID"),
])
def test_actual_review_rejects_drift_and_false_completion(review_case, drift, error):
    changes = {}
    if drift == "source":
        review_case["inputs"]["source"]["f1_identity"] = "0" * 64
    elif drift == "patient":
        review_case["suite"]["o_fit_rows"] = copy.deepcopy(review_case["suite"]["o_fit_rows"])
        review_case["suite"]["o_fit_rows"][0]["patient_set_sha256"] = "0" * 64
    elif drift == "numeric":
        review_case["suite"]["fixed_model_paired_bootstrap"]["replicates"][0]["metrics"]["RSF"]["ibs_0_24"] = .123
    elif drift == "family":
        changes["locked_family"] = "XGBOOST_COX"
    else:
        changes["full_pipeline_bootstrap_status"] = "COMPLETED"
    with pytest.raises(ContractError, match=error):
        seal(review_case, **changes)


def bootstrap_rows(count, varied=False):
    rows = []
    for i in range(1, count + 1):
        left, right = .1, (.3 if i % 2 else .1) if varied else .11
        sides = {side: {"status": "ESTIMABLE", "value": value, "support": []}
                 for side, value in (("bootstrap", left), ("original", right))}
        rows.append({"replicate": i, "family": "RSF", "evidence_label": f4.FULL_PIPELINE_EVIDENCE_LABEL,
                     "scientific_counts": {"final_model_fits": 20}, "evaluation": {"optimism": {
                         name: {"status": "ESTIMABLE", "value": sign * (right - left), **sides}
                         for name, sign in (("optimism_ibs", 1), ("optimism_uno_c", -1))}}})
    return rows


def test_original_b100_mcse_and_b200_denominator_are_unchanged():
    completed = f4._reduce_full_pipeline_native_rows(bootstrap_rows(100), locked_family="RSF")
    assert completed["status"] == "COMPUTED" and completed["required_replicates"] == 100
    pending = f4._reduce_full_pipeline_native_rows(bootstrap_rows(100, True), locked_family="RSF")
    assert pending["status"] == "ADDITIONAL_REPLICATES_REQUIRED"
    assert pending["required_replicates"] == 200 and pending["observed_replicates"] == 100
    assert pending["mcse_thresholds"] == {"optimism_ibs": .001, "optimism_uno_c": .01}
    assert f4._reduce_full_pipeline_native_rows(bootstrap_rows(200, True), locked_family="RSF")["status"] == "COMPUTED"
    with pytest.raises(ContractError, match="B200_NOT_TRIGGERED"):
        f4._reduce_full_pipeline_native_rows(bootstrap_rows(200), locked_family="RSF")


def test_later_b_keeps_frozen_f5_input_and_rejects_mixed_new_handoff(review_case):
    original = seal(review_case)
    original_bytes = canonical_json_bytes(original)
    inputs = list(final_refit_compilation_inputs("RSF"))
    assert inputs[2] == review_case["suite"]["family_decision"]
    inputs[3]["f4_locked_family_handoff_sha256"] = original["identity_sha256"]
    inputs[3]["identity_sha256"] = sha256_bytes(canonical_json_bytes({
        k: v for k, v in inputs[3].items() if k != "identity_sha256"}))
    plan = f5.compile_final_refit_tasks(*inputs, original, workers=24)
    rows = bootstrap_rows(100)
    completion = f4._reduce_full_pipeline_native_rows(rows, locked_family="RSF")
    full = {"kind": "PADML_F4_FULL_PIPELINE_AGGREGATE_NATIVE_SHARDS_V2", "family": "RSF",
            "rows": rows, "completion": completion, "identity_sha256": "b" * 64}
    review_case["embedded_full"] = full
    suite = review_case["suite"]
    suite["full_pipeline_bootstrap_result"] = completion
    record = {"sha256": "c" * 64, "size_bytes": 1}
    review_case["extracted_records"]["full-pipeline-aggregate.zip"] = record
    suite["source"]["full_pipeline_aggregate"] = {
        "member": "full-pipeline-aggregate.zip", "identity_sha256": full["identity_sha256"], **record}
    recompute(review_case)
    assert suite["full_pipeline_bootstrap"]["status"] == "COMPLETED"
    assert suite["full_pipeline_bootstrap"]["review_ready"] is True
    newer = seal(review_case)
    assert newer["identity_sha256"] != original["identity_sha256"]
    assert canonical_json_bytes(original) == original_bytes
    assert f5.compile_final_refit_tasks(*inputs, original, workers=24) == plan
    with pytest.raises(ContractError, match="F5_FINAL_PARAMETER_LOCK_INVALID"):
        f5.compile_final_refit_tasks(*inputs, newer, workers=24)


def test_original_archive_reader_failure_is_not_deferred(tmp_path, monkeypatch):
    source = tmp_path / "UNFITTED-reader-failure.zip"
    write_deterministic_zip(source, {"f4-suite.json": b"{}", "o-fit-aggregate.zip": b"UNFITTED"})
    monkeypatch.setattr(f4, "load_f4_inputs", lambda *a, **k: {"o_fit_source": {}})
    def failed(*args, **kwargs):
        raise ContractError("UNFITTED_ORIGINAL_READER_FAILED")
    monkeypatch.setattr(f4, "load_o_fit_aggregate_archive", failed)
    with pytest.raises(ContractError, match="UNFITTED_ORIGINAL_READER_FAILED"):
        f4.seal_f4_locked_family_handoff(source, {}, f2_run_root=tmp_path)
