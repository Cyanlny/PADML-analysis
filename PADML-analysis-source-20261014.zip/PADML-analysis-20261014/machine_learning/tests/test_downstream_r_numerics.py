"""Native R fits and compiled Cox derivatives, independent of search machinery."""
from __future__ import annotations

import json
import os
from pathlib import Path
import shutil
import subprocess

import numpy as np
import pytest

from padml.bundle import ContractError, canonical_json_bytes, sha256_bytes
from padml.f2_kernel import _validate_r_tree_fit_health
from padml.f2_validation import _validate_fpm_fit_evidence, _validate_nonelastic_fit_health
from test_cox_numerical_roots import finite_derivatives, grouped_loss
from test_selector_sensitivity_numeric import R_FUNCTIONS, R_KERNEL


ROOT = Path(__file__).resolve().parents[1]


def run_r(code, *, extra_env=None):
    rscript = shutil.which("Rscript")
    if rscript is None:
        pytest.skip("Rscript is required for native numerical regression tests")
    result = subprocess.run(
        [rscript, "-e", R_FUNCTIONS + code, str(R_KERNEL)], capture_output=True,
        text=True, timeout=120, env={**os.environ, "OMP_NUM_THREADS": "1",
                                    "OPENBLAS_NUM_THREADS": "1", **(extra_env or {})})
    assert result.returncode == 0, result.stdout + result.stderr
    return json.loads(result.stdout.splitlines()[-1])


@pytest.fixture(scope="module")
def gbm_probe_environment(tmp_path_factory):
    source = os.environ.get("PADML_TEST_GBM_SOURCE")
    if not source:
        pytest.skip("Set PADML_TEST_GBM_SOURCE to the exact patched gbm source tree")
    assert (Path(source)/"src/coxph.h").is_file()
    return {"PADML_TEST_GBM_PROBE": str(ROOT/"tests/native/gbm_cox_probe.cpp"),
            "PADML_TEST_GBM_CACHE": str(tmp_path_factory.mktemp("gbm-native-proof"))}


GBM_PROBE = r'''
suppressPackageStartupMessages({library(gbm); library(Rcpp)})
stopifnot(as.character(packageVersion("gbm")) == "2.3.1.9001",
          packageDescription("gbm")[["PADML-Correction"]] == "cox-breslow-ties-v1")
Sys.setenv(PKG_CPPFLAGS=paste0("-I", Sys.getenv("PADML_TEST_GBM_SOURCE"), "/src"),
           PKG_LIBS=getLoadedDLLs()[["gbm"]][["path"]])
sourceCpp(Sys.getenv("PADML_TEST_GBM_PROBE"), cacheDir=Sys.getenv("PADML_TEST_GBM_CACHE"),
          rebuild=FALSE, showOutput=FALSE)
'''


@pytest.mark.parametrize("tied,weighted", [(True, False), (True, True), (False, False)])
def test_actual_gbm_response_leaf_hessian_deviance_and_oob_match_loss(
    gbm_probe_environment, tied, weighted,
):
    n = 18
    time = np.repeat(np.arange(1, 7), 3) if tied else np.arange(1, n+1)
    event = (np.arange(n) % 4 != 0).astype(int)
    margin = np.random.default_rng(4719).normal(scale=.5, size=n)
    weights = np.resize([.5, 1, 2], n) if weighted else np.ones(n)
    bag = np.arange(n) % 5 != 0
    nodes = np.arange(n) % 3
    adjustment = np.random.default_rng(9382).normal(scale=.2, size=n)
    order = np.argsort(-time, kind="stable")
    fixture = {"times": time[order].tolist(), "events": event[order].tolist(),
               "eta": margin[order].tolist(), "weights": weights[order].tolist(),
               "bag": bag[order].tolist(), "nodes": nodes[order].tolist(),
               "adjustment": adjustment[order].tolist(), "step": .1}
    observed = run_r(GBM_PROBE + r'''
fixture <- fromJSON(Sys.getenv("PADML_TEST_FIXTURE"))
answer <- do.call(gbm_cox_probe, fixture)
cat(toJSON(answer, auto_unbox=TRUE, digits=NA, null="null"), "\n")
''', extra_env={**gbm_probe_environment, "PADML_TEST_FIXTURE": json.dumps(fixture)})
    g, _ = finite_derivatives(lambda z: grouped_loss(time[bag], event[bag], z, weights[bag]),
                              margin[bag])
    inverse_order = np.argsort(order)
    np.testing.assert_allclose(np.asarray(observed["response"])[inverse_order][bag],
                               -g/weights[bag], atol=3e-8, rtol=2e-7)
    assert observed["deviance"] == pytest.approx(
        2*grouped_loss(time, event, margin, weights)/weights[event == 1].sum(), rel=2e-14)
    expected_oob = (grouped_loss(time[~bag], event[~bag], margin[~bag], weights[~bag])
                    - grouped_loss(time[~bag], event[~bag],
                                   (margin + .1*adjustment)[~bag], weights[~bag]))
    expected_oob /= weights[(~bag) & (event == 1)].sum()
    assert observed["oob_improvement"] == pytest.approx(expected_oob, abs=3e-15)
    def leaf_loss(value):
        return grouped_loss(time[bag], event[bag],
                            margin[bag] + np.r_[value, 0.0][nodes[bag]], weights[bag])
    leaf_g, leaf_h = finite_derivatives(leaf_loss, np.zeros(2))
    np.testing.assert_allclose(observed["leaf_gradient"], -leaf_g, atol=3e-8, rtol=2e-7)
    np.testing.assert_allclose(np.linalg.inv(observed["leaf_hessian_inverse"]),
                               -leaf_h, atol=2e-6, rtol=2e-6)
    np.testing.assert_allclose(observed["leaf_update"], np.r_[-np.linalg.solve(leaf_h, leaf_g), 0],
                               atol=2e-6, rtol=2e-6)


def test_actual_gbm_all_tied_equal_risk_and_full_tree_row_reversal(gbm_probe_environment):
    answer = run_r(GBM_PROBE + r'''
n <- 160L
observed <- gbm_cox_probe(rep(1, n), rep(1, n), rep(0, n), rep(1, n),
                          rep(TRUE, n), rep(0:1, each=n/2), rep(0, n), .1)
stopifnot(max(abs(observed$response)) < 1e-13,
          max(abs(observed$leaf_gradient)) < 1e-13,
          max(abs(observed$leaf_update)) < 1e-13,
          abs(observed$deviance - 2 * log(n)) < 1e-13)
x <- matrix(seq_len(n), ncol=1L, dimnames=list(NULL, "X"))
prediction <- lapply(list(seq_len(n), rev(seq_len(n))), function(indices) {
  set.seed(300101L, kind="L'Ecuyer-CMRG")
  fit <- gbm.fit(x=x[indices,,drop=FALSE], y=Surv(rep(1, n), rep(1, n)),
                 distribution="coxph", n.trees=20L, interaction.depth=2L,
                 n.minobsinnode=5L, shrinkage=.05, bag.fraction=1,
                 keep.data=FALSE, verbose=FALSE)
  as.numeric(predict(fit, x, n.trees=20L, type="link"))
})
stopifnot(max(abs(prediction[[1L]])) < 1e-13,
          identical(prediction[[1L]], prediction[[2L]]))
cat(toJSON(list(zero_gradient=TRUE, zero_false_risk=TRUE, row_reversal=TRUE), auto_unbox=TRUE), "\n")
''', extra_env=gbm_probe_environment)
    assert all(answer.values())


def test_actual_gbm_fixed_bag_tie_permutation_is_invariant(gbm_probe_environment):
    answer = run_r(GBM_PROBE + r'''
n <- 60L; set.seed(73219L)
tt <- rep(10:1, each=6); ee <- rep(c(1,1,0,1,0,1), 10)
eta <- rnorm(n, sd=.3); ww <- rep(c(.5,1,2), 20)
bag <- rep(c(TRUE,TRUE,FALSE,TRUE,TRUE,FALSE), 10)
nodes <- rep(c(0L,1L,0L,2L,2L,1L), 10); adj <- rnorm(n, sd=.2)
one <- gbm_cox_probe(tt, ee, eta, ww, bag, nodes, adj, .1)
p <- unlist(lapply(split(seq_len(n), ceiling(seq_len(n)/6)), rev), use.names=FALSE)
two <- gbm_cox_probe(tt[p], ee[p], eta[p], ww[p], bag[p], nodes[p], adj[p], .1)
stopifnot(max(abs(one$response[p]-two$response)) < 1e-13)
for (field in setdiff(names(one), "response"))
  stopifnot(max(abs(unlist(one[[field]]) - unlist(two[[field]]))) < 1e-12)
cat(toJSON(list(all_four_native_functions=TRUE), auto_unbox=TRUE), "\n")
''', extra_env=gbm_probe_environment)
    assert answer["all_four_native_functions"] is True


def test_actual_gbm_untied_full_fit_matches_original_release():
    original = os.environ.get("PADML_TEST_GBM_ORIGINAL_LIBRARY")
    if not original:
        pytest.skip("Set PADML_TEST_GBM_ORIGINAL_LIBRARY to original gbm 2.3.1")
    code = r'''
suppressPackageStartupMessages(library(gbm))
set.seed(2145L); n <- 240L; x <- matrix(rnorm(n*4), n, 4)
colnames(x) <- paste0("X", 1:4); tt <- sample(seq_len(n)); ee <- rbinom(n, 1, .7)
set.seed(300101L, kind="L'Ecuyer-CMRG")
fit <- gbm.fit(x=x, y=Surv(tt,ee), distribution="coxph", n.trees=40L,
               interaction.depth=2L, n.minobsinnode=5L, shrinkage=.05,
               bag.fraction=.7, keep.data=FALSE, verbose=FALSE)
cat(toJSON(list(version=as.character(packageVersion("gbm")), margin=fit$fit,
                deviance=fit$train.error, oob=fit$oobag.improve), digits=NA), "\n")
'''
    before = run_r(code, extra_env={"PADML_TEST_R_LIBRARY": original})
    after = run_r(code)
    assert before.pop("version") == ["2.3.1"]
    assert after.pop("version") == ["2.3.1.9001"]
    assert before == after


def test_actual_gbm_project_stop_curve_and_locked_refit_use_corrected_engine(tmp_path):
    result = run_r(r'''
time_col <- ".time"; event_col <- ".event"
spec <- list(predictors=list(conflict_map=list(
  ANTHROPOMETRY=list(main_parent="BMI",excluded_sources=list("Height","Weight")),
  EXPOSURE_RATIO=list(main_parent="AST_ALT",excluded_sources=list("AST","ALT")),
  RENAL_FUNCTION=list(main_parent="eGFR",excluded_sources=list("Creatinine")))))
variable_rows <- list(list(name="Age",type="continuous"),list(name="AST_ALT",type="continuous"))
set.seed(931L); n <- 240L
frame <- data.frame(.time=sample(1:60,n,replace=TRUE),.event=rbinom(n,1,.7),
                     Age=runif(n,40,80),AST_ALT=runif(n,.5,2))
parameters <- list(max_trees=40L, interaction_depth=2L, min_observations_in_node=5L,
                    shrinkage=.05,bag_fraction=.7)
output_path <- file.path(Sys.getenv("PADML_TEST_OUTPUT"),"operation.json")
curve <- gbm_stop_curve(frame[1:200,],frame[201:240,],c("Age","AST_ALT"),
                         parameters,300101L,NULL,"curve")
parameters$locked_trees <- 20L
fit <- fit_predict("GBM_COX",frame[1:200,],frame[201:240,],c("Age","AST_ALT"),
                     parameters,300101L,c(6,12,24,36),NULL)
stopifnot(all(is.finite(fit$survival)),all(fit$survival >= 0 & fit$survival <= 1),
          identical(curve$fit_health$cox_objective,fit$stopping$cox_objective))
cat(canonical_json(list(curve=c(list(engine="gbm::gbm",stopping_reselected=TRUE),curve$fit_health),
                         refit=fit$stopping,design=curve$ordered_parent_column_map)), "\n")
''', extra_env={"PADML_TEST_OUTPUT": str(tmp_path)})
    for phase, stop_curve in (("curve", True), ("refit", False)):
        health = result[phase]
        _validate_r_tree_fit_health(
            "GBM_COX", health, parameters={"max_trees": 40, "locked_trees": 20},
            ordered_parent_column_map=result["design"], fit_row_count=200, stop_curve=stop_curve)
        old = {**health, "cox_objective": {"implementation": "NATIVE_UNGROUPED"}}
        with pytest.raises(ContractError, match="COX_OBJECTIVE_HEALTH_INVALID"):
            _validate_r_tree_fit_health("GBM_COX", old, parameters={"max_trees": 40, "locked_trees": 20},
                ordered_parent_column_map=result["design"], fit_row_count=200, stop_curve=stop_curve)


def test_rsf_xy_interface_is_formula_equivalent_and_accepts_design_names():
    answer = run_r(r'''
suppressPackageStartupMessages(library(ranger))
set.seed(9317L); n <- 160L
x <- matrix(rnorm(n * 3L), nrow=n,
            dimnames=list(NULL, c("X1", "X2", "X3")))
time <- rexp(n, rate=exp(.25 * x[, 1L] - .15 * x[, 2L]))
event <- rbinom(n, 1L, .75)
test <- matrix(rnorm(45L), nrow=15L, dimnames=list(NULL, colnames(x)))
arguments <- list(
  num.trees=80L, mtry=2L, min.node.size=5L, sample.fraction=.632,
  splitrule="logrank", seed=44031L, num.threads=1L, write.forest=TRUE
)
frame <- data.frame(.time=time, .event=event, x, check.names=FALSE)
formula_fit <- do.call(ranger, c(list(
  formula=Surv(.time, .event) ~ ., data=frame
), arguments))
xy_fit <- do.call(ranger, c(list(x=x, y=Surv(time, event)), arguments))
formula_prediction <- predict(
  formula_fit, data=as.data.frame(test), num.threads=1L
)$survival
xy_prediction <- predict(xy_fit, data=test, num.threads=1L)$survival
stopifnot(
  identical(formula_fit$unique.death.times, xy_fit$unique.death.times),
  identical(formula_prediction, xy_prediction),
  identical(xy_fit$forest$independent.variable.names, colnames(x))
)
illegal <- x
colnames(illegal) <- c("AST/ALT", "Rutherford Grade 0-2", "X-3")
illegal_fit <- do.call(ranger, c(list(
  x=illegal, y=Surv(time, event)
), arguments))
illegal_prediction <- predict(
  illegal_fit, data=illegal[1:5, , drop=FALSE], num.threads=1L
)$survival
time_col <- ".time"; event_col <- ".event"
selected <- c("AST_ALT", "Rutherford_cat", "X")
mapping <- function(value) list(
  x=value,
  parent_map=data.frame(
    parent=selected, column=colnames(value), stringsAsFactors=FALSE
  )
)
project_fit <- fit_predict(
  "RSF", data.frame(.time=time, .event=event), data.frame(row=seq_len(5L)),
  selected,
  list(
    max_depth="3", mtry_fraction="0.50", num_trees=80L,
    min_node_size=5L, sample_fraction=.632, splitrule="logrank"
  ),
  44031L, c(6, 12, 24, 36), NULL,
  prepared_design=list(
    train_mapping=mapping(illegal),
    test_mapping=mapping(illegal[1:5, , drop=FALSE])
  )
)
stopifnot(
  identical(illegal_fit$forest$independent.variable.names, colnames(illegal)),
  nrow(illegal_prediction) == 5L,
  all(is.finite(illegal_prediction)),
  identical(project_fit$stopping$engine, "ranger::ranger"),
  identical(project_fit$ordered_parent_column_map, list(
    list(parent="AST_ALT", columns=list("AST/ALT")),
    list(parent="Rutherford_cat", columns=list("Rutherford Grade 0-2")),
    list(parent="X", columns=list("X-3"))
  )),
  all(is.finite(project_fit$survival))
)
cat(toJSON(list(
  formula_equivalent=TRUE, project_path=TRUE, design_names_preserved=TRUE,
  finite_prediction=TRUE
), auto_unbox=TRUE), "\n")
''')
    assert all(answer.values())


def test_gbm_original_release_is_rejected_before_native_fitting():
    original = os.environ.get("PADML_TEST_GBM_ORIGINAL_LIBRARY")
    if not original:
        pytest.skip("Set PADML_TEST_GBM_ORIGINAL_LIBRARY to original gbm 2.3.1")
    result = run_r(r'''
reason <- tryCatch({gbm_cox_objective_identity();"unexpected_success"},error=function(e) conditionMessage(e))
cat(toJSON(list(reason=reason),auto_unbox=TRUE),"\n")
''', extra_env={"PADML_TEST_R_LIBRARY": original})
    assert result["reason"] == "F2_GBM_COX_CORRECTION_MISSING"


FPM_FIT = r'''
suppressPackageStartupMessages(library(rstpm2))
set.seed(71239L); n <- 400L
frame <- data.frame(.time=rexp(n)+.01, .event=rbinom(n,1,.75), X=rnorm(n), AST_ALT=runif(n,.2,3))
fit <- stpm2(Surv(.time,.event)~X+AST_ALT, data=frame, df=3L,
             tvc=list(AST_ALT=1L), padml.fpm.domain=c(0,15))
'''


@pytest.mark.parametrize("fixture", ["translated","near_ties","separated_times","all_tied"])
def test_native_cox_ph_prediction_matches_survfit_without_overflow_or_time_drift(fixture):
    answer=run_r(f'fixture <- "{fixture}"\n'+r'''
set.seed(71109L); n<-160L
xx<-rnorm(n); zz<-rnorm(n)
frame<-data.frame(.time=rexp(n,exp(1.5*xx-.2*zz))*10+.1,
                  .event=rbinom(n,1,.8),X=xx,Z=zz)
time_col<-".time"; event_col<-".event"
if (fixture %in% c("near_ties","separated_times","all_tied")) {
  delta<-if(fixture=="near_ties") 1e-10 else if(fixture=="separated_times") 1e-4 else 0
  frame$.time<-1+seq.int(0L,n-1L)*delta;frame$.event<-1L
  horizons<-sort(unique(c(1,1+79*delta,1+159*delta,2)))
} else horizons<-c(1,6,12,24,36)
mapping<-function(data) list(x=as.matrix(data[,c("X","Z")]),
             parent_map=data.frame(parent=c("X","Z"),column=c("X","Z")))
native<-function(data) {
  expected_fit<-coxph(
    Surv(.time,.event)~X+Z,data=data,ties="breslow",x=TRUE,y=TRUE,
    singular.ok=FALSE,control=coxph.control(eps=1e-11,iter.max=100L)
  )
  expected_curve<-survfit(expected_fit,newdata=data[1:12,],se.fit=FALSE,conf.type="none")
  positions<-findInterval(horizons,expected_curve$time)
  expected<-matrix(1,12,length(horizons));active<-which(positions>0L)
  expected[,active]<-t(as.matrix(expected_curve$surv)[positions[active],,drop=FALSE])
  prepared<-list(train_mapping=mapping(data),test_mapping=mapping(data[1:12,]))
  actual<-fit_predict("COX_PH",data,data[1:12,],c("X","Z"),list(),300101L,horizons,NULL,prepared_design=prepared)
  stopifnot(all(is.finite(actual$survival)),max(abs(actual$survival-expected))<1e-14,
            actual$stopping$ties=="breslow",actual$stopping$warning_count==0L)
  list(prediction=actual$survival,coefficient=expected_fit$coefficients)
}
original<-native(frame)
if (fixture=="translated") {
  frame$X<-frame$X+1000
  shifted<-native(frame)
  stopifnot(any(!is.finite(exp(as.matrix(frame[,c("X","Z")]) %*% shifted$coefficient))),
            max(abs(shifted$prediction-original$prediction))<1e-10,
            max(abs(shifted$coefficient-original$coefficient))<1e-10)
}
if (fixture=="all_tied") stopifnot(max(abs(original$prediction-exp(-1)))<1e-14)
cat(toJSON(list(finite=TRUE,native_survfit_match=TRUE,breslow_preserved=TRUE),auto_unbox=TRUE),"\n")
''')
    assert all(answer.values())


def test_native_cox_ph_preserves_nonsyntactic_design_columns_by_value():
    answer = run_r(r'''
set.seed(71903L); n <- 220L
time_col <- ".time"; event_col <- ".event"
frame <- data.frame(
  .time = rexp(n, exp(rnorm(n, sd=.2))) * 8 + .1,
  .event = rbinom(n, 1, .75),
  AST_ALT = runif(n, .2, 3),
  check.names = FALSE
)
frame[["Rutherford_catGrade 3-4"]] <- rbinom(n, 1, .45)
frame[["Rutherford_catGrade 5-6"]] <- rbinom(n, 1, .25)
design_columns <- c(
  "AST_ALT", "Rutherford_catGrade 3-4", "Rutherford_catGrade 5-6"
)
mapping <- function(data) list(
  x = as.matrix(data[, design_columns, drop=FALSE]),
  parent_map = data.frame(
    parent = c("AST_ALT", "Rutherford_cat", "Rutherford_cat"),
    column = design_columns,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
)
train_mapping <- mapping(frame)
test_mapping <- mapping(frame[1:18, , drop=FALSE])
safe_train <- train_mapping$x
safe_test <- test_mapping$x
safe_names <- sprintf(".padml_x_%04d", seq_len(ncol(safe_train)))
colnames(safe_train) <- safe_names
colnames(safe_test) <- safe_names
reference_frame <- data.frame(
  .time=frame$.time, .event=frame$.event, safe_train, check.names=FALSE
)
reference_fit <- coxph(
  Surv(.time,.event) ~ ., data=reference_frame, ties="breslow",
  x=TRUE, y=TRUE, singular.ok=FALSE,
  control=coxph.control(eps=1e-11,iter.max=100L)
)
horizons <- c(1, 6, 12, 24, 36)
reference_curve <- survfit(
  reference_fit, newdata=as.data.frame(safe_test),
  se.fit=FALSE, conf.type="none"
)
positions <- findInterval(horizons, reference_curve$time)
expected <- matrix(1, nrow(safe_test), length(horizons))
active <- which(positions > 0L)
expected[, active] <- t(
  as.matrix(reference_curve$surv)[positions[active], , drop=FALSE]
)
actual <- fit_predict(
  "COX_PH", frame, frame[1:18, , drop=FALSE],
  c("AST_ALT", "Rutherford_cat"), list(), 300101L, horizons, NULL,
  prepared_design=list(
    train_mapping=train_mapping, test_mapping=test_mapping
  )
)
stopifnot(
  all(is.finite(actual$survival)),
  max(abs(actual$survival - expected)) < 1e-14,
  identical(
    unlist(lapply(actual$ordered_parent_column_map, `[[`, "columns"), use.names=FALSE),
    design_columns
  ),
  actual$stopping$coefficient_count == length(design_columns),
  actual$stopping$warning_count == 0L
)
cat(toJSON(list(
  finite=TRUE, native_survfit_match=TRUE,
  original_design_labels_preserved=TRUE
), auto_unbox=TRUE), "\n")
''')
    assert all(answer.values())


def test_native_cox_ph_strict_convergence_resolves_finite_boundary_warning():
    answer = run_r(r'''
set.seed(911L); n <- 360L
x1 <- rnorm(n); x2 <- x1 + rnorm(n, sd=.01)
x3 <- rnorm(n); x4 <- rnorm(n)
frame <- data.frame(
  .time=rexp(n, exp(.6*x1-.3*x3))+.01,
  .event=rbinom(n,1,.72), X1=x1, X2=x2, X3=x3, X4=x4
)
time_col <- ".time"; event_col <- ".event"
mapping <- function(data) list(
  x=as.matrix(data[,c("X1","X2","X3","X4")]),
  parent_map=data.frame(
    parent=c("X1","X2","X3","X4"),
    column=c("X1","X2","X3","X4")
  )
)
default_warnings <- character()
default_fit <- withCallingHandlers(
  coxph(
    Surv(.time,.event)~., data=frame, ties="breslow",
    x=TRUE, y=TRUE, singular.ok=FALSE
  ),
  warning=function(condition) {
    default_warnings <<- c(default_warnings, conditionMessage(condition))
    invokeRestart("muffleWarning")
  }
)
horizons <- c(1,6,12,24,36)
actual <- fit_predict(
  "COX_PH", frame, frame[1:24,,drop=FALSE],
  c("X1","X2","X3","X4"), list(), 300101L, horizons, NULL,
  prepared_design=list(
    train_mapping=mapping(frame),
    test_mapping=mapping(frame[1:24,,drop=FALSE])
  )
)
safe <- mapping(frame)$x
safe_test <- mapping(frame[1:24,,drop=FALSE])$x
safe_names <- sprintf(".padml_x_%04d", seq_len(ncol(safe)))
colnames(safe) <- safe_names; colnames(safe_test) <- safe_names
reference <- coxph(
  Surv(.time,.event)~.,
  data=data.frame(.time=frame$.time,.event=frame$.event,safe,check.names=FALSE),
  ties="breslow", x=TRUE, y=TRUE, singular.ok=FALSE,
  control=coxph.control(eps=1e-11,iter.max=100L)
)
curve <- survfit(
  reference, newdata=as.data.frame(safe_test),
  se.fit=FALSE, conf.type="none"
)
positions <- findInterval(horizons,curve$time)
expected <- matrix(1,nrow(safe_test),length(horizons))
observed <- which(positions>0L)
expected[,observed] <- t(as.matrix(curve$surv)[positions[observed],,drop=FALSE])
stopifnot(
  length(default_warnings)==1L,
  grepl("coefficient may be infinite",default_warnings[[1L]],fixed=TRUE),
  default_fit$iter==3L, reference$iter==4L,
  actual$stopping$iteration_count==4L,
  actual$stopping$warning_count==0L,
  qr(reference$var)$rank==4L,
  all(is.finite(reference$coefficients)),
  max(abs(actual$survival-expected))<1e-14
)
cat(toJSON(list(
  default_warning_reproduced=TRUE,
  strict_warning_free=TRUE,
  covariance_full_rank=TRUE,
  native_prediction_match=TRUE
),auto_unbox=TRUE),"\n")
''')
    assert all(answer.values())


@pytest.fixture(scope="module")
def fpm_native_health():
    return run_r(FPM_FIT + r'''
before <- serialize(fit, NULL)
health <- validate_fpm_fit_health(fit, 0L, c(3L,1L))
stopifnot(identical(serialize(fit, NULL), before))
final_consumer <- new.env(parent=globalenv())
for (expression in parse(file.path(dirname(commandArgs(trailingOnly=TRUE)[[1L]]),
                                  "f5_final_refit.R"))) {
  if (is.call(expression) && identical(expression[[1L]], as.name("<-")) &&
      length(expression) == 3L && is.call(expression[[3L]]) &&
      identical(expression[[3L]][[1L]], as.name("function"))) eval(expression, final_consumer)
}
stopifnot(identical(final_consumer$validate_fpm_fit_health(fit, 0L, c(3L,1L)), health))
bases <- Filter(function(value) inherits(value,"nsx"), fit@lm$model)
for (index in 1:2) {
  evidence <- health$fit_evidence$spline_bases[[index]]
  stopifnot(identical(unlist(evidence$knots), if (length(attr(bases[[index]],"knots")))
                      unname(attr(bases[[index]],"knots")) else NULL),
            identical(unlist(evidence$boundary_knots), unname(attr(bases[[index]],"Boundary.knots"))))
}
stopifnot(identical(health$fit_evidence$maximum_gradient, as.numeric(fit@details$maxgrad)),
          identical(health$optimizer_convergence, as.integer(fit@details$convergence)),
          identical(health$fit_evidence$termination_code, as.integer(fit@details$conv)))
time_col <- ".time"; event_col <- ".event"; spec <- list(fpm=list(set_a_df=list(3L,1L)))
mapping <- function(data) list(x=as.matrix(data[,c("X","AST_ALT")]),
              parent_map=data.frame(parent=c("X","AST_ALT"), column=c("X","AST_ALT")))
prepared <- list(train_mapping=mapping(frame), test_mapping=mapping(frame[1:12,]))
actual <- fit_predict("FPM_TVC_SET_A", frame, frame[1:12,], c("X","AST_ALT"), list(),
                       300101L, c(.1,.5,1), NULL, prepared_design=prepared)
newdata <- frame[rep(1:12, times=3),c("X","AST_ALT")]; newdata$.time <- rep(c(.1,.5,1),each=12)
expected <- matrix(as.numeric(predict(fit, newdata=newdata,type="surv")),nrow=12)
stopifnot(identical(actual$survival, expected),
          identical(actual$stopping$fit_evidence, health$fit_evidence))
cat(canonical_json(actual$stopping), "\n")
''')


def test_fpm_actual_fit_evidence_passes_native_final_validator(fpm_native_health):
    health = fpm_native_health
    assert health["df"] == 3 and health["tvc_df"] == 1
    assert health["optimizer"] == "optim"
    _validate_fpm_fit_evidence(health["fit_evidence"], [3, 1], 7)
    rows = [{**health, "imputation": i, "prediction_seal_sha256": f"{i:064x}"} for i in range(1, 21)]
    seal_set = sha256_bytes(canonical_json_bytes([row["prediction_seal_sha256"] for row in rows]))
    _validate_nonelastic_fit_health(
        "FPM_TVC_SET_A", rows,
        {"ordered_parent_column_map": [{"parent": p, "columns": [p]} for p in ("X", "AST_ALT")]},
        {"fpm": {"set_a_df": [3, 1]}}, seal_set)


def test_fpm_initial_cox_uses_strict_convergence_with_unchanged_budget_and_ties():
    answer = run_r(r'''
initial <- list()
trace("coxph.fit", where=asNamespace("survival"), print=FALSE, tracer=quote({
  initial[[length(initial)+1L]] <<- list(control=control, method=method)
}))
''' + FPM_FIT + r'''
untrace("coxph.fit", where=asNamespace("survival"))
stopifnot(length(initial) == 1L,
          identical(packageDescription("rstpm2")[["PADML-Initialization"]],
                    "cox-eps-1e-11-iter20-v1"),
          identical(initial[[1L]]$control,
                    survival::coxph.control(eps=1e-11, iter.max=20L)),
          identical(initial[[1L]]$method, "efron"))
cat(toJSON(list(strict_initialization=TRUE, unchanged_budget=TRUE,
               unchanged_ties=TRUE), auto_unbox=TRUE), "\n")
''')
    assert all(answer.values())


def test_fpm_native_domain_rejects_invalid_hazards_and_preserves_feasible_likelihood():
    answer = run_r(FPM_FIT + r'''
stopifnot(fpm_constraint_identity() == "ph-continuous-domain-bfgs-v1")
args <- fit@args; args$init <- as.numeric(coef(fit))
evaluate <- function(value, type) {
  value$return_type <- type
  .Call("model_output", value, PACKAGE="rstpm2")
}
eta <- as.vector(args$X %*% args$init) + args$offset
etaD <- as.vector(args$XD %*% args$init)
H <- exp(eta); h <- etaD * H
expected <- sum(args$wt * (H - args$event * log(h)))
expected_gradient <- colSums(args$X * (args$wt * (H - args$event))) -
                     colSums(args$XD * (args$wt * args$event / etaD))
stopifnot(isTRUE(evaluate(args, "feasible")),
          abs(evaluate(args, "objective") - expected) < 1e-10,
          max(abs(evaluate(args, "gradient") - expected_gradient)) < 1e-10)
for (damage in c("zero", "negative", "nonfinite_h", "nonfinite_H")) {
  broken <- args
  if (damage == "zero") broken$XD[,] <- 0
  if (damage == "negative") broken$XD <- -args$XD
  if (damage == "nonfinite_h") broken$XD[,] <- NaN
  if (damage == "nonfinite_H") broken$offset[] <- 1000
  stopifnot(isFALSE(evaluate(broken, "feasible")),
            identical(evaluate(broken, "objective"), Inf))
}
cat(toJSON(list(feasible_likelihood_unchanged=TRUE, invalid_trials_rejected=TRUE),
           auto_unbox=TRUE), "\n")
''')
    assert all(answer.values())


def test_fpm_constrained_bfgs_preserves_budget_start_and_boundary_progress():
    answer = run_r(r'''
observed <- list()
trace("optim", where=asNamespace("stats"), print=FALSE, tracer=quote({
  if (identical(method,"BFGS") && identical(control$maxit,100L))
    observed[[length(observed)+1L]] <<- list(theta=par,method=method,control=control)
}))
''' + FPM_FIT + r'''
untrace("optim", where=asNamespace("stats"))
stopifnot(length(observed) == fit@details$constrained_bfgs$outer.iterations,
          length(observed) >= 1L, length(observed) <= 10L)
for (call in observed) stopifnot(call$method == "BFGS", call$control$maxit == 100L,
                                call$control$reltol == 1e-10)
expected_start <- fit@args$lm_init + fit@args$padml_initialization_shift *
                  fit@args$padml_domain_geometry$interior_direction
stopifnot(identical(as.numeric(observed[[1L]]$theta),as.numeric(expected_start)),
          identical(as.numeric(fit@args$lm_init),as.numeric(coef(fit@lm))),
          all(fit@args$XD %*% observed[[1L]]$theta > 0))
args <- fit@args; args$init <- as.numeric(coef(fit)); args$return_type <- "hessian"
before <- serialize(args$init, NULL)
hessian <- .Call("model_output", args, PACKAGE="rstpm2")
stopifnot(identical(serialize(args$init, NULL), before),
          max(abs(solve(hessian, tol=0) - unname(vcov(fit)))) < 1e-12)
# A known boundary optimum must retain tangential progress, not merely h > 0.
control <- observed[[1L]]$control; control$parscale <- rep(1, 2)
geometry <- list(pieces=list(list(exposure=0,lower=0,upper=1,
                       derivative=rbind(c(1,0),c(0,0),c(0,0)))))
boundary <- rstpm2:::padml_ph_constr_optim(c(1,-3),
  function(x) (x[1]+1)^2 + (x[2]-3)^2/2,
  function(x) c(2*(x[1]+1), x[2]-3), ui=matrix(c(1,0),nrow=1),
  geometry=geometry, control=control, outer.eps=1e-5)
stopifnot(boundary$convergence == 0L, boundary$par[1] > 0,
          max(abs(boundary$par-c(0,3))) < 1e-6)
cat(toJSON(list(native_budget_preserved=TRUE, only_feasibility_initialization=TRUE,
                native_hessian_preserved=TRUE, boundary_progress=TRUE),auto_unbox=TRUE),"\n")
''')
    assert all(answer.values())


@pytest.mark.parametrize("anchored", [False, True])
def test_fpm_constrained_bfgs_moving_quadratic_minimum_and_interior(anchored):
    patch = (ROOT / "padml/kernels/rstpm2-feasible.patch").read_text()
    source = "\n".join(row[1:] for row in patch.split("+++ b/R/padml-ph-domain.R\n", 1)[1].splitlines()
                       if row.startswith("+"))
    answer = run_r(r'''
eval(parse(text=Sys.getenv("PADML_TEST_FPM_DOMAIN_SOURCE")))
geometry <- list(pieces=list(list(exposure=0,lower=0,upper=1,
  derivative=rbind(c(1,0,0,0),c(0,1,0,0),c(0,0,1,0)))),
  interior_direction=c(1,0,0,as.numeric(Sys.getenv("PADML_TEST_FPM_ANCHORED_DIRECTION"))))
control <- list(maxit=100L,reltol=1e-10,parscale=rep(1,4),trace=0)
boundary <- c(.25,-1,1,3)
normal <- c(1,.5,.25,0)
target <- boundary-normal
f <- function(x) sum((x-target)^2)/2
g <- function(x) x-target
result <- padml_ph_constr_optim(c(1,-1,1,-3),f,g,
  rbind(c(1,0,0,0),c(1,1,1,0)),geometry,control,1e-5)
check <- padml_ph_optimality(geometry,result$par,g(result$par),f(result$par))
stopifnot(result$convergence == 0L,check$converged,
  max(abs(result$par-boundary)) < 1e-4,result$outer.iterations <= 10L,
  padml_ph_domain_state(geometry,result$par)$minimum > 0)
target <- c(2,-1,1,3)
inside <- padml_ph_constr_optim(c(1,-1,1,-3),f,g,
  rbind(c(1,0,0,0),c(1,1,1,0)),geometry,control,1e-5)
stopifnot(inside$convergence == 0L,max(abs(inside$par-target)) < 1e-6)
cat(toJSON(list(boundary=result$par,boundary_rounds=result$outer.iterations,
  stationarity=check$stationarity,complementarity=check$complementarity,
  interior=inside$par),auto_unbox=TRUE,digits=17),"\n")
''', extra_env={"PADML_TEST_FPM_DOMAIN_SOURCE": source,
               "PADML_TEST_FPM_ANCHORED_DIRECTION": str(int(anchored))})
    assert answer["boundary_rounds"] <= 10
    assert answer["stationarity"] <= 1e-5
    assert answer["complementarity"] <= 1e-10


def test_fpm_tangent_centering_survives_stiff_curvature_and_large_constant():
    patch = (ROOT / "padml/kernels/rstpm2-feasible.patch").read_text()
    source = "\n".join(row[1:] for row in patch.split("+++ b/R/padml-ph-domain.R\n", 1)[1].splitlines()
                       if row.startswith("+"))
    answer = run_r(r'''
eval(parse(text=Sys.getenv("PADML_TEST_FPM_DOMAIN_SOURCE")))
geometry <- list(pieces=list(list(exposure=0,lower=0,upper=1,
  derivative=rbind(c(1,0,0),c(0,0,0),c(0,0,0)))),interior_direction=c(1,0,0))
f <- function(x) 1000+x[1]+x[1]^2/2+2e7*x[2]^2/2+x[3]^2/2
g <- function(x) c(1+x[1],2e7*x[2],x[3])
control <- list(maxit=100L,reltol=1e-10,parscale=c(1,1,1),trace=0)
result <- padml_ph_constr_optim(c(1e-8,5e-8,.1),f,g,
  matrix(c(1,0,0),nrow=1),geometry,control,1e-5)
check <- padml_ph_optimality(geometry,result$par,g(result$par),f(result$par))
stopifnot(result$convergence == 0L,check$converged,result$outer.iterations <= 10L)
cat(toJSON(list(stationarity=check$stationarity,complementarity=check$complementarity,
  rounds=result$outer.iterations),auto_unbox=TRUE,digits=17),"\n")
''', extra_env={"PADML_TEST_FPM_DOMAIN_SOURCE": source})
    assert answer["rounds"] <= 10
    assert answer["stationarity"] <= 1e-5
    assert answer["complementarity"] <= 1e-10


def test_fpm_retained_real_boundary_counterexamples_fail_optimality_without_refitting():
    archives = os.environ.get("PADML_TEST_FPM_OPTIMALITY_ARCHIVES")
    if not archives:
        pytest.skip("Set PADML_TEST_FPM_OPTIMALITY_ARCHIVES to the two retained real fit ZIPs")
    patch = (ROOT / "padml/kernels/rstpm2-feasible.patch").read_text()
    source = "\n".join(row[1:] for row in patch.split("+++ b/R/padml-ph-domain.R\n", 1)[1].splitlines()
                       if row.startswith("+"))
    answer = run_r(r'''
suppressPackageStartupMessages(library(rstpm2))
eval(parse(text=Sys.getenv("PADML_TEST_FPM_DOMAIN_SOURCE")))
paths <- fromJSON(Sys.getenv("PADML_TEST_FPM_OPTIMALITY_ARCHIVES"))
stopifnot(length(paths) == 2L)
values <- lapply(paths,function(path) {
  connection <- gzcon(unz(path,"fit.rds","rb"))
  fit <- readRDS(connection);close(connection)
  a <- fit@args;b <- as.numeric(coef(fit))
  stopifnot(a$link == "PH",!a$delayed,!a$interval,
            all(a$bhazard == 0),all(a$offset == 0))
  X <- a$X;XD <- a$XD;w <- a$wt;e <- a$event
  f <- function(beta) {eta <- as.vector(X%*%beta);d <- as.vector(XD%*%beta)
    sum(w*(exp(eta)-e*(eta+log(d))))}
  eta <- as.vector(X%*%b);d <- as.vector(XD%*%b)
  g <- as.vector(crossprod(X,w*(exp(eta)-e))-crossprod(XD,w*e/d))
  H <- crossprod(X,X*(w*exp(eta)))+crossprod(XD,XD*(w*e/d^2))
  A <- do.call(rbind,lapply(a$padml_domain_geometry$pieces,`[[`,"derivative"))
  free <- which(colSums(abs(A)) == 0)
  delta <- numeric(length(b));delta[free] <- -solve(H[free,free],g[free])
  candidate <- b+.5*delta
  check <- padml_ph_optimality(a$padml_domain_geometry,b,g,f(b))
  stopifnot(fit@details$convergence == 0L,!check$converged,
    identical(A%*%b,A%*%candidate),identical(XD%*%b,XD%*%candidate),
    f(candidate) < f(b))
  list(decrease=f(b)-f(candidate),stationarity=check$stationarity,
       maximum_free_gradient=max(abs(g[free])))
})
cat(toJSON(list(cases=values,model_fits=0L),auto_unbox=TRUE,digits=17),"\n")
''', extra_env={"PADML_TEST_FPM_DOMAIN_SOURCE": source,
               "PADML_TEST_FPM_OPTIMALITY_ARCHIVES": archives})
    assert answer["model_fits"] == 0
    assert len(answer["cases"]) == 2
    assert all(row["stationarity"] > 1e-5 for row in answer["cases"])


@pytest.mark.parametrize("case,expected", [
    ("roundoff", 0), ("increase", 11), ("nonconvergence", 7),
    ("nonfinite", "PADML_FPM_CONTINUOUS_DOMAIN_OPTIMIZER_INVALID"),
    ("domain", "PADML_FPM_CONTINUOUS_DOMAIN_OPTIMIZER_INVALID"),
])
def test_fpm_barrier_native_stop_order_does_not_swallow_failures(case, expected):
    patch = (ROOT / "padml/kernels/rstpm2-feasible.patch").read_text()
    domain = patch.split("+++ b/R/padml-ph-domain.R\n", 1)[1]
    source = "\n".join(row[1:] for row in domain.splitlines() if row.startswith("+"))
    answer = run_r(r'''
eval(parse(text=Sys.getenv("PADML_TEST_FPM_DOMAIN_SOURCE")))
case <- Sys.getenv("PADML_TEST_FPM_BARRIER_CASE")
control <- list(maxit=100L,reltol=1e-10,parscale=c(1,1),trace=0)
geometry <- list(pieces=list(list(exposure=0,lower=0,upper=1,
                     derivative=rbind(c(1,0),c(0,0),c(0,0)))))
objective <- function(x) {
  if (x[2] == 0) return(953.2882187039786)
  if (x[2] == 1) return(952.25119681999763)
  switch(case, roundoff=952.25119681999809, increase=953.25119681999763,
         nonconvergence=952.25119681999763, nonfinite=Inf, domain=952.25119681999763)
}
# Script only the inner optimizer's returns; the actual package patch owns
# feasibility, stopping order, all thresholds, counts and outer-round budget.
calls <- 0L
inner <- function(par,fn,gr,method,control) {
  stopifnot(method == "BFGS", control$maxit == 100L, control$reltol == 1e-10)
  calls <<- calls+1L
  next_par <- c(if (case == "domain" && calls > 1L) -1 else 1,calls)
  list(par=next_par,value=fn(next_par),counts=c(`function`=1L,gradient=1L),
       convergence=if (case == "nonconvergence") 1L else 0L)
}
namespace <- asNamespace("stats"); original <- stats::optim
replace_optim <- function(value) {
  unlockBinding("optim",namespace); assign("optim",value,namespace); lockBinding("optim",namespace)
}
replace_optim(inner)
result <- tryCatch(padml_ph_constr_optim(c(1,0),objective,function(x)c(0,0),
  matrix(c(1,0),nrow=1),geometry,control,1e-5),
  error=function(error) conditionMessage(error), finally=replace_optim(original))
value <- if (is.list(result)) result$convergence else result
if (case == "roundoff") stopifnot(identical(result$par,c(1,2)),
  identical(result$value,952.25119681999809),result$outer.iterations == 2L)
# A real BFGS boundary optimum still makes tangential progress after reordering.
boundary <- padml_ph_constr_optim(c(1,-3),
  function(x)(x[1]+1)^2+(x[2]-3)^2/2,function(x)c(2*(x[1]+1),x[2]-3),
  matrix(c(1,0),nrow=1),geometry,control,1e-5)
stopifnot(boundary$convergence == 0L, boundary$par[1] > 0,
          max(abs(boundary$par-c(0,3))) < 1e-6)
cat(toJSON(list(result=value,calls=calls,boundary_progress=TRUE),auto_unbox=TRUE),"\n")
''', extra_env={"PADML_TEST_FPM_DOMAIN_SOURCE": source,
               "PADML_TEST_FPM_BARRIER_CASE": case})
    assert answer["result"] == expected
    assert answer["calls"] == (10 if case == "nonconvergence" else 2)
    assert answer["boundary_progress"]


def test_fpm_warning_stops_before_native_alternate_optimizer():
    answer = run_r(r'''
time_col <- ".time"; event_col <- ".event"; spec <- list(fpm=list(set_a_df=list(3L,1L)))
frame <- data.frame(.time=1:12, .event=1L, X=1:12, AST_ALT=seq(.1,1.2,.1))
mapping <- function(data) list(x=as.matrix(data[,c("X","AST_ALT")]),
             parent_map=data.frame(parent=c("X","AST_ALT"),column=c("X","AST_ALT")))
prepared <- list(train_mapping=mapping(frame), test_mapping=mapping(frame))
continued <- FALSE
stpm2 <- function(...) {
  warning("Non-invertible Hessian - refitting with Nelder-Mead")
  continued <<- TRUE
  stop("UNAUTHORIZED_ALTERNATE_FIT")
}
reason <- tryCatch({
  fit_predict("FPM_TVC_SET_A",frame,frame,c("X","AST_ALT"),list(),300101L,
              c(.1,.5,1),NULL,prepared_design=prepared)
  "unexpected_success"
}, error=function(e) conditionMessage(e))
stopifnot(!continued, startsWith(reason, "F2_FPM_FIT_WARNING:"))
cat(toJSON(list(alternate_fit_prevented=TRUE),auto_unbox=TRUE),"\n")
''')
    assert answer["alternate_fit_prevented"] is True


@pytest.mark.parametrize("damage", ["missing", "gradient", "code", "tolerance", "knots", "boundary", "df",
                                     "constraint_correction", "native_feasible", "continuous_domain",
                                     "domain_limit", "piece_minimum", "inference", "budget",
                                     "missing_optimality", "free_descent", "negative_multiplier",
                                     "unbound_geometry"])
def test_fpm_final_validator_rejects_missing_or_tampered_native_evidence(fpm_native_health, damage):
    evidence = json.loads(json.dumps(fpm_native_health["fit_evidence"]))
    if damage == "missing":
        evidence.pop("spline_bases")
    elif damage == "gradient":
        evidence["maximum_gradient"] = float("nan")
    elif damage == "code":
        evidence["termination_code"] = 1
    elif damage == "tolerance":
        evidence["controls"]["reltol"] = 1e-5
    elif damage == "knots":
        evidence["spline_bases"][0]["knots"] = []
    elif damage == "boundary":
        evidence["spline_bases"][0]["boundary_knots"].reverse()
    elif damage == "df":
        evidence["spline_bases"][1]["df"] = 2
    elif damage == "constraint_correction":
        evidence["constraint_correction"] = "finite-penalty"
    elif damage == "native_feasible":
        evidence["native_feasible"] = False
    elif damage == "continuous_domain":
        evidence.pop("continuous_domain")
    elif damage == "domain_limit":
        evidence["continuous_domain"]["ast_alt_closure"][1] = 16
    elif damage == "piece_minimum":
        evidence["continuous_domain"]["pieces"][0]["derivative_coefficients"] = [0.24, -1, 1]
    elif damage == "inference":
        evidence["continuous_domain"]["constrained_wald_inference_validated"] = True
    elif damage == "budget":
        evidence["continuous_domain"]["max_rounds"] = 11
    elif damage == "missing_optimality":
        evidence.pop("constrained_optimality")
    elif damage == "free_descent":
        evidence["constrained_optimality"]["gradient"][0] += 1000
        evidence["maximum_gradient"] = max(abs(x) for x in evidence["constrained_optimality"]["gradient"])
    elif damage == "negative_multiplier":
        evidence["constrained_optimality"]["multipliers"][0] = -1
    elif damage == "unbound_geometry":
        evidence["constrained_optimality"]["derivative_matrices"][0][0][0] += 1
    with pytest.raises(ContractError, match="FPM_.*INVALID"):
        _validate_fpm_fit_evidence(evidence, [3, 1], 7)


@pytest.mark.parametrize("damage", ["gradient", "convergence", "conv", "tolerance", "knots", "warning",
                                     "zero_hazard", "nonfinite_hazard"])
def test_fpm_native_evidence_fails_without_altering_optimizer_or_constraints(damage):
    answer = run_r(FPM_FIT + f'\ndamage <- "{damage}"\n' + r'''
if (damage == "gradient") fit@details$maxgrad <- NaN
if (damage == "convergence") fit@details$convergence <- 1L
if (damage == "conv") fit@details$conv <- 1L
if (damage == "tolerance") fit@args$reltol <- 1e-5
if (damage == "zero_hazard") fit@args$XD[,] <- 0
if (damage == "nonfinite_hazard") fit@args$XD[,] <- NaN
if (damage == "knots") {
  index <- which(vapply(fit@lm$model, inherits, logical(1), "nsx"))[[1L]]
  attr(fit@lm$model[[index]], "Boundary.knots") <- NULL
}
reason <- tryCatch({validate_fpm_fit_health(fit, as.integer(damage=="warning"), c(3L,1L));
                    "unexpected_success"}, error=function(e) conditionMessage(e))
stopifnot(reason %in% c("F2_FPM_FIT_HEALTH_INVALID", "F2_FPM_ACTUAL_SPLINE_EVIDENCE_INVALID"))
cat(toJSON(list(rejected=TRUE),auto_unbox=TRUE), "\n")
''')
    assert answer["rejected"] is True


def test_fpm_continuous_domain_catches_training_point_and_between_month_failures():
    answer = run_r(r'''
suppressPackageStartupMessages(library(rstpm2))
set.seed(19437L); n <- 240L
frame <- data.frame(.time=exp(runif(n,0,log(2))),AST_ALT=runif(n,.2,2),X=rnorm(n),y=rnorm(n))
lmfit <- lm(y ~ X+AST_ALT+
  nsx(log(.time),knots=log(c(1.2,1.8)),Boundary.knots=log(c(1,2)))+
  AST_ALT:nsx(log(.time),df=1,Boundary.knots=log(c(1,2))),data=frame)
geometry <- rstpm2:::padml_ph_domain_geometry(lmfit,frame,".time",c(0,15))
state <- function(beta) rstpm2:::padml_ph_domain_state(geometry,beta)
design <- function(data) rstpm2:::lpmatrix.lm(lmfit,data)
direction <- geometry$interior_direction
stopifnot(max(abs(vapply(state(direction)$pieces,function(p)p$minimum,numeric(1))-1))<1e-11)
tvc <- which(grepl(":",colnames(design(frame))))
beta <- 2*direction
beta[tvc] <- -3/geometry$pieces[[4L]]$derivative[1L,tvc]
stopifnot(state(beta)$minimum < -.99)
# Training exposures occupy .2..2: this coefficient vector is positive there,
# although the actual support endpoint 15 is invalid.
derivative_at <- function(x,logt,beta) {
  p <- geometry$pieces[[max(1L,min(3L,findInterval(logt,geometry$breaks)))]]
  z <- (logt-p$lower)/(p$upper-p$lower)
  i <- max(1L,min(3L,findInterval(logt,geometry$breaks)))
  low <- c(1,z,z^2) %*% geometry$pieces[[i]]$derivative
  high <- c(1,z,z^2) %*% geometry$pieces[[i+3L]]$derivative
  as.numeric(((1-x/15)*low+(x/15)*high) %*% beta)
}
stopifnot(all(mapply(derivative_at,frame$AST_ALT,log(frame$.time),MoreArgs=list(beta=beta))>0))
inside <- rstpm2:::padml_ph_interior(beta,geometry,matrix(direction,nrow=1))
stopifnot(state(inside$theta)$minimum > 0, inside$theta[tvc] == beta[tvc])
for (p in seq_len(3L)) for (z in c(0,.17,.51,.92,1)) {
  low <- c(1,z,z^2) %*% geometry$pieces[[p]]$derivative
  high <- c(1,z,z^2) %*% geometry$pieces[[p+3L]]$derivative
  for (x in c(0,.2,3,7.5,14,15))
    stopifnot(as.numeric(((1-x/15)*low+(x/15)*high) %*% inside$theta)>0)
}
# A genuine natural-cubic baseline: integer-month probabilities are valid,
# but the continuous derivative has a negative interior minimum in (1,2).
mat <- rbind(geometry$pieces[[1L]]$derivative[1L,],
             c(1,.5,.25) %*% geometry$pieces[[2L]]$derivative,
             colSums(geometry$pieces[[3L]]$derivative))
columns <- which(colSums(abs(mat))>0)
between <- numeric(length(beta)); between[columns] <- solve(mat[,columns],c(1,-.1,1))
test <- frame[rep(1L,36L),,drop=FALSE];test$.time <- 1:36;test$AST_ALT <- 1
probability <- exp(-exp(as.vector(design(test) %*% between)))
stopifnot(all(is.finite(probability)),all(probability>=0 & probability<=1),
          all(diff(probability)<=1e-10),state(between)$minimum < 0)
cat(toJSON(list(training_only_counterexample=TRUE,affine_endpoints_cover_domain=TRUE,
               between_month_counterexample=TRUE,negative_tvc_not_forced_positive=TRUE),auto_unbox=TRUE),"\n")
''')
    assert all(answer.values())


@pytest.mark.parametrize("bad", [0, -0.1, 15.1])
def test_fpm_out_of_domain_input_stops_before_fitting(bad):
    answer = run_r(r'''
time_col <- ".time"; event_col <- ".event"; spec <- list(fpm=list(set_a_df=list(3L,1L)))
frame <- data.frame(.time=1:12,.event=1L,X=1:12,AST_ALT=seq(.1,1.2,.1))
test <- frame
test$AST_ALT[[1L]] <- BAD_VALUE
mapping <- function(data) list(x=as.matrix(data[,c("X","AST_ALT")]),
               parent_map=data.frame(parent=c("X","AST_ALT"),column=c("X","AST_ALT")))
called <- FALSE
stpm2 <- function(...) {called <<- TRUE;stop("UNAUTHORIZED_FIT")}
reason <- tryCatch({fit_predict("FPM_TVC_SET_A",frame,test,c("X","AST_ALT"),list(),300101L,
                     c(1,2,3),NULL,prepared_design=list(train_mapping=mapping(frame),test_mapping=mapping(test)))
                     "unexpected_success"},error=function(e)conditionMessage(e))
stopifnot(!called,reason=="F2_FPM_FIXED_COMPUTATIONAL_DOMAIN_INVALID")
cat(toJSON(list(rejected_before_fit=TRUE),auto_unbox=TRUE),"\n")
'''.replace("BAD_VALUE", repr(bad)))
    assert answer["rejected_before_fit"] is True
