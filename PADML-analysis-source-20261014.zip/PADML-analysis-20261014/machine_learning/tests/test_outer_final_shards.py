"""Original post-lock workers and M20 consumer; synthetic UNFITTED model leaves."""
import copy
import shutil

import pytest

from padml import f4, nested_loco as nested, runtime
from padml.bundle import ContractError, canonical_json_bytes, read_safe_zip, strict_json_bytes
from test_nested_loco import _accepted_model, _summary
from test_nested_outer_f4 import outer_bundle, _unfitted_engines


def _serial_engines(monkeypatch):
    calls = _unfitted_engines(monkeypatch)
    monkeypatch.setattr(runtime, "effective_cpu_count", lambda: 32)
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda root: {
        "effective_cpus": 32, "available_memory_bytes": 10**12, "scratch_available_bytes": 10**12,
        "scratch_root": str(root)})
    def pool(worker, jobs, *, selected_slots, execution_report=None, on_result=None, **kwargs):
        report = {} if execution_report is None else execution_report
        report.update(configured_worker_ceiling=24, admitted_worker_ceiling=selected_slots,
            runnable_task_count=len(jobs), actual_worker_process_peak=1, completed_task_count=0,
            engine_threads=1, status="RUNNING")
        output = [None] * len(jobs)
        try:
            for index in reversed(range(len(jobs))):
                value = worker(jobs[index])
                if on_result is None:
                    output[index] = value
                else:
                    on_result(index, value)
                report["completed_task_count"] += 1
        except BaseException:
            report["status"] = "FAILED"
            raise
        report["status"] = "COMPLETED"
        return output
    monkeypatch.setattr(f4, "_bounded_ordered_spawn", pool)
    return calls


@pytest.mark.parametrize("scratch_reserve", [None, 0])
def test_final_batch_execution_reads_source_once_per_independent_consumer(tmp_path, monkeypatch, scratch_reserve):
    """Execution-accounting fixture only; no model or numerical acceptance."""
    policy = {"configured_worker_ceiling": runtime.CPU_MINUS_8, "memory_bytes_per_worker": 1,
        "scratch_bytes_per_worker": 1, "memory_reserve_bytes": 0, "scratch_reserve_bytes": 0,
        "transfer_archive_worker_ceiling": 24}
    request = {"identity_sha256": "a" * 64, "resource_policy": policy, "expanded_bytes_per_component": 1,
        "retained_bytes_per_component": 1, "shared_storage_bytes": 1,
        "training_context": {"heldout_ids": ["UNFITTED"]}}
    lock = {"identity_sha256": "b" * 64}
    source = f4._f45_source_member_sha256()
    identity = nested._sha(source)
    components = [{"receipt": {"imputation": imp}} for imp in range(1, 21)]
    observation = {"effective_cpus": 32, "available_memory_bytes": 10**12,
                   "scratch_available_bytes": 10**9, "scratch_root": str(tmp_path)}
    executions = []
    for first in range(1, 7):
        ids = list(range(first, 21, 6))
        admission, reservation = f4._o_fit_final_batch_admission(request, observation, len(ids),
            execution_worker_memory_bytes=2 * 1024**3, execution_scratch_reserve_bytes=scratch_reserve)
        report = {"configured_worker_ceiling": 24, "admitted_worker_ceiling": admission["admitted_worker_ceiling"],
            "runnable_task_count": len(ids), "actual_worker_process_peak": 1, "completed_task_count": len(ids),
            "engine_threads": 1, "status": "COMPLETED"}
        executions.append({"source_identity": identity, "operational_identity": runtime.OPERATIONAL_IDENTITY,
            "request_identity_sha256": request["identity_sha256"], "development_lock_sha256": lock["identity_sha256"],
            "imputations": ids, "components_sha256": nested._sha([components[imp - 1] for imp in ids]),
            "resource_observation": observation, "resource_admission": admission, "resource_reservation": reservation,
            "pool_execution_reports": [report, report], "new_model_fits": len(ids),
            "new_model_native_verification_count": len(ids), "native_model_replay_count": 0,
            "new_mice_chains": 0, "new_stop_fits": 0})
    scans = []
    def current_source():
        scans.append(1)
        return source
    monkeypatch.setattr(f4, "_f45_source_member_sha256", current_source)
    f4._o_fit_final_batch_execution(executions, components, request=request, lock=lock)
    assert scans == [1]
    # The source is independently bound above. A marker cannot excuse a
    # different historical effective policy or a fabricated admission.
    for damage in ("marker", "effective", "admission"):
        changed = copy.deepcopy(executions)
        if damage == "marker":
            changed[0]["resource_reservation"]["execution_scratch_reserve_bytes"] = True
        elif damage == "effective":
            changed[0]["resource_reservation"]["effective_policy"]["scratch_reserve_bytes"] += 1
        else:
            changed[0]["resource_admission"]["admitted_worker_ceiling"] += 1
        with pytest.raises(ContractError):
            f4._o_fit_final_batch_execution(changed, components, request=request, lock=lock)
    scans.clear()
    source = {**source, "padml/f4.py": "f" * 64}
    with pytest.raises(ContractError, match="F4_O_FIT_FINAL_BATCH_SOURCE_DRIFT"):
        f4._o_fit_final_batch_execution(executions, components, request=request, lock=lock)
    assert scans == [1]


def test_final_future_scratch_removes_reserve_not_actual_space(tmp_path):
    policy = {"configured_worker_ceiling": runtime.CPU_MINUS_8, "memory_bytes_per_worker": 1,
        "scratch_bytes_per_worker": 1024, "memory_reserve_bytes": 0, "scratch_reserve_bytes": 4096,
        "transfer_archive_worker_ceiling": 24}
    request = {"resource_policy": policy, "expanded_bytes_per_component": 1,
        "retained_bytes_per_component": 1, "shared_storage_bytes": 8192,
        "training_context": {"heldout_ids": ["UNFITTED"]}}
    observation = {"effective_cpus": 32, "available_memory_bytes": 10**12,
        "scratch_available_bytes": 2048, "scratch_root": str(tmp_path)}
    with pytest.raises(ContractError, match="RESOURCE_ADMISSION_ZERO"):
        f4._o_fit_final_batch_admission(request, observation, 1, execution_worker_memory_bytes=2 * 1024**3)
    admission, reservation = f4._o_fit_final_batch_admission(request, observation, 1,
        execution_worker_memory_bytes=2 * 1024**3, execution_scratch_reserve_bytes=0)
    assert admission["admitted_worker_ceiling"] == 1
    assert reservation["remaining_retention_reserved_bytes"] == 8192
    assert reservation["effective_policy"]["scratch_reserve_bytes"] == 0
    for resource in ("scratch_available_bytes", "available_memory_bytes"):
        with pytest.raises(ContractError, match="RESOURCE_ADMISSION_ZERO"):
            f4._o_fit_final_batch_admission(request, {**observation, resource: 1}, 1,
                execution_worker_memory_bytes=2 * 1024**3, execution_scratch_reserve_bytes=0)


def _winner_inputs(request, request_root, root, winner):
    root.mkdir()
    scores = []
    for family in nested._families():
        mean = .001 if family == winner else .2
        if family in nested.REUSED_SCORE_FAMILIES:
            spec = next(row["selected_spec"] for row in request["reused_training_scores"] if row["family"] == family)
            model = _accepted_model(family, mean)
            model.update(selected_spec=spec, selected_spec_sha256=nested._sha(spec))
            scores.append(nested.project_accepted_training_score(model, source_result_sha256="d" * 64,
                training_context_sha256=request["training_context"]["identity_sha256"]))
        else:
            record = next(row for row in request["post_lock_templates"] if row["family"] == family)
            task = nested._read_component(request_root / record["path"])[0]
            spec = task["f4_outer_elastic_source"]["selected_spec"] if family == "ELASTIC_NET_COX" else task["parameters"]
            scores.append(nested.seal_fresh_training_score(family=family, outer_fold=1,
                training_context_sha256=request["training_context"]["identity_sha256"], selected_spec=spec,
                selector_evidence_sha256="e" * 64, summary=_summary(mean), execution_evidence_sha256="f" * 64))
    for row in request["post_lock_templates"]:
        if row["family"] == winner:
            target = root / "request" / row["path"]
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(request_root / row["path"], target)
    return {"training_scores": scores, "family_decision": nested.select_training_family(scores)}


def test_seven_winners_six_final_shards_feed_original_m20_numbers(outer_bundle, tmp_path, monkeypatch):
    source, _ = outer_bundle
    request_root = tmp_path / "source"
    request = f4._materialize_o_fit_input_bundle(source, request_root)
    calls = _serial_engines(monkeypatch)
    observations = []
    for family in nested._families():
        root = tmp_path / family
        scored = _winner_inputs(request, request_root, root, family)
        before = len(calls)
        prepared = f4._o_fit_post_lock_m20(request, scored, root, workers=4, replay=False, prepare_only=True)
        assert prepared["imputations"] == list(range(1, 21)) and prepared["new_model_fits"] == 0
        assert (root / "development-lock.json").is_file() and not (root / "bound").exists()
        batches = []
        for index in range(6):
            worker = tmp_path / f"{family}-worker-{index}"
            worker_scores = _winner_inputs(request, request_root, worker, family)
            assigned = prepared["imputations"][index::6]
            batch = worker / "final-batches" / "assignment"
            result = f4._o_fit_post_lock_m20(request, worker_scores, worker, workers=4, replay=False,
                imputations=assigned, batch_root=batch)
            assert result["new_model_fits"] == result["new_model_native_verification_count"] == len(assigned)
            assert {path.name for path in (worker / "fits").glob("*.zip")} == {f"M{imp:02d}.zip" for imp in assigned}
            assert not (worker / "final-numbers.zip").exists()
            value = strict_json_bytes((batch / "execution.json").read_bytes())
            assert value["execution"]["development_lock_sha256"] == prepared["development_lock"]["identity_sha256"]
            assert [row["receipt"]["imputation"] for row in value["components"]] == assigned
            if index == 0:
                with pytest.raises(ContractError, match="F4_NATIVE_MODEL_TARGET_ALREADY_STARTED"):
                    f4._o_fit_post_lock_m20(request, worker_scores, worker, workers=4, replay=False,
                        imputations=assigned[:1], batch_root=worker / "final-batches" / "renamed")
            batches.append(batch)
        assert len(calls) - before == 20
        assert not (root / "fits").exists()
        with monkeypatch.context() as collector:
            def forbidden(*args, **kwargs):
                pytest.fail("Whole M20 numerical gathering cannot fit, load or audit execution-owned native models")
            collector.setattr(f4, "_execute_f4_model_component", forbidden)
            collector.setattr(f4, "_replay_f4_model_component", forbidden)
            collector.setattr(nested, "_component_execution_receipt", forbidden)
            if family == "COXTIME_SET_A":
                for invalid in (batches[:-1], [*batches, batches[0]]):
                    with pytest.raises(ContractError, match="FINAL_BATCH_COMPLETE_SET_REQUIRED|FINAL_BATCHES_INVALID"):
                        f4._o_fit_post_lock_m20(request, scored, root, workers=4, replay=False, final_batches=invalid)
                path = batches[0] / "execution.json"
                saved = path.read_bytes()
                for damage in ("source", "lock", "count", "pool", "admission", "duplicate", "number"):
                    value = strict_json_bytes(saved)
                    execution = value["execution"]
                    if damage == "source":
                        execution["source_identity"] = "0" * 64
                    elif damage == "lock":
                        execution["development_lock_sha256"] = "0" * 64
                    elif damage == "count":
                        execution["new_model_native_verification_count"] -= 1
                    elif damage == "pool":
                        execution["pool_execution_reports"][1]["completed_task_count"] -= 1
                    elif damage == "admission":
                        execution["resource_admission"]["admitted_worker_ceiling"] += 1
                    elif damage == "duplicate":
                        value["components"][1] = copy.deepcopy(value["components"][0])
                    else:
                        value["components"][0]["prediction"]["survival"][family][0] = [1.] + [.7] * 36
                    execution["components_sha256"] = nested._sha(value["components"])
                    path.write_bytes(canonical_json_bytes(value))
                    try:
                        with pytest.raises(ContractError):
                            f4._o_fit_post_lock_m20(request, scored, root, workers=4, replay=False, final_batches=batches)
                    finally:
                        path.write_bytes(saved)
                    assert not (root / "final-numbers.zip").exists()
            result = f4._o_fit_post_lock_m20(request, scored, root, workers=4, replay=False, final_batches=list(reversed(batches)))
            replay = f4._o_fit_post_lock_m20(request, scored, root, workers=4, replay=True, native_members=result["native_members"])
        assert result["new_model_fits"] == result["native_model_replay_count"] == 0
        assert result["final_numerical_component_count"] == replay["final_numerical_component_count"] == 20
        assert result["development_lock"] == prepared["development_lock"] == replay["development_lock"]
        assert result["selected_prediction"] == replay["selected_prediction"]
        assert result["selected_prediction"]["survival"][0] == [1.] + [.8] * 36
        numbers = strict_json_bytes(read_safe_zip(root / "final-numbers.zip")["final.json"])
        assert len(numbers["batch_executions"]) == 6
        assert [row["receipt"]["imputation"] for row in numbers["components"]] == list(range(1, 21))
        assert len(calls) - before == 20 and not (root / "fits").exists()
        observations.append({"family": family, "synthetic_model_coordinates": 20, "native_first_audits": 20,
            "shards": 6, "gather_native_object_opens": 0, "final_numbers_sha256": nested.sha256_file(root / "final-numbers.zip")})
    (tmp_path / "outer-final-shards-observation.json").write_bytes(canonical_json_bytes({
        "model_fits": 0, "leaf_adapter": "UNFITTED", "actual_worker_process_peak": 1,
        "original_m20_consumer": True, "observations": observations}))


def test_final_shard_failed_first_audit_preserves_confirmed_numbers_and_owner(outer_bundle, tmp_path, monkeypatch):
    source, _ = outer_bundle
    request_root = tmp_path / "source"
    request = f4._materialize_o_fit_input_bundle(source, request_root)
    calls = _serial_engines(monkeypatch)
    root = tmp_path / "worker"
    scored = _winner_inputs(request, request_root, root, "COX_PH")
    original = f4._replay_f4_model_component
    audited = []
    def fail_second(job, **kwargs):
        audited.append(job["archive"])
        if len(audited) == 2:
            raise ContractError("UNFITTED_FIRST_FINAL_AUDIT_FAILURE")
        return original(job, **kwargs)
    monkeypatch.setattr(f4, "_replay_f4_model_component", fail_second)
    batch = root / "final-batches" / "failure"
    with pytest.raises(ContractError, match="UNFITTED_FIRST_FINAL_AUDIT_FAILURE"):
        f4._o_fit_post_lock_m20(request, scored, root, workers=4, replay=False,
            imputations=[1, 7, 13], batch_root=batch)
    value = strict_json_bytes((batch / "failure.json").read_bytes())
    assert value["execution"]["new_model_fits"] is None
    assert value["execution"]["new_model_native_verification_count"] == len(value["confirmed_native_audits"]) == 1
    assert value["execution"]["pool_execution_reports"][1]["status"] == "FAILED"
    assert len(calls) == 3 and len(list((root / "fits").glob("*.zip"))) == 3
    assert not (batch / "execution.json").exists() and not (root / "final-numbers.zip").exists()
    with pytest.raises(ContractError, match="F4_NATIVE_MODEL_TARGET_ALREADY_STARTED"):
        f4._o_fit_post_lock_m20(request, scored, root, workers=4, replay=False,
            imputations=[1], batch_root=root / "final-batches" / "renamed")
    assert len(calls) == 3


@pytest.mark.parametrize("resource", ["available_memory_bytes", "scratch_available_bytes"])
def test_final_shard_reobserves_resources_before_native_start(outer_bundle, tmp_path, monkeypatch, resource):
    source, _ = outer_bundle
    request_root = tmp_path / "source"
    request = f4._materialize_o_fit_input_bundle(source, request_root)
    calls = _serial_engines(monkeypatch)
    root = tmp_path / "worker"
    scored = _winner_inputs(request, request_root, root, "COX_PH")
    original = runtime.observe_execution_resources
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda path: {**original(path), resource: 1})
    batch = root / "final-batches" / "not-admitted"
    with pytest.raises(ContractError, match="RESOURCE_ADMISSION_ZERO"):
        f4._o_fit_post_lock_m20(request, scored, root, workers=4, replay=False,
            imputations=[1, 7, 13, 19], batch_root=batch)
    assert calls == [] and not batch.exists() and not (root / "fits").exists()


@pytest.mark.parametrize("mode", ["prepare", "worker", "gather"])
def test_original_outer_cli_forwards_final_coordinate_mode(tmp_path, monkeypatch, capsys, mode):
    import sys
    source = tmp_path / "input.zip"
    source.write_bytes(b"UNFITTED CLI input; no input compiler or fit")
    batch = tmp_path / "batch"
    choices = {"prepare": ["--prepare-final"],
        "worker": ["--final-imputations", "1", "7", "--final-batch-root", str(batch)],
        "gather": ["--final-batches", str(batch)]}
    calls = []
    def invoke(*args, **kwargs):
        calls.append((args, kwargs))
        return {"UNFITTED_CLI": True}
    monkeypatch.setattr(f4, "execute_o_fit_bundle", invoke)
    monkeypatch.setattr(sys, "argv", ["padml-f4", "o-fit-execute", str(tmp_path / "outer.zip"),
        "--input-bundle", str(source), "--outer-fold", "1", *choices[mode]])
    f4.main()
    assert len(calls) == 1 and "UNFITTED_CLI" in capsys.readouterr().out
    expected = {"prepare": {"prepare_final": True},
        "worker": {"final_imputations": [1, 7], "final_batch_root": batch},
        "gather": {"final_batches": [batch]}}[mode]
    assert {key: value for key, value in calls[0][1].items()
            if key in {"prepare_final", "final_imputations", "final_batch_root", "final_batches"}} == expected
