"""Synthetic-only M20 recovery: original entry/engine/first-reader boundaries.

Only inventoried byte pins and the projected outer fixture are substituted;
the original source proof, view input/spec checks, M20 pack/first REPLAY,
numerical values, shared admission and fixed attempt exclusions stay live.
"""
import ast
import copy
import csv
import io
import os
import shutil
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import pytest

from padml import f4, f5, f5_sensitivity as sensitivity, nested_loco as nested, runtime
from padml.bundle import ContractError, canonical_json_bytes, sha256_bytes, sha256_file, strict_json_bytes, write_deterministic_zip
from test_f5 import native_mice_fixture
from test_nested_aar_mice import _unfitted_outer_mice_workers
from test_nested_full_development import _unfitted_confirmed_decision
from test_nested_loco import _lock, _scores
from test_retained_full0_source import retained_source_bundle  # noqa: F401


@pytest.fixture
def restoration_case(tmp_path, monkeypatch, retained_source_bundle):
    from padml.f1_kernel import compile_binding_contract

    retained = f4._retained_full0_source_members(retained_source_bundle,
        aar_primary_context=True, aar_mice_restoration=True)
    monkeypatch.setattr(runtime, "effective_cpu_count", lambda: 64)
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda root: {
        "effective_cpus": 64, "available_memory_bytes": 10**12,
        "scratch_available_bytes": 10**12, "scratch_root": str(root)})
    _, covariates, response = native_mice_fixture()
    binding = compile_binding_contract(covariates, response, workbook_sha256="a" * 64,
                                       enforce_formal_denominator=False)
    outer = next(row for row in binding["registry"]["outer"] if row["outer_fold"] == 3)
    centers = {row["Patient_ID"]: row["Center"] for row in csv.DictReader(io.StringIO(covariates.decode()))}
    fields, responses = f5._response_rows(response)
    training = f5._write_response_subset(fields, responses, outer["analysis_ids"], None)["private_bytes"]
    context = nested.compile_training_context(scope="OUTER", outer_fold=3, heldout_center=39,
        training_ids=outer["analysis_ids"], heldout_ids=outer["validation_ids"], centers_by_patient=centers,
        training_response_csv=training, mice_member_set_sha256="b" * 64,
        preprocessing_program_sha256="c" * 64, modeling_program_sha256=nested._sha(retained), seed_program_sha256="d" * 64)
    base = _unfitted_confirmed_decision(fixed_bootstrap=True)
    lock, _ = _lock(context, _scores(context, {name: .01 if name == "GBM_COX" else .2 for name in nested._families()}))
    lock["science_decision_binding"] = nested._outer_science_decision_binding(base)
    lock = nested._sealed({key: item for key, item in lock.items() if key != "identity_sha256"})
    primary = {"program_id": nested.PROGRAM_ID, "primary_training_context": context,
               "primary_development_lock": lock, "science_decision": base}
    policy = {"configured_worker_ceiling": "EXECUTION_HOST_C_MINUS_8", "memory_bytes_per_worker": 1,
        "scratch_bytes_per_worker": 1, "memory_reserve_bytes": 0, "scratch_reserve_bytes": 0,
        "transfer_archive_worker_ceiling": 1000}
    authority = copy.deepcopy(nested._aar3_mice_view_restoration_contract())
    owner = tmp_path / "original-owner"
    owner.mkdir()
    projected = owner / "outer-3.aar.input.zip"
    coordinate_root = owner / "outer-3.aar.input.zip.mice"
    monkeypatch.setattr(sensitivity, "_a12_mice_restoration_coordinate_root",
        lambda unit: coordinate_root / unit["estimand"] / unit["view_id"])
    entries, partials = {}, {}
    for unit in authority["atomic_units"]:
        name = unit["estimand"] + "/" + unit["view_id"]
        coordinate = coordinate_root / name
        coordinate.mkdir(parents=True)
        source = coordinate / "input.zip"
        # Only compilation uses the old producer context. Execution below
        # keeps the actual current executor and the original code-only proof.
        with monkeypatch.context() as old:
            old.setattr(f4, "_f45_source_member_sha256", lambda: retained)
            write_deterministic_zip(source, sensitivity._a12_total_mice_input_members(
                binding, covariates, response, 3, unit["view_id"],
                nested_source={**primary, "estimand": unit["estimand"]}, resource_policy=policy))
        value, _ = sensitivity._load_a12_total_mice_input(source,
            retained_primary_source_bundle=retained_source_bundle, retained_primary_context=True)
        original = coordinate / "input.zip.native-work"
        (original / "native").mkdir(parents=True)
        spec = sensitivity._a12_total_mice_spec(value, original)
        (original / "spec.json").write_bytes(canonical_json_bytes(spec))
        (original / "stderr.txt").write_bytes(b"UNFITTED historical termination remains UNKNOWN\n")
        partials[name] = {}
        for filename in unit["preserve_original_partial_rds"]:
            path = original / "native" / filename
            path.write_bytes(b"UNFITTED original incomplete evidence " + name.encode() + filename.encode())
            partials[name]["input.zip.native-work/native/" + filename] = {
                "sha256": sha256_file(path), "size_bytes": path.stat().st_size}
        unit["original_input"] = {"sha256": sha256_file(source), "size_bytes": source.stat().st_size}
        unit["original_spec"] = {"sha256": sha256_file(original / "spec.json"), "size_bytes": (original / "spec.json").stat().st_size}
        assert value["chain_seeds"] == unit["chain_seeds"]
        entries["mice-inputs/" + name + ".zip"] = source
    index = nested._sealed({"kind": "PADML_F5_A12_PROJECTED_OUTER_INPUTS_V1", "outer_fold": 3,
        "family": "GBM_COX", "resource_policy": policy,
        "mice_inputs": [{"estimand": unit["estimand"], "view_id": unit["view_id"],
                         "member": "mice-inputs/" + unit["estimand"] + "/" + unit["view_id"] + ".zip"}
                        for unit in authority["atomic_units"]]})
    authority["original_projected_input"]["identity_sha256"] = index["identity_sha256"]
    write_deterministic_zip(projected, {"a12-inputs.json": canonical_json_bytes(index), **entries})
    authority["original_projected_input"]["sha256"] = sha256_file(projected)
    # Synthetic hashes never enter a formal source bundle or decision file.
    monkeypatch.setattr(nested, "_aar3_mice_view_restoration_contract", lambda: authority)
    monkeypatch.setattr(sensitivity, "_a12_mice_restoration_partial_refs",
                        lambda unit: partials[unit["estimand"] + "/" + unit["view_id"]])
    decision = nested._sealed({**{key: item for key, item in base.items() if key != "identity_sha256"},
        "twelve_month_development": nested._twelve_month_development_contract(),
        "full0_rsf_tail_restoration": nested._full0_rsf_tail_restoration_contract(),
        "aar3_mice_view_restoration": authority})
    nested.validate_science_decision(decision)
    def projected_leaf(source, target, **kwargs):
        assert source == projected
        assert kwargs.get("retained_primary_source_bundle") == retained_source_bundle
        assert kwargs.get("retained_primary_context") is True or kwargs.get("retained_mice_gather") is True
        sensitivity.extract_safe_zip(source, target, expected_members={"a12-inputs.json", *entries},
                                     max_member_bytes=4 * 1024**2, max_total_bytes=16 * 1024**2)
        return {"root": target, "input": index}
    monkeypatch.setattr(sensitivity, "_load_a12_projected_outer_inputs", projected_leaf)
    calls, pools = _unfitted_outer_mice_workers(monkeypatch)
    return {"source": projected, "index": index, "decision": decision, "authority": authority,
        "calls": calls, "pools": pools, "coordinate_root": coordinate_root, "retained": retained_source_bundle,
        "fixture_inputs": (binding, covariates, response, primary, policy, retained),
        "names": [unit["estimand"] + "/" + unit["view_id"] for unit in authority["atomic_units"]]}


@pytest.fixture
def h0_native_case(restoration_case, tmp_path, monkeypatch):
    """Complete unfitted native fixture; the measured recovery may only REPLAY."""
    case = restoration_case
    binding, covariates, response, primary, policy, retained = case["fixture_inputs"]
    record = copy.deepcopy(sensitivity._a12_h0_native_first_replay_record())
    name = record["estimand"] + "/" + record["view_id"]
    owner = tmp_path / "h0-original-owner"
    coordinate = owner / "outer-3.aar.input.zip.mice" / name
    coordinate.mkdir(parents=True)
    source = coordinate / "input.zip"
    original = coordinate / "input.zip.native-work"
    original.mkdir()
    with monkeypatch.context() as old:
        old.setattr(f4, "_f45_source_member_sha256", lambda: retained)
        write_deterministic_zip(source, sensitivity._a12_total_mice_input_members(
            binding, covariates, response, 3, record["view_id"],
            nested_source={**primary, "estimand": record["estimand"]}, resource_policy=policy))
        sensitivity._run_a12_total_mice_input(source, original)
        sensitivity._pack_a12_total_mice_view(source, original, original / "native-view.zip")
    assert [row[0] for row in case["calls"]] == ["FIT"]  # fake_mice_run, not R
    case["calls"].clear()
    replay_leaf = sensitivity.subprocess.run
    def h0_replay_leaf(command, **kwargs):
        result = replay_leaf(command, **kwargs)
        if command[3] == "REPLAY":
            # The real unchanged f5_a12_mice.R writes this after both modes;
            # the older general fake only supplied it for FIT.
            (Path(command[4]).parent / "native-session.txt").write_text("MOCK_NOT_NATIVE_EXECUTION_PROOF")
        return result
    monkeypatch.setattr(sensitivity.subprocess, "run", h0_replay_leaf)
    old_failure = original / "first-audit"
    old_failure.mkdir()
    (old_failure / "summary.json").write_bytes((original / "output/summary.json").read_bytes())
    (old_failure / "failure.txt").write_bytes(b"UNFITTED retained interrupted first audit; not REPLAY success\n")
    for key, path in (("original_input", source), ("original_native", original / "native-view.zip"),
                      ("original_spec", original / "spec.json")):
        record[key] = {"sha256": sha256_file(path), "size_bytes": path.stat().st_size}
    record["attempt_root"] = str(coordinate / "first-replay-restoration-20260913")
    monkeypatch.setattr(sensitivity, "_a12_h0_native_first_replay_record", lambda: record)
    entry = "mice-inputs/" + name + ".zip"
    index = nested._sealed({"kind": "PADML_F5_A12_PROJECTED_OUTER_INPUTS_V1", "outer_fold": 3,
        "family": "GBM_COX", "resource_policy": policy,
        "mice_inputs": [{"estimand": record["estimand"], "view_id": record["view_id"], "member": entry}]})
    projected = owner / "outer-3.aar.input.zip"
    write_deterministic_zip(projected, {"a12-inputs.json": canonical_json_bytes(index), entry: source})
    authority = {"original_projected_input": {"sha256": sha256_file(projected), "identity_sha256": index["identity_sha256"]},
                 "atomic_units": []}
    monkeypatch.setattr(nested, "_aar3_mice_view_restoration_contract", lambda: authority)
    def projected_leaf(path, target, **kwargs):
        assert path == projected and kwargs.get("retained_primary_source_bundle") == case["retained"]
        assert kwargs.get("retained_primary_context") is True or kwargs.get("retained_mice_gather") is True
        selected = ({"a12-inputs.json"} if kwargs.get("branches") is not None
                    and record["estimand"] not in kwargs["branches"] else None)
        sensitivity.extract_safe_zip(path, target, expected_members={"a12-inputs.json", entry},
            selected_members=selected, max_member_bytes=4 * 1024**2, max_total_bytes=16 * 1024**2)
        return {"root": target, "input": index}
    monkeypatch.setattr(sensitivity, "_load_a12_projected_outer_inputs", projected_leaf)
    return {**case, "source": projected, "index": index, "names": [name], "record": record,
            "coordinate": coordinate, "original_files": {
                str(path): sha256_file(path) for path in coordinate.rglob("*") if path.is_file()}}


def _execute_h0_first_replay(case, target, **options):
    return sensitivity.execute_a12_outer_inputs(case["source"], target, view_ids=case["names"],
        retained_bytes_per_view=128 * 1024**2, retained_primary_source_bundle=case["retained"],
        native_first_replay=True, **options)


def test_h0_complete_m20_first_replay_only_and_direct_consumers(h0_native_case, tmp_path, monkeypatch):
    case = h0_native_case
    result = _execute_h0_first_replay(case, tmp_path / "h0-batch")
    assert [row[0] for row in case["calls"]] == ["REPLAY"]
    assert result["mice_chain_execution_count"] == result["model_fit_count"] == result["selector_path_count"] == 0
    execution = result["execution_report"]
    assert execution["completed_mice_fit_invocations"] == execution["completed_mice_chain_count"] == 0
    assert execution["completed_native_replay_invocations"] == 1
    report_path = Path(result["view_result_paths"][0])
    report = strict_json_bytes(report_path.read_bytes())
    assert report["execution_report"]["status"] == "UNKNOWN"
    assert report["first_audit_execution_report"]["status"] == "COMPLETED"
    assert report["native_first_replay"] == case["record"]
    assert len([key for key in report["numerical_view"]["members"] if key.endswith(".rds")]) == 20
    assert all(sha256_file(Path(path)) == digest for path, digest in case["original_files"].items())
    input_path = case["coordinate"] / "input.zip"
    sensitivity._validate_a12_h0_native_first_replay_report(report, report["numerical_view"], input_path)
    opened = sensitivity.materialize_a12_total_mice_view(input_path, report_path.with_suffix(""), tmp_path / "h0-numbers",
        numerical_view=report["numerical_view"], retained_primary_source_bundle=case["retained"], retained_mice_gather=True)
    assert opened["numerical_view"] == report["numerical_view"] and "execution_report" not in opened
    with pytest.raises(ContractError, match="COORDINATE_ALREADY_STARTED"):
        _execute_h0_first_replay(case, tmp_path / "renamed-h0-batch")
    _exercise_h0_first_replay_readers(case, result, report, tmp_path, monkeypatch)
    assert [row[0] for row in case["calls"]] == ["REPLAY"]


def _exercise_h0_first_replay_readers(case, result, original_report, tmp_path, monkeypatch):
    name = case["names"][0]
    identity = sha256_bytes(canonical_json_bytes(f4._f45_source_member_sha256()))
    def boundary(*args, **kwargs):
        raise ContractError("UNFITTED_H0_ORIGINAL_BRANCH_BOUNDARY")
    monkeypatch.setattr(sensitivity, "_materialize_a12_projected_branches", boundary)
    for damage in ("none", "strip_report", "strip_collection", "fit_completed", "new_chain", "float_replay",
                   "native_pin", "relabel", "release", "release_other", "release_missing_native", "release_size",
                   "inactive_total", "inactive_extra_member"):
        root = tmp_path / ("h0-reader-" + damage)
        root.mkdir()
        report = copy.deepcopy(original_report)
        execution = copy.deepcopy(result["execution_report"])
        if damage == "strip_report":
            del report["native_first_replay"]
        elif damage == "fit_completed":
            report["execution_report"] = report["first_audit_execution_report"]
        elif damage == "new_chain":
            report["native_first_replay"]["new_mice_chains"] = 1
        elif damage == "float_replay":
            report["native_first_replay"]["new_native_replay_invocations"] = 1.0
        elif damage == "native_pin":
            report["numerical_view"]["native_archive"]["sha256"] = "0" * 64
        elif damage == "relabel":
            report["executor_source_identity"] = "c" * 64
        elif damage == "release":
            report["resource_release"]["reader_scan_status"] = "UNKNOWN"
        elif damage in {"release_other", "release_missing_native", "release_size"}:
            files = report["resource_release"]["files"]
            path = str(case["coordinate"] / "input.zip.native-work/native-view.zip")
            old_native = next(row for row in files if row["path"] == path)
            if damage == "release_other":
                old_native["path"] = "/root/autodl-tmp/UNFITTED_OTHER_COORDINATE/native-view.zip"
                files.sort(key=lambda row: row["path"])
            elif damage == "release_missing_native":
                files.remove(old_native)
            else:
                old_native["size_bytes"] += 1
            runtime.validate_resource_release(report["resource_release"])
        elif damage == "inactive_extra_member":
            absolute = "/root/autodl-tmp/UNFITTED_OUTSIDE_H0_COORDINATE.rds"
            report["numerical_view"]["members"][absolute] = {"sha256": "d" * 64, "size_bytes": 1}
            extra = {**report["resource_release"]["files"][0], "path": absolute, "size_bytes": 1}
            report["resource_release"]["files"] = sorted([*report["resource_release"]["files"], extra], key=lambda row: row["path"])
            runtime.validate_resource_release(report["resource_release"])
        if damage == "strip_collection":
            del execution["native_first_replay"]
        report_path = root / "numerical.zip.json"
        report_path.write_bytes(canonical_json_bytes(report))
        shutil.copyfile(Path(result["view_result_paths"][0]).with_suffix(""), report_path.with_suffix(""))
        handle = {"name": name, "result_path": result["view_result_paths"][0], "result_sha256": sha256_file(report_path),
            "result_size_bytes": report_path.stat().st_size, "status": "COMPUTED", "stage_acceptance": False}
        members = {"views/" + name + "/numerical.zip": report_path.with_suffix(""),
            "views/" + name + "/numerical.zip.json": report_path,
            "batch/mice-results.json": canonical_json_bytes([handle]), "batch/execution.json": canonical_json_bytes(execution),
            "cli/run.stdout": canonical_json_bytes({**result, "execution_report": execution}), "cli/run.stderr": b""}
        members["cli/run-execution.json"] = canonical_json_bytes({"source_identity": identity, "exit_code": 0,
            "stdout_sha256": sha256_bytes(members["cli/run.stdout"]), "stderr_sha256": sha256_bytes(b""), "view_ids": [name]})
        def pins(entries):
            return {key: {"sha256": sha256_file(item) if isinstance(item, Path) else sha256_bytes(item),
                          "size_bytes": item.stat().st_size if isinstance(item, Path) else len(item)} for key, item in entries.items()}
        collection = {"source_identity": identity,
            "producer_source_identity": "1513ecba963857099c6b99413b8e976393c551a3ec30ed90da1cb14178338bd7",
            "input_sha256": sha256_file(case["source"]), "input_identity_sha256": case["index"]["identity_sha256"],
            "view_ids": [name], "pool": execution["mice_pool"], "members": pins(members),
            **({"native_first_replay": execution["native_first_replay"]} if "native_first_replay" in execution else {})}
        packet = root / "packet.zip"
        write_deterministic_zip(packet, {"collection.json": canonical_json_bytes(collection), **members})
        ref = {"object_key": "UNFITTED/private-h0/" + damage, "sha256": sha256_file(packet), "size_bytes": packet.stat().st_size}
        if not damage.startswith("inactive_"):
            with pytest.raises(ContractError, match="UNFITTED_H0_ORIGINAL_BRANCH_BOUNDARY" if damage == "none" else
                               "F5_A12_(NATIVE_FIRST_REPLAY|RETAINED_PACKET|VIEW_EXECUTOR)|RESOURCE_RELEASE"):
                sensitivity.execute_a12_outer_inputs(case["source"], root / "gather.zip", view_results=[report_path],
                    retained_primary_source_bundle=case["retained"], retained_view_batches=[(packet, ref)])
        binding = {"executor_source_identity": report["executor_source_identity"],
            "original_report": {"sha256": sha256_file(report_path), "size_bytes": report_path.stat().st_size}, "packet_reference": ref,
            **({"native_first_replay": report["native_first_replay"]} if "native_first_replay" in report else {})}
        if damage == "strip_collection":
            del binding["native_first_replay"]
        view_report = {key: item for key, item in report.items() if key != "numerical_view"}
        payload = {"input.zip": case["source"], "views/" + name + ".zip": report_path.with_suffix(""),
            "execution.json": canonical_json_bytes({"view_execution_reports": {name: view_report},
                "retained_view_batches": [{"path": str(packet), **ref}], "retained_view_report_bindings": {name: binding}})}
        index = nested._sealed({"kind": "PADML_F5_A12_OUTER_INPUTS_NATIVE_V2", "outer_fold": 3, "family": "GBM_COX",
            "projected_input_identity_sha256": case["index"]["identity_sha256"], "stage": "MICE_MATERIALIZED_PRE_DEVELOPMENT",
            "branches": {key: {} for key in nested.AAR_ESTIMANDS}, "mice_views": {name: report["numerical_view"]}, "members": pins(payload)})
        archive = root / "native-inputs.zip"
        write_deterministic_zip(archive, {"a12-inputs.json": canonical_json_bytes(index), **payload})
        with pytest.raises(ContractError, match="UNFITTED_H0_ORIGINAL_BRANCH_BOUNDARY" if damage in {"none", "inactive_total"} else
                           "F5_A12_(NATIVE_FIRST_REPLAY|RETAINED_VIEW|VIEW_EXECUTOR)|RESOURCE_RELEASE"):
            sensitivity.materialize_a12_outer_inputs(archive, None, root / "native-reader", input_bundle=case["source"],
                retained_primary_source_bundle=case["retained"], **({"final_task_ids": ["O3_" + nested.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT + "_M01"]}
                    if damage.startswith("inactive_") else {}))
        if damage.startswith("inactive_"):
            assert not (root / "native-reader/input" / case["index"]["mice_inputs"][0]["member"]).exists()


@pytest.mark.parametrize("damage", ["input", "native", "spec", "complete", "copied", "fit", "mixed", "resource", "failure"])
def test_h0_first_replay_no_fit_or_automatic_retry(h0_native_case, tmp_path, monkeypatch, damage):
    case = h0_native_case
    original = case["coordinate"] / "input.zip.native-work"
    if damage in {"input", "native", "spec"}:
        path = case["coordinate"] / {"input": "input.zip", "native": "input.zip.native-work/native-view.zip",
                                      "spec": "input.zip.native-work/spec.json"}[damage]
        path.write_bytes(path.read_bytes() + b"UNFITTED_DRIFT")
    elif damage == "complete":
        path = original / "first-audit/replay/output"
        path.mkdir(parents=True)
        (path / "summary.json").write_bytes(b"UNFITTED_COMPLETE_REPLAY")
    elif damage == "copied":
        source = tmp_path / "copied.zip"
        shutil.copyfile(case["source"], source)
        case = {**case, "source": source}
    elif damage == "fit":
        with pytest.raises(ContractError, match="NATIVE_FIRST_REPLAY_SCOPE_INVALID"):
            sensitivity._run_a12_total_mice_input(case["coordinate"] / "input.zip",
                Path(case["record"]["attempt_root"]) / "native-work/first-audit/replay", native=None,
                retained_primary_source_bundle=case["retained"], native_first_replay=True)
        assert not case["calls"]
        return
    elif damage == "resource":
        monkeypatch.setattr(runtime, "observe_execution_resources", lambda root: {
            "effective_cpus": 64, "available_memory_bytes": 0, "scratch_available_bytes": 10**12, "scratch_root": str(root)})
    elif damage == "failure":
        run = sensitivity._run_a12_total_mice_input
        def failed(*args, **kwargs):
            assert kwargs.get("native") is not None and kwargs.get("native_first_replay") is True
            run(*args, **kwargs)
            raise ContractError("UNFITTED_H0_FIRST_REPLAY_FAILED")
        monkeypatch.setattr(sensitivity, "_run_a12_total_mice_input", failed)
    with pytest.raises(ContractError):
        _execute_h0_first_replay(case, tmp_path / "first-h0-attempt",
            **({"mice_restoration_decision": case["decision"]} if damage == "mixed" else {}))
    assert [row[0] for row in case["calls"]] == (["REPLAY"] if damage == "failure" else [])
    if damage == "failure":
        with pytest.raises(ContractError, match="COORDINATE_ALREADY_STARTED"):
            _execute_h0_first_replay(case, tmp_path / "renamed-failed-attempt")
        assert [row[0] for row in case["calls"]] == ["REPLAY"]


def _execute(case, target, names=None, **options):
    return sensitivity.execute_a12_outer_inputs(case["source"], target,
        view_ids=case["names"] if names is None else names, retained_bytes_per_view=128 * 1024**2,
        retained_primary_source_bundle=case["retained"], mice_restoration_decision=case["decision"], **options)


def test_original_restoration_all_three_whole_m20_and_first_readers(restoration_case, tmp_path, monkeypatch):
    case = restoration_case
    originals = {name: sensitivity._a12_mice_restoration_original_files(unit)
        for name, unit in zip(case["names"], case["authority"]["atomic_units"])}
    result = _execute(case, tmp_path / "batch")
    assert [row[0] for row in case["calls"]] == ["FIT", "REPLAY"] * 3
    assert result["mice_chain_execution_count"] == 60
    assert result["model_fit_count"] == result["selector_path_count"] == 0
    assert result["execution_report"]["completed_mice_fit_invocations"] == 3
    assert result["execution_report"]["completed_mice_chain_count"] == 60
    for name, unit in zip(case["names"], case["authority"]["atomic_units"]):
        assert sensitivity._a12_mice_restoration_original_files(unit) == originals[name]
        attempt = case["coordinate_root"] / name / "restoration-20260913-00-28"
        report = strict_json_bytes((attempt / "numerical.zip.json").read_bytes())
        assert report["mice_restoration"]["original_files"] == originals[name]
        assert report["numerical_view"]["spec"]["chain_seeds"] == unit["chain_seeds"]
        assert len(list((attempt / "native-work/native").glob("*.rds"))) == 20
        assert len(list((attempt / "native-work/first-audit/native").glob("*.rds"))) == 20
        runtime.validate_resource_release(report["resource_release"])
        source = case["coordinate_root"] / name / "input.zip"
        opened = sensitivity.materialize_a12_total_mice_view(source, attempt / "numerical.zip", attempt / "numbers-reader",
            numerical_view=report["numerical_view"], retained_primary_source_bundle=case["retained"], retained_mice_gather=True)
        assert "execution_report" not in opened and opened["numerical_view"] == report["numerical_view"]
    before = list(case["calls"])
    with pytest.raises(ContractError, match="COORDINATE_ALREADY_STARTED"):
        _execute(case, tmp_path / "renamed-batch")
    copied = tmp_path / "copied.zip"
    shutil.copyfile(case["source"], copied)
    with pytest.raises(ContractError, match="COORDINATE_ALREADY_STARTED"):
        _execute({**case, "source": copied}, tmp_path / "new-executor-directory")
    assert case["calls"] == before
    archived = os.environ.get("PADML_RETAINED_AAR_RESTORATION_SOURCE_BUNDLE")
    if archived is not None:
        retained_root = tmp_path / "retained-a1-readers"
        retained_root.mkdir()
        _exercise_returned_restoration_readers(case, retained_root, monkeypatch, result,
            retained_view_source_bundle=Path(archived))


def _exercise_returned_restoration_readers(case, tmp_path, monkeypatch, result, *, retained_view_source_bundle=None):
    """Reopen actual returned views; only the later branch merger is a sentinel."""
    reports = {name: strict_json_bytes(Path(path).read_bytes())
               for name, path in zip(result["view_ids"], result["view_result_paths"])}
    before = list(case["calls"])
    def boundary(*args, **kwargs):
        raise ContractError("UNFITTED_PAIRED_READER_BOUNDARY_REACHED")
    monkeypatch.setattr(sensitivity, "_materialize_a12_projected_branches", boundary)
    identity = sha256_bytes(canonical_json_bytes(f4._f45_source_member_sha256()))
    options = {}
    if retained_view_source_bundle is not None:
        identity = "a1fabe4424b844025db0449126d60dd81dded09a88cd15e2cd7e78b0c154fa9b"
        options["retained_view_source_bundle"] = retained_view_source_bundle
        for report in reports.values():
            report["executor_source_identity"] = identity
    for damage in ("none", "strip_report", "float_unit", "strip_collection", "missing_source", "relabel"):
        if damage in {"missing_source", "relabel"} and retained_view_source_bundle is None:
            continue
        root = tmp_path / ("returned-" + damage)
        root.mkdir()
        changed = copy.deepcopy(reports)
        first = result["view_ids"][0]
        if damage == "strip_report":
            del changed[first]["mice_restoration"]
        elif damage == "float_unit":
            changed[first]["mice_restoration"]["unit"]["mice_chains_maximum"] = 20.0
        elif damage == "relabel":
            changed[first]["executor_source_identity"] = sha256_bytes(canonical_json_bytes(f4._f45_source_member_sha256()))
        paths, members, handles = [], {}, []
        for name in result["view_ids"]:
            destination = root / "views" / name
            destination.mkdir(parents=True)
            original = Path(reports[name]["mice_restoration"]["attempt_root"]) / "numerical.zip"
            shutil.copyfile(original, destination / "numerical.zip")
            report_path = destination / "numerical.zip.json"
            report_path.write_bytes(canonical_json_bytes(changed[name]))
            paths.append(report_path)
            for suffix in ("", ".json"):
                members["views/" + name + "/numerical.zip" + suffix] = destination / ("numerical.zip" + suffix)
            handles.append({"name": name, "result_path": str(original) + ".json", "result_sha256": sha256_file(report_path),
                "result_size_bytes": report_path.stat().st_size, "status": "COMPUTED", "stage_acceptance": False})
        execution = copy.deepcopy(result["execution_report"])
        if damage == "float_unit":
            execution["mice_restoration"][first] = changed[first]["mice_restoration"]
        if damage == "strip_collection":
            del execution["mice_restoration"]
        output = {**result, "execution_report": execution}
        members.update({"batch/mice-results.json": canonical_json_bytes(handles),
                        "batch/execution.json": canonical_json_bytes(execution),
                        "cli/run.stdout": canonical_json_bytes(output), "cli/run.stderr": b""})
        members["cli/run-execution.json"] = canonical_json_bytes({"source_identity": identity, "exit_code": 0,
            "stdout_sha256": sha256_bytes(members["cli/run.stdout"]), "stderr_sha256": sha256_bytes(b""),
            "view_ids": result["view_ids"]})
        collection = {"source_identity": identity,
            "producer_source_identity": "1513ecba963857099c6b99413b8e976393c551a3ec30ed90da1cb14178338bd7",
            "input_sha256": sha256_file(case["source"]), "input_identity_sha256": case["index"]["identity_sha256"],
            "view_ids": result["view_ids"], "pool": execution["mice_pool"],
            **({"mice_restoration": execution["mice_restoration"]} if "mice_restoration" in execution else {}),
            "members": {name: {"sha256": sha256_file(item) if isinstance(item, Path) else sha256_bytes(item),
                               "size_bytes": item.stat().st_size if isinstance(item, Path) else len(item)}
                        for name, item in members.items()}}
        packet = root / "packet.zip"
        write_deterministic_zip(packet, {"collection.json": canonical_json_bytes(collection), **members})
        ref = {"object_key": "UNFITTED/private-return/" + damage, "sha256": sha256_file(packet),
               "size_bytes": packet.stat().st_size}
        if damage == "none":
            valid_ref = ref
        with pytest.raises(ContractError, match="UNFITTED_PAIRED_READER_BOUNDARY_REACHED" if damage == "none"
                           else "F5_A12_(MICE_RESTORATION|RETAINED_PACKET|VIEW_EXECUTOR)"):
            sensitivity.execute_a12_outer_inputs(case["source"], root / "gather.zip", view_results=paths,
                retained_primary_source_bundle=case["retained"], retained_view_batches=[(packet, ref)],
                **({} if damage == "missing_source" else options))
    # The original NativeV2 input reader must consume the same recovery record,
    # even if all view payload bytes and the resealed container are otherwise valid.
    for damage in ("none", "stripped", "pin", "binding_stripped", "relabel_both", "release_stripped"):
        root = tmp_path / ("materializer-" + damage)
        root.mkdir()
        view_reports = {name: {key: item for key, item in report.items() if key != "numerical_view"}
                        for name, report in reports.items()}
        first = result["view_ids"][0]
        if damage == "stripped":
            del view_reports[first]["mice_restoration"]
        elif damage == "pin":
            view_reports[first]["sha256"] = "0" * 64
        bindings = {name: {"executor_source_identity": identity,
            "original_report": {"sha256": sha256_bytes(canonical_json_bytes(report)), "size_bytes": len(canonical_json_bytes(report))},
            "packet_reference": valid_ref,
            **({"retained_source_bundle": {"sha256": sha256_file(retained_view_source_bundle),
                "size_bytes": retained_view_source_bundle.stat().st_size,
                "manifest_identity_sha256": f4.load_f45_source_bundle(retained_view_source_bundle)["identity_sha256"]}}
               if retained_view_source_bundle is not None else {})} for name, report in reports.items()}
        if damage == "relabel_both":
            view_reports[first]["executor_source_identity"] = "c" * 64
            bindings[first]["executor_source_identity"] = "c" * 64
            raw = canonical_json_bytes({**view_reports[first], "numerical_view": reports[first]["numerical_view"]})
            bindings[first]["original_report"] = {"sha256": sha256_bytes(raw), "size_bytes": len(raw)}
        elif damage == "release_stripped":
            del view_reports[first]["resource_release"]
        members = {"input.zip": case["source"], "execution.json": canonical_json_bytes({"view_execution_reports": view_reports,
            "retained_view_batches": [{"path": "UNFITTED/original-packet.zip", **valid_ref}],
            **({"retained_view_report_bindings": bindings} if damage != "binding_stripped" else {})})}
        for name in result["view_ids"]:
            members["views/" + name + ".zip"] = Path(reports[name]["mice_restoration"]["attempt_root"]) / "numerical.zip"
        value = nested._sealed({"kind": "PADML_F5_A12_OUTER_INPUTS_NATIVE_V2", "outer_fold": 3, "family": "GBM_COX",
            "projected_input_identity_sha256": case["index"]["identity_sha256"], "stage": "MICE_MATERIALIZED_PRE_DEVELOPMENT",
            "branches": {name: {} for name in nested.AAR_ESTIMANDS},
            "mice_views": {name: report["numerical_view"] for name, report in reports.items()},
            "members": {name: {"sha256": sha256_file(item) if isinstance(item, Path) else sha256_bytes(item),
                               "size_bytes": item.stat().st_size if isinstance(item, Path) else len(item)}
                        for name, item in members.items()}})
        source = root / "gathered.zip"
        write_deterministic_zip(source, {"a12-inputs.json": canonical_json_bytes(value), **members})
        with pytest.raises(ContractError, match="UNFITTED_PAIRED_READER_BOUNDARY_REACHED" if damage == "none"
                           else "F5_A12_(MICE_RESTORATION|RETAINED_VIEW)"):
            sensitivity.materialize_a12_outer_inputs(source, None, root / "original-reader", input_bundle=case["source"],
                                                     retained_primary_source_bundle=case["retained"])
    assert case["calls"] == before


@pytest.mark.parametrize("failure", ["FIT", "REPLAY", "release"])
def test_restoration_failure_cannot_restart(restoration_case, tmp_path, monkeypatch, failure):
    case = restoration_case
    original = sensitivity._run_a12_total_mice_input
    def run(*args, **kwargs):
        result = original(*args, **kwargs)
        if failure == ("REPLAY" if kwargs.get("native") is not None else "FIT"):
            raise ContractError("UNFITTED_RESTORATION_FAILURE")
        return result
    monkeypatch.setattr(sensitivity, "_run_a12_total_mice_input", run)
    if failure == "release":
        def release(*args, **kwargs):
            raise ContractError("UNFITTED_RESTORATION_FAILURE")
        monkeypatch.setattr(runtime, "release_step_resources", release)
    name = case["names"][0]
    with pytest.raises(ContractError, match="UNFITTED_RESTORATION_FAILURE"):
        _execute(case, tmp_path / "first", [name])
    before = list(case["calls"])
    attempt = case["coordinate_root"] / name / "restoration-20260913-00-28"
    assert (attempt / "native-work/stdout.txt").is_file()
    with pytest.raises(ContractError, match="COORDINATE_ALREADY_STARTED"):
        _execute(case, tmp_path / "different-version", [name])
    assert case["calls"] == before and len([row for row in before if row[0] == "FIT"]) == 1


@pytest.mark.parametrize("damage", ["input", "spec", "rds", "complete", "seed", "fourth", "copied", "resource"])
def test_restoration_bad_original_or_current_condition_prevents_fit(restoration_case, tmp_path, monkeypatch, damage):
    case = restoration_case
    name = case["names"][0]
    coordinate = case["coordinate_root"] / name
    if damage in {"input", "spec", "rds"}:
        path = coordinate / {"input": "input.zip", "spec": "input.zip.native-work/spec.json",
                             "rds": "input.zip.native-work/native/imp01.rds"}[damage]
        path.write_bytes(path.read_bytes() + b"DRIFT")
    elif damage == "complete":
        (coordinate / "numerical.zip").write_bytes(b"UNFITTED_ALREADY_COMPLETE")
    elif damage == "seed":
        case["decision"] = copy.deepcopy(case["decision"])
        case["decision"]["aar3_mice_view_restoration"]["atomic_units"][0]["chain_seeds"][0] += 1
        case["decision"] = nested._sealed({key: item for key, item in case["decision"].items() if key != "identity_sha256"})
    elif damage == "fourth":
        name = "A12_WITHOUT_AST_ALT_TOTAL/OUTER_ANALYSIS"
    elif damage == "copied":
        copied = tmp_path / "same-bytes-new-source.zip"
        shutil.copyfile(case["source"], copied)
        case = {**case, "source": copied}
    else:
        monkeypatch.setattr(runtime, "observe_execution_resources", lambda root: {
            "effective_cpus": 64, "available_memory_bytes": 0, "scratch_available_bytes": 10**12, "scratch_root": str(root)})
    with pytest.raises(ContractError):
        _execute(case, tmp_path / "never-fit", [name])
    assert not case["calls"] and not (coordinate / "restoration-20260913-00-28").exists()


def test_restoration_competing_batches_cannot_both_claim_view(restoration_case, tmp_path):
    case = restoration_case
    def contender(index):
        try:
            _execute(case, tmp_path / f"batch-{index}", case["names"][:1])
            return "COMPUTED"
        except (ContractError, FileExistsError):
            return "EXCLUDED"
    with ThreadPoolExecutor(max_workers=2) as pool:
        outcomes = list(pool.map(contender, [1, 2]))
    assert sorted(outcomes) == ["COMPUTED", "EXCLUDED"]
    assert [row[0] for row in case["calls"]] == ["FIT", "REPLAY"]


def test_completed_restoration_record_reader_keeps_original_authority(retained_source_bundle, monkeypatch):
    """Code-only provenance and synthetic metadata; no MICE or selector call."""
    base = _unfitted_confirmed_decision(fixed_bootstrap=True)
    authority = nested._aar3_mice_view_restoration_contract()
    decision = nested._sealed({**{key: value for key, value in base.items() if key != "identity_sha256"},
        "twelve_month_development": nested._twelve_month_development_contract(),
        "full0_rsf_tail_restoration": nested._full0_rsf_tail_restoration_contract(),
        "aar3_mice_view_restoration": authority})
    for unit in authority["atomic_units"]:
        record = {"science_decision": decision, "unit": unit,
            "original_files": {"input.zip": unit["original_input"],
                "input.zip.native-work/spec.json": unit["original_spec"],
                **sensitivity._a12_mice_restoration_partial_refs(unit)},
            "attempt_root": str(sensitivity._a12_mice_restoration_coordinate_root(unit)
                                / "restoration-20260913-00-28"),
            "historical_interruption_cause": "UNKNOWN"}
        assert sensitivity._validate_a12_mice_restoration_record(record,
            retained_primary_source_bundle=retained_source_bundle) == unit
        changed = {**record, "unit": copy.deepcopy(unit)}
        changed["unit"]["chain_seeds"][0] += 1
        with pytest.raises(ContractError, match="F5_A12_MICE_RESTORATION_RECORD_INVALID"):
            sensitivity._validate_a12_mice_restoration_record(changed,
                retained_primary_source_bundle=retained_source_bundle)
    current = f4._f45_source_member_sha256()
    monkeypatch.setattr(f4, "_f45_source_member_sha256",
        lambda: {**current, "padml/kernels/f5_a12_mice.R": "0" * 64})
    with pytest.raises(ContractError, match="F5_RETAINED_AAR_MICE_DEPENDENCY_DRIFT"):
        sensitivity._validate_a12_mice_restoration_record(record,
            retained_primary_source_bundle=retained_source_bundle)


@pytest.mark.parametrize("function_name", ["_twelve_month_development_contract", "_full0_rsf_tail_restoration_contract",
                                           "_aar3_mice_view_restoration_contract"])
def test_restoration_pins_every_reachable_authority_body(retained_source_bundle, monkeypatch, function_name):
    name = "padml/nested_loco.py"
    path = Path(f4.__file__).resolve().parent.parent / name
    original = path.read_bytes()
    node = next(row for row in ast.parse(original).body if isinstance(row, ast.FunctionDef) and row.name == function_name)
    lines = original.splitlines(keepends=True)
    changed = b"".join(lines[:node.lineno]) + b'    globals()["_require"] = lambda *args, **kwargs: None\n' + b"".join(lines[node.lineno:])
    current = f4._f45_source_member_sha256()
    read = Path.read_bytes
    monkeypatch.setattr(Path, "read_bytes", lambda target: changed if target == path else read(target))
    monkeypatch.setattr(f4, "_f45_source_member_sha256", lambda: {**current, name: sha256_bytes(changed)})
    with pytest.raises(ContractError, match="F5_RETAINED_AAR_MICE_DEPENDENCY_DRIFT"):
        f4._retained_full0_source_members(retained_source_bundle, aar_primary_context=True, aar_mice_restoration=True)


def test_original_a12_cli_forwards_restoration_decision(tmp_path, monkeypatch, capsys):
    decision = tmp_path / "decision.json"
    decision.write_bytes(canonical_json_bytes({"UNFITTED": "CLI forwarding only"}))
    captured = []
    monkeypatch.setattr(sensitivity, "execute_a12_outer_inputs",
        lambda *args, **kwargs: captured.append((args, kwargs)) or {"status": "UNFITTED"})
    monkeypatch.setattr(sys, "argv", ["padml-f5", "a12-inputs", str(tmp_path / "input.zip"), str(tmp_path / "batch"),
        "--view-ids", "A12_WITHOUT_AST_ALT_TOTAL/INNER_R1_K1_ANALYSIS", "--retained-bytes-per-view", "1",
        "--mice-restoration-science-decision", str(decision), "--retained-primary-source-bundle", str(tmp_path / "old.zip")])
    f5.main()
    assert captured[0][1]["mice_restoration_decision"] == {"UNFITTED": "CLI forwarding only"}
    assert captured[0][1]["view_ids"] == ["A12_WITHOUT_AST_ALT_TOTAL/INNER_R1_K1_ANALYSIS"]
    assert '"UNFITTED"' in capsys.readouterr().out
