"""Synthetic 300-input reuse qualification; original receipts never relabelled."""
import copy
import shutil
from pathlib import Path

import pytest

from padml import f2_kernel, f4, f5, nested_loco as nested, runtime
from padml.bundle import ContractError, canonical_json_bytes, write_deterministic_zip
from test_full0_fixed12_rescore import decision, forbidden
from test_nested_score_replay import build_fixture


def reseal(value):
    return nested._sealed({key: item for key, item in value.items() if key != "identity_sha256"})


def pair(tmp_path, *, old_program=None, new_program=None, family="COX_PH"):
    # Synthetic patients/curves with the original fixed-family task ABIs.
    old, old_root, components, outputs = build_fixture(tmp_path / "old", full_score=True)
    if old_program is not None:
        old["training_context"] = reseal({**old["training_context"],
            "preprocessing_program_sha256": old_program, "modeling_program_sha256": old_program})
        old["development"] = reseal({**old["development"], "training_context": old["training_context"]})
    new_root = tmp_path / "prepared/request"
    new_root.mkdir(parents=True)
    (new_root / "training").mkdir()
    shutil.copyfile(old_root / "training/response.csv", new_root / "training/response.csv")
    spec = ({"family": family, "ties": "breslow"} if family == "COX_PH"
            else {"family": family, "df": [3, 1], "tvc_parent": "AST_ALT"})
    elastic_source = None
    if family == "ELASTIC_NET_COX":
        from test_f5 import _full_test_transform_recipe
        from test_nested_full_development import _unfitted_full_lambda_upper
        transform = _full_test_transform_recipe(f2_kernel.predictor_contract(Path(f5.__file__).parent))
        transform["partition_id"] = "F5_FINAL_FULL_DATA"
        transform["recipe_sha256"] = nested._sha({k: v for k, v in transform.items() if k != "recipe_sha256"})
        ratios = [0.01 * imp for imp in range(1, 21)]
        spec = {"family": family, "alpha": 0.2, "ratio_by_imputation": ratios,
            "lambda_by_imputation": [2 * value for value in ratios],
            "lambda_upper_bound_by_imputation": [_unfitted_full_lambda_upper(transform)] * 20}
        selector = old["development"]["selector_development"]
        elastic_source = {"selector_development_sha256": selector["identity_sha256"],
            "selector_recipe_set_sha256": selector["transform_recipes"]["recipe_set_sha256"],
            "selected_spec": spec, "full_transform_recipe": transform}
    old["development"] = reseal({**old["development"], "locked_specs": {family: spec}})
    new = copy.deepcopy(old)
    new["training_context"] = reseal({**new["training_context"],
        "preprocessing_program_sha256": new_program or "1" * 64, "modeling_program_sha256": new_program or "2" * 64})
    new.update(selection_horizon_months=12, science_decision=decision())
    new["development"] = reseal({**new["development"], "training_context": new["training_context"],
        "selection_horizon_months": 12, "science_decision": new["science_decision"]})
    old_records, new_records, jobs, handles, originals = [], [], [], [], {}
    for old_record in old["component_records"]:
        task, recipe, entries = copy.deepcopy(components[old_record["path"]])
        evidence = copy.deepcopy(outputs[old_record["path"]])
        seed = f4._f4_model_seed(family, task["f4_coordinates"])
        parameters = spec
        if elastic_source is not None:
            parameters, _ = f4._nested_full_elastic_parameters(elastic_source, task["f4_coordinates"])
            task["f4_nested_full_elastic_source"] = elastic_source
        task.update(family=family, parameters=parameters, registered_model_seed=seed,
                    nested_full_score_source=f5._full_score_family_source(old["development"], family))
        path = old_record["path"].replace("FPM_TVC_SET_A", family)
        old_path, new_path = old_root / path, new_root / path
        old_path.parent.mkdir(parents=True, exist_ok=True)
        new_path.parent.mkdir(parents=True, exist_ok=True)
        entries["task.json"] = canonical_json_bytes(task)
        if family == "FPM_TVC_SET_A":
            # Replace only this test builder's non-ZIP placeholder, not evidence.
            old_path.unlink()
        write_deterministic_zip(old_path, entries)
        record = {**old_record, "path": path, "family": family, "registered_model_seed": seed,
            "task_sha256": nested._sha(task), "parameter_sha256": nested._sha(parameters),
            "development_spec_sha256": nested._sha(spec), "sha256": nested.sha256_file(old_path),
            "size_bytes": old_path.stat().st_size}
        target_task = {**task, "nested_full_score_source": f5._full_score_family_source(new["development"], family)}
        write_deterministic_zip(new_path, {**entries, "task.json": canonical_json_bytes(target_task)})
        new_records.append({**record, "sha256": nested.sha256_file(new_path),
            "size_bytes": new_path.stat().st_size, "task_sha256": nested._sha(target_task)})
        prediction = evidence["prediction"]
        prediction["survival"] = {family: prediction["survival"]["FPM_TVC_SET_A"]}
        evidence["receipt"] = reseal({**evidence["receipt"], "family": family, "seed": seed,
            "training_context_sha256": old["training_context"]["identity_sha256"],
            "task_sha256": record["task_sha256"], "parameter_sha256": nested._sha(parameters),
            "prediction_sha256": nested._sha(prediction),
            "input_sha256": nested._sha({name: nested.sha256_bytes(raw) for name, raw in entries.items()})})
        evidence.update(family=family, request_component_path=path, request_component_sha256=record["sha256"])
        evidence = reseal(evidence)
        raw = canonical_json_bytes(evidence)
        evidence_path = tmp_path / "old/score-evidence" / family / (old_path.stem + ".json")
        evidence_path.parent.mkdir(parents=True, exist_ok=True)
        evidence_path.write_bytes(raw)
        originals[evidence_path] = raw
        jobs.append({"source": str(old_path), "source_sha256": record["sha256"],
            "source_size_bytes": record["size_bytes"], "retained_bytes_per_component": 10**6,
            "expanded_bytes_per_component": 10**6,
            "root": str(tmp_path / "old/components/score-native" / family / old_path.stem),
            "scratch_root": str(tmp_path / "old/scratch"), "coordinate_identity": "3" * 64,
            "score_evidence": {"path": str(evidence_path), "record": record,
                "partition_id": evidence["partition_id"],
                "context": {key: old["training_context"][key] for key in ("scope", "identity_sha256", "outer_fold")}}})
        handles.append({"evidence_sha256": nested.sha256_bytes(raw), "evidence_size_bytes": len(raw),
            "archive_sha256": evidence["receipt"]["archive_sha256"]})
        old_records.append(record)
    old["component_records"], new["component_records"] = old_records, new_records
    return reseal(old), reseal(new), new_root, jobs, handles, originals


def reader(old, new, root, jobs, handles):
    return f5._FullScoreArchiveOutputs(old["component_records"], jobs, handles, old["training_context"],
        transported_request=old, prepared_request=new, prepared_request_root=root)


@pytest.mark.parametrize("family", ["COX_PH", "ELASTIC_NET_COX", "FPM_TVC_SET_A"])
def test_complete_pair_retains_original_evidence_and_checks_actual_input_bytes(tmp_path, monkeypatch, family):
    old, new, root, jobs, handles, originals = pair(tmp_path, family=family)
    # Actual ZIP, task ABI, context, record and original numerical checks run.
    # Only native-health/design leaves use the explicitly UNFITTED fixture.
    column_map = f2_kernel._expected_family_parent_column_map
    monkeypatch.setattr(f2_kernel, "_expected_family_parent_column_map", lambda parents, own, predictors, recipe:
        [{"columns": ["AST_ALT", "Age"]}] if recipe.get("fixture") is True
        else column_map(parents, own, predictors, recipe))
    monkeypatch.setattr(f5, "_validate_final_r_fit_health", lambda *a, **k: None)
    monkeypatch.setattr(f5, "_validate_retained_r_audit_numbers", lambda *a, **k: None)
    for name in ("_execute_and_verify_score_archive_job", "_replay_component_job", "_compile_full_score_inputs"):
        monkeypatch.setattr(f5, name, forbidden)
    monkeypatch.setattr(runtime, "_bounded_ordered_spawn", forbidden)
    qualified = reader(old, new, root, jobs, handles)
    for record, original in zip(old["component_records"], originals.values(), strict=True):
        assert canonical_json_bytes(qualified[record["path"]]) == original
    assert all(path.read_bytes() == raw for path, raw in originals.items())

    for damage in ("covariates", "recipe", "seed", "source", "zip_sha",
                   *(("lambda", "full_recipe") if family == "ELASTIC_NET_COX" else ())):
        altered = copy.deepcopy(new)
        record = altered["component_records"][0]
        path = root / record["path"]
        saved = path.read_bytes()
        task, recipe, entries = nested._read_component(path)
        if damage == "covariates":
            entries["fit-covariates.csv"] += b"CHANGED_PATIENT_DATA\n"
        elif damage == "recipe":
            recipe["transform_recipe"]["fixture"] = False
            entries["recipe.json"] = canonical_json_bytes(recipe)
        elif damage == "seed":
            task["registered_model_seed"] += 1
        elif damage == "source":
            task["nested_full_score_source"]["training_context_sha256"] = "9" * 64
        elif damage == "lambda":
            task["parameters"]["lambda"] *= 2
        elif damage == "full_recipe":
            transform = task["f4_nested_full_elastic_source"]["full_transform_recipe"]
            transform["partition_id"] = "INNER_R1_K1"
            transform["recipe_sha256"] = nested._sha({k: v for k, v in transform.items() if k != "recipe_sha256"})
        entries["task.json"] = canonical_json_bytes(task)
        path.unlink()  # Exact synthetic counterexample; never a retained input.
        write_deterministic_zip(path, entries)
        if damage != "zip_sha":
            record.update(sha256=nested.sha256_file(path), size_bytes=path.stat().st_size,
                          task_sha256=nested._sha(task))
        else:
            path.write_bytes(saved + b"ALTERED_ARCHIVE")
        altered = reseal(altered)
        try:
            with pytest.raises(ContractError):
                reader(old, altered, root, jobs, handles)[record["path"]]
        finally:
            path.write_bytes(saved)


@pytest.mark.parametrize("family", ["RSF", "GBM_COX", "XGBOOST_COX", "COXTIME_SET_A"])
def test_fixed_score_pair_never_opens_complex_family_reuse(family):
    with pytest.raises(ContractError, match="COX_REUSE_INPUT_INVALID"):
        f5._full0_cox_reuse_request_pair({"component_records": [{"family": family}] * 300}, {})


@pytest.mark.parametrize("damage", ["missing", "duplicate", "wrong_family", "seed_program", "response", "selector", "decision"])
def test_resealed_pair_metadata_drift_rejected(tmp_path, damage):
    old, new, root, jobs, handles, _ = pair(tmp_path)
    if damage == "missing":
        new["component_records"].pop()
    elif damage == "duplicate":
        new["component_records"][-1] = new["component_records"][0]
    elif damage == "wrong_family":
        new["component_records"][0]["family"] = "FPM_TVC_SET_A"
    elif damage in {"seed_program", "response"}:
        key = "seed_program_sha256" if damage == "seed_program" else "training_response_sha256"
        new["training_context"] = reseal({**new["training_context"], key: "9" * 64})
        new["development"]["training_context"] = new["training_context"]
    elif damage == "selector":
        new["development"]["selector_development"]["selector"]["selected_parents"] = ["Age"]
    else:
        new["science_decision"] = reseal({**new["science_decision"], "twelve_month_development": {}})
        new["development"]["science_decision"] = new["science_decision"]
    new["development"] = reseal(new["development"])
    with pytest.raises(ContractError):
        reader(old, reseal(new), root, jobs, handles)


@pytest.mark.parametrize("common_request", [False, True])
@pytest.mark.parametrize("family", ["COX_PH", "ELASTIC_NET_COX", "FPM_TVC_SET_A"])
def test_original_scorer_and_readback_keep_both_contexts_without_native_replay(tmp_path, monkeypatch, common_request, family):
    old, new, request_root, jobs, handles, originals = pair(tmp_path, family=family)
    if common_request:
        # Other families represent only the common request's coordinate table.
        # Only the parameterized family's actual synthetic ZIPs are consumed.
        new["component_records"] = [{**row, "family": other,
            "path": row["path"].replace(family, other)}
            for other in nested._families() for row in new["component_records"]]
        new = reseal(new)
        assert len(f5._full0_cox_reuse_request_pair(old, new)) == 300
        for damage in ("missing", "duplicate", "path"):
            invalid = copy.deepcopy(new)
            records = invalid["component_records"]
            if damage == "missing": records.pop()
            elif damage == "duplicate": records[-1] = records[-2]
            else: records[-1]["path"] = records[0]["path"]
            with pytest.raises(ContractError):
                f5._full0_cox_reuse_request_pair(old, reseal(invalid))
    root = request_root.parent
    column_map = f2_kernel._expected_family_parent_column_map
    def columns(parents, own_family, predictors, recipe):
        if recipe.get("fixture") is True:
            return [{"columns": ["AST_ALT", "Age"]}]
        return column_map(parents, own_family, predictors, recipe)
    monkeypatch.setattr(f2_kernel, "_expected_family_parent_column_map", columns)
    monkeypatch.setattr(f5, "_validate_final_r_fit_health", lambda *a, **k: None)
    monkeypatch.setattr(f5, "_validate_retained_r_audit_numbers", lambda *a, **k: None)
    for name in ("_execute_and_verify_score_archive_job", "_replay_component_job", "_compile_full_score_inputs"):
        monkeypatch.setattr(f5, name, forbidden)
    monkeypatch.setattr(f4, "_replay_f4_model_component", forbidden)
    monkeypatch.setattr(runtime, "_bounded_ordered_spawn", forbidden)
    qualified = reader(old, new, request_root, jobs, handles)
    score, execution = nested._score_fresh_family(family=family, request=new, root=root,
        outputs=qualified, retained_request=old)
    assert nested.validate_fresh_score_execution(execution) == execution
    assert score["training_context_sha256"] == new["training_context"]["identity_sha256"]
    assert score["selection_horizon_months"] == 12
    assert execution["retained_score_training_context_sha256"] == old["training_context"]["identity_sha256"]
    assert execution["retained_score_request_sha256"] == old["identity_sha256"]
    assert execution["model_fit_count"] == 300
    assert execution["new_model_fit_count"] == execution["new_first_native_audit_count"] == execution["new_native_replay_count"] == 0
    for record, raw in zip(execution["component_evidence_records"], originals.values(), strict=True):
        source = root / "score-evidence" / family / record["path"].split("/")[-1]
        assert source.read_bytes() == raw
        target = root / record["path"]
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
    options = dict(execution=execution, score=score, request=new, request_root=request_root, result_root=root,
        retained_request=old, retained_request_root=tmp_path / "old/request",
        expanded_bytes_per_component=10**6, retained_bytes_per_component=10**6)
    assert nested._recompute_fresh_score_from_evidence(**options) == score
    for change in ({"retained_request": None}, {"retained_request_root": None}, {"replay_models": True}):
        with pytest.raises(ContractError):
            nested._recompute_fresh_score_from_evidence(**{**options, **change})
    for field in ("retained_score_request_sha256", "retained_score_training_context_sha256"):
        bad = reseal({**execution, field: "9" * 64})
        with pytest.raises(ContractError):
            nested._recompute_fresh_score_from_evidence(**{**options, "execution": bad})
    for field in ("new_model_fit_count", "new_first_native_audit_count", "new_native_replay_count"):
        with pytest.raises(ContractError):
            nested.validate_fresh_score_execution(reseal({**execution, field: 1}))
    assert all(path.read_bytes() == raw for path, raw in originals.items())
