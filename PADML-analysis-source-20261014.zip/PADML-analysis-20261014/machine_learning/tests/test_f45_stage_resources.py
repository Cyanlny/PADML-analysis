"""Operational regression checks; no clinical input or model execution."""
import json
import mmap
import os
from pathlib import Path

import pytest

from padml import runtime


def test_shared_inode_requires_every_alias_and_closed_mapping(tmp_path, monkeypatch):
    original_iterdir = Path.iterdir
    # The synthetic files belong solely to this test process. Keep the fd
    # and mmap checks real without coupling a unit test to unrelated ssh PIDs.
    monkeypatch.setattr(Path, "iterdir", lambda p: iter([Path("/proc", str(os.getpid()))])
        if p == Path("/proc") else original_iterdir(p))
    source, alias = tmp_path / "model.bin", tmp_path / "number-copy.bin"
    source.write_bytes(b"UNFITTED" * 4096)
    os.link(source, alias)
    before = source.read_bytes()
    skipped = runtime.release_completed_files([source], owner="TEST", report_root=tmp_path)
    assert not skipped["release"]["files"] and skipped["skipped"]
    with alias.open("rb") as f:
        mapping = mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ)
    try:
        opened = runtime.release_completed_files([source], owner="TEST", report_root=tmp_path,
            alias_roots=[tmp_path])
        assert opened["release"]["files"][0]["status"] == "ACTIVE_READER_OR_WRITER"
    finally:
        mapping.close()
    released = runtime.release_completed_files([source, alias], owner="TEST", report_root=tmp_path,
        alias_roots=[tmp_path])
    assert len(released["release"]["files"]) == 1
    assert released["release"]["files"][0]["status"] == "ADVISED"
    assert source.read_bytes() == alias.read_bytes() == before and source.stat().st_nlink == 2
    assert released["files_deleted"] == 0 and len(released["aliases"]) == 1


def test_alias_outside_owned_roots_is_not_advised(tmp_path, monkeypatch):
    owned = tmp_path / "owned"
    owned.mkdir()
    source = owned / "model"
    source.write_bytes(b"UNFITTED")
    os.link(source, tmp_path / "foreign")
    monkeypatch.setattr(os, "posix_fadvise", lambda *args: pytest.fail("unknown alias"))
    result = runtime.release_completed_files([source], owner="TEST", report_root=owned, alias_roots=[owned])
    assert result["skipped"] and result["release"]["files"] == []


@pytest.mark.parametrize("ended,fail_twice,calls", [(False, False, 1), (True, False, 2), (True, True, 2)])
def test_scan_retries_once_only_for_ended_incarnation(monkeypatch, ended, fail_twice, calls):
    seen = []
    def scan(keys):
        seen.append(keys)
        if len(seen) == 1 or fail_twice:
            error = PermissionError("UNFITTED")
            error.process_incarnation_ended = ended
            raise error
        return set(), 3
    monkeypatch.setattr(runtime, "_scan_visible_open_file_keys", scan)
    if not ended or fail_twice:
        with pytest.raises(PermissionError):
            runtime._visible_open_file_keys({(1, 2)})
    else:
        assert runtime._visible_open_file_keys({(1, 2)}) == (set(), 3)
    assert len(seen) == calls


def test_q_batch_uses_fresh_budget_not_prior_selected_slots(tmp_path, monkeypatch):
    from padml import f5, f2_kernel as k
    root, cache = tmp_path / "q", tmp_path / "cache"
    root.mkdir(); cache.mkdir()
    spec = {"current_q": {"root": str(root), "cache": str(cache), "read_only": False,
        "workers": 24, "resource_policy": {"scratch_bytes_per_worker":0}}}
    calls = [{"task_id": "S3A_" + str(i)} for i in range(10)]
    # Existing atoms need no new fit storage; this test isolates fresh admission.
    for call in calls:
        atom = cache / "atoms" / call["task_id"]
        atom.mkdir(parents=True)
        (atom / "receipt.json").write_text('"UNFITTED_RESOURCE_FIXTURE"')
    f5._CURRENT_Q_STATE[str(root)] = {"coordinates": {}, "references": {}}
    monkeypatch.setattr(f5, "_current_q_reuse_key", lambda spec, fn, call: call["task_id"])
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda p: {})
    monkeypatch.setattr(runtime, "resource_admission", lambda *a, **kw: {"admitted_worker_ceiling": 7})
    monkeypatch.setattr(runtime, "admit_stage", lambda *a, **kw: {"admitted_worker_ceiling": 7})
    counts = []
    def spawn(fn, jobs, *, selected_slots, execution_report):
        counts.append(selected_slots)
        return [{"key": job["key"], "root": str(cache), "value": job["key"]} for job in jobs]
    monkeypatch.setattr(k, "_bounded_ordered_spawn", spawn)
    monkeypatch.setattr(f5, "_current_q_import", lambda root, row, state: row["root"])
    monkeypatch.setattr(f5, "_current_q_row", lambda spec, fn, call, value: value)
    monkeypatch.setattr(runtime, "release_completed_files", lambda *a, **kw: {})
    try:
        result = f5._current_q_task_batch(spec, k._run_xgb_refit_pool_task, calls, selected_slots=2)
        assert counts == [7] and result == [call["task_id"] for call in calls]
    finally:
        f5._CURRENT_Q_STATE.pop(str(root))
