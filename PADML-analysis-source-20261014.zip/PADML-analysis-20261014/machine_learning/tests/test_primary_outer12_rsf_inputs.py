"""Synthetic checks for the original PRIMARY RSF S1 seven-slot transport."""
import copy

import pytest

from padml import f2_kernel as kernel, f5
from padml.bundle import ContractError, canonical_json_bytes, sha256_bytes
from test_primary_outer12_rsf_native import _spec


def _call(tmp_path, outer=1):
    spec = _spec(tmp_path, outer)
    tasks = spec.pop("producer_tasks")
    spec.pop("registered_partitions")
    data = b"Patient_ID,X\nTRAIN,1\nINNER_EVAL,2\n"
    fit = b"Patient_ID,All_Cause_Death,Death_Followup_months\nTRAIN,1,30\n"
    evaluation = b"Patient_ID,All_Cause_Death,Death_Followup_months\nINNER_EVAL,0,36\n"
    directory = tmp_path / "covariates"
    directory.mkdir()
    (directory / "imp01.csv").write_bytes(data)
    members = [{"name": f"imp{imp:02d}.csv", "sha256": sha256_bytes(data), "size_bytes": len(data)}
               for imp in range(1, 21)]
    covariates = {"input_dir": str(directory), "members": members, "data_identity": sha256_bytes(canonical_json_bytes(members))}
    row = {"kind": "INNER", "partition_id": f"INNER_F{outer}_R1_K1", "repeat": 1, "inner_fold": 1,
        "fit_ids": ["TRAIN"], "evaluation_ids": ["INNER_EVAL"], "application_ids": ["TRAIN", "INNER_EVAL"],
        "evaluation_ids_sha256": sha256_bytes(canonical_json_bytes(["INNER_EVAL"])),
        "covariates": covariates,
        "fit_response": {"private_bytes": fit, "sha256": sha256_bytes(fit), "size_bytes": len(fit)},
        "evaluation_response": {"private_bytes": evaluation, "sha256": sha256_bytes(evaluation), "size_bytes": len(evaluation)}}
    registered = {"schema_version": "1.0.0", "kind": "PADML_F2_REGISTERED_PARTITION_INPUTS", "status": "PASS",
        "fold": outer, "outer_count": 1, "inner_count": 15, "stop_count": 15, "diagnostic_count": 5,
        "view_count": 62, "partitions": [row], "diagnostic_partitions": [], "identity": "c" * 64}
    engine = kernel._engine_registered_partitions(registered, {row["partition_id"]})
    # Deliberately preserve the original aliases across engine/evaluation views.
    assert engine["partitions"][0]["covariates"] is row["covariates"]
    assert engine["partitions"][0]["fit_response"] is row["fit_response"]
    return (spec, engine, tasks, str(tmp_path / "work"), str(tmp_path), "IBS", row)


def test_primary_rsf_original_56_atom_order_and_zero_predecessors():
    phase, names = f5._a12_q_stop_phase("S1", refit=True, family="RSF")
    groups = [[f"S1_T{trial:03d}_P{part:02d}_M01" for trial in (first, first + 1)]
              for first in range(1, 25, 2) for part in range(1, 6)]
    assert names == ["batch-" + sha256_bytes(canonical_json_bytes(group))[:24] for group in groups]
    assert len(names) == len(set(names)) == 60
    assert len({task for group in groups for task in group}) == 120
    assert phase == "_run_r_prediction_pool_task-74f61cb0d62e4ff7d362509d"
    assert f5._a12_q_prepared_predecessors("S1", refit=True, family="RSF") == {"total": 0, "stop": 0}
    with pytest.raises(ContractError):
        f5._a12_q_stop_phase("S1", family="RSF")
    with pytest.raises(ContractError):
        f5._a12_q_stop_phase("UNREGISTERED", refit=True, family="RSF")


def test_primary_rsf_seven_slot_alias_safe_round_trip(tmp_path):
    call = _call(tmp_path)
    original = copy.deepcopy(call)
    files = {}
    value = f5._a12_q_stop_unit_input(call, files=files)
    assert call == original
    assert set(files) == {"data/INNER_F1_R1_K1/" + name for name in
        ("imp01.csv", "fit_response.csv", "evaluation_response.csv")}
    assert len(value) == 7 and value[3:6] == ["work", ".", "IBS"]
    assert value[0]["primary_search_source"] == call[0]["primary_search_source"]
    assert value[0]["horizons"] == list(range(1, 37)) and value[0]["selection_horizon_months"] == 12
    assert value[2] == call[2]
    assert len(value[1]["partitions"][0]["covariates"]["members"]) == 20
    assert not kernel._contains_key(value[1], "evaluation_response")
    assert not kernel._contains_key(value, "private_bytes")
    assert value[6]["evaluation_response"]["path"] == "data/INNER_F1_R1_K1/evaluation_response.csv"
    assert "retained_a12_primary_context_source_bundle" not in value[0]
    assert canonical_json_bytes(f5._a12_q_stop_unit_input(value)) == canonical_json_bytes(value)


@pytest.mark.parametrize("damage", ["half", "reverse", "duplicate", "four", "partition", "imputation",
    "suffix", "producer-kind", "recipe", "seed", "source", "response-leak", "file-conflict"])
def test_primary_rsf_scoped_transport_rejects_invalid_call(tmp_path, damage):
    call = list(_call(tmp_path))
    if damage == "half": call[2].pop()
    elif damage == "reverse": call[2].reverse()
    elif damage == "duplicate": call[2][1] = copy.deepcopy(call[2][0])
    elif damage == "four": call[2].extend(copy.deepcopy(call[2]))
    elif damage == "partition": call[2][1]["partition_id"] = "INNER_F1_R1_K2"
    elif damage == "imputation": call[2][0]["imputation"] = 2
    elif damage == "suffix": call[2][0]["task_id"] += "_REFIT"
    elif damage == "producer-kind": call[2][0]["producer_kind"] = "SURVIVAL"
    elif damage == "recipe": call[2][0]["transform_recipe"] = {}
    elif damage == "seed": call[2][0]["seed"] += 1
    elif damage == "source": del call[0]["primary_search_source"]
    elif damage == "response-leak": call[1]["partitions"][0]["evaluation_response"] = call[6]["evaluation_response"]
    else:
        call[6] = copy.deepcopy(call[6])
        raw = b"CONFLICTING_SYNTHETIC_RESPONSE"
        call[6]["fit_response"] = {"private_bytes": raw, "sha256": sha256_bytes(raw), "size_bytes": len(raw)}
    with pytest.raises(ContractError):
        f5._a12_q_stop_unit_input(call, files={})
