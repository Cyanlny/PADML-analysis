"""Same-run AAR reuse: real readers, synthetic data and UNFITTED R leaves."""
import copy
from pathlib import Path

import pytest

from padml import f5_sensitivity as a, nested_loco as n, worker
from padml.bundle import ContractError, canonical_json_bytes, sha256_bytes, sha256_file, strict_json_bytes, write_deterministic_zip
import test_nested_aar_mice as original


@pytest.fixture
def inputs(monkeypatch):
    # The old fixture's two-line decision is retired; use the current science
    # contract with its existing explicitly synthetic raw rows/model leaves.
    science = strict_json_bytes((Path(a.__file__).parents[1] / "science-decision.json").read_bytes())
    monkeypatch.setattr(original, "_unfitted_confirmed_decision", lambda: science)
    return original.aar_source.__wrapped__(monkeypatch)


def _horizon(source, h, family=None):
    source = copy.deepcopy(source)
    lock = source["primary_development_lock"]
    lock["selection_horizon_months"] = h
    lock["science_decision_binding"]["selection_horizon_months"] = h
    if family is not None:
        lock["selected_family"] = family
        lock["selected_spec"]["family"] = family
        lock["selected_spec_sha256"] = n._sha(lock["selected_spec"])
    source["primary_development_lock"] = n._sealed({k: v for k, v in lock.items() if k != "identity_sha256"})
    n.validate_development_lock(source["primary_development_lock"],
        context=source["primary_training_context"], science_decision=source["science_decision"])
    return source


def _view(inputs, path, *, h=24, family=None, branch=n.A12_TOTAL_AAR, role="ANALYSIS"):
    contract, raw, response, source, policy = inputs
    source = _horizon(source, h, family)
    write_deterministic_zip(path, a._a12_total_mice_input_members(contract, raw, response, 1,
        "OUTER_" + role, nested_source={**source, "estimand": branch}, resource_policy=policy))
    return path


def _pin(path):
    return {"sha256": sha256_file(path), "size_bytes": path.stat().st_size}


def test_mice_key_excludes_only_non_numerical_line_binding(inputs, tmp_path):
    producer = _view(inputs, tmp_path / "producer.zip")
    consumer = _view(inputs, tmp_path / "consumer.zip", h=6, family="COX_PH")
    key = a._a12_mice_reuse_identity(producer)
    assert key == a._a12_mice_reuse_identity(consumer)
    assert producer.read_bytes() != consumer.read_bytes()
    assert key != a._a12_mice_reuse_identity(_view(inputs, tmp_path / "branch.zip",
        branch=n.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT))
    assert key != a._a12_mice_reuse_identity(_view(inputs, tmp_path / "role.zip", role="APPLICATION"))
    entries = a.read_safe_zip(producer)
    for damage in ("seed", "raw", "order", "outer", "response"):
        changed = dict(entries)
        meta = strict_json_bytes(changed["input.json"])
        if damage == "seed":
            meta["chain_seeds"] = [seed + 1000 for seed in meta["chain_seeds"]]
        elif damage == "raw":
            rows = changed["covariates.csv"].splitlines(keepends=True)
            fields = rows[0].decode().strip().split(",")
            values = rows[1].decode().strip().split(",")
            values[fields.index("Age")] = "70"
            rows[1] = (",".join(values) + "\n").encode()
            changed["covariates.csv"] = b"".join(rows)
        elif damage == "order":
            meta["view"]["row_ids"].reverse()
            meta["view"]["row_ids_sha256"] = n._sha(meta["view"]["row_ids"])
        elif damage == "outer":
            meta["view"]["outer_fold"] = 2
        else:
            changed["response.csv"] += b"UNFITTED_HELDOUT,1,20\n"
        changed["input.json"] = canonical_json_bytes(meta)
        path = tmp_path / (damage + ".zip")
        write_deterministic_zip(path, changed)
        if damage in {"seed", "raw"}:
            assert a._a12_mice_reuse_identity(path) != key
        else:
            with pytest.raises(ContractError):
                a._a12_mice_reuse_identity(path)


def test_reused_view_keeps_producer_and_first_audit_without_r_calls(inputs, tmp_path, monkeypatch):
    producer = _view(inputs, tmp_path / "producer.zip")
    consumer = _view(inputs, tmp_path / "consumer.zip", h=6)
    calls, _ = original._unfitted_outer_mice_workers(monkeypatch)
    payload = tmp_path / "numbers.zip"
    result = a.execute_a12_total_mice_bundle(producer, payload,
        numerical_output=True, retained_bytes_limit=128 * 1024**2)
    assert [item[0] for item in calls] == ["FIT", "REPLAY"]
    before = {path: path.read_bytes() for path in (producer, payload, payload.with_name(payload.name + ".json"))}
    monkeypatch.setattr(a, "_run_a12_total_mice_input", lambda *a, **k: pytest.fail("NO_NEW_MICE_OR_AUDIT"))
    whole = {"unit_id": "AAR-H24-O1", "run_identity": "c" * 64, "status": "COMPLETED",
        "direct_consumer_completed": True, "selection_horizon_months": 24, "report_horizons_months": [6, 12, 24, 36],
        "artifacts": {"result.zip": {"sha256": "d" * 64, "size_bytes": 123}}}
    record = {"whole_unit": whole, "result_archive": whole["artifacts"]["result.zip"],
        "mice_archive": {"sha256": "e" * 64, "size_bytes": 456}, "view_archive": _pin(payload),
        "producer_input": _pin(producer), "consumer_input": _pin(consumer),
        "numerical_identity_sha256": a._a12_mice_reuse_identity(producer)}
    original_input = a._a12_reused_mice_input(consumer, payload, record, tmp_path / "original-input.zip")
    read = a.materialize_a12_total_mice_view(original_input, payload, tmp_path / "read",
        numerical_view=result["numerical_view"])
    assert read["numerical_view"] == result["numerical_view"]
    assert read["numerical_view"]["spec"]["nested_aar_source"]["primary_development_lock"]["selection_horizon_months"] == 24
    assert all(path.read_bytes() == raw for path, raw in before.items())
    assert original_input.read_bytes() == producer.read_bytes()
    for name, mutate in {
        "incomplete": lambda r: r["whole_unit"].update(direct_consumer_completed=False),
        "producer": lambda r: r["producer_input"].update(sha256="f" * 64),
        "consumer": lambda r: r["consumer_input"].update(sha256="f" * 64),
        "key": lambda r: r.update(numerical_identity_sha256="f" * 64),
    }.items():
        damaged = copy.deepcopy(record)
        mutate(damaged)
        with pytest.raises(ContractError):
            a._a12_reused_mice_input(consumer, payload, damaged, tmp_path / (name + ".zip"))


def test_worker_only_offers_completed_same_run_same_outer_units(tmp_path, monkeypatch):
    from padml import run as r
    monkeypatch.setattr(r, "f45_unit_predecessors", lambda run: [])
    run = {"identity": "a" * 64, "run_root": str(tmp_path), "units": r.f45_units(),
        "science_decision": n.science_decision_template(6)}
    current = next(u for u in run["units"] if u["unit_id"] == "AAR-H12-O1")
    root = tmp_path / "units/AAR-H06-O1"
    root.mkdir(parents=True)
    for name in ("input.zip", "input.compile.json", "result.zip"):
        (root / name).write_bytes(b"UNFITTED_COMPLETED_WHOLE_STUB")
    assert worker._f45_aar_reuse_candidates(run, current) == []
    receipt = {"status": "COMPLETED", "direct_consumer_completed": True,
        "unit_id": root.name, "selection_horizon_months": 6, "report_horizons_months": [6, 12, 24, 36],
        "run_identity": run["identity"], "artifacts": {p.name: _pin(p) for p in root.iterdir()}}
    (root / "unit.json").write_bytes(canonical_json_bytes(receipt))
    assert worker._f45_aar_reuse_candidates(run, current) == [{"root": str(root), "receipt": receipt}]
    report = root / "padml-a12-outer-replay-original/execution.json"
    report.parent.mkdir()
    report.write_bytes(b"UNFITTED_ORIGINAL_REPORT")
    receipt["artifacts"][str(report.relative_to(root))] = _pin(report)
    (root / "unit.json").write_bytes(canonical_json_bytes(receipt))
    assert worker._f45_aar_reuse_candidates(run, current) == [{"root": str(root), "receipt": receipt}]
    report.write_bytes(b"CHANGED_ORIGINAL_REPORT")
    with pytest.raises(ContractError, match="REUSE_ARTIFACT_DRIFT"):
        worker._f45_aar_reuse_candidates(run, current)
    report.write_bytes(b"UNFITTED_ORIGINAL_REPORT")
    receipt["artifacts"]["arbitrary/extra.json"] = receipt["artifacts"].pop(str(report.relative_to(root)))
    (root / "unit.json").write_bytes(canonical_json_bytes(receipt))
    with pytest.raises(ContractError, match="WHOLE_ARTIFACTS_INVALID"):
        worker._f45_aar_reuse_candidates(run, current)
    receipt["artifacts"][str(report.relative_to(root))] = receipt["artifacts"].pop("arbitrary/extra.json")
    receipt["run_identity"] = "b" * 64
    (root / "unit.json").write_bytes(canonical_json_bytes(receipt))
    with pytest.raises(ContractError, match="REUSE_WHOLE_REQUIRED"):
        worker._f45_aar_reuse_candidates(run, current)


@pytest.mark.parametrize("missing", [False, True])
def test_whole_input_owner_reuses_intersection_and_native_consumer_reads_it(inputs, tmp_path, monkeypatch, missing):
    primary, result, policy, _, _, _ = original._projected_outer_fixture(inputs, tmp_path, monkeypatch, "COX_PH")
    source = tmp_path / "producer-input.zip"
    a.compile_a12_outer_inputs(primary, result, source, f2_run_root=tmp_path, outer_fold=1, resource_policy=policy)
    calls, pools = original._unfitted_outer_mice_workers(monkeypatch)
    mice = tmp_path / "producer-mice.zip"
    a.execute_a12_outer_inputs(source, mice, retained_bytes_per_view=128 * 1024**2)
    # This is only an UNFITTED whole-receipt boundary fixture. The native MICE
    # owner/readers run; no clinical whole result or model is manufactured.
    producer = tmp_path / "AAR-H24-O1"
    producer.mkdir()
    projected = a.read_safe_zip(source)
    header = strict_json_bytes(projected["a12-inputs.json"])
    outer = n._sealed({"kind": "PADML_F5_A12_OUTER_NATIVE_V2", "outer_fold": 1,
        "source": header, "members": {"inputs.zip": _pin(mice)}})
    write_deterministic_zip(producer / "result.zip", {"a12-outer.json": canonical_json_bytes(outer), "inputs.zip": mice},
        stored_members={"inputs.zip"})
    receipt = {"status": "COMPLETED", "direct_consumer_completed": True,
        "unit_id": producer.name, "run_identity": "c" * 64, "selection_horizon_months": 24,
        "report_horizons_months": [6, 12, 24, 36], "artifacts": {"result.zip": _pin(producer / "result.zip")}}
    (producer / "unit.json").write_bytes(canonical_json_bytes(receipt))
    original_header = copy.deepcopy(header)
    header["primary_source"] = _horizon(header["primary_source"], 6)
    changed_view = header["mice_inputs"][0]
    for row in header["mice_inputs"]:
        member = row["member"]
        entries = a.read_safe_zip(projected[member])
        value = strict_json_bytes(entries["input.json"])
        value["nested_source"] = {**header["primary_source"], "estimand": row["estimand"]}
        if missing and row == changed_view:
            value["chain_seeds"] = [seed + 1000 for seed in value["chain_seeds"]]
        entries["input.json"] = canonical_json_bytes(value)
        path = tmp_path / (str(len(projected[member])) + "-" + row["estimand"] + "-" + row["view_id"] + ".zip")
        write_deterministic_zip(path, entries)
        projected[member] = path.read_bytes()
        header["members"][member] = _pin(path)
    header = n._sealed({k: v for k, v in header.items() if k != "identity_sha256"})
    projected["a12-inputs.json"] = canonical_json_bytes(header)
    consumer = tmp_path / "consumer-input.zip"
    write_deterministic_zip(consumer, projected, stored_members={name for name in projected if name.endswith(".zip")})
    before_calls, before_pools = len(calls), len(pools)
    target = tmp_path / "consumer-mice.zip"
    produced = a.execute_a12_outer_inputs(consumer, target, retained_bytes_per_view=128 * 1024**2,
        completed_aar_units=[{"root": str(producer), "receipt": receipt}])
    logical = len(header["mice_inputs"])
    assert logical == 34
    assert produced["mice_chain_execution_count"] == 20 * int(missing)
    assert produced["mice_reuse"]["reused_chain_count"] == 20 * (logical - int(missing))
    assert len(calls) == before_calls + 2 * int(missing)
    assert len(pools) == before_pools + int(missing)
    if missing:
        assert pools[-1][1] == [changed_view["estimand"] + "/" + changed_view["view_id"]]
    monkeypatch.setattr(a, "_run_a12_total_mice_input", lambda *a, **k: pytest.fail("NO_NEW_MICE_OR_AUDIT"))
    reopened = a.materialize_a12_outer_inputs(target, None, tmp_path / "readback", input_bundle=consumer)
    assert reopened["source"]["primary_source"] == header["primary_source"]
    assert len(reopened["mice_views"]) == logical
    for name, numbers in reopened["mice_views"].items():
        own = missing and name == changed_view["estimand"] + "/" + changed_view["view_id"]
        assert numbers["spec"]["nested_aar_source"]["primary_development_lock"] == (
            header if own else original_header)["primary_source"]["primary_development_lock"]
    index = strict_json_bytes(a.read_safe_zip(target)["a12-inputs.json"])
    assert all(name.split("/", 1)[0] != n.A12_DIRECT_AAR for name in index["mice_reuse"])
    assert produced["mice_reuse"]["resumed_chain_count"] == 0


def test_selector_reuse_keeps_original_development_and_reads_current_m20(tmp_path, monkeypatch):
    from types import SimpleNamespace
    from padml import f4, f5
    science = strict_json_bytes((Path(a.__file__).parents[1] / "science-decision.json").read_bytes())
    monkeypatch.setattr(original, "_unfitted_confirmed_decision", lambda: science)
    prepared = original.unfitted_selector_shard_inputs.__wrapped__(
        tmp_path, monkeypatch, SimpleNamespace(param="COX_PH"))
    calls = original.unfitted_selector_engines.__wrapped__(monkeypatch)
    original_root = tmp_path / "original-selector"
    first = a._a12_no_aar_selector_program(prepared, original_root, replay=False)
    members = {"development/selector/" + name: path
        for name, path in f5._nested_selector_numerical_members(original_root).items()}
    producer = tmp_path / "AAR-H24-O1"
    producer.mkdir()
    header = n._sealed({"kind": "PADML_F5_A12_OUTER_NATIVE_V2", "outer_fold": 1,
        "source": prepared["source"], "members": {name: _pin(path) for name, path in members.items()}})
    # A synthetic whole-unit boundary; all selector numerical readers are real.
    write_deterministic_zip(producer / "result.zip", {"a12-outer.json": canonical_json_bytes(header), **members})
    receipt = {"status": "COMPLETED", "direct_consumer_completed": True,
        "unit_id": producer.name, "run_identity": "c" * 64, "selection_horizon_months": 24,
        "report_horizons_months": [6, 12, 24, 36], "artifacts": {"result.zip": _pin(producer / "result.zip")}}
    (producer / "unit.json").write_bytes(canonical_json_bytes(receipt))
    current = copy.deepcopy(prepared)
    source = current["source"]
    source["primary_source"] = _horizon(source["primary_source"], 6)
    current["source"] = n._sealed({k: v for k, v in source.items() if k != "identity_sha256"})
    current["completed_aar_units"] = [{"root": str(producer), "receipt": receipt}]
    before = {name: path.read_bytes() for name, path in members.items()}
    assert calls == {"recipe": 16, "path": 640, "replay": 0}
    def forbidden(*args, **kwargs):
        pytest.fail("NO_NEW_SELECTOR_PATH_RECIPE_OR_NATIVE_AUDIT")
    monkeypatch.setattr(f4.subprocess, "run", forbidden)
    monkeypatch.setattr(f4, "_run_learning_selector_path", forbidden)
    monkeypatch.setattr(f4, "_consume_learning_selector_path", forbidden)
    root = tmp_path / "reused-selector"
    second = a._a12_no_aar_selector_program(current, root, replay=False)
    assert second == first
    assert {name: path.read_bytes() for name, path in members.items()} == before
    assert (root / "development-input.json").read_bytes() == (original_root / "development-input.json").read_bytes()
    record = strict_json_bytes((root / "reuse.json").read_bytes())
    assert record["consumer_source"]["primary_development_lock_sha256"] != first["source"]["primary_development_lock_sha256"]
    assert record["execution"] == {"logical_selector_paths": first["selector_path_count"],
        "reused_selector_paths": first["selector_path_count"],
        "new_selector_paths": 0, "new_glmnet_calls": 0, "new_recipe_fits": 0}
    assert a._a12_no_aar_selector_program(current, root, replay=True) == first
    assert calls == {"recipe": 16, "path": 640, "replay": 0}
    # Accounting only: these marked fixture members are not scientific fits.
    count_mice = tmp_path / "UNFITTED-count-mice.zip"
    write_deterministic_zip(count_mice, {"a12-inputs.json": canonical_json_bytes({
        "mice_reuse": {str(i): {} for i in range(len(current["source"]["mice_inputs"]))}})})
    count_members = {"inputs.zip": count_mice,
        "development/selector/development-input.json": root / "development-input.json",
        "development/selector/reuse.json": root / "reuse.json",
        **{f"fits/O1_{branch}_M{i:02d}.numbers.json": b'{"UNFITTED":true}'
           for branch in n.AAR_ESTIMANDS for i in range(1, 21)}}
    count_zip = tmp_path / "UNFITTED-count-whole.zip"
    write_deterministic_zip(count_zip, count_members)
    counted = a._a12_outer_archive_record({"family": "COX_PH", "outer_fold": 1,
        "identity_sha256": "a" * 64, "source": current["source"], "members": count_members}, count_zip)
    assert counted["execution_ledger"]["mice_chains"] == 0
    assert counted["execution_ledger"]["elastic_path_executions"] == 0
    assert counted["execution_ledger"]["glmnet_pilot_and_path_calls"] == 0
    assert counted["execution_ledger"]["post_lock_fits"] == 60
    assert counted["logical_execution_ledger"]["elastic_path_executions"] == first["selector_path_count"]
    for field in ("consumer_source", "members"):
        damaged = copy.deepcopy(record)
        if field == "consumer_source":
            damaged[field]["primary_development_lock_sha256"] = "f" * 64
        else:
            damaged[field]["partitions.json"]["sha256"] = "f" * 64
        (root / "reuse.json").write_bytes(canonical_json_bytes(damaged))
        with pytest.raises(ContractError, match="REUSE_DEPENDENCY_DRIFT"):
            a._a12_no_aar_selector_program(current, root, replay=True)
    (root / "reuse.json").write_bytes(canonical_json_bytes(record))
    # An existing original coordinate is never replaced with another producer.
    started = tmp_path / "started-selector"
    started.mkdir()
    context, partitions = a._a12_no_aar_selector_inputs(current, tmp_path / "current-inputs")
    assert a._a12_selector_reuse_context(current, context, partitions, started) is None
    different = copy.deepcopy(partitions)
    different[0]["fit_covariate_members"][0]["sha256"] = "f" * 64
    missed = tmp_path / "different-inputs-selector"
    assert a._a12_selector_reuse_context(current, context, different, missed) is None
    assert not missed.exists()


@pytest.mark.parametrize('minimum',[15,10])
@pytest.mark.parametrize('damage',[None,'missing-path','native-error','failed','empty','new-policy','wrong-science','training-drift','missing-alpha'])
def test_frequency_successful_old_selector_prefix_reuse_has_exact_boundary(tmp_path,monkeypatch,damage,minimum):
    from padml import f5

    # The real first native reader remains downstream. This seam isolates its
    # source-admission and complete numerical-member transport before replay.
    monkeypatch.setattr(a,'_a12_nested_mice_source',lambda *args,**kwargs:dict(outer_fold=1,
        training_ids_sha256='1'*64,training_response_sha256='2'*64))
    monkeypatch.setattr(f5,'_nested_full_selector_partition_records',lambda rows:copy.deepcopy(rows))
    science=n._base_science_decision_template(24)
    old_source=n._sealed(dict(outer_fold=1,family='COX_PH',primary_source=dict(science_decision=science,
        primary_development_lock=dict(selection_horizon_months=24,selected_family='COX_PH',identity_sha256='3'*64)),
        mice_inputs=[dict(estimand=n.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT,identity='4'*64)]))
    source=dict(kind='PADML_NESTED_NO_AAR_SELECTOR_SOURCE_V1',program_id=n.PROGRAM_ID,context=1,
        inherited_family='COX_PH',primary_development_lock_sha256='3'*64,
        training_ids_sha256='1'*64,training_response_sha256='2'*64,
        mice_plan_sha256=n._sha(old_source['mice_inputs']))
    alphas=f5.load_science_authority()['science']['f2_model_development']['selector_contract']['alpha_grid']['coarse']
    raw_paths=canonical_json_bytes({'UNFITTED_TRANSPORT_BOUNDARY_NOT_NATIVE_PATHS':True})
    epv=dict(preferred_minimum=15,minimum=15,fallback_used=False,coarse_records_sha256=sha256_bytes(raw_paths),
        attempts=[dict(minimum=15,alpha_feasibility=[dict(alpha=x,status='FEASIBLE',reason_code='OK') for x in alphas])])
    if minimum==10:
        epv.update(minimum=10,fallback_used=True,attempts=[dict(minimum=15,alpha_feasibility=[
            dict(alpha=x,status='EPV_INFEASIBLE',reason_code='COMMON_SETA_EPV_BELOW_MINIMUM') for x in alphas]),
            dict(minimum=10,alpha_feasibility=[dict(alpha=x,status='FEASIBLE',reason_code='OK') for x in alphas])])
    if damage=='missing-alpha':epv['attempts'][-1]['alpha_feasibility'].pop()
    selected=dict(status='FEASIBLE',selected_parents=['Sex'],epv_resolution=epv)
    if damage=='native-error':epv['attempts'][0]['alpha_feasibility'][0].update(status='FAILED',reason_code='NATIVE_ERROR')
    if damage=='failed':selected['status']='NOT_ESTIMABLE'
    if damage=='empty':selected['selected_parents']=[]
    if damage=='new-policy':
        epv.update(frequency_policy_sha256=n.selector_frequency_policy()['identity_sha256'],frequency_threshold=12)
        for attempt in epv['attempts']:
            attempt.update(frequency_threshold=12)
            for row in attempt['alpha_feasibility']:row.update(common_set_design_df=1,common_set_epv=20 if row['status']=='FEASIBLE' else 12)
    development=n._sealed(dict(kind='PADML_NESTED_NO_AAR_SELECTOR_DEVELOPMENT_V1',outer_fold=1,source=source,
        selector=selected,selector_path_count=320,glmnet_call_count=640))
    previous=[dict(partition_id='UNFITTED',transform_recipe={})]
    leaves={'development-input.json':canonical_json_bytes(development),'partitions.json':canonical_json_bytes(previous),
        'selector.json':canonical_json_bytes({'coarse_alpha_order':alphas,'fine_alpha_order':[alphas[0]]}),
        'native-members.json':canonical_json_bytes([]),'recipes/native-values.json':canonical_json_bytes([]),'recipes/recipes.json':canonical_json_bytes([]),
        'coarse/paths.json':raw_paths}
    if damage=='missing-path':del leaves['coarse/paths.json']
    root=tmp_path/'AAR-H24-O1';root.mkdir()
    members={'development/selector/'+k:v for k,v in leaves.items()}
    header=n._sealed(dict(kind='PADML_F5_A12_OUTER_NATIVE_V2',outer_fold=1,source=old_source,
        members={k:dict(sha256=sha256_bytes(v),size_bytes=len(v)) for k,v in members.items()}))
    write_deterministic_zip(root/'result.zip',{'a12-outer.json':canonical_json_bytes(header),**members})
    receipt=dict(status='COMPLETED',direct_consumer_completed=True,run_identity='a'*64,unit_id=root.name,
        selection_horizon_months=24,report_horizons_months=[6,12,24,36],
        artifacts={'result.zip':dict(sha256=sha256_bytes((root/'result.zip').read_bytes()),size_bytes=(root/'result.zip').stat().st_size)})
    (root/'unit.json').write_bytes(canonical_json_bytes(receipt))
    current=copy.deepcopy(old_source);current['primary_source']['science_decision']=n.science_decision_template(24)
    current['primary_source']['primary_development_lock'].update(selection_horizon_months=6,identity_sha256='5'*64)
    if damage=='wrong-science':current['primary_source']['science_decision']['selector_frequency_amendment']['policy']['denominator']=19
    current=n._sealed({k:v for k,v in current.items() if k!='identity_sha256'})
    prepared=dict(source=current,outer_fold=1,completed_aar_units=[dict(root=str(root),receipt=receipt)])
    context={'source':dict(source,primary_development_lock_sha256='5'*64)}
    parts=[dict(partition_id='CHANGED' if damage=='training-drift' else 'UNFITTED')]
    target=tmp_path/'new-selector'
    saved={p:p.read_bytes() for p in (root/'unit.json',root/'result.zip')}
    if damage in {'native-error','wrong-science','missing-path','missing-alpha'}:
        with pytest.raises(ContractError):a._a12_selector_reuse_context(prepared,context,parts,target)
    elif damage in {'failed','empty','new-policy','training-drift'}:
        assert a._a12_selector_reuse_context(prepared,context,parts,target) is None
        assert not target.exists()
    else:
        assert a._a12_selector_reuse_context(prepared,context,parts,target)=={'source':source}
        assert a._a12_selector_reuse_context(prepared,context,parts,target)=={'source':source}
        for name,raw in leaves.items():assert (target/name).read_bytes()==raw
        proof=a.strict_json_bytes((target/'reuse.json').read_bytes())
        assert proof['execution']['new_glmnet_calls']==proof['execution']['new_selector_paths']==proof['execution']['new_recipe_fits']==0
    assert {p:p.read_bytes() for p in saved}==saved

@pytest.mark.parametrize('consumer_science',['base','amendment'])
def test_frequency_amendment_preserves_retained_mice_numerical_key(inputs,tmp_path,monkeypatch,consumer_science):
    # Valid original input contracts; the view archive is an explicitly UNFITTED
    # transport fixture. No MICE/model/SHAP/native engine is called.
    source=copy.deepcopy(inputs[3]);source['science_decision']=n._base_science_decision_template(24)
    lock=source['primary_development_lock']
    lock['science_decision_binding']['science_decision_sha256']=source['science_decision']['identity_sha256']
    source['primary_development_lock']=n._sealed({k:v for k,v in lock.items() if k!='identity_sha256'})
    old_inputs=(*inputs[:3],source,inputs[4])
    producer=_view(old_inputs,tmp_path/'producer.zip')
    other=copy.deepcopy(source)
    if consumer_science=='amendment':
        other['science_decision']=n.science_decision_template(24)
        other['primary_development_lock']['science_decision_binding']['science_decision_sha256']=other['science_decision']['identity_sha256']
        other['primary_development_lock']=n._sealed({k:v for k,v in other['primary_development_lock'].items() if k!='identity_sha256'})
    consumer=_view((*inputs[:3],other,inputs[4]),tmp_path/'consumer.zip',h=6)
    payload=tmp_path/'UNFITTED-view.zip';write_deterministic_zip(payload,{'input.zip':producer})
    value,entries=a._load_a12_total_mice_input(producer)
    origin=value['nested_source'];context=origin['primary_training_context']
    # Reconstruct the frozen original key's numerical contract independently of
    # the current declaration factory; only its exact BASE science is admissible.
    key_fields={k:value[k] for k in ('kind','binding_contract_sha256','authority_sha256','variable_sha256','view','chain_seeds')}
    key_fields.update(program_id=origin['program_id'],estimand=origin['estimand'],
        science_decision=n._base_science_decision_template(24),
        training_context={k:v for k,v in context.items() if k not in {'identity_sha256','modeling_program_sha256'}},
        native_sources=a._a12_mice_native_sources(),engine_threads=1,
        inputs={name:{'sha256':sha256_bytes(raw),'size_bytes':len(raw)} for name,raw in entries.items() if name!='input.json'})
    original_key=n._sha(key_fields)
    assert a._a12_mice_reuse_identity(producer)==a._a12_mice_reuse_identity(consumer)==original_key
    whole={'unit_id':'AAR-H24-O1','run_identity':'c'*64,'status':'COMPLETED','direct_consumer_completed':True,
        'selection_horizon_months':24,'report_horizons_months':[6,12,24,36],
        'artifacts':{'result.zip':{'sha256':'d'*64,'size_bytes':123}}}
    record={'whole_unit':whole,'result_archive':whole['artifacts']['result.zip'],
        'mice_archive':{'sha256':'e'*64,'size_bytes':456},'view_archive':_pin(payload),
        'producer_input':_pin(producer),'consumer_input':_pin(consumer),'numerical_identity_sha256':original_key}
    before={p:p.read_bytes() for p in (producer,consumer,payload)}
    def forbidden(*args,**kwargs):pytest.fail('NO_MICE_MODEL_SHAP_NATIVE_EXECUTION')
    monkeypatch.setattr(a,'_run_a12_total_mice_input',forbidden)
    original=a._a12_reused_mice_input(consumer,payload,record,tmp_path/'original-input.zip')
    assert original.read_bytes()==producer.read_bytes()
    assert a._a12_reused_mice_input(consumer,payload,record,original)==original
    assert {p:p.read_bytes() for p in before}==before
    bad=copy.deepcopy(record);bad['numerical_identity_sha256']='f'*64
    with pytest.raises(ContractError,match='F45_AAR_MICE_REUSE_DEPENDENCY_DRIFT'):
        a._a12_reused_mice_input(consumer,payload,bad,tmp_path/'wrong-key.zip')
    raw=a.read_safe_zip(consumer);meta=strict_json_bytes(raw['input.json'])
    meta['nested_source']['science_decision']['selector_frequency_amendment']={'UNAUTHORIZED':True}
    raw['input.json']=canonical_json_bytes(meta)
    foreign=tmp_path/'foreign-science.zip';write_deterministic_zip(foreign,raw)
    with pytest.raises(ContractError):a._a12_mice_reuse_identity(foreign)
