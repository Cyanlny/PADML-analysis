"""Original-reader admission seam only; zero numerical/source acceptance claim."""
import pytest

from padml import f4, runtime
from padml.bundle import ContractError, canonical_json_bytes, write_deterministic_zip


@pytest.mark.parametrize("case", ["owner-current", "legacy-old", "invalid-old", "invalid-current"])
def test_original_fixed12_reader_separates_retained_and_current_policy(tmp_path, monkeypatch, case):
    old = dict(configured_worker_ceiling=runtime.CPU_MINUS_8, memory_bytes_per_worker=1000,
        scratch_bytes_per_worker=1000, memory_reserve_bytes=1000, scratch_reserve_bytes=100,
        transfer_archive_worker_ceiling=2)
    current = {**old, "memory_reserve_bytes": 3000, "transfer_archive_worker_ceiling": 4}
    if case == "invalid-old":
        old["memory_reserve_bytes"] = -1
    if case == "invalid-current":
        current["memory_reserve_bytes"] = -1
    archive, inputs = tmp_path / "old.zip", tmp_path / "input.zip"
    write_deterministic_zip(archive, {
        "o-fit-execution.json": canonical_json_bytes({"kind": "PADML_F4_O_FIT_EXECUTION_ARCHIVE_V3",
            "members": {"final-numbers.zip": {}}, "outer_fold": 1}),
        "final-numbers.zip": b"UNREAD_NUMERICAL_BYTES"})
    write_deterministic_zip(inputs, {"o-fit-input.json": canonical_json_bytes({"resource_policy": old})})
    original = inputs.read_bytes()
    seen = []
    class AdmissionObserved(Exception):
        pass
    def admission(policy, observation, **kwargs):
        seen.append(policy)
        assert observation["scratch_available_bytes"] == 10**12 and kwargs["legal_tasks"] == 1
        raise AdmissionObserved
    def source(*args, admit_io, **kwargs):
        admit_io(memory_bytes=7, pending_bytes=11)
        pytest.fail("admission must precede any source consumption")
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda root: {"scratch_available_bytes": 10**12})
    monkeypatch.setattr(runtime, "resource_admission", admission)
    monkeypatch.setattr(f4, "_load_f4_source_records", source)
    kwargs = dict(input_bundle=inputs, f2_run_root=tmp_path, compiled_input_record={},
        retained_primary_source_bundle=tmp_path / "UNREAD-source.zip",
        replay_evidence=tmp_path / "owned-expansion", rescore_fixed12_decision={},
        rescore_target=tmp_path / "not-written.zip")
    if case != "legacy-old":
        kwargs.update(outer_fixed12_target_request={"resource_policy": current},
            outer_fixed12_target_root=tmp_path, outer_fixed12_result_root=tmp_path)
    with pytest.raises(ContractError if case.startswith("invalid") else AdmissionObserved):
        f4._load_o_fit_execution_archive(archive, **kwargs)
    assert inputs.read_bytes() == original
    if case.startswith("invalid"):
        assert seen == []
    else:
        expected = old if case == "legacy-old" else current
        assert seen == [{**expected, "memory_bytes_per_worker": 2 * 1024**3,
            "memory_reserve_bytes": expected["memory_reserve_bytes"] + 7, "scratch_reserve_bytes": 0}]
    assert not (tmp_path / "not-written.zip").exists()
