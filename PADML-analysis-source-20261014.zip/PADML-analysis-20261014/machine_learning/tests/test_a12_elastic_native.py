"""No-fit regression coverage for A12 native EN retention and scoped adapters."""
from __future__ import annotations

import copy
import json
import os
from pathlib import Path
import shutil
import struct
import subprocess

import pytest

from padml.bundle import ContractError, canonical_json_bytes, sha256_bytes
import padml.f2_kernel as kernel
from padml.f5_sensitivity import _run_a12_elastic_native_batch


def _spec(root, native, *, replay=False):
    root.mkdir()
    value = {
        "execution_scope": "F5_A12_SEARCH", "family": "ELASTIC_NET_COX",
        "native_search_root": str(native), "native_search_replay": replay,
        "output_path": str(root / "output.json"),
        "a12_source": {"fixture": "UNFITTED_IO_ONLY", "outer_fold": 1},
        "seed": 301000,
        "producer_tasks": [{"producer_kind": "ELASTIC_INNER_PATH", "alphas": [0.2]}],
        "registered_partitions": {"partitions": [{
            "partition_id": "UNFITTED-r1-k1", "fit_ids": ["train"],
            "evaluation_ids": ["heldout-1", "heldout-2"],
            "covariates": {"input_dir": "/UNFITTED/inputs", "members_sha256": "1" * 64},
            "fit_response": {"path": "/UNFITTED/response", "sha256": "2" * 64},
        }]},
    }
    (root / "spec.json").write_bytes(canonical_json_bytes(value))
    return value


def _risk(root, role, values):
    name = f"risk-001-alpha-001-{role}.bin"
    raw = struct.pack("<" + "d" * sum(map(len, values)), *(v for row in values for v in row))
    (root / name).write_bytes(raw)
    return {
        "schema_version": "1.0.0", "kind": "PADML_F2_OPERATION_LOCAL_RISK_MATRIX",
        "encoding": "IEEE754_FLOAT64", "byte_order": "LITTLE_ENDIAN", "row_order": "ROW_MAJOR",
        "file_name": name, "rows": len(values), "columns": len(values[0]),
        "size_bytes": len(raw), "sha256": sha256_bytes(raw),
    }


def test_a12_native_originals_survive_real_consumers_and_no_fit_replay(tmp_path, monkeypatch):
    native = tmp_path / "native"
    native.mkdir()
    fresh_root = tmp_path / "fresh"
    replay_root = tmp_path / "replay"
    fresh_root.mkdir()
    replay_root.mkdir()
    fresh = fresh_root / "batch-0001"
    spec = _spec(fresh, native)
    calls = []

    def unfitted_engine(spec_path, output_path, repo_root, environment, *, preserve_logs=False):
        calls.append(str(spec_path))
        assert preserve_logs and spec_path.parent == native / "batch-0001"
        assert json.loads(spec_path.read_bytes())["output_path"] == str(output_path)
        channel = {"schema_version": "1.0.0", "kind": "PADML_F2_OPERATION_LOCAL_RISK_MATRIX_CHANNEL",
                   "fit": _risk(spec_path.parent, "fit", [[1.25, -2.0]]),
                   "evaluation": _risk(spec_path.parent, "evaluation", [[3.0, 4.5], [0.0, 6.0]])}
        output_path.write_bytes(canonical_json_bytes({"fixture": "UNFITTED", "risk_channel": channel}))
        (spec_path.parent / "r.stdout.log").write_bytes(b"UNFITTED stdout\n")
        (spec_path.parent / "r.stderr.log").write_bytes(b"UNFITTED stderr\n")

    monkeypatch.setattr(kernel, "_execute_r_prediction", unfitted_engine)
    output = _run_a12_elastic_native_batch(fresh / "spec.json", fresh / "output.json", tmp_path, {})
    originals = {p.name: p.read_bytes() for p in (native / "batch-0001").iterdir()}
    assert set(originals) == {"spec.json", "output.json", "r.stdout.log", "r.stderr.log",
                              "risk-001-alpha-001-fit.bin", "risk-001-alpha-001-evaluation.bin"}
    kernel._validate_r_risk_scratch_members(fresh, spec["producer_tasks"])
    assert kernel._consume_operation_local_risk_channel(
        output["risk_channel"], fresh, expected_prefix="risk-001-alpha-001",
        fit_rows=1, evaluation_rows=2, columns=2,
    ) == ([[1.25, -2.0]], [[3.0, 4.5], [0.0, 6.0]])
    assert set(p.name for p in fresh.iterdir()) == {"spec.json", "output.json"}
    assert {p.name: p.read_bytes() for p in (native / "batch-0001").iterdir()} == originals

    def forbidden_engine(*args, **kwargs):
        pytest.fail("Native replay must not enter R, even an UNFITTED substitute")

    monkeypatch.setattr(kernel, "_execute_r_prediction", forbidden_engine)
    replay = replay_root / "batch-0001"
    replay_spec = _spec(replay, native, replay=True)
    replay_spec["registered_partitions"]["partitions"][0]["covariates"]["input_dir"] = "/relocated/inputs"
    replay_spec["registered_partitions"]["partitions"][0]["fit_response"]["path"] = "/relocated/response"
    (replay / "spec.json").write_bytes(canonical_json_bytes(replay_spec))
    assert _run_a12_elastic_native_batch(replay / "spec.json", replay / "output.json", tmp_path, {}) == output
    kernel._validate_r_risk_scratch_members(replay, replay_spec["producer_tasks"])
    assert kernel._consume_operation_local_risk_channel(
        output["risk_channel"], replay, expected_prefix="risk-001-alpha-001",
        fit_rows=1, evaluation_rows=2, columns=2,
    ) == ([[1.25, -2.0]], [[3.0, 4.5], [0.0, 6.0]])
    drift = copy.deepcopy(replay_spec)
    drift["registered_partitions"]["partitions"][0]["fit_response"]["sha256"] = "3" * 64
    (replay / "spec.json").write_bytes(canonical_json_bytes(drift))
    with pytest.raises(ContractError, match="F5_A12_ELASTIC_NATIVE_INPUT_MISMATCH"):
        _run_a12_elastic_native_batch(replay / "spec.json", replay / "output.json", tmp_path, {})
    assert len(calls) == 1
    assert {p.name: p.read_bytes() for p in (native / "batch-0001").iterdir()} == originals


def test_a12_native_failure_preserves_original_spec_logs_and_frames(tmp_path, monkeypatch):
    native = tmp_path / "native"
    native.mkdir()
    scratch = tmp_path / "batch-0001"
    _spec(scratch, native)
    calls = []

    def unfitted_failure(spec_path, output_path, repo_root, environment, *, preserve_logs=False):
        calls.append(str(spec_path))
        assert preserve_logs
        for name in ("r.stdout.log", "r.stderr.log", "native-failure.rda"):
            (spec_path.parent / name).write_bytes(b"UNFITTED failure evidence\n")
        raise RuntimeError("UNFITTED intentional native failure")

    monkeypatch.setattr(kernel, "_execute_r_prediction", unfitted_failure)
    with pytest.raises(RuntimeError, match="UNFITTED intentional"):
        _run_a12_elastic_native_batch(scratch / "spec.json", scratch / "output.json", tmp_path, {})
    assert len(calls) == 1 and (scratch / "spec.json").is_file()
    assert set(p.name for p in (native / "batch-0001").iterdir()) == {
        "spec.json", "r.stdout.log", "r.stderr.log", "native-failure.rda"}
    assert not (scratch / "output.json").exists()


_PURE_R_DESIGN = r'''
args <- commandArgs(trailingOnly=TRUE)
extract <- function(path, names, env) {
  found <- character()
  for (item in parse(path)) {
    if (is.call(item) && identical(item[[1L]], as.name("<-")) && length(item) == 3L &&
        is.symbol(item[[2L]]) && as.character(item[[2L]]) %in% names &&
        is.call(item[[3L]]) && identical(item[[3L]][[1L]], as.name("function"))) {
      eval(item, envir=env)
      found <- c(found, as.character(item[[2L]]))
    }
  }
  stopifnot(setequal(found, names))
}
need <- function(ok, reason) { if (!isTRUE(ok)) stop(reason, call.=FALSE) }
rejects <- function(value) inherits(tryCatch(force(value), error=function(e) e), "error")
e2 <- new.env(parent=baseenv()); e2$need <- need
shared <- c("prepare_frame", "glmnet_engine_design", "data_driven_cox_lambda_upper_bound", "elastic_ratio_path")
extract(args[[1L]], shared, e2)
for (name in shared) {
  stopifnot(identical(formals(e2[[name]])$a12, FALSE))
  stopifnot(!("a12_search" %in% all.names(body(e2[[name]]))))
}
x <- matrix(c(-1, 0, 1), ncol=1L, dimnames=list(NULL, "HGB"))
y <- matrix(c(2, 3), ncol=1L, dimnames=list(NULL, "HGB"))
z <- e2$glmnet_engine_design(x, y, 1, a12=TRUE)
stopifnot(identical(colnames(z$train), c("HGB", "PADML_GLMNET_INERT_ZERO")),
          identical(z$penalty, c(1, 1)), identical(unname(z$train[,1L]), c(-1,0,1)),
          all(z$train[,2L] == 0), all(z$test[,2L] == 0))
stopifnot(rejects(e2$glmnet_engine_design(x, y, 1)))
colnames(x) <- colnames(y) <- "AST_ALT"
old <- e2$glmnet_engine_design(x, y, 0)
stopifnot(identical(old$penalty, c(0,1)), rejects(e2$glmnet_engine_design(x,y,0,a12=TRUE)))
e5 <- new.env(parent=baseenv()); e5$need <- need; e5$a12 <- FALSE
extract(args[[2L]], "glmnet_engine_design", e5)
old5 <- e5$glmnet_engine_design(x, 0)
stopifnot(identical(old5$penalty, c(0,1)))
colnames(x) <- "HGB"
stopifnot(rejects(e5$glmnet_engine_design(x, 1)))
e5$a12 <- TRUE
z5 <- e5$glmnet_engine_design(x, 1)
stopifnot(identical(z5$penalty, c(1,1)), identical(z5$x, z$train))
cat("PASS: both R files parsed; explicit default compatibility and inert-zero design; fits=0 RNG=0\n")
'''


def test_a12_single_column_pure_r_design_and_default_import_compatibility(tmp_path):
    rscript = shutil.which("Rscript")
    if rscript is None:
        pytest.skip("Rscript unavailable; this is not a fitting test")
    package = Path(kernel.__file__).resolve().parent
    script = tmp_path / "pure-design.R"
    script.write_text(_PURE_R_DESIGN, encoding="utf-8")
    result = subprocess.run(
        [rscript, "--vanilla", str(script), str(package / "kernels/f2_model_development.R"),
         str(package / "kernels/f5_final_refit.R")],
        capture_output=True, text=True, timeout=30,
        env={**os.environ, "OMP_NUM_THREADS": "1", "OPENBLAS_NUM_THREADS": "1", "MKL_NUM_THREADS": "1"},
    )
    (tmp_path / "r.stdout.log").write_text(result.stdout, encoding="utf-8")
    (tmp_path / "r.stderr.log").write_text(result.stderr, encoding="utf-8")
    assert result.returncode == 0, result.stdout + result.stderr
    assert "fits=0 RNG=0" in result.stdout
