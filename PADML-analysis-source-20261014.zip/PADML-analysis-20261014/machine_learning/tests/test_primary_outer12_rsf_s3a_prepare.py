"""Synthetic S2 numerical ingress and original-funnel S3A boundary, no fits."""
import copy
import os
from pathlib import Path

import pytest

from padml import f2_kernel as kernel, f4, f5
from padml.bundle import ContractError, canonical_json_bytes, sha256_bytes
from test_primary_outer12_rsf_consume import _case


@pytest.mark.parametrize("damage", [None, "execution-source", "kernel"])
def test_completed_executor_source_reaches_s2_consumer_without_relabeling(tmp_path, monkeypatch, damage):
    configured = os.environ.get("PADML_PRIMARY_RSF_COMPLETED_EXECUTOR_SOURCE")
    if configured is None:
        pytest.skip("explicit completed-executor code fixture required")
    executor = Path(configured).resolve(strict=True)
    spec, units, control, seen = _case(tmp_path, monkeypatch, stage="S2")
    identity = "07addcbb504f98caed9be64f2f598454bf6eb1df43bd6494e4d143151eb6e9bc"
    control["retained_primary_rsf_q_source_bundle"] = executor
    for path, row in control["batches"]:
        row["source_identity"] = identity
        if damage == "execution-source": row["source_identity"] = "f" * 64
        (path / "execution.json").write_bytes(canonical_json_bytes(row))
    if damage == "kernel":
        members = f4._f45_source_member_sha256()
        monkeypatch.setattr(f4, "_f45_source_member_sha256",
            lambda: {**members, "padml/kernels/f2_model_development.R": "0" * 64})
    calls = [item[0] for item in units.values()]
    if damage:
        with pytest.raises(ContractError):
            f5._q_search_task_batch(spec, kernel._run_r_prediction_pool_task, calls)
        assert not seen
    else:
        rows = f5._q_search_task_batch(spec, kernel._run_r_prediction_pool_task, calls)
        assert len(rows) == 75 and len(seen) == len(set(seen)) == 200
        assert control["confirmed_model_fits"] == 320
        assert control["primary_rsf_s1_history"]["score_trace_status"] == "NOT_RETAINED"
        assert all(row["source_identity"] == identity for _, row in control["batches"])


@pytest.mark.parametrize("damage", [None, "missing", "duplicate", "source", "input", "audit", "seed", "report", "fit", "publish"])
def test_s2_complete_numerical_consumer_or_reject_before_leaf(tmp_path, monkeypatch, damage):
    spec, units, control, seen = _case(tmp_path, monkeypatch, stage="S2")
    record = control["batches"][0][1]
    if damage == "missing": control["batches"].pop()
    elif damage == "duplicate": control["batches"][-1] = control["batches"][0]
    elif damage == "source": record["source_identity"] = "f" * 64
    elif damage == "input": record["input"]["sha256"] = "e" * 64
    elif damage == "audit": record["units"][0]["first_native_audit_count"] -= 1
    elif damage == "seed": next(iter(units.values()))[0][2][0]["seed"] += 1
    elif damage == "report": control["primary_rsf_s2_evidence"]["primary-s2/report.json"].write_bytes(b'{}')
    elif damage == "fit": control["prepare_only"] = False
    elif damage == "publish": control["q_unit_outputs"] = [["FORBIDDEN"]]
    for path, row in control["batches"]:
        (path / "execution.json").write_bytes(canonical_json_bytes(row))
    calls = [item[0] for item in units.values()]
    if damage:
        with pytest.raises(ContractError): f5._q_search_task_batch(spec, kernel._run_r_prediction_pool_task, calls)
        assert not seen
    else:
        rows = f5._q_search_task_batch(spec, kernel._run_r_prediction_pool_task, calls)
        assert len(rows) == 75 and len(seen) == len(set(seen)) == 200
        assert control["confirmed_model_fits"] == 320 and control["confirmed_stop_fits"] == 0
        assert len(control["used_batches"]) == 7
        assert control["primary_rsf_s1_history"]["score_trace_status"] == "NOT_RETAINED"
        assert "primary_rsf_s2_trace" not in control


@pytest.mark.parametrize("damage", [None, "horizon", "outer", "fit", "continuation-false", "already-consumed", "tie", "s3a-seed",
    pytest.param("retained-s1", marks=pytest.mark.xfail(strict=True,
        reason="Future-source contract gap: S1 transport after source admission is not implemented"))])
@pytest.mark.parametrize("capture_successor", [False, True])
def test_original_rsf_funnel_skips_s1_and_stops_at_genuine_s3a_atoms(tmp_path, monkeypatch, damage, capture_successor):
    spec, units, control, seen = _case(tmp_path, monkeypatch, stage="S2")
    if capture_successor:
        control["prepared_calls"] = []
    base = next(iter(units.values()))[0]
    partitions = []
    for repeat in range(1, 4):
        for part in range(1, 6):
            row = copy.deepcopy(base[6])
            row.update(partition_id=f"INNER_F2_R{repeat}_K{part}", repeat=repeat, inner_fold=part)
            partitions.append(row)
    registered = {**base[1], "partitions": partitions, "diagnostic_partitions": []}
    registered.pop("projected_partition_ids"); registered.pop("projected_partition_count")
    spec["candidate_trials"] = {"S1": [{"FORBIDDEN_S1": True}], "S2": [
        {"trial_id": f"TRIAL-{i}", "parameters": {"splitrule": "logrank", "UNFITTED": i},
         "parameter_sha256": str(i) * 64} for i in range(1, 9)]}
    raw = {"kind": "PADML_F5_Q_INPUT_V1", "task": {"UNFITTED": True},
           "spec": {k: v for k, v in spec.items() if k != "native_search_batch"}}
    (tmp_path / "q/input.json").write_bytes(canonical_json_bytes(raw))
    consumed, summaries = [], []
    def numeric(_, function, original_units, batches, phase, input_ref):
        # Source/member/coordinate validation is tested above. Here substitute
        # only the actual leaf values to exercise the original funnel routing.
        tasks = [row for call, _ in original_units.values() for row in call[2]]
        assert len(original_units) == 75 and len(tasks) == 200
        assert all(row["task_id"].startswith("S2_") for row in tasks)
        consumed.extend(row["task_id"] for row in tasks)
        control["confirmed_model_fits"] = 200
        control["used_batches"] = [kernel._sha(row) for _, row in batches]
        return [[{"task_id": row["task_id"], "partition_id": row["partition_id"], "imputation": row["imputation"],
            "prediction_seal_sha256": "a" * 64, "evaluation_response_sha256": "b" * 64,
            "evaluation_ids_sha256": "c" * 64, "ibs_0_12": 0.1, "stopping": None,
            "sealed_prediction": {"UNFITTED": True}} for row in call[2]] for call, _ in original_units.values()]
    monkeypatch.setattr(f5, "_consume_q_search_batches", numeric)
    if damage == "retained-s1":
        # This is a future-source transport requirement, NOT a reachable
        # accepted historical input: the real reader pins six old report
        # hashes, none carrying S1. The numerical/source leaf below is mocked.
        # Production closure must first admit a genuinely bound new producer
        # receipt, then retain its S1; never loosen the historical pins.
        import json
        report_path = control["primary_rsf_s2_evidence"]["primary-s2/report.json"]
        report = json.loads(report_path.read_bytes())
        retained_s1 = [{"stage_id": "S1", "trial_index": i,
            "candidate_id": f"S1-{i}", "parameters": {"UNFITTED": i},
            "parameter_sha256": kernel._sha({"UNFITTED": i}),
            "evaluation_units": 5, "selection_horizon_months": 12,
            "mean_ibs": .1, "maximum_ibs": .1} for i in range(1, 25)]
        report["original_q_boundary"]["search_trace"] = {"S1": retained_s1}
        report["original_q_boundary"]["complete_search_trace"] = False
        report_path.write_bytes(canonical_json_bytes(report))
    monkeypatch.setattr(kernel, "_accumulate_registered_evaluations", lambda *a: None)
    def context(rows, *, selection_horizon_months):
        assert selection_horizon_months == 12 and [r["repeat"] for r in rows] == [2] * 5
        return {"UNFITTED": True}
    monkeypatch.setattr(kernel, "_trial_scoring_context", context)
    def summary(values, context, m):
        assert m == 5 and len(values) == 25
        summaries.append([v["task_id"] for v in values])
        score = 0.1 if damage == "tie" else len(summaries) / 100
        return {"evaluation_units": 25, "selection_horizon_months": 12, "mean_ibs": score, "maximum_ibs": score}
    monkeypatch.setattr(kernel, "_trial_evaluation_summary", summary)
    original = f5._q_search_task_batch
    def q_boundary(value, function, tasks):
        if damage == "s3a-seed" and tasks[0][2][0]["task_id"].startswith("S3A"):
            tasks[0][2][0]["seed"] += 1
        return original(value, function, tasks)
    monkeypatch.setattr(f5, "_q_search_task_batch", q_boundary)
    if damage == "horizon": spec["selection_horizon_months"] = 24
    elif damage == "outer": spec["primary_search_source"]["outer_fold"] = 1
    elif damage == "fit": control["prepare_only"] = False
    elif damage == "continuation-false": control["primary_rsf_s2_consumption"] = False
    elif damage == "already-consumed": control["used_batches"] = ["a" * 64]
    monkeypatch.setattr(f5, "_execute_q_search_batch", lambda *a, **k: pytest.fail("fit forbidden"))
    monkeypatch.setattr(kernel, "_shared_full_development_search_result", lambda *a, **k: pytest.fail("incomplete full trace forbidden"))
    if damage and damage != "retained-s1":
        with pytest.raises(ContractError):
            kernel._run_r_registered_rsf(spec, registered, tmp_path, tmp_path, search_only=True)
        if damage not in {"tie", "s3a-seed"}: assert not consumed
    else:
        with pytest.raises(f5._QBatchBoundary) as caught:
            kernel._run_r_registered_rsf(spec, registered, tmp_path, tmp_path, search_only=True)
        result = caught.value.result
        if capture_successor:
            assert len(control["prepared_calls"]) == 1
            function, successor = control["prepared_calls"][0]
            assert function is kernel._run_r_prediction_pool_task
            assert [{"task_id": name, "producer_tasks": call[2]}
                    for name, (call, _) in successor.items()] == result["next_atomic_units"]
        assert len(consumed) == 200 and len(summaries) == 8 and not seen
        assert list(result["search_trace"]) == (["S1", "S2"] if damage == "retained-s1" else ["S2"])
        assert result["complete_search_trace"] is False
        if damage == "retained-s1":
            assert result["search_trace"]["S1"] == retained_s1
        assert [c["candidate_id"] for c in result["s3a_candidates"]] == ["TRIAL-1", "TRIAL-2", "TRIAL-3"]
        assert result["model_coordinate_count"] == 300 and len(result["next_atomic_units"]) == 100
        assert all(len(unit["producer_tasks"]) == 3 for unit in result["next_atomic_units"])
        assert result["new_model_fits"] == 0 and result["worker_inputs_ready"] is False
        assert result["stage_acceptance"] is False


@pytest.mark.parametrize("name", ["retainedb077.zip", "retained3700.zip", "retained293f.zip", "retainedbc8e.zip"])
def test_real_s2_producer_source_is_proven_without_execution(name):
    root = Path(os.environ.get("PADML_PRIMARY_RSF_SOURCE_FIXTURES", Path(__file__).parents[1]))
    current = f4._f45_source_member_sha256()
    members = f4._retained_full0_source_members(root / name, primary_rsf_inputs=True)
    assert len(members) == 49 and members != current and f4._f45_source_member_sha256() == current


@pytest.mark.parametrize("name", ["retainedb077.zip", "retained3700.zip", "retained293f.zip", "retainedbc8e.zip"])
@pytest.mark.parametrize("module,damage", [
    ("padml/f2_kernel.py", "binding"), ("padml/f4.py", "binding"),
    ("padml/f5.py", "binding"), ("padml/f5_sensitivity.py", "binding"),
    ("padml/nested_loco.py", "binding"), ("padml/kernels/f4_metrics.R", "binding"),
    ("padml/f4.py", "gbm-proof-body"), ("padml/f4.py", "reciprocal-proof-link"),
])
def test_primary_source_closure_rejects_unpaired_bytes(name, module, damage, monkeypatch):
    root = Path(os.environ.get("PADML_PRIMARY_RSF_SOURCE_FIXTURES", Path(__file__).parents[1]))
    target = Path(f4.__file__).parents[1] / module
    read_bytes = Path.read_bytes
    original = read_bytes(target)
    if damage == "binding":
        changed = original + b"\nUNPAIRED_BINDING = True\n"
    elif damage == "gbm-proof-body":
        before = b"This proof admits numerical consumers only."
        assert original.count(before) == 1
        changed = original.replace(before, b"UNPAIRED GBM proof body.", 1)
    else:
        import ast
        lines = original.splitlines(keepends=True)
        own = next(node for node in ast.parse(original).body
                   if isinstance(node, ast.FunctionDef) and node.name == "_retained_full0_source_members")
        digest = sha256_bytes(b"".join(lines[own.lineno - 1:own.end_lineno])).encode()
        assert original.count(digest) == 2
        changed = original.replace(digest, b"0" * 64, 1)
    current = f4._f45_source_member_sha256()
    monkeypatch.setattr(Path, "read_bytes", lambda path: changed if path == target else read_bytes(path))
    monkeypatch.setattr(f4, "_f45_source_member_sha256", lambda: {**current, module: sha256_bytes(changed)})
    with pytest.raises(ContractError, match="F5_RETAINED_PRIMARY_RSF_INPUT_SOURCE_DRIFT"):
        f4._retained_full0_source_members(root / name, primary_rsf_inputs=True)
