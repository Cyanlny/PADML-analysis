"""Bounded operational release only: no patient data, model or numerical engine."""
import copy
import mmap
import os
import resource
import subprocess
from pathlib import Path
from types import SimpleNamespace

import pytest

from padml import runtime
from padml.bundle import ContractError, canonical_json_bytes, sha256_bytes, sha256_file, write_deterministic_zip
from test_runtime_pool import _cgroup_host


def _memory_host(tmp_path, monkeypatch):
    leaf = _cgroup_host(tmp_path, monkeypatch)
    for path, total, limit in ((leaf, 100, 1000), (leaf.parent, 800, 1000),
                               (leaf.parent.parent, 900, "max")):
        (path / "memory.current").write_text(str(total))
        (path / "memory.max").write_text(str(limit))
        (path / "memory.stat").write_text("anon 40\nfile 50\n")
    original = Path.read_text
    def read(path, *args, **kwargs):
        if str(path) == "/proc/self/smaps_rollup":
            return "Rss: 73 kB\nPss: 4 kB\n"
        if str(path) == "/proc/meminfo":
            return "MemAvailable: 1000 kB\n"
        return original(path, *args, **kwargs)
    monkeypatch.setattr(Path, "read_text", read)
    return leaf


@pytest.mark.parametrize("bad_stat", [None, "anon 3\n", "anon 3\nfile -1\n", "anon 3\nfile 4\nfile 5\n"])
def test_missing_or_bad_stats_are_unknown_without_extra_admission(tmp_path, monkeypatch, bad_stat):
    leaf = _memory_host(tmp_path, monkeypatch)
    if bad_stat is None:
        (leaf / "memory.stat").unlink()
    else:
        (leaf / "memory.stat").write_text(bad_stat)
    snapshot = runtime.observe_step_memory()
    assert snapshot["rss_bytes"] == 73 * 1024
    assert snapshot["cgroups"][0]["stat_status"] == "UNKNOWN"
    assert snapshot["cgroups"][0]["anon_bytes"] is snapshot["cgroups"][0]["file_bytes"] is None
    assert runtime._available_memory_bytes() == 200
    (leaf / "memory.stat").write_text("anon 1\nfile 999999999\n")
    assert runtime.observe_step_memory()["cgroups"][0]["file_bytes"] == 999999999
    assert runtime._available_memory_bytes() == 200


def test_root_stats_observed_even_when_total_is_not_exposed(tmp_path, monkeypatch):
    leaf = _memory_host(tmp_path, monkeypatch)
    root = leaf.parent.parent
    (root / "memory.max").unlink()
    (root / "memory.current").unlink()
    row = runtime.observe_step_memory()["cgroups"][-1]
    assert row["total_bytes"] is None and row["file_bytes"] == 50 and row["anon_bytes"] == 40
    assert runtime._available_memory_bytes() == 200


def test_disappearing_limit_does_not_fall_back_to_parent(tmp_path, monkeypatch):
    leaf = _memory_host(tmp_path, monkeypatch)
    original = Path.is_file
    calls = []
    def is_file(path):
        if path == leaf / "memory.max":
            calls.append(path)
            existed = original(path)
            if existed:
                path.unlink()
            return existed
        return original(path)
    monkeypatch.setattr(Path, "is_file", is_file)
    with pytest.raises(ContractError, match="MEMORY_RESOURCE_UNDETERMINED"):
        runtime._available_memory_bytes()
    assert len(calls) == 1


def _release(path):
    return runtime.release_step_resources([path], owner="UNFITTED_CLOSED_TEST_FILE",
        before=runtime.observe_step_memory(), released_references=[])


@pytest.mark.parametrize('run_owner', [False, True, 'offline_archive'])
def test_completed_io_uses_only_exact_inodes_without_rescans(tmp_path, monkeypatch, run_owner):
    first, second = tmp_path/'first', tmp_path/'second'
    first.write_bytes(b'UNFITTED-original-one'); second.write_bytes(b'UNFITTED-original-two')
    alias, link = tmp_path/'hardlink', tmp_path/'symlink'
    os.link(first, alias); link.symlink_to(second)
    monkeypatch.setattr(runtime, '_COMPLETED_CACHE_FILES', set())
    monkeypatch.setattr(runtime, '_COMPLETED_CACHE_ROOT', tmp_path if run_owner is True else None)
    if run_owner:
        monkeypatch.setenv('PADML_F45_RUN_PATH', str(tmp_path/'run.json'))
    else:
        monkeypatch.delenv('PADML_F45_RUN_PATH', raising=False)
    for name in ('rglob', 'iterdir', 'read_bytes'):
        monkeypatch.setattr(Path, name, lambda *a, **kw: pytest.fail('NO_DISCOVERY_OR_BYTE_READ'))
    monkeypatch.setattr(runtime, '_visible_open_file_keys', lambda *a: pytest.fail('NO_PROC_SCAN'))
    events = []
    monkeypatch.setattr(os, 'fsync', lambda fd: events.append(('sync', os.fstat(fd).st_ino)))
    monkeypatch.setattr(os, 'POSIX_FADV_DONTNEED', 4, raising=False)
    monkeypatch.setattr(os, 'posix_fadvise', lambda fd, start, size, kind:
        events.append(('advice', os.fstat(fd).st_ino, start, size, kind)), raising=False)
    report = runtime.advise_completed_io([first, first, alias, second, link, tmp_path,
        tmp_path/'missing', Path('relative')])
    assert report['attempted_files'] == report['advised_files'] == 2
    assert report['skipped_files'] == 4 and not report['failed_files']
    assert [e[0] for e in events] == ['sync', 'advice', 'sync', 'advice']
    assert all(e[2:] == (0, 0, 4) for e in events if e[0] == 'advice')
    assert runtime._COMPLETED_CACHE_FILES == set()  # Successful hints have no tail retry.
    with first.open('rb') as f: assert f.read() == b'UNFITTED-original-one'
    with second.open('rb') as f: assert f.read() == b'UNFITTED-original-two'


def test_completed_io_advice_failure_is_bounded_and_keeps_entity(tmp_path, monkeypatch):
    path = tmp_path/'kept'; path.write_bytes(b'UNFITTED-original')
    monkeypatch.setattr(os, 'POSIX_FADV_DONTNEED', 4, raising=False)
    def unavailable(*args): raise OSError('UNFITTED unsupported filesystem')
    monkeypatch.setattr(os, 'posix_fadvise', unavailable, raising=False)
    report = runtime.advise_completed_io([path])
    assert report['failed_files'] == report['attempted_files'] == 1
    assert report['advised_files'] == 0 and path.read_bytes() == b'UNFITTED-original'


def test_cache_retry_dedup_and_unchanged_reopen(tmp_path, monkeypatch):
    from collections import OrderedDict
    path = tmp_path / 'same'; path.write_bytes(b'unchanged')
    for name in ('_CACHE_DONE', '_CACHE_PENDING'):
        monkeypatch.setattr(runtime, name, OrderedDict())
    monkeypatch.setattr(runtime, '_COMPLETED_CACHE_FILES', set())
    monkeypatch.setattr(runtime, '_COMPLETED_CACHE_ROOT', tmp_path)
    monkeypatch.setattr(os, 'POSIX_FADV_DONTNEED', 4, raising=False)
    attempts = []
    def fail(*args):
        attempts.append(args)
        raise OSError('advisory unavailable')
    monkeypatch.setattr(os, 'posix_fadvise', fail, raising=False)
    runtime.advise_completed_io([path], sync=False)
    for _ in range(4): runtime.drain_completed_io()
    assert len(attempts) == 2 and not runtime._COMPLETED_CACHE_FILES
    monkeypatch.setattr(os, 'posix_fadvise', lambda *args: attempts.append(args))
    runtime.mark_cache_use([path])
    assert runtime.advise_completed_io([path], sync=False, new_consumption=False)['advised_files'] == 1
    assert runtime.advise_completed_io([path], sync=False, new_consumption=False)['skipped_files'] == 1
    with runtime.ConsumedStream(path.open('rb')) as stream:
        assert stream.read() == b'unchanged'
    assert len(attempts) == 4  # A genuine reread heats this unchanged inode again.
    runtime.advise_completed_io([path], sync=False, new_consumption=False)
    assert len(attempts) == 4 and not runtime._CACHE_PENDING


def test_failed_small_file_hints_remain_bounded(tmp_path, monkeypatch):
    from collections import OrderedDict
    monkeypatch.setattr(runtime, '_CACHE_PENDING', OrderedDict())
    monkeypatch.setattr(runtime, '_COMPLETED_CACHE_FILES', set())
    monkeypatch.setattr(runtime, '_COMPLETED_CACHE_ROOT', tmp_path)
    monkeypatch.setattr(runtime, '_CACHE_PENDING_LIMIT', 4)
    monkeypatch.setattr(runtime, 'advise_consumed_stream', lambda *a, **kw: 'UNKNOWN')
    paths = []
    for i in range(20):
        p = tmp_path / str(i); p.write_bytes(b'x'); paths.append(p)
    runtime.advise_completed_io(paths, sync=False)
    assert len(runtime._CACHE_PENDING) == len(runtime._COMPLETED_CACHE_FILES) == 4
    runtime.drain_completed_io()
    assert not runtime._CACHE_PENDING and not runtime._COMPLETED_CACHE_FILES


def test_consumed_stream_failed_send_retains_only_actual_nonaligned_ranges(tmp_path, monkeypatch):
    path = tmp_path / 'stream'; path.write_bytes(b'x'*(10*1024**2+17))
    rows = []
    monkeypatch.setattr(runtime, 'advise_consumed_stream',
        lambda stream, **kw: rows.append(kw) or 'ADVISED')
    original = BrokenPipeError('receiver went away')
    with pytest.raises(BrokenPipeError) as caught:
        with runtime.ConsumedStream(path.open('rb'), rolling=True) as stream:
            stream.seek(7)
            stream.read(8*1024**2+21)
            raise original
    assert caught.value is original and stream.closed
    assert sum(row['length'] for row in rows) == 8*1024**2+21
    assert rows[0]['offset'] == 7 and rows[-1]['offset']+rows[-1]['length'] == 8*1024**2+28
    assert all(row['length'] > 0 for row in rows)


def test_stream_failed_regions_share_one_retry_and_tail_expiry(tmp_path, monkeypatch):
    from collections import OrderedDict
    for name in ('_CACHE_DONE', '_CACHE_PENDING'):
        monkeypatch.setattr(runtime, name, OrderedDict())
    monkeypatch.setattr(runtime, '_COMPLETED_CACHE_FILES', set())
    monkeypatch.setattr(runtime, '_COMPLETED_CACHE_ROOT', tmp_path)
    path = tmp_path/'regions'; path.write_bytes(b'x'*1024)
    calls = []
    monkeypatch.setattr(runtime, 'advise_consumed_stream',
        lambda stream, **kw: calls.append(kw) or 'UNKNOWN')
    with runtime.ConsumedStream(path.open('rb')) as stream:
        stream.seek(7); stream.read(13)
        stream.seek(50); stream.read(20)
    row = next(iter(runtime._CACHE_PENDING.values()))
    assert row['attempts'] == 1 and row['ranges'] == [(7, 20), (50, 70)]
    runtime.drain_completed_io()
    assert calls == [{'offset':7, 'length':13}, {'offset':50, 'length':20}]*2
    assert not runtime._CACHE_PENDING
    runtime.mark_cache_use([path])
    runtime.advise_completed_io([path], sync=False, new_consumption=False)
    row = next(iter(runtime._CACHE_PENDING.values()))
    monkeypatch.setattr(runtime, 'monotonic', lambda: row['started']+301)
    count = len(calls)
    runtime.advise_completed_io([path], sync=False, new_consumption=False)
    assert len(calls) == count and not runtime._CACHE_PENDING


def test_carrier_last_child_owns_physical_read_advice(tmp_path, monkeypatch):
    from padml.carriers import open_carrier
    path = tmp_path / 'carrier.zip'
    write_deterministic_zip(path, {'data': b'engineering-data'})
    rows = []
    monkeypatch.setattr(runtime, 'advise_consumed_stream', lambda stream, **kw: rows.append(kw) or 'ADVISED')
    archive = open_carrier(path)
    member = archive.open('data')
    archive.close()
    assert not rows
    assert member.read() == b'engineering-data'
    assert not rows
    member.close()
    assert rows and all(row['length'] > 0 for row in rows)


def test_actual_fd_and_closed_fd_mmap_block_advice_then_closed_file_is_advised(tmp_path):
    path = tmp_path / "UNFITTED-owned.bin"
    path.write_bytes(b"UNFITTED" * (256 * 1024))
    original = (sha256_file(path), path.stat().st_size)
    with path.open("rb") as handle:
        assert _release(path)["files"][0]["status"] == "ACTIVE_READER_OR_WRITER"
        mapping = mmap.mmap(handle.fileno(), 0, access=mmap.ACCESS_READ)
    try:
        assert _release(path)["files"][0]["status"] == "ACTIVE_READER_OR_WRITER"
    finally:
        mapping.close()
    report = _release(path)
    assert report["files"][0]["status"] == "ADVISED"
    assert (sha256_file(path), path.stat().st_size) == original
    assert report["before"]["pid"] == report["after"]["pid"] == os.getpid()
    assert report["before"]["clock"] == "MONOTONIC_NS"
    assert report["claim"] == "ADVISORY_ONLY_NONATOMIC_OBSERVATIONS_NOT_ATTRIBUTION"
    runtime.validate_resource_release(report)


def test_unknown_reader_scope_does_not_call_advice(tmp_path, monkeypatch):
    path = tmp_path / "UNFITTED-owned.bin"
    path.write_bytes(b"UNFITTED")
    def inaccessible(_candidates):
        raise PermissionError("UNFITTED /proc reader scope unavailable")
    monkeypatch.setattr(runtime, "_visible_open_file_keys", inaccessible)
    monkeypatch.setattr(runtime.os, "posix_fadvise", lambda *args: pytest.fail("NO_ADVICE_WITH_UNKNOWN_READERS"))
    report = _release(path)
    assert report["reader_scan_status"] == report["files"][0]["status"] == "UNKNOWN"
    assert path.read_bytes() == b"UNFITTED"


@pytest.mark.parametrize("alias", ["symlink", "hardlink"])
def test_alias_never_advised(tmp_path, monkeypatch, alias):
    source, target = tmp_path / "source", tmp_path / "alias"
    source.write_bytes(b"UNFITTED")
    if alias == "symlink":
        target.symlink_to(source)
    else:
        os.link(source, target)
    monkeypatch.setattr(runtime.os, "posix_fadvise", lambda *args: pytest.fail("NO_ALIAS_ADVICE"))
    with pytest.raises(ContractError, match="RESOURCE_RELEASE_(PATH|FILE)_INVALID"):
        _release(target)
    assert source.read_bytes() == b"UNFITTED"


def test_scan_only_retains_candidates_and_empty_set_does_not_scan(tmp_path, monkeypatch):
    first, second = tmp_path / "first", tmp_path / "second"
    first.write_bytes(b"UNFITTED"); second.write_bytes(b"UNFITTED")
    value = first.stat()
    with first.open("rb"), second.open("rb"):
        keys, count = runtime._visible_open_file_keys({(value.st_dev, value.st_ino)})
    assert keys == {(value.st_dev, value.st_ino)} and count > 0
    monkeypatch.setattr(Path, "iterdir", lambda *args: pytest.fail("EMPTY_SCOPE_MUST_NOT_SCAN"))
    assert runtime._visible_open_file_keys(set()) == (set(), 0)


def test_reader_rejects_fake_released_byte_claim_and_bad_counter(tmp_path):
    path = tmp_path / "UNFITTED-owned.bin"
    path.write_bytes(b"UNFITTED")
    report = _release(path)
    bad = copy.deepcopy(report)
    bad["freed_bytes"] = path.stat().st_size
    with pytest.raises(ContractError, match="RESOURCE_RELEASE_REPORT_INVALID"):
        runtime.validate_resource_release(bad)
    bad = copy.deepcopy(report)
    bad["after"]["rss_bytes"] = -1
    with pytest.raises(ContractError, match="RESOURCE_RELEASE_MEMORY_INVALID"):
        runtime.validate_resource_release(bad)


def test_lifetime_maxrss_linux_units_identity_and_old_release_reader(tmp_path, monkeypatch):
    _memory_host(tmp_path, monkeypatch)
    original = Path.read_text
    def read(path, *args, **kwargs):
        if str(path) == "/proc/self/stat":
            return f"{os.getpid()} (UNFITTED comm ) has ( spaces) " + " ".join(
                ["R", *["0"] * 18, "12345", "0"])
        return original(path, *args, **kwargs)
    monkeypatch.setattr(Path, "read_text", read)
    monkeypatch.setattr(resource, "getrusage", lambda who: SimpleNamespace(
        ru_maxrss=73 if who == resource.RUSAGE_SELF else 8192))
    before = runtime.observe_step_memory()
    peak = before["lifetime_maxrss"]
    assert peak == {"status": "OBSERVED", "source": "LINUX_GETRUSAGE", "unit": "BYTES",
        "scope": "LIFETIME_SELF_AND_MAX_REAPED_CHILD", "process_start_ticks": 12345,
        "self_bytes": 73 * 1024, "children_bytes": 8192 * 1024}
    report = runtime.release_step_resources([], owner="UNFITTED_MAXRSS", before=before, released_references=[])
    runtime.validate_resource_release(report)
    assert runtime._available_memory_bytes() == 200  # no RSS/cache/peak subtraction
    legacy = copy.deepcopy(report)
    for side in ("before", "after"):
        del legacy[side]["lifetime_maxrss"]
    runtime.validate_resource_release(legacy)
    for damage in ("unit", "bool", "negative", "pid-incarnation", "decrease", "child-decrease", "mixed-old", "unknown-zero", "tree"):
        bad = copy.deepcopy(report)
        altered = bad["after"]["lifetime_maxrss"]
        if damage == "unit":
            altered["unit"] = "KIB"
        elif damage == "bool":
            altered["self_bytes"] = True
        elif damage == "negative":
            altered["children_bytes"] = -1
        elif damage == "pid-incarnation":
            altered["process_start_ticks"] += 1
        elif damage == "decrease":
            altered["self_bytes"] -= 1
        elif damage == "child-decrease":
            altered["children_bytes"] -= 1
        elif damage == "mixed-old":
            del bad["before"]["lifetime_maxrss"]
        elif damage == "unknown-zero":
            altered.update(status="UNKNOWN", process_start_ticks=None, self_bytes=0, children_bytes=0)
        else:
            altered["scope"] = "LIVE_PROCESS_TREE_TOTAL"
        with pytest.raises(ContractError, match="RESOURCE_RELEASE_MAXRSS_INVALID"):
            runtime.validate_resource_release(bad)


@pytest.mark.parametrize("damage", ["missing-stat", "wrong-pid", "short-stat", "bad-start", "missing-usage", "fractional-usage"])
def test_lifetime_maxrss_unknown_never_changes_admission(tmp_path, monkeypatch, damage):
    _memory_host(tmp_path, monkeypatch)
    original = Path.read_text
    def read(path, *args, **kwargs):
        if str(path) == "/proc/self/stat":
            if damage == "missing-stat":
                raise FileNotFoundError("UNFITTED hidden stat")
            if damage == "short-stat":
                return f"{os.getpid()} (UNFITTED) R 0"
            return f"{os.getpid() + (damage == 'wrong-pid')} (UNFITTED) " + " ".join(
                ["R", *["0"] * 18, "bad" if damage == "bad-start" else "12345"])
        return original(path, *args, **kwargs)
    def usage(_who):
        if damage == "missing-usage":
            raise OSError("UNFITTED unavailable usage")
        return SimpleNamespace(ru_maxrss=3.5 if damage == "fractional-usage" else 73)
    monkeypatch.setattr(Path, "read_text", read)
    monkeypatch.setattr(resource, "getrusage", usage)
    before = runtime.observe_step_memory()
    assert before["lifetime_maxrss"]["status"] == "UNKNOWN"
    assert all(before["lifetime_maxrss"][key] is None for key in ("process_start_ticks", "self_bytes", "children_bytes"))
    runtime.release_step_resources([], owner="UNFITTED_UNKNOWN_MAXRSS", before=before, released_references=[])
    assert runtime._available_memory_bytes() == 200


def _short_r_child_task(_index):
    before = runtime.observe_step_memory()
    assert before["lifetime_maxrss"]["status"] == "OBSERVED"
    assert before["lifetime_maxrss"]["children_bytes"] == 0
    # Allocation only: no patient data, model fitting, metrics or RNG. The
    # original subprocess.run owner waits; diagnostics introduce no reaper.
    child = subprocess.run([runtime.RSCRIPT_EXECUTABLE, "--vanilla", "-e",
        "x <- raw(64L * 1024L * 1024L); invisible(x)"], check=True,
        env={**os.environ, **runtime.THREAD_ENV, "R_LIBS_USER": runtime.R_LIBRARY},
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=30)
    assert child.returncode == 0 and child.stdout == b""
    return runtime.release_step_resources([], owner="UNFITTED_REAPED_R", before=before, released_references=[])


def test_lifetime_maxrss_retains_short_reaped_r_child_without_new_reaper():
    releases = {}
    report, = runtime._bounded_ordered_spawn(_short_r_child_task, [0], selected_slots=1,
        resource_release_report=releases)
    runtime.validate_resource_release(report)
    before = report["before"]
    peak = report["after"]["lifetime_maxrss"]
    assert peak["status"] == "OBSERVED" and peak["children_bytes"] >= 64 * 1024**2
    assert peak["children_bytes"] >= before["lifetime_maxrss"]["children_bytes"]
    assert peak["process_start_ticks"] == before["lifetime_maxrss"]["process_start_ticks"]
    assert before["lifetime_maxrss"]["children_bytes"] == 0
    assert before["pid"] != os.getpid()
    runtime.validate_resource_release(releases["0"])
    assert releases["0"]["after"]["lifetime_maxrss"]["children_bytes"] >= peak["children_bytes"]


def _policy():
    return {"configured_worker_ceiling": runtime.CPU_MINUS_8, "memory_bytes_per_worker": 64 * 1024**2,
            "scratch_bytes_per_worker": 64 * 1024**2, "memory_reserve_bytes": 2 * 1024**3,
            "scratch_reserve_bytes": 2 * 1024**3, "transfer_archive_worker_ceiling": 24}


def _unfitted_completed_q(tmp_path):
    from padml import f4
    source = tmp_path / "source.zip"
    f4.compile_f45_source_bundle(source)
    identity = sha256_bytes(canonical_json_bytes(f4._f45_source_member_sha256()))
    root, batch = tmp_path / "q", tmp_path / "batch"
    (root / "native/U1").mkdir(parents=True)
    batch.mkdir()
    (root / "input.json").write_bytes(b'{"UNFITTED":true}')
    (root / "native/U1/model.bin").write_bytes(b"UNFITTED native evidence, never a loadable model")
    def ref(path):
        return {"sha256": sha256_file(path), "size_bytes": path.stat().st_size}
    report = {"phase": "UNFITTED", "source_identity": identity, "input": ref(root / "input.json"),
        "task_ids": ["U1"], "new_model_fit_count": 1, "confirmed_first_native_audit_count": 1,
        "pool": {"status": "COMPLETED", "completed_task_count": 1, "runnable_task_count": 1},
        "units": [{"task_id": "U1", "native_units": ["U1"], "first_native_audit_count": 1,
                   "members": {"native/U1/model.bin": ref(root / "native/U1/model.bin")}}]}
    path = batch / "execution.json"
    path.write_bytes(canonical_json_bytes(report))
    return source, root, path, ref(path)


def test_completed_cleanup_preserves_originals_and_never_enters_science(tmp_path, monkeypatch):
    from padml import f4, f5, f5_sensitivity as sensitivity
    source, root, path, pin = _unfitted_completed_q(tmp_path)
    originals = {p: p.read_bytes() for p in [path, source, *root.rglob("*")] if p.is_file()}
    def forbidden(*args, **kwargs):
        pytest.fail("PURE_RELEASE_MUST_NOT_ENTER_SCIENCE_OR_PREPARATION")
    for module, name in [(f5, "_run_final_complex_search"), (f5, "_execute_final_refit_engine"),
                         (f5, "_bounded_ordered_spawn"), (sensitivity, "materialize_a12_total_mice_view"),
                         (sensitivity, "_run_a12_total_mice_input")]:
        monkeypatch.setattr(module, name, forbidden)
    result = f5.release_completed_step(path, root, tmp_path / "current-execution.json",
        expected_report=pin, producer_source_bundle=source, resource_policy=_policy())
    assert result["new_model_fits"] == result["new_mice_chains"] == result["new_native_replays"] == result["new_metric_jobs"] == 0
    assert result["resource_release"]["files"][0]["status"] == "ADVISED"
    assert result["executor_source_identity"] == sha256_bytes(canonical_json_bytes(f4._f45_source_member_sha256()))
    assert all(p.read_bytes() == raw for p, raw in originals.items())
    assert {p for p in root.rglob("*") if p.is_file()} == {p for p in originals if p.is_relative_to(root)}


@pytest.mark.parametrize("damage", ["inside-native", "inside-batch", "report-pin", "report-race", "member-drift", "incomplete-pool"])
def test_completed_cleanup_rejects_bad_scope_or_independent_pin_before_advice(tmp_path, monkeypatch, damage):
    from padml import f5
    import json
    source, root, path, pin = _unfitted_completed_q(tmp_path)
    target = tmp_path / "current-execution.json"
    if damage == "inside-native":
        target = root / "native/U1/release.json"
    elif damage == "inside-batch":
        target = path.parent / "release.json"
    elif damage == "report-pin":
        pin["sha256"] = "0" * 64
    elif damage == "report-race":
        original_hash = f5.sha256_file
        def replaced_after_check(target):
            digest = original_hash(target)
            if target == path:
                report = json.loads(path.read_bytes())
                report["phase"] = "UNFITTED_REPLACED_AFTER_FIRST_HASH"
                path.write_bytes(canonical_json_bytes(report))
            return digest
        monkeypatch.setattr(f5, "sha256_file", replaced_after_check)
    elif damage == "member-drift":
        (root / "native/U1/model.bin").write_bytes(b"UNFITTED tampered")
    else:
        report = json.loads(path.read_bytes())
        report["pool"]["completed_task_count"] = 0
        path.write_bytes(canonical_json_bytes(report))
        pin = {"sha256": sha256_file(path), "size_bytes": path.stat().st_size}
    monkeypatch.setattr(runtime.os, "posix_fadvise", lambda *args: pytest.fail("NO_ADVICE_FOR_INVALID_SCOPE"))
    with pytest.raises(ContractError, match="F5_RELEASE_"):
        f5.release_completed_step(path, root, target, expected_report=pin,
            producer_source_bundle=source, resource_policy=_policy())
    assert not target.exists()


def test_completed_cleanup_preserves_observation_when_post_admission_fails(tmp_path, monkeypatch):
    from padml import f5
    import json
    source, root, path, pin = _unfitted_completed_q(tmp_path)
    original = runtime.observe_execution_resources
    observations = []
    def observe(target):
        value = original(target)
        if observations:
            value["available_memory_bytes"] = 1
        observations.append(value)
        return value
    monkeypatch.setattr(runtime, "observe_execution_resources", observe)
    target = tmp_path / "blocked-execution.json"
    with pytest.raises(ContractError, match="RESOURCE_ADMISSION_ZERO"):
        f5.release_completed_step(path, root, target, expected_report=pin,
            producer_source_bundle=source, resource_policy=_policy())
    report = json.loads(target.read_bytes())
    assert report["status"] == "RESOURCE_RELEASE_OBSERVED_ADMISSION_BLOCKED"
    assert report["post_release_resource_admission"] is None
    assert "RESOURCE_ADMISSION_ZERO" in report["post_release_error"]
    runtime.validate_resource_release(report["resource_release"])
    assert report["new_model_fits"] == report["new_mice_chains"] == 0


def _unfitted_legacy_packet(tmp_path):
    import json
    coordinate = "A12_WITHOUT_AST_ALT_TOTAL/OUTER_ANALYSIS"
    source = tmp_path / "original-input.zip"
    source.write_bytes(b"UNFITTED original projected input bytes")
    value = {"identity_sha256": "1" * 64, "outer_fold": 1, "family": "COXTIME_SET_A",
             "mice_inputs": [{"estimand": coordinate.split("/")[0], "view_id": "OUTER_ANALYSIS"}],
             "resource_policy": _policy()}
    pool = {"status": "COMPLETED", "completed_task_count": 1}
    execution = {"view_ids": [coordinate], "projected_input_identity_sha256": value["identity_sha256"], "mice_pool": pool}
    output = {"view_ids": [coordinate], "status": "COMPUTED_NATIVE_VIEWS", "stage_acceptance": False,
              "outer_fold": 1, "family": value["family"], "execution_report": execution,
              "model_fit_count": 0, "selector_path_count": 0, "mice_chain_execution_count": 20}
    identity = "1513ecba963857099c6b99413b8e976393c551a3ec30ed90da1cb14178338bd7"
    report = b'{"UNFITTED_legacy_report":true}'
    handle = {"name": coordinate, "result_path": "/UNFITTED/numerical.zip.json", "result_sha256": sha256_bytes(report),
              "result_size_bytes": len(report), "status": "COMPUTED", "stage_acceptance": False}
    entries = {"batch/execution.json": canonical_json_bytes(execution),
               "batch/mice-results.json": canonical_json_bytes([handle]),
               "cli/H7-view.stdout": json.dumps(output).encode(), "cli/H7-view.stderr": b"",
               "cli/H7-view-execution.json": canonical_json_bytes({"source_identity": identity, "exit_code": 0, "view_ids": [coordinate]}),
               "views/" + coordinate + "/numerical.zip.json": report,
               "views/" + coordinate + "/numerical.zip": b"UNFITTED numerical bytes not consumed by pin reader"}
    entries["cli/H7-view-execution.json"] = canonical_json_bytes({"source_identity": identity, "exit_code": 0,
        "view_ids": [coordinate], "stdout_sha256": sha256_bytes(entries["cli/H7-view.stdout"]),
        "stderr_sha256": sha256_bytes(entries["cli/H7-view.stderr"])})
    collection = {"source_identity": identity, "input_sha256": sha256_file(source), "input_identity_sha256": value["identity_sha256"],
                  "view_ids": [coordinate], "pool": pool,
                  "members": {name: {"sha256": sha256_bytes(raw), "size_bytes": len(raw)} for name, raw in entries.items()}}
    entries["collection.json"] = canonical_json_bytes(collection)
    packet = tmp_path / "original-packet.zip"
    write_deterministic_zip(packet, entries)
    ref = {"object_key": "UNFITTED/independent-original-packet", "sha256": sha256_file(packet), "size_bytes": packet.stat().st_size}
    return source, value, packet, ref, entries, handle


def test_legacy_view_pins_come_from_independently_returned_packet(tmp_path):
    from padml import f5_sensitivity as sensitivity
    source, value, packet, ref, entries, handle = _unfitted_legacy_packet(tmp_path)
    work = tmp_path / "reader"
    work.mkdir()
    pins = sensitivity._retained_a12_view_report_pins([(packet, ref)], source=source, value=value, root=work)
    assert pins == {handle["name"]: {**handle, "packet_reference": ref, "executor_source_identity":
        "1513ecba963857099c6b99413b8e976393c551a3ec30ed90da1cb14178338bd7"}}
    assert not any(path.name.startswith("numerical") for path in work.rglob("*"))


def test_legacy_packet_requires_original_cli_log_digest_binding(tmp_path):
    import json
    from padml import f5_sensitivity as sensitivity
    source, value, packet, ref, entries, _ = _unfitted_legacy_packet(tmp_path)
    name = "cli/H7-view-execution.json"
    cli = json.loads(entries[name])
    cli["stdout_sha256"] = "0" * 64
    entries[name] = canonical_json_bytes(cli)
    collection = json.loads(entries["collection.json"])
    collection["members"][name] = {"sha256": sha256_bytes(entries[name]), "size_bytes": len(entries[name])}
    entries["collection.json"] = canonical_json_bytes(collection)
    invalid = tmp_path / "invalid-binding-packet.zip"
    write_deterministic_zip(invalid, entries)
    ref.update(sha256=sha256_file(invalid), size_bytes=invalid.stat().st_size)
    work = tmp_path / "reader"
    work.mkdir()
    with pytest.raises(ContractError, match="F5_A12_RETAINED_PACKET_EXECUTION_INVALID"):
        sensitivity._retained_a12_view_report_pins([(invalid, ref)], source=source, value=value, root=work)


def test_rehashed_local_candidate_cannot_replace_independent_old_packet_pin(tmp_path):
    import json
    from padml import f5_sensitivity as sensitivity
    source, value, packet, ref, entries, handle = _unfitted_legacy_packet(tmp_path)
    report_name = "views/" + handle["name"] + "/numerical.zip.json"
    entries[report_name] = b'{"UNFITTED_stripped_current_diagnostics":true}'
    handle.update(result_sha256=sha256_bytes(entries[report_name]), result_size_bytes=len(entries[report_name]))
    entries["batch/mice-results.json"] = canonical_json_bytes([handle])
    collection = json.loads(entries["collection.json"])
    collection["members"] = {name: {"sha256": sha256_bytes(raw), "size_bytes": len(raw)}
                             for name, raw in entries.items() if name != "collection.json"}
    entries["collection.json"] = canonical_json_bytes(collection)
    candidate = tmp_path / "rewritten-packet.zip"
    write_deterministic_zip(candidate, entries)
    work = tmp_path / "reader"
    work.mkdir()
    with pytest.raises(ContractError, match="F5_A12_RETAINED_PACKET_DRIFT"):
        sensitivity._retained_a12_view_report_pins([(candidate, ref)], source=source, value=value, root=work)
    assert list(work.iterdir()) == []


def test_release_view_packet_requires_its_actual_executor_bundle_and_original_pins(tmp_path, monkeypatch):
    import json
    from padml import f5_sensitivity as sensitivity
    bundle_name = os.environ.get("PADML_RETAINED_AAR_VIEW_SOURCE_BUNDLE")
    if bundle_name is None:
        pytest.skip("The exact code-only 1e9 view producer is required")
    bundle = Path(bundle_name)
    source, value, _, _, entries, handle = _unfitted_legacy_packet(tmp_path)
    legacy = "1513ecba963857099c6b99413b8e976393c551a3ec30ed90da1cb14178338bd7"
    executor = "1e9b98e5f7f640155bff611e94ba322b402114440eb2fbeef34d7f2c88e36268"
    cli_name = "cli/H7-view-execution.json"
    cli = json.loads(entries[cli_name])
    cli["source_identity"] = executor
    entries[cli_name] = canonical_json_bytes(cli)
    collection = json.loads(entries["collection.json"])
    collection.update(source_identity=executor, producer_source_identity=legacy)
    collection["members"][cli_name] = {"sha256": sha256_bytes(entries[cli_name]), "size_bytes": len(entries[cli_name])}
    entries["collection.json"] = canonical_json_bytes(collection)
    packet = tmp_path / "release-original-packet.zip"
    write_deterministic_zip(packet, entries)
    ref = {"object_key": "UNFITTED/independent-release-packet", "sha256": sha256_file(packet),
           "size_bytes": packet.stat().st_size}
    denied, work = tmp_path / "missing-executor", tmp_path / "reader-release"
    denied.mkdir(); work.mkdir()
    with pytest.raises(ContractError, match="F5_A12_RETAINED_PACKET_SOURCE_INVALID"):
        sensitivity._retained_a12_view_report_pins([(packet, ref)], source=source, value=value, root=denied)
    pins = sensitivity._retained_a12_view_report_pins([(packet, ref)], source=source, value=value, root=work,
        retained_view_source_bundle=bundle)
    from padml.f4 import load_f45_source_bundle
    assert pins == {handle["name"]: {**handle, "executor_source_identity": executor, "packet_reference": ref,
        "retained_source_bundle": {"sha256": sha256_file(bundle), "size_bytes": bundle.stat().st_size,
                                   "manifest_identity_sha256": load_f45_source_bundle(bundle)["identity_sha256"]}}}
    # This helper binds report bytes only. It never accepts the deliberately
    # UNFITTED report's scientific contents or downgrades a 1e9 report to legacy.
    assert not any(path.name.startswith("numerical") for path in work.rglob("*"))
    entries["views/" + handle["name"] + "/numerical.zip.json"] = b'{"UNFITTED_changed_report":true}'
    changed = tmp_path / "changed-release-packet.zip"
    write_deterministic_zip(changed, entries)
    with pytest.raises(ContractError, match="F5_A12_RETAINED_PACKET_DRIFT"):
        sensitivity._retained_a12_view_report_pins([(changed, ref)], source=source, value=value, root=denied,
            retained_view_source_bundle=bundle)
    # Isolate the gather's direct report consumer: an honestly pinned 1e9
    # packet may not use missing diagnostics to enter the 1513 UNKNOWN branch.
    # The real old-source/M20 numerical reader is tested separately.
    projected = tmp_path / "UNFITTED-projected.zip"
    write_deterministic_zip(projected, {"UNFITTED": b"only report admission is exercised"})
    report = {"sha256": "a" * 64, "size_bytes": 1, "status": "COMPUTED", "stage_acceptance": False,
        "numerical_view": {"spec": {"nested_aar_source": {"estimand": handle["name"].split("/")[0]},
                                     "view": {"view_id": "OUTER_ANALYSIS"}}},
        "execution_report": {}, "first_audit_execution_report": {}, "resource_admission": {},
        "resource_observation": {}, "retained_bytes_limit": 1, "retained_bytes_before_report": 1}
    report_path = tmp_path / "missing-release.zip.json"
    report_path.write_bytes(canonical_json_bytes(report))
    report_name = "views/" + handle["name"] + "/numerical.zip.json"
    entries[report_name] = report_path.read_bytes()
    handle.update(result_sha256=sha256_bytes(entries[report_name]), result_size_bytes=len(entries[report_name]))
    entries["batch/mice-results.json"] = canonical_json_bytes([handle])
    collection.update(input_sha256=sha256_file(projected), members={name: {
        "sha256": sha256_bytes(raw), "size_bytes": len(raw)} for name, raw in entries.items() if name != "collection.json"})
    entries["collection.json"] = canonical_json_bytes(collection)
    missing = tmp_path / "missing-diagnostics-original-packet.zip"
    write_deterministic_zip(missing, entries)
    pin = {**ref, "sha256": sha256_file(missing), "size_bytes": missing.stat().st_size}
    monkeypatch.setattr(sensitivity, "_load_a12_projected_outer_inputs", lambda *args, **kwargs: {"input": value, "root": tmp_path})
    monkeypatch.setattr(sensitivity, "_materialize_a12_projected_branches", lambda *args, **kwargs: pytest.fail("NO_NUMERICAL_OR_NATIVE_WORK"))
    with pytest.raises(ContractError, match="F5_A12_VIEW_EXECUTOR_SOURCE_MISMATCH"):
        sensitivity.execute_a12_outer_inputs(projected, tmp_path / "never-gathered.zip", view_results=[report_path],
            retained_primary_source_bundle=Path(os.environ["PADML_RETAINED_FULL0_SOURCE_BUNDLE"]),
            retained_view_source_bundle=bundle, retained_view_batches=[(missing, pin)])
    assert not (tmp_path / "never-gathered.zip").exists()


def test_retained_a1_source_proof_covers_decorators_and_mixed_producers(tmp_path, monkeypatch):
    from padml import f4, f5_sensitivity as sensitivity
    archived = os.environ.get("PADML_RETAINED_AAR_RESTORATION_SOURCE_BUNDLE")
    release = os.environ.get("PADML_RETAINED_AAR_VIEW_SOURCE_BUNDLE")
    if archived is None or release is None:
        pytest.skip("Both exact code-only retained view producers are required")
    source, value, packet, ref, _, _ = _unfitted_legacy_packet(tmp_path)
    roots = [tmp_path / name for name in ("mixed", "duplicate", "decorator")]
    for root in roots:
        root.mkdir()
    pins = sensitivity._retained_a12_view_report_pins([(packet, ref)], source=source, value=value, root=roots[0],
        retained_view_source_bundle=[Path(release), Path(archived)])
    assert len(pins) == 1
    with pytest.raises(ContractError, match="RETAINED_VIEW_EXECUTOR_SOURCE_INVALID"):
        sensitivity._retained_a12_view_report_pins([(packet, ref)], source=source, value=value, root=roots[1],
            retained_view_source_bundle=[Path(archived), Path(archived)])
    current = f4._f45_source_member_sha256()
    path = Path(f4.__file__).resolve().parent / "f5.py"
    raw = path.read_bytes()
    changed = raw.replace(b"@contextmanager\ndef _materialized_full_data_development_sources", 
                          b"@UNFITTED_BAD_DECORATOR\ndef _materialized_full_data_development_sources", 1)
    assert changed != raw
    read = Path.read_bytes
    monkeypatch.setattr(Path, "read_bytes", lambda self: changed if self == path else read(self))
    monkeypatch.setattr(f4, "_f45_source_member_sha256", lambda: {**current, "padml/f5.py": sha256_bytes(changed)})
    with pytest.raises(ContractError, match="RETAINED_VIEW_MICE_DEPENDENCY_DRIFT"):
        sensitivity._retained_a12_view_report_pins([(packet, ref)], source=source, value=value, root=roots[2],
            retained_view_source_bundle=Path(archived))


def _unfitted_complete_view_delivery(tmp_path, monkeypatch):
    """Transport/report boundary only; the downstream M20 reader is a sentinel."""
    from padml import f4, f5_sensitivity as sensitivity, nested_loco as nested
    name = "A12_WITHOUT_AST_ALT_TOTAL/INNER_R1_K2_ANALYSIS"
    original = tmp_path / "original-view.zip"
    original.write_bytes(b"UNFITTED original view input, no clinical data")
    policy = _policy()
    index = nested._sealed({"kind": "PADML_F5_A12_PROJECTED_OUTER_INPUTS_V1", "outer_fold": 3, "family": "GBM_COX",
        "mice_inputs": [{"estimand": name.split("/")[0], "view_id": name.split("/")[1], "member": original.name}],
        "resource_policy": policy})
    source = tmp_path / "projected.zip"
    write_deterministic_zip(source, {"a12-inputs.json": canonical_json_bytes(index), original.name: original})
    authority = {"original_projected_input": {"sha256": sha256_file(source), "identity_sha256": index["identity_sha256"]},
                 "atomic_units": []}
    monkeypatch.setattr(nested, "_aar3_mice_view_restoration_contract", lambda: authority)
    monkeypatch.setattr(sensitivity, "_load_a12_projected_outer_inputs", lambda *args, **kwargs: {"input": index, "root": tmp_path})
    monkeypatch.setattr(sensitivity, "_a12_mice_numerical_policy", lambda *args, **kwargs: policy)
    def boundary(*args, **kwargs):
        raise ContractError("UNFITTED_M20_SCIENTIFIC_READER_BOUNDARY")
    monkeypatch.setattr(sensitivity, "_materialize_a12_projected_branches", boundary)
    monkeypatch.setattr(sensitivity, "_execute_a12_total_view_job", lambda *args: pytest.fail("NO_FIT_OR_REPLAY"))
    observation = {"effective_cpus": 32, "available_memory_bytes": 10**12, "scratch_available_bytes": 10**12,
                   "scratch_root": str(tmp_path)}
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda root: {**observation, "scratch_root": str(root)})
    execution = {"configured_worker_ceiling": 24, "admitted_worker_ceiling": 1, "actual_worker_process_peak": 1,
                 "runnable_task_count": 1, "completed_task_count": 1, "engine_threads": 1, "status": "COMPLETED"}
    numerical = b"UNFITTED complete-view transport bytes; scientific reader not invoked"
    numbers = {"spec": {"nested_aar_source": {"estimand": name.split("/")[0]}, "view": {"view_id": name.split("/")[1]}},
               "native_archive": {"sha256": "a" * 64, "size_bytes": 1},
               "members": {"input.zip": {"sha256": sha256_file(original), "size_bytes": original.stat().st_size}}}
    report = {"sha256": sha256_bytes(numerical), "size_bytes": len(numerical), "status": "COMPUTED", "stage_acceptance": False,
              "numerical_view": numbers, "execution_report": execution, "first_audit_execution_report": execution,
              "resource_observation": observation, "resource_admission": runtime.resource_admission(policy, observation, legal_tasks=1),
              "retained_bytes_limit": 128 * 1024**2, "retained_bytes_before_report": 4096}
    pin = {"sha256": sha256_bytes(canonical_json_bytes(report)), "size_bytes": len(canonical_json_bytes(report))}
    monkeypatch.setattr(sensitivity, "_a12_retained_complete_view_report_pins", lambda: {name: pin})
    coordinate = tmp_path / "UNFITTED-legacy-owner" / name
    coordinate.mkdir(parents=True)
    monkeypatch.setattr(sensitivity, "_a12_mice_restoration_coordinate_root",
        lambda unit: tmp_path / "UNFITTED-legacy-owner" / unit["estimand"] / unit["view_id"])
    (coordinate / "numerical.zip").write_bytes(numerical)
    (coordinate / "numerical.zip.json").write_bytes(canonical_json_bytes(report))
    release = runtime.release_step_resources([coordinate / "numerical.zip", coordinate / "numerical.zip.json"],
        owner="AAR_RETAINED_VIEW_DELIVERY:3:" + sha256_bytes(canonical_json_bytes([name])),
        before=runtime.observe_step_memory(), released_references=[])
    delivery = {"executor_source_identity": sha256_bytes(canonical_json_bytes(f4._f45_source_member_sha256())),
        "historical_batch_status": "UNKNOWN", "view_ids": [name], "original_report_pins": {name: pin}, "resource_release": release,
        **{key: 0 for key in ("new_model_fits", "new_stop_fits", "new_mice_chains", "new_mice_fit_invocations",
                             "new_native_replay_invocations", "new_selector_paths", "new_glmnet_calls")}}
    return source, index, name, numerical, report, pin, delivery


@pytest.mark.parametrize("damage", ["none", "report", "input", "native", "strip", "extra_fit", "unknown_release", "active_reader", "unrelated_file"])
def test_complete_view_delivery_cannot_replace_old_report_or_recreate_batch(tmp_path, monkeypatch, damage):
    from padml import f5_sensitivity as sensitivity
    source, index, name, numerical, report, pin, delivery = _unfitted_complete_view_delivery(tmp_path, monkeypatch)
    if damage == "report":
        report["execution_report"] = {**report["execution_report"], "status": "UNKNOWN"}
    elif damage == "input":
        report["numerical_view"]["members"]["input.zip"]["sha256"] = "0" * 64
    elif damage == "native":
        report["numerical_view"]["native_archive"]["sha256"] = "0" * 64
    elif damage == "extra_fit":
        delivery["new_mice_fit_invocations"] = 1
    elif damage == "unknown_release":
        delivery["resource_release"] = {"status": "UNKNOWN", "owner": delivery["resource_release"]["owner"],
                                       "pid": os.getpid(), "reason": "UNFITTED current release unavailable"}
    elif damage == "active_reader":
        delivery["resource_release"]["files"][0]["status"] = "ACTIVE_READER_OR_WRITER"
    elif damage == "unrelated_file":
        delivery["resource_release"]["files"][0]["path"] = str(tmp_path / "UNFITTED-unrelated.bin")
    raw = canonical_json_bytes(report)
    paths = tmp_path / "delivered"
    paths.mkdir()
    report_path = paths / "numerical.zip.json"
    report_path.write_bytes(raw)
    (paths / "numerical.zip").write_bytes(numerical)
    entries = {"views/" + name + "/numerical.zip.json": raw, "views/" + name + "/numerical.zip": numerical}
    # Rehashing the new container cannot alter the independent historical pin.
    if damage in {"report", "input", "native"}:
        delivery["original_report_pins"] = {name: {"sha256": sha256_bytes(raw), "size_bytes": len(raw)}}
    collection = {"source_identity": "1513ecba963857099c6b99413b8e976393c551a3ec30ed90da1cb14178338bd7",
        "input_sha256": sha256_file(source), "input_identity_sha256": index["identity_sha256"], "view_ids": [name],
        "members": {key: {"sha256": sha256_bytes(value), "size_bytes": len(value)} for key, value in entries.items()},
        **({"retained_complete_views": delivery} if damage != "strip" else {})}
    packet = tmp_path / "delivery.zip"
    write_deterministic_zip(packet, {"collection.json": canonical_json_bytes(collection), **entries})
    ref = {"object_key": "UNFITTED/private-delivery", "sha256": sha256_file(packet), "size_bytes": packet.stat().st_size}
    with pytest.raises(ContractError, match="UNFITTED_M20_SCIENTIFIC_READER_BOUNDARY" if damage == "none" else "F5_A12_RETAINED"):
        sensitivity.execute_a12_outer_inputs(source, tmp_path / "never-gathered.zip", view_results=[report_path],
            retained_primary_source_bundle=tmp_path / "UNFITTED-primary-source.zip", retained_view_batches=[(packet, ref)])
    assert not (tmp_path / "never-gathered.zip").exists()


@pytest.mark.parametrize("damage", ["missing_gather_receipt", "strip_all", "strip_delivery", "report", "extra_replay", "unknown_release", "active_reader", "unrelated_file"])
def test_native_v2_requires_coordinate_bound_delivery_after_resealing(tmp_path, monkeypatch, damage):
    from padml import f5_sensitivity as sensitivity, nested_loco as nested
    source, index, name, numerical, report, pin, delivery = _unfitted_complete_view_delivery(tmp_path, monkeypatch)
    numbers = report.pop("numerical_view")
    report["resource_release"] = {"status": "UNKNOWN", "reason": "LEGACY_REPORT_HAS_NO_DIAGNOSTICS", "report_sha256": pin["sha256"]}
    if damage == "report":
        numbers["native_archive"]["sha256"] = "0" * 64
    elif damage == "extra_replay":
        delivery["new_native_replay_invocations"] = 1
    elif damage == "unknown_release":
        delivery["resource_release"] = {"status": "UNKNOWN", "owner": delivery["resource_release"]["owner"],
                                       "pid": os.getpid(), "reason": "UNFITTED current release unavailable"}
    elif damage == "active_reader":
        delivery["resource_release"]["files"][0]["status"] = "ACTIVE_READER_OR_WRITER"
    elif damage == "unrelated_file":
        delivery["resource_release"]["files"][0]["path"] = str(tmp_path / "UNFITTED-unrelated.bin")
    ref = {"object_key": "UNFITTED/private-delivery", "sha256": "b" * 64, "size_bytes": 1}
    binding = {"executor_source_identity": "1513ecba963857099c6b99413b8e976393c551a3ec30ed90da1cb14178338bd7",
        "original_report": pin, "packet_reference": ref,
        **({"retained_complete_view_delivery": delivery} if damage != "strip_delivery" else {})}
    execution = {"view_execution_reports": {name: report}, "retained_view_batches": [{"path": "UNFITTED/packet.zip", **ref}],
                 **({"retained_view_report_bindings": {name: binding}} if damage != "strip_all" else {})}
    entries = {"input.zip": source.read_bytes(), "execution.json": canonical_json_bytes(execution), "views/" + name + ".zip": numerical}
    value = nested._sealed({"kind": "PADML_F5_A12_OUTER_INPUTS_NATIVE_V2", "outer_fold": 3, "family": "GBM_COX",
        "projected_input_identity_sha256": index["identity_sha256"], "stage": "MICE_MATERIALIZED_PRE_DEVELOPMENT",
        "branches": {branch: {} for branch in nested.AAR_ESTIMANDS}, "mice_views": {name: numbers},
        "members": {key: {"sha256": sha256_bytes(raw), "size_bytes": len(raw)} for key, raw in entries.items()}})
    gathered = tmp_path / "gathered.zip"
    write_deterministic_zip(gathered, {"a12-inputs.json": canonical_json_bytes(value), **entries})
    # Valid individual views cannot qualify a fabricated completed GATHER.
    # This fixture intentionally has no independently bound gather receipt.
    with pytest.raises(ContractError, match="F5_A12_RETAINED_GATHER_EXECUTION_RECEIPT_REQUIRED"
                       if damage == "missing_gather_receipt" else "F5_A12_RETAINED"):
        sensitivity.materialize_a12_outer_inputs(gathered, None, tmp_path / "native-reader", input_bundle=source,
            retained_primary_source_bundle=tmp_path / "UNFITTED-primary-source.zip")
