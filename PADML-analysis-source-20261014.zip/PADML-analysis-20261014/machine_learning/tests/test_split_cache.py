from __future__ import annotations

import json
from pathlib import Path

import pytest

import padml.f2_kernel as kernel
from padml.bundle import ContractError


def test_fold_cache_reuses_exact_materialization_without_persisting_evaluation_response(tmp_path: Path, monkeypatch) -> None:
    raw = b"Patient_ID,All_Cause_Death,Death_Followup_months\nfit,1,40\neval,0,50\n"
    fields, by_id = kernel._response_rows(raw)
    counts = {"admit": 0, "materialize": 0}

    def admit(capsule_path, capsule, fold, staging, binding):
        counts["admit"] += 1
        (staging / "mice-fold-1-result").mkdir()
        (staging / "mice-fold-1-payload").mkdir()
        return {"fold": 1}, {"library_index": {"OUTER_APPLICATION": {"sha256": "a" * 64}}}, {"f1_fold_payload_sha256": "b" * 64}

    def materialize(fold_input, binding, response, fold, destination):
        counts["materialize"] += 1
        (destination / "view-sources").mkdir(parents=True)
        root = destination / "partitions/p1"
        covariates = root / "covariates"
        covariates.mkdir(parents=True)
        (covariates / "imp01.csv").write_text("Patient_ID,Center,Age\nfit,36,60\neval,36,50\n")
        fit = kernel._write_response_subset(fields, by_id, ["fit"], root / "fit-response.csv")
        evaluation = kernel._write_response_subset(fields, by_id, ["eval"], None)
        return {
            "identity": "c" * 64,
            "partitions": [{
                "partition_id": "p1", "evaluation_ids": ["eval"],
                "covariates": {"input_dir": str(covariates)},
                "fit_response": fit, "evaluation_response": evaluation,
            }],
            "diagnostic_partitions": [],
        }

    monkeypatch.setattr(kernel, "admitted_f1_fold", admit)
    monkeypatch.setattr(kernel, "_materialize_registered_partitions", materialize)
    request = {"identities": {"source": "1" * 64, "input": "2" * 64}}
    args = (tmp_path / "capsule.zip", {}, request, 1, {}, raw, tmp_path / "cache")
    first = kernel._cached_fold_assets(*args)
    second = kernel._cached_fold_assets(*args)
    assert first == second
    assert counts == {"admit": 1, "materialize": 1}
    manifests = list((tmp_path / "cache").glob("*/cache.json"))
    assert len(manifests) == 1
    manifest = json.loads(manifests[0].read_bytes())
    assert "private_bytes" not in str(manifest)
    assert not (manifests[0].parent / "registered-inputs/view-sources").exists()
    assert first[1]["partitions"][0]["evaluation_response"]["private_bytes"].endswith(b"eval,0,50\n")

    covariate = Path(first[1]["partitions"][0]["covariates"]["input_dir"]) / "imp01.csv"
    covariate.chmod(0o600)
    covariate.write_text(covariate.read_text().replace("eval,36,50", "eval,36,51"))
    covariate.chmod(0o400)
    with pytest.raises(ContractError, match="F2_SPLIT_CACHE_IDENTITY_CHANGED"):
        kernel._cached_fold_assets(*args)


def test_fold_cache_rejects_symlinks_and_writable_members(tmp_path: Path) -> None:
    root = tmp_path / "cache"
    root.mkdir()
    member = root / "input.csv"
    member.write_text("fixture\n")
    with pytest.raises(ContractError, match="F2_SPLIT_CACHE_MEMBER_INVALID"):
        kernel._fold_cache_tree_identity(root)
    member.chmod(0o400)
    kernel._fold_cache_tree_identity(root)
    (root / "alias.csv").symlink_to(member)
    with pytest.raises(ContractError, match="F2_SPLIT_CACHE_MEMBER_INVALID"):
        kernel._fold_cache_tree_identity(root)
