"""Original F4 archive/worker integration; all scientific engines are UNFITTED."""
import csv
import io
import pickle
import shutil
from pathlib import Path
from types import SimpleNamespace

import pytest

from padml import f4, f5, nested_loco as nested, runtime
from padml.bundle import ContractError, canonical_json_bytes, read_safe_zip, sha256_file, strict_json_bytes, write_deterministic_zip
from test_f5 import _test_final_design_recipe
from test_nested_full_development import _unfitted_confirmed_decision, _unfitted_full_lambda_upper
from test_nested_loco import _accepted_model


def _csv(fields, rows):
    stream = io.StringIO(newline="")
    writer = csv.DictWriter(stream, fieldnames=fields, lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
    return stream.getvalue().encode()


def _projection(root, *, outer=1, winner="RSF", fresh_seven=False, selected_parents=None, patients_per_center=6,
                selected_specs=None):
    """Synthetic accepted-source projection, not an accepted F1/F2 source."""
    root.mkdir()
    selected_parents = selected_parents or ["AST_ALT"]
    science_decision = _unfitted_confirmed_decision(fresh_seven=fresh_seven, fixed_bootstrap=fresh_seven)
    all_ids = [f"c{center}-p{index:02d}" for center in (*nested.OUTER_CENTERS, 55) for index in range(patients_per_center)]
    centers = {patient: patient.split("-")[0][1:] for patient in all_ids}
    heldout = [patient for patient in all_ids if centers[patient] == str(nested.OUTER_CENTERS[outer - 1])]
    training = [patient for patient in all_ids if patient not in heldout]
    fields = ["Patient_ID", "All_Cause_Death", "Death_Followup_months"]
    rows = {patient: dict(zip(fields, [patient, "1", "50"], strict=True)) for patient in all_ids}
    response = _csv(fields, [rows[patient] for patient in training])
    context = nested.compile_training_context(
        scope="OUTER", outer_fold=outer, heldout_center=nested.OUTER_CENTERS[outer - 1],
        training_ids=training, heldout_ids=heldout, centers_by_patient=centers, training_response_csv=response,
        mice_member_set_sha256="a" * 64, preprocessing_program_sha256="b" * 64,
        modeling_program_sha256=nested._sha(f4._f45_source_member_sha256()), seed_program_sha256="c" * 64)
    recipes = {family: _test_final_design_recipe(family, selected_parents) for family in nested._families()}
    outer_recipe = recipes["ELASTIC_NET_COX"]["transform_recipe"]
    outer_recipe["partition_id"] = f"OUTER_F{outer}"
    outer_recipe["recipe_sha256"] = nested._sha({key: value for key, value in outer_recipe.items() if key != "recipe_sha256"})
    specs = {
        "COX_PH": {"family": "COX_PH", "ties": "breslow"},
        "ELASTIC_NET_COX": {"family": "ELASTIC_NET_COX", "alpha": .2,
            "ratio_by_imputation": [.1] * 20, "lambda_by_imputation": [.2] * 20,
            "lambda_upper_bound_by_imputation": [_unfitted_full_lambda_upper(outer_recipe)] * 20},
        "FPM_TVC_SET_A": {"family": "FPM_TVC_SET_A", "df": [3, 1], "tvc_parent": "AST_ALT"},
        "RSF": {"family": "RSF", "parameters": {"num.trees": 1000, "mtry_fraction": "0.50",
            "min.node.size": 15, "max.depth": "UNLIMITED", "sample.fraction": .632, "splitrule": "logrank"}},
        "GBM_COX": {"family": "GBM_COX", "selected_trees": 20,
            "parameters": {"interaction.depth": 2, "shrinkage": .05, "n.minobsinnode": 20,
                "bag.fraction": .8, "n.trees.max": 5000, "early_stopping_metric": "cox_deviance",
                "post_selection_refit": "full_main_training_at_selected_n_trees",
                "locked_iteration_mode": "full_main_training_without_reselection"}},
        "XGBOOST_COX": {"family": "XGBOOST_COX", "selected_rounds": 5,
            "parameters": {"eta": .05, "max_depth": 2, "min_child_weight": 2.0,
                "subsample": .8, "colsample_bytree": .8, "reg_lambda": 1., "reg_alpha": 0., "gamma": 0.,
                "tree_method": "hist", "max_bin": 256, "max_nrounds": 20,
                "stop_scope": "training_only", "post_selection_refit": "full_main_training_at_best_rounds",
                "locked_iteration_mode": "full_main_training_without_reselection"}},
    }
    candidate = f5.load_science_authority()["science"]["f2_model_development"]["coxtime"]["candidates"][0]
    specs["COXTIME_SET_A"] = {"family": "COXTIME_SET_A", "candidate_id": candidate["candidate_id"],
                              "parameters": candidate, "locked_epoch": 30}
    if selected_specs is not None:
        specs.update(selected_specs)
    cov_fields = f5.load_science_authority()["science"]["mice"]["private_handoff"]["columns"]

    def component(family, fit, evaluation, repeat, inner, imputation):
        coordinates = {"purpose": "O_FIT" if repeat else "NESTED_OUTER", "outer_fold": outer,
                       "repeat": repeat, "inner_fold": inner, "imputation": imputation}
        seed = f4._f4_model_seed(family, coordinates)
        design = f5._expected_family_parent_column_map(selected_parents, family,
            f5.predictor_contract(Path(f5.__file__).parent), recipes[family]["transform_recipe"])
        task = {"family": family, "selected_parents": selected_parents, "parameters": specs[family],
                "imputation": imputation, "f4_coordinates": coordinates, "registered_model_seed": seed,
                "model_seed": seed if family in {"RSF", "GBM_COX", "XGBOOST_COX", "COXTIME_SET_A"} else None,
                "row_count": len(fit), "family_design_column_count": sum(len(row["columns"]) for row in design)}
        if family == "ELASTIC_NET_COX":
            task["f4_outer_elastic_source"] = {"outer_fold": outer, "selected_spec": specs[family],
                                               "outer_transform_recipe": outer_recipe}
            task["parameters"], _ = f4._f4_elastic_parameters(task["f4_outer_elastic_source"], coordinates)
        def covariates(ids):
            return _csv(cov_fields, [{column: {"Patient_ID": patient, "Center": centers[patient], "Age": 50,
                "Prior_LE_Surgery_cat": ["None", "Procedure", "Amputation", "Other"][int(patient[-2:]) % 4]}.get(column, 1)
                                      for column in cov_fields} for patient in ids])
        path = root / f"{family}-R{repeat}-K{inner}-M{imputation:02d}.zip"
        nested._write_component_archive(path, {"task.json": canonical_json_bytes(task),
            "recipe.json": canonical_json_bytes(recipes[family]), "fit-covariates.csv": covariates(fit),
            "prediction-covariates.csv": covariates(evaluation),
            "fit-response.csv": _csv(fields, [rows[patient] for patient in fit])})
        return path

    partitions, components, reused, templates = [], [], [], {}
    for repeat in range(1, 4):
        for inner in range(1, 6):
            evaluation = [patient for index, patient in enumerate(training) if index % 5 == inner - 1]
            fit = [patient for patient in training if patient not in evaluation]
            partitions.append({"partition_id": f"F{outer}-R{repeat}-K{inner}", "repeat": repeat,
                               "inner_fold": inner, "fit_ids": fit, "evaluation_ids": evaluation})
            for family in nested.outer_fresh_score_families(science_decision):
                for imputation in range(1, 21):
                    components.append({"family": family, "repeat": repeat, "inner_fold": inner, "imputation": imputation,
                        "archive": component(family, fit, evaluation, repeat, inner, imputation)})
    for family in science_decision["training_score_reuse"]["families"]:
        model = _accepted_model(family, .001 if family == winner else .2, outer_fold=outer)
        model.update(selected_spec=specs[family], selected_spec_sha256=nested._sha(specs[family]))
        reused.append(nested.project_accepted_training_score(model, source_result_sha256="d" * 64,
                                                            training_context_sha256=context["identity_sha256"]))
    for family in nested._families():
        templates[family] = [component(family, training, heldout, 0, 0, imp) for imp in range(1, 21)]
    return {"training_context": context, "science_decision": science_decision,
            "f1_identity": "1" * 64, "f2_acceptance_sha256": "2" * 64,
            "selector_evidence_sha256": "e" * 64,
            "reused_training_scores": reused, "training_response_csv": response,
            "development_metadata": {"selected_parents": selected_parents, "common_set_design_df": sum(len(row["columns"])
                for row in f5._expected_family_parent_column_map(selected_parents, "ELASTIC_NET_COX",
                    f5.predictor_contract(Path(f5.__file__).parent), outer_recipe)),
                "training_event_count": len(training), "baseline_policy_sha256": "b" * 64, "seed_policy_sha256": "c" * 64},
            "score_partitions": partitions, "score_components": components, "post_lock_templates": templates}


@pytest.fixture
def outer_bundle(tmp_path, monkeypatch, request):
    options = getattr(request, "param", False)
    projected = _projection(tmp_path / "UNFITTED-projection", **(options if isinstance(options, dict) else {"fresh_seven": options}))
    monkeypatch.setattr(nested, "project_outer_development_from_accepted", lambda **kwargs: projected)
    monkeypatch.setattr(runtime, "effective_cpu_count", lambda: 64)
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda root: {
        "effective_cpus": 64, "available_memory_bytes": 10**12, "scratch_available_bytes": 10**12, "scratch_root": str(root)})
    policy = {"configured_worker_ceiling": "EXECUTION_HOST_C_MINUS_8", "memory_bytes_per_worker": 1000, "scratch_bytes_per_worker": 1000,
              "memory_reserve_bytes": 100, "scratch_reserve_bytes": 100, "transfer_archive_worker_ceiling": 4}
    path = tmp_path / "input.zip"
    compiled = f4.compile_o_fit_bundle(tmp_path, path, outer_fold=1, science_decision=projected["science_decision"],
        resource_policy=policy, retained_bytes_per_component=10**7, expanded_bytes_per_component=10**6, shared_storage_bytes=10**8)
    assert compiled["model_fit_count"] == compiled["heldout_response_member_count"] == 0
    projected["compiled_input_record"] = compiled
    return path, projected


@pytest.mark.parametrize("resource", ["memory", "scratch"])
@pytest.mark.parametrize("shared_source", [False, True])
def test_outer_compiler_rejects_resource_shortfall_before_source_or_directory(tmp_path, monkeypatch, resource, shared_source):
    observed = {"effective_cpus": 64, "available_memory_bytes": 10**12,
                "scratch_available_bytes": 10**12, "scratch_root": str(tmp_path)}
    observed["available_memory_bytes" if resource == "memory" else "scratch_available_bytes"] = 1
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda root: observed)
    def forbidden(**kwargs):
        pytest.fail("Input source decoding must not start after failed resource admission")
    monkeypatch.setattr(nested, "project_outer_development_from_accepted", forbidden)
    target = tmp_path / "input.zip"
    policy = {"configured_worker_ceiling": "EXECUTION_HOST_C_MINUS_8", "memory_bytes_per_worker": 1000,
              "scratch_bytes_per_worker": 1000, "memory_reserve_bytes": 100,
              "scratch_reserve_bytes": 100, "transfer_archive_worker_ceiling": 4}
    with pytest.raises(ContractError, match="RESOURCE_ADMISSION_ZERO"):
        compiler = f4._compile_o_fit_bundle if shared_source else f4.compile_o_fit_bundle
        compiler(tmp_path, target, outer_fold=1,
            science_decision=_unfitted_confirmed_decision(fresh_seven=True, fixed_bootstrap=True),
            resource_policy=policy, retained_bytes_per_component=10**7,
            expanded_bytes_per_component=10**6, shared_storage_bytes=10**8,
            **({"accepted_source_reader": forbidden} if shared_source else {}))
    assert list(tmp_path.iterdir()) == []


@pytest.mark.parametrize("shared_source", [False, True])
@pytest.mark.parametrize("pending", [5000, 10001])
def test_outer_compiler_future_scratch_policy_keeps_actual_write_check(
        tmp_path, monkeypatch, shared_source, pending):
    policy = {"configured_worker_ceiling": runtime.CPU_MINUS_8, "memory_bytes_per_worker": 1000,
              "scratch_bytes_per_worker": 1000, "memory_reserve_bytes": 100,
              "scratch_reserve_bytes": 10**9, "transfer_archive_worker_ceiling": 4}
    observed = {"effective_cpus": 64, "available_memory_bytes": 10**12,
                "scratch_available_bytes": 10000, "scratch_root": str(tmp_path)}
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda root: observed)
    admissions = []
    original_admission = runtime.resource_admission
    def admission(effective, observation, **kwargs):
        admissions.append(dict(effective))
        return original_admission(effective, observation, **kwargs)
    monkeypatch.setattr(runtime, "resource_admission", admission)
    def projector(*args, **kwargs):
        kwargs["admit_io"](pending_bytes=pending, memory_bytes=200)
        raise ContractError("UNFITTED_WRITE_ADMITTED")
    monkeypatch.setattr(nested, "project_outer_development_from_accepted", projector)
    monkeypatch.setattr(nested, "_project_outer_development_from_inputs", projector)
    reason = "UNFITTED_WRITE_ADMITTED" if pending <= 10000 else "ACTUAL_SPACE_INSUFFICIENT"
    with pytest.raises(ContractError, match=reason):
        f4._compile_o_fit_bundle(tmp_path, tmp_path / "input.zip", outer_fold=1,
            science_decision=_unfitted_confirmed_decision(fresh_seven=True, fixed_bootstrap=True),
            resource_policy=policy, retained_bytes_per_component=10**7,
            expanded_bytes_per_component=10**6, shared_storage_bytes=10**8,
            **({"accepted_source_reader": lambda **kwargs: {}} if shared_source else {}))
    assert len(admissions) == (2 if pending <= 10000 else 1)
    assert all(row["scratch_reserve_bytes"] == 0 and row["memory_bytes_per_worker"] == 2 * 1024**3
               and row["configured_worker_ceiling"] == runtime.CPU_MINUS_8 for row in admissions)
    assert admissions[-1]["memory_reserve_bytes"] == (300 if pending <= 10000 else 100)
    assert policy["scratch_reserve_bytes"] == 10**9
    assert not (tmp_path / "input.zip").exists()


@pytest.mark.parametrize("damage", [None, "acceptance", "member", "snapshot", "observer"])
def test_shared_outer_projection_rebinds_original_acceptance_and_members(tmp_path, monkeypatch, damage):
    """Exercise source guards; stop at original F1 admission before any science."""
    result_root = tmp_path / "results"
    result_root.mkdir()
    records = {}
    for family in nested._families():
        unit = nested._accepted_result_unit_id(1, family)
        path = result_root / (unit + ".zip")
        path.write_bytes(("UNFITTED accepted-source guard fixture " + family).encode())
        records[unit] = sha256_file(path)
    acceptance = canonical_json_bytes({"status": "SCIENTIFICALLY_ACCEPTED", "result_sha256": records})
    (tmp_path / "f2-acceptance.json").write_bytes(acceptance)
    snapshot = {"o_fit_source": {}, "accepted_result_sha256": records,
                "source": {"f2_acceptance_sha256": nested.sha256_bytes(acceptance)}}
    calls = {"source": 0, "fold_admission": 0}
    def source(path, **kwargs):
        assert path == tmp_path and kwargs["include_o_fit_source"] is True
        assert callable(kwargs["admit_io"])
        calls["source"] += 1
        return snapshot
    def fold_admission(frozen, outer, target, **kwargs):
        assert frozen is snapshot["o_fit_source"] and outer == 1
        calls["fold_admission"] += 1
        if damage == "observer" and calls["fold_admission"] == 2:
            return {"UNFITTED_ORIGINAL_MATERIALIZATION": True}
        raise ContractError("UNFITTED_ORIGINAL_F1_ADMISSION_REACHED")
    monkeypatch.setattr(f4, "load_f4_inputs", source)
    monkeypatch.setattr(f4, "_materialize_o_fit_fold", fold_admission)
    def admission(**kwargs):
        assert kwargs["memory_bytes"] > 0
    options = {"outer": 1, "science_decision": _unfitted_confirmed_decision(fresh_seven=True, fixed_bootstrap=True),
               "accepted_f2_run_root": tmp_path, "admit_io": admission}
    with pytest.raises(ContractError, match="UNFITTED_ORIGINAL_F1_ADMISSION_REACHED"):
        nested.project_outer_development_from_accepted(**options,
            accepted_f1_runtime_root=None, scratch=tmp_path / "first")
    assert calls == {"source": 1, "fold_admission": 1}
    if damage == "acceptance":
        (tmp_path / "f2-acceptance.json").write_bytes(acceptance + b"\n")
    elif damage == "member":
        (result_root / (next(iter(records)) + ".zip")).write_bytes(b"UNFITTED changed original")
    elif damage == "snapshot":
        snapshot["source"]["f2_acceptance_sha256"] = "0" * 64
    def observe(frozen, outer, registered):
        assert frozen is snapshot["o_fit_source"] and outer == 1
        assert registered == {"UNFITTED_ORIGINAL_MATERIALIZATION": True}
        raise ContractError("UNFITTED_ORIGINAL_MATERIALIZATION_OBSERVED")
    reason = ("UNFITTED_ORIGINAL_MATERIALIZATION_OBSERVED" if damage == "observer" else
              "UNFITTED_ORIGINAL_F1_ADMISSION_REACHED" if damage is None else
              "NESTED_ACCEPTED_SCORE_ARCHIVE_DRIFT" if damage == "member" else
              "NESTED_ACCEPTED_OUTER_SOURCE_INVALID")
    with pytest.raises(ContractError, match=reason):
        nested._project_outer_development_from_inputs(snapshot, **options, scratch=tmp_path / "second",
            **({"on_materialized_fold": observe} if damage == "observer" else {}))
    assert calls == {"source": 1, "fold_admission": 2 if damage in {None, "observer"} else 1}
    assert (tmp_path / "second").exists() is (damage in {None, "observer"})


@pytest.mark.parametrize("has_source", [False, True])
def test_outer_compiler_fold_observer_requires_original_owned_source(tmp_path, monkeypatch, has_source):
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda root: {
        "effective_cpus": 64, "available_memory_bytes": 10**12,
        "scratch_available_bytes": 10**12, "scratch_root": str(root)})
    snapshot, calls = {"UNFITTED_ACCEPTED_SOURCE": True}, []
    def source(*, admit_io):
        assert callable(admit_io)
        calls.append("original_source")
        return snapshot
    def observer(*args):
        pytest.fail("The compiler must not fabricate an admitted materialization")
    def projector(accepted, **kwargs):
        assert accepted is snapshot and kwargs["on_materialized_fold"] is observer
        assert callable(kwargs["admit_io"])
        calls.append("original_projector")
        raise ContractError("UNFITTED_ORIGINAL_PROJECTOR_REACHED")
    monkeypatch.setattr(nested, "_project_outer_development_from_inputs", projector)
    policy = {"configured_worker_ceiling": runtime.CPU_MINUS_8, "memory_bytes_per_worker": 1000,
              "scratch_bytes_per_worker": 1000, "memory_reserve_bytes": 100,
              "scratch_reserve_bytes": 100, "transfer_archive_worker_ceiling": 4}
    reason = "UNFITTED_ORIGINAL_PROJECTOR_REACHED" if has_source else "F4_O_FIT_SHARED_FOLD_SCOPE_INVALID"
    with pytest.raises(ContractError, match=reason):
        f4._compile_o_fit_bundle(tmp_path, tmp_path / "input.zip", outer_fold=1,
            science_decision=_unfitted_confirmed_decision(fresh_seven=True, fixed_bootstrap=True),
            resource_policy=policy, retained_bytes_per_component=10**7,
            expanded_bytes_per_component=10**6, shared_storage_bytes=10**8,
            accepted_source_reader=source if has_source else None, on_materialized_fold=observer)
    assert calls == (["original_source", "original_projector"] if has_source else [])
    assert not (tmp_path / "input.zip").exists()
    assert bool(list(tmp_path.iterdir())) is has_source


def _unfitted_engines(monkeypatch):
    calls = []
    def engine(family, task, training, response, recipe, *, retained_objects=None, prediction_rows=None, **kwargs):
        binary = canonical_json_bytes({"UNFITTED": True, "task": task, "recipe": recipe})
        if retained_objects is None:
            calls.append((family, task["f4_coordinates"]))
        else:
            assert retained_objects[0] == retained_objects[1] == binary
        rows = training if prediction_rows is None else prediction_rows
        curve = [1.] + [.6 if task["imputation"] <= 10 else 1.] * 36
        return {"model": binary, "baseline": binary, "fit_health": {"UNFITTED": True,
                    **({"model_binary_sha256": nested.sha256_bytes(binary)} if family == "XGBOOST_COX" else {})},
                "survival": [curve] * len(rows),
                **({"training_survival": [curve] * len(training)} if kwargs.get("replay_training") else {})}
    def audit(family, model, baseline, health, task, **kwargs):
        assert model == baseline and strict_json_bytes(model)["task"] == task
        assert health == {"UNFITTED": True,
            **({"model_binary_sha256": nested.sha256_bytes(model)} if family == "XGBOOST_COX" else {})}
        recipe = strict_json_bytes(model)["recipe"]
        design = f5._expected_family_parent_column_map(task["selected_parents"], family,
            f5.predictor_contract(Path(f5.__file__).parent), recipe["transform_recipe"])
        columns = [column for row in design for column in row["columns"]]
        if family in {"XGBOOST_COX", "COXTIME_SET_A"}:
            columns.sort(key=lambda text: text.encode())
        if family == "XGBOOST_COX":
            return {"booster_round_count": task["parameters"]["selected_rounds"], "design_columns": columns}
        if family == "COXTIME_SET_A":
            return {"input_width": len(columns), "design_columns": columns}
        return {"UNFITTED_OBJECT_AUDIT": True, "selected_parents": task["selected_parents"], "design_columns": columns}
    def pool(worker, jobs, *, on_result=None, **kwargs):
        results = [None] * len(jobs)
        for index in reversed(range(len(jobs))):
            result = worker(jobs[index])
            if on_result is not None:
                on_result(index, result)
            else:
                results[index] = result
        return results
    monkeypatch.setattr(f5, "_execute_final_refit_engine", engine)
    monkeypatch.setattr(f5, "_validate_retained_model_objects", audit)
    from padml import f2_kernel
    original_r_health = f5._validate_final_r_fit_health
    original_python_health = f2_kernel._validate_python_fit_health
    original_audit_numbers = f5._validate_retained_r_audit_numbers
    monkeypatch.setattr(f5, "_validate_final_r_fit_health", lambda family, health, *args, **kwargs:
        health if health == {"UNFITTED": True} else original_r_health(family, health, *args, **kwargs))
    monkeypatch.setattr(f2_kernel, "_validate_python_fit_health", lambda family, health, *args, **kwargs:
        health if health.get("UNFITTED") is True else original_python_health(family, health, *args, **kwargs))
    monkeypatch.setattr(f5, "_validate_retained_r_audit_numbers", lambda family, values, health, task:
        values if health == {"UNFITTED": True} and values.get("UNFITTED_OBJECT_AUDIT") is True
        else original_audit_numbers(family, values, health, task))
    monkeypatch.setattr(runtime, "_bounded_ordered_spawn", pool)
    monkeypatch.setattr(f4, "_bounded_ordered_spawn", pool)
    return calls


def test_outer_materializer_reuses_stream_hashes_but_replay_reads_current_bytes(outer_bundle, tmp_path, monkeypatch):
    source, _ = outer_bundle
    destination = tmp_path / "materialized"
    original_hash = nested.sha256_file
    hashes = []
    def count(path):
        if destination in path.parents:
            hashes.append(path.relative_to(destination).as_posix())
        return original_hash(path)
    with monkeypatch.context() as fresh:
        fresh.setattr(nested, "sha256_file", count)
        request = f4._materialize_o_fit_input_bundle(source, destination)
    assert hashes == []
    with monkeypatch.context() as replay:
        replay.setattr(nested, "sha256_file", count)
        assert f4._materialize_o_fit_input_bundle(source, destination, replay=True) == request
    assert len(hashes) == len(request["component_records"]) + len(request["post_lock_templates"])
    component = destination / request["component_records"][0]["path"]
    original = component.read_bytes()
    component.write_bytes(b"X" + original[1:])
    with pytest.raises(ContractError, match="F4_O_FIT_INPUT_REPLAY_DRIFT"):
        f4._materialize_o_fit_input_bundle(source, destination, replay=True)
    component.write_bytes(original)
    (destination / "unknown.bin").write_bytes(b"UNFITTED unexpected member")
    with pytest.raises(ContractError, match="F4_O_FIT_INPUT_REPLAY_DRIFT"):
        f4._materialize_o_fit_input_bundle(source, destination, replay=True)


def test_outer_materializer_bounds_first_component_decode(outer_bundle, tmp_path, monkeypatch):
    source, _ = outer_bundle
    entries = read_safe_zip(source)
    value = strict_json_bytes(entries["o-fit-input.json"])
    value["expanded_bytes_per_component"] = 1
    value = nested._sealed({key: item for key, item in value.items() if key != "identity_sha256"})
    entries["o-fit-input.json"] = canonical_json_bytes(value)
    limited = tmp_path / "limited.zip"
    write_deterministic_zip(limited, entries)
    monkeypatch.setattr(nested, "_validate_outer_component", lambda *a, **k: pytest.fail("NO_UNADMITTED_COMPONENT_DECODE"))
    with pytest.raises(ContractError, match="ZIP_(MEMBER|TOTAL|MANIFEST)_EXPANDED_LIMIT"):
        f4._materialize_o_fit_input_bundle(limited, tmp_path / "limited-input")


@pytest.mark.parametrize("outer_bundle", [False, True], indirect=True, ids=["legacy620", "fresh7_2120"])
def test_f4_outer_bundle_consumes_training_projection_without_global_a15(outer_bundle, tmp_path, monkeypatch):
    source, projected = outer_bundle
    request = f4._materialize_o_fit_input_bundle(source, tmp_path / "read")
    fresh_seven = request["science_decision"]["training_score_reuse"]["confirmed"] == "FRESH_SEVEN_FAMILY_REPLAY"
    fit_count = 2120 if fresh_seven else 620
    winner = "COX_PH" if fresh_seven else "RSF"
    assert len(request["component_records"]) == fit_count - 20 and len(request["post_lock_templates"]) == 140
    if fresh_seven:
        assert request["reused_training_scores"] == []
        assert {row["family"] for row in request["component_records"]} == set(nested._families())
    assert not set(nested._response_ids((tmp_path / "read/training/response.csv").read_bytes(), "TEST")) & set(projected["training_context"]["heldout_ids"])
    assert f4._materialize_o_fit_input_bundle(source, tmp_path / "read", replay=True) == request
    def forbidden(*args, **kwargs):
        pytest.fail("The remote training executor must not read global A15 or accepted full response")
    monkeypatch.setattr(f4, "_load_o_fit_selection", forbidden)
    monkeypatch.setattr(f4, "load_f4_inputs", forbidden)
    calls = _unfitted_engines(monkeypatch)
    result = tmp_path / "result.zip"
    summary = f4.execute_o_fit_bundle(target=result, outer_fold=1, input_bundle=source)
    assert summary["configured_worker_ceiling"] == 56 and summary["admitted_pool_workers"] == 4
    assert len(calls) == summary["model_fit_count"] == fit_count
    assert sum(coord["purpose"] == "NESTED_OUTER" for _, coord in calls) == 20
    assert {family for family, coord in calls if coord["purpose"] == "NESTED_OUTER"} == {winner}
    contents = read_safe_zip(result)
    value = strict_json_bytes(contents["o-fit-execution.json"])
    assert set(contents) == {"o-fit-execution.json", *value["members"]}
    assert "input.zip" not in contents and not any(name.startswith("fits/") or "/score-native/" in name for name in contents)
    assert set(value["native_members"]) == {f"fits/M{imp:02d}.zip" for imp in range(1, 21)}
    compiled = projected["compiled_input_record"]
    assert value["family"] == winner and value["selected_prediction"]["heldout_outcome_read_count"] == 0
    binding = value["development_lock"]["science_decision_binding"]
    assert binding["science_decision_sha256"] == request["science_decision"]["identity_sha256"]
    assert binding["per_outer_fit_budget"]["total_model_fits"] == fit_count
    assert binding["per_outer_fit_budget"]["stop_fits"] == 0
    assert value["selected_prediction"]["patient_ids"] == projected["training_context"]["heldout_ids"]
    assert value["selected_prediction"]["survival"][0] == [1.] + [.8] * 36
    original_source_sha, original_result_sha = sha256_file(source), sha256_file(result)
    original_writer = f4.write_deterministic_zip
    def no_republication(path, *args, **kwargs):
        assert path.name != "replayed.zip", "Numerical outer reader must not republish the complete model archive"
        return original_writer(path, *args, **kwargs)
    def no_native_work(*args, **kwargs):
        pytest.fail("Numerical outer read must not launch fits, native audits or a pool")
    with monkeypatch.context() as numerical:
        numerical.setattr(f4, "compile_o_fit_bundle", no_native_work)
        numerical.setattr(f4, "_materialize_o_fit_fold", no_native_work)
        numerical.setattr(f4, "_load_f4_source_records", lambda *args, **kwargs: {
            "source": {key: compiled[key] for key in ("f1_identity", "f2_acceptance_sha256")}})
        numerical.setattr(f4, "write_deterministic_zip", no_republication)
        numerical.setattr(runtime, "_bounded_ordered_spawn", no_native_work)
        numerical.setattr(f4, "_bounded_ordered_spawn", no_native_work)
        numerical.setattr(f5, "_execute_final_refit_engine", no_native_work)
        numerical.setattr(f5, "_validate_retained_model_objects", no_native_work)
        replay = f4.load_o_fit_execution_archive(result, input_bundle=source, f2_run_root=tmp_path,
                                                compiled_input_record=compiled,
                                                replay_evidence=tmp_path / "local-reader")
    assert len(calls) == fit_count and replay == value
    assert not (tmp_path / "local-reader/replayed.zip").exists()
    assert sha256_file(source) == original_source_sha and sha256_file(result) == original_result_sha
    # An internally rehashed remote input is not the accepted local source.
    value["input_archive"] = {"sha256": "0" * 64, "size_bytes": source.stat().st_size}
    contents["o-fit-execution.json"] = canonical_json_bytes(nested._sealed({key: item for key, item in value.items() if key != "identity_sha256"}))
    altered = tmp_path / "self-rehashed-result.zip"
    write_deterministic_zip(altered, contents)
    with pytest.raises(ContractError, match="F4_O_FIT_ACCEPTED_INPUT_DRIFT"):
        f4.load_o_fit_execution_archive(altered, input_bundle=source, f2_run_root=tmp_path)
    assert len(calls) == fit_count


@pytest.mark.parametrize("damage", ["heldout_response", "application_outcome", "parameter_drift", "coordinate_alias", "unconfirmed_decision"])
def test_f4_outer_input_rejects_real_wrong_component_before_start(outer_bundle, tmp_path, monkeypatch, damage):
    source, projected = outer_bundle
    entries = read_safe_zip(source)
    value = strict_json_bytes(entries["o-fit-input.json"])
    record = value["component_records"][0]
    component = read_safe_zip(entries[record["path"]])
    if damage == "heldout_response":
        component["fit-response.csv"] += f"{projected['training_context']['heldout_ids'][0]},1,50\n".encode()
    elif damage == "application_outcome":
        rows = list(csv.DictReader(io.StringIO(component["prediction-covariates.csv"].decode())))
        component["prediction-covariates.csv"] = _csv([*rows[0], "All_Cause_Death"],
            [{**row, "All_Cause_Death": "1"} for row in rows])
    elif damage == "parameter_drift":
        task = strict_json_bytes(component["task.json"])
        task["parameters"]["lambda"] *= 2
        component["task.json"] = canonical_json_bytes(task)
    elif damage == "coordinate_alias":
        value["component_records"][1] = dict(record)
    else:
        value["science_decision"] = nested.science_decision_template()
    component_path = tmp_path / "altered-component.zip"
    write_deterministic_zip(component_path, component)
    entries[record["path"]] = component_path.read_bytes()
    record.update(sha256=nested.sha256_file(component_path), size_bytes=component_path.stat().st_size)
    value = nested._sealed({key: item for key, item in value.items() if key != "identity_sha256"})
    entries["o-fit-input.json"] = canonical_json_bytes(value)
    altered = tmp_path / "altered-input.zip"
    write_deterministic_zip(altered, entries)
    monkeypatch.setattr(f4, "_execute_f4_model_component", lambda *args, **kwargs: pytest.fail("NO_NATIVE_START"))
    reasons = {"heldout_response": "NESTED_COMPONENT_BINDING_INVALID",
               "application_outcome": "NESTED_COMPONENT_APPLICATION_COVARIATE_SCHEMA_INVALID",
               "parameter_drift": "NESTED_COMPONENT_PARAMETER_DRIFT",
               "coordinate_alias": "F4_O_FIT_INPUT_COMPONENT_SET_INVALID",
               "unconfirmed_decision": "NESTED_SCIENCE_DECISION_INCOMPLETE"}
    with pytest.raises(ContractError, match=reasons[damage]):
        f4.execute_o_fit_bundle(target=tmp_path / "rejected.zip", outer_fold=1, input_bundle=altered)
    assert not (tmp_path / "rejected.zip.work/components").exists()


@pytest.mark.parametrize("outer_bundle", [False, {"selected_parents": ["AST_ALT", "Prior_LE_Surgery_cat"], "patients_per_center": 15}],
                         indirect=True, ids=["single-column", "frozen-categorical-order"])
def test_outer_post_lock_all_seven_families_use_m20_and_replay_before_resume(outer_bundle, tmp_path, monkeypatch):
    from test_nested_loco import _summary
    source, _ = outer_bundle
    request_root = tmp_path / "read"
    request = f4._materialize_o_fit_input_bundle(source, request_root)
    context = request["training_context"]
    calls = _unfitted_engines(monkeypatch)
    for winner in nested._families():
        root = tmp_path / winner
        root.mkdir()
        scores = []
        for family in nested._families():
            mean = .001 if family == winner else .2
            if family in nested.REUSED_SCORE_FAMILIES:
                spec = next(row["selected_spec"] for row in request["reused_training_scores"] if row["family"] == family)
                model = _accepted_model(family, mean)
                model.update(selected_spec=spec, selected_spec_sha256=nested._sha(spec))
                scores.append(nested.project_accepted_training_score(model, source_result_sha256="d" * 64,
                    training_context_sha256=context["identity_sha256"]))
            else:
                record = next(row for row in request["post_lock_templates"] if row["family"] == family)
                task = nested._read_component(request_root / record["path"])[0]
                spec = task["f4_outer_elastic_source"]["selected_spec"] if family == "ELASTIC_NET_COX" else task["parameters"]
                scores.append(nested.seal_fresh_training_score(family=family, outer_fold=1,
                    training_context_sha256=context["identity_sha256"], selected_spec=spec,
                    selector_evidence_sha256="e" * 64, summary=_summary(mean), execution_evidence_sha256="f" * 64))
        for row in request["post_lock_templates"]:
            if row["family"] == winner:
                target = root / "request" / row["path"]
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(request_root / row["path"], target)
        scored = {"training_scores": scores, "family_decision": nested.select_training_family(scores)}
        before = len(calls)
        final = f4._o_fit_post_lock_m20(request, scored, root, workers=4, replay=False)
        assert final["development_lock"]["selected_family"] == winner
        assert final["new_model_fits"] == len(calls) - before == 20
        assert final["new_model_native_verification_count"] == 20
        assert len({row["task_sha256"] for row in final["component_receipts"]}) == 20
        assert final["selected_prediction"]["survival"][0] == [1.] + [.8] * 36
        assert {path.name for path in (root / "fits").iterdir()} == {f"M{imp:02d}.zip" for imp in range(1, 21)}
        assert (root / "request").is_dir() and (root / "bound").is_dir() and (root / "final-numbers.zip").is_file()
        execution_owned_native = tmp_path / (winner + "-execution-owned-native")
        shutil.move(root / "fits", execution_owned_native)
        with monkeypatch.context() as numerical_reader:
            numerical_reader.setattr(f4, "_replay_f4_model_component",
                lambda *args, **kwargs: pytest.fail("Final numerical read must not reopen a native model"))
            replay = f4._o_fit_post_lock_m20(request, scored, root, workers=4, replay=True,
                                           native_members=final["native_members"])
        shutil.move(execution_owned_native, root / "fits")
        assert replay["new_model_fits"] == replay["native_model_replay_count"] == 0
        assert replay["final_numerical_component_count"] == 20
        assert replay["development_lock"] == final["development_lock"]
        assert len(calls) == before + 20
        # The cross-stage thin reader consumes these same original M20
        # numbers and unbound templates, with no scoring or native fallback.
        from padml import f5_sensitivity
        execution = nested._sealed({"outer_fold": 1, "input_identity_sha256": request["identity_sha256"],
            **{key: final[key] for key in ("development_lock", "selected_prediction", "component_receipts", "native_members")}})
        (root / "request/o-fit-input.json").write_bytes(canonical_json_bytes(request))
        (root / "o-fit-execution.json").write_bytes(canonical_json_bytes(execution))
        files = [root / name for name in ("request/o-fit-input.json", "o-fit-execution.json", "development-lock.json", "final-numbers.zip")]
        files += [root / "request" / row["path"] for row in request["post_lock_templates"] if row["family"] == winner]
        prepared_row = f5_sensitivity._read_a12_prepared_numerical_job({"kind": "primary", "outer_fold": 1, "root": root,
            "files": {path: {"sha256": sha256_file(path), "size_bytes": path.stat().st_size} for path in files}})
        assert prepared_row["selected_prediction"] == final["selected_prediction"] and len(calls) == before + 20
        if winner == "XGBOOST_COX":
            from padml.f4_compact import read_o_fit_final_numbers
            retained = read_safe_zip(root / "final-numbers.zip")
            numbers = strict_json_bytes(retained["final.json"])
            component = numbers["components"][0]
            component["fit_health"]["model_binary_sha256"] = "f" * 64
            component["receipt"]["fit_health_sha256"] = nested._sha(component["fit_health"])
            component["receipt"] = nested._sealed({k: v for k, v in component["receipt"].items() if k != "identity_sha256"})
            retained["final.json"] = canonical_json_bytes(nested._sealed({k: v for k, v in numbers.items() if k != "identity_sha256"}))
            wrong = root / "UNFITTED-resealed-model-binding.zip"
            write_deterministic_zip(wrong, retained)
            with pytest.raises(ContractError, match="F4_O_FIT_FINAL_NUMBERS_MODEL_BINDING_DRIFT"):
                read_o_fit_final_numbers(wrong, request=request, request_root=root / "request",
                    lock=final["development_lock"], native_members=final["native_members"])
        if "Prior_LE_Surgery_cat" in final["development_lock"]["selected_parents"] and winner not in {"XGBOOST_COX", "COXTIME_SET_A"}:
            numbers = strict_json_bytes(read_safe_zip(root / "final-numbers.zip")["final.json"])
            columns = numbers["components"][0]["object_audit"]["design_columns"]
            assert columns != sorted(columns, key=lambda text: text.encode())
        if winner == "COX_PH":
            import copy
            import struct
            from padml import f4_compact
            from padml.bundle import extract_safe_zip
            from padml.f4_compact import read_o_fit_final_numbers
            # A failed compact consumer must retain all original and expanded
            # M20 objects; the same native ZIPs are replayed, never refitted.
            failure_root = root / "UNFITTED-compact-consumer-failure"
            failure_root.mkdir()
            shutil.copytree(root / "request", failure_root / "request")
            shutil.copytree(root / "fits", failure_root / "fits")
            for imp in range(1, 21):
                archive = failure_root / f"fits/M{imp:02d}.zip"
                extract_safe_zip(archive, archive.with_suffix(""), expected_members=set(read_safe_zip(archive)),
                    max_member_bytes=request["expanded_bytes_per_component"],
                    max_total_bytes=request["expanded_bytes_per_component"])
            before_failure = {str(path.relative_to(failure_root / "fits")): sha256_file(path)
                for path in (failure_root / "fits").rglob("*") if path.is_file()}
            def failed_compact(*args, **kwargs):
                raise ContractError("UNFITTED_COMPACT_CONSUMER_FAILURE")
            with monkeypatch.context() as failure:
                failure.setattr(f4_compact, "write_o_fit_final_numbers", failed_compact)
                with pytest.raises(ContractError, match="UNFITTED_COMPACT_CONSUMER_FAILURE"):
                    f4._o_fit_post_lock_m20(request, scored, failure_root, workers=4, replay=False)
            assert not (failure_root / "final-numbers.zip").exists()
            assert before_failure == {str(path.relative_to(failure_root / "fits")): sha256_file(path)
                for path in (failure_root / "fits").rglob("*") if path.is_file()}
            assert len(calls) == before + 20
            retained = read_safe_zip(root / "final-numbers.zip")
            original_numbers = strict_json_bytes(retained["final.json"])
            native_members = {row["native_archive"]["member"]: {key: item for key, item in row["native_archive"].items() if key != "member"}
                              for row in original_numbers["components"]}
            from padml.f4_compact import write_o_fit_final_numbers
            for limit in ("shared", "disk", "disk_reserve", "component"):
                budget_root = root / f"UNFITTED-{limit}-budget"
                budget_root.mkdir()
                shutil.copytree(root / "request", budget_root / "request")
                local_request = dict(request)
                with monkeypatch.context() as admission:
                    if limit == "shared":
                        local_request["shared_storage_bytes"] = sum(map(len, retained.values())) + 4096 * 3
                        reason = "NESTED_FULL_SCORE_SHARED_STORAGE_ESTIMATE_EXCEEDED"
                    elif limit in {"disk", "disk_reserve"}:
                        required_free = sum(map(len, retained.values())) + 4096 * 3 + request["resource_policy"]["scratch_reserve_bytes"]
                        free = 0 if limit == "disk" else required_free - 1
                        admission.setattr(shutil, "disk_usage", lambda path: SimpleNamespace(free=free))
                        reason = "F4_O_FIT_FINAL_NUMBERS_DISK_SPACE_INSUFFICIENT"
                    else:
                        admission.setattr(f4, "O_FIT_COMPONENT_BYTES", 1)
                        reason = "F4_O_FIT_FINAL_NUMBERS_ARCHIVE_TOO_LARGE"
                    with pytest.raises(ContractError, match=reason):
                        write_o_fit_final_numbers(budget_root, request=local_request, lock=final["development_lock"],
                            components=original_numbers["components"], selected=final["selected_prediction"], native_members=native_members)
                assert not (budget_root / "final-numbers.zip").exists()
                if limit == "disk_reserve":
                    with monkeypatch.context() as admission:
                        admission.setattr(shutil, "disk_usage", lambda path: SimpleNamespace(free=required_free))
                        rebuilt = write_o_fit_final_numbers(budget_root, request=local_request, lock=final["development_lock"],
                            components=original_numbers["components"], selected=final["selected_prediction"], native_members=native_members)
                    assert rebuilt["selected_prediction"] == final["selected_prediction"]
            for damage in ("lock", "order", "task", "prediction", "health", "audit", "mean", "native", "missing"):
                changed = dict(retained)
                value = copy.deepcopy(original_numbers)
                component = value["components"][0]
                if damage == "lock":
                    value["development_lock_sha256"] = "f" * 64
                elif damage == "order":
                    value["components"].reverse()
                elif damage == "task":
                    component["receipt"]["task_sha256"] = "f" * 64
                    component["receipt"] = nested._sealed({key: item for key, item in component["receipt"].items() if key != "identity_sha256"})
                elif damage == "prediction":
                    component["prediction"]["survival"][winner][0] = [1.] + [.7] * 36
                elif damage == "health":
                    component["fit_health"] = {"UNFITTED": False}
                elif damage == "audit":
                    component["object_audit"]["design_columns"] = ["WRONG_COLUMN"]
                elif damage == "native":
                    component["native_archive"]["sha256"] = "f" * 64
                elif damage == "mean":
                    changed["heldout-mean.f64"] = changed["heldout-mean.f64"][:8] + struct.pack("<d", .75) + changed["heldout-mean.f64"][16:]
                    value["mean"]["sha256"] = nested.sha256_bytes(changed["heldout-mean.f64"])
                else:
                    del changed["heldout-mean.f64"]
                changed["final.json"] = canonical_json_bytes(nested._sealed({key: item for key, item in value.items() if key != "identity_sha256"}))
                bad = root / f"UNFITTED-bad-{damage}.zip"
                write_deterministic_zip(bad, changed)
                with pytest.raises(ContractError):
                    read_o_fit_final_numbers(bad, request=request, request_root=root / "request",
                        lock=final["development_lock"], native_members=native_members)
            # A completed numerical package never authorizes a replacement fit
            # after one of its original native archives has drifted.
            original = (root / "fits/M02.zip").read_bytes()
            (root / "fits/M02.zip").write_bytes(b"UNFITTED_CORRUPT_RETAINED_ARCHIVE")
            with pytest.raises(ContractError, match="F4_O_FIT_FINAL_NUMBERS_COMPONENT_INVALID"):
                f4._o_fit_post_lock_m20(request, scored, root, workers=4, replay=False)
            assert len(calls) == before + 20
            (root / "fits/M02.zip").write_bytes(original)
            # Simulate one unstarted coordinate alongside corrupt retained M2.
            # Such a stage has not yet produced its final numerical package.
            # Missing M1 must not produce a 21st object before M2 is rejected.
            shutil.move(root / "final-numbers.zip", root / "UNFITTED-saved-final-numbers.zip")
            assert not (root / "fits/M01").exists()  # its verified expanded copy was already released
            shutil.move(root / "fits/M01.zip", root / "UNFITTED-saved-M01.zip")
            original = (root / "fits/M02.zip").read_bytes()
            (root / "fits/M02.zip").write_bytes(b"UNFITTED_CORRUPT_RETAINED_ARCHIVE")
            with pytest.raises(ContractError):
                f4._o_fit_post_lock_m20(request, scored, root, workers=4, replay=False)
            assert len(calls) == before + 20 and not (root / "fits/M01").exists()
            (root / "fits/M02.zip").write_bytes(original)
            continued = f4._o_fit_post_lock_m20(request, scored, root, workers=4, replay=False)
            assert continued["new_model_fits"] == 1 and continued["native_model_replay_count"] == 19
            assert len(calls) == before + 21


@pytest.mark.parametrize("damage", ["undeclared", "missing", "duplicate", "oversized"])
def test_outer_reader_requires_final_numbers_before_compiling_or_replaying(tmp_path, monkeypatch, damage):
    import zipfile
    def forbidden(*args, **kwargs):
        pytest.fail("A missing final numerical original must fail before source compilation or native replay")
    monkeypatch.setattr(f4, "compile_o_fit_bundle", forbidden)
    monkeypatch.setattr(f4, "execute_o_fit_bundle", forbidden)
    source = tmp_path / "missing-final-numbers.zip"
    raw = b"UNFITTED final numerical archive"
    members = {} if damage == "undeclared" else {"final-numbers.zip": {
        "sha256": nested.sha256_bytes(raw), "size_bytes": len(raw)}}
    entries = {"o-fit-execution.json": canonical_json_bytes({
        "kind": "PADML_F4_O_FIT_EXECUTION_ARCHIVE_V3", "members": members})}
    if damage in {"duplicate", "oversized"}:
        entries["final-numbers.zip"] = raw
    write_deterministic_zip(source, entries)
    if damage == "duplicate":
        with zipfile.ZipFile(source, "a") as archive, pytest.warns(UserWarning, match="Duplicate name"):
            archive.writestr("final-numbers.zip", raw)
    if damage == "oversized":
        monkeypatch.setattr(f4, "O_FIT_COMPONENT_BYTES", len(raw) - 1)
    reason = "F4_O_FIT_FINAL_NUMBERS_ARCHIVE_TOO_LARGE" if damage == "oversized" else "F4_O_FIT_FINAL_NUMBERS_REQUIRED"
    with pytest.raises(ContractError, match=reason):
        f4.load_o_fit_execution_archive(source, input_bundle=tmp_path / "unread-input.zip", f2_run_root=tmp_path)


@pytest.mark.parametrize("outer_bundle", [True], indirect=True, ids=["fresh7_2100"])
def test_completed_outer_scores_reuse_original_numbers_without_native_pool(outer_bundle, tmp_path, monkeypatch):
    import copy
    import zipfile
    source, _ = outer_bundle
    with zipfile.ZipFile(source) as archive:
        request = strict_json_bytes(archive.read("o-fit-input.json"))
    calls = _unfitted_engines(monkeypatch)
    root = tmp_path / "score"
    options = {name: request[name] for name in ("resource_policy", "retained_bytes_per_component",
               "expanded_bytes_per_component", "shared_storage_bytes")}
    produced = f5._full_data_locked_score_program(None, None, None, None, None, root,
        rscript="UNFITTED", replay=False, outer_input=source, **options)
    assert len(calls) == produced["new_model_fits"] == 2100
    # Simulate the numeric-only transfer after first native verification;
    # retain every original under its execution-owned fixture directory.
    shutil.move(root / "components/score-native", tmp_path / "UNFITTED-execution-owned-native")
    evidence = produced["result"]["fresh_score_execution"][0]
    copy_path = root / "score-evidence" / evidence["family"] / Path(evidence["component_evidence_records"][0]["path"]).name
    saved_copy = tmp_path / "UNFITTED-saved-optional-evidence.json"
    def forbidden(*args, **kwargs):
        pytest.fail("Completed scoring numbers must not launch native replay, fits or a pool")
    with monkeypatch.context() as numerical:
        numerical.setattr(runtime, "_bounded_ordered_spawn", forbidden)
        numerical.setattr(f5, "_execute_final_refit_engine", forbidden)
        numerical.setattr(f4, "_replay_f4_model_component", forbidden)
        numerical.setattr(nested, "_component_execution_receipt", forbidden)
        numerical.setattr(f5, "_score_archive_handle", forbidden)
        for replay, resume in ((True, False), (False, True)):
            if resume:
                shutil.move(copy_path, saved_copy)
            try:
                reread = f5._full_data_locked_score_program(None, None, None, None, None, root,
                    rscript="UNFITTED", replay=replay, resume=resume, outer_input=source, **options)
            finally:
                if resume:
                    shutil.move(saved_copy, copy_path)
            assert reread["result"] == produced["result"] and len(calls) == 2100
            assert reread["new_model_fits"] == reread["native_model_replay_count"] == 0
            assert reread["score_numerical_component_count"] == 2100 and reread["pool_execution_reports"] == []
        # Reseal mutations so rejection depends on original numerical/input
        # contracts, not merely a stale JSON digest. No new fit is possible.
        evidence_record = evidence["component_evidence_records"][0]
        evidence_path = root / evidence_record["path"]
        saved_evidence = evidence_path.read_bytes()
        score = produced["result"]["training_scores"][0]
        for damage in ("audit_missing", "audit_design", "health", "patient", "coordinate", "source", "seed", "mean", "missing", "duplicate", "truncated"):
            changed_execution = copy.deepcopy(evidence)
            changed = strict_json_bytes(saved_evidence)
            if damage == "audit_missing":
                del changed["object_audit"]
            elif damage == "audit_design":
                changed["object_audit"]["design_columns"] = ["WRONG_COLUMN"]
            elif damage == "health":
                changed["fit_health"]["UNFITTED"] = False
                changed["receipt"]["fit_health_sha256"] = nested._sha(changed["fit_health"])
                changed["receipt"] = nested._sealed({k: v for k, v in changed["receipt"].items() if k != "identity_sha256"})
            elif damage == "patient":
                changed["prediction"]["patient_ids"].reverse()
                changed["receipt"]["prediction_sha256"] = nested._sha(changed["prediction"])
                changed["receipt"] = nested._sealed({k: v for k, v in changed["receipt"].items() if k != "identity_sha256"})
            elif damage == "coordinate":
                changed["imputation"] = 2
            elif damage == "source":
                changed["request_component_sha256"] = "0" * 64
            elif damage == "seed":
                changed["receipt"]["seed"] += 1
                changed["receipt"] = nested._sealed({k: v for k, v in changed["receipt"].items() if k != "identity_sha256"})
            elif damage == "mean":
                changed_execution["pooled_partitions"][0]["pooled_survival"][0][1:] = [0.7] * 36
            elif damage == "missing":
                changed_execution["component_evidence_records"].pop()
            elif damage == "duplicate":
                changed_execution["component_evidence_records"][1] = copy.deepcopy(evidence_record)
            changed = nested._sealed({k: v for k, v in changed.items() if k != "identity_sha256"})
            raw = canonical_json_bytes(changed)
            if damage == "truncated":
                raw = raw[:len(raw) // 2]
            evidence_path.write_bytes(raw)
            changed_execution["component_evidence_records"][0] = {**evidence_record,
                "sha256": nested.sha256_bytes(raw), "size_bytes": len(raw), "identity_sha256": changed["identity_sha256"],
                "component_receipt_sha256": changed["receipt"]["identity_sha256"]}
            changed_execution["component_receipt_sha256"][0] = changed["receipt"]["identity_sha256"]
            changed_execution["pooled_partitions"][0]["component_receipt_sha256"][0] = changed["receipt"]["identity_sha256"]
            changed_execution = nested._sealed({k: v for k, v in changed_execution.items() if k != "identity_sha256"})
            changed_score = nested._sealed({**{k: v for k, v in score.items() if k != "identity_sha256"},
                                            "source_result_sha256": changed_execution["identity_sha256"]})
            try:
                with pytest.raises(ContractError):
                    nested._recompute_fresh_score_from_evidence(execution=changed_execution, score=changed_score,
                        request=produced["request"], request_root=root / "request", result_root=root,
                        expanded_bytes_per_component=options["expanded_bytes_per_component"],
                        retained_bytes_per_component=options["retained_bytes_per_component"])
            finally:
                evidence_path.write_bytes(saved_evidence)
        copy_raw = copy_path.read_bytes()
        copy_path.write_bytes(b"X" + copy_raw[1:])  # Same-size mutation cannot earn verified storage credit.
        try:
            with pytest.raises(ContractError, match="NESTED_FULL_SCORE_EVIDENCE_REPLAY_DRIFT"):
                f5._full_data_locked_score_program(None, None, None, None, None, root,
                    rscript="UNFITTED", replay=True, outer_input=source, **options)
        finally:
            copy_path.write_bytes(copy_raw)
        original = root / "o-fit-scores.json"
        saved = root / "UNFITTED-saved-o-fit-scores.json"
        shutil.move(original, saved)
        with pytest.raises(ContractError, match="NESTED_FULL_SCORE_NUMERICAL_ORIGINAL_REQUIRED"):
            f5._full_data_locked_score_program(None, None, None, None, None, root,
                rscript="UNFITTED", replay=True, outer_input=source, **options)
        shutil.move(saved, original)
    assert produced["new_model_native_verification_count"] == 2100


@pytest.mark.parametrize("outer_bundle", [True], indirect=True)
def test_outer_score_shards_first_audit_numeric_gather_and_original_final(outer_bundle, tmp_path, monkeypatch):
    from test_nested_full_score import _check_score_shard_negatives, _unfitted_score_shard_engines
    from test_retained_score_compatibility import retained_score_fixture
    source, _ = outer_bundle
    calls = _unfitted_score_shard_engines(monkeypatch)
    monkeypatch.setattr(f4, "_bounded_ordered_spawn", runtime._bounded_ordered_spawn)
    target = tmp_path / "outer.zip"
    root = target.with_name(target.name + ".work")
    prepared = f4.execute_o_fit_bundle(target=target, input_bundle=source, outer_fold=1, prepare_only=True)
    request = prepared["request"]
    assert prepared["new_model_fits"] == 0 and len(prepared["task_ids"]) == 2100 and calls == []
    assert not (root / "development-lock.json").exists() and not target.exists()
    retained_ids = [next(value for value in prepared["task_ids"] if "/" + family + "/" in value)
                    for family in nested._families()]
    archive = retained_score_fixture(request, root / "request", tmp_path / "historical", retained_ids)
    historical_sha = sha256_file(archive)
    assert len(calls) == 7
    retained_batch = root / "score-batches/retained"
    with monkeypatch.context() as foreign_source:
        foreign_source.setattr(f4, "_f45_source_member_sha256", lambda: {"UNFITTED-foreign-source": "0" * 64})
        with pytest.raises(ContractError, match="F4_O_FIT_INPUT_SCOPE_INVALID"):
            f4.execute_o_fit_bundle(target=target, input_bundle=source, outer_fold=1,
                task_ids=retained_ids, batch_root=retained_batch, retained_native=archive)
    assert not retained_batch.exists() and len(calls) == 7
    with monkeypatch.context() as reuse_only:
        reuse_only.setattr(f5, "_execute_and_verify_score_archive_job", lambda *a, **k: pytest.fail("NO_REFIT"))
        retained = f4.execute_o_fit_bundle(target=target, input_bundle=source, outer_fold=1,
            task_ids=retained_ids, batch_root=retained_batch, retained_native=archive)
    assert retained["new_model_fits"] == retained["new_model_native_verification_count"] == 0
    assert retained["native_model_replay_count"] == retained["execution"]["retained_model_replay_count"] == 7
    assert len(calls) == 7 and sha256_file(archive) == historical_sha
    batches = [retained_batch]
    for index in range(6):
        batch = root / "score-batches" / f"assignment-{index}"
        assigned = [value for value in prepared["task_ids"][index::6] if value not in retained_ids]
        value = f4.execute_o_fit_bundle(target=target, input_bundle=source, outer_fold=1,
            task_ids=assigned, batch_root=batch)
        assert value["new_model_fits"] == value["new_model_native_verification_count"] == len(assigned)
        assert value["result"] is None and value["execution"]["pool"]["completed_task_count"] == len(assigned)
        assert value["execution"]["resource_reservation"]["assigned_component_count"] == len(assigned)
        batches.append(batch)
    assert len(calls) == 2100 and not (root / "development-lock.json").exists()
    with pytest.raises(ContractError, match="F4_NATIVE_MODEL_TARGET_ALREADY_STARTED"):
        f4.execute_o_fit_bundle(target=target, input_bundle=source, outer_fold=1,
            task_ids=prepared["task_ids"][:1], batch_root=root / "score-batches/renamed")
    assert len(calls) == 2100 and not (root / "score-batches/renamed").exists()
    shutil.move(root / "components/score-native", tmp_path / "retained-execution-owned-native")
    _check_score_shard_negatives(root, request, batches[1], monkeypatch=monkeypatch)
    original_gather = f5._consume_full_score_batches
    captured = []
    def gather(*args, **kwargs):
        captured.append((args, kwargs))
        return original_gather(*args, **kwargs)
    monkeypatch.setattr(f5, "_consume_full_score_batches", gather)
    def forbidden(*args, **kwargs):
        pytest.fail("Numerical gathering cannot start score fits or score-native replay")
    monkeypatch.setattr(f5, "_execute_and_verify_score_archive_job", forbidden)
    monkeypatch.setattr(f5, "_replay_component_job", forbidden)
    original_replay = f4._replay_f4_model_component
    def native_only_final(job, **kwargs):
        assert "score-native" not in str(job["archive"])
        return original_replay(job, **kwargs)
    monkeypatch.setattr(f4, "_replay_f4_model_component", native_only_final)
    final_prepared = f4.execute_o_fit_bundle(target=target, input_bundle=source, outer_fold=1,
        score_batches=batches, prepare_final=True)
    assert final_prepared["new_model_fits"] == 0 and final_prepared["imputations"] == list(range(1, 21))
    assert len(calls) == 2100 and not target.exists()
    final_batches = []
    for index in range(6):
        batch = root / "final-batches" / f"assignment-{index}"
        assigned = final_prepared["imputations"][index::6]
        final_shard = f4.execute_o_fit_bundle(target=target, input_bundle=source, outer_fold=1,
            final_imputations=assigned, final_batch_root=batch)
        assert final_shard["new_model_fits"] == final_shard["new_model_native_verification_count"] == len(assigned)
        final_batches.append(batch)
    shutil.move(root / "fits", tmp_path / "retained-execution-owned-final-native")
    monkeypatch.setattr(f4, "_execute_f4_model_component", forbidden)
    monkeypatch.setattr(f4, "_replay_f4_model_component", forbidden)
    result = f4.execute_o_fit_bundle(target=target, input_bundle=source, outer_fold=1, final_batches=final_batches)
    assert result["score_numerical_component_count"] == 2100 and result["model_fit_count"] == 0
    assert result["final_numerical_component_count"] == 20
    assert len(calls) == 2120 and target.is_file()
    assert result["pool_execution_reports"]["scoring"] == []
    assert not list((root / "components/score-native").glob("*/*.zip"))
    scores = strict_json_bytes((root / "o-fit-scores.json").read_bytes())
    lock = strict_json_bytes((root / "development-lock.json").read_bytes())
    assert lock["family_decision_sha256"] == scores["family_decision"]["identity_sha256"]
    assert all(row["ranking_metric_values"] == pytest.approx([0.039166666666666655]*3) for row in scores["training_scores"])
    args, kwargs = captured[0]
    for bad in (batches[:-1], [*batches, batches[0]]):
        with pytest.raises(ContractError, match="BATCH_COMPLETE_SET_REQUIRED|BATCHES_INVALID"):
            original_gather(*args[:3], bad, **kwargs)
    path = batches[0] / "execution.json"
    saved = path.read_bytes()
    for damage in ("duplicate", "unknown", "source", "pool", "audit_count", "new_fit", "reuse_count", "bool_reuse"):
        value = strict_json_bytes(saved)
        if damage == "duplicate":
            value["task_ids"][1] = value["task_ids"][0]
        elif damage == "unknown":
            value["task_ids"][0] = "components/score/WRONG/R1_K1_M01.zip"
        elif damage == "source":
            value["source_identity"] = "0"*64
        elif damage == "pool":
            value["pool"]["completed_task_count"] -= 1
        elif damage == "new_fit":
            value["new_model_fits"] = 3
        elif damage == "reuse_count":
            value["retained_model_replay_count"] -= 1
        elif damage == "bool_reuse":
            value["retained_model_replay_count"] = True
        else:
            value["new_model_native_verification_count"] -= 1
        path.write_bytes(canonical_json_bytes(value))
        try:
            with pytest.raises(ContractError):
                original_gather(*args, **kwargs)
        finally:
            path.write_bytes(saved)
    execution = strict_json_bytes(saved)
    evidence_path = batches[0] / "score-evidence" / Path(retained_ids[0]).relative_to("components/score").with_suffix(".json")
    original_evidence = evidence_path.read_bytes()
    for field in ("model_sha256", "input_component_sha256", "original_coordinate_identity", "new_model_fit_count", "kind"):
        evidence = strict_json_bytes(original_evidence)
        evidence["retained_model_source"][field] = 1 if field == "new_model_fit_count" else "0" * 64
        if field == "kind":
            evidence["retained_model_source"][field] = "PADML_FPM_RETAINED_SCORE_SOURCE_V1"
        changed = nested._sealed({key: value for key, value in evidence.items() if key != "identity_sha256"})
        raw = canonical_json_bytes(changed)
        evidence_path.write_bytes(raw)
        execution["archive_handles"][0].update(evidence_sha256=nested.sha256_bytes(raw), evidence_size_bytes=len(raw))
        path.write_bytes(canonical_json_bytes(execution))
        try:
            with pytest.raises(ContractError):
                original_gather(*args, **kwargs)
        finally:
            evidence_path.write_bytes(original_evidence)
            path.write_bytes(saved)
    assert len(calls) == 2120


def test_score_shard_failed_first_audit_preserves_unknown_fit_count_and_fixed_owner(outer_bundle, tmp_path, monkeypatch):
    from test_nested_full_score import _unfitted_score_shard_engines
    source, _ = outer_bundle
    calls = _unfitted_score_shard_engines(monkeypatch)
    target = tmp_path / "outer.zip"
    root = target.with_name(target.name + ".work")
    prepared = f4.execute_o_fit_bundle(target=target, input_bundle=source, outer_fold=1, prepare_only=True)
    original = f5._replay_component_job
    count = []
    def fail_second(job):
        count.append(job["root"])
        if len(count) == 2:
            raise ContractError("UNFITTED_FIRST_AUDIT_FAILURE")
        return original(job)
    monkeypatch.setattr(f5, "_replay_component_job", fail_second)
    batch = root / "score-batches/failed"
    with pytest.raises(ContractError, match="UNFITTED_FIRST_AUDIT_FAILURE"):
        f4.execute_o_fit_bundle(target=target, input_bundle=source, outer_fold=1,
            task_ids=prepared["task_ids"][:2], batch_root=batch)
    execution = strict_json_bytes((batch / "execution.json").read_bytes())
    assert execution["new_model_fits"] is None  # Never claim zero or an exact unknown in-flight fit count.
    assert execution["new_model_native_verification_count"] == execution["pool"]["completed_task_count"] == 1
    assert execution["pool"]["status"] == "FAILED" and len(calls) == 2
    native = {path: sha256_file(path) for path in (root / "components/score-native").glob("*/*.zip")}
    assert len(native) == 2
    with pytest.raises(ContractError, match="F4_NATIVE_MODEL_TARGET_ALREADY_STARTED"):
        f4.execute_o_fit_bundle(target=target, input_bundle=source, outer_fold=1,
            task_ids=prepared["task_ids"][:2], batch_root=root / "score-batches/renamed-failure")
    assert len(calls) == 2 and all(sha256_file(path) == digest for path, digest in native.items())


@pytest.mark.parametrize("shared_source", [False, True, "with_fold_observer"])
@pytest.mark.parametrize("horizon", [24, 12, "12-proof"])
def test_outer_reader_admits_one_bounded_final_original_to_existing_compiler(tmp_path, monkeypatch, shared_source, horizon):
    source, inputs = tmp_path / "outer.zip", tmp_path / "input.zip"
    raw = b"UNFITTED final original; only the outer admission boundary is exercised"
    write_deterministic_zip(source, {"o-fit-execution.json": canonical_json_bytes({
        "kind": "PADML_F4_O_FIT_EXECUTION_ARCHIVE_V3", "outer_fold": 1,
        "members": {"final-numbers.zip": {"sha256": nested.sha256_bytes(raw), "size_bytes": len(raw)}}}),
        "final-numbers.zip": raw})
    policy = {"configured_worker_ceiling": runtime.CPU_MINUS_8, "memory_bytes_per_worker": 1000,
              "scratch_bytes_per_worker": 1000, "memory_reserve_bytes": 100,
              "scratch_reserve_bytes": 100, "transfer_archive_worker_ceiling": 4}
    declared = {"science_decision": {}, "resource_policy": policy, "retained_bytes_per_component": 1,
                "expanded_bytes_per_component": 1, "shared_storage_bytes": 1}
    if horizon in (12, "12-proof"):
        declared.update(selection_horizon_months=12, primary_searches={"UNFITTED_FORWARDING_ONLY": True})
    proof = b"UNFITTED_SOURCE_FORWARDING_ONLY_NOT_COMPATIBILITY_ACCEPTANCE"
    extra = {}
    if horizon == "12-proof":
        member = "source/primary-search/RSF.zip"
        declared["primary_search_sources"] = {"RSF": {"path": member,
            "sha256": nested.sha256_bytes(proof), "size_bytes": len(proof)}}
        extra[member] = proof
        monkeypatch.setattr(runtime, "observe_execution_resources", lambda root: {
            "effective_cpus": 32, "available_memory_bytes": 10**12,
            "scratch_available_bytes": 10**12, "scratch_root": str(root)})
    write_deterministic_zip(inputs, {"o-fit-input.json": canonical_json_bytes(declared), **extra})
    calls = []
    def compiler(root, target, **kwargs):
        calls.append((root, target, kwargs))
        raise ContractError("UNFITTED_ORIGINAL_COMPILER_REACHED")
    monkeypatch.setattr(f4, "_compile_o_fit_bundle" if shared_source else "compile_o_fit_bundle", compiler)
    monkeypatch.setattr(f4, "execute_o_fit_bundle", lambda **kwargs: pytest.fail("NO_NATIVE_REPLAY"))
    reader = f4._load_o_fit_execution_archive if shared_source else f4.load_o_fit_execution_archive
    def source_reader(**kwargs):
        pytest.fail("No source read before original compiler admission")
    options = {"accepted_source_reader": source_reader} if shared_source else {}
    if shared_source == "with_fold_observer":
        options["on_materialized_fold"] = source_reader
    with pytest.raises(ContractError, match="UNFITTED_ORIGINAL_COMPILER_REACHED"):
        reader(source, input_bundle=inputs, f2_run_root=tmp_path,
               replay_evidence=tmp_path / "reader", **options)
    expected = {key: value for key, value in declared.items() if key != "primary_search_sources"}
    if horizon == "12-proof":
        source_path = tmp_path / "reader/primary-search-RSF.zip"
        assert source_path.read_bytes() == proof
        expected["primary_search_source_bundles"] = {"RSF": source_path}
    assert calls == [(tmp_path, tmp_path / "reader/expected-input.zip",
                      {"outer_fold": 1, "f1_runtime_root": None, **expected, **options})]


@pytest.mark.parametrize("shortfall", [None, "outer"])
@pytest.mark.parametrize("retention", ["owned", "explicit", "borrowed"])
def test_outer_reader_admits_its_owned_expansion_before_first_member(tmp_path, monkeypatch, shortfall, retention):
    """The score entry separately owns/admit-tests the one request expansion."""
    import zipfile
    from padml import bundle
    source, inputs = tmp_path / "outer.zip", tmp_path / "input.zip"
    policy = {"configured_worker_ceiling": runtime.CPU_MINUS_8, "memory_bytes_per_worker": 1000,
              "scratch_bytes_per_worker": 1000, "memory_reserve_bytes": 100,
              "scratch_reserve_bytes": 100, "transfer_archive_worker_ceiling": 4}
    declared = {"science_decision": _unfitted_confirmed_decision(fresh_seven=True, fixed_bootstrap=True),
                "resource_policy": policy, "retained_bytes_per_component": 10**6,
                "expanded_bytes_per_component": 10**6, "shared_storage_bytes": 10**7, "component_records": []}
    write_deterministic_zip(inputs, {"o-fit-input.json": canonical_json_bytes(declared)})
    original = b"UNFITTED final original"
    value = {"kind": "PADML_F4_O_FIT_EXECUTION_ARCHIVE_V3", "outer_fold": 1,
             "input_archive": {"sha256": sha256_file(inputs), "size_bytes": inputs.stat().st_size},
             "native_members": {f"fits/M{imp:02d}.zip": {"sha256": "a" * 64, "size_bytes": 1} for imp in range(1, 21)},
             "members": {name: {"sha256": nested.sha256_bytes(original), "size_bytes": len(original)}
                         for name in ("o-fit-scores.json", "development-lock.json", "final-numbers.zip")}}
    write_deterministic_zip(source, {"o-fit-execution.json": canonical_json_bytes(value),
                                    **dict.fromkeys(value["members"], original)})
    before = {path: sha256_file(path) for path in (source, inputs)}
    with zipfile.ZipFile(source) as archive:
        outer_bytes = sum(info.file_size for info in archive.infolist())
    calls, work, streamed = [], {}, []
    original_stream = bundle._stream_zip_member

    def stream(archive, info, target):
        streamed.append(info.filename)
        return original_stream(archive, info, target)

    def compiler(root, target, **kwargs):
        work["root"] = target.parent
        calls.append("compile")
        return {"sha256": sha256_file(inputs), "size_bytes": inputs.stat().st_size}

    def observation(root):
        assert root == work["root"] and root.parent == tmp_path
        return {"effective_cpus": 64, "available_memory_bytes": 10**12,
                "scratch_available_bytes": outer_bytes + 1100 - int(shortfall == "outer"), "scratch_root": str(root)}

    def materialize(*args, **kwargs):
        pytest.fail("The outer reader must not materialize the score consumer's request a second time")

    def replay(*args, **kwargs):
        assert args[0] == inputs and kwargs["retained_native"] == work["root"] / "archive"
        assert not (kwargs["retained_native"] / "request").exists()
        calls.append("UNFITTED replay")
        return value

    monkeypatch.setattr(f4, "compile_o_fit_bundle", compiler)
    monkeypatch.setattr(f4, "_compile_o_fit_bundle", compiler)
    monkeypatch.setattr(bundle, "_stream_zip_member", stream)
    monkeypatch.setattr(runtime, "observe_execution_resources", observation)
    monkeypatch.setattr(f4, "_materialize_o_fit_input_bundle", materialize)
    monkeypatch.setattr(f4, "_execute_o_fit_training_bundle", replay)
    options = ({"replay_evidence": tmp_path / "retained-reader"} if retention == "explicit" else
               {"accepted_source_reader": lambda **kwargs: None,
                "on_materialized_fold": lambda *args, **kwargs: None} if retention == "borrowed" else {})
    if shortfall is None:
        assert f4._load_o_fit_execution_archive(source, input_bundle=inputs, f2_run_root=tmp_path, **options) == value
        assert calls == ["compile", "UNFITTED replay"]
        if retention == "owned":
            assert not work["root"].exists()
        else:
            assert (work["root"] / "archive/o-fit-scores.json").read_bytes() == original
    else:
        with pytest.raises(ContractError, match="RESOURCE_ADMISSION_ZERO") as captured:
            f4._load_o_fit_execution_archive(source, input_bundle=inputs, f2_run_root=tmp_path, **options)
        assert "UNFITTED replay" not in calls
        assert streamed == []
        assert work["root"].is_dir()
        assert f"F4_O_FIT_OUTER_REPLAY_EVIDENCE:{work['root']}" in captured.value.__notes__
        assert not (work["root"] / "archive").exists()
        assert not list(work["root"].glob(".archive.quarantine-*"))
    assert all(sha256_file(path) == digest for path, digest in before.items())


@pytest.mark.parametrize("outcome", ["success", "retained", "mismatch", "consumer-error"])
def test_outer_aggregate_reader_releases_only_successful_owned_copies(tmp_path, monkeypatch, outcome):
    """Real archive bytes and original owner lifetime; no numerical computation."""
    inputs = {outer: tmp_path / f"input-{outer}.zip" for outer in range(1, 7)}
    entries = {f"execution-o{outer:02d}.zip": b"UNFITTED_OUTER_ARCHIVE" for outer in range(1, 7)}
    entries["evaluation/metrics.zip"] = b"UNFITTED_RETAINED_METRIC_ARCHIVE"
    metric = entries["evaluation/metrics.zip"]
    value = {"UNFITTED_AGGREGATE_VALUE": True,
             "native_metric_archive": {"member": "evaluation/metrics.zip",
                "sha256": nested.sha256_bytes(metric), "size_bytes": len(metric)}}
    entries["o-fit-aggregate.json"] = canonical_json_bytes(value)
    source = tmp_path / "aggregate.zip"
    write_deterministic_zip(source, entries)
    before = sha256_file(source)
    roots = []

    def consume(sources, target, **kwargs):
        root = kwargs["replay_evidence"].parent
        roots.append(root)
        assert all((root / "archive" / name).read_bytes() == raw for name, raw in entries.items())
        assert kwargs["replay_metrics"].is_file() and target is None
        if outcome == "consumer-error":
            raise ContractError("UNFITTED_ORIGINAL_CONSUMER_FAILED")
        return {**value, "UNFITTED_MISMATCH": True} if outcome == "mismatch" else value

    monkeypatch.setattr(f4, "_aggregate_o_fit_training_archives", consume)
    options = {"input_bundles": inputs, "f2_run_root": tmp_path,
               "compiled_input_records": {outer: {} for outer in range(1, 7)}}
    if outcome == "retained":
        options["replay_evidence"] = tmp_path / "explicit-evidence"
    if outcome in {"mismatch", "consumer-error"}:
        with pytest.raises(ContractError, match="F4_O_FIT_AGGREGATE_REPLAY_MISMATCH|UNFITTED_ORIGINAL_CONSUMER_FAILED"):
            f4.load_o_fit_aggregate_archive(source, **options)
    else:
        assert f4.load_o_fit_aggregate_archive(source, **options) == value
    assert len(roots) == 1 and sha256_file(source) == before
    if outcome == "success":
        assert not roots[0].exists()
    else:
        assert all((roots[0] / "archive" / name).read_bytes() == raw for name, raw in entries.items())


@pytest.mark.parametrize("damage", [None, "sha256", "size_bytes", "outer_fold", "identity_sha256",
    "f1_identity", "f2_acceptance_sha256", "self_rehashed_input", "extra_native_member", "missing_native_reference"])
def test_outer_reader_requires_independent_original_compile_record(tmp_path, monkeypatch, damage):
    """Real record/ZIP boundary; downstream scientific consumers are explicit stubs."""
    import copy
    policy = {"configured_worker_ceiling": runtime.CPU_MINUS_8, "memory_bytes_per_worker": 1000,
              "scratch_bytes_per_worker": 1000, "memory_reserve_bytes": 100,
              "scratch_reserve_bytes": 100, "transfer_archive_worker_ceiling": 4}
    declared = {"identity_sha256": "a" * 64,
        "science_decision": _unfitted_confirmed_decision(fresh_seven=True, fixed_bootstrap=True),
        "resource_policy": policy, "component_records": []}
    source, result = tmp_path / "input.zip", tmp_path / "result.zip"
    write_deterministic_zip(source, {"o-fit-input.json": canonical_json_bytes(declared)})
    compiled = {"status": "COMPILED_ZERO_FITS", "outer_fold": 1, "identity_sha256": declared["identity_sha256"],
        "sha256": sha256_file(source), "size_bytes": source.stat().st_size,
        "f1_identity": "1" * 64, "f2_acceptance_sha256": "2" * 64,
        "model_fit_count": 0, "heldout_response_member_count": 0}
    original_compiled = copy.deepcopy(compiled)
    numeric = dict.fromkeys(("o-fit-scores.json", "development-lock.json", "final-numbers.zip"), b"UNFITTED_NUMERICAL_LEAF")
    if damage == "self_rehashed_input":
        source.write_bytes(source.read_bytes() + b"UNFITTED_SELF_REHASHED_REMOTE_INPUT")
    value = {"kind": "PADML_F4_O_FIT_EXECUTION_ARCHIVE_V3", "outer_fold": 1,
        "input_identity_sha256": declared["identity_sha256"],
        "input_archive": {"sha256": sha256_file(source), "size_bytes": source.stat().st_size},
        "native_members": {f"fits/M{imp:02d}.zip": {"sha256": "b" * 64, "size_bytes": 1} for imp in range(1, 21)}}
    if damage in {"sha256", "identity_sha256", "f1_identity", "f2_acceptance_sha256"}:
        compiled[damage] = "f" * 64
    elif damage in {"size_bytes", "outer_fold"}:
        compiled[damage] += 1
    elif damage == "extra_native_member":
        numeric["fits/M01.zip"] = b"UNFITTED_EXTRA_NATIVE"
    elif damage == "missing_native_reference":
        del value["native_members"]["fits/M01.zip"]
    value["members"] = {name: {"sha256": nested.sha256_bytes(raw), "size_bytes": len(raw)} for name, raw in numeric.items()}
    write_deterministic_zip(result, {"o-fit-execution.json": canonical_json_bytes(value), **numeric})
    calls = []
    def forbidden(*args, **kwargs):
        pytest.fail("NO_EXPECTED_RECOMPILE_OR_NATIVE_MODEL_AT_NUMERICAL_BOUNDARY")
    monkeypatch.setattr(f4, "compile_o_fit_bundle", forbidden)
    monkeypatch.setattr(f4, "_compile_o_fit_bundle", forbidden)
    monkeypatch.setattr(f4, "_materialize_o_fit_fold", forbidden)
    monkeypatch.setattr(f4, "load_f4_inputs", forbidden)
    monkeypatch.setattr(f4, "_load_f4_source_records", lambda *args, **kwargs: {
        "source": {key: original_compiled[key] for key in ("f1_identity", "f2_acceptance_sha256")}})
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda root: {
        "effective_cpus": 32, "available_memory_bytes": 10**10, "scratch_available_bytes": 10**10,
        "scratch_root": str(root)})
    def materialize(path, target, **kwargs):
        pytest.fail("The original numerical score consumer owns the one input materialization")
    def numbers(path, target, **kwargs):
        assert path == source and target is None and kwargs["native_members"] == value["native_members"]
        assert not (kwargs["retained_native"] / "fits").exists()
        calls.append("ORIGINAL_NUMERICAL_CONSUMER_STUB")
        return value
    monkeypatch.setattr(f4, "_materialize_o_fit_input_bundle", materialize)
    monkeypatch.setattr(f4, "_execute_o_fit_training_bundle", numbers)
    if damage is None:
        assert f4.load_o_fit_execution_archive(result, input_bundle=source, f2_run_root=tmp_path,
            compiled_input_record=compiled) == value
        assert calls == ["ORIGINAL_NUMERICAL_CONSUMER_STUB"]
    else:
        with pytest.raises(ContractError, match="F4_O_FIT_(COMPILED_INPUT_RECORD_INVALID|ACCEPTED_INPUT_DRIFT|NUMERICAL_MEMBER_SET_INVALID)"):
            f4.load_o_fit_execution_archive(result, input_bundle=source, f2_run_root=tmp_path, compiled_input_record=compiled)
        assert calls == []


@pytest.mark.parametrize("records", [None, {}, {outer: {} for outer in range(1, 6)}, {outer: {} for outer in range(7)}])
def test_aggregate_requires_all_six_original_compile_records_before_results(tmp_path, records):
    with pytest.raises(ContractError, match="F4_O_FIT_ACCEPTED_INPUT_REQUIRED"):
        f4._aggregate_o_fit_training_archives([], tmp_path / "never.zip",
            input_bundles={outer: tmp_path / f"unread-{outer}.zip" for outer in range(1, 7)},
            compiled_input_records=records, f2_run_root=tmp_path, f1_runtime_root=None,
            replay_workers=None, replay_evidence=tmp_path / "never")
    assert list(tmp_path.iterdir()) == []


@pytest.mark.parametrize("damage", [None, "acceptance", "run", "common", "replay", "f1"])
def test_original_f4_source_records_do_not_open_model_or_mice_objects(tmp_path, monkeypatch, damage):
    """The original source/seal checks run; only the pinned F1 identity reader is a fixture."""
    root = tmp_path / "f1"
    (root / "build").mkdir(parents=True)
    (root / "input/f1").mkdir(parents=True)
    common, replay_path = root / "build/common-input.zip", root / "build/f1-replay-seal.zip"
    common.write_bytes(b"UNFITTED_COMMON_SOURCE_BYTES")
    binding = {"registry": {"UNFITTED": True}}
    manifest = {"identity": "a" * 64, "binding_contract_sha256": nested._sha(binding)}
    (root / "input/f1/input-manifest.json").write_bytes(canonical_json_bytes(manifest))
    response = b"Patient_ID,All_Cause_Death,Death_Followup_months\np1,1,50\n"
    seal = {"f1_input_manifest_identity": manifest["identity"], "common_input_sha256": sha256_file(common),
        "binding_contract_sha256": manifest["binding_contract_sha256"], "response_seal_sha256": nested.sha256_bytes(response),
        "response_size_bytes": len(response), "lineage": {"UNFITTED": "b" * 64}}
    seal["identity"] = nested._sha(seal)
    write_deterministic_zip(replay_path, {"manifest.json": canonical_json_bytes(seal),
        "binding-contract.json": canonical_json_bytes(binding), "response-seal.csv": response})
    run = {name: {"path": str(path), "sha256": sha256_file(path), "size_bytes": path.stat().st_size}
           for name, path in (("common_input", common), ("replay_seal", replay_path))}
    run["identity"] = nested._sha(run)
    (tmp_path / "run.json").write_bytes(canonical_json_bytes(run))
    acceptance = {"status": "SCIENTIFICALLY_ACCEPTED", "run_identity": run["identity"],
        "stage_validation": {"outcome": "PASS"}, "unit_count": 46,
        "result_sha256": dict.fromkeys(f4.canonical_unit_ids(), "c" * 64)}
    acceptance["identity"] = nested._sha(acceptance)
    (tmp_path / "f2-acceptance.json").write_bytes(canonical_json_bytes(acceptance))
    if damage in {"acceptance", "run"}:
        path = tmp_path / ("f2-acceptance.json" if damage == "acceptance" else "run.json")
        path.write_bytes(path.read_bytes() + b"\n")
    elif damage in {"common", "replay"}:
        path = common if damage == "common" else replay_path
        path.write_bytes(path.read_bytes() + b"UNFITTED_DRIFT")
    elif damage == "f1":
        manifest["identity"] = "f" * 64
    def f1(path):
        assert path == root / "input/f1/input-manifest.json"
        return manifest
    monkeypatch.setattr(f4, "load_f1_input_manifest", f1)
    # There are deliberately no model results, F1 matrices or native models.
    if damage is None:
        observed = f4._load_f4_source_records(tmp_path, f1_runtime_root=root)
        assert observed["source"] == {"f1_identity": manifest["identity"],
            "f2_acceptance_sha256": sha256_file(tmp_path / "f2-acceptance.json")}
        assert observed["replay"]["response_csv"] == response
    else:
        with pytest.raises(ContractError):
            f4._load_f4_source_records(tmp_path, f1_runtime_root=root)


@pytest.mark.parametrize("family", ["COX_PH", "ELASTIC_NET_COX", "RSF", "GBM_COX", "FPM_TVC_SET_A"])
def test_final_r_audit_numbers_share_original_validation_without_r(tmp_path, monkeypatch, family):
    import sys
    from test_f5 import non_ph_contrast_evidence
    task = {"selected_parents": ["AST_ALT"], "family_design_column_count": 1, "row_count": 100}
    fields = {"COX_PH": {"coefficient_count": 1, "covariance_rank": 1, "iteration_count": 2},
        "ELASTIC_NET_COX": {"alpha": .2, "ratio": .1, "lambda": .2},
        "RSF": {"tree_count": 1000, "mtry": 1, "death_time_count": 4, "prediction_error": .3},
        "GBM_COX": {"tree_count": 20, "training_row_count": 100, "training_loss_count": 20,
                    "minimum_training_loss": .1, "maximum_training_loss": .2},
        "FPM_TVC_SET_A": {"coefficient_count": 6, "covariance_rank": 6}}
    health = dict(fields[family])
    audit = {"selected_parents": ["AST_ALT"], "design_columns": ["AST_ALT"], **health}
    if family == "COX_PH":
        audit.update(training_event_count=40, complete_data_degrees_of_freedom=39, coefficient_ids=["AST_ALT"],
                     coefficient_estimates=[.1], within_standard_errors=[.05], covariance=[[.0025]])
    elif family == "ELASTIC_NET_COX":
        audit.update(coefficient_ids=["AST_ALT"], coefficient_scale=[2.], raw_coefficients=[.1], standardized_coefficients=[.2])
    elif family == "FPM_TVC_SET_A":
        task["row_count"] = 40
        contrast = non_ph_contrast_evidence({"patient_ids": [str(i) for i in range(40)],
            "per_imputation_predictions": [{"model_sha256": "a" * 64}]})[0]
        audit.update(training_event_count=40, complete_data_degrees_of_freedom=34,
            non_ph_contrast={key: item for key, item in contrast.items() if key not in {"imputation", "model_sha256"}})
    calls = []
    def unfitted_audit(command, **kwargs):
        assert Path(command[2]).name == "retained-object-audit.R"
        calls.append(command)
        kwargs["stdout"].write(canonical_json_bytes(audit))
        kwargs["stderr"].write(b"UNFITTED audit transport; no R execution")
        return SimpleNamespace(returncode=0)
    monkeypatch.setattr(f5, "RSCRIPT_EXECUTABLE", sys.executable)
    monkeypatch.setattr(f5.subprocess, "run", unfitted_audit)
    assert f5._validate_retained_model_objects(family, b"UNFITTED-model", b"UNFITTED-baseline", health, task) == audit
    assert f5._validate_retained_r_audit_numbers(family, audit, health, task) == audit and len(calls) == 1
    bad = {**audit, "selected_parents": ["WRONG_PARENT"]}
    with pytest.raises(ContractError, match="F5_FINAL_REFIT_RETAINED_OBJECT_INVALID"):
        f5._validate_retained_r_audit_numbers(family, bad, health, task)
    changed = dict(health)
    changed[next(iter(changed))] += 1
    with pytest.raises(ContractError, match="F5_FINAL_REFIT_RETAINED_OBJECT_HEALTH_DRIFT"):
        f5._validate_retained_r_audit_numbers(family, audit, changed, task)
    assert len(calls) == 1


@pytest.mark.parametrize("case", ["nonzero", "invalid_json", "invalid_numbers", "timeout", "interrupt", "success"])
def test_final_native_audit_retains_failure_streams_and_cleans_success(tmp_path, monkeypatch, case):
    import subprocess
    import sys
    import tempfile
    task = {"selected_parents": ["AST_ALT"], "family_design_column_count": 1, "row_count": 100}
    health = {"tree_count": 1000, "mtry": 1, "death_time_count": 4, "prediction_error": .3}
    audit = {"selected_parents": ["AST_ALT"], "design_columns": ["AST_ALT"], **health}
    if case == "invalid_numbers":
        audit["tree_count"] = 999
    raw_stdout = b"UNFITTED-invalid-json" if case == "invalid_json" else canonical_json_bytes(audit)
    raw_stderr = b"UNFITTED-original-error" * 2000
    def unfitted_audit(command, **kwargs):
        kwargs["stdout"].write(raw_stdout)
        kwargs["stderr"].write(raw_stderr)
        if case == "timeout":
            raise subprocess.TimeoutExpired(command, 120)
        if case == "interrupt":
            raise KeyboardInterrupt("UNFITTED interruption")
        return SimpleNamespace(returncode=3 if case == "nonzero" else 0)
    monkeypatch.setattr(tempfile, "tempdir", str(tmp_path))
    monkeypatch.setattr(f5, "RSCRIPT_EXECUTABLE", sys.executable)
    monkeypatch.setattr(f5.subprocess, "run", unfitted_audit)
    if case == "success":
        assert f5._validate_retained_model_objects("RSF", b"UNFITTED-model", b"UNFITTED-baseline", health, task) == audit
        assert list(tmp_path.iterdir()) == []
    else:
        error_type = subprocess.TimeoutExpired if case == "timeout" else KeyboardInterrupt if case == "interrupt" else ContractError
        with pytest.raises(error_type) as captured:
            f5._validate_retained_model_objects("RSF", b"UNFITTED-model", b"UNFITTED-baseline", health, task)
        roots = list(tmp_path.iterdir())
        assert len(roots) == 1 and roots[0].is_dir()
        assert (roots[0] / "stdout.txt").read_bytes() == raw_stdout and (roots[0] / "stderr.txt").read_bytes() == raw_stderr
        assert (roots[0] / "model.rds").read_bytes() == b"UNFITTED-model" and (roots[0] / "baseline.rds").read_bytes() == b"UNFITTED-baseline"
        assert (roots[0] / "task.json").read_bytes() == canonical_json_bytes(task)
        assert (roots[0] / "fit-health.json").read_bytes() == canonical_json_bytes(health)
        assert (roots[0] / "retained-object-audit.R").read_text() == f5._R_RETAINED_OBJECT_AUDIT
        assert f"F5_RETAINED_AUDIT_EVIDENCE_RETAINED:{roots[0]}" in captured.value.__notes__


def _unfitted_outer_numerical_spawn(item):
    """Exercise the real transport worker; only the unchanged numerical leaf is stubbed."""
    import os
    worker, job = item
    assert runtime._IN_SCIENTIFIC_POOL
    def read(path, **kwargs):
        snapshot = kwargs["accepted_source_reader"](admit_io=lambda **options: None)
        assert snapshot == {"source": {"f1_identity": "a" * 64, "f2_acceptance_sha256": "b" * 64}}
        assert kwargs["compiled_input_record"] == job["compiled_input_record"]
        job["root"].mkdir()
        (job["root"] / "UNFITTED-reader.json").write_bytes(canonical_json_bytes({
            "pid": os.getpid(), "outer": job["compiled_input_record"]["UNFITTED_ORIGINAL_COMPILE_RECORD"],
            "source": snapshot, "engine_threads": os.environ["OMP_NUM_THREADS"], "native_fits": 0}))
        return strict_json_bytes(read_safe_zip(path)["o-fit-execution.json"])
    with pytest.MonkeyPatch.context() as stub:
        stub.setattr(f4, "_load_o_fit_execution_archive", read)
        return worker(job)


@pytest.mark.parametrize("changed", ["archive", "input"])
def test_outer_numerical_worker_rejects_preflight_byte_drift(tmp_path, monkeypatch, changed):
    job = {name: tmp_path / f"{name}.zip" for name in ("archive", "input")}
    for path in job.values():
        path.write_bytes(b"UNFITTED original")
    job["read_reservation"] = {name: {"sha256": sha256_file(path), "size_bytes": path.stat().st_size}
                               for name, path in job.items()}
    job[changed].write_bytes(b"UNFITTED changed!")
    monkeypatch.setattr(f4, "_load_o_fit_execution_archive", lambda *a, **k: pytest.fail("NO_READER_BEFORE_BYTE_BINDING"))
    with pytest.raises(ContractError, match="F4_O_FIT_NUMERICAL_READER_INPUT_DRIFT"):
        f4._read_o_fit_numerical_outer_job(job, source={}, f2_run_root=tmp_path, f1_runtime_root=None)


@pytest.mark.parametrize("stage", ["directory", "manifest"])
def test_outer_numerical_plan_admits_input_before_first_read(tmp_path, monkeypatch, stage):
    import zipfile
    inputs = tmp_path / "input.zip"
    write_deterministic_zip(inputs, {"o-fit-input.json": canonical_json_bytes({"UNFITTED": "x" * 1024**2})})
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda root: {"effective_cpus": 32,
        "available_memory_bytes": 1 if stage == "directory" else 8 * 1024**2,
        "scratch_available_bytes": 10**12, "scratch_root": str(root)})
    monkeypatch.setattr(zipfile.ZipFile, "read", lambda *a, **k: pytest.fail("NO_MANIFEST_BEFORE_RAM_ADMISSION"))
    monkeypatch.setattr(f4, "strict_json_bytes", lambda *a, **k: pytest.fail("NO_DECODE_BEFORE_RAM_ADMISSION"))
    if stage == "directory":
        monkeypatch.setattr(zipfile, "ZipFile", lambda *a, **k: pytest.fail("NO_DIRECTORY_BEFORE_RAM_ADMISSION"))
    with pytest.raises(ContractError, match="F4_O_FIT_NUMERICAL_READER_HEADER_MEMORY_INSUFFICIENT"):
        f4._o_fit_numerical_reader_plan({1: tmp_path / "unread.zip"}, {1: inputs}, {}, tmp_path)


@pytest.mark.parametrize("damage", [None, "duplicate_outer", "full0", "wrong_patient", "last_native_failure", "decision_mix"])
def test_original_f4_aggregate_joins_only_after_six_local_locks(tmp_path, monkeypatch, damage):
    """Native readers are mocked here; actual archive/registry/join owners run."""
    from test_nested_loco import _lock, _receipts, _scores
    ids = [f"c{center}-p{index:02d}" for center in (*nested.OUTER_CENTERS, 55) for index in range(6)]
    centers = {patient: patient.split("-")[0][1:] for patient in ids}
    fields = ["Patient_ID", "All_Cause_Death", "Death_Followup_months"]
    response = {patient: dict(zip(fields, [patient, "1", "50"], strict=True)) for patient in ids}
    policy = {"configured_worker_ceiling": runtime.CPU_MINUS_8, "memory_bytes_per_worker": 1000,
        "scratch_bytes_per_worker": 1000, "memory_reserve_bytes": 100, "scratch_reserve_bytes": 10**15,
        "transfer_archive_worker_ceiling": 6}
    final_numbers = tmp_path / "UNFITTED-final-numbers.zip"
    write_deterministic_zip(final_numbers, {"final.json": b'{"UNFITTED":true}', "heldout-mean.f64": b"UNFITTED"})
    outer_rows, paths, inputs = [], [], {}
    winners = ["COX_PH", "RSF", "GBM_COX", "RSF", "COXTIME_SET_A", "FPM_TVC_SET_A"]
    for outer, center in enumerate(nested.OUTER_CENTERS, 1):
        heldout = [patient for patient in ids if centers[patient] == str(center)]
        training = [patient for patient in ids if patient not in heldout]
        outer_rows.append({"outer_fold": outer, "heldout_center": center, "application_ids": ids,
                           "analysis_ids": training, "validation_ids": heldout})
        context = nested.compile_training_context(scope="OUTER", outer_fold=outer, heldout_center=center,
            training_ids=training, heldout_ids=heldout, centers_by_patient=centers,
            training_response_csv=_csv(fields, [response[patient] for patient in training]),
            mice_member_set_sha256="a" * 64, preprocessing_program_sha256="b" * 64,
            modeling_program_sha256="c" * 64, seed_program_sha256="d" * 64)
        lock, _ = _lock(context, _scores(context, {family: .1 if family == winners[outer - 1] else .2 for family in nested._families()}))
        predicted_ids = [ids[-1], *heldout[1:]] if damage == "wrong_patient" and outer == 6 else heldout
        prediction = nested.seal_selected_prediction(lock=lock, patient_ids=predicted_ids,
            centers=[str(center)] * len(heldout), survival=[[1.] + [.8] * 36] * len(heldout), component_receipts=_receipts(lock))
        decision = _unfitted_confirmed_decision()
        if damage == "decision_mix" and outer == 6:
            decision["aar"]["no_aar_full_data_final_model"] = True
            decision["fit_budget"]["optional_no_aar_full_data"]["authorized"] = True
            decision = nested.validate_science_decision(nested._sealed({key: item for key, item in decision.items() if key != "identity_sha256"}))
        value = nested._sealed({"kind": "PADML_F4_O_FIT_EXECUTION_ARCHIVE_V3",
            "outer_fold": 0 if damage == "full0" and outer == 6 else 1 if damage == "duplicate_outer" and outer == 6 else outer,
            "science_decision_sha256": decision["identity_sha256"],
            "selected_prediction": prediction, "UNFITTED_NATIVE_READER_STUB": True})
        path = tmp_path / f"outer-{outer}.zip"
        write_deterministic_zip(path, {"o-fit-execution.json": canonical_json_bytes(value),
            "o-fit-scores.json": b'{"UNFITTED":true}', "development-lock.json": canonical_json_bytes(lock),
            "final-numbers.zip": final_numbers}, stored_members={"final-numbers.zip"})
        paths.append(path)
        inputs[outer] = tmp_path / f"input-{outer}.zip"
        write_deterministic_zip(inputs[outer], {"o-fit-input.json": canonical_json_bytes({
            "science_decision": decision, "training_context": context, "resource_policy": policy,
            "planned_scoring_fits": len(nested.outer_fresh_score_families(decision)) * 300,
            "score_partitions": [{"evaluation_ids": heldout}], "retained_bytes_per_component": 10**6,
            "expanded_bytes_per_component": 10**6, "shared_storage_bytes": 10**7})})
    calls = {"native": [], "custody": 0, "joins": 0, "UNFITTED_metric_engine": 0, "snapshots": []}
    compiled = {outer: {"UNFITTED_ORIGINAL_COMPILE_RECORD": outer} for outer in range(1, 7)}
    input_options = {"input_bundles": inputs, "compiled_input_records": compiled, "f2_run_root": tmp_path}
    def read(path, *, input_bundle, f2_run_root, **kwargs):
        value = strict_json_bytes(read_safe_zip(path)["o-fit-execution.json"])
        outer = value["outer_fold"]
        assert input_bundle == inputs[outer] and f2_run_root == tmp_path
        assert kwargs["compiled_input_record"] == compiled[outer] and kwargs["compiled_input_record"] is not compiled[outer]
        calls["native"].append(outer)
        # Each spawn receives only the two original source identities.
        def admission(**options):
            return None
        snapshot = kwargs["accepted_source_reader"](admit_io=admission)
        assert kwargs["accepted_source_reader"](admit_io=admission) is snapshot
        assert snapshot == {"source": calls["snapshots"][-1]["source"]} and snapshot is not calls["snapshots"][-1]
        if damage == "last_native_failure" and outer == 6:
            raise ContractError("UNFITTED_LAST_NATIVE_OBJECT_REPLAY_FAILED")
        return value
    def source(*args, **kwargs):
        assert len(calls["native"]) == 6 * calls["custody"] and callable(kwargs["admit_io"])
        kwargs["admit_io"](memory_bytes=256)
        calls["custody"] += 1
        snapshot = {"runtime_root": tmp_path, "f1_manifest": {}, "replay": {},
                    "source": {"f1_identity": "a" * 64, "f2_acceptance_sha256": "b" * 64}}
        calls["snapshots"].append(snapshot)
        return snapshot
    bound_sources = []
    def binding(*args, **kwargs):
        assert args[-1] == [] and calls["native"][-6:] == list(range(1, 7))
        frozen = {"registry": {"outer": outer_rows}, "centers": centers,
                  "response_csv": _csv(fields, list(response.values()))}
        bound_sources.append(frozen)
        return frozen
    original_evaluate = f4.evaluate_predictions
    def evaluate(predictions, response_csv, **kwargs):
        assert calls["native"][-6:] == list(range(1, 7)) and "55" not in predictions["centers"]
        assert nested._response_ids(response_csv, "TEST_JOIN") == predictions["patient_ids"]
        calls["joins"] += 1
        return original_evaluate(predictions, response_csv, **kwargs)
    def metric_engine(command, **options):
        assert Path(command[-1]).name == "f4_metrics.R"
        jobs = strict_json_bytes(options["input"])["jobs"]
        calls["UNFITTED_metric_engine"] += 1
        values = [{"label": job["label"], "UNFITTED_NATIVE_METRICS": True,
            "horizons": {str(h): {"status": "UNFITTED", "reasons": ["UNFITTED"],
                **dict.fromkeys(("slope", "citl", "oe", "ici", "e50", "e90"))} for h in f4.REPORT_HORIZONS},
            "discrimination": {"uno_c_24": {"value": None}, "harrell_c": {"value": None},
                "auc": {str(h): {"value": None} for h in f4.REPORT_HORIZONS}}} for job in jobs]
        options["stdout"].write(canonical_json_bytes({"results": values}))
        options["stderr"].write(b"UNFITTED METRIC ENGINE; no R execution")
        return SimpleNamespace(returncode=0)
    monkeypatch.setattr(f4, "_load_o_fit_execution_archive", read)
    monkeypatch.setattr(f4, "_load_f4_source_records", source)
    monkeypatch.setattr(f4, "_load_o_fit_frozen_source", binding)
    monkeypatch.setattr(f4, "load_f4_inputs", lambda *a, **k: pytest.fail("NO_ALL_MODEL_SOURCE_AT_AGGREGATE"))
    monkeypatch.setattr(f4, "evaluate_predictions", evaluate)
    monkeypatch.setattr(f4.subprocess, "run", metric_engine)
    original_pool = runtime._bounded_ordered_spawn
    def flat(worker, jobs, *, selected_slots, execution_report):
        assert worker.func is f4._read_o_fit_numerical_outer_job and len(jobs) == 6
        assert [job["root"].name for job in jobs] == [f"outer-{outer}" for outer in range(1, 7)]
        copies = [pickle.loads(pickle.dumps((worker, job))) for job in jobs]
        assert all(copy.keywords["source"] == worker.keywords["source"] for copy, _ in copies)
        assert len({id(copy.keywords["source"]) for copy, _ in copies}) == 6
        if damage is None and calls["custody"] == 1:
            values = original_pool(_unfitted_outer_numerical_spawn, copies, selected_slots=selected_slots,
                execution_report=execution_report, schedule_order=list(reversed(range(6))))
            calls["native"].extend(value["outer_fold"] for value in values)
            return values
        execution_report.update(configured_worker_ceiling=runtime.resolve_pool_workers(None),
            admitted_worker_ceiling=selected_slots, runnable_task_count=6, actual_worker_process_peak=1,
            completed_task_count=0, engine_threads=1, status="FAILED")
        values = []
        for copy, job in copies:
            values.append(copy(job))
            execution_report["completed_task_count"] += 1
        execution_report["status"] = "COMPLETED"
        return values
    monkeypatch.setattr(runtime, "_bounded_ordered_spawn", flat)
    target = tmp_path / "ooc.zip"
    if damage is not None:
        with pytest.raises(ContractError) as error:
            f4.aggregate_o_fit_execution_archives(paths, target, **input_options)
        if damage == "decision_mix":
            assert "F4_O_FIT_SCIENCE_DECISION_MISMATCH" in str(error.value)
        assert calls["joins"] == 0 and not target.exists()
        assert calls["custody"] == (0 if damage in {"duplicate_outer", "full0"} else 1)
        if damage == "last_native_failure":
            report = strict_json_bytes((tmp_path / "ooc.zip.native-replay/execution.json").read_bytes())
            assert report["pool"]["status"] == "FAILED" and report["pool"]["completed_task_count"] == 5
        return
    result = f4.aggregate_o_fit_execution_archives(list(reversed(paths)), target, **input_options)
    execution = strict_json_bytes((tmp_path / "ooc.zip.native-replay/execution.json").read_bytes())
    assert execution["execution_scratch_reserve_bytes"] == execution["effective_policy"]["scratch_reserve_bytes"] == 0
    assert execution["pool"]["completed_task_count"] == 6 and execution["pool"]["actual_worker_process_peak"] == 6
    assert execution["pool"]["configured_worker_ceiling"] == runtime.resolve_pool_workers(None)
    probes = [strict_json_bytes((tmp_path / f"ooc.zip.native-replay/outer-{outer}/UNFITTED-reader.json").read_bytes())
              for outer in range(1, 7)]
    assert [probe["outer"] for probe in probes] == list(range(1, 7))
    assert all(probe["engine_threads"] == "1" and probe["native_fits"] == 0 for probe in probes)
    value = strict_json_bytes(read_safe_zip(target)["o-fit-aggregate.json"])
    assert result["model_fit_count"] == 0 and not result["outer_family_consensus_required"]
    assert [row["selected_family"] for row in value["selected_ooc"]["selection_by_outer"]] == winners
    assert value["selected_ooc"]["patient_ids"] == [patient for patient in ids if centers[patient] != "55"]
    assert value["evaluation"]["outcome_join_location"] == "H7_ORIGINAL_F4_F5_EVALUATION_NOT_ACCEPTANCE"
    assert value["status"] == "COMPUTED_PROGRAM_OOC_NOT_STAGE_ACCEPTANCE"
    assert calls["joins"] == calls["custody"] == 1
    assert "evaluation/metrics.zip" in read_safe_zip(target)
    evidence = tmp_path / "retained-reader"
    consumed_sources = []
    def consume_source(frozen, registry):
        assert calls["joins"] == 2 and frozen is bound_sources[-1]
        assert registry["all_patient_ids"] == ids and registry["centers_by_patient"] == centers
        consumed_sources.append((frozen, registry))
    assert f4.load_o_fit_aggregate_archive(target, replay_evidence=evidence,
        _source_consumer=consume_source, **input_options) == value
    assert len(consumed_sources) == 1 and bound_sources[0] is not bound_sources[1]
    assert calls["joins"] == calls["custody"] == 2
    assert calls["snapshots"][0] is not calls["snapshots"][1]
    assert calls["UNFITTED_metric_engine"] == 1

    # Actual parent/worker RAM and worker scratch floors remain mandatory.
    observation = runtime.observe_execution_resources
    for resource in ("memory", "scratch"):
        before = len(calls["native"]), calls["joins"]
        effective = execution["effective_policy"]
        available = effective[f"{resource}_reserve_bytes"] + effective[f"{resource}_bytes_per_worker"] - 1
        field = "available_memory_bytes" if resource == "memory" else "scratch_available_bytes"
        with monkeypatch.context() as short:
            short.setattr(runtime, "observe_execution_resources", lambda root: {**observation(root), field: available})
            short.setattr(runtime, "_bounded_ordered_spawn", lambda *a, **k: pytest.fail("NO_LEAF_BEFORE_SHARED_ADMISSION"))
            with pytest.raises(ContractError):
                f4.aggregate_o_fit_execution_archives(paths, tmp_path / f"short-{resource}.zip", **input_options)
        assert (len(calls["native"]), calls["joins"]) == before
    assert not (evidence / "replayed.zip").exists()
    retained = read_safe_zip(target)
    metric_member = "evaluation/metrics.zip"
    for changed_part in ("missing", "input", "kernel", "output"):
        changed = dict(retained)
        if changed_part == "missing":
            del changed[metric_member]
        else:
            native = read_safe_zip(retained[metric_member])
            if changed_part == "input":
                request = strict_json_bytes(native["input.json"])
                request["jobs"][0]["times"][0] += 1
                native["input.json"] = canonical_json_bytes(request)
            elif changed_part == "kernel":
                native["f4_metrics.R"] += b"\n# UNFITTED changed kernel\n"
            else:
                output = strict_json_bytes(native["stdout.txt"])
                output["results"][0]["horizons"]["24"]["slope"] = 1.25
                native["stdout.txt"] = canonical_json_bytes(output)
            native_path = tmp_path / f"changed-{changed_part}-metrics.zip"
            write_deterministic_zip(native_path, native)
            changed[metric_member] = native_path.read_bytes()
            body = {key: item for key, item in value.items() if key != "identity_sha256"}
            body["native_metric_archive"] = {"member": metric_member, "sha256": sha256_file(native_path),
                                             "size_bytes": native_path.stat().st_size}
            changed["o-fit-aggregate.json"] = canonical_json_bytes(nested._sealed(body))
        bad = tmp_path / f"changed-{changed_part}.zip"
        write_deterministic_zip(bad, changed, stored_members={name for name in changed if name.endswith(".zip")})
        with pytest.raises(ContractError):
            f4.load_o_fit_aggregate_archive(bad, **input_options,
                replay_evidence=tmp_path / f"failed-{changed_part}-reader")
        assert calls["UNFITTED_metric_engine"] == 1
    response[ids[0]]["Death_Followup_months"] = "49"
    with pytest.raises(ContractError, match="F4_NATIVE_METRICS_REPLAY_MISMATCH"):
        f4.load_o_fit_aggregate_archive(target, **input_options,
            replay_evidence=tmp_path / "failed-response-reader")
    assert calls["UNFITTED_metric_engine"] == 1


@pytest.mark.parametrize("command", ["o-fit-compile", "o-fit-execute", "o-fit-aggregate"])
def test_original_f4_cli_forwards_nested_sources_without_global_lock(tmp_path, monkeypatch, capsys, command):
    import sys
    inputs = [tmp_path / f"input-{outer}.zip" for outer in range(1, 7)]
    sources = [tmp_path / f"result-{outer}.zip" for outer in range(1, 7)]
    for path in inputs + sources:
        path.write_bytes(b"UNFITTED_CLI_STUB")
    target = tmp_path / "target.zip"
    calls = []
    def invoke(*args, **kwargs):
        calls.append((args, kwargs))
        return {"UNFITTED_CLI_FORWARDING": True}
    def forbidden(*args, **kwargs):
        pytest.fail("No global-family input consumer belongs in nested CLI forwarding")
    monkeypatch.setattr(f4, "load_f4_inputs", forbidden)
    if command == "o-fit-compile":
        decision, policy = tmp_path / "decision.json", tmp_path / "policy.json"
        decision.write_bytes(canonical_json_bytes({"UNFITTED_DECISION_FORWARDING": True}))
        policy.write_bytes(canonical_json_bytes({"UNFITTED_RESOURCE_FORWARDING": True}))
        argv = [command, str(tmp_path), str(target), "--outer-fold", "1", "--science-decision", str(decision),
                "--resource-policy", str(policy), "--retained-bytes-per-component", "10",
                "--expanded-bytes-per-component", "20", "--shared-storage-bytes", "30"]
        monkeypatch.setattr(f4, "compile_o_fit_bundle", invoke)
    elif command == "o-fit-execute":
        argv = [command, str(target), "--input-bundle", str(inputs[0]), "--outer-fold", "1", "--workers", "4"]
        monkeypatch.setattr(f4, "execute_o_fit_bundle", invoke)
    else:
        argv = [command, str(target), *map(str, sources), "--f2-run-root", str(tmp_path), "--workers", "4"]
        compiled = {}
        for outer, path in enumerate(inputs, 1):
            argv.extend(["--input-bundle", str(path)])
            record_path = tmp_path / f"compile-{outer}.json"
            compiled[outer] = {"UNFITTED_ORIGINAL_COMPILE_RECORD": outer}
            record_path.write_bytes(canonical_json_bytes(compiled[outer]))
            argv.extend(["--compiled-input-record", str(record_path)])
        monkeypatch.setattr(f4, "aggregate_o_fit_execution_archives", invoke)
    monkeypatch.setattr(sys, "argv", ["padml-f4", *argv])
    f4.main()
    args, kwargs = calls[0]
    if command == "o-fit-execute":
        assert args == (None, None, target) and kwargs["input_bundle"] == inputs[0]
    elif command == "o-fit-aggregate":
        assert args == (sources, target) and kwargs["input_bundles"] == dict(enumerate(inputs, 1))
        assert kwargs["compiled_input_records"] == compiled
        assert "locked_family" not in kwargs
    else:
        assert args == (tmp_path, target) and kwargs["shared_storage_bytes"] == 30
        record_path = tmp_path / "original-compile-stdout.json"
        record_path.write_bytes(capsys.readouterr().out.encode("utf-8"))
        assert nested._read_canonical(record_path, "F4_O_FIT_COMPILED_INPUT_RECORD") == {
            "UNFITTED_CLI_FORWARDING": True}
        from padml import f5, f5_sensitivity
        monkeypatch.setattr(f5_sensitivity, "compile_a12_outer_inputs", invoke)
        monkeypatch.setattr(sys, "argv", ["padml-f5", "compile-a12-inputs", str(inputs[0]), str(sources[0]),
            str(target), "--f2-run-root", str(tmp_path), "--outer-fold", "1",
            "--resource-policy", str(policy), "--compiled-input-record", str(record_path)])
        f5.main()
        assert calls[1][1]["compiled_input_record"] == {"UNFITTED_CLI_FORWARDING": True}


@pytest.mark.parametrize("cpus", [32, 64, 128])
def test_original_outer_executor_rejects_arbitrary_per_task_cpu_cap(tmp_path, monkeypatch, cpus):
    monkeypatch.setattr(runtime, "effective_cpu_count", lambda: cpus)
    seen = []
    monkeypatch.setattr(f4, "_execute_o_fit_training_bundle", lambda *args, **kwargs: seen.append(kwargs))
    arguments = {"target": tmp_path / "result.zip", "outer_fold": 1,
                 "input_bundle": tmp_path / "UNFITTED-input.zip"}
    f4.execute_o_fit_bundle(**arguments, workers=cpus - 8)
    assert seen[-1]["workers"] == cpus - 8
    for old_cap in [20, 24, 40, 56]:
        if old_cap == cpus - 8:
            continue
        with pytest.raises(ContractError, match="NESTED_CONFIGURED_CEILING_MUST_BE_EXECUTION_HOST_C_MINUS_8"):
            f4.execute_o_fit_bundle(**arguments, workers=old_cap)
    assert len(seen) == 1


def test_f4_nested_input_cannot_be_mixed_with_global_a15(tmp_path):
    with pytest.raises(ContractError, match="F4_O_FIT_MIXED_DEVELOPMENT_AUTHORITY"):
        f4.execute_o_fit_bundle(tmp_path, tmp_path / "old-global.zip", tmp_path / "target.zip", outer_fold=1,
                               input_bundle=tmp_path / "training-only.zip")


def test_numerical_outer_read_requires_retained_native_before_opening_input(tmp_path):
    with pytest.raises(ContractError, match="F4_O_FIT_RETAINED_NATIVE_PATH_INVALID"):
        f4._execute_o_fit_training_bundle(tmp_path / "UNREAD.zip", None,
            outer_fold=1, workers=None, retained_native=None)
    assert list(tmp_path.iterdir()) == []
    with pytest.raises(ContractError, match="F4_O_FIT_BUNDLE_PATH_INVALID"):
        f4.execute_o_fit_bundle(target=None, outer_fold=1, input_bundle=tmp_path / "UNREAD.zip",
                               retained_native=tmp_path)


@pytest.mark.parametrize("cpus", [32, 64, 128])
def test_numerical_outer_read_keeps_configured_cpu_ceiling(tmp_path, monkeypatch, cpus):
    monkeypatch.setattr(runtime, "effective_cpu_count", lambda: cpus)
    with pytest.raises(ContractError, match="NESTED_CONFIGURED_CEILING_MUST_BE_EXECUTION_HOST_C_MINUS_8"):
        f4._execute_o_fit_training_bundle(tmp_path / "UNREAD.zip", None,
            outer_fold=1, workers=cpus - 9, retained_native=tmp_path)
    assert list(tmp_path.iterdir()) == []


@pytest.mark.parametrize("excess", [0, 1], ids=["exact-shared-boundary", "unknown-residue-overrun"])
def test_numerical_outer_read_counts_retained_storage_without_new_archive(tmp_path, monkeypatch, excess):
    """Only the publication/storage seam; upstream numerical leaves are UNFITTED."""
    root = tmp_path / "retained"
    (root / "request/training").mkdir(parents=True)
    (root / "fits").mkdir()
    (root / "scratch").mkdir()
    monkeypatch.setattr(runtime, "effective_cpu_count", lambda: 64)
    request = {"training_context": {"outer_fold": 1}, "identity_sha256": "a" * 64,
               "science_decision": _unfitted_confirmed_decision(fresh_seven=True, fixed_bootstrap=True),
               "resource_policy": {}, "retained_bytes_per_component": 1000,
               "expanded_bytes_per_component": 1000, "shared_storage_bytes": 100_000,
               "planned_scoring_fits": 2100, "post_lock_templates": [], "score_partitions": [],
               "component_records": []}
    source = tmp_path / "input.zip"
    write_deterministic_zip(source, {"o-fit-input.json": canonical_json_bytes(request)})
    (root / "request/o-fit-input.json").write_bytes(canonical_json_bytes(request))
    (root / "request/training/response.csv").write_bytes(b"UNFITTED response")
    for name in ("o-fit-scores.json", "development-lock.json", "final-numbers.zip"):
        (root / name).write_bytes(b"UNFITTED numeric leaf")
    for imp in range(1, 21):
        (root / f"fits/M{imp:02d}.zip").write_bytes(b"UNFITTED original model archive")
    held = sum(path.stat().st_size for path in root.rglob("*") if path.is_file())
    assert held < request["shared_storage_bytes"]
    (root / "unknown-residue.bin").write_bytes(b"X" * (request["shared_storage_bytes"] - held + excess))
    before = {str(path.relative_to(root)): sha256_file(path) for path in root.rglob("*") if path.is_file()}
    def scores(*args, **kwargs):
        assert kwargs["replay"] is True and kwargs["resume"] is False
        return {"request": request, "result": {"identity_sha256": "b" * 64, "fresh_score_execution": []},
                "storage_usage": {"component_retained_size_bytes": 0}}
    def final(*args, **kwargs):
        assert kwargs["replay"] is True
        return {"development_lock": {"selected_family": "COX_PH"},
                "selected_prediction": {"UNFITTED": True}, "component_receipts": [],
                "native_members": {f"fits/M{imp:02d}.zip": {"sha256": sha256_file(root / f"fits/M{imp:02d}.zip"),
                    "size_bytes": (root / f"fits/M{imp:02d}.zip").stat().st_size} for imp in range(1, 21)}}
    monkeypatch.setattr(f5, "_full_data_locked_score_program", scores)
    monkeypatch.setattr(f5, "_full_score_resource_admission", lambda *args, **kwargs: ({"admitted_worker_ceiling": 1}, {}))
    monkeypatch.setattr(f4, "_o_fit_post_lock_m20", final)
    original_storage = f5._full_score_storage_usage
    pending = []
    def storage(*args, **kwargs):
        pending.append(kwargs["pending_result_bytes"])
        return original_storage(*args, **kwargs)
    monkeypatch.setattr(f5, "_full_score_storage_usage", storage)
    monkeypatch.setattr(f4, "write_deterministic_zip", lambda *args, **kwargs: pytest.fail("No whole archive may be written"))
    if excess:
        with pytest.raises(ContractError, match="NESTED_FULL_SCORE_SHARED_STORAGE_ESTIMATE_EXCEEDED") as failure:
            f4._execute_o_fit_training_bundle(source, None, outer_fold=1, workers=56, retained_native=root)
        assert f"F4_O_FIT_OUTER_EVIDENCE_RETAINED:{root}" in failure.value.__notes__
    else:
        value = f4._execute_o_fit_training_bundle(source, None, outer_fold=1, workers=56, retained_native=root)
        assert value["kind"] == "PADML_F4_O_FIT_EXECUTION_ARCHIVE_V3"
        assert len(value["members"]) == 3 and value["input_archive"]["sha256"] == sha256_file(source)
        assert len(value["native_members"]) == 20
        assert value["identity_sha256"] == nested._sha({key: item for key, item in value.items() if key != "identity_sha256"})
    assert pending == [0]
    assert before == {str(path.relative_to(root)): sha256_file(path) for path in root.rglob("*") if path.is_file()}
    if not excess:
        with pytest.raises(ContractError, match="NESTED_FULL_SCORE_SHARED_STORAGE_ESTIMATE_EXCEEDED"):
            f4._execute_o_fit_training_bundle(source, tmp_path / "unaffordable.zip",
                outer_fold=1, workers=56, retained_native=root)
        assert pending[-1] > 0 and not (tmp_path / "unaffordable.zip").exists()
