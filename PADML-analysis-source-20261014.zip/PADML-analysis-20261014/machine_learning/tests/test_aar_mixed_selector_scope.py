"""Original public owner admission; no inputs or scientific leaf are read."""
import pytest
from padml import f5_sensitivity as sensitivity, nested_loco as nested
from padml.bundle import ContractError


@pytest.mark.parametrize("case,requires_selector", [
    ("direct-complete", False), ("total-complete", False), ("all-fresh", False),
    ("redevelopment-prefix", True), ("redevelopment-complete", True),
    ("redevelopment-prefix-with-selector", False)])
def test_continuous_selector_belongs_only_to_redevelopment(tmp_path, case, requires_selector):
    direct, total, redevelopment = nested.AAR_ESTIMANDS
    roots, batches = {}, {branch: [] for branch in nested.AAR_ESTIMANDS}
    if case in {"direct-complete", "total-complete", "redevelopment-complete"}:
        branch = {"direct-complete": direct, "total-complete": total,
                  "redevelopment-complete": redevelopment}[case]
        roots[branch] = tmp_path / "retained-q"
        del batches[branch]
    if case.startswith("redevelopment-prefix"):
        batches[redevelopment] = [tmp_path / "retained-batch"]
    expected = "F5_A12_Q_RESULT_SCOPE_INVALID" if requires_selector else "F5_A12_OUTER_PATH_INVALID"
    with pytest.raises(ContractError, match=expected):
        sensitivity.execute_a12_outer_bundle(tmp_path / "UNREAD-native.zip", tmp_path / "UNCREATED.zip",
            input_bundle=tmp_path / "UNREAD-input.zip", q_roots=roots, q_batches=batches,
            continuous_batch_root=tmp_path, retained_bytes_per_task=1, retained_bytes_per_component=1,
            selector_root=tmp_path / "selector" if case.endswith("with-selector") else None)
    assert list(tmp_path.iterdir()) == []
