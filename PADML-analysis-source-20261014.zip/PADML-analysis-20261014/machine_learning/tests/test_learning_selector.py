from __future__ import annotations

import copy
import math
import os
from pathlib import Path
import shutil
import subprocess

import pytest

from padml.bundle import ContractError, canonical_json_bytes, sha256_bytes, strict_json_bytes
from padml.f4 import (
    _choose_learning_selector_alpha, _execute_learning_curve_selector,
    _learning_selector_subsets, _prepare_learning_selector_inputs,
    _registered_learning_curve_cells, _run_learning_selector_path,
    _summarize_learning_selector_alpha,
)
from padml.f2_kernel import _elastic_candidate_parents, _elastic_ratios, predictor_contract
from test_f4 import learning_curve_binding_fixture
from test_selector_epv import _alpha_record, _contract


def record(alpha=0.2, **kwargs):
    original = _alpha_record(alpha, **kwargs)
    partitions = [{**row, "mi_losses": row["mi_losses"][:5],
                   "mi_lambda_path_health": row["mi_lambda_path_health"][:5]}
                  for row in original["partition_losses"] if row["repeat"] == 2 and row["inner_fold"] != 1]
    return {"alpha": alpha, "partition_losses": partitions, "full_paths": original["outer_paths"][:5]}


def reseal(path):
    coefficients = path["parent_coefficients"]
    path["penalized_active_count_path"] = [sum(x != 0 for parent, values in coefficients.items()
                                              if parent != "AST_ALT" for x in values[index])
                                           for index in range(150)]
    path["coefficient_path_sha256"] = sha256_bytes(canonical_json_bytes({
        "parent_design_columns": path["parent_design_columns"], "parent_coefficients": coefficients}))


def test_m5_weighted_fold_se_not_repeat_se_or_imputation_se():
    value = record()
    shifts = [-6.0, -2.0, 2.0, 6.0]
    for partition, shift in zip(value["partition_losses"], shifts):
        partition["mi_losses"] = [[x + shift for x in path] for path in partition["mi_losses"]]
    result = _summarize_learning_selector_alpha(value, 1)
    weights = [12 / 54, 13 / 54, 14 / 54, 15 / 54]
    center = sum(w * x for w, x in zip(weights, shifts))
    expected_se = math.sqrt(sum(w * (x - center) ** 2 for w, x in zip(weights, shifts)) / 3)
    assert result["fold_weights"] == weights and result["mi_partition_loss_count"] == 20
    for imp, decision in enumerate(result["imputation_decisions"], 1):
        best = 8 if imp % 2 else 16
        assert decision["fold_se_path"][best] == pytest.approx(expected_se, abs=1e-14)
        assert decision["mean_loss_path"][best] == pytest.approx(10.2 + center)
        assert decision["r_min"] == result["ratios"][best]
        assert decision["r_1se"] == result["ratios"][best - 1]


def test_m5_individual_lambda_forced_df_and_full_seta_columns():
    value = record()
    result = _summarize_learning_selector_alpha(value, 1)
    assert result["status"] == "FEASIBLE"
    assert result["active_design_df_by_imputation"] == [2] * 5
    assert result["common_set_design_df"] == 4 and result["common_set_epv"] == 15
    assert result["selected_parents"] == ["AST_ALT", "X"]
    assert result["lambda_by_imputation"] == [
        path["lambda_max"] * result["ratios"][8 if i % 2 else 16]
        for i, path in enumerate(value["full_paths"], 1)]
    assert len(set(result["lambda_by_imputation"])) == 5


def test_m5_frequency_three_of_five_is_not_twenty_imputation_threshold():
    value = record()
    for imp, path in enumerate(value["full_paths"], 1):
        for index in range(30):
            path["parent_coefficients"]["X"][index] = [1.0 if imp <= 3 else 0.0, 0.0, 0.0]
            path["parent_coefficients"]["Y"][index] = [1.0 if imp <= 2 else 0.0]
        reseal(path)
    result = _summarize_learning_selector_alpha(value, 1)
    assert result["natural_frequency"] == {"X": 3, "Y": 2}
    assert result["selected_parents"] == ["AST_ALT", "X"]


def test_m5_p90_is_fifth_order_statistic_not_interpolated():
    value = record()
    path = value["full_paths"][-1]
    path["parent_coefficients"]["X"][:30] = [[1.0, 1.0, 1.0] for _ in range(30)]
    reseal(path)
    result = _summarize_learning_selector_alpha(value, 1)
    assert result["active_design_df_by_imputation"] == [2, 2, 2, 2, 4]
    assert result["median_active_design_df"] == 2 and result["p90_active_design_df"] == 4


def test_m5_zero_se_has_no_unapproved_tolerance_in_one_se():
    value = record()
    for partition in value["partition_losses"]:
        for path in partition["mi_losses"]:
            path[7], path[8] = 1.0 + 1e-12, 1.0
    result = _summarize_learning_selector_alpha(value, 1)
    assert result["selected_ratio_by_imputation"] == [result["ratios"][8]] * 5


def test_m5_complete_infeasibility_only_and_no_constraint_relaxation():
    bad, good = record(.05, infeasible=True), record(.1)
    chosen, summaries = _choose_learning_selector_alpha([bad, good], [.05, .1], 1)
    assert chosen["alpha"] == .1
    assert [row["status"] for row in summaries] == ["EPV_INFEASIBLE", "FEASIBLE"]
    with pytest.raises(ContractError, match="EPV_UNRESOLVED"):
        _choose_learning_selector_alpha([bad], [.05], 1)
    overfull = _summarize_learning_selector_alpha(record(common_set_overfull=True), 1)
    assert overfull["reason_code"] == "COMMON_SETA_EPV_BELOW_MINIMUM"
    assert all(row["status"] == "FEASIBLE" for row in overfull["imputation_decisions"])


def test_m5_scaled_fold_counts_are_still_population_drift():
    left, right = record(.1), record(.2)
    for partition in right["partition_losses"]:
        partition["validation_n"] *= 2
    with pytest.raises(ContractError, match="POPULATION_OR_DESIGN_DRIFT"):
        _choose_learning_selector_alpha([left, right], [.1, .2], 1)


@pytest.mark.parametrize("corruption", ["nan", "missing_fold", "duplicate_fold", "missing_m5",
                                         "coefficient_hash", "lambda_sentinel", "repeat"])
def test_m5_numerical_and_missing_errors_cannot_be_swallowed(corruption):
    bad, invalid = record(.05, infeasible=True), record(.1, infeasible=True)
    if corruption == "nan":
        invalid["partition_losses"][-1]["mi_losses"][-1][-1] = float("nan")
    elif corruption == "missing_fold":
        invalid["partition_losses"].pop()
    elif corruption == "duplicate_fold":
        invalid["partition_losses"][-1] = copy.deepcopy(invalid["partition_losses"][0])
    elif corruption == "missing_m5":
        invalid["full_paths"].pop()
    elif corruption == "coefficient_hash":
        invalid["full_paths"][-1]["coefficient_path_sha256"] = "0" * 64
    elif corruption == "repeat":
        invalid["partition_losses"][-1]["repeat"] = 1
    else:
        invalid["full_paths"][-1]["lambda_upper_bound"]["sentinel_equivalent"] = True
    with pytest.raises(ContractError) as error:
        _choose_learning_selector_alpha([bad, invalid], [.05, .1], 1)
    assert "EPV_UNRESOLVED" not in str(error.value)


def test_m5_four_registered_subsets_preserve_all_sampled_patients():
    binding = learning_curve_binding_fixture()
    cells = _registered_learning_curve_cells(*binding, family="COX_PH")
    for cell in cells:
        subsets = _learning_selector_subsets(binding[0], cell)
        assert len(subsets) == 4
        assert {x["inner_fold"] for x in subsets} == set(range(1, 6)) - {cell["inner_fold"]}
        validation = [p for x in subsets for p in x["evaluation_ids"]]
        assert len(validation) == len(set(validation)) == len(cell["analysis_ids"])
        for subset in subsets:
            assert set(subset["fit_ids"]).isdisjoint(subset["evaluation_ids"])
            assert set(subset["fit_ids"] + subset["evaluation_ids"]) == set(cell["analysis_ids"])
            assert set(subset["fit_ids"]).isdisjoint(cell["validation_ids"])


def test_m5_coarse_fine_cache_does_not_refit_overlapping_alphas(tmp_path, monkeypatch):
    binding = learning_curve_binding_fixture()
    cell = _registered_learning_curve_cells(*binding, family="COX_PH")[0]
    target = tmp_path / "selector"
    def prepare(*args, **kwargs):
        target.mkdir()
        return []
    phases = []
    def phase(cell, partitions, alphas, directory, **kwargs):
        phases.append(alphas)
        return {a: record(a) for a in alphas}
    monkeypatch.setattr("padml.f4._prepare_learning_selector_inputs", prepare)
    monkeypatch.setattr("padml.f4._evaluate_learning_selector_phase", phase)
    monkeypatch.setattr("padml.f4.resolve_pool_workers", lambda workers: 1)
    result = _execute_learning_curve_selector(*binding, cell, tmp_path / "native", target, rscript="unused")
    assert len(phases) == 2 and set(phases[0]).isdisjoint(phases[1])
    assert result["coarse_alpha_order"] == _contract()["alpha_grid"]["coarse"]
    assert result["distinct_alpha_count"] == len(set(phases[0] + phases[1]))
    assert result["final_model_fits"] == result["new_mice_chains"] == 0
    assert result["formal_stage_acceptance"] is False


def test_m5_native_fixed_inner_and_full_path_from_retained_mice(tmp_path, monkeypatch):
    from padml.runtime import RSCRIPT_EXECUTABLE
    fixture = os.environ.get("PADML_LEARNING_MICE_RETAINED")
    if not fixture:
        pytest.skip("Requires retained synthetic M5; no MICE fits are allowed")
    fixture = Path(fixture)
    source = Path(os.environ.get("PADML_LEARNING_MICE_NATIVE", str(fixture / "fixed-m5")))
    contract, cell, keys = (strict_json_bytes((fixture / name).read_bytes())
                            for name in ("binding.json", "cell.json", "patient-keys.json"))
    covariates, responses = ((fixture / name).read_bytes() for name in ("covariates.csv", "response.csv"))
    native = tmp_path / "retained-m5"
    shutil.copytree(source, native)
    run, actions = subprocess.run, []
    def observed(command, **kwargs):
        kernel = Path(command[2]).name
        assert kernel in {"f4_learning_mice.R", "f4_learning_recipe.R", "f4_learning_selector.R"}
        if kernel == "f4_learning_mice.R":
            assert command[3] == "REPLAY"
        if kernel == "f4_learning_selector.R":
            assert actions.count(kernel) < 2, "Fixed native budget is one inner plus one full path"
        actions.append(kernel)
        return run(command, **kwargs)
    monkeypatch.setattr("padml.f4.subprocess.run", observed)
    partitions = _prepare_learning_selector_inputs(contract, covariates, responses, keys, cell,
                                                    native, tmp_path / "inputs", rscript=RSCRIPT_EXECUTABLE)
    predictors = predictor_contract(Path(__file__).resolve().parents[1] / "padml")
    spec = {"execution_scope": "F4_LEARNING_SELECTOR_M5", "family": "ELASTIC_NET_COX",
            "imputation_count": 5, "predictors": predictors, "time": "Death_Followup_months",
            "outcome": "All_Cause_Death"}
    tasks = tmp_path / "native-paths"
    tasks.mkdir()
    for partition in (partitions[0], partitions[-1]):
        task = {"task_id": f"K{partition['inner_fold']}_M01", "partition_id": partition["partition_id"],
                "imputation": 1, "family": "ELASTIC_NET_COX", "selected_parents": _elastic_candidate_parents(spec),
                "parameters": {}, "alphas": [.2], "ratios": _elastic_ratios(_contract()),
                "producer_kind": "ELASTIC_INNER_PATH" if partition["inner_fold"] else "ELASTIC_OUTER_PATH",
                "transform_recipe": partition["transform_recipe"], "seed": cell["seeds"]["selector"] + 1}
        result = _run_learning_selector_path((spec, partition, task, str(tasks), RSCRIPT_EXECUTABLE))
        path = result["sealed_elastic_paths"][0]
        assert path["lambda_max"] > 0 and path["penalized_entry_covered"] is True
        assert len(path["losses"] if partition["inner_fold"] else path["parent_coefficients"]["AST_ALT"]) == 150
        native_spec = strict_json_bytes((tasks / task["task_id"] / "native/spec.json").read_bytes())
        assert "evaluation_response" not in native_spec["partition"]
        assert set(native_spec["partition"]["fit_ids"]).isdisjoint(cell["validation_ids"])
    assert actions.count("f4_learning_mice.R") == 2
    assert actions.count("f4_learning_recipe.R") == 5
    assert actions.count("f4_learning_selector.R") == 2


def test_m5_retained_native_paths_replay_through_current_entry_without_refitting(tmp_path, monkeypatch):
    from types import SimpleNamespace
    fixture = os.environ.get("PADML_LEARNING_SELECTOR_RETAINED")
    if not fixture:
        pytest.skip("Requires the already-computed fixed native paths; no fits are permitted")
    fixture = Path(fixture)
    case = fixture / "native-tests/test_m5_native_fixed_inner_and0"
    partitions = strict_json_bytes((case / "inputs/partitions.json").read_bytes())
    sources = [case / "native-paths/K2_M01", fixture / "native-completion/K0_M01/native"]
    calls = []
    def replay(command, **kwargs):
        current = strict_json_bytes(Path(command[3]).read_bytes())
        source = sources[len(calls)]
        original = strict_json_bytes((source / "spec.json").read_bytes())
        assert {k: v for k, v in current.items() if k != "output_path"} == {
            k: v for k, v in original.items() if k != "output_path"}
        root = Path(current["output_path"]).parent
        output = "recovered-output.json" if len(calls) == 0 else "output.json"
        shutil.copyfile(source / output, root / "output.json")
        for path in source.glob("*.bin"):
            shutil.copyfile(path, root / path.name)
        calls.append(current["task"]["producer_kind"])
        return SimpleNamespace(returncode=0, stdout=b"retained native replay; no fitting\n", stderr=b"")
    monkeypatch.setattr("padml.f4.subprocess.run", replay)
    for partition, source in zip((partitions[0], partitions[-1]), sources):
        native = strict_json_bytes((source / "spec.json").read_bytes())
        spec = {k: v for k, v in native.items() if k not in {"partition", "task", "output_path"}}
        result = _run_learning_selector_path((spec, partition, native["task"], str(tmp_path), "unused"))
        assert result["imputation"] == 1 and result["sealed_elastic_paths"][0]["alpha"] == .2
        assert (tmp_path / native["task"]["task_id"] / "stdout.txt").is_file()
        assert not (tmp_path / native["task"]["task_id"] / "native/stdout.txt").exists()
        if partition["inner_fold"]:
            assert len(list((tmp_path / native["task"]["task_id"] / "native").glob("*.bin"))) == 2
    assert calls == ["ELASTIC_INNER_PATH", "ELASTIC_OUTER_PATH"]
