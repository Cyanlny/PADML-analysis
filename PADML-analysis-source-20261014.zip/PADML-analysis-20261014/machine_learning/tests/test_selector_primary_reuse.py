from __future__ import annotations

import copy
from unittest.mock import Mock

import pytest

import padml.capsule as capsule
import padml.f2_kernel as kernel
import padml.f2_validation as validation
from padml._science_authority import load_science_authority
from padml.bundle import ContractError, canonical_json_bytes, sha256_bytes, sha256_file, write_deterministic_zip
from padml.f2 import materialize_requests


UNIT = "selector-f1-elastic-net-cox"


def digest(value):
    return sha256_bytes(canonical_json_bytes(value))


def seal(value):
    return {**value, "identity": digest({key: item for key, item in value.items() if key != "identity"})}


@pytest.fixture
def primary_binding(tmp_path):
    previous = materialize_requests(run_id="f2-primary-old", source_identity="1" * 64,
        runtime_identity="2" * 64, worker_identity="3" * 64, input_identity="4" * 64)[UNIT]
    request = materialize_requests(run_id="f2-primary-new", source_identity="5" * 64,
        runtime_identity="6" * 64, worker_identity="7" * 64, input_identity="4" * 64)[UNIT]
    model_input = {"identity": "8" * 64, "fold": 1}
    search = seal({"schema_version": "1.0.0", "kind": "PADML_F2_ELASTIC_SEARCH_REUSE",
                   "model_input_identity": model_input["identity"]})
    value = {"family": "ELASTIC_NET_COX", "model_input": model_input,
             "selector_evidence": {"selected_parents": ["AST_ALT", "X"], "primary_execution": {"engine_threads": 1},
                                   "primary_selector_sha256": "9" * 64, "sensitivity_evidence": {"old": True},
                                   "selector_execution_identity_sha256": "a" * 64},
             "search_trace": {"search_reuse": search, "grid": [1, 2, 3]}, "predictions": [[.9, .8]],
             "selected_spec": {"lambda": [.2, .3]}, "stopping_and_convergence": [20],
             "selector_evidence_sha256": "b" * 64, "science_contract_sha256": "c" * 64}
    primary = capsule.selector_primary_projection(value)
    directory = tmp_path / "selector-primary"
    directory.mkdir()
    path = directory / f"{UNIT}.zip"
    write_deterministic_zip(path, {"primary.json": canonical_json_bytes(primary)})
    def object_record(origin, name, sha, size):
        return {"object_key": f"v22/padml/science/{origin['run_id']}/F2/{origin['transaction_id']}/{UNIT}/{name}.zip",
                "sha256": sha, "size_bytes": size}
    source = seal({"schema_version": "1.0.0", "kind": "PADML_F2_SELECTOR_PRIMARY_REUSE",
        "source_run_identity": "d" * 64, "source_capsule_sha256": "e" * 64, "source_request": previous,
        "source_result": object_record(previous, "result", "f" * 64, 100),
        "primary_science_identity": capsule.primary_science_identity(load_science_authority()),
        "primary_sha256": digest(primary), "model_input_identity": model_input["identity"],
        "selector_search_reuse": search, "archive": object_record(request, "primary", sha256_file(path), path.stat().st_size)})
    return path, source, request, model_input, value, primary


def test_primary_archive_preserves_every_primary_field_and_omits_old_sensitivity(primary_binding):
    path, source, request, model_input, old, primary = primary_binding
    assert capsule.load_selector_primary(path, source, request, model_input) == primary
    assert "sensitivity_evidence" not in primary["selector_evidence"]
    for field in ("predictions", "search_trace", "selected_spec", "stopping_and_convergence"):
        assert primary[field] == old[field]
    assert source["source_request"]["identities"]["runtime"] != request["identities"]["runtime"]


@pytest.mark.parametrize("field", ["seed", "epv", "frequency", "tree_count", "boruta_version"])
def test_primary_reuse_does_not_allow_sensitivity_science_relaxation(field):
    original = load_science_authority()
    changed = copy.deepcopy(original)
    sensitivity = changed["science"]["f2_model_development"]["selector_sensitivity"]
    if field == "seed":
        sensitivity["seed_policy"]["base"] += 1
    elif field == "epv":
        sensitivity["shared_contract"]["epv_minimum"] = 10
    elif field == "frequency":
        sensitivity["shared_contract"]["main_frequency"] = "10/20"
    elif field == "tree_count":
        sensitivity["boruta"]["ranger_num_trees"] = 100
    else:
        sensitivity["boruta"]["version"] = "11.0.0"
    assert capsule.primary_science_identity(original) != capsule.primary_science_identity(changed)


@pytest.mark.parametrize("damage", ["input", "seed", "unit", "science", "payload", "symlink", "old_sensitivity"])
def test_primary_reuse_rejects_wrong_binding_or_old_sensitivity(primary_binding, damage, tmp_path):
    path, source, request, model_input, old, primary = copy.deepcopy(primary_binding)
    if damage == "input":
        source["source_request"]["identities"]["input"] = "0" * 64
    elif damage == "seed":
        source["source_request"]["seed"] += 1
    elif damage == "unit":
        source["source_request"]["unit_id"] = "selector-f2-elastic-net-cox"
    elif damage == "science":
        source["primary_science_identity"] = "0" * 64
    elif damage == "payload":
        source["primary_sha256"] = "0" * 64
    elif damage == "symlink":
        link = tmp_path / "linked.zip"
        link.symlink_to(path)
        path = link
    else:
        path = tmp_path / "mixed.zip"
        write_deterministic_zip(path, {"primary.json": canonical_json_bytes(old)})
        source["archive"].update(sha256=sha256_file(path), size_bytes=path.stat().st_size)
        source["primary_sha256"] = digest(old)
    source = seal(source)
    with pytest.raises(ContractError):
        capsule.load_selector_primary(path, source, request, model_input)


def test_execute_model_sensitivity_only_never_searches_or_refits(primary_binding, tmp_path, monkeypatch):
    path, source, request, model_input, old, primary = primary_binding
    model_input = {**model_input, "lineage": {"f1_registered_partition_identity": "a" * 64}}
    primary["model_input"] = model_input
    primary["f1_library_summary_sha256"] = digest({})
    source["primary_sha256"] = digest(primary)
    monkeypatch.setattr(capsule, "load_selector_primary", Mock(return_value=primary))
    registered = {"identity": "a" * 64, "partitions": [{"kind": "OUTER", "partition_id": "OUTER_F1"}]}
    cap = {"manifest": {"selector_primary_reuse": {UNIT: source}},
           "approved_registry": {"model_inputs": [model_input] * 6}}
    monkeypatch.setattr(kernel, "admitted_f1_frozen_data", lambda *args: ({}, tmp_path / "frozen.csv", {}))
    monkeypatch.setattr(kernel, "_cached_fold_assets", lambda *args: ({}, registered, {}, {}))
    monkeypatch.setattr(kernel, "predictor_contract", lambda *args: {})
    monkeypatch.setattr(kernel, "_expected_model_input", lambda *args: model_input)
    monkeypatch.setattr(kernel, "compile_model_spec", lambda *args: {"family": "ELASTIC_NET_COX"})
    monkeypatch.setattr(kernel, "_finalize_model_result", lambda value, spec: value)
    cap["authority_slice"] = load_science_authority()
    sensitivity = Mock(return_value={"identity_sha256": "1" * 64, "execution_identity_sha256": "2" * 64})
    monkeypatch.setattr(kernel, "_run_selector_sensitivity", sensitivity)
    forbidden = [Mock(side_effect=AssertionError("UNAUTHORIZED_REFIT")) for _ in range(3)]
    for function, stub in zip(("_run_r_registered_elastic", "_evaluate_elastic_alpha_phase", "_run_r_prediction_batch"), forbidden):
        monkeypatch.setattr(kernel, function, stub)
    result = kernel.execute_model(tmp_path / "capsule.zip", cap, request, tmp_path,
                                  cache_root=tmp_path / "cache", checkpoint_root=tmp_path)
    assert sensitivity.call_count == 1 and all(stub.call_count == 0 for stub in forbidden)
    assert result["primary_reuse"] == capsule.primary_reuse_receipt(source)
    assert result["predictions"] == old["predictions"]
    assert result["selected_spec"] == old["selected_spec"]


@pytest.mark.parametrize("damage", ["prediction", "lambda", "grid", "seta", "fit_count"])
def test_sole_validator_checks_exact_primary_before_scientific_acceptance(primary_binding, damage):
    _, source, request, model_input, _, primary = copy.deepcopy(primary_binding)
    value = {**primary, "primary_reuse": capsule.primary_reuse_receipt(source)}
    if damage == "prediction":
        value["predictions"][0][0] = .5
    elif damage == "lambda":
        value["selected_spec"]["lambda"][0] *= 10
    elif damage == "grid":
        value["search_trace"]["grid"].pop()
    elif damage == "seta":
        value["selector_evidence"]["selected_parents"].pop()
    else:
        value["primary_reuse"]["current_elastic_fit_count"] = False
    with pytest.raises(ContractError, match="PRIMARY_WRITEBACK_FORBIDDEN"):
        validation._validate_f2_model(request, value, load_science_authority(), {}, model_input, None,
                                      expected_selector_primary=source)
