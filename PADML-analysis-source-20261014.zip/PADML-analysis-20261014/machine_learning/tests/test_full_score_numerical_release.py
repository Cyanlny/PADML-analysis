"""Synthetic cleanup boundary; no scientific execution or cleanup retries."""
import pytest

from padml import f5, runtime


@pytest.mark.parametrize("owner", ["FULL_SCORE_COX_NUMBERS", "FULL_SCORE_Q_NUMBERS"])
@pytest.mark.parametrize("failure", ["unknown", "release", "malformed", "memory"])
@pytest.mark.parametrize("capacity", ["ready", "ram", "space"])
def test_release_diagnostics_preserve_science_and_fresh_admission(
        tmp_path, monkeypatch, owner, failure, capacity):
    gib = 1024**3
    policy = dict(configured_worker_ceiling=runtime.CPU_MINUS_8,
        memory_bytes_per_worker=2*gib, scratch_bytes_per_worker=gib,
        memory_reserve_bytes=gib, scratch_reserve_bytes=0, transfer_archive_worker_ceiling=24)
    observation = dict(effective_cpus=32, available_memory_bytes=8*gib,
        scratch_available_bytes=8*gib, scratch_root=str(tmp_path))
    if capacity == "ram": observation["available_memory_bytes"] = 1
    if capacity == "space": observation["scratch_available_bytes"] = 1
    science = dict(status="TRAINING_SCORING_COMPLETE_NOT_FINAL_MODEL", error=None,
        score_numerical_component_count=300, new_model_fits=0)
    report = {**science, "resource_reservation": {"effective_policy": policy}}
    calls = []
    receipt = dict(status="UNKNOWN", owner=owner, pid=1, reason="UNFITTED_SCAN")
    def memory():
        calls.append("memory")
        if failure == "memory": raise OSError("UNFITTED_MEMORY")
        return {}
    def release(paths, **kwargs):
        calls.append("release")
        assert paths == [] and kwargs["owner"] == owner
        if failure == "release": raise OSError("UNFITTED_RELEASE")
        return {} if failure == "malformed" else receipt
    def observe(root):
        calls.append("admission_observation")
        assert root == tmp_path
        return observation
    monkeypatch.setattr(runtime, "observe_step_memory", memory)
    monkeypatch.setattr(runtime, "release_step_resources", release)
    monkeypatch.setattr(runtime, "observe_execution_resources", observe)
    f5._full_score_numerical_release(report, tmp_path, [], owner=owner, released_references=[])
    assert {key: report[key] for key in science} == science
    assert calls == (["memory", "admission_observation"] if failure == "memory"
                     else ["memory", "release", "admission_observation"])
    assert (report["resource_error"] is None) == (failure == "unknown")
    if failure == "unknown": assert report["resource_release"] == receipt
    if failure == "malformed": assert report["resource_release"] == {}
    assert report["after_release"]["resource_observation"] == observation
    if capacity == "ready":
        assert report["after_release_error"] is None
        assert report["after_release"]["resource_admission"]["admitted_worker_ceiling"] == 1
    else:
        assert "RESOURCE_ADMISSION_ZERO" in report["after_release_error"]
        assert report["after_release"]["resource_admission"] is None
