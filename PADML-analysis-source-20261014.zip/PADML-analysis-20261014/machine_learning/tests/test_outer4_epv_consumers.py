"""Synthetic direct-consumer counterexamples; run on the engineering host only.

No patient data, model fits, native model replay, MICE, paths or RNG. Numerical
selector tests still belong off the local Mac under the project protocol.
"""
from copy import deepcopy
from pathlib import Path
import os
import tempfile
import unittest
from unittest.mock import patch

from padml import f2_kernel as kernel, f4, f5, f5_sensitivity as sensitivity
from padml import nested_loco as nested, runtime
from padml.bundle import ContractError, canonical_json_bytes, sha256_bytes
from padml.f2_kernel import load_science_authority


def _binding():
    return {"science_decision_sha256": "7dd06b0438c0b3a9275296f44401d1607421665427b0c2a602f51699e19f2ee4",
            "exception": nested._outer4_common_set_epv_exception_contract()}


def _numeric(*, binding=None, failed_mi=False, empty=False, nonfinite=False):
    contract = load_science_authority()["science"]["f2_model_development"]["selector_contract"]
    ratios = [1.0, 0.5]
    losses = [[[0.05, 0.1] for _ in range(3)] for _ in range(20)]
    if nonfinite:
        losses[0][0][0] = float("nan")
    active = [[23, 20] for _ in range(20)]
    if failed_mi:
        active[0] = [23, 23]
    decisions, indices = kernel._elastic_imputation_decisions(ratios, losses, active, [339] * 20,
        contract, no_aar_redevelopment=True)
    parents = {f"P{index:02d}": 1 for index in range(25)}
    coefficients = [{parent: [0.0 if empty or (index - imp) % 25 < 5 else 1.0]
        for index, parent in enumerate(parents)} for imp in range(20)]
    result = kernel._elastic_alpha_numeric_summary(0.5, ratios, decisions, indices, [339] * 20,
        parents, [2.0] * 20, [{} for _ in range(20)], coefficients, contract,
        no_aar_redevelopment=True,
        **({"common_set_epv_binding": binding} if binding is not None else {}))
    return result


def _final_task():
    policy = load_science_authority()["science"]["modeling_seed_policy"]["model"]
    seed = policy["base"] + 4 * policy["outer_multiplier"] + 1
    return {"family": "RSF", "imputation": 1, "selected_parents": ["synthetic_parent"],
        "a12_coordinates": {"outer_fold": 4, "branch": nested.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT, "imputation": 1},
        "registered_model_seed": seed, "model_seed": seed, "common_set_design_df": 25,
        "training_event_count": 339, "nested_aar_final_source": {
            "kind": "PADML_NESTED_AAR_FINAL_SOURCE_V1", "program_id": nested.PROGRAM_ID,
            "science_decision_sha256": "37c96bdd67c8e08a8ae4f1e29bf43023b8d8fb2375bc057079d1ca8581ef4648",
            "primary_development_lock_sha256": _binding()["exception"]["selector_source"]["primary_development_lock_sha256"],
            "training_context_sha256": "a" * 64, "inputs_identity_sha256": "b" * 64,
            "development_input_sha256": "c" * 64, "parameter_source_sha256": "d" * 64,
            "common_set_epv_binding": _binding()}}


class Outer4ConsumerTests(unittest.TestCase):
    def test_completed_fine_source_is_proved_without_relabeling(self):
        path = Path(os.environ["PADML_PRIMARY_RSF_COMPLETED_EXECUTOR_SOURCE"])
        current = f4._f45_source_member_sha256()
        members = f4._retained_full0_source_members(path, aar_no_aar_selector=True)
        self.assertEqual(sha256_bytes(canonical_json_bytes(members)),
            "07addcbb504f98caed9be64f2f598454bf6eb1df43bd6494e4d143151eb6e9bc")
        for member in ("padml/kernels/f2_model_development.R", "padml/science/variable.csv"):
            with patch.object(f4, "_f45_source_member_sha256", return_value={**current, member: "0" * 64}):
                with self.assertRaises(ContractError):
                    f4._retained_full0_source_members(path, aar_no_aar_selector=True)
        self.assertEqual(current, f4._f45_source_member_sha256())

    def test_public_fine_executor_argument_keeps_coarse_separate(self):
        import sys
        coarse = Path(os.environ["PADML_OUTER4_TEST_SELECTOR"])
        fine = Path(os.environ["PADML_PRIMARY_RSF_COMPLETED_EXECUTOR_SOURCE"])
        argv = ["padml-f5", "a12-outer", "/UNFITTED-input.zip", "/UNFITTED-selector",
            "--input-bundle", "/UNFITTED-projected.zip",
            "--selector-only", "--phase", "fine", "--phase-batches", "/UNFITTED-fine-batch",
            "--retained-selector-source-bundle", str(coarse),
            "--retained-selector-executor-source-bundle", str(fine)]
        with patch.object(sys, "argv", argv), \
             patch.object(sensitivity, "execute_a12_outer_bundle", return_value={"UNFITTED": True}) as owner:
            f5.main()
        self.assertEqual(owner.call_count, 1)
        self.assertEqual(owner.call_args.kwargs["retained_selector_source_bundle"], coarse)
        self.assertEqual(owner.call_args.kwargs["retained_selector_executor_source_bundle"], fine)
        self.assertEqual(owner.call_args.kwargs["phase_name"], "fine")

    def test_public_complete_q_executor_argument_is_forwarded_separately(self):
        import sys
        executor = Path("/UNOPENED-5c-source.zip")
        argv = ["padml-f5", "a12-outer", "/UNFITTED-input.zip", "/UNFITTED-q",
            "--input-bundle", "/UNFITTED-projected.zip", "--search-only",
            "--search-branch", nested.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT,
            "--selector-root", "/UNFITTED-selector", "--q-batches", "/UNFITTED-batch",
            "--retained-primary-source-bundle", "/UNFITTED-primary.zip",
            "--retained-selector-source-bundle", "/UNFITTED-coarse.zip",
            "--retained-selector-executor-source-bundle", "/UNFITTED-fine.zip",
            "--retained-a12-q-executor-source-bundle", str(executor)]
        with patch.object(sys, "argv", argv), \
             patch.object(sensitivity, "execute_a12_outer_bundle", return_value={"UNFITTED": True}) as owner:
            f5.main()
        self.assertEqual(owner.call_count, 1)
        self.assertEqual(owner.call_args.kwargs["retained_a12_q_executor_source_bundle"], executor)
        self.assertEqual(owner.call_args.kwargs["q_batches"], [Path("/UNFITTED-batch")])

    def test_old_outer4_q_executor_is_proved_only_for_saved_numeric_spec(self):
        from padml import f4_compact
        old_identity = "5c30305f8279acc7407bffc1b9d2d09cb1d100f819f69d4e7486c131c8bee5df"
        retained = {"UNFITTED_SOURCE_MEMBER": "a" * 64}
        current = sha256_bytes(canonical_json_bytes(f4._f45_source_member_sha256()))
        source = {"family": "RSF", "outer_fold": 4,
            "branch": nested.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT,
            "source": {"kind": "PADML_F5_A12_PROJECTED_OUTER_INPUTS_V1",
                       "synthetic_unfitted": True,
                       "primary_source": {"primary_development_lock": {}}},
            "common_set_epv_binding": _binding()}
        producer = {"task_id": "S1_T001_P01_M01", "family": "RSF", "seed": 304101}
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp).resolve()
            native = root / "native"
            native.mkdir()
            base = {"schema_version": "1.0.0", "execution_scope": "F5_A12_SEARCH", "fold": 4,
                "family": "RSF", "seed": 304000, "outcome": "All_Cause_Death",
                "time": "Death_Followup_months", "horizons": list(range(37)), "heldout_center": 4,
                "predictors": {}, "fpm": None,
                "selector_from_dependency": {"selected_parents": ["Age"], "outer_recipe_sha256": "RAW"},
                "a12_source": source, "registered_inputs_identity_sha256": "c" * 64,
                "retained_a12_primary_context_source_bundle": "/UNOPENED-primary.zip",
                "native_search_root": str(native), "native_search_replay": True,
                "native_search_numbers": True, "producer_tasks": [producer],
                "registered_partitions": {"partitions": []}}
            current_spec = {**base, "a12_executor_source_identity": current,
                "retained_a12_q_executor_source_bundle": "/UNOPENED-5c-source.zip"}
            batch = native / ("batch-" + sha256_bytes(canonical_json_bytes([producer["task_id"]]))[:24])
            batch.mkdir()
            saved = {**base, "a12_executor_source_identity": old_identity,
                "retained_a12_primary_context_source_bundle": "/UNOPENED-old-primary.zip",
                "native_search_root": "/UNOPENED-old-native", "native_search_replay": False,
                "output_path": "/UNOPENED-old-output.json"}
            (batch / "spec.json").write_bytes(canonical_json_bytes(saved))
            (batch / "output.json").write_bytes(canonical_json_bytes({"UNFITTED": True}))
            spec_path, output_path = root / "spec.json", root / "output.json"
            spec_path.write_bytes(canonical_json_bytes({**current_spec, "output_path": str(output_path)}))
            real_sha = f4.sha256_bytes
            retained_raw = canonical_json_bytes(retained)
            def exact_hash(raw):
                return old_identity if raw == retained_raw else real_sha(raw)
            with patch.object(sensitivity, "_validate_a12_search_source"), \
                 patch.object(f4, "_retained_full0_source_members", return_value=retained) as proof, \
                 patch.object(f4, "sha256_bytes", side_effect=exact_hash), \
                 patch.object(f4_compact, "_full_pipeline_q_object_numbers", return_value=None), \
                 patch.object(f4.subprocess, "run", side_effect=AssertionError("NO_FIT_OR_REPLAY")):
                self.assertEqual(f4._run_full_pipeline_r_search_batch(
                    spec_path, output_path, root, {}), {"UNFITTED": True})
            proof.assert_called_once_with(Path("/UNOPENED-5c-source.zip"), aar_q_executor=True)
            # The failed real launcher omitted this already-supported flag.
            # No retained executor may be inferred from the primary/coarse/
            # fine proofs or silently relabelled as the current executable.
            missing = {**current_spec, "output_path": str(output_path)}
            del missing["retained_a12_q_executor_source_bundle"]
            spec_path.write_bytes(canonical_json_bytes(missing))
            with patch.object(sensitivity, "_validate_a12_search_source"), \
                 patch.object(f4.subprocess, "run", side_effect=AssertionError("NO_FIT_OR_REPLAY")), \
                 self.assertRaisesRegex(ContractError, "F5_RETAINED_AAR_Q_EXECUTOR_DRIFT"):
                f4._run_full_pipeline_r_search_batch(spec_path, output_path, root, {})
            changed = {**current_spec, "fold": 5, "output_path": str(output_path)}
            spec_path.write_bytes(canonical_json_bytes(changed))
            with patch.object(sensitivity, "_validate_a12_search_source"), \
                 self.assertRaisesRegex(ContractError, "F5_RETAINED_AAR_Q_EXECUTOR_DRIFT"):
                f4._run_full_pipeline_r_search_batch(spec_path, output_path, root, {})

    def test_fine_executor_cannot_authorize_fits_or_another_selector_mode(self):
        sources = {"retained_primary_source_bundle": Path("/UNOPENED-primary.zip"),
            "retained_selector_source_bundle": Path("/UNOPENED-coarse.zip"),
            "retained_selector_executor_source_bundle": Path("/UNOPENED-fine.zip")}
        for mode in ({"selector_only": True, "prepare_only": True},
                     {"selector_only": True, "phase_name": "fine", "task_ids": ["R1_K1_M01"]},
                     {"selector_only": True, "phase_name": "coarse"},
                     {"search_only": True, "search_branch": nested.A12_DIRECT_AAR}):
            with self.subTest(mode=mode), self.assertRaisesRegex(ContractError, "SOURCE_SCOPE_INVALID"):
                sensitivity.execute_a12_outer_bundle(Path("/UNOPENED-input.zip"), Path("/UNOPENED-output"),
                    **sources, **mode)

    def test_exact_old_producers_stay_distinct_from_executor(self):
        current = f4._f45_source_member_sha256()
        for name, scope, identity in [
            ("PADML_OUTER4_TEST_PRIMARY", "aar_primary_context", "1513ecba963857099c6b99413b8e976393c551a3ec30ed90da1cb14178338bd7"),
            ("PADML_OUTER4_TEST_SELECTOR", "aar_no_aar_selector", "1ae061a1a6b270cffbaddcc9687e314685fa16231558859c8ffeeb98babf94b0"),
        ]:
            producer = f4._retained_full0_source_members(Path(os.environ[name]), **{scope: True})
            self.assertEqual(sha256_bytes(canonical_json_bytes(producer)), identity)
            self.assertNotEqual(current, producer)
            self.assertEqual(current, f4._f45_source_member_sha256())

    def test_two_source_leaves_do_not_supply_an_old_q_producer(self):
        self._check_source_leaves(with_fine=False)

    def test_completed_fine_source_survives_original_q_transport_and_reader(self):
        self._check_source_leaves(with_fine=True)

    def test_completed_fine_source_allows_original_60_q_atoms(self):
        self._check_source_leaves(with_fine=True, execute=True)

    def _check_source_leaves(self, *, with_fine, execute=False):
        policy = {"configured_worker_ceiling": runtime.CPU_MINUS_8, "memory_bytes_per_worker": 2 * 1024**3,
            "scratch_bytes_per_worker": 1, "memory_reserve_bytes": 0, "scratch_reserve_bytes": 0,
            "transfer_archive_worker_ceiling": 1}
        projected = {"synthetic_unfitted": True, "resource_policy": policy}
        source = {"family": "RSF", "outer_fold": 4, "branch": nested.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT,
                  "source": projected, "common_set_epv_binding": _binding()}
        def exact_synthetic_binding(value, *, projected_source=None, **kwargs):
            self.assertEqual(value, _binding())
            self.assertEqual(projected_source, projected)
            return value
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp).resolve()
            (root / "input.json").write_bytes(canonical_json_bytes({"kind": "PADML_F5_A12_Q_INPUT_V1",
                "spec": {"family": "RSF", "fold": 4, "execution_scope": "F5_A12_SEARCH", "a12_source": source}}))
            sources = {"retained_primary_source_bundle": Path(os.environ["PADML_OUTER4_TEST_PRIMARY"]),
                       "retained_selector_source_bundle": Path(os.environ["PADML_OUTER4_TEST_SELECTOR"])}
            if with_fine:
                sources["retained_selector_executor_source_bundle"] = Path(
                    os.environ["PADML_PRIMARY_RSF_COMPLETED_EXECUTOR_SOURCE"])
            # Only the absent clinical context is synthetic. Real code ZIP
            # pins/default-path proofs and the original control still execute.
            with patch.object(nested, "_validate_outer4_common_set_epv_binding", side_effect=exact_synthetic_binding), \
                 patch.object(sensitivity, "_validate_a12_search_source") as validate_source, \
                 patch.object(runtime, "resource_admission", return_value={}), \
                 patch.object(runtime, "observe_execution_resources", return_value={}):
                ids = f5._a12_q_stop_phase("S1", refit=True, family="RSF")[1] if execute else None
                control = f5._q_search_batch_control(root, policy, {"prepare_only": not execute, "task_ids": ids,
                    "batch_root": root / "batch" if execute else None, "q_batches": [],
                    "retained_bytes_per_task": 64 * 1024**2 if execute else None}, **sources)
                self.assertEqual(set(control["gbm_retained_sources"]), {
                    "execution-evidence/retained-sources/primary1513.zip",
                    "execution-evidence/retained-sources/selector1ae.zip",
                    *({"execution-evidence/retained-sources/selector-executor.zip"} if with_fine else set())})
                self.assertFalse({"retained_primary_source_identity", "retained_gbm_q_sources",
                                  "retained_q_producer_source_identity"}.intersection(control))
                self.assertEqual(control["confirmed_model_fits"], 0)
                validate_source.assert_called_once()
                if execute:
                    self.assertEqual(control["task_ids"], ids)
                    self.assertEqual(len(ids), 60)
                    self.assertFalse(control["prepare_only"])
                    return  # Control admission is not a scientific execution.
                if with_fine:
                    # Empty UNFITTED budget exercises only the original source
                    # transport; it is not a complete scientific Q result.
                    f5._q_search_batch_completion(root, control,
                        {"total_search_fit_count": 0, "response_free_stopping_fit_count": 0})
                    copied, refs = f5._q_gbm_source_evidence(root, policy)
                    self.assertEqual(refs, control["gbm_retained_sources"])
                    self.assertEqual(set(copied), set(sources))
                    self.assertTrue(all(copied[key].read_bytes() == path.read_bytes() for key, path in sources.items()))
                    from padml.f4_compact import _full_pipeline_q_numerical_members
                    native = root / "native/UNFITTED"
                    native.mkdir(parents=True)
                    (native / "model.rds").write_bytes(b"UNFITTED object-reference transport, not a model")
                    (root / "result.json").write_bytes(canonical_json_bytes({"UNFITTED": True}))
                    _, published = _full_pipeline_q_numerical_members(root, publish=True)
                    _, reopened = _full_pipeline_q_numerical_members(root)
                    self.assertEqual(published, reopened)
                    self.assertTrue(all(reopened[name] == pin for name, pin in refs.items()))
                    leaf = copied["retained_selector_executor_source_bundle"]
                    original = leaf.read_bytes()
                    leaf.write_bytes(original + b"UNTRUSTED")
                    with self.assertRaises(ContractError):
                        f5._q_gbm_source_evidence(root, policy)
                    leaf.write_bytes(original)
            # With the real binding reader, this synthetic projected source is
            # rejected; filenames and a copied authorization never admit it.
            with patch.object(runtime, "resource_admission", return_value={}), \
                 patch.object(runtime, "observe_execution_resources", return_value={}):
                with self.assertRaisesRegex(ContractError, "NESTED_OUTER4_COMMON_SETA_EPV_SOURCE_INVALID"):
                    f5._q_gbm_source_evidence(root, policy, sources=sources)

    def test_only_common_eligibility_changes(self):
        original, approved = _numeric(), _numeric(binding=_binding())
        self.assertEqual(original["status"], "EPV_INFEASIBLE")
        self.assertEqual(approved["status"], "FEASIBLE")
        self.assertEqual(approved["reason_code"], "USER_CONFIRMED_COMMON_SETA_EPV_EXCEPTION")
        self.assertEqual(approved["common_set_epv"], 339 / 25)
        self.assertTrue(approved["common_set_epv_exception_applied"])
        self.assertEqual(approved["original_common_set_epv_minimum"], 15)
        self.assertEqual(approved["selected_ratio_by_imputation"], [0.5] * 20)
        self.assertTrue(all(row["feasible_ratio_count"] == 1 for row in approved["imputation_decisions"]))
        extra = {"common_set_epv_binding", "common_set_epv_exception_applied", "original_common_set_epv_minimum"}
        self.assertEqual({k: v for k, v in original.items() if k not in {"status", "reason_code"}},
                         {k: v for k, v in approved.items() if k not in extra | {"status", "reason_code"}})

    def test_infeasible_imputation_still_ineligible(self):
        result = _numeric(binding=_binding(), failed_mi=True)
        self.assertEqual(result["status"], "EPV_INFEASIBLE")
        self.assertEqual(result["reason_code"], "IMPUTATION_HAS_NO_EPV_FEASIBLE_RATIO")
        with self.assertRaisesRegex(ContractError, "F2_SELECTOR_EPV_UNRESOLVED"):
            kernel._choose_elastic_summary([result])

    def test_empty_set_and_nonfinite_still_fail(self):
        for flag, code in [("empty", "NESTED_NO_AAR_SELECTOR_EMPTY_SETA"),
                           ("nonfinite", "F2_SELECTOR_LOSS_AGGREGATION_NONFINITE")]:
            with self.subTest(flag=flag), self.assertRaisesRegex(ContractError, code):
                _numeric(binding=_binding(), **{flag: True})

    def test_mutated_binding_never_authorizes(self):
        for field, value in [("outer_fold", 6), ("selection_horizon_months", 12), ("per_imputation_epv_minimum", 10),
                             ("family", "GBM_COX"), ("estimand", nested.A12_DIRECT_AAR)]:
            changed = _binding()
            changed["exception"][field] = value
            with self.subTest(field=field), self.assertRaisesRegex(ContractError, "EPV_BINDING_INVALID"):
                _numeric(binding=changed)

    def test_completed_coarse_execution_rejected_before_files_or_native_calls(self):
        binding = _binding()
        with self.assertRaisesRegex(ContractError, "NESTED_OUTER4_COMPLETED_COARSE_REEXECUTION_FORBIDDEN"):
            f4._full_pipeline_selector_search({"source": binding["exception"]["selector_source"]}, [],
                Path("/unopened-synthetic-selector"), rscript="unused", replay=False, workers=1,
                phase_name="coarse", task_ids=["R1_K1_M01"],
                retained_aar_source_bundle=Path("/unopened-original-source.zip"), common_set_epv_binding=binding)

    def test_wrong_selector_context_rejected_before_files(self):
        source = deepcopy(_binding()["exception"]["selector_source"])
        source["context"] = 6
        with self.assertRaisesRegex(ContractError, "NESTED_OUTER4_COMMON_SETA_EPV_SOURCE_INVALID"):
            f4._full_pipeline_selector_search({"source": source}, [], Path("/unopened-synthetic-selector"),
                rscript="unused", replay=False, workers=1, phase_name="fine", task_ids=["R1_K1_M01"],
                retained_aar_source_bundle=Path("/unopened-original-source.zip"), common_set_epv_binding=_binding())

    def test_top_level_binding_cannot_replace_missing_development_binding(self):
        branch = nested.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT
        prepared = {"source": {"kind": "PADML_F5_A12_PROJECTED_OUTER_INPUTS_V1"},
                    "branch_development": {branch: {}}, "common_set_epv_binding": _binding()}
        with self.assertRaisesRegex(ContractError, "NESTED_OUTER4_COMMON_SETA_EPV_SOURCE_INVALID"):
            sensitivity._a12_branch_search_inputs(prepared, branch)

    def test_final_cannot_drop_binding_or_change_primary_source(self):
        task = _final_task()
        f5._validate_a12_model_task("RSF", task)
        missing = deepcopy(task)
        del missing["nested_aar_final_source"]["common_set_epv_binding"]
        with self.assertRaisesRegex(ContractError, "F5_A12_OUTER_SETA_EPV_INVALID"):
            f5._validate_a12_model_task("RSF", missing)
        for field in ("science_decision_sha256", "primary_development_lock_sha256"):
            changed = deepcopy(task)
            changed["nested_aar_final_source"][field] = "0" * 64
            with self.subTest(field=field), self.assertRaisesRegex(ContractError, "EPV_SOURCE_INVALID"):
                f5._validate_a12_model_task("RSF", changed)

    def test_final_binding_cannot_move_to_other_outer_branch_or_family(self):
        for field, value in [("outer_fold", 6), ("branch", nested.A12_DIRECT_AAR), ("family", "GBM_COX")]:
            task = _final_task()
            if field == "family":
                task["family"] = value
            else:
                task["a12_coordinates"][field] = value
            policy = load_science_authority()["science"]["modeling_seed_policy"]["model"]
            task["model_seed"] = task["registered_model_seed"] = (
                policy["base"] + task["a12_coordinates"]["outer_fold"] * policy["outer_multiplier"] + 1)
            with self.subTest(field=field), self.assertRaisesRegex(ContractError, "EPV_SOURCE_INVALID"):
                f5._validate_a12_model_task(task["family"], task)
