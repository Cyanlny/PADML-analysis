"""Zero-fit original-entry counterexamples; not full historical acceptance.

The complete 1513 -> current owner/archive/numerical-reader test must use
source-bound old 24-month evidence, not relabel a current-source fixture.
"""
from pathlib import Path

import pytest

from padml import f4, f5, runtime
from padml.bundle import ContractError, canonical_json_bytes, write_deterministic_zip


@pytest.mark.parametrize("defect", ["missing-target-root", "missing-result-root", "summary-without-target"])
def test_fixed12_original_reader_rejects_incomplete_pair_before_io(tmp_path, monkeypatch, defect):
    options = dict(outer_fixed12_target_request={}, outer_fixed12_target_root=tmp_path,
                   outer_fixed12_result_root=tmp_path, rescore_target=tmp_path / "new.zip")
    if defect == "missing-target-root":
        options.pop("outer_fixed12_target_root")
    elif defect == "missing-result-root":
        options.pop("outer_fixed12_result_root")
    else:
        options = dict(outer_fixed12_rescored_archive=tmp_path / "old-summary.zip")
    monkeypatch.setattr(f4.zipfile, "ZipFile", lambda *a, **k: pytest.fail("must reject before source IO"))
    with pytest.raises(ContractError, match="F4_O_FIT_FIXED12_RESCORE_SCOPE_INVALID"):
        f4._load_o_fit_execution_archive(tmp_path / "unread.zip", **options)


@pytest.mark.parametrize("defect", ["zero-without-summary", "bool-limit", "extra-field", "partial-stage"])
def test_fixed12_training_context_rejects_before_scoring(tmp_path, monkeypatch, defect):
    source = tmp_path / "input.zip"
    write_deterministic_zip(source, {"o-fit-input.json": canonical_json_bytes({
        "training_context": {"outer_fold": 1}, "resource_policy": {},
        "retained_bytes_per_component": 10**6, "expanded_bytes_per_component": 10**6,
        "shared_storage_bytes": 10**8})})
    context = dict(retained_score_numbers=tmp_path / "old.zip", input_bundle=tmp_path / "old-input.zip",
        compiled_input_record={}, retained_primary_source_bundle=tmp_path / "source.zip", rescore_call_limit=1)
    options = {}
    if defect == "zero-without-summary":
        context["rescore_call_limit"] = 0
    elif defect == "bool-limit":
        context["rescore_call_limit"] = True
    elif defect == "extra-field":
        context["ignore_source"] = True
    else:
        options["prepare_only"] = True
    monkeypatch.setattr(runtime, "effective_cpu_count", lambda: 64)
    monkeypatch.setattr(f5, "_full_data_locked_score_program", lambda *a, **k: pytest.fail("no scoring before full context"))
    with pytest.raises(ContractError, match="F4_O_FIT_FIXED12_RESCORE_SCOPE_INVALID"):
        f4._execute_o_fit_training_bundle(source, tmp_path / "new.zip", outer_fold=1, workers=56,
            retained_native=None, f2_run_root=tmp_path, outer_fixed12_context=context, **options)
    assert not (tmp_path / "new.zip").exists()


def test_fixed12_flat_reader_rejects_noncanonical_root_before_metadata(tmp_path, monkeypatch):
    wrong = tmp_path / "arbitrary-carrier"
    wrong.mkdir()
    monkeypatch.setattr(Path, "read_bytes", lambda *a, **k: pytest.fail("no metadata before original root binding"))
    with pytest.raises(ContractError, match="F4_O_FIT_FIXED12_RESCORE_SCOPE_INVALID"):
        f4._load_o_fit_execution_archive(wrong, f2_run_root=tmp_path,
            outer_fixed12_target_request={}, outer_fixed12_target_root=tmp_path,
            outer_fixed12_result_root=tmp_path)


@pytest.mark.parametrize("nested_root", ["result", "request"])
def test_fixed12_reader_preserves_existing_expansion_before_source_io(tmp_path, monkeypatch, nested_root):
    expansion = tmp_path / "expansion"
    expansion.mkdir()
    contained = expansion / "retained"
    contained.mkdir()
    monkeypatch.setattr(f4.zipfile, "ZipFile", lambda *a, **k: pytest.fail("must reject before source IO"))
    with pytest.raises(ContractError, match="F4_O_FIT_FIXED12_RESCORE_SCOPE_INVALID"):
        f4._load_o_fit_execution_archive(tmp_path / "old.zip", replay_evidence=expansion,
            rescore_target=tmp_path / "unused.zip", outer_fixed12_target_request={},
            outer_fixed12_target_root=contained if nested_root == "request" else tmp_path,
            outer_fixed12_result_root=contained if nested_root == "result" else tmp_path)
    assert contained.is_dir()


@pytest.mark.parametrize("defect", [None, "null-optional", "bad-path", "bool-limit", "unknown"])
def test_fixed12_original_cli_preserves_four_sources_and_limit(tmp_path, monkeypatch, defect):
    import sys
    monkeypatch.chdir(tmp_path)
    fixed = dict(retained_score_numbers="old.zip", input_bundle="old-input.zip",
        compiled_input_record={"identity_sha256": "a" * 64},
        retained_primary_source_bundle="1513.zip", rescore_call_limit=0, rescored_archive="summary.zip")
    if defect == "null-optional":
        fixed.update(rescored_archive=None, rescore_call_limit=1)
    elif defect == "bad-path":
        fixed["input_bundle"] = 123
    elif defect == "bool-limit":
        fixed["rescore_call_limit"] = True
    elif defect == "unknown":
        fixed["ignore_source"] = True
    context = dict(search_roots={}, search_source_bundles={}, pending_searches={}, outer_fixed12_context=fixed)
    file = tmp_path / "context.json"
    file.write_bytes(canonical_json_bytes(context))
    seen = []
    monkeypatch.setattr(f4, "execute_o_fit_bundle", lambda *a, **kw: seen.append(kw) or {})
    monkeypatch.setattr(sys, "argv", ["padml-f4", "o-fit-execute", str(tmp_path), str(tmp_path / "out.zip"),
        "--outer-fold", "1", "--primary-development", str(file)])
    if defect in {"bad-path", "bool-limit", "unknown"}:
        with pytest.raises(ContractError):
            f4.main()
        assert seen == []
    else:
        f4.main()
        expected = {**fixed, **{key: tmp_path / fixed[key] for key in (
            "retained_score_numbers", "input_bundle", "retained_primary_source_bundle")},
            "rescored_archive": None if fixed["rescored_archive"] is None else tmp_path / fixed["rescored_archive"]}
        assert len(seen) == 1 and seen[0]["primary_development"]["outer_fixed12_context"] == expected
