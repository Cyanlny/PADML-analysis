"""Full0 final seed and native-lineage checks; no fits, MICE or RNG draws."""
import copy
import shutil
import subprocess
from pathlib import Path

import numpy as np
import pytest

from padml import f4, f5, nested_loco as nested
from padml.bundle import ContractError, canonical_json_bytes, sha256_bytes, strict_json_bytes


def _source():
    return {"kind": "PADML_NESTED_FULL_FINAL_SOURCE_V1", "program_id": nested.PROGRAM_ID,
            **{key: "a" * 64 for key in (
                "training_context_sha256", "score_development_sha256", "full_score_result_sha256",
                "family_decision_sha256", "selector_development_sha256", "selector_recipe_set_sha256",
                "selected_parents_sha256", "selected_spec_sha256", "recipe_sha256", "mice_member_sha256",
                "training_ids_sha256", "training_response_sha256")}}


def test_140_full_final_python_and_r_seeds_keep_original_300000_and_exact_native_binding():
    rscript = shutil.which("Rscript")
    if rscript is None:
        pytest.skip("pure R seed/binding check requires Rscript, never fits")
    jobs = [{"family": family, "f4_coordinates": {"purpose": "NESTED_FULL_FINAL", "outer_fold": 0,
                "repeat": 0, "inner_fold": 0, "imputation": imputation}, "imputation": imputation,
             "model_seed": 300000 if family in {"RSF", "GBM_COX", "XGBOOST_COX", "COXTIME_SET_A"} else None,
             "nested_full_final_source": _source(), "development_lock_sha256": "b" * 64,
             "selected_parents": ["AST_ALT"], "parameters": {"UNFITTED": True}, "recipe": {"UNFITTED": True}}
            for family in nested._families() for imputation in range(1, 21)]
    assert [f4._f4_model_seed(job["family"], job["f4_coordinates"]) for job in jobs] == [300000] * 140
    invalid = []
    for change in ({"outer_fold": 1}, {"repeat": 1}, {"inner_fold": 1}, {"imputation": True},
                   {"imputation": 0}, {"imputation": 21}, {"bootstrap_replicate": 1}):
        coordinates = {**jobs[0]["f4_coordinates"], **change}
        with pytest.raises(ContractError, match="F4_MODEL_COORDINATE_INVALID"):
            f4._f4_model_seed("COX_PH", coordinates)
        invalid.append(coordinates)
    completed = subprocess.run([rscript, "--vanilla", "-e", r'''
      suppressPackageStartupMessages(library(jsonlite))
      defs <- Filter(function(x) is.call(x) && identical(x[[1]],as.name("<-")) &&
        is.symbol(x[[2]]) && as.character(x[[2]]) %in% c("fail","need","scalar","f4_model_seed",
          "validate_nested_full_final_binding","native_training_binding"),
        as.list(parse(commandArgs(TRUE)[[1]])))
      stopifnot(length(defs)==6L)
      for (definition in defs) eval(definition)
      input <- fromJSON(file("stdin"),simplifyVector=FALSE)
      stopifnot(!exists(".Random.seed",envir=.GlobalEnv,inherits=FALSE))
      for (job in input$jobs) {
        stopifnot(f4_model_seed(job$family,job$f4_coordinates)==300000L)
        validate_nested_full_final_binding(job)
        bind <- function(value) native_training_binding(value, "UNFITTED", "36", matrix(1), 10, 1)
        expected <- bind(job)
        stopifnot(identical(expected$coordinates$development_lock_sha256,job$development_lock_sha256))
        changed <- job; changed$development_lock_sha256 <- strrep("c",64)
        stopifnot(!identical(expected,bind(changed)))
        changed <- job; changed$nested_full_final_source$full_score_result_sha256 <- strrep("c",64)
        stopifnot(!identical(expected,bind(changed)))
        for (key in c("development_lock_sha256","nested_full_final_source")) {
          changed <- job; changed[[key]] <- NULL
          stopifnot(inherits(tryCatch(validate_nested_full_final_binding(changed),error=function(e) e),"error"))
        }
        changed <- job; changed$model_seed <- 300001
        stopifnot(inherits(tryCatch(validate_nested_full_final_binding(changed),error=function(e) e),"error"))
        changed <- job; changed$nested_full_final_source$development_lock_sha256 <- strrep("b",64)
        stopifnot(inherits(tryCatch(validate_nested_full_final_binding(changed),error=function(e) e),"error"))
        changed <- job; changed$nested_full_score_source <- list(forbidden=TRUE)
        stopifnot(inherits(tryCatch(validate_nested_full_final_binding(changed),error=function(e) e),"error"))
      }
      for (coordinates in input$invalid) stopifnot(inherits(
        tryCatch(f4_model_seed("COX_PH",coordinates),error=function(e) e),"error"))
      for (outer in 1:6) {
        job <- input$jobs[[1]]; job$nested_full_final_source <- NULL
        job$f4_coordinates$purpose <- "NESTED_OUTER"; job$f4_coordinates$outer_fold <- outer
        expected <- bind(job)
        stopifnot(identical(expected$coordinates$development_lock_sha256,job$development_lock_sha256))
        changed <- job; changed$development_lock_sha256 <- strrep("c",64)
        stopifnot(!identical(expected,bind(changed)))
        for (lock in list(NULL,"bad",c(strrep("b",64),strrep("c",64)))) {
          changed <- job; changed$development_lock_sha256 <- lock
          stopifnot(inherits(tryCatch(bind(changed),error=function(e) e),"error"))
        }
      }
      stopifnot(!exists(".Random.seed",envir=.GlobalEnv,inherits=FALSE))
      cat(toJSON(list(checked=length(input$jobs),new_model_fits=0,new_mice_chains=0),auto_unbox=TRUE))
    ''', str(Path(f4.__file__).parent / "kernels/f5_final_refit.R")],
        input=canonical_json_bytes({"jobs": jobs, "invalid": invalid}), capture_output=True, timeout=60, check=True)
    assert strict_json_bytes(completed.stdout) == {"checked": 140, "new_model_fits": 0, "new_mice_chains": 0}


@pytest.mark.parametrize("purpose", ["NESTED_FULL_FINAL", "NESTED_OUTER"])
def test_full_final_python_native_objects_cannot_be_relabelled_with_another_lock_or_source(purpose):
    task = {"family": "XGBOOST_COX", "model_seed": 300000, "imputation": 1, "selected_parents": ["AST_ALT"],
            "parameters": {"UNFITTED": True}, "f4_coordinates": {"purpose": "NESTED_FULL_FINAL",
                "outer_fold": 0, "repeat": 0, "inner_fold": 0, "imputation": 1},
            "nested_full_final_source": _source(), "development_lock_sha256": "b" * 64}
    if purpose == "NESTED_OUTER":
        task["f4_coordinates"].update(purpose=purpose, outer_fold=1)
        task["model_seed"] = f4._f4_model_seed(task["family"], task["f4_coordinates"])
        task.pop("nested_full_final_source")
    rows = [{"Patient_ID": "UNFITTED", "Center": "36"}]
    def bind(value):
        return f5._native_python_training_binding("XGBOOST_COX", value, rows, {"UNFITTED": True},
            np.asarray([[1.0]]), ["AST_ALT"], np.asarray([10.0]), np.asarray([1]))
    expected = bind(task)
    model = b"UNFITTED"
    baseline = {"training_binding": expected, "model_object_sha256": sha256_bytes(model)}
    f5._validate_python_training_binding(expected, baseline, expected, model)
    for field in (("lock", "source", "imputation") if purpose == "NESTED_FULL_FINAL" else ("lock", "imputation")):
        changed = copy.deepcopy(task)
        if field == "lock":
            changed["development_lock_sha256"] = "c" * 64
        elif field == "source":
            changed["nested_full_final_source"]["full_score_result_sha256"] = "c" * 64
        else:
            changed["imputation"] = changed["f4_coordinates"]["imputation"] = 2
        assert bind(changed) != expected
        with pytest.raises(ContractError, match="F5_REPLAY_NATIVE_TRAINING_BINDING_MISMATCH"):
            f5._validate_python_training_binding(expected, baseline, bind(changed), model)
    for lock in (None, "bad", ["b" * 64, "c" * 64]):
        with pytest.raises(ContractError):
            bind({**task, "development_lock_sha256": lock})
