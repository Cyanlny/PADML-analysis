"""Bounded A12 Q native transport/AST checks; no scientific fitting."""
import json
import os
from pathlib import Path
import shutil
import struct
import subprocess
from types import SimpleNamespace

import pytest

from padml.bundle import ContractError, canonical_json_bytes, sha256_bytes
from padml import f2_kernel, f4
from test_nested_aar_mice import aar_source  # noqa: F401


def test_a12_r_native_batch_replays_without_losing_originals(tmp_path, monkeypatch):
    calls = []

    def unfitted_native(command, **kwargs):
        spec = json.loads(Path(command[-1]).read_bytes())
        assert spec["execution_scope"] == "F5_A12_SEARCH" and "full_pipeline_source" not in spec
        calls.append((spec["family"], spec["native_search_replay"]))
        kwargs["stdout"].write(b"UNFITTED native transport\n")
        kwargs["stderr"].write(b"")
        root = Path(spec["output_path"]).parent
        native_model = Path(spec["native_search_root"]) / spec["producer_tasks"][0]["task_id"]
        if spec["native_search_replay"]:
            assert (native_model / "model.rds").read_bytes() == b"UNFITTED_R_OBJECT"
        else:
            native_model.mkdir()
            (native_model / "model.rds").write_bytes(b"UNFITTED_R_OBJECT")
        value = {"fixture": "UNFITTED_NATIVE_TRANSPORT"}
        if spec["family"] == "GBM_COX":
            channel = {"schema_version": "1.0.0", "kind": "PADML_F2_OPERATION_LOCAL_RISK_MATRIX_CHANNEL"}
            for role, values in (("fit", [[1.0, 2.0]]), ("evaluation", [[3.0, 4.0]])):
                raw = struct.pack("<dd", *values[0])
                name = f"risk-001-gbm-{role}.bin"
                (root / name).write_bytes(raw)
                channel[role] = {"schema_version": "1.0.0", "kind": "PADML_F2_OPERATION_LOCAL_RISK_MATRIX",
                    "encoding": "IEEE754_FLOAT64", "byte_order": "LITTLE_ENDIAN", "row_order": "ROW_MAJOR",
                    "file_name": name, "rows": 1, "columns": 2, "size_bytes": len(raw), "sha256": sha256_bytes(raw)}
            value["risk_channel"] = channel
        Path(spec["output_path"]).write_bytes(canonical_json_bytes(value))
        return SimpleNamespace(returncode=0)

    monkeypatch.setattr(f4.subprocess, "run", unfitted_native)
    for family in ("RSF", "GBM_COX"):
        base = tmp_path / family
        base.mkdir()
        native = base / "native"
        native.mkdir()
        producer = {"task_id": "S1_T001_P01_M01", "family": family}
        if family == "GBM_COX":
            producer["producer_kind"] = "GBM_STOP_CURVE"
        spec = {"execution_scope": "F5_A12_SEARCH", "action": "MODEL_PREDICTION_BATCH",
            "family": family, "fold": 1, "native_search_root": str(native),
            "a12_source": {"family": family, "outer_fold": 1, "branch": "WITHOUT_AST_ALT_TOTAL",
                           "source": "UNFITTED", "inputs_identity_sha256": "a" * 64},
            "producer_tasks": [producer], "registered_partitions": {"partitions": [{
                "covariates": {"input_dir": "/UNFITTED/original", "data_identity": "b" * 64},
                "fit_response": {"path": "/UNFITTED/response", "sha256": "c" * 64}}]}}
        originals = None
        for replay in (False, True):
            work = base / ("replay" if replay else "fresh")
            work.mkdir()
            actual = {**spec, "native_search_replay": replay, "output_path": str(work / "output.json")}
            (work / "spec.json").write_bytes(canonical_json_bytes(actual))
            output = f4._run_full_pipeline_r_search_batch(work / "spec.json", work / "output.json", tmp_path, {})
            batch, = native.glob("batch-*")
            if originals is None:
                originals = {p.name: p.read_bytes() for p in batch.iterdir()}
            f2_kernel._validate_r_risk_scratch_members(work, [producer])
            if family == "GBM_COX":
                assert f2_kernel._consume_operation_local_risk_channel(
                    output["risk_channel"], work, expected_prefix="risk-001-gbm",
                    fit_rows=1, evaluation_rows=1, columns=2) == ([[1.0, 2.0]], [[3.0, 4.0]])
            assert {p.name: p.read_bytes() for p in batch.iterdir()} == originals
            assert (native / producer["task_id"] / "model.rds").read_bytes() == b"UNFITTED_R_OBJECT"
        actual["a12_source"] = {**actual["a12_source"], "inputs_identity_sha256": "d" * 64}
        (work / "spec.json").write_bytes(canonical_json_bytes(actual))
        with pytest.raises(ContractError, match="Q_R_SPEC_MISMATCH"):
            f4._run_full_pipeline_r_search_batch(work / "spec.json", work / "output.json", tmp_path, {})
    assert calls == [("RSF", False), ("RSF", True), ("GBM_COX", False), ("GBM_COX", True)]


@pytest.fixture
def interrupted_r_publication(tmp_path, monkeypatch):
    """Storage-only failure fixture; no R, model fit or clinical inputs."""
    atom = tmp_path / "atom"
    native = atom / "native"
    native.mkdir(parents=True)
    task = {"task_id": "S3B2_T001_P12_M17_STOP", "family": "GBM_COX", "producer_kind": "GBM_STOP_CURVE"}
    spec = {"execution_scope": "F5_A12_SEARCH", "action": "MODEL_PREDICTION_BATCH",
        "family": "GBM_COX", "fold": 6, "native_search_root": str(native),
        "a12_source": {"family": "GBM_COX", "outer_fold": 6, "branch": "WITHOUT_AST_ALT_TOTAL",
                       "source": "UNFITTED", "inputs_identity_sha256": "a" * 64},
        "producer_tasks": [task], "registered_partitions": {"partitions": [{
            "covariates": {"input_dir": "/UNFITTED/original", "data_identity": "b" * 64},
            "fit_response": {"path": "/UNFITTED/response", "sha256": "c" * 64}}]}}
    channel = {"schema_version": "1.0.0", "kind": "PADML_F2_OPERATION_LOCAL_RISK_MATRIX_CHANNEL"}
    matrices = {"risk-001-gbm-fit.bin": struct.pack("<dd", 1.0, 2.0),
                "risk-001-gbm-evaluation.bin": struct.pack("<dd", 3.0, 4.0)}
    for role in ("fit", "evaluation"):
        name = f"risk-001-gbm-{role}.bin"
        channel[role] = {"schema_version": "1.0.0", "kind": "PADML_F2_OPERATION_LOCAL_RISK_MATRIX",
            "encoding": "IEEE754_FLOAT64", "byte_order": "LITTLE_ENDIAN", "row_order": "ROW_MAJOR",
            "file_name": name, "rows": 1, "columns": 2, "size_bytes": 16, "sha256": sha256_bytes(matrices[name])}
    value = {"tasks": [{"risk_curve": {"risk_matrix_channel": channel}}]}
    calls = []

    def native_return(command, **kwargs):
        actual = json.loads(Path(command[-1]).read_bytes())
        calls.append(actual["native_search_replay"])
        model = native / task["task_id"] / "model.rds"
        if actual["native_search_replay"]:
            assert model.read_bytes() == b"UNFITTED_RETAINED_MODEL"
        else:
            model.parent.mkdir()
            model.write_bytes(b"UNFITTED_RETAINED_MODEL")
        work = Path(actual["output_path"]).parent
        for name, raw in matrices.items():
            (work / name).write_bytes(raw)
        (work / "output.json").write_bytes(canonical_json_bytes(value))
        return SimpleNamespace(returncode=0)

    monkeypatch.setattr(f4.subprocess, "run", native_return)

    def invoke(replay=False):
        work = atom / "work" / ("audit" if replay else "produce") / "f2-r-batch-test"
        work.mkdir(parents=True, exist_ok=True)
        if replay and (atom / "native-replay").exists():
            shutil.rmtree(atom / "native-replay")  # Original current-Q caller's disposable staging.
        actual = {**spec, "native_search_replay": replay, "output_path": str(work / "output.json")}
        if replay:
            actual["native_search_complete_missing_values"] = True
        (work / "spec.json").write_bytes(canonical_json_bytes(actual))
        return f4._run_full_pipeline_r_search_batch(work / "spec.json", work / "output.json", tmp_path, {})

    return SimpleNamespace(atom=atom, native=native, invoke=invoke, task=task, value=value,
                           matrices=matrices, calls=calls)


def test_a12_r_native_truncated_copy_recovers_exact_original(interrupted_r_publication):
    case = interrupted_r_publication
    case.invoke()
    batch, = case.native.glob("batch-*")
    name = "risk-001-gbm-fit.bin"
    original = case.matrices[name]
    (batch / name).write_bytes(original[:7])  # Deliberately not a float64 boundary.
    model = case.native / case.task["task_id"] / "model.rds"
    before_model = model.read_bytes()
    case.invoke(True)
    assert (batch / name).read_bytes() == original
    saved = case.atom / "interrupted-publication" / batch.name / name
    assert saved.read_bytes() == original[:7]
    inode = (batch / name).stat().st_ino
    for folder in (case.atom / "work/produce/f2-r-batch-test", case.atom / "work/audit/f2-r-batch-test"):
        f2_kernel._validate_r_risk_scratch_members(folder, [case.task])
        matrices = f2_kernel._consume_operation_local_risk_channel(
            case.value["tasks"][0]["risk_curve"]["risk_matrix_channel"], folder,
            expected_prefix="risk-001-gbm", fit_rows=1, evaluation_rows=1, columns=2)
        assert [m.column(0) for m in matrices] == [[1.0], [3.0]]
        assert [m.column(1) for m in matrices] == [[2.0], [4.0]]
        assert (folder / name).read_bytes() == original
    # A complete target is reusable even after original disposable risk copies are consumed.
    case.invoke(True)
    assert (batch / name).stat().st_ino == inode
    assert model.read_bytes() == before_model and saved.read_bytes() == original[:7]
    assert case.calls == [False, True, True]
    assert not any((case.atom / x).exists() for x in ("values.json", "audit.json", "receipt.json"))


@pytest.mark.parametrize("damage", ["same_length", "longer", "nonprefix", "produce", "descriptor",
    "original_json", "missing_produce", "symlink", "hardlink", "values.json", "audit.json", "receipt.json", "numbers.json"])
def test_a12_r_native_copy_recovery_rejects_conflicts(interrupted_r_publication, damage):
    case = interrupted_r_publication
    case.invoke()
    batch, = case.native.glob("batch-*")
    name = "risk-001-gbm-fit.bin"
    target, original = batch / name, case.matrices[name]
    target.write_bytes(original[:7])
    produce = case.atom / "work/produce/f2-r-batch-test"
    if damage == "same_length": target.write_bytes(b"x" * len(original))
    elif damage == "longer": target.write_bytes(original + b"x")
    elif damage == "nonprefix": target.write_bytes(b"x" * 7)
    elif damage == "produce": (produce / name).write_bytes(b"x" * len(original))
    elif damage == "missing_produce": (produce / name).unlink()
    elif damage == "original_json": (batch / "output.json").write_bytes(b"{}")
    elif damage == "descriptor":
        case.value["tasks"][0]["risk_curve"]["risk_matrix_channel"]["fit"]["sha256"] = "f" * 64
        for p in (batch / "output.json", produce / "output.json"):
            p.write_bytes(canonical_json_bytes(case.value))
    elif damage == "symlink":
        target.unlink()
        target.symlink_to(produce / name)
        (produce / name).write_bytes(original[:7])
    elif damage == "hardlink": os.link(target, case.atom / "alias.bin")
    else: (case.atom / damage).write_bytes(b"SEALED")
    before = target.read_bytes()
    with pytest.raises(ContractError, match="F45_Q_R_VALUES_DRIFT"):
        case.invoke(True)
    assert target.read_bytes() == before
    assert not (case.atom / "interrupted-publication").exists()


@pytest.mark.parametrize("recover", [False, True])
def test_a12_r_native_publish_enospc_never_leaves_partial_target(interrupted_r_publication, monkeypatch, recover):
    import errno
    import stat
    case = interrupted_r_publication
    if recover:
        case.invoke()
        batch, = case.native.glob("batch-*")
        (batch / "risk-001-gbm-fit.bin").write_bytes(case.matrices["risk-001-gbm-fit.bin"][:7])
    real_fsync = os.fsync

    def no_space(fd):
        info = os.fstat(fd)
        if stat.S_ISREG(info.st_mode) and info.st_size == 16:
            raise OSError(errno.ENOSPC, "injected publication ENOSPC")
        return real_fsync(fd)

    with monkeypatch.context() as scoped:
        scoped.setattr(f4.os, "fsync", no_space)
        with pytest.raises(OSError, match="ENOSPC"):
            case.invoke(recover)
    batch, = case.native.glob("batch-*")
    target = batch / "risk-001-gbm-fit.bin"
    assert target.read_bytes() == case.matrices[target.name][:7] if recover else not target.exists()
    assert not list(case.native.rglob(".*pending*")) and not list(case.atom.rglob(".native-publish-*"))
    case.invoke(True)
    assert target.read_bytes() == case.matrices[target.name]


def _q_numbers_python_unit(aar_source, tmp_path, family, scope):
    """Synthetic arrays, original source/coordinate validators, no trained models."""
    import copy
    import numpy as np
    from padml import f5, nested_loco as nested
    from test_nested_loco import _lock, _scores
    policy = aar_source[4]
    if scope == "AAR":
        primary = copy.deepcopy(aar_source[3])
        context = primary["primary_training_context"]
        primary["primary_development_lock"], _ = _lock(context, _scores(context, {
            key: .01 if key == family else .2 for key in nested._families()}))
        source = nested._sealed({"kind": "PADML_F5_A12_PROJECTED_OUTER_INPUTS_V1",
            "family": family, "outer_fold": 1, "primary_source": primary})
        binding = {"source": source, "family": family, "outer_fold": 1,
            "branch": nested.A12_TOTAL_AAR, "inputs_identity_sha256": "a" * 64,
            "development_input_sha256": "b" * 64}
        source_fields = {"a12_source": binding}
    else:
        source_fields = {"final_search_source": {
            "program_id": nested.PROGRAM_ID, "family": family, "virtual_outer": 0}}
    parameters = {"max_nrounds": 20, "early_stopping_rounds": 2, "stop_scope": "training_only",
        "post_selection_refit": "full_main_training_at_best_rounds",
        "locked_iteration_mode": "full_main_training_without_reselection"}
    candidate = {"candidate_id": "CT001", "time_transform": "LOG1P_STANDARDIZED", "coxtime_shrink": 0.0}
    chosen = {"trial_id": "X001", "parameters": parameters} if family == "XGBOOST_COX" else candidate
    spec = {"execution_scope": "F5_A12_SEARCH" if scope == "AAR" else "F5_FULL_DEVELOPMENT_SEARCH",
        "family": family, "fold": 1 if scope == "AAR" else 0, "backend": "CPU",
        "seed": 301000 if scope == "AAR" else 300000,
        "registered_inputs_identity_sha256": "c" * 64,
        "native_search_root": str(tmp_path / "q" / "native"), "native_search_replay": False,
        "candidate_trials": {"S1": [chosen], "S2": [chosen]},
        "selector_from_dependency": {"selected_parents": ["Age"]},
        "horizons": list(range(37)), "monthly_fit_horizons": list(range(1, 37)),
        "coxtime": {"shared_candidate_parameters": {"validation_repeat": 5, "n_control": 5,
            "validation_control_seed_offset": 70000,
            "validation_control_seed_rule": "TASK_SEED_PLUS_OFFSET_PLUS_ONE_BASED_REPEAT"}},
        **source_fields}
    fields = ["Patient_ID", "All_Cause_Death", "Death_Followup_months"]
    responses = {f"UNFITTED_{i}": dict(zip(fields, [f"UNFITTED_{i}", str(int(i != 1)), str(3 + i * 2)]))
                 for i in range(6)}
    fit_ids, evaluation_ids = list(responses)[:4], list(responses)[4:]
    part = {"partition_id": "UNFITTED_STOP", "kind": "STOP", "repeat": 1, "inner_fold": 1,
        "fit_ids": fit_ids, "evaluation_ids": evaluation_ids}
    part.update({name: f5._write_response_subset(fields, responses, ids, None)
                 for name, ids in (("fit_response", fit_ids), ("evaluation_response", evaluation_ids))})
    loaded = {"partition": part, "fit_ids": fit_ids, "evaluation_ids": evaluation_ids,
        "imputation_indices": [1], "columns": ["Age"],
        "fit_designs": [np.array([[40.], [50.], [60.], [70.]])],
        "evaluation_designs": [np.array([[45.], [65.]])],
        "fit_time": np.array([3., 5., 7., 9.]), "fit_event": np.array([1, 0, 1, 1])}
    task = {"task_id": "S1_T001_P01_M01_FUNCTION", "spec": spec,
        "registered": {"identity": spec["registered_inputs_identity_sha256"]},
        "partition_id": part["partition_id"], "imputation": 1, "seed": spec["seed"] + 10101,
        ("parameters" if family == "XGBOOST_COX" else "candidate"):
            (parameters if family == "XGBOOST_COX" else candidate),
        "handoff_path": str(tmp_path / "first-handoff" / "model")}
    return task, loaded, policy


def _unfitted_q_function(task, loaded, path):
    """Record synthetic function bytes with the original array-binding formula."""
    import io
    import numpy as np
    import torch
    from pycox import models
    from padml.bundle import sha256_file
    family = task["spec"]["family"]
    fit, evaluation = loaded["fit_designs"][0], loaded["evaluation_designs"][0]
    payload = {"schema_version": "1.0.0", "fit_ids": loaded["fit_ids"], "evaluation_ids": loaded["evaluation_ids"],
        "maximum": 20 if family == "XGBOOST_COX" else 300, "seed": task["seed"]}
    if family == "XGBOOST_COX":
        raw = b"UNFITTED_XGB_FUNCTION"
        fit_bytes = np.ascontiguousarray(fit, dtype="float64").tobytes()
        evaluation_bytes = np.ascontiguousarray(evaluation, dtype="float64").tobytes()
        payload.update(kind="PADML_F2_XGBOOST_PREDICTION_FUNCTION", booster_sha256=sha256_bytes(raw),
            parameter_sha256=f2_kernel._sha(task["parameters"]),
            cox_objective={"implementation": "GROUPED_BRESLOW_FLOAT64_TIME_V1", "gradient_evaluations": 20,
                           "training_rows": 4, "event_time_groups": 3},
            design_identity=f2_kernel._sha({"fit_shape": list(fit.shape), "fit_sha256": sha256_bytes(fit_bytes),
                "evaluation_shape": list(evaluation.shape), "evaluation_sha256": sha256_bytes(evaluation_bytes)}),
            fit_input_identity=f2_kernel._sha({"fit_ids_sha256": f2_kernel._sha(loaded["fit_ids"]),
                "fit_design_shape": list(fit.shape), "fit_design_sha256": sha256_bytes(fit_bytes),
                "fit_time_sha256": f2_kernel._sha(loaded["fit_time"].tolist()),
                "fit_event_sha256": f2_kernel._sha(loaded["fit_event"].tolist())}))
    else:
        state = {"UNFITTED.weight": torch.tensor([1.0])}
        stream = io.BytesIO()
        torch.save([state for _ in range(300)], stream)
        raw = stream.getvalue()
        fit, evaluation = np.asarray(fit, dtype="float32"), np.asarray(evaluation, dtype="float32")
        labtrans = f2_kernel._coxtime_labtrans(models, task["candidate"], loaded["fit_time"], loaded["fit_event"], np)
        fit_input = {"fit_ids_sha256": f2_kernel._sha(loaded["fit_ids"]),
            "fit_design_shape": list(fit.shape), "fit_design_sha256": sha256_bytes(np.ascontiguousarray(fit).tobytes()),
            "fit_time_sha256": f2_kernel._sha(loaded["fit_time"].tolist()),
            "fit_event_sha256": f2_kernel._sha(loaded["fit_event"].tolist()),
            "evaluation_design_shape": list(evaluation.shape),
            "evaluation_design_sha256": sha256_bytes(np.ascontiguousarray(evaluation).tobytes())}
        scaler = {}
        _, standardized = f2_kernel._coxtime_standardize(fit, evaluation, np=np, native_scaler=scaler)
        payload.update(kind="PADML_F2_COXTIME_PREDICTION_FUNCTION",
            checkpoint_sha256s=[f2_kernel._coxtime_state_sha256(state, torch)] * 300,
            candidate_sha256=f2_kernel._sha(task["candidate"]),
            scaler_sha256=f2_kernel._sha({name: value.tolist() for name, value in scaler.items()}),
            labtrans_sha256=f2_kernel._sha({"log_duration": bool(labtrans.log_duration),
                "mean": labtrans.duration_scaler.mean_.tolist(), "scale": labtrans.duration_scaler.scale_.tolist()}),
            evaluation_design_sha256=sha256_bytes(np.ascontiguousarray(standardized).tobytes()),
            fit_input_identity=f2_kernel._sha(fit_input))
    path.parent.mkdir()
    path.write_bytes(raw)
    path.chmod(0o600)
    sealed = {"status": "SEALED", "payload": payload, "sha256": f2_kernel._sha(payload)}
    return sealed, {"kind": "PADML_F2_XGBOOST_QUARANTINE_HANDOFF" if family == "XGBOOST_COX"
        else "PADML_F2_COXTIME_QUARANTINE_HANDOFF", "path": str(path), "sha256": sha256_file(path),
        "size_bytes": len(raw)}


def _unfitted_gbm_loss_unit(aar_source, tmp_path, monkeypatch, scope, *, full0_q_input=None):
    """Original R partition/consumer and Q unit owners; only R fitting is fake."""
    import copy
    from padml import f5
    task, loaded, _ = _q_numbers_python_unit(aar_source, tmp_path, "GBM_COX", scope)
    spec = task["spec"]
    q = Path(spec["native_search_root"]).parent
    (q / "native").mkdir(parents=True)
    if full0_q_input is None:
        spec.update(schema_version="1.0.0", imputation_count=20, heldout_center=36 if scope == "AAR" else None,
            outcome="All_Cause_Death", time="Death_Followup_months", fpm={},
            predictors=f2_kernel.predictor_contract(Path(f2_kernel.__file__).parent))
        spec["selector_from_dependency"]["outer_recipe_sha256"] = "f" * 64
    else:
        assert scope == "FULL0"
        spec = f2_kernel._r_prediction_child_spec({**copy.deepcopy(full0_q_input["spec"]),
            "native_search_root": str(q / "native"), "native_search_replay": False})
    part = copy.deepcopy(loaded["partition"])
    response_path = tmp_path / "unfitted-fit-response.csv"
    response_path.write_bytes(part["fit_response"].pop("private_bytes"))
    part["fit_response"]["path"] = str(response_path)
    part["evaluation_ids_sha256"] = f2_kernel._sha(part["evaluation_ids"])
    part["covariates"] = {"input_dir": "/UNFITTED/raw-covariates", "data_identity": "e" * 64}
    registered = {"partitions": [{key: value for key, value in part.items() if key != "evaluation_response"}],
        "projected_partition_ids": [part["partition_id"]], "projected_partition_count": 1}
    producer = {"task_id": "S1_T001_P01_M01_STOP", "family": "GBM_COX", "producer_kind": "GBM_STOP_CURVE",
        "partition_id": part["partition_id"], "imputation": 1, "seed": task["seed"],
        "selected_parents": ["Age"], "transform_recipe": None,
        "parameters": {"max_trees": 6, "minimum_improvement": 0.0, "early_stopping_patience": 2}}
    (q / "input.json").write_bytes(canonical_json_bytes(full0_q_input if full0_q_input is not None
        else {"UNFITTED": True, "spec": spec, "task": producer}))
    leaf = (spec, registered, [producer], str(tmp_path), str(tmp_path), "GROUPED_COX_LOCK", part)
    name, (_, native_units) = next(iter(f5._q_search_units(f2_kernel._run_r_prediction_pool_task, [leaf]).items()))
    job = {"function": "_run_r_prediction_pool_task", "task": leaf, "task_id": name,
        "native_units": list(native_units), "root": str(q), "work": str(q / "unit-work"),
        "retained_bytes_per_task": 4 * 1024**2}
    matrices = {"fit": [[.01 * (i + 1)] * 6 for i in range(len(part["fit_ids"]))],
        "evaluation": [[-.03 * (i + 1)] * 6 for i in range(len(part["evaluation_ids"]))]}
    calls = []

    def unfitted_native(command, **kwargs):
        current = json.loads(Path(command[-1]).read_bytes())
        calls.append(current["native_search_replay"])
        assert "gbm_stop_loss_references" not in current
        assert not f2_kernel._contains_key(current, "evaluation_response")
        engine_task, = current["producer_tasks"]
        assert "transform_recipe" not in engine_task
        model = Path(current["native_search_root"]) / engine_task["task_id"]
        if current["native_search_replay"]:
            assert {p.name for p in model.iterdir()} == {"model.rds"}
            assert (model / "model.rds").read_bytes() == b"UNFITTED_GBM_MODEL"
        else:
            model.mkdir()
            (model / "model.rds").write_bytes(b"UNFITTED_GBM_MODEL")
        kwargs["stdout"].write(b"UNFITTED GBM R transport\n")
        work = Path(current["output_path"]).parent
        channel = {"schema_version": "1.0.0", "kind": "PADML_F2_OPERATION_LOCAL_RISK_MATRIX_CHANNEL"}
        for role, matrix in matrices.items():
            values = [value for row in matrix for value in row]
            raw = struct.pack("<" + "d" * len(values), *values)
            member = f"risk-001-gbm-{role}.bin"
            (work / member).write_bytes(raw)
            channel[role] = {"schema_version": "1.0.0", "kind": "PADML_F2_OPERATION_LOCAL_RISK_MATRIX",
                "encoding": "IEEE754_FLOAT64", "byte_order": "LITTLE_ENDIAN", "row_order": "ROW_MAJOR",
                "file_name": member, "rows": len(matrix), "columns": 6,
                "size_bytes": len(raw), "sha256": sha256_bytes(raw)}
        row = {"task_id": producer["task_id"], "partition_id": producer["partition_id"], "imputation": 1,
            "fit_ids": part["fit_ids"], "evaluation_ids": part["evaluation_ids"],
            "transform_recipe_sha256": "RAW_CANONICAL", "ordered_parent_column_map": [{"parent": "Age", "columns": ["Age"]}],
            "risk_curve": {"maximum": 6, "risk_matrix_channel": channel},
            "stopping": {"converged": True, "warning_count": 0, "engine": "gbm::gbm",
                "tree_count": 6, "training_loss_count": 6, "training_row_count": len(part["fit_ids"]),
                "independent_variable_count": 1, "minimum_training_loss": 1.0, "maximum_training_loss": 2.0,
                "stopping_reselected": True, "cox_objective": {"implementation": "GROUPED_BRESLOW_V1",
                    "engine_version": "2.3.1.9001", "source_correction": "cox-breslow-ties-v1"}}}
        value = {"schema_version": "1.0.0", "kind": "PADML_F2_R_PREDICTION_BATCH", "status": "PASS",
            "task_count": 1, "tasks": [row]}
        Path(current["output_path"]).write_bytes(canonical_json_bytes(value))
        return SimpleNamespace(returncode=0)

    monkeypatch.setattr(f4.subprocess, "run", unfitted_native)
    return q, job, calls, part, matrices


@pytest.mark.parametrize("scope", ["FULL0", "AAR"])
def test_gbm_complete_losses_pair_and_pinned_original_numbers(aar_source, tmp_path, monkeypatch, scope):
    from padml import f5, f4_compact as compact
    q, job, calls, part, _ = _unfitted_gbm_loss_unit(aar_source, tmp_path, monkeypatch, scope)
    evaluations, original = [], f2_kernel._evaluate_grouped_cox_risk_curve
    def independently_evaluate(*args, **kwargs):
        evaluations.append(kwargs["native_evaluation"])
        return original(*args, **kwargs)
    monkeypatch.setattr(f2_kernel, "_evaluate_grouped_cox_risk_curve", independently_evaluate)
    unit = f5._execute_and_verify_q_search_unit(job)
    assert calls == [False, True] and len(evaluations) == 2 and evaluations[0] is not evaluations[1]
    batch = q / "native" / job["task_id"]
    raw = (batch / "evaluation.json").read_bytes()
    evidence = json.loads(raw)
    assert (q / "native-replay" / job["task_id"] / "evaluation.json").read_bytes() == raw
    assert len(evidence["evaluated_path"]["losses"]) == 6 > evidence["result"]["evaluated_tree_count"]
    assert "evaluated_path" not in unit and unit["first_native_audit_count"] == 1
    projection, refs = compact._full_pipeline_q_numerical_members(q,
        native_units=tuple(job["native_units"]), transported_refs=unit["members"])
    destination = tmp_path / "numbers-only-gbm"
    destination.mkdir()
    for name, path in projection.items():
        target = destination / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, target)
    assert not list(destination.rglob("*.rds"))
    originals = {path.relative_to(q).as_posix(): path.read_bytes() for path in q.rglob("*") if path.is_file()}
    monkeypatch.setattr(f4.subprocess, "run", lambda *a, **k: pytest.fail("NO_R_IN_PINNED_GBM_NUMBERS"))
    monkeypatch.setattr(f2_kernel, "_grouped_cox_loss_path", lambda *a, **k: pytest.fail("NO_REPEATED_GBM_LOSS_PATH"))
    work = tmp_path / "numbers-work"
    work.mkdir()
    loss_refs = {name: refs[f"native/{job['task_id']}/{name}"] for name in ("evaluation.json", "output.json")}
    call = f5._q_search_unit_call(f2_kernel._run_r_prediction_pool_task, job["task"], destination, work,
        mode="numbers", gbm_stop_loss_references=loss_refs)
    # The original child projection carries only the two already verified pins.
    assert f2_kernel._r_prediction_child_spec(call[0])["gbm_stop_loss_references"] == loss_refs
    observed, = f2_kernel._run_r_prediction_pool_task(call)
    expected = {"task_id": job["task"][2][0]["task_id"], "partition_id": part["partition_id"], "imputation": 1,
        **evidence["result"], "minimum_stopping_loss": evidence["result"]["minimum_grouped_cox_deviance"]}
    assert canonical_json_bytes(observed) == canonical_json_bytes(expected)
    assert not list(work.iterdir())
    assert {path.relative_to(q).as_posix(): path.read_bytes() for path in q.rglob("*") if path.is_file()} == originals
    assert len(evaluations) == 2 and calls == [False, True]


def test_gbm_first_audit_rejects_same_lock_but_changed_late_loss(aar_source, tmp_path, monkeypatch):
    from padml import f5
    q, job, calls, _, _ = _unfitted_gbm_loss_unit(aar_source, tmp_path, monkeypatch, "FULL0")
    original, count = f2_kernel._evaluate_grouped_cox_risk_curve, []
    def changed_late_loss(*args, **kwargs):
        result = original(*args, **kwargs)
        count.append(1)
        if len(count) == 2:
            kwargs["native_evaluation"]["losses"][-1] += 1.0
        return result
    monkeypatch.setattr(f2_kernel, "_evaluate_grouped_cox_risk_curve", changed_late_loss)
    with pytest.raises(ContractError, match="Q_STOP_EVALUATION_MISMATCH"):
        f5._execute_and_verify_q_search_unit(job)
    producer = json.loads((q / "native" / job["task_id"] / "evaluation.json").read_bytes())
    audit = json.loads((q / "native-replay" / job["task_id"] / "evaluation.json").read_bytes())
    assert producer["result"] == audit["result"] and producer["evaluated_path"] != audit["evaluated_path"]
    assert calls == [False, True] and len(count) == 2 and not list(q.rglob("object-audit.json"))
    assert (q / "native" / job["task"][2][0]["task_id"] / "model.rds").read_bytes() == b"UNFITTED_GBM_MODEL"


def test_gbm_pinned_loss_reader_rejects_missing_tail_and_binding_damage(aar_source, tmp_path, monkeypatch):
    import copy
    from padml import f5, f4_compact as compact
    from padml.bundle import sha256_file
    q, job, _, part, matrices = _unfitted_gbm_loss_unit(aar_source, tmp_path, monkeypatch, "FULL0")
    unit = f5._execute_and_verify_q_search_unit(job)
    root = q / "native" / job["task_id"]
    path = root / "evaluation.json"
    raw = path.read_bytes()
    refs = {name: unit["members"][f"native/{job['task_id']}/{name}"] for name in ("evaluation.json", "output.json")}
    task = job["task"][2][0]
    sealed = f2_kernel._seal_cox_risk_curve(part["fit_ids"], part["evaluation_ids"], matrices["fit"], matrices["evaluation"], 6)
    context = f2_kernel._grouped_cox_evaluation_context(part["fit_response"], part["evaluation_response"],
        part["fit_ids"], part["evaluation_ids"])
    arguments = {"task": task, "sealed": sealed, "partition": part, "evaluation_context": context}
    monkeypatch.setattr(f2_kernel, "_grouped_cox_loss_path", lambda *a, **k: pytest.fail("NO_FALLBACK_RECOMPUTE"))
    original = json.loads(raw)
    # Changing the bytes delivered by the read must fail the independent pin;
    # the same bounded bytes, not a prior hash pass, are the parsed subject.
    damaged_read = copy.deepcopy(original)
    for increment in (.001, .01, .1, 1.0, 2.0, 3.0):
        damaged_read["evaluated_path"]["losses"][-1] = original["evaluated_path"]["losses"][-1] + increment
        replacement = canonical_json_bytes(damaged_read)
        if len(replacement) == len(raw):
            break
    assert len(replacement) == len(raw) and replacement != raw
    original_open = Path.open
    import io
    sizes = []
    class BoundedRead(io.BytesIO):
        def read(self, size=-1):
            sizes.append(size)
            assert size == len(raw) + 1
            return super().read(size)
    with monkeypatch.context() as m:
        m.setattr(Path, "open", lambda self, *args, **kwargs: (
            BoundedRead(replacement) if self == path
            else original_open(self, *args, **kwargs)))
        with pytest.raises(ContractError, match="GBM_LOSS_BYTES_MISMATCH"):
            compact._full_pipeline_q_gbm_stop_numbers(root, refs, **arguments)
    assert sizes == [len(raw) + 1]
    damaged = copy.deepcopy(original)
    damaged["evaluated_path"]["losses"][-1] += 1.0
    path.write_bytes(canonical_json_bytes(damaged))
    with pytest.raises(ContractError, match="GBM_LOSS_BYTES_MISMATCH"):
        compact._full_pipeline_q_gbm_stop_numbers(root, refs, **arguments)
    # Independently rebound synthetic fixtures exercise full-path and scalar
    # checks, not merely the transport SHA gate. Negative finite losses remain legal.
    for damage in ("tail", "boolean", "risk", "response", "lock"):
        damaged = copy.deepcopy(original)
        if damage == "tail":
            damaged["evaluated_path"]["losses"].pop()
        elif damage == "boolean":
            damaged["evaluated_path"]["losses"][-1] = True
        elif damage in {"risk", "response"}:
            damaged["evaluated_path"]["risk_curve_sha256" if damage == "risk" else "evaluation_response_sha256"] = "0" * 64
        else:
            damaged["result"]["selected_trees"] += 1
        path.write_bytes(canonical_json_bytes(damaged))
        rebound = {**refs, "evaluation.json": {"sha256": sha256_file(path), "size_bytes": path.stat().st_size}}
        with pytest.raises(ContractError):
            compact._full_pipeline_q_gbm_stop_numbers(root, rebound, **arguments)
    path.write_bytes(raw)
    for number in (float("nan"), float("inf"), -float("inf")):
        damaged = copy.deepcopy(original)
        damaged["evaluated_path"]["losses"][-1] = number
        path.write_bytes(json.dumps(damaged, separators=(",", ":")).encode())
        rebound = {**refs, "evaluation.json": {"sha256": sha256_file(path), "size_bytes": path.stat().st_size}}
        with pytest.raises(ContractError):
            compact._full_pipeline_q_gbm_stop_numbers(root, rebound, **arguments)
    path.write_bytes(raw)
    for key in ("partition_id", "imputation", "seed", "parameters"):
        damaged_task = copy.deepcopy(task)
        damaged_task[key] = {**task[key], "max_trees": 7} if key == "parameters" else "WRONG"
        with pytest.raises(ContractError, match="GBM_LOSS_SOURCE_MISMATCH"):
            compact._full_pipeline_q_gbm_stop_numbers(root, refs, **{**arguments, "task": damaged_task})
    for damaged_context in ({**context, "evaluation_ids_sha256": "0" * 64},
                            {**context, "evaluation_events": [0] * len(part["evaluation_ids"])}):
        with pytest.raises(ContractError):
            compact._full_pipeline_q_gbm_stop_numbers(root, refs, **{**arguments, "evaluation_context": damaged_context})
    damaged = copy.deepcopy(original)
    losses = [-1.0] * 6
    damaged["evaluated_path"]["losses"] = losses
    damaged["result"] = f2_kernel._tree_stopping_lock_from_losses(losses,
        risk_curve_sha256=sealed["sha256"], fit_response_sha256=part["fit_response"]["sha256"],
        evaluation_response_sha256=part["evaluation_response"]["sha256"], minimum_improvement=0.0, patience=2, family="GBM_COX")
    path.write_bytes(canonical_json_bytes(damaged))
    rebound = {**refs, "evaluation.json": {"sha256": sha256_file(path), "size_bytes": path.stat().st_size}}
    assert compact._full_pipeline_q_gbm_stop_numbers(root, rebound, **arguments) == damaged["result"]
    path.write_bytes(raw)
    assert path.read_bytes() == raw and (root / "output.json").stat().st_size == refs["output.json"]["size_bytes"]


def _xgb_preparation_unit(aar_source, tmp_path, scope):
    """Actual CSV/factor preparation for one synthetic STOP and distinct INNER."""
    import copy
    import numpy as np
    import pandas as pd
    from padml.bundle import sha256_file
    task, loaded, policy = _q_numbers_python_unit(aar_source, tmp_path, "XGBOOST_COX", scope)
    spec = task["spec"]
    spec.update(outcome="All_Cause_Death", time="Death_Followup_months",
                predictors=f2_kernel.predictor_contract(Path(f2_kernel.__file__).parent),
                xgb_preparation_policy=policy)
    spec["selector_from_dependency"]["selected_parents"] = ["Age", "Smoking"]
    registered = []
    for kind, offset in (("STOP", 0), ("INNER", 100)):
        directory = tmp_path / (kind + "-inputs")
        directory.mkdir()
        part = copy.deepcopy(loaded["partition"])
        part.update(kind=kind, partition_id="UNFITTED_" + kind,
                    application_ids=[*part["fit_ids"], *part["evaluation_ids"]],
                    evaluation_ids_sha256=f2_kernel._sha(part["evaluation_ids"]))
        response = part["fit_response"]
        (directory / "fit-response.csv").write_bytes(response.pop("private_bytes"))
        response["path"] = str(directory / "fit-response.csv")
        members = []
        for imp in range(1, 21):
            raw = "Patient_ID,Age,Smoking\n" + "".join(
                f"{patient},{age + offset + imp - 1},{i % 2}\n" for i, (patient, age) in enumerate(
                    zip(part["application_ids"], [40, 50, 60, 70, 45, 65], strict=True)))
            path = directory / f"imp{imp:02d}.csv"
            path.write_text(raw)
            members.append({"name": path.name, "size_bytes": path.stat().st_size, "sha256": sha256_file(path)})
        part["covariates"] = {"input_dir": str(directory), "members": members, "data_identity": f2_kernel._sha(members)}
        projected = {k: v for k, v in part.items() if k != "evaluation_response"}
        registered.append({"identity": spec["registered_inputs_identity_sha256"], "partitions": [projected],
            "diagnostic_partitions": [], "projected_partition_count": 1, "projected_partition_ids": [part["partition_id"]]})
        if kind == "STOP":
            evaluation_partition = part
    task["registered"] = registered[0]
    actual = f2_kernel._load_python_registered_partition(spec, registered[0], task["partition_id"], pd, np, [1])
    actual["partition"] = evaluation_partition
    return task, actual, policy, registered[1]


@pytest.mark.parametrize("scope", ["FULL0", "AAR"])
@pytest.mark.parametrize("family", ["XGBOOST_COX", "COXTIME_SET_A"])
def test_q_original_python_workers_consume_first_audited_numbers_without_objects(
    aar_source, tmp_path, monkeypatch, family, scope, share_preparation=False, unit_publication=False,
    paired_dispatch=False, batch_dispatch=False, full0_pair_inputs=None, common_stage="S1",
):
    import copy
    import io
    import numpy as np
    import pandas as pd
    import torch
    from padml import f5, f4_compact as compact
    from padml.bundle import sha256_file

    if share_preparation:
        assert family == "XGBOOST_COX"
        task, loaded, policy, inner_registered = _xgb_preparation_unit(aar_source, tmp_path, scope)
    else:
        task, loaded, policy = _q_numbers_python_unit(aar_source, tmp_path, family, scope)
    if full0_pair_inputs is not None:
        assert scope == 'FULL0' and not any((share_preparation, unit_publication, paired_dispatch, batch_dispatch))
        spec = full0_pair_inputs[0]['spec']
        task['spec'] = {**copy.deepcopy(spec), **{key: task['spec'][key]
            for key in ('native_search_root', 'native_search_replay')}}
        task['registered']['identity'] = spec['registered_inputs_identity_sha256']
        task['task_id'] = task['task_id'].replace('S1_', common_stage + '_')
        repeat = 1 if common_stage == 'S1' else 2
        task['seed'] = spec['seed'] + repeat * 10000 + 101
        loaded['partition']['repeat'] = repeat
    q = Path(task["spec"]["native_search_root"]).parent
    (q / "native").mkdir(parents=True)
    (q / "input.json").write_bytes(canonical_json_bytes(full0_pair_inputs[0] if full0_pair_inputs is not None
        else {"UNFITTED_Q_COORDINATE": task["spec"]}))
    calls = []
    state = {"UNFITTED.weight": torch.tensor([1.0])}
    stream = io.BytesIO()
    torch.save({"state_dict": state}, stream)
    model = b"UNFITTED_XGB_REFIT" if family == "XGBOOST_COX" else stream.getvalue()
    baseline = b"UNFITTED_BASELINE"
    locked = 1 if family == "XGBOOST_COX" else 50
    survival = np.array([[1.0 - month / 100 for month in range(1, 37)]] * 2)
    health = {"converged": True, **({"engine": "xgboost survival:cox", "objective": "survival:cox",
        "booster_round_count": locked, "training_margin_count": 4, "evaluation_margin_count": 2,
        "model_binary_sha256": sha256_bytes(model),
        "cox_objective": {"implementation": "GROUPED_BRESLOW_FLOAT64_TIME_V1",
            "gradient_evaluations": locked, "training_rows": 4, "event_time_groups": 3}}
        if family == "XGBOOST_COX" else {"engine": "pycox.models.CoxTime", "training_epoch_count": locked,
            "training_row_count": 4, "evaluation_row_count": 2, "final_training_loss": .25,
            "raw_survival_grid_validated": True, "model_state_sha256": f2_kernel._coxtime_state_sha256(state, torch),
            "baseline_numerics": {"implementation": "FULL_T_GE_T_RISK_SET_V1", "training_rows": 4,
                "event_time_groups": 3, "checked_raw_scores": 12}})}
    preparation_reads = []
    original_loader = f2_kernel._load_python_registered_partition
    def loaded_partition(spec, registered, partition_id, *args):
        if share_preparation:
            preparation_reads.append((partition_id, list(args[-1])))
            return original_loader(spec, registered, partition_id, *args)
        result = copy.deepcopy(loaded)
        if partition_id == "UNFITTED_INNER":
            result["partition"]["kind"] = "INNER"
            result["partition"]["partition_id"] = partition_id
        return result
    monkeypatch.setattr(f2_kernel, "_load_python_registered_partition", loaded_partition)
    def fit_function(*args, **kwargs):
        calls.append("UNFITTED_STOP_FIT")
        return _unfitted_q_function(task, loaded, args[-1])
    monkeypatch.setattr(f2_kernel, "_xgb_prediction_function_seal" if family == "XGBOOST_COX"
                        else "_coxtime_prediction_function_seal", fit_function)
    class UnfittedBooster:
        def load_model(self, path):
            assert Path(path).read_bytes() == b"UNFITTED_XGB_FUNCTION"
            calls.append("FIRST_NATIVE_OBJECT_OPEN")
    if family == "XGBOOST_COX":
        import xgboost as xgb
        monkeypatch.setattr(xgb, "Booster", UnfittedBooster)
        monkeypatch.setattr(xgb, "DMatrix", lambda matrix, **kwargs: matrix)
    else:
        monkeypatch.setattr(f2_kernel, "_coxtime_seed", lambda *args: "cpu")
        monkeypatch.setattr(f2_kernel, "_coxtime_model", lambda *args: calls.append("FIRST_NATIVE_OBJECT_OPEN") or object())
    def evaluate_function(sealed, *args, **kwargs):
        calls.append("UNFITTED_STOP_EVALUATION")
        if family == "COXTIME_SET_A":
            return {"schema_version": "1.0.0", "kind": "PADML_F2_COXTIME_VALIDATION_CURVE",
                "function_sha256": sealed["sha256"],
                "evaluation_response_sha256": loaded["partition"]["evaluation_response"]["sha256"],
                **{key: task["spec"]["coxtime"]["shared_candidate_parameters"][key]
                   for key in ("validation_repeat", "n_control", "validation_control_seed_offset",
                               "validation_control_seed_rule")},
                "losses": [1.0 + abs(i - 49) / 100 for i in range(300)]}
        losses = [1.0, 1.0, 1.0]
        path = {"schema_version": "1.0.0", "kind": "PADML_F2_GROUPED_COX_LOSS_PATH",
            "risk_curve_sha256": sealed["sha256"], "fit_response_sha256": kwargs["fit_response"]["sha256"],
            "evaluation_response_sha256": kwargs["evaluation_response"]["sha256"],
            "validation_n": 2, "losses": losses}
        kwargs["native_evaluation"].update(path)
        return f2_kernel._tree_stopping_lock_from_losses(losses, risk_curve_sha256=sealed["sha256"],
            fit_response_sha256=path["fit_response_sha256"], evaluation_response_sha256=path["evaluation_response_sha256"],
            minimum_improvement=0.0, patience=2, family="XGBOOST_COX")
    monkeypatch.setattr(f2_kernel, "_evaluate_grouped_cox_risk_curve" if family == "XGBOOST_COX"
                        else "_evaluate_coxtime_function_seal", evaluate_function)
    for name in ("_xgb_native_model_bytes", "_coxtime_native_model_bytes"):
        monkeypatch.setattr(f5, name, lambda *args: model)
    for name in ("_xgb_native_baseline_bytes", "_coxtime_native_baseline_bytes"):
        monkeypatch.setattr(f5, name, lambda *args: baseline)
    def fit_refit(*args, native_capture):
        calls.append("UNFITTED_REFIT")
        if share_preparation:
            assert np.array_equal(args[2][:, 0], loaded["fit_designs"][0][:, 0] + 100)
            assert np.array_equal(args[5][:, 0], loaded["evaluation_designs"][0][:, 0] + 100)
        native_capture("model", model=object(), design=args[2] if share_preparation else loaded["fit_designs"][0], torch=torch,
                       scaler={"mean": [0.], "scale": [1.]}, labtrans=object())
        if family == "COXTIME_SET_A":
            native_capture("training_log", frame=pd.DataFrame({"train_loss": [.25] * locked}))
        native_capture("baseline", event_times=[3.], cumulative=[.1], baseline=object())
        return {"survival": survival.copy(), "fit_health": health}
    monkeypatch.setattr(f2_kernel, "_xgb_refit_predict" if family == "XGBOOST_COX" else "_coxtime_refit_predict", fit_refit)
    def replay_prediction(*args):
        calls.append("FIRST_NATIVE_REFIT_REPLAY")
        assert args[7] == (model, baseline)
        return {"survival": survival.tolist()}
    monkeypatch.setattr(f5, "_predict_retained_python_arrays", replay_prediction)
    function = f2_kernel._run_xgb_function_pool_task if family == "XGBOOST_COX" else f2_kernel._run_coxtime_function_pool_task
    evaluator = f2_kernel._run_xgb_function_evaluator_pool_task if family == "XGBOOST_COX" else f2_kernel._run_coxtime_function_evaluator_pool_task
    refitter = f2_kernel._run_xgb_refit_pool_task if family == "XGBOOST_COX" else f2_kernel._run_coxtime_refit_pool_task
    if batch_dispatch:
        _q_verify_python_batch_dispatch(task, loaded, policy, refitter, locked, calls, tmp_path, monkeypatch,
            inner_registered=inner_registered if share_preparation else None)
        return
    paired_calls = []
    if paired_dispatch:
        def serial_pair_pool(function, tasks, *, selected_slots):
            assert function is f2_kernel._run_python_stop_pair_pool_task
            paired_calls.append([item[0]["task_id"] for item in tasks])
            return [function(item) for item in tasks]
        monkeypatch.setattr(f2_kernel, "_bounded_ordered_spawn", serial_pair_pool)
        if share_preparation:
            def shared_evaluator(current):
                borrowed = f2_kernel._read_xgb_stop_preparation(current, np)
                for key in ("fit_designs", "evaluation_designs", "fit_time", "fit_event"):
                    original = loaded[key][0] if key.endswith("designs") else loaded[key]
                    actual = borrowed[key][0] if key.endswith("designs") else borrowed[key]
                    assert actual.dtype == original.dtype and actual.shape == original.shape
                    assert actual.tobytes() == original.tobytes()
                return evaluator(current)
            monkeypatch.setattr(f2_kernel, "_run_xgb_function_evaluator_pool_task", shared_evaluator)
    results = []
    for mode in ("producer", "first-audit"):
        current = copy.deepcopy(task)
        current["spec"]["native_search_replay"] = mode == "first-audit"
        current["handoff_path"] = str(tmp_path / (mode + "-handoff") / "model")
        if paired_dispatch:
            evaluation, = f2_kernel._search_python_stop_batch(current["spec"], [current], [loaded["partition"]],
                                                             selected_slots=24)
        else:
            produced = function(current)
            if share_preparation:
                borrowed = f2_kernel._read_xgb_stop_preparation({**current, "function_result": produced}, np)
                assert borrowed["columns"] == loaded["columns"]
                for key in ("fit_designs", "evaluation_designs", "fit_time", "fit_event"):
                    original = loaded[key][0] if key.endswith("designs") else loaded[key]
                    actual = borrowed[key][0] if key.endswith("designs") else borrowed[key]
                    assert actual.dtype == original.dtype and actual.shape == original.shape
                    assert actual.tobytes() == original.tobytes()
            evaluation = evaluator({**current, "evaluation_partition": loaded["partition"], "function_result": produced})
        refit = {key: value for key, value in current.items() if key != "handoff_path"}
        refit.update(task_id=common_stage + "_T001_P01_M01_LOCKED_REFIT", partition_id="UNFITTED_INNER",
                     prediction_horizons=list(range(1, 37)),
                     **{"locked_rounds" if family == "XGBOOST_COX" else "locked_epoch": locked})
        if share_preparation:
            refit["registered"] = inner_registered
        fitted = refitter(refit)
        results.append((evaluation, fitted))
    assert results[0] == results[1]
    if paired_dispatch:
        assert paired_calls == [[task["task_id"]], [task["task_id"]]]
    unit_refs = (_q_publish_units_before_result(q, [(task["task_id"],), (refit["task_id"],)])
                 if unit_publication else None)
    (q / "result.json").write_bytes(canonical_json_bytes(results[0]))
    projection, references = compact._full_pipeline_q_numerical_members(q, publish=True, transported_refs=unit_refs)
    destination = tmp_path / "numbers-only"
    destination.mkdir()
    for name, path in projection.items():
        if unit_publication and name == "numbers.json":
            continue
        target = destination / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, target)
    assert not list(destination.rglob("*.rds")) and not list(destination.rglob("*.pt")) and not list(destination.rglob("*.ubj"))
    if unit_publication:
        _q_publish_transported_units(destination, q, unit_refs, monkeypatch)
        # One complete local STOP object may coexist with transported refit
        # numbers. The normal readers still must not open either model.
        name = "function.ubj" if family == "XGBOOST_COX" else "checkpoints.pt"
        shutil.copyfile(q / "native" / task["task_id"] / name, destination / "native" / task["task_id"] / name)
    compact._full_pipeline_q_numerical_members(destination)
    before = list(calls)
    def forbidden(*args, **kwargs):
        pytest.fail("NORMAL_NUMBERS_MUST_NOT_OPEN_OR_EXECUTE_MODELS")
    for name in ("_xgb_runtime_from_handoff", "_coxtime_runtime_from_handoff",
                 "_xgb_prediction_function_seal", "_coxtime_prediction_function_seal",
                 "_xgb_refit_predict", "_coxtime_refit_predict", "_coxtime_seed"):
        monkeypatch.setattr(f2_kernel, name, forbidden)
    monkeypatch.setattr(f5, "_predict_retained_python_arrays", forbidden)
    current["spec"].update(native_search_root=str(destination / "native"), native_search_numbers=True)
    current["handoff_path"] = str(tmp_path / "never-created-handoff" / "model")
    numeric_function = function(current)
    numeric_evaluation_task = {**current, "evaluation_partition": loaded["partition"], "function_result": numeric_function}
    assert evaluator(numeric_evaluation_task) == results[0][0]
    refit["spec"] = current["spec"]
    assert refitter(refit) == results[0][1]
    assert not Path(current["handoff_path"]).parent.exists() and calls == before
    if full0_pair_inputs is not None:
        source = tmp_path / 'common-source.zip'
        f4.compile_f45_source_bundle(source)
        consumer = tmp_path / 'consumer-input.json'
        consumer.write_bytes(canonical_json_bytes(full0_pair_inputs[1]))
        identity = sha256_bytes(canonical_json_bytes(f4._f45_source_member_sha256()))
        pair = {'producer_input': {'path': str(destination / 'input.json'),
            'sha256': sha256_file(destination / 'input.json'), 'size_bytes': (destination / 'input.json').stat().st_size},
            'consumer_input': {'path': str(consumer), 'sha256': sha256_file(consumer), 'size_bytes': consumer.stat().st_size},
            'retained_source_bundle': str(source), 'producer_source_identity': identity, 'executor_source_identity': identity}
        original_bytes = {p: p.read_bytes() for p in destination.rglob('*') if p.is_file()}
        twelve_stop = {**task, 'spec': copy.deepcopy(full0_pair_inputs[1]['spec'])}
        scratch = tmp_path / 'paired-number-read'
        scratch.mkdir()
        def stop_call(value=twelve_stop, binding=pair, mode='numbers'):
            return f5._q_search_unit_call(f2_kernel._run_python_stop_pair_pool_task,
                (value, loaded['partition']), destination, scratch, mode=mode, full0_rsf_s1s2_pair=binding)
        assert f2_kernel._run_python_stop_pair_pool_task(stop_call()) == results[0][0]
        twelve_refit = {**refit, 'spec': copy.deepcopy(full0_pair_inputs[1]['spec'])}
        read_refit = f5._q_search_unit_call(refitter, twelve_refit, destination, scratch,
            mode='numbers', full0_rsf_s1s2_pair=pair)
        assert refitter(read_refit) == results[0][1]
        assert f2_kernel._selection_horizon_from_spec(read_refit['spec']) == 12
        forbidden_stage, repeat = ('S3A', 3) if family == 'XGBOOST_COX' else ('S2', 2)
        later = copy.deepcopy(stop_call()[0])
        later['task_id'] = later['task_id'].replace(common_stage + '_', forbidden_stage + '_')
        later['seed'] = 300000 + repeat * 10000 + 101
        later_loaded = copy.deepcopy(loaded)
        later_loaded['partition']['repeat'] = repeat
        with pytest.raises(ContractError, match='F5_FULL0_PYTHON_COMMON_INPUT_INVALID'):
            f5._final_python_search_binding(later, later_loaded, later_loaded['fit_designs'][0], stop=True)
        for mode in ('produce', 'audit'):
            with pytest.raises(ContractError): stop_call(mode=mode)
        for damage in ('source', 'input-pin', 'seed', 'parameters', 'stage', 'scope', 'geometry'):
            value, binding = copy.deepcopy(twelve_stop), copy.deepcopy(pair)
            if damage == 'source': binding['producer_source_identity'] = '0' * 64
            elif damage == 'input-pin': binding['consumer_input']['sha256'] = '0' * 64
            elif damage == 'seed': value['seed'] += 1
            elif damage == 'parameters': value['parameters' if family == 'XGBOOST_COX' else 'candidate']['UNFITTED_CHANGED'] = True
            elif damage == 'scope': value['spec']['execution_scope'] = 'F5_A12_SEARCH'
            elif damage == 'geometry': value['spec']['threads'] += 1
            else:
                value['task_id'] = value['task_id'].replace(common_stage + '_', ('S3A' if family == 'XGBOOST_COX' else 'S2') + '_')
            with pytest.raises(ContractError):
                f2_kernel._run_python_stop_pair_pool_task(stop_call(value, binding))
        assert calls == before and {p: p.read_bytes() for p in destination.rglob('*') if p.is_file()} == original_bytes
        return
    if share_preparation:
        assert preparation_reads == [(name, [1]) for _ in range(3) for name in ("UNFITTED_STOP", "UNFITTED_INNER")]
        normal_preparation_reads = list(preparation_reads)
    if unit_publication:
        refit_root = destination / "native" / refit["task_id"]
        shutil.copyfile(q / "native" / refit["task_id"] / "model.bin", refit_root / "model.bin")
        with pytest.raises(ContractError, match="Q_MEMBER_SET_INVALID"):
            compact._full_pipeline_q_numerical_members(destination)
        with pytest.raises(ContractError, match="Q_MEMBER_SET_INVALID"):
            refitter(refit)
        (refit_root / "model.bin").unlink()
    if share_preparation:
        rejected_preparation_reads = [("UNFITTED_INNER", [1])] if unit_publication else []
        assert preparation_reads == normal_preparation_reads + rejected_preparation_reads
        assert not list(tmp_path.glob("*-handoff/preparation.bin"))
        (tmp_path / "xgb-preparation-observation.json").write_bytes(canonical_json_bytes({
            "scope": scope, "original_producer_native_audit_and_numbers_results_identical": True,
            "actual_csv_factor_loads": normal_preparation_reads, "uncached_equivalent_loads": 9,
            "rejected_partial_model_csv_loads": rejected_preparation_reads,
            "stop_evaluator_csv_factor_loads": 0, "native_calls": calls, "normal_native_calls": 0,
            "inner_view_distinct": True, "actual_model_fits": 0, "actual_mice_chains": 0,
            "native_leaf": "UNFITTED", "source_csv_member_count": 40,
            "paired_dispatch": paired_dispatch, "paired_calls": paired_calls}))
        return

    def reseal_leaf(path):
        leaf = path.parent / "object-audit.json"
        record = json.loads(leaf.read_bytes())
        record[path.name] = {"sha256": sha256_file(path), "size_bytes": path.stat().st_size}
        leaf.write_bytes(canonical_json_bytes(record))
    rejected = []
    refit_root, stop_root = destination / "native" / refit["task_id"], destination / "native" / current["task_id"]
    for damage in ("input", "health", "prediction", "missing_baseline", "function_seed", "function_array",
                   "evaluation_source", "loss_count", "boolean_reference"):
        directory = refit_root if damage in {"input", "health", "prediction", "missing_baseline"} else stop_root
        originals = {p.name: p.read_bytes() for p in directory.iterdir()}
        if damage in {"input", "health", "prediction"}:
            path = directory / {"input": "input.json", "health": "fit-health.json", "prediction": "prediction.json"}[damage]
            value = json.loads(path.read_bytes())
            if damage == "input":
                value["training_binding"]["model_seed"] += 1
            elif damage == "health":
                value["booster_round_count" if family == "XGBOOST_COX" else "training_epoch_count"] += 1
            else:
                value[0][0] = 2.0
            path.write_bytes(canonical_json_bytes(value))
            reseal_leaf(path)
        elif damage == "missing_baseline":
            path = directory / "object-audit.json"
            value = json.loads(path.read_bytes())
            del value["baseline.bin"]
            path.write_bytes(canonical_json_bytes(value))
        elif damage in {"function_seed", "function_array"}:
            path = directory / "function.json"
            value = json.loads(path.read_bytes())
            payload = value["sealed"]["payload"]
            if damage == "function_seed":
                payload["seed"] += 1
            else:
                payload["design_identity" if family == "XGBOOST_COX" else "scaler_sha256"] = "f" * 64
            value["sealed"]["sha256"] = f2_kernel._sha(payload)
            path.write_bytes(canonical_json_bytes(value))
            reseal_leaf(path)
        elif damage in {"evaluation_source", "loss_count"}:
            path = directory / "evaluation.json"
            value = json.loads(path.read_bytes())
            if damage == "evaluation_source":
                value["function_sha256"] = "f" * 64
            elif family == "XGBOOST_COX":
                value["evaluated_path"]["losses"].pop()
            else:
                value["result"]["losses"].pop()
            path.write_bytes(canonical_json_bytes(value))
            reseal_leaf(path)
        else:
            path = directory / "object-audit.json"
            value = json.loads(path.read_bytes())
            value["function.ubj" if family == "XGBOOST_COX" else "checkpoints.pt"]["size_bytes"] = True
            path.write_bytes(canonical_json_bytes(value))
        with pytest.raises(ContractError):
            refitter(refit) if directory == refit_root else evaluator(numeric_evaluation_task)
        for name, raw in originals.items():
            (directory / name).write_bytes(raw)
        rejected.append(damage)
    assert calls == before
    (tmp_path / "q-numeric-observation.json").write_bytes(canonical_json_bytes({
        "scope": scope, "family": family, "native_calls": calls, "normal_native_calls": 0,
        "rejected": rejected, "actual_model_fits": 0, "actual_mice_chains": 0,
        "original_stop_refit_worker_results_identical": True, "native_leaf": "UNFITTED",
        "native_reference_count": len(references), "unit_publication": unit_publication,
        "paired_dispatch": paired_dispatch, "paired_calls": paired_calls}))


def _q_publish_units_before_result(root, groups):
    from padml import f4_compact as compact
    refs = {}
    assert not (root / "result.json").exists() and not (root / "numbers.json").exists()
    for group in groups:
        projection, current = compact._full_pipeline_q_numerical_members(root, publish=True, native_units=group)
        assert set(refs) & set(current) <= {"input.json"}
        if refs:
            assert refs["input.json"] == current["input.json"]
        refs.update(current)
        assert not {"result.json", "numbers.json"} & set(projection)
        assert not (root / "result.json").exists() and not (root / "numbers.json").exists()
        with pytest.raises(ContractError, match="Q_ALREADY_PUBLISHED"):
            compact._full_pipeline_q_numerical_members(root, publish=True, native_units=group)
    return refs


def _q_verify_python_batch_dispatch(task, loaded, policy, refitter, locked, calls, tmp_path, monkeypatch,
                                     *, inner_registered=None):
    """Original Python leaves and numerical consumers, two disjoint workers."""
    import copy
    from padml import f5, f4_compact as compact
    root = Path(task["spec"]["native_search_root"]).parent
    def pool(function, tasks, *, selected_slots, execution_report=None, on_result=None):
        if execution_report is not None:
            execution_report.update(configured_worker_ceiling=56, admitted_worker_ceiling=selected_slots,
                runnable_task_count=len(tasks), actual_worker_process_peak=1, completed_task_count=0,
                engine_threads=1, status="RUNNING")
        results = []
        for index, item in enumerate(tasks):
            row = function(item)
            results.append(row)
            if on_result is not None:
                on_result(index, row)
        if execution_report is not None:
            execution_report.update(completed_task_count=len(tasks), status="COMPLETED")
        return results
    monkeypatch.setattr(f5, "_bounded_ordered_spawn", pool)
    workers = [tmp_path / f"worker-{index}" for index in (1, 2)]
    for worker in workers:
        (worker / "native").mkdir(parents=True)
        shutil.copyfile(root / "input.json", worker / "input.json")
    stopped = [({**task, "task_id": f"S1_T{index:03d}_P01_M01_FUNCTION"}, loaded["partition"]) for index in (1, 2)]
    refits = [{**{key: value for key, value in item.items() if key != "handoff_path"},
               "task_id": item["task_id"].replace("FUNCTION", "LOCKED_REFIT"), "partition_id": "UNFITTED_INNER",
               "prediction_horizons": list(range(1, 37)),
               **{"locked_rounds" if task["spec"]["family"] == "XGBOOST_COX" else "locked_epoch": locked},
               **({"registered": inner_registered} if inner_registered is not None else {})}
              for item, _ in stopped]
    phases = [(f2_kernel._run_python_stop_pair_pool_task, stopped), (refitter, refits)]
    batches, expected = [], []
    def invoke(owner, function, tasks, *, ids=None, history=None, destination=None, completed=False):
        options = None if completed else {"prepare_only": ids is None, "task_ids": ids, "batch_root": destination,
            "q_batches": history, "retained_bytes_per_task": 32 * 1024**2 if ids is not None else None}
        control = f5._q_search_batch_control(owner, policy, options)
        spec = {**task["spec"], "native_search_root": str(owner / "native"), "native_search_batch": control}
        try:
            result = f2_kernel._search_task_batch(spec, function, tasks, selected_slots=56)
        except f5._QBatchBoundary as boundary:
            return boundary.result, control
        return result, control
    for phase_index, (function, items) in enumerate(phases):
        # The original funnel supplies all preceding batches before this call;
        # this focused leaf test consumes the current exact batch in isolation.
        prepared, _ = invoke(root, function, items)
        ids = prepared["task_ids"]
        assert prepared["status"] == "PREPARED_Q_BATCH" and len(ids) == 2
        phase_batches = []
        for index, worker in enumerate(workers):
            destination = tmp_path / f"phase-{phase_index}-batch-{index}"
            produced, _ = invoke(worker, function, items, ids=ids[index:index + 1], destination=destination)
            assert produced["status"] == "COMPUTED_Q_BATCH"
            assert produced["execution"]["new_model_fit_count"] == 1
            assert produced["execution"]["confirmed_first_native_audit_count"] == 1
            assert not (worker / "result.json").exists()
            with pytest.raises(ContractError, match="COORDINATE_ALREADY_STARTED"):
                invoke(worker, function, items, ids=ids[index:index + 1], destination=tmp_path / f"duplicate-{phase_index}-{index}")
            phase_batches.append(destination)
        with pytest.raises(ContractError, match="COMPLETE_COORDINATES_REQUIRED"):
            invoke(root, function, items, history=phase_batches[:1])
        before = list(calls)
        rows, _ = invoke(root, function, items, history=phase_batches)
        assert len(rows) == 2 and calls == before
        expected.append(rows)
        batches.extend(phase_batches)
    # Complete reconstruction must consume every source record in original
    # order, and bind the real first-audit counts before publishing the Q.
    control = f5._q_search_batch_control(root, policy, {"prepare_only": True, "task_ids": None,
        "batch_root": None, "q_batches": batches, "retained_bytes_per_task": None})
    spec = {**task["spec"], "native_search_root": str(root / "native"), "native_search_batch": control}
    for (function, items), rows in zip(phases, expected, strict=True):
        assert f2_kernel._search_task_batch(spec, function, items, selected_slots=56) == rows
    result = {"total_search_fit_count": 4, "response_free_stopping_fit_count": 2, "UNFITTED": True}
    f5._q_search_batch_completion(root, control, result)
    (root / "result.json").write_bytes(canonical_json_bytes(result))
    members, _ = compact._full_pipeline_q_numerical_members(root, publish=True, transported_refs=control["references"])
    assert "execution.json" in members
    transported = tmp_path / "complete-transport"
    transported.mkdir()
    for name, path in members.items():
        output = transported / name
        output.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, output)
    before = list(calls)
    def forbidden(*args, **kwargs):
        pytest.fail("COMPLETED_Q_MUST_NOT_REOPEN_OR_REFIT_MODELS")
    for name in ("_xgb_prediction_function_seal", "_coxtime_prediction_function_seal", "_xgb_refit_predict",
                 "_coxtime_refit_predict", "_xgb_runtime_from_handoff", "_coxtime_runtime_from_handoff"):
        monkeypatch.setattr(f2_kernel, name, forbidden)
    monkeypatch.setattr(f5, "_predict_retained_python_arrays", forbidden)
    compact._full_pipeline_q_numerical_members(transported)
    control = f5._q_search_batch_control(transported, policy, None)
    spec.update(native_search_root=str(transported / "native"), native_search_batch=control)
    for (function, items), rows in zip(phases, expected, strict=True):
        assert f2_kernel._search_task_batch(spec, function, items, selected_slots=56) == rows
    f5._q_search_batch_completion(transported, control, result)
    assert calls == before and calls.count("UNFITTED_STOP_FIT") == calls.count("UNFITTED_REFIT") == 2
    assert not list(transported.rglob("model.bin")) and not list(transported.rglob("*.pt"))
    rejected = []
    for damage in ("source", "input", "phase", "missing", "duplicate", "count", "pool", "admission", "retention"):
        damaged = f5._q_search_batch_control(transported, policy, None)
        rows = damaged["batches"]
        row = rows[0][1]
        if damage == "source":
            row["source_identity"] = "0" * 64
        elif damage == "input":
            row["input"]["sha256"] = "0" * 64
        elif damage == "phase":
            row["phase"] += "-alien"
        elif damage == "missing":
            rows.pop(0)
        elif damage == "duplicate":
            rows.append(copy.deepcopy(rows[0]))
        elif damage == "count":
            row["new_model_fit_count"] = True
        elif damage == "pool":
            row["pool"]["completed_task_count"] = 0
        elif damage == "admission":
            row["resource_admission"]["admitted_worker_ceiling"] += 1
        else:
            row["retained_bytes_per_task"] = 1
        spec["native_search_batch"] = damaged
        with pytest.raises(ContractError):
            for function, items in phases:
                f2_kernel._search_task_batch(spec, function, items, selected_slots=56)
            f5._q_search_batch_completion(transported, damaged, result)
        rejected.append(damage)
    (tmp_path / "q-batch-observation.json").write_bytes(canonical_json_bytes({
        "scope": task["spec"]["execution_scope"], "family": task["spec"]["family"],
        "unit_count": 4, "batch_count": 4, "first_audit_count": 4, "disjoint_workers": 2,
        "native_calls": calls, "normal_native_calls": 0, "rejected": rejected,
        "retained_execution_ledger": True, "native_leaf": "UNFITTED", "actual_model_fits": 0}))


@pytest.mark.parametrize("scope", ["FULL0", "AAR"])
@pytest.mark.parametrize("family,share", [("XGBOOST_COX", False), ("XGBOOST_COX", True), ("COXTIME_SET_A", False)])
def test_q_python_disjoint_batches_first_audit_and_complete_numeric_replay(
    aar_source, tmp_path, monkeypatch, family, share, scope,
):
    test_q_original_python_workers_consume_first_audited_numbers_without_objects(
        aar_source, tmp_path, monkeypatch, family, scope, share_preparation=share, batch_dispatch=True)


@pytest.mark.parametrize("scope", ["FULL0", "AAR"])
@pytest.mark.parametrize("family", ["RSF", "GBM_COX"])
def test_q_coalesced_r_batch_uses_original_rich_consumer(aar_source, tmp_path, monkeypatch, family, scope):
    from padml import f5, f4_compact as compact
    task, loaded, policy = _q_numbers_python_unit(aar_source, tmp_path, family, scope)
    spec = {**task["spec"], "predictors": f2_kernel.predictor_contract(Path(f2_kernel.__file__).parent)}
    root = Path(spec["native_search_root"]).parent
    (root / "native").mkdir(parents=True)
    (root / "input.json").write_bytes(canonical_json_bytes({"spec": spec, "UNFITTED": True}))
    part = {**loaded["partition"], "evaluation_ids_sha256": f2_kernel._sha(loaded["evaluation_ids"]),
        "covariates": {"input_dir": "/UNFITTED", "data_identity": "b" * 64}}
    for role in ("fit_response", "evaluation_response"):
        record = dict(part[role])
        path = tmp_path / (role + ".csv")
        path.write_bytes(record.pop("private_bytes"))
        part[role] = {**record, "path": str(path)}
    registered = {"partitions": [{key: value for key, value in part.items() if key != "evaluation_response"}],
        "diagnostic_partitions": [], "projected_partition_ids": [part["partition_id"]], "projected_partition_count": 1}
    parameters = {"num_trees": 10, "mtry_fraction": "1.0"} if family == "RSF" else {"locked_trees": 10}
    producer_tasks = [{"task_id": f"S1_T001_P01_M{imp:02d}", "partition_id": part["partition_id"],
        "family": family, "imputation": imp, "model_seed": 310101, "producer_kind": "SURVIVAL",
        "selected_parents": ["Age"], "parameters": parameters, "prediction_horizons": list(range(1, 37))}
        for imp in range(1, 5)]
    original = (spec, registered, producer_tasks, str(tmp_path), str(Path(f2_kernel.__file__).parent), "IBS", part)
    native_calls = []
    def native(command, **kwargs):
        current = json.loads(Path(command[-1]).read_bytes())
        assert "native_search_batch" not in current and not f2_kernel._contains_key(current, "evaluation_response")
        assert [row["task_id"] for row in current["producer_tasks"]] == [row["task_id"] for row in producer_tasks]
        native_calls.append((current["native_search_replay"], len(current["producer_tasks"])))
        results = []
        for item in current["producer_tasks"]:
            directory = Path(current["native_search_root"]) / item["task_id"]
            if not current["native_search_replay"]:
                directory.mkdir()
            for name in (["model.rds"] if family == "RSF" else ["model.rds", "baseline.rds"]):
                raw = ("UNFITTED:" + item["task_id"] + ":" + name).encode()
                if current["native_search_replay"]:
                    assert (directory / name).read_bytes() == raw
                else:
                    (directory / name).write_bytes(raw)
            health = {"converged": True, "warning_count": 0, "independent_variable_count": 1, "tree_count": 10}
            health.update({"engine": "ranger::ranger", "num_trees": 10, "mtry": 1,
                "death_time_count": 3, "prediction_error": .2} if family == "RSF" else {
                "engine": "gbm::gbm", "training_row_count": 4, "training_loss_count": 10,
                "minimum_training_loss": .2, "maximum_training_loss": .3, "stopping_reselected": False,
                "selected_trees": 10, "training_only_stop_count": 0,
                "cox_objective": {"implementation": "GROUPED_BRESLOW_V1", "engine_version": "2.3.1.9001",
                    "source_correction": "cox-breslow-ties-v1"}})
            results.append({"task_id": item["task_id"], "partition_id": item["partition_id"], "imputation": item["imputation"],
                "evaluation_ids": part["evaluation_ids"], "transform_recipe_sha256": "RAW_CANONICAL",
                "ordered_parent_column_map": f2_kernel._expected_family_parent_column_map(["Age"], family, spec["predictors"], None),
                "stopping": health, "survival": [[1 - month / (100 + item["imputation"]) for month in range(1, 37)]] * 2})
        kwargs["stdout"].write(b"UNFITTED coalesced four-task batch\n")
        Path(current["output_path"]).write_bytes(canonical_json_bytes({"schema_version": "1.0.0",
            "kind": "PADML_F2_R_PREDICTION_BATCH", "status": "PASS", "task_count": 4, "tasks": results}))
        return SimpleNamespace(returncode=0)
    monkeypatch.setattr(f4.subprocess, "run", native)
    function = f2_kernel._run_r_prediction_pool_task
    name, (_, native_units) = next(iter(f5._q_search_units(function, [original]).items()))
    assert len(native_units) == 5
    job = {"function": function.__name__, "task_id": name, "task": original, "native_units": list(native_units),
           "root": str(root), "work": str(root / "batch-work" / name), "retained_bytes_per_task": 32 * 1024**2}
    row = f5._execute_and_verify_q_search_unit(job)
    assert row["first_native_audit_count"] == 4 and native_calls == [(False, 4), (True, 4)]
    with pytest.raises(ContractError, match="COORDINATE_ALREADY_STARTED"):
        f5._execute_and_verify_q_search_unit(job)
    destination = tmp_path / "numeric-batch"
    destination.mkdir()
    for member in row["numerical_members"]:
        output = destination / member
        output.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(root / member, output)
    compact._full_pipeline_q_numerical_members(destination, native_units=native_units, transported_refs=row["members"])
    monkeypatch.setattr(f4.subprocess, "run", lambda *a, **k: pytest.fail("NORMAL_R_NUMERIC_BATCH_MUST_NOT_START_R"))
    scratch = tmp_path / "numeric-consumer"
    scratch.mkdir()
    results = function(f5._q_search_unit_call(function, original, destination, scratch, mode="numbers"))
    assert len(results) == 4 and [item["imputation"] for item in results] == [1, 2, 3, 4]
    assert all(item["ibs_0_24"] > 0 and "sealed_prediction" in item for item in results)
    assert not list(destination.rglob("*.rds")) and native_calls == [(False, 4), (True, 4)]
    (tmp_path / "q-batch-observation.json").write_bytes(canonical_json_bytes({
        "scope": scope, "family": family, "native_calls": native_calls,
        "original_coalesced_task_count": 4, "first_audit_count": 4, "normal_native_calls": 0,
        "rich_original_IBS_consumer": True, "native_leaf": "UNFITTED", "actual_model_fits": 0}))


@pytest.mark.parametrize("resource", ["memory", "scratch"])
def test_q_batch_admission_reserves_whole_assignment_before_start(tmp_path, monkeypatch, resource):
    from padml import f5, runtime
    root = tmp_path / "q"
    (root / "native").mkdir(parents=True)
    (root / "input.json").write_bytes(b"{}")
    policy = {"configured_worker_ceiling": runtime.CPU_MINUS_8, "memory_bytes_per_worker": 3,
        "scratch_bytes_per_worker": 7, "memory_reserve_bytes": 11, "scratch_reserve_bytes": 13,
        "transfer_archive_worker_ceiling": 24}
    effective = f5._q_batch_resource_policy(policy, 2, 5, 100)
    assert effective["memory_bytes_per_worker"] == 3203
    assert effective["scratch_reserve_bytes"] == 13 + 500 + 32 * 1024**2
    assert effective["memory_reserve_bytes"] == 11 + 128 + 32 * 16 * 1024**2
    observation = {"effective_cpus": 32, "available_memory_bytes": 10**10,
        "scratch_available_bytes": 10**10, "scratch_root": str(root)}
    key = "available_memory_bytes" if resource == "memory" else "scratch_available_bytes"
    prefix = "memory" if resource == "memory" else "scratch"
    observation[key] = effective[prefix + "_reserve_bytes"] + effective[prefix + "_bytes_per_worker"] - 1
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda _: observation)
    options = {"prepare_only": False, "task_ids": [f"UNIT_{i}" for i in range(5)], "batch_root": tmp_path / "batch",
               "q_batches": None, "retained_bytes_per_task": 100}
    control = f5._q_search_batch_control(root, policy, options)
    spec = {"native_search_batch": control, "native_search_root": str(root / "native")}
    items = [{"task_id": name} for name in options["task_ids"]]
    monkeypatch.setattr(f5, "_bounded_ordered_spawn", lambda *a, **k: pytest.fail("ADMISSION_MUST_PRECEDE_ANY_WORKER"))
    with pytest.raises(ContractError):
        f5._q_search_task_batch(spec, f2_kernel._run_xgb_refit_pool_task, items)
    assert not options["batch_root"].exists() and not (root / "batch-work").exists()
    observation[key] += 1
    assert runtime.resource_admission(effective, observation, legal_tasks=5)["admitted_worker_ceiling"] == 1


def test_q_batch_failure_retains_confirmed_audits_without_claiming_fit_total(tmp_path, monkeypatch):
    from padml import f5, runtime
    root = tmp_path / "q"
    (root / "native").mkdir(parents=True)
    (root / "input.json").write_bytes(b"{}")
    policy = {"configured_worker_ceiling": runtime.CPU_MINUS_8, "memory_bytes_per_worker": 1,
        "scratch_bytes_per_worker": 1, "memory_reserve_bytes": 0, "scratch_reserve_bytes": 0,
        "transfer_archive_worker_ceiling": 24}
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda _: {
        "effective_cpus": 32, "available_memory_bytes": 10**10, "scratch_available_bytes": 10**10, "scratch_root": str(root)})
    options = {"prepare_only": False, "task_ids": ["UNIT_1", "UNIT_2"], "batch_root": tmp_path / "batch",
               "q_batches": None, "retained_bytes_per_task": 100}
    control = f5._q_search_batch_control(root, policy, options)
    spec = {"native_search_batch": control, "native_search_root": str(root / "native")}
    def failure(function, jobs, *, selected_slots, execution_report, on_result):
        Path(jobs[1]["work"]).mkdir(parents=True)
        on_result(0, {"task_id": "UNIT_1", "first_native_audit_count": 1, "UNFITTED_CALLBACK": True})
        execution_report["status"] = "FAILED"
        raise RuntimeError("UNFITTED_SECOND_UNIT_INTERRUPTED_AFTER_START")
    monkeypatch.setattr(f5, "_bounded_ordered_spawn", failure)
    with pytest.raises(RuntimeError, match="SECOND_UNIT_INTERRUPTED"):
        f5._q_search_task_batch(spec, f2_kernel._run_xgb_refit_pool_task,
                              [{"task_id": name, "spec": spec} for name in options["task_ids"]])
    execution = json.loads((options["batch_root"] / "execution.json").read_bytes())
    assert execution["new_model_fit_count"] is None and execution["confirmed_first_native_audit_count"] == 1
    assert len(execution["units"]) == 1 and (root / "batch-work/UNIT_2").is_dir()


@pytest.mark.parametrize("action", ["full0-prepare", "full0-worker", "full0-gather", "aar-prepare", "aar-worker", "aar-final"])
def test_q_original_cli_forwards_partial_and_complete_search_modes(tmp_path, monkeypatch, capsys, action):
    import sys
    from padml import f5, f5_sensitivity as sensitivity, nested_loco as nested
    calls = []
    def owner(*args, **kwargs):
        calls.append((args, kwargs))
        return {"UNFITTED_CLI_FORWARDING": True}
    monkeypatch.setattr(f5, "execute_final_complex_search", owner)
    monkeypatch.setattr(sensitivity, "execute_a12_outer_bundle", owner)
    if action.startswith("full0"):
        argv = ["complex-search", "--full-development", str(tmp_path / "development.json"),
                "--candidate-family", "XGBOOST_COX", "--target", str(tmp_path / "q.zip")]
    else:
        argv = ["a12-outer", str(tmp_path / "mice.zip"), str(tmp_path / "q"),
                "--input-bundle", str(tmp_path / "inputs.zip")]
        if action != "aar-final":
            argv += ["--search-only", "--search-branch", nested.A12_TOTAL_AAR]
    if action.endswith("prepare"):
        argv += ["--prepare-only"]
    elif action.endswith("worker"):
        argv += ["--task-ids", "UNIT_1", "UNIT_2", "--batch-root", str(tmp_path / "batch"),
                 "--retained-bytes-per-task", "123456", "--q-batches", str(tmp_path / "prior")]
    elif action.endswith("gather"):
        argv += ["--q-batches", str(tmp_path / "batch1"), str(tmp_path / "batch2")]
    else:
        argv += ["--q-roots", *[str(tmp_path / f"q-{i}") for i in range(3)],
                 "--selector-root", str(tmp_path / "selector"), "--retained-bytes-per-component", "234567"]
    monkeypatch.setattr(sys, "argv", ["padml-f5", *argv])
    f5.main()
    assert len(calls) == 1 and json.loads(capsys.readouterr().out)["UNFITTED_CLI_FORWARDING"]
    kwargs = calls[0][1]
    if action.endswith("prepare"):
        assert kwargs["prepare_only"] is True
    elif action.endswith("worker"):
        assert kwargs["task_ids"] == ["UNIT_1", "UNIT_2"] and kwargs["retained_bytes_per_task"] == 123456
        assert kwargs["q_batches"] == [tmp_path / "prior"] and kwargs["batch_root"] == tmp_path / "batch"
    elif action.endswith("gather"):
        assert kwargs["q_batches"] == [tmp_path / "batch1", tmp_path / "batch2"]
    else:
        assert kwargs["q_roots"] == dict(zip(nested.AAR_ESTIMANDS, [tmp_path / f"q-{i}" for i in range(3)], strict=True))
    if action in {"aar-prepare", "aar-worker"}:
        assert kwargs["search_only"] is True and kwargs["search_branch"] == nested.A12_TOTAL_AAR


def _q_publish_transported_units(destination, producer, refs, monkeypatch):
    from padml import bundle, f4_compact as compact
    assert not (destination / "numbers.json").exists()
    # Input binding and every transported numeric member are still checked;
    # neither a missing result nor altered input may create a whole-Q index.
    result = destination / "result.json"
    saved_result = result.read_bytes()
    result.unlink()
    with pytest.raises(ContractError, match="Q_MEMBER_INVALID"):
        compact._full_pipeline_q_numerical_members(destination, publish=True, transported_refs=refs)
    result.write_bytes(saved_result)
    source = destination / "input.json"
    original = source.read_bytes()
    source.write_bytes(original + b" ")
    with pytest.raises(ContractError, match="Q_VALUE_BYTES_MISMATCH"):
        compact._full_pipeline_q_numerical_members(destination, publish=True, transported_refs=refs)
    source.write_bytes(original)
    original_sha = bundle.sha256_file
    def no_native_hash(path):
        assert path.suffix != ".rds" and path.name not in {"model.bin", "baseline.bin", "function.ubj", "checkpoints.pt"}
        return original_sha(path)
    with monkeypatch.context() as patch:
        patch.setattr(bundle, "sha256_file", no_native_hash)
        compact._full_pipeline_q_numerical_members(destination, publish=True, transported_refs=refs)
    assert (destination / "numbers.json").read_bytes() == (producer / "numbers.json").read_bytes()


@pytest.mark.parametrize("scope", ["FULL0", "AAR"])
@pytest.mark.parametrize("family", ["XGBOOST_COX", "COXTIME_SET_A"])
def test_q_python_unit_publication_preserves_original_numeric_consumers(
    aar_source, tmp_path, monkeypatch, family, scope,
):
    test_q_original_python_workers_consume_first_audited_numbers_without_objects(
        aar_source, tmp_path, monkeypatch, family, scope, unit_publication=True)


@pytest.mark.parametrize("scope", ["FULL0", "AAR"])
@pytest.mark.parametrize("family,share", [("XGBOOST_COX", False), ("XGBOOST_COX", True), ("COXTIME_SET_A", False)])
def test_q_python_paired_stop_retains_original_refit_and_native_audit(
    aar_source, tmp_path, monkeypatch, family, share, scope,
):
    test_q_original_python_workers_consume_first_audited_numbers_without_objects(
        aar_source, tmp_path, monkeypatch, family, scope, share_preparation=share,
        unit_publication=True, paired_dispatch=True)


@pytest.mark.parametrize("scope", ["FULL0", "AAR"])
def test_xgb_stop_preparation_preserves_original_three_mode_consumers(aar_source, tmp_path, monkeypatch, scope):
    test_q_original_python_workers_consume_first_audited_numbers_without_objects(
        aar_source, tmp_path, monkeypatch, "XGBOOST_COX", scope, share_preparation=True)


@pytest.mark.parametrize("damage", ["missing", "short", "array", "rehashed_array", "nonfinite", "float_size",
    "source_csv", "response", "registered", "patient_order", "columns", "seed", "parameters", "imputation",
    "unknown_member", "symlink", "consumer_error"])
def test_xgb_stop_preparation_preserves_failed_handoff(aar_source, tmp_path, monkeypatch, damage):
    import copy
    import numpy as np
    import xgboost as xgb
    from padml.bundle import sha256_file
    task, loaded, _, _ = _xgb_preparation_unit(aar_source, tmp_path, "FULL0")
    Path(task["spec"]["native_search_root"]).mkdir(parents=True)
    monkeypatch.setattr(f2_kernel, "_xgb_prediction_function_seal",
        lambda *args: _unfitted_q_function(task, loaded, args[-1]))
    produced = f2_kernel._run_xgb_function_pool_task(task)
    evaluation = {**copy.deepcopy(task), "function_result": produced, "evaluation_partition": loaded["partition"]}
    path = Path(produced["preparation"]["path"])
    calls = []
    class UnfittedBooster:
        def load_model(self, path):
            calls.append("UNFITTED_NATIVE_OPEN")
    monkeypatch.setattr(xgb, "Booster", UnfittedBooster)
    monkeypatch.setattr(xgb, "DMatrix", lambda matrix, **kwargs: matrix)
    def fail_consumer(*args, **kwargs):
        calls.append("UNFITTED_EVALUATOR_FAILURE")
        raise ContractError("UNFITTED_EVALUATOR_FAILURE")
    monkeypatch.setattr(f2_kernel, "_evaluate_grouped_cox_risk_curve", fail_consumer)
    def forbidden(*args, **kwargs):
        pytest.fail("EVALUATOR_MUST_NOT_REPARSE_OR_REFIT")
    monkeypatch.setattr(f2_kernel, "_load_python_registered_partition", forbidden)
    monkeypatch.setattr(f2_kernel, "_xgb_prediction_function_seal", forbidden)
    if damage == "missing":
        path.rename(path.with_name("retained-missing.bin"))
    elif damage == "short":
        path.write_bytes(path.read_bytes()[:-1])
    elif damage in {"array", "rehashed_array", "nonfinite"}:
        raw = bytearray(path.read_bytes())
        raw[:8] = np.asarray([float("nan") if damage == "nonfinite" else 41.], dtype="<f8").tobytes()
        path.write_bytes(raw)
        if damage != "array":
            produced["preparation"]["sha256"] = sha256_file(path)
    elif damage == "source_csv":
        source = Path(task["registered"]["partitions"][0]["covariates"]["input_dir"]) / "imp01.csv"
        original = source.read_bytes()
        changed = original.replace(b",40,", b",41,", 1)
        assert changed != original and len(changed) == len(original)
        source.write_bytes(changed)
    elif damage == "float_size":
        produced["preparation"]["size_bytes"] = float(produced["preparation"]["size_bytes"])
    elif damage == "response":
        source = Path(task["registered"]["partitions"][0]["fit_response"]["path"])
        original = source.read_bytes()
        source.write_bytes(original + b"\n")
    elif damage == "registered":
        evaluation["registered"]["identity"] = "d" * 64
    elif damage == "patient_order":
        evaluation["registered"]["partitions"][0]["fit_ids"].reverse()
    elif damage == "columns":
        evaluation["spec"]["selector_from_dependency"]["selected_parents"] = ["Age"]
    elif damage == "seed":
        evaluation["seed"] += 1
    elif damage == "parameters":
        evaluation["parameters"]["max_nrounds"] += 1
    elif damage == "imputation":
        evaluation["imputation"] = produced["imputation"] = 2
    elif damage == "unknown_member":
        path.with_name("unknown.txt").write_bytes(b"RETAIN UNKNOWN")
    elif damage == "symlink":
        target = tmp_path / "retained-original.bin"
        path.rename(target)
        path.symlink_to(target)
    produced["task_identity_sha256"] = f2_kernel._sha({k: v for k, v in produced.items() if k != "task_identity_sha256"})
    original_members = {p.name: p.read_bytes() for p in path.parent.iterdir() if p.is_file()}
    with pytest.raises(ContractError):
        f2_kernel._run_xgb_function_evaluator_pool_task(evaluation)
    assert {p.name: p.read_bytes() for p in path.parent.iterdir() if p.is_file()} == original_members
    assert calls == (["UNFITTED_NATIVE_OPEN", "UNFITTED_EVALUATOR_FAILURE"] if damage == "consumer_error" else [])
    (tmp_path / "preparation-failure.json").write_bytes(canonical_json_bytes({
        "damage": damage, "all_failure_handoff_bytes_retained": True, "evaluator_csv_reads": 0, "actual_model_fits": 0}))


@pytest.mark.parametrize("scope", ["FULL0", "AAR"])
def test_xgb_stop_preparation_reserves_whole_stage_before_fit(aar_source, tmp_path, monkeypatch, scope):
    import copy
    from padml import runtime
    task, _, _, _ = _xgb_preparation_unit(aar_source, tmp_path, scope)
    spec = task["spec"]
    policy = {"configured_worker_ceiling": runtime.CPU_MINUS_8, "memory_bytes_per_worker": 1,
        "scratch_bytes_per_worker": 100, "memory_reserve_bytes": 20, "scratch_reserve_bytes": 30,
        "transfer_archive_worker_ceiling": 24}
    spec.update(xgb_preparation_policy=policy, pool_workers=24, engine_threads=1)
    tasks = [copy.deepcopy(task), copy.deepcopy(task)]
    tasks[1]["task_id"] = "S1_T002_P01_M01_FUNCTION"
    _, _, layout = f2_kernel._xgb_stop_preparation_layout(task)
    import math
    size = sum(8 * math.prod(shape) for _, shape in layout)
    observation = {"effective_cpus": 32, "available_memory_bytes": 20 + 1 + 32 * size,
        "scratch_available_bytes": 30 + 2 * size + 100, "scratch_root": str(tmp_path)}
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda root: dict(observation))
    def forbidden(*args, **kwargs):
        pytest.fail("ADMISSION_BEFORE_CSV_AND_FIT")
    monkeypatch.setattr(f2_kernel, "_load_python_registered_partition", forbidden)
    monkeypatch.setattr(f2_kernel, "_run_xgb_function_pool_task", forbidden)
    expected = f2_kernel._xgb_stop_preparation_batch_spec(spec, tasks, tmp_path)
    assert expected["active_worker_limit"] == 1 and expected["pool_workers"] == 24
    calls = []
    monkeypatch.setattr(f2_kernel, "_bounded_ordered_spawn", lambda function, jobs, *, selected_slots:
        calls.append(selected_slots) or ["UNFITTED"] * len(jobs))
    for replay in (False, True):
        spec.update(native_search_replay=replay, replay_pool_workers=24)
        expected = f2_kernel._xgb_stop_preparation_batch_spec(spec, tasks, tmp_path)
        assert f2_kernel._search_task_batch(expected, forbidden, tasks, selected_slots=24) == ["UNFITTED"] * 2
    assert calls == [1, 1]
    for field in ("available_memory_bytes", "scratch_available_bytes"):
        observation[field] -= 1
        with pytest.raises(ContractError, match="RESOURCE_ADMISSION_ZERO"):
            f2_kernel._xgb_stop_preparation_batch_spec(spec, tasks, tmp_path)
        observation[field] += 1
    assert not list(tmp_path.rglob("preparation.bin"))


@pytest.mark.parametrize("scope", ["FULL0", "AAR"])
def test_xgb_preparation_combines_original_q_read_reserves(aar_source, tmp_path, monkeypatch, scope):
    import math
    from padml import f4_compact as compact, runtime
    task, _, _, _ = _xgb_preparation_unit(aar_source, tmp_path, scope)
    root = tmp_path / "q"
    (root / "native/FUNCTION").mkdir(parents=True)
    for name in ("input.json", "result.json"):
        (root / name).write_bytes(b"{}")
    (root / "native/FUNCTION/function.ubj").write_bytes(b"UNFITTED" * 1024)
    (root / "native/FUNCTION/evaluation.json").write_bytes(b"{}")
    policy = {"configured_worker_ceiling": runtime.CPU_MINUS_8, "memory_bytes_per_worker": 100,
        "scratch_bytes_per_worker": 100, "memory_reserve_bytes": 20, "scratch_reserve_bytes": 30,
        "transfer_archive_worker_ceiling": 24}
    observed = {"effective_cpus": 32, "available_memory_bytes": 10**10,
        "scratch_available_bytes": 10**10, "scratch_root": str(root)}
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda path: dict(observed))
    admission = compact._full_pipeline_q_read_admission(root, policy, native_audit=True)
    effective = admission["effective_policy"]
    assert effective["scratch_reserve_bytes"] > policy["scratch_reserve_bytes"]
    task["spec"].update(xgb_preparation_policy=effective, pool_workers=24, native_search_replay=True, replay_pool_workers=24)
    size = sum(8 * math.prod(shape) for _, shape in f2_kernel._xgb_stop_preparation_layout(task)[2])
    observed.update(available_memory_bytes=effective["memory_reserve_bytes"] + effective["memory_bytes_per_worker"] + 32 * size,
                    scratch_available_bytes=effective["scratch_reserve_bytes"] + size + effective["scratch_bytes_per_worker"])
    assert f2_kernel._xgb_stop_preparation_batch_spec(task["spec"], [task], root)["active_worker_limit"] == 1
    observed["scratch_available_bytes"] -= 1
    # The old separately admitted reservations both fit; their true sum does not.
    assert runtime.resource_admission(effective, observed, legal_tasks=1)["admitted_worker_ceiling"] == 1
    separate = {**policy, "scratch_reserve_bytes": policy["scratch_reserve_bytes"] + size}
    assert runtime.resource_admission(separate, observed, legal_tasks=1)["admitted_worker_ceiling"] == 1
    with pytest.raises(ContractError, match="RESOURCE_ADMISSION_ZERO"):
        f2_kernel._xgb_stop_preparation_batch_spec(task["spec"], [task], root)

@pytest.mark.parametrize("scope", ["FULL0", "AAR"])
@pytest.mark.parametrize("family", ["RSF", "GBM_COX"])
def test_q_r_numeric_batch_retains_all_original_risks_and_each_native_reference(
    aar_source, tmp_path, monkeypatch, family, scope, unit_publication=False,
):
    import copy
    from padml import f4_compact as compact
    task, _, policy = _q_numbers_python_unit(aar_source, tmp_path, family, scope)
    q = Path(task["spec"]["native_search_root"]).parent
    (q / "native").mkdir(parents=True)
    spec = {**task["spec"], "action": "MODEL_PREDICTION_BATCH",
        "registered_partitions": {"partitions": [{"covariates": {"input_dir": "/UNFITTED/input",
            "data_identity": "b" * 64}, "fit_response": {"path": "/UNFITTED/response", "sha256": "c" * 64}}]},
        "producer_tasks": [{"task_id": "S1_T001_P01_M01", "family": family, "model_seed": task["seed"],
            "producer_kind": "SURVIVAL"}]}
    (q / "input.json").write_bytes(canonical_json_bytes({"spec": spec, "UNFITTED": True}))
    calls, outputs = [], []
    def native(command, **kwargs):
        current = json.loads(Path(command[-1]).read_bytes())
        calls.append(current["native_search_replay"])
        kwargs["stdout"].write(b"UNFITTED original R transport\n")
        unit = current["producer_tasks"][0]
        owned = Path(current["native_search_root"]) / unit["task_id"]
        names = ["model.rds"] + (["baseline.rds"] if family == "GBM_COX" and unit["producer_kind"] == "SURVIVAL" else [])
        if not current["native_search_replay"]:
            owned.mkdir()
        for name in names:
            raw = ("UNFITTED:" + unit["task_id"] + ":" + name).encode()
            if current["native_search_replay"]:
                assert (owned / name).read_bytes() == raw
            else:
                (owned / name).write_bytes(raw)
        work = Path(current["output_path"]).parent
        result = {"UNFITTED": True, "task_id": unit["task_id"]}
        if family == "GBM_COX" and unit["producer_kind"] == "GBM_STOP_CURVE":
            channel = {"schema_version": "1.0.0", "kind": "PADML_F2_OPERATION_LOCAL_RISK_MATRIX_CHANNEL"}
            for role, values in (("fit", [1.0, 2.0]), ("evaluation", [3.0, 4.0])):
                raw = struct.pack("<dd", *values)
                name = f"risk-001-gbm-{role}.bin"
                (work / name).write_bytes(raw)
                channel[role] = {"schema_version": "1.0.0", "kind": "PADML_F2_OPERATION_LOCAL_RISK_MATRIX",
                    "encoding": "IEEE754_FLOAT64", "byte_order": "LITTLE_ENDIAN", "row_order": "ROW_MAJOR",
                    "file_name": name, "rows": 1, "columns": 2, "size_bytes": len(raw), "sha256": sha256_bytes(raw)}
            result["risk_channel"] = channel
        Path(current["output_path"]).write_bytes(canonical_json_bytes(result))
        return SimpleNamespace(returncode=0)
    monkeypatch.setattr(f4.subprocess, "run", native)
    specs = []
    for index in (1, 2):
        unit = {**spec["producer_tasks"][0], "task_id": f"S1_T{index:03d}_P01_M01"}
        if family == "GBM_COX" and index == 2:
            unit["producer_kind"] = "GBM_STOP_CURVE"
        specific = {**spec, "producer_tasks": [unit]}
        specs.append(specific)
        values = []
        for replay in (False, True):
            work = tmp_path / f"native-{index}-{replay}"
            work.mkdir()
            current = {**specific, "native_search_replay": replay, "output_path": str(work / "output.json")}
            (work / "spec.json").write_bytes(canonical_json_bytes(current))
            values.append(f4._run_full_pipeline_r_search_batch(work / "spec.json", work / "output.json", tmp_path, {}))
        assert values[0] == values[1]
        outputs.append(values[0])
    unit_refs = (_q_publish_units_before_result(q, [
        ("batch-" + sha256_bytes(canonical_json_bytes([item["task_id"] for item in specific["producer_tasks"]]))[:24],
         *[item["task_id"] for item in specific["producer_tasks"]]) for specific in specs]) if unit_publication else None)
    (q / "result.json").write_bytes(canonical_json_bytes(outputs))
    compact._full_pipeline_q_read_admission(q, policy, native_audit=True)
    projection, original_refs = compact._full_pipeline_q_numerical_members(q, publish=True, transported_refs=unit_refs)
    destination = tmp_path / "numbers-only"
    destination.mkdir()
    for name, path in projection.items():
        if unit_publication and name == "numbers.json":
            continue
        target = destination / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, target)
    assert not list(destination.rglob("*.rds"))
    if unit_publication:
        _q_publish_transported_units(destination, q, unit_refs, monkeypatch)
        # Retain one complete coordinate locally, not one half of a GBM pair.
        coordinate = specs[1]["producer_tasks"][0]["task_id"]
        shutil.copyfile(q / "native" / coordinate / "model.rds", destination / "native" / coordinate / "model.rds")
    compact._full_pipeline_q_numerical_members(destination)
    original_calls = list(calls)
    monkeypatch.setattr(f4.subprocess, "run", lambda *a, **k: pytest.fail("R_FORBIDDEN_IN_NORMAL_Q"))
    def consume(root, specific, label):
        work = tmp_path / label
        work.mkdir()
        current = {**specific, "native_search_root": str(root / "native"), "native_search_replay": True,
                   "native_search_numbers": True, "output_path": str(work / "output.json")}
        (work / "spec.json").write_bytes(canonical_json_bytes(current))
        result = f4._run_full_pipeline_r_search_batch(work / "spec.json", work / "output.json", tmp_path, {})
        if "risk_channel" in result:
            assert f2_kernel._consume_operation_local_risk_channel(result["risk_channel"], work,
                expected_prefix="risk-001-gbm", fit_rows=1, evaluation_rows=1, columns=2) == (
                    [[1.0, 2.0]], [[3.0, 4.0]])
        return result
    for index, specific in enumerate(specs):
        assert consume(destination, specific, f"numbers-{index}") == outputs[index]
    if unit_publication and family == "GBM_COX":
        coordinate = specs[0]["producer_tasks"][0]["task_id"]
        path = destination / "native" / coordinate / "model.rds"
        shutil.copyfile(q / "native" / coordinate / "model.rds", path)
        with pytest.raises(ContractError, match="Q_MEMBER_SET_INVALID"):
            compact._full_pipeline_q_numerical_members(destination)
        with pytest.raises(ContractError, match="Q_MEMBER_SET_INVALID"):
            consume(destination, specs[0], "partial-model-pair")
        path.unlink()
    rejected = []
    for damage in (["missing_nonwinner", "missing_baseline"] if family == "GBM_COX" else ["missing_nonwinner"]):
        bad = tmp_path / damage
        shutil.copytree(destination, bad)
        index = json.loads((bad / "numbers.json").read_bytes())
        coordinate = specs[0]["producer_tasks"][0]["task_id"]
        leaf_path = bad / "native" / coordinate / "object-audit.json"
        if damage == "missing_nonwinner":
            for name in [name for name in index["members"] if name.startswith(f"native/{coordinate}/")]:
                del index["members"][name]
            leaf_path.unlink()
            leaf_path.parent.rmdir()
        else:
            del index["members"][f"native/{coordinate}/baseline.rds"]
            leaf = json.loads(leaf_path.read_bytes())
            del leaf["baseline.rds"]
            leaf_path.write_bytes(canonical_json_bytes(leaf))
        index["identity_sha256"] = f2_kernel._sha({key: value for key, value in index.items() if key != "identity_sha256"})
        (bad / "numbers.json").write_bytes(canonical_json_bytes(index))
        compact._full_pipeline_q_numerical_members(bad)
        with pytest.raises(ContractError, match="NATIVE_REFERENCE"):
            consume(bad, specs[0], damage + "-consumer")
        rejected.append(damage)
    bad_spec = copy.deepcopy(specs[0])
    bad_spec["producer_tasks"][0]["model_seed"] += 1
    with pytest.raises(ContractError, match="Q_R_SPEC_MISMATCH"):
        consume(destination, bad_spec, "bad-seed-consumer")
    assert calls == original_calls == [False, True, False, True]
    (tmp_path / "q-numeric-observation.json").write_bytes(canonical_json_bytes({
        "scope": scope, "family": family, "native_calls": calls, "normal_native_calls": 0,
        "rejected": rejected + ["seed"], "actual_model_fits": 0, "actual_mice_chains": 0,
        "native_leaf": "UNFITTED", "native_reference_count": len(original_refs),
        "unit_publication": unit_publication}))


@pytest.mark.parametrize("scope", ["FULL0", "AAR"])
@pytest.mark.parametrize("family", ["RSF", "GBM_COX"])
def test_q_r_unit_publication_preserves_original_numeric_consumers(
    aar_source, tmp_path, monkeypatch, family, scope,
):
    test_q_r_numeric_batch_retains_all_original_risks_and_each_native_reference(
        aar_source, tmp_path, monkeypatch, family, scope, unit_publication=True)


@pytest.mark.parametrize("units", [(), ("../UNIT",), ("/UNIT",), ("UNIT", "UNIT"), ["UNIT"],
                                  ("MISSING",), ("LINK",), ("UNIT/file",)])
def test_q_unit_publication_rejects_invalid_scope_before_writing(tmp_path, units):
    from padml import f4_compact as compact
    root = tmp_path / "q"
    (root / "native/UNIT").mkdir(parents=True)
    (root / "input.json").write_bytes(b"{}")
    (root / "native/UNIT/model.rds").write_bytes(b"UNFITTED")
    (root / "native/LINK").symlink_to(root / "native/UNIT", target_is_directory=True)
    with pytest.raises(ContractError, match="Q_UNIT_SET_INVALID"):
        compact._full_pipeline_q_numerical_members(root, publish=True, native_units=units)
    assert not (root / "native/UNIT/object-audit.json").exists() and not (root / "numbers.json").exists()


@pytest.mark.parametrize("family", ["XGBOOST_COX", "COXTIME_SET_A"])
@pytest.mark.parametrize("nested", [False, True])
@pytest.mark.parametrize("scope", ["FULL0", "AAR"])
def test_q_stop_pair_batch_preserves_barrier_and_non_nested_dispatch(monkeypatch, family, nested, scope):
    from padml import runtime
    spec = {"family": family, "execution_scope": "F5_FULL_DEVELOPMENT_SEARCH",
            "final_search_source": {"program_id": "PADML_NESTED_LOCO_20260908" if nested else "LEGACY"}}
    if scope == "AAR":
        spec["execution_scope"] = "F5_A12_SEARCH"
        spec["a12_source"] = {"source": {"kind": "PADML_F5_A12_PROJECTED_OUTER_INPUTS_V1"} if nested else "LEGACY"}
    tasks = [{"task_id": f"FUNCTION_{i}", "partition_id": f"STOP_{i}", "spec": spec} for i in range(3)]
    partitions = [{"partition_id": task["partition_id"], "evaluation_response": {"UNFITTED": True}} for task in tasks]
    events = []
    def function(task):
        assert not f2_kernel._contains_key(task, "evaluation_response")
        events.append(("FUNCTION", task["task_id"]))
        return {"task_id": task["task_id"]}
    def evaluator(task):
        assert task["function_result"]["task_id"] == task["task_id"]
        assert task["evaluation_partition"]["partition_id"] == task["partition_id"]
        events.append(("EVALUATOR", task["task_id"]))
        return task["task_id"]
    for name in ("_run_xgb_function_pool_task", "_run_coxtime_function_pool_task"):
        monkeypatch.setattr(f2_kernel, name, function)
    for name in ("_run_xgb_function_evaluator_pool_task", "_run_coxtime_function_evaluator_pool_task"):
        monkeypatch.setattr(f2_kernel, name, evaluator)
    monkeypatch.setattr(runtime, "resolve_pool_workers", lambda value: 24)
    monkeypatch.setattr(f2_kernel, "_bounded_ordered_spawn",
                        lambda function, items, **kwargs: [function(item) for item in items])
    for replay in (False, True):
        spec["native_search_replay"] = replay
        events.clear()
        assert f2_kernel._search_python_stop_batch(spec, tasks, partitions, selected_slots=24) == [t["task_id"] for t in tasks]
        expected = ([(role, task["task_id"]) for task in tasks for role in ("FUNCTION", "EVALUATOR")] if nested else
                    [(role, task["task_id"]) for role in ("FUNCTION", "EVALUATOR") for task in tasks])
        assert events == expected
    events.clear()
    with pytest.raises(ContractError, match="STOP_PAIR_TASK_INVALID"):
        f2_kernel._search_python_stop_batch(spec, tasks, partitions[:-1], selected_slots=24)
    assert events == []


@pytest.mark.parametrize("family", ["RSF", "GBM_COX", "XGBOOST_COX", "COXTIME_SET_A"])
def test_q_aar_archive_member_owner_transports_numbers_for_each_branch(tmp_path, monkeypatch, family):
    """Exercise original member assembly; selector and model leaves are UNFITTED."""
    from padml import f5, f5_sensitivity as sensitivity, f4_compact as compact, nested_loco as nested
    from padml.bundle import read_safe_zip, write_deterministic_zip
    root = tmp_path / "outer"
    selector = root / "development/selector"
    selector.mkdir(parents=True)
    for path in (root / "development/development.json", selector / "development-input.json"):
        path.write_bytes(b'{"UNFITTED_SELECTOR":true}')
    input_archive = tmp_path / "UNFITTED-input.zip"
    input_archive.write_bytes(b"UNFITTED_UPSTREAM_BOUNDARY")
    monkeypatch.setattr(f5, "_nested_selector_numerical_members", lambda path: {
        "development-input.json": path / "development-input.json"})
    prepared = {"source": {"kind": "PADML_F5_A12_PROJECTED_OUTER_INPUTS_V1"}}
    expected = {}
    for branch in nested.AAR_ESTIMANDS:
        q = root / "search" / branch
        (q / "native").mkdir(parents=True)
        for name in ("input.json", "result.json"):
            (q / name).write_bytes(canonical_json_bytes({"UNFITTED": True, "branch": branch}))
        model = q / "native" / ("model.rds" if family in {"RSF", "GBM_COX"} else "model.bin")
        model.write_bytes(b"UNFITTED_MEMBER_ASSEMBLY_OBJECT")
        (q / "native/output.json").write_bytes(b'{"UNFITTED_NUMBERS":true}')
        projection, _ = compact._full_pipeline_q_numerical_members(q, publish=True)
        expected.update({f"search/{branch}/{name}": path.read_bytes() for name, path in projection.items()})
    members = sensitivity._a12_outer_retained_members(root, family, 1, input_archive,
                                                      prepared=prepared, before_final=True)
    assert {name for name in members if name.startswith("search/")} == set(expected)
    assert not any(name.endswith((".rds", "model.bin")) for name in members)
    archive = tmp_path / "numeric-transport.zip"
    write_deterministic_zip(archive, members)
    actual = read_safe_zip(archive)
    assert {name: raw for name, raw in actual.items() if name.startswith("search/")} == expected
    for branch in nested.AAR_ESTIMANDS:
        assert (root / "search" / branch / "native" / model.name).is_file()


def test_q_first_audit_reserves_whole_retained_tree_and_index_before_replay(
    aar_source, tmp_path, monkeypatch,
):
    from padml import f4_compact as compact, runtime
    root = tmp_path / "q"
    (root / "native" / "FUNCTION").mkdir(parents=True)
    for name in ("input.json", "result.json"):
        (root / name).write_bytes(b"{}")
    (root / "native/FUNCTION/checkpoints.pt").write_bytes(b"UNFITTED" * 1024)
    (root / "native/FUNCTION/evaluation.json").write_bytes(b"{}")
    observed = {"effective_cpus": 32, "available_memory_bytes": 10**10,
                "scratch_available_bytes": 10**10, "scratch_root": str(root)}
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda path: dict(observed))
    result = compact._full_pipeline_q_read_admission(root, aar_source[4], native_audit=True)
    assert result["admitted_worker_ceiling"] == 24
    memory_reserve = 64 * 4 + 32 * 16 * 1024**2
    scratch_reserve = 2 * (8192 + 2) + 2 * 4 + 2 * 16 * 1024**2 + 8192 * 20000
    assert result["memory_usable_bytes"] == observed["available_memory_bytes"] - memory_reserve
    assert result["scratch_usable_bytes"] == observed["scratch_available_bytes"] - scratch_reserve
    with pytest.raises(ContractError, match="Q_NUMBERS_REQUIRED"):
        compact._full_pipeline_q_read_admission(root, aar_source[4], native_audit=False)
    for field in ("available_memory_bytes", "scratch_available_bytes"):
        changed = {**observed, field: memory_reserve if field == "available_memory_bytes" else scratch_reserve}
        monkeypatch.setattr(runtime, "observe_execution_resources", lambda path: changed)
        with pytest.raises(ContractError, match="RESOURCE_ADMISSION_ZERO"):
            compact._full_pipeline_q_read_admission(root, aar_source[4], native_audit=True)

_PURE_R = r'''
args <- commandArgs(trailingOnly=TRUE)
e <- new.env(parent=baseenv())
extract <- function(path, wanted) {
  found <- character()
  for (item in parse(path)) {
    if (is.call(item) && identical(item[[1L]], as.name("<-")) && length(item) == 3L &&
        is.symbol(item[[2L]]) && as.character(item[[2L]]) %in% wanted &&
        is.call(item[[3L]]) && identical(item[[3L]][[1L]], as.name("function"))) {
      eval(item, envir=e); found <- c(found, as.character(item[[2L]]))
    }
  }
  stopifnot(setequal(found, wanted))
}
extract(args[[1L]], c("fit_predict", "gbm_stop_curve", "validate_a12_search_source", "load_partition"))
extract(args[[2L]], c("gbm_stop_native_function", "full_pipeline_q_native_prefix",
                     "full_pipeline_q_refit_function", "full_pipeline_q_program"))
branch <- function(fun, family) {
  code <- as.list(body(fun))
  condition <- substitute(family == FAMILY, list(FAMILY=family))
  index <- which(vapply(code, function(x) is.call(x) && identical(x[[1L]], as.name("if")) &&
                        identical(x[[2L]], condition), logical(1)))
  stopifnot(length(index) == 1L)
  code[[index]][[3L]]
}
has_fit <- function(node, family) {
  if (!is.call(node)) return(FALSE)
  direct <- if (family == "RSF")
    identical(node[[1L]], as.name("do.call")) && length(node) >= 2L && identical(node[[2L]], as.name("ranger"))
  else identical(node[[1L]], as.name("gbm.fit"))
  direct || any(vapply(as.list(node), has_fit, logical(1), family=family))
}
for (family in c("RSF", "GBM_COX")) {
  fresh <- e$full_pipeline_q_refit_function(e$fit_predict, family, FALSE)
  replay <- e$full_pipeline_q_refit_function(e$fit_predict, family, TRUE)
  stopifnot(has_fit(branch(fresh, family),family),
            !has_fit(branch(replay, family),family),
            !("set.seed" %in% all.names(branch(replay, family))))
}
stop_replay <- e$gbm_stop_native_function(e$gbm_stop_curve, TRUE)
stopifnot(!any(c("gbm.fit", "set.seed") %in% all.names(body(stop_replay))))
e$need <- function(ok, message) {if (!isTRUE(ok)) stop(message, call.=FALSE)}
e$scalar <- identity
e$subject <- eval(quote(function() {
  list(task=task, model_path=model_path, baseline_path=baseline_path,
       has_retained=exists("retained", inherits=FALSE))
}), e)
run <- function(task, fun) fun()
base <- args[[3L]]
dir.create(base)
e$a12_search <- TRUE
e$imputation_count <- 1L
e$required_imputations <- 1L
e$read.csv <- utils::read.csv
e$read_response <- function(record) data.frame(Patient_ID="a")
e$sha_object <- function(value) "UNFITTED_SHA"
e$prepare_frame <- function(data, a12, a12_total) {
  stopifnot(a12, identical(a12_total, e$expected_total))
  data
}
utils::write.csv(data.frame(Patient_ID=c("a","b")), file.path(base,"imp01.csv"), row.names=FALSE)
partition_record <- list(kind="INNER", partition_id="p", covariates=list(input_dir=base),
  application_ids=list("a","b"), fit_ids=list("a"), evaluation_ids=list("b"),
  evaluation_ids_sha256="UNFITTED_SHA", fit_response=list(), inner_fold=1L)
partition_record[["repeat"]] <- 1L
for (label in c("WITHOUT_AST_ALT_DIRECT", "WITHOUT_AST_ALT_TOTAL", "A12_WITHOUT_AST_ALT_DIRECT",
                "A12_WITHOUT_AST_ALT_TOTAL", "OUTER_SELECTED_FAMILY_NO_AAR_REDEVELOPMENT")) {
  projected <- !(label %in% c("WITHOUT_AST_ALT_DIRECT", "WITHOUT_AST_ALT_TOTAL"))
  primary <- list(program_id="PADML_F45_REBUILD_20260925",
    primary_training_context=list(outer_fold=1L), primary_development_lock=list(selected_family="RSF"))
  source <- list(family="RSF", outer_fold=1L, branch=label, inputs_identity_sha256=paste(rep("a",64),collapse=""),
    development_input_sha256=paste(rep("b",64),collapse=""), source=if (projected)
    list(kind="PADML_F5_A12_PROJECTED_OUTER_INPUTS_V1", family="RSF", primary_source=primary) else "UNFITTED_LEGACY")
  e$spec <- list(a12_source=source, fold=1L, family="RSF", registered_partitions=list(branch=label))
  e$validate_a12_search_source(e$spec)
  e$expected_total <- !(label %in% c("WITHOUT_AST_ALT_DIRECT", "A12_WITHOUT_AST_ALT_DIRECT"))
  loaded <- e$load_partition(partition_record)
  stopifnot(identical(loaded$fit_ids,"a"), identical(loaded$evaluation_ids,"b"))
  if (projected) {
    for (damage in c("missing_development", "family", "legacy_label")) {
      bad <- e$spec
      if (damage == "missing_development") bad$a12_source$development_input_sha256 <- NULL
      if (damage == "family") bad$a12_source$source$primary_source$primary_development_lock$selected_family <- "GBM_COX"
      if (damage == "legacy_label") bad$a12_source$branch <- "WITHOUT_AST_ALT_TOTAL"
      stopifnot(inherits(tryCatch({e$validate_a12_search_source(bad); NULL}, error=identity),"error"))
    }
  }
}
for (scope in c("F5_A12_SEARCH", "F4_FULL_PIPELINE_SEARCH", "F2_OUTER_DEVELOPMENT")) {
  name <- if (scope == "F5_A12_SEARCH") "A12" else if (scope == "F2_OUTER_DEVELOPMENT") "PRIMARY" else "F4"
  e$spec <- list(execution_scope=scope, native_search_root=base,
                a12_source=list(family="RSF",outer_fold=3L,branch="WITHOUT_AST_ALT_TOTAL"),
                full_pipeline_source=list(family="RSF",context=0L,bootstrap_replicate=1L),
                primary_search_source=list(family="RSF",outer_fold=3L,channel="PRIMARY",selection_horizon_months=12L),
                seta_lock_sha256="UNFITTED_SET_A", registered_inputs_identity_sha256="UNFITTED_INPUT")
  task <- list(task_id=paste0(name,"_S1_T001_P01_M01"))
  fresh <- run(task, e$full_pipeline_q_native_prefix(e$subject, FALSE, FALSE))
  stopifnot(!fresh$has_retained)
  if (scope == "F5_A12_SEARCH") {
    stopifnot(identical(fresh$task$a12_source,e$spec$a12_source),
              !any(c("full_pipeline_source","seta_lock_sha256") %in% names(fresh$task)))
  } else if (scope == "F2_OUTER_DEVELOPMENT") {
    stopifnot(identical(fresh$task$primary_search_source,e$spec$primary_search_source),
              !any(c("a12_source","full_pipeline_source","seta_lock_sha256") %in% names(fresh$task)))
  } else stopifnot(identical(fresh$task$full_pipeline_source,e$spec$full_pipeline_source),
                   !("a12_source" %in% names(fresh$task)))
  saveRDS(list(fixture="UNFITTED_NATIVE_OBJECT"), fresh$model_path)
  replay <- run(task, e$full_pipeline_q_native_prefix(e$subject, TRUE, FALSE))
  stopifnot(replay$has_retained, identical(fresh$task,replay$task))
}
cat("PASS Q AST and source-bound native prefix; fits=0 RNG=0\n")
'''


def test_a12_q_original_r_ast_replay_and_scoped_native_prefix(tmp_path):
    rscript = shutil.which("Rscript")
    if rscript is None:
        pytest.skip("Rscript unavailable; no fitting is performed by this test")
    package = Path(f2_kernel.__file__).resolve().parent
    script = tmp_path / "q-ast.R"
    script.write_text(_PURE_R, encoding="utf-8")
    process = subprocess.run([rscript, "--vanilla", str(script),
        str(package / "kernels/f2_model_development.R"), str(package / "kernels/f4_gbm_stop.R"), str(tmp_path / "native")],
        capture_output=True, text=True, timeout=30,
        env={**os.environ, "OMP_NUM_THREADS": "1", "OPENBLAS_NUM_THREADS": "1", "MKL_NUM_THREADS": "1"})
    (tmp_path / "r.stdout.log").write_text(process.stdout, encoding="utf-8")
    (tmp_path / "r.stderr.log").write_text(process.stderr, encoding="utf-8")
    assert process.returncode == 0, process.stdout + process.stderr
    assert "fits=0 RNG=0" in process.stdout
