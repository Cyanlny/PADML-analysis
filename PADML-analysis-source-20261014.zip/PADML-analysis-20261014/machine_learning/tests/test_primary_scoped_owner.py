"""Scoped owner engineering seam; real input/compiler/Q checks, zero fits.

The last training boundary is deliberately stopped: fixed900/native numerical
completion is covered separately, not asserted by this carrier test.
"""
import zipfile

import pytest

from padml import f4, nested_loco as nested
from padml.bundle import ContractError, sha256_file, strict_json_bytes
from test_nested_aar_mice import aar_source  # noqa: F401
from test_primary_rsf_score_compilation import (
    test_primary12_public_archive_preserves_q_through_original_input_reader as original_case,
)


def test_scoped_compiler_and_owner_match_original_direct_input(aar_source, tmp_path, monkeypatch):
    original_compile = f4.compile_o_fit_bundle
    prepared = []
    carrier = tmp_path / "pre-search.zip"

    def prepare_carrier(source, target, **kwargs):
        if not prepared:
            prepared.append(True)
            options = {key: kwargs[key] for key in ("outer_fold", "science_decision", "resource_policy",
                "retained_bytes_per_component", "expanded_bytes_per_component", "shared_storage_bytes")}
            original_compile(source, carrier, **options, selection_horizon_months=12, pre_search=True)
        return original_compile(source, target, **kwargs)

    # Existing synthetic accepted-source preparation, not a transport mock.
    with monkeypatch.context() as preparation:
        preparation.setattr(f4, "compile_o_fit_bundle", prepare_carrier)
        original_case(aar_source, tmp_path, preparation, True, None, False)
    expected_input = tmp_path / "input12.zip"
    with zipfile.ZipFile(expected_input) as archive:
        expected = strict_json_bytes(archive.read("o-fit-input.json"))
    with zipfile.ZipFile(carrier) as archive:
        declared = strict_json_bytes(archive.read("o-fit-input.json"))
    parameters = {key: expected[key] for key in ("science_decision", "resource_policy",
        "retained_bytes_per_component", "expanded_bytes_per_component", "shared_storage_bytes")}
    roots = {family: tmp_path / ("UNFITTED-Q-" + family) for family in expected["primary_searches"]}
    parameters.update(search_roots=roots, search_source_bundles={}, pending_searches={})

    def no_custody(*args, **kwargs):
        pytest.fail("scoped compute cannot open complete F1/F2 custody")
    monkeypatch.setattr(f4, "load_f4_inputs", no_custody)
    monkeypatch.setattr(f4, "_load_f4_source_records", no_custody)
    rebound = tmp_path / "rebound.zip"
    # Use None exactly as the original compiler did: this tests byte identity,
    # rather than introducing an empty source-proof field into the reference.
    original_compile(None, rebound, **{key: parameters[key] for key in ("science_decision", "resource_policy",
        "retained_bytes_per_component", "expanded_bytes_per_component", "shared_storage_bytes")},
        outer_fold=1, selection_horizon_months=12, pre_search_input=carrier,
        primary_searches=expected["primary_searches"])
    assert sha256_file(rebound) == sha256_file(expected_input)
    observed = []
    def training_boundary(source, target, **kwargs):
        request = f4._materialize_o_fit_input_bundle(source, tmp_path / "owner-direct-input")
        assert request["primary_searches"] == expected["primary_searches"]
        assert len(request["component_records"]) == 2100 and len(request["post_lock_templates"]) == 140
        observed.append(request)
        return {"UNFITTED_TRAINING_BOUNDARY_NOT_SCIENTIFIC_ACCEPTANCE": True}
    monkeypatch.setattr(f4, "_execute_o_fit_training_bundle", training_boundary)
    result = f4.execute_o_fit_bundle(None, target=tmp_path / "owner-result.zip", input_bundle=carrier,
        outer_fold=1, primary_development=parameters)
    assert result["UNFITTED_TRAINING_BOUNDARY_NOT_SCIENTIFIC_ACCEPTANCE"] and len(observed) == 1
    with pytest.raises(ContractError, match="PRIMARY_DEVELOPMENT_EXECUTION_SCOPE"):
        f4.execute_o_fit_bundle(tmp_path, target=tmp_path / "mixed.zip", input_bundle=carrier,
            outer_fold=1, primary_development=parameters)
