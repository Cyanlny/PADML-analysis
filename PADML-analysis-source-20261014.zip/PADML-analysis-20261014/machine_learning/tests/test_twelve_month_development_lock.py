"""Synthetic seven-family score -> own-line lock contract; no engines or metrics."""
from copy import deepcopy

import pytest

from padml import nested_loco as nested
from padml.bundle import ContractError
from test_nested_loco import _context, _response, _summary
from test_nested_full_development import _unfitted_confirmed_decision


def _science():
    old = _unfitted_confirmed_decision(fixed_bootstrap=True)
    return nested._sealed({**{k: v for k, v in old.items() if k != "identity_sha256"},
        "twelve_month_development": nested._twelve_month_development_contract()})


@pytest.mark.parametrize("outer", [0, 1])
@pytest.mark.parametrize("damage", [None, "mixed_scores", "other_decision", "missing_authority",
                                    "budget", "other_line_lock"])
def test_twelve_month_seven_families_bind_original_lock(outer, damage):
    science = _science()
    context = _context()
    if outer == 0:
        ids = context["training_ids"]
        context = nested.compile_training_context(scope="FULL_DATA", outer_fold=0, heldout_center=None,
            training_ids=ids, heldout_ids=[],
            centers_by_patient={p: context["centers_by_patient"][p] for p in ids},
            training_response_csv=_response(ids), mice_member_set_sha256="a" * 64,
            preprocessing_program_sha256="b" * 64, modeling_program_sha256="c" * 64,
            seed_program_sha256="d" * 64)
    scores = [nested.seal_fresh_training_score(
        family=family, outer_fold=outer, training_context_sha256=context["identity_sha256"],
        selected_spec={"family": family}, selector_evidence_sha256="e" * 64,
        summary={**_summary(.1 + i / 100), "selection_horizon_months": 12},
        execution_evidence_sha256="f" * 64,
        source_kind="FRESH_FULL_DATA_M20_INNER_OOF" if outer == 0 else "FRESH_M20_INNER_OOF",
        selection_horizon_months=12, science_decision_sha256=science["identity_sha256"])
        for i, family in enumerate(nested._families())]
    if damage == "mixed_scores":
        scores[0] = nested._sealed({k: v for k, v in scores[0].items()
                                   if k not in {"identity_sha256", "selection_horizon_months", "science_decision_sha256"}})
        with pytest.raises(ContractError, match="NESTED_FAMILY_SELECTION_INPUT_INVALID"):
            nested.select_training_family(scores)
        return
    decision = nested.select_training_family(scores)
    assert decision["selection_horizon_months"] == 12
    if damage == "other_decision":
        decision = nested._sealed({**{k: v for k, v in decision.items() if k != "identity_sha256"},
                                   "science_decision_sha256": "0" * 64})
    templates = [{"family": decision["selected_family"], "imputation": i,
                  "selected_parents": ["AST_ALT", "Age"]} for i in range(1, 21)]
    kwargs = dict(context=context, decision=decision, selected_parents=["AST_ALT", "Age"],
        common_set_design_df=2, training_event_count=context["training_event_count"],
        parameters_by_imputation=[{"fixed": True}] * 20,
        recipe_sha256_by_imputation=["a" * 64] * 20, baseline_policy_sha256="b" * 64,
        seed_policy_sha256="c" * 64,
        post_lock_template_sha256_by_imputation=[nested._sha(t) for t in templates],
        post_lock_template_archive_sha256_by_imputation=["d" * 64] * 20,
        science_decision=None if damage == "missing_authority" else science)
    if damage in {"other_decision", "missing_authority"}:
        with pytest.raises(ContractError):
            nested.seal_development_lock(**kwargs)
        return
    lock = nested.seal_development_lock(**kwargs)
    assert lock["science_decision_binding"]["development_incremental_budget"] == science[
        "twelve_month_development"]["development_incremental_budget"]
    assert lock["post_lock_model_fit_budget"] == 20
    assert nested.bind_post_lock_task(templates[0], lock)["development_lock_sha256"] == lock["identity_sha256"]
    if damage is not None:
        body = deepcopy({k: v for k, v in lock.items() if k != "identity_sha256"})
        if damage == "budget":
            body["science_decision_binding"]["development_incremental_budget"]["total_maximum"]["total_model_fits"] += 1
        else:
            del body["selection_horizon_months"]
            body["science_decision_binding"] = nested._outer_science_decision_binding(science)
        with pytest.raises(ContractError):
            nested.validate_development_lock(nested._sealed(body), context=context, decision=decision,
                                             science_decision=science)
    else:
        assert nested.validate_development_lock(lock, context=context, decision=decision,
                                                science_decision=science) == lock
