"""Bounded outcome-free application tests. All model/MICE leaves are UNFITTED.

Only the membership test calls real R: the existing typed CSV parser, with no
MICE/model entry and no RNG. These tests do not accept native imputation objects.
"""

import copy
import csv
import io
import math
import subprocess
from pathlib import Path

import pytest

from padml import f5_application as application
from padml._science_authority import load_science_authority
from padml.bundle import (ContractError, canonical_json_bytes, read_safe_zip,
                         sha256_bytes, strict_json_bytes, write_deterministic_zip)


def context_fixture():
    columns = load_science_authority()["science"]["mice"]["private_handoff"]["columns"]
    package = Path(application.__file__).parent
    with (package / "science/variable.csv").open() as handle:
        categorical = {row["variable"]: next(part.strip()[7:] for part in row["levels_or_coding"].split(";")
                       if part.strip().startswith("levels=")).split("|")[0]
                       for row in csv.DictReader(handle) if row["type"] in {"binary", "ordered", "unordered"}}
    raw = {}
    for center, missing in ((36, 58), (38, 0), (39, 4), (48, 10), (52, 25), (54, 55), (55, 60)):
        for number in range(60):
            patient = f"UNFITTED-患者-{center}-{number:02d}"
            raw[patient] = {**dict.fromkeys(columns, "1"),
                            **{name: value for name, value in categorical.items() if name in columns},
                            "Patient_ID": patient, "Center": str(center),
                            "HGB": "" if number < missing else "123"}
            if center == 38:
                raw[patient].update(BMI="", AST_ALT="", ALB="")
    raw["UNFITTED-患者-39-10"]["Height_cm"] = ""
    return {"lineage": {"final_family": "COX_PH", "final_seta": {"lock": {
                "selected_parents": ["AST_ALT", "BMI", "HGB"]}}},
            "donor_ids": list(raw), "raw_rows": raw, "columns": columns,
            "patient_keys": {patient: sha256_bytes(patient.encode()) for patient in raw},
            "source": {"final_lineage_sha256": "a"*64, "binding_contract_sha256": "b"*64,
                       "raw_covariates_sha256": "c"*64}}


def source_fixture(root, context, *, validation=False):
    source = root / "input.zip"
    patients = ["UNFITTED-患者-36-01", "UNFITTED-患者-36-00"]
    members = application.application_input_members(context, patients, validation=validation)
    write_deterministic_zip(source, members)
    return source, members, application.load_application_input(source)[0]


def test_raw_input_preserves_donors_mask_keys_and_profile(tmp_path, monkeypatch):
    context = context_fixture()
    source, members, value = source_fixture(tmp_path, context)
    assert value["chain_seeds"] == list(range(150000001, 150000021))
    rows = list(csv.DictReader(io.StringIO(members["covariates.csv"].decode())))
    assert rows[:420] == list(context["raw_rows"].values())
    assert [row["patient_key_hash"] for row in value["application_rows"]] == sorted(
        row["patient_key_hash"] for row in value["application_rows"])
    for item, row in zip(value["application_rows"], rows[420:], strict=True):
        assert row == {**context["raw_rows"][item["source_id"]], "Patient_ID": item["application_id"]}
        assert row["HGB"] == ""
    assert "response" not in " ".join(members)
    other = tmp_path / "m2"; other.mkdir()
    _, _, small = source_fixture(other, context, validation=True)
    assert small["chain_seeds"] == [150000001, 150000002] and small["validation"] is True
    for ordinal, mutation in enumerate(("copy", "seed", "order", "response")):
        altered, changed = dict(members), copy.deepcopy(value)
        if mutation == "copy":
            bad_rows = copy.deepcopy(rows); bad_rows[-1]["HGB"] = "123"
            altered["covariates.csv"] = application._csv_bytes(context["columns"], bad_rows)
        elif mutation == "seed":
            changed["chain_seeds"][0] += 1
        elif mutation == "order":
            changed["application_rows"].reverse()
        else:
            altered["response.csv"] = b"FORBIDDEN"
        altered["input.json"] = canonical_json_bytes(changed)
        path = tmp_path / f"bad-{ordinal}.zip"; write_deterministic_zip(path, altered)
        with pytest.raises(ContractError):
            application.load_application_input(path)
    def forbidden(*args, **kwargs):
        pytest.fail("MICE/model execution is forbidden")
    monkeypatch.setattr(application.subprocess, "run", forbidden)
    link = tmp_path / "linked"; link.symlink_to(tmp_path, target_is_directory=True)
    with pytest.raises(ContractError, match="TARGET_INVALID"):
        application.execute_application_mice(source, link / "result.zip")
    dangling = tmp_path / "dangling.zip"; dangling.symlink_to(tmp_path / "absent")
    with pytest.raises(ContractError, match="TARGET_INVALID"):
        application.execute_application_mice(source, dangling)


def test_final_seta_native_missingness_and_invalid_values(tmp_path, monkeypatch):
    context = context_fixture()
    original_run, calls = subprocess.run, []
    def parser_only(command, **kwargs):
        assert command[2].endswith("/f5_a04_membership.R")
        calls.append(command)
        return original_run(command, **kwargs)
    monkeypatch.setattr(application.subprocess, "run", parser_only)
    cohort = application.application_cohort(context, tmp_path / "cohort")
    assert [row["eligible_count"] for row in cohort["centers"]] == [58, 0, 4, 10, 25, 55]
    assert [len(row["selected_ids"]) for row in cohort["centers"]] == [50, 0, 4, 10, 25, 50]
    assert cohort["patient_count"] == 139
    # The old two-person audit already records the full membership/rank table.
    # Expanding its cap must produce exactly the native50 cohort, without R/MICE.
    retained = copy.deepcopy(cohort)
    for center in retained['centers']:
        center['selected_ids'] = center['selected_ids'][:2]
        center['selected_patient_key_hashes'] = center['selected_patient_key_hashes'][:2]
        for row in retained['candidates']:
            if row['center'] == center['center']:
                row['included'] = row['source_id'] in center['selected_ids']
                row['reason'] = ('SELECTED' if row['included'] else 'OUTSIDE_FIRST_2_CANONICAL_ORDER'
                    if row['missing_sources'] else 'REQUIRED_RAW_SOURCES_OBSERVED')
    retained['patient_count'] = sum(len(c['selected_ids']) for c in retained['centers'])
    assert application._application_expand_qualified_cohort(retained,context) == cohort
    drift = copy.deepcopy(retained); drift['centers'][0]['selected_ids'].reverse()
    with pytest.raises(ContractError,match='ORIGINAL_COHORT_DRIFT'):
        application._application_expand_qualified_cohort(drift,context)
    assert len(cohort["candidates"]) == 420
    assert all(row["reason"] == "TRAINING_DONOR_ONLY_CENTER" for row in cohort["candidates"] if row["center"] == "55")
    assert cohort["centers"][1]["status"] == "NO_APPLICABLE_MISSING_ROWS_IN_FROZEN_SAMPLE"
    extra = next(row for row in cohort["candidates"] if row["source_id"] == "UNFITTED-患者-39-10")
    # Reliable BMI/weight observations fill height before application selection.
    assert not extra["included"] and extra["missing_sources"] == []
    for ordinal, center in enumerate(cohort["centers"], 1):
        candidates = [row for row in cohort["candidates"] if row["center"] == center["center"] and row["missing_sources"]]
        def independently_rank(row):
            return sha256_bytes(canonical_json_bytes({"algorithm_id": "A04_APPLICATION_MEMBERSHIP_ORDER_V1",
                "patient_key_hash": row["patient_key_hash"], "sampling_seed": 409000+ordinal}).rstrip(b"\n")), row["patient_key_hash"]
        assert center["selected_ids"] == [row["source_id"] for row in sorted(candidates, key=independently_rank)[:50]]
    for field, invalid, message in (("HGB", "NaN", "F1_NONNUMERIC_COLUMN:HGB"),
                                    ("Sex", "UNREGISTERED", "F1_FACTOR_LEVEL_INVALID:Sex")):
        bad = copy.deepcopy(context); bad["raw_rows"][bad["donor_ids"][0]][field] = invalid
        destination = tmp_path / field
        with pytest.raises(ContractError, match="MISSINGNESS_FAILED"):
            application.application_cohort(bad, destination)
        assert message in (destination / "stderr.txt").read_text()
        assert (destination / "native-failure.rda").is_file()
    assert len(calls) == 3
    assert not list(tmp_path.rglob("response.csv"))


def test_native_transport_replay_and_failure_retention_unfitted(tmp_path, monkeypatch):
    context = context_fixture()
    source, members, value = source_fixture(tmp_path, context, validation=True)
    calls, fail = [], [False]
    def unfitted_r(command, **kwargs):
        assert command[2].endswith("/f5_application_mice.R")
        spec = strict_json_bytes(Path(command[4]).read_bytes())
        assert "response_path" not in spec and spec["application_validation"] is True
        action = command[3]; calls.append(action)
        if fail[0]:
            kwargs["stderr"].write(b"F5_APPLICATION_UNFITTED_FAILURE\n")
            return subprocess.CompletedProcess(command, 1)
        root = Path(spec["output_dir"]).parent
        output = root / "output"; output.mkdir()
        summary = {"status": "PASS", "formal_m": 2, "final_iteration": 50,
                   "active_target_count": 1, "convergence_max_psrf": 1.03,
                   **{name: value["view"][name] for name in ("view_id", "role", "outer_fold", "row_ids_sha256")},
                   "row_count": 422, "analysis_row_count": 420,
                   "application_response_columns": 0, "application_predictor_matrix_response_edges": 0}
        for name in application._outputs(2):
            path = output / name; path.parent.mkdir(exist_ok=True)
            path.write_bytes(canonical_json_bytes(summary) if name == "summary.json" else
                             b"UNFITTED_COMPLETED_ROWS\n" if name.endswith(".csv") else b"{}\n")
        (root / "native-session.txt").write_bytes(b"UNFITTED_NO_R_PROCESS\n")
        if action == "FIT":
            (root / "native").mkdir()
            for imp in (1, 2):
                (root / "native" / f"imp{imp:02d}.rds").write_bytes(b"UNFITTED_NOT_AN_RDS")
        else:
            assert len(command) == 6 and Path(command[5]).is_dir()
        return subprocess.CompletedProcess(command, 0)
    monkeypatch.setattr(application.subprocess, "run", unfitted_r)
    payload = tmp_path / "native.zip"
    result = application.execute_application_mice(source, payload)
    assert result["new_model_fits"] == 0 and result["validation"] is True
    materialized = application.materialize_application_mice(source, payload, tmp_path / "replayed")
    assert materialized["input"] == value and calls == ["FIT", "REPLAY"]
    changed = read_safe_zip(payload); changed["imputations/imp01.csv"] = b"TAMPERED\n"
    altered = tmp_path / "altered.zip"; write_deterministic_zip(altered, changed)
    with pytest.raises(ContractError, match="NATIVE_REPLAY_MISMATCH"):
        application.materialize_application_mice(source, altered, tmp_path / "mismatch")
    assert (tmp_path / "mismatch/native/imp01.rds").read_bytes() == b"UNFITTED_NOT_AN_RDS"
    fail[0] = True
    with pytest.raises(ContractError, match="UNFITTED_FAILURE") as failure:
        application.execute_application_mice(source, tmp_path / "failed.zip")
    root = Path(failure.value.__notes__[-1].split("F5_APPLICATION_NATIVE_EVIDENCE:", 1)[1])
    assert (root / "covariates.csv").read_bytes() == members["covariates.csv"]
    assert (root / "stderr.txt").read_bytes() == b"F5_APPLICATION_UNFITTED_FAILURE\n"
    assert not (tmp_path / "failed.zip").exists()
    assert calls == ["FIT", "REPLAY", "REPLAY", "FIT"]


@pytest.mark.parametrize("selection_horizon", [24, 12])
def test_paired_final_models_probability_pooling_and_prepared_failure_evidence(tmp_path, monkeypatch, selection_horizon):
    from padml import f5
    context = context_fixture()
    source, members, value = source_fixture(tmp_path, context)
    rows = list(csv.DictReader(io.StringIO(members["covariates.csv"].decode())))
    imputations = tmp_path / "imputations"; imputations.mkdir()
    models = []
    for imp in range(1, 21):
        completed = [{**row, "HGB": str(imp+1)} for row in rows]
        (imputations / f"imp{imp:02d}.csv").write_bytes(application._csv_bytes(context["columns"], completed))
        models.append({"task": {"imputation": imp, "family": "COX_PH"},
                       "covariates": completed[:420], "response": {"UNFITTED": imp},
                       "recipe": {"UNFITTED_MI_RECIPE": imp}, "objects": (f"UNFITTED_MODEL_{imp}".encode(), f"UNFITTED_BASELINE_{imp}".encode()),
                       "source": {"imputation": imp, "final_lineage_sha256": value["final_lineage_sha256"]}})
    calls, drift = [], [False]
    if selection_horizon == 12:
        for model in models:
            model["source"]["selection_horizon_months"] = 12
    def unfitted_prediction(family, task, covariates, response, recipe, *, retained_objects, prediction_rows, single_parity):
        imp = task["imputation"]; expected = models[imp-1]
        assert covariates is expected["covariates"] and response is expected["response"]
        assert recipe is expected["recipe"] and retained_objects == expected["objects"]
        assert all(row["HGB"] == str(imp+1) for row in prediction_rows)
        calls.append((imp, len(prediction_rows)))
        rate = imp / 1000
        result = {"survival": [[math.exp(-rate*month) for month in range(37)] for row in prediction_rows]}
        if single_parity:
            result["single_survival"] = [[math.exp(-(rate+(.001 if drift[0] else 0))*month)
                for month in range(37)] for row in prediction_rows]
        return result
    monkeypatch.setattr(f5, "_execute_final_refit_engine", unfitted_prediction)
    result = application.predict_completed_application(models, value, imputations, tmp_path / "first", prepared_parity=True)
    expected = math.fsum(math.exp(-imp/1000*24) for imp in range(1, 21)) / 20
    assert result["mean_survival"][0][24] == expected
    assert result["risks"][0]["risk_probability_24"] == 1-expected
    if selection_horizon == 12:
        assert result["primary_horizon_months"] == result["selection_horizon_months"] == 12
        expected12 = math.fsum(math.exp(-imp/1000*12) for imp in range(1, 21)) / 20
        assert result["risks"][0]["risk_probability_12"] == 1-expected12
        mixed = copy.deepcopy(models)
        del mixed[-1]["source"]["selection_horizon_months"]
        with pytest.raises(ContractError, match="MODEL_HORIZON_MISMATCH"):
            application.predict_completed_application(mixed, value, imputations, tmp_path / "mixed", prepared_parity=False)
        assert not (tmp_path / "mixed").exists()
    else:
        assert result["selection_horizon_months"] == 24 and "risk_probability_12" in result["risks"][0]
    assert calls == [(imp, 2) for imp in range(1, 21)]
    assert not list((tmp_path / "first").glob("*.json"))
    bad = copy.deepcopy(models); bad[0]["source"]["final_lineage_sha256"] = "f"*64
    with pytest.raises(ContractError, match="MODEL_PAIRING_INVALID"):
        application.execute_application_transaction(source, tmp_path / "never.zip", bad, prepared_parity=False)
    assert len(calls) == 20
    drift[0] = True
    with pytest.raises(ContractError, match="PREPARED_PARITY_FAILED"):
        application.predict_completed_application(models, value, imputations, tmp_path / "failure", prepared_parity=True)
    failed = strict_json_bytes((tmp_path / "failure/imp01-parity-failure.json").read_bytes())
    assert failed["batch"][0] != failed["single"][0]
    assert len(list((tmp_path / "failure").glob("*.json"))) == 1


def test_patient_transactions_are_batch_order_independent_and_predict_both_endpoints(tmp_path, monkeypatch):
    from contextlib import contextmanager
    from padml import f5, carriers
    context = context_fixture()
    patients = ['UNFITTED-患者-36-00', 'UNFITTED-患者-52-01', 'UNFITTED-患者-48-02']
    sources, tables, models, calls = [], {}, [], []
    donors = [context['raw_rows'][p] for p in context['donor_ids']]
    for i, patient in enumerate(patients):
        source = tmp_path/f'patient{i}.zip'
        write_deterministic_zip(source,application.application_input_members(context,[patient]))
        value, entries = application.load_application_input(source)
        directory = tmp_path/f'tables{i}'; directory.mkdir()
        rows = list(csv.DictReader(io.StringIO(entries['covariates.csv'].decode())))
        for imp in range(1,21):
            completed = [*rows[:-1],{**rows[-1],'HGB':str(100+i+imp)}]
            (directory/f'imp{imp:02d}.csv').write_bytes(application._csv_bytes(context['columns'],completed))
        tables[source] = directory
        sources.append(str(source))
    for imp in range(1,21):
        models.append({'task':{'imputation':imp,'family':'COX_PH'}, 'covariates':donors,
            'response':{}, 'recipe':{}, 'objects':(b'UNFITTED',b'UNFITTED'),
            'source':{'imputation':imp,'final_lineage_sha256':context['source']['final_lineage_sha256']}})
    @contextmanager
    def qualified(source, shared, *, retained_only=False):
        value, entries = application.load_application_input(source)
        assert len(value['application_rows']) == 1
        yield value,tables[source],0,source,source,application._application_mice_key(value,entries)
    def predict(family,task,covariates,response,recipe,*,retained_objects,prediction_rows,single_parity):
        calls.append((task['imputation'],tuple(r['Patient_ID'] for r in prediction_rows)))
        curves = [[math.exp(-float(row['HGB'])*month/10000) for month in range(37)] for row in prediction_rows]
        return {'survival':curves,**({'single_survival':copy.deepcopy(curves)} if single_parity else {})}
    monkeypatch.setattr(application,'_qualified_application_tables',qualified)
    monkeypatch.setattr(f5,'_execute_final_refit_engine',predict)
    monkeypatch.setattr(carriers,'file_reference',lambda p,role:{'path':str(p),'role':role})
    monkeypatch.setattr(carriers,'validate_reference',lambda ref:None)
    def invoke(name,subset):
        return application._patient_application_transaction({'sources':subset,
            'target':str(tmp_path/f'{name}.json'),'shared':str(tmp_path/'shared'),'prepared_parity':True},models=models)
    batch = invoke('batch',sources)
    singles = [invoke(f'single{i}',[s]) for i,s in enumerate(sources)]
    reversed_batch = invoke('reverse',sources[::-1])
    assert calls[:20] != calls[20:40] and len(calls) == 100
    def index(records):
        return {r['patient_key_hash']:r for record in records for r in record['prediction']['risks']}
    assert index([batch]) == index(singles) == index([reversed_batch])
    assert all(not row['prediction_result_cache_used'] for row in [batch,*singles,reversed_batch])
    assert invoke('batch',sources) == batch and len(calls) == 100
    with pytest.raises(ContractError,match='APPLICATION_PATIENT_RESULT_DRIFT'):
        invoke('batch',sources[::-1])


# UNFITTED completed-head admission; no native MICE, prediction or P is run.
_COMPLETED_CURRENT={'run_identity':'1'*64,'source_identity':'2'*64}
_COMPLETED_PREVIOUS={'run_identity':'3'*64,'source_identity':'4'*64}
_COMPLETED_UNKNOWN={'run_identity':'f'*64,'source_identity':'e'*64}
_COMPLETED_GENERATIONS={_COMPLETED_CURRENT['run_identity']:_COMPLETED_CURRENT['source_identity'],_COMPLETED_PREVIOUS['run_identity']:_COMPLETED_PREVIOUS['source_identity']}


def _completed_reference_boundary(monkeypatch):
    from padml import f4, f5_application as app, nested_loco as n, integrated, carriers
    from padml.bundle import sha256_file
    monkeypatch.setattr(integrated,'same_batch_generations',lambda *a:_COMPLETED_GENERATIONS)
    monkeypatch.setattr(f4,'_evaluation_provenance',lambda *a:{'producer':_COMPLETED_CURRENT,'generations':_COMPLETED_GENERATIONS})
    monkeypatch.setattr(carriers,'validate_reference',lambda ref,run: (
        None if sha256_file(Path(ref['path']))==ref['sha256'] else pytest.fail('reference drift')))

@pytest.mark.parametrize('producer,accepted',[(_COMPLETED_CURRENT,True),(_COMPLETED_PREVIOUS,True),(_COMPLETED_UNKNOWN,False)])
def test_completed_original96_exact_producer_is_required_before_reuse(tmp_path,monkeypatch,producer,accepted):
    from padml import f4, f5_application as app, nested_loco as n, integrated, carriers
    from padml.bundle import sha256_file
    _completed_reference_boundary(monkeypatch)
    root=tmp_path/'units/FULL0-H12';(root/'application/cohort').mkdir(parents=True)
    context={'source':{'fixture':'QUALIFIED_CONTEXT'}}
    original={'identity_sha256':'9'*64,'comparisons':[{} for _ in range(24)]}
    (root/'application.json').write_bytes(canonical_json_bytes(original))
    cohort={'source':context['source'],'centers':[{'center':str(c),'selected_ids':[f'UNFITTED-{c}']}
                for c in (36,38,39,48,52,54)]}
    (root/'application/cohort/cohort.json').write_bytes(canonical_json_bytes(cohort))
    monkeypatch.setattr(app,'validate_application_self_check',lambda *a:original)
    monkeypatch.setattr(app,'application_context',lambda *a,**k:context)
    def forbidden(*a,**kw): pytest.fail('completed regression cannot start another transaction or fit')
    monkeypatch.setattr(app,'_audit_jobs',forbidden)
    run={'run_root':str(tmp_path),'identity':_COMPLETED_CURRENT['run_identity'],'source_identity':_COMPLETED_CURRENT['source_identity']}
    unit={'unit_id':'FULL0-H12','kind':'FULL0','horizon':12}
    lineage={'fixture':'UNFITTED_LINEAGE'}
    decision=app.application_repair_decision();folder=root/'application-repair'/decision['identity_sha256'];folder.mkdir(parents=True)
    result=n._sealed({'binding':{'decision':decision,'original_result_identity':original['identity_sha256'],
        'unit_id':unit['unit_id'],'lineage_sha256':n._sha(lineage)},'producer':producer,'status':'COMPLETED',
        'regression_status':'PASS','original_failure_closure':'CLOSED','coordinate_count':24,
        'comparisons':[{'status':'PASS'} for _ in range(24)],'original_failure_count':2,
        'formal_references':[{'path':str(root/'application.json'),'role':'ORIGINAL_APPLICATION_RECORD',
                              'sha256':sha256_file(root/'application.json')}]})
    target=folder/'result.json';target.write_bytes(canonical_json_bytes(result));saved=target.read_bytes()
    if accepted: assert app.run_application_regression(run,unit,root,lineage,{}, {'raw_binding_root':str(tmp_path)})==result
    else:
        with pytest.raises(ContractError,match='APPLICATION_REPAIR_PRODUCER_NOT_ADMITTED|EVALUATION_PRODUCER_NOT_ADMITTED'):
            app.run_application_regression(run,unit,root,lineage,{}, {'raw_binding_root':str(tmp_path)})
    assert target.read_bytes()==saved


# Real ReadyPool admission and retained-only recovery; scientific leaves remain UNFITTED.
from padml import f5_a04_current as a,f5_mice_variants as v,f2_kernel as k,f2,f4,runtime as rt,_science_authority as auth


def _unfitted_row(job):
    body={'top_task_id':job['top_task_id'],'atomic_task_id':job['atomic_task_id'],
          'evaluated':{'UNFITTED_POOL_TRANSACTION':True}}
    return {**body,'task_identity_sha256':k._sha(body)}


def _unfitted_atom(job,**kwargs):
    # Engineering pool payload; no model or numerical scientific function.
    return _unfitted_row(job)


@pytest.fixture
def _a04_ready_resume_scope(tmp_path,monkeypatch):
    root=tmp_path.resolve()/'p2';root.mkdir()
    policy={'configured_worker_ceiling':rt.CPU_MINUS_8,'memory_bytes_per_worker':rt.MIN_WORKER_MEMORY_BYTES,
       'scratch_bytes_per_worker':1024,'memory_reserve_bytes':0,'scratch_reserve_bytes':0,
       'transfer_archive_worker_ceiling':24}
    monkeypatch.setattr(rt,'effective_cpu_count',lambda:32)
    monkeypatch.setattr(rt,'observe_execution_resources',lambda p:{'effective_cpus':32,
        'available_memory_bytes':4*1024**3,'scratch_available_bytes':16*1024**3,'scratch_root':str(root)})
    monkeypatch.setattr(auth,'load_science_authority',lambda:{'science':{'f2_model_development':{'p2c2t_contract':{},'coxtime':{}}}})
    monkeypatch.setattr(k,'predictor_contract',lambda *_:{})
    monkeypatch.setattr(k,'F2_COMPONENTS',('CENTER_BLOCKED_STRESS',))
    monkeypatch.setattr(f2,'compile_f2_units',lambda:[{'seed':i} for i in range(43)])
    monkeypatch.setattr(a,'_a04_p2_completed',lambda *args:None)
    monkeypatch.setattr(f4,'_evaluation_provenance',lambda *_:{'producer':{'run_identity':'a'*64,'source_identity':'b'*64},
                                                           'generations':{'a'*64:'b'*64}})
    monkeypatch.setattr(v,'_original_outer',lambda *args:None)
    monkeypatch.setattr(a,'current_layout',lambda *args:{})
    monkeypatch.setattr(a,'prepare_current_center_assets',lambda *args:({}, {}, {}))
    task={'task_id':'UNFITTED_TOP','family':'COX_PH'}
    registry={'tasks':[task],'registry_sha256':a.sha(task)}
    monkeypatch.setattr(k,'compile_p2c2t_registry',lambda *args,**kw:registry)
    monkeypatch.setattr(k,'selected_route_profiles',lambda **kw:{k._FAMILY_ROUTE_KEYS['COX_PH']: {}})
    folder=root/'CENTER_BLOCKED_STRESS';retained=folder/(a.sha(task)+'-native');retained.mkdir(parents=True)
    jobs=[]
    for i in range(2):
        jobs.append({'top_task_id':task['task_id'],'atomic_task_id':f'UNFITTED_ATOM_{i}',
           'scratch':str(root/f'unfitted-scratch-{i}'),'route':'PYTHON','fit_task':{'family':'COX_PH','imputation':i+1},
           'evaluation_partition':{'covariates':{'members':[{'size_bytes':1}]*2},
               'fit_response':{'size_bytes':1},'evaluation_response':{'size_bytes':1}}})
    plan={'kind':'PADML_F2_P2C2T_ATOMIC_JOB_PLAN','pool_workers':1,'engine_threads':1,
          'task_id':task['task_id'],'jobs':jobs,'expected_fit_count':len(jobs)}
    def registered_result(**kw):
        if kw.get('atomic_job_plan'):return plan
        assert kw['evaluated_override']==[_unfitted_row(j)['evaluated'] for j in jobs]
        return {'task_id':task['task_id'],'task_contract_sha256':a.sha(task),'status':'PASS',
                'expected_fit_count':len(jobs),'executed_fit_count':len(jobs)}
    monkeypatch.setattr(k,'_p2c2t_registered_task_result',registered_result)
    monkeypatch.setattr(a,'bind_current_atomic_plan',lambda p,*args:p)
    monkeypatch.setattr(a,'_a04_p2_binding',lambda *args:{'UNFITTED':True})
    monkeypatch.setattr(a,'_a04_p2_read',lambda job,binding,path,*args:strict_json_bytes(path.read_bytes()))
    monkeypatch.setattr(a,'_a04_p2_atomic_job',_unfitted_atom)
    monkeypatch.setattr(a,'_a04_p2_consumed_member_pins',lambda *args:{})
    monkeypatch.setattr(a,'_a04_p2_retire_consumed',lambda *args:0)
    current={'source':{'UNFITTED':True},'frozen':{},'lock':{'outer_fold':1,'selected_family':'COX_PH'},
             'run':{'resource_policy':policy,'budgets':{'retained_bytes_per_view':1024**2,'retained_bytes_per_component':1024**2}}}
    return current,root,retained,jobs,task


@pytest.mark.parametrize('case',['last_atom_top_absent','partial_missing','bad_zip','symlink_zip','bad_numbers'])
def test_actual_a04_p2_caller_retained_boundary(_a04_ready_resume_scope,monkeypatch,case):
    current,root,retained,jobs,task=_a04_ready_resume_scope
    for j in jobs:
        if j is jobs[-1] and case in {'partial_missing','bad_zip','symlink_zip'}:continue
        row=_unfitted_row(j)
        if case=='bad_numbers' and j is jobs[-1]:row['task_identity_sha256']='e'*64
        (retained/(a.sha(j['atomic_task_id'])+'.json')).write_bytes(canonical_json_bytes(row))
    if case in {'bad_zip','symlink_zip'}:
        target=retained/(a.sha(jobs[-1]['atomic_task_id'])+'.zip')
        if case=='bad_zip':target.write_bytes(b'UNFITTED_NOT_A_ZIP')
        else:target.symlink_to(retained/'MISSING_UNFITTED_TARGET')
    # Actual ReadyPool is forbidden on complete retained or invalid retained paths.
    if case!='partial_missing':
        monkeypatch.setattr(rt,'run_ready_families',lambda *args,**kw:pytest.fail('retained-only cannot create a ReadyPool'))
    before={p.name:p.read_bytes() for p in retained.iterdir() if p.is_file() and not p.is_symlink()}
    if case in {'bad_zip','symlink_zip','bad_numbers'}:
        with pytest.raises((ContractError,ValueError),match='ZIP|PATH_INVALID|RESULT_INVALID'):
            a.execute_current_p2c2t(current,root)
        assert not (root/'CENTER_BLOCKED_STRESS'/(a.sha(task)+'.json')).exists()
    else:
        result,new=a.execute_current_p2c2t(current,root)
        assert result['CENTER_BLOCKED_STRESS']['executed_fit_count']==2
        assert new==(1 if case=='partial_missing' else 0)
        assert (root/'CENTER_BLOCKED_STRESS'/(a.sha(task)+'.json')).is_file()
    assert before=={p.name:p.read_bytes() for p in retained.iterdir() if p.is_file() and not p.is_symlink()}
