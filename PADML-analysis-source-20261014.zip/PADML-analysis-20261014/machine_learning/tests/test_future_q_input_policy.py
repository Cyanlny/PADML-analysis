"""Synthetic original Q contract; no MICE, models, metrics or scientific RNG."""
import copy

import pytest

from padml import f5_sensitivity as sensitivity, runtime
from padml.bundle import ContractError
from test_a12_q_input_release import q_call


@pytest.mark.parametrize("diagnostic", ["scan", "exception"])
def test_unknown_input_cleanup_never_replaces_scientific_contract(q_call, monkeypatch, diagnostic):
    case = q_call
    def unavailable(*args, **kwargs):
        raise PermissionError("UNFITTED scan unavailable")
    if diagnostic == "scan":
        monkeypatch.setattr(runtime, "_visible_open_file_keys", unavailable)
    else:
        monkeypatch.setattr(runtime, "release_step_resources", unavailable)
    result = sensitivity.execute_a12_outer_bundle(case["source"], case["target"], **case["arguments"])
    case["consume"](result)
    report = result["execution_report"]
    assert report["effective_policy"]["scratch_reserve_bytes"] == 0
    assert report["execution_scratch_reserve_bytes"] == 0
    assert report["effective_policy"]["memory_bytes_per_worker"] == 2147483648
    assert result["new_model_fits"] == case["state"]["native_calls"] == 0
    assert all(row["resource_release"].get("reader_scan_status", row["resource_release"].get("status")) == "UNKNOWN"
               for row in report["input_lifecycle"].values())
    for change in ("source", "result", "budget"):
        bad = copy.deepcopy(result)
        if change == "source": bad["execution_report"]["input_archive_sha256"] = "0" * 64
        elif change == "result": bad["new_model_fits"] = 1
        else: bad["execution_report"]["execution_scratch_reserve_bytes"] = True
        with pytest.raises(ContractError): case["consume"](bad)
