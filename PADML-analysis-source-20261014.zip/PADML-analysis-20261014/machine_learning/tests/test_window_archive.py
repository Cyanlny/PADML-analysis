from collections import deque
from concurrent.futures import Future
import hashlib
import io
import json
import os
from pathlib import Path
import shutil
import struct
import sys
from threading import BoundedSemaphore

import pytest

from padml import reports, nested_loco as n
from padml.bundle import (ContractError, canonical_json_bytes, sha256_file, read_safe_zip,
                         inspect_safe_zip_manifest, extract_safe_zip)
from padml.carriers import file_reference, open_carrier, pooled_matrix, write_carrier


def review_acceptance_fixture(tmp_path, monkeypatch):
    from padml import f4, result_closure
    run, source, target, _ = fixture(tmp_path, monkeypatch)
    monkeypatch.setattr(reports, '_archive_volume', lambda root:
        {'uuid':'external-volume','mount':str(tmp_path),'filesystem':'exfat'})
    run.update(post_result_repair=f4.post_result_repair_decision(), result_closure=result_closure.decision())
    run['identity']=n._sha({k:v for k,v in run.items() if k!='identity'})
    evidence_root=tmp_path/'controller';evidence_root.mkdir()
    current=n._sealed({'run_identity':run['identity'],'decision_sha256':run['result_closure']['identity_sha256'],
        'cross_time':{'sources':{str(i):str(i)*64 for i in range(8)}},
        'a04':{h:{'source_identity':h*32,'a04':{'negative_gate':'HARD_REVIEW_REQUIRED' if h=='12' else 'PASS'}}
            for h in ('6','12','24','36')}})
    review=n._sealed({'current_report_identity':current['identity_sha256'],
        'decision_sha256':current['decision_sha256'],'tail_sources':current['cross_time']['sources'],
        'status':'COMPLETE_WITH_EXPLICIT_LIMITATIONS','a04_lines':{h:{'source_identity':r['source_identity'],
            'original_gate':r['a04']['negative_gate'],'unresolved_reviews':0} for h,r in current['a04'].items()}})
    evidence={}
    for name,value in [('current.json',current),('review.json',review)]:
        raw=canonical_json_bytes(value);(evidence_root/name).write_bytes(raw)
        evidence[name]={'sha256':hashlib.sha256(raw).hexdigest(),'size_bytes':len(raw)}
    report=n._sealed({'kind':'PADML_POST_RESULT_REPAIR_FINAL_ACCEPTANCE_20261008_V1',
        'run_identity':run['identity'],'source_identity':run['source_identity'],
        'decision_sha256':run['post_result_repair']['identity_sha256'],'status':'ACCEPTED',
        'archive_resume':'EXPLICITLY_ENABLED','original_application':{'original_failures_closed':10,
            'regression_passed':96,'original_successes_without_regression':86,'unresolved_causes':0},
        'calibration':{'unhandled_engineering_or_numerical_failures':0},
        'full_a04':{'completed_primary_scopes':24,'completed_application_lines':4,'unresolved_reviews':0},
        'auc_validation':{'completed_scenarios':6,'datasets_per_scenario':2000,'reliability_scopes_explicit':True},
        'report_direct_consumer':'PASSED','final_cross_audit':{'rounds':2,'agents_per_round':3,
            'unresolved_correctness_recovery_storage_defects':0},'evidence':evidence,
        'result_closure':{'decision_sha256':run['result_closure']['identity_sha256'],
            'a04_auc_coordinates':784,'a04_calibration_groups':784,'a04_uno_coordinates':343,
            'cross_time_units':8,'original_rmse_unchanged':16,'unresolved_reviews':0,
            'interval_disposition':'COMPLETE_WITH_EXPLICIT_RELIABILITY_LIMITS',
            'new_training_mice':0,'new_prediction_model_fits':0,'new_shap_solves':0,'new_resampling':0},
        'result_closure_evidence':{'current_report':'current.json','review':'review.json'}})
    path=evidence_root/'acceptance.json';path.write_bytes(canonical_json_bytes(report))
    return run,target,path,report


@pytest.mark.parametrize('interrupt',[False,True])
def test_final_review_is_durable_offline_and_retains_original_alert(tmp_path,monkeypatch,interrupt):
    from concurrent.futures import ThreadPoolExecutor
    run,target,path,report=review_acceptance_fixture(tmp_path,monkeypatch)
    publish=reports._publish
    def interrupted(destination,*args,**kw):
        if destination.name=='index.json':raise OSError('interrupted before index')
        return publish(destination,*args,**kw)
    with ThreadPoolExecutor(3) as pool:
        if interrupt:
            monkeypatch.setattr(reports,'_publish',interrupted)
            with pytest.raises(OSError,match='before index'):
                reports.WindowArchive(run,target,pool=pool,call=None,command=None,slots=None,acceptance_path=path)
            monkeypatch.setattr(reports,'_publish',publish)
        archive=reports.WindowArchive(run,target,pool=pool,call=None,command=None,slots=None,acceptance_path=path)
        for future in archive.restore_futures:future.result()
        count=len(list((archive.target/'objects').iterdir()))
        again=reports.WindowArchive(run,target,pool=pool,call=None,command=None,slots=None,acceptance_path=path)
        for future in again.restore_futures:future.result()
        assert len(list((archive.target/'objects').iterdir()))==count==3
    shutil.rmtree(path.parent)
    actual,names=reports.archived_review(run,archive.target)
    assert actual==report and len(names)==3
    original=json.loads(reports.archived_bytes(names[1],run,index_path=archive.target/'index.json'))
    assert original['a04']['12']['a04']['negative_gate']=='HARD_REVIEW_REQUIRED'


@pytest.mark.parametrize('damage',['missing','bytes','tail_binding'])
def test_final_review_rejects_unproven_or_drifted_evidence(tmp_path,monkeypatch,damage):
    from padml import f4
    run,target,path,report=review_acceptance_fixture(tmp_path,monkeypatch)
    evidence=path.parent/'review.json'
    if damage=='missing':evidence.unlink()
    elif damage=='bytes':evidence.write_bytes(b'changed')
    else:
        value=json.loads(evidence.read_bytes());value['tail_sources']={}
        raw=canonical_json_bytes(n._sealed({k:v for k,v in value.items() if k!='identity_sha256'}));evidence.write_bytes(raw)
        report['evidence']['review.json']={'sha256':hashlib.sha256(raw).hexdigest(),'size_bytes':len(raw)}
        path.write_bytes(canonical_json_bytes(n._sealed({k:v for k,v in report.items() if k!='identity_sha256'})))
    with pytest.raises(ContractError,match='EVIDENCE_DRIFT|REVIEW_BINDING_DRIFT'):
        f4.validate_post_result_archive_acceptance(run,path)


@pytest.mark.parametrize('staging',[False,True])
def test_result_closure_extends_stable_prior_inventory_without_reopening_zip(tmp_path,monkeypatch,staging):
    import time
    run,source,_,_=fixture(tmp_path,monkeypatch)
    clock=time.time_ns()+10_000_000_000
    monkeypatch.setattr(time,'time_ns',lambda:clock)
    version={'closure_version':2,'evaluation_decision_sha256':'c'*64,
        'post_result_repair_sha256':'d'*64,'curve_rmse_sha256':'e'*64}
    monkeypatch.setattr(reports,'_archive_version',lambda run:dict(version))
    monkeypatch.setattr(reports,'_archive_appendix_pins',lambda *a,**kw:{})
    old=reports.archive_inventory(run,6,['EVALUATION-H06'],[],staging=staging)
    for name in ('H06-inventory.json','H06-inventory-closure2.json'):
        (source/'shared/archives'/name).unlink(missing_ok=True)
    version['result_closure_sha256']='f'*64
    path=source/'shared/closure.json';path.write_bytes(canonical_json_bytes({'compact':True}))
    pin={'sha256':sha256_file(path),'size_bytes':path.stat().st_size}
    monkeypatch.setattr(reports,'_archive_appendix_pins',lambda *a,**kw:{'shared/closure.json':pin})
    def forbidden(*a,**kw):raise AssertionError('qualified unchanged ZIP reopened')
    monkeypatch.setattr(reports.zipfile,'ZipFile',forbidden)
    new=reports.archive_inventory(run,6,['EVALUATION-H06'],[],staging=staging)
    assert new['previous_inventory_identity']==old['identity_sha256']
    assert set(new['members'])==set(old['members'])|{'shared/closure.json'}


def calibration_variants_fixture(tmp_path, monkeypatch, *, damage=None):
    """Two real immutable JSON/ZIP sources, without any scientific fitting."""
    from padml import f4, integrated
    run, source, target, _ = fixture(tmp_path, monkeypatch,
        run_extra={'host_connections':{'H0':{}, 'H1':{}}})
    generations = {run['identity']:run['source_identity'], '1'*64:'2'*64}
    monkeypatch.setattr(reports, 'same_batch_generations', lambda _:generations)
    monkeypatch.setattr(integrated, 'same_batch_generations', lambda _:generations)
    monkeypatch.setattr(reports, '_archive_volume', lambda root:
        {'uuid':'external-volume','mount':str(tmp_path),'filesystem':'exfat'})
    binding = {'calibration_contract_sha256':n._sha({
        'original_evaluation':f4.evaluation_decision()['identity_sha256'],
        'calibration':f4.post_result_repair_decision()['calibration']}),
        'input':'UNFITTED-ARCHIVE-BOUNDARY'}
    name = 'shared/evaluation-calibration-20261008/' + n._sha(binding) + '.json'
    raw, references, inventories, runs = {}, {}, {}, {}
    for host, (identity, producer) in zip(run['host_connections'], generations.items()):
        base = source if host == 'H0' else tmp_path/'second-source'
        base.mkdir(exist_ok=True)
        leaf = {'kind':'PADML_CALIBRATION_NUMERIC_LEAF_20261008_V1',
            'input_identity':n._sha(binding),'binding':binding,
            'producer':{'run_identity':identity,'source_identity':producer},
            'status':'COMPLETED','completed_calibration_fit_calls':1,
            'result':{'status':'ESTIMABLE','value':.375}}
        if host == 'H1':
            if damage == 'numerical': leaf['result']['value'] = .5
            if damage == 'producer': leaf['producer']['source_identity'] = 'f'*64
            if damage == 'input': leaf['binding'] = {**binding,'extra':'drift'}
        leaf = n._sealed(leaf)
        if host == 'H1' and damage == 'seal': leaf['identity_sha256'] = '0'*64
        raw[host] = canonical_json_bytes(leaf)
        path = base/name; path.parent.mkdir(parents=True,exist_ok=True); path.write_bytes(raw[host])
        pin = {'sha256':sha256_file(path),'size_bytes':path.stat().st_size}
        references[host] = {'path':name,'numeric_leaf':n._sha(binding),'producer':producer,**pin}
        note = 'shared/'+host+'.json'; (base/note).write_bytes(canonical_json_bytes({'host':host}))
        members = {name:{**pin,'native_file':False}, note:{'sha256':sha256_file(base/note),
            'size_bytes':(base/note).stat().st_size,'native_file':False}}
        inventories[host] = n._sealed({'kind':'PADML_WINDOW_ARCHIVE_INVENTORY_V1',
            'run_identity':run['identity'],'horizon':6,'units':['EVALUATION-H06'],
            'selections':[],'members':members})
        folder = base/'shared/archives'; folder.mkdir(exist_ok=True)
        (folder/'H06-inventory.json').write_bytes(canonical_json_bytes(inventories[host]))
        runs[host] = {**run,'run_root':str(base)}
    return run, target, name, raw, references, inventories, runs, generations


@pytest.mark.parametrize('staging', [True, False])
def test_archive_producer_variants_preserve_pins_pack_names_and_cold_offline_consumers(tmp_path, monkeypatch, staging):
    from concurrent.futures import ThreadPoolExecutor
    from padml import carriers, f4
    import time
    run,target,name,raw,refs,inventories,runs,generations = calibration_variants_fixture(tmp_path,monkeypatch)
    observations = {host:{'state':'IDLE','completed_units':['EVALUATION-H06'],
        'selection_completed_units':[],'postprocess_ready_units':[]} for host in runs}
    transfers, acks = [], []
    def command(host, op, **kwargs):
        transfers.append((host,kwargs['members_pin']))
        return command_for(runs[host])(host,op,**kwargs)
    def call(host, op, **kwargs):
        if op == 'archive_inventory':
            return {'status':'IDLE','horizon':6} if kwargs.get('status_only') else inventories[host]
        assert op == 'archive_confirm' and not staging
        index = json.loads((target/run['run_id']/'index.json').read_bytes())
        assert len([key for key in index['members'] if reports._calibration_logical_name(key)]) == 2
        assert kwargs['receipt']['inventories'] == {h:i['identity_sha256'] for h,i in inventories.items()}
        acks.append(kwargs['receipt'])
        return {'status':'CONFIRMED'}
    with ThreadPoolExecutor(max_workers=7) as pool:
        collector = reports.WindowArchive(run,target,pool=pool,call=call,command=command,
            slots=BoundedSemaphore(3),staging=staging)
        until = time.monotonic()+15
        while True:
            status = collector.advance(observations)
            if collector.staged() if staging else status.get('6') == 'CONFIRMED': break
            assert time.monotonic() < until, status
            time.sleep(.01)
        old = json.loads((collector.target/'index.json').read_bytes())
        assert len(transfers) == 2 and len(acks) == (0 if staging else 2)
        if staging:
            assert not old['windows']
            for receipt in old['staged_inventories'].values():
                assert receipt['member_pins_sha256'] == n._sha({key:{k:v[k] for k in ('sha256','size_bytes')}
                    for key,v in inventories[receipt['host']]['members'].items()})
        for item in old['members'].values():
            assert item['member'] in set().union(*(set(v['members']) for v in inventories.values()))
        def no_transfer(*args,**kwargs): raise AssertionError('duplicate transfer')
        restored = reports.WindowArchive(run,target,pool=pool,call=call,command=no_transfer,
            slots=BoundedSemaphore(3),staging=staging)
        while True:
            status = restored.advance(observations)
            if restored.staged() if staging else status.get('6') == 'CONFIRMED': break
            assert time.monotonic() < until, status
            time.sleep(.01)
        assert old == json.loads((collector.target/'index.json').read_bytes())
    monkeypatch.setenv('PADML_ARCHIVE_INDEX', str(collector.target/'index.json'))
    for r in runs.values(): shutil.rmtree(r['run_root'])
    for host,ref in refs.items():
        pin = {k:ref[k] for k in ('sha256','size_bytes')}
        assert carriers.read_reference(ref) == raw[host]
        carriers.validate_reference(ref)
        assert carriers.source_bytes(Path(run['run_root'])/name,expected=pin) == raw[host]
        assert f4._evaluation_calibration_repair_leaf_value(ref,
            shared=Path(run['run_root'])/Path(name).parent,generations=generations) == json.loads(raw[host])['result']
        with pytest.raises(ContractError,match='PACKED_MEMBER_HAS_NO_NATIVE_PATH'):
            carriers.resolve_reference(ref)
    with pytest.raises(ContractError,match='AMBIGUOUS_PRODUCER'):
        reports.archived_bytes(name,run)
    with pytest.raises(ContractError,match='PIN_NOT_FOUND'):
        carriers.read_reference({**refs['H0'],'sha256':'f'*64})


@pytest.mark.parametrize('damage', ['numerical','producer','input','seal'])
def test_archive_producer_variant_conflict_cannot_publish_or_confirm(tmp_path, monkeypatch, damage):
    run,target,name,raw,refs,inventories,runs,_ = calibration_variants_fixture(tmp_path,monkeypatch,damage=damage)
    collector = reports.WindowArchive(run,target,pool=None,call=None,command=None,slots=None,staging=True)
    for host in runs:
        collector.states[host] = {'units':{'EVALUATION-H06'},'training':set(),'not_estimable':set()}
        collector._plan(6,{host:inventories[host]},state_key=host)
    accepted = None
    while collector.pending:
        spec = collector.pending.popleft()
        rows = reports.receive_archive(run,collector.target,spec,
            command=command_for(runs[spec['host']]),slots=BoundedSemaphore(3))
        if spec['host'] == 'H0':
            collector._store_staged(rows); accepted = (collector.target/'index.json').read_bytes()
        else:
            with pytest.raises(ContractError,match='ARCHIVE_VARIANT_|EVALUATION_PRODUCER_NOT_ADMITTED'):
                collector._store_staged(rows)
    assert accepted == (collector.target/'index.json').read_bytes() and not collector.index['windows']


def test_archive_old_receipt_alias_first_and_noncalibration_conflicts(tmp_path, monkeypatch):
    run,target,name,raw,refs,inventories,runs,_ = calibration_variants_fixture(tmp_path,monkeypatch)
    collector = reports.WindowArchive(run,target,pool=None,call=None,command=None,slots=None,staging=True)
    for host in runs:
        collector.states[host] = {'units':{'EVALUATION-H06'},'training':set(),'not_estimable':set()}
        collector._plan(6,{host:inventories[host]},state_key=host)
    first,second = list(collector.pending)
    # Out-of-order completion cannot admit an uncomparable producer variant.
    rows = reports.receive_archive(run,collector.target,second,command=command_for(runs['H1']),slots=BoundedSemaphore(3))
    with pytest.raises(ContractError,match='ARCHIVE_VARIANT_BASE_PENDING'):
        collector._store_staged(rows)
    assert not (collector.target/'index.json').exists()
    digest = n._sha({key:{k:v[k] for k in ('sha256','size_bytes')} for key,v in inventories['H1']['members'].items()})
    assert collector._closure_pins_sha(rows) == digest
    rows0 = reports.receive_archive(run,collector.target,first,command=command_for(runs['H0']),slots=BoundedSemaphore(3))
    collector._store_staged(rows0)
    collector._store_staged(rows)
    assert collector._closure_pins_sha(rows|rows0) == collector._closure_pins_sha(rows0|rows)
    legacy = n._sealed({**{k:v for k,v in collector.index.items() if k!='identity_sha256'},'members':rows0})
    (collector.target/'index.json').write_bytes(canonical_json_bytes(legacy))
    assert reports.archived_bytes(name,run,index_path=collector.target/'index.json',
        expected={k:refs['H0'][k] for k in ('sha256','size_bytes')}) == raw['H0']
    with pytest.raises(ContractError,match='PIN_NOT_FOUND'):
        reports.archived_bytes(name,run,index_path=collector.target/'index.json',
            expected={k:refs['H1'][k] for k in ('sha256','size_bytes')})
    collector.member_pins['shared/unrelated.json'] = {'sha256':'a'*64,'size_bytes':1}
    bad = n._sealed({**{k:v for k,v in inventories['H1'].items() if k!='identity_sha256'},
        'members':{'shared/unrelated.json':{'sha256':'b'*64,'size_bytes':1,'native_file':False}}})
    with pytest.raises(ContractError,match='ARCHIVE_CONFLICTING_PRODUCER:shared/unrelated.json'):
        collector._plan(6,{'H1':bad},state_key='H1')


@pytest.mark.parametrize('active_base_host', [False, True])
def test_archive_variants_wait_in_original_queue_without_occupying_base_transfer_slots(tmp_path, monkeypatch, active_base_host):
    run,target,name,raw,refs,inventories,runs,_ = calibration_variants_fixture(tmp_path,monkeypatch)
    class Pool:
        def __init__(self): self.calls = []
        def submit(self, *args, **kwargs):
            self.calls.append((args,kwargs)); return Future()
    pool = Pool()
    collector = reports.WindowArchive(run,target,pool=pool,call=None,command=None,slots=None,staging=True)
    for host in runs:
        collector.states[host] = {'host':host,'horizon':6,'units':{'EVALUATION-H06'},'training':set(),'not_estimable':set()}
        collector._plan(6,{host:inventories[host]},state_key=host)
    base,variant = list(collector.pending)
    third = {**variant,'host':'H2','state_key':'H2'}
    collector.states['H2'] = {**collector.states['H1'],'host':'H2'}
    collector.pending = deque([variant,third,base])
    if active_base_host:
        collector.futures[Future()] = {'host':'H0','state_key':'H0'}
    collector._advance_staging({host:{'state':'IDLE'} for host in ('H0','H1','H2')})
    assert len(pool.calls) == 1 and pool.calls[0][0][3]['host'] == 'H0'
    assert len(collector.pending) == 2


def fixture(tmp_path, monkeypatch, *, run_extra=None):
    source = tmp_path/'source'; source.mkdir()
    run = {'kind':'PADML_INTEGRATED_RAW_RUN_V1','run_root':str(source),'run_id':'archive-test',
        'identity':'a'*64,'source_identity':'b'*64,
        'units':[{'unit_id':'EVALUATION-H06','kind':'EVALUATION','horizon':6}],
        'host_connections':{'H0':{'ssh_target':'unused'}}}
    run.update(run_extra or {})
    run['identity'] = n._sha({k:v for k,v in run.items() if k != 'identity'})
    manifest = tmp_path/'run.json'; manifest.write_bytes(canonical_json_bytes(run))
    monkeypatch.setenv('PADML_F45_RUN_PATH', str(manifest))
    binding = source/'binding'; binding.mkdir()
    for name in ('binding.json','contract.json'): (binding/name).write_bytes(canonical_json_bytes({}))
    for name in ('covariates.csv','response-seal.csv'): (binding/name).write_bytes(b'input\n')
    blob = source/'shared/model.f64'; blob.parent.mkdir()
    blob.write_bytes(struct.pack('<37d', *[.8]*37))
    note = source/'shared/note.json'; note.write_bytes(canonical_json_bytes({'note':'unique'}))
    note2 = source/'shared/other.json'; note2.write_bytes(canonical_json_bytes({'note':'other'}))
    producer = source/'shared/producer.zip'
    write_carrier(producer, {'number.json':canonical_json_bytes({
        'patient_ids':['P'], 'pooled_survival_ref':file_reference(blob,'OOF')})},
        references={'note.json':note, 'other.json':note2})
    unit = source/'units/EVALUATION-H06'; unit.mkdir(parents=True)
    write_carrier(unit/'result.zip',{},references={'producer.zip':producer})
    for name in ('absolute_rows','paired_rows'):
        (unit/f'report-H06-{name}.csv').write_bytes(b'metric,value\na,1\n')
    receipt = {'status':'COMPLETED','run_identity':run['identity'],'unit_id':'EVALUATION-H06',
        'direct_consumer_completed':True,'artifacts':{'result.zip':{
        'sha256':sha256_file(unit/'result.zip'),'size_bytes':(unit/'result.zip').stat().st_size}}}
    (unit/'unit.json').write_bytes(canonical_json_bytes(receipt))
    inventory = reports.archive_inventory(run,6,['EVALUATION-H06'],[])
    target = tmp_path/'archive'; target.mkdir()
    for name in ('objects','packs','windows'): (target/name).mkdir()
    return run, source, target, inventory


def command_for(run):
    def command(host, operation, **kwargs):
        assert operation == 'archive_send'
        payload = json.dumps([run, kwargs])
        return [sys.executable,'-B','-c',
            'import json,sys;from padml.reports import archive_send,archive_members_from_stream;'
            'r,p=json.loads(sys.argv[1]);archive_send(r,p["horizon"],p["inventory_identity"],'
            'archive_members_from_stream(p["members_pin"],sys.stdin.buffer),p["offset"],sys.stdout.buffer)',payload]
    return command


def test_archive_send_error_and_invalid_offset_close_source(tmp_path, monkeypatch):
    from padml import runtime
    run, source, target, inventory = fixture(tmp_path,monkeypatch)
    name = 'shared/model.f64'
    rows, handles = [], []
    def advise(stream, **kw):
        handles.append(stream)
        rows.append(kw)
        return 'ADVISED'
    monkeypatch.setattr(runtime, 'advise_consumed_stream', advise)
    class Broken:
        def write(self, data): raise BrokenPipeError('receiver')
    with pytest.raises(BrokenPipeError, match='receiver'):
        reports.archive_send(run,6,inventory['identity_sha256'],[name],7,Broken())
    assert rows == [{'offset':7,'length':(source/name).stat().st_size-7}]
    assert all(handle.closed for handle in handles)
    rows.clear()
    with pytest.raises(ContractError,match='RESUME_OFFSET_INVALID'):
        reports.archive_send(run,6,inventory['identity_sha256'],[name],999999,io.BytesIO())
    assert not rows


def test_archive_fsync_failure_retains_prefix_and_never_publishes(tmp_path, monkeypatch):
    run, source, target, inventory = fixture(tmp_path,monkeypatch)
    spec = record(inventory,['shared/model.f64'],target)
    def fail(fd): raise OSError('PERSISTENCE_UNAVAILABLE')
    monkeypatch.setattr(reports.os,'fsync',fail)
    with pytest.raises(OSError,match='PERSISTENCE_UNAVAILABLE'):
        reports.receive_archive(run,target,spec,command=command_for(run),slots=BoundedSemaphore(3))
    path = target / 'objects' / spec['pins']['shared/model.f64']['sha256']
    assert not path.exists() and path.with_suffix('.part').read_bytes() == (source/'shared/model.f64').read_bytes()


def record(inventory, names, target):
    return {'host':'H0','horizon':6,'inventory_identity':inventory['identity_sha256'],
        'members':names,'pins':{name:{k:inventory['members'][name][k] for k in ('sha256','size_bytes')}
            for name in names},'volume_device':target.stat().st_dev}


def test_archive_reference_closure_resume_and_offline_direct_consumer(tmp_path, monkeypatch):
    run, source, target, inventory = fixture(tmp_path,monkeypatch)
    assert {'shared/model.f64','shared/note.json','shared/other.json','shared/producer.zip'} <= set(inventory['members'])
    members = {}
    small = [name for name,row in inventory['members'].items() if not row['native_file']]
    groups = [[name] for name in inventory['members'] if name not in small]+[small]
    for names in groups:
        if not names: continue
        spec = record(inventory,names,target)
        if len(names)==1:
            name = names[0]
            part = target/'objects'/(spec['pins'][name]['sha256']+'.part')
            part.write_bytes((source/name).read_bytes()[:4])
        rows = reports.receive_archive(run,target,spec,command=command_for(run),slots=BoundedSemaphore(3))
        members.update(rows)
    index = n._sealed({'kind':'PADML_WINDOW_ARCHIVE_INDEX_V1','run_identity':run['identity'],
        'source_identity':run['source_identity'],'members':members,'windows':{'6':{}}})
    (target/'index.json').write_bytes(canonical_json_bytes(index))
    monkeypatch.setenv('PADML_ARCHIVE_INDEX',str(target/'index.json'))
    shutil.rmtree(source)
    with open_carrier(Path(run['run_root'])/'units/EVALUATION-H06/result.zip') as outer:
        with open_carrier(io.BytesIO(outer.read('producer.zip'))) as inner:
            value = json.loads(inner.read('number.json'))
            assert pooled_matrix(value) == [[.8]*37]
            assert json.loads(inner.read('note.json')) == {'note':'unique'}
    logical = Path(run['run_root'])/'shared/producer.zip'
    admissions = []
    raw = read_safe_zip(logical, admit_io=lambda **kw: admissions.append(kw))
    assert json.loads(raw['note.json']) == {'note':'unique'}
    manifest, names = inspect_safe_zip_manifest(logical, manifest_name='number.json')
    assert manifest == raw['number.json'] and set(names) == set(raw)
    extracted = tmp_path/'required-input'
    extract_safe_zip(logical,extracted,expected_members=set(raw),max_member_bytes=1024**2,
        max_total_bytes=8*1024**2,admit_io=lambda **kw: admissions.append(kw))
    assert (extracted/'note.json').read_bytes() == raw['note.json'] and admissions
    assert not list(target.rglob('*.part'))
    physical = target/members['shared/model.f64']['storage']
    physical.write_bytes(b'broken')
    with pytest.raises(ContractError,match='DRIFT'):
        pooled_matrix(value)


@pytest.mark.parametrize('location', ['embedded', 'reference', 'offline-object', 'offline-pack'])
def test_evaluation_nested_index_consumes_physical_and_logical_zip(tmp_path, monkeypatch, location):
    from padml import f5_sensitivity as a
    from padml.bundle import write_deterministic_zip
    run, source, target, _ = fixture(tmp_path, monkeypatch)
    mice = source / 'shared/mice.zip'
    expected = canonical_json_bytes({'kind': 'SYNTHETIC_INDEX_ONLY', 'outer_fold': 1})
    write_deterministic_zip(mice, {'a12-inputs.json': expected, 'unused.bin': b'0' * 4096})
    pin = {'sha256': sha256_file(mice), 'size_bytes': mice.stat().st_size}
    result = source / 'shared/aar.zip'
    if location == 'embedded':
        write_deterministic_zip(result, {'inputs.zip': mice}, stored_members={'inputs.zip'})
    else:
        write_carrier(result, {}, references={'inputs.zip': mice})
    with open_carrier(result) as archive:
        if location.startswith('offline'):
            packed = location == 'offline-pack'
            storage = 'packs/mice.zip' if packed else 'objects/mice'
            physical = target / storage
            if packed:
                write_deterministic_zip(physical, {'shared/mice.zip': mice})
            else:
                shutil.copyfile(mice, physical)
            index = n._sealed({'kind': 'PADML_WINDOW_ARCHIVE_INDEX_V1',
                'run_identity': run['identity'], 'source_identity': run['source_identity'],
                'windows': {}, 'members': {'shared/mice.zip': {'pin': pin, 'storage': storage,
                    'member': 'shared/mice.zip' if packed else None,
                    'physical': {'sha256': sha256_file(physical), 'size_bytes': physical.stat().st_size}}}})
            (target / 'index.json').write_bytes(canonical_json_bytes(index))
            monkeypatch.setenv('PADML_ARCHIVE_INDEX', str(target / 'index.json'))
            mice.unlink()
        assert a._f45_evaluation_nested_index(archive, 'inputs.zip', 'a12-inputs.json', pin) == expected
        if location != 'embedded':
            with pytest.raises(ContractError, match='MEMBER_DRIFT'):
                a._f45_evaluation_nested_index(archive, 'inputs.zip', 'a12-inputs.json',
                    {**pin, 'sha256': '0' * 64})


def test_archive_rename_without_durable_parent_never_confirms(tmp_path, monkeypatch):
    path = tmp_path / 'published.json'
    original = reports.os.fsync
    calls = []
    def fail_parent(fd):
        import stat
        if stat.S_ISDIR(os.fstat(fd).st_mode):
            calls.append('parent')
            raise OSError('PARENT_NOT_DURABLE')
        return original(fd)
    monkeypatch.setattr(reports.os, 'fsync', fail_parent)
    with pytest.raises(OSError, match='PARENT_NOT_DURABLE'):
        reports._publish(path, b'{}', 'TEST')
    assert calls == ['parent'] and path.read_bytes() == b'{}'
    # A readable leftover must reattempt the failed durability barrier.
    with pytest.raises(OSError, match='PARENT_NOT_DURABLE'):
        reports._publish(path, b'{}', 'TEST')


def test_archive_rejects_missing_closure_and_does_not_publish_failed_transfer(tmp_path,monkeypatch):
    run,source,target,inventory = fixture(tmp_path,monkeypatch)
    name = 'shared/model.f64'; spec = record(inventory,[name],target)
    def bad_command(*args,**kwargs):
        return [sys.executable,'-c','import sys;sys.stdout.buffer.write(b"truncated");sys.exit(1)']
    with pytest.raises(ContractError,match='TRANSFER_FAILED'):
        reports.receive_archive(run,target,spec,command=bad_command,slots=BoundedSemaphore(3))
    assert (source/name).is_file()
    assert not (target/'objects'/spec['pins'][name]['sha256']).exists()
    part = target/'objects'/(spec['pins'][name]['sha256']+'.part')
    part.write_bytes(b'x'*spec['pins'][name]['size_bytes'])
    with pytest.raises(ContractError, match='ARCHIVE_BYTES_DRIFT'):
        reports.receive_archive(run,target,spec,command=command_for(run),slots=BoundedSemaphore(3))
    assert not part.exists() and (source/name).is_file()
    reports.receive_archive(run,target,spec,command=command_for(run),slots=BoundedSemaphore(3))
    (source/name).unlink()
    with pytest.raises(ContractError,match='REFERENCE_MISSING'):
        reports.archive_inventory(run,6,['EVALUATION-H06'],[])


def test_external_subdirectory_uses_actual_mount_even_without_mounted_field(tmp_path,monkeypatch):
    import plistlib
    from types import SimpleNamespace
    mount = tmp_path/'volume'; mount.mkdir()
    root = mount/'results'; root.mkdir()
    monkeypatch.setattr(Path, 'is_mount', lambda p: p in (mount, Path('/')))
    def info(args, **kw):
        assert args[-1] == str(mount)
        return SimpleNamespace(returncode=0, stdout=plistlib.dumps({
            'MountPoint':str(mount), 'VolumeUUID':'fixed-volume', 'FilesystemType':'exfat'}))
    monkeypatch.setattr(reports.subprocess, 'run', info)
    assert reports._archive_volume(root)['uuid'] == 'fixed-volume'
    monkeypatch.setattr(Path, 'is_mount', lambda p: p == Path('/'))
    with pytest.raises(ContractError, match='VOLUME_UNAVAILABLE'):
        reports._archive_volume(root)


def test_archive_publish_uses_rename_on_volumes_without_hardlinks(tmp_path,monkeypatch):
    monkeypatch.setattr(os,'link',lambda *a,**kw:(_ for _ in ()).throw(AssertionError('hardlink')))
    path=tmp_path/'index.json'
    reports._publish(path,b'one','DRIFT')
    reports._publish(path,b'one','DRIFT')
    with pytest.raises(ContractError,match='DRIFT'): reports._publish(path,b'two','DRIFT')
    reports._publish(path,b'two','DRIFT',replace=True)
    assert path.read_bytes()==b'two' and not path.with_name('index.json.part').exists()


def test_window_publication_precedes_ack_and_resume_does_not_retransfer(tmp_path,monkeypatch):
    from concurrent.futures import ThreadPoolExecutor
    import time
    run,source,target,inventory=fixture(tmp_path,monkeypatch)
    monkeypatch.setattr(reports,'_archive_volume',lambda root:{'uuid':'external-volume','mount':str(tmp_path),'filesystem':'exfat'})
    observations={'H0':{'completed_units':['EVALUATION-H06'],'selection_completed_units':[],
        'postprocess_ready_units':[]}}
    acks=[]
    def call(host,operation,**kwargs):
        if operation=='archive_inventory': return inventory
        assert operation=='archive_confirm'
        index=json.loads((target/run['run_id']/'index.json').read_bytes())
        assert index['windows']['6']==kwargs['receipt']
        assert set(index['members'])==set(inventory['members'])
        acks.append(kwargs['receipt']['identity_sha256'])
        return {'status':'CONFIRMED'}
    with ThreadPoolExecutor(max_workers=7) as pool:
        collector=reports.WindowArchive(run,target,pool=pool,call=call,command=command_for(run),slots=BoundedSemaphore(3))
        until=time.monotonic()+15
        while collector.advance(observations).get('6')!='CONFIRMED':
            assert time.monotonic()<until
            time.sleep(.01)
        def no_transfer(*args,**kwargs): raise AssertionError('duplicate transfer')
        restored=reports.WindowArchive(run,target,pool=pool,call=call,command=no_transfer,slots=BoundedSemaphore(3))
        until=time.monotonic()+5
        while restored.advance(observations).get('6')!='CONFIRMED':
            assert time.monotonic()<until
            time.sleep(.01)
    assert len(acks)==2 and acks[0]==acks[1]


def test_staging_inventory_scope_never_rewrites_full_inventory(tmp_path, monkeypatch):
    run, source, target, inventory = fixture(tmp_path, monkeypatch)
    full = source/'shared/archives/H06-inventory-closure2.json'
    if not full.exists(): full = source/'shared/archives/H06-inventory.json'
    before = full.read_bytes()
    staged = reports.archive_inventory(run, 6, [], [], staging=True)
    assert staged['materials_only'] is True and staged['units'] == []
    assert full.read_bytes() == before
    assert reports._read_archive_inventory(source, 6, {staged['identity_sha256']}) == staged
    assert reports.archive_inventory(run, 6, [], [], staging=True) == staged
    assert reports.archive_inventory(run, 6, ['EVALUATION-H06'], []) == inventory
    assert reports.archive_inventory(run, 6, [], [], staging=True, status_only=True) == {'status':'IDLE', 'horizon':6}
    archive = object.__new__(reports.WindowArchive)
    archive.run, archive.states = run, {6: {'not_estimable': set()}}
    with pytest.raises(ContractError, match='INVENTORY_DRIFT'):
        archive._plan(6, {'H0': staged})


@pytest.mark.parametrize('failure', [None, 'inventory', 'index', 'index_after_rename'])
def test_staging_hosts_share_one_entity_and_recover_without_window_ack(tmp_path, monkeypatch, failure):
    from concurrent.futures import ThreadPoolExecutor
    import time
    run, source, target, inventory = fixture(tmp_path, monkeypatch,
        run_extra={'host_connections':{'H0':{'ssh_target':'unused'}, 'H1':{'ssh_target':'unused'}}})
    monkeypatch.setattr(reports, '_archive_volume', lambda root:
        {'uuid':'external-volume', 'mount':str(tmp_path), 'filesystem':'exfat'})
    observations = {host:{'state':'RUNNING' if host == 'H1' else 'IDLE',
        'completed_units':['EVALUATION-H06'], 'selection_completed_units':[],
        'postprocess_ready_units':[]} for host in run['host_connections']}
    errors, transfers = [], []
    def call(host, operation, **kwargs):
        assert operation == 'archive_inventory' and kwargs['staging'] is True
        if kwargs.get('status_only'): return {'status':'IDLE', 'horizon':6,
            **({'request_id':kwargs['request']['request_id']} if kwargs.get('request') else {})}
        if failure == 'inventory' and host == 'H1' and not errors:
            errors.append('inventory'); raise ConnectionError('reply lost')
        return inventory
    def command(host, operation, **kwargs):
        transfers.append((host, kwargs['members_pin']['sha256']))
        return command_for(run)(host, operation, **kwargs)
    publish = reports._publish
    def fail_index(path, raw, reason, **kw):
        if failure == 'index' and path.name == 'index.json' and not errors:
            errors.append('index'); raise OSError('index parent not durable')
        return publish(path, raw, reason, **kw)
    monkeypatch.setattr(reports, '_publish', fail_index)
    persist = reports._persist_published
    def fail_barrier(path):
        if failure == 'index_after_rename' and path.name == 'index.json' and not errors:
            errors.append('index_after_rename'); raise OSError('index parent not durable')
        return persist(path)
    monkeypatch.setattr(reports, '_persist_published', fail_barrier)
    with ThreadPoolExecutor(max_workers=7) as pool:
        collector = reports.WindowArchive(run, target, pool=pool, call=call, command=command,
            slots=BoundedSemaphore(3), staging=True)
        deadline = time.monotonic()+15
        while not collector.staged():
            status = collector.advance(observations)
            assert time.monotonic() < deadline, status
            assert len(collector.futures) <= 2 and not collector.complete()
            for state in collector.states.values(): state['retry_at'] = 0
            for record in [*collector.futures.values(), *collector.pending]: record['retry_at'] = 0
            time.sleep(.01)
        saved = json.loads((collector.target/'index.json').read_bytes())
        assert not saved['windows'] and len(saved['staged_inventories']) == 2
        assert set(saved['members']) == set(inventory['members'])
        assert len({key for _,key in transfers}) == len(transfers)
        assert not list((collector.target/'windows').iterdir())
        assert source.is_dir() and status['hosts']['H1']['status'] == 'MATERIALS_SAVED'
        with pytest.raises(ContractError, match='STAGING_CANNOT_CONFIRM'): collector._finish(6)
        before = list(transfers)
        restored = reports.WindowArchive(run, target, pool=pool, call=call, command=command,
            slots=BoundedSemaphore(3), staging=True)
        while not restored.staged():
            restored.advance(observations)
            assert time.monotonic() < deadline
            time.sleep(.01)
        assert before == transfers and not restored.index['windows']


def test_staging_drain_persists_completed_transfer_and_probes_unknown_reader(tmp_path, monkeypatch):
    from concurrent.futures import Future
    run, source, target, inventory = fixture(tmp_path, monkeypatch)
    monkeypatch.setattr(reports, '_archive_volume', lambda root:
        {'uuid':'external-volume', 'mount':str(tmp_path), 'filesystem':'exfat'})
    class Pool:
        def __init__(self): self.calls = []
        def submit(self, fn, *args, **kw):
            future = Future(); self.calls.append((future, fn, args, kw)); return future
    pool = Pool()
    collector = reports.WindowArchive(run, target, pool=pool, call=lambda *a,**kw:None,
        command=command_for(run), slots=BoundedSemaphore(3), staging=True)
    obs = {'H0':{'state':'RUNNING', 'completed_units':['EVALUATION-H06']}}
    collector.advance(obs)
    pool.calls[0][0].set_result(inventory)
    collector.advance(obs)
    active = list(collector.futures.items())
    assert active and len(active) <= 2
    for future, record in active:
        future.set_result(reports.receive_archive(run, collector.target, record,
            command=command_for(run), slots=BoundedSemaphore(3)))
    submissions = len(pool.calls)
    collector.advance(obs, draining=True)
    assert len(pool.calls) == submissions and collector.drained()
    assert json.loads((collector.target/'index.json').read_bytes())['members']
    assert not collector.index['windows'] and not list((collector.target/'windows').iterdir())
    # An unknown old reader is reconciled by the existing directory lease,
    # without creating its inventory or any new transfer while draining.
    key = next(iter(collector.states))
    state = collector.states[key]
    state.pop('expected'); state['reader_pending'] = True
    collector.advance(obs, draining=True)
    assert pool.calls[-1][3]['status_only'] is True and not collector.drained()
    pool.calls[-1][0].set_result({'status':'IDLE', 'horizon':6})
    collector.advance(obs, draining=True)
    assert collector.drained()


def test_staging_excludes_unfinished_appendices_while_host_computes(tmp_path, monkeypatch):
    from concurrent.futures import Future
    run, source, target, inventory = fixture(tmp_path, monkeypatch)
    run['units'] += [{'unit_id':'PRIMARY-H36-O4', 'kind':'PRIMARY', 'horizon':36},
        {'unit_id':'EVALUATION-H36', 'kind':'EVALUATION', 'horizon':36}]
    run['evaluation_decision'] = {'purpose':'UNFITTED scope test'}
    monkeypatch.setattr(reports, '_archive_version', lambda _: {'closure_version':2})
    monkeypatch.setattr(reports, '_archive_volume', lambda root:
        {'uuid':'external-volume', 'mount':str(tmp_path), 'filesystem':'exfat'})
    class Pool:
        def __init__(self): self.calls = []
        def submit(self, fn, *args, **kw):
            future = Future(); self.calls.append((future, args, kw)); return future
    pool = Pool()
    collector = reports.WindowArchive(run, target, pool=pool, call=lambda *a,**k:None,
        command=command_for(run), slots=BoundedSemaphore(3), staging=True)
    obs = {'H0':{'state':'RUNNING', 'completed_units':[u['unit_id'] for u in run['units']],
        'postprocess_ready_units':['PRIMARY-H36-O4'], 'selection_completed_units':['PRIMARY-H36-O4'],
        'evaluation_amendment_units':['EVALUATION-H06'], 'selection_amendment_units':[]}}
    collector.advance(obs)
    assert len(pool.calls) == 1
    assert len(pool.calls[0][2]['archive_request_id']) == 64
    assert {k:v for k,v in pool.calls[0][2].items() if k != 'archive_request_id'} == {
        'horizon':6, 'units':['EVALUATION-H06'], 'selections':[], 'staging':True}
    # Completion adds a new exact scope; the pending source never enters an
    # earlier inventory or has its publication overwritten by the collector.
    pool.calls[0][0].set_result(inventory)
    obs['H0']['evaluation_amendment_units'] += ['PRIMARY-H36-O4', 'EVALUATION-H36']
    collector.advance(obs)
    assert all(kw.get('horizon') != 36 for _, _, kw in pool.calls)
    # The next scope must wait for this host's admitted streams, otherwise its
    # exclusive inventory lease can stall an already admitted shared sender.
    for _ in range(5):
        for future, spec in list(collector.futures.items()):
            if not future.done():
                future.set_result(reports.receive_archive(run, collector.target, spec,
                    command=command_for(run), slots=BoundedSemaphore(3)))
        collector.advance(obs)
        if any(kw.get('horizon') == 36 for _, _, kw in pool.calls):
            break
    scopes = [kw for _,args,kw in pool.calls if args and args[-1] == 'archive_inventory']
    assert scopes[-1]['horizon'] == 36 and scopes[-1]['units'] == ['EVALUATION-H36','PRIMARY-H36-O4']


def test_staging_singleton_metadata_and_native_alias_have_one_physical_writer(monkeypatch):
    from collections import deque
    archive = object.__new__(reports.WindowArchive)
    archive.run, archive.staging = {'identity':'run'}, True
    archive.member_pins, archive.blobs, archive.reserved = {}, {}, {}
    archive.pending, archive.device = deque(), 1
    archive.states = {key:{'units':{unit}, 'training':set(), 'not_estimable':set()}
        for key,unit in [('first','E1'),('second','E2')]}
    monkeypatch.setattr(reports,'same_batch_generations',lambda _: {'run':'source'})
    def inventory(unit,name,native):
        return n._sealed({'kind':'PADML_WINDOW_ARCHIVE_INVENTORY_V1','run_identity':'run',
            'horizon':6,'materials_only':True,'units':[unit],'selections':[],
            'members':{name:{'sha256':'a'*64,'size_bytes':8,'native_file':native}}})
    archive._plan(6,{'H0':inventory('E1','shared/one.txt',False)},state_key='first')
    archive._plan(6,{'H1':inventory('E2','shared/two.f64',True)},state_key='second')
    assert len(archive.pending) == 1
    assert archive.states['second']['shared'] == {'shared/two.f64':('first','shared/one.txt')}


def test_archive_lost_sender_requires_exact_two_exit_observations(tmp_path, monkeypatch):
    from concurrent.futures import Future
    run, source, target, inventory = fixture(tmp_path, monkeypatch)
    spec = record(inventory, ['shared/model.f64'], target)
    def lost_command(*a,**kw): return [sys.executable, '-c', 'raise SystemExit(255)']
    with pytest.raises(reports._ArchiveSenderUnknown) as failed:
        reports.receive_archive(run,target,spec,command=lost_command,slots=BoundedSemaphore(3))
    request = failed.value.request
    assert request['offset'] == 0 and request['inventory_identity'] == inventory['identity_sha256']
    assert len(request['request_id']) == 64
    monkeypatch.setattr(reports,'_archive_volume',lambda _:
        {'uuid':'external-volume','mount':str(tmp_path),'filesystem':'exfat'})
    class Pool:
        def __init__(self): self.calls = []
        def submit(self,fn,*args,**kw):
            f=Future();self.calls.append((f,fn,args,kw));return f
    pool=Pool()
    collector=reports.WindowArchive(run,target,pool=pool,call=lambda *a,**k:None,
        command=lost_command,slots=BoundedSemaphore(3),staging=True)
    obs={'H0':{'state':'RUNNING','completed_units':['EVALUATION-H06']}}
    collector.advance(obs);pool.calls[0][0].set_result(inventory);collector.advance(obs)
    future, actual = next(iter(collector.futures.items()))
    with pytest.raises(reports._ArchiveSenderUnknown) as actual_failure:
        reports.receive_archive(run,collector.target,actual,command=lost_command,slots=BoundedSemaphore(3))
    request=actual_failure.value.request
    future.set_exception(actual_failure.value)
    # Retain the UNKNOWN slot. Local SSH exit is not an admitted retry.
    collector.advance(obs,draining=True)
    assert future in collector.futures and not collector.drained()
    for response in [{'status':'IN_PROGRESS','horizon':6,'reason':'ARCHIVE_SENDER_ACTIVE'},
                     {'status':'IDLE','horizon':6,'request_id':request['request_id']},
                     {'status':'IDLE','horizon':6,'request_id':request['request_id']}]:
        actual['retry_at']=0;collector.advance(obs,draining=True)
        probe=actual['sender_probe']
        assert pool.calls[-1][3]['sender_request'] == request
        assert pool.calls[-1][3]['status_only'] is True
        probe.set_result(response);collector.advance(obs,draining=True)
        if actual.get('sender_idle_observations',0)<2:
            assert future in collector.futures and not collector.drained()
    assert future not in collector.futures and actual in collector.pending
    assert not collector.index['windows']
    # A second interrupted attempt needs its own two observations, not the
    # previous attempt's counter (which must neither release nor hang it).
    collector.pending.remove(actual)
    second=Future();second.set_exception(actual_failure.value);collector.futures[second]=actual
    actual['retry_at']=0;collector.advance(obs,draining=True)
    assert actual.get('sender_idle_observations',0)==0
    for count in (1,2):
        actual['retry_at']=0;collector.advance(obs,draining=True)
        actual['sender_probe'].set_result({'status':'IDLE','horizon':6,'request_id':request['request_id']})
        collector.advance(obs,draining=True)
        assert (second in collector.futures)==(count==1)


def test_archive_sender_probe_detects_preimport_adapter_without_scanning_payload(tmp_path,monkeypatch):
    from types import SimpleNamespace
    run, source, _, _ = fixture(tmp_path,monkeypatch)
    request={'request_id':'a'*64}
    line='123 123 Thu Oct 8 23:00:00 2026 python -c bootstrap {"archive_request_id":"'+'a'*64+'"}\n'
    monkeypatch.setattr(reports.subprocess,'run',lambda *a,**kw:SimpleNamespace(stdout=line))
    value=reports.archive_inventory(run,6,[],[],status_only=True,sender_request=request)
    assert value['status']=='IN_PROGRESS' and value['processes'][0]['pid']==123
    monkeypatch.setattr(reports.subprocess,'run',lambda *a,**kw:SimpleNamespace(stdout=''))
    assert reports.archive_inventory(run,6,[],[],status_only=True,sender_request=request)=={
        'status':'IDLE','horizon':6,'request_id':'a'*64}


@pytest.mark.parametrize('signal_name', ['SIGTERM','SIGKILL'])
def test_archive_local_sender_signal_is_not_remote_exit(tmp_path,monkeypatch,signal_name):
    run,source,target,inventory=fixture(tmp_path,monkeypatch)
    spec=record(inventory,['shared/model.f64'],target)
    command=lambda *a,**kw:[sys.executable,'-c',
        'import os,signal;os.kill(os.getpid(),signal.'+signal_name+')']
    with pytest.raises(reports._ArchiveSenderUnknown):
        reports.receive_archive(run,target,spec,command=command,slots=BoundedSemaphore(3))
    assert not (target/'objects'/spec['pins']['shared/model.f64']['sha256']).exists()


def test_staging_peer_transfer_success_preserves_original_failure(tmp_path,monkeypatch):
    from concurrent.futures import Future
    run, source, target, inventory = fixture(tmp_path,monkeypatch)
    monkeypatch.setattr(reports,'_archive_volume',lambda _:
        {'uuid':'external-volume','mount':str(tmp_path),'filesystem':'exfat'})
    class Pool:
        def __init__(self): self.calls=[]
        def submit(self,fn,*a,**kw):
            f=Future();self.calls.append(f);return f
    pool=Pool()
    collector=reports.WindowArchive(run,target,pool=pool,call=lambda *a,**kw:None,
        command=command_for(run),slots=BoundedSemaphore(3),staging=True)
    obs={'H0':{'state':'RUNNING','completed_units':['EVALUATION-H06']}}
    collector.advance(obs);pool.calls[0].set_result(inventory);collector.advance(obs)
    (failure,failed_record),(success,record)=list(collector.futures.items())
    failure.set_exception(OSError('original A transfer failure'))
    success.set_result(reports.receive_archive(run,collector.target,record,
        command=command_for(run),slots=BoundedSemaphore(3)))
    status=collector.advance(obs,draining=True)
    assert failed_record in collector.pending and failed_record['retry_at']>reports.time.monotonic()
    assert status['hosts']['H0']['status']=='RETRY_WAIT'
    assert any('original A transfer failure' in reason for reason in status['hosts']['H0']['reasons'])
    assert json.loads((collector.target/'index.json').read_bytes())['members']


@pytest.mark.parametrize('failure', ['inventory','transfer','ack','volume','missing','corrupt'])
def test_archive_failure_preserves_sources_and_dispatch_can_continue(tmp_path,monkeypatch,failure):
    from concurrent.futures import ThreadPoolExecutor
    import time
    run,source,target,inventory=fixture(tmp_path,monkeypatch)
    volume={'uuid':'external-volume','mount':str(tmp_path),'filesystem':'exfat'}
    monkeypatch.setattr(reports,'_archive_volume',lambda root:volume)
    observations={'H0':{'completed_units':['EVALUATION-H06'], 'selection_completed_units':[],
                         'postprocess_ready_units':[]}}
    injected=[]; acks=[]
    def call(host,operation,**kwargs):
        if operation == 'archive_inventory' and kwargs.get('status_only'):
            return {'status':'IDLE','horizon':kwargs['horizon'],
                'request_id':kwargs['request']['request_id']}
        if failure == 'inventory' and operation == 'archive_inventory' and not injected:
            injected.append(1); raise ConnectionError('inventory interrupted')
        if operation == 'archive_inventory': return inventory
        if failure == 'ack' and not injected:
            injected.append(1); raise ConnectionError('confirmation interrupted')
        acks.append(1); return {'status':'CONFIRMED'}
    def command(*args,**kwargs):
        if failure == 'transfer' and not injected:
            injected.append(1)
            return [sys.executable,'-c','import sys;sys.stdout.buffer.write(b"part");sys.exit(1)']
        return command_for(run)(*args,**kwargs)
    with ThreadPoolExecutor(max_workers=7) as pool:
        archive=reports.WindowArchive(run,target,pool=pool,call=call,command=command,slots=BoundedSemaphore(3))
        if failure == 'volume':
            def unavailable(root):
                if not injected:
                    injected.append(1); raise OSError('volume unavailable')
                return volume
            monkeypatch.setattr(reports,'_archive_volume',unavailable)
        deadline=time.monotonic()+15
        failures=[]
        while archive.advance(observations).get('6') != 'CONFIRMED':
            assert time.monotonic()<deadline
            assert source.is_dir()
            # The caller reaches its existing dispatch step even on failure.
            assert pool.submit(lambda:'independent work').result(timeout=2)=='independent work'
            for state in archive.states.values():
                if state.get('error'):
                    failures.append(state['error']); state['retry_at']=0
                for pending in ('inventory_readers','ack_pending'):
                    for request in state.get(pending,{}).values(): request['retry_at']=0
            time.sleep(.01)
        assert acks
        if failure in ('missing','corrupt'):
            entity=next(item for name,item in archive.index['members'].items() if name=='shared/model.f64')
            physical=archive.target/entity['storage']
            original=physical.read_bytes()
            if failure=='missing':physical.unlink()
            else:physical.write_bytes(b'x'*len(original))
            acks.clear()
            restored=reports.WindowArchive(run,target,pool=pool,call=call,command=command,slots=BoundedSemaphore(3))
            deadline=time.monotonic()+10
            while True:
                status=restored.advance(observations)
                if failure=='corrupt' and isinstance(status.get('restore'),dict) and status['restore'].get('status')=='ATTENTION_REQUIRED':
                    assert not acks and source.is_dir(); break
                if status.get('6')=='CONFIRMED':
                    assert failure=='missing' and physical.read_bytes()==original; break
                assert time.monotonic()<deadline
                time.sleep(.01)
        else:
            assert failures


def _archive_generation_fixture(tmp_path, monkeypatch, *, upgrade=True):
    """Small exact source pair; production pin/archive/carrier readers stay real."""
    import zipfile
    from padml import f4, run as runs
    from padml.bundle import sha256_bytes
    package = Path(f4.__file__).parent.parent
    names = ('dependency-lock.json', 'AGENTS.md')
    current = {name: (package/name).read_bytes() for name in names}
    previous = {**current, 'AGENTS.md': current['AGENTS.md'] + b'\n# prior fixture executor\n'}
    monkeypatch.setattr(f4, 'F45_SOURCE_MEMBERS', names)
    monkeypatch.setattr(runs, '_f45_integrated_source_pair', lambda name, old, new:
        name == 'AGENTS.md' and old == previous[name] and new == current[name])
    pin_root = tmp_path/'original-pins'; pin_root.mkdir()
    old_source = pin_root/'source.zip'
    body = {'schema_version':'1.0.0','kind':'PADML_F45_DIRECT_SOURCE_BUNDLE_V1',
        'status':'COMPILED','python_modules':['padml.f4','padml.f5','padml.f5_sensitivity',
            'padml.f5_application','padml.worker','padml.run'],
        'members':[{'path':name,'sha256':sha256_bytes(previous[name]),'size_bytes':len(previous[name])}
            for name in names]}
    with zipfile.ZipFile(old_source, 'w', compression=zipfile.ZIP_DEFLATED) as z:
        z.writestr('manifest.json', canonical_json_bytes(n._sealed(body)))
        for name, raw in previous.items(): z.writestr(name, raw)
    extra = {'source_identity':n._sha({name:sha256_bytes(raw) for name,raw in previous.items()}),
        'source_bundle_sha256':sha256_file(old_source),
        'environment':{'lock_sha256':sha256_bytes(current['dependency-lock.json'])},
        'science_decision':json.loads((package/'science-decision.json').read_bytes()),
        'budgets':{'retained_bytes_per_replicate':262144}}
    old, source, archive_root, inventory = fixture(tmp_path, monkeypatch, run_extra=extra)
    old_manifest = pin_root/'run.json'; old_manifest.write_bytes(canonical_json_bytes(old))
    new = {**old, 'source_identity':n._sha({name:sha256_bytes(raw) for name,raw in current.items()}),
        'source_bundle_sha256':'d'*64, 'unit_predecessor':{
            'run_path':str(old_manifest),'run_sha256':sha256_file(old_manifest),
            'source_path':str(old_source),'source_sha256':sha256_file(old_source)}}
    new['identity'] = n._sha({key:value for key,value in new.items() if key != 'identity'})
    assert runs.f45_unit_predecessors(new) == [old]
    monkeypatch.setattr(reports, '_archive_volume', lambda root:
        {'uuid':'external-volume','mount':str(tmp_path),'filesystem':'exfat'})
    target = reports.prepare_archive(old, archive_root)
    assert json.loads((target/'run.json').read_bytes()) == old
    if upgrade:
        assert reports.prepare_archive(new, archive_root) == target
        assert json.loads((target/'run.json').read_bytes()) == new
    return old, new, source, archive_root, target, inventory, pin_root


def _archive_small_member(source, target, name):
    path = source/name
    pin = {'sha256':sha256_file(path),'size_bytes':path.stat().st_size}
    storage = 'objects/' + pin['sha256']
    reports._publish(target/storage, path.read_bytes(), 'TEST_ARCHIVE_DRIFT')
    return {'storage':storage,'member':None,'pin':pin,'physical':pin}


def test_same_batch_archive_upgrade_offline_reads_both_producers(tmp_path, monkeypatch):
    from padml import carriers, f4, run as runs
    old, new, source, archive_root, target, inventory, pin_root = _archive_generation_fixture(tmp_path, monkeypatch)
    current_manifest = tmp_path/'current.json'; current_manifest.write_bytes(canonical_json_bytes(new))
    monkeypatch.setenv('PADML_F45_RUN_PATH', str(current_manifest))
    note = source/'shared/new-note.json'; note.write_bytes(canonical_json_bytes({'new':'consumer'}))
    write_carrier(source/'new-result.zip', {}, references={'note.json':note})
    names = {*inventory['members'], 'shared/new-note.json', 'new-result.zip'}
    members = {name:_archive_small_member(source,target,name) for name in names}
    index = n._sealed({'kind':'PADML_WINDOW_ARCHIVE_INDEX_V1','run_identity':new['identity'],
        'source_identity':new['source_identity'],'members':members,'windows':{}})
    (target/'index.json').write_bytes(canonical_json_bytes(index))
    original_receipt = (source/'units/EVALUATION-H06/unit.json').read_bytes()
    shutil.rmtree(pin_root); shutil.rmtree(source)
    monkeypatch.setenv('PADML_F45_RUN_PATH', str(target/'run.json'))
    monkeypatch.setenv('PADML_ARCHIVE_INDEX', str(target/'index.json'))
    assert runs.f45_unit_predecessors(new) == [old]
    assert reports.prepare_archive(new,archive_root) == target  # Offline idempotent reopen.
    with open_carrier(Path(old['run_root'])/'units/EVALUATION-H06/result.zip') as outer:
        with open_carrier(io.BytesIO(outer.read('producer.zip'))) as inner:
            value = json.loads(inner.read('number.json'))
            assert pooled_matrix(value) == [[.8]*37]
            assert json.loads(inner.read('note.json')) == {'note':'unique'}
    with open_carrier(Path(new['run_root'])/'new-result.zip') as archive:
        assert json.loads(archive.read('note.json')) == {'new':'consumer'}
    assert reports.archived_bytes('units/EVALUATION-H06/unit.json',new) == original_receipt
    with pytest.raises(ContractError,match='CARRIER_PRODUCER_DRIFT'):
        carriers._admitted_producer({'producer':'f'*64},new)
    # This is a minimal archive schema fixture, not a formal run loader test.
    monkeypatch.setattr(runs,'load_f45_run',lambda path: json.loads(path.read_bytes()))
    assert n._sha(f4._f45_same_run_source(old['source_identity'])) == old['source_identity']
    monkeypatch.delenv('PADML_ARCHIVE_INDEX')
    with pytest.raises(ContractError,match='PREDECESSOR_BYTES_DRIFT'):
        runs.f45_unit_predecessors(new)


@pytest.mark.parametrize('kind', ['run','source'])
@pytest.mark.parametrize('damage', ['missing','changed'])
def test_same_batch_archive_predecessor_damage_is_not_hidden_by_cache(tmp_path,monkeypatch,kind,damage):
    from padml import run as runs
    old,new,source,archive_root,target,inventory,pin_root = _archive_generation_fixture(tmp_path,monkeypatch)
    (target/'index.json').write_bytes(canonical_json_bytes(n._sealed({
        'kind':'PADML_WINDOW_ARCHIVE_INDEX_V1','run_identity':new['identity'],
        'source_identity':new['source_identity'],'members':{},'windows':{}})))
    monkeypatch.setenv('PADML_ARCHIVE_INDEX',str(target/'index.json'))
    shutil.rmtree(pin_root)
    assert runs.f45_unit_predecessors(new) == [old]
    path = target/'objects'/new['unit_predecessor'][kind+'_sha256']
    if damage=='missing': path.unlink()
    else: path.write_bytes(path.read_bytes() + b'changed')
    with pytest.raises(ContractError,match='PREDECESSOR_BYTES_DRIFT'):
        runs.f45_unit_predecessors(new)


def test_same_batch_archive_inventory_preserves_original_identity_and_plan(tmp_path,monkeypatch):
    from collections import deque
    old,new,source,archive_root,target,inventory,pin_root = _archive_generation_fixture(tmp_path,monkeypatch)
    path = source/'shared/archives/H06-inventory.json'
    before = path.read_bytes()
    reused = reports.archive_inventory(new,6,['EVALUATION-H06'],[])
    assert reused == inventory and path.read_bytes() == before
    archive = object.__new__(reports.WindowArchive)
    archive.run,archive.target,archive.device = new,target,target.stat().st_dev
    archive.blobs,archive.blob_stamps,archive.pending = {},{},deque()
    archive.states = {6:{'units':['EVALUATION-H06'],'training':[]}}
    archive._plan(6,{'H0':reused})
    assert archive.states[6]['inventories']['H0']['identity_sha256'] == inventory['identity_sha256']
    with pytest.raises(ContractError,match='ARCHIVE_INVENTORY_DRIFT'):
        reports.archive_inventory(new,6,[],[])
    assert path.read_bytes() == before


@pytest.mark.parametrize('missing_object', [False, True])
def test_same_batch_completed_window_resume_keeps_receipt_and_repairs_only_missing_object(tmp_path,monkeypatch,missing_object):
    from concurrent.futures import ThreadPoolExecutor
    import time
    from padml import run as runs
    old,new,source,archive_root,target,inventory,pin_root = _archive_generation_fixture(tmp_path,monkeypatch,upgrade=False)
    owner=[old]
    current_manifest=tmp_path/'dispatcher-current.json'
    current_manifest.write_bytes(canonical_json_bytes(old))
    monkeypatch.setattr(runs,'load_f45_run',lambda p: json.loads(p.read_bytes()))
    observed={'state':'UNKNOWN','completed_units':['EVALUATION-H06'],
        'selection_completed_units':[],'postprocess_ready_units':[]}
    monkeypatch.setattr(runs,'_f45_host_observation',lambda r: observed)
    calls,transfers=[],[]
    def call(host,operation,**kw):
        calls.append((owner[0]['identity'],operation))
        return runs._f45_remote_operation({'run':str(current_manifest),'identity':owner[0]['identity'],
            'operation':operation,**kw})
    def command(host,operation,**kw):
        transfers.append((owner[0]['identity'],kw['members_pin']))
        return command_for(owner[0])(host,operation,**kw)
    def finish(archive):
        deadline=time.monotonic()+15
        while archive.advance({'H0':observed}).get('6')!='CONFIRMED':
            assert time.monotonic()<deadline, archive.states
            time.sleep(.01)
    with ThreadPoolExecutor(max_workers=7) as pool:
        first=reports.WindowArchive(old,archive_root,pool=pool,call=call,command=command,slots=BoundedSemaphore(3))
        finish(first)
        window=target/'windows/H06.json'; confirmed=source/'shared/archives/H06-confirmed.json'
        window_bytes,confirmed_bytes=window.read_bytes(),confirmed.read_bytes()
        item=first.index['members']['shared/model.f64']; physical=target/item['storage']
        original=physical.read_bytes()
        if missing_object:physical.unlink()
        owner[0]=new;current_manifest.write_bytes(canonical_json_bytes(new))
        second=reports.WindowArchive(new,archive_root,pool=pool,call=call,command=command,slots=BoundedSemaphore(3))
        finish(second)
    repaired=[names for identity,names in transfers if identity==new['identity']]
    envelope=canonical_json_bytes(['shared/model.f64'])
    assert repaired==([{'sha256':hashlib.sha256(envelope).hexdigest(),'size_bytes':len(envelope)}]
        if missing_object else [])
    assert physical.read_bytes()==original
    assert window.read_bytes()==window_bytes and confirmed.read_bytes()==confirmed_bytes
    assert json.loads((target/'run.json').read_bytes())==new
    assert (new['identity'],'archive_confirm') in calls
    assert source.is_dir()  # UNKNOWN owner still forbids retirement.


from pathlib import Path
import json

import pytest

from padml import run as runs
from padml.bundle import ContractError, canonical_json_bytes, sha256_bytes


def _score_report_path_case(tmp_path, monkeypatch):
    control = tmp_path/'control'; control.mkdir()
    former = tmp_path/'unavailable-former-Linux-root'
    previous = {'identity': 'b'*64, 'source_identity': 'c'*64}
    report = {'kind': 'PADML_F45_SCORE_REPAIR_V1', 'run_id': 'UNFITTED', 'unit_id': 'PRIMARY-H06-O5',
        'source_run_identity': previous['identity'], 'request_identity_sha256': 'd'*64,
        'coordinates': [{'source_record': {'path': f'M{i:02d}', 'family': 'RSF'},
            'decision': 'REFIT', 'reason': 'UNFITTED pinned engineering report'} for i in range(1, 15)]}
    raw = canonical_json_bytes({'score_repair': report}); digest = sha256_bytes(raw)
    run = dict(run_root=str(former), run_id='UNFITTED', source_identity='e'*64,
        score_repair={'path': 'repairs/score-repair.json', 'sha256': digest, 'size_bytes': len(raw)})
    run['identity'] = sha256_bytes(canonical_json_bytes(run))
    manifest = control/'run.json'; manifest.write_bytes(canonical_json_bytes(run))
    path = control/run['score_repair']['path']; path.parent.mkdir(); path.write_bytes(raw)
    monkeypatch.delenv('PADML_ARCHIVE_INDEX', raising=False)
    monkeypatch.delenv('PADML_F45_RUN_PATH', raising=False)
    monkeypatch.setattr(runs, 'f45_unit_predecessors', lambda _: [previous])
    return run, report, manifest, path, raw


@pytest.mark.parametrize('binding', ['explicit_manifest', 'dispatcher_environment'])
def test_control_side_report_keeps_linux_root_and_uses_one_bound_copy(tmp_path, monkeypatch, binding):
    run, report, manifest, path, raw = _score_report_path_case(tmp_path, monkeypatch)
    kwargs = {'manifest_path': manifest}
    if binding == 'dispatcher_environment':
        monkeypatch.setenv('PADML_F45_RUN_PATH', str(manifest)); kwargs = {}
    value = runs.f45_score_repair(run, **kwargs)
    assert value == {**report, 'report_sha256': run['score_repair']['sha256']}
    assert path.read_bytes() == raw and not Path(run['run_root']).exists()
    assert json.loads(manifest.read_bytes()) == run


@pytest.mark.parametrize('damage', ['missing_report', 'changed_bytes', 'wrong_manifest', 'symlink', 'native_drift'])
def test_report_path_failure_never_falls_back_to_unqualified_bytes(tmp_path, monkeypatch, damage):
    run, report, manifest, path, raw = _score_report_path_case(tmp_path, monkeypatch)
    if damage == 'missing_report': path.unlink()
    elif damage == 'changed_bytes': path.write_bytes(raw.replace(b'UNFITTED', b'CHANGED!'))
    elif damage == 'wrong_manifest':
        manifest.write_bytes(canonical_json_bytes({**run, 'score_repair': {**run['score_repair'], 'sha256': 'f'*64}}))
    elif damage == 'symlink':
        target = path.with_name('original.json'); path.rename(target); path.symlink_to(target)
    else:
        # Present native bytes take precedence; a good adjacent copy cannot mask drift.
        native = Path(run['run_root'])/run['score_repair']['path']; native.parent.mkdir(parents=True)
        native.write_bytes(raw.replace(b'UNFITTED', b'CHANGED!'))
    with pytest.raises(ContractError, match='F45_SCORE_REPAIR_REPORT_(INVALID|DRIFT)'):
        runs.f45_score_repair(run, manifest_path=manifest)


def test_prepare_archive_preserves_report_then_consumes_without_linux_or_control_copy(tmp_path, monkeypatch):
    from padml import reports
    run, report, manifest, source, raw = _score_report_path_case(tmp_path, monkeypatch)
    monkeypatch.setenv('PADML_F45_RUN_PATH', str(manifest))
    monkeypatch.setattr(reports, '_archive_volume', lambda _: {'UNFITTED': 'temporary fixture volume'})
    archive = tmp_path/'archive'; archive.mkdir()
    target = reports.prepare_archive(run, archive)
    physical = target/'objects'/run['score_repair']['sha256']
    assert physical.read_bytes() == raw
    assert json.loads((target/'run.json').read_bytes()) == run
    before = physical.stat().st_ino
    reports.prepare_archive(run, archive)
    assert physical.stat().st_ino == before and list((target/'objects').iterdir()) == [physical]
    source.unlink(); manifest.unlink()
    index = target/'index.json'; index.write_bytes(b'{}')
    monkeypatch.setenv('PADML_ARCHIVE_INDEX', str(index))
    assert runs.f45_score_repair(run) == {**report, 'report_sha256': run['score_repair']['sha256']}
    assert not Path(run['run_root']).exists()
    physical.write_bytes(raw.replace(b'UNFITTED', b'CHANGED!'))
    with pytest.raises(ContractError, match='F45_SCORE_REPAIR_REPORT_INVALID'):
        runs.f45_score_repair(run)


def test_inventory_nested_stored_member_reads_only_metadata_ranges():
    """Backward central-directory seeks must not replay multi-MiB prefixes."""
    import zipfile
    def carrier(entries):
        result = io.BytesIO()
        with zipfile.ZipFile(result, 'w', compression=zipfile.ZIP_STORED) as output:
            for name, raw in entries.items():
                output.writestr(name, raw)
        return result.getvalue()
    leaf = carrier({'large.bin': b'x' * (8 * 1024**2),
                    '__padml_references__.json': b'{"members":{}}'})
    middle = carrier({'leaf.zip': leaf, 'other.bin': b'y' * 1024})
    class Counted(io.BytesIO):
        read_bytes = 0
        def read(self, size=-1):
            raw = super().read(size)
            self.read_bytes += len(raw)
            return raw
    source = Counted(carrier({'middle.zip': middle}))
    with zipfile.ZipFile(source) as outer:
        with reports._StoredArchiveMember(outer, outer.getinfo('middle.zip')) as window:
            with zipfile.ZipFile(window) as nested:
                with reports._StoredArchiveMember(nested, nested.getinfo('leaf.zip')) as child:
                    with zipfile.ZipFile(child) as final:
                        assert final.read('__padml_references__.json') == b'{"members":{}}'
    assert source.read_bytes < 256 * 1024


def test_inventory_qualified_closure_skips_scan_and_missing_member_still_fails(tmp_path, monkeypatch):
    import time
    run, source, _, expected = fixture(tmp_path, monkeypatch)
    now = time.time_ns
    monkeypatch.setattr(time, 'time_ns', lambda: now() + 10_000_000_000)
    assert reports.archive_inventory(run, 6, ['EVALUATION-H06'], []) == expected
    def no_zip(*args, **kwargs):
        raise AssertionError('stable inventory rescanned a ZIP')
    monkeypatch.setattr(reports.zipfile, 'ZipFile', no_zip)
    assert reports.archive_inventory(run, 6, ['EVALUATION-H06'], []) == expected
    (source / 'shared/model.f64').unlink()
    with pytest.raises(ContractError, match='REFERENCE_MISSING'):
        reports.archive_inventory(run, 6, ['EVALUATION-H06'], [])


def test_inventory_busy_directory_lease_never_enters_scan_or_owner_lock(tmp_path, monkeypatch):
    import subprocess
    folder = tmp_path / 'shared/archives'
    folder.mkdir(parents=True)
    owner = tmp_path / 'active.lock'
    owner.write_bytes(b'unchanged owner')
    old = (owner.stat().st_ino, owner.read_bytes())
    script = ('import fcntl,os,sys; '
              'fd=os.open(sys.argv[1],os.O_RDONLY); '
              'fcntl.flock(fd,fcntl.LOCK_EX); '
              'print("LOCKED",flush=True); sys.stdin.read(); os.close(fd)')
    child = subprocess.Popen([sys.executable, '-B', '-c', script, str(folder)],
        stdin=subprocess.PIPE, stdout=subprocess.PIPE, text=True)
    try:
        assert child.stdout.readline().strip() == 'LOCKED'
        def no_scan(*args, **kwargs):
            raise AssertionError('busy reader started a duplicate inventory')
        monkeypatch.setattr(reports, '_archive_inventory_locked', no_scan)
        value = reports.archive_inventory({'run_root': str(tmp_path)}, 12, [], [])
        assert value == {'status': 'IN_PROGRESS', 'horizon': 12,
                         'reason': 'ARCHIVE_READER_ACTIVE'}
        assert (owner.stat().st_ino, owner.read_bytes()) == old
    finally:
        child.stdin.close()
        child.wait(timeout=5)
        child.stdout.close()
    assert child.returncode == 0


def test_inventory_upgrade_adds_all_1000_selection_members_and_preserves_old_inventory(tmp_path, monkeypatch):
    unit = {'unit_id': 'FULL0-H06', 'kind': 'FULL0', 'horizon': 6}
    run, source, _, original = fixture(tmp_path, monkeypatch, run_extra={'units': [
        {'unit_id': 'EVALUATION-H06', 'kind': 'EVALUATION', 'horizon': 6}, unit]})
    prefix = 'units/EVALUATION-H06/selection/FULL0-H06'
    root = source / prefix
    (root / 'replicates').mkdir(parents=True)
    members = {}
    for r in range(1, 1001):
        name = f'replicates/B{r:04d}.json'
        raw = canonical_json_bytes({'replicate': r})
        (root / name).write_bytes(raw)
        members[name] = {'sha256': hashlib.sha256(raw).hexdigest(), 'size_bytes': len(raw)}
    summary = n._sealed({'status': 'COMPLETED', 'source_unit': unit['unit_id'],
        'replicate_count': 1000, 'replicate_members': members})
    (root / 'result.json').write_bytes(canonical_json_bytes(summary))
    (root / 'selection.csv').write_bytes(b'metric,value\nibs,0\n')
    old_body = {k: v for k, v in original.items() if k != 'identity_sha256'}
    old_body['selections'] = [unit['unit_id']]
    old_body['members'] = dict(old_body['members'])
    for name in ('result.json', 'selection.csv'):
        raw = (root / name).read_bytes()
        old_body['members'][prefix + '/' + name] = {
            'sha256': hashlib.sha256(raw).hexdigest(), 'size_bytes': len(raw),
            'native_file': name.endswith('.csv') or len(raw) >= 1024**2}
    old = n._sealed(old_body)
    path = source / 'shared/archives/H06-inventory.json'
    old_raw = canonical_json_bytes(old)
    path.write_bytes(old_raw)
    current = reports.archive_inventory(run, 6, ['EVALUATION-H06'], [unit['unit_id']])
    assert path.read_bytes() == old_raw
    assert len(current['members']) == len(old['members']) + 1000
    assert all(current['members'][prefix + '/' + name] == {**pin, 'native_file': False}
               for name, pin in members.items())
    assert reports._read_archive_inventory(source, 6, {old['identity_sha256']}) == old
    assert reports._read_archive_inventory(source, 6, {current['identity_sha256']}) == current
    result = io.BytesIO()
    reports.archive_send(run, 6, current['identity_sha256'],
        [prefix + '/replicates/B1000.json'], 0, result)
    assert result.getvalue() == (root / 'replicates/B1000.json').read_bytes()


def _selection_offline_archive_fixture(tmp_path, monkeypatch):
    """Real B1000 consumer; the synthetic draws have typed non-estimable metrics."""
    import zipfile
    from padml import f4
    unit = {'unit_id': 'FULL0-H06', 'kind': 'FULL0', 'horizon': 6}
    run, source, target, _ = fixture(tmp_path, monkeypatch, run_extra={'units': [
        {'unit_id': 'EVALUATION-H06', 'kind': 'EVALUATION', 'horizon': 6}, unit]})
    root = source / 'units/EVALUATION-H06/selection/FULL0-H06'
    (root / 'replicates').mkdir(parents=True)
    loaded = {'manifest': {'source_unit': unit['unit_id'], 'identity_sha256': 'c'*64},
              'draws': {'draws': [[0] for _ in range(1000)]}}
    rows = [{'report_month': t, 'metric': m, 'inbag': None, 'oob': None,
             'repeat_values': {'INBAG': [None]*3, 'OOB': [None]*3},
             'optimism': None, 'status': 'NOT_ESTIMABLE',
             'reasons': ['F2_PRIMARY_IBS_NOT_ESTIMABLE']}
            for t in (6, 12, 24, 36) for m in ('ibs', 'uno_c')]
    for r in range(1, 1001):
        value = n._sealed({'kind': 'PADML_F45_SELECTION_REPLICATE_V1',
            **f4._f45_selection_identity(loaded, r), 'status': 'COMPLETED',
            'selected_family': None, 'selection_evidence': [], 'selection_layers': [],
            'selection_status': 'NOT_ESTIMABLE',
            'selection_reasons': ['F2_PRIMARY_IBS_NOT_ESTIMABLE'], 'report_rows': rows})
        (root / f'replicates/B{r:04d}.json').write_bytes(canonical_json_bytes(value))
    saved = f4._reduce_f45_selection(root, loaded, unit)
    (root / 'result.json').write_bytes(canonical_json_bytes(saved))
    (root / 'selection.csv').write_bytes(f4._f45_optimism_csv(saved['report_rows']))
    pack = target / 'packs/selection.zip'
    members = {}
    with zipfile.ZipFile(pack, 'w', compression=zipfile.ZIP_STORED) as archive:
        for path in sorted(p for p in root.rglob('*') if p.is_file()):
            name = path.relative_to(source).as_posix()
            raw = path.read_bytes()
            archive.writestr(name, raw)
            members[name] = {'pin': {'sha256': hashlib.sha256(raw).hexdigest(),
                'size_bytes': len(raw)}, 'storage': 'packs/selection.zip', 'member': name}
    physical = {'sha256': sha256_file(pack), 'size_bytes': pack.stat().st_size}
    for item in members.values():
        item['physical'] = physical
    index = n._sealed({'kind': 'PADML_WINDOW_ARCHIVE_INDEX_V1',
        'run_identity': run['identity'], 'source_identity': run['source_identity'],
        'members': members, 'windows': {}})
    index_path = target / 'index.json'
    index_path.write_bytes(canonical_json_bytes(index))
    monkeypatch.setenv('PADML_ARCHIVE_INDEX', str(index_path))
    shutil.rmtree(source)
    return run, unit, root, loaded, saved, index_path, index


@pytest.mark.parametrize('damage', [None, 'missing', 'wrong_pin'])
def test_selection_b1000_offline_pack_preserves_ids_and_rejects_missing_or_wrong_pin(tmp_path, monkeypatch, damage):
    from padml import f4
    run, unit, root, loaded, saved, index_path, index = _selection_offline_archive_fixture(tmp_path, monkeypatch)
    def no_fit(*args, **kwargs):
        raise AssertionError('offline read invoked scientific computation')
    monkeypatch.setattr(f4, '_f45_selection_replicate', no_fit)
    monkeypatch.setattr(f4, '_f45_optimism_metrics', no_fit)
    if damage is not None:
        name = root.relative_to(Path(run['run_root'])).as_posix() + '/replicates/B0420.json'
        body = {k: v for k, v in index.items() if k != 'identity_sha256'}
        if damage == 'missing':
            del body['members'][name]
        else:
            body['members'][name]['pin'] = {**body['members'][name]['pin'], 'sha256': 'd'*64}
        index_path.write_bytes(canonical_json_bytes(n._sealed(body)))
        with pytest.raises(ContractError):
            f4.load_f45_selection(root, run, unit, loaded=loaded)
    else:
        value = f4.load_f45_selection(root, run, unit, loaded=loaded)
        assert value == saved
        assert len(value['replicate_identities']) == 1000
        assert value['family_selection_counts'] == {'NOT_ESTIMABLE': 1000}
        assert all(row['estimable_replicates'] == 0 for row in value['report_rows'])
    assert not Path(run['run_root']).exists()


def test_inventory_timeout_keeps_reader_unknown_until_same_lease_can_complete(tmp_path, monkeypatch):
    import fcntl
    import subprocess
    from concurrent.futures import Future
    run, source, target, inventory = fixture(tmp_path, monkeypatch)
    monkeypatch.setattr(reports, '_archive_volume', lambda root: {
        'uuid': 'external-volume', 'mount': str(tmp_path), 'filesystem': 'exfat'})
    class ImmediatePool:
        def submit(self, function, *args, **kwargs):
            future = Future()
            try:
                future.set_result(function(*args, **kwargs))
            except Exception as error:
                future.set_exception(error)
            return future
    calls, scans, planned = [], [], []
    scan = reports._archive_inventory_locked
    def counting_scan(*args, **kwargs):
        scans.append(True)
        return scan(*args, **kwargs)
    monkeypatch.setattr(reports, '_archive_inventory_locked', counting_scan)
    def call(host, operation, **kwargs):
        assert operation == 'archive_inventory', 'unconfirmed reader authorized archive ACK'
        calls.append(host)
        if len(calls) == 1:
            raise subprocess.TimeoutExpired('ssh', 60)
        return reports.archive_inventory(run, kwargs['horizon'], kwargs['units'], kwargs['selections'],
            status_only=kwargs.get('status_only',False), request=kwargs.get('request'))
    collector = reports.WindowArchive(run, target, pool=ImmediatePool(), call=call,
        command=command_for(run), slots=BoundedSemaphore(3))
    def plan(horizon, inventories):
        planned.append(inventories)
        collector.states[horizon].update(expected={}, transfers=1)
    monkeypatch.setattr(collector, '_plan', plan)
    observations = {'H0': {'completed_units': ['EVALUATION-H06'],
        'selection_completed_units': [], 'postprocess_ready_units': []}}
    lease = os.open(source / 'shared/archives', os.O_RDONLY)
    try:
        fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
        collector.advance(observations)  # Local SSH has timed out; remote lease persists.
        collector.advance(observations)
        state = collector.states[6]
        assert state['inventory_readers']['H0']['status'] == 'UNKNOWN'
        assert not state['inventory_results'] and not scans and not planned
        state['inventory_readers']['H0']['retry_at'] = 0
        collector.advance(observations)
        collector.advance(observations)
        assert state['inventory_readers']['H0']['status'] == 'UNKNOWN'
        assert not collector.drained()
        assert len(calls) == 2 and not scans and not planned
    finally:
        os.close(lease)
    for _ in range(5):
        state['retry_at'] = 0
        for row in state['inventory_readers'].values(): row['retry_at'] = 0
        collector.advance(observations)
    assert len(scans) == 1 and planned == [{'H0': inventory}]
    assert not state['inventory_readers'] and 'error' not in state


def _closure_window(run, inventory, **version):
    return n._sealed({'kind': 'PADML_WINDOW_ARCHIVE_RECEIPT_V1',
        'run_identity': run['identity'], 'horizon': 6, 'units': ['EVALUATION-H06'],
        'selections': [], 'inventories': {'H0': inventory['identity_sha256']},
        'member_pins_sha256': n._sha({name: {k: pin[k] for k in ('sha256', 'size_bytes')}
            for name, pin in inventory['members'].items()}), 'status': 'ARCHIVED', **version})


def _closure_ack(monkeypatch, run, receipt, **extra):
    from padml import run as runs
    monkeypatch.setattr(runs, 'load_f45_run', lambda path: run)
    monkeypatch.setattr(runs, '_f45_host_observation', lambda value: {'state': 'UNKNOWN'})
    return runs._f45_remote_operation({'run': '/unused/unfitted-run.json',
        'identity': run['identity'], 'operation': 'archive_confirm', 'receipt': receipt, **extra})


def _closure_finish_fixture(run, source, target, old_inventory, new_inventory, old_window):
    """Only existing publication machinery; no SSH, model, metric or bootstrap jobs."""
    from collections import deque
    members = {name: _archive_small_member(source, target, name) for name in old_inventory['members']}
    index = n._sealed({'kind': 'PADML_WINDOW_ARCHIVE_INDEX_V1', 'run_identity': run['identity'],
        'source_identity': run['source_identity'], 'members': members, 'windows': {'6': old_window}})
    reports._publish(target / 'index.json', canonical_json_bytes(index), 'TEST_INDEX_DRIFT')
    reports._publish(target / 'windows/H06.json', canonical_json_bytes(old_window), 'TEST_WINDOW_DRIFT')
    old_objects = {name: (target / item['storage']).stat().st_ino for name, item in members.items()}
    resolved = {name: members.get(name) or _archive_small_member(source, target, name)
                for name in new_inventory['members']}
    archive = object.__new__(reports.WindowArchive)
    archive.run, archive.target, archive.index = run, target, index
    archive.blobs, archive.blob_stamps, archive.pending = {}, {}, deque()
    archive.states = {6: {'units': {'EVALUATION-H06'}, 'training': set(), 'aliases': {},
        'expected': new_inventory['members'], 'resolved': resolved, 'inventories': {'H0': new_inventory}}}
    return archive, old_objects


def _closure_extended_inventory(run, source, original):
    name = 'shared/new-declared.json'
    raw = canonical_json_bytes({'declared': 'already validated closure member'})
    (source / name).write_bytes(raw)
    value = n._sealed({k: v for k, v in original.items() if k != 'identity_sha256'} |
        {'closure_version': 2, 'previous_inventory_identity': original['identity_sha256'],
         'members': {**original['members'], name: {'sha256': hashlib.sha256(raw).hexdigest(),
             'size_bytes': len(raw), 'native_file': False}}})
    (source / 'shared/archives/H06-inventory-closure2.json').write_bytes(canonical_json_bytes(value))
    return value


def test_first_window_can_confirm_closure2_inventory_without_a_previous_window(tmp_path, monkeypatch):
    run, source, _, original = fixture(tmp_path, monkeypatch)
    inventory = _closure_extended_inventory(run, source, original)
    window = _closure_window(run, inventory, closure_version=2)
    assert _closure_ack(monkeypatch, run, window)['status'] == 'CONFIRMED'
    folder = source / 'shared/archives'
    assert json.loads((folder / 'H06-confirmed.json').read_bytes()) == window
    assert not (folder / 'H06-confirmed-closure2.json').exists()
    assert reports._archive_confirmed_head(run, 6) == (window, inventory)


@pytest.mark.parametrize('parent_damage', [None, 'wrong_identity', 'old_pin_changed'])
def test_closure2_append_recovers_lost_parent_ack_without_rewriting_old_window(tmp_path, monkeypatch, parent_damage):
    run, source, target, original = fixture(tmp_path, monkeypatch)
    inventory = _closure_extended_inventory(run, source, original)
    parent = _closure_window(run, original)
    old_raw = canonical_json_bytes(parent)
    archive, old_objects = _closure_finish_fixture(run, source, target, original, inventory, parent)
    archive._finish(6)
    child = archive.states[6]['receipt']
    assert child['previous_window_identity'] == parent['identity_sha256']
    assert (target / 'windows/H06.json').read_bytes() == old_raw
    assert (target / 'windows/H06-closure2.json').read_bytes() == canonical_json_bytes(child)
    assert not (source / 'shared/archives/H06-confirmed.json').exists()
    supplied = parent
    if parent_damage == 'wrong_identity':
        supplied = n._sealed({k: v for k, v in parent.items() if k != 'identity_sha256'} |
                             {'member_pins_sha256': 'd' * 64})
    elif parent_damage == 'old_pin_changed':
        changed = json.loads(canonical_json_bytes(inventory))
        changed['members']['binding/contract.json']['sha256'] = 'd' * 64
        changed = n._sealed({k: v for k, v in changed.items() if k != 'identity_sha256'})
        (source / 'shared/archives/H06-inventory-closure2.json').write_bytes(canonical_json_bytes(changed))
        child = n._sealed({k: v for k, v in child.items() if k != 'identity_sha256'} |
                         {'inventories': {'H0': changed['identity_sha256']}})
    if parent_damage is not None:
        with pytest.raises(ContractError, match='PREDECESSOR_DRIFT'):
            _closure_ack(monkeypatch, run, child, previous_receipt=supplied)
        assert not (source / 'shared/archives/H06-confirmed-closure2.json').exists()
        return
    assert _closure_ack(monkeypatch, run, child, previous_receipt=supplied)['status'] == 'CONFIRMED'
    assert (source / 'shared/archives/H06-confirmed.json').read_bytes() == old_raw
    assert reports._archive_confirmed_head(run, 6) == (child, inventory)
    for name, inode in old_objects.items():
        assert (target / archive.index['members'][name]['storage']).stat().st_ino == inode
    (source / 'shared/archives/H06-confirmed-closure2.json').unlink()
    assert reports._archive_confirmed_head(run, 6) is None  # Never retire from the old ACK.


def test_current_evaluation_rule_requires_declared_appendix_and_appends_one_versioned_head(tmp_path, monkeypatch):
    import time
    from padml import f4, integrated
    old, source, target, legacy = fixture(tmp_path, monkeypatch)
    now = time.time_ns
    monkeypatch.setattr(time, 'time_ns', lambda: now() + 10_000_000_000)
    assert reports.archive_inventory(old, 6, ['EVALUATION-H06'], []) == legacy
    decision = f4.evaluation_decision()
    run = {**old, 'evaluation_decision': decision}
    run['identity'] = n._sha({k: v for k, v in run.items() if k != 'identity'})
    generations = {old['identity']: old['source_identity'], run['identity']: run['source_identity']}
    monkeypatch.setattr(reports, 'same_batch_generations', lambda value: generations)
    monkeypatch.setattr(integrated, 'same_batch_generations', lambda value: generations)
    pending = reports.archive_inventory(run, 6, ['EVALUATION-H06'], [])
    assert pending == {'status': 'IN_PROGRESS', 'horizon': 6, 'reason': 'EVALUATION_APPENDIX_PENDING'}
    prefix = 'units/EVALUATION-H06/evaluation-amendment'
    folder = source / prefix
    folder.mkdir()
    raw = canonical_json_bytes({'metric': 'fixture numeric evidence already consumed'})
    (folder / 'metrics.json').write_bytes(raw)
    value = n._sealed({'kind': 'PADML_EVALUATION_APPENDIX_V1', 'status': 'COMPLETED',
        'producer':{'run_identity':run['identity'],'source_identity':run['source_identity']},
        'decision_sha256': decision['identity_sha256'], 'target_unit': 'EVALUATION-H06',
        'sources': {'units/EVALUATION-H06/result.zip': {k: legacy['members']['units/EVALUATION-H06/result.zip'][k]
                     for k in ('sha256', 'size_bytes')}},
        'members': {'metrics.json': {'sha256': hashlib.sha256(raw).hexdigest(), 'size_bytes': len(raw)}}})
    (folder / 'result.json').write_bytes(canonical_json_bytes(value))
    inventory = reports.archive_inventory(run, 6, ['EVALUATION-H06'], [])
    assert inventory['evaluation_decision_sha256'] == decision['identity_sha256']
    assert all(inventory['members'][name] == pin for name, pin in legacy['members'].items())
    assert {prefix + '/result.json', prefix + '/metrics.json'} <= set(inventory['members'])
    assert reports.archive_inventory(run, 6, ['EVALUATION-H06'], []) == inventory
    parent = _closure_window(old, legacy, closure_version=2)
    _closure_ack(monkeypatch, old, parent)
    archive, old_objects = _closure_finish_fixture(run, source, target, legacy, inventory, parent)
    assert archive._qualified_window_versions() == set()
    archive._finish(6)
    child = archive.states[6]['receipt']
    assert child['previous_window_identity'] == parent['identity_sha256']
    assert child['evaluation_decision_sha256'] == decision['identity_sha256']
    suffix = decision['identity_sha256'][:12]
    assert json.loads((target / f'windows/H06-{suffix}.json').read_bytes()) == child
    assert json.loads((target / 'windows/H06.json').read_bytes()) == parent
    assert _closure_ack(monkeypatch, run, child, previous_receipt=parent)['status'] == 'CONFIRMED'
    assert reports._archive_confirmed_head(run, 6) == (child, inventory)
    assert archive._qualified_window_versions() == {'6'}
    changed_decision = n._sealed({k: v for k, v in decision.items() if k != 'identity_sha256'} |
                                {'registration': 'UNACCEPTED_DIFFERENT_RULE'})
    archive.run = {**run, 'evaluation_decision': changed_decision}
    assert archive._qualified_window_versions() == set()
    for name, inode in old_objects.items():
        assert (target / archive.index['members'][name]['storage']).stat().st_ino == inode


"""Engineering boundaries only; no scientific model/calibration/bootstrap runs."""
import hashlib
import io
import json
import shutil
import zipfile
from pathlib import Path

import pytest

from padml import carriers, f4, f5_sensitivity as a, integrated, nested_loco as n, reports, worker
from padml.bundle import canonical_json_bytes, sha256_file, write_deterministic_zip


def _appendix_retired_input_fixture(tmp_path):
    base = tmp_path / 'source'
    root = base / 'units/EVALUATION-H06'
    root.mkdir(parents=True)
    unit = {'unit_id': 'EVALUATION-H06', 'kind': 'EVALUATION', 'context': 'EVALUATION', 'horizon': 6, 'depends_on': []}
    run = {'kind': 'PADML_INTEGRATED_RAW_RUN_V1', 'run_root': str(base), 'run_id': 'unfitted-storage-fixture',
           'identity': '1'*64, 'source_identity': '2'*64, 'units': [unit],
           'evaluation_decision': f4.evaluation_decision(), 'resource_policy': {}}
    predictions = n._sealed({'patient_ids': ['p1', 'p2'], 'centers': ['36', '38'],
        'survival': {'PRIMARY': [[1.0 - i/100 for i in range(37)]] * 2}})
    compact = root / 'evaluation-input.zip'
    write_deterministic_zip(compact, {'predictions.json': canonical_json_bytes(predictions)})
    write_deterministic_zip(root / 'result.zip', {'evaluation-input.zip': compact,
        'predictions.json': canonical_json_bytes(predictions)}, stored_members={'evaluation-input.zip'})
    result_pin = {'sha256': sha256_file(root/'result.zip'), 'size_bytes': (root/'result.zip').stat().st_size}
    receipt = {'status': 'COMPLETED', 'direct_consumer_completed': True, 'unit_id': unit['unit_id'],
               'run_identity': run['identity'], 'artifacts': {'result.zip': result_pin}}
    (root/'unit.json').write_bytes(canonical_json_bytes(receipt))
    return run, unit, root, predictions, result_pin


def _appendix_retire_input(run, unit, root, monkeypatch):
    monkeypatch.setattr(integrated, 'same_batch_generations', lambda r: {r['identity']: r['source_identity']})
    def actual_file_pins(paths, **kwargs):
        pins = {name: {'sha256': sha256_file(path), 'size_bytes': path.stat().st_size}
                for name, path in paths.items()}
        assert pins == kwargs['expected']
        return pins
    monkeypatch.setattr(worker, '_f45_file_pins', actual_file_pins)
    integrated.retire_completed_outputs(run, unit, root)
    assert not (root/'evaluation-input.zip').exists()
    assert (root/'result.zip').is_file()


def test_appendix_routes_retired_input_through_published_result(tmp_path, monkeypatch):
    run, unit, root, _, result_pin = _appendix_retired_input_fixture(tmp_path)
    _appendix_retire_input(run, unit, root, monkeypatch)
    calls = []
    class ReachedOriginalReader(Exception): pass
    def read(path, observed_run, observed_unit, work_root, *, input_member=None):
        assert path == root/'result.zip'
        assert input_member == 'evaluation-input.zip'
        assert observed_run is run and observed_unit is unit
        with carriers.open_carrier(path) as outer:
            with zipfile.ZipFile(io.BytesIO(outer.read(input_member))) as inner:
                assert 'predictions.json' in inner.namelist()
        calls.append(path)
        raise ReachedOriginalReader
    monkeypatch.setattr(a, 'load_f45_evaluation', read)
    target = root/'evaluation-amendment'
    target.mkdir()
    with pytest.raises(ReachedOriginalReader):
        f4._evaluation_run_loco(run, unit, root, target)
    assert calls == [root/'result.zip']
    assert {'sha256':sha256_file(root/'result.zip'), 'size_bytes':(root/'result.zip').stat().st_size} == result_pin
    assert not (root/'evaluation-input.zip').exists()


def test_cross_time_reads_offline_published_prediction_without_retired_input(tmp_path, monkeypatch):
    run, unit, root, predictions, result_pin = _appendix_retired_input_fixture(tmp_path)
    _appendix_retire_input(run, unit, root, monkeypatch)
    archive = tmp_path/'archive'
    (archive/'packs').mkdir(parents=True)
    name = 'units/EVALUATION-H06/result.zip'
    packed = archive/'packs/result.zip'
    with zipfile.ZipFile(packed, 'w', compression=zipfile.ZIP_STORED) as z:
        z.writestr(name, (root/'result.zip').read_bytes())
    physical = {'sha256':sha256_file(packed), 'size_bytes':packed.stat().st_size}
    index = n._sealed({'kind':'PADML_WINDOW_ARCHIVE_INDEX_V1', 'run_identity':run['identity'],
        'source_identity':run['source_identity'], 'members':{name:{'pin':result_pin, 'storage':'packs/result.zip',
        'member':name, 'physical':physical}}, 'windows':{}})
    index_path=archive/'index.json'; index_path.write_bytes(canonical_json_bytes(index))
    monkeypatch.setenv('PADML_ARCHIVE_INDEX',str(index_path))
    monkeypatch.setattr(carriers, 'run_context', lambda: run)
    monkeypatch.setattr(reports, 'same_batch_generations', lambda r: {r['identity']:r['source_identity']})
    # Scientific handoff validation is outside this storage fixture; matrix shape/value reader is real.
    monkeypatch.setattr(a, '_validate_a12_handoff', lambda value: value)
    shutil.rmtree(Path(run['run_root']))
    result=f4.evaluation_cross_time_report(run,{unit['unit_id']:{'status':'COMPLETED'}})
    loco=result['results']['LOCO']
    assert loco['sources'][unit['unit_id']] == result_pin
    assert loco['within_model_monotonicity']['EVALUATION-H06/PRIMARY']['patient_count'] == 2
    assert not Path(run['run_root']).exists(), 'offline read must not recreate retired source'


@pytest.mark.parametrize('stored', [True, False])
@pytest.mark.parametrize('wrong_pin', [False, True])
def test_evaluation_nested_worker_preserves_member_pin_and_unique_outer(tmp_path, monkeypatch, stored, wrong_pin):
    run, unit, root, _, _ = _appendix_retired_input_fixture(tmp_path)
    source = root/'one-source.zip'
    payload = canonical_json_bytes(n._sealed({'kind':'UNFITTED_STORAGE_BOUNDARY', 'value':[1,2,3]}))
    write_deterministic_zip(source, {'value.json':payload})
    member = 'sources/PRIMARY-H06-O1.zip'
    pin = {'sha256':sha256_file(source), 'size_bytes':source.stat().st_size}
    nested = root/'one-input.zip'
    write_deterministic_zip(nested,{member:source},stored_members={member} if stored else None)
    outer = root/'one-result.zip'
    write_deterministic_zip(outer,{'evaluation-input.zip':nested},stored_members={'evaluation-input.zip'} if stored else None)
    before = outer.read_bytes()
    source.unlink();nested.unlink()
    calls=[]
    def consume(stream, observed_run, observed_unit):
        assert observed_run is run and observed_unit is unit
        with carriers.open_carrier(stream) as archive:
            assert archive.read('value.json') == payload
        calls.append(True)
        return {'consumed':True}
    monkeypatch.setattr(a, 'load_f45_evaluation_source', consume)
    job=(str(outer),run,unit,member,{**pin,'sha256':'f'*64} if wrong_pin else pin,'evaluation-input.zip')
    if wrong_pin:
        from padml.bundle import ContractError
        with pytest.raises(ContractError,match='RESULT_MEMBER_DRIFT'):
            a._f45_evaluation_load_job(job)
        assert not calls
    else:
        assert a._f45_evaluation_load_job(job) == {'consumed':True}
        assert calls == [True]
    assert outer.read_bytes() == before
    assert not source.exists() and not nested.exists()


from pathlib import Path
import pytest
from padml import f4, f5_sensitivity as a, integrated
from padml.bundle import ContractError


@pytest.mark.parametrize('changed_original',[False,True])
def test_completed_evaluation_appendix_ignores_unbound_copy_and_keeps_original_pin(tmp_path,monkeypatch,changed_original):
    run,unit,root,_,pin=_appendix_retired_input_fixture(tmp_path)
    (root/'evaluation-input.zip').write_bytes(b'unqualified leftover copy')
    original=(root/'result.zip').read_bytes()
    if changed_original:
        raw=bytearray(original); raw[-1]^=1
        (root/'result.zip').write_bytes(raw)
    monkeypatch.setattr(integrated,'same_batch_generations',lambda r:{r['identity']:r['source_identity']})
    calls=[]
    class ReachedBoundSource(Exception):pass
    def load(path,run_arg,unit_arg,work_root,*,input_member=None):
        assert path==root/'result.zip' and input_member=='evaluation-input.zip'
        calls.append(path)
        raise ReachedBoundSource
    monkeypatch.setattr(a,'load_f45_evaluation',load)
    expected=ContractError if changed_original else ReachedBoundSource
    with pytest.raises(expected):
        f4._evaluation_run_loco(run,unit,root,root/'evaluation-amendment')
    assert calls==([] if changed_original else [root/'result.zip'])
    assert (root/'evaluation-input.zip').read_bytes()==b'unqualified leftover copy'


@pytest.mark.parametrize('case', ['sealed', 'unindexed', 'unknown_index', 'bad_index',
    'bad_pin', 'changed_duplicate', 'different_input'])
def test_archive_q_member_identity_deduplicates_input_discovery_only(tmp_path, monkeypatch, case):
    import zipfile
    run, source, _, _ = fixture(tmp_path, monkeypatch)
    for p in (source/'shared/archives').glob('H06-inventory*'):
        p.unlink()
    blob = source/'shared/model.f64'
    raw = canonical_json_bytes({'numbers': list(range(1000)),
        'reference': file_reference(blob, 'OOF')})
    other = canonical_json_bytes({'reference': file_reference(source/'shared/note.json', 'NOTE')})
    prefix = 'search/BRANCH/'
    names = ['input.json', 'native/atoms/a/input.json', 'native/atoms/b/input.json']
    entries = {prefix+name: raw for name in names}
    if case == 'changed_duplicate':
        entries[prefix+names[-1]] = raw.replace(b'"numbers"', b'"changed"')
    elif case == 'different_input':
        entries[prefix+names[-1]] = other
    pins = {name: {'sha256': hashlib.sha256(raw).hexdigest(), 'size_bytes': len(raw)} for name in names}
    if case == 'different_input':
        pins[names[-1]] = {'sha256': hashlib.sha256(other).hexdigest(), 'size_bytes': len(other)}
    if case == 'bad_pin':
        pins[names[0]]['sha256'] = 'f'*64
    index = n._sealed({'kind': 'PADML_F5_Q_CONSUMED_NUMBERS_V1',
        'input_sha256': hashlib.sha256(raw).hexdigest(), 'result_sha256': 'd'*64, 'members': pins})
    if case == 'bad_index':
        index['identity_sha256'] = 'e'*64
    if case == 'unknown_index':
        index = {'kind': 'UNKNOWN_METADATA', 'members': pins}
    if case != 'unindexed':
        entries[prefix+'numbers.json'] = canonical_json_bytes(index)
    path = source/'units/EVALUATION-H06/result.zip'
    with zipfile.ZipFile(path, 'w', compression=zipfile.ZIP_DEFLATED) as z:
        for name, value in entries.items():
            z.writestr(name, value)
    receipt = path.with_name('unit.json')
    value = json.loads(receipt.read_bytes())
    value['artifacts']['result.zip'] = {'sha256': sha256_file(path), 'size_bytes': path.stat().st_size}
    receipt.write_bytes(canonical_json_bytes(value))
    before = path.read_bytes()
    calls = []
    read = zipfile.ZipFile.read
    def counted(archive, member, *args, **kwargs):
        name = member.filename if isinstance(member, zipfile.ZipInfo) else member
        if Path(name).name == 'input.json':
            calls.append(name)
        return read(archive, member, *args, **kwargs)
    monkeypatch.setattr(zipfile.ZipFile, 'read', counted)
    if case in {'bad_index', 'bad_pin', 'changed_duplicate'}:
        with pytest.raises(ContractError, match='NUMBERS_INVALID|METADATA_PIN_DRIFT'):
            reports.archive_inventory(run, 6, ['EVALUATION-H06'], [])
        assert not (source/'shared/archives/H06-inventory.json').exists()
    else:
        inventory = reports.archive_inventory(run, 6, ['EVALUATION-H06'], [])
        assert 'shared/model.f64' in inventory['members']
        expected = 1 if case == 'sealed' else 2 if case == 'different_input' else 3
        assert len(calls) == expected
        if case == 'different_input':
            assert 'shared/note.json' in inventory['members']
    assert path.read_bytes() == before


@pytest.mark.parametrize('other_state', ['RUNNING', 'UNKNOWN'])
def test_inventory_success_clears_only_its_own_timeout(tmp_path, monkeypatch, other_state):
    from concurrent.futures import Future
    run, source, target, inventory = fixture(tmp_path, monkeypatch)
    monkeypatch.setattr(reports, '_archive_volume', lambda root: {
        'uuid': 'external-volume', 'mount': str(tmp_path), 'filesystem': 'exfat'})
    collector = reports.WindowArchive(run, target, pool=None, call=None,
        command=command_for(run), slots=BoundedSemaphore(3))
    # No new remote operation: only harvest an already finished host reply.
    future = Future(); future.set_result(inventory)
    state = {'units': set(), 'training': set(), 'error': 'timeout-B',
        'inventory_futures': {'B': future}, 'inventory_results': {},
        'inventory_readers': {'A': {'status': other_state, 'reason': 'timeout-A'},
            'B': {'status': 'UNKNOWN', 'reason': 'timeout-B'}}}
    collector.states = {6: state}
    result = collector.advance({})['6']
    assert 'B' not in state['inventory_readers'] and state['inventory_results']['B'] == inventory
    if other_state == 'UNKNOWN':
        assert result == {'status': 'RETRY_WAIT', 'reason': 'timeout-A'}
    else:
        assert 'error' not in state
        assert result == {'status': 'IN_PROGRESS', 'phase': 'INVENTORY'}


def test_large_member_envelope_resumes_identical_nonzero_pack(tmp_path, monkeypatch):
    run, source, target, inventory = fixture(tmp_path, monkeypatch)
    members = []
    parent = source/'shared'/('nested-' + 'x'*140); parent.mkdir()
    rows = dict(inventory['members'])
    for i in range(1024):
        path = parent/f'{i:04d}.json'; path.write_bytes(canonical_json_bytes({'i':i}))
        name = path.relative_to(source).as_posix(); members.append(name)
        rows[name] = {'sha256':sha256_file(path),'size_bytes':path.stat().st_size,'native_file':False}
    inventory = n._sealed({**{k:v for k,v in inventory.items() if k!='identity_sha256'},'members':rows})
    (source/'shared/archives/H06-inventory.json').write_bytes(canonical_json_bytes(inventory))
    assert len(canonical_json_bytes(members)) > 131072
    spec = record(inventory, members, target)
    original = io.BytesIO()
    reports.archive_send(run, 6, inventory['identity_sha256'], members, 0, original)
    raw = original.getvalue(); cut = len(raw)//3
    part = target/'packs'/(n._sha(spec['pins'])+'.zip.part'); part.write_bytes(raw[:cut])
    calls = []
    def command(host, operation, **kwargs):
        assert 'members' not in kwargs and kwargs['offset'] == cut
        argv = command_for(run)(host,operation,**kwargs)
        assert max(len(arg.encode()) for arg in argv) < 8192
        calls.append(kwargs)
        return argv
    received = reports.receive_archive(run,target,spec,command=command,slots=BoundedSemaphore(3))
    assert len(calls)==1 and set(received)==set(members)
    path=target/received[members[0]]['storage']
    assert path.read_bytes()==raw and not part.exists()
    assert all((source/name).is_file() for name in members)


@pytest.mark.parametrize('damage',['digest','size','extra','oversize'])
def test_archive_member_envelope_rejects_drift_before_sending(tmp_path,monkeypatch,damage):
    from types import SimpleNamespace
    from padml import run as runs
    run,_,_,inventory=fixture(tmp_path,monkeypatch)
    raw=canonical_json_bytes(['shared/model.f64'])
    pin={'sha256':hashlib.sha256(raw).hexdigest(),'size_bytes':len(raw)}
    if damage=='digest':pin['sha256']='0'*64
    if damage=='size':pin['size_bytes']-=1
    if damage=='extra':raw+=b' '
    if damage=='oversize':pin['size_bytes']=16*1024**2+1
    monkeypatch.setattr(runs,'load_f45_run',lambda _:run)
    monkeypatch.setattr(sys,'stdin',SimpleNamespace(buffer=io.BytesIO(raw)))
    def forbidden(*args,**kwargs):raise AssertionError('drift reached archive sender')
    monkeypatch.setattr(reports,'archive_send',forbidden)
    with pytest.raises(ContractError,match='ARCHIVE_REQUEST'):
        runs._f45_remote_operation({'run':'unused','identity':run['identity'],'operation':'archive_send',
            'horizon':6,'inventory_identity':inventory['identity_sha256'],'members_pin':pin,'offset':0})


def test_archive_failure_receipt_binds_sender_and_retains_prefix(tmp_path,monkeypatch):
    run,source,target,inventory=fixture(tmp_path,monkeypatch)
    spec=record(inventory,['shared/model.f64'],target)
    def command(*args,**kwargs):
        return [sys.executable,'-c',
            'import sys;sys.stdout.buffer.write(b"prefix");sys.stderr.write("x"*4096+" sender failed");sys.exit(23)']
    with pytest.raises(ContractError,match='ARCHIVE_TRANSFER_FAILED:') as caught:
        reports.receive_archive(run,target,spec,command=command,slots=BoundedSemaphore(3))
    detail=json.loads(str(caught.value).split(':',1)[1])
    assert detail['exit_code']==23 and detail['host']==spec['host'] and detail['horizon']==6
    assert detail['inventory']==inventory['identity_sha256'] and detail['offset']==0
    assert detail['received_bytes']==6 and detail['stderr'].endswith(' sender failed')
    assert len(str(caught.value))<1800 and not (target/detail['storage']).exists()
    assert (target/(detail['storage']+'.part')).read_bytes()==b'prefix'
    assert (source/'shared/model.f64').is_file()


@pytest.mark.parametrize('other_failure',[False,True])
def test_recovered_transfer_clears_only_its_own_error(tmp_path,monkeypatch,other_failure):
    from concurrent.futures import Future
    run,_,target,inventory=fixture(tmp_path,monkeypatch)
    monkeypatch.setattr(reports,'_archive_volume',lambda root:{
        'uuid':'external-volume','mount':str(tmp_path),'filesystem':'exfat'})
    collector=reports.WindowArchive(run,target,pool=None,call=None,
        command=command_for(run),slots=BoundedSemaphore(3))
    spec=record(inventory,['shared/model.f64'],target)
    key=(spec['host'],spec['inventory_identity'],n._sha(spec['pins']))
    errors={key:'failed-A'}
    if other_failure:errors[('B','inventory','pins')]='failed-B'
    state={'units':set(),'training':set(),'expected':{},'resolved':{},'transfers':2,
        'error':'failed-A','transfer_errors':errors,'retry_at':float('inf'),'failures':9}
    collector.states={6:state}
    rows=reports.receive_archive(run,collector.target,spec,command=command_for(run),slots=BoundedSemaphore(3))
    future=Future();future.set_result(rows);collector.futures={future:spec}
    result=collector.advance({})['6']
    assert state['transfers']==1 and key not in errors, state
    if other_failure:
        assert result=={'status':'RETRY_WAIT','reason':'failed-B'}
    else:
        assert result=='TRANSFERRING' and 'error' not in state and 'retry_at' not in state


def test_archive_envelope_missing_eof_exits_with_bound():
    import time
    raw=canonical_json_bytes(['member'])
    pin={'sha256':hashlib.sha256(raw).hexdigest(),'size_bytes':len(raw)}
    reader,writer=os.pipe()
    try:
        os.write(writer,raw)  # Complete bytes, but a lost SSH EOF leaves the writer alive.
        start=time.monotonic()
        with os.fdopen(reader,'rb') as stream:
            with pytest.raises(ContractError,match='ARCHIVE_REQUEST_TIMEOUT'):
                reports.archive_members_from_stream(pin,stream,idle_seconds=.05,total_seconds=.1)
        assert time.monotonic()-start<1
    finally:
        os.close(writer)


# Repair interface fixtures only: no calibration/MICE/A04/model calls.
def _post_result_header_fixture(tmp_path,monkeypatch):
    from padml import f4,carriers,integrated
    from padml.bundle import write_deterministic_zip
    run,source,target,_=fixture(tmp_path,monkeypatch)
    run.update(evaluation_decision=f4.evaluation_decision(),post_result_repair=f4.post_result_repair_decision())
    Path(os.environ['PADML_F45_RUN_PATH']).write_bytes(canonical_json_bytes(run))
    producer={'run_identity':run['identity'],'source_identity':run['source_identity']}
    monkeypatch.setattr(integrated,'same_batch_generations',lambda r:{r['identity']:r['source_identity']})
    monkeypatch.setattr(reports,'same_batch_generations',lambda r:{r['identity']:r['source_identity']})
    unit=run['units'][0]; original_root=f4.evaluation_appendix_root(run,unit)
    original_root.mkdir(parents=True)
    for name in ('point.zip','intervals.zip'):
        write_deterministic_zip(original_root/name,{'fixture.json':canonical_json_bytes({'UNFITTED':True})})
    (original_root/'metrics.csv').write_bytes(b'UNFITTED\n')
    original=n._sealed({**f4._evaluation_appendix_identity(run,unit,None,{}),'producer':producer,
        'status':'COMPLETED','direct_consumer_completed':True,'replicate_count':1000,
        'members':{name:carriers.source_pin(original_root/name) for name in ('point.zip','intervals.zip','metrics.csv')}})
    (original_root/'result.json').write_bytes(canonical_json_bytes(original))
    repair_root=f4.post_result_repair_root(run,unit);repair_root.mkdir()
    leaf=repair_root/'UNFITTED.f64';leaf.write_bytes(struct.pack('<d',.123))
    child=repair_root/'child.json'
    child.write_bytes(canonical_json_bytes(n._sealed({'kind':'UNFITTED_REPAIR_CHILD',
        'formal_references':[carriers.file_reference(leaf,'UNFITTED_NUMERICAL_LEAF',run)]})))
    result=n._sealed({**f4._post_result_repair_binding(run,unit,None,original),
        'producer':producer,'status':'COMPLETED','direct_consumer_completed':True,
        'components':{'UNFITTED_TEST':True},'formal_references':[
            carriers.file_reference(original_root/'result.json','ORIGINAL_EVALUATION_APPENDIX',run),
            carriers.file_reference(child,'UNFITTED_CHILD',run)]})
    return run,source,target,unit,original,result,repair_root


def test_post_result_completed_original_requires_new_header(tmp_path,monkeypatch):
    from padml import f4
    run,source,_,unit,original,result,root=_post_result_header_fixture(tmp_path,monkeypatch)
    assert not f4.evaluation_appendix_observation(run,unit)
    assert reports._archive_appendix_pins(run,6,[unit['unit_id']],[]) is None
    (root/'result.json').write_bytes(canonical_json_bytes(result))
    assert f4.evaluation_appendix_observation(run,unit)
    monkeypatch.setattr(f4,'_evaluation_appendix_read',lambda *a,**kw:original)
    def forbidden(*a,**kw):pytest.fail('completed repair cannot call a scientific leaf')
    monkeypatch.setattr(f4,'_post_result_original_view',forbidden)
    assert f4.run_post_result_repair(run,unit,source/'units'/unit['unit_id'])==result


@pytest.mark.parametrize('damage',['binding','producer','leaf'])
def test_post_result_header_rejects_drift(tmp_path,monkeypatch,damage):
    from padml import f4
    run,_,_,unit,original,result,root=_post_result_header_fixture(tmp_path,monkeypatch)
    if damage=='binding':result['original_appendix_identity']='e'*64
    elif damage=='producer':result['producer']['source_identity']='e'*64
    else:(root/'child.json').write_bytes(b'{"UNFITTED":"changed"}\n')
    result=n._sealed({k:v for k,v in result.items() if k!='identity_sha256'})
    (root/'result.json').write_bytes(canonical_json_bytes(result))
    with pytest.raises(ContractError,match='DRIFT|NOT_ADMITTED'):
        f4._post_result_repair_read(run,unit,None,original)


def test_post_result_archive_new_header_closes_nested_refs_and_packed_offline(tmp_path,monkeypatch):
    from padml import carriers,f4
    from padml.bundle import write_deterministic_zip
    run,source,target,unit,_,result,root=_post_result_header_fixture(tmp_path,monkeypatch)
    (root/'result.json').write_bytes(canonical_json_bytes(result))
    head=carriers.file_reference(root/'result.json','REPAIR_COMPLETION',run)
    inventory=reports.archive_inventory(run,6,[unit['unit_id']],[])
    expected={str((root/name).relative_to(source)) for name in ('result.json','child.json','UNFITTED.f64')}
    assert expected<=set(inventory['members'])
    version=reports._archive_version(run)
    assert inventory['post_result_repair_sha256']==run['post_result_repair']['identity_sha256']
    assert reports._archive_receipt_path(target/'windows',6,inventory).name.endswith(
        run['post_result_repair']['identity_sha256'][:12]+'.json')
    # One physical pack, no extra model/copy; remove only this disposable source.
    pack=target/'packs/repair.zip'
    write_deterministic_zip(pack,{name:source/name for name in inventory['members']})
    physical=carriers.source_pin(pack)
    members={name:{'pin':{k:pin[k] for k in ('sha256','size_bytes')},'storage':'packs/repair.zip',
        'member':name,'physical':physical} for name,pin in inventory['members'].items()}
    index=n._sealed({'kind':'PADML_WINDOW_ARCHIVE_INDEX_V1','run_identity':run['identity'],
        'source_identity':run['source_identity'],'members':members,'windows':{'6':version}})
    (target/'index.json').write_bytes(canonical_json_bytes(index))
    monkeypatch.setenv('PADML_ARCHIVE_INDEX',str(target/'index.json'))
    source.rename(source.with_name('saved-source'))
    saved=json.loads(carriers.read_reference(head,run))
    assert saved==result
    for ref in saved['formal_references']:carriers.validate_reference(ref,run)
    child=json.loads(carriers.read_reference(saved['formal_references'][1],run))
    assert struct.unpack('<d',carriers.read_reference(child['formal_references'][0],run))==(.123,)


@pytest.mark.parametrize('damage',[None,'compile_status','lineage'])
def test_post_result_full0_reads_real_compiler_shape_without_lineage_identity(tmp_path,monkeypatch,damage):
    from padml import f4,integrated
    unit={'kind':'FULL0','unit_id':'FULL0-H12','horizon':12}
    run={'run_root':str(tmp_path),'identity':'a'*64,'source_identity':'b'*64}
    root=tmp_path/'units'/unit['unit_id'];(root/'final-input').mkdir(parents=True)
    lineage={'kind':'UNFITTED_FINAL_LINEAGE','selection_horizon_months':12}
    compiled={'status':'COMPILED_NOT_EXECUTED','lineage_sha256':n._sha(lineage)}
    sources={'raw_binding_root':str(tmp_path/'binding'),'response_path':str(tmp_path/'response.csv')}
    receipt={'status':'COMPLETED','run_identity':run['identity'],'unit_id':unit['unit_id'],
             'direct_consumer_completed':True}
    if damage=='compile_status':compiled['status']='COMPLETED'
    if damage=='lineage':compiled['lineage_sha256']='e'*64
    for path,value in ((root/'unit.json',receipt),(root/'final-input/lineage.json',lineage),
                       (root/'final.compile.json',compiled),(root/'full-development.json',sources)):
        path.write_bytes(canonical_json_bytes(value))
    monkeypatch.setattr(integrated,'same_batch_generations',lambda r:{r['identity']:r['source_identity']})
    if damage:
        with pytest.raises(ContractError,match='APPLICATION_REPAIR_FULL0_BINDING_DRIFT'):
            f4._post_result_full0_bindings(run,unit)
    else:assert f4._post_result_full0_bindings(run,unit)==(root,lineage,compiled,sources)


def test_post_result_reports_include_repair_heads(tmp_path,monkeypatch):
    from padml import f4
    run,source,_,unit,_,result,root=_post_result_header_fixture(tmp_path,monkeypatch)
    (root/'result.json').write_bytes(canonical_json_bytes(result))
    names=reports.report_names(run,[unit['unit_id']],[])
    assert str((root/'result.json').relative_to(source)) in names


# UNFITTED paused-report transport and source boundaries; no native task is run.
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import subprocess
import pytest
from padml import reports,run as runs,f4,integrated,nested_loco as n
from padml.bundle import canonical_json_bytes,strict_json_bytes,sha256_bytes,ContractError

@pytest.fixture
def _repair_report_full_heads(tmp_path,monkeypatch):
    base=tmp_path/'source';base.mkdir()
    units=[]
    for h in (6,12,24,36):
        units.extend({'kind':'PRIMARY','unit_id':f'PRIMARY-H{h:02d}-O{o}','horizon':h,'outer_fold':o,'context':f'OUTER-{o}'} for o in range(1,7))
        units.extend(({'kind':'FULL0','unit_id':f'FULL0-H{h:02d}','horizon':h,'context':'FULL0'},
                      {'kind':'EVALUATION','unit_id':f'EVALUATION-H{h:02d}','horizon':h,'context':'EVALUATION'}))
    run={'kind':'PADML_INTEGRATED_RAW_RUN_V1','run_root':str(base),'run_id':'UNFITTED-REPAIR',
         'identity':'a'*64,'source_identity':'b'*64,'units':units,
         'evaluation_decision':f4.evaluation_decision(),'post_result_repair':f4.post_result_repair_decision()}
    producer={'run_identity':run['identity'],'source_identity':run['source_identity']}
    generations={run['identity']:run['source_identity']}
    monkeypatch.setattr(reports,'same_batch_generations',lambda r:generations)
    monkeypatch.setattr(integrated,'same_batch_generations',lambda r:generations)
    monkeypatch.setattr(runs,'load_f45_run',lambda p:run)
    def write(path,value):
        path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(canonical_json_bytes(value));return value
    def ref(path):
        raw=path.read_bytes()
        return {'path':str(path.relative_to(base)),'role':'UNFITTED_DECLARED_SUMMARY','producer':run['source_identity'],
                'sha256':sha256_bytes(raw),'size_bytes':len(raw)}
    all_heads={};obs={'H01':{'state':'IDLE','evaluation_amendment_units':[u['unit_id'] for u in units]}}
    for unit in units:
        uid,kind=unit['unit_id'],unit['kind'];names=reports._repair_report_names(unit)
        original_path=f4.evaluation_appendix_root(run,unit)/'result.json'
        original=write(original_path,n._sealed({**f4._evaluation_appendix_identity(run,unit,None,{}),
                  'producer':producer,'status':'COMPLETED','direct_consumer_completed':True,'replicate_count':1000}))
        references=[ref(original_path)]
        for name in names[1:]:
            body={'kind':'UNFITTED_SUMMARY_FIXTURE','producer':producer,'target_unit':uid,'status':'COMPLETED'}
            if '/a04/result.json' in name:
                body.update(selection_effect='NONE',p2c2t={'CENTER':{'qualified_fit_coordinate_count':0}},
                            actual_new_this_invocation={'model_fits':0,'mice_chain_starts':0})
            elif '/auc-validation/' in name:
                body.update(scenario_ordinal=unit['outer_fold'],dataset_ids_preserved=2000,P_per_dataset=1999)
            elif '/application-repair/' in name:
                body.update(new_mice_chains=0,new_model_fits=0)
                if '/full-a04/' not in name:
                    comparisons=[]
                    for c in ('36','38','39','48','52','54'):
                        for h in (6,12,24,36):
                            failed=unit['horizon']==6 and len(comparisons)<10
                            comparisons.append({'center':c,'report_month':h,'original_status':'FAIL' if failed else 'PASS',
                                'status':'PASS','cause':{'UNFITTED_CAUSE':True} if failed else None})
                    body.update(coordinate_count=24,comparisons=comparisons)
            child=write(base/name,n._sealed(body));all_heads[name]=child;references.append(ref(base/name))
        completion=write(base/names[0],n._sealed({**f4._post_result_repair_binding(run,unit,None,original),
                     'producer':producer,'status':'COMPLETED','direct_consumer_completed':True,
                     'formal_references':references,'components':{'UNFITTED':True}}))
        all_heads[names[0]]=completion
    def payload(op,**kw):return {'run':str(tmp_path/'run.json'),'identity':run['identity'],'operation':op,**kw}
    def call(host,op,**kw):
        assert host=='H01' and op=='pin'
        return runs._f45_remote_operation(payload(op,**kw))
    def command(host,op,**kw):
        assert host=='H01' and op=='send'
        return (host,op,kw)
    def fake_run(command,**options):
        host,op,kw=command
        assert options=={'capture_output':True,'timeout':60,'check':False}
        selected=next(u for u in units if u['unit_id']==kw['report_of'])
        deps=reports.repair_report_dependencies(run,selected)
        assert kw['member'] in deps
        if deps[kw['member']] is not None:assert kw['pin']==deps[kw['member']]
        return subprocess.CompletedProcess(command,0,(base/kw['member']).read_bytes(),b'')
    monkeypatch.setattr(reports.subprocess,'run',fake_run)
    return run,obs,all_heads,payload,call,command,tmp_path/'report'

def _collect_paused_repair_test(f):
    run,obs,heads,payload,call,command,target=f
    with ThreadPoolExecutor(max_workers=7) as pool:
        return reports.collect_repair(run,obs,report_root=target,call=call,command=command,pool=pool)

def test_paused_report_consumes_32_declared_scopes_and_retry_is_exact(_repair_report_full_heads):
    value=_collect_paused_repair_test(_repair_report_full_heads);run,obs,heads,*_,target=_repair_report_full_heads
    assert value['archive_mode']=='PAUSED' and value['source_head_count']==len(heads)==139
    before={p.name:p.read_bytes() for p in target.iterdir()}
    saved=strict_json_bytes(before['repair-results.json'])
    assert saved['original_application']=={'coordinates':96,'original_failures':10,'passed':96,
        'failed_original_coordinates_closed':10,'original_successes_without_regression':86}
    assert len(saved['direct_consumer_sources'])==139
    reused = _collect_paused_repair_test(_repair_report_full_heads)
    assert reused['status']=='REUSED_UNCHANGED_HISTORICAL_REPAIR'
    assert reused['source_head_count']==32 and reused['new_historical_report_copies']==0
    assert before=={p.name:p.read_bytes() for p in target.iterdir()}
    assert not (Path(run['run_root'])/'shared/archives').exists()


@pytest.mark.parametrize('damage',[None,'nearest_drift','source_drift'])
def test_history_reuse_three_generations_has_no_member_transfer_or_large_copy(_repair_report_full_heads,monkeypatch,damage):
    _collect_paused_repair_test(_repair_report_full_heads)
    run,obs,heads,_,_,_,old_target=_repair_report_full_heads
    old=dict(run)
    original=old_target.parent/'run-repair-original.repair-report'
    old_target.rename(original)
    previous1={**old,'identity':'1'*64,'unit_predecessor':{'run_path':'/pins/original/run.json'}}
    previous2={**old,'identity':'2'*64,'unit_predecessor':{'run_path':'/pins/first/run.json'}}
    run.update(identity='3'*64,result_closure={'UNFITTED':True},
        unit_predecessor={'run_path':'/pins/second/run.json'})
    monkeypatch.setattr(runs,'f45_unit_predecessors',lambda r:[previous2,previous1,old])
    target=old_target.parent/'run-repair-current.repair-report'
    if damage=='nearest_drift':
        near=old_target.parent/'run-repair-second.repair-report';near.mkdir()
        (near/'repair-results.json').write_bytes((original/'repair-results.json').read_bytes())
    pins=[]
    def call(host,op,**kw):
        assert op=='pin';pins.append(kw['member'])
        p=Path(run['run_root'])/kw['member'];raw=p.read_bytes()
        return {'sha256':'0'*64 if damage=='source_drift' else sha256_bytes(raw),'size_bytes':len(raw)}
    def command(*a,**kw):pytest.fail('qualified history retransferred a result member')
    before=(original/'repair-results.json').read_bytes()
    with ThreadPoolExecutor(max_workers=7) as pool:
        if damage:
            with pytest.raises(ContractError,match='REPORT_RETAINED'):
                reports.collect_repair(run,obs,report_root=target,call=call,command=command,pool=pool)
        else:
            for _ in range(2):
                result=reports.collect_repair(run,obs,report_root=target,call=call,command=command,pool=pool)
                assert result['report']==str(original/'repair-results.json')
                assert result['new_historical_report_copies']==0
            assert len(pins)==64
    assert (original/'repair-results.json').read_bytes()==before
    assert not (target/'repair-results.json').exists()


@pytest.mark.parametrize('operation',['archive_inventory','archive_confirm'])
def test_enabled_drain_keeps_unknown_exact_request_and_never_reissues_ack(tmp_path,monkeypatch,operation):
    from concurrent.futures import Future
    run,source,target,inventory=fixture(tmp_path,monkeypatch)
    monkeypatch.setattr(reports,'_archive_volume',lambda _:{'uuid':'external-volume','mount':str(tmp_path),'filesystem':'exfat'})
    class Pool:
        def __init__(self):self.calls=[]
        def submit(self,*args,**kwargs):
            f=Future();self.calls.append((args,kwargs,f));return f
    pool=Pool();receipt=n._sealed({'horizon':6,'kind':'UNFITTED_RETAINED_RECEIPT'})
    request=reports._archive_request(operation,6,**({'receipt':receipt} if operation=='archive_confirm' else {}))
    first=Future();first.set_exception(subprocess.TimeoutExpired('ssh',60))
    archive=reports.WindowArchive(run,target,pool=pool,call=lambda *a,**kw:None,
        command=command_for(run),slots=BoundedSemaphore(3))
    pending='ack_pending' if operation=='archive_confirm' else 'inventory_readers'
    futures='ack_futures' if operation=='archive_confirm' else 'inventory_futures'
    state={'units':set(),'training':set(),'receipt':receipt,futures:{'H0':first},pending:{'H0':{'request':request}}}
    archive.states={6:state}
    observations={'H0':{'state':'IDLE'}}
    archive.advance(observations,draining=True);assert not archive.drained()
    for result in [dict(status='IDLE',horizon=6,request_id='0'*64),
                   dict(status='IDLE',horizon=6,request_id=request['request_id']),
                   dict(status='IDLE',horizon=6,request_id=request['request_id'])]:
        state[pending]['H0']['retry_at']=0
        archive.advance(observations,draining=True)
        args,kw,future=pool.calls[-1]
        assert args[2]=='archive_inventory' and kw['status_only'] and kw['request']==request
        future.set_result(result);archive.advance(observations,draining=True)
    assert archive.drained() and not state.get('inventory_results') and not state.get('acknowledged')
    assert not state.get('published') and not list((archive.target/'windows').glob('*.json'))


def test_enabled_drain_retries_index_publication_without_retransferring(tmp_path,monkeypatch):
    run,source,target,inventory=fixture(tmp_path,monkeypatch)
    monkeypatch.setattr(reports,'_archive_volume',lambda _:
        {'uuid':'external-volume','mount':str(tmp_path),'filesystem':'exfat'})
    class Pool:
        def submit(self,*a,**kw):pytest.fail('draining scheduled new remote work')
    archive=reports.WindowArchive(run,target,pool=Pool(),call=None,
        command=command_for(run),slots=BoundedSemaphore(3))
    spec=record(inventory,['shared/model.f64'],archive.target)
    actual=reports.receive_archive(run,archive.target,spec,command=command_for(run),slots=BoundedSemaphore(3))
    future=Future();future.set_result(actual);archive.futures[future]=spec
    archive.states={6:{'units':set(),'training':set(),'resolved':{},'shared':{},'members':inventory['members'],
        'transfers':1}}
    original=archive._store_staged
    monkeypatch.setattr(archive,'_store_staged',lambda *a,**k:(_ for _ in ()).throw(OSError('index interrupted')))
    archive.advance({},draining=True)
    assert future in archive.futures and not archive.drained()
    assert 'index interrupted' in archive.states[6]['error']
    monkeypatch.setattr(archive,'_store_staged',original)
    archive.advance({},draining=True)
    assert archive.drained() and not archive.futures
    assert json.loads((archive.target/'index.json').read_bytes())['members']


def test_chain_review_keeps_pause_and_research_failure_separate_from_engineering(monkeypatch):
    from padml import evaluation_extension as e
    run={'identity':'a'*64}
    current=n._sealed({'run_identity':run['identity'],'decision_sha256':e.decision()['identity_sha256'],
        'mi_coordinate_count':40,'new_mi_coordinates':30,'source_identities':{'retained':'b'*64},
        'clinical_supplement':{'status':'ALL_32_SCOPES_DISPOSITION_COMPLETE','units':{str(i):{
            'coordinate_count':1,'rows':[{'status':'NOT_VALIDATED_FOR_THIS_CLINICAL_SCOPE',
                'original':{'status':'ESTIMABLE'}}]} for i in range(32)}},
        'clinical_source_identities':{str(i):'c'*64 for i in range(32)},
        'research':{'status':'FIXED_RESEARCH_BUDGET_COMPLETED','coordinates':[
            {'coordinate':['confirmation',1,'STUDENTIZED','C1',6,'APPARENT'],'status':'FAILED_REGISTERED_SCOPE'}]},
        'completion_domains':{'required_diagnostics':{'status':'COMPUTED_AND_DIRECTLY_CONSUMED'},
            'statistical_limitations':{'status':'RETAINED'},'delivery':{'status':'PAUSED_BY_USER'}}})
    states={'engineering_defects':'CLOSED_WITH_CHAIN_EVIDENCE','required_calculations':'COMPUTED_AND_DIRECTLY_CONSUMED',
        'new_research':'FIXED_RESEARCH_BUDGET_COMPLETED','statistical_limitations':'RETAINED','controlled_delivery':'PAUSED_BY_USER'}
    closure={'report_identity':current['identity_sha256'],'source_identities':current['source_identities'],
        'domains':{k:{'status':v,'report_identity':current['identity_sha256']} for k,v in states.items()},
        'unresolved_engineering_defects':0,'remaining_required_calculations':0,
        'engineering_issues':{name:{'status':'CLOSED','evidence':{step:['actual.json'] for step in e.CLOSURE_STEPS}}
            for name in e.ENGINEERING_ISSUES},
        'research_disposition':'COMPLETED_WITH_FAILED_OR_UNVALIDATED_SCOPES',
        'statistical_limits_preserved':True,'archive_user_authorization_required':True}
    binding={'evaluation_extension_evidence':{'current_report':'current.json','review':'review.json'}}
    evidence={'current.json':canonical_json_bytes(current),'actual.json':b'actual independent evidence'}
    evidence['review.json']=canonical_json_bytes({'chain_closure':closure})
    assert e.validate_closure_evidence(run,binding,evidence)==current
    closure['research_disposition']='ALL_REGISTERED_SCOPES_VALIDATED'
    evidence['review.json']=canonical_json_bytes({'chain_closure':closure})
    with pytest.raises(ContractError,match='FINAL_DOMAINS_CONFLATED'):
        e.validate_closure_evidence(run,binding,evidence)
    closure['research_disposition']='COMPLETED_WITH_FAILED_OR_UNVALIDATED_SCOPES'
    domain=closure['domains']['new_research'];closure['domains']['new_research']={}
    evidence['review.json']=canonical_json_bytes({'chain_closure':closure})
    with pytest.raises(ContractError,match='FINAL_DOMAIN_STATUS_DRIFT'):
        e.validate_closure_evidence(run,binding,evidence)
    closure['domains']['new_research']=domain
    del closure['engineering_issues'][e.ENGINEERING_ISSUES[0]]['evidence']['interrupted_recovery']
    evidence['review.json']=canonical_json_bytes({'chain_closure':closure})
    with pytest.raises(ContractError,match='FINAL_ISSUE_EVIDENCE_INCOMPLETE'):
        e.validate_closure_evidence(run,binding,evidence)

@pytest.mark.parametrize('damage',['child','completion','original'])
def test_report_drift_does_not_publish(_repair_report_full_heads,damage):
    run,obs,heads,_,_,_,target=_repair_report_full_heads
    unit=run['units'][0];names=reports._repair_report_names(unit);base=Path(run['run_root'])
    path=base/names[1 if damage=='child' else 0]
    if damage=='original':path=f4.evaluation_appendix_root(run,unit)/'result.json'
    value=strict_json_bytes(path.read_bytes())
    value['UNFITTED_DRIFT']=True
    if damage=='completion':value['decision_sha256']='e'*64
    path.write_bytes(canonical_json_bytes(n._sealed({k:v for k,v in value.items() if k!='identity_sha256'})))
    with pytest.raises(ContractError,match='DRIFT|INCOMPLETE'):
        _collect_paused_repair_test(_repair_report_full_heads)
    assert not target.exists()

def test_report_transport_error_is_retryable_and_no_report_is_ack(_repair_report_full_heads,monkeypatch):
    run,obs,heads,_,_,_,target=_repair_report_full_heads
    good=reports.subprocess.run
    def failed(*args,**kw):return subprocess.CompletedProcess(args[0],255,b'',b'UNFITTED_SSH_LOSS')
    monkeypatch.setattr(reports.subprocess,'run',failed)
    with pytest.raises(ContractError,match='REPORT_REPAIR_TRANSPORT_FAILED'):_collect_paused_repair_test(_repair_report_full_heads)
    assert not target.exists()
    monkeypatch.setattr(reports.subprocess,'run',good)
    assert _collect_paused_repair_test(_repair_report_full_heads)['archive_mode']=='PAUSED'

def test_report_partial_local_publication_reenters_without_native_tasks(_repair_report_full_heads,monkeypatch):
    real=reports._publish;target=_repair_report_full_heads[-1]
    def interrupted(path,raw,reason,**kw):
        if path.name=='original-application-96.csv':raise OSError('UNFITTED_PUBLISH_INTERRUPTION')
        return real(path,raw,reason,**kw)
    monkeypatch.setattr(reports,'_publish',interrupted)
    with pytest.raises(OSError,match='UNFITTED_PUBLISH_INTERRUPTION'):_collect_paused_repair_test(_repair_report_full_heads)
    assert (target/'repair-results.json').exists() and not (target/'original-application-96.csv').exists()
    old=(target/'repair-results.json').read_bytes()
    monkeypatch.setattr(reports,'_publish',real)
    _collect_paused_repair_test(_repair_report_full_heads)
    assert (target/'repair-results.json').read_bytes()==old

@pytest.mark.parametrize('damage',['receive','undeclared','cross_scope','wrong_pin','symlink'])
def test_real_remote_report_boundary_is_narrow(_repair_report_full_heads,damage,tmp_path):
    run,obs,heads,payload,call,command,target=_repair_report_full_heads;unit=run['units'][0]
    names=reports._repair_report_names(unit);member=names[1]
    pin=reports.repair_report_dependencies(run,unit)[member]
    op='send';extra={}
    if damage=='receive':op='receive'
    elif damage=='undeclared':member='units/'+unit['unit_id']+'/native/model.bin'
    elif damage=='cross_scope':member=reports._repair_report_names(run['units'][1])[1]
    elif damage=='wrong_pin':pin={**pin,'sha256':'e'*64}
    else:
        path=Path(run['run_root'])/member;raw=path.read_bytes();other=tmp_path/'held.json';other.write_bytes(raw);path.unlink();path.symlink_to(other)
    with pytest.raises(ContractError,match='REPORT_REPAIR_|F45_TRANSFER_'):
        runs._f45_remote_operation(payload(op,member=member,pin=pin,report_of=unit['unit_id']))


def test_staging_unknown_peer_does_not_block_second_eligible_host_transfer(tmp_path, monkeypatch):
    """UNFITTED queue boundary; no native source scan or remote transfer."""
    from collections import deque
    from concurrent.futures import Future
    class Pool:
        def __init__(self):
            self.calls = []
        def submit(self, *args, **kwargs):
            self.calls.append((args, kwargs))
            return Future()

    volume = {'uuid': 'UNFITTED', 'mount': str(tmp_path), 'filesystem': 'exfat'}
    (tmp_path / 'volume.json').write_bytes(canonical_json_bytes(volume))
    monkeypatch.setattr(reports, '_archive_volume', lambda root: volume)
    archive = reports.WindowArchive.__new__(reports.WindowArchive)
    archive.staging = True
    archive.target, archive.pool = tmp_path, Pool()
    archive.call = archive.command = archive.slots = None
    archive.run = {'units': [], 'host_connections': {'H0': {}, 'H1': {}}}
    def state(host):
        return {'host': host, 'horizon': 6, 'units': set(), 'training': set(),
                'not_estimable': set(), 'expected': {}, 'resolved': {},
                'shared': {}, 'aliases': {}, 'transfers': 2}
    archive.states = {'a': state('H0'), 'b': state('H1')}
    archive.futures = {Future(): {'state_key': 'a', 'host': 'H0'}}
    good = {'state_key': 'a', 'host': 'H0'}
    blocked = {'state_key': 'b', 'host': 'H1'}
    archive.pending = deque([good, blocked])
    archive._advance_staging({'H0': {'state': 'RUNNING'}, 'H1': {'state': 'UNKNOWN'}})
    assert len(archive.pool.calls) == 1
    args, _ = archive.pool.calls[0]
    assert args[0] is reports.receive_archive and args[3] is good
    assert len(archive.futures) == 2
    assert list(archive.pending) == [blocked]


def test_full_sender_probe_does_not_claim_other_hosts_unit_scope(tmp_path, monkeypatch):
    """Native status-only admission; no inventory scan or scientific task."""
    from collections import deque
    from concurrent.futures import Future
    run = {'kind': 'PADML_INTEGRATED_RAW_RUN_V1', 'identity': 'a' * 64,
           'run_root': str(tmp_path), 'units': []}
    monkeypatch.setattr(runs, 'load_f45_run', lambda _: run)
    monkeypatch.setattr(runs, '_f45_host_observation', lambda _: pytest.fail('status probe read scientific receipts'))
    state = {'units': {'LOCAL', 'OTHER_HOST'}, 'training': set(),
             'inventories': {'H0': {'units': ['LOCAL'], 'selections': []}}}
    record = {'host': 'H0', 'horizon': 6, 'sender_request': {'request_id': 'b' * 64}}
    def call(host, operation, **kwargs):
        assert host == 'H0' and kwargs['units'] == [] and kwargs['selections'] == []
        return runs._f45_remote_operation({'run': str(tmp_path / 'UNFITTED.json'),
            'identity': run['identity'], 'operation': operation, **kwargs})
    class Pool:
        def submit(self, fn, *args, **kwargs):
            result = Future()
            result.set_result(fn(*args, **kwargs))
            return result
    archive = reports.WindowArchive.__new__(reports.WindowArchive)
    archive.staging = False
    archive.call, archive.pool = call, Pool()
    archive.pending = deque()
    future = Future()
    archive.futures = {future: record}
    assert archive._sender_wait(future, record, state, {'H0': {'state': 'IDLE'}})
    assert record['sender_probe'].result() == {'status': 'IDLE', 'horizon': 6, 'request_id': 'b' * 64}


@pytest.mark.parametrize('draining', [False, True])
def test_inventory_probes_do_not_starve_later_hosts(tmp_path, monkeypatch, draining):
    from collections import deque
    from concurrent.futures import Future
    hosts = ['H0', 'H1', 'H4', 'H5', 'H6', 'H9-2', 'H7-3']
    volume = {'uuid': 'UNFITTED', 'mount': str(tmp_path), 'filesystem': 'exfat'}
    (tmp_path / 'volume.json').write_bytes(canonical_json_bytes(volume))
    class Pool:
        def __init__(self): self.calls = []
        def submit(self, fn, *args, **kwargs):
            future = Future()
            self.calls.append((future, args, kwargs))
            return future
    archive = reports.WindowArchive.__new__(reports.WindowArchive)
    archive.staging = True
    archive.target, archive.pool = tmp_path, Pool()
    archive.call = archive.command = archive.slots = None
    archive.run = {'units': [], 'host_connections': {h: {} for h in hosts}}
    archive.futures, archive.pending = {}, deque()
    archive.states = {h: {'host': h, 'horizon': 6, 'units': set(), 'training': set(),
        'not_estimable': set(), **({'reader_pending': True} if draining else {})} for h in hosts}
    clock = [0.]
    monkeypatch.setattr(reports, '_archive_volume', lambda _: volume)
    monkeypatch.setattr(reports.time, 'monotonic', lambda: clock[0])
    for iteration in range(9):
        for future, _, _ in archive.pool.calls:
            if not future.done(): future.set_result({'status': 'IN_PROGRESS', 'horizon': 6})
        clock[0] = iteration * 30.
        before = len(archive.pool.calls)
        archive._advance_staging({h: {'state': 'IDLE'} for h in hosts}, draining=draining)
        assert len(archive.pool.calls) - before <= 3
        assert len({s['host'] for s in archive.states.values() if s.get('inventory_future')}) <= 3
    assert {args[0] for _, args, _ in archive.pool.calls} == set(hosts)
    if draining:
        assert all(kwargs.get('status_only') is True for _, _, kwargs in archive.pool.calls)


class _ArchiveLeasePool:
    def __init__(self): self.calls=[]
    def submit(self,fn,*args,**kwargs):
        future=Future();self.calls.append((future,fn,args,kwargs));return future

def _archive_lease_fixture(tmp_path, monkeypatch):
    volume={'uuid':'UNFITTED','mount':str(tmp_path),'filesystem':'exfat'}
    (tmp_path/'volume.json').write_bytes(canonical_json_bytes(volume))
    monkeypatch.setattr(reports,'_archive_volume',lambda _:volume)
    monkeypatch.setattr(reports.time,'monotonic',lambda:100.)
    archive=reports.WindowArchive.__new__(reports.WindowArchive)
    archive.staging=True;archive.target=tmp_path;archive.pool=_ArchiveLeasePool()
    archive.call=lambda *a,**k:None
    archive.command=archive.slots=None
    archive.run={'units':[],'host_connections':{'H0':{},'H1':{}}}
    archive.states={};archive.futures={};archive.pending=deque()
    return archive

def _archive_lease_scope(host,horizon=6,prepared=False):
    value={'host':host,'horizon':horizon,'units':set(),'training':set(),'not_estimable':set()}
    if prepared: value.update(expected={},resolved={},shared={},aliases={},transfers=2)
    return value

def _archive_lease_record(host,key):
    return {'host':host,'state_key':key,'horizon':6,'pins':{'x':{'sha256':'a'*64,'size_bytes':1}}}

def _archive_lease_calls(archive, fn):
    return [(args,kw) for _,actual,args,kw in archive.pool.calls if actual is fn]

def _archive_lease_observations(): return {'H0':{'state':'RUNNING'},'H1':{'state':'IDLE'}}

@pytest.mark.parametrize('reader',['new','active','unknown'])
def test_same_host_inventory_blocks_transfer(tmp_path,monkeypatch,reader):
    a=_archive_lease_fixture(tmp_path,monkeypatch)
    a.states={'read':_archive_lease_scope('H0',36),'send':_archive_lease_scope('H0',prepared=True)}
    if reader=='active':a.states['read']['inventory_future']=Future()
    if reader=='unknown':a.states['read']['reader_pending']=True
    a.pending.append(_archive_lease_record('H0','send'))
    a._advance_staging(_archive_lease_observations())
    if reader=='new':
        assert len(_archive_lease_calls(a,reports.receive_archive))==1
        assert not _archive_lease_calls(a,a.call)
    else:
        assert not _archive_lease_calls(a,reports.receive_archive)
    if reader=='unknown':assert all(kw.get('status_only') for _,kw in _archive_lease_calls(a,a.call))

@pytest.mark.parametrize('sender',['active','unknown'])
def test_same_host_sender_blocks_new_inventory(tmp_path,monkeypatch,sender):
    a=_archive_lease_fixture(tmp_path,monkeypatch)
    a.states={'read':_archive_lease_scope('H0',36),'send':_archive_lease_scope('H0',prepared=True)}
    active=Future();r=_archive_lease_record('H0','send');a.futures[active]=r
    if sender=='unknown':
        active.set_result(None);r['sender_request']={'request_id':'b'*64}
    a._advance_staging(_archive_lease_observations())
    inventory=_archive_lease_calls(a,a.call)
    assert not [(args,kw) for args,kw in inventory if not kw.get('status_only')]
    assert (len(inventory)==1)==(sender=='unknown')

@pytest.mark.parametrize('draining',[False,True])
def test_status_probes_remain_allowed_with_legacy_overlap(tmp_path,monkeypatch,draining):
    a=_archive_lease_fixture(tmp_path,monkeypatch)
    a.states={'read':_archive_lease_scope('H0',36),'send':_archive_lease_scope('H0',prepared=True)}
    a.states['read']['reader_pending']=True
    active=Future();active.set_result(None);r=_archive_lease_record('H0','send')
    r['sender_request']={'request_id':'b'*64};a.futures[active]=r
    a._advance_staging(_archive_lease_observations(),draining=draining)
    inventory=_archive_lease_calls(a,a.call)
    assert len(inventory)==2
    assert all(kw.get('status_only') for _,kw in inventory)
    assert {bool(kw.get('sender_request')) for _,kw in inventory}=={True,False}
    assert not _archive_lease_calls(a,reports.receive_archive)

def test_blocked_reader_peer_does_not_waste_second_transfer_slot(tmp_path,monkeypatch):
    a=_archive_lease_fixture(tmp_path,monkeypatch)
    a.states={'send0':_archive_lease_scope('H0',prepared=True),'send1':_archive_lease_scope('H1',prepared=True),'read1':_archive_lease_scope('H1',36)}
    a.states['read1'].update(reader_pending=True,retry_at=200.)
    a.futures[Future()]=_archive_lease_record('H0','send0')
    a.pending.extend([_archive_lease_record('H0','send0'),_archive_lease_record('H1','send1')])
    a._advance_staging(_archive_lease_observations())
    dispatched=[args[2]['host'] for args,_ in _archive_lease_calls(a,reports.receive_archive)]
    assert dispatched==['H0']

def test_reader_idle_releases_transfer_without_new_heavy_scan(tmp_path,monkeypatch):
    a=_archive_lease_fixture(tmp_path,monkeypatch)
    a.states={'read':_archive_lease_scope('H0',36),'send':_archive_lease_scope('H0',prepared=True)}
    a.states['read']['reader_pending']=True
    a.pending.append(_archive_lease_record('H0','send'))
    a._advance_staging(_archive_lease_observations())
    assert len(a.pool.calls)==1 and a.pool.calls[0][3].get('status_only')
    a.pool.calls[0][0].set_result({'status':'IDLE','horizon':36})
    a._advance_staging(_archive_lease_observations())
    assert not a.states['read'].get('reader_pending')
    assert len(_archive_lease_calls(a,reports.receive_archive))==1
    assert len(_archive_lease_calls(a,a.call))==1  # Only the existing status probe; no new raw scan.

def test_successful_transfer_releases_next_inventory(tmp_path,monkeypatch):
    a=_archive_lease_fixture(tmp_path,monkeypatch)
    a.states={'read':_archive_lease_scope('H0',36),'send':_archive_lease_scope('H0',prepared=True)}
    f=Future();r=_archive_lease_record('H0','send');a.futures[f]=r
    a._advance_staging(_archive_lease_observations())
    assert not a.pool.calls
    # Isolate scheduling from the already-covered durable index barrier.
    a._store_staged=lambda rows:None
    f.set_result({})
    a._advance_staging(_archive_lease_observations())
    assert not a.futures
    inventory=_archive_lease_calls(a,a.call)
    assert len(inventory)==1 and inventory[0][1]['horizon']==36
    assert not inventory[0][1].get('status_only')
    assert not _archive_lease_calls(a,reports.receive_archive)


def oss_rebuild_fixture(tmp_path,monkeypatch):
    from padml import f4
    root=tmp_path/'external-project';root.mkdir();(root/'old').mkdir();(root/'old/a').write_bytes(b'old archive')
    acceptance=tmp_path/'acceptance.json';acceptance.write_bytes(b'accepted-test')
    generation='c'*64
    volume={'uuid':'expected-volume','mount':str(tmp_path),'filesystem':'exfat'}
    run={'run_id':'run','identity':'d'*64,'source_bundle_sha256':'a'*64,
        'raw_input':{'sha256':'b'*64,'size_bytes':3},'archive_transfer':{
        'kind':'OSS_RELAY_V1','generation':generation,'relay_prefix':f'padml-relay/run/{generation}/',
        'volume':volume,'project_root':str(root),'rebuild_record':str(tmp_path/'rebuild.json'),
        'controller_sources':{'raw-input.xlsx':{'path':str(tmp_path/'raw'),'sha256':'b'*64,'size_bytes':3},
            'source.zip':{'path':str(tmp_path/'source'),'sha256':'a'*64,'size_bytes':3}}}}
    st=(root/'old').stat()
    record=n._sealed({'phase':'PREPARED','generation':generation,'root':str(root),'volume':volume,
        'run_identity':run['identity'],'entries':{'old':{'device':st.st_dev,'inode':st.st_ino}},
        'acceptance':{'path':str(acceptance),'sha256':sha256_file(acceptance)},
        'readers_quiescent':True,'funds':{'available_cny':30,'estimated_cny':20},
        'probe':{'status':'UPLOAD_DOWNLOAD_RESUME_DELETE_PASSED'},'prepared_at':__import__('time').time()})
    Path(run['archive_transfer']['rebuild_record']).write_bytes(canonical_json_bytes(record))
    monkeypatch.setattr(reports,'_archive_volume',lambda p:volume)
    monkeypatch.setattr(f4,'validate_post_result_archive_acceptance',lambda *a:None)
    return run,root,acceptance


def test_source_only_archive_successor_keeps_exact_scope_and_old_clear_authority(tmp_path,monkeypatch):
    from copy import deepcopy
    from padml.run import _f45_archive_transfer_revision
    old,root,acceptance=oss_rebuild_fixture(tmp_path,monkeypatch)
    new=deepcopy(old);new['identity']='e'*64;new['source_bundle_sha256']='f'*64
    new['archive_transfer']['controller_sources']['source.zip']={
        'path':str(tmp_path/'fixed-source.zip'),'sha256':'f'*64,'size_bytes':5}
    _f45_archive_transfer_revision(old,new)
    # Source compatibility never permits the new executor to consume an old
    # deletion authorization. Rebuild preflight still binds the exact run.
    with pytest.raises(ContractError,match='REBUILD_STATE_INVALID'):
        reports.clear_old_archive(new,acceptance_path=acceptance)
    assert (root/'old/a').read_bytes()==b'old archive'
    for change in ('generation','project_root','rebuild_record','volume','raw','source_pin'):
        bad=deepcopy(new);cfg=bad['archive_transfer']
        if change=='generation':
            cfg['generation']='0'*64;cfg['relay_prefix']='padml-relay/run/'+cfg['generation']+'/'
        elif change=='volume':cfg['volume']['uuid']='different-volume'
        elif change=='raw':cfg['controller_sources']['raw-input.xlsx']['path']=str(tmp_path/'different-raw')
        elif change=='source_pin':cfg['controller_sources']['source.zip']['sha256']='0'*64
        else:cfg[change]=str(tmp_path/('different-'+change))
        with pytest.raises(ContractError,match='REBASE_REQUIRED|SOURCE_DRIFT'):
            _f45_archive_transfer_revision(old,bad)


@pytest.mark.parametrize('boundary',['CLEARING','CLEARED'])
def test_oss_rebuild_crash_barriers_and_never_rec_clear_new_generation(tmp_path,monkeypatch,boundary):
    run,root,acceptance=oss_rebuild_fixture(tmp_path,monkeypatch)
    publish=reports._publish
    def crashed(path,raw,*args,**kwargs):
        if path.name=='rebuild.json' and json.loads(raw).get('phase')==boundary:raise OSError('injected barrier')
        return publish(path,raw,*args,**kwargs)
    monkeypatch.setattr(reports,'_publish',crashed)
    with pytest.raises(OSError,match='injected'):reports.clear_old_archive(run,acceptance_path=acceptance)
    assert (root/'old/a').exists()==(boundary=='CLEARING')
    monkeypatch.setattr(reports,'_publish',publish)
    assert reports.clear_old_archive(run,acceptance_path=acceptance)['phase']=='CLEARED'
    (root/'new-generation').write_bytes(b'new required result')
    assert reports.clear_old_archive(run,acceptance_path=acceptance)['phase']=='CLEARED'
    assert (root/'new-generation').read_bytes()==b'new required result'


def test_oss_rebuild_wrong_volume_new_content_and_reader_gate_reject(tmp_path,monkeypatch):
    run,root,acceptance=oss_rebuild_fixture(tmp_path,monkeypatch)
    original=reports._archive_volume
    monkeypatch.setattr(reports,'_archive_volume',lambda p:{'uuid':'other','mount':str(tmp_path),'filesystem':'exfat'})
    with pytest.raises(ContractError,match='DRIFT'):reports.clear_old_archive(run,acceptance_path=acceptance)
    assert (root/'old/a').exists()
    monkeypatch.setattr(reports,'_archive_volume',original)
    (root/'unknown').write_bytes(b'not in deletion authorization inventory')
    with pytest.raises(ContractError,match='UNEXPECTED_NEW'):reports.clear_old_archive(run,acceptance_path=acceptance)
    assert (root/'old/a').exists()


def test_oss_generation_rejects_old_index_and_old_window_confirmation(tmp_path,monkeypatch):
    run,root,_=oss_rebuild_fixture(tmp_path,monkeypatch)
    run['source_identity']='e'*64;run['run_root']='/remote/run'
    index=n._sealed({'kind':'PADML_WINDOW_ARCHIVE_INDEX_V1','run_identity':run['identity'],'source_identity':run['source_identity'],
        'scientific_run_root':run['run_root'],'members':{},'windows':{}})
    path=root/'index.json';path.write_bytes(canonical_json_bytes(index))
    monkeypatch.setattr(reports,'same_batch_generations',lambda r:{run['identity']:run['source_identity']})
    with pytest.raises(ContractError,match='GENERATION'):
        reports._archive_index(path,run)
    assert reports._archive_confirmed_head(run,6) is None
    old={'horizon':6};new={**old,'archive_generation':run['archive_transfer']['generation']}
    assert reports._archive_receipt_path(root,6,old)!=reports._archive_receipt_path(root,6,new)


def test_oss_constructor_wrong_root_cannot_reach_delete(tmp_path,monkeypatch):
    run,root,acceptance=oss_rebuild_fixture(tmp_path,monkeypatch);other=tmp_path/'wrong';other.mkdir()
    monkeypatch.setattr(reports,'clear_old_archive',lambda *a,**k:pytest.fail('deletion reached'))
    with pytest.raises(ContractError,match='DESTINATION_DRIFT'):
        reports.WindowArchive(run,other,pool=None,call=None,command=None,slots=None,acceptance_path=acceptance)
    assert (root/'old/a').is_file()


def test_archive_later_recharge_keeps_cash_and_exact_generation_authority():
    generation='c'*64
    with pytest.raises(ContractError,match='FUNDS_INSUFFICIENT'):
        reports._archive_rebuild_funds(50,90.78,generation)
    authority={'kind':'USER_AUTHORIZED_ARCHIVE_BEFORE_RECHARGE','generation':generation,
        'authorized_at':'2026-10-09','instruction':'Continue archival; top up later.'}
    funds=reports._archive_rebuild_funds(50,90.78,generation,authority)
    assert funds['available_cny']==50 and funds['estimated_cny']==90.78
    assert funds['proceed_before_recharge']==authority
    with pytest.raises(ContractError,match='AUTHORITY_INVALID'):
        reports._archive_rebuild_funds(50,90.78,'d'*64,authority)


def test_controller_review_retained_across_clear_and_index_publish_failure(tmp_path,monkeypatch):
    from concurrent.futures import ThreadPoolExecutor
    from padml import run as run_module
    run,root,acceptance=oss_rebuild_fixture(tmp_path,monkeypatch)
    run.update(source_identity='e'*64,run_root='/remote/run',hosts=[])
    for name,raw in [('raw-input.xlsx',b'raw'),('source.zip',b'src')]:
        row=run['archive_transfer']['controller_sources'][name];Path(row['path']).write_bytes(raw)
        row['sha256']=hashlib.sha256(raw).hexdigest()
    run['source_bundle_sha256']=run['archive_transfer']['controller_sources']['source.zip']['sha256']
    run['raw_input']['sha256']=run['archive_transfer']['controller_sources']['raw-input.xlsx']['sha256']
    run['identity']=n._sha({k:v for k,v in run.items() if k!='identity'})
    name='shared/final-review/'+'a'*64+'/original-review.json';raw=b'{"original":"review"}'
    pin={'sha256':hashlib.sha256(raw).hexdigest(),'size_bytes':len(raw)}
    old=root/'old/index.json';(old.parent/'objects').mkdir()
    (old.parent/'objects'/pin['sha256']).write_bytes(raw)
    old_body={'members':{name:{'pin':pin,'physical':pin,'storage':'objects/'+pin['sha256'],'member':None}}}
    old.write_bytes(canonical_json_bytes(old_body))
    record_path=Path(run['archive_transfer']['rebuild_record'])
    retained=reports._preserve_archive_controller_reviews(old,old_body,[name],record_path)
    record=json.loads(record_path.read_bytes());record.pop('identity_sha256')
    record['run_identity']=run['identity']
    record['retained_controller_reviews']=retained
    record['funds']=reports._archive_rebuild_funds(50,90.78,record['generation'],{
        'kind':'USER_AUTHORIZED_ARCHIVE_BEFORE_RECHARGE','generation':record['generation'],
        'authorized_at':'2026-10-09','instruction':'Continue; top up later.'})
    record_path.write_bytes(canonical_json_bytes(n._sealed(record)))
    monkeypatch.setattr(run_module,'f45_unit_predecessors',lambda r:[])
    monkeypatch.setattr(reports,'same_batch_generations',lambda r:{run['identity']:run['source_identity']})
    store=reports.WindowArchive._store_staged
    monkeypatch.setattr(reports.WindowArchive,'_store_staged',lambda *a,**k:(_ for _ in ()).throw(OSError('index publication')))
    with ThreadPoolExecutor(max_workers=3) as pool:
        with pytest.raises(OSError,match='index publication'):
            reports.WindowArchive(run,root,pool=pool,call=None,command=None,slots=None,acceptance_path=acceptance)
        assert not (root/'old').exists()
        assert json.loads(record_path.read_bytes())['phase']=='CLEARED'
        assert Path(retained[name]['path']).read_bytes()==raw
        monkeypatch.setattr(reports.WindowArchive,'_store_staged',store)
        archive=reports.WindowArchive(run,root,pool=pool,call=None,command=None,slots=None,acceptance_path=acceptance)
        for future in archive.restore_futures:future.result()
        assert archive.index['members'][name]['pin']==pin
        assert reports._archive_item_bytes(*reports._archive_physical_location(
            archive.index['members'][name],archive.target/'index.json'))==raw
        # Legacy archives used a single source.zip name. Preserve that exact
        # pin while a transport-only successor publishes its own source entity.
        source_key='shared/archive-inputs/sources/'+run['source_bundle_sha256']+'.zip'
        legacy_key='shared/archive-inputs/source.zip'
        archive._store_staged({legacy_key:archive.index['members'][source_key]})
        legacy=archive.index['members'][legacy_key]
        source=run['archive_transfer']['controller_sources']['source.zip']
        Path(source['path']).write_bytes(b'next source')
        source.update(sha256=hashlib.sha256(b'next source').hexdigest(),size_bytes=11)
        run['source_bundle_sha256']=source['sha256']
        recovered=reports.WindowArchive(run,root,pool=pool,call=None,command=None,slots=None,acceptance_path=acceptance)
        for future in recovered.restore_futures:future.result()
        assert recovered.index['members'][legacy_key]==legacy
        new_key='shared/archive-inputs/sources/'+source['sha256']+'.zip'
        assert recovered.index['members'][new_key]['pin']['sha256']==source['sha256']
        assert (recovered.target/legacy['storage']).read_bytes()==b'src'


def test_controller_review_drift_blocks_clear_and_other_missing_sources_reject(tmp_path,monkeypatch):
    run,root,acceptance=oss_rebuild_fixture(tmp_path,monkeypatch)
    record_path=Path(run['archive_transfer']['rebuild_record'])
    with pytest.raises(ContractError,match='SOURCE_MISSING'):
        reports._preserve_archive_controller_reviews(root/'old/index.json',{},['unit/model.zip'],record_path)
    source=tmp_path/'retained-review';source.write_bytes(b'changed')
    record=json.loads(record_path.read_bytes());record.pop('identity_sha256')
    record['retained_controller_reviews']={'shared/final-review/prior/review.json':{
        'path':str(source),'sha256':hashlib.sha256(b'original').hexdigest(),'size_bytes':8}}
    record_path.write_bytes(canonical_json_bytes(n._sealed(record)))
    with pytest.raises(ContractError):reports.clear_old_archive(run,acceptance_path=acceptance)
    assert (root/'old/a').read_bytes()==b'old archive'


def test_oss_cold_transfer_keeps_original_host_request_and_inventory(tmp_path):
    run={'hosts':['H0','H1'],'archive_transfer':{'relay_prefix':'padml-relay/run/gen/'}}
    pin={'sha256':'a'*64,'size_bytes':100}
    original={'host':'H0','horizon':6,'inventory_identity':'b'*64,'members':['model'], 'pins':{'model':pin}}
    first,path=reports._oss_transport_owner(run,tmp_path,original)
    saved=json.loads(path.read_bytes());saved.update(binding={'object_key':'padml-relay/run/gen/objects/'+pin['sha256'],
        'pin':pin},status='UPLOADING',upload_id='original-live-upload')
    path.write_bytes(canonical_json_bytes(saved))
    alternate={'host':'H1','horizon':12,'inventory_identity':'c'*64,'members':['alias'], 'pins':{'alias':pin}}
    again,_=reports._oss_transport_owner(run,tmp_path,alternate)
    assert again==first and again['host']=='H0' and again['horizon']==6
    assert json.loads(path.read_bytes())['upload_id']=='original-live-upload'


def test_oss_queue_seven_remote_hosts_two_local_writes_and_remaining_reserve(tmp_path):
    class Pool:
        def __init__(self):self.calls=[]
        def submit(self,fn,*args,**kwargs):
            f=Future();self.calls.append((fn,args,kwargs,f));return f
    a=reports.WindowArchive.__new__(reports.WindowArchive);a.pool=Pool();a.target=tmp_path
    a.run={'hosts':[f'H{i}' for i in range(7)],'archive_transfer':{'relay_prefix':'padml-relay/run/g/'}}
    a.command=None;a.states={6:{}};a.futures={};a.pending=deque()
    def row(i,phase):
        digest=f'{i+1:064x}';storage='objects/'+digest
        return {'host':f'H{i}','horizon':6,'inventory_identity':'c'*64,'members':[f'm{i}'],
            'pins':{f'm{i}':{'sha256':digest,'size_bytes':100}},'oss_phase':phase,
            'oss_material':{'storage':storage,'physical':{'sha256':digest,'size_bytes':100}}}
    observation={h:{'state':'IDLE'} for h in a.run['hosts']}
    a.pending.extend(row(i,'upload') for i in range(7));a._refill_oss(observation)
    assert len(a.futures)==5
    running=list(a.futures.values());a.futures={}
    for r in running:r.update(oss_phase='poll',retry_at=10**20);a.pending.append(r)
    a._refill_oss(observation)
    assert len(a.futures)==2 and {r['oss_owner']['host'] for r in [*running,*a.futures.values()]}==set(a.run['hosts'])
    a.pending=deque(row(i,'download') for i in range(7));a.futures={}
    (tmp_path/'objects').mkdir()
    (tmp_path/a.pending[0]['oss_material']['storage']).with_suffix('.part').write_bytes(b'x'*10)
    a._refill_oss(observation)
    assert len(a.futures)==2
    assert sorted(r['other_write_reserve'] for r in a.futures.values())==[0,90]


def test_oss_partial_envelope_timeout_is_bounded_without_eof(tmp_path):
    import subprocess,time
    raw=b'{"members":[],"pins":{}}'
    script=('import sys;from padml.reports import archive_members_from_stream;'+
        'archive_members_from_stream('+repr({'sha256':hashlib.sha256(raw).hexdigest(),'size_bytes':len(raw)})+
        ',sys.stdin.buffer,idle_seconds=.15,total_seconds=.3,envelope=True)')
    started=__import__('time').monotonic()
    p=subprocess.Popen([sys.executable,'-B','-c',script],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    try:
        p.stdin.write(raw[:5]);p.stdin.flush()
        p.wait(timeout=5)
        assert p.returncode!=0 and b'ARCHIVE_REQUEST_TIMEOUT' in p.stderr.read()
        assert __import__('time').monotonic()-started<5
    finally:
        p.stdin.close()
        if p.poll() is None:p.kill();p.wait()


@pytest.mark.skipif(not hasattr(os,'fork'),reason='native Unix archive adapter')
def test_oss_fork_release_recovers_after_uploaded_before_pack_cleanup(tmp_path,monkeypatch):
    import time
    from padml import oss
    run,_,_=oss_rebuild_fixture(tmp_path,monkeypatch);run['run_root']=str(tmp_path/'remote')
    base=Path(run['run_root']);base.mkdir();(base/'a').write_bytes(b'a');(base/'b').write_bytes(b'b')
    pins={k:{'sha256':sha256_file(base/k),'size_bytes':1} for k in ('a','b')}
    inventory={'identity_sha256':'e'*64,'members':{k:{**v,'native_file':False} for k,v in pins.items()}}
    monkeypatch.setattr(reports,'_read_archive_inventory',lambda *a:inventory)
    scope={'generation':run['archive_transfer']['generation'],'horizon':6,'inventory_identity':'e'*64,'pins':pins}
    payload={'horizon':6,'inventory_identity':'e'*64,'archive_request_id':n._sha(scope),'action':'prepare'}
    body={'members':['a','b'],'pins':pins}
    prepared=reports.archive_oss_operation(run,payload,body)
    def fake_upload(*args):time.sleep(.12)
    monkeypatch.setattr(oss,'upload_parts',fake_upload)
    original_unlink=Path.unlink
    def crash_cleanup(path,*args,**kwargs):
        if path.suffix=='.zip':raise OSError('after durable UPLOADED')
        return original_unlink(path,*args,**kwargs)
    monkeypatch.setattr(Path,'unlink',crash_cleanup)
    sent=reports.archive_oss_operation(run,{**payload,'action':'upload'},
        {**body,'tokens':{'key':run['archive_transfer']['relay_prefix']+prepared['storage']}})
    assert sent['phase']=='UPLOADING'
    os.wait()
    status=reports.archive_oss_operation(run,{**payload,'action':'status'},body)
    assert status['phase']=='UPLOADED'
    folder=base/'shared/archives/oss-relay'/run['archive_transfer']['generation']
    assert (folder/(payload['archive_request_id']+'.zip')).is_file()
    monkeypatch.setattr(Path,'unlink',original_unlink)
    reports.archive_oss_operation(run,{**payload,'action':'release'},body)
    assert not list(folder.glob('*.zip')) and (base/'a').read_bytes()==b'a'
