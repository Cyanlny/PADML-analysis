"""Scoped S3A transport through the existing publisher/worker; never fit."""
import copy
import json
from pathlib import Path

import pytest

from padml import f2_kernel as kernel, f5
from padml.bundle import ContractError, canonical_json_bytes, sha256_bytes, sha256_file, read_safe_zip, write_deterministic_zip
from test_primary_outer12_rsf_s2_inputs import _published


def test_publication_only_original_compiler_to_seven_workers(tmp_path, monkeypatch):
    """Existing boundary -> original publisher -> workers; synthetic inputs only.

    Clinical materialization and scientific preparation-reader fixtures are
    isolated; compiler-source proof, transport and atom readers are original.
    """
    import os
    from padml import f4, nested_loco as nested
    from test_primary_outer12_rsf_prepared_pipeline import POLICY
    compiler = Path(os.environ["PADML_PRIMARY_6335_SOURCE"])
    capture = {}
    outputs, child, tasks = _published(tmp_path, monkeypatch, stage="S3A", publication_capture=capture)
    original = dict(capture["spec"])
    original.pop("native_search_root"); original.pop("native_search_batch")
    decision = {"UNFITTED": True}
    q_raw = canonical_json_bytes({"kind": "PADML_F5_Q_INPUT_V1", "spec": original,
                                  "task": {"science_decision": decision}})
    phase, ids = f5._a12_q_stop_phase("S3A", refit=True, family="RSF")
    prior_phase, _ = f5._a12_q_stop_phase("S2", refit=True, family="RSF")
    input_pin = {"sha256": sha256_bytes(q_raw), "size_bytes": len(q_raw)}
    records, batches = [], []
    for i in range(7):
        batch = tmp_path / f"existing-batch-{i}"; batch.mkdir()
        row = {"phase": prior_phase, "input": input_pin, "UNFITTED": i}
        (batch / "execution.json").write_bytes(canonical_json_bytes(row))
        batches.append(batch); records.append(row)
    archive = tmp_path / "existing-preparation.zip"
    metadata = {"input.json": q_raw, "result.json": canonical_json_bytes({"UNFITTED": True}),
                "numbers.json": canonical_json_bytes({"UNFITTED_NUMERICAL_FIXTURE": True})}
    write_deterministic_zip(archive, metadata)
    receipt = {"worker_inputs_ready": False, "outer_fold": 2, "input": input_pin,
        "phase": phase, "task_ids": ids, "confirmed_model_fits": 320, "confirmed_stop_fits": 0,
        "predecessor_execution_sha256": [sha256_bytes(canonical_json_bytes(row)) for row in records],
        "f1_identity": "b" * 64, "f2_acceptance_sha256": "c" * 64,
        "compilation_source_identity": "6335b6b30c33ce07a474a20a7426c7e6564feaf7322aa126ad0c3a9a3dd7530e",
        "preparation_metadata": {name: {"sha256": sha256_bytes(raw), "size_bytes": len(raw)}
                                 for name, raw in metadata.items()}}
    receipt_path = tmp_path / "original-compilation.json"
    receipt_path.write_bytes(canonical_json_bytes(receipt))
    before = archive.read_bytes(), receipt_path.read_bytes()
    proof_reads = []
    def preparation_reader(raw, prepared, producer, *, compilation_receipt, compilation_source_bundle):
        assert raw == q_raw and compilation_receipt == receipt
        members = f4._retained_full0_source_members(compilation_source_bundle, primary_rsf_inputs=True)
        assert sha256_bytes(canonical_json_bytes(members)) == receipt["compilation_source_identity"]
        assert producer.read_bytes() == b"UNFITTED_PRODUCER"
        actual = read_safe_zip(prepared) if prepared.is_file() else {
            name: (prepared / name).read_bytes() for name in metadata}
        assert actual == metadata
        proof_reads.append(prepared)
        return child, tasks
    monkeypatch.setattr(f5, "_primary_rsf_prepared_input", preparation_reader)
    registered = {key: value for key, value in capture["calls"][0][1].items()
                  if key not in {"partitions", "projected_partition_ids", "projected_partition_count"}}
    registered["partitions"] = list({call[6]["partition_id"]: call[6]
                                     for call in capture["calls"]}.values())
    materialized = tmp_path / "retained-materialized"; materialized.mkdir()
    monkeypatch.setattr(f4, "load_f4_inputs", lambda *a, **k: {
        "source": {key: receipt[key] for key in ("f1_identity", "f2_acceptance_sha256")}, "o_fit_source": {}})
    def retained_fold(frozen, outer, path, **options):
        assert outer == 2 and path == materialized and options["reuse_existing"] is True
        return registered
    monkeypatch.setattr(f4, "_materialize_o_fit_fold", retained_fold)
    monkeypatch.setattr(nested, "outer_fresh_score_families", lambda _: [])
    for name in ("_prepare_primary_outer_rsf_search", "_consume_q_search_batches", "_run_final_complex_search"):
        monkeypatch.setattr(f5, name, lambda *a, **k: pytest.fail("REPREPARATION_OR_SCIENCE_FORBIDDEN"))
    report = f4.compile_o_fit_bundle(tmp_path, archive, outer_fold=2, science_decision=decision,
        resource_policy=POLICY, retained_bytes_per_component=1024**2,
        expanded_bytes_per_component=1024**2, shared_storage_bytes=1024**3,
        primary_rsf_prepare=True, primary_q_unit_outputs=outputs,
        primary_producer_source_bundle=tmp_path / "producer.zip",
        primary_publication_recovery={"receipt": receipt_path, "compiler_source": compiler,
            "materialized_fold": materialized, "batches": batches})
    assert report["publication_only"] is True and report["worker_inputs_ready"] is True
    seen = []
    def execute(function, units, root, control, observed_phase, pin, **kwargs):
        assert function is kernel._run_r_prediction_pool_task and observed_phase == phase
        for name, (call, native) in units.items():
            assert call[2] == tasks[name] and len(call[2]) == 3
            assert call[0] == child and native == (name, *[task["task_id"] for task in tasks[name]])
            seen.append(name)
        raise f5._QBatchBoundary({"UNFITTED": True})
    monkeypatch.setattr(f5, "_execute_q_search_batch", execute)
    for i, output in enumerate(outputs):
        path = Path(output[0])
        assert f5._execute_a12_prepared_q_batch(path, tmp_path / f"worker-{i}",
            expected_sha256=sha256_file(path), task_ids=output[1:], batch_root=tmp_path / f"batch-{i}",
            retained_bytes_per_task=1024**2, expected_family="RSF",
            selection_horizon_months=12) == {"UNFITTED": True}
    assert len(seen) == len(set(seen)) == 100 and set(seen) == set(tasks)
    assert len(proof_reads) == 9  # owner, publisher and seven transported readers
    assert (archive.read_bytes(), receipt_path.read_bytes()) == before


@pytest.mark.parametrize("stage,atoms,width,history", [("S3A", 100, 3, 320), ("S3B1", 75, 2, 620), ("S3B2", 75, 4, 770)])
def test_s3a_100_original_atoms_publish_and_enter_original_worker_once(tmp_path, monkeypatch, stage, atoms, width, history):
    outputs, spec, tasks = _published(tmp_path, monkeypatch, stage=stage)
    phase, ids = f5._a12_q_stop_phase(stage, refit=True, family="RSF")
    assert list(tasks) == ids and len(ids) == atoms and all(len(rows) == width for rows in tasks.values())
    assert f5._a12_q_prepared_predecessors(stage, refit=True, family="RSF") == {"total": history, "stop": 0}
    seen = []
    def execute(function, units, root, control, observed_phase, input_ref, **kwargs):
        assert function is kernel._run_r_prediction_pool_task and observed_phase == phase
        assert control["execution_worker_memory_bytes"] == 2147483648 and control["execution_scratch_reserve_bytes"] == 0
        for name, (call, native) in units.items():
            assert canonical_json_bytes(call[0]) == canonical_json_bytes(spec)
            assert canonical_json_bytes(call[2]) == canonical_json_bytes(tasks[name])
            assert native == (name, *[row["task_id"] for row in tasks[name]])
            assert not kernel._contains_key(call[1], "evaluation_response")
            seen.append(name)
        raise f5._QBatchBoundary({"UNFITTED": True})
    monkeypatch.setattr(f5, "_execute_q_search_batch", execute)
    for i, output in enumerate(outputs):
        p = Path(output[0])
        assert f5._execute_a12_prepared_q_batch(p, tmp_path / f"worker-{i}",
            expected_sha256=sha256_file(p), task_ids=output[1:], batch_root=tmp_path / f"batch-{i}",
            retained_bytes_per_task=1024**2) == {"UNFITTED": True}
    assert len(seen) == len(set(seen)) == atoms and set(seen) == set(ids)


@pytest.mark.parametrize("damage", ["report", "predecessor", "seed", "parameter", "half", "extra-response"])
@pytest.mark.parametrize("stage", ["S3A", "S3B1", "S3B2"])
def test_s3a_damage_rejected_before_science(tmp_path, monkeypatch, damage, stage):
    outputs, _, _ = _published(tmp_path, monkeypatch, stage=stage)
    entries = read_safe_zip(Path(outputs[0][0])); record = json.loads(entries["prepared-q.json"])
    if damage == "predecessor":
        record["predecessor_execution_sha256"][-1] = record["predecessor_execution_sha256"][0]
    elif damage in {"report", "extra-response"}:
        n = f"primary-{stage.lower()}/report.json" if damage == "report" else "data/OUTER_response.csv"
        entries[n] = b"UNFITTED_TAMPERED"
        record["members"][n] = {"sha256": sha256_bytes(entries[n]), "size_bytes": len(entries[n])}
    else:
        pins = record["units"][record["task_ids"][0]]; old = pins[2]
        value = copy.deepcopy(record["arguments"][old])
        if damage == "seed": value[0]["seed"] += 1
        elif damage == "parameter": value[0]["parameters"]["UNFITTED"] += 1
        else: value.pop()
        new = sha256_bytes(canonical_json_bytes(value)); pins[2] = new
        del record["arguments"][old]; record["arguments"][new] = value
    entries["prepared-q.json"] = canonical_json_bytes(record)
    p = tmp_path / "damaged.zip"; write_deterministic_zip(p, entries)
    monkeypatch.setattr(f5, "_execute_q_search_batch", lambda *a, **k: pytest.fail("damaged input reached science"))
    with pytest.raises(ContractError):
        f5._execute_a12_prepared_q_batch(p, tmp_path / "bad-worker", expected_sha256=sha256_file(p),
            task_ids=record["task_ids"], batch_root=tmp_path / "bad-batch", retained_bytes_per_task=1024**2)
