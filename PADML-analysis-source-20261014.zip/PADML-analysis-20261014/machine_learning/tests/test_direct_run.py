from __future__ import annotations

import shutil
from pathlib import Path
from unittest.mock import Mock

import pytest

from padml.run import prepare
from padml.f2 import F2_COMPONENTS, canonical_unit_ids, compile_f2_plan
from padml.bundle import ContractError, canonical_json_bytes, execution_contract, sha256_bytes
from padml.capsule import build_capsule, load_capsule
from padml.runtime import R_FPM_CORRECTION, R_LIBRARY
from padml.runtime_bundle import RUNTIME_IDENTITY, RUNTIME_OBJECTS
from padml import run as direct_run
from padml._science_authority import load_science_authority, selected_route_profiles
from padml.f2 import materialize_requests


SOURCE_RUNTIME = Path(
    "/Users/liuningyuan/Desktop/PAD/PADML_F2_V1_Runtime"
)


@pytest.fixture(autouse=True)
def synthetic_host_capacity(monkeypatch):
    monkeypatch.setattr("padml.runtime.effective_cpu_count", lambda: 128)


def test_native_fpm_correction_is_bound_to_the_worker_runtime() -> None:
    assert R_LIBRARY.split(":")[0] == R_FPM_CORRECTION
    objects = [value for value in RUNTIME_OBJECTS if value["role"] == "R_FPM_CONSTRAINT_CORRECTION"]
    assert len(objects) == 1
    assert objects[0]["key"].endswith(f"/{objects[0]['sha256']}/r-fpm-correction.tar")
    assert RUNTIME_IDENTITY == sha256_bytes(canonical_json_bytes(RUNTIME_OBJECTS))


def test_prepare_builds_one_six_host_pool24_run(tmp_path: Path) -> None:
    (tmp_path / "input/f1").mkdir(parents=True)
    (tmp_path / "build").mkdir()
    for relative in (
        "input/f1/input-manifest.json",
        "build/common-input.zip",
        "build/f1-replay-seal.zip",
    ):
        target = tmp_path / relative
        shutil.copyfile(SOURCE_RUNTIME / relative, target)
    value = prepare(tmp_path, "f2-test-direct", host_effective_cpus=dict.fromkeys(direct_run.HOSTS,32))
    assert value["execution"] == {
        "aggregate": "LOCAL_AFTER_45_VALIDATED_RESULTS",
        "engine_threads": 1,
        "host_parallelism": 6,
        "order": "LONGEST_EXPECTED_FAMILY_FIRST",
        "pool_workers": dict.fromkeys(direct_run.HOSTS,24),
    }
    assert len(value["result_keys"]) == 45
    assert set(value["host_queues"]) == {"H0", "H1", "H4", "H5", "H6", "H7"}
    assert [len(queue) for queue in value["host_queues"].values()] == [8, 8, 8, 7, 7, 7]
    queued = [unit for queue in value["host_queues"].values() for unit in queue]
    assert len(queued) == len(set(queued)) == 45
    assert set(queued) == set(canonical_unit_ids()[:45])
    assert [value["host_queues"][host][-1] for host in ("H0", "H1", "H4")] == list(canonical_unit_ids()[42:45])
    assert (tmp_path / "runs/f2-test-direct/worker.zip").is_file()
    assert (tmp_path / "runs/f2-test-direct/capsule.zip").is_file()


@pytest.mark.parametrize("center_workers", [24, 56])
def test_diagnostic_pool_override_preserves_model_plan_and_scientific_coordinates(tmp_path, center_workers):
    workers = dict(zip(F2_COMPONENTS, [center_workers, 56, 56], strict=True))
    original = compile_f2_plan()
    updated = compile_f2_plan(p2c2t_pool_workers=workers)
    assert original["units"][:42] == updated["units"][:42]
    assert original["units"][45] == updated["units"][45]
    for old, new in zip(original["units"][42:45], updated["units"][42:45], strict=True):
        assert {**new, "internal_threads": 24} == old
    common = SOURCE_RUNTIME / "build/common-input.zip"
    target = tmp_path / "capsule.zip"
    build_capsule(run_id="f2-diagnostic-pool-test", source_identity="1" * 64,
                  runtime_identity=RUNTIME_IDENTITY, worker_identity="2" * 64,
                  common_input_path=common, target=target, p2c2t_pool_workers=workers)
    capsule = load_capsule(target, common)
    assert capsule["manifest"]["plan"] == updated
    requests = capsule["requests"]
    assert [execution_contract(requests[unit]["plan"])["pool_workers"]
            for unit in canonical_unit_ids()[42:45]] == [center_workers, 56, 56]
    assert all(execution_contract(requests[unit]["plan"])["pool_workers"] == 24
               for unit in canonical_unit_ids()[:42])


@pytest.mark.parametrize("slots", [0, -1, True, 56.0])
def test_diagnostic_pool_capacity_rejected_by_plan_and_request(slots):
    workers = dict(zip(F2_COMPONENTS, [24, slots, 56], strict=True))
    with pytest.raises(ContractError, match="F2_P2C2T_POOL_WORKERS_INVALID"):
        compile_f2_plan(p2c2t_pool_workers=workers)
    with pytest.raises(ContractError, match="EXECUTION_MODE_THREADS_INVALID"):
        execution_contract({"action": "P2C2T", "internal_threads": slots,
                            "coordinates": [{"axis": "execution_mode", "value": "PROCESS_POOL"}]})


@pytest.mark.parametrize("cpus", [32,64,128])
def test_all_f2_requests_bind_observed_remote_capacity_without_changing_science(tmp_path,monkeypatch,cpus):
    from padml.runtime import pool_capacity
    slots=pool_capacity(cpus)
    workers=dict.fromkeys(canonical_unit_ids()[:45],slots)
    plan=compile_f2_plan(unit_pool_workers=workers)
    old=compile_f2_plan()
    for before,after in zip(old["units"],plan["units"],strict=True):
        assert {**after,"internal_threads":before["internal_threads"]}==before
    common=SOURCE_RUNTIME / "build/common-input.zip"
    target=tmp_path / "capsule.zip"
    build_capsule(run_id="f2-host-capacity-test",source_identity="1"*64,
                  runtime_identity=RUNTIME_IDENTITY,worker_identity="2"*64,
                  common_input_path=common,target=target,unit_pool_workers=workers)
    # Archive validation must not query this reader's CPU or invalidate old 24/56.
    monkeypatch.setattr("padml.runtime.effective_cpu_count",lambda:None)
    capsule=load_capsule(target,common)
    assert capsule["manifest"]["plan"]==plan
    assert [execution_contract(capsule["requests"][unit]["plan"])["pool_workers"]
            for unit in canonical_unit_ids()[:45]]==[slots]*45
    routes=selected_route_profiles(pool_workers=slots)
    assert all(row["profile"]["pool_workers"]==slots for row in routes.values())


def test_preparation_requires_remote_cpu_observations(tmp_path):
    with pytest.raises(ContractError,match="CPU_OBSERVATIONS_REQUIRED"):
        prepare(tmp_path,"f2-no-guessed-capacity")


@pytest.fixture
def admitted_predecessors(tmp_path, monkeypatch, request):
    """Mock upstream admission only; exercise real aggregate and stage validators."""
    root = tmp_path.resolve()
    (root / "results").mkdir()
    requests = materialize_requests(
        run_id="aggregate-unit-test", source_identity="1" * 64,
        runtime_identity=RUNTIME_IDENTITY, worker_identity="2" * 64,
        input_identity="3" * 64,
        p2c2t_pool_workers=dict.fromkeys(F2_COMPONENTS, getattr(request, "param", 56)),
    )
    f1_identity = "4" * 64
    predecessors = {}
    for unit_id, request in list(requests.items())[:45]:
        coordinates = {row["axis"]: row["value"] for row in request["plan"]["coordinates"]}
        if request["plan"]["action"] == "MODEL_DEVELOPMENT":
            fold, family = coordinates["outer_fold"], coordinates["family"]
            predictions = [{"Patient_ID": f"test-fold-{fold}"}]
            monthly = {"predictions": predictions, "horizons": list(range(37))}
            spec = {"family": family, "test_only_fold": fold}
            value = {
                "artifact_kind": "F2_MODEL_DEVELOPMENT", "fold": fold, "family": family,
                "selected_spec": spec,
                "selected_spec_sha256": sha256_bytes(canonical_json_bytes(spec)),
                "selector_evidence_sha256": sha256_bytes(str(fold).encode()),
                "lineage": {"f1_approved_result_sha256": f1_identity},
                "predictions": predictions, "monthly_oof": monthly,
                "monthly_oof_sha256": sha256_bytes(canonical_json_bytes(monthly)),
            }
        else:
            component = coordinates["component"]
            tasks, fits = dict(zip(F2_COMPONENTS, [(66, 6600), (504, 10080), (140, 14000)], strict=True))[component]
            value = {
                "artifact_kind": "F2_P2C2T", "component": component,
                "status": "PASS", "typed_terminal": "PASS",
                "expected_task_count": tasks, "executed_task_count": tasks,
                "expected_fit_count": fits, "executed_fit_count": fits,
                "task_result_set_sha256": sha256_bytes(component.encode()),
            }
        predecessors[unit_id] = {
            "status": "PASS", "envelope": request, "value": value,
            "result_sha256": sha256_bytes(unit_id.encode()),
            "artifact": {**request["artifacts"][0], "sha256": sha256_bytes(canonical_json_bytes(value))},
        }
    capsule = {
        "requests": requests, "authority_slice": load_science_authority(),
        "manifest": {"plan": compile_f2_plan(p2c2t_pool_workers=dict.fromkeys(
                         F2_COMPONENTS, requests[canonical_unit_ids()[42]]["plan"]["internal_threads"])),
                     "identity_records": {"execution_plan": {"route_profiles": selected_route_profiles()}}},
    }
    run = {
        "run_id": "aggregate-unit-test", "identity": "5" * 64,
        "f1_identity": f1_identity, "capsule": {"path": str(root / "capsule.zip")},
        "common_input": {"path": str(root / "common-input.zip")},
    }
    admission = Mock(return_value=(predecessors, ("model-confirmation",)))
    monkeypatch.setattr(direct_run, "load_run", lambda _: run)
    monkeypatch.setattr(direct_run, "load_capsule", lambda *_: capsule)
    monkeypatch.setattr(direct_run, "validate_present", admission)
    return root, capsule, predecessors, admission


@pytest.mark.parametrize("admitted_predecessors", [24, 56], indirect=True)
def test_aggregate_reuses_admission_and_keeps_real_downstream_validation(
    admitted_predecessors, monkeypatch,
):
    root, capsule, predecessors, admission = admitted_predecessors
    diagnostic_workers = capsule["requests"][canonical_unit_ids()[42]]["plan"]["internal_threads"]
    validator = Mock(wraps=direct_run.validate_f2_unit_result)
    monkeypatch.setattr(direct_run, "validate_f2_unit_result", validator)
    result = direct_run.aggregate(root)
    admission.assert_called_once_with(root)
    assert validator.call_count == 1
    args, kwargs = validator.call_args
    assert args[0]["unit_id"] == "model-confirmation"
    assert kwargs["authority_mode"] == "LOCAL_SOLE_VALIDATOR"
    assert list(kwargs["admitted_sources"]) == list(predecessors)
    assert all(kwargs["admitted_values"][unit] is row["value"] for unit, row in predecessors.items())
    assert result["stage_validation"]["outcome"] == "PASS"
    assert result["stage_validation"]["unit_count"] == result["unit_count"] == 46
    assert result["stage_validation"]["monthly_oof_prediction_value_count"] == 42 * 37
    assert result["pool_workers"] == 24
    assert result["p2c2t_pool_workers"] == dict.fromkeys(canonical_unit_ids()[42:45], diagnostic_workers)
    assert list(result["result_sha256"]) == list(canonical_unit_ids())
    assert result["aggregate_sha256"] == sha256_bytes((root / "results/model-confirmation.zip").read_bytes())
    assert (root / "f2-acceptance.json").read_bytes() == canonical_json_bytes(result)


@pytest.mark.parametrize("failure,reason", [
    ("missing", "F2_REMOTE_RESULT_SET_INCOMPLETE"),
    ("aggregate", "F2_CONFIRMATION_LOCAL_RECONSTRUCTION_MISMATCH"),
    ("lineage", "F2_STAGE_F1_RESULT_LINEAGE_INVALID"),
])
def test_aggregate_still_rejects_missing_inconsistent_or_wrong_f1_results(
    admitted_predecessors, monkeypatch, failure, reason,
):
    root, _, predecessors, admission = admitted_predecessors
    if failure == "missing":
        predecessors.pop(canonical_unit_ids()[44])
    elif failure == "lineage":
        predecessors[canonical_unit_ids()[0]]["value"]["lineage"]["f1_approved_result_sha256"] = "9" * 64
    else:
        original = direct_run.aggregate_confirmation

        def corrupt(*args):
            return {**original(*args), "model_result_count": 41}

        monkeypatch.setattr(direct_run, "aggregate_confirmation", corrupt)
    with pytest.raises(ContractError, match=reason):
        direct_run.aggregate(root)
    admission.assert_called_once_with(root)
    assert not (root / "f2-acceptance.json").exists()


@pytest.mark.parametrize("admitted_predecessors", [24, 56], indirect=True)
@pytest.mark.parametrize("unit_index", [42, 43, 44])
@pytest.mark.parametrize("reuse", [False, True])
def test_worker_seals_diagnostic_after_consumed_sources_are_assembled(
    admitted_predecessors, monkeypatch, unit_index, reuse,
):
    from padml import worker
    from padml.bundle import execution_result_contract, read_safe_zip, strict_json_bytes

    root, capsule, predecessors, _ = admitted_predecessors
    unit = canonical_unit_ids()[unit_index]
    request = capsule["requests"][unit]
    produced = {
        **predecessors[unit]["value"],
        **execution_result_contract(request["plan"]),
    }
    produced["result_identity_sha256"] = sha256_bytes(canonical_json_bytes(produced))
    original = canonical_json_bytes(produced)
    compute = Mock(return_value=produced)
    monkeypatch.setattr(worker, "load_capsule", lambda *_: capsule)
    monkeypatch.setattr(worker._Dependencies, "load", lambda _, key: predecessors[key])
    monkeypatch.setattr(worker, "execute_p2c2t", compute)
    monkeypatch.setenv("PADML_WORKER_SHA256", request["identities"]["worker"])
    target = root / "results" / f"{unit}.zip"

    prior = root / "previous-diagnostic.zip" if reuse else None
    if prior is not None:
        worker._write_result(request, prior, produced)
    result = worker.execute(root / "capsule.zip", root / "common.zip", unit, target,
                            reuse_non_fpm=prior)
    assert compute.call_args.kwargs["reuse_non_fpm"] == (produced if reuse else None)
    entries = read_safe_zip(target)
    envelope = strict_json_bytes(entries["manifest.json"])
    payload = entries[envelope["artifacts"][0]["relative_path"]]
    value = strict_json_bytes(payload)
    identity = {key: item for key, item in value.items() if key != "result_identity_sha256"}
    assert value["result_identity_sha256"] == sha256_bytes(canonical_json_bytes(identity))
    assert len(value["consumed_sources"]) == 42
    assert {key: item for key, item in value.items()
            if key not in {"result_identity_sha256", "consumed_sources"}} == {
                key: item for key, item in produced.items() if key != "result_identity_sha256"
            }
    assert canonical_json_bytes(produced) == original
    assert envelope["artifacts"][0]["sha256"] == sha256_bytes(payload)
    assert result["sha256"] == sha256_bytes(target.read_bytes())
    compute.assert_called_once()
