"""Original Q replay routing with synthetic inputs; never a fitted Q proof."""
from pathlib import Path

import pytest

from padml import f5, f4_compact, nested_loco as nested, runtime
from padml.bundle import ContractError, canonical_json_bytes
from test_nested_full_development import (
    full_inputs, unfitted_selector_consumers, _physical_full_inputs, _unfitted_confirmed_decision,
)


@pytest.mark.parametrize("family", ["GBM_COX", "XGBOOST_COX", "COXTIME_SET_A"])
def test_same_line_q_uses_only_original_numerical_replay(
        full_inputs, unfitted_selector_consumers, tmp_path, monkeypatch, family):
    plan, parts, final = _physical_full_inputs(full_inputs, tmp_path / "inputs", complete_covariates=True)
    selector = tmp_path / "selector"
    f5._nested_full_selector_program(plan, parts, final, selector, rscript="UNFITTED", replay=False)
    base = _unfitted_confirmed_decision(fixed_bootstrap=True)
    decision = nested._sealed({**{k: v for k, v in base.items() if k != "identity_sha256"},
        "twelve_month_development": nested._twelve_month_development_contract()})
    monkeypatch.setattr(f5, "resolve_pool_workers", lambda workers: 1)
    task = f5.compile_nested_full_complex_search_task(plan, parts, final, selector,
        family=family, rscript="UNFITTED", selection_horizon_months=12, science_decision=decision)
    registered = f5._complex_runtime_registered_inputs(task, parts)
    spec = f5._complex_search_execution_spec(task, registered)
    spec.update(threads=1, pool_workers=1)
    spec["final_search_source"] = {**spec["final_search_source"], "producer_execution": {
        k: spec[k] for k in ("execution_mode", "threads", "pool_workers", "engine_threads")}}
    root = tmp_path / "q"
    (root / "native").mkdir(parents=True)
    (root / "input.json").write_bytes(canonical_json_bytes({"kind": "PADML_F5_Q_INPUT_V1", "task": task, "spec": spec}))
    candidate = task["candidate_trials"]["S1"][0]
    selected = {"family": family, "candidate_id": candidate.get("candidate_id", candidate.get("trial_id")),
        "parameters": candidate if family == "COXTIME_SET_A" else candidate["parameters"],
        "selection_metric": "IBS_0_12", "selection_stage": "S3B2",
        **({"selected_trees": 100} if family == "GBM_COX" else
           {"selected_rounds": 20} if family == "XGBOOST_COX" else {"locked_epoch": 50})}
    result = nested._sealed({"UNFITTED_NUMERICAL_LEAF": True, "family": family,
        "execution_scope": "F5_FULL_DEVELOPMENT_SEARCH", "registered_inputs_identity_sha256": registered["identity"],
        "selected_parents": task["selected_parents"], "selected_spec": selected,
        "selected_spec_sha256": nested._sha(selected)})
    (root / "result.json").write_bytes(canonical_json_bytes(result))
    (root / "native/UNFITTED-model.rds").write_bytes(b"SYNTHETIC_NOT_A_MODEL")
    f4_compact._full_pipeline_q_numerical_members(root, publish=True)
    originals = {p: p.read_bytes() for p in root.rglob("*") if p.is_file()}
    calls = []
    def numerical(actual_spec, actual_registered, scratch):
        assert actual_spec["native_search_numbers"] is True
        assert actual_spec["native_search_replay"] is True
        assert "native_search_batch" not in actual_spec
        assert actual_spec["selection_horizon_months"] == 12
        assert actual_registered == registered
        calls.append(family)
        return result
    monkeypatch.setattr(f5, "_run_final_complex_search", numerical)
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda path: {
        "effective_cpus": 16, "available_memory_bytes": 32 * 1024**3,
        "scratch_available_bytes": 32 * 1024**3, "scratch_root": str(path)})
    policy = {"configured_worker_ceiling": runtime.CPU_MINUS_8,
        "memory_bytes_per_worker": 2 * 1024**3, "memory_reserve_bytes": 0,
        "scratch_bytes_per_worker": 1, "scratch_reserve_bytes": 0,
        "transfer_archive_worker_ceiling": 8}
    assert f5._final_complex_search_program(task, parts, root,
        replay=True, workers=1, resource_policy=policy) == result
    assert calls == [family]
    assert {p: p.read_bytes() for p in root.rglob("*") if p.is_file()} == originals
    development = f5._nested_full_score_development(plan, parts, final, selector, {family: root},
        rscript="UNFITTED", workers=1, resource_policy=policy, family=family,
        selection_horizon_months=12, science_decision=decision)
    assert development["selection_horizon_months"] == 12 and development["science_decision"] == decision
    assert development["locked_specs"] == {family: selected}
    assert development["complex_search_evidence"][0]["task"] == task
    assert calls == [family, family]
    # No new producer, first audit, or old-source alias is granted by this route.
    for changes in ({"replay": False}, {"native_audit": True},
                    {"retained_full0_source_bundle": tmp_path / "old.zip"}):
        target = tmp_path / "unstarted" if changes.get("replay") is False else root
        with pytest.raises(ContractError, match="F5_FULL0_(RSF_S1S2_NUMBERS_ONLY|GBM_COMMON_PREFIX_SCOPE_INVALID)"):
            f5._final_complex_search_program(task, parts, target,
                **{"replay": True, "workers": 1, "resource_policy": policy, **changes})
    assert calls == [family, family] and not (tmp_path / "unstarted").exists()
    if family == "GBM_COX":
        # Qualify the first common-prefix input admission without consuming
        # this deliberately unsuitable same-line fixture as a 24-month source.
        admissions = []
        def before_numbers(effective, observation, *, legal_tasks):
            assert effective['scratch_reserve_bytes'] == 0
            assert effective['memory_bytes_per_worker'] == 2 * 1024**3 and legal_tasks == 1
            assert effective['memory_reserve_bytes'] == 64 * (root / 'input.json').stat().st_size
            admissions.append(effective)
            raise ContractError('UNFITTED_INPUT_ADMISSION_BOUNDARY')
        with monkeypatch.context() as setup:
            setup.setattr(runtime, 'resource_admission', before_numbers)
            with pytest.raises(ContractError, match='UNFITTED_INPUT_ADMISSION_BOUNDARY'):
                f5._final_complex_search_program(task, parts, tmp_path / 'unstarted', replay=False,
                    resource_policy={**policy, 'scratch_reserve_bytes': 10**15},
                    retained_q_resource_policy=policy, retained_q_producer_source_bundle=tmp_path / 'not-read.zip',
                    batch_options={'prepare_only': True, 'q_batches': [root]})
        assert len(admissions) == 1 and calls == [family, family]
