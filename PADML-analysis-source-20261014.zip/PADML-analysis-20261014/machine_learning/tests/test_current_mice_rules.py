import copy
import math

import pytest

from padml._science_authority import load_science_authority, selector_parent_names
from padml.bundle import ContractError
from padml.f1_kernel import effective_mice_rows, formula_value, mice_terminal_valid, validate_mice_continuation


def test_roles_are_distinct_and_old_clinical_predictor_rules_stay_locked():
    science = load_science_authority()['science']['mice']
    parents, targets = set(selector_parent_names()), {r['target'] for r in science['target_rules']}
    assert len(parents) == 44 and len(targets) == 33
    assert {'RBC','HGB','MCV','RDW_CV','INR'} <= parents
    assert not parents & {'HCT','MCH','MCHC','RDW_SD','PT','PT_Activity'}
    assert {'PT','PT_Activity','INR'} <= targets
    assert not targets & {'HCT','MCH','MCHC','Barthel_Admission','Center'}
    assert {'Center','Barthel_Admission','HCT','MCH','MCHC'} <= set(science['always_forbidden_predictors'])
    assert all('Barthel_Admission' not in group for group in science['predictor_groups'].values())


def test_formula_snapshot_conflicts_and_no_recursive_completion():
    raw = {
        'unique':{'RBC':'', 'HCT':'40', 'MCV':'100', 'HGB':'', 'MCH':'30'},
        'conflict':{'RBC':'', 'HCT':'40', 'MCV':'100', 'HGB':'150', 'MCH':'30'},
        'invalid':{'RBC':'', 'HCT':'40', 'MCV':'0', 'HGB':'150', 'MCH':'0'},
        'consistent':{'RBC':'', 'HCT':'40', 'MCV':'100', 'HGB':'120', 'MCH':'30'},
    }
    before = copy.deepcopy(raw)
    filled = effective_mice_rows(raw)
    assert filled['unique']['RBC'] == '4' and filled['unique']['HGB'] == ''
    assert filled['conflict']['RBC'] == filled['invalid']['RBC'] == ''
    assert filled['consistent']['RBC'] == '4'
    assert raw == before


def test_total_projection_cannot_restore_excluded_channels_and_unconfirmed_relations_do_not_fill():
    raw = {'one':{'Patient_ID':'one','RBC':'','HCT':'40','MCV':'100','ALB':'42','TP':'','GLB':'28',
                  'WBC':'9.51','NEUT':'6','LYMPH':'3','MONO':'','ESO':'.5','BASO':'.43'}}
    filled = effective_mice_rows(raw)['one']
    assert filled['RBC'] == '4' and filled['TP'] == filled['MONO'] == ''
    assert not set(filled) & {'AST','ALT','AST_ALT','event_aux','nelson_aalen_aux'}
    rules = load_science_authority()['science']['mice']['formula_completion']['derived']
    base = {'RBC':4,'MCV':100,'HGB':120}
    for name in ('HCT','MCH','MCHC'):
        base[name] = formula_value(base, rules[name])
    assert [base[n] for n in ('HCT','MCH','MCHC')] == [40,30,300]


@pytest.mark.parametrize('iteration,psrf,valid', [(30,1.09,True),(40,1.1,False),(40,1.19,False),
    (50,1.19,True),(50,1.2,False),(50,math.inf,False),(50,math.nan,False),(0,1.0,False)])
def test_psrf_thresholds_are_strict_and_nonfinite_never_pass(iteration, psrf, valid):
    assert mice_terminal_valid({'final_iteration':iteration,'active_target_count':1,
                                'convergence_max_psrf':psrf}) is valid


def test_diagnostic_coordinates_are_complete_unique_and_finite():
    summary = {'final_iteration':30,'active_target_count':1,'convergence_max_psrf':1.01}
    value = {'initial_iteration':30,'continuation_iterations':[],'continuation_increment':10,
             'chain_seeds':[1,2],'final_iterations':[30,30],
             'terminal_diagnostics':[{'.it':i,'vrb':'RBC','parameter':p,'psrf':1.01,'ac':0.1}
                                     for p in ('mean','sd') for i in (28,29,30)]}
    validate_mice_continuation(value,summary,[1,2],['RBC'])
    for mutate in ('duplicate','missing','nonfinite','mixed_iteration'):
        bad = copy.deepcopy(value)
        if mutate == 'duplicate':bad['terminal_diagnostics'][-1] = bad['terminal_diagnostics'][0]
        if mutate == 'missing':bad['terminal_diagnostics'].pop()
        if mutate == 'nonfinite':bad['terminal_diagnostics'][0]['psrf'] = float('nan')
        if mutate == 'mixed_iteration':bad['final_iterations'][1] = 40
        with pytest.raises(ContractError):validate_mice_continuation(bad,summary,[1,2],['RBC'])
