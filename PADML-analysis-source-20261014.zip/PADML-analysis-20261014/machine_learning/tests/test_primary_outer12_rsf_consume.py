"""Synthetic original Q consumption and zero-fit S2 boundary; no native engine."""
import copy
import json
import os
from pathlib import Path

import pytest

from padml import f4, f5, f2_kernel as kernel, f4_compact as compact, runtime
from padml.bundle import ContractError, canonical_json_bytes, sha256_bytes, sha256_file
from test_primary_outer12_rsf_prepared_pipeline import _published, POLICY

OLD = "bc8e099f65716315c84a2561fe8f48598a6fc93c2e1a3539cf2bc6197af57099"


def test_complete_first_fit_source_proof_and_unlisted_member_rejection(monkeypatch):
    path = Path(__file__).parents[1] / "retainedbc8e.zip"
    assert sha256_bytes(canonical_json_bytes(f4._retained_full0_source_members(path, primary_rsf_inputs=True))) == OLD
    original = f4._f45_source_member_sha256
    changed = original()
    changed["padml/f2_kernel.py"] = "0" * 64
    monkeypatch.setattr(f4, "_f45_source_member_sha256", lambda: changed)
    with pytest.raises(ContractError, match="RETAINED_PRIMARY_RSF_INPUT_SOURCE_DRIFT"):
        f4._retained_full0_source_members(path, primary_rsf_inputs=True)


def _case(tmp_path, monkeypatch, *, stage="S1", outer=2):
    if stage in {"S2", "S3A", "S3B2"}:
        from test_primary_outer12_rsf_s2_inputs import _published as publish_s2
        outputs, child, expected = publish_s2(tmp_path, monkeypatch, stage=stage, outer=outer)
    else:
        outputs, child, expected = _published(tmp_path, monkeypatch, outer=2)
    calls, deliveries = {}, []
    def capture(function, units, root, control, phase, input_ref, **kwargs):
        calls.update(units)
        deliveries.append((copy.deepcopy(control["prepared_q_input"]), list(units)))
        raise f5._QBatchBoundary({"UNFITTED": True})
    monkeypatch.setattr(f5, "_execute_q_search_batch", capture)
    for i, output in enumerate(outputs):
        f5._execute_a12_prepared_q_batch(Path(output[0]), tmp_path / f"worker-{i}",
            expected_sha256=sha256_file(Path(output[0])), task_ids=output[1:],
            batch_root=tmp_path / f"unused-{i}", retained_bytes_per_task=1024**2)
    phase, ids = f5._a12_q_stop_phase(stage, refit=True, family="RSF")
    calls = {name: calls[name] for name in ids}
    q = tmp_path / "q"
    raw = (q / "input.json").read_bytes()
    input_ref = {"sha256": sha256_bytes(raw), "size_bytes": len(raw)}
    batches = []
    def unknown(owner):
        return {"status": "UNKNOWN", "owner": owner, "pid": 1, "reason": "UNFITTED diagnostic unavailable"}
    for i, (delivery, selected) in enumerate(deliveries):
        batch = tmp_path / f"numbers-{i}"; batch.mkdir(); (batch / "native").mkdir()
        (batch / "input.json").write_bytes(raw)
        units = []
        for name in selected:
            member = f"native/{name}/UNFITTED.json"
            path = batch / member; path.parent.mkdir(); path.write_bytes(b'{"UNFITTED":true}')
            refs = {"input.json": input_ref, member: {"sha256": sha256_file(path), "size_bytes": path.stat().st_size}}
            units.append({"task_id": name, "native_units": list(calls[name][1]), "members": refs,
                "numerical_members": refs, "retained_bytes": 1, "first_native_audit_count": len(calls[name][1]) - 1})
        delivery["after_release"] = None
        effective = f5._q_batch_resource_policy(POLICY, len(raw), len(selected), 1024**2,
            execution_worker_memory_bytes=2147483648, execution_scratch_reserve_bytes=0, prepared_input=delivery)
        observation = runtime.observe_execution_resources(batch)
        admission = runtime.resource_admission(effective, observation, legal_tasks=len(selected))
        count = sum(row["first_native_audit_count"] for row in units)
        record = {"phase": phase, "input": input_ref, "task_ids": selected, "source_identity": OLD if stage == "S1" else
            ("4339c70013406bdfc10ea7679ac4e8a01054c3ffb01a969c6d427b237614075e" if stage == "S3B2" else
             "b0778469065250c3cc7a40edbc07125cc10778d04b43457f699ce13f55da2621"),
            "operational_identity": runtime.OPERATIONAL_IDENTITY, "resource_policy": POLICY,
            "effective_policy": effective, "resource_observation": observation, "resource_admission": admission,
            "retained_bytes_per_task": 1024**2, "execution_worker_memory_bytes": 2147483648,
            "execution_scratch_reserve_bytes": 0, "prepared_q_input": delivery, "operational_errors": [],
            "pool": {"configured_worker_ceiling": 24, "admitted_worker_ceiling": admission["admitted_worker_ceiling"],
                "runnable_task_count": len(selected), "actual_worker_process_peak": 1,
                "completed_task_count": len(selected), "engine_threads": 1, "status": "COMPLETED"},
            "units": units, "confirmed_first_native_audit_count": count, "new_model_fit_count": count,
            "resource_release": {"units": {name: unknown("Q_UNIT:" + name) for name in selected},
                "worker_results": {str(j): unknown("POOL_TASK_RESULT:" + str(j)) for j in range(len(selected))},
                "prepared_inputs": unknown("Q_PREPARED_INPUTS:" + delivery["archive"]["sha256"])}}
        (batch / "execution.json").write_bytes(canonical_json_bytes(record))
        batches.append((batch, record))
    control = {"prepare_only": True, "task_ids": None, "completed": False, "batches": batches,
        "used_batches": [], "confirmed_model_fits": 0, "confirmed_stop_fits": 0, "references": {},
        "resource_policy": POLICY, "execution_worker_memory_bytes": 2147483648, "execution_scratch_reserve_bytes": 0,
        "retained_primary_rsf_q_source_bundle": Path(__file__).parents[1] / "retainedbc8e.zip",
        "primary_rsf_preparation": tmp_path / "UNFITTED-preparation.zip",
        "primary_rsf_producer": tmp_path / "UNFITTED-producer.zip"}
    if stage in {"S2", "S3A"}:
        control.update(primary_rsf_s2_consumption=True,
            primary_rsf_preparation=tmp_path / "preparation.zip", primary_rsf_producer=tmp_path / "producer.zip",
            retained_primary_rsf_q_source_bundle=Path(os.environ.get(
                "PADML_PRIMARY_RSF_SOURCE_FIXTURES", Path(__file__).parents[1])) / "retainedb077.zip",
            primary_rsf_s2_evidence={name: tmp_path / name for name in (
                "source/primary-s2-producer.zip", "source/primary-q-producer.zip", "primary-s2/report.json",
                *(f"primary-s2/{host}-execution.json" for host in ("H0", "H1", "H4", "H5", "H6", "H7", "H9-2")))})
        if stage == "S3A":
            del control["primary_rsf_s2_consumption"]
            control["primary_rsf_s3a_consumption"] = True
            control["primary_rsf_s3a_evidence"] = {name: tmp_path / name for name in (
                "source/primary-s3a-producer.zip", "primary-s3a/report.json",
                *(f"primary-s3a/{host}-execution.json" for host in ("H0", "H1", "H4", "H5", "H6", "H7", "H9-2")))}
    if stage == "S3B2":
        control.update(primary_rsf_s3b2_consumption=True,
            primary_rsf_preparation=tmp_path / "preparation.zip", primary_rsf_producer=tmp_path / "producer.zip",
            retained_primary_rsf_q_source_bundle=Path(os.environ["PADML_PRIMARY_4339_SOURCE"]))
        for previous in ("s2", "s3a", "s3b1", "s3b2"):
            names = [f"source/primary-{previous}-producer.zip", f"primary-{previous}/report.json",
                *(f"primary-{previous}/{host}-execution.json" for host in ("H0", "H1", "H4", "H5", "H6", "H7", "H9-2"))]
            if previous == "s2": names.append("source/primary-q-producer.zip")
            control[f"primary_rsf_{previous}_evidence"] = {name: tmp_path / name for name in names}
    spec = {**json.loads(raw)["spec"], "native_search_root": str(q / "native"), "native_search_batch": control}
    # Only the synthetic transport members are substituted here. The unchanged
    # real numerical leaf is covered separately by original PRIMARY native tests.
    monkeypatch.setattr(compact, "_full_pipeline_q_numerical_members", lambda root, *, native_units, transported_refs:
        ({name: root / name for name in transported_refs}, transported_refs))
    seen = []
    def numbers(function, jobs, **kwargs):
        assert function is kernel._run_r_prediction_pool_task
        assert len(jobs) == {"S1": 60, "S2": 75, "S3A": 100, "S3B2": 75}[stage]
        for job in jobs:
            assert job[0]["native_search_numbers"] is True and job[0]["native_search_replay"] is True
            assert "native_search_batch" not in job[0]
            seen.extend(row["task_id"] for row in job[2])
        return [[{"UNFITTED": row["task_id"]} for row in job[2]] for job in jobs]
    monkeypatch.setattr(f5, "_bounded_ordered_spawn", numbers)
    return spec, calls, control, seen


@pytest.mark.parametrize("damage", [None, "unbound", "publication-pin", "publication-fold",
    "archive-policy", "execution-policy", "effective", "admission", "current-memory"])
def test_historical_production_policy_is_not_current_reader_policy(tmp_path, monkeypatch, damage):
    """Original 75-atom S2 reader; independent publication bytes anchor history."""
    spec, units, control, seen = _case(tmp_path, monkeypatch, stage="S2", outer=4)
    index = tmp_path / "q/prepared-unit-inputs.json"
    control["primary_q_input_publication"] = ({"path": index, "sha256": sha256_file(index)},)
    # The original published policy remains unchanged. A different current
    # shared reserve must not retroactively invalidate its historical receipt.
    control["resource_policy"] = {**POLICY, "memory_reserve_bytes": POLICY["memory_reserve_bytes"] + 1024**3,
                                  "memory_bytes_per_worker": 4 * 1024**3,
                                  "scratch_reserve_bytes": 2 * 1024**3}
    before = {str(path / "execution.json"): (path / "execution.json").read_bytes()
              for path, _ in control["batches"]}
    current_admissions = []
    original_admit = runtime.resource_admission
    def admit(policy, observed, *, legal_tasks):
        if policy["memory_reserve_bytes"] >= control["resource_policy"]["memory_reserve_bytes"]:
            current_admissions.append(copy.deepcopy(policy))
            if damage == "current-memory":
                observed = {**observed, "available_memory_bytes": 1}
        return original_admit(policy, observed, legal_tasks=legal_tasks)
    monkeypatch.setattr(runtime, "resource_admission", admit)
    record = control["batches"][0][1]
    if damage == "unbound": del control["primary_q_input_publication"]
    elif damage == "publication-pin": control["primary_q_input_publication"][0]["sha256"] = "0" * 64
    elif damage == "publication-fold":
        value = json.loads(index.read_bytes()); value["input"]["sha256"] = "0" * 64
        index.write_bytes(canonical_json_bytes(value))
        control["primary_q_input_publication"][0]["sha256"] = sha256_file(index)
    elif damage == "archive-policy":
        from padml.bundle import read_safe_zip, write_deterministic_zip
        path = Path(record["prepared_q_input"]["archive"]["path"])
        entries = read_safe_zip(path)
        value = json.loads(entries["prepared-q.json"]); value["resource_policy"]["memory_reserve_bytes"] += 1
        entries["prepared-q.json"] = canonical_json_bytes(value)
        altered = tmp_path / "altered.zip"; write_deterministic_zip(altered, entries)
        path.write_bytes(altered.read_bytes())  # synthetic fixture only; external publication pin unchanged
    elif damage == "execution-policy":
        record["resource_policy"] = {**record["resource_policy"], "memory_reserve_bytes": 1}
    elif damage == "effective": record["effective_policy"]["memory_reserve_bytes"] += 1
    elif damage == "admission": record["resource_admission"]["memory_usable_bytes"] += 1
    for path, row in control["batches"]:
        (path / "execution.json").write_bytes(canonical_json_bytes(row))
    call = lambda: f5._q_search_task_batch(spec, kernel._run_r_prediction_pool_task,
                                         [row[0] for row in units.values()])
    if damage:
        with pytest.raises(ContractError): call()
        assert not seen and not control["used_batches"]
    else:
        assert len(call()) == 75 and len(seen) == len(set(seen)) == 200
        assert current_admissions and all(p["memory_bytes_per_worker"] == 2147483648
                                         and p["scratch_reserve_bytes"] == 0 for p in current_admissions)
        assert before == {str(path / "execution.json"): (path / "execution.json").read_bytes()
                          for path, _ in control["batches"]}
        # The witness survives original canonical transport. It is not a
        # mutable alias to the caller's live policy or to a worker assertion.
        proofs = json.loads(canonical_json_bytes(control["historical_q_publications"]))
        reference = control["batches"][0][1]["input"]
        records = [row for _, row in control["batches"]]
        expected = {sha256_bytes(canonical_json_bytes(row)): POLICY for row in records}
        assert f5._primary_q_publication_evidence(proofs, reference, batches=records) == expected
        next_phase = f5._a12_q_stop_phase("S3A", refit=True, family="RSF")[0]
        assert f5._primary_q_publication_evidence(proofs, reference, next_phase=next_phase) == expected
        for kind in ("pin", "input", "policy", "missing-atom", "wrong-execution"):
            changed = copy.deepcopy(proofs)
            phase, = changed
            witness = changed[phase]
            if kind == "pin": witness["publication"]["sha256"] = "0" * 64
            elif kind == "input": witness["publication"]["value"]["input"]["sha256"] = "0" * 64
            elif kind == "policy":
                next(iter(witness["prepared"].values()))["metadata"]["value"]["resource_policy"]["memory_reserve_bytes"] += 1
            elif kind == "missing-atom": witness["publication"]["value"]["outputs"][0]["task_ids"].pop()
            else:
                digest = next(iter(witness["prepared"]))
                witness["prepared"]["0" * 64] = witness["prepared"].pop(digest)
            with pytest.raises(ContractError, match="PUBLISHED_POLICY_INVALID"):
                f5._primary_q_publication_evidence(changed, reference, batches=records)


@pytest.mark.parametrize("outer", [1, 3])
@pytest.mark.parametrize("damage", [None, "missing-source", "unused-source", "wrong-executor", "half-atom"])
def test_s3a_original_consumer_preserves_each_executor(tmp_path, monkeypatch, outer, damage):
    """Real source proof -> original 100-atom reader; input/numerical leaves UNFITTED."""
    paths = [os.environ.get(name) for name in ("PADML_PRIMARY_4A221_SOURCE", "PADML_PRIMARY_4339_SOURCE")]
    if not all(paths):
        pytest.skip("requires both retained executor source archives")
    paths = [Path(value).resolve(strict=True) for value in paths]
    members = {path: {row["path"]: row["sha256"] for row in f4.load_f45_source_bundle(path)["members"]}
               for path in paths}
    identities = [sha256_bytes(canonical_json_bytes(members[path])) for path in paths]
    assert identities == ["4a221cd0f8519dc9c6685fe0b51b0a6fedfe4d31eaf8ffd6e5bdf616e1d294d0",
                          "4339c70013406bdfc10ea7679ac4e8a01054c3ffb01a969c6d427b237614075e"]
    spec, units, control, seen = _case(tmp_path, monkeypatch, stage="S3A", outer=outer)
    control["retained_primary_rsf_q_source_bundle"] = tuple(paths) if outer == 1 else paths[1]
    for index, (path, record) in enumerate(control["batches"]):
        record["source_identity"] = identities[0 if outer == 1 and index != 5 else 1]
    if damage == "missing-source":
        control["retained_primary_rsf_q_source_bundle"] = paths[0]
    elif damage == "unused-source":
        control["retained_primary_rsf_q_source_bundle"] = tuple(paths)
        for _, record in control["batches"]:
            record["source_identity"] = identities[1]
    elif damage == "wrong-executor":
        control["batches"][5][1]["source_identity"] = "0" * 64
    elif damage == "half-atom":
        control["batches"][0][1]["units"][0]["native_units"].pop()
    original_identities = [record["source_identity"] for _, record in control["batches"]]
    for path, record in control["batches"]:
        (path / "execution.json").write_bytes(canonical_json_bytes(record))
    phase = f5._a12_q_stop_phase("S3A", refit=True, family="RSF")[0]
    def consume():
        return f5._consume_q_search_batches(spec, kernel._run_r_prediction_pool_task,
            units, control["batches"], phase, control["batches"][0][1]["input"])
    if damage:
        with pytest.raises(ContractError):
            consume()
        assert not seen
    else:
        result = consume()
        assert len(result) == 100 and all(len(rows) == 3 for rows in result)
        assert len(seen) == len(set(seen)) == control["confirmed_model_fits"] == 300
        assert control["confirmed_stop_fits"] == 0 and len(control["used_batches"]) == 7
        assert [record["source_identity"] for _, record in control["batches"]] == original_identities


@pytest.mark.parametrize("damage", [None, "missing-atom", "wrong-executor", "half-atom"])
def test_original_s3b2_consumer_reads_all_75_historical_atoms(tmp_path, monkeypatch, damage):
    spec, units, control, seen = _case(tmp_path, monkeypatch, stage="S3B2")
    phase = f5._a12_q_stop_phase("S3B2", refit=True, family="RSF")[0]
    input_ref = control["batches"][0][1]["input"]
    if damage == "missing-atom": control["batches"][0][1]["task_ids"].pop()
    elif damage == "wrong-executor": control["batches"][0][1]["source_identity"] = "0" * 64
    elif damage == "half-atom": control["batches"][0][1]["units"][0]["native_units"].pop()
    for path, record in control["batches"]:
        (path / "execution.json").write_bytes(canonical_json_bytes(record))
    if damage:
        with pytest.raises(ContractError):
            f5._consume_q_search_batches(spec, kernel._run_r_prediction_pool_task,
                                        units, control["batches"], phase, input_ref)
        assert not seen
    else:
        result = f5._consume_q_search_batches(spec, kernel._run_r_prediction_pool_task,
                                             units, control["batches"], phase, input_ref)
        assert len(result) == 75 and all(len(rows) == 4 for rows in result)
        assert len(seen) == len(set(seen)) == 300
        assert control["confirmed_model_fits"] == 300 and control["confirmed_stop_fits"] == 0
        assert len(control["used_batches"]) == 7


@pytest.mark.parametrize("damage", [None, "missing", "duplicate", "source", "input", "budget", "scratch-bool", "unprepared", "native-count", "candidate-order"])
def test_original_s1_consumer_complete_or_rejects_before_numbers(tmp_path, monkeypatch, damage):
    spec, units, control, seen = _case(tmp_path, monkeypatch)
    record = control["batches"][0][1]
    if damage == "missing": control["batches"].pop()
    elif damage == "duplicate": control["batches"][-1] = control["batches"][0]
    elif damage == "source": record["source_identity"] = "f" * 64
    elif damage == "input": record["input"]["sha256"] = "e" * 64
    elif damage == "budget": record["execution_worker_memory_bytes"] = True
    elif damage == "scratch-bool": record["execution_scratch_reserve_bytes"] = False
    elif damage == "unprepared": del record["prepared_q_input"]
    elif damage == "native-count": record["confirmed_first_native_audit_count"] -= 1
    elif damage == "candidate-order": spec["candidate_trials"]["S2"].reverse()
    for path, row in control["batches"]:
        (path / "execution.json").write_bytes(canonical_json_bytes(row))
    if damage:
        with pytest.raises(ContractError):
            f5._q_search_task_batch(spec, kernel._run_r_prediction_pool_task, [x[0] for x in units.values()])
        assert not seen
    else:
        result = f5._q_search_task_batch(spec, kernel._run_r_prediction_pool_task, [x[0] for x in units.values()])
        assert len(result) == 60 and len(seen) == len(set(seen)) == 120
        assert control["confirmed_model_fits"] == 120 and control["confirmed_stop_fits"] == 0
        assert len(control["used_batches"]) == 7


@pytest.mark.parametrize("damage", [None, "fit-mode", "not-consumed", "seed", "geometry", "publish"])
def test_s2_original_75_atoms_stop_before_first_fit(tmp_path, monkeypatch, damage):
    spec, units, control, seen = _case(tmp_path, monkeypatch)
    control.update(confirmed_model_fits=120, used_batches=[sha256_bytes(canonical_json_bytes(row)) for _, row in control["batches"]])
    # Original 56-profile coalescing is three candidates at one partition/MI.
    base = next(iter(units.values()))[0]
    calls = []
    for first in (1, 4, 7):
        for part in range(1, 6):
            for imp in range(1, 6):
                call = list(base)
                call[2] = [{"task_id": f"S2_T{trial:03d}_P{part:02d}_M{imp:02d}",
                    "family": "RSF", "partition_id": f"INNER_F2_R2_K{part}", "imputation": imp,
                    "seed": 322000 + 100 * imp + part} for trial in range(first, min(first + 3, 9))]
                calls.append(call)
    if damage == "fit-mode": control["prepare_only"] = False
    elif damage == "not-consumed": control["confirmed_model_fits"] = 0
    elif damage == "seed": calls[0][2][0]["seed"] += 1
    elif damage == "geometry": calls[0][2].pop()
    elif damage == "publish": control["q_unit_outputs"] = [["UNFITTED"]]
    monkeypatch.setattr(f5, "_execute_q_search_batch", lambda *a, **k: pytest.fail("S2 FIRST FIT FORBIDDEN"))
    if damage:
        with pytest.raises(ContractError): f5._q_search_task_batch(spec, kernel._run_r_prediction_pool_task, calls)
    else:
        with pytest.raises(f5._QBatchBoundary) as stopped:
            f5._q_search_task_batch(spec, kernel._run_r_prediction_pool_task, calls)
        assert stopped.value.result["model_coordinate_count"] == 200
        assert stopped.value.result["new_model_fits"] == 0 and stopped.value.result["worker_inputs_ready"] is False
        assert len(stopped.value.result["next_atomic_units"]) == 75
    assert not seen
