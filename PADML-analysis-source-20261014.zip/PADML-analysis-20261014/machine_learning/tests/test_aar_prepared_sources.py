"""Prepared numerical transport; UNFITTED boundaries are explicit, never science evidence."""
import copy

import pytest

from padml import f4_compact, f5, f5_sensitivity as sensitivity, nested_loco as nested, runtime
from padml.bundle import ContractError, canonical_json_bytes, extract_safe_zip, read_safe_zip, sha256_bytes, sha256_file, strict_json_bytes, write_deterministic_zip
from test_nested_aar_aggregate import _unfitted_six_aar, _unfitted_metric_engines
from test_nested_loco import _six_outer_fixture


_ORIGINAL_PREPARED_LEAF = sensitivity._read_a12_prepared_numerical_job


def _unfitted_prepared_aar_jobs(root, row):
    """Owner-boundary fixture only; separate existing tests read rich audit numbers."""
    root.mkdir(parents=True)
    jobs = []
    outer = row["outer_fold"]
    for branch in nested.AAR_ESTIMANDS:
        for imp in range(1, 21):
            name = f"O{outer}_{branch}_M{imp:02d}"
            task = {"UNFITTED": True, "a12_coordinates": {"outer_fold": outer, "branch": branch, "imputation": imp}}
            entries = {"task.json": canonical_json_bytes(task), "recipe.json": b'{"UNFITTED":true}',
                "fit-covariates.csv": b"UNFITTED_TRAINING", "fit-response.csv": b"UNFITTED_RESPONSE",
                "prediction-covariates.csv": b"UNFITTED_APPLICATION"}
            prediction = {key: row["predictions"][key] for key in ("patient_ids", "centers", "horizons")}
            prediction.update(family=row["family"], a12_coordinates=task["a12_coordinates"],
                survival=copy.deepcopy(row["predictions"]["survival"][branch]))
            native = {"sha256": sha256_bytes(("UNFITTED_NATIVE:" + name).encode()), "size_bytes": 100}
            numbers = root / f"{name}.numbers.json"
            numbers.write_bytes(canonical_json_bytes({"UNFITTED": True, "native_archive": native, "prediction": prediction,
                "input_members": {key: sha256_bytes(data) for key, data in entries.items()}}))
            row["members"][f"fits/{numbers.name}"] = {"sha256": sha256_file(numbers), "size_bytes": numbers.stat().st_size}
            row["native_members"][f"fits/{name}.zip"] = native
            jobs.append({"name": name, "entries": entries, "numbers_path": numbers,
                "native_archive": native, "retained_bytes_per_component": 2 * 1024**2})
    row["predictions"] = sensitivity._a12_outer_predictions(row, jobs,
        [strict_json_bytes(job["numbers_path"].read_bytes())["prediction"] for job in jobs])
    row.update(nested._sealed({key: value for key, value in row.items() if key != "identity_sha256"}))
    return jobs


def _unfitted_prepared_primary(root, context):
    selected, _ = _six_outer_fixture()
    assert nested.assemble_selected_ooc(selected, population_registry=context["population_registry"]) == context["primary"]
    for outer, prediction in enumerate(selected, 1):
        original = root / f"primary-replay/native-replay/outer-{outer}/archive"
        original.mkdir(parents=True)
        templates = []
        family = context["family_by_outer"][str(outer)]
        for imp in range(1, 21):
            name = f"post-lock/{family}/M{imp:02d}.zip"
            path = original / "request" / name
            path.parent.mkdir(parents=True, exist_ok=True)
            write_deterministic_zip(path, {"task.json": canonical_json_bytes({"UNFITTED": True, "imputation": imp})})
            templates.append({"family": family, "imputation": imp, "path": name,
                "sha256": sha256_file(path), "size_bytes": path.stat().st_size})
        request = nested._sealed({"UNFITTED": True, "training_context": {"outer_fold": outer},
            "post_lock_templates": templates, "expanded_bytes_per_component": 1024**2, "shared_storage_bytes": 32 * 1024**2})
        lock = nested._sealed({"UNFITTED": True, "outer_fold": outer})
        execution = nested._sealed({"UNFITTED": True, "outer_fold": outer, "input_identity_sha256": request["identity_sha256"],
            "development_lock": lock, "selected_prediction": prediction, "component_receipts": [], "native_members": {}})
        for name, value in (("request/o-fit-input.json", request), ("development-lock.json", lock), ("o-fit-execution.json", execution)):
            (original / name).write_bytes(canonical_json_bytes(value))
        write_deterministic_zip(original / "final-numbers.zip", {"final.json": b'{"UNFITTED":true}', "heldout-mean.f64": b"UNFITTED"})


def _unfitted_prepared_numeric(job):
    """Actual thin worker and byte checks; two unchanged scientific leaves stubbed."""
    def primary(source, **kwargs):
        assert source.name == "final-numbers.zip" and kwargs["request"]["UNFITTED"]
        assert kwargs.get("retained_primary_source_bundle") == job.get("retained_primary_source_bundle")
        value = strict_json_bytes((source.parent / "o-fit-execution.json").read_bytes())
        return {name: value[name] for name in ("development_lock", "selected_prediction", "component_receipts")}
    def aar(item):
        assert "numbers_path" in item and "archive" not in item
        numbers = strict_json_bytes(item["numbers_path"].read_bytes())
        assert numbers["UNFITTED"] and numbers["native_archive"] == item["native_archive"]
        assert numbers["input_members"] == {name: sha256_bytes(raw) for name, raw in item["entries"].items()}
        return numbers["prediction"]
    def forbidden(*args, **kwargs):
        raise AssertionError("NO_ANCESTOR_OR_MODEL_OR_SECOND_POOL")
    with pytest.MonkeyPatch.context() as scoped:
        scoped.setattr(f4_compact, "read_o_fit_final_numbers", primary)
        scoped.setattr(sensitivity, "_replay_ablation_component", aar)
        scoped.setattr(sensitivity, "_a12_context", forbidden)
        scoped.setattr(sensitivity, "_load_a12_outer_archive", forbidden)
        scoped.setattr(sensitivity, "_bounded_ordered_spawn", forbidden)
        scoped.setattr(f5, "_execute_final_refit_engine", forbidden)
        scoped.setattr(f5, "_validate_retained_model_objects", forbidden)
        return _ORIGINAL_PREPARED_LEAF(job)


@pytest.fixture
def prepared_points(tmp_path, monkeypatch):
    live_observer = runtime.observe_execution_resources
    context, outers = _unfitted_six_aar()
    calls, policy = _unfitted_metric_engines(monkeypatch)
    root = tmp_path / "original-prepare"
    root.mkdir()
    _unfitted_prepared_primary(root, context)
    captured = {"members": {}, "jobs": [], "records": {}}
    for outer, row in enumerate(outers, 1):
        jobs = _unfitted_prepared_aar_jobs(root / f"UNFITTED-owner-{outer}", row)
        record = {"outer_fold": outer, "identity_sha256": row["identity_sha256"], "UNFITTED_LEDGER": True}
        sensitivity._capture_a12_prepared_outer(row, jobs, record, root=root, captured=captured, resource_policy=policy)
    material = sensitivity._a12_prepare_sources(context, root, captured, policy)
    source, points = tmp_path / "bootstrap.zip", tmp_path / "points.zip"
    record = sensitivity.evaluate_a12_incremental_value(sensitivity._a12_handoff_from_outers(context, outers),
        context["evaluation_response_csv"], formal=True, evidence_root=root / "evaluation", resource_policy=policy,
        retained_bytes_per_replicate=2 * 1024**2, retained_primary_point=context["primary_point"],
        primary_point_native=context["primary_point_native"], bootstrap_input_target=source, point_archive_target=points,
        prepared_members=material)
    return context, outers, calls, policy, source, points, record, live_observer


@pytest.mark.parametrize("retained", [False, True])
def test_prepared_point_packet_runs_one_366_leaf_pool_and_original_m20(prepared_points, tmp_path, monkeypatch, retained):
    context, outers, calls, policy, source, points, record, live_observer = prepared_points
    # Resolve the actual H9 C-8 and live resources for the real spawn phase.
    policy = {**policy, "transfer_archive_worker_ceiling": 6}
    proof = tmp_path / "UNFITTED-primary-producer-proof.zip" if retained else None
    def flat(worker, jobs, *, selected_slots, execution_report):
        assert worker is sensitivity._read_a12_prepared_numerical_job and len(jobs) == 366
        assert sum(job["kind"] == "primary" for job in jobs) == 6 and selected_slots <= 6
        assert all(job.get("retained_primary_source_bundle") == (proof if job["kind"] == "primary" else None)
                   for job in jobs)
        return runtime._bounded_ordered_spawn(_unfitted_prepared_numeric, jobs, selected_slots=selected_slots,
            execution_report=execution_report, schedule_order=list(reversed(range(366))))
    monkeypatch.setattr(sensitivity, "_bounded_ordered_spawn", flat)
    monkeypatch.setattr(runtime, "observe_execution_resources", live_observer)
    opened = sensitivity._read_a12_prepared_sources(points, tmp_path / "numeric-read",
        prepared_input_record=record, resource_policy=policy,
        **({"retained_primary_source_bundle": proof} if retained else {}))
    assert opened["context"]["primary"] == context["primary"] and opened["outers"] == outers
    assert opened["context"]["evaluation_response_csv"] == context["evaluation_response_csv"]
    assert opened["context"]["primary_point_native"].is_file()
    pool = opened["execution"]["pool"]
    assert pool["completed_task_count"] == pool["runnable_task_count"] == 366
    assert pool["actual_worker_process_peak"] == 6 and pool["engine_threads"] == 1
    assert opened["execution"]["resource_reservation"]["future_retention_reserved_bytes"] == 64 * 1024
    assert set(read_safe_zip(source)) == {"bootstrap-input.json", "predictions.json", "response.csv", "plan.json", "rng.zip"}
    assert not any("model.bin" in name or "selector/" in name or "search/" in name for name in read_safe_zip(points))
    assert calls == {"UNFITTED_RNG": 1, "UNFITTED_METRICS": 1, "metric_replays": 2}
    assert pool["configured_worker_ceiling"] == live_observer(tmp_path)["effective_cpus"] - 8


@pytest.mark.parametrize("damage", ["missing-record", "changed-bytes", "wrong-source", "point-size", "missing-mi", "duplicate-mi", "wrong-outer", "wrong-lock"])
def test_prepared_point_rejects_independent_binding_and_coordinate_drift(prepared_points, tmp_path, monkeypatch, damage):
    _, _, calls, policy, _, points, record, _ = prepared_points
    before = dict(calls)
    record = copy.deepcopy(record)
    if damage == "missing-record":
        record = None
    elif damage == "wrong-source":
        record["f45_source_sha256"] = "f" * 64
    elif damage == "point-size":
        record["point_archive"]["size_bytes"] += 1
    else:
        entries = read_safe_zip(points)
        index = strict_json_bytes(entries["preparation-sources.json"])
        if damage == "missing-mi":
            index["aar_jobs"].pop()
        elif damage == "duplicate-mi":
            index["aar_jobs"][-1] = index["aar_jobs"][0]
        elif damage == "wrong-outer":
            index["aar_jobs"][0]["outer_fold"] = 2
        elif damage == "wrong-lock":
            name = "prepared/aar/outer-1/a12-outer.json"
            value = strict_json_bytes(entries[name])
            value["source"]["primary_source"]["primary_development_lock"]["identity_sha256"] = "f" * 64
            value = nested._sealed({key: item for key, item in value.items() if key != "identity_sha256"})
            entries[name] = canonical_json_bytes(value)
            index["members"][name] = {"sha256": sha256_bytes(entries[name]), "size_bytes": len(entries[name])}
            index["source_archives"][0]["identity_sha256"] = value["identity_sha256"]
        else:
            name = index["aar_jobs"][0]["input_member"]
            entries[name] += b"UNFITTED_TAMPER"
            index["members"][name] = {"sha256": sha256_bytes(entries[name]), "size_bytes": len(entries[name])}
        entries["preparation-sources.json"] = canonical_json_bytes(index)
        changed = tmp_path / "changed.zip"
        write_deterministic_zip(changed, entries, stored_members={name for name in entries if name.endswith(".zip")})
        points = changed
        if damage != "changed-bytes":
            # Explicit invalid-producer fixture to exercise inner coordinate
            # readers independently of the already-tested outer byte gate.
            record["point_archive"].update(sha256=sha256_file(points), size_bytes=points.stat().st_size)
            record["preparation_sources_sha256"] = sha256_bytes(entries["preparation-sources.json"])
    monkeypatch.setattr(sensitivity, "_read_a12_prepared_numerical_job", _unfitted_prepared_numeric)
    with pytest.raises(ContractError):
        sensitivity._read_a12_prepared_sources(points, tmp_path / "rejected", prepared_input_record=record, resource_policy=policy)
    assert calls == before


@pytest.mark.parametrize("phase", ["directory", "index", "expansion", "pool", "report-space"])
def test_prepared_point_admits_resource_boundary_before_consumer(prepared_points, tmp_path, monkeypatch, phase):
    _, _, _, policy, _, points, record, _ = prepared_points
    seen = []
    original = runtime.observe_execution_resources
    def observe(root):
        value = original(root)
        if phase == "directory" or phase == "index" and not seen:
            value["available_memory_bytes"] = 1 if phase == "directory" else 4 * 1024**2
        if phase == "expansion":
            value["scratch_available_bytes"] = 1
        if phase == "pool" and (root / "prepared/response.csv").exists():
            value["available_memory_bytes"] = 1
        if phase == "report-space" and (root / "prepared/response.csv").exists():
            value["scratch_available_bytes"] = 64 * 1024
        return value
    original_read = sensitivity.zipfile.ZipFile.read
    def read(archive, member, *args, **kwargs):
        seen.append(getattr(member, "filename", member))
        return original_read(archive, member, *args, **kwargs)
    monkeypatch.setattr(runtime, "observe_execution_resources", observe)
    monkeypatch.setattr(sensitivity.zipfile.ZipFile, "read", read)
    monkeypatch.setattr(sensitivity, "_bounded_ordered_spawn", lambda *a, **k: pytest.fail("NO_UNADMITTED_POOL"))
    with pytest.raises(ContractError):
        sensitivity._read_a12_prepared_sources(points, tmp_path / "limited", prepared_input_record=record, resource_policy=policy)
    if phase in {"directory", "index"}:
        assert seen == []


def test_prepared_point_reuse_admits_before_first_point_read(prepared_points, tmp_path, monkeypatch):
    context, outers, _, policy, source, points, record, _ = prepared_points
    shared = sensitivity._load_a12_bootstrap_inputs(source, tmp_path / "shared", policy, prepared_input_record=record)
    point_root = tmp_path / "points-extracted"
    members = extract_safe_zip(points, point_root, expected_members=set(read_safe_zip(points)),
        max_member_bytes=32 * 1024**2, max_total_bytes=128 * 1024**2)
    prepared = {"root": point_root, "members": members, "sha256": sha256_file(points)}
    paths = {"bootstrap-input.zip": source, "point-sources.zip": points}
    for index in range(1, 7):
        path = tmp_path / f"unused-shard-{index}.zip"
        path.write_bytes(b"UNFITTED_NOT_READ")
        paths[f"shard-{index}.zip"] = path
    root = tmp_path / "gather"
    root.mkdir()
    handoff = sensitivity._validate_a12_handoff(sensitivity._a12_handoff_from_outers(context, outers))
    monkeypatch.setattr(sensitivity, "_load_a12_bootstrap_inputs", lambda *a, **k: shared)
    monkeypatch.setattr(runtime, "observe_execution_resources", lambda root: {"effective_cpus": 32,
        "available_memory_bytes": 1, "scratch_available_bytes": 10**12, "scratch_root": str(root)})
    monkeypatch.setattr(sensitivity, "_replay_a12_point", lambda *a, **k: pytest.fail("NO_UNADMITTED_POINT_READ"))
    with pytest.raises(ContractError, match="RESOURCE_ADMISSION_ZERO"):
        sensitivity._collect_a12_bootstrap_shards(root, handoff, context["evaluation_response_csv"], resource_policy=policy,
            retained_primary_point=context["primary_point"], primary_point_native=context["primary_point_native"],
            original_paths=paths, prepared_input_record=record, prepared_points=prepared)


def test_prepared_capture_failure_publishes_neither_points_nor_bootstrap(tmp_path, monkeypatch):
    context, outers = _unfitted_six_aar()
    calls, policy = _unfitted_metric_engines(monkeypatch)
    primary, target = tmp_path / "primary.zip", tmp_path / "bootstrap.zip"
    primary.write_bytes(b"UNFITTED_PRIMARY_OWNER_BOUNDARY")
    sources = []
    for outer in range(1, 7):
        source = tmp_path / f"outer-{outer}.zip"
        write_deterministic_zip(source, {"a12-outer.json": canonical_json_bytes({"outer_fold": outer})})
        sources.append(source)
    monkeypatch.setattr(sensitivity, "_a12_context", lambda *args, **kwargs: context)
    def outer_reader(path, *, input_bundle, _prepared_consumer):
        _prepared_consumer(outers[0], [], {"UNFITTED_VERIFIED_LEDGER": True})
        pytest.fail("Capture failure must propagate")
    monkeypatch.setattr(sensitivity, "_load_a12_outer_archive", outer_reader)
    def failure(*args, **kwargs):
        raise ContractError("UNFITTED_CAPTURE_FAILURE_AFTER_ORIGINAL_OWNER")
    monkeypatch.setattr(sensitivity, "_capture_a12_prepared_outer", failure)
    with pytest.raises(ContractError, match="UNFITTED_CAPTURE_FAILURE_AFTER_ORIGINAL_OWNER"):
        sensitivity.execute_a12_bundle(primary, target, sources=sources, f2_run_root=tmp_path,
            primary_input_bundles=dict(enumerate(sources, 1)), input_bundles=dict(enumerate(sources, 1)),
            primary_compiled_input_records={outer: {} for outer in range(1, 7)}, resource_policy=policy,
            retained_bytes_per_replicate=2 * 1024**2, bootstrap_inputs_only=True)
    assert not target.exists() and not (tmp_path / "bootstrap.points.zip").exists()
    assert (tmp_path / "bootstrap.zip.work").is_dir() and all(path.is_file() for path in sources)
    assert calls == {"UNFITTED_RNG": 0, "UNFITTED_METRICS": 0, "metric_replays": 0}
