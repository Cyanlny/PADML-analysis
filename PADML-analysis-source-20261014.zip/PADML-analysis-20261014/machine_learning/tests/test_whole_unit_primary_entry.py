"""Whole-unit transport routing; every numerical leaf is explicitly unfitted."""
import pytest

from padml import f4, f5, nested_loco, worker
from padml.bundle import canonical_json_bytes


def test_primary_entry_consumes_materialized_transport(tmp_path, monkeypatch):
    families = ("RSF", "GBM_COX", "XGBOOST_COX", "COXTIME_SET_A")
    state = {
        "projection": {"training_context": {"outer_fold": 1}},
        "registered": {"UNFITTED": True},
        "source_registered_identity": "a" * 64,
        "frozen": {
            "models": {(1, family): {"selector_evidence": {
                "recipe_set": {"recipe_set_sha256": "b" * 64},
                "outer_recipe_sha256": "c" * 64}} for family in families},
            "accepted_result_sha256": {
                nested_loco._accepted_result_unit_id(1, family): "d" * 64 for family in families},
        },
    }
    root, context = tmp_path / "unit", tmp_path / "context"
    root.mkdir(); context.mkdir()
    run = {"resource_policy": {}, "budgets": {
        name: 1024 for name in ("retained_bytes_per_component", "expanded_bytes_per_component",
                               "shared_storage_bytes", "retained_bytes_per_q_task")},
        "f1_runtime_root": str(tmp_path), "f2_run_root": str(tmp_path), "science_decision": {}}
    calls = []
    monkeypatch.setattr(worker, "_f45_compile_archive", lambda *args: {})
    monkeypatch.setattr(f4, "_materialize_o_fit_input_bundle",
                        lambda *args, **kwargs: {"materialized_pre_search": state})

    def search(projected, target, policy, **options):
        assert projected["registered"] is state["registered"]
        assert options["source_registered_identity"] == state["source_registered_identity"]
        assert options["selection_horizon_months"] == 6
        calls.append(options["family"])
        return {"UNFITTED": True}

    monkeypatch.setattr(f5, "_prepare_primary_outer_rsf_search", search)
    monkeypatch.setattr(f4, "execute_o_fit_bundle", lambda **kwargs: None)
    monkeypatch.setattr(f4, "load_o_fit_execution_archive", lambda *args, **kwargs: {"outer_fold": 1})
    assert worker._f45_primary(run, {"outer_fold": 1, "horizon": 6}, root, context) == [
        root / "input.zip", root / "input.compile.json", root / "result.zip"]
    assert calls == list(families)


def test_full0_resume_preserves_original_preparation(tmp_path, monkeypatch):
    context, root = tmp_path / "context", tmp_path / "unit"
    common = context / "common"
    common.mkdir(parents=True); root.mkdir()
    from padml.nested_loco import science_decision_template
    sources = {"science_decision": science_decision_template(24), "resource_policy": {}, "plan": {},
               "raw_input_binding": {"f45_source_sha256": "e" * 64}}
    shared = common / "full-development.json"
    original = canonical_json_bytes(sources)
    shared.write_bytes(original)
    monkeypatch.setattr(worker, "_f45_raw_inputs", lambda *a: pytest.fail("Do not recompile retained preparation"))
    monkeypatch.setattr(f5, "compile_full_data_search_mice_tasks", lambda plan: [])
    monkeypatch.setattr(f5, "compile_final_full_data_mice_task", lambda plan: {"view_id": "UNFITTED"})

    class ReachedOriginalMiceReader(Exception): pass

    def consume(source, target, **options):
        assert source == shared and source.read_bytes() == original
        assert options == {"view_ids": ["UNFITTED"], "selection_horizon_months": 24}
        raise ReachedOriginalMiceReader

    monkeypatch.setattr(f5, "execute_full_data_mice_batch", consume)
    with pytest.raises(ReachedOriginalMiceReader):
        worker._f45_full0({"resource_policy": {}, "budgets": {}, "science_decision": {}},
                         {"horizon": 6}, root, context)
    assert shared.read_bytes() == original
