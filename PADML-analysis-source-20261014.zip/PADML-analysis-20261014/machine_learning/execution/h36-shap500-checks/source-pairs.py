import ast, hashlib, pprint, subprocess
from pathlib import Path
repo=Path('/Users/liuningyuan/Desktop/Result/Machine Learning/PADML_F45_REBUILD')
p=repo/'padml/run.py'
text=p.read_text()
begin='    # Begin exact H36 population and SHAP500 revision.\n'
end='    # End exact H36 population and SHAP500 revision.\n'
if begin in text:
 a=text.index(begin); b=text.index(end,a)+len(end); text=text[:a]+text[b:]
raw_begin='    # Begin exact H36 non-Python sources.\n'
raw_end='    # End exact H36 non-Python sources.\n'
if raw_begin in text:
 a=text.index(raw_begin); b=text.index(raw_end,a)+len(raw_end);text=text[:a]+text[b:]
p.write_text(text)
def sha(x):return hashlib.sha256(x).hexdigest()
# Keep the old operational comparison, with an exact audited full-function
# exception for the new zero-fit STOP consumer branch.
f5=ast.parse((repo/'padml/f5.py').read_bytes())
atom=next(n for n in f5.body if isinstance(n,ast.FunctionDef) and n.name=='_current_q_atom_result')
atom_sha=sha(ast.dump(atom,include_attributes=False).encode())
line='            retained_h36_stop = '
lines=text.splitlines(keepends=True)
lines=[s for s in lines if not s.startswith(line)]
text=''.join(lines)
needle='            retained = ProducerMetadataOnly().visit(retained)\n'
assert text.count(needle)==1
text=text.replace(needle,f'            retained_h36_stop = sha256_bytes(ast.dump(retained, include_attributes=False).encode()) == {atom_sha!r} and sha256_bytes(ast.dump(original, include_attributes=False).encode()) == \"95cafc8b2370ea0532109a8e5491cd48ea788198524ceb950b5488f25571ebb5\"\n'+needle)
text=text.replace('_require(ast.dump(original, include_attributes=False) == ast.dump(retained, include_attributes=False),\n                     "F45_RESOURCE_REVISION_ATOM_NUMERICS_DRIFT")','_require(retained_h36_stop or ast.dump(original, include_attributes=False) == ast.dump(retained, include_attributes=False),\n                     "F45_RESOURCE_REVISION_ATOM_NUMERICS_DRIFT")')
p.write_text(text)
changed=subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=repo,text=True).splitlines()
rawfiles=[n for n in changed if n in {'science-decision.json','AGENTS.md','NESTED_LOCO_PROTOCOL.md'} or n.endswith('.R')]
rawpins={n:tuple(dict.fromkeys((sha(subprocess.check_output(['git','show','HEAD:'+n],cwd=repo)),sha((repo/n).read_bytes())))) for n in rawfiles}
rawblock=raw_begin+'    revised_raw = '+pprint.pformat(rawpins,width=108,sort_dicts=True).replace('\n','\n    ')+'\n    if name in revised_raw and sha256_bytes(raw) in revised_raw[name]:\n        return ast.parse(repr(b""))\n'+raw_end
assert text.count('    import ast\n    if name in {"AGENTS.md", "NESTED_LOCO_PROTOCOL.md"}:')==1
text=text.replace('    import ast\n    if name in {"AGENTS.md", "NESTED_LOCO_PROTOCOL.md"}:','    import ast\n'+rawblock+'    if name in {"AGENTS.md", "NESTED_LOCO_PROTOCOL.md"}:',1)
p.write_text(text)
qualified={}
for name in changed:
 if not name.startswith('padml/') or not name.endswith('.py'):continue
 old=ast.parse(subprocess.check_output(['git','show','HEAD:'+name],cwd=repo));new=ast.parse((repo/name).read_bytes())
 def defs(t):return {n.name:sha(ast.dump(n,include_attributes=False).encode()) for n in t.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
 a,b=defs(old),defs(new)
 changes={k:(a.get(k),b.get(k)) for k in a.keys()|b.keys() if a.get(k)!=b.get(k) and k!='_f45_aar_binding_ast'}
 if changes:qualified[name]=changes
block=begin+'    population_qualified = '+pprint.pformat(qualified,width=120,sort_dicts=True).replace('\n','\n    ')+'\n    for module, definitions in population_qualified.items():\n        target = qualified.setdefault(module, {})\n        for function, revisions in definitions.items():\n            target[function] = tuple(dict.fromkeys((*target.get(function, ()), *revisions)))\n'+end
assert text.count('    def unchanged_or_qualified(node):')==1
text=text.replace('    def unchanged_or_qualified(node):',block+'    def unchanged_or_qualified(node):',1)
p.write_text(text)
print({'raw':rawpins,'function_counts':{k:len(v) for k,v in qualified.items()},'atom_sha256':atom_sha})
