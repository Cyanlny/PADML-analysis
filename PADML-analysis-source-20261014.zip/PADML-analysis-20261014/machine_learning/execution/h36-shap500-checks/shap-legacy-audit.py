import copy,json,sys,tempfile,hashlib
from pathlib import Path
from unittest.mock import patch
ROOT=Path("/Users/liuningyuan/Desktop/Result/Machine Learning/PADML_F45_REBUILD")
sys.path.insert(0,str(ROOT))
from padml import f5,nested_loco as n
from padml.bundle import canonical_json_bytes as enc,read_safe_zip,write_deterministic_zip,sha256_file,ContractError
ORIGIN=Path("/private/tmp/padml-shap-round2-mi-paa_sa0a")
BASE=Path(tempfile.mkdtemp(prefix="padml-shap-round2-legacy-",dir="/tmp")).resolve()
old_root=ORIGIN/"FULL0-H06"; cur_root=ORIGIN/"FULL0-H12"
old_input=old_root/"final-input/bound/M01.zip"; cur_input=cur_root/"final-input/bound/M01.zip"
old_target=old_root/"final-result/F5_FINAL_FULL_DATA_M01.zip"; cur_target=cur_root/"final-result/F5_FINAL_FULL_DATA_M01.zip"
old_numbers=json.loads(old_target.with_suffix(".numbers.json").read_bytes())
cur_numbers=json.loads(cur_target.with_suffix(".numbers.json").read_bytes())
old_task=n._read_component(old_input)[0]; task=n._read_component(cur_input)[0]
old_prediction=f5._full_final_prediction_record(old_numbers["prediction"],old_numbers["receipt"],"COX_PH")
prediction=f5._full_final_prediction_record(cur_numbers["prediction"],cur_numbers["receipt"],"COX_PH")
old_sources={"padml/f5.py":"17ff0772603392a50fd71a07e6715e348ca81af51c0239ae0f482087a2d6d98a","padml/kernels/f5_shap.R":"584000e05f81ebbc6cdbb7406e069561be71ef4d32071480168db800a0032fe0"}
sources={name:sha256_file(ROOT/name) for name in old_sources}
body=read_safe_zip(next((old_root/"final-result/shap-components").glob("F5_FINAL_AGGREGATE_SHAP_M01_*.zip")))
component=json.loads(body["component.json"]); assert component["imputation"]==1 and component["engine"]["max_iter"]==100
old_binding=f5._f45_final_shap_binding(old_input,old_numbers["archive"]["archive_sha256"],old_task,old_prediction,old_sources)
transport=BASE/"M01.shap.zip"; write_deterministic_zip(transport,{"binding.json":enc(old_binding),"component.json":enc(component)})
pin={"archive_sha256":sha256_file(transport),"archive_size_bytes":transport.stat().st_size,"component_sha256":n._sha(component),"binding_identity_sha256":old_binding["identity_sha256"]}
source_path=BASE/"source.json";source_path.write_bytes(enc({"SYNTHETIC_QUALIFICATION":True}))
(BASE/"M01.numbers.json").write_bytes(enc(old_numbers))
proof={"shap_component_archives":[pin]*20,"executor_source_identity":"e"*64}
numbers={**cur_numbers,"reused_final":{"SYNTHETIC_QUALIFICATION":True}}
evidence={"numbers":numbers,"source_path":source_path,"original_numbers":old_numbers,
 "original_input":old_input,"original_task":old_task,"proof":proof}
reuse={"plan":{"SYNTHETIC_QUALIFICATION":True},"numbers":numbers,"target":cur_target}
binding=f5._f45_final_shap_binding(cur_input,cur_numbers["archive"]["archive_sha256"],task,prediction,sources)
dest=BASE/"new-wrapper.zip"
with patch.object(f5,"_f45_full_final_reuse_evidence",return_value=evidence),patch.object(f5,"_f45_score_reuse_authorities",return_value=({},{"e"*64:old_sources})),patch.object(f5,"_produce_final_shap_component",side_effect=AssertionError("SHAP_RECOMPUTED")) as producer:
 v,record,path=f5._f45_full_shap_checkpoint(dest,binding,cur_input,task,prediction,reuse,None,None,reuse_only=True)
 assert v["engine"]["max_iter"]==100 and record["reuse_mode"]=="COMPLETED_WHOLE_SHAP"
 wrapped=read_safe_zip(path); nested=read_safe_zip(wrapped["producer.zip"])
 assert json.loads(nested["binding.json"])["source_member_sha256"]==old_sources
 assert json.loads(wrapped["binding.json"])["source_member_sha256"]==sources
 assert wrapped["producer.zip"]==transport.read_bytes()
 repeated=f5._f45_full_shap_checkpoint(dest,binding,cur_input,task,prediction,reuse,None,None,reuse_only=True)
 assert repeated[0]==v and producer.call_count==0
 bad=BASE/"bad-wrapper.zip"; saved=transport.read_bytes();transport.write_bytes(saved+b" ")
 try:f5._f45_full_shap_checkpoint(bad,binding,cur_input,task,prediction,reuse,None,None,reuse_only=True)
 except ContractError as e:assert str(e)=="F45_FULL_SHAP_REUSE_PRODUCER_DRIFT"; negative=str(e)
 else:raise AssertionError("Producer tamper accepted")
 transport.write_bytes(saved)
result={"evidence":str(BASE),"original_fixture":str(ORIGIN),"legacy100_complete_producer_reused":True,
 "new_R_source":sources["padml/kernels/f5_shap.R"],"old_R_source":old_sources["padml/kernels/f5_shap.R"],
 "legacy_engine_max_iter":v["engine"]["max_iter"],"mode":record["reuse_mode"],"shap_calls":0,
 "producer_bytes_preserved":True,"tamper_rejected":negative,
 "scope":"Source authority and final-reuse metadata mocked; original checkpoint, byte pin, model-prediction and SHAP-number readers actual"}
(BASE/"result.json").write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
