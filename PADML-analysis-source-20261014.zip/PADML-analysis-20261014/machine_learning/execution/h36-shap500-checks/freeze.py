"""One production freeze; original source compiler and frozen run reader."""
import io,json,os,subprocess,sys,zipfile
from pathlib import Path
from padml import f4,nested_loco as n
from padml.bundle import canonical_json_bytes as enc,sha256_bytes as sha,sha256_file,write_deterministic_zip
assert sys.version_info[:2]==(3,12)
repo=Path(__file__).resolve().parents[2]
base=repo/'execution';checks=base/'h36-shap500-checks'
previous=base/'release-shap-hotpath/PADML_F45_REBUILD_20260928_SHAP_HOTPATH.zip'
assert sha256_file(previous)=='e75282502db329f5c68b3a069ba8cf4342130b4b6c70d822b6f76f7edcc4fa15'
identity=sha(enc(f4._f45_source_member_sha256()))
qualification=json.loads((checks/'source-qualification.json').read_bytes())
linux=json.loads((checks/'linux-input-result.json').read_bytes())
assert qualification['source_identity']==linux['source_identity']==identity
assert len(qualification['checks']['same_run_predecessors'])==14
assert qualification['checks']['baseline_science_retained_for_6_12_24']
assert linux['status']=='PASS' and linux['mice']==linux['selector_paths']==linux['model_fits']==linux['shap']==0
assert linux['prepared_selector_tasks']==320 and linux['training_n']==1811
assert all(q['evaluation_count']==1799 and q['metric_estimable'] for q in linux['repeat_qc'])
assert linux['source_members']==f4._f45_source_member_sha256()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert not subprocess.check_output(['git','diff','--name-only','HEAD','--',*f4.F45_SOURCE_MEMBERS],cwd=repo)
for name in f4.F45_SOURCE_MEMBERS:
    assert subprocess.check_output(['git','show',head+':'+name],cwd=repo)==(repo/name).read_bytes()
with zipfile.ZipFile(previous) as archive:
    members={name:archive.read(name) for name in archive.namelist() if name!='release.json'}
    with zipfile.ZipFile(io.BytesIO(members['source.zip'])) as source:
        changed=[name for name in f4.F45_SOURCE_MEMBERS if source.read(name)!=(repo/name).read_bytes()]
expected={'AGENTS.md','NESTED_LOCO_PROTOCOL.md','science-decision.json','padml/f2_kernel.py','padml/f4.py',
    'padml/f4_compact.py','padml/f5.py','padml/f5_sensitivity.py','padml/kernels/f4_learning_selector.R',
    'padml/kernels/f5_shap.R','padml/nested_loco.py','padml/run.py','padml/worker.py'}
assert set(changed)==expected
out=base/'release-h36-shap500';out.mkdir()
compiled=f4.compile_f45_source_bundle(out/'source.zip')
assert compiled['sha256']==sha256_file(checks/'candidate-source-fixed.zip')
prefix='h36-shap500-predecessor'
members[prefix+'/run.json']=members['run.json'];members[prefix+'/source.zip']=members['source.zip']
old=json.loads(members['run.json'])
members['source.zip']=(out/'source.zip').read_bytes();members['source.compile.json']=enc(compiled)
run={**old,'source_identity':identity,'source_bundle_sha256':compiled['sha256'],'science_decision':n.science_decision_template(),
    'unit_predecessor':{'run_path':old['run_root']+'/'+prefix+'/run.json',
        'run_sha256':sha(members[prefix+'/run.json']),'source_path':old['run_root']+'/'+prefix+'/source.zip',
        'source_sha256':sha(members[prefix+'/source.zip'])}}
run['identity']=sha(enc({k:v for k,v in run.items() if k!='identity'}))
assert run['units']==old['units'] and len(run['units'])==56
members['run.json']=enc(run)
for name in ('AGENTS.md','NESTED_LOCO_PROTOCOL.md','science-decision.json'):
    members[name]=(repo/name).read_bytes()
evidence={p.name:p for p in checks.iterdir() if p.is_file() and p.suffix in {'.py','.json','.log','.md','.txt'}
    and p.name not in {'candidate-record.json'}}
evidence.update({name:repo/name for name in ('tests/test_f2_scoring.py','tests/test_f45_final_full0_reuse.py')})
write_deterministic_zip(out/'h36-shap500-checks.zip',evidence)
members['h36-shap500-checks.zip']=(out/'h36-shap500-checks.zip').read_bytes()
report=(f'Frozen Git: {head}. Source: {identity}. Run: {run["identity"]}.\n\n'+(base/'H36_SHAP500_COMPILE.md').read_text()).encode()
members['README.md']=members['COMPILE_REPORT.md']=report
handoff=f'''# H36 population / retained SHAP500 delivery

Git: {head}
Source: {identity}
Run: {run['identity']}

Unique execution owner: 01a0e04f-b009-71d3-af35-7ae22fe25f9a.

Keep the original 56 units, seven hosts, sealed dependencies, OSS channel, resource admission and owner/process-group wrapper. Deploy this one package atomically with run.json last, only after the old owner and registered groups have exited. Never replace active source.

Whole-unit entry: python -m padml.worker f45 /root/autodl-tmp/PADML_V22/f45-rebuild-20260925/run.json UNIT_ID

H0 resumes FULL0-H06: keep all 20 original model archives/numbers and old failed SHAP directories; produce only missing explanations at max_iter=500. Remove the obsolete PADML_F45_SHAP_DEPENDENCY_REPAIR environment token for this authorized run. A finite exhausted MI permits the other MI to finish but cannot publish the whole unit.

H9 resumes PRIMARY-H36-O6: preserve original presearch/MICE/recipes/shared q-atoms. The native worker creates selector-h36 and search-h36-exclude55 and derives new H36 scores/lock. Full valid STOP functions may be re-scored without refitting; changed actual SetA/params/STOP/seed cause a miss. Do not copy the old H36 selection as new evidence.

H7 remains paused for new dispatch after AAR-H06-O5. Existing valid AAR on other instances finish under the old source before cutover; keep their unchanged H6/H12/H24 scientific identity and original producer. Do not silently revoke user holds. UNKNOWN running state never permits another dispatch.

Retain all F1/F2, 46 accepted F2 outputs, original runtime/source predecessor pins and every legal current-run coordinate. No new historical cleanup or whole-root deletion accompanies this amendment. F2 model-f4/model-f5 are fold identifiers. Preserve all fourteen predecessor manifests/source bundles byte-for-byte; h36-shap500-predecessor is the immediate predecessor.

The package includes three audit rounds, 30 targeted tests, bounded synthetic STOP/SHAP recovery checks, and one Linux real F2 input/320-task prepare-only check. The latter verifies three complete H36 OOF populations of 1799 while preserving 1811 training patients, original events/M20/recipes; all fit/MICE/SHAP counts were zero. No completed clinical model or SHAP500 convergence is claimed. Continue to report true numerical and direct-consumer completion from execution.
'''
members['EXECUTION_HANDOFF.md']=handoff.encode()
summary={'head':head,'source_identity':identity,'run_identity':run['identity'],'source':compiled,
    'changed_source_members':changed,'source_member_count':len(f4.F45_SOURCE_MEMBERS),
    'units':len(run['units']),'predecessors':14,'focused_cases':30,
    'linux_input_check':{'sha256':sha256_file(checks/'linux-input-result.json'),
        'status':linux['status'],'scope':linux['scope']},
    'deployed':False,'clinical_completion_claimed':False}
members['compile-summary.json']=enc(summary)
for name in ('shared/bootstrap.zip','shared/bootstrap-preparation.json','dependencies.json'):
    with zipfile.ZipFile(previous) as archive:assert members[name]==archive.read(name)
release={'kind':'PADML_F45_H36_SHAP500_RELEASE','head':head,'run_identity':run['identity'],'source_identity':identity,
    'members':{name:{'sha256':sha(raw),'size_bytes':len(raw)} for name,raw in members.items()}}
members['release.json']=enc(release)
target=out/'PADML_F45_REBUILD_20260928_H36_SHAP500.zip'
write_deterministic_zip(target,members)
reader_path=checks/'frozen-reader.py'
completed=subprocess.run([sys.executable,'-B',str(reader_path),str(target)],cwd=repo,check=True,capture_output=True,text=True,
    env={**os.environ,'PYTHONPATH':str(repo),'PYTHONDONTWRITEBYTECODE':'1'})
(out/'frozen-reader.log').write_text(completed.stdout)
summary.update(package=str(target),sha256=sha256_file(target),size_bytes=target.stat().st_size)
(out/'compile-summary.json').write_bytes(enc(summary))
print(json.dumps(summary))
