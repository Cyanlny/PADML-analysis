"""Bounded real-input read/prepare check; execution owner runs once on Linux.

No MICE, selector paths, predictive fit, SHAP or production dispatch is allowed.
Original source dictionaries come only from the pinned prior production package.
The full source graph is verified separately by the original frozen reader.
"""
import argparse, ast, copy, io, json, os, platform, subprocess, tempfile, zipfile
from pathlib import Path
from unittest.mock import patch
from padml import f2_kernel as k, f4, f5, nested_loco as n
from padml.bundle import canonical_json_bytes as enc, sha256_bytes, sha256_file


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--presearch', type=Path, required=True)
    parser.add_argument('--prior-package', type=Path, required=True)
    parser.add_argument('--source-identity', required=True)
    parser.add_argument('--output', type=Path, required=True)
    args=parser.parse_args()
    assert platform.system()=='Linux' and not args.output.exists() and args.output.parent.is_dir()
    assert n._sha(f4._f45_source_member_sha256())==args.source_identity
    assert sha256_file(args.prior_package)=='e75282502db329f5c68b3a069ba8cf4342130b4b6c70d822b6f76f7edcc4fa15'
    producers={}
    with zipfile.ZipFile(args.prior_package) as archive:
        release=json.loads(archive.read('release.json'))
        for name in archive.namelist():
            if name=='source.zip' or name.endswith('/source.zip'):
                raw=archive.read(name)
                assert release['members'][name]=={'sha256':sha256_bytes(raw),'size_bytes':len(raw)}
                with zipfile.ZipFile(io.BytesIO(raw)) as source:
                    members={name:sha256_bytes(source.read(name)) for name in f4.F45_SOURCE_MEMBERS}
                producers[n._sha(members)]=members
    receipt=json.loads(args.presearch.with_suffix('.compile.json').read_bytes())
    assert receipt['sha256']=='b9382be2fe88394db6be67489730ec565f35d2d268d3fab971ca07038ccc2b75'
    assert args.presearch.stat().st_size==receipt['size_bytes']==294896792
    assert sha256_file(args.presearch)==receipt['sha256']
    repo=Path(f4.__file__).resolve().parent.parent
    for file in (repo/'padml').rglob('*.py'):
        ast.parse(file.read_bytes())
    parsed=subprocess.run(['Rscript','--vanilla','-e',
        'for (p in commandArgs(TRUE)) invisible(parse(p)); cat("R_PARSE_PASS\\n")',
        str(repo/'padml/kernels/f4_learning_selector.R'),str(repo/'padml/kernels/f5_shap.R')],
        check=True, capture_output=True, text=True)
    calls_seen=[]
    original_phase=f4._full_pipeline_selector_phase_calls
    original_nested=f5._nested_selector_program
    def phase(*a,**kw):
        calls=original_phase(*a,**kw)
        assert len(calls)==320
        for spec,part,task,directory,rscript in calls:
            native=f4._learning_selector_native_spec(spec,part,task,Path(directory))
            assert spec['selection_horizon_months']==36 and spec['execution_scope']=='NESTED_PRIMARY_SELECTOR_M20'
            assert 'evaluation_response' not in native['partition']
        calls_seen.append(len(calls))
        return calls
    def prepare(*a,**kw):
        return original_nested(*a,**kw,prepare_only=True)
    def forbidden(*a,**kw):
        raise AssertionError('NO_NATIVE_CALCULATION_IN_INPUT_PROBE')
    with tempfile.TemporaryDirectory(prefix='h36-input-prepare-',dir=args.output.parent) as temporary:
        root=Path(temporary).resolve()
        with patch.object(f4,'_f45_same_run_source',lambda identity:copy.deepcopy(producers[identity])):
            opened=f4._materialize_o_fit_input_bundle(args.presearch,root/'inputs',pre_search=True)
        state=opened['materialized_pre_search']
        context=state['projection']['training_context']
        assert context['identity_sha256']=='93328c2fc629100bca845c4025325432faf463bf2b035841a32378054be38de7'
        assert len(context['training_ids'])==1811 and len(context['heldout_ids'])==313
        assert set(context['training_ids']).isdisjoint(context['heldout_ids'])
        inner=sorted((p for p in state['registered']['partitions'] if p['kind']=='INNER'),
            key=lambda p:(p['repeat'],p['inner_fold']))
        fit_pins=[dict(p['fit_response']) for p in inner]
        contexts=k._trial_scoring_context(inner,selection_horizon_months=36)
        summaries=[row['context']['ipcw_qc'] for row in contexts['ranking_groups']]
        assert len(summaries)==3 and all(q['metric_estimable'] and q['evaluation_count']==1799 for q in summaries)
        assert [p['fit_response'] for p in inner]==fit_pins
        population=[{'repeat':p['repeat'],'inner_fold':p['inner_fold'],
            'full_validation_n':len(p['evaluation_ids']),
            'eligible_validation_n':len(k._development_evaluation_indices(p,36)),
            'training_n':len(p['fit_ids']),'training_events':p['fit_response']['event_count']} for p in inner]
        with patch.object(f5,'_nested_selector_program',prepare),patch.object(f4,'_full_pipeline_selector_phase_calls',phase), \
             patch.object(subprocess,'run',forbidden):
            prepared=f5._primary_selector_program(state,root/'selector',replay=False,workers=1,
                resource_policy=opened['resource_policy'])
        assert calls_seen==[320] and prepared['status']=='PREPARED_SELECTOR_INPUTS'
        assert prepared['selector_path_count']==prepared['glmnet_call_count']==prepared['new_mice_chains']==0
        assert prepared['source']['science_decision_sha256']==n.science_decision_template(36)['identity_sha256']
        assert not (root/'selector/development-input.json').exists()
        report={'status':'PASS','scope':'ACTUAL_F2_INPUT_READER_H36_POPULATION_AND_SELECTOR_PREPARATION',
            'source_identity':args.source_identity,'source_members':f4._f45_source_member_sha256(),
            'presearch_archive_sha256':receipt['sha256'],'input_context_sha256':context['identity_sha256'],
            'training_n':1811,'heldout_n':313,'training_events':context['training_event_count'],
            'center55_training_n':sum(c=='55' for c in context['centers_by_patient'].values()),
            'repeat_qc':summaries,'partitions':population,'prepared_selector_tasks':len(prepared['task_ids']),
            'prepare_source':prepared['source'],'r_parse':parsed.stdout.strip(),
            'mice':0,'selector_paths':0,'model_fits':0,'shap':0,'production_mutations':0,
            'source_dictionary_qualification':'PINNED_PRIOR_PACKAGE; FULL_GRAPH_VERIFIED_SEPARATELY',
            'scientific_completion':False}
    args.output.write_bytes(enc(report))
    print(json.dumps({'status':report['status'],'output':str(args.output),'sha256':sha256_file(args.output)}))

if __name__=='__main__':
    main()
