import ast, hashlib, json, subprocess, sys, tempfile
from pathlib import Path
from unittest.mock import patch

ROOT = Path('/Users/liuningyuan/Desktop/Result/Machine Learning/PADML_F45_REBUILD')
sys.path.insert(0, str(ROOT))
from padml import f5, nested_loco as n
from padml.bundle import ContractError, canonical_json_bytes as enc, read_safe_zip, sha256_file, write_deterministic_zip

BASE = Path(tempfile.mkdtemp(prefix='padml-shap-round3-', dir='/tmp')).resolve()
RAW_FIXTURE = Path('/private/var/folders/qj/5799w4651d7gmrcfq_wwhyym0000gn/T/padml-shap-round2-z1p7bngp/raw-success/kernelshap-return.rds')
MI_FIXTURE = Path('/private/tmp/padml-shap-round2-mi-paa_sa0a')
r_script = BASE / 'raw-negative.R'
r_script.write_text(r'''
args <- commandArgs(TRUE)
source(args[[1]])
root <- args[[2]]
original <- readRDS(args[[3]])
selected <- paste0('x',1:9)
data <- as.data.frame(matrix(0,2,9)); colnames(data) <- selected
count <- 0L
kernelshap <- function(...) { count <<- count+1L; stop('UNEXPECTED_SHAP_EXECUTION') }
need <- function(x,why) if(!isTRUE(x)) stop(why,call.=FALSE)
errors <- list()
for (case in c('corrupt','wrong-spec','nan-S','inf-SE','nan-prediction')) {
  d <- file.path(root,case); dir.create(d)
  raw <- file.path(d,'kernelshap-return.rds')
  value <- original
  if(case=='corrupt') writeBin(as.raw(c(1,2,3)),raw) else {
    if(case=='wrong-spec') value$spec <- as.raw(c(9,9,9))
    if(case=='nan-S') value$result$S[[1]][1,1] <- NaN
    if(case=='inf-SE') value$result$SE[[1]][1,1] <- Inf
    if(case=='nan-prediction') value$result$predictions[1,1] <- NaN
    saveRDS(value,raw)
  }
  before <- readBin(raw,'raw',n=file.info(raw)$size)
  error <- tryCatch({padml_kernelshap_component('XGBOOST_COX',1L,
    paste(rep('a',64),collapse=''),selected,c('p1','p2'),data,
    function(x) matrix(.5,nrow(x),4),780000001L,need,d,as.raw(c(1,2,3))); 'ACCEPTED'},
    error=function(e) conditionMessage(e))
  need(error!='ACCEPTED','INVALID_RAW_ACCEPTED')
  need(count==0L,'RAW_RECOMPUTED')
  need(identical(before,readBin(raw,'raw',n=file.info(raw)$size)),'RAW_MODIFIED')
  need(!file.exists(file.path(d,'shap.json')),'INVALID_RAW_PUBLISHED')
  errors[[case]] <- error
}
writeLines(jsonlite::toJSON(list(errors=errors,shap_calls=count,raw_bytes_preserved=TRUE),
  auto_unbox=TRUE),file.path(root,'r-result.json'))
''')
r = subprocess.run(['/usr/local/bin/Rscript','--vanilla',str(r_script),str(ROOT/'padml/kernels/f5_shap.R'),str(BASE),str(RAW_FIXTURE)], capture_output=True, text=True)
(BASE/'r.stdout').write_text(r.stdout); (BASE/'r.stderr').write_text(r.stderr)
assert r.returncode == 0, (r.stdout,r.stderr)
result = json.loads((BASE/'r-result.json').read_bytes())
task = dict(family='XGBOOST_COX',imputation=1,selected_parents=[f'x{i}' for i in range(1,10)])
prediction = dict(patient_ids=['p1','p2'],survival=[[1.]+[.5]*36]*2)
result['python_invalid_diagnostics'] = {}
for case in ('nan-S','inf-SE','nan-prediction'):
    try: f5._read_final_shap_diagnostic(BASE/case,task,prediction,'a'*64)
    except f5._FinalShapBudgetExhausted: raise AssertionError(case+': swallowed as finite budget failure')
    except ContractError as exc: result['python_invalid_diagnostics'][case] = str(exc)
    else: raise AssertionError(case+': accepted')

cur = MI_FIXTURE/'FULL0-H12'
source = cur/'final-input/bound/M01.zip'
target = cur/'final-result/F5_FINAL_FULL_DATA_M01.zip'
native = read_safe_zip(target)
numbers = json.loads(target.with_suffix('.numbers.json').read_bytes())
task = n._read_component(source)[0]
prediction = f5._full_final_prediction_record(numbers['prediction'],numbers['receipt'],'COX_PH')
sources = {name:sha256_file(ROOT/name) for name in ('padml/f5.py','padml/kernels/f5_shap.R')}
binding = f5._f45_final_shap_binding(source,numbers['archive']['archive_sha256'],task,prediction,sources)
root = BASE/'binding'; root.mkdir()
archive = root/f"F5_FINAL_AGGREGATE_SHAP_M01_{binding['identity_sha256']}.zip"
work = archive.with_suffix(''); work.mkdir()
(work/'binding.json').write_bytes(enc({**binding,'model_sha256':'b'*64}))
(work/'kernelshap-return.rds').write_bytes(RAW_FIXTURE.read_bytes())
with patch.object(f5,'_produce_final_shap_component',side_effect=AssertionError('UNEXPECTED_SHAP_EXECUTION')) as producer:
    try: f5._load_or_produce_final_shap_checkpoint(root,source,numbers['archive']['archive_sha256'],task,native['model.bin'],native['baseline.bin'],prediction)
    except ContractError as exc:
        assert str(exc)=='F5_SHAP_INCOMPLETE_COMPONENT_REQUIRES_NEW_AUTHORITY',str(exc)
        result['work_binding_drift'] = str(exc)
    else: raise AssertionError('Work binding drift accepted')
    assert producer.call_count==0

old_checkpoint = next((MI_FIXTURE/'FULL0-H06/final-result/shap-components').glob('F5_FINAL_AGGREGATE_SHAP_M01_*.zip'))
old_component = read_safe_zip(old_checkpoint)['component.json']
assert json.loads(old_component)['engine']['max_iter']==100
root = BASE/'current-binding-old-budget'; root.mkdir()
archive = root/f"F5_FINAL_AGGREGATE_SHAP_M01_{binding['identity_sha256']}.zip"
write_deterministic_zip(archive,{'binding.json':enc(binding),'component.json':old_component})
with patch.object(f5,'_produce_final_shap_component',side_effect=AssertionError('UNEXPECTED_SHAP_EXECUTION')) as producer:
    try: f5._load_or_produce_final_shap_checkpoint(root,source,numbers['archive']['archive_sha256'],task,native['model.bin'],native['baseline.bin'],prediction)
    except ContractError as exc:
        assert str(exc)=='F5_SHAP_ENGINE_INVALID',str(exc)
        result['current_binding_old_budget'] = str(exc)
    else: raise AssertionError('Old budget accepted as current producer')
    assert producer.call_count==0

tree = ast.parse((ROOT/'padml/f5.py').read_text())
names = {'_validate_final_shap_component','_read_final_shap_diagnostic','_produce_final_shap_component',
    '_f45_full_shap_checkpoint','_load_or_produce_final_shap_checkpoint','_execute_final_refit_bundle_pair','execute_final_refit_batch'}
result.update(evidence=str(BASE),raw_fixture=str(RAW_FIXTURE),mi_fixture=str(MI_FIXTURE),sources=sources,
    source_functions={node.name:hashlib.sha256(ast.dump(node,include_attributes=False).encode()).hexdigest()
        for node in tree.body if isinstance(node,(ast.FunctionDef,ast.ClassDef)) and node.name in names},
    scope='Actual R raw-recovery and Python diagnostic/checkpoint readers; synthetic retained return/model bytes; zero model fit or SHAP computation')
(BASE/'result.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
