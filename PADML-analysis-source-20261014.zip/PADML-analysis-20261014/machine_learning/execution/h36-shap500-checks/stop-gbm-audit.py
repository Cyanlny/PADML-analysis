"""Isolated H36 GBM transport/rescore audit. Synthetic native bytes only; no R or fit."""
from pathlib import Path
import copy, json, shutil, sys, tempfile
REPO = Path('/Users/liuningyuan/Desktop/Result/Machine Learning/PADML_F45_REBUILD')
sys.path[:0] = [str(REPO), str(REPO / 'tests')]
import pytest
from padml import f5, f4_compact as compact, f2_kernel as k
from padml.bundle import canonical_json_bytes as enc, sha256_file, sha256_bytes, ContractError
from test_a12_q_native import _unfitted_gbm_loss_unit
logs = []
def note(s):
    logs.append(s); print(s, flush=True)
def put(p, value):
    p.parent.mkdir(parents=True, exist_ok=True); p.write_bytes(enc(value))
def pin(p): return {'sha256': sha256_file(p), 'size_bytes': p.stat().st_size}
base = Path(tempfile.mkdtemp(prefix='padml-h36-stop-audit-', dir='/tmp')).resolve()
try:
    note('SOURCE f5.py ' + sha256_file(REPO / 'padml/f5.py'))
    note('FIXTURE ' + str(base))
    with pytest.MonkeyPatch.context() as mp:
        fixture = base / 'fixture'; fixture.mkdir()
        q, initial_job, native_calls, part, matrices = _unfitted_gbm_loss_unit((None,None,None,None,{}), fixture, mp, 'FULL0')
        cov = base / 'covariates'; cov.mkdir()
        ids = part['fit_ids'] + part['evaluation_ids']
        raw = ('Patient_ID,Center,Age\n' + ''.join(f'{patient},{55 if i == 4 else 36},{40+i}\n' for i,patient in enumerate(ids))).encode()
        (cov / 'imp01.csv').write_bytes(raw)
        part['application_ids'] = ids
        part['covariates'] = {'input_dir': str(cov), 'members': [{'name':'imp01.csv', **pin(cov / 'imp01.csv')}], 'data_identity': k._sha(raw.decode())}
        reg = initial_job['task'][1]
        reg['partitions'][0].update(covariates=copy.deepcopy(part['covariates']), application_ids=ids)
        fn = k._run_r_prediction_pool_task
        reg['diagnostic_partitions'] = []
        initial_job['task'] = (k._r_prediction_child_spec(initial_job['task'][0]), *initial_job['task'][1:])
        initial = f5._execute_and_verify_q_search_unit(initial_job)
        assert native_calls == [False, True]
        note('SYNTHETIC_NATIVE fixture emitted original risk arrays; original produce/audit transport=2, real R/fit=0')
        old_call = initial_job['task']
        current_spec = {**old_call[0], 'selection_horizon_months':36, 'trial_scoring': {**k.load_science_authority()['science']['f2_model_development']['trial_scoring'], 'ibs_grid_months':list(range(37)), 'ibs_integration':'TRAPEZOID_DIVIDE_BY_36'}}
        current = (current_spec, old_call[1], old_call[2], old_call[3], old_call[4], old_call[5], part)
        cache = base / 'cache'; cache.mkdir()
        control = {'cache':str(cache), 'source_identity':'e'*64, 'read_only':False}
        key_old = f5._current_q_key({'current_q':control}, fn, old_call, include_stop_population=False)
        key_new = f5._current_q_key({'current_q':control}, fn, current)
        assert key_new != key_old
        assert f5._current_q_key({'current_q':control}, fn, current, include_stop_population=False) == key_old
        donor = cache / 'atoms' / key_old
        shutil.copytree(q, donor)
        old_sha = sha256_file(donor / 'input.json')
        old_scope = cache / 'inputs' / old_sha; old_scope.mkdir(parents=True)
        shutil.copyfile(donor / 'input.json', old_scope / 'input.json')
        put(old_scope / 'registered.json', reg)
        task = old_call[2][0]
        description = {'key':key_old,'function':fn.__name__,'executor_source_identity':'e'*64,'q_input_sha256':old_sha,
            'task':task, 'native_units':initial['native_units'],'evaluation_mode':old_call[5],'handoff_name':None}
        put(donor / 'producer.json', description)
        evaluation = json.loads((donor / 'native' / initial_job['task_id'] / 'evaluation.json').read_bytes())
        lock = evaluation['result']
        old_value = [{'task_id':task['task_id'],'partition_id':task['partition_id'],'imputation':task['imputation'],**lock,'minimum_stopping_loss':lock['minimum_grouped_cox_deviance']}]
        put(donor / 'values.json', old_value)
        old_audit = {'values_sha256':sha256_file(donor / 'values.json'), 'native_units':initial['native_units']}
        put(donor / 'audit.json', old_audit)
        receipt = {'key':key_old, 'native_units':initial['native_units'],'members':initial['members'],'values':pin(donor / 'values.json'),'audit':old_audit}
        put(donor / 'receipt.json', receipt)
        current_input = {'kind':'PADML_F5_Q_INPUT_V1','spec':current_spec,'task':task}
        current_sha = sha256_bytes(enc(current_input)); scope = cache / 'inputs' / current_sha
        put(scope / 'input.json', current_input); put(scope / 'registered.json', reg)
        control['input_sha256'] = current_sha
        job = {'function':fn.__name__,'call':current,'key':key_new,'control':control}
        before = {p.relative_to(donor).as_posix():p.read_bytes() for p in donor.rglob('*') if p.is_file()}
        found = f5._current_q_stop_source(job, fn)
        assert found and found['key'] == key_old and found['new_model_fit_count'] == 0
        note('PASS legacy fit key found; H36 scoring key differs and 0-fit donor is selected')
        for change in ('seed','parameters','selected_parents'):
            changed = copy.deepcopy(current)
            if change == 'seed': changed[2][0]['seed'] += 1
            elif change == 'parameters': changed[2][0]['parameters']['minimum_improvement'] = .1
            else: changed[2][0]['selected_parents'] = ['BMI']
            assert f5._current_q_stop_source({**job,'call':changed}, fn) is None
        note('PASS seed/parameters/SetA changes reject donor')
        answer = f5._current_q_atom_result(job)
        assert native_calls == [False, True]
        new_root = Path(answer['root']); ev_path = new_root / 'native/h36-stop-score/evaluation.json'
        ev = json.loads(ev_path.read_bytes())
        assert ev['binding']['scoring_ids'] == [part['evaluation_ids'][1]]
        assert ev['evaluated_path']['validation_n'] == 1 and len(ev['evaluated_path']['losses']) == 6
        assert {p.relative_to(donor).as_posix():p.read_bytes() for p in donor.rglob('*') if p.is_file()} == before
        note('PASS GBM raw NONE reader -> real grouped loss rescore: validation_n=1, 6 trees, donor bytes unchanged, no native call')
        outer = base / 'completed-q'; (outer / 'native').mkdir(parents=True)
        put(outer / 'input.json', current_input); put(outer / 'result.json', {'kind':'SYNTHETIC_Q_RESULT','result':answer['value']})
        state = {'references': {'input.json':pin(outer / 'input.json')}}
        f5._current_q_import(outer, answer, state)
        compact._full_pipeline_q_numerical_members(outer, publish=True, transported_refs=state['references'])
        compact._full_pipeline_q_numerical_members(outer)
        note('PASS nested donor numeric import -> outer Q numbers publish -> direct compact readback')
        def forbidden(*args, **kwargs): raise AssertionError('RESCORE_CALLED_ON_RESUME')
        mp.setattr(f5,'_q_search_unit_call',forbidden)
        again = f5._current_q_atom_result(job)
        assert again['value'] == answer['value']
        for name in ('receipt.json','values.json','audit.json'): (new_root / name).unlink()
        tail = f5._current_q_atom_result(job)
        assert tail['value'] == answer['value']
        note('PASS complete receipt and evaluation-only tail resume without raw/function/score invocation')
        for name in ('receipt.json','values.json','audit.json'): (new_root / name).unlink()
        bad = copy.deepcopy(ev); bad['value'][0]['selected_trees'] = 999999
        ev_path.write_bytes(enc(bad))
        try:
            accepted = f5._current_q_atom_result(job)
        except (ContractError, AssertionError, KeyError, TypeError) as exc:
            note('BAD_VALUE_REJECTED ' + type(exc).__name__ + ':' + str(exc))
        else:
            assert accepted['value'][0]['selected_trees'] == 999999
            note('DEFECT bad selected_trees=999999 with unchanged binding was sealed into new receipt on tail resume')
finally:
    Path('/tmp/padml_h36_stop_atom_audit.stdout').write_text('\n'.join(logs)+'\n')
