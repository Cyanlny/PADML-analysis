import copy, csv, io, json, sys, tempfile
from pathlib import Path
root=Path('/Users/liuningyuan/Desktop/Result/Machine Learning/PADML_F45_REBUILD')
sys.path[:0]=[str(root), str(root/'tests')]
import pytest
from padml import f2_kernel as f2, f4, f5, nested_loco as n
from padml.bundle import canonical_json_bytes as enc, strict_json_bytes
import test_f5, test_nested_aar_mice as fixtures
from test_nested_full_development import _unfitted_selector_path_values

mp=pytest.MonkeyPatch()
mp.setattr(fixtures,'_unfitted_confirmed_decision',lambda **k:n.science_decision_template(24))
mp.setattr(test_f5,'compile_full_data_mice_plan',lambda *a,**k: {'UNFITTED_UNUSED_PLAN':True})
mp.setattr(f5.subprocess,'run',lambda *a,**k: (_ for _ in ()).throw(AssertionError('NO_NATIVE_RNG_OR_FIT')))
work=Path(tempfile.mkdtemp(prefix='unfitted-primary-interface-')).resolve()
source=fixtures.aar_source.__wrapped__(mp)
_,_,policy,_,frozen,lock=fixtures._projected_outer_fixture(source,work,mp,'ELASTIC_NET_COX')
registered=f4._materialize_o_fit_fold(frozen,1,work/'unused')
parts=registered['partitions']
registered['identity']='1'*64
model=frozen['models'][1,'ELASTIC_NET_COX']
recipes=model['selector_evidence']['recipe_set']
by_id={r['partition_id']:r for r in recipes['recipes']}
ordered=sorted((p for p in parts if p['kind']=='INNER'),key=lambda p:(p['repeat'],p['inner_fold']))
outer,=[p for p in parts if p['kind']=='OUTER']
recipes['recipes']=[by_id[p['partition_id']] for p in [*ordered,outer]]
recipes['recipe_set_sha256']=n._sha({k:v for k,v in recipes.items() if k!='recipe_set_sha256'})
model['selector_evidence']['outer_recipe_sha256']=recipes['recipes'][-1]['recipe_sha256']
frozen['f2_acceptance_sha256']='2'*64
frozen['accepted_result_sha256']={n._accepted_result_unit_id(1,'ELASTIC_NET_COX'):'3'*64}
frozen['centers']={r['Patient_ID']:r['Center'] for r in csv.DictReader(io.StringIO(frozen['covariates_csv'].decode()))}
state={'projection':{'training_context':source[3]['primary_training_context'],
    'f2_acceptance_sha256':'2'*64, 'science_decision':n.science_decision_template(24),
    'training_event_count':source[3]['primary_training_context']['training_event_count'],
    'selected_parents':model['selector_evidence']['selected_parents'],
    'common_set_design_df':model['selector_evidence']['common_set_design_df'],
    'selector_evidence_sha256':model['selector_evidence_sha256']},
    'frozen':frozen,'registered':registered,'source_registered_identity':'1'*64}
observed={}
def selector_stub(context, partitions, target, **kw):
    calls=f4._full_pipeline_selector_phase_calls(context,partitions,[.5],target/'synthetic',rscript='FORBIDDEN')
    assert len(calls)==320 and all(c[0]['selection_horizon_months']==36 for c in calls)
    assert all(c[0]['execution_scope']=='NESTED_PRIMARY_SELECTOR_M20' for c in calls)
    assert all('evaluation_response' not in f4._learning_selector_native_spec(c[0],c[1],c[2],target)['partition'] for c in calls)
    full=partitions[-1]
    assert full['fit_ids']==outer['fit_ids']==full['application_ids']==full['evaluation_ids']
    assert not set(full['fit_ids']) & set(outer['evaluation_ids'])
    assert any(frozen['centers'][p]=='55' for p in full['fit_ids'])
    observed['eligible_n']=[len(f2._development_evaluation_indices(p,36)) for p in partitions[:-1]]
    observed['full_validation_n']=[len(p['evaluation_ids']) for p in partitions[:-1]]
    values=[_unfitted_selector_path_values(*c[:3])['sealed_elastic_paths'][0] for c in calls[-20:]]
    ratios=calls[-1][2]['ratios']
    chosen={'alpha':.5,'selected_parents':['AST_ALT','Sex'],'common_set_design_df':sum(len(r['columns']) for r in f2._expected_family_parent_column_map(['AST_ALT','Sex'],'ELASTIC_NET_COX',calls[-1][0]['predictors'],full['transform_recipe'])),
      'outer_training_event_count':full['fit_response']['event_count'],
      'selected_ratio_by_imputation':[ratios[8]]*20,
      'lambda_by_imputation':[v['lambda_path'][8] for v in values],
      'lambda_upper_bound_by_imputation':[v['lambda_upper_bound'] for v in values],
      'epv_resolution':{'preferred_minimum':15,'minimum':15,'fallback_used':False,
        'coarse_records_sha256':'4'*64,'attempts':[{'minimum':15,'alpha_feasibility':[
          {'alpha':a,'status':'FEASIBLE','reason_code':'OK'} for a in f4.load_science_authority()['science']['f2_model_development']['selector_contract']['alpha_grid']['coarse']]}]}}
    n.validate_epv_resolution(chosen['epv_resolution'])
    return {'selector':chosen,'candidate_records_sha256':'5'*64,'native_member_set_sha256':'6'*64,
      'distinct_alpha_count':1,'selector_path_count':320}, {'UNFITTED':True}
mp.setattr(f4,'_full_pipeline_selector_search',selector_stub)
development=f5._primary_selector_program(state,work/'selector',replay=False,workers=1,resource_policy=policy)
assert development['transform_recipes']==recipes
chosen=development['selector']
new_spec={'family':'ELASTIC_NET_COX','alpha':chosen['alpha'],
 'ratio_by_imputation':chosen['selected_ratio_by_imputation'],'lambda_by_imputation':chosen['lambda_by_imputation'],
 'lambda_upper_bound_by_imputation':chosen['lambda_upper_bound_by_imputation']}
old_spec=copy.deepcopy(new_spec);old_spec['alpha']=.25
for b in old_spec['lambda_upper_bound_by_imputation']:b['alpha']=.25
model.update(selected_spec=old_spec, selected_spec_sha256=n._sha(old_spec))
inner=ordered[0]
raw=inner['evaluation_response']['private_bytes'];vpath=work/'inner-evaluation.csv';vpath.write_bytes(raw)
inner['evaluation_response']={k:v for k,v in inner['evaluation_response'].items() if k!='private_bytes'}
inner['evaluation_response']['path']=str(vpath)
jobs=f4._prepare_o_fit_partition(model,inner,frozen,primary_selector=development,locked_scoring_decision=n.science_decision_template(36))
assert len(jobs)==20
for i,j in enumerate(jobs):
    t=strict_json_bytes(j['entries']['task.json'])
    assert t['selected_parents']==chosen['selected_parents'] and t['parameters']['alpha']==.5
    assert t['parameters']['lambda']==chosen['lambda_by_imputation'][i]
    assert t['f4_outer_elastic_source']['selected_spec']==new_spec
projection=f4._primary_pre_search_family_projection(state,'ELASTIC_NET_COX',primary_selector=development)
assert projection['selector_evidence_sha256']==development['identity_sha256']
assert projection['selected_parents']==['AST_ALT','Sex'] and projection['science_decision']==n.science_decision_template(36)
print(json.dumps({'status':'PASS','scope':'SYNTHETIC_UNFITTED helper + 320 task specs + original prepare M20 + family projection; selector numeric reduction mocked; no subprocess/native/clinical computation','work':str(work),'selector_identity':development['identity_sha256'],'jobs':len(jobs),**observed},indent=2))
mp.undo()
