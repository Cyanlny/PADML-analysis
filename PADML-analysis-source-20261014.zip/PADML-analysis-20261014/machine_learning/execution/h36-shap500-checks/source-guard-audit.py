"""Exact source-qualification branch only; no source import or clinical calls."""
import ast
import copy
import hashlib
import io
import json
import zipfile
from pathlib import Path

repo = Path('/Users/liuningyuan/Desktop/Result/Machine Learning/PADML_F45_REBUILD')
release = repo / 'execution/release-aar-binding/PADML_F45_REBUILD_20260926_AAR_BINDING.zip'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
assert sha(release.read_bytes()) == 'fece8eb4b8be17a386527cb9ab1c75894b2627a358dfacd06ff3a76bbfd42bec'
with zipfile.ZipFile(release) as z:
    source_raw = z.read('resource-baseline/source.zip')
assert sha(source_raw) == '6ef9a23dc4e881f41c10f305bab1c9940a02e9a8e63b3b6dba176fdf56486734'
with zipfile.ZipFile(io.BytesIO(source_raw)) as z:
    old_raw = z.read('padml/f5.py')
new_raw = (repo / 'padml/f5.py').read_bytes()
run_raw = (repo / 'padml/run.py').read_bytes()
def definition(raw, name):
    return next(n for n in ast.parse(raw).body if isinstance(n, ast.FunctionDef) and n.name == name)
original = definition(old_raw, '_current_q_atom')
retained = definition(new_raw, '_current_q_atom_result')
fn = definition(run_raw, '_validate_f45_resource_revision_uncached')
block = next(n for n in ast.walk(fn) if isinstance(n, ast.If) and any(
    isinstance(c, ast.ClassDef) and c.name == 'ProducerMetadataOnly' for c in n.body))
start = next(i for i, n in enumerate(block.body) if isinstance(n, ast.ClassDef) and n.name == 'ProducerMetadataOnly')
# Run the actual five guard statements; no bundle reader, run chain or producer executes.
statements = copy.deepcopy(block.body[start:])
assert len(statements) == 5
module = ast.fix_missing_locations(ast.Module(body=statements, type_ignores=[]))
code = compile(module, '<actual-run-source-guard>', 'exec')
class Refusal(Exception): pass
def require(ok, reason):
    if not ok: raise Refusal(reason)
def guard(old):
    scope = dict(ast=ast, sha256_bytes=sha, _require=require,
        original=copy.deepcopy(old), retained=copy.deepcopy(retained))
    exec(code, scope)
    return scope['retained_h36_stop']
assert guard(original) is True
mutated = copy.deepcopy(original)
mutated.body.append(ast.Assign(targets=[ast.Name(id='_unreviewed_producer_mutation', ctx=ast.Store())], value=ast.Constant(value=1)))
try:
    guard(mutated)
except Refusal as e:
    refused = str(e)
    assert refused == 'F45_RESOURCE_REVISION_ATOM_NUMERICS_DRIFT'
else:
    raise AssertionError('unknown old atom accepted')
result = {'positive_exact_pair': True, 'mutated_old_atom_rejected': refused,
    'old_atom_ast_sha256': sha(ast.dump(original, include_attributes=False).encode()),
    'current_atom_result_ast_sha256': sha(ast.dump(retained, include_attributes=False).encode()),
    'mutated_old_atom_ast_sha256': sha(ast.dump(mutated, include_attributes=False).encode()),
    'source_pins': {'run.py': sha(run_raw), 'f5.py': sha(new_raw), 'resource_baseline_source_zip': sha(source_raw)},
    'scope': 'actual isolated five source-guard statements only; no complete source/chain test',
    'clinical_calls': 0, 'repository_writes': 0}
assert result['old_atom_ast_sha256'] == '95cafc8b2370ea0532109a8e5491cd48ea788198524ceb950b5488f25571ebb5'
print(json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2))
Path('/tmp/padml-h36-source-guard-audit-20260928/results.json').write_text(json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2)+'\n')
