"""Exact same-run readback qualification and frozen-package consumption; no clinical work."""
import ast, copy, io, json, os, tempfile, zipfile, subprocess, sys
from pathlib import Path
from unittest.mock import patch
from padml import f4, run as r, f5
from padml.bundle import ContractError, canonical_json_bytes as encode, sha256_bytes, sha256_file, strict_json_bytes

base=Path('/Users/liuningyuan/Desktop/Result/Machine Learning/PADML_F45_REBUILD/execution')
repo=base.parent
release=base/'release-shap-hotpath/PADML_F45_REBUILD_20260928_SHAP_HOTPATH.zip'
assert sha256_file(release)=='e75282502db329f5c68b3a069ba8cf4342130b4b6c70d822b6f76f7edcc4fa15'
checks={}
with tempfile.TemporaryDirectory(prefix='padml-aar-tail-source-') as tmp:
 root=Path(tmp).resolve()
 with zipfile.ZipFile(release) as z:
  for name in z.namelist():
   if name in ('run.json','source.zip') or name.endswith(('/run.json','/source.zip')):
    p=root/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z.read(name))
 original=strict_json_bytes((root/'run.json').read_bytes())
 remote=original['run_root']
 def local_path(value):
  value=str(value)
  return Path(str(root)+value[len(remote):]) if value.startswith(remote+'/') else Path(value)
 value={**original,'science_decision':f5._nested_science.science_decision_template(),'source_identity':sha256_bytes(encode(f4._f45_source_member_sha256())),
  'source_bundle_sha256':'d'*64,
  'unit_predecessor':{'run_path':str(root/'run.json'),'run_sha256':sha256_file(root/'run.json'),
   'source_path':str(root/'source.zip'),'source_sha256':sha256_file(root/'source.zip')}}
 value['identity']=sha256_bytes(encode({k:v for k,v in value.items() if k!='identity'}))
 (root/'current-run.json').write_bytes(encode(value))
 with patch.object(r,'Path',local_path),patch.object(f4,'Path',local_path):
  revisions=r.f45_unit_predecessors(value)
  assert [x['identity'] for x in revisions]==[
   'd3cdbaef39e498f5c1f832d760d2f13c8835b7558889e5b9dc03849ea505bc47',
   'c424be6060187ccec5c83f55f9774d513e11569c35dd3ee107b715d0e445d237',
   '9d2443b7ea630856f54f3a2b5f136c4f909b0b6ee01cae7e7036ef954bc2f5a7',
   '17fd4ef5e29e3bc4cd5d755f806a7b43f1c08c78d93dd4416a1efd9b2c0e924e',
   '225e771f874a0791b524257e532b8620d0f00128240870868ff0d4b1b50e8b48',
   'f018afee81e4947b992854979e1f765bd276ced6fccfe4f1f533fd02297e603e',
   '4fd95eb512ba20a925ba3ee6146e6640b3c144bc955fdb5d20d6b4b2e1e684fb',
   '4c8cabe991a6e9d0eab29411522adae5db8bd6684e8d6e33b8e5e36205a29f7f',
   '9633db6d7a3ada9d1252bef53c35ae583b315034611a8d24216970d7dc3ec1c1',
   '1a5fba765d42f0a9b3f1ccd46690e689796b948e72216f25cccf72d6fdb0d955',
   '66c67b37bf25a365e95a8748927bea4782128f892d204735fef4c5cacd2c3e24',
   'edf9df2afa86dc8e2e38516bd94f821feba51485f26c590946f0ef3ab6994338',
   '2d7929461468f78347133b036f93fd1ea57c187777b74801b47015a8dcf78419',
   '096b856d4f3aedb609e7e15b8898144ec565f037db7ddf3e79e3957a0e64f723']
  checks['same_run_predecessors']=[x['identity'] for x in revisions]
  baseline=r.validate_f45_resource_revision(value)
  assert sha256_bytes(encode(baseline))=='25190343ea52b20014b6cb38eae518b4fe77621e02c8eb24a5b3f66fc5047c50'
  checks['original_fit_producer_baseline_qualified']=True
  checks['baseline_science_retained_for_6_12_24']=all(f5._nested_science.science_decision_template(h)==original['science_decision'] for h in (6,12,24))
  assert checks['baseline_science_retained_for_6_12_24']
  assert value['science_decision']!=original['science_decision']
  with patch.dict(os.environ,{'PADML_F45_RUN_PATH':str(root/'current-run.json')}):
   # This exact chain was validated above. Reuse that result inside the
   # authority mapping instead of repeatedly parsing the same eleven bundles.
   with patch.object(r,'f45_unit_predecessors',return_value=revisions):
    executors,sources=f5._f45_score_reuse_authorities()
  assert set(executors)=={value['identity'],*(x['identity'] for x in revisions)}
  aar=next(x for x in revisions if x['identity'].startswith('edf9df'))
  assert aar['source_identity'] in sources
  checks['original_aar_producer_qualified']=aar['source_identity']
  current=repo/'padml/f5.py'
  raw=current.read_bytes();real_read=Path.read_bytes
  before=b'predict_type="margin", iteration_range=(0, 0),'
  assert raw.count(before)==1
  altered=raw.replace(before,b'predict_type="value", iteration_range=(0, 0),',1)
  with patch.object(Path,'read_bytes',lambda path:altered if path==current else real_read(path)):
   for label,validator in [('predecessor',r.f45_unit_predecessors),('baseline',r.validate_f45_resource_revision)]:
    try:validator(value)
    except ContractError as exc:checks[label+'_unreviewed_margin_change_rejected']=str(exc)
    else:raise AssertionError(label)
  damaged=copy.deepcopy(value);damaged['unit_predecessor']['source_sha256']='f'*64
  try:r.f45_unit_predecessors(damaged)
  except ContractError as exc:checks['unknown_source_pin_rejected']=str(exc)
  else:raise AssertionError('unknown source')
 assert (root/'run.json').read_bytes()==encode(original)
result={'source_identity':value['source_identity'],'checks':checks,'clinical_calls':0,'production_mutations':0}
(base/'h36-shap500-checks/source-qualification.json').write_bytes(encode(result))
print(json.dumps(result))
