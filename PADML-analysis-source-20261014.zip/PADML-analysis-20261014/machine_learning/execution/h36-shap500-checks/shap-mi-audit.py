import copy, json, sys, tempfile, hashlib
from pathlib import Path
from unittest.mock import patch
ROOT=Path("/Users/liuningyuan/Desktop/Result/Machine Learning/PADML_F45_REBUILD")
sys.path[:0]=[str(ROOT),str(ROOT/"tests")]
import pytest
from padml import f5
from padml.bundle import ContractError
from test_f45_final_full0_reuse import fixture
import test_f45_final_full0_reuse as fixture_module
from test_full0_cox12_prepare import _policy
BASE=Path(tempfile.mkdtemp(prefix="padml-shap-round2-mi-",dir="/tmp")).resolve()
mp=pytest.MonkeyPatch()
try:
 real_components = fixture_module.final_shap_components
 def current_components(*a, **kw):
  values = real_components(*a, **kw)
  for value in values: value['engine']['max_iter'] = 500
  return values
 mp.setattr(fixture_module, 'final_shap_components', current_components)
 state,candidate,counts=fixture(BASE,mp)
 owner,inputs,outputs,lineage,tasks=state
 jobs=[(inputs/f"bound/M{i:02d}.zip",outputs/f"F5_FINAL_FULL_DATA_M{i:02d}.zip",
        lineage["final_refit_plan"],tasks[i],lineage["final_recipe"]) for i in range(1,21)]
 real_collect=f5._collect_final_shap_component
 def seed_numbers(job,**kw):raise f5._FinalShapBudgetExhausted("SYNTHETIC_PREEXISTING_MODEL")
 with patch.object(f5,"_collect_final_shap_component",seed_numbers):
  for job in jobs:
   assert f5._execute_final_refit_bundle_pair(job)["status"]=="SHAP_BUDGET_EXHAUSTED"
 native=[*outputs.glob("F5_FINAL_FULL_DATA_M*.zip"),*outputs.glob("*.numbers.json")]
 before={str(p.relative_to(BASE)):hashlib.sha256(p.read_bytes()).hexdigest() for p in native}
 assert len(before)==40
 producer=f5._produce_final_shap_component
 counts.update(fit=0,audit=0,shap=0,pools=[])
 calls=[]
 def shap(source,task,model,baseline,prediction,**kw):
  calls.append(task["imputation"])
  if task["imputation"]==5:
   (kw["work_root"]/"kernelshap-return.rds").write_bytes(b"SYNTHETIC_RAW_NO_REAL_SHAP")
   raise f5._FinalShapBudgetExhausted("SYNTHETIC_VALIDATED_BUDGET_EXHAUSTED")
  v=producer(source,task,model,baseline,prediction,**kw)
  v["engine"]["max_iter"]=500
  return v
 mp.setattr(f5,"_produce_final_shap_component",shap)
 errors=[]
 for attempt in (1,2):
  try:f5.execute_final_refit_batch(inputs,outputs,resource_policy=_policy(),selection_horizon_months=12)
  except ContractError as e:
   assert str(e)=="F5_FULL_FINAL_SHAP_INCOMPLETE:5",str(e)
   errors.append(str(e))
  else:raise AssertionError("Incomplete batch accepted")
  report=json.loads((outputs/"shap-failures.json").read_bytes())
  assert len(report["results"])==20
  assert [v["imputation"] for v in report["results"] if v["status"]=="SHAP_BUDGET_EXHAUSTED"]==[5]
  assert len(list((outputs/"shap-components").glob("*.zip")))==19
 after={str(p.relative_to(BASE)):hashlib.sha256(p.read_bytes()).hexdigest() for p in native}
 assert before==after and counts["fit"]==counts["audit"]==0
 assert calls==list(range(1,21))+[5],calls
 result={"fixture":str(BASE),"errors":errors,"typed_worker_shap_calls":calls,
  "native_model_number_pins_unchanged":len(before),"remaining_complete_shap_checkpoints":19,
  "new_fits":counts["fit"],"new_native_audits":counts["audit"],
  "first_typed_failure_does_not_cancel_other_mi":True,
  "resume_skips_19_complete_shap":True,"pool":counts["pools"],
  "scope":"native model leaves/upstream proof/pool/typed SHAP leaf mocked; actual 20 MI input/model/numbers/checkpoint/batch readers"}
 (BASE/"result.json").write_text(json.dumps(result,indent=2))
 print(json.dumps(result,indent=2))
finally:mp.undo()
