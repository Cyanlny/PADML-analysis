"""H36 STOP Python transport audit: UNFITTED synthetic objects, no fitting."""
from pathlib import Path
import copy, json, shutil, sys, tempfile, types
REPO=Path('/Users/liuningyuan/Desktop/Result/Machine Learning/PADML_F45_REBUILD')
sys.path[:0]=[str(REPO),str(REPO/'tests')]
import pytest, numpy as np, torch, xgboost as xgb
from padml import f5, f2_kernel as k, f4_compact as compact
from padml.bundle import canonical_json_bytes as enc, sha256_file, sha256_bytes, ContractError
from test_a12_q_native import _q_numbers_python_unit, _unfitted_q_function
logs=[]
def note(x): logs.append(x);print(x,flush=True)
def put(p,v): p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(enc(v))
def pin(p): return {'sha256':sha256_file(p),'size_bytes':p.stat().st_size}
base=Path(tempfile.mkdtemp(prefix='padml-h36-python-audit-',dir='/tmp')).resolve()
note('SOURCE f5.py '+sha256_file(REPO/'padml/f5.py'));note('FIXTURE '+str(base))
try:
 for family in ['XGBOOST_COX','COXTIME_SET_A']:
  with pytest.MonkeyPatch.context() as mp:
   directory=base/family;directory.mkdir()
   task,loaded,policy=_q_numbers_python_unit((None,None,None,None,{}),directory,family,'FULL0')
   spec=task['spec'];spec.update(outcome='All_Cause_Death',time='Death_Followup_months',predictors=k.predictor_contract(REPO/'padml'))
   part=loaded['partition'];part['evaluation_ids_sha256']=k._sha(part['evaluation_ids'])
   ids=part['fit_ids']+part['evaluation_ids'];part['application_ids']=ids
   cov=directory/'cov';cov.mkdir()
   raw=('Patient_ID,Center,Age\n'+''.join(f'{p},{55 if i==4 else 36},{40+i}\n' for i,p in enumerate(ids))).encode()
   (cov/'imp01.csv').write_bytes(raw)
   part['covariates']={'input_dir':str(cov),'members':[{'name':'imp01.csv',**pin(cov/'imp01.csv')}],'data_identity':sha256_bytes(raw)}
   fit_path=directory/'fit.csv';fit_path.write_bytes(part['fit_response'].pop('private_bytes'));part['fit_response']['path']=str(fit_path)
   registered={**task['registered'],'partitions':[{n:v for n,v in part.items() if n!='evaluation_response'}],'diagnostic_partitions':[]}
   task['registered']=registered
   q=Path(spec['native_search_root']).parent;(q/'native').mkdir(parents=True)
   put(q/'input.json',{'kind':'PADML_F5_Q_INPUT_V1','spec':spec,'task':{}})
   counters={'unfitted_produce':0,'object_open':0}
   mp.setattr(k,'_load_python_registered_partition',lambda *args:copy.deepcopy(loaded))
   def synthetic(*args,**kwargs):
    counters['unfitted_produce']+=1
    return _unfitted_q_function(task,loaded,args[-1])
   mp.setattr(k,'_xgb_prediction_function_seal' if family=='XGBOOST_COX' else '_coxtime_prediction_function_seal',synthetic)
   class UnfittedBooster:
    def load_model(self,path):
     assert Path(path).read_bytes()==b'UNFITTED_XGB_FUNCTION';counters['object_open']+=1
    def predict(self,matrix,**kwargs):return np.asarray(matrix)[:,0]/100
   class UnfittedNet(torch.nn.Module):
    def __init__(self):
     super().__init__();self.UNFITTED=torch.nn.Linear(1,1,bias=False)
    def forward(self,x,t):return self.UNFITTED(x)/100
   if family=='XGBOOST_COX':
    mp.setattr(xgb,'Booster',UnfittedBooster);mp.setattr(xgb,'DMatrix',lambda matrix,**kwargs:matrix)
   else:
    mp.setattr(k,'_coxtime_seed',lambda *args:'cpu')
    def synthetic_model(*args):
     counters['object_open']+=1
     # Existing UNFITTED checkpoint holds a one-dimensional weight.
     net=UnfittedNet()
     original=net.load_state_dict
     def load(state,strict=True):return original({'UNFITTED.weight':state['UNFITTED.weight'].reshape(1,1)},strict=strict)
     net.load_state_dict=load
     return types.SimpleNamespace(net=net)
    mp.setattr(k,'_coxtime_model',synthetic_model)
   fn=k._run_python_stop_pair_pool_task;old_call=(task,part)
   job0={'function':fn.__name__,'task':old_call,'root':str(q),'work':str(directory/'first-work'),
    'task_id':task['task_id'],'native_units':[task['task_id']],'retained_bytes_per_task':16*1024**2}
   initial=f5._execute_and_verify_q_search_unit(job0)
   assert counters=={'unfitted_produce':1,'object_open':2}
   current=copy.deepcopy(old_call);current[0]['spec'].update(selection_horizon_months=36,trial_scoring={**k.load_science_authority()['science']['f2_model_development']['trial_scoring'],'ibs_grid_months':list(range(37)),'ibs_integration':'TRAPEZOID_DIVIDE_BY_36'})
   cache=directory/'cache';cache.mkdir();control={'cache':str(cache),'source_identity':'e'*64,'read_only':False}
   old_key=f5._current_q_key({'current_q':control},fn,old_call,include_stop_population=False)
   new_key=f5._current_q_key({'current_q':control},fn,current);assert old_key!=new_key
   donor=cache/'atoms'/old_key;shutil.copytree(q,donor);old_sha=sha256_file(donor/'input.json')
   scope=cache/'inputs'/old_sha;put(scope/'registered.json',registered);shutil.copyfile(donor/'input.json',scope/'input.json')
   desc={'key':old_key,'function':fn.__name__,'executor_source_identity':'e'*64,'q_input_sha256':old_sha,
    'task':{n:v for n,v in task.items() if n not in {'spec','registered','handoff_path'}},'native_units':initial['native_units'],
    'evaluation_mode':None,'handoff_name':'model'}
   put(donor/'producer.json',desc)
   ev=json.loads((donor/'native'/task['task_id']/'evaluation.json').read_bytes())
   row={'task_id':task['task_id'],'partition_id':task['partition_id'],'imputation':task['imputation']}
   row.update({'lock':ev['result']} if family=='XGBOOST_COX' else {'function_sha256':ev['function_sha256'],'curve':ev['result']})
   row['task_identity_sha256']=k._sha(row);put(donor/'values.json',row)
   audit={'values_sha256':sha256_file(donor/'values.json'),'native_units':initial['native_units']};put(donor/'audit.json',audit)
   receipt={'key':old_key,'native_units':initial['native_units'],'members':initial['members'],'values':pin(donor/'values.json'),'audit':audit};put(donor/'receipt.json',receipt)
   current_input={'kind':'PADML_F5_Q_INPUT_V1','spec':current[0]['spec'],'task':{}};input_sha=sha256_bytes(enc(current_input))
   scope=cache/'inputs'/input_sha;put(scope/'input.json',current_input);put(scope/'registered.json',registered);control['input_sha256']=input_sha
   job={'function':fn.__name__,'call':current,'key':new_key,'control':control}
   before={p.relative_to(donor).as_posix():p.read_bytes() for p in donor.rglob('*') if p.is_file()}
   found=f5._current_q_stop_source(job,fn);assert found and found['key']==old_key and found['new_model_fit_count']==0
   result=f5._current_q_atom_result(job)
   assert counters=={'unfitted_produce':1,'object_open':3}
   root=Path(result['root']);ev_path=root/'native/h36-stop-score/evaluation.json';new=json.loads(ev_path.read_bytes())
   assert new['binding']['scoring_ids']==[part['evaluation_ids'][1]]
   if family=='XGBOOST_COX': assert new['evaluated_path']['validation_n']==1
   else:assert len(new['value']['curve']['losses'])==300
   assert {p.relative_to(donor).as_posix():p.read_bytes() for p in donor.rglob('*') if p.is_file()}==before
   outer=directory/'complete-q';put(outer/'input.json',current_input);put(outer/'result.json',result['value']);(outer/'native').mkdir()
   state={'references':{'input.json':pin(outer/'input.json')}};f5._current_q_import(outer,result,state)
   compact._full_pipeline_q_numerical_members(outer,publish=True,transported_refs=state['references']);compact._full_pipeline_q_numerical_members(outer)
   def forbidden(*args,**kwargs):raise AssertionError('UNEXPECTED_FUNCTION_OPEN_ON_RESUME')
   mp.setattr(f5,'_q_search_unit_call',forbidden)
   assert f5._current_q_atom_result(job)['value']==result['value']
   for name in ['values.json','audit.json','receipt.json']:(root/name).unlink()
   assert f5._current_q_atom_result(job)['value']==result['value']
   note(f'PASS {family}: original sealed arrays/source + native handoff + real synthetic loss reducer -> H36 filtered rescore -> nested compact consumer; donor unchanged; receipt/evaluation-only resume; no new fit')
   for name in ['values.json','audit.json','receipt.json']:(root/name).unlink()
   bad=copy.deepcopy(new)
   if family=='XGBOOST_COX':bad['value']['lock']['selected_rounds']=999999
   else:bad['value']['curve']['losses'][0]=-1.0
   ev_path.write_bytes(enc(bad))
   try:f5._current_q_atom_result(job)
   except ContractError as exc:note(f'PASS {family}: corrupt saved result rejected {exc}')
   else:raise AssertionError('BAD_VALUE_ACCEPTED')
finally:
 Path('/tmp/padml_h36_stop_python_audit.stdout').write_text('\n'.join(logs)+'\n')
