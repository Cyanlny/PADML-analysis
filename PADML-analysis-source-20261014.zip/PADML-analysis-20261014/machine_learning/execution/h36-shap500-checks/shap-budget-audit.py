import copy, json, os, subprocess, sys, tempfile, hashlib
from pathlib import Path
from unittest.mock import patch
ROOT = Path("/Users/liuningyuan/Desktop/Result/Machine Learning/PADML_F45_REBUILD")
sys.path[:0] = [str(ROOT), str(ROOT/"tests")]
from padml import f5
from padml.bundle import ContractError
BASE = Path(tempfile.mkdtemp(prefix="padml-shap-round2-")).resolve()
R = BASE/"diagnostic.R"
R.write_text(r'''
args <- commandArgs(TRUE)
source(args[[1]])
dir <- args[[2]]
family <- "XGBOOST_COX"; ids <- c("p1", "p2")
selected <- paste0("x",1:9); data <- as.data.frame(matrix(0,2,9)); colnames(data) <- selected
count <- 0L; mode <- "budget"
kernelshap <- function(object,X,...) {
  count <<- count + 1L
  n <- nrow(X); names <- c("t6","t12","t24","t36")
  beta <- matrix(rep(c(-0.04,0.04,rep(0,7)),n), nrow=n, byrow=TRUE)
  out <- list(S=setNames(rep(list(beta),4),names),baseline=rep(0.5,4),
    predictions=matrix(0.5,n,4),algorithm="kernelshap",
    SE=setNames(rep(list(matrix(if(mode=="budget") 0.002 else 0,n,9)),4),names),
    converged=rep(mode!="budget",n),n_iter=rep(if(mode=="budget") 500L else 2L,n))
  class(out) <- "kernelshap"; out
}
need <- function(x,why) if(!isTRUE(x)) stop(why,call.=FALSE)
call <- function(d) padml_kernelshap_component(family,1L,paste(rep("a",64),collapse=""),
  selected,ids,data,function(x) matrix(0.5,nrow(x),4),780000001L,need,d,as.raw(c(1,2,3)))
for (name in c("budget","raw-success")) dir.create(file.path(dir,name))
tryCatch(call(file.path(dir,"budget")),error=function(e) cat(conditionMessage(e),"\n"))
first <- count
tryCatch(call(file.path(dir,"budget")),error=function(e) cat(conditionMessage(e),"\n"))
need(count==first, "RAW_BUDGET_RECOMPUTED")
mode <- "converged"
value <- kernelshap(NULL,data)
saveRDS(list(spec=as.raw(c(1,2,3)),result=value),file.path(dir,"raw-success","kernelshap-return.rds"))
before <- count
value <- call(file.path(dir,"raw-success"))
need(count==before+1L,"RAW_SUCCESS_DID_NOT_ONLY_SENTINEL")
writeLines(jsonlite::toJSON(value,auto_unbox=TRUE,null="null",digits=NA),file.path(dir,"raw-success","shap.json"))
cat("budget_full_calls=",first," total_calls=",count," raw_success_sentinel_only=TRUE\n",sep="")
''')
r = subprocess.run(["/usr/local/bin/Rscript","--vanilla",str(R),str(ROOT/"padml/kernels/f5_shap.R"),str(BASE)],capture_output=True,text=True)
(BASE/"r.stdout").write_text(r.stdout); (BASE/"r.stderr").write_text(r.stderr)
assert r.returncode==0,(r.stdout,r.stderr)
task={"family":"XGBOOST_COX","imputation":1,"selected_parents":[f"x{i}" for i in range(1,10)]}
prediction={"patient_ids":["p1","p2"],"survival":[[1.0]+[0.5]*36]*2}
checks = {}
try:f5._read_final_shap_diagnostic(BASE/"budget",task,prediction,"a"*64)
except f5._FinalShapBudgetExhausted as e: checks["budget"]=str(e)
else:raise AssertionError("budget incorrectly accepted")
v=f5._read_final_shap_diagnostic(BASE/"raw-success",task,prediction,"a"*64)
checks["raw_success"]=v["status"]
source=BASE/"budget"/"kernelshap-diagnostic.json"
for case in ("iter499","source","SE"):
    q=BASE/case;q.mkdir(); d=json.loads(source.read_bytes())
    if case=="iter499":d["n_iter"][0]=499
    elif case=="source":d["model_sha256"]="b"*64
    else:d["SE"]["t6"][0][0]=-0.001
    (q/"kernelshap-diagnostic.json").write_text(json.dumps(d,ensure_ascii=False))
    try:f5._read_final_shap_diagnostic(q,task,prediction,"a"*64)
    except f5._FinalShapBudgetExhausted:raise AssertionError(case+": typed invalid")
    except ContractError as e:checks[case]=str(e)
    else:raise AssertionError(case+": invalid accepted")
checks["r_stdout"]=r.stdout
checks["sources"]={name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in ("padml/f5.py","padml/kernels/f5_shap.R")}
(BASE/"result.json").write_text(json.dumps(checks,indent=2))
print(json.dumps({"evidence":str(BASE),"checks":checks},indent=2))
