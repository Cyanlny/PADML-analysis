"""Exact same-run source qualification for the AAR completed-consumer repair; no clinical work."""
import ast, copy, io, json, os, tempfile, zipfile
from pathlib import Path
from unittest.mock import patch
from padml import f4, run as r, f5
from padml.bundle import ContractError, canonical_json_bytes as encode, sha256_bytes, sha256_file, strict_json_bytes

base=Path(__file__).resolve().parent
repo=base.parent
release=base/'release-aar-prefix/PADML_F45_REBUILD_20260926_ABCDE_AAR_PREFIX.zip'
assert sha256_file(release)=='5f17ced8933da47c0109e05be30160c8692f54d61ae286290a375d7594e3e707'
checks={}
with tempfile.TemporaryDirectory(prefix='padml-aar-tail-source-') as tmp:
 root=Path(tmp).resolve()
 with zipfile.ZipFile(release) as z:
  for name in z.namelist():
   if name in ('run.json','source.zip') or name.endswith(('/run.json','/source.zip')):
    p=root/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z.read(name))
 original=strict_json_bytes((root/'run.json').read_bytes())
 remote=original['run_root']
 def local_path(value):
  value=str(value)
  return Path(str(root)+value[len(remote):]) if value.startswith(remote+'/') else Path(value)
 value={**original,'source_identity':sha256_bytes(encode(f4._f45_source_member_sha256())),
  'source_bundle_sha256':'d'*64,
  'unit_predecessor':{'run_path':str(root/'run.json'),'run_sha256':sha256_file(root/'run.json'),
   'source_path':str(root/'source.zip'),'source_sha256':sha256_file(root/'source.zip')}}
 value['identity']=sha256_bytes(encode({k:v for k,v in value.items() if k!='identity'}))
 (root/'current-run.json').write_bytes(encode(value))
 with patch.object(r,'Path',local_path),patch.object(f4,'Path',local_path):
  revisions=r.f45_unit_predecessors(value)
  assert [x['identity'] for x in revisions]==[
   '4fd95eb512ba20a925ba3ee6146e6640b3c144bc955fdb5d20d6b4b2e1e684fb',
   '4c8cabe991a6e9d0eab29411522adae5db8bd6684e8d6e33b8e5e36205a29f7f',
   '9633db6d7a3ada9d1252bef53c35ae583b315034611a8d24216970d7dc3ec1c1',
   '1a5fba765d42f0a9b3f1ccd46690e689796b948e72216f25cccf72d6fdb0d955',
   '66c67b37bf25a365e95a8748927bea4782128f892d204735fef4c5cacd2c3e24',
   'edf9df2afa86dc8e2e38516bd94f821feba51485f26c590946f0ef3ab6994338',
   '2d7929461468f78347133b036f93fd1ea57c187777b74801b47015a8dcf78419',
   '096b856d4f3aedb609e7e15b8898144ec565f037db7ddf3e79e3957a0e64f723']
  checks['same_run_predecessors']=[x['identity'] for x in revisions]
  baseline=r.validate_f45_resource_revision(value)
  assert sha256_bytes(encode(baseline))=='25190343ea52b20014b6cb38eae518b4fe77621e02c8eb24a5b3f66fc5047c50'
  checks['original_numerical_baseline_unchanged']=True
  with patch.dict(os.environ,{'PADML_F45_RUN_PATH':str(root/'current-run.json')}):
   executors,sources=f5._f45_score_reuse_authorities()
  assert set(executors)=={value['identity'],*(x['identity'] for x in revisions)}
  aar=next(x for x in revisions if x['identity'].startswith('edf9df'))
  assert aar['source_identity'] in sources
  checks['original_aar_producer_qualified']=aar['source_identity']
  current=repo/'padml/f5_sensitivity.py'
  raw=current.read_bytes()
  real_read=Path.read_bytes
  before=b'and report_path.name == "execution.json"'
  assert raw.count(before)==1
  altered=raw.replace(before,b'and True',1)
  with patch.object(Path,'read_bytes',lambda path:altered if path==current else real_read(path)):
   for label,validator in [('predecessor',r.f45_unit_predecessors),('baseline',r.validate_f45_resource_revision)]:
    try:validator(value)
    except ContractError as exc:checks[label+'_unreviewed_body_rejected']=str(exc)
    else:raise AssertionError(label)
  damaged=copy.deepcopy(value);damaged['unit_predecessor']['source_sha256']='f'*64
  try:r.f45_unit_predecessors(damaged)
  except ContractError as exc:checks['unknown_source_pin_rejected']=str(exc)
  else:raise AssertionError('unknown source')
 assert (root/'run.json').read_bytes()==encode(original)
result={'source_identity':value['source_identity'],'checks':checks,'clinical_calls':0,'production_mutations':0}
(base/'aar-tail-sidecar-source-validation.json').write_bytes(encode(result))
print(json.dumps(result))

