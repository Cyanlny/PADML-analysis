import json,os,datetime,hashlib
from pathlib import Path
from collections import Counter
cfg=json.loads(CONFIG_LITERAL)
root=Path('/root/autodl-tmp/PADML_V22/f45-rebuild-20260925');unit=root/'units'/cfg['unit_id']
launch=json.loads((root/cfg['launch']).read_bytes())
assert launch['pid']==cfg['pid'] and launch['start_ticks']==cfg['start_ticks'],'LAUNCH_BINDING_MISMATCH'
def proc(pid):
 try:
  p=Path('/proc')/str(pid);s=(p/'stat').read_text().split(') ',1)[1].split()
  return {'pid':int(pid),'pgid':int(s[2]),'state':s[0],'start_ticks':int(s[19]),'cpu_ticks':int(s[11])+int(s[12]),'rss_bytes':int(s[21])*os.sysconf('SC_PAGE_SIZE'),'command':(p/'cmdline').read_bytes().replace(bytes([0]),b' ').decode(errors='replace')}
 except (FileNotFoundError,ProcessLookupError):return None
raw=(root/'active.lock').read_bytes();rows=[json.loads(x) for x in raw.splitlines() if x.strip()]
groups={int(x['pgid']) for x in rows}|{cfg['pid']};members=[]
for p in Path('/proc').iterdir():
 if p.name.isdigit():
  x=proc(int(p.name))
  if x and x['state']!='Z' and x['pgid'] in groups:members.append(x)
owner=proc(cfg['pid'])
if owner and owner['state']=='Z':owner=None
logs={}
for label in ('stdout','stderr'):
 p=Path(launch[label]);st=p.stat();offset=int(cfg.get(label+'_bytes',0))
 v={'path':str(p),'size_bytes':st.st_size,'mtime_ns':str(st.st_mtime_ns)}
 if st.st_size>offset:
  with p.open('rb') as f:
   f.seek(max(offset,st.st_size-2200));v['new_tail']=f.read(2200).decode(errors='replace');v['read_from_offset']=f.tell()-len(v['new_tail'].encode())
  if label=='stderr' and st.st_size-offset<=262144:
   with p.open('rb') as f:f.seek(offset);s=f.read(st.st_size-offset).decode(errors='replace')
   v['delta_warning_audit']={'delta_bytes':st.st_size-offset,'syntax_warnings':s.count('SyntaxWarning:'),'error_markers':[t for t in ['Traceback (most recent call last)','Error:','F5_','No space left','Killed'] if t in s]}
 logs[label]=v
files={}
for n in ('unit.json','unit.zip','result.zip'):
 p=unit/n
 if p.exists():
  st=p.stat();files[n]={'size_bytes':st.st_size,'mtime_ns':str(st.st_mtime_ns)}
c=cfg['cursor'];seen=set(c.get('already_read_paths',[]))
ns=c.get('next_report_mtime_ns')
if ns is None:ns=int(datetime.datetime.fromisoformat(c['next_report_mtime_after'].replace('Z','+00:00')).timestamp()*1e9)
new=[]
for p in (unit/'resource-release').glob(str(cfg['pid'])+'-*.json'):
 st=p.stat()
 if str(p) not in seen and st.st_mtime_ns>=int(ns):new.append({'path':str(p),'size_bytes':st.st_size,'mtime_ns':str(st.st_mtime_ns)})
new.sort(key=lambda x:int(x['mtime_ns']))
for row in new[:64]:
 # New cumulative reports are bounded; historical multi-GB detail is never
 # loaded by a heartbeat merely to obtain an operational cache summary.
 if row['size_bytes']<=65536:
  try:
   report=json.loads(Path(row['path']).read_bytes());summary=report.get('cumulative')
   if isinstance(summary,dict):
    row['cumulative_summary']={k:summary[k] for k in ('scope','status','global_cache','attempted_files','attempted_bytes','advised_files','advised_bytes','failed_files','skipped_files','unsupported_files','duplicate_files','error_counts','errors_omitted','claim') if k in summary}
    row['cumulative_summary']['diagnostic_error']=report.get('error')
  except (OSError,ValueError) as error:row['summary_read_error']=str(error)[:512]
run=json.loads((root/'run.json').read_bytes())
print(json.dumps({'host':cfg['host'],'unit_id':cfg['unit_id'],'time_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'owner':owner,'owner_identity_matches':bool(owner and owner['start_ticks']==cfg['start_ticks']),'lock_owner':rows[0] if rows else None,'lock_sha256':hashlib.sha256(raw).hexdigest(),'registered_groups':len(groups),'live_registered_members':len(members),'spawn_workers':sum('spawn_main' in x['command'] for x in members),'live_processes':members,'process_states':dict(Counter(x['state'] for x in members)),'logs':logs,'unit_files':files,'new_native_reports':new[:64],'additional_new_report_count':max(0,len(new)-64),'disk_free_bytes':os.statvfs(root).f_bavail*os.statvfs(root).f_frsize,'run_identity':run['identity'],'source_identity':run['source_identity']}))
