"""Qualify the exact H36 AAR consumer correction; no clinical execution."""
import copy, json, os, tempfile, zipfile
from pathlib import Path
from unittest.mock import patch
from padml import f4, nested_loco as nested, run
from padml.bundle import ContractError, canonical_json_bytes as enc, sha256_bytes as sha, sha256_file

repo = Path(__file__).resolve().parents[2]
checks = Path(__file__).resolve().parent
previous = repo / 'execution/release-pilot-json-key/PADML_F45_REBUILD_20260929_PILOT_JSON_KEY.zip'
assert sha256_file(previous) == 'a1905aa6cfb2ae6682057d382456f92157bf8b9659e5a90a7c85480d8f3b7fd1'
current_members = f4._f45_source_member_sha256()
results = {}
with tempfile.TemporaryDirectory(prefix='aar-primary-selector-source-') as temporary:
    base = Path(temporary).resolve()
    with zipfile.ZipFile(previous) as archive:
        for name in archive.namelist():
            if name in ('run.json', 'source.zip') or name.endswith(('/run.json', '/source.zip')):
                target = base / name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(archive.read(name))
    with zipfile.ZipFile(base / 'source.zip') as source:
        old_members = {name: sha(source.read(name)) for name in f4.F45_SOURCE_MEMBERS}
    assert {name for name in current_members if current_members[name] != old_members[name]} == {
        'padml/f5_sensitivity.py', 'padml/run.py'}
    original = json.loads((base / 'run.json').read_bytes())
    value = {**original, 'source_identity': sha(enc(current_members)), 'source_bundle_sha256': 'd'*64,
        'unit_predecessor': {'run_path': str(base / 'run.json'), 'run_sha256': sha256_file(base / 'run.json'),
            'source_path': str(base / 'source.zip'), 'source_sha256': sha256_file(base / 'source.zip')}}
    value['identity'] = sha(enc({k: v for k, v in value.items() if k != 'identity'}))
    remote = original['run_root']
    def mapped(location):
        location = str(location)
        return Path(str(base) + location[len(remote):]) if location.startswith(remote + '/') else Path(location)
    with patch.object(run, 'Path', mapped), patch.object(f4, 'Path', mapped):
        predecessors = run.f45_unit_predecessors(value)
        prior = json.loads((repo / 'execution/patient-recovery-readback-checks/qualification.json').read_bytes())
        assert [p['identity'] for p in predecessors] == [original['identity'], *prior['checks']['predecessors']]
        assert len(predecessors) == 21
        baseline = run.validate_f45_resource_revision(value)
        assert sha(enc(baseline)) == '25190343ea52b20014b6cb38eae518b4fe77621e02c8eb24a5b3f66fc5047c50'
        results.update(predecessors=[p['identity'] for p in predecessors], original_baseline_qualified=True)
        current = repo / 'padml/f5_sensitivity.py'
        raw, actual_read = current.read_bytes(), Path.read_bytes
        before = b'and common_df > 0 and events >= minimum * common_df'
        assert raw.count(before) == 1
        altered = raw.replace(before, b'and common_df > 0 and events >= 0 * common_df')
        with patch.object(Path, 'read_bytes', lambda path: altered if path == current else actual_read(path)):
            for name, validator in [('predecessor', run.f45_unit_predecessors),
                                    ('baseline', run.validate_f45_resource_revision)]:
                try:
                    validator(value)
                except ContractError as error:
                    results[name + '_unknown_epv_edit_rejected'] = str(error)
                else:
                    raise AssertionError(name + ': unknown EPV edit accepted')
        damaged = copy.deepcopy(value)
        damaged['unit_predecessor']['source_sha256'] = 'f'*64
        try:
            run.f45_unit_predecessors(damaged)
        except ContractError as error:
            results['unknown_source_pin_rejected'] = str(error)
        else:
            raise AssertionError('unknown predecessor source')
    assert value['science_decision'] == original['science_decision']

evidence = repo / 'execution/step-cache-shap-checks/heartbeat-20260929T0158/H9-primary-selector-metadata.json'
observed = json.loads(evidence.read_bytes())['members']
lock = observed['o-fit-execution.json']['development_lock']
# This remote JSON projection is not the original canonical member bytes.
# Compare source identities/fields; original PRIMARY acceptance owns its seal.
development = observed['source/primary-selector/development-input.json']
assert lock['selector_evidence_sha256'] == development['identity_sha256'] == observed['o-fit-input.json']['selector_evidence_sha256']
assert lock['selected_parents'] == development['selector']['selected_parents']
assert lock['common_set_design_df'] == development['selector']['common_set_design_df']
assert lock['epv_resolution'] == development['selector']['epv_resolution']
assert lock['selection_horizon_months'] == 36 and lock['outer_fold'] == 6
old_selector = json.loads(evidence.read_bytes())['comparison_from_requested_members']['original_F2_selector']['selector_evidence_sha256']
assert old_selector != lock['selector_evidence_sha256']
results['real_h9_metadata'] = {'evidence_sha256': sha256_file(evidence), 'primary_selector': lock['selector_evidence_sha256'],
    'f2_selector': old_selector, 'family': lock['selected_family'], 'design_df': lock['common_set_design_df'],
    'events': lock['training_event_count'], 'epv_minimum': lock['epv_resolution']['minimum'],
    'projection_only_not_independent_full_archive_acceptance': True}
record = {'source_identity': sha(enc(current_members)), 'checks': results,
    'clinical_calls': 0, 'remote_operations': 0, 'science_decision_unchanged': True,
    'all_other_scientific_sources_unchanged': True}
(checks / 'qualification.json').write_bytes(enc(record))
print(json.dumps(record))
