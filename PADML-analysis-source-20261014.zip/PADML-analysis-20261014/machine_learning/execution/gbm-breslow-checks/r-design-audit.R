args <- commandArgs(trailingOnly = TRUE)
source(args[[1L]])
original <- padml_prepare_final_r_design
scalar <- function(value) unname(unlist(value, use.names = FALSE)[[1L]])
need <- function(ok, code) if (!isTRUE(ok)) stop(code, call. = FALSE)
# Probe only: transplant unchanged value-dependent expressions from the oracle.
# A production change should write the factory directly, not parse its own body.
make_builder <- function(selected, predictor_rows, transform, family, scalar, need) {
  expr <- as.list(body(original))
  fixed <- environment()
  for (i in c(2L, 3L, 4L, 6L, 7L, 8L)) eval(expr[[i]], envir = fixed)
  contracts <- setNames(lapply(selected, function(name) categorical_contract(rows[[name]])), selected)
  formulae <- setNames(lapply(selected, function(name) {
    if (is.null(contracts[[name]])) return(NULL)
    if (reference_coded) as.formula(sprintf("~ `%s`", name)) else as.formula(sprintf("~ `%s` - 1", name))
  }), selected)
  contrasts <- setNames(lapply(selected, function(name) {
    contract <- contracts[[name]]
    if (is.null(contract)) return(NULL)
    if (reference_coded) contr.treatment(contract$levels,
      base = match(contract$reference, contract$levels), contrasts = TRUE) else {
      value <- diag(length(contract$levels))
      dimnames(value) <- list(contract$levels, contract$levels)
      value
    }
  }), selected)
  rewrite <- function(node) {
    if (!is.call(node)) return(node)
    if (identical(node[[1L]], as.name("categorical_contract"))) return(quote(contracts[[name]]))
    if (identical(node[[1L]], as.name("<-")) && identical(node[[2L]], as.name("formula")))
      return(quote(formula <- formulae[[name]]))
    if (identical(node[[1L]], as.name("<-")) && identical(node[[2L]], as.name("contrast")))
      return(quote(contrast <- contrasts[[name]]))
    as.call(lapply(as.list(node), rewrite))
  }
  result <- function(covariates) NULL
  body(result) <- as.call(c(list(as.name("{")), lapply(expr[c(5L, 9L, 10L, 11L, 12L, 13L)], rewrite)))
  environment(result) <- fixed
  result
}
selected <- c("AST_ALT", "年龄", "log value", "弯曲指标", "binary", "ordered", "分型")
rows <- list(
  list(name="AST_ALT", type="continuous", levels_or_coding=""),
  list(name="年龄", type="continuous", levels_or_coding=""),
  list(name="log value", type="continuous", levels_or_coding=""),
  list(name="弯曲指标", type="continuous", levels_or_coding=""),
  list(name="binary", type="binary", levels_or_coding="levels=0|1; reference=0"),
  list(name="ordered", type="ordered", levels_or_coding="levels=low|middle|high; reference=middle (ref)"),
  list(name="分型", type="unordered", levels_or_coding="levels=甲|乙|C+; reference=乙")
)
representation <- function(parent, kind, columns, parameters = list())
  list(parent=parent, representation=kind, design_columns=as.list(columns), parameters=parameters)
transform <- list(representations=list(
  representation("AST_ALT", "IDENTITY", "AST_ALT"),
  representation("年龄", "IDENTITY", "年龄"),
  representation("log value", "LOG1P", "log value_LOG1P"),
  representation("弯曲指标", "NATURAL_SPLINE_K3", c("弯曲1", "弯曲2"),
    list(boundary_knots=list(-3, 13), interior_knots=list(4)))
))
i <- seq_len(2124L)
data <- data.frame(Patient_ID = sprintf("S%04d", i), Center="SYNTHETIC", check.names=FALSE)
data$AST_ALT <- as.character(0.5 + (i %% 100)/10)
data$年龄 <- as.character(18 + (i %% 80))
data[["log value"]] <- as.character(i %% 80)
data[["弯曲指标"]] <- as.character((i %% 25) - 6)
data$binary <- as.character(i %% 2)
data$ordered <- c("low", "middle", "high")[(i %% 3) + 1L]
data$分型 <- c("甲", "乙", "C+")[(i %% 3) + 1L]
rownames(data) <- paste0("row", i)
bytes <- function(value) serialize(value, NULL, version=2L)
checked <- 0L
rejected <- 0L
family_builders <- list()
for (family in c("COX_PH", "ELASTIC_NET_COX", "RSF", "GBM_COX", "FPM_TVC_SET_A")) {
  recipe <- if (family %in% c("RSF", "GBM_COX")) NULL else transform
  builder <- make_builder(selected, rows, recipe, family, scalar, need)
  oracle <- function(d) original(d, selected, rows, recipe, family, scalar, need)
  family_builders[[family]] <- builder
  for (indices in list(1L, c(9L, 2L, 12L, 1L, 2124L, 30L, 1L), 1:2000, 2001:2124)) {
    block <- data[indices, , drop=FALSE]
    before <- bytes(block)
    expected <- oracle(block)
    actual <- builder(block)
    stopifnot(identical(bytes(actual), bytes(expected)), identical(bytes(block), before))
    masked <- expected$covariates[, selected, drop=FALSE]
    masked[["binary"]] <- rev(masked[["binary"]])
    masked[["log value"]] <- rev(masked[["log value"]])
    stopifnot(identical(bytes(builder(masked)), bytes(oracle(masked))))
    checked <- checked + 2L
  }
  changes <- list(
    numeric_na=function(d) {d$年龄[1] <- NA; d},
    numeric_inf=function(d) {d$年龄[1] <- "Inf"; d},
    numeric_nan=function(d) {d$年龄[1] <- "NaN"; d},
    numeric_bad=function(d) {d$年龄[1] <- "bad"; d},
    factor_na=function(d) {d$binary[1] <- NA; d},
    factor_bad=function(d) {d$binary[1] <- "unseen"; d},
    missing_numeric=function(d) {d$年龄 <- NULL; d},
    missing_factor=function(d) {d$binary <- NULL; d})
  if (!family %in% c("RSF", "GBM_COX")) changes$log_negative <- function(d) {d[["log value"]][1] <- "-1"; d}
  for (change in changes) {
    bad <- change(data[1:7, , drop=FALSE])
    error <- function(f) tryCatch({f(bad); "NO_ERROR"}, error=function(e) conditionMessage(e))
    old_error <- error(oracle)
    stopifnot(old_error != "NO_ERROR", identical(error(builder), old_error))
    rejected <- rejected + 1L
  }
  block <- data[1:2000, , drop=FALSE]
  invisible(oracle(block)); invisible(builder(block))
  iterations <- 150L
  old_time <- system.time(for (k in seq_len(iterations)) invisible(oracle(block)))[["elapsed"]]
  new_time <- system.time(for (k in seq_len(iterations)) invisible(builder(block)))[["elapsed"]]
  cat(sprintf("TIMING %s n=2000 iterations=%d original=%.3fs cached=%.3fs speedup=%.3f\n", family, iterations, old_time, new_time, old_time/new_time))
}
# Original horizon expressions remain unchanged; only evaluated once per model.
horizons <- c(6,12,24,36)
times <- c(1,6,6,7,12,18,24,24,35,36,40)
hazard <- c(0,.01,.02,.03,.04,.08,.1,.11,.18,.2,.25)
lookup <- function() vapply(horizons, function(value) {
  positions <- which(times <= value)
  if (!length(positions)) 0 else hazard[max(positions)]
}, numeric(1))
cumulative <- lookup()
risk <- exp(seq(-4,4,length.out=2124L))
stopifnot(identical(bytes(exp(-outer(risk, lookup()))), bytes(exp(-outer(risk, cumulative)))))
death <- c(7,12,20,24,30,36,40)
positions <- vapply(horizons, function(h) max(which(death <= h), 0L), integer(1))
for (n in c(1L,7L,2000L,124L)) {
  native <- matrix(seq_len(n*length(death))/(n*length(death)), nrow=n)
  old <- matrix(1,n,length(horizons))
  new <- old
  for (j in seq_along(horizons)) {
    index <- max(which(death <= horizons[[j]]), 0L)
    if (index > 0L) old[,j] <- native[,index]
    if (positions[[j]] > 0L) new[,j] <- native[,positions[[j]]]
  }
  stopifnot(identical(bytes(old),bytes(new)))
}
cat(sprintf("PASS design_serialized_bytes=%d rejection_messages=%d original_input_unchanged=TRUE risk_four_horizon_bytes=TRUE rsf_horizon_selection_bytes=TRUE\n", checked,rejected))
cat("BOUNDARY no_native_models_no_predictors_no_SHAP_no_fits; R=", as.character(getRversion()), " platform=", R.version$platform, "\n", sep="")
