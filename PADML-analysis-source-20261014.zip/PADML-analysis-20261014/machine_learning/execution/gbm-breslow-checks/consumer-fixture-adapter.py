"""Only repair the stale synthetic science fixture; keep original production validators/tests."""
import contextlib, hashlib, io, json, os, sys
from pathlib import Path

REPO=Path('/Users/liuningyuan/Desktop/Result/Machine Learning/PADML_F45_REBUILD')
BASE=Path('/private/tmp/padml-gbm-hotspot-n449ajs4')
PIN='4fa1816aac04a98b7088add56fb24fba2151632bcb05f96a5d369ba57fcb8f76'
sys.path[:0]=[str(REPO),str(REPO/'tests')]
os.chdir(REPO)
assert hashlib.sha256((REPO/'padml/f2_kernel.py').read_bytes()).hexdigest()==PIN
import pytest
from padml import nested_loco as nested
import test_nested_aar_mice as fixture_module

nodes=['tests/test_a12_q_native.py::test_gbm_complete_losses_pair_and_pinned_original_numbers',
       'tests/test_a12_q_native.py::test_gbm_first_audit_rejects_same_lock_but_changed_late_loss']
original=fixture_module._unfitted_confirmed_decision
fixture_module._unfitted_confirmed_decision=lambda **kwargs:nested.science_decision_template(24)
out=io.StringIO()
try:
    with contextlib.redirect_stdout(out),contextlib.redirect_stderr(out):
        code=pytest.main(['-q','-p','no:cacheprovider','--basetemp='+str(BASE/'pytest-adapted'),*nodes])
finally:
    fixture_module._unfitted_confirmed_decision=original
assert hashlib.sha256((REPO/'padml/f2_kernel.py').read_bytes()).hexdigest()==PIN
(BASE/'consumer-pytest.stdout').write_text(out.getvalue())
report={'phase':'ORIGINAL_CONSUMER_TESTS_AFTER_ISOLATED_FIXTURE_SETUP_REPAIR',
    'kernel_sha256':PIN,'python':sys.version,'script':str(Path(__file__)),
    'fixture_adapter':'test_nested_aar_mice._unfitted_confirmed_decision -> nested.science_decision_template(24)',
    'reason':'Original helper overwrites current exact science with obsolete bootstrap/fit-budget values before the kernel is reached.',
    'production_validators_modified':False,'repository_modified':False,'native_fit_performed':False,
    'nodes':nodes,'expected_parameterized_cases':3,'pytest_exit_code':int(code),
    'stdout':str(BASE/'consumer-pytest.stdout'),'h36_repeated':False}
(BASE/'consumer-tests.json').write_text(json.dumps(report,indent=2))
print(out.getvalue());print(json.dumps(report,indent=2))
raise SystemExit(code)
