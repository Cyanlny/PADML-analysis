"""Synthetic current loss-reader timing; no glmnet/native model and no fit."""
import json, statistics, sys, time
from pathlib import Path
REPO=Path('/Users/liuningyuan/Desktop/Result/Machine Learning/PADML_F45_REBUILD')
BASE=Path(sys.argv[1])
sys.path.insert(0,str(REPO))
from padml import f2_kernel as k
from padml.bundle import canonical_json_bytes as enc, sha256_bytes
raw=json.loads(Path('/private/tmp/padml-gbm-hotspot-n449ajs4/benchmark-input.json').read_bytes())
fit_n,eval_n=raw['fit_n'],raw['evaluation_n'];total=fit_n+eval_n
columns=150
fit_ids=[f'SYNTH-F{i:04d}' for i in range(fit_n)]
eval_ids=[f'SYNTH-V{i:04d}' for i in range(eval_n)]
eta=[[raw['eta_by_column'][j%len(raw['eta_by_column'])][i] for j in range(columns)] for i in range(total)]
def response(ids,times,events):
    csv=('Patient_ID,All_Cause_Death,Death_Followup_months\n'+''.join(
        f'{pid},{event},{t}\n' for pid,event,t in zip(ids,events,times,strict=True))).encode()
    return {'private_bytes':csv,'sha256':sha256_bytes(csv),'size_bytes':len(csv),'row_count':len(ids),'row_ids_sha256':k._sha(ids)}
fit=response(fit_ids,raw['times'][:fit_n],raw['events'][:fit_n]);evaluation=response(eval_ids,raw['times'][fit_n:],raw['events'][fit_n:])
sealed=k._seal_cox_risk_curve(fit_ids,eval_ids,eta[:fit_n],eta[fit_n:],columns)
context=k._grouped_cox_evaluation_context(fit,evaluation,fit_ids,eval_ids)
(BASE/'benchmark-150-input.json').write_bytes(enc({'kind':'SYNTHETIC_NO_FIT','response_fit':fit['private_bytes'].decode(),
    'response_evaluation':evaluation['private_bytes'].decode(),'sealed':sealed}))
loss_times=[];value=None
for _ in range(2):
    begin=time.perf_counter()
    current=k._grouped_cox_loss_path(sealed,fit_response=fit,evaluation_response=evaluation,evaluation_context=context)
    loss_times.append(time.perf_counter()-begin)
    assert value is None or enc(value)==enc(current)
    value=current
# Time only selecting already parsed records, matching the new phase branch.
records=[{'alpha':a,'mi_losses':value['losses']} for a in (.01,.1,.3,.5,.7,.9,1.0)]
begin=time.perf_counter()
for _ in range(10000):
    lookup={r['alpha']:r for r in records}
    selected={a:lookup[a] for a in (.01,.1,.3,.5,.7,.9,1.0)}
lookup_seconds=(time.perf_counter()-begin)/10000
assert all(enc(row['mi_losses'])==enc(value['losses']) for row in selected.values())
report={'python':sys.version,'kernel_sha256':sha256_bytes(Path(k.__file__).read_bytes()),
    'fit_n':fit_n,'evaluation_n':eval_n,'events':sum(raw['events']),'lambda_count':columns,
    'current_grouped_loss_150_seconds':loss_times,'median_seconds':statistics.median(loss_times),
    'select_already_parsed_seven_alpha_records_seconds':lookup_seconds,
    'losses_sha256':sha256_bytes(enc(value['losses'])),'loss_count':len(value['losses']),
    'risksets_and_seal_prebuilt':True,'scope':'Actual grouped loss reader on synthetic finite eta; no native fitting. Native pin/JSON reads and remaining whole EPV/lambda/parameter reducers excluded from microbenchmark. No end-to-end production speed claim.'}
(BASE/'benchmark-150-result.json').write_text(json.dumps(report,indent=2))
(BASE/'benchmark-150-losses.json').write_bytes(enc(value))
print(json.dumps(report,indent=2))
