import os
for k in ('OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'NUMEXPR_NUM_THREADS'):
    os.environ[k] = '1'
import sys, json, math, hashlib, time, statistics, platform, contextlib
from pathlib import Path
import numpy as np
import torch
import torchtuples as tt
from pycox import models
ROOT=Path('/Users/liuningyuan/Desktop/Result/Machine Learning/PADML_F45_REBUILD')
sys.path.insert(0,str(ROOT))
from padml import f2_kernel as k
OUT=Path('/tmp/padml-python-hotpath-20260928')

def forbid_fit(*args,**kwargs):
    raise AssertionError('NO FIT IS AUTHORIZED IN THIS ENGINEERING CHECK')
tt.Model.fit=forbid_fit
candidate=json.loads((ROOT/'padml/science/authority.json').read_text())['science']['f2_model_development']['coxtime']['candidates'][6]
device=k._coxtime_seed(torch,91827,'CPU')
model=k._coxtime_model((models,torch,tt),candidate,13,None,300,device)
rng=np.random.RandomState(73061)
N=17
X=[torch.from_numpy(rng.normal(size=(N,13)).astype('float32')) for _ in range(26)]
T=torch.from_numpy(rng.normal(size=(N,1)).astype('float32'))

def original_scores():
    model.net.eval()
    with torch.no_grad():
        return [model.net(x,T) for x in X]

def batch_scores():
    model.net.eval()
    with torch.no_grad():
        return list(model.net(torch.cat(X,dim=0),torch.cat([T]*26,dim=0)).split(N))

def original_loss(scores):
    g_case=scores[0]
    values=[]
    for repeat in range(5):
        control_sum=torch.zeros_like(g_case)
        shrink_control=torch.zeros(())
        for j in range(5):
            g_control=scores[1+repeat*5+j]
            difference=g_control-g_case
            shrink_control=shrink_control+g_control.abs().mean()
            control_sum=control_sum+torch.exp(torch.clamp(difference,-3e38,80.0))
        loss=torch.log1p(control_sum).mean()
        shrink=float(candidate['coxtime_shrink'])
        if shrink:
            loss=loss+(shrink*(g_case.abs().mean()+shrink_control)/5).abs()
        values.append(float(loss.detach().cpu()))
    return math.fsum(values)/5

a,b=original_scores(),batch_scores()
aa=torch.cat(a).numpy();bb=torch.cat(b).numpy()
result={'scope':'LOCAL CPU1 UNFITTED SYNTHETIC FORWARD ONLY; NO CLINICAL DATA OR FIT; NO LINUX CLAIM',
        'python':sys.version,'platform':platform.platform(),
        'versions':{'torch':torch.__version__,'numpy':np.__version__,'torchtuples':tt.__version__},
        'f2_kernel_sha256':hashlib.sha256((ROOT/'padml/f2_kernel.py').read_bytes()).hexdigest(),
        'candidate':candidate,'threads':[torch.get_num_threads(),torch.get_num_interop_threads()],
        'batching':{'case_n':N,'input_width':13,'original_calls':26,'candidate_calls':1,
                    'raw_bytes_equal':aa.tobytes()==bb.tobytes(),
                    'different_elements':int(np.count_nonzero(aa.view('uint32')!=bb.view('uint32'))),
                    'maximum_abs_difference':float(np.max(np.abs(aa-bb))),
                    'original_loss_hex':original_loss(a).hex(),'batched_loss_hex':original_loss(b).hex()}}

def median_seconds(function,repetitions=5):
    timings=[]
    for _ in range(repetitions):
        start=time.perf_counter();function();timings.append(time.perf_counter()-start)
    return statistics.median(timings)
result['batching']['original_seconds']=median_seconds(original_scores)
result['batching']['batched_seconds']=median_seconds(batch_scores)

# Original baseline and wrapper-only alternative, exact same event risk sets/batch8224.
# Candidate lives only on this synthetic instance; no repository edit.
NB=640
inputs=rng.normal(size=(NB,13)).astype('float32')
durations=np.repeat(np.arange(1,65,dtype='float32'),10)
events=np.array([1,0,0,1,0,1,0,0,0,1]*64,dtype='float32')
native_predict=model.predict

def direct_predict(input,batch_size=8224,numpy=True,eval_=True,**kwargs):
    assert batch_size==8224 and numpy is True and eval_ is True and kwargs=={'num_workers':0}
    features,time_values=input
    features=torch.from_numpy(features)
    time_values=torch.from_numpy(time_values)
    model.net.eval()
    with torch.set_grad_enabled(False):
        values=[model.net(features[start:start+batch_size],time_values[start:start+batch_size])
                for start in range(0,len(features),batch_size)]
    model.net.train()
    return torch.cat(values,dim=0).cpu().numpy()

def run_baseline(predict):
    model.predict=predict
    return k._coxtime_complete_baseline(model,inputs,(durations,events),np)
try:
    original_baseline,old_health=run_baseline(native_predict)
    direct_baseline,new_health=run_baseline(direct_predict)
    original_time=median_seconds(lambda:run_baseline(native_predict),3)
    direct_time=median_seconds(lambda:run_baseline(direct_predict),3)
    result['baseline_wrapper']={'n':NB,'event_groups':old_health['event_time_groups'],
                               'checked_raw_scores':old_health['checked_raw_scores'],
                               'raw_baseline_bytes_equal':original_baseline.to_numpy().tobytes()==direct_baseline.to_numpy().tobytes(),
                               'index_bytes_equal':original_baseline.index.to_numpy().tobytes()==direct_baseline.index.to_numpy().tobytes(),
                               'health_equal':old_health==new_health,
                               'original_seconds':original_time,'direct_seconds':direct_time,
                               'speedup':original_time/direct_time,
                               'scope_limit':'single untrained candidate, one CPU architecture; no full STOP curve or production baseline claim'}
finally:
    model.predict=native_predict
(OUT/'result.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps(result,indent=2,sort_keys=True))
