"""Equivalent numerical hot paths and AAR extraction boundary, using the existing compiler."""
import ast, io, json, os, subprocess, sys, zipfile
from pathlib import Path
from padml import f4
from padml.bundle import canonical_json_bytes as enc, sha256_bytes as sha, sha256_file, write_deterministic_zip

assert sys.version_info[:2] == (3, 12)
repo = Path(__file__).resolve().parents[2]
base, checks = repo / 'execution', Path(__file__).resolve().parent
previous = base / 'release-aar-reader-admission/PADML_F45_REBUILD_20260928_AAR_READER_ADMISSION.zip'
assert sha256_file(previous) == 'e1016df444f1c515c6cb119cf9ac64eae4491cd89fc2eb4ecc138fbf2485e8c0'
pins = f4._f45_source_member_sha256()
identity = sha(enc(pins))
qualification = json.loads((checks / 'qualification.json').read_bytes())
tests = json.loads((checks / 'focused-tests.json').read_bytes())
assert qualification['source_identity'] == identity
assert len(qualification['checks']['predecessors']) == 16
assert tests['aar_boundary_cases_passed'] == 7 and tests['aar_boundary_exit_code'] == 0
assert tests['aar_reader_function_ast_sha256'] == '8f6dc3342eb9dad77b98cfa4f2c9cfaaeda8f3e3802c631a3c970a600ebd9231'
reader = next(n for n in ast.parse((repo / 'padml/f5_sensitivity.py').read_bytes()).body
    if isinstance(n, ast.FunctionDef) and n.name == '_load_a12_outer_archive')
assert sha(ast.dump(reader, include_attributes=False).encode()) == tests['aar_reader_function_ast_sha256']
linux = json.loads((checks / 'linux-result.json').read_bytes())
assert linux['status'] == 'PASS' and linux['candidate_kernel_sha256'] == pins['padml/f2_kernel.py']
assert len(linux['records']) == 2 and all(r['full_path_exact'] and r['original_lock_exact'] for r in linux['records'])
linux_exit = json.loads((checks / 'linux-exit.json').read_bytes())
assert linux_exit['exit_code'] == 0 and linux_exit['candidate.stderr']['size_bytes'] == 0
assert linux['actual_threads'] == linux['engine_threads'] == 1
assert linux_exit['linux-result.json']['sha256'] == sha256_file(checks / 'linux-result.json')
assert tests['runtime_sha256'] == pins['padml/runtime.py']
assert tests['test_sha256'] == sha256_file(repo / 'tests/test_f45_aar_cross_audit.py')
elastic = json.loads((checks / 'elastic-reuse-audit.json').read_bytes())
assert elastic['status'] == 'PASS'
assert elastic['source_pins']['f5_sensitivity.py'] == pins['padml/f5_sensitivity.py']
assert elastic['reuse']['old_full_result_sha256'] == elastic['reuse']['new_full_result_sha256']
assert elastic['reuse']['candidate_crossline_native_reads'] == 0
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
assert not subprocess.check_output(['git', 'diff', '--name-only', 'HEAD', '--', *f4.F45_SOURCE_MEMBERS], cwd=repo)
for name in f4.F45_SOURCE_MEMBERS:
    assert subprocess.check_output(['git', 'show', head + ':' + name], cwd=repo) == (repo / name).read_bytes()
with zipfile.ZipFile(previous) as archive:
    members = {name: archive.read(name) for name in archive.namelist() if name != 'release.json'}
    with zipfile.ZipFile(io.BytesIO(members['source.zip'])) as source:
        changed = [name for name in f4.F45_SOURCE_MEMBERS if source.read(name) != (repo / name).read_bytes()]
assert set(changed) == {'padml/f2_kernel.py', 'padml/f5_sensitivity.py', 'padml/run.py', 'AGENTS.md', 'NESTED_LOCO_PROTOCOL.md'}
out = base / 'release-equivalent-hotpaths'
out.mkdir()
compiled = f4.compile_f45_source_bundle(out / 'source.zip')
prefix = 'equivalent-hotpaths-predecessor'
members[prefix + '/run.json'] = members['run.json']
members[prefix + '/source.zip'] = members['source.zip']
old = json.loads(members['run.json'])
members['source.zip'] = (out / 'source.zip').read_bytes()
members['source.compile.json'] = enc(compiled)
run = {**old, 'source_identity': identity, 'source_bundle_sha256': compiled['sha256'],
    'unit_predecessor': {'run_path': old['run_root'] + '/' + prefix + '/run.json',
        'run_sha256': sha(members[prefix + '/run.json']),
        'source_path': old['run_root'] + '/' + prefix + '/source.zip',
        'source_sha256': sha(members[prefix + '/source.zip'])}}
run['identity'] = sha(enc({k: v for k, v in run.items() if k != 'identity'}))
assert run['units'] == old['units'] and len(run['units']) == 56
assert run['science_decision'] == old['science_decision']
members['run.json'] = enc(run)
evidence = {p.name: p for p in checks.iterdir() if p.is_file() and p.suffix in {'.py', '.json', '.R', '.log', '.stdout', '.stderr', '.txt'}}
evidence['tests/test_f45_aar_cross_audit.py'] = repo / 'tests/test_f45_aar_cross_audit.py'
write_deterministic_zip(out / 'equivalent-hotpaths-checks.zip', evidence)
members['equivalent-hotpaths-checks.zip'] = (out / 'equivalent-hotpaths-checks.zip').read_bytes()
members['HISTORICAL_AAR_READER_ADMISSION_COMPILE.md'] = members['COMPILE_REPORT.md']
for name in ('AGENTS.md', 'NESTED_LOCO_PROTOCOL.md'):
    members[name] = (repo / name).read_bytes()
report = (f'Frozen Git: {head}. Source: {identity}. Run: {run["identity"]}.\n\n'
    + (base / 'EQUIVALENT_HOTPATHS_COMPILE.md').read_text()).encode()
members['README.md'] = members['COMPILE_REPORT.md'] = report
members['EXECUTION_HANDOFF.md'] = report
summary = {'head': head, 'source_identity': identity, 'run_identity': run['identity'], 'source': compiled,
    'changed_source_members': changed, 'source_member_count': len(f4.F45_SOURCE_MEMBERS),
    'units': len(run['units']), 'predecessors': 16, 'focused_cases': 7,
    'retained_linux_coordinates': 1, 'retained_linux_population_paths': 2,
    'previous_package_sha256': sha256_file(previous), 'science_unchanged_from_previous_package': True,
    'qualification_sha256': sha256_file(checks / 'qualification.json'),
    'deployed': False, 'compiler_clinical_calls': 0, 'compiler_remote_operations': 0,
    'execution_owner_retained_path_check': True, 'clinical_completion_claimed': False}
members['compile-summary.json'] = enc(summary)
with zipfile.ZipFile(previous) as archive:
    for name in archive.namelist():
        if name in {'science-decision.json', 'dependencies.json',
                    'shared/bootstrap.zip', 'shared/bootstrap-preparation.json', 'h36-shap500-checks.zip', 'aar-reader-admission-checks.zip'} \
                or name.endswith(('/run.json', '/source.zip')):
            assert members[name] == archive.read(name)
release = {'kind': 'PADML_F45_EQUIVALENT_HOTPATHS_RELEASE', 'head': head,
    'run_identity': run['identity'], 'source_identity': identity,
    'members': {name: {'sha256': sha(raw), 'size_bytes': len(raw)} for name, raw in members.items()}}
members['release.json'] = enc(release)
target = out / 'PADML_F45_REBUILD_20260928_EQUIVALENT_HOTPATHS.zip'
write_deterministic_zip(target, members)
completed = subprocess.run([sys.executable, '-B', str(checks / 'frozen-reader.py'), str(target)],
    cwd=repo, check=True, capture_output=True, text=True,
    env={**os.environ, 'PYTHONPATH': str(repo), 'PYTHONDONTWRITEBYTECODE': '1'})
(out / 'frozen-reader.log').write_text(completed.stdout)
summary.update(package=str(target), sha256=sha256_file(target), size_bytes=target.stat().st_size)
(out / 'compile-summary.json').write_bytes(enc(summary))
print(json.dumps(summary))
