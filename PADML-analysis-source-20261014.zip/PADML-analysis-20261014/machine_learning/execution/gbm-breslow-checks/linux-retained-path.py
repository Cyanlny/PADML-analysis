"""One retained GBM STOP path: original/candidate numerical consumers, no fitting."""
import gc, hashlib, importlib.util, json, os, resource, shutil, sys, time
from pathlib import Path

assert sys.platform == 'linux', 'Real numerical input is consumed only on the execution instance'
root = Path(__file__).resolve().parent
from padml.bundle import canonical_json_bytes as enc, sha256_file
from padml.runtime import observe_execution_resources, resource_admission

def module(name, filename, expected):
    path = root / filename
    assert sha256_file(path) == expected
    spec = importlib.util.spec_from_file_location('padml.' + name, path)
    value = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = value
    spec.loader.exec_module(value)
    return value

old = module('_breslow_original', 'original_f2_kernel.py',
    'e3d5663e41387c41a0a939b7c1d7570da5adba3ee365529d3085ab559c710062')
new = module('_breslow_candidate', 'candidate_f2_kernel.py',
    '4fa1816aac04a98b7088add56fb24fba2151632bcb05f96a5d369ba57fcb8f76')
inventory = json.loads((root / 'inventory.json').read_bytes())
atom = Path(inventory['verification']['root'])
task, = inventory['producer_and_paths']['coordinate']
members = {row['path']: row for row in inventory['verification']['members']}
batch = next(Path(p).parent for p in members if p.endswith('/risk-001-gbm-fit.bin'))
read_pins = {}
material_root = Path(sys.argv[1]).resolve() if len(sys.argv) == 2 else None
production_root = Path('/root/autodl-tmp/PADML_V22/f45-rebuild-20260925')

def physical(path):
    return material_root / path.relative_to(production_root) if material_root else path

def read_pinned(path):
    row = members[str(path)]
    raw = physical(path).read_bytes()
    assert len(raw) == row['size_bytes'] and hashlib.sha256(raw).hexdigest() == row['declared_sha256']
    read_pins[str(path)] = row['declared_sha256']
    return json.loads(raw)

output = read_pinned(batch / 'output.json')
original = read_pinned(batch / 'evaluation.json')
h36 = read_pinned(atom / 'native/h36-stop-score/evaluation.json')
input_record = read_pinned(atom / 'input.json')
native_spec = read_pinned(batch / 'spec.json')
donor = batch.parent.parent
receipt = read_pinned(donor / 'receipt.json')
donor_input = read_pinned(donor / 'input.json')
row, = output['tasks']
assert row['task_id'] == task['task_id'] and row['partition_id'] == task['partition_id']
assert row['imputation'] == task['imputation'] == 4
assert row['risk_curve']['maximum'] == task['parameters']['max_trees'] == 5000
assert original['task_sha256'] == old._sha(task)
assert original['native_output']['sha256'] == read_pins[str(batch / 'output.json')]
assert h36['binding']['input_sha256'] == read_pins[str(atom / 'input.json')]
assert input_record['spec']['selection_horizon_months'] == 36
assert h36['binding']['source'] == inventory['producer_and_paths']['h36_binding_source']
assert h36['binding']['source']['receipt_sha256'] == read_pins[str(donor / 'receipt.json')]
assert h36['binding']['source']['input_sha256'] == read_pins[str(donor / 'input.json')]
assert native_spec['producer_tasks'] == [task]
for name in ('output.json', 'evaluation.json'):
    assert receipt['members']['native/' + batch.name + '/' + name]['sha256'] == read_pins[str(batch / name)]

def response(pin, ids):
    path = Path(pin['path'])
    raw = physical(path).read_bytes()
    assert len(raw) == pin['size_bytes'] and hashlib.sha256(raw).hexdigest() == pin['sha256']
    read_pins[str(path)] = pin['sha256']
    return dict(private_bytes=raw, sha256=pin['sha256'], size_bytes=len(raw),
        row_count=len(ids), row_ids_sha256=old._sha(ids))

fit_ids, evaluation_ids = row['fit_ids'], row['evaluation_ids']
fit = response(inventory['response_locations']['existing_response_candidates'][0], fit_ids)
evaluation = response(inventory['evaluation_response'], evaluation_ids)
assert fit['sha256'] == h36['binding']['fit_response_sha256'] == original['evaluated_path']['fit_response_sha256']
assert evaluation['sha256'] == h36['binding']['evaluation_response_sha256']
assert old._sha(evaluation_ids) == h36['binding']['evaluation_ids_sha256']
policy = dict(configured_worker_ceiling='EXECUTION_HOST_C_MINUS_8',
    memory_bytes_per_worker=2*1024**3, memory_reserve_bytes=2*1024**3,
    scratch_bytes_per_worker=128*1024**2, scratch_reserve_bytes=0,
    transfer_archive_worker_ceiling=1)
observation = observe_execution_resources(root)
admission = resource_admission(policy, observation, legal_tasks=1)
copies = root / 'disposable-risk-copies'
copies.mkdir()
channel = row['risk_curve']['risk_matrix_channel']
assert channel == inventory['producer_and_paths']['risk_curve']['risk_matrix_channel']
for role in ('fit', 'evaluation'):
    descriptor = channel[role]
    source = batch / descriptor['file_name']
    assert receipt['members']['native/' + batch.name + '/' + source.name] == {
        'sha256': descriptor['sha256'], 'size_bytes': descriptor['size_bytes']}
    assert physical(source).stat().st_size == descriptor['size_bytes']
    shutil.copyfile(physical(source), copies / source.name)
    read_pins[str(source)] = descriptor['sha256']
# This original reader validates hashes/shape/finite values and unlinks only
# its own disposable copies. The saved production matrices remain untouched.
fit_eta, evaluation_eta = old._consume_operation_local_risk_channel(channel, copies,
    expected_prefix='risk-001-gbm', fit_rows=len(fit_ids), evaluation_rows=len(evaluation_ids), columns=5000)
assert not list(copies.iterdir())
sealed = old._seal_cox_risk_curve(fit_ids, evaluation_ids, fit_eta, evaluation_eta, 5000)
del fit_eta, evaluation_eta
gc.collect()
assert sealed['sha256'] == original['evaluated_path']['risk_curve_sha256'] == h36['function_sha256']
selected_ids = h36['binding']['scoring_ids']
indices = [i for i, pid in enumerate(evaluation_ids) if pid in set(selected_ids)]
assert [evaluation_ids[i] for i in indices] == selected_ids
assert (len(fit_ids), len(evaluation_ids), len(indices)) == (1230, 218, 216)
records = []
for label, projection, saved_path, saved_lock in [
        ('original_population', None, original['evaluated_path'], original['result']),
        ('H36_excludes_55', indices, h36['evaluated_path'], h36['value'][0])]:
    context = old._grouped_cox_evaluation_context(fit, evaluation, fit_ids, evaluation_ids,
        evaluation_indices=projection)
    results, timings = {}, {}
    for tag, kernel in [('old', old), ('new', new)]:
        gc.collect()
        start = time.perf_counter()
        path = kernel._grouped_cox_loss_path(sealed, fit_response=fit,
            evaluation_response=evaluation, evaluation_context=context)
        timings[tag] = time.perf_counter() - start
        assert len(path['losses']) == 5000 and enc(path) == enc(saved_path), (label, tag, 'FULL_PATH_DRIFT')
        lock = kernel._tree_stopping_lock_from_losses(path['losses'], risk_curve_sha256=sealed['sha256'],
            fit_response_sha256=fit['sha256'], evaluation_response_sha256=evaluation['sha256'],
            minimum_improvement=task['parameters']['minimum_improvement'],
            patience=task['parameters']['early_stopping_patience'], family='GBM_COX')
        assert enc(lock) == enc({key: saved_lock[key] for key in lock}), (label, tag, 'LOCK_DRIFT')
        results[tag] = {'path_sha256': old._sha(path), 'lock': lock}
    assert results['old'] == results['new']
    record = dict(population=label, fit_n=len(fit_ids), validation_n=len(context['evaluation_times']),
        timings_seconds=timings, measured_speedup=timings['old']/timings['new'],
        full_path_exact=True, original_lock_exact=True, **results['new'])
    records.append(record)
    print(json.dumps(record), flush=True)

result = dict(status='PASS', coordinate=task['task_id'], candidate_kernel_sha256=sha256_file(root/'candidate_f2_kernel.py'),
    original_kernel_sha256=sha256_file(root/'original_f2_kernel.py'), python=sys.version,
    source_matrix_bytes=sum(channel[role]['size_bytes'] for role in ('fit','evaluation')),
    observation=observation, admission=admission, records=records,
    maximum_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
    actual_threads=len(list(Path('/proc/self/task').iterdir())), engine_threads=1,
    input_pins=read_pins, new_model_fits=0, mice=0, shap=0,
    production_files_written=0, scientific_unit_completion_claimed=False,
    scope='One retained GBM path, both original/H36 populations, original complete numerical consumers; timings exclude preparation')
(root/'linux-result.json').write_bytes(enc(result))
print(json.dumps(result), flush=True)
