"""Synthetic arithmetic-only audit. No clinical, native model or repository writes."""
import copy, hashlib, json, math, random, statistics, struct, sys, time
from pathlib import Path
sys.path.insert(0, '/Users/liuningyuan/Desktop/Result/Machine Learning/PADML_F45_REBUILD')
from padml import f2_kernel as k
from padml.bundle import canonical_json_bytes
original = k._cox_breslow_log_likelihood

def dense(times, events, eta, *, event_groups=None):
    k._require(len(times) == len(events) == len(eta) and times
        and all(math.isfinite(v) for v in eta), 'F2_COX_RISK_CURVE_EVALUATION_INVALID')
    value, cached_maximum, scaled = 0.0, None, None
    groups = k._cox_breslow_event_groups(times, events) if event_groups is None else event_groups
    for failures, at_risk in groups:
        k._require(failures and at_risk, 'F2_COX_RISK_CURVE_EVALUATION_INVALID')
        maximum_eta = max(eta[index] for index in at_risk)
        if maximum_eta != cached_maximum:
            scaled = [math.exp(v - maximum_eta) if v <= maximum_eta else 0.0 for v in eta]
            cached_maximum = maximum_eta
        log_risk = maximum_eta + math.log(math.fsum(scaled[index] for index in at_risk))
        value += math.fsum(eta[index] for index in failures) - len(failures) * log_risk
    k._require(math.isfinite(value), 'F2_COX_RISK_CURVE_EVALUATION_INVALID')
    return value

def lazy(times, events, eta, *, event_groups=None):
    k._require(len(times) == len(events) == len(eta) and times
        and all(math.isfinite(v) for v in eta), 'F2_COX_RISK_CURVE_EVALUATION_INVALID')
    value, cached_maximum, scaled = 0.0, None, None
    groups = k._cox_breslow_event_groups(times, events) if event_groups is None else event_groups
    for failures, at_risk in groups:
        k._require(failures and at_risk, 'F2_COX_RISK_CURVE_EVALUATION_INVALID')
        maximum_eta = max(eta[index] for index in at_risk)
        if maximum_eta != cached_maximum:
            scaled = {i: math.exp(eta[i] - maximum_eta) for i in at_risk}
            cached_maximum = maximum_eta
        try:
            total = math.fsum(scaled[index] for index in at_risk)
        except KeyError:
            for i in at_risk:
                if i not in scaled:
                    scaled[i] = math.exp(eta[i] - maximum_eta)
            total = math.fsum(scaled[index] for index in at_risk)
        log_risk = maximum_eta + math.log(total)
        value += math.fsum(eta[index] for index in failures) - len(failures) * log_risk
    k._require(math.isfinite(value), 'F2_COX_RISK_CURVE_EVALUATION_INVALID')
    return value

def delayed_dense(times, events, eta, *, event_groups=None):
    k._require(len(times) == len(events) == len(eta) and times
        and all(math.isfinite(v) for v in eta), 'F2_COX_RISK_CURVE_EVALUATION_INVALID')
    value, cached_maximum, scaled = 0.0, None, None
    groups = k._cox_breslow_event_groups(times, events) if event_groups is None else event_groups
    for failures, at_risk in groups:
        k._require(failures and at_risk, 'F2_COX_RISK_CURVE_EVALUATION_INVALID')
        maximum_eta = max(eta[index] for index in at_risk)
        if maximum_eta == cached_maximum:
            if scaled is None:
                scaled = [math.exp(v - maximum_eta) if v <= maximum_eta else 0.0 for v in eta]
            total = math.fsum(scaled[index] for index in at_risk)
        else:
            total = math.fsum(math.exp(eta[index] - maximum_eta) for index in at_risk)
            cached_maximum, scaled = maximum_eta, None
        log_risk = maximum_eta + math.log(total)
        value += math.fsum(eta[index] for index in failures) - len(failures) * log_risk
    k._require(math.isfinite(value), 'F2_COX_RISK_CURVE_EVALUATION_INVALID')
    return value

def delayed_dense_map(times, events, eta, *, event_groups=None):
    k._require(len(times) == len(events) == len(eta) and times
        and all(math.isfinite(v) for v in eta), 'F2_COX_RISK_CURVE_EVALUATION_INVALID')
    value, cached_maximum, scaled = 0.0, None, None
    groups = k._cox_breslow_event_groups(times, events) if event_groups is None else event_groups
    for failures, at_risk in groups:
        k._require(failures and at_risk, 'F2_COX_RISK_CURVE_EVALUATION_INVALID')
        maximum_eta = max(map(eta.__getitem__, at_risk))
        if maximum_eta == cached_maximum:
            if scaled is None:
                scaled = [math.exp(v - maximum_eta) if v <= maximum_eta else 0.0 for v in eta]
            total = math.fsum(map(scaled.__getitem__, at_risk))
        else:
            total = math.fsum(math.exp(eta[index] - maximum_eta) for index in at_risk)
            cached_maximum, scaled = maximum_eta, None
        log_risk = maximum_eta + math.log(total)
        value += math.fsum(map(eta.__getitem__, failures)) - len(failures) * log_risk
    k._require(math.isfinite(value), 'F2_COX_RISK_CURVE_EVALUATION_INVALID')
    return value

bits=lambda x:struct.pack('>d', x).hex()
rng=random.Random(20260928)
n=640
times=[float(1 + i % 160) for i in range(n)]; rng.shuffle(times)
events=[int(i%4==0) for i in range(n)]
groups=k._cox_breslow_event_groups(times,events)
variants={'original':original, 'dense':dense, 'lazy':lazy, 'delayed_dense':delayed_dense, 'delayed_dense_map':delayed_dense_map}
shapes={
    'leaf_ties': [[rng.randrange(-8,9)*0.125 for _ in range(n)] for _ in range(20)],
    'dense_scores': [[rng.gauss(0,2) for _ in range(n)] for _ in range(20)],
    'maximum_changes_every_group': [[-v + j*1e-4 for v in times] for j in range(20)]}
checks, timings={},{ }
for label, vectors in shapes.items():
    expected=[bits(original(times,events,v,event_groups=groups)) for v in vectors]
    for name, function in variants.items():
        assert [bits(function(times,events,v,event_groups=groups)) for v in vectors]==expected, (label,name)
    measures={}
    for name,function in variants.items():
        samples=[]
        for _ in range(5):
            start=time.perf_counter()
            for v in vectors:function(times,events,v,event_groups=groups)
            samples.append(time.perf_counter()-start)
        measures[name]=statistics.median(samples)
    timings[label]={**measures, 'dense_speedup':measures['original']/measures['dense'],
        'lazy_speedup':measures['original']/measures['lazy'], 'delayed_dense_speedup':measures['original']/measures['delayed_dense'], 'delayed_dense_map_speedup':measures['original']/measures['delayed_dense_map']}
    checks[label]='all 20 likelihood float64 byte sequences identical'

# Non-nested supplied risksets and extreme finite eta: no invalid exp(+large) work.
edge_times=[1.,2.,3.,4.,5.,6.]; edge_events=[1]*6
edge_eta=[1000., -1000., 0., -0., -700., -710.]
edge_groups=[([2],[2,3,4]),([3],[1,2,3,5]),([1],[1]),([0],[0])]
expected=bits(original(edge_times,edge_events,edge_eta,event_groups=edge_groups))
for name,function in variants.items():assert bits(function(edge_times,edge_events,edge_eta,event_groups=edge_groups))==expected,name
checks['non_nested_and_extreme']='byte identical; no overflow from values outside a riskset'

# Call actual complete grouped loss producer and actual STOP lock on synthetic curves.
fit_ids=[f'f{i}' for i in range(12)]; eval_ids=[f'e{i}' for i in range(9)]
fit_times=[float(1+i//2) for i in range(12)]; fit_events=[int(i%3!=0) for i in range(12)]
eval_times=[float(1+i//2) for i in range(9)]; eval_events=[int(i%3!=1) for i in range(9)]
indices=list(range(8)) # one validation row excluded; fit rows remain complete.
combined_times=fit_times+[eval_times[i] for i in indices]
combined_events=fit_events+[eval_events[i] for i in indices]
fit_response={'sha256':'a'*64}; evaluation_response={'sha256':'b'*64}
context={'fit_response_sha256':'a'*64,'evaluation_response_sha256':'b'*64,
 'fit_ids_sha256':k._sha(fit_ids),'evaluation_ids_sha256':k._sha(eval_ids),
 'fit_times':fit_times,'fit_events':fit_events,
 'evaluation_times':[eval_times[i] for i in indices], 'evaluation_events':[eval_events[i] for i in indices],
 'evaluation_indices':indices,
 'fit_event_groups':k._cox_breslow_event_groups(fit_times,fit_events),
 'combined_event_groups':k._cox_breslow_event_groups(combined_times,combined_events)}
for count,label in [(5000,'GBM_full_5000'),(150,'Elastic_full_150')]:
    fit_eta=[[math.sin((i+1)*(j+1)*.0007)*1.7 for j in range(count)] for i in range(12)]
    eval_eta=[[math.sin((i+2)*(j+1)*.0009)*1.7 for j in range(count)] for i in range(9)]
    sealed=k._seal_cox_risk_curve(fit_ids,eval_ids,fit_eta,eval_eta,count)
    outputs={}
    try:
        for name,function in variants.items():
            k._cox_breslow_log_likelihood=function
            path=k._grouped_cox_loss_path(sealed,fit_response=fit_response,
                evaluation_response=evaluation_response,evaluation_context=context)
            lock=k._tree_stopping_lock_from_losses(path['losses'],risk_curve_sha256=sealed['sha256'],
                fit_response_sha256='a'*64,evaluation_response_sha256='b'*64,
                minimum_improvement=1e-6,patience=50,family='GBM_COX')
            outputs[name]=canonical_json_bytes({'path':path,'lock':lock})
        assert all(value == outputs['original'] for value in outputs.values())
        checks[label]={'all_loss_and_stop_bytes_identical':True,
            'loss_count':count,'sha256':hashlib.sha256(outputs['original']).hexdigest()}
    finally:k._cox_breslow_log_likelihood=original

result={'checks':checks,'timings_seconds':timings,'python':sys.version,
 'source_f2_sha256':hashlib.sha256((Path(k.__file__)).read_bytes()).hexdigest(),
 'scope':'synthetic LL and existing grouped loss/STOP only; no native or clinical; local timing is not production benchmark'}
print(json.dumps(result,indent=2,sort_keys=True))
Path('/tmp/padml-gbm-exp-cache-audit-20260928/results.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
