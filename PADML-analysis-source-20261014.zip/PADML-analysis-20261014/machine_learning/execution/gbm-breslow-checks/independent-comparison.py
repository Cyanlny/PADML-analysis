"""Compare a proposed hot loop to the frozen 35ef61e oracle, without model fitting."""
import argparse, copy, cProfile, hashlib, importlib.util, json, math, pstats, statistics, sys, time, zipfile
from pathlib import Path

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--candidate-root',type=Path,default=Path('/Users/liuningyuan/Desktop/Result/Machine Learning/PADML_F45_REBUILD'))
parser.add_argument('--source-zip',type=Path,default=Path('/Users/liuningyuan/Desktop/Result/Machine Learning/PADML_F45_REBUILD/execution/release-h36-shap500/source.zip'))
parser.add_argument('--evidence-root',type=Path,default=Path('/private/tmp/padml-gbm-hotspot-n449ajs4'))
args=parser.parse_args()
REPO=args.candidate_root.resolve();BASE=args.evidence_root.resolve()
expected_candidate_sha256='4fa1816aac04a98b7088add56fb24fba2151632bcb05f96a5d369ba57fcb8f76'
assert hashlib.sha256((REPO/'padml/f2_kernel.py').read_bytes()).hexdigest()==expected_candidate_sha256
sys.path.insert(0,str(REPO))
from padml import f2_kernel as new
from padml.bundle import ContractError, canonical_json_bytes as enc, sha256_bytes
baseline=json.loads((BASE/'baseline.json').read_bytes())
oracle_path=BASE/'f2_kernel_35ef61e.py'
with zipfile.ZipFile(args.source_zip) as archive:
    oracle_raw=archive.read('padml/f2_kernel.py')
assert sha256_bytes(oracle_raw)==baseline['oracle_sha256']=='e3d5663e41387c41a0a939b7c1d7570da5adba3ee365529d3085ab559c710062'
if oracle_path.exists():assert oracle_path.read_bytes()==oracle_raw
else:oracle_path.write_bytes(oracle_raw)
spec=importlib.util.spec_from_file_location('padml._gbm_hotspot_oracle_35ef61e',oracle_path)
old=importlib.util.module_from_spec(spec);sys.modules[spec.name]=old;spec.loader.exec_module(old)
boundary=json.loads((BASE/'boundary-input-and-expected.json').read_bytes())
result={'oracle_commit':baseline['oracle_commit'],'oracle_sha256':baseline['oracle_sha256'],
    'oracle_source_zip':str(args.source_zip),'oracle_source_zip_sha256':sha256_bytes(args.source_zip.read_bytes()),
    'current_source_sha256':sha256_bytes((REPO/'padml/f2_kernel.py').read_bytes()),'checks':[]}

for case in boundary['scalar_cases']:
    args=(case['times'],case['events'],case['eta']); unchanged=copy.deepcopy(args)
    expected=old._cox_breslow_log_likelihood(*args)
    assert expected.hex()==case['expected'].hex()
    groups=old._cox_breslow_event_groups(args[0],args[1]); saved=copy.deepcopy(groups)
    for kwargs in ({},{'event_groups':groups}):
        actual=new._cox_breslow_log_likelihood(*args,**kwargs)
        assert actual.hex()==expected.hex(),(case['name'],expected.hex(),actual.hex())
    assert args==unchanged and groups==saved
    result['checks'].append(case['name']+':EXACT_HEX_UNMUTATED')
for bad in (math.nan,math.inf,-math.inf):
    errors=[]
    for module in (old,new):
        try:module._cox_breslow_log_likelihood([1.,2.],[1,1],[bad,0.])
        except ContractError as exc:errors.append(str(exc))
        else:raise AssertionError('Nonfinite eta accepted')
    assert errors[0]==errors[1]=='F2_COX_RISK_CURVE_EVALUATION_INVALID'
result['checks'].append('nonfinite_eta:ORIGINAL_ERROR')

def response(ids,times,events):
    raw=('Patient_ID,All_Cause_Death,Death_Followup_months\n'+''.join(
        f'{pid},{event},{t}\n' for pid,event,t in zip(ids,events,times,strict=True))).encode()
    return dict(private_bytes=raw,sha256=sha256_bytes(raw),size_bytes=len(raw),row_count=len(ids),row_ids_sha256=old._sha(ids))
fit=response(boundary['fit_ids'],boundary['fit_times'],boundary['fit_events'])
evaluation=response(boundary['evaluation_ids'],boundary['evaluation_times'],boundary['evaluation_events'])
class SyntheticBooster:
    def __init__(self):self.calls=[]
    def predict(self,matrix,*,output_margin,iteration_range):
        assert output_margin is True and iteration_range[0]==0
        self.calls.append([matrix,iteration_range[1]])
        eta=boundary['fit_eta'] if matrix=='fit' else boundary['evaluation_eta']
        return [row[iteration_range[1]-1] for row in eta]

for case in boundary['path_cases']:
    if case['name']=='ELASTIC_SHARED_PATH':continue
    context=old._grouped_cox_evaluation_context(fit,evaluation,boundary['fit_ids'],boundary['evaluation_ids'],
        evaluation_indices=case['indices'])
    kwargs=dict(fit_response=fit,evaluation_response=evaluation,evaluation_context=context)
    sealed=boundary['sealed'];family='GBM_COX'
    if case['name'].startswith('XGB'):
        family='XGBOOST_COX';sealed=boundary['xgb_sealed'];booster=SyntheticBooster()
        kwargs.update(runtime={'booster':booster,'fit_matrix':'fit','evaluation_matrix':'evaluation'},
            xgb_patience=3,minimum_improvement=1e-4)
    actual=new._grouped_cox_loss_path(sealed,**kwargs)
    assert enc(actual)==enc(case['expected']),case['name']
    lock=new._tree_stopping_lock_from_losses(actual['losses'],risk_curve_sha256=sealed['sha256'],
        fit_response_sha256=fit['sha256'],evaluation_response_sha256=evaluation['sha256'],
        minimum_improvement=1e-4,patience=3,family=family)
    assert enc(lock)==enc(case['expected_lock']),case['name']
    if family=='XGBOOST_COX':assert booster.calls==case['predict_calls']
    result['checks'].append(case['name']+':EXACT_PATH_AND_LOCK')

fit_eta=[[math.sin(i*.7)*.15+math.cos(j*.08+i*.1)*.04 for j in range(150)] for i in range(8)]
eval_eta=[[math.cos(i*.5)*.11+math.sin(j*.04+i*.3)*.03 for j in range(150)] for i in range(6)]
elastic=old._seal_cox_risk_curve(boundary['fit_ids'],boundary['evaluation_ids'],fit_eta,eval_eta,150)
context=old._grouped_cox_evaluation_context(fit,evaluation,boundary['fit_ids'],boundary['evaluation_ids'])
expected=old._grouped_cox_loss_path(elastic,fit_response=fit,evaluation_response=evaluation,evaluation_context=context)
actual=new._grouped_cox_loss_path(elastic,fit_response=fit,evaluation_response=evaluation,evaluation_context=context)
assert len(actual['losses'])==150 and enc(actual)==enc(expected)
(BASE/'elastic150-input-and-expected.json').write_bytes(enc({'sealed':elastic,'expected':expected}))
result['checks'].append('ELASTIC_150_COLUMN_SHARED_OWNER:EXACT_FULL_PATH')
without_events=response(boundary['evaluation_ids'],boundary['evaluation_times'],[0]*6)
for module in (old,new):
    context=module._grouped_cox_evaluation_context(fit,without_events,boundary['fit_ids'],boundary['evaluation_ids'])
    try:module._grouped_cox_loss_path(boundary['sealed'],fit_response=fit,evaluation_response=without_events,evaluation_context=context)
    except ContractError as exc:assert str(exc)=='F2_COX_RISK_CURVE_EVALUATION_INVALID'
    else:raise AssertionError('Grouped zero event validation accepted')
result['checks'].append('GROUPED_NO_VALIDATION_EVENT:ORIGINAL_ERROR')

fixture=json.loads((BASE/'benchmark-input.json').read_bytes())
fit_n=fixture['fit_n'];eval_n=fixture['evaluation_n'];times=fixture['times'];events=fixture['events'];etas=fixture['eta_by_column']
groups=old._cox_breslow_event_groups(times,events)
fit_groups=old._cox_breslow_event_groups(times[:fit_n],events[:fit_n])
def run(module):
    return [-2*(module._cox_breslow_log_likelihood(times,events,eta,event_groups=groups)
        -module._cox_breslow_log_likelihood(times[:fit_n],events[:fit_n],eta[:fit_n],event_groups=fit_groups))/eval_n
        for eta in etas]
timings={'old':[],'new':[]}
for attempt in range(3):
    for label,module in (('old',old),('new',new)) if attempt%2==0 else (('new',new),('old',old)):
        started=time.perf_counter();observed=run(module);timings[label].append(time.perf_counter()-started)
        assert [v.hex() for v in observed]==[v.hex() for v in baseline['original_losses']],label
prof=cProfile.Profile();prof.enable();run(new);prof.disable();prof.dump_stats(BASE/'new-prebuilt.prof')
stats=pstats.Stats(prof)
count=lambda name:sum(value[1] for key,value in stats.stats.items() if key[2]==name)
result.update(timings=timings,speedup=statistics.median(timings['old'])/statistics.median(timings['new']),
    new_math_exp_calls=count('<built-in method math.exp>'),new_max_calls=count('<built-in method builtins.max>'),
    profile_new_total_seconds=stats.total_tt,representative_24_column_losses_exact_hex=True,
    scope='Synthetic only; risksets prebuilt/excluded; frozen old oracle; actual production loss/lock consumer; no fit/native model/SSH')
(BASE/'comparison.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
