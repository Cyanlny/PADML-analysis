def main():
    """Bounded synthetic audit: qualified whole reuse; no native fitting or clinical data."""
    import ast, copy, hashlib, json, math, statistics, subprocess, sys, tempfile, time, traceback
    from pathlib import Path
    from types import SimpleNamespace
    REPO=Path('/Users/liuningyuan/Desktop/Result/Machine Learning/PADML_F45_REBUILD')
    BASE=Path(tempfile.mkdtemp(prefix='padml-elastic-reuse-audit-',dir='/tmp')).resolve()
    sys.path[:0]=[str(REPO),str(REPO/'tests')]
    import pytest
    import test_f45_aar_development_reuse as t
    from padml.bundle import canonical_json_bytes as enc, sha256_bytes, strict_json_bytes
    from padml import f2_kernel as kernel
    report={'evidence_root':str(BASE),'python':sys.version,'scope':'Synthetic engineering only. No native fit, real data, remote, MICE or SHAP.', 'checks':[]}
    print(BASE,flush=True)
    source=Path(t.a.__file__).read_text()
    assert sha256_bytes(source.encode()) == "e9b0b0e79a4defdb36cfd069510ea963c7ee8e750b60b4af7a39704cd0d1d64a"
    old_source=subprocess.check_output(["git","show","35ef61e:padml/f5_sensitivity.py"],cwd=REPO).decode()
    def extract(raw):
        node=next(n for n in ast.parse(raw).body if isinstance(n,ast.FunctionDef) and n.name=="_a12_elastic_search_program")
        return ast.get_source_segment(raw,node)
    old=extract(old_source);candidate_text=extract(source)
    (BASE/"original-function.py").write_text(old+"\n")
    (BASE/"candidate-function.py").write_text(candidate_text+"\n")
    ns=dict(t.a.__dict__);exec(compile(old,str(BASE/"original-function.py"),"exec"),ns)
    original_function=ns["_a12_elastic_search_program"]
    candidate=t.a._a12_elastic_search_program
    report["oracle"]={"commit":"35ef61e","file_sha256":sha256_bytes(old_source.encode()),"function_sha256":sha256_bytes(old.encode())}
    report['source_pins']={name:sha256_bytes((REPO/'padml'/name).read_bytes()) for name in ('f2_kernel.py','f5_sensitivity.py','f5.py','nested_loco.py')}
    report['function_pins']={'original':sha256_bytes(old.encode()),'candidate':sha256_bytes(candidate_text.encode())}
    try:
        fixture_root=BASE/'fixture';fixture_root.mkdir()
        with pytest.MonkeyPatch.context() as m:
            from padml import runtime
            m.setattr(runtime, "_IN_SCIENTIFIC_POOL", True)  # Bounded test fixture: inline existing readback owner.
            # Same existing AAR fixture; correct only its stale science-file/template mismatch.
            m.setattr(t.original,'_unfitted_confirmed_decision',lambda:t.n.science_decision_template(24))
            members=t.f4._f45_source_member_sha256()
            m.setattr(t.f4,'_f45_source_member_sha256',lambda:members)
            m.setattr(t.f5,'_f45_score_reuse_authorities',lambda:({'e'*64:t.n._sha(members)},{t.n._sha(members):members}))
            prepared=t.original.unfitted_selector_shard_inputs.__wrapped__(fixture_root,m,SimpleNamespace(param='ELASTIC_NET_COX'))
            recipes=t.original.unfitted_selector_engines.__wrapped__(m)
            branch=t.n.A12_TOTAL_AAR
            producer=BASE/'producer';producer.mkdir()
            first=t.a._a12_projected_development_inputs(prepared,producer/'development',replay=False,branch=branch)
            counts=t.elastic_leaves(m)
            (producer/'search').mkdir()
            print('producer synthetic native leaves',flush=True)
            original_search=original_function(first,branch,producer/'search'/branch,replay=False,workers=1)
            native_produced=counts['native'];read_produced=counts['read']
            assert native_produced==original_search['native_batch_count']==640
            whole=t.whole(BASE,prepared,producer)
            current=t.current_line(prepared,whole)
            consumer=BASE/'consumer';consumer.mkdir()
            current=t.a._a12_projected_development_inputs(current,consumer/'development',replay=False,branch=branch)
            (consumer/'search').mkdir()
            current_root=consumer/'search'/branch
            print('old cross-line replay',flush=True)
            started=time.perf_counter()
            old_result=original_function(current,branch,current_root,replay=False,workers=1)
            old_seconds=time.perf_counter()-started
            old_reads=counts['read']-read_produced
            old_bytes=enc(old_result)
            pins={p:p.read_bytes() for p in (producer/'search').rglob('*') if p.is_file()}
            before_read=counts['read']
            print('candidate qualified cross-line replay',flush=True)
            started=time.perf_counter()
            new_result=candidate(current,branch,current_root,replay=True,workers=1)
            new_seconds=time.perf_counter()-started
            assert enc(new_result)==old_bytes==(current_root/'search.json').read_bytes()
            assert counts['native']==native_produced and counts['read']==before_read
            assert all(path.read_bytes()==raw for path,raw in pins.items())
            assert enc(old_result['parameters_by_imputation'])==enc(new_result['parameters_by_imputation'])
            assert enc(old_result['epv_resolution'])==enc(new_result['epv_resolution'])
            report['reuse']={'fixture_adapter':'Existing test_nested_aar_mice confirmed-decision helper -> current science_decision_template(24); no production validator edits.',
                'old_full_result_sha256':sha256_bytes(old_bytes),'new_full_result_sha256':sha256_bytes(enc(new_result)),
                'parameter_lock_sha256':sha256_bytes(enc(new_result['parameters_by_imputation'])),
                'epv_resolution_sha256':sha256_bytes(enc(new_result['epv_resolution'])),
                'old_crossline_seconds':old_seconds,'candidate_crossline_seconds':new_seconds,
                'synthetic_native_batches_produced':native_produced,'old_crossline_native_reads':old_reads,
                'candidate_crossline_native_reads':counts['read']-before_read,'candidate_new_fits':0,
                'distinct_alphas':new_result['distinct_alphas'],'losses_per_alpha':15*20*150,
                'record_count':len(new_result['records']), 'whole_proof_metadata':'Synthetic completion fixture; original source/artifact/path/health/EPV/reuse readers kept real.'}
            report['checks'].append('WHOLE_RESULT_PARAMETERS_EPV_BYTE_EXACT_ZERO_NATIVE_REPLAY')
            # The native member byte pins remain enforced before the shortcut.
            member=next((current_root/'native').glob('*/output.json'));saved=member.read_bytes();member.write_bytes(saved+b' ')
            try:
                candidate(current,branch,current_root,replay=True,workers=1)
            except (t.ContractError,ValueError) as exc:
                assert str(exc)=='F45_AAR_ELASTIC_REUSE_INVALID'
            else:raise AssertionError('Changed original native bytes accepted')
            finally:member.write_bytes(saved)
            report['checks'].append('CHANGED_NATIVE_BYTES_REJECTED_BEFORE_SHORTCUT')
            # Original numeric reduction catches changed retained loss, even if identity has been rebuilt.
            original_reuse=t.a._a12_elastic_reuse
            for damage in ('duplicate_alpha','missing_alpha','nonfinite_loss','changed_loss'):
                def corrupted(*args,**kwargs):
                    prior=copy.deepcopy(original_reuse(*args,**kwargs))
                    if damage=='duplicate_alpha':prior['records'].append(copy.deepcopy(prior['records'][0]))
                    elif damage=='missing_alpha':prior['records'].pop(0)
                    elif damage=='nonfinite_loss':prior['records'][0]['partition_losses'][0]['mi_losses'][0][0]=math.nan
                    else:prior['records'][0]['partition_losses'][0]['mi_losses'][0][0]+=.125
                    return prior
                t.a._a12_elastic_reuse=corrupted
                try:candidate(current,branch,current_root,replay=True,workers=1)
                except (t.ContractError,ValueError) as exc:
                    report['checks'].append(damage+':REJECTED:'+str(exc))
                else:raise AssertionError('Changed record accepted: '+damage)
                finally:t.a._a12_elastic_reuse=original_reuse
        report['status']='PASS'
    except BaseException:
        report['status']='FAILED';report['failure']=traceback.format_exc()
        print(report['failure'],flush=True)
    finally:
        (BASE/'result.json').write_text(json.dumps(report,indent=2))
        print(json.dumps({k:v for k,v in report.items() if k!='failure'},indent=2),flush=True)
    if report['status']!='PASS':raise SystemExit(1)

if __name__ == "__main__":
    main()
