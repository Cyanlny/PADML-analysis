"""Freeze inert validation bytes; this is not a deployable production release."""
import json, zipfile
from pathlib import Path
from padml import f4
from padml.bundle import canonical_json_bytes as enc, sha256_bytes as sha, sha256_file, write_deterministic_zip

repo = Path(__file__).resolve().parents[2]
checks = Path(__file__).parent
previous = repo / 'execution/release-q-risk-copy/PADML_F45_REBUILD_20260930_Q_RISK_COPY.zip'
assert sha256_file(previous) == '13d5c2f7b3a0850581707ce1ee0643ffd44fc5816fe350c509015d9fa5a738b2'
identity = sha(enc(f4._f45_source_member_sha256()))
assert json.loads((checks/'qualification.json').read_bytes())['source_identity'] == identity
out = checks / ('candidate-' + identity[:12]); out.mkdir(exist_ok=True)
if (out / 'source.zip').exists():
    manifest = f4.load_f45_source_bundle(out / 'source.zip')
    compiled = {'sha256': sha256_file(out / 'source.zip')}
else:
    compiled = f4.compile_f45_source_bundle(out / 'source.zip')
with zipfile.ZipFile(previous) as source:
    members = {name: source.read(name) for name in source.namelist()
        if name in ('source.zip', 'run.json') or name.endswith(('/source.zip', '/run.json'))}
prefix = 'optimism-predecessor'
members[prefix+'/source.zip'], members[prefix+'/run.json'] = members['source.zip'], members['run.json']
old = json.loads(members['run.json'])
run = {**old, 'source_identity': identity, 'source_bundle_sha256': compiled['sha256'],
    'unit_predecessor': {'run_path': old['run_root']+'/'+prefix+'/run.json', 'run_sha256': sha(members[prefix+'/run.json']),
        'source_path': old['run_root']+'/'+prefix+'/source.zip', 'source_sha256': sha(members[prefix+'/source.zip'])}}
run['identity'] = sha(enc({k:v for k,v in run.items() if k!='identity'}))
members['run.json'] = enc(run)
members['source.zip'] = (out/'source.zip').read_bytes()
members['linux-check.py'] = (checks/'linux-check.py').read_bytes()
members['validation-candidate.json'] = enc({'source_identity': identity, 'run_identity': run['identity'],
    'source_bundle_sha256': compiled['sha256'], 'formal_release': False, 'official_b1000_authorized': False})
target = out / 'VALIDATION_ONLY.zip'
write_deterministic_zip(target, members)
record = {'path': str(target), 'sha256': sha256_file(target), 'size_bytes': target.stat().st_size,
    'source_identity': identity, 'run_identity': run['identity'], 'script_sha256': sha(members['linux-check.py']),
    'formal_release': False}
(checks/'validation-candidate.json').write_bytes(enc(record))
print(json.dumps(record))
