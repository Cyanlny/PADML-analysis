"""Record exact reviewed changed definitions; no blanket source exemption."""
import ast, hashlib, json, pprint, subprocess, sys
from pathlib import Path

assert sys.version_info[:2] == (3, 12)
repo = Path(__file__).resolve().parents[2]
base = 'b290a3869f8158a8396c2c7ed938215c30388c01'
names = ['padml/f4.py', 'padml/f5.py', 'padml/nested_loco.py', 'padml/worker.py', 'padml/run.py']
def digest(raw):
    return hashlib.sha256(raw).hexdigest()
def definitions(raw):
    return {node.name: digest(ast.dump(node, include_attributes=False).encode())
        for node in ast.parse(raw).body if isinstance(node, (ast.FunctionDef, ast.ClassDef))}
changes = {}
for name in names:
    old = definitions(subprocess.check_output(['git', 'show', base + ':' + name], cwd=repo))
    new = definitions((repo / name).read_bytes())
    assert not (set(old) - set(new)), 'Do not silently remove historical readers'
    changed = {key: (old.get(key), value) for key, value in new.items()
        if old.get(key) != value and key != '_f45_aar_binding_ast'}
    if changed:
        changes[name] = changed
path = repo / 'padml/run.py'
text = path.read_text()
start, end = '    # BEGIN EXACT OPTIMISM DEFINITIONS\n', '    # END EXACT OPTIMISM DEFINITIONS\n'
if start in text:
    left, rest = text.split(start)
    _, right = rest.split(end)
    text = left + right
block = start + '    optimism_qualified = ' + pprint.pformat(changes, width=120, sort_dicts=True) + '\n'
block += '''    for module, definitions in optimism_qualified.items():
        target = qualified.setdefault(module, {})
        for function, revisions in definitions.items():
            target[function] = tuple(dict.fromkeys((*target.get(function, ()), *revisions)))
'''+end
marker = '    if name == "padml/runtime.py":\n'
assert text.count(marker) == 1
path.write_text(text.replace(marker, block + marker))
raws = {name: [digest(subprocess.check_output(['git', 'show', base + ':' + name], cwd=repo)),
    digest((repo / name).read_bytes())] for name in ['AGENTS.md', 'NESTED_LOCO_PROTOCOL.md', 'padml/kernels/f4_metrics.R']}
record = {'baseline_git': base, 'function_revisions': changes, 'raw_revisions': raws}
(Path(__file__).parent / 'reviewed-source-ast.json').write_text(json.dumps(record, indent=2, sort_keys=True)+'\n')
print(json.dumps({'changed_definitions': {name: len(rows) for name, rows in changes.items()}, 'raw': raws}))
