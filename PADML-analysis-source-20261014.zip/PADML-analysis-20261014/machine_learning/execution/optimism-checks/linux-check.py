"""One isolated real-input consumer check. Run only by the existing remote owner."""
from __future__ import annotations
import argparse, fcntl, json, os, platform, subprocess, time
from pathlib import Path
from unittest.mock import patch
from padml import f4, run as runs, runtime, worker
from padml.bundle import canonical_json_bytes as enc, sha256_bytes as sha, sha256_file

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('candidate', type=Path)
    parser.add_argument('workspace', type=Path)
    args = parser.parse_args()
    candidate, workspace = args.candidate.resolve(strict=True), args.workspace.resolve(strict=True)
    assert platform.system() == 'Linux'
    assert Path(f4.__file__).resolve().is_relative_to(candidate / 'source')
    run_raw = (candidate / 'run.json').read_bytes()
    original = json.loads(run_raw)
    production = Path(original['run_root'])
    assert workspace.is_relative_to(production / 'engineering')
    assert not candidate.is_relative_to(production / 'source')
    index = json.loads((candidate / 'validation-candidate.json').read_bytes())
    assert index['source_identity'] == sha(enc(f4._f45_source_member_sha256())) == original['source_identity']
    def mapped(value):
        value = str(value)
        if value.startswith(str(production) + '/') and not value.startswith(str(candidate) + '/'):
            replacement = Path(str(candidate) + value[len(str(production)):])
            if replacement.is_file():
                return replacement
        return Path(value)
    os.environ.update(runtime.THREAD_ENV)
    os.environ['R_LIBS_USER'] = runtime.R_LIBRARY
    staged_run = workspace / 'run.json'
    if staged_run.exists():
        assert staged_run.read_bytes() == run_raw
    else:
        staged_run.write_bytes(run_raw)
    os.environ['PADML_F45_RUN_PATH'] = str(staged_run)
    # The original instance lock also owns all validation pool groups. No other launch.
    with (production / 'active.lock').open('a+') as owner:
        fcntl.flock(owner, fcntl.LOCK_EX | fcntl.LOCK_NB)
        owner.seek(0)
        previous = [json.loads(line) for line in owner.read().splitlines() if line.strip()]
        groups = {row.get('pgid') for row in previous}
        assert all(type(group) is int and group > 0 for group in groups)
        live = set(subprocess.check_output(['ps', '-eo', 'pgid='], text=True).split())
        assert all(str(group) not in live for group in groups if group != os.getpgrp())
        owner.seek(0); owner.truncate()
        owner.write(json.dumps({'pid': os.getpid(), 'pgid': os.getpgrp(), 'unit_id': 'PRIMARY-H06-O2',
            'mode': 'postprocess', 'validation_only': True, 'run_identity': original['identity']})+'\n')
        owner.flush(); os.fsync(owner.fileno())
        def observe(group):
            owner.write(json.dumps({'pgid': group})+'\n'); owner.flush(); os.fsync(owner.fileno())
        runtime._POOL_GROUP_OBSERVER = observe
        started = time.monotonic()
        result = {'kind': 'REAL_INPUT_BOUNDED_OPTIMISM_CHECK', 'formal_scientific_completion': False,
            'new_prediction_model_fits': 0, 'source_identity': index['source_identity'], 'contexts': [],
            'validation_script_sha256': sha256_file(Path(__file__)),
            'before': runtime.observe_execution_resources(workspace)}
        try:
            with patch.object(runs, 'Path', mapped), patch.object(f4, 'Path', mapped):
                run = runs.load_f45_run(candidate / 'run.json')
                assert len(runs.f45_unit_predecessors(run)) == 24
                units = {u['unit_id']: u for u in run['units']}
                for uid in ('PRIMARY-H06-O2', 'FULL0-H06'):
                    root = workspace / 'units' / uid
                    original_receipt = (root / 'unit.json').read_bytes()
                    postprocess_preexisting = (root / 'postprocess/result.json').is_file()
                    prior_coordinates = [r for r in range(1, 9) if
                        (workspace / 'evaluation' / uid / 'replicates' / f'B{r:04d}.json').is_file()]
                    old_archive = root / 'unit.zip'
                    old_zip_state = None if not old_archive.exists() else (old_archive.stat().st_size, old_archive.stat().st_mtime_ns)
                    begin = time.monotonic()
                    tail = f4.run_f45_postprocess(run, units[uid], root)
                    postprocess_seconds = time.monotonic() - begin
                    assert f4.run_f45_postprocess(run, units[uid], root) == tail
                    loaded = f4.load_f45_optimism_inputs(root / 'postprocess/input.zip', run, units[uid])
                    destination = workspace / 'evaluation' / uid
                    begin = time.monotonic()
                    selection = f4.run_f45_selection(run, units['EVALUATION-H06'], units[uid], destination,
                        input_path=root / 'postprocess/input.zip', replicate_ids=range(1, 9))
                    selection_seconds = time.monotonic() - begin
                    paths = [destination / 'replicates' / f'B{r:04d}.json' for r in range(1, 9)]
                    pins = {str(p): sha256_file(p) for p in paths}
                    with patch.object(f4, '_bounded_ordered_spawn', side_effect=AssertionError('MUST_NOT_RECOMPUTE')):
                        resumed = f4.run_f45_selection(run, units['EVALUATION-H06'], units[uid], destination,
                            input_path=root / 'postprocess/input.zip', replicate_ids=range(1, 9))
                    assert not resumed['computed_now'] and all(sha256_file(p) == pins[str(p)] for p in paths)
                    assert (root / 'unit.json').read_bytes() == original_receipt
                    assert (None if not old_archive.exists() else (old_archive.stat().st_size, old_archive.stat().st_mtime_ns)) == old_zip_state
                    numbers = [f4._f45_read_selection_replicate(p, loaded, r) for r, p in enumerate(paths, 1)]
                    for row in numbers:
                        if row['selected_family'] is not None:
                            chosen = next(e for e in row['selection_evidence'] if e['family'] == row['selected_family'])
                            reported = next(r for r in row['report_rows'] if r['report_month'] == 6 and r['metric'] == 'ibs')
                            assert chosen['repeat_ibs'] == reported['repeat_values']['INBAG']
                    result['contexts'].append({'source_unit': uid, 'input_identity': loaded['manifest']['identity_sha256'],
                        'postprocess_preexisting': postprocess_preexisting,
                        'initial_completed_replicates': prior_coordinates,
                        'patient_count': len(loaded['manifest']['patient_ids']), 'o_fit_rows': tail['report_rows'],
                        'postprocess_seconds': postprocess_seconds, 'selection_seconds': selection_seconds,
                        'selection_validation': selection, 'resume_computed_now': resumed['computed_now'],
                        'retained_bytes': sum(p.stat().st_size for folder in (root / 'postprocess', destination)
                            for p in folder.rglob('*') if p.is_file()),
                        'original_receipt_unchanged': True, 'original_unit_zip_unchanged_or_absent': True,
                        'memory': runtime.observe_step_memory()})
                    worker._f45_release(root, 'BOUNDED_OPTIMISM_VALIDATION:' + uid, root, workspace / 'contexts')
            result.update(status='PASS', elapsed_seconds=time.monotonic()-started,
                after=runtime.observe_execution_resources(workspace))
            (workspace / 'validation.json').write_bytes(enc(result))
            print(json.dumps(result, sort_keys=True))
        finally:
            runtime._POOL_GROUP_OBSERVER = None

if __name__ == '__main__':
    if os.getpgrp() != os.getpid():
        os.setsid()
    main()
