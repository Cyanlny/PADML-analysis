"""One production release, only after the real-input bounded Linux check passes."""
import ast, io, json, os, subprocess, sys, zipfile
from pathlib import Path
from padml import f4
from padml.bundle import canonical_json_bytes as enc, sha256_bytes as sha, sha256_file, write_deterministic_zip

assert sys.version_info[:2] == (3, 12)
repo = Path(__file__).resolve().parents[2]
base, checks = repo/'execution', Path(__file__).parent
previous = base/'release-q-risk-copy/PADML_F45_REBUILD_20260930_Q_RISK_COPY.zip'
assert sha256_file(previous) == '13d5c2f7b3a0850581707ce1ee0643ffd44fc5816fe350c509015d9fa5a738b2'
pins = f4._f45_source_member_sha256(); identity = sha(enc(pins))
qualification = json.loads((checks/'qualification.json').read_bytes())
tests = json.loads((checks/'focused-checks.json').read_bytes())
linux = json.loads((checks/'linux-validation/validation.json').read_bytes())
closure = json.loads((checks/'linux-validation/VALIDATION-CLOSURE.json').read_bytes())
assert qualification['source_identity'] == tests['source_identity'] == linux['source_identity'] == identity
assert len(qualification['checks']['predecessors']) == 24 and tests['existing_pytest_cases_passed'] == 6
assert tests['dispatch_and_worker_cases_passed'] == 10 and tests['current_source_pins'] == pins
assert linux['status'] == 'PASS' and not linux['formal_scientific_completion']
assert linux['validation_script_sha256'] == sha256_file(checks/'linux-check.py')
assert closure['status'] == 'PASS' and closure['source_identity'] == identity
assert closure['final_validation_json_sha256'] == sha256_file(checks/'linux-validation/validation.json')
assert closure['all_final_registered_groups_exited'] and closure['unique_computed_numeric_coordinates'] == 16
assert closure['all_24_completed_numeric_artifact_sha_size_mtime_unchanged']
assert closure['all_27_sealed_source_carriers_sha_unchanged']
assert [row['source_unit'] for row in linux['contexts']] == ['PRIMARY-H06-O2','FULL0-H06']
assert all(row['selection_validation']['replicates'] == list(range(1,9)) and not row['resume_computed_now']
    and row['original_receipt_unchanged'] and row['original_unit_zip_unchanged_or_absent'] for row in linux['contexts'])
review = json.loads((checks/'reviewed-source-ast.json').read_bytes())
for name, definitions in review['function_revisions'].items():
    observed = {n.name:sha(ast.dump(n,include_attributes=False).encode()) for n in ast.parse((repo/name).read_bytes()).body
        if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
    assert all(observed[n] == revisions[-1] for n,revisions in definitions.items())
for name, revisions in review['raw_revisions'].items():
    assert sha256_file(repo/name) == revisions[-1]
head = subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert not subprocess.check_output(['git','diff','--name-only','HEAD','--',*f4.F45_SOURCE_MEMBERS],cwd=repo)
for name in f4.F45_SOURCE_MEMBERS:
    assert subprocess.check_output(['git','show',head+':'+name],cwd=repo) == (repo/name).read_bytes()
with zipfile.ZipFile(previous) as source:
    members = {n:source.read(n) for n in source.namelist() if n!='release.json'}
    with zipfile.ZipFile(io.BytesIO(members['source.zip'])) as old_source:
        changed = [n for n in f4.F45_SOURCE_MEMBERS if old_source.read(n)!=(repo/n).read_bytes()]
out = base/'release-optimism';out.mkdir()
compiled = f4.compile_f45_source_bundle(out/'source.zip')
prefix='optimism-predecessor'
members[prefix+'/run.json'],members[prefix+'/source.zip']=members['run.json'],members['source.zip']
old=json.loads(members['run.json'])
run={**old,'source_identity':identity,'source_bundle_sha256':compiled['sha256'],
    'unit_predecessor':{'run_path':old['run_root']+'/'+prefix+'/run.json','run_sha256':sha(members[prefix+'/run.json']),
        'source_path':old['run_root']+'/'+prefix+'/source.zip','source_sha256':sha(members[prefix+'/source.zip'])}}
run['identity']=sha(enc({k:v for k,v in run.items() if k!='identity'}))
assert run['units']==old['units'] and run['science_decision']==old['science_decision']
members['run.json']=enc(run);members['source.zip']=(out/'source.zip').read_bytes();members['source.compile.json']=enc(compiled)
for name in ('AGENTS.md','NESTED_LOCO_PROTOCOL.md'):
    members[name]=(repo/name).read_bytes()
evidence={p.relative_to(checks).as_posix():p for p in checks.rglob('*') if p.is_file()
    and not any(part.startswith('candidate-') for part in p.relative_to(checks).parts)
    and 'input-staging' not in p.relative_to(checks).parts
    and p.suffix in {'.py','.R','.json','.xml','.txt','.log','.md','.stdout','.stderr'}}
write_deterministic_zip(out/'optimism-checks.zip',evidence)
members['optimism-checks.zip']=(out/'optimism-checks.zip').read_bytes()
members['HISTORICAL_Q_RISK_COPY_COMPILE.md']=members['COMPILE_REPORT.md']
report=(f'Frozen Git: {head}. Source: {identity}. Run: {run["identity"]}.\n\n'+(base/'OPTIMISM_COMPILE.md').read_text()).encode()
members['README.md']=members['COMPILE_REPORT.md']=members['EXECUTION_HANDOFF.md']=report
summary={'head':head,'source_identity':identity,'run_identity':run['identity'],'source':compiled,
    'changed_source_members':changed,'source_member_count':len(f4.F45_SOURCE_MEMBERS),'units':56,'optimism_contexts':28,
    'predecessors':24,'science_decision_unchanged':True,'new_prediction_model_fits':0,
    'linux_validation_sha256':sha256_file(checks/'linux-validation/validation.json'),
    'previous_package_sha256':sha256_file(previous),'deployed':False,'formal_scientific_completion':False}
members['compile-summary.json']=enc(summary)
with zipfile.ZipFile(previous) as source:
    for name in source.namelist():
        if name in {'science-decision.json','dependencies.json','shared/bootstrap.zip','shared/bootstrap-preparation.json'} \
            or name.endswith(('/run.json','/source.zip','-checks.zip')):
            assert members[name]==source.read(name)
release={'kind':'PADML_F45_OPTIMISM_RELEASE','head':head,'source_identity':identity,'run_identity':run['identity'],
    'members':{name:{'sha256':sha(raw),'size_bytes':len(raw)} for name,raw in members.items()}}
members['release.json']=enc(release)
target=out/'PADML_F45_REBUILD_20261001_OPTIMISM.zip';write_deterministic_zip(target,members)
readback=subprocess.check_output([sys.executable,'-B',str(checks/'frozen-reader.py'),str(target)],cwd=repo,
    env={**os.environ,'PYTHONPATH':str(repo),'PYTHONDONTWRITEBYTECODE':'1'},text=True)
(out/'frozen-reader.log').write_text(readback)
summary.update(package=str(target),sha256=sha256_file(target),size_bytes=target.stat().st_size)
(out/'compile-summary.json').write_bytes(enc(summary));print(json.dumps(summary))
