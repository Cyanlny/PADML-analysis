import ast, csv, hashlib, io, json, math, pathlib, subprocess, sys
ROOT=pathlib.Path(__file__).resolve().parent
REPO=pathlib.Path('/Users/liuningyuan/Desktop/Result/Machine Learning/PADML_F45_REBUILD')
sys.path.insert(0,str(REPO))
from padml import f4, f2_kernel as k, nested_loco as n
from padml.bundle import canonical_json_bytes
pins={name:hashlib.sha256((REPO/name).read_bytes()).hexdigest() for name in ('padml/f4.py','padml/nested_loco.py','padml/kernels/f4_metrics.R')}
(ROOT/'f4_metrics.R').write_bytes((REPO/'padml/kernels/f4_metrics.R').read_bytes())
ids=[f'UNFITTED_{i:03d}' for i in range(180)]
centers=['36']*90+['38']*90
fields=['Patient_ID','All_Cause_Death','Death_Followup_months']
s=io.StringIO(newline=''); writer=csv.DictWriter(s,fieldnames=fields,lineterminator='\n');writer.writeheader()
for i,pid in enumerate(ids):
 j=i%90; e=int(j<60); time=(1+(j%12)*.4 if j<30 else 10+(j%27)) if e else ({60:8.,61:18.,62:28.}.get(j,45.+j%5))
 writer.writerow(dict(zip(fields,(pid,str(e),str(time)))))
fields,rows=k._response_rows(s.getvalue().encode()); response=k._write_response_subset(fields,rows,ids,None)
context=f4.censoring_context(ids,centers,response)
assert all(context['rows'][h]['status']=='ESTIMABLE' and context['rows'][h]['n_events']>=20 and context['rows'][h]['n_non_events']>=20 for h in (6,12,24,36))
curves=[[math.exp(-(0.003+(i*37%173)*.00018)*t) for t in (6,12,24,36)] for i in range(180)]
job={'label':'UNFITTED_ONLY','patient_ids':ids,'survival':curves,'times':context['times'],'events':context['events'],'centers':centers,'censoring_steps':context['censoring_steps'],'ipcw':[context['rows'][h] for h in (6,12,24,36)],'include_slope':True,'nested_optimism':True,'primary_report_horizon_months':24}
(ROOT/'job.json').write_bytes(canonical_json_bytes(job))
old=subprocess.check_output(['git','show','HEAD:padml/nested_loco.py'],cwd=REPO).decode()
def extract(text,names):
 tree=ast.parse(text); return ast.Module(body=[v for v in tree.body if isinstance(v,ast.FunctionDef) and v.name in names],type_ignores=[])
old_ns=dict(n.__dict__);old_ns['validate_training_score']=lambda x:x
exec(compile(extract(old,{'select_training_family'}),'<HEAD_SELECT>','exec'),old_ns)
new_ns=dict(n.__dict__);new_ns['validate_training_score']=lambda x:x
exec(compile(extract((REPO/'padml/nested_loco.py').read_text(),{'select_training_family','_rank_training_families'}),'<CURRENT_SELECT>','exec'),new_ns)
families=n._families(); cases=[]
for label,means,maxima in [
 ('unique_near_group',[.1,.3,.4,.5,.6,.7,.8],[.2,.4,.5,.6,.7,.8,.9]),
 ('inclusive_margin',[.1,.102,.4,.5,.6,.7,.8],[.2,.15,.5,.6,.7,.8,.9]),
 ('exact_all_ties',[.1]*7,[.2]*7)]:
 evidence=[dict(family=f,mean_ibs=means[i],maximum_ibs=maxima[i],training_context_sha256='ctx',outer_fold=1,heldout_center='37',selector_evidence_sha256='sel',selection_horizon_months=36,science_decision_sha256='sci',identity_sha256=f,selected_spec={'synthetic':f},selected_spec_sha256=f) for i,f in enumerate(families)]
 a=old_ns['select_training_family'](list(reversed(evidence)));b=new_ns['select_training_family'](list(reversed(evidence)))
 assert canonical_json_bytes(a)==canonical_json_bytes(b)
 cases.append({'case':label,'selected':a['selected_family'],'decision_bytes_equal':True})
(ROOT/'source-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
(ROOT/'ranking-result.json').write_text(json.dumps({'scope':'SYNTHETIC_RANK_ARITHMETIC_ONLY_VALIDATORS_STUBBED','cases':cases},indent=2)+'\n')
print(json.dumps({'ranking':'PASS','case_count':len(cases),'directory':str(ROOT)},sort_keys=True))
