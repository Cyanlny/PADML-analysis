import hashlib,json,pathlib,sys
ROOT=pathlib.Path(__file__).resolve().parent
REPO=pathlib.Path('/Users/liuningyuan/Desktop/Result/Machine Learning/PADML_F45_REBUILD')
sys.path.insert(0,str(REPO))
from padml import f4
from padml.bundle import ContractError

def forbidden(*args,**kwargs): raise AssertionError('NO_NATIVE_R_OR_FIT_OR_REPLICATE_PRODUCER_PERMITTED')
f4.native_metrics=forbidden;f4._f45_selection_replicate=forbidden
ids=[f'UNFITTED_{i:03d}' for i in range(180)];centers=['36']*90+['38']*90
draw=[]
for start in (0,90):
 indices=[i for i in range(start,start+90) if i%3];draw.extend(indices+indices[:30])
loaded={'manifest':{'source_unit':'PRIMARY-H12-O1','identity_sha256':'0'*64,'patient_ids':ids,'centers':centers,'selection_horizon_months':12},'draws':{'draws':[draw]}}
original=(ROOT/'B0001.json').read_bytes();valid=f4._f45_read_selection_replicate(ROOT/'B0001.json',loaded,1)
assert (ROOT/'B0001.json').read_bytes()==original
checks={}
for label in ('row_order','selected_family','repeat_value'):
 try:f4._f45_read_selection_replicate(ROOT/(label+'.json'),loaded,1)
 except ContractError as exc:checks[label]={'rejected':True,'reason':str(exc)}
 else:raise AssertionError(label+'_ACCEPTED')
family=valid['selected_family'];selected=next(e for e in valid['selection_evidence'] if e['family']==family)
assert all(selected['repeat_ibs'][r-1].hex()==valid['numbers'][f'INBAG/R{r}']['12']['ibs']['value'].hex() for r in range(1,4))
result={'status':'PASS','scope':'SAVED_SYNTHETIC_REPLICATE_READONLY_NO_R_NO_RECOMPUTATION','source_f4_sha256':hashlib.sha256((REPO/'padml/f4.py').read_bytes()).hexdigest(),'original_replicate_sha256':hashlib.sha256(original).hexdigest(),'valid_unchanged':True,'selection_vs_report_ibs_h_exact':True,'negative_checks':checks}
(ROOT/'reader-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,sort_keys=True))
