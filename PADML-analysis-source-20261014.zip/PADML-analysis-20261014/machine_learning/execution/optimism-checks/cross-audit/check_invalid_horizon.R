source('/Users/liuningyuan/Desktop/Result/Machine Learning/PADML_F45_REBUILD/padml/kernels/f4_metrics.R')
root <- '/private/var/folders/qj/5799w4651d7gmrcfq_wwhyym0000gn/T/padml-optimism-science-audit-0bvhaewv'
job<-jsonlite::fromJSON(file.path(root,'job.json'),simplifyVector=FALSE)
job$primary_report_horizon_months<-12.9
reason<-tryCatch({evaluate_optimism_job(job);NULL},error=function(e)conditionMessage(e))
stopifnot(identical(reason,'F4_DISCRIMINATION_HORIZON_INVALID'))
result<-list(status='PASS',scope='SINGLE_FRACTIONAL_HORIZON_NEGATIVE_NO_METRIC_COMPUTATION',reason=reason)
jsonlite::write_json(result,file.path(root,'r-horizon-negative-result.json'),auto_unbox=TRUE,pretty=TRUE)
cat(jsonlite::toJSON(result,auto_unbox=TRUE),'\n')
