from __future__ import annotations
import ast
import copy
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

REPO = Path('/Users/liuningyuan/Desktop/Result/Machine Learning/PADML_F45_REBUILD')
sys.path.insert(0, str(REPO))
from padml import run as r
from padml import worker as w
from padml import f4
from padml.bundle import ContractError

BASELINE = subprocess.check_output(['git', 'show', 'HEAD:padml/run.py'], cwd=REPO, text=True)
old_tree = ast.parse(BASELINE)
old_fns = [n for n in old_tree.body if isinstance(n, ast.FunctionDef) and n.name in {'f45_ready_assignments', 'f45_units'}]
old_ns = dict(r.__dict__)
exec(compile(ast.Module(body=old_fns, type_ignores=[]), '<HEAD-original-dispatcher>', 'exec'), old_ns)
old_ready, old_units = old_ns['f45_ready_assignments'], old_ns['f45_units']
UNITS = r.f45_units()
RUN = {'units': UNITS}
IDS = {u['unit_id'] for u in UNITS}
SOURCES = {u['unit_id'] for u in UNITS if u['kind'] in {'PRIMARY', 'FULL0'}}
HOSTS = list(r.F45_HOSTS)
BYID = {u['unit_id']: u for u in UNITS}

def observations():
    return {h: {'state': 'IDLE', 'active_unit': None, 'completed_units': [], 'local_contexts': []} for h in HOSTS}

def complete(*, pending=(), unprocessed=(), unselected=()):
    o = observations()
    o[HOSTS[0]]['completed_units'] = sorted(IDS - set(pending))
    o[HOSTS[0]]['postprocess_ready_units'] = sorted(SOURCES - set(unprocessed))
    o[HOSTS[0]]['selection_completed_units'] = sorted(SOURCES - set(unselected))
    return o

def active(o, host, unit, mode='execute', source=None, state='RUNNING'):
    o[host].update(state=state, active_unit=unit, active_mode=mode)
    if source is not None:
        o[host]['active_source_unit'] = source

class DispatcherAudit(unittest.TestCase):
    def test_01_original_56_and_original_dispatch_match(self):
        self.assertEqual(UNITS, old_units())
        self.assertEqual(len(UNITS), 56)
        scenarios = [observations()]
        o = observations(); active(o, 'H0', 'PRIMARY-H06-O1'); scenarios.append(o)
        o = observations()
        for host, context in zip(HOSTS, ['FULL0', *[f'OUTER-{i}' for i in range(1, 7)]]):
            o[host]['local_contexts'] = [context]
        scenarios.append(o)
        o = observations()
        o['H0']['completed_units'] = sorted(SOURCES)
        o['H0']['postprocess_ready_units'] = sorted(SOURCES)
        o['H0']['selection_completed_units'] = sorted(SOURCES)
        scenarios.append(o)
        for i, o in enumerate(scenarios):
            with self.subTest(scenario=i):
                self.assertEqual(r.f45_ready_assignments(RUN, o), old_ready(RUN, o))

    def test_02_four_selection_lines_distributed_once(self):
        candidates = {f'PRIMARY-H{h:02d}-O1' for h in (6, 12, 24, 36)}
        out = r.f45_ready_assignments(RUN, complete(unselected=candidates))
        self.assertEqual(len(out), 4)
        self.assertEqual({x['source_unit'] for x in out}, candidates)
        self.assertEqual(len({x['host'] for x in out}), 4)
        self.assertTrue(all(x['mode'] == 'selection' and x['source_host'] == 'H0' for x in out))

    def test_03_ready_context_does_not_wait_for_full_line(self):
        o = observations()
        for host, fold in zip(HOSTS[1:], range(1, 7)):
            active(o, host, f'PRIMARY-H{12 if fold == 1 else 6:02d}-O{fold}')
            o[host]['local_contexts'] = [f'OUTER-{fold}']
        o['H1']['local_contexts'].append('FULL0')
        o['H1']['completed_units'] = ['PRIMARY-H06-O1']
        o['H1']['postprocess_ready_units'] = ['PRIMARY-H06-O1']
        self.assertEqual(r.f45_ready_assignments(RUN, o), [
            {'host': 'H0', 'unit_id': 'EVALUATION-H06', 'mode': 'selection',
             'source_unit': 'PRIMARY-H06-O1', 'source_host': 'H1'}])

    def test_04_same_horizon_selection_deduplicated(self):
        o = complete(unselected={'PRIMARY-H06-O1', 'PRIMARY-H06-O2'})
        active(o, 'H0', 'EVALUATION-H06', 'selection', 'PRIMARY-H06-O1')
        self.assertEqual(r.f45_ready_assignments(RUN, o), [])
        active(o, 'H1', 'EVALUATION-H06', 'selection', 'PRIMARY-H06-O2')
        with self.assertRaises(ContractError):
            r.f45_ready_assignments(RUN, o)

    def test_05_paired_and_selection_independent_both_directions(self):
        o = complete(pending={'EVALUATION-H06'}, unselected={'PRIMARY-H06-O1'})
        active(o, 'H0', 'EVALUATION-H06', 'selection', 'PRIMARY-H06-O1')
        self.assertEqual(r.f45_ready_assignments(RUN, o), [{'host': 'H1', 'unit_id': 'EVALUATION-H06'}])
        o = complete(pending={'EVALUATION-H06'}, unselected={'PRIMARY-H06-O1'})
        active(o, 'H0', 'EVALUATION-H06')
        self.assertEqual(r.f45_ready_assignments(RUN, o), [
            {'host': 'H1', 'unit_id': 'EVALUATION-H06', 'mode': 'selection',
             'source_unit': 'PRIMARY-H06-O1', 'source_host': 'H0'}])

    def test_06_unknown_matches_original_and_identified_selection_blocks_its_line(self):
        o = observations(); o['H0']['state'] = 'UNKNOWN'
        self.assertEqual(r.f45_ready_assignments(RUN, o), old_ready(RUN, o))
        self.assertEqual(r.f45_ready_assignments(RUN, o), [])
        o = observations(); active(o, 'H0', 'PRIMARY-H06-O1', state='UNKNOWN')
        self.assertEqual(r.f45_ready_assignments(RUN, o), old_ready(RUN, o))
        candidates = {f'PRIMARY-H{h:02d}-O1' for h in (6, 12, 24, 36)}
        o = complete(unselected=candidates)
        active(o, 'H0', 'EVALUATION-H06', 'selection', 'PRIMARY-H06-O1', state='UNKNOWN')
        out = r.f45_ready_assignments(RUN, o)
        self.assertEqual({x['unit_id'] for x in out}, {'EVALUATION-H12', 'EVALUATION-H24', 'EVALUATION-H36'})

    def test_07_postprocess_stays_local_and_is_not_redispatched(self):
        source = 'PRIMARY-H06-O1'
        o = complete(unprocessed={source}, unselected={source})
        o['H0']['local_contexts'] = ['OUTER-1']
        self.assertEqual(r.f45_ready_assignments(RUN, o), [
            {'host': 'H0', 'unit_id': source, 'mode': 'postprocess'}])
        # A receipt copied to a different host does not transfer context ownership.
        o['H0']['completed_units'].remove(source)
        o['H1']['completed_units'] = [source]
        self.assertEqual(r.f45_ready_assignments(RUN, o), [])
        # In-flight source postprocessing blocks a copied receipt from being redispatched.
        o['H0']['completed_units'].append(source)
        active(o, 'H0', source, 'postprocess')
        self.assertEqual(r.f45_ready_assignments(RUN, o), [])

    def test_08_original_pending_work_precedes_selection(self):
        o = complete(pending={'EVALUATION-H12'}, unselected={'PRIMARY-H06-O1'})
        out = r.f45_ready_assignments(RUN, o)
        self.assertEqual(out[0], {'host': 'H0', 'unit_id': 'EVALUATION-H12'})
        self.assertEqual(out[1]['mode'], 'selection')

    def test_09_invalid_mode_source_and_duplicate_identity_rejected(self):
        bad = [
            ('EVALUATION-H06', 'selection', 'AAR-H06-O1'),
            ('EVALUATION-H06', 'selection', 'PRIMARY-H12-O1'),
            ('AAR-H06-O1', 'postprocess', None),
        ]
        for unit, mode, source in bad:
            o = complete(); active(o, 'H0', unit, mode, source)
            with self.subTest(unit=unit, mode=mode, source=source), self.assertRaises(ContractError):
                r.f45_ready_assignments(RUN, o)
        o = complete()
        active(o, 'H0', 'PRIMARY-H06-O1')
        active(o, 'H1', 'PRIMARY-H06-O1', 'postprocess')
        with self.assertRaises(ContractError):
            r.f45_ready_assignments(RUN, o)

    def test_10_worker_modes_route_before_receipts_deps_and_never_repackage(self):
        # Engineering route test only: explicit route token, and diagnostic UNKNOWN return.
        for mode, unit, source, leaf in [
            ('postprocess', 'PRIMARY-H06-O1', None, 'run_f45_postprocess'),
            ('postprocess', 'FULL0-H12', None, 'run_f45_postprocess'),
            ('selection', 'EVALUATION-H06', 'PRIMARY-H06-O1', 'run_f45_selection'),
            ('selection', 'EVALUATION-H12', 'FULL0-H12', 'run_f45_selection'),
            ('execute', 'PRIMARY-H06-O1', None, 'run_f45_postprocess'),
            ('execute', 'FULL0-H12', None, 'run_f45_postprocess'),
        ]:
            with self.subTest(mode=mode, unit=unit), tempfile.TemporaryDirectory(prefix='f45-mode-route-', dir='/tmp') as tmp:
                run = {**RUN, 'identity': 'isolated-route-fixture', 'run_root': tmp,
                       'science_decision': {'amendment_20260928': {}}, 'resource_policy': {}}
                root = Path(tmp) / 'units' / unit
                root.mkdir(parents=True)
                receipt = {'run_identity': run['identity'], 'unit_id': unit, 'status': 'COMPLETED'}
                original_receipt = json.dumps(receipt).encode()
                (root / 'unit.json').write_bytes(original_receipt)
                events = []
                def leaf_result(*args):
                    events.append('scientific_leaf_returned')
                    return {'audit_route_only': mode}
                def released(*args):
                    self.assertEqual(events, ['scientific_leaf_returned'])
                    events.append('release_diagnostic_unknown')
                    return {'cumulative': {'status': 'UNKNOWN'}, 'files_deleted': 0}
                def read_original(path):
                    self.assertEqual(mode, 'execute', 'new mode reached old receipt path')
                    self.assertEqual(path, root / 'unit.json')
                    return receipt
                with patch('platform.system', return_value='Linux'), \
                     patch.object(r, 'load_f45_run', return_value=run), \
                     patch.object(r, 'f45_unit_predecessors', return_value=[]), \
                     patch.object(f4, leaf, side_effect=leaf_result) as target, \
                     patch.object(w, '_f45_read', side_effect=read_original), \
                     patch.object(w, '_f45_release', side_effect=released) as release, \
                     patch.object(w, '_f45_file_pins', side_effect=AssertionError('old artifact packaging path executed')), \
                     patch.object(w, 'write_deterministic_zip', side_effect=AssertionError('unit.zip rebuilt')):
                    actual = w.execute_f45(Path(tmp) / 'run.json', unit, mode=mode, source_unit=source)
                    self.assertEqual(actual, receipt if mode == 'execute' else {'audit_route_only': mode})
                self.assertEqual(events, ['scientific_leaf_returned', 'release_diagnostic_unknown'])
                self.assertEqual((root / 'unit.json').read_bytes(), original_receipt)
                self.assertFalse((root / 'unit.zip').exists())
                if mode == 'selection':
                    self.assertEqual(target.call_args.args[-1], root / 'selection' / source)
                    self.assertFalse((Path(tmp) / 'contexts' / BYID[source]['context']).exists())
                    expected_owner = 'SELECTION:' + source
                else:
                    self.assertEqual(target.call_args.args[-1], root)
                    expected_owner = 'POSTPROCESS:' + unit
                self.assertEqual(target.call_count, 1)
                self.assertEqual(release.call_count, 1)
                self.assertEqual(release.call_args.args, (root, expected_owner, root, Path(tmp) / 'contexts' / BYID[unit]['context']))
                owner = json.loads((Path(tmp) / 'active.lock').read_text().splitlines()[0])
                self.assertEqual((owner['mode'], owner['source_unit']), (mode, source))

if __name__ == '__main__':
    print(json.dumps({'audit': 'metadata dispatcher + worker mode routes only, no scientific computation',
        'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip(),
        'source_sha256': {p: hashlib.sha256((REPO/p).read_bytes()).hexdigest()
                         for p in ['padml/run.py', 'padml/worker.py', 'padml/f4.py']},
        'python': sys.version.split()[0]}, sort_keys=True), flush=True)
    unittest.main(verbosity=2)
