import copy,hashlib,json,pathlib,sys
ROOT=pathlib.Path(__file__).resolve().parent
REPO=pathlib.Path('/Users/liuningyuan/Desktop/Result/Machine Learning/PADML_F45_REBUILD')
sys.path.insert(0,str(REPO))
from padml import f4,nested_loco as n
from padml.bundle import canonical_json_bytes,ContractError

def forbidden(*args,**kwargs):raise AssertionError('NO_NATIVE_R_OR_FIT_OR_METRIC_PRODUCER_PERMITTED')
f4.native_metrics=forbidden;f4._f45_optimism_metrics=forbidden
source=json.loads((ROOT/'B0001.json').read_text())
manifest={'identity_sha256':'1'*64,'source_receipt_sha256':'2'*64,'patient_ids':[f'UNFITTED_{i:03d}' for i in range(180)],'source_unit':'PRIMARY-H12-O1','selection_horizon_months':12,'development_lock':{'selected_family':source['selected_family']}}
loaded={'manifest':manifest};unit={'unit_id':'PRIMARY-H12-O1','horizon':12,'kind':'PRIMARY'}
numbers={}
for name,r in [('APPARENT',1),('OOF-R1',1),('OOF-R2',2),('OOF-R3',3)]:
 numbers['TRAINING/'+name]=copy.deepcopy(source['numbers'][f'INBAG/R{r}'])
 for values in numbers['TRAINING/'+name].values():
  values['calibration_slope']={'value':-.4 if name=='APPARENT' else .1*r,'status':'ESTIMABLE','reasons':[],'warnings':[]}
rows=f4._f45_o_fit_rows(numbers,manifest)
report=f4._f45_optimism_csv(rows)
value=n._sealed({'kind':'PADML_F45_O_FIT_V1','status':'COMPLETED','source_unit':unit['unit_id'],'input_identity_sha256':manifest['identity_sha256'],'source_receipt_sha256':manifest['source_receipt_sha256'],'contract':f4.f45_optimism_contract(),'interpretation':'FIXED_LOCK_PARAMETERS_FITTING_OPTIMISM','full_data_development_model':False,'new_prediction_model_fits':0,'native_metrics':source['native_metrics'],'numbers':numbers,'report_rows':rows,'csv_sha256':hashlib.sha256(report).hexdigest(),'numerically_estimable_rows':sum(row['status']=='ESTIMABLE' for row in rows)})
folder=ROOT/'postprocess-reader-fixture';folder.mkdir(exist_ok=True)
def publish(v):
 csv=f4._f45_optimism_csv(v['report_rows']);v['csv_sha256']=hashlib.sha256(csv).hexdigest();v=n._sealed({k:x for k,x in v.items() if k!='identity_sha256'})
 (folder/'result.json').write_bytes(canonical_json_bytes(v));(folder/'o-fit.csv').write_bytes(csv)
 return v
value=publish(value)
try:observed=f4.load_f45_postprocess(folder,{},unit,loaded=loaded)
except ContractError as exc:
 print(json.dumps({'status':'BLOCKED','reason':str(exc),'canonical_json_csv_headers_equal':f4._f45_optimism_csv(rows)==f4._f45_optimism_csv(json.loads(canonical_json_bytes(rows)))}));raise
assert observed==value
assert all(row['optimism'] is None for row in observed['report_rows'] if row['metric']=='calibration_slope')
checks={}
for label,mutate in [('mean',lambda v:v['report_rows'][0].update(oof_mean=.999)),('count',lambda v:v.update(numerically_estimable_rows=0))]:
 bad=copy.deepcopy(value);mutate(bad);publish(bad)
 try:f4.load_f45_postprocess(folder,{},unit,loaded=loaded)
 except ContractError as exc:checks[label]={'rejected':True,'reason':str(exc)}
 else:raise AssertionError(label+'_ACCEPTED')
publish(value)
result={'status':'PASS','scope':'PURE_POSTPROCESS_SCHEMA_STITCH_EXISTING_IBS_UNO_NUMBERS_MOCK_SLOPE_NO_R_NO_MODEL_FITS','source_f4_sha256':hashlib.sha256((REPO/'padml/f4.py').read_bytes()).hexdigest(),'canonical_json_csv_roundtrip':True,'finite_negative_slope_retained':True,'slope_optimism_none':True,'negative_checks':checks}
(ROOT/'postprocess-reader-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,sort_keys=True))
