args <- commandArgs(trailingOnly=TRUE)
root <- normalizePath(args[[1]])
source(file.path(root,'f4_metrics.R'))
job <- jsonlite::fromJSON(file.path(root,'job.json'),simplifyVector=FALSE)
rows <- list()
for (h in c(6L,12L,24L,36L)) {
 job$primary_report_horizon_months <- h
 old <- evaluate_job(job)
 new <- evaluate_optimism_job(job)
 for (t in c(6L,12L,24L,36L)) {
   stopifnot(identical(old$horizons[[as.character(t)]]$slope,new$horizons[[as.character(t)]]$calibration_slope$value))
   fixed <- job
   fixed$primary_report_horizon_months <- t
   fixed$survival <- lapply(job$survival,function(x) as.list(rep(unlist(x)[match(h,c(6L,12L,24L,36L))],4L)))
   fixed_matrix <- do.call(rbind,lapply(fixed$survival,unlist,use.names=FALSE))
   reference <- discriminate(fixed_matrix,unlist(fixed$times),unlist(fixed$events),fixed$ipcw,fixed$centers,fixed$censoring_steps,t)
   stopifnot(identical(reference[[paste0('uno_c_',t)]]$value,new$horizons[[as.character(t)]]$uno_c$value))
 }
 stopifnot(identical(old$discrimination[[paste0('uno_c_',h)]]$value,new$horizons[[as.character(h)]]$uno_c$value))
 rows[[as.character(h)]] <- list(slope_4t_bit_identical=TRUE,uno_4t_fixed_risk_bit_identical=TRUE,uno_t_equals_h_bit_identical=TRUE)
}
# Exact original h type boundary: negative diagnostic, not another model case.
bad <- job; bad$primary_report_horizon_months <- 12.9
old_error <- tryCatch({evaluate_job(bad);NULL},error=function(e) conditionMessage(e))
new_error <- tryCatch({evaluate_optimism_job(bad);NULL},error=function(e) conditionMessage(e))
result <- list(status='PASS_NUMERICAL',scope='SYNTHETIC_FIXED_CURVE_METRICS_ONLY_NO_MODEL_FIT',R_version=R.version.string,jsonlite_version=as.character(packageVersion('jsonlite')),survival_version=as.character(packageVersion('survival')),horizon_rows=rows,fractional_horizon=list(old_rejection=old_error,new_rejection=new_error,new_silent_integer_coercion=is.null(new_error)))
jsonlite::write_json(result,file.path(root,'r-result.json'),auto_unbox=TRUE,pretty=TRUE,null='null',digits=NA)
cat(jsonlite::toJSON(result,auto_unbox=TRUE,null='null',digits=NA),'\n')
