import csv, io, json, hashlib, math, pathlib, sys
ROOT=pathlib.Path(__file__).resolve().parent
REPO=pathlib.Path('/Users/liuningyuan/Desktop/Result/Machine Learning/PADML_F45_REBUILD')
sys.path.insert(0,str(REPO))
from padml import f4, f2_kernel as k, nested_loco as n, runtime
from padml.bundle import canonical_json_bytes, ContractError
runtime.RSCRIPT_EXECUTABLE='/usr/local/bin/Rscript'
ids=[f'UNFITTED_{i:03d}' for i in range(180)]
centers=['36']*90+['38']*90
fields=['Patient_ID','All_Cause_Death','Death_Followup_months']
s=io.StringIO(newline='');w=csv.DictWriter(s,fieldnames=fields,lineterminator='\n');w.writeheader()
for i,pid in enumerate(ids):
 j=i%90; e=int(j<60); t=(1+(j%12)*.4 if j<30 else 10+(j%27)) if e else ({60:8.,61:18.,62:28.}.get(j,45.+j%5))
 w.writerow(dict(zip(fields,(pid,str(e),str(t)))))
raw=s.getvalue().encode()
draw=[]
for start in (0,90):
 indices=[i for i in range(start,start+90) if i%3]
 draw.extend(indices+indices[:30])
curves={f:{r:[[math.exp(-(0.003+(i*37%173)*.00018+fi*.00015+(r-2)*.00013)*t) for t in range(37)] for i in range(180)] for r in range(1,4)} for fi,f in enumerate(n._families())}
loaded={'manifest':{'source_unit':'PRIMARY-H12-O1','identity_sha256':'0'*64,'patient_ids':ids,'centers':centers,'selection_horizon_months':12},'draws':{'draws':[draw]},'response_csv':raw,'oof':curves}
pins={name:hashlib.sha256((REPO/name).read_bytes()).hexdigest() for name in ('padml/f4.py','padml/nested_loco.py','padml/kernels/f4_metrics.R')}
result=f4._f45_selection_replicate(1,loaded=loaded,root=ROOT)
assert len(result['selection_evidence'])==7 and len(result['report_rows'])==8
for e in result['selection_evidence']:
 assert e['mean_ibs']==math.fsum(e['repeat_ibs'])/3
 assert e['maximum_ibs']==max(e['repeat_ibs'])
for row in result['report_rows']:
 for label,key in [('INBAG','inbag'),('OOB','oob')]:
  assert row[key]==f4._f45_optimism_mean(row['repeat_values'][label])
assert result['sampling']['INBAG']['draw_count']==180 and result['sampling']['INBAG']['unique_source_patient_count']==120
assert result['oob_count']==60 and result['selected_family'] in n._families()
path=ROOT/'B0001.json';path.write_bytes(canonical_json_bytes(result))
assert f4._f45_read_selection_replicate(path,loaded,1)==result
findings={}
# Pure consumer negatives: deliberately reordered/coherently resealed rows, no metric recomputation.
for label,mutate in (
 ('row_order',lambda d:d.update(report_rows=list(reversed(d['report_rows'])))),
 ('selected_family',lambda d:d.update(selected_family=next(f for f in n._families() if f!=d['selected_family']))),
 ('repeat_value',lambda d:d['report_rows'][0]['repeat_values']['INBAG'].__setitem__(0,.999))):
 changed=json.loads(json.dumps(result));mutate(changed);changed=n._sealed({kk:vv for kk,vv in changed.items() if kk!='identity_sha256'})
 target=ROOT/(label+'.json');target.write_bytes(canonical_json_bytes(changed))
 try:f4._f45_read_selection_replicate(target,loaded,1)
 except ContractError as e:findings[label]={'rejected':True,'reason':str(e)}
 else:findings[label]={'rejected':False}
summary={'scope':'SYNTHETIC_DIRECT_REPLICATE_REAL_IPCW_AND_R_METRICS_NO_MODEL_FITS_NO_ARCHIVE_LOADER','status':'PRODUCER_PASS','source_pins':pins,'selected_family':result['selected_family'],'repeat_mean_max_exact':True,'paired_draw_multiplicity':[180,120,60],'consumer_negatives':findings,'report_ne':[{'t':r['report_month'],'metric':r['metric'],'reasons':r['reasons']} for r in result['report_rows'] if r['status']=='NOT_ESTIMABLE']}
(ROOT/'replicate-result.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,sort_keys=True))
