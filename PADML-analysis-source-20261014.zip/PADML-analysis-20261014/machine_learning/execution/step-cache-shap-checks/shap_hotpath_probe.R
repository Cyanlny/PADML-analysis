#!/usr/bin/env Rscript
# Isolated, one-patient comparison with the original complete background.
# The execution owner admits one worker and supplies the sealed environment.
args <- commandArgs(trailingOnly = TRUE)
stopifnot(length(args) == 3L)
suppressPackageStartupMessages(library(jsonlite))
suppressPackageStartupMessages(library(reticulate))
suppressPackageStartupMessages(library(kernelshap))
stopifnot(as.character(packageVersion("kernelshap")) == "0.9.1")
spec <- fromJSON(args[[1L]], simplifyVector = FALSE)
scalar <- function(x) unname(unlist(x, use.names = FALSE)[[1L]])
stopifnot(scalar(spec$family) == "XGBOOST_COX", !file.exists(args[[3L]]))
use_python(scalar(spec$python_executable), required = TRUE)
bridge <- py_run_string("
import ast, hashlib, importlib.metadata, pathlib, time
from padml import f5
import numpy as np
class Probe:
    def __init__(self, predictor):
        self.predictor = predictor
        self.reset()
        original = predictor._masked_design
        def encode(frame):
            start = time.perf_counter()
            value = original(frame)
            self.encoding_seconds += time.perf_counter() - start
            return value
        predictor._masked_design = encode
    def reset(self):
        self.encoding_seconds = self.prediction_seconds = 0.0
        self.calls = self.rows = self.max_rows = 0
    def predict_survival(self, frame):
        start = time.perf_counter()
        value = self.predictor.predict_survival(frame)
        self.prediction_seconds += time.perf_counter() - start
        self.calls += 1
        self.rows += len(frame)
        self.max_rows = max(self.max_rows, len(frame))
        return value
    def summary(self):
        return {k: getattr(self, k) for k in ('calls', 'rows', 'max_rows',
            'encoding_seconds', 'prediction_seconds')}
def pair(spec_path, candidate_path):
    old_raw = pathlib.Path(f5.__file__).read_bytes()
    assert hashlib.sha256(old_raw).hexdigest() == '17ff0772603392a50fd71a07e6715e348ca81af51c0239ae0f482087a2d6d98a'
    raw = pathlib.Path(candidate_path).read_bytes()
    cls = next(n for n in ast.parse(raw).body if isinstance(n, ast.ClassDef)
               and n.name == '_FinalShapPythonPredictor')
    namespace = dict(vars(f5))
    exec(compile(ast.Module(body=[cls], type_ignores=[]), candidate_path, 'exec'), namespace)
    old = Probe(f5._FinalShapPythonPredictor(spec_path))
    new = Probe(namespace['_FinalShapPythonPredictor'](spec_path))
    return {'old': old, 'new': new, 'old_source_sha256': hashlib.sha256(old_raw).hexdigest(),
        'candidate_sha256': hashlib.sha256(raw).hexdigest(),
        'candidate_class_ast_sha256': hashlib.sha256(ast.dump(cls, include_attributes=False).encode()).hexdigest(),
        'versions': {p: importlib.metadata.version(p) for p in ('numpy','pandas','xgboost')},
        'kernel_path': str(pathlib.Path(f5.__file__).parent / 'kernels' / 'f5_design.R')}
", convert = FALSE)
pair <- bridge$pair(normalizePath(args[[1L]]), normalizePath(args[[2L]]))
source(py_to_r(pair$kernel_path), local = TRUE)
selected <- as.character(unlist(spec$selected_parents, use.names = FALSE))
patient_data <- read.csv(scalar(spec$covariate_path), check.names = FALSE,
                        stringsAsFactors = FALSE, colClasses = "character")
need <- function(value, code) if (!isTRUE(value)) stop(code, call. = FALSE)
prepared <- padml_prepare_final_r_design(patient_data, selected,
    spec$recipe$predictor_rows, spec$recipe$transform_recipe, scalar(spec$family), scalar, need)
background <- prepared$covariates[, selected, drop = FALSE]
stopifnot(nrow(background) > 1L, identical(names(background), selected))
horizons <- c(6L, 12L, 24L, 36L)
names_out <- paste0("t", horizons)
predictor <- function(which) {
  force(which)
  function(object, newdata) {
    value <- as.matrix(py_to_r(which$predict_survival(r_to_py(newdata))))
    stopifnot(identical(dim(value), c(nrow(newdata), 4L)),
              all(is.finite(value)), all(value >= 0 & value <= 1))
    colnames(value) <- names_out
    value
  }
}
old_fun <- predictor(pair$old)
new_fun <- predictor(pair$new)
old_prediction <- old_fun(NULL, background)
new_prediction <- new_fun(NULL, background)
stopifnot(identical(old_prediction, new_prediction))
pair$old$reset(); pair$new$reset()
p <- length(selected)
run <- function(fun) kernelshap(object = NULL, X = background[1L, , drop = FALSE],
    bg_X = background, pred_fun = fun, feature_names = selected,
    bg_w = NULL, bg_n = nrow(background), exact = p <= 8L,
    hybrid_degree = if (p <= 8L) 0L else if (p <= 16L) 2L else 1L,
    m = 2L * p, tol = 0.005, max_iter = 100L, parallel = FALSE,
    verbose = FALSE, seed = as.integer(scalar(spec$seed)))
old_seconds <- system.time(old <- run(old_fun))[["elapsed"]]
new_seconds <- system.time(new <- run(new_fun))[["elapsed"]]
old_profile <- py_to_r(pair$old$summary())
new_profile <- py_to_r(pair$new$summary())
fields <- c("S", "baseline", "predictions", "n_iter", "converged")
stopifnot(all(vapply(fields, function(k) identical(old[[k]], new[[k]]), logical(1))),
    identical(names(new$S), names_out),
    all(vapply(new$S, function(x) identical(colnames(x), selected), logical(1))))
if (p > 8L) stopifnot(all(new$converged), all(new$n_iter >= 2L & new$n_iter <= 100L))
error <- max(vapply(seq_along(horizons), function(j)
    abs(new$baseline[[j]] + sum(new$S[[j]][1L, ]) - new$predictions[1L, j]), numeric(1)))
stopifnot(is.finite(error), error <= 1e-6)
replay_seconds <- system.time(replay <- run(new_fun))[["elapsed"]]
stopifnot(all(vapply(fields, function(k) identical(new[[k]], replay[[k]]), logical(1))))
result <- list(status = "PASS", kind = "BOUNDED_SHAP_HOTPATH_COMPARISON",
    old_source_sha256 = py_to_r(pair$old_source_sha256),
    candidate_sha256 = py_to_r(pair$candidate_sha256),
    candidate_class_ast_sha256 = py_to_r(pair$candidate_class_ast_sha256),
    versions = py_to_r(pair$versions), kernelshap = "0.9.1",
    imputation = scalar(spec$imputation), model_sha256 = scalar(spec$model_sha256),
    explained_patients = 1L, background_patients = nrow(background), parents = p,
    seed = scalar(spec$seed), horizons = horizons, order = c("old", "new", "new_replay"),
    full_background_prediction_byte_equal = TRUE, shap_fields_identical = fields,
    fixed_seed_first_patient_replay_exact = TRUE, n_iter = new$n_iter,
    all_converged = if (p <= 8L) TRUE else all(new$converged),
    maximum_absolute_additivity_error = error,
    maximum_absolute_survival_difference = max(abs(old_prediction - new_prediction)),
    maximum_absolute_shap_difference = max(abs(unlist(old$S) - unlist(new$S))),
    old_seconds = old_seconds, new_seconds = new_seconds, replay_seconds = replay_seconds,
    old_profile = old_profile, new_profile = new_profile,
    model_fits = 0L, mice_chains = 0L, kernelshap_calls = 3L,
    production_results_written = FALSE, whole_unit_completion = FALSE)
writeLines(toJSON(result, auto_unbox = TRUE, null = "null", digits = NA), args[[3L]])
