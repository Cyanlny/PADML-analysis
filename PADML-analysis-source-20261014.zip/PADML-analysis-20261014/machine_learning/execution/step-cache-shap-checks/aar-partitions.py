"""Bounded scope1 engineering comparison; no MICE/model engine invocation."""
import ast
import copy
import csv
import io
import json
import shutil
import subprocess
import sys
import tempfile
import types
from pathlib import Path

REPO = Path(__file__).resolve().parents[2]
sys.dont_write_bytecode = True
sys.path[:0] = [str(REPO), str(REPO/'tests')]
import pytest
from padml import f5_sensitivity as a, f4, f5, nested_loco as nested, runtime
from padml.bundle import ContractError, canonical_json_bytes, sha256_bytes, sha256_file, strict_json_bytes, write_deterministic_zip
import test_nested_aar_mice as fixture
from test_f5 import private_response, valid_unfitted_mice_covariates


def head_function(source, name):
    node = next(n for n in ast.parse(source).body if isinstance(n, ast.FunctionDef) and n.name == name)
    ns = dict(a.__dict__)
    exec(compile(ast.Module(body=[node], type_ignores=[]), 'cc2026cd4d54d94c1d373618983dad18b598c8b5:padml/f5_sensitivity.py', 'exec'), ns)
    original = ns[name]
    result = types.FunctionType(original.__code__, a.__dict__, name, original.__defaults__, original.__closure__)
    result.__kwdefaults__ = original.__kwdefaults__
    return result


def normalize(value, paths):
    if isinstance(value, Path):
        value = str(value)
    if isinstance(value, str):
        for path in paths:
            value = value.replace(str(path), '<TARGET>')
        return value
    if isinstance(value, bytes):
        return value
    if isinstance(value, list):
        return [normalize(item, paths) for item in value]
    if isinstance(value, tuple):
        return tuple(normalize(item, paths) for item in value)
    if isinstance(value, dict):
        return {key: normalize(item, paths) for key, item in value.items()
                if key not in {'scratch_available_bytes', 'readback'}}
    return value


def main():
    baseline = subprocess.check_output(['git', 'show', 'cc2026cd4d54d94c1d373618983dad18b598c8b5:padml/f5_sensitivity.py'], cwd=REPO, text=True)
    old_load = head_function(baseline, '_load_a12_projected_outer_inputs')
    old_materialize = head_function(baseline, '_materialize_a12_projected_branches')
    source_sha = {str(path.relative_to(REPO)): sha256_file(path)
                  for path in [REPO/'padml/f5_sensitivity.py', REPO/'padml/runtime.py']}
    evidence = []
    with tempfile.TemporaryDirectory(prefix='padml-scope1-readback-', dir='/tmp') as temporary, pytest.MonkeyPatch.context() as mp:
        work = Path(temporary).resolve()
        def pure_fixture():
            ids = [f'mice-fixture-{i:04d}' for i in range(420)]
            centers = [[36, 38, 39, 48, 52, 54, 55][i % 7] for i in range(420)]
            return None, valid_unfitted_mice_covariates(ids, centers), private_response(ids, [int(i % 3 != 0) for i in range(420)])
        mp.setattr(fixture, 'native_mice_fixture', pure_fixture)
        mp.setattr(fixture, '_unfitted_confirmed_decision', nested.science_decision_template)
        source = fixture.aar_source.__wrapped__(mp)
        primary_input, primary_archive, policy, _, frozen, _ = fixture._projected_outer_fixture(source, work, mp, 'GBM_COX')
        def deny_engine(*args, **kwargs):
            raise AssertionError('SCIENTIFIC_MICE_OR_MODEL_CALL_FORBIDDEN')
        mp.setattr(a, '_run_a12_total_mice_input', deny_engine)
        projected = work/'projected.zip'
        a.compile_a12_outer_inputs(primary_input, primary_archive, projected, f2_run_root=work,
                                   outer_fold=1, resource_policy=policy)
        mp.setattr(runtime, '_IN_SCIENTIFIC_POOL', True)
        mp.setattr(runtime, '_bounded_ordered_spawn', deny_engine)
        old_target, new_target = work/'opened-old', work/'opened-new'
        old = old_load(projected, old_target)
        captured = []
        actual_readback = runtime._readback_ordered
        def capture_readback(worker, tasks, **kwargs):
            captured.append((worker, tasks, kwargs))
            return actual_readback(worker, tasks, **kwargs)
        mp.setattr(runtime, '_readback_ordered', capture_readback)
        current = a._load_a12_projected_outer_inputs(projected, new_target)
        assert normalize(old, [old_target]) == normalize(current, [new_target])
        print('PASS full projected parent comparison', flush=True)
        read_worker, read_jobs, read_opts = captured.pop()
        assert read_worker is a._a12_projected_input_read_job
        assert len(read_jobs) == 155 and sum(job['kind']=='DIRECT' for job in read_jobs) == 31
        assert all(item is not None for item in [a._a12_projected_input_read_job(job) for job in read_jobs if job['kind']=='VIEW'])
        evidence.append({'case':'old_HEAD_vs_new_projected_parent', 'result':'PASS', 'direct_M20_partitions':31,
                         'view_input_checks':124, 'pool_calls':0, 'scientific_calls':0})
        bad_direct = copy.deepcopy(read_jobs[0])
        bad_direct['record']['fit_covariate_members'][0]['sha256'] = '0'*64
        with pytest.raises(ContractError, match='F5_A12_DIRECT_PARTITION_MISMATCH'):
            a._a12_projected_input_read_job(bad_direct)
        bad_view = copy.deepcopy(next(job for job in read_jobs if job['kind']=='VIEW'))
        bad_view['definition']['fit_ids'] = bad_view['definition']['fit_ids'][:-1]
        with pytest.raises(ContractError, match='F5_A12_PROJECTED_MICE_SOURCE_MISMATCH'):
            a._a12_projected_input_read_job(bad_view)
        evidence.append({'case':'new_input_workers_reject_bad_member_and_view_binding', 'result':'PASS'})

        # Keep OUTER, INNER and STOP pairs in each fresh branch. Every leaf below
        # is explicitly synthetic; the real merge/M20/response/identity bodies run.
        chosen = [current['input']['definitions'][0], current['input']['definitions'][1],
                  next(row for row in current['input']['definitions'] if row['kind']=='STOP')]
        view_ids = {row[key] for row in chosen for key in ('analysis', 'application')}
        input_value = {**current['input'], 'definitions':chosen,
                       'mice_inputs':[row for row in current['input']['mice_inputs'] if row['view_id'] in view_ids]}
        opened = {**current, 'input':input_value, 'retained_mice_gather':True,
                  'retained_primary_source_bundle':work/'UNFITTED-retained-source.zip'}
        fresh = (nested.A12_TOTAL_AAR, nested.WITHIN_FAMILY_NO_AAR_REDEVELOPMENT)
        columns = [name for name in f5.load_science_authority()['science']['mice']['private_handoff']['columns']
                   if name not in {'AST','ALT','AST_ALT'}]
        raw_rows = {row['Patient_ID']:{key:value or '100' for key,value in row.items()}
                    for row in csv.DictReader(io.StringIO(source[1].decode()))}
        archives, numbers, leaf_calls = {}, {}, []
        for record in input_value['mice_inputs']:
            branch, view_id = record['estimand'], record['view_id']
            row = next(row for row in chosen if view_id in (row['analysis'], row['application']))
            ids = row['fit_ids'] if view_id==row['analysis'] else row['application_ids']
            stream = io.StringIO(newline='')
            writer = csv.DictWriter(stream, fieldnames=columns, lineterminator='\n')
            writer.writeheader()
            writer.writerows({name:raw_rows[patient][name] for name in columns} for patient in ids)
            raw = stream.getvalue().encode()
            archive = work/f'UNFITTED-{branch}-{view_id}.zip'
            write_deterministic_zip(archive, {'manifest.json':canonical_json_bytes({'UNFITTED_READBACK_ONLY':view_id}),
                **{f'imputations/imp{i:02d}.csv':raw for i in range(1,21)}})
            archives[branch, view_id] = archive
            numbers[f'{branch}/{view_id}'] = {'UNFITTED_READBACK_ONLY':f'{branch}/{view_id}'}
        by_archive = {path:key for key,path in archives.items()}
        def completed_view_leaf(original, payload, destination, *, retain_evidence=False,
                                collect_numbers=False, numerical_view=None, **kwargs):
            branch, view_id = by_archive[payload]
            assert original == current['root']/next(row['member'] for row in input_value['mice_inputs']
                                                    if (row['estimand'],row['view_id'])==(branch,view_id))
            assert kwargs == {'retained_mice_gather':True, 'retained_primary_source_bundle':opened['retained_primary_source_bundle']}
            assert collect_numbers == (numerical_view is None)
            value = numbers[f'{branch}/{view_id}']
            assert numerical_view is None or numerical_view == value
            leaf_calls.append((branch, view_id, retain_evidence, collect_numbers, copy.deepcopy(kwargs)))
            a.extract_safe_zip(payload, destination, expected_members={'manifest.json', *(f'imputations/imp{i:02d}.csv' for i in range(1,21))}, max_member_bytes=128*1024**2, max_total_bytes=3*1024**3)
            return {'numerical_view':value, 'execution_report':{'UNFITTED_READBACK_ONLY':True}}
        mp.setattr(a, 'materialize_a12_total_mice_view', completed_view_leaf)
        for numeric in (False, True):
            prior_target, after_target = work/f'material-old-{numeric}', work/f'material-new-{numeric}'
            leaf_calls.clear()
            prior = old_materialize(opened, archives, prior_target, retain_evidence=True,
                numerical_views=numbers if numeric else None, branches=fresh)
            prior_calls = copy.deepcopy(leaf_calls)
            leaf_calls.clear()
            after = a._materialize_a12_projected_branches(opened, archives, after_target, retain_evidence=True,
                numerical_views=numbers if numeric else None, branches=fresh)
            assert prior_calls == leaf_calls and len(leaf_calls)==12
            print('PASS ordered leaf calls numeric='+str(numeric), flush=True)
            assert normalize(prior,[prior_target]) == normalize(after,[after_target])
            assert list(after['mice_views']) == list(prior['mice_views'])
            for branch in fresh:
                assert [row['kind'] for row in after['branches'][branch]['partitions']] == ['OUTER','INNER','STOP']
                assert after['branches'][branch]['identity'] == prior['branches'][branch]['identity']
            evidence.append({'case':f'old_HEAD_vs_new_materialize_numeric_{numeric}', 'result':'PASS',
                             'partitions':6, 'views':12, 'M20_csvs':120,
                             'native_leaf':'UNFITTED readback fixture', 'scientific_calls':0})
        part_worker, part_jobs, part_opts = captured.pop()
        assert part_worker is a._a12_projected_partition_read_job and len(part_jobs)==6
        # Directly run the new partition worker with a damaged held-out Center.
        bad_job = dict(part_jobs[0])
        bad_job['root'] = work/'bad-partition'
        bad_job['root'].mkdir()
        base_leaf = completed_view_leaf
        def damaged_leaf(original,payload,destination,**kwargs):
            result = base_leaf(original,payload,destination,**kwargs)
            if destination.name == bad_job['definition']['application']:
                path = destination/'imputations/imp20.csv'
                reader = csv.DictReader(io.StringIO(path.read_text()))
                frame = list(reader)
                row = next(row for row in frame if row['Patient_ID'] in bad_job['definition']['evaluation_ids'])
                row['Center'] = '999'
                with path.open('w', newline='') as handle:
                    writer=csv.DictWriter(handle,fieldnames=reader.fieldnames,lineterminator='\n')
                    writer.writeheader(); writer.writerows(frame)
            return result
        mp.setattr(a,'materialize_a12_total_mice_view',damaged_leaf)
        with pytest.raises(ContractError,match='F5_A12_TOTAL_CHANNEL_OR_PATIENT_DRIFT'):
            part_worker(bad_job)
        mp.setattr(a,'materialize_a12_total_mice_view',base_leaf)
        evidence.append({'case':'new_partition_worker_rejects_damaged_MI20_heldout_Center','result':'PASS'})
        # Nested fallback cannot re-admit or create a nested pool.
        with mp.context() as fallback:
            fallback.setattr(runtime,'observe_execution_resources',deny_engine)
            fallback.setattr(runtime,'_bounded_ordered_spawn',deny_engine)
            view_job=next(job for job in read_jobs if job['kind']=='VIEW')
            assert actual_readback(a._a12_projected_input_read_job,[view_job],policy=policy,root=current['root'])==[True]
        # Non-nested handoff: original admission selects legal task count and
        # orders the same direct workers. A serial pool double isolates spawn.
        pool_calls=[]
        def bounded_pool(worker,tasks,*,selected_slots,execution_report):
            pool_calls.append((worker,len(tasks),selected_slots))
            execution_report.update(status='UNFITTED_SERIAL_POOL_DOUBLE',completed_task_count=len(tasks))
            return [worker(job) for job in tasks]
        with mp.context() as handoff:
            handoff.setattr(runtime,'_IN_SCIENTIFIC_POOL',False)
            handoff.setattr(runtime,'_bounded_ordered_spawn',bounded_pool)
            report={}
            selected=[job for job in read_jobs if job['kind']=='VIEW'][:2]
            assert actual_readback(a._a12_projected_input_read_job,selected,policy=policy,root=current['root'],
                                   retained_bytes=1024,execution_report=report)==[True,True]
            assert pool_calls==[(a._a12_projected_input_read_job,2,2)]
            assert report['effective_policy']['memory_bytes_per_worker']==2*1024**3
            assert report['effective_policy']['memory_reserve_bytes']==1024
            assert report['effective_policy']['scratch_reserve_bytes']==0
        evidence.append({'case':'readback_nested_fallback_and_original_pool_handoff','result':'PASS',
                         'nested_pool_calls':0,'nested_resource_probes':0,'non_nested_tasks':2})
    final_sha={str(path.relative_to(REPO)):sha256_file(path) for path in [REPO/'padml/f5_sensitivity.py',REPO/'padml/runtime.py']}
    result={'scope':'scope1 engineering only','cases':evidence,'source_sha256_start':source_sha,
            'source_sha256_end':final_sha,'clinical_computation':False,'source_written':False}
    Path(__file__).with_suffix('.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(result,ensure_ascii=False,indent=2))

if __name__=='__main__':
    main()
