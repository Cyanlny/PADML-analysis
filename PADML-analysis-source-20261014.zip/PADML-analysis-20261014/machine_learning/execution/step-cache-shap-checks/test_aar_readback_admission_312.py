"""Focused owner regression: synthetic bytes/resources, no scientific calculation."""
from contextlib import ExitStack, nullcontext
from pathlib import Path
from unittest import mock
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from padml import f4, f5, f5_sensitivity as a, runtime, run
from padml.bundle import ContractError

GIB = 1024**3
POLICY = dict(configured_worker_ceiling="EXECUTION_HOST_C_MINUS_8",
    memory_bytes_per_worker=2*GIB, memory_reserve_bytes=GIB,
    scratch_bytes_per_worker=2*GIB, scratch_reserve_bytes=0,
    transfer_archive_worker_ceiling=2147483647)

class PoolReached(Exception):
    pass

class AdmissionReadbackTests(unittest.TestCase):
    def case(self, after=60*GIB, reused_count=0, invalid_readback=False, branches=1):
        events, pools = [], []
        state = {"memory": 60*GIB}
        with tempfile.TemporaryDirectory(prefix="padml-aar-admission-") as tmp, ExitStack() as patches:
            root = Path(tmp).resolve()
            source = root/"source.zip"
            source.write_bytes(b"UNFITTED retained bytes")
            prepared = dict(outer_fold=3, family="COX_PH", input_expansion_resources={},
                source={"resource_policy": POLICY, "identity_sha256": "d"*64})
            names = [f"UNFITTED_BRANCH_{i}" for i in range(branches)]
            def use(obj, name, value):
                patches.enter_context(mock.patch.object(obj, name, value))
            def materialize(source, lineage, destination, **kwargs):
                destination.mkdir(parents=True)
                (destination/"input").write_bytes(b"UNFITTED input")
                return prepared
            def observation(where):
                events.append("observe")
                return dict(effective_cpus=32, available_memory_bytes=state["memory"],
                    scratch_available_bytes=100*GIB, scratch_root=str(where))
            def readback(*args, **kwargs):
                events.append("readback")
                if invalid_readback:
                    raise ContractError("UNFITTED_NUMERICAL_DEPENDENCY_INVALID")
                state["memory"] = 64*1024
                return {"retained": source}
            def release(files, *, owner, report_root, **kwargs):
                events.append("clear")
                self.assertEqual(files, [source])
                self.assertTrue(owner.startswith("AAR_FINAL_PRE_ADMISSION:"))
                self.assertEqual(report_root, root/"result.zip.work")
                self.assertEqual(source.read_bytes(), b"UNFITTED retained bytes")
                state["memory"] = after
                return {"status": "ADVICE_ONLY"}
            def pool(active, reused, capacity, record):
                events.append("pool")
                pools.append(dict(capacity=capacity, reused=len(reused), admission=record["resource_admission"]))
                self.assertEqual(events[-4:], ["readback", "clear", "observe", "pool"])
                if len(pools) == branches:
                    raise PoolReached
                return []
            use(f5, "_full_score_scratch", lambda p: nullcontext())
            use(f4, "_f45_source_member_sha256", lambda: {"UNFITTED": "f"*64})
            use(a, "materialize_a12_outer_inputs", materialize)
            use(a, "_a12_final_task_coordinates", lambda *args: [])
            use(a, "_a12_branch_names", lambda p: names)
            use(a, "_a12_projected_development_inputs", lambda p, *args, **kwargs: p)
            use(a, "_a12_outer_searches", lambda *args, **kwargs: {})
            use(a, "_a12_outer_model_jobs", lambda p, s, *, branch: [
                {"name": f"{branch}_{i}"} for i in range(20)])
            use(a, "_prepare_a12_final_reuse", lambda p, r, active: {
                job["name"]: {} for job in active[:reused_count]})
            use(a, "_a12_outer_retained_members", readback)
            use(a, "_a12_final_resource_reservation", lambda *args, **kwargs: {"effective_policy": POLICY})
            use(a, "_a12_execute_final_pool", pool)
            use(runtime, "observe_execution_resources", observation)
            use(runtime, "observe_step_memory", lambda: {"started_ns": 1})
            use(runtime, "release_f45_cumulative_files", release)
            expected = "UNFITTED_NUMERICAL_DEPENDENCY_INVALID" if invalid_readback else (
                "RESOURCE_ADMISSION_ZERO" if after < 3*GIB else None)
            if expected:
                with self.assertRaisesRegex(ContractError, expected):
                    a.execute_a12_outer_bundle(source, root/"result.zip", input_bundle=source,
                        retained_bytes_per_component=1)
            else:
                with self.assertRaises(PoolReached):
                    a.execute_a12_outer_bundle(source, root/"result.zip", input_bundle=source,
                        retained_bytes_per_component=1)
            self.assertEqual(source.read_bytes(), b"UNFITTED retained bytes")
        return events, pools

    def test_each_branch_clears_readback_before_twenty_legal_tasks(self):
        events, pools = self.case(branches=2)
        self.assertEqual(events.count("clear"), 2)
        self.assertEqual([p["capacity"] for p in pools], [20, 20])
        self.assertTrue(all(p["admission"]["limits"]["cpu_c_minus_8"] == 24 for p in pools))

    def test_completed_reuse_is_removed_from_legal_task_count(self):
        _, pools = self.case(reused_count=6)
        self.assertEqual(pools[0]["capacity"], 14)
        self.assertEqual(pools[0]["reused"], 6)

    def test_remaining_memory_constraint_is_recorded(self):
        _, pools = self.case(after=13*GIB)
        self.assertEqual(pools[0]["capacity"], 6)
        self.assertEqual(pools[0]["admission"]["limits"]["memory"], 6)

    def test_advice_failure_to_free_memory_does_not_bypass_admission(self):
        events, pools = self.case(after=2*GIB)
        self.assertEqual(events.count("clear"), 1)
        self.assertEqual(pools, [])

    def test_invalid_numerical_dependency_never_enters_pool(self):
        events, pools = self.case(invalid_readback=True)
        self.assertNotIn("clear", events)
        self.assertEqual(pools, [])

class PredecessorBoundTests(unittest.TestCase):
    def chain(self, count):
        value = {"identity": "first"}
        for i in range(count):
            value = {"identity": str(i), "unit_predecessor": {"fixture": value}}
        return value

    def test_twelve_reviewed_executors_fit_but_thirteen_remain_bounded(self):
        with mock.patch.object(run, "f45_unit_predecessor", lambda v: v["unit_predecessor"]["fixture"]):
            self.assertEqual(len(run.f45_unit_predecessors(self.chain(12))), 12)
            with self.assertRaisesRegex(ContractError, "PREDECESSOR_CHAIN_INVALID"):
                run.f45_unit_predecessors(self.chain(13))

    def test_cycle_remains_rejected(self):
        value = self.chain(1)
        value["unit_predecessor"]["fixture"]["unit_predecessor"] = {"fixture": value}
        with mock.patch.object(run, "f45_unit_predecessor", lambda v: v["unit_predecessor"]["fixture"]):
            with self.assertRaisesRegex(ContractError, "PREDECESSOR_CHAIN_INVALID"):
                run.f45_unit_predecessors(value)

class QFirstBatchReadbackTests(unittest.TestCase):
    def case(self, after=60*GIB, batches=1):
        from padml import f2_kernel as k
        events, ceilings = [], []
        memory = {"available": 1}
        with tempfile.TemporaryDirectory(prefix="padml-q-cache-boundary-") as tmp, ExitStack() as patches:
            root = Path(tmp).resolve()
            source = root / "input.json"
            source.write_bytes(b"UNFITTED reuse-key input")
            state = {"coordinates": {}, "references": {}}
            control = dict(root=str(root), cache=str(root), read_only=False, workers=24, resource_policy=POLICY)
            spec = {"current_q": control}
            def numerical_atom(task):
                raise AssertionError("No numerical fit is permitted in this boundary fixture")
            def reuse_key(spec, function, call):
                self.assertEqual(source.read_bytes(), b"UNFITTED reuse-key input")
                events.append("key_read")
                if not state["coordinates"]:
                    memory["available"] = 1
                return call["task_id"]
            def release(files, *, owner, report_root, **kwargs):
                self.assertEqual(report_root, root)
                events.append("pre_clear" if owner.startswith("Q_PRE_ADMISSION:") else "post_clear")
                memory["available"] = after
                return {"report_path": str(root / ("pre.json" if owner.startswith("Q_PRE_ADMISSION:") else "post.json")),
                        "cumulative": {"status": "UNKNOWN"}}
            def observe(where):
                events.append("observe")
                return dict(effective_cpus=32, available_memory_bytes=memory["available"],
                    scratch_available_bytes=100*GIB, scratch_root=str(where))
            def pool(function, jobs, *, selected_slots, execution_report):
                self.assertIs(function, f5._current_q_atom)
                events.append("pool")
                ceilings.append(selected_slots)
                return [{"key": job["key"], "root": str(root), "value": job["call"]["task_id"]} for job in jobs]
            for obj, name, value in (
                (f5, "_current_q_reuse_key", reuse_key),
                (f5, "_current_q_import", lambda root, answer, state: answer["key"]),
                (f5, "_current_q_row", lambda spec, function, call, value: value),
                (runtime, "release_f45_cumulative_files", release),
                (runtime, "release_completed_files", lambda *a, **k: {}),
                (runtime, "observe_execution_resources", observe),
                (k, "_bounded_ordered_spawn", pool)):
                patches.enter_context(mock.patch.object(obj, name, value))
            patches.enter_context(mock.patch.dict(f5._CURRENT_Q_STATE, {str(root): state}))
            for batch in range(batches):
                calls = [{"task_id": "UNFITTED_" + str(batch*32+i)} for i in range(32)]
                if after < 3*GIB:
                    with self.assertRaisesRegex(ContractError, "RESOURCE_ADMISSION_ZERO"):
                        f5._current_q_task_batch(spec, numerical_atom, calls, selected_slots=24)
                    self.assertEqual(state["coordinates"], {})
                else:
                    self.assertEqual(f5._current_q_task_batch(spec, numerical_atom, calls, selected_slots=24),
                                     [call["task_id"] for call in calls])
            import json
            reports = [json.loads(path.read_bytes()) for path in root.glob("batch-resources-*.json")]
            self.assertEqual(sum(row["pre_admission_resource_release_report"] is not None for row in reports),
                             1 if reports else 0)
            self.assertEqual(source.read_bytes(), b"UNFITTED reuse-key input")
        return events, ceilings

    def test_first_resume_batch_clears_after_keys_later_batch_uses_existing_tail(self):
        events, ceilings = self.case(batches=2)
        self.assertEqual(ceilings, [24, 24])
        self.assertEqual(events, ["key_read"]*32 + ["pre_clear", "observe", "pool", "post_clear"]
            + ["key_read"]*32 + ["observe", "pool", "post_clear"])

    def test_unknown_advice_keeps_real_memory_limit(self):
        _, ceilings = self.case(after=13*GIB)
        self.assertEqual(ceilings, [6])

    def test_unknown_advice_with_zero_memory_never_spawns(self):
        events, ceilings = self.case(after=2*GIB)
        self.assertEqual(ceilings, [])
        self.assertEqual(events[-2:], ["pre_clear", "observe"])

    def test_ordinary_complex_branch_has_no_unused_entry_admission(self):
        with tempfile.TemporaryDirectory(prefix="padml-q-entry-") as tmp, ExitStack() as patches:
            root = Path(tmp).resolve()
            branch = "UNFITTED_BRANCH"
            prepared = {"family": "RSF", "source": {"resource_policy": POLICY}, "branch_development": {branch: {}}}
            def search(prepared, name, destination, **kwargs):
                self.assertEqual(kwargs["workers"], 24)
                raise PoolReached
            for obj, name, value in (
                (a, "_a12_branch_names", lambda prepared: (branch,)),
                (a, "_a12_branch_search_inputs", lambda *a, **k: None),
                (a, "_a12_complex_search_program", search),
                (a, "resolve_pool_workers", lambda workers: 24),
                (f5, "_full_score_scratch", lambda root: nullcontext()),
                (runtime, "observe_execution_resources", mock.Mock(side_effect=AssertionError("unused entry admission")))):
                patches.enter_context(mock.patch.object(obj, name, value))
            with self.assertRaises(PoolReached):
                a._a12_outer_searches(prepared, root, replay=False)

class CompletedReadbackTailTests(unittest.TestCase):
    def test_successful_pool_clears_without_discarding_results_or_nesting(self):
        events, result = [], [{"UNFITTED": [1, 2, 3]}]
        root = Path("/tmp/UNFITTED")
        def pool(function, tasks, **kwargs):
            events.append("pool_exited")
            return result
        def clear(files, *, owner, report_root, **kwargs):
            self.assertEqual(events, ["pool_exited"])
            self.assertEqual(files, [])
            self.assertEqual(owner, "READBACK:abs")
            self.assertEqual(report_root, root)
            self.assertNotIn("released_references", kwargs)
            events.append("clear")
            return {"cumulative": {"status": "UNKNOWN"}}
        observation = dict(effective_cpus=32, available_memory_bytes=60*GIB,
                           scratch_available_bytes=100*GIB, scratch_root=str(root))
        with mock.patch.object(runtime, "_IN_SCIENTIFIC_POOL", False), \
             mock.patch.object(runtime, "_bounded_ordered_spawn", pool), \
             mock.patch.object(runtime, "observe_execution_resources", return_value=observation), \
             mock.patch.object(runtime, "release_f45_cumulative_files", clear):
            self.assertIs(runtime._readback_ordered(abs, [-1], policy=POLICY, root=root), result)
        self.assertEqual(events, ["pool_exited", "clear"])
        with mock.patch.object(runtime, "_IN_SCIENTIFIC_POOL", True), \
             mock.patch.object(runtime, "_bounded_ordered_spawn", side_effect=AssertionError("nested pool")), \
             mock.patch.object(runtime, "release_f45_cumulative_files", side_effect=AssertionError("worker clear")):
            self.assertEqual(runtime._readback_ordered(abs, [-1], policy=POLICY, root=root), [1])

    def test_shared_context_diagnostics_use_existing_unit_owner(self):
        import os
        from padml.bundle import canonical_json_bytes
        with tempfile.TemporaryDirectory(prefix="padml-shared-readback-") as tmp:
            base = Path(tmp).resolve()
            unit = base / "units" / "FULL0-H06"
            unit.mkdir(parents=True)
            shared = base / "contexts" / "FULL0" / "common" / "UNFITTED-search"
            shared.mkdir(parents=True)
            data = shared / "imp01.csv"
            data.write_bytes(b"UNFITTED INPUT")
            (base / "active.lock").write_bytes(canonical_json_bytes({"unit_id": unit.name}) + b'{"pgid":123}\n')
            def release(files, **kwargs):
                self.assertIn(data, files)
                self.assertEqual(kwargs["report_root"], unit)
                return {}
            with mock.patch.dict(os.environ, {"PADML_F45_RUN_PATH": str(base / "run.json")}), \
                 mock.patch.object(os, "sync", create=True), \
                 mock.patch.object(Path, "write_text", side_effect=PermissionError("UNFITTED drop_caches denied")), \
                 mock.patch.object(runtime, "release_completed_files", side_effect=release):
                report = runtime.release_f45_cumulative_files([], owner="READBACK:UNFITTED", report_root=shared)
            self.assertEqual(report["cumulative"]["global_cache"]["status"], "FAILED")
            self.assertEqual(data.read_bytes(), b"UNFITTED INPUT")
            self.assertFalse((shared / "resource-release").exists())

if __name__ == "__main__":
    unittest.main(verbosity=2)
