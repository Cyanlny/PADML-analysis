"""Bounded engineering I/O only; no clinical input, MICE, fitting or remote use."""
import json
import os
from pathlib import Path
import sys
import tempfile
from time import perf_counter
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from padml import runtime as rt, worker, f5
from padml.bundle import ContractError


def main():
    assert sys.version_info[:2] == (3, 12)
    policy = dict(configured_worker_ceiling=rt.CPU_MINUS_8, memory_bytes_per_worker=2 * 1024**3,
        memory_reserve_bytes=0, scratch_bytes_per_worker=1024**2, scratch_reserve_bytes=0,
        transfer_archive_worker_ceiling=2147483647)
    with tempfile.TemporaryDirectory(prefix="padml-completed-io-") as temporary:
        root = Path(temporary).resolve()
        members = {}
        for i in range(64):
            path = root / f"retained-{i:03d}.bin"
            path.write_bytes(bytes([i]) * (64 * 1024 + i))
            members[path.name] = path
        started = perf_counter()
        with patch.object(rt, "_IN_SCIENTIFIC_POOL", True):
            serial = worker._f45_file_pins(members, policy=policy, root=root)
        serial_seconds = perf_counter() - started
        groups, reports = [], []
        original = rt._bounded_ordered_spawn
        def observed_pool(function, tasks, **kwargs):
            value = original(function, tasks, **kwargs)
            reports.append(kwargs["execution_report"])
            return value
        started = perf_counter()
        with patch.object(rt, "_POOL_GROUP_OBSERVER", groups.append), patch.object(rt, "_bounded_ordered_spawn", observed_pool):
            parallel = worker._f45_file_pins(members, policy=policy, root=root)
        parallel_seconds = perf_counter() - started
        assert parallel == serial and list(parallel) == list(serial)
        assert groups and reports[0]["status"] == "COMPLETED"
        assert len(groups) == reports[0]["actual_worker_process_peak"]
        assert reports[0]["actual_worker_process_peak"] <= reports[0]["admitted_worker_ceiling"] <= rt.effective_cpu_count() - 8
        observation = dict(effective_cpus=32, available_memory_bytes=64 * 1024**3,
            scratch_available_bytes=1024**4, scratch_root=str(root))
        admission = rt.resource_admission(policy, observation, legal_tasks=124)
        assert admission["admitted_worker_ceiling"] == 24
        assert rt.resource_admission(policy, observation, legal_tasks=15)["admitted_worker_ceiling"] == 15
        # Ordinary worker reuse takes the inline branch, without a nested pool or observation.
        with patch.object(rt, "_IN_SCIENTIFIC_POOL", True), patch.object(rt, "observe_execution_resources", side_effect=AssertionError("nested admission")), patch.object(rt, "_bounded_ordered_spawn", side_effect=AssertionError("nested pool")):
            assert rt._readback_ordered(abs, [-3, -1, -2], policy=policy, root=root) == [3, 1, 2]
        with patch.object(rt, "observe_execution_resources", return_value={**observation, "available_memory_bytes": 1}), patch.object(rt, "_bounded_ordered_spawn", side_effect=AssertionError("zero pool")):
            try:
                rt._readback_ordered(abs, [-1], policy=policy, root=root)
            except ContractError as exc:
                assert str(exc).startswith("RESOURCE_ADMISSION_ZERO")
            else:
                raise AssertionError("zero memory accepted")
        print(json.dumps(dict(status="PASS", python=sys.version, host=sys.platform,
            local_cpus=os.cpu_count(), simulated_observation=rt.observe_execution_resources(root), pool=reports[0],
            registered_worker_groups=len(groups), serial_seconds=serial_seconds,
            parallel_seconds=parallel_seconds, same_input_bytes=sum(row["size_bytes"] for row in serial.values()),
            input_files=len(serial), configured_c32_ceiling=24, single_pool_nested_inline=True,
            zero_admission_rejected=True, new_fits=0, new_mice=0,
            limitations="Small local synthetic I/O; simulated C11 admits at most 3 real spawn workers. No production speedup, Linux RSS or clinical equivalence claim.")))


if __name__ == "__main__":
    # The Mac has eight CPUs: its real geometry correctly rejects production.
    # A bounded C11 fixture exercises three real processes without remote work.
    def local_fixture(root):
        return dict(effective_cpus=11, available_memory_bytes=64 * 1024**3,
            scratch_available_bytes=1024**4, scratch_root=str(root))
    with patch.object(rt, "effective_cpu_count", return_value=11), patch.object(rt, "observe_execution_resources", side_effect=local_fixture):
        main()
