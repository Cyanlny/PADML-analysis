import ast,contextlib,copy,hashlib,inspect,json,sys,unittest,zipfile,tempfile,subprocess,shutil
from pathlib import Path
from unittest.mock import patch
CHECKS=Path(__file__).resolve().parent
REPO=CHECKS.parents[1]
ROOT=Path(tempfile.mkdtemp(prefix='full0-readback-check-')).resolve()
sys.path.insert(0,str(REPO))
from padml import f5,runtime,nested_loco
from padml.bundle import ContractError,canonical_json_bytes,sha256_bytes
POLICY={'configured_worker_ceiling':'EXECUTION_HOST_C_MINUS_8','memory_bytes_per_worker':2*1024**3,'scratch_bytes_per_worker':2*1024**3,'memory_reserve_bytes':1024**3,'scratch_reserve_bytes':0,'transfer_archive_worker_ceiling':2147483647}
DETAILS={}
def functions(raw): return {x.name:x for x in ast.parse(raw).body if isinstance(x,(ast.FunctionDef,ast.AsyncFunctionDef))}
OLD=functions(subprocess.check_output(['git','show','cc2026cd4d54d94c1d373618983dad18b598c8b5:padml/f5.py'],cwd=REPO,text=True))
NEW=functions((REPO/'padml/f5.py').read_text())
def dump(value): return ast.dump(value,include_attributes=False)
def observation(root): return {'effective_cpus':32,'available_memory_bytes':64*1024**3,'scratch_available_bytes':100*1024**3,'scratch_root':str(root)}
def inline_pool(worker,tasks,**kwargs):
    DETAILS.setdefault('pool_calls',[]).append({'worker':worker.__name__,'tasks':len(tasks),'slots':kwargs['selected_slots']})
    return [worker(task) for task in tasks]
class ReadbackTests(unittest.TestCase):
    def test_01_original_science_bodies_and_moved_family_call_equal(self):
        for name in ('materialize_full_data_search_partition','_extract_full_data_mice_view','materialize_final_full_data_mice'):
            self.assertEqual(dump(OLD[name]),dump(NEW[name]),name)
        old_nested=functions(subprocess.check_output(['git','show','cc2026cd4d54d94c1d373618983dad18b598c8b5:padml/nested_loco.py'],cwd=REPO,text=True))
        new_nested=functions((REPO/'padml/nested_loco.py').read_text())
        self.assertEqual(dump(old_nested['_recompute_fresh_score_from_evidence']),dump(new_nested['_recompute_fresh_score_from_evidence']))
        original=next(x for x in ast.walk(OLD['_full_data_locked_score_program']) if isinstance(x,ast.For) and isinstance(x.iter,ast.Call) and isinstance(x.iter.func,ast.Attribute) and dump(x.iter.func.value)==dump(ast.Name(id='retained_families',ctx=ast.Load())))
        worker=NEW['_completed_score_family_read_job']
        checked=next(x for x in worker.body if isinstance(x,ast.Assign) and isinstance(x.targets[0],ast.Name) and x.targets[0].id=='checked')
        evidence_loop=next(x for x in worker.body if isinstance(x,ast.For))
        self.assertEqual(dump(original.body[1]),dump(checked))
        self.assertEqual(dump(original.body[3]),dump(evidence_loop))
        DETAILS['science_bodies']='exact AST equality: 3 MICE readers + nested recompute; moved call/evidence loop exact'
    def test_02_parent_split_jobs_match_original_bindings_and_order(self):
        work=ROOT/'partitions';work.mkdir()
        members={};pairs=[]
        for i in range(1,16):
            split=f'R{(i-1)//5+1}_K{(i-1)%5+1}';stop=split+'_STOP'
            pairs.append({'split_id':split,'stopping':{'partition_id':stop},'stop_mice':{}})
            for name in (split,stop):
                for role in ('analysis','application'):
                    path=work/(name+'_'+role+'.zip')
                    with zipfile.ZipFile(path,'w') as archive:
                        for m in range(1,21): archive.writestr(f'imputations/imp{m:02d}.csv',f'UNFITTED,{i},{m}\n')
                    members[name+'/'+role+'.zip']=path
        plan={'split_pairs':pairs};response=b'PRIVATE_RESPONSE_SENTINEL'
        signature=inspect.signature(f5.materialize_full_data_search_partition)
        def unchanged_reader(*args,**kwargs):
            values=signature.bind(*args,**kwargs);values.apply_defaults();row=dict(values.arguments)
            self.assertIs(row.pop('response_csv'),response)
            row['destination']=row['destination'].name
            return row
        old=copy.deepcopy(OLD['_materialize_final_search_inputs']);old.name='_old_materialize_for_audit'
        ns=dict(f5.__dict__);ns['materialize_full_data_search_partition']=unchanged_reader
        ns['_final_search_mice_members']=lambda *args,**kwargs:members
        exec(compile(ast.fix_missing_locations(ast.Module(body=[old],type_ignores=[])),'old-materializer','exec'),ns)
        with patch.object(f5,'_final_search_mice_members',return_value=members),patch.object(f5,'materialize_full_data_search_partition',side_effect=unchanged_reader),patch.object(runtime,'observe_execution_resources',side_effect=observation),patch.object(runtime,'_bounded_ordered_spawn',side_effect=inline_pool):
            for stop in (False,True):
                expected=ns['_old_materialize_for_audit'](plan,work,response,work/('old-'+str(stop)),include_stop=stop,retain_evidence=True)
                actual=f5._materialize_final_search_inputs(plan,work,response,work/('new-'+str(stop)),include_stop=stop,retain_evidence=True,resource_policy=POLICY)
                self.assertEqual(expected,actual)
                self.assertEqual([r['split_id'] for r in actual],[p['split_id'] for p in pairs])
        DETAILS['partition_jobs']='15 canonical split bindings equal original for INNER-only and INNER+STOP; response_csv preserved'
    def test_03_real_parent_family_fragment_and_wrapper(self):
        work=ROOT/'scores';work.mkdir()
        retained={}
        for family in ('RSF','COX_PH'):
            directory=work/'score-evidence'/family;directory.mkdir(parents=True)
            raw=('UNFITTED_'+family).encode();path=directory/'R1_K1_M01.json';path.write_bytes(raw)
            evidence={'component_evidence_records':[{'path':'components/score-evidence/'+family+'/'+path.name,'size_bytes':len(raw),'sha256':sha256_bytes(raw)}]}
            retained[family]=({'family':family},evidence)
        nodes=NEW['_full_data_locked_score_program'].body
        # Locate the exact body fragment inside its original try.
        body=next(x.body for x in nodes if isinstance(x,ast.Try))
        start=next(i for i,x in enumerate(body) if isinstance(x,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='checked_families' for t in x.targets))
        end=next(i for i,x in enumerate(body[start:],start) if isinstance(x,ast.Expr) and isinstance(x.value,ast.Call) and isinstance(x.value.func,ast.Attribute) and isinstance(x.value.func.value,ast.Name) and x.value.func.value.id=='checked_families')
        admitted=[];calls=[]
        def original_numeric_reader(**kwargs):
            inspect.signature(nested_loco._recompute_fresh_score_from_evidence_original).bind(**kwargs)
            calls.append(kwargs);return kwargs['score']
        nested_loco._recompute_fresh_score_from_evidence_original=nested_loco._recompute_fresh_score_from_evidence
        ns=dict(f5.__dict__);ns.update(retained_families=retained,admit_score_context=admitted.append,request={'UNFITTED_REQUEST':True,'training_context':{'training_ids':['UNFITTED_A','UNFITTED_B']},'score_partitions':[{'evaluation_ids':['UNFITTED_A']}]},reservation={'effective_policy':POLICY},root=work,expanded_bytes_per_component=1024,retained_bytes_per_component=2048,retained_fixed_requests={},resource_policy=POLICY)
        with patch.object(nested_loco,'_recompute_fresh_score_from_evidence',side_effect=original_numeric_reader),patch.object(runtime,'observe_execution_resources',side_effect=observation),patch.object(runtime,'_bounded_ordered_spawn',side_effect=inline_pool):
            exec(compile(ast.fix_missing_locations(ast.Module(body=body[start:end+1],type_ignores=[])),'actual-family-parent-fragment','exec'),ns)
        self.assertEqual(admitted,list(retained));self.assertEqual(list(ns['checked_families']),list(retained))
        self.assertEqual([c['score']['family'] for c in calls],list(retained))
        self.assertTrue(all('replay_models' not in c and c['request_root']==work/'request' for c in calls))
        wrong=next(iter(retained.values()))[1]['component_evidence_records'][0];wrong['sha256']='0'*64
        job={'family':'RSF','score':retained['RSF'][0],'evidence':retained['RSF'][1],'request':{},'root':work,'expanded':1024,'retained':2048,'retained_fixed_requests':{}}
        with patch.object(nested_loco,'_recompute_fresh_score_from_evidence',return_value={'family':'RSF'}),self.assertRaisesRegex(ContractError,'NESTED_FULL_SCORE_EVIDENCE_REPLAY_DRIFT'):
            f5._completed_score_family_read_job(job)
        with patch.object(nested_loco,'_recompute_fresh_score_from_evidence',side_effect=ContractError('ORIGINAL_NUMERICAL_FAILURE')),self.assertRaisesRegex(ContractError,'ORIGINAL_NUMERICAL_FAILURE'):
            f5._completed_score_family_read_job(job)
        DETAILS['family_readback']='actual parent AST + exact new worker; order kept; kwargs bind original; evidence and numerical failures reject'
    def test_04_nested_worker_inlines_without_second_observation_or_pool(self):
        with patch.object(runtime,'_IN_SCIENTIFIC_POOL',True),patch.object(runtime,'observe_execution_resources',side_effect=AssertionError('nested observation forbidden')),patch.object(runtime,'_bounded_ordered_spawn',side_effect=AssertionError('nested pool forbidden')):
            self.assertEqual(runtime._readback_ordered(lambda x:x*2,[3,1,2],policy=POLICY,root=ROOT),[6,2,4])
    def test_05_zero_memory_workers_rejected(self):
        with patch.object(runtime,'observe_execution_resources',return_value={**observation(ROOT),'available_memory_bytes':2*1024**3}),patch.object(runtime,'_bounded_ordered_spawn',side_effect=AssertionError('zero-capacity pool forbidden')),self.assertRaisesRegex(ContractError,'RESOURCE_ADMISSION_ZERO'):
            runtime._readback_ordered(lambda x:x,[1],policy=POLICY,root=ROOT)
if __name__=='__main__':
    suite=unittest.defaultTestLoader.loadTestsFromTestCase(ReadbackTests)
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    DETAILS.update(tests_run=result.testsRun,failures=len(result.failures),errors=len(result.errors),clinical_calls=0,native_model_calls=0,real_pool_processes=0,scope='synthetic I/O + mocked scientific reader/pool; original AST comparison; actual admission; not numerical equivalence or Linux peak measurement')
    (CHECKS/'full0-results.json').write_text(json.dumps(DETAILS,indent=2)+'\n')
    shutil.rmtree(ROOT)
    sys.exit(not result.wasSuccessful())
