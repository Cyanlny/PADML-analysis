"""Completed-Q readback only. Synthetic bytes; no fitting or native object load."""
import ast
import copy
import json
import shutil
import subprocess
import sys
import tempfile
import types
from pathlib import Path
REPO=Path(__file__).resolve().parents[2]
sys.dont_write_bytecode=True
sys.path[:0]=[str(REPO)]
import pytest
from padml import f4_compact as q, runtime
from padml.bundle import ContractError,canonical_json_bytes,sha256_bytes,sha256_file

def old_function():
    source=subprocess.check_output(['git','show','cc2026cd4d54d94c1d373618983dad18b598c8b5:padml/f4_compact.py'],cwd=REPO,text=True)
    node=next(n for n in ast.parse(source).body if isinstance(n,ast.FunctionDef) and n.name=='_full_pipeline_q_numerical_members')
    namespace=dict(q.__dict__)
    exec(compile(ast.Module(body=[node],type_ignores=[]),'cc2026cd4d54d94c1d373618983dad18b598c8b5:padml/f4_compact.py','exec'),namespace)
    original=namespace[node.name]
    result=types.FunctionType(original.__code__,q.__dict__,node.name,original.__defaults__,original.__closure__)
    result.__kwdefaults__=original.__kwdefaults__
    return result

def main():
    old=old_function()
    fingerprint=sha256_file(REPO/'padml/f4_compact.py')
    evidence=[]
    with tempfile.TemporaryDirectory(prefix='padml-q-readback-',dir='/tmp') as temporary, pytest.MonkeyPatch.context() as mp:
        root=Path(temporary).resolve()
        prior=root/'old'; after=root/'new'
        files={'input.json':b'{"UNFITTED_INPUT_ONLY":true}\n','result.json':b'{"UNFITTED_RESULT_ONLY":true}\n',
               'native/A/a.json':b'{"UNFITTED_NUMBER_ONLY":1}\n',
               'native/A/model.rds':b'UNFITTED_R_MODEL_PLACEHOLDER',
               'native/A/child/model.bin':b'UNFITTED_PYTHON_MODEL_PLACEHOLDER',
               'native/A/child/baseline.bin':b'UNFITTED_PYTHON_BASELINE_PLACEHOLDER',
               'native/A/child/numbers.json':b'{"UNFITTED_NUMBER_ONLY":2}\n'}
        for directory in (prior,after):
            for name,raw in files.items():
                path=directory/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(raw)
        old_members,old_refs=old(prior,publish=True)
        new_members,new_refs=q._full_pipeline_q_numerical_members(after,publish=True)
        assert list(old_members)==list(new_members) and old_refs==new_refs
        assert [old_members[name].read_bytes() for name in old_members]==[new_members[name].read_bytes() for name in new_members]
        # Deliberate old-order edge: A/a.json occurs before child native objects,
        # while A/model.rds occurs after the child; audits must be child then A.
        assert [name for name in new_members if name.endswith('/object-audit.json')]==['native/A/child/object-audit.json','native/A/object-audit.json']
        evidence.append({'case':'old_HEAD_vs_new_publication_bytes_and_order','result':'PASS','members':len(new_members)})
        # Delete complete native object pairs: original projection contract
        # permits this and a readback can now only succeed without opening them.
        for name in files:
            if Path(name).suffix=='.rds' or Path(name).name in {'model.bin','baseline.bin'}:
                (after/name).unlink()
        policy={'configured_worker_ceiling':'EXECUTION_HOST_C_MINUS_8','memory_bytes_per_worker':1,
                'scratch_bytes_per_worker':1,'memory_reserve_bytes':0,'scratch_reserve_bytes':0,
                'transfer_archive_worker_ceiling':1000}
        mp.setattr(runtime,'effective_cpu_count',lambda:32)
        mp.setattr(runtime,'observe_execution_resources',lambda target:{'effective_cpus':32,
            'available_memory_bytes':60*1024**3,'scratch_available_bytes':10**10,'scratch_root':str(target)})
        captured=[]
        original_readback=runtime._readback_ordered
        def capture(worker,tasks,**kwargs):
            report={};captured.append((worker,tasks,report))
            return original_readback(worker,tasks,execution_report=report,**kwargs)
        mp.setattr(runtime,'_readback_ordered',capture)
        members,refs=q._full_pipeline_q_numerical_members(after,resource_policy=policy)
        assert list(members)==list(old_members) and refs==old_refs
        worker,tasks,report=captured.pop()
        assert worker is q._q_coordinate_read_job and len(tasks)==3
        assert report['pool']['completed_task_count']==3 and report['pool']['actual_worker_process_peak']<=3
        assert report['pool']['status']=='COMPLETED'
        evidence.append({'case':'completed_Q_actual_ordered_spawn_native_objects_absent','result':'PASS',
                         'groups':3,'actual_workers':report['pool']['actual_worker_process_peak'],
                         'scientific_calls':0,'admission_observation':'synthetic bounded test'})
        job=next(job for job in tasks if 'native/A/a.json' in job['refs'])
        projection,objects=worker(job)
        assert 'native/A/a.json' in projection and objects['native/A']
        path=after/'native/A/a.json';saved=path.read_bytes();path.write_bytes(saved.replace(b'1',b'9'))
        with pytest.raises(ContractError,match='F4_COMPACT_Q_VALUE_BYTES_MISMATCH'):worker(job)
        path.write_bytes(saved)
        audit=after/'native/A/object-audit.json';saved=audit.read_bytes();audit.write_bytes(b'X'+saved[1:])
        with pytest.raises(ContractError,match='F4_COMPACT_Q_NATIVE_REFERENCE_MISMATCH'):worker(job)
        audit.write_bytes(saved)
        broken=copy.deepcopy(job);broken['refs']['native/A/a.json']['size_bytes']=True
        with pytest.raises(ContractError,match='F4_COMPACT_Q_MEMBER_INVALID'):worker(broken)
        evidence.append({'case':'new_Q_coordinate_worker_rejects_hash_audit_refschema','result':'PASS','rejections':3})
        def deny_pool(*args,**kwargs):raise AssertionError('NATIVE_UNITS_MUST_REMAIN_INLINE')
        with mp.context() as inline:
            inline.setattr(runtime,'_readback_ordered',deny_pool)
            subset={name:record for name,record in refs.items() if name!='result.json'}
            local,local_refs=q._full_pipeline_q_numerical_members(after,native_units=('A',),transported_refs=subset,resource_policy=policy)
            old_local,old_local_refs=old(after,native_units=('A',),transported_refs=subset)
            assert list(local)==list(old_local) and local_refs==old_local_refs and 'numbers.json' not in local
        with mp.context() as nested:
            nested.setattr(runtime,'_IN_SCIENTIFIC_POOL',True)
            nested.setattr(runtime,'_bounded_ordered_spawn',deny_pool)
            nested.setattr(runtime,'observe_execution_resources',deny_pool)
            local,local_refs=q._full_pipeline_q_numerical_members(after,resource_policy=policy)
            assert list(local)==list(members) and local_refs==refs
        evidence.append({'case':'native_units_inline_and_nested_pool_fallback','result':'PASS','nested_spawns':0})
    result={'scope':'completed Q readback engineering only','cases':evidence,
            'source_sha256_start':fingerprint,'source_sha256_end':sha256_file(REPO/'padml/f4_compact.py'),
            'source_written':False,'clinical_computation':False}
    Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
if __name__=='__main__':main()
