"""Unified A+B+C+D+E same-run release; no remote effects or science runs."""
import json
import subprocess
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

from padml.bundle import canonical_json_bytes, sha256_bytes, sha256_file, write_deterministic_zip
from padml.f4 import compile_f45_source_bundle, _f45_source_member_sha256, F45_SOURCE_MEMBERS

base = Path(__file__).resolve().parent
repo = base.parent
old_path = base / 'release-score-reuse/PADML_F45_REBUILD_20260926_SCORE_REUSE.zip'
assert sha256_file(old_path) == '8a7fa4d65acb987638c7aa227cf2ab4e9615ebf42da2cc8354fc011fabdae40a'
checks = [
    'final-reuse-numerics-initial.xml', 'final-reuse-numerics-followup.xml',
    'final-primary-reuse-local.xml', 'final-aar-reuse-direct.xml',
    'final-aar-reuse-followup.xml', 'final-aar-reuse-archive-resource.xml',
    'final-full0-reuse-zero-lock.xml', 'final-full0-reuse-missing.xml',
    'final-full0-reuse-custody.xml', 'final-full0-reuse-final-boundary.xml',
    'final-full0-reuse-object-admission.xml', 'final-c-recipe-consumer.xml',
    'final-c-elastic-outer-isolation.xml', 'final-c-elastic-native-retention.xml',
    'final-c-elastic-reuse-initial.xml', 'final-c-e-closure-corrected.xml',
]
# Reuse named evidence, retaining failed originals. Later results for the same
# case supersede its earlier fixture failure, not unrelated scientific results.
cases = {}
for name in checks:
    for case in ET.parse(base / name).getroot().iter('testcase'):
        cases[(case.get('classname'), case.get('name'))] = {
            'source': name, 'passed': not any(case.find(tag) is not None
                for tag in ('failure', 'error', 'skipped'))}
assert len(cases) == 62 and all(row['passed'] for row in cases.values())
audit = json.loads((base / 'final-reuse-cross-audit.json').read_bytes())
assert audit['status'] == 'CLOSED' and audit['open_findings'] == []
for name in audit['verification_files']:
    suite, = ET.parse(base / name).getroot().findall('testsuite')
    assert int(suite.attrib['tests']) > 0
    assert all(int(suite.attrib[key]) == 0 for key in ('errors', 'failures', 'skipped'))
    checks.append(name)
validated = json.loads((base / 'final-reuse-source-validation.json').read_bytes())
identity = sha256_bytes(canonical_json_bytes(_f45_source_member_sha256()))
assert validated['source_identity'] == identity
assert not subprocess.check_output(['git', 'diff', '--name-only', 'HEAD', '--', *F45_SOURCE_MEMBERS, 'tests'], cwd=repo)
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
for name in F45_SOURCE_MEMBERS:
    assert subprocess.check_output(['git', 'show', f'{head}:{name}'], cwd=repo) == (repo / name).read_bytes()
release_dir = base / 'release-final-reuse'
release_dir.mkdir(exist_ok=True)
compiled = compile_f45_source_bundle(release_dir / 'source.zip')
with zipfile.ZipFile(old_path) as archive:
    members = {name: archive.read(name) for name in archive.namelist() if name != 'release.json'}
old_run = json.loads(members['run.json'])
members['final-predecessor/run.json'] = members['run.json']
members['final-predecessor/source.zip'] = members['source.zip']
members['source.zip'] = (release_dir / 'source.zip').read_bytes()
with zipfile.ZipFile(release_dir / 'source.zip') as source_archive:
    for name in ('AGENTS.md', 'NESTED_LOCO_PROTOCOL.md'):
        members[name] = (repo / name).read_bytes()
        assert members[name] == source_archive.read(name)
members['source.compile.json'] = canonical_json_bytes(compiled)
run = {**old_run, 'source_identity': identity, 'source_bundle_sha256': compiled['sha256'],
    'unit_predecessor': {
        'run_path': old_run['run_root'] + '/final-predecessor/run.json',
        'run_sha256': sha256_bytes(members['final-predecessor/run.json']),
        'source_path': old_run['run_root'] + '/final-predecessor/source.zip',
        'source_sha256': sha256_bytes(members['final-predecessor/source.zip'])}}
run['identity'] = sha256_bytes(canonical_json_bytes({k: v for k, v in run.items() if k != 'identity'}))
members['run.json'] = canonical_json_bytes(run)
evidence = {name: base / name for name in [*checks, 'final-reuse-source-validation.json',
    'validate_final_reuse_source.py', 'compile_final_reuse_release.py',
    'final-reuse-cross-audit.json', 'final-reuse-ast-changes.json']}
for name in audit['retained_counterexamples']:
    evidence[name] = base / name
evidence.update({'cross-audit-scripts/' + path.name: path
    for path in sorted((base / 'cross-audit-scripts').glob('*.py'))})
evidence.update({'tests/' + name: repo / 'tests' / name for name in
    ('test_f45_final_reuse.py', 'test_f45_final_primary_reuse.py',
     'test_f45_final_aar_reuse.py', 'test_f45_final_full0_reuse.py',
     'test_f45_aar_development_reuse.py', 'test_full0_application_boundary.py',
     'test_f45_full0_whole_retention.py', 'test_f45_aar_cross_audit.py')})
write_deterministic_zip(release_dir / 'final-reuse-checks.zip', evidence)
members['final-reuse-checks.zip'] = (release_dir / 'final-reuse-checks.zip').read_bytes()
report = (
    '# Unified same-run A+B+C+D+E reuse\n\n'
    f'Frozen Git commit: {head}. Source: {identity}. Run: {run["identity"]}.\n\n'
    'This single package includes A same-branch MICE/complete-selector reuse; B seven-family '
    'pre-lock score components with independent current-h IBS and family decisions; C exact '
    'TOTAL transformed recipes and complete fixed-SetA AAR Elastic paths; D explicit AAR Q '
    'branch boundaries; and E exact post-lock M20 model reuse in PRIMARY, AAR and FULL0.\n\n'
    'Each consumer first establishes its own line/outer/branch lock. Actual M20 patient order, '
    'response roles, SetA, transforms, recipe, full-follow-up parameters, seeds, applicable STOP '
    'and engine definitions must match. Original model/input/audit bytes and producers remain '
    'unchanged. Missing model bodies are misses. All 20 model hits require zero new fits and no '
    'model worker pool; mixed hits compute only the missing original coordinates. FULL0 SHAP '
    'independently matches model/baseline, background, recipe, algorithm/seed and four targets. '
    'An absent SHAP body requires only SHAP computation from the original retained model.\n\n'
    'Logical coverage, shared computations and physical new model/path/SHAP work remain separate. '
    'Counters do not change independent scientific grids, EPV15-to-10 full-context rules, '
    'prediction isolation or the 56 whole-unit completion requirement. Original F1/F2 and the '
    'single frozen B1000 stay byte-identical. Old F4/F5 runs remain excluded.\n\n'
    'Focused UNFITTED evidence and user-requested cross-agent audit are retained in '
    'final-reuse-checks.zip. They prove engineering boundaries, not clinical cross-h savings. '
    'The exact same-run executor/source chain rejects unknown edits while retaining original '
    'receipts. The AAR Elastic adapter now permits its OUTER prediction-only view without '
    'held-out responses; inner response validation and numerical engines remain unchanged.\n\n'
    'Isolated native reading of an already completed whole and confirmed idle cutover are '
    'required before production deployment. Real cross-h request validation occurs only after '
    'legitimate independent locks exist. This package alone is not scientific completion.\n')
members['README.md'] = members['COMPILE_REPORT.md'] = report.encode()
members['EXECUTION_HANDOFF.md'] = (
    '# Execution handoff\n\n'
    'Seven-host and OSS cleanup is COMPLETE. Never repeat deletion. Protect F1/F2, the 46 accepted '
    'results, required dependencies, original stage coordinates/receipts and the single frozen B1000.\n\n'
    'The main task remains the sole writer and dispatcher. Use SSH-MCP only. Reconnect to active '
    'padml.worker units. Unknown status is not idle. Confirm every original active.lock process '
    'group has exited before applying the existing atomic release helper with run.json last. '
    'Use native f45_ready_assignments with this same run; transfer completed byte-verified whole '
    'units only. Do not introduce a scheduler, manual stage handoffs or duplicate starts.\n\n'
    'The user\'s later authorized seven-host formal computation and exact same-run reuse supersede '
    'historical compile-only and not-yet-implemented reuse wording. Scientific definitions, '
    'independent horizons/locks and all 56-unit deliverables remain unchanged. Follow up every '
    '15 minutes, keeping unchanged healthy states quiet and distinguishing runs, checkpoints '
    'and directly consumed completed units. This engineering release is not scientific completion.\n'
).encode()
release = {'kind': 'PADML_F45_ABCDE_REUSE_RELEASE', 'head': head,
    'run_identity': run['identity'], 'source_identity': identity,
    'members': {name: {'sha256': sha256_bytes(raw), 'size_bytes': len(raw)} for name, raw in members.items()}}
members['release.json'] = canonical_json_bytes(release)
target = release_dir / 'PADML_F45_REBUILD_20260926_ABCDE_REUSE.zip'
write_deterministic_zip(target, members)
with zipfile.ZipFile(target) as archive:
    assert {name: archive.read(name) for name in archive.namelist()} == members
    with zipfile.ZipFile(old_path) as original:
        for name in ('shared/bootstrap.zip', 'shared/bootstrap-preparation.json', 'science-decision.json', 'dependencies.json'):
            assert members[name] == original.read(name)
summary = {'head': head, 'package': str(target), 'sha256': sha256_file(target),
    'size_bytes': target.stat().st_size, 'source': compiled, 'source_identity': identity,
    'run_identity': run['identity'], 'unit_predecessor': run['unit_predecessor'],
    'scope': 'A+B+C+D+E', 'prior_engineering_cases': len(cases),
    'engineering_cases': audit['effective_unique_engineering_cases'],
    'cross_audit_test_executions': audit['cross_audit_test_executions'],
    'clinical_completion_claimed': False, 'deployed': False, 'native_reader_validation_pending': True}
(release_dir / 'compile-summary.json').write_bytes(canonical_json_bytes(summary))
print(json.dumps(summary))
