"""Freeze the surgical R native output publication revision with the original package compiler."""
import ast, io, json, os, subprocess, sys, zipfile
from pathlib import Path
from padml import f4
from padml.bundle import canonical_json_bytes as enc, sha256_bytes as sha, sha256_file, write_deterministic_zip

assert sys.version_info[:2] == (3, 12)
repo = Path(__file__).resolve().parents[2]
base, checks = repo / 'execution', Path(__file__).resolve().parent
previous = base / 'release-full0-rsf-scope/PADML_F45_REBUILD_20260929_FULL0_RSF_SCOPE.zip'
assert sha256_file(previous) == '53953a381e6f84c5353147598fcf1ef4353722a08dec0269199cbf807d624cfe'
pins = f4._f45_source_member_sha256()
identity = sha(enc(pins))
qualification = json.loads((checks / 'qualification.json').read_bytes())
tests = json.loads((checks / 'focused-tests.json').read_bytes())
assert qualification['source_identity'] == identity
assert len(qualification['checks']['predecessors']) == 23
assert tests['unique_cases_passed'] == 20 and tests['latest_case_failures'] == 0
assert tests['current_source_pins'] == pins
for name, digest in tests['test_pins'].items():
    assert sha256_file(repo / name) == digest
review = json.loads((checks / 'reviewed-source-ast.json').read_bytes())
for name, functions in review['function_revisions'].items():
    observed = {node.name: sha(ast.dump(node, include_attributes=False).encode())
        for node in ast.parse((repo / name).read_bytes()).body if isinstance(node, (ast.FunctionDef, ast.ClassDef))}
    for function, revisions in functions.items():
        assert observed[function] == revisions[-1]
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
assert not subprocess.check_output(['git', 'diff', '--name-only', 'HEAD', '--', *f4.F45_SOURCE_MEMBERS], cwd=repo)
for name in f4.F45_SOURCE_MEMBERS:
    assert subprocess.check_output(['git', 'show', head + ':' + name], cwd=repo) == (repo / name).read_bytes()
with zipfile.ZipFile(previous) as archive:
    members = {name: archive.read(name) for name in archive.namelist() if name != 'release.json'}
    with zipfile.ZipFile(io.BytesIO(members['source.zip'])) as source:
        changed = [name for name in f4.F45_SOURCE_MEMBERS if source.read(name) != (repo / name).read_bytes()]
assert set(changed) == {'padml/f4.py', 'padml/run.py'}
out = base / 'release-q-risk-copy'
out.mkdir()
compiled = f4.compile_f45_source_bundle(out / 'source.zip')
prefix = 'q-risk-copy-predecessor'
members[prefix + '/run.json'] = members['run.json']
members[prefix + '/source.zip'] = members['source.zip']
old = json.loads(members['run.json'])
members['source.zip'] = (out / 'source.zip').read_bytes()
members['source.compile.json'] = enc(compiled)
run = {**old, 'source_identity': identity, 'source_bundle_sha256': compiled['sha256'],
    'unit_predecessor': {'run_path': old['run_root'] + '/' + prefix + '/run.json',
        'run_sha256': sha(members[prefix + '/run.json']),
        'source_path': old['run_root'] + '/' + prefix + '/source.zip',
        'source_sha256': sha(members[prefix + '/source.zip'])}}
run['identity'] = sha(enc({k: v for k, v in run.items() if k != 'identity'}))
assert run['units'] == old['units'] and len(run['units']) == 56
assert run['science_decision'] == old['science_decision']
members['run.json'] = enc(run)
assert json.loads((checks / 'real-byte-validation.json').read_bytes())['status'] == 'PASS'
evidence = {p.name: p for p in checks.iterdir() if p.is_file() and p.suffix in {'.py', '.json', '.xml', '.txt'}}
for name in tests['test_pins']:
    evidence[name] = repo / name
write_deterministic_zip(out / 'q-risk-copy-checks.zip', evidence)
members['q-risk-copy-checks.zip'] = (out / 'q-risk-copy-checks.zip').read_bytes()
members['HISTORICAL_FULL0_RSF_SCOPE_COMPILE.md'] = members['COMPILE_REPORT.md']
report = (f'Frozen Git: {head}. Source: {identity}. Run: {run["identity"]}.\n\n'
    + (base / 'Q_RISK_COPY_COMPILE.md').read_text()).encode()
members['README.md'] = members['COMPILE_REPORT.md'] = members['EXECUTION_HANDOFF.md'] = report
summary = {'head': head, 'source_identity': identity, 'run_identity': run['identity'], 'source': compiled,
    'changed_source_members': changed, 'source_member_count': len(f4.F45_SOURCE_MEMBERS),
    'units': len(run['units']), 'predecessors': 23, 'focused_cases': 20,
    'previous_package_sha256': sha256_file(previous), 'development_science_unchanged': True,
    'qualification_sha256': sha256_file(checks / 'qualification.json'),
    'deployed': False, 'compiler_clinical_calls': 0, 'compiler_remote_mutations': 0, 'compiler_remote_scientific_launches': 0,
    'compiler_readonly_evidence_collection': True,
    'clinical_completion_claimed': False}
members['compile-summary.json'] = enc(summary)
with zipfile.ZipFile(previous) as archive:
    for name in archive.namelist():
        if name in {'science-decision.json', 'dependencies.json', 'shared/bootstrap.zip', 'shared/bootstrap-preparation.json',
                    'patient-recovery-readback-checks/pilot.py', 'AGENTS.md', 'NESTED_LOCO_PROTOCOL.md'} \
                or name.endswith(('/run.json', '/source.zip', '-checks.zip')):
            assert members[name] == archive.read(name)
release = {'kind': 'PADML_F45_Q_RISK_COPY_RELEASE', 'head': head,
    'run_identity': run['identity'], 'source_identity': identity,
    'members': {name: {'sha256': sha(raw), 'size_bytes': len(raw)} for name, raw in members.items()}}
members['release.json'] = enc(release)
target = out / 'PADML_F45_REBUILD_20260930_Q_RISK_COPY.zip'
write_deterministic_zip(target, members)
completed = subprocess.run([sys.executable, '-B', str(checks / 'frozen-reader.py'), str(target)],
    cwd=repo, check=True, capture_output=True, text=True,
    env={**os.environ, 'PYTHONPATH': str(repo), 'PYTHONDONTWRITEBYTECODE': '1'})
(out / 'frozen-reader.log').write_text(completed.stdout)
summary.update(package=str(target), sha256=sha256_file(target), size_bytes=target.stat().st_size)
(out / 'compile-summary.json').write_bytes(enc(summary))
print(json.dumps(summary))
