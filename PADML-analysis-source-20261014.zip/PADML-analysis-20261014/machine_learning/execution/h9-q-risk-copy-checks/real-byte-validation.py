from __future__ import annotations
import ast
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import sys
import tempfile

sys.dont_write_bytecode = True
REPO = Path('/Users/liuningyuan/Desktop/Result/Machine Learning/PADML_F45_REBUILD')
INPUT = Path('/private/var/folders/qj/5799w4651d7gmrcfq_wwhyym0000gn/T/padml-h9-risk-copy-7gj_7fy8')
OUT = Path(__file__).resolve().parent
RECORD = REPO / 'execution/h9-q-risk-copy-checks/native-comparison.json'
sys.path.insert(0, str(REPO))
from padml.bundle import ContractError, canonical_json_bytes, sha256_bytes, strict_json_bytes
from padml.nested_loco import _write_exact_once

def forbidden(*args, **kwargs):
    raise AssertionError('R/FIT/LOSS/SUBPROCESS_FORBIDDEN')
for name in ('run', 'Popen', 'call', 'check_call', 'check_output'):
    setattr(subprocess, name, forbidden)

def pin(p):
    before = p.lstat()
    assert stat.S_ISREG(before.st_mode) and before.st_nlink == 1 and not p.is_symlink()
    digest = hashlib.sha256()
    with p.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    after = p.lstat()
    signature = lambda s: (s.st_dev, s.st_ino, s.st_mode, s.st_nlink, s.st_size, s.st_mtime_ns)
    assert signature(before) == signature(after)
    return {'size': before.st_size, 'sha256': digest.hexdigest(), 'nlink': before.st_nlink,
            'inode': before.st_ino, 'mtime_ns': before.st_mtime_ns}

def files_pinned(directory):
    return {p.relative_to(directory).as_posix(): pin(p) for p in sorted(directory.rglob('*')) if p.is_file()}

record = strict_json_bytes(RECORD.read_bytes())
input_before = files_pinned(INPUT)
assert set(input_before) == {
    'native/output.json', 'native/risk-001-gbm-fit.bin',
    'produce/output.json', 'produce/spec.json', 'produce/risk-001-gbm-fit.bin',
    'audit/output.json', 'audit/risk-001-gbm-fit.bin'}
for relative, observed in input_before.items():
    role, name = relative.split('/', 1)
    expected = record['files'][role][name]
    assert observed['sha256'] == expected['sha256'] and observed['size'] == expected['size']
assert record['output_bytes_identical'] is True
assert len({(INPUT / role / 'output.json').read_bytes() for role in ('native', 'produce', 'audit')}) == 1

source_path = REPO / 'padml/f4.py'
source = source_path.read_bytes()
tree = ast.parse(source)
outer = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == '_run_full_pipeline_r_search_batch')
helper = next(n for n in outer.body if isinstance(n, ast.FunctionDef) and n.name == 'publish')
require = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == '_require')
fragment = b''.join(source.splitlines(keepends=True)[helper.lineno-1:helper.end_lineno])
(OUT / 'publish.snapshot.txt').write_bytes(fragment)
source_pin = {'path': str(source_path), 'sha256': sha256_bytes(source),
              'helper_start': helper.lineno, 'helper_end': helper.end_lineno,
              'helper_source_sha256': sha256_bytes(fragment),
              'helper_ast_sha256': sha256_bytes(ast.dump(helper, include_attributes=False).encode())}

original = strict_json_bytes((INPUT / 'produce/spec.json').read_bytes())
remote_atom = Path(record['atom'])
assert original['native_search_root'] == str(remote_atom / 'native')
remote_produce = Path(original['output_path']).parent
assert remote_produce.parent == remote_atom / 'work/produce'
assert len(original['producer_tasks']) == 1
assert original['producer_tasks'][0]['task_id'] == 'S3B2_T001_P12_M17_STOP'
atom = OUT / 'isolated-atom'
base = atom / 'native'
root = base / ('batch-' + sha256_bytes(canonical_json_bytes([t['task_id'] for t in original['producer_tasks']]))[:24])
produce = atom / 'work/produce' / remote_produce.name
audit = atom / 'work/audit' / remote_produce.name
for folder in (root, produce, audit):
    folder.mkdir(parents=True)
for role, destination in (('native', root), ('produce', produce), ('audit', audit)):
    for p in (INPUT / role).iterdir():
        shutil.copyfile(p, destination / p.name)
# Only operational filesystem locations are relocated; all scientific fields and raw R outputs stay unchanged.
original = {**original, 'native_search_root': str(base), 'output_path': str(produce / 'output.json')}
original_bytes = canonical_json_bytes(original)
(root / 'spec.json').write_bytes(original_bytes)
(produce / 'spec.json').write_bytes(original_bytes)
output_path = audit / 'output.json'
spec = {**original, 'native_search_replay': True, 'native_search_complete_missing_values': True,
        'output_path': str(output_path)}
(audit / 'spec.json').write_bytes(canonical_json_bytes(spec))
namespace = {'__package__': 'padml', '__name__': 'padml._isolated_publisher',
    'os': os, 'stat': stat, 'tempfile': tempfile, 'Path': Path, 'ContractError': ContractError,
    'strict_json_bytes': strict_json_bytes, 'sha256_bytes': sha256_bytes,
    'root': root, 'base': base, 'original': original, 'spec': spec, 'output_path': output_path}
exec(compile(ast.Module(body=[require, helper], type_ignores=[]), str(source_path), 'exec'), namespace)
publish = namespace['publish']
name = 'risk-001-gbm-fit.bin'
target, source_risk = root / name, audit / name
staged_sources_before = {role: files_pinned(folder) for role, folder in (('produce', produce), ('audit', audit))}
original_target = pin(target)
original_output = pin(root / 'output.json')
native_members = sorted(p.relative_to(base).as_posix() for p in base.rglob('*') if p.is_file())
try:
    _write_exact_once(target, source_risk.read_bytes(), 'F45_Q_R_VALUES_DRIFT')
except ContractError as exc:
    assert str(exc) == 'F45_Q_R_VALUES_DRIFT'
    old_rejection = str(exc)
else:
    raise AssertionError('Original guard did not reject the retained short publication')
assert pin(target) == original_target
publish(source_risk, recover=True)
first = pin(target)
assert first['size'] == 49160000 and first['sha256'] == record['files']['audit'][name]['sha256']
assert target.read_bytes() == source_risk.read_bytes() == (produce / name).read_bytes()
fragment_path = atom / 'interrupted-publication' / root.name / name
saved_fragment = pin(fragment_path)
assert saved_fragment['sha256'] == original_target['sha256'] and saved_fragment['size'] == original_target['size']
assert fragment_path.read_bytes() == (INPUT / 'native' / name).read_bytes()
publish(source_risk, recover=True)
assert pin(target) == first and pin(fragment_path) == saved_fragment
assert pin(root / 'output.json') == original_output
assert {role: files_pinned(folder) for role, folder in (('produce', produce), ('audit', audit))} == staged_sources_before
assert files_pinned(INPUT) == input_before
assert sorted(p.relative_to(base).as_posix() for p in base.rglob('*') if p.is_file()) == native_members
assert not list(atom.rglob('.native-publish-*'))
assert all(not (atom / n).exists() for n in ('values.json', 'audit.json', 'receipt.json', 'numbers.json'))
assert source_path.read_bytes() == source
result = {'status': 'PASS', 'scope': 'REAL_H9_RAW_BYTE_PUBLICATION_ONLY', 'python': sys.version,
    'source': source_pin, 'input_path': str(INPUT), 'input_files_verified_unchanged': input_before,
    'metadata_path': str(RECORD), 'metadata_sha256': sha256_bytes(RECORD.read_bytes()),
    'task_id': original['producer_tasks'][0]['task_id'], 'original_guard_rejected': old_rejection,
    'original_native_fragment': original_target, 'published_file': first,
    'saved_fragment': {'path': str(fragment_path), **saved_fragment},
    'idempotent_same_inode_mtime': True, 'native_member_set_unchanged': True,
    'original_output_unchanged': True, 'staged_produce_audit_unchanged': True,
    'all_input_and_published_files_nlink_one': True, 'repository_source_unchanged': True,
    'r_calls': 0, 'fit_calls': 0, 'loss_calls': 0, 'float_risk_consumption_calls': 0,
    'native_model_loaded': False, 'first_audit_receipt_created': False,
    'not_proven': ['native R replay', 'STOP loss/lock consumption', 'whole atom acceptance']}
(OUT / 'result.json').write_bytes(canonical_json_bytes(result))
print(json.dumps({'status': result['status'], 'result': str(OUT/'result.json'),
                  'script': str(Path(__file__).resolve()), 'published_size': first['size'],
                  'published_sha256': first['sha256'], 'saved_fragment_size': saved_fragment['size'],
                  'old_guard': old_rejection, 'idempotent': True}, ensure_ascii=False))
