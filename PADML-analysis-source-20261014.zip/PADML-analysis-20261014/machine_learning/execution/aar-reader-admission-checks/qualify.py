"""Original same-run source qualification for the bounded AAR reader change."""
import ast, copy, io, json, os, tempfile, zipfile
from pathlib import Path
from unittest.mock import patch
from padml import f4, f5, run
from padml.bundle import ContractError, canonical_json_bytes as enc, sha256_bytes as sha, sha256_file

repo = Path(__file__).resolve().parents[2]
checks = Path(__file__).resolve().parent
previous = repo / 'execution/release-h36-shap500/PADML_F45_REBUILD_20260928_H36_SHAP500.zip'
assert sha256_file(previous) == 'ba8b38c32ad0fcd861cdba723744990702006fdcbe27a264f3338d0f6baa7dde'
current_members = f4._f45_source_member_sha256()
results = {}
with tempfile.TemporaryDirectory(prefix='aar-reader-source-') as temporary:
    base = Path(temporary).resolve()
    with zipfile.ZipFile(previous) as archive:
        for name in archive.namelist():
            if name in ('run.json', 'source.zip') or name.endswith(('/run.json', '/source.zip')):
                target = base / name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(archive.read(name))
    with zipfile.ZipFile(base / 'source.zip') as source:
        old_members = {name: sha(source.read(name)) for name in f4.F45_SOURCE_MEMBERS}
    assert {name for name in current_members if current_members[name] != old_members[name]} == {
        'padml/f5_sensitivity.py', 'padml/run.py'}
    original = json.loads((base / 'run.json').read_bytes())
    value = {**original, 'source_identity': sha(enc(current_members)), 'source_bundle_sha256': 'd'*64,
        'unit_predecessor': {'run_path': str(base / 'run.json'), 'run_sha256': sha256_file(base / 'run.json'),
            'source_path': str(base / 'source.zip'), 'source_sha256': sha256_file(base / 'source.zip')}}
    value['identity'] = sha(enc({k: v for k, v in value.items() if k != 'identity'}))
    (base / 'current-run.json').write_bytes(enc(value))
    remote = original['run_root']
    def mapped(location):
        location = str(location)
        return Path(str(base) + location[len(remote):]) if location.startswith(remote + '/') else Path(location)
    with patch.object(run, 'Path', mapped), patch.object(f4, 'Path', mapped):
        predecessors = run.f45_unit_predecessors(value)
        prior = json.loads((repo / 'execution/h36-shap500-checks/source-qualification.json').read_bytes())
        assert [p['identity'] for p in predecessors] == [original['identity'], *prior['checks']['same_run_predecessors']]
        assert len(predecessors) == 15
        baseline = run.validate_f45_resource_revision(value)
        assert sha(enc(baseline)) == '25190343ea52b20014b6cb38eae518b4fe77621e02c8eb24a5b3f66fc5047c50'
        with patch.dict(os.environ, {'PADML_F45_RUN_PATH': str(base / 'current-run.json')}):
            with patch.object(run, 'f45_unit_predecessors', return_value=predecessors):
                executors, sources = f5._f45_score_reuse_authorities()
        h5_run = 'c424be6060187ccec5c83f55f9774d513e11569c35dd3ee107b715d0e445d237'
        h5_source = '5cef1529df525f18e961e9bc472b0f9b4646da941f182fc24ee1702f0f7a99c4'
        assert executors[h5_run] == h5_source and h5_source in sources
        results.update(predecessors=[p['identity'] for p in predecessors], h5_producer_run=h5_run,
            h5_producer_source=h5_source, original_fit_producer_baseline_qualified=True)
        current = repo / 'padml/f5_sensitivity.py'
        raw, actual_read = current.read_bytes(), Path.read_bytes
        before = b'owner="AAR_OUTER_REPLAY_HASHED_INPUTS",'
        assert raw.count(before) == 1
        altered = raw.replace(before, b'owner="UNREVIEWED_CHANGE",', 1)
        with patch.object(Path, 'read_bytes', lambda path: altered if path == current else actual_read(path)):
            for name, validator in [('predecessor', run.f45_unit_predecessors), ('baseline', run.validate_f45_resource_revision)]:
                try:
                    validator(value)
                except ContractError as error:
                    results[name + '_unknown_reader_change_rejected'] = str(error)
                else:
                    raise AssertionError(name)
        damaged = copy.deepcopy(value)
        damaged['unit_predecessor']['source_sha256'] = 'f'*64
        try:
            run.f45_unit_predecessors(damaged)
        except ContractError as error:
            results['unknown_source_pin_rejected'] = str(error)
        else:
            raise AssertionError('unknown predecessor source')
    assert (base / 'run.json').read_bytes() == enc(original)
    assert value['science_decision'] == original['science_decision']
    results['all_scientific_and_runtime_sources_unchanged'] = True
record = {'source_identity': sha(enc(current_members)), 'checks': results,
    'clinical_calls': 0, 'remote_operations': 0}
(checks / 'qualification.json').write_bytes(enc(record))
print(json.dumps(record))
