"""Same-run AAR completed-consumer repair; preserve original numerical producers."""
import ast
import io
import json
import subprocess
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

from padml.bundle import canonical_json_bytes as encode, sha256_bytes, sha256_file, write_deterministic_zip
from padml.f4 import compile_f45_source_bundle, _f45_source_member_sha256, F45_SOURCE_MEMBERS

base=Path(__file__).resolve().parent
repo=base.parent
old_path=base/"release-aar-prefix/PADML_F45_REBUILD_20260926_ABCDE_AAR_PREFIX.zip"
assert sha256_file(old_path)=="5f17ced8933da47c0109e05be30160c8692f54d61ae286290a375d7594e3e707"
identity=sha256_bytes(encode(_f45_source_member_sha256()))
validated=json.loads((base/"aar-tail-sidecar-source-validation.json").read_bytes())
assert validated["source_identity"]==identity
suite,=ET.parse(base/"aar-tail-sidecar-final.xml").getroot().findall("testsuite")
assert int(suite.attrib["tests"])==36 and all(int(suite.attrib[n])==0 for n in ("failures","errors","skipped"))
assert not subprocess.check_output(["git","diff","--name-only","HEAD","--",*F45_SOURCE_MEMBERS,"tests"],cwd=repo)
head=subprocess.check_output(["git","rev-parse","HEAD"],cwd=repo,text=True).strip()
for name in F45_SOURCE_MEMBERS:
    assert subprocess.check_output(["git","show",f"{head}:{name}"],cwd=repo)==(repo/name).read_bytes()
release_dir=base/"release-aar-tail-sidecar"
release_dir.mkdir(exist_ok=True)
compiled=compile_f45_source_bundle(release_dir/"source.zip")
with zipfile.ZipFile(old_path) as old:
    members={n:old.read(n) for n in old.namelist() if n!="release.json"}
old_run=json.loads(members["run.json"])
members["tail-predecessor/run.json"]=members["run.json"]
members["tail-predecessor/source.zip"]=members["source.zip"]
members["source.zip"]=(release_dir/"source.zip").read_bytes()
members["source.compile.json"]=encode(compiled)
run={**old_run,"source_identity":identity,"source_bundle_sha256":compiled["sha256"],
    "unit_predecessor":{"run_path":old_run["run_root"]+"/tail-predecessor/run.json",
        "run_sha256":sha256_bytes(members["tail-predecessor/run.json"]),
        "source_path":old_run["run_root"]+"/tail-predecessor/source.zip",
        "source_sha256":sha256_bytes(members["tail-predecessor/source.zip"])}}
run["identity"]=sha256_bytes(encode({k:v for k,v in run.items() if k!="identity"}))
members["run.json"]=encode(run)
evidence={n:base/n for n in ("aar-tail-sidecar-final.xml", "aar-tail-sidecar-source-validation.json",
    "validate_aar_completed_tail_source.py", "compile_aar_completed_tail_release.py", "AAR_COMPLETED_CONSUMER_REPAIR.md")}
for n in ("test_a12_completed_consumer.py", "test_aar_final_shards.py", "test_f45_aar_reuse.py", "test_f45_aar_cross_audit.py"):
    evidence["tests/"+n]=repo/"tests"/n
write_deterministic_zip(release_dir/"aar-tail-checks.zip",evidence)
members["aar-tail-checks.zip"]=(release_dir/"aar-tail-checks.zip").read_bytes()
addendum=(
    "\n\nAAR completed-consumer repair: the shared OUTER_REPLAY diagnostic leaf and "
    "envelope accept at most 64 MiB with measured metadata memory admission; other "
    "operations retain their existing limits. A whole-unit worker can finish from "
    "an independently pinned original report only after its completed numerical "
    "pool, returned consumer marker, unchanged input/result, exact same-run "
    "producer and complete retained file identities pass their native checks. "
    "Original AAR_SEARCH diagnostic sidecars are classified by their exact branch, "
    "owner, PID, chronology and unchanged archive inventory; arbitrary extras fail. "
    "No numerical replay, MICE or models are repeated by this route. The original "
    "report is retained in whole-unit artifacts, and later horizons independently "
    "qualify the numerical producer and finishing executor. Ordinary units still "
    "run the original direct consumer. Thirty-six focused engineering cases pass; "
    "eight pinned predecessor revisions and the original numerical baseline "
    "are qualified under production Python. This is not clinical completion. "
    "Only replace idle sources; never hot-edit active processes or repeat deletion.\n")
for name in ("README.md","COMPILE_REPORT.md","EXECUTION_HANDOFF.md"):
    members[name]+=addendum.encode()
for name in ("AGENTS.md","NESTED_LOCO_PROTOCOL.md"):
    assert members[name]==(repo/name).read_bytes()
release={"kind":"PADML_F45_ABCDE_AAR_TAIL_SIDECAR_RELEASE","head":head,"run_identity":run["identity"],
    "source_identity":identity,"members":{n:{"sha256":sha256_bytes(b),"size_bytes":len(b)} for n,b in members.items()}}
members["release.json"]=encode(release)
target=release_dir/"PADML_F45_REBUILD_20260927_ABCDE_AAR_TAIL_SIDECAR.zip"
write_deterministic_zip(target,members)
with zipfile.ZipFile(target) as archive:
    assert {n:archive.read(n) for n in archive.namelist()}==members
with zipfile.ZipFile(old_path) as original:
    for n in ("shared/bootstrap.zip","shared/bootstrap-preparation.json","science-decision.json","dependencies.json"):
        assert members[n]==original.read(n)
summary={"head":head,"package":str(target),"sha256":sha256_file(target),"size_bytes":target.stat().st_size,
    "source_identity":identity,"run_identity":run["identity"],"source":compiled,
    "focused_engineering_cases":36,"deployed":False,
    "clinical_completion_claimed":False}
(release_dir/"compile-summary.json").write_bytes(encode(summary))
print(json.dumps(summary))
