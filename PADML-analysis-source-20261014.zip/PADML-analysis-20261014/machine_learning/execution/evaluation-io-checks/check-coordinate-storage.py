"""Isolated storage-routing checks; synthetic rows, numerical/R functions spied.
Uses the production coordinate consumer and ZIP writer. Not clinical evidence.
"""
import json, tempfile, sys
from contextlib import ExitStack
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0, '/Users/liuningyuan/Desktop/Result/Machine Learning/PADML_F45_REBUILD/execution/evaluation-io-checks/recovery')
from fixtures import six_outers
from padml import f5_sensitivity as a, runtime
from padml.bundle import canonical_json_bytes, ContractError

context, outers = six_outers()
handoff = a._validate_a12_handoff(a._a12_handoff_from_outers(context, outers))
fixed = {k: handoff[k] for k in ('patient_ids','centers','horizons','survival')}
fixed.update(a._a12_evaluation_scope(handoff))
response = context['evaluation_response_csv']
draw = list(range(len(handoff['patient_ids'])))
binding = a._a12_bootstrap_binding(fixed, response, {'replicate_count': 1000})
cap = 128 * 1024
checks = []

def observe(root, available):
    return {'effective_cpus':32,'available_memory_bytes':16*1024**3,
            'scratch_available_bytes':available,'scratch_root':str(root)}

def run_new(root, *, raw_json_bytes, native_bytes, available=10**12):
    native = root / 'replicate-0001'; native.mkdir()
    (native/'metrics.zip').write_bytes(native_bytes)
    calls = []
    def fake_eval(*args, **kwargs):
        assert kwargs['replay_native_archive'] == native/'metrics.zip'
        calls.append('REPLAY_SYNTHETIC_NATIVE')
        return {'UNFITTED_STORAGE_ROUTING': True, 'padding': 'x'*raw_json_bytes}
    with ExitStack() as s:
        s.enter_context(patch.object(runtime,'observe_execution_resources',lambda p:observe(p,available)))
        s.enter_context(patch.object(a,'evaluate_predictions',fake_eval))
        s.enter_context(patch.object(a,'_validate_a12_native_evaluation',lambda *args,**kwargs:None))
        s.enter_context(patch.object(a,'_a12_bootstrap_row',lambda *args,**kwargs:{'replicate':1,'UNFITTED':True}))
        value = a._a12_bootstrap_replicate((1,draw),evaluation_handoff=fixed,response_csv=response,
                work_root=root,source_binding=binding,retained_bytes_per_replicate=cap)
    return value, calls

with tempfile.TemporaryDirectory(prefix='f45-cap-',dir='/private/tmp') as td:
    base = Path(td)
    root=base/'raw-large';root.mkdir()
    value,calls=run_new(root,raw_json_bytes=3*1024**2,native_bytes=b'not-clinical-native')
    assert (root/'replicate-0001.zip').stat().st_size <= cap
    assert not (root/'replicate-0001').exists()
    checks.append({'check':'raw_larger_than_cap_compressed_zip_below_cap','status':'PASS','zip_bytes':(root/'replicate-0001.zip').stat().st_size})

    root=base/'oversize';root.mkdir()
    try:run_new(root,raw_json_bytes=1,native_bytes=b'z'*(2*cap))
    except ContractError as e:failure=str(e)
    else:raise AssertionError('oversize ZIP returned success')
    archive=root/'replicate-0001.zip';native=root/'replicate-0001'
    assert archive.stat().st_size>cap
    assert all((native/n).is_file() for n in ('input.json','evaluation.json','metrics.zip'))
    pins={p.name:p.read_bytes() for p in (archive,native/'input.json',native/'evaluation.json',native/'metrics.zip')}
    checks.append({'check':'published_oversize_zip_fails_and_keeps_native_leaves','status':'PASS','error':failure,'zip_bytes':archive.stat().st_size})
    with patch.object(a,'read_safe_zip',side_effect=AssertionError('oversize reached ZIP expansion')):
        try:a._a12_bootstrap_replicate((1,draw),evaluation_handoff=fixed,response_csv=response,work_root=root,
                     source_binding=binding,retained_bytes_per_replicate=cap)
        except ContractError:pass
        else:raise AssertionError('oversize resumed as completed')
    assert pins=={p.name:p.read_bytes() for p in (archive,native/'input.json',native/'evaluation.json',native/'metrics.zip')}
    checks.append({'check':'oversize_resume_rejected_by_reader_before_zip_expansion_without_mutation','status':'PASS'})
    with patch.object(a,'read_safe_zip',side_effect=AssertionError('oversize reached ZIP expansion')):
        try:a._replay_a12_bootstrap_replicate((1,draw),evaluation_handoff=fixed,response_csv=response,root=root,
                     source_binding=binding,retained_bytes_per_replicate=cap)
        except ContractError:pass
        else:raise AssertionError('oversize direct reader returned success')
    checks.append({'check':'oversize_direct_reader_rejected_before_zip_expansion','status':'PASS'})

    root=base/'no-space';root.mkdir()
    try:run_new(root,raw_json_bytes=1000,native_bytes=b'x',available=1)
    except ContractError as e:failure=str(e)
    else:raise AssertionError('insufficient free space published ZIP')
    assert not (root/'replicate-0001.zip').exists()
    assert all((root/'replicate-0001'/n).is_file() for n in ('input.json','evaluation.json','metrics.zip'))
    checks.append({'check':'insufficient_disk_stops_before_publish_and_preserves_leaves','status':'PASS','error':failure})

print(json.dumps({'status':'PASS','scope':'SYNTHETIC_STORAGE_ROUTING_REAL_PRODUCTION_FUNCTION_AND_ZIP_WRITER','R_calls':0,'model_fits':0,'checks':checks},sort_keys=True))
