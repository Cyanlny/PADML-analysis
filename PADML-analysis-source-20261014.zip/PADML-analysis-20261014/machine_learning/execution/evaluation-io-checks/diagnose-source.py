"""Read only the failed member binding; never qualify or publish a new capsule."""
import ast, inspect, json, os, traceback
from pathlib import Path
from unittest.mock import patch
from padml import f5_sensitivity as a, f2_kernel as kernel, worker, run as runs

root = Path('/root/autodl-tmp/PADML_V22/f45-rebuild-20260925')
os.environ['PADML_F45_RUN_PATH'] = str(root / 'evaluation-validation-run.json')
run = runs.load_f45_run(root / 'evaluation-validation-run.json')
uid = 'PRIMARY-H12-O5'
unit = next(u for u in run['units'] if u['unit_id'] == uid)
source = Path(inspect.getfile(a))
tree = ast.parse(source.read_text())
original = a._require
failures = []

def require(condition, message):
    if not condition and message == 'F45_EVALUATION_NUMBERS_SOURCE_DRIFT':
        frame = inspect.currentframe().f_back
        nodes = [n for n in ast.walk(tree) if isinstance(n, ast.Call) and
                 isinstance(n.func, ast.Name) and n.func.id == '_require' and
                 n.lineno <= frame.f_lineno <= n.end_lineno]
        terms = []
        for node in nodes:
            expressions = node.args[0].values if isinstance(node.args[0], ast.BoolOp) else [node.args[0]]
            for expression in expressions:
                try:
                    value = bool(eval(compile(ast.Expression(expression), str(source), 'eval'), frame.f_globals, frame.f_locals))
                except Exception as error:
                    value = type(error).__name__ + ':' + str(error)
                terms.append({'expression': ast.unparse(expression), 'value': value})
        local = frame.f_locals
        detail = {key: local[key] for key in ('imp', 'family', 'h', 'outer')
                  if key in local and isinstance(local[key], (str, int))}
        if 'lock' in local and 'old_lock' in local and 'imp' in local:
            imp = local['imp']
            current_parameters = local['lock']['parameters_by_imputation'][imp-1]
            old_parameters = local['old_lock']['parameters_by_imputation'][imp-1]
            detail.update(family=local['lock']['selected_family'],
                parameter_keys=sorted(set(current_parameters) | set(old_parameters)),
                different_parameter_fields=sorted(k for k in set(current_parameters) | set(old_parameters)
                    if current_parameters.get(k) != old_parameters.get(k)))
        failures.append({'function': frame.f_code.co_name, 'line': frame.f_lineno,
                         'terms': terms, 'metadata': detail})
    return original(condition, message)

class DiagnosticComplete(Exception):
    pass

def stop_publication(*args, **kwargs):
    raise DiagnosticComplete('NUMERIC_CONSUMER_PASSED; NO_NEW_QUALIFICATION_OR_PUBLICATION')

result = {'unit': uid, 'scope': 'READ_ONLY_MEMBER_DIAGNOSIS_NOT_SOURCE_QUALIFICATION',
          'whole_archive_hash_skipped': True, 'new_model_fits': 0, 'published_files': 0}
try:
    with patch.object(worker, '_f45_file_pins', return_value={}), \
            patch.object(a, '_require', require), patch.object(kernel, '_require', require), \
            patch.object(a, 'write_deterministic_zip', stop_publication):
        path = a.prepare_f45_evaluation_source(run, unit, root / 'units' / uid)
        result['status'] = 'EXISTING_COMPACT_NUMBERS_PASS'
except DiagnosticComplete as error:
    result.update(status='MEMBER_NUMBERS_PASS_NO_PUBLISH', detail=str(error))
except Exception as error:
    result.update(status='REPRODUCED', error=type(error).__name__+':'+str(error), traceback=traceback.format_exc())
result['failed_guards'] = failures
print(json.dumps(result, sort_keys=True))
