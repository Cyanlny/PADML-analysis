"""Record exact reviewed changed definitions; no blanket source exemption."""
import ast, hashlib, json, pprint, subprocess, sys, zipfile
from pathlib import Path

assert sys.version_info[:2] == (3, 12)
repo = Path(__file__).resolve().parents[2]
base = '3b971cb9e1d33589e5b2839d787e48f131d9b8ff'
names = ['padml/f4.py', 'padml/f5.py', 'padml/f4_compact.py', 'padml/f5_sensitivity.py', 'padml/runtime.py', 'padml/worker.py', 'padml/run.py']
def digest(raw):
    return hashlib.sha256(raw).hexdigest()
def definitions(raw):
    return {node.name: digest(ast.dump(node, include_attributes=False).encode())
        for node in ast.parse(raw).body if isinstance(node, (ast.FunctionDef, ast.ClassDef))}
changes = {}
retained_generations = []
for folder, expected in (
    ('candidate-f15c41c4c22c', '99900b0318a30b2ad74351e12f9f481c9fa2718dff595a17f446a4e1fd3fc8e4'),
    ('candidate-4ef01be829e3', '9f224af0b6f9d62e4f47a5cd96dc0dbda738496726db76d96265bf31d7ae49bd'),
    ('candidate-a82cb4d2b8df', '51cf2eb78ef68bdcee808587cfa9b0e87ac587e9851ab21784fb410be02c6155')):
    retained_path = Path(__file__).parent / folder / 'source.zip'
    assert digest(retained_path.read_bytes()) == expected
    with zipfile.ZipFile(retained_path) as archive:
        retained_generations.append({name: archive.read(name) for name in (*names, 'AGENTS.md', 'NESTED_LOCO_PROTOCOL.md')})
for name in names:
    old = definitions(subprocess.check_output(['git', 'show', base + ':' + name], cwd=repo))
    new = definitions((repo / name).read_bytes())
    assert not (set(old) - set(new)), 'Do not silently remove historical readers'
    middles = [definitions(retained[name]) for retained in retained_generations]
    changed = {key: tuple(dict.fromkeys((old.get(key), *(middle.get(key) for middle in middles), value)))
        for key, value in new.items() if (old.get(key) != value or any(middle.get(key) != value for middle in middles))
        and key != '_f45_aar_binding_ast'}
    if changed:
        changes[name] = changed
path = repo / 'padml/run.py'
text = path.read_text()
start, end = '    # BEGIN EXACT COMPACT EVALUATION DEFINITIONS\n', '    # END EXACT COMPACT EVALUATION DEFINITIONS\n'
if start in text:
    left, rest = text.split(start)
    _, right = rest.split(end)
    text = left + right
block = start + '    compact_evaluation_qualified = ' + pprint.pformat(changes, width=120, sort_dicts=True) + '\n'
block += '''    for module, definitions in compact_evaluation_qualified.items():
        target = qualified.setdefault(module, {})
        for function, revisions in definitions.items():
            target[function] = tuple(dict.fromkeys((*target.get(function, ()), *revisions)))
'''+end
marker = '    if name == "padml/runtime.py":\n'
assert text.count(marker) == 1
text = text.replace(marker, block + marker)
raws = {name: tuple(dict.fromkeys((*(digest(retained[name]) for retained in retained_generations), digest((repo/name).read_bytes()))))
        for name in ('AGENTS.md','NESTED_LOCO_PROTOCOL.md')}
raw_start, raw_end = '    # BEGIN COMPACT EVALUATION DOCS\n', '    # END COMPACT EVALUATION DOCS\n'
if raw_start in text:
    left, rest = text.split(raw_start); _, right = rest.split(raw_end); text = left + right
raw_block = raw_start + '    compact_evaluation_raw = ' + repr(raws) + '\n    if name in compact_evaluation_raw and sha256_bytes(raw) in compact_evaluation_raw[name]:\n        return ast.parse(repr(b""))\n' + raw_end
text = text.replace('    import ast\n    # Exact 28-context', '    import ast\n' + raw_block + '    # Exact 28-context')
path.write_text(text)
raws = {name: [digest(subprocess.check_output(['git', 'show', base + ':' + name], cwd=repo)),
    digest((repo / name).read_bytes())] for name in ['AGENTS.md', 'NESTED_LOCO_PROTOCOL.md', 'padml/kernels/f4_metrics.R']}
record = {'baseline_git': base, 'function_revisions': changes, 'raw_revisions': raws}
(Path(__file__).parent / 'reviewed-source-ast.json').write_text(json.dumps(record, indent=2, sort_keys=True)+'\n')
print(json.dumps({'changed_definitions': {name: len(rows) for name, rows in changes.items()}, 'raw': raws}))
