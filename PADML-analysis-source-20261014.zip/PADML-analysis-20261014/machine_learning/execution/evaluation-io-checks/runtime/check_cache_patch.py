import ast
import json
from pathlib import Path, PurePosixPath
OUT=Path('/tmp/padml-runtime-audit.4n8u2M')
class ProbePath(PurePosixPath):
    tested=[]
    def is_file(self):
        self.tested.append(str(self))
        return not self.name.startswith('missing')
P=ProbePath
root=P('/synthetic/unit')
manifest=json.loads((OUT/'readback-cache-files-manifest.json').read_text())
results=[]
for key in manifest['calls']:
    file,worker,occ=key.split(':');occ=int(occ)
    tree=ast.parse((OUT/'proposed'/file).read_text())
    calls=sorted([n for n in ast.walk(tree) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name)
        and n.func.id=='_readback_ordered' and n.args and isinstance(n.args[0],ast.Name)
        and n.args[0].id==worker],key=lambda n:n.lineno)
    call=calls[occ]
    expression=next(k.value for k in call.keywords if k.arg=='cache_files')
    env={'Path':P,'PurePosixPath':PurePosixPath,'root':root,'target':root/'target','source':root/'source.zip',
        'input_source':root/'actual-input.json','_MICE_CONFIGURATION_NAMES':['method','predictor_matrix'],
        'refs':{'input.json':{},'native/C1/model.bin':{},'native/C1/prediction.json':{},'missing.json':{}}}
    binding={'source':{'path':'final-reuse/PRIMARY-H06-O1/source.json'},'imputation':1}
    item={'root':root,'binding':binding,'job':{'root':str(root/'fits/M01'),'archive':str(root/'fits/M01.zip'),
        'name':'O1_A_M01'},'candidate':P('/synthetic/old'),'location':root/'final-reuse/OLD/source.json',
        'metadata':{'members':{}},'result':{'members':{}}}
    env.update(completed=[item],read_jobs=[item])
    if worker=='_a12_projected_input_read_job':
        env.update(value={'members':{'training-response.csv':{},'direct/P1/imp01.csv':{},'mice-inputs/A/V1.zip':{}}},
            selected_members={'training-response.csv','direct/P1/imp01.csv','mice-inputs/A/V1.zip'},
            direct_jobs=[{'row':{'partition_id':'P1'}}],retained_primary_source_bundle=P('/synthetic/producer.zip'))
    if worker=='_a12_projected_partition_read_job':
        env['opened']={'root':root/'opened'}
        env['jobs']=[{'root':root/'target/A','estimand':'A','opened':{'root':root/'opened',
            'retained_primary_source_bundle':P('/synthetic/producer.zip')},
            'records':[{'view_id':'V1','member':'mice-inputs/A/V1.zip'}],
            'archives':{('A','V1'):root/'archives/V1.zip'},'reuse':{'A/V1':{}},
            'numerical_views':{'A/V1':{'members':{'input.zip':{},'imputations/imp01.csv':{},'native/imp01.rds':{}}}},
            'definition':{'partition_id':'P1'}}]
    if worker=='_full_data_partition_read_job':
        env['jobs']=[{'destination':root/'P1','analysis_payload':root/'mice/analysis.zip',
            'application_payload':root/'mice/application.zip','stop_analysis_payload':root/'stop/analysis.zip',
            'stop_application_payload':root/'stop/application.zip','retain_evidence':True}]
    if worker=='_f45_full_final_reuse_job':
        item={**item,'job':(root/'bound/M01.zip',root/'F5_FINAL_FULL_DATA_M01.zip',None,{'imputation':1},None)}
        env.update(completed=[item],read_jobs=[item])
    if worker=='_f45_score_reuse_read_job':
        name='components/score/COX_PH/R1_K1_M01.zip'
        env.update(sources={'OLD':{'path':'score-reuse/OLD/source.json'}},unit='OLD',
            extra={'candidate':P('/synthetic/old')},outer=True,names=[name],replay=False,
            records={name:{'family':'COX_PH'}},by_path={name:{'score_evidence':{'path':str(root/'components/score-evidence/COX_PH/R1_K1_M01.json')}}})
    if worker=='_completed_score_family_read_job':
        record={'family':'COX_PH','path':'components/score/COX_PH/R1_K1_M01.zip'}
        env.update(request={'component_records':[record]},completed_jobs=[{'family':'COX_PH',
            'retained_fixed_requests':{'COX_PH':({'component_records':[record]},P('/synthetic/retained'))},
            'evidence':{'reused_score_sources':{'OLD':{'path':'score-reuse/OLD/source.json'}},
                'component_evidence_records':[{'path':'components/score-evidence/COX_PH/R1_K1_M01.json',
                    'native_archive_path':'components/score-native/COX_PH/R1_K1_M01.zip','reused_score_unit_id':'OLD'}]}}])
    if worker=='_full_final_bound_read_job':
        env.update(input_root=root/'input',application_readback={'result_root':root/'final'},
            jobs=[{'row':{'path':'bound/M01.zip','imputation':1}}])
    if any(isinstance(n,ast.Name) and n.id=='readback_cache_files' for n in ast.walk(expression)):
        helper=max([n for n in ast.walk(tree) if isinstance(n,ast.FunctionDef)
                    and n.name=='readback_cache_files' and n.lineno<call.lineno],key=lambda n:n.lineno)
        exec(compile(ast.Module(body=[helper],type_ignores=[]),'<isolated-cache-generator>','exec'),env)
    ProbePath.tested=[]
    iterator=eval(compile(ast.Expression(body=expression),'<isolated-cache-expression>','eval'),env)
    assert not ProbePath.tested,(key,'IS_FILE_FILTER_BEFORE_POOL')
    paths=list(iterator)
    assert paths and all(isinstance(p,ProbePath) for p in paths),key
    assert not any('/score-native/' in str(p) or p.suffix=='.rds' or p.name=='model.bin' for p in paths),key
    assert all(not p.name.startswith('missing') for p in paths),key
    if worker=='_q_coordinate_read_job':
        assert root/'actual-input.json' in paths and root/'input.json' not in paths
        assert root/'native/C1/object-audit.json' in paths
    if worker=='_a12_projected_input_read_job':
        assert root/'target/direct/P1/fit-response.csv' in paths
    results.append({'call':key,'post_pool_path_checks':len(ProbePath.tested),'files':len(paths),
                    'file_filter_lazy':True,'referenced_model_excluded':True})
assert len(results)==13
(OUT/'readback-cache-files-checks.json').write_text(json.dumps({'status':'PASS','cases':results,
    'scope':'Synthetic path generation only; no fits, R, real data or cache syscalls.'},indent=2)+'\n')
print(json.dumps({'status':'PASS','calls':13,'file_filter_lazy':True,'referenced_models_excluded':True,
    'checks':str(OUT/'readback-cache-files-checks.json')}))
