"""Actual runtime cgroup reader against /tmp fixtures; zero scientific calls."""
from __future__ import annotations
import ast
import hashlib
import json
import os
from pathlib import Path
import sys
import tempfile
from unittest.mock import patch

REPO = Path(sys.argv[1] if len(sys.argv) > 1 else '/Users/liuningyuan/Desktop/Result/Machine Learning/PADML_F45_REBUILD')
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(REPO))
from padml import runtime
from padml.bundle import ContractError
G = 1024**3
KEYS = {'path','version','total_bytes','limit_bytes','anon_bytes','file_bytes','stat_keys','stat_status'}
SOURCE = Path(runtime.__file__).read_text()
TREE = ast.parse(SOURCE)
def function_hash(name):
    n = next(n for n in TREE.body if isinstance(n, ast.FunctionDef) and n.name == name)
    return hashlib.sha256(ast.dump(n, include_attributes=False).encode()).hexdigest()

# Unchanged detailed scientific release functions; this test is confined to admission.
for name, expected in {
    'release_step_resources':'b032e8ff557ce51d76afbe20b402f6e3f3d97b6304b2d7c43d7f55dc73c1ac54',
    'validate_resource_release':'2652468b85e4505179bbc7905f336606f36bacc652c6048346ee837af93473d4',
}.items():
    assert function_hash(name) == expected, 'SCIENTIFIC_RELEASE_CONTRACT_CHANGED:' + name

rows = []
def run_case(name, expected, *, version=2, usage=59*G, stats=None, parent=None, host=100*G):
    with tempfile.TemporaryDirectory(prefix='cgroup-fixture-') as temp:
        mount = Path(temp) / 'memory'
        leaf = mount / 'parent/leaf'
        leaf.mkdir(parents=True)
        limits = [(leaf,60*G,usage,stats),(leaf.parent,*(parent or (80*G,G,None))),
                  (mount,'max' if version == 2 else 1000*G,G,None)]
        for directory,limit,current,counters in limits:
            (directory / ('memory.max' if version == 2 else 'memory.limit_in_bytes')).write_text(str(limit)+'\n')
            (directory / ('memory.current' if version == 2 else 'memory.usage_in_bytes')).write_text(str(current)+'\n')
            if counters is not None:
                (directory / 'memory.stat').write_text(counters if isinstance(counters,str) else
                    ''.join(f'{key} {value}\n' for key,value in counters.items()))
        reads=[]
        original_read=Path.read_text
        proc={
            '/proc/self/mountinfo':f'1 0 0:1 / {mount} ro - '+('cgroup2 cgroup rw\n' if version==2 else 'cgroup cgroup rw,memory\n'),
            '/proc/self/cgroup':'0::/parent/leaf\n' if version==2 else '0::/parent/leaf\n1:memory:/parent/leaf\n',
            '/proc/meminfo':f'MemTotal: 999999999 kB\nMemAvailable: {host//1024} kB\n',
            '/proc/self/smaps_rollup':'Rss: 73 kB\nPss: 20 kB\n',
            '/proc/self/stat':f'{os.getpid()} (fixture) '+' '.join(['S']+['0']*18+['12345'])+'\n',
        }
        def read(path,*args,**kwargs):
            if str(path).startswith('/proc/'):
                reads.append(str(path))
                return proc[str(path)]
            return original_read(path,*args,**kwargs)
        with patch.object(runtime.sys,'platform','linux'), patch.object(Path,'read_text',read):
            observed=[]
            headrooms=runtime._cgroup_memory_headrooms(observed)
            if isinstance(expected,str):
                try:
                    runtime._available_memory_bytes()
                except ContractError as exc:
                    actual=str(exc.__cause__ or exc)
                else:
                    raise AssertionError('EXHAUSTED_MEMORY_ACCEPTED')
            else:
                actual=runtime._available_memory_bytes()
            assert actual == expected, (name,actual,expected)
            assert len(observed)==3 and all(set(r)==KEYS for r in observed), name
            assert observed[0]['stat_keys']==(['anon','file'] if version==2 else ['total_rss','total_cache'])
            assert observed[0]['total_bytes']==usage and observed[0]['limit_bytes']==60*G
            before=runtime.observe_step_memory()
            detailed=runtime.release_step_resources([],owner='ISOLATED_CGROUP_FIXTURE',before=before,
                released_references=[],force_cache=True)
            runtime.validate_resource_release(detailed)
            assert set(detailed)=={'owner','before','after','released_references','gc_collected',
                'reader_scan_status','visible_processes_checked','files','claim'}
            assert all(set(r)==KEYS for s in (detailed['before'],detailed['after']) for r in s['cgroups'])
            assert all(r['total_bytes'] in (usage, parent[1] if parent else G, G) for r in observed)
        rows.append({'case':name,'version':version,'actual':actual,'expected':expected,
                     'ancestor_headrooms':headrooms,'detailed_schema_unchanged':True})

clean={'anon':G,'file':57*G,'inactive_file':55*G,'shmem':0,'file_dirty':0,'file_writeback':0,
       'active_file':2*G,'slab_reclaimable':G,'swapcached':20*G}
run_case('v2_clean_inactive',56*G,stats=clean)
run_case('v2_clean_cache_at_limit',55*G,usage=60*G,stats=clean)
run_case('v2_dirty_and_writeback_excluded',53*G,stats={**clean,'file_dirty':2*G,'file_writeback':G})
run_case('v2_shmem_excluded',2*G,stats={**clean,'shmem':56*G})
run_case('v2_active_slab_swap_no_credit',G,stats={**clean,'inactive_file':0})
run_case('v2_missing_stat_raw_headroom',G)
run_case('v2_missing_counter_raw_headroom',G,stats={k:v for k,v in clean.items() if k!='shmem'})
run_case('v2_invalid_counter_raw_headroom',G,stats={**clean,'file_dirty':-1})
run_case('parent_including_siblings_wins',G,stats=clean,parent=(80*G,79*G,None))
run_case('host_memavailable_wins',G//2,stats=clean,host=G//2)
run_case('v2_true_anon_exhaustion_rejected','MEMORY_RESOURCE_EXHAUSTED',usage=60*G,
         stats={**clean,'file':0,'inactive_file':0})
v1={'total_rss':G,'total_cache':57*G,'total_inactive_file':55*G,'total_shmem':0,
    'total_dirty':0,'total_writeback':0,'cache':1,'inactive_file':1}
run_case('v1_hierarchical_totals_and_unmounted_unified',56*G,version=1,stats=v1)
run_case('v1_parent_sibling_limit_wins',G,version=1,stats=v1,parent=(80*G,79*G,None))
result={'status':'PASS','runtime_file':str(Path(runtime.__file__)),
    'runtime_sha256':hashlib.sha256(SOURCE.encode()).hexdigest(),
    'cgroup_function_ast_sha256':function_hash('_cgroup_memory_headrooms'),
    'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'cases':rows,'scientific_release_functions_unchanged':True,
    'scope':'Actual production functions, mocked proc and isolated cgroup files; no remote operations, fits, or production writes.'}
path=OUT/'cgroup-headroom-actual.json'
path.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':'PASS','cases':len(rows),'cgroup_function_ast_sha256':result['cgroup_function_ast_sha256'],
                  'report':str(path),'schema_unchanged':True}))
