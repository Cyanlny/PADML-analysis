"""Actual producer live-disk guards with explicitly UNFITTED point material.
Only /tmp is written. Native/R/model work is stubbed; this is not science QA.
"""
from __future__ import annotations
from contextlib import ExitStack
import hashlib
import inspect
import json
from pathlib import Path
import sys
import tempfile
from unittest.mock import patch

REPO=Path(sys.argv[1] if len(sys.argv)>1 else '/Users/liuningyuan/Desktop/Result/Machine Learning/PADML_F45_REBUILD')
OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(REPO))
from padml import f4, f5_sensitivity as a, runtime
from padml.bundle import ContractError, canonical_json_bytes
R=8*1024**2
sizes={'aar-point-evaluation.json':3340947,'point-evaluation.json':4414837,
       'point-native.zip':1763948,'primary-point-evaluation.json':1192826,
       'primary-point-native.zip':597526}
expected=sum(sizes.values())*3+16384
assert sum(sizes.values())==11310084 and expected==33946636

def payload(size):
    empty={'UNFITTED_RESOURCE_TEST_PADDING':''}
    empty['UNFITTED_RESOURCE_TEST_PADDING']='x'*(size-len(canonical_json_bytes(empty)))
    assert len(canonical_json_bytes(empty))==size
    return empty
primary=payload(sizes['primary-point-evaluation.json'])
aar=payload(sizes['aar-point-evaluation.json'])
merged=payload(sizes['point-evaluation.json'])
policy={'configured_worker_ceiling':runtime.CPU_MINUS_8,'memory_bytes_per_worker':2*1024**3,
        'scratch_bytes_per_worker':1,'memory_reserve_bytes':0,'scratch_reserve_bytes':0,
        'transfer_archive_worker_ceiling':1000}
handoff={'patient_ids':['UNFITTED_1'],'patient_keys':{'UNFITTED_1':'UNFITTED_KEY'},
         'centers':['36'],'horizons':list(range(37)),
         'survival':{branch:[[1.0]*37] for branch in ('PRIMARY',*a.nested_loco.AAR_ESTIMANDS)}
            if hasattr(a,'nested_loco') else {'PRIMARY':[[1.0]*37]},
         'science_decision':{'UNFITTED_RESOURCE_TEST':True},'primary_ooc_sha256':'0'*64}
class PoolReached(Exception):
    pass

rows=[]
for prepare in (True,False):
    for delta in (-1,0):
        with tempfile.TemporaryDirectory(prefix='point-live-disk-',dir=OUT) as temp, ExitStack() as stack:
            base=Path(temp); root=base/'evaluation'; targets=[base/'shared.zip',base/'point.zip']
            seen=[]; calls={'UNFITTED_metric_calls':0,'UNFITTED_rng_calls':0,'pool_calls':0}
            need=expected+(0 if prepare else 3*1000*R)
            def observed(path):
                point_complete=root.is_dir() and all((root/n).is_file() for n in sizes)
                available=need+delta if Path(path)==root and point_complete else 10**12
                seen.append({'root':str(path),'point_complete':point_complete,'available':available})
                return {'effective_cpus':32,'available_memory_bytes':10**12,
                        'scratch_available_bytes':available,'scratch_root':str(path)}
            def rng(*args,**kwargs):
                kwargs['retained_archive'].write_bytes(b'UNFITTED RNG transport')
                calls['UNFITTED_rng_calls']+=1
                return {'replicate_count':1000,'draws':[[0] for _ in range(1000)]}
            def evaluate(*args,**kwargs):
                assert 'replay_native_archive' not in kwargs
                kwargs['native_archive'].write_bytes(b'x'*sizes['point-native.zip'])
                calls['UNFITTED_metric_calls']+=1
                return aar
            def pool(*args,**kwargs):
                calls['pool_calls']+=1
                raise PoolReached()
            changes=[(a,'_validate_a12_handoff',lambda p:p),
                     (a,'_a12_prediction_branches',lambda p:('PRIMARY','A1','A2','A3')),
                     (a,'_a12_evaluation_scope',lambda p:{}),
                     (a,'_a12_primary_point_origin',lambda *x,**kw:primary),
                     (a,'_validate_a12_native_evaluation',lambda *x,**kw:None),
                     (a,'_merge_a12_point_evaluations',lambda *x:merged),
                     (a,'_a12_bootstrap_binding',lambda *x:{'UNFITTED_RESOURCE_TEST':True}),
                     (a,'bootstrap_draws',rng),(a,'evaluate_predictions',evaluate),
                     (a,'_bounded_ordered_spawn',pool),
                     (runtime,'observe_execution_resources',observed),
                     (f4,'_f45_source_member_sha256',lambda:{'UNFITTED_RESOURCE_TEST':'0'*64})]
            for obj,name,value in changes:
                stack.enter_context(patch.object(obj,name,value))
            error=None
            try:
                a.evaluate_a12_incremental_value(handoff,b'UNFITTED_RESPONSE',formal=True,
                    evidence_root=root,resource_policy=policy,retained_bytes_per_replicate=R,
                    retained_primary_point=primary,primary_point_native=b'x'*sizes['primary-point-native.zip'],
                    **({'bootstrap_input_target':targets[0],'point_archive_target':targets[1]} if prepare else {}))
            except (ContractError,PoolReached) as exc:
                error=type(exc).__name__+':'+str(exc)
            execution=json.loads((root/'execution.json').read_bytes())
            reservation=execution['resource_reservation']
            assert {name:(root/name).stat().st_size for name in sizes}==sizes
            assert reservation['point_retention_reserved_bytes']==expected
            assert reservation['retained_bytes_per_replicate']==R
            assert reservation['metric_retention_reserved_bytes']==expected+(0 if prepare else 1000*R)
            assert execution['effective_policy']['memory_bytes_per_worker']==2*1024**3
            assert execution['effective_policy']['scratch_reserve_bytes']==0
            assert execution['point_storage_observation']['scratch_available_bytes']==need+delta
            assert calls['UNFITTED_metric_calls']==calls['UNFITTED_rng_calls']==1
            if delta<0:
                assert error=='ContractError:F5_A12_BOOTSTRAP_PACKAGING_SPACE_INSUFFICIENT',error
                assert calls['pool_calls']==0 and not any(p.exists() for p in targets)
            elif prepare:
                assert error is None and all(p.is_file() for p in targets)
                assert calls['pool_calls']==0
            else:
                assert error=='PoolReached:' and calls['pool_calls']==1,error
            assert not list(root.glob('replicate-*.zip'))
            rows.append({'prepare_only':prepare,'free_delta_bytes':delta,'result':'PASS',
                'required_free_bytes':need,'point_material_bytes':sum(sizes.values()),
                'point_reserved_bytes':expected,'retained_bytes_per_replicate':R,
                'metric_retention_reserved_bytes':reservation['metric_retention_reserved_bytes'],
                'observed_error':error,'coordinate_calls':0,'evidence_preserved_on_rejection':True})
output={'status':'PASS','test':'ACTUAL_PRODUCER_POINT_LIVE_DISK_BOUNDARY_UNFITTED',
        'source_function_sha256':hashlib.sha256(inspect.getsource(a.evaluate_a12_incremental_value).encode()).hexdigest(),
        'rows':rows,'scientific_completion_claim':False,'writes':'ONLY_TMP'}
(OUT/'point-live-disk-results.json').write_text(json.dumps(output,indent=2)+'\n')
print(json.dumps(output,sort_keys=True))
