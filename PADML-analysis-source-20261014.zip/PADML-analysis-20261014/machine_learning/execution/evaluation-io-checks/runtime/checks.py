"""Isolated cache and existing prediction-seal checks; no clinical inputs or fits."""
from __future__ import annotations

import argparse
import ast
import copy
import hashlib
import json
import math
import os
from pathlib import Path
import subprocess
import sys
import tempfile
from contextlib import ExitStack
from unittest.mock import patch

REPO = Path('/Users/liuningyuan/Desktop/Result/Machine Learning/PADML_F45_REBUILD')
WORK = Path(__file__).resolve().parent
BASE = '3b971cb'
sys.path.insert(0, str(REPO))
from padml import runtime, f2_kernel as k
from padml import f4
from padml.bundle import ContractError, canonical_json_bytes


def baseline(module):
    return subprocess.run(['git', 'show', BASE + ':' + module], cwd=REPO,
                          check=True, capture_output=True).stdout.decode()


def definition(source, name):
    return next(n for n in ast.parse(source).body
                if isinstance(n, (ast.FunctionDef, ast.ClassDef)) and n.name == name)


def ast_sha(node):
    return hashlib.sha256(ast.dump(node, include_attributes=False).encode()).hexdigest()


def original_functions():
    source = baseline('padml/f2_kernel.py')
    namespace = dict(k.__dict__)
    for name in ('_seal_prediction_matrix', '_monthly_prediction_seal', '_pool_prediction_batch'):
        exec(compile(ast.Module(body=[definition(source, name)], type_ignores=[]),
                     '<sealed-old-function>', 'exec'), namespace)
    return namespace


def prediction_golden():
    old = original_functions()
    ids = ['SYNTHETIC_A', 'SYNTHETIC_B', 'SYNTHETIC_C']
    cases = []
    for horizons in (list(range(1, 37)), list(range(37)), [6, 12, 24, 36]):
        values = [[math.exp(-(i + 1) * t / 1000) for t in horizons] for i in range(3)]
        expected = old['_seal_prediction_matrix'](ids, values, horizons)
        actual = k._seal_prediction_matrix(ids, values, horizons)
        assert canonical_json_bytes(actual) == canonical_json_bytes(expected)
        cases.append(dict(horizons=horizons, sha256=expected['sha256']))
    monthly_input = old['_seal_prediction_matrix'](
        ids, [[math.exp(-(i + 1) * t / 1000) for t in range(1, 37)] for i in range(3)], list(range(1, 37)))
    assert canonical_json_bytes(k._monthly_prediction_seal(monthly_input)) == canonical_json_bytes(
        old['_monthly_prediction_seal'](monthly_input))
    produced = [{'sealed_prediction': old['_seal_prediction_matrix'](ids,
        [[math.exp(-(i + 1) * t / (1000 + mi)) for t in range(37)] for i in range(3)], list(range(37)))}
        for mi in range(20)]
    expected_pool = old['_pool_prediction_batch'](produced, list(range(37)))
    assert canonical_json_bytes(k._pool_prediction_batch(produced, list(range(37)))) == canonical_json_bytes(expected_pool)
    for bad in (True, float('nan'), float('inf'), -1, 1.01):
        values = [[1.0, .9], [1.0, bad], [1.0, .8]]
        for function in (old['_seal_prediction_matrix'], k._seal_prediction_matrix):
            try:
                function(ids, values, [1, 2])
            except ContractError as error:
                assert str(error) == 'F2_PREDICTION_SEAL_INVALID'
            else:
                raise AssertionError('MALFORMED_MATRIX_ACCEPTED')
    return {'seal_cases': cases, 'm20_pool_sha256': expected_pool['sha256'],
            'monthly_and_m20_byte_equal': True, 'malformed_cases': 5}


def snapshot_factory():
    counter = 100
    def observe():
        nonlocal counter
        counter += 2
        return {'pid': os.getpid(), 'started_ns': counter, 'finished_ns': counter + 1,
                'clock': 'MONOTONIC_NS', 'rss_bytes': 1024,
                'rss_source': '/proc/self/smaps_rollup:Rss', 'cgroup_status': 'UNKNOWN', 'cgroups': []}
    return observe


def file_pin(path):
    st = path.stat()
    return (hashlib.sha256(path.read_bytes()).hexdigest(), st.st_dev, st.st_ino,
            st.st_size, st.st_mtime_ns, st.st_ctime_ns)


def original_release_golden():
    old_source = baseline('padml/runtime.py')
    current_source = (REPO / 'padml/runtime.py').read_text()
    functions = ('release_step_resources', 'validate_resource_release')
    hashes = {}
    for name in functions:
        hashes[name] = ast_sha(definition(old_source, name))
        assert hashes[name] == ast_sha(definition(current_source, name)), name + ':CONTRACT_CHANGED'
    path = WORK / 'SYNTHETIC_original_release.bin'
    path.write_bytes(b'SYNTHETIC-NOT-SCIENTIFIC')
    pin = file_pin(path)
    advised = []
    observe = snapshot_factory()
    def no_scan(*_a, **_k):
        raise AssertionError('FORCE_RELEASE_SCANNED_READERS')
    with patch.object(runtime, 'observe_step_memory', observe), \
         patch.object(runtime, '_visible_open_file_keys', no_scan), \
         patch.object(runtime.gc, 'collect', lambda: 0), \
         patch.object(runtime.os, 'posix_fadvise', lambda fd, a, b, c: advised.append(os.fstat(fd).st_ino), create=True), \
         patch.object(runtime.os, 'POSIX_FADV_DONTNEED', 4, create=True):
        report = runtime.release_step_resources([path], owner='SYNTHETIC_GOLDEN',
            before=observe(), released_references=['dead_synthetic_reference'], force_cache=True)
    runtime.validate_resource_release(report)
    assert advised == [path.stat().st_ino] and file_pin(path) == pin
    assert set(report) == {'owner', 'before', 'after', 'released_references', 'gc_collected',
        'reader_scan_status', 'visible_processes_checked', 'files', 'claim'}
    row = report['files'][0]
    assert set(row) == {'path', 'device', 'inode', 'size_bytes', 'mtime_ns', 'ctime_ns', 'status', 'error'}
    assert row['status'] == 'ADVISED' and row['error'] is None
    assert report['reader_scan_status'] == 'WAIVED_BY_USER'
    unknown = {'status': 'UNKNOWN', 'owner': 'SYNTHETIC_GOLDEN', 'pid': os.getpid(), 'reason': 'synthetic unavailable'}
    runtime.validate_resource_release(unknown)
    rejected = []
    for name in ('extra_claim', 'negative_size', 'fake_advice', 'duplicate_path'):
        bad = copy.deepcopy(report)
        if name == 'extra_claim':
            bad['freed_bytes'] = row['size_bytes']
        elif name == 'negative_size':
            bad['files'][0]['size_bytes'] = -1
        elif name == 'fake_advice':
            bad['files'][0]['error'] = 'NOT_ACTUALLY_ADVISED'
        else:
            bad['files'].append(copy.deepcopy(bad['files'][0]))
        try:
            runtime.validate_resource_release(bad)
        except ContractError:
            rejected.append(name)
        else:
            raise AssertionError('INVALID_RELEASE_ACCEPTED:' + name)
    return {'function_ast_sha256': hashes, 'bytes_and_stat_unchanged': True,
            'old_unknown_readable': True, 'rejected': rejected}


def metrics_golden():
    namespace = dict(f4.__dict__)
    source = baseline('padml/f4.py')
    current_source = (REPO / 'padml/f4.py').read_text()
    arithmetic = {}
    for original_name, helper_name in (('prediction_error', '_prediction_error_values'),
                                       ('decision_curve', '_decision_curve_values')):
        old_body = definition(source, original_name).body[2:]
        new_body = definition(current_source, helper_name).body[1:]
        old_ast = ast.dump(ast.Module(body=old_body, type_ignores=[]), include_attributes=False)
        new_ast = ast.dump(ast.Module(body=new_body, type_ignores=[]), include_attributes=False)
        assert old_ast == new_ast, helper_name + ':ARITHMETIC_BODY_CHANGED'
        arithmetic[helper_name] = hashlib.sha256(old_ast.encode()).hexdigest()
    for name in ('prediction_error', 'decision_curve'):
        exec(compile(ast.Module(body=[definition(source, name)], type_ignores=[]),
                     '<sealed-old-metrics>', 'exec'), namespace)
    ids = ['SYNTHETIC_A', 'SYNTHETIC_B', 'SYNTHETIC_C', 'SYNTHETIC_D']
    survival = [[math.exp(-(i + 1) * t / 100) for t in range(37)] for i in range(4)]
    contexts = []
    for profile in ('estimable', 'support_gap', 'zero_prevalence'):
        rows = [{'horizon': t, 'status': 'ESTIMABLE', 'reasons': [],
                 'weights': [1.1, .8, 0.0, 1.0],
                 'truth': [1.0] * 4 if profile == 'zero_prevalence' else [0.0, 1.0, 0.0, 1.0]}
                for t in range(37)]
        if profile == 'support_gap':
            rows[13].update(status='NOT_ESTIMABLE', reasons=['CENSORING_SUPPORT_BELOW_0_05'])
            rows[36].update(status='NOT_ESTIMABLE', reasons=['CENSORING_SUPPORT_BELOW_0_05'])
        context = {'patient_ids': ids, 'rows': rows}
        expected = {**namespace['prediction_error'](ids, survival, context),
                    **{f'dca_{t}': namespace['decision_curve'](ids, survival, context, horizon=t)
                       for t in (6, 12, 24, 36)}}
        count = []
        original = f4._seal_prediction_matrix
        def seal(*args, **kwargs):
            count.append(1)
            return original(*args, **kwargs)
        with patch.object(f4, '_seal_prediction_matrix', seal):
            actual = f4._prediction_metrics(ids, survival, context)
        assert len(count) == 1, 'JOINT_METRICS_MUST_SEAL_ONCE'
        assert canonical_json_bytes(actual) == canonical_json_bytes(expected), profile + ':NUMERIC_DRIFT'
        contexts.append({'profile': profile, 'sha256': hashlib.sha256(canonical_json_bytes(actual)).hexdigest(),
                         'seal_calls': len(count)})
    return {'arithmetic_body_ast_equal': arithmetic, 'byte_equal_cases': contexts, 'r_calls': 0}


def scoped_release_checks():
    results = []
    failures = []
    def case(name, scope='stage', count=2, global_ok=False, advice_fail=False, observation_fail=False, aliases=False):
        root = Path(tempfile.mkdtemp(prefix=name + '-', dir=WORK)).resolve()
        unit = root / 'units' / 'SYNTHETIC_UNIT'
        unit.mkdir(parents=True)
        targets = []
        for i in range(count):
            path = unit / f'input-{i:04d}.bin'
            path.write_bytes(b'SYNTHETIC-' + bytes(str(i), 'ascii'))
            targets.append(path)
        foreign = root / 'UNTOUCHED_OTHER_UNIT.bin'
        foreign.write_bytes(b'SYNTHETIC-FOREIGN')
        before = {str(p): file_pin(p) for p in [*targets, foreign]}
        supplied = list(targets)
        if aliases and targets:
            alias = unit / 'hardlink.bin'
            os.link(targets[0], alias)
            supplied.extend([targets[0], alias])
            before[str(targets[0])] = file_pin(targets[0])
        by_inode = {p.stat().st_ino: p for p in [*targets, foreign]}
        syncs, drops, walks, advised, fsynced = [], [], [], [], []
        original_walk, original_sync, original_write = os.walk, os.fsync, Path.write_text
        def walk(path, *args, **kwargs):
            walks.append(str(path))
            assert scope == 'run' or Path(path) != root, 'STAGE_WALKED_RUN'
            return original_walk(path, *args, **kwargs)
        def sync():
            assert scope == 'run', 'STAGE_CALLED_GLOBAL_SYNC'
            syncs.append(1)
        def write_text(path, content, *args, **kwargs):
            if str(path) == '/proc/sys/vm/drop_caches':
                assert scope == 'run', 'STAGE_CALLED_GLOBAL_DROP'
                drops.append(content)
                if not global_ok:
                    raise PermissionError(13, 'SYNTHETIC_GLOBAL_DENIED')
                return len(content)
            return original_write(path, content, *args, **kwargs)
        def advise(fd, *_args):
            inode = os.fstat(fd).st_ino
            advised.append(str(by_inode.get(inode, inode)))
            if advice_fail:
                raise OSError(5, 'SYNTHETIC_FILE_ADVICE_FAILURE')
        def fsync(fd):
            inode = os.fstat(fd).st_ino
            if inode in by_inode:
                fsynced.append(str(by_inode[inode]))
            return original_sync(fd)
        def resource_observation(path):
            if observation_fail:
                raise ContractError('MEMORY_RESOURCE_EXHAUSTED')
            return {'effective_cpus': 32, 'available_memory_bytes': 8 * 1024**3,
                    'scratch_available_bytes': 1024**4, 'scratch_root': str(path)}
        with ExitStack() as stack:
            stack.enter_context(patch.dict(os.environ, {'PADML_F45_RUN_PATH': str(root / 'run.json')}))
            stack.enter_context(patch.object(runtime, 'observe_step_memory', snapshot_factory()))
            stack.enter_context(patch.object(runtime, 'observe_execution_resources', resource_observation))
            stack.enter_context(patch.object(runtime.gc, 'collect', lambda: 0))
            stack.enter_context(patch.object(runtime.os, 'walk', walk))
            stack.enter_context(patch.object(runtime.os, 'sync', sync, create=True))
            stack.enter_context(patch.object(runtime.os, 'fsync', fsync))
            stack.enter_context(patch.object(Path, 'write_text', write_text))
            stack.enter_context(patch.object(runtime.os, 'posix_fadvise', advise, create=True))
            stack.enter_context(patch.object(runtime.os, 'POSIX_FADV_DONTNEED', 4, create=True))
            report = runtime.release_f45_cumulative_files(supplied, owner=name, report_root=unit,
                                                        scope=scope)
        for path, pin in before.items():
            assert file_pin(Path(path)) == pin, 'SCIENTIFIC_FILE_CHANGED'
        assert report['files_deleted'] == 0
        summary = report['cumulative']
        if observation_fail:
            if summary.get('attempted_files') != count or summary.get('advised_files') != count:
                failures.append({'case': name, 'defect': 'POST_OBSERVATION_DISCARDED_REAL_SYSCALL_RESULTS',
                                 'actual_advice_calls': len(advised), 'report': report})
        elif scope == 'stage':
            assert not syncs and not drops and not walks
            assert str(foreign) not in advised
            assert summary['attempted_files'] == count
            assert summary['advised_files'] == (0 if advice_fail else count)
            assert summary['failed_files'] == (count if advice_fail else 0)
            assert summary['duplicate_files'] == (2 if aliases else 0)
            assert summary['attempted_bytes'] == sum(p.stat().st_size for p in targets)
            assert set(fsynced) == set(map(str, targets))
            assert summary['global_cache']['status'] == 'NOT_REQUESTED'
        elif global_ok:
            assert len(syncs) == len(drops) == 1 and not walks and not advised and not fsynced
            assert summary['global_cache']['status'] == 'SUCCEEDED'
            assert summary['enumerated'] is False and summary['attempted_files'] == 0
        else:
            assert len(syncs) == len(drops) == 1 and walks == [str(root)]
            assert str(foreign) in advised and not fsynced
            assert summary['global_cache']['status'] == 'FAILED'
            assert summary['attempted_files'] == count + 1
        size = len(canonical_json_bytes({key: value for key, value in report.items() if key != 'report_path'}))
        assert size < 32 * 1024, 'UNBOUNDED_RELEASE_REPORT'
        if advice_fail and not observation_fail:
            assert len(summary['error_samples']) == min(16, count)
            assert summary['errors_omitted'] == max(0, count - 16)
            assert summary['error_counts']['FILE_ADVICE:5'] == count
        results.append({'case': name, 'report_bytes': size, 'advice_calls': len(advised),
                        'global_sync_calls': len(syncs), 'whole_run_walks': len(walks)})
    case('stage_basic', aliases=True)
    case('stage_empty', count=0)
    case('stage_bounded', count=256)
    case('stage_advice_errors', count=24, advice_fail=True)
    case('run_global_success', scope='run', global_ok=True)
    case('run_global_denied', scope='run')
    case('stage_post_observation_failure', observation_fail=True)
    return {'cases': results, 'defects': failures}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--golden', action='store_true')
    parser.add_argument('--new', action='store_true')
    args = parser.parse_args()
    if args.golden:
        result = {'status': 'PASS', 'baseline_commit': BASE,
                  'release': original_release_golden(), 'prediction': prediction_golden(),
                  'scientific_inputs': 0, 'model_fits': 0, 'r_calls': 0,
                  'production_writes': 0, 'stage_scope_check': 'PENDING_WRITER_CHANGE'}
        (WORK / 'golden.json').write_text(json.dumps(result, indent=2) + '\n')
        print(json.dumps(result, sort_keys=True))
    if args.new:
        result = {'release_golden': original_release_golden(), 'metrics': metrics_golden(),
                  'scope': scoped_release_checks(), 'scientific_inputs': 0,
                  'model_fits': 0, 'r_calls': 0, 'production_writes': 0}
        result['status'] = 'DEFECT_FOUND' if result['scope']['defects'] else 'PASS'
        (WORK / 'new-checks.json').write_text(json.dumps(result, indent=2) + '\n')
        print(json.dumps(result, sort_keys=True))


if __name__ == '__main__':
    main()
