"""Bounded real paired check, owned only by the existing remote executor.

No dispatch mode and no formal completion receipt are created. The eight original
paired coordinates stay in the production evaluation directory for continuation.
"""
from __future__ import annotations

import argparse, ast, fcntl, json, os, platform, resource, shutil, subprocess
import threading, time, zipfile
from functools import partial
from pathlib import Path
from unittest.mock import patch

from padml import f4, f5, f5_sensitivity as a, nested_loco as nested
from padml import run as runs, runtime
from padml.bundle import canonical_json_bytes as enc, sha256_bytes as sha, sha256_file


def forbidden(*args, **kwargs):
    raise AssertionError('VALIDATION_MUST_NOT_ENTER_DEVELOPMENT_OR_FULL_ARCHIVE_REPLAY')


# Spawn imports this module as __mp_main__; the same guards apply in every child.
GUARDS = {f4: ('execute_o_fit_bundle', 'load_o_fit_execution_archive',
    'load_o_fit_aggregate_archive', 'aggregate_o_fit_execution_archives'),
    a: ('_load_a12_outer_archive', '_a12_context', '_execute_ablation_component')}
for module, names in GUARDS.items():
    for name in names:
        assert hasattr(module, name), name
        setattr(module, name, forbidden)


def file_state(path, digest=False):
    if not path.exists():
        return None
    st = path.stat()
    return {'size_bytes': st.st_size, 'mtime_ns': st.st_mtime_ns,
            **({'sha256': sha256_file(path)} if digest else {})}


def proc_io():
    return {key: int(value) for key, value in
            (line.split(':') for line in Path('/proc/self/io').read_text().splitlines())}


def old_arithmetic(candidate):
    with zipfile.ZipFile(candidate / 'evaluation-io-predecessor/source.zip') as archive:
        raw = archive.read('padml/f4.py')
    namespace = dict(vars(f4))
    tree = ast.parse(raw)
    for name in ('prediction_error', 'decision_curve'):
        node = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == name)
        exec(compile(ast.Module(body=[node], type_ignores=[]), '<original-arithmetic>', 'exec'), namespace)
    return namespace


def compare_metrics(fixed, response_csv, old):
    fields, responses = a._response_rows(response_csv)
    checked = 0
    for scope in ('MICRO', *sorted(set(fixed['centers']))):
        indices = [i for i, center in enumerate(fixed['centers']) if scope == 'MICRO' or center == scope]
        ids = [fixed['patient_ids'][i] for i in indices]
        centers = [fixed['centers'][i] for i in indices]
        response = a._write_response_subset(fields, responses, ids, None)
        context = f4.censoring_context(ids, centers, response)
        for matrix in fixed['survival'].values():
            values = [matrix[i] for i in indices]
            expected = {**old['prediction_error'](ids, values, context),
                **{f'dca_{h}': old['decision_curve'](ids, values, context, horizon=h)
                   for h in (6, 12, 24, 36)}}
            assert enc(expected) == enc(f4._prediction_metrics(ids, values, context))
            checked += 1
    return checked


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('candidate', type=Path)
    parser.add_argument('workspace', type=Path)
    parser.add_argument('--horizon', type=int, choices=(6, 12), required=True)
    args = parser.parse_args()
    candidate, workspace = args.candidate.resolve(strict=True), args.workspace.resolve(strict=True)
    assert platform.system() == 'Linux'
    assert Path(f4.__file__).resolve().is_relative_to(candidate / 'source')
    raw = (candidate / 'run.json').read_bytes()
    index, manifest = json.loads((candidate / 'validation-candidate.json').read_bytes()), json.loads(raw)
    production = Path(manifest['run_root'])
    assert workspace.is_relative_to(production / 'engineering')
    assert index['source_identity'] == sha(enc(f4._f45_source_member_sha256())) == manifest['source_identity']
    assert sha256_file(candidate / 'source.zip') == manifest['source_bundle_sha256']
    live_manifest = (production / 'run.json').read_bytes()
    # Same immutable manifest as the final release, without changing live run.json.
    staged = production / ('evaluation-validation-' + manifest['source_identity'][:12] + '.json')
    nested._write_exact_once(staged, raw, 'VALIDATION_RUN_DRIFT')
    os.environ.update(runtime.THREAD_ENV)
    os.environ.update(PADML_F45_RUN_PATH=str(staged), R_LIBS_USER=runtime.R_LIBRARY)
    rscript = Path(runtime.SEALED_RSCRIPT_EXECUTABLE)
    assert rscript.is_file() and os.access(rscript, os.X_OK)
    os.environ['PATH'] = str(rscript.parent) + os.pathsep + os.environ.get('PATH', '')
    assert Path(shutil.which('Rscript')).resolve() == rscript.resolve()
    run = runs.load_f45_run(staged)
    assert len(runs.f45_unit_predecessors(run)) == 28
    uid = f'EVALUATION-H{args.horizon:02d}'
    units = {u['unit_id']: u for u in run['units']}
    unit, root = units[uid], production / 'units' / uid
    assert root.is_dir() and not (root / 'unit.json').exists() and not (root / 'result.zip').exists()
    result = {'kind': 'REAL_COMPACT_PAIRED_BOUNDED_CHECK', 'unit_id': uid,
        'source_identity': index['source_identity'], 'run_identity': run['identity'],
        'resolved_rscript': str(rscript.resolve()),
        'validation_script_sha256': sha256_file(Path(__file__)),
        'formal_scientific_completion': False, 'replicate_ids': list(range(1, 9)),
        'guarded_development_entrypoints': [name for names in GUARDS.values() for name in names]}
    started, io_before = time.monotonic(), proc_io()
    result['before'] = runtime.observe_execution_resources(root)
    minimum_free = [shutil.disk_usage(root).free]
    stop = threading.Event()
    def observe_disk():
        while not stop.wait(2):
            minimum_free[0] = min(minimum_free[0], shutil.disk_usage(root).free)
    monitor = threading.Thread(target=observe_disk, daemon=True)
    with (production / 'active.lock').open('a+') as owner:
        fcntl.flock(owner, fcntl.LOCK_EX | fcntl.LOCK_NB)
        owner.seek(0)
        previous = [json.loads(line) for line in owner.read().splitlines() if line.strip()]
        groups = {row.get('pgid') for row in previous}
        assert all(type(group) is int and group > 0 for group in groups)
        live_groups = set(subprocess.check_output(['ps', '-eo', 'pgid='], text=True).split())
        assert all(str(group) not in live_groups for group in groups if group != os.getpgrp())
        owner.seek(0); owner.truncate()
        owner.write(json.dumps({'pid': os.getpid(), 'pgid': os.getpgrp(), 'unit_id': uid,
            'mode': 'unit', 'validation_only': True, 'run_identity': run['identity']})+'\n')
        owner.flush(); os.fsync(owner.fileno())
        def observe(group):
            owner.write(json.dumps({'pgid': group})+'\n'); owner.flush(); os.fsync(owner.fileno())
        runtime._POOL_GROUP_OBSERVER = observe
        monitor.start()
        try:
            source_roots = [production / 'units' / f'{kind}-H{args.horizon:02d}-O{o}'
                for kind in ('PRIMARY', 'AAR') for o in range(1, 7)]
            originals = {str(p / name): file_state(p / name, digest=name == 'unit.json')
                for p in source_roots for name in ('unit.json', 'unit.zip', 'input.zip', 'result.zip')}
            originals[str(root / 'primary.zip')] = file_state(root / 'primary.zip')
            prior = [p for p in source_roots if (p / 'evaluation-input.zip').exists()]
            begin = time.monotonic()
            prepared = a.prepare_f45_evaluation(run, unit, root)
            result['prepare_seconds'] = time.monotonic() - begin
            result['source_capsules_preexisting'] = len(prior)
            result['source_capsules'] = {p.name: file_state(p / 'evaluation-input.zip', digest=True) for p in source_roots}
            context = prepared['context']
            handoff = a._validate_a12_handoff(prepared['handoff'])
            response = context['evaluation_response_csv']
            fixed = {key: handoff[key] for key in ('patient_ids', 'centers', 'horizons', 'survival')}
            fixed.update(a._a12_evaluation_scope(handoff))
            stage = root / 'result.zip.work/evaluation'
            shared = production / 'shared'
            targets = (workspace / 'pilot-shared.zip', workspace / 'pilot-point.zip')
            point_members = ('plan.json', 'rng.zip', 'execution.json', 'primary-point-evaluation.json',
                'primary-point-native.zip', 'aar-point-evaluation.json', 'point-evaluation.json', 'point-native.zip')
            existing_scientific = {str(stage / n): file_state(stage / n, digest=True)
                for n in point_members if n != 'execution.json' and (stage / n).is_file()}
            ready = all((stage / name).is_file() for name in point_members)
            if ready:
                reservation = json.loads((stage / 'execution.json').read_bytes())['resource_reservation']
                ready = (reservation.get('retained_bytes_per_replicate') == run['budgets']['retained_bytes_per_replicate']
                    and reservation.get('point_retention_reserved_bytes') == (
                        3 * sum((stage / name).stat().st_size for name in a._A12_NESTED_POINT_MEMBERS) + 16384))
            if not ready:
                # These two small validation-only wrappers are not scientific inputs;
                # preserve any interrupted wrapper and use a new sibling on retry.
                stamp = str(time.time_ns())
                targets = tuple(p.with_name(stamp + '-' + p.name) for p in targets)
                a.evaluate_a12_incremental_value(prepared['handoff'], response,
                    formal=True, replicate_count=1000, evidence_root=stage,
                    resource_policy=run['resource_policy'],
                    retained_bytes_per_replicate=run['budgets']['retained_bytes_per_replicate'],
                    retained_primary_point=context['primary_point'], primary_point_native=context['primary_point_native'],
                    retained_rng_archive=shared / 'bootstrap.zip',
                    retained_rng_preparation_record=json.loads((shared / 'bootstrap-preparation.json').read_bytes()),
                    bootstrap_input_target=targets[0], point_archive_target=targets[1])
            assert all(file_state(Path(p), digest=True) == state for p, state in existing_scientific.items())
            result['point_reservation'] = json.loads((stage / 'execution.json').read_bytes())['resource_reservation']
            result['existing_plan_rng_point_unchanged'] = True
            admit = partial(a._admit_a12_bootstrap_io, resource_policy=run['resource_policy'], scratch_root=stage)
            plan, binding = a._replay_a12_bootstrap_plan(stage, handoff, response, nested=True, admit_io=admit)
            a._replay_a12_point(stage, handoff, response, retained_primary_point=context['primary_point'],
                primary_point_native=context['primary_point_native'], admit_io=admit)
            items = a._a12_replicate_items(plan, list(range(1, 9)))
            effective = json.loads((stage / 'execution.json').read_bytes())['effective_policy']
            admitted = runtime.resource_admission(effective, runtime.observe_execution_resources(stage), legal_tasks=8)
            paths = [stage / f'replicate-{r:04d}.zip' for r in range(1, 9)]
            result['preexisting_coordinates'] = [i for i, p in enumerate(paths, 1) if p.is_file()]
            before_coordinates = {str(p): file_state(p, digest=True) for p in paths if p.is_file()}
            begin = time.monotonic()
            pool = {}
            rows = runtime._bounded_ordered_spawn(partial(a._execute_and_replay_a12_bootstrap_replicate,
                root=stage, evaluation_handoff=fixed, response_csv=response, source_binding=binding,
                retained_bytes_per_replicate=run['budgets']['retained_bytes_per_replicate'], admit_io=admit),
                items, selected_slots=admitted['admitted_worker_ceiling'], execution_report=pool)
            result['eight_coordinate_seconds'], result['pool'] = time.monotonic()-begin, pool
            assert all(file_state(Path(p), digest=True) == state for p, state in before_coordinates.items())
            result['preexisting_coordinate_bytes_unchanged'] = True
            protected = [stage / n for n in ('plan.json', 'rng.zip', 'primary-point-evaluation.json',
                'primary-point-native.zip', 'aar-point-evaluation.json', 'point-evaluation.json', 'point-native.zip')] + paths
            pins = {str(p): file_state(p, digest=True) for p in protected}
            with patch.object(a, 'evaluate_predictions', side_effect=AssertionError('NO_NEW_METRIC_ENGINE_ON_RESUME')):
                for item, returned in zip(items, rows, strict=True):
                    read = a._a12_bootstrap_replicate(item, evaluation_handoff=fixed, response_csv=response,
                        work_root=stage, source_binding=binding, admit_io=admit,
                        retained_bytes_per_replicate=run['budgets']['retained_bytes_per_replicate'])
                    assert enc(read) == enc(returned['row'])
            with patch.object(a, 'prepare_f45_evaluation_source', side_effect=AssertionError('NO_SOURCE_REPREPARATION')):
                resumed = a.prepare_f45_evaluation(run, unit, root)
            assert enc(resumed['handoff']) == enc(prepared['handoff'])
            assert resumed['context']['primary_point_native'] == context['primary_point_native']
            assert all(file_state(Path(p), digest=True) == state for p, state in pins.items())
            assert all(file_state(Path(p), digest=Path(p).name == 'unit.json') == state for p, state in originals.items())
            old = old_arithmetic(candidate)
            checks = compare_metrics(fixed, response, old)
            for rid, indices in items:
                selected, sampled_response, _ = a.materialize_resampled_view(fixed, response, indices,
                    f'A12-PAIRED-{rid:04d}')
                checks += compare_metrics(selected, sampled_response, old)
            result.update(status='PASS', original_sources_unchanged=True, original_live_run_unchanged=True,
                completed_coordinates_unchanged_on_resume=True, preparation_resume_full_source_calls=0,
                new_prediction_model_fits=0, new_mice_selector_search_calls=0,
                arithmetic_comparisons=checks, original_and_joint_arithmetic_byte_equal=True,
                retained_coordinate_and_point_pins=pins, patient_count=len(handoff['patient_ids']),
                compact_input=file_state(root / 'evaluation-input.zip', digest=True),
                capacity=json.loads((root / 'evaluation-capacity.json').read_bytes()))
            assert (production / 'run.json').read_bytes() == live_manifest
        except BaseException as error:
            result.update(status='FAILED', error=type(error).__name__ + ': ' + str(error))
            raise
        finally:
            stop.set(); monitor.join()
            # All original pools have exited at this point. Exactly one whole-run release.
            result['run_release'] = runtime.release_f45_cumulative_files([], owner='BOUNDED_COMPACT_EVALUATION_EXIT',
                scope='run', report_root=root)
            runtime._POOL_GROUP_OBSERVER = None
            after_io = proc_io()
            result.update(elapsed_seconds=time.monotonic()-started,
                parent_io_delta={k: after_io[k]-io_before[k] for k in io_before},
                parent_max_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
                largest_child_max_rss_kib=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,
                minimum_free_bytes_sampled_2s=minimum_free[0], after=runtime.observe_execution_resources(root))
            (workspace / 'validation.json').write_bytes(enc(result))
            print(json.dumps(result, sort_keys=True), flush=True)


if __name__ == '__main__':
    if os.getpgrp() != os.getpid():
        os.setsid()
    main()
