"""Freeze inert validation bytes; this is not a deployable production release."""
import json, zipfile
from pathlib import Path
from padml import f4
from padml.bundle import canonical_json_bytes as enc, sha256_bytes as sha, sha256_file, write_deterministic_zip

repo = Path(__file__).resolve().parents[2]
checks = Path(__file__).parent
previous = repo / 'execution/release-optimism/PADML_F45_REBUILD_20261001_OPTIMISM.zip'
assert sha256_file(previous) == '8070b90e5c1d8646545c24a131e26dfe8433ccb9b9ec38808c5cc04e4f9cb49a'
identity = sha(enc(f4._f45_source_member_sha256()))
assert json.loads((checks/'qualification.json').read_bytes())['source_identity'] == identity
out = checks / ('candidate-' + identity[:12]); out.mkdir(exist_ok=True)
if (out / 'source.zip').exists():
    manifest = f4.load_f45_source_bundle(out / 'source.zip')
    compiled = {'sha256': sha256_file(out / 'source.zip')}
else:
    compiled = f4.compile_f45_source_bundle(out / 'source.zip')
with zipfile.ZipFile(previous) as source:
    members = {name: source.read(name) for name in source.namelist()
        if name in ('source.zip', 'run.json') or name.endswith(('/source.zip', '/run.json'))}
prefix = 'evaluation-io-predecessor'
members[prefix+'/source.zip'], members[prefix+'/run.json'] = members['source.zip'], members['run.json']
old = json.loads(members['run.json'])
retained_pins = []
for retained_prefix, filename, run_sha, source_sha in (
    ('evaluation-io-capsule-predecessor', 'candidate-f15c41c4c22c/VALIDATION_ONLY.zip',
     '706521641add77e6d3694d655dec426527296d51e231d8b9c9afecbed316ea6d',
     '99900b0318a30b2ad74351e12f9f481c9fa2718dff595a17f446a4e1fd3fc8e4'),
    ('evaluation-io-point-predecessor', 'candidate-4ef01be829e3/VALIDATION_ONLY-2e2d76cf018e.zip',
     '4491fb135b2890869d637982fdb97e02ee51947a14f99ebae21597ff4bc1c19b',
     '9f224af0b6f9d62e4f47a5cd96dc0dbda738496726db76d96265bf31d7ae49bd'),
        ('evaluation-io-coordinate-predecessor', 'candidate-a82cb4d2b8df/VALIDATION_ONLY-0262c3dfb273.zip',
         '4cf9bacdbaa22b31a03496ab2ddc8d913664fae94b056e69edda480c3025dd2d',
         '51cf2eb78ef68bdcee808587cfa9b0e87ac587e9851ab21784fb410be02c6155')):
    with zipfile.ZipFile(checks / filename) as retained:
        for name, expected in (('run.json', run_sha), ('source.zip', source_sha)):
            raw = retained.read(name)
            assert sha(raw) == expected
            members[retained_prefix+'/'+name] = raw
    retained_pins.append({'run_path': old['run_root']+'/'+retained_prefix+'/run.json',
        'run_sha256': sha(members[retained_prefix+'/run.json']),
        'source_path': old['run_root']+'/'+retained_prefix+'/source.zip',
        'source_sha256': sha(members[retained_prefix+'/source.zip'])})
run = {**old, 'source_identity': identity, 'source_bundle_sha256': compiled['sha256'],
        'budgets': {**old['budgets'], 'retained_bytes_per_replicate': 16 * 1024**2},
    'unit_source_predecessors': [*old.get('unit_source_predecessors', []), *retained_pins],
    'unit_predecessor': {'run_path': old['run_root']+'/'+prefix+'/run.json', 'run_sha256': sha(members[prefix+'/run.json']),
        'source_path': old['run_root']+'/'+prefix+'/source.zip', 'source_sha256': sha(members[prefix+'/source.zip'])}}
run['identity'] = sha(enc({k:v for k,v in run.items() if k!='identity'}))
members['run.json'] = enc(run)
members['source.zip'] = (out/'source.zip').read_bytes()
members['linux-check.py'] = (checks/'linux-check.py').read_bytes()
members['validation-candidate.json'] = enc({'source_identity': identity, 'run_identity': run['identity'],
    'source_bundle_sha256': compiled['sha256'], 'formal_release': False, 'official_b1000_authorized': False})
target = out / ('VALIDATION_ONLY-' + sha(members['linux-check.py'])[:12] + '.zip')
write_deterministic_zip(target, members)
record = {'path': str(target), 'sha256': sha256_file(target), 'size_bytes': target.stat().st_size,
    'source_identity': identity, 'run_identity': run['identity'], 'script_sha256': sha(members['linux-check.py']),
    'formal_release': False}
(checks/'validation-candidate.json').write_bytes(enc(record))
print(json.dumps(record))
