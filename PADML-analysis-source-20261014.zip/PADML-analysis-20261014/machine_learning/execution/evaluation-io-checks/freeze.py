"""Freeze the single compact-evaluation release after two real Linux checks."""
import ast, io, json, os, subprocess, sys, zipfile
from pathlib import Path
from padml import f4
from padml.bundle import canonical_json_bytes as enc, sha256_bytes as sha, sha256_file, write_deterministic_zip

assert sys.version_info[:2] == (3, 12)
repo = Path(__file__).resolve().parents[2]
base, checks = repo / 'execution', Path(__file__).parent
previous = base / 'release-optimism/PADML_F45_REBUILD_20261001_OPTIMISM.zip'
assert sha256_file(previous) == '8070b90e5c1d8646545c24a131e26dfe8433ccb9b9ec38808c5cc04e4f9cb49a'
pins = f4._f45_source_member_sha256()
identity = sha(enc(pins))
qualification = json.loads((checks / 'qualification.json').read_bytes())
focused = json.loads((checks / 'focused-checks.json').read_bytes())
candidate = json.loads((checks / 'validation-candidate.json').read_bytes())
assert qualification['source_identity'] == focused['source_identity'] == candidate['source_identity'] == identity
assert len(qualification['checks']['predecessors']) == 28
assert focused['status'] == 'PASS' and focused['current_source_pins'] == pins
assert all(row['returncode'] == 0 and sha256_file(checks / row['script']) == row['sha256']
           for row in focused['focused_scripts'])
assert candidate['script_sha256'] == sha256_file(checks / 'linux-check.py')
linux = {}
for host, horizon in (('H4', 6), ('H9', 12)):
    path = checks / 'linux-validation' / host / 'validation.json'
    result = json.loads(path.read_bytes())
    assert result['source_identity'] == identity and result['status'] == 'PASS'
    assert result['run_identity'] == candidate['run_identity']
    assert result['validation_script_sha256'] == candidate['script_sha256']
    assert result['unit_id'] == f'EVALUATION-H{horizon:02d}' and result['replicate_ids'] == list(range(1, 9))
    assert not result['formal_scientific_completion']
    assert result['new_prediction_model_fits'] == result['new_mice_selector_search_calls'] == 0
    assert result['original_sources_unchanged'] and result['original_live_run_unchanged']
    assert result['existing_plan_rng_point_unchanged'] and result['preexisting_coordinate_bytes_unchanged']
    assert result['point_reservation']['point_retention_reserved_bytes'] > 0
    assert result['completed_coordinates_unchanged_on_resume'] and result['preparation_resume_full_source_calls'] == 0
    assert result['original_and_joint_arithmetic_byte_equal'] and result['arithmetic_comparisons'] == 252
    linux[host] = {'validation_sha256': sha256_file(path), 'result': result}
# The sole executor already returned the original process/group observations.
# Bind these directly instead of requiring another separately formatted receipt.
closure = {'status': 'PASS', 'source_identity': identity, 'hosts': {}}
for host, physical in (('H4', 'H4-5'), ('H9', 'H9-3')):
    proof = checks / 'linux-validation' / physical / ('pilot-latest-observation-' + identity[:12] + '.json')
    record = json.loads(proof.read_bytes())
    actor = record['actor']
    assert actor['candidate_source_identity'] == identity and actor['candidate_run_identity'] == candidate['run_identity']
    assert actor['old_owner_groups_exited'] and actor['pgid'] in record['registered_groups']
    assert record['owner'] is None and record['group_members'] == []
    assert record['validation']['sha256'] == linux[host]['validation_sha256']
    assert record['validation']['result'] == linux[host]['result']
    closure['hosts'][host] = {'validation_sha256': linux[host]['validation_sha256'],
        'all_registered_groups_exited': True, 'old_owner_groups_exited': True,
        'group_exit_proof': str(proof), 'group_exit_proof_sha256': sha256_file(proof),
        'observed_at_utc': record['time_utc']}
review = json.loads((checks / 'reviewed-source-ast.json').read_bytes())
for name, definitions in review['function_revisions'].items():
    observed = {n.name: sha(ast.dump(n, include_attributes=False).encode()) for n in ast.parse((repo/name).read_bytes()).body
        if isinstance(n, (ast.FunctionDef, ast.ClassDef))}
    assert all(observed[n] == revisions[-1] for n, revisions in definitions.items())
for name, revisions in review['raw_revisions'].items():
    assert sha256_file(repo / name) == revisions[-1]
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
assert not subprocess.check_output(['git', 'diff', '--name-only', 'HEAD', '--', *f4.F45_SOURCE_MEMBERS], cwd=repo)
for name in f4.F45_SOURCE_MEMBERS:
    assert subprocess.check_output(['git', 'show', head+':'+name], cwd=repo) == (repo/name).read_bytes()
observer = 'execution/heartbeat-current-owner-observer-template.py'
assert subprocess.check_output(['git', 'show', head+':'+observer], cwd=repo) == (repo/observer).read_bytes()
with zipfile.ZipFile(previous) as archive:
    members = {n: archive.read(n) for n in archive.namelist() if n != 'release.json'}
    with zipfile.ZipFile(io.BytesIO(members['source.zip'])) as old_source:
        changed = [n for n in f4.F45_SOURCE_MEMBERS if old_source.read(n) != (repo/n).read_bytes()]
out = base / 'release-evaluation-io'
out.mkdir()
compiled = f4.compile_f45_source_bundle(out / 'source.zip')
prefix = 'evaluation-io-predecessor'
members[prefix+'/run.json'], members[prefix+'/source.zip'] = members['run.json'], members['source.zip']
old = json.loads(members['run.json'])
with zipfile.ZipFile(candidate['path']) as archive:
    assert sha256_file(Path(candidate['path'])) == candidate['sha256']
    for name in ('evaluation-io-capsule-predecessor/run.json', 'evaluation-io-capsule-predecessor/source.zip',
                 'evaluation-io-point-predecessor/run.json', 'evaluation-io-point-predecessor/source.zip',
                 'evaluation-io-coordinate-predecessor/run.json', 'evaluation-io-coordinate-predecessor/source.zip'):
        members[name] = archive.read(name)
    run = json.loads(archive.read('run.json'))
assert run['identity'] == sha(enc({k:v for k,v in run.items() if k != 'identity'}))
assert run['source_identity'] == identity and run['source_bundle_sha256'] == compiled['sha256']
assert run['unit_predecessor'] == {'run_path': old['run_root']+'/'+prefix+'/run.json',
    'run_sha256': sha(members[prefix+'/run.json']), 'source_path': old['run_root']+'/'+prefix+'/source.zip',
    'source_sha256': sha(members[prefix+'/source.zip'])}
assert run['identity'] == candidate['run_identity']
assert run['units'] == old['units'] and run['science_decision'] == old['science_decision']
members.update({'run.json': enc(run), 'source.zip': (out/'source.zip').read_bytes(), 'source.compile.json': enc(compiled)})
for name in ('AGENTS.md', 'NESTED_LOCO_PROTOCOL.md'):
    members[name] = (repo / name).read_bytes()
# Keep the changed-path checks and final readback, not duplicate operational
# snapshots, remote command dumps, candidate trees, or obsolete drivers.
evidence_paths = list(checks.iterdir())
for folder in ('runtime', 'recovery'):
    evidence_paths.extend((checks / folder).rglob('*'))
for host in linux:
    evidence_paths.append(checks / 'linux-validation' / host / 'validation.json')
    for name in ('exact-storage-guard-inputs.json', 'storage-guard-existing-stage-inventory.json',
                 'coordinate-files-unqualified-inventory-a82cb4d2b8df.json',
                 'first-written-coordinate-native-leaf-inventory-a82cb4d2b8df.json'):
        evidence_paths.append(checks / 'linux-validation' / host / name)
    proof = closure['hosts'][host].get('group_exit_proof')
    if proof:
        path = Path(proof).resolve(strict=True)
        assert path.is_relative_to(checks)
        evidence_paths.append(path)
evidence = {str(p.relative_to(checks)): p for p in evidence_paths if p.is_file()
    and '__pycache__' not in p.parts and 'tool-result' not in p.name
    and p.suffix in {'.py', '.json', '.txt', '.log', '.md', '.stdout', '.stderr'}
    and p.stat().st_size <= 8 * 1024**2}
write_deterministic_zip(out / 'evaluation-io-checks.zip', evidence)
members['evaluation-io-checks.zip'] = (out / 'evaluation-io-checks.zip').read_bytes()
members['HISTORICAL_OPTIMISM_COMPILE.md'] = members['COMPILE_REPORT.md']
report = (f'Frozen Git: {head}. Source: {identity}. Run: {run["identity"]}.\n\n' +
          (base / 'EVALUATION_IO_COMPILE.md').read_text()).encode()
members['README.md'] = members['COMPILE_REPORT.md'] = report
members['EXECUTION_HANDOFF.md'] = (base / 'EVALUATION_IO_HANDOFF.md').read_bytes()
members['heartbeat-current-owner-observer-template.py'] = (base / 'heartbeat-current-owner-observer-template.py').read_bytes()
summary = {'head': head, 'source_identity': identity, 'run_identity': run['identity'], 'source': compiled,
    'changed_source_members': changed, 'source_member_count': len(f4.F45_SOURCE_MEMBERS),
    'observer_template_sha256': sha256_file(repo / observer),
    'units': 56, 'optimism_contexts': 28, 'predecessors': 28, 'science_decision_unchanged': True,
    'new_prediction_model_fits': 0, 'linux_validation': {k: v['validation_sha256'] for k, v in linux.items()},
    'linux_validation_exit_proofs': closure['hosts'],
    'previous_package_sha256': sha256_file(previous), 'deployed': False, 'formal_scientific_completion': False}
members['compile-summary.json'] = enc(summary)
with zipfile.ZipFile(previous) as archive:
    for name in archive.namelist():
        if name in {'science-decision.json', 'dependencies.json', 'shared/bootstrap.zip', 'shared/bootstrap-preparation.json'} \
            or name.endswith(('/run.json', '/source.zip', '-checks.zip')):
            assert members[name] == archive.read(name)
members['release.json'] = enc({'kind': 'PADML_F45_COMPACT_EVALUATION_RELEASE', 'head': head,
    'source_identity': identity, 'run_identity': run['identity'],
    'members': {name: {'sha256': sha(raw), 'size_bytes': len(raw)} for name, raw in members.items()}})
target = out / 'PADML_F45_REBUILD_20261002_EVALUATION_IO.zip'
write_deterministic_zip(target, members)
reader = subprocess.check_output([sys.executable, '-B', str(checks/'frozen-reader.py'), str(target)], cwd=repo,
    env={**os.environ, 'PYTHONPATH': str(repo), 'PYTHONDONTWRITEBYTECODE': '1'}, text=True)
(out / 'frozen-reader.log').write_text(reader)
summary.update(package=str(target), sha256=sha256_file(target), size_bytes=target.stat().st_size)
(out / 'compile-summary.json').write_bytes(enc(summary))
print(json.dumps(summary))
