"""Synthetic-only focused consumer checks; no clinical numerical work."""
import copy, io, json, struct, zipfile
from pathlib import Path
from padml import f4, f5_sensitivity as a, nested_loco as n
from padml.bundle import canonical_json_bytes as raw, sha256_bytes, ContractError
from padml.f2_kernel import _pool_prediction_batch, _seal_prediction_matrix
from test_nested_loco import _context,_scores,_lock,_receipts
consume=a._f45_evaluation_numbers
pin=lambda b:{'sha256':sha256_bytes(b),'size_bytes':len(b)}
def zipped(members):
 o=io.BytesIO()
 with zipfile.ZipFile(o,'w',compression=zipfile.ZIP_STORED) as z:
  for k,v in members.items():z.writestr(k,v)
 return o.getvalue()
ctx=_context();lock,_=_lock(ctx,_scores(ctx));h=lock['selection_horizon_months'];family=lock['selected_family']
run='1'*64;source=ctx['modeling_program_sha256'];authorities=({run:source},{source:{}})
def receipt(kind):return {'unit_id':f'{kind}-H{h:02d}-O1','status':'COMPLETED','direct_consumer_completed':True,'selection_horizon_months':h,'report_horizons_months':[6,12,24,36],'run_identity':run,'artifacts':{'input.zip':pin(b'UNFITTED-input'),'result.zip':pin(b'UNFITTED-result')}}
def manifest(kind,r):return {'kind':'PADML_F45_EVALUATION_SOURCE_V1','source_kind':kind,'unit_id':r['unit_id'],'horizon':h,'outer_fold':1,'source_receipt':r,'source_receipt_sha256':sha256_bytes(raw(r))}
request=n._sealed({'kind':'PADML_F4_O_FIT_INPUT_V1','training_context':ctx,'selection_horizon_months':h,'science_decision':n.science_decision_template(h)})
components=[]
for i,r in enumerate(_receipts(lock),1):
 coords={'purpose':'NESTED_OUTER','outer_fold':1,'repeat':0,'inner_fold':0,'imputation':i}
 prediction={'f4_coordinates':coords,'patient_ids':ctx['heldout_ids'],'centers':['36']*2,'horizons':list(range(37)),'survival':{family:[[1.]+[.9-i/1000]*36 for _ in range(2)]}}
 health={'UNFITTED':True};r={k:v for k,v in r.items() if k!='identity_sha256'}
 r.update(training_response_sha256=ctx['training_response_sha256'],prediction_sha256=n._sha(prediction),fit_health_sha256=n._sha(health),seed=f4._f4_model_seed(family,coords))
 components.append({'receipt':n._sealed(r),'prediction':prediction,'fit_health':health,'object_audit':{'UNFITTED':True},'native_archive':{'member':f'fits/M{i:02d}.zip',**pin(f'UNFITTED-{i}'.encode())}})
def primary_entries(values):
 pooled=_pool_prediction_batch([{'sealed_prediction':_seal_prediction_matrix(ctx['heldout_ids'],c['prediction']['survival'][family],list(range(37)))} for c in values],list(range(37)))['payload']['survival']
 mean=b''.join(struct.pack('<37d',*row) for row in pooled)
 selected=n.seal_selected_prediction(lock=lock,patient_ids=ctx['heldout_ids'],centers=['36']*2,survival=pooled,component_receipts=[v['receipt'] for v in values])
 final=n._sealed({'kind':'PADML_F4_O_FIT_FINAL_NUMBERS_V1','input_identity_sha256':request['identity_sha256'],'development_lock_sha256':lock['identity_sha256'],'components':values,'mean':{'encoding':'IEEE754_FLOAT64_LE_ROW_MAJOR','patient_ids':ctx['heldout_ids'],'centers':['36']*2,'horizons':list(range(37)),'imputation_count':20,**pin(mean)}})
 final_raw=zipped({'final.json':raw(final),'heldout-mean.f64':mean});r=receipt('PRIMARY')
 header=n._sealed({'kind':'PADML_F4_O_FIT_EXECUTION_ARCHIVE_V3','outer_fold':1,'family':family,'development_lock':lock,'input_identity_sha256':request['identity_sha256'],'input_archive':r['artifacts']['input.zip'],'science_decision_sha256':request['science_decision']['identity_sha256'],'native_members':{v['native_archive']['member']:{k:v['native_archive'][k] for k in ('sha256','size_bytes')} for v in values},'members':{'final-numbers.zip':pin(final_raw)},'component_receipts':[v['receipt'] for v in values],'selected_prediction':selected})
 return {'source-unit.json':raw(r),'o-fit-input.json':raw(request),'o-fit-execution.json':raw(header),'final-numbers.zip':final_raw},manifest('PRIMARY',r)
entries,m=primary_entries(components)
assert consume(entries,m,authorities)['selected_prediction']['patient_ids']==ctx['heldout_ids']
checks=['synthetic_primary_positive']
for damage in ('bad_mean','missing_component','wrong_member_pin'):
 e=copy.deepcopy(entries)
 if damage=='wrong_member_pin':
  head=json.loads(e['o-fit-execution.json']);head['members']['final-numbers.zip']['sha256']='0'*64;head=n._sealed({k:v for k,v in head.items() if k!='identity_sha256'});e['o-fit-execution.json']=raw(head)
 else:
  with zipfile.ZipFile(io.BytesIO(e['final-numbers.zip'])) as z: f=json.loads(z.read('final.json'));b=z.read('heldout-mean.f64')
  if damage=='bad_mean':b=b[:-8]+struct.pack('<d',.5)
  else:f['components']=f['components'][:-1]
  f=n._sealed({k:v for k,v in f.items() if k!='identity_sha256'});e['final-numbers.zip']=zipped({'final.json':raw(f),'heldout-mean.f64':b})
  head=json.loads(e['o-fit-execution.json']);head['members']['final-numbers.zip']=pin(e['final-numbers.zip']);e['o-fit-execution.json']=raw(n._sealed({k:v for k,v in head.items() if k!='identity_sha256'}))
 try:consume(e,m,authorities)
 except ContractError:checks.append('rejected_'+damage)
 else:raise AssertionError(damage)
r=receipt('AAR');m=manifest('AAR',r)
source_header=n._sealed({'kind':'PADML_F5_A12_PROJECTED_OUTER_INPUTS_V1','outer_fold':1,'family':family,'primary_source':{'program_id':n.PROGRAM_ID,'primary_training_context':ctx,'primary_development_lock':lock,'science_decision':n.science_decision_template(h)}})
aentries={'source-unit.json':raw(r),'inputs-index.json':raw(n._sealed({'kind':'PADML_F5_A12_OUTER_INPUTS_NATIVE_V2','outer_fold':1,'family':family,'projected_input_identity_sha256':source_header['identity_sha256'],'stage':'MICE_MATERIALIZED_PRE_DEVELOPMENT','mice_views':{}})),'development/selector/development-input.json':raw({'UNFITTED':True})}
natives={};survival={};first=None
for branch in n.AAR_ESTIMANDS:
 matrices=[]
 for i in range(1,21):
  name=f'O1_{branch}_M{i:02d}';coords={'outer_fold':1,'branch':branch,'imputation':i}
  def pred(ids):return {'a12_coordinates':coords,'family':family,'patient_ids':ids,'centers':[ctx['centers_by_patient'][p] for p in ids],'horizons':list(range(37)),'survival':[[1.]+[.9-i/1000]*36 for _ in ids]}
  p=pred(ctx['heldout_ids']);matrices.append({'sealed_prediction':_seal_prediction_matrix(ctx['heldout_ids'],p['survival'],list(range(37)))})
  ip={key:pin(('UNFITTED-'+key).encode()) for key in ('task.json','recipe.json','fit-covariates.csv','fit-response.csv','prediction-covariates.csv')};ip['fit-response.csv']={'sha256':ctx['training_response_sha256'],'size_bytes':ctx['training_response_size_bytes']}
  v={'input_members':ip,'prediction':p,'training_prediction':pred(ctx['training_ids']),'fit_health':{'UNFITTED':True},'object_audit':{'UNFITTED':True},'model_sha256':'2'*64,'baseline_sha256':'3'*64,'native_archive':pin(name.encode()),'native_expanded_bytes':100}
  key=f'fits/{name}.numbers.json';aentries[key]=raw(v);first=first or key;natives[f'fits/{name}.zip']=v['native_archive']
 survival[branch]=_pool_prediction_batch(matrices,list(range(37)))['payload']['survival']
header=n._sealed({'kind':'PADML_F5_A12_OUTER_NATIVE_V2','outer_fold':1,'family':family,'source':source_header,'predictions':{'patient_ids':ctx['heldout_ids'],'centers':['36']*2,'horizons':list(range(37)),'survival':survival},'members':{k:pin(v) for k,v in aentries.items() if k not in {'source-unit.json','inputs-index.json'}},'native_members':natives})
aentries['a12-outer.json']=raw(header)
assert consume(aentries,m,authorities)['selected_prediction']==header['predictions'];checks.append('synthetic_aar_positive')
for damage in ('training_order','bool_imputation'):
 e=copy.deepcopy(aentries);v=json.loads(e[first])
 if damage=='training_order':v['training_prediction']['patient_ids'].reverse()
 else:v['prediction']['a12_coordinates']['imputation']=True
 e[first]=raw(v);head=json.loads(e['a12-outer.json']);head['members'][first]=pin(e[first]);e['a12-outer.json']=raw(n._sealed({k:v for k,v in head.items() if k!='identity_sha256'}))
 try:consume(e,m,authorities)
 except ContractError:checks.append('rejected_'+damage)
 else:raise AssertionError(damage)

# Compact ledger only: no numeric source qualification claimed here.
import tempfile
from padml.bundle import write_deterministic_zip
science=n.science_decision_template(24)
accounting=[]
with tempfile.TemporaryDirectory(prefix='f45-eval-counts-',dir='/private/tmp') as temporary:
 for shared in (0,19,60):
  path=Path(temporary)/f'counts-{shared}.zip'
  members={'development/selector/development-input.json':raw({'selector_path_count':640,'glmnet_call_count':1280})}
  for j,(branch,imp) in enumerate((b,i) for b in n.AAR_ESTIMANDS for i in range(1,21)):
   members[f'fits/O1_{branch}_M{imp:02d}.numbers.json']=raw({'UNFITTED':True,**({'reused_final':{'UNFITTED_COUNTER_ONLY':True}} if j<shared else {})})
  write_deterministic_zip(path,members)
  record=a._a12_outer_archive_record({'family':'COX_PH','outer_fold':1,'identity_sha256':'a'*64,
      'source':{'kind':'PADML_F5_A12_PROJECTED_OUTER_INPUTS_V1','mice_inputs':[{}]*34,'primary_source':{'science_decision':science}},
      'members':{k:pin(v) for k,v in members.items()}},path,source_pin=pin(b'UNFITTED_ORIGINAL_ARCHIVE'),mice_index={})
  assert record['execution_ledger']['post_lock_fits']==60-shared
  records=[{**copy.deepcopy(record),'outer_fold':outer} for outer in range(1,7)]
  families={str(outer):'COX_PH' for outer in range(1,7)}
  context={'primary':{'kind':'PADML_NESTED_LOCO_SELECTED_POLICY_OOC_V1','identity_sha256':'c'*64},'family_by_outer':families,'science_decision':science,'source':{'UNFITTED':True},'compact_evaluation':True}
  numeric={'family_by_outer':families,'science_decision_sha256':science['identity_sha256'],'primary_ooc_sha256':'c'*64,'bootstrap':{'replicate_count':1000,'paired_row_count':24,'metrics':{'macro':[0],'scope':[0]}}}
  result=a._a12_native_summary(context,numeric,records)
  assert result['post_lock_model_fit_execution_count']==6*(60-shared)
  assert result['post_lock_logical_fit_count']==360
  assert result['post_lock_reused_fit_count']==6*shared
  assert result['evaluation_new_model_fit_count']==0
  accounting.append({'shared_per_outer':shared,'logical':360,'physical':6*(60-shared),'reused':6*shared})
  checks.append(f'logical_physical_reused_ledger_{shared}_of_60')
# Retained real source: schema inspection only, no pooling/metrics/native calls.
realroot=Path('execution/optimism-checks/linux-validation/input-staging/units/PRIMARY-H06-O2')
with zipfile.ZipFile(realroot/'result.zip') as archive:
 head=json.loads(archive.read('o-fit-execution.json'))
 with zipfile.ZipFile(io.BytesIO(archive.read('final-numbers.zip'))) as numbers:
  body=json.loads(numbers.read('final.json'))
  assert len(body['components'])==20
  for imp,v in enumerate(body['components'],1):
   assert set(v)=={'fit_health','native_archive','object_audit','prediction','receipt'}
   assert set(v['prediction'])=={'centers','f4_coordinates','horizons','patient_ids','survival'}
   assert v['native_archive']=={'member':f'fits/M{imp:02d}.zip',**head['native_members'][f'fits/M{imp:02d}.zip']}
   assert v['prediction']['f4_coordinates']=={'imputation':imp,'inner_fold':0,'outer_fold':2,'purpose':'NESTED_OUTER','repeat':0}
real_schema={'unit':'PRIMARY-H06-O2','header_kind':head['kind'],'component_count':20,'component_keys':sorted(body['components'][0]),'numeric_consumer_called':False,'metadata_only':True}
checks.append('real_PRIMARY_H06_O2_schema_only')
print(json.dumps({'status':'PASS','consumer':'padml.f5_sensitivity._f45_evaluation_numbers','checks':checks,'accounting':accounting,'real_schema':real_schema,'synthetic_numerical_checks_only':True,'clinical_numbers_executed':False,'model_reads':0,'model_fits':0}))
