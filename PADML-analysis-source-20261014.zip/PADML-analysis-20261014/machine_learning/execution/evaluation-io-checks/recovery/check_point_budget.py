"""Actual A12 producer/replay budget paths; science/native engine functions are spied."""
import copy,json,tempfile
from contextlib import ExitStack,nullcontext
from pathlib import Path
from unittest.mock import patch
from fixtures import six_outers,digest
from padml import f4,f5,f5_sensitivity as a,runtime
from padml.bundle import canonical_json_bytes as enc,sha256_bytes as sha,ContractError

ctx,outers=six_outers(12)
predictions=a._a12_handoff_from_outers(ctx,outers)
handoff=a._validate_a12_handoff(predictions)
fixed={k:handoff[k] for k in ('patient_ids','centers','horizons','survival')}
fixed.update(a._a12_evaluation_scope(handoff))
response=ctx['evaluation_response_csv']; retained=8*1024**2
policy={'configured_worker_ceiling':runtime.CPU_MINUS_8,'memory_bytes_per_worker':2*1024**3,
 'scratch_bytes_per_worker':1,'memory_reserve_bytes':0,'scratch_reserve_bytes':0,
 'transfer_archive_worker_ceiling':1000}
plan={'domain':'FIXED_MODEL_PAIRED','root_seed':700000001,'replicate_count':1000,
 'rng':["L'Ecuyer-CMRG",'Inversion','Rejection'],'r_version':'UNFITTED',
 'patient_key_rule':f4.PATIENT_KEY_RULE,'source_sha256':sha(enc({'patient_ids':handoff['patient_ids'],
 'centers':handoff['centers'],'patient_keys':[handoff['patient_keys'][i] for i in handoff['patient_ids']]})),
 'draws':[list(range(len(handoff['patient_ids']))) for i in range(1000)]}
source=a._a12_bootstrap_binding(fixed,response,plan)
oldsource={**source,'producer_sha256':digest('original_4ef_generation')}
source_members=f4._f45_source_member_sha256(); source_id=sha(enc(source_members))
old_members={**source_members,'padml/f5_sensitivity.py':oldsource['producer_sha256']}
authorities=({'currentrun':source_id},{source_id:source_members,'oldqualified':old_members})
primary={'UNFITTED_PRIMARY':'p'*300000}; aar={'UNFITTED_AAR':'a'*600000}; merged={'UNFITTED_MERGED':'m'*900000}
primary_native=b'UNFITTED_NATIVE_'+b'P'*(1024**2)
aarnative=b'UNFITTED_NATIVE_'+b'A'*(2*1024**2)
checks=[]; engine_replays=[]

with tempfile.TemporaryDirectory(prefix='point-budget-route-',dir='/tmp') as tmp:
 base=Path(tmp).resolve(); root=base/'evaluation'; root.mkdir()
 data={'plan.json':enc({'source':oldsource,'plan':plan}),'rng.zip':b'ORIGINAL_UNFITTED_RNG',
 'primary-point-evaluation.json':enc(primary),'primary-point-native.zip':primary_native,
 'aar-point-evaluation.json':enc(aar),'point-evaluation.json':enc(merged),'point-native.zip':aarnative}
 for name,raw in data.items():(root/name).write_bytes(raw)
 (root/'execution.json').write_bytes(enc({'old_failed_attempt':True}))
 def pins():return {name:(sha((root/name).read_bytes()),(root/name).stat().st_mtime_ns) for name in data}
 before=pins()
 point_reserved=3*sum((root/name).stat().st_size for name in a._A12_NESTED_POINT_MEMBERS)+16384
 assert point_reserved>retained
 disk={'free':point_reserved-1}
 def observe(where):return {'effective_cpus':16,'available_memory_bytes':10**12,
   'scratch_available_bytes':disk['free'],'scratch_root':str(where)}
 def fake_draws(*args,**kwargs):
  assert kwargs['replay_archive']==root/'rng.zip';return copy.deepcopy(plan)
 def fake_evaluate(*args,**kwargs):
  assert kwargs['replay_native_archive']==root/'point-native.zip'
  assert (root/'point-native.zip').read_bytes()==aarnative
  engine_replays.append('READ_EXISTING_NATIVE');return copy.deepcopy(aar)
 def fake_pool(worker,items,*,selected_slots,execution_report):
  assert len(items)==1000 and selected_slots==8
  execution_report.update(status='COMPLETED',engine_threads=1,configured_worker_ceiling=8,
    admitted_worker_ceiling=8,completed_task_count=1000,runnable_task_count=1000,actual_worker_process_peak=8)
  for i,_ in items:(root/f'replicate-{i:04d}.zip').write_bytes(b'UNFITTED_COORDINATE')
  return [{'replicate':i} for i,_ in items]
 def call(*,prepare):
  kwargs=({'bootstrap_input_target':base/f'inputs-{len(engine_replays)}.zip',
    'point_archive_target':base/f'points-{len(engine_replays)}.zip'} if prepare else {})
  return a.evaluate_a12_incremental_value(predictions,response,formal=True,evidence_root=root,
    resource_policy=policy,retained_bytes_per_replicate=retained,retained_primary_point=primary,
    primary_point_native=primary_native,**kwargs)
 with ExitStack() as stack:
  stack.enter_context(patch.object(runtime,'observe_execution_resources',observe))
  stack.enter_context(patch.object(f5,'_full_score_scratch',lambda root:nullcontext()))
  stack.enter_context(patch.object(f5,'_f45_score_reuse_authorities',lambda:authorities))
  stack.enter_context(patch.object(a,'bootstrap_draws',fake_draws))
  stack.enter_context(patch.object(a,'_a12_primary_point_origin',lambda *args,**kw:primary))
  stack.enter_context(patch.object(a,'evaluate_predictions',fake_evaluate))
  stack.enter_context(patch.object(a,'_validate_a12_native_evaluation',lambda *args,**kw:None))
  stack.enter_context(patch.object(a,'_merge_a12_point_evaluations',lambda *args:copy.deepcopy(merged)))
  stack.enter_context(patch.object(a,'_bounded_ordered_spawn',fake_pool))
  stack.enter_context(patch.object(a,'_reduce_a12_incremental_value',lambda *args,**kw:{'UNFITTED_REDUCTION':True}))
  try:call(prepare=True)
  except ContractError as exc:assert str(exc)=='F5_A12_BOOTSTRAP_PACKAGING_SPACE_INSUFFICIENT'
  else:raise AssertionError('insufficient point space accepted')
  failed=json.loads((root/'execution.json').read_bytes())
  assert failed['resource_reservation']['point_retention_reserved_bytes']==point_reserved
  assert failed['bootstrap_pool']=={} and pins()==before
  checks.append('failed_space_guard_records_attempt_without_mutating_seven_scientific_files')
  disk['free']=10**12
  prepared=call(prepare=True)
  prep=json.loads((root/'execution.json').read_bytes())
  assert prepared['bootstrap_replicates_executed']==0 and pins()==before
  assert prep['resource_reservation']['metric_retention_reserved_bytes']==point_reserved
  assert prep['resource_reservation']['point_retention_reserved_bytes']==point_reserved
  assert prep['resource_reservation']['retained_bytes_per_replicate']==retained
  checks.append('failed_attempt_reentered_prepare_point_above_8MiB_accepted_seven_files_unchanged')
  produced=call(prepare=False)
  formal=json.loads((root/'execution.json').read_bytes())
  assert formal['resource_reservation']['metric_retention_reserved_bytes']==1000*retained+point_reserved
  assert formal['bootstrap_pool']['completed_task_count']==1000 and pins()==before
  assert json.loads((root/'plan.json').read_bytes())['source']==oldsource
  checks.append('formal_reentry_preserves_old_plan_producer_and_updates_complete_pool_record')
  stack.enter_context(patch.object(a,'_replay_a12_point',lambda *args,**kw:copy.deepcopy(merged)))
  stack.enter_context(patch.object(a,'_replay_a12_bootstrap_replicate',lambda item,**kw:{'replicate':item[0]}))
  read=a._replay_a12_evaluation(root,predictions,response)
  assert read==produced
  checks.append('actual_new_reservation_direct_reader_matches_actual_producer')
  damaged=copy.deepcopy(formal);damaged['resource_reservation']['point_retention_reserved_bytes']+=1
  (root/'execution.json').write_bytes(enc(damaged))
  try:a._replay_a12_evaluation(root,predictions,response)
  except ContractError as exc:assert str(exc)=='F5_A12_BOOTSTRAP_EXECUTION_INVALID'
  else:raise AssertionError('wrong point budget accepted')
  checks.append('one_byte_point_reservation_drift_rejected')
  # Old complete format is still accepted when it satisfies its original point ceiling.
  for name in a._A12_NESTED_POINT_MEMBERS:(root/name).write_bytes(b'{}\n' if name.endswith('.json') else b'OLD_NATIVE')
  legacy=copy.deepcopy(formal);reservation=legacy['resource_reservation']
  reservation.pop('point_retention_reserved_bytes');legacy.pop('point_storage_observation')
  reservation['metric_retention_reserved_bytes']=1001*retained
  primary_size=sum((root/n).stat().st_size for n in ('primary-point-evaluation.json','primary-point-native.zip'))
  reservation['coordinator_memory_estimate_bytes']=32*(len(enc(fixed))+16*1000*len(handoff['patient_ids'])+primary_size)+128*1000*((2*4-1)*((12*len(a.REPORT_HORIZONS)+2)+7*(10*len(a.REPORT_HORIZONS)+2)))
  legacy['effective_policy']['memory_reserve_bytes']=policy['memory_reserve_bytes']+reservation['coordinator_memory_estimate_bytes']
  legacy['resource_admission']=runtime.resource_admission(legacy['effective_policy'],legacy['resource_observation'],legal_tasks=1000)
  (root/'execution.json').write_bytes(enc(legacy))
  oldread=a._replay_a12_evaluation(root,predictions,response)
  assert oldread['evaluation_execution']==legacy
  checks.append('old_complete_reservation_reader_keeps_original_record')
 print(json.dumps({'status':'PASS','checks':checks,'source_identity_at_start':source_id,
   'point_retention_reserved_bytes':point_reserved,'coordinate_retained_bytes':retained,
   'native_replay_route_calls':len(engine_replays),'model_fits':0,'R_calls':0,
   'scope':'ACTUAL_PRODUCER_AND_DIRECT_READER_BUDGET_ROUTES_WITH_SCIENCE_AND_POOL_SPIED',
   'scientific_completion':False}))
