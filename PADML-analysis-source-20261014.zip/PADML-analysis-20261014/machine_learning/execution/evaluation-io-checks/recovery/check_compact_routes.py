"""No science engines: exercise actual prepare/load/package/replay wiring."""
import copy,json,shutil,tempfile,zipfile
from pathlib import Path
from unittest.mock import patch
from contextlib import ExitStack
import check_context_integrated as f
from fixtures import digest,ledger_case
from padml import f5_sensitivity as a, f5, nested_loco as n, runtime
from padml.bundle import canonical_json_bytes,write_deterministic_zip,ContractError

checks=[]
with tempfile.TemporaryDirectory(prefix='compact-eval-routing-',dir='/tmp') as tmp:
    base=Path(tmp).resolve(); root=base/'units'/'EVALUATION-H12';root.mkdir(parents=True)
    run={**f.run,'run_root':str(base),'budgets':{'retained_bytes_per_replicate':8*1024**2},
         'units':[{'unit_id':f'{kind}-H12-O{o}','kind':kind,'horizon':12,'outer_fold':o}
            for kind in ('PRIMARY','AAR') for o in range(1,7)]}
    unit={'unit_id':'EVALUATION-H12','kind':'EVALUATION','horizon':12}
    context=copy.deepcopy(f.ctx); context['primary']=f.ooc
    context['source']['primary_source_archives']=copy.deepcopy(f.records)
    context['source']['primary_input_sha256']={str(o):f.sources[o-1]['manifest']['source_receipt']['artifacts']['input.zip']['sha256'] for o in range(1,7)}
    context.update(evaluation_response_csv=f.response,primary_point=f.point,primary_point_native=f.native,compact_evaluation=True)
    _,numeric,records=ledger_case()
    numeric['primary_ooc_sha256']=f.ooc['identity_sha256']
    numeric['selection_horizon_months']=12
    outers=copy.deepcopy(f.outers)
    mapping={}; created=[]; loaded=[]; origin=[]
    for i,row in enumerate(outers):
        row['source']['primary_archive_sha256']=f.records[i]['sha256']
        row['source']['primary_input_sha256']=context['source']['primary_input_sha256'][str(i+1)]
        row['source']['primary_source']['primary_development_lock']['identity_sha256']=f.ooc['selection_by_outer'][i]['development_lock_sha256']
        row['identity_sha256']=n._sha({k:v for k,v in row.items() if k!='identity_sha256'})
    for u,row in zip(run['units'][:6],f.sources,strict=True):mapping[u['unit_id']]=copy.deepcopy(row)
    for u,row,r in zip(run['units'][6:],outers,records,strict=True):
        mapping[u['unit_id']]={'metadata':row,'archive_record':r}
    def source(run,u,path):
        path.mkdir(parents=True,exist_ok=True)
        target=path/'evaluation-input.zip'
        if not target.exists():
            write_deterministic_zip(target,{'unfitted-source.json':canonical_json_bytes({'id':u['unit_id']})})
            created.append(u['unit_id'])
        return target
    def source_load(path,run,u):
        with zipfile.ZipFile(path) as z:assert json.loads(z.read('unfitted-source.json'))['id']==u['unit_id']
        loaded.append(u['unit_id']);return copy.deepcopy(mapping[u['unit_id']])
    def ordered(worker,tasks,**kwargs):return [worker(t) for t in tasks]
    def point_origin(h,raw,p,native,**kwargs):
        assert raw==f.response and p==f.point and native==f.native
        assert h['patient_ids']==f.ooc['patient_ids'] and h['primary_ooc_sha256']==f.ooc['identity_sha256']
        assert h['selection_horizon_months']==12
        origin.append(1);return p['evaluation']
    def evaluation(*args,**kwargs):
        loc=kwargs['evidence_root'];loc.mkdir(parents=True,exist_ok=True)
        for name in a._a12_evaluation_member_names(nested=True):
            (loc/name).write_bytes(b'UNFITTED_NATIVE' if name.endswith('.zip') else b'{}\n')
        return copy.deepcopy(numeric)
    def replay(loc,*args,**kwargs):
        assert set(p.name for p in loc.iterdir())==a._a12_evaluation_member_names(nested=True)
        return copy.deepcopy(numeric)
    with ExitStack() as stack:
        stack.enter_context(patch.object(runtime,'observe_execution_resources',lambda root:{'scratch_available_bytes':10**12}))
        stack.enter_context(patch.object(runtime,'_readback_ordered',ordered))
        stack.enter_context(patch.object(a,'prepare_f45_evaluation_source',source))
        stack.enter_context(patch.object(a,'load_f45_evaluation_source',source_load))
        stack.enter_context(patch.object(a,'_f45_evaluation_context',lambda *args:copy.deepcopy(context)))
        stack.enter_context(patch.object(a,'_a12_primary_point_origin',point_origin))
        prepared=a.prepare_f45_evaluation(run,unit,root)
        assert len(created)==len(loaded)==12
        original=(root/'evaluation-input.zip').read_bytes()
        created.clear(); loaded.clear()
        loaded_result=a.prepare_f45_evaluation(run,unit,root)
        assert created==[] and len(loaded)==12 and loaded_result['handoff']==prepared['handoff']
        assert (root/'evaluation-input.zip').read_bytes()==original
        checks.append('prepare_then_resume_no_source_regeneration_same_bytes')
        (base/'shared').mkdir();(base/'shared'/'bootstrap-preparation.json').write_bytes(b'{}\n')
        stack.enter_context(patch.object(a,'evaluate_a12_incremental_value',evaluation))
        stack.enter_context(patch.object(a,'_replay_a12_evaluation',replay))
        result=a.execute_f45_compact_evaluation(run,unit,root,prepared)
        packet=(root/'result.zip').read_bytes()
        with zipfile.ZipFile(root/'result.zip') as z:
            assert not any(name.startswith('outer-o') or name.startswith('execution-o') for name in z.namelist())
        checks.append('result_contains_only_compact_sources_and_metric_coordinates')
        shutil.rmtree(root/'result.zip.work');(root/'evaluation-input.zip').unlink()
        restored=a.replay_f45_compact_evaluation(run,unit,root)
        assert restored==result and (root/'result.zip').read_bytes()==packet
        assert (root/'evaluation-input.zip').read_bytes()==original
        checks.append('result_replay_rehydrates_without_old_work_or_archives')

# The source compatibility preserves a single exact original code generation.
names=('padml/f5_sensitivity.py','padml/f4.py','padml/kernels/f4_metrics.R')
keys=('producer_sha256','evaluation_module_sha256','metric_engine_sha256')
oldvals={name:digest('old-'+name) for name in names};newvals={name:digest('new-'+name) for name in names}
old={**dict(zip(keys,oldvals.values())),'handoff_sha256':digest('handoff'),'response_sha256':digest('response'),'plan':{'root_seed':700000001},'replicate':1,'draw_indices':[1,0,1]}
new={**old,**dict(zip(keys,newvals.values()))}
with patch.object(f5,'_f45_score_reuse_authorities',lambda:({}, {'old':oldvals,'new':newvals})):
    assert a._a12_compatible_binding(old,new)
    mixed={**old,'evaluation_module_sha256':new['evaluation_module_sha256']}
    assert not a._a12_compatible_binding(mixed,new)
    assert not a._a12_compatible_binding({**old,'draw_indices':[1,0,0]},new)
    assert not a._a12_compatible_binding({**old,'replicate':2},new)
    checks.append('old_source_tuple_accepted_mixed_generation_or_draw_or_coordinate_rejected')
print(json.dumps({'status':'PASS','checks':checks,'scope':'UNFITTED_ROUTING_WITH_NATIVE_ENGINES_AND_SOURCE_NUMERIC_READERS_SPIED','model_fits':0,'R_calls':0,'scientific_completion':False}))
