"""Identity-only pending coordinate probe; no clinical metric calculation."""
import json,tempfile,zipfile
from pathlib import Path
from unittest.mock import patch
from fixtures import six_outers,digest
from padml import f5_sensitivity as a,f5
from padml.bundle import canonical_json_bytes,ContractError
context,outers=six_outers()
handoff=a._validate_a12_handoff(a._a12_handoff_from_outers(context,outers))
eval_handoff={key:handoff[key] for key in ('patient_ids','centers','horizons','survival')}
eval_handoff.update(a._a12_evaluation_scope(handoff))
draw=list(range(len(handoff['patient_ids'])))
names=('padml/f5_sensitivity.py','padml/f4.py','padml/kernels/f4_metrics.R')
keys=('producer_sha256','evaluation_module_sha256','metric_engine_sha256')
oldvals={name:digest('old-'+name) for name in names};newvals={name:digest('new-'+name) for name in names}
old={**dict(zip(keys,oldvals.values())),'handoff_sha256':digest('handoff'),'response_sha256':digest('response'),'plan':{'replicate_count':1000}}
new={**old,**dict(zip(keys,newvals.values()))}
with tempfile.TemporaryDirectory(prefix='pending-coord-',dir='/tmp') as tmp:
    root=Path(tmp).resolve();native=root/'replicate-0001';native.mkdir()
    before=canonical_json_bytes({**old,'replicate':1,'draw_indices':draw})
    (native/'input.json').write_bytes(before);(native/'metrics.zip').write_bytes(b'ORIGINAL_NATIVE_BYTES')
    calls=[]
    def fake_eval(*args,**kwargs):
        assert kwargs['replay_native_archive']==native/'metrics.zip'
        assert kwargs['replay_native_archive'].read_bytes()==b'ORIGINAL_NATIVE_BYTES'
        calls.append('REPLAY_ORIGINAL_NATIVE');return {'UNFITTED_ROUTING':True}
    with patch.object(f5,'_f45_score_reuse_authorities',lambda:({}, {'old':oldvals,'new':newvals})),\
            patch.object(a,'evaluate_predictions',fake_eval),\
            patch.object(a,'_validate_a12_native_evaluation',lambda *args,**kwargs:None),\
            patch.object(a,'_a12_bootstrap_row',lambda *args,**kwargs:{'replicate':1,'UNFITTED_ROUTING':True}):
        a._a12_bootstrap_replicate((1,draw),evaluation_handoff=eval_handoff,
            response_csv=context['evaluation_response_csv'],work_root=root,source_binding=new,
            retained_bytes_per_replicate=8*1024**2)
    with zipfile.ZipFile(root/'replicate-0001.zip') as archive:
        after=archive.read('input.json')
    retained=before==after
    print(json.dumps({'status':'PASS' if retained else 'CONFIRMED_DEFECT','original_pending_input_retained':retained,
        'old_native_replayed':calls==['REPLAY_ORIGINAL_NATIVE'],'scope':'IDENTITY_ROUTE_ONLY_NUMERIC_ENGINE_SPIED',
        'model_fits':0,'R_calls':0}))
    assert retained,'Original pending coordinate input was relabeled to the new source while retaining the old native result'

with tempfile.TemporaryDirectory(prefix='bad-pending-coord-',dir='/tmp') as tmp:
    root=Path(tmp).resolve();native=root/'replicate-0001';native.mkdir()
    badraw=canonical_json_bytes({**old,'replicate':1,'draw_indices':list(reversed(draw))})
    (native/'input.json').write_bytes(badraw);(native/'metrics.zip').write_bytes(b'ORIGINAL_NATIVE_BYTES')
    with patch.object(f5,'_f45_score_reuse_authorities',lambda:({}, {'old':oldvals,'new':newvals})),\
            patch.object(a,'evaluate_predictions',side_effect=AssertionError('SHOULD_REJECT_BEFORE_METRICS')):
        try:
            a._a12_bootstrap_replicate((1,draw),evaluation_handoff=eval_handoff,
                response_csv=context['evaluation_response_csv'],work_root=root,source_binding=new,
                retained_bytes_per_replicate=8*1024**2)
        except ContractError as exc:
            assert str(exc)=='F5_A12_RETAINED_INPUT_MISMATCH'
            assert (native/'input.json').read_bytes()==badraw
            assert not (root/'replicate-0001.zip').exists()
        else:raise AssertionError('MUTATED_PENDING_DRAW_ACCEPTED')
    print(json.dumps({'status':'PASS','check':'bad_pending_binding_rejected_before_metric_and_bytes_unchanged'}))
