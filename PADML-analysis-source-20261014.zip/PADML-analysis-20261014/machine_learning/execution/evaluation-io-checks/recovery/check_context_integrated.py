"""Unfitted control-flow checks for the context transplant candidate."""
import copy
import json
import tempfile
import zipfile
from pathlib import Path
from unittest.mock import patch
from padml import f5_sensitivity as p
from padml import runtime,run as runmod
from fixtures import six_outers,digest
from padml import f4,nested_loco as n,f5_sensitivity as a
from padml.bundle import canonical_json_bytes,sha256_bytes,write_deterministic_zip,ContractError

ctx,outers=six_outers(12)
registry=ctx['population_registry']
full_response=('Patient_ID,All_Cause_Death,Death_Followup_months\n'+''.join(
    f'{pid},{i%2},{10+i}\n' for i,pid in enumerate(registry['all_patient_ids']))).encode()
sources=[]
for i,part in enumerate(registry['outer'],1):
    selection=ctx['primary']['selection_by_outer'][i-1]
    ids=part['heldout_ids']
    matrix=[ctx['primary']['survival']['NESTED_SELECTED_POLICY'][ctx['primary']['patient_ids'].index(pid)] for pid in ids]
    components=[{'imputation':m,'identity_sha256':digest(f'{i}-{m}')} for m in range(1,21)]
    selected=n._sealed({'schema_version':n.SCHEMA_VERSION,
        'kind':'PADML_NESTED_LOCO_SELECTED_OUTER_PREDICTION_V1','selection_horizon_months':12,
        'science_decision_sha256':ctx['science_decision']['identity_sha256'],'status':'SEALED_RESPONSE_FREE',
        'outer_fold':i,'heldout_center':part['heldout_center'],'selected_family':selection['selected_family'],
        'development_lock_sha256':selection['development_lock_sha256'],'patient_ids':ids,
        'patient_ids_sha256':n._sha(ids),'centers':[str(part['heldout_center'])]*len(ids),
        'horizons':list(f4.HORIZONS),'survival':matrix,
        'survival_seal_sha256':a._seal_prediction_matrix(ids,matrix,list(f4.HORIZONS))['sha256'],
        'component_receipt_sha256':[r['identity_sha256'] for r in components],'component_count':20,
        'model_fit_count':20,'heldout_outcome_read_count':0})
    request=n._sealed({'kind':'PADML_F4_O_FIT_INPUT_V1','selection_horizon_months':12,
        'science_decision':ctx['science_decision'],'training_context':{**part,
            'centers_by_patient':registry['centers_by_patient']}})
    receipt={'unit_id':f'PRIMARY-H12-O{i}','status':'COMPLETED','direct_consumer_completed':True,
        'selection_horizon_months':12,'report_horizons_months':[6,12,24,36],'run_identity':digest('run'),
        'artifacts':{'input.zip':{'sha256':digest(f'input-{i}'),'size_bytes':100+i},
            'result.zip':{'sha256':digest(f'result-{i}'),'size_bytes':200+i}}}
    meta=n._sealed({'kind':'PADML_F4_O_FIT_EXECUTION_ARCHIVE_V3','outer_fold':i,
        'family':selection['selected_family'],'input_archive':receipt['artifacts']['input.zip'],
        'input_identity_sha256':request['identity_sha256'],
        'science_decision_sha256':ctx['science_decision']['identity_sha256'],
        'development_lock':{'selected_family':selection['selected_family'],'identity_sha256':selection['development_lock_sha256']},
        'selected_prediction':selected,'component_receipts':components})
    sources.append({'manifest':{'source_receipt':receipt,'unit_id':receipt['unit_id'],'horizon':12,'outer_fold':i},
        'metadata':meta,'request':request,'selected_prediction':selected})
run={'identity':digest('run'),'source_identity':digest('source'),'f2_run_root':'/unfitted/f2',
    'f1_runtime_root':'/unfitted/f1','resource_policy':{'memory_reserve_bytes':1}}
frozen={'registry':{'outer':[{'outer_fold':r['outer_fold'],'heldout_center':r['heldout_center'],
    'application_ids':registry['all_patient_ids'],'analysis_ids':r['training_ids'],'validation_ids':r['heldout_ids']}
    for r in registry['outer']]},'centers':registry['centers_by_patient'],'response_csv':full_response}
accepted={'runtime_root':Path('/unfitted/f1'),'f1_manifest':{},'replay':{},
    'source':{'f2_acceptance_sha256':digest('f2'),'f1_identity':digest('f1')}}
ooc=n.assemble_selected_ooc([r['selected_prediction'] for r in sources],population_registry=registry)
fields,responses=a._response_rows(full_response)
response=a._write_response_subset(fields,responses,ooc['patient_ids'],None)['private_bytes']
native=b'UNFITTED_NATIVE_POINT_ARCHIVE_BYTES'
point=n._sealed({'schema_version':n.SCHEMA_VERSION,'kind':'PADML_NESTED_LOCO_SELECTED_POLICY_EVALUATION_V1',
    'selection_horizon_months':12,'science_decision_sha256':ctx['science_decision']['identity_sha256'],
    'status':'COMPUTED_NOT_EXTERNAL_VALIDATION_OF_FULL_DATA_MODEL','selected_ooc_sha256':ooc['identity_sha256'],
    'heldout_response_sha256':sha256_bytes(response),'outcome_join_location':'WHOLE_UNIT_ORIGINAL_F4_F5_EVALUATION',
    'evaluation':{'UNFITTED_ROUTING_ONLY':True},'full_data_final_model_external_validation':False})
records=[{'outer_fold':i,'member':f'execution-o{i:02d}.zip',
    'identity_sha256':row['metadata']['identity_sha256'],**row['manifest']['source_receipt']['artifacts']['result.zip']}
    for i,row in enumerate(sources,1)]
aggregate=n._sealed({'schema_version':n.SCHEMA_VERSION,'kind':'PADML_F4_O_FIT_AGGREGATE_ARCHIVE_V4',
    'status':'COMPUTED_PROGRAM_OOC_NOT_STAGE_ACCEPTANCE','source_archives':records,
    'science_decision_sha256':ctx['science_decision']['identity_sha256'],
    'native_metric_archive':{'member':'evaluation/metrics.zip','sha256':sha256_bytes(native),'size_bytes':len(native)},
    'selected_ooc':ooc,'evaluation':point,'model_fit_count':0,
    'outer_family_consensus_required':False,'full_data_model_independently_validated':False})
reads=[]
origin_calls=[]
metric_calls=[]
original_read=zipfile.ZipFile.read

def read_spy(self,name,*args,**kwargs):
    reads.append(name.filename if isinstance(name,zipfile.ZipInfo) else name)
    return original_read(self,name,*args,**kwargs)

def origin(handoff,raw,original_point,original_native,**kwargs):
    assert handoff['patient_ids']==ooc['patient_ids'] and raw==response
    assert original_point==point and original_native==native
    origin_calls.append('NATIVE_READ_ONLY')
    return original_point['evaluation']

def metric(selected,raw,**kwargs):
    assert selected==ooc and raw==response
    if 'native_archive' in kwargs:
        metric_calls.append('FIRST_NATIVE_POINT')
        kwargs['native_archive'].write_bytes(native)
    else:
        metric_calls.append('RETAINED_NATIVE_POINT')
        assert kwargs['replay_native_archive'].read_bytes()==native
    return copy.deepcopy(point)

patches=[patch.object(runmod,'f45_unit_predecessors',lambda run:[]),
    patch.object(runtime,'resource_admission',lambda *x,**kw:{}),
    patch.object(runtime,'observe_execution_resources',lambda root:{}),
    patch.object(n,'validate_training_context',lambda value,*args,**kw:value),
    patch.object(n,'validate_development_lock',lambda value,**kw:value),
    patch.object(n,'validate_component_receipt',lambda value,lock:value),
    patch.object(n,'validate_selected_prediction',lambda value,lock=None:value),
    patch.object(f4,'_load_f4_source_records',lambda *x,**kw:copy.deepcopy(accepted)),
    patch.object(f4,'_load_o_fit_frozen_source',lambda *x,**kw:copy.deepcopy(frozen)),
    patch.object(a,'_a12_primary_point_origin',origin),
    patch.object(n,'evaluate_selected_ooc',metric),patch.object(zipfile.ZipFile,'read',read_spy)]
for x in patches:x.start()
checks=[]
try:
    with tempfile.TemporaryDirectory(prefix='context-check-',dir='/tmp') as tmp:
        root=Path(tmp).resolve()/'old'/'EVALUATION-H12';root.mkdir(parents=True)
        source=root/'primary.zip'
        write_deterministic_zip(source,{'o-fit-aggregate.json':canonical_json_bytes(aggregate),
            'evaluation/metrics.zip':native,'execution-o01.zip':b'DO_NOT_READ_FULL_DEVELOPMENT'})
        before=source.read_bytes()
        result=p._f45_evaluation_context(run,root,sources)
        assert reads==['o-fit-aggregate.json','evaluation/metrics.zip']
        assert metric_calls==[] and source.read_bytes()==before
        assert 'frozen' not in result and result['primary']==ooc
        checks.append('old_zip_two_members_no_new_point_no_mutation')
        pins={path.name:path.read_bytes() for path in (root/'result.zip.work'/'primary-context').iterdir() if path.is_file()}
        reads.clear()
        with patch.object(f4,'_load_f4_source_records',side_effect=AssertionError('REPEATED_F1_PREPARATION')):
            replay=p._f45_evaluation_context(run,root,sources)
        assert reads==[] and replay==result
        assert pins=={path.name:path.read_bytes() for path in (root/'result.zip.work'/'primary-context').iterdir() if path.is_file()}
        checks.append('cached_context_no_archive_or_F1_read_same_bytes')
        bad=copy.deepcopy(sources)
        bad[0]['manifest']['source_receipt']['artifacts']['input.zip']['sha256']=digest('bad')
        try:p._f45_evaluation_context(run,root,bad)
        except ContractError:checks.append('changed_receipt_input_rejected')
        else:raise AssertionError('CHANGED_SOURCE_ACCEPTED')
        root=Path(tmp).resolve()/'new'/'EVALUATION-H12';root.mkdir(parents=True)
        fresh=p._f45_evaluation_context(run,root,sources)
        assert metric_calls==['FIRST_NATIVE_POINT'] and not (root/'primary.zip').exists()
        assert fresh['primary']==ooc
        checks.append('no_old_zip_first_point_once_no_heavy_primary_zip')
        (root/'result.zip.work'/'primary-context'/'context.json').unlink()
        replay=p._f45_evaluation_context(run,root,sources)
        assert metric_calls==['FIRST_NATIVE_POINT','RETAINED_NATIVE_POINT']
        checks.append('interrupted_context_reuses_native_point')
finally:
    for x in reversed(patches):x.stop()
print(json.dumps({'status':'PASS','checks':checks,
    'test_scope':'UNFITTED_ROUTING_ONLY_NATIVE_VALIDATORS_SPIED','actual_R_calls':0,
    'model_fits':0,'clinical_or_scientific_completion':False}))
