"""One-field engineering retention compatibility only; no pipeline or native work."""
import ast,copy,json
from pathlib import Path
from padml import run as r
from padml.bundle import sha256_file

M=1024**2; K='retained_bytes_per_replicate'
base={'retained_bytes_per_view':2*1024**3,'retained_bytes_per_component':64*M,
 'expanded_bytes_per_component':16*M,'shared_storage_bytes':4*1024**3,
 K:8*M,'retained_bytes_per_q_task':512*M}
def row(value):return {**base,K:value}
cases=[]
def expect(name,old,new,want):
 before=copy.deepcopy((old,new)); observed=r._f45_compatible_retention_budgets(old,new)
 assert observed is want,(name,observed,want)
 assert (old,new)==before,(name,'INPUT_MUTATED')
 cases.append({'case':name,'result':observed})
for name,old,new,want in [('same_8_MiB',8*M,8*M,True),('same_16_MiB',16*M,16*M,True),
 ('exact_8_to_16_MiB',8*M,16*M,True),('reverse_16_to_8_MiB',16*M,8*M,False),
 ('8_to_32_MiB',8*M,32*M,False),('16_to_32_MiB',16*M,32*M,False),
 ('32_to_16_MiB',32*M,16*M,False),('32_to_8_MiB',32*M,8*M,False),
 ('old_float',float(8*M),16*M,False),('new_float',8*M,float(16*M),False),
 ('same_float',float(8*M),float(8*M),False),('old_bool',True,16*M,False),
 ('new_bool',8*M,True,False),('same_bool',True,True,False),('same_zero',0,0,False)]:
 expect(name,row(old),row(new),want)
changed=row(16*M);changed['retained_bytes_per_component']+=1
expect('other_budget_numeric_change',row(8*M),changed,False)
changed=row(16*M);changed['retained_bytes_per_component']=float(changed['retained_bytes_per_component'])
expect('other_budget_type_change',row(8*M),changed,False)
missing={k:v for k,v in row(16*M).items() if k!=K}
expect('current_missing_target',row(8*M),missing,False)
expect('previous_missing_target',missing,row(16*M),False)
expect('both_missing_target',missing,missing,False)
missing_other={k:v for k,v in row(16*M).items() if k!='shared_storage_bytes'}
expect('current_missing_other_key',row(8*M),missing_other,False)
expect('previous_missing_other_key',missing_other,row(16*M),False)
expect('current_added_other_key',row(8*M),{**row(16*M),'new_budget':1},False)

# Check both manifest comparators require the narrow helper before unchanged-body equality.
path=Path(r.__file__);tree=ast.parse(path.read_bytes())
call_sites=[]
for name in ('_f45_unit_predecessor_uncached','_validate_f45_resource_revision_uncached'):
 node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name==name)
 requirements=[n for n in ast.walk(node) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name)
   and n.func.id=='_require' and n.args and any(isinstance(x,ast.Call) and isinstance(x.func,ast.Name)
   and x.func.id=='_f45_compatible_retention_budgets' for x in ast.walk(n.args[0]))]
 assert len(requirements)==1
 condition=requirements[0].args[0]
 assert isinstance(condition,ast.BoolOp) and isinstance(condition.op,ast.And)
 assert any(isinstance(x,ast.Compare) and isinstance(x.left,ast.DictComp) for x in ast.walk(condition))
 call_sites.append({'function':name,'helper_required_with_unchanged_manifest_body':True})
report={'status':'PASS','cases':cases,'call_sites':call_sites,'run_module_sha256':sha256_file(path),
 'scope':'LOCAL_COMPATIBILITY_HELPER_AND_TWO_MANDATORY_CALL_SITES_ONLY',
 'clinical_calls':0,'remote_operations':0,'scientific_completion':False,
 'unchanged_32_MiB_pair_result':r._f45_compatible_retention_budgets(row(32*M),row(32*M))}
out=Path(__file__).with_name('check_retention_budget_compatibility_result.json')
out.write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
print(json.dumps(report,sort_keys=True))
