"""Focused synthetic direct-consumer routing checks, zero fits/R/RNG."""
import copy
import json
from unittest.mock import patch
from fixtures import six_outers, ledger_case
from padml import f5_sensitivity as a
from padml.bundle import ContractError

out=[]
for h in (6,12,24,36):
    context, outers = six_outers(h)
    handoff = a._a12_handoff_from_outers(context, outers)
    opened = a._validate_a12_handoff(handoff)
    assert opened['selection_horizon_months'] == h
    assert opened['patient_ids'] == context['population_registry']['evaluation_patient_ids']
    assert '55' not in opened['centers']
    assert len(set(opened['family_by_outer'].values())) == 6
    out.append('six_outer_handoff_' + str(h))
context, outers = six_outers()
for damage in ('patient_order','lock','input','horizon'):
    bad=copy.deepcopy(outers)
    if damage=='patient_order':
        bad[0]['predictions']['patient_ids'].reverse()
    elif damage=='lock':
        bad[0]['source']['primary_source']['primary_development_lock']['identity_sha256']='e'*64
    elif damage=='input':
        bad[0]['source']['primary_input_sha256']='e'*64
    else:
        bad[0]['source']['primary_source']['primary_development_lock']['selection_horizon_months']=24
    try:
        a._a12_handoff_from_outers(context,bad)
    except ContractError:
        out.append('reject_' + damage)
    else:
        raise AssertionError('accepted ' + damage)
context,numeric,records=ledger_case()
result=a._a12_native_summary(context,numeric,records)
assert result['actual_aar_execution_ledger']['post_lock_fits']==340
assert result['logical_aar_execution_ledger']['post_lock_fits']==360
assert result['reused_aar_execution_ledger']['post_lock_fits']==20
out.append('logical360_physical340_shared20')
bad=copy.deepcopy(records)
bad[0]['reused_execution_ledger']['post_lock_fits']=21
try:
    a._a12_native_summary(context,numeric,bad)
except ContractError:
    out.append('reject_inconsistent_ledger')
else:
    raise AssertionError('accepted inconsistent ledger')
print(json.dumps({'status':'PASS','checks':out,'scientific_estimation':False,'model_fits':0,'R_calls':0,'RNG_calls':0}))
