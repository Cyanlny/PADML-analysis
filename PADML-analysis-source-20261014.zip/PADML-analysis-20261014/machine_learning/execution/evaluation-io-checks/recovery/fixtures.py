"""Unfitted compact-EVALUATION routing fixtures; never clinical evidence."""
from copy import deepcopy
from padml import f4, f5_sensitivity as a, nested_loco as n
from padml.bundle import canonical_json_bytes, sha256_bytes


def digest(label):
    return sha256_bytes(('UNFITTED:' + label).encode())


def six_outers(h=12):
    science = n.science_decision_template(h)
    ids = [f'p{o}-{i}' for i in range(6) for o in range(1, 7)] + ['training-only-55']
    centers = {f'p{o}-{i}': str(c) for o, c in enumerate(n.OUTER_CENTERS, 1) for i in range(6)}
    centers[ids[-1]] = '55'
    registry = {'all_patient_ids': ids, 'evaluation_patient_ids': ids[:-1], 'centers_by_patient': centers,
        'outer': [{'outer_fold': o, 'heldout_center': c,
            'training_ids': [p for p in ids if centers[p] != str(c)],
            'heldout_ids': [p for p in ids if centers[p] == str(c)]}
            for o, c in enumerate(n.OUTER_CENTERS, 1)]}
    n.validate_population_registry(registry)
    families = list(n._families())[:6]
    selections = [{'outer_fold': o, 'heldout_center': c, 'selected_family': families[o-1],
        'development_lock_sha256': digest(f'lock-{h}-{o}'),
        'primary_development_lock_sha256': digest(f'lock-{h}-{o}'),
        'prediction_identity_sha256': digest(f'prediction-{h}-{o}')}
        for o, c in enumerate(n.OUTER_CENTERS, 1)]
    curve = [1.0] + [1.0 - t * .01 for t in range(1, 37)]
    primary = n._sealed({'schema_version': n.SCHEMA_VERSION,
        'kind': 'PADML_NESTED_LOCO_SELECTED_POLICY_OOC_V1',
        'selection_horizon_months': h, 'science_decision_sha256': science['identity_sha256'],
        'status': 'SEALED_RESPONSE_FREE', 'variant': 'PRIMARY',
        'population_registry_sha256': n._sha(registry), 'patient_ids': ids[:-1],
        'patient_ids_sha256': n._sha(ids[:-1]), 'centers': [centers[p] for p in ids[:-1]],
        'horizons': list(f4.HORIZONS), 'survival': {'NESTED_SELECTED_POLICY': [curve[:] for p in ids[:-1]]},
        'selection_by_outer': selections, 'outer_family_consensus_required': False,
        'heldout_outcome_read_count': 0})
    n.validate_selected_ooc(primary, population_registry=registry)
    records = [{'outer_fold': o, 'member': f'execution-o{o:02d}.zip',
        'identity_sha256': digest(f'primary-header-{o}'), 'sha256': digest(f'primary-archive-{o}'),
        'size_bytes': 1000 + o} for o in range(1, 7)]
    inputs = {str(o): digest(f'input-{o}') for o in range(1, 7)}
    context = {'primary': primary, 'population_registry': registry, 'science_decision': science,
        'family_by_outer': {str(o): family for o, family in enumerate(families, 1)},
        'source': {'kind': 'PADML_F5_NESTED_AAR_PRIMARY_SOURCE_V1', 'program_id': n.PROGRAM_ID,
            'primary_aggregate_sha256': digest('primary.zip'),
            'primary_aggregate_identity_sha256': digest('primary-header'),
            'science_decision_sha256': science['identity_sha256'], 'primary_ooc_sha256': primary['identity_sha256'],
            'primary_source_archives': records, 'primary_input_sha256': inputs}}
    outers = []
    for part, selection in zip(registry['outer'], selections, strict=True):
        o = part['outer_fold']
        source = {'primary_archive_sha256': records[o-1]['sha256'], 'primary_input_sha256': inputs[str(o)],
            'primary_source': {'science_decision': science, 'primary_development_lock': {
                'identity_sha256': selection['development_lock_sha256'], 'selection_horizon_months': h,
                'science_decision_binding': {'science_decision_sha256': science['identity_sha256']}},
                'primary_training_context': {k: part[k] for k in ('training_ids', 'heldout_ids', 'heldout_center')}}}
        row = {'kind': 'PADML_F5_A12_OUTER_NATIVE_V2', 'outer_fold': o, 'family': families[o-1], 'source': source,
            'predictions': {'patient_ids': part['heldout_ids'], 'centers': [str(part['heldout_center'])] * 6,
                'horizons': list(f4.HORIZONS), 'survival': {b: [[1.0] + [1-t*(.010 + j*.001) for t in range(1,37)]
                    for p in part['heldout_ids']] for j, b in enumerate(n.AAR_ESTIMANDS)}},
            'native_members': {f'fits/O{o}_{b}_M{i:02d}.zip': {'sha256': digest(f'{o}-{b}-{i}'), 'size_bytes': 100}
                for b in n.AAR_ESTIMANDS for i in range(1,21)}, 'members': {}}
        outers.append(n._sealed(row))
    response = ('Patient_ID,All_Cause_Death,Death_Followup_months\n' + ''.join(
        f'{p},{i%2},{10+i}\n' for i, p in enumerate(ids[:-1]))).encode()
    context['evaluation_response_csv'] = response
    return context, outers


def ledger_case(h=12):
    context, _ = six_outers(h)
    context['compact_evaluation'] = True
    keys = ('mice_chains', 'elastic_path_executions', 'glmnet_pilot_and_path_calls',
        'candidate_prediction_fits', 'stop_fits', 'inner_scoring_fits', 'post_lock_fits', 'total_model_fits')
    logical = dict.fromkeys(keys, 0)
    logical.update(mice_chains=40, post_lock_fits=60, total_model_fits=60)
    records = []
    for o in range(1, 7):
        shared = dict.fromkeys(keys, 0)
        if o == 1:
            shared.update(post_lock_fits=20, total_model_fits=20)
        physical = {k: logical[k] - shared[k] for k in keys}
        records.append({'outer_fold': o, 'execution_ledger': physical,
            'logical_execution_ledger': deepcopy(logical), 'reused_execution_ledger': shared})
    numeric = {'family_by_outer': context['family_by_outer'],
        'science_decision_sha256': context['science_decision']['identity_sha256'],
        'primary_ooc_sha256': context['primary']['identity_sha256'],
        'bootstrap': {'replicate_count':1000,'paired_row_count':24,
            'metrics': {'macro': ['one'], 'scope': ['two']}}}
    return context, numeric, records
