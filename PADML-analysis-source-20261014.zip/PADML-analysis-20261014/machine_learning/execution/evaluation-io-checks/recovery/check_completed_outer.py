"""Optional completed-consumer migration routing only; no production reads."""
import json,tempfile,copy
from pathlib import Path
from unittest.mock import patch
from fixtures import digest
from padml import f5_sensitivity as a
from padml.bundle import canonical_json_bytes,sha256_bytes,ContractError
p=lambda s:{'sha256':digest(s),'size_bytes':10}
receipt={'artifacts':{'result.zip':p('result'),'input.zip':p('input')}}
header={'outer_fold':1,'family':'COXTIME_SET_A','source':{'identity_sha256':digest('projected'),'resource_policy':{}}}
authorities=({'run':digest('executor')},{})
with tempfile.TemporaryDirectory(prefix='completed-outer-check-',dir='/tmp') as tmp:
    root=Path(tmp).resolve()
    reports={}
    def put(name,record):
        path=root/f'padml-a12-outer-replay-{name}'/'execution.json';path.parent.mkdir()
        path.write_bytes(canonical_json_bytes(record));reports[name]=path
        return path
    def value(name):
        return {'executor_source_identity':digest('executor'),'operation':'OUTER_REPLAY','outer_fold':1,'family':'COXTIME_SET_A',
            'task_names':list(a._a12_final_task_coordinates(1)),'input_archive':receipt['artifacts']['result.zip'],
            'projected_input':receipt['artifacts']['input.zip'],'projected_input_identity_sha256':header['source']['identity_sha256'],
            'work_root':str(root/f'padml-a12-outer-replay-{name}'),'last_consumer_finished_ns':1234}
    put('00-expansion',{'archive_expansion':{'expanded_bytes':123}})
    no_marker={**value('01-partial'),'last_consumer_finished_ns':None}
    put('01-partial',{'input_execution':no_marker})
    incomplete={**value('02-diagnostic-tail'),'DIAGNOSTIC_INCOMPLETE':True}
    put('02-diagnostic-tail',{'input_execution':incomplete,'numerical_read_pool':{'status':'COMPLETED','completed_task_count':60}})
    completed=value('03-complete')
    good=put('03-complete',{'input_execution':completed,'numerical_read_pool':{'status':'COMPLETED','completed_task_count':60}})
    validated=[]
    def validate(raw,**kwargs):
        obj=json.loads(raw)['input_execution']
        assert kwargs['loader_report'] is True and kwargs.get('expected_owners') is None
        assert not (Path(obj['work_root'])/'archive').exists() and not (Path(obj['work_root'])/'inputs').exists()
        if obj.get('DIAGNOSTIC_INCOMPLETE') or obj['last_consumer_finished_ns'] is None:
            raise ContractError('F5_A12_FINAL_INPUT_EXECUTION_INVALID')
        validated.append(obj['work_root']);return obj
    with patch.object(a,'_validate_a12_final_input_execution',validate):
        result=a._f45_evaluation_completed_outer(root,receipt,header,authorities)
    assert result['temporary_trees_required'] is False
    assert result['original_report']['path']==good.relative_to(root).as_posix()
    assert validated==[str(good.parent)]
    bad=copy.deepcopy(receipt)
    bad['artifacts'][good.relative_to(root).as_posix()]={'sha256':digest('wrong'),'size_bytes':good.stat().st_size}
    with patch.object(a,'_validate_a12_final_input_execution',validate):
        try:a._f45_evaluation_completed_outer(root,bad,header,authorities)
        except ContractError as e:assert str(e)=='F45_EVALUATION_CONSUMER_REPORT_DRIFT'
        else:raise AssertionError('ORIGINAL_RECEIPT_PIN_DRIFT_ACCEPTED')
print(json.dumps({'status':'PASS','checks':['expansion_or_partial_diagnostic_not_a_whole_veto','complete_consumer_migrates_without_temporary_trees','explicit_receipt_report_pin_drift_rejected'],
    'scope':'OPTIONAL_DIAGNOSTIC_ROUTE_NATIVE_VALIDATOR_SPIED','R_calls':0,'model_fits':0}))
