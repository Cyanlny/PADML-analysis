"""Qualify the exact appended optimism consumers; no clinical execution."""
import copy, json, os, tempfile, zipfile
from pathlib import Path
from unittest.mock import patch
from padml import f4, nested_loco as nested, run
from padml.bundle import ContractError, canonical_json_bytes as enc, sha256_bytes as sha, sha256_file

repo = Path(__file__).resolve().parents[2]
checks = Path(__file__).resolve().parent
previous = repo / 'execution/release-optimism/PADML_F45_REBUILD_20261001_OPTIMISM.zip'
assert sha256_file(previous) == '8070b90e5c1d8646545c24a131e26dfe8433ccb9b9ec38808c5cc04e4f9cb49a'
current_members = f4._f45_source_member_sha256()
results = {}
with tempfile.TemporaryDirectory(prefix='h9-q-risk-copy-source-') as temporary:
    base = Path(temporary).resolve()
    with zipfile.ZipFile(previous) as archive:
        for name in archive.namelist():
            if name in ('run.json', 'source.zip') or name.endswith(('/run.json', '/source.zip')):
                target = base / name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(archive.read(name))
    with zipfile.ZipFile(base / 'source.zip') as source:
        old_members = {name: sha(source.read(name)) for name in f4.F45_SOURCE_MEMBERS}
    assert {name for name in current_members if current_members[name] != old_members[name]} == {
        'padml/f4.py', 'padml/f5.py', 'padml/f4_compact.py', 'padml/f5_sensitivity.py', 'padml/runtime.py', 'padml/worker.py', 'padml/run.py', 'AGENTS.md', 'NESTED_LOCO_PROTOCOL.md'}
    original = json.loads((base / 'run.json').read_bytes())
    retained_pins = []
    for retained_prefix, filename, run_sha, source_sha in (
        ('evaluation-io-capsule-predecessor', 'candidate-f15c41c4c22c/VALIDATION_ONLY.zip',
         '706521641add77e6d3694d655dec426527296d51e231d8b9c9afecbed316ea6d',
         '99900b0318a30b2ad74351e12f9f481c9fa2718dff595a17f446a4e1fd3fc8e4'),
        ('evaluation-io-point-predecessor', 'candidate-4ef01be829e3/VALIDATION_ONLY-2e2d76cf018e.zip',
         '4491fb135b2890869d637982fdb97e02ee51947a14f99ebae21597ff4bc1c19b',
         '9f224af0b6f9d62e4f47a5cd96dc0dbda738496726db76d96265bf31d7ae49bd'),
        ('evaluation-io-coordinate-predecessor', 'candidate-a82cb4d2b8df/VALIDATION_ONLY-0262c3dfb273.zip',
         '4cf9bacdbaa22b31a03496ab2ddc8d913664fae94b056e69edda480c3025dd2d',
         '51cf2eb78ef68bdcee808587cfa9b0e87ac587e9851ab21784fb410be02c6155')):
        with zipfile.ZipFile(checks / filename) as archive:
            for name, expected in (('run.json', run_sha), ('source.zip', source_sha)):
                raw = archive.read(name); assert sha(raw) == expected
                target = base / retained_prefix / name; target.parent.mkdir(exist_ok=True)
                target.write_bytes(raw)
        retained_pins.append({'run_path': str(base / retained_prefix / 'run.json'),
            'run_sha256': sha256_file(base / retained_prefix / 'run.json'),
            'source_path': str(base / retained_prefix / 'source.zip'),
            'source_sha256': sha256_file(base / retained_prefix / 'source.zip')})
    parent = base / 'evaluation-io-predecessor'; parent.mkdir()
    for name in ('run.json', 'source.zip'):
        (parent / name).write_bytes((base / name).read_bytes())
    value = {**original, 'source_identity': sha(enc(current_members)), 'source_bundle_sha256': 'd'*64,
        'budgets': {**original['budgets'], 'retained_bytes_per_replicate': 16 * 1024**2},
        'unit_source_predecessors': [*original.get('unit_source_predecessors', []), *retained_pins],
        'unit_predecessor': {'run_path': str(base / 'run.json'), 'run_sha256': sha256_file(base / 'run.json'),
            'source_path': str(base / 'source.zip'), 'source_sha256': sha256_file(base / 'source.zip')}}
    value['identity'] = sha(enc({k: v for k, v in value.items() if k != 'identity'}))
    remote = original['run_root']
    def mapped(location):
        location = str(location)
        return Path(str(base) + location[len(remote):]) if location.startswith(remote + '/') else Path(location)
    with patch.object(run, 'Path', mapped), patch.object(f4, 'Path', mapped):
        predecessors = run.f45_unit_predecessors(value)
        prior = json.loads((repo / 'execution/optimism-checks/qualification.json').read_bytes())
        assert [p['identity'] for p in predecessors] == [original['identity'], *prior['checks']['predecessors'],
            '42befbc14024edaba152988bf62308438dbb8cb370e1ccb8e9a2c57a2a322cb7',
            '23ed5ad6eb2a46d36d2c49b72623bf85d6358ed3beb08ec1aa2bbd883ed6f95b',
            'c33725484ea09178a6e261a5ea7cac0ec70db2fe5c79400cbbdd062623069939']
        assert len(predecessors) == 28
        baseline = run.validate_f45_resource_revision(value)
        assert sha(enc(baseline)) == '25190343ea52b20014b6cb38eae518b4fe77621e02c8eb24a5b3f66fc5047c50'
        results.update(predecessors=[p['identity'] for p in predecessors], original_baseline_qualified=True)
        current = repo / 'padml/f4.py'
        raw, actual_read = current.read_bytes(), Path.read_bytes
        before = b'outside - inbag if metric == "ibs" else inbag - outside'
        assert raw.count(before) == 1
        altered = raw.replace(before, b'inbag - outside if metric == "ibs" else outside - inbag')
        with patch.object(Path, 'read_bytes', lambda path: altered if path == current else actual_read(path)):
            for name, validator in [('predecessor', run.f45_unit_predecessors),
                                    ('baseline', run.validate_f45_resource_revision)]:
                try:
                    validator(value)
                except ContractError as error:
                    results[name + '_unknown_scope_edit_rejected'] = str(error)
                else:
                    raise AssertionError(name + ': unknown scope edit accepted')
        damaged = copy.deepcopy(value)
        damaged['unit_predecessor']['source_sha256'] = 'f'*64
        try:
            run.f45_unit_predecessors(damaged)
        except ContractError as error:
            results['unknown_source_pin_rejected'] = str(error)
        else:
            raise AssertionError('unknown predecessor source')
    assert value['science_decision'] == original['science_decision']


old_r = __import__('subprocess').check_output(['git', 'show', 'b290a3869f8158a8396c2c7ed938215c30388c01:padml/kernels/f4_metrics.R'], cwd=repo)
new_r = (repo/'padml/kernels/f4_metrics.R').read_bytes()
assert all(f4._metric_kernel_compatible(old_r,new_r,horizon=h) for h in (6,12,24,36))
assert not f4._metric_kernel_compatible(old_r,new_r+b'\n# unauthorized',horizon=24)
assert not f4._metric_kernel_compatible(old_r+b'\n',new_r,horizon=24)
results['legacy_metric_numerics_byte_identical_projection'] = True
results['old_metric_archive_preserved_and_unknown_revision_rejected'] = True
record = {'source_identity': sha(enc(current_members)), 'checks': results, 'clinical_calls': 0,
    'qualification_remote_operations': 0, 'science_decision_unchanged': True}
(checks/'qualification.json').write_bytes(enc(record))
print(json.dumps(record))
