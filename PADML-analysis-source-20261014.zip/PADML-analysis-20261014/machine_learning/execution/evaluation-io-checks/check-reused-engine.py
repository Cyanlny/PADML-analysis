"""UNFITTED cross-horizon PRIMARY proof; actual production consumer, no native models."""
import copy,io,json,struct,zipfile
from pathlib import Path
from padml import f4,f5,f5_sensitivity as a,nested_loco as n
from padml.bundle import canonical_json_bytes as raw,sha256_bytes,ContractError
from padml.f2_kernel import _pool_prediction_batch,_seal_prediction_matrix
from test_nested_loco import _context,_summary,_receipts
pin=lambda b:{'sha256':sha256_bytes(b),'size_bytes':len(b)}
def sealed(v):return n._sealed({k:w for k,w in v.items() if k!='identity_sha256'})
def zipped(members):
 s=io.BytesIO()
 with zipfile.ZipFile(s,'w',compression=zipfile.ZIP_STORED) as z:
  for k,v in members.items():z.writestr(k,v)
 return s.getvalue()
ctx=_context();family='GBM_COX';run='e'*64;source=ctx['modeling_program_sha256'];authorities=({run:source},{source:{}})
ids=ctx['training_ids']
partitions=[{'partition_id':f'R{r}K{k}','repeat':r,'inner_fold':k,'fit_ids':[p for p in ids if p not in ids[(k-1)*6:k*6]],'evaluation_ids':ids[(k-1)*6:k*6]} for r in range(1,4) for k in range(1,6)]
records=[{'family':fam,'repeat':r,'inner_fold':k,'imputation':i,'path':f'components/score/{fam}/R{r}_K{k}_M{i:02d}.zip'} for fam in n._families() for r in range(1,4) for k in range(1,6) for i in range(1,21)]
def build(h,old=None,drift=False):
 science=n.science_decision_template(h)
 spec={'family':family,'parameters':{'max_trees':1000,'early_stopping_metric':'cox_deviance','post_selection_refit':'full_main_training_at_selected_n_trees','locked_iteration_mode':'full_main_training_without_reselection'},'selected_trees':100,'selection_metric':f'IBS_0_{h}','selection_stage':'S3B2'}
 scores=[n.seal_fresh_training_score(family=fam,outer_fold=1,training_context_sha256=ctx['identity_sha256'],selected_spec=spec if fam==family else {'family':fam,'UNFITTED':True},selector_evidence_sha256='a'*64,summary={**_summary(.01 if fam==family else .2+idx*.01),'selection_horizon_months':h},execution_evidence_sha256='f'*64,selection_horizon_months=h,science_decision_sha256=science['identity_sha256']) for idx,fam in enumerate(n._families())]
 decision=n.select_training_family(scores)
 parameters=[copy.deepcopy(spec) for _ in range(20)]
 if drift:parameters[0]['selected_trees']+=1
 lock=n.seal_development_lock(context=ctx,decision=decision,science_decision=science,selected_parents=['AST_ALT','Age'],common_set_design_df=2,training_event_count=ctx['training_event_count'],parameters_by_imputation=parameters,recipe_sha256_by_imputation=[f'{i:064x}' for i in range(1,21)],baseline_policy_sha256='b'*64,seed_policy_sha256='c'*64,post_lock_template_sha256_by_imputation=[f'{i+100:064x}' for i in range(1,21)],post_lock_template_archive_sha256_by_imputation=[f'{i+200:064x}' for i in range(1,21)])
 request=sealed({'kind':'PADML_F4_O_FIT_INPUT_V1','training_context':ctx,'selection_horizon_months':h,'science_decision':science,'score_partitions':partitions,'component_records':records})
 receipt={'unit_id':f'PRIMARY-H{h:02d}-O1','status':'COMPLETED','direct_consumer_completed':True,'selection_horizon_months':h,'report_horizons_months':[6,12,24,36],'run_identity':run,'artifacts':{'input.zip':pin(f'UNFITTED_INPUT_{h}'.encode()),'input.compile.json':pin(b'{}'),'result.zip':pin(f'UNFITTED_RESULT_{h}'.encode())}}
 entries={};additional={};binding=None
 if old is not None:
  prefix=f'final-reuse/{old["receipt"]["unit_id"]}'
  proof=sealed({'kind':'PADML_F45_SCORE_REUSE_SOURCE_V1','whole_unit':old['receipt'],'executor_source_identity':source,'request':old['request'],'result_metadata':old['header']})
  additional={prefix+'/source.json':raw(proof),prefix+'/final-numbers.zip':old['entries']['final-numbers.zip']}
  binding={'path':prefix+'/source.json',**pin(raw(proof))}
 components=[]
 for i,r in enumerate(_receipts(lock),1):
  coords={'purpose':'NESTED_OUTER','outer_fold':1,'repeat':0,'inner_fold':0,'imputation':i}
  prediction={'f4_coordinates':coords,'patient_ids':ctx['heldout_ids'],'centers':['36']*2,'horizons':list(range(37)),'survival':{family:[[1.]+[.9-i/1000]*36 for _ in range(2)]}}
  health={'UNFITTED':True};r=sealed({**r,'training_response_sha256':ctx['training_response_sha256'],'prediction_sha256':n._sha(prediction),'fit_health_sha256':n._sha(health),'seed':f4._f4_model_seed(family,coords)})
  v={'receipt':r,'prediction':prediction,'fit_health':health,'object_audit':{'UNFITTED':True},'native_archive':{'member':f'fits/M{i:02d}.zip',**pin(f'UNFITTED_{i}'.encode())}}
  if binding:v['reused_final']={'source':binding,'imputation':i}
  components.append(v)
 pooled=_pool_prediction_batch([{'sealed_prediction':_seal_prediction_matrix(ctx['heldout_ids'],v['prediction']['survival'][family],list(range(37)))} for v in components],list(range(37)))['payload']['survival']
 mean=b''.join(struct.pack('<37d',*v) for v in pooled)
 selected=n.seal_selected_prediction(lock=lock,patient_ids=ctx['heldout_ids'],centers=['36']*2,survival=pooled,component_receipts=[v['receipt'] for v in components])
 final=sealed({'kind':'PADML_F4_O_FIT_FINAL_NUMBERS_V1','input_identity_sha256':request['identity_sha256'],'development_lock_sha256':lock['identity_sha256'],'components':components,'mean':{'encoding':'IEEE754_FLOAT64_LE_ROW_MAJOR','patient_ids':ctx['heldout_ids'],'centers':['36']*2,'horizons':list(range(37)),'imputation_count':20,**pin(mean)}})
 finalraw=zipped({'final.json':raw(final),'heldout-mean.f64':mean})
 header=sealed({'kind':'PADML_F4_O_FIT_EXECUTION_ARCHIVE_V3','outer_fold':1,'family':family,'development_lock':lock,'input_identity_sha256':request['identity_sha256'],'input_archive':receipt['artifacts']['input.zip'],'science_decision_sha256':science['identity_sha256'],'native_members':{v['native_archive']['member']:{k:v['native_archive'][k] for k in ('sha256','size_bytes')} for v in components},'members':{'final-numbers.zip':pin(finalraw),**{k:pin(v) for k,v in additional.items()}},'component_receipts':[v['receipt'] for v in components],'selected_prediction':selected})
 entries={'source-unit.json':raw(receipt),'o-fit-input.json':raw(request),'o-fit-execution.json':raw(header),'final-numbers.zip':finalraw,**additional}
 manifest={'kind':'PADML_F45_EVALUATION_SOURCE_V1','source_kind':'PRIMARY','unit_id':receipt['unit_id'],'horizon':h,'outer_fold':1,'source_receipt':receipt,'source_receipt_sha256':sha256_bytes(raw(receipt))}
 return {'entries':entries,'manifest':manifest,'receipt':receipt,'header':header,'request':request,'components':components}
old=build(6);current=build(12,old)
assert old['components'][0]['receipt']['parameter_sha256']!=current['components'][0]['receipt']['parameter_sha256']
checked=a._f45_evaluation_numbers(current['entries'],current['manifest'],authorities)
assert checked['reused_final_count']==20
assert checked['selected_prediction']['survival']==old['header']['selected_prediction']['survival']
bad=build(12,old,drift=True)
for v in bad['components']:n.validate_component_receipt(v['receipt'],bad['header']['development_lock'])
try:a._f45_evaluation_numbers(bad['entries'],bad['manifest'],authorities)
except ContractError as exc:
 assert str(exc)=='F45_EVALUATION_NUMBERS_SOURCE_DRIFT',str(exc)
 failure_frame=[];tb=exc.__traceback__
 while tb:
  if tb.tb_frame.f_code.co_name=='_f45_evaluation_numbers':failure_frame.append(tb.tb_lineno)
  tb=tb.tb_next
else:raise AssertionError('genuine selected_trees drift was accepted')
print(json.dumps({'status':'PASS','consumer':'padml.f5_sensitivity._f45_evaluation_numbers','positive':'synthetic GBM PRIMARY H06 to H12 all 20 reused_final, distinct complete parameter SHA, identical engine parameters','negative':'synthetic selected_trees 100 to 101 with own valid updated lock+receipt rejected','negative_consumer_line':failure_frame,'original_source_proof_validator_mocked':False,'all_predictions_synthetic':True,'clinical_numerical_work':False,'model_reads':0,'model_fits':0}))
