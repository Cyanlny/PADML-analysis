"""Coherent A+B+C+D+E package with the bounded FULL0 scoring continuation fix."""
import ast
import io
import json
import subprocess
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

from padml.bundle import canonical_json_bytes as encode, sha256_bytes, sha256_file, write_deterministic_zip
from padml.f4 import compile_f45_source_bundle, _f45_source_member_sha256, F45_SOURCE_MEMBERS

base=Path(__file__).resolve().parent
repo=base.parent
old_path=base/"release-final-reuse/PADML_F45_REBUILD_20260926_ABCDE_REUSE.zip"
assert sha256_file(old_path)=="5bd312d21280e16f4b6463ef33d70e5211c28db81dcbebd28571383ab3489d5d"
identity=sha256_bytes(encode(_f45_source_member_sha256()))
validated=json.loads((base/"full0-score-cache-source-validation.json").read_bytes())
assert validated["source_identity"]==identity
suite,=ET.parse(base/"full0-score-cache-and-producer.xml").getroot().findall("testsuite")
assert int(suite.attrib["tests"])==8 and all(int(suite.attrib[n])==0 for n in ("failures","errors","skipped"))
assert not subprocess.check_output(["git","diff","--name-only","HEAD","--",*F45_SOURCE_MEMBERS,"tests"],cwd=repo)
head=subprocess.check_output(["git","rev-parse","HEAD"],cwd=repo,text=True).strip()
for name in F45_SOURCE_MEMBERS:
    assert subprocess.check_output(["git","show",f"{head}:{name}"],cwd=repo)==(repo/name).read_bytes()
release_dir=base/"release-score-cache"
release_dir.mkdir(exist_ok=True)
compiled=compile_f45_source_bundle(release_dir/"source.zip")
with zipfile.ZipFile(old_path) as old:
    members={n:old.read(n) for n in old.namelist() if n!="release.json"}
old_run=json.loads(members["run.json"])
members["cache-predecessor/run.json"]=members["run.json"]
members["cache-predecessor/source.zip"]=members["source.zip"]
members["source.zip"]=(release_dir/"source.zip").read_bytes()
members["source.compile.json"]=encode(compiled)
run={**old_run,"source_identity":identity,"source_bundle_sha256":compiled["sha256"],
    "unit_predecessor":{"run_path":old_run["run_root"]+"/cache-predecessor/run.json",
        "run_sha256":sha256_bytes(members["cache-predecessor/run.json"]),
        "source_path":old_run["run_root"]+"/cache-predecessor/source.zip",
        "source_sha256":sha256_bytes(members["cache-predecessor/source.zip"])}}
run["identity"]=sha256_bytes(encode({k:v for k,v in run.items() if k!="identity"}))
members["run.json"]=encode(run)
evidence={n:base/n for n in ("full0-score-cache-and-producer.xml",
    "full0-score-cache-source-validation.json","validate_full0_score_cache_source.py",
    "compile_full0_score_cache_release.py","full0-score-cache-regression.xml",
    "full0-score-cache-regression-corrected.xml","full0-score-cache-regression-final.xml",
    "full0-score-cache-regression-pass.xml")}
evidence["tests/test_f45_full0_score_cache_release.py"]=repo/"tests/test_f45_full0_score_cache_release.py"
write_deterministic_zip(release_dir/"full0-score-cache-checks.zip",evidence)
members["full0-score-cache-checks.zip"]=(release_dir/"full0-score-cache-checks.zip").read_bytes()
addendum=(
    "\n\nFULL0 scoring continuation repair: each original completed Q consumer and byte inventory "
    "returns before the existing scoped closed-file cache advisory runs. It checks inode aliases "
    "and live readers; no files are deleted. Real resource admission is unchanged, including "
    "2 GiB per worker and the scoring coordinator reserve. UNKNOWN advice does not imply free RAM. "
    "A retained FULL0 scoring request keeps its original input producer only after exact same-run "
    "source qualification and equality of all non-program context fields and all development evidence; "
    "every rebuilt component and full request must still match original bytes. Unknown source, "
    "patient, parameter and request changes are rejected. Eight new UNFITTED boundary cases pass, "
    "in addition to the predecessor's 69 cases and completed whole native-reader evidence. "
    "Engineering readiness is not clinical completion. Only idle hosts may cut over via the existing "
    "atomic release helper; current scientific outputs and producer coordinates are preserved.\n")
for name in ("README.md","COMPILE_REPORT.md","EXECUTION_HANDOFF.md"):
    members[name]+=addendum.encode()
for name in ("AGENTS.md","NESTED_LOCO_PROTOCOL.md"):
    assert members[name]==(repo/name).read_bytes()
release={"kind":"PADML_F45_ABCDE_SCORE_CACHE_RELEASE","head":head,"run_identity":run["identity"],
    "source_identity":identity,"members":{n:{"sha256":sha256_bytes(b),"size_bytes":len(b)} for n,b in members.items()}}
members["release.json"]=encode(release)
target=release_dir/"PADML_F45_REBUILD_20260926_ABCDE_SCORE_CACHE.zip"
write_deterministic_zip(target,members)
with zipfile.ZipFile(target) as archive:
    assert {n:archive.read(n) for n in archive.namelist()}==members
with zipfile.ZipFile(old_path) as original:
    for n in ("shared/bootstrap.zip","shared/bootstrap-preparation.json","science-decision.json","dependencies.json"):
        assert members[n]==original.read(n)
summary={"head":head,"package":str(target),"sha256":sha256_file(target),"size_bytes":target.stat().st_size,
    "source_identity":identity,"run_identity":run["identity"],"source":compiled,
    "preserved_engineering_cases":69,"new_engineering_cases":8,"deployed":False,
    "clinical_completion_claimed":False}
(release_dir/"compile-summary.json").write_bytes(encode(summary))
print(json.dumps(summary))
