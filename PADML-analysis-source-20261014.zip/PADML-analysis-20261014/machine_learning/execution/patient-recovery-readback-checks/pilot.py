"""One finite H0 patient trial under the original execute_f45 owner and pool.

Executor-only: use the frozen package's Python environment and source path.
This calls no fit/MICE/replay and never publishes a whole-unit result.
"""
import json
import os
import sys
from pathlib import Path
from time import monotonic

from padml import f4, f5, nested_loco as n, runtime, worker
from padml.bundle import canonical_json_bytes as encode, sha256_file


class PilotComplete(Exception):
    pass


def pilot_job(job):
    root, policy = Path(job['root']), job['policy']
    started = monotonic()
    inputs, outputs = root / 'final-input', root / 'final-result'
    checkpoints = outputs / 'shap-components'
    lineage = f5._read_final_lineage(inputs / 'lineage.json', selection_horizon_months=6)
    plan = lineage['final_refit_plan']
    n._require(plan['kind'] == 'PADML_NESTED_FULL_FINAL_INPUT_V1'
        and plan['selection_horizon_months'] == 6, 'PILOT_FULL0_H06_REQUIRED')
    sources = {'padml/f5.py': sha256_file(Path(f5.__file__)),
        'padml/kernels/f5_shap.R': sha256_file(Path(f5.__file__).with_name('kernels') / 'f5_shap.R')}
    rows, missing, complete, original_numbers = [], [], [], {}
    best, selected = None, None
    for imp in range(1, 21):
        source, target = inputs / f'bound/M{imp:02d}.zip', outputs / f'F5_FINAL_FULL_DATA_M{imp:02d}.zip'
        task, recipe, entries = n._read_component(source)
        n._validate_full_final_component(source, context=plan['training_context'],
            lock=plan['development_lock'], parsed_component=(task, recipe, entries))
        numbers = f5._collect_final_refit_component((target, source, task, plan, plan['family_decision'], None))
        n._require('reused_final' not in numbers, 'PILOT_ORIGINAL_H0_MODEL_REQUIRED')
        original_numbers[imp] = sha256_file(target.with_suffix('.numbers.json'))
        prediction = f5._full_final_prediction_record(numbers['prediction'], numbers['receipt'], task['family'])
        binding = f5._f45_final_shap_binding(source, numbers['archive']['archive_sha256'], task, prediction, sources)
        previous, donor = f5._f45_previous_shap(checkpoints, binding, source, task, prediction)
        if previous is not None:
            complete.append(imp)
            continue
        if donor is None:
            missing.append(imp)
            continue
        diagnostic = f5._read_final_shap_diagnostic(Path(donor['raw_path']).parent, task, prediction,
            numbers['receipt']['model_sha256'], expected_budget=500, require_converged=False)
        failures = []
        for index, converged in enumerate(diagnostic['converged']):
            if converged:
                continue
            ratios = [se / width if width > 0 else float('inf') if se > 0 else 0.0
                for se, width in zip(diagnostic['maximum_se'][index], diagnostic['shap_range'][index], strict=True)]
            score = max(ratios)
            failures.append({'patient_index': index + 1,
                'failed_horizons': [h for h, ok in zip(f5.REPORT_HORIZONS, diagnostic['criterion'][index], strict=True) if not ok],
                'maximum_relative_se': score if score != float('inf') else 'UNBOUNDED_ZERO_RANGE'})
            rank = (score, -imp, -index)
            if best is None or rank > best:
                best, selected = rank, (source, target, task, entries, numbers, prediction, binding, donor, index + 1)
        rows.append({'imputation': imp, 'patients': len(prediction['patient_ids']), 'failed_rows': failures})
    n._require(selected is not None, 'PILOT_NO_FAILED_ORIGINAL500_PATIENT')
    source, target, task, entries, numbers, prediction, binding, donor, patient = selected
    work = checkpoints / f"F5_FINAL_AGGREGATE_SHAP_M{task['imputation']:02d}_{binding['identity_sha256']}"
    n._require(not work.is_symlink(), 'F5_SHAP_CHECKPOINT_PATH_INVALID')
    work.mkdir(mode=0o700, exist_ok=True)
    n._write_exact_once(work / 'binding.json', encode(binding), 'F5_SHAP_CHECKPOINT_BINDING_DRIFT')
    selection = {'kind': 'PADML_H0_FINITE_PATIENT_PILOT_V1', 'run_identity': job['run_identity'],
        'source_identity': job['source_identity'], 'imputation': task['imputation'], 'patient_index': patient,
        'binding_identity_sha256': binding['identity_sha256'], 'work_root': str(work),
        'max_iter': 2000, 'tol': .005, 'pool_deadline_seconds': 7200,
        'rng_policy': 'ORIGINAL_500_PATIENT_START', 'completed_old_components': complete,
        'missing_old_raw_imputations': missing, 'original500_diagnostics': rows,
        'original_numbers_sha256': {str(imp): digest for imp, digest in original_numbers.items()},
        'whole_unit_completion': False}
    n._write_exact_once(checkpoints / 'pilot-selection.json', encode(selection), 'PILOT_SELECTION_DRIFT')
    objects = f5._f45_final_native_objects(target, entries, numbers)
    prepared = monotonic()
    diagnostic = f5._produce_final_shap_component(source, task, objects['model.bin'], objects['baseline.bin'],
        prediction, work_root=work, recovery_source=donor, pilot_patient_index=patient)
    n._require(sha256_file(target) == numbers['archive']['archive_sha256']
        and all(sha256_file(outputs / f'F5_FINAL_FULL_DATA_M{imp:02d}.numbers.json') == digest
            for imp, digest in original_numbers.items()), 'PILOT_RETAINED_MODEL_OR_NUMBERS_CHANGED')
    return {'kind': 'PADML_H0_FINITE_PATIENT_PILOT_RESULT_V1', 'status': diagnostic['status'],
        'run_identity': job['run_identity'], 'source_identity': job['source_identity'],
        'imputation': task['imputation'], 'patient_index': patient, 'max_iter': 2000, 'tol': .005,
        'n_iter': diagnostic['n_iter'], 'criterion': diagnostic['criterion'],
        'maximum_se': diagnostic['maximum_se'], 'shap_range': diagnostic['shap_range'],
        'preparation_seconds': prepared - started, 'native_and_postcheck_seconds': monotonic() - prepared,
        'diagnostic_path': str(work / 'pilot-diagnostic.json'),
        'diagnostic_sha256': sha256_file(work / 'pilot-diagnostic.json'),
        'checkpoint_path': str(work / 'patients' / f'P{patient:05d}.rds'),
        'model_fits': 0, 'whole_unit_completion': False}


def pilot_action(run, unit, root, context):
    n._require(unit['unit_id'] == 'FULL0-H06' and not (root / 'unit.json').exists(), 'PILOT_SCOPE_INVALID')
    policy = {**run['resource_policy'], 'memory_bytes_per_worker': 2 * 1024**3, 'scratch_reserve_bytes': 0}
    runtime.resource_admission(policy, runtime.observe_execution_resources(root), legal_tasks=1)
    report = {}
    with f5._full_score_scratch(root):
        result, = runtime._bounded_ordered_spawn(pilot_job, [{'root': str(root), 'policy': policy,
            'run_identity': run['identity'], 'source_identity': run['source_identity']}],
            selected_slots=1, execution_report=report, task_timeout_seconds=7200)
    n._write_exact_once(root / 'final-result/shap-components/pilot-result.json', encode({**result, 'pool': report}),
        'PILOT_RESULT_ALREADY_PRESENT')
    print(json.dumps(result), flush=True)
    raise PilotComplete(result)


def main():
    n._require(len(sys.argv) == 2, 'USAGE: pilot.py /absolute/frozen/run.json')
    run_path = Path(sys.argv[1]).resolve(strict=True)
    if os.getpgrp() != os.getpid():
        os.setsid()
    os.environ.update(runtime.THREAD_ENV)
    os.environ['R_LIBS_USER'] = runtime.R_LIBRARY
    original = worker._f45_full0
    worker._f45_full0 = pilot_action
    try:
        worker.execute_f45(run_path, 'FULL0-H06')
    except PilotComplete as completed:
        return 0 if completed.args[0]["status"] == "CONVERGED" else 2
    finally:
        worker._f45_full0 = original


if __name__ == '__main__':
    sys.exit(main())
